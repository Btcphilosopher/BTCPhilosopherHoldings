'use client';

import React, { useState } from 'react';
import Header from '../components/Header';
import Hero from '../components/Hero';
import PriceEngine from '../components/PriceEngine';
import TrackingMap from '../components/TrackingMap';
import PortNetwork from '../components/PortNetwork';
import TradeLanes from '../components/TradeLanes';
import ContainerTools from '../components/ContainerTools';
import ImportExportCustoms from '../components/ImportExportCustoms';
import CustomerDashboard from '../components/CustomerDashboard';
import AdminConsole from '../components/AdminConsole';
import Footer from '../components/Footer';
import { QuoteOutput } from '@/lib/shippingData';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldAlert, Sparkles, Anchor, Scale, BadgeHelp, HelpCircle, 
  ArrowRight, ShieldCheck, Mail, Phone, MapPin 
} from 'lucide-react';

export default function Home() {
  const [activeTab, setActiveTab] = useState('ship');
  const [isLoggedIn, setIsLoggedIn] = useState(true); // Pre-log-in for awesome demo convenience
  const [customBookings, setCustomBookings] = useState<QuoteOutput[]>([]);
  
  // Quick Dialog / Form states
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginEmail, setLoginEmail] = useState('tom@ahyx.org');
  const [loginPass, setLoginPass] = useState('••••••••');

  const handleBookingSuccess = (quote: QuoteOutput) => {
    setCustomBookings([quote, ...customBookings]);
    // Smooth redirect to portal
    setActiveTab('portal');
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggedIn(true);
    setShowLoginModal(false);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  // Structured Data (JSON-LD) for Schema.org SEO compliance (applet-seo skill)
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'WebApplication',
    'name': 'Medway Maritime Pricing Engine',
    'applicationCategory': 'BusinessApplication',
    'operatingSystem': 'All',
    'description': 'Kent-based maritime shipping agency, intermodal freight platform, and container pricing engine.',
    'offers': {
      '@type': 'Offer',
      'price': '0',
      'priceCurrency': 'GBP'
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#1C252C] font-sans flex flex-col justify-between selection:bg-[#F37021]/30">
      
      {/* Inject JSON-LD Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      {/* Header Contract */}
      <Header 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        openQuote={() => {
          setActiveTab('ship');
          const el = document.getElementById('price-engine');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        openLogin={() => setShowLoginModal(true)}
        isLoggedIn={isLoggedIn}
        onLogout={handleLogout}
      />

      {/* Hero Section displayed on landing tab */}
      {activeTab === 'ship' && (
        <Hero 
          onPriceClick={() => {
            const el = document.getElementById('price-engine');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          onExploreRoutes={() => setActiveTab('routes')}
          onTrackClick={() => setActiveTab('track')}
        />
      )}

      {/* Dynamic Content Views Render container */}
      <main className="flex-grow w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
          >
            {activeTab === 'ship' && (
              <div className="space-y-12">
                
                {/* 1. Core Price Engine */}
                <PriceEngine 
                  onBookingSuccess={handleBookingSuccess} 
                  onRequestTabSwitch={setActiveTab}
                />

                {/* 2. Popular Trade Lanes Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
                  <div className="p-5 border border-slate-200 bg-white rounded shadow-sm">
                    <span className="text-[10px] font-mono font-bold text-[#F37021] block uppercase mb-1">INTERMODAL LOGISTICS</span>
                    <h4 className="text-sm font-mono font-bold text-[#0B1E36] uppercase mb-2">ROAD. RAIL. SEA.</h4>
                    <p className="text-xs text-slate-500 leading-relaxed font-sans">
                      Medway Maritime operates comprehensive drayage routes connecting active UK terminals. Optimize transit parameters using rail siding slots or direct road haulage.
                    </p>
                  </div>

                  <div className="p-5 border border-slate-200 bg-white rounded shadow-sm">
                    <span className="text-[10px] font-mono font-bold text-[#F37021] block uppercase mb-1">TRANSPARENCY MANDATE</span>
                    <h4 className="text-sm font-mono font-bold text-[#0B1E36] uppercase mb-2">ONE QUOTE. EVERY LEG.</h4>
                    <p className="text-xs text-slate-500 leading-relaxed font-sans">
                      Eradicate hidden port handling tariffs or customs filing surcharges. Receive indicative pricing covering UK collection to final discharge gate.
                    </p>
                  </div>

                  <div className="p-5 border border-slate-200 bg-white rounded shadow-sm">
                    <span className="text-[10px] font-mono font-bold text-[#F37021] block uppercase mb-1">COMPLIANCE PORTAL</span>
                    <h4 className="text-sm font-mono font-bold text-[#0B1E36] uppercase mb-2">CUSTOMS DE-RISKED</h4>
                    <p className="text-xs text-slate-500 leading-relaxed font-sans">
                      Our trade desks coordinate Bill of Lading, Certificate of Origin, and import CDS clearance logs seamlessly to prevent demurrage charges.
                    </p>
                  </div>
                </div>

                {/* 3. Operational Headquarters profile card (Kent geography identity) */}
                <div className="bg-[#0B1E36] text-white p-8 rounded-lg text-left grid grid-cols-1 md:grid-cols-12 gap-8 items-center border border-slate-800">
                  <div className="md:col-span-8 space-y-4">
                    <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#F37021] tracking-wider uppercase">
                      <Anchor className="w-4 h-4" />
                      COGNIZANT OF PHYSICAL GEOGRAPHY
                    </div>
                    <h3 className="text-2xl font-mono font-bold tracking-tight">THE MEDWAY ESTUARY OPERATIONS HUB</h3>
                    <p className="text-xs text-slate-300 leading-relaxed font-sans">
                      From Rochester, Gravesend, and Sheerness terminals, our fleet commands transit corridors running down the River Medway and out into the North Sea trade lanes. By positioning our primary dispatch coordinators adjacent to active Kent intermodal hubs, we secure prioritized loading allocations.
                    </p>
                    <div className="flex flex-wrap gap-4 text-[11px] font-mono font-bold text-slate-400">
                      <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-[#F37021]" /> ME1 CHATHAM WHARF</span>
                      <span>• M2/M20 ROAD ACCESS</span>
                      <span>• RAIL CONNECTED SIDINGS</span>
                    </div>
                  </div>

                  <div className="md:col-span-4 bg-[#1C252C] p-5 rounded border border-white/5 space-y-3 font-mono text-xs">
                    <div className="text-white font-bold pb-2 border-b border-white/10 text-[10px] uppercase tracking-wider">OFFICE GEOGRAPHY CONTACT</div>
                    <div className="flex items-center gap-2"><Mail className="w-4 h-4 text-[#F37021]" /> ops@medway-maritime.demo</div>
                    <div className="flex items-center gap-2"><Phone className="w-4 h-4 text-[#F37021]" /> +44 (0) 1634 882100</div>
                    <div className="text-[10px] text-slate-500 uppercase font-bold pt-1">ROCHESTER, KENT, ME1</div>
                  </div>
                </div>

              </div>
            )}

            {activeTab === 'rates' && <TradeLanes />}
            
            {activeTab === 'routes' && <ContainerTools />}

            {activeTab === 'ports' && <PortNetwork />}

            {activeTab === 'track' && <TrackingMap />}

            {activeTab === 'customs' && <ImportExportCustoms />}

            {activeTab === 'portal' && (
              <CustomerDashboard 
                customBookings={customBookings} 
                activeTab={activeTab} 
              />
            )}

            {activeTab === 'admin' && <AdminConsole />}

          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <Footer setActiveTab={setActiveTab} />

      {/* QUICK LOGIN DIALOG MODAL */}
      {showLoginModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-lg border border-slate-200 p-6 max-w-sm w-full text-left font-sans shadow-2xl">
            <h3 className="text-sm font-mono font-bold text-[#0B1E36] uppercase border-b border-slate-100 pb-3 mb-4">
              DEMO CLIENT SECURITY LOGIN
            </h3>
            
            <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs font-mono font-bold">
              <div>
                <label className="block text-slate-500 text-[10px] uppercase mb-1.5">EMAIL REGISTER</label>
                <input
                  type="email"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  className="w-full px-2.5 py-2 border border-slate-300 rounded bg-white font-mono focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-500 text-[10px] uppercase mb-1.5">PASS CODE</label>
                <input
                  type="password"
                  value={loginPass}
                  onChange={(e) => setLoginPass(e.target.value)}
                  className="w-full px-2.5 py-2 border border-slate-300 rounded bg-white focus:outline-none"
                  required
                />
              </div>

              <div className="p-3 bg-blue-50 border border-blue-100 rounded text-[10px] leading-relaxed text-blue-800 font-normal">
                * Simulated Accounts: Enter any credentials to authenticate and view shipment dashboards.
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-grow py-2.5 bg-[#0B1E36] hover:bg-[#1C252C] transition-colors text-white text-xs font-mono font-bold rounded uppercase tracking-wider text-center"
                >
                  AUTHORIZE SESSION
                </button>
                <button
                  type="button"
                  onClick={() => setShowLoginModal(false)}
                  className="px-4 py-2.5 border border-slate-300 text-slate-600 rounded text-xs font-mono font-bold uppercase hover:bg-slate-50"
                >
                  CANCEL
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
