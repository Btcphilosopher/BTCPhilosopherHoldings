import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Medway Maritime – UK Container Shipping & Intermodal Freight Platform',
  description: 'Kent-based maritime shipping agency, intermodal freight platform, and container pricing engine. Move goods, move business from warehouse to world.',
  openGraph: {
    title: 'Medway Maritime – UK Container Shipping & Intermodal Freight Platform',
    description: 'Kent-based maritime shipping agency, intermodal freight platform, and container pricing engine. Move goods, move business from warehouse to world.',
    type: 'website',
    images: [
      {
        url: 'https://picsum.photos/seed/medway/1200/630',
        width: 1200,
        height: 630,
        alt: 'Medway Maritime Cargo Container Vessel',
      }
    ]
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Medway Maritime – UK Container Shipping & Intermodal Freight Platform',
    description: 'Kent-based maritime shipping agency, intermodal freight platform, and container pricing engine. Move goods, move business from warehouse to world.',
    images: ['https://picsum.photos/seed/medway/1200/630'],
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning className="antialiased bg-[#F8F9FA]">
        {children}
      </body>
    </html>
  );
}
