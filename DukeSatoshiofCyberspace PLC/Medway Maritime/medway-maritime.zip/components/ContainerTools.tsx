'use client';

import React, { useState } from 'react';
import { CONTAINER_TYPES } from '@/lib/shippingData';
import { 
  Calculator, Package, AlertCircle, ShoppingBag, ShieldAlert,
  ArrowRight, CheckCircle, ChevronDown, Plus, Minus
} from 'lucide-react';

export default function ContainerTools() {
  const [activeTab, setActiveTab] = useState<'catalog' | 'calculator'>('catalog');

  // Calculator inputs
  const [palletQty, setPalletQty] = useState(14);
  const [palletWeightKg, setPalletWeightKg] = useState(850);
  const [palletWidthCm, setPalletWidthCm] = useState(120);
  const [palletLengthCm, setPalletLengthCm] = useState(100);
  const [palletHeightCm, setPalletHeightCm] = useState(160);

  // Calculated states
  const totalVolumeCbm = Math.round((palletWidthCm / 100 * palletLengthCm / 100 * palletHeightCm / 100 * palletQty) * 10) / 10;
  const totalWeightKg = palletQty * palletWeightKg;

  // Recommended Container choosing logic
  const getRecommendation = () => {
    // Standard packing capacities for EUR pallets (120x80) or ISO pallets (120x100)
    // 20GP can hold approx 10-11 ISO Pallets or 14 EUR Pallets
    // 40GP can hold approx 21-22 ISO Pallets or 25 EUR Pallets
    // 40HC can hold same but has higher height ceiling
    let rec = CONTAINER_TYPES[0]; // default 20GP

    if (palletQty > 10 || totalVolumeCbm > 28 || totalWeightKg > 21000) {
      rec = CONTAINER_TYPES[2]; // 40HC
    } else if (palletQty > 22 || totalVolumeCbm > 60) {
      rec = CONTAINER_TYPES[3]; // 45HC
    }

    // Calc capacity utilization percentage
    const utilizationCbm = Math.min(100, Math.round((totalVolumeCbm / rec.capacityCbm) * 100));
    const utilizationWeight = Math.min(100, Math.round((totalWeightKg / rec.weightLimitKg) * 100));
    const finalUtil = Math.max(utilizationCbm, utilizationWeight);

    return {
      container: rec,
      utilizationCbm,
      utilizationWeight,
      finalUtil
    };
  };

  const recResult = getRecommendation();

  return (
    <div className="bg-white border border-slate-200 rounded-lg p-6 lg:p-8 max-w-6xl mx-auto my-8 shadow-sm text-left text-[#1C252C]">
      
      {/* Title */}
      <div className="mb-6 border-b border-slate-100 pb-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Package className="w-5 h-5 text-[#F37021]" />
            <h2 className="text-xl font-mono font-bold tracking-wider text-[#0B1E36] uppercase">CONTAINER SPECIFICATIONS & LOADING CALCULATOR</h2>
          </div>
          <p className="text-xs text-slate-500 font-sans">
            Audit physical tare weights, cubic capacities, and simulate pallet loading algorithms to determine container requirements.
          </p>
        </div>

        {/* Tab Controls (Functional tabs with click handlers) */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-mono font-bold self-start">
          <button 
            onClick={() => setActiveTab('catalog')} 
            className={`px-3 py-1.5 rounded transition-colors ${activeTab === 'catalog' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            CONTAINER CATALOG
          </button>
          <button 
            onClick={() => setActiveTab('calculator')} 
            className={`px-3 py-1.5 rounded transition-colors ${activeTab === 'calculator' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            HOW MUCH FITS?
          </button>
        </div>
      </div>

      {activeTab === 'catalog' ? (
        /* TAB 1: CONTAINER CATALOG */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {CONTAINER_TYPES.map((type) => (
            <div key={type.code} className="bg-slate-50 border border-slate-200 rounded p-5 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-3">
                  <span className="font-mono font-bold text-xs bg-[#0B1E36] text-white px-2 py-0.5 rounded uppercase">
                    {type.code}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 font-bold uppercase">
                    ISO STANDARD
                  </span>
                </div>

                <h4 className="text-xs font-mono font-bold text-[#0B1E36] uppercase mb-2">{type.name}</h4>
                
                <div className="space-y-1 text-[11px] font-mono text-slate-600 leading-normal">
                  <div className="flex justify-between">
                    <span>INTERNAL DIMS:</span>
                    <span className="font-bold text-slate-800">{type.dimensions}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>CUBIC CAPACITY:</span>
                    <span className="font-bold text-slate-800">{type.capacityCbm} m³ (CBM)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>MAX CARGO WEIGHT:</span>
                    <span className="font-bold text-slate-800">{type.weightLimitKg.toLocaleString()} KG</span>
                  </div>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed pt-3 mt-3 border-t border-slate-100 font-sans">
                  {type.typicalUse}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 text-[9px] font-mono text-slate-400 uppercase tracking-wider">
                * High-tensile steel construction. Sea & rail certified.
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* TAB 2: PACKING CALCULATOR */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Form left Column */}
          <div className="lg:col-span-5 bg-slate-50 border border-slate-200 p-5 rounded space-y-4">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 pb-2 border-b border-slate-200">
              SIMULATED PALLET SPECIFICATIONS
            </h3>

            <div className="space-y-3.5 text-xs font-mono font-bold">
              <div>
                <label className="block text-slate-500 text-[10px] uppercase mb-1.5">PALLET QUANTITY</label>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setPalletQty(Math.max(1, palletQty - 1))}
                    className="p-1.5 bg-slate-200 hover:bg-slate-300 rounded focus:outline-none"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <input
                    type="number"
                    value={palletQty}
                    onChange={(e) => setPalletQty(parseInt(e.target.value) || 1)}
                    className="w-16 text-center py-1 border border-slate-300 rounded font-mono"
                  />
                  <button 
                    onClick={() => setPalletQty(palletQty + 1)}
                    className="p-1.5 bg-slate-200 hover:bg-slate-300 rounded focus:outline-none"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-slate-400 font-normal text-[11px] uppercase">Standard ISO Pallets (120x100)</span>
                </div>
              </div>

              <div>
                <label className="block text-slate-500 text-[10px] uppercase mb-1.5">AVERAGE WEIGHT PER PALLET (KG)</label>
                <input
                  type="number"
                  value={palletWeightKg}
                  onChange={(e) => setPalletWeightKg(parseInt(e.target.value) || 100)}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono bg-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-500 text-[9px] uppercase mb-1">LENGTH (CM)</label>
                  <input
                    type="number"
                    value={palletLengthCm}
                    onChange={(e) => setPalletLengthCm(parseInt(e.target.value) || 120)}
                    className="w-full px-2 py-1.5 border border-slate-300 rounded font-mono bg-white text-center"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 text-[9px] uppercase mb-1">WIDTH (CM)</label>
                  <input
                    type="number"
                    value={palletWidthCm}
                    onChange={(e) => setPalletWidthCm(parseInt(e.target.value) || 100)}
                    className="w-full px-2 py-1.5 border border-slate-300 rounded font-mono bg-white text-center"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 text-[9px] uppercase mb-1">HEIGHT (CM)</label>
                  <input
                    type="number"
                    value={palletHeightCm}
                    onChange={(e) => setPalletHeightCm(parseInt(e.target.value) || 150)}
                    className="w-full px-2 py-1.5 border border-slate-300 rounded font-mono bg-white text-center"
                  />
                </div>
              </div>

            </div>

            <div className="p-3 bg-blue-50 border border-blue-200 text-blue-800 text-[10px] font-mono leading-normal rounded">
              * Calculations assume standard 3D pallet cube structures without overhang.
            </div>
          </div>

          {/* Results right Column */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Recommendation block */}
            <div className="border border-slate-200 rounded p-5 bg-slate-50">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 mb-4">
                LOADING UTILIZATION REPORT
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                <div>
                  <span className="block text-[9px] font-mono text-slate-500 uppercase font-bold tracking-widest">RECOMMENDED TYPE</span>
                  <span className="font-mono font-bold text-lg text-[#F37021] block mt-0.5">{recResult.container.name}</span>
                  <span className="text-[10px] font-mono text-slate-400 mt-0.5 block font-semibold">{recResult.container.code} specification</span>
                </div>

                <div className="space-y-2 text-xs font-mono font-bold">
                  <div>
                    <div className="flex justify-between text-slate-600 mb-1">
                      <span>VOLUME UTILIZATION:</span>
                      <span>{recResult.utilizationCbm}%</span>
                    </div>
                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div className="bg-[#0B1E36] h-full" style={{ width: `${recResult.utilizationCbm}%` }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-slate-600 mb-1">
                      <span>WEIGHT CAPACITY UTILIZATION:</span>
                      <span>{recResult.utilizationWeight}%</span>
                    </div>
                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div className="bg-[#F37021] h-full" style={{ width: `${recResult.utilizationWeight}%` }} />
                    </div>
                  </div>
                </div>
              </div>

              {/* Data Summary row */}
              <div className="grid grid-cols-3 gap-2 bg-white border border-slate-200 p-4 rounded mt-6 text-xs font-mono font-bold text-slate-600">
                <div>
                  <span className="block text-[8px] text-slate-400 uppercase">TOTAL CUBIC VOL</span>
                  <span className="text-slate-800 block text-sm font-extrabold mt-0.5">{totalVolumeCbm} m³</span>
                </div>
                <div>
                  <span className="block text-[8px] text-slate-400 uppercase">TOTAL CARGO WT</span>
                  <span className="text-slate-800 block text-sm font-extrabold mt-0.5">{(totalWeightKg / 1000).toFixed(1)} Tons</span>
                </div>
                <div>
                  <span className="block text-[8px] text-slate-400 uppercase">PALLET COUNT</span>
                  <span className="text-[#0B1E36] block text-sm font-extrabold mt-0.5">{palletQty} ISO units</span>
                </div>
              </div>
            </div>

            {/* Warning disclosure */}
            <div className="p-4 bg-orange-50 border border-orange-200 text-orange-800 text-xs leading-relaxed rounded flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-[#F37021] shrink-0 mt-0.5" />
              <div>
                <span className="font-mono font-bold block uppercase mb-1">PROFESSIONAL VERIFICATION REQUIRED</span>
                This container loading calculator generates approximate container size recommendations using volumetric algorithms. Actual packing configurations depend on cargo weight center points, loading sequences, and dynamic port transit weight mandates. Always verify with our engineering office before dispatch.
              </div>
            </div>

          </div>

        </div>
      )}

    </div>
  );
}
