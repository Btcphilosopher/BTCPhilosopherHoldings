'use client';

import React from 'react';
import Image from 'next/image';
import { motion } from 'motion/react';
import { ArrowRight, Calculator, MapPin, Compass } from 'lucide-react';

interface HeroProps {
  onPriceClick: () => void;
  onExploreRoutes: () => void;
  onTrackClick: () => void;
}

export default function Hero({ onPriceClick, onExploreRoutes, onTrackClick }: HeroProps) {
  // Use the high fidelity generated image path
  const heroImgUrl = '/src/assets/images/hero_maritime_estuary_1790958078632.jpg';

  return (
    <section className="relative w-full min-h-[85vh] flex items-center bg-[#0B1E36] overflow-hidden">
      {/* Background Image with precise dark scrim */}
      <div className="absolute inset-0 w-full h-full z-0">
        <Image
          src={heroImgUrl}
          alt="Container ship navigating the River Medway Estuary in Kent"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center filter brightness-[0.45] contrast-[1.05]"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B1E36] via-[#0B1E36]/40 to-transparent z-10" />
      </div>

      {/* Main Content Area */}
      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full text-white">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Column 1: Marketing / Copy */}
          <div className="lg:col-span-7 flex flex-col items-start gap-6">
            <div className="flex items-center gap-2 border-l-2 border-[#F37021] pl-3 text-xs font-mono font-bold tracking-widest text-[#F37021]">
              MEDWAY MARITIME • KENT BASE, GLOBAL REACH
            </div>

            <motion.h1 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight font-sans leading-[1.1] text-wrap-balance"
            >
              MOVE GOODS.<br />
              <span className="text-[#FBBF24]">MOVE BUSINESS.</span>
            </motion.h1>

            <motion.p 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="text-lg md:text-xl text-slate-200 font-sans max-w-xl leading-relaxed"
            >
              From warehouse to port. From port to world. Commercial maritime agency, container intermodal freight operations, and customs coordination based in Rochester, Kent.
            </motion.p>

            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto mt-2"
            >
              <button
                onClick={onPriceClick}
                className="group flex items-center justify-center gap-2.5 px-6 py-4 text-sm font-mono font-bold uppercase text-[#0B1E36] bg-[#F37021] rounded hover:bg-[#F37021]/90 transition-all duration-200 active:scale-95 shadow-lg shadow-orange-500/20"
              >
                <Calculator className="w-4 h-4" />
                <span>PRICE A CONTAINER</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onExploreRoutes}
                className="flex items-center justify-center gap-2 px-6 py-4 text-sm font-mono font-bold uppercase text-white bg-slate-800/80 border border-white/20 rounded hover:bg-slate-700/90 transition-all duration-200"
              >
                <Compass className="w-4 h-4" />
                <span>EXPLORE ROUTE NETWORK</span>
              </button>
            </motion.div>
          </div>

          {/* Column 2: Quick Metrics / Interactive Quick Tracker Widget */}
          <div className="lg:col-span-5 w-full">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-[#1C252C]/90 border border-white/10 p-6 rounded-lg shadow-2xl backdrop-blur-sm"
            >
              <div className="flex items-center justify-between pb-4 border-b border-white/10">
                <span className="text-xs font-mono font-bold tracking-wider text-slate-400">INSTANT VESSEL TRACKING</span>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              </div>

              <div className="py-5 space-y-4">
                <p className="text-xs text-slate-300 leading-normal">
                  Enter your container number or shipment booking reference to check real-time vessel status and intermodal handovers.
                </p>
                
                <div className="relative">
                  <input
                    type="text"
                    id="hero-track-input"
                    placeholder="e.g., MED-2026-004821"
                    defaultValue="MED-2026-004821"
                    className="w-full px-4 py-3 bg-[#0B1E36] border border-white/20 rounded font-mono text-sm uppercase placeholder-slate-500 text-white focus:outline-none focus:border-[#F37021] transition-colors"
                  />
                  <button
                    onClick={() => {
                      const input = document.getElementById('hero-track-input') as HTMLInputElement;
                      if (input && input.value) {
                        onTrackClick();
                        // Put in localstorage to share across components
                        localStorage.setItem('medway_search_ref', input.value);
                      }
                    }}
                    className="absolute right-2 top-1.5 px-3 py-1.5 bg-[#F37021] hover:bg-orange-600 transition-colors rounded text-xs font-mono font-bold text-[#0B1E36]"
                  >
                    TRACK
                  </button>
                </div>
              </div>

              {/* Monospace Quick Data Board */}
              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/10 text-left">
                <div>
                  <span className="block text-[10px] font-mono text-slate-500 uppercase">HEADQUARTERS</span>
                  <span className="text-xs font-mono font-bold text-white flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3 h-3 text-[#F37021]" />
                    Rochester, Medway
                  </span>
                </div>
                <div>
                  <span className="block text-[10px] font-mono text-slate-500 uppercase">FLEET IN SERVICE</span>
                  <span className="text-xs font-mono font-bold text-white mt-0.5 block">
                    52 Cargo Vessels
                  </span>
                </div>
                <div>
                  <span className="block text-[10px] font-mono text-slate-500 uppercase">ACTIVE ROUTES</span>
                  <span className="text-xs font-mono font-bold text-white mt-0.5 block">
                    50+ Global Lanes
                  </span>
                </div>
                <div>
                  <span className="block text-[10px] font-mono text-slate-500 uppercase">ESTUARY GATEWAY</span>
                  <span className="text-xs font-mono font-bold text-white mt-0.5 block">
                    Thamesport / London
                  </span>
                </div>
              </div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
