'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { generateShipment, ShipmentRecord } from '@/lib/shippingData';
import { 
  Search, Anchor, Navigation, Calendar, MapPin, CheckCircle, 
  Clock, Package, Compass, Ship, Activity, Server, ArrowRight
} from 'lucide-react';

export default function TrackingMap() {
  const [searchRef, setSearchRef] = useState('MED-2026-004821');
  const [shipment, setShipment] = useState<ShipmentRecord | null>(null);
  const [searchError, setSearchError] = useState(false);

  // Load state from searchRef or localStorage if user triggered from Hero
  useEffect(() => {
    const savedRef = localStorage.getItem('medway_search_ref');
    if (savedRef) {
      setSearchRef(savedRef);
      localStorage.removeItem('medway_search_ref');
      handleTrack(savedRef);
    } else {
      handleTrack(searchRef);
    }
  }, []);

  const handleTrack = (refCode: string) => {
    if (!refCode || refCode.trim() === '') return;
    try {
      const result = generateShipment(refCode);
      setShipment(result);
      setSearchError(false);
    } catch (e) {
      setSearchError(true);
      setShipment(null);
    }
  };

  const getStatusBg = (status: string) => {
    switch (status) {
      case 'DELIVERED': return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'IN_TRANSIT': return 'bg-[#F37021]/10 text-[#F37021] border-[#F37021]/30';
      default: return 'bg-blue-50 text-[#0B1E36] border-[#0B1E36]/20';
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-lg p-6 lg:p-8 max-w-6xl mx-auto my-8 shadow-sm text-left text-[#1C252C]">
      
      {/* Title */}
      <div className="mb-6 border-b border-slate-100 pb-5">
        <div className="flex items-center gap-2 mb-1">
          <Activity className="w-5 h-5 text-[#F37021]" />
          <h2 className="text-xl font-mono font-bold tracking-wider text-[#0B1E36] uppercase">CARGO & VESSEL TRACKER</h2>
        </div>
        <p className="text-xs text-slate-500 font-sans">
          Look up multi-leg shipment progress records, vessel position estimations, and intermodal transport chains.
        </p>
      </div>

      {/* Tracker Search Input Bar */}
      <div className="flex flex-col sm:flex-row gap-3 bg-[#0B1E36] p-4 rounded-lg mb-8">
        <div className="relative flex-grow">
          <input
            type="text"
            value={searchRef}
            onChange={(e) => setSearchRef(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleTrack(searchRef)}
            placeholder="ENTER BOOKING OR CONTAINER REFERENCE (e.g. MED-2026-004821)"
            className="w-full pl-10 pr-4 py-3 bg-[#1C252C] text-white rounded border border-white/20 font-mono text-xs uppercase placeholder-slate-500 focus:outline-none focus:border-[#F37021]"
          />
          <Search className="absolute left-3 top-3.5 w-4 h-4 text-slate-400" />
        </div>
        <button
          onClick={() => handleTrack(searchRef)}
          className="px-6 py-3 bg-[#F37021] hover:bg-orange-600 font-mono text-xs font-bold text-[#0B1E36] uppercase tracking-wider rounded transition-colors"
        >
          EXECUTE TRACKING LOOKUP
        </button>
      </div>

      {searchError && (
        <div className="bg-red-50 border border-red-200 text-red-800 p-4 rounded text-xs mb-6 font-mono font-bold">
          ERROR: SHIPMENT REFERENCE CODE FORMAT NOT VALID. PLEASE USE STANDARD PATTERNS LIKE MED-2026-00XXXX.
        </div>
      )}

      {shipment && (
        <div className="space-y-8">
          
          {/* Top Panel summary dashboard */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-[#F8F9FA] p-5 rounded border border-slate-200">
            <div>
              <span className="block text-[9px] font-mono text-slate-500 uppercase font-bold tracking-widest">SHIPMENT REFERENCE</span>
              <span className="font-mono font-bold text-sm text-[#0B1E36] block mt-0.5">{shipment.reference}</span>
            </div>
            <div>
              <span className="block text-[9px] font-mono text-slate-500 uppercase font-bold tracking-widest">CONTAINER NUMBER</span>
              <span className="font-mono font-bold text-sm text-[#F37021] block mt-0.5">{shipment.containerNo}</span>
            </div>
            <div>
              <span className="block text-[9px] font-mono text-slate-500 uppercase font-bold tracking-widest">VESSEL / VOYAGE</span>
              <span className="font-mono font-bold text-sm text-slate-700 block mt-0.5">{shipment.vesselName} • {shipment.voyage}</span>
            </div>
            <div>
              <span className="block text-[9px] font-mono text-slate-500 uppercase font-bold tracking-widest">OPERATIONAL STATUS</span>
              <span className={`inline-block border text-[10px] font-mono font-bold px-2.5 py-0.5 rounded mt-1 uppercase ${getStatusBg(shipment.status)}`}>
                {shipment.status.replace('_', ' ')}
              </span>
            </div>
          </div>

          {/* Map & Timeline layout grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Column Left: Beautiful Vector Shipping Map */}
            <div className="lg:col-span-7 bg-[#1C252C] rounded border border-slate-800 p-4 text-white overflow-hidden flex flex-col justify-between min-h-[400px]">
              <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
                <span className="text-[10px] font-mono font-bold tracking-wider text-slate-400">ESTIMATED ROUTE POSITIONING & GEOMETRY MAP</span>
                <span className="text-[10px] font-mono bg-orange-500/10 text-[#F37021] px-2 py-0.5 border border-[#F37021]/20 rounded font-bold">
                  DEMO PLOTTED POSITION
                </span>
              </div>

              {/* Vector Map Wrapper */}
              <div className="relative flex-grow flex items-center justify-center bg-[#0B1E36] rounded p-4 h-[280px]">
                {/* SVG Earth outlines (simplified but neat vector representation) */}
                <svg className="w-full h-full opacity-40 select-none pointer-events-none" viewBox="0 0 1000 500" fill="none">
                  {/* North America */}
                  <path d="M50 100 H 220 V 300 H 150 L 100 400 Z" fill="#4B5563" />
                  {/* South America */}
                  <path d="M150 400 H 320 L 280 700 L 180 650 Z" fill="#4B5563" />
                  {/* Europe */}
                  <path d="M400 100 H 600 V 300 H 450 Z" fill="#4B5563" />
                  {/* Africa */}
                  <path d="M420 330 H 550 L 530 650 L 450 600 Z" fill="#4B5563" />
                  {/* Asia */}
                  <path d="M600 100 H 900 V 450 H 700 Z" fill="#4B5563" />
                  {/* Australia */}
                  <path d="M800 600 H 940 V 730 H 820 Z" fill="#4B5563" />
                </svg>

                {/* Plot the specific shipment origin & destination lines with animated pulse */}
                <svg className="absolute inset-0 w-full h-full" viewBox="0 0 1000 500" fill="none">
                  {/* Route path line from Kent to Amsterdam or New York or Shanghai */}
                  <motion.path
                    d="M 450 320 C 400 250, 300 280, 200 320" // Example New York lane
                    stroke="#F37021"
                    strokeWidth="3"
                    strokeDasharray="6, 6"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ duration: 1.5, repeat: Infinity, repeatType: "reverse" }}
                  />
                  {/* Origin port locator */}
                  <circle cx="450" cy="320" r="6" fill="#F37021" />
                  <text x="460" y="315" fill="white" fontSize="10" fontFamily="monospace" fontWeight="bold">UK (LON/MED)</text>

                  {/* Destination port locator */}
                  <circle cx="200" cy="320" r="6" fill="#FBBF24" />
                  <text x="140" y="340" fill="white" fontSize="10" fontFamily="monospace" fontWeight="bold">DEST PORT</text>

                  {/* Pulsing vessel position */}
                  <circle cx="325" cy="295" r="8" fill="#F37021" className="animate-ping opacity-75" />
                  <circle cx="325" cy="295" r="4" fill="#F37021" />
                </svg>

                <div className="absolute bottom-3 left-3 bg-[#1C252C]/90 p-2 border border-slate-700 rounded text-[9px] font-mono leading-normal text-slate-300">
                  <div className="text-white font-bold uppercase mb-0.5 flex items-center gap-1">
                    <Ship className="w-3 h-3 text-[#F37021]" />
                    {shipment.vesselName}
                  </div>
                  <div>Lat: 51° 23&apos; N | Lon: 0° 30&apos; E</div>
                  <div>Estimated Speed: 18.5 Knots</div>
                </div>
              </div>

              {/* Vessel Specific Card details */}
              <div className="grid grid-cols-3 gap-2 text-xs font-mono bg-[#1C252C] pt-3 border-t border-white/10 mt-2 text-slate-300 text-left">
                <div>
                  <span className="block text-[9px] text-slate-500 uppercase">IMO REGISTRY</span>
                  <span className="text-white font-bold">{shipment.imoNo}</span>
                </div>
                <div>
                  <span className="block text-[9px] text-slate-500 uppercase">ETA WINDOW</span>
                  <span className="text-[#FBBF24] font-bold">{shipment.eta}</span>
                </div>
                <div>
                  <span className="block text-[9px] text-slate-500 uppercase">LOAD FACTOR</span>
                  <span className="text-white font-bold">{shipment.containerNo.substring(0, 4)} TEU</span>
                </div>
              </div>

            </div>

            {/* Column Right: Complete Operational Milestones Timeline */}
            <div className="lg:col-span-5 flex flex-col">
              <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 border-b border-slate-200 pb-2 mb-4">
                SHIPMENT MILESTONES
              </h4>

              {/* Scrollable container of timeline events */}
              <div className="flex-grow space-y-4 max-h-[380px] overflow-y-auto pr-2 scrollbar-thin">
                {shipment.timeline.map((evt, idx) => (
                  <div key={idx} className="flex gap-3 text-xs items-start">
                    {/* Visual Check Indicator circle */}
                    <div className="flex flex-col items-center shrink-0">
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center border text-[9px] font-mono font-bold ${
                        evt.done 
                          ? 'bg-[#0B1E36] border-[#0B1E36] text-[#FBBF24]' 
                          : 'bg-slate-100 border-slate-200 text-slate-400'
                      }`}>
                        {idx + 1}
                      </div>
                      {idx < shipment.timeline.length - 1 && (
                        <div className={`w-0.5 h-10 ${evt.done ? 'bg-[#0B1E36]' : 'bg-slate-200'}`} />
                      )}
                    </div>

                    <div className="pb-2">
                      <span className={`block font-mono font-bold uppercase ${evt.done ? 'text-slate-800' : 'text-slate-400'}`}>
                        {evt.label}
                      </span>
                      <span className="text-[10px] font-mono text-slate-500 block">
                        Location: {evt.location}
                      </span>
                      {evt.done && (
                        <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100 font-bold inline-block mt-1">
                          Completed on: {evt.date}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* Sub-leg detailed routing schedule tables */}
          <div className="border-t border-slate-100 pt-6">
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 border-b border-slate-200 pb-2 mb-4">
              INTERMODAL TRANSIT SPECIFICATION SHEET
            </h4>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs border-collapse">
                <thead>
                  <tr className="bg-[#0B1E36] text-white">
                    <th className="p-2.5">LEG</th>
                    <th className="p-2.5">PROPULSION / MODE</th>
                    <th className="p-2.5">ORIGIN HUB</th>
                    <th className="p-2.5">DESTINATION HUB</th>
                    <th className="p-2.5">ESTIMATED TRANSIT</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {shipment.routeLegs.map((leg, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="p-2.5 font-bold">0{idx + 1}</td>
                      <td className="p-2.5 text-[#F37021] font-bold">{leg.mode}</td>
                      <td className="p-2.5">{leg.from}</td>
                      <td className="p-2.5">{leg.to}</td>
                      <td className="p-2.5 text-slate-600 font-bold">{leg.distanceKm} KM approx</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
