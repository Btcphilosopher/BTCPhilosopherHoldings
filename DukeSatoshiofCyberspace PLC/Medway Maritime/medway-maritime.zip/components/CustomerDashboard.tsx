'use client';

import React, { useState } from 'react';
import { generateShipment, ShipmentRecord, QuoteOutput } from '@/lib/shippingData';
import { 
  FileText, TrendingUp, AlertTriangle, Printer, Download, Clock,
  CheckCircle, Plus, Bell, RefreshCw, ShoppingBag, Award, ArrowRight
} from 'lucide-react';

interface CustomerDashboardProps {
  customBookings: QuoteOutput[];
  activeTab: string;
}

export default function CustomerDashboard({ customBookings }: CustomerDashboardProps) {
  const [activePortalTab, setActivePortalTab] = useState<'shipments' | 'documents' | 'watch' | 'invoices'>('shipments');
  const [selectedDocType, setSelectedDocType] = useState<string>('BOL');
  const [rateAlerts, setRateAlerts] = useState([
    { route: 'Kent → Rotterdam', size: '40HC', prev: 2540, curr: 2480, change: -60, date: '2026-10-02' },
    { route: 'Manchester → New York', size: '40HC', prev: 4750, curr: 4900, change: 150, date: '2026-10-02' },
    { route: 'Birmingham → Shanghai', size: '40HC', prev: 5850, curr: 5800, change: -50, date: '2026-10-01' }
  ]);
  const [newWatchRoute, setNewWatchRoute] = useState('London → Singapore');

  // Shipment 4821 is our baseline demo shipment
  const defaultShipment = generateShipment('MED-2026-004821');

  const addRateWatch = () => {
    if (!newWatchRoute) return;
    setRateAlerts([
      ...rateAlerts,
      { route: newWatchRoute, size: '40HC', prev: 3100, curr: 3100, change: 0, date: '2026-10-02' }
    ]);
  };

  const getDocContent = () => {
    switch (selectedDocType) {
      case 'BOL':
        return {
          title: 'BILL OF LADING (SEA WAYBILL)',
          ref: 'BOL-EST-981203',
          shipper: 'MEDWAY MARITIME AGENCY / TOM@AHYX.ORG',
          consignee: 'ROTTERDAM CARGO STORAGE GMBH',
          notify: 'AMSTERDAM IMPORT CLEARANCE LOGISTICS',
          vessel: 'MEDWAY MONARCH VOYAGE MM206E',
          portLoad: 'LONDON THAMESPORT (GBPMD)',
          portDischarge: 'ROTTERDAM PORT (NLRTM)',
          desc: '1 × 40ft HIGH CUBE STEEL CONTAINER (MEDU-482103-9)\nSAID TO CONTAIN: 18,500 KG GENERAL CONSUMER GOODS PACKED ON 14 WOODEN PALLETS.'
        };
      case 'CI':
        return {
          title: 'COMMERCIAL INVOICE',
          ref: 'CI-MM-2026-4821',
          shipper: 'KENT RETAIL GLOBAL CORP, ROCHESTER',
          consignee: 'BENELUX DISTRIBUTORS BV, AMSTERDAM',
          notify: 'SAME AS CONSIGNEE',
          vessel: 'MEDWAY MONARCH VOYAGE MM206E',
          portLoad: 'LONDON THAMESPORT',
          portDischarge: 'ROTTERDAM PORT',
          desc: 'SHIPPING FEE CHARGES FOR ROAD & SEA MULTIMODAL INTERMODAL DRAYAGE\nUK ROAD COLLECTION: £420\nPORT GATE HANDLING: £285\nOCEAN FREIGHT LEG: £690\nDESTINATION HANDLING: £310\nFINAL INLAND TRUCKING: £575\nCUSTOMS ENTRY & DOCS: £200\nTOTAL CHARGES INVOICED: £2,480 GBP'
        };
      default:
        return {
          title: 'BOOKING CONFIRMATION',
          ref: 'BK-MED-98103',
          shipper: 'KENT RETAIL GLOBAL CORP',
          consignee: 'BENELUX DISTRIBUTORS BV',
          notify: 'N/A',
          vessel: 'MEDWAY MONARCH VOYAGE MM206E',
          portLoad: 'LONDON THAMESPORT',
          portDischarge: 'ROTTERDAM PORT',
          desc: 'BOOKING IS CONFIRMED. EQUIPMENT RELEASE CODE: REL-4812039. POSITIONING ADDRESS: CHATHAM WHARF DEPOT, KENT. EXPECTED CUT-OFF DATE: OCT 12, 2026.'
        };
    }
  };

  const doc = getDocContent();

  return (
    <div className="bg-white border border-slate-200 rounded-lg p-6 lg:p-8 max-w-6xl mx-auto my-8 shadow-sm text-left text-[#1C252C]">
      
      {/* Title */}
      <div className="mb-6 border-b border-slate-100 pb-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Award className="w-5 h-5 text-[#F37021]" />
            <h2 className="text-xl font-mono font-bold tracking-wider text-[#0B1E36] uppercase">CUSTOMER CONSOLE & SHIPMENTS ARCHIVE</h2>
          </div>
          <p className="text-xs text-slate-500 font-sans">
            Review active booking authorizations, compile pro-forma invoices, and configure customizable rate watches.
          </p>
        </div>

        {/* Dashboard Tabs (Interactive filter control with click handler) */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-mono font-bold self-start">
          <button 
            onClick={() => setActivePortalTab('shipments')} 
            className={`px-3 py-1.5 rounded transition-colors ${activePortalTab === 'shipments' ? 'bg-[#0B1E36] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            MY SHIPMENTS
          </button>
          <button 
            onClick={() => setActivePortalTab('documents')} 
            className={`px-3 py-1.5 rounded transition-colors ${activePortalTab === 'documents' ? 'bg-[#0B1E36] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            DOCUMENT CENTRE
          </button>
          <button 
            onClick={() => setActivePortalTab('watch')} 
            className={`px-3 py-1.5 rounded transition-colors ${activePortalTab === 'watch' ? 'bg-[#0B1E36] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            RATE WATCH ALERT
          </button>
        </div>
      </div>

      {activePortalTab === 'shipments' && (
        /* PORTAL TAB 1: SHIPMENTS LIST */
        <div className="space-y-6">
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
            ACTIVE BOOKINGS & INTRANSIT LOG (DEMO ACCOUNTS)
          </h3>

          <div className="space-y-4">
            {/* Hardcoded baseline Demo Shipment */}
            <div className="border border-slate-200 rounded p-5 hover:border-slate-300 transition-colors">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-3 mb-4">
                <div>
                  <span className="text-[9px] font-mono text-slate-400 font-bold block uppercase">SHIPMENT CODE</span>
                  <span className="font-mono font-bold text-sm text-[#0B1E36]">{defaultShipment.reference}</span>
                </div>
                <div className="text-right">
                  <span className="text-[9px] font-mono text-slate-400 font-bold block uppercase">ETA AT PORT DISCHARGE</span>
                  <span className="font-mono font-bold text-[#F37021]">{defaultShipment.eta}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono font-bold text-slate-600 mb-4">
                <div>
                  <span>Origin:</span>
                  <span className="text-slate-800 block mt-0.5">{defaultShipment.origin}</span>
                </div>
                <div>
                  <span>Destination:</span>
                  <span className="text-slate-800 block mt-0.5">{defaultShipment.destination}</span>
                </div>
                <div>
                  <span>Container Type:</span>
                  <span className="text-slate-800 block mt-0.5">{defaultShipment.containerType}</span>
                </div>
                <div>
                  <span>Vessel Route:</span>
                  <span className="text-slate-800 block mt-0.5">{defaultShipment.vesselName}</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-100 text-[11px] font-mono font-bold text-slate-500">
                <span>Status: <strong className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 uppercase">{defaultShipment.status}</strong></span>
                <span className="text-[#F37021]">Estimated Value: £{defaultShipment.totalCostGBP.toLocaleString()}</span>
              </div>
            </div>

            {/* Custom generated bookings list from current session */}
            {customBookings.map((bk, idx) => (
              <div key={idx} className="border border-[#F37021]/30 bg-orange-50/10 rounded p-5">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#F37021]/10 pb-3 mb-4">
                  <div>
                    <span className="text-[9px] font-mono text-slate-400 font-bold block uppercase">SESSION SIMULATOR BOOKING</span>
                    <span className="font-mono font-bold text-sm text-[#0B1E36]">{bk.reference}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] font-mono text-slate-400 font-bold block uppercase">VALIDITY</span>
                    <span className="font-mono font-bold text-[#F37021]">{bk.validityDate}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono font-bold text-slate-600 mb-4">
                  <div>
                    <span>Origin Address:</span>
                    <span className="text-slate-800 block mt-0.5 truncate">{bk.origin}</span>
                  </div>
                  <div>
                    <span>Discharge Port:</span>
                    <span className="text-slate-800 block mt-0.5 truncate">{bk.destination}</span>
                  </div>
                  <div>
                    <span>Equipment:</span>
                    <span className="text-slate-800 block mt-0.5">{bk.containerName}</span>
                  </div>
                  <div>
                    <span>Multimodal legs:</span>
                    <span className="text-slate-800 block mt-0.5">3 Handovers Checked</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-100 text-[11px] font-mono font-bold text-slate-500">
                  <span>Status: <strong className="text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-100 uppercase">PROVISIONED</strong></span>
                  <span className="text-[#0B1E36]">Est. Cost: £{bk.totalCostGBP.toLocaleString()}</span>
                </div>
              </div>
            ))}

            {customBookings.length === 0 && (
              <div className="p-8 text-center bg-slate-50 border border-dashed border-slate-200 rounded text-slate-400 font-mono text-xs">
                NO ACTIVE BOOKINGS FOUND IN THIS CURRENT CLIENT SESSION. PROVISION A SIMULATOR BOOKING INSIDE THE CONTAINER PRICE ENGINE TABS TO GENERATE RECORDS.
              </div>
            )}
          </div>
        </div>
      )}

      {activePortalTab === 'documents' && (
        /* PORTAL TAB 2: DOCUMENT CENTRE */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Doc types checklist switcher */}
          <div className="lg:col-span-4 bg-slate-50 border border-slate-200 p-5 rounded space-y-3">
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 pb-2 border-b border-slate-200">
              DOCUMENT ARCHIVE LIST
            </h4>

            <div className="flex flex-col gap-2 text-xs font-mono font-bold text-left">
              {[
                { code: 'BOL', name: 'Bill of Lading (Sea Waybill)' },
                { code: 'CI', name: 'Commercial Invoice Statement' },
                { code: 'BC', name: 'Booking Confirmation Receipt' }
              ].map((item) => (
                <button
                  key={item.code}
                  onClick={() => setSelectedDocType(item.code)}
                  className={`w-full p-3 border rounded text-left ${
                    selectedDocType === item.code 
                      ? 'bg-[#0B1E36] text-white border-[#0B1E36]' 
                      : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  {item.name}
                </button>
              ))}
            </div>

            <div className="p-3 bg-orange-50 border border-orange-200 text-orange-800 text-[10px] font-mono leading-relaxed rounded">
              <strong>SAMPLE DOCUMENT NOTICE:</strong> All documents exported from this dashboard are generated for compliance training and simulation purposes and do not convey commercial ownership.
            </div>
          </div>

          {/* Doc rendering page */}
          <div className="lg:col-span-8 bg-slate-100 border border-slate-200 p-6 rounded shadow-inner text-left text-slate-800 font-mono text-[11px] leading-relaxed relative min-h-[420px]">
            {/* Watermark */}
            <div className="absolute inset-0 flex items-center justify-center opacity-10 select-none pointer-events-none rotate-12">
              <span className="text-6xl font-bold tracking-widest text-[#0B1E36]">SAMPLE / DEMO</span>
            </div>

            <div className="border-b border-slate-300 pb-4 mb-4 flex justify-between items-center text-xs">
              <span className="font-extrabold text-[#0B1E36] tracking-wider">MEDWAY MARITIME AGENCY</span>
              <span className="text-slate-500">REF: {doc.ref}</span>
            </div>

            <h3 className="text-center font-extrabold text-sm border-y border-slate-300 py-2 my-4 text-slate-900 uppercase tracking-widest">
              {doc.title}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-4 border-b border-slate-200">
              <div>
                <strong className="text-[10px] text-slate-500 block">SHIPPER / EXPORTER</strong>
                <span>{doc.shipper}</span>
              </div>
              <div>
                <strong className="text-[10px] text-slate-500 block">CONSIGNEE / RECEIVER</strong>
                <span>{doc.consignee}</span>
              </div>
              <div>
                <strong className="text-[10px] text-slate-500 block">VESSEL & VOYAGE IMO</strong>
                <span>{doc.vessel}</span>
              </div>
              <div>
                <strong className="text-[10px] text-slate-500 block">HANDOVER DEPOTS</strong>
                <span>L: {doc.portLoad} → D: {doc.portDischarge}</span>
              </div>
            </div>

            <div className="pt-4">
              <strong className="text-[10px] text-slate-500 block mb-2">PARTICULARS OF THE CONSIGNMENT</strong>
              <pre className="whitespace-pre-wrap font-mono leading-relaxed text-slate-700 bg-white p-3 border border-slate-200 rounded">
                {doc.desc}
              </pre>
            </div>

            <div className="pt-6 text-center">
              <button
                onClick={() => window.print()}
                className="px-4 py-2 bg-[#F37021] text-white hover:bg-orange-600 transition-colors text-xs font-mono font-bold rounded"
              >
                PRINT DOCUMENT SIMULATION
              </button>
            </div>

          </div>

        </div>
      )}

      {activePortalTab === 'watch' && (
        /* PORTAL TAB 3: RATE WATCH */
        <div className="space-y-6">
          <div className="p-4 bg-blue-50 border border-blue-200 text-blue-800 text-xs rounded leading-normal flex items-start gap-3">
            <Bell className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-mono font-bold block uppercase mb-0.5">RATE WATCH WATCHLIST ACTIVATED</span>
              Configure saved corridors and receive automated digital reports inside this portal whenever indicative freight rates shift based on simulated bunker adjustments.
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
            {/* Quick adding container */}
            <div className="bg-slate-50 border border-slate-200 p-5 rounded space-y-4">
              <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                ADD NEW CORRIDOR TO WATCH
              </h4>

              <div className="space-y-3 text-xs font-mono font-bold">
                <div>
                  <label className="block text-slate-500 text-[10px] uppercase mb-1.5">ROUTE PATHWAY</label>
                  <input
                    type="text"
                    value={newWatchRoute}
                    onChange={(e) => setNewWatchRoute(e.target.value)}
                    placeholder="e.g. Manchester → Hamburg"
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono bg-white focus:outline-none"
                  />
                </div>

                <button
                  onClick={addRateWatch}
                  className="w-full py-2 bg-[#0B1E36] text-white hover:bg-[#1C252C] transition-colors text-xs font-mono font-bold rounded uppercase text-center"
                >
                  ADD TO RATE WATCH
                </button>
              </div>
            </div>

            {/* Displaying active alerts */}
            <div className="md:col-span-2 space-y-3">
              {rateAlerts.map((alert, idx) => {
                const isDown = alert.change < 0;
                return (
                  <div key={idx} className="border border-slate-200 rounded p-4 flex items-center justify-between text-xs font-mono font-bold text-slate-700">
                    <div>
                      <span className="text-[#0B1E36] block text-sm">{alert.route}</span>
                      <span className="text-slate-400 text-[9px] block uppercase mt-0.5">Equipment: {alert.size} • Recorded {alert.date}</span>
                    </div>

                    <div className="text-right">
                      <span className="text-slate-500 text-[10px] uppercase block">INDICATIVE VALUE</span>
                      <span className="text-[#0B1E36] text-sm block">£{alert.curr}</span>
                      {alert.change !== 0 ? (
                        <span className={`text-[10px] inline-block px-1.5 py-0.2 rounded mt-0.5 ${isDown ? 'bg-emerald-50 text-emerald-800' : 'bg-red-50 text-red-800'}`}>
                          {isDown ? '↓' : '↑'} £{Math.abs(alert.change)}
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-400">Stable</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
