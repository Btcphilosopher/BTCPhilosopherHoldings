'use client';

import React, { useState } from 'react';
import { CONTAINER_TYPES } from '@/lib/shippingData';
import { 
  FileCheck, ShieldCheck, ArrowRight, TableProperties, AlertCircle,
  HelpCircle, ShieldAlert, Sparkles, ArrowDownToLine, ArrowUpFromLine, BookOpen
} from 'lucide-react';

export default function ImportExportCustoms() {
  const [direction, setDirection] = useState<'import' | 'export'>('import');
  
  // Compliance simulator state
  const [countryOrigin, setCountryOrigin] = useState('China');
  const [commodityCode, setCommodityCode] = useState('8517.13.00'); // Smartphone HSC
  const [incoterm, setIncoterm] = useState('FOB');
  const [cargoValueUSD, setCargoValueUSD] = useState(125000);
  const [complianceResult, setComplianceResult] = useState<any | null>(null);

  const incotermDatabase: Record<string, { pay: string; transport: string; risk: string; desc: string }> = {
    EXW: { pay: 'Buyer pays all costs', transport: 'Buyer arranges all freight', risk: 'Transfers at Supplier Warehouse door', desc: 'Ex Works puts maximum obligation on buyer.' },
    FCA: { pay: 'Seller pays to terminal, Buyer pays rest', transport: 'Buyer arranges main ocean leg', risk: 'Transfers when delivered to carrier', desc: 'Free Carrier is flexible and suited for container transport.' },
    FOB: { pay: 'Seller pays to load ship, Buyer pays ocean', transport: 'Buyer arranges main ocean leg', risk: 'Transfers when loaded on vessel', desc: 'Free On Board is standard maritime only protocol.' },
    CFR: { pay: 'Seller pays ocean freight, Buyer pays handling', transport: 'Seller arranges ocean freight', risk: 'Transfers when loaded on vessel', desc: 'Cost and Freight puts transport costs on seller, but risk on buyer during transit.' },
    CIF: { pay: 'Seller pays ocean + insurance', transport: 'Seller arranges ocean freight', risk: 'Transfers when loaded on vessel', desc: 'Cost, Insurance and Freight requires seller to buy marine insurance.' },
    DAP: { pay: 'Seller pays to final door, Buyer pays customs duty', transport: 'Seller arranges all freight', risk: 'Transfers at final delivery point', desc: 'Delivered At Place means seller bears all risk to the final address.' },
    DDP: { pay: 'Seller pays everything including customs & tax', transport: 'Seller arranges all freight', risk: 'Transfers at final delivery point', desc: 'Delivered Duty Paid is maximum obligation on the seller.' }
  };

  const handleRunCompliance = () => {
    // Generate simulated customs compliance profile
    const hscPattern = /^\d{4}\.\d{2}(\.\d{2})?$/;
    const isCodeOk = hscPattern.test(commodityCode) || commodityCode.length >= 4;
    
    // Duty approximation
    let dutyRate = 2.5;
    let vatRate = 20.0;
    if (commodityCode.startsWith('85')) dutyRate = 0; // Smartphones / electronics often 0% WTO
    else if (commodityCode.startsWith('44')) dutyRate = 4.2; // Timber
    else dutyRate = 6.5;

    const estimatedDuty = Math.round(cargoValueUSD * (dutyRate / 100));
    const estimatedVAT = Math.round((cargoValueUSD + estimatedDuty) * (vatRate / 100));

    setComplianceResult({
      validCode: isCodeOk,
      estimatedDutyUSD: estimatedDuty,
      estimatedVATUSD: estimatedVAT,
      dutyRatePercent: dutyRate,
      vatRatePercent: vatRate,
      documentsRequired: [
        'Commercial Invoice (stating buyer/seller VAT numbers)',
        'Detailed Packing List (gross/net weight, carton breakdown)',
        'Bill of Lading (Original or Sea Waybill)',
        `Customs Declaration (using CDS system)`,
        incoterm === 'CIF' ? 'Marine Cargo Insurance Certificate' : 'Proof of Incoterm terms Agreement'
      ]
    });
  };

  return (
    <div className="bg-white border border-slate-200 rounded-lg p-6 lg:p-8 max-w-6xl mx-auto my-8 shadow-sm text-left text-[#1C252C]">
      
      {/* Title */}
      <div className="mb-6 border-b border-slate-100 pb-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <ShieldCheck className="w-5 h-5 text-[#F37021]" />
            <h2 className="text-xl font-mono font-bold tracking-wider text-[#0B1E36] uppercase">TRADE COMPLIANCE, INCUTERMS & CUSTOMS ENGINE</h2>
          </div>
          <p className="text-xs text-slate-500 font-sans">
            Validate import tariffs, inspect required customs documentation lists, and study the physical transfer of freight risks.
          </p>
        </div>

        {/* Direction Segment Switch (Interactive filter button with click handler) */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-mono font-bold self-start">
          <button 
            onClick={() => setDirection('import')} 
            className={`px-3 py-1.5 rounded flex items-center gap-1 transition-colors ${direction === 'import' ? 'bg-[#0B1E36] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            <ArrowDownToLine className="w-3.5 h-3.5" />
            IMPORT WORKFLOW
          </button>
          <button 
            onClick={() => setDirection('export')} 
            className={`px-3 py-1.5 rounded flex items-center gap-1 transition-colors ${direction === 'export' ? 'bg-[#0B1E36] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            <ArrowUpFromLine className="w-3.5 h-3.5" />
            EXPORT WORKFLOW
          </button>
        </div>
      </div>

      {/* WORKFLOW GRAPHS */}
      <div className="bg-slate-50 p-5 rounded border border-slate-200 mb-8 text-center">
        <h3 className="text-xs font-mono font-bold uppercase text-slate-400 tracking-wider text-left mb-6">
          {direction === 'import' ? 'UK IMPORT MULTI-LEG CHAIN' : 'UK EXPORT MULTI-LEG CHAIN'}
        </h3>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-xs font-mono font-bold text-slate-700">
          {direction === 'import' ? (
            <>
              <div className="bg-white p-3 border border-slate-200 rounded">
                <span className="block text-[#F37021] text-[9px]">LEG 01</span>
                Supplier Warehouse
              </div>
              <div className="bg-white p-3 border border-slate-200 rounded">
                <span className="block text-[#F37021] text-[9px]">LEG 02</span>
                Export Clearance & Port Gate
              </div>
              <div className="bg-white p-3 border border-slate-200 rounded">
                <span className="block text-[#F37021] text-[9px]">LEG 03</span>
                Ocean Freight Voyage
              </div>
              <div className="bg-white p-3 border border-slate-200 rounded">
                <span className="block text-[#F37021] text-[9px]">LEG 04</span>
                UK Port Customs CDS
              </div>
              <div className="bg-white p-3 border border-slate-200 rounded">
                <span className="block text-[#F37021] text-[9px]">LEG 05</span>
                Final Inland Delivery
              </div>
            </>
          ) : (
            <>
              <div className="bg-white p-3 border border-slate-200 rounded">
                <span className="block text-[#F37021] text-[9px]">LEG 01</span>
                UK Origin Depot / Packing
              </div>
              <div className="bg-white p-3 border border-slate-200 rounded">
                <span className="block text-[#F37021] text-[9px]">LEG 02</span>
                Export Document Clearance
              </div>
              <div className="bg-white p-3 border border-slate-200 rounded">
                <span className="block text-[#F37021] text-[9px]">LEG 03</span>
                Port Haulage & Loading
              </div>
              <div className="bg-white p-3 border border-slate-200 rounded">
                <span className="block text-[#F37021] text-[9px]">LEG 04</span>
                Ocean Carrier Voyage
              </div>
              <div className="bg-white p-3 border border-slate-200 rounded">
                <span className="block text-[#F37021] text-[9px]">LEG 05</span>
                Overseas Destination Discharge
              </div>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Interactive Customs Calculator */}
        <div className="lg:col-span-5 bg-slate-50 border border-slate-200 p-5 rounded space-y-4">
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 pb-2 border-b border-slate-200">
            COMPLIANCE PROFILER
          </h3>

          <div className="space-y-3 text-xs font-mono font-bold">
            <div>
              <label className="block text-slate-500 text-[10px] uppercase mb-1.5">COUNTRY OF ORIGIN / DESTINATION</label>
              <input
                type="text"
                value={countryOrigin}
                onChange={(e) => setCountryOrigin(e.target.value)}
                placeholder="e.g. China, USA, Japan"
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono bg-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-500 text-[10px] uppercase mb-1.5 flex items-center justify-between">
                <span>COMMODITY CODE (HSC)</span>
                <span className="text-[8px] text-slate-400 font-normal">Format: XXXX.XX.XX</span>
              </label>
              <input
                type="text"
                value={commodityCode}
                onChange={(e) => setCommodityCode(e.target.value)}
                placeholder="e.g. 8517.13.00 (Smartphones)"
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono bg-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-500 text-[10px] uppercase mb-1.5">INCOTERM RULING</label>
              <select
                value={incoterm}
                onChange={(e) => setIncoterm(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono bg-white focus:outline-none"
              >
                {Object.keys(incotermDatabase).map(inc => (
                  <option key={inc} value={inc}>{inc}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-500 text-[10px] uppercase mb-1.5">CARGO VALUE (USD)</label>
              <input
                type="number"
                value={cargoValueUSD}
                onChange={(e) => setCargoValueUSD(parseInt(e.target.value) || 0)}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono bg-white focus:outline-none"
              />
            </div>

            <button
              onClick={handleRunCompliance}
              className="w-full py-2.5 bg-[#0B1E36] hover:bg-[#1C252C] transition-colors text-white font-mono text-xs font-bold rounded uppercase tracking-wider text-center"
            >
              GENERATE CUSTOMS PROFILE
            </button>
          </div>
        </div>

        {/* Right Column: Custom Compliance Checklist Output */}
        <div className="lg:col-span-7 space-y-6">
          {complianceResult ? (
            <div className="border border-slate-200 rounded p-5 bg-slate-50 space-y-4">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-emerald-600" />
                CUSTOMS COMPLIANCE REPORT
              </h3>

              <div className="grid grid-cols-2 gap-4 text-xs font-mono font-bold text-slate-600 border-b border-slate-200 pb-4">
                <div>
                  <span className="block text-[8px] text-slate-400 uppercase">HSC CODE VALIDITY</span>
                  <span className={complianceResult.validCode ? 'text-emerald-700' : 'text-orange-700'}>
                    {complianceResult.validCode ? 'VERIFIED STRUCTURE' : 'UNVERIFIED STRUCTURE'}
                  </span>
                </div>
                <div>
                  <span className="block text-[8px] text-slate-400 uppercase">ESTIMATED TARIF RATE</span>
                  <span className="text-[#0B1E36] block mt-0.5">{complianceResult.dutyRatePercent}% Duty</span>
                </div>
                <div>
                  <span className="block text-[8px] text-slate-400 uppercase">APPROX DUTY PAYABLE</span>
                  <span className="text-slate-800 block text-sm font-extrabold mt-0.5">${complianceResult.estimatedDutyUSD.toLocaleString()} USD</span>
                </div>
                <div>
                  <span className="block text-[8px] text-slate-400 uppercase">ESTIMATED IMPORT VAT ({complianceResult.vatRatePercent}%)</span>
                  <span className="text-slate-800 block text-sm font-extrabold mt-0.5">${complianceResult.estimatedVATUSD.toLocaleString()} USD</span>
                </div>
              </div>

              <div>
                <span className="block text-[9px] font-mono text-slate-500 uppercase font-bold tracking-widest mb-3">
                  REQUIRED ENTRY DOCUMENTATION CHECKLIST
                </span>
                <ul className="space-y-2 text-xs font-mono font-bold text-slate-700">
                  {complianceResult.documentsRequired.map((doc: string, idx: number) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-[#F37021] shrink-0 mt-0.5">▪</span>
                      <span>{doc}</span>
                    </li>
                  ))}
                </ul>
              </div>

            </div>
          ) : (
            /* Tab Prompt */
            <div className="border border-dashed border-slate-300 rounded p-12 text-center text-slate-400 font-mono text-xs">
              <BookOpen className="w-8 h-8 mx-auto text-slate-300 mb-2" />
              ENTER THE CARGO DETAILS IN THE PROFILER FORM ON THE LEFT TO EVALUATE TARIFFS AND CHECKLISTS.
            </div>
          )}

          {/* Incoterm Guide block */}
          <div className="border border-slate-200 rounded p-5">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 mb-3">
              INCOTERM QUICK DICTIONARY: {incoterm}
            </h3>

            <div className="space-y-2.5 text-xs font-mono font-bold">
              <div className="flex justify-between text-slate-600">
                <span>COST LIABILITY:</span>
                <span className="text-[#0B1E36]">{incotermDatabase[incoterm].pay}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>TRANSPORT CONTRACTS:</span>
                <span className="text-[#0B1E36]">{incotermDatabase[incoterm].transport}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>RISK TRANSFER POINT:</span>
                <span className="text-[#F37021]">{incotermDatabase[incoterm].risk}</span>
              </div>
              <p className="text-[11px] text-slate-500 italic pt-2 font-normal">
                &quot;{incotermDatabase[incoterm].desc}&quot;
              </p>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="p-4 bg-orange-50 border border-orange-200 text-orange-800 text-[11px] leading-relaxed rounded flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-[#F37021] shrink-0 mt-0.5" />
            <div>
              <span className="font-mono font-bold block uppercase mb-1">NO LEGAL ADVICE CONNOTED</span>
              Customs classifications, duties, VAT calculations, and Incoterm liabilities are simulated values using standardized approximations. Medway Maritime does not provide legally binding customs rulings. Final filings must be declared against HM Revenue & Customs or regional equivalent bodies.
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
