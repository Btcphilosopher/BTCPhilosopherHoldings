'use client';

import React, { useState } from 'react';
import { SYNTHETIC_RATES, VESSELS, PORTS, SyntheticRate } from '@/lib/shippingData';
import { 
  Server, ShieldCheck, Database, Sliders, AlertCircle, 
  Trash2, Plus, Play, RefreshCw, Send, CheckCircle, FileCode2
} from 'lucide-react';

export default function AdminConsole() {
  const [activeAdminTab, setActiveAdminTab] = useState<'rates' | 'vessels' | 'surcharges' | 'audit'>('rates');
  
  // Admin Surcharge state
  const [fuelMultiplier, setFuelMultiplier] = useState(1.0);
  const [securityMultiplier, setSecurityMultiplier] = useState(1.0);
  const [equipmentPremiumGBP, setEquipmentPremiumGBP] = useState(150);

  // Editable Vessel state list
  const [vesselsList, setVesselsList] = useState(VESSELS.slice(0, 6));
  const [selectedVesselImo, setSelectedVesselImo] = useState('IMO9811000');
  const [newVesselStatus, setNewVesselStatus] = useState('In Transit');

  // Audit Logs database
  const [auditLogs, setAuditLogs] = useState([
    { id: 'EVT-1004', action: 'PORT_DOCKET_INIT', operator: 'tom@ahyx.org', ip: '192.168.1.104', payload: 'Configured Medway Thamesport gateway coordinates', time: '09:12:04' },
    { id: 'EVT-1003', action: 'SURCHARGE_ADJUST', operator: 'tom@ahyx.org', ip: '192.168.1.104', payload: 'Updated base fuel factor multiplier to 1.0', time: '09:08:45' },
    { id: 'EVT-1002', action: 'ADMIN_CONSOLE_ACCESS', operator: 'tom@ahyx.org', ip: '192.168.1.104', payload: 'Logged into administrative terminal', time: '09:05:11' },
    { id: 'EVT-1001', action: 'DATABASE_SEED_VERIFIED', operator: 'system', ip: '127.0.0.1', payload: 'Populated 105 ports, 100 rates, 50 vessels', time: '09:00:00' }
  ]);

  const handleUpdateSurcharges = () => {
    // Save to simulated state or generate audit event
    const newLog = {
      id: `EVT-${Math.floor(1005 + Math.random() * 9000)}`,
      action: 'SURCHARGE_ADJUST',
      operator: 'tom@ahyx.org',
      ip: '192.168.1.104',
      payload: `Modified fuel drayage multiplier: ${fuelMultiplier}x, equipment premium: £${equipmentPremiumGBP}`,
      time: new Date().toLocaleTimeString()
    };
    setAuditLogs([newLog, ...auditLogs]);
    alert("SYSTEM CONFIRMATION: Base surcharge parameters updated inside active memory cache.");
  };

  const handleUpdateVessel = () => {
    setVesselsList(vesselsList.map(v => {
      if (v.imo === selectedVesselImo) {
        return { ...v, status: newVesselStatus };
      }
      return v;
    }));

    const targetVes = vesselsList.find(v => v.imo === selectedVesselImo);
    const newLog = {
      id: `EVT-${Math.floor(1005 + Math.random() * 9000)}`,
      action: 'VESSEL_DISPATCH_UPDATE',
      operator: 'tom@ahyx.org',
      ip: '192.168.1.104',
      payload: `Updated ${targetVes?.name || 'Vessel'} status code to: ${newVesselStatus}`,
      time: new Date().toLocaleTimeString()
    };
    setAuditLogs([newLog, ...auditLogs]);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-lg p-6 lg:p-8 max-w-6xl mx-auto my-8 shadow-sm text-left text-[#1C252C]">
      
      {/* Title */}
      <div className="mb-6 border-b border-slate-100 pb-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Server className="w-5 h-5 text-[#F37021]" />
            <h2 className="text-xl font-mono font-bold tracking-wider text-[#0B1E36] uppercase font-bold">MEDWAY CORE CONTROL CONSOLE</h2>
          </div>
          <p className="text-xs text-slate-500 font-sans">
            Adjust global base multipliers, override active vessel status tracks, and audit system-wide logging registers.
          </p>
        </div>

        {/* Console Subtabs (Interactive filter controls styled with clean segmented backgrounds) */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-mono font-bold self-start">
          <button 
            onClick={() => setActiveAdminTab('rates')} 
            className={`px-3 py-1.5 rounded transition-colors ${activeAdminTab === 'rates' ? 'bg-[#0B1E36] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            RATE REGISTER
          </button>
          <button 
            onClick={() => setActiveAdminTab('vessels')} 
            className={`px-3 py-1.5 rounded transition-colors ${activeAdminTab === 'vessels' ? 'bg-[#0B1E36] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            VESSEL OVERRIDES
          </button>
          <button 
            onClick={() => setActiveAdminTab('surcharges')} 
            className={`px-3 py-1.5 rounded transition-colors ${activeAdminTab === 'surcharges' ? 'bg-[#0B1E36] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            SURCHARGE TUNING
          </button>
          <button 
            onClick={() => setActiveAdminTab('audit')} 
            className={`px-3 py-1.5 rounded transition-colors ${activeAdminTab === 'audit' ? 'bg-[#0B1E36] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            AUDIT JOURNAL
          </button>
        </div>
      </div>

      {activeAdminTab === 'rates' && (
        /* ADMIN TAB 1: BROWSE ALL SYNTHETIC RATES */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
              ACTIVE PRICE ENGINE SEEDS INDICES (50+ ACTIVE)
            </h3>
            <span className="text-[10px] font-mono bg-emerald-50 text-emerald-800 border border-emerald-200 px-2.5 py-0.5 rounded font-bold uppercase">
              STATUS: SYNCED
            </span>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded">
            <table className="w-full text-left font-mono text-xs border-collapse">
              <thead>
                <tr className="bg-[#0B1E36] text-white">
                  <th className="p-2.5">ID</th>
                  <th className="p-2.5">UK ORIGIN</th>
                  <th className="p-2.5">GATEWAY PORT</th>
                  <th className="p-2.5">DEST DISCHARGE</th>
                  <th className="p-2.5">CONTAINER</th>
                  <th className="p-2.5 text-right">INDICATIVE BASE COST</th>
                  <th className="p-2.5 text-right">TRANSIT</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {SYNTHETIC_RATES.slice(0, 10).map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50">
                    <td className="p-2.5 text-[#F37021] font-bold">{r.id}</td>
                    <td className="p-2.5 font-bold text-slate-800">{r.origin}</td>
                    <td className="p-2.5 text-slate-600">{r.port}</td>
                    <td className="p-2.5 text-slate-800">{r.destination}</td>
                    <td className="p-2.5">{r.containerType}</td>
                    <td className="p-2.5 text-right font-extrabold text-[#0B1E36]">£{r.indicativePriceGBP}</td>
                    <td className="p-2.5 text-right text-slate-500 font-bold">{r.transitDays} Days</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeAdminTab === 'vessels' && (
        /* ADMIN TAB 2: VESSEL POSITION OVERRIDES */
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          {/* Dispatch tool left */}
          <div className="md:col-span-4 bg-slate-50 border border-slate-200 p-5 rounded space-y-4 text-xs font-mono font-bold">
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 pb-2 border-b border-slate-200">
              VESSEL DISPATCH OVERRIDE
            </h4>

            <div>
              <label className="block text-slate-500 text-[10px] uppercase mb-1.5">TARGET ACTIVE VESSEL</label>
              <select
                value={selectedVesselImo}
                onChange={(e) => setSelectedVesselImo(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono bg-white focus:outline-none"
              >
                {vesselsList.map((ves) => (
                  <option key={ves.imo} value={ves.imo}>{ves.name} ({ves.imo})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-500 text-[10px] uppercase mb-1.5">POSITION/DISPATCH STATUS</label>
              <select
                value={newVesselStatus}
                onChange={(e) => setNewVesselStatus(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono bg-white focus:outline-none"
              >
                <option value="In Transit">In Transit</option>
                <option value="At Sea">At Sea</option>
                <option value="Arriving">Arriving</option>
                <option value="Loading">Loading</option>
                <option value="Moored">Moored</option>
              </select>
            </div>

            <button
              onClick={handleUpdateVessel}
              className="w-full py-2 bg-[#F37021] text-white hover:bg-orange-600 transition-colors text-xs font-mono font-bold rounded uppercase text-center"
            >
              BROADCAST VESSEL UPDATE
            </button>
          </div>

          {/* Active Vessels list right */}
          <div className="md:col-span-8 space-y-3">
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
              ACTIVE FLEET TRACKING DIRECTORY
            </h4>

            <div className="space-y-2">
              {vesselsList.map((ves) => (
                <div key={ves.imo} className="border border-slate-200 rounded p-4 flex items-center justify-between text-xs font-mono font-bold text-slate-700">
                  <div>
                    <span className="text-[#0B1E36] block text-sm">{ves.name}</span>
                    <span className="text-slate-400 text-[9px] block uppercase mt-0.5">Voyage Code: {ves.voyage} • IMO {ves.imo}</span>
                  </div>

                  <div className="text-right">
                    <span className="text-slate-500 text-[9px] uppercase block">CURRENT POSITION TRACK</span>
                    <span className="text-emerald-700 font-bold block uppercase">{ves.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeAdminTab === 'surcharges' && (
        /* ADMIN TAB 3: SURCHARGE MULTIPLIER TUNING */
        <div className="space-y-6">
          <div className="p-4 bg-orange-50 border border-orange-200 text-orange-800 text-xs rounded leading-normal flex items-start gap-3">
            <Sliders className="w-5 h-5 text-[#F37021] shrink-0 mt-0.5" />
            <div>
              <span className="font-mono font-bold block uppercase mb-0.5">ACTIVE MULTIPLIER ALGORITHM OVERRIDES</span>
              This dashboard adjusts base surcharges calculated by the container pricing engine. Shifts are globally populated into current user sessions upon confirmation.
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
            <div className="bg-slate-50 border border-slate-200 p-5 rounded space-y-4 text-xs font-mono font-bold">
              <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 pb-2 border-b border-slate-200">
                FUEL DRAG FACTOR TUNER
              </h4>
              <p className="text-[11px] text-slate-500 font-normal">Multiplies default fuel surcharges across FCL containers.</p>

              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min="0.5"
                  max="2.5"
                  step="0.1"
                  value={fuelMultiplier}
                  onChange={(e) => setFuelMultiplier(parseFloat(e.target.value))}
                  className="w-full accent-[#F37021]"
                />
                <span className="text-sm text-[#0B1E36] font-extrabold w-12">{fuelMultiplier}x</span>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 p-5 rounded space-y-4 text-xs font-mono font-bold">
              <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 pb-2 border-b border-slate-200">
                SECURITY LEVY FACTOR TUNER
              </h4>
              <p className="text-[11px] text-slate-500 font-normal">Adjusts marine drayage protection coefficients.</p>

              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min="0.8"
                  max="2.0"
                  step="0.1"
                  value={securityMultiplier}
                  onChange={(e) => setSecurityMultiplier(parseFloat(e.target.value))}
                  className="w-full accent-[#0B1E36]"
                />
                <span className="text-sm text-[#0B1E36] font-extrabold w-12">{securityMultiplier}x</span>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 p-5 rounded space-y-4 text-xs font-mono font-bold">
              <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 pb-2 border-b border-slate-200">
                OOG EQUIPMENT PREMIUM
              </h4>
              <p className="text-[11px] text-slate-500 font-normal">Custom container equipment allocation fees in GBP.</p>

              <div className="flex items-center gap-2">
                <span className="text-slate-400">£</span>
                <input
                  type="number"
                  value={equipmentPremiumGBP}
                  onChange={(e) => setEquipmentPremiumGBP(parseInt(e.target.value) || 0)}
                  className="w-full p-1.5 border border-slate-300 rounded text-center bg-white"
                />
              </div>
            </div>
          </div>

          <div className="text-center pt-4">
            <button
              onClick={handleUpdateSurcharges}
              className="px-6 py-3 bg-[#0B1E36] hover:bg-[#1C252C] transition-all text-white font-mono text-xs font-bold rounded uppercase tracking-wider"
            >
              APPLY OVERRIDES TO ACTIVE ENGINE CACHE
            </button>
          </div>
        </div>
      )}

      {activeAdminTab === 'audit' && (
        /* ADMIN TAB 4: AUDIT LOG JOURNAL */
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <FileCode2 className="w-4 h-4 text-[#F37021]" />
              SYSTEM COMPLIANCE AUDIT EVENTS JOURNAL
            </h3>
            <span className="text-[10px] font-mono text-slate-400">SEVERITY: DEEP DIAGNOSTIC</span>
          </div>

          <div className="space-y-2">
            {auditLogs.map((log) => (
              <div key={log.id} className="bg-slate-50 border border-slate-200 p-3 rounded text-xs font-mono flex flex-col md:flex-row md:items-center justify-between gap-2">
                <div className="flex items-start gap-2.5">
                  <span className="text-[#F37021] font-bold">{log.id}</span>
                  <div>
                    <span className="bg-[#0B1E36] text-[#FBBF24] px-1.5 py-0.2 rounded text-[9px] font-bold uppercase mr-2">{log.action}</span>
                    <span className="text-slate-800 font-bold">{log.payload}</span>
                  </div>
                </div>

                <div className="text-right text-slate-400 text-[10px]">
                  <span>Operator: <strong>{log.operator}</strong> | IP: {log.ip} | Recorded {log.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
