'use client';

import React from 'react';
import { Anchor, ShieldCheck } from 'lucide-react';

interface FooterProps {
  setActiveTab: (tab: string) => void;
}

export default function Footer({ setActiveTab }: FooterProps) {
  return (
    <footer className="bg-[#0B1E36] text-white pt-16 pb-12 border-t border-white/10 font-sans text-left mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-12">
        
        {/* Col 1: Brand & Kent Statement */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Anchor className="w-5 h-5 text-[#F37021]" />
            <span className="text-sm font-mono font-bold tracking-widest text-white">MEDWAY MARITIME</span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed font-sans">
            Kent-based commercial maritime shipping agency and intermodal freight platform. Supporting direct transit corridor connections from the River Medway and Thames Estuary to the UK and the world.
          </p>
          <div className="text-[10px] font-mono text-[#F37021] font-bold tracking-wider uppercase">
            BASED IN KENT • CONNECTED TO THE WORLD
          </div>
        </div>

        {/* Col 2: Services Quicklinks */}
        <div className="space-y-4">
          <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">SERVICES CATALOG</h4>
          <ul className="space-y-2 text-xs font-mono text-slate-300">
            <li><button onClick={() => setActiveTab('ship')} className="hover:text-[#F37021] transition-colors">Container Shipping</button></li>
            <li><button onClick={() => setActiveTab('rates')} className="hover:text-[#F37021] transition-colors">Intermodal Freight</button></li>
            <li><button onClick={() => setActiveTab('routes')} className="hover:text-[#F37021] transition-colors">Port Agency Services</button></li>
            <li><button onClick={() => setActiveTab('customs')} className="hover:text-[#F37021] transition-colors">Customs Clearance coordination</button></li>
          </ul>
        </div>

        {/* Col 3: Portal Sitemaps */}
        <div className="space-y-4">
          <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">DIGITAL HUB</h4>
          <ul className="space-y-2 text-xs font-mono text-slate-300">
            <li><button onClick={() => setActiveTab('portal')} className="hover:text-[#F37021] transition-colors">Customer Portal Dashboard</button></li>
            <li><button onClick={() => setActiveTab('track')} className="hover:text-[#F37021] transition-colors">Cargo Vessel Tracking</button></li>
            <li><button onClick={() => setActiveTab('admin')} className="hover:text-[#F37021] transition-colors">Core Control Console</button></li>
            <li><button onClick={() => setActiveTab('ports')} className="hover:text-[#F37021] transition-colors">UK Gateway Profiles</button></li>
          </ul>
        </div>

        {/* Col 4: Address / Contact */}
        <div className="space-y-4 text-xs font-sans">
          <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">MEDWAY HQ</h4>
          <div className="space-y-1.5 text-slate-300 font-mono">
            <div>Medway Maritime Agency Ltd</div>
            <div>Rochester Terminal Offices, ME1</div>
            <div>Kent, United Kingdom</div>
            <div className="pt-2">Desk: ops@medway-maritime.demo</div>
          </div>
        </div>

      </div>

      {/* Disclosures Footer segment */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 mt-12 border-t border-white/10 text-center space-y-4">
        
        <div className="bg-[#1C252C]/60 p-4 border border-white/5 rounded max-w-4xl mx-auto text-[11px] font-mono leading-relaxed text-slate-400 flex items-start gap-3 text-left">
          <ShieldCheck className="w-5 h-5 text-[#FBBF24] shrink-0 mt-0.5" />
          <div>
            <strong>DEMO / SIMULATION SYSTEM DISCLOSURE:</strong> Medway Maritime is a fictional agency built as a technical demonstration platform. Every cargo routing, vessel position track, drayage tariff index, pro-forma customs declaration value, and booking confirmation represents synthetic, simulated computer outputs and does not constitute a real-world commercial contract or ocean freight booking.
          </div>
        </div>

        <div className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">
          © {new Date().getFullYear()} MEDWAY MARITIME INC. ALL RIGHTS RESERVED. REGISTERED IN ENGLAND AND WALES.
        </div>

      </div>
    </footer>
  );
}
