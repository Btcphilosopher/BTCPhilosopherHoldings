'use client';

import React, { useState } from 'react';
import { PORTS, Port } from '@/lib/shippingData';
import { 
  MapPin, Anchor, Train, Activity, ShieldAlert, Navigation, 
  Compass, Calculator, ArrowRight, TableProperties
} from 'lucide-react';

export default function PortNetwork() {
  const [selectedPortCode, setSelectedPortCode] = useState<string>('GBPMD'); // Default Medway
  
  // Quick domestic haulage state
  const [originPostcode, setOriginPostcode] = useState('ME1 1UT');
  const [arrivalPort, setArrivalPort] = useState('GBPMD');
  const [containerCode, setContainerCode] = useState('40HC');
  const [estimatedHaulagePrice, setEstimatedHaulagePrice] = useState<number | null>(null);
  const [estimatedDistanceMiles, setEstimatedDistanceMiles] = useState<number | null>(null);

  const ukPorts = PORTS.filter(p => p.country === 'United Kingdom');
  const selectedPort = ukPorts.find(p => p.code === selectedPortCode) || ukPorts[0];

  const calculateHaulage = () => {
    // Basic deterministic calculations
    const cleanPostcode = originPostcode.trim().toUpperCase();
    let distance = 35; // Default short Kent haul
    
    if (cleanPostcode.startsWith('B') || cleanPostcode.startsWith('M') || cleanPostcode.startsWith('L')) {
      distance = 165; // Midlands / North
    } else if (cleanPostcode.startsWith('EH') || cleanPostcode.startsWith('G')) {
      distance = 380; // Scotland
    } else if (cleanPostcode.startsWith('SO') || cleanPostcode.startsWith('BS')) {
      distance = 110; // South / West
    }

    const baseCostPerMile = 2.45;
    const baseDropFee = 150;
    const sizeMultiplier = containerCode === '20GP' ? 0.9 : containerCode === '40HC' ? 1.15 : 1.0;
    
    const rawCost = (distance * baseCostPerMile + baseDropFee) * sizeMultiplier;
    setEstimatedHaulagePrice(Math.round(rawCost));
    setEstimatedDistanceMiles(distance);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-lg p-6 lg:p-8 max-w-6xl mx-auto my-8 shadow-sm text-left text-[#1C252C]">
      
      {/* Title */}
      <div className="mb-6 border-b border-slate-100 pb-5">
        <div className="flex items-center gap-2 mb-1">
          <Compass className="w-5 h-5 text-[#F37021]" />
          <h2 className="text-xl font-mono font-bold tracking-wider text-[#0B1E36] uppercase">UK PORT NETWORK & INLAND CONTAINER HAULAGE</h2>
        </div>
        <p className="text-xs text-slate-500 font-sans">
          Navigate key British container terminals, rail freight gateways, and calculate direct warehouse-to-port road haulage rates.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left column: Vector Map of UK Ports */}
        <div className="lg:col-span-6 bg-[#0B1E36] text-white p-5 rounded-lg border border-slate-800 flex flex-col justify-between min-h-[460px]">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <span className="text-[10px] font-mono font-bold tracking-wider text-slate-400">INTERACTIVE VECTOR UK CONTAINER PORT PLOTTER</span>
              <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
            </div>

            {/* Simple neat SVG of UK outlines & locator points */}
            <div className="relative h-[320px] bg-[#1C252C] rounded p-4 flex items-center justify-center">
              <svg className="w-full h-full opacity-35 select-none" viewBox="0 0 300 400" fill="none">
                {/* Simulated UK mainland outlines */}
                <path d="M120 40 L 150 70 L 160 120 L 140 180 L 160 210 L 180 250 L 195 280 L 210 320 L 190 350 L 150 360 L 100 340 L 90 310 L 110 270 L 80 240 L 110 180 L 90 140 L 105 80 Z" fill="#4B5563" />
                {/* Northern Ireland outline */}
                <path d="M50 180 L 70 190 L 65 220 L 45 210 Z" fill="#4B5563" />
              </svg>

              {/* Port Points overlaid onto specific positions */}
              <div className="absolute inset-0">
                {ukPorts.map((port) => {
                  // Re-map real port coords to fit our UK outline cleanly
                  let x = 160;
                  let y = 300;
                  
                  if (port.code === 'GBPLG') { x = 202; y = 312; } // London Gateway
                  else if (port.code === 'GBPMD') { x = 205; y = 315; } // Thamesport
                  else if (port.code === 'GBFXT') { x = 210; y = 295; } // Felixstowe
                  else if (port.code === 'GBSOU') { x = 180; y = 328; } // Southampton
                  else if (port.code === 'GBLIV') { x = 145; y = 230; } // Liverpool
                  else if (port.code === 'GBIMM') { x = 190; y = 222; } // Immingham
                  else if (port.code === 'GBTEE') { x = 185; y = 180; } // Teesport
                  else if (port.code === 'GBHUL') { x = 188; y = 210; } // Hull
                  else if (port.code === 'GBBRS') { x = 140; y = 305; } // Bristol
                  else if (port.code === 'GBCPT') { x = 110; y = 115; } // Clydeport
                  else if (port.code === 'GBGRG') { x = 125; y = 100; } // Grangemouth
                  else if (port.code === 'GBDVR') { x = 215; y = 325; } // Dover

                  return (
                    <button
                      key={port.code}
                      onClick={() => setSelectedPortCode(port.code)}
                      className="absolute group -translate-x-1/2 -translate-y-1/2 focus:outline-none"
                      style={{ left: `${x}%`, top: `${y}%` }}
                    >
                      <span className={`block w-3.5 h-3.5 rounded-full border-2 border-white cursor-pointer transition-all ${
                        selectedPortCode === port.code 
                          ? 'bg-[#F37021] scale-125 ring-2 ring-orange-500/50' 
                          : 'bg-[#0B1E36] hover:bg-slate-400'
                      }`} />
                      
                      {/* Quiet tooltip on hover */}
                      <span className="hidden group-hover:block absolute left-5 -top-3 bg-[#1C252C] border border-slate-700 text-[10px] font-mono font-bold text-white px-1.5 py-0.5 rounded whitespace-nowrap z-30">
                        {port.name}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="text-[10px] font-mono text-slate-500 mt-4 leading-normal uppercase">
            * Interactive plotter: click points to review terminal profiles, rail connectivity index, and depths.
          </div>
        </div>

        {/* Right column: Selected Port Profile details & Haulage Rates */}
        <div className="lg:col-span-6 space-y-6">
          
          {/* Profile Card */}
          <div className="bg-slate-50 border border-slate-200 p-5 rounded">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 mb-3">
              TERMINAL PROFILE SHEET
            </h3>

            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Anchor className="w-5 h-5 text-[#F37021]" />
                <span className="text-lg font-mono font-bold text-[#0B1E36] uppercase">{selectedPort.name}</span>
                <span className="text-[10px] font-mono bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded font-bold">{selectedPort.code}</span>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs font-mono font-bold text-slate-600 mt-4">
                <div>
                  <span className="block text-[9px] text-slate-400 uppercase">PORT OPERATION TYPE</span>
                  <span className="text-slate-800 uppercase block mt-0.5">{selectedPort.type}</span>
                </div>
                <div>
                  <span className="block text-[9px] text-slate-400 uppercase">RAIL TERMINAL INDEX</span>
                  <span className="text-slate-800 block mt-0.5">
                    {selectedPort.railConnected ? 'CONNECTED (Class 66/70/90)' : 'NO DIRECT RAIL'}
                  </span>
                </div>
                <div>
                  <span className="block text-[9px] text-slate-400 uppercase">ESTUARY LOCATOR</span>
                  <span className="text-slate-800 block mt-0.5">Kent/Essex Channels</span>
                </div>
                <div>
                  <span className="block text-[9px] text-slate-400 uppercase">STATUS CODE</span>
                  <span className="text-emerald-700 block mt-0.5">ACTIVE</span>
                </div>
              </div>

              <p className="text-xs text-slate-500 leading-normal pt-2 font-sans">
                {selectedPort.name} is a key {selectedPort.type} node handling significant intermodal cargo from River Medway, Kent Estuary and Thames corridor to main global trade lanes.
              </p>
            </div>
          </div>

          {/* Quick inland road haulage price calculator */}
          <div className="border border-slate-200 rounded p-5">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-1.5">
              <Calculator className="w-4 h-4 text-[#F37021]" />
              QUICK HAULAGE ESTIMATOR (WAREHOUSE ↔ PORT)
            </h3>

            <div className="grid grid-cols-2 gap-4 text-xs font-mono font-bold mb-4">
              <div>
                <label className="block text-slate-500 text-[10px] uppercase mb-1.5">DELIVERY POSTCODE</label>
                <input
                  type="text"
                  value={originPostcode}
                  onChange={(e) => setOriginPostcode(e.target.value)}
                  placeholder="e.g. ME1 1UT"
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono uppercase bg-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-500 text-[10px] uppercase mb-1.5">PORT OF HANDOVER</label>
                <select
                  value={arrivalPort}
                  onChange={(e) => setArrivalPort(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono bg-white focus:outline-none"
                >
                  {ukPorts.map((p) => (
                    <option key={p.code} value={p.code}>{p.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-500 text-[10px] uppercase mb-1.5">CONTAINER SPEC</label>
                <select
                  value={containerCode}
                  onChange={(e) => setContainerCode(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono bg-white focus:outline-none"
                >
                  <option value="20GP">20&apos; Dry Van</option>
                  <option value="40HC">40&apos; High Cube</option>
                </select>
              </div>

              <div className="flex items-end">
                <button
                  onClick={calculateHaulage}
                  className="w-full py-2 bg-[#0B1E36] hover:bg-[#1C252C] transition-colors text-[#FBBF24] font-mono text-xs font-bold rounded uppercase tracking-wider text-center"
                >
                  CALCULATE RATE
                </button>
              </div>
            </div>

            {estimatedHaulagePrice !== null && (
              <div className="bg-orange-50 border border-orange-200 p-4 rounded text-xs font-mono font-bold text-orange-800 space-y-1">
                <div className="flex justify-between">
                  <span>ESTIMATED HAULAGE DISTANCE:</span>
                  <span className="text-[#0B1E36]">{estimatedDistanceMiles} Miles</span>
                </div>
                <div className="flex justify-between border-t border-orange-200 pt-2 mt-2 text-sm">
                  <span>INDICATIVE HAULAGE PRICE:</span>
                  <span className="text-[#0B1E36] text-base font-extrabold">£{estimatedHaulagePrice}</span>
                </div>
                <div className="text-[10px] text-slate-400 font-normal pt-1 uppercase">
                  * Rate includes port fuel surcharges and vehicle booking fees. DEMO ONLY.
                </div>
              </div>
            )}
          </div>

        </div>

      </div>

      {/* Grid of All UK ports browsable */}
      <div className="border-t border-slate-100 pt-8 mt-8">
        <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-1.5">
          <TableProperties className="w-4 h-4 text-[#F37021]" />
          UK PORT CAPABILITIES REGISTER (12 ACTIVE PORTS)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs border-collapse">
            <thead>
              <tr className="bg-[#0B1E36] text-white">
                <th className="p-2.5">PORT CODE</th>
                <th className="p-2.5">TERMINAL NAME</th>
                <th className="p-2.5">TYPE CATEGORY</th>
                <th className="p-2.5">RAIL CONNECTED</th>
                <th className="p-2.5">TYPICAL SERVICES</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {ukPorts.map((p) => (
                <tr key={p.code} className={`hover:bg-slate-50 cursor-pointer ${selectedPortCode === p.code ? 'bg-orange-50/50' : ''}`} onClick={() => setSelectedPortCode(p.code)}>
                  <td className="p-2.5 font-bold text-[#F37021]">{p.code}</td>
                  <td className="p-2.5 font-bold text-slate-800">{p.name}</td>
                  <td className="p-2.5 uppercase">{p.type}</td>
                  <td className="p-2.5">{p.railConnected ? 'Yes, Direct Rail Siding' : 'Road Transport Only'}</td>
                  <td className="p-2.5 text-slate-500">FCL, Import/Export, Customs Schedulers</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
