'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  calculateIndicativeRate, 
  CONTAINER_TYPES, 
  PORTS, 
  WAREHOUSES, 
  QuoteRequest, 
  QuoteOutput,
  CURRENCY_CONVERSION
} from '@/lib/shippingData';
import { 
  ArrowRight, ArrowLeft, Check, RefreshCw, Calculator, ShieldAlert, 
  ChevronRight, Sparkles, AlertCircle, Printer, Download, Plus, ShoppingBag
} from 'lucide-react';

interface PriceEngineProps {
  onBookingSuccess: (quote: QuoteOutput) => void;
  onRequestTabSwitch: (tab: string) => void;
}

export default function PriceEngine({ onBookingSuccess, onRequestTabSwitch }: PriceEngineProps) {
  // Wizard state: 1 to 5
  const [step, setStep] = useState(1);
  
  // Form values
  const [originCountry, setOriginCountry] = useState('United Kingdom');
  const [originCity, setOriginCity] = useState('Manchester');
  const [originPostcode, setOriginPostcode] = useState('M17 1UP');
  const [warehouseId, setWarehouseId] = useState('WH05');
  const [pickupDate, setPickupDate] = useState('2026-10-15');

  const [destCountry, setDestCountry] = useState('Netherlands');
  const [destPort, setDestPort] = useState('Rotterdam');
  const [destCity, setDestCity] = useState('Amsterdam');
  const [destPostcode, setDestPostcode] = useState('1012 JS');

  const [containerCode, setContainerCode] = useState('40HC');
  const [cargoType, setCargoType] = useState('General Cargo');
  const [cargoWeightKg, setCargoWeightKg] = useState(18500);
  const [cargoVolumeCbm, setCargoVolumeCbm] = useState(65);
  const [commodity, setCommodity] = useState('Consumer Goods');
  const [isHazardous, setIsHazardous] = useState(false);
  const [isTempControlled, setIsTempControlled] = useState(false);

  const [serviceType, setServiceType] = useState<'door-door' | 'door-port' | 'port-door' | 'port-port'>('door-door');
  const [transportMode, setTransportMode] = useState<'road-sea' | 'rail-sea' | 'road-rail-sea'>('road-sea');

  // Calculation outputs
  const [quoteOutput, setQuoteOutput] = useState<QuoteOutput | null>(null);
  const [activeCurrency, setActiveCurrency] = useState('GBP');
  const [isBookingDone, setIsBookingDone] = useState(false);
  const [bookingRef, setBookingRef] = useState('');

  // Handle warehouse changes to auto-fill city
  useEffect(() => {
    const wh = WAREHOUSES.find(w => w.id === warehouseId);
    if (wh) {
      setOriginCity(wh.city);
      setOriginPostcode(wh.postcode);
    }
  }, [warehouseId]);

  // Handle cargo properties based on container choice
  const handleContainerChange = (code: string) => {
    setContainerCode(code);
    const container = CONTAINER_TYPES.find(c => c.code === code);
    if (container) {
      setCargoVolumeCbm(Math.round(container.capacityCbm * 0.85));
      setCargoWeightKg(Math.round(container.weightLimitKg * 0.7));
      if (code.includes('RF')) {
        setIsTempControlled(true);
      } else {
        setIsTempControlled(false);
      }
    }
  };

  const calculateQuote = () => {
    const request: QuoteRequest = {
      originCountry,
      originCity,
      originPostcode,
      pickupDate,
      destCountry,
      destPort,
      destCity,
      destPostcode,
      containerCode,
      cargoType,
      cargoWeightKg,
      cargoVolumeCbm,
      commodity,
      isHazardous,
      isTempControlled,
      serviceType,
      transportMode: transportMode as any
    };

    const out = calculateIndicativeRate(request);
    setQuoteOutput(out);
    setStep(6); // Step 6 is Quote View
  };

  const handleBookShipment = () => {
    if (!quoteOutput) return;
    setIsBookingDone(true);
    
    // Simple custom string hash calculation
    let hash = 0;
    for (let i = 0; i < quoteOutput.reference.length; i++) {
      hash = (hash << 5) - hash + quoteOutput.reference.charCodeAt(i);
      hash |= 0;
    }
    const finalHash = Math.abs(hash);
    const ref = `MED-2026-${(100000 + (finalHash % 899999))}`;
    setBookingRef(ref);

    // Create a mock active shipment & trigger callback
    onBookingSuccess({
      ...quoteOutput,
      reference: ref
    });
  };

  const resetForm = () => {
    setStep(1);
    setIsBookingDone(false);
    setQuoteOutput(null);
  };

  const getCurrencyPrice = (priceGBP: number) => {
    const conv = CURRENCY_CONVERSION[activeCurrency];
    if (!conv) return `£${priceGBP.toLocaleString()}`;
    const value = Math.round(priceGBP * conv.rateToGBP);
    return `${conv.symbol}${value.toLocaleString()}`;
  };

  return (
    <div id="price-engine" className="bg-[#F8F9FA] border border-[#1C252C]/10 rounded-lg p-6 lg:p-8 text-[#1C252C] shadow-sm max-w-5xl mx-auto my-8">
      
      {/* Title & Step Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-[#1C252C]/10 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 bg-[#F37021] rounded-sm" />
            <h2 className="text-xl font-mono font-bold tracking-wider">CONTAINER PRICE ENGINE</h2>
          </div>
          <p className="text-xs text-slate-500 font-sans">
            Configure shipping variables to receive structured, real-time logistics approximations.
          </p>
        </div>

        {step <= 5 && (
          <div className="flex items-center gap-1 mt-4 md:mt-0 text-xs font-mono font-bold text-slate-400">
            {[1, 2, 3, 4, 5].map((num) => (
              <div 
                key={num} 
                className={`flex items-center ${num < 5 ? "after:content-['-'] after:mx-1 after:text-slate-300" : ""}`}
              >
                <span className={`px-2 py-0.5 rounded ${step === num ? 'bg-[#0B1E36] text-[#FBBF24]' : 'bg-slate-200 text-slate-600'}`}>
                  {num}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Main Wizard Form */}
      <div className="min-h-[350px]">
        <AnimatePresence mode="wait">
          
          {/* STEP 1: ORIGIN */}
          {step === 1 && (
            <motion.div
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              className="space-y-6 text-left"
            >
              <h3 className="text-sm font-mono font-bold border-l-2 border-[#0B1E36] pl-2 uppercase text-[#0B1E36]">
                Step 1: ORIGIN / PICKUP GEOGRAPHY
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">PICKUP WAREHOUSE / HUB</label>
                  <select 
                    value={warehouseId} 
                    onChange={(e) => setWarehouseId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded font-mono text-sm bg-white focus:outline-none focus:border-[#0B1E36]"
                  >
                    {WAREHOUSES.map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.name} ({w.city})
                      </option>
                    ))}
                    <option value="custom">Other / Custom Location</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">ORIGIN COUNTRY</label>
                  <input 
                    type="text" 
                    value={originCountry} 
                    onChange={(e) => setOriginCountry(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded text-sm bg-white focus:outline-none focus:border-[#0B1E36]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">CITY</label>
                  <input 
                    type="text" 
                    value={originCity} 
                    onChange={(e) => setOriginCity(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded text-sm bg-white focus:outline-none focus:border-[#0B1E36]"
                    disabled={warehouseId !== 'custom'}
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">POSTCODE</label>
                  <input 
                    type="text" 
                    value={originPostcode} 
                    onChange={(e) => setOriginPostcode(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded font-mono text-sm bg-white focus:outline-none focus:border-[#0B1E36]"
                    disabled={warehouseId !== 'custom'}
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">PICKUP DATE</label>
                  <input 
                    type="date" 
                    value={pickupDate} 
                    onChange={(e) => setPickupDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded text-sm font-mono bg-white focus:outline-none focus:border-[#0B1E36]"
                  />
                </div>
              </div>
            </motion.div>
          )}

          {/* STEP 2: DESTINATION */}
          {step === 2 && (
            <motion.div
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              className="space-y-6 text-left"
            >
              <h3 className="text-sm font-mono font-bold border-l-2 border-[#0B1E36] pl-2 uppercase text-[#0B1E36]">
                Step 2: DESTINATION / GATEWAY
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">DESTINATION COUNTRY</label>
                  <input 
                    type="text" 
                    value={destCountry} 
                    onChange={(e) => setDestCountry(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded text-sm bg-white focus:outline-none focus:border-[#0B1E36]"
                    placeholder="e.g. USA, China, Netherlands"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">DESTINATION PORT / TERMINAL</label>
                  <select 
                    value={destPort} 
                    onChange={(e) => {
                      setDestPort(e.target.value);
                      const pt = PORTS.find(p => p.name === e.target.value || p.code === e.target.value);
                      if (pt) {
                        setDestCountry(pt.country);
                        setDestCity(pt.name);
                      }
                    }}
                    className="w-full px-3 py-2 border border-slate-300 rounded font-mono text-sm bg-white focus:outline-none focus:border-[#0B1E36]"
                  >
                    {PORTS.filter(p => p.country !== 'United Kingdom').map((p) => (
                      <option key={p.code} value={p.name}>
                        {p.name} ({p.country}) [{p.code}]
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">DELIVERY CITY</label>
                  <input 
                    type="text" 
                    value={destCity} 
                    onChange={(e) => setDestCity(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded text-sm bg-white focus:outline-none focus:border-[#0B1E36]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">DESTINATION POSTCODE</label>
                  <input 
                    type="text" 
                    value={destPostcode} 
                    onChange={(e) => setDestPostcode(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded font-mono text-sm bg-white focus:outline-none focus:border-[#0B1E36]"
                    placeholder="e.g. 1012 JS"
                  />
                </div>
              </div>
            </motion.div>
          )}

          {/* STEP 3: CONTAINER TYPE */}
          {step === 3 && (
            <motion.div
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              className="space-y-6 text-left"
            >
              <h3 className="text-sm font-mono font-bold border-l-2 border-[#0B1E36] pl-2 uppercase text-[#0B1E36]">
                Step 3: CONTAINER SELECTION
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {CONTAINER_TYPES.map((type) => (
                  <div
                    key={type.code}
                    onClick={() => handleContainerChange(type.code)}
                    className={`p-4 border rounded cursor-pointer transition-all ${
                      containerCode === type.code 
                        ? 'border-[#F37021] bg-[#F37021]/5 ring-1 ring-[#F37021]' 
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-mono font-bold bg-[#0B1E36] text-white px-2 py-0.5 rounded">
                        {type.code}
                      </span>
                      {containerCode === type.code && <Check className="w-4 h-4 text-[#F37021]" />}
                    </div>
                    <h4 className="text-xs font-bold font-mono tracking-tight text-slate-800">{type.name}</h4>
                    <p className="text-[11px] text-slate-500 mt-1">Dims: {type.dimensions}</p>
                    <p className="text-[11px] text-slate-500">Max Cargo: {(type.weightLimitKg / 1000).toFixed(1)}T / {type.capacityCbm} m³</p>
                    <p className="text-[10px] text-slate-400 font-mono mt-2 uppercase border-t border-slate-100 pt-1">
                      {type.typicalUse.substring(0, 50)}...
                    </p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* STEP 4: CARGO DETAILS */}
          {step === 4 && (
            <motion.div
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              className="space-y-6 text-left"
            >
              <h3 className="text-sm font-mono font-bold border-l-2 border-[#0B1E36] pl-2 uppercase text-[#0B1E36]">
                Step 4: CARGO & WEIGHT SPECIFICATIONS
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">CARGO CATEGORY</label>
                  <select
                    value={cargoType}
                    onChange={(e) => setCargoType(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded text-sm bg-white focus:outline-none focus:border-[#0B1E36]"
                  >
                    <option value="General Cargo">General Cargo (Dry Goods, Retail)</option>
                    <option value="Industrial Machinery">Heavy Machinery & Spares</option>
                    <option value="Agriculture / Produce">Agricultural / Perishable Produce</option>
                    <option value="Chemicals">Chemicals & Hazardous Cargo</option>
                    <option value="Forest Products">Timber, Wood & Paper</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">COMMODITY DESCRIPTION</label>
                  <input 
                    type="text" 
                    value={commodity} 
                    onChange={(e) => setCommodity(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded text-sm bg-white focus:outline-none focus:border-[#0B1E36]"
                    placeholder="e.g. Copper wire reels, packed cardboard cartons"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">CARGO WEIGHT (KG)</label>
                  <input 
                    type="number" 
                    value={cargoWeightKg} 
                    onChange={(e) => setCargoWeightKg(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded font-mono text-sm bg-white focus:outline-none focus:border-[#0B1E36]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">CARGO VOLUME (CBM)</label>
                  <input 
                    type="number" 
                    value={cargoVolumeCbm} 
                    onChange={(e) => setCargoVolumeCbm(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded font-mono text-sm bg-white focus:outline-none focus:border-[#0B1E36]"
                  />
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-6 p-4 bg-slate-100 rounded border border-slate-200 mt-4 text-xs font-mono font-bold text-slate-700">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={isHazardous} 
                    onChange={(e) => setIsHazardous(e.target.checked)}
                    className="rounded border-slate-300 text-[#F37021] focus:ring-[#F37021] w-4 h-4"
                  />
                  <span>HAZARDOUS FREIGHT (ADR/IMDG CLASS COMPLIANT)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={isTempControlled} 
                    onChange={(e) => setIsTempControlled(e.target.checked)}
                    className="rounded border-slate-300 text-[#F37021] focus:ring-[#F37021] w-4 h-4"
                  />
                  <span>TEMPERATURE CONTROLLED (REEFER ACTIVE POWER)</span>
                </label>
              </div>
            </motion.div>
          )}

          {/* STEP 5: SERVICE & INTERMODAL */}
          {step === 5 && (
            <motion.div
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              className="space-y-6 text-left"
            >
              <h3 className="text-sm font-mono font-bold border-l-2 border-[#0B1E36] pl-2 uppercase text-[#0B1E36]">
                Step 5: SERVICE MODE & INTERMODAL SELECTION
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">SERVICE TYPE</label>
                  <div className="grid grid-cols-2 gap-2 text-xs font-mono font-bold">
                    {[
                      { code: 'door-door', label: 'Door → Door' },
                      { code: 'door-port', label: 'Door → Port' },
                      { code: 'port-door', label: 'Port → Door' },
                      { code: 'port-port', label: 'Port → Port' }
                    ].map((srv) => (
                      <button
                        key={srv.code}
                        onClick={() => setServiceType(srv.code as any)}
                        type="button"
                        className={`p-3 border rounded text-center uppercase ${
                          serviceType === srv.code 
                            ? 'bg-[#0B1E36] text-white border-[#0B1E36]' 
                            : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        {srv.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold text-slate-600 mb-2">INTERMODAL PROPULSION</label>
                  <div className="grid grid-cols-1 gap-2 text-xs font-mono font-bold">
                    {[
                      { code: 'road-sea', label: 'Road + Sea Freight' },
                      { code: 'rail-sea', label: 'Rail + Sea Freight (Port Terminal Connected)' },
                      { code: 'road-rail-sea', label: 'Road + Rail + Sea Freight (Multi-leg Intermodal)' }
                    ].map((mode) => (
                      <button
                        key={mode.code}
                        onClick={() => setTransportMode(mode.code as any)}
                        type="button"
                        className={`p-3 border rounded text-left px-4 ${
                          transportMode === mode.code 
                            ? 'bg-[#F37021] text-white border-[#F37021]' 
                            : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        {mode.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Warning box */}
              <div className="p-4 bg-orange-50 border border-orange-200 rounded text-xs leading-relaxed text-orange-800 flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-[#F37021] shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">IMPORTANT PRICING NOTICE:</span> Every displayed rate generated by this computer tool represents an <strong>INDICATIVE / DEMO RATE</strong> based on static calculation algorithms. These values do not represent binding market contracts unless finalized by our booking desk.
                </div>
              </div>
            </motion.div>
          )}

          {/* STEP 6: QUOTE OUTPUT SUMMARY */}
          {step === 6 && quoteOutput && (
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-8 text-left"
            >
              {/* Header Badge */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 bg-[#0B1E36] text-white rounded">
                <div>
                  <span className="text-[10px] font-mono tracking-widest text-[#FBBF24] font-bold block uppercase">
                    INDICATIVE RATE BOOKING REFERENCE
                  </span>
                  <span className="text-lg font-mono font-bold text-white tracking-wider">
                    {quoteOutput.reference}
                  </span>
                </div>
                
                {/* Currency Swapper */}
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-slate-300">CURRENCY:</span>
                  <select 
                    value={activeCurrency}
                    onChange={(e) => setActiveCurrency(e.target.value)}
                    className="bg-slate-800 text-white font-mono font-bold text-xs p-1.5 rounded border border-white/20 focus:outline-none"
                  >
                    {Object.keys(CURRENCY_CONVERSION).map(cur => (
                      <option key={cur} value={cur}>{cur} - {CURRENCY_CONVERSION[cur].name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Grid 2 Column Breakdown */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* Col Left: Specifics and Route Timeline */}
                <div className="lg:col-span-7 space-y-6">
                  <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 border-b border-slate-200 pb-2">
                    SHIPMENT SUMMARY
                  </h4>

                  <div className="grid grid-cols-2 gap-4 text-xs font-sans">
                    <div>
                      <span className="block text-slate-500 font-bold uppercase font-mono text-[10px]">ORIGIN PICKUP</span>
                      <span className="font-semibold text-slate-800">{quoteOutput.origin}</span>
                    </div>
                    <div>
                      <span className="block text-slate-500 font-bold uppercase font-mono text-[10px]">FINAL DESTINATION</span>
                      <span className="font-semibold text-slate-800">{quoteOutput.destination}</span>
                    </div>
                    <div>
                      <span className="block text-slate-500 font-bold uppercase font-mono text-[10px]">CONTAINER TYPE</span>
                      <span className="font-mono text-[#0B1E36] font-bold">{quoteOutput.containerName}</span>
                    </div>
                    <div>
                      <span className="block text-slate-500 font-bold uppercase font-mono text-[10px]">CARGO & VOLUME</span>
                      <span className="font-semibold text-slate-800">{quoteOutput.cargoDescription}</span>
                    </div>
                    <div>
                      <span className="block text-slate-500 font-bold uppercase font-mono text-[10px]">TRANSIT ESTIMATION</span>
                      <span className="font-mono font-bold text-slate-800 text-sm">
                        {quoteOutput.estimatedTransitDays}–{quoteOutput.estimatedTransitDays + 3} Days
                      </span>
                    </div>
                    <div>
                      <span className="block text-slate-500 font-bold uppercase font-mono text-[10px]">EMISSIONS METRIC</span>
                      <span className="font-mono text-emerald-700 font-bold">
                        ~{quoteOutput.co2EmissionsKg} kg CO₂e
                      </span>
                    </div>
                  </div>

                  {/* Route Leg Progress Graph */}
                  <div>
                    <h5 className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest mb-4">
                      MULTIMODAL LEG CHAIN
                    </h5>
                    
                    <div className="space-y-4 border-l-2 border-[#0B1E36]/20 pl-4 ml-2">
                      {quoteOutput.routeLegs.map((leg, index) => (
                        <div key={index} className="relative">
                          <span className="absolute -left-[23px] top-1 w-2.5 h-2.5 rounded-full bg-[#0B1E36] border-2 border-white" />
                          <div className="text-xs">
                            <span className="font-mono font-bold text-[#F37021] uppercase tracking-wider block text-[9px]">
                              LEG {index + 1} • {leg.mode}
                            </span>
                            <span className="font-bold text-slate-800 block text-xs mt-0.5">
                              {leg.from} → {leg.to}
                            </span>
                            <span className="text-[11px] text-slate-500 font-mono">
                              Transit: {leg.transit}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Col Right: Detailed Cost breakdown */}
                <div className="lg:col-span-5 bg-white p-5 border border-slate-200 rounded shadow-sm flex flex-col justify-between">
                  <div>
                    <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 border-b border-slate-200 pb-2 mb-4">
                      RATE BREAKDOWN
                    </h4>

                    <div className="space-y-2.5 text-xs font-mono font-bold">
                      <div className="flex justify-between text-slate-600">
                        <span>UK Inland Collection</span>
                        <span>{getCurrencyPrice(quoteOutput.ukCollectionCost)}</span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Port Gate Handling</span>
                        <span>{getCurrencyPrice(quoteOutput.portHandlingCost)}</span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Ocean Freight Leg</span>
                        <span>{getCurrencyPrice(quoteOutput.baseOceanFreight)}</span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Destination Port THC</span>
                        <span>{getCurrencyPrice(quoteOutput.destinationHandlingCost)}</span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Final Inland Delivery</span>
                        <span>{getCurrencyPrice(quoteOutput.finalDeliveryCost)}</span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Documentation Issuance</span>
                        <span>{getCurrencyPrice(quoteOutput.documentationCost)}</span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Customs Clearance</span>
                        <span>{getCurrencyPrice(quoteOutput.customsCost)}</span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Fuel & Safety Surcharges</span>
                        <span>{getCurrencyPrice(quoteOutput.surcharges)}</span>
                      </div>
                      
                      <div className="border-t border-dashed border-slate-200 my-4 pt-4 flex justify-between text-base font-bold text-[#0B1E36]">
                        <span>TOTAL QUOTE</span>
                        <span>{getCurrencyPrice(quoteOutput.totalCostGBP)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-slate-100 mt-6 space-y-3">
                    {isBookingDone ? (
                      <div className="bg-emerald-50 border border-emerald-200 p-4 rounded text-center text-emerald-800 text-xs">
                        <div className="flex items-center justify-center gap-2 mb-1">
                          <Check className="w-4 h-4" />
                          <span className="font-bold">BOOKING GENERATED SUCCESSFULLY</span>
                        </div>
                        <p className="text-[11px] font-mono mt-1 text-slate-600">
                          Shipment Ref: <strong className="text-[#0B1E36]">{bookingRef}</strong> has been booked in DEMO state. Manage this inside the <button onClick={() => onRequestTabSwitch('portal')} className="underline font-bold text-[#F37021]">Customer Portal</button>.
                        </p>
                      </div>
                    ) : (
                      <>
                        <button
                          onClick={handleBookShipment}
                          className="w-full py-3 bg-[#F37021] hover:bg-orange-600 transition-colors text-white text-xs font-mono font-bold rounded text-center uppercase tracking-wider"
                        >
                          PROVISION BOOKING SIMULATION
                        </button>

                        <button
                          onClick={() => window.print()}
                          className="w-full py-2 bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-700 text-xs font-mono font-bold rounded flex items-center justify-center gap-2"
                        >
                          <Printer className="w-4 h-4" />
                          <span>PRINT PRO-FORMA QUOTE</span>
                        </button>
                      </>
                    )}

                    <div className="text-[10px] font-mono text-slate-400 text-center uppercase tracking-wide leading-normal mt-2">
                      * Rate Valid Until {quoteOutput.validityDate} under Demo FX values.
                    </div>
                  </div>
                </div>

              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between border-t border-[#1C252C]/10 pt-6 mt-8">
        {step > 1 && step <= 5 && (
          <button
            onClick={() => setStep(step - 1)}
            className="flex items-center gap-1.5 px-4 py-2 border border-slate-300 text-slate-600 hover:text-[#0B1E36] font-mono text-xs font-bold rounded uppercase transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>PREVIOUS</span>
          </button>
        )}

        {step === 1 && (
          <div className="text-slate-400 text-[10px] font-mono uppercase tracking-wider">
            MEDWAY PRICE CORE V1.4.2
          </div>
        )}

        {step < 5 ? (
          <button
            onClick={() => setStep(step + 1)}
            className="ml-auto flex items-center gap-1.5 px-5 py-2.5 bg-[#0B1E36] hover:bg-[#1C252C] text-white font-mono text-xs font-bold rounded uppercase tracking-wider transition-colors"
          >
            <span>CONTINUE</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        ) : step === 5 ? (
          <button
            onClick={calculateQuote}
            className="ml-auto flex items-center gap-1.5 px-6 py-3 bg-[#F37021] hover:bg-orange-600 text-white font-mono text-xs font-bold rounded uppercase tracking-wider transition-all"
          >
            <Calculator className="w-4 h-4" />
            <span>CALCULATE INDICATIVE PRICE</span>
          </button>
        ) : (
          <button
            onClick={resetForm}
            className="mx-auto flex items-center gap-1.5 px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-mono text-xs font-bold rounded uppercase transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>START NEW CALCULATION</span>
          </button>
        )}
      </div>

    </div>
  );
}
