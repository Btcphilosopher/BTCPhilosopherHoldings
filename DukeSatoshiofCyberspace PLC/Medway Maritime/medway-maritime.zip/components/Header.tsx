'use client';

import React from 'react';
import { Anchor, ShieldAlert } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  openQuote: () => void;
  openLogin: () => void;
  isLoggedIn: boolean;
  onLogout: () => void;
}

export default function Header({
  activeTab,
  setActiveTab,
  openQuote,
  openLogin,
  isLoggedIn,
  onLogout,
}: HeaderProps) {
  const navItems = [
    { id: 'ship', label: 'SHIP' },
    { id: 'rates', label: 'RATES' },
    { id: 'routes', label: 'ROUTES' },
    { id: 'ports', label: 'PORTS' },
    { id: 'track', label: 'TRACK' },
    { id: 'customs', label: 'CUSTOMS' },
    { id: 'portal', label: 'PORTAL' },
    { id: 'admin', label: 'ADMIN' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-[#1C252C]/10 bg-[#0B1E36]/95 backdrop-blur text-white shadow-md">
      {/* Disclaimer strip */}
      <div className="bg-[#FBBF24] text-[#78350F] px-4 py-1 text-center text-xs font-mono font-bold flex items-center justify-center gap-1.5 whitespace-nowrap">
        <ShieldAlert className="w-3.5 h-3.5" />
        <span>DEMO SYSTEMS: ALL FREIGHT QUOTATIONS AND VESSEL STATUSES DISPLAYED ARE SYNTHETIC FOR SIMULATION PURPOSES.</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Zone 1: Brand Wordmark (Single text element layout) */}
        <div 
          onClick={() => setActiveTab('ship')} 
          className="flex items-center gap-2 cursor-pointer group shrink-0"
        >
          <Anchor className="w-6 h-6 text-[#F37021] group-hover:rotate-12 transition-transform duration-300" />
          <span className="text-xl font-bold tracking-wider font-mono bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
            MEDWAY MARITIME
          </span>
        </div>

        {/* Zone 2: 4-6 primary nav links (clean, single-line typography) */}
        <nav className="hidden lg:flex items-center gap-6 text-xs font-mono font-bold tracking-wider">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`py-2 px-1 relative transition-colors duration-200 uppercase hover:text-[#F37021] whitespace-nowrap ${
                activeTab === item.id ? 'text-[#F37021]' : 'text-slate-200'
              }`}
            >
              {item.label}
              {activeTab === item.id && (
                <span className="absolute bottom-0 left-0 w-full h-0.5 bg-[#F37021]" />
              )}
            </button>
          ))}
        </nav>

        {/* Zone 3: 1-2 primary action points */}
        <div className="flex items-center gap-3">
          <button
            onClick={openQuote}
            className="px-4 py-2 text-xs font-mono font-bold tracking-wider uppercase text-[#0B1E36] bg-[#F37021] rounded hover:bg-[#F37021]/95 transition-all duration-200 active:scale-95 shadow shadow-orange-500/20 whitespace-nowrap"
          >
            GET A QUOTE
          </button>
          
          {isLoggedIn ? (
            <button
              onClick={onLogout}
              className="hidden sm:block px-3 py-2 text-xs font-mono border border-white/20 rounded text-slate-300 hover:text-white hover:border-white transition-colors whitespace-nowrap"
            >
              LOGOUT
            </button>
          ) : (
            <button
              onClick={openLogin}
              className="hidden sm:block px-3 py-2 text-xs font-mono border border-white/20 rounded text-slate-300 hover:text-white hover:border-white transition-colors whitespace-nowrap"
            >
              CUSTOMER LOGIN
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
