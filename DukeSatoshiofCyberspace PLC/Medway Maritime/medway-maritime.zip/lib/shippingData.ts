// Medway Maritime Shipping & Intermodal Pricing Engine Data & Logic
// Contains rich synthetic dataset with 100+ ports, 50+ trade lanes, 50+ vessels, etc.
// All clearly marked as DEMO / INDICATIVE where applicable.

export interface Port {
  code: string;
  name: string;
  country: string;
  region: 'EUROPE' | 'NORTH AMERICA' | 'SOUTH AMERICA' | 'ASIA' | 'MIDDLE EAST' | 'AFRICA' | 'OCEANIA';
  type: 'container' | 'RoRo' | 'general' | 'deep-water' | 'short-sea';
  railConnected: boolean;
  coordinates: { x: number; y: number }; // Relative coordinates for our vector map
}

export interface ContainerType {
  code: string;
  name: string;
  dimensions: string;
  capacityCbm: number;
  weightLimitKg: number;
  typicalUse: string;
  baseMultiplier: number;
}

export interface TradeLane {
  id: string;
  originRegion: string;
  destRegion: string;
  typicalContainer: string;
  mode: string;
  baseOceanRateGBP: number;
  transitDays: number;
  ports: string[]; // port codes
  documentationRequired: string[];
}

export interface Vessel {
  imo: string;
  name: string;
  voyage: string;
  origin: string;
  destination: string;
  etaDays: number; // days from now
  status: string;
  containerCount: number;
}

export interface Warehouse {
  id: string;
  name: string;
  city: string;
  postcode: string;
  region: string;
  railConnected: boolean;
}

// 1. Ports Database (100+ ports)
export const PORTS: Port[] = [
  // UK Ports
  { code: 'GBPLG', name: 'London Gateway', country: 'United Kingdom', region: 'EUROPE', type: 'container', railConnected: true, coordinates: { x: 450, y: 320 } },
  { code: 'GBPMD', name: 'London Thamesport (Medway)', country: 'United Kingdom', region: 'EUROPE', type: 'container', railConnected: true, coordinates: { x: 455, y: 325 } },
  { code: 'GBFXT', name: 'Felixstowe', country: 'United Kingdom', region: 'EUROPE', type: 'deep-water', railConnected: true, coordinates: { x: 462, y: 305 } },
  { code: 'GBSOU', name: 'Southampton', country: 'United Kingdom', region: 'EUROPE', type: 'deep-water', railConnected: true, coordinates: { x: 420, y: 340 } },
  { code: 'GBLIV', name: 'Liverpool', country: 'United Kingdom', region: 'EUROPE', type: 'container', railConnected: true, coordinates: { x: 380, y: 240 } },
  { code: 'GBIMM', name: 'Immingham', country: 'United Kingdom', region: 'EUROPE', type: 'general', railConnected: true, coordinates: { x: 440, y: 220 } },
  { code: 'GBTEE', name: 'Teesport', country: 'United Kingdom', region: 'EUROPE', type: 'container', railConnected: true, coordinates: { x: 435, y: 180 } },
  { code: 'GBHUL', name: 'Hull', country: 'United Kingdom', region: 'EUROPE', type: 'general', railConnected: true, coordinates: { x: 438, y: 200 } },
  { code: 'GBBRS', name: 'Bristol', country: 'United Kingdom', region: 'EUROPE', type: 'general', railConnected: false, coordinates: { x: 375, y: 310 } },
  { code: 'GBCPT', name: 'Clydeport', country: 'United Kingdom', region: 'EUROPE', type: 'deep-water', railConnected: false, coordinates: { x: 320, y: 120 } },
  { code: 'GBGRG', name: 'Grangemouth', country: 'United Kingdom', region: 'EUROPE', type: 'container', railConnected: true, coordinates: { x: 340, y: 100 } },
  { code: 'GBDVR', name: 'Dover', country: 'United Kingdom', region: 'EUROPE', type: 'RoRo', railConnected: false, coordinates: { x: 465, y: 338 } },

  // EUROPE (Rest of Europe)
  { code: 'NLRTM', name: 'Rotterdam', country: 'Netherlands', region: 'EUROPE', type: 'deep-water', railConnected: true, coordinates: { x: 495, y: 320 } },
  { code: 'BEANR', name: 'Antwerp', country: 'Belgium', region: 'EUROPE', type: 'container', railConnected: true, coordinates: { x: 490, y: 335 } },
  { code: 'DEHAM', name: 'Hamburg', country: 'Germany', region: 'EUROPE', type: 'deep-water', railConnected: true, coordinates: { x: 530, y: 270 } },
  { code: 'DEBRE', name: 'Bremerhaven', country: 'Germany', region: 'EUROPE', type: 'container', railConnected: true, coordinates: { x: 518, y: 280 } },
  { code: 'FRLEH', name: 'Le Havre', country: 'France', region: 'EUROPE', type: 'container', railConnected: true, coordinates: { x: 445, y: 365 } },
  { code: 'ESBIO', name: 'Bilbao', country: 'Spain', region: 'EUROPE', type: 'general', railConnected: false, coordinates: { x: 410, y: 460 } },
  { code: 'ITGOA', name: 'Genoa', country: 'Italy', region: 'EUROPE', type: 'container', railConnected: true, coordinates: { x: 495, y: 440 } },
  { code: 'ESBCN', name: 'Barcelona', country: 'Spain', region: 'EUROPE', type: 'container', railConnected: true, coordinates: { x: 470, y: 475 } },
  { code: 'DKAAR', name: 'Aarhus', country: 'Denmark', region: 'EUROPE', type: 'container', railConnected: true, coordinates: { x: 535, y: 230 } },
  { code: 'PLGDN', name: 'Gdansk', country: 'Poland', region: 'EUROPE', type: 'deep-water', railConnected: true, coordinates: { x: 610, y: 250 } },
  { code: 'GOPIR', name: 'Piraeus', country: 'Greece', region: 'EUROPE', type: 'deep-water', railConnected: true, coordinates: { x: 605, y: 510 } },
  { code: 'TRVQN', name: 'Ambarli (Istanbul)', country: 'Turkey', region: 'EUROPE', type: 'container', railConnected: true, coordinates: { x: 655, y: 490 } },

  // NORTH AMERICA
  { code: 'USNYC', name: 'New York / New Jersey', country: 'USA', region: 'NORTH AMERICA', type: 'deep-water', railConnected: true, coordinates: { x: 200, y: 320 } },
  { code: 'USORF', name: 'Norfolk', country: 'USA', region: 'NORTH AMERICA', type: 'container', railConnected: true, coordinates: { x: 195, y: 340 } },
  { code: 'USSAV', name: 'Savannah', country: 'USA', region: 'NORTH AMERICA', type: 'container', railConnected: true, coordinates: { x: 185, y: 375 } },
  { code: 'USHOU', name: 'Houston', country: 'USA', region: 'NORTH AMERICA', type: 'deep-water', railConnected: true, coordinates: { x: 140, y: 410 } },
  { code: 'USLAX', name: 'Los Angeles', country: 'USA', region: 'NORTH AMERICA', type: 'deep-water', railConnected: true, coordinates: { x: 60, y: 360 } },
  { code: 'USLGB', name: 'Long Beach', country: 'USA', region: 'NORTH AMERICA', type: 'container', railConnected: true, coordinates: { x: 62, y: 362 } },
  { code: 'CAVAN', name: 'Vancouver', country: 'Canada', region: 'NORTH AMERICA', type: 'deep-water', railConnected: true, coordinates: { x: 70, y: 250 } },
  { code: 'CAMTR', name: 'Montreal', country: 'Canada', region: 'NORTH AMERICA', type: 'container', railConnected: true, coordinates: { x: 215, y: 290 } },
  { code: 'USOAK', name: 'Oakland', country: 'USA', region: 'NORTH AMERICA', type: 'container', railConnected: true, coordinates: { x: 55, y: 330 } },
  { code: 'USSEA', name: 'Seattle', country: 'USA', region: 'NORTH AMERICA', type: 'container', railConnected: true, coordinates: { x: 70, y: 270 } },
  { code: 'USMIA', name: 'Miami', country: 'USA', region: 'NORTH AMERICA', type: 'general', railConnected: false, coordinates: { x: 190, y: 415 } },
  { code: 'MXVER', name: 'Veracruz', country: 'Mexico', region: 'NORTH AMERICA', type: 'general', railConnected: true, coordinates: { x: 125, y: 450 } },

  // ASIA
  { code: 'CNSHA', name: 'Shanghai', country: 'China', region: 'ASIA', type: 'deep-water', railConnected: true, coordinates: { x: 810, y: 380 } },
  { code: 'CNNGB', name: 'Ningbo', country: 'China', region: 'ASIA', type: 'deep-water', railConnected: true, coordinates: { x: 815, y: 390 } },
  { code: 'CNSZX', name: 'Shenzhen', country: 'China', region: 'ASIA', type: 'container', railConnected: true, coordinates: { x: 795, y: 420 } },
  { code: 'HKHKG', name: 'Hong Kong', country: 'Hong Kong', region: 'ASIA', type: 'deep-water', railConnected: false, coordinates: { x: 800, y: 425 } },
  { code: 'SGSIN', name: 'Singapore', country: 'Singapore', region: 'ASIA', type: 'deep-water', railConnected: true, coordinates: { x: 765, y: 530 } },
  { code: 'KRBUS', name: 'Busan', country: 'South Korea', region: 'ASIA', type: 'deep-water', railConnected: true, coordinates: { x: 835, y: 360 } },
  { code: 'TYOJP', name: 'Tokyo', country: 'Japan', region: 'ASIA', type: 'container', railConnected: true, coordinates: { x: 865, y: 350 } },
  { code: 'YOKJP', name: 'Yokohama', country: 'Japan', region: 'ASIA', type: 'deep-water', railConnected: true, coordinates: { x: 868, y: 355 } },
  { code: 'MYPKG', name: 'Port Klang', country: 'Malaysia', region: 'ASIA', type: 'container', railConnected: true, coordinates: { x: 755, y: 520 } },
  { code: 'THLCH', name: 'Laem Chabang', country: 'Thailand', region: 'ASIA', type: 'container', railConnected: true, coordinates: { x: 760, y: 480 } },
  { code: 'VNSGN', name: 'Saigon (Ho Chi Minh)', country: 'Vietnam', region: 'ASIA', type: 'general', railConnected: false, coordinates: { x: 775, y: 495 } },
  { code: 'INNSA', name: 'Nhava Sheva (Mumbai)', country: 'India', region: 'ASIA', type: 'container', railConnected: true, coordinates: { x: 690, y: 460 } },
  { code: 'LKCMB', name: 'Colombo', country: 'Sri Lanka', region: 'ASIA', type: 'deep-water', railConnected: true, coordinates: { x: 705, y: 510 } },
  { code: 'KHHJP', name: 'Kaohsiung', country: 'Taiwan', region: 'ASIA', type: 'container', railConnected: false, coordinates: { x: 818, y: 418 } },

  // MIDDLE EAST
  { code: 'AEDXB', name: 'Dubai Cargo Port', country: 'UAE', region: 'MIDDLE EAST', type: 'general', railConnected: false, coordinates: { x: 650, y: 430 } },
  { code: 'AEJEA', name: 'Jebel Ali', country: 'UAE', region: 'MIDDLE EAST', type: 'deep-water', railConnected: true, coordinates: { x: 652, y: 434 } },
  { code: 'QADOH', name: 'Doha', country: 'Qatar', region: 'MIDDLE EAST', type: 'container', railConnected: false, coordinates: { x: 640, y: 436 } },
  { code: 'SAJED', name: 'Jeddah', country: 'Saudi Arabia', region: 'MIDDLE EAST', type: 'deep-water', railConnected: true, coordinates: { x: 615, y: 465 } },
  { code: 'SADMM', name: 'Dammam', country: 'Saudi Arabia', region: 'MIDDLE EAST', type: 'container', railConnected: true, coordinates: { x: 635, y: 432 } },
  { code: 'OMMCT', name: 'Sohar', country: 'Oman', region: 'MIDDLE EAST', type: 'container', railConnected: false, coordinates: { x: 660, y: 442 } },
  { code: 'KWTWI', name: 'Shuaiba', country: 'Kuwait', region: 'MIDDLE EAST', type: 'general', railConnected: false, coordinates: { x: 630, y: 420 } },

  // SOUTH AMERICA
  { code: 'BRSSZ', name: 'Santos', country: 'Brazil', region: 'SOUTH AMERICA', type: 'deep-water', railConnected: true, coordinates: { x: 290, y: 640 } },
  { code: 'ARBUE', name: 'Buenos Aires', country: 'Argentina', region: 'SOUTH AMERICA', type: 'container', railConnected: true, coordinates: { x: 270, y: 690 } },
  { code: 'COCTG', name: 'Cartagena', country: 'Colombia', region: 'SOUTH AMERICA', type: 'container', railConnected: false, coordinates: { x: 190, y: 500 } },
  { code: 'CLVAP', name: 'Valparaiso', country: 'Chile', region: 'SOUTH AMERICA', type: 'general', railConnected: true, coordinates: { x: 210, y: 680 } },
  { code: 'PECLL', name: 'Callao', country: 'Peru', region: 'SOUTH AMERICA', type: 'container', railConnected: false, coordinates: { x: 200, y: 580 } },
  { code: 'ECGYE', name: 'Guayaquil', country: 'Ecuador', region: 'SOUTH AMERICA', type: 'general', railConnected: false, coordinates: { x: 195, y: 550 } },

  // AFRICA
  { code: 'ZACPT', name: 'Cape Town', country: 'South Africa', region: 'AFRICA', type: 'deep-water', railConnected: true, coordinates: { x: 500, y: 680 } },
  { code: 'ZADUR', name: 'Durban', country: 'South Africa', region: 'AFRICA', type: 'container', railConnected: true, coordinates: { x: 520, y: 670 } },
  { code: 'NGAPP', name: 'Apapa (Lagos)', country: 'Nigeria', region: 'AFRICA', type: 'container', railConnected: false, coordinates: { x: 460, y: 540 } },
  { code: 'KEMBA', name: 'Mombasa', country: 'Kenya', region: 'AFRICA', type: 'container', railConnected: true, coordinates: { x: 545, y: 575 } },
  { code: 'MACAS', name: 'Casablanca', country: 'Morocco', region: 'AFRICA', type: 'general', railConnected: true, coordinates: { x: 420, y: 420 } },
  { code: 'EGALY', name: 'Alexandria', country: 'Egypt', region: 'AFRICA', type: 'deep-water', railConnected: true, coordinates: { x: 540, y: 430 } },
  { code: 'DZALG', name: 'Algiers', country: 'Algeria', region: 'AFRICA', type: 'general', railConnected: false, coordinates: { x: 465, y: 425 } },

  // OCEANIA
  { code: 'AUSYD', name: 'Sydney', country: 'Australia', region: 'OCEANIA', type: 'deep-water', railConnected: true, coordinates: { x: 880, y: 680 } },
  { code: 'AUMEL', name: 'Melbourne', country: 'Australia', region: 'OCEANIA', type: 'container', railConnected: true, coordinates: { x: 860, y: 695 } },
  { code: 'AUBNE', name: 'Brisbane', country: 'Australia', region: 'OCEANIA', type: 'container', railConnected: true, coordinates: { x: 890, y: 660 } },
  { code: 'NZAKL', name: 'Auckland', country: 'New Zealand', region: 'OCEANIA', type: 'container', railConnected: false, coordinates: { x: 920, y: 710 } },
  { code: 'NZLYT', name: 'Lyttelton (Christchurch)', country: 'New Zealand', region: 'OCEANIA', type: 'general', railConnected: true, coordinates: { x: 915, y: 730 } }
];

// Complete the array up to 100 entries for high-fidelity dataset
const countriesAndSubPorts = [
  { prefix: 'US', names: ['Oakland', 'Charleston', 'Tacoma', 'Boston', 'Philadelphia', 'Baltimore', 'Jacksonville', 'San Juan'], region: 'NORTH AMERICA' },
  { prefix: 'CN', names: ['Xiamen', 'Qingdao', 'Tianjin', 'Dalian', 'Fuzhou', 'Guangzhou', 'Yantian', 'Shekou'], region: 'ASIA' },
  { prefix: 'DE', names: ['Rostock', 'Kiel', 'Lubeck', 'Wilhelmshaven'], region: 'EUROPE' },
  { prefix: 'FR', names: ['Marseille', 'Dunkirk', 'Brest', 'Nantes'], region: 'EUROPE' },
  { prefix: 'IT', names: ['Trieste', 'Naples', 'La Spezia', 'Venice'], region: 'EUROPE' },
  { prefix: 'ES', names: ['Valencia', 'Algeciras', 'Las Palmas', 'Vigo'], region: 'EUROPE' },
  { prefix: 'UK', names: ['Grangemouth', 'Clydeport', 'Belfast', 'Cardiff', 'Tyne', 'Teignmouth', 'Warrenpoint'], region: 'EUROPE' },
  { prefix: 'JP', names: ['Osaka', 'Kobe', 'Nagoya', 'Hakata', 'Shimizu'], region: 'ASIA' },
  { prefix: 'IN', names: ['Chennai', 'Kolkata', 'Cochin', 'Mundra', 'Kandla'], region: 'ASIA' }
];

let counter = 0;
countriesAndSubPorts.forEach(group => {
  group.names.forEach(name => {
    const code = `${group.prefix}${name.substring(0, 3).toUpperCase()}${counter++}`;
    if (PORTS.length < 105) {
      PORTS.push({
        code: code,
        name: name,
        country: group.prefix === 'US' ? 'USA' : group.prefix === 'CN' ? 'China' : group.prefix === 'DE' ? 'Germany' : group.prefix === 'FR' ? 'France' : group.prefix === 'IT' ? 'Italy' : group.prefix === 'ES' ? 'Spain' : group.prefix === 'JP' ? 'Japan' : group.prefix === 'IN' ? 'India' : 'United Kingdom',
        region: group.region as any,
        type: counter % 2 === 0 ? 'container' : 'general',
        railConnected: counter % 3 !== 0,
        coordinates: { x: 400 + (counter * 5) % 300, y: 300 + (counter * 8) % 200 }
      });
    }
  });
});

// 2. Container Specifications
export const CONTAINER_TYPES: ContainerType[] = [
  { code: '20GP', name: "20' Standard Dry Van (GP)", dimensions: "5.90m × 2.35m × 2.39m", capacityCbm: 33.2, weightLimitKg: 28200, typicalUse: "Heavy machinery, stone, copper, heavy industrial commodities.", baseMultiplier: 1.0 },
  { code: '40GP', name: "40' Standard Dry Van (GP)", dimensions: "12.03m × 2.35m × 2.39m", capacityCbm: 67.7, weightLimitKg: 28800, typicalUse: "Retail cargo, consumer goods, furniture, boxed freight.", baseMultiplier: 1.6 },
  { code: '40HC', name: "40' High Cube (HC)", dimensions: "12.03m × 2.35m × 2.69m", capacityCbm: 76.4, weightLimitKg: 28600, typicalUse: "Voluminous goods, light garments, machinery, tall packages.", baseMultiplier: 1.75 },
  { code: '45HC', name: "45' High Cube (HC)", dimensions: "13.56m × 2.35m × 2.69m", capacityCbm: 86.1, weightLimitKg: 27700, typicalUse: "Extra-long cargo, maximum domestic and short-sea capacity.", baseMultiplier: 2.0 },
  { code: '20RF', name: "20' Refrigerated Container (Reefer)", dimensions: "5.44m × 2.29m × 2.27m", capacityCbm: 28.3, weightLimitKg: 27200, typicalUse: "Frozen fruit, meat, dairy, temperature-sensitive chemicals.", baseMultiplier: 2.2 },
  { code: '40RF', name: "40' Refrigerated Container (Reefer)", dimensions: "11.56m × 2.29m × 2.50m", capacityCbm: 59.3, weightLimitKg: 29500, typicalUse: "Chilled produce, pharma, fresh seafood, long-distance cold-chain.", baseMultiplier: 2.9 },
  { code: '20OT', name: "20' Open Top", dimensions: "5.89m × 2.34m × 2.28m", capacityCbm: 32.5, weightLimitKg: 28000, typicalUse: "Overheight cargo, bulk minerals, machinery loaded from top via crane.", baseMultiplier: 1.9 },
  { code: '40FR', name: "40' Flat Rack", dimensions: "12.03m × 2.44m × 2.59m", capacityCbm: 67.0, weightLimitKg: 40000, typicalUse: "Heavy out-of-gauge (OOG) machinery, yachts, boilers, heavy steel.", baseMultiplier: 2.5 }
];

// 3. Trade Lanes (50+ Trade Lanes)
export const TRADE_LANES: TradeLane[] = [
  { id: 'TL-01', originRegion: 'EUROPE', destRegion: 'EUROPE', typicalContainer: '40HC', mode: 'Road + Sea', baseOceanRateGBP: 420, transitDays: 2, ports: ['GBPMD', 'NLRTM'], documentationRequired: ['T1 Transit', 'Bill of Lading', 'Commercial Invoice'] },
  { id: 'TL-02', originRegion: 'EUROPE', destRegion: 'ASIA', typicalContainer: '40HC', mode: 'Rail + Sea', baseOceanRateGBP: 2150, transitDays: 28, ports: ['GBPLG', 'CNSHA'], documentationRequired: ['Export Declarations', 'Bill of Lading', 'Packing List'] },
  { id: 'TL-03', originRegion: 'EUROPE', destRegion: 'NORTH AMERICA', typicalContainer: '40HC', mode: 'Road + Sea', baseOceanRateGBP: 1950, transitDays: 12, ports: ['GBSOU', 'USNYC'], documentationRequired: ['ISF Filing', 'Automated Manifest System (AMS)', 'Bill of Lading'] },
  { id: 'TL-04', originRegion: 'EUROPE', destRegion: 'MIDDLE EAST', typicalContainer: '40GP', mode: 'Road + Sea', baseOceanRateGBP: 1650, transitDays: 18, ports: ['GBFXT', 'AEJEA'], documentationRequired: ['Certificate of Origin', 'Customs Invoice', 'BOL'] },
  { id: 'TL-05', originRegion: 'EUROPE', destRegion: 'AFRICA', typicalContainer: '20GP', mode: 'Road + Sea', baseOceanRateGBP: 2200, transitDays: 22, ports: ['GBPMD', 'ZADUR'], documentationRequired: ['FERI Certificate', 'Packing List', 'Export Dec'] },
  { id: 'TL-06', originRegion: 'EUROPE', destRegion: 'OCEANIA', typicalContainer: '40HC', mode: 'Road + Sea', baseOceanRateGBP: 3100, transitDays: 38, ports: ['GBFXT', 'AUSYD'], documentationRequired: ['AQIS Declaration', 'BMSB Heat Treatment Cert', 'Bill of Lading'] },
  { id: 'TL-07', originRegion: 'EUROPE', destRegion: 'SOUTH AMERICA', typicalContainer: '40HC', mode: 'Road + Sea', baseOceanRateGBP: 2400, transitDays: 20, ports: ['GBPLG', 'BRSSZ'], documentationRequired: ['Mercosur customs declaration', 'Bill of Lading', 'Invoice'] }
];

// Fill up up to 50 trade lanes programmatically for search indexing / browsability
const globalRegions = ['EUROPE', 'NORTH AMERICA', 'SOUTH AMERICA', 'ASIA', 'MIDDLE EAST', 'AFRICA', 'OCEANIA'];
let laneCounter = 8;
globalRegions.forEach(origin => {
  globalRegions.forEach(dest => {
    if (origin !== dest && TRADE_LANES.length < 52) {
      const distanceFactor = Math.abs(globalRegions.indexOf(origin) - globalRegions.indexOf(dest));
      const transit = 5 + distanceFactor * 8;
      const baseRate = 1000 + distanceFactor * 750;
      TRADE_LANES.push({
        id: `TL-${laneCounter.toString().padStart(2, '0')}`,
        originRegion: origin,
        destRegion: dest,
        typicalContainer: laneCounter % 2 === 0 ? '40HC' : '20GP',
        mode: 'Road + Sea',
        baseOceanRateGBP: baseRate,
        transitDays: transit,
        ports: [
          PORTS.find(p => p.region === origin)?.code || 'GBPLG',
          PORTS.find(p => p.region === dest)?.code || 'CNSHA'
        ],
        documentationRequired: ['Commercial Invoice', 'Packing List', 'Bill of Lading', 'Customs Entry Form']
      });
      laneCounter++;
    }
  });
});

// 4. Fixed Demo Currencies and Rates to GBP
export const CURRENCY_CONVERSION: Record<string, { symbol: string; rateToGBP: number; name: string }> = {
  GBP: { symbol: '£', rateToGBP: 1.0, name: 'British Pound Sterling' },
  EUR: { symbol: '€', rateToGBP: 1.20, name: 'Euro' },
  USD: { symbol: '$', rateToGBP: 1.31, name: 'US Dollar' },
  CNY: { symbol: '¥', rateToGBP: 9.12, name: 'Chinese Yuan Renminbi' },
  JPY: { symbol: '¥', rateToGBP: 194.2, name: 'Japanese Yen' },
  AED: { symbol: 'د.إ', rateToGBP: 4.81, name: 'UAE Dirham' },
  SGD: { symbol: 'S$', rateToGBP: 1.69, name: 'Singapore Dollar' },
  CAD: { symbol: 'C$', rateToGBP: 1.77, name: 'Canadian Dollar' },
  AUD: { symbol: 'A$', rateToGBP: 1.91, name: 'Australian Dollar' }
};

// 5. Vessels Database (50 vessels)
export const VESSELS: Vessel[] = [
  { imo: 'IMO9811000', name: 'Medway Monarch', voyage: 'MM206E', origin: 'London Gateway', destination: 'Rotterdam', etaDays: 1, status: 'In Transit', containerCount: 18500 },
  { imo: 'IMO9778462', name: 'Kent Voyager', voyage: 'KV092W', origin: 'Shanghai', destination: 'London Thamesport', etaDays: 14, status: 'In Transit', containerCount: 21000 },
  { imo: 'IMO9912445', name: 'Thames Pioneer', voyage: 'TP304A', origin: 'Southampton', destination: 'New York', etaDays: 6, status: 'At Sea', containerCount: 15400 },
  { imo: 'IMO9632002', name: 'Estuary Eagle', voyage: 'EE011S', origin: 'Hamburg', destination: 'Singapore', etaDays: 20, status: 'Loading', containerCount: 19800 },
  { imo: 'IMO9745112', name: 'Rochester Castle', voyage: 'RC442N', origin: 'Dubai Jebel Ali', destination: 'Felixstowe', etaDays: 8, status: 'At Sea', containerCount: 22100 },
  { imo: 'IMO9821334', name: 'Chatham Vanguard', voyage: 'CV101E', origin: 'Felixstowe', destination: 'Antwerp', etaDays: 2, status: 'Arriving', containerCount: 8900 }
];

// Dynamically generate the remaining up to 50 vessels for the lookup
const vesselAdjectives = ['Kent', 'Medway', 'Thames', 'Gravesend', 'Sheerness', 'Dover', 'Downs', 'Solent', 'Estuary', 'Channel', 'Global', 'Ocean', 'Pacific', 'Atlantic', 'Northern', 'Southern', 'Equatorial', 'Maritime', 'Trade', 'Alliance'];
const vesselNouns = ['Monarch', 'Pioneer', 'Vessel', 'Voyager', 'Eagle', 'Castle', 'Vanguard', 'Tracer', 'Merchant', 'Carrier', 'Leader', 'Express', 'Star', 'Breeze', 'Clipper', 'Wanderer', 'Titan', 'Navigator', 'Trader', 'Sentinel'];

for (let i = 0; i < 45; i++) {
  const name = `${vesselAdjectives[i % vesselAdjectives.length]} ${vesselNouns[(i * 3) % vesselNouns.length]}`;
  const statusPool = ['At Sea', 'In Transit', 'Loading', 'Arriving', 'Moored', 'Anchored'];
  VESSELS.push({
    imo: `IMO9${(820000 + i * 231).toString().padStart(6, '0')}`,
    name: name,
    voyage: `${name.split(' ').map(n => n[0]).join('')}${100 + i}${i % 2 === 0 ? 'E' : 'W'}`,
    origin: PORTS[i % PORTS.length].name,
    destination: PORTS[(i + 3) % PORTS.length].name,
    etaDays: 1 + (i % 30),
    status: statusPool[i % statusPool.length],
    containerCount: 8000 + (i * 320) % 15000
  });
}

// 6. Warehouses Database (20 warehouses)
export const WAREHOUSES: Warehouse[] = [
  { id: 'WH01', name: 'Medway Logistics Centre East', city: 'Rochester', postcode: 'ME1 1UT', region: 'Kent', railConnected: false },
  { id: 'WH02', name: 'Thames Gateway Gateway Depot', city: 'Gravesend', postcode: 'DA12 2RE', region: 'Kent', railConnected: true },
  { id: 'WH03', name: 'Sheerness Terminal Hub', city: 'Sheerness', postcode: 'ME12 1RS', region: 'Kent', railConnected: true },
  { id: 'WH04', name: 'Midlands Intermodal Depot', city: 'Birmingham', postcode: 'B46 1AL', region: 'West Midlands', railConnected: true },
  { id: 'WH05', name: 'Manchester container Yard', city: 'Manchester', postcode: 'M17 1UP', region: 'Greater Manchester', railConnected: true },
  { id: 'WH06', name: 'Leeds Valley Freight Depot', city: 'Leeds', postcode: 'LS10 1PS', region: 'West Yorkshire', railConnected: true },
  { id: 'WH07', name: 'Southampton Freight Terminal', city: 'Southampton', postcode: 'SO15 1DA', region: 'Hampshire', railConnected: true },
  { id: 'WH08', name: 'Bristol Gateway Warehouse', city: 'Bristol', postcode: 'BS11 9YB', region: 'Bristol', railConnected: false },
  { id: 'WH09', name: 'London East Depot', city: 'Barking', postcode: 'IG11 0TU', region: 'Greater London', railConnected: true },
  { id: 'WH10', name: 'Glasgow Intermodal Terminal', city: 'Glasgow', postcode: 'G51 4UP', region: 'Glasgow', railConnected: true }
];

// Add 10 more programmatically to reach 20 warehouses
const extraCities = ['Nottingham', 'Sheffield', 'Liverpool', 'Felixstowe', 'Newcastle', 'Cardiff', 'Belfast', 'Edinburgh', 'Hull', 'Immingham'];
extraCities.forEach((city, index) => {
  WAREHOUSES.push({
    id: `WH${(11 + index)}`,
    name: `${city} Freight Junction`,
    city: city,
    postcode: `${city.substring(0,2).toUpperCase()}${1 + index} ${9}XY`,
    region: city === 'Belfast' ? 'Northern Ireland' : city === 'Cardiff' ? 'Wales' : city === 'Edinburgh' ? 'Scotland' : 'England',
    railConnected: index % 2 === 0
  });
});

// 7. Synthetic Rates (100 Rates)
export interface SyntheticRate {
  id: string;
  origin: string;
  port: string;
  destination: string;
  mode: string;
  containerType: string;
  indicativePriceGBP: number;
  transitDays: number;
  validityDate: string;
}

export const SYNTHETIC_RATES: SyntheticRate[] = [
  { id: 'RATE-001', origin: 'Birmingham', port: 'Felixstowe', destination: 'Rotterdam', mode: 'Road + Sea', containerType: '40HC', indicativePriceGBP: 1850, transitDays: 3, validityDate: '2026-12-31' },
  { id: 'RATE-002', origin: 'Manchester', port: 'Liverpool', destination: 'New York', mode: 'Road + Sea', containerType: '40HC', indicativePriceGBP: 4900, transitDays: 11, validityDate: '2026-12-31' },
  { id: 'RATE-003', origin: 'Leeds', port: 'Teesport', destination: 'Hamburg', mode: 'Rail + Sea', containerType: '20GP', indicativePriceGBP: 1720, transitDays: 4, validityDate: '2026-12-31' },
  { id: 'RATE-004', origin: 'London', port: 'London Gateway', destination: 'Singapore', mode: 'Road + Sea', containerType: '40HC', indicativePriceGBP: 5800, transitDays: 24, validityDate: '2026-12-31' },
  { id: 'RATE-005', origin: 'Bristol', port: 'Southampton', destination: 'Dubai', mode: 'Road + Sea', containerType: '40HC', indicativePriceGBP: 5100, transitDays: 16, validityDate: '2026-12-31' }
];

// Generate 95 more synthetic rates to make a comprehensive index of 100 rates
const majorCities = ['Birmingham', 'Manchester', 'Leeds', 'London', 'Bristol', 'Glasgow', 'Cardiff', 'Nottingham', 'Sheffield', 'Rochester', 'Dover'];
const activeGatewayPorts = ['London Gateway', 'Felixstowe', 'Southampton', 'Liverpool', 'Teesport', 'Hull'];
const mainDestinations = ['Rotterdam', 'Hamburg', 'Antwerp', 'New York', 'Shanghai', 'Singapore', 'Dubai', 'Santos', 'Sydney', 'Cape Town'];

for (let r = 0; r < 95; r++) {
  const city = majorCities[r % majorCities.length];
  const port = activeGatewayPorts[(r + 2) % activeGatewayPorts.length];
  const dest = mainDestinations[(r * 3) % mainDestinations.length];
  const container = r % 3 === 0 ? '20GP' : r % 3 === 1 ? '40GP' : '40HC';
  const price = 1200 + (r * 45) % 4500 + (container === '20GP' ? 0 : container === '40GP' ? 600 : 900);
  const trans = 3 + (r * 4) % 32;
  
  SYNTHETIC_RATES.push({
    id: `RATE-${(r + 6).toString().padStart(3, '0')}`,
    origin: city,
    port: port,
    destination: dest,
    mode: r % 4 === 0 ? 'Rail + Sea' : 'Road + Sea',
    containerType: container,
    indicativePriceGBP: price,
    transitDays: trans,
    validityDate: '2026-12-31'
  });
}

// 8. 500+ Synthetic shipment records (Looked up by reference codes)
// To keep memory optimal, we write a generator that takes a shipment code and constructs
// a deterministically valid shipment record, so that ANY code can be looked up or we have
// a list of popular predefined codes that match exactly.
export interface ShipmentRecord {
  reference: string;
  customerName: string;
  origin: string;
  destination: string;
  containerNo: string; // e.g. MEDU-482103-9
  containerType: string;
  vesselName: string;
  voyage: string;
  imoNo: string;
  cargoType: string;
  weightKg: number;
  status: 'BOOKED' | 'COLLECTED' | 'AT_DEPOT' | 'GATE_IN' | 'LOADED' | 'IN_TRANSIT' | 'ARRIVED' | 'CUSTOMS' | 'RELEASED' | 'DELIVERING' | 'DELIVERED';
  timeline: { status: string; label: string; date: string; location: string; done: boolean }[];
  eta: string;
  totalCostGBP: number;
  routeLegs: { mode: string; from: string; to: string; distanceKm: number }[];
}

export function generateShipment(reference: string): ShipmentRecord {
  // Extract number from MED-2026-XXXXXX or return a default
  const numMatch = reference.match(/\d+/);
  const seed = numMatch ? parseInt(numMatch[0]) : 4821;

  // Deterministic values based on seed
  const custName = ['Apex Global Trading', 'Kent Agriculture Ltd', 'Vanguard Retail UK', 'Medway Timber Imports', 'London Electro Corp', 'British Trade Partners'][seed % 6];
  const origins = ['Manchester, UK', 'Birmingham, UK', 'Rochester, Kent', 'Leeds, UK', 'Glasgow, Scotland', 'London Gateway Terminal'];
  const dests = ['Rotterdam, Netherlands', 'Shanghai, China', 'New York, USA', 'Singapore Terminal', 'Dubai Jebel Ali', 'Santos, Brazil'];
  
  const selectedOrigin = origins[seed % origins.length];
  const selectedDest = dests[(seed + 2) % dests.length];
  
  const containerType = CONTAINER_TYPES[seed % CONTAINER_TYPES.length];
  const cargoTypes = ['General Consumer Goods', 'Machinery Spares', 'Agricultural Produce (Cold)', 'Timber Products', 'Electronics', 'Chemicals (Non-Hazardous)'];
  const selectedCargo = cargoTypes[seed % cargoTypes.length];
  
  const vessel = VESSELS[seed % VESSELS.length];
  
  const weight = 4500 + (seed * 113) % 20000;
  const cost = 1200 + (seed * 87) % 6000;

  // Status mapping
  const statuses: ShipmentRecord['status'][] = [
    'BOOKED', 'COLLECTED', 'AT_DEPOT', 'GATE_IN', 'LOADED', 
    'IN_TRANSIT', 'ARRIVED', 'CUSTOMS', 'RELEASED', 'DELIVERING', 'DELIVERED'
  ];
  const currentStatus = statuses[seed % statuses.length];
  const statusIndex = statuses.indexOf(currentStatus);

  // Generate historical timeline dates backwards from Oct 2, 2026
  const timelineEvents = [
    { key: 'BOOKED', label: 'Booking Confirmed', location: 'Medway Office, Rochester' },
    { key: 'COLLECTED', label: 'Container Collected', location: selectedOrigin },
    { key: 'AT_DEPOT', label: 'Arrived at Medway Depot', location: 'Chatham Wharf, Kent' },
    { key: 'GATE_IN', label: 'Gated-In at Port Terminal', location: 'London Gateway' },
    { key: 'LOADED', label: 'Loaded Onboard Vessel', location: vessel.name },
    { key: 'IN_TRANSIT', label: 'Vessel Departed (At Sea)', location: 'Thames Estuary' },
    { key: 'ARRIVED', label: 'Vessel Arrived at Destination Port', location: selectedDest.split(',')[0] },
    { key: 'CUSTOMS', label: 'Customs Clearance Process', location: selectedDest.split(',')[0] },
    { key: 'RELEASED', label: 'Customs Released & Gated Out', location: selectedDest.split(',')[0] },
    { key: 'DELIVERING', label: 'Out for Final Inland Delivery', location: selectedDest },
    { key: 'DELIVERED', label: 'Delivered to Final Consignee', location: selectedDest }
  ];

  const timeline = timelineEvents.map((evt, idx) => {
    const isDone = idx <= statusIndex;
    const daysOffset = statusIndex - idx;
    const dateObj = new Date(2026, 9, 2); // Local Oct 2, 2026
    dateObj.setDate(dateObj.getDate() - daysOffset);
    return {
      status: evt.key,
      label: evt.label,
      date: isDone ? dateObj.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—',
      location: evt.location,
      done: isDone
    };
  });

  const containerLetter = ['MEDU', 'KNTU', 'ESTU', 'TMXU'][seed % 4];
  const containerNo = `${containerLetter}-${(100000 + seed * 19) % 999999}-${seed % 9}`;

  const etaDate = new Date(2026, 9, 2 + (seed % 12));

  return {
    reference: reference.toUpperCase(),
    customerName: custName,
    origin: selectedOrigin,
    destination: selectedDest,
    containerNo: containerNo,
    containerType: containerType.name,
    vesselName: vessel.name,
    voyage: vessel.voyage,
    imoNo: vessel.imo,
    cargoType: selectedCargo,
    weightKg: weight,
    status: currentStatus,
    timeline: timeline,
    eta: etaDate.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
    totalCostGBP: cost,
    routeLegs: [
      { mode: 'Road Haulage', from: selectedOrigin, to: 'Chatham Terminal, Kent', distanceKm: 85 },
      { mode: 'Ocean Freight', from: 'London Gateway', to: selectedDest.split(',')[0], distanceKm: seed % 2 === 0 ? 450 : 12400 },
      { mode: 'Destination Haulage', from: selectedDest.split(',')[0], to: selectedDest, distanceKm: 42 }
    ]
  };
}

// 9. Pricing Engine calculation model
export interface QuoteRequest {
  originCountry: string;
  originCity: string;
  originPostcode: string;
  pickupDate: string;
  destCountry: string;
  destPort: string;
  destCity: string;
  destPostcode: string;
  containerCode: string;
  cargoType: string;
  cargoWeightKg: number;
  cargoVolumeCbm: number;
  commodity: string;
  isHazardous: boolean;
  isTempControlled: boolean;
  serviceType: 'door-door' | 'door-port' | 'port-door' | 'port-port';
  transportMode: 'road-sea' | 'rail-sea' | 'road-rail-sea' | 'road-only' | 'rail-only';
}

export interface QuoteOutput {
  reference: string;
  origin: string;
  destination: string;
  containerName: string;
  cargoDescription: string;
  estimatedTransitDays: number;
  baseOceanFreight: number;
  ukCollectionCost: number;
  portHandlingCost: number;
  destinationHandlingCost: number;
  finalDeliveryCost: number;
  documentationCost: number;
  customsCost: number;
  surcharges: number;
  co2EmissionsKg: number;
  totalCostGBP: number;
  validityDate: string;
  routeLegs: { from: string; to: string; mode: string; transit: string }[];
}

export function calculateIndicativeRate(req: QuoteRequest): QuoteOutput {
  // Base distances calculation (deterministic approximation)
  const isUKOrigin = req.originCountry.toLowerCase().includes('united kingdom') || req.originCountry.toLowerCase() === 'uk';
  const isUKDest = req.destCountry.toLowerCase().includes('united kingdom') || req.destCountry.toLowerCase() === 'uk';

  // 1. UK Inland Haulage
  let collectionCost = 0;
  if (req.serviceType.startsWith('door')) {
    const isKent = req.originCity.toLowerCase().includes('kent') || req.originPostcode.toUpperCase().startsWith('ME') || req.originPostcode.toUpperCase().startsWith('DA') || req.originPostcode.toUpperCase().startsWith('TN') || req.originPostcode.toUpperCase().startsWith('CT');
    collectionCost = isKent ? 180 : 420;
    if (req.transportMode.includes('rail')) {
      collectionCost -= 45; // Rail efficiency discount
    }
  }

  // 2. Port and Terminal Handling (THC)
  const portHandling = 285;
  const destinationHandling = 310;

  // 3. Base Ocean Freight
  const container = CONTAINER_TYPES.find(c => c.code === req.containerCode) || CONTAINER_TYPES[2]; // Default to 40HC
  const baseRate = isUKOrigin && isUKDest ? 350 : 1200; // Inter-UK is short sea or road only, global is 1200 base
  let oceanFreight = baseRate * container.baseMultiplier;

  // Global distance factor based on destination port region
  const matchedPort = PORTS.find(p => p.name.toLowerCase() === req.destPort.toLowerCase() || p.code === req.destPort);
  if (matchedPort) {
    if (matchedPort.region === 'ASIA') {
      oceanFreight += 1800;
    } else if (matchedPort.region === 'NORTH AMERICA') {
      oceanFreight += 1450;
    } else if (matchedPort.region === 'MIDDLE EAST') {
      oceanFreight += 1100;
    } else if (matchedPort.region === 'SOUTH AMERICA') {
      oceanFreight += 1600;
    } else if (matchedPort.region === 'AFRICA') {
      oceanFreight += 1500;
    } else if (matchedPort.region === 'OCEANIA') {
      oceanFreight += 2400;
    } else {
      oceanFreight += 250; // Europe
    }
  } else {
    // Fallback based on text match
    if (req.destCountry.toLowerCase().includes('china') || req.destCountry.toLowerCase().includes('singapore') || req.destCountry.toLowerCase().includes('shanghai')) {
      oceanFreight += 1800;
    } else if (req.destCountry.toLowerCase().includes('usa') || req.destCountry.toLowerCase().includes('states') || req.destCountry.toLowerCase().includes('york')) {
      oceanFreight += 1450;
    } else {
      oceanFreight += 400;
    }
  }

  // 4. Final Delivery Cost
  let finalDelivery = 0;
  if (req.serviceType.endsWith('door')) {
    finalDelivery = 575;
  }

  // 5. Documentation and Customs Clearance
  const documentation = 85;
  const customs = req.isHazardous ? 180 : 115;

  // 6. Surcharges
  let fuelSurcharge = 115 * container.baseMultiplier;
  if (req.isTempControlled) {
    fuelSurcharge += 350; // Reefer active cooling power fuel cost
  }
  const securitySurcharge = 45;
  const surcharges = fuelSurcharge + securitySurcharge;

  // 7. Weight multiplier
  let weightFactor = 1.0;
  if (req.cargoWeightKg > 20000) {
    weightFactor = 1.12; // Heavy load premium
  }

  // Apply adjustments
  const totalRaw = (oceanFreight + collectionCost + portHandling + destinationHandling + finalDelivery + documentation + customs + surcharges) * weightFactor;
  const totalCostGBP = Math.round(totalRaw);

  // Transit days calculation
  let transitDays = 3;
  if (matchedPort) {
    if (matchedPort.region === 'ASIA') transitDays = 28;
    else if (matchedPort.region === 'NORTH AMERICA') transitDays = 12;
    else if (matchedPort.region === 'MIDDLE EAST') transitDays = 18;
    else if (matchedPort.region === 'SOUTH AMERICA') transitDays = 22;
    else if (matchedPort.region === 'AFRICA') transitDays = 24;
    else if (matchedPort.region === 'OCEANIA') transitDays = 36;
    else transitDays = 4; // Europe
  }

  // Route Legs calculation
  const routeLegs = [
    { from: `${req.originCity || 'Warehouse'}, UK`, to: 'London Gateway Port', mode: req.transportMode.includes('rail') ? 'Freight Rail' : 'Heavy Haulage Truck', transit: '1 day' },
    { from: 'London Gateway Port', to: matchedPort ? matchedPort.name : req.destPort || 'Rotterdam Port', mode: 'Ocean Freight Vessel', transit: `${transitDays - 2} days` },
    { from: matchedPort ? matchedPort.name : req.destPort || 'Rotterdam Port', to: `${req.destCity || 'Final Consignee'}, ${req.destCountry}`, mode: 'Local Container Chassis', transit: '1 day' }
  ];

  // Estimated CO2 emissions in kg
  const seaDist = transitDays * 600; // rough sea km
  const roadDist = 150;
  // CO2 per km: Truck = 0.9kg/km, Rail = 0.2kg/km, Sea = 0.05kg/km per container
  const co2EmissionsKg = Math.round((roadDist * 0.9) + (seaDist * 0.05) + (req.transportMode.includes('rail') ? 100 * 0.2 : 100 * 0.9));

  // Generate deterministic quote reference
  const hash = Math.abs(req.originCity.charCodeAt(0) + req.destCity.charCodeAt(0) + req.containerCode.charCodeAt(0) + req.cargoWeightKg);
  const quoteRef = `MED-Q-2026-${(100000 + (hash % 899999))}`;

  return {
    reference: quoteRef,
    origin: `${req.originCity}, ${req.originCountry}`,
    destination: `${req.destCity}, ${req.destCountry}`,
    containerName: container.name,
    cargoDescription: `${req.commodity || req.cargoType} (${req.cargoWeightKg}kg, ${req.cargoVolumeCbm}m³)`,
    estimatedTransitDays: transitDays,
    baseOceanFreight: Math.round(oceanFreight),
    ukCollectionCost: Math.round(collectionCost),
    portHandlingCost: portHandling,
    destinationHandlingCost: destinationHandling,
    finalDeliveryCost: Math.round(finalDelivery),
    documentationCost: documentation,
    customsCost: customs,
    surcharges: Math.round(surcharges),
    co2EmissionsKg: co2EmissionsKg,
    totalCostGBP: totalCostGBP,
    validityDate: new Date(2026, 11, 31).toLocaleDateString('en-GB'),
    routeLegs: routeLegs
  };
}
