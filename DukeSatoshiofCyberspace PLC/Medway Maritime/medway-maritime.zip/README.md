# MEDWAY MARITIME FREIGHT PLATFORM & PRICE ENGINE

**Kent-based maritime shipping agency, intermodal freight platform, and container logistics pricing engine.**

> **MOVE GOODS. MOVE BUSINESS.**  
> *From warehouse to port. From port to world.*

---

## 1. APPLICATION ARCHITECTURE & FEATURES

Medway Maritime sits at the intersection of a traditional maritime shipping agency, intermodal carrier operator, and a late-2020s digital freight platform. 

This application implements a complete full-stack experience with the following structural components:

### 🚢 CONTAINER PRICE ENGINE
- **Volumetric Multi-Step Quotation System**: Form guides operators through setting Origin Geography (UK Hubs/Postcodes), Global Destinations (over 105 indexed ports), Container specification selection, Cargo parameters, and Intermodal service lines (e.g. Road+Sea, Rail+Sea, Multi-leg Intermodal).
- **Indicative Price Calculation Engine**: Pricing accounts for base ocean freight legs, drayage distances, fuel surcharges (including temperature active power reefers), terminal handling charges (THC), security levies, documentation fees, and cargo weight multipliers.

### 📍 GEOGRAPHIC UK PORT & ROAD HAULAGE NETWORK
- **Interactive Vector UK Port Plotter**: Clean vector SVG mapping plots key gateways (London Gateway, London Thamesport, Felixstowe, Southampton, Liverpool, Teesport, etc.). Selecting nodes accesses active terminal depth profiles and rail connected yard statuses.
- **Inland Drayage Estimator**: Enter a UK postcode, container size, and discharge gateway to calculate approximate drayage mileages and road hauling tariffs.

### 📦 CONTAINER PACKING CALCULATOR
- **How Much Fits Volumetric Simulator**: Enter pallet weights, dimensions, and total quantities. The calculator determines volume utilization percentages against certified container cargo limit parameters (including standard GP, High Cube, Reefers, and Flat Rack specifications).

### 🌍 GLOBAL TRADE DIRECTORY & GATEWAY COMPARATORS
- **Browsable Tariff Indexes**: Audit over 100 programmed rates across trade lanes. Filter by region (Europe, North America, Asia, Middle East, etc.).
- **UK Export Gateway Comparator**: Input a cargo profile and evaluate multiple active UK gateways side-by-side (e.g., London Gateway vs Southampton vs Felixstowe) across prices, transit speeds, and environmental CO₂ emissions.

### 📊 OPERATIONAL SHIPMENT TRACKER & LIVE VECTOR MAP
- **Multi-Leg Cargo Tracker**: Check shipment reference codes (e.g., `MED-2026-004821`) to retrieve detailed multi-leg progress tracking data.
- **Interactive Positioning Map**: Visually represents real-world ocean trade lanes and presents an animated pulsing drayage vessel location with speed telemetry.
- **Operational Timeline Milestones**: Step-by-step handover states from origin collection down to final destination gate discharge.

### 💼 CUSTOMER PORTAL & ADMIN OVERRIDES CONSOLE
- **Active Bookings Registry**: Simulate bookings from the quote engine and manage them directly.
- **Digital Document Centre**: Review or print pro-forma bills of lading (Sea Waybill), commercial invoices, and booking receipts carrying a "SAMPLE / DEMONSTRATION" watermark.
- **Rate Watch Watchlists**: Track corridor pricing shifts with custom visual change notifications.
- **Surcharge Tuning Controls**: Administrative override panel allows tuning global fuel multipliers, security levies, and OOG equipment premiums in real-time.
- **Diagnostic Audit Events Journal**: Real-time logging monitors operator dockets, logins, and database parameters.

---

## 2. DESIGN & ACCESSIBILITY DIRECTIVES

- **Late-2020s British Maritime Aesthetic**: The visual interface strictly follows the domain constitution with high contrast deep navy, off-white background canvases, and industrial signal orange primary action points.
- **Typography Pairing**: Features clean industrial sans-grotesk paired with cleanmonospace tabular numerals for tables, tariffs, vessel IMO codes, and shipment reference numbers.
- **Zero-Pill Discipline**: High quality information styling utilizing typographic dot separators and unboxed metadata structures to prevent clutter.
- **WCAG Compliant**: High accessibility contrast profiles, visible focus indicators, screen reader landmarks, and clean responsive layouts for mobile and desktop viewports.

---

## 3. HOW TO RUN THE SYSTEM

1. **Install Applet Dependencies**:
   ```bash
   npm install
   ```

2. **Execute Development Environment**:
   ```bash
   npm run dev
   ```
   *The server initializes at port 3000.*

3. **Production Standalone Compilation**:
   ```bash
   npm run build
   ```

---

## 4. DESIGN DISCLAIMER

*All freight quotations, vessel positions, drayage mileage, transit speed windows, and compliance tariffs displayed by this software represent synthetic, simulated values for demonstrative operations only. No contractual agreements or active commercial bookings are connoted.*
