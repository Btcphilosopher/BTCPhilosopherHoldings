package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Medway Maritime Brand Colors
val MedwayNavyPrimary = Color(0xFF0A2540)
val MedwayNavyLight = Color(0xFF1E3A8A)
val MedwayCyan = Color(0xFF0284C7)
val MedwayCyanContainer = Color(0xFFE0F2FE)
val MedwayGold = Color(0xFFD97706)
val MedwayGoldContainer = Color(0xFFFEF3C7)

val MedwaySuccess = Color(0xFF10B981)
val MedwaySuccessContainer = Color(0xFFD1FAE5)
val MedwayError = Color(0xFFEF4444)
val MedwayWarning = Color(0xFFF59E0B)

val MedwayDarkBackground = Color(0xFF0B1120)
val MedwayDarkSurface = Color(0xFF151D30)
val MedwayDarkSurfaceVariant = Color(0xFF1E293B)

val MedwayLightBackground = Color(0xFFF8FAFC)
val MedwayLightSurface = Color(0xFFFFFFFF)
val MedwayLightSurfaceVariant = Color(0xFFF1F5F9)

val StrikeRateBadgeBg = Color(0xFFEDE9FE)
val StrikeRateBadgeText = Color(0xFF6D28D9)

val SpotRateBadgeBg = Color(0xFFE0F2FE)
val SpotRateBadgeText = Color(0xFF0369A1)
