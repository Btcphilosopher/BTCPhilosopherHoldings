package com.example.medway.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.medway.data.model.CargoType
import com.example.medway.data.model.ContainerType
import com.example.medway.data.model.ServiceType
import com.example.medway.engine.FXEngine
import com.example.medway.ui.MedwayViewModel
import com.example.medway.ui.components.QuoteCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuoteCalculatorScreen(viewModel: MedwayViewModel) {
    val currentQuote by viewModel.currentQuote.collectAsState()
    val multiOptions by viewModel.multiQuoteOptions.collectAsState()
    val isCalculating by viewModel.isCalculating.collectAsState()
    val userRole by viewModel.userRole.collectAsState()

    val origCountry by viewModel.originCountry.collectAsState()
    val origPostcode by viewModel.originPostcode.collectAsState()
    val destCountry by viewModel.destCountry.collectAsState()
    val destPostcode by viewModel.destPostcode.collectAsState()
    val selContainer by viewModel.containerType.collectAsState()
    val selCargo by viewModel.cargoType.collectAsState()
    val selService by viewModel.serviceType.collectAsState()

    val countries = listOf(
        "GB" to "United Kingdom (Kent Gateway)",
        "NL" to "Netherlands (Rotterdam)",
        "DE" to "Germany (Hamburg)",
        "BE" to "Belgium (Antwerp)",
        "CN" to "China (Shanghai)",
        "US" to "United States (New York)",
        "SG" to "Singapore Gateway"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Image Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.medway_hero_banner_1790958687195),
                        contentDescription = "Medway Container Terminal",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.55f))
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.secondary
                        ) {
                            Text(
                                text = "MEDWAY PRICING ENGINE v2026",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Instant Executable Container Quotes",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Text(
                            text = "Spot Market Rates • Strike Contracts • Transparent Line Items",
                            color = Color.LightGray,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Quoting Form Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("quote_calculator_form"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "1. ORIGIN & DESTINATION CORRIDOR",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Origin Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        var origExpanded by remember { mutableStateOf(false) }

                        ExposedDropdownMenuBox(
                            expanded = origExpanded,
                            onExpandedChange = { origExpanded = !origExpanded },
                            modifier = Modifier.weight(1.2f)
                        ) {
                            OutlinedTextField(
                                value = origCountry,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Origin Country") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = origExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .testTag("origin_country_dropdown")
                            )

                            ExposedDropdownMenu(
                                expanded = origExpanded,
                                onDismissRequest = { origExpanded = false }
                            ) {
                                countries.forEach { (code, name) ->
                                    DropdownMenuItem(
                                        text = { Text("$code - $name") },
                                        onClick = {
                                            viewModel.originCountry.value = code
                                            origExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = origPostcode,
                            onValueChange = { viewModel.originPostcode.value = it },
                            label = { Text("Postcode") },
                            modifier = Modifier
                                .weight(0.8f)
                                .testTag("origin_postcode_input")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Destination Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        var destExpanded by remember { mutableStateOf(false) }

                        ExposedDropdownMenuBox(
                            expanded = destExpanded,
                            onExpandedChange = { destExpanded = !destExpanded },
                            modifier = Modifier.weight(1.2f)
                        ) {
                            OutlinedTextField(
                                value = destCountry,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Dest. Country") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = destExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .testTag("dest_country_dropdown")
                            )

                            ExposedDropdownMenu(
                                expanded = destExpanded,
                                onDismissRequest = { destExpanded = false }
                            ) {
                                countries.forEach { (code, name) ->
                                    DropdownMenuItem(
                                        text = { Text("$code - $name") },
                                        onClick = {
                                            viewModel.destCountry.value = code
                                            destExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = destPostcode,
                            onValueChange = { viewModel.destPostcode.value = it },
                            label = { Text("Postcode") },
                            modifier = Modifier
                                .weight(0.8f)
                                .testTag("dest_postcode_input")
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "2. CONTAINER TYPE & CARGO SPECIFICATION",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Container Type Chips Row
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(ContainerType.entries) { type ->
                            val isSelected = type == selContainer
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clickable { viewModel.containerType.value = type }
                                    .testTag("container_type_chip_${type.code}")
                            ) {
                                Text(
                                    text = type.displayName,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Cargo Type & Service Type Selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        var cargoExpanded by remember { mutableStateOf(false) }

                        ExposedDropdownMenuBox(
                            expanded = cargoExpanded,
                            onExpandedChange = { cargoExpanded = !cargoExpanded },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = selCargo.label.take(18),
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Cargo Type") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = cargoExpanded) },
                                modifier = Modifier.menuAnchor()
                            )

                            ExposedDropdownMenu(
                                expanded = cargoExpanded,
                                onDismissRequest = { cargoExpanded = false }
                            ) {
                                CargoType.entries.forEach { cargo ->
                                    DropdownMenuItem(
                                        text = { Text(cargo.label) },
                                        onClick = {
                                            viewModel.cargoType.value = cargo
                                            cargoExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        var serviceExpanded by remember { mutableStateOf(false) }

                        ExposedDropdownMenuBox(
                            expanded = serviceExpanded,
                            onExpandedChange = { serviceExpanded = !serviceExpanded },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = selService.label,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Service Type") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = serviceExpanded) },
                                modifier = Modifier.menuAnchor()
                            )

                            ExposedDropdownMenu(
                                expanded = serviceExpanded,
                                onDismissRequest = { serviceExpanded = false }
                            ) {
                                ServiceType.entries.forEach { srv ->
                                    DropdownMenuItem(
                                        text = { Text(srv.label) },
                                        onClick = {
                                            viewModel.serviceType.value = srv
                                            serviceExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Action Buttons Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.calculateQuote() },
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("calculate_quote_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Calculate,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("GET QUOTE", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { viewModel.compareOptions() },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("compare_options_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Compare,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("COMPARE", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Loading State
        if (isCalculating) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Querying Spot Market & Contract Strike Rates...",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Single Quote Result
        if (currentQuote != null && multiOptions.isEmpty() && !isCalculating) {
            item {
                QuoteCard(
                    quote = currentQuote!!,
                    userRole = userRole,
                    onAcceptQuote = { id -> viewModel.acceptQuote(id) }
                )
            }
        }

        // Multi-Option Comparison View
        if (multiOptions.isNotEmpty() && !isCalculating) {
            item {
                Text(
                    text = "MULTI-OPTION ROUTE COMPARISON (POST /api/v1/quotes/compare)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            items(multiOptions) { option ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = option.optionName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = FXEngine.format(option.totalAmount, option.currency),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }

                        Text(
                            text = option.description,
                            fontSize = 11.sp,
                            color = Color.Gray
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Route: ${option.routeSummary}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${option.transitDays} Days Transit",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = { viewModel.acceptQuote(option.quoteResponse.quoteId) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("SELECT & BOOK THIS OPTION", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
