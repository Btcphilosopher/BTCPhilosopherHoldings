package com.example.medway.engine

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class MarketConditionState(
    val bafFuelIndex: Double = 112.0,      // Base 100.0, current 112.0
    val lowSulfurSurchargeGbp: Double = 95.0,
    val portCongestionMultiplier: Double = 1.0,
    val demandMultiplier: Double = 1.0,
    val activeRateBookVersion: String = "RATEBOOK-2026-10-02-001"
)

object SpotMarketSimulator {
    private val _marketState = MutableStateFlow(MarketConditionState())
    val marketState: StateFlow<MarketConditionState> = _marketState.asStateFlow()

    fun updateFuelIndex(newIndex: Double) {
        _marketState.value = _marketState.value.copy(
            bafFuelIndex = newIndex,
            lowSulfurSurchargeGbp = 95.0 * (newIndex / 100.0)
        )
    }

    fun updateCongestion(multiplier: Double) {
        _marketState.value = _marketState.value.copy(portCongestionMultiplier = multiplier)
    }

    fun updateDemandFactor(factor: Double) {
        _marketState.value = _marketState.value.copy(demandMultiplier = factor)
    }

    fun resetToDefault() {
        _marketState.value = MarketConditionState()
    }
}
