package com.example.medway.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Http
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.medway.ui.MedwayViewModel
import com.google.gson.GsonBuilder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiExplorerScreen(viewModel: MedwayViewModel) {
    val apiKey by viewModel.apiKey.collectAsState()
    val gson = remember { GsonBuilder().setPrettyPrinting().create() }

    var selectedEndpoint by remember { mutableStateOf("POST /api/v1/quotes") }
    var sdkTab by remember { mutableStateOf(0) } // 0: Curl, 1: Python SDK, 2: TypeScript SDK

    val endpoints = listOf(
        "POST /api/v1/quotes",
        "POST /api/v1/quotes/compare",
        "POST /api/v1/rfqs",
        "POST /api/v1/quotes/{id}/accept",
        "GET /api/v1/contracts",
        "GET /api/v1/shipments/{id}"
    )

    var jsonBody by remember {
        mutableStateOf(
            "{\n" +
                    "  \"origin\": {\n" +
                    "    \"country\": \"GB\",\n" +
                    "    \"postcode\": \"ME1 1AA\"\n" +
                    "  },\n" +
                    "  \"destination\": {\n" +
                    "    \"country\": \"NL\",\n" +
                    "    \"postcode\": \"3011AA\"\n" +
                    "  },\n" +
                    "  \"container\": {\n" +
                    "    \"type\": \"40HC\",\n" +
                    "    \"quantity\": 1\n" +
                    "  },\n" +
                    "  \"cargo\": {\n" +
                    "    \"type\": \"GENERAL\",\n" +
                    "    \"weight_kg\": 18500\n" +
                    "  },\n" +
                    "  \"service\": \"DOOR_TO_DOOR\",\n" +
                    "  \"incoterm\": \"DAP\",\n" +
                    "  \"pickup_date\": \"2026-10-20\",\n" +
                    "  \"currency\": \"GBP\"\n" +
                    "}"
        )
    }

    var jsonResponse by remember {
        mutableStateOf(
            "{\n" +
                    "  \"quote_id\": \"MWQ-20261002-000184\",\n" +
                    "  \"pricing_mode\": \"SPOT\",\n" +
                    "  \"rate_book_id\": \"RATEBOOK-2026-10-02-001\",\n" +
                    "  \"currency\": \"GBP\",\n" +
                    "  \"total\": 2480.00,\n" +
                    "  \"valid_until\": \"2026-10-03T23:59:59Z\",\n" +
                    "  \"route\": {\n" +
                    "    \"transit_days\": 4,\n" +
                    "    \"corridor\": \"Kent Port -> Rotterdam RWG\"\n" +
                    "  },\n" +
                    "  \"charges\": [\n" +
                    "    { \"code\": \"ORIG_HAUL\", \"amount\": 420.00 },\n" +
                    "    { \"code\": \"ORIG_THC\", \"amount\": 285.00 },\n" +
                    "    { \"code\": \"OCEAN_BASE\", \"amount\": 690.00 },\n" +
                    "    { \"code\": \"SUR_BAF\", \"amount\": 95.00 },\n" +
                    "    { \"code\": \"DEST_THC\", \"amount\": 310.00 },\n" +
                    "    { \"code\": \"DEST_HAUL\", \"amount\": 575.00 }\n" +
                    "  ]\n" +
                    "}"
        )
    }

    val pythonSdkSnippet = """
        from medway import MedwayClient

        client = MedwayClient(api_key="$apiKey")

        quote = client.quotes.create(
            origin={"country": "GB", "postcode": "ME1 1AA"},
            destination={"country": "NL", "postcode": "3011AA"},
            container={"type": "40HC", "quantity": 1},
            service="DOOR_TO_DOOR",
            currency="GBP"
        )

        print(f"Quote ID: {quote.id}, Total: {quote.currency} {quote.total}")
    """.trimIndent()

    val tsSdkSnippet = """
        import { MedwayClient } from '@medway/maritime-sdk';

        const medway = new MedwayClient({ apiKey: '$apiKey' });

        const quote = await medway.quotes.create({
          origin: { country: 'GB', postcode: 'ME1 1AA' },
          destination: { country: 'NL', postcode: '3011AA' },
          container: { type: '40HC', quantity: 1 },
          service: 'DOOR_TO_DOOR',
          currency: 'GBP'
        });

        console.log("Executable Quote: " + quote.total + " " + quote.currency);
    """.trimIndent()

    val curlSnippet = """
        curl -X POST https://api.medwaymaritime.co.uk/v1/quotes \
          -H "Authorization: Bearer $apiKey" \
          -H "Content-Type: application/json" \
          -H "Idempotency-Key: IDEM-${(100000..999999).random()}" \
          -d '$jsonBody'
    """.trimIndent()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "INTERACTIVE API CONSOLE & SDK EXPLORER",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Execute live HTTP quote API endpoints and generate typed SDK code",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Endpoint Selector Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        var expanded by remember { mutableStateOf(false) }

                        ExposedDropdownMenuBox(
                            expanded = expanded,
                            onExpandedChange = { expanded = !expanded },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = selectedEndpoint,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("HTTP Endpoint") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .testTag("api_endpoint_dropdown")
                            )

                            ExposedDropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false }
                            ) {
                                endpoints.forEach { ep ->
                                    DropdownMenuItem(
                                        text = { Text(ep) },
                                        onClick = {
                                            selectedEndpoint = ep
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                val current = viewModel.currentQuote.value
                                if (current != null) {
                                    jsonResponse = gson.toJson(current)
                                }
                            },
                            modifier = Modifier.testTag("execute_api_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("RUN API", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "HEADERS: Authorization: Bearer $apiKey | Idempotency-Key: IDEM-882194",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "REQUEST JSON PAYLOAD",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    OutlinedTextField(
                        value = jsonBody,
                        onValueChange = { jsonBody = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "RESPONSE JSON PAYLOAD (HTTP 200 OK)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF10B981)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .background(Color(0xFF0F172A), shape = RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = jsonResponse,
                            color = Color(0xFF38BDF8),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        )
                    }
                }
            }
        }

        // SDK Code Snippets Generator
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "OFFICIAL SDK & CURL CODE GENERATOR",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    TabRow(selectedTabIndex = sdkTab) {
                        Tab(
                            selected = sdkTab == 0,
                            onClick = { sdkTab = 0 },
                            text = { Text("cURL", fontSize = 12.sp) }
                        )
                        Tab(
                            selected = sdkTab == 1,
                            onClick = { sdkTab = 1 },
                            text = { Text("Python SDK", fontSize = 12.sp) }
                        )
                        Tab(
                            selected = sdkTab == 2,
                            onClick = { sdkTab = 2 },
                            text = { Text("TypeScript SDK", fontSize = 12.sp) }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val codeText = when (sdkTab) {
                        0 -> curlSnippet
                        1 -> pythonSdkSnippet
                        else -> tsSdkSnippet
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                            .background(Color(0xFF090D16), shape = RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = codeText,
                            color = Color(0xFFF1F5F9),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
