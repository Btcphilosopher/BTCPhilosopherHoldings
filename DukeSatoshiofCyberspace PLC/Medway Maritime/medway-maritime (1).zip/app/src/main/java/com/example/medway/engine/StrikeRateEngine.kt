package com.example.medway.engine

import com.example.medway.data.model.Contract
import com.example.medway.data.model.QuoteRequest

object StrikeRateEngine {

    fun findApplicableContract(request: QuoteRequest, availableContracts: List<Contract>): Contract? {
        val origCountry = request.origin.country.uppercase()
        val destCountry = request.destination.country.uppercase()
        val cType = request.containerType

        return availableContracts.firstOrNull { contract ->
            contract.status.equals("ACTIVE", ignoreCase = true) &&
                    (contract.customerId == request.customerId || contract.customerId == "ALL_KEY_ACCOUNTS") &&
                    contract.originCountry.equals(origCountry, ignoreCase = true) &&
                    contract.destinationCountry.equals(destCountry, ignoreCase = true) &&
                    (contract.containerType == cType || contract.containerType == request.containerType) &&
                    contract.volumeUsedTeu < contract.volumeCommitmentTeu
        }
    }
}
