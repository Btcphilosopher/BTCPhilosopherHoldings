package com.example.medway.engine

import com.example.medway.data.model.Currency

object FXEngine {
    // Base currency is GBP (1.0)
    private val ratesToGbp = mapOf(
        Currency.GBP to 1.0,
        Currency.EUR to 0.85,
        Currency.USD to 0.77,
        Currency.CNY to 0.11,
        Currency.JPY to 0.0053,
        Currency.AED to 0.21,
        Currency.SGD to 0.58,
        Currency.CAD to 0.56,
        Currency.AUD to 0.51
    )

    fun convert(amount: Double, fromCurrency: Currency, toCurrency: Currency): Double {
        if (fromCurrency == toCurrency) return amount
        val amountInGbp = amount * (ratesToGbp[fromCurrency] ?: 1.0)
        val rateTo = ratesToGbp[toCurrency] ?: 1.0
        return amountInGbp / rateTo
    }

    fun format(amount: Double, currency: Currency): String {
        return "${currency.symbol}${String.format("%.2f", amount)}"
    }

    fun getRatesMap(): Map<Currency, Double> = ratesToGbp
}
