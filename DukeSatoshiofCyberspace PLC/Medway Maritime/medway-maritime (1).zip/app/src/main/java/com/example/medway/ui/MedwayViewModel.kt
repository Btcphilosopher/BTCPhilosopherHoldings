package com.example.medway.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.medway.data.local.MedwayDatabase
import com.example.medway.data.model.AuditLog
import com.example.medway.data.model.CargoType
import com.example.medway.data.model.ContainerType
import com.example.medway.data.model.Contract
import com.example.medway.data.model.Currency
import com.example.medway.data.model.Incoterm
import com.example.medway.data.model.Location
import com.example.medway.data.model.MultiQuoteOption
import com.example.medway.data.model.QuoteRequest
import com.example.medway.data.model.QuoteResponse
import com.example.medway.data.model.RateBook
import com.example.medway.data.model.RfqItem
import com.example.medway.data.model.RfqResponse
import com.example.medway.data.model.ServiceType
import com.example.medway.data.model.Shipment
import com.example.medway.data.model.UserRole
import com.example.medway.data.repository.MedwayRepository
import com.example.medway.engine.MarketConditionState
import com.example.medway.engine.SpotMarketSimulator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MainTab(val title: String) {
    QUOTE_CALCULATOR("Instant Quote"),
    SPOT_VS_STRIKE("Contracts"),
    RATEBOOK_STUDIO("RateBook"),
    MARKET_SIMULATOR("Market Rates"),
    SHIPMENT_TRACKING("Shipments"),
    API_EXPLORER("API & SDKs")
}

class MedwayViewModel(application: Application) : AndroidViewModel(application) {
    private val database = MedwayDatabase.getDatabase(application)
    val repository = MedwayRepository(database.medwayDao())

    val userRole = MutableStateFlow(UserRole.FREIGHT_STAFF)
    val activeTab = MutableStateFlow(MainTab.QUOTE_CALCULATOR)
    val apiKey = MutableStateFlow("mw_live_kent8841")

    // Form State
    val originCountry = MutableStateFlow("GB")
    val originPostcode = MutableStateFlow("ME1 1AA")
    val destCountry = MutableStateFlow("NL")
    val destPostcode = MutableStateFlow("3011AA")
    val containerType = MutableStateFlow(ContainerType.C40HC)
    val containerQty = MutableStateFlow(1)
    val cargoType = MutableStateFlow(CargoType.GENERAL)
    val serviceType = MutableStateFlow(ServiceType.DOOR_TO_DOOR)
    val currency = MutableStateFlow(Currency.GBP)
    val customerId = MutableStateFlow("CUST-0184")

    val currentQuote = MutableStateFlow<QuoteResponse?>(null)
    val multiQuoteOptions = MutableStateFlow<List<MultiQuoteOption>>(emptyList())
    val isCalculating = MutableStateFlow(false)
    val toastMessage = MutableStateFlow<String?>(null)

    val contracts: StateFlow<List<Contract>> = repository.contractsFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val rateBooks: StateFlow<List<RateBook>> = repository.rateBooksFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val quotes: StateFlow<List<QuoteResponse>> = repository.quotesFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val shipments: StateFlow<List<Shipment>> = repository.bookingsFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val auditLogs: StateFlow<List<AuditLog>> = repository.auditLogsFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val rfqs: StateFlow<List<RfqResponse>> = repository.rfqsFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val marketState: StateFlow<MarketConditionState> = SpotMarketSimulator.marketState

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
            calculateQuote()
        }
    }

    fun calculateQuote() {
        viewModelScope.launch {
            isCalculating.value = true
            val request = QuoteRequest(
                origin = Location(originCountry.value, originPostcode.value),
                destination = Location(destCountry.value, destPostcode.value),
                containerType = containerType.value,
                containerQuantity = containerQty.value,
                cargoType = cargoType.value,
                serviceType = serviceType.value,
                currency = currency.value,
                customerId = customerId.value,
                apiKey = apiKey.value
            )
            val quote = repository.calculateQuote(request)
            currentQuote.value = quote
            multiQuoteOptions.value = emptyList()
            isCalculating.value = false
        }
    }

    fun compareOptions() {
        viewModelScope.launch {
            isCalculating.value = true
            val request = QuoteRequest(
                origin = Location(originCountry.value, originPostcode.value),
                destination = Location(destCountry.value, destPostcode.value),
                containerType = containerType.value,
                containerQuantity = containerQty.value,
                cargoType = cargoType.value,
                serviceType = serviceType.value,
                currency = currency.value,
                customerId = customerId.value,
                apiKey = apiKey.value
            )
            val options = repository.compareQuoteOptions(request)
            multiQuoteOptions.value = options
            isCalculating.value = false
        }
    }

    fun acceptQuote(quoteId: String) {
        viewModelScope.launch {
            val result = repository.acceptQuote(quoteId, customerId.value)
            if (result != null) {
                toastMessage.value = "Booking ${result.bookingId} created successfully!"
                calculateQuote()
            }
        }
    }

    fun createContract(contract: Contract) {
        viewModelScope.launch {
            repository.createContract(contract)
            toastMessage.value = "Contract ${contract.contractId} created and activated."
        }
    }

    fun publishRateBook(version: String, itemCount: Int) {
        viewModelScope.launch {
            repository.publishRateBook(version, itemCount)
            toastMessage.value = "RateBook $version published successfully!"
        }
    }

    fun submitRfq(items: List<RfqItem>) {
        viewModelScope.launch {
            val res = repository.submitRfq(customerId.value, items)
            toastMessage.value = "RFQ ${res.rfqId} submitted for pricing."
        }
    }

    fun updateFuelIndex(newIndex: Double) {
        SpotMarketSimulator.updateFuelIndex(newIndex)
        calculateQuote()
    }

    fun updateCongestion(multiplier: Double) {
        SpotMarketSimulator.updateCongestion(multiplier)
        calculateQuote()
    }

    fun clearToast() {
        toastMessage.value = null
    }
}
