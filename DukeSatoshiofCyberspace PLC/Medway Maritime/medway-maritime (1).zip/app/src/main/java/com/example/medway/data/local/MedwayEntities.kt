package com.example.medway.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "contracts")
data class ContractEntity(
    @PrimaryKey val contractId: String,
    val customerId: String,
    val customerName: String,
    val laneName: String,
    val originCountry: String,
    val destinationCountry: String,
    val containerType: String,
    val rateAmount: Double,
    val currency: String,
    val validFrom: String,
    val validUntil: String,
    val volumeCommitmentTeu: Int,
    val volumeUsedTeu: Int,
    val status: String
)

@Entity(tableName = "rate_books")
data class RateBookEntity(
    @PrimaryKey val rateBookId: String,
    val version: String,
    val status: String,
    val publishedAt: String,
    val itemCount: Int
)

@Entity(tableName = "quotes")
data class QuoteEntity(
    @PrimaryKey val quoteId: String,
    val pricingMode: String,
    val rateBookId: String,
    val currency: String,
    val totalAmount: Double,
    val validUntil: String,
    val originSummary: String,
    val destinationSummary: String,
    val containerType: String,
    val containerQty: Int,
    val cargoType: String,
    val serviceType: String,
    val chargesJson: String,
    val routeJson: String,
    val marginJson: String,
    val assumptionsJson: String,
    val warningsJson: String,
    val requiresManualReview: Boolean,
    val status: String = "ISSUED", // ISSUED, ACCEPTED, EXPIRED, CANCELLED
    val createdAt: String
)

@Entity(tableName = "bookings")
data class BookingEntity(
    @PrimaryKey val bookingId: String,
    val quoteId: String,
    val customerName: String,
    val containerNumber: String,
    val vesselName: String,
    val voyageNumber: String,
    val origin: String,
    val destination: String,
    val containerType: String,
    val currentStatus: String,
    val estimatedDelivery: String,
    val eventsJson: String,
    val bookedAt: String
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val timestamp: String,
    val actor: String,
    val organization: String,
    val apiKey: String,
    val action: String,
    val details: String
)

@Entity(tableName = "rfqs")
data class RfqEntity(
    @PrimaryKey val rfqId: String,
    val customerId: String,
    val status: String,
    val requestedAt: String,
    val itemsJson: String
)
