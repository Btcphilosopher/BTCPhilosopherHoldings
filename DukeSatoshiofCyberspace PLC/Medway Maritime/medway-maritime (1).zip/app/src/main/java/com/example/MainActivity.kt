package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.medway.ui.MainTab
import com.example.medway.ui.MedwayViewModel
import com.example.medway.ui.components.HeaderBar
import com.example.medway.ui.screens.ApiExplorerScreen
import com.example.medway.ui.screens.ContractManagerScreen
import com.example.medway.ui.screens.MarketSimulatorScreen
import com.example.medway.ui.screens.QuoteCalculatorScreen
import com.example.medway.ui.screens.RateBookStudioScreen
import com.example.medway.ui.screens.ShipmentTrackingScreen
import com.example.ui.theme.MedwayTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MedwayViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MedwayTheme {
                MedwayApp(viewModel)
            }
        }
    }
}

@Composable
fun MedwayApp(viewModel: MedwayViewModel) {
    val activeTab by viewModel.activeTab.collectAsState()
    val userRole by viewModel.userRole.collectAsState()
    val currency by viewModel.currency.collectAsState()
    val apiKey by viewModel.apiKey.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    BackHandler(enabled = activeTab != MainTab.QUOTE_CALCULATOR) {
        viewModel.activeTab.value = MainTab.QUOTE_CALCULATOR
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            HeaderBar(
                currentRole = userRole,
                onRoleSelected = { viewModel.userRole.value = it },
                currentCurrency = currency,
                onCurrencySelected = { viewModel.currency.value = it },
                apiKey = apiKey
            )
        },
        bottomBar = {
            ScrollableTabRow(
                selectedTabIndex = activeTab.ordinal,
                edgePadding = 8.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.testTag("main_tab_row")
            ) {
                MainTab.entries.forEach { tab ->
                    Tab(
                        selected = activeTab == tab,
                        onClick = { viewModel.activeTab.value = tab },
                        text = {
                            Text(
                                text = tab.title,
                                fontSize = 11.sp,
                                fontWeight = if (activeTab == tab) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        icon = {
                            Icon(
                                imageVector = when (tab) {
                                    MainTab.QUOTE_CALCULATOR -> Icons.Default.Calculate
                                    MainTab.SPOT_VS_STRIKE -> Icons.Default.Lock
                                    MainTab.RATEBOOK_STUDIO -> Icons.Default.LibraryBooks
                                    MainTab.MARKET_SIMULATOR -> Icons.Default.ShowChart
                                    MainTab.SHIPMENT_TRACKING -> Icons.Default.DirectionsBoat
                                    MainTab.API_EXPLORER -> Icons.Default.Code
                                },
                                contentDescription = tab.title
                            )
                        },
                        modifier = Modifier.testTag("tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (activeTab) {
                MainTab.QUOTE_CALCULATOR -> QuoteCalculatorScreen(viewModel)
                MainTab.SPOT_VS_STRIKE -> ContractManagerScreen(viewModel)
                MainTab.RATEBOOK_STUDIO -> RateBookStudioScreen(viewModel)
                MainTab.MARKET_SIMULATOR -> MarketSimulatorScreen(viewModel)
                MainTab.SHIPMENT_TRACKING -> ShipmentTrackingScreen(viewModel)
                MainTab.API_EXPLORER -> ApiExplorerScreen(viewModel)
            }
        }
    }
}
