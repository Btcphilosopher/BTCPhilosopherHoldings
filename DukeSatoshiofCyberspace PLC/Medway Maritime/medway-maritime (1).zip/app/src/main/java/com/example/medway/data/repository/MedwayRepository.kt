package com.example.medway.data.repository

import com.example.medway.data.local.AuditLogEntity
import com.example.medway.data.local.BookingEntity
import com.example.medway.data.local.ContractEntity
import com.example.medway.data.local.MedwayDao
import com.example.medway.data.local.QuoteEntity
import com.example.medway.data.local.RateBookEntity
import com.example.medway.data.local.RfqEntity
import com.example.medway.data.model.AuditLog
import com.example.medway.data.model.CargoType
import com.example.medway.data.model.ChargeLine
import com.example.medway.data.model.ContainerType
import com.example.medway.data.model.Contract
import com.example.medway.data.model.Currency
import com.example.medway.data.model.Location
import com.example.medway.data.model.MarginDetails
import com.example.medway.data.model.MultiQuoteOption
import com.example.medway.data.model.PricingMode
import com.example.medway.data.model.QuoteRequest
import com.example.medway.data.model.QuoteResponse
import com.example.medway.data.model.RateBook
import com.example.medway.data.model.RfqItem
import com.example.medway.data.model.RfqResponse
import com.example.medway.data.model.Route
import com.example.medway.data.model.RouteLeg
import com.example.medway.data.model.ServiceType
import com.example.medway.data.model.Shipment
import com.example.medway.data.model.TrackingEvent
import com.example.medway.data.model.TrackingStatus
import com.example.medway.data.model.TransportMode
import com.example.medway.engine.PricingOrchestrator
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MedwayRepository(private val dao: MedwayDao) {
    private val gson = Gson()

    val contractsFlow: Flow<List<Contract>> = dao.getAllContracts().map { entities ->
        entities.map { entityToContract(it) }
    }

    val rateBooksFlow: Flow<List<RateBook>> = dao.getAllRateBooks().map { entities ->
        entities.map { RateBook(it.rateBookId, it.version, it.status, it.publishedAt, it.itemCount) }
    }

    val quotesFlow: Flow<List<QuoteResponse>> = dao.getAllQuotes().map { entities ->
        entities.map { entityToQuoteResponse(it) }
    }

    val bookingsFlow: Flow<List<Shipment>> = dao.getAllBookings().map { entities ->
        entities.map { entityToShipment(it) }
    }

    val auditLogsFlow: Flow<List<AuditLog>> = dao.getAllAuditLogs().map { entities ->
        entities.map { AuditLog(it.id, it.timestamp, it.actor, it.organization, it.apiKey, it.action, it.details) }
    }

    val rfqsFlow: Flow<List<RfqResponse>> = dao.getAllRfqs().map { entities ->
        entities.map { entityToRfq(it) }
    }

    suspend fun seedInitialDataIfEmpty() {
        val existingContracts = dao.getAllContracts().first()
        if (existingContracts.isEmpty()) {
            val seedContracts = listOf(
                ContractEntity(
                    contractId = "MWC-2026-0042",
                    customerId = "CUST-0184",
                    customerName = "Kent Industrial Freight Ltd",
                    laneName = "GB (Kent) -> NL (Rotterdam)",
                    originCountry = "GB",
                    destinationCountry = "NL",
                    containerType = "40HC",
                    rateAmount = 1850.0,
                    currency = "GBP",
                    validFrom = "2026-10-01",
                    validUntil = "2026-12-31",
                    volumeCommitmentTeu = 1000,
                    volumeUsedTeu = 428,
                    status = "ACTIVE"
                ),
                ContractEntity(
                    contractId = "MWC-2026-0089",
                    customerId = "CUST-0512",
                    customerName = "EuroLogistics Forwarding NV",
                    laneName = "GB -> DE (Hamburg)",
                    originCountry = "GB",
                    destinationCountry = "DE",
                    containerType = "20GP",
                    rateAmount = 1420.0,
                    currency = "EUR",
                    validFrom = "2026-09-15",
                    validUntil = "2026-11-30",
                    volumeCommitmentTeu = 500,
                    volumeUsedTeu = 190,
                    status = "ACTIVE"
                ),
                ContractEntity(
                    contractId = "MWC-2026-0115",
                    customerId = "ALL_KEY_ACCOUNTS",
                    customerName = "Global Transact Key Accounts Tier",
                    laneName = "GB -> CN (Shanghai)",
                    originCountry = "GB",
                    destinationCountry = "CN",
                    containerType = "40HC",
                    rateAmount = 2890.0,
                    currency = "USD",
                    validFrom = "2026-08-01",
                    validUntil = "2026-12-31",
                    volumeCommitmentTeu = 2500,
                    volumeUsedTeu = 1120,
                    status = "ACTIVE"
                )
            )
            dao.insertContracts(seedContracts)

            // Seed RateBooks
            dao.insertRateBook(
                RateBookEntity(
                    rateBookId = "RATEBOOK-2026-10-02-001",
                    version = "v2026.10.1",
                    status = "PUBLISHED",
                    publishedAt = "2026-10-02 08:00:00 UTC",
                    itemCount = 142
                )
            )

            // Seed Sample Booking with Shipment Events
            val sampleEvents = listOf(
                TrackingEvent(TrackingStatus.BOOKED, "Medway System", "2026-09-28 09:15 UTC", "Booking confirmed under Quote MWQ-20261002-000184."),
                TrackingEvent(TrackingStatus.CONTAINER_ASSIGNED, "Medway Depot Chatham", "2026-09-28 14:00 UTC", "Container MSKU-8821941 assigned and inspected."),
                TrackingEvent(TrackingStatus.EMPTY_RELEASED, "Medway Depot Chatham", "2026-09-29 08:30 UTC", "Empty container released to driver."),
                TrackingEvent(TrackingStatus.PICKUP, "ME1 1AA Rochester Kent", "2026-09-29 11:45 UTC", "Cargo loaded at origin warehouse."),
                TrackingEvent(TrackingStatus.GATE_IN, "Medway Maritime Port Gate 3", "2026-09-29 16:20 UTC", "Gate-in weight verified (18,500 kg)."),
                TrackingEvent(TrackingStatus.LOADED, "Medway Terminal Berth 2", "2026-09-30 04:10 UTC", "Container stowed on vessel 'Medway Feeder Express' V.204."),
                TrackingEvent(TrackingStatus.VESSEL_DEPARTED, "Medway Port", "2026-09-30 08:00 UTC", "Vessel departed Kent waters bound for Rotterdam."),
                TrackingEvent(TrackingStatus.ARRIVED, "Rotterdam World Gateway", "2026-10-01 06:30 UTC", "Vessel berthed at RWG Terminal."),
                TrackingEvent(TrackingStatus.DISCHARGED, "RWG Terminal Yard B", "2026-10-01 10:15 UTC", "Container discharged and stacked."),
                TrackingEvent(TrackingStatus.CUSTOMS, "Dutch Customs Authority", "2026-10-01 13:00 UTC", "Import customs cleared (DAP status approved).")
            )

            dao.insertBooking(
                BookingEntity(
                    bookingId = "MWB-2026-000821",
                    quoteId = "MWQ-20261002-000184",
                    customerName = "Kent Industrial Freight Ltd",
                    containerNumber = "MSKU-8821941",
                    vesselName = "Medway Feeder Express",
                    voyageNumber = "V.204",
                    origin = "ME1 1AA Kent, UK",
                    destination = "3011AA Rotterdam, NL",
                    containerType = "40HC",
                    currentStatus = "CUSTOMS",
                    estimatedDelivery = "2026-10-03 14:00 UTC",
                    eventsJson = gson.toJson(sampleEvents),
                    bookedAt = "2026-09-28 09:15:00 UTC"
                )
            )

            // Seed Audit Log
            logAudit(
                actor = "SYSTEM_INITIALIZER",
                organization = "Medway Maritime",
                apiKey = "mw_live_system",
                action = "RATEBOOK_PUBLISH",
                details = "Published active RateBook RATEBOOK-2026-10-02-001 with 142 lane base rates."
            )
        }
    }

    suspend fun calculateQuote(request: QuoteRequest): QuoteResponse {
        val availableContracts = contractsFlow.first()
        val quote = PricingOrchestrator.generateQuote(request, availableContracts)

        // Save Quote entity
        val entity = QuoteEntity(
            quoteId = quote.quoteId,
            pricingMode = quote.pricingMode.name,
            rateBookId = quote.rateBookId,
            currency = quote.currency.name,
            totalAmount = quote.totalAmount,
            validUntil = quote.validUntil,
            originSummary = "${request.origin.postcode} (${request.origin.country})",
            destinationSummary = "${request.destination.postcode} (${request.destination.country})",
            containerType = request.containerType.code,
            containerQty = request.containerQuantity,
            cargoType = request.cargoType.name,
            serviceType = request.serviceType.name,
            chargesJson = gson.toJson(quote.charges),
            routeJson = gson.toJson(quote.route),
            marginJson = gson.toJson(quote.margin),
            assumptionsJson = gson.toJson(quote.assumptions),
            warningsJson = gson.toJson(quote.warnings),
            requiresManualReview = quote.requiresManualReview,
            createdAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        )
        dao.insertQuote(entity)

        logAudit(
            actor = request.customerId,
            organization = "Medway Partner Portal",
            apiKey = request.apiKey,
            action = "QUOTE_CREATED",
            details = "Quote ${quote.quoteId} generated (${quote.pricingMode.name}): ${quote.currency.symbol}${quote.totalAmount}"
        )

        return quote
    }

    suspend fun compareQuoteOptions(request: QuoteRequest): List<MultiQuoteOption> {
        val availableContracts = contractsFlow.first()
        return PricingOrchestrator.compareQuoteOptions(request, availableContracts)
    }

    suspend fun acceptQuote(quoteId: String, customerName: String): Shipment? {
        val entity = dao.getQuoteById(quoteId) ?: return null
        dao.updateQuoteStatus(quoteId, "ACCEPTED")

        val bookingId = "MWB-" + SimpleDateFormat("yyyy", Locale.US).format(Date()) + "-" + (100000..999999).random()
        val containerNum = "MEDU-" + (1000000..9999999).random()

        val events = listOf(
            TrackingEvent(TrackingStatus.BOOKED, "Medway Maritime Booking Desk", SimpleDateFormat("yyyy-MM-dd HH:mm 'UTC'", Locale.US).format(Date()), "Booking created from Quote $quoteId."),
            TrackingEvent(TrackingStatus.CONTAINER_ASSIGNED, "Medway Depot Chatham", "Scheduled", "Container $containerNum assigned.")
        )

        val bookingEntity = BookingEntity(
            bookingId = bookingId,
            quoteId = quoteId,
            customerName = customerName,
            containerNumber = containerNum,
            vesselName = "Medway Kent Voyager",
            voyageNumber = "V." + (100..999).random(),
            origin = entity.originSummary,
            destination = entity.destinationSummary,
            containerType = entity.containerType,
            currentStatus = "BOOKED",
            estimatedDelivery = "2026-10-25 12:00 UTC",
            eventsJson = gson.toJson(events),
            bookedAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US).format(Date())
        )
        dao.insertBooking(bookingEntity)

        logAudit(
            actor = customerName,
            organization = "Customer Portal",
            apiKey = "mw_live_user",
            action = "QUOTE_ACCEPTED",
            details = "Quote $quoteId accepted. Created Booking $bookingId for container $containerNum."
        )

        return entityToShipment(bookingEntity)
    }

    suspend fun createContract(contract: Contract) {
        val entity = ContractEntity(
            contractId = contract.contractId,
            customerId = contract.customerId,
            customerName = contract.customerName,
            laneName = contract.laneName,
            originCountry = contract.originCountry,
            destinationCountry = contract.destinationCountry,
            containerType = contract.containerType.code,
            rateAmount = contract.rateAmount,
            currency = contract.currency.name,
            validFrom = contract.validFrom,
            validUntil = contract.validUntil,
            volumeCommitmentTeu = contract.volumeCommitmentTeu,
            volumeUsedTeu = contract.volumeUsedTeu,
            status = contract.status
        )
        dao.insertContract(entity)

        logAudit(
            actor = "COMMERCIAL_ADMIN",
            organization = "Medway Maritime Commercial Desk",
            apiKey = "mw_admin_key",
            action = "CONTRACT_CREATED",
            details = "Created Strike Contract ${contract.contractId} for ${contract.customerName} on ${contract.laneName}: ${contract.currency.symbol}${contract.rateAmount}"
        )
    }

    suspend fun publishRateBook(version: String, itemCount: Int) {
        val rateBookId = "RATEBOOK-" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + "-" + (100..999).random()
        val rateBookEntity = RateBookEntity(
            rateBookId = rateBookId,
            version = version,
            status = "PUBLISHED",
            publishedAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US).format(Date()),
            itemCount = itemCount
        )
        dao.insertRateBook(rateBookEntity)

        logAudit(
            actor = "COMMERCIAL_DIRECTOR",
            organization = "Medway Maritime",
            apiKey = "mw_admin_key",
            action = "RATEBOOK_PUBLISH",
            details = "Published new RateBook $rateBookId ($version) containing $itemCount rates."
        )
    }

    suspend fun submitRfq(customerId: String, items: List<RfqItem>): RfqResponse {
        val rfqId = "MWRFQ-" + (10000..99999).random()
        val requestedAt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US).format(Date())
        val rfq = RfqResponse(rfqId, customerId, "OPEN", requestedAt, items)

        dao.insertRfq(RfqEntity(rfqId, customerId, "OPEN", requestedAt, gson.toJson(items)))

        logAudit(
            actor = customerId,
            organization = "Portal User",
            apiKey = "mw_live_user",
            action = "RFQ_SUBMITTED",
            details = "Submitted RFQ $rfqId with ${items.size} lanes."
        )

        return rfq
    }

    suspend fun logAudit(actor: String, organization: String, apiKey: String, action: String, details: String) {
        val id = "AUDIT-" + UUID.randomUUID().toString().take(8)
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US).format(Date())
        dao.insertAuditLog(AuditLogEntity(id, timestamp, actor, organization, apiKey, action, details))
    }

    private fun entityToContract(entity: ContractEntity): Contract {
        return Contract(
            contractId = entity.contractId,
            customerId = entity.customerId,
            customerName = entity.customerName,
            laneName = entity.laneName,
            originCountry = entity.originCountry,
            destinationCountry = entity.destinationCountry,
            containerType = ContainerType.fromCode(entity.containerType),
            rateAmount = entity.rateAmount,
            currency = Currency.valueOf(entity.currency),
            validFrom = entity.validFrom,
            validUntil = entity.validUntil,
            volumeCommitmentTeu = entity.volumeCommitmentTeu,
            volumeUsedTeu = entity.volumeUsedTeu,
            status = entity.status
        )
    }

    private fun entityToQuoteResponse(entity: QuoteEntity): QuoteResponse {
        val chargesType = object : TypeToken<List<ChargeLine>>() {}.type
        val assumptionsType = object : TypeToken<List<String>>() {}.type
        val warningsType = object : TypeToken<List<String>>() {}.type

        val charges: List<ChargeLine> = gson.fromJson(entity.chargesJson, chargesType) ?: emptyList()
        val route: Route = gson.fromJson(entity.routeJson, Route::class.java)
        val margin: MarginDetails? = gson.fromJson(entity.marginJson, MarginDetails::class.java)
        val assumptions: List<String> = gson.fromJson(entity.assumptionsJson, assumptionsType) ?: emptyList()
        val warnings: List<String> = gson.fromJson(entity.warningsJson, warningsType) ?: emptyList()

        return QuoteResponse(
            quoteId = entity.quoteId,
            pricingMode = PricingMode.valueOf(entity.pricingMode),
            rateBookId = entity.rateBookId,
            currency = Currency.valueOf(entity.currency),
            totalAmount = entity.totalAmount,
            validUntil = entity.validUntil,
            route = route,
            charges = charges,
            margin = margin,
            assumptions = assumptions,
            warnings = warnings,
            requiresManualReview = entity.requiresManualReview
        )
    }

    private fun entityToShipment(entity: BookingEntity): Shipment {
        val eventsType = object : TypeToken<List<TrackingEvent>>() {}.type
        val events: List<TrackingEvent> = gson.fromJson(entity.eventsJson, eventsType) ?: emptyList()
        val status = try {
            TrackingStatus.valueOf(entity.currentStatus)
        } catch (e: Exception) {
            TrackingStatus.BOOKED
        }

        return Shipment(
            bookingId = entity.bookingId,
            quoteId = entity.quoteId,
            customerName = entity.customerName,
            containerNumber = entity.containerNumber,
            vesselName = entity.vesselName,
            voyageNumber = entity.voyageNumber,
            origin = entity.origin,
            destination = entity.destination,
            containerType = ContainerType.fromCode(entity.containerType),
            currentStatus = status,
            estimatedDelivery = entity.estimatedDelivery,
            events = events
        )
    }

    private fun entityToRfq(entity: RfqEntity): RfqResponse {
        val itemsType = object : TypeToken<List<RfqItem>>() {}.type
        val items: List<RfqItem> = gson.fromJson(entity.itemsJson, itemsType) ?: emptyList()
        return RfqResponse(entity.rfqId, entity.customerId, entity.status, entity.requestedAt, items)
    }
}
