package com.example.medway.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MedwayDao {
    // Contracts
    @Query("SELECT * FROM contracts")
    fun getAllContracts(): Flow<List<ContractEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContract(contract: ContractEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContracts(contracts: List<ContractEntity>)

    @Query("UPDATE contracts SET volumeUsedTeu = volumeUsedTeu + :usedTeu WHERE contractId = :contractId")
    suspend fun updateContractUsage(contractId: String, usedTeu: Int)

    // RateBooks
    @Query("SELECT * FROM rate_books ORDER BY publishedAt DESC")
    fun getAllRateBooks(): Flow<List<RateBookEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRateBook(rateBook: RateBookEntity)

    // Quotes
    @Query("SELECT * FROM quotes ORDER BY createdAt DESC")
    fun getAllQuotes(): Flow<List<QuoteEntity>>

    @Query("SELECT * FROM quotes WHERE quoteId = :quoteId LIMIT 1")
    suspend fun getQuoteById(quoteId: String): QuoteEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuote(quote: QuoteEntity)

    @Query("UPDATE quotes SET status = :status WHERE quoteId = :quoteId")
    suspend fun updateQuoteStatus(quoteId: String, status: String)

    // Bookings
    @Query("SELECT * FROM bookings ORDER BY bookedAt DESC")
    fun getAllBookings(): Flow<List<BookingEntity>>

    @Query("SELECT * FROM bookings WHERE bookingId = :bookingId LIMIT 1")
    suspend fun getBookingById(bookingId: String): BookingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: BookingEntity)

    // Audit Logs
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC")
    fun getAllAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)

    // RFQs
    @Query("SELECT * FROM rfqs ORDER BY requestedAt DESC")
    fun getAllRfqs(): Flow<List<RfqEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRfq(rfq: RfqEntity)
}
