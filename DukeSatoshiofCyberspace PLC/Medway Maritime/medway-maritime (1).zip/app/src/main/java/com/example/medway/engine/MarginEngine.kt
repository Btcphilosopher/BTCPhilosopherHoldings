package com.example.medway.engine

import com.example.medway.data.model.MarginDetails

object MarginEngine {
    fun calculateMargin(cost: Double, revenue: Double): MarginDetails {
        val grossMargin = revenue - cost
        val percent = if (revenue > 0) (grossMargin / revenue) * 100.0 else 0.0
        return MarginDetails(
            cost = cost,
            revenue = revenue,
            grossMargin = grossMargin,
            grossMarginPercent = Math.round(percent * 100.0) / 100.0
        )
    }
}
