package com.example.medway.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ContractEntity::class,
        RateBookEntity::class,
        QuoteEntity::class,
        BookingEntity::class,
        AuditLogEntity::class,
        RfqEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MedwayDatabase : RoomDatabase() {
    abstract fun medwayDao(): MedwayDao

    companion object {
        @Volatile
        private var INSTANCE: MedwayDatabase? = null

        fun getDatabase(context: Context): MedwayDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MedwayDatabase::class.java,
                    "medway_maritime.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
