package com.example.medway.engine

import com.example.medway.data.model.CargoType
import com.example.medway.data.model.ChargeLine
import com.example.medway.data.model.ContainerType
import com.example.medway.data.model.Currency
import com.example.medway.data.model.QuoteRequest
import com.example.medway.data.model.ServiceType

object ChargeEngine {

    fun generateSpotCharges(request: QuoteRequest, market: MarketConditionState): List<ChargeLine> {
        val list = mutableListOf<ChargeLine>()
        val curr = request.currency
        val qty = request.containerQuantity
        val teus = request.containerType.teus

        // Base factors
        val isLongHaul = request.destination.country == "CN"
        val distMultiplier = if (isLongHaul) 3.5 else 1.0

        // 1. Origin Haulage
        if (request.serviceType == ServiceType.DOOR_TO_DOOR || request.serviceType == ServiceType.DOOR_TO_PORT) {
            val ukHaulageGbp = 420.0 * qty
            list.add(
                ChargeLine(
                    code = "ORIG_HAUL",
                    description = "UK Origin Road Haulage (Kent Base)",
                    amount = FXEngine.convert(ukHaulageGbp, Currency.GBP, curr),
                    currency = curr
                )
            )
        }

        // 2. Origin Terminal Handling Charge (THC)
        val origThcGbp = 285.0 * teus * qty
        list.add(
            ChargeLine(
                code = "ORIG_THC",
                description = "Origin Terminal Handling (Medway Port)",
                amount = FXEngine.convert(origThcGbp, Currency.GBP, curr),
                currency = curr
            )
        )

        // 3. Documentation & Export Customs
        val docGbp = 85.0
        list.add(
            ChargeLine(
                code = "DOC_EXP",
                description = "Export Documentation & Port Customs Clearance",
                amount = FXEngine.convert(docGbp, Currency.GBP, curr),
                currency = curr
            )
        )

        // 4. Base Ocean Freight
        var baseOceanGbp = 690.0 * teus * qty * distMultiplier * market.demandMultiplier
        if (request.containerType == ContainerType.C20RF || request.containerType == ContainerType.C40RF) {
            baseOceanGbp *= 1.4 // Reefer premium
        }
        list.add(
            ChargeLine(
                code = "OCEAN_BASE",
                description = "Base Ocean Freight (${request.containerType.displayName})",
                amount = FXEngine.convert(baseOceanGbp, Currency.GBP, curr),
                currency = curr
            )
        )

        // 5. Fuel Surcharge (BAF)
        val bafGbp = (95.0 * (market.bafFuelIndex / 100.0)) * teus * qty
        list.add(
            ChargeLine(
                code = "SUR_BAF",
                description = "Bunker Adjustment Factor (BAF Index ${market.bafFuelIndex.toInt()})",
                amount = FXEngine.convert(bafGbp, Currency.GBP, curr),
                currency = curr
            )
        )

        // 6. Security (ISPS)
        val ispsGbp = 25.0 * qty
        list.add(
            ChargeLine(
                code = "SUR_ISPS",
                description = "Port Security (ISPS Compliance)",
                amount = FXEngine.convert(ispsGbp, Currency.GBP, curr),
                currency = curr
            )
        )

        // 7. Destination Terminal Handling Charge (THC)
        val destThcGbp = (310.0 * market.portCongestionMultiplier) * teus * qty
        list.add(
            ChargeLine(
                code = "DEST_THC",
                description = "Destination Terminal Handling (${request.destination.country} Gateway)",
                amount = FXEngine.convert(destThcGbp, Currency.GBP, curr),
                currency = curr
            )
        )

        // 8. Import Customs & Delivery
        if (request.serviceType == ServiceType.DOOR_TO_DOOR || request.serviceType == ServiceType.PORT_TO_DOOR) {
            val finalDeliveryGbp = 575.0 * qty
            list.add(
                ChargeLine(
                    code = "DEST_HAUL",
                    description = "Destination Final Delivery Haulage",
                    amount = FXEngine.convert(finalDeliveryGbp, Currency.GBP, curr),
                    currency = curr
                )
            )
        }

        // Special Cargo Accessorials
        if (request.cargoType == CargoType.REEFER) {
            val reeferPowerGbp = 150.0 * qty
            list.add(
                ChargeLine(
                    code = "ACC_REEFER",
                    description = "Reefer Monitoring & Genset Power",
                    amount = FXEngine.convert(reeferPowerGbp, Currency.GBP, curr),
                    currency = curr
                )
            )
        }

        // Medway Commercial Service Margin
        val serviceMarginGbp = 20.0 * qty
        list.add(
            ChargeLine(
                code = "MEDWAY_MARGIN",
                description = "Medway Freight Orchestration Fee",
                amount = FXEngine.convert(serviceMarginGbp, Currency.GBP, curr),
                currency = curr
            )
        )

        return list
    }

    fun generateStrikeCharges(
        baseStrikeRate: Double,
        contractCurrency: Currency,
        request: QuoteRequest,
        market: MarketConditionState
    ): List<ChargeLine> {
        val list = mutableListOf<ChargeLine>()
        val curr = request.currency
        val qty = request.containerQuantity

        // Convert contracted base rate to quote currency
        val strikeInQuoteCurrency = FXEngine.convert(baseStrikeRate * qty, contractCurrency, curr)
        list.add(
            ChargeLine(
                code = "STRIKE_BASE",
                description = "Contractual Strike Base Rate (${request.containerType.displayName})",
                amount = strikeInQuoteCurrency,
                currency = curr,
                source = "CUSTOMER_CONTRACT"
            )
        )

        // Contract Surcharges (BAF Fuel Index adjustment if indexed)
        val bafGbp = (95.0 * (market.bafFuelIndex / 100.0)) * request.containerType.teus * qty
        list.add(
            ChargeLine(
                code = "SUR_BAF_INDEXED",
                description = "Indexed Bunker Fuel Adjustment (BAF)",
                amount = FXEngine.convert(bafGbp, Currency.GBP, curr),
                currency = curr,
                source = "INDEXED_CONTRACT"
            )
        )

        val docGbp = 85.0
        list.add(
            ChargeLine(
                code = "DOC_EXP",
                description = "Documentation & Customs Administration",
                amount = FXEngine.convert(docGbp, Currency.GBP, curr),
                currency = curr,
                source = "MEDWAY_SYSTEM"
            )
        )

        return list
    }
}
