package com.example.medway.engine

import com.example.medway.data.model.Location
import com.example.medway.data.model.Route
import com.example.medway.data.model.RouteLeg
import com.example.medway.data.model.ServiceType
import com.example.medway.data.model.TransportMode
import java.util.UUID

object RouteEngine {

    fun generateRoute(
        origin: Location,
        destination: Location,
        serviceType: ServiceType,
        viaAltPort: Boolean = false
    ): Route {
        val legs = mutableListOf<RouteLeg>()
        val routeId = "ROUTE-" + UUID.randomUUID().toString().take(8).uppercase()

        val originPort = if (origin.country == "GB") {
            if (viaAltPort) "Felixstowe Port (GBFXT)" else "Medway Maritime Port (GBME1)"
        } else {
            "${origin.country} Ocean Terminal"
        }

        val destPort = if (destination.country == "NL") {
            if (viaAltPort) "Antwerp Port (BEANT)" else "Rotterdam World Gateway (NLRTM)"
        } else if (destination.country == "CN") {
            "Shanghai Port (CNSHA)"
        } else if (destination.country == "DE") {
            "Hamburg Port (DEHAM)"
        } else {
            "${destination.country} Gateway Terminal"
        }

        val originLocName = if (origin.postcode.isNotBlank()) "${origin.postcode}, ${origin.country}" else origin.country
        val destLocName = if (destination.postcode.isNotBlank()) "${destination.postcode}, ${destination.country}" else destination.country

        when (serviceType) {
            ServiceType.DOOR_TO_DOOR -> {
                legs.add(
                    RouteLeg(
                        mode = TransportMode.ROAD,
                        originName = originLocName,
                        destinationName = originPort,
                        carrier = "Medway Kent Haulage",
                        transitDays = 1
                    )
                )
                legs.add(
                    RouteLeg(
                        mode = TransportMode.SEA,
                        originName = originPort,
                        destinationName = destPort,
                        carrier = "Medway Container Feeder Line",
                        transitDays = if (destination.country == "CN") 28 else 2
                    )
                )
                legs.add(
                    RouteLeg(
                        mode = TransportMode.ROAD,
                        originName = destPort,
                        destinationName = destLocName,
                        carrier = "Euro-Express Transport",
                        transitDays = 1
                    )
                )
            }
            ServiceType.PORT_TO_PORT -> {
                legs.add(
                    RouteLeg(
                        mode = TransportMode.SEA,
                        originName = originPort,
                        destinationName = destPort,
                        carrier = "Medway Ocean Direct",
                        transitDays = if (destination.country == "CN") 28 else 2
                    )
                )
            }
            ServiceType.DOOR_TO_PORT -> {
                legs.add(
                    RouteLeg(
                        mode = TransportMode.ROAD,
                        originName = originLocName,
                        destinationName = originPort,
                        carrier = "Medway Inland Transport",
                        transitDays = 1
                    )
                )
                legs.add(
                    RouteLeg(
                        mode = TransportMode.SEA,
                        originName = originPort,
                        destinationName = destPort,
                        carrier = "Medway Lines",
                        transitDays = if (destination.country == "CN") 28 else 2
                    )
                )
            }
            ServiceType.PORT_TO_DOOR -> {
                legs.add(
                    RouteLeg(
                        mode = TransportMode.SEA,
                        originName = originPort,
                        destinationName = destPort,
                        carrier = "Medway Lines",
                        transitDays = if (destination.country == "CN") 28 else 2
                    )
                )
                legs.add(
                    RouteLeg(
                        mode = TransportMode.ROAD,
                        originName = destPort,
                        destinationName = destLocName,
                        carrier = "Local Destination Haulage",
                        transitDays = 1
                    )
                )
            }
        }

        val totalTransit = legs.sumOf { it.transitDays }
        return Route(routeId = routeId, totalTransitDays = totalTransit, legs = legs)
    }

    fun generateRailRouteOption(origin: Location, destination: Location): Route {
        val routeId = "ROUTE-RAIL-" + UUID.randomUUID().toString().take(6).uppercase()
        val legs = listOf(
            RouteLeg(TransportMode.ROAD, "${origin.postcode}, ${origin.country}", "Medway Rail Freight Depot", "Medway Rail", 1),
            RouteLeg(TransportMode.RAIL, "Medway Rail Depot", "Channel Tunnel Rail Link / Rotterdam Rail", "Intermodal Rail EU", 2),
            RouteLeg(TransportMode.ROAD, "Rotterdam Rail Depot", "${destination.postcode}, ${destination.country}", "Euro Rail Express", 1)
        )
        return Route(routeId = routeId, totalTransitDays = 4, legs = legs)
    }
}
