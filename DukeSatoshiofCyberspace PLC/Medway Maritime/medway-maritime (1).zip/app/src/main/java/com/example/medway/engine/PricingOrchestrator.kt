package com.example.medway.engine

import com.example.medway.data.model.CargoType
import com.example.medway.data.model.Contract
import com.example.medway.data.model.MultiQuoteOption
import com.example.medway.data.model.PricingMode
import com.example.medway.data.model.QuoteRequest
import com.example.medway.data.model.QuoteResponse
import java.util.UUID

object PricingOrchestrator {

    fun generateQuote(
        request: QuoteRequest,
        availableContracts: List<Contract>,
        viaAltPort: Boolean = false
    ): QuoteResponse {
        val market = SpotMarketSimulator.marketState.value
        val contract = StrikeRateEngine.findApplicableContract(request, availableContracts)

        val pricingMode = if (contract != null) PricingMode.STRIKE else PricingMode.SPOT

        val charges = if (contract != null) {
            ChargeEngine.generateStrikeCharges(contract.rateAmount, contract.currency, request, market)
        } else {
            ChargeEngine.generateSpotCharges(request, market)
        }

        val totalAmount = charges.sumOf { it.amount }
        val roundedTotal = Math.round(totalAmount * 100.0) / 100.0

        val route = RouteEngine.generateRoute(request.origin, request.destination, request.serviceType, viaAltPort)

        // Internal Margin Calculation
        val supplierCostRatio = if (contract != null) 0.85 else 0.81
        val estimatedCost = roundedTotal * supplierCostRatio
        val margin = MarginEngine.calculateMargin(estimatedCost, roundedTotal)

        val warnings = mutableListOf<String>()
        val assumptions = mutableListOf<String>()

        assumptions.add("Price includes standard container detention (5 free days at port).")
        assumptions.add("Rate benchmarked against RateBook ${market.activeRateBookVersion}.")

        if (contract != null) {
            assumptions.add("Strike Contract ${contract.contractId} applied for ${contract.customerName}.")
            assumptions.add("Volume commitment balance: ${contract.volumeCommitmentTeu - contract.volumeUsedTeu} TEUs remaining.")
        } else {
            assumptions.add("Spot rate calculated from live market indices (BAF Index ${market.bafFuelIndex.toInt()}).")
        }

        var manualReview = false
        if (request.cargoType.requiresManualReview) {
            warnings.add("MANUAL REVIEW REQUIRED: Hazardous/Oversized cargo subject to carrier approval.")
            manualReview = true
        }

        if (market.portCongestionMultiplier > 1.05) {
            warnings.add("Port Congestion Surcharge applied due to port delay alerts.")
        }

        warnings.add("Quote valid for 24 hours from issuance.")

        val quoteId = "MWQ-" + System.currentTimeMillis().toString().takeLast(6) + "-" + (1000..9999).random()

        return QuoteResponse(
            quoteId = quoteId,
            pricingMode = pricingMode,
            rateBookId = market.activeRateBookVersion,
            currency = request.currency,
            totalAmount = roundedTotal,
            validUntil = "2026-10-03T23:59:59Z",
            route = route,
            charges = charges,
            margin = margin,
            assumptions = assumptions,
            warnings = warnings,
            requiresManualReview = manualReview
        )
    }

    fun compareQuoteOptions(
        request: QuoteRequest,
        availableContracts: List<Contract>
    ): List<MultiQuoteOption> {
        // Option A: Standard Direct Road + Sea
        val optAQuote = generateQuote(request, availableContracts, viaAltPort = false)

        // Option B: Rail Intermodal + Sea
        val railRoute = RouteEngine.generateRailRouteOption(request.origin, request.destination)
        val optBAmount = Math.round(optAQuote.totalAmount * 0.89 * 100.0) / 100.0
        val optBQuote = optAQuote.copy(
            quoteId = optAQuote.quoteId + "-RAIL",
            totalAmount = optBAmount,
            route = railRoute
        )

        // Option C: Alternative Gateway Port (Felixstowe / Antwerp)
        val optCQuote = generateQuote(request, availableContracts, viaAltPort = true)

        return listOf(
            MultiQuoteOption(
                optionName = "Option A: Medway Direct (Road + Sea)",
                description = "Primary express corridor via Medway Maritime Port (Kent, UK)",
                totalAmount = optAQuote.totalAmount,
                currency = request.currency,
                transitDays = optAQuote.route.totalTransitDays,
                routeSummary = "${request.origin.country} Port → ${request.destination.country} Gateway",
                quoteResponse = optAQuote
            ),
            MultiQuoteOption(
                optionName = "Option B: Rail Intermodal Corridor",
                description = "Eco-friendly Rail + Channel Tunnel freight link",
                totalAmount = optBQuote.totalAmount,
                currency = request.currency,
                transitDays = optBQuote.route.totalTransitDays,
                routeSummary = "Rail Rail Hub → Rotterdam Intermodal",
                quoteResponse = optBQuote
            ),
            MultiQuoteOption(
                optionName = "Option C: Alternative Gateway (Felixstowe / Antwerp)",
                description = "Secondary port routing for peak congestion bypass",
                totalAmount = optCQuote.totalAmount,
                currency = request.currency,
                transitDays = optCQuote.route.totalTransitDays,
                routeSummary = "Felixstowe Port → Antwerp World Gateway",
                quoteResponse = optCQuote
            )
        )
    }
}
