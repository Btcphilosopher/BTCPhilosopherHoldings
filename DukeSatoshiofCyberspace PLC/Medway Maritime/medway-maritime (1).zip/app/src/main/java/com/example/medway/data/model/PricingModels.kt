package com.example.medway.data.model

import java.util.UUID

enum class ContainerType(val code: String, val displayName: String, val teus: Float) {
    C20GP("20GP", "20' General Purpose", 1.0f),
    C40GP("40GP", "40' General Purpose", 2.0f),
    C40HC("40HC", "40' High Cube", 2.0f),
    C45HC("45HC", "45' High Cube", 2.25f),
    C20RF("20RF", "20' Reefer", 1.0f),
    C40RF("40RF", "40' Reefer", 2.0f),
    OPEN_TOP("OPEN_TOP", "40' Open Top", 2.0f),
    FLAT_RACK("FLAT_RACK", "40' Flat Rack", 2.0f),
    TANK("TANK", "20' ISO Tank", 1.0f);

    companion object {
        fun fromCode(code: String): ContainerType =
            entries.find { it.code.equals(code, ignoreCase = true) } ?: C40HC
    }
}

enum class CargoType(val label: String, val requiresManualReview: Boolean) {
    GENERAL("General Freight", false),
    REEFER("Temperature Controlled / Reefer", false),
    DANGEROUS_GOODS("Dangerous Goods (Hazmat / IMO)", true),
    OVERSIZED("Oversized / Out of Gauge", true),
    LIQUID("Bulk Liquid (ISO Tank)", false),
    PERISHABLE("Perishable Goods", false)
}

enum class Incoterm {
    DAP, DDP, FOB, CIF, EXW
}

enum class ServiceType(val label: String) {
    DOOR_TO_DOOR("Door to Door"),
    PORT_TO_PORT("Port to Port"),
    DOOR_TO_PORT("Door to Port"),
    PORT_TO_DOOR("Port to Door")
}

enum class PricingMode(val title: String, val isContractual: Boolean) {
    SPOT("Spot Market Rate", false),
    STRIKE("Strike / Contract Rate", true),
    STRIKE_PLUS_SURCHARGES("Strike Rate + Variable Surcharges", true),
    INDEXED_CONTRACT("Indexed Fuel/FX Contract", true),
    MANUAL_OVERRIDE("Manual Commercial Override", false)
}

enum class UserRole(val displayName: String, val canSeeMargins: Boolean, val canPublishRateBook: Boolean) {
    CUSTOMER("Customer Portal", false, false),
    FORWARDER("Freight Forwarder / Partner", false, false),
    FREIGHT_STAFF("Medway Internal Staff", true, false),
    ADMIN("Commercial Pricing Admin", true, true)
}

enum class Currency(val code: String, val symbol: String) {
    GBP("GBP", "£"),
    EUR("EUR", "€"),
    USD("USD", "$"),
    CNY("CNY", "¥"),
    JPY("JPY", "¥"),
    AED("AED", "AED "),
    SGD("SGD", "S$"),
    CAD("CAD", "CA$"),
    AUD("AUD", "A$")
}

data class Location(
    val country: String,
    val postcode: String = "",
    val portName: String = "",
    val portCode: String = ""
)

data class QuoteRequest(
    val origin: Location,
    val destination: Location,
    val containerType: ContainerType,
    val containerQuantity: Int = 1,
    val cargoType: CargoType = CargoType.GENERAL,
    val cargoWeightKg: Int = 18500,
    val serviceType: ServiceType = ServiceType.DOOR_TO_DOOR,
    val incoterm: Incoterm = Incoterm.DAP,
    val pickupDate: String = "2026-10-20",
    val currency: Currency = Currency.GBP,
    val customerId: String = "CUST-0184",
    val apiKey: String = "mw_live_demo8841",
    val idempotencyKey: String = UUID.randomUUID().toString()
)

data class ChargeLine(
    val code: String,
    val description: String,
    val amount: Double,
    val currency: Currency,
    val source: String = "MEDWAY_SYSTEM",
    val mandatory: Boolean = true,
    val isTaxable: Boolean = false
)

enum class TransportMode(val label: String) {
    ROAD("Road Haulage"),
    SEA("Ocean Vessel"),
    RAIL("Rail Freight")
}

data class RouteLeg(
    val mode: TransportMode,
    val originName: String,
    val destinationName: String,
    val carrier: String = "Medway Logistics",
    val transitDays: Int = 2
)

data class Route(
    val routeId: String,
    val totalTransitDays: Int,
    val legs: List<RouteLeg>
)

data class MarginDetails(
    val cost: Double,
    val revenue: Double,
    val grossMargin: Double,
    val grossMarginPercent: Double
)

data class QuoteResponse(
    val quoteId: String,
    val pricingMode: PricingMode,
    val rateBookId: String,
    val currency: Currency,
    val totalAmount: Double,
    val validUntil: String,
    val route: Route,
    val charges: List<ChargeLine>,
    val margin: MarginDetails?,
    val assumptions: List<String>,
    val warnings: List<String>,
    val requiresManualReview: Boolean = false
)

data class MultiQuoteOption(
    val optionName: String,
    val description: String,
    val totalAmount: Double,
    val currency: Currency,
    val transitDays: Int,
    val routeSummary: String,
    val quoteResponse: QuoteResponse
)

data class Contract(
    val contractId: String,
    val customerId: String,
    val customerName: String,
    val laneName: String,
    val originCountry: String,
    val destinationCountry: String,
    val containerType: ContainerType,
    val rateAmount: Double,
    val currency: Currency,
    val validFrom: String,
    val validUntil: String,
    val volumeCommitmentTeu: Int,
    val volumeUsedTeu: Int,
    val status: String = "ACTIVE"
)

data class RateBook(
    val rateBookId: String,
    val version: String,
    val status: String, // DRAFT, VALIDATED, APPROVED, PUBLISHED, SUPERSEDED
    val publishedAt: String,
    val itemCount: Int
)

enum class TrackingStatus(val label: String, val stepIndex: Int) {
    BOOKED("Booked", 1),
    CONTAINER_ASSIGNED("Container Assigned", 2),
    EMPTY_RELEASED("Empty Released", 3),
    PICKUP("Pickup Completed", 4),
    GATE_IN("Gate-In at Origin Port", 5),
    LOADED("Loaded on Vessel", 6),
    VESSEL_DEPARTED("Vessel Departed", 7),
    TRANSSHIPMENT("Transshipment En Route", 8),
    ARRIVED("Arrived at Destination Port", 9),
    DISCHARGED("Container Discharged", 10),
    CUSTOMS("Customs Clearance", 11),
    RELEASED("Port Released", 12),
    OUT_FOR_DELIVERY("Out for Delivery", 13),
    DELIVERED("Delivered to Destination", 14)
}

data class TrackingEvent(
    val status: TrackingStatus,
    val location: String,
    val timestamp: String,
    val description: String
)

data class Shipment(
    val bookingId: String,
    val quoteId: String,
    val customerName: String,
    val containerNumber: String,
    val vesselName: String,
    val voyageNumber: String,
    val origin: String,
    val destination: String,
    val containerType: ContainerType,
    val currentStatus: TrackingStatus,
    val estimatedDelivery: String,
    val events: List<TrackingEvent>
)

data class RfqItem(
    val lane: String,
    val containerType: ContainerType,
    val quantity: Int,
    val targetDate: String,
    val indicativeRate: Double? = null
)

data class RfqResponse(
    val rfqId: String,
    val customerId: String,
    val status: String, // OPEN, PRICING, QUOTED, ACCEPTED, EXPIRED
    val requestedAt: String,
    val items: List<RfqItem>
)

data class AuditLog(
    val id: String,
    val timestamp: String,
    val actor: String,
    val organization: String,
    val apiKey: String,
    val action: String,
    val details: String
)
