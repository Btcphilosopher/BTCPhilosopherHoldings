"""
bloch_viz.py — Matplotlib Bloch Sphere & Circuit Visualiser
=============================================================
Provides:
  • 3D Bloch sphere rendering of one or more qubit states (matplotlib)
  • Qubit state evolution trace (step-by-step gate application)
  • ASCII circuit diagram renderer
  • BB84 basis/bit strip chart
  • E91 CHSH S parameter bar chart
  • Quantum key bit distribution histogram

All plots can be shown interactively or saved to PNG.
Falls back gracefully when matplotlib is not installed.
"""

import math
from typing import List, Tuple, Optional, Sequence

try:
    import numpy as np
    import matplotlib
    matplotlib.use("Agg")          # headless-safe; GUI backends override this
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    from matplotlib.patches import FancyArrowPatch
    from mpl_toolkits.mplot3d import Axes3D
    from mpl_toolkits.mplot3d.proj3d import proj_transform
    MPL_AVAILABLE = True
except ImportError:
    MPL_AVAILABLE = False

from qubit_sim import Qubit, TwoQubitSystem


# ─────────────────────────────────────────────────────────────────────────────
# Bloch sphere helpers
# ─────────────────────────────────────────────────────────────────────────────

def _bloch_xyz(qubit: Qubit) -> Tuple[float, float, float]:
    """Convert qubit state to Bloch sphere Cartesian coordinates (x, y, z)."""
    theta, phi = qubit.bloch_angles()
    x = math.sin(theta) * math.cos(phi)
    y = math.sin(theta) * math.sin(phi)
    z = math.cos(theta)
    return x, y, z


def _draw_sphere(ax, alpha: float = 0.08):
    """Draw the unit sphere wireframe."""
    u = np.linspace(0, 2 * np.pi, 60)
    v = np.linspace(0, np.pi, 30)
    sx = np.outer(np.cos(u), np.sin(v))
    sy = np.outer(np.sin(u), np.sin(v))
    sz = np.outer(np.ones_like(u), np.cos(v))
    ax.plot_surface(sx, sy, sz, color="steelblue", alpha=alpha, linewidth=0)

    # Equator + meridians
    theta = np.linspace(0, 2 * np.pi, 100)
    ax.plot(np.cos(theta), np.sin(theta), 0, "k--", lw=0.5, alpha=0.4)
    ax.plot(np.cos(theta), np.zeros(100), np.sin(theta), "k--", lw=0.5, alpha=0.4)
    ax.plot(np.zeros(100), np.cos(theta), np.sin(theta), "k--", lw=0.5, alpha=0.4)


def _draw_axes(ax):
    """Draw X, Y, Z axis arrows and labels."""
    lim = 1.3
    for (xs, ys, zs), (xe, ye, ze), label, color in [
        ([0,0,0], [lim,0,0], "+X", "#e74c3c"),
        ([0,0,0], [0,lim,0], "+Y", "#2ecc71"),
        ([0,0,0], [0,0,lim], "|0⟩", "#3498db"),
        ([0,0,0], [0,0,-lim], "|1⟩", "#9b59b6"),
    ]:
        ax.quiver(xs, ys, zs, xe, ye, ze, color=color,
                  arrow_length_ratio=0.1, linewidth=1.5)
        ax.text(xe * 1.1, ye * 1.1, ze * 1.1, label,
                fontsize=9, color=color, ha="center")


def plot_bloch_sphere(
    qubits: List[Qubit],
    labels: Optional[List[str]] = None,
    title:  str  = "Bloch Sphere",
    save_path: Optional[str] = None,
    show: bool = True,
) -> Optional[object]:
    """
    Plot one or more qubit states on the Bloch sphere.

    Parameters
    ----------
    qubits    : list of Qubit objects
    labels    : optional list of label strings
    title     : plot title
    save_path : if given, save figure to this path (PNG/PDF/SVG)
    show      : if True, call plt.show() (GUI mode)

    Returns
    -------
    matplotlib Figure or None if matplotlib unavailable.
    """
    if not MPL_AVAILABLE:
        print("[bloch_viz] matplotlib not available — skipping Bloch plot")
        return None

    fig = plt.figure(figsize=(7, 6))
    ax  = fig.add_subplot(111, projection="3d")

    _draw_sphere(ax)
    _draw_axes(ax)

    colors = plt.cm.tab10.colors
    for i, qubit in enumerate(qubits):
        x, y, z = _bloch_xyz(qubit)
        color = colors[i % len(colors)]
        label = (labels[i] if labels else f"q{i}")

        # Draw state vector
        ax.quiver(0, 0, 0, x, y, z,
                  color=color, arrow_length_ratio=0.15,
                  linewidth=2.5, label=label)
        # Mark tip
        ax.scatter([x], [y], [z], color=color, s=60, zorder=5)

        # Probability annotation
        p0, p1 = qubit.probabilities
        ax.text(x * 1.2, y * 1.2, z * 1.2,
                f"P(0)={p0:.2f}",
                fontsize=7, color=color, alpha=0.8)

    ax.set_xlim(-1.4, 1.4)
    ax.set_ylim(-1.4, 1.4)
    ax.set_zlim(-1.4, 1.4)
    ax.set_title(title, fontsize=13, fontweight="bold", pad=12)
    ax.legend(loc="upper left", fontsize=8)
    ax.axis("off")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    if show:
        plt.show()
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# Gate evolution trace
# ─────────────────────────────────────────────────────────────────────────────

def plot_gate_evolution(
    gates:     List[str],
    save_path: Optional[str] = None,
    show:      bool = True,
) -> Optional[object]:
    """
    Plot the Bloch sphere position of |0⟩ after each gate in `gates`.
    Shows state evolution as a trajectory on the sphere.

    Parameters
    ----------
    gates : list of gate names: 'H', 'X', 'Y', 'Z', 'S' (identity)
    """
    if not MPL_AVAILABLE:
        print("[bloch_viz] matplotlib not available")
        return None

    q    = Qubit.zero()
    xs   = [0.0]
    ys   = [0.0]
    zs   = [1.0]
    lbls = ["|0⟩"]

    gate_map = {
        "H": lambda q: q.hadamard(),
        "X": lambda q: q.pauli_x(),
        "Y": lambda q: q.pauli_y(),
        "Z": lambda q: q.pauli_z(),
    }

    for g in gates:
        if g.upper() in gate_map:
            gate_map[g.upper()](q)
        x, y, z = _bloch_xyz(q)
        xs.append(x); ys.append(y); zs.append(z)
        lbls.append(g.upper())

    fig = plt.figure(figsize=(8, 7))
    ax  = fig.add_subplot(111, projection="3d")
    _draw_sphere(ax)
    _draw_axes(ax)

    # Draw trajectory
    ax.plot(xs, ys, zs, "o-", color="darkorange",
            lw=2, ms=7, zorder=6, label="State path")

    # Label each step
    for i, (x, y, z, lbl) in enumerate(zip(xs, ys, zs, lbls)):
        ax.text(x * 1.25, y * 1.25, z * 1.25, f"{i}:{lbl}",
                fontsize=7.5, color="darkorange")

    ax.set_xlim(-1.4, 1.4)
    ax.set_ylim(-1.4, 1.4)
    ax.set_zlim(-1.4, 1.4)
    title_gates = " → ".join(["$|0\\rangle$"] + [f"${g}$" for g in gates])
    ax.set_title(f"Gate Evolution: {title_gates}", fontsize=11,
                 fontweight="bold", pad=10)
    ax.legend(fontsize=8)
    ax.axis("off")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    if show:
        plt.show()
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# ASCII circuit diagram
# ─────────────────────────────────────────────────────────────────────────────

def render_circuit_ascii(
    circuit: List[List[str]],
    qubit_labels: Optional[List[str]] = None,
) -> str:
    """
    Render a quantum circuit as ASCII art.

    Parameters
    ----------
    circuit       : list of columns; each column is a list of gate strings
                    (one per qubit), e.g. [["H", "I"], ["CNOT_C", "CNOT_T"]]
    qubit_labels  : optional qubit labels (default: q0, q1, …)

    Returns
    -------
    Multi-line ASCII string.

    Example input → output
    ----------------------
    circuit = [["H","I"],["CNOT_C","CNOT_T"],["M","M"]]
    qubit_labels = ["Alice", "Bob"]

    q0 Alice: ─[H]────●─────[M]─
    q1   Bob: ─────[I]─[X]──[M]─
    """
    if not circuit:
        return ""

    n_qubits = len(circuit[0])
    labels   = qubit_labels or [f"q{i}" for i in range(n_qubits)]
    max_lbl  = max(len(l) for l in labels)

    # Build rows
    rows = ["─" * 2] * n_qubits

    for col in circuit:
        # Find widest gate in this column
        max_w = max(len(g) for g in col)
        for q_idx, gate in enumerate(col):
            gate_str = gate.center(max_w)
            if gate.upper() in ("I", "ID", "─"):
                block = "─" * (max_w + 2)
            elif gate.upper() in ("CNOT_C", "CTRL"):
                block = "─" * (max_w // 2) + "●" + "─" * (max_w - max_w // 2)
            elif gate.upper() in ("CNOT_T", "TARG"):
                block = "─" * (max_w // 2) + "⊕" + "─" * (max_w - max_w // 2)
            elif gate.upper() == "M":
                block = "─[M]─"
            else:
                block = f"─[{gate_str}]─"
            rows[q_idx] += block

    lines = []
    for q_idx, (lbl, row) in enumerate(zip(labels, rows)):
        prefix = f"{lbl:>{max_lbl}}: "
        lines.append(prefix + row + "─")
    return "\n".join(lines)


def show_bb84_circuit() -> str:
    """Return ASCII representation of the BB84 encoding + measurement circuit."""
    circuit = [
        ["bit=0", "─────"],
        ["H?",    "─────"],
        ["───",   "H?"],
        ["M(Z)",  "M(Z)"],
    ]
    qubit_labels = ["Alice (send)", "Bob (recv) "]
    return render_circuit_ascii(circuit, qubit_labels)


def show_bell_circuit() -> str:
    """Return ASCII for the Bell state preparation circuit."""
    circuit = [
        ["H",      "I"     ],
        ["CNOT_C", "CNOT_T"],
        ["M",      "M"     ],
    ]
    return render_circuit_ascii(circuit, ["q0 (Alice)", "q1 (Bob)  "])


# ─────────────────────────────────────────────────────────────────────────────
# BB84 session strip chart
# ─────────────────────────────────────────────────────────────────────────────

def plot_bb84_session(
    result,
    n_show:    int  = 64,
    save_path: Optional[str] = None,
    show:      bool = True,
) -> Optional[object]:
    """
    Visualise the first `n_show` qubits of a BB84 session as colour-coded strips.
    Rows: Alice bits, Alice bases, Bob bases, match?, Bob result.
    """
    if not MPL_AVAILABLE:
        return None

    n = min(n_show, len(result.alice_bits))
    sifted = set(result.sifted_indices)

    alice_bits   = result.alice_bits[:n]
    alice_bases  = [1 if b == "X" else 0 for b in result.alice_bases[:n]]
    bob_bases    = [1 if b == "X" else 0 for b in result.bob_bases[:n]]
    bob_meas     = result.bob_measurements[:n]
    matches      = [1 if result.alice_bases[i] == result.bob_bases[i] else 0
                    for i in range(n)]

    rows   = [alice_bits, alice_bases, bob_bases, matches, bob_meas]
    labels = ["Alice bits", "Alice basis\n(1=X, 0=Z)",
              "Bob basis\n(1=X, 0=Z)", "Basis match", "Bob result"]
    cmaps  = ["RdYlGn", "PuBu", "PuBu", "Greens", "RdYlGn"]

    fig, axes = plt.subplots(5, 1, figsize=(min(n * 0.22 + 2, 18), 6))
    fig.suptitle(
        f"BB84 Session — First {n} Qubits  "
        f"(QBER={result.error_rate:.1%}  "
        f"Eve={'Yes' if result.eve_present else 'No'})",
        fontsize=12, fontweight="bold",
    )

    for ax, row, label, cmap in zip(axes, rows, labels, cmaps):
        data = np.array(row).reshape(1, -1)
        ax.imshow(data, aspect="auto", cmap=cmap, vmin=0, vmax=1,
                  interpolation="nearest")
        ax.set_yticks([0])
        ax.set_yticklabels([label], fontsize=8)
        ax.set_xticks([])

        # Outline sifted positions
        for i in range(n):
            if i in sifted:
                ax.add_patch(mpatches.Rectangle(
                    (i - 0.5, -0.5), 1, 1,
                    fill=False, edgecolor="gold", lw=1.5
                ))

    axes[-1].set_xticks(range(n))
    axes[-1].set_xticklabels([str(i) for i in range(n)], fontsize=5, rotation=90)

    # Legend
    fig.text(0.01, 0.01,
             "Gold outline = matching bases (sifted key)",
             fontsize=7, color="goldenrod")

    plt.tight_layout(rect=[0, 0.03, 1, 1])
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    if show:
        plt.show()
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# E91 CHSH bar chart
# ─────────────────────────────────────────────────────────────────────────────

def plot_chsh_comparison(
    results_list: List[tuple],   # list of (label, chsh_S, color)
    save_path: Optional[str] = None,
    show: bool = True,
) -> Optional[object]:
    """
    Bar chart comparing CHSH S values across multiple E91 runs.

    Parameters
    ----------
    results_list : list of (label_str, S_value, color_str)
    """
    if not MPL_AVAILABLE:
        return None

    quantum_max = 2 * math.sqrt(2)

    labels = [r[0] for r in results_list]
    values = [r[1] for r in results_list]
    colors = [r[2] for r in results_list]

    fig, ax = plt.subplots(figsize=(max(4, len(labels) * 1.5 + 2), 5))

    bars = ax.bar(labels, values, color=colors, edgecolor="black",
                  linewidth=0.8, width=0.5)

    # Reference lines
    ax.axhline(2.0,          color="orange", lw=2, ls="--",
               label=f"Classical bound  S = 2.0")
    ax.axhline(quantum_max,  color="green",  lw=2, ls=":",
               label=f"Quantum max  S = 2√2 ≈ {quantum_max:.3f}")

    # Value labels on bars
    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2,
                val + 0.03,
                f"{val:.3f}",
                ha="center", va="bottom", fontsize=10, fontweight="bold")

    ax.set_ylim(0, quantum_max * 1.15)
    ax.set_ylabel("CHSH Parameter S", fontsize=11)
    ax.set_title("E91 Bell Test: CHSH S Parameter", fontsize=13, fontweight="bold")
    ax.legend(fontsize=9)

    # Shade regions
    ax.axhspan(0,           2.0,         alpha=0.06, color="red",   label="Classical region")
    ax.axhspan(2.0,         quantum_max, alpha=0.06, color="green", label="Quantum region")
    ax.axhspan(quantum_max, quantum_max * 1.15, alpha=0.03, color="blue")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    if show:
        plt.show()
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# Key bit distribution histogram
# ─────────────────────────────────────────────────────────────────────────────

def plot_key_distribution(
    key_hex:   str,
    title:     str = "Key Byte Distribution",
    save_path: Optional[str] = None,
    show:      bool = True,
) -> Optional[object]:
    """
    Histogram of byte values in the key — should be uniform for good keys.
    Also plots bit-level balance.
    """
    if not MPL_AVAILABLE:
        return None

    key_bytes = bytes.fromhex(key_hex)
    byte_vals = list(key_bytes)
    bits      = []
    for b in key_bytes:
        for i in range(7, -1, -1):
            bits.append((b >> i) & 1)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
    fig.suptitle(title, fontsize=13, fontweight="bold")

    # Byte histogram
    ax1.bar(range(256), [byte_vals.count(v) for v in range(256)],
            color="steelblue", alpha=0.7, width=1)
    ax1.axhline(len(key_bytes) / 256, color="red", lw=1.5, ls="--",
                label="Expected (uniform)")
    ax1.set_xlim(0, 255)
    ax1.set_xlabel("Byte value (0–255)")
    ax1.set_ylabel("Count")
    ax1.set_title("Byte Value Histogram")
    ax1.legend(fontsize=8)

    # Bit balance pie
    n1 = sum(bits)
    n0 = len(bits) - n1
    ax2.pie([n0, n1],
            labels=[f"|0⟩ bits ({n0}/{len(bits)})", f"|1⟩ bits ({n1}/{len(bits)})"],
            colors=["#3498db", "#e74c3c"],
            autopct="%1.1f%%",
            startangle=90,
            wedgeprops={"edgecolor": "white", "linewidth": 2})
    ax2.set_title(f"Bit Balance  ({len(bits)} total bits)")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    if show:
        plt.show()
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# All-in-one demo
# ─────────────────────────────────────────────────────────────────────────────

def render_all_demo(save_dir: str = ".") -> List[str]:
    """
    Generate all visualisations and save to `save_dir`.
    Returns list of saved file paths.
    """
    if not MPL_AVAILABLE:
        print("[bloch_viz] matplotlib not installed — skipping all plots")
        return []

    import os
    os.makedirs(save_dir, exist_ok=True)
    saved = []

    # 1. Bloch sphere with common states
    states  = [Qubit.zero(), Qubit.plus(), Qubit.one(), Qubit.minus()]
    labels  = ["|0⟩", "|+⟩", "|1⟩", "|−⟩"]
    p = os.path.join(save_dir, "bloch_states.png")
    plot_bloch_sphere(states, labels, "Common Qubit States", save_path=p, show=False)
    saved.append(p); print(f"  Saved: {p}")

    # 2. Gate evolution
    p = os.path.join(save_dir, "gate_evolution.png")
    plot_gate_evolution(["H", "Z", "H", "X"], save_path=p, show=False)
    saved.append(p); print(f"  Saved: {p}")

    # 3. BB84 session
    from bb84 import run_bb84
    result = run_bb84(num_qubits=128, eavesdrop=False)
    p = os.path.join(save_dir, "bb84_session.png")
    plot_bb84_session(result, n_show=64, save_path=p, show=False)
    saved.append(p); print(f"  Saved: {p}")

    # 4. CHSH comparison
    from e91 import run_e91
    r_clean = run_e91(num_pairs=500, eavesdrop=False)
    r_eve   = run_e91(num_pairs=500, eavesdrop=True)
    p = os.path.join(save_dir, "chsh_comparison.png")
    plot_chsh_comparison([
        ("E91 (no Eve)",    r_clean.chsh_S, "#2ecc71"),
        ("E91 (with Eve)",  r_eve.chsh_S,   "#e74c3c"),
        ("Classical bound", 2.0,             "#f39c12"),
    ], save_path=p, show=False)
    saved.append(p); print(f"  Saved: {p}")

    # 5. Key distribution
    p = os.path.join(save_dir, "key_distribution.png")
    plot_key_distribution(result.final_key_hex,
                          "BB84 Key Byte Distribution",
                          save_path=p, show=False)
    saved.append(p); print(f"  Saved: {p}")

    return saved
