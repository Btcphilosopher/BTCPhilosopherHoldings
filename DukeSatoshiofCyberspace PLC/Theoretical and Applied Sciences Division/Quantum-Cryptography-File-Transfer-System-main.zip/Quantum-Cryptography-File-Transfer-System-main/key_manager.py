"""
key_manager.py — Password-Protected Quantum Key Vault
=======================================================
Stores named quantum keys in an encrypted local vault file.
The vault itself is AES-256-GCM encrypted using a password-derived key
(Scrypt KDF) so no plaintext key ever touches disk.

Vault file layout (.qvault):
  ┌─────────────────────────────────────────────────────┐
  │  Magic       │ 8 bytes  │ "QVAULT\x01"              │
  │  Scrypt salt │ 32 bytes │ random, stored in clear   │
  │  Nonce       │ 12 bytes │ AES-GCM nonce             │
  │  Tag         │ 16 bytes │ GCM authentication tag    │
  │  Payload     │ variable │ JSON of key entries       │
  └─────────────────────────────────────────────────────┘

Key entry JSON schema:
  {
    "name":        str,          # human label
    "key_hex":     str,          # 64-char hex AES-256 key
    "protocol":    str,          # "bb84" | "e91"
    "created_at":  ISO timestamp,
    "num_qubits":  int,          # qubits/pairs used
    "qber":        float,        # QBER at generation time
    "notes":       str           # optional free text
  }
"""

import os
import json
import struct
import hashlib
import datetime
from typing import List, Optional, Dict, Any
from dataclasses import dataclass, field, asdict

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.backends import default_backend


# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────

VAULT_MAGIC   = b"QVAULT\x01\x00"   # 8 bytes
SALT_SIZE     = 32
NONCE_SIZE    = 12
TAG_SIZE      = 16
HEADER_SIZE   = len(VAULT_MAGIC) + SALT_SIZE + NONCE_SIZE + TAG_SIZE  # 68 bytes

# Scrypt parameters (interactive login strength: ~100ms on modern hardware)
SCRYPT_N = 2 ** 15   # CPU/memory cost
SCRYPT_R = 8
SCRYPT_P = 1
SCRYPT_KEY_LEN = 32


# ─────────────────────────────────────────────────────────────────────────────
# Data model
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class KeyEntry:
    """A single named quantum key stored in the vault."""
    name:       str
    key_hex:    str
    protocol:   str   = "bb84"
    created_at: str   = field(default_factory=lambda: datetime.datetime.utcnow().isoformat())
    num_qubits: int   = 0
    qber:       float = 0.0
    notes:      str   = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "KeyEntry":
        return cls(**{k: d[k] for k in cls.__dataclass_fields__ if k in d})

    @property
    def key_bytes(self) -> bytes:
        return bytes.fromhex(self.key_hex)

    @property
    def length_bits(self) -> int:
        return len(self.key_hex) * 4

    def summary(self) -> str:
        return (
            f"[{self.name}]  {self.length_bits}-bit  "
            f"protocol={self.protocol}  "
            f"qber={self.qber:.2%}  "
            f"created={self.created_at[:19]}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# KDF
# ─────────────────────────────────────────────────────────────────────────────

def _derive_vault_key(password: str, salt: bytes) -> bytes:
    """Derive a 256-bit vault key from a password using Scrypt."""
    kdf = Scrypt(
        salt=salt,
        length=SCRYPT_KEY_LEN,
        n=SCRYPT_N,
        r=SCRYPT_R,
        p=SCRYPT_P,
        backend=default_backend(),
    )
    return kdf.derive(password.encode("utf-8"))


# ─────────────────────────────────────────────────────────────────────────────
# Vault class
# ─────────────────────────────────────────────────────────────────────────────

class KeyVault:
    """
    Encrypted local key vault.

    Usage
    -----
    vault = KeyVault("keys.qvault")
    vault.unlock("my_password")           # or .create("my_password") for new vault
    vault.add_key(entry)
    vault.save()
    vault.lock()

    key = vault.get("alice_key")          # returns KeyEntry
    """

    def __init__(self, path: str):
        self.path   = path
        self._keys: Dict[str, KeyEntry] = {}
        self._unlocked = False
        self._vault_key: Optional[bytes] = None

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def create(self, password: str) -> None:
        """
        Create a new empty vault at self.path protected by `password`.
        Raises FileExistsError if the vault already exists.
        """
        if os.path.exists(self.path):
            raise FileExistsError(
                f"Vault already exists at '{self.path}'. "
                f"Use unlock() to open it."
            )
        self._keys = {}
        self._unlocked = True
        self._vault_key = None   # will be set on save()
        self._password  = password
        self.save(password)

    def unlock(self, password: str) -> None:
        """
        Open and decrypt an existing vault.
        Raises ValueError if the password is wrong.
        """
        if not os.path.exists(self.path):
            raise FileNotFoundError(
                f"Vault not found at '{self.path}'. "
                f"Use create() to make a new one."
            )
        entries = self._load_and_decrypt(password)
        self._keys = {e.name: e for e in entries}
        self._unlocked = True
        self._password  = password

    def lock(self) -> None:
        """Zero sensitive data and mark vault as locked."""
        self._keys = {}
        self._unlocked = False
        self._vault_key = None
        self._password  = ""

    def save(self, password: Optional[str] = None) -> None:
        """Encrypt and write the vault to disk."""
        self._require_unlocked()
        pwd = password or self._password
        self._encrypt_and_save(list(self._keys.values()), pwd)

    # ── Key operations ────────────────────────────────────────────────────────

    def add_key(self, entry: KeyEntry, overwrite: bool = False) -> None:
        """Add a KeyEntry to the vault (in memory; call save() to persist)."""
        self._require_unlocked()
        if entry.name in self._keys and not overwrite:
            raise KeyError(
                f"Key '{entry.name}' already exists. "
                f"Use overwrite=True to replace it."
            )
        self._keys[entry.name] = entry

    def get(self, name: str) -> KeyEntry:
        """Retrieve a key by name."""
        self._require_unlocked()
        if name not in self._keys:
            raise KeyError(f"Key '{name}' not found in vault.")
        return self._keys[name]

    def delete(self, name: str) -> None:
        """Remove a key by name (in memory; call save() to persist)."""
        self._require_unlocked()
        if name not in self._keys:
            raise KeyError(f"Key '{name}' not found.")
        del self._keys[name]

    def list_keys(self) -> List[KeyEntry]:
        """Return all stored keys sorted by creation time."""
        self._require_unlocked()
        return sorted(self._keys.values(), key=lambda e: e.created_at)

    def rename(self, old_name: str, new_name: str) -> None:
        """Rename a key."""
        self._require_unlocked()
        entry = self.get(old_name)
        if new_name in self._keys:
            raise KeyError(f"A key named '{new_name}' already exists.")
        entry.name = new_name
        del self._keys[old_name]
        self._keys[new_name] = entry

    def change_password(self, old_password: str, new_password: str) -> None:
        """
        Re-encrypt the vault with a new password.
        Old password is verified before proceeding.
        """
        if not self._unlocked:
            self.unlock(old_password)
        self._password = new_password
        self.save(new_password)

    # ── Internals ─────────────────────────────────────────────────────────────

    def _require_unlocked(self):
        if not self._unlocked:
            raise PermissionError("Vault is locked. Call unlock() first.")

    def _encrypt_and_save(self, entries: List[KeyEntry], password: str) -> None:
        """Serialize, encrypt, and write entries to disk."""
        payload = json.dumps(
            [e.to_dict() for e in entries],
            indent=2,
        ).encode("utf-8")

        salt  = os.urandom(SALT_SIZE)
        nonce = os.urandom(NONCE_SIZE)
        key   = _derive_vault_key(password, salt)

        aesgcm = AESGCM(key)
        # AESGCM.encrypt() appends 16-byte tag
        ct_with_tag = aesgcm.encrypt(nonce, payload, None)
        ct  = ct_with_tag[:-TAG_SIZE]
        tag = ct_with_tag[-TAG_SIZE:]

        with open(self.path, "wb") as f:
            f.write(VAULT_MAGIC)
            f.write(salt)
            f.write(nonce)
            f.write(tag)
            f.write(ct)

        # Zero the KDF key from local scope (best-effort)
        key = b"\x00" * 32

    def _load_and_decrypt(self, password: str) -> List[KeyEntry]:
        """Read, decrypt, and parse the vault file."""
        with open(self.path, "rb") as f:
            magic = f.read(len(VAULT_MAGIC))
            if magic != VAULT_MAGIC:
                raise ValueError("Not a valid .qvault file or file is corrupted.")
            salt  = f.read(SALT_SIZE)
            nonce = f.read(NONCE_SIZE)
            tag   = f.read(TAG_SIZE)
            ct    = f.read()

        vault_key = _derive_vault_key(password, salt)
        aesgcm    = AESGCM(vault_key)

        try:
            payload = aesgcm.decrypt(nonce, ct + tag, None)
        except Exception:
            raise ValueError(
                "Failed to decrypt vault — wrong password or corrupted file."
            )

        entries_raw = json.loads(payload.decode("utf-8"))
        vault_key   = b"\x00" * 32   # zero
        return [KeyEntry.from_dict(d) for d in entries_raw]

    # ── Dunder helpers ────────────────────────────────────────────────────────

    def __len__(self) -> int:
        return len(self._keys)

    def __contains__(self, name: str) -> bool:
        return name in self._keys

    def __repr__(self) -> str:
        status = "unlocked" if self._unlocked else "locked"
        return f"<KeyVault path='{self.path}' status={status} keys={len(self._keys)}>"


# ─────────────────────────────────────────────────────────────────────────────
# Convenience helpers
# ─────────────────────────────────────────────────────────────────────────────

def vault_from_bb84(
    result,                          # BB84Result
    name: str,
    notes: str = "",
) -> KeyEntry:
    """Build a KeyEntry from a BB84Result."""
    return KeyEntry(
        name       = name,
        key_hex    = result.final_key_hex,
        protocol   = "bb84",
        num_qubits = result.num_qubits,
        qber       = result.error_rate,
        notes      = notes,
    )


def vault_from_e91(
    result,                          # E91Result
    name: str,
    notes: str = "",
) -> KeyEntry:
    """Build a KeyEntry from an E91Result."""
    return KeyEntry(
        name       = name,
        key_hex    = result.final_key_hex,
        protocol   = "e91",
        num_qubits = result.num_pairs,
        qber       = result.error_rate,
        notes      = notes,
    )


def print_vault_table(vault: "KeyVault") -> None:
    """Pretty-print all keys in the vault."""
    keys = vault.list_keys()
    if not keys:
        print("  (vault is empty)")
        return

    try:
        from rich.table import Table
        from rich.console import Console
        from rich import box
        t = Table(title=f"Key Vault — {vault.path}", box=box.ROUNDED)
        t.add_column("#",          justify="right", style="dim")
        t.add_column("Name",       style="bold cyan")
        t.add_column("Protocol",   justify="center")
        t.add_column("Bits",       justify="right")
        t.add_column("QBER",       justify="right")
        t.add_column("Qubits",     justify="right")
        t.add_column("Created",    style="dim")
        t.add_column("Notes")

        for i, e in enumerate(keys, 1):
            t.add_row(
                str(i),
                e.name,
                e.protocol.upper(),
                str(e.length_bits),
                f"{e.qber:.2%}",
                str(e.num_qubits),
                e.created_at[:19],
                e.notes[:30],
            )
        Console().print(t)
    except ImportError:
        print(f"\nKey Vault — {vault.path}")
        print(f"  {'#':>3}  {'Name':<20}  {'Proto':<5}  {'Bits':>6}  "
              f"{'QBER':>6}  {'Created':<19}  Notes")
        for i, e in enumerate(keys, 1):
            print(f"  {i:>3}  {e.name:<20}  {e.protocol.upper():<5}  "
                  f"{e.length_bits:>6}  {e.qber:.2%}  "
                  f"{e.created_at[:19]}  {e.notes[:30]}")
