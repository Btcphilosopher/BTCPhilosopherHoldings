"""
grover.py — Grover's Quantum Search Algorithm
===============================================
Simulates Grover's algorithm on small problem instances to demonstrate
quadratic quantum speedup and its implications for cryptographic key lengths.

Grover's algorithm (1996) finds a marked element in an unstructured database
of N items using O(√N) quantum queries, versus O(N) classically.

Cryptographic implications:
  • AES-128: Classical → 2^128 queries. Quantum → 2^64 queries.
             With Grover: effectively 64-bit security. VULNERABLE.
  • AES-256: Classical → 2^256 queries. Quantum → 2^128 queries.
             With Grover: effectively 128-bit security. SAFE.
  • SHA-256: Collision resistance 2^128 (Grover gives 2^85 preimage).
             Still safe but watch for quantum collision attacks.

Why BB84/E91 are quantum-safe:
  • QKD security is INFORMATION-THEORETIC, not computational.
  • Eve's information is bounded by physics (QBER), not computing power.
  • No algorithm — quantum or classical — can break the Shannon security
    guarantee of privacy amplification when QBER < threshold.

Implementation:
  • Full state-vector simulation for n ≤ 20 qubits (2^20 = 1M states)
  • Classical oracle (marks a random target state)
  • Grover diffusion operator (amplitude amplification)
  • Verification of quadratic speedup O(√N) vs O(N)

References:
  Grover, L.K. (1996). "A fast quantum mechanical algorithm for database search."
  Proceedings of STOC, pp. 212-219.

  Brassard et al. (2002). "Quantum Amplitude Amplification and Estimation."
  Contemporary Mathematics, 305, 53-74.
"""

import math
import time
from typing import List, Optional, Tuple, Dict, Any
from dataclasses import dataclass, field

import numpy as np


# ─────────────────────────────────────────────────────────────────────────────
# Core Grover simulation
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class GroverResult:
    """Result of a Grover's algorithm simulation."""
    n_qubits:           int
    n_states:           int        # N = 2^n
    target_state:       int        # the marked state
    found_state:        int        # state with highest amplitude after iterations
    iterations:         int        # Grover iterations performed
    optimal_iterations: int        # ⌊π/4 · √N⌋ = theoretical optimum
    success_prob:       float      # P(measuring target state)
    classical_queries:  float      # O(N) expected queries classically
    quantum_queries:    int        # O(√N) queries via Grover
    speedup_factor:     float      # classical / quantum
    duration_ms:        float

    @property
    def correct(self) -> bool:
        return self.found_state == self.target_state

    def summary(self) -> str:
        return (
            f"n_qubits:      {self.n_qubits}\n"
            f"N (database):  {self.n_states:,}\n"
            f"target state:  {self.target_state} (binary: {self.target_state:0{self.n_qubits}b})\n"
            f"found state:   {self.found_state} {'✓' if self.correct else '✗'}\n"
            f"iterations:    {self.iterations} (optimal: {self.optimal_iterations})\n"
            f"success P:     {self.success_prob:.4f} ({self.success_prob*100:.1f}%)\n"
            f"classical:     {self.classical_queries:,.0f} expected queries\n"
            f"quantum:       {self.quantum_queries} Grover iterations\n"
            f"speedup:       {self.speedup_factor:.1f}×\n"
            f"time:          {self.duration_ms:.2f} ms"
        )


def grover_simulate(
    n_qubits:   int,
    target:     Optional[int] = None,
    iterations: Optional[int] = None,
    verbose:    bool = False,
) -> GroverResult:
    """
    Simulate Grover's algorithm on an n-qubit register.

    Parameters
    ----------
    n_qubits   : number of qubits (database size N = 2^n_qubits)
    target     : target state index (random if None)
    iterations : Grover iterations (optimal π/4·√N if None)
    verbose    : print per-iteration amplitude of target state

    Returns
    -------
    GroverResult with full statistics.

    Note: n_qubits ≤ 20 due to memory (2^20 × 16B ≈ 16MB state vector).
    """
    if n_qubits < 1 or n_qubits > 20:
        raise ValueError(f"n_qubits must be 1–20, got {n_qubits}")

    N = 2 ** n_qubits

    if target is None:
        target = np.random.randint(0, N)

    # Optimal Grover iterations: ⌊π/4 · √N⌋
    opt_iters = max(1, int(math.pi / 4 * math.sqrt(N)))
    if iterations is None:
        iterations = opt_iters

    t0 = time.perf_counter()

    # ── Initialise uniform superposition ─────────────────────────────────────
    # |ψ₀⟩ = H^⊗n|0⟩ = 1/√N · Σ|x⟩
    state = np.ones(N, dtype=complex) / math.sqrt(N)

    if verbose:
        print(f"  [Grover] n={n_qubits} N={N:,} target={target} "
              f"iterations={iterations} (optimal={opt_iters})")
        print(f"  Iter 0:  P(target) = {abs(state[target])**2:.6f}  "
              f"(expected 1/{N} = {1/N:.6f})")

    # ── Grover iterations ─────────────────────────────────────────────────────
    for it in range(iterations):
        # Step 1: Oracle — flip the amplitude of the target state
        state[target] *= -1.0

        # Step 2: Diffusion operator (inversion about the mean)
        # D = 2|ψ⟩⟨ψ| - I
        # Efficiently: mean → scale → subtract
        mean    = state.mean()
        state   = 2.0 * mean - state
        # Note: this applies -(I - 2|ψ⟩⟨ψ|) which is equivalent with phase

        # Fix: correct Grover diffusion is: state = 2*mean*ones - state
        # which equals 2*mean - state per element — already done above

        if verbose:
            p = abs(state[target]) ** 2
            print(f"  Iter {it+1:3d}: P(target) = {p:.6f}  "
                  f"{'[PEAK]' if it == opt_iters - 1 else ''}")

    # ── Measurement ───────────────────────────────────────────────────────────
    probs = np.abs(state) ** 2
    probs /= probs.sum()   # renormalise

    measured = int(np.random.choice(N, p=probs))
    p_target = float(probs[target])

    dt = (time.perf_counter() - t0) * 1000

    # Classical expected queries: N/2 on average (uniform random search)
    classical = N / 2.0
    speedup   = classical / max(iterations, 1)

    return GroverResult(
        n_qubits           = n_qubits,
        n_states           = N,
        target_state       = target,
        found_state        = measured,
        iterations         = iterations,
        optimal_iterations = opt_iters,
        success_prob       = p_target,
        classical_queries  = classical,
        quantum_queries    = iterations,
        speedup_factor     = speedup,
        duration_ms        = dt,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Success probability sweep
# ─────────────────────────────────────────────────────────────────────────────

def grover_success_vs_iterations(
    n_qubits:   int,
    target:     Optional[int] = None,
    max_iters:  Optional[int] = None,
) -> List[Tuple[int, float]]:
    """
    Compute Grover's success probability vs number of iterations.

    Returns list of (iteration, P(success)) pairs.
    The probability oscillates: rises to maximum at π/4·√N,
    then falls back toward 0 — this is the quantum "over-rotation".
    """
    N = 2 ** n_qubits
    if target is None:
        target = np.random.randint(0, N)

    opt_iters  = int(math.pi / 4 * math.sqrt(N))
    if max_iters is None:
        max_iters = min(opt_iters * 3, 1000)

    state   = np.ones(N, dtype=complex) / math.sqrt(N)
    results = [(0, float(abs(state[target]) ** 2))]

    for it in range(1, max_iters + 1):
        state[target] *= -1.0
        mean   = state.mean()
        state  = 2.0 * mean - state
        p      = float(abs(state[target]) ** 2)
        results.append((it, p))

    return results


# ─────────────────────────────────────────────────────────────────────────────
# Cryptographic security analysis
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class SecurityLevel:
    """Security level of a cryptographic primitive against quantum attacks."""
    name:                str
    classical_key_bits:  int
    post_grover_bits:    int      # effective security after Grover
    grover_queries:      float    # √(2^n) queries Eve needs
    safe_against_grover: bool
    recommendation:      str


CRYPTO_SECURITY: Dict[str, SecurityLevel] = {
    "AES-128": SecurityLevel(
        name               = "AES-128",
        classical_key_bits = 128,
        post_grover_bits   = 64,
        grover_queries     = 2 ** 64,
        safe_against_grover= False,
        recommendation     = "Upgrade to AES-256 (NIST PQC recommendation)",
    ),
    "AES-192": SecurityLevel(
        name               = "AES-192",
        classical_key_bits = 192,
        post_grover_bits   = 96,
        grover_queries     = 2 ** 96,
        safe_against_grover= True,
        recommendation     = "Adequate but AES-256 preferred",
    ),
    "AES-256": SecurityLevel(
        name               = "AES-256",
        classical_key_bits = 256,
        post_grover_bits   = 128,
        grover_queries     = 2 ** 128,
        safe_against_grover= True,
        recommendation     = "Quantum-safe. Use with QKD-generated keys.",
    ),
    "RSA-2048": SecurityLevel(
        name               = "RSA-2048",
        classical_key_bits = 112,   # effective
        post_grover_bits   = 0,     # broken by Shor's, not Grover's
        grover_queries     = 0,
        safe_against_grover= False,
        recommendation     = "BROKEN by Shor's algorithm. Migrate to PQC.",
    ),
    "SHA-256": SecurityLevel(
        name               = "SHA-256",
        classical_key_bits = 256,
        post_grover_bits   = 128,   # preimage: 2^128 (Grover)
        grover_queries     = 2 ** 128,
        safe_against_grover= True,
        recommendation     = "Safe for preimage. Watch collision resistance.",
    ),
    "SHA-3-256": SecurityLevel(
        name               = "SHA-3-256",
        classical_key_bits = 256,
        post_grover_bits   = 128,
        grover_queries     = 2 ** 128,
        safe_against_grover= True,
        recommendation     = "Quantum-safe for preimage resistance.",
    ),
    "QKD-BB84": SecurityLevel(
        name               = "QKD-BB84",
        classical_key_bits = 256,    # typical AES-256 output
        post_grover_bits   = 256,    # information-theoretic — Grover doesn't apply
        grover_queries     = float("inf"),
        safe_against_grover= True,
        recommendation     = "Information-theoretic security. Grover irrelevant.",
    ),
}


def print_security_analysis() -> None:
    """Print a comprehensive security table for cryptographic primitives."""
    try:
        from rich.table import Table
        from rich.console import Console
        from rich import box
        t = Table(
            title="Quantum Security Analysis — Grover's Algorithm Impact",
            box=box.ROUNDED, show_header=True,
        )
        t.add_column("Primitive",        style="bold", width=14)
        t.add_column("Classical bits",   justify="right", width=14)
        t.add_column("Post-Grover bits", justify="right", width=15)
        t.add_column("Grover queries",   justify="right", width=16)
        t.add_column("Quantum-safe",     justify="center", width=13)
        t.add_column("Recommendation",   style="dim", width=35)

        for name, s in CRYPTO_SECURITY.items():
            safe_c = "green" if s.safe_against_grover else "red"
            gq = ("∞ (IT-secure)" if s.grover_queries == float("inf")
                  else f"2^{int(math.log2(s.grover_queries))}" if s.grover_queries > 0
                  else "N/A (Shor)")
            t.add_row(
                name,
                str(s.classical_key_bits),
                str(s.post_grover_bits) if s.post_grover_bits > 0 else "BROKEN",
                gq,
                f"[{safe_c}]{'✓ YES' if s.safe_against_grover else '✗ NO'}[/]",
                s.recommendation,
            )
        Console().print(t)

    except ImportError:
        print(f"\n{'─'*80}")
        print("Quantum Security Analysis:")
        for name, s in CRYPTO_SECURITY.items():
            print(f"  {name:<14}  {s.classical_key_bits:>4} bits  "
                  f"PostGrover={s.post_grover_bits:>4}  "
                  f"Safe={'Y' if s.safe_against_grover else 'N'}  "
                  f"{s.recommendation[:40]}")


# ─────────────────────────────────────────────────────────────────────────────
# Visualisation (matplotlib)
# ─────────────────────────────────────────────────────────────────────────────

def plot_grover_oscillation(
    n_qubits:  int  = 6,
    save_path: str  = None,
    show:      bool = True,
):
    """
    Plot P(success) vs number of Grover iterations, showing the sine-wave
    oscillation and the optimal stopping point at ⌊π/4·√N⌋.
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return None

    N    = 2 ** n_qubits
    data = grover_success_vs_iterations(n_qubits)
    iters, probs = zip(*data)

    opt = int(math.pi / 4 * math.sqrt(N))

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(iters, probs, "b-", lw=2, label="P(success)")
    ax.axvline(opt, color="red",   ls="--", lw=1.5,
               label=f"Optimal: ⌊π√N/4⌋ = {opt}")
    ax.axhline(1/N, color="gray", ls=":",  lw=1,
               label=f"Classical (1/N = {1/N:.4f})")

    ax.scatter([opt], [probs[opt]], color="red", s=100, zorder=5)
    ax.annotate(f"P = {probs[opt]:.3f}",
                (opt, probs[opt]), textcoords="offset points",
                xytext=(10, -15), fontsize=9, color="red")

    ax.set_xlabel("Grover Iterations", fontsize=11)
    ax.set_ylabel("P(finding target)", fontsize=11)
    ax.set_title(f"Grover's Algorithm — {n_qubits} qubits, N = {N:,} states",
                 fontsize=13, fontweight="bold")
    ax.legend(fontsize=9); ax.grid(alpha=0.3)
    ax.set_ylim(-0.05, 1.05)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    if show:
        plt.show()
    return fig


def plot_grover_speedup(
    n_range:   List[int] = None,
    save_path: str       = None,
    show:      bool      = True,
):
    """
    Plot classical O(N) vs quantum O(√N) query complexity.
    Shows the quadratic separation growing with problem size.
    """
    try:
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError:
        return None

    if n_range is None:
        n_range = list(range(1, 21))

    ns      = [2 ** n for n in n_range]
    classic = [n / 2 for n in ns]           # O(N/2) classical average
    quantum = [int(math.pi / 4 * n ** 0.5) # O(√N·π/4) quantum
               for n in ns]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))
    fig.suptitle("Grover's Algorithm — Quantum Speedup", fontsize=13, fontweight="bold")

    ax1.semilogy(n_range, classic, "r-o", ms=5, lw=2, label="Classical O(N/2)")
    ax1.semilogy(n_range, quantum, "b-s", ms=5, lw=2, label="Quantum O(π√N/4)")
    ax1.set_xlabel("n (qubits)", fontsize=11)
    ax1.set_ylabel("Queries (log scale)", fontsize=11)
    ax1.set_title("Query Complexity", fontsize=11)
    ax1.legend(fontsize=9); ax1.grid(alpha=0.3, which="both")

    # Speedup factor N / √N = √N
    speedup = [c / q for c, q in zip(classic, quantum)]
    ax2.plot(n_range, speedup, "g-^", ms=5, lw=2, label="Speedup = N / √N = √N")
    ax2.set_xlabel("n (qubits)", fontsize=11)
    ax2.set_ylabel("Speedup factor", fontsize=11)
    ax2.set_title("Quantum Speedup (×)", fontsize=11)
    ax2.legend(fontsize=9); ax2.grid(alpha=0.3)

    # Annotate AES key lengths
    for label, bits in [("AES-128", 128), ("AES-256", 256)]:
        if bits // 1 <= max(n_range):
            continue   # beyond plot range, skip
        n_equiv = bits
        speedup_equiv = math.sqrt(2 ** min(bits, 20))
        ax2.annotate(label, (min(n_range + [bits // 2]), speedup_equiv),
                     fontsize=8, color="purple")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    if show:
        plt.show()
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# Demo + validation sweep
# ─────────────────────────────────────────────────────────────────────────────

def run_grover_demo(
    n_qubits_list: List[int] = None,
    verbose:       bool      = True,
) -> List[GroverResult]:
    """
    Run Grover's algorithm across a range of problem sizes and validate
    that the success rate matches the theoretical prediction.

    Parameters
    ----------
    n_qubits_list : qubit counts to test (default: 2, 4, 6, 8, 10)

    Returns
    -------
    List of GroverResult, one per problem size.
    """
    if n_qubits_list is None:
        n_qubits_list = [2, 4, 6, 8, 10]

    results = []

    for n in n_qubits_list:
        N   = 2 ** n
        opt = int(math.pi / 4 * math.sqrt(N))

        # Theoretical success probability at optimal iterations:
        # P_opt ≈ sin²((2k+1)·θ) where sin(θ) = 1/√N, k = iterations
        # Approximately: P_opt ≈ 1 - 1/N for large N
        theta   = math.asin(1 / math.sqrt(N))
        angle   = (2 * opt + 1) * theta
        p_theory = math.sin(angle) ** 2

        r = grover_simulate(n, verbose=False)

        if verbose:
            match = "✓" if r.correct else "✗"
            print(f"  n={n:2d}  N={N:>6,}  iters={r.iterations:>4}  "
                  f"P={r.success_prob:.4f}  (theory={p_theory:.4f})  "
                  f"speedup={r.speedup_factor:.1f}×  {match}")

        results.append(r)

    return results


# ─────────────────────────────────────────────────────────────────────────────
# CLI entry point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Grover's Algorithm Demo")
    parser.add_argument("--qubits",   type=int, default=8,
                        help="Number of qubits (database size = 2^n)")
    parser.add_argument("--demo",     action="store_true",
                        help="Run demo across multiple qubit counts")
    parser.add_argument("--security", action="store_true",
                        help="Print cryptographic security table")
    parser.add_argument("--plot",     action="store_true",
                        help="Show oscillation and speedup plots")
    parser.add_argument("--verbose",  action="store_true")
    args = parser.parse_args()

    if args.security:
        print_security_analysis()

    if args.demo:
        print("\nGrover's Algorithm — Speedup Demonstration:")
        run_grover_demo(verbose=True)

    if not args.demo:
        print(f"\nGrover simulation (n={args.qubits}):")
        r = grover_simulate(args.qubits, verbose=args.verbose)
        print(r.summary())

    if args.plot:
        plot_grover_oscillation(args.qubits if args.qubits <= 10 else 8)
        plot_grover_speedup()
