"""
benchmarks.py — Performance Benchmarking Suite
===============================================
Measures and reports:

  1. Qubit gate throughput  (gates/second)
  2. BB84 key generation    (keys/second, bits/second)
  3. E91 key generation     (keys/second, CHSH accuracy)
  4. AES-256-GCM throughput (MB/s encrypt + decrypt)
  5. Vault operations       (open/close/read latency)
  6. Network session timing (full Alice↔Bob round-trip)
  7. Noise channel overhead (overhead vs ideal)

Run with:  python benchmarks.py
Or import: from benchmarks import run_all_benchmarks
"""

import time
import os
import sys
import tempfile
import statistics
from typing import List, Callable, Optional, Dict, Any
from dataclasses import dataclass, field

import numpy as np


# ─────────────────────────────────────────────────────────────────────────────
# Timer utility
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class BenchResult:
    """Result of a single benchmark run."""
    name:        str
    unit:        str
    value:       float
    std_dev:     float   = 0.0
    trials:      int     = 1
    details:     dict    = field(default_factory=dict)
    passed:      bool    = True

    def __str__(self) -> str:
        pm = f" ± {self.std_dev:.2f}" if self.std_dev > 0 else ""
        return f"{self.name:<45}  {self.value:>10.2f}{pm}  {self.unit}"


def _timeit(fn: Callable, trials: int = 5) -> tuple[float, float, Any]:
    """
    Run fn() `trials` times and return (mean_ms, std_ms, last_result).
    Drops the slowest outlier when trials >= 5.
    """
    times   = []
    last    = None
    for _ in range(trials):
        t0   = time.perf_counter()
        last = fn()
        times.append((time.perf_counter() - t0) * 1000)

    if trials >= 5:
        times.remove(max(times))

    return statistics.mean(times), statistics.stdev(times) if len(times) > 1 else 0.0, last


# ─────────────────────────────────────────────────────────────────────────────
# Individual benchmarks
# ─────────────────────────────────────────────────────────────────────────────

def bench_qubit_gates(trials: int = 8) -> List[BenchResult]:
    """Measure throughput of single-qubit gate operations."""
    from qubit_sim import Qubit

    results = []
    N = 10_000   # gates per trial

    for gate_name, fn in [
        ("Hadamard",  lambda: [Qubit.zero().hadamard()   for _ in range(N)]),
        ("Pauli-X",   lambda: [Qubit.zero().pauli_x()    for _ in range(N)]),
        ("Pauli-Z",   lambda: [Qubit.zero().pauli_z()    for _ in range(N)]),
        ("Measure",   lambda: [Qubit.plus().measure()    for _ in range(N)]),
        ("H+X+Z+M",   lambda: [Qubit.zero().hadamard().pauli_x().pauli_z().measure()
                                for _ in range(N)]),
    ]:
        mean_ms, std_ms, _ = _timeit(fn, trials)
        throughput = N / (mean_ms / 1000)   # gates per second
        results.append(BenchResult(
            name    = f"Gate: {gate_name}",
            unit    = "gates/s",
            value   = throughput,
            std_dev = std_ms / mean_ms * throughput,
            trials  = trials,
            details = {"N": N, "mean_ms": round(mean_ms, 3)},
        ))

    # Bell pair generation
    from qubit_sim import TwoQubitSystem
    mean_ms, _, _ = _timeit(
        lambda: [TwoQubitSystem.create_bell_pair() for _ in range(1000)],
        trials,
    )
    results.append(BenchResult(
        name   = "Bell pair creation",
        unit   = "pairs/s",
        value  = 1000 / (mean_ms / 1000),
        trials = trials,
    ))

    return results


def bench_bb84(trials: int = 5) -> List[BenchResult]:
    """Benchmark BB84 key generation at various qubit counts."""
    from bb84 import run_bb84
    results = []

    for n_qubits in [128, 256, 512, 1024, 2048]:
        fn = lambda nq=n_qubits: run_bb84(nq, eavesdrop=False)
        mean_ms, std_ms, last = _timeit(fn, trials)

        key_bits = last.key_length_bits
        bits_per_sec = key_bits / (mean_ms / 1000)

        results.append(BenchResult(
            name    = f"BB84 key gen ({n_qubits} qubits)",
            unit    = "ms",
            value   = mean_ms,
            std_dev = std_ms,
            trials  = trials,
            details = {
                "key_bits":     key_bits,
                "efficiency":   f"{last.efficiency:.1%}",
                "bits_per_sec": round(bits_per_sec),
                "qber":         f"{last.error_rate:.2%}",
            },
        ))

    return results


def bench_e91(trials: int = 5) -> List[BenchResult]:
    """Benchmark E91 key generation at various pair counts."""
    from e91 import run_e91
    results = []

    for n_pairs in [200, 400, 800]:
        fn = lambda n=n_pairs: run_e91(n, eavesdrop=False)
        mean_ms, std_ms, last = _timeit(fn, trials)

        results.append(BenchResult(
            name    = f"E91 key gen ({n_pairs} pairs)",
            unit    = "ms",
            value   = mean_ms,
            std_dev = std_ms,
            trials  = trials,
            details = {
                "key_bits": last.key_length_bits,
                "chsh_S":   round(last.chsh_S, 4),
                "qber":     f"{last.error_rate:.2%}",
            },
        ))

    return results


def bench_aes(trials: int = 6) -> List[BenchResult]:
    """Benchmark AES-256-GCM encryption and decryption throughput."""
    from crypto import encrypt_bytes, decrypt_bytes
    results = []

    key_hex = os.urandom(32).hex()

    for size_bytes in [1024, 64*1024, 1024*1024, 10*1024*1024]:
        plaintext = os.urandom(size_bytes)

        # Encrypt
        enc_fn  = lambda pt=plaintext: encrypt_bytes(pt, key_hex)
        mean_e, std_e, blob = _timeit(enc_fn, trials)

        # Decrypt
        dec_fn  = lambda b=blob: decrypt_bytes(b, key_hex)
        mean_d, std_d, _   = _timeit(dec_fn, trials)

        mb = size_bytes / (1024 * 1024)
        label = (f"{size_bytes // 1024} KiB" if size_bytes < 1024*1024
                 else f"{size_bytes // (1024*1024)} MiB")

        results.append(BenchResult(
            name    = f"AES-256-GCM encrypt ({label})",
            unit    = "MB/s",
            value   = mb / (mean_e / 1000),
            std_dev = 0.0,
            trials  = trials,
            details = {"mean_ms": round(mean_e, 2), "size": label},
        ))
        results.append(BenchResult(
            name    = f"AES-256-GCM decrypt ({label})",
            unit    = "MB/s",
            value   = mb / (mean_d / 1000),
            trials  = trials,
        ))

    return results


def bench_vault(trials: int = 5) -> List[BenchResult]:
    """Benchmark vault create, save, unlock, and key retrieval."""
    from key_manager import KeyVault, KeyEntry
    from bb84 import run_bb84
    results = []

    with tempfile.TemporaryDirectory() as tmp:
        vault_path = os.path.join(tmp, "bench.qvault")
        password   = "benchmark_password_123"

        # Pre-populate vault with 20 keys
        v = KeyVault(vault_path)
        v.create(password)
        for i in range(20):
            r  = run_bb84(num_qubits=256)
            e  = KeyEntry(name=f"key_{i:03d}", key_hex=r.final_key_hex,
                          protocol="bb84", qber=r.error_rate)
            v.add_key(e)
        v.save()
        v.lock()

        # Unlock benchmark
        def do_unlock():
            v2 = KeyVault(vault_path)
            v2.unlock(password)
            return v2

        mean_ms, std_ms, v2 = _timeit(do_unlock, trials)
        results.append(BenchResult(
            name    = "Vault unlock (20 keys, Scrypt N=32768)",
            unit    = "ms",
            value   = mean_ms,
            std_dev = std_ms,
            trials  = trials,
        ))

        # Key retrieval
        mean_ms, _, _ = _timeit(lambda: v2.get("key_010"), trials * 5)
        results.append(BenchResult(
            name   = "Vault key lookup by name",
            unit   = "ms",
            value  = mean_ms,
            trials = trials * 5,
        ))

        # Save benchmark
        mean_ms, _, _ = _timeit(lambda: v2.save(), trials)
        results.append(BenchResult(
            name   = "Vault save (20 keys)",
            unit   = "ms",
            value  = mean_ms,
            trials = trials,
        ))

    return results


def bench_noise_overhead(trials: int = 4) -> List[BenchResult]:
    """Compare noisy BB84 overhead vs ideal channel."""
    from noise_model import NoiseConfig, run_bb84_noisy
    results = []

    n_qubits = 512

    configs = [
        ("ideal",            NoiseConfig.ideal()),
        ("depol p=0.01",     NoiseConfig(depolarizing_p=0.01)),
        ("depol p=0.05",     NoiseConfig(depolarizing_p=0.05)),
        ("fibre 10km",       NoiseConfig.fibre_10km()),
        ("fibre 50km",       NoiseConfig.fibre_50km()),
        ("superconducting",  NoiseConfig.superconducting()),
    ]

    for label, cfg in configs:
        fn = lambda c=cfg: run_bb84_noisy(n_qubits, c)
        try:
            mean_ms, std_ms, last = _timeit(fn, trials)
            qber = last.error_rate
            results.append(BenchResult(
                name    = f"BB84 noisy ({label})",
                unit    = "ms",
                value   = mean_ms,
                std_dev = std_ms,
                trials  = trials,
                details = {"qber": f"{qber:.2%}",
                           "key_bits": last.key_length_bits},
            ))
        except RuntimeError as exc:
            results.append(BenchResult(
                name   = f"BB84 noisy ({label})",
                unit   = "ms",
                value  = 0.0,
                passed = False,
                details = {"error": str(exc)[:60]},
            ))

    return results


def bench_network(trials: int = 2) -> List[BenchResult]:
    """Benchmark the full network Alice↔Bob round-trip."""
    from network_sim import run_network_session
    from noise_model import NoiseConfig
    results = []

    for label, nq, cfg in [
        ("ideal 128q",   128, NoiseConfig.ideal()),
        ("ideal 256q",   256, NoiseConfig.ideal()),
        ("10km  256q",   256, NoiseConfig.fibre_10km()),
    ]:
        times, qbers = [], []
        for _ in range(trials):
            r = run_network_session(nq, cfg, verbose=False)
            if not r.error:
                times.append(r.duration_ms)
                qbers.append(r.qber)

        if times:
            results.append(BenchResult(
                name    = f"Net session ({label})",
                unit    = "ms",
                value   = statistics.mean(times),
                std_dev = statistics.stdev(times) if len(times) > 1 else 0.0,
                trials  = trials,
                details = {"qber": f"{statistics.mean(qbers):.2%}",
                           "key_rate": "256-bit"},
            ))
        else:
            results.append(BenchResult(
                name  = f"Net session ({label})",
                unit  = "ms",
                value = 0.0, passed=False,
            ))

    return results


# ─────────────────────────────────────────────────────────────────────────────
# Report rendering
# ─────────────────────────────────────────────────────────────────────────────

def _print_section(title: str, results: List[BenchResult]) -> None:
    """Print a benchmark section."""
    try:
        from rich.console import Console
        from rich.table import Table
        from rich.rule import Rule
        from rich import box
        console = Console()
        console.print(Rule(f"[bold cyan]{title}[/]", style="cyan"))
        t = Table(box=box.SIMPLE, show_header=True)
        t.add_column("Benchmark",  style="bold", width=48)
        t.add_column("Value",      justify="right", width=12)
        t.add_column("Std Dev",    justify="right", width=10)
        t.add_column("Unit",       width=12)
        t.add_column("Details",    style="dim")
        for r in results:
            pm  = f"±{r.std_dev:.1f}" if r.std_dev > 0 else ""
            det = "  ".join(f"{k}={v}" for k, v in r.details.items())
            clr = "green" if r.passed else "red"
            t.add_row(
                f"[{clr}]{r.name}[/]",
                f"{r.value:.2f}",
                pm,
                r.unit,
                det,
            )
        console.print(t)
    except ImportError:
        print(f"\n{'='*60}\n  {title}\n{'='*60}")
        for r in results:
            pm  = f" ±{r.std_dev:.1f}" if r.std_dev > 0 else ""
            print(f"  {r}")


def plot_benchmark_summary(
    all_results: Dict[str, List[BenchResult]],
    save_path:   str  = None,
    show:        bool = True,
) -> None:
    """Generate a visual benchmark summary chart."""
    try:
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError:
        return

    # Focus on timing results for the main protocol operations
    bb84 = [r for r in all_results.get("BB84", []) if "ms" in r.unit]
    aes  = [r for r in all_results.get("AES",  []) if "MB/s" in r.unit
            and "encrypt" in r.name]

    if not bb84 and not aes:
        return

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    fig.suptitle("Quantum Crypto System — Benchmark Summary",
                 fontsize=13, fontweight="bold")

    # BB84 timing
    if bb84:
        labels = [r.name.split("(")[1].rstrip(")").strip() for r in bb84]
        vals   = [r.value  for r in bb84]
        errs   = [r.std_dev for r in bb84]
        colors = [f"#{int(220-i*25):02x}{int(100+i*20):02x}60" for i in range(len(bb84))]

        ax = axes[0]
        bars = ax.bar(range(len(labels)), vals, yerr=errs,
                      color=colors, edgecolor="black", lw=0.8, capsize=4)
        ax.set_xticks(range(len(labels)))
        ax.set_xticklabels(labels, rotation=30, ha="right", fontsize=8)
        ax.set_ylabel("Time (ms)", fontsize=10)
        ax.set_title("BB84 Key Generation Latency", fontsize=11)
        ax.grid(alpha=0.3, axis="y")
        for bar, val in zip(bars, vals):
            ax.text(bar.get_x() + bar.get_width()/2, val + max(vals)*0.01,
                    f"{val:.1f}", ha="center", va="bottom", fontsize=8)

    # AES throughput
    if aes:
        labels = [r.name.split("(")[1].rstrip(")") for r in aes]
        vals   = [r.value for r in aes]

        ax = axes[1]
        ax.barh(labels, vals, color="#4fc3f7", edgecolor="black", lw=0.8)
        ax.set_xlabel("Throughput (MB/s)", fontsize=10)
        ax.set_title("AES-256-GCM Encrypt Throughput", fontsize=11)
        ax.grid(alpha=0.3, axis="x")
        for i, (label, val) in enumerate(zip(labels, vals)):
            ax.text(val + max(vals)*0.01, i, f"{val:.0f} MB/s",
                    va="center", fontsize=8)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    if show:
        plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# Master runner
# ─────────────────────────────────────────────────────────────────────────────

def run_all_benchmarks(
    include_network:   bool = True,
    include_noise:     bool = True,
    save_chart:        str  = None,
    show_chart:        bool = False,
) -> Dict[str, List[BenchResult]]:
    """
    Run the complete benchmark suite.

    Parameters
    ----------
    include_network : run full TCP socket session benchmarks (slower)
    include_noise   : run noisy channel benchmarks
    save_chart      : path to save benchmark chart PNG
    show_chart      : show matplotlib chart interactively

    Returns
    -------
    Dict mapping section name → list of BenchResult
    """
    all_results: Dict[str, List[BenchResult]] = {}

    sections = [
        ("Qubit Gates",     bench_qubit_gates),
        ("BB84",            bench_bb84),
        ("E91",             bench_e91),
        ("AES-256-GCM",     bench_aes),
        ("Key Vault",       bench_vault),
    ]

    if include_noise:
        sections.append(("Noise Channels", bench_noise_overhead))
    if include_network:
        sections.append(("Network (TCP)",  bench_network))

    total_start = time.perf_counter()

    for name, fn in sections:
        print(f"\nRunning: {name}…")
        try:
            results = fn()
            all_results[name] = results
            _print_section(name, results)
        except Exception as exc:
            print(f"  [FAILED] {exc}")
            all_results[name] = []

    total_ms = (time.perf_counter() - total_start) * 1000
    print(f"\n{'─'*60}")
    print(f"  Total benchmark time: {total_ms/1000:.1f}s")

    if save_chart or show_chart:
        plot_benchmark_summary(all_results, save_path=save_chart, show=show_chart)

    return all_results


# ─────────────────────────────────────────────────────────────────────────────
# CLI entry point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Quantum Crypto Benchmark Suite")
    parser.add_argument("--no-network", action="store_true", help="Skip network benchmarks")
    parser.add_argument("--no-noise",   action="store_true", help="Skip noise benchmarks")
    parser.add_argument("--save-chart", metavar="FILE",      help="Save chart to PNG")
    parser.add_argument("--show-chart", action="store_true", help="Display chart")
    args = parser.parse_args()

    run_all_benchmarks(
        include_network = not args.no_network,
        include_noise   = not args.no_noise,
        save_chart      = args.save_chart,
        show_chart      = args.show_chart,
    )
