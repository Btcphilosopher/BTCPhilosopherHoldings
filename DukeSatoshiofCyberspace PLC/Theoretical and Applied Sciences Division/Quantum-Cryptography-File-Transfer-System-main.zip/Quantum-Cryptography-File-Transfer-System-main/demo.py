"""
demo.py — End-to-End Demo & Self-Test
======================================
Runs a complete demonstration of the quantum crypto system:
  1. Qubit gate tests
  2. BB84 key generation (with and without Eve)
  3. E91 key generation (with and without Eve)
  4. File encryption + decryption round-trip
  5. Integrity verification

Run with:  python demo.py
"""

import os
import sys
import tempfile
import hashlib

# ─────────────────────────────────────────────────────────────────────────────
# Rich setup
# ─────────────────────────────────────────────────────────────────────────────
try:
    from rich.console import Console
    from rich.rule import Rule
    from rich.panel import Panel
    console = Console()
    def section(title):
        console.print(Rule(f"[bold cyan]{title}[/]", style="cyan"))
    def ok(msg):  console.print(f"  [bold green]✓[/] {msg}")
    def err(msg): console.print(f"  [bold red]✗[/] {msg}")
    def info(msg):console.print(f"  [dim]{msg}[/]")
    def bold(msg):console.print(f"  [bold]{msg}[/]")
except ImportError:
    console = None
    def section(t): print(f"\n{'='*60}\n  {t}\n{'='*60}")
    def ok(m):   print(f"  OK  {m}")
    def err(m):  print(f"  ERR {m}")
    def info(m): print(f"      {m}")
    def bold(m): print(f"  **  {m}")


PASS = 0
FAIL = 0


def test(name: str, condition: bool, detail: str = ""):
    global PASS, FAIL
    if condition:
        ok(f"{name}  {detail}")
        PASS += 1
    else:
        err(f"{name}  {detail}")
        FAIL += 1


# ─────────────────────────────────────────────────────────────────────────────
# 1. Qubit simulation tests
# ─────────────────────────────────────────────────────────────────────────────

def test_qubits():
    section("1 · Qubit Simulation Tests")
    from qubit_sim import Qubit, TwoQubitSystem
    import numpy as np

    # |0⟩ state
    q = Qubit.zero()
    p0, p1 = q.probabilities
    test("P(0)=1 for |0⟩", abs(p0 - 1.0) < 1e-9, f"P(0)={p0:.4f}")
    test("P(1)=0 for |0⟩", abs(p1 - 0.0) < 1e-9, f"P(1)={p1:.4f}")

    # |0⟩ measures to 0 always
    results = [Qubit.zero().measure() for _ in range(20)]
    test("Deterministic |0⟩ measurement", all(r == 0 for r in results))

    # |1⟩ measures to 1 always
    results = [Qubit.one().measure() for _ in range(20)]
    test("Deterministic |1⟩ measurement", all(r == 1 for r in results))

    # Hadamard: |0⟩ → |+⟩ (50/50)
    results = [Qubit.zero().hadamard().measure() for _ in range(200)]
    ratio = sum(results) / 200
    test("Hadamard gives ~50% |1⟩", 0.35 < ratio < 0.65,
         f"ratio={ratio:.2f}")

    # Hadamard twice = identity
    q = Qubit.zero()
    q.hadamard().hadamard()
    p0, _ = q.probabilities
    test("H·H = I  (P(0)=1)", abs(p0 - 1.0) < 1e-9, f"P(0)={p0:.6f}")

    # Pauli-X flips
    q = Qubit.zero().pauli_x()
    _, p1 = q.probabilities
    test("Pauli-X flips |0⟩→|1⟩", abs(p1 - 1.0) < 1e-9)

    # Pauli-Z phase
    q = Qubit.plus().pauli_z()
    # |+⟩ → |−⟩: state = (1/√2, -1/√2)
    test("Pauli-Z converts |+⟩→|−⟩", abs(q.state[1].real + 1/np.sqrt(2)) < 1e-9)

    # Bell pair: correlated measurements
    corr_count = 0
    for _ in range(100):
        pair = TwoQubitSystem.bell_phi_plus()
        q0, q1 = pair.measure_both()
        if q0 == q1:
            corr_count += 1
    test("Bell Φ⁺: 100% correlated", corr_count == 100, f"{corr_count}/100")

    # Entanglement entropy of Bell state
    pair = TwoQubitSystem.bell_phi_plus()
    entropy = pair.entanglement_entropy()
    import math
    test("Bell state max entanglement entropy",
         abs(entropy - math.log(2)) < 1e-6, f"S={entropy:.4f}")

    # Separable state has zero entanglement
    sep = TwoQubitSystem()  # |00⟩
    entropy_sep = sep.entanglement_entropy()
    test("Separable state zero entropy",
         abs(entropy_sep) < 1e-9, f"S={entropy_sep:.4f}")


# ─────────────────────────────────────────────────────────────────────────────
# 2. BB84 protocol tests
# ─────────────────────────────────────────────────────────────────────────────

def test_bb84():
    section("2 · BB84 Key Distribution Tests")
    from bb84 import (run_bb84, random_bits, random_bases, alice_prepare,
                      bob_measure, sift_key, bits_to_bytes, bytes_to_bits)

    # Basic encoding/decoding in matching basis
    for basis in ["Z", "X"]:
        for bit in [0, 1]:
            from qubit_sim import Qubit
            q = Qubit.from_bit(bit, basis)
            measured = q.measure_in_basis(basis)
            test(f"Encode/measure bit={bit} basis={basis}", measured == bit,
                 f"got {measured}")

    # bits ↔ bytes roundtrip
    bits = [1, 0, 1, 1, 0, 0, 1, 0,  0, 1, 1, 0, 0, 1, 0, 1]
    b = bits_to_bytes(bits)
    recovered = bytes_to_bits(b)[:16]
    test("bits_to_bytes → bytes_to_bits roundtrip", recovered == bits)

    # Sifting keeps matching bases only
    a_bases = ["Z", "X", "Z", "X", "Z"]
    b_bases = ["Z", "Z", "Z", "X", "X"]
    indices = sift_key(a_bases, b_bases)
    test("Sift selects matching bases", indices == [0, 2, 3])

    # Full BB84 without Eve → low QBER
    result = run_bb84(num_qubits=512, eavesdrop=False)
    test("BB84 no-Eve QBER < 5%", result.error_rate < 0.05,
         f"QBER={result.error_rate:.2%}")
    test("BB84 generates 32-byte key", len(result.final_key_hex) == 64,
         f"len={len(result.final_key_hex)}")
    test("BB84 efficiency ~50%", 0.3 < result.efficiency < 0.7,
         f"eff={result.efficiency:.1%}")

    # BB84 with Eve → high QBER (should detect)
    eve_result = run_bb84(num_qubits=1024, eavesdrop=True,
                          error_threshold=1.0)  # don't abort, just check
    test("BB84 with Eve has higher QBER",
         eve_result.error_rate > 0.10,
         f"QBER={eve_result.error_rate:.2%}")

    # Abort on high QBER
    aborted = False
    try:
        run_bb84(num_qubits=512, eavesdrop=True, error_threshold=0.01)
    except RuntimeError as e:
        aborted = "ABORT" in str(e) or "threshold" in str(e).lower()
    test("BB84 aborts when QBER > threshold", aborted)

    info(f"BB84 key sample: {result.final_key_hex[:32]}…")


# ─────────────────────────────────────────────────────────────────────────────
# 3. E91 protocol tests
# ─────────────────────────────────────────────────────────────────────────────

def test_e91():
    section("3 · E91 Protocol Tests")
    from e91 import run_e91
    import math

    # Without Eve: Bell inequality should be violated (S > 2)
    result = run_e91(num_pairs=800, eavesdrop=False)
    test("E91 no-Eve: Bell inequality violated (S > 2)",
         result.chsh_S > 2.0, f"S={result.chsh_S:.4f}")
    test("E91 no-Eve: low error rate",
         result.error_rate < 0.1, f"err={result.error_rate:.2%}")
    test("E91 generates 32-byte key",
         len(result.final_key_hex) == 64)

    # With Eve: entanglement broken → S closer to 2 or below
    eve_result = run_e91(num_pairs=800, eavesdrop=True)
    test("E91 with Eve: Bell inequality NOT violated (S ≤ 2.1)",
         eve_result.chsh_S <= 2.1, f"S={eve_result.chsh_S:.4f}")
    test("E91 with Eve: high error rate",
         eve_result.error_rate > 0.1, f"err={eve_result.error_rate:.2%}")

    info(f"E91 key sample: {result.final_key_hex[:32]}…")


# ─────────────────────────────────────────────────────────────────────────────
# 4. Crypto module tests
# ─────────────────────────────────────────────────────────────────────────────

def test_crypto():
    section("4 · AES-256-GCM Encryption Tests")
    import os
    from crypto import (encrypt_bytes, decrypt_bytes, encrypt_file,
                        decrypt_file, verify_roundtrip, inspect_qcrypt_header,
                        validate_key_strength, derive_aes_key)

    # Known key (32 bytes)
    key_hex = os.urandom(32).hex()

    # ── In-memory encrypt/decrypt ─────────────────────────────────────────────
    plaintext = b"Hello, Quantum World! \x00\x01\x02\x03" * 100
    blob = encrypt_bytes(plaintext, key_hex)
    recovered = decrypt_bytes(blob, key_hex)
    test("In-memory encrypt/decrypt roundtrip", recovered == plaintext)
    test("Ciphertext differs from plaintext", blob != plaintext)

    # ── Wrong key fails GCM tag ───────────────────────────────────────────────
    wrong_key = os.urandom(32).hex()
    tamper_failed = False
    try:
        decrypt_bytes(blob, wrong_key)
    except Exception:
        tamper_failed = True
    test("Wrong key raises authentication error", tamper_failed)

    # ── Tampered ciphertext fails ─────────────────────────────────────────────
    tampered = bytearray(blob)
    tampered[-10] ^= 0xFF  # flip bytes in ciphertext
    tamper_failed2 = False
    try:
        decrypt_bytes(bytes(tampered), key_hex)
    except Exception:
        tamper_failed2 = True
    test("Tampered ciphertext raises error", tamper_failed2)

    # ── File encrypt/decrypt ──────────────────────────────────────────────────
    with tempfile.TemporaryDirectory() as tmp:
        orig_path = os.path.join(tmp, "original.txt")
        enc_path  = os.path.join(tmp, "original.txt.qcrypt")
        dec_path  = os.path.join(tmp, "decrypted.txt")

        test_data = b"Quantum secure file transfer test data.\n" * 500
        with open(orig_path, "wb") as f:
            f.write(test_data)

        enc_meta = encrypt_file(orig_path, enc_path, key_hex)
        test("File encrypted successfully",
             os.path.isfile(enc_path), f"size={enc_meta['output_size']}")

        dec_meta = decrypt_file(enc_path, dec_path, key_hex)
        test("File decrypted successfully",
             os.path.isfile(dec_path))
        test("GCM integrity verified", dec_meta["integrity_verified"])

        match = verify_roundtrip(orig_path, dec_path)
        test("Decrypted file matches original", match)

        # Inspect header
        header = inspect_qcrypt_header(enc_path)
        test("Header reads QCRYPT magic", header["magic"] == "514352595054010000"[:-2] or
             header["format"] == "AES-256-GCM")
        test("Header records plaintext size", header["plaintext_size"] == len(test_data),
             f"expected={len(test_data)}, got={header['plaintext_size']}")

    # ── Key derivation ────────────────────────────────────────────────────────
    raw = os.urandom(16)  # short input
    derived, salt = derive_aes_key(raw)
    test("HKDF derives 32-byte key", len(derived) == 32)

    # Same input + salt → same key (deterministic)
    derived2, _ = derive_aes_key(raw, salt=salt)
    test("HKDF is deterministic with same salt", derived == derived2)

    # ── Key strength ──────────────────────────────────────────────────────────
    quality = validate_key_strength(key_hex)
    test("Key strength rating not Weak",
         "Weak" not in quality["rating"], f"rating={quality['rating']}")


# ─────────────────────────────────────────────────────────────────────────────
# 5. Full pipeline integration test
# ─────────────────────────────────────────────────────────────────────────────

def test_integration():
    section("5 · Full Pipeline Integration Test")
    import tempfile, os
    from bb84 import run_bb84
    from crypto import encrypt_file, decrypt_file, verify_roundtrip

    # Generate key via BB84
    result = run_bb84(num_qubits=1024, eavesdrop=False)
    key_hex = result.final_key_hex
    test("BB84 key generated", len(key_hex) == 64)

    with tempfile.TemporaryDirectory() as tmp:
        # Create a test "file" (simulate a small document)
        orig_path = os.path.join(tmp, "document.txt")
        enc_path  = os.path.join(tmp, "document.txt.qcrypt")
        dec_path  = os.path.join(tmp, "document_recovered.txt")

        content = (
            "CONFIDENTIAL: Quantum cryptography demo document.\n"
            "This file was encrypted using a key generated by the BB84\n"
            "quantum key distribution protocol.\n"
            "AES-256-GCM ensures both confidentiality and integrity.\n"
        ).encode() * 100

        with open(orig_path, "wb") as f:
            f.write(content)

        # Encrypt
        enc_meta = encrypt_file(orig_path, enc_path, key_hex)
        test("Integration: file encrypted",
             os.path.isfile(enc_path))

        # Decrypt
        dec_meta = decrypt_file(enc_path, dec_path, key_hex)
        test("Integration: file decrypted",
             os.path.isfile(dec_path))

        # Verify
        ok_match = verify_roundtrip(orig_path, dec_path)
        test("Integration: round-trip verified", ok_match)

        # E91 pipeline
        from e91 import run_e91
        e91_result = run_e91(num_pairs=600, eavesdrop=False)
        e91_key    = e91_result.final_key_hex

        enc_path2 = os.path.join(tmp, "doc_e91.qcrypt")
        dec_path2 = os.path.join(tmp, "doc_e91_dec.txt")

        encrypt_file(orig_path, enc_path2, e91_key)
        decrypt_file(enc_path2, dec_path2, e91_key)
        test("E91 pipeline round-trip",
             verify_roundtrip(orig_path, dec_path2))

    info("All integration tests passed!")


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Quantum Crypto Self-Test")
    parser.add_argument("--extended", action="store_true",
                        help="Also run noise/network/benchmark tests (slower)")
    args, _ = parser.parse_known_args()

    if console:
        console.print("\n[bold cyan]Quantum Crypto Self-Test[/]\n")

    test_qubits()
    test_bb84()
    test_e91()
    test_crypto()
    test_integration()

    if args.extended:
        _run_extended()

    section("Test Summary")
    total = PASS + FAIL
    if FAIL == 0:
        msg = f"\n  All {total} tests passed\n"
        if console: console.print(msg)
        else: print(msg)
    else:
        msg = f"\n  {PASS} passed / {FAIL} failed / {total} total\n"
        if console: console.print(msg)
        else: print(msg)
        sys.exit(1)


if __name__ == "__main__":
    main()
