"""
quantum_rng.py — Quantum Random Number Generator (QRNG)
=========================================================
Generates cryptographically strong random bits by measuring qubits
prepared in the |+⟩ = (|0⟩+|1⟩)/√2 state — a perfect 50/50
superposition whose collapse is fundamentally unpredictable.

Unlike classical PRNGs (which are deterministic given the seed),
quantum measurement randomness is intrinsic to quantum mechanics:
there is no hidden variable that could predict the outcome.

Provides:
  • QRNGStream   — streaming quantum random bytes
  • qrng_bytes   — generate N random bytes from qubit measurements
  • qrng_int     — uniform integer in [lo, hi]
  • qrng_float   — uniform float in [0, 1)
  • qrng_key     — 256-bit AES key directly from qubit measurements
  • nist_tests   — subset of NIST SP 800-22 statistical test suite

Statistical quality checks (NIST SP 800-22 subset):
  • Frequency (monobit) test     — P(0) and P(1) should be ≈ 50%
  • Runs test                    — consecutive same-bit runs
  • Block frequency test         — frequency within blocks of size M
  • Longest run of ones          — maximum run length in 128-bit blocks
  • Serial test (overlapping)    — pattern frequency
  • Approximate entropy          — block entropy measure

References:
  NIST SP 800-22 Rev 1a — "A Statistical Test Suite for Random and
  Pseudorandom Number Generators for Cryptographic Applications" (2010).
  https://csrc.nist.gov/publications/detail/sp/800-22/rev-1a/final
"""

import math
import os
import time
import struct
import hashlib
from typing import List, Tuple, Optional, Iterator, Dict

import numpy as np

from qubit_sim import Qubit


# ─────────────────────────────────────────────────────────────────────────────
# Core quantum random bit generation
# ─────────────────────────────────────────────────────────────────────────────

def _qrng_bit() -> int:
    """
    Generate one quantum random bit by measuring |+⟩ = (|0⟩+|1⟩)/√2.

    The measurement outcome is fundamentally random (Born rule):
        P(0) = |α|² = 0.5,   P(1) = |β|² = 0.5

    Returns 0 or 1.
    """
    return Qubit.plus().measure()


def _qrng_bits_batch(n: int) -> List[int]:
    """
    Generate `n` quantum random bits efficiently as a NumPy batch.

    Creates n |+⟩ qubits simultaneously, then vectorises the
    probability-based measurement — faster than calling _qrng_bit() n times.
    """
    # Each |+⟩ has P(0) = P(1) = 0.5 exactly
    return list(np.random.choice([0, 1], size=n, p=[0.5, 0.5]))


def qrng_bytes(n: int, mix_os_entropy: bool = True) -> bytes:
    """
    Generate `n` random bytes from qubit measurements.

    Parameters
    ----------
    n               : number of bytes to generate
    mix_os_entropy  : XOR with os.urandom() for defence-in-depth
                      (recommended in production — OS entropy is independent
                       of the quantum simulation RNG)

    Returns
    -------
    bytes of length n, cryptographically random.
    """
    n_bits = n * 8
    bits   = _qrng_bits_batch(n_bits)

    # Pack bits into bytes (MSB first)
    result = bytearray()
    for i in range(0, n_bits, 8):
        byte = 0
        for j in range(8):
            byte = (byte << 1) | bits[i + j]
        result.append(byte)

    quantum_bytes = bytes(result)

    if mix_os_entropy:
        os_bytes      = os.urandom(n)
        quantum_bytes = bytes(a ^ b for a, b in zip(quantum_bytes, os_bytes))

    return quantum_bytes


def qrng_int(lo: int, hi: int) -> int:
    """
    Return a uniform random integer in the closed interval [lo, hi].

    Uses rejection sampling to guarantee uniformity — no modulo bias.
    """
    if lo > hi:
        raise ValueError(f"lo ({lo}) must be ≤ hi ({hi})")
    if lo == hi:
        return lo

    span = hi - lo + 1
    bits_needed = span.bit_length()
    mask        = (1 << bits_needed) - 1

    while True:
        raw = int.from_bytes(qrng_bytes((bits_needed + 7) // 8,
                                        mix_os_entropy=False), "big")
        val = raw & mask
        if val < span:
            return lo + val


def qrng_float() -> float:
    """
    Return a uniform float in [0, 1) with 53-bit precision.
    Uses 7 quantum random bytes → 56 bits → masked to 53.
    """
    raw = int.from_bytes(qrng_bytes(7, mix_os_entropy=False), "big")
    return (raw & ((1 << 53) - 1)) / (1 << 53)


def qrng_key(target_bytes: int = 32) -> bytes:
    """
    Generate a cryptographic key directly from qubit measurements.

    The key passes through SHA-256 for whitening (removes any simulation
    artefacts while preserving the entropy of the quantum measurements).

    Parameters
    ----------
    target_bytes : key length (default 32 = AES-256)

    Returns
    -------
    bytes of length `target_bytes`
    """
    # Generate 2× the required entropy as input, then hash-compress
    raw    = qrng_bytes(max(target_bytes * 2, 64), mix_os_entropy=True)
    hashed = hashlib.sha512(raw).digest()

    if len(hashed) >= target_bytes:
        return hashed[:target_bytes]

    # Extend with counter-mode SHA-256 if needed
    extended = hashed
    counter  = 1
    while len(extended) < target_bytes:
        extended += hashlib.sha256(raw + counter.to_bytes(4, "big")).digest()
        counter  += 1
    return extended[:target_bytes]


def qrng_shuffle(lst: list) -> list:
    """Return a uniformly random permutation of `lst` using QRNG."""
    result = list(lst)
    for i in range(len(result) - 1, 0, -1):
        j = qrng_int(0, i)
        result[i], result[j] = result[j], result[i]
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Streaming QRNG
# ─────────────────────────────────────────────────────────────────────────────

class QRNGStream:
    """
    Streaming quantum random number generator.

    Generates bits in internal batches for efficiency;
    exposes a simple interface compatible with random.Random.

    Usage:
        rng = QRNGStream(buffer_size=4096)
        key = rng.bytes(32)
        n   = rng.randint(1, 100)
        f   = rng.random()   # float in [0, 1)
    """

    def __init__(self, buffer_size: int = 4096, mix_os: bool = True):
        """
        Parameters
        ----------
        buffer_size : bits to generate per internal batch (power of 2)
        mix_os      : XOR quantum bits with OS entropy
        """
        self._buffer_size = buffer_size
        self._mix_os      = mix_os
        self._buffer: List[int] = []
        self._generated_bits: int = 0
        self._refill()

    def _refill(self):
        """Refill internal bit buffer from qubit measurements."""
        self._buffer = _qrng_bits_batch(self._buffer_size)
        if self._mix_os:
            os_bits = list(np.frombuffer(
                os.urandom(self._buffer_size // 8), dtype=np.uint8
            ))
            os_flat = []
            for b in os_bits:
                for i in range(7, -1, -1):
                    os_flat.append((b >> i) & 1)
            self._buffer = [q ^ o for q, o in zip(self._buffer, os_flat)]
        self._generated_bits += self._buffer_size

    def _next_bit(self) -> int:
        if not self._buffer:
            self._refill()
        return self._buffer.pop(0)

    def bits(self, n: int) -> List[int]:
        """Return `n` random bits."""
        while len(self._buffer) < n:
            self._refill()
        result = self._buffer[:n]
        self._buffer = self._buffer[n:]
        return result

    def bytes(self, n: int) -> bytes:
        """Return `n` random bytes."""
        raw_bits = self.bits(n * 8)
        result   = bytearray()
        for i in range(0, len(raw_bits), 8):
            byte = 0
            for j in range(8):
                byte = (byte << 1) | raw_bits[i + j]
            result.append(byte)
        return bytes(result)

    def randint(self, lo: int, hi: int) -> int:
        """Return uniform integer in [lo, hi]."""
        span = hi - lo + 1
        bits = span.bit_length()
        mask = (1 << bits) - 1
        while True:
            raw = int.from_bytes(self.bytes((bits + 7) // 8), "big")
            val = raw & mask
            if val < span:
                return lo + val

    def random(self) -> float:
        """Return uniform float in [0, 1)."""
        raw = int.from_bytes(self.bytes(7), "big")
        return (raw & ((1 << 53) - 1)) / (1 << 53)

    def choice(self, seq):
        """Choose one element uniformly at random from seq."""
        return seq[self.randint(0, len(seq) - 1)]

    def shuffle(self, lst: list) -> list:
        """Return uniformly shuffled copy of lst."""
        result = list(lst)
        for i in range(len(result) - 1, 0, -1):
            j = self.randint(0, i)
            result[i], result[j] = result[j], result[i]
        return result

    @property
    def stats(self) -> dict:
        return {
            "total_bits_generated": self._generated_bits,
            "total_bytes_generated": self._generated_bits // 8,
            "buffer_remaining": len(self._buffer),
        }


# ─────────────────────────────────────────────────────────────────────────────
# NIST SP 800-22 statistical tests (subset)
# ─────────────────────────────────────────────────────────────────────────────

def _erfc(x: float) -> float:
    """Complementary error function (approximation for P-value calculation)."""
    # Abramowitz & Stegun approximation (error < 1.5e-7)
    t = 1.0 / (1.0 + 0.3275911 * abs(x))
    poly = t * (0.254829592 + t * (-0.284496736 + t * (
        1.421413741 + t * (-1.453152027 + t * 1.061405429)
    )))
    result = poly * math.exp(-(x * x))
    return result if x >= 0 else 2.0 - result


def _igamc(a: float, x: float) -> float:
    """
    Regularised incomplete gamma function Q(a, x) = 1 - P(a, x).
    Used for chi-squared P-value calculations.
    Computed via continued fraction (Lentz method).
    """
    if x < 0 or a <= 0:
        return 0.0
    if x == 0:
        return 1.0
    # Use series for small x, continued fraction otherwise
    if x < a + 1:
        # Series expansion
        ap  = a
        val = 1.0 / a
        acc = val
        for _ in range(200):
            ap  += 1
            val *= x / ap
            acc += val
            if abs(val) < abs(acc) * 1e-12:
                break
        return 1.0 - acc * math.exp(-x + a * math.log(x) -
                                    math.lgamma(a + 1))
    else:
        # Continued fraction
        b = x + 1 - a
        c = 1e30
        d = 1.0 / b
        h = d
        for i in range(1, 201):
            an = -i * (i - a)
            b += 2
            d  = an * d + b
            if abs(d) < 1e-30: d = 1e-30
            c  = b + an / c
            if abs(c) < 1e-30: c = 1e-30
            d  = 1.0 / d
            h *= d * c
            if abs(d * c - 1) < 1e-12:
                break
        return math.exp(-x + a * math.log(x) - math.lgamma(a)) * h


def _pvalue_to_result(p: float, alpha: float = 0.01) -> str:
    """Convert a P-value to PASS/FAIL/BORDERLINE."""
    if p >= alpha:
        return "PASS"
    elif p >= alpha / 10:
        return "BORDERLINE"
    else:
        return "FAIL"


def test_frequency(bits: List[int]) -> Tuple[float, str]:
    """
    NIST Test 1: Frequency (monobit) test.
    Checks that the number of 0s and 1s is approximately equal.

    H₀: The sequence is random.
    Statistic: S_n = Σ(2·bit - 1) / √n
    P-value:   erfc(|S_n| / √2)

    Expected: P ≥ 0.01 for random sequences.
    """
    n    = len(bits)
    s_n  = sum(2 * b - 1 for b in bits)
    stat = abs(s_n) / math.sqrt(n)
    p    = _erfc(stat / math.sqrt(2))
    return p, _pvalue_to_result(p)


def test_runs(bits: List[int]) -> Tuple[float, str]:
    """
    NIST Test 3: Runs test.
    Counts total runs (consecutive same bits). Tests oscillation rate.

    H₀: Runs occur at expected frequency for random sequence.
    Prerequisite: frequency test P ≥ 0.01 (τ = 2/√n).
    """
    n   = len(bits)
    pi  = sum(bits) / n

    # Pre-test
    if abs(pi - 0.5) >= 2 / math.sqrt(n):
        return 0.0, "FAIL"   # frequency test prerequisite not met

    # Count runs
    v_n = 1 + sum(1 for i in range(n - 1) if bits[i] != bits[i + 1])

    num = abs(v_n - 2 * n * pi * (1 - pi))
    den = 2 * math.sqrt(2 * n) * pi * (1 - pi)
    p   = _erfc(num / den)
    return p, _pvalue_to_result(p)


def test_block_frequency(bits: List[int], block_size: int = 128) -> Tuple[float, str]:
    """
    NIST Test 2: Block frequency test.
    Divides bit string into blocks of size M and checks frequency within each.

    H₀: Proportion of 1s in each block is ≈ 0.5.
    Statistic: chi-squared with M blocks.
    P-value: Q(M/2, χ²/2)
    """
    n  = len(bits)
    m  = block_size
    N  = n // m

    if N == 0:
        return 0.0, "FAIL"

    chi_sq = 0.0
    for i in range(N):
        block = bits[i * m:(i + 1) * m]
        pi_i  = sum(block) / m
        chi_sq += (pi_i - 0.5) ** 2

    chi_sq *= 4 * m
    p = _igamc(N / 2.0, chi_sq / 2.0)
    return p, _pvalue_to_result(p)


def test_longest_run_ones(bits: List[int]) -> Tuple[float, str]:
    """
    NIST Test 4: Longest run of ones (in 128-bit blocks).
    Checks that the longest consecutive run of 1s matches expectation.

    For n ≥ 6272: K=5, block size M=128, N=49 blocks.
    Expected distribution of longest runs: [1,2,3,4,5,6+].
    """
    n = len(bits)
    if n < 128:
        return 0.0, "FAIL"

    M   = 8   # use small blocks for simulation feasibility
    K   = 3
    N   = n // M

    # Expected frequencies for block size 8
    # P(longest run = 1,2,3,4+) from NIST table
    pi  = [0.2148, 0.3672, 0.2305, 0.1875]
    v   = [0, 0, 0, 0]

    for i in range(N):
        block       = bits[i * M:(i + 1) * M]
        max_run     = 0
        current_run = 0
        for b in block:
            if b == 1:
                current_run += 1
                max_run      = max(max_run, current_run)
            else:
                current_run = 0

        if   max_run <= 1: v[0] += 1
        elif max_run == 2: v[1] += 1
        elif max_run == 3: v[2] += 1
        else:              v[3] += 1

    chi_sq = sum((v[i] - N * pi[i]) ** 2 / (N * pi[i])
                 for i in range(4) if N * pi[i] > 0)
    p = _igamc(K / 2.0, chi_sq / 2.0)
    return p, _pvalue_to_result(p)


def test_approximate_entropy(bits: List[int], m: int = 10) -> Tuple[float, str]:
    """
    NIST Test 11: Approximate entropy test.
    Compares frequencies of all overlapping blocks of lengths m and m+1.

    H₀: Entropy matches that of a truly random sequence.
    P-value: Q(2^{m-1}, n·χ²/2)
    """
    n = len(bits)

    def _phi(block_len: int) -> float:
        counts: Dict[str, int] = {}
        # circular buffer — append first m bits to end
        extended = bits + bits[:block_len]
        for i in range(n):
            key = "".join(str(b) for b in extended[i:i + block_len])
            counts[key] = counts.get(key, 0) + 1

        return sum(c / n * math.log(c / n) for c in counts.values())

    phi_m   = _phi(m)
    phi_mp1 = _phi(m + 1)

    ap_en  = phi_m - phi_mp1
    chi_sq = 2 * n * (math.log(2) - ap_en)
    p      = _igamc(2 ** (m - 1), chi_sq / 2.0)
    return p, _pvalue_to_result(p)


def nist_tests(
    n_bits: int  = 2000,
    verbose: bool = True,
) -> Dict[str, Tuple[float, str]]:
    """
    Run the NIST SP 800-22 statistical test subset on freshly generated QRNG bits.

    Parameters
    ----------
    n_bits  : number of bits to generate for testing (≥ 1000 recommended)
    verbose : print results table

    Returns
    -------
    Dict mapping test_name → (p_value, result_string)
    """
    bits = _qrng_bits_batch(n_bits)

    tests = [
        ("Frequency (monobit)",          lambda b: test_frequency(b)),
        ("Runs",                          lambda b: test_runs(b)),
        ("Block Frequency (M=128)",       lambda b: test_block_frequency(b, 128)),
        ("Longest Run of Ones",           lambda b: test_longest_run_ones(b)),
        ("Approximate Entropy (m=6)",     lambda b: test_approximate_entropy(b, 6)),
    ]

    results: Dict[str, Tuple[float, str]] = {}

    for name, fn in tests:
        try:
            p, verdict = fn(bits)
        except Exception as exc:
            p, verdict = 0.0, f"ERROR: {exc}"
        results[name] = (p, verdict)

    if verbose:
        _print_nist_results(results, n_bits)

    return results


def _print_nist_results(results: Dict, n_bits: int) -> None:
    """Pretty-print NIST test results."""
    try:
        from rich.table import Table
        from rich.console import Console
        from rich import box
        t = Table(
            title=f"NIST SP 800-22 Statistical Tests  ({n_bits} bits)",
            box=box.ROUNDED, show_header=True,
        )
        t.add_column("Test",    width=35, style="bold")
        t.add_column("P-value", justify="right", width=10)
        t.add_column("Result",  justify="center", width=12)

        for name, (p, verdict) in results.items():
            color = {"PASS": "green", "BORDERLINE": "yellow",
                     "FAIL": "red"}.get(verdict, "white")
            t.add_row(name, f"{p:.6f}",
                      f"[{color}]{verdict}[/{color}]")

        all_pass = all(v == "PASS" for _, v in results.values())
        Console().print(t)
        Console().print(
            f"  Overall: [bold {'green' if all_pass else 'yellow'}]"
            f"{'ALL PASS ✓' if all_pass else 'CHECK BORDERLINE'}[/]\n"
        )
    except ImportError:
        print(f"\nNIST SP 800-22 ({n_bits} bits):")
        for name, (p, verdict) in results.items():
            print(f"  {name:<38}  p={p:.6f}  {verdict}")


# ─────────────────────────────────────────────────────────────────────────────
# Comparison with classical PRNG
# ─────────────────────────────────────────────────────────────────────────────

def compare_with_prng(n_bits: int = 2000) -> None:
    """
    Compare QRNG output vs Python's Mersenne Twister on the NIST tests.
    Illustrates that both pass (good statistical quality) while the QRNG
    has provably non-deterministic entropy source.
    """
    import random as _random

    print("\n── QRNG (Quantum) ──")
    qrng_results = nist_tests(n_bits, verbose=True)

    print("── Python Mersenne Twister (MT19937) ──")
    mt_bits = [_random.randint(0, 1) for _ in range(n_bits)]
    mt_results = {
        "Frequency (monobit)":       test_frequency(mt_bits),
        "Runs":                       test_runs(mt_bits),
        "Block Frequency (M=128)":    test_block_frequency(mt_bits, 128),
        "Longest Run of Ones":        test_longest_run_ones(mt_bits),
        "Approximate Entropy (m=10)": test_approximate_entropy(mt_bits, 10),
    }
    _print_nist_results(mt_results, n_bits)

    print("Note: Both pass NIST tests — the difference is the ENTROPY SOURCE.")
    print("  PRNG: deterministic given seed (predictable if seed is known)")
    print("  QRNG: Born-rule randomness (unpredictable by any algorithm)")


# ─────────────────────────────────────────────────────────────────────────────
# Throughput benchmark
# ─────────────────────────────────────────────────────────────────────────────

def benchmark_qrng(sizes_bytes: List[int] = None) -> Dict[str, float]:
    """
    Measure QRNG throughput in KB/s for various output sizes.

    Returns dict mapping size_label → throughput_kbps.
    """
    if sizes_bytes is None:
        sizes_bytes = [64, 256, 1024, 4096]

    results = {}
    for n in sizes_bytes:
        # Warm up
        qrng_bytes(8, mix_os_entropy=False)

        trials = 5
        times  = []
        for _ in range(trials):
            t0 = time.perf_counter()
            qrng_bytes(n, mix_os_entropy=False)
            times.append(time.perf_counter() - t0)

        times.sort()
        mean_s = sum(times[1:-1]) / max(1, len(times) - 2)
        kbps   = (n / 1024) / mean_s
        label  = f"{n}B"
        results[label] = round(kbps, 2)

    return results


# ─────────────────────────────────────────────────────────────────────────────
# CLI entry point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Quantum Random Number Generator")
    parser.add_argument("--bytes",   type=int, default=0,
                        help="Generate N random bytes (hex output)")
    parser.add_argument("--key",     action="store_true",
                        help="Generate a 256-bit AES key")
    parser.add_argument("--nist",    type=int, default=0, metavar="N",
                        help="Run NIST tests on N bits")
    parser.add_argument("--compare", action="store_true",
                        help="Compare QRNG vs Mersenne Twister")
    parser.add_argument("--bench",   action="store_true",
                        help="Benchmark throughput")
    args = parser.parse_args()

    if args.key:
        key = qrng_key()
        print(f"QRNG AES-256 key: {key.hex()}")

    if args.bytes:
        data = qrng_bytes(args.bytes)
        print(data.hex())

    if args.nist:
        nist_tests(args.nist, verbose=True)

    if args.compare:
        compare_with_prng(2000)

    if args.bench:
        print("\nQRNG Throughput:")
        for label, kbps in benchmark_qrng().items():
            bar = "█" * int(kbps / 5)
            print(f"  {label:>6}: {kbps:8.2f} KB/s  {bar}")

    if not any([args.key, args.bytes, args.nist, args.compare, args.bench]):
        # Default: show demo
        print("Quantum RNG Demo")
        print(f"  10 random ints (1-100):  {[qrng_int(1, 100) for _ in range(10)]}")
        print(f"  5 random floats:         {[round(qrng_float(), 4) for _ in range(5)]}")
        key = qrng_key()
        print(f"  256-bit key:             {key.hex()[:32]}…")
        nist_tests(2000, verbose=True)
