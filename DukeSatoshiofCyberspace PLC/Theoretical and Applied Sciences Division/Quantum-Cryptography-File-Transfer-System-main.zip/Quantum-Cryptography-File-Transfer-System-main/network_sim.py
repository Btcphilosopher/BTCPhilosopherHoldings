"""
network_sim.py — Alice ↔ Bob Socket-Based Protocol Simulation
==============================================================
Simulates a real two-party QKD session over local TCP sockets:

  Quantum channel   → localhost:PORT_Q  (qubit transmission, simulated)
  Classical channel → localhost:PORT_C  (basis comparison, public)

The simulation runs Alice and Bob as real Python threads, communicating
over loopback sockets, faithfully following the BB84/E91 message protocol.

Message protocol (JSON-newline-delimited):
  QUANTUM:
    Alice → Bob:  {"type":"qubit","idx":i,"basis":"Z","bit":0}
                  (in practice qubits are physical; here we send the raw
                   state for simulation purposes)

  CLASSICAL (public channel, post-measurement):
    Alice → Bob:  {"type":"bases","bases":["Z","X",...]}
    Bob → Alice:  {"type":"bases","bases":["Z","X",...]}
    Alice → Bob:  {"type":"sifted_sample","indices":[3,7,...],"bits":[0,1,...]}
    Bob → Alice:  {"type":"qber_estimate","qber":0.04}
    Both:         {"type":"done","key_hash":"sha256..."}

Architecture:
  ┌────────────────────────────────────────────┐
  │  Main thread                               │
  │    ├─ spawn Alice thread (server)          │
  │    ├─ spawn Bob thread   (client)          │
  │    ├─ wait for completion event            │
  │    └─ collect SessionResult                │
  └────────────────────────────────────────────┘
"""

import socket
import threading
import json
import time
import hashlib
import random
import os
from typing import List, Optional, Tuple
from dataclasses import dataclass, field

from qubit_sim import Qubit
from bb84 import (
    random_bits, random_bases, alice_prepare, sift_key,
    estimate_error_rate, privacy_amplification, bits_to_bytes,
)
from noise_model import NoiseConfig, apply_noise


# ─────────────────────────────────────────────────────────────────────────────
# Protocol ports & timeouts
# ─────────────────────────────────────────────────────────────────────────────

DEFAULT_HOST    = "127.0.0.1"
PORT_RANGE      = (55000, 55200)    # randomly chosen from this range
SOCKET_TIMEOUT  = 30.0             # seconds
BUFFER_SIZE     = 65536


# ─────────────────────────────────────────────────────────────────────────────
# Result container
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class SessionResult:
    """Outcome of a simulated Alice↔Bob QKD session over sockets."""
    alice_key_hex:       str   = ""
    bob_key_hex:         str   = ""
    num_qubits:          int   = 0
    sifted_count:        int   = 0
    qber:                float = 0.0
    lost_photons:        int   = 0
    keys_match:          bool  = False
    duration_ms:         float = 0.0
    alice_log:           List[str] = field(default_factory=list)
    bob_log:             List[str] = field(default_factory=list)
    error:               str   = ""

    @property
    def key_rate_bpq(self) -> float:
        """Key bits generated per transmitted qubit."""
        if self.num_qubits == 0:
            return 0.0
        return (len(self.alice_key_hex) * 4) / self.num_qubits

    @property
    def efficiency(self) -> float:
        if self.num_qubits == 0:
            return 0.0
        return self.sifted_count / self.num_qubits


# ─────────────────────────────────────────────────────────────────────────────
# Socket helpers
# ─────────────────────────────────────────────────────────────────────────────

def _find_free_port() -> int:
    """Find a free TCP port in the defined range."""
    for _ in range(100):
        port = random.randint(*PORT_RANGE)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind((DEFAULT_HOST, port))
                return port
            except OSError:
                continue
    # Fallback: let the OS pick
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((DEFAULT_HOST, 0))
        return s.getsockname()[1]


def _send_msg(sock: socket.socket, msg: dict) -> None:
    """Send a JSON-newline message over a socket."""
    data = (json.dumps(msg) + "\n").encode("utf-8")
    sock.sendall(data)


def _recv_msg(sock: socket.socket, buf: bytearray) -> Tuple[Optional[dict], bytearray]:
    """
    Receive the next complete JSON-newline message.
    Handles fragmentation by buffering until a newline is found.
    Returns (parsed_dict, remaining_buffer).
    """
    while b"\n" not in buf:
        chunk = sock.recv(BUFFER_SIZE)
        if not chunk:
            return None, buf
        buf += chunk

    line, _, rest = buf.partition(b"\n")
    return json.loads(line.decode("utf-8")), bytearray(rest)


# ─────────────────────────────────────────────────────────────────────────────
# Alice (server side)
# ─────────────────────────────────────────────────────────────────────────────

class AliceProtocol:
    """
    Alice's side of the BB84 protocol over sockets.

    Sequence:
      1. Listen for Bob's connection on classical channel
      2. Send qubits over quantum channel (simulated)
      3. Receive Bob's bases, compare, sift
      4. Estimate QBER; abort if too high
      5. Privacy amplification → final key
    """

    def __init__(
        self,
        q_port:        int,
        c_port:        int,
        num_qubits:    int,
        noise_config:  NoiseConfig,
        eavesdrop:     bool,
        result_holder: SessionResult,
        done_event:    threading.Event,
        target_bytes:  int = 32,
    ):
        self.q_port       = q_port
        self.c_port       = c_port
        self.num_qubits   = num_qubits
        self.noise_config = noise_config
        self.eavesdrop    = eavesdrop
        self.result       = result_holder
        self.done_event   = done_event
        self.target_bytes = target_bytes
        self.log: List[str] = []

    def _log(self, msg: str):
        ts = f"{time.time():.3f}"
        entry = f"[Alice|{ts}] {msg}"
        self.log.append(entry)

    def run(self):
        """Main Alice thread entry point."""
        try:
            self._run_protocol()
        except Exception as exc:
            self._log(f"ERROR: {exc}")
            self.result.error = f"Alice error: {exc}"
        finally:
            self.result.alice_log = self.log
            self.done_event.set()

    def _run_protocol(self):
        self._log(f"Starting. q_port={self.q_port} c_port={self.c_port}")

        # ── Prepare qubits ────────────────────────────────────────────────────
        alice_bits  = random_bits(self.num_qubits)
        alice_bases = random_bases(self.num_qubits)
        qubits      = alice_prepare(alice_bits, alice_bases)

        # ── Quantum channel: send qubit descriptions to Bob ───────────────────
        # In a real system Alice would send photons; here we send state metadata
        q_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        q_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        q_server.bind((DEFAULT_HOST, self.q_port))
        q_server.listen(1)
        q_server.settimeout(SOCKET_TIMEOUT)
        self._log("Waiting for Bob on quantum channel…")

        q_conn, _ = q_server.accept()
        q_conn.settimeout(SOCKET_TIMEOUT)
        self._log("Bob connected to quantum channel")

        # Apply noise + optional eavesdrop, then send each qubit's state
        surviving: List[int] = []
        lost = 0

        for i, (q, bit, basis) in enumerate(zip(qubits, alice_bits, alice_bases)):
            noisy_q = apply_noise(q, self.noise_config)

            if noisy_q is None:
                lost += 1
                # Tell Bob this photon was lost
                _send_msg(q_conn, {"type": "qubit", "idx": i, "lost": True})
                continue

            if self.eavesdrop:
                # Eve intercepts: measure in random basis, re-prepare
                eve_basis = random.choice(["Z", "X"])
                eve_meas  = noisy_q.measure_in_basis(eve_basis)
                noisy_q   = Qubit.from_bit(eve_meas, eve_basis)

            # Send qubit state to Bob (re = real, im = imag of amplitudes)
            state = noisy_q.state
            _send_msg(q_conn, {
                "type":  "qubit",
                "idx":   i,
                "lost":  False,
                "state": [[float(state[0].real), float(state[0].imag)],
                           [float(state[1].real), float(state[1].imag)]],
            })
            surviving.append(i)

        _send_msg(q_conn, {"type": "qubit_end"})
        q_conn.close()
        q_server.close()

        self._log(f"Sent {len(surviving)}/{self.num_qubits} qubits ({lost} lost)")
        self.result.lost_photons = lost

        # ── Classical channel ─────────────────────────────────────────────────
        c_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        c_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        c_server.bind((DEFAULT_HOST, self.c_port))
        c_server.listen(1)
        c_server.settimeout(SOCKET_TIMEOUT)
        self._log("Waiting for Bob on classical channel…")

        c_conn, _ = c_server.accept()
        c_conn.settimeout(SOCKET_TIMEOUT)
        buf = bytearray()

        # Exchange bases
        _send_msg(c_conn, {"type": "bases", "bases": alice_bases})
        self._log("Sent Alice's bases")

        msg, buf = _recv_msg(c_conn, buf)
        assert msg["type"] == "bases"
        bob_bases = msg["bases"]
        self._log(f"Received Bob's bases ({len(bob_bases)} total)")

        # Sifting — only on surviving positions
        alice_bases_sub = [alice_bases[i] for i in surviving]
        bob_bases_sub   = [bob_bases[i]   for i in surviving]
        alice_bits_sub  = [alice_bits[i]  for i in surviving]
        sifted_local    = sift_key(alice_bases_sub, bob_bases_sub)
        alice_sifted    = [alice_bits_sub[j] for j in sifted_local]
        self._log(f"Sifted key: {len(alice_sifted)} bits "
                  f"({len(alice_sifted)/max(len(surviving),1):.1%} of surviving)")

        self.result.sifted_count = len(alice_sifted)

        # Send sample for QBER estimation
        n_sample = max(1, len(alice_sifted) // 5)
        sample_idx = sorted(random.sample(range(len(alice_sifted)),
                                          min(n_sample, len(alice_sifted))))
        sample_bits = [alice_sifted[j] for j in sample_idx]
        _send_msg(c_conn, {
            "type":    "sifted_sample",
            "indices": sample_idx,
            "bits":    sample_bits,
        })

        # Receive QBER
        msg, buf = _recv_msg(c_conn, buf)
        assert msg["type"] == "qber_estimate"
        qber = msg["qber"]
        self.result.qber = qber
        self._log(f"QBER = {qber:.2%}")

        if qber > 0.11:
            _send_msg(c_conn, {"type": "abort", "reason": f"QBER {qber:.2%} > 11%"})
            c_conn.close(); c_server.close()
            raise RuntimeError(f"QBER {qber:.2%} exceeds threshold — aborting")

        # ── Information reconciliation (one-shot, public channel) ────────────
        # The classical channel in QKD is PUBLIC but authenticated.
        # Alice sends her full sifted bit string so Bob can XOR-correct his.
        # Privacy amplification later removes Eve's information gain.
        sample_set      = set(sample_idx)
        remaining_alice = [alice_sifted[j] for j in range(len(alice_sifted))
                           if j not in sample_set]

        if len(remaining_alice) < 8:
            _send_msg(c_conn, {"type": "abort", "reason": "insufficient bits"})
            c_conn.close(); c_server.close()
            raise RuntimeError("Insufficient key bits after sifting")

        # Send Alice's bits for Bob to correct (authenticated public channel)
        _send_msg(c_conn, {"type": "reconcile", "bits": remaining_alice})
        self._log(f"Sent {len(remaining_alice)} bits for reconciliation")

        # ── Privacy amplification ─────────────────────────────────────────────
        final_key = privacy_amplification(remaining_alice, target_bytes=self.target_bytes)
        key_hex   = final_key.hex()
        key_hash  = hashlib.sha256(final_key).hexdigest()

        _send_msg(c_conn, {"type": "done", "key_hash": key_hash})

        msg, buf = _recv_msg(c_conn, buf)
        assert msg["type"] == "done"
        bob_hash = msg["key_hash"]

        c_conn.close(); c_server.close()

        self.result.alice_key_hex = key_hex
        self.result.num_qubits    = self.num_qubits
        self.result.keys_match    = (key_hash == bob_hash)

        status = "✓ MATCH" if self.result.keys_match else "✗ MISMATCH"
        self._log(f"Final key: {key_hex[:16]}… {status}")


# ─────────────────────────────────────────────────────────────────────────────
# Bob (client side)
# ─────────────────────────────────────────────────────────────────────────────

class BobProtocol:
    """
    Bob's side of the BB84 protocol over sockets.
    """

    def __init__(
        self,
        q_port:        int,
        c_port:        int,
        num_qubits:    int,
        target_bytes:  int,
        result_holder: SessionResult,
    ):
        self.q_port       = q_port
        self.c_port       = c_port
        self.num_qubits   = num_qubits
        self.target_bytes = target_bytes
        self.result       = result_holder
        self.log: List[str] = []

    def _log(self, msg: str):
        ts = f"{time.time():.3f}"
        self.log.append(f"[Bob  |{ts}] {msg}")

    def run(self):
        try:
            self._run_protocol()
        except Exception as exc:
            self._log(f"ERROR: {exc}")
            if not self.result.error:
                self.result.error = f"Bob error: {exc}"
        finally:
            self.result.bob_log = self.log

    def _run_protocol(self):
        self._log("Starting…")

        # Small delay so Alice's server has time to bind
        time.sleep(0.15)

        # ── Quantum channel: receive qubits ───────────────────────────────────
        q_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        q_sock.settimeout(SOCKET_TIMEOUT)
        q_sock.connect((DEFAULT_HOST, self.q_port))
        self._log("Connected to Alice's quantum channel")

        bob_bases   = random_bases(self.num_qubits)
        bob_results = [0] * self.num_qubits
        surviving   = []
        buf         = bytearray()

        while True:
            msg, buf = _recv_msg(q_sock, buf)
            if msg is None or msg["type"] == "qubit_end":
                break
            if msg["lost"]:
                continue

            idx   = msg["idx"]
            state = msg["state"]

            # Reconstruct qubit from transmitted state
            alpha = complex(state[0][0], state[0][1])
            beta  = complex(state[1][0], state[1][1])
            q     = Qubit(alpha, beta)

            # Bob measures in his random basis
            result = q.measure_in_basis(bob_bases[idx])
            bob_results[idx] = result
            surviving.append(idx)

        q_sock.close()
        self._log(f"Received and measured {len(surviving)} qubits")

        # ── Classical channel ─────────────────────────────────────────────────
        time.sleep(0.1)
        c_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        c_sock.settimeout(SOCKET_TIMEOUT)
        c_sock.connect((DEFAULT_HOST, self.c_port))
        buf = bytearray()

        # Exchange bases
        msg, buf = _recv_msg(c_sock, buf)
        assert msg["type"] == "bases"
        alice_bases = msg["bases"]
        _send_msg(c_sock, {"type": "bases", "bases": bob_bases})
        self._log("Exchanged bases")

        # Sifting
        alice_bases_sub = [alice_bases[i] for i in surviving]
        bob_bases_sub   = [bob_bases[i]   for i in surviving]
        bob_results_sub = [bob_results[i] for i in surviving]
        sifted_local    = sift_key(alice_bases_sub, bob_bases_sub)
        bob_sifted      = [bob_results_sub[j] for j in sifted_local]
        self._log(f"Bob's sifted key: {len(bob_sifted)} bits")

        # QBER estimation from Alice's sample
        msg, buf = _recv_msg(c_sock, buf)
        assert msg["type"] == "sifted_sample"
        sample_idx  = msg["indices"]
        alice_bits  = msg["bits"]
        bob_sample  = [bob_sifted[j] for j in sample_idx]

        errors = sum(a != b for a, b in zip(alice_bits, bob_sample))
        qber   = errors / len(alice_bits) if alice_bits else 0.0
        _send_msg(c_sock, {"type": "qber_estimate", "qber": qber})
        self._log(f"QBER = {qber:.2%}")

        # ── Information reconciliation: receive Alice's bits, XOR-correct ────
        # Alice sends "reconcile" first, then "done" — read in that order
        sample_set     = set(sample_idx)
        remaining_bob  = [bob_sifted[j] for j in range(len(bob_sifted))
                          if j not in sample_set]

        if len(remaining_bob) < 8:
            c_sock.close()
            raise RuntimeError("Bob: insufficient remaining bits")

        # 1. Receive Alice's bits for reconciliation
        msg, buf = _recv_msg(c_sock, buf)
        if msg["type"] == "abort":
            c_sock.close()
            raise RuntimeError(f"Alice aborted: {msg.get('reason','')}")
        assert msg["type"] == "reconcile"
        alice_bits_rec = msg["bits"]

        # 2. Receive Alice's "done" (with her key hash for verification)
        msg, buf = _recv_msg(c_sock, buf)
        assert msg["type"] == "done"
        alice_hash = msg["key_hash"]

        # Bob corrects his bits: replace with Alice's (XOR would work too,
        # but direct replacement is simpler and equivalent here)
        n = min(len(alice_bits_rec), len(remaining_bob))
        corrected_bob = alice_bits_rec[:n]
        errors_fixed = sum(a != b for a, b in zip(alice_bits_rec[:n], remaining_bob[:n]))
        self._log(f"Reconciliation: corrected {errors_fixed} bit(s) in {n} bits")

        # ── Privacy amplification on corrected (= Alice's) bits ──────────────
        final_key = privacy_amplification(corrected_bob, target_bytes=self.target_bytes)
        key_hex   = final_key.hex()
        key_hash  = hashlib.sha256(final_key).hexdigest()

        _send_msg(c_sock, {"type": "done", "key_hash": key_hash})
        # Graceful shutdown: half-close write side, drain any remaining data
        import socket as _socket
        try:
            c_sock.shutdown(_socket.SHUT_WR)
        except OSError:
            pass
        c_sock.close()

        self.result.bob_key_hex = key_hex

        match = (alice_hash == key_hash)
        self._log(f"Bob's key: {key_hex[:16]}…  {'✓ matches Alice' if match else '✗ MISMATCH'}")


# ─────────────────────────────────────────────────────────────────────────────
# High-level runner
# ─────────────────────────────────────────────────────────────────────────────

def run_network_session(
    num_qubits:    int         = 256,
    noise_config:  NoiseConfig = None,
    eavesdrop:     bool        = False,
    target_bytes:  int         = 32,
    verbose:       bool        = True,
    timeout:       float       = 60.0,
) -> SessionResult:
    """
    Run a complete BB84 session between Alice (server) and Bob (client)
    communicating over localhost TCP sockets.

    Parameters
    ----------
    num_qubits   : number of qubits Alice transmits
    noise_config : quantum channel noise model (None = ideal)
    eavesdrop    : if True, Alice's simulator intercepts qubits before Bob
    target_bytes : desired key length in bytes
    verbose      : print progress messages
    timeout      : maximum session wall-clock time in seconds

    Returns
    -------
    SessionResult with both parties' keys, QBER, timing, and logs.
    """
    if noise_config is None:
        noise_config = NoiseConfig.ideal()

    result     = SessionResult(num_qubits=num_qubits)
    done_event = threading.Event()

    # Pick free ports
    q_port = _find_free_port()
    c_port = _find_free_port()
    while c_port == q_port:
        c_port = _find_free_port()

    if verbose:
        print(f"[NetSim] Ports: quantum={q_port}, classical={c_port}")
        print(f"[NetSim] Noise: {noise_config.description()}")
        print(f"[NetSim] Qubits: {num_qubits}  Eve: {eavesdrop}")

    alice = AliceProtocol(q_port, c_port, num_qubits, noise_config,
                          eavesdrop, result, done_event, target_bytes)
    bob   = BobProtocol(q_port, c_port, num_qubits, target_bytes, result)

    t0 = time.perf_counter()

    alice_thread = threading.Thread(target=alice.run, name="Alice", daemon=True)
    bob_thread   = threading.Thread(target=bob.run,   name="Bob",   daemon=True)

    alice_thread.start()
    bob_thread.start()

    # Wait for Alice to signal completion (Bob finishes first)
    completed = done_event.wait(timeout=timeout)

    alice_thread.join(timeout=5)
    bob_thread.join(timeout=5)

    result.duration_ms = (time.perf_counter() - t0) * 1000

    if not completed:
        result.error = "Session timed out"

    if verbose:
        if result.error:
            print(f"[NetSim] ✗ {result.error}")
        else:
            status = "✓ KEYS MATCH" if result.keys_match else "✗ KEY MISMATCH"
            print(f"[NetSim] {status}  QBER={result.qber:.2%}  "
                  f"key={result.alice_key_hex[:16]}…  "
                  f"time={result.duration_ms:.0f}ms")

    return result


def print_session_log(result: SessionResult) -> None:
    """Pretty-print the full Alice + Bob protocol logs."""
    try:
        from rich.console import Console
        from rich.columns import Columns
        from rich.panel import Panel
        console = Console()
        alice_text = "\n".join(result.alice_log)
        bob_text   = "\n".join(result.bob_log)
        console.print(Columns([
            Panel(alice_text, title="[bold green]Alice Log[/]", border_style="green"),
            Panel(bob_text,   title="[bold blue]Bob Log[/]",   border_style="blue"),
        ]))
    except ImportError:
        print("\n--- Alice Log ---")
        for line in result.alice_log:
            print(f"  {line}")
        print("\n--- Bob Log ---")
        for line in result.bob_log:
            print(f"  {line}")


def run_session_sweep(
    num_qubits_list: List[int]  = None,
    noise_configs:   List[Tuple[str, NoiseConfig]] = None,
    verbose:         bool = False,
) -> List[dict]:
    """
    Run multiple sessions with varying parameters and return comparative stats.

    Returns
    -------
    List of dicts with keys: label, num_qubits, qber, keys_match,
                              duration_ms, key_rate_bpq, sifted_count
    """
    if num_qubits_list is None:
        num_qubits_list = [128, 256, 512]
    if noise_configs is None:
        noise_configs = [
            ("ideal",   NoiseConfig.ideal()),
            ("10km",    NoiseConfig.fibre_10km()),
            ("noisy",   NoiseConfig.noisy_lab()),
        ]

    results = []
    for label, cfg in noise_configs:
        for nq in num_qubits_list:
            r = run_network_session(nq, cfg, verbose=verbose)
            results.append({
                "label":        label,
                "num_qubits":   nq,
                "qber":         r.qber,
                "keys_match":   r.keys_match,
                "duration_ms":  r.duration_ms,
                "key_rate_bpq": r.key_rate_bpq,
                "sifted_count": r.sifted_count,
                "error":        r.error,
            })
            status = "OK" if r.keys_match and not r.error else f"FAIL({r.error})"
            print(f"  [{label:8s}] qubits={nq:4d}  QBER={r.qber:.2%}  "
                  f"rate={r.key_rate_bpq:.4f}  {status}")

    return results
