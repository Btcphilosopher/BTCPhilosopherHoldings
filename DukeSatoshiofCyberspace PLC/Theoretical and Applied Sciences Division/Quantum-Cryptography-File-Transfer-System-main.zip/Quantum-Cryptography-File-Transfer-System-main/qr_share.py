"""
qr_share.py — QR-Code Key Export / Import
==========================================
Encodes a quantum-derived AES key into a QR code for out-of-band sharing
(e.g. scan from another device, print on paper, etc.).

The key is *not* encrypted in the QR code itself — physical security of the
QR image is the user's responsibility.  For an extra layer of protection, an
optional passphrase wraps the key with AES-256-GCM before encoding.

QR payload format (JSON):
  {
    "version":   1,
    "key_hex":   "…64 hex chars…" | "<protected>",
    "protocol":  "bb84" | "e91",
    "bits":      256,
    "created":   "ISO timestamp",
    "protected": false | true,
    "nonce":     "…hex…",     # only if protected=true
    "tag":       "…hex…",     # only if protected=true
    "ciphertext":"…hex…"      # only if protected=true
  }

Requires: qrcode[pil]  (pip install qrcode[pil] pillow)
"""

import json
import os
import base64
import datetime
from typing import Optional, Tuple

# ── Optional deps ─────────────────────────────────────────────────────────────
try:
    import qrcode
    from qrcode.image.styledpil import StyledPilImage
    from qrcode.image.styles.moduledrawers import RoundedModuleDrawer
    QR_AVAILABLE = True
except ImportError:
    QR_AVAILABLE = False

try:
    from PIL import Image, ImageDraw, ImageFont
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend


# ─────────────────────────────────────────────────────────────────────────────
# Passphrase-based key wrapping (for protected QR codes)
# ─────────────────────────────────────────────────────────────────────────────

_PBKDF2_ITERATIONS = 200_000


def _wrap_key(key_hex: str, passphrase: str) -> dict:
    """
    Encrypt `key_hex` with a passphrase using PBKDF2-HMAC-SHA256 + AES-256-GCM.
    Returns a dict of nonce_hex, tag_hex, ciphertext_hex, salt_hex.
    """
    salt  = os.urandom(16)
    kdf   = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=_PBKDF2_ITERATIONS,
        backend=default_backend(),
    )
    wrap_key = kdf.derive(passphrase.encode("utf-8"))

    nonce = os.urandom(12)
    aesgcm = AESGCM(wrap_key)
    ct_tag = aesgcm.encrypt(nonce, key_hex.encode("utf-8"), None)
    ct  = ct_tag[:-16]
    tag = ct_tag[-16:]

    return {
        "nonce":      nonce.hex(),
        "tag":        tag.hex(),
        "ciphertext": ct.hex(),
        "salt":       salt.hex(),
    }


def _unwrap_key(wrapped: dict, passphrase: str) -> str:
    """
    Decrypt a wrapped key using the passphrase.
    Returns the plain key_hex string.
    """
    salt  = bytes.fromhex(wrapped["salt"])
    kdf   = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=_PBKDF2_ITERATIONS,
        backend=default_backend(),
    )
    wrap_key = kdf.derive(passphrase.encode("utf-8"))

    nonce = bytes.fromhex(wrapped["nonce"])
    tag   = bytes.fromhex(wrapped["tag"])
    ct    = bytes.fromhex(wrapped["ciphertext"])

    aesgcm = AESGCM(wrap_key)
    plain  = aesgcm.decrypt(nonce, ct + tag, None)
    return plain.decode("utf-8")


# ─────────────────────────────────────────────────────────────────────────────
# QR encoding
# ─────────────────────────────────────────────────────────────────────────────

def _build_payload(
    key_hex:    str,
    protocol:   str = "bb84",
    passphrase: Optional[str] = None,
) -> str:
    """Build the JSON string to encode in the QR code."""
    payload: dict = {
        "version":  1,
        "protocol": protocol,
        "bits":     len(key_hex) * 4,
        "created":  datetime.datetime.utcnow().isoformat(),
    }

    if passphrase:
        wrapped = _wrap_key(key_hex, passphrase)
        payload["key_hex"]    = "<protected>"
        payload["protected"]  = True
        payload.update(wrapped)
    else:
        payload["key_hex"]   = key_hex
        payload["protected"] = False

    return json.dumps(payload, separators=(",", ":"))


def export_key_qr(
    key_hex:    str,
    output_path: str,
    protocol:    str  = "bb84",
    passphrase:  Optional[str]  = None,
    label:       str  = "Quantum Key",
    box_size:    int  = 8,
    border:      int  = 4,
) -> dict:
    """
    Encode `key_hex` as a QR code and save to `output_path` (PNG).

    Parameters
    ----------
    key_hex     : 64-char AES-256 key hex string
    output_path : where to save the PNG
    protocol    : 'bb84' or 'e91' (informational only)
    passphrase  : if given, wrap the key with this passphrase before encoding
    label       : text label printed below the QR code
    box_size    : pixel size of each QR module
    border      : number of quiet-zone modules

    Returns
    -------
    dict with: output_path, payload_length, protected
    """
    if not QR_AVAILABLE:
        raise ImportError(
            "qrcode package not installed. "
            "Run: pip install qrcode[pil] pillow"
        )
    if len(key_hex) != 64:
        raise ValueError(f"Key must be 64 hex chars (256-bit), got {len(key_hex)}.")

    payload = _build_payload(key_hex, protocol, passphrase)

    qr = qrcode.QRCode(
        version      = None,
        error_correction = qrcode.constants.ERROR_CORRECT_M,
        box_size     = box_size,
        border       = border,
    )
    qr.add_data(payload)
    qr.make(fit=True)

    if PIL_AVAILABLE:
        img = qr.make_image(fill_color="black", back_color="white")

        # Add label text below
        if label:
            pil_img = img.convert("RGB") if hasattr(img, "convert") else Image.new("RGB", img.size, "white")
            try: pil_img.paste(img.tobytes(), (0, 0))
            except Exception: pass
            try: base_w, base_h = pil_img.size
            except: base_w, base_h = 300, 300
            pad = 40
            new_img = Image.new("RGB", (base_w, base_h + pad), "white")
            new_img.paste(pil_img, (0, 0, base_w, base_h))

            draw = ImageDraw.Draw(new_img)
            try:
                font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
            except Exception:
                font = ImageFont.load_default()

            # Centred label
            bbox = draw.textbbox((0, 0), label, font=font)
            tw   = bbox[2] - bbox[0]
            draw.text(((base_w - tw) // 2, base_h + 6), label,
                      fill="black", font=font)

            new_img.save(output_path)
        else:
            img.save(output_path)
    else:
        # PIL not available — save raw QR without label
        img = qr.make_image()
        img.save(output_path)

    return {
        "output_path":    output_path,
        "payload_length": len(payload),
        "protected":      passphrase is not None,
        "qr_version":     qr.version,
        "protocol":       protocol,
    }


# ─────────────────────────────────────────────────────────────────────────────
# QR decoding
# ─────────────────────────────────────────────────────────────────────────────

def import_key_qr(
    image_path:  str,
    passphrase:  Optional[str] = None,
) -> Tuple[str, dict]:
    """
    Scan a QR-code image and extract the key hex.

    Parameters
    ----------
    image_path : path to the QR code PNG
    passphrase : required if the key was protected during export

    Returns
    -------
    (key_hex, metadata_dict)

    Raises
    ------
    ImportError  : if qrcode or pyzbar are not installed
    ValueError   : if QR data is invalid or passphrase is wrong
    """
    try:
        from pyzbar.pyzbar import decode as zbar_decode
        from PIL import Image as PILImage
    except ImportError:
        raise ImportError(
            "pyzbar + pillow are required for QR import. "
            "Run: pip install pyzbar pillow"
        )

    img    = PILImage.open(image_path)
    codes  = zbar_decode(img)

    if not codes:
        raise ValueError(f"No QR code found in image: {image_path}")

    raw_data = codes[0].data.decode("utf-8")

    try:
        payload = json.loads(raw_data)
    except json.JSONDecodeError:
        raise ValueError("QR payload is not valid JSON.")

    if payload.get("version") != 1:
        raise ValueError(f"Unsupported QR payload version: {payload.get('version')}")

    if payload.get("protected"):
        if not passphrase:
            raise ValueError("This QR code is passphrase-protected. Provide passphrase.")
        key_hex = _unwrap_key(payload, passphrase)
    else:
        key_hex = payload.get("key_hex", "")

    if len(key_hex) != 64:
        raise ValueError(f"Decoded key has wrong length: {len(key_hex)} chars.")

    meta = {
        "protocol":  payload.get("protocol", "unknown"),
        "bits":      payload.get("bits",     256),
        "created":   payload.get("created",  ""),
        "protected": payload.get("protected", False),
    }
    return key_hex, meta


# ─────────────────────────────────────────────────────────────────────────────
# Text-based QR (ASCII fallback — no image required)
# ─────────────────────────────────────────────────────────────────────────────

def export_key_text_qr(
    key_hex:  str,
    protocol: str = "bb84",
    passphrase: Optional[str] = None,
) -> str:
    """
    Render a QR code directly as a UTF-8 block-character string
    (works in any terminal without PIL).

    Returns the multi-line QR string.
    """
    if not QR_AVAILABLE:
        raise ImportError("qrcode not installed. Run: pip install qrcode[pil]")

    payload = _build_payload(key_hex, protocol, passphrase)

    qr = qrcode.QRCode(
        version          = None,
        error_correction = qrcode.constants.ERROR_CORRECT_M,
        box_size         = 1,
        border           = 2,
    )
    qr.add_data(payload)
    qr.make(fit=True)

    # Build string using block characters
    matrix = qr.modules
    lines  = []
    for row in matrix:
        line = "".join("██" if cell else "  " for cell in row)
        lines.append(line)
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Key fingerprint (short human-readable identifier)
# ─────────────────────────────────────────────────────────────────────────────

def key_fingerprint(key_hex: str, words: int = 6) -> str:
    """
    Return a human-readable fingerprint of a key using SHA-256.
    Format: XXXX-XXXX-XXXX-XXXX  (8-char hex groups)

    Useful for out-of-band verification ("does your key start with AB12-CD34?")
    """
    import hashlib
    digest = hashlib.sha256(bytes.fromhex(key_hex)).hexdigest()
    groups = [digest[i:i+4].upper() for i in range(0, 32, 4)][:words]
    return "-".join(groups)


def verify_key_fingerprint(key_hex: str, fingerprint: str) -> bool:
    """
    Verify that a key matches a fingerprint.
    Constant-time comparison to prevent timing attacks.
    """
    import hmac
    computed = key_fingerprint(key_hex, words=len(fingerprint.split("-")))
    return hmac.compare_digest(computed.upper(), fingerprint.upper())
