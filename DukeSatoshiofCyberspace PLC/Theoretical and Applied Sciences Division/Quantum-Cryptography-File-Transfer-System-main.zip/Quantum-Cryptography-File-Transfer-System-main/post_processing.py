"""
post_processing.py — Full QKD Post-Processing Pipeline
========================================================
Implements the complete information-theoretic key distillation chain
that transforms a noisy, partially-leaked sifted key into a provably
secure final key:

    Sifted bits
        │
        ▼ 1. Parameter estimation (QBER)
        │
        ▼ 2. Error correction (Cascade)
        │
        ▼ 3. Verification (hash comparison)
        │
        ▼ 4. Privacy amplification (HKDF/SHA-256)
        │
        ▼
    Secret key  ← provably secure against computationally unbounded Eve

Security guarantees (information-theoretic, not computational):
  • Composable security: the key is ε-secure for ε → 0 as n → ∞
  • Leftover Hash Lemma: PA compresses Eve's information exponentially
  • Authenticated classical channel prevents man-in-the-middle
  • QBER threshold ensures Eve's Holevo information stays bounded

Reference parameters for BB84 with one-way reconciliation:
  • Maximum tolerable QBER:   ~11% (depolarising channel)
  • Cascade leakage:          ~1.16 / QBER bits per key bit
  • Secure key fraction:      1 - H_bin(QBER) - leak  bits per sifted bit
  • where H_bin(p) = -p·log2(p) - (1-p)·log2(1-p)
"""

import math
import hashlib
import os
import time
from typing import List, Tuple, Optional, Dict, Any
from dataclasses import dataclass, field


# ─────────────────────────────────────────────────────────────────────────────
# Information-theoretic calculations
# ─────────────────────────────────────────────────────────────────────────────

def binary_entropy(p: float) -> float:
    """H_bin(p) = -p·log2(p) - (1-p)·log2(1-p)  (binary entropy in bits)."""
    if p <= 0 or p >= 1:
        return 0.0
    return -p * math.log2(p) - (1 - p) * math.log2(1 - p)


def secure_key_fraction(qber: float, reconciliation_efficiency: float = 1.16) -> float:
    """
    Fraction of sifted bits that become secure key bits after full post-processing.

    Formula (asymptotic BB84):
        r = 1 - H_bin(QBER) - f·H_bin(QBER)
        where f ≥ 1 is the reconciliation efficiency factor (Cascade ≈ 1.16).

    A positive rate is achievable only when QBER < ~11%.

    Parameters
    ----------
    qber                      : quantum bit error rate ∈ [0, 0.5]
    reconciliation_efficiency : bits leaked per bit of Shannon entropy (f)

    Returns
    -------
    Secure key fraction ∈ [0, 1], or 0 if QBER too high.
    """
    h = binary_entropy(qber)
    rate = 1.0 - h - reconciliation_efficiency * h
    return max(0.0, rate)


def max_tolerable_qber(reconciliation_efficiency: float = 1.16) -> float:
    """
    Find the maximum QBER at which a positive key rate is still achievable.
    Solved numerically: 1 - (1+f)·H_bin(QBER) = 0.
    """
    lo, hi = 0.0, 0.5
    for _ in range(60):
        mid = (lo + hi) / 2
        if secure_key_fraction(mid, reconciliation_efficiency) > 0:
            lo = mid
        else:
            hi = mid
    return lo


def privacy_amplification_length(
    n_sifted:  int,
    qber:      float,
    security_param: float = 1e-10,
) -> int:
    """
    Compute the final key length after privacy amplification.

    From the Leftover Hash Lemma, the final key has ε-security where:
        ε ≈ 2^{-(l - K + log(2/ε))}  →  l = K - log(2/ε) - security_margin

    Conservative bound (assuming one-way reconciliation, BB84 depolarising):
        K = n · (1 - H_bin(QBER))         # Alice's min-entropy
        leak = n · reconciliation_efficiency · H_bin(QBER)

    Parameters
    ----------
    n_sifted       : number of sifted bits (after QBER estimation sacrifice)
    qber           : measured QBER
    security_param : security parameter ε (default: 10^{-10})

    Returns
    -------
    Maximum safe key length in bits.
    """
    h    = binary_entropy(qber)
    # Min-entropy Alice holds
    k_min = n_sifted * (1.0 - h)
    # Reconciliation leakage
    leak  = n_sifted * 1.16 * h
    # Security slack from Leftover Hash Lemma: -2 log₂(ε)
    slack = -2 * math.log2(security_param) if security_param > 0 else 66
    # Final safe length
    safe_bits = int(k_min - leak - slack)
    return max(0, safe_bits)


# ─────────────────────────────────────────────────────────────────────────────
# Full post-processing pipeline result
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PostProcessingResult:
    """Complete record of a post-processing run."""
    # Inputs
    n_sifted:             int   = 0
    qber_measured:        float = 0.0
    qber_threshold:       float = 0.11

    # Error correction (Cascade)
    cascade_errors_before: int   = 0
    cascade_errors_after:  int   = 0
    cascade_passes:        int   = 0
    cascade_bits_leaked:   int   = 0
    cascade_duration_ms:   float = 0.0

    # Verification
    verification_passed:   bool  = True
    verification_hash:     str   = ""

    # Privacy amplification
    pa_input_bits:         int   = 0
    pa_output_bits:        int   = 0
    pa_theoretical_max:    int   = 0
    pa_duration_ms:        float = 0.0

    # Final key
    final_key_hex:         str   = ""
    key_fingerprint:       str   = ""
    total_duration_ms:     float = 0.0

    # Information-theoretic metrics
    secure_key_fraction:   float = 0.0
    shannon_efficiency:    float = 0.0

    @property
    def key_bytes(self) -> bytes:
        return bytes.fromhex(self.final_key_hex)

    @property
    def key_length_bits(self) -> int:
        return len(self.final_key_hex) * 4

    def summary(self) -> str:
        lines = [
            f"Sifted bits:       {self.n_sifted}",
            f"QBER:              {self.qber_measured:.2%}",
            f"Cascade errors:    {self.cascade_errors_before} → {self.cascade_errors_after}",
            f"Cascade leaked:    {self.cascade_bits_leaked} bits",
            f"PA input bits:     {self.pa_input_bits}",
            f"PA output bits:    {self.pa_output_bits} ({self.key_length_bits}-bit key)",
            f"Theoretical max:   {self.pa_theoretical_max} bits",
            f"Key fraction:      {self.secure_key_fraction:.4f}",
            f"Shannon eff:       {self.shannon_efficiency:.2%}",
            f"Total time:        {self.total_duration_ms:.1f} ms",
            f"Verification:      {'✓ PASSED' if self.verification_passed else '✗ FAILED'}",
            f"Key fingerprint:   {self.key_fingerprint}",
        ]
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Pipeline runner
# ─────────────────────────────────────────────────────────────────────────────

def run_post_processing(
    alice_sifted:    List[int],
    bob_sifted:      List[int],
    qber:            float           = None,
    target_bytes:    int             = 32,
    qber_threshold:  float           = 0.11,
    cascade_passes:  int             = 4,
    sample_fraction: float           = 0.2,
    verbose:         bool            = False,
) -> PostProcessingResult:
    """
    Run the full BB84 post-processing pipeline on Alice and Bob's sifted bits.

    Steps:
    -------
    1. Parameter estimation: measure QBER on a random sample
    2. Error correction: Cascade protocol
    3. Verification: compare SHA-256 hashes over the public channel
    4. Privacy amplification: HKDF-SHA256 to final key

    Parameters
    ----------
    alice_sifted   : Alice's sifted key bits
    bob_sifted     : Bob's sifted key bits (may have errors)
    qber           : pre-measured QBER (if None, estimated from sample)
    target_bytes   : desired final key length in bytes
    qber_threshold : abort if QBER exceeds this value
    cascade_passes : number of Cascade passes
    sample_fraction: fraction of bits used for QBER estimation
    verbose        : print progress

    Returns
    -------
    PostProcessingResult with full statistics and the final key.

    Raises
    ------
    RuntimeError: if QBER exceeds threshold or verification fails.
    """
    from cascade import cascade as _cascade
    from bb84 import estimate_error_rate, privacy_amplification

    t_start = time.perf_counter()
    res     = PostProcessingResult()
    res.n_sifted        = len(alice_sifted)
    res.qber_threshold  = qber_threshold

    def log(msg):
        if verbose:
            print(f"  [PP] {msg}")

    # ── Step 1: Parameter estimation ──────────────────────────────────────────
    log(f"Step 1: QBER estimation ({sample_fraction:.0%} sample)…")
    if qber is not None:
        measured_qber   = qber
        remaining_alice = alice_sifted
        remaining_bob   = bob_sifted
    else:
        measured_qber, remaining_alice, remaining_bob = estimate_error_rate(
            alice_sifted, bob_sifted, sample_fraction=sample_fraction
        )

    res.qber_measured = measured_qber
    log(f"  QBER = {measured_qber:.2%}")

    if measured_qber > qber_threshold:
        raise RuntimeError(
            f"ABORT: QBER {measured_qber:.2%} > threshold {qber_threshold:.2%}. "
            f"Possible eavesdropping."
        )

    # ── Step 2: Error correction (Cascade) ────────────────────────────────────
    log(f"Step 2: Cascade error correction ({cascade_passes} passes)…")
    t_casc = time.perf_counter()

    errors_before = sum(a != b for a, b in zip(remaining_alice, remaining_bob))
    casc_result   = _cascade(
        remaining_alice,
        remaining_bob,
        estimated_qber = max(measured_qber, 0.001),
        num_passes     = cascade_passes,
        verbose        = False,
    )
    errors_after = casc_result.errors_after

    res.cascade_errors_before = errors_before
    res.cascade_errors_after  = errors_after
    res.cascade_passes        = cascade_passes
    res.cascade_bits_leaked   = casc_result.parity_bits_sent
    res.cascade_duration_ms   = (time.perf_counter() - t_casc) * 1000

    log(f"  Errors: {errors_before} → {errors_after}  "
        f"(correction rate: {casc_result.correction_rate:.1%})")
    log(f"  Parity bits leaked: {casc_result.parity_bits_sent}")

    if errors_after > 0:
        log(f"  WARNING: {errors_after} uncorrected errors remain. "
            f"Keys may diverge. Consider more Cascade passes.")

    # ── Step 3: Verification ──────────────────────────────────────────────────
    log("Step 3: Verification hash…")
    alice_hash = hashlib.sha256(bytes([b & 1 for b in remaining_alice])).hexdigest()
    bob_hash   = hashlib.sha256(bytes([b & 1 for b in casc_result.bob_bits_out])).hexdigest()
    verified   = (alice_hash == bob_hash)

    res.verification_passed = verified
    res.verification_hash   = alice_hash[:16] + "…"
    log(f"  Verification: {'✓ MATCH' if verified else '✗ MISMATCH'}")

    # ── Step 4: Privacy amplification ─────────────────────────────────────────
    log(f"Step 4: Privacy amplification → {target_bytes * 8}-bit key…")
    t_pa = time.perf_counter()

    # Use Alice's bits (ground truth); in real QKD both parties run this
    # independently on their (now identical after Cascade) bit strings
    final_key = privacy_amplification(remaining_alice, target_bytes=target_bytes)

    res.pa_input_bits      = len(remaining_alice)
    res.pa_output_bits     = target_bytes * 8
    res.pa_theoretical_max = privacy_amplification_length(
        len(remaining_alice), measured_qber
    )
    res.pa_duration_ms     = (time.perf_counter() - t_pa) * 1000

    # Key metrics
    res.final_key_hex       = final_key.hex()
    res.secure_key_fraction = secure_key_fraction(measured_qber)
    # Shannon efficiency: actual key bits vs theoretical maximum
    res.shannon_efficiency  = (
        res.pa_output_bits / res.pa_theoretical_max
        if res.pa_theoretical_max > 0 else 0.0
    )

    # Key fingerprint (6 × 4-hex groups from SHA-256 of key)
    fp_bytes = hashlib.sha256(final_key).hexdigest()
    res.key_fingerprint = "-".join(
        fp_bytes[i:i+4].upper() for i in range(0, 24, 4)
    )

    res.total_duration_ms = (time.perf_counter() - t_start) * 1000

    log(f"  Key: {final_key.hex()[:16]}…  ({target_bytes * 8} bits)")
    log(f"  Fingerprint: {res.key_fingerprint}")
    log(f"  Secure fraction: {res.secure_key_fraction:.4f}  "
        f"Shannon eff: {res.shannon_efficiency:.1%}")
    log(f"  Total time: {res.total_duration_ms:.1f} ms")

    return res


# ─────────────────────────────────────────────────────────────────────────────
# Integrated BB84 + post-processing
# ─────────────────────────────────────────────────────────────────────────────

def bb84_full_pipeline(
    num_qubits:    int         = 1024,
    noise_config               = None,
    eavesdrop:     bool        = False,
    target_bytes:  int         = 32,
    cascade_passes: int        = 4,
    verbose:       bool        = True,
) -> Tuple["BB84Result", PostProcessingResult]:
    """
    Run BB84 key generation followed by full post-processing.

    Returns
    -------
    (bb84_result, post_processing_result)
    """
    from bb84 import run_bb84
    from noise_model import NoiseConfig, run_bb84_noisy

    if noise_config is None:
        r = run_bb84(num_qubits, eavesdrop=eavesdrop,
                     verbose_callback=print if verbose else None)
    else:
        r = run_bb84_noisy(num_qubits, noise_config, eavesdrop=eavesdrop,
                           verbose_callback=print if verbose else None)

    if verbose:
        print(f"\n[Pipeline] Starting post-processing on {len(r.alice_sifted)} sifted bits…")

    pp = run_post_processing(
        alice_sifted  = r.alice_sifted,
        bob_sifted    = r.bob_sifted,
        qber          = r.error_rate,
        target_bytes  = target_bytes,
        cascade_passes = cascade_passes,
        verbose       = verbose,
    )

    return r, pp


# ─────────────────────────────────────────────────────────────────────────────
# Security parameter sweep
# ─────────────────────────────────────────────────────────────────────────────

def sweep_security_parameters(
    qber_values: List[float] = None,
    n_sifted:    int         = 500,
) -> List[Dict[str, Any]]:
    """
    Compute theoretical key rates and lengths across QBER values.

    Returns a list of dicts with information-theoretic metrics.
    """
    if qber_values is None:
        qber_values = [0.0, 0.01, 0.02, 0.05, 0.08, 0.10, 0.11, 0.12, 0.15]

    rows = []
    for q in qber_values:
        h         = binary_entropy(q)
        frac      = secure_key_fraction(q)
        pa_max    = privacy_amplification_length(n_sifted, q)
        rows.append({
            "qber":              q,
            "binary_entropy":    round(h, 4),
            "key_fraction":      round(frac, 4),
            "pa_bits_per_500":   pa_max,
            "key_bits_per_500":  max(0, int(frac * n_sifted)),
            "achievable":        frac > 0,
        })
    return rows


def print_security_table(qber_values: List[float] = None) -> None:
    """Print a formatted security parameter table."""
    rows = sweep_security_parameters(qber_values)
    try:
        from rich.table import Table
        from rich.console import Console
        from rich import box
        t = Table(title="BB84 Security Parameters", box=box.ROUNDED)
        t.add_column("QBER",        justify="right")
        t.add_column("H_bin(QBER)", justify="right")
        t.add_column("Key fraction", justify="right")
        t.add_column("Key bits/500 sifted", justify="right")
        t.add_column("Achievable",  justify="center")

        for r in rows:
            color = "green" if r["achievable"] else "red"
            t.add_row(
                f"[{color}]{r['qber']:.2%}[/]",
                f"{r['binary_entropy']:.4f}",
                f"{r['key_fraction']:.4f}",
                f"{r['key_bits_per_500']}",
                f"[{color}]{'✓' if r['achievable'] else '✗'}[/]",
            )
        Console().print(t)
    except ImportError:
        header = f"  {'QBER':>6}  {'H_bin':>7}  {'Fraction':>9}  {'Key bits':>9}  OK"
        print(header)
        print("  " + "-" * (len(header) - 2))
        for r in rows:
            print(f"  {r['qber']:6.2%}  {r['binary_entropy']:7.4f}  "
                  f"{r['key_fraction']:9.4f}  {r['key_bits_per_500']:9d}  "
                  f"{'✓' if r['achievable'] else '✗'}")


# ─────────────────────────────────────────────────────────────────────────────
# Matplotlib security plot
# ─────────────────────────────────────────────────────────────────────────────

def plot_key_rate_vs_qber(
    save_path: str  = None,
    show:      bool = True,
):
    """
    Plot secure key fraction vs QBER for BB84.
    Shows theoretical maximum and Cascade-limited rate.
    """
    try:
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError:
        return None

    qbers = np.linspace(0, 0.5, 500)
    h_bin = np.array([binary_entropy(q) for q in qbers])

    # Theoretical maximum (no reconciliation overhead)
    k_max = 1 - h_bin

    # With Cascade reconciliation (f=1.16)
    k_casc = np.array([secure_key_fraction(q, 1.16) for q in qbers])

    # With ideal reconciliation (f=1.0, Shannon limit)
    k_ideal = 1 - 2 * h_bin

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))
    fig.suptitle("BB84 Security — Key Rate vs QBER", fontsize=13, fontweight="bold")

    # Key rate plot
    ax1.fill_between(qbers * 100, 0, k_casc, alpha=0.15, color="#2ecc71",
                     label="Secure region (Cascade)")
    ax1.plot(qbers * 100, k_max,  lw=2, color="#3498db", ls="--",
             label="1 − H(e)  [theoretical max]")
    ax1.plot(qbers * 100, k_ideal, lw=2, color="#9b59b6", ls="-.",
             label="1 − 2H(e)  [Shannon ideal]")
    ax1.plot(qbers * 100, k_casc,  lw=2.5, color="#2ecc71",
             label="Cascade (f=1.16)")
    ax1.axvline(11, color="orange", lw=1.5, ls=":", label="BB84 threshold 11%")
    ax1.axhline(0,  color="black",  lw=0.8)
    ax1.set_xlabel("QBER (%)", fontsize=11)
    ax1.set_ylabel("Secure key fraction", fontsize=11)
    ax1.set_title("Key Rate vs QBER", fontsize=11)
    ax1.set_xlim(0, 35)
    ax1.set_ylim(-0.05, 1.05)
    ax1.legend(fontsize=8)
    ax1.grid(alpha=0.3)

    # Binary entropy
    ax2.plot(qbers * 100, h_bin, lw=2.5, color="#e74c3c")
    ax2.fill_between(qbers * 100, 0, h_bin, alpha=0.15, color="#e74c3c")
    ax2.axvline(11,   color="orange", lw=1.5, ls=":", label="BB84 threshold")
    ax2.axhline(0.5,  color="gray",   lw=1,   ls="--", label="H=0.5 (max)")
    ax2.set_xlabel("QBER (%)", fontsize=11)
    ax2.set_ylabel("Binary entropy H(e)", fontsize=11)
    ax2.set_title("Binary Entropy Function", fontsize=11)
    ax2.set_xlim(0, 50)
    ax2.set_ylim(0, 1.05)
    ax2.legend(fontsize=8)
    ax2.grid(alpha=0.3)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    if show:
        plt.show()
    return fig
