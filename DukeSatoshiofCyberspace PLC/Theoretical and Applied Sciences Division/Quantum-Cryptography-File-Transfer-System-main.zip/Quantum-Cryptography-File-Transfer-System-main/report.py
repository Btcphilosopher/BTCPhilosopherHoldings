"""
report.py — Quantum Cryptography Session Report Generator
==========================================================
Generates a self-contained HTML security report from a QKD session,
embedding:
  • Session metadata (protocol, timestamp, parameters)
  • BB84 / E91 statistics (QBER, efficiency, sifted key length)
  • Cascade reconciliation results (if available)
  • Noise model parameters (if used)
  • Key quality metrics (entropy, fingerprint)
  • Embedded base64 plots (Bloch sphere, BB84 strip, CHSH, key distribution)
  • Security assessment and recommendations

The report is a single .html file that opens in any browser without
any external dependencies.
"""

import base64
import datetime
import hashlib
import json
import math
import os
import tempfile
from typing import Optional, Dict, Any, List


# ─────────────────────────────────────────────────────────────────────────────
# HTML template
# ─────────────────────────────────────────────────────────────────────────────

_CSS = """
:root {
  --bg: #0d1117; --surface: #161b22; --card: #1c2128;
  --border: #30363d; --text: #c9d1d9; --dim: #8b949e;
  --accent: #58a6ff; --green: #3fb950; --yellow: #d29922;
  --red: #f85149; --purple: #bc8cff;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background: var(--bg); color: var(--text); font-family: 'Segoe UI', system-ui, sans-serif;
       font-size: 14px; line-height: 1.6; }
.container { max-width: 1100px; margin: 0 auto; padding: 24px 16px; }
header { background: var(--surface); border-bottom: 1px solid var(--border);
         padding: 20px 24px; display: flex; align-items: center; gap: 16px; }
header .logo { font-size: 32px; }
header h1 { font-size: 22px; font-weight: 700; color: var(--accent); }
header .subtitle { color: var(--dim); font-size: 12px; margin-top: 2px; }
.section { margin: 24px 0; }
.section-title { font-size: 16px; font-weight: 700; color: var(--accent);
                 border-bottom: 1px solid var(--border); padding-bottom: 8px;
                 margin-bottom: 16px; }
.card { background: var(--card); border: 1px solid var(--border); border-radius: 8px;
        padding: 16px; margin-bottom: 12px; }
.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; }
.metric { background: var(--surface); border: 1px solid var(--border); border-radius: 6px;
          padding: 12px 16px; }
.metric .label { font-size: 11px; color: var(--dim); text-transform: uppercase;
                 letter-spacing: 0.05em; margin-bottom: 4px; }
.metric .value { font-size: 22px; font-weight: 700; font-variant-numeric: tabular-nums; }
.metric .value.ok     { color: var(--green);  }
.metric .value.warn   { color: var(--yellow); }
.metric .value.bad    { color: var(--red);    }
.metric .value.purple { color: var(--purple); }
.metric .sub { font-size: 11px; color: var(--dim); margin-top: 2px; }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
th { background: var(--surface); color: var(--dim); font-weight: 600;
     text-transform: uppercase; font-size: 11px; letter-spacing: 0.05em;
     padding: 8px 12px; text-align: left; border-bottom: 1px solid var(--border); }
td { padding: 8px 12px; border-bottom: 1px solid var(--border); }
tr:last-child td { border-bottom: none; }
tr:hover td { background: rgba(88,166,255,0.05); }
.badge { display: inline-block; padding: 2px 8px; border-radius: 12px;
         font-size: 11px; font-weight: 600; }
.badge.ok   { background: rgba(63,185,80,0.15);  color: var(--green);  }
.badge.warn { background: rgba(210,153,34,0.15); color: var(--yellow); }
.badge.bad  { background: rgba(248,81,73,0.15);  color: var(--red);    }
.key-hex { font-family: 'Courier New', monospace; font-size: 12px; color: var(--yellow);
           word-break: break-all; background: var(--surface); padding: 8px 12px;
           border-radius: 4px; border: 1px solid var(--border); margin: 6px 0; }
.plot-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(420px, 1fr)); gap: 16px; }
.plot-box { background: var(--card); border: 1px solid var(--border); border-radius: 8px;
            padding: 12px; text-align: center; }
.plot-box img { max-width: 100%; border-radius: 4px; }
.plot-box .caption { font-size: 11px; color: var(--dim); margin-top: 6px; }
.assessment { list-style: none; }
.assessment li { padding: 6px 0; display: flex; align-items: flex-start; gap: 8px; }
.assessment li::before { content: ''; }
.mono { font-family: 'Courier New', monospace; font-size: 12px; }
.footer { text-align: center; color: var(--dim); font-size: 11px;
          border-top: 1px solid var(--border); padding-top: 16px; margin-top: 32px; }
"""

_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>QKD Session Report — {title}</title>
<style>{css}</style>
</head>
<body>
<header>
  <div class="logo">⚛</div>
  <div>
    <h1>Quantum Cryptography Session Report</h1>
    <div class="subtitle">{protocol} Protocol · Generated {timestamp}</div>
  </div>
</header>

<div class="container">

{body}

<div class="footer">
  Generated by Quantum Crypto File Transfer System · AES-256-GCM + {protocol} ·
  Python {python_version}
</div>

</div>
</body>
</html>"""


# ─────────────────────────────────────────────────────────────────────────────
# Section builders
# ─────────────────────────────────────────────────────────────────────────────

def _badge(value: str, level: str) -> str:
    return f'<span class="badge {level}">{value}</span>'


def _metric(label: str, value: str, cls: str = "", sub: str = "") -> str:
    sub_html = f'<div class="sub">{sub}</div>' if sub else ""
    return f"""
    <div class="metric">
      <div class="label">{label}</div>
      <div class="value {cls}">{value}</div>
      {sub_html}
    </div>"""


def _section(title: str, content: str) -> str:
    return f"""
<div class="section">
  <div class="section-title">{title}</div>
  {content}
</div>"""


def _table(headers: List[str], rows: List[List[str]]) -> str:
    th_html = "".join(f"<th>{h}</th>" for h in headers)
    rows_html = "".join(
        "<tr>" + "".join(f"<td>{c}</td>" for c in row) + "</tr>"
        for row in rows
    )
    return f"<table><thead><tr>{th_html}</tr></thead><tbody>{rows_html}</tbody></table>"


def _embed_image(path: str) -> str:
    """Read a PNG and return a base64 data URL."""
    with open(path, "rb") as f:
        data = base64.b64encode(f.read()).decode()
    return f"data:image/png;base64,{data}"


# ─────────────────────────────────────────────────────────────────────────────
# Report generator
# ─────────────────────────────────────────────────────────────────────────────

def generate_report(
    session_data:    Dict[str, Any],
    output_path:     str,
    include_plots:   bool = True,
    plot_dir:        str  = None,
) -> str:
    """
    Generate a full HTML security report.

    Parameters
    ----------
    session_data : dict containing session info (see build_session_data helpers)
    output_path  : where to write the .html file
    include_plots: embed matplotlib plots as base64 images
    plot_dir     : directory for temporary plot files (auto-created if None)

    Returns
    -------
    Path to the generated HTML file.
    """
    import sys

    protocol  = session_data.get("protocol", "BB84").upper()
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")
    key_hex   = session_data.get("key_hex", "")
    qber      = session_data.get("qber", 0.0)

    sections = []

    # ── 1. Overview metrics ───────────────────────────────────────────────────
    qber_cls  = "ok" if qber < 0.05 else ("warn" if qber < 0.11 else "bad")
    key_bits  = len(key_hex) * 4
    eve       = session_data.get("eavesdrop", False)
    eve_badge = _badge("Eve Detected" if eve else "No Eve", "bad" if eve else "ok")

    metrics_html = '<div class="grid">' + (
        _metric("Protocol",          protocol,           "purple") +
        _metric("QBER",              f"{qber:.2%}",      qber_cls,
                sub="Quantum Bit Error Rate") +
        _metric("Key Length",        f"{key_bits} bits", "ok",
                sub=f"{key_bits//8} bytes") +
        _metric("Qubits / Pairs",    str(session_data.get("num_qubits", "—")), "",
                sub="transmitted") +
        _metric("Sifted Bits",       str(session_data.get("sifted_count", "—")), "",
                sub=f"efficiency {session_data.get('efficiency', 0):.1%}") +
        _metric("Eavesdrop",         eve_badge,          "")
    ) + "</div>"
    sections.append(_section("Session Overview", metrics_html))

    # ── 2. Key material ───────────────────────────────────────────────────────
    fp   = _fingerprint(key_hex) if key_hex else "—"
    qual = _assess_key_quality(key_hex)
    key_html = f"""
    <div class="card">
      <strong>AES-256 Key Hex</strong>
      <div class="key-hex">{key_hex or '(not available)'}</div>
      <table style="margin-top:10px">
        <tr><td>Fingerprint</td><td class="mono">{fp}</td></tr>
        <tr><td>Quality</td>    <td>{_badge(qual['rating'], qual['cls'])}</td></tr>
        <tr><td>Bit balance</td><td>{qual.get('bit_balance','—')}</td></tr>
        <tr><td>Unique bytes</td><td>{qual.get('unique_bytes','—')} / {key_bits//8}</td></tr>
      </table>
    </div>"""
    sections.append(_section("Key Material", key_html))

    # ── 3. Protocol details ───────────────────────────────────────────────────
    prot_rows = _build_protocol_rows(session_data, protocol)
    prot_html = _table(["Parameter", "Value", "Notes"], prot_rows)
    sections.append(_section(f"{protocol} Protocol Parameters", prot_html))

    # ── 4. Cascade (if present) ───────────────────────────────────────────────
    casc = session_data.get("cascade")
    if casc:
        casc_html = '<div class="grid">' + (
            _metric("Errors Before",   str(casc.get("errors_before", "—")), "bad") +
            _metric("Errors After",    str(casc.get("errors_after",  "—")),
                    "ok" if casc.get("errors_after", 1) == 0 else "warn") +
            _metric("Correction Rate", f"{casc.get('correction_rate', 0):.1%}", "ok") +
            _metric("Parity Bits Sent",str(casc.get("parity_bits_sent","—")),"",
                    sub="leaked to public channel") +
            _metric("Binary Searches", str(casc.get("binary_searches","—")), "") +
            _metric("Leakage",         f"{casc.get('leakage',0):.4f}","warn",
                    sub="bits leaked per key bit")
        ) + "</div>"
        sections.append(_section("Cascade Error Reconciliation", casc_html))

    # ── 5. Noise model (if present) ───────────────────────────────────────────
    noise = session_data.get("noise")
    if noise:
        noise_rows = [
            ["Depolarizing p",    f"{noise.get('depolarizing_p',0):.4f}", "Isotropic qubit error"],
            ["Bit-flip p",        f"{noise.get('bit_flip_p',0):.4f}",    "X-gate error"],
            ["Phase-flip p",      f"{noise.get('phase_flip_p',0):.4f}",  "Z-gate error"],
            ["Amplitude damping", f"{noise.get('amplitude_damping',0):.4f}", "T1 decay"],
            ["Phase damping",     f"{noise.get('phase_damping',0):.4f}", "T2 dephasing"],
            ["Photon loss η",     f"{noise.get('photon_loss_eta',1):.4f}",
             f"≈{_eta_to_km(noise.get('photon_loss_eta',1)):.1f} km fibre equiv."],
        ]
        noise_html = _table(["Parameter", "Value", "Description"], noise_rows)
        sections.append(_section("Quantum Channel Noise Model", noise_html))

    # ── 6. Security assessment ────────────────────────────────────────────────
    items = _build_assessment(session_data, protocol, qber)
    assess_html = '<ul class="assessment">' + "".join(
        f'<li><span>{icon}</span><span>{text}</span></li>'
        for icon, text in items
    ) + "</ul>"
    sections.append(_section("Security Assessment", assess_html))

    # ── 7. Plots ──────────────────────────────────────────────────────────────
    if include_plots:
        plots_html = _generate_plot_section(session_data, plot_dir)
        if plots_html:
            sections.append(_section("Visualisations", plots_html))

    # ── Assemble ──────────────────────────────────────────────────────────────
    body = "\n".join(sections)
    html = _HTML_TEMPLATE.format(
        title          = f"{protocol} · {timestamp}",
        css            = _CSS,
        protocol       = protocol,
        timestamp      = timestamp,
        body           = body,
        python_version = sys.version.split()[0],
    )

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    return output_path


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _fingerprint(key_hex: str) -> str:
    if not key_hex:
        return "—"
    digest = hashlib.sha256(bytes.fromhex(key_hex)).hexdigest()
    groups = [digest[i:i+4].upper() for i in range(0, 24, 4)]
    return "-".join(groups)


def _assess_key_quality(key_hex: str) -> dict:
    if not key_hex:
        return {"rating": "N/A", "cls": "warn", "bit_balance": "—", "unique_bytes": "—"}
    kb = bytes.fromhex(key_hex)
    n  = len(kb)
    unique = len(set(kb))
    ones   = sum(bin(b).count("1") for b in kb)
    total_bits = n * 8
    balance = ones / total_bits
    score   = (unique / min(n, 256)) * 0.5 + (1 - abs(balance - 0.5) * 2) * 0.5
    rating  = "Excellent" if score > 0.9 else ("Good" if score > 0.75 else "Fair")
    cls     = "ok" if score > 0.9 else ("warn" if score > 0.75 else "bad")
    return {
        "rating":       rating,
        "cls":          cls,
        "bit_balance":  f"{balance:.3f} (ideal: 0.500)",
        "unique_bytes": unique,
    }


def _eta_to_km(eta: float) -> float:
    if eta <= 0:
        return 999.0
    return -10 * math.log10(max(eta, 1e-10)) / 0.2


def _build_protocol_rows(data: dict, protocol: str) -> list:
    rows = []
    if protocol == "BB84":
        rows = [
            ["Qubits transmitted",  str(data.get("num_qubits", "—")), "Alice → Bob (quantum channel)"],
            ["Basis",               "Z (rectilinear), X (diagonal)", "Random choice per qubit"],
            ["Sifted bits",         str(data.get("sifted_count", "—")), "After basis comparison"],
            ["Efficiency",          f"{data.get('efficiency', 0):.1%}", "Sifted / transmitted (ideal ≈ 50%)"],
            ["QBER",                f"{data.get('qber', 0):.3%}", "Ideal = 0%, Eve = ~25%"],
            ["Abort threshold",     "11%", "QBER above this → eavesdropping suspected"],
            ["Privacy amplification","SHA-256 / HKDF", "Removes Eve's partial information"],
        ]
    elif protocol == "E91":
        rows = [
            ["Bell pairs",          str(data.get("num_qubits", "—")), "Entangled pairs generated"],
            ["Alice angles",        "0°, 45°, 90°", "Random measurement angles"],
            ["Bob angles",          "45°, 90°, 135°", "Random measurement angles"],
            ["CHSH S",              f"{data.get('chsh_S', 0):.4f}", f"Classical ≤ 2.0, Quantum max ≈ 2.828"],
            ["Bell test",           "PASSED" if data.get("chsh_S", 0) > 2 else "FAILED",
             "Violation confirms entanglement & security"],
            ["Key error rate",      f"{data.get('qber', 0):.3%}", "From matching-angle measurements"],
        ]
    rows.append(["Final key length", f"{len(data.get('key_hex','')) * 4} bits",
                 "After privacy amplification"])
    return rows


def _build_assessment(data: dict, protocol: str, qber: float) -> list:
    items = []
    eve   = data.get("eavesdrop", False)

    if qber < 0.05:
        items.append(("✅", f"<strong>QBER {qber:.2%}</strong> is well within safe limits (< 5%). "
                            "Channel appears noise-free."))
    elif qber < 0.11:
        items.append(("⚠️", f"<strong>QBER {qber:.2%}</strong> is elevated but below the 11% abort threshold. "
                            "Minor noise or weak eavesdropping may be present."))
    else:
        items.append(("🚨", f"<strong>QBER {qber:.2%}</strong> EXCEEDS the 11% abort threshold. "
                            "Strong eavesdropping or severe channel noise detected. "
                            "<em>This key should NOT be used.</em>"))

    if protocol == "E91":
        chsh_s = data.get("chsh_S", 0)
        if chsh_s > 2.0:
            items.append(("✅", f"Bell inequality violated (S = {chsh_s:.4f} > 2). "
                                "Entanglement is intact — quantum security guaranteed."))
        else:
            items.append(("🚨", f"Bell inequality NOT violated (S = {chsh_s:.4f} ≤ 2). "
                                "Entanglement may have been disturbed by Eve."))

    if not eve:
        items.append(("✅", "No eavesdropper simulated. Key generation proceeded securely."))
    else:
        items.append(("🚨", "Eve (intercept-resend) was present during key exchange. "
                            "QBER reflects eavesdropping signature."))

    key_quality = _assess_key_quality(data.get("key_hex", ""))
    items.append(("✅" if key_quality["cls"] == "ok" else "⚠️",
                  f"Key quality: <strong>{key_quality['rating']}</strong>. "
                  f"Bit balance: {key_quality['bit_balance']}."))

    items.append(("✅", "AES-256-GCM provides authenticated encryption. "
                        "Any tampering with encrypted files will be detected."))

    casc = data.get("cascade")
    if casc:
        if casc.get("errors_after", 1) == 0:
            items.append(("✅", f"Cascade reconciliation corrected all "
                                f"{casc['errors_before']} bit errors. "
                                f"Alice and Bob share identical keys."))
        else:
            items.append(("⚠️", f"Cascade left {casc['errors_after']} uncorrected errors. "
                                "Increase num_passes or check QBER."))

    return items


def _generate_plot_section(data: dict, plot_dir: Optional[str]) -> str:
    """Generate plots and embed them as base64 in HTML."""
    try:
        import matplotlib
        matplotlib.use("Agg")
    except ImportError:
        return "<p>matplotlib not installed — plots unavailable.</p>"

    tmp_owned = plot_dir is None
    if tmp_owned:
        plot_dir = tempfile.mkdtemp(prefix="qcrypto_report_")

    plots = []

    try:
        # Bloch sphere
        from bloch_viz import plot_bloch_sphere
        from qubit_sim import Qubit
        p = os.path.join(plot_dir, "bloch.png")
        fig = plot_bloch_sphere(
            [Qubit.zero(), Qubit.plus(), Qubit.one(), Qubit.minus()],
            ["|0⟩", "|+⟩", "|1⟩", "|−⟩"],
            title="Common Qubit States",
            save_path=p, show=False,
        )
        if fig and os.path.isfile(p):
            plots.append((p, "Bloch Sphere — Common Qubit States"))
        _close(fig)
    except Exception:
        pass

    try:
        # BB84 session strip
        bb84_result = data.get("_bb84_result")
        if bb84_result:
            from bloch_viz import plot_bb84_session
            p = os.path.join(plot_dir, "bb84_strip.png")
            fig = plot_bb84_session(bb84_result, n_show=64, save_path=p, show=False)
            if fig and os.path.isfile(p):
                plots.append((p, "BB84 Session — First 64 Qubits (gold = sifted)"))
            _close(fig)
    except Exception:
        pass

    try:
        # Key distribution
        key_hex = data.get("key_hex", "")
        if key_hex and len(key_hex) == 64:
            from bloch_viz import plot_key_distribution
            p = os.path.join(plot_dir, "key_dist.png")
            fig = plot_key_distribution(key_hex, "Key Byte Distribution",
                                        save_path=p, show=False)
            if fig and os.path.isfile(p):
                plots.append((p, "Key Byte & Bit Distribution"))
            _close(fig)
    except Exception:
        pass

    try:
        # E91 CHSH (if E91 session)
        if data.get("protocol", "").upper() == "E91":
            from bloch_viz import plot_chsh_comparison
            from e91 import run_e91
            r1 = run_e91(num_pairs=300, eavesdrop=False)
            r2 = run_e91(num_pairs=300, eavesdrop=True)
            p  = os.path.join(plot_dir, "chsh.png")
            fig = plot_chsh_comparison([
                ("Clean channel",  r1.chsh_S, "#2ecc71"),
                ("With Eve",       r2.chsh_S, "#e74c3c"),
                ("Classical bound", 2.0,      "#f39c12"),
            ], save_path=p, show=False)
            if fig and os.path.isfile(p):
                plots.append((p, "CHSH Bell Parameter Comparison"))
            _close(fig)
    except Exception:
        pass

    try:
        # Cascade performance (if cascade data available)
        if data.get("cascade"):
            from cascade import sweep_cascade_vs_qber, plot_cascade_performance
            sweep = sweep_cascade_vs_qber(trials=2)
            p = os.path.join(plot_dir, "cascade.png")
            fig = plot_cascade_performance(sweep, save_path=p, show=False)
            if fig and os.path.isfile(p):
                plots.append((p, "Cascade Error Correction Performance"))
            _close(fig)
    except Exception:
        pass

    if not plots:
        return "<p style='color:var(--dim)'>No plots could be generated.</p>"

    boxes = ""
    for path, caption in plots:
        try:
            src = _embed_image(path)
            boxes += f"""
            <div class="plot-box">
              <img src="{src}" alt="{caption}">
              <div class="caption">{caption}</div>
            </div>"""
        except Exception:
            pass

    return f'<div class="plot-grid">{boxes}</div>'


def _close(fig):
    try:
        import matplotlib.pyplot as plt
        plt.close(fig)
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
# Session data builders
# ─────────────────────────────────────────────────────────────────────────────

def session_data_from_bb84(result, noise_config=None, cascade_info=None) -> dict:
    """Build session_data dict from a BB84Result."""
    data = {
        "protocol":     "BB84",
        "key_hex":      result.final_key_hex,
        "num_qubits":   result.num_qubits,
        "sifted_count": len(result.sifted_indices),
        "efficiency":   result.efficiency,
        "qber":         result.error_rate,
        "eavesdrop":    result.eve_present,
        "_bb84_result": result,
    }
    if noise_config:
        data["noise"] = {
            "depolarizing_p":   noise_config.depolarizing_p,
            "bit_flip_p":       noise_config.bit_flip_p,
            "phase_flip_p":     noise_config.phase_flip_p,
            "amplitude_damping":noise_config.amplitude_damping,
            "phase_damping":    noise_config.phase_damping,
            "photon_loss_eta":  noise_config.photon_loss_eta,
        }
    if cascade_info:
        cr = cascade_info.get("cascade_result")
        if cr:
            data["cascade"] = {
                "errors_before":    cr.errors_before,
                "errors_after":     cr.errors_after,
                "correction_rate":  cr.correction_rate,
                "parity_bits_sent": cr.parity_bits_sent,
                "binary_searches":  cr.binary_searches,
                "leakage":          cr.information_leakage,
            }
    return data


def session_data_from_e91(result, noise_config=None) -> dict:
    """Build session_data dict from an E91Result."""
    data = {
        "protocol":     "E91",
        "key_hex":      result.final_key_hex,
        "num_qubits":   result.num_pairs,
        "sifted_count": len(result.key_bits_alice),
        "efficiency":   len(result.key_bits_alice) / result.num_pairs if result.num_pairs else 0,
        "qber":         result.error_rate,
        "eavesdrop":    result.eve_present,
        "chsh_S":       result.chsh_S,
    }
    if noise_config:
        data["noise"] = {
            "depolarizing_p":   noise_config.depolarizing_p,
            "bit_flip_p":       noise_config.bit_flip_p,
            "phase_flip_p":     noise_config.phase_flip_p,
            "amplitude_damping":noise_config.amplitude_damping,
            "phase_damping":    noise_config.phase_damping,
            "photon_loss_eta":  noise_config.photon_loss_eta,
        }
    return data


# ─────────────────────────────────────────────────────────────────────────────
# CLI convenience
# ─────────────────────────────────────────────────────────────────────────────

def generate_bb84_report(
    num_qubits:    int  = 512,
    eavesdrop:     bool = False,
    with_cascade:  bool = True,
    output_path:   str  = "qkd_report.html",
    verbose:       bool = True,
) -> str:
    """
    One-shot: run a BB84 session and generate a full HTML report.

    Returns
    -------
    Path to generated HTML file.
    """
    from bb84 import run_bb84
    from cascade import bb84_with_cascade

    if verbose:
        print(f"Running BB84 ({num_qubits} qubits, eavesdrop={eavesdrop})…")

    result = run_bb84(num_qubits=num_qubits, eavesdrop=eavesdrop)

    cascade_info = None
    if with_cascade:
        if verbose:
            print("Running Cascade reconciliation…")
        try:
            cascade_info = bb84_with_cascade(
                num_qubits=num_qubits,
                eavesdrop=eavesdrop,
                target_key_bytes=32,
            )
        except Exception as exc:
            if verbose:
                print(f"  Cascade skipped: {exc}")

    data = session_data_from_bb84(result, cascade_info=cascade_info)

    if verbose:
        print(f"Generating report → {output_path}")

    return generate_report(data, output_path, include_plots=True)


def generate_e91_report(
    num_pairs:   int  = 600,
    eavesdrop:   bool = False,
    output_path: str  = "e91_report.html",
    verbose:     bool = True,
) -> str:
    """One-shot: run E91 and generate HTML report."""
    from e91 import run_e91

    if verbose:
        print(f"Running E91 ({num_pairs} pairs, eavesdrop={eavesdrop})…")

    result = run_e91(num_pairs=num_pairs, eavesdrop=eavesdrop)
    data   = session_data_from_e91(result)

    if verbose:
        print(f"Generating report → {output_path}")

    return generate_report(data, output_path, include_plots=True)
