"""
interactive_demo.py — Live Interactive Terminal Demonstration
=============================================================
A guided, self-running demo of the entire quantum cryptography system.
Each section pauses for the user to read before continuing.

Run with:  python interactive_demo.py
           python interactive_demo.py --fast   (no pauses)
           python interactive_demo.py --save-plots <dir>
"""

import sys
import os
import time
import argparse
import textwrap
import random

# ── Optional Rich ─────────────────────────────────────────────────────────────
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.rule import Rule
    from rich.syntax import Syntax
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
    from rich import box
    RICH = True
    console = Console(width=88)
except ImportError:
    RICH = False
    console = None

sys.path.insert(0, os.path.dirname(__file__))


# ─────────────────────────────────────────────────────────────────────────────
# Display helpers
# ─────────────────────────────────────────────────────────────────────────────

FAST_MODE   = False
SAVE_PLOTS  = None

def cprint(msg: str, style: str = ""):
    if RICH: console.print(msg, style=style)
    else:    print(msg)

def rule(title: str = ""):
    if RICH: console.print(Rule(f"[bold cyan]{title}[/]", style="cyan"))
    else:    print(f"\n{'═'*70}\n  {title}\n{'═'*70}")

def panel(content: str, title: str = "", border: str = "cyan"):
    if RICH:
        console.print(Panel(content, title=f"[bold]{title}[/]",
                            border_style=border, padding=(0, 2)))
    else:
        print(f"\n┌─ {title} {'─'*(60-len(title))}┐")
        for line in content.split("\n"):
            print(f"│  {line}")
        print(f"└{'─'*62}┘")

def pause(msg: str = "Press ENTER to continue…"):
    if not FAST_MODE:
        try:
            input(f"\n  [dim]{msg}[/dim]" if not RICH else f"\n  {msg}")
        except (EOFError, KeyboardInterrupt):
            pass
    else:
        time.sleep(0.05)

def typed(text: str, delay: float = 0.018):
    """Print text character-by-character for effect."""
    if FAST_MODE:
        cprint(text)
        return
    for ch in text:
        print(ch, end="", flush=True)
        time.sleep(delay if ch not in " \n" else 0)
    print()

def animate_bar(label: str, n: int = 30, delay: float = 0.03):
    """Show a simple animated progress bar."""
    if FAST_MODE:
        cprint(f"  {label}: [{'█'*n}] done")
        return
    sys.stdout.write(f"  {label}: [")
    for i in range(n):
        sys.stdout.write("█")
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write("] ✓\n")
    sys.stdout.flush()


# ─────────────────────────────────────────────────────────────────────────────
# Section 1: Introduction
# ─────────────────────────────────────────────────────────────────────────────

def demo_intro():
    rule("Welcome to the Quantum Cryptography Demo")

    intro = textwrap.dedent("""\
    This demo walks through a complete quantum key distribution session,
    from single-qubit simulation through to encrypted file transfer.

    What you'll see:
      • Single qubit states, gates, and measurement
      • Bell pair entanglement
      • BB84 quantum key distribution (with and without eavesdropping)
      • E91 entanglement-based QKD and Bell inequality test
      • Cascade error reconciliation
      • AES-256-GCM file encryption using a quantum-generated key
      • Full information-theoretic security analysis
    """)
    cprint(intro, style="dim")
    pause()


# ─────────────────────────────────────────────────────────────────────────────
# Section 2: Qubit Simulation
# ─────────────────────────────────────────────────────────────────────────────

def demo_qubits():
    rule("Qubit Simulation")

    from qubit_sim import Qubit, TwoQubitSystem

    cprint("\n[bold cyan]Single Qubit States[/bold cyan]\n")
    cprint("A qubit lives in a superposition α|0⟩ + β|1⟩ where |α|² + |β|² = 1.")
    cprint("The probability of measuring 0 is |α|², and 1 is |β|².\n")

    for label, q in [
        ("|0⟩  (computational basis)",     Qubit.zero()),
        ("|1⟩  (computational basis)",     Qubit.one()),
        ("|+⟩ = H|0⟩  (superposition)",   Qubit.plus()),
        ("|−⟩          (superposition)",   Qubit.minus()),
    ]:
        p0, p1 = q.probabilities
        bar0 = "█" * int(p0 * 24)
        bar1 = "█" * int(p1 * 24)
        cprint(f"  [bold]{label}[/bold]")
        cprint(f"    P(|0⟩) = {p0:.4f}  [{bar0:<24}]")
        cprint(f"    P(|1⟩) = {p1:.4f}  [{bar1:<24}]")
        cprint(f"    State:   {q}\n")

    pause("Press ENTER to see gate operations…")

    rule("Quantum Gates")
    cprint("\nGates transform qubit states. All quantum gates are unitary — reversible.\n")

    gates_demo = [
        ("Hadamard (H)",   Qubit.zero(),   lambda q: q.hadamard(),
         "Creates superposition from |0⟩"),
        ("Pauli-X (NOT)",  Qubit.zero(),   lambda q: q.pauli_x(),
         "Flips |0⟩ → |1⟩ (quantum NOT gate)"),
        ("Pauli-Z",        Qubit.plus(),   lambda q: q.pauli_z(),
         "Phase flip: |+⟩ → |−⟩"),
        ("H·H = I",        Qubit.zero(),   lambda q: q.hadamard().hadamard(),
         "Two Hadamards = identity"),
        ("H·X·H = Z",      Qubit.plus(),   lambda q: q.hadamard().pauli_x().hadamard(),
         "Basis change conjugation"),
    ]

    for gate, q, fn, desc in gates_demo:
        result = fn(q)
        p0, p1 = result.probabilities
        cprint(f"  [bold yellow]{gate}[/bold yellow]  {desc}")
        cprint(f"    → P(|0⟩)={p0:.3f}  P(|1⟩)={p1:.3f}")
        if not FAST_MODE: time.sleep(0.4)

    pause("Press ENTER to see Bell state entanglement…")

    rule("Bell State Entanglement")
    cprint("\nBell pairs are maximally entangled two-qubit states.")
    cprint("Measuring one qubit instantly determines the other, regardless of distance.\n")

    cprint("[bold]Creating Φ⁺ = (|00⟩ + |11⟩)/√2 via H ⊗ I followed by CNOT:[/bold]\n")
    cprint("  Step 1:  |00⟩  →  (|0⟩+|1⟩)/√2 ⊗ |0⟩  [Hadamard on qubit 0]")
    cprint("  Step 2:  →  (|00⟩+|11⟩)/√2            [CNOT: control=q0, target=q1]\n")

    animate_bar("Generating Bell pair", 20, 0.04 if not FAST_MODE else 0)

    cprint("\n[bold]Measuring Φ⁺ Bell pair 8 times:[/bold]")
    for i in range(8):
        pair = TwoQubitSystem.bell_phi_plus()
        q0, q1 = pair.measure_both()
        corr = "✓ correlated" if q0 == q1 else "✗ anti-corr"
        cprint(f"  Trial {i+1}: Alice={q0}, Bob={q1}  [{corr}]")
        if not FAST_MODE: time.sleep(0.2)

    cprint("\n  → Alice and Bob always get the same result! (100% correlation for Φ⁺)")
    cprint("  → This correlation cannot be explained classically (Bell's theorem)")

    pause()


# ─────────────────────────────────────────────────────────────────────────────
# Section 3: BB84 Protocol
# ─────────────────────────────────────────────────────────────────────────────

def demo_bb84():
    rule("BB84 Quantum Key Distribution")

    from bb84 import run_bb84

    cprint("\nBB84 (Bennett & Brassard, 1984) — the first QKD protocol.\n")
    cprint("Protocol steps:")
    for step in [
        "1. Alice encodes random bits in random bases (Z=rectilinear, X=diagonal)",
        "2. Bob measures each qubit in a random basis",
        "3. They publicly compare bases — discard mismatches",
        "4. Remaining bits = sifted key  (≈50% survive)",
        "5. Estimate QBER on random sample; abort if > 11%",
        "6. Privacy amplification → final secret key",
    ]:
        cprint(f"  [dim]{step}[/dim]")
        if not FAST_MODE: time.sleep(0.15)

    pause("Press ENTER to run BB84 with 512 qubits…")

    cprint("\n[bold green]Running BB84 — no eavesdropper…[/bold green]\n")
    messages = []

    def cb(m):
        messages.append(m)
        cprint(f"  [dim]{m}[/dim]")

    result = run_bb84(num_qubits=512, eavesdrop=False, verbose_callback=cb)

    cprint(f"\n[bold]Results:[/bold]")
    cprint(f"  Qubits transmitted:  512")
    cprint(f"  Sifted bits:         {len(result.sifted_indices)}  ({result.efficiency:.1%} efficiency)")
    cprint(f"  QBER:                {result.error_rate:.2%}  [green]✓ within threshold[/green]")
    cprint(f"  Key bits:            {result.key_length_bits}")
    cprint(f"  Final key (256-bit): [yellow]{result.final_key_hex[:32]}…[/yellow]")

    pause("Press ENTER to see eavesdropping detection…")

    cprint("\n[bold red]Now injecting Eve (intercept-resend attack)…[/bold red]\n")
    cprint("Eve intercepts each qubit, measures in a random basis, and re-sends.")
    cprint("When Eve guesses the wrong basis (50% of the time), she introduces errors.\n")

    eve_messages = []

    try:
        result_eve = run_bb84(
            num_qubits=1024,
            eavesdrop=True,
            error_threshold=1.0,    # don't abort — show the QBER
            verbose_callback=lambda m: eve_messages.append(m),
        )
        qber_e = result_eve.error_rate
    except RuntimeError as exc:
        qber_e = 0.25   # typical Eve QBER

    cprint(f"  QBER without Eve:  {result.error_rate:.2%}")
    cprint(f"  QBER with Eve:     [red]{qber_e:.2%}[/red]  "
           f"(expected ~25% for intercept-resend)")
    cprint(f"\n  → QBER > 11%  →  [bold red]EAVESDROPPING DETECTED! Protocol aborts.[/bold red]")

    # Show first 12 qubits as a table
    pause("Press ENTER to inspect the qubit-by-qubit trace…")
    rule("BB84 Qubit Trace (first 12 qubits)")

    if RICH:
        t = Table(box=box.SIMPLE_HEAVY, show_header=True)
        for col in ["#", "Alice bit", "Alice basis", "Bob basis",
                    "Bob meas", "Match", "Key bit"]:
            t.add_column(col, justify="center")

        sifted_set = set(result.sifted_indices)
        for i in range(min(12, len(result.alice_bits))):
            match = result.alice_bases[i] == result.bob_bases[i]
            kb = str(result.alice_bits[i]) if i in sifted_set else "—"
            t.add_row(
                str(i),
                str(result.alice_bits[i]),
                result.alice_bases[i],
                result.bob_bases[i],
                str(result.bob_measurements[i]),
                "[green]✓[/green]" if match else "[red]✗[/red]",
                f"[bold cyan]{kb}[/bold cyan]" if match else kb,
            )
        console.print(t)
    else:
        print(f"  # Alice AliceBasis BobBasis BobMeas Match KeyBit")
        sifted_set = set(result.sifted_indices)
        for i in range(min(12, len(result.alice_bits))):
            match = result.alice_bases[i] == result.bob_bases[i]
            kb = str(result.alice_bits[i]) if i in sifted_set else "—"
            print(f"  {i:2d}   {result.alice_bits[i]}      {result.alice_bases[i]}       "
                  f"{result.bob_bases[i]}       {result.bob_measurements[i]}     "
                  f"{'Y' if match else 'N'}   {kb}")

    pause()


# ─────────────────────────────────────────────────────────────────────────────
# Section 4: E91 Protocol
# ─────────────────────────────────────────────────────────────────────────────

def demo_e91():
    rule("E91 Entanglement-Based QKD (Ekert 1991)")

    from e91 import run_e91
    import math

    cprint("\nE91 uses entangled Bell pairs instead of prepared qubits.")
    cprint("Security is guaranteed by Bell's theorem — any eavesdropper")
    cprint("disturbs entanglement, reducing the CHSH parameter S below 2.\n")

    cprint("[bold]CHSH Bell inequality:[/bold]")
    cprint("  Classical physics:  S ≤ 2.000")
    cprint(f"  Quantum mechanics:  S ≤ 2√2 ≈ {2*math.sqrt(2):.4f}")
    cprint("  Eve present:        S drops toward 2 or below\n")

    pause("Press ENTER to run E91 without Eve…")

    cprint("[bold green]E91 — clean channel (no Eve):[/bold green]\n")
    r_clean = run_e91(num_pairs=600, eavesdrop=False,
                      verbose_callback=lambda m: cprint(f"  [dim]{m}[/dim]"))
    s_clean = r_clean.chsh_S

    cprint(f"\n  CHSH S = [bold green]{s_clean:.4f}[/bold green]  "
           f"({'Bell inequality VIOLATED ✓' if s_clean > 2 else 'NOT violated ✗'})")
    cprint(f"  Key error rate: {r_clean.error_rate:.2%}")
    cprint(f"  Key bits: {r_clean.key_length_bits}")

    pause("Press ENTER to inject Eve into E91…")

    cprint("\n[bold red]E91 — with Eve intercepting entangled qubits:[/bold red]\n")
    r_eve = run_e91(num_pairs=600, eavesdrop=True,
                    verbose_callback=lambda m: cprint(f"  [dim]{m}[/dim]"))
    s_eve = r_eve.chsh_S

    cprint(f"\n  CHSH S = [bold red]{s_eve:.4f}[/bold red]  "
           f"({'Violated' if s_eve > 2 else 'NOT violated — eavesdropping!'})")

    # Visualise the S-parameter bar
    quantum_max = 2 * math.sqrt(2)
    width = 44
    pos_clean = int(s_clean  / quantum_max * width)
    pos_eve   = int(s_eve    / quantum_max * width)
    pos_class = int(2.0      / quantum_max * width)

    cprint(f"\n  [bold]S-parameter scale[/bold]  (0 ─────── 2.0 ─────── 2√2)")
    bar = list("░" * width)
    bar[pos_class] = "|"
    if 0 <= pos_clean < width: bar[pos_clean] = "●"
    cprint(f"  No-Eve: [green]{''.join(bar)}[/green]  S={s_clean:.3f}")
    bar2 = list("░" * width)
    bar2[pos_class] = "|"
    if 0 <= pos_eve < width: bar2[pos_eve] = "●"
    cprint(f"  +Eve:   [red]{''.join(bar2)}[/red]  S={s_eve:.3f}")
    cprint(f"           [yellow]{'':>{pos_class}}↑ Classical limit[/yellow]")

    pause()


# ─────────────────────────────────────────────────────────────────────────────
# Section 5: Error Reconciliation
# ─────────────────────────────────────────────────────────────────────────────

def demo_cascade():
    rule("Cascade Error Reconciliation")

    from cascade import cascade, CascadeResult
    from post_processing import binary_entropy, secure_key_fraction, print_security_table

    cprint("\nAfter sifting, Alice and Bob's keys differ slightly (QBER ≈ 1–10%).")
    cprint("Cascade corrects these errors using interactive parity checks over")
    cprint("the authenticated public classical channel.\n")

    cprint("[bold]Algorithm:[/bold]")
    for step in [
        "1. Divide bits into blocks of size k₁ = ⌈0.73 / QBER⌉",
        "2. Alice announces block parities publicly",
        "3. Bob finds differing parities → binary search locates error",
        "4. Correcting one error may reveal others → backward correction",
        "5. Repeat with doubled block sizes (4 passes typical)",
    ]:
        cprint(f"  [dim]{step}[/dim]")
        if not FAST_MODE: time.sleep(0.12)

    pause("Press ENTER to run Cascade on a real noisy key…")

    # Create a realistic noisy pair (QBER ≈ 5%)
    n = 400
    qber = 0.05
    alice_bits = [random.randint(0, 1) for _ in range(n)]
    bob_bits   = [b ^ (1 if random.random() < qber else 0) for b in alice_bits]
    errors_in  = sum(a != b for a, b in zip(alice_bits, bob_bits))

    cprint(f"\n  Simulating {n} sifted bits with QBER={qber:.0%}…")
    cprint(f"  Errors introduced: {errors_in} / {n}  ({errors_in/n:.1%})\n")

    t0 = time.perf_counter()
    animate_bar("Running Cascade", 25, 0.04 if not FAST_MODE else 0)
    result = cascade(alice_bits, bob_bits, estimated_qber=qber, num_passes=4)
    elapsed = (time.perf_counter() - t0) * 1000

    cprint(f"\n  [bold]Cascade Results:[/bold]")
    cprint(f"  Errors before:    {result.errors_before}")
    cprint(f"  Errors after:     [{'green' if result.errors_after==0 else 'red'}]"
           f"{result.errors_after}[/]")
    cprint(f"  Correction rate:  {result.correction_rate:.1%}")
    cprint(f"  Parity bits sent: {result.parity_bits_sent}  (leaked to Eve)")
    cprint(f"  Passes:           {result.passes}")
    cprint(f"  Time:             {elapsed:.1f} ms")

    pause("Press ENTER for the information-theoretic security table…")

    rule("Information-Theoretic Security Parameters")
    cprint("\nHow many secret key bits can we extract from n sifted bits at QBER e?\n")
    print_security_table([0.0, 0.01, 0.03, 0.05, 0.08, 0.10, 0.11, 0.12, 0.15])
    cprint("\n  Formula:  r = 1 − H(e) − 1.16·H(e)  (asymptotic BB84, Cascade)")
    cprint("  H(e) = binary entropy = −e·log₂e − (1−e)·log₂(1−e)")

    pause()


# ─────────────────────────────────────────────────────────────────────────────
# Section 6: File Encryption
# ─────────────────────────────────────────────────────────────────────────────

def demo_encryption():
    rule("AES-256-GCM File Encryption")
    import tempfile

    from bb84 import run_bb84
    from crypto import (encrypt_file, decrypt_file, verify_roundtrip,
                        compute_file_hash, inspect_qcrypt_header)

    cprint("\nThe quantum key drives AES-256-GCM encryption:")
    cprint("  • AES-256:  256-bit key, 128-bit block")
    cprint("  • GCM mode: authenticated encryption (confidentiality + integrity)")
    cprint("  • Fresh 96-bit random nonce per file — prevents replay")
    cprint("  • 128-bit GCM tag: detects any tampering\n")

    cprint("[bold]File format (.qcrypt):[/bold]")
    cprint("  ┌────────────────────────────────────────┐")
    cprint("  │  Magic     │ 8B  │ 'QCRYPT\\x01\\x00'  │")
    cprint("  │  Nonce     │ 12B │ random per file    │")
    cprint("  │  GCM tag   │ 16B │ auth tag           │")
    cprint("  │  Length    │ 8B  │ plaintext size     │")
    cprint("  │  Ciphertext│ var │                    │")
    cprint("  └────────────────────────────────────────┘")

    pause("Press ENTER to run a live encrypt/decrypt round-trip…")

    # Generate key
    cprint("\n[bold green]Step 1: Generating quantum key via BB84…[/bold green]")
    animate_bar("BB84 key exchange", 28, 0.03 if not FAST_MODE else 0)
    result = run_bb84(num_qubits=512, eavesdrop=False)
    key    = result.final_key_hex
    cprint(f"  Key (256-bit): [yellow]{key[:32]}…[/yellow]")

    with tempfile.TemporaryDirectory() as tmp:
        orig_path = os.path.join(tmp, "quantum_secret.txt")
        enc_path  = os.path.join(tmp, "quantum_secret.txt.qcrypt")
        dec_path  = os.path.join(tmp, "quantum_secret_recovered.txt")

        # Create file
        content = (
            "QUANTUM ENCRYPTED DOCUMENT\n"
            "==========================\n"
            "This file was encrypted using a key generated by the\n"
            "BB84 Quantum Key Distribution protocol.\n\n"
            "The key was never transmitted over a classical channel.\n"
            "Any eavesdropping attempt would have been detected.\n\n"
            f"Key fingerprint: {key[:8]}…{key[-8:]}\n"
        )
        with open(orig_path, "w") as f:
            f.write(content * 100)

        orig_size = os.path.getsize(orig_path)
        orig_hash = compute_file_hash(orig_path)

        # Encrypt
        cprint(f"\n[bold green]Step 2: Encrypting ({orig_size:,} bytes)…[/bold green]")
        animate_bar("AES-256-GCM encrypt", 28, 0.02 if not FAST_MODE else 0)
        t0 = time.perf_counter()
        meta = encrypt_file(orig_path, enc_path, key)
        enc_ms = (time.perf_counter() - t0) * 1000

        cprint(f"  Input:    {meta['input_size']:,} bytes")
        cprint(f"  Output:   {meta['output_size']:,} bytes (+{meta['overhead_bytes']}B header)")
        cprint(f"  Nonce:    [dim]{meta['nonce_hex']}[/dim]")
        cprint(f"  Auth tag: [dim]{meta['integrity_tag_hex']}[/dim]")
        cprint(f"  Speed:    {meta['input_size'] / enc_ms / 1024:.1f} MB/s")

        # Inspect header (no key needed)
        header = inspect_qcrypt_header(enc_path)
        cprint(f"\n  File header reveals: format={header['format']}, "
               f"plaintext_size={header['plaintext_size']:,}B")
        cprint("  (nonce + tag are visible; ciphertext is indistinguishable from random)")

        # Decrypt
        cprint(f"\n[bold green]Step 3: Decrypting…[/bold green]")
        animate_bar("AES-256-GCM decrypt", 28, 0.02 if not FAST_MODE else 0)
        dec_meta = decrypt_file(enc_path, dec_path, key)
        cprint(f"  GCM integrity: [bold green]{'VERIFIED ✓' if dec_meta['integrity_verified'] else 'FAILED ✗'}[/bold green]")

        # Verify
        match = verify_roundtrip(orig_path, dec_path)
        cprint(f"  Bit-for-bit:   [bold {'green' if match else 'red'}]"
               f"{'IDENTICAL ✓' if match else 'DIFFER ✗'}[/bold {'green' if match else 'red'}]")

        # Wrong key demo
        cprint(f"\n[bold]Demonstrating tamper detection with wrong key:[/bold]")
        wrong_key = os.urandom(32).hex()
        try:
            decrypt_file(enc_path, dec_path + ".bad", wrong_key)
            cprint("  [red]Should have failed![/red]")
        except Exception:
            cprint("  [bold green]Wrong key → GCM authentication FAILED → no output ✓[/bold green]")

    pause()


# ─────────────────────────────────────────────────────────────────────────────
# Section 7: Network Session
# ─────────────────────────────────────────────────────────────────────────────

def demo_network():
    rule("Alice ↔ Bob Network Session (TCP Sockets)")

    from network_sim import run_network_session, print_session_log
    from noise_model import NoiseConfig

    cprint("\nThis runs Alice and Bob as real Python threads communicating")
    cprint("over localhost TCP sockets — mimicking a real QKD network link.\n")

    cprint("  [bold]Quantum channel[/bold]  → Alice sends qubit states to Bob")
    cprint("  [bold]Classical channel[/bold] → authenticated public channel for sifting")
    cprint("  [bold]Reconciliation[/bold]   → Alice sends her bits for Bob to correct")
    cprint("  [bold]Verification[/bold]     → hash comparison confirms matching keys\n")

    for label, cfg, n in [
        ("Ideal channel",  NoiseConfig.ideal(),      256),
        ("10km fibre",     NoiseConfig.fibre_10km(), 512),
    ]:
        pause(f"Press ENTER to run '{label}' session…")
        cprint(f"\n[bold cyan]Session: {label} ({n} qubits)[/bold cyan]")
        animate_bar(f"Running {label}", 30, 0.03 if not FAST_MODE else 0)

        r = run_network_session(n, cfg, verbose=False)

        cprint(f"  Duration:    {r.duration_ms:.0f} ms")
        cprint(f"  Sifted bits: {r.sifted_count}")
        cprint(f"  QBER:        {r.qber:.2%}")
        cprint(f"  Alice key:   [yellow]{r.alice_key_hex[:24]}…[/yellow]")
        cprint(f"  Bob key:     [yellow]{r.bob_key_hex[:24]}…[/yellow]")
        cprint(f"  Keys match:  [bold {'green' if r.keys_match else 'red'}]"
               f"{'✓ YES' if r.keys_match else '✗ NO'}[/bold {'green' if r.keys_match else 'red'}]")

    pause()


# ─────────────────────────────────────────────────────────────────────────────
# Section 8: Noise Models
# ─────────────────────────────────────────────────────────────────────────────

def demo_noise():
    rule("Quantum Channel Noise Models")

    from noise_model import (NoiseConfig, run_bb84_noisy,
                              fibre_distance_to_eta, eta_to_fibre_distance)

    cprint("\nReal quantum channels are noisy. Key sources of error:\n")
    noise_types = [
        ("Depolarizing",      "Random X/Y/Z error with prob p"),
        ("Bit-flip",          "Random NOT gate (fibre birefringence)"),
        ("Phase-flip",        "Phase decoherence (atmosphere, vibration)"),
        ("Amplitude damping", "T₁ relaxation: |1⟩ → |0⟩ (SC qubits)"),
        ("Photon loss",       "Fibre attenuation ~0.2 dB/km"),
    ]
    for name, desc in noise_types:
        cprint(f"  • [bold]{name:<22}[/bold] {desc}")

    pause("Press ENTER to compare channel presets…")

    cprint("\n[bold]Running BB84 under different channel models:[/bold]\n")

    configs = [
        ("Ideal",           NoiseConfig.ideal(),           300),
        ("10km fibre",      NoiseConfig.fibre_10km(),      600),
        ("Noisy lab",       NoiseConfig.noisy_lab(),       600),
        ("Superconducting", NoiseConfig.superconducting(),  600),
    ]

    if RICH:
        t = Table(box=box.SIMPLE, show_header=True)
        t.add_column("Channel",      style="bold")
        t.add_column("Description",  style="dim")
        t.add_column("QBER",         justify="right")
        t.add_column("Key bits",     justify="right")
        t.add_column("Status",       justify="center")

    rows = []
    for label, cfg, nq in configs:
        try:
            r = run_bb84_noisy(nq, cfg)
            qber = r.error_rate
            kbits = r.key_length_bits
            ok = qber < 0.11
        except RuntimeError:
            qber, kbits, ok = 0.99, 0, False

        desc = cfg.description()[:40]
        rows.append((label, desc, qber, kbits, ok))

    for label, desc, qber, kbits, ok in rows:
        color = "green" if ok else "red"
        if RICH:
            t.add_row(label, desc, f"{qber:.2%}",
                      str(kbits),
                      f"[{color}]{'✓ OK' if ok else '✗ FAIL'}[/]")
        else:
            print(f"  {label:<20} QBER={qber:.2%}  bits={kbits}  "
                  f"{'OK' if ok else 'FAIL'}")

    if RICH: console.print(t)

    # Fibre distance table
    pause("Press ENTER to see QBER vs fibre distance…")
    cprint("\n[bold]Fibre distance vs transmissivity (α = 0.2 dB/km):[/bold]\n")
    for km in [0, 5, 10, 25, 50, 100]:
        eta = fibre_distance_to_eta(km)
        cprint(f"  {km:>4} km  →  η = {eta:.4f}  "
               f"({'▓' * int(eta * 20):<20} {eta:.0%})")

    pause()


# ─────────────────────────────────────────────────────────────────────────────
# Section 9: Security Analysis
# ─────────────────────────────────────────────────────────────────────────────

def demo_security():
    rule("Full Security Analysis")

    from post_processing import (run_post_processing, print_security_table,
                                  max_tolerable_qber, binary_entropy,
                                  secure_key_fraction)
    from bb84 import run_bb84

    cprint("\nRunning complete post-processing pipeline with security metrics…\n")

    result = run_bb84(num_qubits=800, eavesdrop=False)
    pause("Press ENTER to start post-processing…")

    animate_bar("Running Cascade + Privacy Amplification", 35,
                0.02 if not FAST_MODE else 0)

    pp = run_post_processing(
        alice_sifted  = result.alice_sifted,
        bob_sifted    = result.bob_sifted,
        qber          = result.error_rate,
        target_bytes  = 32,
        cascade_passes = 4,
        verbose       = False,
    )

    cprint(f"\n[bold]Post-Processing Summary:[/bold]")
    for line in pp.summary().split("\n"):
        cprint(f"  {line}")

    pause("Press ENTER for security parameter analysis…")

    qber_max = max_tolerable_qber()
    cprint(f"\n[bold]Security Boundaries:[/bold]")
    cprint(f"  Max tolerable QBER (Cascade, f=1.16):  {qber_max:.2%}")
    cprint(f"  At QBER=0%:    secure fraction = {secure_key_fraction(0):.4f}")
    cprint(f"  At QBER=5%:    secure fraction = {secure_key_fraction(0.05):.4f}")
    cprint(f"  At QBER=10%:   secure fraction = {secure_key_fraction(0.10):.4f}")
    cprint(f"  At QBER=11%:   secure fraction = {secure_key_fraction(0.11):.4f}")

    pause("Press ENTER for the full security table…")
    print_security_table()

    pause()


# ─────────────────────────────────────────────────────────────────────────────
# Section 10: Visualisations
# ─────────────────────────────────────────────────────────────────────────────

def demo_visualisations():
    rule("Visualisations")

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        cprint("[dim]matplotlib not available — skipping visualisations[/dim]")
        return

    from bloch_viz import (plot_bloch_sphere, plot_gate_evolution,
                            plot_bb84_session, plot_chsh_comparison,
                            plot_key_distribution)
    from post_processing import plot_key_rate_vs_qber
    from bb84 import run_bb84
    from e91 import run_e91
    from qubit_sim import Qubit

    plots = [
        ("Bloch sphere (common states)",  None),
        ("Gate evolution H→Z→H→X",        None),
        ("BB84 strip chart",              None),
        ("E91 CHSH comparison",           None),
        ("Key rate vs QBER",              None),
    ]
    cprint(f"\nGenerating {len(plots)} visualisations…\n")

    saved = []
    save_dir = SAVE_PLOTS or os.path.join(os.getcwd(), "demo_plots")
    os.makedirs(save_dir, exist_ok=True)

    animate_bar("Bloch sphere", 20, 0.04 if not FAST_MODE else 0)
    states = [Qubit.zero(), Qubit.plus(), Qubit.one(), Qubit.minus()]
    fig = plot_bloch_sphere(states, ["|0⟩","|+⟩","|1⟩","|−⟩"],
                            title="Common Qubit States", show=False)
    p = os.path.join(save_dir, "bloch_sphere.png")
    fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    saved.append(p)

    animate_bar("Gate evolution", 20, 0.04 if not FAST_MODE else 0)
    fig = plot_gate_evolution(["H", "Z", "H", "X"], show=False)
    p = os.path.join(save_dir, "gate_evolution.png")
    fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    saved.append(p)

    animate_bar("BB84 strip chart", 20, 0.04 if not FAST_MODE else 0)
    r_bb84 = run_bb84(num_qubits=128)
    fig = plot_bb84_session(r_bb84, n_show=64, show=False)
    p = os.path.join(save_dir, "bb84_session.png")
    fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    saved.append(p)

    animate_bar("E91 CHSH chart", 20, 0.04 if not FAST_MODE else 0)
    r1 = run_e91(num_pairs=400, eavesdrop=False)
    r2 = run_e91(num_pairs=400, eavesdrop=True)
    fig = plot_chsh_comparison([
        ("Clean",    r1.chsh_S, "#2ecc71"),
        ("+Eve",     r2.chsh_S, "#e74c3c"),
        ("Classical", 2.0,      "#f39c12"),
    ], show=False)
    p = os.path.join(save_dir, "chsh_comparison.png")
    fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    saved.append(p)

    animate_bar("Security rate plot", 20, 0.04 if not FAST_MODE else 0)
    fig = plot_key_rate_vs_qber(show=False)
    p = os.path.join(save_dir, "key_rate_vs_qber.png")
    fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    saved.append(p)

    cprint(f"\n  Saved {len(saved)} plots to [cyan]{save_dir}/[/cyan]:")
    for p in saved:
        size = os.path.getsize(p)
        cprint(f"  • {os.path.basename(p):35s}  {size:,} bytes")

    pause()


# ─────────────────────────────────────────────────────────────────────────────
# Final summary
# ─────────────────────────────────────────────────────────────────────────────

def demo_summary():
    rule("Summary")

    summary = textwrap.dedent("""\
    You've seen the complete quantum cryptography pipeline:

    ┌─────────────────────────────────────────────────────────────────┐
    │  Qubit simulation   Hadamard · Pauli · CNOT · Bell states       │
    │  BB84 protocol      Prepare · Measure · Sift · QBER · PA        │
    │  E91 protocol       Entanglement · CHSH · Bell inequality        │
    │  Cascade            Error reconciliation (4-pass parity)         │
    │  Post-processing    Information-theoretic security bounds        │
    │  AES-256-GCM        Authenticated encryption with quantum key    │
    │  Network session    Alice↔Bob over real TCP sockets              │
    │  Noise models       Depolarizing · Loss · T₁/T₂ decoherence     │
    └─────────────────────────────────────────────────────────────────┘

    CLI commands:
      python cli.py generate-key --protocol bb84 --qubits 512
      python cli.py encrypt-file secret.pdf --key <hex>
      python cli.py decrypt-file secret.pdf.qcrypt --key <hex>
      python cli.py simulate --demo e91

    GUI:
      python gui.py

    Full test suite:
      python demo.py
      python demo_extended.py

    Benchmarks:
      python benchmarks.py
    """)

    panel(summary, "Quantum Crypto System — Complete", border="green")


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

SECTIONS = [
    ("Introduction",            demo_intro),
    ("Qubit Simulation",        demo_qubits),
    ("BB84 Protocol",           demo_bb84),
    ("E91 Protocol",            demo_e91),
    ("Cascade Reconciliation",  demo_cascade),
    ("File Encryption",         demo_encryption),
    ("Network Session",         demo_network),
    ("Noise Models",            demo_noise),
    ("Security Analysis",       demo_security),
    ("Visualisations",          demo_visualisations),
    ("Summary",                 demo_summary),
]


def main():
    global FAST_MODE, SAVE_PLOTS

    parser = argparse.ArgumentParser(description="Quantum Crypto Interactive Demo")
    parser.add_argument("--fast",        action="store_true",
                        help="Skip all pauses (automated mode)")
    parser.add_argument("--save-plots",  metavar="DIR",
                        help="Save all plots to this directory")
    parser.add_argument("--section",     type=int, default=0,
                        help="Start from this section number (1-indexed)")
    parser.add_argument("--only",        type=int, default=0,
                        help="Run only this section number")
    args = parser.parse_args()

    FAST_MODE  = args.fast
    SAVE_PLOTS = args.save_plots

    if RICH:
        console.print("\n[bold cyan]⚛  Quantum Cryptography — Interactive Demo[/bold cyan]")
        console.print("[dim]BB84 · E91 · Cascade · AES-256-GCM · Network Session[/dim]\n")
    else:
        print("\n⚛  Quantum Cryptography — Interactive Demo")
        print("BB84 · E91 · Cascade · AES-256-GCM · Network Session\n")

    start = (args.only - 1) if args.only else max(0, args.section - 1)
    end   = args.only if args.only else len(SECTIONS)

    for i, (name, fn) in enumerate(SECTIONS[start:end], start + 1):
        try:
            fn()
        except KeyboardInterrupt:
            cprint("\n\n[yellow]Demo interrupted.[/yellow]")
            break
        except Exception as exc:
            cprint(f"\n[red]Section '{name}' error: {exc}[/red]")
            if not FAST_MODE:
                import traceback; traceback.print_exc()
            pause("Press ENTER to continue to next section…")


if __name__ == "__main__":
    main()
