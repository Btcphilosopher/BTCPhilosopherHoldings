"""
noise_model.py — Quantum Channel Noise Models
===============================================
Simulates realistic noise sources that affect qubit transmission:

  • Depolarizing channel   — symmetric X/Y/Z errors (most common model)
  • Bit-flip channel       — random X gate with probability p
  • Phase-flip channel     — random Z gate with probability p
  • Amplitude damping      — |1⟩ → |0⟩ decay (T1 relaxation)
  • Phase damping          — dephasing without energy loss (T2 decoherence)
  • Photon loss            — qubit is lost entirely (erasure channel)
  • Composite channel      — combine any subset of the above

Key physical insights:
  • In fibre-optic QKD, the dominant noise source is photon loss (~0.2 dB/km)
  • Depolarizing error rate p > 11% → protocol should abort (same as Eve's 25% QBER)
  • T1/T2 decoherence affects trapped-ion and superconducting implementations
  • This module plugs directly into BB84/E91 via a noise_fn callback

References:
  Nielsen & Chuang, "Quantum Computation and Quantum Information", Ch. 8.
  Gisin et al., "Quantum cryptography", Rev. Mod. Phys. 74, 145 (2002).
"""

import random
import math
from typing import Callable, List, Optional, Tuple, Dict
from dataclasses import dataclass, field

import numpy as np

from qubit_sim import Qubit, TwoQubitSystem, X_GATE, Y_GATE, Z_GATE, I_GATE


# ─────────────────────────────────────────────────────────────────────────────
# Kraus operator helpers
# ─────────────────────────────────────────────────────────────────────────────

def _apply_kraus(qubit: Qubit, kraus_ops: List[np.ndarray]) -> Qubit:
    """
    Apply a quantum channel defined by Kraus operators {K_i} to a pure state |ψ⟩.

    For a pure state, we probabilistically select which Kraus branch to take:
        P(branch i) = ⟨ψ|K_i†K_i|ψ⟩
    Then collapse to the (normalised) output of that branch.

    This is equivalent to tracing over the environment for a mixed-state input.
    """
    psi = qubit.state
    probs = []
    states = []

    for K in kraus_ops:
        out  = K @ psi
        prob = float(np.real(np.dot(out.conj(), out)))
        probs.append(max(prob, 0.0))     # guard against float negatives
        states.append(out)

    total = sum(probs)
    if total < 1e-12:
        # Degenerate: return unchanged
        return qubit
    probs = [p / total for p in probs]

    idx = np.random.choice(len(probs), p=probs)
    out = states[idx]
    norm = np.linalg.norm(out)
    qubit.state = out / norm if norm > 1e-12 else out
    return qubit


# ─────────────────────────────────────────────────────────────────────────────
# Individual noise channels
# ─────────────────────────────────────────────────────────────────────────────

def depolarizing_channel(qubit: Qubit, p: float) -> Qubit:
    """
    Depolarizing channel: with probability p the qubit is replaced by
    the maximally mixed state (equivalent to random X, Y, or Z error).

    Kraus operators:
        K0 = √(1-p)·I
        K1 = √(p/3)·X
        K2 = √(p/3)·Y
        K3 = √(p/3)·Z

    Physical interpretation: models isotropic noise (photon scattering,
    random rotations). Standard model for comparing QKD error budgets.
    Introduces QBER of ≈ p/2 in the sifted key.

    Parameters
    ----------
    p : error probability ∈ [0, 1]; p=0 → identity, p=3/4 → fully mixed
    """
    if p <= 0:
        return qubit
    p = min(p, 0.999)

    kraus = [
        math.sqrt(1 - p)       * I_GATE,
        math.sqrt(p / 3)       * X_GATE,
        math.sqrt(p / 3)       * Y_GATE,
        math.sqrt(p / 3)       * Z_GATE,
    ]
    return _apply_kraus(qubit, kraus)


def bit_flip_channel(qubit: Qubit, p: float) -> Qubit:
    """
    Bit-flip channel: applies X gate (flip |0⟩↔|1⟩) with probability p.

    Kraus operators:  K0 = √(1-p)·I,  K1 = √p·X
    """
    if p <= 0:
        return qubit
    p = min(p, 1.0)
    return _apply_kraus(qubit, [math.sqrt(1-p)*I_GATE, math.sqrt(p)*X_GATE])


def phase_flip_channel(qubit: Qubit, p: float) -> Qubit:
    """
    Phase-flip channel: applies Z gate (phase flip) with probability p.
    Only matters in the X basis; invisible in Z-basis measurements.

    Kraus operators:  K0 = √(1-p)·I,  K1 = √p·Z
    """
    if p <= 0:
        return qubit
    p = min(p, 1.0)
    return _apply_kraus(qubit, [math.sqrt(1-p)*I_GATE, math.sqrt(p)*Z_GATE])


def amplitude_damping_channel(qubit: Qubit, gamma: float) -> Qubit:
    """
    Amplitude damping channel: models T1 relaxation (energy loss to environment).
    |1⟩ decays to |0⟩ with probability gamma.

    Kraus operators:
        K0 = [[1, 0], [0, √(1-γ)]]   — no decay
        K1 = [[0, √γ], [0, 0]]       — decay to |0⟩

    Physical: superconducting qubit T1 decay, spontaneous emission.
    Only affects the |1⟩ component; |0⟩ is stable (ground state).

    Parameters
    ----------
    gamma : decay probability ∈ [0, 1]; gamma = 1 → always collapses to |0⟩
    """
    if gamma <= 0:
        return qubit
    gamma = min(gamma, 1.0)

    K0 = np.array([[1, 0],
                   [0, math.sqrt(1 - gamma)]], dtype=complex)
    K1 = np.array([[0, math.sqrt(gamma)],
                   [0, 0]], dtype=complex)
    return _apply_kraus(qubit, [K0, K1])


def phase_damping_channel(qubit: Qubit, gamma: float) -> Qubit:
    """
    Phase damping (dephasing) channel: destroys superposition without energy loss.
    Models T2 dephasing, charge noise in superconducting qubits.

    Kraus operators:
        K0 = [[1, 0], [0, √(1-γ)]]
        K1 = [[0, 0], [0, √γ]]

    Effect: off-diagonal density matrix elements decay as e^{-γ/2}.
    """
    if gamma <= 0:
        return qubit
    gamma = min(gamma, 1.0)

    K0 = np.array([[1, 0],
                   [0, math.sqrt(1 - gamma)]], dtype=complex)
    K1 = np.array([[0, 0],
                   [0, math.sqrt(gamma)]], dtype=complex)
    return _apply_kraus(qubit, [K0, K1])


def photon_loss_channel(qubit: Qubit, eta: float) -> Optional[Qubit]:
    """
    Photon loss (erasure) channel: the qubit is lost with probability (1 - eta).
    Models fibre attenuation, detector inefficiency.

    In QKD, lost photons are simply discarded — they don't contribute to the
    key but also don't introduce errors (unlike depolarizing).

    Parameters
    ----------
    eta : transmission probability (channel efficiency) ∈ (0, 1]
          For fibre: eta = 10^{-αL/10}, α ≈ 0.2 dB/km
          e.g. 10 km fibre → eta = 10^{-0.2} ≈ 0.63

    Returns
    -------
    qubit (transmitted) or None (lost — discard this position)
    """
    eta = max(0.0, min(1.0, eta))
    if random.random() < eta:
        return qubit   # photon survived
    return None        # photon lost


# ─────────────────────────────────────────────────────────────────────────────
# Composite noise channel
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class NoiseConfig:
    """
    Configuration for a composite quantum channel.
    Each parameter can be set independently; they are applied sequentially.
    """
    depolarizing_p:     float = 0.0   # isotropic error probability
    bit_flip_p:         float = 0.0   # X-error probability
    phase_flip_p:       float = 0.0   # Z-error probability
    amplitude_damping:  float = 0.0   # T1 decay probability (gamma)
    phase_damping:      float = 0.0   # T2 dephasing probability
    photon_loss_eta:    float = 1.0   # channel transmissivity (1 = no loss)

    @classmethod
    def ideal(cls) -> "NoiseConfig":
        """No noise at all — perfect channel."""
        return cls()

    @classmethod
    def fibre_10km(cls) -> "NoiseConfig":
        """
        Typical 10 km single-mode fibre QKD channel.
        ~0.2 dB/km loss, small depolarizing from scattering.
        """
        return cls(
            photon_loss_eta  = 10 ** (-0.2 * 10 / 10),  # ≈ 0.631
            depolarizing_p   = 0.005,
        )

    @classmethod
    def fibre_50km(cls) -> "NoiseConfig":
        """50 km fibre — significant loss and noise."""
        return cls(
            photon_loss_eta  = 10 ** (-0.2 * 50 / 10),  # ≈ 0.100
            depolarizing_p   = 0.02,
            phase_flip_p     = 0.005,
        )

    @classmethod
    def noisy_lab(cls) -> "NoiseConfig":
        """
        Noisy lab environment — high background noise, moderate loss.
        """
        return cls(
            depolarizing_p   = 0.05,
            bit_flip_p       = 0.02,
            phase_flip_p     = 0.02,
            amplitude_damping= 0.01,
        )

    @classmethod
    def superconducting(cls) -> "NoiseConfig":
        """
        Superconducting qubit gate noise model.
        Amplitude and phase damping dominate.
        """
        return cls(
            amplitude_damping= 0.005,
            phase_damping    = 0.010,
            depolarizing_p   = 0.002,
        )

    def description(self) -> str:
        parts = []
        if self.depolarizing_p   > 0: parts.append(f"depol={self.depolarizing_p:.3f}")
        if self.bit_flip_p       > 0: parts.append(f"bitflip={self.bit_flip_p:.3f}")
        if self.phase_flip_p     > 0: parts.append(f"phaseflip={self.phase_flip_p:.3f}")
        if self.amplitude_damping> 0: parts.append(f"amp_damp={self.amplitude_damping:.3f}")
        if self.phase_damping    > 0: parts.append(f"phase_damp={self.phase_damping:.3f}")
        if self.photon_loss_eta  < 1: parts.append(f"eta={self.photon_loss_eta:.3f}")
        return ", ".join(parts) if parts else "ideal (no noise)"


def apply_noise(qubit: Qubit, config: NoiseConfig) -> Optional[Qubit]:
    """
    Pass a qubit through the composite noisy channel defined by `config`.

    Returns
    -------
    Noisy qubit, or None if the photon was lost.
    """
    if config is None:
        return qubit

    # 1. Photon loss (erasure) — check first; if lost, no further processing
    if config.photon_loss_eta < 1.0:
        result = photon_loss_channel(qubit, config.photon_loss_eta)
        if result is None:
            return None
        qubit = result

    # 2. Depolarizing
    if config.depolarizing_p > 0:
        qubit = depolarizing_channel(qubit, config.depolarizing_p)

    # 3. Bit flip
    if config.bit_flip_p > 0:
        qubit = bit_flip_channel(qubit, config.bit_flip_p)

    # 4. Phase flip
    if config.phase_flip_p > 0:
        qubit = phase_flip_channel(qubit, config.phase_flip_p)

    # 5. Amplitude damping (T1)
    if config.amplitude_damping > 0:
        qubit = amplitude_damping_channel(qubit, config.amplitude_damping)

    # 6. Phase damping (T2)
    if config.phase_damping > 0:
        qubit = phase_damping_channel(qubit, config.phase_damping)

    return qubit


# ─────────────────────────────────────────────────────────────────────────────
# Noisy BB84 session
# ─────────────────────────────────────────────────────────────────────────────

def run_bb84_noisy(
    num_qubits:       int        = 512,
    noise_config:     NoiseConfig = None,
    eavesdrop:        bool       = False,
    target_key_bytes: int        = 32,
    verbose_callback             = None,
):
    """
    Run BB84 with a realistic noisy channel model.

    This is a drop-in replacement for bb84.run_bb84() that adds:
    - Channel noise via NoiseConfig
    - Lost-photon tracking (photon_loss_eta < 1)
    - Returns same BB84Result type

    Returns
    -------
    BB84Result (from bb84 module) with noise-affected QBER.
    """
    import random as _random
    from bb84 import (BB84Result, random_bits, random_bases, alice_prepare,
                      bob_measure, sift_key, estimate_error_rate,
                      privacy_amplification, bits_to_bytes)
    from qubit_sim import Qubit

    if noise_config is None:
        noise_config = NoiseConfig.ideal()

    def log(msg):
        if verbose_callback:
            verbose_callback(msg)

    result = BB84Result(num_qubits=num_qubits)

    log(f"[NoiseQKD] Channel: {noise_config.description()}")
    log(f"[NoiseQKD] Alice preparing {num_qubits} qubits…")

    alice_bits  = random_bits(num_qubits)
    alice_bases = random_bases(num_qubits)
    qubits      = alice_prepare(alice_bits, alice_bases)

    # Pass through noisy channel
    survived_idx: List[int] = []
    noisy_qubits: List[Qubit] = []

    for i, q in enumerate(qubits):
        noisy_q = apply_noise(q, noise_config)
        if noisy_q is not None:   # photon not lost
            survived_idx.append(i)
            noisy_qubits.append(noisy_q)

    lost = num_qubits - len(survived_idx)
    loss_rate = lost / num_qubits if num_qubits > 0 else 0
    log(f"[NoiseQKD] Photon loss: {lost}/{num_qubits} ({loss_rate:.1%})")

    # Eve intercept (on surviving qubits only)
    if eavesdrop:
        from bb84 import eve_intercept
        noisy_qubits, _, _ = eve_intercept(noisy_qubits)

    # Bob measures surviving qubits
    bob_bases_full    = random_bases(num_qubits)
    bob_bases_sub     = [bob_bases_full[i] for i in survived_idx]
    alice_bases_sub   = [alice_bases[i]    for i in survived_idx]
    alice_bits_sub    = [alice_bits[i]     for i in survived_idx]

    bob_measurements  = bob_measure(noisy_qubits, bob_bases_sub)

    # Sifting
    sifted_local = sift_key(alice_bases_sub, bob_bases_sub)

    alice_sifted = [alice_bits_sub[j]    for j in sifted_local]
    bob_sifted   = [bob_measurements[j]  for j in sifted_local]

    # Map back to original indices
    sifted_global = [survived_idx[j] for j in sifted_local]

    result.alice_bits        = alice_bits
    result.alice_bases       = alice_bases
    result.bob_bases         = bob_bases_full
    result.bob_measurements  = ([0] * num_qubits)  # placeholder for lost positions
    for j, idx in enumerate(survived_idx):
        result.bob_measurements[idx] = bob_measurements[j]
    result.sifted_indices    = sifted_global
    result.alice_sifted      = alice_sifted
    result.bob_sifted        = bob_sifted

    if not alice_sifted:
        raise RuntimeError(
            f"[NoiseQKD] No sifted bits — too much photon loss "
            f"({loss_rate:.1%}). Reduce distance or increase num_qubits."
        )

    error_rate, remaining_a, remaining_b = estimate_error_rate(
        alice_sifted, bob_sifted
    )
    result.error_rate = error_rate
    log(f"[NoiseQKD] QBER={error_rate:.2%}  sifted={len(alice_sifted)}  "
        f"remaining={len(remaining_a)}")

    if len(remaining_a) < 8:
        raise RuntimeError(
            f"[NoiseQKD] Too few key bits after noise + sifting. "
            f"Increase num_qubits."
        )

    final_key        = privacy_amplification(remaining_a, target_bytes=target_key_bytes)
    result.raw_key_bits   = remaining_a
    result.final_key_hex  = final_key.hex()
    result.num_qubits     = num_qubits

    log(f"[NoiseQKD] ✓ Key: {final_key.hex()[:16]}… (loss={loss_rate:.1%}, QBER={error_rate:.2%})")
    return result


# ─────────────────────────────────────────────────────────────────────────────
# QBER vs noise sweep
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class NoiseSweepResult:
    """Results from sweeping a noise parameter across multiple levels."""
    param_name:  str
    param_values: List[float]
    qber_values:  List[float]
    key_rates:    List[float]   # bits per transmitted qubit
    loss_rates:   List[float]

    def as_table(self) -> str:
        """Return a formatted ASCII table of results."""
        header = f"  {'Param':>10}  {'QBER':>8}  {'Key rate':>10}  {'Loss':>8}"
        sep    = "  " + "-" * (len(header) - 2)
        rows   = [header, sep]
        for p, q, k, l in zip(self.param_values, self.qber_values,
                               self.key_rates, self.loss_rates):
            rows.append(f"  {p:>10.4f}  {q:>8.2%}  {k:>10.4f}  {l:>8.2%}")
        return "\n".join(rows)


def sweep_depolarizing(
    p_values:   List[float] = None,
    num_qubits: int         = 800,
    trials:     int         = 3,
) -> NoiseSweepResult:
    """
    Sweep the depolarizing error rate p and measure resulting QBER + key rate.

    Parameters
    ----------
    p_values   : list of depolarizing probabilities to test
    num_qubits : qubits per trial
    trials     : number of trials per p value (results are averaged)
    """
    if p_values is None:
        p_values = [0.0, 0.01, 0.02, 0.05, 0.08, 0.10, 0.12, 0.15, 0.20]

    qbers, key_rates, loss_rates = [], [], []

    for p in p_values:
        cfg = NoiseConfig(depolarizing_p=p)
        trial_qbers, trial_kr = [], []

        for _ in range(trials):
            try:
                r = run_bb84_noisy(num_qubits, cfg)
                trial_qbers.append(r.error_rate)
                trial_kr.append(len(r.raw_key_bits) / num_qubits)
            except RuntimeError:
                trial_qbers.append(1.0)
                trial_kr.append(0.0)

        qbers.append(sum(trial_qbers) / len(trial_qbers))
        key_rates.append(sum(trial_kr) / len(trial_kr))
        loss_rates.append(0.0)   # depolarizing doesn't lose photons

    return NoiseSweepResult(
        param_name   = "depolarizing_p",
        param_values = p_values,
        qber_values  = qbers,
        key_rates    = key_rates,
        loss_rates   = loss_rates,
    )


def sweep_photon_loss(
    eta_values: List[float] = None,
    num_qubits: int         = 1200,
    trials:     int         = 3,
) -> NoiseSweepResult:
    """
    Sweep photon-loss transmissivity eta (0 = total loss, 1 = no loss).
    Models QKD over increasing fibre distances.

    eta = 10^{-α·L/10}, so L = -10/α · log10(eta)
    For α = 0.2 dB/km: L = 50·log10(1/eta) km
    """
    if eta_values is None:
        eta_values = [1.0, 0.9, 0.75, 0.63, 0.5, 0.4, 0.32, 0.20, 0.10]

    qbers, key_rates, loss_rates = [], [], []

    for eta in eta_values:
        cfg = NoiseConfig(photon_loss_eta=eta, depolarizing_p=0.003)
        trial_qbers, trial_kr, trial_lr = [], [], []

        for _ in range(trials):
            try:
                r = run_bb84_noisy(num_qubits, cfg)
                trial_qbers.append(r.error_rate)
                trial_kr.append(len(r.raw_key_bits) / num_qubits)
                # Estimate loss from sifted count
                expected_sifted = num_qubits * eta * 0.5
                actual_sifted   = len(r.sifted_indices)
                lr = max(0.0, 1.0 - actual_sifted / max(expected_sifted, 1))
                trial_lr.append(lr)
            except RuntimeError:
                trial_qbers.append(0.0)
                trial_kr.append(0.0)
                trial_lr.append(1.0)

        qbers.append(sum(trial_qbers) / len(trial_qbers))
        key_rates.append(sum(trial_kr) / len(trial_kr))
        loss_rates.append(sum(trial_lr) / len(trial_lr))

    return NoiseSweepResult(
        param_name   = "photon_loss_eta",
        param_values = eta_values,
        qber_values  = qbers,
        key_rates    = key_rates,
        loss_rates   = loss_rates,
    )


def fibre_distance_to_eta(distance_km: float, alpha_db_per_km: float = 0.2) -> float:
    """Convert fibre distance (km) to transmissivity eta."""
    return 10 ** (-alpha_db_per_km * distance_km / 10)


def eta_to_fibre_distance(eta: float, alpha_db_per_km: float = 0.2) -> float:
    """Convert transmissivity eta to equivalent fibre distance in km."""
    if eta <= 0:
        return float("inf")
    return -10 * math.log10(eta) / alpha_db_per_km


# ─────────────────────────────────────────────────────────────────────────────
# Noise visualisation (matplotlib)
# ─────────────────────────────────────────────────────────────────────────────

def plot_noise_sweep(
    sweep:     NoiseSweepResult,
    title:     str  = "Noise Sweep",
    save_path: str  = None,
    show:      bool = True,
):
    """Plot QBER and key rate vs noise parameter."""
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("[noise_model] matplotlib not available — skipping plot")
        return None

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle(title, fontsize=13, fontweight="bold")

    xs = sweep.param_values

    # QBER plot
    ax1.plot(xs, [q * 100 for q in sweep.qber_values],
             "o-", color="#e74c3c", lw=2, ms=7, label="QBER (%)")
    ax1.axhline(11, color="orange", ls="--", lw=1.5, label="BB84 abort threshold (11%)")
    ax1.axhline(25, color="red",    ls=":",  lw=1,   label="Eve intercept-resend (25%)")
    ax1.fill_between(xs, 11, 100, alpha=0.08, color="red")
    ax1.set_xlabel(sweep.param_name, fontsize=10)
    ax1.set_ylabel("QBER (%)", fontsize=10)
    ax1.set_title("Quantum Bit Error Rate", fontsize=11)
    ax1.legend(fontsize=8); ax1.grid(alpha=0.3); ax1.set_ylim(0, 35)

    # Key rate plot
    ax2.plot(xs, sweep.key_rates,
             "s-", color="#2ecc71", lw=2, ms=7, label="Key rate (bits/qubit)")
    if any(l > 0 for l in sweep.loss_rates):
        ax2.plot(xs, sweep.loss_rates,
                 "^--", color="#f39c12", lw=1.5, ms=6, label="Loss rate")
    ax2.set_xlabel(sweep.param_name, fontsize=10)
    ax2.set_ylabel("Rate", fontsize=10)
    ax2.set_title("Key Generation Rate", fontsize=11)
    ax2.legend(fontsize=8); ax2.grid(alpha=0.3)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    if show:
        plt.show()
    return fig


def plot_channel_comparison(
    configs:   List[Tuple[str, "NoiseConfig"]],
    num_qubits: int  = 600,
    trials:     int  = 5,
    save_path:  str  = None,
    show:       bool = True,
):
    """
    Bar chart comparing QBER across different channel configurations.

    Parameters
    ----------
    configs : list of (label, NoiseConfig) pairs
    """
    try:
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError:
        return None

    labels, qbers, stds = [], [], []

    for label, cfg in configs:
        trial_qbers = []
        for _ in range(trials):
            try:
                r = run_bb84_noisy(num_qubits, cfg)
                trial_qbers.append(r.error_rate * 100)
            except RuntimeError:
                trial_qbers.append(50.0)
        labels.append(label)
        qbers.append(np.mean(trial_qbers))
        stds.append(np.std(trial_qbers))

    fig, ax = plt.subplots(figsize=(max(6, len(labels)*1.8), 5))
    colors = ["#2ecc71" if q < 11 else "#e74c3c" for q in qbers]
    bars = ax.bar(labels, qbers, yerr=stds, color=colors, edgecolor="black",
                  lw=0.8, capsize=5, width=0.6)

    ax.axhline(11, color="orange", ls="--", lw=2, label="Abort threshold (11%)")
    ax.axhline(25, color="red",    ls=":",  lw=1.5, label="Eve QBER (25%)")

    for bar, q in zip(bars, qbers):
        ax.text(bar.get_x() + bar.get_width()/2, q + 0.5,
                f"{q:.1f}%", ha="center", va="bottom", fontsize=9)

    ax.set_ylabel("QBER (%)", fontsize=11)
    ax.set_title("Channel Comparison — QBER", fontsize=13, fontweight="bold")
    ax.legend(fontsize=9); ax.grid(alpha=0.3, axis="y")
    ax.set_ylim(0, max(max(qbers) * 1.4, 30))

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    if show:
        plt.show()
    return fig
