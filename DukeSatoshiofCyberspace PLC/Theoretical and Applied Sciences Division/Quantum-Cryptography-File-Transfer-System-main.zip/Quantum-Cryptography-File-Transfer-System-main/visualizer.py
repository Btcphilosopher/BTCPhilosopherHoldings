"""
visualizer.py — Qubit State & Protocol Visualisation
======================================================
Provides text-based (Rich) and optional ASCII visualisations for:
  • Bloch sphere (ASCII art approximation)
  • Qubit probability bars
  • BB84 session table
  • E91 Bell inequality plot
  • Key hex dump

Requires only: rich (pip install rich)
"""

import math
from typing import List, Optional

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import (
        Progress, SpinnerColumn, BarColumn, TextColumn,
        TimeElapsedColumn, MofNCompleteColumn,
    )
    from rich.text import Text
    from rich.columns import Columns
    from rich import box
    from rich.syntax import Syntax
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

from qubit_sim import Qubit, TwoQubitSystem


# ─────────────────────────────────────────────────────────────────────────────
# Console singleton
# ─────────────────────────────────────────────────────────────────────────────

console = Console() if RICH_AVAILABLE else None


def _fallback_print(msg: str):
    print(msg)


def cprint(msg: str, style: str = ""):
    if RICH_AVAILABLE and console:
        console.print(msg, style=style)
    else:
        _fallback_print(msg)


# ─────────────────────────────────────────────────────────────────────────────
# Bloch sphere (ASCII)
# ─────────────────────────────────────────────────────────────────────────────

BLOCH_TEMPLATE = r"""
         Z
         |
         * ← |0⟩
        /|
       / |      θ={theta:.0f}°
      /  |
  ---*---+--- X
      \  |
       \ |
        \|
         * ← |1⟩
         |
"""


def render_bloch_sphere(qubit: Qubit) -> str:
    """Return an ASCII Bloch sphere string for a qubit state."""
    theta, phi = qubit.bloch_angles()
    p0, p1 = qubit.probabilities
    theta_deg = math.degrees(theta)
    phi_deg   = math.degrees(phi)

    lines = [
        "┌─────────────────── Bloch Sphere ───────────────────┐",
        "│                        |0⟩                         │",
        "│                         ↑                          │",
        "│                         │                          │",
    ]

    # ASCII dot position based on θ
    arrow_row = min(int(theta_deg / 180 * 6), 5)
    for i in range(7):
        if i == arrow_row:
            lines.append(f"│  X ────────────────── ● ←── state ──────────── Y   │")
        else:
            lines.append("│                         │                          │")

    lines += [
        "│                         ↓                          │",
        "│                        |1⟩                         │",
        "└────────────────────────────────────────────────────┘",
        f"  θ = {theta_deg:6.2f}°   φ = {phi_deg:7.2f}°",
        f"  P(|0⟩) = {p0:.4f}   P(|1⟩) = {p1:.4f}",
        f"  State: {qubit}",
    ]
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Probability bar chart (text)
# ─────────────────────────────────────────────────────────────────────────────

def probability_bar(prob: float, width: int = 30, char: str = "█") -> str:
    """Render a single probability as a filled bar."""
    filled = int(prob * width)
    return char * filled + "░" * (width - filled)


def show_qubit_state(qubit: Qubit, label: str = "Qubit"):
    """Pretty-print qubit state probabilities."""
    p0, p1 = qubit.probabilities
    if RICH_AVAILABLE and console:
        table = Table(title=f"[bold cyan]{label} State[/]",
                      box=box.ROUNDED, show_header=True)
        table.add_column("Outcome", style="bold")
        table.add_column("Amplitude", style="dim")
        table.add_column("Probability", justify="right")
        table.add_column("Bar", no_wrap=True)

        a0, a1 = qubit.state
        table.add_row(
            "|0⟩",
            f"{a0.real:+.4f}{a0.imag:+.4f}j",
            f"{p0:.4f} ({p0*100:.1f}%)",
            f"[green]{probability_bar(p0)}[/]",
        )
        table.add_row(
            "|1⟩",
            f"{a1.real:+.4f}{a1.imag:+.4f}j",
            f"{p1:.4f} ({p1*100:.1f}%)",
            f"[red]{probability_bar(p1)}[/]",
        )
        console.print(table)
    else:
        print(f"\n{label} State:")
        print(f"  |0⟩  P={p0:.4f}  [{probability_bar(p0, 20)}]")
        print(f"  |1⟩  P={p1:.4f}  [{probability_bar(p1, 20)}]")


def show_two_qubit_state(sys2: TwoQubitSystem, label: str = "2-Qubit System"):
    """Pretty-print two-qubit state amplitudes and probabilities."""
    labels   = ["|00⟩", "|01⟩", "|10⟩", "|11⟩"]
    probs    = [float(abs(a)**2) for a in sys2.state]
    entropy  = sys2.entanglement_entropy()

    if RICH_AVAILABLE and console:
        table = Table(title=f"[bold magenta]{label}[/]",
                      box=box.ROUNDED, show_header=True)
        table.add_column("Basis State", style="bold")
        table.add_column("Amplitude")
        table.add_column("Probability", justify="right")
        table.add_column("Bar", no_wrap=True)

        colors = ["green", "yellow", "cyan", "red"]
        for lbl, amp, prob, col in zip(labels, sys2.state, probs, colors):
            table.add_row(
                lbl,
                f"{amp.real:+.4f}{amp.imag:+.4f}j",
                f"{prob:.4f}",
                f"[{col}]{probability_bar(prob)}[/]",
            )

        console.print(table)
        console.print(
            f"  [bold]Entanglement entropy:[/] {entropy:.4f} nat  "
            f"(max = {math.log(2):.4f} for Bell states)"
        )
    else:
        print(f"\n{label}:")
        for lbl, amp, prob in zip(labels, sys2.state, probs):
            print(f"  {lbl}  {amp.real:+.4f}{amp.imag:+.4f}j  P={prob:.4f}  "
                  f"[{probability_bar(prob, 20)}]")
        print(f"  Entanglement entropy: {entropy:.4f}")


# ─────────────────────────────────────────────────────────────────────────────
# BB84 session summary
# ─────────────────────────────────────────────────────────────────────────────

def show_bb84_summary(result, max_show: int = 16):
    """Display a condensed BB84 session summary table."""
    from bb84 import BB84Result

    n_show = min(max_show, len(result.alice_bits))

    if RICH_AVAILABLE and console:
        # ── Qubit transmission table ──────────────────────────────────────
        table = Table(
            title=f"[bold green]BB84 Session — First {n_show} Qubits[/]",
            box=box.SIMPLE_HEAVY,
            show_header=True,
        )
        for col in ["#", "Alice bit", "Alice basis", "Bob basis",
                    "Bob result", "Match?", "Key bit"]:
            table.add_column(col, justify="center")

        sifted_set = set(result.sifted_indices)

        for i in range(n_show):
            match = result.alice_bases[i] == result.bob_bases[i]
            key_bit = str(result.alice_bits[i]) if i in sifted_set else "–"
            style = "bold cyan" if match else "dim"
            table.add_row(
                str(i),
                str(result.alice_bits[i]),
                result.alice_bases[i],
                result.bob_bases[i],
                str(result.bob_measurements[i]),
                "[green]✓[/]" if match else "[red]✗[/]",
                f"[bold]{key_bit}[/]" if match else key_bit,
                style=style,
            )
        console.print(table)

        # ── Statistics panel ─────────────────────────────────────────────
        lines = [
            f"[bold]Total qubits:[/]      {result.num_qubits}",
            f"[bold]Sifted bits:[/]       {len(result.sifted_indices)}  "
            f"({result.efficiency:.1%} efficiency)",
            f"[bold]QBER:[/]              {result.error_rate:.2%}  "
            f"{'[red]⚠ High![/]' if result.error_rate > 0.11 else '[green]✓ OK[/]'}",
            f"[bold]Key bits:[/]          {result.key_length_bits}",
            f"[bold]Eve present:[/]       "
            f"{'[red]YES — eavesdropping![/]' if result.eve_present else '[green]No[/]'}",
            f"[bold]Final key:[/]         [yellow]{result.final_key_hex[:32]}…[/]",
        ]
        console.print(Panel("\n".join(lines), title="[bold]Statistics[/]",
                            border_style="cyan"))
    else:
        print(f"\nBB84 Summary (first {n_show} qubits):")
        print(f"  {'#':>3}  Alice  AliceBasis  BobBasis  BobResult  Match  KeyBit")
        sifted_set = set(result.sifted_indices)
        for i in range(n_show):
            match = result.alice_bases[i] == result.bob_bases[i]
            key_bit = str(result.alice_bits[i]) if i in sifted_set else "-"
            print(f"  {i:>3}    {result.alice_bits[i]}       {result.alice_bases[i]}        "
                  f"   {result.bob_bases[i]}       {result.bob_measurements[i]}       "
                  f"{'Y' if match else 'N'}     {key_bit}")

        print(f"\n  Total qubits:   {result.num_qubits}")
        print(f"  Sifted bits:    {len(result.sifted_indices)}")
        print(f"  QBER:           {result.error_rate:.2%}")
        print(f"  Key bits:       {result.key_length_bits}")
        print(f"  Eve present:    {result.eve_present}")
        print(f"  Final key:      {result.final_key_hex[:32]}…")


# ─────────────────────────────────────────────────────────────────────────────
# E91 Bell test visualisation
# ─────────────────────────────────────────────────────────────────────────────

def show_e91_summary(result):
    """Display E91 session summary including Bell inequality result."""
    import math as _math
    quantum_max = 2 * _math.sqrt(2)

    if RICH_AVAILABLE and console:
        # Bell parameter gauge
        s_val = result.chsh_S
        bar_width = 40
        classical_pos = int(2.0 / quantum_max * bar_width)
        quantum_pos   = bar_width
        marker_pos    = int(s_val / quantum_max * bar_width)
        marker_pos    = min(marker_pos, bar_width)

        bar = list("░" * bar_width)
        bar[classical_pos] = "|"   # classical limit at S=2
        if 0 <= marker_pos < bar_width:
            bar[marker_pos] = "★"

        color = "green" if s_val > 2.0 else "red"
        bar_str = f"[{color}]{''.join(bar)}[/]"

        lines = [
            f"[bold]CHSH S parameter:[/]   {s_val:.4f}",
            f"[bold]Classical bound:[/]    S ≤ 2.0000",
            f"[bold]Quantum max:[/]        S ≤ {quantum_max:.4f}  (2√2)",
            f"",
            f"  0 ─ {bar_str} ─ 2√2",
            f"       Classical ↑        Quantum max ↑",
            f"",
            f"[bold]Bell test:[/]          "
            f"{'[green]PASSED — entanglement confirmed, channel secure[/]' if result.bell_test_passed else '[red]FAILED — entanglement degraded, possible eavesdropping[/]'}",
            f"[bold]Key error rate:[/]     {result.error_rate:.2%}",
            f"[bold]Key bits:[/]           {result.key_length_bits}",
            f"[bold]Eve present:[/]        "
            f"{'[red]YES[/]' if result.eve_present else '[green]No[/]'}",
            f"[bold]Final key:[/]          [yellow]{result.final_key_hex[:32]}…[/]",
        ]
        console.print(Panel("\n".join(lines),
                            title="[bold magenta]E91 Protocol Summary[/]",
                            border_style="magenta"))
    else:
        print(f"\nE91 Summary:")
        print(f"  CHSH S:      {result.chsh_S:.4f}  (classical ≤ 2, quantum ≤ {quantum_max:.4f})")
        print(f"  Bell test:   {'PASSED' if result.bell_test_passed else 'FAILED'}")
        print(f"  Error rate:  {result.error_rate:.2%}")
        print(f"  Key bits:    {result.key_length_bits}")
        print(f"  Final key:   {result.final_key_hex[:32]}…")


# ─────────────────────────────────────────────────────────────────────────────
# Key hex dump
# ─────────────────────────────────────────────────────────────────────────────

def show_key_hex(key_hex: str, title: str = "Generated Quantum Key"):
    """Display a hex key in a formatted dump (16 bytes per row)."""
    key_bytes = bytes.fromhex(key_hex)
    rows = []
    for i in range(0, len(key_bytes), 16):
        chunk = key_bytes[i:i + 16]
        hex_part  = " ".join(f"{b:02x}" for b in chunk)
        ascii_part = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        rows.append(f"  {i:04x}:  {hex_part:<47}  |{ascii_part}|")

    body = "\n".join(rows)
    if RICH_AVAILABLE and console:
        console.print(Panel(f"[bold yellow]{body}[/]",
                            title=f"[bold]{title}  ({len(key_bytes)*8} bits)[/]",
                            border_style="yellow"))
    else:
        print(f"\n{title} ({len(key_bytes)*8} bits):")
        print(body)


# ─────────────────────────────────────────────────────────────────────────────
# Progress bar helper
# ─────────────────────────────────────────────────────────────────────────────

def make_progress_bar(description: str = "Working…"):
    """Return a Rich Progress context manager or a no-op fallback."""
    if RICH_AVAILABLE:
        return Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
        )
    # Return a simple no-op context manager
    import contextlib

    @contextlib.contextmanager
    def _noop():
        class _FakeProgress:
            def add_task(self, *a, **kw): return 0
            def update(self, *a, **kw): pass
            def advance(self, *a, **kw): pass
        yield _FakeProgress()

    return _noop()


# ─────────────────────────────────────────────────────────────────────────────
# Gate demo
# ─────────────────────────────────────────────────────────────────────────────

def demo_gates():
    """Demonstrate all gate operations on a fresh |0⟩ qubit."""
    cprint("\n[bold cyan]══ Qubit Gate Demonstration ══[/]\n")

    demos = [
        ("Fresh |0⟩",          Qubit.zero()),
        ("After Hadamard",      Qubit.zero().hadamard()),
        ("After Pauli-X",       Qubit.zero().pauli_x()),
        ("After Pauli-Z on |1⟩",Qubit.one().pauli_z()),
        ("|+⟩ state",           Qubit.plus()),
        ("|−⟩ state",           Qubit.minus()),
    ]

    for label, q in demos:
        show_qubit_state(q, label)
        cprint("")

    cprint("[bold magenta]══ Bell State Demonstration ══[/]\n")
    bell = TwoQubitSystem.create_bell_pair()
    show_two_qubit_state(bell, "Φ⁺ Bell Pair (|00⟩+|11⟩)/√2")

    cprint("\n[bold]Measuring Bell pair 5 times:[/]")
    for trial in range(5):
        fresh = TwoQubitSystem.bell_phi_plus()
        q0, q1 = fresh.measure_both()
        cprint(f"  Trial {trial+1}: Alice={q0}, Bob={q1}  "
               f"{'[green]✓ correlated[/]' if q0==q1 else '[red]✗[/]'}")
