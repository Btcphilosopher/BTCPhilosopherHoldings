"""
gui.py — Quantum Cryptography File Transfer System — GUI
=========================================================
Full Tkinter-based graphical interface with five tabs:

  1. Key Generation  — run BB84 / E91 with live log output
  2. Encrypt File    — pick a file, encrypt with loaded key
  3. Decrypt File    — pick a .qcrypt file, decrypt
  4. Key Vault       — password-protected named key storage
  5. Visualise       — Bloch sphere, BB84 strip, CHSH chart, key histogram

Run with:  python gui.py
"""

import os
import sys
import threading
import queue
import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from typing import Optional

# ── Attempt matplotlib embedding ─────────────────────────────────────────────
try:
    import matplotlib
    matplotlib.use("TkAgg")
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
    MPL_TK = True
except ImportError:
    MPL_TK = False

# ── Project modules ───────────────────────────────────────────────────────────
sys.path.insert(0, os.path.dirname(__file__))

from bb84 import run_bb84
from e91 import run_e91
from crypto import (
    encrypt_file, decrypt_file, inspect_qcrypt_header,
    verify_roundtrip, compute_file_hash,
)
from key_manager import (
    KeyVault, KeyEntry, vault_from_bb84, vault_from_e91, print_vault_table,
)
from qr_share import key_fingerprint
from visualizer import (
    show_bb84_summary, show_e91_summary, show_key_hex,
)

# ─────────────────────────────────────────────────────────────────────────────
# Colour palette
# ─────────────────────────────────────────────────────────────────────────────

PALETTE = {
    "bg":       "#1a1b2e",
    "surface":  "#16213e",
    "card":     "#0f3460",
    "accent":   "#e94560",
    "accent2":  "#533483",
    "text":     "#eaeaea",
    "text_dim": "#8892b0",
    "green":    "#64ffda",
    "yellow":   "#ffd700",
    "red":      "#ff6b6b",
    "blue":     "#4fc3f7",
}

FONT_MONO  = ("Courier New", 10)
FONT_LABEL = ("Segoe UI", 10)
FONT_HEAD  = ("Segoe UI", 13, "bold")
FONT_SMALL = ("Segoe UI", 8)


# ─────────────────────────────────────────────────────────────────────────────
# Helper widgets
# ─────────────────────────────────────────────────────────────────────────────

class LogPane(tk.Frame):
    """
    Scrollable monospaced log widget with colour-tagged lines.
    Tags: info (default), success (green), warning (yellow), error (red).
    """

    def __init__(self, parent, **kwargs):
        height = kwargs.pop("height", 14)
        super().__init__(parent, bg=PALETTE["surface"], **kwargs)

        self.text = tk.Text(
            self,
            height=height,
            bg="#0a0a16",
            fg=PALETTE["text"],
            font=FONT_MONO,
            wrap="word",
            state="disabled",
            relief="flat",
            bd=0,
            insertbackground=PALETTE["accent"],
        )
        sb = ttk.Scrollbar(self, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=sb.set)

        self.text.tag_configure("success", foreground=PALETTE["green"])
        self.text.tag_configure("warning", foreground=PALETTE["yellow"])
        self.text.tag_configure("error",   foreground=PALETTE["red"])
        self.text.tag_configure("info",    foreground=PALETTE["text"])
        self.text.tag_configure("dim",     foreground=PALETTE["text_dim"])
        self.text.tag_configure("key",     foreground=PALETTE["yellow"],
                                font=FONT_MONO)
        self.text.tag_configure("head",    foreground=PALETTE["blue"],
                                font=("Courier New", 10, "bold"))

        sb.pack(side="right", fill="y")
        self.text.pack(side="left", fill="both", expand=True)

    def log(self, msg: str, tag: str = "info"):
        ts  = datetime.datetime.now().strftime("%H:%M:%S")
        self.text.configure(state="normal")
        self.text.insert("end", f"[{ts}] ", "dim")
        self.text.insert("end", msg + "\n", tag)
        self.text.see("end")
        self.text.configure(state="disabled")

    def clear(self):
        self.text.configure(state="normal")
        self.text.delete("1.0", "end")
        self.text.configure(state="disabled")


class LabeledEntry(tk.Frame):
    """A label + entry pair in a horizontal frame."""

    def __init__(self, parent, label: str, width: int = 50,
                 show: str = "", **kwargs):
        super().__init__(parent, bg=PALETTE["surface"], **kwargs)
        tk.Label(self, text=label, fg=PALETTE["text_dim"],
                 bg=PALETTE["surface"], font=FONT_LABEL,
                 width=14, anchor="w").pack(side="left")
        self.var = tk.StringVar()
        self.entry = tk.Entry(
            self,
            textvariable=self.var,
            width=width,
            bg=PALETTE["card"],
            fg=PALETTE["text"],
            insertbackground=PALETTE["text"],
            relief="flat",
            font=FONT_MONO,
            show=show,
        )
        self.entry.pack(side="left", fill="x", expand=True, padx=(4, 0))

    def get(self) -> str:
        return self.var.get().strip()

    def set(self, val: str):
        self.var.set(val)


def styled_button(parent, text: str, command, color=None, **kwargs) -> tk.Button:
    """Return a styled flat button."""
    c = color or PALETTE["accent"]
    return tk.Button(
        parent,
        text=text,
        command=command,
        bg=c,
        fg="white",
        font=("Segoe UI", 10, "bold"),
        relief="flat",
        bd=0,
        padx=14,
        pady=6,
        cursor="hand2",
        activebackground=PALETTE["accent2"],
        activeforeground="white",
        **kwargs,
    )


def section_label(parent, text: str) -> tk.Label:
    """Horizontal divider with section title."""
    return tk.Label(
        parent,
        text=f"  {text}  ",
        fg=PALETTE["blue"],
        bg=PALETTE["surface"],
        font=("Segoe UI", 10, "bold"),
        anchor="w",
    )


# ─────────────────────────────────────────────────────────────────────────────
# Tab 1: Key Generation
# ─────────────────────────────────────────────────────────────────────────────

class KeyGenTab(ttk.Frame):
    """BB84 / E91 quantum key generation with live log."""

    def __init__(self, parent, app, **kwargs):
        super().__init__(parent, **kwargs)
        self.app     = app
        self.result  = None
        self._q: queue.Queue = queue.Queue()
        self._build()

    def _build(self):
        self.configure(style="Dark.TFrame")
        pad = {"padx": 12, "pady": 4}

        # ── Protocol & options ────────────────────────────────────────────────
        opts = tk.Frame(self, bg=PALETTE["surface"])
        opts.pack(fill="x", **pad)

        section_label(opts, "Protocol Settings").pack(anchor="w", pady=(8, 2))

        row1 = tk.Frame(opts, bg=PALETTE["surface"])
        row1.pack(fill="x")

        tk.Label(row1, text="Protocol:", fg=PALETTE["text_dim"],
                 bg=PALETTE["surface"], font=FONT_LABEL).pack(side="left")
        self.protocol_var = tk.StringVar(value="BB84")
        for p in ["BB84", "E91"]:
            tk.Radiobutton(
                row1, text=p, variable=self.protocol_var, value=p,
                bg=PALETTE["surface"], fg=PALETTE["text"],
                selectcolor=PALETTE["card"],
                activebackground=PALETTE["surface"],
                font=FONT_LABEL,
                command=self._on_protocol_change,
            ).pack(side="left", padx=10)

        row2 = tk.Frame(opts, bg=PALETTE["surface"])
        row2.pack(fill="x", pady=4)

        # BB84 qubit count
        tk.Label(row2, text="Qubits:", fg=PALETTE["text_dim"],
                 bg=PALETTE["surface"], font=FONT_LABEL,
                 width=10, anchor="w").pack(side="left")
        self.qubits_var = tk.IntVar(value=512)
        self.qubits_spin = tk.Spinbox(
            row2, from_=128, to=8192, increment=128,
            textvariable=self.qubits_var,
            width=8, bg=PALETTE["card"], fg=PALETTE["text"],
            buttonbackground=PALETTE["card"],
            relief="flat", font=FONT_LABEL,
        )
        self.qubits_spin.pack(side="left")

        # E91 pair count
        tk.Label(row2, text="Pairs:", fg=PALETTE["text_dim"],
                 bg=PALETTE["surface"], font=FONT_LABEL,
                 width=8, anchor="w").pack(side="left", padx=(16, 0))
        self.pairs_var = tk.IntVar(value=600)
        self.pairs_spin = tk.Spinbox(
            row2, from_=100, to=5000, increment=100,
            textvariable=self.pairs_var,
            width=8, bg=PALETTE["card"], fg=PALETTE["text"],
            buttonbackground=PALETTE["card"],
            relief="flat", font=FONT_LABEL,
        )
        self.pairs_spin.pack(side="left")

        row3 = tk.Frame(opts, bg=PALETTE["surface"])
        row3.pack(fill="x", pady=4)

        self.eavesdrop_var = tk.BooleanVar(value=False)
        tk.Checkbutton(
            row3, text="Simulate eavesdropper (Eve)", variable=self.eavesdrop_var,
            bg=PALETTE["surface"], fg=PALETTE["red"],
            selectcolor=PALETTE["card"],
            activebackground=PALETTE["surface"],
            font=FONT_LABEL,
        ).pack(side="left")

        # ── Action buttons ────────────────────────────────────────────────────
        btn_row = tk.Frame(opts, bg=PALETTE["surface"])
        btn_row.pack(fill="x", pady=8)

        styled_button(btn_row, "⚡  Generate Key",
                      self._generate, color=PALETTE["accent"]).pack(side="left", padx=4)
        styled_button(btn_row, "📋  Copy Key",
                      self._copy_key, color=PALETTE["card"]).pack(side="left", padx=4)
        styled_button(btn_row, "💾  Save Key",
                      self._save_key, color=PALETTE["card"]).pack(side="left", padx=4)
        styled_button(btn_row, "🗄️  Store in Vault",
                      self._store_vault, color=PALETTE["accent2"]).pack(side="left", padx=4)
        styled_button(btn_row, "🗑  Clear",
                      lambda: self.log_pane.clear(),
                      color="#444").pack(side="right", padx=4)

        # ── Progress bar ──────────────────────────────────────────────────────
        self.progress = ttk.Progressbar(self, mode="indeterminate", length=400)
        self.progress.pack(fill="x", padx=12, pady=2)

        # ── Key display ───────────────────────────────────────────────────────
        key_frame = tk.Frame(self, bg=PALETTE["surface"])
        key_frame.pack(fill="x", padx=12, pady=4)

        section_label(key_frame, "Generated Key (AES-256)").pack(anchor="w")

        self.key_entry = LabeledEntry(key_frame, "Key hex:", width=70)
        self.key_entry.pack(fill="x", pady=2)

        self.fingerprint_lbl = tk.Label(
            key_frame, text="Fingerprint: —",
            fg=PALETTE["text_dim"], bg=PALETTE["surface"],
            font=FONT_SMALL,
        )
        self.fingerprint_lbl.pack(anchor="w")

        # ── Log pane ──────────────────────────────────────────────────────────
        section_label(self, "Protocol Log").pack(anchor="w", padx=12)
        self.log_pane = LogPane(self, height=16)
        self.log_pane.pack(fill="both", expand=True, padx=12, pady=(2, 8))

        # Start polling the message queue
        self._poll()
        self._on_protocol_change()

    def _on_protocol_change(self):
        p = self.protocol_var.get()
        self.qubits_spin.configure(state="normal" if p == "BB84" else "disabled")
        self.pairs_spin.configure(state="normal"  if p == "E91"  else "disabled")

    def _generate(self):
        self.log_pane.clear()
        self.log_pane.log("Starting quantum key generation…", "head")
        self.progress.start(10)
        threading.Thread(target=self._run_protocol, daemon=True).start()

    def _run_protocol(self):
        protocol  = self.protocol_var.get()
        eavesdrop = self.eavesdrop_var.get()

        def cb(msg):
            self._q.put(("log", msg, "info"))

        try:
            if protocol == "BB84":
                result = run_bb84(
                    num_qubits=self.qubits_var.get(),
                    eavesdrop=eavesdrop,
                    verbose_callback=cb,
                )
                self.result = result
                key = result.final_key_hex
                self._q.put(("log", f"✓ BB84 complete. QBER={result.error_rate:.2%}",
                              "success" if result.error_rate < 0.05 else "warning"))
            else:
                result = run_e91(
                    num_pairs=self.pairs_var.get(),
                    eavesdrop=eavesdrop,
                    verbose_callback=cb,
                )
                self.result = result
                key = result.final_key_hex
                chsh = result.chsh_S
                self._q.put(("log",
                              f"✓ E91 complete. CHSH S={chsh:.4f}  "
                              f"({'Bell test PASSED' if chsh > 2 else 'Bell test FAILED — possible Eve'})",
                              "success" if chsh > 2 else "warning"))

            self._q.put(("key", key, ""))
            fp = key_fingerprint(key)
            self._q.put(("fingerprint", fp, ""))
            self._q.put(("log", f"Key fingerprint: {fp}", "key"))
            self._q.put(("log", f"Key: {key[:24]}…{key[-8:]}", "key"))
        except RuntimeError as exc:
            self._q.put(("log", f"✗ {exc}", "error"))
        except Exception as exc:
            self._q.put(("log", f"✗ Unexpected error: {exc}", "error"))
        finally:
            self._q.put(("stop_progress", "", ""))

    def _poll(self):
        try:
            while True:
                kind, msg, tag = self._q.get_nowait()
                if kind == "log":
                    self.log_pane.log(msg, tag)
                elif kind == "key":
                    self.key_entry.set(msg)
                    self.app.shared_key.set(msg)
                elif kind == "fingerprint":
                    self.fingerprint_lbl.config(text=f"Fingerprint: {msg}")
                elif kind == "stop_progress":
                    self.progress.stop()
        except queue.Empty:
            pass
        self.after(100, self._poll)

    def _copy_key(self):
        key = self.key_entry.get()
        if not key:
            messagebox.showwarning("No key", "Generate a key first.")
            return
        self.clipboard_clear()
        self.clipboard_append(key)
        self.log_pane.log("Key copied to clipboard.", "success")

    def _save_key(self):
        key = self.key_entry.get()
        if not key:
            messagebox.showwarning("No key", "Generate a key first.")
            return
        path = filedialog.asksaveasfilename(
            title="Save Key",
            defaultextension=".hex",
            filetypes=[("Hex key files", "*.hex"), ("All files", "*.*")],
        )
        if path:
            with open(path, "w") as f:
                f.write(key)
            self.log_pane.log(f"Key saved to {path}", "success")

    def _store_vault(self):
        key = self.key_entry.get()
        if not key:
            messagebox.showwarning("No key", "Generate a key first.")
            return
        self.app.notebook.select(3)  # Switch to vault tab
        self.app.vault_tab.quick_store(key, self.result)


# ─────────────────────────────────────────────────────────────────────────────
# Tab 2: Encrypt File
# ─────────────────────────────────────────────────────────────────────────────

class EncryptTab(ttk.Frame):

    def __init__(self, parent, app, **kwargs):
        super().__init__(parent, **kwargs)
        self.app = app
        self._build()

    def _build(self):
        pad = {"padx": 12, "pady": 4}

        section_label(self, "File Selection").pack(anchor="w", padx=12, pady=(12, 0))

        # Input file
        f1 = tk.Frame(self, bg=PALETTE["surface"])
        f1.pack(fill="x", **pad)
        tk.Label(f1, text="Input file:", fg=PALETTE["text_dim"],
                 bg=PALETTE["surface"], font=FONT_LABEL,
                 width=14, anchor="w").pack(side="left")
        self.input_var = tk.StringVar()
        tk.Entry(f1, textvariable=self.input_var, width=55,
                 bg=PALETTE["card"], fg=PALETTE["text"],
                 insertbackground=PALETTE["text"],
                 relief="flat", font=FONT_MONO).pack(side="left", padx=4)
        styled_button(f1, "Browse…",
                      self._browse_input,
                      color=PALETTE["card"]).pack(side="left")

        # Output file
        f2 = tk.Frame(self, bg=PALETTE["surface"])
        f2.pack(fill="x", **pad)
        tk.Label(f2, text="Output file:", fg=PALETTE["text_dim"],
                 bg=PALETTE["surface"], font=FONT_LABEL,
                 width=14, anchor="w").pack(side="left")
        self.output_var = tk.StringVar()
        tk.Entry(f2, textvariable=self.output_var, width=55,
                 bg=PALETTE["card"], fg=PALETTE["text"],
                 insertbackground=PALETTE["text"],
                 relief="flat", font=FONT_MONO).pack(side="left", padx=4)
        styled_button(f2, "Browse…",
                      self._browse_output,
                      color=PALETTE["card"]).pack(side="left")

        section_label(self, "Key").pack(anchor="w", padx=12, pady=(10, 0))

        f3 = tk.Frame(self, bg=PALETTE["surface"])
        f3.pack(fill="x", **pad)
        tk.Label(f3, text="Key (hex):", fg=PALETTE["text_dim"],
                 bg=PALETTE["surface"], font=FONT_LABEL,
                 width=14, anchor="w").pack(side="left")
        self.key_var = tk.StringVar()
        tk.Entry(f3, textvariable=self.key_var, width=55,
                 bg=PALETTE["card"], fg=PALETTE["text"],
                 insertbackground=PALETTE["text"],
                 relief="flat", font=FONT_MONO).pack(side="left", padx=4)
        styled_button(f3, "Load .hex",
                      self._load_key_file,
                      color=PALETTE["card"]).pack(side="left")
        styled_button(f3, "Use Generated",
                      self._use_shared_key,
                      color=PALETTE["accent2"]).pack(side="left", padx=4)

        # Encrypt button
        btn_row = tk.Frame(self, bg=PALETTE["surface"])
        btn_row.pack(fill="x", padx=12, pady=10)
        self.progress = ttk.Progressbar(btn_row, mode="indeterminate", length=350)
        self.progress.pack(side="left", padx=(0, 10))
        styled_button(btn_row, "🔒  Encrypt File",
                      self._encrypt, color=PALETTE["accent"]).pack(side="left")

        section_label(self, "Result").pack(anchor="w", padx=12)
        self.log_pane = LogPane(self, height=14)
        self.log_pane.pack(fill="both", expand=True, padx=12, pady=(2, 8))

    def _browse_input(self):
        path = filedialog.askopenfilename(title="Select file to encrypt")
        if path:
            self.input_var.set(path)
            self.output_var.set(path + ".qcrypt")

    def _browse_output(self):
        path = filedialog.asksaveasfilename(
            title="Save encrypted file as",
            defaultextension=".qcrypt",
            filetypes=[("Quantum encrypted files", "*.qcrypt"), ("All", "*.*")],
        )
        if path:
            self.output_var.set(path)

    def _load_key_file(self):
        path = filedialog.askopenfilename(
            title="Load hex key file",
            filetypes=[("Hex key", "*.hex"), ("All", "*.*")],
        )
        if path:
            with open(path) as f:
                self.key_var.set(f.read().strip())

    def _use_shared_key(self):
        self.key_var.set(self.app.shared_key.get())

    def _encrypt(self):
        input_path  = self.input_var.get()
        output_path = self.output_var.get()
        key_hex     = self.key_var.get()

        if not input_path or not os.path.isfile(input_path):
            messagebox.showerror("Error", "Input file not found.")
            return
        if not output_path:
            output_path = input_path + ".qcrypt"
            self.output_var.set(output_path)
        if not key_hex or len(key_hex) != 64:
            messagebox.showerror("Error", "Invalid key. Need 64 hex characters.")
            return

        self.log_pane.clear()
        self.progress.start(10)

        def run():
            try:
                meta = encrypt_file(input_path, output_path, key_hex)
                orig_hash = compute_file_hash(input_path)
                self.after(0, lambda: self._on_encrypt_done(meta, orig_hash))
            except Exception as exc:
                self.after(0, lambda: self._on_error(str(exc)))

        threading.Thread(target=run, daemon=True).start()

    def _on_encrypt_done(self, meta, orig_hash):
        self.progress.stop()
        self.log_pane.log("✓ Encryption successful!", "success")
        self.log_pane.log(f"  Input:      {meta['input_size']:,} bytes", "info")
        self.log_pane.log(f"  Output:     {meta['output_size']:,} bytes", "info")
        self.log_pane.log(f"  Nonce:      {meta['nonce_hex']}", "dim")
        self.log_pane.log(f"  Auth tag:   {meta['integrity_tag_hex']}", "dim")
        self.log_pane.log(f"  SHA-256:    {orig_hash}", "key")
        self.log_pane.log("  Store the SHA-256 hash to verify after decryption.", "warning")

    def _on_error(self, msg):
        self.progress.stop()
        self.log_pane.log(f"✗ {msg}", "error")


# ─────────────────────────────────────────────────────────────────────────────
# Tab 3: Decrypt File
# ─────────────────────────────────────────────────────────────────────────────

class DecryptTab(ttk.Frame):

    def __init__(self, parent, app, **kwargs):
        super().__init__(parent, **kwargs)
        self.app = app
        self._build()

    def _build(self):
        pad = {"padx": 12, "pady": 4}

        section_label(self, "File Selection").pack(anchor="w", padx=12, pady=(12, 0))

        f1 = tk.Frame(self, bg=PALETTE["surface"])
        f1.pack(fill="x", **pad)
        tk.Label(f1, text="Encrypted file:", fg=PALETTE["text_dim"],
                 bg=PALETTE["surface"], font=FONT_LABEL,
                 width=16, anchor="w").pack(side="left")
        self.input_var = tk.StringVar()
        tk.Entry(f1, textvariable=self.input_var, width=52,
                 bg=PALETTE["card"], fg=PALETTE["text"],
                 insertbackground=PALETTE["text"],
                 relief="flat", font=FONT_MONO).pack(side="left", padx=4)
        styled_button(f1, "Browse…",
                      self._browse_input,
                      color=PALETTE["card"]).pack(side="left")
        styled_button(f1, "Inspect",
                      self._inspect, color="#444").pack(side="left", padx=4)

        f2 = tk.Frame(self, bg=PALETTE["surface"])
        f2.pack(fill="x", **pad)
        tk.Label(f2, text="Output file:", fg=PALETTE["text_dim"],
                 bg=PALETTE["surface"], font=FONT_LABEL,
                 width=16, anchor="w").pack(side="left")
        self.output_var = tk.StringVar()
        tk.Entry(f2, textvariable=self.output_var, width=52,
                 bg=PALETTE["card"], fg=PALETTE["text"],
                 insertbackground=PALETTE["text"],
                 relief="flat", font=FONT_MONO).pack(side="left", padx=4)
        styled_button(f2, "Browse…",
                      self._browse_output,
                      color=PALETTE["card"]).pack(side="left")

        section_label(self, "Key").pack(anchor="w", padx=12, pady=(10, 0))

        f3 = tk.Frame(self, bg=PALETTE["surface"])
        f3.pack(fill="x", **pad)
        tk.Label(f3, text="Key (hex):", fg=PALETTE["text_dim"],
                 bg=PALETTE["surface"], font=FONT_LABEL,
                 width=16, anchor="w").pack(side="left")
        self.key_var = tk.StringVar()
        tk.Entry(f3, textvariable=self.key_var, width=52,
                 bg=PALETTE["card"], fg=PALETTE["text"],
                 insertbackground=PALETTE["text"],
                 relief="flat", font=FONT_MONO).pack(side="left", padx=4)
        styled_button(f3, "Load .hex",
                      self._load_key_file,
                      color=PALETTE["card"]).pack(side="left")
        styled_button(f3, "Use Generated",
                      self._use_shared_key,
                      color=PALETTE["accent2"]).pack(side="left", padx=4)

        # Optional verify path
        f4 = tk.Frame(self, bg=PALETTE["surface"])
        f4.pack(fill="x", **pad)
        tk.Label(f4, text="Verify against:", fg=PALETTE["text_dim"],
                 bg=PALETTE["surface"], font=FONT_LABEL,
                 width=16, anchor="w").pack(side="left")
        self.verify_var = tk.StringVar()
        tk.Entry(f4, textvariable=self.verify_var, width=52,
                 bg=PALETTE["card"], fg=PALETTE["text"],
                 insertbackground=PALETTE["text"],
                 relief="flat", font=FONT_MONO).pack(side="left", padx=4)
        styled_button(f4, "Browse…",
                      self._browse_verify,
                      color=PALETTE["card"]).pack(side="left")

        btn_row = tk.Frame(self, bg=PALETTE["surface"])
        btn_row.pack(fill="x", padx=12, pady=10)
        self.progress = ttk.Progressbar(btn_row, mode="indeterminate", length=350)
        self.progress.pack(side="left", padx=(0, 10))
        styled_button(btn_row, "🔓  Decrypt File",
                      self._decrypt, color=PALETTE["accent"]).pack(side="left")

        section_label(self, "Result").pack(anchor="w", padx=12)
        self.log_pane = LogPane(self, height=12)
        self.log_pane.pack(fill="both", expand=True, padx=12, pady=(2, 8))

    def _browse_input(self):
        path = filedialog.askopenfilename(
            title="Select encrypted file",
            filetypes=[("Quantum encrypted", "*.qcrypt"), ("All", "*.*")],
        )
        if path:
            self.input_var.set(path)
            if path.endswith(".qcrypt"):
                self.output_var.set(path[:-7])

    def _browse_output(self):
        path = filedialog.asksaveasfilename(title="Save decrypted file as")
        if path:
            self.output_var.set(path)

    def _browse_verify(self):
        path = filedialog.askopenfilename(title="Select original file to verify against")
        if path:
            self.verify_var.set(path)

    def _load_key_file(self):
        path = filedialog.askopenfilename(
            title="Load hex key file",
            filetypes=[("Hex key", "*.hex"), ("All", "*.*")],
        )
        if path:
            with open(path) as f:
                self.key_var.set(f.read().strip())

    def _use_shared_key(self):
        self.key_var.set(self.app.shared_key.get())

    def _inspect(self):
        path = self.input_var.get()
        if not path or not os.path.isfile(path):
            messagebox.showerror("Error", "Select a valid .qcrypt file first.")
            return
        try:
            meta = inspect_qcrypt_header(path)
            lines = "\n".join(f"  {k}: {v}" for k, v in meta.items())
            messagebox.showinfo("File Header", f"{os.path.basename(path)}\n\n{lines}")
        except Exception as exc:
            messagebox.showerror("Error", str(exc))

    def _decrypt(self):
        input_path  = self.input_var.get()
        output_path = self.output_var.get()
        key_hex     = self.key_var.get()

        if not input_path or not os.path.isfile(input_path):
            messagebox.showerror("Error", "Encrypted file not found.")
            return
        if not output_path:
            output_path = input_path.replace(".qcrypt", ".decrypted")
            self.output_var.set(output_path)
        if not key_hex or len(key_hex) != 64:
            messagebox.showerror("Error", "Invalid key. Need 64 hex characters.")
            return

        verify_path = self.verify_var.get() or None
        self.log_pane.clear()
        self.progress.start(10)

        def run():
            try:
                meta = decrypt_file(input_path, output_path, key_hex)
                match = None
                if verify_path and os.path.isfile(verify_path):
                    match = verify_roundtrip(verify_path, output_path)
                self.after(0, lambda: self._on_decrypt_done(meta, match))
            except Exception as exc:
                self.after(0, lambda: self._on_error(str(exc)))

        threading.Thread(target=run, daemon=True).start()

    def _on_decrypt_done(self, meta, match):
        self.progress.stop()
        self.log_pane.log("✓ Decryption successful!", "success")
        self.log_pane.log(f"  Plaintext size: {meta['plaintext_size']:,} bytes", "info")
        self.log_pane.log(f"  GCM integrity:  {'VERIFIED ✓' if meta['integrity_verified'] else 'FAILED ✗'}",
                          "success" if meta["integrity_verified"] else "error")
        if match is not None:
            tag = "success" if match else "error"
            self.log_pane.log(
                f"  Round-trip:     {'Bit-for-bit identical ✓' if match else 'FILES DIFFER ✗'}",
                tag,
            )

    def _on_error(self, msg):
        self.progress.stop()
        self.log_pane.log(f"✗ {msg}", "error")
        if "Authentication" in msg or "tag" in msg.lower():
            self.log_pane.log("  Wrong key or tampered file!", "error")


# ─────────────────────────────────────────────────────────────────────────────
# Tab 4: Key Vault
# ─────────────────────────────────────────────────────────────────────────────

class VaultTab(ttk.Frame):

    def __init__(self, parent, app, **kwargs):
        super().__init__(parent, **kwargs)
        self.app      = app
        self.vault    = None
        self._build()

    def _build(self):
        pad = {"padx": 12, "pady": 4}

        section_label(self, "Vault File").pack(anchor="w", padx=12, pady=(12, 0))

        top = tk.Frame(self, bg=PALETTE["surface"])
        top.pack(fill="x", **pad)

        tk.Label(top, text="Vault:", fg=PALETTE["text_dim"],
                 bg=PALETTE["surface"], font=FONT_LABEL,
                 width=7, anchor="w").pack(side="left")
        self.vault_path_var = tk.StringVar(value="keys.qvault")
        tk.Entry(top, textvariable=self.vault_path_var, width=40,
                 bg=PALETTE["card"], fg=PALETTE["text"],
                 insertbackground=PALETTE["text"],
                 relief="flat", font=FONT_MONO).pack(side="left", padx=4)
        styled_button(top, "Browse…",    self._browse_vault,    color=PALETTE["card"]).pack(side="left")
        styled_button(top, "Create",     self._create_vault,    color=PALETTE["accent"]).pack(side="left", padx=4)
        styled_button(top, "Unlock",     self._unlock_vault,    color="#2ecc71").pack(side="left", padx=4)
        styled_button(top, "Lock",       self._lock_vault,      color="#e74c3c").pack(side="left", padx=4)

        self.vault_status_lbl = tk.Label(
            self, text="Vault: locked",
            fg=PALETTE["red"], bg=PALETTE["surface"], font=FONT_LABEL,
        )
        self.vault_status_lbl.pack(anchor="w", padx=12)

        section_label(self, "Stored Keys").pack(anchor="w", padx=12, pady=(8, 0))

        list_frame = tk.Frame(self, bg=PALETTE["surface"])
        list_frame.pack(fill="both", expand=True, padx=12)

        cols = ("name", "protocol", "bits", "qber", "qubits", "created")
        self.tree = ttk.Treeview(list_frame, columns=cols, show="headings", height=8)
        for c, w in zip(cols, [160, 70, 50, 60, 70, 160]):
            self.tree.heading(c, text=c.title())
            self.tree.column(c, width=w, anchor="center" if c != "name" else "w")

        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)

        act_row = tk.Frame(self, bg=PALETTE["surface"])
        act_row.pack(fill="x", padx=12, pady=8)

        styled_button(act_row, "Copy Key",    self._copy_selected,   color=PALETTE["card"]).pack(side="left", padx=2)
        styled_button(act_row, "Use Key",     self._use_selected,    color=PALETTE["accent2"]).pack(side="left", padx=2)
        styled_button(act_row, "Rename",      self._rename_key,      color=PALETTE["card"]).pack(side="left", padx=2)
        styled_button(act_row, "Delete",      self._delete_key,      color="#c0392b").pack(side="left", padx=2)
        styled_button(act_row, "Refresh",     self._refresh_list,    color=PALETTE["card"]).pack(side="right", padx=2)

        section_label(self, "Vault Log").pack(anchor="w", padx=12)
        self.log_pane = LogPane(self, height=6)
        self.log_pane.pack(fill="x", padx=12, pady=(2, 8))

    def _browse_vault(self):
        path = filedialog.askopenfilename(title="Select vault", filetypes=[("Vault","*.qvault"),("All","*.*")])
        if path: self.vault_path_var.set(path)

    def _get_password(self, prompt="Vault password:"):
        return simpledialog.askstring("Password", prompt, show="*", parent=self)

    def _create_vault(self):
        path = self.vault_path_var.get()
        pw   = self._get_password("New vault password:")
        if not pw: return
        try:
            v = KeyVault(path); v.create(pw); self.vault = v
            self.vault_status_lbl.config(text=f"Vault: created {path}", fg=PALETTE["green"])
            self.log_pane.log(f"Created vault: {path}", "success")
        except Exception as e: messagebox.showerror("Error", str(e))

    def _unlock_vault(self):
        path = self.vault_path_var.get()
        pw   = self._get_password("Vault password:")
        if not pw: return
        try:
            v = KeyVault(path); v.unlock(pw); self.vault = v
            self.vault_status_lbl.config(text=f"Vault: unlocked ({len(v)} keys)", fg=PALETTE["green"])
            self.log_pane.log(f"Vault unlocked. {len(v)} key(s).", "success")
            self._refresh_list()
        except Exception as e: messagebox.showerror("Wrong password", str(e))

    def _lock_vault(self):
        if self.vault: self.vault.lock(); self.vault = None
        self.vault_status_lbl.config(text="Vault: locked", fg=PALETTE["red"])
        self._clear_list()
        self.log_pane.log("Vault locked.", "warning")

    def _clear_list(self):
        for item in self.tree.get_children(): self.tree.delete(item)

    def _refresh_list(self):
        self._clear_list()
        if not self.vault or not self.vault._unlocked: return
        for e in self.vault.list_keys():
            self.tree.insert("", "end", iid=e.name,
                             values=(e.name, e.protocol.upper(), e.length_bits,
                                     f"{e.qber:.2%}", e.num_qubits, e.created_at[:19]))

    def _selected_entry(self):
        sel = self.tree.selection()
        if not sel: messagebox.showwarning("No selection", "Select a key first."); return None
        try: return self.vault.get(sel[0])
        except Exception as e: messagebox.showerror("Error", str(e)); return None

    def _copy_selected(self):
        e = self._selected_entry()
        if e:
            self.clipboard_clear(); self.clipboard_append(e.key_hex)
            self.log_pane.log(f"Copied '{e.name}' to clipboard.", "success")

    def _use_selected(self):
        e = self._selected_entry()
        if e:
            self.app.shared_key.set(e.key_hex)
            self.log_pane.log(f"Key '{e.name}' is now active.", "success")
            messagebox.showinfo("Key Loaded", f"Key '{e.name}' loaded.\nUse 'Use Generated' in Encrypt/Decrypt tabs.")

    def _rename_key(self):
        e = self._selected_entry()
        if not e: return
        new_name = simpledialog.askstring("Rename", f"New name for '{e.name}':", parent=self)
        if new_name:
            try: self.vault.rename(e.name, new_name); self.vault.save(); self._refresh_list()
            except Exception as ex: messagebox.showerror("Error", str(ex))

    def _delete_key(self):
        e = self._selected_entry()
        if not e: return
        if messagebox.askyesno("Confirm", f"Delete '{e.name}'?"):
            try: self.vault.delete(e.name); self.vault.save(); self._refresh_list()
            except Exception as ex: messagebox.showerror("Error", str(ex))

    def quick_store(self, key_hex, result):
        if not self.vault or not self.vault._unlocked:
            messagebox.showwarning("Vault Locked", "Create or unlock a vault first.")
            return
        name = simpledialog.askstring("Store Key", "Name for this key:",
                                       initialvalue=f"key_{datetime.datetime.now().strftime('%H%M%S')}",
                                       parent=self)
        if not name: return
        try:
            from bb84 import BB84Result
            from e91  import E91Result
            if isinstance(result, BB84Result): entry = vault_from_bb84(result, name)
            elif isinstance(result, E91Result): entry = vault_from_e91(result, name)
            else: entry = KeyEntry(name=name, key_hex=key_hex)
            self.vault.add_key(entry, overwrite=True); self.vault.save(); self._refresh_list()
            self.log_pane.log(f"Stored '{name}'", "success")
        except Exception as e: messagebox.showerror("Error", str(e))


# ─────────────────────────────────────────────────────────────────────────────
# Tab 5: Visualise
# ─────────────────────────────────────────────────────────────────────────────

class VisualiseTab(ttk.Frame):

    def __init__(self, parent, app, **kwargs):
        super().__init__(parent, **kwargs)
        self.app = app
        self._current_fig = None
        self._build()

    def _build(self):
        ctrl = tk.Frame(self, bg=PALETTE["surface"], width=200)
        ctrl.pack(side="left", fill="y", padx=(8,0), pady=8)
        ctrl.pack_propagate(False)

        section_label(ctrl, "Visualisations").pack(anchor="w", pady=(4,8))

        for label, cmd in [
            ("Bloch Sphere",         self._plot_bloch),
            ("Gate Evolution",       self._plot_gate_evo),
            ("BB84 Strip Chart",     self._plot_bb84),
            ("E91 CHSH Chart",       self._plot_chsh),
            ("Key Distribution",     self._plot_key_dist),
            ("Bell Correlations",    self._plot_bell),
        ]:
            styled_button(ctrl, label, cmd, color=PALETTE["card"]).pack(fill="x", padx=4, pady=3)

        tk.Label(ctrl, text="", bg=PALETTE["surface"]).pack(expand=True)
        styled_button(ctrl, "Save Plot",  self._save_plot,   color=PALETTE["accent2"]).pack(fill="x", padx=4, pady=3)
        styled_button(ctrl, "Clear",      self._clear_plot,  color="#444").pack(fill="x", padx=4, pady=3)

        self.canvas_frame = tk.Frame(self, bg=PALETTE["bg"])
        self.canvas_frame.pack(side="left", fill="both", expand=True, padx=8, pady=8)

        if not MPL_TK:
            tk.Label(self.canvas_frame, text="matplotlib not available.\npip install matplotlib",
                     fg=PALETTE["text_dim"], bg=PALETTE["bg"], font=FONT_HEAD).pack(expand=True)

    def _show_fig(self, fig):
        if not MPL_TK or not fig: return
        for w in self.canvas_frame.winfo_children(): w.destroy()
        canvas = FigureCanvasTkAgg(fig, master=self.canvas_frame)
        NavigationToolbar2Tk(canvas, self.canvas_frame).update()
        canvas.get_tk_widget().pack(fill="both", expand=True)
        canvas.draw()
        self._current_fig = fig

    def _plot_bloch(self):
        from qubit_sim import Qubit
        from bloch_viz import plot_bloch_sphere
        states = [Qubit.zero(), Qubit.plus(), Qubit.one(), Qubit.minus()]
        self._show_fig(plot_bloch_sphere(states, ["|0>","|+>","|1>","|->"],
                                         title="Common Qubit States", show=False))

    def _plot_gate_evo(self):
        from bloch_viz import plot_gate_evolution
        self._show_fig(plot_gate_evolution(["H","Z","H","X"], show=False))

    def _plot_bb84(self):
        from bloch_viz import plot_bb84_session
        self._show_fig(plot_bb84_session(run_bb84(num_qubits=128), n_show=64, show=False))

    def _plot_chsh(self):
        from bloch_viz import plot_chsh_comparison
        r1 = run_e91(num_pairs=400, eavesdrop=False)
        r2 = run_e91(num_pairs=400, eavesdrop=True)
        self._show_fig(plot_chsh_comparison([
            ("E91 Clean", r1.chsh_S, "#2ecc71"),
            ("E91 + Eve",  r2.chsh_S, "#e74c3c"),
            ("Classical",  2.0,       "#f39c12"),
        ], show=False))

    def _plot_key_dist(self):
        from bloch_viz import plot_key_distribution
        key = self.app.shared_key.get()
        if len(key) != 64:
            key = run_bb84(num_qubits=512).final_key_hex
        self._show_fig(plot_key_distribution(key, show=False))

    def _plot_bell(self):
        import matplotlib.pyplot as plt
        import numpy as np
        from qubit_sim import TwoQubitSystem
        outcomes = {"00":0,"01":0,"10":0,"11":0}
        for _ in range(300):
            p = TwoQubitSystem.bell_phi_plus(); q0,q1 = p.measure_both()
            outcomes[f"{q0}{q1}"] += 1

        fig, (ax1,ax2) = plt.subplots(1,2,figsize=(10,4))
        fig.patch.set_facecolor("#1a1b2e")
        for ax in [ax1,ax2]: ax.set_facecolor("#0f3460")

        ax1.bar(outcomes.keys(), outcomes.values(), color=["#2ecc71","#e74c3c","#e74c3c","#2ecc71"], edgecolor="white")
        ax1.axhline(75, color="yellow", ls="--", lw=1.5, label="Expected (random)")
        ax1.axhline(150, color="cyan", ls=":", lw=1.5, label="Bell (correlated)")
        ax1.set_title("Bell Φ⁺ Outcomes", color="white", fontweight="bold")
        ax1.legend(fontsize=8, labelcolor="white", facecolor="#0f3460")
        ax1.tick_params(colors="white")

        angles = np.linspace(0,360,100)
        ax2.plot(angles, np.cos(np.radians(angles))**2, color="#4fc3f7", lw=2)
        ax2.set_title("P(correlated) vs Angle", color="white", fontweight="bold")
        ax2.set_xlabel("Δθ (°)", color="#8892b0"); ax2.tick_params(colors="white")
        ax2.axhline(0.5, color="yellow", ls="--", lw=1, label="Classical 50%")
        ax2.legend(fontsize=8, labelcolor="white", facecolor="#0f3460")

        plt.tight_layout()
        self._show_fig(fig)

    def _save_plot(self):
        if not self._current_fig:
            messagebox.showinfo("No plot", "Generate a plot first."); return
        path = filedialog.asksaveasfilename(defaultextension=".png",
               filetypes=[("PNG","*.png"),("PDF","*.pdf"),("SVG","*.svg")])
        if path:
            self._current_fig.savefig(path, dpi=150, bbox_inches="tight")
            messagebox.showinfo("Saved", f"Saved to {path}")

    def _clear_plot(self):
        if MPL_TK:
            import matplotlib.pyplot as plt; plt.close("all")
        for w in self.canvas_frame.winfo_children(): w.destroy()
        self._current_fig = None


# ─────────────────────────────────────────────────────────────────────────────
# Main Application
# ─────────────────────────────────────────────────────────────────────────────

class App(tk.Tk):

    def __init__(self):
        super().__init__()
        self.title("Quantum Crypto File Transfer System")
        self.geometry("1020x760")
        self.minsize(900, 640)
        self.configure(bg=PALETTE["bg"])
        self._apply_theme()

        self.shared_key = tk.StringVar()

        # Header
        hdr = tk.Frame(self, bg=PALETTE["card"], height=52)
        hdr.pack(fill="x"); hdr.pack_propagate(False)
        tk.Label(hdr, text="⚛  QUANTUM CRYPTO FILE TRANSFER",
                 fg=PALETTE["accent"], bg=PALETTE["card"],
                 font=("Segoe UI",15,"bold")).pack(side="left", padx=16, pady=8)
        tk.Label(hdr, text="BB84 · E91 · AES-256-GCM",
                 fg=PALETTE["text_dim"], bg=PALETTE["card"],
                 font=("Segoe UI",9)).pack(side="left")

        key_bar = tk.Frame(hdr, bg=PALETTE["card"])
        key_bar.pack(side="right", padx=12)
        tk.Label(key_bar, text="Active key:", fg=PALETTE["text_dim"],
                 bg=PALETTE["card"], font=FONT_SMALL).pack(side="left")
        tk.Label(key_bar, textvariable=self.shared_key,
                 fg=PALETTE["yellow"], bg=PALETTE["card"],
                 font=("Courier New",8)).pack(side="left")

        # Notebook
        style = ttk.Style()
        style.configure("TNotebook",       background=PALETTE["bg"])
        style.configure("TNotebook.Tab",   background=PALETTE["surface"],
                        foreground=PALETTE["text_dim"], padding=[14,6],
                        font=("Segoe UI",10))
        style.map("TNotebook.Tab",
                  background=[("selected", PALETTE["card"])],
                  foreground=[("selected", PALETTE["accent"])])
        style.configure("Dark.TFrame", background=PALETTE["surface"])

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=6, pady=6)

        self.vault_tab = None
        for name, TabClass in [
            ("⚡ Key Gen",    KeyGenTab),
            ("🔒 Encrypt",   EncryptTab),
            ("🔓 Decrypt",   DecryptTab),
            ("🗄  Vault",     VaultTab),
            ("📊 Visualise", VisualiseTab),
        ]:
            tab = TabClass(self.notebook, app=self)
            tab.configure(style="Dark.TFrame")
            self.notebook.add(tab, text=name)
            if TabClass == VaultTab: self.vault_tab = tab

        # Status bar
        sb = tk.Frame(self, bg=PALETTE["surface"], height=22)
        sb.pack(fill="x", side="bottom")
        self.status_var = tk.StringVar(value="Ready")
        tk.Label(sb, textvariable=self.status_var, fg=PALETTE["text_dim"],
                 bg=PALETTE["surface"], font=FONT_SMALL, anchor="w").pack(side="left", padx=8)
        import platform
        tk.Label(sb, text=f"Python {sys.version.split()[0]} · matplotlib={'OK' if MPL_TK else 'not installed'}",
                 fg=PALETTE["text_dim"], bg=PALETTE["surface"], font=FONT_SMALL).pack(side="right", padx=8)

    def _apply_theme(self):
        style = ttk.Style(self)
        try: style.theme_use("clam")
        except Exception: pass
        style.configure(".", background=PALETTE["surface"], foreground=PALETTE["text"],
                        fieldbackground=PALETTE["card"], troughcolor=PALETTE["card"])
        style.configure("TScrollbar", background=PALETTE["card"],
                        troughcolor=PALETTE["surface"], arrowcolor=PALETTE["text_dim"])
        style.configure("Horizontal.TProgressbar", troughcolor=PALETTE["surface"],
                        background=PALETTE["accent"])
        style.configure("Treeview", background=PALETTE["card"],
                        fieldbackground=PALETTE["card"], foreground=PALETTE["text"])
        style.configure("Treeview.Heading", background=PALETTE["surface"],
                        foreground=PALETTE["blue"], font=("Segoe UI",9,"bold"))
        style.map("Treeview", background=[("selected", PALETTE["accent2"])],
                  foreground=[("selected","white")])


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
