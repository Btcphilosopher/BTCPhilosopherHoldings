"""
bb84.py — BB84 Quantum Key Distribution Protocol
==================================================
Implements the full BB84 protocol:
  1. Alice prepares qubits in random bits + bases
  2. Bob measures in random bases
  3. Sift key by discarding basis mismatches
  4. Optional eavesdropper (Eve) intercept-resend attack
  5. Error rate estimation to detect eavesdropping
  6. Privacy amplification via SHA-256 hashing

References: Bennett & Brassard (1984), "Quantum cryptography:
            Public key distribution and coin tossing."
"""

import random
import hashlib
from typing import List, Tuple, Optional, Dict
from dataclasses import dataclass, field

from qubit_sim import Qubit


# ─────────────────────────────────────────────────────────────────────────────
# Data containers
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class BB84Result:
    """Complete record of one BB84 key exchange session."""
    alice_bits:       List[int]  = field(default_factory=list)
    alice_bases:      List[str]  = field(default_factory=list)
    bob_bases:        List[str]  = field(default_factory=list)
    bob_measurements: List[int]  = field(default_factory=list)
    sifted_indices:   List[int]  = field(default_factory=list)
    alice_sifted:     List[int]  = field(default_factory=list)
    bob_sifted:       List[int]  = field(default_factory=list)
    error_rate:       float       = 0.0
    raw_key_bits:     List[int]  = field(default_factory=list)
    final_key_hex:    str         = ""
    eavesdropped:     bool        = False
    num_qubits:       int         = 0
    eve_present:      bool        = False

    @property
    def key_length_bits(self) -> int:
        return len(self.raw_key_bits)

    @property
    def key_length_bytes(self) -> int:
        return self.key_length_bits // 8

    @property
    def efficiency(self) -> float:
        """Fraction of transmitted qubits that contributed to the raw key."""
        if self.num_qubits == 0:
            return 0.0
        return len(self.sifted_indices) / self.num_qubits


# ─────────────────────────────────────────────────────────────────────────────
# Core BB84 functions
# ─────────────────────────────────────────────────────────────────────────────

def random_bits(n: int) -> List[int]:
    """Generate n uniformly random bits."""
    return [random.randint(0, 1) for _ in range(n)]


def random_bases(n: int) -> List[str]:
    """Generate n random bases, each 'Z' (rectilinear) or 'X' (diagonal)."""
    return [random.choice(["Z", "X"]) for _ in range(n)]


def alice_prepare(bits: List[int], bases: List[str]) -> List[Qubit]:
    """
    Alice encodes each classical bit into a qubit using her chosen basis.

    Encoding table
    ──────────────
    Basis Z: bit 0 → |0⟩,  bit 1 → |1⟩
    Basis X: bit 0 → |+⟩,  bit 1 → |−⟩
    """
    return [Qubit.from_bit(b, basis) for b, basis in zip(bits, bases)]


def eve_intercept(
    qubits: List[Qubit],
    detection_probability: float = 0.5,
) -> Tuple[List[Qubit], List[int], List[str]]:
    """
    Eve performs an intercept-resend attack:
      1. Randomly chooses a basis for each qubit
      2. Measures (collapses) the qubit
      3. Re-prepares a fresh qubit in the measured value + her basis

    On average Eve guesses the wrong basis 50% of the time,
    introducing a 25% QBER (Quantum Bit Error Rate) in the sifted key.

    Returns
    -------
    intercepted_qubits : re-prepared qubits sent onward to Bob
    eve_bits           : Eve's measurement outcomes
    eve_bases          : Eve's chosen bases
    """
    eve_bases = random_bases(len(qubits))
    eve_bits: List[int] = []
    new_qubits: List[Qubit] = []

    for qubit, basis in zip(qubits, eve_bases):
        # Measure in her chosen basis (collapses Alice's qubit)
        measured = qubit.measure_in_basis(basis)
        eve_bits.append(measured)
        # Re-prepare a fresh qubit to send to Bob
        new_qubits.append(Qubit.from_bit(measured, basis))

    return new_qubits, eve_bits, eve_bases


def bob_measure(qubits: List[Qubit], bases: List[str]) -> List[int]:
    """
    Bob measures each received qubit in his randomly chosen basis.
    If Bob's basis matches Alice's, he gets the correct bit with certainty.
    If it doesn't match, his result is random.
    """
    return [q.measure_in_basis(b) for q, b in zip(qubits, bases)]


def sift_key(
    alice_bases: List[str],
    bob_bases:   List[str],
) -> List[int]:
    """
    Return indices where Alice and Bob chose the same basis.
    These positions form the 'sifted key' after the public comparison step.
    """
    return [i for i, (a, b) in enumerate(zip(alice_bases, bob_bases)) if a == b]


def estimate_error_rate(
    alice_sifted: List[int],
    bob_sifted:   List[int],
    sample_fraction: float = 0.2,
) -> Tuple[float, List[int], List[int]]:
    """
    Publicly compare a random sample of sifted bits to estimate QBER.
    The sample positions are *sacrificed* (not used in the final key).

    Parameters
    ----------
    sample_fraction : fraction of sifted bits used for error estimation

    Returns
    -------
    error_rate   : fraction of sampled bits that disagree
    remaining_a  : Alice's bits after removing the sample
    remaining_b  : Bob's bits after removing the sample
    """
    n = len(alice_sifted)
    num_sample = max(1, int(n * sample_fraction))
    sample_idx = sorted(random.sample(range(n), min(num_sample, n)))
    sample_set = set(sample_idx)

    errors = sum(
        alice_sifted[i] != bob_sifted[i]
        for i in sample_idx
    )
    error_rate = errors / len(sample_idx) if sample_idx else 0.0

    remaining_a = [alice_sifted[i] for i in range(n) if i not in sample_set]
    remaining_b = [bob_sifted[i]   for i in range(n) if i not in sample_set]

    return error_rate, remaining_a, remaining_b


def privacy_amplification(bits: List[int], target_bytes: int = 32) -> bytes:
    """
    Compress the raw key bits into a final secret key using SHA-256.
    This removes any partial information Eve may have gained.

    Parameters
    ----------
    bits         : raw sifted key bits
    target_bytes : desired output length (default 32 = 256-bit AES key)

    Returns
    -------
    Final key as bytes (exactly target_bytes long via HKDF-like extension).
    """
    if not bits:
        raise ValueError("Cannot generate a key from empty bit list.")

    # Pack bits into bytes
    raw = bits_to_bytes(bits)

    # Use SHA-256 for initial compression; extend if needed
    key = hashlib.sha256(raw).digest()

    # If we need more than 32 bytes, use SHA-512 and truncate
    if target_bytes > 32:
        key = hashlib.sha512(raw).digest()

    # Truncate or pad with counter-mode extension
    if len(key) < target_bytes:
        extended = key
        counter = 1
        while len(extended) < target_bytes:
            extended += hashlib.sha256(raw + counter.to_bytes(4, "big")).digest()
            counter += 1
        key = extended[:target_bytes]
    else:
        key = key[:target_bytes]

    return key


def bits_to_bytes(bits: List[int]) -> bytes:
    """Pack a list of bits (MSB first) into bytes, zero-padding if needed."""
    # Pad to multiple of 8
    padded = bits + [0] * ((8 - len(bits) % 8) % 8)
    result = bytearray()
    for i in range(0, len(padded), 8):
        byte = 0
        for j in range(8):
            byte = (byte << 1) | padded[i + j]
        result.append(byte)
    return bytes(result)


def bytes_to_bits(data: bytes) -> List[int]:
    """Unpack bytes into a list of bits (MSB first)."""
    bits = []
    for byte in data:
        for i in range(7, -1, -1):
            bits.append((byte >> i) & 1)
    return bits


# ─────────────────────────────────────────────────────────────────────────────
# High-level BB84 session
# ─────────────────────────────────────────────────────────────────────────────

def run_bb84(
    num_qubits:      int   = 512,
    eavesdrop:       bool  = False,
    target_key_bytes: int  = 32,
    error_threshold: float = 0.11,  # >11% QBER → abort (theory: Eve causes ~25%)
    verbose_callback          = None,  # optional callable(str) for live updates
) -> BB84Result:
    """
    Run a complete BB84 key exchange session.

    Parameters
    ----------
    num_qubits       : number of qubits transmitted (more → longer key)
    eavesdrop        : if True, inject Eve's intercept-resend attack
    target_key_bytes : desired final key length in bytes (default 32 = AES-256)
    error_threshold  : QBER above this triggers abort
    verbose_callback : optional callback for progress strings

    Returns
    -------
    BB84Result with all protocol data and the final key hex string.

    Raises
    ------
    RuntimeError : if QBER exceeds threshold (eavesdropping detected)
    RuntimeError : if sifted key is too short for the desired key length
    """
    def log(msg: str):
        if verbose_callback:
            verbose_callback(msg)

    result = BB84Result(num_qubits=num_qubits, eve_present=eavesdrop)

    # ── Step 1: Alice prepares qubits ────────────────────────────────────────
    log(f"[BB84] Alice generating {num_qubits} random bits and bases…")
    alice_bits  = random_bits(num_qubits)
    alice_bases = random_bases(num_qubits)
    qubits      = alice_prepare(alice_bits, alice_bases)

    result.alice_bits  = alice_bits
    result.alice_bases = alice_bases

    # ── Step 2: (Optional) Eve intercepts ────────────────────────────────────
    if eavesdrop:
        log("[BB84] ⚠  Eve performing intercept-resend attack…")
        qubits, eve_bits, eve_bases = eve_intercept(qubits)
        result.eavesdropped = True

    # ── Step 3: Bob measures in random bases ─────────────────────────────────
    log("[BB84] Bob measuring in random bases…")
    bob_bases        = random_bases(num_qubits)
    bob_measurements = bob_measure(qubits, bob_bases)

    result.bob_bases        = bob_bases
    result.bob_measurements = bob_measurements

    # ── Step 4: Basis sifting (public channel) ───────────────────────────────
    log("[BB84] Comparing bases (public channel)…")
    sifted_idx = sift_key(alice_bases, bob_bases)

    alice_sifted = [alice_bits[i]       for i in sifted_idx]
    bob_sifted   = [bob_measurements[i] for i in sifted_idx]

    result.sifted_indices = sifted_idx
    result.alice_sifted   = alice_sifted
    result.bob_sifted     = bob_sifted

    log(f"[BB84] Sifted key length: {len(sifted_idx)} bits "
        f"(efficiency: {len(sifted_idx)/num_qubits:.1%})")

    if len(sifted_idx) == 0:
        raise RuntimeError("Sifted key is empty — no basis matches found.")

    # ── Step 5: Error rate estimation ────────────────────────────────────────
    log("[BB84] Estimating error rate on sample…")
    error_rate, remaining_a, remaining_b = estimate_error_rate(
        alice_sifted, bob_sifted
    )
    result.error_rate = error_rate

    if error_rate > error_threshold:
        raise RuntimeError(
            f"[BB84] ABORT — QBER {error_rate:.1%} exceeds threshold "
            f"{error_threshold:.1%}. Eavesdropping detected!"
        )

    log(f"[BB84] QBER: {error_rate:.1%} — {'⚠ HIGH (possible Eve)' if error_rate > 0.05 else '✓ acceptable'}")

    # ── Step 6: Privacy amplification → final key ────────────────────────────
    log(f"[BB84] Privacy amplification → {target_key_bytes * 8}-bit key…")

    if len(remaining_a) < 8:
        raise RuntimeError(
            f"Insufficient sifted bits ({len(remaining_a)}) for key generation. "
            f"Increase num_qubits (try {num_qubits * 4})."
        )

    final_key = privacy_amplification(remaining_a, target_bytes=target_key_bytes)

    result.raw_key_bits  = remaining_a
    result.final_key_hex = final_key.hex()

    log(f"[BB84] ✓ Key generated: {final_key.hex()[:16]}… ({target_key_bytes * 8} bits)")

    return result


# ─────────────────────────────────────────────────────────────────────────────
# Convenience: get raw key bytes from a result
# ─────────────────────────────────────────────────────────────────────────────

def key_bytes_from_result(result: BB84Result) -> bytes:
    """Return the final key as bytes from a BB84Result."""
    return bytes.fromhex(result.final_key_hex)
