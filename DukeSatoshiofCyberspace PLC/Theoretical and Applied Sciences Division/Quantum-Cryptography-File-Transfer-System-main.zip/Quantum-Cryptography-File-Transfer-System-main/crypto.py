"""
crypto.py — AES-256-GCM File Encryption / Decryption
======================================================
Uses the quantum-generated key from BB84 or E91 to encrypt files with
AES-256 in Galois/Counter Mode (GCM), which provides:
  • Confidentiality  (256-bit AES)
  • Integrity        (128-bit authentication tag)
  • Authenticated encryption  (no silent tampering)

Key handling rules:
  1. Keys are NEVER written to disk in plaintext.
  2. Keys are zeroed in memory after use (where Python allows).
  3. A random 96-bit nonce is generated fresh for every encryption.
  4. The nonce + tag are stored in the file header (not secret).

Encrypted file layout (.qcrypt):
  ┌─────────────────────────────────────────┐
  │  Magic   │ 8 bytes  │ "QCRYPT\x01"      │
  │  Nonce   │ 12 bytes │ AES-GCM nonce     │
  │  Tag     │ 16 bytes │ GCM auth tag      │
  │  Length  │ 8 bytes  │ plaintext length  │
  │  Ciphertext         │ variable          │
  └─────────────────────────────────────────┘
  Total overhead: 44 bytes per file.
"""

import os
import struct
import hashlib
import hmac
from typing import Optional, Callable

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.exceptions import InvalidTag


# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────

MAGIC           = b"QCRYPT\x01\x00"   # 8-byte file magic
NONCE_SIZE      = 12                   # AES-GCM standard nonce
TAG_SIZE        = 16                   # AES-GCM authentication tag
HEADER_SIZE     = len(MAGIC) + NONCE_SIZE + TAG_SIZE + 8   # 44 bytes
CHUNK_SIZE      = 64 * 1024            # 64 KiB read/write chunks


# ─────────────────────────────────────────────────────────────────────────────
# Key derivation & validation
# ─────────────────────────────────────────────────────────────────────────────

def derive_aes_key(
    raw_key_material: bytes,
    salt: Optional[bytes] = None,
    info: bytes = b"quantum-crypto-file-encryption",
) -> bytes:
    """
    Derive a 256-bit AES key from raw quantum key material using HKDF-SHA256.

    Even if the input key material is already 32 bytes, running it through
    HKDF ensures uniform distribution and domain separation.

    Parameters
    ----------
    raw_key_material : key bytes from BB84 / E91
    salt             : optional HKDF salt (random 32 bytes if None)
    info             : context string for domain separation

    Returns
    -------
    (key_bytes, salt) — 32-byte AES key and the salt used
    """
    if not raw_key_material:
        raise ValueError("Key material cannot be empty.")

    if salt is None:
        salt = os.urandom(32)

    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        info=info,
    )
    key = hkdf.derive(raw_key_material)
    return key, salt


def validate_key_strength(key_hex: str) -> dict:
    """
    Assess the entropy and quality of a hex-encoded key.

    Note: Shannon entropy per-byte is only reliable for large samples (1000+ bytes).
    For 32-byte keys we instead report total key length bits as the primary
    security metric, supplemented by a uniqueness ratio and bit-balance check.

    Returns
    -------
    dict with: length_bits, unique_bytes, uniqueness_ratio, bit_balance, rating
    """
    import math
    key_bytes = bytes.fromhex(key_hex)
    n = len(key_bytes)
    counts: dict = {}
    for b in key_bytes:
        counts[b] = counts.get(b, 0) + 1

    # Uniqueness: fraction of byte values that appear at least once
    # For a 32-byte uniform random key, ~28-30 unique values is normal
    unique = len(counts)
    # Max possible unique values is min(n, 256)
    uniqueness_ratio = unique / min(n, 256)

    # Bit balance: fraction of set bits across all bytes (should be ~0.5)
    total_bits_set = sum(bin(b).count("1") for b in key_bytes)
    bit_balance = total_bits_set / (n * 8)
    bit_balance_score = 1.0 - abs(bit_balance - 0.5) * 2  # 1.0 = perfect balance

    # Shannon entropy (informational, not the primary security metric)
    shannon = 0.0
    for c in counts.values():
        p = c / n
        if p > 0:
            shannon -= p * math.log2(p)

    # Rating is based on key length (primary) + bit balance (secondary)
    # AES-256 requires 256-bit key; shorter keys are weak regardless of entropy
    if n >= 32 and bit_balance_score >= 0.6:
        rating = "Excellent"
    elif n >= 24 and bit_balance_score >= 0.4:
        rating = "Good"
    elif n >= 16:
        rating = "Fair"
    else:
        rating = "Weak — consider regenerating"

    return {
        "length_bits":       n * 8,
        "unique_bytes":      unique,
        "uniqueness_ratio":  round(uniqueness_ratio, 3),
        "bit_balance":       round(bit_balance, 3),
        "shannon_entropy":   round(shannon, 3),
        "rating":            rating,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Encryption
# ─────────────────────────────────────────────────────────────────────────────

def encrypt_file(
    input_path:  str,
    output_path: str,
    key_hex:     str,
    progress_cb: Optional[Callable[[int, int], None]] = None,
) -> dict:
    """
    Encrypt a file using AES-256-GCM.

    Parameters
    ----------
    input_path  : path to the plaintext file
    output_path : path to write the encrypted .qcrypt file
    key_hex     : 32-byte (64 hex char) AES key from quantum key exchange
    progress_cb : optional callback(bytes_done, total_bytes)

    Returns
    -------
    dict with: nonce_hex, output_size, input_size, integrity_tag_hex

    Raises
    ------
    ValueError      : if key is invalid length
    FileNotFoundError : if input file not found
    """
    key_bytes = bytes.fromhex(key_hex)
    if len(key_bytes) != 32:
        raise ValueError(
            f"AES-256 requires a 32-byte key, got {len(key_bytes)} bytes."
        )

    if not os.path.isfile(input_path):
        raise FileNotFoundError(f"Input file not found: {input_path}")

    nonce = os.urandom(NONCE_SIZE)
    aesgcm = AESGCM(key_bytes)

    # Read full plaintext (stream for large files)
    input_size = os.path.getsize(input_path)
    with open(input_path, "rb") as f:
        plaintext = f.read()

    if progress_cb:
        progress_cb(0, input_size)

    # Encrypt — AESGCM.encrypt() appends the 16-byte GCM tag to ciphertext
    ciphertext_with_tag = aesgcm.encrypt(nonce, plaintext, None)

    # Split ciphertext and tag
    ciphertext = ciphertext_with_tag[:-TAG_SIZE]
    tag        = ciphertext_with_tag[-TAG_SIZE:]

    with open(output_path, "wb") as f:
        f.write(MAGIC)
        f.write(nonce)
        f.write(tag)
        f.write(struct.pack(">Q", input_size))   # 8 bytes big-endian
        f.write(ciphertext)

    if progress_cb:
        progress_cb(input_size, input_size)

    # Zero the key from memory (best-effort in CPython)
    key_bytes = b"\x00" * 32

    return {
        "nonce_hex":         nonce.hex(),
        "integrity_tag_hex": tag.hex(),
        "input_size":        input_size,
        "output_size":       os.path.getsize(output_path),
        "overhead_bytes":    HEADER_SIZE,
    }


def encrypt_bytes(
    plaintext: bytes,
    key_hex:   str,
) -> bytes:
    """
    Encrypt raw bytes; returns the complete .qcrypt blob.
    Useful for in-memory encryption without touching disk.
    """
    key_bytes = bytes.fromhex(key_hex)
    if len(key_bytes) != 32:
        raise ValueError(f"Key must be 32 bytes, got {len(key_bytes)}.")

    nonce = os.urandom(NONCE_SIZE)
    aesgcm = AESGCM(key_bytes)
    ciphertext_with_tag = aesgcm.encrypt(nonce, plaintext, None)
    ciphertext = ciphertext_with_tag[:-TAG_SIZE]
    tag        = ciphertext_with_tag[-TAG_SIZE:]

    return (MAGIC
            + nonce
            + tag
            + struct.pack(">Q", len(plaintext))
            + ciphertext)


# ─────────────────────────────────────────────────────────────────────────────
# Decryption
# ─────────────────────────────────────────────────────────────────────────────

def decrypt_file(
    input_path:  str,
    output_path: str,
    key_hex:     str,
    progress_cb: Optional[Callable[[int, int], None]] = None,
) -> dict:
    """
    Decrypt a .qcrypt file using AES-256-GCM.

    Parameters
    ----------
    input_path  : path to the encrypted .qcrypt file
    output_path : path to write the decrypted plaintext
    key_hex     : the same 32-byte key used during encryption
    progress_cb : optional callback(bytes_done, total_bytes)

    Returns
    -------
    dict with: plaintext_size, integrity_verified

    Raises
    ------
    ValueError    : if file header is invalid or corrupted
    InvalidTag    : if GCM authentication fails (wrong key or tampering)
    """
    key_bytes = bytes.fromhex(key_hex)
    if len(key_bytes) != 32:
        raise ValueError(f"AES-256 requires a 32-byte key, got {len(key_bytes)} bytes.")

    if not os.path.isfile(input_path):
        raise FileNotFoundError(f"Encrypted file not found: {input_path}")

    with open(input_path, "rb") as f:
        header_magic = f.read(len(MAGIC))
        if header_magic != MAGIC:
            raise ValueError(
                "Invalid file header — not a .qcrypt file or file is corrupted."
            )
        nonce      = f.read(NONCE_SIZE)
        tag        = f.read(TAG_SIZE)
        (pt_size,) = struct.unpack(">Q", f.read(8))
        ciphertext = f.read()

    if progress_cb:
        progress_cb(0, pt_size)

    aesgcm = AESGCM(key_bytes)

    try:
        plaintext = aesgcm.decrypt(nonce, ciphertext + tag, None)
    except InvalidTag:
        raise InvalidTag(
            "Authentication failed — the file may be corrupted, tampered with, "
            "or you are using the wrong key."
        )

    with open(output_path, "wb") as f:
        f.write(plaintext)

    if progress_cb:
        progress_cb(pt_size, pt_size)

    # Zero key from memory
    key_bytes = b"\x00" * 32

    return {
        "plaintext_size":    len(plaintext),
        "integrity_verified": True,
        "expected_size":     pt_size,
        "size_match":        len(plaintext) == pt_size,
    }


def decrypt_bytes(blob: bytes, key_hex: str) -> bytes:
    """
    Decrypt a .qcrypt blob in memory; returns plaintext bytes.
    """
    key_bytes = bytes.fromhex(key_hex)
    if len(key_bytes) != 32:
        raise ValueError(f"Key must be 32 bytes, got {len(key_bytes)}.")

    if blob[:len(MAGIC)] != MAGIC:
        raise ValueError("Invalid .qcrypt magic header.")

    offset     = len(MAGIC)
    nonce      = blob[offset:offset + NONCE_SIZE];       offset += NONCE_SIZE
    tag        = blob[offset:offset + TAG_SIZE];         offset += TAG_SIZE
    offset    += 8                                       # skip plaintext length field
    ciphertext = blob[offset:]

    aesgcm = AESGCM(key_bytes)
    return aesgcm.decrypt(nonce, ciphertext + tag, None)


# ─────────────────────────────────────────────────────────────────────────────
# Verification helpers
# ─────────────────────────────────────────────────────────────────────────────

def compute_file_hash(path: str, algorithm: str = "sha256") -> str:
    """Compute the hex digest of a file using the given algorithm."""
    h = hashlib.new(algorithm)
    with open(path, "rb") as f:
        while chunk := f.read(CHUNK_SIZE):
            h.update(chunk)
    return h.hexdigest()


def verify_roundtrip(
    original_path:  str,
    decrypted_path: str,
) -> bool:
    """
    Confirm that the decrypted file is bit-for-bit identical to the original.
    Uses HMAC-SHA256 to prevent timing attacks.
    """
    h_orig = compute_file_hash(original_path)
    h_dec  = compute_file_hash(decrypted_path)
    return hmac.compare_digest(h_orig, h_dec)


def inspect_qcrypt_header(path: str) -> dict:
    """
    Read and return the metadata from a .qcrypt file header without decrypting.
    """
    with open(path, "rb") as f:
        magic = f.read(len(MAGIC))
        if magic != MAGIC:
            raise ValueError("Not a valid .qcrypt file.")
        nonce      = f.read(NONCE_SIZE)
        tag        = f.read(TAG_SIZE)
        (pt_size,) = struct.unpack(">Q", f.read(8))
        ct_size    = os.path.getsize(path) - HEADER_SIZE

    return {
        "magic":              magic.hex(),
        "nonce_hex":          nonce.hex(),
        "auth_tag_hex":       tag.hex(),
        "plaintext_size":     pt_size,
        "ciphertext_size":    ct_size,
        "overhead_bytes":     HEADER_SIZE,
        "file_size":          os.path.getsize(path),
        "format":             "AES-256-GCM",
    }
