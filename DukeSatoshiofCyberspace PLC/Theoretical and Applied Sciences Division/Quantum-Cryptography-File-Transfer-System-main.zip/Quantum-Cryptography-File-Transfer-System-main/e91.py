"""
e91.py — E91 Entanglement-Based Quantum Key Distribution
=========================================================
Implements the Ekert (1991) protocol using entangled Bell pairs:

  1. A source generates pairs of entangled qubits (Φ⁺ Bell state)
  2. Alice and Bob each receive one qubit from every pair
  3. Each measures in one of three randomly chosen angles
  4. They publicly compare measurement settings
  5. Correlated measurements (matching bases) → raw key
  6. Anti-correlated measurements (specific mismatched bases) → Bell test
  7. Bell inequality violation confirms absence of eavesdropping

Security guarantee: any eavesdropper disturbs entanglement, reducing
the Bell parameter S below the quantum maximum of 2√2 ≈ 2.828.

References: Ekert, A.K. (1991). "Quantum cryptography based on Bell's theorem."
            Physical Review Letters, 67(6), 661.
"""

import random
import math
import hashlib
from typing import List, Tuple, Optional, Dict
from dataclasses import dataclass, field

import numpy as np

from qubit_sim import TwoQubitSystem


# ─────────────────────────────────────────────────────────────────────────────
# Measurement angle sets
# ─────────────────────────────────────────────────────────────────────────────

# Alice measures at: 0°, 45°, 90°
ALICE_ANGLES = [0.0, math.pi / 4, math.pi / 2]

# Bob measures at: 45°, 90°, 135°   (shifted by 45° from Alice)
BOB_ANGLES   = [math.pi / 4, math.pi / 2, 3 * math.pi / 4]

# Angle labels for display
ALICE_LABELS = ["0°", "45°", "90°"]
BOB_LABELS   = ["45°", "90°", "135°"]


# ─────────────────────────────────────────────────────────────────────────────
# Core measurement functions
# ─────────────────────────────────────────────────────────────────────────────

def measure_at_angle(qubit_state: np.ndarray, angle: float) -> int:
    """
    Measure a single-qubit state in the basis rotated by `angle` from Z-axis.

    The measurement basis is:
        |+θ⟩ =  cos(θ/2)|0⟩ + sin(θ/2)|1⟩
        |−θ⟩ = -sin(θ/2)|0⟩ + cos(θ/2)|1⟩

    Returns +1 (mapped to 0) or −1 (mapped to 1).
    """
    # Rotation matrix in the equatorial plane
    cos_h = math.cos(angle / 2)
    sin_h = math.sin(angle / 2)
    # Projector onto |+θ⟩
    plus_vec = np.array([cos_h, sin_h], dtype=complex)
    # Probability of outcome +1
    prob_plus = float(abs(np.dot(plus_vec.conj(), qubit_state)) ** 2)
    return 0 if random.random() < prob_plus else 1


def measure_entangled_pair(
    theta_a: float,
    theta_b: float,
    eavesdrop: bool = False,
) -> Tuple[int, int]:
    """
    Generate a Φ⁺ Bell pair and measure qubit A at angle theta_a,
    qubit B at angle theta_b.

    For a perfect Φ⁺ state, the joint probability is:
        P(same result) = cos²((θ_a − θ_b)/2)
        P(diff result) = sin²((θ_a − θ_b)/2)

    If eavesdrop=True, Eve measures qubit B in the Z-basis first,
    collapsing entanglement before Bob measures — this reduces
    correlations and disrupts the Bell inequality.
    """
    # Create entangled pair |Φ⁺⟩ = (|00⟩ + |11⟩)/√2
    pair = TwoQubitSystem.bell_phi_plus()

    # Extract individual qubit states from the entangled state
    # We use the full 4-component state and trace-based marginals
    full_state = pair.state  # shape (4,) in basis {|00⟩,|01⟩,|10⟩,|11⟩}

    if eavesdrop:
        # Eve measures qubit B (qubit 1) in Z-basis, collapses entanglement
        eve_result = pair.measure_qubit1()
        # Now qubit A collapses too; extract its post-measurement state
        # pair.state is now either |0x⟩ or |1x⟩
        if eve_result == 0:
            state_a = np.array([pair.state[0], pair.state[2]], dtype=complex)
        else:
            state_a = np.array([pair.state[1], pair.state[3]], dtype=complex)
        norm_a = np.linalg.norm(state_a)
        state_a = state_a / norm_a if norm_a > 0 else state_a

        # Bob receives a product state (entanglement broken)
        if eve_result == 0:
            state_b = np.array([1.0, 0.0], dtype=complex)
        else:
            state_b = np.array([0.0, 1.0], dtype=complex)

        result_a = measure_at_angle(state_a, theta_a)
        result_b = measure_at_angle(state_b, theta_b)
        return result_a, result_b

    # ── No eavesdropping: use quantum-mechanical joint measurement ────────────
    # For Φ⁺ the expectation E(θ_a, θ_b) = cos(θ_a − θ_b)
    # We simulate this directly for efficiency
    delta = theta_a - theta_b
    prob_same = math.cos(delta / 2) ** 2
    same = random.random() < prob_same

    # Alice's result is uniformly random (50/50)
    result_a = random.randint(0, 1)
    result_b = result_a if same else (1 - result_a)
    return result_a, result_b


# ─────────────────────────────────────────────────────────────────────────────
# CHSH Bell inequality
# ─────────────────────────────────────────────────────────────────────────────

def compute_chsh_parameter(
    results: List[Dict],
    angle_pairs: List[Tuple[int, int]],
) -> float:
    """
    Compute the CHSH parameter S from measurement results.

    S = |E(a,b) − E(a,b')| + |E(a',b) + E(a',b')|

    Classical bound: S ≤ 2
    Quantum maximum: S = 2√2 ≈ 2.828

    Parameters
    ----------
    results     : list of {'a_angle_idx': int, 'b_angle_idx': int,
                            'a_result': int, 'b_result': int}
    angle_pairs : list of 4 (alice_idx, bob_idx) pairs for CHSH correlators

    Returns
    -------
    S : CHSH parameter (float)
    """
    def correlator(ai: int, bi: int) -> float:
        """E(ai, bi) = average product of ±1 outcomes."""
        filtered = [
            r for r in results
            if r["a_angle_idx"] == ai and r["b_angle_idx"] == bi
        ]
        if not filtered:
            return 0.0
        # Convert 0/1 results to ±1
        products = [
            (1 - 2 * r["a_result"]) * (1 - 2 * r["b_result"])
            for r in filtered
        ]
        return sum(products) / len(products)

    # Standard CHSH: using Alice angles 0,1 and Bob angles 0,1
    # E(0°,45°), E(0°,135°), E(90°,45°), E(90°,135°)
    E_00 = correlator(0, 0)  # Alice 0°, Bob 45°
    E_01 = correlator(0, 2)  # Alice 0°, Bob 135°
    E_10 = correlator(2, 0)  # Alice 90°, Bob 45°
    E_11 = correlator(2, 2)  # Alice 90°, Bob 135°

    S = abs(E_00 - E_01) + abs(E_10 + E_11)
    return S


# ─────────────────────────────────────────────────────────────────────────────
# E91 session
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class E91Result:
    """Complete record of one E91 key exchange session."""
    num_pairs:      int   = 0
    raw_results:    list  = field(default_factory=list)
    key_bits_alice: List[int] = field(default_factory=list)
    key_bits_bob:   List[int] = field(default_factory=list)
    chsh_S:         float = 0.0
    error_rate:     float = 0.0
    final_key_hex:  str   = ""
    eve_present:    bool  = False

    @property
    def bell_test_passed(self) -> bool:
        """True if CHSH S > 2 (quantum correlations confirmed, no Eve)."""
        return self.chsh_S > 2.0

    @property
    def key_length_bits(self) -> int:
        return len(self.key_bits_alice)


def run_e91(
    num_pairs:       int   = 600,
    eavesdrop:       bool  = False,
    target_key_bytes: int  = 32,
    verbose_callback       = None,
) -> E91Result:
    """
    Run a complete E91 entanglement-based key exchange session.

    Parameters
    ----------
    num_pairs        : total entangled pairs to generate
    eavesdrop        : if True, Eve intercepts each pair
    target_key_bytes : final key length (default 32 = AES-256)
    verbose_callback : optional callable(str) for progress updates

    Returns
    -------
    E91Result with CHSH parameter, key bits, and final key hex.
    """
    def log(msg: str):
        if verbose_callback:
            verbose_callback(msg)

    result = E91Result(num_pairs=num_pairs, eve_present=eavesdrop)

    log(f"[E91] Generating {num_pairs} entangled Bell pairs…")
    if eavesdrop:
        log("[E91] ⚠  Eve is intercepting entangled qubits…")

    all_results = []
    key_a: List[int] = []
    key_b: List[int] = []

    for _ in range(num_pairs):
        # Alice and Bob each randomly pick one of their three angles
        a_idx = random.randint(0, 2)
        b_idx = random.randint(0, 2)

        theta_a = ALICE_ANGLES[a_idx]
        theta_b = BOB_ANGLES[b_idx]

        r_a, r_b = measure_entangled_pair(theta_a, theta_b, eavesdrop=eavesdrop)

        entry = {
            "a_angle_idx": a_idx,
            "b_angle_idx": b_idx,
            "a_angle":     math.degrees(theta_a),
            "b_angle":     math.degrees(theta_b),
            "a_result":    r_a,
            "b_result":    r_b,
        }
        all_results.append(entry)

        # Key generation: when both chose the same angle
        if ALICE_ANGLES[a_idx] == BOB_ANGLES[b_idx]:
            # For Φ⁺, measuring at the same angle → perfectly correlated (r_a == r_b)
            # Both keep their bit directly; they share the same value.
            key_a.append(r_a)
            key_b.append(r_b)

    result.raw_results = all_results

    # ── Bell test ─────────────────────────────────────────────────────────────
    log("[E91] Computing CHSH Bell parameter…")
    S = compute_chsh_parameter(all_results, [])
    result.chsh_S = S

    log(f"[E91] CHSH S = {S:.4f}  "
        f"(classical max: 2.0, quantum max: 2√2 ≈ {2*math.sqrt(2):.4f})")

    if S <= 2.0:
        log("[E91] ⚠  Bell inequality NOT violated — eavesdropping may be present!")
    else:
        log("[E91] ✓ Bell inequality violated — quantum channel is secure")

    # ── Key agreement check ───────────────────────────────────────────────────
    if key_a and key_b:
        errors = sum(a != b for a, b in zip(key_a, key_b))
        result.error_rate = errors / len(key_a)
        log(f"[E91] Key error rate: {result.error_rate:.1%} "
            f"({len(key_a)} key bits from {num_pairs} pairs)")

    result.key_bits_alice = key_a
    result.key_bits_bob   = key_b

    # ── Privacy amplification ─────────────────────────────────────────────────
    if len(key_a) < 8:
        raise RuntimeError(
            f"[E91] Insufficient key bits ({len(key_a)}). "
            f"Increase num_pairs (try {num_pairs * 4})."
        )

    from bb84 import privacy_amplification
    final_key = privacy_amplification(key_a, target_bytes=target_key_bytes)
    result.final_key_hex = final_key.hex()

    log(f"[E91] ✓ Final key: {final_key.hex()[:16]}… ({target_key_bytes * 8} bits)")

    return result


def key_bytes_from_e91(result: E91Result) -> bytes:
    """Return the final key as bytes from an E91Result."""
    return bytes.fromhex(result.final_key_hex)
