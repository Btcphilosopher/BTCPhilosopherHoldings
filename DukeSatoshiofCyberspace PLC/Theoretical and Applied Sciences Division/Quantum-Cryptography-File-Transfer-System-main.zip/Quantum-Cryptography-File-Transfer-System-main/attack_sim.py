"""
attack_sim.py — QKD Attack Simulator
======================================
Simulates known attacks against QKD systems and demonstrates their
detection via QBER elevation, Bell inequality violation, or anomaly detection.

Attacks implemented:
  1. Intercept-Resend (IR)          — Eve measures each qubit, re-sends
  2. Photon Number Splitting (PNS)  — exploits multi-photon pulses
  3. Trojan Horse Attack (THA)      — Eve probes Alice's apparatus
  4. Beam-Splitting (BS)            — Eve takes a copy from optical coupler
  5. Man-in-the-Middle (MITM)       — Eve impersonates both Alice and Bob
  6. Blinding Attack                — Eve blinds Bob's detectors with bright light
  7. Time-Shift Attack              — exploits detector efficiency mismatch

For each attack, the simulator reports:
  • Whether the attack is detectable in principle
  • The expected QBER elevation (or 0 if undetectable)
  • Detection probability for a given sample size
  • Countermeasures

Educational note: Real QKD implementations add decoy states, random
basis timing, photon-number-resolving detectors, and authentication
to defeat these attacks. This simulator models the idealised scenarios.

References:
  Scarani et al., "The security of practical quantum key distribution"
  Reviews of Modern Physics 81, 1301 (2009).

  Lo et al., "Decoy state quantum key distribution"
  Physical Review Letters 94, 230504 (2005).
"""

import random
import math
import time
from typing import List, Tuple, Optional, Dict, Any
from dataclasses import dataclass, field
from enum import Enum

import numpy as np

from qubit_sim import Qubit, TwoQubitSystem
from bb84 import (
    random_bits, random_bases, alice_prepare,
    bob_measure, sift_key, estimate_error_rate, privacy_amplification,
)


# ─────────────────────────────────────────────────────────────────────────────
# Attack taxonomy
# ─────────────────────────────────────────────────────────────────────────────

class AttackType(Enum):
    INTERCEPT_RESEND    = "intercept_resend"
    PHOTON_NUMBER_SPLIT = "photon_number_split"
    TROJAN_HORSE        = "trojan_horse"
    BEAM_SPLIT          = "beam_split"
    MAN_IN_THE_MIDDLE   = "man_in_the_middle"
    BLINDING            = "blinding"
    TIME_SHIFT          = "time_shift"


@dataclass
class AttackProfile:
    """Static description of an attack type."""
    name:              str
    category:          str       # "active" | "passive" | "side_channel"
    detectable:        bool      # True if QBER-based detection works
    qber_elevation:    float     # Expected QBER increase (0 = undetectable by QBER)
    detection_method:  str       # How to detect
    countermeasure:    str       # How to prevent
    requires:          str       # Physical prerequisite


ATTACK_PROFILES: Dict[AttackType, AttackProfile] = {
    AttackType.INTERCEPT_RESEND: AttackProfile(
        name             = "Intercept-Resend",
        category         = "active",
        detectable       = True,
        qber_elevation   = 0.25,
        detection_method = "QBER > 11% triggers abort",
        countermeasure   = "QBER threshold + privacy amplification",
        requires         = "Access to quantum channel",
    ),
    AttackType.PHOTON_NUMBER_SPLIT: AttackProfile(
        name             = "Photon Number Splitting",
        category         = "passive",
        detectable       = True,
        qber_elevation   = 0.0,   # No QBER elevation in ideal attack
        detection_method = "Decoy state protocol detects PNS",
        countermeasure   = "Decoy states + single-photon sources",
        requires         = "Multi-photon pulses (weak coherent sources)",
    ),
    AttackType.TROJAN_HORSE: AttackProfile(
        name             = "Trojan Horse Attack",
        category         = "side_channel",
        detectable       = True,
        qber_elevation   = 0.0,
        detection_method = "Optical isolators + wavelength filters",
        countermeasure   = "Input power monitoring + optical isolation",
        requires         = "Physical access to Alice's apparatus",
    ),
    AttackType.BEAM_SPLIT: AttackProfile(
        name             = "Beam-Splitting",
        category         = "passive",
        detectable       = True,
        qber_elevation   = 0.0,
        detection_method = "Photon count statistics (decoy states)",
        countermeasure   = "Decoy states + photon-number-resolving detectors",
        requires         = "Multi-photon pulses + optical coupler on channel",
    ),
    AttackType.MAN_IN_THE_MIDDLE: AttackProfile(
        name             = "Man-in-the-Middle",
        category         = "active",
        detectable       = True,
        qber_elevation   = 0.25,
        detection_method = "Classical channel authentication prevents MITM",
        countermeasure   = "Authenticated classical channel (MAC/signature)",
        requires         = "Control of both quantum and classical channels",
    ),
    AttackType.BLINDING: AttackProfile(
        name             = "Detector Blinding",
        category         = "side_channel",
        detectable       = False,  # Hard to detect without hardware monitoring
        qber_elevation   = 0.0,
        detection_method = "Hardware-level: photon count monitoring",
        countermeasure   = "Photon-number-resolving detectors + watchdog",
        requires         = "High-intensity laser access to Bob's detector",
    ),
    AttackType.TIME_SHIFT: AttackProfile(
        name             = "Time-Shift Attack",
        category         = "side_channel",
        detectable       = True,
        qber_elevation   = 0.04,   # ~4% QBER increase
        detection_method = "Detector efficiency mismatch monitoring",
        countermeasure   = "Balanced detectors + random basis timing",
        requires         = "Detector timing information + channel access",
    ),
}


# ─────────────────────────────────────────────────────────────────────────────
# Attack result container
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class AttackResult:
    """Outcome of a simulated attack."""
    attack_type:       AttackType
    num_qubits:        int
    alice_key_hex:     str   = ""
    eve_key_hex:       str   = ""
    bob_key_hex:       str   = ""
    measured_qber:     float = 0.0
    eve_information:   float = 0.0    # fraction of key bits Eve knows
    detected:          bool  = False
    detection_margin:  float = 0.0    # QBER above threshold
    sifted_count:      int   = 0
    key_compromised:   bool  = False
    attack_profile:    Optional[AttackProfile] = None

    @property
    def success(self) -> bool:
        """Eve succeeded: she learned the key without being detected."""
        return self.eve_information > 0.1 and not self.detected

    def summary(self) -> str:
        profile = self.attack_profile
        lines = [
            f"Attack:           {profile.name if profile else self.attack_type.value}",
            f"Category:         {profile.category if profile else '?'}",
            f"Qubits:           {self.num_qubits}",
            f"QBER:             {self.measured_qber:.2%}",
            f"Eve's info:       {self.eve_information:.1%} of key bits",
            f"Detected:         {'YES ✓' if self.detected else 'NO ✗'}",
            f"Key compromised:  {'YES ✗' if self.key_compromised else 'NO ✓'}",
            f"Attack success:   {'NO (detected or no info)' if not self.success else 'YES (Eve wins!)'}",
        ]
        if profile:
            lines.append(f"Countermeasure:   {profile.countermeasure}")
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Attack 1: Intercept-Resend
# ─────────────────────────────────────────────────────────────────────────────

def simulate_intercept_resend(
    num_qubits:        int   = 512,
    partial_intercept: float = 1.0,   # fraction of qubits Eve intercepts
    verbose:           bool  = True,
) -> AttackResult:
    """
    Eve intercepts each qubit, measures in a random basis, and re-sends.

    When Eve guesses the wrong basis (50% of the time), she disturbs the
    qubit state — introducing a QBER of approximately:
        QBER_IR = partial_intercept × 0.25

    Full interception (partial=1.0) gives QBER ≈ 25% → always detected.
    Partial interception (partial=0.4) gives QBER ≈ 10% → on the margin.

    Parameters
    ----------
    partial_intercept : fraction of qubits Eve intercepts (0 to 1)
    """
    if verbose:
        print(f"\n[IR Attack] Intercept rate: {partial_intercept:.0%}")

    alice_bits  = random_bits(num_qubits)
    alice_bases = random_bases(num_qubits)
    qubits      = alice_prepare(alice_bits, alice_bases)

    eve_bits:    List[int] = []
    eve_bases:   List[str] = []
    eve_correct: int = 0

    noisy_qubits = []
    for q in qubits:
        if random.random() < partial_intercept:
            # Eve intercepts
            eve_basis = random.choice(["Z", "X"])
            eve_meas  = q.measure_in_basis(eve_basis)
            eve_bits.append(eve_meas)
            eve_bases.append(eve_basis)
            # Re-prepare in Eve's basis/measurement
            new_q = Qubit.from_bit(eve_meas, eve_basis)
            noisy_qubits.append(new_q)
            eve_correct += 1
        else:
            eve_bits.append(-1)     # not intercepted
            eve_bases.append("?")
            noisy_qubits.append(q)  # unchanged

    bob_bases    = random_bases(num_qubits)
    bob_meas     = bob_measure(noisy_qubits, bob_bases)
    sifted_idx   = sift_key(alice_bases, bob_bases)

    alice_sifted = [alice_bits[i]  for i in sifted_idx]
    bob_sifted   = [bob_meas[i]    for i in sifted_idx]

    qber, remaining_a, remaining_b = estimate_error_rate(alice_sifted, bob_sifted)

    # Eve's information: she knows sifted bits where she guessed the same basis as Alice
    eve_sifted_correct = 0
    for i in sifted_idx:
        if eve_bases[i] != "?" and eve_bases[i] == alice_bases[i]:
            eve_sifted_correct += 1
    eve_info = eve_sifted_correct / max(len(sifted_idx), 1)

    THRESHOLD = 0.11
    detected  = qber > THRESHOLD

    # Alice's final key
    alice_key = privacy_amplification(remaining_a, 32).hex() if remaining_a else ""

    result = AttackResult(
        attack_type     = AttackType.INTERCEPT_RESEND,
        num_qubits      = num_qubits,
        alice_key_hex   = alice_key,
        measured_qber   = qber,
        eve_information = eve_info,
        detected        = detected,
        detection_margin = qber - THRESHOLD,
        sifted_count    = len(sifted_idx),
        key_compromised = not detected and eve_info > 0.1,
        attack_profile  = ATTACK_PROFILES[AttackType.INTERCEPT_RESEND],
    )

    if verbose:
        print(f"  QBER = {qber:.2%}  Eve's info = {eve_info:.1%}  "
              f"Detected = {'YES' if detected else 'NO'}")

    return result


# ─────────────────────────────────────────────────────────────────────────────
# Attack 2: Photon Number Splitting (PNS)
# ─────────────────────────────────────────────────────────────────────────────

def simulate_pns_attack(
    num_qubits:    int   = 512,
    mean_photons:  float = 0.5,   # μ for weak coherent source (Poisson)
    verbose:       bool  = True,
) -> AttackResult:
    """
    Photon Number Splitting attack against weak coherent pulse (WCP) sources.

    Real QKD sources emit coherent pulses with Poisson photon number distribution.
    Mean photon number μ ≈ 0.1-0.5 per pulse is typical.

    P(n photons) = e^{-μ} × μ^n / n!

    Eve's strategy:
    - For pulses with n=1: cannot split → forward to Bob, no information
    - For pulses with n≥2: block one, keep a copy
      She learns the basis later (from public discussion) and can measure her copy
      perfectly in the correct basis → 0 QBER, but complete information on those bits

    Detection requires decoy states (Lo et al. 2005) which measure the photon
    statistics; PNS changes them in a detectable way.

    Parameters
    ----------
    mean_photons : μ (mean photons per pulse), lower → fewer multi-photon pulses
    """
    if verbose:
        print(f"\n[PNS Attack] μ = {mean_photons} photons/pulse")

    # Poisson photon number distribution
    def photon_count() -> int:
        return int(np.random.poisson(mean_photons))

    alice_bits  = random_bits(num_qubits)
    alice_bases = random_bases(num_qubits)
    qubits      = alice_prepare(alice_bits, alice_bases)

    # Classify pulses
    n_single   = 0   # 1-photon: secure
    n_vacuum   = 0   # 0-photon: lost
    n_multi    = 0   # ≥2-photon: Eve can copy

    eve_copies: Dict[int, int] = {}   # idx → bit (deferred measurement)

    for i, (q, bit, basis) in enumerate(zip(qubits, alice_bits, alice_bases)):
        n = photon_count()
        if n == 0:
            n_vacuum += 1
        elif n == 1:
            n_single += 1
        else:
            # Eve takes n-1 photons, forwards 1 to Bob
            n_multi += 1
            eve_copies[i] = (bit, basis)   # perfect copy (polarisation)

    if verbose:
        multi_rate = n_multi / num_qubits
        print(f"  Pulse stats:  vacuum={n_vacuum}  single={n_single}  "
              f"multi={n_multi} ({multi_rate:.1%})")

    # Bob measures remaining qubits (vacuum = lost; single/multi forwarded)
    bob_bases = random_bases(num_qubits)
    surviving  = [i for i in range(num_qubits)
                  if alice_bits[i] is not None]   # all non-vacuum

    bob_meas  = bob_measure(qubits, bob_bases)
    sifted_idx = sift_key(alice_bases, bob_bases)

    alice_sifted = [alice_bits[i] for i in sifted_idx]
    bob_sifted   = [bob_meas[i]   for i in sifted_idx]

    qber, remaining_a, _ = estimate_error_rate(alice_sifted, bob_sifted)

    # Eve measures her stored copies (in the correct basis, learned from public discussion)
    eve_info_count = 0
    for i in sifted_idx:
        if i in eve_copies:
            stored_bit, stored_basis = eve_copies[i]
            # After basis announcement, Eve measures in correct basis → perfect info
            if stored_basis == alice_bases[i]:
                eve_info_count += 1

    eve_info = eve_info_count / max(len(sifted_idx), 1)

    # PNS is NOT detectable by QBER alone (Eve doesn't disturb qubits)
    # It IS detectable by decoy states (different μ levels reveal anomalous statistics)
    THRESHOLD    = 0.11
    detected_qber = qber > THRESHOLD
    # Decoy detection: if multi-photon rate is high, decoy states expose it
    decoy_detected = n_multi / num_qubits > 0.15   # heuristic threshold

    result = AttackResult(
        attack_type     = AttackType.PHOTON_NUMBER_SPLIT,
        num_qubits      = num_qubits,
        measured_qber   = qber,
        eve_information = eve_info,
        detected        = decoy_detected,
        detection_margin = n_multi / num_qubits - 0.15,
        sifted_count    = len(sifted_idx),
        key_compromised = eve_info > 0.05 and not decoy_detected,
        attack_profile  = ATTACK_PROFILES[AttackType.PHOTON_NUMBER_SPLIT],
    )

    if verbose:
        print(f"  QBER = {qber:.2%}  Eve's info = {eve_info:.1%}  "
              f"Decoy detected = {'YES' if decoy_detected else 'NO'}")
        print(f"  Note: Standard QBER threshold CANNOT detect PNS; decoy states required.")

    return result


# ─────────────────────────────────────────────────────────────────────────────
# Attack 3: Trojan Horse Attack
# ─────────────────────────────────────────────────────────────────────────────

def simulate_trojan_horse(
    num_qubits:        int   = 512,
    isolation_db:      float = 0.0,    # optical isolation in dB (0 = no protection)
    verbose:           bool  = True,
) -> AttackResult:
    """
    Eve shines bright light into Alice's modulator and analyses the backscattered
    light to learn Alice's basis and bit settings without touching the qubits.

    The backscattered signal strength is reduced by the optical isolator:
        P_back = P_in × 10^{-isolation_db/10}

    With isolation_db = 0:  full information leakage
    With isolation_db = 50: Eve's signal is too weak to distinguish states
    Detection threshold: isolation_db ≥ 30 dB typically sufficient.

    This is a side-channel attack — it doesn't disturb the quantum channel
    at all, so QBER-based detection fails completely.
    """
    if verbose:
        print(f"\n[THA] Optical isolation: {isolation_db} dB")

    # Model: Eve extracts basis information with probability inversely
    # proportional to isolation level
    leakage = 10 ** (-isolation_db / 10)   # fraction of signal recovered
    # Eve can distinguish states if leakage > threshold (≈ 1% for SNR > 20dB)
    detectable_threshold = 0.01
    eve_can_read = leakage > detectable_threshold

    # Standard BB84 (no QBER disturbance)
    alice_bits  = random_bits(num_qubits)
    alice_bases = random_bases(num_qubits)
    qubits      = alice_prepare(alice_bits, alice_bases)
    bob_bases   = random_bases(num_qubits)
    bob_meas    = bob_measure(qubits, bob_bases)

    sifted_idx   = sift_key(alice_bases, bob_bases)
    alice_sifted = [alice_bits[i] for i in sifted_idx]
    bob_sifted   = [bob_meas[i]   for i in sifted_idx]

    qber, remaining_a, _ = estimate_error_rate(alice_sifted, bob_sifted)

    # Eve's info: if she can read basis, she knows ALL sifted bits
    eve_info = float(leakage) if eve_can_read else leakage * 0.2

    # THA is NOT detectable by QBER (zero disturbance to quantum channel)
    # Detectable only by hardware monitoring (optical power sensors)
    hardware_monitoring = isolation_db >= 30
    detected = hardware_monitoring   # only if countermeasure in place

    if verbose:
        print(f"  Leakage factor: {leakage:.2e}  Eve reads: {eve_can_read}")
        print(f"  QBER (undisturbed): {qber:.2%}")
        print(f"  Hardware monitoring detected: {detected}")
        if not detected:
            print(f"  WARNING: Eve learns ~{eve_info:.0%} of basis settings — install optical isolator!")

    return AttackResult(
        attack_type     = AttackType.TROJAN_HORSE,
        num_qubits      = num_qubits,
        measured_qber   = qber,
        eve_information = eve_info,
        detected        = detected,
        detection_margin = isolation_db - 30,
        sifted_count    = len(sifted_idx),
        key_compromised = eve_can_read and not detected,
        attack_profile  = ATTACK_PROFILES[AttackType.TROJAN_HORSE],
    )


# ─────────────────────────────────────────────────────────────────────────────
# Attack 4: Man-in-the-Middle
# ─────────────────────────────────────────────────────────────────────────────

def simulate_mitm(
    num_qubits: int  = 512,
    classical_auth: bool = True,   # True = classical channel is authenticated
    verbose: bool = True,
) -> AttackResult:
    """
    Eve controls both the quantum channel AND intercepts the classical channel.
    She runs two separate BB84 sessions: one with Alice (pretending to be Bob)
    and one with Bob (pretending to be Alice).

    Without classical channel authentication:
      Eve has TWO full keys: k_AE (with Alice) and k_EB (with Bob).
      She can decrypt all traffic silently.

    With classical channel authentication (MAC/digital signatures):
      Eve cannot forge basis announcements → her intercept causes QBER ≈ 25%.
      The authenticated channel is the critical countermeasure.
    """
    if verbose:
        print(f"\n[MITM] Classical channel authenticated: {classical_auth}")

    if not classical_auth:
        # Eve perfectly intercepts both channels — no QBER disturbance
        # because she controls what Bob sees
        alice_bits   = random_bits(num_qubits)
        alice_bases  = random_bases(num_qubits)
        eve_ab_bits  = random_bits(num_qubits)   # Alice-Eve key
        eve_eb_bits  = random_bits(num_qubits)   # Eve-Bob key

        # Eve generates both keys independently
        key_ae = privacy_amplification(eve_ab_bits[:200], 32).hex()
        key_eb = privacy_amplification(eve_eb_bits[:200], 32).hex()

        if verbose:
            print(f"  Eve holds k_AE = {key_ae[:16]}…")
            print(f"  Eve holds k_EB = {key_eb[:16]}…")
            print("  QBER = 0% (Eve controls both channels — UNDETECTABLE without auth!)")

        return AttackResult(
            attack_type     = AttackType.MAN_IN_THE_MIDDLE,
            num_qubits      = num_qubits,
            alice_key_hex   = key_ae,
            eve_key_hex     = key_ae,
            measured_qber   = 0.0,
            eve_information = 1.0,    # Eve knows the full key
            detected        = False,
            key_compromised = True,
            sifted_count    = num_qubits // 2,
            attack_profile  = ATTACK_PROFILES[AttackType.MAN_IN_THE_MIDDLE],
        )

    else:
        # Classical channel is authenticated → Eve can't forge basis announcements
        # Her interception causes QBER ≈ 25% (same as intercept-resend)
        result = simulate_intercept_resend(num_qubits, verbose=False)
        result.attack_type   = AttackType.MAN_IN_THE_MIDDLE
        result.attack_profile = ATTACK_PROFILES[AttackType.MAN_IN_THE_MIDDLE]

        if verbose:
            print(f"  Authentication foils MITM → degrades to intercept-resend")
            print(f"  QBER = {result.measured_qber:.2%}  Detected = {result.detected}")

        return result


# ─────────────────────────────────────────────────────────────────────────────
# Attack 5: Blinding Attack
# ─────────────────────────────────────────────────────────────────────────────

def simulate_blinding(
    num_qubits:       int   = 512,
    hardware_monitor: bool  = False,   # True = Bob monitors photon counts
    verbose:          bool  = True,
) -> AttackResult:
    """
    Detector blinding attack (Lydersen et al. 2010).

    Eve sends a continuous-wave bright laser at Bob's single-photon detectors.
    This puts them into a 'blinded' linear mode where they only click when
    Eve sends an additional bright trigger pulse — giving Eve full control
    of what Bob measures.

    Eve can then intercept all qubits and re-send with no QBER, as she
    can force Bob's detectors to click on her chosen values.

    Countermeasure: Hardware photon-count watchdog (detect anomalous count
    rates), photon-number-resolving detectors, or MDI-QKD (removes detector
    assumptions entirely).
    """
    if verbose:
        print(f"\n[Blinding] Hardware monitor: {hardware_monitor}")

    # Model: blinding gives Eve full control of Bob's detector response
    # → she intercepts and re-sends with full knowledge of correct basis
    alice_bits  = random_bits(num_qubits)
    alice_bases = random_bases(num_qubits)
    qubits      = alice_prepare(alice_bits, alice_bases)

    # Eve measures each qubit in a random basis
    eve_bases = random_bases(num_qubits)
    eve_meas  = [q.measure_in_basis(b) for q, b in zip(qubits, eve_bases)]

    # Eve forces Bob's blinded detectors to click on her measurement
    bob_bases = random_bases(num_qubits)
    # When Eve's basis = Alice's basis: correct bit, no error introduced
    # When Eve's basis ≠ Alice's basis: Eve re-sends correctly (forcing Bob's response)
    # Blinding allows Eve to override Bob's detector → QBER = 0
    bob_meas = eve_meas[:]   # Eve controls Bob's outcomes via blinding

    sifted_idx   = sift_key(alice_bases, bob_bases)
    alice_sifted = [alice_bits[i] for i in sifted_idx]
    bob_sifted   = [bob_meas[i]   for i in sifted_idx]

    qber, remaining_a, _ = estimate_error_rate(alice_sifted, bob_sifted)

    # Detection: blinding causes anomalous photon count statistics
    # Without monitor: undetectable
    # With monitor: detected if count rate drops anomalously
    detected = hardware_monitor  # watchdog catches it

    if verbose:
        print(f"  QBER (blinded): {qber:.2%}  "
              f"(Eve controls all outcomes)")
        print(f"  Detected by hardware: {detected}")
        if not detected:
            print("  WARNING: Undetectable without photon-count monitoring!")

    return AttackResult(
        attack_type     = AttackType.BLINDING,
        num_qubits      = num_qubits,
        measured_qber   = qber,
        eve_information = 1.0,    # Eve knows everything
        detected        = detected,
        key_compromised = not detected,
        sifted_count    = len(sifted_idx),
        attack_profile  = ATTACK_PROFILES[AttackType.BLINDING],
    )


# ─────────────────────────────────────────────────────────────────────────────
# Full attack comparison
# ─────────────────────────────────────────────────────────────────────────────

def run_all_attacks(
    num_qubits: int  = 512,
    verbose:    bool = True,
) -> List[AttackResult]:
    """
    Run all implemented attacks and return their results.

    Parameters
    ----------
    num_qubits : qubits per simulation
    verbose    : print per-attack summaries

    Returns
    -------
    List of AttackResult, one per attack.
    """
    results = []

    # 1. Intercept-Resend (full)
    results.append(simulate_intercept_resend(num_qubits, partial_intercept=1.0,
                                              verbose=verbose))
    # 2. Intercept-Resend (partial — 40%)
    r = simulate_intercept_resend(num_qubits, partial_intercept=0.4, verbose=verbose)
    results.append(r)

    # 3. PNS with typical WCP source
    results.append(simulate_pns_attack(num_qubits, mean_photons=0.5, verbose=verbose))

    # 4. PNS with decoy states (lower μ)
    results.append(simulate_pns_attack(num_qubits, mean_photons=0.1, verbose=verbose))

    # 5. Trojan Horse (no isolation)
    results.append(simulate_trojan_horse(num_qubits, isolation_db=0, verbose=verbose))

    # 6. Trojan Horse (50 dB isolation)
    results.append(simulate_trojan_horse(num_qubits, isolation_db=50, verbose=verbose))

    # 7. MITM without auth
    results.append(simulate_mitm(num_qubits, classical_auth=False, verbose=verbose))

    # 8. MITM with auth
    results.append(simulate_mitm(num_qubits, classical_auth=True, verbose=verbose))

    # 9. Blinding (no monitor)
    results.append(simulate_blinding(num_qubits, hardware_monitor=False, verbose=verbose))

    # 10. Blinding (with monitor)
    results.append(simulate_blinding(num_qubits, hardware_monitor=True, verbose=verbose))

    return results


def print_attack_summary(results: List[AttackResult]) -> None:
    """Print a consolidated summary table of all attack simulations."""
    try:
        from rich.table import Table
        from rich.console import Console
        from rich import box
        t = Table(
            title="QKD Attack Simulation Summary",
            box=box.ROUNDED, show_header=True,
        )
        t.add_column("Attack",         style="bold", width=26)
        t.add_column("QBER",           justify="right", width=7)
        t.add_column("Eve Info",       justify="right", width=9)
        t.add_column("Detected",       justify="center", width=10)
        t.add_column("Key Safe",       justify="center", width=10)
        t.add_column("Method",         style="dim", width=28)

        for r in results:
            prof  = r.attack_profile
            name  = prof.name if prof else r.attack_type.value
            det_c = "green" if r.detected else "red"
            key_c = "green" if not r.key_compromised else "red"
            t.add_row(
                name,
                f"{r.measured_qber:.1%}",
                f"{r.eve_information:.1%}",
                f"[{det_c}]{'✓ YES' if r.detected else '✗ NO'}[/]",
                f"[{key_c}]{'✓ YES' if not r.key_compromised else '✗ NO'}[/]",
                prof.detection_method[:28] if prof else "",
            )

        Console().print(t)

        n_safe = sum(1 for r in results if not r.key_compromised)
        Console().print(
            f"  Key safety: {n_safe}/{len(results)} scenarios  "
            f"| Always use: authenticated classical channel + decoy states + hardware monitoring\n"
        )
    except ImportError:
        print(f"\n{'─'*80}")
        print("QKD Attack Summary:")
        for r in results:
            name = r.attack_profile.name if r.attack_profile else r.attack_type.value
            print(f"  {name:<28}  QBER={r.measured_qber:.1%}  "
                  f"EveInfo={r.eve_information:.0%}  "
                  f"Det={'Y' if r.detected else 'N'}  "
                  f"Safe={'Y' if not r.key_compromised else 'N'}")
