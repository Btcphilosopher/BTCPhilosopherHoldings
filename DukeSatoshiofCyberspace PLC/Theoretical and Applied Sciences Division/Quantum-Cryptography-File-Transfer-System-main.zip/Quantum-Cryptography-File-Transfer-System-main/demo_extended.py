"""
demo_extended.py — Extended Tests for noise_model, cascade, network_sim, report, benchmarks
"""

import os
import sys
import tempfile
import random

sys.path.insert(0, os.path.dirname(__file__))

try:
    from rich.console import Console
    from rich.rule import Rule
    console = Console()
    def section(t): console.print(Rule(f"[bold cyan]{t}[/]", style="cyan"))
    def ok(m):   console.print(f"  [bold green]✓[/] {m}")
    def err(m):  console.print(f"  [bold red]✗[/] {m}")
    def info(m): console.print(f"  [dim]{m}[/]")
except ImportError:
    console = None
    def section(t): print(f"\n{'='*60}\n  {t}\n{'='*60}")
    def ok(m):   print(f"  OK  {m}")
    def err(m):  print(f"  ERR {m}")
    def info(m): print(f"      {m}")

PASS = 0
FAIL = 0

def test(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        ok(f"{name}  {detail}")
        PASS += 1
    else:
        err(f"{name}  {detail}")
        FAIL += 1


# ─────────────────────────────────────────────────────────────────────────────
# Noise model tests
# ─────────────────────────────────────────────────────────────────────────────

def test_noise_model():
    section("6 · Quantum Channel Noise Model Tests")
    from qubit_sim import Qubit
    from noise_model import (
        depolarizing_channel, bit_flip_channel, phase_flip_channel,
        amplitude_damping_channel, phase_damping_channel,
        photon_loss_channel, apply_noise, NoiseConfig,
        run_bb84_noisy, sweep_depolarizing,
        fibre_distance_to_eta, eta_to_fibre_distance,
    )

    # p=0 is identity
    q = Qubit.plus(); orig = abs(q.state[0])**2
    q = depolarizing_channel(q, 0.0)
    test("Depolarizing p=0 is identity", abs(abs(q.state[0])**2 - orig) < 1e-9)

    # Bit-flip p=1 always flips |0>
    r = bit_flip_channel(Qubit.zero(), 1.0).measure()
    test("Bit-flip p=1 flips |0>→|1>", r == 1)

    # Phase-flip leaves Z-basis |0> unchanged
    results = [phase_flip_channel(Qubit.zero(), 1.0).measure() for _ in range(10)]
    test("Phase-flip leaves Z-basis |0> unchanged", all(r == 0 for r in results))

    # Amplitude damping collapses |1> at high gamma
    highdecay = [amplitude_damping_channel(Qubit.one(), 0.99).measure() for _ in range(50)]
    test("Amplitude damping γ=0.99 collapses |1>→|0>",
         highdecay.count(0) > 40, f"zeros={highdecay.count(0)}/50")

    # |0> stable under amplitude damping
    stable = [amplitude_damping_channel(Qubit.zero(), 1.0).measure() for _ in range(20)]
    test("Amplitude damping leaves |0> stable", all(r == 0 for r in stable))

    # Photon loss: eta=0 always loses
    lost = sum(1 for _ in range(50) if photon_loss_channel(Qubit.zero(), 0.0) is None)
    test("Photon loss eta=0 always loses", lost == 50, f"lost={lost}/50")

    # Photon loss: eta=1 never loses
    lost = sum(1 for _ in range(50) if photon_loss_channel(Qubit.zero(), 1.0) is None)
    test("Photon loss eta=1 never loses", lost == 0, f"lost={lost}/50")

    # All NoiseConfig presets run without error
    for label, cfg in [("ideal", NoiseConfig.ideal()),
                       ("10km",  NoiseConfig.fibre_10km()),
                       ("50km",  NoiseConfig.fibre_50km()),
                       ("noisy", NoiseConfig.noisy_lab()),
                       ("sc",    NoiseConfig.superconducting())]:
        result = apply_noise(Qubit.plus(), cfg)
        test(f"NoiseConfig.{label} valid output", result is None or 0 <= result.probabilities[0] <= 1)

    # Noisy BB84 ideal = low QBER
    r = run_bb84_noisy(512, NoiseConfig.ideal())
    test("Noisy BB84 (ideal) QBER < 5%", r.error_rate < 0.05, f"QBER={r.error_rate:.2%}")
    test("Noisy BB84 generates 32-byte key", len(r.final_key_hex) == 64)

    # Depolarizing raises QBER — average 5 trials to beat sample variance
    qbers_d = [run_bb84_noisy(800, NoiseConfig(depolarizing_p=0.06)).error_rate for _ in range(5)]
    mean_qber_d = sum(qbers_d) / len(qbers_d)
    test("Depolarizing p=0.06 raises QBER (mean 5 trials)",
         mean_qber_d > 0.01, f"mean QBER={mean_qber_d:.2%}")

    # Fibre distance utilities
    eta = fibre_distance_to_eta(10)
    test("10km fibre eta ≈ 0.63", 0.60 < eta < 0.66, f"eta={eta:.4f}")
    dist = eta_to_fibre_distance(eta)
    test("eta→distance roundtrip ≈ 10km", abs(dist - 10) < 0.01, f"{dist:.2f}km")

    # Sweep shape
    sweep = sweep_depolarizing([0.0, 0.05, 0.10], num_qubits=400, trials=2)
    test("Depolarizing sweep returns correct shape", len(sweep.qber_values) == 3)
    test("Sweep QBER increases with p", sweep.qber_values[2] >= sweep.qber_values[0])
    info(f"Sweep table:\n{sweep.as_table()}")


# ─────────────────────────────────────────────────────────────────────────────
# Cascade tests
# ─────────────────────────────────────────────────────────────────────────────

def test_cascade():
    section("7 · Cascade Error Reconciliation Tests")
    from cascade import (cascade, reconcile_and_amplify, bb84_with_cascade,
                         sweep_cascade_vs_qber, CascadeResult)

    # Identical inputs: zero errors before and after
    bits = [random.randint(0,1) for _ in range(200)]
    r = cascade(bits, list(bits), estimated_qber=0.0)
    test("Cascade on identical bits: 0 errors before", r.errors_before == 0)
    test("Cascade on identical bits: 0 errors after",  r.errors_after  == 0)
    test("Cascade output matches alice",               r.bob_bits_out == bits)

    # Moderate QBER: should correct all errors
    alice = [random.randint(0,1) for _ in range(500)]
    bob   = [(b ^ 1) if random.random() < 0.05 else b for b in alice]
    errs_before = sum(a != b for a, b in zip(alice, bob))
    r = cascade(alice, bob, estimated_qber=0.05, num_passes=4)
    test(f"Cascade corrects 5% QBER ({errs_before} errors)",
         r.errors_after < max(1, errs_before // 4),
         f"before={r.errors_before} after={r.errors_after}")
    test("CascadeResult has parity count > 0", r.parity_bits_sent > 0)
    test("CascadeResult has binary_searches > 0", r.binary_searches > 0 or errs_before == 0)

    # High QBER: 10%
    alice = [random.randint(0,1) for _ in range(500)]
    bob   = [(b ^ 1) if random.random() < 0.10 else b for b in alice]
    errs_before = sum(a != b for a, b in zip(alice, bob))
    r2 = cascade(alice, bob, estimated_qber=0.10, num_passes=4)
    test(f"Cascade handles 10% QBER ({errs_before} errors)",
         r2.errors_after < errs_before,
         f"before={r2.errors_before} after={r2.errors_after}")

    # reconcile_and_amplify: alice_key == bob_key when errors corrected
    alice = [random.randint(0,1) for _ in range(300)]
    bob   = [(b ^ 1) if random.random() < 0.03 else b for b in alice]
    ak, bk, cr = reconcile_and_amplify(alice, bob, estimated_qber=0.03, target_bytes=32)
    test("reconcile_and_amplify returns 32-byte keys", len(ak) == 32 and len(bk) == 32)
    test("reconcile_and_amplify: keys match after correction", ak == bk,
         f"errors_after={cr.errors_after}")

    # bb84_with_cascade integration
    result = bb84_with_cascade(num_qubits=800, eavesdrop=False)
    test("bb84_with_cascade: keys match",   result["keys_match"])
    test("bb84_with_cascade: 64-char hex",  len(result["alice_key_hex"]) == 64)
    test("bb84_with_cascade: has cascade info", "cascade_result" in result)
    info(f"Cascade: errors {result['errors_before']}→{result['errors_after']}, "
         f"leakage={result['leakage_bits_per_bit']:.4f} bits/bit, "
         f"searches={result['binary_searches']}")

    # Sweep
    sweep = sweep_cascade_vs_qber([0.02, 0.05, 0.08], n_bits=300, trials=2)
    test("Cascade sweep returns 3 entries", len(sweep) == 3)
    test("Cascade correction_rate > 0 for all QBERs",
         all(s["correction_rate"] > 0 for s in sweep))


# ─────────────────────────────────────────────────────────────────────────────
# Network simulation tests
# ─────────────────────────────────────────────────────────────────────────────

def test_network_sim():
    section("8 · Network Simulation Tests (Alice↔Bob TCP)")
    from network_sim import run_network_session
    from noise_model import NoiseConfig

    # Ideal channel
    r = run_network_session(128, NoiseConfig.ideal(), verbose=False)
    test("Net session: no error",       not r.error, r.error or "OK")
    test("Net session: keys match",     r.keys_match,
         f"A={r.alice_key_hex[:8]}… B={r.bob_key_hex[:8]}…")
    test("Net session: QBER near zero", r.qber < 0.10, f"QBER={r.qber:.2%}")
    test("Net session: has duration",   r.duration_ms > 0, f"{r.duration_ms:.0f}ms")
    test("Net session: sifted > 0",     r.sifted_count > 0, f"sifted={r.sifted_count}")
    test("Net session: has logs",       len(r.alice_log) > 3 and len(r.bob_log) > 3)

    # 10km fibre — use more qubits to compensate for ~37% photon loss
    r2 = run_network_session(512, NoiseConfig.fibre_10km(), verbose=False)
    test("Net session (10km fibre): success", not r2.error, r2.error or "OK")
    # Key match is the gold standard; skip on protocol abort (insufficient bits)
    if not r2.error:
        test("Net session (10km fibre): match", r2.keys_match,
             f"A={r2.alice_key_hex[:8]}… B={r2.bob_key_hex[:8]}…")

    # Two sessions produce different keys
    r3 = run_network_session(128, verbose=False)
    r4 = run_network_session(128, verbose=False)
    test("Two sessions: different keys", r3.alice_key_hex != r4.alice_key_hex)

    # Key rate metric
    test("Net key rate > 0", r.key_rate_bpq > 0, f"bpq={r.key_rate_bpq:.4f}")


# ─────────────────────────────────────────────────────────────────────────────
# Report generation tests
# ─────────────────────────────────────────────────────────────────────────────

def test_report():
    section("9 · HTML Report Generator Tests")
    from report import (generate_report, generate_bb84_report,
                        generate_e91_report, session_data_from_bb84,
                        session_data_from_e91)
    from bb84 import run_bb84
    from e91 import run_e91

    with tempfile.TemporaryDirectory() as tmp:
        # BB84 report
        bb84_r = run_bb84(num_qubits=256)
        data   = session_data_from_bb84(bb84_r)
        path   = os.path.join(tmp, "bb84_report.html")
        out    = generate_report(data, path, include_plots=False)

        test("BB84 report file created",       os.path.isfile(out))
        test("BB84 report is non-trivial HTML",os.path.getsize(out) > 5000,
             f"size={os.path.getsize(out):,} bytes")

        html = open(out).read()
        test("BB84 report contains key hex",   bb84_r.final_key_hex[:16] in html)
        test("BB84 report contains QBER",      "QBER" in html or "qber" in html.lower())
        test("BB84 report contains protocol",  "BB84" in html)

        # E91 report
        e91_r = run_e91(num_pairs=300)
        data2  = session_data_from_e91(e91_r)
        path2  = os.path.join(tmp, "e91_report.html")
        out2   = generate_report(data2, path2, include_plots=False)

        test("E91 report file created",        os.path.isfile(out2))
        test("E91 report contains CHSH",       "CHSH" in open(out2).read())

        # One-shot report with plots
        path3 = os.path.join(tmp, "full_report.html")
        out3  = generate_bb84_report(num_qubits=256, with_cascade=True,
                                     output_path=path3, verbose=False)
        test("Full report with plots created",  os.path.isfile(out3))
        test("Full report is large (has plots)",os.path.getsize(out3) > 50_000,
             f"size={os.path.getsize(out3):,} bytes")

        html3 = open(out3).read()
        test("Full report has embedded images", "data:image/png;base64," in html3)
        test("Full report has Cascade section", "Cascade" in html3)

        info(f"Reports: {os.path.getsize(out):,}B, {os.path.getsize(out2):,}B, "
             f"{os.path.getsize(out3):,}B")


# ─────────────────────────────────────────────────────────────────────────────
# Benchmarks smoke test
# ─────────────────────────────────────────────────────────────────────────────

def test_benchmarks():
    section("10 · Benchmark Suite Smoke Tests")
    from benchmarks import bench_qubit_gates, bench_bb84, bench_aes

    gates = bench_qubit_gates(trials=3)
    test("Gate benchmarks return results", len(gates) > 0)
    test("Gate throughput > 1000/s",
         all(r.value > 1000 for r in gates if "gates" in r.unit))

    bb84s = bench_bb84(trials=2)
    test("BB84 benchmarks return results", len(bb84s) > 0)
    test("BB84 128-qubit < 10000ms",       bb84s[0].value < 10000,
         f"{bb84s[0].value:.1f}ms")

    aes = bench_aes(trials=3)
    test("AES benchmarks return results",  len(aes) > 0)
    enc = [r for r in aes if "encrypt" in r.name and "MB/s" in r.unit]
    test("AES encrypt > 1 MB/s",           all(r.value > 1 for r in enc),
         f"min={min(r.value for r in enc):.1f} MB/s")

    info("Full suite: python benchmarks.py")


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def run_all():
    test_noise_model()
    test_cascade()
    test_network_sim()
    test_report()
    test_benchmarks()

    section("Extended Test Summary")
    total = PASS + FAIL
    if FAIL == 0:
        if console:
            console.print(f"\n  [bold green]All {total} extended tests passed ✓[/]\n")
        else:
            print(f"\n  All {total} extended tests passed\n")
    else:
        if console:
            console.print(f"\n  [bold green]{PASS}[/] passed  [bold red]{FAIL}[/] failed  ({total} total)\n")
        else:
            print(f"\n  {PASS} passed / {FAIL} failed / {total} total\n")
        sys.exit(1)


if __name__ == "__main__":
    run_all()
