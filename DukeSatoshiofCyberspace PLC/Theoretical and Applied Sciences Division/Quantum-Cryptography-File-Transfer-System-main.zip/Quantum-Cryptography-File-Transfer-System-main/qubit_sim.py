"""
qubit_sim.py — Quantum Bit Simulator
======================================
Simulates single qubits and two-qubit entangled systems using NumPy.
Supports: superposition, Hadamard, Pauli-X/Y/Z, CNOT, Bell states,
          and probabilistic measurement with state collapse.
"""

import numpy as np
import random
from typing import Tuple, List


# ─────────────────────────────────────────────────────────────────────────────
# Gate matrices (2×2 and 4×4)
# ─────────────────────────────────────────────────────────────────────────────

H_GATE  = np.array([[1,  1],
                     [1, -1]], dtype=complex) / np.sqrt(2)

X_GATE  = np.array([[0, 1],
                     [1, 0]], dtype=complex)

Y_GATE  = np.array([[0, -1j],
                     [1j,  0]], dtype=complex)

Z_GATE  = np.array([[1,  0],
                     [0, -1]], dtype=complex)

CNOT_GATE = np.array([
    [1, 0, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 0, 1],
    [0, 0, 1, 0],
], dtype=complex)

I_GATE  = np.eye(2, dtype=complex)


# ─────────────────────────────────────────────────────────────────────────────
# Single Qubit
# ─────────────────────────────────────────────────────────────────────────────

class Qubit:
    """
    Represents a single qubit as a normalised 2-component complex vector:
        |ψ⟩ = α|0⟩ + β|1⟩,  |α|² + |β|² = 1
    """

    def __init__(self, alpha: complex = 1.0 + 0j, beta: complex = 0.0 + 0j):
        raw = np.array([alpha, beta], dtype=complex)
        norm = np.linalg.norm(raw)
        if norm == 0:
            raise ValueError("Qubit state vector cannot be zero.")
        self.state = raw / norm

    # ── factory helpers ──────────────────────────────────────────────────────

    @classmethod
    def zero(cls) -> "Qubit":
        """Computational basis state |0⟩."""
        return cls(1.0, 0.0)

    @classmethod
    def one(cls) -> "Qubit":
        """Computational basis state |1⟩."""
        return cls(0.0, 1.0)

    @classmethod
    def plus(cls) -> "Qubit":
        """Hadamard basis |+⟩ = (|0⟩ + |1⟩)/√2."""
        return cls(1 / np.sqrt(2), 1 / np.sqrt(2))

    @classmethod
    def minus(cls) -> "Qubit":
        """Hadamard basis |−⟩ = (|0⟩ − |1⟩)/√2."""
        return cls(1 / np.sqrt(2), -1 / np.sqrt(2))

    @classmethod
    def from_bit(cls, bit: int, basis: str = "Z") -> "Qubit":
        """
        Encode a classical bit into a qubit.

        Parameters
        ----------
        bit   : 0 or 1
        basis : 'Z' (rectilinear) or 'X' (diagonal)
        """
        if basis == "Z":
            return cls.zero() if bit == 0 else cls.one()
        elif basis == "X":
            return cls.plus() if bit == 0 else cls.minus()
        else:
            raise ValueError(f"Unknown basis '{basis}'. Use 'Z' or 'X'.")

    # ── gate operations (in-place, return self for chaining) ─────────────────

    def apply(self, gate: np.ndarray) -> "Qubit":
        """Apply an arbitrary 2×2 unitary gate."""
        self.state = gate @ self.state
        return self

    def hadamard(self) -> "Qubit":
        """Apply Hadamard gate: rotates between Z and X bases."""
        return self.apply(H_GATE)

    def pauli_x(self) -> "Qubit":
        """Apply Pauli-X (NOT) gate: flips |0⟩↔|1⟩."""
        return self.apply(X_GATE)

    def pauli_y(self) -> "Qubit":
        """Apply Pauli-Y gate."""
        return self.apply(Y_GATE)

    def pauli_z(self) -> "Qubit":
        """Apply Pauli-Z gate: phase flip on |1⟩."""
        return self.apply(Z_GATE)

    # ── measurement ──────────────────────────────────────────────────────────

    def measure(self) -> int:
        """
        Measure the qubit in the computational (Z) basis.
        Collapses the state probabilistically: P(0) = |α|², P(1) = |β|².

        Returns
        -------
        0 or 1
        """
        prob_zero = float(np.abs(self.state[0]) ** 2)
        result = 0 if random.random() < prob_zero else 1
        # Collapse
        self.state = np.array([1.0, 0.0], dtype=complex) if result == 0 \
                     else np.array([0.0, 1.0], dtype=complex)
        return result

    def measure_in_basis(self, basis: str) -> int:
        """
        Measure in Z or X basis.
        For X-basis measurement, apply Hadamard first then measure.
        """
        if basis == "X":
            self.hadamard()
        return self.measure()

    # ── display ──────────────────────────────────────────────────────────────

    @property
    def probabilities(self) -> Tuple[float, float]:
        """Return (P(0), P(1))."""
        return (float(np.abs(self.state[0]) ** 2),
                float(np.abs(self.state[1]) ** 2))

    def bloch_angles(self) -> Tuple[float, float]:
        """Return (θ, φ) polar angles on the Bloch sphere (radians)."""
        alpha, beta = self.state
        theta = 2 * np.arccos(np.clip(np.abs(alpha), 0, 1))
        phi   = float(np.angle(beta) - np.angle(alpha))
        return float(theta), float(phi)

    def __repr__(self) -> str:
        a, b = self.state
        return f"({a.real:+.4f}{a.imag:+.4f}j)|0⟩ + ({b.real:+.4f}{b.imag:+.4f}j)|1⟩"


# ─────────────────────────────────────────────────────────────────────────────
# Two-Qubit Entangled System
# ─────────────────────────────────────────────────────────────────────────────

class TwoQubitSystem:
    """
    Represents a two-qubit system as a 4-component complex vector in the basis:
        { |00⟩, |01⟩, |10⟩, |11⟩ }  (index = 2*q0 + q1)
    """

    def __init__(self, state: np.ndarray = None):
        if state is None:
            # Default: |00⟩
            self.state = np.array([1, 0, 0, 0], dtype=complex)
        else:
            norm = np.linalg.norm(state)
            self.state = np.array(state, dtype=complex) / norm

    # ── Bell states ──────────────────────────────────────────────────────────

    @classmethod
    def bell_phi_plus(cls) -> "TwoQubitSystem":
        """Φ⁺ = (|00⟩ + |11⟩)/√2  — maximally entangled."""
        return cls([1, 0, 0, 1])

    @classmethod
    def bell_phi_minus(cls) -> "TwoQubitSystem":
        """Φ⁻ = (|00⟩ − |11⟩)/√2."""
        return cls([1, 0, 0, -1])

    @classmethod
    def bell_psi_plus(cls) -> "TwoQubitSystem":
        """Ψ⁺ = (|01⟩ + |10⟩)/√2."""
        return cls([0, 1, 1, 0])

    @classmethod
    def bell_psi_minus(cls) -> "TwoQubitSystem":
        """Ψ⁻ = (|01⟩ − |10⟩)/√2  — singlet state."""
        return cls([0, 1, -1, 0])

    @classmethod
    def create_bell_pair(cls) -> "TwoQubitSystem":
        """
        Create Φ⁺ from |00⟩ by applying H⊗I then CNOT.
        This mirrors the physical circuit for generating entanglement.
        """
        sys = cls()               # |00⟩
        sys.hadamard_first()      # (|0⟩+|1⟩)/√2 ⊗ |0⟩
        sys.cnot()                # Φ⁺
        return sys

    # ── gate operations ──────────────────────────────────────────────────────

    def apply2(self, gate: np.ndarray) -> "TwoQubitSystem":
        """Apply an arbitrary 4×4 gate."""
        self.state = gate @ self.state
        return self

    def hadamard_first(self) -> "TwoQubitSystem":
        """Apply H to qubit 0 (H ⊗ I)."""
        return self.apply2(np.kron(H_GATE, I_GATE))

    def hadamard_second(self) -> "TwoQubitSystem":
        """Apply H to qubit 1 (I ⊗ H)."""
        return self.apply2(np.kron(I_GATE, H_GATE))

    def cnot(self) -> "TwoQubitSystem":
        """Apply CNOT: qubit 0 is control, qubit 1 is target."""
        return self.apply2(CNOT_GATE)

    # ── measurement ──────────────────────────────────────────────────────────

    def measure_both(self) -> Tuple[int, int]:
        """
        Measure both qubits simultaneously.
        Returns (q0_result, q1_result) and collapses to that basis state.
        """
        probs = np.abs(self.state) ** 2
        # Ensure probabilities sum to 1 (guard against float drift)
        probs = probs / probs.sum()
        idx = int(np.random.choice(4, p=probs))
        q0 = (idx >> 1) & 1
        q1 = idx & 1
        # Collapse
        collapsed = np.zeros(4, dtype=complex)
        collapsed[idx] = 1.0
        self.state = collapsed
        return q0, q1

    def measure_qubit0(self) -> int:
        """Measure only qubit 0; collapse state accordingly."""
        prob_q0_is_0 = float(np.abs(self.state[0]) ** 2 + np.abs(self.state[1]) ** 2)
        result = 0 if random.random() < prob_q0_is_0 else 1
        new = np.zeros(4, dtype=complex)
        if result == 0:
            new[0], new[1] = self.state[0], self.state[1]
        else:
            new[2], new[3] = self.state[2], self.state[3]
        norm = np.linalg.norm(new)
        self.state = new / norm if norm > 0 else new
        return result

    def measure_qubit1(self) -> int:
        """Measure only qubit 1; collapse state accordingly."""
        prob_q1_is_0 = float(np.abs(self.state[0]) ** 2 + np.abs(self.state[2]) ** 2)
        result = 0 if random.random() < prob_q1_is_0 else 1
        new = np.zeros(4, dtype=complex)
        if result == 0:
            new[0], new[2] = self.state[0], self.state[2]
        else:
            new[1], new[3] = self.state[1], self.state[3]
        norm = np.linalg.norm(new)
        self.state = new / norm if norm > 0 else new
        return result

    def entanglement_entropy(self) -> float:
        """
        Compute von Neumann entropy of qubit 0's reduced density matrix.
        Ranges from 0 (separable) to log(2) ≈ 0.693 (maximally entangled).
        """
        rho_full = np.outer(self.state, self.state.conj())
        # Reshape to (2,2,2,2) then trace out qubit 1
        rho_2x2x2x2 = rho_full.reshape(2, 2, 2, 2)
        rho_reduced = np.einsum('ijik->jk', rho_2x2x2x2)
        eigenvalues = np.linalg.eigvalsh(rho_reduced)
        eigenvalues = eigenvalues[eigenvalues > 1e-12]  # drop zeros
        return float(-np.sum(eigenvalues * np.log(eigenvalues)))

    def __repr__(self) -> str:
        labels = ["|00⟩", "|01⟩", "|10⟩", "|11⟩"]
        parts = []
        for amp, lbl in zip(self.state, labels):
            if abs(amp) > 1e-6:
                parts.append(f"({amp.real:+.3f}{amp.imag:+.3f}j){lbl}")
        return " + ".join(parts) if parts else "|0⟩"


# ─────────────────────────────────────────────────────────────────────────────
# Qubit register  (n qubits, tensor product state)
# ─────────────────────────────────────────────────────────────────────────────

class QubitRegister:
    """
    An n-qubit register stored as a 2^n complex vector.
    Useful for small demos (n ≤ 12 before memory becomes impractical).
    """

    def __init__(self, n: int):
        if n < 1 or n > 16:
            raise ValueError("Register size must be between 1 and 16.")
        self.n = n
        self.state = np.zeros(2 ** n, dtype=complex)
        self.state[0] = 1.0  # |00…0⟩

    def apply_single(self, gate: np.ndarray, qubit: int) -> "QubitRegister":
        """Apply a single-qubit gate to qubit `qubit` (0-indexed)."""
        ops = [I_GATE] * self.n
        ops[qubit] = gate
        full_gate = ops[0]
        for op in ops[1:]:
            full_gate = np.kron(full_gate, op)
        self.state = full_gate @ self.state
        return self

    def measure_all(self) -> List[int]:
        """Measure all qubits; return list of 0/1 results."""
        probs = np.abs(self.state) ** 2
        probs /= probs.sum()
        idx = int(np.random.choice(len(self.state), p=probs))
        results = [(idx >> (self.n - 1 - i)) & 1 for i in range(self.n)]
        collapsed = np.zeros(len(self.state), dtype=complex)
        collapsed[idx] = 1.0
        self.state = collapsed
        return results

    def __repr__(self) -> str:
        dim = 2 ** self.n
        parts = []
        for i, amp in enumerate(self.state):
            if abs(amp) > 1e-6:
                bits = format(i, f"0{self.n}b")
                parts.append(f"({amp.real:+.3f})|{bits}⟩")
        return " + ".join(parts[:8]) + ("  …" if len(parts) > 8 else "")
