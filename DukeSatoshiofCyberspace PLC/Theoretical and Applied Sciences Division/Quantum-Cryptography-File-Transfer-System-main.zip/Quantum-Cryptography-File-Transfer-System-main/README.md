# Quantum Cryptography File Transfer System

A complete, production-quality Python implementation of Quantum Key Distribution (QKD)
combined with AES-256-GCM authenticated file encryption — running entirely on classical
hardware via NumPy qubit simulation.

**105 tests pass. Zero dependencies on real quantum hardware.**

---

## Architecture

```
quantum_crypto/
├── qubit_sim.py         Qubit & two-qubit simulator (gates, Bell states, entropy)
├── bb84.py              BB84 QKD: sifting · QBER · eavesdrop detection · privacy amp
├── e91.py               E91 QKD: Bell pairs · CHSH parameter · Bell inequality
├── cascade.py           Cascade error reconciliation (4-pass interactive parity)
├── noise_model.py       Quantum channel noise: depolarizing · loss · T₁/T₂
├── network_sim.py       Alice↔Bob TCP socket session with reconciliation
├── post_processing.py   Full post-processing pipeline + security bounds
├── crypto.py            AES-256-GCM file encryption (HKDF, integrity, .qcrypt format)
├── key_manager.py       Scrypt-encrypted key vault (.qvault format)
├── qr_share.py          QR code key export/import with optional passphrase protection
├── bloch_viz.py         Matplotlib: Bloch sphere · BB84 strip · CHSH chart
├── report.py            HTML session security report generator
├── visualizer.py        Rich-based terminal display engine
├── benchmarks.py        Full performance benchmark suite
├── cli.py               5-command CLI (generate-key · encrypt · decrypt · sim · inspect)
├── gui.py               5-tab Tkinter GUI application
├── interactive_demo.py  10-section guided terminal walkthrough
├── demo.py              45-test core self-test suite
├── demo_extended.py     60-test extended suite (noise · network · cascade · report)
├── requirements.txt
└── pyproject.toml       Installable package metadata
```

---

## Quick Start

```bash
# 1. Install
pip install -r requirements.txt

# 2. Run the interactive demo (10 guided sections)
python interactive_demo.py

# 3. Generate a 256-bit quantum key (BB84)
python cli.py generate-key --protocol bb84 --qubits 512 --save-key my.hex

# 4. Encrypt a file
python cli.py encrypt-file secret.pdf --key my.hex

# 5. Decrypt it
python cli.py decrypt-file secret.pdf.qcrypt --key my.hex --verify secret.pdf

# 6. Launch the GUI
python gui.py

# 7. Run all 105 tests
python demo.py && python demo_extended.py
```

---

## Protocols

### BB84 (Bennett & Brassard, 1984)
The first QKD protocol. Uses single photons prepared in four states:

| Basis | Bit 0 | Bit 1 |
|-------|-------|-------|
| Z (rectilinear) | \|0⟩ | \|1⟩ |
| X (diagonal)    | \|+⟩ | \|−⟩ |

Alice encodes random bits → Bob measures in random bases → public basis comparison → sifted key → QBER estimation → Cascade error correction → privacy amplification.

**Security**: eavesdropper Eve must measure qubits before they reach Bob. Any measurement collapses the state, introducing ~25% QBER detectable by Alice and Bob.

```bash
python cli.py generate-key --protocol bb84 --qubits 512
python cli.py generate-key --protocol bb84 --qubits 512 --eavesdrop  # Eve detection
```

### E91 (Ekert, 1991)
Uses entangled Bell pairs. Security guaranteed by Bell's theorem — any eavesdropper disturbs entanglement, reducing the CHSH parameter S below the quantum maximum.

| Condition | CHSH S | Meaning |
|-----------|--------|---------|
| Classical | S ≤ 2.000 | Local hidden variables |
| Quantum (no Eve) | S ≈ 2.828 = 2√2 | Entanglement confirmed |
| Eve present | S ≤ 2.0 | Entanglement destroyed |

```bash
python cli.py generate-key --protocol e91 --pairs 600
python cli.py simulate --demo e91
```

### Cascade Error Reconciliation
Interactive parity-based error correction over the public authenticated channel.

- Block size k₁ = ⌈0.73 / QBER⌉, doubled each pass
- 4 passes correct >99% of errors at QBER ≤ 10%
- Information leaked: ~1.16 × H_bin(QBER) bits per key bit
- Accounted for in privacy amplification

### Privacy Amplification
HKDF-SHA256 compresses the reconciled key, squeezing out Eve's partial information. The Leftover Hash Lemma guarantees ε-security:

```
Key bits = n_sifted × [1 − H(e) − 1.16 × H(e)]
         = n_sifted × (1 − 2.16 × H_bin(QBER))
```

Maximum tolerable QBER for positive key rate: **≈ 8%** (Cascade) / **≈ 11%** (ideal reconciliation).

---

## File Encryption

AES-256-GCM provides authenticated encryption — any tampering is detected.

**`.qcrypt` file format:**
```
┌─────────────────────────────────────────┐
│  Magic      │ 8B  │ "QCRYPT\x01\x00"   │
│  Nonce      │ 12B │ random per file     │
│  Auth tag   │ 16B │ GCM integrity tag   │
│  Length     │ 8B  │ plaintext size      │
│  Ciphertext │ var │ AES-256-GCM output  │
└─────────────────────────────────────────┘
Total header: 44 bytes overhead
```

Keys are never written to disk unencrypted unless `--save-key` is used explicitly.

---

## Noise Models

Simulate realistic quantum channel imperfections:

| Model | Description | Physical source |
|-------|-------------|-----------------|
| Depolarizing | Random X/Y/Z error with prob p | Photon scattering |
| Bit-flip | Random NOT gate | Fibre birefringence |
| Phase-flip | Random Z gate | Atmospheric turbulence |
| Amplitude damping | \|1⟩→\|0⟩ with prob γ | T₁ relaxation (SC qubits) |
| Phase damping | Dephasing without energy loss | T₂ decoherence |
| Photon loss | Qubit lost with prob 1−η | Fibre attenuation (0.2 dB/km) |

```python
from noise_model import NoiseConfig, run_bb84_noisy

# Ideal channel
r = run_bb84_noisy(512, NoiseConfig.ideal())

# 10 km single-mode fibre (~37% photon loss + 0.5% depolarizing)
r = run_bb84_noisy(512, NoiseConfig.fibre_10km())

# 50 km fibre (~90% photon loss)
r = run_bb84_noisy(1200, NoiseConfig.fibre_50km())

# Custom
cfg = NoiseConfig(depolarizing_p=0.03, photon_loss_eta=0.8, amplitude_damping=0.005)
r = run_bb84_noisy(512, cfg)
```

---

## Key Vault

Stores named keys in an Scrypt-encrypted `.qvault` file. Keys never touch disk in plaintext.

```python
from key_manager import KeyVault, vault_from_bb84
from bb84 import run_bb84

result = run_bb84(num_qubits=512)
entry  = vault_from_bb84(result, name="alice_session_1")

vault = KeyVault("keys.qvault")
vault.create("my_password")
vault.add_key(entry)
vault.save()
vault.lock()

# Later:
vault.unlock("my_password")
key = vault.get("alice_session_1")
print(key.key_hex)
```

---

## Network Simulation

Runs Alice and Bob as real Python threads communicating over localhost TCP sockets:

```python
from network_sim import run_network_session
from noise_model import NoiseConfig

# Ideal channel
r = run_network_session(256, NoiseConfig.ideal())
print(r.keys_match)    # True
print(r.alice_key_hex) # 64-char hex

# 10 km fibre with noise
r = run_network_session(512, NoiseConfig.fibre_10km())
```

**Protocol message sequence:**
```
Alice                          Bob
  │── quantum channel ──────────│  (qubit states)
  │── bases (public) ──────────→│
  │←─ bases (public) ──────────│
  │── sifted sample ──────────→│  (QBER estimation)
  │←─ qber_estimate ───────────│
  │── reconcile (bits) ───────→│  (public channel, auth'd)
  │── done (key_hash) ────────→│
  │←─ done (key_hash) ─────────│  (verification)
```

---

## CLI Reference

```bash
# Key generation
python cli.py generate-key --protocol bb84 --qubits 512 --save-key key.hex
python cli.py generate-key --protocol e91  --pairs 600 --eavesdrop
python cli.py generate-key --protocol bb84 --qubits 1024 --json

# Encryption
python cli.py encrypt-file document.pdf --key key.hex --output document.qcrypt
python cli.py encrypt-file document.pdf --key <64-hex-chars>

# Decryption
python cli.py decrypt-file document.qcrypt --key key.hex
python cli.py decrypt-file document.qcrypt --key key.hex --verify document.pdf

# Simulations
python cli.py simulate --demo gates   # Qubit gate effects on Bloch sphere
python cli.py simulate --demo bb84    # BB84 with/without eavesdropper
python cli.py simulate --demo e91     # E91 Bell inequality test
python cli.py simulate --demo bell    # Bell state correlation measurements
python cli.py simulate --demo qubit   # Single qubit measurement statistics

# File inspection (no key needed)
python cli.py inspect document.qcrypt
python cli.py inspect document.qcrypt --json
```

---

## GUI

Launch the 5-tab Tkinter GUI:

```bash
python gui.py
```

| Tab | Function |
|-----|----------|
| ⚡ Key Gen | BB84/E91 key generation with live protocol log |
| 🔒 Encrypt | File encryption with key browser |
| 🔓 Decrypt | File decryption with integrity verification |
| 🗄 Vault | Password-protected key storage |
| 📊 Visualise | Bloch sphere, BB84 strip, CHSH chart, key distribution |

---

## Benchmarks

```bash
# Full suite (~30 seconds)
python benchmarks.py

# Without slow network benchmarks
python benchmarks.py --no-network

# Save chart
python benchmarks.py --save-chart benchmark_results.png
```

**Typical performance (Python 3.12, modern CPU):**

| Operation | Performance |
|-----------|-------------|
| Single qubit gate | ~190,000 gates/s |
| Bell pair creation | ~60,000 pairs/s |
| BB84 (512 qubits) | ~4 ms |
| E91 (800 pairs) | ~5 ms |
| AES-256-GCM encrypt | ~900 MB/s (1 MiB+) |
| Network session (ideal) | ~300 ms |
| Vault unlock (Scrypt) | ~100 ms |

---

## Security Notes

1. **Keys never written unencrypted** — use `--save-key` only for demos
2. **GCM authentication tag** — any tampering detected before plaintext output
3. **Privacy amplification** — HKDF-SHA256 removes Eve's partial information
4. **Cascade leakage** — accounted for in key length calculation
5. **QBER threshold 11%** — above this, protocol aborts (Eve detected)
6. **Classical channel** — authenticated but not secret (correct QKD model)
7. **Vault encryption** — Scrypt N=32768 + AES-256-GCM

This is a **simulation** of quantum cryptography. Production QKD requires real photon sources, single-photon detectors, and a quantum channel (optical fibre or free-space). The security proofs hold for the physical protocol; the classical simulation faithfully implements the information-theoretic post-processing.

---

## Test Suite

```bash
python demo.py              # 45 core tests
python demo_extended.py     # 60 extended tests (noise, cascade, network, report)
# Total: 105 tests, all passing
```

---

## References

- Bennett & Brassard (1984). "Quantum cryptography: Public key distribution and coin tossing." *Proc. IEEE ISIT*.
- Ekert (1991). "Quantum cryptography based on Bell's theorem." *Physical Review Letters*, 67(6), 661.
- Brassard & Salvail (1993). "Secret-Key Reconciliation by Public Discussion." *Eurocrypt 1993*.
- Gisin et al. (2002). "Quantum cryptography." *Reviews of Modern Physics*, 74(1), 145.
- Nielsen & Chuang (2000). *Quantum Computation and Quantum Information*. Cambridge.
- Shor & Preskill (2000). "Simple proof of security of the BB84 quantum key distribution protocol." *Physical Review Letters*, 85(2), 441.
