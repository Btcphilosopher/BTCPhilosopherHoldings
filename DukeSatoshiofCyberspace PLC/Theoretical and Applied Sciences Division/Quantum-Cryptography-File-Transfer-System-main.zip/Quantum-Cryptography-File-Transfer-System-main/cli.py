"""
cli.py — Quantum Crypto File Transfer System — CLI
====================================================
Commands
--------
  generate-key   Run BB84 or E91 to produce a quantum-derived AES-256 key
  encrypt-file   Encrypt a file with the quantum key
  decrypt-file   Decrypt a .qcrypt file
  simulate       Interactive qubit / gate demonstration
  inspect        Show metadata of a .qcrypt file without decrypting

Usage examples
--------------
  python cli.py generate-key --protocol bb84 --qubits 1024
  python cli.py generate-key --protocol e91  --pairs 800 --eavesdrop
  python cli.py encrypt-file secret.pdf --key <hex>
  python cli.py decrypt-file secret.pdf.qcrypt --key <hex> --out recovered.pdf
  python cli.py simulate --demo gates
  python cli.py simulate --demo bb84
  python cli.py simulate --demo e91
  python cli.py simulate --demo bell
  python cli.py inspect encrypted.qcrypt
"""

import argparse
import sys
import os
import time
import json
import traceback

# ── Optional Rich imports ─────────────────────────────────────────────────────
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.rule import Rule
    from rich import box
    RICH = True
    console = Console()
except ImportError:
    RICH = False
    console = None

# ── Project modules ───────────────────────────────────────────────────────────
from bb84 import run_bb84, key_bytes_from_result
from e91 import run_e91, key_bytes_from_e91
from crypto import (
    encrypt_file, decrypt_file,
    validate_key_strength, inspect_qcrypt_header,
    verify_roundtrip, compute_file_hash,
)
from visualizer import (
    cprint, show_bb84_summary, show_e91_summary,
    show_key_hex, demo_gates, show_qubit_state,
    show_two_qubit_state,
)


# ─────────────────────────────────────────────────────────────────────────────
# Banner
# ─────────────────────────────────────────────────────────────────────────────

BANNER = r"""
  ██████  ██████  ██   ██    ██████ ██████  ██    ██ ██████  ████████  ██████
 ██    ██ ██   ██ ██  ██    ██      ██   ██  ██  ██  ██   ██    ██    ██    ██
 ██    ██ ██████  █████     ██      ██████    ████   ██████     ██    ██    ██
 ██ ▄▄ ██ ██      ██  ██    ██      ██   ██    ██    ██         ██    ██    ██
  ██████  ██      ██   ██    ██████ ██   ██    ██    ██         ██     ██████
     ▀▀
         Quantum Key Distribution + AES-256-GCM File Encryption
         BB84 · E91 · Qubit Simulation · Eavesdropping Detection
"""


def print_banner():
    if RICH and console:
        console.print(BANNER, style="bold cyan")
        console.print(Rule(style="cyan"))
    else:
        print(BANNER)
        print("=" * 70)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _log(msg: str, style: str = ""):
    cprint(msg, style)


def _success(msg: str):
    _log(f"[bold green]✓[/] {msg}")


def _warn(msg: str):
    _log(f"[bold yellow]⚠[/]  {msg}")


def _error(msg: str):
    _log(f"[bold red]✗[/] {msg}", "red")


def _section(title: str):
    if RICH and console:
        console.print(Rule(f"[bold]{title}[/]", style="cyan"))
    else:
        print(f"\n{'─'*60}\n  {title}\n{'─'*60}")


def _save_key(key_hex: str, path: str = "quantum_key.hex"):
    """
    Save key hex to a file (for convenience in demos).
    In production, keys should be kept only in memory.
    """
    with open(path, "w") as f:
        f.write(key_hex)
    _warn(f"Key saved to [yellow]{path}[/] — delete after use!")


def _load_key(key_arg: str) -> str:
    """
    Accept a key either as a hex string directly or as a path to a .hex file.
    """
    if os.path.isfile(key_arg):
        with open(key_arg) as f:
            return f.read().strip()
    # Validate it looks like hex
    try:
        bytes.fromhex(key_arg)
        return key_arg
    except ValueError:
        raise ValueError(f"'{key_arg}' is neither a valid hex string nor a file path.")


# ─────────────────────────────────────────────────────────────────────────────
# Command: generate-key
# ─────────────────────────────────────────────────────────────────────────────

def cmd_generate_key(args):
    _section("Quantum Key Generation")

    protocol = args.protocol.lower()
    eavesdrop = args.eavesdrop
    key_bytes_target = 32  # AES-256 = 32 bytes

    messages = []

    def on_message(msg: str):
        messages.append(msg)
        _log(f"  {msg}")

    t0 = time.perf_counter()

    try:
        if protocol == "bb84":
            num_qubits = args.qubits
            _log(f"\n[bold]Protocol:[/] BB84  |  Qubits: {num_qubits}  |"
                 f"  Eavesdrop: {'[red]YES[/]' if eavesdrop else '[green]No[/]'}\n")

            result = run_bb84(
                num_qubits=num_qubits,
                eavesdrop=eavesdrop,
                target_key_bytes=key_bytes_target,
                verbose_callback=on_message,
            )

            elapsed = time.perf_counter() - t0

            _section("BB84 Session Details")
            show_bb84_summary(result, max_show=args.show_qubits)

            key_hex = result.final_key_hex

        elif protocol == "e91":
            num_pairs = args.pairs
            _log(f"\n[bold]Protocol:[/] E91  |  Pairs: {num_pairs}  |"
                 f"  Eavesdrop: {'[red]YES[/]' if eavesdrop else '[green]No[/]'}\n")

            result = run_e91(
                num_pairs=num_pairs,
                eavesdrop=eavesdrop,
                target_key_bytes=key_bytes_target,
                verbose_callback=on_message,
            )

            elapsed = time.perf_counter() - t0

            _section("E91 Session Details")
            show_e91_summary(result)

            key_hex = result.final_key_hex

        else:
            _error(f"Unknown protocol '{protocol}'. Choose 'bb84' or 'e91'.")
            sys.exit(1)

    except RuntimeError as exc:
        _error(str(exc))
        if "ABORT" in str(exc) or "eavesdrop" in str(exc).lower():
            _warn("Key exchange aborted — eavesdropping detected. No key generated.")
        sys.exit(1)

    # ── Key quality ───────────────────────────────────────────────────────────
    _section("Key Quality Assessment")
    quality = validate_key_strength(key_hex)

    if RICH and console:
        from rich.table import Table
        t = Table(box=box.SIMPLE, show_header=False)
        t.add_column("Metric", style="bold")
        t.add_column("Value")
        for k, v in quality.items():
            t.add_row(str(k).replace("_", " ").title(), str(v))
        console.print(t)
    else:
        for k, v in quality.items():
            print(f"  {k}: {v}")

    show_key_hex(key_hex)

    _log(f"\n  [bold]Generation time:[/] {elapsed*1000:.1f} ms")

    # ── Save key? ─────────────────────────────────────────────────────────────
    if args.save_key:
        _save_key(key_hex, args.save_key)

    if args.json:
        print(json.dumps({"key_hex": key_hex, "quality": quality}, indent=2))
    else:
        _log(f"\n[bold green]Key:[/] [yellow]{key_hex}[/]")

    _success("Key generation complete.")
    return key_hex


# ─────────────────────────────────────────────────────────────────────────────
# Command: encrypt-file
# ─────────────────────────────────────────────────────────────────────────────

def cmd_encrypt_file(args):
    _section("File Encryption (AES-256-GCM)")

    input_path  = args.input
    output_path = args.output or (input_path + ".qcrypt")
    key_hex     = _load_key(args.key)

    if not os.path.isfile(input_path):
        _error(f"File not found: {input_path}")
        sys.exit(1)

    input_size = os.path.getsize(input_path)
    _log(f"  Input:    [cyan]{input_path}[/]  ({input_size:,} bytes)")
    _log(f"  Output:   [cyan]{output_path}[/]")
    _log(f"  Key:      {key_hex[:16]}…{key_hex[-8:]}")
    _log(f"  Cipher:   AES-256-GCM")

    prog_bar = [0]
    def progress(done: int, total: int):
        if total > 0:
            pct = done / total * 100
            if RICH and console:
                pass  # Rich progress handled inline
            else:
                print(f"\r  Progress: {pct:.1f}%", end="", flush=True)

    t0 = time.perf_counter()
    try:
        meta = encrypt_file(input_path, output_path, key_hex, progress_cb=progress)
    except Exception as exc:
        _error(f"Encryption failed: {exc}")
        sys.exit(1)

    elapsed = time.perf_counter() - t0

    print()  # newline after progress
    _success(f"Encrypted to [cyan]{output_path}[/]")

    if RICH and console:
        from rich.table import Table
        t = Table(box=box.SIMPLE, show_header=False, title="Encryption Metadata")
        t.add_column("Field", style="bold")
        t.add_column("Value")
        t.add_row("Input size",      f"{meta['input_size']:,} bytes")
        t.add_row("Output size",     f"{meta['output_size']:,} bytes")
        t.add_row("Overhead",        f"{meta['overhead_bytes']} bytes (header)")
        t.add_row("Nonce",           meta['nonce_hex'])
        t.add_row("Auth tag",        meta['integrity_tag_hex'])
        t.add_row("Elapsed",         f"{elapsed*1000:.2f} ms")
        console.print(t)
    else:
        print(f"  Input size:  {meta['input_size']:,} bytes")
        print(f"  Output size: {meta['output_size']:,} bytes")
        print(f"  Nonce:       {meta['nonce_hex']}")
        print(f"  Auth tag:    {meta['integrity_tag_hex']}")
        print(f"  Elapsed:     {elapsed*1000:.2f} ms")

    # ── File hash for verification ────────────────────────────────────────────
    orig_hash = compute_file_hash(input_path)
    _log(f"  [bold]Original SHA-256:[/] {orig_hash}")
    _log(f"  [dim](Store this hash to verify after decryption)[/]")

    if args.json:
        print(json.dumps({**meta, "original_sha256": orig_hash, "elapsed_ms": elapsed*1000}))


# ─────────────────────────────────────────────────────────────────────────────
# Command: decrypt-file
# ─────────────────────────────────────────────────────────────────────────────

def cmd_decrypt_file(args):
    _section("File Decryption (AES-256-GCM)")

    input_path  = args.input
    output_path = args.output
    key_hex     = _load_key(args.key)

    # Auto-derive output path by stripping .qcrypt
    if not output_path:
        if input_path.endswith(".qcrypt"):
            output_path = input_path[:-7]
        else:
            output_path = input_path + ".decrypted"

    if not os.path.isfile(input_path):
        _error(f"Encrypted file not found: {input_path}")
        sys.exit(1)

    _log(f"  Input:  [cyan]{input_path}[/]")
    _log(f"  Output: [cyan]{output_path}[/]")
    _log(f"  Key:    {key_hex[:16]}…{key_hex[-8:]}")

    t0 = time.perf_counter()
    try:
        meta = decrypt_file(input_path, output_path, key_hex)
    except Exception as exc:
        _error(f"Decryption failed: {exc}")
        if "Authentication" in str(exc) or "InvalidTag" in str(exc.__class__.__name__):
            _error("GCM authentication tag mismatch — wrong key or file tampered!")
        sys.exit(1)

    elapsed = time.perf_counter() - t0

    _success(f"Decrypted to [cyan]{output_path}[/]")
    _log(f"  [bold]Plaintext size:[/]  {meta['plaintext_size']:,} bytes")
    _log(f"  [bold]GCM integrity:[/]   "
         f"{'[green]VERIFIED ✓[/]' if meta['integrity_verified'] else '[red]FAILED ✗[/]'}")
    _log(f"  [bold]Elapsed:[/]         {elapsed*1000:.2f} ms")

    # Optional: verify against original
    if args.verify and os.path.isfile(args.verify):
        match = verify_roundtrip(args.verify, output_path)
        if match:
            _success(f"File is [green]bit-for-bit identical[/] to original [cyan]{args.verify}[/]")
        else:
            _error(f"File differs from [cyan]{args.verify}[/] — something went wrong!")
        if args.json:
            print(json.dumps({**meta, "elapsed_ms": elapsed*1000, "roundtrip_match": match}))
    elif args.json:
        print(json.dumps({**meta, "elapsed_ms": elapsed*1000}))


# ─────────────────────────────────────────────────────────────────────────────
# Command: simulate
# ─────────────────────────────────────────────────────────────────────────────

def cmd_simulate(args):
    demo = args.demo.lower()

    if demo == "gates":
        _section("Gate Demonstration")
        demo_gates()

    elif demo == "bb84":
        _section("BB84 Key Distribution Simulation")
        _log("\n[dim]Simulating BB84 with 64 qubits (small demo)…[/]\n")

        result = run_bb84(num_qubits=64, eavesdrop=False,
                          verbose_callback=lambda m: _log(f"  {m}"))
        show_bb84_summary(result, max_show=20)

        _log("\n[bold yellow]Now with Eve eavesdropping:[/]\n")
        try:
            result_eve = run_bb84(num_qubits=256, eavesdrop=True,
                                  verbose_callback=lambda m: _log(f"  {m}"))
            show_bb84_summary(result_eve, max_show=10)
        except RuntimeError as e:
            _warn(f"Protocol aborted: {e}")

    elif demo == "e91":
        _section("E91 Entanglement-Based QKD Simulation")

        _log("\n[dim]Without eavesdropping:[/]\n")
        result = run_e91(num_pairs=300, eavesdrop=False,
                         verbose_callback=lambda m: _log(f"  {m}"))
        show_e91_summary(result)

        _log("\n[bold yellow]With Eve intercepting entangled qubits:[/]\n")
        result_eve = run_e91(num_pairs=300, eavesdrop=True,
                             verbose_callback=lambda m: _log(f"  {m}"))
        show_e91_summary(result_eve)

    elif demo == "bell":
        _section("Bell State & Entanglement Demo")
        from qubit_sim import TwoQubitSystem
        from visualizer import show_two_qubit_state

        for name, state in [
            ("Φ⁺ = (|00⟩+|11⟩)/√2", TwoQubitSystem.bell_phi_plus()),
            ("Φ⁻ = (|00⟩−|11⟩)/√2", TwoQubitSystem.bell_phi_minus()),
            ("Ψ⁺ = (|01⟩+|10⟩)/√2", TwoQubitSystem.bell_psi_plus()),
            ("Created via H+CNOT",    TwoQubitSystem.create_bell_pair()),
        ]:
            show_two_qubit_state(state, name)
            _log(f"  Measuring 3 times:")
            for _ in range(3):
                fresh = TwoQubitSystem.bell_phi_plus()
                q0, q1 = fresh.measure_both()
                _log(f"    A={q0}, B={q1}  {'[green]correlated[/]' if q0==q1 else '[red]anti-correlated[/]'}")
            _log("")

    elif demo == "qubit":
        _section("Single Qubit Demo")
        from qubit_sim import Qubit

        _log("\nStarting from |0⟩:")
        q = Qubit.zero()
        show_qubit_state(q, "|0⟩")

        q.hadamard()
        show_qubit_state(q, "After H (superposition)")

        _log("\n  Measuring 8 times from |+⟩ state:")
        results = []
        for i in range(8):
            q = Qubit.plus()
            r = q.measure()
            results.append(r)
        _log(f"  Results: {results}  (should be ~50% each)")
        _log(f"  Got: {results.count(0)}×0  {results.count(1)}×1")

    else:
        _error(f"Unknown demo '{demo}'. Choose: gates, bb84, e91, bell, qubit")
        sys.exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# Command: inspect
# ─────────────────────────────────────────────────────────────────────────────

def cmd_inspect(args):
    _section("Inspect .qcrypt File")
    path = args.input

    if not os.path.isfile(path):
        _error(f"File not found: {path}")
        sys.exit(1)

    try:
        meta = inspect_qcrypt_header(path)
    except Exception as exc:
        _error(f"Failed to inspect: {exc}")
        sys.exit(1)

    if RICH and console:
        from rich.table import Table
        t = Table(title=f"[bold]{path}[/]", box=box.ROUNDED,
                  show_header=False)
        t.add_column("Field", style="bold cyan")
        t.add_column("Value")
        for k, v in meta.items():
            t.add_row(k.replace("_", " ").title(), str(v))
        console.print(t)
    else:
        print(f"\n{path}:")
        for k, v in meta.items():
            print(f"  {k}: {v}")

    if args.json:
        print(json.dumps(meta, indent=2))


# ─────────────────────────────────────────────────────────────────────────────
# Argument parser
# ─────────────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="qcrypto",
        description="Quantum Cryptography File Transfer System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("--no-banner", action="store_true", help="Suppress banner")

    sub = p.add_subparsers(dest="command", required=True)

    # ── generate-key ─────────────────────────────────────────────────────────
    gk = sub.add_parser("generate-key", help="Run QKD to produce an AES-256 key")
    gk.add_argument("--protocol",   choices=["bb84", "e91"], default="bb84",
                    help="QKD protocol (default: bb84)")
    gk.add_argument("--qubits",     type=int, default=512,
                    help="BB84: number of qubits to transmit (default: 512)")
    gk.add_argument("--pairs",      type=int, default=600,
                    help="E91: number of entangled pairs (default: 600)")
    gk.add_argument("--eavesdrop",  action="store_true",
                    help="Inject an eavesdropper (Eve) to test detection")
    gk.add_argument("--save-key",   metavar="FILE",
                    help="Save key hex to FILE (e.g. quantum_key.hex)")
    gk.add_argument("--show-qubits", type=int, default=20,
                    help="Number of qubits to show in BB84 table (default: 20)")
    gk.add_argument("--json",       action="store_true", help="Output as JSON")

    # ── encrypt-file ─────────────────────────────────────────────────────────
    ef = sub.add_parser("encrypt-file", help="Encrypt a file with AES-256-GCM")
    ef.add_argument("input",  help="File to encrypt")
    ef.add_argument("--key",  required=True, metavar="HEX_OR_FILE",
                    help="64-char hex key or path to .hex file")
    ef.add_argument("--output", "-o", metavar="FILE",
                    help="Output path (default: <input>.qcrypt)")
    ef.add_argument("--json",   action="store_true", help="Output metadata as JSON")

    # ── decrypt-file ─────────────────────────────────────────────────────────
    df = sub.add_parser("decrypt-file", help="Decrypt a .qcrypt file")
    df.add_argument("input",  help=".qcrypt file to decrypt")
    df.add_argument("--key",  required=True, metavar="HEX_OR_FILE",
                    help="64-char hex key or path to .hex file")
    df.add_argument("--output", "-o", metavar="FILE",
                    help="Output path (default: strip .qcrypt)")
    df.add_argument("--verify", metavar="ORIGINAL_FILE",
                    help="Verify decrypted file matches this original")
    df.add_argument("--json",   action="store_true", help="Output metadata as JSON")

    # ── simulate ─────────────────────────────────────────────────────────────
    sim = sub.add_parser("simulate", help="Interactive qubit/protocol demo")
    sim.add_argument("--demo", default="gates",
                     choices=["gates", "bb84", "e91", "bell", "qubit"],
                     help="Demo to run (default: gates)")

    # ── inspect ──────────────────────────────────────────────────────────────
    ins = sub.add_parser("inspect", help="Show metadata of a .qcrypt file")
    ins.add_argument("input", help=".qcrypt file to inspect")
    ins.add_argument("--json", action="store_true", help="Output as JSON")

    return p


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = build_parser()
    args   = parser.parse_args()

    if not getattr(args, "no_banner", False):
        print_banner()

    dispatch = {
        "generate-key": cmd_generate_key,
        "encrypt-file": cmd_encrypt_file,
        "decrypt-file": cmd_decrypt_file,
        "simulate":     cmd_simulate,
        "inspect":      cmd_inspect,
    }

    try:
        dispatch[args.command](args)
    except KeyboardInterrupt:
        _log("\n[yellow]Interrupted.[/]")
        sys.exit(0)
    except Exception as exc:
        _error(f"Unexpected error: {exc}")
        if os.environ.get("QCRYPTO_DEBUG"):
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
