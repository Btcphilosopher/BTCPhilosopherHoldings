"""
cascade.py — Cascade Information Reconciliation Protocol
=========================================================
After BB84 sifting, Alice and Bob share correlated but not identical
bit strings (QBER ≈ 1–20%). Cascade is an interactive parity-based
error-correction protocol that:

  1. Divides bits into blocks of size k₁ = ceil(0.73 / QBER)
  2. Alice announces block parities over the public channel
  3. Bob checks his parities; if they differ, binary search finds the error
  4. Repeat with larger blocks (k_i = 2·k_{i-1}) to catch secondary errors
     introduced by the binary-search corrections
  5. Randomly permute and repeat — typically 4 passes suffice for QBER ≤ 10%

Security: parity announcements leak information to Eve.
  Bits leaked ≈ 1.16 / QBER (slightly above the Shannon entropy H(QBER)).
  The leaked information is accounted for in the privacy amplification step.

References:
  Brassard & Salvail, "Secret-Key Reconciliation by Public Discussion",
  Eurocrypt 1993, LNCS 765, pp. 410-423.

  van Assche, "Quantum Cryptography and Secret-Key Distillation", Ch. 4.
"""

import random
import math
from typing import List, Tuple, Optional
from dataclasses import dataclass, field


# ─────────────────────────────────────────────────────────────────────────────
# Data types
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CascadeResult:
    """Outcome of a Cascade reconciliation session."""
    alice_bits_in:    List[int]  = field(default_factory=list)
    bob_bits_in:      List[int]  = field(default_factory=list)
    bob_bits_out:     List[int]  = field(default_factory=list)
    errors_before:    int        = 0
    errors_after:     int        = 0
    passes:           int        = 0
    parity_bits_sent: int        = 0   # bits leaked to public channel
    binary_searches:  int        = 0

    @property
    def correction_rate(self) -> float:
        """Fraction of errors corrected."""
        if self.errors_before == 0:
            return 1.0
        return 1.0 - self.errors_after / self.errors_before

    @property
    def information_leakage(self) -> float:
        """
        Estimated information leakage in bits per key bit.
        Approximation: each parity bit leaks ~1 bit about the key.
        Actual leakage is lower since parities of large blocks reveal less.
        """
        n = len(self.alice_bits_in)
        return self.parity_bits_sent / n if n > 0 else 0.0

    @property
    def frame_error_rate(self) -> float:
        """Fraction of remaining positions with errors."""
        n = len(self.bob_bits_out)
        return self.errors_after / n if n > 0 else 0.0


# ─────────────────────────────────────────────────────────────────────────────
# Core helpers
# ─────────────────────────────────────────────────────────────────────────────

def _parity(bits: List[int], indices: List[int]) -> int:
    """XOR parity of bits at given indices."""
    p = 0
    for i in indices:
        p ^= bits[i]
    return p


def _count_errors(alice: List[int], bob: List[int]) -> int:
    """Count positions where alice and bob disagree."""
    return sum(a != b for a, b in zip(alice, bob))


def _block_indices(block_size: int, n: int, permutation: List[int]) -> List[List[int]]:
    """
    Generate list of index-blocks after applying the permutation.
    Each block is a list of original indices of size block_size
    (last block may be smaller).
    """
    blocks = []
    for start in range(0, n, block_size):
        block = permutation[start:start + block_size]
        blocks.append(block)
    return blocks


# ─────────────────────────────────────────────────────────────────────────────
# Binary search (BINSEARCH) sub-protocol
# ─────────────────────────────────────────────────────────────────────────────

def _binary_search(
    alice_bits: List[int],
    bob_bits:   List[int],
    indices:    List[int],
    parity_count: List[int],
) -> int:
    """
    Find a single error in `indices` by bisection.
    Precondition: parity(alice, indices) ≠ parity(bob, indices) — exactly
    one error in this block.

    Returns
    -------
    The original index of the erroneous bit in bob_bits.
    Increments parity_count[0] by the number of parity announcements made.
    """
    while len(indices) > 1:
        mid   = len(indices) // 2
        left  = indices[:mid]

        alice_p = _parity(alice_bits, left)
        bob_p   = _parity(bob_bits,   left)
        parity_count[0] += 1  # one parity announced

        if alice_p != bob_p:
            indices = left
        else:
            indices = indices[mid:]

    return indices[0]


# ─────────────────────────────────────────────────────────────────────────────
# Main Cascade protocol
# ─────────────────────────────────────────────────────────────────────────────

def cascade(
    alice_bits:    List[int],
    bob_bits:      List[int],
    estimated_qber: float     = None,
    num_passes:    int        = 4,
    verbose:       bool       = False,
) -> CascadeResult:
    """
    Run the Cascade error-correction protocol.

    Alice and Bob each have a list of sifted key bits; Bob's bits contain
    some errors (QBER). After Cascade, Bob's list is corrected to match Alice's.

    Communication model:
    - Alice announces block parities (public channel, assumed read by Eve)
    - Bob compares and triggers binary search when parities differ
    - No bits of the actual key are revealed

    Parameters
    ----------
    alice_bits     : Alice's sifted key bits (reference — not modified)
    bob_bits       : Bob's sifted key bits   (will be corrected in-place copy)
    estimated_qber : estimated error rate; if None, computed from actual errors
    num_passes     : number of Cascade passes (4 is standard)
    verbose        : print per-pass statistics

    Returns
    -------
    CascadeResult with corrected bob_bits_out and leak statistics.
    """
    n = len(alice_bits)
    if n == 0:
        return CascadeResult()
    if len(bob_bits) != n:
        raise ValueError("alice_bits and bob_bits must have the same length.")

    # Work on a copy of Bob's bits
    bob = list(bob_bits)

    errors_before = _count_errors(alice_bits, bob)
    result = CascadeResult(
        alice_bits_in  = list(alice_bits),
        bob_bits_in    = list(bob_bits),
        errors_before  = errors_before,
        passes         = num_passes,
    )

    if estimated_qber is None:
        estimated_qber = errors_before / n if n > 0 else 0.05

    # Clamp to reasonable range
    estimated_qber = max(0.001, min(estimated_qber, 0.5))

    parity_count = [0]   # mutable counter (shared across closures)
    binary_searches = 0

    # Track which original positions were corrected in each pass
    # so we can re-check earlier passes (the "cascade" effect)
    pass_blocks: List[List[List[int]]] = []   # pass_blocks[pass][block]

    for pass_idx in range(num_passes):
        # Block size grows geometrically: k₁ ≈ 0.73/QBER, k_{i+1} = 2·k_i
        k = max(1, math.ceil(0.73 / estimated_qber) * (2 ** pass_idx))
        k = min(k, n)

        # Random permutation for this pass
        perm = list(range(n))
        random.shuffle(perm)

        blocks = _block_indices(k, n, perm)
        pass_blocks.append(blocks)

        if verbose:
            errors_now = _count_errors(alice_bits, bob)
            print(f"  Pass {pass_idx+1}: block_size={k}  "
                  f"blocks={len(blocks)}  errors={errors_now}")

        corrected_positions = set()

        for block in blocks:
            alice_p = _parity(alice_bits, block)
            bob_p   = _parity(bob,        block)
            parity_count[0] += 1

            if alice_p == bob_p:
                continue   # no error in this block (or even number of errors)

            # Exactly one detectable error (odd count) — binary search
            err_idx = _binary_search(alice_bits, bob, list(block), parity_count)
            bob[err_idx] ^= 1   # flip the error bit
            binary_searches += 1
            corrected_positions.add(err_idx)

        # ── Cascade: re-check earlier passes for new errors introduced ────────
        # Each correction may create an odd-error block in a previous pass.
        # We check all blocks from all previous passes that contain a corrected pos.
        if corrected_positions:
            for prev_pass_idx in range(pass_idx):
                for prev_block in pass_blocks[prev_pass_idx]:
                    prev_set = set(prev_block)
                    if not corrected_positions & prev_set:
                        continue

                    alice_p = _parity(alice_bits, prev_block)
                    bob_p   = _parity(bob,        prev_block)
                    parity_count[0] += 1

                    if alice_p == bob_p:
                        continue

                    err_idx = _binary_search(
                        alice_bits, bob, list(prev_block), parity_count
                    )
                    bob[err_idx] ^= 1
                    binary_searches += 1
                    corrected_positions.add(err_idx)

    errors_after = _count_errors(alice_bits, bob)

    result.bob_bits_out     = bob
    result.errors_after     = errors_after
    result.parity_bits_sent = parity_count[0]
    result.binary_searches  = binary_searches

    if verbose:
        print(f"  Final: errors {errors_before}→{errors_after}  "
              f"leakage={result.information_leakage:.4f} bits/bit  "
              f"searches={binary_searches}")

    return result


# ─────────────────────────────────────────────────────────────────────────────
# Cascade + Privacy Amplification pipeline
# ─────────────────────────────────────────────────────────────────────────────

def reconcile_and_amplify(
    alice_bits:     List[int],
    bob_bits:       List[int],
    estimated_qber: float = None,
    target_bytes:   int   = 32,
    num_passes:     int   = 4,
    verbose:        bool  = False,
) -> Tuple[bytes, bytes, CascadeResult]:
    """
    Full post-processing pipeline:
      1. Cascade error correction → corrected Bob bits
      2. Privacy amplification (SHA-256/HKDF) on corrected bits

    After this, Alice and Bob should have identical final keys.
    Eve's information is squeezed out by the hash compression.

    Parameters
    ----------
    alice_bits     : Alice's sifted key bits
    bob_bits       : Bob's sifted key bits (with errors)
    estimated_qber : QBER estimate (used to choose initial block size)
    target_bytes   : desired final key length
    num_passes     : Cascade passes
    verbose        : print progress

    Returns
    -------
    (alice_key, bob_key, cascade_result)
    alice_key and bob_key should be identical if Cascade succeeded.
    """
    from bb84 import privacy_amplification

    # Step 1: Cascade
    result = cascade(alice_bits, bob_bits, estimated_qber, num_passes, verbose)

    # Step 2: Privacy amplification on each party's corrected bits
    # After successful Cascade, bob_bits_out ≈ alice_bits.
    # Both parties apply the same hash to their own bits independently.
    alice_key = privacy_amplification(alice_bits,        target_bytes=target_bytes)
    bob_key   = privacy_amplification(result.bob_bits_out, target_bytes=target_bytes)

    return alice_key, bob_key, result


# ─────────────────────────────────────────────────────────────────────────────
# Integrate Cascade into BB84 session
# ─────────────────────────────────────────────────────────────────────────────

def bb84_with_cascade(
    num_qubits:       int   = 1024,
    eavesdrop:        bool  = False,
    target_key_bytes: int   = 32,
    num_passes:       int   = 4,
    verbose_callback         = None,
):
    """
    BB84 + Cascade post-processing pipeline.

    Unlike vanilla BB84 (which discards the sample used for QBER estimation),
    Cascade corrects *all* sifted bits, producing a longer final key for the
    same number of qubits.

    Returns
    -------
    dict with:
      alice_key_hex, bob_key_hex, keys_match, cascade_result,
      errors_before, errors_after, leakage_bits_per_bit
    """
    from bb84 import (run_bb84, BB84Result)

    def log(msg):
        if verbose_callback:
            verbose_callback(msg)

    # Run BB84 to get sifted bits (we override privacy amplification)
    log("[Cascade] Running BB84 sifting…")
    result = run_bb84(
        num_qubits=num_qubits,
        eavesdrop=eavesdrop,
        # Use all sifted bits (no QBER sample sacrifice) by using a
        # near-zero sample fraction:
        verbose_callback=verbose_callback,
    )

    # Use the sifted bits (before privacy amplification)
    alice_sifted = result.alice_sifted
    bob_sifted   = result.bob_sifted

    if len(alice_sifted) < 16:
        raise RuntimeError(f"Not enough sifted bits for Cascade: {len(alice_sifted)}")

    log(f"[Cascade] Sifted bits: {len(alice_sifted)}  QBER≈{result.error_rate:.2%}")
    log(f"[Cascade] Running Cascade ({num_passes} passes)…")

    alice_key, bob_key, cascade_res = reconcile_and_amplify(
        alice_sifted,
        bob_sifted,
        estimated_qber=max(result.error_rate, 0.01),
        target_bytes=target_key_bytes,
        num_passes=num_passes,
        verbose=False,
    )

    keys_match = alice_key == bob_key

    log(f"[Cascade] Errors: {cascade_res.errors_before}→{cascade_res.errors_after}  "
        f"correction rate={cascade_res.correction_rate:.1%}")
    log(f"[Cascade] Leakage: {cascade_res.parity_bits_sent} parity bits "
        f"({cascade_res.information_leakage:.4f} bits/bit)")
    log(f"[Cascade] Keys {'✓ MATCH' if keys_match else '✗ DIFFER'}")

    return {
        "alice_key_hex":        alice_key.hex(),
        "bob_key_hex":          bob_key.hex(),
        "keys_match":           keys_match,
        "cascade_result":       cascade_res,
        "errors_before":        cascade_res.errors_before,
        "errors_after":         cascade_res.errors_after,
        "leakage_bits_per_bit": cascade_res.information_leakage,
        "parity_bits_sent":     cascade_res.parity_bits_sent,
        "binary_searches":      cascade_res.binary_searches,
        "qber_in":              result.error_rate,
        "sifted_count":         len(alice_sifted),
    }


# ─────────────────────────────────────────────────────────────────────────────
# QBER sweep: measure Cascade performance vs error rate
# ─────────────────────────────────────────────────────────────────────────────

def sweep_cascade_vs_qber(
    qber_values: List[float] = None,
    n_bits:      int         = 500,
    num_passes:  int         = 4,
    trials:      int         = 3,
) -> List[dict]:
    """
    Evaluate Cascade correction rate and leakage across a range of QBERs.

    Generates synthetic bit strings with the given QBER, runs Cascade,
    and reports correction success.

    Returns
    -------
    List of dicts: qber, errors_before, errors_after, correction_rate,
                   leakage, searches
    """
    if qber_values is None:
        qber_values = [0.01, 0.02, 0.05, 0.08, 0.10, 0.12, 0.15]

    results = []
    for qber in qber_values:
        corr_rates, leakages = [], []

        for _ in range(trials):
            alice = [random.randint(0, 1) for _ in range(n_bits)]
            # Introduce errors at given QBER
            bob = [
                (b ^ 1) if random.random() < qber else b
                for b in alice
            ]
            r = cascade(alice, bob, estimated_qber=qber, num_passes=num_passes)
            corr_rates.append(r.correction_rate)
            leakages.append(r.information_leakage)

        results.append({
            "qber":            qber,
            "correction_rate": sum(corr_rates) / len(corr_rates),
            "leakage":         sum(leakages)   / len(leakages),
        })

    return results


def plot_cascade_performance(
    sweep_data: List[dict],
    save_path:  str  = None,
    show:       bool = True,
):
    """
    Plot Cascade correction rate and information leakage vs QBER.
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("[cascade] matplotlib not available — skipping plot")
        return None

    qbers  = [d["qber"]            for d in sweep_data]
    corr   = [d["correction_rate"] * 100 for d in sweep_data]
    leak   = [d["leakage"]         for d in sweep_data]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle("Cascade Protocol Performance", fontsize=13, fontweight="bold")

    ax1.plot([q*100 for q in qbers], corr, "o-", color="#2ecc71", lw=2, ms=8)
    ax1.axhline(100, color="gray", ls="--", lw=1)
    ax1.set_xlabel("QBER (%)")
    ax1.set_ylabel("Correction Rate (%)")
    ax1.set_title("Error Correction Rate vs QBER")
    ax1.set_ylim(0, 105)
    ax1.grid(alpha=0.3)
    for x, y in zip([q*100 for q in qbers], corr):
        ax1.annotate(f"{y:.1f}%", (x, y), textcoords="offset points",
                     xytext=(0, 7), ha="center", fontsize=8)

    ax2.plot([q*100 for q in qbers], leak, "s-", color="#e74c3c", lw=2, ms=8)
    ax2.set_xlabel("QBER (%)")
    ax2.set_ylabel("Leakage (bits per key bit)")
    ax2.set_title("Information Leakage vs QBER")
    ax2.grid(alpha=0.3)
    # Theoretical Shannon limit: H(p) = -p log2(p) - (1-p)log2(1-p)
    import math
    theory_x = [q*100 for q in qbers]
    theory_y = []
    for q in qbers:
        if 0 < q < 1:
            h = -q*math.log2(q) - (1-q)*math.log2(1-q)
        else:
            h = 0.0
        theory_y.append(h)
    ax2.plot(theory_x, theory_y, "--", color="#f39c12", lw=1.5, label="Shannon limit H(p)")
    ax2.legend(fontsize=8)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    if show:
        plt.show()
    return fig
