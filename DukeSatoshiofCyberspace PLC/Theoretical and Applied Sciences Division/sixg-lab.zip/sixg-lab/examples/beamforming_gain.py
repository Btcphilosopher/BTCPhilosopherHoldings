"""Slice 2: SINR improvement from 64-element arrays (MRT / codebook) vs a single-element baseline. Same city, same
seed, same UEs; only the antenna model changes. Every number comes from the simulation."""
from sixglab.config import load_scenario
from sixglab.network import Simulation

POP = [{"kind": "pedestrian", "count": 60}, {"kind": "vehicle", "count": 40}]
base = {"simulation": {"duration_s": 10}, "network": {"populations": POP}}
cases = {
    "single element (5 dBi, no beamforming)": {"radio": {"antenna": {"mode": "fixed_gain", "bs_gain_dbi": 5.0}}},
    "64-element URA x4 panels, codebook beams": {"radio": {"antenna": {"mode": "array", "beamformer": "codebook"}}},
    "64-element URA x4 panels, MRT (ideal CSI)": {"radio": {"antenna": {"mode": "array", "beamformer": "mrt"}}},
}
print(f"{'case':46s} {'cover':>6s} {'median SINR':>10s} {'thr Gb/s':>9s} {'P95 ms':>7s}")
for name, ov in cases.items():
    cfg = load_scenario("scenarios/urban_6g.yaml", overrides={**base, **{"radio": ov["radio"]}})
    s = Simulation(cfg).run()
    print(f"{name:46s} {s['coverage_fraction']:6.2f} {s['median_sinr_db']:10.2f} {s['mean_throughput_bps'] / 1e9:9.2f} {s['latency_p95_ms']:7.2f}")
