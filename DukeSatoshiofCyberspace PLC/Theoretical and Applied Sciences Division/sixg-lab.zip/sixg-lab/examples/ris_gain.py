"""Slice 3: RIS phase optimisation. Finds outage UEs, searches building faces for the RIS site that serves the most of
them, optimises phases (coordinate descent and gradient) and prints received power / SINR / rate with and without RIS."""
import numpy as np

from sixglab.config import load_scenario
from sixglab.network import Simulation
from sixglab.ris import RIS
from sixglab.ris.experiment import evaluate_ris, find_ris_site

cfg = load_scenario("scenarios/urban_140ghz_fixed_gain.yaml", overrides={"simulation": {"duration_s": 2}})
sim = Simulation(cfg)
for _ in range(cfg.simulation.n_epochs):
    sim.step_epoch()
out = np.nonzero(sim.state.cqi <= 1)[0]
print(f"{len(out)} of {sim.n_ue} UEs in outage or at the lowest CQI at t={sim.state.t_s:.1f} s")
pos, nrm, vis = find_ris_site(sim, out)
print(f"RIS site {pos.round(1)} normal {nrm}: {vis} weak UEs have LoS to it (and it to their serving gNB)")
for n_side, bits in ((16, None), (64, None), (128, None), (128, 2)):
    for method in ("coordinate_descent", "gradient"):
        ris = RIS(pos, nrm, n_side, n_side, cfg.radio.carrier_frequency_hz, phase_bits=bits)
        r = evaluate_ris(sim, ris, out, method)
        vis_idx = np.array(r["ris_visible"])
        if not vis_idx.any():
            print(f"{n_side}x{n_side}: no UE sees the RIS"); continue
        d = lambda k: np.array(r[k])[vis_idx]  # noqa: E731
        print(f"{n_side}x{n_side} bits={bits} {method:19s} visible UEs {vis_idx.sum():2d}  "
              f"Prx w/o {d('rx_power_dbm_without').mean():7.1f}  random {d('rx_power_dbm_random_phase').mean():7.1f}  "
              f"optimised {d('rx_power_dbm_with').mean():7.1f} dBm | SINR {d('sinr_db_without').mean():6.1f} -> {d('sinr_db_with').mean():6.1f} dB | "
              f"rate {d('rate_bps_without').mean() / 1e6:7.0f} -> {d('rate_bps_with').mean() / 1e6:8.0f} Mb/s")
