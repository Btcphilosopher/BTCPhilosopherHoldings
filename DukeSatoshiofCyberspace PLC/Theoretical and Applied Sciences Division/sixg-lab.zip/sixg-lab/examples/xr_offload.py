"""Slice 4: XR frame rendering - local vs edge vs cloud, using rates measured from the simulation."""
import numpy as np

from sixglab.config import load_scenario
from sixglab.edge.offload import OffloadParams, compare, link_rates, xr_frame_task
from sixglab.edge.server import EdgeServer
from sixglab.network import Simulation

cfg = load_scenario("scenarios/urban_6g.yaml", overrides={"simulation": {"duration_s": 3},
                    "network": {"populations": [{"kind": "pedestrian", "count": 60}, {"kind": "vehicle", "count": 40}]}})
sim = Simulation(cfg)
for _ in range(cfg.simulation.n_epochs):
    sim.step_epoch()
# Illustrative capacities (GPU-equivalent operations/s): mobile GPU 1e12, edge render node 1e14, cloud share 1e15.
p, task, st = OffloadParams(ue_cycles_per_s=1e12, cloud_cycles_per_s=1e15, kappa=1e-35), xr_frame_task(), sim.state
render = EdgeServer('edge-render', 1e14)
CONCURRENT_XR, XR_HZ = 10, 60.0   # other XR users already served by the same node
res = {"local": [], "edge": [], "cloud": []}
conn = np.nonzero(st.cqi > 0)[0]
for u in conn:
    ul, dl = link_rates(sim, int(u), p)
    c = compare(task, ul, dl, sim.bs_transport_s[st.serving[u]], render, CONCURRENT_XR * XR_HZ, task.compute_cycles, p)
    for key in res:
        res[key].append(c[key])
print(f"{len(conn)} connected UEs; task: {task.input_bits/8e3:.0f} kB up, {task.output_bits/8e6:.1f} MB down, {task.compute_cycles:.1e} cycles, budget {task.latency_budget_s*1e3:.0f} ms")
for key, v in res.items():
    t = np.array([x["total_s"] for x in v]) * 1e3
    e = np.array([x["energy_j"] for x in v])
    ok = np.mean([x["meets_budget"] for x in v])
    print(f"{key:6s} latency median {np.median(t):8.2f} ms  P95 {np.percentile(t[np.isfinite(t)], 95):8.2f} ms  meets budget {ok*100:5.1f}%  UE energy {np.median(e):.3e} J")
e0 = res["edge"][0]
print("edge component breakdown (UE 0, ms):", {k: round(v * 1e3, 3) for k, v in e0.items() if k.endswith("_s")})
