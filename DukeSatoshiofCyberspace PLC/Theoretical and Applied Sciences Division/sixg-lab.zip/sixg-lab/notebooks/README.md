Notebooks are thin: they import `sixglab` and call the same entry points as the CLI (see `examples/`). No simulation
logic lives in notebooks.
