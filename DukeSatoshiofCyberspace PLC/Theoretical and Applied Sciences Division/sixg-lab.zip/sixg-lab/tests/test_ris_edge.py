import numpy as np
import pytest

from sixglab.core.errors import ConfigurationError
from sixglab.edge.offload import OffloadParams, compare, link_rates, xr_frame_task
from sixglab.edge.server import EdgeServer
from sixglab.network import Simulation
from sixglab.ris import RIS, coordinate_descent, gradient_ascent, total_field
from sixglab.ris.experiment import evaluate_ris, find_ris_site
from tests.conftest import tiny_cfg

F = 140e9
TX, RX = np.array([-30.0, 30.0, 10.0]), np.array([30.0, 30.0, 1.5])


def make(n=16, bits=None):
    return RIS(np.array([0.0, 0.0, 5.0]), np.array([0.0, 1.0, 0.0]), n, n, F, phase_bits=bits)


def test_ris_coherent_gain_scales_as_n_squared():
    ratios = []
    for n in (4, 8, 16):
        r = make(n)
        c = r.cascade(TX, RX, 1.0, 100.0, 10.0)
        r.phases = coordinate_descent(np.zeros(1, complex), c[None, :], r)
        p = np.abs(total_field(np.zeros(1, complex), c[None, :], r.reflection()))[0] ** 2
        ratios.append(p / np.mean(np.abs(c) ** 2))
        assert ratios[-1] == pytest.approx(r.n**2, rel=1e-3)
    assert ratios[2] / ratios[1] == pytest.approx(16.0, rel=1e-3)             # 4x elements -> 16x power


def test_ris_random_phase_scales_as_n_not_n_squared():
    r = make(16)
    c = r.cascade(TX, RX, 1.0, 100.0, 10.0)
    rng = np.random.default_rng(0)
    p = []
    for _ in range(300):
        r.phases = rng.uniform(0, 2 * np.pi, r.n)
        p.append(np.abs(np.sum(c * r.reflection())) ** 2)
    assert np.mean(p) / np.sum(np.abs(c) ** 2) == pytest.approx(1.0, rel=0.15)


def test_ris_cascade_follows_friis_two_hop():
    r = RIS(np.array([0.0, 0.0, 5.0]), np.array([0.0, 1.0, 0.0]), 1, 1, F)
    tx, rx = np.array([0.0, 50.0, 5.0]), np.array([0.0, 20.0, 5.0])         # both on the normal axis: cos = 1
    c = r.cascade(tx, rx, 2.0, 10.0, 4.0, include_absorption=False)
    lam = 299792458.0 / F
    expect = 2.0 * 10.0 * 4.0 * r.g0**2 * (lam / (4 * np.pi)) ** 4 / (50.0 * 20.0) ** 2
    assert np.abs(c[0]) ** 2 == pytest.approx(expect, rel=1e-9)


def test_ris_quantisation_and_constraints():
    r = make(8, bits=2)
    assert set(np.round(r.quantise(np.linspace(0, 6.2, 200)) / (np.pi / 2)).astype(int)) <= {0, 1, 2, 3, 4}
    with pytest.raises(ConfigurationError):
        RIS(np.zeros(3), np.array([0, 1.0, 0]), 4, 4, F, max_amplitude=1.5)
    c = r.cascade(TX, RX, 1.0, 100.0, 10.0)
    d = np.array([1e-10 + 0j])
    r.phases = coordinate_descent(d, c[None, :], r)
    assert np.all(np.isin(np.round(r.phases / (np.pi / 2), 9) % 4, [0, 1, 2, 3]))
    p2 = np.abs(total_field(d, c[None, :], r.reflection()))[0] ** 2
    ideal = make(8, None)
    ideal.phases = coordinate_descent(d, c[None, :], ideal)
    p_ideal = np.abs(total_field(d, c[None, :], ideal.reflection()))[0] ** 2
    assert p_ideal >= p2 >= 0.6 * p_ideal                                     # 2-bit loss is bounded (~0.9 dB ideal)


def test_ris_behind_panel_contributes_nothing():
    r = make(4)
    assert np.all(r.cascade(np.array([0.0, -30.0, 5.0]), RX, 1.0, 10.0, 10.0) == 0)


def test_gradient_matches_coordinate_descent_single_user():
    r1, r2 = make(8), make(8)
    c = r1.cascade(TX, RX, 1.0, 100.0, 10.0)
    d = np.array([0.3 * np.abs(c).sum() * np.exp(-0.7j)])
    r1.phases = coordinate_descent(d, c[None, :], r1)
    r2.phases = gradient_ascent(d, c[None, :], r2, iters=400)
    p1 = np.abs(total_field(d, c[None, :], r1.reflection()))[0] ** 2
    p2 = np.abs(total_field(d, c[None, :], r2.reflection()))[0] ** 2
    assert p2 >= 0.9 * p1 and p1 > np.abs(d[0]) ** 2


def test_coordinate_descent_never_decreases_sum_power():
    rng = np.random.default_rng(2)
    r = make(6)
    C = (rng.standard_normal((3, r.n)) + 1j * rng.standard_normal((3, r.n))) * 1e-6
    d = (rng.standard_normal(3) + 1j * rng.standard_normal(3)) * 1e-5
    before = np.sum(np.abs(total_field(d, C, r.reflection())) ** 2)
    r.phases = coordinate_descent(d, C, r)
    assert np.sum(np.abs(total_field(d, C, r.reflection())) ** 2) >= before


def test_ris_experiment_on_live_simulation_reports_before_after():
    sim = Simulation(tiny_cfg(simulation={"duration_s": 0.5}))
    sim.run()
    weak = np.nonzero(sim.state.cqi <= 1)[0]
    if weak.size == 0:
        weak = np.arange(3)
    pos, nrm, vis = find_ris_site(sim, weak, n_along=2)
    r = RIS(pos, nrm, 64, 64, F, phase_bits=2)
    out = evaluate_ris(sim, r, weak, "coordinate_descent")
    ok = np.array(out["ris_visible"])
    assert set(out) >= {"objective", "constraints", "rx_power_dbm_without", "rx_power_dbm_with", "sinr_db_with"}
    if ok.any():
        assert np.all(np.array(out["rx_power_dbm_with"])[ok] >= np.array(out["rx_power_dbm_random_phase"])[ok] - 1e-6)
    assert np.allclose(np.array(out["rx_power_dbm_with"])[~ok], np.array(out["rx_power_dbm_without"])[~ok], atol=1e-6)


def test_offload_comparison_is_physical():
    p = OffloadParams(ue_cycles_per_s=1e12, cloud_cycles_per_s=1e15, kappa=1e-35)
    srv = EdgeServer("r", 1e14)
    t = xr_frame_task()
    c = compare(t, 1e9, 1e10, 4e-5, srv, 600.0, t.compute_cycles, p)
    assert c["local"]["total_s"] == pytest.approx(t.compute_cycles / 1e12)
    e = c["edge"]
    assert e["total_s"] == pytest.approx(e["uplink_s"] + e["transport_s"] + e["queue_s"] + e["compute_s"] + e["downlink_s"], rel=1e-9)
    assert e["uplink_s"] == pytest.approx(t.input_bits / 1e9) and e["downlink_s"] == pytest.approx(t.output_bits / 1e10)
    assert c["cloud"]["total_s"] > c["edge"]["total_s"]                       # WAN round trip dominates
    assert c["edge"]["meets_budget"] and not c["local"]["meets_budget"]
    assert c["local"]["energy_j"] > c["edge"]["energy_j"]
    dead = compare(t, 0.0, 1e9, 0.0, srv, 0.0, 1.0, p)
    assert dead["edge"]["total_s"] == float("inf") and not dead["edge"]["meets_budget"]


def test_link_rates_from_live_simulation():
    sim = Simulation(tiny_cfg(simulation={"duration_s": 0.3}))
    sim.run()
    u = int(np.argmax(sim.state.cqi))
    ul, dl = link_rates(sim, u, OffloadParams())
    assert dl == pytest.approx(sim.state.rate_bps[u] * 0.8) and ul >= 0
