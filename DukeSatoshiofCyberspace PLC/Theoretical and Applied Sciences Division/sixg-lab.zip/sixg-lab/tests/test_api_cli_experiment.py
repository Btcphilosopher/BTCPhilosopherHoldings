import json
import subprocess
import sys
import time

import numpy as np
import pytest
from fastapi.testclient import TestClient

from sixglab.api.main import app, manager
from sixglab.cli import main
from sixglab.config import scenario_from_dict
from sixglab.scenarios.experiment import Experiment, MonteCarloRunner, apply_parameter, confidence_interval
from sixglab.storage.runs import load_run
from sixglab.visualisation.report import batch_means_ci, generate_report
from tests.conftest import tiny_cfg

client = TestClient(app)
SHORT = {"simulation": {"duration_s": 1.0}, "network": {"populations": [{"kind": "pedestrian", "count": 15}, {"kind": "vehicle", "count": 10}]}}


def test_api_lifecycle_and_endpoints(tmp_path):
    manager.runs_root = str(tmp_path)
    assert client.get("/api/health").json()["title"] == "6G DIGITAL TWIN LAB"
    assert {s["id"] for s in client.get("/api/scenarios").json()} >= {"urban_6g", "urban_140ghz_fixed_gain"}
    r = client.post("/api/simulations", json={"scenario": "urban_140ghz_fixed_gain", "overrides": SHORT, "mode": "batch"})
    assert r.status_code == 201 and r.json()["status"] == "created"
    sid = r.json()["id"]
    assert client.post(f"/api/simulations/{sid}/step").json()["epoch"] == 1
    assert client.post(f"/api/simulations/{sid}/start").json()["status"] in ("running", "completed")
    for _ in range(100):
        d = client.get(f"/api/simulations/{sid}").json()
        if d["status"] == "completed":
            break
        time.sleep(0.1)
    assert d["status"] == "completed" and d["summary"]["mean_sinr_db"] is not None and d["saved_to"]
    assert client.get("/api/network").json()["base_stations"] and client.get("/api/network").json()["topology"]["links"]
    radio = client.get(f"/api/radio?simulation_id={sid}").json()
    assert "Reduced-Order THz" in radio["path_loss_model"] and len(radio["link_adaptation"]["cqi_thresholds_db"]) == 15
    ues = client.get(f"/api/ues?simulation_id={sid}").json()
    assert len(ues) == 25
    tr = client.get(f"/api/ues/2/trace?simulation_id={sid}").json()
    assert tr["link_budget"][-1]["term"] == "SINR" and tr["latency_ms"]["total_ms"] is not None or tr["link_adaptation"]["cqi"] == 0
    ch = client.get(f"/api/channels?ue=1&simulation_id={sid}").json()
    assert len(ch["cells"]) == 12 and "components_db" in ch["cells"][0]
    assert len(client.get(f"/api/telemetry?simulation_id={sid}").json()) == 10
    assert client.get(f"/api/events?simulation_id={sid}").json()
    cov = client.get(f"/api/coverage?simulation_id={sid}&resolution_m=40").json()
    assert cov["nx"] > 5 and cov["model"]
    assert client.get("/api/ues/999/trace").status_code == 404


def test_api_errors_and_guards():
    assert client.get("/api/simulations/doesnotexist").status_code == 404
    assert client.post("/api/simulations", json={"scenario": "../../etc/passwd"}).status_code == 422
    assert client.post("/api/simulations", json={"scenario": "urban_6g", "overrides": {"radio": {"bandwidth_hz": -1}}}).status_code == 422
    assert client.post("/api/simulations", json={"scenario": "urban_6g", "mode": "warp"}).status_code == 422
    assert client.post("/api/simulations", json={"bogus": 1}).status_code == 422


def test_api_pause_stop():
    sid = client.post("/api/simulations", json={"scenario": "urban_140ghz_fixed_gain", "save": False, "mode": "real_time",
                                               "overrides": {"simulation": {"duration_s": 30.0}, "network": SHORT["network"]}, "autostart": True}).json()["id"]
    time.sleep(0.4)
    assert client.post(f"/api/simulations/{sid}/pause").json()["status"] == "paused"
    e1 = client.get(f"/api/simulations/{sid}").json()["epoch"]
    time.sleep(0.4)
    assert client.get(f"/api/simulations/{sid}").json()["epoch"] <= e1 + 1
    assert client.post(f"/api/simulations/{sid}/stop").json()["status"] in ("stopped", "paused", "running")
    time.sleep(0.5)
    assert client.get(f"/api/simulations/{sid}").json()["status"] == "stopped"


def test_websocket_streams_frames_with_physical_content():
    sid = client.post("/api/simulations", json={"scenario": "urban_140ghz_fixed_gain", "save": False, "mode": "batch", "autostart": True, "overrides": SHORT}).json()["id"]
    with client.websocket_connect(f"/ws/simulation/{sid}?all_frames=true") as ws:
        kinds, last = [], None
        while True:
            m = ws.receive_json()
            kinds.append(m["type"])
            if m["type"] == "frame":
                last = m
            if m["type"] == "status":
                break
    assert kinds[0] == "static" and kinds.count("frame") == 10 and m["status"] == "completed"
    assert set(last) >= {"metrics", "ue", "beams", "latency_breakdown_ms", "events", "bs_load"}
    assert len(last["ue"]["x"]) == 25 and set(last["latency_breakdown_ms"]) == {"radio", "queue", "transport", "edge", "application"}
    with client.websocket_connect("/ws/simulation/nope") as ws:
        assert ws.receive_json()["type"] == "error"


def test_cli_validate_and_simulate(capsys, tmp_path):
    assert main(["validate"]) == 0
    assert "analytical checks passed" in capsys.readouterr().out
    sc = tmp_path / "s.yaml"
    sc.write_text("name: Tiny\nsimulation: {duration_s: 1, seed: 3}\nradio: {antenna: {mode: fixed_gain}}\nnetwork:\n  populations: [{kind: pedestrian, count: 10}]\n")
    assert main(["simulate", str(sc), "--out", str(tmp_path / "runs"), "--quiet"]) == 0
    out = capsys.readouterr().out
    for token in ("6G DIGITAL TWIN LAB", "Scenario: Tiny", "Seed: 3", "Base Stations: 12", "UEs: 10", "Bandwidth: 2 GHz", "Carrier: 140 GHz",
                  "Mean SINR:", "Mean Throughput:", "P95 Latency:", "Energy:", "Simulation complete."):
        assert token in out, token
    rid = out.split("Run id: ")[1].split()[0]
    run = load_run(rid, tmp_path / "runs")
    assert run["summary"]["provenance"]["random_seed"] == 3 and len(run["metrics"]) == 10
    assert main(["replay", rid, "--out", str(tmp_path / "runs")]) == 0
    paths = generate_report(rid, tmp_path / "runs")
    assert "6G DIGITAL TWIN LAB" in paths["html"].read_text() and paths["pdf"].stat().st_size > 1000
    assert json.loads(paths["json"].read_text())["summary"]["seed"] == 3
    prov = run["summary"]["provenance"]
    assert {"git_commit", "python_version", "package_versions", "scenario_version", "random_seed", "config_hash"} <= set(prov)
    assert main(["simulate", "/no/such/file.yaml"]) == 2


def test_python_dash_m_sixglab_runs():
    out = subprocess.run([sys.executable, "-m", "sixglab", "--version"], capture_output=True, text=True, timeout=60)
    assert out.returncode == 0 and "sixg-lab" in out.stdout


def test_experiment_sweep_frequency_and_reproducibility(tmp_path):
    exp = Experiment("freq", tiny_cfg(simulation={"duration_s": 0.5}).model_dump(mode="json"),
                     {"radio.carrier_frequency_hz": [100e9, 140e9, 220e9]}, 1)
    df = exp.run()
    assert list(df["radio.carrier_frequency_hz"]) == [100e9, 140e9, 220e9]
    assert df["mean_sinr_db"].is_monotonic_decreasing                          # SINR falls as frequency rises
    out = exp.save(tmp_path)
    meta = json.loads((out / "experiment.json").read_text())
    assert meta["provenance"]["config_hash"] and (out / "results.parquet").exists()
    again = Experiment("freq", exp.scenario, exp.sweep, 1).run()
    assert np.allclose(df["mean_sinr_db"], again["mean_sinr_db"])


def test_parameter_helpers():
    doc = tiny_cfg().model_dump(mode="json")
    apply_parameter(doc, "ue_count", 60)
    assert scenario_from_dict(doc).n_ues == 60
    apply_parameter(doc, "antenna_count", 256)
    assert doc["radio"]["antenna"]["rows"] == 16
    with pytest.raises(Exception):
        apply_parameter(doc, "antenna_count", 50)


def test_monte_carlo_ci_and_seeds():
    res = MonteCarloRunner(tiny_cfg(simulation={"duration_s": 0.5}), 4).run()
    assert res["n_runs"] == 4 and len(set(res["seeds"])) == 4
    m = res["metrics"]["mean_sinr_db"]
    assert m["ci95_low"] <= m["mean"] <= m["ci95_high"]
    lo = confidence_interval(np.array([1.0, 2.0, 3.0, 4.0]))
    assert lo[0] == 2.5 and lo[1] < 2.5 < lo[2]
    assert batch_means_ci(np.random.default_rng(0).normal(5, 1, 1000))[1] < 5.3
