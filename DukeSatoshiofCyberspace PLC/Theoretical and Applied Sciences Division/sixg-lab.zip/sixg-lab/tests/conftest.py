import numpy as np
import pytest

from sixglab.config import scenario_from_dict


def tiny_cfg(**over):
    doc = {"simulation": {"duration_s": 1.0, "seed": 5},
           "network": {"populations": [{"kind": "pedestrian", "count": 20}, {"kind": "vehicle", "count": 10}]},
           "radio": {"antenna": {"mode": "fixed_gain"}}}
    for k, v in over.items():
        doc.setdefault(k, {}).update(v)
    return scenario_from_dict(doc)


@pytest.fixture
def cfg():
    return tiny_cfg()


@pytest.fixture
def rng():
    return np.random.default_rng(1234)
