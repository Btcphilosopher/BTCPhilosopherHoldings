import hashlib

import numpy as np
import pytest

from sixglab.core.events import EventType
from sixglab.digital_twin import DigitalTwin
from sixglab.network import Simulation
from tests.conftest import tiny_cfg


def digest(sim):
    h = hashlib.sha256()
    for k, v in sim.telemetry.ue_arrays().items():
        h.update(np.nan_to_num(v).tobytes())
    return h.hexdigest()


def test_deterministic_seed_fixed_and_array():
    for mode in ("fixed_gain", "array"):
        a = Simulation(tiny_cfg(radio={"antenna": {"mode": mode}}))
        b = Simulation(tiny_cfg(radio={"antenna": {"mode": mode}}))
        a.run(); b.run()
        assert digest(a) == digest(b) and a.summary()["mean_sinr_db"] == b.summary()["mean_sinr_db"]
    base, other = Simulation(tiny_cfg()), Simulation(tiny_cfg(simulation={"seed": 6}))
    base.run(); other.run()
    assert digest(base) != digest(other)                       # a different seed gives a different world


def test_traceability_chain_is_self_consistent():
    """SINR from the reported terms == SINR the simulator used; MCS/throughput follow from it (spec 108/117)."""
    sim = Simulation(tiny_cfg(simulation={"duration_s": 0.5}))
    sim.run()
    for u in range(sim.n_ue):
        t = sim.trace_ue(u)
        lb = {r["term"]: r["value"] for r in t["link_budget"]}
        assert lb["Received power"] == pytest.approx(30 + lb["Tx antenna gain"] + lb["Path loss"] + lb["Shadowing"] + lb["Rx antenna gain"], abs=1e-6)
        assert lb["SINR"] == pytest.approx(t["sinr"]["sinr_db"], abs=1e-6)
        assert t["link_adaptation"]["cqi"] == int(sim.la.cqi(t["sinr"]["sinr_db"] + t["sinr"]["fading_margin_db"]))
        comps = t["channel_model"]["path_loss_components_db"]
        assert comps["free_space_db"] + comps["excess_over_free_space_db"] + comps["molecular_absorption_db"] == pytest.approx(t["channel_model"]["path_loss_db"], abs=1e-6)
        thr = t["throughput"]
        assert thr["delivered_bps"] <= thr["achievable_rate_bps"] * thr["time_share"] * 1.0001 + 1e-6
        assert thr["delivered_bps"] <= thr["offered_bps"] * 1.5
        lat = t["latency_ms"]
        if lat["total_ms"] is not None:
            parts = sum(lat[k] for k in ("radio_ms", "queue_ms", "transport_ms", "edge_ms", "application_ms"))
            assert parts == pytest.approx(lat["total_ms"], abs=1e-9)
    assert "Reduced-Order THz" in sim.trace_ue(0)["channel_model"]["path_loss_model"]


def test_sinr_uses_noise_and_interference_correctly():
    sim = Simulation(tiny_cfg(simulation={"duration_s": 0.3}))
    sim.run()
    st = sim.state
    lin = st.signal_w / (st.interference_w + sim.noise_w)
    assert np.allclose(10 * np.log10(lin), st.sinr_db, atol=1e-6)
    assert np.all(st.interference_w >= 0) and np.all(np.isfinite(st.sinr_db))


def test_no_nan_inf_and_physical_bounds():
    sim = Simulation(tiny_cfg(simulation={"duration_s": 1.0}))
    s = sim.run()
    ue = sim.telemetry.ue_arrays()
    assert np.all(np.isfinite(ue["sinr_db"])) and np.all(np.isfinite(ue["throughput_bps"]))
    peak = sim.cfg.radio.bandwidth_hz * sim.la.efficiency.max() * (1 - sim.cfg.radio.overhead_fraction)
    assert ue["throughput_bps"].max() <= peak * 1.001
    assert 0 <= s["coverage_fraction"] <= 1 and s["energy_j"] > 0 and s["j_per_bit"] > 0


def test_events_emitted_and_typed():
    sim = Simulation(tiny_cfg(simulation={"duration_s": 3.0}))
    sim.run()
    c = sim.events.counts
    assert c[EventType.CHANNEL_UPDATE] == sim.cfg.simulation.n_epochs
    assert c[EventType.HANDOVER] >= 1 and c[EventType.UE_CONNECTED] >= 1


def test_array_beamforming_improves_coverage_and_sinr():
    """Slice 2: a 64-element array must beat a single 5 dBi element on the same scenario."""
    ov = {"simulation": {"duration_s": 1.0}}
    single = Simulation(tiny_cfg(**ov, radio={"antenna": {"mode": "fixed_gain", "bs_gain_dbi": 5.0}}))
    arr = Simulation(tiny_cfg(**ov, radio={"antenna": {"mode": "array", "beamformer": "mrt"}}))
    a, b = single.run(), arr.run()
    assert b["median_sinr_db"] > a["median_sinr_db"] + 8.0
    assert b["coverage_fraction"] > a["coverage_fraction"]


def test_mrt_at_least_as_good_as_codebook():
    ov = {"simulation": {"duration_s": 1.0}}
    mrt = Simulation(tiny_cfg(**ov, radio={"antenna": {"mode": "array", "beamformer": "mrt"}})).run()
    cb = Simulation(tiny_cfg(**ov, radio={"antenna": {"mode": "array", "beamformer": "codebook"}})).run()
    assert mrt["median_sinr_db"] >= cb["median_sinr_db"] - 0.5


def test_higher_frequency_lowers_sinr_same_geometry():
    lo = Simulation(tiny_cfg(simulation={"duration_s": 0.5}, radio={"carrier_frequency_hz": 28e9, "path_loss_model": "urban_micro"})).run()
    hi = Simulation(tiny_cfg(simulation={"duration_s": 0.5}, radio={"carrier_frequency_hz": 140e9})).run()
    assert lo["mean_sinr_db"] > hi["mean_sinr_db"]


def test_coverage_map_uses_same_models():
    sim = Simulation(tiny_cfg(simulation={"duration_s": 0.5}))
    sim.run()
    cov = sim.coverage_map(25.0)
    sinr = np.array([[np.nan if v is None else v for v in row] for row in cov["sinr_db"]], float)
    assert sinr.shape == (cov["ny"], cov["nx"]) and np.nanmax(sinr) > 10 and "Reduced-Order THz" in cov["model"]
    # the point closest to a gNB at UE height must have high SINR (sanity vs geometry)
    b = sim.bs_pos[0]
    ix = int((b[0] - cov["extent"][0]) // 25.0); iy = int((b[1] - cov["extent"][1]) // 25.0)
    assert sinr[iy, ix] > 10


def test_digital_twin_state_separation_and_divergence():
    twin = DigitalTwin(tiny_cfg(simulation={"duration_s": 0.5}))
    twin.step()
    pos = twin.sim.ue_pos.copy()
    twin.ingest_observation(ue_positions=pos + 1.0, sinr_db=twin.simulated_state.sinr_db + 2.0)
    d = twin.divergence()
    assert d["position_rmse_m"] == pytest.approx(np.sqrt(3.0), rel=1e-6) and d["sinr_rmse_db"] == pytest.approx(2.0)
    assert len(twin.history) == 1 and twin.network is twin.sim.topology
    with pytest.raises(Exception):
        twin.ingest_observation(ue_positions=np.zeros((2, 3)))


def test_saturation_is_reported_not_hidden():
    sim = Simulation(tiny_cfg(simulation={"duration_s": 1.0}, network={"traffic": {"rate_scale": 200.0}}))
    s = sim.run()
    assert s["packet_loss_ratio"] > 0.1 and s["latency_censored"] >= 0
