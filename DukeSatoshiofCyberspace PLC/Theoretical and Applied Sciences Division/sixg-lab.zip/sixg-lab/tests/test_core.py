import json
import logging

import numpy as np
import pytest
from hypothesis import given
from hypothesis import strategies as st

from sixglab.core import (
    ClockMode,
    ConfigurationError,
    EventBus,
    EventType,
    NumericalError,
    PhysicsError,
    RngFactory,
    SimulationClock,
)
from sixglab.core.logging import JsonFormatter, LogContext, get_logger
from sixglab.core.units import db_to_lin, dbm_to_w, lin_to_db, w_to_dbm
from sixglab.core.validation import (
    require_condition_ok,
    require_finite,
    require_nonnegative,
    require_positive,
)


def test_clock_integer_ticks_no_drift():
    c = SimulationClock(0.001, 60.0)
    for _ in range(600):
        c.advance(100)
    assert c.tick == 60000 and c.finished and c.time_s == pytest.approx(60.0, abs=1e-12)


def test_clock_pause_resume_and_replicate():
    c = SimulationClock(0.001, 1.0, ClockMode.ACCELERATED, 10.0)
    c.pause()
    assert c.paused
    with pytest.raises(ConfigurationError):
        c.advance()
    c.resume()
    assert c.mode == ClockMode.ACCELERATED
    r = c.for_replicate(3)
    assert r.mode == ClockMode.MONTE_CARLO and r.replicate == 3


def test_clock_realtime_pacing_sleeps():
    c = SimulationClock(0.01, 1.0, ClockMode.ACCELERATED, 100.0)
    c.advance(10)
    assert c.pace() >= 0.0


def test_clock_rejects_invalid():
    with pytest.raises(PhysicsError):
        SimulationClock(0.0, 1.0)
    with pytest.raises(ConfigurationError):
        SimulationClock(1.0, 0.5)


def test_event_bus_dispatch_and_history():
    bus = EventBus(history=3)
    got = []
    bus.subscribe(EventType.HANDOVER, got.append)
    allev = []
    bus.subscribe(None, allev.append)
    for i in range(5):
        bus.emit(i * 0.1, EventType.HANDOVER, "ue1", cell=i)
    bus.emit(1.0, EventType.BEAM_SWITCH, "ue1")
    assert len(got) == 5 and len(allev) == 6 and len(bus.history) == 3
    assert bus.counts[EventType.HANDOVER] == 5
    assert bus.recent(10, EventType.BEAM_SWITCH)[0].to_dict()["type"] == "BEAM_SWITCH"


def test_all_required_event_types_exist():
    required = {"UE_CONNECTED", "UE_DISCONNECTED", "HANDOVER", "BEAM_SWITCH", "CHANNEL_UPDATE", "PACKET_SENT", "PACKET_RECEIVED",
                "PACKET_DROPPED", "EDGE_TASK_CREATED", "EDGE_TASK_COMPLETED", "SATELLITE_HANDOVER", "SLICE_CREATED", "SLICE_UPDATED"}
    assert required <= {e.value for e in EventType}


def test_rng_streams_reproducible_and_independent():
    a, b = RngFactory(42), RngFactory(42)
    assert np.array_equal(a.stream("x").random(5), b.stream("x").random(5))
    assert not np.array_equal(a.stream("x").random(5), a.stream("y").random(5))
    assert not np.array_equal(RngFactory(1).stream("x").random(3), RngFactory(2).stream("x").random(3))
    assert a.replicate(1).seed != a.replicate(2).seed


def test_validation_errors_are_informative():
    with pytest.raises(PhysicsError, match="frequency"):
        require_positive("frequency", 0.0)
    with pytest.raises(PhysicsError):
        require_nonnegative("power", -1.0)
    with pytest.raises(NumericalError, match="non-finite"):
        require_finite("H", np.array([1.0, np.nan]))
    with pytest.raises(NumericalError, match="singular"):
        require_condition_ok("G", np.zeros((3, 3)))
    with pytest.raises(NumericalError):
        lin_to_db(np.array([-1.0]))


@given(st.floats(min_value=-150, max_value=150))
def test_db_roundtrip(x):
    assert lin_to_db(db_to_lin(x)) == pytest.approx(x, abs=1e-9)


@given(st.floats(min_value=-100, max_value=60))
def test_dbm_watt_roundtrip(x):
    assert w_to_dbm(dbm_to_w(x)) == pytest.approx(x, abs=1e-9)


def test_structured_log_has_required_fields():
    rec = logging.LogRecord("sixglab.radio", logging.INFO, "", 0, "channel_updated", (), None)
    rec.ctx = LogContext("sim1", "exp1", "scn1")
    rec.fields = {"n": 3}
    doc = json.loads(JsonFormatter().format(rec))
    for k in ("simulation_id", "experiment_id", "scenario_id", "timestamp", "component", "event"):
        assert k in doc
    assert doc["component"] == "radio" and doc["n"] == 3
    get_logger("x").info("smoke")
