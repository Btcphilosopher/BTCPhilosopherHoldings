import pytest
import yaml

from sixglab.config import load_scenario, scenario_from_dict
from sixglab.config.models import ScenarioConfig
from sixglab.core.errors import ConfigurationError


def test_defaults_match_spec_example():
    c = ScenarioConfig()
    assert c.simulation.duration_s == 60 and c.simulation.timestep_s == 0.001 and c.simulation.seed == 42
    assert c.radio.carrier_frequency_hz == 140e9 and c.radio.bandwidth_hz == 2e9 and c.radio.transmit_power_w == 1.0


def test_unknown_key_is_rejected():
    with pytest.raises(ConfigurationError, match="carier_frequency_hz"):
        scenario_from_dict({"radio": {"carier_frequency_hz": 1e9}})


@pytest.mark.parametrize("bad", [{"radio": {"carrier_frequency_hz": 0}}, {"radio": {"bandwidth_hz": -1}},
                                 {"radio": {"transmit_power_w": -1}}, {"radio": {"temperature_k": 0}},
                                 {"radio": {"antenna": {"rows": 0}}}, {"simulation": {"timestep_s": 0.0003, "update_interval_s": 0.1}}])
def test_invalid_values_rejected(bad):
    with pytest.raises(ConfigurationError):
        scenario_from_dict(bad)


def test_layered_loading_and_overrides(tmp_path):
    (tmp_path / "radio.yaml").write_text("radio: {bandwidth_hz: 1000000000}")
    sc = tmp_path / "s.yaml"
    sc.write_text(yaml.safe_dump({"name": "x", "radio": {"transmit_power_w": 2.0}}))
    c = load_scenario(sc, config_dir=tmp_path)
    assert c.radio.bandwidth_hz == 1e9 and c.radio.transmit_power_w == 2.0
    c2 = load_scenario(sc, config_dir=tmp_path, overrides={"radio": {"transmit_power_w": 3.0}})
    assert c2.radio.transmit_power_w == 3.0


def test_repo_config_dir_and_scenarios_load():
    c = load_scenario("scenarios/urban_6g.yaml")
    assert c.n_ues == 500 and c.network.base_stations == 12 and c.radio.antenna.n_elements == 64
    assert c.radio.carrier_frequency_hz == 140e9 and c.radio.bandwidth_hz == 2e9
