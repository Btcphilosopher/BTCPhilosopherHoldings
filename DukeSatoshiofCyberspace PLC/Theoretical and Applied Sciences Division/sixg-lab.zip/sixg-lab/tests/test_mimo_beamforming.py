import numpy as np
import pytest

from sixglab.beamforming import BeamManager, downlink_sinr, mmse, mrt, zf
from sixglab.beamforming.precoders import array_gain_db
from sixglab.channel.spatial import SpatialChannel
from sixglab.config import AntennaConfig
from sixglab.core.errors import ConfigurationError, NumericalError
from sixglab.mimo import AntennaArray, MIMOChannel, capacity_bps_hz


@pytest.mark.parametrize("nr,nt,kind", [(1, 1, "SISO"), (4, 1, "SIMO"), (1, 4, "MISO"), (4, 4, "MIMO"), (2, 64, "massive MIMO")])
def test_mimo_dimensions_and_kind(nr, nt, kind, rng):
    ch = MIMOChannel(nr, nt, rng)
    h = ch.rayleigh()
    assert h.shape == (nr, nt) and np.iscomplexobj(h) and ch.kind == kind
    assert ch.rayleigh(7).shape == (7, nr, nt)


def test_rayleigh_channel_statistics(rng):
    h = MIMOChannel(4, 4, rng).rayleigh(20000)
    assert np.mean(np.abs(h) ** 2) == pytest.approx(1.0, rel=0.03)
    assert abs(np.mean(h)) < 0.02


@pytest.mark.parametrize("n", [32, 64, 128, 256])
def test_massive_mimo_array_sizes(n):
    a = AntennaArray.ura(int(np.sqrt(n / 2)) if n in (32, 128) else int(np.sqrt(n)), int(n / (int(np.sqrt(n / 2)) if n in (32, 128) else int(np.sqrt(n)))), 140e9, element_gain_dbi=0.0)
    assert a.n_elements == n


def test_array_geometry_spacing_and_gain():
    a = AntennaArray.ura(8, 8, 140e9, 0.5, element_gain_dbi=0.0)
    lam = 299792458.0 / 140e9
    ys = np.unique(np.round(a.positions_m[:, 1], 12))
    assert np.allclose(np.diff(ys), lam / 2)
    h = a.response(np.array([1.0, 0, 0]))
    assert array_gain_db(h, np.conj(h) / np.linalg.norm(h)) == pytest.approx(10 * np.log10(64), abs=1e-9)
    assert a.ula(16, 28e9).n_elements == 16
    assert AntennaArray.custom(np.random.default_rng(0).normal(size=(5, 3)) * 1e-3, 140e9).response(np.array([1.0, 0, 0])).shape == (5,)
    with pytest.raises(ConfigurationError):
        AntennaArray(np.zeros((0, 3)), 1e9)


def test_separable_steering_matches_generic():
    a = AntennaArray.ura(4, 6, 140e9)
    u = np.random.default_rng(3).normal(size=(5, 3)); u /= np.linalg.norm(u, axis=1, keepdims=True)
    generic = np.exp(1j * a.k * (u @ a.positions_m.T))
    assert np.allclose(generic, a.steering(u))


def test_beam_points_toward_target_and_null_behind():
    a = AntennaArray.ura(8, 8, 140e9, element_gain_dbi=5.0)
    az = np.deg2rad(25.0)
    u = np.array([np.cos(az), np.sin(az), 0.0])
    w = np.conj(a.steering(u)) / 8.0
    scan = np.deg2rad(np.linspace(-60, 60, 241))
    gains = a.pattern_gain_db(w, np.column_stack([np.cos(scan), np.sin(scan), np.zeros_like(scan)]))
    assert np.rad2deg(scan[np.argmax(gains)]) == pytest.approx(25.0, abs=1.0)
    assert gains.max() == pytest.approx(5 * 1 + 10 * np.log10(64) + 10 * np.log10(np.cos(az) ** 0.0 * max(np.cos(az), 0) ** a._q), abs=0.15)
    assert a.element_gain(np.array([-1.0, 0, 0])) == 0.0                      # nothing radiated behind the panel


def test_downtilt_rotation():
    a = AntennaArray.ura(2, 2, 140e9, downtilt_rad=np.deg2rad(10))
    boresight = a.rotation @ np.array([1.0, 0, 0])
    assert boresight[2] == pytest.approx(-np.sin(np.deg2rad(10))) and boresight[0] == pytest.approx(np.cos(np.deg2rad(10)))


def test_mrt_zf_mmse_beamformers(rng):
    k, nt, sigma2 = 4, 64, 1e-4
    H = (rng.standard_normal((k, nt)) + 1j * rng.standard_normal((k, nt))) / np.sqrt(2)
    for W in (mrt(H, 1.0), zf(H, 1.0), mmse(H, sigma2, 1.0)):
        assert W.shape == (nt, k)
        assert np.sum(np.linalg.norm(W, axis=0) ** 2) == pytest.approx(1.0)
    G = np.abs(H @ zf(H)) ** 2
    assert np.max(G - np.diag(np.diag(G))) < 1e-12 * np.diag(G).min()
    s_mrt, s_zf, s_mmse = (downlink_sinr(H, W, sigma2) for W in (mrt(H), zf(H), mmse(H, sigma2)))
    assert s_zf.sum() > s_mrt.sum()
    assert s_mmse.sum() >= 0.99 * s_zf.sum()
    # MRT single user gain = ||h||^2 * P / sigma2
    h1 = H[:1]
    assert downlink_sinr(h1, mrt(h1, 2.0), sigma2)[0] == pytest.approx(2.0 * np.linalg.norm(h1) ** 2 / sigma2)


def test_zf_errors(rng):
    with pytest.raises(ConfigurationError):
        zf(rng.standard_normal((5, 3)) + 0j)
    with pytest.raises(NumericalError):
        zf(np.ones((2, 8), dtype=complex))                                    # identical users -> singular
    with pytest.raises(NumericalError):
        mrt(np.array([[np.nan + 0j, 1.0]]))


def test_capacity_scaling(rng):
    snr = 10 ** (10 / 10)
    c_siso = np.mean([capacity_bps_hz(MIMOChannel(1, 1, rng).rayleigh(), snr) for _ in range(400)])
    c_mimo = np.mean([capacity_bps_hz(MIMOChannel(4, 4, rng).rayleigh(), snr) for _ in range(400)])
    from scipy.special import exp1
    analytic = float(np.exp(1 / snr) * exp1(1 / snr) / np.log(2))              # ergodic Rayleigh capacity E[log2(1+snr|h|^2)]
    assert c_siso == pytest.approx(analytic, rel=0.06)
    assert c_mimo > 2.0 * c_siso


def test_spatial_channel_shapes_and_los_gain(rng):
    cfg = AntennaConfig(mode="array", rows=8, columns=8, panels=4)
    sc = SpatialChannel(cfg, 140e9)
    bs = np.array([[0.0, 0.0, 10.0]])
    ue = np.array([[60.0, 10.0, 1.5], [-40.0, -30.0, 1.5], [10.0, 80.0, 1.5]])
    los = np.ones((1, 3), bool)
    st = sc.generate(bs, ue, los, rng)
    assert st.h.shape == (1, 3, 2, 64) and st.panel.shape == (1, 3, 2)
    gain = np.max(np.linalg.norm(st.h, axis=-1) ** 2, axis=-1)                # ideal-beam gain
    assert np.all(gain > 10 ** (18 / 10) * 0.5)                                # ~ N * G_e minus pattern roll-off
    st2 = sc.generate(bs, ue, ~los, np.random.default_rng(1))
    assert np.max(np.linalg.norm(st2.h, axis=-1) ** 2) < np.max(gain) * 4      # scattered energy is bounded


def test_beam_manager_sweep_track_failure_recovery(rng):
    a = AntennaArray.ura(8, 8, 140e9)
    w, u, _ = a.codebook(16, 6)
    bm = BeamManager(w, 16, 6, sweep_period=4, failure_drop_db=10.0)
    target = 37
    h = np.tile(np.conj(w[target]) * 8.0, (3, 1))                             # channel matched to codebook beam 37
    r0 = bm.update(h)
    assert r0.swept and np.all(r0.beam_idx == target)
    r1 = bm.update(h)
    assert not r1.swept and not r1.switched.any()
    moved = np.tile(np.conj(w[target + 1]) * 8.0, (3, 1))                     # small motion: tracking follows a neighbour
    r2 = bm.update(moved)
    assert np.all(r2.beam_idx == target + 1) and r2.switched.all()
    far = np.tile(np.conj(w[90]) * 8.0, (3, 1))                               # big jump: failure -> recovery sweep
    before = bm.failures
    r3 = bm.update(far)
    assert r3.failed.all() and bm.failures == before + 3 and np.all(r3.beam_idx == 90)
