import numpy as np
import pytest

from sixglab.config import EnergyConfig
from sixglab.edge.server import EdgeServer
from sixglab.energy.model import base_station_power_w, joule_per_bit, wh_per_gb
from sixglab.network.handover import HandoverManager
from sixglab.network.scheduler import SlotMAC
from sixglab.network.topology import FIBRE_SPEED, NetworkGraph
from sixglab.network.traffic import PROFILES, assign_applications

DT = 1e-3


def run_mac(sched, n, rates, demand_pkts, epochs=20, pkt=1e3, slots=100, tags=20, seed=0, buffer=1e12):
    rng = np.random.default_rng(seed)
    mac = SlotMAC(n, sched, DT, 100, buffer, rng, tags_per_epoch=tags)
    served = np.zeros(n); delays = []; offered = np.zeros(n); dropped = np.zeros(n)
    for _ in range(epochs):
        arr = rng.poisson(np.asarray(demand_pkts)[None, :], (slots, n))
        r = mac.run_epoch(np.zeros(n, int), 1, np.ones(n, bool), np.asarray(rates, float), np.ones((slots, n), bool), arr, np.full(n, pkt))
        served += r.served_bits; offered += r.offered_bits; dropped += r.dropped_bits; delays.append(r.delays_s)
    return mac, served, offered, dropped, np.concatenate(delays)


def test_packet_latency_deterministic_case():
    """1 packet/slot, capacity 2 packets/slot -> every packet leaves half a slot after the slot boundary."""
    rng = np.random.default_rng(0)
    mac = SlotMAC(1, "round_robin", DT, 100, 1e12, rng, tags_per_epoch=50)
    d = []
    for _ in range(4):
        r = mac.run_epoch(np.array([0]), 1, np.array([True]), np.array([2e7]), np.ones((100, 1), bool), np.ones((100, 1), int), np.array([1e4]))
        d.append(r.delays_s)
    d = np.concatenate(d)
    assert d.size > 100 and np.allclose(d, 0.5 * DT, atol=1e-9)


def test_packet_latency_matches_batch_queue_analysis():
    """Poisson batch arrivals per slot, fluid service: mean delay of a random packet = (m + 2) / (2 C) slots (no backlog)."""
    m_pk, cap_pk = 12.0, 20.0
    _, _, _, _, d = run_mac("round_robin", 1, [cap_pk * 1e3 / DT], [m_pk], epochs=500, tags=40)
    assert d.mean() / DT == pytest.approx((m_pk + 2) / (2 * cap_pk), rel=0.08)


def test_mac_conservation_and_no_drop_below_capacity():
    mac, served, offered, dropped, _ = run_mac("proportional_fair", 5, [1e8] * 5, [3.0] * 5, epochs=15)
    assert dropped.sum() == 0
    assert np.allclose(served + mac.backlog, offered, rtol=0, atol=1e-6)


def test_overload_drops_at_buffer_limit_and_serves_capacity():
    mac, served, offered, dropped, _ = run_mac("round_robin", 2, [1e6, 1e6], [5.0, 5.0], epochs=10, buffer=5e4)
    assert dropped.sum() > 0
    assert served.sum() / (10 * 100 * DT) == pytest.approx(1e6, rel=0.03)         # carries exactly the link capacity
    assert np.allclose(served + dropped + mac.backlog, offered, atol=1e-6)


def test_scheduler_fairness_and_throughput_ordering():
    """Saturated cell, UEs with 10x rate spread: RR equalises airtime; max-throughput starves the weak UE."""
    rates = [1e9, 5e8, 1e8]
    res = {}
    for s in ("round_robin", "proportional_fair", "max_throughput"):
        _, served, *_ = run_mac(s, 3, rates, [4000.0] * 3, epochs=15, buffer=1e9)
        res[s] = served / served.sum()
    airtime = {s: None for s in res}
    for s in res:
        _, served, *_ = run_mac(s, 3, rates, [4000.0] * 3, epochs=15, buffer=1e9)
        airtime[s] = served / np.array(rates)
        airtime[s] /= airtime[s].sum()
    assert np.allclose(airtime["round_robin"], 1 / 3, atol=0.03)                      # equal time
    assert np.allclose(airtime["proportional_fair"], 1 / 3, atol=0.05)                # PF converges to equal time here
    assert airtime["max_throughput"][0] > 0.95                                        # best UE takes all
    tot = {s: run_mac(s, 3, rates, [4000.0] * 3, epochs=15, buffer=1e9)[1].sum() for s in res}
    assert tot["max_throughput"] > tot["round_robin"] * 1.2
    jain = lambda x: x.sum() ** 2 / (len(x) * (x**2).sum())  # noqa: E731
    thr_rr = run_mac("round_robin", 3, rates, [4000.0] * 3, epochs=15, buffer=1e9)[1]
    thr_mt = run_mac("max_throughput", 3, rates, [4000.0] * 3, epochs=15, buffer=1e9)[1]
    assert jain(thr_rr) > jain(thr_mt)


def test_mac_block_errors_leave_bits_queued():
    rng = np.random.default_rng(0)
    mac = SlotMAC(1, "round_robin", DT, 100, 1e12, rng)
    ok = np.zeros((100, 1), bool)
    r = mac.run_epoch(np.array([0]), 1, np.array([True]), np.array([1e8]), ok, np.full((100, 1), 2), np.array([1e3]))
    assert r.served_bits[0] == 0 and r.blocks_failed[0] > 0 and r.backlog_bits[0] == pytest.approx(2e3 * 100)


def test_unknown_scheduler():
    with pytest.raises(ValueError):
        SlotMAC(1, "nope", DT, 100, 1.0, np.random.default_rng(0))


def test_handover_hysteresis_ttt_success_failure_pingpong():
    hm = HandoverManager(1, hysteresis_db=3.0, ttt_s=0.3, interruption_s=0.02, failure_quality_db=-8.0, ping_pong_window_s=2.0)
    hm.initial_attach(np.array([[-70.0], [-80.0]]))
    q_ok = np.array([[10.0], [10.0]])
    assert hm.serving[0] == 0
    # target better by only 2 dB: below hysteresis -> nothing
    for k in range(10):
        assert hm.update(0.1 * k, 0.1, np.array([[-70.0], [-68.0]]), q_ok) == []
    # target better by 6 dB: needs TTT of 0.3 s
    ev = []
    for k in range(5):
        ev += hm.update(1.0 + 0.1 * k, 0.1, np.array([[-70.0], [-64.0]]), q_ok)
    assert len(ev) == 1 and ev[0][:4] == (0, 0, 1, True) and hm.serving[0] == 1 and not ev[0][4]
    # go back within the ping-pong window
    ev = []
    for k in range(5):
        ev += hm.update(1.6 + 0.1 * k, 0.1, np.array([[-60.0], [-70.0]]), q_ok)
    assert len(ev) == 1 and ev[0][4] is True and hm.stats.ping_pongs == 1
    # failure: target quality below the failure threshold
    hm2 = HandoverManager(1, 3.0, 0.1, 0.02, -8.0, 2.0)
    hm2.initial_attach(np.array([[-70.0], [-80.0]]))
    ev = []
    for k in range(4):
        ev += hm2.update(0.1 * k, 0.1, np.array([[-70.0], [-60.0]]), np.array([[10.0], [-20.0]]))
    assert ev and ev[0][3] is False and hm2.serving[0] == 0 and hm2.stats.failures == 1


def test_topology_latency_is_propagation_plus_hops():
    ng = NetworkGraph()
    ng.add_node("a", "gNB", (0, 0, 0)); ng.add_node("b", "edge_server", (2000, 0, 0))
    ng.add_link("a", "b", "fibre", 2000.0, per_hop_s=2e-5)
    assert ng.path_latency_s("a", "b") == pytest.approx(2000 / FIBRE_SPEED + 2e-5)
    with pytest.raises(ValueError):
        ng.add_node("x", "toaster")
    with pytest.raises(ValueError):
        ng.add_link("a", "b", "carrier-pigeon", 1.0)
    ng.add_node("s", "satellite"); ng.add_link("a", "s", "satellite", 550e3)
    assert ng.path_latency_s("a", "s") == pytest.approx(550e3 / 299792458.0)


def test_edge_server_matches_pollaczek_khinchine():
    srv = EdgeServer("e", cpu_cycles_per_s=1e9)
    lam, cyc = np.array([500.0]), np.array([1e6])                      # s = 1 ms, rho = 0.5, M/D/1
    resp, rho, sat = srv.response_time_s(lam, cyc)
    s = 1e-3
    assert rho == pytest.approx(0.5) and not sat
    assert resp[0] == pytest.approx(s + 0.5 * s / (2 * 0.5))          # W = rho s / (2(1-rho))
    resp2, rho2, sat2 = srv.response_time_s(np.array([990.0]), cyc)
    assert sat2 and resp2[0] == pytest.approx(s + srv.max_wait_s)      # saturation flagged, wait capped (never inf)
    assert srv.power_w(0.0) == srv.idle_power_w and srv.power_w(2.0) == srv.max_power_w


def test_energy_model_analytic():
    cfg = EnergyConfig(bs_static_w=60, bs_chain_w=1.0, pa_efficiency=0.2, cooling_overhead=0.1)
    idle = base_station_power_w(cfg, 64, 1.0, 0.0)
    full = base_station_power_w(cfg, 64, 1.0, 1.0)
    assert idle == pytest.approx((60 + 64) * 1.1) and full == pytest.approx((60 + 64 + 5) * 1.1)
    assert joule_per_bit(10.0, 5.0) == 2.0
    assert wh_per_gb(3600.0, 8e9) == pytest.approx(1.0)                # 1 Wh per GB
    assert np.isnan(joule_per_bit(1.0, 0.0))


def test_traffic_profiles():
    assert {"web", "video", "voice", "xr", "industrial_control", "iot", "robotics", "autonomous_vehicle", "digital_twin"} <= set(PROFILES)
    apps = assign_applications(2000, {"video": 0.5, "iot": 0.5}, np.random.default_rng(0))
    assert abs(sum(a.name == "video" for a in apps) / 2000 - 0.5) < 0.05
    with pytest.raises(Exception):
        assign_applications(3, {"hologram": 1.0}, np.random.default_rng(0))


@pytest.mark.parametrize("sched", ["round_robin", "proportional_fair", "max_throughput"])
def test_scheduler_is_work_conserving_no_starvation_with_spare_airtime(sched):
    """Regression: 40 UEs, rates spanning 50x, total demand ~10% of airtime -> every UE must receive its demand.
    (An earlier version capped UEs per slot and starved low-rate UEs while 90% of the airtime was idle.)"""
    n = 40
    rates = np.where(np.arange(n) % 2 == 0, 1.2e10, 2.6e8)
    demand_pkts = np.full(n, 0.3)                                   # 0.3 packets/slot of 1 kbit -> 300 kb/s each
    _, served, offered, dropped, d = run_mac(sched, n, rates, demand_pkts, epochs=20, buffer=1e12)
    assert dropped.sum() == 0
    assert np.all(served > 0.9 * offered)
    assert np.percentile(d, 95) < 5e-3
