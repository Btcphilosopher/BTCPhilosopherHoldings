import numpy as np
import pytest

from sixglab.config import EnvironmentConfig
from sixglab.core import RngFactory
from sixglab.mobility import build_model
from sixglab.radio.environment import RadioEnvironment


@pytest.fixture(scope="module")
def env():
    return RadioEnvironment.generate_city(EnvironmentConfig(), RngFactory(3).stream("env"))


def _run(kind, env, seed=1, n=20, steps=200, dt=0.1, **kw):
    m = build_model(kind, n, RngFactory(seed).stream("m"), env, **kw)
    traj = []
    for _ in range(steps):
        m.step(dt)
        traj.append(m.pos.copy())
    return m, np.array(traj)


@pytest.mark.parametrize("kind", ["static", "random_walk", "random_waypoint", "pedestrian", "vehicle", "train", "uav"])
def test_every_ue_has_reproducible_trajectory(kind, env):
    _, a = _run(kind, env, seed=7, steps=50)
    _, b = _run(kind, env, seed=7, steps=50)
    _, c = _run(kind, env, seed=8, steps=50)
    assert np.array_equal(a, b)
    if kind not in ("static", "train"):
        assert not np.array_equal(a, c)                        # a different seed gives a different trajectory


def test_static_does_not_move(env):
    _, t = _run("static", env, steps=20)
    assert np.all(t == t[0])


def test_positions_stay_in_map_and_out_of_buildings(env):
    x0, y0, x1, y1 = env.extent
    for kind in ("random_walk", "random_waypoint", "pedestrian", "vehicle"):
        _, t = _run(kind, env, steps=150)
        assert t[..., 0].min() >= x0 - 5 and t[..., 0].max() <= x1 + 5 and t[..., 1].min() >= y0 - 5 and t[..., 1].max() <= y1 + 5
        assert not env.is_inside_building(t[..., :2].reshape(-1, 2), 1.5).any(), kind


def test_speeds_match_configuration(env):
    m, t = _run("vehicle", env, n=30, steps=300, speed_mps=13.9)
    v = np.linalg.norm(np.diff(t[100:, :, :2], axis=0), axis=2) / 0.1
    assert 8 < np.median(v) < 18
    m, t = _run("pedestrian", env, n=30, steps=300)
    v = np.linalg.norm(np.diff(t[100:, :, :2], axis=0), axis=2) / 0.1
    assert 0.8 < np.median(v) < 1.8
    m, t = _run("train", env, n=3, steps=50, speed_mps=40.0)
    assert np.allclose(np.linalg.norm(m.vel[:, :2], axis=1), 40.0)


def test_vehicle_acceleration_limit(env):
    m = build_model("vehicle", 10, RngFactory(2).stream("m"), env, speed_mps=15.0)
    speeds = []
    for _ in range(40):
        m.step(0.1)
        speeds.append(m.speed.copy())
    dv = np.diff(np.array(speeds), axis=0) / 0.1
    assert dv.max() <= 2.5 + 1e-9


def test_vehicle_follows_given_route(env):
    m = build_model("vehicle", 1, RngFactory(2).stream("m"), env, speed_mps=15.0)
    nodes = [int(x) for x in env.roads.neighbours[int(m.to[0])][:1]]
    m.set_route(0, nodes * 1)
    for _ in range(400):
        m.step(0.1)
    assert env.roads.n_nodes > 0 and np.all(np.isfinite(m.pos))


def test_uav_altitude_constant(env):
    m, t = _run("uav", env, n=5, steps=80, height_m=80.0)
    assert np.allclose(t[..., 2], 80.0)
