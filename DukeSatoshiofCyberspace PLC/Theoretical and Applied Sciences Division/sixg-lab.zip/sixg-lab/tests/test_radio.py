import numpy as np
import pytest
from hypothesis import given
from hypothesis import strategies as st

from sixglab.channel.thz import THzChannelModel
from sixglab.config import EnvironmentConfig
from sixglab.core import RngFactory
from sixglab.core.errors import ConfigurationError, NumericalError, PhysicsError
from sixglab.core.units import K_BOLTZMANN
from sixglab.radio.atmosphere import absorption_loss_db, specific_attenuation_db_per_km
from sixglab.radio.coding import PolarCoder, UncodedCoder, bpsk_awgn_llr
from sixglab.radio.environment import Building, RadioEnvironment, RoadNetwork, Weather
from sixglab.radio.link_budget import LinkBudget
from sixglab.radio.mcs import LinkAdaptation
from sixglab.radio.modulation import SCHEMES, ber_test, demodulate, modulate, theoretical_ber_awgn
from sixglab.radio.noise import thermal_noise_dbm, thermal_noise_power_w
from sixglab.radio.ofdm import OFDMConfig, OFDMModem
from sixglab.radio.pathloss import FreeSpace, Indoor, LogDistance, Rural, UrbanMacro, UrbanMicro, fspl_db


def test_free_space_path_loss():
    assert fspl_db(1000.0, 1e9) == pytest.approx(92.4478, abs=1e-3)
    assert fspl_db(200, 140e9) - fspl_db(100, 140e9) == pytest.approx(6.0206, abs=1e-4)
    assert fspl_db(100, 280e9) - fspl_db(100, 140e9) == pytest.approx(6.0206, abs=1e-4)
    with pytest.raises(PhysicsError):
        fspl_db(0.0, 1e9)


@given(st.floats(1, 5000), st.floats(1, 5000))
def test_fspl_monotone_in_distance(a, b):
    lo, hi = sorted((a, b))
    assert fspl_db(lo, 140e9) <= fspl_db(hi, 140e9) + 1e-12


def test_thermal_noise():
    assert thermal_noise_dbm(1.0, 290.0) == pytest.approx(-173.975, abs=0.01)
    assert thermal_noise_power_w(1e6, 300.0) == pytest.approx(K_BOLTZMANN * 300 * 1e6)
    assert thermal_noise_dbm(2e9, 290, 10) == pytest.approx(-173.975 + 10 * np.log10(2e9) + 10, abs=0.01)
    for bad in ((0, 290, 0), (1e6, 0, 0), (1e6, 290, -1)):
        with pytest.raises(PhysicsError):
            thermal_noise_power_w(*bad)


def test_link_budget_chain_and_sinr():
    lb = LinkBudget(1.0, 20.0, 10.0, 120.0, 3.0, 5.0, 0.0, 1e9, 290.0, 8.0, 0.0)
    assert lb.rx_power_dbm == pytest.approx(30 + 20 + 5 - 120 - 3 + 10)
    assert lb.snr_db == pytest.approx(lb.rx_power_dbm - lb.noise_dbm)
    assert lb.sinr_db == pytest.approx(lb.snr_db, abs=1e-9)
    noisy = LinkBudget(1.0, 20.0, 10.0, 120.0, 3.0, 5.0, 0.0, 1e9, 290.0, 8.0, lb.noise_w)
    assert noisy.sinr_db == pytest.approx(lb.snr_db - 10 * np.log10(2), abs=1e-6)
    assert lb.terms()[-1]["term"] == "SINR"


def test_3gpp_formulas_reference_values():
    d = np.array([100.0])
    ones = np.array([True])
    umi = UrbanMicro().compute(d, d, ones, 3.5e9, 10, 1.5)
    assert umi.loss_db[0] == pytest.approx(32.4 + 42 + 20 * np.log10(3.5), abs=1e-9)
    assert "38.901" in umi.model_id
    nlos = UrbanMicro().compute(d, d, ~ones, 3.5e9, 10, 1.5)
    assert nlos.loss_db[0] >= umi.loss_db[0]
    assert nlos.loss_db[0] == pytest.approx(35.3 * 2 + 22.4 + 21.3 * np.log10(3.5) - 0.3 * 0.0, abs=1e-9)
    uma = UrbanMacro().compute(np.array([500.0]), np.array([500.0]), ones, 3.5e9, 25, 1.5)
    assert 90 < uma.loss_db[0] < 130
    assert Indoor().compute(d, d, ones, 28e9, 3, 1.5).loss_db[0] == pytest.approx(32.4 + 17.3 * 2 + 20 * np.log10(28))
    assert Rural().compute(np.array([1000.0]), np.array([1000.0]), ones, 3.5e9, 35, 1.5).loss_db[0] > 80
    assert FreeSpace().compute(d, d, ones, 1e9, 10, 1.5).loss_db[0] == pytest.approx(fspl_db(100, 1e9))
    ld = LogDistance(3.0).compute(np.array([100.0]), d, ones, 1e9, 10, 1.5)
    assert ld.loss_db[0] == pytest.approx(fspl_db(1.0, 1e9) + 60)


def test_pathloss_flags_extrapolation():
    r = UrbanMicro().compute(np.array([50.0]), np.array([50.0]), np.array([True]), 140e9, 10, 1.5)
    assert "outside" in r.validity_note
    assert UrbanMicro().compute(np.array([50.0]), np.array([50.0]), np.array([True]), 28e9, 10, 1.5).validity_note == ""


def test_molecular_absorption_reasonable_envelope():
    g = lambda f: float(specific_attenuation_db_per_km(f))  # noqa: E731
    assert g(3.5e9) < 0.05 and g(28e9) < 0.5
    assert 8 < g(60e9) < 25            # oxygen complex
    assert 0.5 < g(140e9) < 4          # atmospheric window
    assert g(183e9) > 10               # water line
    assert g(183e9) > 5 * g(140e9)
    dry = float(specific_attenuation_db_per_km(183e9, 0.0))
    assert dry < 0.1 * g(183e9)        # water lines vanish without vapour
    assert absorption_loss_db(2000.0, 140e9) == pytest.approx(2 * g(140e9))


def test_thz_model_components_and_guardrails():
    m = THzChannelModel(7.5)
    d = np.array([100.0, 300.0])
    r = m.compute(d, d, np.array([True, True]), 140e9, 10, 1.5)
    assert set(r.components) >= {"free_space_db", "molecular_absorption_db", "excess_over_free_space_db"}
    assert np.allclose(r.loss_db, r.components["free_space_db"] + r.components["excess_over_free_space_db"] + r.components["molecular_absorption_db"])
    assert "Reduced-Order THz" in r.model_id and r.validity_note
    with pytest.raises(ConfigurationError):
        THzChannelModel(7.5, rain_rate_mm_h=10.0)


def _wall_env():
    import networkx as nx
    g = nx.Graph(); g.add_node(0, pos=(0.0, 0.0)); g.add_node(1, pos=(1.0, 0.0)); g.add_edge(0, 1)
    return RadioEnvironment((0, 0, 100, 100), [Building(45, 0, 55, 100, 20.0)], RoadNetwork(g), Weather(), 1.0, 200)


def test_los_blocked_by_building_and_clear_over_it():
    env = _wall_env()
    assert not env.los(np.array([[10, 50, 10.0]]), np.array([[90, 50, 1.5]]))[0, 0]      # through the wall
    assert env.los(np.array([[10, 50, 60.0]]), np.array([[90, 50, 1.5]]))[0, 0]          # ray passes above the roof
    assert env.los(np.array([[10, 50, 10.0]]), np.array([[30, 50, 1.5]]))[0, 0]          # same side
    assert env.is_inside_building(np.array([[50.0, 50.0]]))[0]


def test_city_generation_deterministic_and_consistent():
    a = RadioEnvironment.generate_city(EnvironmentConfig(), RngFactory(1).stream("e"))
    b = RadioEnvironment.generate_city(EnvironmentConfig(), RngFactory(1).stream("e"))
    assert a.buildings == b.buildings and np.array_equal(a.height_map, b.height_map)
    bs = a.place_base_stations(12, 10.0)
    assert bs.shape == (12, 3) and len({tuple(p[:2]) for p in bs}) == 12
    assert not a.is_inside_building(bs[:, :2], 5.0).any()
    with pytest.raises(ConfigurationError):
        a.place_base_stations(10_000, 10.0)


def test_mcs_thresholds_monotone_and_shannon_gap():
    la = LinkAdaptation(3.0)
    th = la.thresholds_db
    assert np.all(np.diff(th) > 0) and len(th) == 15
    eta = la.efficiency[1:]
    assert np.all(eta <= np.log2(1 + 10 ** (th / 10)) + 1e-9)             # never exceeds capacity at its threshold
    assert th[0] == pytest.approx(10 * np.log10(10 ** 0.3 * (2 ** eta[0] - 1)), abs=1e-9)
    assert la.cqi(-20.0) == 0 and la.cqi(40.0) == 15
    assert la.efficiency[15] == pytest.approx(8 * 948 / 1024)
    assert la.modulation_name(15) == "256-QAM" and la.modulation_name(1) == "QPSK"


@pytest.mark.parametrize("scheme", list(SCHEMES))
def test_qam_roundtrip_and_unit_energy(scheme, rng):
    k = int(np.log2(SCHEMES[scheme]))
    bits = rng.integers(0, 2, 20000 * k, dtype=np.uint8)
    sym = modulate(bits, scheme)
    assert np.array_equal(demodulate(sym, scheme), bits)
    assert np.mean(np.abs(sym) ** 2) == pytest.approx(1.0, abs=0.02)


def test_gray_mapping_neighbours_differ_by_one_bit():
    bits = np.array([[int(c) for c in f"{i:04b}"] for i in range(16)], dtype=np.uint8)
    sym = modulate(bits.ravel(), "16-QAM")
    for i in range(16):
        for j in range(i + 1, 16):
            if abs(sym[i] - sym[j]) < 2.01 / np.sqrt(10):                 # nearest neighbours (grid step 2/sqrt(10))
                assert np.sum(bits[i] != bits[j]) == 1


@pytest.mark.parametrize("scheme,eb", [("QPSK", 6.0), ("16-QAM", 8.0), ("64-QAM", 11.0)])
def test_ber_matches_theory(scheme, eb, rng):
    th = float(theoretical_ber_awgn(eb, scheme))
    assert ber_test(scheme, eb, 800_000, rng) == pytest.approx(th, rel=0.15)


def test_modulation_errors():
    with pytest.raises(ConfigurationError):
        modulate(np.array([0, 1, 0]), "16-QAM")
    with pytest.raises(ConfigurationError):
        modulate(np.array([0, 1]), "BPSK")


def test_ofdm_roundtrip_and_multipath(rng):
    cfg = OFDMConfig(fft_size=256, subcarrier_spacing_hz=1e6, cp_length=32, num_subcarriers=200)
    m = OFDMModem(cfg)
    grid = rng.standard_normal((6, 200)) + 1j * rng.standard_normal((6, 200))
    tx = m.modulate(grid)
    assert tx.shape == (6, 288)
    assert np.allclose(m.demodulate(tx), grid, atol=1e-12)
    assert np.mean(np.abs(tx) ** 2) == pytest.approx(200 / 256 * np.mean(np.abs(grid) ** 2), rel=0.1)   # power ~ occupied fraction
    h = np.array([1.0, 0.4j, -0.2, 0.1])
    rx = np.stack([np.convolve(r, h)[: r.size] for r in tx])
    hf = np.fft.fft(h, 256)[m.bins]
    assert np.allclose(m.demodulate(rx) / hf, grid, atol=1e-10)
    assert cfg.sample_rate_hz == 256e6 and cfg.symbol_duration_s == pytest.approx(288 / 256e6)
    assert cfg.occupied_bandwidth_hz == 200e6 and cfg.num_resource_blocks == 16


def test_ofdm_cp_shorter_than_delay_spread_breaks_orthogonality(rng):
    cfg = OFDMConfig(fft_size=128, subcarrier_spacing_hz=1e6, cp_length=2, num_subcarriers=100)
    m = OFDMModem(cfg)
    grid = rng.standard_normal((4, 100)) + 0j
    tx = m.modulate(grid)
    h = np.zeros(10); h[0], h[9] = 1.0, 0.8
    rx = np.stack([np.convolve(r, h)[: r.size] for r in tx])
    hf = np.fft.fft(h, 128)[m.bins]
    assert np.max(np.abs(m.demodulate(rx) / hf - grid)) > 0.05          # ISI/ICI appears: the test is not vacuous


def test_ofdm_pilots_and_config_validation():
    cfg = OFDMConfig(fft_size=64, subcarrier_spacing_hz=1e6, cp_length=8, num_subcarriers=48, pilot_spacing=6)
    m = OFDMModem(cfg)
    n_data = int((~cfg.pilot_mask()).sum())
    grid = m.insert_pilots(np.ones(n_data * 2), 2 + 0j)
    assert grid.shape == (2, 48) and np.all(grid[:, cfg.pilot_mask()] == 2)
    for bad in (dict(fft_size=100), dict(fft_size=64, num_subcarriers=64), dict(fft_size=64, cp_length=64, num_subcarriers=10)):
        with pytest.raises(ConfigurationError):
            OFDMConfig(**bad)


def test_polar_code_has_real_coding_gain(rng):
    pc = PolarCoder(8, 128)
    assert pc.rate == 0.5 and len(pc.info) == 128
    bits = rng.integers(0, 2, 128, dtype=np.uint8)
    assert np.array_equal(pc.decode(bpsk_awgn_llr(pc.encode(bits), 30.0, pc.rate, rng)), bits)   # noiseless round trip
    err_c = err_u = n = 0
    for _ in range(120):
        b = rng.integers(0, 2, 128, dtype=np.uint8)
        err_c += int(np.sum(pc.decode(bpsk_awgn_llr(pc.encode(b), 3.0, pc.rate, rng)) != b))
        u = UncodedCoder()
        err_u += int(np.sum(u.decode(bpsk_awgn_llr(u.encode(b), 3.0, 1.0, rng)) != b))
        n += 128
    assert err_c / n < 0.3 * err_u / n


def test_numerical_guards():
    from sixglab.core.validation import require_finite
    with pytest.raises(NumericalError):
        require_finite("x", np.array([np.inf]))
