"""TelemetryRecorder: per-epoch aggregate metrics + per-UE arrays. Stored as Parquet (metrics),
NPZ (per-UE arrays) and JSON (summary/provenance). CSV is deliberately not used for internal telemetry."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from sixglab.core.errors import NumericalError


def _clean(o: Any) -> Any:
    if isinstance(o, dict):
        return {k: _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, np.ndarray):
        return _clean(o.tolist())
    if isinstance(o, (np.floating, float)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return o


def to_jsonable(o: Any) -> Any:
    """NaN/Inf -> null so that the payload is valid JSON."""
    return _clean(o)


class TelemetryRecorder:
    UE_FIELDS = ("x", "y", "z", "serving", "sinr_db", "throughput_bps", "latency_ms", "cqi")

    def __init__(self) -> None:
        self.metrics: list[dict[str, float]] = []
        self.ue: dict[str, list[np.ndarray]] = {k: [] for k in self.UE_FIELDS}

    def record(self, metrics: dict[str, float], ue: dict[str, np.ndarray]) -> None:
        for k, v in metrics.items():
            if isinstance(v, float) and np.isinf(v):
                raise NumericalError(f"infinite telemetry value for {k!r}")
        self.metrics.append(dict(metrics))
        for k in self.UE_FIELDS:
            self.ue[k].append(np.asarray(ue[k], dtype=np.float32))

    def __len__(self) -> int:
        return len(self.metrics)

    def dataframe(self) -> pd.DataFrame:
        return pd.DataFrame(self.metrics)

    def ue_arrays(self) -> dict[str, np.ndarray]:
        return {k: np.stack(v) for k, v in self.ue.items() if v}

    def save(self, out_dir: str | Path, summary: dict[str, Any]) -> dict[str, Path]:
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        paths = {"metrics": out / "metrics.parquet", "ue": out / "ue_frames.npz", "summary": out / "summary.json"}
        self.dataframe().to_parquet(paths["metrics"], index=False)
        np.savez_compressed(paths["ue"], **self.ue_arrays())  # type: ignore[arg-type]
        paths["summary"].write_text(json.dumps(to_jsonable(summary), indent=2))
        return paths
