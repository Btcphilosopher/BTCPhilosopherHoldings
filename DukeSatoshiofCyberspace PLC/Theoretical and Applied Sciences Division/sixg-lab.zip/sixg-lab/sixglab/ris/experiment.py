"""RIS with/without comparison on a live Simulation snapshot (actual link-budget results, spec slice 3).

Direct field amplitude comes from the simulator's serving-link signal power; the RIS cascade uses the same gNB
transmit power/gain, geometric LoS tests (gNB->RIS and RIS->UE must both be LoS) and the reduced-order molecular
absorption. Interference and noise are held at the simulator's values, so SINR changes only through the signal.
"""
from __future__ import annotations

from typing import Any

import numpy as np

from sixglab.core.units import db_to_lin, lin_to_db
from sixglab.ris.surface import RIS, coordinate_descent, gradient_ascent, total_field


def evaluate_ris(sim, ris: RIS, ue_indices: np.ndarray, method: str = "coordinate_descent",
                 seed: int = 0) -> dict[str, Any]:
    st = sim.state
    rad = sim.cfg.radio
    u = np.asarray(ue_indices, dtype=int)
    b = st.serving[u]
    tx = sim.bs_pos[b]
    rx = sim.ue_pos[u]
    g_tx = float(db_to_lin(rad.antenna.element_gain_dbi + 10 * np.log10(rad.antenna.n_elements))) if sim.array_mode \
        else sim.g_bs_fixed
    C = np.zeros((len(u), ris.n), dtype=complex)
    ok = np.zeros(len(u), dtype=bool)
    for i in range(len(u)):
        los_tx = sim.env.los(tx[i][None], ris.position[None])[0, 0]
        los_rx = sim.env.los(ris.position[None], rx[i][None])[0, 0]
        if los_tx and los_rx:
            C[i] = ris.cascade(tx[i], rx[i], sim.p_tx, g_tx, sim.g_ue, rad.water_vapour_density_g_m3)
            ok[i] = True
    d_dir = np.linalg.norm(tx - rx, axis=1)
    direct = np.sqrt(st.signal_w[u]) * np.exp(-1j * ris.k * d_dir)
    rng = np.random.default_rng(seed)
    ris.phases = ris.quantise(rng.uniform(0, 2 * np.pi, ris.n))
    p_random = np.abs(total_field(direct, C, ris.reflection())) ** 2
    ris.phases = np.zeros(ris.n)
    if method == "coordinate_descent":
        ris.phases = coordinate_descent(direct, C, ris)
    elif method == "gradient":
        ris.phases = gradient_ascent(direct, C, ris)
    else:
        raise ValueError(f"unknown RIS optimisation method {method!r}")
    p_after = np.abs(total_field(direct, C, ris.reflection())) ** 2
    p_before = np.abs(direct) ** 2
    noise_i = sim.noise_w + st.interference_w[u]
    la = sim.la
    sinr_b, sinr_a = lin_to_db(p_before / noise_i), lin_to_db(p_after / noise_i)
    rate = lambda s: sim.cfg.radio.bandwidth_hz * la.spectral_efficiency(s + sim.fading_margin_db) * (1 - rad.overhead_fraction)  # noqa: E731
    return {
        "method": method, "n_elements": ris.n, "phase_bits": ris.phase_bits, "amplitude_limit": ris.max_amplitude,
        "objective": "maximise sum received power (equivalently SINR at fixed interference)",
        "constraints": "phase in [0, 2pi) quantised to phase_bits; passive amplitude <= max_amplitude",
        "ue": u.tolist(), "ris_visible": ok.tolist(),
        "rx_power_dbm_without": (lin_to_db(p_before) + 30).tolist(),
        "rx_power_dbm_random_phase": (lin_to_db(p_random) + 30).tolist(),
        "rx_power_dbm_with": (lin_to_db(p_after) + 30).tolist(),
        "sinr_db_without": sinr_b.tolist(), "sinr_db_with": sinr_a.tolist(),
        "rate_bps_without": rate(sinr_b).tolist(), "rate_bps_with": rate(sinr_a).tolist(),
        "mean_gain_db": float(np.mean(lin_to_db(p_after) - lin_to_db(p_before))),
    }


def find_ris_site(sim, ue_indices: np.ndarray, height_m: float = 10.0, offset_m: float = 2.5, n_along: int = 3):
    """Search building faces (``n_along`` candidate points per face) for the RIS site that serves the most target UEs:
    LoS to the UE, LoS to the UE's serving gNB, and both on the front side of the panel. A geometric search over the
    environment. ``offset_m`` must exceed the raster resolution so the panel is not inside an obstacle cell.
    Returns (position, normal, n_visible)."""
    best: tuple[Any, Any, int] = (None, None, -1)
    u = np.asarray(ue_indices, dtype=int)
    b = sim.state.serving[u]
    x0, y0, x1, y1 = sim.env.extent
    for bd in sim.env.buildings:
        if bd.height < height_m + 1:
            continue
        faces = []
        for f in np.linspace(0.1, 0.9, n_along):
            xa, ya = bd.x_min + f * (bd.x_max - bd.x_min), bd.y_min + f * (bd.y_max - bd.y_min)
            faces += [((0, -1), (xa, bd.y_min - offset_m)), ((0, 1), (xa, bd.y_max + offset_m)),
                      ((-1, 0), (bd.x_min - offset_m, ya)), ((1, 0), (bd.x_max + offset_m, ya))]
        for nrm, (px, py) in faces:
            if not (x0 < px < x1 and y0 < py < y1):
                continue
            pos = np.array([px, py, height_m])
            nvec = np.array([nrm[0], nrm[1], 0.0])
            los_u = sim.env.los(pos[None], sim.ue_pos[u])[0]
            los_b = sim.env.los(sim.bs_pos, pos[None])[:, 0][b]
            front = ((sim.ue_pos[u] - pos) @ nvec > 0) & ((sim.bs_pos[b] - pos) @ nvec > 0)
            score = int(np.sum(los_u & los_b & front))
            if score > best[2]:
                best = (pos, nvec, score)
    return best
