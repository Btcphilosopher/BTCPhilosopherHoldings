"""Reconfigurable Intelligent Surface: physical cascade model + phase optimisation.

Two-hop Friis cascade per element n (each element re-radiates the power it captures, amplitude scaled by beta_n<=1):

    P_n = P_t G_t G_r  G0^2 cos(th_in) cos(th_out)  (lambda / 4 pi)^4 / (d1_n d2_n)^2 ,   c_n = sqrt(P_n) e^{-jk(d1_n + d2_n)}

Received field at the UE:  y = c_direct + sum_n beta_n e^{j theta_n} c_n     (power |y|^2, coherent sum).
Coherent alignment therefore gives the well-known N^2 scaling of received power. Element gain G0 = 4 pi A_e/lambda^2
with A_e = (spacing)^2. Molecular absorption on both hops is included through the reduced-order atmosphere model.
Limitations: far-field per-element model, no mutual coupling, ideal reflection phase response, one-sided panel.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from sixglab.core.errors import ConfigurationError
from sixglab.core.units import C_LIGHT
from sixglab.radio.atmosphere import absorption_loss_db


@dataclass
class RIS:
    position: np.ndarray
    normal: np.ndarray
    rows: int
    columns: int
    frequency_hz: float
    spacing_wavelengths: float = 0.5
    phase_bits: int | None = None        # None = continuous phase
    max_amplitude: float = 1.0
    phases: np.ndarray = field(default=None)          # type: ignore[arg-type]
    amplitude: np.ndarray = field(default=None)       # type: ignore[arg-type]

    def __post_init__(self) -> None:
        self.position = np.asarray(self.position, float)
        nrm = np.asarray(self.normal, float)
        self.normal = nrm / np.linalg.norm(nrm)
        if self.rows < 1 or self.columns < 1 or not (0 < self.max_amplitude <= 1.0):
            raise ConfigurationError("invalid RIS size or amplitude limit (passive surface: 0 < beta <= 1)")
        self.n = self.rows * self.columns
        self.lam = C_LIGHT / self.frequency_hz
        self.k = 2 * np.pi / self.lam
        self.d = self.spacing_wavelengths * self.lam
        self.g0 = 4 * np.pi * self.d**2 / self.lam**2
        up = np.array([0.0, 0.0, 1.0]) if abs(self.normal[2]) < 0.99 else np.array([1.0, 0, 0])
        t1 = np.cross(up, self.normal)
        t1 /= np.linalg.norm(t1)
        t2 = np.cross(self.normal, t1)
        ii, jj = np.meshgrid((np.arange(self.columns) - (self.columns - 1) / 2) * self.d,
                             (np.arange(self.rows) - (self.rows - 1) / 2) * self.d)
        self.element_pos = self.position + ii.ravel()[:, None] * t1 + jj.ravel()[:, None] * t2
        if self.phases is None:
            self.phases = np.zeros(self.n)
        if self.amplitude is None:
            self.amplitude = np.full(self.n, self.max_amplitude)

    def quantise(self, phases: np.ndarray) -> np.ndarray:
        ph = np.mod(phases, 2 * np.pi)
        if self.phase_bits is None:
            return ph
        levels = 2**self.phase_bits
        return np.mod(np.round(ph / (2 * np.pi) * levels), levels) * 2 * np.pi / levels

    def cascade(self, tx_pos, rx_pos, tx_power_w: float, g_tx_lin: float, g_rx_lin: float,
                water_vapour: float = 7.5, include_absorption: bool = True) -> np.ndarray:
        """Complex per-element coefficients c_n (before reflection coefficient), shape (N,).
        Elements with the Tx or Rx behind the panel contribute zero."""
        tx, rx = np.asarray(tx_pos, float), np.asarray(rx_pos, float)
        v1, v2 = tx - self.element_pos, rx - self.element_pos
        d1, d2 = np.linalg.norm(v1, axis=1), np.linalg.norm(v2, axis=1)
        c_in = (v1 @ self.normal) / d1
        c_out = (v2 @ self.normal) / d2
        front = (c_in > 0) & (c_out > 0)
        p = (tx_power_w * g_tx_lin * g_rx_lin * self.g0**2 * np.maximum(c_in, 0) * np.maximum(c_out, 0)
             * (self.lam / (4 * np.pi)) ** 4 / (d1 * d2) ** 2)
        amp = np.sqrt(p)
        if include_absorption:
            loss = absorption_loss_db(d1 + d2, self.frequency_hz, water_vapour)
            amp = amp * 10 ** (-loss / 20)
        return np.where(front, amp * np.exp(-1j * self.k * (d1 + d2)), 0.0)

    def reflection(self) -> np.ndarray:
        return self.amplitude * np.exp(1j * self.phases)


def total_field(direct: np.ndarray, C: np.ndarray, refl: np.ndarray) -> np.ndarray:
    """y_u = direct_u + sum_n C_un * refl_n   (direct (U,), C (U,N))."""
    return direct + C @ refl


def coordinate_descent(direct: np.ndarray, C: np.ndarray, ris: RIS, sweeps: int = 3) -> np.ndarray:
    """Exact per-element optimum of sum_u |y_u|^2 (continuous phase), then quantised to the RIS phase resolution
    with the coordinate updated in turn so the quantisation error is accounted for in later coordinates."""
    beta = ris.amplitude
    theta = ris.phases.copy()
    refl = beta * np.exp(1j * theta)
    y = direct + C @ refl
    for _ in range(sweeps):
        for n in range(ris.n):
            y_wo = y - C[:, n] * refl[n]
            opt = -np.angle(np.sum(np.conj(y_wo) * C[:, n]))
            theta[n] = ris.quantise(np.array([opt]))[0]
            refl_n = beta[n] * np.exp(1j * theta[n])
            y = y_wo + C[:, n] * refl_n
            refl[n] = refl_n
    return theta


def gradient_ascent(direct: np.ndarray, C: np.ndarray, ris: RIS, iters: int = 200, lr: float = 0.2,
                    objective: str = "sum", softmin_temp: float = 8.0) -> np.ndarray:
    """Projected gradient ascent on the continuous phases (analytic gradient), then quantisation.
    objective 'sum': sum_u |y_u|^2 ; 'maxmin': soft-min of |y_u|^2 (dB-normalised)."""
    beta = ris.amplitude
    theta = ris.phases.copy()
    scale = max(float(np.mean(np.abs(direct) ** 2)), 1e-300)
    for _ in range(iters):
        refl = beta * np.exp(1j * theta)
        y = direct + C @ refl
        p = np.abs(y) ** 2 / scale
        dp = -2.0 * beta[None, :] * np.imag(np.conj(y)[:, None] * C * np.exp(1j * theta)[None, :]) / scale
        if objective == "sum":
            grad = dp.sum(axis=0)
        else:
            w = np.exp(-softmin_temp * (p - p.min())); w /= w.sum()
            grad = (w[:, None] * dp).sum(axis=0)
        norm = np.linalg.norm(grad)
        if norm < 1e-18:
            break
        theta = theta + lr * grad / norm * np.sqrt(ris.n) * 0.1
    return ris.quantise(theta)
