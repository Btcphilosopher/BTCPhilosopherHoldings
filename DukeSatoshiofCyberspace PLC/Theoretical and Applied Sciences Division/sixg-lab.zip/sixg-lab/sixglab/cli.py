"""sixg command line: simulate | run | replay | benchmark | validate | report."""
from __future__ import annotations

import argparse
import logging
import sys
import time
from pathlib import Path

import numpy as np

from sixglab import SUBTITLE, TITLE, __version__
from sixglab.config import load_scenario
from sixglab.core.errors import SixGError
from sixglab.core.logging import configure_logging


def _fmt_rate(bps: float) -> str:
    for unit, div in (("Gb/s", 1e9), ("Mb/s", 1e6), ("kb/s", 1e3)):
        if abs(bps) >= div:
            return f"{bps / div:.2f} {unit}"
    return f"{bps:.1f} b/s"


def _fmt_hz(hz: float) -> str:
    return f"{hz / 1e9:g} GHz" if hz >= 1e9 else f"{hz / 1e6:g} MHz"


def _banner() -> None:
    print(TITLE)
    print(SUBTITLE + "\n")


def find_default_scenario() -> Path | None:
    for base in (Path.cwd(), Path(__file__).resolve().parents[1]):
        p = base / "scenarios" / "urban_6g.yaml"
        if p.exists():
            return p
    return None


def cmd_simulate(args: argparse.Namespace) -> int:
    from sixglab.network.simulation import Simulation
    from sixglab.storage.runs import save_run

    overrides: dict = {}
    if args.duration:
        overrides.setdefault("simulation", {})["duration_s"] = args.duration
    if args.seed is not None:
        overrides.setdefault("simulation", {})["seed"] = args.seed
    cfg = load_scenario(args.scenario, overrides=overrides)
    _banner()
    sim = Simulation(cfg)
    print(f"Scenario: {cfg.name}")
    print(f"Seed: {cfg.simulation.seed}\n")
    print(f"Base Stations: {sim.n_bs}")
    print(f"UEs: {sim.n_ue}")
    print(f"Bandwidth: {_fmt_hz(cfg.radio.bandwidth_hz)}")
    print(f"Carrier: {_fmt_hz(cfg.radio.carrier_frequency_hz)}")
    print(f"Antenna mode: {cfg.radio.antenna.mode}"
          + (f" ({cfg.radio.antenna.rows}x{cfg.radio.antenna.columns} per panel, {cfg.radio.antenna.panels} panels)"
             if cfg.radio.antenna.mode == "array" else ""))
    print(f"Path loss: {sim.pathloss.model_id.split(' [')[0]}\n")
    print(f"Simulation time: {cfg.simulation.duration_s:g} s\n")
    t0 = time.time()

    def progress(i, n, m):
        if not args.quiet and (i % max(1, n // 20) == 0 or i == n):
            print(f"\r  epoch {i}/{n}  SINR {m['mean_sinr_db']:.1f} dB  thr {_fmt_rate(m['throughput_bps'])}  "
                  f"wall {time.time() - t0:.0f}s", end="", file=sys.stderr, flush=True)

    s = sim.run(progress=progress)
    if not args.quiet:
        print(file=sys.stderr)
    print(f"Mean SINR: {s['mean_sinr_db']:.2f} dB  (median {s['median_sinr_db']:.2f} dB, coverage {s['coverage_fraction'] * 100:.1f}%)")
    print(f"Mean Throughput: {_fmt_rate(s['mean_throughput_bps'])}  (offered {_fmt_rate(s['offered_bps'])}, per UE {_fmt_rate(s['mean_ue_throughput_bps'])})")
    print(f"P95 Latency: {s['latency_p95_ms']:.2f} ms  (P50 {s['latency_p50_ms']:.2f} ms, P99 {s['latency_p99_ms']:.2f} ms)")
    print(f"Energy: {s['energy_wh']:.2f} Wh  (mean {s['mean_power_w'] / 1e3:.2f} kW, {s['wh_per_gb']:.3f} Wh/GB, {s['j_per_bit'] * 1e9:.1f} nJ/bit)")
    ho = s["handover"]
    print(f"Handovers: {ho['attempts']} attempts, {ho['failures']} failed, {ho['ping_pongs']} ping-pong")
    print(f"Blocked traffic (outage): {s['blocked_traffic_ratio'] * 100:.1f}%   Congestion loss: {s['packet_loss_ratio'] * 100:.2f}%")
    print(f"Run id: {sim.simulation_id}   (wall time {s['wall_time_s']:.1f} s)")
    if not args.no_save:
        out = save_run(sim, s, args.out)
        print(f"Saved: {out}")
    print("\nSimulation complete.")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    from sixglab.scenarios.experiment import Experiment

    exp = Experiment.from_yaml(args.experiments)
    _banner()
    n = int(np.prod([len(v) for v in exp.sweep.values()])) * exp.replicates if exp.sweep else exp.replicates
    print(f"Experiment: {exp.name} ({exp.experiment_id})   runs: {n}   workers: {args.workers}")
    df = exp.run(workers=args.workers)
    import pandas as pd

    with pd.option_context("display.width", 200, "display.max_columns", 30, "display.float_format", "{:.4g}".format):
        print(df.drop(columns=["config_hash"]).to_string(index=False))
    out = exp.save(args.out)
    print(f"\nSaved: {out}\nExperiment complete.")
    return 0


def cmd_replay(args: argparse.Namespace) -> int:
    from sixglab.storage.runs import load_run

    run = load_run(args.simulation_id, args.out)
    _banner()
    m = run["metrics"]
    print(f"Replay of {args.simulation_id}: {run['scenario']['name']} ({len(m)} epochs)\n")
    step = max(1, len(m) // args.frames)
    print(f"{'t[s]':>7} {'SINR[dB]':>9} {'cover':>6} {'thr[Gb/s]':>10} {'P95[ms]':>9} {'load':>6} {'power[kW]':>10} {'HO':>4}")
    for _, r in m.iloc[::step].iterrows():
        print(f"{r.t_s:7.1f} {r.mean_sinr_db:9.2f} {r.coverage_fraction:6.2f} {r.throughput_bps / 1e9:10.3f} "
              f"{r.latency_p95_ms:9.2f} {r.network_load:6.2f} {r.power_w / 1e3:10.2f} {int(r.handovers):4d}")
    return 0


def cmd_benchmark(args: argparse.Namespace) -> int:
    from sixglab.benchmark import run_benchmarks

    _banner()
    for k, v in run_benchmarks().items():
        print(f"{k:38s} {v * 1e3:10.3f} ms")
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    from sixglab.validation import run_validation

    _banner()
    checks = run_validation()
    for c in checks:
        print(f"[{'PASS' if c.passed else 'FAIL'}] {c.name:58s} expected {c.expected:<14.6g} got {c.got:<14.6g}")
    bad = [c for c in checks if not c.passed]
    print(f"\n{len(checks) - len(bad)}/{len(checks)} analytical checks passed")
    return 1 if bad else 0


def cmd_report(args: argparse.Namespace) -> int:
    from sixglab.visualisation.report import generate_report

    paths = generate_report(args.simulation_id, args.out)
    for k, p in paths.items():
        print(f"{k:8s} {p}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="sixg", description=f"{TITLE} - {SUBTITLE}")
    ap.add_argument("--version", action="version", version=f"sixg-lab {__version__}")
    ap.add_argument("-v", "--verbose", action="store_true", help="structured JSON logs to stderr")
    sub = ap.add_subparsers(dest="command")
    p = sub.add_parser("simulate", help="run one scenario"); p.add_argument("scenario")
    p.add_argument("--duration", type=float); p.add_argument("--seed", type=int)
    p.add_argument("--out", default="data/runs"); p.add_argument("--no-save", action="store_true"); p.add_argument("--quiet", action="store_true")
    p.set_defaults(fn=cmd_simulate)
    p = sub.add_parser("run", help="run an experiment file (sweeps / replicates)"); p.add_argument("experiments")
    p.add_argument("--workers", type=int, default=1); p.add_argument("--out", default="data/experiments"); p.set_defaults(fn=cmd_run)
    p = sub.add_parser("replay", help="replay a saved run"); p.add_argument("simulation_id")
    p.add_argument("--frames", type=int, default=20); p.add_argument("--out", default="data/runs"); p.set_defaults(fn=cmd_replay)
    p = sub.add_parser("benchmark", help="performance benchmarks"); p.set_defaults(fn=cmd_benchmark)
    p = sub.add_parser("validate", help="analytical physics validation"); p.set_defaults(fn=cmd_validate)
    p = sub.add_parser("report", help="HTML/PDF/JSON/Parquet report for a run"); p.add_argument("simulation_id")
    p.add_argument("--out", default="data/runs"); p.set_defaults(fn=cmd_report)
    return ap


def main(argv: list[str] | None = None) -> int:
    ap = build_parser()
    args = ap.parse_args(argv)
    configure_logging(logging.INFO if args.verbose else logging.WARNING)
    if not args.command:
        sc = find_default_scenario()
        if sc is None:
            ap.print_help()
            return 0
        print(f"(no command given: running the default scenario {sc} for 10 s; see `sixg --help`)\n")
        args = ap.parse_args(["simulate", str(sc), "--duration", "10"])
    try:
        return int(args.fn(args))
    except SixGError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
