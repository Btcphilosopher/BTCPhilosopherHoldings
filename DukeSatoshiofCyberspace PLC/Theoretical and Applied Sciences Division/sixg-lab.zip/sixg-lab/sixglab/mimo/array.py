"""AntennaArray: ULA / URA / custom geometry with a cosine-power element pattern.

Local frame: x = boresight, y = horizontal, z = vertical. Elements of a URA lie in the y-z plane.
Far-field steering vector toward unit direction u (local frame):  a_n(u) = exp(+j k p_n . u).
Received amplitude for transmit weights w:  y = sum_n sqrt(g(u)) a_n(u) w_n  (see ``response``).
Element power gain g(u) = D0 * max(u_x, 0)^q with D0 = element_gain_dbi (linear) and q = D0/2 - 1
(cosine-power pattern: peak directivity of cos^q over the half-space is 2(q+1)).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from sixglab.core.errors import ConfigurationError
from sixglab.core.units import C_LIGHT, db_to_lin
from sixglab.core.validation import require_positive


def rotation_matrix(yaw_rad: float, downtilt_rad: float) -> np.ndarray:
    """Local->global rotation: Rz(yaw) @ Ry(tilt); positive tilt points boresight below the horizon."""
    cy, sy = np.cos(yaw_rad), np.sin(yaw_rad)
    ct, st = np.cos(downtilt_rad), np.sin(downtilt_rad)
    rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1.0]])
    ry = np.array([[ct, 0, st], [0, 1.0, 0], [-st, 0, ct]])
    return rz @ ry


@dataclass
class AntennaArray:
    positions_m: np.ndarray            # (N, 3) local frame
    frequency_hz: float
    element_gain_dbi: float = 5.0
    rows: int | None = None            # set for URA/ULA (enables the separable fast path)
    columns: int | None = None
    spacing_m: float | None = None
    yaw_rad: float = 0.0
    downtilt_rad: float = 0.0

    def __post_init__(self) -> None:
        require_positive("frequency_hz", self.frequency_hz)
        self.positions_m = np.asarray(self.positions_m, dtype=float)
        if self.positions_m.ndim != 2 or self.positions_m.shape[1] != 3 or len(self.positions_m) < 1:
            raise ConfigurationError("positions_m must be (N, 3) with N >= 1")
        self.k = 2 * np.pi * self.frequency_hz / C_LIGHT
        d0 = float(db_to_lin(self.element_gain_dbi))
        self._d0, self._q = d0, max(d0 / 2.0 - 1.0, 0.0)
        self.rotation = rotation_matrix(self.yaw_rad, self.downtilt_rad)

    # ---- constructors --------------------------------------------------------------------
    @classmethod
    def ura(cls, rows: int, columns: int, frequency_hz: float, spacing_wavelengths: float = 0.5,
            element_gain_dbi: float = 5.0, yaw_rad: float = 0.0, downtilt_rad: float = 0.0) -> AntennaArray:
        d = spacing_wavelengths * C_LIGHT / frequency_hz
        ys = (np.arange(columns) - (columns - 1) / 2) * d
        zs = (np.arange(rows) - (rows - 1) / 2) * d
        yy, zz = np.meshgrid(ys, zs)                       # row-major: element index = r*columns + c
        pos = np.column_stack([np.zeros(rows * columns), yy.ravel(), zz.ravel()])
        return cls(pos, frequency_hz, element_gain_dbi, rows, columns, d, yaw_rad, downtilt_rad)

    @classmethod
    def ula(cls, n: int, frequency_hz: float, **kw) -> AntennaArray:
        return cls.ura(1, n, frequency_hz, **kw)

    @classmethod
    def custom(cls, positions_m: np.ndarray, frequency_hz: float, element_gain_dbi: float = 0.0) -> AntennaArray:
        return cls(np.asarray(positions_m, float), frequency_hz, element_gain_dbi)

    @property
    def n_elements(self) -> int:
        return len(self.positions_m)

    # ---- pattern / steering --------------------------------------------------------------
    def to_local(self, u_global: np.ndarray) -> np.ndarray:
        return u_global @ self.rotation                    # == (R^T u) row-wise

    def element_gain(self, u_local: np.ndarray) -> np.ndarray:
        cos = np.maximum(u_local[..., 0], 0.0)
        return self._d0 * cos**self._q * (cos > 0)

    def steering(self, u_local: np.ndarray) -> np.ndarray:
        """(..., N) complex, unit-modulus entries."""
        u = np.asarray(u_local, dtype=float)
        if self.rows is not None:
            return steering_ura(u, self.rows or 1, self.columns or 1, self.spacing_m or 0.0, self.k)
        return np.exp(1j * self.k * (u @ self.positions_m.T))

    def response(self, u_local: np.ndarray) -> np.ndarray:
        """Channel row for a unit-gain path: sqrt(g(u)) * a(u)."""
        return np.sqrt(self.element_gain(u_local))[..., None] * self.steering(u_local)

    def pattern_gain_db(self, weights: np.ndarray, u_local: np.ndarray) -> np.ndarray:
        """Directional gain (dBi) of transmit weights (unit norm) toward u: |a^T w|^2 * g(u)."""
        w = np.asarray(weights)
        amp = np.abs(self.steering(u_local) @ w) ** 2 * self.element_gain(u_local)
        return 10 * np.log10(np.maximum(amp, 1e-30))

    def codebook(self, n_az: int, n_el: int, az_range_deg=(-60.0, 60.0), el_range_deg=(-40.0, 15.0)):
        """Steering-vector beams on an (az, el) grid. Returns (weights (B,N), directions_local (B,3), (az, el) deg)."""
        az = np.deg2rad(np.linspace(az_range_deg[0], az_range_deg[1], n_az)) if n_az > 1 else np.array([0.0])
        el = np.deg2rad(np.linspace(el_range_deg[0], el_range_deg[1], n_el)) if n_el > 1 else np.array([0.0])
        aa, ee = np.meshgrid(az, el)
        u = np.column_stack([(np.cos(ee) * np.cos(aa)).ravel(), (np.cos(ee) * np.sin(aa)).ravel(), np.sin(ee).ravel()])
        w = np.conj(self.steering(u)) / np.sqrt(self.n_elements)
        return w, u, (np.rad2deg(aa).ravel(), np.rad2deg(ee).ravel())


def steering_ura(u: np.ndarray, rows: int, columns: int, spacing_m: float, k: float) -> np.ndarray:
    """Separable URA steering: exp(jk y u_y) (x) exp(jk z u_z), element index = r*columns + c."""
    ys = (np.arange(columns) - (columns - 1) / 2) * spacing_m
    zs = (np.arange(rows) - (rows - 1) / 2) * spacing_m
    ay = np.exp(1j * k * u[..., 1, None] * ys)             # (..., columns)
    az = np.exp(1j * k * u[..., 2, None] * zs)             # (..., rows)
    return (az[..., :, None] * ay[..., None, :]).reshape(*u.shape[:-1], rows * columns)
