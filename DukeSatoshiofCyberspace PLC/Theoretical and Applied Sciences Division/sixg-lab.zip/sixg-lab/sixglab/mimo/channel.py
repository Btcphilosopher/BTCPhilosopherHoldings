"""MIMOChannel: H in C^{Nr x Nt} for SISO / SIMO / MISO / MIMO / massive MIMO, with i.i.d. Rayleigh or
geometric (array-manifold) spatial models, and the capacity expressions used for validation."""
from __future__ import annotations

import numpy as np

from sixglab.core.errors import ConfigurationError
from sixglab.core.validation import require_finite


class MIMOChannel:
    def __init__(self, n_rx: int, n_tx: int, rng: np.random.Generator) -> None:
        if n_rx < 1 or n_tx < 1:
            raise ConfigurationError("antenna counts must be >= 1")
        self.nr, self.nt, self.rng = n_rx, n_tx, rng

    @property
    def kind(self) -> str:
        if self.nt == 1 and self.nr == 1:
            return "SISO"
        if self.nt == 1:
            return "SIMO"
        if self.nr == 1:
            return "MISO"
        return "massive MIMO" if max(self.nt, self.nr) >= 32 else "MIMO"

    def rayleigh(self, n_realisations: int | None = None) -> np.ndarray:
        shape = (self.nr, self.nt) if n_realisations is None else (n_realisations, self.nr, self.nt)
        h = (self.rng.standard_normal(shape) + 1j * self.rng.standard_normal(shape)) / np.sqrt(2.0)
        return require_finite("H", h)

    def geometric(self, tx_array, rx_array, n_paths: int, spread_deg: float = 10.0,
                  bearing_deg: float = 0.0) -> np.ndarray:
        """Sum of ``n_paths`` plane waves with angles around ``bearing_deg`` (azimuth) at both ends."""
        h = np.zeros((self.nr, self.nt), dtype=complex)
        for _ in range(n_paths):
            def unit(az_deg):
                az = np.deg2rad(az_deg + self.rng.normal(0, spread_deg))
                return np.array([np.cos(az), np.sin(az), 0.0])
            a_t = tx_array.response(unit(bearing_deg))
            a_r = rx_array.response(unit(bearing_deg + 180.0))
            gain = (self.rng.standard_normal() + 1j * self.rng.standard_normal()) / np.sqrt(2 * n_paths)
            h += gain * np.outer(a_r, a_t)
        return require_finite("H", h)


def capacity_bps_hz(h: np.ndarray, snr_lin: float) -> float:
    """Equal-power open-loop capacity  log2 det(I + snr/Nt * H H^H)  [bit/s/Hz]."""
    nr, nt = h.shape
    m = np.eye(nr) + (snr_lin / nt) * (h @ h.conj().T)
    sign, logdet = np.linalg.slogdet(m)
    return float(logdet / np.log(2.0)) if sign > 0 else float("nan")
