"""sixglab - 6G DIGITAL TWIN LAB: AI-NATIVE WIRELESS SYSTEMS SIMULATION."""

import logging as _logging

__version__ = "0.1.0"
TITLE = "6G DIGITAL TWIN LAB"
SUBTITLE = "AI-NATIVE WIRELESS SYSTEMS SIMULATION"

_logging.getLogger("sixglab").addHandler(_logging.NullHandler())
