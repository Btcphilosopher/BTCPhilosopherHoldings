from sixglab.visualisation.report import generate_report

__all__ = ["generate_report"]
