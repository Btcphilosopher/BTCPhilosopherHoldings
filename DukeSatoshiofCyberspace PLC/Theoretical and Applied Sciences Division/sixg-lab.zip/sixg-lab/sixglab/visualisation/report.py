"""Experiment reports: HTML (embedded plots), PDF, JSON and Parquet, from a saved run."""
from __future__ import annotations

import base64
import html
import io
import json
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.backends.backend_pdf import PdfPages  # noqa: E402

from sixglab.scenarios.experiment import confidence_interval  # noqa: E402
from sixglab.storage.runs import load_run  # noqa: E402

NAVY, BLUE, STEEL, AMBER = "#14213d", "#4f6d8f", "#8a94a0", "#c98a1b"


def batch_means_ci(x: np.ndarray, n_batches: int = 10) -> tuple[float, float, float]:
    """95% CI of a time-series mean via batch means (accounts for temporal correlation)."""
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if x.size < n_batches * 2:
        return confidence_interval(x)
    b = np.array_split(x, n_batches)
    return confidence_interval(np.array([bi.mean() for bi in b]))


def _figs(run: dict[str, Any]) -> list[tuple[str, plt.Figure]]:
    m, ue = run["metrics"], run["ue"]
    figs = []
    plt.rcParams.update({"font.size": 9, "axes.edgecolor": STEEL, "axes.labelcolor": NAVY, "axes.grid": True,
                         "grid.color": "#e3e6ea"})
    f, ax = plt.subplots(figsize=(6, 3.2))
    s = np.sort(ue["sinr_db"].ravel())
    ax.plot(s, np.linspace(0, 1, s.size), color=BLUE)
    ax.set_xlabel("SINR [dB]"); ax.set_ylabel("CDF"); ax.set_title("SINR distribution (all UE-epochs)")
    figs.append(("SINR CDF", f))
    f, ax = plt.subplots(figsize=(6, 3.2))
    ax.plot(m["t_s"], m["throughput_bps"] / 1e9, color=NAVY, label="delivered")
    ax.plot(m["t_s"], m["offered_bps"] / 1e9, color=STEEL, ls="--", label="offered")
    ax.set_xlabel("time [s]"); ax.set_ylabel("Gb/s"); ax.legend(); ax.set_title("Network throughput")
    figs.append(("Throughput", f))
    f, ax = plt.subplots(figsize=(6, 3.2))
    ax.plot(m["t_s"], m["latency_p95_ms"], color=AMBER)
    ax.set_xlabel("time [s]"); ax.set_ylabel("P95 latency [ms]"); ax.set_title("P95 end-to-end latency per epoch")
    figs.append(("Latency", f))
    f, ax = plt.subplots(figsize=(6, 3.2))
    ax.plot(m["t_s"], m["power_w"] / 1e3, color=BLUE)
    ax.set_xlabel("time [s]"); ax.set_ylabel("kW"); ax.set_title("Network power")
    figs.append(("Energy", f))
    return figs


def _png(fig) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=130, bbox_inches="tight")
    return base64.b64encode(buf.getvalue()).decode()


def generate_report(simulation_id: str, root: str | Path = "data/runs") -> dict[str, Path]:
    run = load_run(simulation_id, root)
    d: Path = run["dir"]
    s, cfg, m = run["summary"], run["scenario"], run["metrics"]
    figs = _figs(run)
    ci = {k: batch_means_ci(m[c].to_numpy()) for k, c in
          (("Mean throughput [b/s]", "throughput_bps"), ("Coverage fraction", "coverage_fraction"),
           ("Mean SINR [dB]", "mean_sinr_db"), ("Power [W]", "power_w"))}
    prov = s.get("provenance", {})
    rows = "".join(f"<tr><td>{html.escape(k)}</td><td>{v[0]:.4g}</td><td>{v[1]:.4g} ... {v[2]:.4g}</td></tr>" for k, v in ci.items())
    keyres = "".join(f"<tr><td>{html.escape(k)}</td><td>{s.get(k)!r}</td></tr>" for k in (
        "mean_sinr_db", "median_sinr_db", "coverage_fraction", "mean_throughput_bps", "latency_p50_ms", "latency_p95_ms",
        "latency_p99_ms", "packet_loss_ratio", "blocked_traffic_ratio", "block_error_rate", "energy_wh", "j_per_bit", "wh_per_gb",
        "jain_fairness", "handover"))
    imgs = "".join(f"<h3>{n}</h3><img src='data:image/png;base64,{_png(f)}'/>" for n, f in figs)
    page = f"""<!doctype html><html><head><meta charset='utf-8'><title>6G DIGITAL TWIN LAB - report {simulation_id}</title>
<style>body{{font-family:'IBM Plex Sans',Helvetica,Arial,sans-serif;color:#14213d;max-width:980px;margin:32px auto;padding:0 16px}}
h1{{font-weight:600;letter-spacing:.04em}}h2{{border-bottom:1px solid #8a94a0;padding-bottom:4px;margin-top:32px}}
table{{border-collapse:collapse;width:100%;font-size:13px}}td{{border-bottom:1px solid #e3e6ea;padding:4px 8px;font-family:'IBM Plex Mono',monospace}}
pre{{background:#f4f5f7;padding:12px;overflow:auto;font-size:12px}}.warn{{color:#c98a1b}}</style></head><body>
<h1>6G DIGITAL TWIN LAB</h1><p>AI-NATIVE WIRELESS SYSTEMS SIMULATION &mdash; experiment report</p>
<h2>Parameters</h2><pre>{html.escape(json.dumps(cfg, indent=2))}</pre>
<h2>Assumptions and model versions</h2><ul>
<li>Path loss: {html.escape(str(s.get('path_loss_model')))}</li>
<li>Antenna mode: {s.get('antenna_mode')}; scheduler: {s.get('scheduler')}</li>
<li>Link adaptation: gap-to-Shannon abstraction (research approximation), TS 38.214 CQI efficiency table</li>
<li class='warn'>Above 100 GHz the 3GPP-derived large-scale term is extrapolated; molecular absorption is a coarse reduced-order fit.</li>
<li>LoS/NLoS from geometric ray-marching of a building height map. Latency is measured by tagged-packet tracking through the slot MAC.</li></ul>
<h2>Results</h2><table>{keyres}</table>
<h2>Confidence intervals (95%, batch means over epochs)</h2><table><tr><td>metric</td><td>mean</td><td>95% CI</td></tr>{rows}</table>
<h2>Plots</h2>{imgs}
<h2>Reproducibility</h2><pre>{html.escape(json.dumps(prov, indent=2))}</pre></body></html>"""
    paths = {"html": d / "report.html", "pdf": d / "report.pdf", "json": d / "report.json", "parquet": d / "report_metrics.parquet"}
    paths["html"].write_text(page)
    with PdfPages(paths["pdf"]) as pdf:
        t = plt.figure(figsize=(8.27, 11.69)); t.text(0.06, 0.95, "6G DIGITAL TWIN LAB - experiment report", fontsize=14, weight="bold")
        t.text(0.06, 0.92, f"simulation {simulation_id}   scenario {s.get('scenario')}   seed {s.get('seed')}", fontsize=9)
        y = 0.88
        for k in ("mean_sinr_db", "coverage_fraction", "mean_throughput_bps", "latency_p95_ms", "energy_wh", "wh_per_gb"):
            t.text(0.06, y, f"{k}: {s.get(k)}", fontsize=9, family="monospace"); y -= 0.025
        t.text(0.06, y - 0.01, f"commit {prov.get('git_commit')}  python {prov.get('python_version')}  config {prov.get('config_hash')}", fontsize=8, family="monospace")
        pdf.savefig(t); plt.close(t)
        for _, f in figs:
            pdf.savefig(f)
    for _, f in figs:
        plt.close(f)
    paths["json"].write_text(json.dumps({"summary": s, "ci95": {k: list(v) for k, v in ci.items()}}, indent=2, default=str))
    m.to_parquet(paths["parquet"], index=False)
    return paths
