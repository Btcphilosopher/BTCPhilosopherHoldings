"""EventBus: synchronous, deterministic publish/subscribe with bounded history."""
from __future__ import annotations

from collections import Counter, deque
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class EventType(StrEnum):
    UE_CONNECTED = "UE_CONNECTED"
    UE_DISCONNECTED = "UE_DISCONNECTED"
    HANDOVER = "HANDOVER"
    BEAM_SWITCH = "BEAM_SWITCH"
    CHANNEL_UPDATE = "CHANNEL_UPDATE"
    PACKET_SENT = "PACKET_SENT"
    PACKET_RECEIVED = "PACKET_RECEIVED"
    PACKET_DROPPED = "PACKET_DROPPED"
    EDGE_TASK_CREATED = "EDGE_TASK_CREATED"
    EDGE_TASK_COMPLETED = "EDGE_TASK_COMPLETED"
    SATELLITE_HANDOVER = "SATELLITE_HANDOVER"
    SLICE_CREATED = "SLICE_CREATED"
    SLICE_UPDATED = "SLICE_UPDATED"


@dataclass(frozen=True)
class Event:
    time_s: float
    type: EventType
    source: str
    payload: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"t": self.time_s, "type": self.type.value, "source": self.source, **self.payload}


Handler = Callable[[Event], None]


class EventBus:
    def __init__(self, history: int = 20_000) -> None:
        self._subs: dict[EventType | None, list[Handler]] = {}
        self.history: deque[Event] = deque(maxlen=history)
        self.counts: Counter[EventType] = Counter()

    def subscribe(self, event_type: EventType | None, handler: Handler) -> None:
        """Subscribe to one event type, or to all events with ``None``."""
        self._subs.setdefault(event_type, []).append(handler)

    def publish(self, event: Event) -> None:
        self.history.append(event)
        self.counts[event.type] += 1
        for h in self._subs.get(event.type, ()):
            h(event)
        for h in self._subs.get(None, ()):
            h(event)

    def emit(self, time_s: float, type_: EventType, source: str, **payload: Any) -> None:
        self.publish(Event(time_s, type_, source, payload))

    def recent(self, n: int = 100, type_: EventType | None = None) -> list[Event]:
        items = [e for e in self.history if type_ is None or e.type == type_]
        return items[-n:]
