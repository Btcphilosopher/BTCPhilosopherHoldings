"""Exception hierarchy. Numerical failures are never silently swallowed (spec section 103)."""


class SixGError(Exception):
    """Base class for all sixglab errors."""


class ConfigurationError(SixGError):
    """Invalid or inconsistent configuration."""


class NumericalError(SixGError):
    """NaN / Inf / singular matrix / invalid channel matrix encountered."""


class PhysicsError(SixGError):
    """A physical constraint was violated (negative power, non-positive frequency, ...)."""
