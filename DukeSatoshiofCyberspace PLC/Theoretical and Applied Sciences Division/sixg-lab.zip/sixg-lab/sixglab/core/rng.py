"""Deterministic named random streams.

Every component asks for its own stream by name; streams are independent, reproducible from
(seed, name) alone, and unaffected by the order in which other components consume randomness.
"""
from __future__ import annotations

import zlib

import numpy as np


class RngFactory:
    def __init__(self, seed: int) -> None:
        self.seed = int(seed)

    def stream(self, name: str) -> np.random.Generator:
        key = zlib.crc32(name.encode("utf-8"))
        return np.random.default_rng(np.random.SeedSequence(entropy=self.seed, spawn_key=(key,)))

    def replicate(self, index: int) -> RngFactory:
        """Independent factory for Monte Carlo replicate ``index``."""
        ss = np.random.SeedSequence(entropy=self.seed, spawn_key=(0xC0FFEE, int(index)))
        return RngFactory(int(ss.generate_state(1, dtype=np.uint64)[0] % (2**63)))
