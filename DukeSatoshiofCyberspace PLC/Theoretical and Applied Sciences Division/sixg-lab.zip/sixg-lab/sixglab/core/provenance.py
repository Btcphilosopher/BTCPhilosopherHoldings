"""Reproducibility record: git commit, Python + package versions, config hash, seed (spec 82)."""
from __future__ import annotations

import hashlib
import json
import platform
import subprocess
from importlib import metadata
from pathlib import Path
from typing import Any

import sixglab

_PACKAGES = ("numpy", "scipy", "pandas", "pydantic", "networkx", "fastapi", "pyyaml", "pyarrow")


def config_hash(config: Any) -> str:
    doc = json.dumps(config, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(doc.encode()).hexdigest()[:16]


def git_commit() -> str:
    try:
        root = Path(__file__).resolve().parents[2]
        out = subprocess.run(
            ["git", "-C", str(root), "rev-parse", "--short=12", "HEAD"],
            capture_output=True, text=True, timeout=5, check=False,
        )
        return out.stdout.strip() or "unversioned"
    except (OSError, subprocess.SubprocessError):
        return "unversioned"


def collect_provenance(cfg_hash: str, seed: int, scenario_version: str = "1") -> dict[str, Any]:
    versions = {}
    for name in _PACKAGES:
        try:
            versions[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            versions[name] = "not-installed"
    return {
        "sixglab_version": sixglab.__version__,
        "git_commit": git_commit(),
        "python_version": platform.python_version(),
        "package_versions": versions,
        "scenario_version": scenario_version,
        "random_seed": seed,
        "config_hash": cfg_hash,
    }
