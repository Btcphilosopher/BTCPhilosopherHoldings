"""SimulationClock: integer-tick clock (no float drift) with the required run modes."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import StrEnum

from sixglab.core.errors import ConfigurationError, PhysicsError


class ClockMode(StrEnum):
    REAL_TIME = "real_time"      # wall-clock paced 1:1
    ACCELERATED = "accelerated"  # wall-clock paced at speed_factor x
    PAUSED = "paused"
    STEP = "step"                # advances only on explicit step()
    BATCH = "batch"              # as fast as possible
    MONTE_CARLO = "monte_carlo"  # batch, tagged with a replicate index


@dataclass
class SimulationClock:
    timestep_s: float
    duration_s: float
    mode: ClockMode = ClockMode.BATCH
    speed_factor: float = 1.0
    replicate: int = 0
    tick: int = 0
    _mode_before_pause: ClockMode = field(default=ClockMode.BATCH, repr=False)
    _wall_start: float | None = field(default=None, repr=False)
    _sim_start_s: float = field(default=0.0, repr=False)

    def __post_init__(self) -> None:
        if not (self.timestep_s > 0 and self.duration_s > 0):
            raise PhysicsError("timestep_s and duration_s must be > 0")
        if self.duration_s < self.timestep_s:
            raise ConfigurationError("duration_s must be >= timestep_s")
        if self.speed_factor <= 0:
            raise ConfigurationError("speed_factor must be > 0")
        self.mode = ClockMode(self.mode)

    @property
    def total_ticks(self) -> int:
        return int(round(self.duration_s / self.timestep_s))

    @property
    def time_s(self) -> float:
        return self.tick * self.timestep_s

    @property
    def finished(self) -> bool:
        return self.tick >= self.total_ticks

    @property
    def paused(self) -> bool:
        return self.mode == ClockMode.PAUSED

    def advance(self, n_ticks: int = 1) -> float:
        if self.paused:
            raise ConfigurationError("clock is paused")
        if n_ticks < 1:
            raise ConfigurationError("n_ticks must be >= 1")
        self.tick = min(self.tick + int(n_ticks), self.total_ticks)
        return self.time_s

    def pause(self) -> None:
        if not self.paused:
            self._mode_before_pause = self.mode
            self.mode = ClockMode.PAUSED

    def resume(self) -> None:
        if self.paused:
            self.mode = self._mode_before_pause
            self._wall_start = None

    def pace(self) -> float:
        """Sleep so that wall time tracks simulated time for REAL_TIME / ACCELERATED modes.

        Returns the seconds slept (0 in other modes).
        """
        if self.mode not in (ClockMode.REAL_TIME, ClockMode.ACCELERATED):
            return 0.0
        if self._wall_start is None:
            self._wall_start = time.perf_counter()
            self._sim_start_s = self.time_s
        factor = 1.0 if self.mode == ClockMode.REAL_TIME else self.speed_factor
        target_wall = (self.time_s - self._sim_start_s) / factor
        delay = target_wall - (time.perf_counter() - self._wall_start)
        if delay > 0:
            time.sleep(delay)
            return delay
        return 0.0

    def for_replicate(self, index: int) -> SimulationClock:
        return SimulationClock(self.timestep_s, self.duration_s, ClockMode.MONTE_CARLO, 1.0, index)
