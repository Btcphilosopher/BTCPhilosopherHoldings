"""Structured JSON logging. Every record carries simulation_id, experiment_id, scenario_id,
timestamp, component and event (spec section 102)."""
from __future__ import annotations

import json
import logging
import sys
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any


@dataclass
class LogContext:
    simulation_id: str = "-"
    experiment_id: str = "-"
    scenario_id: str = "-"


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        ctx: LogContext = getattr(record, "ctx", LogContext())
        doc: dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(record.created, UTC).isoformat(),
            "level": record.levelname,
            "component": record.name.removeprefix("sixglab."),
            "event": record.getMessage(),
            "simulation_id": ctx.simulation_id,
            "experiment_id": ctx.experiment_id,
            "scenario_id": ctx.scenario_id,
        }
        doc.update(getattr(record, "fields", {}))
        return json.dumps(doc, default=str)


class ComponentLogger:
    def __init__(self, component: str, ctx: LogContext | None = None) -> None:
        self._log = logging.getLogger(f"sixglab.{component}")
        self.ctx = ctx or LogContext()

    def _emit(self, level: int, event: str, fields: dict[str, Any]) -> None:
        self._log.log(level, event, extra={"ctx": self.ctx, "fields": fields})

    def info(self, event: str, **fields: Any) -> None:
        self._emit(logging.INFO, event, fields)

    def warning(self, event: str, **fields: Any) -> None:
        self._emit(logging.WARNING, event, fields)

    def error(self, event: str, **fields: Any) -> None:
        self._emit(logging.ERROR, event, fields)


def configure_logging(level: int = logging.WARNING, stream=None) -> None:
    root = logging.getLogger("sixglab")
    root.handlers.clear()
    handler = logging.StreamHandler(stream or sys.stderr)
    handler.setFormatter(JsonFormatter())
    root.addHandler(handler)
    root.setLevel(level)
    root.propagate = False


def get_logger(component: str, ctx: LogContext | None = None) -> ComponentLogger:
    return ComponentLogger(component, ctx)
