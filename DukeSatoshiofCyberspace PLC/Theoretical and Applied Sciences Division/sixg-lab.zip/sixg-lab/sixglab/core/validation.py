"""Numerical-safety validators (spec sections 103-104). Explicit tolerances, useful errors."""
from __future__ import annotations

import numpy as np

from sixglab.core.errors import NumericalError, PhysicsError

REL_TOL = 1e-9
ABS_TOL = 1e-12


def require_positive(name: str, value) -> None:
    a = np.asarray(value, dtype=float)
    if not np.all(np.isfinite(a)) or np.any(a <= 0):
        raise PhysicsError(f"{name} must be finite and > 0, got {value!r}")


def require_nonnegative(name: str, value) -> None:
    a = np.asarray(value, dtype=float)
    if not np.all(np.isfinite(a)) or np.any(a < 0):
        raise PhysicsError(f"{name} must be finite and >= 0, got {value!r}")


def require_int_at_least(name: str, value, minimum: int) -> None:
    if int(value) != value or int(value) < minimum:
        raise PhysicsError(f"{name} must be an integer >= {minimum}, got {value!r}")


def require_finite(name: str, arr) -> np.ndarray:
    """Raise NumericalError (with counts) if the array contains NaN/Inf."""
    a = np.asarray(arr)
    bad = ~np.isfinite(a)
    if bad.any():
        raise NumericalError(f"{name}: {int(bad.sum())} non-finite value(s) out of {a.size}")
    return a


def require_condition_ok(name: str, matrix: np.ndarray, max_cond: float = 1e12) -> None:
    """Singular / ill-conditioned matrix guard used before any inversion."""
    require_finite(name, matrix)
    cond = np.linalg.cond(matrix)
    if not np.isfinite(cond) or cond > max_cond:
        raise NumericalError(f"{name} is singular or ill-conditioned (cond={cond:.3e})")


def close(a, b, rel: float = 1e-9, abs_: float = 1e-12) -> bool:
    return bool(np.allclose(a, b, rtol=rel, atol=abs_))
