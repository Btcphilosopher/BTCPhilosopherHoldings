"""SI constants and dB helpers. All internal quantities are SI (Hz, s, m, m/s, W, K, rad).

Only the UI layer converts to human-readable units.
"""
from __future__ import annotations

import numpy as np

from sixglab.core.errors import NumericalError

C_LIGHT = 299_792_458.0  # m/s (exact)
K_BOLTZMANN = 1.380649e-23  # J/K (exact, SI 2019)
T_REFERENCE_K = 290.0  # IEEE standard noise reference temperature
EPS = 1e-30  # floor used only to avoid log10(0); never to hide invalid inputs


def db_to_lin(x_db):
    return np.power(10.0, np.asarray(x_db, dtype=float) / 10.0)


def lin_to_db(x_lin):
    """10*log10 with an explicit error for negative / NaN input; zero maps to -300 dB."""
    x = np.asarray(x_lin, dtype=float)
    if np.any(np.isnan(x)) or np.any(x < 0):
        raise NumericalError("lin_to_db received NaN or negative input")
    return 10.0 * np.log10(np.maximum(x, EPS))


def w_to_dbm(p_w):
    return lin_to_db(np.asarray(p_w, dtype=float) * 1e3)


def dbm_to_w(p_dbm):
    return db_to_lin(p_dbm) * 1e-3


def wavelength_m(frequency_hz):
    f = np.asarray(frequency_hz, dtype=float)
    if np.any(f <= 0):
        raise NumericalError("frequency must be > 0")
    return C_LIGHT / f
