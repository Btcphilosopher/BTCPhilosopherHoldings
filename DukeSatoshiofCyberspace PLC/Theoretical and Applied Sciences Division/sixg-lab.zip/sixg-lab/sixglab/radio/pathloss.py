"""Modular propagation models. Every result carries the identity of the model that produced it.

Formulas follow 3GPP TR 38.901 (V16) Table 7.4.1-1 (path loss) for UMa/UMi-street-canyon/InH/RMa,
evaluated with fc in GHz and distances in metres. Above the standard's validity range (100 GHz) the
models are EXTRAPOLATED and flagged via ``PathLossModel.validity_note``.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import numpy as np

from sixglab.core.units import C_LIGHT
from sixglab.core.validation import require_finite, require_positive

MIN_DISTANCE_M = 10.0  # 38.901 minimum 3D distance for the formulas; shorter links are clamped


@dataclass
class PathLossResult:
    model_id: str
    loss_db: np.ndarray
    los: np.ndarray
    components: dict[str, np.ndarray] = field(default_factory=dict)
    sigma_los_db: float = 4.0
    sigma_nlos_db: float = 7.82
    validity_note: str = ""


def fspl_db(distance_m, frequency_hz):
    """Free-space path loss: 20 log10(4 pi d f / c)."""
    d = np.asarray(distance_m, dtype=float)
    require_positive("distance_m", d)
    require_positive("frequency_hz", frequency_hz)
    return 20.0 * np.log10(4.0 * np.pi * d * frequency_hz / C_LIGHT)


class PathLossModel(ABC):
    model_id: str = "abstract"
    validity_ghz: tuple[float, float] = (0.5, 100.0)
    sigma_los_db: float = 4.0
    sigma_nlos_db: float = 7.82

    def validity_note(self, frequency_hz: float) -> str:
        lo, hi = self.validity_ghz
        f = frequency_hz / 1e9
        if lo <= f <= hi:
            return ""
        return f"{self.model_id}: {f:g} GHz is outside the model's stated validity range {lo:g}-{hi:g} GHz (extrapolation)"

    @abstractmethod
    def _loss(self, d3d, d2d, los, fc_ghz, h_bs, h_ut) -> tuple[np.ndarray, dict[str, np.ndarray]]: ...

    def compute(self, d3d, d2d, los, frequency_hz: float, h_bs: float, h_ut: float) -> PathLossResult:
        require_positive("frequency_hz", frequency_hz)
        d3 = np.maximum(np.asarray(d3d, dtype=float), MIN_DISTANCE_M)
        d2 = np.maximum(np.asarray(d2d, dtype=float), 1.0)
        los = np.asarray(los, dtype=bool)
        loss, comps = self._loss(d3, d2, los, frequency_hz / 1e9, h_bs, h_ut)
        require_finite(f"{self.model_id} loss", loss)
        return PathLossResult(self.model_id, loss, los, comps, self.sigma_los_db, self.sigma_nlos_db,
                              self.validity_note(frequency_hz))


class FreeSpace(PathLossModel):
    model_id = "FreeSpace (Friis)"
    validity_ghz = (0.001, 1e4)
    sigma_los_db = sigma_nlos_db = 0.0

    def _loss(self, d3d, d2d, los, fc, h_bs, h_ut):
        loss = fspl_db(d3d, fc * 1e9)
        return loss, {"free_space_db": loss}


class LogDistance(PathLossModel):
    validity_ghz = (0.001, 1e4)

    def __init__(self, exponent: float = 2.5, d0_m: float = 1.0) -> None:
        require_positive("exponent", exponent)
        self.n, self.d0 = exponent, d0_m
        self.model_id = f"LogDistance (n={exponent:g}, d0={d0_m:g} m)"

    def _loss(self, d3d, d2d, los, fc, h_bs, h_ut):
        pl0 = fspl_db(self.d0, fc * 1e9)
        loss = pl0 + 10.0 * self.n * np.log10(d3d / self.d0)
        return loss, {"reference_fspl_db": np.full_like(loss, pl0), "distance_term_db": loss - pl0}


def _breakpoint(h_bs, h_ut, fc_ghz, h_e=1.0):
    return 4.0 * (h_bs - h_e) * (h_ut - h_e) * fc_ghz * 1e9 / C_LIGHT


class UrbanMicro(PathLossModel):
    model_id = "UrbanMicro (3GPP TR 38.901 UMi street canyon)"
    sigma_los_db, sigma_nlos_db = 4.0, 7.82

    def _loss(self, d3d, d2d, los, fc, h_bs, h_ut):
        dbp = _breakpoint(h_bs, h_ut, fc)
        pl1 = 32.4 + 21.0 * np.log10(d3d) + 20.0 * np.log10(fc)
        pl2 = (32.4 + 40.0 * np.log10(d3d) + 20.0 * np.log10(fc)
               - 9.5 * np.log10(dbp**2 + (h_bs - h_ut) ** 2))
        pl_los = np.where(d2d <= dbp, pl1, pl2)
        pl_nlos = np.maximum(pl_los, 35.3 * np.log10(d3d) + 22.4 + 21.3 * np.log10(fc) - 0.3 * (h_ut - 1.5))
        loss = np.where(los, pl_los, pl_nlos)
        return loss, {"los_formula_db": pl_los, "nlos_formula_db": pl_nlos}


class UrbanMacro(PathLossModel):
    model_id = "UrbanMacro (3GPP TR 38.901 UMa)"
    sigma_los_db, sigma_nlos_db = 4.0, 6.0

    def _loss(self, d3d, d2d, los, fc, h_bs, h_ut):
        dbp = _breakpoint(h_bs, h_ut, fc)
        pl1 = 28.0 + 22.0 * np.log10(d3d) + 20.0 * np.log10(fc)
        pl2 = (28.0 + 40.0 * np.log10(d3d) + 20.0 * np.log10(fc)
               - 9.0 * np.log10(dbp**2 + (h_bs - h_ut) ** 2))
        pl_los = np.where(d2d <= dbp, pl1, pl2)
        pl_nlos = np.maximum(pl_los, 13.54 + 39.08 * np.log10(d3d) + 20.0 * np.log10(fc) - 0.6 * (h_ut - 1.5))
        loss = np.where(los, pl_los, pl_nlos)
        return loss, {"los_formula_db": pl_los, "nlos_formula_db": pl_nlos}


class Indoor(PathLossModel):
    model_id = "Indoor (3GPP TR 38.901 InH-Office)"
    validity_ghz = (0.5, 100.0)
    sigma_los_db, sigma_nlos_db = 3.0, 8.03

    def _loss(self, d3d, d2d, los, fc, h_bs, h_ut):
        pl_los = 32.4 + 17.3 * np.log10(d3d) + 20.0 * np.log10(fc)
        pl_nlos = np.maximum(pl_los, 38.3 * np.log10(d3d) + 17.30 + 24.9 * np.log10(fc))
        return np.where(los, pl_los, pl_nlos), {"los_formula_db": pl_los, "nlos_formula_db": pl_nlos}


class Rural(PathLossModel):
    model_id = "Rural (3GPP TR 38.901 RMa; transcribed, unverified against the standard text)"
    validity_ghz = (0.5, 30.0)
    sigma_los_db, sigma_nlos_db = 4.0, 8.0

    def __init__(self, avg_building_height_m: float = 5.0, avg_street_width_m: float = 20.0) -> None:
        self.h, self.w = avg_building_height_m, avg_street_width_m

    def _pl1(self, d3d, fc):
        h = self.h
        return (20.0 * np.log10(40.0 * np.pi * d3d * fc / 3.0)
                + min(0.03 * h**1.72, 10.0) * np.log10(d3d) - min(0.044 * h**1.72, 14.77)
                + 0.002 * np.log10(h) * d3d)

    def _loss(self, d3d, d2d, los, fc, h_bs, h_ut):
        dbp = 2.0 * np.pi * h_bs * h_ut * fc * 1e9 / C_LIGHT
        pl1 = self._pl1(d3d, fc)
        d_bp3 = np.sqrt(dbp**2 + (h_bs - h_ut) ** 2)
        pl2 = self._pl1(d_bp3, fc) + 40.0 * np.log10(d3d / d_bp3)
        pl_los = np.where(d2d <= dbp, pl1, pl2)
        h, w = self.h, self.w
        nl = (161.04 - 7.1 * np.log10(w) + 7.5 * np.log10(h)
              - (24.37 - 3.7 * (h / h_bs) ** 2) * np.log10(h_bs)
              + (43.42 - 3.1 * np.log10(h_bs)) * (np.log10(d3d) - 3.0) + 20.0 * np.log10(fc)
              - (3.2 * np.log10(11.75 * h_ut) ** 2 - 4.97))
        pl_nlos = np.maximum(pl_los, nl)
        return np.where(los, pl_los, pl_nlos), {"los_formula_db": pl_los, "nlos_formula_db": pl_nlos}
