"""RadioEnvironment: geometric description of the physical world (ENU metres, z up).

Contents: buildings (axis-aligned boxes rasterised to a height map), a road network (graph of
intersections), weather. Terrain is flat (z = 0). LoS/NLoS is decided geometrically by ray-marching the
height map - it is not drawn from a probability. Vegetation, reflectors and non-box obstacles are not
modelled yet (documented limitation).
"""
from __future__ import annotations

from dataclasses import dataclass

import networkx as nx
import numpy as np

from sixglab.config.models import EnvironmentConfig
from sixglab.core.errors import ConfigurationError


@dataclass(frozen=True)
class Building:
    x_min: float
    y_min: float
    x_max: float
    y_max: float
    height: float


@dataclass(frozen=True)
class Weather:
    temperature_k: float = 288.15
    water_vapour_density_g_m3: float = 7.5
    rain_rate_mm_h: float = 0.0


class RoadNetwork:
    """Undirected graph whose nodes are intersections with (x, y) coordinates."""

    def __init__(self, graph: nx.Graph) -> None:
        self.graph = graph
        self.node_ids = sorted(graph.nodes)
        self.coords = np.array([graph.nodes[n]["pos"] for n in self.node_ids], dtype=float)
        idx = {n: i for i, n in enumerate(self.node_ids)}
        self.neighbours: list[np.ndarray] = [
            np.array(sorted(idx[m] for m in graph.neighbors(n)), dtype=int) for n in self.node_ids
        ]

    @property
    def n_nodes(self) -> int:
        return len(self.node_ids)

    def edge_length(self, a: int, b: int) -> float:
        return float(np.linalg.norm(self.coords[a] - self.coords[b]))


class RadioEnvironment:
    def __init__(self, extent: tuple[float, float, float, float], buildings: list[Building],
                 roads: RoadNetwork, weather: Weather, resolution_m: float = 2.0,
                 los_samples: int = 160) -> None:
        self.extent = extent
        self.buildings = buildings
        self.roads = roads
        self.weather = weather
        self.res = resolution_m
        self.los_samples = los_samples
        x0, y0, x1, y1 = extent
        self.nx = int(np.ceil((x1 - x0) / resolution_m))
        self.ny = int(np.ceil((y1 - y0) / resolution_m))
        self.height_map = np.zeros((self.ny, self.nx), dtype=np.float32)
        for b in buildings:
            ix0, ix1 = int((b.x_min - x0) // resolution_m), int(np.ceil((b.x_max - x0) / resolution_m))
            iy0, iy1 = int((b.y_min - y0) // resolution_m), int(np.ceil((b.y_max - y0) / resolution_m))
            self.height_map[iy0:iy1, ix0:ix1] = np.maximum(self.height_map[iy0:iy1, ix0:ix1], b.height)

    # ---- construction -------------------------------------------------------------------
    @classmethod
    def generate_city(cls, cfg: EnvironmentConfig, rng: np.random.Generator) -> RadioEnvironment:
        if cfg.building_height_max_m < cfg.building_height_min_m:
            raise ConfigurationError("building_height_max_m < building_height_min_m")
        pitch = cfg.block_m + cfg.street_m
        w = cfg.blocks_x * pitch + cfg.street_m
        h = cfg.blocks_y * pitch + cfg.street_m
        buildings: list[Building] = []
        lot = cfg.block_m / cfg.lots_per_block_side
        gap = 3.0  # alley between lots
        for bx in range(cfg.blocks_x):
            for by in range(cfg.blocks_y):
                x_b = cfg.street_m + bx * pitch
                y_b = cfg.street_m + by * pitch
                for i in range(cfg.lots_per_block_side):
                    for j in range(cfg.lots_per_block_side):
                        if rng.random() < cfg.empty_lot_probability:
                            continue
                        height = float(rng.uniform(cfg.building_height_min_m, cfg.building_height_max_m))
                        buildings.append(Building(
                            x_b + i * lot + gap / 2, y_b + j * lot + gap / 2,
                            x_b + (i + 1) * lot - gap / 2, y_b + (j + 1) * lot - gap / 2, height))
        g = nx.Graph()
        for i in range(cfg.blocks_x + 1):
            for j in range(cfg.blocks_y + 1):
                g.add_node((i, j), pos=(cfg.street_m / 2 + i * pitch, cfg.street_m / 2 + j * pitch))
        for i in range(cfg.blocks_x + 1):
            for j in range(cfg.blocks_y + 1):
                if i < cfg.blocks_x:
                    g.add_edge((i, j), (i + 1, j))
                if j < cfg.blocks_y:
                    g.add_edge((i, j), (i, j + 1))
        return cls((0.0, 0.0, w, h), buildings, RoadNetwork(g),
                   Weather(cfg.temperature_k), cfg.raster_resolution_m, cfg.los_samples)

    # ---- queries ------------------------------------------------------------------------
    @property
    def size(self) -> tuple[float, float]:
        return self.extent[2] - self.extent[0], self.extent[3] - self.extent[1]

    def obstacle_height_at(self, xy: np.ndarray) -> np.ndarray:
        x0, y0, _, _ = self.extent
        ix = np.clip(((xy[..., 0] - x0) // self.res).astype(int), 0, self.nx - 1)
        iy = np.clip(((xy[..., 1] - y0) // self.res).astype(int), 0, self.ny - 1)
        return self.height_map[iy, ix]

    def is_inside_building(self, xy: np.ndarray, z: float = 1.5) -> np.ndarray:
        return self.obstacle_height_at(xy) > z

    def los(self, tx: np.ndarray, rx: np.ndarray) -> np.ndarray:
        """Boolean LoS matrix (n_tx, n_rx) by ray-marching the building height map.

        A link is NLoS if the straight ray is below the obstacle height at any sampled point. Samples are
        spaced ``d / los_samples`` apart, so links longer than ~los_samples * resolution/2 lose
        sub-cell accuracy (documented tolerance ~1 raster cell).
        """
        tx = np.atleast_2d(tx)
        rx = np.atleast_2d(rx)
        k = self.los_samples
        t = (np.arange(1, k + 1) / (k + 1)).astype(np.float32)  # exclude the endpoints
        out = np.ones((tx.shape[0], rx.shape[0]), dtype=bool)
        for i in range(tx.shape[0]):
            p = tx[i][None, None, :] + t[None, :, None] * (rx[:, None, :] - tx[i][None, None, :])
            obst = self.obstacle_height_at(p[..., :2])
            out[i] = ~np.any(p[..., 2] < obst, axis=1)
        return out

    def snap_to_intersection(self, xy: np.ndarray) -> int:
        return int(np.argmin(np.linalg.norm(self.roads.coords - np.asarray(xy), axis=1)))

    def place_base_stations(self, n: int, height_m: float) -> np.ndarray:
        """Regular grid of targets snapped to distinct road intersections."""
        w, h = self.size
        cols = max(1, int(round(np.sqrt(n * w / h))))
        rows = int(np.ceil(n / cols))
        targets = [((c + 0.5) * w / cols, (r + 0.5) * h / rows) for r in range(rows) for c in range(cols)][:n]
        chosen: list[int] = []
        for tgt in targets:
            d = np.linalg.norm(self.roads.coords - np.asarray(tgt), axis=1)
            for idx in np.argsort(d):
                if int(idx) not in chosen:
                    chosen.append(int(idx))
                    break
        if len(chosen) < n:
            raise ConfigurationError(f"cannot place {n} base stations on {self.roads.n_nodes} intersections")
        xy = self.roads.coords[chosen]
        return np.column_stack([xy, np.full(len(chosen), height_m)])

    def place_edge_servers(self, n: int, bs_xy: np.ndarray) -> np.ndarray:
        """Edge sites at the intersections nearest the k-means-like grid of BS positions."""
        order = np.argsort(bs_xy[:, 0] + 1e-3 * bs_xy[:, 1])
        picks = [order[int((i + 0.5) * len(order) / n)] for i in range(n)]
        return bs_xy[picks].copy()
