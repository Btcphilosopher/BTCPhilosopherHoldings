"""ChannelCoder abstraction with a REAL Polar code (successive-cancellation, min-sum) so that coding gain is measured.

LDPC is not implemented yet (roadmap). The system-level simulator does not call these coders per block; it uses the
gap-to-Shannon abstraction in sixglab.radio.mcs, which is labelled as a research approximation.
"""
from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np

from sixglab.core.errors import ConfigurationError


class ChannelCoder(ABC):
    name = "abstract"

    @property
    @abstractmethod
    def rate(self) -> float: ...

    @abstractmethod
    def encode(self, bits: np.ndarray) -> np.ndarray: ...

    @abstractmethod
    def decode(self, llr: np.ndarray) -> np.ndarray: ...


class UncodedCoder(ChannelCoder):
    name = "uncoded"
    rate = 1.0

    def encode(self, bits):
        return np.asarray(bits, dtype=np.uint8)

    def decode(self, llr):
        return (np.asarray(llr) < 0).astype(np.uint8)


class PolarCoder(ChannelCoder):
    """Arikan polar code of length N = 2^n and K information bits; frozen set from polarization-weight ordering
    (w_i = sum_j b_j 2^(j/4), the construction used as the basis of the 5G reliability sequence)."""
    name = "polar-SC"

    def __init__(self, n_log2: int = 8, k: int = 128) -> None:
        self.n = 1 << n_log2
        if not (1 <= k <= self.n):
            raise ConfigurationError("K must satisfy 1 <= K <= N")
        self.k = k
        idx = np.arange(self.n)
        w = np.zeros(self.n)
        for j in range(n_log2):
            w += ((idx >> j) & 1) * 2.0 ** (j / 4.0)
        self.info = np.sort(np.argsort(-w, kind="stable")[:k])
        self.frozen = np.ones(self.n, dtype=bool)
        self.frozen[self.info] = False

    @property
    def rate(self) -> float:
        return self.k / self.n

    def encode(self, bits: np.ndarray) -> np.ndarray:
        u = np.zeros(self.n, dtype=np.uint8)
        u[self.info] = np.asarray(bits, dtype=np.uint8)
        x = u.copy()
        step = 1
        while step < self.n:                                   # x = u F^{(x)n}
            for i in range(0, self.n, 2 * step):
                x[i:i + step] ^= x[i + step:i + 2 * step]
            step *= 2
        return x

    def decode(self, llr: np.ndarray) -> np.ndarray:
        u, _ = self._sc(np.asarray(llr, dtype=float), self.frozen)
        return u[self.info]

    def _sc(self, llr, frozen):
        if len(llr) == 1:
            bit = 0 if frozen[0] else int(llr[0] < 0)
            return np.array([bit], dtype=np.uint8), np.array([bit], dtype=np.uint8)
        h = len(llr) // 2
        a, b = llr[:h], llr[h:]
        f = np.sign(a) * np.sign(b) * np.minimum(np.abs(a), np.abs(b))
        u1, x1 = self._sc(f, frozen[:h])
        g = b + (1 - 2 * x1.astype(float)) * a
        u2, x2 = self._sc(g, frozen[h:])
        return np.concatenate([u1, u2]), np.concatenate([x1 ^ x2, x2])


def bpsk_awgn_llr(x_bits: np.ndarray, ebn0_db: float, rate: float, rng: np.random.Generator) -> np.ndarray:
    """BPSK (0 -> +1) over AWGN; returns channel LLRs 2y/sigma^2."""
    es_n0 = rate * 10 ** (ebn0_db / 10.0)
    sigma2 = 1.0 / (2.0 * es_n0)
    y = (1 - 2.0 * x_bits) + rng.normal(0.0, np.sqrt(sigma2), x_bits.shape)
    return 2.0 * y / sigma2
