"""Gray-mapped square QAM (QPSK, 16, 64, 256) with unit average symbol energy, hard-decision demodulation,
theoretical AWGN BER and a Monte Carlo BER test."""
from __future__ import annotations

import numpy as np
from scipy.special import erfc

from sixglab.core.errors import ConfigurationError

SCHEMES = {"QPSK": 4, "16-QAM": 16, "64-QAM": 64, "256-QAM": 256}


def _order(scheme: str) -> int:
    if scheme not in SCHEMES:
        raise ConfigurationError(f"unknown modulation {scheme!r}; supported: {sorted(SCHEMES)}")
    return SCHEMES[scheme]


def bits_per_symbol(scheme: str) -> int:
    return int(np.log2(_order(scheme)))


def _gray(n: np.ndarray) -> np.ndarray:
    return n ^ (n >> 1)


def _gray_inverse(g: np.ndarray) -> np.ndarray:
    n = g.copy()
    shift = 1
    while (g >> shift).any():
        n ^= g >> shift
        shift += 1
    return n


def modulate(bits: np.ndarray, scheme: str) -> np.ndarray:
    m = _order(scheme)
    k = int(np.log2(m))
    bits = np.asarray(bits, dtype=np.uint8).ravel()
    if bits.size % k:
        raise ConfigurationError(f"bit count {bits.size} is not a multiple of {k}")
    b = bits.reshape(-1, k)
    half = k // 2
    weights = 1 << np.arange(half - 1, -1, -1)
    gi = (b[:, :half] * weights).sum(axis=1)                    # Gray-coded index per axis
    gq = (b[:, half:] * weights).sum(axis=1)
    side = int(np.sqrt(m))
    level = lambda g: 2 * _gray_inverse(g) - (side - 1)         # noqa: E731
    scale = np.sqrt(2.0 * (m - 1) / 3.0)
    return (level(gi) + 1j * level(gq)) / scale


def demodulate(symbols: np.ndarray, scheme: str) -> np.ndarray:
    m = _order(scheme)
    k = int(np.log2(m))
    half = k // 2
    side = int(np.sqrt(m))
    scale = np.sqrt(2.0 * (m - 1) / 3.0)
    s = np.asarray(symbols).ravel() * scale

    def axis_bits(x):
        idx = np.clip(np.rint((x + (side - 1)) / 2.0), 0, side - 1).astype(np.int64)
        g = _gray(idx)
        return ((g[:, None] >> np.arange(half - 1, -1, -1)) & 1).astype(np.uint8)

    return np.concatenate([axis_bits(s.real), axis_bits(s.imag)], axis=1).ravel()


def theoretical_ber_awgn(ebn0_db, scheme: str) -> np.ndarray:
    """Standard Gray-coded square-QAM approximation (tight for BER < 1e-2):
    BER ~= (4/k)(1 - 1/sqrt(M)) Q( sqrt(3 k Eb/N0 / (M-1)) )."""
    m = _order(scheme)
    k = np.log2(m)
    ebn0 = 10 ** (np.asarray(ebn0_db, dtype=float) / 10.0)
    q = 0.5 * erfc(np.sqrt(3.0 * k * ebn0 / (m - 1)) / np.sqrt(2.0))
    ber = (4.0 / k) * (1.0 - 1.0 / np.sqrt(m)) * q
    if m == 4:
        ber = q                                                # exact for Gray QPSK
    return ber


def awgn(symbols: np.ndarray, ebn0_db: float, scheme: str, rng: np.random.Generator) -> np.ndarray:
    k = np.log2(_order(scheme))
    n0 = 1.0 / (k * 10 ** (ebn0_db / 10.0))                    # Es = 1
    noise = (rng.standard_normal(symbols.shape) + 1j * rng.standard_normal(symbols.shape)) * np.sqrt(n0 / 2)
    return symbols + noise


def ber_test(scheme: str, ebn0_db: float, n_bits: int, rng: np.random.Generator) -> float:
    k = bits_per_symbol(scheme)
    n_bits -= n_bits % k
    bits = rng.integers(0, 2, n_bits, dtype=np.uint8)
    rx = awgn(modulate(bits, scheme), ebn0_db, scheme, rng)
    return float(np.mean(demodulate(rx, scheme) != bits))
