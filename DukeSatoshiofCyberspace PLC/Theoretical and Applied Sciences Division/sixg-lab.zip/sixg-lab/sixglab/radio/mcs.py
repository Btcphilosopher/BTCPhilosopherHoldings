"""Link adaptation abstraction: SINR -> CQI/MCS -> spectral efficiency.

Efficiencies and code rates are the 256-QAM CQI table of 3GPP TS 38.214 (Table 5.2.2.1-3), transcribed.
SINR thresholds are NOT taken from 3GPP: they are derived with a gap-to-Shannon link abstraction,

    SINR_req(eta) = Gamma * (2^eta - 1),     Gamma = mcs_gap_db (default 3 dB),

i.e. a mathematically explicit RESEARCH APPROXIMATION of coded performance. Replace it with
link-level BLER curves (see sixglab.radio.coding for a real Polar code) for quantitative results.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from sixglab.core.units import db_to_lin, lin_to_db

# (modulation order Qm, code rate x 1024)
_CQI_TABLE = (
    (2, 78), (2, 193), (2, 449), (4, 378), (4, 490), (4, 616), (6, 466), (6, 567),
    (6, 666), (6, 772), (6, 873), (8, 711), (8, 797), (8, 885), (8, 948),
)


@dataclass(frozen=True)
class LinkAdaptation:
    gap_db: float = 3.0

    @property
    def qm(self) -> np.ndarray:
        return np.array([0] + [q for q, _ in _CQI_TABLE])

    @property
    def code_rate(self) -> np.ndarray:
        return np.array([0.0] + [r / 1024.0 for _, r in _CQI_TABLE])

    @property
    def efficiency(self) -> np.ndarray:
        """bit/s/Hz per resource element (index 0 = outage)."""
        return self.qm * self.code_rate

    @property
    def thresholds_db(self) -> np.ndarray:
        """SINR needed for CQI 1..15 (length 15)."""
        eta = self.efficiency[1:]
        return lin_to_db(db_to_lin(self.gap_db) * (2.0**eta - 1.0))

    def cqi(self, sinr_db) -> np.ndarray:
        """Highest CQI whose threshold is met (0 = out of range)."""
        return np.searchsorted(self.thresholds_db, np.asarray(sinr_db, dtype=float), side="right")

    def spectral_efficiency(self, sinr_db) -> np.ndarray:
        return self.efficiency[self.cqi(sinr_db)]

    def modulation_name(self, cqi: int) -> str:
        return {0: "none", 2: "QPSK", 4: "16-QAM", 6: "64-QAM", 8: "256-QAM"}[int(self.qm[cqi])]
