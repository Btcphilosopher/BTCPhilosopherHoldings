"""Thermal noise: N = k * T * B * F  (Johnson-Nyquist, with receiver noise figure F)."""
from __future__ import annotations

import numpy as np

from sixglab.core.units import K_BOLTZMANN, db_to_lin, w_to_dbm
from sixglab.core.validation import require_nonnegative, require_positive


def thermal_noise_power_w(bandwidth_hz: float, temperature_k: float = 290.0,
                          noise_figure_db: float = 0.0) -> float:
    """Noise power in watts. N = k T B, multiplied by the linear noise figure."""
    require_positive("bandwidth_hz", bandwidth_hz)
    require_positive("temperature_k", temperature_k)
    require_nonnegative("noise_figure_db", noise_figure_db)
    return float(K_BOLTZMANN * temperature_k * bandwidth_hz * db_to_lin(noise_figure_db))


def thermal_noise_dbm(bandwidth_hz: float, temperature_k: float = 290.0,
                      noise_figure_db: float = 0.0) -> float:
    return float(w_to_dbm(np.asarray(thermal_noise_power_w(bandwidth_hz, temperature_k, noise_figure_db))))
