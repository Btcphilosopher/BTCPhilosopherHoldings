"""LinkBudget: an explicit, inspectable chain  P_tx + G_tx + G_bf - PL - shadow + G_rx  -> P_rx,
then SNR = P_rx - N and SINR = P_rx / (N + I)."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from sixglab.core.units import db_to_lin, lin_to_db, w_to_dbm
from sixglab.radio.noise import thermal_noise_power_w


@dataclass
class LinkBudget:
    tx_power_w: float
    tx_antenna_gain_db: float
    rx_antenna_gain_db: float
    path_loss_db: float
    shadowing_db: float = 0.0
    beamforming_gain_db: float = 0.0
    fading_db: float = 0.0
    bandwidth_hz: float = 1e9
    temperature_k: float = 290.0
    noise_figure_db: float = 0.0
    interference_w: float = 0.0

    @property
    def rx_power_dbm(self) -> float:
        return float(w_to_dbm(self.tx_power_w) + self.tx_antenna_gain_db + self.beamforming_gain_db
                     + self.rx_antenna_gain_db - self.path_loss_db - self.shadowing_db + self.fading_db)

    @property
    def noise_w(self) -> float:
        return thermal_noise_power_w(self.bandwidth_hz, self.temperature_k, self.noise_figure_db)

    @property
    def noise_dbm(self) -> float:
        return float(w_to_dbm(self.noise_w))

    @property
    def snr_db(self) -> float:
        return self.rx_power_dbm - self.noise_dbm

    @property
    def sinr_db(self) -> float:
        rx_w = float(db_to_lin(self.rx_power_dbm - 30.0))
        return float(lin_to_db(rx_w / (self.noise_w + self.interference_w)))

    def terms(self) -> list[dict]:
        """Ordered chain for display; every entry is an input or a computed value."""
        return [
            {"term": "Transmit power", "value": float(w_to_dbm(self.tx_power_w)), "unit": "dBm"},
            {"term": "Tx antenna gain", "value": self.tx_antenna_gain_db, "unit": "dB"},
            {"term": "Beamforming gain", "value": self.beamforming_gain_db, "unit": "dB"},
            {"term": "Path loss", "value": -self.path_loss_db, "unit": "dB"},
            {"term": "Shadowing", "value": -self.shadowing_db, "unit": "dB"},
            {"term": "Rx antenna gain", "value": self.rx_antenna_gain_db, "unit": "dB"},
            {"term": "Received power", "value": self.rx_power_dbm, "unit": "dBm"},
            {"term": "Thermal noise + NF", "value": self.noise_dbm, "unit": "dBm"},
            {"term": "Interference", "value": float(w_to_dbm(max(self.interference_w, 1e-30))), "unit": "dBm"},
            {"term": "SNR", "value": self.snr_db, "unit": "dB"},
            {"term": "SINR", "value": self.sinr_db, "unit": "dB"},
        ]


def sinr_linear(signal_w, interference_w, noise_w):
    return np.asarray(signal_w) / (np.asarray(interference_w) + noise_w)
