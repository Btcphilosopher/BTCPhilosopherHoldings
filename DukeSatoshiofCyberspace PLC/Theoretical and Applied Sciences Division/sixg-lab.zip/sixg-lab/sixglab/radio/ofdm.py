"""Configurable OFDM modem: IFFT/FFT, cyclic prefix, occupied subcarriers (DC excluded), pilots, resource blocks."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from sixglab.core.errors import ConfigurationError


@dataclass(frozen=True)
class OFDMConfig:
    fft_size: int = 4096
    subcarrier_spacing_hz: float = 960e3
    cp_length: int = 288
    num_subcarriers: int = 3300
    pilot_spacing: int = 6

    def __post_init__(self) -> None:
        if self.fft_size < 2 or (self.fft_size & (self.fft_size - 1)):
            raise ConfigurationError("fft_size must be a power of two")
        if not (0 < self.num_subcarriers < self.fft_size):
            raise ConfigurationError("num_subcarriers must satisfy 0 < num_subcarriers < fft_size")
        if self.cp_length < 0 or self.cp_length >= self.fft_size:
            raise ConfigurationError("invalid cp_length")

    @property
    def sample_rate_hz(self) -> float:
        return self.fft_size * self.subcarrier_spacing_hz

    @property
    def occupied_bandwidth_hz(self) -> float:
        return self.num_subcarriers * self.subcarrier_spacing_hz

    @property
    def symbol_duration_s(self) -> float:
        return (self.fft_size + self.cp_length) / self.sample_rate_hz

    @property
    def cp_duration_s(self) -> float:
        return self.cp_length / self.sample_rate_hz

    @property
    def num_resource_blocks(self) -> int:
        return self.num_subcarriers // 12

    @property
    def cp_overhead(self) -> float:
        return self.cp_length / (self.fft_size + self.cp_length)

    def subcarrier_bins(self) -> np.ndarray:
        """FFT bins used: half below and half above DC (DC bin unused)."""
        half = self.num_subcarriers // 2
        pos = np.arange(1, half + 1)
        neg = np.arange(self.fft_size - (self.num_subcarriers - half), self.fft_size)
        return np.concatenate([neg, pos])

    def pilot_mask(self) -> np.ndarray:
        m = np.zeros(self.num_subcarriers, dtype=bool)
        m[:: self.pilot_spacing] = True
        return m


class OFDMModem:
    def __init__(self, cfg: OFDMConfig) -> None:
        self.cfg = cfg
        self.bins = cfg.subcarrier_bins()

    def modulate(self, grid: np.ndarray) -> np.ndarray:
        """grid (n_symbols, num_subcarriers) -> time samples (n_symbols, fft + cp)."""
        grid = np.atleast_2d(grid)
        if grid.shape[1] != self.cfg.num_subcarriers:
            raise ConfigurationError(f"grid must have {self.cfg.num_subcarriers} subcarriers, got {grid.shape[1]}")
        x = np.zeros((grid.shape[0], self.cfg.fft_size), dtype=complex)
        x[:, self.bins] = grid
        t = np.fft.ifft(x, axis=1) * np.sqrt(self.cfg.fft_size)      # unitary scaling
        cp = self.cfg.cp_length
        return np.concatenate([t[:, -cp:], t], axis=1) if cp else t

    def demodulate(self, samples: np.ndarray) -> np.ndarray:
        samples = np.atleast_2d(samples)
        t = samples[:, self.cfg.cp_length:]
        x = np.fft.fft(t, axis=1) / np.sqrt(self.cfg.fft_size)
        return x[:, self.bins]

    def insert_pilots(self, data: np.ndarray, pilot_value: complex = 1.0 + 0j) -> np.ndarray:
        """Fill pilot positions with a known symbol and the remaining ones with ``data`` (row-major)."""
        mask = self.cfg.pilot_mask()
        n_data = int((~mask).sum())
        data = np.asarray(data).ravel()
        if data.size % n_data:
            raise ConfigurationError(f"data length must be a multiple of {n_data}")
        rows = data.size // n_data
        grid = np.full((rows, self.cfg.num_subcarriers), pilot_value, dtype=complex)
        grid[:, ~mask] = data.reshape(rows, n_data)
        return grid
