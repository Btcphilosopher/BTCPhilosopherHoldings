"""Reduced-order molecular absorption (sub-THz / THz).

MODEL: sum of Lorentzian-like line shapes for the dominant O2 / H2O resonances plus a
water-vapour continuum ~ f^2:

    gamma(f) [dB/km] = sum_i P_i * s_i * (1 + ((f - f_i)/w_i)^2)^(-3/2)  +  C * s_w * f_GHz^2

s_i = rho/7.5 for water lines, 1 for oxygen lines. Peak values P_i are COARSE anchors read from the
shape of ITU-R P.676 sea-level curves (7.5 g/m^3, 15 C, 1013 hPa). They are NOT a line-by-line
implementation. Expected accuracy: within a factor ~2 in window regions; peaks are indicative only.
Temperature/pressure dependence is not modelled. Use ITU-R P.676 line-by-line for quantitative work.
"""
from __future__ import annotations

import numpy as np

from sixglab.core.validation import require_nonnegative, require_positive

# (center GHz, peak dB/km at 7.5 g/m^3, half-width GHz, is_water)
_LINES = (
    (22.235, 0.20, 2.5, True),
    (60.0, 15.0, 4.0, False),
    (118.75, 2.5, 1.5, False),
    (183.31, 28.0, 3.0, True),
    (325.15, 90.0, 4.0, True),
    (380.20, 200.0, 4.0, True),
    (448.00, 250.0, 5.0, True),
    (557.00, 500.0, 6.0, True),
)
_CONTINUUM_DB_KM_PER_GHZ2 = 6.6e-5  # water-vapour continuum at 7.5 g/m^3
_REFERENCE_RHO = 7.5
MODEL_ID = "reduced-order molecular absorption v1 (Lorentzian lines + f^2 continuum; coarse ITU-R P.676 anchors)"


def specific_attenuation_db_per_km(frequency_hz, water_vapour_density_g_m3: float = 7.5):
    f = np.asarray(frequency_hz, dtype=float)
    require_positive("frequency_hz", f)
    require_nonnegative("water_vapour_density_g_m3", water_vapour_density_g_m3)
    fg = f / 1e9
    s_w = water_vapour_density_g_m3 / _REFERENCE_RHO
    total = np.zeros_like(fg)
    for f0, peak, w, is_water in _LINES:
        total = total + peak * (s_w if is_water else 1.0) * (1.0 + ((fg - f0) / w) ** 2) ** -1.5
    total = total + _CONTINUUM_DB_KM_PER_GHZ2 * s_w * fg**2
    return total


def absorption_loss_db(distance_m, frequency_hz, water_vapour_density_g_m3: float = 7.5):
    """Total molecular absorption loss over a path of ``distance_m``."""
    d = np.asarray(distance_m, dtype=float)
    require_nonnegative("distance_m", d)
    return specific_attenuation_db_per_km(frequency_hz, water_vapour_density_g_m3) * d / 1000.0
