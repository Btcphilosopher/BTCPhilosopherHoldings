"""Edge offloading comparison: local vs edge vs cloud, with latency (uplink, queue, compute, downlink,
transport) and UE energy, using achievable rates measured from a Simulation.

Local energy: kappa f^2 per cycle (dynamic CMOS model). Radio energy: P_tx * t_uplink + P_rx * t_downlink.
Uplink/downlink rates: full-band rate at the selected MCS times a TDD time share (assumption, configurable).
Uplink SINR ignores UL interference (documented simplification: SNR-limited uplink).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from sixglab.core.units import db_to_lin, lin_to_db
from sixglab.edge.server import EdgeServer


@dataclass(frozen=True)
class Task:
    input_bits: float
    output_bits: float
    compute_cycles: float
    deadline_s: float
    priority: int = 0
    latency_budget_s: float = 0.02


@dataclass(frozen=True)
class OffloadParams:
    ue_cycles_per_s: float = 2.0e9
    kappa: float = 1e-28                 # J s^2 / cycle^3
    ue_tx_power_w: float = 0.2
    ue_rx_power_w: float = 0.8
    ul_share: float = 0.2
    dl_share: float = 0.8
    cloud_cycles_per_s: float = 5.0e11
    cloud_rtt_s: float = 0.020
    edge_cost_per_gcycle: float = 4e-6
    cloud_cost_per_gcycle: float = 2e-6


def xr_frame_task() -> Task:
    """Edge-rendered XR frame at 60 Hz: 4 kB pose/sensor uplink, 3e10 GPU-equivalent operations, 1.2 MB compressed frame
    downlink, 20 ms motion-to-photon budget. Illustrative scenario inputs, not measurements."""
    return Task(input_bits=4e3 * 8, output_bits=1.2e6 * 8, compute_cycles=3.0e10, deadline_s=1 / 60, latency_budget_s=0.020)


def link_rates(sim, u: int, p: OffloadParams) -> tuple[float, float]:
    """(uplink_bps, downlink_bps) for UE u from the latest epoch."""
    st, rad = sim.state, sim.cfg.radio
    b = int(st.serving[u])
    dl_full = float(st.rate_bps[u])
    g_bs = sim.g_bs_fixed if not sim.array_mode else float(db_to_lin(st.beam_gain_db[u]))
    pl = float(db_to_lin(st.pl_db[b, u] + st.shadow_db[b, u]))
    snr_ul = p.ue_tx_power_w * float(db_to_lin(rad.antenna.ue_gain_dbi)) * g_bs / pl / sim.noise_w
    ul_full = rad.bandwidth_hz * sim.la.spectral_efficiency(lin_to_db(snr_ul) + sim.fading_margin_db) * (1 - rad.overhead_fraction)
    return float(ul_full * p.ul_share), float(dl_full * p.dl_share)


def compare(task: Task, ul_bps: float, dl_bps: float, transport_s: float, edge: EdgeServer,
            edge_background_rate_hz: float, edge_background_cycles: float, p: OffloadParams | None = None) -> dict:
    p = p or OffloadParams()
    out: dict = {}
    t_loc = task.compute_cycles / p.ue_cycles_per_s
    out["local"] = {"compute_s": t_loc, "total_s": t_loc, "energy_j": p.kappa * p.ue_cycles_per_s**2 * task.compute_cycles,
                    "cost": 0.0}
    if ul_bps <= 0 or dl_bps <= 0:
        for k in ("edge", "cloud"):
            out[k] = {"total_s": float("inf"), "energy_j": float("inf"), "cost": float("nan"), "reason": "no radio link"}
    else:
        t_ul, t_dl = task.input_bits / ul_bps, task.output_bits / dl_bps
        lam = np.array([edge_background_rate_hz, 1.0 / max(task.deadline_s, 1e-9)])
        cyc = np.array([edge_background_cycles, task.compute_cycles])
        resp, rho, sat = edge.response_time_s(lam, cyc)
        t_edge = float(resp[1])
        service = task.compute_cycles / edge.cpu_cycles_per_s
        e_radio = p.ue_tx_power_w * t_ul + p.ue_rx_power_w * t_dl
        out["edge"] = {"uplink_s": t_ul, "transport_s": 2 * transport_s, "queue_s": max(t_edge - service, 0.0),
                       "compute_s": service, "downlink_s": t_dl, "edge_utilisation": rho, "saturated": sat,
                       "total_s": t_ul + 2 * transport_s + t_edge + t_dl, "energy_j": e_radio,
                       "cost": p.edge_cost_per_gcycle * task.compute_cycles / 1e9}
        t_c = task.compute_cycles / p.cloud_cycles_per_s
        out["cloud"] = {"uplink_s": t_ul, "transport_s": p.cloud_rtt_s, "compute_s": t_c, "downlink_s": t_dl,
                        "total_s": t_ul + p.cloud_rtt_s + t_c + t_dl, "energy_j": e_radio,
                        "cost": p.cloud_cost_per_gcycle * task.compute_cycles / 1e9}
    for k, v in out.items():
        v["meets_budget"] = bool(v["total_s"] <= task.latency_budget_s)
    return out
