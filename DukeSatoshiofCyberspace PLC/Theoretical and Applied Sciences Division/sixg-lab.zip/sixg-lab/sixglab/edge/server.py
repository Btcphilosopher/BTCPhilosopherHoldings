"""EdgeServer with an M/G/1 (Pollaczek-Khinchine) processing queue and a linear power model."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class EdgeServer:
    server_id: str
    cpu_cycles_per_s: float
    gpu_flops: float = 0.0
    memory_bytes: float = 64e9
    network_bandwidth_bps: float = 1e11
    idle_power_w: float = 150.0
    max_power_w: float = 600.0
    max_wait_s: float = 0.1

    def utilisation(self, arrival_rate_hz: np.ndarray, cycles: np.ndarray) -> float:
        return float(np.sum(arrival_rate_hz * cycles) / self.cpu_cycles_per_s)

    def response_time_s(self, arrival_rate_hz: np.ndarray, cycles: np.ndarray) -> tuple[np.ndarray, float, bool]:
        """Per-class mean response time (wait + service) for classes with given arrival rates and cycle
        demands, FIFO M/G/1. Returns (response_s, rho, saturated). Saturated queues are capped at max_wait_s
        and flagged instead of returning an infinite mean."""
        lam = np.asarray(arrival_rate_hz, dtype=float)
        s = np.asarray(cycles, dtype=float) / self.cpu_cycles_per_s
        rho = float(np.sum(lam * s))
        lam_tot = float(lam.sum())
        if lam_tot <= 0:
            return s, rho, False
        es2 = float(np.sum(lam * s**2) / lam_tot) * 1.0          # deterministic service per class
        if rho >= 0.98:
            return s + self.max_wait_s, rho, True
        wait = lam_tot * es2 / (2.0 * (1.0 - rho))
        return s + min(wait, self.max_wait_s), rho, False

    def power_w(self, rho: float) -> float:
        return self.idle_power_w + (self.max_power_w - self.idle_power_w) * float(np.clip(rho, 0.0, 1.0))
