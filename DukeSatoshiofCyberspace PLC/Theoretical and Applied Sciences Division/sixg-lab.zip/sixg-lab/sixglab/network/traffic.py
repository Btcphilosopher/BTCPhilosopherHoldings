"""Traffic profiles. Values are configurable scenario inputs (typical orders of magnitude, not measurements)."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from sixglab.core.errors import ConfigurationError


@dataclass(frozen=True)
class TrafficProfile:
    name: str
    mean_rate_bps: float
    packet_bytes: int
    edge_cycles_per_packet: float
    latency_budget_s: float
    slice_name: str

    @property
    def packet_bits(self) -> float:
        return self.packet_bytes * 8.0


PROFILES: dict[str, TrafficProfile] = {p.name: p for p in (
    TrafficProfile("web", 5e6, 1500, 2e4, 0.100, "eMBB"),
    TrafficProfile("video", 25e6, 1400, 5e4, 0.100, "eMBB"),
    TrafficProfile("voice", 1e5, 200, 1e4, 0.050, "eMBB"),
    TrafficProfile("xr", 100e6, 1400, 2e5, 0.020, "XR"),
    TrafficProfile("industrial_control", 1e6, 100, 5e4, 0.002, "URLLC"),
    TrafficProfile("iot", 1e4, 50, 0.0, 1.000, "mMTC"),
    TrafficProfile("robotics", 10e6, 200, 1e5, 0.005, "URLLC"),
    TrafficProfile("autonomous_vehicle", 20e6, 500, 1e5, 0.010, "URLLC"),
    TrafficProfile("digital_twin", 50e6, 1400, 1e5, 0.020, "XR"),
)}


def assign_applications(n: int, mix: dict[str, float], rng: np.random.Generator) -> list[TrafficProfile]:
    unknown = set(mix) - set(PROFILES)
    if unknown:
        raise ConfigurationError(f"unknown traffic application(s): {sorted(unknown)}")
    names = list(mix)
    w = np.array([mix[k] for k in names], dtype=float)
    if np.any(w < 0) or w.sum() <= 0:
        raise ConfigurationError("traffic mix weights must be >= 0 with a positive sum")
    picks = rng.choice(len(names), size=n, p=w / w.sum())
    return [PROFILES[names[i]] for i in picks]
