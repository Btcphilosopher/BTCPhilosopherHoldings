"""HandoverManager: A3-style event (neighbour better than serving by a hysteresis for a time-to-trigger).

Simulates handover success/failure, ping-pong (return to the previous cell within a window) and the
interruption time during which the UE cannot be scheduled. Metric is RSRP or a wideband SINR estimate.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class HandoverStats:
    attempts: int = 0
    successes: int = 0
    failures: int = 0
    ping_pongs: int = 0
    events: list = field(default_factory=list)


class HandoverManager:
    def __init__(self, n_ue: int, hysteresis_db: float, ttt_s: float, interruption_s: float,
                 failure_quality_db: float, ping_pong_window_s: float, retry_backoff_s: float = 0.5) -> None:
        self.hyst, self.ttt, self.interruption = hysteresis_db, ttt_s, interruption_s
        self.fail_db, self.pp_window = failure_quality_db, ping_pong_window_s
        self.serving = np.full(n_ue, -1, dtype=int)
        self.previous = np.full(n_ue, -1, dtype=int)
        self.last_ho_t = np.full(n_ue, -np.inf)
        self.timer = np.zeros(n_ue)
        self.candidate = np.full(n_ue, -1, dtype=int)
        self.backoff = retry_backoff_s
        self.blocked_until = np.full(n_ue, -np.inf)     # after a failed execution the UE waits before retrying
        self.stats = HandoverStats()

    def initial_attach(self, metric_db: np.ndarray) -> np.ndarray:
        self.serving = np.argmax(metric_db, axis=0)
        return self.serving

    def update(self, t_s: float, dt_s: float, metric_db: np.ndarray, target_quality_db: np.ndarray):
        """metric_db (M,N) per-cell measurement; target_quality_db (M,N) SNR-like quality used to judge whether
        execution succeeds. Returns list of (ue, from_cell, to_cell, success, ping_pong)."""
        n = metric_db.shape[1]
        ue = np.arange(n)
        best = np.argmax(metric_db, axis=0)
        serving_val = metric_db[self.serving, ue]
        trig = (best != self.serving) & (metric_db[best, ue] > serving_val + self.hyst)
        same = trig & (best == self.candidate)
        self.timer = np.where(same, self.timer + dt_s, np.where(trig, dt_s, 0.0))
        self.candidate = np.where(trig, best, -1)
        fire = trig & (self.timer >= self.ttt) & (t_s >= self.blocked_until)
        out = []
        for u in np.nonzero(fire)[0]:
            src, dst = int(self.serving[u]), int(best[u])
            self.stats.attempts += 1
            ok = bool(target_quality_db[dst, u] >= self.fail_db)
            pp = False
            if ok:
                pp = bool(dst == self.previous[u] and (t_s - self.last_ho_t[u]) <= self.pp_window)
                self.previous[u], self.serving[u], self.last_ho_t[u] = src, dst, t_s
                self.stats.successes += 1
                self.stats.ping_pongs += int(pp)
            else:
                self.stats.failures += 1
                self.blocked_until[u] = t_s + self.backoff
            self.timer[u], self.candidate[u] = 0.0, -1
            out.append((int(u), src, dst, ok, pp))
        return out
