"""Simulation: the RAN + transport + edge system model driven epoch by epoch.

Traceability chain for every UE (see ``trace_ue``):
    configuration -> path-loss model -> link budget -> SINR -> CQI/MCS -> slot scheduler -> throughput
                                                                       -> radio + queue + transport + edge + app latency
"""
from __future__ import annotations

import time as _time
import uuid
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from sixglab.beamforming.beam_manager import BeamManager
from sixglab.channel.models import build_path_loss_model
from sixglab.channel.shadowing import ShadowingProcess
from sixglab.channel.spatial import SpatialChannel, SpatialChannelState
from sixglab.channel.stochastic import StochasticChannel, doppler_hz
from sixglab.config.models import ScenarioConfig
from sixglab.core.clock import ClockMode, SimulationClock
from sixglab.core.errors import NumericalError
from sixglab.core.events import EventBus, EventType
from sixglab.core.logging import LogContext, get_logger
from sixglab.core.provenance import collect_provenance, config_hash
from sixglab.core.rng import RngFactory
from sixglab.core.units import db_to_lin, lin_to_db, w_to_dbm
from sixglab.core.validation import require_finite
from sixglab.edge.server import EdgeServer
from sixglab.energy.model import base_station_power_w, joule_per_bit, wh_per_gb
from sixglab.mobility.models import build_model
from sixglab.network.handover import HandoverManager
from sixglab.network.scheduler import SlotMAC
from sixglab.network.topology import NetworkGraph
from sixglab.network.traffic import assign_applications
from sixglab.radio.environment import RadioEnvironment
from sixglab.radio.link_budget import LinkBudget
from sixglab.radio.mcs import LinkAdaptation
from sixglab.radio.noise import thermal_noise_power_w
from sixglab.telemetry.recorder import TelemetryRecorder, to_jsonable


@dataclass
class EpochState:
    """Everything computed in the latest epoch, kept for inspection (research mode)."""
    t_s: float = 0.0
    d3d: np.ndarray = None  # type: ignore[assignment]
    los: np.ndarray = None  # type: ignore[assignment]
    pl_db: np.ndarray = None  # type: ignore[assignment]
    pl_components: dict[str, np.ndarray] = field(default_factory=dict)
    shadow_db: np.ndarray = None  # type: ignore[assignment]
    rsrp_dbm: np.ndarray = None  # type: ignore[assignment]
    serving: np.ndarray = None  # type: ignore[assignment]
    signal_w: np.ndarray = None  # type: ignore[assignment]
    interference_w: np.ndarray = None  # type: ignore[assignment]
    sinr_db: np.ndarray = None  # type: ignore[assignment]
    tx_gain_db: np.ndarray = None  # type: ignore[assignment]
    beam_gain_db: np.ndarray = None  # type: ignore[assignment]
    cqi: np.ndarray = None  # type: ignore[assignment]
    rate_bps: np.ndarray = None  # type: ignore[assignment]
    share: np.ndarray = None  # type: ignore[assignment]
    throughput_bps: np.ndarray = None  # type: ignore[assignment]
    latency: dict[str, np.ndarray] = field(default_factory=dict)
    beam_idx: np.ndarray | None = None
    beam_panel: np.ndarray | None = None
    weights: np.ndarray | None = None
    spatial: SpatialChannelState | None = None


class Simulation:
    def __init__(self, cfg: ScenarioConfig, simulation_id: str | None = None, experiment_id: str = "-",
                 scenario_id: str | None = None) -> None:
        self.cfg = cfg
        self.simulation_id = simulation_id or uuid.uuid4().hex[:12]
        self.log = get_logger("simulation", LogContext(self.simulation_id, experiment_id, scenario_id or cfg.name))
        sim, rad = cfg.simulation, cfg.radio
        self.rf = RngFactory(sim.seed)
        self.clock = SimulationClock(sim.timestep_s, sim.duration_s, ClockMode(sim.mode), sim.speed_factor)
        self.events = EventBus()
        self.epoch = 0
        self.wall_s = 0.0

        # ---- physical world ---------------------------------------------------------------
        self.env = RadioEnvironment.generate_city(cfg.environment, self.rf.stream("environment"))
        self.env.weather = type(self.env.weather)(cfg.environment.temperature_k, rad.water_vapour_density_g_m3,
                                                  rad.rain_rate_mm_h)
        self.bs_pos = self.env.place_base_stations(cfg.network.base_stations, cfg.network.bs_height_m)
        self.n_bs = len(self.bs_pos)
        self._build_population()
        # ---- radio models -----------------------------------------------------------------
        self.pathloss = build_path_loss_model(rad)
        note = self.pathloss.validity_note(rad.carrier_frequency_hz)
        if note:
            self.log.warning("model_validity", note=note)
        self.shadow = ShadowingProcess(self.n_bs, self.n_ue, rad.shadow_decorrelation_m, self.rf.stream("shadowing"))
        self.fading = StochasticChannel(rad.fading, rad.rician_k_db, rad.nakagami_m)
        self.la = LinkAdaptation(rad.mcs_gap_db)
        self.noise_w = thermal_noise_power_w(rad.bandwidth_hz, rad.temperature_k, rad.noise_figure_db)
        self.p_tx = rad.transmit_power_w
        self.array_mode = rad.antenna.mode == "array"
        self.g_ue = float(db_to_lin(rad.antenna.ue_gain_dbi))
        self.g_bs_fixed = float(db_to_lin(rad.antenna.bs_gain_dbi))
        self.fading_margin_db = 0.0 if self.array_mode else self.fading.quantile_db(rad.bler_target)
        self.spatial = SpatialChannel(rad.antenna, rad.carrier_frequency_hz) if self.array_mode else None
        self.beams: BeamManager | None = None
        self.codebook = None
        if self.array_mode:
            a = self.spatial.arrays[0]
            w, u, ang = a.codebook(rad.antenna.codebook_azimuth_beams, rad.antenna.codebook_elevation_beams)
            self.codebook = (w, u, ang)
            self.beams = BeamManager(w, rad.antenna.codebook_azimuth_beams, rad.antenna.codebook_elevation_beams)
        # ---- network ----------------------------------------------------------------------
        net = cfg.network
        self.handover = HandoverManager(self.n_ue, net.handover.hysteresis_db, net.handover.time_to_trigger_s,
                                        net.handover.interruption_s, net.handover.failure_sinr_db,
                                        net.handover.ping_pong_window_s)
        self.mac = SlotMAC(self.n_ue, net.scheduler, sim.timestep_s, net.pf_time_constant_slots,
                           net.edge.buffer_bytes * 8.0, self.rf.stream("mac"))
        self.edge_pos = self.env.place_edge_servers(net.edge.servers, self.bs_pos[:, :2])
        self.topology = NetworkGraph.build_ran_transport(self.bs_pos, np.column_stack(
            [self.edge_pos, np.zeros(len(self.edge_pos))]) if self.edge_pos.shape[1] == 2 else self.edge_pos,
            net.edge.fibre_route_factor, net.edge.per_hop_latency_s, net.edge.core_latency_s)
        self.bs_edge = np.zeros(self.n_bs, dtype=int)
        self.bs_transport_s = np.zeros(self.n_bs)
        for b in range(self.n_bs):
            k, lat = self.topology.nearest_edge(b, net.edge.servers)
            self.bs_edge[b], self.bs_transport_s[b] = k, lat
        self.edge_servers = [EdgeServer(f"edge{k}", net.edge.cpu_cycles_per_s, idle_power_w=cfg.energy.edge_idle_w,
                                        max_power_w=cfg.energy.edge_max_w) for k in range(net.edge.servers)]
        # ---- state ------------------------------------------------------------------------
        self.telemetry = TelemetryRecorder()
        self.state = EpochState()
        self.connected = np.ones(self.n_ue, dtype=bool)
        self.share = np.zeros(self.n_ue)            # measured time share of last epoch (interference coupling)
        self._first = True
        self._prev_pos = self.ue_pos.copy()
        self._latency_samples: list[np.ndarray] = []
        self._latency_censored = 0
        self.totals = dict(bits=0.0, energy_j=0.0, offered=0.0, dropped=0.0, sched=0.0, failed=0.0,
                           bs_energy_j=0.0, edge_energy_j=0.0, ue_energy_j=0.0)
        self.cfg_hash = config_hash(cfg.model_dump(mode="json"))
        self.provenance = collect_provenance(self.cfg_hash, sim.seed, cfg.version)
        self.log.info("initialised", n_bs=self.n_bs, n_ue=self.n_ue, model=self.pathloss.model_id,
                      antenna_mode=rad.antenna.mode)

    # ------------------------------------------------------------------------------------------
    def _build_population(self) -> None:
        self.groups = []
        kinds: list[str] = []
        pos = []
        for gi, g in enumerate(self.cfg.network.populations):
            if g.count == 0:
                continue
            m = build_model(g.kind, g.count, self.rf.stream(f"mobility/{gi}/{g.kind}"), self.env, g.speed_mps, g.height_m)
            self.groups.append((g.kind, len(kinds), len(kinds) + g.count, m))
            kinds += [g.kind] * g.count
            pos.append(m.pos)
        self.ue_kind = kinds
        self.n_ue = len(kinds)
        if self.n_ue == 0:
            raise NumericalError("scenario has no UEs")
        self.ue_pos = np.vstack(pos)
        self.ue_vel = np.zeros_like(self.ue_pos)
        self.apps = assign_applications(self.n_ue, self.cfg.network.traffic.mix, self.rf.stream("traffic"))
        scale = self.cfg.network.traffic.rate_scale
        self.demand_bps = np.array([a.mean_rate_bps * scale for a in self.apps])
        self.packet_bits = np.array([a.packet_bits for a in self.apps])
        self.edge_cycles = np.array([a.edge_cycles_per_packet for a in self.apps])

    def _advance_mobility(self, dt: float) -> None:
        for _, a, b, m in self.groups:
            m.step(dt)
            self.ue_pos[a:b] = m.pos
            self.ue_vel[a:b] = m.vel

    # ------------------------------------------------------------------------------------------
    def _geometry(self, ue_pos: np.ndarray):
        d = ue_pos[None, :, :] - self.bs_pos[:, None, :]
        return np.linalg.norm(d, axis=-1), np.linalg.norm(d[..., :2], axis=-1)

    def _interference_gain(self, sp: SpatialChannelState, b: np.ndarray, panel: np.ndarray, w: np.ndarray,
                           share: np.ndarray, active: np.ndarray) -> np.ndarray:
        """Time-averaged directional gain (M, N_victims) of every gNB toward every victim, weighted by the
        share of time each of its beams is on: sum_k share_k |h_{j,u,panel_k}^T w_k|^2."""
        m, n = sp.h.shape[0], sp.h.shape[1]
        out = np.zeros((m, n))
        for j in range(m):
            ks = np.nonzero((b == j) & active)[0]
            if ks.size == 0:
                continue
            for p in np.unique(panel[ks]):
                kp = ks[panel[ks] == p]
                for s in range(sp.h.shape[2]):
                    sel = np.nonzero(sp.panel[j, :, s] == p)[0]
                    if sel.size == 0:
                        continue
                    y = sp.h[j, sel, s, :] @ w[kp].T
                    out[j, sel] += (np.abs(y) ** 2) @ share[kp]
        return out

    def _link_gains(self, ue_pos, los, rng, serving, share, active):
        """Returns (rsrp_w (M,N), tx_gain_serv (N,), tx_gain_matrix (M,N) time-averaged, extras)."""
        m, n = self.n_bs, len(ue_pos)
        if not self.array_mode:
            load = np.zeros(m)
            np.add.at(load, serving, share * active)
            load = np.clip(load, 0.0, 1.0)
            gm = np.repeat((load * self.g_bs_fixed)[:, None], n, axis=1)
            return None, np.full(n, self.g_bs_fixed), gm, {"load": load}
        sp = self.spatial.generate(self.bs_pos, ue_pos, los, rng)
        return sp, None, None, {}

    # ------------------------------------------------------------------------------------------
    def step_epoch(self) -> dict[str, Any]:
        t0 = _time.perf_counter()
        cfg, rad = self.cfg, self.cfg.radio
        sim = cfg.simulation
        dt = sim.update_interval_s
        s_n = sim.slots_per_epoch
        t = self.clock.time_s
        if not self._first:
            self._advance_mobility(dt)
        disp = np.linalg.norm(self.ue_pos - self._prev_pos, axis=1)
        self._prev_pos = self.ue_pos.copy()
        n, m = self.n_ue, self.n_bs
        idx = np.arange(n)
        rng = self.rf.stream(f"epoch/{self.epoch}")

        # 1. geometry, LoS, path loss, shadowing -------------------------------------------------
        d3d, d2d = self._geometry(self.ue_pos)
        los = self.env.los(self.bs_pos, self.ue_pos)
        plr = self.pathloss.compute(d3d, d2d, los, rad.carrier_frequency_hz, cfg.network.bs_height_m,
                                    cfg.environment.ue_height_m)
        if rad.shadowing:
            z = self.shadow.update(disp)
            shadow_db = z * np.where(los, rad.shadow_sigma_los_db, rad.shadow_sigma_nlos_db)
        else:
            shadow_db = np.zeros((m, n))
        total_loss_lin = db_to_lin(plr.loss_db + shadow_db)

        # 2. antenna / beamforming gains and RSRP ------------------------------------------------
        share_prev = np.where(self.share > 0, self.share, 1.0 / max(1, n / m)) if self._first else self.share
        serving_guess = self.handover.serving if not self._first else np.zeros(n, dtype=int)
        sp = None
        if self.array_mode:
            sp = self.spatial.generate(self.bs_pos, self.ue_pos, los, rng)
            best_gain = np.max(np.linalg.norm(sp.h, axis=-1) ** 2, axis=-1)           # ideal-beam gain (M,N)
            rsrp_w = self.p_tx * self.g_ue * best_gain / total_loss_lin
        else:
            rsrp_w = self.p_tx * self.g_bs_fixed * self.g_ue / total_loss_lin
        rsrp_dbm = w_to_dbm(rsrp_w)
        require_finite("rsrp", rsrp_dbm)

        # 3. association / handover ---------------------------------------------------------------
        load_est = self._bs_load(serving_guess, share_prev)
        if cfg.network.handover.metric == "sinr":
            tot = (rsrp_w * load_est[:, None]).sum(axis=0)
            metric_db = lin_to_db(rsrp_w / (tot[None, :] - rsrp_w * load_est[:, None] + self.noise_w))
        else:
            metric_db = rsrp_dbm
        quality_db = rsrp_dbm - float(w_to_dbm(self.noise_w))
        ho_events = []
        if self._first:
            self.handover.initial_attach(metric_db)
        else:
            ho_events = self.handover.update(t, dt, metric_db, quality_db)
        serving = self.handover.serving.copy()
        for (u, a, b, ok, pp) in ho_events:
            self.events.emit(t, EventType.HANDOVER, f"ue{u}", ue=u, source_cell=a, target_cell=b, success=ok,
                             ping_pong=pp)
            if ok:
                self.mac.interrupt_left_s[u] = cfg.network.handover.interruption_s
        reset = np.zeros(n, dtype=bool)
        for (u, a, b, ok, pp) in ho_events:
            reset[u] = ok

        # 4. serving signal, interference, SINR ----------------------------------------------------
        share_use = share_prev
        active = self.connected.copy()
        beam_gain_db = np.zeros(n)
        weights = None
        beam_idx = None
        beam_panel = None
        if self.array_mode:
            hs_all = sp.h[serving, idx]                                            # (N, S, Nt)
            slot = np.argmax(np.linalg.norm(hs_all, axis=-1), axis=-1)
            h_serv = hs_all[idx, slot]                                             # (N, Nt)
            beam_panel = sp.panel[serving, idx, slot]
            rep = self.beams.update(h_serv, reset if reset.any() else None)
            if cfg.radio.antenna.beamformer == "mrt":
                weights = np.conj(h_serv) / np.maximum(np.linalg.norm(h_serv, axis=1, keepdims=True), 1e-30)
                gain_serv = np.linalg.norm(h_serv, axis=1) ** 2
            else:
                weights = self.beams.w[rep.beam_idx]
                gain_serv = np.abs(np.einsum("nt,nt->n", h_serv, weights)) ** 2
            beam_idx = rep.beam_idx
            for u in np.nonzero(rep.switched)[0]:
                self.events.emit(t, EventType.BEAM_SWITCH, f"ue{int(u)}", ue=int(u), beam=int(beam_idx[u]))
            gain_matrix = self._interference_gain(sp, serving, beam_panel, weights, share_use, active)
            tx_gain_serv = gain_serv
            beam_gain_db = lin_to_db(gain_serv)
        else:
            load = self._bs_load(serving, share_use * active)
            gain_matrix = np.repeat((load * self.g_bs_fixed)[:, None], n, axis=1)
            tx_gain_serv = np.full(n, self.g_bs_fixed)
        sig_w = self.p_tx * self.g_ue * tx_gain_serv / total_loss_lin[serving, idx]
        i_all = self.p_tx * self.g_ue * gain_matrix / total_loss_lin                  # (M, N)
        interference_w = i_all.sum(axis=0) - i_all[serving, idx]
        interference_w = np.maximum(interference_w, 0.0)
        sinr_lin = sig_w / (interference_w + self.noise_w)
        sinr_db = lin_to_db(sinr_lin)
        require_finite("sinr", sinr_db)

        # 5. link adaptation ------------------------------------------------------------------------
        cqi = self.la.cqi(sinr_db + self.fading_margin_db)
        eta = self.la.efficiency[cqi]
        rate_bps = rad.bandwidth_hz * eta * (1.0 - rad.overhead_fraction)
        connected = cqi > 0
        for u in np.nonzero(connected & ~self.connected)[0]:
            self.events.emit(t, EventType.UE_CONNECTED, f"ue{int(u)}", ue=int(u), cell=int(serving[u]))
        for u in np.nonzero(~connected & self.connected)[0]:
            self.events.emit(t, EventType.UE_DISCONNECTED, f"ue{int(u)}", ue=int(u), cell=int(serving[u]))
        if self._first:  # the initial attach is reported as connections, not as a state change
            self.events.counts[EventType.UE_DISCONNECTED] = 0
            self.events.history = type(self.events.history)(
                (e for e in self.events.history if e.type != EventType.UE_DISCONNECTED), maxlen=self.events.history.maxlen)
        self.connected = connected

        # 6. traffic + MAC --------------------------------------------------------------------------
        speed = np.linalg.norm(self.ue_vel, axis=1)
        if self.array_mode or self.fading.kind == "none":
            g_fast = np.ones((s_n, n))
        else:
            g_fast = self.fading.sample_series(rng, s_n, n, doppler_hz(speed, rad.carrier_frequency_hz), sim.timestep_s)
        thr_lin = np.where(cqi > 0, db_to_lin(self.la.thresholds_db[np.maximum(cqi - 1, 0)]), np.inf)
        success = sinr_lin[None, :] * g_fast >= thr_lin[None, :]
        lam = self.demand_bps / self.packet_bits * sim.timestep_s
        arrivals = rng.poisson(lam, (s_n, n))
        # UEs in outage are not attached to the network: their traffic is blocked (reported as coverage outage,
        # not as congestion loss) and any stale backlog is flushed.
        blocked_bits = float((arrivals[:, ~connected] * self.packet_bits[~connected][None, :]).sum())
        arrivals[:, ~connected] = 0
        flushed = float(self.mac.backlog[~connected].sum())
        self.mac.backlog[~connected] = 0.0
        self.totals["blocked"] = self.totals.get("blocked", 0.0) + blocked_bits
        self.totals["dropped"] += flushed
        res = self.mac.run_epoch(serving, m, connected, rate_bps, success, arrivals, self.packet_bits)
        window = s_n * sim.timestep_s
        throughput = res.served_bits / window
        share = res.slots_scheduled / s_n
        self.share = share

        # 7. latency decomposition ---------------------------------------------------------------------
        lat = self._latency(res, serving, rate_bps, connected, throughput)

        # 8. energy -----------------------------------------------------------------------------------
        activity = np.zeros(m)
        np.add.at(activity, serving, share)
        p_bs = base_station_power_w(cfg.energy, cfg.radio.antenna.n_elements * (cfg.radio.antenna.panels if self.array_mode else 1),
                                    self.p_tx, activity)
        p_edge = np.array([s.power_w(r) for s, r in zip(self.edge_servers, lat["edge_rho"], strict=True)])
        p_ue = cfg.energy.ue_rx_w * float(connected.sum())
        power_w = float(p_bs.sum() + p_edge.sum() + p_ue)
        bits = float(res.served_bits.sum())
        self.totals["bits"] += bits
        self.totals["energy_j"] += power_w * dt
        self.totals["bs_energy_j"] += float(p_bs.sum()) * dt
        self.totals["edge_energy_j"] += float(p_edge.sum()) * dt
        self.totals["ue_energy_j"] += p_ue * dt
        self.totals["offered"] += float(res.offered_bits.sum())
        self.totals["dropped"] += float(res.dropped_bits.sum())
        self.totals["sched"] += float(res.extra["blocks_tx"].sum())
        self.totals["failed"] += float(res.blocks_failed.sum())
        self._latency_censored += res.censored
        if lat["sample_total_s"].size:
            self._latency_samples.append(lat["sample_total_s"])

        # 9. state + telemetry ---------------------------------------------------------------------------
        st = self.state
        st.t_s, st.d3d, st.los, st.pl_db, st.pl_components = t, d3d, los, plr.loss_db, plr.components
        st.shadow_db, st.rsrp_dbm, st.serving = shadow_db, rsrp_dbm, serving
        st.signal_w, st.interference_w, st.sinr_db = sig_w, interference_w, sinr_db
        st.tx_gain_db, st.beam_gain_db = lin_to_db(tx_gain_serv), beam_gain_db
        st.cqi, st.rate_bps, st.share, st.throughput_bps = cqi, rate_bps, share, throughput
        st.latency, st.beam_idx, st.beam_panel, st.weights, st.spatial = lat, beam_idx, beam_panel, weights, sp
        self.pl_model_id = plr.model_id
        self.events.emit(t, EventType.CHANNEL_UPDATE, "channel", mean_sinr_db=float(sinr_db.mean()),
                         los_fraction=float(los[serving, idx].mean()))

        lat_total = lat["total_ms"]
        finite = np.isfinite(lat_total)
        samples = lat["sample_total_s"]
        metrics = {
            "epoch": self.epoch, "t_s": t,
            "mean_sinr_db": float(sinr_db.mean()),
            "mean_sinr_connected_db": float(sinr_db[connected].mean()) if connected.any() else float("nan"),
            "coverage_fraction": float(connected.mean()),
            "throughput_bps": float(throughput.sum()),
            "offered_bps": float(res.offered_bits.sum() / window),
            "mean_ue_throughput_bps": float(throughput.mean()),
            "latency_mean_ms": float(lat_total[finite].mean()) if finite.any() else float("nan"),
            "latency_p95_ms": float(np.percentile(samples, 95) * 1e3) if samples.size else float("nan"),
            "network_load": float(np.clip(activity, 0, 1).mean()),
            "power_w": power_w, "energy_j": power_w * dt,
            "handovers": len(ho_events), "los_fraction": float(los[serving, idx].mean()),
            "loss_ratio": float(res.dropped_bits.sum() / max(res.offered_bits.sum(), 1.0)),
            "edge_utilisation": float(np.mean(lat["edge_rho"])),
            "serving_distance_p90_m": float(np.percentile(d3d[serving, idx][connected], 90)) if connected.any() else float("nan"),
        }
        ue_frame = {"x": self.ue_pos[:, 0], "y": self.ue_pos[:, 1], "z": self.ue_pos[:, 2], "serving": serving,
                    "sinr_db": sinr_db, "throughput_bps": throughput, "latency_ms": lat_total, "cqi": cqi}
        self.telemetry.record(metrics, ue_frame)
        self._first = False
        self.epoch += 1
        self.clock.advance(s_n)
        self.wall_s += _time.perf_counter() - t0
        self.last_metrics = metrics
        return metrics

    def _bs_load(self, serving, share) -> np.ndarray:
        load = np.zeros(self.n_bs)
        np.add.at(load, serving, share)
        return np.clip(load, 0.0, 1.0)

    # ------------------------------------------------------------------------------------------
    def _latency(self, res, serving, rate_bps, connected, throughput) -> dict[str, np.ndarray]:
        cfg = self.cfg
        n = self.n_ue
        dt = cfg.simulation.timestep_s
        edge_cfg = cfg.network.edge
        radio = np.full(n, np.nan)
        queue = np.full(n, np.nan)
        align = 0.5 * dt
        tx = np.where(rate_bps > 0, self.packet_bits / np.maximum(rate_bps, 1e-9), np.nan)
        cnt = res.delay_count
        mac_mean = np.where(cnt > 0, res.delay_sum_s / np.maximum(cnt, 1), np.nan)
        have = connected & np.isfinite(mac_mean)
        radio[have] = align + tx[have]
        queue[have] = np.maximum(mac_mean[have] - tx[have], 0.0)
        transport = self.bs_transport_s[serving]
        # edge M/G/1 per server from delivered packet rates
        edge = np.zeros(n)
        rho = np.zeros(len(self.edge_servers))
        pkt_rate = throughput / self.packet_bits
        server_of = self.bs_edge[serving]
        for k, srv in enumerate(self.edge_servers):
            ues = np.nonzero((server_of == k) & (self.edge_cycles > 0) & connected)[0]
            if ues.size == 0:
                continue
            resp, r, sat = srv.response_time_s(pkt_rate[ues], self.edge_cycles[ues])
            edge[ues] = resp
            rho[k] = r
        app = np.full(n, edge_cfg.application_latency_s)
        total = radio + queue + transport + edge + app
        # pooled per-packet samples
        s_ue = res.delay_ue
        if s_ue.size:
            sample_total = res.delays_s + align + (tx[s_ue] * 0.0) + transport[s_ue] + edge[s_ue] + app[s_ue]
        else:
            sample_total = np.empty(0)
        return {"radio_ms": radio * 1e3, "queue_ms": queue * 1e3, "transport_ms": transport * 1e3,
                "edge_ms": edge * 1e3, "application_ms": app * 1e3, "total_ms": total * 1e3,
                "edge_rho": rho, "sample_total_s": sample_total}

    # ------------------------------------------------------------------------------------------
    def run(self, progress=None, stop=None) -> dict[str, Any]:
        n_epochs = self.cfg.simulation.n_epochs
        while self.epoch < n_epochs and not (stop and stop()):
            if self.clock.paused:
                _time.sleep(0.05)
                continue
            self.step_epoch()
            self.clock.pace()
            if progress:
                progress(self.epoch, n_epochs, self.last_metrics)
        return self.summary()

    # ------------------------------------------------------------------------------------------
    def summary(self) -> dict[str, Any]:
        df = self.telemetry.dataframe()
        if df.empty:
            return {}
        tot = self.totals
        lat = np.concatenate(self._latency_samples) if self._latency_samples else np.empty(0)
        dur = float(df["t_s"].iloc[-1] + self.cfg.simulation.update_interval_s)
        ue = self.telemetry.ue_arrays()
        served_bits = tot["bits"]
        out = {
            "scenario": self.cfg.name, "simulation_id": self.simulation_id, "seed": self.cfg.simulation.seed,
            "base_stations": self.n_bs, "ues": self.n_ue, "bandwidth_hz": self.cfg.radio.bandwidth_hz,
            "carrier_hz": self.cfg.radio.carrier_frequency_hz, "simulated_time_s": dur,
            "epochs": len(df), "wall_time_s": self.wall_s,
            "path_loss_model": self.pl_model_id,
            "antenna_mode": self.cfg.radio.antenna.mode,
            "scheduler": self.cfg.network.scheduler,
            "mean_sinr_db": float(np.nanmean(ue["sinr_db"])),
            "median_sinr_db": float(np.nanmedian(ue["sinr_db"])),
            "coverage_fraction": float(df["coverage_fraction"].mean()),
            "serving_distance_p90_m": float(df["serving_distance_p90_m"].mean()),
            "mean_throughput_bps": float(df["throughput_bps"].mean()),
            "mean_ue_throughput_bps": float(df["mean_ue_throughput_bps"].mean()),
            "offered_bps": float(df["offered_bps"].mean()),
            "latency_mean_ms": float(lat.mean() * 1e3) if lat.size else float("nan"),
            "latency_p50_ms": float(np.percentile(lat, 50) * 1e3) if lat.size else float("nan"),
            "latency_p95_ms": float(np.percentile(lat, 95) * 1e3) if lat.size else float("nan"),
            "latency_p99_ms": float(np.percentile(lat, 99) * 1e3) if lat.size else float("nan"),
            "latency_samples": int(lat.size), "latency_censored": self._latency_censored,
            "packet_loss_ratio": float(tot["dropped"] / max(tot["offered"], 1.0)),
            "blocked_traffic_ratio": float(tot.get("blocked", 0.0) / max(tot.get("blocked", 0.0) + tot["offered"], 1.0)),
            "block_error_rate": float(tot["failed"] / max(tot["sched"], 1.0)),
            "energy_j": tot["energy_j"], "energy_wh": tot["energy_j"] / 3600.0,
            "mean_power_w": tot["energy_j"] / dur,
            "energy_split_j": {k: tot[k] for k in ("bs_energy_j", "edge_energy_j", "ue_energy_j")},
            "j_per_bit": joule_per_bit(tot["energy_j"], served_bits), "wh_per_gb": wh_per_gb(tot["energy_j"], served_bits),
            "jain_fairness": _jain(np.mean(ue["throughput_bps"], axis=0)),
            "handover": {"attempts": self.handover.stats.attempts, "successes": self.handover.stats.successes,
                         "failures": self.handover.stats.failures, "ping_pongs": self.handover.stats.ping_pongs},
            "events": {k.value: v for k, v in self.events.counts.items()},
            "provenance": self.provenance,
        }
        return out

    # ------------------------------------------------------------------------------------------
    def trace_ue(self, u: int) -> dict[str, Any]:
        """Full inspectable chain for UE ``u`` from the latest epoch (spec 108, 117)."""
        st = self.state
        if st.serving is None:
            raise NumericalError("no epoch has been simulated yet")
        rad = self.cfg.radio
        b = int(st.serving[u])
        comps = {k: float(v[b, u]) for k, v in st.pl_components.items()}
        interference = float(st.interference_w[u])
        lb = LinkBudget(self.p_tx, float(lin_to_db(self.g_bs_fixed)) if not self.array_mode else float(self.cfg.radio.antenna.element_gain_dbi),
                        rad.antenna.ue_gain_dbi, float(st.pl_db[b, u]), float(st.shadow_db[b, u]),
                        float(st.beam_gain_db[u]) if self.array_mode else 0.0,
                        0.0, rad.bandwidth_hz, rad.temperature_k, rad.noise_figure_db, interference)
        cqi = int(st.cqi[u])
        la = self.la
        lat = {k: (None if not np.isfinite(v[u]) else float(v[u])) for k, v in st.latency.items()
               if k.endswith("_ms")}
        return {
            "ue": int(u), "kind": self.ue_kind[u], "application": self.apps[u].name,
            "time_s": st.t_s,
            "configuration": {"carrier_frequency_hz": rad.carrier_frequency_hz, "bandwidth_hz": rad.bandwidth_hz,
                              "transmit_power_w": rad.transmit_power_w, "noise_figure_db": rad.noise_figure_db,
                              "antenna_mode": rad.antenna.mode, "fading": rad.fading, "scheduler": self.cfg.network.scheduler},
            "channel_model": {"path_loss_model": self.pl_model_id, "los": bool(st.los[b, u]),
                              "distance_3d_m": float(st.d3d[b, u]), "serving_cell": b,
                              "path_loss_components_db": comps, "path_loss_db": float(st.pl_db[b, u]),
                              "shadowing_db": float(st.shadow_db[b, u]),
                              "validity_note": self.pathloss.validity_note(rad.carrier_frequency_hz)},
            "link_budget": lb.terms(),
            "beamforming": None if not self.array_mode else {
                "beamformer": rad.antenna.beamformer, "panel": int(st.beam_panel[u]), "beam_index": int(st.beam_idx[u]),
                "beam_gain_db": float(st.beam_gain_db[u]), "array_elements": rad.antenna.n_elements},
            "sinr": {"signal_dbm": float(w_to_dbm(st.signal_w[u])), "interference_dbm": float(w_to_dbm(max(interference, 1e-30))),
                     "noise_dbm": float(w_to_dbm(self.noise_w)), "sinr_db": float(st.sinr_db[u]),
                     "fading_margin_db": self.fading_margin_db},
            "link_adaptation": {"cqi": cqi, "modulation": la.modulation_name(cqi), "code_rate": float(la.code_rate[cqi]),
                                "spectral_efficiency_bps_hz": float(la.efficiency[cqi]),
                                "threshold_db": None if cqi == 0 else float(la.thresholds_db[cqi - 1]),
                                "model": f"gap-to-Shannon abstraction, gap {rad.mcs_gap_db} dB (research approximation)"},
            "throughput": {"achievable_rate_bps": float(st.rate_bps[u]), "time_share": float(st.share[u]),
                           "delivered_bps": float(st.throughput_bps[u]), "offered_bps": float(self.demand_bps[u]),
                           "overhead_fraction": rad.overhead_fraction},
            "latency_ms": lat,
        }

    # ------------------------------------------------------------------------------------------
    def static_snapshot(self) -> dict[str, Any]:
        e = self.env
        return {
            "title": "6G DIGITAL TWIN LAB", "scenario": self.cfg.name, "simulation_id": self.simulation_id,
            "extent": list(e.extent),
            "buildings": [[b.x_min, b.y_min, b.x_max, b.y_max, b.height] for b in e.buildings],
            "roads": [[*map(float, e.roads.coords[a]), *map(float, e.roads.coords[c])]
                      for a, c in ((e.roads.node_ids.index(u), e.roads.node_ids.index(v)) for u, v in e.roads.graph.edges)],
            "base_stations": self.bs_pos.tolist(), "edge_servers": self.edge_pos.tolist(),
            "ue_kinds": self.ue_kind, "ue_apps": [a.name for a in self.apps],
            "carrier_hz": self.cfg.radio.carrier_frequency_hz, "bandwidth_hz": self.cfg.radio.bandwidth_hz,
            "path_loss_model": self.pathloss.model_id, "antenna_mode": self.cfg.radio.antenna.mode,
            "panels": self.cfg.radio.antenna.panels, "elements": self.cfg.radio.antenna.n_elements,
            "duration_s": self.cfg.simulation.duration_s, "epoch_s": self.cfg.simulation.update_interval_s,
            "n_epochs": self.cfg.simulation.n_epochs, "scheduler": self.cfg.network.scheduler,
            "slices": sorted({a.slice_name for a in self.apps}),
        }

    def frame(self) -> dict[str, Any]:
        """Compact JSON-ready frame of the latest epoch for the WebSocket stream."""
        st = self.state
        m = self.last_metrics
        n = self.n_ue
        idx = np.arange(n)
        beams = []
        if self.array_mode and st.beam_idx is not None:
            for u in range(n):
                if st.cqi[u] > 0:
                    b = int(st.serving[u])
                    beams.append([b, u, round(float(st.beam_gain_db[u]) + float(self.cfg.radio.antenna.element_gain_dbi), 1)])
        else:
            beams = [[int(st.serving[u]), u, round(float(st.tx_gain_db[u]), 1)] for u in range(n) if st.cqi[u] > 0]
        lat = st.latency
        return to_jsonable({
            "epoch": self.epoch - 1, "t": st.t_s, "metrics": m,
            "ue": {"x": np.round(self.ue_pos[:, 0], 2), "y": np.round(self.ue_pos[:, 1], 2), "z": np.round(self.ue_pos[:, 2], 2),
                   "serving": st.serving, "sinr": np.round(st.sinr_db, 2), "thr": np.round(st.throughput_bps / 1e6, 2),
                   "lat": np.round(lat["total_ms"], 3), "cqi": st.cqi, "los": st.los[st.serving, idx].astype(int)},
            "beams": beams,
            "latency_breakdown_ms": {k: _nanmean(lat[k + "_ms"]) for k in ("radio", "queue", "transport", "edge", "application")},
            "bs_load": np.round(self._bs_load(st.serving, st.share), 3),
            "events": [e.to_dict() for e in self.events.recent(12)],
            "event_counts": {k.value: v for k, v in self.events.counts.items()},
        })

    # ------------------------------------------------------------------------------------------
    def coverage_map(self, resolution_m: float = 10.0) -> dict[str, Any]:
        """SINR / RSRP / peak-rate maps on a grid, from the SAME propagation and link models as the UEs.
        Median-channel view: no shadowing; in array mode one spatial-channel realisation with real beams."""
        rad = self.cfg.radio
        x0, y0, x1, y1 = self.env.extent
        xs = np.arange(x0 + resolution_m / 2, x1, resolution_m)
        ys = np.arange(y0 + resolution_m / 2, y1, resolution_m)
        gx, gy = np.meshgrid(xs, ys)
        pts = np.column_stack([gx.ravel(), gy.ravel(), np.full(gx.size, self.cfg.environment.ue_height_m)])
        d3d, d2d = self._geometry(pts)
        los = self.env.los(self.bs_pos, pts)
        plr = self.pathloss.compute(d3d, d2d, los, rad.carrier_frequency_hz, self.cfg.network.bs_height_m,
                                    self.cfg.environment.ue_height_m)
        loss = db_to_lin(plr.loss_db)
        rng = self.rf.stream("coverage")
        n = len(pts)
        idx = np.arange(n)
        load = self._bs_load(self.handover.serving, self.share) if not self._first else np.ones(self.n_bs)
        if self.array_mode:
            sp = self.spatial.generate(self.bs_pos, pts, los, rng)
            best = np.max(np.linalg.norm(sp.h, axis=-1) ** 2, axis=-1)
            rsrp = self.p_tx * self.g_ue * best / loss
            serving = np.argmax(rsrp, axis=0)
            sig = rsrp[serving, idx]
            st = self.state
            gm = self._interference_gain(sp, st.serving, st.beam_panel, st.weights, np.maximum(self.share, 1e-3), self.connected) \
                if st.weights is not None else np.repeat(load[:, None], n, axis=1)
            iall = self.p_tx * self.g_ue * gm / loss
        else:
            rsrp = self.p_tx * self.g_bs_fixed * self.g_ue / loss
            serving = np.argmax(rsrp, axis=0)
            sig = rsrp[serving, idx]
            iall = rsrp * load[:, None]
        interference = np.maximum(iall.sum(axis=0) - iall[serving, idx], 0.0)
        sinr_db = lin_to_db(sig / (interference + self.noise_w))
        cqi = self.la.cqi(sinr_db + self.fading_margin_db)
        rate = rad.bandwidth_hz * self.la.efficiency[cqi] * (1 - rad.overhead_fraction)
        shape = gx.shape
        return to_jsonable({
            "model": self.pathloss.model_id, "resolution_m": resolution_m, "extent": [x0, y0, x1, y1],
            "nx": shape[1], "ny": shape[0],
            "rsrp_dbm": np.round(w_to_dbm(sig), 1).reshape(shape), "sinr_db": np.round(sinr_db, 1).reshape(shape),
            "peak_rate_gbps": np.round(rate / 1e9, 3).reshape(shape), "serving": serving.reshape(shape),
            "los": los[serving, idx].reshape(shape).astype(int),
            "note": "median channel (no shadowing) at UE height; peak rate = full-resource rate at the selected MCS",
        })


def _jain(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    return float(x.sum() ** 2 / (len(x) * np.sum(x**2))) if np.sum(x**2) > 0 else float("nan")


def _nanmean(a: np.ndarray) -> float:
    a = np.asarray(a, dtype=float)
    return float(np.nanmean(a)) if np.isfinite(a).any() else float("nan")
