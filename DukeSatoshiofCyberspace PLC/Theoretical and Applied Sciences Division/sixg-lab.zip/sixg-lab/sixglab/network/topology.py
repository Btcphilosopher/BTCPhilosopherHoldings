"""NetworkGraph (NetworkX): gNB, small_cell, edge_server, core, satellite, UAV, RIS nodes;
fibre / microwave / wireless / satellite edges. Latency of a path = sum of per-edge latencies."""
from __future__ import annotations

import networkx as nx
import numpy as np

from sixglab.core.units import C_LIGHT

FIBRE_SPEED = 2.0e8  # m/s in silica fibre (n ~ 1.5)
NODE_TYPES = {"gNB", "small_cell", "edge_server", "core", "satellite", "UAV", "RIS"}
EDGE_TYPES = {"fibre", "microwave", "wireless", "satellite"}


class NetworkGraph:
    def __init__(self) -> None:
        self.g = nx.Graph()

    def add_node(self, node_id: str, kind: str, pos=None, **attrs) -> None:
        if kind not in NODE_TYPES:
            raise ValueError(f"unknown node type {kind!r}")
        self.g.add_node(node_id, kind=kind, pos=None if pos is None else tuple(map(float, pos)), **attrs)

    def add_link(self, a: str, b: str, medium: str, length_m: float, per_hop_s: float = 0.0,
                 capacity_bps: float = 1e11, route_factor: float = 1.0) -> None:
        if medium not in EDGE_TYPES:
            raise ValueError(f"unknown link medium {medium!r}")
        speed = FIBRE_SPEED if medium == "fibre" else C_LIGHT
        latency = route_factor * length_m / speed + per_hop_s
        self.g.add_edge(a, b, medium=medium, length_m=length_m, latency_s=latency, capacity_bps=capacity_bps)

    def path_latency_s(self, a: str, b: str) -> float:
        return float(nx.shortest_path_length(self.g, a, b, weight="latency_s"))

    def path(self, a: str, b: str) -> list[str]:
        return nx.shortest_path(self.g, a, b, weight="latency_s")

    @classmethod
    def build_ran_transport(cls, bs_pos: np.ndarray, edge_pos: np.ndarray, route_factor: float,
                            per_hop_s: float, core_latency_s: float) -> NetworkGraph:
        """gNBs connected to their two nearest neighbours (ring-like aggregation); edge servers co-sited with a
        gNB; core attached to every edge server."""
        ng = cls()
        m = len(bs_pos)
        for i, p in enumerate(bs_pos):
            ng.add_node(f"gNB{i}", "gNB", p)
        for i in range(m):
            d = np.linalg.norm(bs_pos[:, :2] - bs_pos[i, :2], axis=1)
            for j in np.argsort(d)[1:3]:
                if not ng.g.has_edge(f"gNB{i}", f"gNB{int(j)}"):
                    ng.add_link(f"gNB{i}", f"gNB{int(j)}", "fibre", float(d[j]), per_hop_s, route_factor=route_factor)
        ng.add_node("core", "core")
        for k, p in enumerate(edge_pos):
            ng.add_node(f"edge{k}", "edge_server", p)
            host = int(np.argmin(np.linalg.norm(bs_pos[:, :2] - p[:2], axis=1)))
            ng.add_link(f"edge{k}", f"gNB{host}", "fibre", 5.0, per_hop_s)
            ng.g.add_edge(f"edge{k}", "core", medium="fibre", length_m=0.0, latency_s=core_latency_s,
                          capacity_bps=1e12)
        return ng

    def nearest_edge(self, bs_index: int, n_edge: int) -> tuple[int, float]:
        lats = [self.path_latency_s(f"gNB{bs_index}", f"edge{k}") for k in range(n_edge)]
        k = int(np.argmin(lats))
        return k, float(lats[k])
