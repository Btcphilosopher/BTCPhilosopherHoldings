"""Slot-level MAC: Round Robin, Proportional Fair, Max Throughput, plus a per-UE queue simulation.

Each slot every gNB serves ONE UE with the full band (TDMA; consistent with analog/hybrid beamforming
where one beam is active at a time). Vectorised across gNBs with padded (n_bs, K_max) index matrices.

Link adaptation uses the epoch-average SINR (slow CQI) with an outage-based margin, so the block error
rate emerges from fast fading: a slot succeeds if instantaneous SINR >= the threshold of the selected MCS.
Failed blocks leave their bits in the queue (retransmission). This is a research abstraction of HARQ
without soft combining.

Latency is MEASURED: tagged packets are followed through the FIFO using cumulative arrival/departure
curves (bit-level fluid service inside a slot), not drawn from a formula.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

SCHEDULERS = ("round_robin", "proportional_fair", "max_throughput")


@dataclass
class EpochMacResult:
    served_bits: np.ndarray            # (N,)
    offered_bits: np.ndarray           # (N,)
    dropped_bits: np.ndarray           # (N,)
    slots_scheduled: np.ndarray        # (N,)
    blocks_failed: np.ndarray          # (N,)
    backlog_bits: np.ndarray           # (N,)
    delay_sum_s: np.ndarray            # (N,) sum over resolved tagged packets
    delay_count: np.ndarray            # (N,)
    delays_s: np.ndarray               # pooled resolved tagged-packet delays in this epoch
    delay_ue: np.ndarray = field(default_factory=lambda: np.empty(0, dtype=int))  # UE index of each sample
    censored: int = 0
    n_slots: int = 0
    extra: dict = field(default_factory=dict)


class SlotMAC:
    def __init__(self, n_ue: int, scheduler: str, slot_s: float, pf_tc_slots: float,
                 buffer_bits: float, rng: np.random.Generator, tags_per_epoch: int = 3,
                 horizon_s: float = 1.0) -> None:
        if scheduler not in SCHEDULERS:
            raise ValueError(f"unknown scheduler {scheduler!r}")
        self.n, self.scheduler, self.dt, self.tc = n_ue, scheduler, slot_s, pf_tc_slots
        self.buffer, self.rng, self.tags, self.horizon = buffer_bits, rng, tags_per_epoch, horizon_s
        self.backlog = np.zeros(n_ue)
        self.pf_avg = np.full(n_ue, 1e6)
        self.age = np.zeros(n_ue)
        self.cum_a = np.zeros(n_ue)
        self.cum_d = np.zeros(n_ue)
        self.slot_clock = 0
        self.interrupt_left_s = np.zeros(n_ue)
        # pending tagged packets: (ue, arrival_time_s, cumA_level)
        self.p_ue = np.empty(0, dtype=int)
        self.p_t = np.empty(0)
        self.p_a = np.empty(0)

    def _metric(self, idx, rate):
        if self.scheduler == "round_robin":
            return self.age[idx]                      # least recently served first
        if self.scheduler == "proportional_fair":
            return rate[idx] / self.pf_avg[idx]       # r / T
        return rate[idx]                              # max throughput

    def run_epoch(self, serving: np.ndarray, n_bs: int, connected: np.ndarray, mcs_rate_bps: np.ndarray,
                  success: np.ndarray, arrival_pkts: np.ndarray, packet_bits: np.ndarray) -> EpochMacResult:
        """serving (N,), connected (N,) bool, mcs_rate_bps (N,) = full-slot rate at the selected MCS
        (already net of overhead), success (S,N) bool, arrival_pkts (S,N) int packet counts."""
        s_n, n = success.shape
        dt = self.dt
        # padded UE lists per gNB
        order = np.argsort(serving, kind="stable")
        counts = np.bincount(serving, minlength=n_bs)
        kmax = max(int(counts.max()), 1)
        idx = np.full((n_bs, kmax), -1, dtype=int)
        start = 0
        for b in range(n_bs):
            c = counts[b]
            idx[b, :c] = order[start:start + c]
            start += c
        valid = idx >= 0
        safe = np.where(valid, idx, 0)
        rows = np.arange(n_bs)

        served = np.zeros(n)
        offered = np.zeros(n)
        dropped = np.zeros(n)
        sched = np.zeros(n)
        failed = np.zeros(n)
        d_series = np.empty((s_n, n))
        a_series = np.empty((s_n, n))

        d_start = self.cum_d.copy()
        arrivals_bits = arrival_pkts * packet_bits[None, :]
        # tag packets (choose slots uniformly among slots with arrivals) per UE
        tag_slots = self._choose_tags(arrival_pkts)

        off_series = np.zeros((s_n, n))
        blocks = np.zeros(n)
        cap_all = mcs_rate_bps * dt
        for s in range(s_n):
            arr = arrivals_bits[s]
            offered += arr
            self.backlog += arr
            over = np.maximum(self.backlog - self.buffer, 0.0)
            dropped += over
            self.backlog -= over
            self.cum_a += arr - over
            a_series[s] = self.cum_a
            self.interrupt_left_s = np.maximum(self.interrupt_left_s - dt, 0.0)

            rem = np.ones(n_bs)                    # remaining fraction of the slot per gNB
            done = np.zeros((n_bs, kmax), dtype=bool)
            inst = np.zeros(n)
            served_any = np.zeros(n, dtype=bool)
            base_ok = valid & connected[safe] & (mcs_rate_bps[safe] > 0)
            for _ in range(kmax):                  # work-conserving: keep serving until the slot is used up
                elig = (base_ok & (self.backlog[safe] > 0) & (self.interrupt_left_s[safe] <= 0) & ~done
                        & (rem > 1e-9)[:, None])
                metric = np.where(elig, self._metric(safe, mcs_rate_bps), -np.inf)
                k = np.argmax(metric, axis=1)
                active = np.isfinite(metric[rows, k])
                if not active.any():
                    break
                b_act = rows[active]
                ue = safe[rows, k][active]
                need = self.backlog[ue] / np.maximum(cap_all[ue], 1e-12)     # slot fraction needed to empty the queue
                use = np.minimum(need, rem[b_act])
                ok = success[s, ue]
                tx = np.where(ok, use * cap_all[ue], 0.0)                     # a failed block wastes its airtime
                off_series[s, ue] = 1.0 - rem[b_act]
                rem[b_act] -= use
                done[b_act, k[active]] = True
                self.backlog[ue] -= tx
                served[ue] += tx
                sched[ue] += use
                blocks[ue] += 1
                failed[ue] += ~ok
                self.cum_d[ue] += tx
                inst[ue] += tx / dt
                served_any[ue] = True
            self.pf_avg = np.maximum((1 - 1 / self.tc) * self.pf_avg + (1 / self.tc) * inst, 1.0)
            self.age += 1
            self.age[served_any] = 0
            d_series[s] = self.cum_d
        # ---- tagged packet delays -------------------------------------------------------------
        base_t = self.slot_clock * dt
        if tag_slots[0].size:
            t_ue, t_slot = tag_slots
            t_arr = base_t + t_slot * dt  # bits become schedulable at the slot boundary
            self.p_ue = np.concatenate([self.p_ue, t_ue])
            self.p_t = np.concatenate([self.p_t, t_arr])
            n_pk = arrival_pkts[t_slot, t_ue]
            k = 1 + np.floor(self.rng.random(t_slot.size) * n_pk)       # uniformly random packet in the batch
            level = a_series[t_slot, t_ue] - (n_pk - k) * packet_bits[t_ue]
            self.p_a = np.concatenate([self.p_a, level])
        delays, delay_ue, delay_sum, delay_cnt, censored = self._resolve(d_series, d_start, mcs_rate_bps, base_t, off_series)
        self.slot_clock += s_n
        return EpochMacResult(served, offered, dropped, sched, failed, self.backlog.copy(),
                              delay_sum, delay_cnt, delays, delay_ue, censored, s_n, {"blocks_tx": blocks})

    def _choose_tags(self, arrival_pkts):
        has = arrival_pkts > 0
        ues, slots = [], []
        for u in range(self.n):
            cand = np.nonzero(has[:, u])[0]
            if cand.size == 0:
                continue
            w = arrival_pkts[cand, u].astype(float)          # packet-weighted so the sample is a random packet
            pick = self.rng.choice(cand, size=min(self.tags, cand.size), replace=False, p=w / w.sum())
            ues.append(np.full(pick.size, u))
            slots.append(pick)
        if not ues:
            return np.empty(0, dtype=int), np.empty(0, dtype=int)
        return np.concatenate(ues), np.concatenate(slots)

    def _resolve(self, d_series, d_start, mcs_rate_bps, base_t, off_series):
        n = self.n
        dsum = np.zeros(n)
        dcnt = np.zeros(n)
        if self.p_ue.size == 0:
            return np.empty(0), np.empty(0, dtype=int), dsum, dcnt, 0
        s_n = d_series.shape[0]
        d_end = d_series[-1, self.p_ue]
        done = self.p_a <= d_end + 1e-9
        out = np.empty(0)
        out_u = np.empty(0, dtype=int)
        if done.any():
            u, a, t_arr = self.p_ue[done], self.p_a[done], self.p_t[done]
            cols = d_series[:, u]                                   # (S, R)
            r = np.arange(u.size)
            first = np.argmax(cols >= a[None, :] - 1e-9, axis=0)    # slot in which the packet's last bit departs
            prev = np.where(first > 0, cols[np.maximum(first - 1, 0), r], d_start[u])
            cap = np.maximum(mcs_rate_bps[u] * self.dt, 1e-12)      # bits the slot can carry
            frac = np.clip((a - prev) / cap, 0.0, 1.0)              # airtime fraction spent on this packet
            t_dep = base_t + (first + off_series[first, u] + frac) * self.dt
            out = np.maximum(t_dep - t_arr, 0.0)
            out_u = u
            np.add.at(dsum, u, out)
            np.add.at(dcnt, u, 1)
        keep = ~done
        cur_t = base_t + s_n * self.dt
        stale = keep & (cur_t - self.p_t > self.horizon)
        censored = int(stale.sum())
        keep &= ~stale
        self.p_ue, self.p_t, self.p_a = self.p_ue[keep], self.p_t[keep], self.p_a[keep]
        return out, out_u, dsum, dcnt, censored
