"""NOT IMPLEMENTED YET - Phase 4/6 - SpectrumManager (allocation, guard bands, sharing). Frequency/bandwidth are currently plain radio config values.

This package is a placeholder in the target layout. Nothing here is simulated or reported.
"""
