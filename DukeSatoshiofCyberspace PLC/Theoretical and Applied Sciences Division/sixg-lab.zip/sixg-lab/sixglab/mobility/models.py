"""Mobility engine. Every group owns a named seeded RNG stream, so trajectories are reproducible.

All models expose ``step(dt)`` and the arrays ``pos`` (N,3) [m] and ``vel`` (N,3) [m/s].
Road-bound models (pedestrian, vehicle, train) move along the environment's road graph.
"""
from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np

from sixglab.radio.environment import RadioEnvironment


class MobilityModel(ABC):
    kind = "abstract"

    def __init__(self, n: int, rng: np.random.Generator) -> None:
        self.n = n
        self.rng = rng
        self.pos = np.zeros((n, 3))
        self.vel = np.zeros((n, 3))

    @abstractmethod
    def step(self, dt: float) -> None: ...


class Static(MobilityModel):
    kind = "static"

    def __init__(self, n, rng, env: RadioEnvironment, height_m: float = 1.5) -> None:
        super().__init__(n, rng)
        x0, y0, x1, y1 = env.extent
        for i in range(n):
            while True:
                p = np.array([rng.uniform(x0, x1), rng.uniform(y0, y1)])
                if not env.is_inside_building(p[None])[0]:
                    break
            self.pos[i] = (*p, height_m)

    def step(self, dt: float) -> None:
        return None


class RandomWalk(MobilityModel):
    """Constant speed, Gaussian heading perturbation, reflection at the map boundary and at buildings."""
    kind = "random_walk"

    def __init__(self, n, rng, env: RadioEnvironment, speed_mps=1.4, height_m=1.5, turn_std_rad=0.4) -> None:
        super().__init__(n, rng)
        self.env, self.speed, self.turn = env, speed_mps, turn_std_rad
        self.pos = Static(n, rng, env, height_m).pos
        self.heading = rng.uniform(0, 2 * np.pi, n)

    def step(self, dt: float) -> None:
        self.heading += self.rng.normal(0.0, self.turn * np.sqrt(dt), self.n)
        step = self.speed * dt * np.column_stack([np.cos(self.heading), np.sin(self.heading)])
        new = self.pos[:, :2] + step
        x0, y0, x1, y1 = self.env.extent
        bad = ((new[:, 0] < x0) | (new[:, 0] > x1) | (new[:, 1] < y0) | (new[:, 1] > y1)
               | self.env.is_inside_building(new, self.pos[0, 2]))
        self.heading[bad] += np.pi  # reflect
        new[bad] = self.pos[bad, :2]
        self.pos[:, :2] = new
        self.vel[:, :2] = step / dt


class RandomWaypoint(MobilityModel):
    kind = "random_waypoint"

    def __init__(self, n, rng, env: RadioEnvironment, speed_mps=(1.0, 3.0), height_m=1.5, pause_s=0.0) -> None:
        super().__init__(n, rng)
        self.env, self.speed_range, self.pause_s = env, speed_mps, pause_s
        self.pos = Static(n, rng, env, height_m).pos
        self.h = height_m
        self.target = self.pos.copy()
        self.speed = np.zeros(n)
        self.pause_left = np.zeros(n)
        for i in range(n):
            self._new_target(i)

    def _new_target(self, i: int) -> None:
        x0, y0, x1, y1 = self.env.extent
        while True:
            p = np.array([self.rng.uniform(x0, x1), self.rng.uniform(y0, y1)])
            if not self.env.is_inside_building(p[None])[0]:
                break
        self.target[i] = (*p, self.h)
        self.speed[i] = self.rng.uniform(*self.speed_range)

    def step(self, dt: float) -> None:
        self.vel[:] = 0.0
        for i in range(self.n):
            if self.pause_left[i] > 0:
                self.pause_left[i] -= dt
                continue
            d = self.target[i] - self.pos[i]
            dist = np.linalg.norm(d)
            travel = self.speed[i] * dt
            if dist <= travel:
                self.pos[i] = self.target[i]
                self.pause_left[i] = self.pause_s
                self._new_target(i)
            else:
                nxt = self.pos[i] + d / dist * travel
                if self.env.is_inside_building(nxt[None, :2], self.h)[0]:   # straight path is blocked: pick a new waypoint
                    self._new_target(i)
                    continue
                self.pos[i] = nxt
                self.vel[i] = d / dist * self.speed[i]


class RoadNetworkMobility(MobilityModel):
    """Agents on the road graph with speed, acceleration, lane offset and a random route.

    Route: at each intersection choose uniformly among neighbours except the one just left (no U-turn
    unless at a dead end). ``route`` may be supplied per agent as a list of node indices instead.
    """
    kind = "road"

    def __init__(self, n, rng, env: RadioEnvironment, speed_mps: float, height_m: float,
                 accel_mps2: float, lane_offset_m: float, speed_jitter: float = 0.15) -> None:
        super().__init__(n, rng)
        self.env, self.roads = env, env.roads
        self.h = height_m
        self.accel = accel_mps2
        self.target_speed = speed_mps * (1 + speed_jitter * rng.uniform(-1, 1, n))
        self.speed = self.target_speed.copy() * 0.0
        self.lane = lane_offset_m * rng.choice([-1.0, 1.0], n)
        nn = self.roads.n_nodes
        self.frm = rng.integers(0, nn, n)
        self.to = np.array([self._next_node(int(f), -1) for f in self.frm])
        self.s = np.zeros(n)
        self.length = np.array([self.roads.edge_length(int(a), int(b)) for a, b in zip(self.frm, self.to, strict=True)])
        self.s = rng.uniform(0, self.length)
        self.route: dict[int, list[int]] = {}
        self._update_pos(dt=1.0)
        self.vel[:] = 0.0

    def set_route(self, agent: int, nodes: list[int]) -> None:
        self.route[agent] = list(nodes)

    def _next_node(self, current: int, previous: int) -> int:
        nb = self.roads.neighbours[current]
        cand = nb[nb != previous] if len(nb) > 1 else nb
        return int(self.rng.choice(cand))

    def _update_pos(self, dt: float) -> None:
        a, b = self.roads.coords[self.frm], self.roads.coords[self.to]
        direction = (b - a) / np.maximum(self.length, 1e-9)[:, None]
        normal = np.column_stack([-direction[:, 1], direction[:, 0]])
        xy = a + direction * self.s[:, None] + normal * self.lane[:, None]
        old = self.pos[:, :2].copy()
        self.pos[:, :2] = xy
        self.pos[:, 2] = self.h
        self.vel[:, :2] = (xy - old) / dt if dt > 0 else 0.0

    def step(self, dt: float) -> None:
        self.speed = np.minimum(self.target_speed, self.speed + self.accel * dt)
        self.s += self.speed * dt
        for i in np.nonzero(self.s >= self.length)[0]:
            over = self.s[i] - self.length[i]
            prev, cur = int(self.frm[i]), int(self.to[i])
            if int(i) in self.route and self.route[int(i)]:
                nxt = self.route[int(i)].pop(0)
            else:
                nxt = self._next_node(cur, prev)
            self.frm[i], self.to[i] = cur, nxt
            self.length[i] = self.roads.edge_length(cur, nxt)
            self.s[i] = min(over, self.length[i])
        self._update_pos(dt)


class Pedestrian(RoadNetworkMobility):
    kind = "pedestrian"

    def __init__(self, n, rng, env, speed_mps=1.4, height_m=1.5) -> None:
        super().__init__(n, rng, env, speed_mps, height_m, accel_mps2=1.0, lane_offset_m=8.0, speed_jitter=0.2)


class VehicleMobility(RoadNetworkMobility):
    kind = "vehicle"

    def __init__(self, n, rng, env, speed_mps=13.9, height_m=1.5, accel_mps2=2.5) -> None:
        super().__init__(n, rng, env, speed_mps, height_m, accel_mps2, lane_offset_m=3.0, speed_jitter=0.2)


class Train(MobilityModel):
    """Constant-speed motion back and forth along a straight track across the map at mid-height."""
    kind = "train"

    def __init__(self, n, rng, env: RadioEnvironment, speed_mps=40.0, height_m=3.0) -> None:
        super().__init__(n, rng)
        x0, y0, x1, y1 = env.extent
        self.x0, self.x1, self.speed, self.h = x0, x1, speed_mps, height_m
        self.track_y = 0.5 * (y0 + y1) + 0.0
        self.dir = np.ones(n)
        self.pos[:, 0] = rng.uniform(x0, x1, n)
        self.pos[:, 1] = self.track_y
        self.pos[:, 2] = height_m

    def step(self, dt: float) -> None:
        self.pos[:, 0] += self.dir * self.speed * dt
        hi, lo = self.pos[:, 0] > self.x1, self.pos[:, 0] < self.x0
        self.pos[hi, 0] = 2 * self.x1 - self.pos[hi, 0]
        self.pos[lo, 0] = 2 * self.x0 - self.pos[lo, 0]
        self.dir[hi], self.dir[lo] = -1.0, 1.0
        self.vel[:] = 0.0
        self.vel[:, 0] = self.dir * self.speed


class UAV(MobilityModel):
    """3-D random waypoint at a fixed cruise altitude."""
    kind = "uav"

    def __init__(self, n, rng, env: RadioEnvironment, speed_mps=10.0, height_m=60.0) -> None:
        super().__init__(n, rng)
        x0, y0, x1, y1 = env.extent
        self.bounds, self.speed, self.h = (x0, y0, x1, y1), speed_mps, height_m
        self.pos = np.column_stack([rng.uniform(x0, x1, n), rng.uniform(y0, y1, n), np.full(n, height_m)])
        self.target = self.pos.copy()
        for i in range(n):
            self._retarget(i)

    def _retarget(self, i: int) -> None:
        x0, y0, x1, y1 = self.bounds
        self.target[i] = (self.rng.uniform(x0, x1), self.rng.uniform(y0, y1), self.h)

    def step(self, dt: float) -> None:
        d = self.target - self.pos
        dist = np.linalg.norm(d, axis=1)
        arrived = dist <= self.speed * dt
        for i in np.nonzero(arrived)[0]:
            self.pos[i] = self.target[i]
            self._retarget(int(i))
        mv = ~arrived
        self.vel[:] = 0.0
        self.vel[mv] = d[mv] / dist[mv, None] * self.speed
        self.pos[mv] += self.vel[mv] * dt


def build_model(kind: str, n: int, rng: np.random.Generator, env: RadioEnvironment,
                speed_mps: float | None = None, height_m: float | None = None) -> MobilityModel:
    h = height_m if height_m is not None else 1.5
    if kind == "static":
        return Static(n, rng, env, h)
    if kind == "random_walk":
        return RandomWalk(n, rng, env, speed_mps or 1.4, h)
    if kind == "random_waypoint":
        s = speed_mps or 2.0
        return RandomWaypoint(n, rng, env, (0.5 * s, 1.5 * s), h)
    if kind == "pedestrian":
        return Pedestrian(n, rng, env, speed_mps or 1.4, h)
    if kind == "vehicle":
        return VehicleMobility(n, rng, env, speed_mps or 13.9, h)
    if kind == "train":
        return Train(n, rng, env, speed_mps or 40.0, height_m or 3.0)
    if kind == "uav":
        return UAV(n, rng, env, speed_mps or 10.0, height_m or 60.0)
    raise ValueError(f"unknown mobility kind {kind!r}")
