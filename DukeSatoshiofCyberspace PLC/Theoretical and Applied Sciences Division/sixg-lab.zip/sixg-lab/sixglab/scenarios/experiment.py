"""Experiment manager, parameter sweeps and Monte Carlo runner. Every result carries full provenance."""
from __future__ import annotations

import copy
import itertools
import json
import time
import uuid
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml
from scipy import stats

from sixglab.config.loader import _deep_merge, load_scenario, scenario_from_dict
from sixglab.config.models import ScenarioConfig
from sixglab.core.errors import ConfigurationError
from sixglab.core.provenance import collect_provenance, config_hash
from sixglab.network.simulation import Simulation
from sixglab.telemetry.recorder import to_jsonable

METRICS = ("mean_sinr_db", "coverage_fraction", "mean_throughput_bps", "latency_p95_ms", "serving_distance_p90_m",
           "energy_wh", "j_per_bit", "wh_per_gb", "packet_loss_ratio", "jain_fairness")


def set_dotted(doc: dict, key: str, value: Any) -> None:
    parts = key.split(".")
    d = doc
    for p in parts[:-1]:
        d = d.setdefault(p, {})
    d[parts[-1]] = value


def apply_parameter(doc: dict, key: str, value: Any) -> None:
    """Sweep keys are dotted config paths, plus two conveniences: ``ue_count`` (rescales all populations) and
    ``antenna_count`` (square array with that many elements)."""
    if key == "ue_count":
        pops = doc.setdefault("network", {}).get("populations")
        if not pops:
            raise ConfigurationError("ue_count sweep needs network.populations in the scenario")
        total = sum(p["count"] for p in pops)
        for p in pops:
            p["count"] = max(0, int(round(p["count"] * value / total)))
    elif key == "antenna_count":
        side = int(round(np.sqrt(value)))
        if side * side != value:
            raise ConfigurationError("antenna_count must be a perfect square (square URA)")
        set_dotted(doc, "radio.antenna.rows", side)
        set_dotted(doc, "radio.antenna.columns", side)
    else:
        set_dotted(doc, key, value)


def run_one(doc: dict) -> dict[str, Any]:
    cfg = scenario_from_dict(doc)
    sim = Simulation(cfg)
    return sim.run()


def _worker(args):
    return run_one(args)


def _map(docs: list[dict], workers: int) -> list[dict]:
    if workers <= 1 or len(docs) == 1:
        return [run_one(d) for d in docs]
    with ProcessPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(_worker, docs))


@dataclass
class Experiment:
    name: str
    scenario: dict[str, Any]
    sweep: dict[str, list[Any]] = field(default_factory=dict)
    replicates: int = 1
    experiment_id: str = field(default_factory=lambda: uuid.uuid4().hex[:10])
    timestamp: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    results: pd.DataFrame | None = None

    @classmethod
    def from_yaml(cls, path: str | Path) -> Experiment:
        p = Path(path)
        spec = yaml.safe_load(p.read_text())
        base = spec.get("scenario")
        if isinstance(base, str):
            sc = p.parent / base
            if not sc.exists():
                sc = Path(base)
            base = load_scenario(sc).model_dump(mode="json")
        base = _deep_merge(base or {}, spec.get("overrides", {}))
        return cls(spec.get("name", p.stem), base, spec.get("sweep", {}), int(spec.get("replicates", 1)))

    def run(self, workers: int = 1, progress=None) -> pd.DataFrame:
        keys = list(self.sweep)
        combos = list(itertools.product(*[self.sweep[k] for k in keys])) if keys else [()]
        docs, meta = [], []
        seed0 = self.scenario.get("simulation", {}).get("seed", 42)
        for combo in combos:
            for r in range(self.replicates):
                d = copy.deepcopy(self.scenario)
                for k, v in zip(keys, combo, strict=True):
                    apply_parameter(d, k, v)
                set_dotted(d, "simulation.seed", int(seed0) + r)
                d["name"] = f"{self.name}"
                docs.append(d)
                meta.append({**dict(zip(keys, combo, strict=True)), "replicate": r})
        t0 = time.time()
        sums = _map(docs, workers)
        rows = []
        for m, s, d in zip(meta, sums, docs, strict=True):
            row = {**m, "seed": s["seed"], "config_hash": s["provenance"]["config_hash"], "wall_time_s": s["wall_time_s"]}
            for k in METRICS:
                row[k] = s.get(k, float("nan"))
            rows.append(row)
        self.results = pd.DataFrame(rows)
        self.elapsed_s = time.time() - t0
        return self.results

    def save(self, out_dir: str | Path) -> Path:
        out = Path(out_dir) / self.experiment_id
        out.mkdir(parents=True, exist_ok=True)
        assert self.results is not None
        self.results.to_parquet(out / "results.parquet", index=False)
        meta = {"experiment_id": self.experiment_id, "name": self.name, "timestamp": self.timestamp,
                "sweep": self.sweep, "replicates": self.replicates,
                "provenance": collect_provenance(config_hash(self.scenario), int(self.scenario.get("simulation", {}).get("seed", 42))),
                "scenario": self.scenario}
        (out / "experiment.json").write_text(json.dumps(to_jsonable(meta), indent=2))
        (out / "results.json").write_text(json.dumps(to_jsonable(self.results.to_dict(orient="records")), indent=2))
        return out


def confidence_interval(x: np.ndarray, level: float = 0.95) -> tuple[float, float, float]:
    """(mean, lo, hi) Student-t interval."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if x.size < 2:
        return (float(x.mean()) if x.size else float("nan"),) * 3
    h = stats.sem(x) * stats.t.ppf((1 + level) / 2, x.size - 1)
    return float(x.mean()), float(x.mean() - h), float(x.mean() + h)


class MonteCarloRunner:
    """Independent replicates (different seeds) of one scenario; reports mean and 95% CI for each metric."""

    def __init__(self, cfg: ScenarioConfig, n_runs: int, workers: int = 1) -> None:
        self.cfg, self.n_runs, self.workers = cfg, n_runs, workers

    def run(self) -> dict[str, Any]:
        base = self.cfg.model_dump(mode="json")
        docs = []
        for r in range(self.n_runs):
            d = copy.deepcopy(base)
            d["simulation"]["seed"] = self.cfg.simulation.seed + r
            docs.append(d)
        sums = _map(docs, self.workers)
        out: dict[str, Any] = {"n_runs": self.n_runs, "seeds": [s["seed"] for s in sums], "metrics": {}}
        for k in METRICS:
            m, lo, hi = confidence_interval(np.array([s.get(k, np.nan) for s in sums]))
            out["metrics"][k] = {"mean": m, "ci95_low": lo, "ci95_high": hi}
        return out
