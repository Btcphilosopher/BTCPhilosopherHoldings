"""Performance benchmarks (spec 87). Reports wall time per operation; profile before adding Numba/JAX."""
from __future__ import annotations

import time
from collections.abc import Callable

import numpy as np

from sixglab.beamforming.precoders import mmse, mrt, zf
from sixglab.channel.spatial import SpatialChannel
from sixglab.config import AntennaConfig, EnvironmentConfig, scenario_from_dict
from sixglab.core.rng import RngFactory
from sixglab.mobility import build_model
from sixglab.network.scheduler import SlotMAC
from sixglab.network.simulation import Simulation
from sixglab.radio.environment import RadioEnvironment
from sixglab.scenarios.experiment import MonteCarloRunner


def _time(fn: Callable[[], object], repeat: int = 5) -> float:
    fn()
    t0 = time.perf_counter()
    for _ in range(repeat):
        fn()
    return (time.perf_counter() - t0) / repeat


def run_benchmarks() -> dict[str, float]:
    rf = RngFactory(1)
    env = RadioEnvironment.generate_city(EnvironmentConfig(), rf.stream("e"))
    bs = env.place_base_stations(12, 10.0)
    ue = np.column_stack([np.random.default_rng(0).uniform(0, 500, (500, 2)), np.full(500, 1.5)])
    ac = AntennaConfig(mode="array")
    sc = SpatialChannel(ac, 140e9)
    los = env.los(bs, ue)
    rng = np.random.default_rng(0)
    H = (rng.standard_normal((16, 256)) + 1j * rng.standard_normal((16, 256))) / np.sqrt(2)
    veh = build_model("vehicle", 500, rf.stream("v"), env)
    n, s = 500, 100
    mac = SlotMAC(n, "proportional_fair", 1e-3, 100, 1e9, np.random.default_rng(0))
    serving = np.arange(n) % 12
    args = (serving, 12, np.ones(n, bool), np.full(n, 1e9), np.ones((s, n), bool), np.random.default_rng(0).poisson(0.5, (s, n)), np.full(n, 1e4))
    res = {
        "los_12x500_s": _time(lambda: env.los(bs, ue)),
        "spatial_channel_12x500x64_s": _time(lambda: sc.generate(bs, ue, los, np.random.default_rng(0)), 3),
        "mimo_matmul_256x16_s": _time(lambda: H @ H.conj().T, 200),
        "beamforming_mrt_s": _time(lambda: mrt(H)), "beamforming_zf_s": _time(lambda: zf(H)),
        "beamforming_mmse_s": _time(lambda: mmse(H, 1e-3)),
        "mac_epoch_500ue_100slots_s": _time(lambda: mac.run_epoch(*args), 3),
        "mobility_500vehicles_step_s": _time(lambda: veh.step(0.1), 100),
    }
    cfg = scenario_from_dict({"simulation": {"duration_s": 0.3}, "network": {"populations": [{"kind": "pedestrian", "count": 30}]}})
    res["simulation_epoch_30ue_s"] = _time(lambda: Simulation(cfg).step_epoch(), 2)
    res["monte_carlo_3runs_s"] = _time(lambda: MonteCarloRunner(cfg, 3).run(), 1)
    return res
