"""Energy model (EARTH-style, simplified and explicit):

    P_bs = (P_static + N_chains * P_chain + P_tx * activity / eta_PA) * (1 + cooling)

``activity`` is the measured fraction of slots the gNB transmits. Edge power is linear in utilisation.
Energy is the integral of power over simulated time. Parameters are scenario inputs, not measurements.
"""
from __future__ import annotations

import numpy as np

from sixglab.config.models import EnergyConfig


def base_station_power_w(cfg: EnergyConfig, n_chains: int, tx_power_w: float, activity) -> np.ndarray:
    a = np.clip(np.asarray(activity, dtype=float), 0.0, 1.0)
    return (cfg.bs_static_w + n_chains * cfg.bs_chain_w + tx_power_w * a / cfg.pa_efficiency) * (1 + cfg.cooling_overhead)


def joule_per_bit(energy_j: float, bits: float) -> float:
    return float(energy_j / bits) if bits > 0 else float("nan")


def wh_per_gb(energy_j: float, bits: float) -> float:
    return float((energy_j / 3600.0) / (bits / 8e9)) if bits > 0 else float("nan")
