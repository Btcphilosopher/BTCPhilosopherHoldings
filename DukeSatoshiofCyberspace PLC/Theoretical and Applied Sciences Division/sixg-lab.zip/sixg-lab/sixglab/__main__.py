import sys

from sixglab.cli import main

sys.exit(main())
