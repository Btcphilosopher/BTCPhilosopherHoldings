"""SimulationManager: owns Simulation objects and their background runner threads."""
from __future__ import annotations

import os
import threading
import time
import uuid
from collections import deque
from pathlib import Path
from typing import Any

import yaml

from sixglab.config.loader import load_scenario
from sixglab.config.models import ScenarioConfig
from sixglab.core.errors import ConfigurationError
from sixglab.network.simulation import Simulation
from sixglab.storage.runs import save_run

_DEFAULT_MODES = ("real_time", "accelerated", "step", "batch")


def scenarios_dir() -> Path:
    env = os.environ.get("SIXG_SCENARIOS")
    if env:
        return Path(env)
    for base in (Path.cwd(), Path(__file__).resolve().parents[2]):
        if (base / "scenarios").is_dir():
            return base / "scenarios"
    return Path("scenarios")


def list_scenarios() -> list[dict[str, Any]]:
    out = []
    for f in sorted(scenarios_dir().glob("*.yaml")):
        try:
            doc = yaml.safe_load(f.read_text()) or {}
            out.append({"id": f.stem, "file": f.name, "name": doc.get("name", f.stem), "description": doc.get("description", "")})
        except yaml.YAMLError:
            continue
    return out


def resolve_scenario(name: str) -> Path:
    """Scenario ids map to files inside the scenarios directory only (no arbitrary filesystem paths)."""
    stem = Path(name).stem
    p = scenarios_dir() / f"{stem}.yaml"
    if not p.is_file():
        raise ConfigurationError(f"unknown scenario {name!r}; available: {[s['id'] for s in list_scenarios()]}")
    return p


class Runner:
    def __init__(self, sim: Simulation, mode: str, speed: float, save: bool, root: str) -> None:
        self.sim, self.mode, self.speed, self.save, self.root = sim, mode, speed, save, root
        self.frames: deque[tuple[int, dict]] = deque(maxlen=3000)
        self.counter = 0
        self.lock = threading.RLock()
        self.status = "created"
        self.error: str | None = None
        self._stop = threading.Event()
        self._run = threading.Event()
        self.thread: threading.Thread | None = None
        self.summary: dict[str, Any] | None = None
        self.saved_to: str | None = None

    def start(self) -> None:
        if self.status == "completed" or self.status == "stopped":
            raise ConfigurationError(f"simulation is {self.status}")
        self._run.set()
        if self.thread is None:
            self.status = "running"
            self.thread = threading.Thread(target=self._loop, daemon=True, name=f"sim-{self.sim.simulation_id}")
            self.thread.start()
        else:
            self.status = "running"

    def pause(self) -> None:
        self._run.clear()
        if self.status == "running":
            self.status = "paused"

    def stop(self) -> None:
        self._stop.set()
        self._run.set()
        if self.thread is None:
            self.status = "stopped"

    def step(self) -> None:
        """STEP mode: advance exactly one epoch."""
        if self.status in ("completed", "stopped"):
            raise ConfigurationError(f"simulation is {self.status}")
        with self.lock:
            self._advance()
        if self.sim.epoch >= self.sim.cfg.simulation.n_epochs:
            self._finish()
        elif self.status == "created":
            self.status = "paused"

    def _advance(self) -> None:
        self.sim.step_epoch()
        self.counter += 1
        self.frames.append((self.counter, self.sim.frame()))

    def _finish(self) -> None:
        with self.lock:
            self.summary = self.sim.summary()
            if self.save:
                self.saved_to = str(save_run(self.sim, self.summary, self.root))
        self.status = "completed"

    def _loop(self) -> None:
        n = self.sim.cfg.simulation.n_epochs
        epoch_s = self.sim.cfg.simulation.update_interval_s
        try:
            while self.sim.epoch < n and not self._stop.is_set():
                if not self._run.wait(0.1):
                    continue
                if self._stop.is_set():
                    break
                t0 = time.perf_counter()
                with self.lock:
                    self._advance()
                if self.mode in ("real_time", "accelerated"):
                    target = epoch_s / (1.0 if self.mode == "real_time" else self.speed)
                    delay = target - (time.perf_counter() - t0)
                    if delay > 0:
                        time.sleep(delay)
            if self._stop.is_set() and self.sim.epoch < n:
                self.status = "stopped"
            else:
                self._finish()
        except Exception as exc:  # surface numerical/config errors to the client instead of dying silently
            self.error = f"{type(exc).__name__}: {exc}"
            self.status = "failed"
            self.sim.log.error("runner_failed", error=self.error)


class SimulationManager:
    def __init__(self, runs_root: str = "data/runs") -> None:
        self.runs: dict[str, Runner] = {}
        self.order: list[str] = []
        self.runs_root = runs_root

    def create(self, scenario: str | None, overrides: dict[str, Any] | None, mode: str = "accelerated",
               speed_factor: float = 1.0, save: bool = True) -> Runner:
        if mode not in _DEFAULT_MODES:
            raise ConfigurationError(f"mode must be one of {_DEFAULT_MODES}")
        sc = resolve_scenario(scenario or "urban_140ghz_fixed_gain")
        cfg: ScenarioConfig = load_scenario(sc, overrides=overrides)
        sim = Simulation(cfg, simulation_id=uuid.uuid4().hex[:12])
        r = Runner(sim, mode, speed_factor, save, self.runs_root)
        self.runs[sim.simulation_id] = r
        self.order.append(sim.simulation_id)
        return r

    def get(self, sim_id: str | None) -> Runner:
        if sim_id is None:
            if not self.order:
                raise KeyError("no simulations exist yet; POST /api/simulations first")
            sim_id = self.order[-1]
        if sim_id not in self.runs:
            raise KeyError(f"simulation {sim_id!r} not found")
        return self.runs[sim_id]

    def describe(self, r: Runner) -> dict[str, Any]:
        sim = r.sim
        return {"id": sim.simulation_id, "status": r.status, "scenario": sim.cfg.name, "mode": r.mode,
                "epoch": sim.epoch, "n_epochs": sim.cfg.simulation.n_epochs, "time_s": sim.clock.time_s,
                "duration_s": sim.cfg.simulation.duration_s, "seed": sim.cfg.simulation.seed,
                "config_hash": sim.cfg_hash, "error": r.error, "saved_to": r.saved_to,
                "summary": r.summary}
