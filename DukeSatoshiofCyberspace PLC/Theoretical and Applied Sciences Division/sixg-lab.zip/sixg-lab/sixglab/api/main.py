"""FastAPI application: REST + WebSocket for the 6G DIGITAL TWIN LAB.  uvicorn sixglab.api.main:app --reload"""
from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Any

import numpy as np
from fastapi import FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field

from sixglab import SUBTITLE, TITLE, __version__
from sixglab.api.manager import SimulationManager, list_scenarios
from sixglab.core.errors import SixGError
from sixglab.telemetry.recorder import to_jsonable

app = FastAPI(title=TITLE, description=SUBTITLE, version=__version__)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
manager = SimulationManager(os.environ.get("SIXG_RUNS", "data/runs"))


class CreateSimulation(BaseModel):
    model_config = ConfigDict(extra="forbid")
    scenario: str | None = Field(None, description="scenario id (file stem in scenarios/)")
    overrides: dict[str, Any] = Field(default_factory=dict)
    mode: str = "accelerated"
    speed_factor: float = Field(1.0, gt=0)
    save: bool = True
    autostart: bool = False


@app.exception_handler(SixGError)
async def _sixg_error(_, exc: SixGError):
    return JSONResponse(status_code=422, content={"error": type(exc).__name__, "detail": str(exc)})


def _runner(sim_id: str | None):
    try:
        return manager.get(sim_id)
    except KeyError as exc:
        raise HTTPException(404, str(exc.args[0])) from exc


@app.get("/api/health")
def health():
    return {"title": TITLE, "subtitle": SUBTITLE, "version": __version__, "simulations": len(manager.runs)}


@app.get("/api/scenarios")
def scenarios():
    return list_scenarios()


@app.post("/api/simulations", status_code=201)
def create_simulation(body: CreateSimulation):
    r = manager.create(body.scenario, body.overrides, body.mode, body.speed_factor, body.save)
    if body.autostart:
        r.start()
    return manager.describe(r)


@app.get("/api/simulations")
def list_simulations():
    return [manager.describe(manager.runs[i]) for i in manager.order]


@app.get("/api/simulations/{sim_id}")
def get_simulation(sim_id: str):
    return to_jsonable(manager.describe(_runner(sim_id)))


@app.post("/api/simulations/{sim_id}/start")
def start(sim_id: str):
    r = _runner(sim_id)
    r.start()
    return manager.describe(r)


@app.post("/api/simulations/{sim_id}/pause")
def pause(sim_id: str):
    r = _runner(sim_id)
    r.pause()
    return manager.describe(r)


@app.post("/api/simulations/{sim_id}/stop")
def stop(sim_id: str):
    r = _runner(sim_id)
    r.stop()
    return manager.describe(r)


@app.post("/api/simulations/{sim_id}/step")
def step(sim_id: str):
    r = _runner(sim_id)
    r.step()
    return manager.describe(r)


@app.get("/api/network")
def network(simulation_id: str | None = None):
    r = _runner(simulation_id)
    snap = r.sim.static_snapshot()
    g = r.sim.topology.g
    snap["topology"] = {"nodes": [{"id": n, "kind": d["kind"], "pos": d["pos"]} for n, d in g.nodes(data=True)],
                        "links": [{"a": a, "b": b, "medium": d["medium"], "latency_us": d["latency_s"] * 1e6}
                                  for a, b, d in g.edges(data=True)]}
    snap["bs_edge"] = r.sim.bs_edge.tolist()
    snap["bs_transport_ms"] = (r.sim.bs_transport_s * 1e3).tolist()
    return to_jsonable(snap)


@app.get("/api/radio")
def radio(simulation_id: str | None = None):
    r = _runner(simulation_id)
    sim = r.sim
    la = sim.la
    return to_jsonable({
        "config": sim.cfg.radio.model_dump(mode="json"),
        "path_loss_model": sim.pathloss.model_id,
        "validity_note": sim.pathloss.validity_note(sim.cfg.radio.carrier_frequency_hz),
        "noise_power_dbm": float(10 * np.log10(sim.noise_w * 1e3)),
        "fading_margin_db": sim.fading_margin_db,
        "link_adaptation": {"gap_db": la.gap_db, "cqi_thresholds_db": la.thresholds_db,
                            "efficiency_bps_hz": la.efficiency[1:], "code_rate": la.code_rate[1:], "qm": la.qm[1:],
                            "model": "gap-to-Shannon abstraction (research approximation); TS 38.214 CQI efficiencies"},
        "provenance": sim.provenance})


@app.get("/api/ues")
def ues(simulation_id: str | None = None):
    r = _runner(simulation_id)
    with r.lock:
        sim = r.sim
        st = sim.state
        if st.serving is None:
            return []
        lat = st.latency["total_ms"]
        return to_jsonable([{"ue": i, "kind": sim.ue_kind[i], "application": sim.apps[i].name,
                             "pos": sim.ue_pos[i].tolist(), "serving_cell": int(st.serving[i]),
                             "sinr_db": float(st.sinr_db[i]), "cqi": int(st.cqi[i]),
                             "throughput_bps": float(st.throughput_bps[i]), "latency_ms": float(lat[i])}
                            for i in range(sim.n_ue)])


@app.get("/api/ues/{ue}/trace")
def ue_trace(ue: int, simulation_id: str | None = None):
    r = _runner(simulation_id)
    with r.lock:
        if not 0 <= ue < r.sim.n_ue:
            raise HTTPException(404, f"ue {ue} out of range 0..{r.sim.n_ue - 1}")
        return to_jsonable(r.sim.trace_ue(ue))


@app.get("/api/channels")
def channels(ue: int = 0, simulation_id: str | None = None):
    """Research mode: per-gNB channel state for one UE (path loss components, LoS, RSRP) and, in array mode,
    the beamforming weights' azimuth pattern."""
    r = _runner(simulation_id)
    with r.lock:
        sim, st = r.sim, r.sim.state
        if st.serving is None:
            raise HTTPException(409, "no epoch simulated yet")
        cells = [{"cell": b, "distance_m": float(st.d3d[b, ue]), "los": bool(st.los[b, ue]),
                  "path_loss_db": float(st.pl_db[b, ue]), "shadowing_db": float(st.shadow_db[b, ue]),
                  "rsrp_dbm": float(st.rsrp_dbm[b, ue]),
                  "components_db": {k: float(v[b, ue]) for k, v in st.pl_components.items()}} for b in range(sim.n_bs)]
        out: dict[str, Any] = {"ue": ue, "serving_cell": int(st.serving[ue]), "path_loss_model": sim.pl_model_id, "cells": cells}
        if sim.array_mode and st.weights is not None:
            arr = sim.spatial.arrays[0]
            az = np.deg2rad(np.linspace(-90, 90, 181))
            el = np.deg2rad(-5.0)
            u = np.column_stack([np.cos(el) * np.cos(az), np.cos(el) * np.sin(az), np.full(az.size, np.sin(el))])
            out["beam_pattern"] = {"azimuth_deg": np.rad2deg(az), "gain_dbi": arr.pattern_gain_db(st.weights[ue], u),
                                   "elevation_deg": -5.0, "panel": int(st.beam_panel[ue]), "beam_index": int(st.beam_idx[ue]),
                                   "weights_abs": np.abs(st.weights[ue]), "weights_phase_rad": np.angle(st.weights[ue])}
        return to_jsonable(out)


@app.get("/api/telemetry")
def telemetry(simulation_id: str | None = None, last: int = Query(600, ge=1, le=100000)):
    r = _runner(simulation_id)
    with r.lock:
        return to_jsonable(r.sim.telemetry.metrics[-last:])


@app.get("/api/events")
def events(simulation_id: str | None = None, n: int = Query(100, ge=1, le=5000)):
    r = _runner(simulation_id)
    return to_jsonable([e.to_dict() for e in r.sim.events.recent(n)])


@app.get("/api/coverage")
def coverage(simulation_id: str | None = None, resolution_m: float = Query(10.0, ge=2.0, le=100.0)):
    r = _runner(simulation_id)
    with r.lock:
        return r.sim.coverage_map(resolution_m)


@app.websocket("/ws/simulation/{sim_id}")
async def ws_simulation(ws: WebSocket, sim_id: str, all_frames: bool = False):
    await ws.accept()
    try:
        r = manager.get(sim_id)
    except KeyError as exc:
        await ws.send_json({"type": "error", "detail": str(exc.args[0])})
        await ws.close()
        return
    await ws.send_json({"type": "static", **to_jsonable(r.sim.static_snapshot())})
    cursor = 0
    try:
        while True:
            pending = [(i, f) for i, f in list(r.frames) if i > cursor]
            if pending:
                if not all_frames and len(pending) > 3:
                    pending = pending[-1:]
                for i, f in pending:
                    await ws.send_json({"type": "frame", "index": i, **f})
                    cursor = i
            elif r.status in ("completed", "stopped", "failed"):
                await ws.send_json({"type": "status", **to_jsonable(manager.describe(r))})
                break
            else:
                await asyncio.sleep(0.05)
            await asyncio.sleep(0.02)
    except WebSocketDisconnect:
        return
    await ws.close()


_FRONTEND = Path(os.environ.get("SIXG_FRONTEND", Path(__file__).resolve().parents[2] / "frontend" / "dist"))
if _FRONTEND.is_dir():
    app.mount("/assets", StaticFiles(directory=_FRONTEND / "assets"), name="assets") if (_FRONTEND / "assets").is_dir() else None

    @app.get("/", include_in_schema=False)
    def index():
        return FileResponse(_FRONTEND / "index.html")
else:
    @app.get("/", include_in_schema=False)
    def index_missing():
        return {"title": TITLE, "subtitle": SUBTITLE, "docs": "/docs",
                "frontend": "not built - run `make frontend` (cd frontend && npm install && npm run build)"}
