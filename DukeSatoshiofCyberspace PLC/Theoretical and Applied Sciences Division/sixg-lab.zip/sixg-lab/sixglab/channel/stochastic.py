"""StochasticChannel: small-scale fading power gains (unit mean) - Rayleigh, Rician, Nakagami-m,
optionally time-varying via a Jakes-correlated AR(1) process (rho = J0(2 pi f_d T))."""
from __future__ import annotations

import numpy as np
from scipy import stats
from scipy.special import j0

from sixglab.core.errors import ConfigurationError
from sixglab.core.units import C_LIGHT, lin_to_db


class StochasticChannel:
    def __init__(self, kind: str = "rayleigh", rician_k_db: float = 9.0, nakagami_m: float = 2.0) -> None:
        if kind not in ("none", "rayleigh", "rician", "nakagami"):
            raise ConfigurationError(f"unknown fading kind {kind!r}")
        self.kind = kind
        self.k = float(10 ** (rician_k_db / 10.0))
        self.m = nakagami_m

    def distribution(self):
        """Frozen scipy distribution of the unit-mean power gain (None for 'none')."""
        if self.kind == "rayleigh":
            return stats.expon()
        if self.kind == "rician":
            return stats.ncx2(df=2, nc=2 * self.k, scale=1.0 / (2 * (self.k + 1)))
        if self.kind == "nakagami":
            return stats.gamma(a=self.m, scale=1.0 / self.m)
        return None

    def quantile_db(self, p: float) -> float:
        """Fading gain (dB) exceeded with probability 1-p: the p-quantile of the power gain."""
        d = self.distribution()
        return 0.0 if d is None else float(lin_to_db(d.ppf(p)))

    def sample_power(self, rng: np.random.Generator, shape) -> np.ndarray:
        d = self.distribution()
        if d is None:
            return np.ones(shape)
        if self.kind == "rayleigh":
            return rng.exponential(1.0, shape)
        if self.kind == "nakagami":
            return rng.gamma(self.m, 1.0 / self.m, shape)
        g = (rng.standard_normal(shape) + 1j * rng.standard_normal(shape)) / np.sqrt(2.0)
        los = np.sqrt(self.k / (self.k + 1.0))
        return np.abs(los + g / np.sqrt(self.k + 1.0)) ** 2

    def sample_series(self, rng: np.random.Generator, n_slots: int, n_links: int,
                      doppler_hz: np.ndarray, slot_s: float) -> np.ndarray:
        """(n_slots, n_links) time-correlated power gains. Nakagami is i.i.d. per slot (documented)."""
        if self.kind == "none":
            return np.ones((n_slots, n_links))
        if self.kind == "nakagami":
            return self.sample_power(rng, (n_slots, n_links))
        rho = j0(2 * np.pi * np.asarray(doppler_hz) * slot_s)
        w = (rng.standard_normal((n_slots, n_links)) + 1j * rng.standard_normal((n_slots, n_links))) / np.sqrt(2)
        g = np.empty((n_slots, n_links), dtype=complex)
        g[0] = w[0]
        s = np.sqrt(np.maximum(1 - rho**2, 0.0))
        for t in range(1, n_slots):
            g[t] = rho * g[t - 1] + s * w[t]
        if self.kind == "rayleigh":
            return np.abs(g) ** 2
        los = np.sqrt(self.k / (self.k + 1.0))
        return np.abs(los + g / np.sqrt(self.k + 1.0)) ** 2


def doppler_hz(speed_mps, carrier_hz: float) -> np.ndarray:
    """Maximum Doppler shift f_d = v f / c (worst-case, radial motion)."""
    return np.asarray(speed_mps, dtype=float) * carrier_hz / C_LIGHT
