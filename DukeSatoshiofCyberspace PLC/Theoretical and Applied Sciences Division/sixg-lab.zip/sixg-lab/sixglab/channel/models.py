"""Path-loss model registry: config name -> model instance."""
from __future__ import annotations

from sixglab.channel.thz import THzChannelModel
from sixglab.config.models import RadioConfig
from sixglab.core.errors import ConfigurationError
from sixglab.radio.pathloss import (
    FreeSpace,
    Indoor,
    LogDistance,
    PathLossModel,
    Rural,
    UrbanMacro,
    UrbanMicro,
)


def build_path_loss_model(radio: RadioConfig) -> PathLossModel:
    name = radio.path_loss_model
    if name == "free_space":
        return FreeSpace()
    if name == "log_distance":
        return LogDistance(radio.log_distance_exponent)
    if name == "urban_macro":
        return UrbanMacro()
    if name == "urban_micro":
        return UrbanMicro()
    if name == "indoor":
        return Indoor()
    if name == "rural":
        return Rural()
    if name == "thz":
        return THzChannelModel(radio.water_vapour_density_g_m3, radio.rain_rate_mm_h)
    raise ConfigurationError(f"unknown path loss model {name!r}")
