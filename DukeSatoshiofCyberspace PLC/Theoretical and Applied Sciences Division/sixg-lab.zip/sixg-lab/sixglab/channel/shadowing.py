"""Spatially correlated log-normal shadowing: Gudmundson AR(1) in travelled distance.

    z_k = rho * z_{k-1} + sqrt(1 - rho^2) * eps,    rho = exp(-delta_d / d_corr)
"""
from __future__ import annotations

import numpy as np


class ShadowingProcess:
    def __init__(self, n_bs: int, n_ue: int, decorrelation_m: float, rng: np.random.Generator) -> None:
        self.rng, self.dcorr = rng, decorrelation_m
        self.z = rng.standard_normal((n_bs, n_ue))

    def update(self, ue_displacement_m: np.ndarray) -> np.ndarray:
        rho = np.exp(-np.asarray(ue_displacement_m) / self.dcorr)[None, :]
        eps = self.rng.standard_normal(self.z.shape)
        self.z = rho * self.z + np.sqrt(1.0 - rho**2) * eps
        return self.z
