"""THzChannelModel: Reduced-Order THz Propagation Model.

    PL(d, f) = PL_UMi(d, f, LoS/NLoS)  +  A_mol(d, f)

* PL_UMi: 3GPP TR 38.901 UMi street-canyon formulas, EXTRAPOLATED above 100 GHz; LoS/NLoS state
  comes from the geometric height-map ray test in RadioEnvironment.
* A_mol: reduced-order molecular absorption (see sixglab.radio.atmosphere).

NOT implemented (and therefore not claimed): full electromagnetic ray tracing, diffuse scattering,
surface-roughness reflection, rain/fog/foliage. Requesting rain > 0 raises an error rather than
silently ignoring it.
"""
from __future__ import annotations

from sixglab.core.errors import ConfigurationError
from sixglab.radio.atmosphere import MODEL_ID as ATMOS_ID
from sixglab.radio.atmosphere import absorption_loss_db
from sixglab.radio.pathloss import PathLossModel, UrbanMicro, fspl_db


class THzChannelModel(PathLossModel):
    model_id = f"Reduced-Order THz Propagation Model [UMi-38.901 extrapolated + {ATMOS_ID}]"
    validity_ghz = (0.1, 400.0)
    sigma_los_db, sigma_nlos_db = 4.0, 7.82

    def __init__(self, water_vapour_density_g_m3: float = 7.5, rain_rate_mm_h: float = 0.0) -> None:
        if rain_rate_mm_h > 0:
            raise ConfigurationError("rain attenuation is not implemented in the reduced-order THz model")
        self.rho = water_vapour_density_g_m3
        self._umi = UrbanMicro()

    def validity_note(self, frequency_hz: float) -> str:
        notes = []
        if frequency_hz / 1e9 > 100.0:
            notes.append("UMi-38.901 large-scale term extrapolated above its 100 GHz validity limit")
        return "; ".join(notes)

    def _loss(self, d3d, d2d, los, fc, h_bs, h_ut):
        base, comps = self._umi._loss(d3d, d2d, los, fc, h_bs, h_ut)
        absorb = absorption_loss_db(d3d, fc * 1e9, self.rho)
        fs = fspl_db(d3d, fc * 1e9)
        comps = {**comps, "free_space_db": fs, "excess_over_free_space_db": base - fs,
                 "molecular_absorption_db": absorb}
        return base + absorb, comps
