"""SpatialChannel: reduced-order geometric multi-cluster channel between multi-panel gNBs and single-antenna UEs.

For each (gNB, UE) pair: one LoS path with Rician K (only when the geometric LoS test passed) plus C scattered
clusters whose directions are perturbed around the LoS bearing (small spread for LoS pairs, wide spread for NLoS
pairs) with complex Gaussian gains. Each cluster is evaluated against every candidate panel's steering vector and
element pattern. Normalisation: per-element mean power = element gain toward the cluster; large-scale path loss
is applied OUTSIDE (link budget), so h itself carries only array geometry, element pattern and small-scale phase.

This is NOT ray tracing and NOT a 3GPP CDL/TDL model; angles are drawn from Gaussian spreads. Label results
"reduced-order spatial channel".
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from sixglab.config.models import AntennaConfig
from sixglab.mimo.array import AntennaArray


@dataclass
class SpatialChannelState:
    h: np.ndarray            # (M, N, S, Nt) complex, S candidate panels
    panel: np.ndarray        # (M, N, S) panel index of each candidate slot
    u_global: np.ndarray     # (M, N, 3) LoS unit direction (gNB -> UE)


class SpatialChannel:
    def __init__(self, cfg: AntennaConfig, frequency_hz: float) -> None:
        self.cfg = cfg
        self.freq = frequency_hz
        self.tilt = np.deg2rad(cfg.downtilt_deg)
        self.yaws = 2 * np.pi * np.arange(cfg.panels) / cfg.panels
        self.arrays = [AntennaArray.ura(cfg.rows, cfg.columns, frequency_hz, cfg.spacing_wavelengths,
                                        cfg.element_gain_dbi, yaw, self.tilt) for yaw in self.yaws]
        self.rot = np.stack([a.rotation for a in self.arrays])           # (P, 3, 3)
        self.n_cand = min(cfg.panels, 2)
        self.k_los = float(10 ** (cfg.rician_k_los_db / 10))

    @property
    def n_elements(self) -> int:
        return self.cfg.n_elements

    def generate(self, bs_pos: np.ndarray, ue_pos: np.ndarray, los: np.ndarray,
                 rng: np.random.Generator) -> SpatialChannelState:
        cfg = self.cfg
        m, n = len(bs_pos), len(ue_pos)
        d = ue_pos[None, :, :] - bs_pos[:, None, :]                       # (M, N, 3)
        dist = np.linalg.norm(d, axis=-1, keepdims=True)
        u = d / np.maximum(dist, 1e-9)
        az = np.arctan2(u[..., 1], u[..., 0])
        el = np.arcsin(np.clip(u[..., 2], -1, 1))
        c = cfg.n_clusters
        spread = np.where(los, np.deg2rad(cfg.angular_spread_los_deg), np.deg2rad(cfg.angular_spread_nlos_deg))
        az_c = az[..., None] + spread[..., None] * rng.standard_normal((m, n, c))
        el_c = el[..., None] + 0.5 * spread[..., None] * rng.standard_normal((m, n, c))
        u_c = np.stack([np.cos(el_c) * np.cos(az_c), np.cos(el_c) * np.sin(az_c), np.sin(el_c)], axis=-1)  # (M,N,C,3)
        cn = (rng.standard_normal((m, n, c)) + 1j * rng.standard_normal((m, n, c))) / np.sqrt(2)
        kf = np.where(los, self.k_los, 0.0)[..., None]
        beta_sc = cn * np.sqrt(1.0 / ((kf + 1.0) * c))                    # scattered amplitudes
        beta_los = np.sqrt(kf[..., 0] / (kf[..., 0] + 1.0)) * np.exp(1j * rng.uniform(0, 2 * np.pi, (m, n)))
        # candidate panels: the S nearest in azimuth to the LoS bearing
        yaws = self.yaws[None, None, :]
        diff = np.abs((az[..., None] - yaws + np.pi) % (2 * np.pi) - np.pi)
        panel = np.argsort(diff, axis=-1)[..., : self.n_cand]             # (M, N, S)
        nt = cfg.n_elements
        h = np.zeros((m, n, self.n_cand, nt), dtype=complex)
        arr0 = self.arrays[0]
        for s in range(self.n_cand):
            r = self.rot[panel[..., s]]                                   # (M, N, 3, 3) local->global
            # LoS path
            ul = np.einsum("mnij,mni->mnj", r, u)                         # R^T u
            resp_los = arr0.response(ul)                                  # panels share geometry (same array)
            h[:, :, s] += beta_los[..., None] * resp_los
            # scattered clusters
            uc = np.einsum("mnij,mnci->mncj", r, u_c)
            resp = arr0.response(uc)                                      # (M, N, C, Nt)
            h[:, :, s] += np.einsum("mnc,mnct->mnt", beta_sc, resp)
        return SpatialChannelState(h, panel, u)
