"""Filesystem run store (Parquet + NPZ + JSON). PostgreSQL/TimescaleDB/MinIO backends are Phase 12 roadmap items."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from sixglab.core.errors import ConfigurationError
from sixglab.network.simulation import Simulation
from sixglab.telemetry.recorder import to_jsonable

DEFAULT_ROOT = Path("data/runs")


def save_run(sim: Simulation, summary: dict[str, Any], root: str | Path = DEFAULT_ROOT) -> Path:
    out = Path(root) / sim.simulation_id
    sim.telemetry.save(out, summary)
    (out / "scenario.json").write_text(json.dumps(sim.cfg.model_dump(mode="json"), indent=2))
    (out / "static.json").write_text(json.dumps(to_jsonable(sim.static_snapshot())))
    return out


def load_run(simulation_id: str, root: str | Path = DEFAULT_ROOT) -> dict[str, Any]:
    d = Path(root) / simulation_id
    if not d.is_dir():
        raise ConfigurationError(f"run {simulation_id!r} not found under {root}")
    return {"dir": d, "summary": json.loads((d / "summary.json").read_text()),
            "scenario": json.loads((d / "scenario.json").read_text()),
            "static": json.loads((d / "static.json").read_text()),
            "metrics": pd.read_parquet(d / "metrics.parquet"),
            "ue": dict(np.load(d / "ue_frames.npz"))}
