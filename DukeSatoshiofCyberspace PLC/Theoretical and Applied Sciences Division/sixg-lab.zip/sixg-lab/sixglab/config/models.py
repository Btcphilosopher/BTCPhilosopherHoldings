"""Pydantic configuration models (strict: unknown keys are errors, ranges are validated).

All values are SI. Nothing in the simulator hard-codes a parameter that is not exposed here.
"""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class _Model(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)


class SimulationSettings(_Model):
    duration_s: float = Field(60.0, gt=0)
    timestep_s: float = Field(0.001, gt=0, description="MAC slot duration")
    update_interval_s: float = Field(0.1, gt=0, description="mobility/channel/telemetry epoch")
    seed: int = Field(42, ge=0)
    mode: Literal["real_time", "accelerated", "step", "batch", "monte_carlo"] = "batch"
    speed_factor: float = Field(1.0, gt=0)

    @model_validator(mode="after")
    def _check(self) -> SimulationSettings:
        ratio = self.update_interval_s / self.timestep_s
        if abs(ratio - round(ratio)) > 1e-6 or round(ratio) < 1:
            raise ValueError("update_interval_s must be an integer multiple of timestep_s")
        if self.duration_s < self.update_interval_s:
            raise ValueError("duration_s must be >= update_interval_s")
        return self

    @property
    def slots_per_epoch(self) -> int:
        return int(round(self.update_interval_s / self.timestep_s))

    @property
    def n_epochs(self) -> int:
        return int(round(self.duration_s / self.update_interval_s))


class AntennaConfig(_Model):
    mode: Literal["fixed_gain", "array"] = "fixed_gain"
    bs_gain_dbi: float = 23.0  # fixed_gain mode only
    ue_gain_dbi: float = 10.0
    rows: int = Field(8, ge=1)
    columns: int = Field(8, ge=1)
    spacing_wavelengths: float = Field(0.5, gt=0)
    element_gain_dbi: float = Field(5.0, ge=0)
    panels: int = Field(4, ge=1, description="array panels per gNB, evenly spaced in azimuth")
    downtilt_deg: float = 0.0
    beamformer: Literal["mrt", "codebook"] = "codebook"
    codebook_azimuth_beams: int = Field(16, ge=1)
    codebook_elevation_beams: int = Field(6, ge=1)
    n_clusters: int = Field(4, ge=1)
    angular_spread_los_deg: float = Field(4.0, ge=0)
    angular_spread_nlos_deg: float = Field(25.0, ge=0)
    rician_k_los_db: float = 9.0

    @property
    def n_elements(self) -> int:
        return self.rows * self.columns


class RadioConfig(_Model):
    carrier_frequency_hz: float = Field(140e9, gt=0)
    bandwidth_hz: float = Field(2e9, gt=0)
    transmit_power_w: float = Field(1.0, ge=0)
    noise_figure_db: float = Field(10.0, ge=0)
    temperature_k: float = Field(290.0, gt=0)
    path_loss_model: Literal[
        "free_space", "log_distance", "urban_macro", "urban_micro", "indoor", "rural", "thz"
    ] = "thz"
    log_distance_exponent: float = Field(2.5, gt=0)
    shadowing: bool = True
    shadow_sigma_los_db: float = Field(4.0, ge=0)
    shadow_sigma_nlos_db: float = Field(7.82, ge=0)
    shadow_decorrelation_m: float = Field(13.0, gt=0)
    fading: Literal["none", "rayleigh", "rician", "nakagami"] = "rayleigh"
    rician_k_db: float = 9.0
    nakagami_m: float = Field(2.0, ge=0.5)
    mcs_gap_db: float = Field(3.0, ge=0, description="gap-to-Shannon of the link-level abstraction")
    overhead_fraction: float = Field(0.14, ge=0, lt=1)
    bler_target: float = Field(0.1, gt=0, lt=0.5)
    water_vapour_density_g_m3: float = Field(7.5, ge=0)
    rain_rate_mm_h: float = Field(0.0, ge=0)
    antenna: AntennaConfig = AntennaConfig()


class EnvironmentConfig(_Model):
    blocks_x: int = Field(6, ge=1)
    blocks_y: int = Field(5, ge=1)
    block_m: float = Field(80.0, gt=0)
    street_m: float = Field(20.0, gt=0)
    lots_per_block_side: int = Field(2, ge=1)
    building_height_min_m: float = Field(10.0, gt=0)
    building_height_max_m: float = Field(50.0, gt=0)
    empty_lot_probability: float = Field(0.1, ge=0, le=1)
    raster_resolution_m: float = Field(2.0, gt=0)
    los_samples: int = Field(160, ge=8)
    ue_height_m: float = Field(1.5, gt=0)
    temperature_k: float = Field(288.15, gt=0)


class HandoverConfig(_Model):
    metric: Literal["rsrp", "sinr"] = "rsrp"
    hysteresis_db: float = Field(3.0, ge=0)
    time_to_trigger_s: float = Field(0.2, ge=0)
    interruption_s: float = Field(0.02, ge=0)
    failure_sinr_db: float = Field(-8.0, description="target SINR below which HO execution fails")
    ping_pong_window_s: float = Field(2.0, gt=0)


class PopulationGroup(_Model):
    kind: Literal["static", "random_walk", "random_waypoint", "pedestrian", "vehicle", "train", "uav"]
    count: int = Field(ge=0)
    speed_mps: float | None = Field(None, gt=0)
    height_m: float | None = Field(None, gt=0)


class TrafficConfig(_Model):
    mix: dict[str, float] = {"video": 0.4, "web": 0.3, "xr": 0.1, "voice": 0.1, "digital_twin": 0.1}
    rate_scale: float = Field(1.0, gt=0)


class EdgeConfig(_Model):
    servers: int = Field(3, ge=1)
    cpu_cycles_per_s: float = Field(4.0e10, gt=0)
    fibre_route_factor: float = Field(1.3, ge=1)
    per_hop_latency_s: float = Field(2e-5, ge=0)
    core_latency_s: float = Field(5e-4, ge=0)
    application_latency_s: float = Field(5e-4, ge=0)
    buffer_bytes: float = Field(2e6, gt=0)


class NetworkConfig(_Model):
    base_stations: int = Field(12, ge=1)
    bs_height_m: float = Field(10.0, gt=0)
    scheduler: Literal["round_robin", "proportional_fair", "max_throughput"] = "proportional_fair"
    pf_time_constant_slots: float = Field(100.0, gt=1)
    handover: HandoverConfig = HandoverConfig()
    populations: list[PopulationGroup] = [
        PopulationGroup(kind="pedestrian", count=60),
        PopulationGroup(kind="vehicle", count=40),
    ]
    traffic: TrafficConfig = TrafficConfig()
    edge: EdgeConfig = EdgeConfig()


class EnergyConfig(_Model):
    bs_static_w: float = Field(60.0, ge=0)
    bs_chain_w: float = Field(1.2, ge=0, description="per antenna element RF chain")
    pa_efficiency: float = Field(0.15, gt=0, le=1)
    cooling_overhead: float = Field(0.10, ge=0)
    edge_idle_w: float = Field(150.0, ge=0)
    edge_max_w: float = Field(600.0, ge=0)
    ue_rx_w: float = Field(0.8, ge=0)


class ScenarioConfig(_Model):
    name: str = "scenario"
    version: str = "1"
    description: str = ""
    simulation: SimulationSettings = SimulationSettings()
    radio: RadioConfig = RadioConfig()
    environment: EnvironmentConfig = EnvironmentConfig()
    network: NetworkConfig = NetworkConfig()
    energy: EnergyConfig = EnergyConfig()
    ai: dict = {}

    @property
    def n_ues(self) -> int:
        return sum(g.count for g in self.network.populations)
