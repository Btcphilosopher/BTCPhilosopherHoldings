"""YAML loading: package defaults < config/*.yaml < scenario file. Unknown keys are rejected."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from sixglab.config.models import ScenarioConfig
from sixglab.core.errors import ConfigurationError
from sixglab.core.provenance import config_hash

_DEFAULT_FILES = ("simulation.yaml", "radio.yaml", "network.yaml", "ai.yaml", "energy.yaml")


def _deep_merge(base: dict[str, Any], over: dict[str, Any]) -> dict[str, Any]:
    out = dict(base)
    for k, v in over.items():
        out[k] = _deep_merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def _read(path: Path) -> dict[str, Any]:
    try:
        doc = yaml.safe_load(path.read_text())
    except (OSError, yaml.YAMLError) as exc:
        raise ConfigurationError(f"cannot read {path}: {exc}") from exc
    if doc is None:
        return {}
    if not isinstance(doc, dict):
        raise ConfigurationError(f"{path}: top level must be a mapping")
    return doc


def default_config_dir() -> Path:
    return Path(__file__).resolve().parents[2] / "config"


def scenario_from_dict(doc: dict[str, Any]) -> ScenarioConfig:
    try:
        return ScenarioConfig.model_validate(doc)
    except Exception as exc:  # pydantic ValidationError -> our error type with full message
        raise ConfigurationError(f"invalid scenario configuration:\n{exc}") from exc


def load_scenario(path: str | Path, config_dir: str | Path | None = None,
                  overrides: dict[str, Any] | None = None) -> ScenarioConfig:
    merged: dict[str, Any] = {}
    cdir = Path(config_dir) if config_dir else default_config_dir()
    if cdir.is_dir():
        for fname in _DEFAULT_FILES:
            f = cdir / fname
            if f.exists():
                merged = _deep_merge(merged, _read(f))
    merged = _deep_merge(merged, _read(Path(path)))
    if overrides:
        merged = _deep_merge(merged, overrides)
    return scenario_from_dict(merged)


def scenario_hash(cfg: ScenarioConfig) -> str:
    return config_hash(cfg.model_dump(mode="json"))
