"""Beamformer: MRT, ZF and MMSE (regularised ZF) downlink precoders and their SINR.

H (K x Nt): row k is user k's channel (y_k = h_k^T w_k s_k + ...).  W (Nt x K): columns are per-user weights
scaled so that  sum_k ||w_k||^2 * p_k  equals the total transmit power  (equal power allocation).
"""
from __future__ import annotations

import numpy as np

from sixglab.core.errors import ConfigurationError
from sixglab.core.validation import require_condition_ok, require_finite


def _normalise(w: np.ndarray, total_power_w: float) -> np.ndarray:
    k = w.shape[1]
    norms = np.linalg.norm(w, axis=0, keepdims=True)
    return w / np.maximum(norms, 1e-300) * np.sqrt(total_power_w / k)


def mrt(H: np.ndarray, total_power_w: float = 1.0) -> np.ndarray:
    """Maximum-ratio transmission: w_k proportional to conj(h_k)."""
    require_finite("H", H)
    return _normalise(H.conj().T, total_power_w)


def zf(H: np.ndarray, total_power_w: float = 1.0) -> np.ndarray:
    """Zero-forcing: W ~ H^H (H H^H)^-1, so h_j^T w_k = 0 for j != k. Requires K <= Nt."""
    require_finite("H", H)
    k, nt = H.shape
    if k > nt:
        raise ConfigurationError(f"ZF needs users <= antennas (got {k} > {nt})")
    g = H @ H.conj().T
    require_condition_ok("H H^H (ZF)", g)
    return _normalise(H.conj().T @ np.linalg.inv(g), total_power_w)


def mmse(H: np.ndarray, noise_power_w: float, total_power_w: float = 1.0) -> np.ndarray:
    """MMSE / regularised ZF: W ~ H^H (H H^H + (K sigma^2 / P) I)^-1."""
    require_finite("H", H)
    k = H.shape[0]
    alpha = k * noise_power_w / total_power_w
    return _normalise(H.conj().T @ np.linalg.inv(H @ H.conj().T + alpha * np.eye(k)), total_power_w)


def downlink_sinr(H: np.ndarray, W: np.ndarray, noise_power_w: float) -> np.ndarray:
    """Per-user SINR. G[k, j] = |h_k^T w_j|^2 ; SINR_k = G_kk / (sum_{j!=k} G_kj + sigma^2)."""
    G = np.abs(H @ W) ** 2
    sig = np.diag(G)
    interf = G.sum(axis=1) - sig
    return sig / (interf + noise_power_w)


def array_gain_db(h_row: np.ndarray, w: np.ndarray) -> float:
    """Beamforming gain relative to a single element with unit channel: |h^T w|^2 / (|w|^2)."""
    return float(10 * np.log10(np.abs(h_row @ w) ** 2 / max(np.linalg.norm(w) ** 2, 1e-300)))


def sum_spectral_efficiency(sinr: np.ndarray) -> float:
    return float(np.sum(np.log2(1.0 + sinr)))


PRECODERS = {"mrt": mrt, "zf": zf, "mmse": mmse}
