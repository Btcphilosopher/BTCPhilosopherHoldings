"""BeamManager: beam sweeping, measurement, selection, tracking, failure detection and recovery.

Per UE the manager holds the selected codebook beam. Every ``sweep_period`` epochs a full codebook sweep is
measured (using the actual channel); in between, only the selected beam and its grid neighbours are measured
(tracking). A beam failure is declared when the tracked gain falls ``failure_drop_db`` below the gain measured at
the last full sweep; recovery triggers an immediate full sweep.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class BeamReport:
    beam_idx: np.ndarray       # (N,)
    gain_lin: np.ndarray       # (N,) |h^T w|^2 of the selected beam
    switched: np.ndarray       # (N,) bool
    failed: np.ndarray         # (N,) bool (failure detected this epoch, before recovery)
    swept: bool


class BeamManager:
    def __init__(self, weights: np.ndarray, n_az: int, n_el: int, sweep_period: int = 5,
                 failure_drop_db: float = 10.0) -> None:
        self.w = weights                                  # (B, Nt)
        self.n_az, self.n_el = n_az, n_el
        self.period, self.drop = sweep_period, failure_drop_db
        self.beam = np.array([], dtype=int)
        self.ref_gain = np.array([])
        self.epoch = 0
        self.sweeps = 0
        self.failures = 0
        # neighbour table on the (el, az) grid, meshgrid ordering index = el*n_az + az
        nb = []
        for b in range(n_az * n_el):
            e, a = divmod(b, n_az)
            cand = [(e + de) * n_az + (a + da) for de in (-1, 0, 1) for da in (-1, 0, 1)
                    if 0 <= e + de < n_el and 0 <= a + da < n_az]
            nb.append(cand + [cand[0]] * (9 - len(cand)))
        self.neighbours = np.array(nb)

    def sweep(self, h: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        g = np.abs(h @ self.w.T) ** 2                     # (N, B): measured gain per beam
        idx = np.argmax(g, axis=1)
        return idx, g[np.arange(len(h)), idx]

    def update(self, h: np.ndarray, reset: np.ndarray | None = None) -> BeamReport:
        n = len(h)
        if len(self.beam) != n:                           # first call or population change: full sweep
            idx, gain = self.sweep(h)
            self.beam, self.ref_gain = idx, gain
            self.epoch += 1
            self.sweeps += 1
            return BeamReport(idx, gain, np.zeros(n, bool), np.zeros(n, bool), True)
        full = self.epoch % self.period == 0
        prev = self.beam.copy()
        failed = np.zeros(n, bool)
        if full:
            idx, gain = self.sweep(h)
            self.ref_gain = gain
            self.sweeps += 1
            reset = None
        else:
            cand = self.neighbours[self.beam]             # (N, 9)
            g = np.abs(np.einsum("nt,nct->nc", h, self.w[cand])) ** 2
            j = np.argmax(g, axis=1)
            idx, gain = cand[np.arange(n), j], g[np.arange(n), j]
            failed = gain < self.ref_gain * 10 ** (-self.drop / 10)
            if failed.any():                              # beam recovery: immediate full sweep for failed UEs
                fi, fg = self.sweep(h[failed])
                idx[failed], gain[failed] = fi, fg
                self.ref_gain[failed] = fg
                self.failures += int(failed.sum())
        if reset is not None and reset.any():             # serving cell/panel changed: fresh sweep for these UEs
            ri, rg = self.sweep(h[reset])
            idx[reset], gain[reset] = ri, rg
            self.ref_gain[reset] = rg
        self.beam = idx
        self.epoch += 1
        return BeamReport(idx, gain, idx != prev, failed, full)
