"""DigitalTwin: the central object. Wraps the simulated network and keeps three states apart:

* simulated state  - what the model currently computes (Simulation.state)
* physical state   - observations ingested from the real (or emulated) network via ``ingest_observation``
* historical state - per-epoch telemetry of the simulated state

``divergence`` quantifies model-vs-observation error (RMSE of position and SINR), which is what a twin needs in order
to be calibrated - it is computed, not asserted.
"""
from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from sixglab.config.models import ScenarioConfig
from sixglab.core.errors import ConfigurationError
from sixglab.network.simulation import Simulation


class DigitalTwin:
    def __init__(self, cfg: ScenarioConfig, **kw) -> None:
        self.sim = Simulation(cfg, **kw)
        self.physical: dict[str, Any] = {}

    # ---- components exposed by name ------------------------------------------------------------
    @property
    def network(self):
        return self.sim.topology

    @property
    def radio_environment(self):
        return self.sim.env

    @property
    def telemetry(self):
        return self.sim.telemetry

    def step(self) -> dict[str, Any]:
        return self.sim.step_epoch()

    def run(self, **kw) -> dict[str, Any]:
        return self.sim.run(**kw)

    @property
    def simulated_state(self):
        return self.sim.state

    @property
    def history(self) -> pd.DataFrame:
        return self.sim.telemetry.dataframe()

    def ingest_observation(self, ue_positions: np.ndarray | None = None, sinr_db: np.ndarray | None = None) -> None:
        obs: dict[str, Any] = {"t_s": self.sim.state.t_s}
        if ue_positions is not None:
            if ue_positions.shape != (self.sim.n_ue, 3):
                raise ConfigurationError(f"ue_positions must be ({self.sim.n_ue}, 3)")
            obs["ue_positions"] = np.asarray(ue_positions, float)
        if sinr_db is not None:
            if sinr_db.shape != (self.sim.n_ue,):
                raise ConfigurationError(f"sinr_db must be ({self.sim.n_ue},)")
            obs["sinr_db"] = np.asarray(sinr_db, float)
        self.physical = obs

    def divergence(self) -> dict[str, float]:
        out: dict[str, float] = {}
        if "ue_positions" in self.physical:
            d = np.linalg.norm(self.physical["ue_positions"] - self.sim.ue_pos, axis=1)
            out["position_rmse_m"] = float(np.sqrt(np.mean(d**2)))
        if "sinr_db" in self.physical:
            e = self.physical["sinr_db"] - self.sim.state.sinr_db
            out["sinr_rmse_db"] = float(np.sqrt(np.mean(e**2)))
        return out
