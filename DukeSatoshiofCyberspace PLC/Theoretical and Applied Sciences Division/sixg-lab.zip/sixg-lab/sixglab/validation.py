"""Analytical validation suite: numerical results vs closed-form physics. Used by ``sixg validate`` and the tests."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from sixglab.beamforming.precoders import downlink_sinr, mrt, zf
from sixglab.core.units import C_LIGHT, K_BOLTZMANN
from sixglab.mimo.array import AntennaArray
from sixglab.radio.modulation import ber_test, theoretical_ber_awgn
from sixglab.radio.noise import thermal_noise_dbm, thermal_noise_power_w
from sixglab.radio.ofdm import OFDMConfig, OFDMModem
from sixglab.radio.pathloss import UrbanMicro, fspl_db
from sixglab.ris.surface import RIS, coordinate_descent, total_field


@dataclass
class Check:
    name: str
    expected: float
    got: float
    tol: float
    note: str = ""

    @property
    def passed(self) -> bool:
        return bool(abs(self.got - self.expected) <= self.tol)


def run_validation() -> list[Check]:
    rng = np.random.default_rng(7)
    out: list[Check] = []
    out.append(Check("FSPL 1 km @ 1 GHz (dB)", 20 * np.log10(4 * np.pi * 1e3 * 1e9 / C_LIGHT), float(fspl_db(1e3, 1e9)), 1e-9,
                     "= 92.45 dB (textbook)"))
    out.append(Check("FSPL +6.02 dB per distance doubling", 20 * np.log10(2), float(fspl_db(200, 140e9) - fspl_db(100, 140e9)), 1e-9))
    out.append(Check("Thermal noise density @290 K (dBm/Hz)", -173.975, thermal_noise_dbm(1.0, 290.0), 5e-3, "kT = -174 dBm/Hz"))
    out.append(Check("Thermal noise 2 GHz + 10 dB NF (dBm)", -173.975 + 93.0103 + 10, thermal_noise_dbm(2e9, 290.0, 10.0), 5e-3))
    out.append(Check("N = kTB (W)", K_BOLTZMANN * 300 * 1e6, thermal_noise_power_w(1e6, 300.0), 1e-30))
    out.append(Check("UMi LoS 3.5 GHz 100 m (dB)", 32.4 + 21 * 2 + 20 * np.log10(3.5),
                     float(UrbanMicro().compute(np.array([100.0]), np.array([100.0]), np.array([True]), 3.5e9, 10, 1.5).loss_db[0]), 1e-9))
    # OFDM round trip
    cfg = OFDMConfig(fft_size=256, subcarrier_spacing_hz=1e6, cp_length=32, num_subcarriers=200)
    m = OFDMModem(cfg)
    g = rng.standard_normal((4, 200)) + 1j * rng.standard_normal((4, 200))
    out.append(Check("OFDM IFFT/FFT round-trip max error", 0.0, float(np.max(np.abs(m.demodulate(m.modulate(g)) - g))), 1e-12))
    # OFDM through multipath with CP >= delay spread: one-tap ZF is exact
    h = np.array([1.0, 0.5j, -0.3])
    tx = m.modulate(g)
    rx = np.stack([np.convolve(r, h)[: r.size] for r in tx])
    hf = np.fft.fft(h, cfg.fft_size)[m.bins]
    out.append(Check("OFDM 1-tap equalisation in multipath (CP >= L)", 0.0,
                     float(np.max(np.abs(m.demodulate(rx) / hf - g))), 1e-10))
    # BER vs theory
    for sch, eb in (("QPSK", 6.0), ("16-QAM", 8.0)):
        sim_ber = ber_test(sch, eb, 600_000, rng)
        th = float(theoretical_ber_awgn(eb, sch))
        out.append(Check(f"{sch} BER @ Eb/N0={eb} dB", th, sim_ber, 0.15 * th, "Monte Carlo vs closed form (15%)"))
    # Shannon: high-SNR capacity slope 1 bit per 3.01 dB
    cap = lambda snr_db: np.log2(1 + 10 ** (snr_db / 10))  # noqa: E731
    out.append(Check("Shannon: +3.01 dB -> +1 bit/s/Hz at high SNR", 1.0, float(cap(33.01) - cap(30.0)), 1e-3))
    # Array gain
    a = AntennaArray.ura(8, 8, 140e9, element_gain_dbi=0.0)
    h_bore = a.response(np.array([1.0, 0, 0]))
    gain = 10 * np.log10(np.abs(h_bore @ (np.conj(h_bore) / np.linalg.norm(h_bore))) ** 2)
    out.append(Check("MRT array gain, 64 elements (dB) = 10log10(N)", 10 * np.log10(64), float(gain), 1e-9))
    # ZF nulls inter-user interference
    H = (rng.standard_normal((4, 32)) + 1j * rng.standard_normal((4, 32))) / np.sqrt(2)
    Gz = np.abs(H @ zf(H, 1.0)) ** 2
    out.append(Check("ZF residual interference / signal", 0.0, float(np.max(Gz - np.diag(np.diag(Gz))) / np.min(np.diag(Gz))), 1e-12))
    s_mrt, s_zf = downlink_sinr(H, mrt(H, 1.0), 1e-3), downlink_sinr(H, zf(H, 1.0), 1e-3)
    out.append(Check("ZF beats MRT in sum-SINR at high SNR (1 = yes)", 1.0, float(s_zf.sum() > s_mrt.sum()), 0.0))
    # RIS N^2
    ris = RIS(np.array([0, 0, 5.0]), np.array([0, 1.0, 0]), 16, 16, 140e9)
    C = ris.cascade(np.array([-30, 30, 10.0]), np.array([30, 30, 1.5]), 1.0, 100.0, 10.0)
    ris.phases = coordinate_descent(np.zeros(1, complex), C[None, :], ris)
    p = np.abs(total_field(np.zeros(1, complex), C[None, :], ris.reflection()))[0] ** 2
    out.append(Check("RIS coherent gain over one element = N^2", float(ris.n**2), float(p / np.mean(np.abs(C) ** 2)), 1e-3 * ris.n**2))
    return out
