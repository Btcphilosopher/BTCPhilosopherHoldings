# AI-native networking - status: NOT IMPLEMENTED in this release

No ML component exists yet (traffic/channel/mobility prediction, Random Forest/GBM/LSTM comparison, RL controller, AI scheduler,
semantic communications). The dashboard's AI tab says so and shows nothing. Design constraints for Phase 11, unchanged from the brief:
prediction / optimisation / control are separate objects; every model is trained, validated, tested and reported with dataset, features,
target, metric and training version; every optimisation is shown as before -> objective -> constraints -> decision -> after; the RL
environment defines state/action/reward/transition explicitly and cannot modify safety-critical assumptions. The simulator already
produces the required labelled data (`data/runs/<id>/ue_frames.npz`, `metrics.parquet`).
