# Network: RAN, handover, scheduler, traffic, latency, transport, energy

* **Association / handover** (`network.handover`): A3 event - neighbour better than serving by `hysteresis_db` for `time_to_trigger_s`; metric RSRP or wideband SINR;
  execution fails if the target cell's SNR is below `failure_sinr_db` (then retries after a back-off); ping-pong = return to the previous cell within a window;
  successful handover imposes an `interruption_s` during which the UE is not scheduled. RSRQ is not implemented.
* **MAC / scheduler** (`network.scheduler`): per-slot Round Robin (least recently served), Proportional Fair (`r/T`), Max Throughput; airtime is multiplexed
  across UEs inside a slot (work-conserving: a slot carries as many UEs as its airtime allows). Link adaptation is slow (average SINR): a slot succeeds if instantaneous SINR >= threshold of the selected MCS; failed blocks stay queued.
  Channel-aware (fast-CQI) scheduling is not modelled, so PF converges to equal airtime for saturated UEs (visible in the tests).
* **Traffic**: web, video, voice, xr, industrial_control, iot, robotics, autonomous_vehicle, digital_twin; Poisson packet arrivals at a configurable rate. Buffer overflow = congestion loss. UEs in outage are *blocked* (reported separately from loss).
* **Latency is measured**: tagged packets are followed through the FIFO with cumulative arrival/departure curves. `radio = 0.5 slot + tx time`, `queue = measured sojourn - tx`, `transport` = NetworkX shortest-path latency gNB->edge (fibre 2e8 m/s x route factor + per-hop), `edge` = M/G/1 Pollaczek-Khinchine on the edge CPU (saturation is flagged and capped, never infinite), `application` = configurable constant. Resolution is one slot (1 ms); sub-slot URLLC latency needs mini-slots (not modelled). Validated against deterministic and batch-queue analytics.
* **Interference coupling**: interference at epoch e uses airtime shares measured in epoch e-1 (load-coupled, one-epoch lag).
* **Energy**: `P_gNB = (P_static + N_chain P_chain + P_tx activity/eta_PA)(1+cooling)`; edge linear in utilisation; UE receive power. Outputs W, Wh, J/bit, Wh/GB. Parameters are scenario inputs.
* Not implemented: slicing orchestrator (traffic classes carry a slice label but no resources are sliced), cell-free MIMO, core network functions.
