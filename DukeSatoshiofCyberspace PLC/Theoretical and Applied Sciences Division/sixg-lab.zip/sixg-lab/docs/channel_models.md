# Channel models

* **Large scale**: path loss (see radio_models.md) + log-normal shadowing, Gudmundson AR(1) in travelled distance,
  `z_k = rho z_{k-1} + sqrt(1-rho^2) eps`, `rho = exp(-dd/d_corr)`, sigma per LoS state. Limitation: shadowing is independent per gNB-UE link (no inter-site correlation).
* **Small scale (fixed-gain mode)**: unit-mean power gain, Rayleigh / Rician(K) / Nakagami-m (`StochasticChannel`); time correlation
  from Jakes `rho = J0(2 pi f_d T_slot)` with `f_d = v f / c` (worst-case radial). At 140 GHz and 14 m/s `f_d` = 6.5 kHz: the
  channel decorrelates within a slot, which the simulator reproduces. Nakagami is i.i.d. per slot.
* **Spatial (array mode)**: `SpatialChannel` - one LoS path (Rician K = `rician_k_los_db`, only if geometric LoS) plus `n_clusters`
  scattered paths with Gaussian angular spread (small for LoS pairs, wide for NLoS pairs); each path is evaluated against each
  candidate panel's steering vector and cosine-power element pattern. **Not ray tracing, not 3GPP CDL/TDL.** One realisation per
  epoch (100 ms): within-epoch fading is not modelled in array mode (channel hardening with 64 elements assumed).
* **THz**: see radio_models.md.
