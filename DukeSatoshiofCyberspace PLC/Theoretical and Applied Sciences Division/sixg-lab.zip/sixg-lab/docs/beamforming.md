# Beamforming and beam management

Precoders (`beamforming.precoders`), `H` is K x Nt, total power P:
* MRT `W ~ H^H`; * ZF `W ~ H^H (H H^H)^-1`; * MMSE `W ~ H^H (H H^H + K sigma^2/P I)^-1`; columns scaled to the power budget.
SINR_k = |h_k^T w_k|^2 / (sum_{j!=k}|h_k^T w_j|^2 + sigma^2). Validation: MRT array gain = 10 log10 N (18.06 dB for 64); ZF residual
interference < 1e-12 of the signal; ZF beats MRT in sum-SINR at high SNR; MRT single-user SINR = P ||h||^2/sigma^2.
Singular / ill-conditioned Gram matrices raise `NumericalError`; ZF with more users than antennas raises `ConfigurationError`.

`BeamManager`: codebook sweep (measured on the actual channel), selection, neighbour tracking, failure (gain drops `failure_drop_db` below
the last sweep) and recovery (immediate re-sweep). In the system simulator each gNB has `panels` URA panels (default 4 x 8x8=64
elements); the serving panel is the one with the strongest channel. Interference from gNB j on UE u is computed exactly as the time-averaged
`sum_k share_k |h_{j,u}^T w_{j,k}|^2` over the beams j actually uses (weights and time shares from the simulation), not an isotropic assumption.
Baseline vs beamforming on the shipped scenario (seed 42, 100 UEs, 10 s): median SINR -3.5 dB (single element) -> 12.7 dB (codebook) -> 13.7 dB (MRT ideal CSI); coverage 33% -> 73% -> 85% (`examples/beamforming_gain.py`).
Limitations: analog single-beam per slot; no multi-user spatial multiplexing in the system simulator (ZF/MMSE are link-level); ideal CSI for MRT.
