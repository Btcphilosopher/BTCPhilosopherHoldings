# Edge computing and offloading

`EdgeServer`: CPU (cycles/s), power model, M/G/1 queue: `W = lambda E[S^2] / (2(1-rho))`, response = service + W; saturation (`rho >= 0.98`) is flagged and the wait capped.
Validated against M/D/1: `rho=0.5, s=1 ms -> W = 0.5 ms`.
`edge.offload.compare(task, ul, dl, ...)`: local (`t = cycles/f`, energy `kappa f^2 cycles`), edge (uplink + 2 x transport + queue + compute + downlink; UE radio energy) and cloud (adds WAN RTT).
Uplink/downlink rates come from the simulation (`link_rates`): full-band rate at the selected MCS times a TDD share; **uplink ignores UL interference**.
`examples/xr_offload.py` (seeded, 100 UEs): XR frame (4 kB up, 1.2 MB down, 3e10 ops, 20 ms budget) - local 30.0 ms (0% within budget), edge median 1.8 ms (80.8% of connected UEs within budget), cloud 21.4 ms (0%).
The compute capacities in that example (mobile 1e12, edge render node 1e14, cloud 1e15 ops/s) are illustrative inputs.
