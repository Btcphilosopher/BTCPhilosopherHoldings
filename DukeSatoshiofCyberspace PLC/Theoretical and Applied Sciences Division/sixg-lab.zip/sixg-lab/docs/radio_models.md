# Radio models

## Free-space path loss  (`radio.pathloss.fspl_db`)
`PL = 20 log10(4 pi d f / c)`. d [m], f [Hz], c = 299 792 458 m/s. Assumes far field, isotropic antennas, no obstruction.
Validation: 92.45 dB at 1 km / 1 GHz; +6.02 dB per distance or frequency doubling.

## 3GPP-derived models (`UrbanMicro`, `UrbanMacro`, `Indoor`, `Rural`)
TR 38.901 Table 7.4.1-1 formulas, `fc` in GHz, `d3D` in m, breakpoint `d_BP' = 4 h'_BS h'_UT fc / c` (h_E = 1 m).
`PL = max(PL_LoS, PL'_NLoS)` in NLoS. LoS/NLoS is **geometric**, not the probabilistic 3GPP LoS probability.
Limits: valid range is stated per model and reported in every result (`validity_note`); `Rural` (RMa) was transcribed
without access to the standard text and is flagged as unverified; distances below 10 m are clamped.
Validation: UMi LoS at 3.5 GHz / 100 m equals `32.4 + 21*2 + 20 log10 3.5 = 85.28 dB`.

## Reduced-Order THz Propagation Model (`channel.thz.THzChannelModel`)
`PL = PL_UMi(d, f, LoS/NLoS) + A_mol(d, f)`. The UMi term is **extrapolated** above 100 GHz. `A_mol = gamma(f) d / 1 km`
with `gamma` from `radio.atmosphere`: eight Lorentzian-like lines (O2 at 60/118.75 GHz, H2O at 22/183/325/380/448/557 GHz)
`P_i (1+((f-f_i)/w_i)^2)^-3/2` plus a `f^2` water-vapour continuum, water terms scaled by `rho/7.5 g/m^3`.
The line peaks are coarse anchors read off ITU-R P.676 curves - **not** a line-by-line implementation; expect a factor ~2
error in windows and only indicative peaks. Temperature and pressure dependence, rain, fog, foliage, diffuse scattering,
surface roughness and full ray tracing are **not** modelled; requesting rain > 0 raises an error.
Validation (tests): 0.008 dB/km at 3.5 GHz, ~15 dB/km at 60 GHz, ~1.3 dB/km at 140 GHz, ~30 dB/km at 183 GHz;
water lines vanish at zero humidity.

## Noise (`radio.noise`)
`N = k T B F`, k = 1.380649e-23 J/K. -173.98 dBm/Hz at 290 K; 2 GHz + 10 dB NF -> -70.96 dBm (tested).

## Link budget (`radio.link_budget.LinkBudget`)
`P_rx = P_tx + G_tx + G_bf - PL - shadow + G_rx`, `SNR = P_rx - N`, `SINR = P_rx / (N + I)`. `terms()` returns the ordered chain shown in the UI.

## Link adaptation (`radio.mcs`) - RESEARCH APPROXIMATION
Spectral efficiencies and code rates: TS 38.214 256-QAM CQI table. SINR thresholds: `Gamma (2^eta - 1)`, `Gamma` = `mcs_gap_db`
(3 dB). This is a gap-to-Shannon abstraction, not link-level BLER curves. The MCS is chosen from the average SINR plus the
fading `bler_target` quantile, so the block error rate emerges from simulated fading. Throughput = `B * eta * (1 - overhead)`.

## Coding (`radio.coding`)
`PolarCoder`: real Arikan polar code (polarization-weight construction, SC min-sum decoder). At Eb/N0 = 3 dB, N=256, K=128 the
measured BER is ~10x lower than uncoded BPSK (tested). LDPC is **not implemented**. The system simulator uses the MCS
abstraction above, not the coder, per block.

## Modulation and OFDM
Gray-mapped square QAM (QPSK/16/64/256), unit average energy, hard demodulation; simulated BER matches the closed form within
Monte Carlo error (tested). `OFDMModem`: unitary IFFT/FFT, CP, DC-free subcarrier mapping, pilots, resource blocks; round trip
exact to 1e-15; one-tap equalisation exact when CP >= channel delay spread, and demonstrably not when CP is too short.
