# Architecture

```
PHYSICAL WORLD  ->  RADIO ENVIRONMENT  ->  CHANNEL  ->  RAN  ->  TRANSPORT/CORE  ->  EDGE  ->  APPLICATION
        \______________________ DigitalTwin (simulated | physical | historical state) ______________________/
```

| Layer | Package | Status |
|---|---|---|
| Config, clock, events, RNG, logging, provenance | `core`, `config` | implemented |
| Radio environment (buildings, roads, weather), LoS ray-marching | `radio.environment` | implemented (flat terrain; no vegetation/reflectors) |
| Path loss, THz reduced-order model, noise, link budget, MCS, OFDM, QAM, Polar code | `radio`, `channel` | implemented |
| Arrays, spatial channel, MRT/ZF/MMSE, beam management | `mimo`, `beamforming`, `channel.spatial` | implemented |
| Mobility (static, random walk/waypoint, pedestrian, vehicle, train, UAV) | `mobility` | implemented |
| RAN: association, A3 handover, slot-level scheduler, measured latency | `network` | implemented |
| Transport graph (NetworkX), edge M/G/1 server, offloading comparison | `network.topology`, `edge` | implemented |
| Energy | `energy` | implemented (simple explicit model) |
| RIS cascade + optimisation | `ris` | implemented (link-level experiment on a live snapshot) |
| Telemetry, Parquet/NPZ/JSON storage, HTML/PDF/JSON reports | `telemetry`, `storage`, `visualisation` | implemented |
| Experiments, parameter sweeps, Monte Carlo | `scenarios` | implemented |
| REST + WebSocket, dashboard | `api`, `frontend` | implemented |
| Satellite, UAV base station, ISAC, semantic comms, slicing orchestrator, cell-free MIMO, AI/RL, PostgreSQL/MinIO | packages exist as empty placeholders | **not implemented** |

## Data flow of one epoch (`Simulation.step_epoch`)
1. mobility -> UE positions/velocities; 2. geometry + geometric LoS; 3. path loss (+ AR(1) shadowing);
4. antenna gains (fixed, or spatial channel + beam selection); 5. RSRP -> association / handover;
6. serving signal, time-averaged interference from measured airtime shares of the previous epoch, SINR;
7. CQI/MCS; 8. per-slot fast fading, Poisson traffic, slot-level MAC (100 slots/epoch), tagged-packet delay measurement;
9. latency decomposition (radio / queue / transport / edge / application), energy, telemetry, events.

Time base: `timestep_s` is the MAC slot (1 ms); `update_interval_s` is the epoch (100 ms) at which mobility, path loss,
channel and telemetry are refreshed. Both are configurable; the epoch must be an integer number of slots.

## Design decisions
* SI units internally; conversion only at the UI (`dB`, `dBm`, GHz, Gb/s in the frontend/CLI).
* Determinism: every component draws from a named stream `RngFactory(seed).stream(name)` so the result does not depend
  on call order. Same seed + config => identical telemetry (tested).
* Numba/JAX are not used yet: profiling (`sixg benchmark`) shows LoS, spatial channel and MAC each take 50-100 ms per
  epoch at 500 UEs; they are the candidates when a real bottleneck appears.
