# MIMO / arrays

`H in C^{Nr x Nt}` (`MIMOChannel`: SISO, SIMO, MISO, MIMO, massive MIMO, i.i.d. Rayleigh or geometric). Equal-power capacity
`C = log2 det(I + snr/Nt H H^H)`; validated against the analytic ergodic Rayleigh SISO capacity `e^{1/snr} E1(1/snr)/ln 2`.
`AntennaArray`: ULA / URA / custom positions, spacing in wavelengths, yaw and downtilt, steering `a_n(u) = exp(j k p_n.u)`,
element gain `D0 cos^q`, `q = D0/2 - 1`. Separable fast path for URA (checked against the generic formula).
Massive MIMO sizes 32/64/128/256 are all configurable (`rows`, `columns`, `panels`). Limitations: no mutual coupling, no
polarisation, ideal (non-quantised) phase shifters, single-antenna UEs in the system simulation (multi-antenna UEs only at link level).
