# Validation

`sixg validate` runs 15 closed-form checks; `pytest` (123 tests) adds property-based and simulation-level checks.

| Physics | Reference | Check |
|---|---|---|
| Free-space path loss | Friis | 92.45 dB @ 1 km, 1 GHz; +6.02 dB/octave |
| Thermal noise | kTB | -173.98 dBm/Hz; 2 GHz+10 dB NF = -70.96 dBm |
| UMi LoS | TR 38.901 | 85.28 dB @ 3.5 GHz, 100 m |
| OFDM | IFFT/FFT identity; CP theorem | round trip 1e-15; 1-tap equalisation exact for CP >= L, fails for CP < L |
| QAM BER | Gray-QAM closed form | within 15% (Monte Carlo) for QPSK, 16-, 64-QAM |
| Shannon | 1 bit / 3.01 dB | slope check; MCS never exceeds capacity at its threshold |
| Ergodic MIMO capacity | Rayleigh SISO formula | within 6% |
| Array gain | 10 log10 N | exact for 64 elements |
| ZF | H W diag | residual interference < 1e-12 |
| RIS | N^2 coherent scaling | ratio = N^2 within 1e-3; random phase ~ N |
| M/G/1 | Pollaczek-Khinchine | exact |
| Slot queue | batch-arrival analysis | within 8% |
| Polar code | coding gain | BER < 0.3x uncoded at 3 dB |
| Determinism | same seed => identical telemetry | hash equality |
| Traceability | SINR from reported link-budget terms equals the simulator's SINR; latency parts sum to total | per-UE assertion |

The suite also found and fixed real defects during development (RandomWaypoint crossing buildings; handover retry storm after a failed execution; tagged-packet sampling bias in the delay estimator).
Known unvalidated areas: absorption line fit (only envelope-checked), RMa path loss (transcribed), spatial channel angular statistics (no measurement data), energy parameters.
