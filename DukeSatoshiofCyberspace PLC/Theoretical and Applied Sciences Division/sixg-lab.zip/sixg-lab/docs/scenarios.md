# Scenarios

`scenarios/urban_6g.yaml` (first scenario): 12 gNBs, 500 UEs (300 pedestrians + 200 vehicles), 140 GHz, 2 GHz, 4 panels x 8x8=64-element URA per gNB (codebook beams),
urban 620 x 520 m Manhattan grid, 3 edge servers, 60 s. `urban_140ghz_fixed_gain.yaml`: slice-1 baseline (fixed-gain antennas, 100 UEs, 10 s).
Layering: package defaults < `config/*.yaml` < scenario file < CLI overrides; unknown keys are errors. Experiment files (`examples/parameter_sweep.yaml`) sweep any dotted parameter
(plus `ue_count`, `antenna_count`) with replicates; results go to Parquet+JSON with provenance (commit, versions, seed, config hash).
Vertical slices: 1 fixed-gain chain; 2 arrays + beam selection (`examples/beamforming_gain.py`); 3 RIS (`examples/ris_gain.py`); 4 edge/XR (`examples/xr_offload.py`); 5 AI, 6 satellite, 7 ISAC: not built.
