"""python benchmarks/run_benchmarks.py  (same as `sixg benchmark`)"""
from sixglab.benchmark import run_benchmarks

if __name__ == "__main__":
    for k, v in run_benchmarks().items():
        print(f"{k:40s} {v * 1e3:10.3f} ms")
