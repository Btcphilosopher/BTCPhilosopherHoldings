import { useCallback, useEffect, useRef, useState } from "react";

/* eslint-disable @typescript-eslint/no-explicit-any */
export type Json = any;

export interface StaticInfo {
  title: string; scenario: string; simulation_id: string; extent: number[];
  buildings: number[][]; roads: number[][]; base_stations: number[][]; edge_servers: number[][];
  ue_kinds: string[]; ue_apps: string[]; carrier_hz: number; bandwidth_hz: number; path_loss_model: string;
  antenna_mode: string; panels: number; elements: number; duration_s: number; epoch_s: number; n_epochs: number;
  scheduler: string; slices: string[];
}
export interface Frame {
  epoch: number; t: number; metrics: Record<string, number>;
  ue: { x: number[]; y: number[]; z: number[]; serving: number[]; sinr: number[]; thr: number[]; lat: (number | null)[]; cqi: number[]; los: number[] };
  beams: number[][]; latency_breakdown_ms: Record<string, number | null>; bs_load: number[];
  events: Json[]; event_counts: Record<string, number>;
}

export async function jget<T = Json>(url: string): Promise<T> {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`${url}: ${r.status} ${await r.text()}`);
  return r.json();
}
export async function jpost<T = Json>(url: string, body?: Json): Promise<T> {
  const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  if (!r.ok) throw new Error(`${url}: ${r.status} ${await r.text()}`);
  return r.json();
}

export function useSimulation() {
  const [scenarios, setScenarios] = useState<Json[]>([]);
  const [simId, setSimId] = useState<string | null>(null);
  const [status, setStatus] = useState("idle");
  const [info, setInfo] = useState<StaticInfo | null>(null);
  const [frame, setFrame] = useState<Frame | null>(null);
  const [history, setHistory] = useState<Record<string, number>[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [summary, setSummary] = useState<Json | null>(null);
  const ws = useRef<WebSocket | null>(null);

  useEffect(() => { jget("/api/scenarios").then(setScenarios).catch((e) => setError(String(e))); }, []);

  const connect = useCallback((id: string) => {
    ws.current?.close();
    const proto = location.protocol === "https:" ? "wss" : "ws";
    const sock = new WebSocket(`${proto}://${location.host}/ws/simulation/${id}`);
    ws.current = sock;
    sock.onmessage = (ev) => {
      const m = JSON.parse(ev.data);
      if (m.type === "static") setInfo(m as StaticInfo);
      else if (m.type === "frame") {
        setFrame(m as Frame);
        setHistory((h) => [...h.slice(-899), m.metrics]);
      } else if (m.type === "status") { setStatus(m.status); setSummary(m.summary); if (m.error) setError(m.error); }
      else if (m.type === "error") setError(m.detail);
    };
    sock.onerror = () => setError("WebSocket error");
  }, []);

  const create = useCallback(async (scenario: string, mode: string, speed: number) => {
    setError(null); setHistory([]); setFrame(null); setSummary(null);
    try {
      const r = await jpost("/api/simulations", { scenario, mode, speed_factor: speed, autostart: true });
      setSimId(r.id); setStatus(r.status); connect(r.id);
    } catch (e) { setError(String(e)); }
  }, [connect]);

  const act = useCallback(async (verb: "start" | "pause" | "stop" | "step") => {
    if (!simId) return;
    try { const r = await jpost(`/api/simulations/${simId}/${verb}`); setStatus(r.status); if (verb === "start" && !ws.current) connect(simId); }
    catch (e) { setError(String(e)); }
  }, [simId, connect]);

  return { scenarios, simId, status, info, frame, history, error, summary, create, act };
}
