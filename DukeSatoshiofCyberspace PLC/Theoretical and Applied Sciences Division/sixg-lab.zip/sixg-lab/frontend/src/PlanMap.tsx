import { useEffect, useRef } from "react";
import type { Frame, StaticInfo } from "./api";

export const sinrColor = (s: number, cqi: number) => {
  if (cqi === 0) return "#b23a3a";
  const t = Math.max(0, Math.min(1, (s + 5) / 30));
  const r = Math.round(201 - 150 * t), g = Math.round(138 - 30 * t + 60 * t), b = Math.round(27 + 110 * t);
  return `rgb(${r},${g},${b})`;
};

export default function PlanMap({ info, frame, selected, onSelect, coverage }: {
  info: StaticInfo | null; frame: Frame | null; selected: number | null; onSelect: (i: number) => void;
  coverage: { sinr_db: number[][]; extent: number[] } | null;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  const view = useRef({ s: 1, ox: 0, oy: 0, h: 0 });

  useEffect(() => {
    const cv = ref.current; if (!cv || !info) return;
    const dpr = window.devicePixelRatio || 1;
    const w = cv.clientWidth, h = cv.clientHeight;
    cv.width = w * dpr; cv.height = h * dpr;
    const ctx = cv.getContext("2d")!; ctx.scale(dpr, dpr);
    const [x0, y0, x1, y1] = info.extent;
    const s = Math.min((w - 20) / (x1 - x0), (h - 20) / (y1 - y0));
    const ox = (w - s * (x1 - x0)) / 2, oy = (h - s * (y1 - y0)) / 2;
    view.current = { s, ox, oy, h };
    const X = (x: number) => ox + (x - x0) * s, Y = (y: number) => h - oy - (y - y0) * s;
    ctx.fillStyle = "#f7f8fa"; ctx.fillRect(0, 0, w, h);
    if (coverage) {
      const g = coverage.sinr_db, ny = g.length, nx = g[0].length;
      const [cx0, cy0, cx1, cy1] = coverage.extent;
      const cw = (cx1 - cx0) / nx, ch = (cy1 - cy0) / ny;
      for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
        const v = g[j][i]; const t = Math.max(0, Math.min(1, (v + 5) / 30));
        ctx.fillStyle = v < -5 ? "rgba(178,58,58,.25)" : `rgba(79,109,143,${0.08 + 0.55 * t})`;
        ctx.fillRect(X(cx0 + i * cw), Y(cy0 + (j + 1) * ch), cw * s + 0.6, ch * s + 0.6);
      }
    }
    ctx.strokeStyle = "#c5cad1"; ctx.lineWidth = Math.max(2, 20 * s * 0.5);
    for (const r of info.roads) { ctx.beginPath(); ctx.moveTo(X(r[0]), Y(r[1])); ctx.lineTo(X(r[2]), Y(r[3])); ctx.stroke(); }
    for (const b of info.buildings) {
      const t = Math.min(1, b[4] / 55); const v = Math.round(190 - 60 * t);
      ctx.fillStyle = `rgb(${v},${v + 3},${v + 8})`; ctx.fillRect(X(b[0]), Y(b[3]), (b[2] - b[0]) * s, (b[3] - b[1]) * s);
    }
    if (frame) {
      ctx.lineWidth = 0.6;
      for (const bm of frame.beams) {
        const b = info.base_stations[bm[0]], i = bm[1];
        ctx.strokeStyle = i === selected ? "rgba(20,33,61,.9)" : "rgba(79,109,143,.16)";
        ctx.beginPath(); ctx.moveTo(X(b[0]), Y(b[1])); ctx.lineTo(X(frame.ue.x[i]), Y(frame.ue.y[i])); ctx.stroke();
      }
      for (let i = 0; i < frame.ue.x.length; i++) {
        ctx.fillStyle = sinrColor(frame.ue.sinr[i], frame.ue.cqi[i]);
        ctx.beginPath(); ctx.arc(X(frame.ue.x[i]), Y(frame.ue.y[i]), i === selected ? 5 : 2.6, 0, 7); ctx.fill();
        if (i === selected) { ctx.strokeStyle = "#14213d"; ctx.lineWidth = 1.5; ctx.stroke(); }
      }
    }
    ctx.fillStyle = "#14213d";
    info.base_stations.forEach((b, k) => {
      ctx.fillRect(X(b[0]) - 5, Y(b[1]) - 5, 10, 10);
      ctx.fillStyle = "#fff"; ctx.font = "8px IBM Plex Mono, monospace"; ctx.fillText(String(k), X(b[0]) - 3, Y(b[1]) + 3); ctx.fillStyle = "#14213d";
    });
    ctx.strokeStyle = "#c98a1b"; ctx.lineWidth = 1.5;
    for (const e of info.edge_servers) { ctx.strokeRect(X(e[0]) - 8, Y(e[1]) - 8, 16, 16); }
  }, [info, frame, selected, coverage]);

  return <canvas ref={ref} onClick={(ev) => {
    if (!frame) return;
    const r = ref.current!.getBoundingClientRect(); const { s, ox, oy, h } = view.current;
    const [x0, y0] = info!.extent; const mx = (ev.clientX - r.left - ox) / s + x0, my = (h - (ev.clientY - r.top) - oy) / s + y0;
    let best = -1, bd = 15 * 15 / (s * s);
    frame.ue.x.forEach((x, i) => { const d = (x - mx) ** 2 + (frame.ue.y[i] - my) ** 2; if (d < bd) { bd = d; best = i; } });
    if (best >= 0) onSelect(best);
  }} />;
}
