import { useEffect, useRef } from "react";
import * as echarts from "echarts";

export default function EChart({ option, className = "chart" }: { option: echarts.EChartsOption; className?: string }) {
  const el = useRef<HTMLDivElement>(null);
  const chart = useRef<echarts.ECharts | null>(null);
  useEffect(() => {
    chart.current = echarts.init(el.current!);
    const onResize = () => chart.current?.resize();
    window.addEventListener("resize", onResize);
    return () => { window.removeEventListener("resize", onResize); chart.current?.dispose(); };
  }, []);
  useEffect(() => { chart.current?.setOption(option, true); }, [option]);
  return <div ref={el} className={className} />;
}

export const axisStyle = { axisLine: { lineStyle: { color: "#8a94a0" } }, axisLabel: { color: "#6b7480", fontSize: 10 }, splitLine: { lineStyle: { color: "#e6e9ed" } }, nameTextStyle: { color: "#6b7480", fontSize: 10 } };
export const baseOption = { animation: false, grid: { left: 46, right: 12, top: 26, bottom: 28 }, textStyle: { fontFamily: "IBM Plex Sans, sans-serif" } };
