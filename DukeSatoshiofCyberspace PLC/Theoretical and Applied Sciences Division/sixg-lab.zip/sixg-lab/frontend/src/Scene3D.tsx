import { useEffect, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import type { Frame, StaticInfo } from "./api";

/** Engineering-style 3D view. Beam lines are drawn from the simulation's beam list (serving gNB -> UE) with opacity
 *  proportional to the directional gain computed by the array model; nothing here is decorative. */
export default function Scene3D({ info, frame, selected }: { info: StaticInfo | null; frame: Frame | null; selected: number | null }) {
  const host = useRef<HTMLDivElement>(null);
  const three = useRef<{ scene: THREE.Scene; ues: THREE.InstancedMesh; beams: THREE.LineSegments; sel: THREE.Mesh; render: () => void } | null>(null);

  useEffect(() => {
    if (!info || !host.current) return;
    const el = host.current;
    const scene = new THREE.Scene(); scene.background = new THREE.Color("#f4f5f7");
    const [x0, y0, x1, y1] = info.extent; const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
    const camera = new THREE.PerspectiveCamera(45, el.clientWidth / el.clientHeight, 1, 5000);
    camera.up.set(0, 0, 1); camera.position.set(cx, y0 - (y1 - y0) * 0.55, 480); camera.lookAt(cx, cy, 0);
    const renderer = new THREE.WebGLRenderer({ antialias: true }); renderer.setSize(el.clientWidth, el.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio); el.innerHTML = ""; el.appendChild(renderer.domElement);
    const controls = new OrbitControls(camera, renderer.domElement); controls.target.set(cx, cy, 0); controls.update();
    scene.add(new THREE.HemisphereLight(0xffffff, 0x9aa3ae, 0.9));
    const sun = new THREE.DirectionalLight(0xffffff, 0.6); sun.position.set(300, -200, 500); scene.add(sun);
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(x1 - x0, y1 - y0), new THREE.MeshLambertMaterial({ color: 0xdfe3e8 }));
    ground.position.set(cx, cy, -0.1); scene.add(ground);
    const bm = new THREE.MeshLambertMaterial({ color: 0xaab2bd });
    for (const b of info.buildings) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(b[2] - b[0], b[3] - b[1], b[4]), bm);
      m.position.set((b[0] + b[2]) / 2, (b[1] + b[3]) / 2, b[4] / 2); scene.add(m);
    }
    const rp: number[] = []; for (const r of info.roads) rp.push(r[0], r[1], 0.2, r[2], r[3], 0.2);
    const rg = new THREE.BufferGeometry(); rg.setAttribute("position", new THREE.Float32BufferAttribute(rp, 3));
    scene.add(new THREE.LineSegments(rg, new THREE.LineBasicMaterial({ color: 0x8a94a0 })));
    const mast = new THREE.MeshLambertMaterial({ color: 0x14213d });
    for (const b of info.base_stations) {
      const m = new THREE.Mesh(new THREE.CylinderGeometry(1, 1.4, b[2], 8), mast); m.rotation.x = Math.PI / 2; m.position.set(b[0], b[1], b[2] / 2); scene.add(m);
      const p = new THREE.Mesh(new THREE.BoxGeometry(4, 4, 4), mast); p.position.set(b[0], b[1], b[2] + 2); scene.add(p);
    }
    for (const e of info.edge_servers) { const m = new THREE.Mesh(new THREE.BoxGeometry(9, 9, 5), new THREE.MeshLambertMaterial({ color: 0xc98a1b })); m.position.set(e[0], e[1], 2.5); scene.add(m); }
    const n = info.ue_kinds.length;
    const ues = new THREE.InstancedMesh(new THREE.SphereGeometry(2.2, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffffff }), n);
    ues.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(n * 3), 3); scene.add(ues);
    const beams = new THREE.LineSegments(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.55 })); scene.add(beams);
    const sel = new THREE.Mesh(new THREE.RingGeometry(5, 6.5, 24), new THREE.MeshBasicMaterial({ color: 0x14213d, side: THREE.DoubleSide })); sel.visible = false; scene.add(sel);
    let raf = 0; const loop = () => { raf = requestAnimationFrame(loop); controls.update(); renderer.render(scene, camera); }; loop();
    const onResize = () => { camera.aspect = el.clientWidth / el.clientHeight; camera.updateProjectionMatrix(); renderer.setSize(el.clientWidth, el.clientHeight); };
    window.addEventListener("resize", onResize);
    three.current = { scene, ues, beams, sel, render: () => renderer.render(scene, camera) };
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", onResize); renderer.dispose(); };
  }, [info]);

  useEffect(() => {
    const t = three.current; if (!t || !frame || !info) return;
    const m = new THREE.Matrix4(); const c = new THREE.Color();
    for (let i = 0; i < frame.ue.x.length; i++) {
      m.setPosition(frame.ue.x[i], frame.ue.y[i], frame.ue.z[i] + 1); t.ues.setMatrixAt(i, m);
      const s = frame.ue.sinr[i]; const k = Math.max(0, Math.min(1, (s + 5) / 30));
      if (frame.ue.cqi[i] === 0) c.set("#b23a3a"); else c.setRGB((201 - 150 * k) / 255, (138 + 30 * k) / 255, (27 + 110 * k) / 255);
      t.ues.setColorAt(i, c);
    }
    t.ues.instanceMatrix.needsUpdate = true; if (t.ues.instanceColor) t.ues.instanceColor.needsUpdate = true;
    const pos: number[] = [], col: number[] = [];
    let gmax = -1e9, gmin = 1e9; for (const b of frame.beams) { gmax = Math.max(gmax, b[2]); gmin = Math.min(gmin, b[2]); }
    for (const b of frame.beams) {
      const bs = info.base_stations[b[0]]; const u = b[1];
      pos.push(bs[0], bs[1], bs[2] + 3, frame.ue.x[u], frame.ue.y[u], frame.ue.z[u] + 1);
      const k = gmax > gmin ? (b[2] - gmin) / (gmax - gmin) : 1; const v = 0.35 + 0.65 * k;
      col.push(0.31 * v, 0.43 * v, 0.56 * v, 0.31 * v, 0.43 * v, 0.56 * v);
    }
    t.beams.geometry.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    t.beams.geometry.setAttribute("color", new THREE.Float32BufferAttribute(col, 3));
    if (selected !== null && selected < frame.ue.x.length) { t.sel.visible = true; t.sel.position.set(frame.ue.x[selected], frame.ue.y[selected], 0.5); } else t.sel.visible = false;
  }, [frame, info, selected]);

  return <div ref={host} style={{ width: "100%", height: "100%" }} />;
}
