import { useEffect, useMemo, useState } from "react";
import EChart, { axisStyle, baseOption } from "./EChart";
import PlanMap from "./PlanMap";
import Scene3D from "./Scene3D";
import { jget, useSimulation, Json } from "./api";

const fmtRate = (b: number) => (b >= 1e9 ? [b / 1e9, "Gb/s"] : b >= 1e6 ? [b / 1e6, "Mb/s"] : [b / 1e3, "kb/s"]) as [number, string];
const f = (v: number | null | undefined, d = 1) => (v === null || v === undefined || Number.isNaN(v) ? "–" : v.toFixed(d));
const TABS = ["RADIO", "CHANNEL", "AI", "EDGE", "ENERGY", "ISAC"] as const;

function Metric({ label, value, unit, cls = "" }: { label: string; value: string; unit: string; cls?: string }) {
  return <div className="metric"><div className="lbl">{label}</div><div className={`big ${cls}`}>{value}<span className="unit">{unit}</span></div></div>;
}

function Trace({ t }: { t: Json | null }) {
  if (!t) return <div className="note">Select a UE on the map to inspect exactly how its SINR, throughput and latency were produced.</div>;
  const cm = t.channel_model, s = t.sinr, la = t.link_adaptation, th = t.throughput;
  return (
    <div className="chain">
      <div><b>UE {t.ue}</b> · {t.kind} · {t.application} · t = {f(t.time_s, 1)} s</div>
      <h3>1 CONFIGURATION</h3>
      <div className="kv"><span>carrier / bandwidth</span><span>{f(t.configuration.carrier_frequency_hz / 1e9, 0)} GHz / {f(t.configuration.bandwidth_hz / 1e9, 1)} GHz</span>
        <span>Tx power / antennas</span><span>{f(t.configuration.transmit_power_w, 2)} W / {t.configuration.antenna_mode}</span></div>
      <h3>2 CHANNEL MODEL</h3>
      <div className="note" style={{ fontSize: 11 }}>{cm.path_loss_model}</div>
      <div className="kv"><span>serving cell / LoS</span><span>{cm.serving_cell} / {cm.los ? "LoS" : "NLoS"}</span><span>3D distance</span><span>{f(cm.distance_3d_m, 1)} m</span>
        {Object.entries(cm.path_loss_components_db).map(([k, v]) => [<span key={k}>{k}</span>, <span key={k + "v"}>{f(v as number, 1)} dB</span>])}
        <span>path loss (total)</span><span>{f(cm.path_loss_db, 1)} dB</span><span>shadowing</span><span>{f(cm.shadowing_db, 1)} dB</span></div>
      {cm.validity_note && <div className="warn" style={{ fontSize: 11 }}>⚠ {cm.validity_note}</div>}
      <h3>3 LINK BUDGET</h3>
      <table><tbody>{t.link_budget.map((r: Json) => <tr key={r.term}><td>{r.term}</td><td className="r">{f(r.value, 2)} {r.unit}</td></tr>)}</tbody></table>
      {t.beamforming && <><h3>4 BEAMFORMING</h3><div className="kv"><span>beamformer / panel</span><span>{t.beamforming.beamformer} / {t.beamforming.panel}</span><span>beam index / gain</span><span>{t.beamforming.beam_index} / {f(t.beamforming.beam_gain_db, 1)} dB</span></div></>}
      <h3>5 SINR</h3>
      <div className="kv"><span>signal / interference</span><span>{f(s.signal_dbm, 1)} / {f(s.interference_dbm, 1)} dBm</span><span>noise</span><span>{f(s.noise_dbm, 1)} dBm</span><span>SINR</span><span>{f(s.sinr_db, 2)} dB</span><span>fading margin (BLER target)</span><span>{f(s.fading_margin_db, 1)} dB</span></div>
      <h3>6 LINK ADAPTATION</h3>
      <div className="kv"><span>CQI / modulation</span><span>{la.cqi} / {la.modulation}</span><span>code rate / efficiency</span><span>{f(la.code_rate, 3)} / {f(la.spectral_efficiency_bps_hz, 3)}</span><span>threshold</span><span>{f(la.threshold_db, 1)} dB</span></div>
      <div className="note" style={{ fontSize: 10 }}>{la.model}</div>
      <h3>7 THROUGHPUT</h3>
      <div className="kv"><span>full-resource rate</span><span>{f(th.achievable_rate_bps / 1e6, 1)} Mb/s</span><span>scheduled time share</span><span>{f(th.time_share * 100, 1)} %</span><span>delivered / offered</span><span>{f(th.delivered_bps / 1e6, 1)} / {f(th.offered_bps / 1e6, 1)} Mb/s</span></div>
      <h3>8 LATENCY (MS)</h3>
      <div className="kv">{["radio", "queue", "transport", "edge", "application", "total"].map((k) => [<span key={k}>{k}</span>, <span key={k + "v"}>{f(t.latency_ms[k + "_ms"], 3)}</span>])}</div>
    </div>
  );
}

export default function App() {
  const sim = useSimulation();
  const [scenario, setScenario] = useState("urban_140ghz_fixed_gain");
  const [mode, setMode] = useState("accelerated");
  const [view, setView] = useState<"3D" | "2D">("2D");
  const [tab, setTab] = useState<(typeof TABS)[number]>("RADIO");
  const [research, setResearch] = useState(true);
  const [selected, setSelected] = useState<number | null>(null);
  const [trace, setTrace] = useState<Json | null>(null);
  const [chan, setChan] = useState<Json | null>(null);
  const [coverage, setCoverage] = useState<Json | null>(null);
  const { info, frame, history } = sim;

  useEffect(() => {
    if (selected === null || !sim.simId || !frame || frame.epoch % 3 !== 0) return;
    jget(`/api/ues/${selected}/trace?simulation_id=${sim.simId}`).then(setTrace).catch(() => {});
    if (tab === "CHANNEL") jget(`/api/channels?ue=${selected}&simulation_id=${sim.simId}`).then(setChan).catch(() => {});
  }, [selected, frame?.epoch, tab, sim.simId]);
  useEffect(() => { setTrace(null); setChan(null); setCoverage(null); setSelected(null); }, [sim.simId]);

  const m = frame?.metrics;
  const thr = m ? fmtRate(m.throughput_bps) : [NaN, "Gb/s"];
  const nUe = info?.ue_kinds.length ?? 0;
  const kinds = useMemo(() => { const c: Record<string, number> = {}; info?.ue_kinds.forEach((k) => (c[k] = (c[k] ?? 0) + 1)); return c; }, [info]);
  const faults = useMemo(() => {
    const out: string[] = [];
    if (!frame || !m) return out;
    frame.bs_load.forEach((l, i) => { if (l > 0.9) out.push(`Cell ${i} saturated (${f(l * 100, 0)} % airtime)`); });
    if (m.coverage_fraction < 0.6) out.push(`Coverage ${f(m.coverage_fraction * 100, 0)} % of UEs`);
    if (m.loss_ratio > 0.01) out.push(`Congestion loss ${f(m.loss_ratio * 100, 1)} %`);
    if (m.edge_utilisation > 0.8) out.push(`Edge utilisation ${f(m.edge_utilisation * 100, 0)} %`);
    return out;
  }, [frame, m]);
  const t = history.map((h) => h.t_s);
  const line = (name: string, key: string, scale = 1, color = "#4f6d8f") => ({ name, type: "line" as const, showSymbol: false, data: history.map((h) => h[key] / scale), lineStyle: { color, width: 1.5 }, itemStyle: { color } });
  const tsOpt = (series: object[], yname: string) => ({ ...baseOption, tooltip: { trigger: "axis" as const }, xAxis: { type: "category" as const, data: t.map((v) => v.toFixed(1)), ...axisStyle, name: "t [s]" }, yAxis: { type: "value" as const, name: yname, ...axisStyle, scale: true }, series, legend: { top: 0, textStyle: { fontSize: 10, color: "#6b7480" } } });

  const sinrHist = useMemo(() => {
    if (!frame) return null; const bins = Array.from({ length: 16 }, (_, i) => -10 + i * 3); const cnt = bins.map(() => 0);
    frame.ue.sinr.forEach((s) => { const k = Math.min(bins.length - 1, Math.max(0, Math.floor((s + 10) / 3))); cnt[k]++; });
    return { ...baseOption, xAxis: { type: "category" as const, data: bins.map((b) => `${b}`), name: "SINR [dB]", ...axisStyle }, yAxis: { type: "value" as const, name: "UEs", ...axisStyle }, series: [{ type: "bar" as const, data: cnt, itemStyle: { color: "#4f6d8f" } }] };
  }, [frame]);
  const cqiHist = useMemo(() => {
    if (!frame) return null; const cnt = Array(16).fill(0); frame.ue.cqi.forEach((c) => cnt[c]++);
    return { ...baseOption, xAxis: { type: "category" as const, data: cnt.map((_, i) => `${i}`), name: "CQI (0 = outage)", ...axisStyle }, yAxis: { type: "value" as const, name: "UEs", ...axisStyle }, series: [{ type: "bar" as const, data: cnt.map((v, i) => ({ value: v, itemStyle: { color: i === 0 ? "#b23a3a" : "#8a94a0" } })) }] };
  }, [frame]);
  const latBar = useMemo(() => {
    const b = frame?.latency_breakdown_ms; if (!b) return null; const names = ["radio", "queue", "transport", "edge", "application"]; const cols = ["#14213d", "#4f6d8f", "#8a94a0", "#c98a1b", "#b8bfc8"];
    return { ...baseOption, grid: { left: 60, right: 12, top: 26, bottom: 28 }, tooltip: {}, xAxis: { type: "value" as const, name: "mean ms", ...axisStyle }, yAxis: { type: "category" as const, data: ["end-to-end"], ...axisStyle }, legend: { top: 0, textStyle: { fontSize: 10, color: "#6b7480" } }, series: names.map((n, i) => ({ name: n, type: "bar" as const, stack: "l", data: [b[n] ?? 0], itemStyle: { color: cols[i] } })) };
  }, [frame]);
  const beamOpt = chan?.beam_pattern ? { ...baseOption, grid: { left: 46, right: 12, top: 26, bottom: 30 }, xAxis: { type: "value" as const, name: "azimuth [deg]", min: -90, max: 90, ...axisStyle }, yAxis: { type: "value" as const, name: "gain [dBi]", min: -10, ...axisStyle }, series: [{ type: "line" as const, showSymbol: false, data: chan.beam_pattern.azimuth_deg.map((a: number, i: number) => [a, chan.beam_pattern.gain_dbi[i]]), lineStyle: { color: "#14213d" } }] } : null;

  const running = sim.status === "running";
  const loadCoverage = () => sim.simId && jget(`/api/coverage?simulation_id=${sim.simId}&resolution_m=10`).then(setCoverage).catch(() => {});

  return (
    <div className="app">
      <header>
        <div><h1>6G DIGITAL TWIN LAB</h1><div className="sub">AI-NATIVE WIRELESS SYSTEMS SIMULATION</div></div>
        <div className="spacer" />
        <div className="controls">
          <select value={scenario} onChange={(e) => setScenario(e.target.value)}>{sim.scenarios.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
          <select value={mode} onChange={(e) => setMode(e.target.value)}><option value="accelerated">accelerated</option><option value="batch">batch</option><option value="real_time">real time</option></select>
          <button className="primary" onClick={() => sim.create(scenario, mode, 4)}>RUN NEW</button>
          <button disabled={!sim.simId || running} onClick={() => sim.act("start")}>RESUME</button>
          <button disabled={!running} onClick={() => sim.act("pause")}>PAUSE</button>
          <button disabled={!sim.simId} onClick={() => sim.act("stop")}>STOP</button>
          <div className="seg"><button className={research ? "on" : ""} onClick={() => setResearch(true)}>RESEARCH</button><button className={!research ? "on" : ""} onClick={() => setResearch(false)}>OPERATIONS</button></div>
          <span className="status">{sim.status.toUpperCase()}{frame ? ` · ${f(frame.t, 1)} / ${info?.duration_s} s` : ""}</span>
        </div>
      </header>
      <main>
        <div className="col">
          <div className="panel"><h2>Network</h2>
            <div className="kv"><span>cells</span><span>{info?.base_stations.length ?? "–"}</span><span>UEs</span><span>{nUe || "–"}</span><span>edge nodes</span><span>{info?.edge_servers.length ?? "–"}</span><span>slices (traffic classes)</span><span>{info?.slices.join(" ") ?? "–"}</span>
              <span>carrier</span><span>{info ? f(info.carrier_hz / 1e9, 0) : "–"} GHz</span><span>bandwidth</span><span>{info ? f(info.bandwidth_hz / 1e9, 1) : "–"} GHz</span><span>antenna</span><span>{info?.antenna_mode ?? "–"}{info?.antenna_mode === "array" ? ` ${info.elements}×${info.panels}` : ""}</span><span>scheduler</span><span>{info?.scheduler ?? "–"}</span></div>
            <div style={{ marginTop: 8 }} className="kv">{Object.entries(kinds).map(([k, v]) => [<span key={k}>{k}</span>, <span key={k + "v"}>{v}</span>])}</div>
          </div>
          <div className="panel" style={{ flex: 1, overflow: "auto" }}><h2>What changed</h2>
            <div className="events">{frame?.events.slice().reverse().map((e, i) => <div key={i}>{f(e.t, 1)}s {e.type}{e.ue !== undefined ? ` ue${e.ue}` : ""}{e.target_cell !== undefined ? ` ${e.source_cell}→${e.target_cell}${e.success ? "" : " FAILED"}` : ""}</div>) ?? "waiting for events"}</div>
            {frame && <div className="kv" style={{ marginTop: 8 }}>{Object.entries(frame.event_counts).map(([k, v]) => [<span key={k}>{k}</span>, <span key={k + "v"}>{v}</span>])}</div>}
          </div>
        </div>
        <div className="col">
          <div className="panel stage">
            <div className="tools seg"><button className={view === "2D" ? "on" : ""} onClick={() => setView("2D")}>2D MAP</button><button className={view === "3D" ? "on" : ""} onClick={() => setView("3D")}>3D NETWORK</button>
              <button onClick={loadCoverage} disabled={!sim.simId || !frame}>SINR COVERAGE</button>{coverage && <button onClick={() => setCoverage(null)}>CLEAR</button>}</div>
            {view === "2D" ? <PlanMap info={info} frame={frame} selected={selected} onSelect={setSelected} coverage={coverage} /> : <Scene3D info={info} frame={frame} selected={selected} />}
            <div className="legend">UE colour = SINR (red = outage) · squares = gNB · amber = edge · lines = serving beams{coverage ? " · shading = median SINR (from the same link model)" : ""}</div>
            {!info && <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center" }} className="note">Choose a scenario and press RUN NEW.{sim.error && <div className="bad">{sim.error}</div>}</div>}
          </div>
        </div>
        <div className="col">
          <div className="panel"><h2>{research ? "Live metrics" : "Network operations"}</h2>
            <Metric label="THROUGHPUT" value={f(thr[0] as number, 2)} unit={thr[1] as string} />
            <Metric label="LATENCY P95" value={f(m?.latency_p95_ms, 2)} unit="ms" cls={m && m.latency_p95_ms > 20 ? "warn" : ""} />
            <Metric label="ENERGY" value={f(m ? m.power_w / 1e3 : NaN, 2)} unit="kW" />
            {research && <Metric label="MEAN SINR" value={f(m?.mean_sinr_db, 1)} unit="dB" />}
            <Metric label="COVERAGE" value={f(m ? m.coverage_fraction * 100 : NaN, 0)} unit="% of UEs" cls={m && m.coverage_fraction < 0.6 ? "warn" : ""} />
            <Metric label="NETWORK LOAD" value={f(m ? m.network_load * 100 : NaN, 0)} unit="% airtime" />
            {!research && <div style={{ marginTop: 8 }}><h2>Faults</h2>{faults.length ? faults.map((x, i) => <div key={i} className="warn">⚠ {x}</div>) : <div className="note">none</div>}</div>}
          </div>
          {research && <div className="panel" style={{ flex: 1, overflow: "auto" }}><h2>Why · traceability</h2><Trace t={trace} /></div>}
        </div>
      </main>
      <div>
        <div className="tabs">{TABS.map((x) => <button key={x} className={tab === x ? "on" : ""} onClick={() => setTab(x)}>{x}</button>)}</div>
        <div className="drawer">
          {tab === "RADIO" && <>{sinrHist && <EChart option={sinrHist} />}{cqiHist && <EChart option={cqiHist} />}<EChart option={tsOpt([line("delivered", "throughput_bps", 1e9), line("offered", "offered_bps", 1e9, "#8a94a0")], "Gb/s")} /></>}
          {tab === "CHANNEL" && <><div className="chain">{chan ? <table><thead><tr><th>cell</th><th>d [m]</th><th>LoS</th><th>PL [dB]</th><th>shadow</th><th>RSRP [dBm]</th></tr></thead><tbody>{chan.cells.map((c: Json) => <tr key={c.cell} style={c.cell === chan.serving_cell ? { background: "#e6eaf0" } : {}}><td>{c.cell}</td><td>{f(c.distance_m, 0)}</td><td>{c.los ? "LoS" : "NLoS"}</td><td>{f(c.path_loss_db, 1)}</td><td>{f(c.shadowing_db, 1)}</td><td>{f(c.rsrp_dbm, 1)}</td></tr>)}</tbody></table> : <div className="note">Select a UE on the map (research mode) to see its channel to every cell.</div>}</div>
            {beamOpt ? <EChart option={beamOpt} /> : <div className="note">Beam pattern (from the actual beamforming weights) is available in array antenna mode.</div>}</>}
          {tab === "AI" && <div className="note" style={{ gridColumn: "1/-1" }}>AI-native control is not built in this release. When it is, this tab will list each model with its dataset, features, target, metric and training version, and every optimisation as before → objective → constraints → decision → after. No prediction is shown here because none is computed.</div>}
          {tab === "EDGE" && <>{latBar && <EChart option={latBar} />}<EChart option={tsOpt([line("edge utilisation", "edge_utilisation", 0.01), line("P95 latency [ms]", "latency_p95_ms", 1, "#c98a1b")], "% / ms")} /></>}
          {tab === "ENERGY" && <><EChart option={tsOpt([line("network power", "power_w", 1e3)], "kW")} /><div className="note">Model: gNB = (static + chains·P_chain + P_tx·activity/η_PA)·(1+cooling); edge linear in utilisation; UE receive power constant. Parameters are scenario inputs. {sim.summary && `Run total: ${f(sim.summary.energy_wh, 2)} Wh, ${f(sim.summary.wh_per_gb, 3)} Wh/GB.`}</div></>}
          {tab === "ISAC" && <div className="note" style={{ gridColumn: "1/-1" }}>ISAC (range / Doppler / angle estimation) is not built in this release; nothing is simulated or displayed for it.</div>}
        </div>
      </div>
    </div>
  );
}
