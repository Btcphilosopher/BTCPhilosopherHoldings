# Frontend (React + TypeScript + Three.js + ECharts)

`npm install && npm run build` (runs `tsc --noEmit` then `vite build`) -> `dist/`, served by the FastAPI app at `/`.
Dev: `npm run dev` (proxies `/api` and `/ws` to :8000).
Views: 2D plan map (canvas; click a UE to open its traceability chain), 3D network (Three.js; beams are drawn from the simulation's beam list, opacity = computed gain),
SINR coverage overlay from `/api/coverage` (same link model as the UEs), RADIO / CHANNEL / EDGE / ENERGY tabs (ECharts), RESEARCH vs OPERATIONS mode.
AI and ISAC tabs state that those modules are not built. MapLibre is not used yet (the city is a local metric frame, not geo-referenced).
