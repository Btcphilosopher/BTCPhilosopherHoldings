Run artefacts (`data/runs/<id>/`: metrics.parquet, ue_frames.npz, summary.json, scenario.json, report.*) and
experiment outputs (`data/experiments/<id>/`) are written here. Static datasets for future ML work go under `data/datasets/`.
