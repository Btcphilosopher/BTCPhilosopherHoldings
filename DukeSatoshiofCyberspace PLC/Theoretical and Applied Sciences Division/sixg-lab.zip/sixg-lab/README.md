# sixg-lab — 6G DIGITAL TWIN LAB
*AI-NATIVE WIRELESS SYSTEMS SIMULATION* — a Python computational laboratory for 6G radio / network digital-twin research.

Status: **first three-and-a-half vertical slices are built and executable**; the rest of the brief is scaffolded and honestly marked (see [Scope](#scope--what-is-and-is-not-built)).
Every reported number comes from an equation, a simulation or a measurement in this repository; nothing is decorative.

## Quick start
```bash
pip install -e ".[dev]"          # Python 3.12+
sixg validate                     # 15 analytical physics checks
python -m sixglab                 # runs scenarios/urban_6g.yaml for 10 s (a bare `sixg` does the same)
sixg simulate scenarios/urban_6g.yaml          # full 60 s scenario: 12 gNBs, 500 UEs, 140 GHz, 2 GHz, 64-element arrays
uvicorn sixglab.api.main:app --reload          # REST + WebSocket + dashboard at http://localhost:8000
pytest                            # 123 tests
```
The dashboard is pre-built in `frontend/dist`; rebuild with `make frontend` (needs Node 20). Docker: `docker compose up --build`.

## Result of the first scenario (seed 42, 60 s simulated, this repository at delivery)
```
Scenario: Urban 140 GHz
Seed: 42

Base Stations: 12
UEs: 500
Bandwidth: 2 GHz
Carrier: 140 GHz
Antenna mode: array (8x8 per panel, 4 panels)
Path loss: Reduced-Order THz Propagation Model

Simulation time: 60 s

Mean SINR: 8.85 dB  (median 14.45 dB, coverage 73.8%)
Mean Throughput: 6.08 Gb/s  (offered 6.09 Gb/s, per UE 12.17 Mb/s)
P95 Latency: 1.31 ms  (P50 1.06 ms, P99 13.09 ms)
Energy: 101.45 Wh  (mean 6.09 kW, 2.223 Wh/GB, 1000.4 nJ/bit)
Handovers: 7209 attempts, 1504 failed, 1548 ping-pong
Blocked traffic (outage): 27.0%   Congestion loss: 0.01%
Run id: 84a117f83839   (wall time 151.6 s)
Saved: data/runs/84a117f83839

Simulation complete.
```
Reproducible: same seed + config gives bit-identical telemetry (tested). Each run stores commit, Python/package versions, seed and config hash.

## Traceability (the main requirement)
`GET /api/ues/{id}/trace` (and the "Why" panel in the dashboard) returns for any UE
`configuration -> channel model (LoS/NLoS, path-loss components, model id, validity note) -> link budget -> beamforming -> SINR (signal/interference/noise)
-> CQI/MCS -> scheduled airtime -> throughput -> latency = radio + queue + transport + edge + application`.
A test asserts that SINR recomputed from the reported link-budget terms equals the simulator's SINR and that the latency parts sum to the total.

## Vertical slices — measured results
| Slice | What | Measured (seeded, from `examples/`) |
|---|---|---|
| 1 | 12 gNBs, mobility, 140 GHz channel, path loss, noise, SINR, throughput, telemetry, FastAPI, WebSocket, dashboard | see result above; 100-UE fixed-gain baseline in `scenarios/urban_140ghz_fixed_gain.yaml` |
| 2 | 64-element arrays, MRT/codebook beam selection, 3D beams | median SINR -3.5 dB (1 element) → 12.7 dB (codebook) → 13.7 dB (ideal-CSI MRT); coverage 33% → 73% → 85% |
| 3 | RIS + phase optimisation | RIS obeys N² scaling exactly (tested). On the 3 weak UEs that can see the best façade site, a 128×128 panel (~14 cm) raises received power −73.3 → −70.7 dBm (SINR −2.5 → +0.2 dB); 16×16 and 64×64 give <1 dB. Modest by design of this geometry — reported as measured |
| 4 | Edge server + XR workload | XR frame budget 20 ms: local 30 ms (0% within budget), edge median 1.8 ms (80.8% of connected UEs), cloud 21.4 ms (0%); illustrative capacities, see docs/edge.md |
| 5 | AI prediction + resource allocation | **not built** |
| 6 | Satellite + terrestrial + handover | **not built** |
| 7 | ISAC | **not built** |

## Scope — what is and is not built
Implemented: config/clock/events/RNG/logging/provenance; radio environment with geometric LoS; FSPL, 3GPP UMa/UMi/InH/RMa, Reduced-Order THz model; thermal noise; link budget;
OFDM, QAM, a real Polar code, gap-to-Shannon link adaptation; Rayleigh/Rician/Nakagami + shadowing + spatial array channel; MIMO, MRT/ZF/MMSE, beam manager; all mobility models;
A3 handover; slot-level RR/PF/MaxT scheduler with measured latency; transport graph; edge M/G/1; energy; RIS; telemetry (Parquet/NPZ/JSON); reports (HTML/PDF/JSON/Parquet);
experiments, parameter sweeps, Monte Carlo (multiprocessing); CLI; REST + WebSocket; React/TypeScript/Three.js/ECharts dashboard; 123 tests, ruff and mypy clean, CI workflow.

**Not implemented (placeholders only, clearly labelled in their `__init__.py`):** satellites/NTN, UAV base stations (UAV *mobility* exists), ISAC, semantic communications, cell-free massive MIMO,
network slicing orchestrator (traffic classes carry a slice label but resources are not sliced), AI/ML prediction, RL, Pareto/multi-objective optimiser, LDPC, spectrum manager,
PostgreSQL/PostGIS/TimescaleDB/MinIO backends (runs are stored as files), MapLibre map, geospatial layer (GeoPandas/Shapely/PyProj), Numba/JAX/GPU kernels (profile first), latency map and beam-map views.

## Honest model limits (details in `docs/`)
* Above 100 GHz the 3GPP-derived large-scale term is **extrapolated**; molecular absorption is a **coarse fit** to ITU-R P.676 (factor ~2), not line-by-line; no rain/fog/foliage; no ray tracing.
* Link adaptation is a **gap-to-Shannon abstraction**; the Polar code is real but not used per block by the system simulator; LDPC is absent.
* Spatial channel = Gaussian-angle multi-cluster (not CDL/TDL); one realisation per 100 ms epoch in array mode.
* Latency has 1 ms resolution (slot); sub-slot URLLC needs mini-slots. Uplink is not simulated in the system model (only in the offload helper, SNR-limited).
* The dashboard was type-checked and built and its API/WebSocket contract is tested, but it was **not visually inspected in a browser** in the delivery environment. Please look at it and report layout problems.
* Energy/edge/traffic parameters are scenario inputs, not measurements.
* The first scenario shows heavy handover churn (7209 attempts, 1504 failed, 1548 ping-pong in 60 s for 500 UEs): at 140 GHz, LoS/NLoS flips swing RSRP by tens of dB between cells. Hysteresis 3 dB / TTT 200 ms are untuned defaults - treat mobility conclusions accordingly and sweep them (`network.handover.*`).
* 27% of UEs are in coverage outage in that scenario (their traffic is reported as *blocked*, separately from congestion loss); that is a property of 12 street-level gNBs at 140 GHz in a building-dense canyon, not a fault.

## Layout
`sixglab/` package (`core, config, radio, channel, mimo, beamforming, mobility, network, edge, energy, ris, telemetry, storage, visualisation, scenarios, digital_twin, api`; placeholders for the rest) ·
`frontend/` (Vite + React + TS) · `scenarios/` · `config/` · `tests/` · `benchmarks/` · `examples/` · `docs/` (architecture, radio_models, channel_models, mimo, beamforming, network, edge, AI, scenarios, validation).

## CLI
`sixg simulate scenario.yaml [--duration S --seed N]` · `sixg run experiments.yaml [--workers N]` · `sixg replay <id>` · `sixg report <id>` · `sixg benchmark` · `sixg validate`.
Example sweep: `sixg run examples/parameter_sweep.yaml --workers 2`.
