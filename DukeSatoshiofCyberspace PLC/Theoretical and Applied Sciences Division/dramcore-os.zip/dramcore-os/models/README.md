Reserved for saved/calibrated models (spec section 102).
