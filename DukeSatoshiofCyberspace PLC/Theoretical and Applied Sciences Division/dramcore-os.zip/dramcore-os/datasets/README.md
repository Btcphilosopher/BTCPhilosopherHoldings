Reserved for imported/generated datasets (spec section 102).
