"""
dramcore.controller.simulation

High-level orchestrator tying device + controller + workload together
into a single ``Simulation.run()`` call, matching the Python API sketch
in spec section 86.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from dramcore.address_mapping.mapper import AddressMapper, InterleavingPolicy
from dramcore.channel.topology import MemoryTopology
from dramcore.controller.controller import MemoryController, PagePolicy
from dramcore.controller.request import MemoryRequest
from dramcore.core.clock import EventLog, SimulationClock
from dramcore.core.reproducibility import ReproducibilityRecord
from dramcore.core.result import EngineeringResult
from dramcore.device.dram_device import DRAMDevice
from dramcore.performance.engine import (
    analyse_bottleneck, compute_bandwidth_gbps, compute_latency_stats,
    detect_saturation, row_hit_rate,
)
from dramcore.power.engine import PowerEngine
from dramcore.refresh.engine import RefreshEngine
from dramcore.refresh.profile import RefreshProfile
from dramcore.scheduler.scheduler import BaseScheduler, SchedulerPolicy, make_scheduler
from dramcore.thermal.engine import ThermalModel
from dramcore.timing.engine import TimingEngine


@dataclass
class SimulationResult:
    n_requests: int
    elapsed_ns: float
    bandwidth: EngineeringResult
    latency: EngineeringResult
    power: EngineeringResult
    row_hit_rate: EngineeringResult
    refresh_overhead: dict
    bottleneck: object
    reproducibility: ReproducibilityRecord
    requests: List[MemoryRequest] = field(default_factory=list, repr=False)

    def summary(self) -> dict:
        return {
            "n_requests": self.n_requests,
            "elapsed_ns": self.elapsed_ns,
            "bandwidth_gbps": self.bandwidth.value,
            "latency_ns": self.latency.value,
            "power_mw": self.power.value,
            "row_hit_rate": self.row_hit_rate.value,
            "refresh_overhead": self.refresh_overhead,
            "bottleneck": self.bottleneck.bottleneck.value if self.bottleneck else None,
        }


@dataclass
class Simulation:
    device: DRAMDevice
    n_channels: int = 2
    n_ranks_per_channel: int = 1
    devices_per_rank: int = 1
    scheduler_policy: SchedulerPolicy = SchedulerPolicy.FR_FCFS
    page_policy: PagePolicy = PagePolicy.OPEN_PAGE
    interleaving: InterleavingPolicy = InterleavingPolicy.CACHE_LINE_AWARE
    queue_depth: int = 128
    seed: Optional[int] = None

    topology: MemoryTopology = field(init=False)
    controller: MemoryController = field(init=False)
    clock: SimulationClock = field(init=False)
    event_log: EventLog = field(init=False)

    def __post_init__(self):
        self.topology = MemoryTopology(
            device_template=self.device, n_channels=self.n_channels,
            n_ranks_per_channel=self.n_ranks_per_channel,
            devices_per_rank=self.devices_per_rank,
        )
        mapper = AddressMapper(device=self.device, n_channels=self.n_channels,
                                n_ranks=self.n_ranks_per_channel, policy=self.interleaving)
        timing_engine = TimingEngine(timing=self.device.timing_profile)
        refresh_engine = RefreshEngine(profile=self.device.refresh_profile,
                                        timing_engine=timing_engine)
        scheduler = make_scheduler(self.scheduler_policy)
        self.clock = SimulationClock()
        self.event_log = EventLog()
        self.controller = MemoryController(
            topology=self.topology, mapper=mapper, timing_engine=timing_engine,
            refresh_engine=refresh_engine, scheduler=scheduler, clock=self.clock,
            event_log=self.event_log, page_policy=self.page_policy,
            queue_depth=self.queue_depth,
        )

    def run(self, requests: List[MemoryRequest]) -> SimulationResult:
        completed = self.controller.run(requests)
        first_arrival = min((r.arrival_time_ns for r in completed), default=0.0)
        last_completion = max((r.completion_time_ns for r in completed
                               if r.completion_time_ns is not None), default=0.0)
        elapsed_ns = max(1e-9, last_completion - first_arrival)

        bw_result = compute_bandwidth_gbps(completed, elapsed_ns)
        lat_result = compute_latency_stats(completed)
        hit_rate_result = row_hit_rate(self.topology)

        n_act = sum(b.activation_count for _, _, b in self.topology.all_banks())
        n_reads = sum(1 for r in completed if r.operation.value == "READ")
        n_writes = sum(1 for r in completed if r.operation.value == "WRITE")
        n_refresh = sum(self.controller.refresh_engine.refresh_count.values())
        total_bytes = sum(r.size_bytes for r in completed)

        power_engine = PowerEngine(power_profile=self.device.power_profile,
                                    timing_profile=self.device.timing_profile)
        power_result = power_engine.compute(
            n_activations=n_act, n_reads=n_reads, n_writes=n_writes,
            n_refreshes=n_refresh, total_elapsed_ns=elapsed_ns,
            total_bytes_transferred=total_bytes,
            achieved_bandwidth_gbps=bw_result.value,
        )

        refresh_overhead = {
            rank_id: self.controller.refresh_engine.refresh_overhead(rank_id, elapsed_ns).value
            for rank_id in self.controller.refresh_engine.next_refresh_due_ns
        }
        max_refresh_overhead = max(refresh_overhead.values()) if refresh_overhead else 0.0

        theoretical_bw = self.topology.total_theoretical_bandwidth_gbps()
        saturation = detect_saturation(completed, bw_result.value, theoretical_bw)
        lat_table = lat_result.value
        bottleneck = analyse_bottleneck(
            row_hit_rate_value=hit_rate_result.value,
            refresh_overhead_fraction=max_refresh_overhead,
            bandwidth_saturation_ratio=(bw_result.value / theoretical_bw if theoretical_bw else 0),
            p99_latency_ns=lat_table.get("p99", 0.0),
            mean_latency_ns=lat_table.get("mean", 0.0),
        )

        repro = ReproducibilityRecord(
            configuration={
                "device_id": self.device.device_id, "n_channels": self.n_channels,
                "n_ranks_per_channel": self.n_ranks_per_channel,
                "scheduler_policy": self.scheduler_policy.value,
                "page_policy": self.page_policy.value,
                "interleaving": self.interleaving.value,
                "queue_depth": self.queue_depth,
            },
            random_seed=self.seed,
        )

        return SimulationResult(
            n_requests=len(completed), elapsed_ns=elapsed_ns,
            bandwidth=bw_result, latency=lat_result, power=power_result,
            row_hit_rate=hit_rate_result, refresh_overhead=refresh_overhead,
            bottleneck=bottleneck, reproducibility=repro, requests=completed,
        )
