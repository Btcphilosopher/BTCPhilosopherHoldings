"""
dramcore.controller.request

Memory request model (spec section 17).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class RequestOperation(str, Enum):
    READ = "READ"
    WRITE = "WRITE"
    ATOMIC = "ATOMIC"
    PREFETCH = "PREFETCH"
    REFRESH = "REFRESH"


class RequestState(str, Enum):
    ARRIVED = "ARRIVED"
    QUEUED = "QUEUED"
    IN_SERVICE = "IN_SERVICE"
    COMPLETED = "COMPLETED"
    DROPPED = "DROPPED"


@dataclass
class MemoryRequest:
    request_id: int
    timestamp_ns: float          # arrival time
    address: int
    size_bytes: int
    operation: RequestOperation
    source: str = "unknown"
    priority: int = 0
    deadline_ns: Optional[float] = None

    # Filled in by address mapper
    channel: Optional[int] = None
    rank: Optional[int] = None
    bank_group: Optional[int] = None
    bank: Optional[int] = None
    row: Optional[int] = None
    column: Optional[int] = None
    burst_length: int = 16

    # Lifecycle timestamps
    arrival_time_ns: Optional[float] = None
    queued_time_ns: Optional[float] = None
    service_start_ns: Optional[float] = None
    completion_time_ns: Optional[float] = None
    state: RequestState = RequestState.ARRIVED

    def __post_init__(self):
        if self.arrival_time_ns is None:
            self.arrival_time_ns = self.timestamp_ns

    def total_latency_ns(self) -> Optional[float]:
        if self.completion_time_ns is None:
            return None
        return self.completion_time_ns - self.arrival_time_ns

    def queue_latency_ns(self) -> Optional[float]:
        if self.service_start_ns is None:
            return None
        return self.service_start_ns - self.arrival_time_ns

    def service_latency_ns(self) -> Optional[float]:
        if self.completion_time_ns is None or self.service_start_ns is None:
            return None
        return self.completion_time_ns - self.service_start_ns

    def is_past_deadline(self, now_ns: float) -> bool:
        return self.deadline_ns is not None and now_ns > self.deadline_ns
