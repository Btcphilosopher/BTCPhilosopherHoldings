"""
dramcore.controller.controller

The memory controller (spec section 22) drives every request through the
explicit command state machine (spec section 19):

    REQUEST -> ADDRESS DECODE -> BANK CHECK -> ROW CHECK ->
    ACTIVATE IF REQUIRED -> WAIT TIMING -> READ/WRITE -> DATA TRANSFER ->
    PRECHARGE IF REQUIRED -> COMPLETE

All timing decisions are delegated to ``TimingEngine`` (authoritative --
spec section 21). The controller additionally tracks per-channel command-
bus and data-bus occupancy so that bus contention (spec section 42) is a
real, measurable effect rather than an assumed constant.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

from dramcore.address_mapping.mapper import AddressMapper
from dramcore.bank.bank import BankState
from dramcore.channel.topology import MemoryTopology
from dramcore.commands.command import CommandType, DRAMCommand
from dramcore.controller.request import MemoryRequest, RequestOperation, RequestState
from dramcore.core.clock import EventLog, EventType, SimulationClock
from dramcore.core.result import InvalidConfigurationError
from dramcore.refresh.engine import RefreshEngine
from dramcore.scheduler.scheduler import BaseScheduler


class PagePolicy(str, Enum):
    OPEN_PAGE = "OPEN_PAGE"      # leave row open after access (bet on future row hits)
    CLOSE_PAGE = "CLOSE_PAGE"    # auto-precharge immediately after access


COMMAND_ISSUE_CYCLES = 1  # one command per command-bus cycle, standard DDR assumption


@dataclass
class MemoryController:
    topology: MemoryTopology
    mapper: AddressMapper
    timing_engine: object  # dramcore.timing.engine.TimingEngine
    refresh_engine: RefreshEngine
    scheduler: BaseScheduler
    clock: SimulationClock
    event_log: EventLog
    page_policy: PagePolicy = PagePolicy.OPEN_PAGE
    queue_depth: int = 128

    _command_bus_free_at: Dict[int, float] = field(default_factory=dict)
    _data_bus_free_at: Dict[int, float] = field(default_factory=dict)
    _last_completion_time_ns: float = 0.0
    _completed_requests: List[MemoryRequest] = field(default_factory=list)
    _dropped_requests: List[MemoryRequest] = field(default_factory=list)
    _command_count: int = 0

    def __post_init__(self):
        for ch_id in self.topology.channels:
            self._command_bus_free_at[ch_id] = 0.0
            self._data_bus_free_at[ch_id] = 0.0
        for ch in self.topology.channels.values():
            for rank in ch.ranks.values():
                self.refresh_engine.register_rank(rank.rank_id)

    @property
    def clock_period_ns(self) -> float:
        return self.topology.device_template.clock_period_ns

    def _bank_and_group(self, req: MemoryRequest):
        ch = self.topology.channels[req.channel]
        rank = ch.ranks[req.rank]
        bank = rank.banks[req.bank]
        bank_group = rank.bank_groups[bank.bank_group_id]
        return ch, rank, bank, bank_group

    def decode_and_place(self, req: MemoryRequest) -> None:
        """ADDRESS DECODE step of the command state machine."""
        addr = self.mapper.decode(req.address)
        req.channel = addr.channel % self.topology.n_channels
        req.rank = addr.rank % self.topology.n_ranks_per_channel
        req.bank_group = addr.bank_group % self.topology.device_template.bank_groups
        req.bank = (addr.bank_group * self.topology.device_template.banks_per_group
                    + addr.bank) % self.topology.device_template.banks
        req.row = addr.row
        req.column = addr.column

    def row_is_open_for(self, req: MemoryRequest) -> bool:
        """Used by the scheduler (FR-FCFS etc) to check row-buffer
        readiness without mutating state."""
        if req.channel is None:
            self.decode_and_place(req)
        _, _, bank, _ = self._bank_and_group(req)
        return bank.row_buffer.active_row == req.row and bank.is_open()

    def _maybe_refresh_rank(self, channel_id: int, rank, hint_time_ns: float) -> float:
        """If refresh is due for this rank, close any open banks and issue
        REF before proceeding. Returns the time at which the rank becomes
        available (>= hint_time_ns)."""
        now = max(hint_time_ns, self._command_bus_free_at[channel_id])
        if not self.refresh_engine.is_due(rank.rank_id, now):
            return hint_time_ns

        # close any open banks first
        for bank in rank.banks.values():
            if bank.state in (BankState.ACTIVE, BankState.READING, BankState.WRITING):
                pre_time = max(now, self.timing_engine.earliest_precharge_time(bank),
                               self._command_bus_free_at[channel_id])
                bank.precharge(pre_time)
                self._command_bus_free_at[channel_id] = pre_time + COMMAND_ISSUE_CYCLES * self.clock_period_ns
                self.event_log.record(self.clock, EventType.PRECHARGE_ISSUED,
                                       bank_id=bank.bank_id, reason="pre_refresh",
                                       time_ns=pre_time)
                now = self._command_bus_free_at[channel_id]

        completion = self.refresh_engine.issue_refresh(rank, now, self.clock, self.event_log)
        self._command_bus_free_at[channel_id] = max(self._command_bus_free_at[channel_id], completion)
        self._command_count += 1
        return completion

    def service(self, req: MemoryRequest) -> MemoryRequest:
        """Drive one request through the full command state machine.
        Mutates and returns the request with completion timestamps set."""
        if req.channel is None:
            self.decode_and_place(req)
        req.state = RequestState.IN_SERVICE
        req.service_start_ns = max(req.arrival_time_ns, self._last_completion_time_ns * 0.0
                                    + req.arrival_time_ns)

        ch, rank, bank, bank_group = self._bank_and_group(req)
        channel_id = req.channel

        now = max(req.arrival_time_ns, self._command_bus_free_at[channel_id])
        now = self._maybe_refresh_rank(channel_id, rank, now)

        classification = bank.classify_access(req.row)
        if classification.value == "ROW_HIT":
            bank.record_access(classification)  # activate() is not called on a hit
        self.event_log.record(self.clock, EventType.__members__[
            "ROW_HIT" if classification.value == "ROW_HIT" else
            ("ROW_MISS" if classification.value == "ROW_MISS" else "ROW_CONFLICT")
        ], bank_id=bank.bank_id, row=req.row)

        # ROW CHECK / ACTIVATE IF REQUIRED
        if classification.value == "ROW_CONFLICT":
            pre_time = max(now, self.timing_engine.earliest_precharge_time(bank),
                           self._command_bus_free_at[channel_id])
            bank.precharge(pre_time)
            self._command_bus_free_at[channel_id] = pre_time + COMMAND_ISSUE_CYCLES * self.clock_period_ns
            self._command_count += 1
            self.event_log.record(self.clock, EventType.PRECHARGE_ISSUED,
                                   bank_id=bank.bank_id, reason="conflict", time_ns=pre_time)
            now = self._command_bus_free_at[channel_id]

        if classification.value in ("ROW_CONFLICT", "ROW_MISS"):
            act_time = max(now, self.timing_engine.earliest_activate_time(bank, bank_group, rank),
                           self._command_bus_free_at[channel_id])
            bank.activate(req.row, act_time, classification=classification)
            rank.record_rank_activation(act_time)
            bank_group.record_activation(act_time)
            self._command_bus_free_at[channel_id] = act_time + COMMAND_ISSUE_CYCLES * self.clock_period_ns
            self._command_count += 1
            self.event_log.record(self.clock, EventType.ROW_ACTIVATED,
                                   bank_id=bank.bank_id, row=req.row, time_ns=act_time)
            now = self._command_bus_free_at[channel_id]

        # WAIT TIMING + READ/WRITE
        is_read = req.operation in (RequestOperation.READ, RequestOperation.PREFETCH, RequestOperation.ATOMIC)
        col_time = max(now, self.timing_engine.earliest_column_access_time(bank, bank_group, is_read),
                       self._command_bus_free_at[channel_id])

        t = self.timing_engine.timing
        # Data-bus occupancy MUST be derived from the actual bytes this
        # request transfers, not an assumed/default burst_length -- using
        # a fixed burst_length here (independent of req.size_bytes) would
        # let achieved bandwidth exceed the channel's physical peak
        # whenever size_bytes doesn't match burst_length*bus_width/8.
        channel_bytes_per_ns = ch.theoretical_bandwidth_gbps().value  # GB/s == bytes/ns
        transfer_time_ns = req.size_bytes / channel_bytes_per_ns
        data_start = col_time + t.tCL
        if data_start < self._data_bus_free_at[channel_id]:
            # data bus busy (bus contention): push the column command later
            shift = self._data_bus_free_at[channel_id] - data_start
            col_time += shift
            data_start += shift

        if is_read:
            bank.read(col_time)
            self.event_log.record(self.clock, EventType.READ_ISSUED, bank_id=bank.bank_id,
                                   time_ns=col_time)
        else:
            bank.write(col_time)
            self.event_log.record(self.clock, EventType.WRITE_ISSUED, bank_id=bank.bank_id,
                                   time_ns=col_time)
        self._command_bus_free_at[channel_id] = max(self._command_bus_free_at[channel_id],
                                                      col_time + COMMAND_ISSUE_CYCLES * self.clock_period_ns)
        self._command_count += 1

        data_end = data_start + transfer_time_ns
        self._data_bus_free_at[channel_id] = data_end

        # PRECHARGE IF REQUIRED (close-page policy)
        completion_time = data_end
        if self.page_policy == PagePolicy.CLOSE_PAGE:
            pre_time = max(data_end, self.timing_engine.earliest_precharge_time(bank),
                           self._command_bus_free_at[channel_id])
            bank.precharge(pre_time)
            self._command_bus_free_at[channel_id] = pre_time + COMMAND_ISSUE_CYCLES * self.clock_period_ns
            self._command_count += 1
            self.event_log.record(self.clock, EventType.PRECHARGE_ISSUED,
                                   bank_id=bank.bank_id, reason="close_page", time_ns=pre_time)
            completion_time = max(completion_time, pre_time)

        req.completion_time_ns = completion_time
        req.state = RequestState.COMPLETED
        req.service_start_ns = min(req.service_start_ns, now)
        self._last_completion_time_ns = max(self._last_completion_time_ns, completion_time)
        # The controller services independent banks in scheduler-chosen
        # (not strictly chronological) order, so per-request completion
        # times are not globally monotonic even though each bank's own
        # timeline is. The simulation clock tracks the monotonic
        # high-water mark of simulated time for event-log purposes.
        if completion_time > self.clock.time_ns:
            self.clock.advance_to(completion_time)
        self.event_log.record(self.clock, EventType.REQUEST_COMPLETED,
                               request_id=req.request_id, latency_ns=req.total_latency_ns())
        self._completed_requests.append(req)
        return req

    def run(self, requests: List[MemoryRequest]) -> List[MemoryRequest]:
        """Drain a full request list through the controller, honouring the
        configured scheduler for ordering among currently-eligible
        (arrived) requests. This is a greedy, one-request-at-a-time
        service loop: requests are admitted to an eligible pool as their
        arrival time is reached, and the scheduler picks the next to
        service from that pool. Bus/bank timing (not FIFO submission
        order) determines actual completion order."""
        pending = sorted(requests, key=lambda r: r.arrival_time_ns)
        eligible: List[MemoryRequest] = []
        i = 0
        n = len(pending)
        results = []

        while i < n or eligible:
            # admit everything that has arrived by the controller's
            # current earliest-available time (or immediately if idle)
            horizon = eligible[0].arrival_time_ns if eligible else (
                pending[i].arrival_time_ns if i < n else float("inf"))
            controller_ready_time = min(self._command_bus_free_at.values()) if self._command_bus_free_at else 0.0
            admit_time = max(horizon, controller_ready_time)
            while i < n and pending[i].arrival_time_ns <= max(admit_time, pending[i].arrival_time_ns):
                if len(eligible) >= self.queue_depth:
                    break
                eligible.append(pending[i])
                self.event_log.record(self.clock, EventType.REQUEST_QUEUED,
                                       request_id=pending[i].request_id)
                i += 1

            if not eligible:
                if i < n:
                    continue
                break

            for r in eligible:
                if r.channel is None:
                    self.decode_and_place(r)

            chosen = self.scheduler.select(eligible, now_ns=admit_time,
                                            row_is_open=self.row_is_open_for)
            eligible.remove(chosen)
            self.service(chosen)
            if hasattr(self.scheduler, "record_service"):
                self.scheduler.record_service(chosen)
            results.append(chosen)

            # keep admitting any requests that have now arrived
            while i < n and pending[i].arrival_time_ns <= self._last_completion_time_ns:
                if len(eligible) >= self.queue_depth:
                    break
                eligible.append(pending[i])
                i += 1

        return results

    def completed_requests(self) -> List[MemoryRequest]:
        return list(self._completed_requests)

    def total_commands_issued(self) -> int:
        return self._command_count
