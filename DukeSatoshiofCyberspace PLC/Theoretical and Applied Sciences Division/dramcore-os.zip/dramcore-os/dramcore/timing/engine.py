"""
dramcore.timing.engine

THE TIMING ENGINE IS AUTHORITATIVE (spec section 21, 109).

No other layer (scheduler, controller, ML policy) is permitted to issue a
command that this engine has rejected. Every legality check here is tied
to an explicit timing parameter from the device's ``TimingProfile`` and a
recorded timestamp from bank/bank-group/rank state -- there are no bare
magic-number delays.

Two entry points:

    ``earliest_legal_time(cmd, ...)`` -> float ns
        The earliest timestamp at which the given command *would* become
        legal, given everything currently known. Used by schedulers to
        decide when to issue.

    ``validate(cmd, ...)`` -> None or raises TimingViolationError
        Hard legality gate. Raises if the command's stated timestamp is
        earlier than the earliest legal time.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from dramcore.bank.bank import BankState, DRAMBank
from dramcore.bank.bank_group import BankGroup
from dramcore.commands.command import CommandType, DRAMCommand
from dramcore.core.result import TimingViolationError
from dramcore.rank.rank import DRAMRank
from dramcore.timing.profile import TimingProfile


@dataclass
class TimingEngine:
    timing: TimingProfile

    # ------------------------------------------------------------------
    # ACT legality
    # ------------------------------------------------------------------
    def earliest_activate_time(self, bank: DRAMBank, bank_group: BankGroup,
                                rank: DRAMRank) -> float:
        candidates = [0.0]
        t = self.timing

        if bank.last_precharge_ns is not None:
            candidates.append(bank.last_precharge_ns + t.tRP)  # tRP: PRE -> ACT same bank
        if bank.last_activate_ns is not None:
            candidates.append(bank.last_activate_ns + t.tRC)   # tRC: ACT -> ACT same bank

        last_bg_act = bank_group.last_activation_ns()
        if last_bg_act is not None:
            candidates.append(last_bg_act + t.tRRD_L)  # same bank-group ACT->ACT

        # different-bank-group-but-same-rank ACT->ACT (tRRD_S): approximate
        # via the most recent rank-wide activation not in this bank group.
        other_bg_acts = [
            ts for ts in rank.activation_history_ns
            if ts not in bank_group.activation_history_ns
        ]
        if other_bg_acts:
            candidates.append(max(other_bg_acts) + t.tRRD_S)

        # tFAW: no more than 4 activations to this rank within a tFAW window.
        if t.tFAW > 0 and len(rank.activation_history_ns) >= 4:
            fourth_most_recent = sorted(rank.activation_history_ns)[-4]
            candidates.append(fourth_most_recent + t.tFAW)

        return max(candidates)

    def validate_activate(self, cmd: DRAMCommand, bank: DRAMBank,
                           bank_group: BankGroup, rank: DRAMRank) -> None:
        if bank.state != BankState.IDLE:
            raise TimingViolationError(
                f"ACT rejected: bank {bank.bank_id} not IDLE (state={bank.state}) "
                f"at t={cmd.timestamp_ns}"
            )
        earliest = self.earliest_activate_time(bank, bank_group, rank)
        if cmd.timestamp_ns < earliest - 1e-9:
            raise TimingViolationError(
                f"ACT rejected on bank {bank.bank_id}: issued at {cmd.timestamp_ns}ns, "
                f"earliest legal time is {earliest}ns (tRC/tRP/tRRD/tFAW constraint)"
            )

    # ------------------------------------------------------------------
    # RD / WR legality
    # ------------------------------------------------------------------
    def earliest_column_access_time(self, bank: DRAMBank, bank_group: BankGroup,
                                     is_read: bool) -> float:
        t = self.timing
        candidates = [0.0]
        if bank.last_activate_ns is not None:
            candidates.append(bank.last_activate_ns + t.tRCD)  # tRCD: ACT -> RD/WR

        # CAS-to-CAS same bank group vs cross bank group
        last_col_same_bg = None
        for other_bank in bank_group.banks:
            for ts in (other_bank.last_read_ns, other_bank.last_write_ns):
                if ts is not None:
                    last_col_same_bg = ts if last_col_same_bg is None else max(last_col_same_bg, ts)
        if last_col_same_bg is not None:
            candidates.append(last_col_same_bg + t.tCCD_L)

        if is_read:
            # WTR: switching from a write to a read requires tWTR
            if bank.last_write_ns is not None:
                same_bg_write = bank.last_write_ns
                candidates.append(same_bg_write + t.tWTR_L)
        else:
            # RTW: switching from a read to a write requires tRTW
            if bank.last_read_ns is not None:
                candidates.append(bank.last_read_ns + t.tRTW)

        return max(candidates)

    def validate_column_access(self, cmd: DRAMCommand, bank: DRAMBank,
                                bank_group: BankGroup) -> None:
        is_read = cmd.command_type == CommandType.RD
        if bank.state not in (BankState.ACTIVE, BankState.READING, BankState.WRITING):
            raise TimingViolationError(
                f"{cmd.command_type.value} rejected: bank {bank.bank_id} has no open row "
                f"(state={bank.state}) at t={cmd.timestamp_ns}"
            )
        if bank.row_buffer.active_row != cmd.row and cmd.row is not None:
            raise TimingViolationError(
                f"{cmd.command_type.value} rejected: requested row 0x{cmd.row:x} does not "
                f"match open row {bank.row_buffer.active_row} on bank {bank.bank_id}"
            )
        earliest = self.earliest_column_access_time(bank, bank_group, is_read)
        if cmd.timestamp_ns < earliest - 1e-9:
            raise TimingViolationError(
                f"{cmd.command_type.value} rejected on bank {bank.bank_id}: issued at "
                f"{cmd.timestamp_ns}ns, earliest legal time is {earliest}ns "
                f"(tRCD/tCCD/tWTR/tRTW constraint)"
            )

    # ------------------------------------------------------------------
    # PRE legality
    # ------------------------------------------------------------------
    def earliest_precharge_time(self, bank: DRAMBank) -> float:
        t = self.timing
        candidates = [0.0]
        if bank.last_activate_ns is not None:
            candidates.append(bank.last_activate_ns + t.tRAS)  # min row-active time
        if bank.last_read_ns is not None:
            candidates.append(bank.last_read_ns + t.tRTP)
        if bank.last_write_ns is not None:
            candidates.append(bank.last_write_ns + t.tWR)
        return max(candidates)

    def validate_precharge(self, cmd: DRAMCommand, bank: DRAMBank) -> None:
        if bank.state not in (BankState.ACTIVE, BankState.READING, BankState.WRITING):
            raise TimingViolationError(
                f"PRE rejected: bank {bank.bank_id} not active (state={bank.state}) "
                f"at t={cmd.timestamp_ns}"
            )
        earliest = self.earliest_precharge_time(bank)
        if cmd.timestamp_ns < earliest - 1e-9:
            raise TimingViolationError(
                f"PRE rejected on bank {bank.bank_id}: issued at {cmd.timestamp_ns}ns, "
                f"earliest legal time is {earliest}ns (tRAS/tRTP/tWR constraint)"
            )

    # ------------------------------------------------------------------
    # REF legality
    # ------------------------------------------------------------------
    def earliest_refresh_time(self, rank: DRAMRank, last_rank_refresh_ns: Optional[float]) -> float:
        t = self.timing
        if last_rank_refresh_ns is None:
            return 0.0
        return last_rank_refresh_ns + t.tRFC

    def validate_refresh(self, cmd: DRAMCommand, rank: DRAMRank,
                          last_rank_refresh_ns: Optional[float]) -> None:
        for bank in rank.banks.values():
            if bank.state != BankState.IDLE:
                raise TimingViolationError(
                    f"REF rejected: bank {bank.bank_id} in rank {rank.rank_id} not IDLE "
                    f"(state={bank.state}); all banks must be precharged before refresh"
                )
        earliest = self.earliest_refresh_time(rank, last_rank_refresh_ns)
        if cmd.timestamp_ns < earliest - 1e-9:
            raise TimingViolationError(
                f"REF rejected on rank {rank.rank_id}: issued at {cmd.timestamp_ns}ns, "
                f"earliest legal time is {earliest}ns (tRFC constraint)"
            )

    # ------------------------------------------------------------------
    # dispatch
    # ------------------------------------------------------------------
    def validate(self, cmd: DRAMCommand, *, bank: Optional[DRAMBank] = None,
                 bank_group: Optional[BankGroup] = None,
                 rank: Optional[DRAMRank] = None,
                 last_rank_refresh_ns: Optional[float] = None) -> None:
        if cmd.command_type == CommandType.ACT:
            self.validate_activate(cmd, bank, bank_group, rank)
        elif cmd.command_type in (CommandType.RD, CommandType.WR):
            self.validate_column_access(cmd, bank, bank_group)
        elif cmd.command_type == CommandType.PRE:
            self.validate_precharge(cmd, bank)
        elif cmd.command_type == CommandType.REF:
            self.validate_refresh(cmd, rank, last_rank_refresh_ns)
        else:
            # SREF/PDE/PDX legality handled by power-state engine; timing
            # engine has nothing further to enforce for those here.
            return
