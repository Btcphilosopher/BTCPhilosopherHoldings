"""
dramcore.timing.profile
========================

Timing parameters as data (spec section 20). A ``TimingProfile`` is a
plain, explicit bag of DRAM timing parameters, all in **nanoseconds**
unless suffixed ``_cycles`` (raw cycle counts as specified by a JEDEC-style
datasheet, convertible to ns via the device's clock period).

No default timing profile secretly stands in for "a specific commercial
part" (spec section 84, 111) -- ``TimingProfile.synthetic_ddr5_like()`` is
explicitly labelled as an illustrative synthetic profile, not a claim about
any real product.

Every parameter that a given DRAM generation does not use may be left as
``None`` -- the timing engine treats a ``None`` constraint as "not
applicable to this configured protocol" rather than silently defaulting to
zero.
"""

from __future__ import annotations

from dataclasses import dataclass, fields
from typing import Optional

from dramcore.core.result import InvalidConfigurationError


@dataclass(frozen=True)
class TimingProfile:
    """All values in nanoseconds unless noted. This is a *data* object --
    the timing engine (dramcore.timing.engine) is what enforces legality;
    this class only stores and validates internal consistency of the
    numbers themselves."""

    name: str = "unnamed_timing_profile"

    # Core command timings
    tCL: float = 0.0      # CAS latency: ACT/RD column access -> data ready
    tRCD: float = 0.0     # RAS-to-CAS delay: ACT -> RD/WR allowed
    tRP: float = 0.0      # Row precharge time: PRE -> next ACT allowed (same bank)
    tRAS: float = 0.0     # Row active time: ACT -> PRE allowed (min active time)
    tRC: float = 0.0      # Row cycle time: ACT -> next ACT (same bank), >= tRAS+tRP
    tRRD_S: float = 0.0   # ACT-to-ACT, different bank group (short)
    tRRD_L: float = 0.0   # ACT-to-ACT, same bank group (long)
    tFAW: float = 0.0     # Four-activate window: max 4 ACTs per rolling window
    tWR: float = 0.0      # Write recovery: last write data -> PRE allowed
    tWTR_S: float = 0.0   # Write-to-read turnaround, different bank group
    tWTR_L: float = 0.0   # Write-to-read turnaround, same bank group
    tCCD_S: float = 0.0   # CAS-to-CAS delay, different bank group
    tCCD_L: float = 0.0   # CAS-to-CAS delay, same bank group
    tRTP: float = 0.0     # Read-to-precharge

    # Refresh
    tRFC: float = 0.0     # Refresh cycle time: REF -> next ACT allowed (same rank)
    tREFI: float = 0.0    # Average refresh interval

    # Bus / turnaround
    tRTW: float = 0.0     # Read-to-write bus turnaround
    tWTW: Optional[float] = None  # Write-to-write (defaults to burst-derived if None)

    # Power-down / self-refresh
    tXP: float = 0.0      # Exit power-down -> command allowed
    tXS: float = 0.0      # Exit self-refresh -> command allowed
    tCKE: float = 0.0     # Minimum CKE pulse width

    def __post_init__(self):
        for f in fields(self):
            if f.type in ("float",):
                v = getattr(self, f.name)
                if v is not None and v < 0:
                    raise InvalidConfigurationError(
                        f"TimingProfile.{f.name} must be >= 0, got {v}"
                    )
        if self.tRC and self.tRAS and self.tRP and self.tRC < (self.tRAS + self.tRP) - 1e-9:
            raise InvalidConfigurationError(
                f"TimingProfile inconsistency: tRC ({self.tRC}) must be >= "
                f"tRAS + tRP ({self.tRAS + self.tRP})"
            )

    @staticmethod
    def synthetic_ddr5_like(data_rate_mt_s: float = 6400) -> "TimingProfile":
        """An illustrative, DDR5-class synthetic timing profile for
        demonstration and testing purposes ONLY. Values are representative
        of publicly documented DDR5 *timing structure and rough magnitude*,
        not any specific commercial die revision, vendor, or speed bin.
        See spec section 84."""
        return TimingProfile(
            name=f"synthetic_ddr5_like_{int(data_rate_mt_s)}MTs",
            tCL=27.0, tRCD=27.0, tRP=27.0, tRAS=32.0, tRC=59.0,
            tRRD_S=5.0, tRRD_L=6.0, tFAW=20.0, tWR=30.0,
            tWTR_S=5.0, tWTR_L=9.0, tCCD_S=2.5, tCCD_L=5.0, tRTP=7.5,
            tRFC=295.0, tREFI=3900.0,
            tRTW=8.0, tWTW=None,
            tXP=8.0, tXS=300.0, tCKE=8.0,
        )

    @staticmethod
    def synthetic_lpddr_like(data_rate_mt_s: float = 6400) -> "TimingProfile":
        """Illustrative LPDDR-class synthetic profile: shorter tRFC per bank
        due to bank-group/per-bank refresh assumptions, otherwise similar
        structure. Synthetic only -- see spec section 84."""
        return TimingProfile(
            name=f"synthetic_lpddr_like_{int(data_rate_mt_s)}MTs",
            tCL=24.0, tRCD=18.0, tRP=18.0, tRAS=28.0, tRC=46.0,
            tRRD_S=4.0, tRRD_L=5.0, tFAW=16.0, tWR=20.0,
            tWTR_S=4.0, tWTR_L=8.0, tCCD_S=2.0, tCCD_L=4.0, tRTP=6.0,
            tRFC=140.0, tREFI=1950.0,
            tRTW=7.0, tWTW=None,
            tXP=6.0, tXS=140.0, tCKE=6.0,
        )
