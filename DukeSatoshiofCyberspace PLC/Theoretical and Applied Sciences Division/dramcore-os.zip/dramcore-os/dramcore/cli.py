"""
dramcore.cli

Command-line interface (spec section 85):
    dramcore simulate config.yaml
    dramcore benchmark <name>
    dramcore sweep ...
    dramcore montecarlo ...
    dramcore thermal ...
    dramcore validate
    dramcore report ...
"""
from __future__ import annotations

import argparse
import json
import sys

from dramcore.configuration.config import (
    controller_config_from_config, device_from_config, load_config,
)
from dramcore.controller.simulation import Simulation
from dramcore.device.dram_device import DRAMDevice
from dramcore.traffic.generators import TrafficConfig, mixed, random_traffic, sequential_read


def _cmd_simulate(args):
    cfg = load_config(args.config)
    device = device_from_config(cfg)
    ctrl_cfg = controller_config_from_config(cfg)
    sim = Simulation(device=device, n_channels=cfg.get("dram", {}).get("channels", 2),
                      n_ranks_per_channel=cfg.get("dram", {}).get("ranks", 1),
                      seed=args.seed, **ctrl_cfg)
    traffic_cfg = TrafficConfig(
        n_requests=args.n_requests, address_space_bytes=sim.topology.total_capacity_bytes,
        request_size_bytes=64, mean_inter_arrival_ns=args.inter_arrival_ns, seed=args.seed,
        write_fraction=args.write_fraction,
    )
    reqs = mixed(traffic_cfg, sequential_fraction=args.sequential_fraction)
    result = sim.run(reqs)
    print(json.dumps(result.summary(), indent=2, default=str))


def _cmd_benchmark(args):
    from dramcore.benchmarks.suite import BENCHMARKS
    if args.name not in BENCHMARKS:
        print(f"Unknown benchmark '{args.name}'. Available: {list(BENCHMARKS)}", file=sys.stderr)
        sys.exit(1)
    result = BENCHMARKS[args.name](n_requests=args.n_requests, seed=args.seed)
    print(json.dumps(result.summary(), indent=2, default=str))


def _cmd_validate(args):
    from dramcore.validation.suite import run_all_validations
    ok, report = run_all_validations()
    print(report)
    sys.exit(0 if ok else 1)


def _cmd_thermal(args):
    from dramcore.thermal.engine import ThermalModel
    model = ThermalModel(ambient_temperature_c=args.ambient)
    result = model.steady_state_temperature_c(args.power_w)
    print(json.dumps(result.as_dict(), indent=2, default=str))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="dramcore", description="DRAMCORE.OS engineering CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p_sim = sub.add_parser("simulate", help="Run a simulation from a config file")
    p_sim.add_argument("config")
    p_sim.add_argument("--n-requests", type=int, default=5000)
    p_sim.add_argument("--seed", type=int, default=42)
    p_sim.add_argument("--inter-arrival-ns", type=float, default=1.0)
    p_sim.add_argument("--write-fraction", type=float, default=0.3)
    p_sim.add_argument("--sequential-fraction", type=float, default=0.5)
    p_sim.set_defaults(func=_cmd_simulate)

    p_bench = sub.add_parser("benchmark", help="Run a standard synthetic benchmark")
    p_bench.add_argument("name")
    p_bench.add_argument("--n-requests", type=int, default=5000)
    p_bench.add_argument("--seed", type=int, default=42)
    p_bench.set_defaults(func=_cmd_benchmark)

    p_val = sub.add_parser("validate", help="Run the full validation suite")
    p_val.set_defaults(func=_cmd_validate)

    p_therm = sub.add_parser("thermal", help="Steady-state thermal calculation")
    p_therm.add_argument("--power-w", type=float, default=2.0)
    p_therm.add_argument("--ambient", type=float, default=35.0)
    p_therm.set_defaults(func=_cmd_thermal)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
