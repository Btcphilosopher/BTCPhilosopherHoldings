"""
dramcore.rank.rank

DRAM rank model (spec section 14): a set of DRAM devices operated in
lockstep sharing chip-select, address, and command bus, combining to form
the full data bus width of a channel.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List

from dramcore.bank.bank import DRAMBank
from dramcore.bank.bank_group import BankGroup
from dramcore.core.result import InvalidConfigurationError
from dramcore.device.dram_device import DRAMDevice


class RankPowerState(str, Enum):
    ACTIVE = "ACTIVE"
    POWER_DOWN = "POWER_DOWN"
    SELF_REFRESH = "SELF_REFRESH"


@dataclass
class DRAMRank:
    rank_id: int
    device_template: DRAMDevice
    devices_per_rank: int = 1
    power_state: RankPowerState = RankPowerState.ACTIVE

    bank_groups: Dict[int, BankGroup] = field(default_factory=dict)
    banks: Dict[int, DRAMBank] = field(default_factory=dict)
    activation_history_ns: List[float] = field(default_factory=list)  # rank-wide, for tFAW

    def __post_init__(self):
        if self.devices_per_rank <= 0:
            raise InvalidConfigurationError("devices_per_rank must be > 0")
        if not self.bank_groups:
            self._build_banks()

    def _build_banks(self) -> None:
        dev = self.device_template
        for bg_id in range(dev.bank_groups):
            self.bank_groups[bg_id] = BankGroup(bank_group_id=bg_id)
        for bank_id in range(dev.banks):
            bg_id = bank_id % dev.bank_groups
            bank = DRAMBank(bank_id=bank_id, rows=dev.rows, columns=dev.columns,
                             bank_group_id=bg_id)
            self.banks[bank_id] = bank
            self.bank_groups[bg_id].banks.append(bank)

    @property
    def rank_capacity_bytes(self) -> int:
        return self.device_template.device_capacity_bytes * self.devices_per_rank

    @property
    def bus_width_bits(self) -> int:
        return self.device_template.bus_width_bits * self.devices_per_rank

    def record_rank_activation(self, timestamp_ns: float) -> None:
        self.activation_history_ns.append(timestamp_ns)
        # keep only a bounded recent window to avoid unbounded growth over
        # very long simulations (tFAW window is small; we retain generously)
        if len(self.activation_history_ns) > 4096:
            self.activation_history_ns = self.activation_history_ns[-1024:]

    def activations_in_window(self, now_ns: float, window_ns: float) -> int:
        return sum(1 for t in self.activation_history_ns if now_ns - t < window_ns)

    def total_row_hits(self) -> int:
        return sum(b.row_hits for b in self.banks.values())

    def total_row_misses(self) -> int:
        return sum(b.row_misses for b in self.banks.values())

    def total_row_conflicts(self) -> int:
        return sum(b.row_conflicts for b in self.banks.values())
