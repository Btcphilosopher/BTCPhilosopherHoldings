"""
dramcore.optimisation.cost_model

Optional configurable cost model (spec section 97). All cost assumptions
are explicit fields on ``CostModel`` -- nothing is hard-coded.
"""
from __future__ import annotations

from dataclasses import dataclass

from dramcore.core.result import EngineeringResult, Fidelity, InvalidConfigurationError, Provenance


@dataclass(frozen=True)
class CostModel:
    device_cost_usd_per_gb: float = 2.5
    controller_cost_usd: float = 8.0
    phy_cost_usd_per_channel: float = 3.0
    package_cost_usd: float = 1.5
    power_cost_usd_per_w_year: float = 1.2
    cooling_cost_usd_per_w: float = 0.4

    def __post_init__(self):
        for attr in ("device_cost_usd_per_gb", "controller_cost_usd",
                     "phy_cost_usd_per_channel", "package_cost_usd",
                     "power_cost_usd_per_w_year", "cooling_cost_usd_per_w"):
            if getattr(self, attr) < 0:
                raise InvalidConfigurationError(f"{attr} must be >= 0")

    def total_cost_usd(self, capacity_gb: float, n_channels: int,
                        average_power_w: float) -> EngineeringResult:
        device = capacity_gb * self.device_cost_usd_per_gb
        phy = n_channels * self.phy_cost_usd_per_channel
        power = average_power_w * (self.power_cost_usd_per_w_year + self.cooling_cost_usd_per_w)
        total = device + self.controller_cost_usd + phy + self.package_cost_usd + power
        return EngineeringResult(
            value=total, unit="USD",
            equation=("total_cost = device_cost + controller_cost + phy_cost "
                      "+ package_cost + power_cost + cooling_cost"),
            inputs={"capacity_gb": capacity_gb, "n_channels": n_channels,
                    "average_power_w": average_power_w,
                    "device_component_usd": device, "phy_component_usd": phy,
                    "power_component_usd": power},
            assumptions=("Illustrative configurable cost coefficients, not "
                         "sourced from any specific vendor pricing (spec "
                         "section 97).",),
            fidelity=Fidelity.FIDELITY_0,
            provenance=Provenance.SIMULATED,
        )

    def cost_per_gb(self, total_cost_usd: float, capacity_gb: float) -> float:
        return total_cost_usd / capacity_gb if capacity_gb > 0 else float("inf")

    def cost_per_gbps(self, total_cost_usd: float, bandwidth_gbps: float) -> float:
        return total_cost_usd / bandwidth_gbps if bandwidth_gbps > 0 else float("inf")

    def cost_per_operation(self, total_cost_usd: float, lifetime_operations: float) -> float:
        return total_cost_usd / lifetime_operations if lifetime_operations > 0 else float("inf")
