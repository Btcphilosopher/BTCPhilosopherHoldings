"""
dramcore.optimisation.design_space

Design-space exploration (spec section 49-50): generate parameter
combinations automatically and run a supplied evaluation function across
all of them, returning structured results.

Multi-objective optimisation (spec section 51): a dependency-free Pareto
filter (no external optimisation library required) plus an optional
thin wrapper around ``scipy.optimize.differential_evolution`` for
single-objective continuous optimisation when scipy is available.
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Sequence, Tuple

from dramcore.core.result import InvalidConfigurationError


@dataclass
class DesignSpace:
    """parameters: dict of name -> list of candidate values. All
    combinations are the Cartesian product (spec section 49)."""
    parameters: Dict[str, Sequence[Any]] = field(default_factory=dict)

    def __post_init__(self):
        for name, values in self.parameters.items():
            if len(values) == 0:
                raise InvalidConfigurationError(f"parameter '{name}' has no candidate values")

    def combinations(self) -> List[Dict[str, Any]]:
        names = list(self.parameters.keys())
        value_lists = [self.parameters[n] for n in names]
        return [dict(zip(names, combo)) for combo in itertools.product(*value_lists)]

    def size(self) -> int:
        n = 1
        for v in self.parameters.values():
            n *= len(v)
        return n


def sweep_parameter(name: str, values: Sequence[Any],
                     eval_fn: Callable[[Any], Dict[str, float]]) -> List[Dict[str, Any]]:
    """Sweep a single parameter (spec section 50) -- convenience wrapper
    over the general DesignSpace machinery for the common 1-D case."""
    results = []
    for v in values:
        out = eval_fn(v)
        results.append({name: v, **out})
    return results


def run_design_space(space: DesignSpace,
                      eval_fn: Callable[[Dict[str, Any]], Dict[str, float]]
                      ) -> List[Dict[str, Any]]:
    """Evaluate `eval_fn` (which returns a dict of output metrics) over
    every combination in the design space (spec section 49)."""
    results = []
    for combo in space.combinations():
        out = eval_fn(combo)
        results.append({**combo, **out})
    return results


def pareto_front(results: List[Dict[str, Any]], objectives: Dict[str, str]
                  ) -> List[Dict[str, Any]]:
    """objectives: dict of metric_name -> 'max' or 'min'. Returns the
    subset of `results` that is not dominated by any other result on all
    objectives simultaneously (spec section 51 Pareto optimisation)."""
    def dominates(a: Dict[str, Any], b: Dict[str, Any]) -> bool:
        at_least_as_good_everywhere = True
        strictly_better_somewhere = False
        for metric, direction in objectives.items():
            av, bv = a[metric], b[metric]
            if direction == "max":
                if av < bv:
                    at_least_as_good_everywhere = False
                if av > bv:
                    strictly_better_somewhere = True
            else:  # 'min'
                if av > bv:
                    at_least_as_good_everywhere = False
                if av < bv:
                    strictly_better_somewhere = True
        return at_least_as_good_everywhere and strictly_better_somewhere

    front = []
    for i, r in enumerate(results):
        dominated = any(dominates(other, r) for j, other in enumerate(results) if j != i)
        if not dominated:
            front.append(r)
    return front


def differential_evolution_optimise(objective_fn: Callable[[Sequence[float]], float],
                                     bounds: List[Tuple[float, float]],
                                     seed: int = 0, maxiter: int = 100):
    """Thin wrapper around scipy.optimize.differential_evolution for
    single-objective continuous optimisation (spec section 51). Raises a
    clear error if scipy is unavailable rather than silently no-op'ing."""
    try:
        from scipy.optimize import differential_evolution
    except ImportError as e:
        raise ImportError(
            "differential_evolution_optimise requires scipy "
            "(pip install scipy)"
        ) from e
    result = differential_evolution(objective_fn, bounds, seed=seed, maxiter=maxiter)
    return {"x": result.x, "fun": result.fun, "success": result.success,
            "message": result.message, "nit": result.nit}
