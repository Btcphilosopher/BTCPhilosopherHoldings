"""
dramcore.power.profile

Explicit, per-operation power/current coefficients (spec section 29, 84).
Values are in milliamps (IDD-style datasheet convention) plus a supply
voltage, OR directly in milliwatts -- both representations are supported;
``PowerProfile`` normalises to milliwatt operation costs via ``as_mw()``.

Synthetic default values are illustrative magnitudes only (spec 84, 111).
"""
from __future__ import annotations

from dataclasses import dataclass

from dramcore.core.result import InvalidConfigurationError


@dataclass(frozen=True)
class PowerProfile:
    name: str = "unnamed_power_profile"
    vdd_v: float = 1.1

    # IDD-style currents, milliamps, per JEDEC IDD-spec convention
    idd0_activate_precharge_ma: float = 55.0   # activate-precharge current (per bank cycle)
    idd1_active_standby_ma: float = 48.0
    idd2n_precharge_standby_ma: float = 34.0
    idd2p_precharge_powerdown_ma: float = 20.0
    idd3n_active_standby_ma: float = 42.0
    idd3p_active_powerdown_ma: float = 28.0
    idd4r_read_ma: float = 145.0
    idd4w_write_ma: float = 140.0
    idd5_refresh_ma: float = 190.0
    idd6_self_refresh_ma: float = 6.0

    io_power_per_gbps_mw: float = 4.0     # I/O driver power per GB/s of active transfer
    phy_static_power_mw: float = 35.0     # PHY always-on overhead
    controller_static_power_mw: float = 60.0

    def __post_init__(self):
        for attr in ("vdd_v", "idd0_activate_precharge_ma", "idd1_active_standby_ma",
                     "idd2n_precharge_standby_ma", "idd2p_precharge_powerdown_ma",
                     "idd3n_active_standby_ma", "idd3p_active_powerdown_ma",
                     "idd4r_read_ma", "idd4w_write_ma", "idd5_refresh_ma",
                     "idd6_self_refresh_ma", "io_power_per_gbps_mw",
                     "phy_static_power_mw", "controller_static_power_mw"):
            if getattr(self, attr) < 0:
                raise InvalidConfigurationError(f"PowerProfile.{attr} must be >= 0")

    def current_to_mw(self, current_ma: float) -> float:
        """P[mW] = I[mA] * V[V]"""
        return current_ma * self.vdd_v

    @staticmethod
    def synthetic_ddr5_like() -> "PowerProfile":
        return PowerProfile(name="synthetic_ddr5_like_power")

    @staticmethod
    def synthetic_lpddr_like() -> "PowerProfile":
        return PowerProfile(
            name="synthetic_lpddr_like_power", vdd_v=0.5,
            idd0_activate_precharge_ma=30.0, idd1_active_standby_ma=26.0,
            idd2n_precharge_standby_ma=18.0, idd2p_precharge_powerdown_ma=5.0,
            idd3n_active_standby_ma=22.0, idd3p_active_powerdown_ma=8.0,
            idd4r_read_ma=90.0, idd4w_write_ma=85.0,
            idd5_refresh_ma=110.0, idd6_self_refresh_ma=1.2,
            io_power_per_gbps_mw=2.2, phy_static_power_mw=18.0,
            controller_static_power_mw=40.0,
        )
