"""
dramcore.power.engine

Power model (spec section 29). Uses JEDEC IDD-spec-style operation
currents from ``PowerProfile`` to derive per-operation energies, combined
into instantaneous/average power and energy-per-bit/GB metrics.

Simplification explicitly disclosed: JEDEC IDD measurements are defined
under continuous back-to-back operation at minimum legal timing; this
engine uses them as per-operation energy coefficients (current x voltage x
the timing interval that operation "occupies"), which is the standard
architectural-level approximation used in academic DRAM power modelling
(e.g. DRAMPower-style accounting) -- it is FIDELITY_2, not a datasheet-
calibrated FIDELITY_3 model unless calibration data has been supplied.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional

from dramcore.core.result import EngineeringResult, Fidelity
from dramcore.core.units import energy_pj
from dramcore.power.profile import PowerProfile
from dramcore.timing.profile import TimingProfile


@dataclass
class PowerBreakdown:
    activation_energy_pj: float = 0.0
    read_energy_pj: float = 0.0
    write_energy_pj: float = 0.0
    refresh_energy_pj: float = 0.0
    standby_energy_pj: float = 0.0
    io_energy_pj: float = 0.0
    phy_energy_pj: float = 0.0
    controller_energy_pj: float = 0.0

    @property
    def total_energy_pj(self) -> float:
        return (self.activation_energy_pj + self.read_energy_pj + self.write_energy_pj
                + self.refresh_energy_pj + self.standby_energy_pj + self.io_energy_pj
                + self.phy_energy_pj + self.controller_energy_pj)

    def as_dict(self) -> Dict[str, float]:
        return {
            "activation_pj": self.activation_energy_pj,
            "read_pj": self.read_energy_pj,
            "write_pj": self.write_energy_pj,
            "refresh_pj": self.refresh_energy_pj,
            "standby_pj": self.standby_energy_pj,
            "io_pj": self.io_energy_pj,
            "phy_pj": self.phy_energy_pj,
            "controller_pj": self.controller_energy_pj,
            "total_pj": self.total_energy_pj,
        }


@dataclass
class PowerEngine:
    power_profile: PowerProfile
    timing_profile: TimingProfile

    def compute(self, *, n_activations: int, n_reads: int, n_writes: int,
                n_refreshes: int, total_elapsed_ns: float,
                total_bytes_transferred: int,
                achieved_bandwidth_gbps: float,
                standby_duty_cycle_fraction: float = 1.0) -> EngineeringResult:
        pp, tp = self.power_profile, self.timing_profile

        e_act = n_activations * energy_pj(
            pp.current_to_mw(pp.idd0_activate_precharge_ma), tp.tRC
        )
        e_rd = n_reads * energy_pj(pp.current_to_mw(pp.idd4r_read_ma), tp.tCCD_S)
        e_wr = n_writes * energy_pj(pp.current_to_mw(pp.idd4w_write_ma), tp.tCCD_S)
        e_ref = n_refreshes * energy_pj(pp.current_to_mw(pp.idd5_refresh_ma), tp.tRFC)
        e_standby = energy_pj(
            pp.current_to_mw(pp.idd2n_precharge_standby_ma) * standby_duty_cycle_fraction,
            total_elapsed_ns,
        )
        e_io = energy_pj(pp.io_power_per_gbps_mw * achieved_bandwidth_gbps, total_elapsed_ns)
        e_phy = energy_pj(pp.phy_static_power_mw, total_elapsed_ns)
        e_ctrl = energy_pj(pp.controller_static_power_mw, total_elapsed_ns)

        breakdown = PowerBreakdown(
            activation_energy_pj=e_act, read_energy_pj=e_rd, write_energy_pj=e_wr,
            refresh_energy_pj=e_ref, standby_energy_pj=e_standby, io_energy_pj=e_io,
            phy_energy_pj=e_phy, controller_energy_pj=e_ctrl,
        )
        total_e = breakdown.total_energy_pj
        avg_power_mw = total_e / total_elapsed_ns if total_elapsed_ns > 0 else 0.0
        total_bits = total_bytes_transferred * 8
        energy_per_bit_pj = total_e / total_bits if total_bits > 0 else None
        energy_per_gb_pj = (total_e / (total_bytes_transferred / 1e9)
                            if total_bytes_transferred > 0 else None)

        return EngineeringResult(
            value=avg_power_mw, unit="mW",
            equation="P_avg = sum(E_component) / total_elapsed_time",
            inputs={
                "n_activations": n_activations, "n_reads": n_reads, "n_writes": n_writes,
                "n_refreshes": n_refreshes, "total_elapsed_ns": total_elapsed_ns,
                "breakdown_pj": breakdown.as_dict(),
                "energy_per_bit_pj": energy_per_bit_pj,
                "energy_per_gb_pj": energy_per_gb_pj,
                "total_energy_pj": total_e,
            },
            assumptions=(
                "IDD-spec currents applied as per-operation energy "
                "coefficients (current x voltage x nominal timing "
                "interval) rather than a full cycle-by-cycle current "
                "trace -- standard architectural DRAM power-modelling "
                "approximation, not datasheet-calibrated unless "
                "CALIBRATED provenance is attached.",
                "Standby duty cycle applied as a flat multiplier on "
                "precharge-standby current for the whole simulated "
                "window.",
            ),
            fidelity=Fidelity.FIDELITY_2,
        )
