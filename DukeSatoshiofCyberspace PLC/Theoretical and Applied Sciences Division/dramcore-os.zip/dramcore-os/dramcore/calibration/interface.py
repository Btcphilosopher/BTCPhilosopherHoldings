"""
dramcore.calibration.interface

Calibration interface (spec section 99-100): allow measured hardware data
to be imported and compared against simulation output, computing standard
error metrics. Clearly distinguishes MODEL output from MEASURED input
(spec section 67).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np

from dramcore.core.result import EngineeringResult, Fidelity, Provenance


@dataclass(frozen=True)
class MeasuredDataPoint:
    measured_latency_ns: Optional[float] = None
    measured_bandwidth_gbps: Optional[float] = None
    measured_power_mw: Optional[float] = None
    measured_temperature_c: Optional[float] = None
    measured_error_rate: Optional[float] = None
    source_description: str = "unspecified hardware measurement"


def compare_to_measured(simulated: Dict[str, float], measured: MeasuredDataPoint) -> EngineeringResult:
    """Compute absolute/relative error between simulated and measured
    values for every metric present in both (spec section 100)."""
    pairs = {
        "latency_ns": (simulated.get("latency_ns"), measured.measured_latency_ns),
        "bandwidth_gbps": (simulated.get("bandwidth_gbps"), measured.measured_bandwidth_gbps),
        "power_mw": (simulated.get("power_mw"), measured.measured_power_mw),
        "temperature_c": (simulated.get("temperature_c"), measured.measured_temperature_c),
        "error_rate": (simulated.get("error_rate"), measured.measured_error_rate),
    }
    errors = {}
    for metric, (sim_v, meas_v) in pairs.items():
        if sim_v is None or meas_v is None:
            continue
        abs_err = sim_v - meas_v
        rel_err = abs_err / meas_v if meas_v != 0 else float("inf")
        errors[metric] = {"absolute_error": abs_err, "relative_error": rel_err,
                           "simulated": sim_v, "measured": meas_v}

    if errors:
        abs_errs = [abs(e["absolute_error"]) for e in errors.values()]
        rel_errs = [abs(e["relative_error"]) for e in errors.values() if np.isfinite(e["relative_error"])]
        summary = {
            "MAE": float(np.mean(abs_errs)),
            "RMSE": float(np.sqrt(np.mean(np.square(abs_errs)))),
            "mean_relative_error": float(np.mean(rel_errs)) if rel_errs else None,
            "per_metric": errors,
        }
    else:
        summary = {"per_metric": {}}

    return EngineeringResult(
        value=summary, unit="mixed",
        equation="absolute_error = simulated - measured; relative_error = absolute_error / measured",
        inputs={"source": measured.source_description},
        assumptions=("Comparison uses whatever aggregate simulated metric "
                     "was supplied (e.g. mean latency) against a single "
                     "measured value -- for a rigorous calibration, "
                     "compare matched percentiles/operating points rather "
                     "than a single summary number.",),
        fidelity=Fidelity.FIDELITY_1,
        provenance=Provenance.CALIBRATED if errors else Provenance.SIMULATED,
    )
