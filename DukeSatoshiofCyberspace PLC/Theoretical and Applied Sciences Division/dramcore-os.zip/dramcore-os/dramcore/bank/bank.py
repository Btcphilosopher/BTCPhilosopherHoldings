"""
dramcore.bank.bank

DRAM bank model with explicit state machine (spec section 12): IDLE ->
ACTIVATING -> ACTIVE -> READING/WRITING -> PRECHARGING -> IDLE, plus
REFRESHING and POWER_DOWN/SELF_REFRESH side states.

The bank tracks its own row buffer, per-bank timing bookkeeping (last
ACT/PRE/RD/WR timestamps -- consumed by the timing engine to enforce
legality), and row hit/miss/conflict counters.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from dramcore.array.row_buffer import AccessClassification, RowBuffer, RowBufferState
from dramcore.core.result import InvalidConfigurationError


class BankState(str, Enum):
    IDLE = "IDLE"
    ACTIVATING = "ACTIVATING"
    ACTIVE = "ACTIVE"
    READING = "READING"
    WRITING = "WRITING"
    PRECHARGING = "PRECHARGING"
    REFRESHING = "REFRESHING"
    POWER_DOWN = "POWER_DOWN"
    SELF_REFRESH = "SELF_REFRESH"


# Legal transitions for the *bank* lifecycle state machine (independent of
# the finer-grained timing legality enforced by the timing engine, which
# additionally gates *when* a transition may occur).
_LEGAL_TRANSITIONS = {
    BankState.IDLE: {BankState.ACTIVATING, BankState.REFRESHING,
                      BankState.POWER_DOWN, BankState.SELF_REFRESH},
    BankState.ACTIVATING: {BankState.ACTIVE},
    BankState.ACTIVE: {BankState.READING, BankState.WRITING,
                        BankState.PRECHARGING, BankState.POWER_DOWN},
    BankState.READING: {BankState.ACTIVE, BankState.PRECHARGING, BankState.READING,
                         BankState.WRITING},
    BankState.WRITING: {BankState.ACTIVE, BankState.PRECHARGING, BankState.WRITING,
                         BankState.READING},
    BankState.PRECHARGING: {BankState.IDLE},
    BankState.REFRESHING: {BankState.IDLE},
    BankState.POWER_DOWN: {BankState.IDLE, BankState.ACTIVE},
    BankState.SELF_REFRESH: {BankState.IDLE},
}


class IllegalBankTransitionError(InvalidConfigurationError):
    pass


@dataclass
class DRAMBank:
    bank_id: int
    rows: int
    columns: int
    bank_group_id: int = 0
    state: BankState = BankState.IDLE
    row_buffer: RowBuffer = None
    temperature_c: float = 35.0

    # Timing bookkeeping: last time (ns) each command type occurred on this
    # bank. Consumed by the timing engine for tRAS/tRP/tRC/tWR/etc checks.
    last_activate_ns: Optional[float] = None
    last_precharge_ns: Optional[float] = None
    last_read_ns: Optional[float] = None
    last_write_ns: Optional[float] = None
    last_refresh_ns: Optional[float] = None
    activate_history_ns: list = field(default_factory=list)  # for tFAW (rank-level copies in too)

    # Counters
    row_hits: int = 0
    row_misses: int = 0
    row_conflicts: int = 0
    activation_count: int = 0
    activation_count_per_row: dict = field(default_factory=dict)

    def __post_init__(self):
        if self.row_buffer is None:
            self.row_buffer = RowBuffer(bank_id=self.bank_id)

    def _transition(self, new_state: BankState) -> None:
        if new_state not in _LEGAL_TRANSITIONS[self.state]:
            raise IllegalBankTransitionError(
                f"Bank {self.bank_id}: illegal transition {self.state} -> {new_state}"
            )
        self.state = new_state

    def classify_access(self, row: int) -> AccessClassification:
        return self.row_buffer.classify(row)

    def record_access(self, classification: AccessClassification) -> None:
        """Record a classification decided by the caller. Split out from
        ``activate()`` because a ROW_CONFLICT must be counted using the
        classification observed BEFORE any precharge -- by the time a
        real controller has precharged the old row and calls activate()
        for the new one, the row buffer is already EMPTY and would
        (wrongly) reclassify as ROW_MISS if re-derived at that point."""
        if classification == AccessClassification.ROW_HIT:
            self.row_hits += 1
        elif classification == AccessClassification.ROW_CONFLICT:
            self.row_conflicts += 1
        else:
            self.row_misses += 1

    def activate(self, row: int, timestamp_ns: float,
                 classification: "AccessClassification | None" = None) -> AccessClassification:
        """Perform an ACT. If `classification` is not supplied, it is
        derived from current state (correct for standalone/direct calls
        with no intervening precharge); callers that precharge first
        (e.g. the memory controller resolving a ROW_CONFLICT) MUST pass
        the classification they observed prior to that precharge so
        counting stays accurate."""
        observed = self.classify_access(row)
        effective = classification if classification is not None else observed
        self.record_access(effective)
        if observed == AccessClassification.ROW_HIT:
            return observed

        self._transition(BankState.ACTIVATING)
        self._transition(BankState.ACTIVE)
        self.row_buffer.open_row(row, timestamp_ns)
        self.last_activate_ns = timestamp_ns
        self.activate_history_ns.append(timestamp_ns)
        self.activation_count += 1
        self.activation_count_per_row[row] = self.activation_count_per_row.get(row, 0) + 1
        return effective

    def read(self, timestamp_ns: float) -> None:
        if self.state not in (BankState.ACTIVE, BankState.READING, BankState.WRITING):
            raise IllegalBankTransitionError(
                f"Bank {self.bank_id}: cannot READ from state {self.state}"
            )
        self._transition(BankState.READING)
        self.last_read_ns = timestamp_ns

    def write(self, timestamp_ns: float) -> None:
        if self.state not in (BankState.ACTIVE, BankState.READING, BankState.WRITING):
            raise IllegalBankTransitionError(
                f"Bank {self.bank_id}: cannot WRITE from state {self.state}"
            )
        self._transition(BankState.WRITING)
        self.last_write_ns = timestamp_ns

    def precharge(self, timestamp_ns: float) -> None:
        if self.state in (BankState.READING, BankState.WRITING):
            self._transition(BankState.ACTIVE)
        if self.state != BankState.ACTIVE:
            raise IllegalBankTransitionError(
                f"Bank {self.bank_id}: cannot PRECHARGE from state {self.state}"
            )
        self._transition(BankState.PRECHARGING)
        self._transition(BankState.IDLE)
        self.row_buffer.close()
        self.last_precharge_ns = timestamp_ns

    def begin_refresh(self, timestamp_ns: float) -> None:
        self._transition(BankState.REFRESHING)
        self.last_refresh_ns = timestamp_ns

    def end_refresh(self) -> None:
        self._transition(BankState.IDLE)

    def is_open(self) -> bool:
        return self.row_buffer.state == RowBufferState.OPEN
