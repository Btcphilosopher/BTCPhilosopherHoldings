"""
dramcore.bank.bank_group

Bank-group aggregation (spec section 13). Bank groups matter because
same-bank-group timing constraints (tCCD_L, tRRD_L, tWTR_L) are stricter
than cross-bank-group constraints (tCCD_S, tRRD_S, tWTR_S) -- this is one
of the primary levers the scheduler has for extracting bandwidth.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from dramcore.bank.bank import DRAMBank


@dataclass
class BankGroup:
    bank_group_id: int
    banks: List[DRAMBank] = field(default_factory=list)
    activation_history_ns: List[float] = field(default_factory=list)  # for tRRD_L tracking

    def record_activation(self, timestamp_ns: float) -> None:
        self.activation_history_ns.append(timestamp_ns)

    def last_activation_ns(self):
        return self.activation_history_ns[-1] if self.activation_history_ns else None

    def total_row_hits(self) -> int:
        return sum(b.row_hits for b in self.banks)

    def total_row_conflicts(self) -> int:
        return sum(b.row_conflicts for b in self.banks)
