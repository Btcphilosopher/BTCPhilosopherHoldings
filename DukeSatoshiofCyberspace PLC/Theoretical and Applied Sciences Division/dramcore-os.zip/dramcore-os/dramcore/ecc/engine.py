"""
dramcore.ecc.engine

ECC abstraction (spec section 34). Implements mathematically well-defined,
configurable ECC classes -- NO_ECC, and a SECDED (Single Error Correct,
Double Error Detect) model based on standard Hamming-distance-4 coding
theory -- rather than any proprietary vendor ECC algorithm.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

import numpy as np

from dramcore.core.result import EngineeringResult, Fidelity, InvalidConfigurationError


class ECCMode(str, Enum):
    NO_ECC = "NO_ECC"
    SECDED = "SECDED"
    CONFIGURABLE_ECC = "CONFIGURABLE_ECC"


@dataclass
class ECCEngine:
    mode: ECCMode = ECCMode.SECDED
    data_word_bits: int = 64
    """Configurable-ECC generalisation: correct up to `t` errors per
    codeword using a generic distance-based capability model (an
    idealised bound based on minimum Hamming distance d = 2t+1, matching
    the standard theoretical relationship -- not a specific vendor
    algorithm)."""
    configurable_t_errors_correctable: int = 1

    correctable_errors: int = field(default=0, init=False)
    uncorrectable_errors: int = field(default=0, init=False)
    detected_only_errors: int = field(default=0, init=False)

    def __post_init__(self):
        if self.data_word_bits <= 0:
            raise InvalidConfigurationError("data_word_bits must be > 0")
        if self.configurable_t_errors_correctable < 0:
            raise InvalidConfigurationError(
                "configurable_t_errors_correctable must be >= 0"
            )

    def parity_check_bits_required(self) -> int:
        """Hamming SECDED bound: r parity bits satisfy 2^r >= m + r + 1 for
        an (m+r)-bit codeword protecting m data bits with SEC, plus one
        additional overall-parity bit for DED. Returns r (SEC bits) + 1."""
        m = self.data_word_bits
        r = 1
        while (2 ** r) < (m + r + 1):
            r += 1
        return r + 1  # +1 for the overall/DED parity bit

    def codeword_bits(self) -> int:
        return self.data_word_bits + self.parity_check_bits_required()

    def classify_and_correct(self, n_bit_errors_in_codeword: int) -> str:
        """Given a simulated number of bit errors that landed in one
        codeword, classify the outcome under the configured ECC mode."""
        if self.mode == ECCMode.NO_ECC:
            outcome = "UNDETECTED" if n_bit_errors_in_codeword > 0 else "CLEAN"
        elif self.mode == ECCMode.SECDED:
            if n_bit_errors_in_codeword == 0:
                outcome = "CLEAN"
            elif n_bit_errors_in_codeword == 1:
                outcome = "CORRECTABLE"
                self.correctable_errors += 1
            elif n_bit_errors_in_codeword == 2:
                outcome = "DETECTED_UNCORRECTABLE"
                self.uncorrectable_errors += 1
            else:
                outcome = "UNDETECTED"  # beyond SECDED's guaranteed detection radius
        else:  # CONFIGURABLE_ECC
            t = self.configurable_t_errors_correctable
            if n_bit_errors_in_codeword == 0:
                outcome = "CLEAN"
            elif n_bit_errors_in_codeword <= t:
                outcome = "CORRECTABLE"
                self.correctable_errors += 1
            elif n_bit_errors_in_codeword <= 2 * t + 1:
                outcome = "DETECTED_UNCORRECTABLE"
                self.uncorrectable_errors += 1
            else:
                outcome = "UNDETECTED"
        return outcome

    def simulate_stream(self, n_codewords: int, per_bit_error_probability: float,
                         seed: Optional[int] = None) -> EngineeringResult:
        """Simulate n_codewords independent codewords, each with
        Binomial(codeword_bits, p) bit errors, and classify each outcome
        under the configured ECC mode."""
        if n_codewords < 0:
            raise InvalidConfigurationError("n_codewords must be >= 0")
        rng = np.random.default_rng(seed)
        cw_bits = self.codeword_bits() if self.mode != ECCMode.NO_ECC else self.data_word_bits
        counts = rng.binomial(n=cw_bits, p=per_bit_error_probability, size=n_codewords) \
            if n_codewords > 0 else np.array([])

        outcomes = {"CLEAN": 0, "CORRECTABLE": 0, "DETECTED_UNCORRECTABLE": 0, "UNDETECTED": 0}
        for c in counts:
            outcomes[self.classify_and_correct(int(c))] += 1

        return EngineeringResult(
            value=outcomes, unit="count_by_outcome",
            equation="per-codeword errors ~ Binomial(codeword_bits, p); classified by ECC capability",
            inputs={"n_codewords": n_codewords, "per_bit_error_probability": per_bit_error_probability,
                    "mode": self.mode.value, "codeword_bits": cw_bits, "seed": seed},
            assumptions=(
                "Standard Hamming-distance SECDED capability model "
                "(corrects 1 error, detects 2 per codeword) -- "
                "mathematically defined, not a specific vendor "
                "implementation (spec section 34).",
                "Independent per-bit error probability within a codeword "
                "(no burst-error correlation modelled).",
            ),
            fidelity=Fidelity.FIDELITY_1,
        )

    def error_rate_summary(self, n_codewords: int) -> EngineeringResult:
        ce_rate = self.correctable_errors / n_codewords if n_codewords else 0.0
        ue_rate = self.uncorrectable_errors / n_codewords if n_codewords else 0.0
        return EngineeringResult(
            value={"correctable_error_rate": ce_rate, "uncorrectable_error_rate": ue_rate},
            unit="errors/codeword",
            equation="rate = cumulative_error_count / n_codewords",
            inputs={"correctable_errors": self.correctable_errors,
                    "uncorrectable_errors": self.uncorrectable_errors,
                    "n_codewords": n_codewords},
            fidelity=Fidelity.FIDELITY_1,
        )
