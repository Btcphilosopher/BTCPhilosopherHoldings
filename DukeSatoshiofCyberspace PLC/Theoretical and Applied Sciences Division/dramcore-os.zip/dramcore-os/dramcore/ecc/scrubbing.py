"""
dramcore.ecc.scrubbing

Memory scrubbing policies (spec section 35): proactively reading and
ECC-correcting memory in the background to prevent single-bit errors from
accumulating into uncorrectable multi-bit errors within a codeword.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from dramcore.core.result import EngineeringResult, Fidelity, InvalidConfigurationError
from dramcore.ecc.engine import ECCEngine


class ScrubPolicy(str, Enum):
    PERIODIC_SCRUB = "PERIODIC_SCRUB"
    BACKGROUND_SCRUB = "BACKGROUND_SCRUB"
    TARGETED_SCRUB = "TARGETED_SCRUB"


@dataclass
class ScrubEngine:
    policy: ScrubPolicy = ScrubPolicy.BACKGROUND_SCRUB
    scrub_bandwidth_gbps: float = 0.5
    """Bandwidth budget dedicated to scrub traffic -- directly trades off
    against application bandwidth (spec section 35)."""
    total_capacity_bytes: int = 0

    def __post_init__(self):
        if self.scrub_bandwidth_gbps <= 0:
            raise InvalidConfigurationError("scrub_bandwidth_gbps must be > 0")
        if self.total_capacity_bytes < 0:
            raise InvalidConfigurationError("total_capacity_bytes must be >= 0")

    def full_pass_time_s(self) -> EngineeringResult:
        """Time to scrub the entire configured capacity once at the
        allocated scrub bandwidth."""
        if self.total_capacity_bytes == 0:
            t = 0.0
        else:
            t = (self.total_capacity_bytes / 1e9) / self.scrub_bandwidth_gbps
        return EngineeringResult(
            value=t, unit="s",
            equation="t_full_pass = capacity_GB / scrub_bandwidth_GBps",
            inputs={"total_capacity_bytes": self.total_capacity_bytes,
                    "scrub_bandwidth_gbps": self.scrub_bandwidth_gbps},
            fidelity=Fidelity.FIDELITY_1,
        )

    def scrub_energy_pj(self, io_power_per_gbps_mw: float) -> EngineeringResult:
        t_s = self.full_pass_time_s().value
        e_pj = io_power_per_gbps_mw * self.scrub_bandwidth_gbps * (t_s * 1e9)
        return EngineeringResult(
            value=e_pj, unit="pJ",
            equation="E_scrub = io_power_per_gbps * scrub_bandwidth_gbps * full_pass_time_ns",
            inputs={"io_power_per_gbps_mw": io_power_per_gbps_mw,
                    "scrub_bandwidth_gbps": self.scrub_bandwidth_gbps,
                    "full_pass_time_s": t_s},
            fidelity=Fidelity.FIDELITY_1,
        )

    def latency_impact_fraction(self, total_available_bandwidth_gbps: float) -> EngineeringResult:
        """Fraction of total available bandwidth consumed by scrub traffic
        -- directly reduces application-visible bandwidth (a simple
        proportional latency/bandwidth impact estimate)."""
        if total_available_bandwidth_gbps <= 0:
            raise InvalidConfigurationError("total_available_bandwidth_gbps must be > 0")
        frac = min(1.0, self.scrub_bandwidth_gbps / total_available_bandwidth_gbps)
        return EngineeringResult(
            value=frac, unit="fraction",
            equation="impact = scrub_bandwidth_gbps / total_available_bandwidth_gbps",
            inputs={"scrub_bandwidth_gbps": self.scrub_bandwidth_gbps,
                    "total_available_bandwidth_gbps": total_available_bandwidth_gbps},
            fidelity=Fidelity.FIDELITY_1,
        )
