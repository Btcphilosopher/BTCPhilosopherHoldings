"""
dramcore.reporting.report

Engineering reports (spec section 67): every report identifies whether
its constituent results are SIMULATED / CALIBRATED / MEASURED / IMPORTED,
and bundles configuration, timing, workload, performance, power, thermal,
reliability, and assumptions into one exportable artifact.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from dramcore.core.reproducibility import ReproducibilityRecord
from dramcore.core.result import EngineeringResult


@dataclass
class EngineeringReport:
    title: str
    configuration: Dict[str, Any] = field(default_factory=dict)
    workload_description: str = ""
    results: Dict[str, EngineeringResult] = field(default_factory=dict)
    reproducibility: Optional[ReproducibilityRecord] = None
    limitations: List[str] = field(default_factory=list)
    generated_at_utc: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def add_result(self, name: str, result: EngineeringResult) -> None:
        self.results[name] = result

    def fidelity_summary(self) -> Dict[str, str]:
        return {name: r.fidelity.value for name, r in self.results.items()}

    def provenance_summary(self) -> Dict[str, str]:
        return {name: r.provenance.value for name, r in self.results.items()}

    def as_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "generated_at_utc": self.generated_at_utc,
            "configuration": self.configuration,
            "workload_description": self.workload_description,
            "results": {name: r.as_dict() for name, r in self.results.items()},
            "fidelity_summary": self.fidelity_summary(),
            "provenance_summary": self.provenance_summary(),
            "limitations": self.limitations,
            "reproducibility": self.reproducibility.as_dict() if self.reproducibility else None,
        }

    def to_json(self, path: Optional[str] = None) -> str:
        text = json.dumps(self.as_dict(), indent=2, default=str)
        if path:
            with open(path, "w") as f:
                f.write(text)
        return text

    def to_markdown(self, path: Optional[str] = None) -> str:
        lines = [f"# {self.title}", "", f"_Generated: {self.generated_at_utc}_", ""]
        if self.workload_description:
            lines += ["## Workload", "", self.workload_description, ""]
        if self.configuration:
            lines += ["## Configuration", "", "| Parameter | Value |", "|---|---|"]
            for k, v in self.configuration.items():
                lines.append(f"| {k} | {v} |")
            lines.append("")
        lines += ["## Results", ""]
        for name, r in self.results.items():
            lines.append(f"### {name}")
            lines.append("")
            lines.append(f"- **Value**: {r.value} {r.unit}")
            lines.append(f"- **Equation**: `{r.equation}`")
            lines.append(f"- **Fidelity**: {r.fidelity.value}")
            lines.append(f"- **Provenance**: {r.provenance.value}")
            if r.validity_range:
                lines.append(f"- **Validity range**: {r.validity_range}")
            if r.uncertainty is not None:
                lines.append(f"- **Uncertainty**: {r.uncertainty}")
            if r.assumptions:
                lines.append("- **Assumptions**:")
                for a in r.assumptions:
                    lines.append(f"  - {a}")
            lines.append("")
        if self.limitations:
            lines += ["## Limitations", ""]
            for lim in self.limitations:
                lines.append(f"- {lim}")
            lines.append("")
        if self.reproducibility:
            lines += ["## Reproducibility", "", "```json",
                       json.dumps(self.reproducibility.as_dict(), indent=2, default=str),
                       "```", ""]
        text = "\n".join(lines)
        if path:
            with open(path, "w") as f:
                f.write(text)
        return text
