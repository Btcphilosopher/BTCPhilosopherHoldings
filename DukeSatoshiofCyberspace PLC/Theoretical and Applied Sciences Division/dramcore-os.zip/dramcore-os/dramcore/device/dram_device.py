"""
dramcore.device.dram_device

Generic, standards-aware DRAM device abstraction (spec section 4). Does
not hard-code any single commercial implementation -- geometry, timing,
power, and refresh are all supplied as explicit configuration.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

from dramcore.core.result import InvalidConfigurationError
from dramcore.core.units import data_rate_mt_s_to_clock_period_ns
from dramcore.power.profile import PowerProfile
from dramcore.refresh.profile import RefreshProfile
from dramcore.timing.profile import TimingProfile


@dataclass(frozen=True)
class DRAMDevice:
    device_id: str
    technology_node_nm: float           # illustrative process node, nm
    density_gb: float                   # capacity of a single device, GB (decimal)
    data_rate_mt_s: float                # MT/s (mega-transfers/second)
    bus_width_bits: int                  # device I/O width, e.g. x4/x8/x16
    banks: int
    bank_groups: int
    rows: int
    columns: int
    burst_length: int = 16
    voltage_v: float = 1.1
    ambient_temperature_c: float = 35.0

    timing_profile: TimingProfile = field(default_factory=TimingProfile.synthetic_ddr5_like)
    refresh_profile: RefreshProfile = field(default_factory=RefreshProfile)
    power_profile: PowerProfile = field(default_factory=PowerProfile.synthetic_ddr5_like)

    def __post_init__(self):
        if self.density_gb <= 0:
            raise InvalidConfigurationError("density_gb must be > 0")
        if self.data_rate_mt_s <= 0:
            raise InvalidConfigurationError("data_rate_mt_s must be > 0")
        if self.bus_width_bits <= 0 or (self.bus_width_bits & (self.bus_width_bits - 1)) != 0:
            raise InvalidConfigurationError("bus_width_bits should be a power of two")
        if self.banks <= 0:
            raise InvalidConfigurationError("banks must be > 0")
        if self.bank_groups <= 0 or self.banks % self.bank_groups != 0:
            raise InvalidConfigurationError(
                "bank_groups must be > 0 and evenly divide banks"
            )
        if self.rows <= 0 or (self.rows & (self.rows - 1)) != 0:
            raise InvalidConfigurationError("rows should be a power of two")
        if self.columns <= 0 or (self.columns & (self.columns - 1)) != 0:
            raise InvalidConfigurationError("columns should be a power of two")
        if self.burst_length <= 0:
            raise InvalidConfigurationError("burst_length must be > 0")

    # -- derived geometry --------------------------------------------------
    @property
    def banks_per_group(self) -> int:
        return self.banks // self.bank_groups

    @property
    def clock_period_ns(self) -> float:
        return data_rate_mt_s_to_clock_period_ns(self.data_rate_mt_s)

    @property
    def row_bits(self) -> int:
        return int(math.log2(self.rows))

    @property
    def column_bits(self) -> int:
        return int(math.log2(self.columns))

    @property
    def bank_bits(self) -> int:
        return int(math.log2(self.banks_per_group))

    @property
    def bank_group_bits(self) -> int:
        return int(math.log2(self.bank_groups))

    @property
    def burst_bits(self) -> int:
        return int(math.log2(self.burst_length))

    @property
    def page_size_bytes(self) -> int:
        """The row buffer ('page') size in bytes: one full row width
        across the device's I/O bus, i.e. columns * bus_width."""
        return (self.columns * self.bus_width_bits) // 8

    @property
    def device_capacity_bytes(self) -> int:
        return int(self.density_gb * 1e9)

    @property
    def raw_geometric_capacity_bytes(self) -> int:
        """Capacity implied purely by rows*columns*banks*bus_width, used as
        a cross-check invariant against the declared density_gb."""
        bits = self.rows * self.columns * self.banks * self.bus_width_bits
        return bits // 8

    def theoretical_bandwidth_gbps(self) -> float:
        """Peak theoretical per-device bandwidth.
        BW[GB/s] = data_rate[MT/s] * bus_width[bits] / 8 [bits/byte] / 1000
        """
        return self.data_rate_mt_s * self.bus_width_bits / 8.0 / 1000.0

    @staticmethod
    def synthetic_ddr5_like(device_id: str = "DDR5_SYN_0",
                             density_gb: float = 4.0,
                             data_rate_mt_s: float = 6400) -> "DRAMDevice":
        """Illustrative synthetic DDR5-class device. Not a claim about any
        specific commercial part (spec 84)."""
        return DRAMDevice(
            device_id=device_id,
            technology_node_nm=14.0,
            density_gb=density_gb,
            data_rate_mt_s=data_rate_mt_s,
            bus_width_bits=8,
            banks=32,
            bank_groups=8,
            rows=131072,
            columns=2048,
            burst_length=16,
            voltage_v=1.1,
            timing_profile=TimingProfile.synthetic_ddr5_like(data_rate_mt_s),
            refresh_profile=RefreshProfile(),
            power_profile=PowerProfile.synthetic_ddr5_like(),
        )

    @staticmethod
    def synthetic_lpddr_like(device_id: str = "LPDDR_SYN_0",
                              density_gb: float = 8.0,
                              data_rate_mt_s: float = 6400) -> "DRAMDevice":
        return DRAMDevice(
            device_id=device_id,
            technology_node_nm=10.0,
            density_gb=density_gb,
            data_rate_mt_s=data_rate_mt_s,
            bus_width_bits=16,
            banks=16,
            bank_groups=4,
            rows=65536,
            columns=2048,
            burst_length=16,
            voltage_v=0.5,
            timing_profile=TimingProfile.synthetic_lpddr_like(data_rate_mt_s),
            refresh_profile=RefreshProfile(
                refresh_interval_ns=1950.0, refresh_duration_ns=140.0
            ),
            power_profile=PowerProfile.synthetic_lpddr_like(),
        )
