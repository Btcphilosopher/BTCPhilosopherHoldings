"""
dramcore.performance.ai_analysis

For AI workloads, compares workload memory demand against DRAM
capability and classifies the limiting factor (spec section 77, 95, 108).
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from dramcore.core.result import EngineeringResult, Fidelity
from dramcore.traffic.ai_workloads import TransformerWorkloadSpec


class AIMemoryVerdict(str, Enum):
    MEMORY_SUFFICIENT = "MEMORY_SUFFICIENT"
    MEMORY_BANDWIDTH_LIMITED = "MEMORY_BANDWIDTH_LIMITED"
    MEMORY_CAPACITY_LIMITED = "MEMORY_CAPACITY_LIMITED"
    MEMORY_LATENCY_LIMITED = "MEMORY_LATENCY_LIMITED"


@dataclass(frozen=True)
class AIMemoryAnalysisResult:
    verdict: AIMemoryVerdict
    weight_bytes: int
    kv_cache_bytes: int
    total_working_set_bytes: int
    available_capacity_bytes: int
    required_bandwidth_gbps: float
    available_bandwidth_gbps: float
    achieved_p99_latency_ns: float
    latency_budget_ns: float
    evidence: dict


def analyse_ai_workload(spec: TransformerWorkloadSpec, target_tokens_per_second: float,
                         available_capacity_bytes: int, available_bandwidth_gbps: float,
                         achieved_p99_latency_ns: float = 0.0,
                         latency_budget_ns: float = float("inf")) -> AIMemoryAnalysisResult:
    """Determine whether an AI workload (as characterised by
    TransformerWorkloadSpec) is capacity-, bandwidth-, or latency-limited
    on the given DRAM topology (spec section 77). The answer comes
    directly from the simulator's own computed quantities -- no
    hard-coded verdict."""
    weight_b = spec.weight_bytes().value
    kv_b = spec.kv_cache_bytes().value
    working_set = weight_b + kv_b
    required_bw = spec.required_bandwidth_gbps(target_tokens_per_second).value

    if working_set > available_capacity_bytes:
        verdict = AIMemoryVerdict.MEMORY_CAPACITY_LIMITED
    elif required_bw > available_bandwidth_gbps:
        verdict = AIMemoryVerdict.MEMORY_BANDWIDTH_LIMITED
    elif achieved_p99_latency_ns > latency_budget_ns:
        verdict = AIMemoryVerdict.MEMORY_LATENCY_LIMITED
    else:
        verdict = AIMemoryVerdict.MEMORY_SUFFICIENT

    evidence = {
        "weight_bytes": weight_b, "kv_cache_bytes": kv_b,
        "total_working_set_bytes": working_set,
        "available_capacity_bytes": available_capacity_bytes,
        "capacity_headroom_bytes": available_capacity_bytes - working_set,
        "required_bandwidth_gbps": required_bw,
        "available_bandwidth_gbps": available_bandwidth_gbps,
        "bandwidth_headroom_gbps": available_bandwidth_gbps - required_bw,
        "achieved_p99_latency_ns": achieved_p99_latency_ns,
        "latency_budget_ns": latency_budget_ns,
    }
    return AIMemoryAnalysisResult(
        verdict=verdict, weight_bytes=int(weight_b), kv_cache_bytes=int(kv_b),
        total_working_set_bytes=int(working_set),
        available_capacity_bytes=available_capacity_bytes,
        required_bandwidth_gbps=required_bw,
        available_bandwidth_gbps=available_bandwidth_gbps,
        achieved_p99_latency_ns=achieved_p99_latency_ns,
        latency_budget_ns=latency_budget_ns,
        evidence=evidence,
    )
