"""
dramcore.performance.engine

Bandwidth and latency analysis (spec section 42-44), queueing saturation
detection (spec section 44), and bottleneck analysis (spec section 75-76).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

import numpy as np

from dramcore.controller.request import MemoryRequest
from dramcore.core.result import EngineeringResult, Fidelity


@dataclass
class LatencyBreakdown:
    """Aggregated latency component statistics across a batch of completed
    requests (spec section 43)."""
    queue_latencies_ns: List[float] = field(default_factory=list)
    total_latencies_ns: List[float] = field(default_factory=list)

    def percentile_table(self) -> Dict[str, float]:
        if not self.total_latencies_ns:
            return {}
        arr = np.array(self.total_latencies_ns)
        return {
            "mean": float(np.mean(arr)),
            "median": float(np.median(arr)),
            "p50": float(np.percentile(arr, 50)),
            "p90": float(np.percentile(arr, 90)),
            "p95": float(np.percentile(arr, 95)),
            "p99": float(np.percentile(arr, 99)),
            "p99.9": float(np.percentile(arr, 99.9)) if len(arr) >= 1000 else float(np.max(arr)),
            "max": float(np.max(arr)),
            "min": float(np.min(arr)),
        }


def compute_bandwidth_gbps(requests: List[MemoryRequest], elapsed_ns: float) -> EngineeringResult:
    total_bytes = sum(r.size_bytes for r in requests if r.completion_time_ns is not None)
    bw = (total_bytes / 1e9) / (elapsed_ns / 1e9) if elapsed_ns > 0 else 0.0
    return EngineeringResult(
        value=bw, unit="GB/s",
        equation="achieved_BW = total_bytes_transferred / elapsed_time",
        inputs={"total_bytes": total_bytes, "elapsed_ns": elapsed_ns,
                "n_requests": len(requests)},
        assumptions=("Elapsed time is the completion time of the last "
                     "request minus the arrival time of the first -- "
                     "reflects sustained achieved bandwidth over the "
                     "measured window, not an instantaneous rate.",),
        fidelity=Fidelity.FIDELITY_2,
    )


def compute_latency_stats(requests: List[MemoryRequest]) -> EngineeringResult:
    completed = [r for r in requests if r.completion_time_ns is not None]
    breakdown = LatencyBreakdown(
        queue_latencies_ns=[r.queue_latency_ns() for r in completed
                             if r.queue_latency_ns() is not None],
        total_latencies_ns=[r.total_latency_ns() for r in completed],
    )
    table = breakdown.percentile_table()
    return EngineeringResult(
        value=table, unit="ns",
        equation="latency = completion_time - arrival_time, aggregated by percentile",
        inputs={"n_completed": len(completed)},
        fidelity=Fidelity.FIDELITY_2,
    )


def row_hit_rate(topology) -> EngineeringResult:
    hits = misses = conflicts = 0
    for _, _, bank in topology.all_banks():
        hits += bank.row_hits
        misses += bank.row_misses
        conflicts += bank.row_conflicts
    total = hits + misses + conflicts
    rate = hits / total if total > 0 else 0.0
    return EngineeringResult(
        value=rate, unit="fraction",
        equation="row_hit_rate = row_hits / (row_hits + row_misses + row_conflicts)",
        inputs={"row_hits": hits, "row_misses": misses, "row_conflicts": conflicts,
                "total_accesses": total},
        fidelity=Fidelity.FIDELITY_2,
    )


@dataclass
class QueueingStats:
    queue_depth_samples: List[int] = field(default_factory=list)
    arrival_rate_req_per_ns: float = 0.0
    service_rate_req_per_ns: float = 0.0

    def utilisation(self) -> float:
        if self.service_rate_req_per_ns <= 0:
            return float("inf")
        return self.arrival_rate_req_per_ns / self.service_rate_req_per_ns

    def is_saturated(self) -> bool:
        return self.utilisation() >= 1.0


def detect_saturation(requests: List[MemoryRequest], achieved_bandwidth_gbps: float,
                       theoretical_bandwidth_gbps: float,
                       saturation_threshold: float = 0.92) -> EngineeringResult:
    ratio = achieved_bandwidth_gbps / theoretical_bandwidth_gbps if theoretical_bandwidth_gbps > 0 else 0.0
    saturated = ratio >= saturation_threshold
    return EngineeringResult(
        value=saturated, unit="bool",
        equation="MEMORY_SATURATION when achieved_BW / theoretical_BW >= threshold",
        inputs={"achieved_bandwidth_gbps": achieved_bandwidth_gbps,
                "theoretical_bandwidth_gbps": theoretical_bandwidth_gbps,
                "ratio": ratio, "saturation_threshold": saturation_threshold},
        fidelity=Fidelity.FIDELITY_1,
    )


class BottleneckType(str, Enum):
    CONTROLLER_BOTTLENECK = "CONTROLLER_BOTTLENECK"
    ROW_CONFLICT_BOTTLENECK = "ROW_CONFLICT_BOTTLENECK"
    REFRESH_BOTTLENECK = "REFRESH_BOTTLENECK"
    BANDWIDTH_BOTTLENECK = "BANDWIDTH_BOTTLENECK"
    LATENCY_BOTTLENECK = "LATENCY_BOTTLENECK"
    THERMAL_BOTTLENECK = "THERMAL_BOTTLENECK"
    NONE_IDENTIFIED = "NONE_IDENTIFIED"


@dataclass(frozen=True)
class BottleneckReport:
    bottleneck: BottleneckType
    evidence: Dict[str, float]
    contribution_pct: float
    possible_design_change: str
    expected_effect: str


def analyse_bottleneck(*, row_hit_rate_value: float, refresh_overhead_fraction: float,
                        bandwidth_saturation_ratio: float, p99_latency_ns: float,
                        mean_latency_ns: float,
                        thermal_throttled: bool = False) -> BottleneckReport:
    """Rule-based bottleneck classifier (spec section 75): given the
    measured evidence, returns the single dominant bottleneck plus a
    concrete design-change suggestion and its expected direction of
    effect. Thresholds are illustrative engineering heuristics, not
    calibrated against silicon."""
    candidates = []

    if thermal_throttled:
        candidates.append(BottleneckReport(
            BottleneckType.THERMAL_BOTTLENECK,
            {"thermal_throttled": 1.0}, 100.0,
            "Improve cooling / reduce refresh multiplier trigger threshold / "
            "lower sustained bandwidth target",
            "Removing thermal throttling should restore full bandwidth/frequency",
        ))
    if refresh_overhead_fraction > 0.08:
        candidates.append(BottleneckReport(
            BottleneckType.REFRESH_BOTTLENECK,
            {"refresh_overhead_fraction": refresh_overhead_fraction},
            refresh_overhead_fraction * 100,
            "Switch to PER_BANK or FINE_GRANULARITY refresh policy, or "
            "reduce refresh_count_multiplier if thermal margin allows",
            "Reduces rank-blocked time proportionally, recovering "
            "bandwidth roughly equal to the overhead fraction removed",
        ))
    if row_hit_rate_value < 0.3:
        candidates.append(BottleneckReport(
            BottleneckType.ROW_CONFLICT_BOTTLENECK,
            {"row_hit_rate": row_hit_rate_value}, (1 - row_hit_rate_value) * 100,
            "Switch scheduler to FR_FCFS, increase queue depth to expose "
            "more reordering opportunity, or use a row-friendlier address "
            "interleaving policy",
            "Higher row-hit rate reduces ACT/PRE round trips per access, "
            "lowering both latency and bandwidth loss from conflicts",
        ))
    if bandwidth_saturation_ratio >= 0.92:
        candidates.append(BottleneckReport(
            BottleneckType.BANDWIDTH_BOTTLENECK,
            {"bandwidth_saturation_ratio": bandwidth_saturation_ratio},
            bandwidth_saturation_ratio * 100,
            "Add channels, widen the bus, or increase data rate",
            "Additional channels scale theoretical bandwidth "
            "near-linearly (see multi-channel scaling experiment)",
        ))
    if mean_latency_ns > 0 and p99_latency_ns > 5 * mean_latency_ns:
        candidates.append(BottleneckReport(
            BottleneckType.LATENCY_BOTTLENECK,
            {"p99_latency_ns": p99_latency_ns, "mean_latency_ns": mean_latency_ns},
            (p99_latency_ns / mean_latency_ns) * 10,
            "Use a deadline-aware or priority scheduler for latency-"
            "sensitive sources; consider reducing queue depth to bound "
            "worst-case queueing delay",
            "Reduces tail latency at the cost of some average-case "
            "bandwidth efficiency",
        ))

    if not candidates:
        return BottleneckReport(BottleneckType.NONE_IDENTIFIED, {}, 0.0,
                                 "No dominant bottleneck identified under current thresholds",
                                 "N/A")
    return max(candidates, key=lambda c: c.contribution_pct)


class WorkloadBound(str, Enum):
    COMPUTE_BOUND = "COMPUTE_BOUND"
    MEMORY_BANDWIDTH_BOUND = "MEMORY_BANDWIDTH_BOUND"
    MEMORY_LATENCY_BOUND = "MEMORY_LATENCY_BOUND"


def roofline_analysis(compute_rate_flops: float, memory_bandwidth_gbps: float,
                       bytes_per_operation: float,
                       achieved_flops: float) -> EngineeringResult:
    """Roofline-style memory analysis (spec section 76). arithmetic
    intensity = flops / byte. The workload is memory-bandwidth-bound if
    the compute rate implied by available bandwidth * arithmetic
    intensity is below the peak compute rate."""
    if bytes_per_operation <= 0:
        raise ValueError("bytes_per_operation must be > 0")
    arithmetic_intensity = 1.0 / bytes_per_operation  # flops per byte, if bytes_per_operation is bytes/flop
    memory_bound_flops = memory_bandwidth_gbps * 1e9 * arithmetic_intensity
    ridge_point = compute_rate_flops / (memory_bandwidth_gbps * 1e9) if memory_bandwidth_gbps > 0 else float("inf")

    if memory_bound_flops < compute_rate_flops:
        bound = WorkloadBound.MEMORY_BANDWIDTH_BOUND
    else:
        bound = WorkloadBound.COMPUTE_BOUND

    return EngineeringResult(
        value=bound.value, unit="classification",
        equation="bound = MEMORY_BANDWIDTH_BOUND if (BW * arithmetic_intensity) < peak_compute_rate else COMPUTE_BOUND",
        inputs={"compute_rate_flops": compute_rate_flops,
                "memory_bandwidth_gbps": memory_bandwidth_gbps,
                "bytes_per_operation": bytes_per_operation,
                "arithmetic_intensity_flops_per_byte": arithmetic_intensity,
                "memory_bound_flops_ceiling": memory_bound_flops,
                "ridge_point_flops_per_byte": ridge_point,
                "achieved_flops": achieved_flops},
        assumptions=("Classic roofline model; does not separately account "
                     "for memory-latency-bound regimes (low-occupancy, "
                     "poor overlap) -- see AI memory analysis for a "
                     "latency-aware classification.",),
        fidelity=Fidelity.FIDELITY_1,
    )
