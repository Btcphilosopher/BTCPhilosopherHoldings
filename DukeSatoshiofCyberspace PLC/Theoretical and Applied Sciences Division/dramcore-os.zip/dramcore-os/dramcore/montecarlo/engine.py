"""
dramcore.montecarlo.engine

Monte Carlo engine (spec section 52-53): randomises configurable
parameters (timing margin, temperature, voltage, request-pattern seed)
across many simulation runs and reports percentile distributions of the
output metrics.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

import numpy as np

from dramcore.core.result import EngineeringResult, Fidelity


@dataclass(frozen=True)
class VariationSpec:
    """A single randomised input parameter: sampled as
    nominal * (1 + N(0, sigma_fraction)), clipped to [min_mult, max_mult]
    times nominal."""
    name: str
    nominal: float
    sigma_fraction: float
    min_multiplier: float = 0.5
    max_multiplier: float = 1.5

    def sample(self, rng: np.random.Generator, n: int) -> np.ndarray:
        mult = 1.0 + rng.normal(0.0, self.sigma_fraction, size=n)
        mult = np.clip(mult, self.min_multiplier, self.max_multiplier)
        return self.nominal * mult


@dataclass
class MonteCarloEngine:
    variations: List[VariationSpec] = field(default_factory=list)

    def sample_inputs(self, n_trials: int, seed: Optional[int] = None) -> Dict[str, np.ndarray]:
        rng = np.random.default_rng(seed)
        return {v.name: v.sample(rng, n_trials) for v in self.variations}

    def run(self, trial_fn: Callable[..., Dict[str, float]], n_trials: int,
            seed: Optional[int] = None,
            output_metrics: Optional[List[str]] = None) -> "MonteCarloResult":
        """`trial_fn` receives the sampled parameters for one trial as
        kwargs (matching each VariationSpec.name) plus `trial_seed`, and
        must return a dict of output metric name -> value."""
        sampled = self.sample_inputs(n_trials, seed)
        rng = np.random.default_rng((seed or 0) + 999983)
        trial_seeds = rng.integers(0, 2**31 - 1, size=n_trials)

        outputs: Dict[str, List[float]] = {}
        for i in range(n_trials):
            kwargs = {name: float(arr[i]) for name, arr in sampled.items()}
            kwargs["trial_seed"] = int(trial_seeds[i])
            result = trial_fn(**kwargs)
            for k, v in result.items():
                outputs.setdefault(k, []).append(v)

        return MonteCarloResult(n_trials=n_trials, sampled_inputs=sampled, outputs=outputs)


@dataclass
class MonteCarloResult:
    n_trials: int
    sampled_inputs: Dict[str, np.ndarray]
    outputs: Dict[str, List[float]]

    def percentiles(self, metric: str,
                     ps=(1, 5, 10, 50, 90, 95, 99)) -> EngineeringResult:
        arr = np.array(self.outputs[metric])
        table = {f"P{p}": float(np.percentile(arr, p)) for p in ps}
        table["mean"] = float(np.mean(arr))
        table["std"] = float(np.std(arr))
        return EngineeringResult(
            value=table, unit="metric-dependent",
            equation=f"percentiles of '{metric}' across {self.n_trials} Monte Carlo trials",
            inputs={"n_trials": self.n_trials, "metric": metric},
            assumptions=("Trials are independent draws from the configured "
                         "VariationSpec distributions; no cross-trial "
                         "correlation modelled.",),
            fidelity=Fidelity.FIDELITY_1,
        )

    def summary(self) -> Dict[str, Dict[str, float]]:
        return {m: self.percentiles(m).value for m in self.outputs}
