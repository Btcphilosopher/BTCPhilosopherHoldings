"""
dramcore.refresh.engine

First-class refresh subsystem (spec section 27-28). Tracks, per rank, when
the next refresh is due, issues REF commands through the timing engine
(which enforces tRFC), and measures the performance cost of refresh
(fraction of time each rank spends blocked for refresh).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from dramcore.bank.bank import BankState
from dramcore.core.clock import EventLog, EventType, SimulationClock
from dramcore.core.result import EngineeringResult, Fidelity
from dramcore.rank.rank import DRAMRank
from dramcore.refresh.profile import RefreshPolicy, RefreshProfile
from dramcore.timing.engine import TimingEngine


@dataclass
class RefreshEngine:
    profile: RefreshProfile
    timing_engine: TimingEngine

    next_refresh_due_ns: Dict[int, float] = field(default_factory=dict)  # per rank_id
    last_refresh_ns: Dict[int, Optional[float]] = field(default_factory=dict)
    refresh_count: Dict[int, int] = field(default_factory=dict)
    total_blocked_ns: Dict[int, float] = field(default_factory=dict)

    def register_rank(self, rank_id: int, start_time_ns: float = 0.0) -> None:
        self.next_refresh_due_ns[rank_id] = start_time_ns + self.profile.effective_interval_ns()
        self.last_refresh_ns[rank_id] = None
        self.refresh_count[rank_id] = 0
        self.total_blocked_ns[rank_id] = 0.0

    def is_due(self, rank_id: int, now_ns: float) -> bool:
        return now_ns >= self.next_refresh_due_ns.get(rank_id, float("inf"))

    def all_banks_idle(self, rank: DRAMRank) -> bool:
        return all(b.state == BankState.IDLE for b in rank.banks.values())

    def issue_refresh(self, rank: DRAMRank, now_ns: float,
                       clock: SimulationClock, log: EventLog) -> float:
        """Issue a REF for this rank at (or after) `now_ns`. Returns the
        timestamp at which the rank becomes available again (now +
        tRFC). Caller (controller) is responsible for ensuring all banks
        are precharged before calling this -- validate_refresh will raise
        otherwise."""
        earliest = self.timing_engine.earliest_refresh_time(
            rank, self.last_refresh_ns[rank.rank_id]
        )
        issue_time = max(now_ns, earliest)

        for bank in rank.banks.values():
            bank.begin_refresh(issue_time)
        log.record(clock, EventType.REFRESH_ISSUED, rank_id=rank.rank_id,
                   time_ns=issue_time)

        completion_time = issue_time + self.profile.refresh_duration_ns
        for bank in rank.banks.values():
            bank.end_refresh()

        self.last_refresh_ns[rank.rank_id] = issue_time
        self.refresh_count[rank.rank_id] += 1
        self.next_refresh_due_ns[rank.rank_id] = issue_time + self.profile.effective_interval_ns()
        self.total_blocked_ns[rank.rank_id] += self.profile.refresh_duration_ns

        log.record(clock, EventType.REFRESH_COMPLETED, rank_id=rank.rank_id,
                   time_ns=completion_time)
        return completion_time

    def refresh_overhead(self, rank_id: int, total_elapsed_ns: float) -> EngineeringResult:
        """Fraction of total simulated time this rank spent blocked
        servicing refresh -- the direct 'performance cost' the spec asks
        for (section 27)."""
        blocked = self.total_blocked_ns.get(rank_id, 0.0)
        frac = blocked / total_elapsed_ns if total_elapsed_ns > 0 else 0.0
        return EngineeringResult(
            value=frac, unit="fraction",
            equation="refresh_overhead = total_refresh_blocked_time / total_elapsed_time",
            inputs={"rank_id": rank_id, "total_blocked_ns": blocked,
                    "total_elapsed_ns": total_elapsed_ns,
                    "refresh_count": self.refresh_count.get(rank_id, 0)},
            assumptions=("ALL_BANK refresh policy blocks the entire rank for "
                         "the full tRFC duration; PER_BANK/FINE_GRANULARITY "
                         "policies would reduce (but not eliminate) this.",),
            fidelity=Fidelity.FIDELITY_2,
        )
