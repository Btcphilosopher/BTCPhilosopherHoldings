"""
dramcore.refresh.profile

Refresh policy configuration (spec section 27, 84).
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from dramcore.core.result import InvalidConfigurationError


class RefreshPolicy(str, Enum):
    ALL_BANK = "ALL_BANK"                 # REF blocks the whole rank
    PER_BANK = "PER_BANK"                 # REF issued per-bank, others stay available
    FINE_GRANULARITY = "FINE_GRANULARITY"  # REFsb-style, smaller/more-frequent refreshes


@dataclass(frozen=True)
class RefreshProfile:
    name: str = "unnamed_refresh_profile"
    policy: RefreshPolicy = RefreshPolicy.ALL_BANK
    refresh_interval_ns: float = 3900.0     # tREFI
    refresh_duration_ns: float = 295.0      # tRFC
    banks_per_refresh_burst: int = 1        # for PER_BANK/FINE_GRANULARITY
    refresh_count_multiplier: float = 1.0   # 1x/2x/4x refresh-rate modes (thermal-driven)

    def __post_init__(self):
        if self.refresh_interval_ns <= 0:
            raise InvalidConfigurationError("refresh_interval_ns must be > 0")
        if self.refresh_duration_ns <= 0:
            raise InvalidConfigurationError("refresh_duration_ns must be > 0")
        if self.refresh_count_multiplier <= 0:
            raise InvalidConfigurationError("refresh_count_multiplier must be > 0")
        if self.banks_per_refresh_burst < 1:
            raise InvalidConfigurationError("banks_per_refresh_burst must be >= 1")

    def effective_interval_ns(self) -> float:
        """Higher refresh_count_multiplier (e.g. 2x refresh under thermal
        stress) shortens the effective interval between refreshes."""
        return self.refresh_interval_ns / self.refresh_count_multiplier
