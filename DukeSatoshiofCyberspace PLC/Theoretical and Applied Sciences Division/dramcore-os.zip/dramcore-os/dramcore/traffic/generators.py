"""
dramcore.traffic.generators

Synthetic memory traffic generators (spec section 38). Each generator
produces a deterministic (given a seed) list of ``MemoryRequest`` objects
with explicit arrival times, addresses, sizes, and operations -- these
feed directly into the memory controller.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import numpy as np

from dramcore.controller.request import MemoryRequest, RequestOperation
from dramcore.core.result import InvalidConfigurationError


def _op_for_rw_mix(rng: np.random.Generator, write_fraction: float) -> RequestOperation:
    return RequestOperation.WRITE if rng.random() < write_fraction else RequestOperation.READ


@dataclass
class TrafficConfig:
    n_requests: int
    address_space_bytes: int
    request_size_bytes: int = 64
    write_fraction: float = 0.3
    mean_inter_arrival_ns: float = 2.0
    source: str = "generic"
    seed: Optional[int] = None
    start_time_ns: float = 0.0

    def __post_init__(self):
        if self.n_requests < 0:
            raise InvalidConfigurationError("n_requests must be >= 0")
        if self.address_space_bytes <= 0:
            raise InvalidConfigurationError("address_space_bytes must be > 0")
        if not (0.0 <= self.write_fraction <= 1.0):
            raise InvalidConfigurationError("write_fraction must be in [0,1]")
        if self.mean_inter_arrival_ns < 0:
            raise InvalidConfigurationError("mean_inter_arrival_ns must be >= 0")


def _make_arrival_times(cfg: TrafficConfig, rng: np.random.Generator, poisson: bool) -> np.ndarray:
    if cfg.mean_inter_arrival_ns == 0:
        gaps = np.zeros(cfg.n_requests)
    elif poisson:
        gaps = rng.exponential(cfg.mean_inter_arrival_ns, size=cfg.n_requests)
    else:
        gaps = np.full(cfg.n_requests, cfg.mean_inter_arrival_ns)
    return cfg.start_time_ns + np.cumsum(gaps) - gaps[0] if cfg.n_requests > 0 else np.array([])


def _build(cfg: TrafficConfig, addresses: np.ndarray, arrivals: np.ndarray,
           rng: np.random.Generator, id_offset: int = 0) -> List[MemoryRequest]:
    reqs = []
    for i in range(cfg.n_requests):
        op = _op_for_rw_mix(rng, cfg.write_fraction)
        reqs.append(MemoryRequest(
            request_id=id_offset + i,
            timestamp_ns=float(arrivals[i]),
            address=int(addresses[i]) % cfg.address_space_bytes,
            size_bytes=cfg.request_size_bytes,
            operation=op,
            source=cfg.source,
        ))
    return reqs


def sequential_read(cfg: TrafficConfig, id_offset: int = 0) -> List[MemoryRequest]:
    """Monotonically increasing address, maximally row-buffer-friendly."""
    rng = np.random.default_rng(cfg.seed)
    addrs = np.arange(cfg.n_requests, dtype=np.int64) * cfg.request_size_bytes
    arrivals = _make_arrival_times(cfg, rng, poisson=False)
    cfg2 = TrafficConfig(**{**cfg.__dict__, "write_fraction": 0.0})
    return _build(cfg2, addrs, arrivals, rng, id_offset)


def sequential_write(cfg: TrafficConfig, id_offset: int = 0) -> List[MemoryRequest]:
    rng = np.random.default_rng(cfg.seed)
    addrs = np.arange(cfg.n_requests, dtype=np.int64) * cfg.request_size_bytes
    arrivals = _make_arrival_times(cfg, rng, poisson=False)
    cfg2 = TrafficConfig(**{**cfg.__dict__, "write_fraction": 1.0})
    return _build(cfg2, addrs, arrivals, rng, id_offset)


def random_traffic(cfg: TrafficConfig, id_offset: int = 0) -> List[MemoryRequest]:
    """Uniform-random address, low row-buffer locality by construction."""
    rng = np.random.default_rng(cfg.seed)
    n_slots = max(1, cfg.address_space_bytes // cfg.request_size_bytes)
    slot_idx = rng.integers(0, n_slots, size=cfg.n_requests)
    addrs = slot_idx.astype(np.int64) * cfg.request_size_bytes
    arrivals = _make_arrival_times(cfg, rng, poisson=True)
    return _build(cfg, addrs, arrivals, rng, id_offset)


def strided(cfg: TrafficConfig, stride_bytes: int, id_offset: int = 0) -> List[MemoryRequest]:
    """Fixed-stride access pattern -- common in scientific/array-processing
    codes; locality depends on how stride relates to row/page size."""
    if stride_bytes <= 0:
        raise InvalidConfigurationError("stride_bytes must be > 0")
    rng = np.random.default_rng(cfg.seed)
    addrs = (np.arange(cfg.n_requests, dtype=np.int64) * stride_bytes)
    arrivals = _make_arrival_times(cfg, rng, poisson=False)
    return _build(cfg, addrs, arrivals, rng, id_offset)


def pointer_chase(cfg: TrafficConfig, id_offset: int = 0) -> List[MemoryRequest]:
    """Each access's address is a pseudo-random function of the previous
    one (simulating linked-list / graph traversal): strictly serial
    dependency chain, worst-case for latency hiding since no request can
    be issued before the previous one's data (its 'next pointer') returns.
    We approximate the dependency by spacing arrivals with the *previous*
    request's expected service latency instead of a fixed inter-arrival
    time, and choose addresses via a random permutation walk."""
    rng = np.random.default_rng(cfg.seed)
    n_slots = max(1, cfg.address_space_bytes // cfg.request_size_bytes)
    perm = rng.permutation(n_slots)
    idx = np.arange(cfg.n_requests) % n_slots
    addrs = perm[idx].astype(np.int64) * cfg.request_size_bytes
    # pointer-chase arrivals are spaced by an assumed round-trip latency
    # (mean_inter_arrival_ns here represents that assumed RTT, not a
    # Poisson generation rate, since requests are serially dependent)
    arrivals = cfg.start_time_ns + np.arange(cfg.n_requests) * cfg.mean_inter_arrival_ns
    cfg2 = TrafficConfig(**{**cfg.__dict__, "write_fraction": 0.0})
    return _build(cfg2, addrs, arrivals, rng, id_offset)


def bursty(cfg: TrafficConfig, burst_size: int, burst_gap_ns: float,
           id_offset: int = 0) -> List[MemoryRequest]:
    """Requests arrive in tight bursts of `burst_size`, separated by idle
    gaps of `burst_gap_ns` -- models bursty CPU/GPU issue behaviour rather
    than a smooth Poisson stream."""
    if burst_size <= 0:
        raise InvalidConfigurationError("burst_size must be > 0")
    rng = np.random.default_rng(cfg.seed)
    n_slots = max(1, cfg.address_space_bytes // cfg.request_size_bytes)
    arrivals = np.zeros(cfg.n_requests)
    t = cfg.start_time_ns
    for i in range(cfg.n_requests):
        if i > 0 and i % burst_size == 0:
            t += burst_gap_ns
        arrivals[i] = t
        t += max(cfg.mean_inter_arrival_ns, 0.1)
    addrs = rng.integers(0, n_slots, size=cfg.n_requests).astype(np.int64) * cfg.request_size_bytes
    return _build(cfg, addrs, arrivals, rng, id_offset)


def mixed(cfg: TrafficConfig, sequential_fraction: float = 0.5,
          id_offset: int = 0) -> List[MemoryRequest]:
    """Blend of sequential and random requests, interleaved by arrival
    order -- approximates a realistic mixed application workload."""
    rng = np.random.default_rng(cfg.seed)
    n_seq = int(cfg.n_requests * sequential_fraction)
    n_rand = cfg.n_requests - n_seq
    seq_cfg = TrafficConfig(**{**cfg.__dict__, "n_requests": n_seq})
    rand_cfg = TrafficConfig(**{**cfg.__dict__, "n_requests": n_rand,
                                 "seed": None if cfg.seed is None else cfg.seed + 1})
    seq_reqs = sequential_read(seq_cfg, id_offset)
    rand_reqs = random_traffic(rand_cfg, id_offset + n_seq)
    combined = sorted(seq_reqs + rand_reqs, key=lambda r: r.timestamp_ns)
    return combined


def multi_source(cfgs: List[TrafficConfig]) -> List[MemoryRequest]:
    """Merge several TrafficConfig-generated streams (with distinct
    `source` tags) into a single arrival-ordered stream -- used for
    multi-thread / multi-core / GPU-vs-CPU traffic mixing (spec 38)."""
    all_reqs: List[MemoryRequest] = []
    offset = 0
    for cfg in cfgs:
        reqs = random_traffic(cfg, id_offset=offset)
        all_reqs.extend(reqs)
        offset += len(reqs)
    return sorted(all_reqs, key=lambda r: r.timestamp_ns)
