"""
dramcore.traffic.ai_workloads

Synthetic memory traffic models for AI workloads (spec section 39) and the
AI memory demand analysis used to classify a workload as
capacity/bandwidth/latency bound (spec section 77, 95).

These are explicitly SYNTHETIC traffic models derived from the declared
architecture of a transformer-style model (layer count, hidden dimension,
heads, sequence length, batch size) -- they do NOT reproduce a trace from
any real AI framework (spec section 39). Real traces can be imported via
dramcore.traces.trace_import for direct comparison.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np

from dramcore.controller.request import MemoryRequest, RequestOperation
from dramcore.core.result import EngineeringResult, Fidelity, InvalidConfigurationError


@dataclass(frozen=True)
class TransformerWorkloadSpec:
    num_layers: int
    hidden_dim: int
    num_heads: int
    seq_len: int
    batch_size: int
    vocab_size: int = 32000
    dtype_bytes: int = 2          # bf16/fp16
    ffn_multiplier: int = 4       # FFN inner dim = ffn_multiplier * hidden_dim
    use_kv_cache: bool = True
    mode: str = "inference_decode"  # "inference_decode" | "inference_prefill" | "training"

    def __post_init__(self):
        for name in ("num_layers", "hidden_dim", "num_heads", "seq_len", "batch_size"):
            if getattr(self, name) <= 0:
                raise InvalidConfigurationError(f"{name} must be > 0")
        if self.hidden_dim % self.num_heads != 0:
            raise InvalidConfigurationError("hidden_dim must be divisible by num_heads")

    @property
    def head_dim(self) -> int:
        return self.hidden_dim // self.num_heads

    # -- weight traffic -----------------------------------------------
    def weight_params_per_layer(self) -> int:
        h = self.hidden_dim
        ffn = self.ffn_multiplier * h
        attn_params = 4 * h * h           # Q,K,V,O projections
        ffn_params = 2 * h * ffn          # up + down projections
        return attn_params + ffn_params

    def total_weight_params(self) -> int:
        per_layer = self.weight_params_per_layer()
        embedding_params = self.vocab_size * self.hidden_dim * 2  # in + out embedding
        return self.num_layers * per_layer + embedding_params

    def weight_bytes(self) -> EngineeringResult:
        params = self.total_weight_params()
        b = params * self.dtype_bytes
        return EngineeringResult(
            value=b, unit="bytes",
            equation="weight_bytes = total_params * dtype_bytes",
            inputs={"total_params": params, "dtype_bytes": self.dtype_bytes},
            assumptions=("Dense (non-MoE) transformer parameter count "
                         "estimate: 4*h^2 attention + 2*h*ffn FFN per layer "
                         "plus input/output embeddings.",),
            fidelity=Fidelity.FIDELITY_1,
        )

    # -- KV cache traffic -----------------------------------------------
    def kv_cache_bytes(self) -> EngineeringResult:
        """KV cache size = 2 (K and V) * layers * batch * seq_len * hidden_dim * dtype_bytes"""
        if not self.use_kv_cache:
            b = 0
        else:
            b = 2 * self.num_layers * self.batch_size * self.seq_len * self.hidden_dim \
                * self.dtype_bytes
        return EngineeringResult(
            value=b, unit="bytes",
            equation="kv_bytes = 2 * layers * batch * seq_len * hidden_dim * dtype_bytes",
            inputs={"num_layers": self.num_layers, "batch_size": self.batch_size,
                    "seq_len": self.seq_len, "hidden_dim": self.hidden_dim,
                    "dtype_bytes": self.dtype_bytes},
            fidelity=Fidelity.FIDELITY_1,
        )

    # -- activation traffic ----------------------------------------------
    def activation_bytes_per_token(self) -> EngineeringResult:
        """Rough per-token activation footprint touched per layer
        (residual stream + attention intermediate + FFN intermediate)."""
        h = self.hidden_dim
        ffn = self.ffn_multiplier * h
        per_layer = (h            # residual stream
                     + 3 * h      # Q,K,V vectors for this token
                     + h          # attention output
                     + ffn)       # FFN intermediate
        total = self.num_layers * per_layer * self.dtype_bytes
        return EngineeringResult(
            value=total, unit="bytes/token",
            equation="act_bytes_per_token = layers * (residual + qkv + attn_out + ffn) * dtype_bytes",
            inputs={"num_layers": self.num_layers, "hidden_dim": h, "ffn_dim": ffn},
            assumptions=("Simplified activation footprint; does not "
                         "account for fused-kernel intermediate reuse "
                         "that real implementations exploit to reduce "
                         "DRAM traffic.",),
            fidelity=Fidelity.FIDELITY_1,
        )

    def read_write_ratio(self) -> float:
        """Decode-mode inference is heavily read-dominated (weights + KV
        cache read every token, KV cache write is comparatively tiny).
        Training has a much higher write fraction (gradients, optimiser
        state, activation checkpointing)."""
        if self.mode == "training":
            return 0.55  # write fraction, illustrative
        return 0.05  # write fraction for inference decode/prefill

    # -- total per-token / per-batch traffic -----------------------------
    def bytes_per_decode_step(self) -> EngineeringResult:
        """In decode mode, EVERY weight byte must be streamed from DRAM
        once per generated token per batch element sharing that forward
        pass (weights are batch-shared, read once per step regardless of
        batch size, assuming they fit and are reloaded/streamed each
        step in this simplified model), plus the full KV cache is read
        each step (self-attention over all past tokens), plus a small KV
        cache append write."""
        w = self.weight_bytes().value
        kv = self.kv_cache_bytes().value
        act = self.activation_bytes_per_token().value * self.batch_size
        total = w + kv + act
        return EngineeringResult(
            value=total, unit="bytes/step",
            equation="bytes_per_step = weight_bytes + kv_cache_bytes + activation_bytes*batch",
            inputs={"weight_bytes": w, "kv_cache_bytes": kv,
                    "activation_bytes_total": act},
            assumptions=("Decode-mode model: weights streamed fully each "
                         "step (no cross-step weight residency assumed); "
                         "this is a conservative (traffic-maximising) "
                         "estimate -- real systems may keep weights "
                         "resident in on-chip cache/SRAM across steps if "
                         "they fit.",),
            fidelity=Fidelity.FIDELITY_1,
        )

    def required_bandwidth_gbps(self, target_tokens_per_second: float) -> EngineeringResult:
        bytes_per_step = self.bytes_per_decode_step().value
        bw = bytes_per_step * target_tokens_per_second / 1e9
        return EngineeringResult(
            value=bw, unit="GB/s",
            equation="required_BW = bytes_per_step * target_tokens_per_second / 1e9",
            inputs={"bytes_per_step": bytes_per_step,
                    "target_tokens_per_second": target_tokens_per_second},
            fidelity=Fidelity.FIDELITY_1,
        )


def generate_transformer_decode_trace(spec: TransformerWorkloadSpec, n_steps: int,
                                       address_space_bytes: int,
                                       step_period_ns: float, seed: int = 0,
                                       source: str = "ai_accelerator",
                                       request_size_bytes: int = 256) -> List[MemoryRequest]:
    """Generate a synthetic request trace for `n_steps` decode steps. Each
    step issues a burst of read requests approximating weight-streaming +
    KV-cache read, plus a small tail of write requests for the KV-cache
    append -- spread across `step_period_ns` of simulated time."""
    rng = np.random.default_rng(seed)
    bytes_per_step = spec.bytes_per_decode_step().value
    write_fraction = spec.read_write_ratio()
    n_reqs_per_step = max(1, int(bytes_per_step / request_size_bytes / 1e4))  # scaled down for tractable sim
    n_reqs_per_step = min(n_reqs_per_step, 20000)

    reqs: List[MemoryRequest] = []
    rid = 0
    for step in range(n_steps):
        step_start = step * step_period_ns
        # weights + KV reads are largely sequential-ish per layer (high
        # locality); model as sequential-within-step with random layer start
        base_addr = int(rng.integers(0, max(1, address_space_bytes - n_reqs_per_step * request_size_bytes)))
        arrivals = step_start + np.linspace(0, step_period_ns * 0.9, n_reqs_per_step)
        for i in range(n_reqs_per_step):
            is_write = rng.random() < write_fraction
            addr = (base_addr + i * request_size_bytes) % address_space_bytes
            reqs.append(MemoryRequest(
                request_id=rid, timestamp_ns=float(arrivals[i]), address=addr,
                size_bytes=request_size_bytes,
                operation=RequestOperation.WRITE if is_write else RequestOperation.READ,
                source=source,
            ))
            rid += 1
    return reqs
