"""
dramcore.commands.command

Explicit DRAM command representation (spec section 18). The command set
supported is protocol-configurable (spec section 18) via
``CommandType`` -- a generic DDR-class command set is provided; a
different DRAM protocol (e.g. GDDR, HBM) could subclass or supply an
alternate enum without changing the timing-engine algorithm.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Optional


class CommandType(str, Enum):
    ACT = "ACT"     # activate a row
    PRE = "PRE"     # precharge a bank (or PREA: all banks, via arguments)
    RD = "RD"       # column read
    WR = "WR"       # column write
    REF = "REF"     # refresh
    SREF_ENTRY = "SREF_ENTRY"
    SREF_EXIT = "SREF_EXIT"
    PDE = "PDE"     # power-down entry
    PDX = "PDX"     # power-down exit


@dataclass(frozen=True)
class DRAMCommand:
    command_type: CommandType
    timestamp_ns: float
    channel: int
    rank: int
    bank_group: int = 0
    bank: int = 0
    row: Optional[int] = None
    column: Optional[int] = None
    duration_ns: float = 0.0
    arguments: Dict[str, Any] = field(default_factory=dict)
    timing_constraints: Dict[str, float] = field(default_factory=dict)
    request_id: Optional[int] = None

    def target_key(self) -> tuple:
        return (self.channel, self.rank, self.bank_group, self.bank)

    def rank_key(self) -> tuple:
        return (self.channel, self.rank)

    def bank_group_key(self) -> tuple:
        return (self.channel, self.rank, self.bank_group)

    def __repr__(self) -> str:
        loc = f"ch{self.channel}.rk{self.rank}.bg{self.bank_group}.bk{self.bank}"
        extra = f" row=0x{self.row:x}" if self.row is not None else ""
        return f"<{self.command_type.value} @{self.timestamp_ns:.1f}ns {loc}{extra}>"
