"""
dramcore.array.sense_amp

Conceptual sense-amplifier / bitline abstraction (spec sections 10-11).
Encodes the architectural fact that a DRAM read is destructive and
requires restore: activating a row moves its charge onto the bitline,
the sense amplifier detects a small differential voltage and amplifies
it to a full-rail value, and that value is *written back* into the cell
(restore) as part of activation -- the row then stays "open" in the row
buffer until precharge.

This is a timing/architectural abstraction (FIDELITY_1), not a bitline
electrical/SPICE simulation.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from dramcore.core.result import EngineeringResult, Fidelity, InvalidConfigurationError


class BitlineState(str, Enum):
    PRECHARGED = "PRECHARGED"       # bitline equalised at Vdd/2, ready for next ACT
    DEVELOPING = "DEVELOPING"       # cell charge sharing onto the bitline in progress
    SENSED = "SENSED"               # sense amp has latched/amplified the differential
    RESTORED = "RESTORED"           # cell has been rewritten (restore complete)


@dataclass(frozen=True)
class BitlineElectricalParams:
    """Simplified lumped electrical parameters for the bitline (spec
    section 11). Used only to derive an illustrative sense-delay estimate
    -- not a substitute for real bitline RC extraction."""
    bitline_capacitance_ff: float = 250.0
    bitline_resistance_ohm: float = 800.0
    cell_capacitance_ff: float = 25.0
    supply_voltage_v: float = 1.1
    sense_amp_gain: float = 1e4  # dimensionless amplification factor

    def __post_init__(self):
        for attr in ("bitline_capacitance_ff", "bitline_resistance_ohm",
                     "cell_capacitance_ff", "supply_voltage_v", "sense_amp_gain"):
            if getattr(self, attr) <= 0:
                raise InvalidConfigurationError(f"{attr} must be > 0")

    def charge_sharing_voltage(self) -> EngineeringResult:
        """Differential voltage developed on the bitline immediately after
        cell/bitline charge sharing:
            dV = Vdd * Ccell / (Ccell + Cbitline)
        This is the classic DRAM charge-sharing formula -- a FIDELITY_1
        architectural approximation of the real analog signal development.
        """
        c_cell = self.cell_capacitance_ff
        c_bl = self.bitline_capacitance_ff
        dv = self.supply_voltage_v * c_cell / (c_cell + c_bl)
        return EngineeringResult(
            value=dv, unit="V",
            equation="dV = Vdd * Ccell / (Ccell + Cbitline)",
            inputs={"Vdd": self.supply_voltage_v, "Ccell_fF": c_cell,
                    "Cbitline_fF": c_bl},
            assumptions=(
                "Ideal charge sharing, no parasitic leakage during "
                "development, single lumped bitline capacitance.",
                "Does not model bitline resistance distribution or "
                "twisted-bitline noise cancellation.",
            ),
            fidelity=Fidelity.FIDELITY_1,
        )

    def rc_time_constant_ns(self) -> float:
        """tau = R * C, converted to ns. R[ohm]*C[fF] = R*C*1e-15 s ->
        convert to ns by *1e9 => R*C*1e-6 ns."""
        return self.bitline_resistance_ohm * self.bitline_capacitance_ff * 1e-6


@dataclass
class SenseAmplifier:
    """A single sense amplifier serving one bitline pair, with mutable
    lifecycle state used by the row-buffer / bank models."""
    electrical: BitlineElectricalParams = None
    state: BitlineState = BitlineState.PRECHARGED

    def __post_init__(self):
        if self.electrical is None:
            self.electrical = BitlineElectricalParams()

    def begin_development(self) -> None:
        if self.state != BitlineState.PRECHARGED:
            raise InvalidConfigurationError(
                f"Cannot begin development from state {self.state}"
            )
        self.state = BitlineState.DEVELOPING

    def sense(self) -> None:
        if self.state != BitlineState.DEVELOPING:
            raise InvalidConfigurationError(f"Cannot sense from state {self.state}")
        self.state = BitlineState.SENSED

    def restore(self) -> None:
        if self.state != BitlineState.SENSED:
            raise InvalidConfigurationError(f"Cannot restore from state {self.state}")
        self.state = BitlineState.RESTORED

    def precharge(self) -> None:
        self.state = BitlineState.PRECHARGED
