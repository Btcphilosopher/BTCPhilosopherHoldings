"""
dramcore.array.row_buffer

Per-bank row buffer state (spec sections 8-9). Classifies each incoming
access against the currently-open row as a ROW HIT, ROW MISS (buffer was
closed/empty), or ROW CONFLICT (a different row is open and must be
precharged first).
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class RowBufferState(str, Enum):
    EMPTY = "EMPTY"          # no row currently open (closed-page / just precharged)
    OPEN = "OPEN"            # a row is open and active


class AccessClassification(str, Enum):
    ROW_HIT = "ROW_HIT"
    ROW_MISS = "ROW_MISS"
    ROW_CONFLICT = "ROW_CONFLICT"


@dataclass
class RowBuffer:
    bank_id: int
    active_row: Optional[int] = None
    state: RowBufferState = RowBufferState.EMPTY
    activation_timestamp_ns: Optional[float] = None

    def classify(self, requested_row: int) -> AccessClassification:
        if self.state == RowBufferState.EMPTY:
            return AccessClassification.ROW_MISS
        if self.active_row == requested_row:
            return AccessClassification.ROW_HIT
        return AccessClassification.ROW_CONFLICT

    def open_row(self, row: int, timestamp_ns: float) -> None:
        self.active_row = row
        self.state = RowBufferState.OPEN
        self.activation_timestamp_ns = timestamp_ns

    def close(self) -> None:
        self.active_row = None
        self.state = RowBufferState.EMPTY
        self.activation_timestamp_ns = None

    def row_open_duration_ns(self, now_ns: float) -> Optional[float]:
        if self.state != RowBufferState.OPEN or self.activation_timestamp_ns is None:
            return None
        return now_ns - self.activation_timestamp_ns
