"""
dramcore.channel.channel

DRAM channel model (spec section 15). Bandwidth is always *calculated*
from explicit device/topology parameters -- never hard-coded (spec
section 15, 42).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from dramcore.core.result import EngineeringResult, Fidelity, InvalidConfigurationError
from dramcore.device.dram_device import DRAMDevice
from dramcore.rank.rank import DRAMRank


@dataclass
class DRAMChannel:
    channel_id: int
    device_template: DRAMDevice
    n_ranks: int = 1
    devices_per_rank: int = 1
    protocol: str = "generic-DDR"
    ranks: Dict[int, DRAMRank] = field(default_factory=dict)

    def __post_init__(self):
        if self.n_ranks <= 0:
            raise InvalidConfigurationError("n_ranks must be > 0")
        if not self.ranks:
            for r in range(self.n_ranks):
                self.ranks[r] = DRAMRank(rank_id=r, device_template=self.device_template,
                                          devices_per_rank=self.devices_per_rank)

    @property
    def channel_width_bits(self) -> int:
        return self.device_template.bus_width_bits * self.devices_per_rank

    def theoretical_bandwidth_gbps(self) -> EngineeringResult:
        """BW[GB/s] = data_rate[MT/s] * channel_width[bits] / 8 / 1000.
        Explicitly derived -- never a hard-coded constant (spec 15)."""
        dr = self.device_template.data_rate_mt_s
        width = self.channel_width_bits
        bw = dr * width / 8.0 / 1000.0
        return EngineeringResult(
            value=bw, unit="GB/s",
            equation="BW = data_rate_MTs * channel_width_bits / 8 / 1000",
            inputs={"data_rate_mt_s": dr, "channel_width_bits": width},
            assumptions=("Theoretical peak; ignores protocol overhead, "
                         "refresh, turnaround, and command bus contention "
                         "-- see performance engine for effective bandwidth.",),
            fidelity=Fidelity.FIDELITY_1,
        )

    @property
    def channel_capacity_bytes(self) -> int:
        return sum(r.rank_capacity_bytes for r in self.ranks.values())
