"""
dramcore.channel.topology

Explicit memory topology: Controller -> Channel -> Rank -> Device (spec
sections 5, 89). This object is the single source of truth for "what
hardware exists" that the address mapper, controller, and every engine
(power/thermal/reliability/performance) walk over.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from dramcore.channel.channel import DRAMChannel
from dramcore.core.result import InvalidConfigurationError
from dramcore.device.dram_device import DRAMDevice


@dataclass
class MemoryTopology:
    device_template: DRAMDevice
    n_channels: int = 2
    n_ranks_per_channel: int = 1
    devices_per_rank: int = 1
    channels: Dict[int, DRAMChannel] = field(default_factory=dict)

    def __post_init__(self):
        if self.n_channels <= 0:
            raise InvalidConfigurationError("n_channels must be > 0")
        if not self.channels:
            for c in range(self.n_channels):
                self.channels[c] = DRAMChannel(
                    channel_id=c, device_template=self.device_template,
                    n_ranks=self.n_ranks_per_channel,
                    devices_per_rank=self.devices_per_rank,
                )

    @property
    def total_capacity_bytes(self) -> int:
        return sum(ch.channel_capacity_bytes for ch in self.channels.values())

    def total_theoretical_bandwidth_gbps(self) -> float:
        return sum(ch.theoretical_bandwidth_gbps().value for ch in self.channels.values())

    def get_bank(self, channel: int, rank: int, bank: int):
        return self.channels[channel].ranks[rank].banks[bank]

    def all_banks(self):
        for ch in self.channels.values():
            for rk in ch.ranks.values():
                for bank in rk.banks.values():
                    yield ch.channel_id, rk.rank_id, bank

    def render_ascii(self) -> str:
        """Textual topology tree for inspection (spec section 89)."""
        lines = ["Controller"]
        for ch_id, ch in sorted(self.channels.items()):
            lines.append(f"|")
            lines.append(f"+-- Channel {ch_id} (width={ch.channel_width_bits}b, "
                         f"BW={ch.theoretical_bandwidth_gbps().value:.1f} GB/s)")
            for rk_id, rk in sorted(ch.ranks.items()):
                prefix = "     +-- " if rk_id < len(ch.ranks) - 1 else "     +-- "
                lines.append(f"{prefix}Rank {rk_id} ({rk.devices_per_rank} devices, "
                             f"{rk.rank_capacity_bytes/1e9:.1f} GB)")
        return "\n".join(lines)

    def summary(self) -> dict:
        return {
            "n_channels": self.n_channels,
            "n_ranks_per_channel": self.n_ranks_per_channel,
            "devices_per_rank": self.devices_per_rank,
            "banks_per_device": self.device_template.banks,
            "bank_groups_per_device": self.device_template.bank_groups,
            "total_capacity_gb": self.total_capacity_bytes / 1e9,
            "total_theoretical_bandwidth_gbps": self.total_theoretical_bandwidth_gbps(),
        }
