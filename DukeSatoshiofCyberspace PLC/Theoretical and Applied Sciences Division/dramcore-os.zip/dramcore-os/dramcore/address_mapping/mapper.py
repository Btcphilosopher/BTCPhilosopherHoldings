"""
dramcore.address_mapping.mapper

Real address-mapping engine (spec section 16): translates a flat physical
address into (channel, rank, bank_group, bank, row, column, burst_offset)
using explicit, configurable bit-field slicing. Supports multiple
interleaving policies by permuting the *order* in which address bits are
consumed, not by special-casing each policy separately.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Tuple

from dramcore.core.result import InvalidConfigurationError
from dramcore.device.dram_device import DRAMDevice


class InterleavingPolicy(str, Enum):
    NONE = "NONE"                                   # sequential / row-major, no interleave
    ROW_INTERLEAVING = "ROW_INTERLEAVING"            # consecutive addresses -> same row, rotate channel/bank last
    BANK_INTERLEAVING = "BANK_INTERLEAVING"          # consecutive cache lines rotate across banks first
    CHANNEL_INTERLEAVING = "CHANNEL_INTERLEAVING"    # consecutive cache lines rotate across channels first
    BANK_CHANNEL_INTERLEAVING = "BANK_CHANNEL_INTERLEAVING"  # rotate channel, then bank
    CACHE_LINE_AWARE = "CACHE_LINE_AWARE"            # burst-then-channel-then-bank, row stays maximally sticky


@dataclass(frozen=True)
class DecodedAddress:
    physical_address: int
    channel: int
    rank: int
    bank_group: int
    bank: int
    row: int
    column: int
    burst_offset: int

    @property
    def global_bank_id(self) -> int:
        return self.bank_group * 1_000_000 + self.bank  # human-legible composite, not used for indexing

    def __repr__(self) -> str:
        return (f"<Addr 0x{self.physical_address:012x} ch={self.channel} rk={self.rank} "
                f"bg={self.bank_group} bk={self.bank} row=0x{self.row:x} col=0x{self.column:x} "
                f"burst={self.burst_offset}>")


@dataclass
class AddressMapper:
    """Configurable field-order address mapper.

    field_order lists the address fields from LEAST-significant to
    MOST-significant bit position, e.g. for CACHE_LINE_AWARE:
        [burst, column(low bits implied by burst), bank_group, bank,
         channel, rank, row]
    means consecutive physical addresses first walk the burst, then hop
    bank groups/banks/channels before finally incrementing row -- keeping
    row-locality high (rows stay resident across many accesses) while
    still spreading traffic across the parallel resources.
    """
    device: DRAMDevice
    n_channels: int
    n_ranks: int
    policy: InterleavingPolicy = InterleavingPolicy.CACHE_LINE_AWARE
    cache_line_bytes: int = 64

    channel_bits: int = field(init=False)
    rank_bits: int = field(init=False)
    bank_group_bits: int = field(init=False)
    bank_bits: int = field(init=False)
    row_bits: int = field(init=False)
    column_bits: int = field(init=False)
    burst_bits: int = field(init=False)
    field_order: List[str] = field(init=False)

    def __post_init__(self):
        if self.n_channels <= 0 or (self.n_channels & (self.n_channels - 1)) != 0:
            raise InvalidConfigurationError("n_channels must be a power of two")
        if self.n_ranks <= 0 or (self.n_ranks & (self.n_ranks - 1)) != 0:
            raise InvalidConfigurationError("n_ranks must be a power of two")

        self.channel_bits = int(math.log2(self.n_channels))
        self.rank_bits = int(math.log2(self.n_ranks))
        self.bank_group_bits = self.device.bank_group_bits
        self.bank_bits = self.device.bank_bits
        self.row_bits = self.device.row_bits
        self.column_bits = self.device.column_bits
        self.burst_bits = self.device.burst_bits

        self.field_order = self._resolve_field_order()

    def _resolve_field_order(self) -> List[str]:
        # Each entry is (field_name, width). Listed LSB-first.
        burst = ("burst", self.burst_bits)
        col = ("column", self.column_bits - self.burst_bits)
        bank = ("bank", self.bank_bits)
        bg = ("bank_group", self.bank_group_bits)
        chan = ("channel", self.channel_bits)
        rank = ("rank", self.rank_bits)
        row = ("row", self.row_bits)

        if self.policy == InterleavingPolicy.NONE:
            # sequential: row-major -- row varies fastest after column,
            # channel/rank/bank are the *most* significant (large stride)
            return [burst, col, bank, bg, rank, chan, row]
        if self.policy == InterleavingPolicy.ROW_INTERLEAVING:
            return [burst, col, chan, rank, bg, bank, row]
        if self.policy == InterleavingPolicy.BANK_INTERLEAVING:
            return [burst, col, bg, bank, chan, rank, row]
        if self.policy == InterleavingPolicy.CHANNEL_INTERLEAVING:
            return [burst, col, chan, bg, bank, rank, row]
        if self.policy == InterleavingPolicy.BANK_CHANNEL_INTERLEAVING:
            return [burst, col, chan, bank, bg, rank, row]
        if self.policy == InterleavingPolicy.CACHE_LINE_AWARE:
            return [burst, col, bg, bank, chan, rank, row]
        raise InvalidConfigurationError(f"Unknown interleaving policy {self.policy}")

    def decode(self, physical_address: int) -> DecodedAddress:
        if physical_address < 0:
            raise InvalidConfigurationError("physical_address must be >= 0")
        addr = physical_address
        values = {}
        shift = 0
        for name, width in self.field_order:
            mask = (1 << width) - 1 if width > 0 else 0
            values[name] = (addr >> shift) & mask
            shift += width
        return DecodedAddress(
            physical_address=physical_address,
            channel=values.get("channel", 0),
            rank=values.get("rank", 0),
            bank_group=values.get("bank_group", 0),
            bank=values.get("bank", 0),
            row=values.get("row", 0),
            column=(values.get("column", 0) << self.burst_bits) | values.get("burst", 0),
            burst_offset=values.get("burst", 0),
        )

    def total_address_bits(self) -> int:
        return sum(w for _, w in self.field_order)

    def addressable_bytes(self) -> int:
        return 1 << self.total_address_bits()
