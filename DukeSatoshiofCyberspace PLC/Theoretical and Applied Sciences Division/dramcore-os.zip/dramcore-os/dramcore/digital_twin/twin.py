"""
dramcore.digital_twin.twin

Memory digital twin (spec section 61) and state inspector (spec section
62). The digital twin is derived entirely from live simulator state --
it holds no independent data of its own.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

from dramcore.channel.topology import MemoryTopology
from dramcore.controller.controller import MemoryController


@dataclass
class DRAMDigitalTwin:
    topology: MemoryTopology
    controller: MemoryController

    def snapshot(self) -> Dict[str, Any]:
        """A point-in-time derived view of the full topology state (spec
        section 61)."""
        channels = {}
        for ch_id, ch in self.topology.channels.items():
            ranks = {}
            for rk_id, rk in ch.ranks.items():
                banks = {}
                for bk_id, bank in rk.banks.items():
                    banks[bk_id] = {
                        "state": bank.state.value,
                        "active_row": bank.row_buffer.active_row,
                        "row_hits": bank.row_hits,
                        "row_misses": bank.row_misses,
                        "row_conflicts": bank.row_conflicts,
                        "activation_count": bank.activation_count,
                        "temperature_c": bank.temperature_c,
                    }
                ranks[rk_id] = {"power_state": rk.power_state.value, "banks": banks}
            channels[ch_id] = {"ranks": ranks}
        return {
            "sim_time_ns": self.controller.clock.time_ns,
            "channels": channels,
            "total_commands_issued": self.controller.total_commands_issued(),
        }

    def inspect(self, channel: int, rank: int, bank: int) -> Optional[Dict[str, Any]]:
        """Inspect a specific channel/rank/bank location (spec section 62
        example: 'Channel 2 Rank 0 Bank Group 1 Bank 3')."""
        try:
            ch = self.topology.channels[channel]
            rk = ch.ranks[rank]
            b = rk.banks[bank]
        except KeyError:
            return None
        age_ns = None
        if b.row_buffer.activation_timestamp_ns is not None:
            age_ns = self.controller.clock.time_ns - b.row_buffer.activation_timestamp_ns
        return {
            "channel": channel, "rank": rank, "bank_group": b.bank_group_id, "bank": bank,
            "state": b.state.value,
            "row": b.row_buffer.active_row,
            "age_ns": age_ns,
            "temperature_c": b.temperature_c,
            "row_hits": b.row_hits, "row_misses": b.row_misses,
            "row_conflicts": b.row_conflicts,
        }

    def render_inspection(self, channel: int, rank: int, bank: int) -> str:
        info = self.inspect(channel, rank, bank)
        if info is None:
            return f"No such location: channel={channel} rank={rank} bank={bank}"
        row_str = f"0x{info['row']:x}" if info["row"] is not None else "None"
        age_str = f"{info['age_ns']:.1f} ns" if info["age_ns"] is not None else "N/A"
        return (
            f"Channel {info['channel']}\n"
            f"Rank {info['rank']}\n"
            f"Bank Group {info['bank_group']}\n"
            f"Bank {info['bank']}\n"
            f"  State: {info['state']}\n"
            f"  Row: {row_str}\n"
            f"  Age: {age_str}\n"
            f"  Temperature: {info['temperature_c']:.1f} C\n"
            f"  Hits/Misses/Conflicts: {info['row_hits']}/{info['row_misses']}/{info['row_conflicts']}"
        )
