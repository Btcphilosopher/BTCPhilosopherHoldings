"""
dramcore.scheduler.scheduler

Memory scheduling policies (spec section 23). Each scheduler implements a
single method, ``select``, that picks the next request to issue a command
for out of the set of currently-eligible requests (already arrived, not
yet completed). The controller (dramcore.controller.controller) is
responsible for actually walking each chosen request through the
ACT/RD/WR/PRE command sequence subject to the timing engine -- the
scheduler ONLY decides *order*, never bypasses timing legality.

Implemented policies: FCFS, FR_FCFS, DEADLINE, PRIORITY, ROUND_ROBIN,
FAIRNESS_AWARE. OPEN_PAGE / CLOSE_PAGE is an orthogonal *page policy*
(see dramcore.controller.controller.PagePolicy) rather than a request
ordering policy, since real controllers combine an ordering policy with
an independent page-management policy. BANDWIDTH_AWARE and QoS_AWARE are
provided as thin specialisations of FAIRNESS_AWARE / DEADLINE respectively,
since they draw on the same admission-shaping primitives.
"""
from __future__ import annotations

from collections import defaultdict
from enum import Enum
from typing import Callable, Dict, List, Optional

from dramcore.controller.request import MemoryRequest


class SchedulerPolicy(str, Enum):
    FCFS = "FCFS"
    FR_FCFS = "FR_FCFS"
    DEADLINE = "DEADLINE"
    PRIORITY = "PRIORITY"
    ROUND_ROBIN = "ROUND_ROBIN"
    FAIRNESS_AWARE = "FAIRNESS_AWARE"


class BaseScheduler:
    name = "base"

    def select(self, eligible: List[MemoryRequest], *, now_ns: float,
               row_is_open: Callable[[MemoryRequest], bool]) -> MemoryRequest:
        raise NotImplementedError


class FCFSScheduler(BaseScheduler):
    """Strict arrival-order service. Simple, fair, but ignores row-buffer
    locality -- leaves bandwidth on the table versus FR-FCFS."""
    name = "FCFS"

    def select(self, eligible, *, now_ns, row_is_open):
        return min(eligible, key=lambda r: (r.arrival_time_ns, r.request_id))


class FRFCFSScheduler(BaseScheduler):
    """First-Ready, First-Come-First-Served: prioritises requests that hit
    an already-open row (avoiding an ACT/PRE round trip), breaking ties by
    arrival order. This is the dominant real-world DRAM scheduling policy
    because it directly maximises row-buffer hit rate."""
    name = "FR_FCFS"

    def select(self, eligible, *, now_ns, row_is_open):
        ready = [r for r in eligible if row_is_open(r)]
        pool = ready if ready else eligible
        return min(pool, key=lambda r: (r.arrival_time_ns, r.request_id))


class DeadlineScheduler(BaseScheduler):
    """Earliest-deadline-first. Requests without a deadline are treated as
    having the lowest priority (serviced last), broken by arrival order."""
    name = "DEADLINE"

    def select(self, eligible, *, now_ns, row_is_open):
        def key(r: MemoryRequest):
            deadline = r.deadline_ns if r.deadline_ns is not None else float("inf")
            return (deadline, r.arrival_time_ns, r.request_id)
        return min(eligible, key=key)


class PriorityScheduler(BaseScheduler):
    """Highest numeric priority first (ties broken by arrival order)."""
    name = "PRIORITY"

    def select(self, eligible, *, now_ns, row_is_open):
        return max(eligible, key=lambda r: (r.priority, -r.arrival_time_ns))


class RoundRobinScheduler(BaseScheduler):
    """Rotates service fairly across distinct request `source` identifiers
    (e.g. CPU cores / GPU compute units), preventing a single aggressive
    source from starving others."""
    name = "ROUND_ROBIN"

    def __init__(self):
        self._last_source_index = -1

    def select(self, eligible, *, now_ns, row_is_open):
        sources = sorted({r.source for r in eligible})
        n = len(sources)
        for offset in range(1, n + 1):
            idx = (self._last_source_index + offset) % n
            candidate_source = sources[idx]
            candidates = [r for r in eligible if r.source == candidate_source]
            if candidates:
                self._last_source_index = idx
                return min(candidates, key=lambda r: (r.arrival_time_ns, r.request_id))
        return min(eligible, key=lambda r: (r.arrival_time_ns, r.request_id))


class FairnessAwareScheduler(BaseScheduler):
    """Tracks bytes-serviced-per-source and prioritises the most
    under-served source, using row-buffer hit as a tiebreak. This directly
    trades some row-locality for inter-source fairness (spec section 24)."""
    name = "FAIRNESS_AWARE"

    def __init__(self):
        self.bytes_served: Dict[str, int] = defaultdict(int)

    def select(self, eligible, *, now_ns, row_is_open):
        def key(r: MemoryRequest):
            served = self.bytes_served[r.source]
            hit_bonus = 0 if row_is_open(r) else 1  # prefer hits, but fairness dominates
            return (served, hit_bonus, r.arrival_time_ns, r.request_id)
        return min(eligible, key=key)

    def record_service(self, request: MemoryRequest) -> None:
        self.bytes_served[request.source] += request.size_bytes


def make_scheduler(policy: SchedulerPolicy) -> BaseScheduler:
    return {
        SchedulerPolicy.FCFS: FCFSScheduler,
        SchedulerPolicy.FR_FCFS: FRFCFSScheduler,
        SchedulerPolicy.DEADLINE: DeadlineScheduler,
        SchedulerPolicy.PRIORITY: PriorityScheduler,
        SchedulerPolicy.ROUND_ROBIN: RoundRobinScheduler,
        SchedulerPolicy.FAIRNESS_AWARE: FairnessAwareScheduler,
    }[policy]()
