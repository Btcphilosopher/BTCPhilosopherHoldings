"""
dramcore.core.clock
====================

Deterministic simulation clock (spec section 59) and the event log
(spec section 60). Simulation time is tracked internally in nanoseconds
as a float, with an explicit resolution guard to keep floating point
accumulation from drifting into non-determinism over long runs -- time
is quantised to an integer number of "clock ticks" of configurable
resolution (default 1 picosecond) and all comparisons happen on that
integer tick count.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class EventType(str, Enum):
    REQUEST_ARRIVED = "REQUEST_ARRIVED"
    REQUEST_QUEUED = "REQUEST_QUEUED"
    REQUEST_COMPLETED = "REQUEST_COMPLETED"
    REQUEST_DROPPED = "REQUEST_DROPPED"
    ROW_ACTIVATED = "ROW_ACTIVATED"
    ROW_HIT = "ROW_HIT"
    ROW_MISS = "ROW_MISS"
    ROW_CONFLICT = "ROW_CONFLICT"
    READ_ISSUED = "READ_ISSUED"
    WRITE_ISSUED = "WRITE_ISSUED"
    PRECHARGE_ISSUED = "PRECHARGE_ISSUED"
    REFRESH_ISSUED = "REFRESH_ISSUED"
    REFRESH_COMPLETED = "REFRESH_COMPLETED"
    SELF_REFRESH_ENTRY = "SELF_REFRESH_ENTRY"
    SELF_REFRESH_EXIT = "SELF_REFRESH_EXIT"
    ECC_CORRECTION = "ECC_CORRECTION"
    ECC_UNCORRECTABLE = "ECC_UNCORRECTABLE"
    THERMAL_WARNING = "THERMAL_WARNING"
    THERMAL_THROTTLE = "THERMAL_THROTTLE"
    POWER_STATE_CHANGED = "POWER_STATE_CHANGED"
    TIMING_VIOLATION_REJECTED = "TIMING_VIOLATION_REJECTED"
    SCHEDULER_DECISION = "SCHEDULER_DECISION"


@dataclass(frozen=True)
class Event:
    tick: int
    time_ns: float
    event_type: EventType
    payload: Dict[str, Any] = field(default_factory=dict)


class SimulationClock:
    """Deterministic tick-based clock. All scheduling decisions are made
    against integer ticks; ``time_ns`` is a derived, read-only view."""

    def __init__(self, resolution_ps: float = 1.0):
        if resolution_ps <= 0:
            raise ValueError("resolution_ps must be > 0")
        self.resolution_ps = resolution_ps
        self._tick = 0  # integer ticks since t=0

    @property
    def tick(self) -> int:
        return self._tick

    @property
    def time_ns(self) -> float:
        return self._tick * self.resolution_ps / 1000.0

    def ns_to_ticks(self, ns: float) -> int:
        return round(ns * 1000.0 / self.resolution_ps)

    def advance_to(self, time_ns: float) -> None:
        new_tick = self.ns_to_ticks(time_ns)
        if new_tick < self._tick:
            raise ValueError(
                f"Cannot move clock backwards: {new_tick} < current {self._tick}"
            )
        self._tick = new_tick

    def advance_by(self, delta_ns: float) -> None:
        if delta_ns < 0:
            raise ValueError("delta_ns must be >= 0")
        self._tick += self.ns_to_ticks(delta_ns)

    def reset(self) -> None:
        self._tick = 0


class EventLog:
    """Append-only structured event log. Deterministic given a fixed seed
    and configuration (spec section 60)."""

    def __init__(self):
        self._events: List[Event] = []

    def record(self, clock: SimulationClock, event_type: EventType,
               **payload: Any) -> Event:
        ev = Event(tick=clock.tick, time_ns=clock.time_ns,
                   event_type=event_type, payload=payload)
        self._events.append(ev)
        return ev

    def events(self, event_type: Optional[EventType] = None) -> List[Event]:
        if event_type is None:
            return list(self._events)
        return [e for e in self._events if e.event_type == event_type]

    def count(self, event_type: EventType) -> int:
        return sum(1 for e in self._events if e.event_type == event_type)

    def __len__(self) -> int:
        return len(self._events)

    def to_records(self) -> List[Dict[str, Any]]:
        return [
            {"tick": e.tick, "time_ns": e.time_ns, "event_type": e.event_type.value,
             **e.payload}
            for e in self._events
        ]

    def clear(self) -> None:
        self._events.clear()
