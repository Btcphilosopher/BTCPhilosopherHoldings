"""
dramcore.core.reproducibility

Every experiment/simulation run must record enough metadata to be
reproduced exactly (spec section 101, 59).
"""
from __future__ import annotations

import platform
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, Optional

DRAMCORE_VERSION = "0.1.0"
MODEL_VERSION = "0.1.0"
WORKLOAD_VERSION = "0.1.0"


@dataclass(frozen=True)
class ReproducibilityRecord:
    dramcore_version: str = DRAMCORE_VERSION
    python_version: str = field(default_factory=lambda: sys.version.split()[0])
    platform_info: str = field(default_factory=platform.platform)
    configuration: Dict[str, Any] = field(default_factory=dict)
    random_seed: Optional[int] = None
    model_version: str = MODEL_VERSION
    workload_version: str = WORKLOAD_VERSION
    date_utc: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def as_dict(self) -> Dict[str, Any]:
        return {
            "dramcore_version": self.dramcore_version,
            "python_version": self.python_version,
            "platform_info": self.platform_info,
            "configuration": self.configuration,
            "random_seed": self.random_seed,
            "model_version": self.model_version,
            "workload_version": self.workload_version,
            "date_utc": self.date_utc,
        }
