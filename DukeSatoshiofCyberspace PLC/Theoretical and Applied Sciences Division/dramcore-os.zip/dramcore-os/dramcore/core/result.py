"""
dramcore.core.result
=====================

The single most important abstraction in DRAMCORE.OS.

Per the master build spec (section 68, 110): no bare numbers are allowed to
flow out of an engineering model. Every value that leaves a model must be
wrapped in an ``EngineeringResult`` that discloses:

    value              the number (or array) itself
    unit               explicit physical unit (never implicit)
    equation           human-readable equation string that produced it
    inputs             the named inputs that were fed into the equation
    assumptions        simplifications / assumptions baked into the model
    validity_range     the domain over which the model is considered valid
    uncertainty        None, a +/- absolute value, or a relative fraction
    model_version      version string of the *model*, not the software
    fidelity           a Fidelity enum member (see below)
    provenance         SIMULATED / CALIBRATED / MEASURED / IMPORTED

``EngineeringResult`` is intentionally a frozen dataclass: results are
immutable engineering artifacts, not mutable scratch state.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping, Optional, Sequence, Union

Number = Union[int, float]


class Fidelity(str, Enum):
    """Model fidelity ladder (spec section 69). Never claim FIDELITY_3
    without attached calibration data on the model that produced the
    result."""

    FIDELITY_0 = "FIDELITY_0_CONCEPTUAL"
    FIDELITY_1 = "FIDELITY_1_ARCHITECTURAL_APPROXIMATION"
    FIDELITY_2 = "FIDELITY_2_DETAILED_TIMING_PERFORMANCE"
    FIDELITY_3 = "FIDELITY_3_CALIBRATED_ENGINEERING"


class Provenance(str, Enum):
    SIMULATED = "SIMULATED"
    CALIBRATED = "CALIBRATED"
    MEASURED = "MEASURED"
    IMPORTED = "IMPORTED"


class DramCoreError(Exception):
    """Base exception for all DRAMCORE.OS engineering errors."""


class TimingViolationError(DramCoreError):
    """Raised when the timing engine rejects an illegal command sequence.
    This exception is authoritative: nothing in the controller, scheduler,
    or ML layer is permitted to swallow it silently and proceed."""


class InvalidConfigurationError(DramCoreError):
    """Raised when a device/topology/timing configuration is internally
    inconsistent or outside representable bounds."""


class ValidityRangeWarning(UserWarning):
    """Warned when a result is produced outside its model's declared
    validity range. The result is still returned (the caller may be doing
    deliberate stress testing) but the fact is surfaced, never hidden."""


@dataclass(frozen=True)
class EngineeringResult:
    value: Any
    unit: str
    equation: str
    inputs: Mapping[str, Any] = field(default_factory=dict)
    assumptions: Sequence[str] = field(default_factory=tuple)
    validity_range: Optional[str] = None
    uncertainty: Optional[Union[Number, str]] = None
    model_version: str = "0.1.0"
    fidelity: Fidelity = Fidelity.FIDELITY_1
    provenance: Provenance = Provenance.SIMULATED
    notes: Sequence[str] = field(default_factory=tuple)

    def __post_init__(self):
        if self.fidelity == Fidelity.FIDELITY_3 and self.provenance != Provenance.CALIBRATED:
            object.__setattr__(
                self,
                "notes",
                tuple(self.notes)
                + (
                    "WARNING: FIDELITY_3 claimed without CALIBRATED provenance; "
                    "downgrade recommended.",
                ),
            )

    def as_dict(self) -> dict:
        d = dict(
            value=self.value,
            unit=self.unit,
            equation=self.equation,
            inputs=dict(self.inputs),
            assumptions=list(self.assumptions),
            validity_range=self.validity_range,
            uncertainty=self.uncertainty,
            model_version=self.model_version,
            fidelity=self.fidelity.value,
            provenance=self.provenance.value,
            notes=list(self.notes),
        )
        return d

    def __float__(self) -> float:
        return float(self.value)

    def __repr__(self) -> str:
        u = f" +/-{self.uncertainty}" if self.uncertainty is not None else ""
        return f"<EngineeringResult {self.value}{u} {self.unit} | {self.equation}>"

    def scaled(self, factor: Number, *, new_unit: Optional[str] = None,
               note: Optional[str] = None) -> "EngineeringResult":
        """Return a derived result scaled by a dimensionless factor,
        preserving provenance chain via a note."""
        notes = tuple(self.notes) + ((note,) if note else ())
        return EngineeringResult(
            value=self.value * factor,
            unit=new_unit or self.unit,
            equation=f"({self.equation}) * {factor}",
            inputs=self.inputs,
            assumptions=self.assumptions,
            validity_range=self.validity_range,
            uncertainty=(self.uncertainty * factor
                         if isinstance(self.uncertainty, (int, float)) else self.uncertainty),
            model_version=self.model_version,
            fidelity=self.fidelity,
            provenance=self.provenance,
            notes=notes,
        )


def check_validity(value: Number, lo: Number, hi: Number, *, label: str) -> None:
    """Raise/­warn-style validity check used throughout the engine. Models
    call this instead of silently clamping values."""
    import warnings

    if value is None or (isinstance(value, float) and math.isnan(value)):
        raise InvalidConfigurationError(f"{label} is NaN/None")
    if value < lo or value > hi:
        warnings.warn(
            f"{label}={value} is outside declared validity range [{lo}, {hi}]",
            ValidityRangeWarning,
            stacklevel=2,
        )
