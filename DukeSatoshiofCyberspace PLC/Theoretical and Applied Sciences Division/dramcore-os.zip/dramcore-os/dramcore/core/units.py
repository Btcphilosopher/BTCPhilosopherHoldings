"""
dramcore.core.units
====================

DRAMCORE.OS forbids silent unit conversion (spec section 1, 84, 110).
This module centralises every conversion factor used anywhere in the
engine so that a reviewer can audit all unit handling in one file.

Time is represented internally, canonically, in **nanoseconds** (ns) for
timing-engine quantities (DRAM timing parameters are conventionally
specified in ns or in memory clock cycles — we standardise on ns and
require an explicit clock period to convert to/from cycles).

Energy is represented internally in **picojoules** (pJ).
Power is represented internally in **milliwatts** (mW).
Charge is represented internally in **femtocoulombs** (fC).
Capacitance is represented internally in **femtofarads** (fF).
Data sizes are represented internally in **bytes**.
Bandwidth is represented internally in **GB/s** (10^9 bytes/second, decimal
GB, consistent with JEDEC data-rate conventions — *not* GiB/s).
Temperature is represented internally in **degrees Celsius**.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Time
# ---------------------------------------------------------------------------
NS_PER_S = 1e9
NS_PER_US = 1e3
NS_PER_MS = 1e6
PS_PER_NS = 1e3


def cycles_to_ns(cycles: float, clock_period_ns: float) -> float:
    """Explicit cycle -> ns conversion. clock_period_ns must be supplied by
    the caller from the device's configured data rate; never assumed."""
    return cycles * clock_period_ns


def ns_to_cycles(ns: float, clock_period_ns: float) -> float:
    if clock_period_ns <= 0:
        raise ValueError("clock_period_ns must be > 0")
    return ns / clock_period_ns


def data_rate_mt_s_to_clock_period_ns(data_rate_mt_s: float) -> float:
    """DDR-style memory operates on both clock edges: data rate (MT/s,
    mega-transfers per second) = 2x the clock frequency (MHz).
    clock_period_ns = 1000 / clock_freq_MHz = 2000 / data_rate_mt_s
    """
    if data_rate_mt_s <= 0:
        raise ValueError("data_rate_mt_s must be > 0")
    clock_freq_mhz = data_rate_mt_s / 2.0
    return 1000.0 / clock_freq_mhz


# ---------------------------------------------------------------------------
# Data / bandwidth
# ---------------------------------------------------------------------------
BYTES_PER_GB = 1e9  # decimal GB, JEDEC/industry bandwidth convention
BITS_PER_BYTE = 8


def bytes_per_ns_to_gbps(bytes_per_ns: float) -> float:
    # bytes/ns * 1e9 ns/s = bytes/s; /1e9 = GB/s -> the 1e9 factors cancel
    return bytes_per_ns


def gbps_to_bytes_per_ns(gbps: float) -> float:
    return gbps


# ---------------------------------------------------------------------------
# Energy / power / charge / capacitance
# ---------------------------------------------------------------------------
PJ_PER_J = 1e12
MW_PER_W = 1e3
FC_PER_C = 1e15
FF_PER_F = 1e15


def energy_pj(power_mw: float, duration_ns: float) -> float:
    """E [pJ] = P [mW] * t [ns].  (mW * ns = pJ, dimensionally consistent:
    1 mW = 1e-3 W, 1 ns = 1e-9 s -> 1e-12 J = 1 pJ.)"""
    return power_mw * duration_ns


def power_mw(energy_pj_: float, duration_ns: float) -> float:
    if duration_ns <= 0:
        raise ValueError("duration_ns must be > 0")
    return energy_pj_ / duration_ns


def charge_fc(capacitance_ff: float, voltage_v: float) -> float:
    """Q [fC] = C [fF] * V [V]. (fF * V = 1e-15 F * V = 1e-15 C = fC.)"""
    return capacitance_ff * voltage_v


# ---------------------------------------------------------------------------
# Physical constants (explicit, cited use only)
# ---------------------------------------------------------------------------
BOLTZMANN_EV_PER_K = 8.617333262e-5  # eV/K, used in Arrhenius-style leakage scaling
KELVIN_OFFSET = 273.15


def celsius_to_kelvin(temp_c: float) -> float:
    return temp_c + KELVIN_OFFSET
