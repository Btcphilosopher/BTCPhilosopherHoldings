"""
dramcore.visualisation.plots

Engineering plots (spec section 87), heat maps (spec section 63-66).
Matplotlib-based; every function returns the Figure so callers can save,
embed, or further annotate it -- no plot silently displays/blocks.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def plot_latency_distribution(latencies_ns: Sequence[float], title: str = "Latency Distribution"):
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.hist(latencies_ns, bins=60, color="#3b6ea5", edgecolor="black", linewidth=0.3)
    ax.set_xlabel("Latency (ns)")
    ax.set_ylabel("Request count")
    ax.set_title(title)
    fig.tight_layout()
    return fig


def plot_bandwidth_curve(requested_gbps: Sequence[float], achieved_gbps: Sequence[float],
                          title: str = "Requested vs Achieved Bandwidth"):
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(requested_gbps, achieved_gbps, marker="o", color="#3b6ea5", label="Achieved")
    ax.plot(requested_gbps, requested_gbps, linestyle="--", color="gray", label="Ideal (1:1)")
    ax.set_xlabel("Requested bandwidth (GB/s)")
    ax.set_ylabel("Achieved bandwidth (GB/s)")
    ax.set_title(title)
    ax.legend()
    fig.tight_layout()
    return fig


def plot_row_hit_rate_vs_x(x_values: Sequence[float], hit_rates: Sequence[float],
                            x_label: str, title: str = "Row-Hit Rate"):
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(x_values, hit_rates, marker="s", color="#5a9367")
    ax.set_xlabel(x_label)
    ax.set_ylabel("Row-hit rate")
    ax.set_ylim(0, 1)
    ax.set_title(title)
    fig.tight_layout()
    return fig


def plot_power_vs_bandwidth(bandwidth_gbps: Sequence[float], power_mw: Sequence[float],
                             title: str = "Power vs Bandwidth"):
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(bandwidth_gbps, power_mw, marker="^", color="#b5544a")
    ax.set_xlabel("Bandwidth (GB/s)")
    ax.set_ylabel("Average power (mW)")
    ax.set_title(title)
    fig.tight_layout()
    return fig


def plot_temperature_trace(elapsed_s: Sequence[float], temperature_c: Sequence[float],
                            title: str = "Temperature vs Time"):
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(elapsed_s, temperature_c, color="#b5544a")
    ax.set_xlabel("Elapsed time (s)")
    ax.set_ylabel("Temperature (C)")
    ax.set_title(title)
    fig.tight_layout()
    return fig


def plot_refresh_overhead(refresh_intervals_ns: Sequence[float], overhead_fraction: Sequence[float],
                           title: str = "Refresh Overhead vs Refresh Interval"):
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(refresh_intervals_ns, overhead_fraction, marker="d", color="#8a5aa3")
    ax.set_xlabel("Refresh interval (ns)")
    ax.set_ylabel("Performance overhead (fraction of time)")
    ax.set_title(title)
    fig.tight_layout()
    return fig


def plot_row_activation_heatmap(activation_counts: np.ndarray, title: str = "Row Activation Heat Map"):
    """activation_counts: 2D array [bank][row_bucket] of activation
    counts (spec section 64) -- rows are typically bucketed since a full
    row axis (e.g. 131072 rows) is too fine to render directly."""
    fig, ax = plt.subplots(figsize=(8, 5))
    im = ax.imshow(activation_counts, aspect="auto", cmap="inferno")
    ax.set_xlabel("Row bucket")
    ax.set_ylabel("Bank")
    ax.set_title(title)
    fig.colorbar(im, ax=ax, label="Activation count")
    fig.tight_layout()
    return fig


def plot_channel_rank_bank_power_map(power_mw: np.ndarray, title: str = "Power Map"):
    """power_mw: 2D array [channel*rank][bank] (spec section 65)."""
    fig, ax = plt.subplots(figsize=(8, 5))
    im = ax.imshow(power_mw, aspect="auto", cmap="plasma")
    ax.set_xlabel("Bank")
    ax.set_ylabel("Channel x Rank")
    ax.set_title(title)
    fig.colorbar(im, ax=ax, label="Power (mW)")
    fig.tight_layout()
    return fig


def save_fig(fig, path: str) -> str:
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return path
