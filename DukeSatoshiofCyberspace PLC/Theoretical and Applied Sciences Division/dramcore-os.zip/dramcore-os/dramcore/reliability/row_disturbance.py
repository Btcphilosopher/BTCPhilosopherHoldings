"""
dramcore.reliability.row_disturbance

Configurable RESEARCH model for repeated-row-activation disturbance
effects (spec section 36). This is explicitly a simulation/research
abstraction inspired by the general *class* of phenomena where repeatedly
activating one "aggressor" row can disturb charge in physically adjacent
"victim" rows -- it is NOT a claim of exact behaviour for any specific
commercial DRAM device, vendor, or process node. Thresholds and disturbance
probabilities are configurable parameters for experimentation, not
calibrated hardware constants.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional

import numpy as np

from dramcore.core.result import EngineeringResult, Fidelity, InvalidConfigurationError, Provenance


@dataclass
class RowDisturbanceModel:
    activation_threshold: int = 100_000
    """Illustrative aggressor-activation count above which victim
    disturbance probability becomes non-negligible. A configurable
    research parameter, not a measured hardware constant."""

    base_disturbance_probability: float = 1e-6
    """Disturbance probability per bit at exactly the threshold activation
    count, before distance/temperature/refresh scaling."""

    victim_distance_decay: float = 0.5
    """Multiplicative decay factor applied per row of physical distance
    from the aggressor (row N+1 immediately adjacent -> full effect; row
    N+2 -> decayed by this factor; etc)."""

    def __post_init__(self):
        if self.activation_threshold <= 0:
            raise InvalidConfigurationError("activation_threshold must be > 0")
        if not (0.0 <= self.base_disturbance_probability <= 1.0):
            raise InvalidConfigurationError(
                "base_disturbance_probability must be in [0,1]"
            )
        if not (0.0 < self.victim_distance_decay <= 1.0):
            raise InvalidConfigurationError(
                "victim_distance_decay must be in (0,1]"
            )

    def disturbance_probability(self, aggressor_activation_count: int,
                                 victim_row_distance: int,
                                 refresh_interval_ns: float,
                                 reference_refresh_interval_ns: float,
                                 temperature_rate_multiplier: float = 1.0) -> EngineeringResult:
        """SIMULATED disturbance probability per victim-row bit.

        p = base_p * max(0, activations/threshold) * distance_decay^(dist-1)
              * (reference_refresh_interval / refresh_interval) * temp_mult

        Shorter refresh interval (more frequent refresh) proportionally
        REDUCES disturbance probability, since the victim row's disturbed
        charge gets corrected sooner -- this captures the well-established
        qualitative mitigation effect of increased refresh rate."""
        if victim_row_distance < 1:
            raise InvalidConfigurationError("victim_row_distance must be >= 1")
        if aggressor_activation_count < 0:
            raise InvalidConfigurationError("aggressor_activation_count must be >= 0")

        activation_factor = max(0.0, aggressor_activation_count / self.activation_threshold)
        distance_factor = self.victim_distance_decay ** (victim_row_distance - 1)
        # Proportional in refresh_interval_ns: a SHORTER interval (more
        # frequent refresh) gives disturbed charge less time to decay
        # past the sense margin before being corrected, so it REDUCES
        # probability; a longer interval increases it.
        refresh_factor = refresh_interval_ns / reference_refresh_interval_ns

        p = self.base_disturbance_probability * activation_factor * distance_factor \
            * refresh_factor * temperature_rate_multiplier
        p = min(1.0, max(0.0, p))

        return EngineeringResult(
            value=p, unit="probability",
            equation=("p = base_p * (activations/threshold) * decay^(dist-1) "
                      "* (refresh_interval / ref_refresh_interval) * temp_mult"),
            inputs={
                "aggressor_activation_count": aggressor_activation_count,
                "victim_row_distance": victim_row_distance,
                "refresh_interval_ns": refresh_interval_ns,
                "reference_refresh_interval_ns": reference_refresh_interval_ns,
                "temperature_rate_multiplier": temperature_rate_multiplier,
            },
            assumptions=(
                "RESEARCH/SIMULATION MODEL ONLY -- illustrative functional "
                "form (linear-in-activations, geometric-in-distance, "
                "inverse-in-refresh-interval), not calibrated against any "
                "specific commercial DRAM device.",
                "No inter-row coupling beyond the single configured decay "
                "factor; real disturbance patterns can be highly "
                "non-monotonic and device-specific.",
            ),
            fidelity=Fidelity.FIDELITY_0,
            provenance=Provenance.SIMULATED,
        )

    def simulate_victim_errors(self, victim_row_bits: int, aggressor_activation_count: int,
                                victim_row_distance: int, refresh_interval_ns: float,
                                reference_refresh_interval_ns: float,
                                temperature_rate_multiplier: float = 1.0,
                                seed: Optional[int] = None) -> EngineeringResult:
        p_result = self.disturbance_probability(
            aggressor_activation_count, victim_row_distance, refresh_interval_ns,
            reference_refresh_interval_ns, temperature_rate_multiplier,
        )
        rng = np.random.default_rng(seed)
        n_errors = int(rng.binomial(n=victim_row_bits, p=p_result.value))
        return EngineeringResult(
            value=n_errors, unit="count",
            equation="n_errors ~ Binomial(victim_row_bits, disturbance_probability)",
            inputs={**p_result.inputs, "victim_row_bits": victim_row_bits,
                    "disturbance_probability": p_result.value, "seed": seed},
            assumptions=p_result.assumptions,
            fidelity=Fidelity.FIDELITY_0,
            provenance=Provenance.SIMULATED,
        )

    def sweep_activation_frequency(self, activation_counts, victim_row_distance: int,
                                    refresh_interval_ns: float,
                                    reference_refresh_interval_ns: float,
                                    temperature_rate_multiplier: float = 1.0) -> Dict[int, float]:
        """Sweep experiment (spec section 36): activation_frequency vs
        simulated disturbance probability, holding other parameters fixed."""
        return {
            int(n): self.disturbance_probability(
                int(n), victim_row_distance, refresh_interval_ns,
                reference_refresh_interval_ns, temperature_rate_multiplier,
            ).value
            for n in activation_counts
        }
