"""
dramcore.reliability.engine

Configurable error/reliability model (spec section 33). All errors here
are explicitly SIMULATED -- this module injects synthetic faults into a
simulation according to configurable statistical rates; it does not claim
to predict real hardware failure rates for any specific product.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

import numpy as np

from dramcore.core.result import EngineeringResult, Fidelity, InvalidConfigurationError, Provenance


class ErrorType(str, Enum):
    BIT_FLIP = "BIT_FLIP"
    RETENTION_ERROR = "RETENTION_ERROR"
    ROW_DISTURBANCE = "ROW_DISTURBANCE"
    TIMING_ERROR = "TIMING_ERROR"
    VOLTAGE_ERROR = "VOLTAGE_ERROR"
    TEMPERATURE_ERROR = "TEMPERATURE_ERROR"
    INTERFACE_ERROR = "INTERFACE_ERROR"
    CONTROLLER_ERROR = "CONTROLLER_ERROR"


@dataclass(frozen=True)
class ErrorRateConfig:
    """Per-error-type rate, expressed as a probability per bit per
    refresh-interval (dimensionless, [0, 1]). All SIMULATED (spec 33)."""
    rates: Dict[ErrorType, float] = field(default_factory=dict)

    def __post_init__(self):
        for k, v in self.rates.items():
            if not (0.0 <= v <= 1.0):
                raise InvalidConfigurationError(
                    f"Error rate for {k} must be in [0,1], got {v}"
                )

    @staticmethod
    def illustrative_default() -> "ErrorRateConfig":
        return ErrorRateConfig(rates={
            ErrorType.BIT_FLIP: 1e-12,
            ErrorType.RETENTION_ERROR: 1e-10,
            ErrorType.ROW_DISTURBANCE: 1e-11,
            ErrorType.TIMING_ERROR: 1e-13,
            ErrorType.VOLTAGE_ERROR: 1e-13,
            ErrorType.TEMPERATURE_ERROR: 1e-12,
            ErrorType.INTERFACE_ERROR: 1e-14,
            ErrorType.CONTROLLER_ERROR: 1e-15,
        })


@dataclass
class ReliabilityEngine:
    config: ErrorRateConfig = field(default_factory=ErrorRateConfig.illustrative_default)

    def simulate_bit_errors(self, n_bits: int, error_type: ErrorType,
                             seed: Optional[int] = None,
                             rate_multiplier: float = 1.0) -> EngineeringResult:
        """Draw a SIMULATED count of bit errors out of n_bits using the
        configured (possibly multiplier-scaled, e.g. by temperature)
        per-bit probability."""
        if n_bits < 0:
            raise InvalidConfigurationError("n_bits must be >= 0")
        p = min(1.0, self.config.rates.get(error_type, 0.0) * rate_multiplier)
        rng = np.random.default_rng(seed)
        n_errors = int(rng.binomial(n=n_bits, p=p)) if n_bits > 0 else 0
        return EngineeringResult(
            value=n_errors, unit="count",
            equation="n_errors ~ Binomial(n_bits, p_error)",
            inputs={"n_bits": n_bits, "error_type": error_type.value,
                    "p_error_per_bit": p, "rate_multiplier": rate_multiplier, "seed": seed},
            assumptions=(
                "SIMULATED error injection: independent-bit Bernoulli "
                "model, no spatial/temporal correlation between errors.",
                "Configured rates are illustrative, not measured hardware "
                "failure-in-time (FIT) data.",
            ),
            fidelity=Fidelity.FIDELITY_1,
            provenance=Provenance.SIMULATED,
        )

    def temperature_rate_multiplier(self, temperature_c: float,
                                     reference_c: float = 85.0,
                                     doubling_per_c: float = 10.0) -> float:
        """Simple 'doubles every N degrees above reference' scaling,
        matching the qualitative direction of real leakage/retention
        temperature dependence (see DRAMCell.tau_at_temperature_ns for the
        Arrhenius-based version used for retention specifically)."""
        return 2.0 ** ((temperature_c - reference_c) / doubling_per_c)
