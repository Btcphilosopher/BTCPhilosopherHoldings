"""
dramcore.validation.suite

Validation suite (spec section 70) and conservation/invariant tests (spec
section 71), exposed as a single callable used by both the CLI
(`dramcore validate`) and pytest (`tests/test_validation_suite.py`).
"""
from __future__ import annotations

from typing import List, Tuple

from dramcore.address_mapping.mapper import AddressMapper, InterleavingPolicy
from dramcore.commands.command import CommandType, DRAMCommand
from dramcore.controller.controller import PagePolicy
from dramcore.controller.simulation import Simulation
from dramcore.core.result import TimingViolationError
from dramcore.device.dram_device import DRAMDevice
from dramcore.scheduler.scheduler import SchedulerPolicy
from dramcore.timing.engine import TimingEngine
from dramcore.traffic.generators import TrafficConfig, random_traffic, sequential_read


class ValidationCheck:
    def __init__(self, name: str):
        self.name = name
        self.passed = False
        self.detail = ""

    def ok(self, detail: str = ""):
        self.passed = True
        self.detail = detail
        return self

    def fail(self, detail: str):
        self.passed = False
        self.detail = detail
        return self


def check_address_mapping_determinism() -> ValidationCheck:
    c = ValidationCheck("address_mapping_determinism")
    device = DRAMDevice.synthetic_ddr5_like()
    mapper = AddressMapper(device=device, n_channels=2, n_ranks=1,
                            policy=InterleavingPolicy.CACHE_LINE_AWARE)
    addr = 123456789
    d1 = mapper.decode(addr)
    d2 = mapper.decode(addr)
    if d1 == d2:
        return c.ok("Same address decoded identically across repeated calls")
    return c.fail(f"Non-deterministic decode: {d1} != {d2}")


def check_command_legality_enforced() -> ValidationCheck:
    c = ValidationCheck("command_legality_enforced")
    device = DRAMDevice.synthetic_ddr5_like()
    te = TimingEngine(timing=device.timing_profile)
    from dramcore.bank.bank import DRAMBank
    from dramcore.bank.bank_group import BankGroup
    from dramcore.rank.rank import DRAMRank

    rank = DRAMRank(rank_id=0, device_template=device)
    bank = rank.banks[0]
    bg = rank.bank_groups[bank.bank_group_id]

    bank.activate(row=5, timestamp_ns=0.0)
    rank.record_rank_activation(0.0)
    bg.record_activation(0.0)

    # Attempting a second ACT immediately (violates tRC/tRAS) must raise.
    illegal_cmd = DRAMCommand(command_type=CommandType.ACT, timestamp_ns=1.0,
                               channel=0, rank=0, bank=0, row=6)
    try:
        te.validate(illegal_cmd, bank=bank, bank_group=bg, rank=rank)
        return c.fail("Illegal immediate re-ACT was NOT rejected")
    except TimingViolationError:
        pass

    # A PRE issued before tRAS has elapsed must also raise.
    illegal_pre = DRAMCommand(command_type=CommandType.PRE, timestamp_ns=1.0,
                               channel=0, rank=0, bank=0)
    try:
        te.validate(illegal_pre, bank=bank, bank_group=bg, rank=rank)
        return c.fail("Illegal early PRE was NOT rejected")
    except TimingViolationError:
        pass

    return c.ok("Illegal ACT-before-tRC and PRE-before-tRAS both correctly rejected")


def check_row_classification_consistency() -> ValidationCheck:
    c = ValidationCheck("row_classification_consistency")
    device = DRAMDevice.synthetic_ddr5_like()
    sim = Simulation(device=device, n_channels=1, n_ranks_per_channel=1,
                      scheduler_policy=SchedulerPolicy.FR_FCFS)
    cfg = TrafficConfig(n_requests=500, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=1)
    reqs = sequential_read(cfg)
    sim.run(reqs)
    hits = sum(b.row_hits for _, _, b in sim.topology.all_banks())
    misses = sum(b.row_misses for _, _, b in sim.topology.all_banks())
    conflicts = sum(b.row_conflicts for _, _, b in sim.topology.all_banks())
    if hits + misses + conflicts != 500:
        return c.fail(f"Classification counts don't sum to request count: "
                      f"{hits}+{misses}+{conflicts} != 500")
    if hits == 0:
        return c.fail("Sequential access pattern produced zero row hits (expected many)")
    return c.ok(f"hits={hits} misses={misses} conflicts={conflicts}, sums correctly")


def check_conservation_of_requests() -> ValidationCheck:
    c = ValidationCheck("conservation_of_requests")
    device = DRAMDevice.synthetic_ddr5_like()
    sim = Simulation(device=device, n_channels=2, queue_depth=32)
    cfg = TrafficConfig(n_requests=800, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=0.5, seed=2)
    reqs = random_traffic(cfg)
    result = sim.run(reqs)
    if result.n_requests != len(reqs):
        return c.fail(f"completed({result.n_requests}) != submitted({len(reqs)}); "
                      f"requested_bytes must equal completed+failed+cancelled bytes")
    for r in result.requests:
        if r.completion_time_ns is None:
            return c.fail(f"Request {r.request_id} marked complete without a completion time")
        if r.completion_time_ns < r.arrival_time_ns:
            return c.fail(f"Request {r.request_id} completed before it arrived")
    return c.ok(f"All {len(reqs)} submitted requests accounted for as completed")


def check_energy_and_latency_non_negative() -> ValidationCheck:
    c = ValidationCheck("energy_and_latency_non_negative")
    device = DRAMDevice.synthetic_ddr5_like()
    sim = Simulation(device=device, n_channels=2)
    cfg = TrafficConfig(n_requests=500, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=3)
    result = sim.run(random_traffic(cfg))
    if result.power.value < 0:
        return c.fail(f"Negative average power: {result.power.value}")
    for r in result.requests:
        lat = r.total_latency_ns()
        if lat is not None and lat < 0:
            return c.fail(f"Negative latency for request {r.request_id}: {lat}")
    return c.ok("Power and all per-request latencies are non-negative")


def check_bandwidth_energy_invariants() -> ValidationCheck:
    c = ValidationCheck("bandwidth_and_energy_invariants")
    device = DRAMDevice.synthetic_ddr5_like()
    sim = Simulation(device=device, n_channels=2)
    cfg = TrafficConfig(n_requests=1000, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=4)
    result = sim.run(sequential_read(cfg))
    total_bytes = sum(r.size_bytes for r in result.requests)
    expected_bw = (total_bytes / 1e9) / (result.elapsed_ns / 1e9)
    if abs(expected_bw - result.bandwidth.value) > 1e-6:
        return c.fail(f"bandwidth = bytes/time invariant violated: "
                      f"{expected_bw} != {result.bandwidth.value}")
    return c.ok("bandwidth = bytes / elapsed_time holds exactly")


def check_channel_scaling_monotonic() -> ValidationCheck:
    c = ValidationCheck("channel_scaling_never_reduces_theoretical_bandwidth")
    device = DRAMDevice.synthetic_ddr5_like()
    bws = []
    for n_ch in (1, 2, 4, 8):
        sim = Simulation(device=device, n_channels=n_ch)
        bws.append(sim.topology.total_theoretical_bandwidth_gbps())
    if any(bws[i] > bws[i + 1] for i in range(len(bws) - 1)):
        return c.fail(f"Theoretical bandwidth decreased with more channels: {bws}")
    return c.ok(f"Theoretical bandwidth non-decreasing across channel counts: {bws}")


def check_determinism_same_seed() -> ValidationCheck:
    c = ValidationCheck("determinism_same_seed_same_config")
    device = DRAMDevice.synthetic_ddr5_like()

    def one_run():
        sim = Simulation(device=DRAMDevice.synthetic_ddr5_like(), n_channels=2, seed=99)
        cfg = TrafficConfig(n_requests=400, address_space_bytes=sim.topology.total_capacity_bytes,
                             request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=99)
        result = sim.run(random_traffic(cfg))
        return result.summary()

    s1, s2 = one_run(), one_run()
    if s1 != s2:
        return c.fail(f"Same seed + config produced different results:\n{s1}\nvs\n{s2}")
    return c.ok("Identical seed+configuration reproduced identical summary results")


def check_achieved_bandwidth_never_exceeds_theoretical() -> ValidationCheck:
    c = ValidationCheck("achieved_bandwidth_never_exceeds_theoretical_peak")
    device = DRAMDevice.synthetic_ddr5_like()
    sim = Simulation(device=device, n_channels=2, queue_depth=256)
    cfg = TrafficConfig(n_requests=3000, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=256, mean_inter_arrival_ns=0.05, seed=11)
    result = sim.run(sequential_read(cfg))
    theoretical = sim.topology.total_theoretical_bandwidth_gbps()
    if result.bandwidth.value > theoretical + 1e-6:
        return c.fail(f"Achieved bandwidth {result.bandwidth.value:.2f} GB/s exceeds "
                      f"theoretical peak {theoretical:.2f} GB/s -- physically impossible")
    return c.ok(f"Achieved {result.bandwidth.value:.2f} GB/s <= theoretical peak {theoretical:.2f} GB/s")


ALL_CHECKS = [
    check_address_mapping_determinism,
    check_command_legality_enforced,
    check_row_classification_consistency,
    check_conservation_of_requests,
    check_energy_and_latency_non_negative,
    check_bandwidth_energy_invariants,
    check_channel_scaling_monotonic,
    check_determinism_same_seed,
    check_achieved_bandwidth_never_exceeds_theoretical,
]


def run_all_validations() -> Tuple[bool, str]:
    lines = ["DRAMCORE.OS VALIDATION SUITE", "=" * 40]
    all_ok = True
    for check_fn in ALL_CHECKS:
        result = check_fn()
        status = "PASS" if result.passed else "FAIL"
        if not result.passed:
            all_ok = False
        lines.append(f"[{status}] {result.name}: {result.detail}")
    lines.append("=" * 40)
    lines.append("OVERALL: " + ("PASS" if all_ok else "FAIL"))
    return all_ok, "\n".join(lines)
