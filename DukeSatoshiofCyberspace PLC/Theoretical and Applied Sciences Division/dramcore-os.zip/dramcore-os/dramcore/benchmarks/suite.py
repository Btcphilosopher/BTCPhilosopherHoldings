"""
dramcore.benchmarks.suite

Standard synthetic benchmarks (spec section 74).
"""
from __future__ import annotations

from typing import Optional

from dramcore.controller.controller import PagePolicy
from dramcore.controller.simulation import Simulation, SimulationResult
from dramcore.device.dram_device import DRAMDevice
from dramcore.refresh.profile import RefreshProfile
from dramcore.scheduler.scheduler import SchedulerPolicy
from dramcore.timing.profile import TimingProfile
from dramcore.traffic.generators import (
    TrafficConfig, bursty, mixed, random_traffic, sequential_read, sequential_write,
    strided,
)


def _default_sim(n_channels=2, scheduler=SchedulerPolicy.FR_FCFS,
                  page_policy=PagePolicy.OPEN_PAGE, device: Optional[DRAMDevice] = None) -> Simulation:
    device = device or DRAMDevice.synthetic_ddr5_like()
    return Simulation(device=device, n_channels=n_channels, scheduler_policy=scheduler,
                       page_policy=page_policy, queue_depth=128)


def bench_streaming_read(n_requests=5000, seed=42) -> SimulationResult:
    sim = _default_sim()
    cfg = TrafficConfig(n_requests=n_requests, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=seed)
    return sim.run(sequential_read(cfg))


def bench_streaming_write(n_requests=5000, seed=42) -> SimulationResult:
    sim = _default_sim()
    cfg = TrafficConfig(n_requests=n_requests, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=seed)
    return sim.run(sequential_write(cfg))


def bench_random_read(n_requests=5000, seed=42) -> SimulationResult:
    sim = _default_sim()
    cfg = TrafficConfig(n_requests=n_requests, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, write_fraction=0.0, seed=seed)
    return sim.run(random_traffic(cfg))


def bench_random_write(n_requests=5000, seed=42) -> SimulationResult:
    sim = _default_sim()
    cfg = TrafficConfig(n_requests=n_requests, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, write_fraction=1.0, seed=seed)
    return sim.run(random_traffic(cfg))


def bench_mixed_traffic(n_requests=5000, seed=42) -> SimulationResult:
    sim = _default_sim()
    cfg = TrafficConfig(n_requests=n_requests, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, write_fraction=0.3, seed=seed)
    return sim.run(mixed(cfg, sequential_fraction=0.5))


def bench_row_hit(n_requests=5000, seed=42) -> SimulationResult:
    """Deliberately high-locality: tight address range, forcing row hits."""
    sim = _default_sim()
    cfg = TrafficConfig(n_requests=n_requests, address_space_bytes=sim.device.page_size_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=seed)
    return sim.run(sequential_read(cfg))


def bench_row_conflict(n_requests=5000, seed=42) -> SimulationResult:
    """Deliberately low-locality: strided across row-size boundary on
    every access, forcing a conflict nearly every time."""
    sim = _default_sim()
    stride = sim.device.page_size_bytes * sim.device.banks  # jump past all banks' rows
    cfg = TrafficConfig(n_requests=n_requests, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=seed)
    return sim.run(strided(cfg, stride_bytes=sim.device.page_size_bytes))


def bench_bank_conflict(n_requests=5000, seed=42) -> SimulationResult:
    sim = _default_sim(n_channels=1)
    cfg = TrafficConfig(n_requests=n_requests, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=0.5, seed=seed)
    return sim.run(random_traffic(cfg))


def bench_channel_saturation(n_requests=5000, seed=42) -> SimulationResult:
    sim = _default_sim(n_channels=1)
    cfg = TrafficConfig(n_requests=n_requests, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=0.05, seed=seed)
    return sim.run(sequential_read(cfg))


def bench_refresh_heavy(n_requests=2000, seed=42) -> SimulationResult:
    device = DRAMDevice.synthetic_ddr5_like()
    device = DRAMDevice(**{**device.__dict__, "refresh_profile": RefreshProfile(
        refresh_interval_ns=200.0, refresh_duration_ns=100.0)})
    sim = Simulation(device=device, n_channels=2)
    cfg = TrafficConfig(n_requests=n_requests, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=2.0, seed=seed)
    return sim.run(random_traffic(cfg))


def bench_ai_bandwidth(n_requests=5000, seed=42) -> SimulationResult:
    sim = _default_sim()
    cfg = TrafficConfig(n_requests=n_requests, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=256, mean_inter_arrival_ns=0.2, write_fraction=0.05, seed=seed)
    return sim.run(sequential_read(cfg))


def bench_latency_sensitive(n_requests=3000, seed=42) -> SimulationResult:
    sim = _default_sim(scheduler=SchedulerPolicy.DEADLINE)
    cfg = TrafficConfig(n_requests=n_requests, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=3.0, seed=seed)
    reqs = random_traffic(cfg)
    for r in reqs:
        r.deadline_ns = r.arrival_time_ns + 500.0
    return sim.run(reqs)


BENCHMARKS = {
    "STREAMING_READ": bench_streaming_read,
    "STREAMING_WRITE": bench_streaming_write,
    "RANDOM_READ": bench_random_read,
    "RANDOM_WRITE": bench_random_write,
    "MIXED_TRAFFIC": bench_mixed_traffic,
    "ROW_HIT": bench_row_hit,
    "ROW_CONFLICT": bench_row_conflict,
    "BANK_CONFLICT": bench_bank_conflict,
    "CHANNEL_SATURATION": bench_channel_saturation,
    "REFRESH_HEAVY": bench_refresh_heavy,
    "AI_BANDWIDTH": bench_ai_bandwidth,
    "LATENCY_SENSITIVE": bench_latency_sensitive,
}
