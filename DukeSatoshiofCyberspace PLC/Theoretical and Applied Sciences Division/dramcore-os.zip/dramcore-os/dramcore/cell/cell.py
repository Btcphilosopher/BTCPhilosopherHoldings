"""
dramcore.cell.cell

Conceptual DRAM cell model (spec section 6). This is explicitly a
FIDELITY_1 architectural abstraction: Q = C*V and exponential charge decay
Q(t) = Q0 * exp(-t/tau). This is NOT transistor-level / SPICE / TCAD
semiconductor physics (spec section 111) -- it captures the *architectural
consequence* of leakage (finite retention time -> refresh requirement)
without claiming device-physics accuracy.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from dramcore.core.result import EngineeringResult, Fidelity, InvalidConfigurationError
from dramcore.core.units import charge_fc, celsius_to_kelvin, BOLTZMANN_EV_PER_K


@dataclass(frozen=True)
class DRAMCell:
    """A single conceptual storage cell: one access transistor + one
    storage capacitor, addressed by one wordline and one bitline."""

    capacitance_ff: float = 25.0     # storage capacitance, femtofarads (illustrative)
    leakage_time_constant_ns: float = 64_000_000.0  # tau at reference temp, ns (illustrative ~64ms)
    reference_temperature_c: float = 85.0  # datasheet-style worst-case reference temp
    activation_energy_ev: float = 0.6      # Arrhenius activation energy, illustrative

    def __post_init__(self):
        if self.capacitance_ff <= 0:
            raise InvalidConfigurationError("capacitance_ff must be > 0")
        if self.leakage_time_constant_ns <= 0:
            raise InvalidConfigurationError("leakage_time_constant_ns must be > 0")

    def stored_charge_fc(self, voltage_v: float) -> EngineeringResult:
        q = charge_fc(self.capacitance_ff, voltage_v)
        return EngineeringResult(
            value=q, unit="fC", equation="Q = C * V",
            inputs={"capacitance_ff": self.capacitance_ff, "voltage_v": voltage_v},
            assumptions=("Linear capacitor model; ignores cell-transistor "
                         "non-idealities and sub-threshold leakage detail.",),
            fidelity=Fidelity.FIDELITY_1,
        )

    def tau_at_temperature_ns(self, temperature_c: float) -> float:
        """Arrhenius-style scaling of the leakage time constant with
        temperature: tau(T) = tau_ref * exp[ (Ea/k) * (1/T - 1/T_ref) ],
        with T in Kelvin. Higher temperature -> shorter tau (faster decay),
        consistent with leakage-current physics increasing with temperature.
        """
        t_k = celsius_to_kelvin(temperature_c)
        t_ref_k = celsius_to_kelvin(self.reference_temperature_c)
        exponent = (self.activation_energy_ev / BOLTZMANN_EV_PER_K) * (
            1.0 / t_k - 1.0 / t_ref_k
        )
        return self.leakage_time_constant_ns * math.exp(exponent)

    def charge_after_decay(self, q0_fc: float, elapsed_ns: float,
                            temperature_c: float) -> EngineeringResult:
        """Q(t) = Q0 * exp(-t / tau(T))"""
        tau = self.tau_at_temperature_ns(temperature_c)
        q_t = q0_fc * math.exp(-elapsed_ns / tau)
        return EngineeringResult(
            value=q_t, unit="fC",
            equation="Q(t) = Q0 * exp(-t / tau(T))",
            inputs={"Q0_fC": q0_fc, "elapsed_ns": elapsed_ns,
                    "temperature_c": temperature_c, "tau_ns": tau},
            assumptions=(
                "Single-exponential leakage decay model.",
                "Arrhenius temperature scaling with a single fixed "
                "activation energy; real leakage has multiple competing "
                "mechanisms (junction leakage, subthreshold, GIDL) with "
                "different temperature dependences.",
                "Not SPICE/TCAD-level device physics (see spec section 111).",
            ),
            fidelity=Fidelity.FIDELITY_1,
        )

    def retention_time_ns(self, temperature_c: float,
                           sense_margin_fraction: float = 0.5) -> EngineeringResult:
        """Time until charge decays to `sense_margin_fraction` of Q0 -- the
        point at which the sense amplifier can no longer reliably
        distinguish stored '1' from '0'. t = -tau * ln(margin)."""
        if not (0.0 < sense_margin_fraction < 1.0):
            raise InvalidConfigurationError(
                "sense_margin_fraction must be in (0, 1)"
            )
        tau = self.tau_at_temperature_ns(temperature_c)
        t_ret = -tau * math.log(sense_margin_fraction)
        return EngineeringResult(
            value=t_ret, unit="ns",
            equation="t_retention = -tau(T) * ln(sense_margin_fraction)",
            inputs={"temperature_c": temperature_c,
                    "sense_margin_fraction": sense_margin_fraction, "tau_ns": tau},
            assumptions=(
                "Single-exponential decay; fixed sense-amplifier margin "
                "threshold; ignores bit-line coupling and disturbance "
                "effects (see row-disturbance model for those).",
            ),
            fidelity=Fidelity.FIDELITY_1,
            validity_range="0C to 125C ambient (typical DRAM commercial range)",
        )
