"""
dramcore.cell.retention

Statistical retention model over a population of cells (spec section 7).
Real DRAM arrays exhibit a wide distribution of per-cell retention times
due to process variation; a small population of "weak cells" dominates the
tail and drives the required refresh interval. This module generates that
distribution explicitly rather than assuming a single deterministic
retention time for the whole array.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

from dramcore.cell.cell import DRAMCell
from dramcore.core.result import EngineeringResult, Fidelity, InvalidConfigurationError


@dataclass(frozen=True)
class RetentionModel:
    cell: DRAMCell
    process_variation_sigma_fraction: float = 0.15
    """Fractional (1-sigma) variation applied to leakage_time_constant_ns
    across the population, modelling process variation in leakage current
    from cell to cell."""

    def __post_init__(self):
        if self.process_variation_sigma_fraction < 0:
            raise InvalidConfigurationError(
                "process_variation_sigma_fraction must be >= 0"
            )

    def sample_population(self, n_cells: int, temperature_c: float,
                           sense_margin_fraction: float = 0.5,
                           seed: Optional[int] = None) -> EngineeringResult:
        """Draw a population of `n_cells` retention times (ns) at a given
        temperature, with each cell's tau perturbed by lognormal process
        variation (lognormal keeps tau strictly positive)."""
        if n_cells <= 0:
            raise InvalidConfigurationError("n_cells must be > 0")
        rng = np.random.default_rng(seed)
        sigma = self.process_variation_sigma_fraction
        # lognormal parameterised so that the *median* multiplier is 1.0
        mult = rng.lognormal(mean=0.0, sigma=sigma, size=n_cells) if sigma > 0 else \
            np.ones(n_cells)

        base_tau = self.cell.tau_at_temperature_ns(temperature_c)
        tau_population = base_tau * mult
        retention_times = -tau_population * np.log(sense_margin_fraction)

        return EngineeringResult(
            value=retention_times, unit="ns",
            equation="t_i = -tau_ref(T) * variation_multiplier_i * ln(margin)",
            inputs={"n_cells": n_cells, "temperature_c": temperature_c,
                    "sense_margin_fraction": sense_margin_fraction,
                    "process_variation_sigma_fraction": sigma, "seed": seed},
            assumptions=(
                "Lognormal process variation applied independently per cell "
                "(no spatial correlation modelled).",
                "Single-exponential decay per cell (see DRAMCell).",
            ),
            fidelity=Fidelity.FIDELITY_1,
        )

    def summary_statistics(self, n_cells: int, temperature_c: float,
                            sense_margin_fraction: float = 0.5,
                            seed: Optional[int] = None) -> dict:
        pop = self.sample_population(n_cells, temperature_c,
                                      sense_margin_fraction, seed).value
        return {
            "min_ns": float(np.min(pop)),
            "max_ns": float(np.max(pop)),
            "mean_ns": float(np.mean(pop)),
            "median_ns": float(np.median(pop)),
            "p0_1_ns": float(np.percentile(pop, 0.1)),
            "p1_ns": float(np.percentile(pop, 1)),
            "p99_ns": float(np.percentile(pop, 99)),
            "std_ns": float(np.std(pop)),
        }

    def required_refresh_interval_ns(self, n_cells: int, temperature_c: float,
                                      safety_margin_fraction: float = 0.5,
                                      sense_margin_fraction: float = 0.5,
                                      seed: Optional[int] = None) -> EngineeringResult:
        """The refresh interval must be shorter than the *weakest* cell's
        retention time (the population minimum), reduced further by an
        engineering safety margin. This connects the statistical
        population model to a single actionable refresh requirement."""
        stats = self.summary_statistics(n_cells, temperature_c,
                                         sense_margin_fraction, seed)
        weakest = stats["min_ns"]
        required = weakest * (1.0 - safety_margin_fraction)
        return EngineeringResult(
            value=required, unit="ns",
            equation="t_refresh_required = min(population_retention) * (1 - safety_margin)",
            inputs={"weakest_cell_retention_ns": weakest,
                    "safety_margin_fraction": safety_margin_fraction,
                    "n_cells_sampled": n_cells, "temperature_c": temperature_c},
            assumptions=(
                "Population minimum from a finite Monte Carlo sample "
                "under-estimates the true tail for small n_cells; larger "
                "n_cells gives a better estimate of the true weak-cell tail.",
                "Independent per-cell variation (no spatial/row correlation).",
            ),
            fidelity=Fidelity.FIDELITY_1,
        )
