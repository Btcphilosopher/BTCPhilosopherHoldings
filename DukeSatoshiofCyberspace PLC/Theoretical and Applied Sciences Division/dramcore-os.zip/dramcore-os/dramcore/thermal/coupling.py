"""
dramcore.thermal.coupling

Connects the thermal model to retention and refresh (spec section 31):

    POWER -> TEMPERATURE -> RETENTION -> REFRESH REQUIREMENT -> PERFORMANCE

and to thermal throttling policy (spec section 32): thermal state can
scale the refresh-rate multiplier and (optionally) cap achievable
bandwidth/frequency.
"""
from __future__ import annotations

from dataclasses import dataclass

from dramcore.cell.cell import DRAMCell
from dramcore.refresh.profile import RefreshProfile
from dramcore.thermal.engine import ThermalState


# Refresh-rate multiplier by thermal state, per JEDEC-style "2x refresh"
# conventions triggered by elevated temperature (illustrative thresholds,
# configurable via ThermalPolicy elsewhere).
_REFRESH_MULTIPLIER_BY_STATE = {
    ThermalState.NORMAL: 1.0,
    ThermalState.WARNING: 2.0,
    ThermalState.THROTTLED: 4.0,
    ThermalState.CRITICAL: 4.0,
}

# Bandwidth cap (fraction of nominal) applied under throttling.
_BANDWIDTH_CAP_BY_STATE = {
    ThermalState.NORMAL: 1.0,
    ThermalState.WARNING: 1.0,
    ThermalState.THROTTLED: 0.5,
    ThermalState.CRITICAL: 0.25,
}


def refresh_profile_for_thermal_state(base_profile: RefreshProfile,
                                       state: ThermalState) -> RefreshProfile:
    """Return a new RefreshProfile with the refresh_count_multiplier
    adjusted for the given thermal state (higher temperature -> shorter
    retention -> more frequent refresh required)."""
    mult = _REFRESH_MULTIPLIER_BY_STATE[state]
    return RefreshProfile(
        name=f"{base_profile.name}_thermal_{state.value}",
        policy=base_profile.policy,
        refresh_interval_ns=base_profile.refresh_interval_ns,
        refresh_duration_ns=base_profile.refresh_duration_ns,
        banks_per_refresh_burst=base_profile.banks_per_refresh_burst,
        refresh_count_multiplier=mult,
    )


def bandwidth_cap_fraction(state: ThermalState) -> float:
    return _BANDWIDTH_CAP_BY_STATE[state]


@dataclass(frozen=True)
class ThermalRetentionSummary:
    temperature_c: float
    thermal_state: ThermalState
    retention_time_ns: float
    required_refresh_interval_ns: float
    refresh_multiplier_applied: float


def evaluate_causal_chain(cell: DRAMCell, temperature_c: float,
                           thermal_state: ThermalState,
                           sense_margin_fraction: float = 0.5) -> ThermalRetentionSummary:
    """Walk the full POWER -> TEMPERATURE -> RETENTION -> REFRESH chain for
    a single representative cell at the given (already-computed)
    temperature and thermal state."""
    retention = cell.retention_time_ns(temperature_c, sense_margin_fraction)
    mult = _REFRESH_MULTIPLIER_BY_STATE[thermal_state]
    # Required refresh interval must clear the retention time with margin,
    # and is tightened further by the thermal-state multiplier.
    required = (retention.value * 0.5) / mult
    return ThermalRetentionSummary(
        temperature_c=temperature_c,
        thermal_state=thermal_state,
        retention_time_ns=retention.value,
        required_refresh_interval_ns=required,
        refresh_multiplier_applied=mult,
    )
