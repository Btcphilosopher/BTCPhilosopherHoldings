"""
dramcore.thermal.engine

Simplified dynamic thermal model (spec section 30-32):

    C * dT/dt = P - (T - T_ambient) / R

integrated explicitly (forward Euler, with a documented step-size
validity caveat) rather than hidden inside an opaque "thermal factor".
Connects to retention (spec 31) and thermal throttling policy (spec 32).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Tuple

from dramcore.core.result import EngineeringResult, Fidelity, InvalidConfigurationError


class ThermalState(str, Enum):
    NORMAL = "NORMAL"
    WARNING = "WARNING"
    THROTTLED = "THROTTLED"
    CRITICAL = "CRITICAL"


@dataclass(frozen=True)
class ThermalPolicy:
    warning_temp_c: float = 75.0
    throttle_temp_c: float = 85.0
    critical_temp_c: float = 95.0

    def classify(self, temp_c: float) -> ThermalState:
        if temp_c >= self.critical_temp_c:
            return ThermalState.CRITICAL
        if temp_c >= self.throttle_temp_c:
            return ThermalState.THROTTLED
        if temp_c >= self.warning_temp_c:
            return ThermalState.WARNING
        return ThermalState.NORMAL


@dataclass
class ThermalModel:
    thermal_resistance_c_per_w: float = 8.0   # R: junction-to-ambient
    thermal_mass_j_per_c: float = 0.05        # C: lumped thermal mass
    ambient_temperature_c: float = 35.0
    policy: ThermalPolicy = field(default_factory=ThermalPolicy)

    current_temperature_c: float = None

    def __post_init__(self):
        if self.thermal_resistance_c_per_w <= 0:
            raise InvalidConfigurationError("thermal_resistance_c_per_w must be > 0")
        if self.thermal_mass_j_per_c <= 0:
            raise InvalidConfigurationError("thermal_mass_j_per_c must be > 0")
        if self.current_temperature_c is None:
            self.current_temperature_c = self.ambient_temperature_c

    def step(self, power_w: float, dt_s: float) -> EngineeringResult:
        """Forward-Euler integration of C*dT/dt = P - (T-Tamb)/R over one
        step of duration dt_s (seconds). Caller should keep dt_s small
        relative to the thermal time constant R*C for numerical stability
        -- see validity_range."""
        r, c = self.thermal_resistance_c_per_w, self.thermal_mass_j_per_c
        tau_s = r * c
        if dt_s > 0.5 * tau_s:
            import warnings
            warnings.warn(
                f"Thermal integration step dt_s={dt_s} is large relative to "
                f"thermal time constant tau={tau_s}s; forward-Euler may be "
                f"inaccurate/unstable. Consider a smaller step.",
                stacklevel=2,
            )
        t = self.current_temperature_c
        dT = (power_w - (t - self.ambient_temperature_c) / r) / c * dt_s
        new_t = t + dT
        self.current_temperature_c = new_t
        return EngineeringResult(
            value=new_t, unit="C",
            equation="T(t+dt) = T(t) + [P - (T(t) - T_ambient)/R] / C * dt",
            inputs={"power_w": power_w, "dt_s": dt_s, "R_C_per_W": r, "C_J_per_C": c,
                    "T_ambient_c": self.ambient_temperature_c, "tau_s": tau_s},
            assumptions=(
                "Single lumped thermal node (no spatial gradient across "
                "the die/package/heatsink stack).",
                "Forward-Euler explicit integration; accuracy degrades if "
                "dt_s is not << R*C.",
            ),
            fidelity=Fidelity.FIDELITY_1,
        )

    def steady_state_temperature_c(self, power_w: float) -> EngineeringResult:
        """T_ss = T_ambient + P * R (dT/dt = 0)."""
        t_ss = self.ambient_temperature_c + power_w * self.thermal_resistance_c_per_w
        return EngineeringResult(
            value=t_ss, unit="C",
            equation="T_steady_state = T_ambient + P * R",
            inputs={"power_w": power_w, "R_C_per_W": self.thermal_resistance_c_per_w,
                    "T_ambient_c": self.ambient_temperature_c},
            fidelity=Fidelity.FIDELITY_1,
        )

    def thermal_margin_c(self) -> float:
        return self.policy.critical_temp_c - self.current_temperature_c

    def state(self) -> ThermalState:
        return self.policy.classify(self.current_temperature_c)

    def simulate_trace(self, power_trace_w: List[Tuple[float, float]]
                        ) -> List[Tuple[float, float]]:
        """power_trace_w: list of (duration_s, power_w) segments. Returns
        list of (elapsed_s, temperature_c) samples, one per segment
        boundary."""
        trace = [(0.0, self.current_temperature_c)]
        elapsed = 0.0
        for duration_s, power_w in power_trace_w:
            # subdivide each segment for stability if long relative to tau
            tau = self.thermal_resistance_c_per_w * self.thermal_mass_j_per_c
            n_steps = max(1, int(duration_s / (0.1 * tau)) + 1)
            dt = duration_s / n_steps
            for _ in range(n_steps):
                self.step(power_w, dt)
                elapsed += dt
                trace.append((elapsed, self.current_temperature_c))
        return trace
