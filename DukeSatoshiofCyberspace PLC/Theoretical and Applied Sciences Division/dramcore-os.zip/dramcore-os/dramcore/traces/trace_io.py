"""
dramcore.traces.trace_io

Trace import (spec section 57) and deterministic replay (spec section
58). Canonical trace schema (``MemoryTrace``) fields: timestamp, address,
size, operation, source, thread, priority. Supports CSV and JSON directly
(stdlib only); Parquet/Arrow supported when ``pyarrow`` is installed.
"""
from __future__ import annotations

import csv
import json
from dataclasses import asdict
from typing import List, Optional

from dramcore.controller.request import MemoryRequest, RequestOperation
from dramcore.core.result import InvalidConfigurationError

CANONICAL_FIELDS = ["timestamp", "address", "size", "operation", "source", "thread", "priority"]


def export_csv(requests: List[MemoryRequest], path: str) -> None:
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CANONICAL_FIELDS)
        writer.writeheader()
        for r in requests:
            writer.writerow({
                "timestamp": r.timestamp_ns, "address": r.address, "size": r.size_bytes,
                "operation": r.operation.value, "source": r.source, "thread": 0,
                "priority": r.priority,
            })


def import_csv(path: str, id_offset: int = 0) -> List[MemoryRequest]:
    reqs = []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader):
            reqs.append(_row_to_request(row, id_offset + i))
    return reqs


def export_json(requests: List[MemoryRequest], path: str) -> None:
    records = [{
        "timestamp": r.timestamp_ns, "address": r.address, "size": r.size_bytes,
        "operation": r.operation.value, "source": r.source, "thread": 0,
        "priority": r.priority,
    } for r in requests]
    with open(path, "w") as f:
        json.dump(records, f, indent=2)


def import_json(path: str, id_offset: int = 0) -> List[MemoryRequest]:
    with open(path) as f:
        records = json.load(f)
    return [_row_to_request(row, id_offset + i) for i, row in enumerate(records)]


def _row_to_request(row: dict, request_id: int) -> MemoryRequest:
    try:
        op = RequestOperation(str(row["operation"]).upper())
    except ValueError:
        raise InvalidConfigurationError(f"Unknown operation in trace: {row['operation']}")
    return MemoryRequest(
        request_id=request_id,
        timestamp_ns=float(row["timestamp"]),
        address=int(row["address"]),
        size_bytes=int(row["size"]),
        operation=op,
        source=str(row.get("source", "trace")),
        priority=int(row.get("priority", 0) or 0),
    )


def export_parquet(requests: List[MemoryRequest], path: str) -> None:
    try:
        import pyarrow as pa
        import pyarrow.parquet as pq
    except ImportError as e:
        raise ImportError("export_parquet requires pyarrow (pip install pyarrow)") from e
    table = pa.table({
        "timestamp": [r.timestamp_ns for r in requests],
        "address": [r.address for r in requests],
        "size": [r.size_bytes for r in requests],
        "operation": [r.operation.value for r in requests],
        "source": [r.source for r in requests],
        "priority": [r.priority for r in requests],
    })
    pq.write_table(table, path)


def import_parquet(path: str, id_offset: int = 0) -> List[MemoryRequest]:
    try:
        import pyarrow.parquet as pq
    except ImportError as e:
        raise ImportError("import_parquet requires pyarrow (pip install pyarrow)") from e
    table = pq.read_table(path)
    rows = table.to_pylist()
    return [_row_to_request(row, id_offset + i) for i, row in enumerate(rows)]


def verify_deterministic_replay(requests: List[MemoryRequest], run_fn, n_repeats: int = 2) -> bool:
    """Replay the same trace through `run_fn` (a callable taking a request
    list and returning a SimulationResult-like object with .summary())
    `n_repeats` times and verify identical results -- the determinism
    guarantee from spec section 58/59."""
    import copy
    summaries = []
    for _ in range(n_repeats):
        reqs_copy = copy.deepcopy(requests)
        for r in reqs_copy:
            r.channel = r.rank = r.bank_group = r.bank = r.row = r.column = None
            r.completion_time_ns = r.service_start_ns = None
        result = run_fn(reqs_copy)
        summaries.append(result.summary())
    return all(s == summaries[0] for s in summaries)
