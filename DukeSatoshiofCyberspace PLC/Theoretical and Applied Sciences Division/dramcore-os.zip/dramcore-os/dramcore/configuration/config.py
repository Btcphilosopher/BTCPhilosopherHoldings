"""
dramcore.configuration.config

YAML/JSON configuration loading (spec section 84). Values loaded here are
treated as illustrative synthetic configuration, not a claim about any
specific commercial part, per spec section 84's explicit instruction.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, Optional

import yaml

from dramcore.controller.controller import PagePolicy
from dramcore.core.result import InvalidConfigurationError
from dramcore.device.dram_device import DRAMDevice
from dramcore.power.profile import PowerProfile
from dramcore.refresh.profile import RefreshProfile
from dramcore.scheduler.scheduler import SchedulerPolicy
from dramcore.timing.profile import TimingProfile


def load_config(path: str) -> Dict[str, Any]:
    with open(path) as f:
        if path.endswith(".json"):
            return json.load(f)
        return yaml.safe_load(f)


def device_from_config(cfg: Dict[str, Any]) -> DRAMDevice:
    d = cfg.get("dram", {})
    timing_cfg = cfg.get("timing", {})
    power_cfg = cfg.get("power", {})
    refresh_cfg = cfg.get("refresh", {})

    required = ("density_gb", "channels", "banks", "bank_groups", "rows", "columns",
                "data_rate_mt_s")
    missing = [k for k in required if k not in d]
    if missing:
        raise InvalidConfigurationError(f"Config missing required 'dram' keys: {missing}")

    timing = TimingProfile(name=cfg.get("name", "config_timing"), **{
        k: v for k, v in timing_cfg.items() if k in TimingProfile.__dataclass_fields__
    })
    power = PowerProfile(name=cfg.get("name", "config_power"), **{
        k: v for k, v in power_cfg.items() if k in PowerProfile.__dataclass_fields__
    })
    refresh = RefreshProfile(name=cfg.get("name", "config_refresh"), **{
        k: v for k, v in refresh_cfg.items() if k in RefreshProfile.__dataclass_fields__
    })

    return DRAMDevice(
        device_id=cfg.get("name", "config_device"),
        technology_node_nm=d.get("technology_node_nm", 14.0),
        density_gb=d["density_gb"],
        data_rate_mt_s=d["data_rate_mt_s"],
        bus_width_bits=d.get("bus_width_bits", 8),
        banks=d["banks"],
        bank_groups=d["bank_groups"],
        rows=d["rows"],
        columns=d["columns"],
        burst_length=d.get("burst_length", 16),
        voltage_v=d.get("voltage_v", 1.1),
        timing_profile=timing,
        refresh_profile=refresh,
        power_profile=power,
    )


def controller_config_from_config(cfg: Dict[str, Any]) -> Dict[str, Any]:
    c = cfg.get("controller", {})
    return {
        "scheduler_policy": SchedulerPolicy(c.get("scheduler", "fr_fcfs").upper()),
        "page_policy": PagePolicy(c.get("page_policy", "OPEN_PAGE").upper()),
        "queue_depth": c.get("queue_depth", 128),
    }


EXAMPLE_CONFIG_YAML = """\
name: illustrative_synthetic_config
dram:
  density_gb: 32
  channels: 2
  ranks: 2
  banks: 16
  bank_groups: 4
  rows: 65536
  columns: 1024
  data_rate_mt_s: 6400
  bus_width_bits: 8
  burst_length: 16
timing:
  tCL: 36
  tRCD: 36
  tRP: 36
  tRAS: 76
  tRC: 112
  tRFC: 350
  tREFI: 7800
controller:
  scheduler: fr_fcfs
  page_policy: OPEN_PAGE
  queue_depth: 128
"""
