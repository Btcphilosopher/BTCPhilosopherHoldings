Reserved for benchmark run artifacts (spec section 102/74).
