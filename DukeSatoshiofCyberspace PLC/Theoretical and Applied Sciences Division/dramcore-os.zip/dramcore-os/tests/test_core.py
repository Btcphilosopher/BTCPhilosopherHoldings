import math
import warnings

import pytest

from dramcore.core.result import (
    EngineeringResult, Fidelity, InvalidConfigurationError, Provenance,
    TimingViolationError, ValidityRangeWarning, check_validity,
)
from dramcore.core.units import (
    cycles_to_ns, data_rate_mt_s_to_clock_period_ns, energy_pj, ns_to_cycles,
)
from dramcore.core.clock import EventLog, EventType, SimulationClock


def test_engineering_result_basic_fields():
    r = EngineeringResult(value=42.0, unit="ns", equation="x = 42")
    assert r.value == 42.0
    assert r.unit == "ns"
    assert float(r) == 42.0


def test_engineering_result_fidelity3_without_calibration_warns_in_notes():
    r = EngineeringResult(value=1.0, unit="ns", equation="x",
                           fidelity=Fidelity.FIDELITY_3, provenance=Provenance.SIMULATED)
    assert any("WARNING" in n for n in r.notes)


def test_engineering_result_scaled_preserves_equation_chain():
    r = EngineeringResult(value=10.0, unit="mW", equation="P = 10")
    r2 = r.scaled(2.0, new_unit="mW")
    assert r2.value == 20.0
    assert "10" in r2.equation


def test_check_validity_raises_on_nan():
    with pytest.raises(InvalidConfigurationError):
        check_validity(float("nan"), 0, 10, label="x")


def test_check_validity_warns_outside_range():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        check_validity(20, 0, 10, label="x")
        assert any(issubclass(warning.category, ValidityRangeWarning) for warning in w)


def test_data_rate_to_clock_period():
    # DDR: 6400 MT/s -> 3200 MHz clock -> period = 1000/3200 ns
    period = data_rate_mt_s_to_clock_period_ns(6400)
    assert math.isclose(period, 1000.0 / 3200.0)


def test_cycles_ns_roundtrip():
    period = 0.3125
    ns = cycles_to_ns(10, period)
    cycles = ns_to_cycles(ns, period)
    assert math.isclose(cycles, 10)


def test_energy_pj_dimensional_consistency():
    # 100 mW for 10 ns = 1000 pJ
    assert energy_pj(100.0, 10.0) == 1000.0


def test_simulation_clock_monotonic_advance():
    clock = SimulationClock(resolution_ps=1.0)
    clock.advance_by(5.0)
    assert math.isclose(clock.time_ns, 5.0)
    with pytest.raises(ValueError):
        clock.advance_to(1.0)


def test_simulation_clock_resolution_quantisation():
    clock = SimulationClock(resolution_ps=1000.0)  # 1 ns resolution
    clock.advance_to(5.4)
    assert math.isclose(clock.time_ns, 5.0)


def test_event_log_records_and_counts():
    clock = SimulationClock()
    log = EventLog()
    log.record(clock, EventType.ROW_HIT, bank_id=0)
    clock.advance_by(10)
    log.record(clock, EventType.ROW_HIT, bank_id=1)
    log.record(clock, EventType.ROW_MISS, bank_id=2)
    assert len(log) == 3
    assert log.count(EventType.ROW_HIT) == 2
    assert log.count(EventType.ROW_MISS) == 1
    records = log.to_records()
    assert records[0]["event_type"] == "ROW_HIT"
