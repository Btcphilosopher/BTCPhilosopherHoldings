import pytest

from dramcore.array.row_buffer import AccessClassification
from dramcore.bank.bank import BankState, DRAMBank, IllegalBankTransitionError


def test_bank_starts_idle():
    bank = DRAMBank(bank_id=0, rows=1024, columns=256)
    assert bank.state == BankState.IDLE


def test_activate_transitions_to_active():
    bank = DRAMBank(bank_id=0, rows=1024, columns=256)
    cls = bank.activate(row=3, timestamp_ns=0.0)
    assert cls == AccessClassification.ROW_MISS
    assert bank.state == BankState.ACTIVE
    assert bank.row_buffer.active_row == 3


def test_activate_same_row_is_hit_and_does_not_reactivate():
    bank = DRAMBank(bank_id=0, rows=1024, columns=256)
    bank.activate(row=3, timestamp_ns=0.0)
    cls = bank.activate(row=3, timestamp_ns=10.0)
    assert cls == AccessClassification.ROW_HIT
    assert bank.activation_count == 1  # second "activate" call was a no-op hit


def test_activate_different_row_is_conflict_after_precharge():
    """A conflicting ACT is only legal after the open row has been
    explicitly precharged (real DRAM hardware requires PRE before ACT on
    an already-active bank) -- the controller handles this PRE/ACT
    sequencing; here we exercise it directly at the bank level."""
    bank = DRAMBank(bank_id=0, rows=1024, columns=256)
    bank.activate(row=3, timestamp_ns=0.0)
    classification = bank.classify_access(4)
    assert classification == AccessClassification.ROW_CONFLICT
    bank.precharge(timestamp_ns=10.0)
    # Counting must use the classification observed BEFORE the precharge
    # (see DRAMBank.activate's `classification` parameter) since after
    # precharge the row buffer is EMPTY and would misclassify as a MISS.
    cls = bank.activate(row=4, timestamp_ns=20.0, classification=classification)
    assert cls == AccessClassification.ROW_CONFLICT
    assert bank.row_conflicts == 1
    assert bank.row_misses == 1  # the initial activate(row=3) was a miss


def test_activate_without_explicit_classification_after_precharge_undercounts_as_miss():
    """Documents the known caveat: if a caller precharges first and then
    calls activate() WITHOUT passing the original classification, the
    conflict cannot be distinguished from a miss anymore -- this is why
    the memory controller always passes classification explicitly."""
    bank = DRAMBank(bank_id=0, rows=1024, columns=256)
    bank.activate(row=3, timestamp_ns=0.0)
    bank.precharge(timestamp_ns=10.0)
    cls = bank.activate(row=4, timestamp_ns=20.0)  # no classification passed
    assert cls == AccessClassification.ROW_MISS


def test_read_requires_active_state():
    bank = DRAMBank(bank_id=0, rows=1024, columns=256)
    with pytest.raises(IllegalBankTransitionError):
        bank.read(timestamp_ns=0.0)


def test_precharge_requires_active_state():
    bank = DRAMBank(bank_id=0, rows=1024, columns=256)
    with pytest.raises(IllegalBankTransitionError):
        bank.precharge(timestamp_ns=0.0)


def test_full_lifecycle_returns_to_idle():
    bank = DRAMBank(bank_id=0, rows=1024, columns=256)
    bank.activate(row=1, timestamp_ns=0.0)
    bank.read(timestamp_ns=5.0)
    bank.precharge(timestamp_ns=10.0)
    assert bank.state == BankState.IDLE
    assert bank.row_buffer.active_row is None


def test_refresh_requires_precharged_banks_conceptually():
    bank = DRAMBank(bank_id=0, rows=1024, columns=256)
    bank.begin_refresh(timestamp_ns=0.0)
    assert bank.state == BankState.REFRESHING
    bank.end_refresh()
    assert bank.state == BankState.IDLE


def test_activation_count_per_row_tracked():
    bank = DRAMBank(bank_id=0, rows=1024, columns=256)
    bank.activate(row=1, timestamp_ns=0.0)
    bank.precharge(timestamp_ns=10.0)
    bank.activate(row=1, timestamp_ns=20.0)
    assert bank.activation_count_per_row[1] == 2
