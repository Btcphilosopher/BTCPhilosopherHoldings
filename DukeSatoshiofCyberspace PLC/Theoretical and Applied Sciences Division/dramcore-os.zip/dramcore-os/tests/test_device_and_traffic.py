import pytest

from dramcore.device.dram_device import DRAMDevice
from dramcore.channel.topology import MemoryTopology
from dramcore.core.result import InvalidConfigurationError
from dramcore.traffic.generators import (
    TrafficConfig, bursty, mixed, pointer_chase, random_traffic, sequential_read,
    sequential_write, strided,
)


def test_device_rejects_non_power_of_two_rows():
    with pytest.raises(InvalidConfigurationError):
        DRAMDevice(device_id="x", technology_node_nm=10, density_gb=1, data_rate_mt_s=6400,
                   bus_width_bits=8, banks=8, bank_groups=2, rows=1000, columns=1024)


def test_device_rejects_bank_groups_not_dividing_banks():
    with pytest.raises(InvalidConfigurationError):
        DRAMDevice(device_id="x", technology_node_nm=10, density_gb=1, data_rate_mt_s=6400,
                   bus_width_bits=8, banks=10, bank_groups=3, rows=1024, columns=1024)


def test_theoretical_bandwidth_formula():
    dev = DRAMDevice.synthetic_ddr5_like(data_rate_mt_s=6400)
    bw = dev.theoretical_bandwidth_gbps()
    assert bw == pytest.approx(6400 * 8 / 8.0 / 1000.0)


def test_topology_capacity_scales_with_channels():
    dev = DRAMDevice.synthetic_ddr5_like()
    t1 = MemoryTopology(device_template=dev, n_channels=1)
    t2 = MemoryTopology(device_template=dev, n_channels=2)
    assert t2.total_capacity_bytes == 2 * t1.total_capacity_bytes
    assert t2.total_theoretical_bandwidth_gbps() == pytest.approx(2 * t1.total_theoretical_bandwidth_gbps())


def test_topology_ascii_render_contains_channels():
    dev = DRAMDevice.synthetic_ddr5_like()
    t = MemoryTopology(device_template=dev, n_channels=2)
    text = t.render_ascii()
    assert "Channel 0" in text and "Channel 1" in text


def _base_cfg(n=200, space=1 << 30, seed=1):
    return TrafficConfig(n_requests=n, address_space_bytes=space, request_size_bytes=64,
                          mean_inter_arrival_ns=1.0, seed=seed)


def test_sequential_read_is_monotonic_addresses():
    reqs = sequential_read(_base_cfg())
    addrs = [r.address for r in reqs]
    assert addrs == sorted(addrs)
    assert all(r.operation.value == "READ" for r in reqs)


def test_sequential_write_all_writes():
    reqs = sequential_write(_base_cfg())
    assert all(r.operation.value == "WRITE" for r in reqs)


def test_random_traffic_deterministic_with_seed():
    r1 = random_traffic(_base_cfg(seed=5))
    r2 = random_traffic(_base_cfg(seed=5))
    assert [r.address for r in r1] == [r.address for r in r2]


def test_random_traffic_different_seeds_differ():
    r1 = random_traffic(_base_cfg(seed=5))
    r2 = random_traffic(_base_cfg(seed=6))
    assert [r.address for r in r1] != [r.address for r in r2]


def test_strided_addresses_match_stride():
    reqs = strided(_base_cfg(n=10), stride_bytes=256)
    addrs = [r.address for r in reqs]
    assert addrs == [i * 256 for i in range(10)]


def test_strided_rejects_nonpositive_stride():
    with pytest.raises(InvalidConfigurationError):
        strided(_base_cfg(), stride_bytes=0)


def test_pointer_chase_addresses_within_bounds():
    cfg = _base_cfg(n=50, space=1 << 20)
    reqs = pointer_chase(cfg)
    for r in reqs:
        assert 0 <= r.address < cfg.address_space_bytes


def test_bursty_produces_gaps_between_bursts():
    cfg = _base_cfg(n=20)
    reqs = bursty(cfg, burst_size=5, burst_gap_ns=1000.0)
    arrivals = [r.timestamp_ns for r in reqs]
    gaps = [arrivals[i + 1] - arrivals[i] for i in range(len(arrivals) - 1)]
    assert max(gaps) > 500  # the burst-boundary gap should dominate


def test_mixed_combines_sequential_and_random():
    cfg = _base_cfg(n=200)
    reqs = mixed(cfg, sequential_fraction=0.5)
    assert len(reqs) == 200
    # arrival-ordered
    arrivals = [r.timestamp_ns for r in reqs]
    assert arrivals == sorted(arrivals)


def test_write_fraction_respected_approximately():
    cfg = TrafficConfig(n_requests=5000, address_space_bytes=1 << 30, request_size_bytes=64,
                         mean_inter_arrival_ns=1.0, write_fraction=0.4, seed=3)
    reqs = random_traffic(cfg)
    write_frac = sum(1 for r in reqs if r.operation.value == "WRITE") / len(reqs)
    assert abs(write_frac - 0.4) < 0.05
