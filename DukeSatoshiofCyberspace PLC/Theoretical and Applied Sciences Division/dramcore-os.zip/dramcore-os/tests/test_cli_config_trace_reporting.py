import json
import os
import subprocess
import sys
import tempfile

import pytest

from dramcore.configuration.config import (
    EXAMPLE_CONFIG_YAML, controller_config_from_config, device_from_config, load_config,
)
from dramcore.controller.simulation import Simulation
from dramcore.device.dram_device import DRAMDevice
from dramcore.digital_twin.twin import DRAMDigitalTwin
from dramcore.reporting.report import EngineeringReport
from dramcore.traces.trace_io import export_csv, export_json, import_csv, import_json
from dramcore.traffic.generators import TrafficConfig, sequential_read
from dramcore.validation.suite import run_all_validations


def test_example_config_loads_and_builds_device(tmp_path):
    cfg_path = tmp_path / "config.yaml"
    cfg_path.write_text(EXAMPLE_CONFIG_YAML)
    cfg = load_config(str(cfg_path))
    device = device_from_config(cfg)
    assert device.density_gb == 32
    assert device.banks == 16
    ctrl_cfg = controller_config_from_config(cfg)
    assert "scheduler_policy" in ctrl_cfg


def test_trace_csv_roundtrip(tmp_path):
    device = DRAMDevice.synthetic_ddr5_like()
    sim = Simulation(device=device, n_channels=1)
    cfg = TrafficConfig(n_requests=50, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=1)
    reqs = sequential_read(cfg)
    path = str(tmp_path / "trace.csv")
    export_csv(reqs, path)
    reloaded = import_csv(path)
    assert len(reloaded) == len(reqs)
    assert reloaded[0].address == reqs[0].address
    assert reloaded[0].operation == reqs[0].operation


def test_trace_json_roundtrip(tmp_path):
    device = DRAMDevice.synthetic_ddr5_like()
    sim = Simulation(device=device, n_channels=1)
    cfg = TrafficConfig(n_requests=50, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=1, write_fraction=0.5)
    reqs = sequential_read(cfg)
    path = str(tmp_path / "trace.json")
    export_json(reqs, path)
    reloaded = import_json(path)
    assert len(reloaded) == len(reqs)


def test_engineering_report_produces_markdown_and_json():
    device = DRAMDevice.synthetic_ddr5_like()
    sim = Simulation(device=device, n_channels=2)
    cfg = TrafficConfig(n_requests=300, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=1)
    result = sim.run(sequential_read(cfg))

    report = EngineeringReport(title="Test Report", configuration={"n_channels": 2})
    report.add_result("bandwidth", result.bandwidth)
    report.add_result("power", result.power)
    md = report.to_markdown()
    js = report.to_json()
    assert "Test Report" in md
    assert "bandwidth" in md.lower()
    parsed = json.loads(js)
    assert parsed["title"] == "Test Report"
    assert "results" in parsed


def test_digital_twin_snapshot_and_inspect():
    device = DRAMDevice.synthetic_ddr5_like()
    sim = Simulation(device=device, n_channels=1)
    cfg = TrafficConfig(n_requests=200, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=1)
    sim.run(sequential_read(cfg))
    twin = DRAMDigitalTwin(topology=sim.topology, controller=sim.controller)
    snap = twin.snapshot()
    assert "channels" in snap
    info = twin.inspect(channel=0, rank=0, bank=0)
    assert info is not None
    assert info["channel"] == 0
    rendered = twin.render_inspection(0, 0, 0)
    assert "Channel 0" in rendered


def test_validation_suite_passes_as_pytest():
    ok, report = run_all_validations()
    assert ok, report


def test_cli_validate_subcommand_runs():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    result = subprocess.run(
        [sys.executable, "-m", "dramcore.cli", "validate"],
        cwd=root, capture_output=True, text=True, timeout=60,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "OVERALL: PASS" in result.stdout


def test_cli_benchmark_subcommand_runs():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    result = subprocess.run(
        [sys.executable, "-m", "dramcore.cli", "benchmark", "ROW_HIT", "--n-requests", "200"],
        cwd=root, capture_output=True, text=True, timeout=60,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    data = json.loads(result.stdout)
    assert "bandwidth_gbps" in data


def test_cli_thermal_subcommand_runs():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    result = subprocess.run(
        [sys.executable, "-m", "dramcore.cli", "thermal", "--power-w", "2.5", "--ambient", "40"],
        cwd=root, capture_output=True, text=True, timeout=30,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    data = json.loads(result.stdout)
    assert data["value"] > 40
