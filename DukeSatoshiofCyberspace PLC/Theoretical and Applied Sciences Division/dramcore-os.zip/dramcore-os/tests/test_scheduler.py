from dramcore.controller.request import MemoryRequest, RequestOperation
from dramcore.scheduler.scheduler import (
    DeadlineScheduler, FCFSScheduler, FairnessAwareScheduler, FRFCFSScheduler,
    PriorityScheduler, RoundRobinScheduler, SchedulerPolicy, make_scheduler,
)


def _req(rid, arrival, source="s", priority=0, deadline=None, size=64):
    return MemoryRequest(request_id=rid, timestamp_ns=arrival, address=rid * 64,
                          size_bytes=size, operation=RequestOperation.READ,
                          source=source, priority=priority, deadline_ns=deadline)


def test_fcfs_picks_earliest_arrival():
    reqs = [_req(0, 10), _req(1, 5), _req(2, 20)]
    sched = FCFSScheduler()
    chosen = sched.select(reqs, now_ns=20, row_is_open=lambda r: False)
    assert chosen.request_id == 1


def test_frfcfs_prefers_row_hit_over_earlier_arrival():
    reqs = [_req(0, 5), _req(1, 10)]
    sched = FRFCFSScheduler()
    chosen = sched.select(reqs, now_ns=10, row_is_open=lambda r: r.request_id == 1)
    assert chosen.request_id == 1


def test_frfcfs_falls_back_to_fcfs_when_no_hits():
    reqs = [_req(0, 5), _req(1, 10)]
    sched = FRFCFSScheduler()
    chosen = sched.select(reqs, now_ns=10, row_is_open=lambda r: False)
    assert chosen.request_id == 0


def test_deadline_scheduler_picks_earliest_deadline():
    reqs = [_req(0, 0, deadline=100), _req(1, 0, deadline=50)]
    sched = DeadlineScheduler()
    chosen = sched.select(reqs, now_ns=0, row_is_open=lambda r: False)
    assert chosen.request_id == 1


def test_deadline_scheduler_deprioritises_no_deadline():
    reqs = [_req(0, 0, deadline=None), _req(1, 0, deadline=50)]
    sched = DeadlineScheduler()
    chosen = sched.select(reqs, now_ns=0, row_is_open=lambda r: False)
    assert chosen.request_id == 1


def test_priority_scheduler_picks_highest_priority():
    reqs = [_req(0, 0, priority=1), _req(1, 0, priority=5)]
    sched = PriorityScheduler()
    chosen = sched.select(reqs, now_ns=0, row_is_open=lambda r: False)
    assert chosen.request_id == 1


def test_round_robin_rotates_across_sources():
    sched = RoundRobinScheduler()
    reqs = [_req(0, 0, source="A"), _req(1, 0, source="B")]
    first = sched.select(reqs, now_ns=0, row_is_open=lambda r: False)
    reqs2 = [_req(2, 0, source="A"), _req(3, 0, source="B")]
    second = sched.select(reqs2, now_ns=0, row_is_open=lambda r: False)
    assert first.source != second.source


def test_fairness_aware_prioritises_underserved_source():
    sched = FairnessAwareScheduler()
    sched.bytes_served["A"] = 10000
    sched.bytes_served["B"] = 0
    reqs = [_req(0, 0, source="A"), _req(1, 0, source="B")]
    chosen = sched.select(reqs, now_ns=0, row_is_open=lambda r: False)
    assert chosen.source == "B"


def test_make_scheduler_factory_covers_all_policies():
    for policy in SchedulerPolicy:
        sched = make_scheduler(policy)
        assert sched is not None
