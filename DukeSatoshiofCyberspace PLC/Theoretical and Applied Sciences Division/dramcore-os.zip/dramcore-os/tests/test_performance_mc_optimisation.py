import math

import pytest

from dramcore.controller.request import MemoryRequest, RequestOperation
from dramcore.montecarlo.engine import MonteCarloEngine, VariationSpec
from dramcore.optimisation.cost_model import CostModel
from dramcore.optimisation.design_space import (
    DesignSpace, pareto_front, run_design_space, sweep_parameter,
)
from dramcore.performance.ai_analysis import AIMemoryVerdict, analyse_ai_workload
from dramcore.performance.engine import (
    BottleneckType, analyse_bottleneck, compute_bandwidth_gbps, compute_latency_stats,
    detect_saturation, roofline_analysis,
)
from dramcore.traffic.ai_workloads import TransformerWorkloadSpec


def _completed_request(rid, arrival, completion, size=64):
    r = MemoryRequest(request_id=rid, timestamp_ns=arrival, address=rid * 64, size_bytes=size,
                       operation=RequestOperation.READ)
    r.arrival_time_ns = arrival
    r.completion_time_ns = completion
    r.service_start_ns = arrival
    return r


def test_compute_bandwidth_matches_bytes_over_time():
    reqs = [_completed_request(i, i, i + 10) for i in range(10)]
    result = compute_bandwidth_gbps(reqs, elapsed_ns=100.0)
    total_bytes = 10 * 64
    assert result.value == pytest.approx((total_bytes / 1e9) / (100.0 / 1e9))


def test_latency_percentiles_monotonic():
    reqs = [_completed_request(i, 0, i) for i in range(1, 101)]  # latencies 1..100
    result = compute_latency_stats(reqs)
    t = result.value
    assert t["p50"] <= t["p90"] <= t["p95"] <= t["p99"] <= t["max"]
    assert t["min"] == 1


def test_saturation_detection_threshold():
    reqs = [_completed_request(i, 0, 1) for i in range(1)]
    sat = detect_saturation(reqs, achieved_bandwidth_gbps=95.0, theoretical_bandwidth_gbps=100.0,
                             saturation_threshold=0.9)
    assert sat.value is True
    not_sat = detect_saturation(reqs, achieved_bandwidth_gbps=50.0, theoretical_bandwidth_gbps=100.0)
    assert not_sat.value is False


def test_bottleneck_identifies_refresh_when_overhead_high():
    report = analyse_bottleneck(row_hit_rate_value=0.8, refresh_overhead_fraction=0.3,
                                 bandwidth_saturation_ratio=0.2, p99_latency_ns=100,
                                 mean_latency_ns=90)
    assert report.bottleneck == BottleneckType.REFRESH_BOTTLENECK


def test_bottleneck_identifies_row_conflict_when_hit_rate_low():
    report = analyse_bottleneck(row_hit_rate_value=0.05, refresh_overhead_fraction=0.01,
                                 bandwidth_saturation_ratio=0.2, p99_latency_ns=100,
                                 mean_latency_ns=90)
    assert report.bottleneck == BottleneckType.ROW_CONFLICT_BOTTLENECK


def test_bottleneck_none_identified_when_all_healthy():
    report = analyse_bottleneck(row_hit_rate_value=0.9, refresh_overhead_fraction=0.01,
                                 bandwidth_saturation_ratio=0.3, p99_latency_ns=100,
                                 mean_latency_ns=90)
    assert report.bottleneck == BottleneckType.NONE_IDENTIFIED


def test_roofline_memory_bandwidth_bound():
    result = roofline_analysis(compute_rate_flops=1e15, memory_bandwidth_gbps=100,
                                bytes_per_operation=100, achieved_flops=1e12)
    assert result.value == "MEMORY_BANDWIDTH_BOUND"


def test_roofline_compute_bound():
    result = roofline_analysis(compute_rate_flops=1e9, memory_bandwidth_gbps=1000,
                                bytes_per_operation=0.01, achieved_flops=1e8)
    assert result.value == "COMPUTE_BOUND"


def test_transformer_workload_spec_scales_with_layers():
    small = TransformerWorkloadSpec(num_layers=4, hidden_dim=512, num_heads=8, seq_len=1024, batch_size=1)
    large = TransformerWorkloadSpec(num_layers=32, hidden_dim=512, num_heads=8, seq_len=1024, batch_size=1)
    assert large.weight_bytes().value > small.weight_bytes().value


def test_kv_cache_disabled_gives_zero():
    spec = TransformerWorkloadSpec(num_layers=4, hidden_dim=512, num_heads=8, seq_len=1024,
                                    batch_size=1, use_kv_cache=False)
    assert spec.kv_cache_bytes().value == 0


def test_ai_analysis_capacity_limited():
    spec = TransformerWorkloadSpec(num_layers=80, hidden_dim=8192, num_heads=64, seq_len=8192,
                                    batch_size=32)
    result = analyse_ai_workload(spec, target_tokens_per_second=50,
                                  available_capacity_bytes=1_000_000,  # tiny
                                  available_bandwidth_gbps=10000)
    assert result.verdict == AIMemoryVerdict.MEMORY_CAPACITY_LIMITED


def test_ai_analysis_bandwidth_limited():
    spec = TransformerWorkloadSpec(num_layers=32, hidden_dim=4096, num_heads=32, seq_len=2048,
                                    batch_size=8)
    result = analyse_ai_workload(spec, target_tokens_per_second=1000,
                                  available_capacity_bytes=int(1e12),
                                  available_bandwidth_gbps=1.0)  # tiny bandwidth
    assert result.verdict == AIMemoryVerdict.MEMORY_BANDWIDTH_LIMITED


def test_ai_analysis_sufficient():
    spec = TransformerWorkloadSpec(num_layers=4, hidden_dim=512, num_heads=8, seq_len=256, batch_size=1)
    result = analyse_ai_workload(spec, target_tokens_per_second=10,
                                  available_capacity_bytes=int(1e12),
                                  available_bandwidth_gbps=10000)
    assert result.verdict == AIMemoryVerdict.MEMORY_SUFFICIENT


def test_monte_carlo_engine_produces_n_trials():
    mc = MonteCarloEngine(variations=[VariationSpec(name="temp_c", nominal=85.0, sigma_fraction=0.1)])

    def trial(temp_c, trial_seed):
        return {"latency_ns": temp_c * 2.0}

    result = mc.run(trial, n_trials=200, seed=1)
    assert result.n_trials == 200
    assert len(result.outputs["latency_ns"]) == 200


def test_monte_carlo_percentiles_ordering():
    mc = MonteCarloEngine(variations=[VariationSpec(name="x", nominal=1.0, sigma_fraction=0.3)])

    def trial(x, trial_seed):
        return {"y": x}

    result = mc.run(trial, n_trials=1000, seed=2)
    p = result.percentiles("y").value
    assert p["P1"] <= p["P50"] <= p["P99"]


def test_design_space_combinations_cartesian_product():
    space = DesignSpace(parameters={"channels": [1, 2, 4], "banks": [8, 16]})
    combos = space.combinations()
    assert len(combos) == 6
    assert space.size() == 6


def test_run_design_space_calls_eval_fn_for_each_combo():
    space = DesignSpace(parameters={"x": [1, 2], "y": [10, 20]})
    results = run_design_space(space, lambda c: {"sum": c["x"] + c["y"]})
    assert len(results) == 4
    assert {"x": 1, "y": 10, "sum": 11} in results


def test_sweep_parameter_basic():
    results = sweep_parameter("channels", [1, 2, 4], lambda v: {"bw": v * 6.4})
    assert results[2]["bw"] == pytest.approx(4 * 6.4)


def test_pareto_front_excludes_dominated_points():
    results = [
        {"bandwidth": 10, "power": 5},   # dominated by bandwidth=20,power=5
        {"bandwidth": 20, "power": 5},
        {"bandwidth": 15, "power": 3},   # non-dominated tradeoff point
    ]
    front = pareto_front(results, {"bandwidth": "max", "power": "min"})
    assert {"bandwidth": 20, "power": 5} in front
    assert {"bandwidth": 15, "power": 3} in front
    assert {"bandwidth": 10, "power": 5} not in front


def test_cost_model_total_cost_positive_and_scales_with_capacity():
    cm = CostModel()
    small = cm.total_cost_usd(capacity_gb=16, n_channels=2, average_power_w=2.0)
    large = cm.total_cost_usd(capacity_gb=128, n_channels=2, average_power_w=2.0)
    assert large.value > small.value > 0
