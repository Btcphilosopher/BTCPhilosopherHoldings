import pytest

from dramcore.controller.controller import PagePolicy
from dramcore.controller.simulation import Simulation
from dramcore.device.dram_device import DRAMDevice
from dramcore.scheduler.scheduler import SchedulerPolicy
from dramcore.traffic.generators import TrafficConfig, random_traffic, sequential_read


@pytest.fixture
def device():
    return DRAMDevice.synthetic_ddr5_like()


def test_simulation_completes_all_requests(device):
    sim = Simulation(device=device, n_channels=2, queue_depth=64)
    cfg = TrafficConfig(n_requests=1000, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=1)
    reqs = sequential_read(cfg)
    result = sim.run(reqs)
    assert result.n_requests == 1000
    assert all(r.completion_time_ns is not None for r in result.requests)


def test_simulation_bandwidth_positive_and_latency_reasonable(device):
    sim = Simulation(device=device, n_channels=2, queue_depth=128)
    cfg = TrafficConfig(n_requests=2000, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=5.0, seed=1)
    result = sim.run(sequential_read(cfg))
    assert result.bandwidth.value > 0
    assert result.latency.value["mean"] > 0


def test_sequential_gets_higher_row_hit_rate_than_random(device):
    seq_sim = Simulation(device=device, n_channels=1, scheduler_policy=SchedulerPolicy.FR_FCFS)
    rand_sim = Simulation(device=device, n_channels=1, scheduler_policy=SchedulerPolicy.FR_FCFS)
    space = seq_sim.topology.total_capacity_bytes

    seq_cfg = TrafficConfig(n_requests=1000, address_space_bytes=space, request_size_bytes=64,
                             mean_inter_arrival_ns=1.0, seed=1)
    rand_cfg = TrafficConfig(n_requests=1000, address_space_bytes=space, request_size_bytes=64,
                              mean_inter_arrival_ns=1.0, seed=1)

    seq_result = seq_sim.run(sequential_read(seq_cfg))
    rand_result = rand_sim.run(random_traffic(rand_cfg))

    assert seq_result.row_hit_rate.value > rand_result.row_hit_rate.value


def test_close_page_never_leaves_bank_open_between_requests(device):
    sim = Simulation(device=device, n_channels=1, page_policy=PagePolicy.CLOSE_PAGE)
    cfg = TrafficConfig(n_requests=300, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=2.0, seed=1)
    sim.run(sequential_read(cfg))
    for _, _, bank in sim.topology.all_banks():
        assert bank.row_hits == 0  # CLOSE_PAGE means every access reopens the row


def test_fcfs_vs_frfcfs_row_hit_rate_ordering(device):
    space_fn = lambda: DRAMDevice.synthetic_ddr5_like()
    fcfs_sim = Simulation(device=space_fn(), n_channels=1, scheduler_policy=SchedulerPolicy.FCFS)
    frfcfs_sim = Simulation(device=space_fn(), n_channels=1, scheduler_policy=SchedulerPolicy.FR_FCFS)

    cfg1 = TrafficConfig(n_requests=1500, address_space_bytes=fcfs_sim.topology.total_capacity_bytes,
                          request_size_bytes=64, mean_inter_arrival_ns=0.5, write_fraction=0.3, seed=9)
    cfg2 = TrafficConfig(n_requests=1500, address_space_bytes=frfcfs_sim.topology.total_capacity_bytes,
                          request_size_bytes=64, mean_inter_arrival_ns=0.5, write_fraction=0.3, seed=9)

    from dramcore.traffic.generators import mixed
    r1 = fcfs_sim.run(mixed(cfg1, sequential_fraction=0.7))
    r2 = frfcfs_sim.run(mixed(cfg2, sequential_fraction=0.7))
    # FR-FCFS should never do WORSE than FCFS on row-hit rate for the same
    # traffic, since it actively prioritises hits.
    assert r2.row_hit_rate.value >= r1.row_hit_rate.value - 1e-9


def test_refresh_actually_occurs_over_long_run(device):
    sim = Simulation(device=device, n_channels=1)
    cfg = TrafficConfig(n_requests=3000, address_space_bytes=sim.topology.total_capacity_bytes,
                         request_size_bytes=64, mean_inter_arrival_ns=2.0, seed=3)
    sim.run(random_traffic(cfg))
    total_refreshes = sum(sim.controller.refresh_engine.refresh_count.values())
    assert total_refreshes > 0


def test_multi_channel_scales_theoretical_bandwidth(device):
    sims = [Simulation(device=device, n_channels=n) for n in (1, 2, 4)]
    bws = [s.topology.total_theoretical_bandwidth_gbps() for s in sims]
    assert bws[0] < bws[1] < bws[2]
    assert bws[1] == pytest.approx(2 * bws[0])
    assert bws[2] == pytest.approx(4 * bws[0])


def test_deterministic_replay_same_seed(device):
    def one_run():
        sim = Simulation(device=DRAMDevice.synthetic_ddr5_like(), n_channels=2, seed=123)
        cfg = TrafficConfig(n_requests=500, address_space_bytes=sim.topology.total_capacity_bytes,
                             request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=123)
        return sim.run(random_traffic(cfg)).summary()

    assert one_run() == one_run()
