import pytest

from dramcore.ecc.engine import ECCEngine, ECCMode
from dramcore.ecc.scrubbing import ScrubEngine, ScrubPolicy
from dramcore.reliability.engine import ErrorRateConfig, ErrorType, ReliabilityEngine
from dramcore.reliability.row_disturbance import RowDisturbanceModel
from dramcore.core.result import InvalidConfigurationError


def test_error_rate_config_rejects_out_of_range():
    with pytest.raises(InvalidConfigurationError):
        ErrorRateConfig(rates={ErrorType.BIT_FLIP: 1.5})


def test_reliability_engine_zero_bits_zero_errors():
    engine = ReliabilityEngine()
    result = engine.simulate_bit_errors(n_bits=0, error_type=ErrorType.BIT_FLIP, seed=1)
    assert result.value == 0


def test_reliability_engine_deterministic_with_seed():
    engine = ReliabilityEngine()
    r1 = engine.simulate_bit_errors(n_bits=1_000_000, error_type=ErrorType.RETENTION_ERROR, seed=42)
    r2 = engine.simulate_bit_errors(n_bits=1_000_000, error_type=ErrorType.RETENTION_ERROR, seed=42)
    assert r1.value == r2.value


def test_temperature_rate_multiplier_increases_with_temperature():
    engine = ReliabilityEngine()
    low = engine.temperature_rate_multiplier(50.0)
    high = engine.temperature_rate_multiplier(100.0)
    assert high > low


def test_ecc_secded_corrects_single_bit():
    ecc = ECCEngine(mode=ECCMode.SECDED, data_word_bits=64)
    outcome = ecc.classify_and_correct(1)
    assert outcome == "CORRECTABLE"
    assert ecc.correctable_errors == 1


def test_ecc_secded_detects_double_bit_as_uncorrectable():
    ecc = ECCEngine(mode=ECCMode.SECDED, data_word_bits=64)
    outcome = ecc.classify_and_correct(2)
    assert outcome == "DETECTED_UNCORRECTABLE"
    assert ecc.uncorrectable_errors == 1


def test_ecc_no_ecc_never_corrects():
    ecc = ECCEngine(mode=ECCMode.NO_ECC, data_word_bits=64)
    outcome = ecc.classify_and_correct(1)
    assert outcome == "UNDETECTED"
    assert ecc.correctable_errors == 0


def test_ecc_codeword_bits_greater_than_data_bits():
    ecc = ECCEngine(mode=ECCMode.SECDED, data_word_bits=64)
    assert ecc.codeword_bits() > 64


def test_ecc_simulate_stream_outcomes_sum_to_n_codewords():
    ecc = ECCEngine(mode=ECCMode.SECDED, data_word_bits=64)
    result = ecc.simulate_stream(n_codewords=1000, per_bit_error_probability=0.001, seed=5)
    assert sum(result.value.values()) == 1000


def test_configurable_ecc_corrects_up_to_t_errors():
    ecc = ECCEngine(mode=ECCMode.CONFIGURABLE_ECC, data_word_bits=64,
                     configurable_t_errors_correctable=3)
    assert ecc.classify_and_correct(3) == "CORRECTABLE"
    assert ecc.classify_and_correct(7) == "DETECTED_UNCORRECTABLE"
    assert ecc.classify_and_correct(20) == "UNDETECTED"


def test_scrub_full_pass_time_scales_with_capacity():
    small = ScrubEngine(scrub_bandwidth_gbps=1.0, total_capacity_bytes=int(1e9))
    large = ScrubEngine(scrub_bandwidth_gbps=1.0, total_capacity_bytes=int(10e9))
    assert large.full_pass_time_s().value > small.full_pass_time_s().value


def test_scrub_latency_impact_bounded_by_one():
    scrub = ScrubEngine(scrub_bandwidth_gbps=100.0, total_capacity_bytes=1)
    impact = scrub.latency_impact_fraction(total_available_bandwidth_gbps=10.0)
    assert impact.value == 1.0


def test_row_disturbance_probability_zero_below_threshold_activations():
    model = RowDisturbanceModel(activation_threshold=100000)
    p = model.disturbance_probability(
        aggressor_activation_count=0, victim_row_distance=1,
        refresh_interval_ns=1000.0, reference_refresh_interval_ns=1000.0,
    )
    assert p.value == 0.0


def test_row_disturbance_probability_increases_with_activations():
    model = RowDisturbanceModel(activation_threshold=100000)
    low = model.disturbance_probability(50000, 1, 1000.0, 1000.0)
    high = model.disturbance_probability(500000, 1, 1000.0, 1000.0)
    assert high.value > low.value


def test_row_disturbance_decays_with_distance():
    model = RowDisturbanceModel(activation_threshold=100000, victim_distance_decay=0.5)
    near = model.disturbance_probability(200000, 1, 1000.0, 1000.0)
    far = model.disturbance_probability(200000, 3, 1000.0, 1000.0)
    assert far.value < near.value


def test_row_disturbance_shorter_refresh_reduces_probability():
    model = RowDisturbanceModel(activation_threshold=100000)
    slow_refresh = model.disturbance_probability(200000, 1, 2000.0, 1000.0)
    fast_refresh = model.disturbance_probability(200000, 1, 500.0, 1000.0)
    assert fast_refresh.value < slow_refresh.value


def test_row_disturbance_probability_clipped_to_one():
    model = RowDisturbanceModel(activation_threshold=10, base_disturbance_probability=1.0)
    p = model.disturbance_probability(1_000_000, 1, 1.0, 1000.0)
    assert p.value <= 1.0


def test_row_disturbance_sweep_returns_monotonic_trend():
    model = RowDisturbanceModel(activation_threshold=100000)
    sweep = model.sweep_activation_frequency(
        [0, 50000, 100000, 200000], victim_row_distance=1,
        refresh_interval_ns=1000.0, reference_refresh_interval_ns=1000.0,
    )
    values = list(sweep.values())
    assert values == sorted(values)
