import pytest

from dramcore.address_mapping.mapper import AddressMapper, InterleavingPolicy
from dramcore.core.result import InvalidConfigurationError
from dramcore.device.dram_device import DRAMDevice


@pytest.fixture
def device():
    return DRAMDevice.synthetic_ddr5_like()


def test_decode_is_deterministic(device):
    mapper = AddressMapper(device=device, n_channels=2, n_ranks=2,
                            policy=InterleavingPolicy.CACHE_LINE_AWARE)
    a1 = mapper.decode(999999)
    a2 = mapper.decode(999999)
    assert a1 == a2


def test_decode_zero_address_is_all_zero(device):
    mapper = AddressMapper(device=device, n_channels=2, n_ranks=1,
                            policy=InterleavingPolicy.CACHE_LINE_AWARE)
    d = mapper.decode(0)
    assert d.channel == 0 and d.rank == 0 and d.bank == 0 and d.row == 0


def test_channel_bits_requires_power_of_two(device):
    with pytest.raises(InvalidConfigurationError):
        AddressMapper(device=device, n_channels=3, n_ranks=1)


def test_all_interleaving_policies_construct_and_decode(device):
    for policy in InterleavingPolicy:
        mapper = AddressMapper(device=device, n_channels=2, n_ranks=2, policy=policy)
        d = mapper.decode(1234567)
        assert 0 <= d.channel < 2
        assert 0 <= d.rank < 2


def test_cache_line_aware_keeps_row_sticky_for_consecutive_addresses(device):
    """Consecutive addresses within one page should map to the same row --
    that's the entire point of CACHE_LINE_AWARE mapping."""
    mapper = AddressMapper(device=device, n_channels=2, n_ranks=1,
                            policy=InterleavingPolicy.CACHE_LINE_AWARE)
    rows = set()
    for addr in range(0, 512, 64):  # well within one page (2048 bytes)
        rows.add(mapper.decode(addr).row)
    assert len(rows) == 1, f"Expected a single sticky row, got {rows}"


def test_addressable_bytes_matches_field_widths(device):
    mapper = AddressMapper(device=device, n_channels=2, n_ranks=1,
                            policy=InterleavingPolicy.CACHE_LINE_AWARE)
    total_bits = mapper.total_address_bits()
    assert mapper.addressable_bytes() == 2 ** total_bits
