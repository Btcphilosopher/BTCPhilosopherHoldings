import math

import pytest

from dramcore.cell.cell import DRAMCell
from dramcore.cell.retention import RetentionModel
from dramcore.core.result import InvalidConfigurationError


def test_stored_charge_q_equals_cv():
    cell = DRAMCell(capacitance_ff=25.0)
    q = cell.stored_charge_fc(voltage_v=1.1)
    assert math.isclose(q.value, 25.0 * 1.1)


def test_charge_decay_monotonic_decrease():
    cell = DRAMCell()
    q0 = 27.5
    q_early = cell.charge_after_decay(q0, elapsed_ns=1e6, temperature_c=85.0).value
    q_late = cell.charge_after_decay(q0, elapsed_ns=1e8, temperature_c=85.0).value
    assert q_late < q_early < q0


def test_higher_temperature_reduces_retention_time():
    cell = DRAMCell()
    ret_cold = cell.retention_time_ns(temperature_c=20.0).value
    ret_hot = cell.retention_time_ns(temperature_c=95.0).value
    assert ret_hot < ret_cold, "Higher temperature must shorten retention time"


def test_retention_requires_valid_margin():
    cell = DRAMCell()
    with pytest.raises(InvalidConfigurationError):
        cell.retention_time_ns(temperature_c=50, sense_margin_fraction=1.5)


def test_cell_rejects_nonpositive_capacitance():
    with pytest.raises(InvalidConfigurationError):
        DRAMCell(capacitance_ff=0.0)


def test_retention_population_statistics_reasonable():
    cell = DRAMCell()
    model = RetentionModel(cell=cell, process_variation_sigma_fraction=0.2)
    stats = model.summary_statistics(n_cells=5000, temperature_c=85.0, seed=1)
    assert stats["min_ns"] <= stats["median_ns"] <= stats["max_ns"]
    assert stats["min_ns"] > 0


def test_required_refresh_interval_below_weakest_cell():
    cell = DRAMCell()
    model = RetentionModel(cell=cell, process_variation_sigma_fraction=0.25)
    result = model.required_refresh_interval_ns(n_cells=2000, temperature_c=85.0,
                                                 safety_margin_fraction=0.5, seed=2)
    weakest = result.inputs["weakest_cell_retention_ns"]
    assert result.value < weakest


def test_retention_model_deterministic_with_seed():
    cell = DRAMCell()
    model = RetentionModel(cell=cell)
    s1 = model.summary_statistics(1000, 85.0, seed=7)
    s2 = model.summary_statistics(1000, 85.0, seed=7)
    assert s1 == s2
