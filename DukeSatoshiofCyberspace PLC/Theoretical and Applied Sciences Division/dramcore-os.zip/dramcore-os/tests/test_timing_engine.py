import pytest

from dramcore.bank.bank import BankState, DRAMBank
from dramcore.bank.bank_group import BankGroup
from dramcore.commands.command import CommandType, DRAMCommand
from dramcore.core.result import InvalidConfigurationError, TimingViolationError
from dramcore.rank.rank import DRAMRank
from dramcore.device.dram_device import DRAMDevice
from dramcore.timing.engine import TimingEngine
from dramcore.timing.profile import TimingProfile


def test_timing_profile_rejects_negative_values():
    with pytest.raises(InvalidConfigurationError):
        TimingProfile(tCL=-1)


def test_timing_profile_rejects_inconsistent_trc():
    with pytest.raises(InvalidConfigurationError):
        TimingProfile(tRAS=50, tRP=50, tRC=10)  # tRC must be >= tRAS+tRP


def test_synthetic_profiles_construct_cleanly():
    p1 = TimingProfile.synthetic_ddr5_like()
    p2 = TimingProfile.synthetic_lpddr_like()
    assert p1.tCL > 0 and p2.tCL > 0


@pytest.fixture
def rank_setup():
    device = DRAMDevice.synthetic_ddr5_like()
    rank = DRAMRank(rank_id=0, device_template=device)
    bank = rank.banks[0]
    bg = rank.bank_groups[bank.bank_group_id]
    te = TimingEngine(timing=device.timing_profile)
    return te, bank, bg, rank


def test_activate_immediately_legal_from_idle(rank_setup):
    te, bank, bg, rank = rank_setup
    earliest = te.earliest_activate_time(bank, bg, rank)
    assert earliest == 0.0


def test_second_activate_before_trc_is_illegal(rank_setup):
    te, bank, bg, rank = rank_setup
    bank.activate(row=1, timestamp_ns=0.0)
    rank.record_rank_activation(0.0)
    bg.record_activation(0.0)
    bank.precharge(timestamp_ns=te.timing.tRAS)  # legal precharge at tRAS
    cmd = DRAMCommand(command_type=CommandType.ACT, timestamp_ns=te.timing.tRAS + 0.1,
                       channel=0, rank=0, bank=0, row=2)
    with pytest.raises(TimingViolationError):
        te.validate_activate(cmd, bank, bg, rank)


def test_activate_after_trp_is_legal(rank_setup):
    te, bank, bg, rank = rank_setup
    bank.activate(row=1, timestamp_ns=0.0)
    rank.record_rank_activation(0.0)
    bg.record_activation(0.0)
    pre_time = te.timing.tRAS
    bank.precharge(timestamp_ns=pre_time)
    legal_time = pre_time + te.timing.tRP
    cmd = DRAMCommand(command_type=CommandType.ACT, timestamp_ns=legal_time,
                       channel=0, rank=0, bank=0, row=2)
    te.validate_activate(cmd, bank, bg, rank)  # should not raise


def test_read_before_trcd_is_illegal(rank_setup):
    te, bank, bg, rank = rank_setup
    bank.activate(row=1, timestamp_ns=0.0)
    rank.record_rank_activation(0.0)
    bg.record_activation(0.0)
    cmd = DRAMCommand(command_type=CommandType.RD, timestamp_ns=0.1,
                       channel=0, rank=0, bank=0, row=1)
    with pytest.raises(TimingViolationError):
        te.validate_column_access(cmd, bank, bg)


def test_read_after_trcd_is_legal(rank_setup):
    te, bank, bg, rank = rank_setup
    bank.activate(row=1, timestamp_ns=0.0)
    rank.record_rank_activation(0.0)
    bg.record_activation(0.0)
    cmd = DRAMCommand(command_type=CommandType.RD, timestamp_ns=te.timing.tRCD,
                       channel=0, rank=0, bank=0, row=1)
    te.validate_column_access(cmd, bank, bg)  # should not raise


def test_precharge_before_tras_is_illegal(rank_setup):
    te, bank, bg, rank = rank_setup
    bank.activate(row=1, timestamp_ns=0.0)
    cmd = DRAMCommand(command_type=CommandType.PRE, timestamp_ns=1.0, channel=0, rank=0, bank=0)
    with pytest.raises(TimingViolationError):
        te.validate_precharge(cmd, bank)


def test_precharge_wrong_bank_state_is_illegal(rank_setup):
    te, bank, bg, rank = rank_setup
    cmd = DRAMCommand(command_type=CommandType.PRE, timestamp_ns=100.0, channel=0, rank=0, bank=0)
    with pytest.raises(TimingViolationError):
        te.validate_precharge(cmd, bank)  # bank is IDLE, never activated


def test_faw_blocks_fifth_activation_within_window():
    device = DRAMDevice.synthetic_ddr5_like()
    rank = DRAMRank(rank_id=0, device_template=device)
    te = TimingEngine(timing=device.timing_profile)
    t = 0.0
    # Fire 4 activations spaced exactly at the minimum RRD interval, across
    # 4 different bank groups to avoid tripping RRD_L/RRD_S first.
    banks_used = []
    for i in range(4):
        bank = rank.banks[i * device.banks_per_group]  # first bank of each group
        bg = rank.bank_groups[bank.bank_group_id]
        bank.activate(row=1, timestamp_ns=t)
        rank.record_rank_activation(t)
        bg.record_activation(t)
        banks_used.append(bank)
        t += te.timing.tRRD_S

    fifth_bank = rank.banks[4 * device.banks_per_group % device.banks]
    fifth_bg = rank.bank_groups[fifth_bank.bank_group_id]
    earliest = te.earliest_activate_time(fifth_bank, fifth_bg, rank)
    fourth_most_recent_act = sorted(rank.activation_history_ns)[-4]
    assert earliest >= fourth_most_recent_act + te.timing.tFAW
