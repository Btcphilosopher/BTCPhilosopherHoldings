import math

import pytest

from dramcore.core.clock import EventLog, SimulationClock
from dramcore.device.dram_device import DRAMDevice
from dramcore.power.engine import PowerEngine
from dramcore.rank.rank import DRAMRank
from dramcore.refresh.engine import RefreshEngine
from dramcore.refresh.profile import RefreshProfile
from dramcore.thermal.engine import ThermalModel, ThermalPolicy, ThermalState
from dramcore.thermal.coupling import (
    bandwidth_cap_fraction, evaluate_causal_chain, refresh_profile_for_thermal_state,
)
from dramcore.cell.cell import DRAMCell
from dramcore.timing.engine import TimingEngine


def test_refresh_engine_blocks_and_advances_next_due_time():
    device = DRAMDevice.synthetic_ddr5_like()
    te = TimingEngine(timing=device.timing_profile)
    profile = RefreshProfile(refresh_interval_ns=100.0, refresh_duration_ns=20.0)
    re = RefreshEngine(profile=profile, timing_engine=te)
    rank = DRAMRank(rank_id=0, device_template=device)
    re.register_rank(0, start_time_ns=0.0)

    assert not re.is_due(0, now_ns=50.0)
    assert re.is_due(0, now_ns=150.0)

    clock = SimulationClock()
    log = EventLog()
    completion = re.issue_refresh(rank, now_ns=150.0, clock=clock, log=log)
    assert math.isclose(completion, 150.0 + 20.0)
    assert re.refresh_count[0] == 1
    assert re.total_blocked_ns[0] == 20.0
    assert re.next_refresh_due_ns[0] == 150.0 + 100.0


def test_refresh_overhead_fraction_reasonable():
    device = DRAMDevice.synthetic_ddr5_like()
    te = TimingEngine(timing=device.timing_profile)
    profile = RefreshProfile(refresh_interval_ns=1000.0, refresh_duration_ns=100.0)
    re = RefreshEngine(profile=profile, timing_engine=te)
    rank = DRAMRank(rank_id=0, device_template=device)
    re.register_rank(0)
    clock = SimulationClock()
    log = EventLog()
    re.issue_refresh(rank, now_ns=1000.0, clock=clock, log=log)
    overhead = re.refresh_overhead(0, total_elapsed_ns=10000.0)
    assert math.isclose(overhead.value, 100.0 / 10000.0)


def test_power_engine_zero_activity_only_standby():
    device = DRAMDevice.synthetic_ddr5_like()
    engine = PowerEngine(power_profile=device.power_profile, timing_profile=device.timing_profile)
    result = engine.compute(n_activations=0, n_reads=0, n_writes=0, n_refreshes=0,
                             total_elapsed_ns=1e6, total_bytes_transferred=0,
                             achieved_bandwidth_gbps=0.0)
    assert result.value > 0  # standby/PHY/controller static power still present


def test_power_scales_with_activity():
    device = DRAMDevice.synthetic_ddr5_like()
    engine = PowerEngine(power_profile=device.power_profile, timing_profile=device.timing_profile)
    low = engine.compute(n_activations=10, n_reads=10, n_writes=5, n_refreshes=1,
                          total_elapsed_ns=1e5, total_bytes_transferred=1000,
                          achieved_bandwidth_gbps=1.0)
    high = engine.compute(n_activations=1000, n_reads=1000, n_writes=500, n_refreshes=10,
                           total_elapsed_ns=1e5, total_bytes_transferred=100000,
                           achieved_bandwidth_gbps=10.0)
    assert high.value > low.value


def test_thermal_steady_state_formula():
    model = ThermalModel(thermal_resistance_c_per_w=10.0, ambient_temperature_c=30.0)
    result = model.steady_state_temperature_c(power_w=2.0)
    assert math.isclose(result.value, 30.0 + 2.0 * 10.0)


def test_thermal_step_converges_toward_steady_state():
    model = ThermalModel(thermal_resistance_c_per_w=5.0, thermal_mass_j_per_c=0.01,
                          ambient_temperature_c=30.0)
    for _ in range(20000):
        model.step(power_w=1.0, dt_s=1e-5)
    expected_ss = 30.0 + 1.0 * 5.0
    assert abs(model.current_temperature_c - expected_ss) < 1.0


def test_thermal_policy_classification():
    policy = ThermalPolicy(warning_temp_c=70, throttle_temp_c=85, critical_temp_c=95)
    assert policy.classify(50) == ThermalState.NORMAL
    assert policy.classify(75) == ThermalState.WARNING
    assert policy.classify(90) == ThermalState.THROTTLED
    assert policy.classify(99) == ThermalState.CRITICAL


def test_refresh_multiplier_increases_with_thermal_state():
    base = RefreshProfile(refresh_interval_ns=1000.0, refresh_duration_ns=100.0)
    normal = refresh_profile_for_thermal_state(base, ThermalState.NORMAL)
    hot = refresh_profile_for_thermal_state(base, ThermalState.THROTTLED)
    assert hot.effective_interval_ns() < normal.effective_interval_ns()


def test_bandwidth_cap_decreases_under_throttling():
    assert bandwidth_cap_fraction(ThermalState.NORMAL) == 1.0
    assert bandwidth_cap_fraction(ThermalState.CRITICAL) < bandwidth_cap_fraction(ThermalState.THROTTLED)


def test_causal_chain_power_temp_retention_refresh():
    cell = DRAMCell()
    summary_cold = evaluate_causal_chain(cell, temperature_c=30.0, thermal_state=ThermalState.NORMAL)
    summary_hot = evaluate_causal_chain(cell, temperature_c=95.0, thermal_state=ThermalState.THROTTLED)
    assert summary_hot.retention_time_ns < summary_cold.retention_time_ns
    assert summary_hot.required_refresh_interval_ns < summary_cold.required_refresh_interval_ns
