Reserved for saved Experiment objects / experiment manager output (spec section 82, 102).
