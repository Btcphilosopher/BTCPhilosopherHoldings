# Changelog

## 0.1.0 — initial build

Two genuine correctness bugs were found and fixed during this build via
actual test execution against the running simulator (not just code
inspection), and both are now covered by permanent regression tests /
validation checks:

1. **Row-hit counters never incremented.** `MemoryController.service()`
   only called `DRAMBank.activate()` on a MISS/CONFLICT (an actual ACT
   command), so the row-hit counter — which lived inside `activate()` —
   never incremented on the (much more common) HIT path. Sequential
   traffic was reporting a 0% row-hit rate. Fixed by splitting counting
   (`DRAMBank.record_access()`) from the state-transition logic
   (`DRAMBank.activate()`), and having the controller record hits
   explicitly. Covered by `tests/test_bank.py` and
   `check_row_classification_consistency` in the validation suite.

2. **Row conflicts silently miscounted as misses.** The controller
   correctly precharges a conflicting row before issuing the new ACT —
   but `DRAMBank.activate()` was re-deriving the hit/miss/conflict
   classification from *current* state at the moment it ran, which by
   then was already `EMPTY` (post-precharge), so every real conflict was
   being recorded as a miss. Fixed by having `activate()` accept an
   optional `classification` parameter so the controller can pass the
   classification it observed *before* precharging. Covered by
   `tests/test_bank.py::test_activate_different_row_is_conflict_after_precharge`
   and the accompanying
   `test_activate_without_explicit_classification_after_precharge_undercounts_as_miss`
   test that documents the caveat for direct/standalone callers.

3. **Data-bus transfer time computed from a stale default, not the
   request's actual size.** `transfer_time_ns` was derived from
   `req.burst_length` (a device-level default of 16) regardless of the
   request's real `size_bytes`. For any traffic generator using a
   request size larger than the implied `burst_length * bus_width/8`
   bytes-per-burst, this under-reserved the data bus, letting
   *achieved* bandwidth exceed the channel's *theoretical peak* —
   caught while building the AI-workload demonstration, where 256-byte
   requests showed 38 GB/s achieved against a 12.8 GB/s theoretical
   ceiling. Fixed by deriving transfer time directly from
   `req.size_bytes / channel_bytes_per_ns`. Added a permanent
   regression check,
   `check_achieved_bandwidth_never_exceeds_theoretical_peak`, to the
   validation suite (`dramcore validate`) so this class of bug can't
   silently return.

4. **Row-disturbance refresh-interval direction was inverted.** The
   research disturbance model's docstring claimed "shorter refresh
   interval reduces disturbance probability" but the formula divided by
   `refresh_interval_ns`, which *increases* probability as the interval
   shortens — the opposite of the intended (and physically expected)
   direction. Fixed the formula to be directly proportional to
   `refresh_interval_ns`. Covered by
   `tests/test_reliability_ecc.py::test_row_disturbance_shorter_refresh_reduces_probability`.
