Reserved for generated engineering reports (spec section 102).
