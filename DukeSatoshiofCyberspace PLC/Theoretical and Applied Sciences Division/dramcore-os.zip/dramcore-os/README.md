# DRAMCORE.OS

**Python Engineering Laboratory for Dynamic Random-Access Memory**

DRAMCORE.OS is a Python-native computational laboratory for modelling,
simulating, analysing, testing, and optimising DRAM memory systems. It
models DRAM as a physical and architectural system end to end:

```
MEMORY CELL -> BITLINE -> SENSE AMPLIFIER -> ROW -> BANK -> BANK GROUP ->
RANK -> CHANNEL -> MEMORY CONTROLLER -> CPU / GPU / AI ACCELERATOR
```

It connects physical memory behaviour, electrical abstractions, timing,
row activation, refresh, power, thermal, controller scheduling, memory
traffic, reliability, performance, and cost into one executable
engineering model — not a dashboard that assumes bandwidth and latency
numbers, but the machine that derives them.

## Design philosophy

Every model in this codebase exposes **inputs, equation, parameters,
units, assumptions, outputs, validity range, model fidelity, and
uncertainty** through a single common type, `EngineeringResult`
(`dramcore/core/result.py`). No function anywhere returns a bare number
like `latency = 80` without the equation and assumptions that produced
it. The **timing engine is authoritative**: nothing in the scheduler,
controller, or ML layer is permitted to issue a command it has rejected.

Illustrative synthetic configurations (`DRAMDevice.synthetic_ddr5_like()`,
the example YAML config, default timing/power profiles) are explicitly
labelled as such — they represent plausible *magnitudes and structure*
for a DDR5-class or LPDDR-class part, not a claim about any specific
commercial product. Cell/retention/sense-amp models are FIDELITY_1
architectural approximations (Q=CV, exponential decay, charge-sharing
formula) — explicitly **not** SPICE/TCAD-level semiconductor physics.

## Installation

```bash
pip install -r requirements.txt
pip install -e .          # installs the `dramcore` CLI entry point
```

Requires Python 3.10+ (developed and tested on 3.12). Core dependencies:
NumPy, SciPy, Pandas, Pydantic, Matplotlib, PyYAML. Optional extras:
`pyarrow` (Parquet trace I/O), `scikit-learn`/`numba` (future ML/accel
work) — the engine runs fully without them.

## Quick start

### Python API

```python
from dramcore.device.dram_device import DRAMDevice
from dramcore.controller.simulation import Simulation
from dramcore.scheduler.scheduler import SchedulerPolicy
from dramcore.traffic.generators import TrafficConfig, sequential_read

device = DRAMDevice.synthetic_ddr5_like(density_gb=8.0, data_rate_mt_s=6400)
sim = Simulation(device=device, n_channels=2, scheduler_policy=SchedulerPolicy.FR_FCFS)

cfg = TrafficConfig(n_requests=5000, address_space_bytes=sim.topology.total_capacity_bytes,
                     request_size_bytes=64, mean_inter_arrival_ns=1.0, seed=42)
result = sim.run(sequential_read(cfg))

print(result.bandwidth)     # EngineeringResult: value, unit, equation, assumptions...
print(result.latency.value) # {'mean': ..., 'p50': ..., 'p99': ..., ...}
print(result.power)
print(result.row_hit_rate)
print(result.bottleneck)    # BottleneckReport: dominant bottleneck + suggested design change
```

### CLI

```bash
dramcore simulate configs/example_config.yaml --n-requests 5000
dramcore benchmark ROW_HIT --n-requests 2000
dramcore validate
dramcore thermal --power-w 2.5 --ambient 40
```

(`python -m dramcore.cli ...` works identically if the console-script
entry point isn't installed.)

## What's implemented

| Layer | Module(s) | Notes |
|---|---|---|
| Engineering result type | `core/result.py`, `core/units.py` | Every output is unit-bearing, equation-disclosing, fidelity-tagged |
| Deterministic clock / event log | `core/clock.py` | Tick-quantised; full structured event stream |
| Cell / retention | `cell/cell.py`, `cell/retention.py` | Q=CV, Arrhenius-scaled exponential decay, statistical cell populations |
| Sense amp / bitline | `array/sense_amp.py` | Charge-sharing formula, lifecycle state |
| Row buffer / bank / bank group / rank / channel | `array/`, `bank/`, `rank/`, `channel/` | Explicit state machines, hit/miss/conflict classification |
| Address mapping | `address_mapping/mapper.py` | 6 interleaving policies via configurable bit-field ordering |
| Commands / timing engine | `commands/`, `timing/` | **Authoritative** legality enforcement: tCL/tRCD/tRP/tRAS/tRC/tRRD_S/tRRD_L/tFAW/tWTR/tCCD/tRFC |
| Memory controller | `controller/controller.py` | Full REQUEST→DECODE→ACT→WAIT→RD/WR→TRANSFER→PRE→COMPLETE state machine, per-channel command/data-bus contention |
| Schedulers | `scheduler/scheduler.py` | FCFS, FR-FCFS, Deadline, Priority, Round-Robin, Fairness-Aware |
| Refresh | `refresh/` | All-bank refresh, tRFC-gated, measured overhead |
| Power | `power/` | JEDEC IDD-style per-operation energy accounting |
| Thermal | `thermal/` | RC lumped-node integration, throttling policy, power→temp→retention→refresh coupling |
| Reliability / ECC | `reliability/`, `ecc/` | Configurable error injection, row-disturbance research model, SECDED via real Hamming-distance theory, scrubbing |
| Traffic generators | `traffic/generators.py`, `traffic/ai_workloads.py` | Sequential/random/strided/pointer-chase/bursty/mixed + transformer decode/KV-cache AI workload model |
| Performance / bottleneck analysis | `performance/` | Bandwidth, latency percentiles, saturation detection, rule-based bottleneck classifier, roofline, AI memory verdict |
| Monte Carlo | `montecarlo/engine.py` | Parameter-variation sampling, percentile output distributions |
| Design-space / optimisation | `optimisation/` | Cartesian sweeps, Pareto front, differential-evolution wrapper, cost model |
| Calibration | `calibration/interface.py` | Simulated-vs-measured error metrics (MAE/RMSE/relative error) |
| Traces | `traces/trace_io.py` | CSV/JSON (stdlib) + Parquet (pyarrow) import/export, deterministic-replay check |
| Digital twin | `digital_twin/twin.py` | Live-state-derived snapshot and per-bank inspector |
| Visualisation | `visualisation/plots.py` | Matplotlib engineering plots + heat maps |
| Reporting | `reporting/report.py` | Markdown/JSON reports disclosing fidelity + provenance per result |
| Benchmarks | `benchmarks/suite.py` | 12 standard synthetic benchmarks |
| Validation | `validation/suite.py` | 9 end-to-end invariant/property checks, run via `dramcore validate` |
| Configuration | `configuration/config.py` | YAML/JSON device + controller config loading |
| CLI | `cli.py` | `simulate`, `benchmark`, `validate`, `thermal` |

### Deliberately out of scope for this build

The PySide6 desktop UI (spec §88) and LBM.OS runtime integration (spec
§78–79) are architecturally anticipated (the engine/UI separation is
already clean — the simulation engine has no UI dependency, and every
capability §79 asks DRAMCORE to expose — capacity, bandwidth, latency,
power, temperature, timing, topology — is already a first-class query on
`Simulation`/`MemoryTopology`) but weren't built out as standalone
deliverables in this session. A full JAX/CuPy GPU-accelerated backend and
ML-based surrogate/scheduler layer (§54–56) were likewise left as future
extensions rather than built shallow.

## Demonstrations

Five runnable demonstrations live in `examples/`, corresponding to spec
sections 104–108:

```bash
cd examples
python3 demo1_first_demonstration.py   # full stack: 2ch/2rank/FR-FCFS/AI workload
python3 demo2_scheduler_comparison.py  # FCFS vs FR-FCFS vs DEADLINE, identical traffic
python3 demo3_thermal_sweep.py         # 20/40/60/80C: retention/refresh/power chain
python3 demo4_channel_scaling.py       # 1/2/4/8 channels, scaling efficiency
python3 demo5_ai_workload_analysis.py  # capacity- vs bandwidth- vs sufficient- AI verdicts
```

Each prints a results table and writes a JSON/Markdown artifact. Note on
scale: spec §104 mentions "100 million memory requests or a smaller
configurable amount for development" — this is a timing-accurate,
per-command Python discrete-event simulator, so demonstrations run at a
development-appropriate request count (hundreds to low thousands) rather
than the literal upper bound; nothing in the architecture caps the count
itself, only wall-clock time does. Demo 1 & 5 additionally show the
pattern used throughout for AI workloads: **capacity/bandwidth demand
figures come from closed-form formulas** (spec §77's analytic
requirement) while **DRAM timing/scheduling behaviour is exercised via a
separate, tractably-sized representative trace** — replaying every byte
of a realistic multi-GB/step LLM workload through a per-command
simulator is not what a per-command timing simulator is for.

## Testing & validation

```bash
pytest tests/ -v          # 135 unit/integration tests
dramcore validate         # 9 end-to-end invariant checks (determinism,
                           # conservation, timing legality, bandwidth <=
                           # theoretical peak, monotonic channel scaling, ...)
```

Both are green as of this build. Two genuine bugs were found and fixed
*during* this build via testing (not just inspection) — documented in
`CHANGELOG.md` — including a data-bus-timing bug that let achieved
bandwidth exceed the theoretical channel peak, now covered by a
permanent regression check.

## Project layout

```
dramcore-os/
  dramcore/
    core/            address_mapping/   commands/        timing/
    device/          cell/              array/           bank/
    rank/            channel/           controller/      scheduler/
    refresh/         power/             thermal/         reliability/
    ecc/             traffic/           performance/     montecarlo/
    optimisation/    digital_twin/      visualisation/   reporting/
    calibration/     traces/            benchmarks/      validation/
    configuration/   cli.py
  tests/             135 pytest tests across every module above
  examples/          5 runnable demonstrations (spec 104-108)
  configs/           example_config.yaml
  requirements.txt   pyproject.toml     README.md         CHANGELOG.md
```

## A note on scope and honesty

The original spec (114 sections) describes a build large enough for a
multi-quarter engineering team. This delivers a genuinely working,
tested core across the full causal chain — cell physics through
controller scheduling through power/thermal/reliability through
performance analysis and design-space optimisation — with real timing
legality enforcement, not a shell that prints plausible-looking numbers.
Sections given lighter treatment (GUI, ML surrogate training, GPU
backends, full LBM.OS runtime wiring) are noted above rather than
silently dropped.
