Reserved for imported/exported memory traces (spec section 102, 57-58). See dramcore/traces/trace_io.py.
