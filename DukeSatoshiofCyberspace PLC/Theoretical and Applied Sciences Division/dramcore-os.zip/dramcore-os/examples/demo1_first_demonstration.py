"""
Demonstration 1 (spec section 104): the first serious end-to-end
demonstration of DRAMCORE.OS.

    DRAM DEVICE -> 2 CHANNELS -> 2 RANKS -> BANK GROUPS -> BANKS ->
    MEMORY CONTROLLER -> FR-FCFS -> SYNTHETIC AI MEMORY WORKLOAD

The spec calls for "100 million memory requests or a smaller configurable
amount for development" -- this script defaults to a development-scale
count (set via --n-requests) since a literal 100M-request run through a
timing-accurate, per-command Python simulator is not tractable in a
single interactive session; the architecture places no ceiling on the
count itself.
"""
from __future__ import annotations

import argparse
import json
import time

from dramcore.controller.controller import PagePolicy
from dramcore.controller.simulation import Simulation
from dramcore.device.dram_device import DRAMDevice
from dramcore.performance.ai_analysis import analyse_ai_workload
from dramcore.reporting.report import EngineeringReport
from dramcore.scheduler.scheduler import SchedulerPolicy
from dramcore.traffic.ai_workloads import TransformerWorkloadSpec, generate_transformer_decode_trace


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-steps", type=int, default=20,
                         help="Number of synthetic decode steps to simulate at trace scale")
    args = parser.parse_args()

    print("=" * 70)
    print("DEMONSTRATION 1: DRAM Device -> 2 Channels -> 2 Ranks -> Bank")
    print("Groups -> Banks -> Memory Controller -> FR-FCFS -> AI Workload")
    print("=" * 70)

    device = DRAMDevice.synthetic_ddr5_like(density_gb=8.0, data_rate_mt_s=6400)
    sim = Simulation(
        device=device, n_channels=2, n_ranks_per_channel=2,
        scheduler_policy=SchedulerPolicy.FR_FCFS, page_policy=PagePolicy.OPEN_PAGE,
        queue_depth=256, seed=42,
    )
    print("\nTopology:")
    print(sim.topology.render_ascii())
    print(json.dumps(sim.topology.summary(), indent=2))

    # The TARGET workload we want an AI memory-demand verdict for: a
    # realistically-sized model. Its capacity/bandwidth requirements are
    # computed analytically (formula-based -- spec section 77) and do NOT
    # require replaying every individual byte through the per-command
    # simulator.
    target_spec = TransformerWorkloadSpec(
        num_layers=32, hidden_dim=4096, num_heads=32, seq_len=4096, batch_size=4,
        dtype_bytes=2, mode="inference_decode",
    )
    print("\nTarget AI workload characterisation (analytic, spec section 77):")
    print(f"  Weight bytes:    {target_spec.weight_bytes().value / 1e9:.2f} GB")
    print(f"  KV cache bytes:  {target_spec.kv_cache_bytes().value / 1e9:.2f} GB")
    print(f"  Bytes/step:      {target_spec.bytes_per_decode_step().value / 1e6:.2f} MB")

    # A much smaller companion spec is used purely to generate a
    # TRACTABLE, representatively-shaped command-level traffic trace to
    # actually drive the timing-accurate DRAM simulator (a literal
    # per-command replay of a 22 GB/step trace is not tractable for a
    # Python discrete-event simulator in an interactive session -- the
    # traffic-shape and timing/scheduling behaviour it exercises is the
    # same regardless of absolute model size).
    trace_spec = TransformerWorkloadSpec(
        num_layers=4, hidden_dim=512, num_heads=8, seq_len=512, batch_size=1,
        dtype_bytes=2, mode="inference_decode",
    )
    reqs = generate_transformer_decode_trace(
        trace_spec, n_steps=args.n_steps, address_space_bytes=sim.topology.total_capacity_bytes,
        step_period_ns=200.0, seed=42, request_size_bytes=256,
    )
    print(f"\nGenerated {len(reqs)} synthetic memory requests across {args.n_steps} "
          f"decode steps (tractable trace-scale model; see note above).")

    t0 = time.time()
    result = sim.run(reqs)
    wallclock = time.time() - t0

    print(f"\nSimulation wall-clock time: {wallclock:.2f}s")
    print("\nResults:")
    print(f"  Total simulated time:  {result.elapsed_ns:.1f} ns")
    print(f"  Achieved bandwidth:    {result.bandwidth.value:.2f} GB/s "
          f"(theoretical peak: {sim.topology.total_theoretical_bandwidth_gbps():.1f} GB/s)")
    lat = result.latency.value
    print(f"  Mean latency:          {lat.get('mean', 0):.1f} ns")
    print(f"  p99 latency:           {lat.get('p99', 0):.1f} ns")
    print(f"  Row-hit rate:          {result.row_hit_rate.value:.3f}")
    print(f"  Refresh overhead:      {result.refresh_overhead}")
    print(f"  Power (avg):           {result.power.value:.1f} mW")
    print(f"  Bottleneck:            {result.bottleneck.bottleneck.value}")

    ai_result = analyse_ai_workload(
        target_spec, target_tokens_per_second=500,
        available_capacity_bytes=sim.topology.total_capacity_bytes,
        available_bandwidth_gbps=sim.topology.total_theoretical_bandwidth_gbps(),
        achieved_p99_latency_ns=lat.get("p99", 0.0), latency_budget_ns=50000.0,
    )
    print(f"\nAI memory verdict: {ai_result.verdict.value}")
    print(f"  Required BW: {ai_result.required_bandwidth_gbps:.2f} GB/s | "
          f"Available BW: {ai_result.available_bandwidth_gbps:.2f} GB/s")

    report = EngineeringReport(
        title="Demonstration 1: Full-Stack AI Workload Simulation",
        configuration=sim.topology.summary(),
        workload_description=f"Synthetic transformer decode workload, {args.n_steps} steps",
    )
    report.add_result("bandwidth", result.bandwidth)
    report.add_result("latency", result.latency)
    report.add_result("power", result.power)
    report.add_result("row_hit_rate", result.row_hit_rate)
    report.limitations = [
        "Development-scale request count, not the literal 100M requests "
        "mentioned in the spec as an upper bound -- architecture imposes "
        "no ceiling, only wall-clock time does.",
        "AI workload trace is synthetic (derived from declared model "
        "architecture), not captured from a real framework.",
    ]
    report.to_markdown("demo1_report.md")
    report.to_json("demo1_report.json")
    print("\nReport written to demo1_report.md / demo1_report.json")


if __name__ == "__main__":
    main()
