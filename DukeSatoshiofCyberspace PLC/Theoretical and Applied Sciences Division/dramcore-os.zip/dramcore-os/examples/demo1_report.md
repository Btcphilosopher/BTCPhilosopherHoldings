# Demonstration 1: Full-Stack AI Workload Simulation

_Generated: 2026-09-15T18:06:36.695951+00:00_

## Workload

Synthetic transformer decode workload, 20 steps

## Configuration

| Parameter | Value |
|---|---|
| n_channels | 2 |
| n_ranks_per_channel | 2 |
| devices_per_rank | 1 |
| banks_per_device | 32 |
| bank_groups_per_device | 8 |
| total_capacity_gb | 32.0 |
| total_theoretical_bandwidth_gbps | 12.8 |

## Results

### bandwidth

- **Value**: 10.053634153379747 GB/s
- **Equation**: `achieved_BW = total_bytes_transferred / elapsed_time`
- **Fidelity**: FIDELITY_2_DETAILED_TIMING_PERFORMANCE
- **Provenance**: SIMULATED
- **Assumptions**:
  - Elapsed time is the completion time of the last request minus the arrival time of the first -- reflects sustained achieved bandwidth over the measured window, not an instantaneous rate.

### latency

- **Value**: {'mean': 6287.2394425675675, 'median': 5691.53125, 'p50': 5691.53125, 'p90': 12919.875, 'p95': 13978.00625, 'p99': 14804.2875, 'p99.9': 15062.9375, 'max': 15062.9375, 'min': 94.0} ns
- **Equation**: `latency = completion_time - arrival_time, aggregated by percentile`
- **Fidelity**: FIDELITY_2_DETAILED_TIMING_PERFORMANCE
- **Provenance**: SIMULATED

### power

- **Value**: 229.8539267033073 mW
- **Equation**: `P_avg = sum(E_component) / total_elapsed_time`
- **Fidelity**: FIDELITY_2_DETAILED_TIMING_PERFORMANCE
- **Provenance**: SIMULATED
- **Assumptions**:
  - IDD-spec currents applied as per-operation energy coefficients (current x voltage x nominal timing interval) rather than a full cycle-by-cycle current trace -- standard architectural DRAM power-modelling approximation, not datasheet-calibrated unless CALIBRATED provenance is attached.
  - Standby duty cycle applied as a flat multiplier on precharge-standby current for the whole simulated window.

### row_hit_rate

- **Value**: 0.8432432432432433 fraction
- **Equation**: `row_hit_rate = row_hits / (row_hits + row_misses + row_conflicts)`
- **Fidelity**: FIDELITY_2_DETAILED_TIMING_PERFORMANCE
- **Provenance**: SIMULATED

## Limitations

- Development-scale request count, not the literal 100M requests mentioned in the spec as an upper bound -- architecture imposes no ceiling, only wall-clock time does.
- AI workload trace is synthetic (derived from declared model architecture), not captured from a real framework.
