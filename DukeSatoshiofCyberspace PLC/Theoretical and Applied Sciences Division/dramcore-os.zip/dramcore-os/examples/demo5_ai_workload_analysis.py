"""
Demonstration 5 (spec section 108): run an AI workload and answer, from
the simulator's own computed quantities:

    How much DRAM bandwidth does this workload require?
    How much DRAM bandwidth is available?
    Where does the bottleneck occur?
    Is the workload capacity-, bandwidth-, or latency-bound?
"""
from __future__ import annotations

import json

from dramcore.controller.simulation import Simulation
from dramcore.device.dram_device import DRAMDevice
from dramcore.performance.ai_analysis import analyse_ai_workload
from dramcore.scheduler.scheduler import SchedulerPolicy
from dramcore.traffic.ai_workloads import TransformerWorkloadSpec, generate_transformer_decode_trace


def analyse_one(name: str, target_spec: TransformerWorkloadSpec, trace_spec: TransformerWorkloadSpec,
                 device: DRAMDevice, n_channels: int, target_tokens_per_second: float):
    sim = Simulation(device=device, n_channels=n_channels, scheduler_policy=SchedulerPolicy.FR_FCFS,
                      queue_depth=256, seed=1)
    reqs = generate_transformer_decode_trace(
        trace_spec, n_steps=15, address_space_bytes=sim.topology.total_capacity_bytes,
        step_period_ns=200.0, seed=1, request_size_bytes=256,
    )
    sim_result = sim.run(reqs)
    lat_p99 = sim_result.latency.value.get("p99", 0.0)

    available_bw = sim.topology.total_theoretical_bandwidth_gbps()
    available_capacity = sim.topology.total_capacity_bytes

    ai_result = analyse_ai_workload(
        target_spec, target_tokens_per_second=target_tokens_per_second,
        available_capacity_bytes=available_capacity, available_bandwidth_gbps=available_bw,
        achieved_p99_latency_ns=lat_p99, latency_budget_ns=100000.0,
    )

    print(f"\n--- {name} ---")
    print(f"  Model: {target_spec.num_layers} layers, hidden={target_spec.hidden_dim}, "
          f"heads={target_spec.num_heads}, seq_len={target_spec.seq_len}, batch={target_spec.batch_size}")
    print(f"  Target throughput:     {target_tokens_per_second} tokens/s")
    print(f"  Required bandwidth:    {ai_result.required_bandwidth_gbps:.2f} GB/s")
    print(f"  Available bandwidth:   {ai_result.available_bandwidth_gbps:.2f} GB/s")
    print(f"  Working set:           {ai_result.total_working_set_bytes / 1e9:.2f} GB "
          f"(capacity available: {available_capacity / 1e9:.1f} GB)")
    print(f"  Simulated p99 latency: {lat_p99:.1f} ns")
    print(f"  Bottleneck (measured): {sim_result.bottleneck.bottleneck.value}")
    print(f"  >>> VERDICT: {ai_result.verdict.value}")
    return {"name": name, "verdict": ai_result.verdict.value, "evidence": ai_result.evidence,
            "measured_bottleneck": sim_result.bottleneck.bottleneck.value}


def main():
    print("=" * 70)
    print("DEMONSTRATION 5: AI workload memory analysis")
    print("=" * 70)

    device = DRAMDevice.synthetic_ddr5_like(density_gb=16.0, data_rate_mt_s=8000)
    trace_spec = TransformerWorkloadSpec(num_layers=4, hidden_dim=512, num_heads=8,
                                          seq_len=512, batch_size=1, dtype_bytes=2)

    results = []

    # Case A: a modest model at a modest target rate -- should fit comfortably.
    small_target = TransformerWorkloadSpec(num_layers=8, hidden_dim=1024, num_heads=16,
                                            seq_len=2048, batch_size=1, dtype_bytes=2)
    results.append(analyse_one("Small model, modest throughput target", small_target, trace_spec,
                                device, n_channels=4, target_tokens_per_second=20))

    # Case B: a moderately large model whose working set fits in
    # capacity, but whose required bandwidth at the target rate does not
    # -- should be bandwidth-limited (not capacity-limited).
    large_target = TransformerWorkloadSpec(num_layers=24, hidden_dim=4096, num_heads=32,
                                            seq_len=4096, batch_size=2, dtype_bytes=2)
    results.append(analyse_one("Large model, working set fits but bandwidth doesn't", large_target,
                                trace_spec, device, n_channels=4, target_tokens_per_second=50))

    # Case C: a huge model whose working set exceeds available capacity.
    huge_target = TransformerWorkloadSpec(num_layers=96, hidden_dim=12288, num_heads=96,
                                           seq_len=8192, batch_size=32, dtype_bytes=2)
    results.append(analyse_one("Huge model exceeding device capacity", huge_target, trace_spec,
                                device, n_channels=2, target_tokens_per_second=50))

    with open("demo5_ai_workload_analysis.json", "w") as f:
        json.dump(results, f, indent=2, default=str)
    print("\nResults written to demo5_ai_workload_analysis.json")


if __name__ == "__main__":
    main()
