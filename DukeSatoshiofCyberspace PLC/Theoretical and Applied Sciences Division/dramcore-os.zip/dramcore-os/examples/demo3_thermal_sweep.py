"""
Demonstration 3 (spec section 106): sweep ambient temperature across
20C / 40C / 60C / 80C and observe thermal state, retention, refresh
requirement, and power.
"""
from __future__ import annotations

import json

from dramcore.cell.cell import DRAMCell
from dramcore.power.profile import PowerProfile
from dramcore.thermal.coupling import bandwidth_cap_fraction, evaluate_causal_chain
from dramcore.thermal.engine import ThermalModel, ThermalPolicy


def main():
    print("=" * 70)
    print("DEMONSTRATION 3: Temperature sweep -- thermal / retention /")
    print("refresh / power causal chain (20C / 40C / 60C / 80C)")
    print("=" * 70)

    cell = DRAMCell()
    policy = ThermalPolicy(warning_temp_c=70, throttle_temp_c=85, critical_temp_c=95)
    power_profile = PowerProfile.synthetic_ddr5_like()

    temperatures = [20.0, 40.0, 60.0, 80.0]
    results = []

    for ambient_c in temperatures:
        thermal_model = ThermalModel(thermal_resistance_c_per_w=8.0, thermal_mass_j_per_c=0.05,
                                      ambient_temperature_c=ambient_c, policy=policy)
        # steady-state die temperature under a representative ~2W load
        ss_result = thermal_model.steady_state_temperature_c(power_w=2.0)
        die_temp = ss_result.value
        thermal_model.current_temperature_c = die_temp
        state = thermal_model.state()

        chain = evaluate_causal_chain(cell, temperature_c=die_temp, thermal_state=state)
        bw_cap = bandwidth_cap_fraction(state)

        results.append({
            "ambient_c": ambient_c,
            "steady_state_die_temp_c": die_temp,
            "thermal_state": state.value,
            "thermal_margin_c": thermal_model.thermal_margin_c(),
            "retention_time_ns": chain.retention_time_ns,
            "required_refresh_interval_ns": chain.required_refresh_interval_ns,
            "refresh_multiplier_applied": chain.refresh_multiplier_applied,
            "bandwidth_cap_fraction": bw_cap,
        })

    print(f"\n{'Ambient':>8}{'Die T':>8}{'State':>12}{'Retention(ns)':>16}"
          f"{'ReqRefresh(ns)':>16}{'RefreshMult':>12}{'BW cap':>8}")
    for r in results:
        print(f"{r['ambient_c']:>8.0f}{r['steady_state_die_temp_c']:>8.1f}"
              f"{r['thermal_state']:>12}{r['retention_time_ns']:>16.1f}"
              f"{r['required_refresh_interval_ns']:>16.1f}"
              f"{r['refresh_multiplier_applied']:>12.1f}{r['bandwidth_cap_fraction']:>8.2f}")

    # sanity: retention must strictly decrease as temperature rises
    retentions = [r["retention_time_ns"] for r in results]
    assert retentions == sorted(retentions, reverse=True), \
        "Retention should monotonically decrease with temperature"
    print("\nConfirmed: retention time monotonically decreases with temperature "
          "(POWER -> TEMPERATURE -> RETENTION -> REFRESH causal chain holds).")

    with open("demo3_thermal_sweep.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nResults written to demo3_thermal_sweep.json")


if __name__ == "__main__":
    main()
