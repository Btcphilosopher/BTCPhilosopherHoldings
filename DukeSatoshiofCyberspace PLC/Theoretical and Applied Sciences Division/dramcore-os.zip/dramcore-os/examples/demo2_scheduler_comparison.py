"""
Demonstration 2 (spec section 105): FCFS vs FR-FCFS vs DEADLINE against
the exact same workload -- latency, bandwidth, fairness, power comparison.
"""
from __future__ import annotations

import json

from dramcore.controller.simulation import Simulation
from dramcore.device.dram_device import DRAMDevice
from dramcore.scheduler.scheduler import SchedulerPolicy
from dramcore.traffic.generators import TrafficConfig, mixed


def fairness_jain_index(bytes_by_source: dict) -> float:
    """Jain's fairness index over per-source bytes served: 1.0 = perfectly
    fair, 1/n = maximally unfair (all traffic to one source)."""
    values = list(bytes_by_source.values())
    if not values or sum(values) == 0:
        return 1.0
    n = len(values)
    num = sum(values) ** 2
    den = n * sum(v ** 2 for v in values)
    return num / den if den > 0 else 1.0


def main():
    print("=" * 70)
    print("DEMONSTRATION 2: FCFS vs FR-FCFS vs DEADLINE, identical workload")
    print("=" * 70)

    device_factory = lambda: DRAMDevice.synthetic_ddr5_like()
    policies = [SchedulerPolicy.FCFS, SchedulerPolicy.FR_FCFS, SchedulerPolicy.DEADLINE]
    results = {}

    for policy in policies:
        sim = Simulation(device=device_factory(), n_channels=2, scheduler_policy=policy,
                          queue_depth=128, seed=77)
        cfg = TrafficConfig(n_requests=4000, address_space_bytes=sim.topology.total_capacity_bytes,
                             request_size_bytes=64, mean_inter_arrival_ns=0.6, write_fraction=0.3,
                             seed=77)
        reqs = mixed(cfg, sequential_fraction=0.6)
        for i, r in enumerate(reqs):
            r.source = "cpu" if i % 3 != 0 else "gpu"
            if policy == SchedulerPolicy.DEADLINE:
                r.deadline_ns = r.arrival_time_ns + 2000.0

        result = sim.run(reqs)

        bytes_by_source = {}
        for r in result.requests:
            bytes_by_source[r.source] = bytes_by_source.get(r.source, 0) + r.size_bytes
        fairness = fairness_jain_index(bytes_by_source)

        results[policy.value] = {
            "bandwidth_gbps": result.bandwidth.value,
            "mean_latency_ns": result.latency.value.get("mean"),
            "p99_latency_ns": result.latency.value.get("p99"),
            "row_hit_rate": result.row_hit_rate.value,
            "power_mw": result.power.value,
            "fairness_jain_index": fairness,
            "bottleneck": result.bottleneck.bottleneck.value,
        }

    print(f"\n{'Policy':<12}{'BW (GB/s)':>12}{'Mean lat':>12}{'p99 lat':>12}"
          f"{'Hit rate':>10}{'Power(mW)':>12}{'Fairness':>10}")
    for policy_name, r in results.items():
        print(f"{policy_name:<12}{r['bandwidth_gbps']:>12.2f}{r['mean_latency_ns']:>12.1f}"
              f"{r['p99_latency_ns']:>12.1f}{r['row_hit_rate']:>10.3f}"
              f"{r['power_mw']:>12.1f}{r['fairness_jain_index']:>10.3f}")

    print("\nFull results:")
    print(json.dumps(results, indent=2))

    with open("demo2_scheduler_comparison.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nResults written to demo2_scheduler_comparison.json")


if __name__ == "__main__":
    main()
