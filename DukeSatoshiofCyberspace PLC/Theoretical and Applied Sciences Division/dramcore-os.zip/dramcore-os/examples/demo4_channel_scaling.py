"""
Demonstration 4 (spec section 107): run 1 / 2 / 4 / 8 channels and
calculate scaling efficiency (achieved bandwidth relative to ideal linear
scaling from the 1-channel baseline).
"""
from __future__ import annotations

import json

from dramcore.controller.simulation import Simulation
from dramcore.device.dram_device import DRAMDevice
from dramcore.scheduler.scheduler import SchedulerPolicy
from dramcore.traffic.generators import TrafficConfig, random_traffic


def main():
    print("=" * 70)
    print("DEMONSTRATION 4: Multi-channel scaling (1/2/4/8 channels)")
    print("=" * 70)

    channel_counts = [1, 2, 4, 8]
    results = []
    baseline_achieved = None

    for n_ch in channel_counts:
        device = DRAMDevice.synthetic_ddr5_like()
        sim = Simulation(device=device, n_channels=n_ch, scheduler_policy=SchedulerPolicy.FR_FCFS,
                          queue_depth=64 * n_ch, seed=55)
        # scale offered load with channel count so the system stays in a
        # comparable (near-saturated) operating regime at every point
        n_requests = 1500 * n_ch
        cfg = TrafficConfig(n_requests=n_requests, address_space_bytes=sim.topology.total_capacity_bytes,
                             request_size_bytes=64, mean_inter_arrival_ns=0.5 / n_ch, seed=55)
        result = sim.run(random_traffic(cfg))

        theoretical = sim.topology.total_theoretical_bandwidth_gbps()
        achieved = result.bandwidth.value
        if baseline_achieved is None:
            baseline_achieved = achieved
        ideal_scaled = baseline_achieved * n_ch
        scaling_efficiency = achieved / ideal_scaled if ideal_scaled > 0 else 0.0

        results.append({
            "n_channels": n_ch,
            "theoretical_bandwidth_gbps": theoretical,
            "achieved_bandwidth_gbps": achieved,
            "ideal_linear_scaled_gbps": ideal_scaled,
            "scaling_efficiency": scaling_efficiency,
            "row_hit_rate": result.row_hit_rate.value,
            "mean_latency_ns": result.latency.value.get("mean"),
        })

    print(f"\n{'Channels':>10}{'Theoretical':>14}{'Achieved':>12}{'IdealScaled':>14}"
          f"{'Efficiency':>12}{'HitRate':>10}")
    for r in results:
        print(f"{r['n_channels']:>10}{r['theoretical_bandwidth_gbps']:>14.1f}"
              f"{r['achieved_bandwidth_gbps']:>12.2f}{r['ideal_linear_scaled_gbps']:>14.2f}"
              f"{r['scaling_efficiency']:>12.2%}{r['row_hit_rate']:>10.3f}")

    theoretical_bws = [r["theoretical_bandwidth_gbps"] for r in results]
    assert theoretical_bws == sorted(theoretical_bws), "Theoretical BW must scale with channels"
    print("\nConfirmed: theoretical bandwidth scales linearly with channel count.")

    with open("demo4_channel_scaling.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nResults written to demo4_channel_scaling.json")


if __name__ == "__main__":
    main()
