Reserved for saved plots (spec section 102).
