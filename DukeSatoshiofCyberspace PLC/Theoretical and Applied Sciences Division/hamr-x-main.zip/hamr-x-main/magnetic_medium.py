"""
HAMR-X CORE :: physics/magnetic_medium.py
==========================================
Magnetic recording medium model for Heat-Assisted Magnetic Recording (HAMR).

Models the ensemble of magnetic grains that constitutes a HAMR storage medium,
including:
  - Temperature-dependent coercivity using mean-field theory approximation
  - Grain size distribution (log-normal)
  - Thermal stability factor (KuV/kT)
  - Switching field distribution
  - Accumulated degradation state

Physical basis
--------------
The coercivity Hc(T) of an FePt-class material is approximated via:

    Hc(T) = Hc(0) · [1 - (T/Tc)^α]^β

where α, β are empirical fitting exponents (~1.5, 0.5 for FePt L10).

The thermal stability factor Δ:

    Δ = Ku · V / (kB · T)

where V is the grain volume = π/6 · d³,  Ku is uniaxial anisotropy density.

For reliable storage: Δ > 40.

Switching probability P_switch for a grain follows Néel-Brown relaxation:

    τ = τ0 · exp(Δ · (1 - H/Hk)²)
    P_switch = 1 - exp(-t_write / τ)

where Hk = 2·Ku / μ0·Ms is the anisotropy field.
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Optional

from ..utils.config import MediumConfig, PhysicalConstants, MEDIUM_LIBRARY
from ..utils.logging import get_logger


_logger = get_logger("physics.magnetic_medium")

# Néel relaxation pre-exponential factor (s)
TAU_0: float = 1.0e-9


# ─────────────────────────────────────────────────────────────────────────────
#  GRAIN STATE DATACLASS
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class GrainState:
    """
    State of a single magnetic grain in the recording medium.

    Attributes
    ----------
    magnetisation   : Current magnetisation direction (+1 = UP, -1 = DOWN)
    diameter_nm     : Physical grain diameter (nm)
    coercivity_oe   : Current coercivity at ambient temperature (Oe)
    switched        : Whether this grain switched in the current write event
    cycle_count     : Total write cycles experienced by this grain
    """
    magnetisation:  float
    diameter_nm:    float
    coercivity_oe:  float
    switched:       bool  = False
    cycle_count:    int   = 0


# ─────────────────────────────────────────────────────────────────────────────
#  MAGNETIC MEDIUM MODEL
# ─────────────────────────────────────────────────────────────────────────────

class MagneticMedium:
    """
    Ensemble-level model of a HAMR recording medium.

    Represents a population of magnetic grains drawn from a log-normal size
    distribution. Provides methods to compute temperature-dependent coercivity,
    switching probability under combined thermal and field conditions, and
    accumulated degradation after repeated write cycles.

    Parameters
    ----------
    config    : MediumConfig specifying material parameters
    n_grains  : Number of grains to model in the ensemble
    seed      : RNG seed for reproducible grain population generation
    """

    # Coercivity-temperature fitting exponents for FePt-class materials
    _COER_ALPHA: float = 1.5
    _COER_BETA:  float = 0.5

    def __init__(self, config: MediumConfig, n_grains: int = 500,
                 seed: int = 42) -> None:
        self.config   = config
        self.n_grains = n_grains
        self.rng      = np.random.default_rng(seed)

        # Total write cycles applied to medium (for degradation tracking)
        self._total_cycles:       int   = 0
        self._degradation_factor: float = 1.0   # multiplies current coercivity

        # Initialise grain population
        self.grains: list[GrainState] = []
        self._initialise_grains()

        _logger.info(
            f"Medium '{config.name}' initialised: "
            f"{n_grains} grains, "
            f"d̄={config.grain_diameter_nm:.1f} nm, "
            f"Hc={config.coercivity_oe:.0f} Oe"
        )

    # ──────────────────────────────────────────────────────────────────────────
    #  INITIALISATION
    # ──────────────────────────────────────────────────────────────────────────

    def _initialise_grains(self) -> None:
        """
        Populate the grain ensemble using a log-normal diameter distribution.

        Log-normal is appropriate because grain sizes from physical deposition
        processes are multiplicatively distributed (central limit theorem in
        log-space).
        """
        # Compute log-normal parameters from mean/sigma specification
        d_mean = self.config.grain_diameter_nm
        d_sigma = self.config.grain_sigma_nm
        # Method of moments conversion to log-normal μ, σ
        ln_sigma = np.sqrt(np.log(1 + (d_sigma / d_mean) ** 2))
        ln_mu    = np.log(d_mean) - 0.5 * ln_sigma ** 2

        diameters = self.rng.lognormal(mean=ln_mu, sigma=ln_sigma,
                                        size=self.n_grains)
        # Clamp to physically reasonable range
        diameters = np.clip(diameters, 2.0, 25.0)

        # Initialise each grain with random magnetisation and scaled coercivity
        for d in diameters:
            # Coercivity scales approximately with grain volume for fine particles
            # Larger grains have slightly lower coercivity due to multi-domain onset
            hc_scale = 1.0 + 0.05 * self.rng.standard_normal()
            hc = self.config.coercivity_oe * hc_scale
            m  = float(self.rng.choice([-1, 1]))
            self.grains.append(GrainState(
                magnetisation=m,
                diameter_nm=d,
                coercivity_oe=max(hc, 1000.0),
            ))

    # ──────────────────────────────────────────────────────────────────────────
    #  COERCIVITY MODEL
    # ──────────────────────────────────────────────────────────────────────────

    def coercivity_at_temperature(self, temperature_k: float) -> float:
        """
        Return the mean coercivity of the ensemble at a given temperature.

        Uses the empirical power-law fit:
            Hc(T) = Hc(0) · [1 - (T/Tc)^α]^β

        Parameters
        ----------
        temperature_k : Temperature in Kelvin

        Returns
        -------
        Coercivity in Oersteds (Oe)
        """
        tc   = self.config.curie_temp_k
        hc0  = self.config.coercivity_oe * self._degradation_factor

        # Clamp temperature: above Curie temp → zero coercivity
        if temperature_k >= tc:
            return 0.0

        t_ratio = temperature_k / tc
        hc      = hc0 * (1.0 - t_ratio ** self._COER_ALPHA) ** self._COER_BETA
        return max(hc, 0.0)

    def switching_field_at_temperature(self, temperature_k: float) -> float:
        """
        Return the mean switching field Hk at temperature T.

        Hk ≈ 2·Ku(T) / (μ0·Ms(T))

        Ku and Ms both decrease with temperature; Hk decreases faster than Hc
        due to the reduced anisotropy near Tc.
        """
        tc   = self.config.curie_temp_k
        if temperature_k >= tc:
            return 0.0
        t_ratio = temperature_k / tc
        # Anisotropy field approximation
        ku_T = self.config.ku_density * (1.0 - t_ratio ** 2.0)
        ms_T = self.config.saturation_mag * (1.0 - t_ratio ** 0.5)
        if ms_T < 1e3:
            return 0.0
        hk = 2.0 * ku_T / (PhysicalConstants.MU_0 * ms_T)
        # Convert A/m → Oe  (1 A/m = 4π/1000 * 10 Oe ≈ 0.01257 Oe)
        return hk * 0.01257

    # ──────────────────────────────────────────────────────────────────────────
    #  THERMAL STABILITY
    # ──────────────────────────────────────────────────────────────────────────

    def thermal_stability_factor(self, temperature_k: float,
                                  grain_diameter_nm: Optional[float] = None) -> float:
        """
        Compute the thermal stability factor Δ = KuV / (kB·T).

        Parameters
        ----------
        temperature_k    : Temperature in Kelvin
        grain_diameter_nm: Grain diameter; uses config mean if None

        Returns
        -------
        Dimensionless stability factor Δ
        """
        d_nm = grain_diameter_nm or self.config.grain_diameter_nm
        d_m  = d_nm * 1e-9
        V    = (np.pi / 6.0) * d_m ** 3          # spherical grain volume (m³)
        tc   = self.config.curie_temp_k
        t_ratio = temperature_k / tc
        ku_T = self.config.ku_density * max(0.0, 1.0 - t_ratio ** 2.0)
        delta = (ku_T * V) / (PhysicalConstants.BOLTZMANN_K * temperature_k)
        return delta

    # ──────────────────────────────────────────────────────────────────────────
    #  SWITCHING PROBABILITY (NÉEL-BROWN MODEL)
    # ──────────────────────────────────────────────────────────────────────────

    def switching_probability(self,
                               applied_field_oe: float,
                               temperature_k:    float,
                               pulse_duration_ns: float,
                               grain_diameter_nm: Optional[float] = None) -> float:
        """
        Compute switching probability for a grain using a coercivity-based
        logistic (sigmoid) model appropriate for system-level simulation.

        At the system level, switching is modelled via:

            P_switch = σ(k · (H / Hc(T) − 1))

        where σ is the logistic function and k controls sharpness (~10–20).

        Physical basis:
          - When H ≫ Hc(T): P → 1.0  (certain switching)
          - When H = Hc(T): P = 0.5  (threshold condition)
          - When H ≪ Hc(T): P → 0.0  (no switching)

        At temperatures near Tc, Hc → 0 so small fields trigger switching.
        This is the correct system-level model for HAMR where many grains
        are thermally activated simultaneously.

        Parameters
        ----------
        applied_field_oe  : Applied write field magnitude (Oe)
        temperature_k     : Local temperature at the grain (Kelvin)
        pulse_duration_ns : Write pulse width (ns) — affects noise floor
        grain_diameter_nm : Grain diameter for fine-grain adjustment

        Returns
        -------
        Switching probability in [0, 1]
        """
        hc = self.coercivity_at_temperature(temperature_k)

        # Above Curie temperature — zero coercivity, free switching
        if hc <= 0.0:
            return 1.0

        h_ratio = abs(applied_field_oe) / hc

        # Logistic switching model with sharpness k=15
        # k=15 gives <1% switching at H=0.7·Hc and >99% at H=1.3·Hc
        k     = 15.0
        prob  = 1.0 / (1.0 + np.exp(-k * (h_ratio - 1.0)))

        # Pulse-duration penalty: very short pulses (<0.5 ns) reduce prob
        if pulse_duration_ns < 0.5:
            prob *= pulse_duration_ns / 0.5

        return float(np.clip(prob, 0.0, 1.0))

    # ──────────────────────────────────────────────────────────────────────────
    #  ENSEMBLE WRITE SIMULATION
    # ──────────────────────────────────────────────────────────────────────────

    def simulate_write_event(self,
                              applied_field_oe: float,
                              temperature_k:    float,
                              pulse_duration_ns: float,
                              target_direction: float = 1.0) -> dict:
        """
        Simulate a single write event across the entire grain ensemble.

        Each grain is tested independently for switching. The write is
        considered successful if the majority of grains align with the
        target direction.

        Parameters
        ----------
        applied_field_oe  : Applied write field magnitude (Oe)
        temperature_k     : Peak temperature in the write zone (K)
        pulse_duration_ns : Duration of write pulse (ns)
        target_direction  : Desired magnetisation direction (+1 or -1)

        Returns
        -------
        dict with keys:
          success          : bool — write succeeded
          fraction_switched: float — fraction of grains that switched
          mean_coercivity  : float — current mean coercivity (Oe)
          switched_count   : int — number of grains that switched
        """
        switched_count = 0

        for grain in self.grains:
            # Determine if this grain needs to switch
            if grain.magnetisation == target_direction:
                continue   # Already aligned — no switching needed

            # Compute per-grain switching probability
            p_switch = self.switching_probability(
                applied_field_oe  = applied_field_oe,
                temperature_k     = temperature_k,
                pulse_duration_ns = pulse_duration_ns,
                grain_diameter_nm = grain.diameter_nm,
            )

            # Stochastic switching decision
            if self.rng.random() < p_switch:
                grain.magnetisation = target_direction
                grain.switched      = True
                switched_count     += 1
            else:
                grain.switched = False

            grain.cycle_count += 1

        self._total_cycles += 1

        # Majority vote to determine write outcome
        aligned = sum(1 for g in self.grains
                      if g.magnetisation == target_direction)
        fraction_aligned = aligned / self.n_grains

        # Write is successful if >85% of grains align with target
        success = fraction_aligned > 0.85

        mean_hc = np.mean([g.coercivity_oe for g in self.grains])

        return {
            "success":           success,
            "fraction_aligned":  fraction_aligned,
            "fraction_switched": switched_count / self.n_grains,
            "mean_coercivity":   mean_hc,
            "switched_count":    switched_count,
            "temperature_k":     temperature_k,
        }

    # ──────────────────────────────────────────────────────────────────────────
    #  THERMAL DEMAGNETISATION CHECK
    # ──────────────────────────────────────────────────────────────────────────

    def check_thermal_erasure_risk(self, temperature_k: float) -> float:
        """
        Estimate the fraction of grains at risk of thermal demagnetisation.

        A grain is 'at risk' if its thermal stability factor drops below
        the minimum threshold (Δ_min = 40) at the given temperature.

        Returns
        -------
        Fraction of grains in the ensemble with Δ < 40
        """
        at_risk = 0
        for grain in self.grains:
            delta = self.thermal_stability_factor(temperature_k,
                                                   grain.diameter_nm)
            if delta < 40.0:
                at_risk += 1
        return at_risk / self.n_grains

    # ──────────────────────────────────────────────────────────────────────────
    #  DEGRADATION MODEL
    # ──────────────────────────────────────────────────────────────────────────

    def apply_degradation_cycle(self) -> float:
        """
        Update grain coercivities to reflect one write cycle of degradation.

        Degradation arises from repeated thermal cycling causing:
          - Grain boundary diffusion
          - Partial grain decomposition
          - Surface oxidation

        The model applies a fractional coercivity reduction per cycle,
        with added Gaussian noise to simulate spatial variation.

        Returns
        -------
        Current mean degradation factor (1.0 = pristine)
        """
        base_rate  = self.config.degradation_rate
        noise_amp  = base_rate * 0.1  # 10% variation around mean rate

        for grain in self.grains:
            local_rate = base_rate + self.rng.normal(0.0, noise_amp)
            local_rate = max(local_rate, 0.0)
            grain.coercivity_oe *= (1.0 - local_rate)
            grain.coercivity_oe  = max(grain.coercivity_oe, 100.0)

        # Recompute ensemble-level degradation factor
        mean_hc    = np.mean([g.coercivity_oe for g in self.grains])
        self._degradation_factor = mean_hc / self.config.coercivity_oe
        return self._degradation_factor

    def get_degradation_factor(self) -> float:
        """Return current coercivity degradation factor [0, 1]."""
        return self._degradation_factor

    def get_total_cycles(self) -> int:
        """Return total write cycles applied to this medium."""
        return self._total_cycles

    # ──────────────────────────────────────────────────────────────────────────
    #  STATE SNAPSHOT
    # ──────────────────────────────────────────────────────────────────────────

    def state_snapshot(self) -> dict:
        """Return a dictionary summary of current medium state."""
        hc_values = [g.coercivity_oe for g in self.grains]
        d_values  = [g.diameter_nm   for g in self.grains]
        m_values  = [g.magnetisation  for g in self.grains]
        return {
            "medium_name":          self.config.name,
            "n_grains":             self.n_grains,
            "mean_coercivity_oe":   float(np.mean(hc_values)),
            "std_coercivity_oe":    float(np.std(hc_values)),
            "mean_diameter_nm":     float(np.mean(d_values)),
            "std_diameter_nm":      float(np.std(d_values)),
            "net_magnetisation":    float(np.mean(m_values)),
            "degradation_factor":   self._degradation_factor,
            "total_cycles":         self._total_cycles,
            "thermal_stability_room": self.thermal_stability_factor(298.15),
        }

    def grain_diameter_distribution(self) -> np.ndarray:
        """Return array of all grain diameters (nm)."""
        return np.array([g.diameter_nm for g in self.grains])

    def grain_coercivity_distribution(self) -> np.ndarray:
        """Return array of all grain coercivities (Oe)."""
        return np.array([g.coercivity_oe for g in self.grains])
