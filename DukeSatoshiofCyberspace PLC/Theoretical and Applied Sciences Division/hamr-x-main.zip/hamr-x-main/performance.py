"""
HAMR-X CORE :: metrics/performance.py
=======================================
Performance metrics computation and aggregation engine for HAMR-X.

Computes system-level KPIs from simulation state:
  - Storage density (Tb/in²)
  - Bit Error Rate (BER)
  - Write success rate
  - Energy cost per write (fJ)
  - Durability lifetime (cycles)
  - System reliability score
  - Figure of Merit (FoM) for optimisation ranking
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Optional
import time

from ..utils.config import HAMRConfig
from ..utils.logging import get_logger


_logger = get_logger("metrics.performance")


# ─────────────────────────────────────────────────────────────────────────────
#  PERFORMANCE METRICS DATACLASS
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PerformanceMetrics:
    """
    Complete performance metrics snapshot for a HAMR simulation run.

    Attributes
    ----------
    cycle_number            : Simulation cycle at which metrics were computed
    areal_density_tbpin2    : Net areal storage density (Tb/in²)
    raw_ber                 : Raw bit error rate
    post_ecc_ber            : Post-ECC bit error rate
    write_success_rate      : Fraction of writes succeeded
    read_success_rate       : Fraction of reads succeeded
    energy_per_write_fj     : Energy consumed per write (femtojoules)
    lifetime_cycles         : Estimated remaining usable write cycles
    reliability_score       : Overall system reliability [0, 1]
    peak_temperature_k      : Mean peak write temperature (K)
    thermal_misfire_rate    : Rate of off-target thermal events
    alignment_quality       : Mean head alignment factor
    degradation_health      : Medium health score [0, 1]
    figure_of_merit         : Composite optimisation score (higher=better)
    timestamp               : Unix timestamp of metric capture
    """
    cycle_number:           int
    areal_density_tbpin2:   float
    raw_ber:                float
    post_ecc_ber:           float
    write_success_rate:     float
    read_success_rate:      float
    energy_per_write_fj:    float
    lifetime_cycles:        int
    reliability_score:      float
    peak_temperature_k:     float
    thermal_misfire_rate:   float
    alignment_quality:      float
    degradation_health:     float
    figure_of_merit:        float
    timestamp:              float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        """Serialise to plain dictionary."""
        return {
            "cycle_number":           self.cycle_number,
            "areal_density_tbpin2":   round(self.areal_density_tbpin2, 6),
            "raw_ber":                f"{self.raw_ber:.4e}",
            "post_ecc_ber":           f"{self.post_ecc_ber:.4e}",
            "write_success_rate":     round(self.write_success_rate, 6),
            "read_success_rate":      round(self.read_success_rate, 6),
            "energy_per_write_fj":    round(self.energy_per_write_fj, 4),
            "lifetime_cycles":        self.lifetime_cycles,
            "reliability_score":      round(self.reliability_score, 6),
            "peak_temperature_k":     round(self.peak_temperature_k, 2),
            "thermal_misfire_rate":   f"{self.thermal_misfire_rate:.4e}",
            "alignment_quality":      round(self.alignment_quality, 6),
            "degradation_health":     round(self.degradation_health, 6),
            "figure_of_merit":        round(self.figure_of_merit, 8),
        }

    def formatted_report(self) -> str:
        """Return a formatted engineering report string."""
        lines = [
            "┌─────────────────────────────────────────────────────────┐",
            f"│  HAMR-X PERFORMANCE METRICS  ::  Cycle {self.cycle_number:>10,}     │",
            "├─────────────────────────────────────────────────────────┤",
            f"│  Areal Density      : {self.areal_density_tbpin2:>10.4f}  Tb/in²          │",
            f"│  Raw BER            : {self.raw_ber:>14.4e}               │",
            f"│  Post-ECC BER       : {self.post_ecc_ber:>14.4e}               │",
            f"│  Write Success      : {self.write_success_rate * 100:>10.4f}  %               │",
            f"│  Read Success       : {self.read_success_rate * 100:>10.4f}  %               │",
            f"│  Energy / Write     : {self.energy_per_write_fj:>10.2f}  fJ              │",
            f"│  Lifetime           : {self.lifetime_cycles:>10,}  cycles           │",
            f"│  Reliability Score  : {self.reliability_score:>10.4f}  [0-1]           │",
            f"│  Peak Temperature   : {self.peak_temperature_k:>10.1f}  K               │",
            f"│  Alignment Quality  : {self.alignment_quality:>10.4f}  [0-1]           │",
            f"│  Medium Health      : {self.degradation_health:>10.4f}  [0-1]           │",
            f"│  Figure of Merit    : {self.figure_of_merit:>14.6f}               │",
            "└─────────────────────────────────────────────────────────┘",
        ]
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
#  PERFORMANCE METRICS ENGINE
# ─────────────────────────────────────────────────────────────────────────────

class PerformanceEngine:
    """
    Computes and tracks system-level performance metrics across simulation runs.

    Aggregates raw simulation outputs into engineering KPIs and maintains
    a historical time series for trend analysis and reporting.

    Parameters
    ----------
    config         : HAMRConfig master configuration
    ber_target     : Target maximum BER (e.g. 1e-6)
    density_target : Target minimum density (Tb/in²)
    """

    # Figure of Merit weights
    _FOM_DENSITY_WEIGHT:    float = 0.40
    _FOM_RELIABILITY_WEIGHT: float = 0.35
    _FOM_ENERGY_WEIGHT:     float = 0.15
    _FOM_LIFETIME_WEIGHT:   float = 0.10

    # Reference values for normalisation
    _REF_DENSITY_TBPIN2:   float = 4.0
    _REF_LIFETIME_CYCLES:  int   = 1_000_000
    _REF_ENERGY_FJ:        float = 100.0

    def __init__(self, config: HAMRConfig,
                 ber_target:      float = 1e-6,
                 density_target:  float = 4.0) -> None:
        self.config          = config
        self.ber_target      = ber_target
        self.density_target  = density_target
        self._history:       list[PerformanceMetrics] = []
        _logger.info(
            f"Performance engine: BER_target={ber_target:.0e}, "
            f"density_target={density_target:.1f} Tb/in²"
        )

    # ──────────────────────────────────────────────────────────────────────────
    #  FIGURE OF MERIT
    # ──────────────────────────────────────────────────────────────────────────

    def compute_figure_of_merit(self,
                                  density_tbpin2:  float,
                                  reliability:     float,
                                  energy_per_write_fj: float,
                                  lifetime_cycles: int) -> float:
        """
        Compute a weighted Figure of Merit (FoM) for system ranking.

        FoM ∈ [0, 1] where higher is better. Combines:
          - Density score    (normalised, higher density = better)
          - Reliability score (direct [0,1])
          - Energy score     (lower energy = better)
          - Lifetime score   (normalised)

        Parameters
        ----------
        density_tbpin2     : Areal density (Tb/in²)
        reliability        : Reliability score [0,1]
        energy_per_write_fj: Energy per write (fJ)
        lifetime_cycles    : Estimated lifetime (cycles)

        Returns
        -------
        Figure of Merit [0, 1]
        """
        # Density normalised to target (capped at 2× target)
        density_score = float(np.clip(
            density_tbpin2 / self.density_target, 0.0, 2.0
        )) / 2.0

        # Reliability score (already [0,1])
        reliability_score = float(np.clip(reliability, 0.0, 1.0))

        # Energy score: penalise high energy
        energy_score = float(np.clip(
            1.0 - energy_per_write_fj / (self._REF_ENERGY_FJ * 5), 0.0, 1.0
        ))

        # Lifetime score
        lifetime_score = float(np.clip(
            lifetime_cycles / self._REF_LIFETIME_CYCLES, 0.0, 1.0
        ))

        fom = (
            self._FOM_DENSITY_WEIGHT    * density_score    +
            self._FOM_RELIABILITY_WEIGHT * reliability_score +
            self._FOM_ENERGY_WEIGHT     * energy_score     +
            self._FOM_LIFETIME_WEIGHT   * lifetime_score
        )
        return float(np.clip(fom, 0.0, 1.0))

    # ──────────────────────────────────────────────────────────────────────────
    #  METRIC COMPUTATION
    # ──────────────────────────────────────────────────────────────────────────

    def compute_metrics(self,
                         cycle_number:          int,
                         areal_density_tbpin2:  float,
                         raw_ber:               float,
                         post_ecc_ber:          float,
                         write_success_rate:    float,
                         read_success_rate:     float,
                         energy_per_pulse_pj:   float,
                         lifetime_cycles:       int,
                         reliability_score:     float,
                         peak_temperature_k:    float,
                         thermal_misfire_rate:  float,
                         alignment_quality:     float,
                         degradation_health:    float) -> PerformanceMetrics:
        """
        Compute a complete PerformanceMetrics snapshot.

        Parameters are sourced from the individual subsystem modules.
        """
        # Convert pulse energy (pJ) to per-write energy (fJ)
        # Account for total system energy including electronics overhead
        electronics_overhead = 2.5   # overhead multiplier
        energy_fj = energy_per_pulse_pj * 1000 * electronics_overhead

        fom = self.compute_figure_of_merit(
            density_tbpin2      = areal_density_tbpin2,
            reliability         = reliability_score,
            energy_per_write_fj = energy_fj,
            lifetime_cycles     = lifetime_cycles,
        )

        metrics = PerformanceMetrics(
            cycle_number          = cycle_number,
            areal_density_tbpin2  = areal_density_tbpin2,
            raw_ber               = raw_ber,
            post_ecc_ber          = post_ecc_ber,
            write_success_rate    = write_success_rate,
            read_success_rate     = read_success_rate,
            energy_per_write_fj   = energy_fj,
            lifetime_cycles       = lifetime_cycles,
            reliability_score     = reliability_score,
            peak_temperature_k    = peak_temperature_k,
            thermal_misfire_rate  = thermal_misfire_rate,
            alignment_quality     = alignment_quality,
            degradation_health    = degradation_health,
            figure_of_merit       = fom,
        )

        self._history.append(metrics)
        return metrics

    # ──────────────────────────────────────────────────────────────────────────
    #  HISTORICAL ANALYSIS
    # ──────────────────────────────────────────────────────────────────────────

    def get_history_arrays(self) -> dict[str, np.ndarray]:
        """
        Return historical metrics as numpy arrays for plotting.

        Returns
        -------
        dict mapping metric names to 1D numpy arrays
        """
        if not self._history:
            return {}
        n = len(self._history)
        return {
            "cycle":             np.array([m.cycle_number        for m in self._history]),
            "density":           np.array([m.areal_density_tbpin2 for m in self._history]),
            "raw_ber":           np.array([m.raw_ber              for m in self._history]),
            "post_ecc_ber":      np.array([m.post_ecc_ber         for m in self._history]),
            "write_success":     np.array([m.write_success_rate   for m in self._history]),
            "energy_fj":         np.array([m.energy_per_write_fj  for m in self._history]),
            "reliability":       np.array([m.reliability_score    for m in self._history]),
            "peak_temp":         np.array([m.peak_temperature_k   for m in self._history]),
            "alignment":         np.array([m.alignment_quality    for m in self._history]),
            "health":            np.array([m.degradation_health   for m in self._history]),
            "fom":               np.array([m.figure_of_merit      for m in self._history]),
        }

    def trend_analysis(self) -> dict:
        """
        Compute trends (linear regression slope) for key metrics.

        Returns
        -------
        dict with per-metric slopes (positive = improving, negative = degrading)
        """
        arrays = self.get_history_arrays()
        if len(arrays.get("cycle", [])) < 3:
            return {}

        cycles = arrays["cycle"].astype(float)
        cycles_norm = (cycles - cycles.mean()) / max(cycles.std(), 1.0)

        trends = {}
        for key, values in arrays.items():
            if key == "cycle" or len(values) < 3:
                continue
            # Simple linear trend
            slope = float(np.polyfit(cycles_norm, values, deg=1)[0])
            trends[f"{key}_trend"] = slope

        return trends

    def best_configuration_cycle(self) -> Optional[int]:
        """Return the simulation cycle with the highest Figure of Merit."""
        if not self._history:
            return None
        best = max(self._history, key=lambda m: m.figure_of_merit)
        return best.cycle_number

    def summary_statistics(self) -> dict:
        """Return aggregate statistics over all recorded metrics."""
        if not self._history:
            return {"n_snapshots": 0}
        n = len(self._history)
        return {
            "n_snapshots":          n,
            "mean_density_tbpin2":  float(np.mean([m.areal_density_tbpin2 for m in self._history])),
            "mean_post_ecc_ber":    float(np.mean([m.post_ecc_ber         for m in self._history])),
            "mean_write_success":   float(np.mean([m.write_success_rate   for m in self._history])),
            "mean_reliability":     float(np.mean([m.reliability_score    for m in self._history])),
            "peak_fom":             float(max(m.figure_of_merit            for m in self._history)),
            "final_health":         float(self._history[-1].degradation_health),
        }

    def ber_meets_target(self, metrics: PerformanceMetrics) -> bool:
        """Return True if post-ECC BER meets the system BER target."""
        return metrics.post_ecc_ber <= self.ber_target

    def density_meets_target(self, metrics: PerformanceMetrics) -> bool:
        """Return True if areal density meets the minimum density target."""
        return metrics.areal_density_tbpin2 >= self.density_target
