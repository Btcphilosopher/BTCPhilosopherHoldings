"""
HAMR-X CORE :: gui/dashboard.py
=================================
PyQt6 Engineering Dashboard for the HAMR-X simulation platform.

Industrial-grade, zero-decoration UI:
  - Left panel: parameter controls
  - Centre: live simulation output / log
  - Right: metrics display

Design language:
  - Near-black background (#0d0d0d)
  - Gold accent (#c9a84c) for headings and values
  - Cyan (#00d4e0) for interactive elements
  - Monospace throughout (JetBrains Mono / Consolas fallback)
"""

from __future__ import annotations
import sys
import time
import threading
from typing import Optional

try:
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QLabel, QSlider, QComboBox, QPushButton, QTextEdit, QFrame,
        QGridLayout, QGroupBox, QSpinBox, QDoubleSpinBox, QProgressBar,
        QTabWidget, QSplitter, QScrollArea,
    )
    from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
    from PyQt6.QtGui import QFont, QColor, QPalette, QTextCursor
    PYQT6_AVAILABLE = True
except ImportError:
    PYQT6_AVAILABLE = False

from ..utils.config import HAMRConfig, MEDIUM_LIBRARY, OPTIMISATION_BOUNDS
from ..utils.logging import get_logger

_logger = get_logger("gui.dashboard")


# ─────────────────────────────────────────────────────────────────────────────
#  STYLE SHEET
# ─────────────────────────────────────────────────────────────────────────────

HAMR_STYLESHEET = """
QMainWindow, QWidget {
    background-color: #0d0d0d;
    color: #c8c8c8;
    font-family: "JetBrains Mono", "Consolas", "Courier New", monospace;
    font-size: 11px;
}
QGroupBox {
    border: 1px solid #2a2a2a;
    border-radius: 2px;
    margin-top: 8px;
    padding: 6px;
    color: #c9a84c;
    font-size: 10px;
    font-weight: bold;
    letter-spacing: 1px;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 8px;
    padding: 0 4px;
}
QLabel {
    color: #909090;
    font-size: 11px;
}
QLabel#value_label {
    color: #c9a84c;
    font-size: 12px;
    font-weight: bold;
}
QLabel#metric_value {
    color: #00d4e0;
    font-size: 13px;
    font-weight: bold;
    font-family: "JetBrains Mono", monospace;
}
QLabel#metric_label {
    color: #606060;
    font-size: 10px;
    letter-spacing: 0.5px;
}
QLabel#title_label {
    color: #c9a84c;
    font-size: 16px;
    font-weight: bold;
    letter-spacing: 3px;
}
QLabel#subtitle_label {
    color: #505050;
    font-size: 9px;
    letter-spacing: 2px;
}
QPushButton {
    background-color: #1a1a1a;
    border: 1px solid #2e2e2e;
    border-radius: 1px;
    color: #c0c0c0;
    padding: 6px 14px;
    font-size: 11px;
    letter-spacing: 1px;
}
QPushButton:hover {
    background-color: #1e2020;
    border-color: #00d4e0;
    color: #00d4e0;
}
QPushButton:pressed {
    background-color: #0d1818;
    border-color: #007a82;
}
QPushButton#primary_btn {
    background-color: #162020;
    border: 1px solid #00d4e0;
    color: #00d4e0;
    font-weight: bold;
}
QPushButton#primary_btn:hover {
    background-color: #1a2a2a;
}
QPushButton#run_btn {
    background-color: #1a1a10;
    border: 1px solid #c9a84c;
    color: #c9a84c;
    font-weight: bold;
    font-size: 12px;
    padding: 8px 20px;
    letter-spacing: 2px;
}
QPushButton#run_btn:hover {
    background-color: #222210;
    border-color: #e0c060;
    color: #e0c060;
}
QPushButton#run_btn:disabled {
    background-color: #111111;
    border-color: #333333;
    color: #404040;
}
QDoubleSpinBox, QSpinBox, QComboBox {
    background-color: #111111;
    border: 1px solid #252525;
    border-radius: 1px;
    color: #c0c0c0;
    padding: 3px 6px;
    font-size: 11px;
    selection-background-color: #1a2020;
}
QDoubleSpinBox:focus, QSpinBox:focus, QComboBox:focus {
    border-color: #00d4e0;
}
QComboBox::drop-down {
    border: none;
    width: 16px;
}
QComboBox QAbstractItemView {
    background-color: #111111;
    border: 1px solid #2a2a2a;
    color: #c0c0c0;
    selection-background-color: #1a2020;
}
QTextEdit {
    background-color: #080808;
    border: 1px solid #1e1e1e;
    color: #7a9a7a;
    font-family: "JetBrains Mono", "Consolas", monospace;
    font-size: 10px;
    selection-background-color: #1a2020;
}
QProgressBar {
    background-color: #111111;
    border: 1px solid #252525;
    border-radius: 1px;
    text-align: center;
    color: #00d4e0;
    font-size: 10px;
    height: 12px;
}
QProgressBar::chunk {
    background-color: #00d4e0;
    width: 2px;
    margin: 0px;
}
QSlider::groove:horizontal {
    height: 3px;
    background: #222222;
    border-radius: 1px;
}
QSlider::handle:horizontal {
    background: #c9a84c;
    width: 10px;
    height: 10px;
    margin: -4px 0;
    border-radius: 1px;
}
QSlider::handle:horizontal:hover {
    background: #e0c060;
}
QTabWidget::pane {
    border: 1px solid #1e1e1e;
    background-color: #0d0d0d;
}
QTabBar::tab {
    background-color: #0d0d0d;
    border: 1px solid #1e1e1e;
    border-bottom: none;
    padding: 5px 14px;
    color: #606060;
    font-size: 10px;
    letter-spacing: 1px;
}
QTabBar::tab:selected {
    background-color: #111111;
    color: #c9a84c;
    border-color: #2a2a2a;
    border-bottom: 1px solid #111111;
}
QTabBar::tab:hover {
    color: #909090;
}
QScrollBar:vertical {
    background: #0d0d0d;
    width: 8px;
    border: none;
}
QScrollBar::handle:vertical {
    background: #2a2a2a;
    border-radius: 2px;
    min-height: 20px;
}
QScrollBar::handle:vertical:hover {
    background: #3a3a3a;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QFrame#separator {
    background-color: #1e1e1e;
    max-height: 1px;
}
"""


# ─────────────────────────────────────────────────────────────────────────────
#  SIMULATION WORKER THREAD
# ─────────────────────────────────────────────────────────────────────────────

if PYQT6_AVAILABLE:
    class SimulationWorker(QThread):
        """
        Background thread for running HAMR-X simulations without blocking UI.
        Emits progress and result signals.
        """
        progress_signal = pyqtSignal(int, str)          # (percent, message)
        metrics_signal  = pyqtSignal(dict)               # metrics dict
        complete_signal = pyqtSignal(object)             # SimulationResult
        error_signal    = pyqtSignal(str)                # error message

        def __init__(self, config: HAMRConfig) -> None:
            super().__init__()
            self.config  = config
            self._abort  = False

        def abort(self) -> None:
            self._abort = True

        def run(self) -> None:
            try:
                from ..core.simulation_engine import SimulationEngine
                engine = SimulationEngine(self.config)

                n_cycles  = self.config.simulation.n_cycles
                batch_sz  = 50
                n_batches = max(1, n_cycles // batch_sz)
                done_batches = 0

                # Patch the engine to emit progress signals
                original_run = engine.run

                def patched_run():
                    from ..storage.models import DensityModel, ErrorModel, DegradationModel
                    nonlocal done_batches
                    density_model = engine.density_model
                    density_result = density_model.compute_density()
                    current_density = density_result.areal_density_tbpin2

                    write_success_series = []
                    ber_series           = []
                    density_series       = []
                    temp_series          = []
                    total_failures = 0
                    total_writes   = 0
                    import time as _time
                    t0 = _time.perf_counter()

                    for batch_idx in range(n_batches):
                        if self._abort:
                            break
                        cycle_num = batch_idx * batch_sz
                        batch     = engine._run_write_batch(batch_sz, cycle_num)
                        total_writes   += batch_sz
                        total_failures += batch["n_failures"]

                        write_success_series.append(batch["write_success_rate"])
                        ber_series.append(batch["post_ecc_ber"])
                        density_series.append(current_density)
                        temp_series.append(batch["mean_peak_temp_k"])

                        if batch_idx % max(1, n_batches // 20) == 0:
                            pct = int(100 * batch_idx / n_batches)
                            msg = (f"Cycle {cycle_num:,}/{n_cycles:,}  |  "
                                   f"BER={batch['post_ecc_ber']:.2e}  |  "
                                   f"density={current_density:.4f} Tb/in²")
                            self.progress_signal.emit(pct, msg)
                            self.metrics_signal.emit({
                                "cycle":   cycle_num,
                                "ber":     batch["post_ecc_ber"],
                                "density": current_density,
                                "write_sr":batch["write_success_rate"],
                                "temp_k":  batch["mean_peak_temp_k"],
                            })

                        if batch_idx % 5 == 0:
                            degrad = engine.degradation.step(batch_sz)
                            tmr_st = engine.head.tmr_statistics()
                            if tmr_st.get("n_samples", 0) > 0:
                                engine.density_model.tmr_3sigma_nm = tmr_st["tmr_3sigma_nm"]
                                density_result  = engine.density_model.compute_density()
                                current_density = density_result.areal_density_tbpin2

                    # Build result
                    import numpy as np, uuid
                    from ..metrics.performance import PerformanceMetrics
                    import time as _t
                    degrad_state  = engine.degradation.get_current_state()
                    final_metrics = engine.perf_engine.compute_metrics(
                        cycle_number          = n_cycles,
                        areal_density_tbpin2  = current_density,
                        raw_ber               = float(np.mean(ber_series[-5:])) if ber_series else 0.1,
                        post_ecc_ber          = float(np.mean(ber_series[-5:])) if ber_series else 0.1,
                        write_success_rate    = float(np.mean(write_success_series[-5:])) if write_success_series else 0.9,
                        read_success_rate     = 0.99,
                        energy_per_pulse_pj   = engine.laser.state_summary()["energy_per_pulse_pj"],
                        lifetime_cycles       = engine.degradation.lifetime_estimate_cycles(),
                        reliability_score     = 0.8,
                        peak_temperature_k    = float(np.mean(temp_series[-5:])) if temp_series else 500.0,
                        thermal_misfire_rate  = 0.0,
                        alignment_quality     = 0.95,
                        degradation_health    = degrad_state.health_score,
                    )
                    from ..core.simulation_engine import SimulationResult
                    degrad_curve = engine.degradation.degradation_curve()
                    elapsed = _t.perf_counter() - t0
                    return SimulationResult(
                        run_id=engine.run_id,
                        config=self.config,
                        final_metrics=final_metrics,
                        metrics_history=engine.perf_engine._history,
                        degradation_curve=degrad_curve,
                        write_success_series=write_success_series,
                        ber_series=ber_series,
                        density_series=density_series,
                        temp_series=temp_series,
                        elapsed_seconds=elapsed,
                        n_write_ops=total_writes,
                        n_failures=total_failures,
                    )

                result = patched_run()
                self.progress_signal.emit(100, "Simulation complete")
                self.complete_signal.emit(result)

            except Exception as exc:
                import traceback
                self.error_signal.emit(
                    f"Simulation error: {exc}\n{traceback.format_exc()}"
                )


# ─────────────────────────────────────────────────────────────────────────────
#  METRIC DISPLAY WIDGET
# ─────────────────────────────────────────────────────────────────────────────

if PYQT6_AVAILABLE:
    class MetricWidget(QWidget):
        """Single metric display: label + large value."""

        def __init__(self, label: str, initial_value: str = "—",
                      unit: str = "") -> None:
            super().__init__()
            layout = QVBoxLayout(self)
            layout.setContentsMargins(8, 6, 8, 6)
            layout.setSpacing(2)

            self._label_w = QLabel(label.upper())
            self._label_w.setObjectName("metric_label")
            self._value_w = QLabel(initial_value)
            self._value_w.setObjectName("metric_value")
            self._unit_w  = QLabel(unit)
            self._unit_w.setObjectName("metric_label")

            layout.addWidget(self._label_w)
            layout.addWidget(self._value_w)
            layout.addWidget(self._unit_w)

            self.setStyleSheet("border: 1px solid #1a1a1a; background-color: #0a0a0a;")

        def set_value(self, value: str) -> None:
            self._value_w.setText(value)


# ─────────────────────────────────────────────────────────────────────────────
#  MAIN DASHBOARD WINDOW
# ─────────────────────────────────────────────────────────────────────────────

if PYQT6_AVAILABLE:
    class HAMRDashboard(QMainWindow):
        """
        Main HAMR-X engineering dashboard window.

        Three-panel layout:
          Left   — system parameter controls
          Centre — simulation log + progress
          Right  — live metrics display
        """

        def __init__(self) -> None:
            super().__init__()
            self._worker:  Optional[SimulationWorker] = None
            self._result   = None
            self._setup_window()
            self._build_ui()
            self.setStyleSheet(HAMR_STYLESHEET)

        def _setup_window(self) -> None:
            self.setWindowTitle("HAMR-X CORE  ::  Heat-Assisted Magnetic Recording Engine")
            self.setMinimumSize(1280, 780)
            self.resize(1440, 860)

        def _build_ui(self) -> None:
            central = QWidget()
            self.setCentralWidget(central)
            root_layout = QVBoxLayout(central)
            root_layout.setContentsMargins(10, 8, 10, 8)
            root_layout.setSpacing(6)

            # ── Header ────────────────────────────────────────────────────────
            root_layout.addWidget(self._build_header())

            sep = QFrame()
            sep.setObjectName("separator")
            sep.setFrameShape(QFrame.Shape.HLine)
            root_layout.addWidget(sep)

            # ── Main body (3 panels) ──────────────────────────────────────────
            body = QSplitter(Qt.Orientation.Horizontal)
            body.addWidget(self._build_left_panel())
            body.addWidget(self._build_centre_panel())
            body.addWidget(self._build_right_panel())
            body.setSizes([310, 620, 340])
            root_layout.addWidget(body, stretch=1)

            # ── Status bar ────────────────────────────────────────────────────
            self.statusBar().setStyleSheet(
                "background-color: #0a0a0a; color: #505050; "
                "border-top: 1px solid #1a1a1a; font-size: 10px;"
            )
            self.statusBar().showMessage(
                "HAMR-X CORE v1.0.0  ::  READY  ::  Select parameters and press RUN SIMULATION"
            )

        # ── HEADER ────────────────────────────────────────────────────────────

        def _build_header(self) -> QWidget:
            w = QWidget()
            layout = QHBoxLayout(w)
            layout.setContentsMargins(4, 4, 4, 4)

            title    = QLabel("HAMR-X")
            title.setObjectName("title_label")
            subtitle = QLabel("HEAT-ASSISTED MAGNETIC RECORDING  //  OPTIMISATION ENGINE  //  v1.0.0")
            subtitle.setObjectName("subtitle_label")

            layout.addWidget(title)
            layout.addWidget(subtitle)
            layout.addStretch()

            # Status indicator
            self._status_dot = QLabel("●")
            self._status_dot.setStyleSheet("color: #505050; font-size: 16px;")
            layout.addWidget(self._status_dot)
            self._status_label = QLabel("IDLE")
            self._status_label.setStyleSheet("color: #505050; font-size: 10px; letter-spacing: 2px;")
            layout.addWidget(self._status_label)

            return w

        # ── LEFT PANEL (parameters) ───────────────────────────────────────────

        def _build_left_panel(self) -> QWidget:
            w      = QWidget()
            layout = QVBoxLayout(w)
            layout.setContentsMargins(0, 0, 4, 0)
            layout.setSpacing(6)

            # Medium selection
            med_group = QGroupBox("RECORDING MEDIUM")
            med_layout = QVBoxLayout(med_group)
            self._medium_combo = QComboBox()
            for key, med in MEDIUM_LIBRARY.items():
                self._medium_combo.addItem(med.name, key)
            med_layout.addWidget(self._medium_combo)
            layout.addWidget(med_group)

            # Laser parameters
            laser_group = QGroupBox("LASER SYSTEM")
            laser_layout = QGridLayout(laser_group)

            self._laser_power  = self._make_double_spinbox(1.0, 15.0, 6.0, " mW")
            self._pulse_dur    = self._make_double_spinbox(0.5,  5.0, 1.5, " ns")
            self._spot_radius  = self._make_double_spinbox(15.0,50.0,25.0, " nm")
            self._nft_eff      = self._make_double_spinbox(0.60, 1.0, 0.85, "")

            for i, (lbl, widget) in enumerate([
                ("Power",      self._laser_power),
                ("Pulse dur.", self._pulse_dur),
                ("Spot radius",self._spot_radius),
                ("NFT η",      self._nft_eff),
            ]):
                laser_layout.addWidget(QLabel(lbl), i, 0)
                laser_layout.addWidget(widget,       i, 1)
            layout.addWidget(laser_group)

            # Storage geometry
            geom_group = QGroupBox("STORAGE GEOMETRY")
            geom_layout = QGridLayout(geom_group)

            self._track_spacing = self._make_double_spinbox(15.0, 60.0, 30.0, " nm")
            self._bit_length    = self._make_double_spinbox(5.0,  20.0,  8.0, " nm")
            self._head_prec     = self._make_double_spinbox(0.85,  1.0, 0.97, "")

            for i, (lbl, widget) in enumerate([
                ("Track pitch", self._track_spacing),
                ("Bit length",  self._bit_length),
                ("Head prec.",  self._head_prec),
            ]):
                geom_layout.addWidget(QLabel(lbl), i, 0)
                geom_layout.addWidget(widget,       i, 1)
            layout.addWidget(geom_group)

            # Simulation control
            sim_group = QGroupBox("SIMULATION CONTROL")
            sim_layout = QGridLayout(sim_group)

            self._n_cycles = QSpinBox()
            self._n_cycles.setRange(1000, 500_000)
            self._n_cycles.setValue(10_000)
            self._n_cycles.setSingleStep(1000)
            self._n_cycles.setSuffix("  cycles")

            self._seed_box = QSpinBox()
            self._seed_box.setRange(0, 99999)
            self._seed_box.setValue(42)

            sim_layout.addWidget(QLabel("Cycles"),   0, 0)
            sim_layout.addWidget(self._n_cycles,      0, 1)
            sim_layout.addWidget(QLabel("RNG seed"),  1, 0)
            sim_layout.addWidget(self._seed_box,      1, 1)
            layout.addWidget(sim_group)

            layout.addStretch()

            # Run / Stop buttons
            btn_layout = QHBoxLayout()
            self._run_btn  = QPushButton("▶  RUN SIMULATION")
            self._run_btn.setObjectName("run_btn")
            self._stop_btn = QPushButton("■  STOP")
            self._stop_btn.setEnabled(False)
            self._run_btn.clicked.connect(self._on_run)
            self._stop_btn.clicked.connect(self._on_stop)
            btn_layout.addWidget(self._run_btn)
            btn_layout.addWidget(self._stop_btn)
            layout.addLayout(btn_layout)

            return w

        # ── CENTRE PANEL (log + progress) ─────────────────────────────────────

        def _build_centre_panel(self) -> QWidget:
            w      = QWidget()
            layout = QVBoxLayout(w)
            layout.setContentsMargins(4, 0, 4, 0)
            layout.setSpacing(4)

            tabs = QTabWidget()

            # Tab 1: Simulation log
            log_tab = QWidget()
            log_layout = QVBoxLayout(log_tab)
            self._log_text = QTextEdit()
            self._log_text.setReadOnly(True)
            self._log_text.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
            log_layout.addWidget(self._log_text)
            tabs.addTab(log_tab, "SIMULATION LOG")

            # Tab 2: Results
            results_tab = QWidget()
            results_layout = QVBoxLayout(results_tab)
            self._results_text = QTextEdit()
            self._results_text.setReadOnly(True)
            results_layout.addWidget(self._results_text)
            tabs.addTab(results_tab, "RESULTS")

            layout.addWidget(tabs, stretch=1)

            # Progress bar
            prog_layout = QHBoxLayout()
            prog_label  = QLabel("PROGRESS")
            prog_label.setStyleSheet("color: #404040; font-size: 10px; letter-spacing: 1px;")
            self._progress_bar  = QProgressBar()
            self._progress_bar.setValue(0)
            self._progress_label = QLabel("—")
            self._progress_label.setStyleSheet("color: #505050; font-size: 10px;")
            prog_layout.addWidget(prog_label)
            prog_layout.addWidget(self._progress_bar, stretch=1)
            prog_layout.addWidget(self._progress_label)
            layout.addLayout(prog_layout)

            return w

        # ── RIGHT PANEL (live metrics) ────────────────────────────────────────

        def _build_right_panel(self) -> QWidget:
            w      = QScrollArea()
            w.setWidgetResizable(True)
            w.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

            inner = QWidget()
            layout = QVBoxLayout(inner)
            layout.setContentsMargins(4, 0, 0, 0)
            layout.setSpacing(4)

            header = QLabel("LIVE METRICS")
            header.setStyleSheet(
                "color: #404040; font-size: 9px; letter-spacing: 3px; "
                "padding: 4px 0; border-bottom: 1px solid #1a1a1a;"
            )
            layout.addWidget(header)

            self._metric_widgets: dict[str, MetricWidget] = {}

            metrics_defs = [
                ("density",   "AREAL DENSITY",    "Tb/in²"),
                ("ber",       "POST-ECC BER",      ""),
                ("write_sr",  "WRITE SUCCESS",     "%"),
                ("temp_k",    "PEAK TEMP",         "K"),
                ("health",    "MEDIUM HEALTH",     "[0-1]"),
                ("fom",       "FIGURE OF MERIT",   "[0-1]"),
                ("energy",    "ENERGY / WRITE",    "fJ"),
                ("lifetime",  "EST. LIFETIME",     "cycles"),
            ]

            for key, label, unit in metrics_defs:
                mw = MetricWidget(label, "—", unit)
                self._metric_widgets[key] = mw
                layout.addWidget(mw)

            layout.addStretch()
            w.setWidget(inner)
            return w

        # ── HELPERS ───────────────────────────────────────────────────────────

        def _make_double_spinbox(self, lo: float, hi: float,
                                  val: float, suffix: str = "") -> QDoubleSpinBox:
            sb = QDoubleSpinBox()
            sb.setRange(lo, hi)
            sb.setValue(val)
            sb.setDecimals(3 if hi - lo < 2 else 2)
            if suffix:
                sb.setSuffix(suffix)
            return sb

        def _build_config(self) -> HAMRConfig:
            medium_key = self._medium_combo.currentData()
            cfg        = HAMRConfig.from_medium(medium_key)

            cfg.laser.power_mw              = self._laser_power.value()
            cfg.laser.pulse_duration_ns     = self._pulse_dur.value()
            cfg.laser.spot_radius_nm        = self._spot_radius.value()
            cfg.laser.nft_efficiency        = self._nft_eff.value()
            cfg.density.track_spacing_nm    = self._track_spacing.value()
            cfg.density.bit_length_nm       = self._bit_length.value()
            cfg.head.precision              = self._head_prec.value()
            cfg.simulation.n_cycles         = self._n_cycles.value()
            cfg.simulation.seed             = self._seed_box.value()
            cfg.simulation.verbose          = False

            return cfg

        # ── ACTIONS ───────────────────────────────────────────────────────────

        def _on_run(self) -> None:
            cfg = self._build_config()
            self._log_text.clear()
            self._results_text.clear()
            self._progress_bar.setValue(0)

            self._log(f"[HAMR-X] Initialising simulation")
            self._log(f"  Medium    : {cfg.medium.name}")
            self._log(f"  Laser     : {cfg.laser.power_mw:.1f} mW, "
                       f"r0={cfg.laser.spot_radius_nm:.1f} nm")
            self._log(f"  Geometry  : track={cfg.density.track_spacing_nm:.1f} nm, "
                       f"bit={cfg.density.bit_length_nm:.1f} nm")
            self._log(f"  Cycles    : {cfg.simulation.n_cycles:,}")
            self._log(f"{'─' * 60}")

            self._worker = SimulationWorker(cfg)
            self._worker.progress_signal.connect(self._on_progress)
            self._worker.metrics_signal.connect(self._on_metrics)
            self._worker.complete_signal.connect(self._on_complete)
            self._worker.error_signal.connect(self._on_error)
            self._worker.start()

            self._run_btn.setEnabled(False)
            self._stop_btn.setEnabled(True)
            self._set_status("RUNNING", "#00d4e0")

        def _on_stop(self) -> None:
            if self._worker:
                self._worker.abort()
            self._run_btn.setEnabled(True)
            self._stop_btn.setEnabled(False)
            self._set_status("ABORTED", "#e05252")
            self._log("[HAMR-X] Simulation aborted by user")

        def _on_progress(self, pct: int, msg: str) -> None:
            self._progress_bar.setValue(pct)
            self._progress_label.setText(f"{pct}%")
            self._log(f"  {msg}")

        def _on_metrics(self, m: dict) -> None:
            self._metric_widgets["density"].set_value(f"{m.get('density', 0):.4f}")
            ber = m.get("ber", 1.0)
            self._metric_widgets["ber"].set_value(f"{ber:.3e}")
            self._metric_widgets["write_sr"].set_value(
                f"{m.get('write_sr', 0) * 100:.2f}")
            self._metric_widgets["temp_k"].set_value(f"{m.get('temp_k', 0):.1f}")

        def _on_complete(self, result) -> None:
            self._result = result
            m = result.final_metrics

            self._metric_widgets["density"].set_value(f"{m.areal_density_tbpin2:.4f}")
            self._metric_widgets["ber"].set_value(f"{m.post_ecc_ber:.3e}")
            self._metric_widgets["write_sr"].set_value(f"{m.write_success_rate * 100:.2f}")
            self._metric_widgets["temp_k"].set_value(f"{m.peak_temperature_k:.1f}")
            self._metric_widgets["health"].set_value(f"{m.degradation_health:.4f}")
            self._metric_widgets["fom"].set_value(f"{m.figure_of_merit:.6f}")
            self._metric_widgets["energy"].set_value(f"{m.energy_per_write_fj:.2f}")
            self._metric_widgets["lifetime"].set_value(f"{m.lifetime_cycles:,}")

            self._results_text.setPlainText(result.summary())
            self._log(f"{'─' * 60}")
            self._log(f"[HAMR-X] Simulation complete in {result.elapsed_seconds:.2f}s")
            self._log(f"  FoM     = {m.figure_of_merit:.6f}")
            self._log(f"  Density = {m.areal_density_tbpin2:.4f} Tb/in²")
            self._log(f"  BER     = {m.post_ecc_ber:.3e}")

            self._progress_bar.setValue(100)
            self._progress_label.setText("100%")
            self._run_btn.setEnabled(True)
            self._stop_btn.setEnabled(False)
            self._set_status("COMPLETE", "#52c082")

        def _on_error(self, msg: str) -> None:
            self._log(f"[ERROR] {msg}")
            self._run_btn.setEnabled(True)
            self._stop_btn.setEnabled(False)
            self._set_status("ERROR", "#e05252")

        def _log(self, text: str) -> None:
            self._log_text.append(text)
            self._log_text.moveCursor(QTextCursor.MoveOperation.End)

        def _set_status(self, label: str, colour: str) -> None:
            self._status_dot.setStyleSheet(f"color: {colour}; font-size: 16px;")
            self._status_label.setStyleSheet(
                f"color: {colour}; font-size: 10px; letter-spacing: 2px;"
            )
            self._status_label.setText(label)
            self.statusBar().showMessage(f"HAMR-X CORE  ::  {label}")


# ─────────────────────────────────────────────────────────────────────────────
#  LAUNCH FUNCTION
# ─────────────────────────────────────────────────────────────────────────────

def launch_dashboard() -> None:
    """Launch the HAMR-X PyQt6 dashboard application."""
    if not PYQT6_AVAILABLE:
        _logger.error("PyQt6 is not installed. Install with: pip install PyQt6")
        return

    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("HAMR-X CORE")
    app.setOrganizationName("HAMR Research Platform")

    window = HAMRDashboard()
    window.show()

    sys.exit(app.exec())
