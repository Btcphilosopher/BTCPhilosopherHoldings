"""
HAMR-X CORE :: tests/test_hamr_x.py
======================================
Comprehensive unit and integration test suite for the HAMR-X platform.

Tests cover all core subsystems:
  - Physical models (thermal, magnetic, switching)
  - Storage models (density, error, degradation)
  - Mechanical models (head positioning)
  - Optimisation engines (GA, brute-force)
  - Simulation engine (integration)
  - Metrics engine
"""

from __future__ import annotations
import sys
import os
import unittest
import numpy as np
import math

# Ensure package root is in path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hamr_x.utils.config import (
    HAMRConfig, MediumConfig, LaserConfig, HeadConfig,
    DensityConfig, SimulationConfig, MEDIUM_LIBRARY,
    OptimisationConfig, PhysicalConstants,
)
from hamr_x.physics.magnetic_medium import MagneticMedium, GrainState
from hamr_x.physics.thermal_laser import ThermalLaserModel, ThermalProfile
from hamr_x.physics.switching_model import HAMRSwitchingModel
from hamr_x.mechanical.head_positioning import HeadPositioningModel, VibrationModel
from hamr_x.storage.models import DensityModel, ErrorModel, DegradationModel
from hamr_x.metrics.performance import PerformanceEngine


# ─────────────────────────────────────────────────────────────────────────────
#  FIXTURES
# ─────────────────────────────────────────────────────────────────────────────

def make_default_config() -> HAMRConfig:
    """Return a lightweight config suitable for unit tests."""
    cfg = HAMRConfig.default()
    cfg.simulation.n_cycles  = 500
    cfg.simulation.n_grains  = 50
    cfg.simulation.verbose   = False
    cfg.simulation.seed      = 1337
    return cfg


# ══════════════════════════════════════════════════════════════════════════════
#  TEST: CONFIG
# ══════════════════════════════════════════════════════════════════════════════

class TestHAMRConfig(unittest.TestCase):

    def test_default_config_construction(self):
        cfg = HAMRConfig.default()
        self.assertIsNotNone(cfg.medium)
        self.assertIsNotNone(cfg.laser)
        self.assertIsNotNone(cfg.density)
        self.assertIsNotNone(cfg.head)
        self.assertIsNotNone(cfg.simulation)
        self.assertIsNotNone(cfg.optimisation)

    def test_medium_library_contains_expected_keys(self):
        expected = {"high_density_alloy", "standard_alloy",
                    "ultra_dense_experimental", "low_power_media"}
        self.assertTrue(expected.issubset(set(MEDIUM_LIBRARY.keys())))

    def test_from_medium_factory(self):
        cfg = HAMRConfig.from_medium("ultra_dense_experimental")
        self.assertEqual(cfg.medium.name, "FePtCu Ultra-Dense Experimental")

    def test_from_medium_invalid_raises(self):
        with self.assertRaises(KeyError):
            HAMRConfig.from_medium("nonexistent_medium")

    def test_summary_returns_string(self):
        cfg = HAMRConfig.default()
        s   = cfg.summary()
        self.assertIsInstance(s, str)
        self.assertIn("HAMR-X", s)

    def test_medium_coercivity_positive(self):
        for key, med in MEDIUM_LIBRARY.items():
            self.assertGreater(med.coercivity_oe, 0,
                                f"Coercivity non-positive for {key}")

    def test_medium_curie_above_write_temp(self):
        for key, med in MEDIUM_LIBRARY.items():
            self.assertGreater(med.curie_temp_k, med.write_temp_k,
                                f"Curie ≤ write_temp for {key}")


# ══════════════════════════════════════════════════════════════════════════════
#  TEST: MAGNETIC MEDIUM
# ══════════════════════════════════════════════════════════════════════════════

class TestMagneticMedium(unittest.TestCase):

    def setUp(self):
        self.cfg    = MEDIUM_LIBRARY["high_density_alloy"]
        self.medium = MagneticMedium(self.cfg, n_grains=100, seed=42)

    def test_grain_population_size(self):
        self.assertEqual(len(self.medium.grains), 100)

    def test_grain_diameters_positive(self):
        diameters = self.medium.grain_diameter_distribution()
        self.assertTrue(np.all(diameters > 0))

    def test_grain_coercivities_positive(self):
        coercivities = self.medium.grain_coercivity_distribution()
        self.assertTrue(np.all(coercivities > 0))

    def test_coercivity_at_room_temperature(self):
        hc = self.medium.coercivity_at_temperature(298.15)
        self.assertGreater(hc, 0)
        self.assertLess(hc, self.cfg.coercivity_oe * 1.1)

    def test_coercivity_zero_at_curie(self):
        hc = self.medium.coercivity_at_temperature(self.cfg.curie_temp_k)
        self.assertEqual(hc, 0.0)

    def test_coercivity_monotonically_decreasing(self):
        temps = np.linspace(298.15, self.cfg.curie_temp_k - 1, 20)
        hcs   = [self.medium.coercivity_at_temperature(t) for t in temps]
        for i in range(1, len(hcs)):
            self.assertLessEqual(hcs[i], hcs[i-1] + 1.0,
                                  f"Coercivity not monotone at index {i}")

    def test_thermal_stability_at_room_temp(self):
        delta = self.medium.thermal_stability_factor(298.15)
        self.assertGreater(delta, 0)

    def test_switching_prob_above_curie_is_one(self):
        p = self.medium.switching_probability(
            applied_field_oe=50000.0,
            temperature_k=self.cfg.curie_temp_k + 50,
            pulse_duration_ns=2.0,
        )
        self.assertAlmostEqual(p, 1.0)

    def test_switching_prob_bounds(self):
        for temp in [300.0, 500.0, 700.0]:
            p = self.medium.switching_probability(
                applied_field_oe=10000.0,
                temperature_k=temp,
                pulse_duration_ns=1.5,
            )
            self.assertGreaterEqual(p, 0.0)
            self.assertLessEqual(p, 1.0)

    def test_write_event_returns_expected_keys(self):
        result = self.medium.simulate_write_event(
            applied_field_oe=50000.0,
            temperature_k=580.0,
            pulse_duration_ns=1.5,
            target_direction=1.0,
        )
        for key in ["success", "fraction_aligned", "mean_coercivity"]:
            self.assertIn(key, result)

    def test_degradation_reduces_coercivity(self):
        hc_before = np.mean(self.medium.grain_coercivity_distribution())
        for _ in range(100):
            self.medium.apply_degradation_cycle()
        hc_after = np.mean(self.medium.grain_coercivity_distribution())
        self.assertLess(hc_after, hc_before)

    def test_state_snapshot_structure(self):
        snap = self.medium.state_snapshot()
        for key in ["n_grains", "mean_coercivity_oe", "degradation_factor"]:
            self.assertIn(key, snap)


# ══════════════════════════════════════════════════════════════════════════════
#  TEST: THERMAL LASER MODEL
# ══════════════════════════════════════════════════════════════════════════════

class TestThermalLaserModel(unittest.TestCase):

    def setUp(self):
        self.laser_cfg = LaserConfig(
            power_mw=6.0, spot_radius_nm=25.0, pulse_duration_ns=1.5,
            nft_efficiency=0.85, thermal_diffusivity=4e-6, heat_capacity=3e6,
            cooling_rate_ns=3.0,
        )
        self.laser = ThermalLaserModel(self.laser_cfg, ambient_temp_k=298.15)

    def test_peak_temp_above_ambient(self):
        t_peak = self.laser.peak_temperature_end_of_pulse()
        self.assertGreater(t_peak, 298.15)

    def test_peak_temp_at_zero_time_is_ambient(self):
        t = self.laser.peak_temperature_at_time(0.0)
        self.assertAlmostEqual(t, 298.15, places=1)

    def test_peak_temp_increases_with_power(self):
        powers = np.array([2.0, 4.0, 6.0, 8.0, 10.0])
        temps  = self.laser.power_sweep(powers)
        for i in range(1, len(temps)):
            self.assertGreater(temps[i], temps[i-1])

    def test_temp_decreases_with_radius(self):
        t_pulse = self.laser_cfg.pulse_duration_ns
        t0  = self.laser.temperature_at_radius(0.0,  t_pulse)
        t10 = self.laser.temperature_at_radius(10.0, t_pulse)
        t25 = self.laser.temperature_at_radius(25.0, t_pulse)
        self.assertGreater(t0, t10)
        self.assertGreater(t10, t25)

    def test_cooling_returns_toward_ambient(self):
        t_end = self.laser.temperature_at_radius(0.0, self.laser_cfg.pulse_duration_ns)
        t_cool = self.laser.temperature_after_pulse(0.0, 10.0)
        self.assertLess(t_cool, t_end)
        self.assertGreaterEqual(t_cool, 298.15)

    def test_simulate_pulse_returns_profile(self):
        profile = self.laser.simulate_pulse(580.0, generate_map=False)
        self.assertIsInstance(profile, ThermalProfile)
        self.assertGreater(profile.peak_temperature_k, 0)
        self.assertGreater(profile.energy_delivered_pj, 0)

    def test_simulate_pulse_with_map(self):
        profile = self.laser.simulate_pulse(580.0, generate_map=True)
        self.assertIsNotNone(profile.temperature_map)
        self.assertEqual(profile.temperature_map.ndim, 2)

    def test_effective_radius_positive(self):
        r = self.laser.effective_thermal_radius_nm(self.laser_cfg.pulse_duration_ns)
        self.assertGreater(r, 0)

    def test_state_summary_structure(self):
        s = self.laser.state_summary()
        for key in ["laser_power_mw", "peak_temperature_k", "energy_per_pulse_pj"]:
            self.assertIn(key, s)


# ══════════════════════════════════════════════════════════════════════════════
#  TEST: HEAD POSITIONING MODEL
# ══════════════════════════════════════════════════════════════════════════════

class TestHeadPositioningModel(unittest.TestCase):

    def setUp(self):
        head_cfg = HeadConfig(
            precision=0.97, vibration_amplitude_nm=1.2,
            jitter_sigma_nm=0.8, positional_drift_nm_per_ms=0.005,
        )
        self.head = HeadPositioningModel(head_cfg, track_pitch_nm=30.0, seed=99)

    def test_sample_returns_positional_state(self):
        from hamr_x.mechanical.head_positioning import PositionalState
        state = self.head.sample_position_error()
        self.assertIsInstance(state, PositionalState)

    def test_tmr_non_negative(self):
        for _ in range(50):
            state = self.head.sample_position_error()
            self.assertGreaterEqual(state.tmr_nm, 0.0)

    def test_alignment_factor_bounds(self):
        for _ in range(100):
            state = self.head.sample_position_error()
            self.assertGreaterEqual(state.alignment_factor, 0.0)
            self.assertLessEqual(state.alignment_factor,  1.0)

    def test_batch_sample_length(self):
        states = self.head.sample_batch(50)
        self.assertEqual(len(states), 50)

    def test_tmr_statistics_after_sampling(self):
        self.head.sample_batch(200)
        stats = self.head.tmr_statistics()
        self.assertIn("tmr_mean_nm", stats)
        self.assertGreater(stats["n_samples"], 0)
        self.assertGreater(stats["tmr_mean_nm"], 0.0)

    def test_high_precision_improves_alignment(self):
        head_lo = HeadPositioningModel(
            HeadConfig(precision=0.90, vibration_amplitude_nm=2.0,
                        jitter_sigma_nm=1.5), track_pitch_nm=30.0, seed=1)
        head_hi = HeadPositioningModel(
            HeadConfig(precision=0.99, vibration_amplitude_nm=0.5,
                        jitter_sigma_nm=0.3), track_pitch_nm=30.0, seed=1)
        af_lo = np.mean([head_lo.sample_position_error().alignment_factor
                          for _ in range(200)])
        af_hi = np.mean([head_hi.sample_position_error().alignment_factor
                          for _ in range(200)])
        self.assertGreater(af_hi, af_lo)


# ══════════════════════════════════════════════════════════════════════════════
#  TEST: DENSITY MODEL
# ══════════════════════════════════════════════════════════════════════════════

class TestDensityModel(unittest.TestCase):

    def setUp(self):
        self.density_cfg = DensityConfig(
            track_spacing_nm=30.0, bit_length_nm=8.0,
            guard_band_fraction=0.15,
        )
        self.model = DensityModel(self.density_cfg, tmr_3sigma_nm=2.5)

    def test_compute_density_positive(self):
        result = self.model.compute_density()
        self.assertGreater(result.areal_density_tbpin2, 0)

    def test_density_increases_with_tighter_geometry(self):
        self.density_cfg.track_spacing_nm = 30.0
        self.density_cfg.bit_length_nm    = 8.0
        d_coarse = self.model.compute_density().areal_density_tbpin2

        self.density_cfg.track_spacing_nm = 15.0
        self.density_cfg.bit_length_nm    = 5.0
        d_fine = self.model.compute_density().areal_density_tbpin2

        self.assertGreater(d_fine, d_coarse)
        # Reset
        self.density_cfg.track_spacing_nm = 30.0
        self.density_cfg.bit_length_nm    = 8.0

    def test_density_vs_track_spacing_monotone(self):
        spacings = np.linspace(15.0, 60.0, 10)
        densities = self.model.density_vs_track_spacing(spacings)
        for i in range(1, len(densities)):
            self.assertLessEqual(densities[i], densities[i-1] + 0.01)

    def test_track_density_in_physical_range(self):
        result = self.model.compute_density()
        # Realistic range: 100k to 10M TPI
        self.assertGreater(result.track_density_tpi, 1e5)
        self.assertLess(result.track_density_tpi, 1e7)


# ══════════════════════════════════════════════════════════════════════════════
#  TEST: ERROR MODEL
# ══════════════════════════════════════════════════════════════════════════════

class TestErrorModel(unittest.TestCase):

    def setUp(self):
        self.cfg   = make_default_config()
        self.model = ErrorModel(self.cfg, seed=42)

    def test_raw_ber_bounds(self):
        for ws, aq, tm in [(0.99, 0.98, 0.01), (0.80, 0.85, 0.05),
                            (0.50, 0.70, 0.10)]:
            ber = self.model.compute_raw_ber(ws, aq, tm)
            self.assertGreaterEqual(ber, 0.0)
            self.assertLessEqual(ber, 1.0)

    def test_ecc_reduces_ber(self):
        raw_ber  = 0.05
        post_ber = self.model.apply_ecc_correction(raw_ber)
        self.assertLess(post_ber, raw_ber)

    def test_higher_write_success_lower_ber(self):
        ber_lo = self.model.compute_raw_ber(0.80, 0.90, 0.05)
        ber_hi = self.model.compute_raw_ber(0.99, 0.99, 0.01)
        self.assertLess(ber_hi, ber_lo)

    def test_error_budget_returns_budget(self):
        from hamr_x.storage.models import ErrorBudget
        budget = self.model.compute_error_budget(0.98, 0.97, 0.01, 0.005)
        self.assertIsInstance(budget, ErrorBudget)
        self.assertGreaterEqual(budget.reliability_score, 0.0)
        self.assertLessEqual(budget.reliability_score,    1.0)

    def test_ber_vs_density_increases_with_density(self):
        densities = np.array([2.0, 4.0, 6.0, 8.0, 10.0])
        bers      = self.model.ber_vs_density(densities)
        # BER should generally increase with density
        self.assertGreater(bers[-1], bers[0])


# ══════════════════════════════════════════════════════════════════════════════
#  TEST: DEGRADATION MODEL
# ══════════════════════════════════════════════════════════════════════════════

class TestDegradationModel(unittest.TestCase):

    def setUp(self):
        self.cfg   = make_default_config()
        self.model = DegradationModel(self.cfg)

    def test_initial_state_pristine(self):
        state = self.model.get_current_state()
        self.assertEqual(state.cycle_count, 0)
        self.assertAlmostEqual(state.coercivity_factor, 1.0)
        self.assertAlmostEqual(state.health_score, 1.0, places=1)
        self.assertEqual(state.degradation_stage, "PRISTINE")

    def test_health_decreases_with_cycles(self):
        state0 = self.model.get_current_state()
        self.model.step(100_000)
        state1 = self.model.get_current_state()
        self.assertLess(state1.health_score, state0.health_score)

    def test_coercivity_factor_bounded(self):
        self.model.step(1_000_000)
        state = self.model.get_current_state()
        self.assertGreaterEqual(state.coercivity_factor, 0.0)
        self.assertLessEqual(state.coercivity_factor,    1.0)

    def test_degradation_stages_progression(self):
        stages_seen = set()
        for n in [0, 50_000, 200_000, 500_000]:
            self.model._cycle_count = 0  # reset for this test
            self.model.step(n)
            state = self.model.get_current_state()
            stages_seen.add(state.degradation_stage)
        # At some cycle count we should see non-pristine stages
        self.assertGreater(len(stages_seen), 1)

    def test_degradation_curve_shape(self):
        cycles, coer, health = self.model.degradation_curve()
        self.assertEqual(len(cycles), len(coer))
        self.assertEqual(len(cycles), len(health))
        self.assertGreater(coer[0], coer[-1])     # coercivity decreases

    def test_lifetime_estimate_positive(self):
        lt = self.model.lifetime_estimate_cycles()
        self.assertGreater(lt, 0)


# ══════════════════════════════════════════════════════════════════════════════
#  TEST: PERFORMANCE ENGINE
# ══════════════════════════════════════════════════════════════════════════════

class TestPerformanceEngine(unittest.TestCase):

    def setUp(self):
        self.cfg    = make_default_config()
        self.engine = PerformanceEngine(self.cfg, ber_target=1e-6,
                                         density_target=4.0)

    def test_fom_bounds(self):
        fom = self.engine.compute_figure_of_merit(
            density_tbpin2=5.0, reliability=0.9,
            energy_per_write_fj=50.0, lifetime_cycles=500_000,
        )
        self.assertGreaterEqual(fom, 0.0)
        self.assertLessEqual(fom,    1.0)

    def test_higher_density_better_fom(self):
        fom_lo = self.engine.compute_figure_of_merit(2.0, 0.9, 50.0, 500_000)
        fom_hi = self.engine.compute_figure_of_merit(8.0, 0.9, 50.0, 500_000)
        self.assertGreater(fom_hi, fom_lo)

    def test_compute_metrics_returns_object(self):
        from hamr_x.metrics.performance import PerformanceMetrics
        m = self.engine.compute_metrics(
            cycle_number=1000, areal_density_tbpin2=4.5,
            raw_ber=1e-4, post_ecc_ber=1e-8,
            write_success_rate=0.99, read_success_rate=0.999,
            energy_per_pulse_pj=0.05, lifetime_cycles=1_000_000,
            reliability_score=0.92, peak_temperature_k=590.0,
            thermal_misfire_rate=0.002, alignment_quality=0.97,
            degradation_health=0.98,
        )
        self.assertIsInstance(m, PerformanceMetrics)
        self.assertGreater(m.figure_of_merit, 0.0)

    def test_metrics_history_accumulates(self):
        for i in range(5):
            self.engine.compute_metrics(
                cycle_number=i*100, areal_density_tbpin2=4.0+i*0.1,
                raw_ber=1e-4, post_ecc_ber=1e-8,
                write_success_rate=0.98, read_success_rate=0.999,
                energy_per_pulse_pj=0.05, lifetime_cycles=1_000_000,
                reliability_score=0.9, peak_temperature_k=580.0,
                thermal_misfire_rate=0.0, alignment_quality=0.97,
                degradation_health=0.99,
            )
        self.assertEqual(len(self.engine._history), 5)

    def test_summary_statistics(self):
        self.engine.compute_metrics(
            cycle_number=0, areal_density_tbpin2=4.5,
            raw_ber=1e-4, post_ecc_ber=1e-8,
            write_success_rate=0.99, read_success_rate=0.999,
            energy_per_pulse_pj=0.05, lifetime_cycles=1_000_000,
            reliability_score=0.92, peak_temperature_k=590.0,
            thermal_misfire_rate=0.0, alignment_quality=0.97,
            degradation_health=0.98,
        )
        s = self.engine.summary_statistics()
        self.assertIn("mean_density_tbpin2", s)
        self.assertGreater(s["n_snapshots"], 0)


# ══════════════════════════════════════════════════════════════════════════════
#  TEST: SWITCHING MODEL
# ══════════════════════════════════════════════════════════════════════════════

class TestSwitchingModel(unittest.TestCase):

    def setUp(self):
        cfg    = make_default_config()
        medium = MagneticMedium(cfg.medium, n_grains=50, seed=42)
        laser  = ThermalLaserModel(cfg.laser)
        self.switcher = HAMRSwitchingModel(cfg, medium, laser, seed=42)

    def test_write_returns_result(self):
        from hamr_x.physics.switching_model import WriteEventResult
        result = self.switcher.execute_write(target_direction=1.0,
                                               alignment_factor=1.0)
        self.assertIsInstance(result, WriteEventResult)

    def test_write_result_bounds(self):
        result = self.switcher.execute_write()
        self.assertIn(result.error_type,
                       [None, "thermal", "field", "timing", "alignment"])
        self.assertGreaterEqual(result.fraction_aligned, 0.0)
        self.assertLessEqual(result.fraction_aligned, 1.0)

    def test_batch_write_returns_dict(self):
        batch = self.switcher.simulate_write_batch(n_writes=20)
        for key in ["write_success_rate", "mean_peak_temp_k",
                     "mean_energy_pj", "total_failures"]:
            self.assertIn(key, batch)

    def test_write_success_rate_bounds(self):
        batch = self.switcher.simulate_write_batch(n_writes=50)
        self.assertGreaterEqual(batch["write_success_rate"], 0.0)
        self.assertLessEqual(batch["write_success_rate"],    1.0)

    def test_read_success_is_bool(self):
        result = self.switcher.simulate_read(snr_db=25.0)
        self.assertIn("success", result)
        self.assertIsInstance(result["success"], bool)

    def test_adj_track_erasure_zero_far_away(self):
        prob = self.switcher.adjacent_track_erasure_probability(500.0)
        self.assertAlmostEqual(prob, 0.0)


# ══════════════════════════════════════════════════════════════════════════════
#  INTEGRATION TEST: SIMULATION ENGINE
# ══════════════════════════════════════════════════════════════════════════════

class TestSimulationEngine(unittest.TestCase):

    def setUp(self):
        self.cfg = make_default_config()
        self.cfg.simulation.n_cycles = 200
        self.cfg.simulation.n_grains = 30

    def test_engine_runs_and_returns_result(self):
        from hamr_x.core.simulation_engine import SimulationEngine, SimulationResult
        engine = SimulationEngine(self.cfg)
        result = engine.run()
        self.assertIsInstance(result, SimulationResult)

    def test_result_has_final_metrics(self):
        from hamr_x.core.simulation_engine import SimulationEngine
        engine = SimulationEngine(self.cfg)
        result = engine.run()
        self.assertIsNotNone(result.final_metrics)
        self.assertGreater(result.final_metrics.areal_density_tbpin2, 0)

    def test_result_run_id_is_string(self):
        from hamr_x.core.simulation_engine import SimulationEngine
        engine = SimulationEngine(self.cfg)
        result = engine.run()
        self.assertIsInstance(result.run_id, str)
        self.assertGreater(len(result.run_id), 0)

    def test_deterministic_with_same_seed(self):
        from hamr_x.core.simulation_engine import SimulationEngine
        r1 = SimulationEngine(make_default_config()).run()
        r2 = SimulationEngine(make_default_config()).run()
        self.assertAlmostEqual(
            r1.final_metrics.figure_of_merit,
            r2.final_metrics.figure_of_merit,
            places=4
        )

    def test_different_seeds_give_different_results(self):
        from hamr_x.core.simulation_engine import SimulationEngine
        cfg1 = make_default_config(); cfg1.simulation.seed = 1
        cfg2 = make_default_config(); cfg2.simulation.seed = 9999
        r1 = SimulationEngine(cfg1).run()
        r2 = SimulationEngine(cfg2).run()
        # Not guaranteed to differ significantly, but FoM usually changes
        # Just check both complete successfully
        self.assertIsNotNone(r1.final_metrics)
        self.assertIsNotNone(r2.final_metrics)

    def test_result_summary_is_string(self):
        from hamr_x.core.simulation_engine import SimulationEngine
        engine = SimulationEngine(self.cfg)
        result = engine.run()
        s = result.summary()
        self.assertIsInstance(s, str)
        self.assertIn("HAMR-X", s)

    def test_run_hamr_simulation_convenience(self):
        from hamr_x.core.simulation_engine import run_hamr_simulation
        result = run_hamr_simulation(
            laser_power=6.0, track_spacing=30.0,
            medium_type="standard_alloy", simulation_cycles=200,
        )
        self.assertIsNotNone(result)
        self.assertGreater(result.n_write_ops, 0)


# ══════════════════════════════════════════════════════════════════════════════
#  TEST: PHYSICAL CONSTANTS
# ══════════════════════════════════════════════════════════════════════════════

class TestPhysicalConstants(unittest.TestCase):

    def test_boltzmann_correct(self):
        self.assertAlmostEqual(
            PhysicalConstants.BOLTZMANN_K, 1.380649e-23, places=30
        )

    def test_room_temperature_correct(self):
        self.assertAlmostEqual(
            PhysicalConstants.ROOM_TEMPERATURE, 298.15, places=2
        )

    def test_curie_temps_positive(self):
        self.assertGreater(PhysicalConstants.CURIE_TEMP_FEPT, 0)
        self.assertGreater(PhysicalConstants.CURIE_TEMP_SMCO, 0)


# ─────────────────────────────────────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    loader  = unittest.TestLoader()
    suite   = loader.loadTestsFromModule(sys.modules[__name__])
    runner  = unittest.TextTestRunner(verbosity=2)
    result  = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
