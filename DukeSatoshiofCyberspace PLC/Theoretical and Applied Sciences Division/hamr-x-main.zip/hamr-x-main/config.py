"""
HAMR-X CORE :: utils/config.py
================================
Central configuration registry for the Heat-Assisted Magnetic Recording
eXperimental Optimisation Engine (HAMR-X).

All physical constants, default simulation parameters, and system-level
configuration flags are defined here. Modules import from this file to
ensure consistency across the entire simulation platform.

Physical units used throughout:
  - Temperature : Kelvin (K)
  - Time        : nanoseconds (ns)
  - Length      : nanometres (nm)
  - Magnetic    : Oersteds (Oe) for coercivity; Tesla (T) for field
  - Power       : milliwatts (mW)
  - Density     : Tb/in² (terabits per square inch)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
import numpy as np


# ─────────────────────────────────────────────────────────────────────────────
#  PHYSICAL CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────

class PhysicalConstants:
    """Fundamental physical constants used in HAMR physics models."""
    BOLTZMANN_K: float = 1.380649e-23      # J/K
    MU_0: float        = 1.2566370614e-6   # H/m  (vacuum permeability)
    ROOM_TEMPERATURE: float = 298.15       # K
    CURIE_TEMP_FEPT: float  = 750.0        # K  — FePt L10 alloy Curie temperature
    CURIE_TEMP_SMCO: float  = 1000.0       # K  — SmCo alloy Curie temperature


# ─────────────────────────────────────────────────────────────────────────────
#  MAGNETIC MEDIUM CONFIGURATIONS
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class MediumConfig:
    """
    Physical parameters describing a HAMR recording medium.

    Attributes
    ----------
    name              : Human-readable medium identifier
    coercivity_oe     : Room-temperature coercivity in Oersteds
    grain_diameter_nm : Mean magnetic grain diameter (nm)
    grain_sigma_nm    : Standard deviation of grain diameter distribution (nm)
    ku_density        : Uniaxial anisotropy energy density (J/m³)
    curie_temp_k      : Curie temperature (K)
    thermal_stability : KuV/kT ratio at room temperature (>40 for stable)
    write_temp_k      : Target write temperature (K) — where coercivity drops
    saturation_mag    : Saturation magnetisation (A/m)
    degradation_rate  : Fractional coercivity loss per 1000 write cycles
    """
    name:               str
    coercivity_oe:      float   = 30_000.0
    grain_diameter_nm:  float   = 7.0
    grain_sigma_nm:     float   = 0.7
    ku_density:         float   = 7.0e6       # J/m³
    curie_temp_k:       float   = 750.0
    thermal_stability:  float   = 60.0
    write_temp_k:       float   = 600.0
    saturation_mag:     float   = 1.0e6       # A/m
    degradation_rate:   float   = 1.5e-5      # fraction per write cycle


MEDIUM_LIBRARY: dict[str, MediumConfig] = {
    "high_density_alloy": MediumConfig(
        name="FePt L10 High-Density Alloy",
        coercivity_oe=30_000.0,
        grain_diameter_nm=6.5,
        grain_sigma_nm=0.6,
        ku_density=7.0e6,
        curie_temp_k=750.0,
        thermal_stability=65.0,
        write_temp_k=480.0,      # achievable at ~8 mW default
        saturation_mag=1.1e6,
        degradation_rate=1.2e-5,
    ),
    "standard_alloy": MediumConfig(
        name="CoCrPt Standard Recording Alloy",
        coercivity_oe=18_000.0,
        grain_diameter_nm=8.5,
        grain_sigma_nm=0.9,
        ku_density=3.5e6,
        curie_temp_k=680.0,
        thermal_stability=45.0,
        write_temp_k=420.0,      # achievable at ~6 mW
        saturation_mag=0.85e6,
        degradation_rate=2.1e-5,
    ),
    "ultra_dense_experimental": MediumConfig(
        name="FePtCu Ultra-Dense Experimental",
        coercivity_oe=40_000.0,
        grain_diameter_nm=4.5,
        grain_sigma_nm=0.4,
        ku_density=9.5e6,
        curie_temp_k=780.0,
        thermal_stability=80.0,
        write_temp_k=540.0,      # needs higher power (~11 mW)
        saturation_mag=1.25e6,
        degradation_rate=0.8e-5,
    ),
    "low_power_media": MediumConfig(
        name="SmCo Low-Power Media",
        coercivity_oe=22_000.0,
        grain_diameter_nm=9.0,
        grain_sigma_nm=1.0,
        ku_density=4.8e6,
        curie_temp_k=1000.0,
        thermal_stability=50.0,
        write_temp_k=460.0,      # achievable at standard power
        saturation_mag=0.9e6,
        degradation_rate=1.8e-5,
    ),
}


# ─────────────────────────────────────────────────────────────────────────────
#  LASER / THERMAL SYSTEM CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LaserConfig:
    """
    Laser heating system parameters.

    Attributes
    ----------
    power_mw          : Laser output power (milliwatts)
    spot_radius_nm    : 1/e² beam radius on medium surface (nm)
    pulse_duration_ns : Heating pulse width (nanoseconds)
    wavelength_nm     : Laser wavelength (nm) — affects NFT coupling
    nft_efficiency    : Near-field transducer energy coupling efficiency [0,1]
    thermal_diffusivity : Medium thermal diffusivity (m²/s)
    heat_capacity     : Volumetric heat capacity of medium (J/m³·K)
    cooling_rate_ns   : Time constant for thermal decay (ns)
    """
    power_mw:           float = 8.0
    spot_radius_nm:     float = 25.0
    pulse_duration_ns:  float = 1.5
    wavelength_nm:      float = 780.0
    nft_efficiency:     float = 0.85
    thermal_diffusivity:float = 4.0e-6     # m²/s
    heat_capacity:      float = 3.0e6      # J/(m³·K)
    cooling_rate_ns:    float = 3.0


# ─────────────────────────────────────────────────────────────────────────────
#  HEAD POSITIONING SYSTEM CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class HeadConfig:
    """
    Read/write head mechanical and positional parameters.

    Attributes
    ----------
    precision            : Baseline track-follow precision [0,1]
    vibration_amplitude_nm: Peak vibration amplitude (nm)
    jitter_sigma_nm      : RMS track-follow jitter (nm)
    positional_drift_nm_per_ms: Linear positional drift rate (nm/ms)
    fly_height_nm        : Head-media spacing (nm)
    write_field_gradient : Write field gradient (Oe/nm)
    """
    precision:                  float = 0.97
    vibration_amplitude_nm:     float = 1.2
    jitter_sigma_nm:            float = 0.8
    positional_drift_nm_per_ms: float = 0.005
    fly_height_nm:              float = 2.5
    write_field_gradient:       float = 800.0    # Oe/nm


# ─────────────────────────────────────────────────────────────────────────────
#  STORAGE DENSITY CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class DensityConfig:
    """
    Storage density and track geometry parameters.

    Attributes
    ----------
    track_spacing_nm      : Centre-to-centre track pitch (nm)
    bit_length_nm         : Along-track bit cell length (nm)
    guard_band_fraction   : Fraction of track pitch reserved for guard band
    bits_per_sector       : Bits per logical sector
    sectors_per_track     : Sectors per physical track
    read_channel_snr_db   : Read channel SNR threshold (dB)
    """
    track_spacing_nm:      float = 30.0
    bit_length_nm:         float = 8.0
    guard_band_fraction:   float = 0.15
    bits_per_sector:       int   = 4096
    sectors_per_track:     int   = 256
    read_channel_snr_db:   float = 22.0


# ─────────────────────────────────────────────────────────────────────────────
#  SIMULATION ENGINE CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class SimulationConfig:
    """
    Top-level simulation control parameters.

    Attributes
    ----------
    seed              : RNG seed for reproducible simulations
    n_cycles          : Number of write/read cycles to simulate
    n_grains          : Number of magnetic grains to model per simulation cell
    dt_ns             : Simulation time step (nanoseconds)
    temperature_k     : Ambient temperature (Kelvin)
    enable_degradation: Enable lifecycle degradation model
    enable_vibration  : Enable mechanical vibration model
    batch_size        : Number of write ops per simulation batch
    verbose           : Enable detailed logging output
    """
    seed:               int   = 42
    n_cycles:           int   = 10_000
    n_grains:           int   = 500
    dt_ns:              float = 0.5
    temperature_k:      float = 298.15
    enable_degradation: bool  = True
    enable_vibration:   bool  = True
    batch_size:         int   = 100
    verbose:            bool  = False


# ─────────────────────────────────────────────────────────────────────────────
#  OPTIMISATION ENGINE CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class OptimisationConfig:
    """
    Genetic algorithm and Bayesian optimisation parameters.

    Attributes
    ----------
    population_size      : GA population (individuals per generation)
    n_generations        : Number of GA generations to evolve
    mutation_rate        : Probability of parameter mutation per gene
    crossover_rate       : Probability of crossover between parents
    elite_fraction       : Fraction of top individuals preserved as elites
    ber_target           : Maximum acceptable Bit Error Rate
    min_density_tbpin2   : Minimum acceptable storage density (Tb/in²)
    bayesian_n_iter      : Number of Bayesian optimisation iterations
    bayesian_n_init      : Random initial samples for Bayesian opt
    """
    population_size:      int   = 80
    n_generations:        int   = 50
    mutation_rate:        float = 0.12
    crossover_rate:       float = 0.75
    elite_fraction:       float = 0.10
    ber_target:           float = 1e-6
    min_density_tbpin2:   float = 4.0
    bayesian_n_iter:      int   = 50
    bayesian_n_init:      int   = 10


# ─────────────────────────────────────────────────────────────────────────────
#  MASTER CONFIGURATION BUNDLE
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class HAMRConfig:
    """
    Composite configuration object passed to the simulation engine.
    Aggregates all sub-system configurations.
    """
    simulation:    SimulationConfig    = field(default_factory=SimulationConfig)
    medium:        MediumConfig        = field(default_factory=lambda: MEDIUM_LIBRARY["high_density_alloy"])
    laser:         LaserConfig         = field(default_factory=LaserConfig)
    head:          HeadConfig          = field(default_factory=HeadConfig)
    density:       DensityConfig       = field(default_factory=DensityConfig)
    optimisation:  OptimisationConfig  = field(default_factory=OptimisationConfig)

    @classmethod
    def default(cls) -> "HAMRConfig":
        """Return a default HAMR-X system configuration."""
        return cls()

    @classmethod
    def from_medium(cls, medium_key: str) -> "HAMRConfig":
        """Create config with specified medium from library."""
        if medium_key not in MEDIUM_LIBRARY:
            raise KeyError(f"Unknown medium '{medium_key}'. "
                           f"Available: {list(MEDIUM_LIBRARY.keys())}")
        cfg = cls()
        cfg.medium = MEDIUM_LIBRARY[medium_key]
        return cfg

    def summary(self) -> str:
        """Return a formatted configuration summary string."""
        lines = [
            "══════════════════════════════════════════════════",
            "  HAMR-X CORE  ::  System Configuration Summary  ",
            "══════════════════════════════════════════════════",
            f"  Medium        : {self.medium.name}",
            f"  Coercivity    : {self.medium.coercivity_oe:,.0f} Oe",
            f"  Grain Size    : {self.medium.grain_diameter_nm:.1f} ± {self.medium.grain_sigma_nm:.1f} nm",
            f"  Curie Temp    : {self.medium.curie_temp_k:.0f} K",
            f"  Write Temp    : {self.medium.write_temp_k:.0f} K",
            f"  Laser Power   : {self.laser.power_mw:.1f} mW",
            f"  Spot Radius   : {self.laser.spot_radius_nm:.1f} nm",
            f"  Track Spacing : {self.density.track_spacing_nm:.1f} nm",
            f"  Bit Length    : {self.density.bit_length_nm:.1f} nm",
            f"  Head Precision: {self.head.precision:.3f}",
            f"  Sim Cycles    : {self.simulation.n_cycles:,}",
            f"  RNG Seed      : {self.simulation.seed}",
            "══════════════════════════════════════════════════",
        ]
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
#  OPTIMISATION PARAMETER BOUNDS
# ─────────────────────────────────────────────────────────────────────────────

OPTIMISATION_BOUNDS: dict[str, tuple[float, float]] = {
    "laser_power_mw":         (1.0,   15.0),
    "pulse_duration_ns":      (0.5,    5.0),
    "spot_radius_nm":         (15.0,  50.0),
    "track_spacing_nm":       (15.0,  60.0),
    "bit_length_nm":          (5.0,   20.0),
    "head_precision":         (0.85,   1.0),
    "write_temp_k":           (400.0, 700.0),
    "nft_efficiency":         (0.60,   1.0),
}


# ─────────────────────────────────────────────────────────────────────────────
#  OUTPUT / LOGGING CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────

LOG_FORMAT: str = "[%(asctime)s] %(levelname)-8s :: %(name)s :: %(message)s"
LOG_DATE_FORMAT: str = "%Y-%m-%d %H:%M:%S"
DEFAULT_OUTPUT_DIR: str = "hamr_x_output"
RESULTS_DB_NAME: str = "hamr_x_results.db"
