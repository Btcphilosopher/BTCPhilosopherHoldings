# HAMR-X CORE
## Heat-Assisted Magnetic Recording eXperimental Optimisation Engine

```
  ██╗  ██╗ █████╗ ███╗   ███╗██████╗      ██╗  ██╗
  ██║  ██║██╔══██╗████╗ ████║██╔══██╗     ╚██╗██╔╝
  ███████║███████║██╔████╔██║██████╔╝      ╚███╔╝
  ██╔══██║██╔══██║██║╚██╔╝██║██╔══██╗      ██╔██╗
  ██║  ██║██║  ██║██║ ╚═╝ ██║██║  ██║     ██╔╝ ██╗
  ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝    ╚═╝  ╚═╝
  Version 1.0.0  ::  Research-Grade HAMR Simulation Platform
```

---

## Overview

HAMR-X CORE is a production-grade Python simulation and optimisation platform for **Heat-Assisted Magnetic Recording (HAMR)** systems. It models the complete write/read physics stack, from laser heating and magnetic grain switching through to system-level storage density trade-offs and lifecycle degradation.

**Not** a low-level molecular dynamics solver. **Is** a system-level engineering platform for R&D exploration of storage density limits, thermal-magnetic interaction constraints, and reliability modelling.

---

## System Architecture

```
hamr_x/
├── core/
│   └── simulation_engine.py    Master timestep loop + evaluate_fn interface
├── physics/
│   ├── magnetic_medium.py      Grain ensemble, coercivity, Néel-Brown switching
│   ├── thermal_laser.py        NFT laser, Gaussian beam, thermal diffusion
│   └── switching_model.py      Integrated write/read process model
├── mechanical/
│   └── head_positioning.py     TMR, servo error, vibration, jitter, drift
├── storage/
│   └── models.py               Density model, Error model, Degradation model
├── optimisation/
│   ├── genetic.py              Real-valued GA with elitism + adaptive mutation
│   └── optimisers.py           Brute-force grid search + Bayesian GP-UCB
├── metrics/
│   └── performance.py          KPI engine, Figure of Merit, history tracking
├── visualization/
│   └── plots.py                8 Plotly charts, Anglo-industrial dark theme
├── gui/
│   └── dashboard.py            PyQt6 3-panel engineering dashboard
├── utils/
│   ├── config.py               All configuration dataclasses + MEDIUM_LIBRARY
│   └── logging.py              Structured colour logging + SimulationJournal
├── tests/
│   └── test_hamr_x.py          50+ unit and integration tests
└── main.py                     CLI entry point
```

---

## Physical Models

### 1 — Magnetic Medium (Néel-Brown)

Grain ensemble drawn from a **log-normal diameter distribution**. Temperature-dependent coercivity via empirical power-law:

```
Hc(T) = Hc(0) · [1 − (T/Tc)^α]^β
```

where α = 1.5, β = 0.5 for FePt L10 alloys.

Thermal stability factor:

```
Δ = Ku·V / (kB·T)     [must exceed 40 for stable storage]
```

Grain switching probability (Néel-Brown relaxation):

```
τ = τ0 · exp(Δ · (1 − H/Hk)²)
P_switch = 1 − exp(−t_write / τ)
```

### 2 — Thermal Laser (NFT Heating)

2D Gaussian diffusion model (thin-film approximation):

```
ΔT(r, t) = P_abs / (ρ·Cp·π·(r0² + 4·D·t)) · exp(−r² / (r0² + 4·D·t))
```

Post-pulse cooling (exponential decay):

```
ΔT(t) = ΔT_peak · exp(−t / τ_cool)
```

### 3 — Write Condition

Write succeeds when ALL conditions are satisfied simultaneously:

| Condition  | Formula                    |
|------------|----------------------------|
| Thermal    | `T_peak ≥ T_write`         |
| Field      | `H_applied ≥ Hc(T_write)` |
| Timing     | `t_write ≥ 0.2 ns`        |
| Alignment  | `rng < alignment_factor`  |

### 4 — Track Mis-Registration (TMR)

RSS combination of all mechanical error sources:

```
TMR = √(σ_servo² + σ_vibration² + σ_jitter² + σ_drift²)
```

Write alignment factor (Gaussian penalty):

```
alignment_factor = exp(−0.5 · (TMR / σ_budget)²)
```

### 5 — Bit Error Rate

```
BER_raw = P_write_fail + P_align_error + P_thermal_misfire + P_channel
BER_ecc ≈ BER_raw^(1 + correction_exponent)
```

### 6 — Degradation

Arrhenius-inspired power-law model:

```
Hc(N) = Hc(0) · exp(−k · N^α)     α = 0.6
```

Failure threshold: `Hc(N) / Hc(0) < 0.65`

### 7 — Areal Density

```
ρ_areal = (1 / (track_pitch × bit_length)) × (1 − ECC_overhead) × η_channel
```

Units: Tb/in² via conversion `1 inch = 25,400,000 nm`

---

## Recording Media Library

| Key | Material | Hc (Oe) | Grain (nm) | Tc (K) | Twrite (K) |
|-----|----------|---------|-----------|--------|-----------|
| `high_density_alloy` | FePt L10 | 30,000 | 6.5 | 750 | 580 |
| `standard_alloy` | CoCrPt | 18,000 | 8.5 | 680 | 500 |
| `ultra_dense_experimental` | FePtCu | 40,000 | 4.5 | 780 | 620 |
| `low_power_media` | SmCo | 22,000 | 9.0 | 1000 | 650 |

---

## Installation

```bash
pip install numpy scipy pandas plotly matplotlib PyQt6 scikit-learn
```

**Minimum Python: 3.11**

Optional (for full functionality):
```bash
pip install plotly  # Visualisation (required for plots)
pip install PyQt6   # GUI dashboard
```

---

## Usage

### Command Line

```bash
# Run a simulation
python -m hamr_x.main simulate \
    --medium high_density_alloy \
    --cycles 10000 \
    --power 6.0 \
    --track 30.0 \
    --bit 8.0 \
    --precision 0.97

# Genetic algorithm optimisation
python -m hamr_x.main optimise \
    --method ga \
    --generations 50 \
    --population 80 \
    --ber-target 1e-6

# Bayesian optimisation
python -m hamr_x.main optimise --method bayesian --generations 60

# Brute-force grid search
python -m hamr_x.main optimise --method brute --generations 30

# Parameter sensitivity sweep
python -m hamr_x.main sweep --param laser_power_mw --points 25

# Launch PyQt6 dashboard
python -m hamr_x.main gui

# Run unit tests
python -m hamr_x.main test

# Benchmark all media
python -m hamr_x.main benchmark --cycles 2000
```

### Python API

```python
from hamr_x.core.simulation_engine import run_hamr_simulation

# Simple factory function
result = run_hamr_simulation(
    laser_power       = 6.0,
    track_spacing     = 30.0,
    medium_type       = "high_density_alloy",
    head_precision    = 0.98,
    simulation_cycles = 10_000,
    seed              = 42,
)

print(result.summary())
print(result.final_metrics.formatted_report())
```

```python
from hamr_x.utils.config import HAMRConfig
from hamr_x.core.simulation_engine import SimulationEngine

# Full configuration control
cfg = HAMRConfig.from_medium("ultra_dense_experimental")
cfg.laser.power_mw           = 8.0
cfg.laser.pulse_duration_ns  = 1.2
cfg.density.track_spacing_nm = 20.0
cfg.density.bit_length_nm    = 6.0
cfg.head.precision           = 0.99
cfg.simulation.n_cycles      = 50_000
cfg.simulation.seed          = 1234

engine = SimulationEngine(cfg)
result = engine.run()
```

```python
# Genetic algorithm optimisation
from hamr_x.optimisation.genetic import GeneticOptimiser

optimiser = GeneticOptimiser(cfg, engine.evaluate_params)
ga_result = optimiser.optimise()

print(f"Best FoM:     {ga_result.best_fitness:.6f}")
print(f"Best BER:     {ga_result.best_ber:.4e}")
print(f"Best Density: {ga_result.best_density_tbpin2:.4f} Tb/in²")
print(f"Optimal params: {ga_result.best_params}")
```

```python
# Generate all plots
from hamr_x.visualization.plots import save_all_figures

saved = save_all_figures(result, output_dir="plots/", ga_result=ga_result)
```

---

## Example Scenarios

### Scenario A — Baseline 4 Tb/in² System
```python
result = run_hamr_simulation(
    laser_power=6.0, track_spacing=30.0, simulation_cycles=10000
)
# Expected: ~4–5 Tb/in², BER ~1e-8, FoM ~0.55
```

### Scenario B — Ultra-Dense Push (≥8 Tb/in²)
```python
cfg = HAMRConfig.from_medium("ultra_dense_experimental")
cfg.density.track_spacing_nm = 16.0
cfg.density.bit_length_nm    = 5.0
cfg.head.precision           = 0.995
cfg.laser.power_mw           = 9.0
# Expected: ~8–10 Tb/in², higher BER, requires strong ECC
```

### Scenario C — Lifetime Study (1M cycles)
```python
cfg.simulation.n_cycles         = 1_000_000
cfg.simulation.enable_degradation = True
# Track health score degradation and write success rate over time
```

### Scenario D — GA Optimisation Target ≥6 Tb/in²
```python
cfg.optimisation.min_density_tbpin2 = 6.0
cfg.optimisation.ber_target          = 1e-7
cfg.optimisation.n_generations       = 80
cfg.optimisation.population_size     = 100
```

---

## Output Files

| File | Description |
|------|-------------|
| `simulation_<run_id>.json` | Full simulation result in JSON |
| `benchmark_results.json` | Medium benchmark comparison |
| `ga_optimisation_result.json` | GA best parameters |
| `sweep_<param>.csv` | Sensitivity sweep data |
| `plots/density_vs_ber.html` | Density/BER trade-off chart |
| `plots/temperature_vs_write_success.html` | Thermal write probability |
| `plots/laser_power_vs_reliability.html` | Power/reliability curve |
| `plots/degradation_over_time.html` | Lifecycle degradation |
| `plots/thermal_spot_profile.html` | NFT thermal heatmap |
| `plots/performance_dashboard.html` | 6-panel KPI dashboard |
| `plots/grain_distribution.html` | Grain size/coercivity histograms |
| `plots/ga_convergence.html` | GA convergence history |

---

## Modelling Assumptions

1. **Thin-film thermal model** — 2D heat diffusion (ignores z-axis conduction into substrate)
2. **Gaussian beam profile** — NFT produces an ideal Gaussian spot; no optical aberrations
3. **Néel-Brown switching** — Single-domain grain approximation; no exchange coupling
4. **Log-normal grain distribution** — From physical vapour deposition statistics
5. **Independent grain switching** — Inter-grain magnetostatic coupling neglected
6. **Polynomial ECC model** — Simplified RS-code correction; not a full LDPC model
7. **Empirical coercivity-temperature** — Power-law fit to FePt L10 experimental data
8. **AWGN read channel** — Read errors modelled as additive Gaussian noise
9. **Deterministic degradation** — Per-cycle coercivity reduction without spatial correlation
10. **Head servo** — Mechanical errors are statistically stationary

---

## Performance Notes

- A 10,000-cycle simulation runs in ~1–3 seconds on modern hardware
- GA optimisation (80 pop × 50 gen) takes ~5–15 minutes (fast-eval mode)
- Each fast-eval uses 500 cycles with 100 grains for speed
- Full degradation studies (1M cycles) may take several minutes

---

## Testing

```bash
python -m hamr_x.main test
# Or directly:
python hamr_x/tests/test_hamr_x.py
```

The test suite covers 50+ individual test cases across all subsystems including integration tests that run a complete simulation end-to-end and verify deterministic reproducibility.

---

## Design Philosophy

> *"A system-level storage optimisation simulator that helps determine how to maximise storage density while maintaining reliability."*

HAMR-X is built as a **sovereign research platform** — deterministic, extensively documented, and extensible. Every physical assumption is documented inline. Every parameter has physical units. Every model can be replaced without touching the simulation engine.

The Anglo-industrial design aesthetic (dark terminals, gold metrics, monospace engineering outputs) reflects the platform's intended use in serious R&D environments.
