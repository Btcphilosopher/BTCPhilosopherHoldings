"""
HAMR-X CORE :: mechanical/head_positioning.py
=============================================
Read/write head positioning accuracy model.

Models the mechanical precision of the read/write head assembly including:
  - Track-follow servo error
  - Vibration-induced positional noise
  - Thermal expansion drift
  - TMR (Track Mis-Registration) computation
  - Effective write-track width under positional error

The Track Mis-Registration (TMR) budget determines the minimum usable track
pitch and thus sets the upper bound on areal density.

TMR Components (RSS combined)
-----------------------------
  TMR = √(σ_servo² + σ_vib² + σ_drift² + σ_media²)

where:
  σ_servo : Servo follow error (from control system bandwidth)
  σ_vib   : Vibration-induced displacement
  σ_drift : Positional drift (thermal, aging)
  σ_media : Media surface roughness contribution
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Optional

from ..utils.config import HeadConfig, HAMRConfig
from ..utils.logging import get_logger


_logger = get_logger("mechanical.head_positioning")


# ─────────────────────────────────────────────────────────────────────────────
#  POSITIONAL ERROR STATE
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PositionalState:
    """
    Instantaneous head positional state.

    Attributes
    ----------
    x_nm          : Cross-track position error (nm)
    y_nm          : Down-track position error (nm)
    tmr_nm        : Total track mis-registration (nm)
    alignment_factor: Write quality factor [0, 1] based on TMR/track_pitch
    on_track      : Whether head is within tolerance of target track
    """
    x_nm:           float
    y_nm:           float
    tmr_nm:         float
    alignment_factor: float
    on_track:       bool


# ─────────────────────────────────────────────────────────────────────────────
#  HEAD POSITIONING MODEL
# ─────────────────────────────────────────────────────────────────────────────

class HeadPositioningModel:
    """
    Statistical model of read/write head position accuracy.

    Generates realistic positional error distributions for each write
    event by sampling from calibrated noise distributions.

    Parameters
    ----------
    config          : HeadConfig specifying mechanical parameters
    track_pitch_nm  : Track-to-track pitch (nm)
    seed            : RNG seed
    """

    # Maximum allowed TMR as fraction of track pitch (3-sigma rule)
    _MAX_TMR_FRACTION: float = 0.25

    def __init__(self, config: HeadConfig,
                 track_pitch_nm: float = 30.0,
                 seed: int = 42) -> None:
        self.config         = config
        self.track_pitch_nm = track_pitch_nm
        self.rng            = np.random.default_rng(seed)

        # Running state for drift simulation
        self._drift_accumulator_nm: float = 0.0
        self._elapsed_ms:           float = 0.0
        self._event_count:          int   = 0

        # Per-event position log for statistical analysis
        self._position_log: list[PositionalState] = []

        _logger.info(
            f"Head positioning model: "
            f"precision={config.precision:.3f}, "
            f"jitter={config.jitter_sigma_nm:.1f} nm, "
            f"track_pitch={track_pitch_nm:.1f} nm"
        )

    # ──────────────────────────────────────────────────────────────────────────
    #  TMR COMPONENT MODELS
    # ──────────────────────────────────────────────────────────────────────────

    def _servo_error_nm(self) -> float:
        """
        Sample servo tracking error from a Gaussian distribution.

        Servo error σ_servo is derived from the head precision parameter:
            σ_servo = (1 - precision) × track_pitch / 3

        The factor /3 implements a 3-sigma fit to the track pitch budget.
        """
        sigma = (1.0 - self.config.precision) * self.track_pitch_nm / 3.0
        return float(self.rng.normal(0.0, sigma))

    def _vibration_displacement_nm(self) -> float:
        """
        Sample instantaneous vibration displacement.

        Vibration is modelled as a combination of:
          - Low-frequency arm resonance: sinusoidal component
          - High-frequency bearing noise: Gaussian component

        The amplitude is modulated to simulate realistic non-stationary
        vibration environment.
        """
        amp = self.config.vibration_amplitude_nm
        # Slow sinusoidal component (arm sway)
        slow_phase = (self._event_count * 0.017) % (2 * np.pi)
        slow_comp  = 0.5 * amp * np.sin(slow_phase)
        # Fast Gaussian noise (bearing/spindle)
        fast_comp  = self.rng.normal(0.0, amp * 0.5)
        return slow_comp + fast_comp

    def _jitter_displacement_nm(self) -> float:
        """
        Sample servo jitter from Gaussian distribution.

        Jitter represents high-frequency servo position uncertainty.
        """
        return float(self.rng.normal(0.0, self.config.jitter_sigma_nm))

    def _drift_increment_nm(self, dt_ms: float = 0.001) -> float:
        """
        Compute incremental positional drift.

        Drift arises from thermal expansion and bearing wear.
        Modelled as a biased random walk.
        """
        rate   = self.config.positional_drift_nm_per_ms
        # Slow random walk component
        drift_rw = self.rng.normal(rate * dt_ms, rate * dt_ms * 0.3)
        self._drift_accumulator_nm += drift_rw
        # Servo periodically corrects large drift (seek correction)
        if abs(self._drift_accumulator_nm) > self.track_pitch_nm * 0.4:
            # Seek correction returns drift toward zero
            self._drift_accumulator_nm *= 0.1
        return self._drift_accumulator_nm

    # ──────────────────────────────────────────────────────────────────────────
    #  COMBINED POSITION ERROR
    # ──────────────────────────────────────────────────────────────────────────

    def sample_position_error(self, dt_ms: float = 0.001) -> PositionalState:
        """
        Sample a complete positional error state for one write event.

        Combines all TMR components via RSS (root sum of squares):
            TMR = √(σ_servo² + σ_vib² + σ_jitter² + σ_drift²)

        Parameters
        ----------
        dt_ms : Time since last position sample (milliseconds)

        Returns
        -------
        PositionalState with cross-track and down-track errors, alignment factor
        """
        self._event_count += 1
        self._elapsed_ms  += dt_ms

        # Cross-track position error (most critical for density)
        x_servo   = self._servo_error_nm()
        x_vib     = self._vibration_displacement_nm()
        x_jitter  = self._jitter_displacement_nm()
        x_drift   = self._drift_increment_nm(dt_ms)

        # RSS combination for cross-track TMR
        tmr_x = np.sqrt(x_servo**2 + x_vib**2 + x_jitter**2 + x_drift**2)

        # Down-track jitter (affects write timing accuracy)
        y_jitter = float(self.rng.normal(0.0, self.config.jitter_sigma_nm * 0.6))
        tmr_y    = abs(y_jitter)

        # Total TMR (cross-track dominant)
        tmr_total = np.sqrt(tmr_x**2 + tmr_y**2)

        # Alignment factor: Gaussian function of TMR relative to track pitch
        # Peak at TMR=0 → factor=1.0; drops as TMR approaches track_pitch/2
        sigma_align = self.track_pitch_nm * self._MAX_TMR_FRACTION
        alignment_factor = float(np.exp(-0.5 * (tmr_total / sigma_align) ** 2))
        alignment_factor = float(np.clip(alignment_factor, 0.0, 1.0))

        # On-track: TMR within 15% of track pitch
        on_track = tmr_total < (self.track_pitch_nm * 0.15)

        state = PositionalState(
            x_nm             = float(x_servo + x_vib + x_jitter + x_drift),
            y_nm             = float(y_jitter),
            tmr_nm           = float(tmr_total),
            alignment_factor = alignment_factor,
            on_track         = on_track,
        )
        self._position_log.append(state)
        return state

    # ──────────────────────────────────────────────────────────────────────────
    #  BATCH POSITION SAMPLING
    # ──────────────────────────────────────────────────────────────────────────

    def sample_batch(self, n: int, dt_ms: float = 0.001) -> list[PositionalState]:
        """
        Sample n consecutive positional states.

        Parameters
        ----------
        n     : Number of position samples
        dt_ms : Inter-sample time (ms)

        Returns
        -------
        List of PositionalState records
        """
        return [self.sample_position_error(dt_ms) for _ in range(n)]

    # ──────────────────────────────────────────────────────────────────────────
    #  STATISTICAL ANALYSIS
    # ──────────────────────────────────────────────────────────────────────────

    def tmr_statistics(self) -> dict:
        """
        Compute TMR statistics from the position log.

        Returns
        -------
        dict with mean, sigma, 3sigma, p99 TMR values and on-track fraction
        """
        if not self._position_log:
            return {"n_samples": 0}

        tmr_values = np.array([s.tmr_nm for s in self._position_log])
        af_values  = np.array([s.alignment_factor for s in self._position_log])
        on_track   = np.array([s.on_track for s in self._position_log])

        return {
            "n_samples":             len(tmr_values),
            "tmr_mean_nm":           float(np.mean(tmr_values)),
            "tmr_sigma_nm":          float(np.std(tmr_values)),
            "tmr_3sigma_nm":         float(3.0 * np.std(tmr_values)),
            "tmr_p99_nm":            float(np.percentile(tmr_values, 99)),
            "tmr_max_nm":            float(np.max(tmr_values)),
            "mean_alignment_factor": float(np.mean(af_values)),
            "on_track_fraction":     float(np.mean(on_track)),
            "track_pitch_nm":        self.track_pitch_nm,
            "tmr_budget_nm":         self.track_pitch_nm * self._MAX_TMR_FRACTION,
        }

    def minimum_track_pitch_nm(self, target_on_track_fraction: float = 0.99) -> float:
        """
        Estimate the minimum track pitch achievable with this head precision,
        such that target_on_track_fraction of writes are on-track.

        Uses the 3-sigma TMR rule:
            track_pitch_min = TMR_3sigma / MAX_TMR_FRACTION

        Parameters
        ----------
        target_on_track_fraction : Target fraction of writes on-track

        Returns
        -------
        Minimum track pitch in nm
        """
        # Generate fresh statistical sample if log is small
        if len(self._position_log) < 1000:
            self.sample_batch(1000)

        stats = self.tmr_statistics()
        # Use 3-sigma for given target fraction (normal approximation)
        # 99% → 2.576σ; 99.9% → 3.090σ
        from scipy.stats import norm
        n_sigma = norm.ppf(target_on_track_fraction) * 2
        tmr_budget = stats["tmr_sigma_nm"] * n_sigma
        min_pitch  = tmr_budget / self._MAX_TMR_FRACTION
        return max(min_pitch, 5.0)   # physical minimum 5 nm

    def reset_log(self) -> None:
        """Clear the position log to free memory."""
        self._position_log.clear()


# ─────────────────────────────────────────────────────────────────────────────
#  VIBRATION MODEL (standalone)
# ─────────────────────────────────────────────────────────────────────────────

class VibrationModel:
    """
    Multi-frequency vibration model for HDD spindle and actuator resonances.

    Models the dominant vibration modes as damped harmonic oscillators.
    Used for frequency-domain analysis and noise floor estimation.

    Parameters
    ----------
    config : HeadConfig
    seed   : RNG seed
    """

    # Dominant resonance frequencies (Hz) and Q-factors
    _RESONANCES: list[tuple[float, float]] = [
        (5_000.0,  12.0),    # Actuator arm first mode
        (15_000.0, 8.0),     # Actuator arm second mode
        (70_000.0, 20.0),    # Suspension resonance
        (150_000.0, 5.0),    # Slider pitch mode
    ]

    def __init__(self, config: HeadConfig, seed: int = 42) -> None:
        self.config = config
        self.rng    = np.random.default_rng(seed)

    def displacement_rms_nm(self) -> float:
        """
        Compute RMS displacement contribution from all resonance modes.

        The amplitude of each mode is scaled to the configured vibration
        amplitude parameter.

        Returns
        -------
        RMS displacement in nm
        """
        base_amp = self.config.vibration_amplitude_nm
        rms_sq = 0.0
        for freq, q_factor in self._RESONANCES:
            # Amplitude scaling: higher Q → sharper but taller resonance peak
            mode_amp = base_amp * (q_factor / 15.0) * (5000.0 / freq) ** 0.5
            rms_sq  += 0.5 * mode_amp ** 2
        return float(np.sqrt(rms_sq))

    def frequency_spectrum(self, f_max_hz: float = 200_000.0,
                            n_points: int = 1000) -> tuple[np.ndarray, np.ndarray]:
        """
        Generate the displacement power spectral density.

        Returns
        -------
        (frequencies_hz, psd_nm2_per_hz) arrays
        """
        freqs = np.linspace(1.0, f_max_hz, n_points)
        psd   = np.zeros(n_points)
        base_amp = self.config.vibration_amplitude_nm

        for f_res, q_factor in self._RESONANCES:
            # Lorentzian line shape
            bw    = f_res / q_factor   # bandwidth
            mode_amp = base_amp * (q_factor / 15.0) * (5000.0 / f_res) ** 0.5
            psd  += (mode_amp ** 2 / 2.0) * (
                (bw / 2.0) ** 2 /
                ((freqs - f_res) ** 2 + (bw / 2.0) ** 2)
            )

        return freqs, psd

    def simulate_time_series(self, duration_ms: float,
                              sample_rate_mhz: float = 1.0) -> tuple[np.ndarray, np.ndarray]:
        """
        Generate a time-domain vibration displacement signal.

        Parameters
        ----------
        duration_ms    : Signal duration (ms)
        sample_rate_mhz: Sample rate (MHz)

        Returns
        -------
        (time_ms, displacement_nm) arrays
        """
        dt_us     = 1.0 / sample_rate_mhz    # µs
        dt_ms     = dt_us * 1e-3
        n_samples = int(duration_ms / dt_ms)
        t_ms      = np.arange(n_samples) * dt_ms

        signal    = np.zeros(n_samples)
        base_amp  = self.config.vibration_amplitude_nm

        for f_res, q_factor in self._RESONANCES:
            mode_amp = base_amp * (q_factor / 15.0) * (5000.0 / f_res) ** 0.5
            phase    = self.rng.uniform(0, 2 * np.pi)
            decay    = np.exp(-np.pi * f_res / q_factor * t_ms * 1e-3)
            signal  += mode_amp * decay * np.sin(
                2 * np.pi * f_res * t_ms * 1e-3 + phase
            )

        # Add white noise floor
        noise_amp = base_amp * 0.05
        signal   += self.rng.normal(0.0, noise_amp, n_samples)

        return t_ms, signal
