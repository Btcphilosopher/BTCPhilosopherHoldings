"""
HAMR-X CORE :: storage/density_model.py
                storage/error_model.py
                storage/degradation_model.py
=============================================
Combined storage subsystem models for HAMR-X.

Includes:
  1. DensityModel    — areal storage density computation
  2. ErrorModel      — bit error rate and reliability modelling
  3. DegradationModel — long-term lifecycle degradation curves
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Optional

from ..utils.config import DensityConfig, HAMRConfig
from ..utils.logging import get_logger


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 1: DENSITY MODEL
# ══════════════════════════════════════════════════════════════════════════════

_logger_density = get_logger("storage.density")

# Conversion: 1 inch = 25,400,000 nm
NM_PER_INCH: float = 25.4e6


@dataclass
class DensityResult:
    """
    Areal storage density calculation result.

    Attributes
    ----------
    areal_density_tbpin2 : Areal density (Tb/in²)
    track_density_tpi    : Track density (tracks per inch)
    linear_density_bpi   : Linear density (bits per inch)
    bits_per_nm2         : Raw bit density per nm²
    tracks_per_nm        : Track pitch reciprocal (tracks/nm)
    effective_bit_width_nm: Effective written bit width accounting for TMR
    write_window_nm      : Maximum TMR budget for this density
    """
    areal_density_tbpin2:  float
    track_density_tpi:     float
    linear_density_bpi:    float
    bits_per_nm2:          float
    tracks_per_nm:         float
    effective_bit_width_nm: float
    write_window_nm:       float


class DensityModel:
    """
    Areal storage density model for HAMR recording systems.

    Computes achievable storage density given track geometry, bit cell
    dimensions, and head accuracy constraints.

    The effective areal density accounts for:
      - Guard bands between tracks
      - TMR-induced track width penalty
      - Overhead bits (ECC, servo, sync)

    Parameters
    ----------
    config         : DensityConfig with geometry parameters
    tmr_3sigma_nm  : 3-sigma TMR budget from head positioning model (nm)
    """

    # Fraction of capacity consumed by ECC and overhead
    _ECC_OVERHEAD: float = 0.15
    # PRML read channel efficiency factor
    _CHANNEL_EFFICIENCY: float = 0.93

    def __init__(self, config: DensityConfig,
                 tmr_3sigma_nm: float = 2.5) -> None:
        self.config        = config
        self.tmr_3sigma_nm = tmr_3sigma_nm
        _logger_density.info(
            f"Density model: track_pitch={config.track_spacing_nm:.1f} nm, "
            f"bit_length={config.bit_length_nm:.1f} nm, "
            f"TMR_3σ={tmr_3sigma_nm:.2f} nm"
        )

    def compute_density(self) -> DensityResult:
        """
        Compute areal storage density for current configuration.

        The effective track pitch accounts for:
          - Guard band (fraction of pitch)
          - TMR budget (head must stay within write window)

        Returns
        -------
        DensityResult with all density metrics
        """
        track_pitch = self.config.track_spacing_nm
        bit_length  = self.config.bit_length_nm
        guard_frac  = self.config.guard_band_fraction

        # Effective writable track width
        write_window = track_pitch * (1.0 - guard_frac) - self.tmr_3sigma_nm * 2
        write_window = max(write_window, 0.5)  # enforce physical minimum

        # Bits per nm² (raw)
        bits_per_nm2 = 1.0 / (track_pitch * bit_length)

        # Tracks per nm and per inch
        tracks_per_nm  = 1.0 / track_pitch
        track_density_tpi = tracks_per_nm * NM_PER_INCH

        # Linear density (bits per inch)
        linear_density_bpi = (1.0 / bit_length) * NM_PER_INCH

        # Areal density (bits/in²) → convert to Tb/in²
        raw_density_tbpin2 = (bits_per_nm2 * NM_PER_INCH ** 2) / 1e12

        # Apply overhead factors
        net_density = (raw_density_tbpin2
                       * (1.0 - self._ECC_OVERHEAD)
                       * self._CHANNEL_EFFICIENCY)

        return DensityResult(
            areal_density_tbpin2   = net_density,
            track_density_tpi      = track_density_tpi,
            linear_density_bpi     = linear_density_bpi,
            bits_per_nm2           = bits_per_nm2,
            tracks_per_nm          = tracks_per_nm,
            effective_bit_width_nm = write_window,
            write_window_nm        = write_window,
        )

    def density_vs_track_spacing(self,
                                   spacings_nm: np.ndarray) -> np.ndarray:
        """
        Compute areal density for an array of track spacings.

        Useful for trade-off analysis plots.

        Parameters
        ----------
        spacings_nm : Array of track spacings (nm)

        Returns
        -------
        Array of net areal densities (Tb/in²)
        """
        original = self.config.track_spacing_nm
        densities = []
        for sp in spacings_nm:
            self.config.track_spacing_nm = sp
            densities.append(self.compute_density().areal_density_tbpin2)
        self.config.track_spacing_nm = original
        return np.array(densities)

    def density_vs_bit_length(self,
                               bit_lengths_nm: np.ndarray) -> np.ndarray:
        """Compute areal density for an array of bit lengths (nm)."""
        original = self.config.bit_length_nm
        densities = []
        for bl in bit_lengths_nm:
            self.config.bit_length_nm = bl
            densities.append(self.compute_density().areal_density_tbpin2)
        self.config.bit_length_nm = original
        return np.array(densities)


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 2: ERROR MODEL
# ══════════════════════════════════════════════════════════════════════════════

_logger_error = get_logger("storage.error")


@dataclass
class ErrorBudget:
    """
    Decomposed error budget for a HAMR storage system.

    Attributes
    ----------
    raw_ber           : Raw bit error rate before ECC
    post_ecc_ber      : Bit error rate after error correction
    write_fail_rate   : Write operation failure rate
    thermal_misfire_rate: Rate of off-target thermal writes
    adjacent_track_erasure_rate: Rate of adjacent track interference
    read_snr_margin_db  : Read SNR margin above threshold (dB)
    reliability_score   : Overall system reliability [0, 1]
    dominant_error_mode : String identifier of worst error source
    """
    raw_ber:                    float
    post_ecc_ber:               float
    write_fail_rate:            float
    thermal_misfire_rate:       float
    adjacent_track_erasure_rate: float
    read_snr_margin_db:         float
    reliability_score:          float
    dominant_error_mode:        str


class ErrorModel:
    """
    Comprehensive bit error rate and reliability model for HAMR systems.

    Combines write failure rates, thermal misfire rates, read channel
    noise, and ECC correction capability to produce a total error budget.

    Parameters
    ----------
    config          : HAMRConfig master configuration
    seed            : RNG seed
    """

    # ECC correction capability parameters (RS-like code model)
    _ECC_CORRECTION_EXPONENT: float = 2.5  # correction power law
    _ECC_OVERHEAD_FRACTION:   float = 0.15

    def __init__(self, config: HAMRConfig, seed: int = 42) -> None:
        self.config = config
        self.rng    = np.random.default_rng(seed)
        _logger_error.info("Error model initialised")

    def compute_raw_ber(self,
                         write_success_rate:    float,
                         alignment_quality:     float,
                         thermal_misfire_rate:  float) -> float:
        """
        Compute the raw (pre-ECC) bit error rate from system parameters.

        The raw BER combines:
          - Write failures → P_write_fail = 1 - write_success_rate
          - Alignment errors → weighted by mis-alignment probability
          - Thermal misfires → random bit flips from adjacent write heat
          - Media noise → SNR-dependent channel noise floor

        Parameters
        ----------
        write_success_rate   : Fraction of writes that succeed [0, 1]
        alignment_quality    : Mean alignment factor [0, 1]
        thermal_misfire_rate : Adjacent track interference rate [0, 1]

        Returns
        -------
        Raw BER estimate
        """
        # Write failure contribution
        p_write_fail = 1.0 - write_success_rate

        # Alignment error contribution (mis-written bits)
        p_align_error = (1.0 - alignment_quality) * 0.5

        # Thermal misfire (partial erasure of adjacent track → 50% chance
        # each affected bit is wrong)
        p_thermal = thermal_misfire_rate * 0.5

        # Channel noise floor (from read SNR)
        snr_db  = self.config.density.read_channel_snr_db
        snr_lin = 10.0 ** (snr_db / 10.0)
        from scipy.special import erfc
        p_channel = 0.5 * erfc(np.sqrt(snr_lin / 2.0))

        # Combined raw BER (independent error sources — upper bound)
        raw_ber = (p_write_fail
                   + p_align_error
                   + p_thermal
                   + p_channel)

        # Clip to valid probability range
        return float(np.clip(raw_ber, 0.0, 1.0))

    def apply_ecc_correction(self, raw_ber: float) -> float:
        """
        Apply ECC correction to reduce raw BER.

        Model: Reed-Solomon-like code with overhead fraction r_ecc.
        Post-ECC BER approximation:

            BER_ecc ≈ BER_raw^(1 + correction_exponent)

        This is a simplified polynomial correction model.

        Parameters
        ----------
        raw_ber : Pre-ECC bit error rate

        Returns
        -------
        Post-ECC bit error rate
        """
        if raw_ber <= 0.0:
            return 0.0
        # ECC provides polynomial error reduction
        post_ber = raw_ber ** (1.0 + self._ECC_CORRECTION_EXPONENT)
        return float(np.clip(post_ber, 0.0, 1.0))

    def compute_error_budget(self,
                               write_success_rate:           float,
                               alignment_quality:            float,
                               thermal_misfire_rate:         float,
                               adjacent_track_erasure_rate:  float) -> ErrorBudget:
        """
        Compute the complete error budget for the current system state.

        Parameters
        ----------
        write_success_rate          : Write success fraction
        alignment_quality           : Mean alignment factor
        thermal_misfire_rate        : Thermal pulse misfire rate
        adjacent_track_erasure_rate : Adjacent track interference rate

        Returns
        -------
        ErrorBudget with all error components
        """
        raw_ber      = self.compute_raw_ber(
            write_success_rate, alignment_quality, thermal_misfire_rate
        )
        post_ecc_ber = self.apply_ecc_correction(raw_ber)

        # Read SNR margin above threshold
        snr_threshold_db = self.config.density.read_channel_snr_db
        # Estimate operational SNR (degrades with density and alignment)
        operational_snr_db = snr_threshold_db + 3.0 * alignment_quality - 1.0
        snr_margin = operational_snr_db - snr_threshold_db

        # Reliability score [0, 1] — logarithmic mapping
        if post_ecc_ber <= 0.0:
            reliability = 1.0
        elif post_ecc_ber >= 1.0:
            reliability = 0.0
        else:
            log_ber = np.log10(max(post_ecc_ber, 1e-15))
            # Target BER = 1e-15 → reliability = 1.0
            # BER = 1e-6 → reliability ≈ 0.6
            # BER = 0.01 → reliability ≈ 0.1
            reliability = float(np.clip(-log_ber / 15.0, 0.0, 1.0))

        # Determine dominant error mode
        error_contributions = {
            "write_failure":       1.0 - write_success_rate,
            "alignment":           (1.0 - alignment_quality) * 0.5,
            "thermal_misfire":     thermal_misfire_rate * 0.5,
            "adjacent_erasure":    adjacent_track_erasure_rate * 0.3,
        }
        dominant_mode = max(error_contributions, key=error_contributions.get)

        return ErrorBudget(
            raw_ber                     = raw_ber,
            post_ecc_ber                = post_ecc_ber,
            write_fail_rate             = 1.0 - write_success_rate,
            thermal_misfire_rate        = thermal_misfire_rate,
            adjacent_track_erasure_rate = adjacent_track_erasure_rate,
            read_snr_margin_db          = snr_margin,
            reliability_score           = reliability,
            dominant_error_mode         = dominant_mode,
        )

    def ber_vs_density(self,
                        densities_tbpin2: np.ndarray,
                        base_write_success: float = 0.98) -> np.ndarray:
        """
        Model BER as a function of areal density.

        Higher density → smaller grains → more noise → higher BER.

        Parameters
        ----------
        densities_tbpin2 : Array of areal densities (Tb/in²)
        base_write_success: Write success rate at baseline density

        Returns
        -------
        Array of post-ECC BER values
        """
        baseline_density = 4.0  # Tb/in² reference
        ber_values = []
        for d in densities_tbpin2:
            # Write success degrades with density
            density_ratio  = d / baseline_density
            write_success  = base_write_success * np.exp(-0.08 * (density_ratio - 1))
            write_success  = float(np.clip(write_success, 0.0, 1.0))
            # Thermal misfire increases with higher density (smaller track pitch)
            misfire_rate   = 0.01 * density_ratio ** 1.5
            adj_erasure    = 0.005 * density_ratio ** 2.0
            raw_ber        = self.compute_raw_ber(write_success, 0.95, misfire_rate)
            post_ber       = self.apply_ecc_correction(raw_ber)
            ber_values.append(post_ber)
        return np.array(ber_values)


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 3: DEGRADATION MODEL
# ══════════════════════════════════════════════════════════════════════════════

_logger_degrad = get_logger("storage.degradation")


@dataclass
class DegradationState:
    """
    Current lifecycle degradation state of the recording medium.

    Attributes
    ----------
    cycle_count            : Total write cycles applied
    coercivity_factor      : Current coercivity / initial coercivity [0, 1]
    thermal_stability_factor: Current Δ / initial Δ [0, 1]
    surface_roughness_nm   : Accumulated surface roughness increase (nm)
    lubrication_factor     : Lubricant effectiveness [0, 1]
    estimated_lifetime_cycles: Estimated remaining usable cycles
    health_score           : Overall medium health [0, 1]
    degradation_stage      : 'PRISTINE'|'NORMAL'|'WORN'|'CRITICAL'|'FAILED'
    """
    cycle_count:                int
    coercivity_factor:          float
    thermal_stability_factor:   float
    surface_roughness_nm:       float
    lubrication_factor:         float
    estimated_lifetime_cycles:  int
    health_score:               float
    degradation_stage:          str


class DegradationModel:
    """
    Long-term lifecycle degradation model for HAMR recording media.

    Simulates the evolution of magnetic and physical properties under
    repeated thermal cycling, including:
      - Coercivity reduction from grain boundary diffusion
      - Thermal stability degradation from grain growth/dissolution
      - Surface roughness increase from head contact and wear
      - Lubricant depletion from repeated laser heating

    The Arrhenius-based degradation model is:

        property(N) = property(0) · exp(-k · N^exponent)

    where k is the degradation rate constant and N is cycle count.

    Parameters
    ----------
    config        : HAMRConfig with medium parameters
    initial_cycles: Starting cycle count (0 for new medium)
    """

    # Degradation model parameters
    _COER_DEGRADATION_EXPONENT:   float = 0.6   # sub-linear degradation
    _THERM_DEGRADATION_EXPONENT:  float = 0.7
    _ROUGHNESS_GROWTH_RATE:       float = 1e-5   # nm per cycle
    _LUBRICANT_DECAY_RATE:        float = 2e-6   # fraction per cycle
    _FAILURE_COERCIVITY_FRACTION: float = 0.65   # Hc/Hc0 where medium fails

    def __init__(self, config: HAMRConfig, initial_cycles: int = 0) -> None:
        self.config         = config
        self._cycle_count   = initial_cycles
        self._coer_factor   = 1.0
        self._therm_factor  = 1.0
        self._roughness_nm  = 0.0
        self._lubricant     = 1.0

        # Reference parameters for normalisation
        self._ref_coercivity   = config.medium.coercivity_oe
        self._ref_stability    = config.medium.thermal_stability
        self._base_degrad_rate = config.medium.degradation_rate

        _logger_degrad.info(
            f"Degradation model: medium={config.medium.name}, "
            f"base_rate={self._base_degrad_rate:.2e}"
        )

    def step(self, n_cycles: int = 1) -> DegradationState:
        """
        Advance the degradation model by n_cycles write cycles.

        Updates all degradation state variables and returns the
        current degradation state.

        Parameters
        ----------
        n_cycles : Number of write cycles to advance

        Returns
        -------
        DegradationState
        """
        self._cycle_count += n_cycles

        N   = float(self._cycle_count)
        k   = self._base_degrad_rate

        # Coercivity degradation: Hc(N) = Hc(0) · exp(-k · N^α)
        self._coer_factor  = np.exp(-k * N ** self._COER_DEGRADATION_EXPONENT)
        self._coer_factor  = float(np.clip(self._coer_factor, 0.0, 1.0))

        # Thermal stability degradation
        self._therm_factor = np.exp(-k * 0.8 * N ** self._THERM_DEGRADATION_EXPONENT)
        self._therm_factor = float(np.clip(self._therm_factor, 0.0, 1.0))

        # Surface roughness growth (cumulative)
        self._roughness_nm = self._ROUGHNESS_GROWTH_RATE * N ** 0.5

        # Lubricant depletion
        self._lubricant    = np.exp(-self._LUBRICANT_DECAY_RATE * N)
        self._lubricant    = float(np.clip(self._lubricant, 0.0, 1.0))

        return self._compute_state()

    def _compute_state(self) -> DegradationState:
        """Compute full DegradationState from current internal variables."""
        # Estimate remaining lifetime
        # Find N_fail where coercivity_factor = failure threshold
        # coer_factor(N_fail) = threshold → N_fail = (−ln(threshold)/k)^(1/α)
        k   = self._base_degrad_rate
        if k > 0:
            n_fail = (-np.log(self._FAILURE_COERCIVITY_FRACTION) / k) ** (
                1.0 / self._COER_DEGRADATION_EXPONENT
            )
        else:
            n_fail = 1e12
        remaining = max(0, int(n_fail - self._cycle_count))

        # Overall health score (geometric mean of factors)
        health = float(np.sqrt(self._coer_factor * self._therm_factor
                                * self._lubricant))
        health = float(np.clip(health, 0.0, 1.0))

        # Degradation stage classification
        if health > 0.90:
            stage = "PRISTINE"
        elif health > 0.75:
            stage = "NORMAL"
        elif health > 0.55:
            stage = "WORN"
        elif health > self._FAILURE_COERCIVITY_FRACTION:
            stage = "CRITICAL"
        else:
            stage = "FAILED"

        return DegradationState(
            cycle_count               = self._cycle_count,
            coercivity_factor         = self._coer_factor,
            thermal_stability_factor  = self._therm_factor,
            surface_roughness_nm      = self._roughness_nm,
            lubrication_factor        = self._lubricant,
            estimated_lifetime_cycles = remaining,
            health_score              = health,
            degradation_stage         = stage,
        )

    def get_current_state(self) -> DegradationState:
        """Return current degradation state without advancing cycles."""
        return self._compute_state()

    def degradation_curve(self,
                           n_points: int = 200) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Generate complete degradation curves from 0 to failure.

        Returns
        -------
        (cycles, coercivity_factors, health_scores) arrays
        """
        k      = self._base_degrad_rate
        n_fail = (-np.log(self._FAILURE_COERCIVITY_FRACTION) / k) ** (
            1.0 / self._COER_DEGRADATION_EXPONENT
        )
        cycles    = np.linspace(0, n_fail * 1.2, n_points)
        coer_f    = np.exp(-k * cycles ** self._COER_DEGRADATION_EXPONENT)
        therm_f   = np.exp(-k * 0.8 * cycles ** self._THERM_DEGRADATION_EXPONENT)
        lubr_f    = np.exp(-self._LUBRICANT_DECAY_RATE * cycles)
        health    = np.sqrt(np.clip(coer_f * therm_f * lubr_f, 0, 1))

        return cycles, coer_f, health

    def coercivity_at_cycle(self, n: int) -> float:
        """Return coercivity at cycle n (Oe)."""
        k    = self._base_degrad_rate
        cf   = np.exp(-k * float(n) ** self._COER_DEGRADATION_EXPONENT)
        return float(np.clip(cf, 0.0, 1.0)) * self._ref_coercivity

    def lifetime_estimate_cycles(self) -> int:
        """Return estimated remaining usable write cycles."""
        return self._compute_state().estimated_lifetime_cycles
