"""
HAMR-X CORE :: optimisation/genetic.py
========================================
Genetic Algorithm optimiser for HAMR system parameter space.

Optimises the multi-dimensional parameter space of a HAMR recording system
to maximise storage density while keeping BER below a target threshold.

Optimised Parameters
--------------------
  - laser_power_mw         : Laser output power (mW)
  - pulse_duration_ns      : Write pulse duration (ns)
  - spot_radius_nm         : NFT spot radius (nm)
  - track_spacing_nm       : Track pitch (nm)
  - bit_length_nm          : Along-track bit cell length (nm)
  - head_precision         : Servo precision [0, 1]
  - write_temp_k           : Target write temperature (K)
  - nft_efficiency         : NFT energy coupling efficiency [0, 1]

GA Implementation
-----------------
  - Real-valued chromosome encoding
  - Tournament selection with elitism
  - Gaussian mutation with adaptive sigma
  - Uniform + arithmetic crossover
  - Multi-objective: maximise FoM subject to BER constraint
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Callable, Optional

from ..utils.config import HAMRConfig, OptimisationConfig, OPTIMISATION_BOUNDS
from ..utils.logging import get_logger, ProgressLogger


_logger = get_logger("optimisation.genetic")


# ─────────────────────────────────────────────────────────────────────────────
#  CHROMOSOME DEFINITION
# ─────────────────────────────────────────────────────────────────────────────

# Parameter names in fixed order — defines chromosome gene positions
GENE_NAMES: list[str] = [
    "laser_power_mw",
    "pulse_duration_ns",
    "spot_radius_nm",
    "track_spacing_nm",
    "bit_length_nm",
    "head_precision",
    "write_temp_k",
    "nft_efficiency",
]

N_GENES: int = len(GENE_NAMES)

# Bounds arrays (same order as GENE_NAMES)
GENE_LOWER: np.ndarray = np.array([
    OPTIMISATION_BOUNDS[g][0] for g in GENE_NAMES
])
GENE_UPPER: np.ndarray = np.array([
    OPTIMISATION_BOUNDS[g][1] for g in GENE_NAMES
])


@dataclass
class Individual:
    """
    A single individual in the GA population.

    Attributes
    ----------
    genes    : Real-valued parameter vector (length N_GENES)
    fitness  : Fitness score (higher = better); None if unevaluated
    ber      : BER at this parameter set; None if unevaluated
    density  : Areal density at this parameter set; None if unevaluated
    feasible : Whether this individual satisfies the BER constraint
    """
    genes:    np.ndarray
    fitness:  Optional[float] = None
    ber:      Optional[float] = None
    density:  Optional[float] = None
    feasible: bool            = False

    def to_params(self) -> dict[str, float]:
        """Convert gene vector to named parameter dictionary."""
        return {name: float(g) for name, g in zip(GENE_NAMES, self.genes)}

    def clone(self) -> "Individual":
        """Return a deep copy of this individual."""
        return Individual(
            genes   = self.genes.copy(),
            fitness = self.fitness,
            ber     = self.ber,
            density = self.density,
            feasible= self.feasible,
        )


@dataclass
class GenerationStats:
    """Statistics for one GA generation."""
    generation:        int
    best_fitness:      float
    mean_fitness:      float
    best_ber:          float
    best_density:      float
    n_feasible:        int
    population_size:   int
    diversity:         float    # mean pairwise distance in gene space


@dataclass
class GAResult:
    """
    Final result of the Genetic Algorithm optimisation.

    Attributes
    ----------
    best_params        : Optimal parameter dictionary
    best_fitness       : Best fitness achieved
    best_ber           : BER at optimal parameters
    best_density_tbpin2: Density at optimal parameters
    n_generations      : Number of generations run
    convergence_history: List of GenerationStats per generation
    feasible           : Whether best solution satisfies BER constraint
    """
    best_params:          dict[str, float]
    best_fitness:         float
    best_ber:             float
    best_density_tbpin2:  float
    n_generations:        int
    convergence_history:  list[GenerationStats]
    feasible:             bool


# ─────────────────────────────────────────────────────────────────────────────
#  GENETIC ALGORITHM OPTIMISER
# ─────────────────────────────────────────────────────────────────────────────

class GeneticOptimiser:
    """
    Real-valued Genetic Algorithm for HAMR parameter optimisation.

    Fitness Function
    ----------------
    For feasible individuals (BER ≤ target):
        fitness = Figure_of_Merit(density, reliability, energy, lifetime)
    For infeasible individuals:
        fitness = -penalty_weight × (BER / BER_target - 1)

    Parameters
    ----------
    config         : HAMRConfig providing system parameters
    evaluate_fn    : Function (params_dict) → (ber, density, fom)
                     Provided by the SimulationEngine
    opt_config     : OptimisationConfig with GA hyper-parameters
    seed           : RNG seed
    """

    def __init__(self,
                 config:       HAMRConfig,
                 evaluate_fn:  Callable[[dict[str, float]], tuple[float, float, float]],
                 opt_config:   Optional[OptimisationConfig] = None,
                 seed:         int = 42) -> None:
        self.config      = config
        self.evaluate_fn = evaluate_fn
        self.opt_config  = opt_config or config.optimisation
        self.rng         = np.random.default_rng(seed)
        self._eval_count: int = 0

        _logger.info(
            f"Genetic optimiser: "
            f"pop={self.opt_config.population_size}, "
            f"gen={self.opt_config.n_generations}, "
            f"mut={self.opt_config.mutation_rate}, "
            f"cx={self.opt_config.crossover_rate}"
        )

    # ──────────────────────────────────────────────────────────────────────────
    #  POPULATION INITIALISATION
    # ──────────────────────────────────────────────────────────────────────────

    def _init_population(self, pop_size: int) -> list[Individual]:
        """
        Initialise population with uniform random sampling within bounds.

        A fraction of the population is seeded near the current config
        to exploit prior knowledge.
        """
        population = []
        n_seed     = max(1, pop_size // 5)    # 20% seeded near current config
        n_random   = pop_size - n_seed

        # Current config as reference point
        ref_genes = np.array([
            self.config.laser.power_mw,
            self.config.laser.pulse_duration_ns,
            self.config.laser.spot_radius_nm,
            self.config.density.track_spacing_nm,
            self.config.density.bit_length_nm,
            self.config.head.precision,
            self.config.medium.write_temp_k,
            self.config.laser.nft_efficiency,
        ])

        # Seeded individuals: Gaussian perturbation around reference
        for _ in range(n_seed):
            genes = ref_genes.copy()
            sigma = (GENE_UPPER - GENE_LOWER) * 0.08
            genes = genes + self.rng.normal(0, sigma)
            genes = np.clip(genes, GENE_LOWER, GENE_UPPER)
            population.append(Individual(genes=genes))

        # Random individuals: uniform over full bounds
        for _ in range(n_random):
            genes = self.rng.uniform(GENE_LOWER, GENE_UPPER)
            population.append(Individual(genes=genes))

        return population

    # ──────────────────────────────────────────────────────────────────────────
    #  FITNESS EVALUATION
    # ──────────────────────────────────────────────────────────────────────────

    def _evaluate(self, ind: Individual) -> None:
        """
        Evaluate fitness for a single individual by calling the simulation.

        Assigns fitness, ber, density, and feasible flag in-place.
        """
        params = ind.to_params()
        try:
            ber, density, fom = self.evaluate_fn(params)
        except Exception as exc:
            _logger.warning(f"Evaluation failed: {exc}")
            ber, density, fom = 1.0, 0.0, 0.0

        self._eval_count += 1
        ind.ber     = float(ber)
        ind.density = float(density)
        ind.feasible = ber <= self.opt_config.ber_target

        if ind.feasible:
            ind.fitness = float(fom)
        else:
            # Penalty proportional to BER constraint violation
            penalty = (ber / self.opt_config.ber_target - 1.0) * 0.5
            ind.fitness = -float(penalty)

    def _evaluate_population(self, population: list[Individual]) -> None:
        """Evaluate all unevaluated individuals in the population."""
        unevaluated = [ind for ind in population if ind.fitness is None]
        for ind in unevaluated:
            self._evaluate(ind)

    # ──────────────────────────────────────────────────────────────────────────
    #  SELECTION
    # ──────────────────────────────────────────────────────────────────────────

    def _tournament_select(self, population: list[Individual],
                            k: int = 3) -> Individual:
        """
        Tournament selection: pick k random individuals, return the best.

        Parameters
        ----------
        population : Current population
        k          : Tournament size
        """
        competitors = self.rng.choice(len(population), size=k, replace=False)
        best_idx    = max(competitors, key=lambda i: population[i].fitness or -1e9)
        return population[best_idx].clone()

    # ──────────────────────────────────────────────────────────────────────────
    #  CROSSOVER OPERATORS
    # ──────────────────────────────────────────────────────────────────────────

    def _uniform_crossover(self, parent1: Individual,
                            parent2: Individual) -> tuple[Individual, Individual]:
        """
        Uniform crossover: each gene independently chosen from either parent.
        """
        mask    = self.rng.random(N_GENES) < 0.5
        genes_c1 = np.where(mask, parent1.genes, parent2.genes)
        genes_c2 = np.where(mask, parent2.genes, parent1.genes)
        return Individual(genes=genes_c1), Individual(genes=genes_c2)

    def _arithmetic_crossover(self, parent1: Individual,
                               parent2: Individual) -> tuple[Individual, Individual]:
        """
        Arithmetic (blend) crossover: BLX-α with α=0.2.

        Offspring genes sampled uniformly from expanded interval between parents.
        """
        alpha    = 0.2
        lo       = np.minimum(parent1.genes, parent2.genes)
        hi       = np.maximum(parent1.genes, parent2.genes)
        span     = hi - lo

        genes_c1 = self.rng.uniform(lo - alpha * span, hi + alpha * span)
        genes_c2 = self.rng.uniform(lo - alpha * span, hi + alpha * span)

        genes_c1 = np.clip(genes_c1, GENE_LOWER, GENE_UPPER)
        genes_c2 = np.clip(genes_c2, GENE_LOWER, GENE_UPPER)
        return Individual(genes=genes_c1), Individual(genes=genes_c2)

    def _crossover(self, parent1: Individual,
                   parent2: Individual) -> tuple[Individual, Individual]:
        """
        Apply crossover with probability cx_rate.
        Alternates between uniform and arithmetic crossover.
        """
        if self.rng.random() > self.opt_config.crossover_rate:
            return parent1.clone(), parent2.clone()
        # Alternate between crossover operators
        if self._eval_count % 2 == 0:
            return self._uniform_crossover(parent1, parent2)
        else:
            return self._arithmetic_crossover(parent1, parent2)

    # ──────────────────────────────────────────────────────────────────────────
    #  MUTATION OPERATORS
    # ──────────────────────────────────────────────────────────────────────────

    def _mutate(self, ind: Individual, generation: int,
                n_generations: int) -> Individual:
        """
        Gaussian mutation with adaptive sigma decay.

        Mutation sigma decreases over generations (exploration → exploitation):
            σ(g) = σ_max · (1 - g / n_gen)^2

        Each gene mutated independently with probability mutation_rate.
        """
        sigma_max = (GENE_UPPER - GENE_LOWER) * 0.15
        decay     = (1.0 - generation / n_generations) ** 2.0
        sigma     = sigma_max * decay

        new_genes = ind.genes.copy()
        for i in range(N_GENES):
            if self.rng.random() < self.opt_config.mutation_rate:
                new_genes[i] += self.rng.normal(0.0, sigma[i])

        new_genes = np.clip(new_genes, GENE_LOWER, GENE_UPPER)
        return Individual(genes=new_genes)

    # ──────────────────────────────────────────────────────────────────────────
    #  DIVERSITY MEASURE
    # ──────────────────────────────────────────────────────────────────────────

    def _population_diversity(self, population: list[Individual]) -> float:
        """
        Compute mean pairwise Euclidean distance (normalised) between individuals.
        Diversity → 0 means converged; diversity → 1 means maximally spread.
        """
        genes_matrix = np.vstack([ind.genes for ind in population])
        # Normalise to [0, 1] range
        ranges       = GENE_UPPER - GENE_LOWER
        genes_norm   = (genes_matrix - GENE_LOWER) / ranges

        n = len(population)
        if n < 2:
            return 0.0

        # Sample pairs for efficiency with large populations
        n_pairs = min(500, n * (n - 1) // 2)
        total_dist = 0.0
        for _ in range(n_pairs):
            i, j = self.rng.choice(n, size=2, replace=False)
            total_dist += float(np.linalg.norm(genes_norm[i] - genes_norm[j]))
        return total_dist / (n_pairs * np.sqrt(N_GENES))

    # ──────────────────────────────────────────────────────────────────────────
    #  GENERATION STATISTICS
    # ──────────────────────────────────────────────────────────────────────────

    def _compute_gen_stats(self, population: list[Individual],
                            gen: int) -> GenerationStats:
        """Compute statistics for the current generation."""
        fitnesses   = [ind.fitness or -1e9 for ind in population]
        feasible    = [ind for ind in population if ind.feasible]

        best_ind    = max(population, key=lambda x: x.fitness or -1e9)
        best_ber    = best_ind.ber    or 1.0
        best_dens   = best_ind.density or 0.0
        diversity   = self._population_diversity(population)

        return GenerationStats(
            generation      = gen,
            best_fitness    = float(max(fitnesses)),
            mean_fitness    = float(np.mean(fitnesses)),
            best_ber        = best_ber,
            best_density    = best_dens,
            n_feasible      = len(feasible),
            population_size = len(population),
            diversity       = diversity,
        )

    # ──────────────────────────────────────────────────────────────────────────
    #  MAIN OPTIMISATION LOOP
    # ──────────────────────────────────────────────────────────────────────────

    def optimise(self) -> GAResult:
        """
        Execute the Genetic Algorithm optimisation.

        Returns
        -------
        GAResult with best parameters, BER, density, and convergence history
        """
        pop_size   = self.opt_config.population_size
        n_gen      = self.opt_config.n_generations
        elite_n    = max(1, int(pop_size * self.opt_config.elite_fraction))

        _logger.info(
            f"GA optimisation start: "
            f"pop={pop_size}, gen={n_gen}, elite={elite_n}"
        )

        # Initialise and evaluate initial population
        population = self._init_population(pop_size)
        self._evaluate_population(population)

        convergence: list[GenerationStats] = []
        progress = ProgressLogger(n_gen, "GA Optimisation", logger=_logger)

        for gen in range(n_gen):
            # Sort population by fitness (descending)
            population.sort(key=lambda x: x.fitness or -1e9, reverse=True)

            # Compute and log generation statistics
            stats = self._compute_gen_stats(population, gen)
            convergence.append(stats)

            if gen % 5 == 0 or gen == n_gen - 1:
                _logger.info(
                    f"Gen {gen:>4d} | best_fom={stats.best_fitness:>8.6f} | "
                    f"BER={stats.best_ber:.2e} | "
                    f"density={stats.best_density:.3f} Tb/in² | "
                    f"feasible={stats.n_feasible}/{pop_size} | "
                    f"diversity={stats.diversity:.4f}"
                )

            # Elitism: preserve top individuals
            new_population: list[Individual] = [ind.clone()
                                                  for ind in population[:elite_n]]

            # Generate offspring via selection + crossover + mutation
            while len(new_population) < pop_size:
                parent1 = self._tournament_select(population)
                parent2 = self._tournament_select(population)
                child1, child2 = self._crossover(parent1, parent2)
                child1 = self._mutate(child1, gen, n_gen)
                child2 = self._mutate(child2, gen, n_gen)
                new_population.append(child1)
                if len(new_population) < pop_size:
                    new_population.append(child2)

            # Evaluate new offspring only
            self._evaluate_population(new_population)
            population = new_population

            progress.update(gen + 1)

            # Early convergence check
            if gen > 20 and stats.diversity < 0.005:
                _logger.info(f"Convergence detected at generation {gen}")
                break

        progress.done()

        # Extract best individual
        population.sort(key=lambda x: x.fitness or -1e9, reverse=True)

        # Prefer best feasible; fall back to best overall
        feasibles = [ind for ind in population if ind.feasible]
        best = feasibles[0] if feasibles else population[0]

        _logger.info(
            f"GA complete: best_fom={best.fitness:.6f}, "
            f"BER={best.ber:.2e}, "
            f"density={best.density:.4f} Tb/in², "
            f"feasible={best.feasible}, "
            f"evals={self._eval_count}"
        )

        return GAResult(
            best_params          = best.to_params(),
            best_fitness         = best.fitness or 0.0,
            best_ber             = best.ber     or 1.0,
            best_density_tbpin2  = best.density or 0.0,
            n_generations        = len(convergence),
            convergence_history  = convergence,
            feasible             = best.feasible,
        )

    def get_eval_count(self) -> int:
        """Return total number of fitness evaluations performed."""
        return self._eval_count
