"""
HAMR-X CORE :: optimisation/brute_force.py
                optimisation/bayesian.py
=============================================
Brute-force grid search and Bayesian optimisation for HAMR-X.

BruteForceOptimiser  — systematic grid search over parameter space
BayesianOptimiser    — Gaussian Process surrogate model with UCB acquisition
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Callable, Optional
import itertools

from ..utils.config import HAMRConfig, OptimisationConfig, OPTIMISATION_BOUNDS
from ..utils.logging import get_logger, ProgressLogger, timed_section


_logger_bf  = get_logger("optimisation.brute_force")
_logger_bay = get_logger("optimisation.bayesian")


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 1: BRUTE-FORCE GRID SEARCH
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class GridSearchResult:
    """
    Result of brute-force grid search optimisation.

    Attributes
    ----------
    best_params         : Optimal parameter dictionary
    best_ber            : BER at optimal parameters
    best_density_tbpin2 : Density at optimal parameters
    best_fom            : Figure of Merit at optimal parameters
    n_evaluations       : Total parameter combinations evaluated
    feasible_count      : Number of feasible configurations found
    results_table       : All evaluated configurations (list of dicts)
    """
    best_params:          dict[str, float]
    best_ber:             float
    best_density_tbpin2:  float
    best_fom:             float
    n_evaluations:        int
    feasible_count:       int
    results_table:        list[dict]


class BruteForceOptimiser:
    """
    Systematic grid search over a reduced HAMR parameter space.

    Performs exhaustive evaluation of parameter combinations on a
    coarse grid to identify promising regions for subsequent fine-grained
    or GA-based optimisation.

    For computational tractability, only 3-4 key parameters are swept
    at a time. The grid resolution trades coverage against compute cost.

    Parameters
    ----------
    config        : HAMRConfig master configuration
    evaluate_fn   : Function (params_dict) → (ber, density, fom)
    opt_config    : OptimisationConfig
    n_grid_points : Number of grid points per parameter (default 6)
    """

    # Parameters selected for grid search (highest impact on density/BER)
    _SWEEP_PARAMS: list[str] = [
        "laser_power_mw",
        "track_spacing_nm",
        "bit_length_nm",
        "head_precision",
    ]

    def __init__(self,
                 config:        HAMRConfig,
                 evaluate_fn:   Callable[[dict[str, float]], tuple[float, float, float]],
                 opt_config:    Optional[OptimisationConfig] = None,
                 n_grid_points: int = 6) -> None:
        self.config        = config
        self.evaluate_fn   = evaluate_fn
        self.opt_config    = opt_config or config.optimisation
        self.n_grid_points = n_grid_points
        _logger_bf.info(
            f"Brute-force optimiser: "
            f"{len(self._SWEEP_PARAMS)} params × {n_grid_points} pts = "
            f"{n_grid_points ** len(self._SWEEP_PARAMS):,} combinations"
        )

    def _build_grid(self) -> dict[str, np.ndarray]:
        """Build the parameter grid over selected sweep parameters."""
        grid = {}
        for param in self._SWEEP_PARAMS:
            lo, hi = OPTIMISATION_BOUNDS[param]
            grid[param] = np.linspace(lo, hi, self.n_grid_points)
        return grid

    def _default_params(self) -> dict[str, float]:
        """Return default values for non-swept parameters from current config."""
        return {
            "laser_power_mw":    self.config.laser.power_mw,
            "pulse_duration_ns": self.config.laser.pulse_duration_ns,
            "spot_radius_nm":    self.config.laser.spot_radius_nm,
            "track_spacing_nm":  self.config.density.track_spacing_nm,
            "bit_length_nm":     self.config.density.bit_length_nm,
            "head_precision":    self.config.head.precision,
            "write_temp_k":      self.config.medium.write_temp_k,
            "nft_efficiency":    self.config.laser.nft_efficiency,
        }

    def optimise(self, ber_target: Optional[float] = None) -> GridSearchResult:
        """
        Execute the brute-force grid search.

        Parameters
        ----------
        ber_target : Maximum acceptable BER; uses opt_config default if None

        Returns
        -------
        GridSearchResult with best configuration and full results table
        """
        ber_target = ber_target or self.opt_config.ber_target
        grid       = self._build_grid()
        defaults   = self._default_params()

        # Generate all combinations
        param_values = [grid[p] for p in self._SWEEP_PARAMS]
        combinations = list(itertools.product(*param_values))
        n_total      = len(combinations)

        _logger_bf.info(f"Grid search: evaluating {n_total:,} combinations")
        progress     = ProgressLogger(n_total, "Grid Search", report_pct=10.0,
                                        logger=_logger_bf)

        best_fom     = -1e9
        best_params  = defaults.copy()
        best_ber     = 1.0
        best_density = 0.0
        feasible_count = 0
        results_table: list[dict] = []

        for i, combo in enumerate(combinations):
            # Build parameter dict for this combination
            params = defaults.copy()
            for pname, pval in zip(self._SWEEP_PARAMS, combo):
                params[pname] = float(pval)

            try:
                ber, density, fom = self.evaluate_fn(params)
            except Exception as exc:
                _logger_bf.debug(f"Eval error at combo {i}: {exc}")
                ber, density, fom = 1.0, 0.0, 0.0

            feasible = ber <= ber_target
            if feasible:
                feasible_count += 1

            # Record result
            record = {**params, "ber": ber, "density": density,
                      "fom": fom, "feasible": feasible}
            results_table.append(record)

            # Track best feasible configuration
            if feasible and fom > best_fom:
                best_fom     = fom
                best_params  = params.copy()
                best_ber     = ber
                best_density = density

            progress.update(i + 1)

        progress.done()

        # If no feasible config found, return best by fom regardless
        if best_fom < -1e8:
            best_record  = max(results_table, key=lambda r: r["fom"])
            best_params  = {k: v for k, v in best_record.items()
                            if k in defaults}
            best_ber     = best_record["ber"]
            best_density = best_record["density"]
            best_fom     = best_record["fom"]

        _logger_bf.info(
            f"Grid search complete: "
            f"best_fom={best_fom:.6f}, "
            f"BER={best_ber:.2e}, "
            f"density={best_density:.4f} Tb/in², "
            f"feasible={feasible_count}/{n_total}"
        )

        return GridSearchResult(
            best_params          = best_params,
            best_ber             = best_ber,
            best_density_tbpin2  = best_density,
            best_fom             = best_fom,
            n_evaluations        = n_total,
            feasible_count       = feasible_count,
            results_table        = results_table,
        )

    def sensitivity_sweep(self,
                           param_name: str,
                           n_points:   int = 20) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Single-parameter sensitivity sweep holding all others at default.

        Parameters
        ----------
        param_name : Parameter to sweep
        n_points   : Number of evaluation points

        Returns
        -------
        (param_values, ber_array, density_array)
        """
        lo, hi   = OPTIMISATION_BOUNDS[param_name]
        p_values = np.linspace(lo, hi, n_points)
        defaults = self._default_params()

        bers, densities = [], []
        for pval in p_values:
            params = defaults.copy()
            params[param_name] = float(pval)
            try:
                ber, density, _ = self.evaluate_fn(params)
            except Exception:
                ber, density = 1.0, 0.0
            bers.append(ber)
            densities.append(density)

        return p_values, np.array(bers), np.array(densities)


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 2: BAYESIAN OPTIMISATION (GAUSSIAN PROCESS)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class BayesianResult:
    """
    Result of Bayesian optimisation.

    Attributes
    ----------
    best_params         : Optimal parameter dictionary
    best_fom            : Best FoM achieved
    best_ber            : BER at optimal parameters
    best_density_tbpin2 : Density at optimal parameters
    n_iterations        : Number of evaluations performed
    acquisition_history : Acquisition function values per iteration
    surrogate_rmse      : Final GP surrogate model RMSE
    feasible            : Whether best solution is feasible
    """
    best_params:          dict[str, float]
    best_fom:             float
    best_ber:             float
    best_density_tbpin2:  float
    n_iterations:         int
    acquisition_history:  list[float]
    surrogate_rmse:       float
    feasible:             bool


class BayesianOptimiser:
    """
    Bayesian optimisation using a Gaussian Process surrogate model
    with Upper Confidence Bound (UCB) acquisition function.

    GP kernel: Matérn 5/2 (captures smooth but non-infinitely-differentiable
    objective surfaces typical of engineering systems).

    UCB acquisition: f_acq(x) = μ(x) + κ·σ(x)
    where κ balances exploration (high σ) vs exploitation (high μ).

    Parameters
    ----------
    config         : HAMRConfig master configuration
    evaluate_fn    : Function (params_dict) → (ber, density, fom)
    opt_config     : OptimisationConfig
    kappa          : UCB exploration parameter (default 2.576 → 99% CI)
    seed           : RNG seed
    """

    def __init__(self,
                 config:      HAMRConfig,
                 evaluate_fn: Callable[[dict[str, float]], tuple[float, float, float]],
                 opt_config:  Optional[OptimisationConfig] = None,
                 kappa:       float = 2.576,
                 seed:        int   = 42) -> None:
        self.config      = config
        self.evaluate_fn = evaluate_fn
        self.opt_config  = opt_config or config.optimisation
        self.kappa       = kappa
        self.rng         = np.random.default_rng(seed)

        # Gene names for this optimiser (subset for tractability)
        self._param_names = list(OPTIMISATION_BOUNDS.keys())
        self._n_params    = len(self._param_names)
        self._lower       = np.array([OPTIMISATION_BOUNDS[p][0]
                                       for p in self._param_names])
        self._upper       = np.array([OPTIMISATION_BOUNDS[p][1]
                                       for p in self._param_names])

        # Data storage for GP
        self._X: list[np.ndarray] = []   # evaluated parameter vectors
        self._y: list[float]      = []   # corresponding FoM values (penalty-adjusted)
        self._ber_log: list[float] = []

        _logger_bay.info(
            f"Bayesian optimiser: n_init={opt_config and opt_config.bayesian_n_init or 10}, "
            f"n_iter={opt_config and opt_config.bayesian_n_iter or 50}, "
            f"kappa={kappa}"
        )

    # ──────────────────────────────────────────────────────────────────────────
    #  UTILITY FUNCTIONS
    # ──────────────────────────────────────────────────────────────────────────

    def _normalise(self, x: np.ndarray) -> np.ndarray:
        """Normalise parameter vector to [0, 1]^d."""
        return (x - self._lower) / (self._upper - self._lower)

    def _denormalise(self, x_norm: np.ndarray) -> np.ndarray:
        """Map normalised vector back to physical parameter space."""
        return x_norm * (self._upper - self._lower) + self._lower

    def _vec_to_params(self, x: np.ndarray) -> dict[str, float]:
        """Convert parameter vector to named dictionary."""
        return {name: float(v) for name, v in zip(self._param_names, x)}

    # ──────────────────────────────────────────────────────────────────────────
    #  GP KERNEL (Matérn 5/2)
    # ──────────────────────────────────────────────────────────────────────────

    def _matern52_kernel(self, X1: np.ndarray, X2: np.ndarray,
                          length_scale: float = 0.3,
                          amplitude:    float = 1.0) -> np.ndarray:
        """
        Matérn 5/2 covariance kernel.

        k(r) = A²·(1 + √5·r/l + 5r²/(3l²)) · exp(-√5·r/l)

        Parameters
        ----------
        X1, X2        : Input matrices (n1×d, n2×d), already normalised to [0,1]
        length_scale  : Characteristic length scale
        amplitude     : Signal variance

        Returns
        -------
        Covariance matrix of shape (n1, n2)
        """
        # Pairwise squared distances
        n1, n2 = X1.shape[0], X2.shape[0]
        K = np.zeros((n1, n2))

        for i in range(n1):
            diff = X2 - X1[i]
            r_sq = np.sum(diff ** 2, axis=1)
            r    = np.sqrt(np.maximum(r_sq, 0.0)) / length_scale
            sqrt5r = np.sqrt(5.0) * r
            K[i]   = (amplitude ** 2
                      * (1.0 + sqrt5r + 5.0 * r_sq / (3.0 * length_scale ** 2))
                      * np.exp(-sqrt5r))

        return K

    # ──────────────────────────────────────────────────────────────────────────
    #  GP POSTERIOR PREDICTION
    # ──────────────────────────────────────────────────────────────────────────

    def _gp_predict(self, X_train: np.ndarray, y_train: np.ndarray,
                     X_test:  np.ndarray,
                     noise:   float = 1e-4) -> tuple[np.ndarray, np.ndarray]:
        """
        Compute GP posterior mean and standard deviation at test points.

        Parameters
        ----------
        X_train : Training inputs (n_train × d)
        y_train : Training targets (n_train,)
        X_test  : Test inputs (n_test × d)
        noise   : Observation noise variance

        Returns
        -------
        (mu, sigma) arrays of length n_test
        """
        if len(X_train) == 0:
            n_test = X_test.shape[0]
            return np.zeros(n_test), np.ones(n_test)

        K_train = self._matern52_kernel(X_train, X_train)
        K_train += noise * np.eye(len(X_train))
        K_star  = self._matern52_kernel(X_test, X_train)
        K_ss    = np.diag(self._matern52_kernel(X_test, X_test))

        try:
            L    = np.linalg.cholesky(K_train)
            alpha = np.linalg.solve(L.T, np.linalg.solve(L, y_train))
            mu    = K_star @ alpha

            v     = np.linalg.solve(L, K_star.T)
            var   = K_ss - np.sum(v ** 2, axis=0)
            sigma = np.sqrt(np.maximum(var, 1e-10))
        except np.linalg.LinAlgError:
            # Fallback if Cholesky fails (ill-conditioned matrix)
            n_test = X_test.shape[0]
            mu   = np.full(n_test, float(np.mean(y_train)))
            sigma = np.ones(n_test)

        return mu, sigma

    # ──────────────────────────────────────────────────────────────────────────
    #  ACQUISITION FUNCTION (UCB)
    # ──────────────────────────────────────────────────────────────────────────

    def _ucb_acquisition(self, X_cand: np.ndarray,
                          X_train: np.ndarray,
                          y_train: np.ndarray) -> np.ndarray:
        """
        Upper Confidence Bound (UCB) acquisition function.

        UCB(x) = μ(x) + κ·σ(x)

        Parameters
        ----------
        X_cand  : Candidate points (n_cand × d), normalised
        X_train : Training points (n_train × d), normalised
        y_train : Observed FoM values

        Returns
        -------
        UCB values for each candidate
        """
        mu, sigma = self._gp_predict(X_train, y_train, X_cand)
        return mu + self.kappa * sigma

    # ──────────────────────────────────────────────────────────────────────────
    #  NEXT POINT SUGGESTION
    # ──────────────────────────────────────────────────────────────────────────

    def _suggest_next(self, X_train: np.ndarray,
                       y_train: np.ndarray,
                       n_candidates: int = 2000) -> np.ndarray:
        """
        Suggest next evaluation point by maximising UCB over random candidates.

        Parameters
        ----------
        X_train     : Existing normalised training data
        y_train     : Corresponding FoM values
        n_candidates: Number of random candidates to evaluate

        Returns
        -------
        Best candidate parameter vector (normalised)
        """
        X_cand    = self.rng.uniform(0.0, 1.0, size=(n_candidates, self._n_params))
        acq_vals  = self._ucb_acquisition(X_cand, X_train, y_train)
        best_idx  = int(np.argmax(acq_vals))
        return X_cand[best_idx]

    # ──────────────────────────────────────────────────────────────────────────
    #  MAIN OPTIMISATION LOOP
    # ──────────────────────────────────────────────────────────────────────────

    def optimise(self) -> BayesianResult:
        """
        Execute the Bayesian optimisation loop.

        Phase 1: Random initialisation (n_init evaluations)
        Phase 2: GP-guided Bayesian optimisation (n_iter evaluations)

        Returns
        -------
        BayesianResult with optimal parameters and surrogate model quality
        """
        n_init = self.opt_config.bayesian_n_init
        n_iter = self.opt_config.bayesian_n_iter
        ber_target = self.opt_config.ber_target

        _logger_bay.info(
            f"Bayesian opt start: n_init={n_init}, n_iter={n_iter}"
        )

        acq_history: list[float] = []

        # ── Phase 1: Random initialisation ───────────────────────────────────
        _logger_bay.info("Phase 1: Random initialisation")
        for i in range(n_init):
            x_norm  = self.rng.uniform(0.0, 1.0, size=self._n_params)
            x_phys  = self._denormalise(x_norm)
            params  = self._vec_to_params(x_phys)
            try:
                ber, density, fom = self.evaluate_fn(params)
            except Exception:
                ber, density, fom = 1.0, 0.0, 0.0

            # Penalty-adjusted objective
            feasible = ber <= ber_target
            if feasible:
                adjusted_fom = fom
            else:
                penalty      = (ber / ber_target - 1.0) * 0.3
                adjusted_fom = -penalty

            self._X.append(x_norm)
            self._y.append(adjusted_fom)
            self._ber_log.append(ber)
            acq_history.append(adjusted_fom)

        # ── Phase 2: Bayesian guided search ──────────────────────────────────
        _logger_bay.info("Phase 2: GP-guided search")
        progress = ProgressLogger(n_iter, "Bayesian Opt", logger=_logger_bay)

        for i in range(n_iter):
            X_arr    = np.vstack(self._X)
            y_arr    = np.array(self._y)

            # Suggest next point via UCB
            x_next_norm = self._suggest_next(X_arr, y_arr)
            x_next_phys = self._denormalise(x_next_norm)
            params       = self._vec_to_params(x_next_phys)

            try:
                ber, density, fom = self.evaluate_fn(params)
            except Exception:
                ber, density, fom = 1.0, 0.0, 0.0

            feasible = ber <= ber_target
            if feasible:
                adjusted_fom = fom
            else:
                penalty      = (ber / ber_target - 1.0) * 0.3
                adjusted_fom = -penalty

            self._X.append(x_next_norm)
            self._y.append(adjusted_fom)
            self._ber_log.append(ber)
            acq_history.append(adjusted_fom)

            if i % 10 == 0:
                best_so_far = max(v for v, b in zip(self._y, self._ber_log)
                                   if b <= ber_target) if any(
                                       b <= ber_target for b in self._ber_log
                                   ) else max(self._y)
                _logger_bay.info(
                    f"Iter {n_init + i:>4d} | "
                    f"BER={ber:.2e} | fom={fom:.6f} | "
                    f"best_fom={best_so_far:.6f}"
                )
            progress.update(i + 1)

        progress.done()

        # ── Extract best result ───────────────────────────────────────────────
        # Prefer best feasible
        feasible_mask   = np.array(self._ber_log) <= ber_target
        y_arr           = np.array(self._y)

        if feasible_mask.any():
            feasible_indices = np.where(feasible_mask)[0]
            best_idx         = feasible_indices[np.argmax(y_arr[feasible_indices])]
            feasible_result  = True
        else:
            best_idx        = int(np.argmax(y_arr))
            feasible_result = False

        best_x_norm   = self._X[best_idx]
        best_x_phys   = self._denormalise(best_x_norm)
        best_params   = self._vec_to_params(best_x_phys)
        best_fom      = float(y_arr[best_idx])
        best_ber      = float(self._ber_log[best_idx])

        # Evaluate best point fresh for accurate density
        try:
            _, best_density, _ = self.evaluate_fn(best_params)
        except Exception:
            best_density = 0.0

        # GP surrogate RMSE (leave-one-out estimate)
        X_arr   = np.vstack(self._X)
        n_train = len(y_arr)
        loo_errors = []
        for j in range(min(20, n_train)):
            mask   = np.ones(n_train, dtype=bool)
            mask[j] = False
            mu, _  = self._gp_predict(X_arr[mask], y_arr[mask],
                                        X_arr[j:j+1])
            loo_errors.append((mu[0] - y_arr[j]) ** 2)
        surrogate_rmse = float(np.sqrt(np.mean(loo_errors))) if loo_errors else 0.0

        _logger_bay.info(
            f"Bayesian opt complete: "
            f"best_fom={best_fom:.6f}, "
            f"BER={best_ber:.2e}, "
            f"density={best_density:.4f} Tb/in², "
            f"feasible={feasible_result}, "
            f"GP_RMSE={surrogate_rmse:.4f}"
        )

        return BayesianResult(
            best_params          = best_params,
            best_fom             = best_fom,
            best_ber             = best_ber,
            best_density_tbpin2  = best_density,
            n_iterations         = n_init + n_iter,
            acquisition_history  = acq_history,
            surrogate_rmse       = surrogate_rmse,
            feasible             = feasible_result,
        )
