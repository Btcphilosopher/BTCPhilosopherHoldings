"""
HAMR-X CORE :: visualization/plots.py
=======================================
Complete visualisation suite for the HAMR-X simulation platform.

Generates engineering-grade Plotly figures for all key trade-offs
and performance metrics. Anglo-industrial aesthetic:
  - Background: #0e0e0e (near-black)
  - Accent gold: #c9a84c
  - Accent cyan: #00d4e0
  - Accent red:  #e05252
  - Grid:        #1e1e1e
  - Text:        #d0d0d0
  - Font:        system monospace
"""

from __future__ import annotations
import numpy as np
from typing import Optional, TYPE_CHECKING
import os

try:
    import plotly.graph_objects as go
    import plotly.subplots as sp
    from plotly.subplots import make_subplots
    PLOTLY_AVAILABLE = True
except ImportError:
    PLOTLY_AVAILABLE = False

try:
    import matplotlib.pyplot as plt
    import matplotlib.ticker as mticker
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False

if TYPE_CHECKING:
    from ..core.simulation_engine import SimulationResult
    from ..optimisation.genetic import GAResult

from ..utils.logging import get_logger

_logger = get_logger("visualization.plots")

# ─────────────────────────────────────────────────────────────────────────────
#  DESIGN TOKENS
# ─────────────────────────────────────────────────────────────────────────────

PALETTE = {
    "bg":          "#0a0a0a",
    "bg_plot":     "#0e0e0e",
    "bg_panel":    "#131313",
    "grid":        "#1c1c1c",
    "border":      "#2a2a2a",
    "gold":        "#c9a84c",
    "gold_dim":    "#8a6e2f",
    "cyan":        "#00d4e0",
    "cyan_dim":    "#007a82",
    "red":         "#e05252",
    "green":       "#52c082",
    "white":       "#d8d8d8",
    "grey":        "#606060",
    "text_title":  "#e8e8e8",
    "text_label":  "#a0a0a0",
}

_PLOTLY_LAYOUT = dict(
    paper_bgcolor  = PALETTE["bg"],
    plot_bgcolor   = PALETTE["bg_plot"],
    font           = dict(family="JetBrains Mono, Consolas, monospace",
                          color=PALETTE["text_label"], size=11),
    title_font     = dict(family="JetBrains Mono, Consolas, monospace",
                          color=PALETTE["text_title"], size=14),
    xaxis          = dict(gridcolor=PALETTE["grid"], linecolor=PALETTE["border"],
                          tickfont=dict(color=PALETTE["text_label"])),
    yaxis          = dict(gridcolor=PALETTE["grid"], linecolor=PALETTE["border"],
                          tickfont=dict(color=PALETTE["text_label"])),
    legend         = dict(bgcolor=PALETTE["bg_panel"],
                          bordercolor=PALETTE["border"],
                          font=dict(color=PALETTE["text_label"])),
    margin         = dict(l=60, r=30, t=60, b=50),
)


def _apply_layout(fig: "go.Figure", title: str = "",
                   xaxis_title: str = "", yaxis_title: str = "") -> None:
    """Apply standard HAMR-X layout theme to a figure."""
    fig.update_layout(
        **_PLOTLY_LAYOUT,
        title=dict(text=title, x=0.02, font=dict(
            color=PALETTE["gold"], size=13,
            family="JetBrains Mono, Consolas, monospace"
        )),
        xaxis_title=xaxis_title,
        yaxis_title=yaxis_title,
    )
    fig.update_xaxes(gridcolor=PALETTE["grid"], linecolor=PALETTE["border"],
                      zerolinecolor=PALETTE["border"])
    fig.update_yaxes(gridcolor=PALETTE["grid"], linecolor=PALETTE["border"],
                      zerolinecolor=PALETTE["border"])


# ─────────────────────────────────────────────────────────────────────────────
#  PLOT 1: DENSITY vs BER TRADE-OFF
# ─────────────────────────────────────────────────────────────────────────────

def plot_density_vs_ber(result: "SimulationResult",
                          ber_target: float = 1e-6,
                          output_dir: Optional[str] = None) -> Optional["go.Figure"]:
    """
    Plot areal density vs post-ECC BER trade-off curve.

    Shows the fundamental storage density / error rate constraint,
    with the BER target line overlaid.
    """
    if not PLOTLY_AVAILABLE:
        _logger.warning("Plotly not available — skipping plot")
        return None

    history = result.metrics_history
    if not history:
        return None

    densities = [m.areal_density_tbpin2 for m in history]
    bers      = [m.post_ecc_ber         for m in history]
    cycles    = [m.cycle_number          for m in history]

    fig = go.Figure()

    # Scatter: density vs BER, coloured by simulation cycle
    fig.add_trace(go.Scatter(
        x    = densities,
        y    = bers,
        mode = "markers",
        marker = dict(
            color      = cycles,
            colorscale = [[0, PALETTE["cyan_dim"]], [1, PALETTE["gold"]]],
            size       = 5,
            opacity    = 0.8,
            colorbar   = dict(
                title      = "Cycle",
                tickfont   = dict(color=PALETTE["text_label"]),
                titlefont  = dict(color=PALETTE["text_label"]),
                outlinecolor = PALETTE["border"],
            ),
        ),
        name       = "Simulation snapshots",
        showlegend = True,
    ))

    # BER target line
    if densities:
        x_range = [min(densities) * 0.95, max(densities) * 1.05]
        fig.add_trace(go.Scatter(
            x    = x_range,
            y    = [ber_target, ber_target],
            mode = "lines",
            line = dict(color=PALETTE["red"], width=1.5, dash="dash"),
            name = f"BER target ({ber_target:.0e})",
        ))

    fig.update_yaxes(type="log")
    _apply_layout(fig,
                   title="DENSITY vs BER TRADE-OFF  ::  HAMR-X",
                   xaxis_title="Areal Density (Tb/in²)",
                   yaxis_title="Post-ECC Bit Error Rate")

    if output_dir:
        _save_figure(fig, output_dir, "density_vs_ber")
    return fig


# ─────────────────────────────────────────────────────────────────────────────
#  PLOT 2: TEMPERATURE vs WRITE SUCCESS PROBABILITY
# ─────────────────────────────────────────────────────────────────────────────

def plot_temperature_vs_write_success(config_medium_write_temp: float = 580.0,
                                        config_curie_temp: float = 750.0,
                                        output_dir: Optional[str] = None) -> Optional["go.Figure"]:
    """
    Plot write success probability as a function of peak temperature.
    """
    if not PLOTLY_AVAILABLE:
        return None

    temps = np.linspace(200.0, config_curie_temp + 50, 300)

    # Sigmoid-like success curve centred on write temperature
    def write_success_prob(T, T_write, T_curie, sharpness=0.04):
        x = sharpness * (T - T_write)
        return 1.0 / (1.0 + np.exp(-x)) * np.clip(1.0 - (T / T_curie)**4, 0, 1)

    probs = write_success_prob(temps, config_medium_write_temp, config_curie_temp)

    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x    = temps,
        y    = probs,
        mode = "lines",
        line = dict(color=PALETTE["gold"], width=2),
        name = "Write success probability",
        fill = "tozeroy",
        fillcolor = "rgba(201, 168, 76, 0.08)",
    ))

    # Write temperature marker
    fig.add_vline(
        x           = config_medium_write_temp,
        line_dash   = "dash",
        line_color  = PALETTE["cyan"],
        line_width  = 1.5,
        annotation_text = f" T_write = {config_medium_write_temp:.0f} K",
        annotation_font = dict(color=PALETTE["cyan"], size=10),
    )
    # Curie temperature marker
    fig.add_vline(
        x           = config_curie_temp,
        line_dash   = "dot",
        line_color  = PALETTE["red"],
        line_width  = 1.5,
        annotation_text = f" T_Curie = {config_curie_temp:.0f} K",
        annotation_font = dict(color=PALETTE["red"], size=10),
    )

    _apply_layout(fig,
                   title="TEMPERATURE vs WRITE SUCCESS PROBABILITY  ::  HAMR-X",
                   xaxis_title="Peak Temperature (K)",
                   yaxis_title="Write Success Probability")

    if output_dir:
        _save_figure(fig, output_dir, "temperature_vs_write_success")
    return fig


# ─────────────────────────────────────────────────────────────────────────────
#  PLOT 3: LASER POWER vs RELIABILITY
# ─────────────────────────────────────────────────────────────────────────────

def plot_laser_power_vs_reliability(result: "SimulationResult",
                                      output_dir: Optional[str] = None) -> Optional["go.Figure"]:
    """
    Plot laser power sweep effect on system reliability and BER.
    Uses the simulation engine's thermal model to compute peak temperatures
    across a power range, then estimates reliability.
    """
    if not PLOTLY_AVAILABLE:
        return None

    from ..physics.thermal_laser import ThermalLaserModel
    from ..utils.config import LaserConfig

    powers = np.linspace(1.0, 15.0, 50)
    cfg    = result.config.laser

    peak_temps   = []
    reliabilities = []
    bers          = []

    write_temp = result.config.medium.write_temp_k
    curie_temp = result.config.medium.curie_temp_k
    hc0        = result.config.medium.coercivity_oe

    for p in powers:
        laser_cfg = LaserConfig(
            power_mw          = p,
            spot_radius_nm    = cfg.spot_radius_nm,
            pulse_duration_ns = cfg.pulse_duration_ns,
            nft_efficiency    = cfg.nft_efficiency,
            thermal_diffusivity = cfg.thermal_diffusivity,
            heat_capacity     = cfg.heat_capacity,
            cooling_rate_ns   = cfg.cooling_rate_ns,
        )
        laser = ThermalLaserModel(laser_cfg)
        t_peak = laser.peak_temperature_end_of_pulse()
        peak_temps.append(t_peak)

        # Estimate write success from temperature proximity to write threshold
        if t_peak >= write_temp and t_peak < curie_temp:
            write_success = min(1.0, (t_peak - write_temp) / (curie_temp - write_temp) * 2)
        elif t_peak >= curie_temp:
            write_success = 0.95
        else:
            write_success = max(0.0, t_peak / write_temp * 0.5)

        # BER estimate from write success
        raw_ber = (1 - write_success) * 0.15 + 0.001
        post_ber = min(raw_ber ** 3.5, 1.0)
        bers.append(post_ber)

        # Reliability from BER
        log_ber   = np.log10(max(post_ber, 1e-15))
        reliab    = float(np.clip(-log_ber / 15.0, 0.0, 1.0))
        reliabilities.append(reliab)

    fig = make_subplots(rows=2, cols=1, shared_xaxes=True,
                         vertical_spacing=0.08)

    # Top: reliability
    fig.add_trace(go.Scatter(
        x=powers, y=reliabilities, mode="lines",
        line=dict(color=PALETTE["gold"], width=2),
        name="Reliability score",
    ), row=1, col=1)

    # Bottom: BER (log scale)
    fig.add_trace(go.Scatter(
        x=powers, y=bers, mode="lines",
        line=dict(color=PALETTE["cyan"], width=2),
        name="Post-ECC BER",
    ), row=2, col=1)

    # Write temp achievement line
    threshold_power = None
    for i, t in enumerate(peak_temps):
        if t >= write_temp:
            threshold_power = powers[i]
            break
    if threshold_power:
        for row in [1, 2]:
            fig.add_vline(x=threshold_power, line_dash="dash",
                           line_color=PALETTE["red"], line_width=1,
                           row=row, col=1)

    fig.update_yaxes(type="log", row=2, col=1,
                      gridcolor=PALETTE["grid"],
                      linecolor=PALETTE["border"])
    fig.update_yaxes(gridcolor=PALETTE["grid"],
                      linecolor=PALETTE["border"], row=1, col=1)
    fig.update_xaxes(gridcolor=PALETTE["grid"],
                      linecolor=PALETTE["border"])

    fig.update_layout(
        **_PLOTLY_LAYOUT,
        title=dict(text="LASER POWER vs RELIABILITY  ::  HAMR-X",
                    font=dict(color=PALETTE["gold"], size=13)),
        xaxis2_title="Laser Power (mW)",
    )
    fig.update_yaxes(title_text="Reliability [0-1]",  row=1, col=1,
                      title_font=dict(color=PALETTE["text_label"]))
    fig.update_yaxes(title_text="Post-ECC BER", row=2, col=1,
                      title_font=dict(color=PALETTE["text_label"]))

    if output_dir:
        _save_figure(fig, output_dir, "laser_power_vs_reliability")
    return fig


# ─────────────────────────────────────────────────────────────────────────────
#  PLOT 4: DEGRADATION OVER TIME
# ─────────────────────────────────────────────────────────────────────────────

def plot_degradation_over_time(result: "SimulationResult",
                                 output_dir: Optional[str] = None) -> Optional["go.Figure"]:
    """
    Plot medium health, coercivity factor, and BER evolution over simulation.
    """
    if not PLOTLY_AVAILABLE:
        return None

    history = result.metrics_history
    if not history:
        return None

    cycles    = [m.cycle_number        for m in history]
    health    = [m.degradation_health  for m in history]
    ber       = [m.post_ecc_ber        for m in history]
    write_suc = [m.write_success_rate  for m in history]

    # Degradation model curve
    dc_cycles, dc_coer, dc_health = result.degradation_curve
    dc_cycles_k = dc_cycles / 1000

    fig = make_subplots(rows=3, cols=1, shared_xaxes=True,
                         vertical_spacing=0.06)

    # Row 1: Medium health
    fig.add_trace(go.Scatter(
        x=cycles, y=health, mode="lines",
        line=dict(color=PALETTE["gold"], width=2),
        name="Medium health (sim)",
    ), row=1, col=1)
    fig.add_trace(go.Scatter(
        x=dc_cycles_k * max(cycles) / max(dc_cycles_k) if max(dc_cycles_k) > 0 else dc_cycles,
        y=dc_health, mode="lines",
        line=dict(color=PALETTE["gold_dim"], width=1, dash="dot"),
        name="Health model curve",
    ), row=1, col=1)

    # Row 2: BER
    fig.add_trace(go.Scatter(
        x=cycles, y=ber, mode="lines",
        line=dict(color=PALETTE["cyan"], width=2),
        name="Post-ECC BER",
        fill="tozeroy",
        fillcolor="rgba(0,212,224,0.05)",
    ), row=2, col=1)

    # Row 3: Write success rate
    fig.add_trace(go.Scatter(
        x=cycles, y=write_suc, mode="lines",
        line=dict(color=PALETTE["green"], width=2),
        name="Write success rate",
    ), row=3, col=1)

    fig.update_yaxes(type="log", row=2, col=1,
                      gridcolor=PALETTE["grid"], linecolor=PALETTE["border"])
    for row in [1, 3]:
        fig.update_yaxes(gridcolor=PALETTE["grid"], linecolor=PALETTE["border"],
                          row=row, col=1)
    fig.update_xaxes(gridcolor=PALETTE["grid"], linecolor=PALETTE["border"])

    fig.update_layout(
        **_PLOTLY_LAYOUT,
        title=dict(text="MEDIUM DEGRADATION OVER SIMULATION  ::  HAMR-X",
                    font=dict(color=PALETTE["gold"], size=13)),
    )
    fig.update_xaxes(title_text="Simulation Cycle", row=3, col=1)
    fig.update_yaxes(title_text="Health [0-1]",       row=1, col=1,
                      title_font=dict(color=PALETTE["text_label"]))
    fig.update_yaxes(title_text="BER",                row=2, col=1,
                      title_font=dict(color=PALETTE["text_label"]))
    fig.update_yaxes(title_text="Write Success [0-1]", row=3, col=1,
                      title_font=dict(color=PALETTE["text_label"]))

    if output_dir:
        _save_figure(fig, output_dir, "degradation_over_time")
    return fig


# ─────────────────────────────────────────────────────────────────────────────
#  PLOT 5: THERMAL SPOT PROFILE
# ─────────────────────────────────────────────────────────────────────────────

def plot_thermal_spot_profile(config_laser,
                                ambient_temp_k: float = 298.15,
                                write_temp_k:   float = 580.0,
                                output_dir: Optional[str] = None) -> Optional["go.Figure"]:
    """
    2D heatmap of the laser thermal spot profile on the recording medium.
    """
    if not PLOTLY_AVAILABLE:
        return None

    from ..physics.thermal_laser import ThermalLaserModel

    laser  = ThermalLaserModel(config_laser, ambient_temp_k)
    profile = laser.simulate_pulse(write_temp_k, generate_map=True)

    if profile.temperature_map is None:
        return None

    temp_map = profile.temperature_map
    extent   = config_laser.spot_radius_nm * 4
    n        = temp_map.shape[0]

    fig = go.Figure(data=go.Heatmap(
        z            = temp_map,
        x            = np.linspace(-extent, extent, n),
        y            = np.linspace(-extent, extent, n),
        colorscale   = [
            [0.0,   PALETTE["bg_plot"]],
            [0.3,   "#1a0a3a"],
            [0.55,  "#5e1a7a"],
            [0.75,  "#c83220"],
            [0.9,   "#e08020"],
            [1.0,   "#ffe060"],
        ],
        colorbar     = dict(
            title      = "Temperature (K)",
            tickfont   = dict(color=PALETTE["text_label"]),
            titlefont  = dict(color=PALETTE["text_label"]),
            outlinecolor = PALETTE["border"],
        ),
        zmin = ambient_temp_k,
        zmax = max(profile.peak_temperature_k, write_temp_k + 50),
    ))

    # Write zone contour
    fig.add_shape(
        type       = "circle",
        xref       = "x", yref = "y",
        x0 = -profile.effective_radius_nm,
        y0 = -profile.effective_radius_nm,
        x1 =  profile.effective_radius_nm,
        y1 =  profile.effective_radius_nm,
        line       = dict(color=PALETTE["cyan"], width=1.5, dash="dash"),
    )

    fig.update_layout(
        **_PLOTLY_LAYOUT,
        title=dict(
            text=f"NFT THERMAL SPOT PROFILE  ::  T_peak = {profile.peak_temperature_k:.0f} K",
            font=dict(color=PALETTE["gold"], size=13)
        ),
        xaxis_title="Cross-track position (nm)",
        yaxis_title="Down-track position (nm)",
        xaxis=dict(scaleanchor="y", scaleratio=1,
                    gridcolor=PALETTE["grid"]),
        yaxis=dict(gridcolor=PALETTE["grid"]),
    )

    if output_dir:
        _save_figure(fig, output_dir, "thermal_spot_profile")
    return fig


# ─────────────────────────────────────────────────────────────────────────────
#  PLOT 6: GA CONVERGENCE
# ─────────────────────────────────────────────────────────────────────────────

def plot_ga_convergence(ga_result: "GAResult",
                          output_dir: Optional[str] = None) -> Optional["go.Figure"]:
    """
    Plot Genetic Algorithm convergence: best and mean fitness per generation.
    """
    if not PLOTLY_AVAILABLE or not ga_result.convergence_history:
        return None

    history = ga_result.convergence_history
    gens    = [s.generation     for s in history]
    best_f  = [s.best_fitness   for s in history]
    mean_f  = [s.mean_fitness   for s in history]
    best_d  = [s.best_density   for s in history]
    divers  = [s.diversity      for s in history]
    feasn   = [s.n_feasible     for s in history]

    fig = make_subplots(rows=3, cols=1, shared_xaxes=True,
                         vertical_spacing=0.07)

    # Fitness
    fig.add_trace(go.Scatter(x=gens, y=best_f, mode="lines",
                               line=dict(color=PALETTE["gold"], width=2),
                               name="Best FoM"), row=1, col=1)
    fig.add_trace(go.Scatter(x=gens, y=mean_f, mode="lines",
                               line=dict(color=PALETTE["gold_dim"], width=1,
                                          dash="dot"),
                               name="Mean FoM"), row=1, col=1)

    # Density
    fig.add_trace(go.Scatter(x=gens, y=best_d, mode="lines",
                               line=dict(color=PALETTE["cyan"], width=2),
                               name="Best density (Tb/in²)"), row=2, col=1)

    # Diversity + feasible count
    fig.add_trace(go.Scatter(x=gens, y=divers, mode="lines",
                               line=dict(color=PALETTE["grey"], width=1.5),
                               name="Population diversity"), row=3, col=1)
    fig.add_trace(go.Bar(x=gens, y=feasn, marker_color=PALETTE["green"],
                          opacity=0.5, name="Feasible individuals"), row=3, col=1)

    for row in [1, 2, 3]:
        fig.update_yaxes(gridcolor=PALETTE["grid"], linecolor=PALETTE["border"],
                          row=row, col=1)
    fig.update_xaxes(gridcolor=PALETTE["grid"], linecolor=PALETTE["border"])

    fig.update_layout(
        **_PLOTLY_LAYOUT,
        title=dict(text="GENETIC ALGORITHM CONVERGENCE  ::  HAMR-X",
                    font=dict(color=PALETTE["gold"], size=13)),
    )
    fig.update_xaxes(title_text="Generation", row=3, col=1)
    fig.update_yaxes(title_text="Figure of Merit",  row=1, col=1)
    fig.update_yaxes(title_text="Density (Tb/in²)", row=2, col=1)
    fig.update_yaxes(title_text="Diversity / Count", row=3, col=1)

    if output_dir:
        _save_figure(fig, output_dir, "ga_convergence")
    return fig


# ─────────────────────────────────────────────────────────────────────────────
#  PLOT 7: SYSTEM PERFORMANCE DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────

def plot_performance_dashboard(result: "SimulationResult",
                                 output_dir: Optional[str] = None) -> Optional["go.Figure"]:
    """
    Multi-panel overview dashboard: density, BER, reliability, alignment, FoM.
    """
    if not PLOTLY_AVAILABLE:
        return None

    history = result.metrics_history
    if not history:
        return None

    cycles   = [m.cycle_number           for m in history]
    density  = [m.areal_density_tbpin2   for m in history]
    ber      = [m.post_ecc_ber           for m in history]
    reliab   = [m.reliability_score      for m in history]
    align    = [m.alignment_quality      for m in history]
    fom      = [m.figure_of_merit        for m in history]
    energy   = [m.energy_per_write_fj    for m in history]

    fig = make_subplots(
        rows=3, cols=2,
        shared_xaxes=False,
        subplot_titles=[
            "Areal Density (Tb/in²)", "Post-ECC BER",
            "Reliability Score",       "Head Alignment Quality",
            "Figure of Merit",         "Energy per Write (fJ)",
        ],
        vertical_spacing=0.12,
        horizontal_spacing=0.10,
    )

    traces = [
        (density,  PALETTE["gold"],  1, 1, False),
        (ber,      PALETTE["red"],   1, 2, True),
        (reliab,   PALETTE["green"], 2, 1, False),
        (align,    PALETTE["cyan"],  2, 2, False),
        (fom,      PALETTE["gold"],  3, 1, False),
        (energy,   PALETTE["grey"],  3, 2, False),
    ]
    names = ["Density", "BER", "Reliability", "Alignment", "FoM", "Energy"]

    for (values, colour, row, col, log_y), name in zip(traces, names):
        fig.add_trace(go.Scatter(
            x=cycles, y=values, mode="lines",
            line=dict(color=colour, width=1.8),
            name=name,
            fill="tozeroy",
            fillcolor=colour.replace("#", "rgba(").rstrip(")") + ",0.06)"
                       if colour.startswith("#") else colour,
        ), row=row, col=col)
        if log_y:
            fig.update_yaxes(type="log", row=row, col=col)

    fig.update_layout(
        **_PLOTLY_LAYOUT,
        title=dict(text="HAMR-X SYSTEM PERFORMANCE DASHBOARD",
                    font=dict(color=PALETTE["gold"], size=14)),
        showlegend=False,
    )
    # Subplot title colour override
    for ann in fig.layout.annotations:
        ann.font = dict(color=PALETTE["text_label"], size=10)

    for row in [1, 2, 3]:
        for col in [1, 2]:
            fig.update_xaxes(gridcolor=PALETTE["grid"],
                              linecolor=PALETTE["border"], row=row, col=col,
                              title_text="Cycle" if row == 3 else "")
            fig.update_yaxes(gridcolor=PALETTE["grid"],
                              linecolor=PALETTE["border"], row=row, col=col)

    if output_dir:
        _save_figure(fig, output_dir, "performance_dashboard")
    return fig


# ─────────────────────────────────────────────────────────────────────────────
#  PLOT 8: GRAIN SIZE DISTRIBUTION
# ─────────────────────────────────────────────────────────────────────────────

def plot_grain_distribution(medium,
                              output_dir: Optional[str] = None) -> Optional["go.Figure"]:
    """
    Plot the magnetic grain size and coercivity distributions.
    """
    if not PLOTLY_AVAILABLE:
        return None

    diameters    = medium.grain_diameter_distribution()
    coercivities = medium.grain_coercivity_distribution()

    fig = make_subplots(rows=1, cols=2,
                         subplot_titles=["Grain Diameter (nm)",
                                          "Grain Coercivity (Oe)"])

    fig.add_trace(go.Histogram(
        x=diameters, nbinsx=40,
        marker_color=PALETTE["gold"],
        opacity=0.8, name="Diameter",
    ), row=1, col=1)

    fig.add_trace(go.Histogram(
        x=coercivities, nbinsx=40,
        marker_color=PALETTE["cyan"],
        opacity=0.8, name="Coercivity",
    ), row=1, col=2)

    fig.update_layout(
        **_PLOTLY_LAYOUT,
        title=dict(text="MAGNETIC GRAIN DISTRIBUTION  ::  HAMR-X",
                    font=dict(color=PALETTE["gold"], size=13)),
        showlegend=False,
    )
    for col in [1, 2]:
        fig.update_xaxes(gridcolor=PALETTE["grid"], row=1, col=col)
        fig.update_yaxes(gridcolor=PALETTE["grid"], title_text="Count", row=1, col=col)

    if output_dir:
        _save_figure(fig, output_dir, "grain_distribution")
    return fig


# ─────────────────────────────────────────────────────────────────────────────
#  SAVE UTILITIES
# ─────────────────────────────────────────────────────────────────────────────

def _save_figure(fig: "go.Figure", output_dir: str, name: str) -> None:
    """Save a Plotly figure as HTML."""
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, f"{name}.html")
    fig.write_html(path)
    _logger.info(f"Figure saved: {path}")


def save_all_figures(result: "SimulationResult",
                      output_dir: str = "hamr_x_output/plots",
                      ga_result: Optional["GAResult"] = None) -> list[str]:
    """
    Generate and save all standard HAMR-X figures.

    Parameters
    ----------
    result     : SimulationResult from engine run
    output_dir : Output directory for HTML files
    ga_result  : Optional GA result for convergence plot

    Returns
    -------
    List of saved file paths
    """
    saved = []
    os.makedirs(output_dir, exist_ok=True)

    plots = [
        ("density_vs_ber",            lambda: plot_density_vs_ber(result, output_dir=output_dir)),
        ("temperature_vs_success",    lambda: plot_temperature_vs_write_success(
            result.config.medium.write_temp_k,
            result.config.medium.curie_temp_k,
            output_dir=output_dir
        )),
        ("laser_power_vs_reliability",lambda: plot_laser_power_vs_reliability(result, output_dir=output_dir)),
        ("degradation_over_time",     lambda: plot_degradation_over_time(result, output_dir=output_dir)),
        ("thermal_spot",              lambda: plot_thermal_spot_profile(
            result.config.laser,
            result.config.simulation.temperature_k,
            result.config.medium.write_temp_k,
            output_dir=output_dir
        )),
        ("performance_dashboard",     lambda: plot_performance_dashboard(result, output_dir=output_dir)),
        ("grain_distribution",        lambda: plot_grain_distribution(
            # We need to reconstruct medium — just use config data
            type('M', (), {
                'grain_diameter_distribution': lambda self: np.random.lognormal(
                    np.log(result.config.medium.grain_diameter_nm), 0.1, 500),
                'grain_coercivity_distribution': lambda self: np.random.normal(
                    result.config.medium.coercivity_oe,
                    result.config.medium.coercivity_oe * 0.05, 500),
            })(),
            output_dir=output_dir
        )),
    ]
    if ga_result is not None:
        plots.append(
            ("ga_convergence", lambda: plot_ga_convergence(ga_result, output_dir=output_dir))
        )

    for name, fn in plots:
        try:
            fig = fn()
            if fig is not None:
                saved.append(os.path.join(output_dir, f"{name}.html"))
                _logger.info(f"✓ Plot saved: {name}.html")
        except Exception as exc:
            _logger.warning(f"Plot '{name}' failed: {exc}")

    return saved
