"""
HAMR-X CORE :: main.py
========================
Command-line entry point for the HAMR-X simulation platform.

Usage modes:
  python main.py simulate     — run a single simulation
  python main.py optimise     — run GA optimisation
  python main.py sweep        — parameter sensitivity sweep
  python main.py gui          — launch PyQt6 dashboard
  python main.py test         — run unit test suite
  python main.py benchmark    — benchmark multiple medium types

Examples
--------
  python main.py simulate --medium high_density_alloy --cycles 10000
  python main.py optimise --method ga --generations 50
  python main.py sweep --param laser_power_mw
  python main.py gui
"""

from __future__ import annotations
import sys
import os
import argparse
import json
import time

# Ensure the package root is importable
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from hamr_x.utils.logging import get_logger, print_banner
from hamr_x.utils.config import HAMRConfig, MEDIUM_LIBRARY, OptimisationConfig

_logger = get_logger("main")


# ─────────────────────────────────────────────────────────────────────────────
#  ARGUMENT PARSER
# ─────────────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog        = "hamr_x",
        description = "HAMR-X CORE :: Heat-Assisted Magnetic Recording Optimisation Engine",
        formatter_class = argparse.RawDescriptionHelpFormatter,
        epilog = """
COMMANDS:
  simulate   Run a deterministic HAMR simulation
  optimise   Run GA / Bayesian / brute-force parameter optimisation
  sweep      Single-parameter sensitivity sweep
  gui        Launch the PyQt6 engineering dashboard
  test       Run the full unit test suite
  benchmark  Compare all recording media types
        """
    )
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    # ── simulate ─────────────────────────────────────────────────────────────
    sim_p = sub.add_parser("simulate", help="Run a HAMR simulation")
    sim_p.add_argument("--medium",   default="high_density_alloy",
                        choices=list(MEDIUM_LIBRARY.keys()),
                        help="Recording medium type")
    sim_p.add_argument("--cycles",   type=int,   default=10_000,
                        help="Number of simulation cycles")
    sim_p.add_argument("--power",    type=float, default=6.0,
                        help="Laser power (mW)")
    sim_p.add_argument("--track",    type=float, default=30.0,
                        help="Track spacing (nm)")
    sim_p.add_argument("--bit",      type=float, default=8.0,
                        help="Bit length (nm)")
    sim_p.add_argument("--precision",type=float, default=0.97,
                        help="Head precision [0-1]")
    sim_p.add_argument("--seed",     type=int,   default=42)
    sim_p.add_argument("--verbose",  action="store_true")
    sim_p.add_argument("--output",   default="hamr_x_output",
                        help="Output directory for plots and reports")
    sim_p.add_argument("--no-plots", action="store_true",
                        help="Skip generating visualisation plots")

    # ── optimise ─────────────────────────────────────────────────────────────
    opt_p = sub.add_parser("optimise", help="Run parameter optimisation")
    opt_p.add_argument("--method",   default="ga",
                        choices=["ga", "bayesian", "brute"],
                        help="Optimisation method")
    opt_p.add_argument("--medium",   default="high_density_alloy",
                        choices=list(MEDIUM_LIBRARY.keys()))
    opt_p.add_argument("--generations", type=int, default=40,
                        help="GA generations (or Bayesian iterations)")
    opt_p.add_argument("--population",  type=int, default=60,
                        help="GA population size")
    opt_p.add_argument("--ber-target",  type=float, default=1e-6,
                        help="Target maximum BER")
    opt_p.add_argument("--seed",     type=int, default=42)
    opt_p.add_argument("--output",   default="hamr_x_output")

    # ── sweep ────────────────────────────────────────────────────────────────
    sweep_p = sub.add_parser("sweep", help="Parameter sensitivity sweep")
    sweep_p.add_argument("--param",  required=True,
                          choices=["laser_power_mw", "track_spacing_nm",
                                    "bit_length_nm", "head_precision",
                                    "pulse_duration_ns", "nft_efficiency"],
                          help="Parameter to sweep")
    sweep_p.add_argument("--medium", default="high_density_alloy",
                          choices=list(MEDIUM_LIBRARY.keys()))
    sweep_p.add_argument("--points", type=int, default=20,
                          help="Number of sweep points")
    sweep_p.add_argument("--output", default="hamr_x_output")

    # ── gui ──────────────────────────────────────────────────────────────────
    sub.add_parser("gui", help="Launch PyQt6 dashboard")

    # ── test ─────────────────────────────────────────────────────────────────
    sub.add_parser("test", help="Run unit test suite")

    # ── benchmark ────────────────────────────────────────────────────────────
    bench_p = sub.add_parser("benchmark", help="Benchmark all medium types")
    bench_p.add_argument("--cycles", type=int, default=2000)
    bench_p.add_argument("--output", default="hamr_x_output")

    return parser


# ─────────────────────────────────────────────────────────────────────────────
#  COMMAND: SIMULATE
# ─────────────────────────────────────────────────────────────────────────────

def cmd_simulate(args) -> None:
    from hamr_x.core.simulation_engine import SimulationEngine
    from hamr_x.visualization.plots import save_all_figures

    _logger.info(f"SIMULATE  ::  medium={args.medium}, cycles={args.cycles:,}")

    cfg = HAMRConfig.from_medium(args.medium)
    cfg.laser.power_mw           = args.power
    cfg.density.track_spacing_nm = args.track
    cfg.density.bit_length_nm    = args.bit
    cfg.head.precision           = args.precision
    cfg.simulation.n_cycles      = args.cycles
    cfg.simulation.seed          = args.seed
    cfg.simulation.verbose       = args.verbose

    engine = SimulationEngine(cfg)
    result = engine.run()

    # Print result summary
    print("\n" + result.summary())
    print("\n" + result.final_metrics.formatted_report())

    # Save plots
    if not args.no_plots:
        try:
            plot_dir = os.path.join(args.output, "plots")
            saved    = save_all_figures(result, output_dir=plot_dir)
            print(f"\n[PLOTS] {len(saved)} figures saved to {plot_dir}/")
        except Exception as exc:
            _logger.warning(f"Plot generation failed: {exc}")

    # Save JSON report
    os.makedirs(args.output, exist_ok=True)
    report_path = os.path.join(args.output, f"simulation_{result.run_id}.json")
    with open(report_path, "w") as f:
        json.dump({
            "run_id":    result.run_id,
            "medium":    args.medium,
            "config": {
                "laser_power_mw":    cfg.laser.power_mw,
                "track_spacing_nm":  cfg.density.track_spacing_nm,
                "bit_length_nm":     cfg.density.bit_length_nm,
                "head_precision":    cfg.head.precision,
                "n_cycles":          cfg.simulation.n_cycles,
                "seed":              cfg.simulation.seed,
            },
            "final_metrics": result.final_metrics.to_dict(),
            "elapsed_s":     result.elapsed_seconds,
        }, f, indent=2)
    print(f"[REPORT] Saved → {report_path}")


# ─────────────────────────────────────────────────────────────────────────────
#  COMMAND: OPTIMISE
# ─────────────────────────────────────────────────────────────────────────────

def cmd_optimise(args) -> None:
    from hamr_x.core.simulation_engine import SimulationEngine
    from hamr_x.visualization.plots import plot_ga_convergence, _save_figure

    _logger.info(
        f"OPTIMISE  ::  method={args.method}, medium={args.medium}"
    )

    cfg = HAMRConfig.from_medium(args.medium)
    cfg.optimisation.n_generations   = args.generations
    cfg.optimisation.population_size  = args.population
    cfg.optimisation.ber_target       = args.ber_target
    cfg.simulation.n_cycles           = 300   # fast eval during optimisation
    cfg.simulation.n_grains           = 80
    cfg.simulation.seed               = args.seed

    engine      = SimulationEngine(cfg)
    evaluate_fn = engine.evaluate_params

    if args.method == "ga":
        from hamr_x.optimisation.genetic import GeneticOptimiser
        optimiser = GeneticOptimiser(cfg, evaluate_fn, seed=args.seed)
        result    = optimiser.optimise()

        print("\n" + "═" * 60)
        print("  GA OPTIMISATION RESULT  ::  HAMR-X")
        print("═" * 60)
        print(f"  Best FoM     : {result.best_fitness:.6f}")
        print(f"  Best BER     : {result.best_ber:.4e}")
        print(f"  Best Density : {result.best_density_tbpin2:.4f} Tb/in²")
        print(f"  Feasible     : {result.feasible}")
        print(f"  Generations  : {result.n_generations}")
        print("\n  OPTIMAL PARAMETERS:")
        for k, v in result.best_params.items():
            print(f"    {k:<25} = {v:.6f}")

        # GA convergence plot
        try:
            fig = plot_ga_convergence(result)
            if fig is not None:
                plot_dir = os.path.join(args.output, "plots")
                _save_figure(fig, plot_dir, "ga_convergence")
                print(f"\n[PLOTS] GA convergence chart saved to {plot_dir}/")
        except Exception as exc:
            _logger.warning(f"GA plot failed: {exc}")

        # Save results
        os.makedirs(args.output, exist_ok=True)
        out_path = os.path.join(args.output, "ga_optimisation_result.json")
        with open(out_path, "w") as f:
            json.dump({
                "method":            "genetic_algorithm",
                "best_fom":          result.best_fitness,
                "best_ber":          result.best_ber,
                "best_density":      result.best_density_tbpin2,
                "feasible":          result.feasible,
                "n_generations":     result.n_generations,
                "best_params":       result.best_params,
            }, f, indent=2)
        print(f"[REPORT] Saved → {out_path}")

    elif args.method == "bayesian":
        from hamr_x.optimisation.optimisers import BayesianOptimiser
        cfg.optimisation.bayesian_n_iter  = args.generations
        cfg.optimisation.bayesian_n_init  = max(5, args.generations // 5)
        optimiser = BayesianOptimiser(cfg, evaluate_fn, seed=args.seed)
        result    = optimiser.optimise()

        print("\n" + "═" * 60)
        print("  BAYESIAN OPTIMISATION RESULT  ::  HAMR-X")
        print("═" * 60)
        print(f"  Best FoM        : {result.best_fom:.6f}")
        print(f"  Best BER        : {result.best_ber:.4e}")
        print(f"  Best Density    : {result.best_density_tbpin2:.4f} Tb/in²")
        print(f"  Feasible        : {result.feasible}")
        print(f"  Iterations      : {result.n_iterations}")
        print(f"  GP Surrogate RMSE: {result.surrogate_rmse:.4f}")
        print("\n  OPTIMAL PARAMETERS:")
        for k, v in result.best_params.items():
            print(f"    {k:<25} = {v:.6f}")

    elif args.method == "brute":
        from hamr_x.optimisation.optimisers import BruteForceOptimiser
        grid_pts  = min(6, max(3, args.generations // 10))
        optimiser = BruteForceOptimiser(cfg, evaluate_fn,
                                         n_grid_points=grid_pts)
        result    = optimiser.optimise(ber_target=args.ber_target)

        print("\n" + "═" * 60)
        print("  BRUTE-FORCE GRID SEARCH RESULT  ::  HAMR-X")
        print("═" * 60)
        print(f"  Best FoM        : {result.best_fom:.6f}")
        print(f"  Best BER        : {result.best_ber:.4e}")
        print(f"  Best Density    : {result.best_density_tbpin2:.4f} Tb/in²")
        print(f"  Evaluations     : {result.n_evaluations:,}")
        print(f"  Feasible Configs: {result.feasible_count:,}")
        print("\n  OPTIMAL PARAMETERS:")
        for k, v in result.best_params.items():
            print(f"    {k:<25} = {v:.6f}")


# ─────────────────────────────────────────────────────────────────────────────
#  COMMAND: SWEEP
# ─────────────────────────────────────────────────────────────────────────────

def cmd_sweep(args) -> None:
    from hamr_x.core.simulation_engine import SimulationEngine
    from hamr_x.optimisation.optimisers import BruteForceOptimiser

    _logger.info(f"SWEEP  ::  param={args.param}, medium={args.medium}")

    cfg = HAMRConfig.from_medium(args.medium)
    cfg.simulation.n_cycles = 300
    cfg.simulation.n_grains = 60

    engine = SimulationEngine(cfg)
    opt    = BruteForceOptimiser(cfg, engine.evaluate_params)
    p_vals, bers, densities = opt.sensitivity_sweep(args.param, args.points)

    print(f"\n{'─' * 65}")
    print(f"  PARAMETER SWEEP  ::  {args.param.upper()}")
    print(f"{'─' * 65}")
    print(f"  {'Value':>12}  {'BER':>12}  {'Density (Tb/in²)':>18}")
    print(f"  {'─' * 12}  {'─' * 12}  {'─' * 18}")
    for pv, ber, d in zip(p_vals, bers, densities):
        flag = "  ✓" if ber <= cfg.optimisation.ber_target else ""
        print(f"  {pv:>12.4f}  {ber:>12.4e}  {d:>18.6f}{flag}")
    print(f"{'─' * 65}")
    print(f"  ✓ = BER ≤ {cfg.optimisation.ber_target:.0e}")

    # Save CSV
    os.makedirs(args.output, exist_ok=True)
    csv_path = os.path.join(args.output, f"sweep_{args.param}.csv")
    with open(csv_path, "w") as f:
        f.write(f"{args.param},ber,density_tbpin2\n")
        for pv, ber, d in zip(p_vals, bers, densities):
            f.write(f"{pv:.6f},{ber:.6e},{d:.6f}\n")
    print(f"\n[REPORT] Sweep data saved → {csv_path}")


# ─────────────────────────────────────────────────────────────────────────────
#  COMMAND: GUI
# ─────────────────────────────────────────────────────────────────────────────

def cmd_gui(_args) -> None:
    from hamr_x.gui.dashboard import launch_dashboard
    launch_dashboard()


# ─────────────────────────────────────────────────────────────────────────────
#  COMMAND: TEST
# ─────────────────────────────────────────────────────────────────────────────

def cmd_test(_args) -> None:
    import unittest
    from hamr_x.tests.test_hamr_x import (
        TestHAMRConfig, TestMagneticMedium, TestThermalLaserModel,
        TestHeadPositioningModel, TestDensityModel, TestErrorModel,
        TestDegradationModel, TestPerformanceEngine, TestSwitchingModel,
        TestSimulationEngine, TestPhysicalConstants,
    )

    loader = unittest.TestLoader()
    suite  = unittest.TestSuite()
    for cls in [TestPhysicalConstants, TestHAMRConfig, TestMagneticMedium,
                 TestThermalLaserModel, TestHeadPositioningModel,
                 TestDensityModel, TestErrorModel, TestDegradationModel,
                 TestPerformanceEngine, TestSwitchingModel,
                 TestSimulationEngine]:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)


# ─────────────────────────────────────────────────────────────────────────────
#  COMMAND: BENCHMARK
# ─────────────────────────────────────────────────────────────────────────────

def cmd_benchmark(args) -> None:
    from hamr_x.core.simulation_engine import SimulationEngine

    print("\n" + "═" * 70)
    print("  HAMR-X MEDIUM BENCHMARK")
    print("═" * 70)
    print(f"  {'Medium':<35}  {'Density':>10}  {'BER':>12}  {'FoM':>10}")
    print(f"  {'─' * 35}  {'─' * 10}  {'─' * 12}  {'─' * 10}")

    results = []
    for key, med in MEDIUM_LIBRARY.items():
        cfg = HAMRConfig.from_medium(key)
        cfg.simulation.n_cycles = args.cycles
        cfg.simulation.n_grains = 80
        cfg.simulation.verbose  = False

        t0     = time.perf_counter()
        engine = SimulationEngine(cfg)
        result = engine.run()
        elapsed = time.perf_counter() - t0
        m = result.final_metrics

        print(
            f"  {med.name:<35}  "
            f"{m.areal_density_tbpin2:>10.4f}  "
            f"{m.post_ecc_ber:>12.4e}  "
            f"{m.figure_of_merit:>10.6f}  "
            f"({elapsed:.1f}s)"
        )
        results.append({
            "medium_key": key,
            "medium_name": med.name,
            "density": m.areal_density_tbpin2,
            "ber": m.post_ecc_ber,
            "fom": m.figure_of_merit,
            "elapsed_s": elapsed,
        })

    print("═" * 70)

    # Best medium
    best = max(results, key=lambda r: r["fom"])
    print(f"\n  BEST  ::  {best['medium_name']}  (FoM = {best['fom']:.6f})")

    # Save JSON
    os.makedirs(args.output, exist_ok=True)
    out_path = os.path.join(args.output, "benchmark_results.json")
    with open(out_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"  [REPORT] Saved → {out_path}\n")


# ─────────────────────────────────────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    print_banner()
    parser = build_parser()
    args   = parser.parse_args()

    if args.command is None:
        parser.print_help()
        return

    dispatch = {
        "simulate":  cmd_simulate,
        "optimise":  cmd_optimise,
        "sweep":     cmd_sweep,
        "gui":       cmd_gui,
        "test":      cmd_test,
        "benchmark": cmd_benchmark,
    }

    handler = dispatch.get(args.command)
    if handler:
        handler(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
