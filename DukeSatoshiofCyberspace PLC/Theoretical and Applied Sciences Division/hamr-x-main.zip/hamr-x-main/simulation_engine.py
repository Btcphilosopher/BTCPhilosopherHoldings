"""
HAMR-X CORE :: core/simulation_engine.py
==========================================
Master simulation engine for the HAMR-X platform.

Orchestrates all subsystem modules in a deterministic timestep loop:

    for cycle in simulation:
        generate_write_request()
        apply_heat_model()
        simulate_magnetic_switching()
        apply_head_positioning_errors()
        compute_read_write_success()
        update_degradation()
        record_metrics()

The engine is the single source of truth for simulation state and
provides the evaluate_fn interface required by the optimisation modules.

Architecture
------------
SimulationEngine holds references to all subsystem instances and
coordinates data flow between them. It is the only class that
instantiates subsystems, ensuring consistent configuration propagation.
"""

from __future__ import annotations
import numpy as np
import time
import uuid
from dataclasses import dataclass, field
from typing import Optional

from ..utils.config import (
    HAMRConfig, MEDIUM_LIBRARY,
    LaserConfig, HeadConfig, DensityConfig
)
from ..utils.logging import get_logger, SimulationJournal, ProgressLogger, timed_section
from ..physics.magnetic_medium import MagneticMedium
from ..physics.thermal_laser import ThermalLaserModel
from ..physics.switching_model import HAMRSwitchingModel
from ..mechanical.head_positioning import HeadPositioningModel, VibrationModel
from ..storage.models import DensityModel, ErrorModel, DegradationModel
from ..metrics.performance import PerformanceEngine, PerformanceMetrics


_logger = get_logger("core.simulation_engine")


# ─────────────────────────────────────────────────────────────────────────────
#  SIMULATION RESULT RECORD
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class SimulationResult:
    """
    Complete result package from a HAMR-X simulation run.

    Attributes
    ----------
    run_id              : Unique run identifier
    config              : Configuration used for this run
    final_metrics       : Final performance metrics snapshot
    metrics_history     : Time series of performance snapshots
    degradation_curve   : (cycles, hc_factors, health_scores) arrays
    write_success_series: Per-batch write success rates
    ber_series          : Per-batch BER values
    density_series      : Per-batch density values
    temp_series         : Per-batch mean peak temperatures
    elapsed_seconds     : Wall-clock simulation time
    n_write_ops         : Total write operations simulated
    n_failures          : Total write failures
    """
    run_id:                str
    config:                HAMRConfig
    final_metrics:         PerformanceMetrics
    metrics_history:       list[PerformanceMetrics]
    degradation_curve:     tuple[np.ndarray, np.ndarray, np.ndarray]
    write_success_series:  list[float]
    ber_series:            list[float]
    density_series:        list[float]
    temp_series:           list[float]
    elapsed_seconds:       float
    n_write_ops:           int
    n_failures:            int

    def summary(self) -> str:
        """Return a formatted simulation result summary."""
        m = self.final_metrics
        lines = [
            "╔══════════════════════════════════════════════════════════╗",
            f"║  HAMR-X RUN  ::  {self.run_id[:32]:<32}  ║",
            "╠══════════════════════════════════════════════════════════╣",
            f"║  Medium          : {self.config.medium.name:<38}║",
            f"║  Write Ops       : {self.n_write_ops:>12,}                         ║",
            f"║  Failures        : {self.n_failures:>12,}                         ║",
            f"║  Elapsed         : {self.elapsed_seconds:>12.2f} s                      ║",
            "╠══════════════════════════════════════════════════════════╣",
            f"║  Final Density   : {m.areal_density_tbpin2:>12.4f} Tb/in²              ║",
            f"║  Post-ECC BER    : {m.post_ecc_ber:>14.4e}                ║",
            f"║  Write Success   : {m.write_success_rate * 100:>12.4f} %               ║",
            f"║  Reliability     : {m.reliability_score:>12.4f} [0-1]            ║",
            f"║  Medium Health   : {m.degradation_health:>12.4f} [0-1]            ║",
            f"║  Figure of Merit : {m.figure_of_merit:>12.6f}                    ║",
            "╚══════════════════════════════════════════════════════════╝",
        ]
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
#  SIMULATION ENGINE
# ─────────────────────────────────────────────────────────────────────────────

class SimulationEngine:
    """
    HAMR-X master simulation engine.

    Instantiates all subsystems from a HAMRConfig and runs the
    deterministic write/read/degrade timestep loop.

    Parameters
    ----------
    config : HAMRConfig specifying all system parameters
    """

    # Degradation update frequency (every N cycles)
    _DEGRAD_UPDATE_FREQ: int   = 100
    # Metrics snapshot frequency (every N cycles)
    _METRICS_FREQ:       int   = 500
    # Batch size for write simulation
    _BATCH_SIZE:         int   = 50

    def __init__(self, config: HAMRConfig) -> None:
        self.config = config
        self.run_id = str(uuid.uuid4())[:16]

        # Seed the numpy global RNG for any non-seeded usage
        np.random.seed(config.simulation.seed)

        # ── Subsystem instantiation ───────────────────────────────────────
        self.medium = MagneticMedium(
            config   = config.medium,
            n_grains = config.simulation.n_grains,
            seed     = config.simulation.seed,
        )
        self.laser = ThermalLaserModel(
            config        = config.laser,
            ambient_temp_k = config.simulation.temperature_k,
        )
        self.switcher = HAMRSwitchingModel(
            config = config,
            medium = self.medium,
            laser  = self.laser,
            seed   = config.simulation.seed + 1,
        )
        self.head = HeadPositioningModel(
            config          = config.head,
            track_pitch_nm  = config.density.track_spacing_nm,
            seed            = config.simulation.seed + 2,
        )
        self.vibration = VibrationModel(
            config = config.head,
            seed   = config.simulation.seed + 3,
        )
        self.density_model = DensityModel(
            config        = config.density,
            tmr_3sigma_nm = config.head.jitter_sigma_nm * 3,
        )
        self.error_model = ErrorModel(
            config = config,
            seed   = config.simulation.seed + 4,
        )
        self.degradation = DegradationModel(
            config = config,
        )
        self.perf_engine = PerformanceEngine(
            config          = config,
            ber_target      = config.optimisation.ber_target,
            density_target  = config.optimisation.min_density_tbpin2,
        )
        self.journal = SimulationJournal(run_id=self.run_id)

        _logger.info(f"SimulationEngine[{self.run_id}] initialised")
        if config.simulation.verbose:
            _logger.info(config.summary())

    # ──────────────────────────────────────────────────────────────────────────
    #  SINGLE CYCLE STEP
    # ──────────────────────────────────────────────────────────────────────────

    def _run_write_batch(self, batch_size: int,
                          cycle_offset:  int) -> dict:
        """
        Execute a batch of write operations and return aggregate statistics.

        Parameters
        ----------
        batch_size    : Number of writes in this batch
        cycle_offset  : Starting cycle number for this batch

        Returns
        -------
        Batch statistics dictionary
        """
        # Sample head positions for the entire batch
        positions = self.head.sample_batch(batch_size)
        alignment_factors = np.array([p.alignment_factor for p in positions])

        # Alternating write directions
        directions = np.array([1.0 if i % 2 == 0 else -1.0
                                for i in range(batch_size)])

        # Execute write batch through the switching model
        batch_result = self.switcher.simulate_write_batch(
            n_writes           = batch_size,
            alignment_factors  = alignment_factors,
            directions         = directions,
        )

        # Compute adjacent-track erasure probability at current track pitch
        adj_erasure_prob = self.switcher.adjacent_track_erasure_probability(
            self.config.density.track_spacing_nm
        )

        # Compute error budget
        error_budget = self.error_model.compute_error_budget(
            write_success_rate          = batch_result["write_success_rate"],
            alignment_quality           = float(np.mean(alignment_factors)),
            thermal_misfire_rate        = batch_result["thermal_fail_rate"],
            adjacent_track_erasure_rate = adj_erasure_prob,
        )

        # Simulate read operations
        read_successes = []
        snr_base = self.config.density.read_channel_snr_db
        degrad_penalty = (1.0 - self.degradation.get_current_state().health_score) * 3.0
        effective_snr = snr_base - degrad_penalty
        for _ in range(min(batch_size, 20)):  # sample read performance
            read_result = self.switcher.simulate_read(
                snr_db = effective_snr
            )
            read_successes.append(read_result["success"])
        read_success_rate = float(np.mean(read_successes))

        return {
            "write_success_rate":   batch_result["write_success_rate"],
            "read_success_rate":    read_success_rate,
            "raw_ber":              error_budget.raw_ber,
            "post_ecc_ber":         error_budget.post_ecc_ber,
            "mean_peak_temp_k":     batch_result["mean_peak_temp_k"],
            "mean_energy_pj":       batch_result["mean_energy_pj"],
            "alignment_quality":    float(np.mean(alignment_factors)),
            "thermal_misfire_rate": batch_result["thermal_fail_rate"],
            "reliability_score":    error_budget.reliability_score,
            "adj_erasure_prob":     adj_erasure_prob,
            "n_failures":           batch_result["total_failures"],
        }

    # ──────────────────────────────────────────────────────────────────────────
    #  MAIN SIMULATION LOOP
    # ──────────────────────────────────────────────────────────────────────────

    def run(self) -> SimulationResult:
        """
        Execute the complete HAMR-X simulation.

        Runs for n_cycles, collecting metrics, applying degradation, and
        building a complete time series of system performance.

        Returns
        -------
        SimulationResult with all output data
        """
        n_cycles     = self.config.simulation.n_cycles
        batch_size   = self._BATCH_SIZE
        n_batches    = max(1, n_cycles // batch_size)

        _logger.info(
            f"[{self.run_id}] Simulation start: "
            f"{n_cycles:,} cycles, {n_batches:,} batches"
        )

        t0 = time.perf_counter()

        # Running accumulators
        write_success_series: list[float] = []
        ber_series:           list[float] = []
        density_series:       list[float] = []
        temp_series:          list[float] = []
        total_failures:       int         = 0
        total_writes:         int         = 0

        progress = ProgressLogger(n_batches, f"Simulation[{self.run_id}]",
                                   report_pct=10.0, logger=_logger)

        # Compute initial density
        density_result = self.density_model.compute_density()
        current_density = density_result.areal_density_tbpin2

        for batch_idx in range(n_batches):
            cycle_num = batch_idx * batch_size

            # ── Execute write batch ──────────────────────────────────────────
            batch = self._run_write_batch(batch_size, cycle_num)
            total_writes   += batch_size
            total_failures += batch["n_failures"]

            write_success_series.append(batch["write_success_rate"])
            ber_series.append(batch["post_ecc_ber"])
            density_series.append(current_density)
            temp_series.append(batch["mean_peak_temp_k"])

            # ── Degradation update ───────────────────────────────────────────
            if batch_idx % (self._DEGRAD_UPDATE_FREQ // batch_size + 1) == 0:
                degrad_state = self.degradation.step(batch_size)
                # Also apply grain-level degradation in medium model
                if self.config.simulation.enable_degradation:
                    self.medium.apply_degradation_cycle()

            else:
                degrad_state = self.degradation.get_current_state()

            # ── Update density model with current TMR ────────────────────────
            tmr_stats = self.head.tmr_statistics()
            if tmr_stats.get("n_samples", 0) > 0:
                tmr_3s = tmr_stats["tmr_3sigma_nm"]
                self.density_model.tmr_3sigma_nm = tmr_3s
                density_result  = self.density_model.compute_density()
                current_density = density_result.areal_density_tbpin2

            # ── Metrics snapshot ─────────────────────────────────────────────
            if batch_idx % (self._METRICS_FREQ // batch_size + 1) == 0:
                degrad_lifetime = self.degradation.lifetime_estimate_cycles()
                metrics = self.perf_engine.compute_metrics(
                    cycle_number          = cycle_num,
                    areal_density_tbpin2  = current_density,
                    raw_ber               = batch["raw_ber"],
                    post_ecc_ber          = batch["post_ecc_ber"],
                    write_success_rate    = batch["write_success_rate"],
                    read_success_rate     = batch["read_success_rate"],
                    energy_per_pulse_pj   = batch["mean_energy_pj"],
                    lifetime_cycles       = degrad_lifetime,
                    reliability_score     = batch["reliability_score"],
                    peak_temperature_k    = batch["mean_peak_temp_k"],
                    thermal_misfire_rate  = batch["thermal_misfire_rate"],
                    alignment_quality     = batch["alignment_quality"],
                    degradation_health    = degrad_state.health_score,
                )

                if self.config.simulation.verbose:
                    _logger.info(
                        f"Batch {batch_idx:>6d} | "
                        f"density={metrics.areal_density_tbpin2:.4f} Tb/in² | "
                        f"BER={metrics.post_ecc_ber:.2e} | "
                        f"health={metrics.degradation_health:.4f} | "
                        f"FoM={metrics.figure_of_merit:.6f}"
                    )

                self.journal.emit_metric(cycle_num, metrics.to_dict())

            progress.update(batch_idx + 1)

        progress.done()

        # ── Final metrics snapshot ────────────────────────────────────────────
        degrad_state    = self.degradation.get_current_state()
        final_metrics   = self.perf_engine.compute_metrics(
            cycle_number          = n_cycles,
            areal_density_tbpin2  = current_density,
            raw_ber               = float(np.mean(ber_series[-10:])),
            post_ecc_ber          = float(np.mean(ber_series[-10:])),
            write_success_rate    = float(np.mean(write_success_series[-10:])),
            read_success_rate     = 0.99 * degrad_state.health_score,
            energy_per_pulse_pj   = self.laser.state_summary()["energy_per_pulse_pj"],
            lifetime_cycles       = self.degradation.lifetime_estimate_cycles(),
            reliability_score     = float(np.mean([
                1.0 - b for b in ber_series[-10:]
            ])),
            peak_temperature_k    = float(np.mean(temp_series[-10:])),
            thermal_misfire_rate  = 0.0,
            alignment_quality     = float(np.mean([
                p.alignment_factor
                for p in self.head.sample_batch(20)
            ])),
            degradation_health    = degrad_state.health_score,
        )

        elapsed = time.perf_counter() - t0
        _logger.info(
            f"[{self.run_id}] Simulation complete in {elapsed:.2f}s | "
            f"FoM={final_metrics.figure_of_merit:.6f}"
        )

        # Degradation curve for plotting
        degrad_curve = self.degradation.degradation_curve()

        return SimulationResult(
            run_id               = self.run_id,
            config               = self.config,
            final_metrics        = final_metrics,
            metrics_history      = self.perf_engine._history,
            degradation_curve    = degrad_curve,
            write_success_series = write_success_series,
            ber_series           = ber_series,
            density_series       = density_series,
            temp_series          = temp_series,
            elapsed_seconds      = elapsed,
            n_write_ops          = total_writes,
            n_failures           = total_failures,
        )

    # ──────────────────────────────────────────────────────────────────────────
    #  OPTIMISATION INTERFACE
    # ──────────────────────────────────────────────────────────────────────────

    def evaluate_params(self, params: dict[str, float]) -> tuple[float, float, float]:
        """
        Fast evaluation function for optimisation routines.

        Given a parameter dictionary, applies the parameters to the
        configuration, runs a short simulation (1000 cycles), and returns
        (ber, density, fom).

        This is the evaluate_fn required by GA, Bayesian, and brute-force
        optimisers.

        Parameters
        ----------
        params : dict mapping parameter names to values

        Returns
        -------
        (ber, density_tbpin2, figure_of_merit)
        """
        # Apply parameters to a fresh config copy
        cfg = HAMRConfig.from_medium(
            list(MEDIUM_LIBRARY.keys())[0]
        )
        cfg.medium       = self.config.medium
        cfg.simulation   = self.config.simulation
        cfg.optimisation = self.config.optimisation

        # Apply laser parameters
        cfg.laser.power_mw          = params.get("laser_power_mw",
                                                   self.config.laser.power_mw)
        cfg.laser.pulse_duration_ns = params.get("pulse_duration_ns",
                                                   self.config.laser.pulse_duration_ns)
        cfg.laser.spot_radius_nm    = params.get("spot_radius_nm",
                                                   self.config.laser.spot_radius_nm)
        cfg.laser.nft_efficiency    = params.get("nft_efficiency",
                                                   self.config.laser.nft_efficiency)
        cfg.medium.write_temp_k     = params.get("write_temp_k",
                                                   self.config.medium.write_temp_k)
        cfg.density.track_spacing_nm = params.get("track_spacing_nm",
                                                    self.config.density.track_spacing_nm)
        cfg.density.bit_length_nm   = params.get("bit_length_nm",
                                                   self.config.density.bit_length_nm)
        cfg.head.precision          = params.get("head_precision",
                                                   self.config.head.precision)

        # Override simulation for fast evaluation
        cfg.simulation.n_cycles   = 500
        cfg.simulation.n_grains   = 100
        cfg.simulation.verbose    = False

        # Run fast simulation
        try:
            fast_engine = SimulationEngine(cfg)
            result      = fast_engine.run()
            m           = result.final_metrics
            return m.post_ecc_ber, m.areal_density_tbpin2, m.figure_of_merit
        except Exception as exc:
            _logger.debug(f"Fast eval failed: {exc}")
            return 1.0, 0.0, 0.0


# ─────────────────────────────────────────────────────────────────────────────
#  CONVENIENCE FACTORY FUNCTION
# ─────────────────────────────────────────────────────────────────────────────

def run_hamr_simulation(
    laser_power:         float  = 6.0,
    track_spacing:       float  = 30.0,
    medium_type:         str    = "high_density_alloy",
    head_precision:      float  = 0.97,
    simulation_cycles:   int    = 10_000,
    seed:                int    = 42,
    verbose:             bool   = False,
) -> SimulationResult:
    """
    Top-level convenience function to run a HAMR-X simulation.

    Parameters
    ----------
    laser_power        : Laser output power (mW)
    track_spacing      : Track pitch (nm)
    medium_type        : Recording medium key from MEDIUM_LIBRARY
    head_precision     : Servo tracking precision [0, 1]
    simulation_cycles  : Number of write/read cycles to simulate
    seed               : RNG seed for reproducibility
    verbose            : Enable detailed logging

    Returns
    -------
    SimulationResult

    Example
    -------
    >>> result = run_hamr_simulation(
    ...     laser_power=1.5,
    ...     track_spacing=12,
    ...     medium_type="high_density_alloy",
    ...     head_precision=0.98,
    ...     simulation_cycles=10000,
    ... )
    >>> print(result.summary())
    """
    cfg = HAMRConfig.from_medium(medium_type)
    cfg.laser.power_mw              = laser_power
    cfg.density.track_spacing_nm    = track_spacing
    cfg.head.precision              = head_precision
    cfg.simulation.n_cycles         = simulation_cycles
    cfg.simulation.seed             = seed
    cfg.simulation.verbose          = verbose

    engine = SimulationEngine(cfg)
    return engine.run()
