"""
HAMR-X CORE :: physics/switching_model.py
==========================================
Combined thermal-magnetic switching model for HAMR write process simulation.

Integrates the thermal laser model and magnetic medium model to determine
write success probabilities under realistic HAMR operating conditions.

The switching model evaluates:
  1. Whether the thermal pulse achieves the required write temperature
  2. Whether the applied field exceeds the thermally-reduced switching field
  3. Whether the write completes before the medium cools back below threshold
  4. Interference effects from adjacent track heating (cross-track erasure)

Key Equations
-------------
Write success requires simultaneous satisfaction of:
  (A) T_peak ≥ T_write_threshold     [thermal condition]
  (B) H_applied ≥ Hc(T_write)        [field condition at write temperature]
  (C) t_write ≤ t_cooling            [timing condition]

The combined write probability:

    P_write = P_thermal · P_field · P_timing · P_alignment

where P_alignment is provided by the head positioning subsystem.
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Optional

from ..utils.config import HAMRConfig
from ..utils.logging import get_logger
from .magnetic_medium import MagneticMedium
from .thermal_laser import ThermalLaserModel, ThermalProfile


_logger = get_logger("physics.switching_model")


# ─────────────────────────────────────────────────────────────────────────────
#  WRITE EVENT RESULT
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class WriteEventResult:
    """
    Complete result record for a single HAMR write event.

    Attributes
    ----------
    success                  : Write operation succeeded
    peak_temperature_k       : Peak temperature achieved (K)
    write_temperature_k      : Required write temperature (K)
    thermal_condition_met    : Thermal threshold reached
    field_condition_met      : Write field exceeded coercivity
    timing_condition_met     : Write completed within thermal window
    fraction_aligned         : Fraction of grains aligned with target
    coercivity_at_write_temp : Medium coercivity at write temperature (Oe)
    applied_field_oe         : Applied write field (Oe)
    pulse_energy_pj          : Laser pulse energy (pJ)
    alignment_factor         : Head alignment quality [0, 1]
    error_type               : If failed: 'thermal'|'field'|'timing'|'alignment'|None
    """
    success:                  bool
    peak_temperature_k:       float
    write_temperature_k:      float
    thermal_condition_met:    bool
    field_condition_met:      bool
    timing_condition_met:     bool
    fraction_aligned:         float
    coercivity_at_write_temp: float
    applied_field_oe:         float
    pulse_energy_pj:          float
    alignment_factor:         float
    error_type:               Optional[str] = None


# ─────────────────────────────────────────────────────────────────────────────
#  HAMR SWITCHING MODEL
# ─────────────────────────────────────────────────────────────────────────────

class HAMRSwitchingModel:
    """
    Integrated HAMR write/read process model.

    Combines thermal, magnetic, and mechanical subsystems to evaluate
    write success probability for a given set of operating parameters.

    Parameters
    ----------
    config  : HAMRConfig master configuration object
    medium  : MagneticMedium instance (shared with simulation engine)
    laser   : ThermalLaserModel instance (shared with simulation engine)
    seed    : RNG seed
    """

    # Applied write field is approximated as a fraction of room-temperature Hc
    # In practice the head generates a fixed field; here we use a parametric
    # fraction of the nominal coercivity
    _WRITE_FIELD_FRACTION: float = 1.8   # H_applied = factor × Hc(room temp)

    def __init__(self, config: HAMRConfig, medium: MagneticMedium,
                 laser: ThermalLaserModel, seed: int = 42) -> None:
        self.config  = config
        self.medium  = medium
        self.laser   = laser
        self.rng     = np.random.default_rng(seed)
        self._write_count: int   = 0
        self._fail_count:  int   = 0

        # Compute the nominal applied write field
        self._applied_field_oe: float = (
            config.medium.coercivity_oe * self._WRITE_FIELD_FRACTION
        )

        _logger.info(
            f"Switching model initialised: "
            f"H_applied = {self._applied_field_oe:.0f} Oe, "
            f"T_write_target = {config.medium.write_temp_k:.0f} K"
        )

    # ──────────────────────────────────────────────────────────────────────────
    #  INDIVIDUAL WRITE EVENT
    # ──────────────────────────────────────────────────────────────────────────

    def execute_write(self,
                       target_direction: float = 1.0,
                       alignment_factor: float = 1.0,
                       generate_thermal_profile: bool = False) -> WriteEventResult:
        """
        Execute a single HAMR write operation and return the result.

        Evaluates all three write conditions (thermal, field, timing)
        and the mechanical alignment factor.

        Parameters
        ----------
        target_direction       : Desired bit value (+1 UP, -1 DOWN)
        alignment_factor       : Head-track alignment quality [0, 1]
                                 (from head positioning subsystem)
        generate_thermal_profile: Whether to compute spatial temperature map

        Returns
        -------
        WriteEventResult with complete write event data
        """
        self._write_count += 1
        t_write_thresh = self.config.medium.write_temp_k

        # ── 1. Thermal condition ──────────────────────────────────────────────
        thermal_profile: ThermalProfile = self.laser.simulate_pulse(
            write_temp_threshold_k=t_write_thresh,
            generate_map=generate_thermal_profile
        )
        t_peak           = thermal_profile.peak_temperature_k
        thermal_met      = t_peak >= t_write_thresh
        pulse_energy_pj  = thermal_profile.energy_delivered_pj

        # Effective write temperature: use peak or write threshold, whichever lower
        t_effective = min(t_peak, t_write_thresh * 1.05) if thermal_met else t_peak

        # ── 2. Field condition ────────────────────────────────────────────────
        hc_at_write_temp = self.medium.coercivity_at_temperature(t_effective)
        field_met        = self._applied_field_oe >= hc_at_write_temp

        # ── 3. Timing condition ───────────────────────────────────────────────
        # Write must complete within thermal window (time above T_write)
        # Approximate: write pulse duration vs required switching time
        t_cool = self.laser.time_to_cool_below(t_write_thresh)
        timing_met = self.config.laser.pulse_duration_ns >= 0.2  # minimum pulse

        # ── 4. Alignment condition ────────────────────────────────────────────
        # Stochastically interpret alignment factor as write success probability
        alignment_met = self.rng.random() < alignment_factor

        # ── 5. Determine success ──────────────────────────────────────────────
        all_conditions = thermal_met and field_met and timing_met and alignment_met
        success = all_conditions

        # Determine primary error type
        error_type: Optional[str] = None
        if not success:
            self._fail_count += 1
            if not thermal_met:
                error_type = "thermal"
            elif not field_met:
                error_type = "field"
            elif not timing_met:
                error_type = "timing"
            else:
                error_type = "alignment"

        # ── 6. Simulate grain switching if thermal + field conditions met ─────
        fraction_aligned = 0.0
        if thermal_met and field_met:
            write_result = self.medium.simulate_write_event(
                applied_field_oe  = self._applied_field_oe,
                temperature_k     = t_effective,
                pulse_duration_ns = self.config.laser.pulse_duration_ns,
                target_direction  = target_direction,
            )
            fraction_aligned = write_result["fraction_aligned"]
            # Override success based on grain-level outcome
            if not write_result["success"] and alignment_met:
                success    = False
                error_type = "field"

        return WriteEventResult(
            success                  = success,
            peak_temperature_k       = t_peak,
            write_temperature_k      = t_write_thresh,
            thermal_condition_met    = thermal_met,
            field_condition_met      = field_met,
            timing_condition_met     = timing_met,
            fraction_aligned         = fraction_aligned,
            coercivity_at_write_temp = hc_at_write_temp,
            applied_field_oe         = self._applied_field_oe,
            pulse_energy_pj          = pulse_energy_pj,
            alignment_factor         = alignment_factor,
            error_type               = error_type,
        )

    # ──────────────────────────────────────────────────────────────────────────
    #  BATCH WRITE SIMULATION
    # ──────────────────────────────────────────────────────────────────────────

    def simulate_write_batch(self,
                              n_writes:          int,
                              alignment_factors: Optional[np.ndarray] = None,
                              directions:        Optional[np.ndarray] = None) -> dict:
        """
        Simulate a batch of write operations and return aggregate statistics.

        Parameters
        ----------
        n_writes           : Number of write operations
        alignment_factors  : Per-write alignment quality array; uses 1.0 if None
        directions         : Per-write target directions; alternates +1/-1 if None

        Returns
        -------
        dict with:
          write_success_rate  : Fraction of successful writes
          thermal_fail_rate   : Fraction of failures due to thermal issues
          field_fail_rate     : Fraction of failures due to field issues
          alignment_fail_rate : Fraction of failures due to alignment
          mean_peak_temp_k    : Mean peak temperature (K)
          mean_energy_pj      : Mean pulse energy (pJ)
          total_failures      : Total failure count
          results             : List of WriteEventResult objects
        """
        if alignment_factors is None:
            alignment_factors = np.ones(n_writes)
        if directions is None:
            directions = np.array([1.0 if i % 2 == 0 else -1.0
                                   for i in range(n_writes)])

        results:       list[WriteEventResult] = []
        fail_thermal:  int = 0
        fail_field:    int = 0
        fail_alignment:int = 0
        fail_timing:   int = 0
        total_success: int = 0
        temp_sum:      float = 0.0
        energy_sum:    float = 0.0

        for i in range(n_writes):
            result = self.execute_write(
                target_direction = directions[i],
                alignment_factor = float(alignment_factors[i]),
            )
            results.append(result)

            if result.success:
                total_success += 1
            elif result.error_type == "thermal":
                fail_thermal  += 1
            elif result.error_type == "field":
                fail_field    += 1
            elif result.error_type == "alignment":
                fail_alignment += 1
            elif result.error_type == "timing":
                fail_timing   += 1

            temp_sum   += result.peak_temperature_k
            energy_sum += result.pulse_energy_pj

        total_failures = n_writes - total_success

        return {
            "write_success_rate":   total_success / n_writes,
            "thermal_fail_rate":    fail_thermal   / n_writes,
            "field_fail_rate":      fail_field     / n_writes,
            "alignment_fail_rate":  fail_alignment / n_writes,
            "timing_fail_rate":     fail_timing    / n_writes,
            "mean_peak_temp_k":     temp_sum   / n_writes,
            "mean_energy_pj":       energy_sum / n_writes,
            "total_failures":       total_failures,
            "n_writes":             n_writes,
            "results":              results,
        }

    # ──────────────────────────────────────────────────────────────────────────
    #  READ ERROR SIMULATION
    # ──────────────────────────────────────────────────────────────────────────

    def simulate_read(self, snr_db: float = 22.0,
                       bit_transition: bool = False) -> dict:
        """
        Simulate a single read operation with channel noise.

        Models the read channel as an AWGN channel where the probability
        of bit error depends on the read SNR.

        P_bit_error = 0.5 · erfc(sqrt(SNR_linear / 2))

        Parameters
        ----------
        snr_db        : Read channel signal-to-noise ratio (dB)
        bit_transition: Whether reading a bit transition (harder to detect)

        Returns
        -------
        dict with success, ber_probability, snr_db
        """
        snr_lin = 10.0 ** (snr_db / 10.0)

        # AWGN bit error probability
        from scipy.special import erfc
        ber = 0.5 * erfc(np.sqrt(snr_lin / 2.0))

        # Bit transitions have slightly higher error rate
        if bit_transition:
            ber *= 1.15

        success = bool(self.rng.random() > ber)

        return {
            "success":       success,
            "ber_estimate":  ber,
            "snr_db":        snr_db,
        }

    # ──────────────────────────────────────────────────────────────────────────
    #  ADJACENT TRACK ERASURE RISK
    # ──────────────────────────────────────────────────────────────────────────

    def adjacent_track_erasure_probability(self,
                                            track_spacing_nm: float) -> float:
        """
        Estimate probability of erasing data on adjacent tracks due to
        thermal spillover from the current write operation.

        If the thermal radius exceeds the track pitch, the adjacent track
        experiences temperatures above the write threshold.

        Parameters
        ----------
        track_spacing_nm : Centre-to-centre track pitch (nm)

        Returns
        -------
        Probability of adjacent track thermal erasure [0, 1]
        """
        t_pulse   = self.config.laser.pulse_duration_ns
        t_write   = self.config.medium.write_temp_k

        # Temperature at adjacent track centre
        t_adj = self.laser.temperature_at_radius(track_spacing_nm, t_pulse)

        if t_adj < t_write:
            return 0.0

        # Erasure probability scales with (T_adj - T_write) / (T_Curie - T_write)
        t_curie    = self.config.medium.curie_temp_k
        t_range    = max(t_curie - t_write, 1.0)
        excess     = t_adj - t_write
        prob       = float(np.clip(excess / t_range, 0.0, 1.0))
        return prob

    # ──────────────────────────────────────────────────────────────────────────
    #  DIAGNOSTICS
    # ──────────────────────────────────────────────────────────────────────────

    def write_statistics(self) -> dict:
        """Return cumulative write/fail statistics."""
        total = max(self._write_count, 1)
        return {
            "total_writes":   self._write_count,
            "total_failures": self._fail_count,
            "write_success_rate": (self._write_count - self._fail_count) / total,
        }

    def update_applied_field(self, new_field_oe: float) -> None:
        """Update the applied write field (for optimisation parameter sweeps)."""
        self._applied_field_oe = new_field_oe
        _logger.debug(f"Applied field updated: {new_field_oe:.0f} Oe")
