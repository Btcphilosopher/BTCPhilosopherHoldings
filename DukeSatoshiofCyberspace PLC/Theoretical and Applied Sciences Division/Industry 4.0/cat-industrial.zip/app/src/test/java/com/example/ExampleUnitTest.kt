package com.example

import com.example.data.EquipmentRepository
import com.example.model.FaultStatus
import com.example.model.MaintenancePriority
import com.example.model.RentalStatus
import com.example.model.WorkOrderStatus
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testRepositoryInitialization() {
        val repo = EquipmentRepository()
        val equipment = repo.equipmentList.value
        assertTrue("Equipment list should contain machinery records", equipment.isNotEmpty())
        assertEquals(6, equipment.size)
        assertEquals("EQ-CAT-336-01", repo.selectedEquipmentId.value)
    }

    @Test
    fun testFaultLifecycleTransitions() {
        val repo = EquipmentRepository()
        val faultId = "FLT-0912"

        // Initial state should be ACTIVE
        val initialFault = repo.faultsList.value.first { it.id == faultId }
        assertEquals(FaultStatus.ACTIVE, initialFault.status)

        // Acknowledge fault
        repo.acknowledgeFault(faultId, "Senior Tech J. Doe")
        val ackFault = repo.faultsList.value.first { it.id == faultId }
        assertEquals(FaultStatus.ACKNOWLEDGED, ackFault.status)
        assertEquals("Senior Tech J. Doe", ackFault.acknowledgedBy)

        // Resolve fault
        repo.resolveFault(faultId, "Replaced thermostat regulator kit.")
        val resolvedFault = repo.faultsList.value.first { it.id == faultId }
        assertEquals(FaultStatus.RESOLVED, resolvedFault.status)
        assertEquals("Replaced thermostat regulator kit.", resolvedFault.resolutionNotes)
    }

    @Test
    fun testWorkOrderCreationAndCompletion() {
        val repo = EquipmentRepository()
        val initialCount = repo.workOrdersList.value.size

        repo.createWorkOrder(
            equipmentId = "EQ-CAT-336-01",
            equipmentModel = "Cat 336",
            title = "Hydraulic Line Inspection",
            description = "Check high pressure main lines",
            priority = MaintenancePriority.HIGH,
            assignedTechnician = "Marcus Henderson",
            estimatedHours = 3.5
        )

        val updatedList = repo.workOrdersList.value
        assertEquals(initialCount + 1, updatedList.size)
        val created = updatedList.first()
        assertEquals(WorkOrderStatus.SCHEDULED, created.status)
        assertEquals("Hydraulic Line Inspection", created.title)

        // Complete work order
        repo.completeWorkOrder(created.id, "M. Henderson #441")
        val completed = repo.workOrdersList.value.first { it.id == created.id }
        assertEquals(WorkOrderStatus.COMPLETED, completed.status)
        assertEquals("M. Henderson #441", completed.technicianSignOff)
    }

    @Test
    fun testAtomicInventoryReservation() {
        val repo = EquipmentRepository()
        val partNumber = "1R-1808"
        val warehouseId = "WH-PEORIA"

        val partBefore = repo.partsList.value.first { it.partNumber == partNumber }
        val whBefore = partBefore.stockByWarehouse.first { it.warehouseId == warehouseId }
        val availBefore = whBefore.quantityAvailable

        val success = repo.reservePart(partNumber, warehouseId, 5)
        assertTrue("Reservation should succeed when stock is available", success)

        val partAfter = repo.partsList.value.first { it.partNumber == partNumber }
        val whAfter = partAfter.stockByWarehouse.first { it.warehouseId == warehouseId }
        assertEquals(availBefore - 5, whAfter.quantityAvailable)
        assertEquals(whBefore.quantityReserved + 5, whAfter.quantityReserved)
    }

    @Test
    fun testRentalReturnWorkflow() {
        val repo = EquipmentRepository()
        val rentalId = "RNT-2026-8801"

        repo.returnRental(rentalId, 3425.0, "All systems nominal, machine washed.")
        val rental = repo.rentalsList.value.first { it.id == rentalId }
        assertEquals(RentalStatus.RETURNED, rental.status)
        assertEquals(3425.0, rental.currentMeterHours, 0.01)
        assertEquals("All systems nominal, machine washed.", rental.returnConditionNotes)
    }
}
