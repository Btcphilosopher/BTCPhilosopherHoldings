package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.EquipmentRepository
import com.example.model.*
import kotlinx.coroutines.flow.*

class MainViewModel(
    private val repository: EquipmentRepository = EquipmentRepository()
) : ViewModel() {

    val equipmentList: StateFlow<List<Equipment>> = repository.equipmentList
    val selectedEquipmentId: StateFlow<String> = repository.selectedEquipmentId
    val telemetryMap: StateFlow<Map<String, TelemetryMeasurement>> = repository.telemetryMap
    val faultsList: StateFlow<List<DiagnosticFault>> = repository.faultsList
    val workOrdersList: StateFlow<List<WorkOrder>> = repository.workOrdersList
    val partsList: StateFlow<List<PartItem>> = repository.partsList
    val rentalsList: StateFlow<List<EquipmentRental>> = repository.rentalsList
    val isSimulatorRunning: StateFlow<Boolean> = repository.isSimulatorRunning
    val lastApiCallLog: StateFlow<String?> = repository.lastApiCallLog

    val selectedEquipment: StateFlow<Equipment?> = combine(
        equipmentList,
        selectedEquipmentId
    ) { list, id ->
        list.firstOrNull { it.id == id } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedTelemetry: StateFlow<TelemetryMeasurement?> = combine(
        telemetryMap,
        selectedEquipmentId
    ) { map, id ->
        map[id]
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _equipmentCategoryFilter = MutableStateFlow<EquipmentCategory?>(null)
    val equipmentCategoryFilter: StateFlow<EquipmentCategory?> = _equipmentCategoryFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun selectTab(index: Int) {
        _selectedTab.value = index
    }

    fun setCategoryFilter(category: EquipmentCategory?) {
        _equipmentCategoryFilter.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectEquipment(id: String) {
        repository.selectEquipment(id)
    }

    fun toggleSimulator() {
        repository.toggleSimulator()
    }

    fun acknowledgeFault(faultId: String, technician: String) {
        repository.acknowledgeFault(faultId, technician)
    }

    fun resolveFault(faultId: String, notes: String) {
        repository.resolveFault(faultId, notes)
    }

    fun createWorkOrder(
        equipmentId: String,
        equipmentModel: String,
        title: String,
        description: String,
        priority: MaintenancePriority,
        technician: String,
        hours: Double
    ) {
        repository.createWorkOrder(
            equipmentId = equipmentId,
            equipmentModel = equipmentModel,
            title = title,
            description = description,
            priority = priority,
            assignedTechnician = technician,
            estimatedHours = hours
        )
    }

    fun completeWorkOrder(workOrderId: String, signOff: String) {
        repository.completeWorkOrder(workOrderId, signOff)
    }

    fun reservePart(partNumber: String, warehouseId: String, qty: Int): Boolean {
        return repository.reservePart(partNumber, warehouseId, qty)
    }

    fun returnRental(rentalId: String, meterHours: Double, notes: String) {
        repository.returnRental(rentalId, meterHours, notes)
    }

    fun simulateApiEndpoint(endpoint: ApiEndpointInfo): String {
        return repository.simulateApiEndpoint(endpoint)
    }
}
