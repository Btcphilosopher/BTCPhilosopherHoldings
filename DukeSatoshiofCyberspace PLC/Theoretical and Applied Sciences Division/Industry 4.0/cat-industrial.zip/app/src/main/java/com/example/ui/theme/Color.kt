package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Caterpillar Industrial Equipment Signature Palette
val CatYellow = Color(0xFFFFCD11)
val CatYellowDark = Color(0xFFE5B50A)
val CatYellowContainer = Color(0xFF453600)
val OnCatYellowContainer = Color(0xFFFFE082)

val IndustrialDarkBackground = Color(0xFF141518)
val IndustrialDarkSurface = Color(0xFF1E2024)
val IndustrialDarkSurfaceVariant = Color(0xFF282B32)
val IndustrialBorder = Color(0xFF3B3F48)

val CatBlack = Color(0xFF111214)
val CatCharcoal = Color(0xFF222428)

val StatusActiveGreen = Color(0xFF43A047)
val StatusWarningAmber = Color(0xFFFFA000)
val StatusCriticalRed = Color(0xFFE53935)
val StatusIdleBlue = Color(0xFF1E88E5)

val TextPrimary = Color(0xFFF1F3F5)
val TextSecondary = Color(0xFFADB5BD)
val TextMuted = Color(0xFF6C757D)
