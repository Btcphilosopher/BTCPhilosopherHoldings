package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.*
import com.example.ui.theme.CatIndustrialTheme
import com.example.ui.theme.CatYellow
import com.example.ui.theme.StatusActiveGreen
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            CatIndustrialTheme {
                val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
                val equipmentList by viewModel.equipmentList.collectAsStateWithLifecycle()
                val selectedEquipment by viewModel.selectedEquipment.collectAsStateWithLifecycle()
                val telemetry by viewModel.selectedTelemetry.collectAsStateWithLifecycle()
                val faults by viewModel.faultsList.collectAsStateWithLifecycle()
                val workOrders by viewModel.workOrdersList.collectAsStateWithLifecycle()
                val parts by viewModel.partsList.collectAsStateWithLifecycle()
                val rentals by viewModel.rentalsList.collectAsStateWithLifecycle()
                val isSimulatorRunning by viewModel.isSimulatorRunning.collectAsStateWithLifecycle()
                val lastApiCallLog by viewModel.lastApiCallLog.collectAsStateWithLifecycle()
                val categoryFilter by viewModel.equipmentCategoryFilter.collectAsStateWithLifecycle()
                val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

                BackHandler(enabled = selectedTab != 0) {
                    viewModel.selectTab(0)
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        TopAppBar(
                            title = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(CatYellow),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PrecisionManufacturing,
                                            contentDescription = null,
                                            tint = Color.Black,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = "CAT INDUSTRIAL",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                                            color = CatYellow,
                                            letterSpacing = 1.sp
                                        )
                                        Text(
                                            text = "Equipment API Platform & Operations",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            },
                            actions = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(end = 8.dp)
                                ) {
                                    IconButton(
                                        onClick = { viewModel.toggleSimulator() },
                                        modifier = Modifier.testTag("action_toggle_simulator")
                                    ) {
                                        Icon(
                                            imageVector = if (isSimulatorRunning) Icons.Default.Sensors else Icons.Default.SensorsOff,
                                            contentDescription = "Toggle Telemetry Ingest",
                                            tint = if (isSimulatorRunning) StatusActiveGreen else Color.Gray
                                        )
                                    }
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.testTag("bottom_nav")
                        ) {
                            NavigationBarItem(
                                selected = selectedTab == 0,
                                onClick = { viewModel.selectTab(0) },
                                icon = { Icon(Icons.Default.Engineering, contentDescription = null) },
                                label = { Text("Fleet") },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = CatYellow,
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = CatYellow
                                ),
                                modifier = Modifier.testTag("nav_fleet")
                            )

                            NavigationBarItem(
                                selected = selectedTab == 1,
                                onClick = { viewModel.selectTab(1) },
                                icon = { Icon(Icons.Default.Speed, contentDescription = null) },
                                label = { Text("Telemetry") },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = CatYellow,
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = CatYellow
                                ),
                                modifier = Modifier.testTag("nav_telemetry")
                            )

                            NavigationBarItem(
                                selected = selectedTab == 2,
                                onClick = { viewModel.selectTab(2) },
                                icon = {
                                    BadgedBox(badge = {
                                        val activeCount = faults.count { it.status == com.example.model.FaultStatus.ACTIVE }
                                        if (activeCount > 0) {
                                            Badge { Text("$activeCount") }
                                        }
                                    }) {
                                        Icon(Icons.Default.Warning, contentDescription = null)
                                    }
                                },
                                label = { Text("Faults") },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = CatYellow,
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = CatYellow
                                ),
                                modifier = Modifier.testTag("nav_faults")
                            )

                            NavigationBarItem(
                                selected = selectedTab == 3,
                                onClick = { viewModel.selectTab(3) },
                                icon = { Icon(Icons.Default.Build, contentDescription = null) },
                                label = { Text("Service") },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = CatYellow,
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = CatYellow
                                ),
                                modifier = Modifier.testTag("nav_service")
                            )

                            NavigationBarItem(
                                selected = selectedTab == 4,
                                onClick = { viewModel.selectTab(4) },
                                icon = { Icon(Icons.Default.Inventory2, contentDescription = null) },
                                label = { Text("Parts") },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = CatYellow,
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = CatYellow
                                ),
                                modifier = Modifier.testTag("nav_parts")
                            )

                            NavigationBarItem(
                                selected = selectedTab == 5,
                                onClick = { viewModel.selectTab(5) },
                                icon = { Icon(Icons.Default.Code, contentDescription = null) },
                                label = { Text("API") },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = CatYellow,
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = CatYellow
                                ),
                                modifier = Modifier.testTag("nav_api")
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (selectedTab) {
                            0 -> FleetScreen(
                                equipmentList = equipmentList,
                                selectedCategory = categoryFilter,
                                searchQuery = searchQuery,
                                onCategorySelected = { viewModel.setCategoryFilter(it) },
                                onSearchChanged = { viewModel.setSearchQuery(it) },
                                onSelectEquipment = { viewModel.selectEquipment(it) },
                                onNavigateToTelemetry = {
                                    viewModel.selectEquipment(it)
                                    viewModel.selectTab(1)
                                }
                            )
                            1 -> TelemetryScreen(
                                equipmentList = equipmentList,
                                selectedEquipment = selectedEquipment,
                                telemetry = telemetry,
                                isSimulatorRunning = isSimulatorRunning,
                                onSelectEquipment = { viewModel.selectEquipment(it) },
                                onToggleSimulator = { viewModel.toggleSimulator() }
                            )
                            2 -> DiagnosticsScreen(
                                faults = faults,
                                onAcknowledgeFault = { id, tech -> viewModel.acknowledgeFault(id, tech) },
                                onResolveFault = { id, notes -> viewModel.resolveFault(id, notes) }
                            )
                            3 -> MaintenanceScreen(
                                equipmentList = equipmentList,
                                workOrders = workOrders,
                                onCreateWorkOrder = { id, model, title, desc, prio, tech, hrs ->
                                    viewModel.createWorkOrder(id, model, title, desc, prio, tech, hrs)
                                },
                                onCompleteWorkOrder = { id, signOff ->
                                    viewModel.completeWorkOrder(id, signOff)
                                }
                            )
                            4 -> PartsInventoryScreen(
                                partsList = parts,
                                onReservePart = { pNum, whId, qty -> viewModel.reservePart(pNum, whId, qty) }
                            )
                            5 -> ApiConsoleScreen(
                                lastApiCallLog = lastApiCallLog,
                                onExecuteEndpoint = { ep -> viewModel.simulateApiEndpoint(ep) }
                            )
                        }
                    }
                }
            }
        }
    }
}
