package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Equipment
import com.example.model.TelemetryMeasurement
import com.example.ui.components.TelemetryGaugeCard
import com.example.ui.theme.*

@Composable
fun TelemetryScreen(
    equipmentList: List<Equipment>,
    selectedEquipment: Equipment?,
    telemetry: TelemetryMeasurement?,
    isSimulatorRunning: Boolean,
    onSelectEquipment: (String) -> Unit,
    onToggleSimulator: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showManualIngestDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Equipment Selector Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            equipmentList.forEach { eq ->
                val isSelected = eq.id == selectedEquipment?.id
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelectEquipment(eq.id) },
                    label = { Text(eq.model.replace("Cat ", "")) },
                    leadingIcon = {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (eq.telemetryConnected) StatusActiveGreen else Color.Gray)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CatYellow,
                        selectedLabelColor = MaterialTheme.colorScheme.background
                    ),
                    modifier = Modifier.testTag("telemetry_select_${eq.id}")
                )
            }
        }

        // Live Header & Simulator Status Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = selectedEquipment?.model ?: "Equipment Telematics",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Gateway: PL542 4G/Sat • Protocol: MQTT v5 / CAN J1939",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Pulsing Live Indicator
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                        val alpha by infiniteTransition.animateFloat(
                            initialValue = 0.4f,
                            targetValue = 1f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(800, easing = LinearEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "alpha"
                        )

                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isSimulatorRunning) StatusActiveGreen.copy(alpha = alpha) else Color.Gray
                                )
                        )
                        Text(
                            text = if (isSimulatorRunning) "LIVE MQTT" else "PAUSED",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isSimulatorRunning) StatusActiveGreen else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "CURRENT CYCLE STATE",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = telemetry?.operatingState ?: "Active Telemetry Stream",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = CatYellow
                        )
                    }

                    FilledTonalButton(
                        onClick = onToggleSimulator,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (isSimulatorRunning) Color(0xFF3E2723) else Color(0xFF1B5E20),
                            contentColor = if (isSimulatorRunning) Color(0xFFFFCCBC) else Color(0xFFC8E6C9)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("toggle_simulator_btn")
                    ) {
                        Icon(
                            imageVector = if (isSimulatorRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isSimulatorRunning) "Pause Stream" else "Resume Stream")
                    }
                }
            }
        }

        // Live Telemetry Gauges Grid
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 6.dp)
                .testTag("telemetry_gauges_list"),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            item {
                // Tachometer RPM Hero Card
                val rpm = telemetry?.engineRpm ?: 0
                val rpmRatio = (rpm / 2400f).coerceIn(0f, 1f)

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ENGINE SPEED TACHOMETER",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "$rpm RPM",
                                style = MonospaceTelemetryStyle.copy(fontSize = 24.sp),
                                color = CatYellow
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Visual RPM Bar
                        LinearProgressIndicator(
                            progress = { rpmRatio },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(12.dp)
                                .clip(RoundedCornerShape(6.dp)),
                            color = if (rpm > 2000) StatusCriticalRed else if (rpm > 1750) CatYellow else StatusActiveGreen,
                            trackColor = MaterialTheme.colorScheme.surface
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("0 RPM", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("1200", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("1800", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("2400 MAX", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val temp = telemetry?.coolantTempC ?: 85.0
                    val tempColor = if (temp > 100.0) StatusCriticalRed else if (temp > 95.0) StatusWarningAmber else StatusActiveGreen
                    TelemetryGaugeCard(
                        title = "Coolant Temp",
                        value = "%.1f".format(temp),
                        unit = "°C",
                        icon = Icons.Default.Thermostat,
                        statusColor = tempColor,
                        modifier = Modifier.weight(1f)
                    )

                    val oilPressure = telemetry?.oilPressureKpa ?: 380.0
                    val oilColor = if (oilPressure < 250.0) StatusCriticalRed else StatusActiveGreen
                    TelemetryGaugeCard(
                        title = "Oil Pressure",
                        value = "%.0f".format(oilPressure),
                        unit = "kPa",
                        icon = Icons.Default.Speed,
                        statusColor = oilColor,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TelemetryGaugeCard(
                        title = "Fuel Level",
                        value = "%.1f".format(telemetry?.fuelLevelPct ?: 65.0),
                        unit = "%",
                        icon = Icons.Default.LocalGasStation,
                        statusColor = CatYellow,
                        modifier = Modifier.weight(1f)
                    )

                    TelemetryGaugeCard(
                        title = "Fuel Burn Rate",
                        value = "%.1f".format(telemetry?.fuelRateLph ?: 28.0),
                        unit = "L/h",
                        icon = Icons.Default.Opacity,
                        statusColor = CatYellow,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TelemetryGaugeCard(
                        title = "Battery / Bus",
                        value = "%.1f".format(telemetry?.batteryVoltageV ?: 27.8),
                        unit = "V DC",
                        icon = Icons.Default.ElectricBolt,
                        statusColor = StatusActiveGreen,
                        modifier = Modifier.weight(1f)
                    )

                    TelemetryGaugeCard(
                        title = "Hydraulic Main",
                        value = "%.0f".format(telemetry?.hydraulicPressureBar ?: 320.0),
                        unit = "bar",
                        icon = Icons.Default.Compress,
                        statusColor = CatYellow,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TelemetryGaugeCard(
                        title = "Current Payload",
                        value = "%.1f".format(telemetry?.payloadTonnes ?: 0.0),
                        unit = "tonnes",
                        icon = Icons.Default.Scale,
                        statusColor = if ((telemetry?.payloadTonnes ?: 0.0) > 0) CatYellow else Color.Gray,
                        modifier = Modifier.weight(1f)
                    )

                    TelemetryGaugeCard(
                        title = "Engine Hours",
                        value = "%.2f".format(telemetry?.engineHours ?: 3000.0),
                        unit = "hrs",
                        icon = Icons.Default.AccessTime,
                        statusColor = CatYellow,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}
