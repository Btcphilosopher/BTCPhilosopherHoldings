package com.example.model

enum class RentalStatus(val label: String) {
    RESERVED("Reserved"),
    DISPATCHED("Dispatched / Active"),
    INSPECTION_PENDING("Return Inspection Pending"),
    RETURNED("Returned & Closed")
}

data class EquipmentRental(
    val id: String,
    val equipmentId: String,
    val equipmentModel: String,
    val customerName: String,
    val jobSite: String,
    val startDate: String,
    val estimatedEndDate: String,
    val initialMeterHours: Double,
    val currentMeterHours: Double,
    val dailyRateUsd: Double,
    val status: RentalStatus,
    val returnConditionNotes: String? = null
)
