package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MockIndustrialData
import com.example.model.ApiEndpointInfo
import com.example.ui.theme.*

@Composable
fun ApiConsoleScreen(
    lastApiCallLog: String?,
    onExecuteEndpoint: (ApiEndpointInfo) -> String,
    modifier: Modifier = Modifier
) {
    var selectedEndpoint by remember { mutableStateOf(MockIndustrialData.apiEndpointsDocumentation.first()) }
    var activeResponsePayload by remember { mutableStateOf(selectedEndpoint.responseSample) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Caterpillar API Platform Console",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "OpenAPI 3.1 • FastAPI Backend • OAuth2 Scopes",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Live Log Banner
        if (lastApiCallLog != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = CatYellowContainer),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Terminal, contentDescription = null, tint = CatYellow, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "LAST GATEWAY EVENT: $lastApiCallLog",
                        style = MonospaceTelemetryStyle.copy(fontSize = 11.sp),
                        color = OnCatYellowContainer
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("api_console_list"),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            item {
                Text(
                    text = "DOCUMENTED ENTERPRISE ENDPOINTS (/api/v1)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            items(MockIndustrialData.apiEndpointsDocumentation) { endpoint ->
                val isSelected = selectedEndpoint.path == endpoint.path && selectedEndpoint.method == endpoint.method
                val methodColor = when (endpoint.method) {
                    "GET" -> Color(0xFF4CAF50)
                    "POST" -> CatYellow
                    "PATCH" -> Color(0xFF29B6F6)
                    "DELETE" -> StatusCriticalRed
                    else -> Color.Gray
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("endpoint_card_${endpoint.method}_${endpoint.path.replace("/", "_")}"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(methodColor.copy(alpha = 0.2f))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = endpoint.method,
                                        style = MonospaceTelemetryStyle.copy(fontSize = 12.sp),
                                        fontWeight = FontWeight.Bold,
                                        color = methodColor
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = endpoint.path,
                                    style = MonospaceTelemetryStyle.copy(fontSize = 13.sp),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Text(
                                text = endpoint.category,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = endpoint.summary,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = endpoint.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = {
                                    selectedEndpoint = endpoint
                                    activeResponsePayload = onExecuteEndpoint(endpoint)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) CatYellow else MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = if (isSelected) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onPrimaryContainer
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("test_endpoint_${endpoint.path.replace("/", "_")}")
                            ) {
                                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Execute Test Call", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "INSPECTOR: ${selectedEndpoint.method} ${selectedEndpoint.path}",
                                style = MonospaceTelemetryStyle.copy(fontSize = 12.sp),
                                color = CatYellow
                            )
                            Text(
                                text = "Status: 200 OK",
                                style = MaterialTheme.typography.labelSmall,
                                color = StatusActiveGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (selectedEndpoint.requestSample != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("REQUEST BODY (JSON):", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp),
                                color = MaterialTheme.colorScheme.background,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = selectedEndpoint.requestSample ?: "",
                                    style = MonospaceTelemetryStyle.copy(fontSize = 11.sp),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text("RESPONSE PAYLOAD (JSON):", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            color = MaterialTheme.colorScheme.background,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = activeResponsePayload,
                                style = MonospaceTelemetryStyle.copy(fontSize = 11.sp),
                                color = CatYellow,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
