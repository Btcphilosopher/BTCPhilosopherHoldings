package com.example.model

enum class FaultSeverity(val label: String) {
    INFO("Level 1 - Information"),
    WARNING("Level 2 - Maintenance Required"),
    DERATE("Level 2S - Engine Derate Active"),
    CRITICAL("Level 3 - Immediate Shutdown Required")
}

enum class FaultStatus {
    ACTIVE,
    ACKNOWLEDGED,
    RESOLVED
}

data class DiagnosticFault(
    val id: String,
    val equipmentId: String,
    val equipmentModel: String,
    val code: String, // e.g. MID 036 - CID 0100 - FMI 01
    val description: String,
    val sourceSubsystem: String, // Engine, Hydraulics, Electrical, Transmission
    val severity: FaultSeverity,
    val status: FaultStatus,
    val timestamp: String,
    val engineHoursAtFault: Double,
    val acknowledgedBy: String? = null,
    val acknowledgedAt: String? = null,
    val resolutionNotes: String? = null,
    val resolvedAt: String? = null,
    val associatedWorkOrderId: String? = null
)
