package com.example.data

import com.example.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.Instant
import kotlin.random.Random

class EquipmentRepository(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) {
    private val _equipmentList = MutableStateFlow(MockIndustrialData.initialEquipmentList)
    val equipmentList: StateFlow<List<Equipment>> = _equipmentList.asStateFlow()

    private val _selectedEquipmentId = MutableStateFlow("EQ-CAT-336-01")
    val selectedEquipmentId: StateFlow<String> = _selectedEquipmentId.asStateFlow()

    private val _telemetryMap = MutableStateFlow(MockIndustrialData.initialTelemetry)
    val telemetryMap: StateFlow<Map<String, TelemetryMeasurement>> = _telemetryMap.asStateFlow()

    private val _faultsList = MutableStateFlow(MockIndustrialData.initialFaults)
    val faultsList: StateFlow<List<DiagnosticFault>> = _faultsList.asStateFlow()

    private val _workOrdersList = MutableStateFlow(MockIndustrialData.initialWorkOrders)
    val workOrdersList: StateFlow<List<WorkOrder>> = _workOrdersList.asStateFlow()

    private val _partsList = MutableStateFlow(MockIndustrialData.initialPartsCatalog)
    val partsList: StateFlow<List<PartItem>> = _partsList.asStateFlow()

    private val _rentalsList = MutableStateFlow(MockIndustrialData.initialRentals)
    val rentalsList: StateFlow<List<EquipmentRental>> = _rentalsList.asStateFlow()

    private val _isSimulatorRunning = MutableStateFlow(true)
    val isSimulatorRunning: StateFlow<Boolean> = _isSimulatorRunning.asStateFlow()

    private val _lastApiCallLog = MutableStateFlow<String?>(null)
    val lastApiCallLog: StateFlow<String?> = _lastApiCallLog.asStateFlow()

    private var simulatorJob: Job? = null

    init {
        startTelemetrySimulator()
    }

    fun selectEquipment(id: String) {
        _selectedEquipmentId.value = id
    }

    fun toggleSimulator() {
        val current = _isSimulatorRunning.value
        _isSimulatorRunning.value = !current
        if (!current) {
            startTelemetrySimulator()
        } else {
            simulatorJob?.cancel()
            simulatorJob = null
        }
    }

    private fun startTelemetrySimulator() {
        simulatorJob?.cancel()
        simulatorJob = scope.launch {
            while (_isSimulatorRunning.value) {
                delay(2000) // 2-second telemetry cycle
                val selectedId = _selectedEquipmentId.value
                _telemetryMap.update { currentMap ->
                    val updated = currentMap.toMutableMap()
                    currentMap.forEach { (eqId, prev) ->
                        val isSelected = eqId == selectedId
                        val rpmVariance = if (prev.engineRpm > 0) Random.nextInt(-40, 45) else 0
                        val newRpm = (prev.engineRpm + rpmVariance).coerceIn(600, 2200)

                        val tempVariance = Random.nextDouble(-0.3, 0.4)
                        val newTemp = (prev.coolantTempC + tempVariance).coerceIn(40.0, 115.0)

                        val oilVariance = Random.nextDouble(-5.0, 5.0)
                        val newOil = (prev.oilPressureKpa + oilVariance).coerceIn(200.0, 520.0)

                        val newFuel = (prev.fuelLevelPct - 0.02).coerceAtLeast(5.0)
                        val newHours = prev.engineHours + 0.001

                        updated[eqId] = prev.copy(
                            engineRpm = if (prev.engineRpm == 0) 0 else newRpm,
                            coolantTempC = Math.round(newTemp * 10.0) / 10.0,
                            oilPressureKpa = Math.round(newOil * 10.0) / 10.0,
                            fuelLevelPct = Math.round(newFuel * 10.0) / 10.0,
                            engineHours = Math.round(newHours * 1000.0) / 1000.0,
                            timestamp = Instant.now().toString()
                        )
                    }
                    updated
                }
            }
        }
    }

    fun acknowledgeFault(faultId: String, technician: String) {
        val now = Instant.now().toString()
        _faultsList.update { list ->
            list.map { fault ->
                if (fault.id == faultId) {
                    fault.copy(
                        status = FaultStatus.ACKNOWLEDGED,
                        acknowledgedBy = technician,
                        acknowledgedAt = now
                    )
                } else fault
            }
        }
        _lastApiCallLog.value = "POST /api/v1/faults/$faultId/acknowledge [200 OK]"
    }

    fun resolveFault(faultId: String, resolutionNotes: String) {
        val now = Instant.now().toString()
        _faultsList.update { list ->
            list.map { fault ->
                if (fault.id == faultId) {
                    fault.copy(
                        status = FaultStatus.RESOLVED,
                        resolutionNotes = resolutionNotes,
                        resolvedAt = now
                    )
                } else fault
            }
        }
        _lastApiCallLog.value = "POST /api/v1/faults/$faultId/resolve [200 OK]"
    }

    fun createWorkOrder(
        equipmentId: String,
        equipmentModel: String,
        title: String,
        description: String,
        priority: MaintenancePriority,
        assignedTechnician: String,
        estimatedHours: Double
    ) {
        val newId = "WO-2026-${Random.nextInt(5000, 9999)}"
        val wo = WorkOrder(
            id = newId,
            equipmentId = equipmentId,
            equipmentModel = equipmentModel,
            title = title,
            description = description,
            priority = priority,
            status = WorkOrderStatus.SCHEDULED,
            assignedTechnician = assignedTechnician,
            scheduledDate = "2026-11-04",
            laborHoursEstimated = estimatedHours
        )
        _workOrdersList.update { listOf(wo) + it }
        _lastApiCallLog.value = "POST /api/v1/work-orders -> $newId [201 Created]"
    }

    fun completeWorkOrder(workOrderId: String, signOff: String) {
        val now = Instant.now().toString()
        _workOrdersList.update { list ->
            list.map { wo ->
                if (wo.id == workOrderId) {
                    wo.copy(
                        status = WorkOrderStatus.COMPLETED,
                        technicianSignOff = signOff,
                        completedAt = now
                    )
                } else wo
            }
        }
        _lastApiCallLog.value = "POST /api/v1/work-orders/$workOrderId/complete [200 OK]"
    }

    fun reservePart(partNumber: String, warehouseId: String, qty: Int): Boolean {
        var success = false
        _partsList.update { list ->
            list.map { part ->
                if (part.partNumber == partNumber) {
                    val updatedStocks = part.stockByWarehouse.map { wh ->
                        if (wh.warehouseId == warehouseId && wh.quantityAvailable >= qty) {
                            success = true
                            wh.copy(
                                quantityReserved = wh.quantityReserved + qty,
                                quantityAvailable = wh.quantityAvailable - qty
                            )
                        } else wh
                    }
                    if (success) {
                        part.copy(
                            totalAvailable = part.totalAvailable - qty,
                            stockByWarehouse = updatedStocks
                        )
                    } else part
                } else part
            }
        }
        if (success) {
            _lastApiCallLog.value = "POST /api/v1/inventory/reservations -> Part $partNumber ($qty units at $warehouseId) [200 OK]"
        }
        return success
    }

    fun returnRental(rentalId: String, meterHours: Double, notes: String) {
        _rentalsList.update { list ->
            list.map { rental ->
                if (rental.id == rentalId) {
                    rental.copy(
                        status = RentalStatus.RETURNED,
                        currentMeterHours = meterHours,
                        returnConditionNotes = notes
                    )
                } else rental
            }
        }
        _lastApiCallLog.value = "POST /api/v1/rentals/$rentalId/return [200 OK]"
    }

    fun simulateApiEndpoint(endpoint: ApiEndpointInfo): String {
        _lastApiCallLog.value = "${endpoint.method} ${endpoint.path} [200 OK - ${Random.nextInt(18, 48)}ms]"
        return endpoint.responseSample
    }
}
