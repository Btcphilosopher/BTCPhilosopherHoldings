package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PartItem
import com.example.model.WarehouseStock
import com.example.ui.theme.*

@Composable
fun PartsInventoryScreen(
    partsList: List<PartItem>,
    onReservePart: (String, String, Int) -> Boolean,
    modifier: Modifier = Modifier
) {
    var partToReserve by remember { mutableStateOf<PartItem?>(null) }
    var selectedWarehouseId by remember { mutableStateOf("WH-PEORIA") }
    var reservationQty by remember { mutableStateOf("2") }
    var reservationSuccessMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Genuine Cat® Parts & Inventory",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Peoria Hub • Dallas Depot • Rotterdam European DC",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (reservationSuccessMsg != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = StatusActiveGreen.copy(alpha = 0.15f)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusActiveGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = reservationSuccessMsg ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusActiveGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("parts_inventory_list"),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(partsList, key = { it.partNumber }) { part ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("part_card_${part.partNumber}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = part.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "CAT P/N: ${part.partNumber} • Category: ${part.category}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CatYellow
                                )
                            }

                            Text(
                                text = "$%.2f".format(part.unitPriceUsd),
                                style = MonospaceTelemetryStyle.copy(fontSize = 16.sp),
                                color = CatYellow
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Compatible: ${part.compatibleModels.joinToString(", ")}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "WAREHOUSE AVAILABILITY",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(4.dp))
                        part.stockByWarehouse.forEach { wh ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${wh.warehouseName} (${wh.locationCity})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${wh.quantityAvailable} avail (${wh.quantityReserved} res)",
                                    style = MonospaceTelemetryStyle.copy(fontSize = 12.sp),
                                    color = if (wh.quantityAvailable > 0) StatusActiveGreen else StatusCriticalRed
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                partToReserve = part
                                selectedWarehouseId = part.stockByWarehouse.firstOrNull()?.warehouseId ?: "WH-PEORIA"
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("reserve_part_btn_${part.partNumber}"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CatYellow,
                                contentColor = MaterialTheme.colorScheme.background
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Allocate & Reserve Parts", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Reservation Dialog
    if (partToReserve != null) {
        val part = partToReserve!!
        AlertDialog(
            onDismissRequest = { partToReserve = null },
            title = { Text("Atomic Inventory Reservation") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Part: ${part.name} (${part.partNumber})", fontWeight = FontWeight.Bold, color = CatYellow)

                    Text("Select Distribution Warehouse:", style = MaterialTheme.typography.labelSmall)
                    part.stockByWarehouse.forEach { wh ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                        ) {
                            RadioButton(
                                selected = selectedWarehouseId == wh.warehouseId,
                                onClick = { selectedWarehouseId = wh.warehouseId }
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("${wh.warehouseName} (${wh.quantityAvailable} in stock)")
                        }
                    }

                    OutlinedTextField(
                        value = reservationQty,
                        onValueChange = { reservationQty = it },
                        label = { Text("Quantity to Reserve") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val qty = reservationQty.toIntOrNull() ?: 1
                        val ok = onReservePart(part.partNumber, selectedWarehouseId, qty)
                        if (ok) {
                            reservationSuccessMsg = "Successfully reserved $qty units of ${part.partNumber} at $selectedWarehouseId!"
                        }
                        partToReserve = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CatYellow, contentColor = MaterialTheme.colorScheme.background)
                ) {
                    Text("Confirm Reservation", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { partToReserve = null }) { Text("Cancel") }
            }
        )
    }
}
