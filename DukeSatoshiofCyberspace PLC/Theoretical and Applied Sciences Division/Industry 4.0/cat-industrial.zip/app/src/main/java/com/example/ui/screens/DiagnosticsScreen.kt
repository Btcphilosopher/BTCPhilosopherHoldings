package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DiagnosticFault
import com.example.model.FaultSeverity
import com.example.model.FaultStatus
import com.example.ui.theme.*

@Composable
fun DiagnosticsScreen(
    faults: List<DiagnosticFault>,
    onAcknowledgeFault: (String, String) -> Unit,
    onResolveFault: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedStatusFilter by remember { mutableStateOf<FaultStatus?>(null) }
    var faultToAcknowledge by remember { mutableStateOf<DiagnosticFault?>(null) }
    var faultToResolve by remember { mutableStateOf<DiagnosticFault?>(null) }
    var techNameInput by remember { mutableStateOf("Lead Tech M. Vance") }
    var resolutionNotesInput by remember { mutableStateOf("") }

    val filteredFaults = remember(faults, selectedStatusFilter) {
        if (selectedStatusFilter == null) faults else faults.filter { it.status == selectedStatusFilter }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Status Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedStatusFilter == null,
                onClick = { selectedStatusFilter = null },
                label = { Text("All DTCs (${faults.size})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CatYellow,
                    selectedLabelColor = MaterialTheme.colorScheme.background
                ),
                modifier = Modifier.testTag("filter_faults_all")
            )
            FaultStatus.values().forEach { status ->
                val count = faults.count { it.status == status }
                FilterChip(
                    selected = selectedStatusFilter == status,
                    onClick = { selectedStatusFilter = if (selectedStatusFilter == status) null else status },
                    label = { Text("${status.name} ($count)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CatYellow,
                        selectedLabelColor = MaterialTheme.colorScheme.background
                    ),
                    modifier = Modifier.testTag("filter_faults_${status.name.lowercase()}")
                )
            }
        }

        // Faults List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("diagnostics_list"),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(filteredFaults, key = { it.id }) { fault ->
                val (badgeColor, badgeTextColor) = when (fault.severity) {
                    FaultSeverity.INFO -> Pair(Color(0xFF2196F3).copy(alpha = 0.2f), Color(0xFF64B5F6))
                    FaultSeverity.WARNING -> Pair(StatusWarningAmber.copy(alpha = 0.25f), StatusWarningAmber)
                    FaultSeverity.DERATE -> Pair(Color(0xFFFF9800).copy(alpha = 0.3f), Color(0xFFFFB74D))
                    FaultSeverity.CRITICAL -> Pair(StatusCriticalRed.copy(alpha = 0.3f), StatusCriticalRed)
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("fault_card_${fault.id}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = fault.code,
                                    style = MonospaceTelemetryStyle.copy(fontSize = 15.sp),
                                    color = CatYellow
                                )
                                Text(
                                    text = "${fault.equipmentModel} (${fault.equipmentId})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(badgeColor)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = fault.severity.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = badgeTextColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = fault.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "SUBSYSTEM",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = fault.sourceSubsystem,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Column {
                                Text(
                                    text = "AT ENGINE HOURS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "%.1f hrs".format(fault.engineHoursAtFault),
                                    style = MonospaceTelemetryStyle.copy(fontSize = 13.sp),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "STATUS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = fault.status.name,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = when (fault.status) {
                                        FaultStatus.ACTIVE -> StatusCriticalRed
                                        FaultStatus.ACKNOWLEDGED -> StatusWarningAmber
                                        FaultStatus.RESOLVED -> StatusActiveGreen
                                    }
                                )
                            }
                        }

                        if (fault.acknowledgedBy != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Acknowledged by ${fault.acknowledgedBy} at ${fault.acknowledgedAt?.take(16)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (fault.resolutionNotes != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Resolution: ${fault.resolutionNotes}",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusActiveGreen
                            )
                        }

                        // Action Buttons
                        if (fault.status != FaultStatus.RESOLVED) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (fault.status == FaultStatus.ACTIVE) {
                                    OutlinedButton(
                                        onClick = { faultToAcknowledge = fault },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("ack_fault_btn_${fault.id}"),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Done, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Acknowledge")
                                    }
                                }

                                Button(
                                    onClick = {
                                        resolutionNotesInput = "Inspected and rectified component per Cat SIS service manual."
                                        faultToResolve = fault
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("resolve_fault_btn_${fault.id}"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CatYellow,
                                        contentColor = MaterialTheme.colorScheme.background
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Resolve Fault", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Acknowledge Dialog
    if (faultToAcknowledge != null) {
        AlertDialog(
            onDismissRequest = { faultToAcknowledge = null },
            title = { Text("Acknowledge Diagnostic Fault") },
            text = {
                Column {
                    Text("Record field technician acknowledgement for ${faultToAcknowledge?.code}:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = techNameInput,
                        onValueChange = { techNameInput = it },
                        label = { Text("Technician / Dispatcher") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        faultToAcknowledge?.let { onAcknowledgeFault(it.id, techNameInput) }
                        faultToAcknowledge = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CatYellow, contentColor = MaterialTheme.colorScheme.background)
                ) {
                    Text("Confirm Acknowledgement", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { faultToAcknowledge = null }) { Text("Cancel") }
            }
        )
    }

    // Resolve Dialog
    if (faultToResolve != null) {
        AlertDialog(
            onDismissRequest = { faultToResolve = null },
            title = { Text("Resolve Diagnostic Trouble Code") },
            text = {
                Column {
                    Text("Enter repair details and evidence for ${faultToResolve?.code}:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = resolutionNotesInput,
                        onValueChange = { resolutionNotesInput = it },
                        label = { Text("Resolution Notes & Replaced Parts") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        faultToResolve?.let { onResolveFault(it.id, resolutionNotesInput) }
                        faultToResolve = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CatYellow, contentColor = MaterialTheme.colorScheme.background)
                ) {
                    Text("Mark as Resolved", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { faultToResolve = null }) { Text("Cancel") }
            }
        )
    }
}
