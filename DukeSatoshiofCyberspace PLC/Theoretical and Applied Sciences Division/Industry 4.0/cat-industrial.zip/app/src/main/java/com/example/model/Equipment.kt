package com.example.model

enum class EquipmentCategory(val displayName: String) {
    EXCAVATOR("Excavators"),
    ARTICULATED_TRUCK("Articulated Trucks"),
    DOZER("Track-Type Tractors / Dozers"),
    WHEEL_LOADER("Wheel Loaders"),
    MOTOR_GRADER("Motor Graders"),
    MINING_TRUCK("Mining Trucks"),
    GENERATOR("Power Systems / Generators")
}

enum class OperationalStatus(val label: String) {
    OPERATING("Operating"),
    IDLE("Idle"),
    STANDBY("Standby"),
    MAINTENANCE_DUE("Maintenance Due"),
    DERATED("Derated / Warning"),
    CRITICAL_FAULT("Critical Fault")
}

data class EquipmentSpecification(
    val engineModel: String,
    val netPowerHp: Int,
    val operatingWeightKg: Double,
    val ratedPayloadOrCapacity: String,
    val fuelTankCapacityLiters: Double,
    val hydraulicSystemMaxBar: Double,
    val emissionStandard: String
)

data class EquipmentLocation(
    val latitude: Double,
    val longitude: Double,
    val siteName: String
)

data class Equipment(
    val id: String,
    val model: String,
    val serialNumber: String,
    val category: EquipmentCategory,
    val productFamily: String,
    val modelYear: Int,
    val owningOrganisation: String,
    val operatingOrganisation: String,
    val assignedDealer: String,
    val status: OperationalStatus,
    val engineHours: Double,
    val odometerKm: Double,
    val lastServiceDate: String,
    val nextServiceDueHours: Double,
    val specifications: EquipmentSpecification,
    val location: EquipmentLocation,
    val telemetryConnected: Boolean = true
)
