package com.example.model

data class WarehouseStock(
    val warehouseId: String,
    val warehouseName: String,
    val locationCity: String,
    val quantityOnHand: Int,
    val quantityReserved: Int,
    val quantityAvailable: Int
)

data class PartItem(
    val partNumber: String,
    val name: String,
    val category: String, // Filtration, Engine, Hydraulics, Undercarriage, Ground Engaging
    val unitPriceUsd: Double,
    val compatibleModels: List<String>,
    val leadTimeDays: Int,
    val totalAvailable: Int,
    val stockByWarehouse: List<WarehouseStock>
)

data class PartReservation(
    val reservationId: String,
    val partNumber: String,
    val warehouseId: String,
    val quantity: Int,
    val requestedForWorkOrderId: String,
    val reservedAt: String,
    val status: String // ACTIVE, CONSUMED, RELEASED
)
