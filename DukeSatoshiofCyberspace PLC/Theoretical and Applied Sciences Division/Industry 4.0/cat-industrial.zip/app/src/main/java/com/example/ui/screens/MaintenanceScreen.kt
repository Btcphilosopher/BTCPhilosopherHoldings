package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Equipment
import com.example.model.MaintenancePriority
import com.example.model.WorkOrder
import com.example.model.WorkOrderStatus
import com.example.ui.theme.*

@Composable
fun MaintenanceScreen(
    equipmentList: List<Equipment>,
    workOrders: List<WorkOrder>,
    onCreateWorkOrder: (String, String, String, String, MaintenancePriority, String, Double) -> Unit,
    onCompleteWorkOrder: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var selectedOrderToComplete by remember { mutableStateOf<WorkOrder?>(null) }
    var signOffInput by remember { mutableStateOf("Tech M. Vance #1049") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Top Action Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Service & Work Orders",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${workOrders.count { it.status != WorkOrderStatus.COMPLETED }} Active Orders",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = { showCreateDialog = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = CatYellow,
                    contentColor = MaterialTheme.colorScheme.background
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("create_work_order_btn")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("New Work Order", fontWeight = FontWeight.Bold)
            }
        }

        // Work Orders List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("work_orders_list"),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(workOrders, key = { it.id }) { wo ->
                val (priorityBg, priorityText) = when (wo.priority) {
                    MaintenancePriority.LOW -> Pair(Color(0xFF2E7D32).copy(alpha = 0.2f), StatusActiveGreen)
                    MaintenancePriority.MEDIUM -> Pair(StatusWarningAmber.copy(alpha = 0.2f), StatusWarningAmber)
                    MaintenancePriority.HIGH -> Pair(Color(0xFFFF9800).copy(alpha = 0.25f), Color(0xFFFFB74D))
                    MaintenancePriority.EMERGENCY -> Pair(StatusCriticalRed.copy(alpha = 0.25f), StatusCriticalRed)
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("work_order_card_${wo.id}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = wo.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${wo.id} • ${wo.equipmentModel}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CatYellow
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(priorityBg)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = wo.priority.label.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = priorityText,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = wo.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("ASSIGNED LEAD", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(wo.assignedTechnician, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                            }
                            Column {
                                Text("LABOR HOURS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("%.1f / %.1f hrs".format(wo.laborHoursLogged, wo.laborHoursEstimated), style = MonospaceTelemetryStyle.copy(fontSize = 13.sp), color = MaterialTheme.colorScheme.onSurface)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("STATUS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    wo.status.label,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (wo.status == WorkOrderStatus.COMPLETED) StatusActiveGreen else CatYellow
                                )
                            }
                        }

                        if (wo.partsConsumed.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Parts Required/Consumed: ${wo.partsConsumed.joinToString(", ")}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (wo.completedAt != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Completed: ${wo.completedAt.take(16)} by ${wo.technicianSignOff}",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusActiveGreen
                            )
                        } else {
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { selectedOrderToComplete = wo },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("complete_work_order_${wo.id}"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Sign-Off & Complete Work Order")
                            }
                        }
                    }
                }
            }
        }
    }

    // Create Work Order Dialog
    if (showCreateDialog) {
        var selectedEqId by remember { mutableStateOf(equipmentList.firstOrNull()?.id ?: "") }
        var titleInput by remember { mutableStateOf("PM 500-Hour Interval Service") }
        var descInput by remember { mutableStateOf("Drain crankcase oil, replace filters, calibrate electronic sensors, check cooling package.") }
        var prioritySelected by remember { mutableStateOf(MaintenancePriority.MEDIUM) }
        var techInput by remember { mutableStateOf("Marcus Henderson (Field Tech)") }
        var estHoursInput by remember { mutableStateOf("4.5") }

        val eq = equipmentList.firstOrNull { it.id == selectedEqId }

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Generate Maintenance Work Order") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Machine: ${eq?.model ?: "Select Machine"}", fontWeight = FontWeight.Bold, color = CatYellow)

                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        label = { Text("Work Order Title") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        label = { Text("Service Description & Checklist") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )

                    OutlinedTextField(
                        value = techInput,
                        onValueChange = { techInput = it },
                        label = { Text("Assigned Field Specialist") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = estHoursInput,
                        onValueChange = { estHoursInput = it },
                        label = { Text("Estimated Labor Hours") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val hours = estHoursInput.toDoubleOrNull() ?: 4.0
                        onCreateWorkOrder(
                            selectedEqId,
                            eq?.model ?: "Cat Equipment",
                            titleInput,
                            descInput,
                            prioritySelected,
                            techInput,
                            hours
                        )
                        showCreateDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CatYellow, contentColor = MaterialTheme.colorScheme.background)
                ) {
                    Text("Dispatch Work Order", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Complete Order Dialog
    if (selectedOrderToComplete != null) {
        AlertDialog(
            onDismissRequest = { selectedOrderToComplete = null },
            title = { Text("Sign-Off Work Order") },
            text = {
                Column {
                    Text("Record final technician sign-off for ${selectedOrderToComplete?.title}:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = signOffInput,
                        onValueChange = { signOffInput = it },
                        label = { Text("Technician Certification & Signature") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        selectedOrderToComplete?.let { onCompleteWorkOrder(it.id, signOffInput) }
                        selectedOrderToComplete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CatYellow, contentColor = MaterialTheme.colorScheme.background)
                ) {
                    Text("Confirm & Close Order", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedOrderToComplete = null }) { Text("Cancel") }
            }
        )
    }
}
