package com.example.model

data class ApiEndpointInfo(
    val path: String,
    val method: String,
    val category: String,
    val summary: String,
    val description: String,
    val requestSample: String? = null,
    val responseSample: String
)
