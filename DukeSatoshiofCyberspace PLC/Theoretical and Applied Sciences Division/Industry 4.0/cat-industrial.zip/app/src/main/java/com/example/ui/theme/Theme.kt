package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CatDarkColorScheme = darkColorScheme(
    primary = CatYellow,
    onPrimary = CatBlack,
    primaryContainer = CatYellowContainer,
    onPrimaryContainer = OnCatYellowContainer,
    secondary = CatYellowDark,
    onSecondary = CatBlack,
    secondaryContainer = IndustrialDarkSurfaceVariant,
    onSecondaryContainer = TextPrimary,
    tertiary = StatusActiveGreen,
    onTertiary = Color.White,
    background = IndustrialDarkBackground,
    onBackground = TextPrimary,
    surface = IndustrialDarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = IndustrialDarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = IndustrialBorder,
    error = StatusCriticalRed,
    onError = Color.White
)

private val CatLightColorScheme = lightColorScheme(
    primary = CatYellowDark,
    onPrimary = CatBlack,
    primaryContainer = Color(0xFFFFF3CD),
    onPrimaryContainer = CatBlack,
    secondary = Color(0xFF33373E),
    onSecondary = Color.White,
    background = Color(0xFFF6F8FA),
    onBackground = CatBlack,
    surface = Color(0xFFFFFFFF),
    onSurface = CatBlack,
    surfaceVariant = Color(0xFFE9ECEF),
    onSurfaceVariant = Color(0xFF495057),
    outline = Color(0xFFCED4DA),
    error = StatusCriticalRed,
    onError = Color.White
)

@Composable
fun CatIndustrialTheme(
    darkTheme: Boolean = true, // Industrial machinery terminals default to high-visibility dark UI
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) CatDarkColorScheme else CatLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
