package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Equipment
import com.example.model.EquipmentCategory
import com.example.ui.components.MachineSpecsRow
import com.example.ui.components.OperationalStatusBadge
import com.example.ui.theme.CatYellow
import com.example.ui.theme.MonospaceTelemetryStyle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FleetScreen(
    equipmentList: List<Equipment>,
    selectedCategory: EquipmentCategory?,
    searchQuery: String,
    onCategorySelected: (EquipmentCategory?) -> Unit,
    onSearchChanged: (String) -> Unit,
    onSelectEquipment: (String) -> Unit,
    onNavigateToTelemetry: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expandedEquipmentId by remember { mutableStateOf<String?>(null) }

    val filteredList = remember(equipmentList, selectedCategory, searchQuery) {
        equipmentList.filter { eq ->
            val matchesCategory = selectedCategory == null || eq.category == selectedCategory
            val matchesSearch = searchQuery.isBlank() ||
                eq.model.contains(searchQuery, ignoreCase = true) ||
                eq.serialNumber.contains(searchQuery, ignoreCase = true) ||
                eq.operatingOrganisation.contains(searchQuery, ignoreCase = true) ||
                eq.assignedDealer.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Search & Filter row
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChanged,
            placeholder = { Text("Search machinery, serial, site or dealer...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CatYellow) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChanged("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear")
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .testTag("equipment_search_input"),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CatYellow,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
            ),
            singleLine = true
        )

        // Category Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedCategory == null,
                onClick = { onCategorySelected(null) },
                label = { Text("All Machinery (${equipmentList.size})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CatYellow,
                    selectedLabelColor = MaterialTheme.colorScheme.background
                ),
                modifier = Modifier.testTag("filter_all")
            )
            EquipmentCategory.values().forEach { cat ->
                val count = equipmentList.count { it.category == cat }
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { onCategorySelected(if (selectedCategory == cat) null else cat) },
                    label = { Text("${cat.displayName} ($count)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CatYellow,
                        selectedLabelColor = MaterialTheme.colorScheme.background
                    ),
                    modifier = Modifier.testTag("filter_${cat.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Fleet List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("fleet_list"),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(filteredList, key = { it.id }) { equipment ->
                val isExpanded = expandedEquipmentId == equipment.id

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("equipment_card_${equipment.id}")
                        .clickable {
                            expandedEquipmentId = if (isExpanded) null else equipment.id
                            onSelectEquipment(equipment.id)
                        },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = equipment.model,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "S/N: ${equipment.serialNumber} • ${equipment.productFamily}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            OperationalStatusBadge(status = equipment.status)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "ENGINE HOURS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "%.1f hrs".format(equipment.engineHours),
                                    style = MonospaceTelemetryStyle.copy(fontSize = 15.sp),
                                    color = CatYellow
                                )
                            }
                            Column {
                                Text(
                                    text = "CURRENT SITE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = equipment.location.siteName,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "NEXT PM DUE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "%.0f hrs".format(equipment.nextServiceDueHours),
                                    style = MonospaceTelemetryStyle.copy(fontSize = 14.sp),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        // Expandable Specs and Action Bar
                        AnimatedVisibility(visible = isExpanded) {
                            Column(
                                modifier = Modifier
                                    .padding(top = 14.dp)
                                    .fillMaxWidth()
                            ) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = "TECHNICAL SPECIFICATIONS",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = CatYellow
                                )

                                Spacer(modifier = Modifier.height(4.dp))
                                MachineSpecsRow("Engine Model", equipment.specifications.engineModel)
                                MachineSpecsRow("Net Flywheel Power", "${equipment.specifications.netPowerHp} HP")
                                MachineSpecsRow("Operating Weight", "%,.0f kg".format(equipment.specifications.operatingWeightKg))
                                MachineSpecsRow("Rated Capacity / Payload", equipment.specifications.ratedPayloadOrCapacity)
                                MachineSpecsRow("Hydraulic Max Pressure", "%.1f bar".format(equipment.specifications.hydraulicSystemMaxBar))
                                MachineSpecsRow("Fuel Tank Capacity", "%.0f L".format(equipment.specifications.fuelTankCapacityLiters))
                                MachineSpecsRow("Assigned Dealer", equipment.assignedDealer)
                                MachineSpecsRow("Operator / Client", equipment.operatingOrganisation)

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = {
                                        onSelectEquipment(equipment.id)
                                        onNavigateToTelemetry(equipment.id)
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("monitor_telemetry_btn_${equipment.id}"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CatYellow,
                                        contentColor = MaterialTheme.colorScheme.background
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.Sensors, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Open Real-time Telemetry & Ingest", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
