package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EquipmentRental
import com.example.model.RentalStatus
import com.example.ui.theme.*

@Composable
fun RentalsScreen(
    rentals: List<EquipmentRental>,
    onReturnRental: (String, Double, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var rentalToReturn by remember { mutableStateOf<EquipmentRental?>(null) }
    var returnMeterHours by remember { mutableStateOf("") }
    var inspectionNotes by remember { mutableStateOf("Passed return walkaround. Track pads 75% life remaining, fluid levels nominal.") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Equipment Rental & Asset Allocation",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Customer contracts • Meter verification • Check-in inspection",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("rentals_list"),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(rentals, key = { it.id }) { rental ->
                val (statusBg, statusText) = when (rental.status) {
                    RentalStatus.DISPATCHED -> Pair(StatusActiveGreen.copy(alpha = 0.2f), StatusActiveGreen)
                    RentalStatus.RESERVED -> Pair(Color(0xFF2196F3).copy(alpha = 0.2f), Color(0xFF64B5F6))
                    RentalStatus.INSPECTION_PENDING -> Pair(StatusWarningAmber.copy(alpha = 0.2f), StatusWarningAmber)
                    RentalStatus.RETURNED -> Pair(Color.Gray.copy(alpha = 0.2f), Color.LightGray)
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("rental_card_${rental.id}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = rental.equipmentModel,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Contract: ${rental.id} • ${rental.customerName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CatYellow
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(statusBg)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = rental.status.label.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = statusText,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Site: ${rental.jobSite}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("CONTRACT DATES", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${rental.startDate.take(10)} -> ${rental.estimatedEndDate.take(10)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                            }
                            Column {
                                Text("METER CONSUMPTION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                val consumed = (rental.currentMeterHours - rental.initialMeterHours).coerceAtLeast(0.0)
                                Text("%.1f hrs used".format(consumed), style = MonospaceTelemetryStyle.copy(fontSize = 13.sp), color = CatYellow)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("DAY RATE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("$%.0f / day".format(rental.dailyRateUsd), style = MonospaceTelemetryStyle.copy(fontSize = 13.sp), color = MaterialTheme.colorScheme.onSurface)
                            }
                        }

                        if (rental.returnConditionNotes != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Return Inspection: ${rental.returnConditionNotes}",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusActiveGreen
                            )
                        } else if (rental.status == RentalStatus.DISPATCHED) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    rentalToReturn = rental
                                    returnMeterHours = "%.1f".format(rental.currentMeterHours + 12.0)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("return_asset_btn_${rental.id}"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CatYellow,
                                    contentColor = MaterialTheme.colorScheme.background
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.AssignmentTurnedIn, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Check-In & Complete Return Inspection", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    if (rentalToReturn != null) {
        val rental = rentalToReturn!!
        AlertDialog(
            onDismissRequest = { rentalToReturn = null },
            title = { Text("Asset Return & Ingestion") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Machine: ${rental.equipmentModel} (${rental.equipmentId})", fontWeight = FontWeight.Bold, color = CatYellow)

                    OutlinedTextField(
                        value = returnMeterHours,
                        onValueChange = { returnMeterHours = it },
                        label = { Text("Final Odometer / Engine Hours") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = inspectionNotes,
                        onValueChange = { inspectionNotes = it },
                        label = { Text("Post-Rental Inspection Notes") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val hours = returnMeterHours.toDoubleOrNull() ?: rental.currentMeterHours
                        onReturnRental(rental.id, hours, inspectionNotes)
                        rentalToReturn = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CatYellow, contentColor = MaterialTheme.colorScheme.background)
                ) {
                    Text("Accept Asset Return", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { rentalToReturn = null }) { Text("Cancel") }
            }
        )
    }
}
