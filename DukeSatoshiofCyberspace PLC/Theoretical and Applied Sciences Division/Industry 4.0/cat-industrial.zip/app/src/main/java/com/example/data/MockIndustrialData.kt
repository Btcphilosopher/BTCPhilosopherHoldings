package com.example.data

import com.example.model.*

object MockIndustrialData {

    val initialEquipmentList = listOf(
        Equipment(
            id = "EQ-CAT-336-01",
            model = "Cat 336 Hydraulic Excavator",
            serialNumber = "CAT0336HDK98213",
            category = EquipmentCategory.EXCAVATOR,
            productFamily = "Medium Excavators",
            modelYear = 2024,
            owningOrganisation = "Atlas Heavy Infrastructure Ltd",
            operatingOrganisation = "Metro Rail Tunnel Project Joint Venture",
            assignedDealer = "Altorfer Cat - Central Region",
            status = OperationalStatus.OPERATING,
            engineHours = 3412.5,
            odometerKm = 8240.0,
            lastServiceDate = "2026-09-15",
            nextServiceDueHours = 3500.0,
            specifications = EquipmentSpecification(
                engineModel = "Cat C9.3B ACERT",
                netPowerHp = 314,
                operatingWeightKg = 37200.0,
                ratedPayloadOrCapacity = "2.27 m³ HD Bucket",
                fuelTankCapacityLiters = 600.0,
                hydraulicSystemMaxBar = 380.0,
                emissionStandard = "EPA Tier 4 Final / EU Stage V"
            ),
            location = EquipmentLocation(latitude = 41.8781, longitude = -87.6298, siteName = "Sector 4 Cut & Fill"),
            telemetryConnected = true
        ),
        Equipment(
            id = "EQ-CAT-745-02",
            model = "Cat 745 Articulated Truck",
            serialNumber = "CAT0745A004128",
            category = EquipmentCategory.ARTICULATED_TRUCK,
            productFamily = "Articulated Haulage",
            modelYear = 2023,
            owningOrganisation = "Apex Mining & Quarries Corp",
            operatingOrganisation = "Silver Creek Granite Quarry",
            assignedDealer = "Patten Cat - Midwest Hub",
            status = OperationalStatus.OPERATING,
            engineHours = 5120.8,
            odometerKm = 42100.0,
            lastServiceDate = "2026-08-20",
            nextServiceDueHours = 5250.0,
            specifications = EquipmentSpecification(
                engineModel = "Cat C18 ACERT",
                netPowerHp = 504,
                operatingWeightKg = 34500.0,
                ratedPayloadOrCapacity = "41.0 Tonnes (25.0 m³)",
                fuelTankCapacityLiters = 550.0,
                hydraulicSystemMaxBar = 240.0,
                emissionStandard = "EPA Tier 4 Final / EU Stage V"
            ),
            location = EquipmentLocation(latitude = 40.7128, longitude = -74.0060, siteName = "Haul Road North Ramp"),
            telemetryConnected = true
        ),
        Equipment(
            id = "EQ-CAT-D8T-03",
            model = "Cat D8T Track-Type Tractor",
            serialNumber = "CAT00D8TML55901",
            category = EquipmentCategory.DOZER,
            productFamily = "Track-Type Tractors",
            modelYear = 2023,
            owningOrganisation = "Great Lakes Earthworks Inc",
            operatingOrganisation = "Interstate 80 Expansion Corridor",
            assignedDealer = "Ziegler Cat - North Central",
            status = OperationalStatus.DERATED,
            engineHours = 4980.2,
            odometerKm = 12400.0,
            lastServiceDate = "2026-07-10",
            nextServiceDueHours = 5000.0,
            specifications = EquipmentSpecification(
                engineModel = "Cat C15 ACERT",
                netPowerHp = 354,
                operatingWeightKg = 39750.0,
                ratedPayloadOrCapacity = "8.7 m³ Semi-Universal Blade",
                fuelTankCapacityLiters = 625.0,
                hydraulicSystemMaxBar = 280.0,
                emissionStandard = "EPA Tier 4 Final / EU Stage V"
            ),
            location = EquipmentLocation(latitude = 41.5868, longitude = -93.6250, siteName = "Des Moines Cut Mile 14"),
            telemetryConnected = true
        ),
        Equipment(
            id = "EQ-CAT-988K-04",
            model = "Cat 988K Large Wheel Loader",
            serialNumber = "CAT0988KL00892",
            category = EquipmentCategory.WHEEL_LOADER,
            productFamily = "Wheel Loaders",
            modelYear = 2022,
            owningOrganisation = "Apex Mining & Quarries Corp",
            operatingOrganisation = "Eagle Point Limestone Facility",
            assignedDealer = "MacAllister Machinery",
            status = OperationalStatus.IDLE,
            engineHours = 7890.0,
            odometerKm = 36800.0,
            lastServiceDate = "2026-09-02",
            nextServiceDueHours = 8000.0,
            specifications = EquipmentSpecification(
                engineModel = "Cat C18 ACERT High Pressure Common Rail",
                netPowerHp = 588,
                operatingWeightKg = 51000.0,
                ratedPayloadOrCapacity = "7.6 m³ Rock Bucket (11.3 Tonnes)",
                fuelTankCapacityLiters = 712.0,
                hydraulicSystemMaxBar = 320.0,
                emissionStandard = "EPA Tier 4 Final"
            ),
            location = EquipmentLocation(latitude = 39.7684, longitude = -86.1581, siteName = "Primary Crusher Feed Hopper"),
            telemetryConnected = true
        ),
        Equipment(
            id = "EQ-CAT-797F-05",
            model = "Cat 797F Ultra-Class Mining Truck",
            serialNumber = "CAT0797FMN00188",
            category = EquipmentCategory.MINING_TRUCK,
            productFamily = "Mining Trucks",
            modelYear = 2021,
            owningOrganisation = "Rio Grande Mineral Resources",
            operatingOrganisation = "Highland Open Pit Copper Mine",
            assignedDealer = "Empire Southwest Cat",
            status = OperationalStatus.OPERATING,
            engineHours = 14320.4,
            odometerKm = 142000.0,
            lastServiceDate = "2026-09-28",
            nextServiceDueHours = 14500.0,
            specifications = EquipmentSpecification(
                engineModel = "Cat C175-20 Quad-Turbocharged",
                netPowerHp = 4000,
                operatingWeightKg = 623700.0,
                ratedPayloadOrCapacity = "363.0 Metric Tonnes (400 US Tons)",
                fuelTankCapacityLiters = 3785.0,
                hydraulicSystemMaxBar = 310.0,
                emissionStandard = "Tier 4 Final Optimized"
            ),
            location = EquipmentLocation(latitude = 32.2226, longitude = -110.9747, siteName = "Pit Bench 14 South"),
            telemetryConnected = true
        ),
        Equipment(
            id = "EQ-CAT-C32-06",
            model = "Cat C32 Industrial Power Generator",
            serialNumber = "CAT0C32GEN0047",
            category = EquipmentCategory.GENERATOR,
            productFamily = "Electric Power Generation",
            modelYear = 2023,
            owningOrganisation = "Atlas Heavy Infrastructure Ltd",
            operatingOrganisation = "Emergency Backup Substation Beta",
            assignedDealer = "Altorfer Cat - Power Systems",
            status = OperationalStatus.STANDBY,
            engineHours = 840.1,
            odometerKm = 0.0,
            lastServiceDate = "2026-08-11",
            nextServiceDueHours = 1000.0,
            specifications = EquipmentSpecification(
                engineModel = "Cat C32 TA 12-Cylinder 4-Stroke",
                netPowerHp = 1475,
                operatingWeightKg = 8900.0,
                ratedPayloadOrCapacity = "1000 kVA / 800 ekW Prime Power",
                fuelTankCapacityLiters = 1800.0,
                hydraulicSystemMaxBar = 0.0,
                emissionStandard = "EPA Stationary Emergency"
            ),
            location = EquipmentLocation(latitude = 41.8369, longitude = -87.6847, siteName = "Central Utility Vault B"),
            telemetryConnected = true
        )
    )

    val initialTelemetry = mapOf(
        "EQ-CAT-336-01" to TelemetryMeasurement(
            equipmentId = "EQ-CAT-336-01",
            timestamp = "2026-10-30T09:20:00Z",
            engineHours = 3412.5,
            engineRpm = 1780,
            coolantTempC = 88.5,
            oilPressureKpa = 390.0,
            fuelLevelPct = 74.2,
            fuelRateLph = 26.4,
            batteryVoltageV = 27.8,
            hydraulicPressureBar = 345.0,
            payloadTonnes = 3.2,
            operatingState = "Excavating / Heavy Duty Cycle"
        ),
        "EQ-CAT-745-02" to TelemetryMeasurement(
            equipmentId = "EQ-CAT-745-02",
            timestamp = "2026-10-30T09:20:00Z",
            engineHours = 5120.8,
            engineRpm = 1620,
            coolantTempC = 91.2,
            oilPressureKpa = 410.0,
            fuelLevelPct = 58.0,
            fuelRateLph = 38.6,
            batteryVoltageV = 27.6,
            hydraulicPressureBar = 210.0,
            payloadTonnes = 39.8,
            operatingState = "Loaded Haul / Incline 8%"
        ),
        "EQ-CAT-D8T-03" to TelemetryMeasurement(
            equipmentId = "EQ-CAT-D8T-03",
            timestamp = "2026-10-30T09:20:00Z",
            engineHours = 4980.2,
            engineRpm = 1450,
            coolantTempC = 101.4, // elevated
            oilPressureKpa = 270.0, // lower than normal
            fuelLevelPct = 34.1,
            fuelRateLph = 42.1,
            batteryVoltageV = 26.4,
            hydraulicPressureBar = 275.0,
            payloadTonnes = 0.0,
            operatingState = "Derated / High Engine Temperature"
        ),
        "EQ-CAT-988K-04" to TelemetryMeasurement(
            equipmentId = "EQ-CAT-988K-04",
            timestamp = "2026-10-30T09:20:00Z",
            engineHours = 7890.0,
            engineRpm = 750,
            coolantTempC = 78.0,
            oilPressureKpa = 320.0,
            fuelLevelPct = 82.5,
            fuelRateLph = 9.2,
            batteryVoltageV = 28.1,
            hydraulicPressureBar = 45.0,
            payloadTonnes = 0.0,
            operatingState = "Low Idle / Staged at Stockpile"
        ),
        "EQ-CAT-797F-05" to TelemetryMeasurement(
            equipmentId = "EQ-CAT-797F-05",
            timestamp = "2026-10-30T09:20:00Z",
            engineHours = 14320.4,
            engineRpm = 1750,
            coolantTempC = 93.8,
            oilPressureKpa = 460.0,
            fuelLevelPct = 48.0,
            fuelRateLph = 285.0,
            batteryVoltageV = 28.4,
            hydraulicPressureBar = 295.0,
            payloadTonnes = 361.4,
            operatingState = "Full Payload Haul Out of Pit"
        ),
        "EQ-CAT-C32-06" to TelemetryMeasurement(
            equipmentId = "EQ-CAT-C32-06",
            timestamp = "2026-10-30T09:20:00Z",
            engineHours = 840.1,
            engineRpm = 0,
            coolantTempC = 42.0,
            oilPressureKpa = 0.0,
            fuelLevelPct = 96.0,
            fuelRateLph = 0.0,
            batteryVoltageV = 27.9,
            hydraulicPressureBar = 0.0,
            payloadTonnes = 0.0,
            operatingState = "Ready / Standby Grid Power Online"
        )
    )

    val initialFaults = listOf(
        DiagnosticFault(
            id = "FLT-0912",
            equipmentId = "EQ-CAT-D8T-03",
            equipmentModel = "Cat D8T Track-Type Tractor",
            code = "MID 036 - CID 0110 - FMI 00",
            description = "Engine Coolant Temperature : Data Valid But Above Normal Operational Range (Derate 15%)",
            sourceSubsystem = "Powertrain / Engine ECM",
            severity = FaultSeverity.DERATE,
            status = FaultStatus.ACTIVE,
            timestamp = "2026-10-30T08:14:22Z",
            engineHoursAtFault = 4979.8,
            associatedWorkOrderId = "WO-2026-4401"
        ),
        DiagnosticFault(
            id = "FLT-0908",
            equipmentId = "EQ-CAT-745-02",
            equipmentModel = "Cat 745 Articulated Truck",
            code = "MID 082 - CID 0342 - FMI 03",
            description = "Secondary Fuel Pressure Sensor : Voltage Above Normal or Shorted High",
            sourceSubsystem = "Chassis & Fuel Management",
            severity = FaultSeverity.WARNING,
            status = FaultStatus.ACKNOWLEDGED,
            timestamp = "2026-10-29T16:40:11Z",
            engineHoursAtFault = 5116.3,
            acknowledgedBy = "Lead Tech M. Vance",
            acknowledgedAt = "2026-10-29T17:05:00Z"
        ),
        DiagnosticFault(
            id = "FLT-0899",
            equipmentId = "EQ-CAT-336-01",
            equipmentModel = "Cat 336 Hydraulic Excavator",
            code = "MID 036 - CID 0094 - FMI 01",
            description = "Fuel Delivery Pressure : Low Pressure Detected During High Load Acceleration",
            sourceSubsystem = "Engine Fuel System",
            severity = FaultSeverity.INFO,
            status = FaultStatus.RESOLVED,
            timestamp = "2026-10-26T11:20:00Z",
            engineHoursAtFault = 3388.0,
            acknowledgedBy = "Service Dispatcher R. King",
            acknowledgedAt = "2026-10-26T11:30:00Z",
            resolutionNotes = "Replaced primary fuel separator element (Cat Part 1R-0770). Fuel rail pressure restored to nominal 600 kPa.",
            resolvedAt = "2026-10-26T14:15:00Z",
            associatedWorkOrderId = "WO-2026-4389"
        )
    )

    val initialWorkOrders = listOf(
        WorkOrder(
            id = "WO-2026-4401",
            equipmentId = "EQ-CAT-D8T-03",
            equipmentModel = "Cat D8T Track-Type Tractor",
            title = "Cooling System Overhaul & Radiator Descaling",
            description = "Investigate high coolant temp fault MID 036-CID 0110. Inspect fan drive viscous clutch, coolant regulator thermostats, and clean core fins.",
            priority = MaintenancePriority.HIGH,
            status = WorkOrderStatus.IN_PROGRESS,
            assignedTechnician = "Marcus Henderson (Master Tech Cert #882)",
            scheduledDate = "2026-10-30",
            laborHoursEstimated = 6.0,
            laborHoursLogged = 2.5,
            partsConsumed = listOf("248-5513 Thermostat Regulator", "1R-1808 Oil Filter")
        ),
        WorkOrder(
            id = "WO-2026-4395",
            equipmentId = "EQ-CAT-745-02",
            equipmentModel = "Cat 745 Articulated Truck",
            title = "PM 500-Hour Scheduled Interval Service",
            description = "Complete 500-hour preventive maintenance: drain and refill crankcase oil, replace fuel filters, inspect brake accumulator nitrogen pre-charge, greasing.",
            priority = MaintenancePriority.MEDIUM,
            status = WorkOrderStatus.SCHEDULED,
            assignedTechnician = "Sarah Lindqvist (Patten Cat Field Service)",
            scheduledDate = "2026-11-02",
            laborHoursEstimated = 4.5,
            laborHoursLogged = 0.0,
            partsConsumed = emptyList()
        ),
        WorkOrder(
            id = "WO-2026-4389",
            equipmentId = "EQ-CAT-336-01",
            equipmentModel = "Cat 336 Hydraulic Excavator",
            title = "Fuel System Filtration & Pressure Sensor Calibration",
            description = "Fuel delivery low pressure correction. Replaced primary & secondary fuel filter canisters and verified low-pressure line integrity.",
            priority = MaintenancePriority.HIGH,
            status = WorkOrderStatus.COMPLETED,
            assignedTechnician = "Dave Miller (Certified Field Tech)",
            scheduledDate = "2026-10-26",
            laborHoursEstimated = 3.0,
            laborHoursLogged = 2.8,
            partsConsumed = listOf("1R-0770 Fuel Filter", "1R-0774 Advanced Efficiency Filter"),
            technicianSignOff = "D. Miller #1043",
            completedAt = "2026-10-26T14:15:00Z"
        )
    )

    val initialPartsCatalog = listOf(
        PartItem(
            partNumber = "1R-1808",
            name = "Cat Standard Efficiency Engine Oil Filter",
            category = "Filtration",
            unitPriceUsd = 38.50,
            compatibleModels = listOf("Cat 336", "Cat D8T", "Cat 745", "Cat 988K"),
            leadTimeDays = 1,
            totalAvailable = 84,
            stockByWarehouse = listOf(
                WarehouseStock("WH-PEORIA", "Peoria Global Distribution Hub", "Peoria, IL", 48, 4, 44),
                WarehouseStock("WH-DALLAS", "Dallas Logistics Depot", "Dallas, TX", 26, 2, 24),
                WarehouseStock("WH-ROTTERDAM", "Rotterdam European Parts DC", "Rotterdam, NL", 16, 0, 16)
            )
        ),
        PartItem(
            partNumber = "1R-0774",
            name = "Cat Advanced Efficiency Hydraulic Filter Element",
            category = "Hydraulics",
            unitPriceUsd = 72.00,
            compatibleModels = listOf("Cat 336", "Cat 745", "Cat 988K", "Cat 797F"),
            leadTimeDays = 1,
            totalAvailable = 42,
            stockByWarehouse = listOf(
                WarehouseStock("WH-PEORIA", "Peoria Global Distribution Hub", "Peoria, IL", 24, 2, 22),
                WarehouseStock("WH-DALLAS", "Dallas Logistics Depot", "Dallas, TX", 14, 1, 13),
                WarehouseStock("WH-ROTTERDAM", "Rotterdam European Parts DC", "Rotterdam, NL", 8, 1, 7)
            )
        ),
        PartItem(
            partNumber = "326-1644",
            name = "Cat Heavy-Duty Water Separator / Fuel Filter",
            category = "Filtration",
            unitPriceUsd = 54.20,
            compatibleModels = listOf("Cat 745", "Cat D8T", "Cat C32"),
            leadTimeDays = 2,
            totalAvailable = 35,
            stockByWarehouse = listOf(
                WarehouseStock("WH-PEORIA", "Peoria Global Distribution Hub", "Peoria, IL", 20, 0, 20),
                WarehouseStock("WH-DALLAS", "Dallas Logistics Depot", "Dallas, TX", 15, 0, 15)
            )
        ),
        PartItem(
            partNumber = "1U-3352",
            name = "Cat Advansys Heavy Penetration Bucket Tip (GET)",
            category = "Ground Engaging Tools",
            unitPriceUsd = 125.00,
            compatibleModels = listOf("Cat 336", "Cat 988K"),
            leadTimeDays = 3,
            totalAvailable = 60,
            stockByWarehouse = listOf(
                WarehouseStock("WH-PEORIA", "Peoria Global Distribution Hub", "Peoria, IL", 30, 5, 25),
                WarehouseStock("WH-DALLAS", "Dallas Logistics Depot", "Dallas, TX", 30, 0, 30)
            )
        ),
        PartItem(
            partNumber = "248-5513",
            name = "Cat Dual Thermostat Coolant Regulator Kit",
            category = "Powertrain / Cooling",
            unitPriceUsd = 195.50,
            compatibleModels = listOf("Cat D8T", "Cat C15", "Cat C18"),
            leadTimeDays = 1,
            totalAvailable = 18,
            stockByWarehouse = listOf(
                WarehouseStock("WH-PEORIA", "Peoria Global Distribution Hub", "Peoria, IL", 12, 1, 11),
                WarehouseStock("WH-DALLAS", "Dallas Logistics Depot", "Dallas, TX", 6, 0, 6)
            )
        )
    )

    val initialRentals = listOf(
        EquipmentRental(
            id = "RNT-2026-8801",
            equipmentId = "EQ-CAT-336-01",
            equipmentModel = "Cat 336 Hydraulic Excavator",
            customerName = "Midwest Ground Excavations Corp",
            jobSite = "South Loop Subway Extension (Station 3)",
            startDate = "2026-10-01",
            estimatedEndDate = "2026-11-30",
            initialMeterHours = 3280.0,
            currentMeterHours = 3412.5,
            dailyRateUsd = 1450.0,
            status = RentalStatus.DISPATCHED
        ),
        EquipmentRental(
            id = "RNT-2026-8802",
            equipmentId = "EQ-CAT-745-02",
            equipmentModel = "Cat 745 Articulated Truck",
            customerName = "Silver Creek Aggregates LLC",
            jobSite = "Bryn Mawr Quarry Bench 4",
            startDate = "2026-09-15",
            estimatedEndDate = "2026-12-15",
            initialMeterHours = 4920.0,
            currentMeterHours = 5120.8,
            dailyRateUsd = 1850.0,
            status = RentalStatus.DISPATCHED
        ),
        EquipmentRental(
            id = "RNT-2026-8803",
            equipmentId = "EQ-CAT-C32-06",
            equipmentModel = "Cat C32 Industrial Power Generator",
            customerName = "Commonwealth Hospital Network",
            jobSite = "Auxiliary Hospital Power Infrastructure",
            startDate = "2026-10-15",
            estimatedEndDate = "2026-11-15",
            initialMeterHours = 820.0,
            currentMeterHours = 840.1,
            dailyRateUsd = 1100.0,
            status = RentalStatus.RESERVED
        )
    )

    val apiEndpointsDocumentation = listOf(
        ApiEndpointInfo(
            path = "/api/v1/equipment",
            method = "GET",
            category = "Equipment Fleet",
            summary = "List industrial equipment records",
            description = "Retrieves paginated equipment records with organization-level scoping, filterable by model, category, dealer, and status.",
            responseSample = """{
  "items": [
    {
      "id": "EQ-CAT-336-01",
      "model": "Cat 336",
      "category": "EXCAVATOR",
      "serial_number": "CAT0336HDK98213",
      "engine_hours": 3412.5,
      "status": "OPERATING",
      "telemetry_connected": true
    }
  ],
  "total": 6,
  "page": 1,
  "size": 50
}"""
        ),
        ApiEndpointInfo(
            path = "/api/v1/telemetry/ingest",
            method = "POST",
            category = "Industrial Telemetry",
            summary = "Ingest industrial telemetry stream event",
            description = "Receives signed high-frequency CAN-bus/PL542 telemetry packets over HTTPS or internal MQTT adapter with idempotent deduplication and anomaly evaluation.",
            requestSample = """{
  "equipment_id": "EQ-CAT-336-01",
  "timestamp": "2026-10-30T09:25:00Z",
  "engine_hours": 3412.6,
  "engine_rpm": 1820,
  "coolant_temp_c": 89.2,
  "oil_pressure_kpa": 395.0,
  "fuel_level_pct": 73.8,
  "fuel_rate_lph": 27.1,
  "battery_voltage_v": 27.8,
  "hydraulic_pressure_bar": 348.0,
  "payload_tonnes": 3.4,
  "source_protocol": "MQTT"
}""",
            responseSample = """{
  "status": "INGESTED",
  "event_id": "evt-77182903",
  "anomaly_detected": false,
  "ingested_at": "2026-10-30T09:25:00.104Z"
}"""
        ),
        ApiEndpointInfo(
            path = "/api/v1/faults/{fault_id}/acknowledge",
            method = "POST",
            category = "Diagnostics",
            summary = "Acknowledge diagnostic trouble code",
            description = "Marks an active DTC as acknowledged by a certified technician or dispatcher, assigning responsibility and updating machine status.",
            requestSample = """{
  "acknowledged_by": "Lead Tech M. Vance",
  "comment": "Scheduled for site inspection"
}""",
            responseSample = """{
  "fault_id": "FLT-0912",
  "status": "ACKNOWLEDGED",
  "acknowledged_by": "Lead Tech M. Vance",
  "acknowledged_at": "2026-10-30T09:26:00Z"
}"""
        ),
        ApiEndpointInfo(
            path = "/api/v1/work-orders",
            method = "POST",
            category = "Maintenance",
            summary = "Create maintenance work order",
            description = "Generates a structured corrective or preventive maintenance work order tied to engine hour thresholds or active DTCs.",
            requestSample = """{
  "equipment_id": "EQ-CAT-D8T-03",
  "title": "Cooling System Service",
  "priority": "HIGH",
  "assigned_technician": "Marcus Henderson",
  "estimated_hours": 6.0
}""",
            responseSample = """{
  "work_order_id": "WO-2026-4402",
  "status": "SCHEDULED",
  "created_at": "2026-10-30T09:26:15Z"
}"""
        ),
        ApiEndpointInfo(
            path = "/api/v1/inventory/reservations",
            method = "POST",
            category = "Parts & Inventory",
            summary = "Reserve parts stock atomically",
            description = "Atomically allocates available genuine parts stock against a specific warehouse and work order to prevent overselling.",
            requestSample = """{
  "part_number": "1R-1808",
  "warehouse_id": "WH-PEORIA",
  "quantity": 2,
  "work_order_id": "WO-2026-4401"
}""",
            responseSample = """{
  "reservation_id": "RSV-99321",
  "part_number": "1R-1808",
  "warehouse_id": "WH-PEORIA",
  "allocated_quantity": 2,
  "remaining_available": 42,
  "status": "CONFIRMED"
}"""
        ),
        ApiEndpointInfo(
            path = "/api/v1/rentals/{rental_id}/return",
            method = "POST",
            category = "Asset Rentals",
            summary = "Check in and inspect returned asset",
            description = "Closes equipment rental period, records final engine hour meters, calculates billable overages and triggers return inspection.",
            requestSample = """{
  "final_meter_hours": 3415.0,
  "inspection_notes": "Undercarriage clean, no structural defects",
  "wear_status": "NORMAL"
}""",
            responseSample = """{
  "rental_id": "RNT-2026-8801",
  "status": "RETURNED",
  "billable_engine_hours": 135.0,
  "closed_at": "2026-10-30T09:27:00Z"
}"""
        )
    )
}
