package com.example.model

enum class WorkOrderStatus(val label: String) {
    SCHEDULED("Scheduled"),
    IN_PROGRESS("In Progress"),
    AWAITING_PARTS("Awaiting Parts"),
    COMPLETED("Completed"),
    CANCELLED("Cancelled")
}

enum class MaintenancePriority(val label: String) {
    LOW("Low Routine"),
    MEDIUM("Medium Planned"),
    HIGH("High Priority"),
    EMERGENCY("Critical Emergency")
}

data class MaintenanceSchedule(
    val id: String,
    val equipmentId: String,
    val intervalHours: Int, // 250, 500, 1000, 2000
    val serviceName: String,
    val nextDueHours: Double,
    val isOverdue: Boolean
)

data class WorkOrder(
    val id: String,
    val equipmentId: String,
    val equipmentModel: String,
    val title: String,
    val description: String,
    val priority: MaintenancePriority,
    val status: WorkOrderStatus,
    val assignedTechnician: String,
    val scheduledDate: String,
    val laborHoursEstimated: Double,
    val laborHoursLogged: Double = 0.0,
    val partsConsumed: List<String> = emptyList(),
    val technicianSignOff: String? = null,
    val completedAt: String? = null
)
