package com.example.model

enum class QualityFlag {
    GOOD,
    SUSPECT,
    DEGRADED,
    SIMULATED
}

data class TelemetryMeasurement(
    val equipmentId: String,
    val timestamp: String,
    val engineHours: Double,
    val engineRpm: Int,
    val coolantTempC: Double,
    val oilPressureKpa: Double,
    val fuelLevelPct: Double,
    val fuelRateLph: Double,
    val batteryVoltageV: Double,
    val hydraulicPressureBar: Double,
    val payloadTonnes: Double,
    val operatingState: String,
    val qualityFlag: QualityFlag = QualityFlag.SIMULATED,
    val sourceProtocol: String = "MQTT / PL542 Gateway"
)

data class TelemetrySummary(
    val equipmentId: String,
    val avgEngineRpm: Int,
    val maxCoolantTempC: Double,
    val avgFuelConsumptionLph: Double,
    val totalOperatingHours: Double,
    val activeFaultCount: Int
)
