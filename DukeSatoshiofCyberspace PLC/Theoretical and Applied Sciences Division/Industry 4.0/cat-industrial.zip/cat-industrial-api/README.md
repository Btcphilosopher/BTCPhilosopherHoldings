# Caterpillar Industrial Equipment API Platform

Enterprise Fleet, Machinery, Telematics, Parts, Maintenance & Dealer Integration Platform.

## Overview
A production-oriented enterprise API platform for Caterpillar industrial equipment operations, spanning:
- **Equipment Fleet Management**: Excavators (Cat 336, 349), Articulated Trucks (Cat 745), Dozers (Cat D8T), Wheel Loaders (Cat 988K), Mining Trucks (Cat 797F), and Industrial Power Generators (Cat C32).
- **Industrial Telemetry & IoT Ingest**: High-throughput CAN-bus (J1939) and PL542 gateway telemetry ingestion over MQTT and HTTPS with physical bounds validation, idempotent deduplication, and anomaly detection.
- **Diagnostic Trouble Codes (DTCs)**: Caterpillar MID/CID/FMI fault management, technician acknowledgement, derate alerts, and resolution audit trails.
- **Maintenance & Work Orders**: Preventive maintenance schedules (250h, 500h, 1000h intervals), technician dispatching, labor logging, and service sign-off.
- **Genuine Parts & Inventory**: Caterpillar parts catalog (1R-1808, 1R-0774, 326-1644, 1U-3352), dealer warehouse availability (Peoria DC, Dallas Hub, Rotterdam), and atomic stock reservation.
- **Asset Rentals & Allocation**: Job site assignments, meter verification, and return inspection checklists.
- **Field Companion Android App**: Production Jetpack Compose mobile terminal for field engineers, telematics monitoring, and API gateway inspection.

## Architecture & Technology Stack
- **Backend**: Python 3.12+, FastAPI, Pydantic v2, SQLAlchemy 2.x
- **Database & Messaging**: PostgreSQL 16 (partitioned time-series telemetry), Redis (caching & rate-limiting), Mosquitto MQTT v5
- **Mobile Client**: Android (Kotlin, Jetpack Compose, Material 3 Industrial Theme)
- **Deployment**: Docker Compose, Kubernetes manifests, OpenTelemetry & Prometheus

## Quickstart (Local Backend)
```bash
cd cat-industrial-api
pip install -e .
uvicorn src.cat_api.main:app --host 0.0.0.0 --port 8000 --reload
```
Interactive OpenAPI documentation will be accessible at `http://localhost:8000/docs`.

## Quickstart (Docker Compose)
```bash
docker compose -f compose.yaml up -d
```
