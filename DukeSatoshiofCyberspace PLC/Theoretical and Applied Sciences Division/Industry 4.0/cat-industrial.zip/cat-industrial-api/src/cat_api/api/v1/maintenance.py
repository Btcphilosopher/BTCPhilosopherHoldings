from datetime import datetime
from typing import List, Optional
import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from src.cat_api.schemas.maintenance import (
    WorkOrderCreate,
    WorkOrderUpdate,
    WorkOrderCompleteRequest,
    WorkOrderResponse
)
from src.cat_api.dependencies import SecurityContext, get_current_security_context

router = APIRouter(tags=["Maintenance & Work Orders"])

_WORK_ORDERS_STORE: dict[str, dict] = {
    "WO-2026-4401": {
        "id": "WO-2026-4401",
        "equipment_id": "EQ-CAT-336-01",
        "title": "Cooling System Service & Radiator Inspection",
        "description": "Inspect fan drive clutch and clean core fins per DTC FLT-0912.",
        "priority": "HIGH",
        "status": "IN_PROGRESS",
        "assigned_technician": "Marcus Henderson",
        "scheduled_date": "2026-10-30",
        "labor_hours_estimated": 6.0,
        "labor_hours_logged": 2.5,
        "parts_consumed": ["248-5513", "1R-1808"],
        "technician_sign_off": None,
        "completed_at": None
    }
}

@router.get("/work-orders", response_model=List[WorkOrderResponse])
async def list_work_orders(
    equipment_id: Optional[str] = None,
    status: Optional[str] = None,
    context: SecurityContext = Depends(get_current_security_context)
):
    orders = list(_WORK_ORDERS_STORE.values())
    if equipment_id:
        orders = [o for o in orders if o["equipment_id"] == equipment_id]
    if status:
        orders = [o for o in orders if o["status"].upper() == status.upper()]
    return [WorkOrderResponse(**o) for o in orders]

@router.post("/work-orders", response_model=WorkOrderResponse, status_code=status.HTTP_201_CREATED)
async def create_work_order(
    payload: WorkOrderCreate,
    context: SecurityContext = Depends(get_current_security_context)
):
    new_id = f"WO-2026-{uuid.uuid4().hex[:4].upper()}"
    record = payload.model_dump()
    record.update({
        "id": new_id,
        "status": "SCHEDULED",
        "labor_hours_logged": 0.0,
        "technician_sign_off": None,
        "completed_at": None
    })
    _WORK_ORDERS_STORE[new_id] = record
    return WorkOrderResponse(**record)

@router.post("/work-orders/{work_order_id}/complete", response_model=WorkOrderResponse)
async def complete_work_order(
    work_order_id: str,
    payload: WorkOrderCompleteRequest,
    context: SecurityContext = Depends(get_current_security_context)
):
    order = _WORK_ORDERS_STORE.get(work_order_id)
    if not order:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Work order not found.")

    order["status"] = "COMPLETED"
    order["technician_sign_off"] = payload.technician_sign_off
    order["completed_at"] = datetime.utcnow().isoformat()
    if payload.final_labor_hours is not None:
        order["labor_hours_logged"] = payload.final_labor_hours

    return WorkOrderResponse(**order)
