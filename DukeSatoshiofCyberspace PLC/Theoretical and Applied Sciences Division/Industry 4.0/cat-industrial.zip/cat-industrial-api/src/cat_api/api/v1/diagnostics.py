from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from src.cat_api.schemas.diagnostics import (
    DiagnosticFaultResponse,
    FaultAcknowledgeRequest,
    FaultResolveRequest
)
from src.cat_api.dependencies import SecurityContext, get_current_security_context

router = APIRouter(tags=["Diagnostics & Faults"])

_FAULTS_STORE: dict[str, dict] = {
    "FLT-0912": {
        "id": "FLT-0912",
        "equipment_id": "EQ-CAT-336-01",
        "fault_code": "MID 036 - CID 0110 - FMI 00",
        "description": "Engine Coolant Temperature High (Derate 15%)",
        "subsystem": "ENGINE",
        "severity": "DERATE",
        "status": "ACTIVE",
        "engine_hours_at_fault": 3410.2,
        "acknowledged_by": None,
        "acknowledged_at": None,
        "resolution_notes": None,
        "resolved_at": None,
        "work_order_id": None
    }
}

@router.get("/equipment/{equipment_id}/faults", response_model=List[DiagnosticFaultResponse])
async def list_equipment_faults(
    equipment_id: str,
    context: SecurityContext = Depends(get_current_security_context)
):
    return [
        DiagnosticFaultResponse(**f) for f in _FAULTS_STORE.values()
        if f["equipment_id"] == equipment_id
    ]

@router.post("/faults/{fault_id}/acknowledge", response_model=DiagnosticFaultResponse)
async def acknowledge_fault(
    fault_id: str,
    payload: FaultAcknowledgeRequest,
    context: SecurityContext = Depends(get_current_security_context)
):
    fault = _FAULTS_STORE.get(fault_id)
    if not fault:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Fault not found.")

    fault["status"] = "ACKNOWLEDGED"
    fault["acknowledged_by"] = payload.acknowledged_by
    fault["acknowledged_at"] = datetime.utcnow().isoformat()
    return DiagnosticFaultResponse(**fault)

@router.post("/faults/{fault_id}/resolve", response_model=DiagnosticFaultResponse)
async def resolve_fault(
    fault_id: str,
    payload: FaultResolveRequest,
    context: SecurityContext = Depends(get_current_security_context)
):
    fault = _FAULTS_STORE.get(fault_id)
    if not fault:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Fault not found.")

    fault["status"] = "RESOLVED"
    fault["resolution_notes"] = payload.resolution_notes
    fault["resolved_at"] = datetime.utcnow().isoformat()
    if payload.work_order_id:
        fault["work_order_id"] = payload.work_order_id
    return DiagnosticFaultResponse(**fault)
