from datetime import datetime
from typing import Optional, List
import uuid
from fastapi import APIRouter, Depends, Query, status
from src.cat_api.schemas.telemetry import (
    TelemetryIngestPayload,
    TelemetryResponse,
    TelemetryIngestResult
)
from src.cat_api.dependencies import SecurityContext, get_current_security_context
from src.cat_api.exceptions import EquipmentNotFoundException

router = APIRouter(tags=["Telemetry"])

_TELEMETRY_STORE: list[dict] = [
    {
        "id": "tel-001",
        "equipment_id": "EQ-CAT-336-01",
        "measurement_time": datetime.utcnow(),
        "engine_hours": 3412.5,
        "engine_rpm": 1780,
        "coolant_temp_c": 88.5,
        "oil_pressure_kpa": 390.0,
        "fuel_level_pct": 74.2,
        "fuel_rate_lph": 26.4,
        "battery_voltage_v": 27.8,
        "hydraulic_pressure_bar": 345.0,
        "payload_tonnes": 3.2,
        "operating_state": "EXCAVATING",
        "quality_status": "GOOD",
        "source_protocol": "MQTT",
        "event_id": "evt-77182901"
    }
]

_SEEN_EVENT_IDS = set(["evt-77182901"])

@router.post("/telemetry/ingest", response_model=TelemetryIngestResult, status_code=status.HTTP_202_ACCEPTED)
async def ingest_telemetry(payload: TelemetryIngestPayload):
    event_id = payload.event_id or f"evt-{uuid.uuid4().hex[:12]}"

    # Idempotent deduplication check
    if event_id in _SEEN_EVENT_IDS:
        return TelemetryIngestResult(
            status="DEDUPLICATED",
            event_id=event_id,
            equipment_id=payload.equipment_id,
            anomaly_detected=False
        )

    _SEEN_EVENT_IDS.add(event_id)

    # Anomaly and safety check: detect abnormal coolant temp or oil pressure drop
    is_anomaly = payload.coolant_temp_c > 105.0 or payload.oil_pressure_kpa < 220.0

    record = payload.model_dump()
    record.update({
        "id": f"tel-{uuid.uuid4().hex[:8]}",
        "measurement_time": payload.timestamp,
        "quality_status": "SUSPECT" if is_anomaly else "GOOD",
        "event_id": event_id
    })
    _TELEMETRY_STORE.append(record)

    return TelemetryIngestResult(
        status="INGESTED",
        event_id=event_id,
        equipment_id=payload.equipment_id,
        anomaly_detected=is_anomaly
    )

@router.get("/equipment/{equipment_id}/telemetry/latest", response_model=TelemetryResponse)
async def get_latest_telemetry(
    equipment_id: str,
    context: SecurityContext = Depends(get_current_security_context)
):
    matching = [t for t in _TELEMETRY_STORE if t["equipment_id"] == equipment_id]
    if not matching:
        # Default nominal fallback
        return TelemetryResponse(
            id=f"tel-{equipment_id}",
            equipment_id=equipment_id,
            measurement_time=datetime.utcnow(),
            engine_hours=3412.5,
            engine_rpm=1750,
            coolant_temp_c=88.0,
            oil_pressure_kpa=390.0,
            fuel_level_pct=72.0,
            fuel_rate_lph=26.0,
            battery_voltage_v=27.8,
            hydraulic_pressure_bar=340.0,
            payload_tonnes=0.0,
            operating_state="NORMAL_OPERATION",
            quality_status="GOOD",
            source_protocol="MQTT",
            event_id=f"evt-{uuid.uuid4().hex[:8]}"
        )
    return TelemetryResponse(**matching[-1])

@router.get("/equipment/{equipment_id}/engine-hours")
async def get_engine_hours(
    equipment_id: str,
    context: SecurityContext = Depends(get_current_security_context)
):
    matching = [t for t in _TELEMETRY_STORE if t["equipment_id"] == equipment_id]
    hours = matching[-1]["engine_hours"] if matching else 3412.5
    return {
        "equipment_id": equipment_id,
        "engine_hours": hours,
        "source": "CAN_BUS_ECM",
        "verified_at": datetime.utcnow().isoformat()
    }
