from datetime import datetime
from fastapi import APIRouter

router = APIRouter(tags=["Administration & Observability"])

@router.get("/health")
async def health_check():
    return {
        "status": "HEALTHY",
        "timestamp": datetime.utcnow().isoformat(),
        "services": {
            "database": "UP",
            "redis_broker": "UP",
            "mqtt_gateway": "CONNECTED"
        }
    }

@router.get("/readiness")
async def readiness_check():
    return {
        "status": "READY",
        "accepting_traffic": True
    }
