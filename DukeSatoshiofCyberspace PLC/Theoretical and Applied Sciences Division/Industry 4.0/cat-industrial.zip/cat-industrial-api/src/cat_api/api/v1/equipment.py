from typing import Optional, List
from fastapi import APIRouter, Depends, Query, status
from src.cat_api.schemas.equipment import EquipmentCreate, EquipmentUpdate, EquipmentResponse
from src.cat_api.schemas.common import PaginatedResponse, ApiSuccessResponse
from src.cat_api.dependencies import SecurityContext, get_current_security_context
from src.cat_api.exceptions import EquipmentNotFoundException

router = APIRouter(prefix="/equipment", tags=["Equipment"])

# In-memory backing store for demo/standalone evaluation
_EQUIPMENT_STORE: dict[str, dict] = {
    "EQ-CAT-336-01": {
        "id": "EQ-CAT-336-01",
        "serial_number": "CAT0336HDK98213",
        "manufacturer": "Caterpillar",
        "model": "Cat 336 Hydraulic Excavator",
        "category": "EXCAVATOR",
        "product_family": "Medium Excavators",
        "model_year": 2024,
        "owning_organisation_id": "ORG-CAT-ATLAS",
        "operating_organisation_id": "ORG-METRO-JV",
        "assigned_dealer_id": "DLR-ALTORFER",
        "operational_status": "OPERATING",
        "engine_hours": 3412.5,
        "odometer_km": 8240.0,
        "last_service_date": "2026-09-15",
        "next_maintenance_due_hours": 3500.0,
        "telemetry_connected": True,
        "is_archived": False,
        "specifications": {
            "engine_model": "Cat C9.3B ACERT",
            "net_power_hp": 314,
            "operating_weight_kg": 37200.0,
            "rated_payload": "2.27 m³ HD Bucket"
        },
        "last_latitude": 41.8781,
        "last_longitude": -87.6298,
        "current_site_name": "Sector 4 Cut & Fill"
    },
    "EQ-CAT-745-02": {
        "id": "EQ-CAT-745-02",
        "serial_number": "CAT0745A004128",
        "manufacturer": "Caterpillar",
        "model": "Cat 745 Articulated Truck",
        "category": "ARTICULATED_TRUCK",
        "product_family": "Articulated Haulage",
        "model_year": 2023,
        "owning_organisation_id": "ORG-CAT-ATLAS",
        "operating_organisation_id": "ORG-APEX-MINING",
        "assigned_dealer_id": "DLR-PATTEN",
        "operational_status": "OPERATING",
        "engine_hours": 5120.8,
        "odometer_km": 42100.0,
        "last_service_date": "2026-08-20",
        "next_maintenance_due_hours": 5250.0,
        "telemetry_connected": True,
        "is_archived": False,
        "specifications": {
            "engine_model": "Cat C18 ACERT",
            "net_power_hp": 504,
            "operating_weight_kg": 34500.0,
            "rated_payload": "41.0 Tonnes"
        },
        "last_latitude": 40.7128,
        "last_longitude": -74.0060,
        "current_site_name": "Haul Road North Ramp"
    }
}

@router.get("", response_model=PaginatedResponse[EquipmentResponse])
async def list_equipment(
    category: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    context: SecurityContext = Depends(get_current_security_context)
):
    items = list(_EQUIPMENT_STORE.values())
    # Tenant filter
    items = [eq for eq in items if eq["owning_organisation_id"] == context.organisation_id and not eq.get("is_archived", False)]
    if category:
        items = [eq for eq in items if eq["category"].upper() == category.upper()]
    if status:
        items = [eq for eq in items if eq["operational_status"].upper() == status.upper()]

    total = len(items)
    start = (page - 1) * size
    paged = items[start:start + size]

    return PaginatedResponse(
        items=[EquipmentResponse(**it) for it in paged],
        total=total,
        page=page,
        size=size,
        total_pages=(total + size - 1) // size if size > 0 else 1
    )

@router.get("/{equipment_id}", response_model=EquipmentResponse)
async def get_equipment(
    equipment_id: str,
    context: SecurityContext = Depends(get_current_security_context)
):
    record = _EQUIPMENT_STORE.get(equipment_id)
    if not record or record["owning_organisation_id"] != context.organisation_id:
        raise EquipmentNotFoundException(equipment_id)
    return EquipmentResponse(**record)

@router.post("", response_model=EquipmentResponse, status_code=status.HTTP_201_CREATED)
async def register_equipment(
    payload: EquipmentCreate,
    context: SecurityContext = Depends(get_current_security_context)
):
    eq_id = payload.id or f"EQ-CAT-{payload.serial_number[:6]}"
    record = payload.model_dump()
    record.update({
        "id": eq_id,
        "manufacturer": "Caterpillar",
        "engine_hours": 0.0,
        "odometer_km": 0.0,
        "last_service_date": None,
        "next_maintenance_due_hours": 250.0,
        "telemetry_connected": True,
        "is_archived": False,
        "owning_organisation_id": context.organisation_id
    })
    _EQUIPMENT_STORE[eq_id] = record
    return EquipmentResponse(**record)

@router.patch("/{equipment_id}", response_model=EquipmentResponse)
async def update_equipment(
    equipment_id: str,
    payload: EquipmentUpdate,
    context: SecurityContext = Depends(get_current_security_context)
):
    record = _EQUIPMENT_STORE.get(equipment_id)
    if not record or record["owning_organisation_id"] != context.organisation_id:
        raise EquipmentNotFoundException(equipment_id)

    update_data = payload.model_dump(exclude_unset=True)
    record.update(update_data)
    _EQUIPMENT_STORE[equipment_id] = record
    return EquipmentResponse(**record)

@router.delete("/{equipment_id}", response_model=ApiSuccessResponse)
async def archive_equipment(
    equipment_id: str,
    context: SecurityContext = Depends(get_current_security_context)
):
    record = _EQUIPMENT_STORE.get(equipment_id)
    if not record or record["owning_organisation_id"] != context.organisation_id:
        raise EquipmentNotFoundException(equipment_id)
    # Enforce retention/archival policy instead of permanent hard delete
    record["is_archived"] = True
    return ApiSuccessResponse(message=f"Equipment '{equipment_id}' safely archived under audit retention policy.")
