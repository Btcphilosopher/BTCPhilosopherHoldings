from typing import List
import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from src.cat_api.schemas.rentals import RentalCreate, RentalReturnRequest, RentalResponse
from src.cat_api.dependencies import SecurityContext, get_current_security_context
from src.cat_api.exceptions import RentalConflictException

router = APIRouter(prefix="/rentals", tags=["Asset Rentals & Allocation"])

_RENTALS_STORE: dict[str, dict] = {
    "RNT-2026-8801": {
        "id": "RNT-2026-8801",
        "equipment_id": "EQ-CAT-336-01",
        "customer_organisation_id": "ORG-METRO-JV",
        "job_site": "South Loop Subway Extension",
        "start_date": "2026-10-01",
        "end_date": "2026-11-30",
        "initial_meter_hours": 3280.0,
        "current_meter_hours": 3412.5,
        "daily_rate_usd": 1450.0,
        "status": "DISPATCHED",
        "return_condition_notes": None
    }
}

@router.get("", response_model=List[RentalResponse])
async def list_rentals(
    context: SecurityContext = Depends(get_current_security_context)
):
    return [RentalResponse(**r) for r in _RENTALS_STORE.values()]

@router.post("", response_model=RentalResponse, status_code=status.HTTP_201_CREATED)
async def create_rental(
    payload: RentalCreate,
    context: SecurityContext = Depends(get_current_security_context)
):
    # Check for active conflicting allocations
    for existing in _RENTALS_STORE.values():
        if existing["equipment_id"] == payload.equipment_id and existing["status"] in ["RESERVED", "DISPATCHED"]:
            raise RentalConflictException(payload.equipment_id)

    new_id = f"RNT-2026-{uuid.uuid4().hex[:4].upper()}"
    record = payload.model_dump()
    record.update({
        "id": new_id,
        "initial_meter_hours": 3412.5,
        "current_meter_hours": 3412.5,
        "status": "RESERVED",
        "return_condition_notes": None
    })
    _RENTALS_STORE[new_id] = record
    return RentalResponse(**record)

@router.post("/{rental_id}/return", response_model=RentalResponse)
async def return_rental(
    rental_id: str,
    payload: RentalReturnRequest,
    context: SecurityContext = Depends(get_current_security_context)
):
    rental = _RENTALS_STORE.get(rental_id)
    if not rental:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Rental record not found.")

    rental["status"] = "RETURNED"
    rental["current_meter_hours"] = payload.final_meter_hours
    rental["return_condition_notes"] = payload.inspection_notes
    return RentalResponse(**rental)
