from typing import List, Dict, Any
from fastapi import APIRouter, Depends
from src.cat_api.dependencies import SecurityContext, get_current_security_context

router = APIRouter(prefix="/fleets", tags=["Fleet Management"])

_FLEETS_STORE = [
    {
        "id": "FLT-METRO-01",
        "name": "Metro Rail Excavation Fleet",
        "organisation_id": "ORG-CAT-ATLAS",
        "equipment_ids": ["EQ-CAT-336-01", "EQ-CAT-745-02"],
        "active_units": 2,
        "total_units": 2,
        "average_engine_hours": 4266.6,
        "fleet_utilisation_pct": 87.5
    }
]

@router.get("")
async def list_fleets(
    context: SecurityContext = Depends(get_current_security_context)
) -> List[Dict[str, Any]]:
    return [f for f in _FLEETS_STORE if f["organisation_id"] == context.organisation_id]

@router.get("/{fleet_id}/utilisation")
async def get_fleet_utilisation(
    fleet_id: str,
    context: SecurityContext = Depends(get_current_security_context)
) -> Dict[str, Any]:
    return {
        "fleet_id": fleet_id,
        "window_days": 30,
        "utilisation_rate_pct": 87.5,
        "total_operating_hours": 580.4,
        "total_idle_hours": 82.6,
        "fuel_efficiency_index": "94.2% optimal",
        "computed_at": "2026-10-30T09:30:00Z"
    }

@router.get("/{fleet_id}/availability")
async def get_fleet_availability(
    fleet_id: str,
    context: SecurityContext = Depends(get_current_security_context)
) -> Dict[str, Any]:
    return {
        "fleet_id": fleet_id,
        "ready_for_dispatch": 2,
        "in_maintenance": 0,
        "derated": 0,
        "mechanical_availability_pct": 100.0
    }
