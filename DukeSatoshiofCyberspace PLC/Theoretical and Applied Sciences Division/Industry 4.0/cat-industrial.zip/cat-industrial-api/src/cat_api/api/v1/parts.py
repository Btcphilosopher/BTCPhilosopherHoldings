from typing import List, Optional
import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from src.cat_api.schemas.parts import (
    PartResponse,
    PartAvailabilityResponse,
    WarehouseStockResponse,
    InventoryReservationRequest,
    InventoryReservationResponse
)
from src.cat_api.dependencies import SecurityContext, get_current_security_context
from src.cat_api.exceptions import InsufficientInventoryException

router = APIRouter(tags=["Parts & Inventory"])

_PARTS_STORE = {
    "1R-1808": {
        "part_number": "1R-1808",
        "name": "Cat Standard Efficiency Engine Oil Filter",
        "category": "Filtration",
        "unit_price_usd": 38.50,
        "compatible_models": ["Cat 336", "Cat D8T", "Cat 745"],
        "lead_time_days": 1,
        "warehouses": {
            "WH-PEORIA": {"name": "Peoria Global DC", "city": "Peoria, IL", "on_hand": 48, "reserved": 4},
            "WH-DALLAS": {"name": "Dallas Logistics Hub", "city": "Dallas, TX", "on_hand": 26, "reserved": 2}
        }
    },
    "1R-0774": {
        "part_number": "1R-0774",
        "name": "Cat Advanced Efficiency Hydraulic Filter",
        "category": "Hydraulics",
        "unit_price_usd": 72.00,
        "compatible_models": ["Cat 336", "Cat 745", "Cat 988K"],
        "lead_time_days": 1,
        "warehouses": {
            "WH-PEORIA": {"name": "Peoria Global DC", "city": "Peoria, IL", "on_hand": 24, "reserved": 2}
        }
    }
}

@router.get("/parts", response_model=List[PartResponse])
async def list_parts(
    context: SecurityContext = Depends(get_current_security_context)
):
    return [
        PartResponse(
            part_number=p["part_number"],
            name=p["name"],
            category=p["category"],
            unit_price_usd=p["unit_price_usd"],
            compatible_models=p["compatible_models"],
            lead_time_days=p["lead_time_days"]
        ) for p in _PARTS_STORE.values()
    ]

@router.get("/parts/{part_id}/availability", response_model=PartAvailabilityResponse)
async def get_part_availability(
    part_id: str,
    context: SecurityContext = Depends(get_current_security_context)
):
    part = _PARTS_STORE.get(part_id)
    if not part:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Part '{part_id}' not found.")

    warehouse_responses = []
    total_avail = 0
    for wh_id, wh in part["warehouses"].items():
        avail = max(0, wh["on_hand"] - wh["reserved"])
        total_avail += avail
        warehouse_responses.append(
            WarehouseStockResponse(
                warehouse_id=wh_id,
                warehouse_name=wh["name"],
                city=wh["city"],
                quantity_on_hand=wh["on_hand"],
                quantity_reserved=wh["reserved"],
                quantity_available=avail
            )
        )

    return PartAvailabilityResponse(
        part_number=part["part_number"],
        name=part["name"],
        category=part["category"],
        unit_price_usd=part["unit_price_usd"],
        compatible_models=part["compatible_models"],
        lead_time_days=part["lead_time_days"],
        total_available=total_avail,
        stock_by_warehouse=warehouse_responses
    )

@router.post("/inventory/reservations", response_model=InventoryReservationResponse, status_code=status.HTTP_201_CREATED)
async def reserve_inventory(
    payload: InventoryReservationRequest,
    context: SecurityContext = Depends(get_current_security_context)
):
    part = _PARTS_STORE.get(payload.part_number)
    if not part:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Part not found.")

    wh = part["warehouses"].get(payload.warehouse_id)
    if not wh:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Warehouse not found.")

    available = max(0, wh["on_hand"] - wh["reserved"])
    if available < payload.quantity:
        raise InsufficientInventoryException(payload.part_number, payload.quantity, available)

    # Atomic allocation
    wh["reserved"] += payload.quantity
    new_available = max(0, wh["on_hand"] - wh["reserved"])

    return InventoryReservationResponse(
        reservation_id=f"RSV-{uuid.uuid4().hex[:6].upper()}",
        part_number=payload.part_number,
        warehouse_id=payload.warehouse_id,
        allocated_quantity=payload.quantity,
        remaining_available=new_available,
        status="CONFIRMED"
    )
