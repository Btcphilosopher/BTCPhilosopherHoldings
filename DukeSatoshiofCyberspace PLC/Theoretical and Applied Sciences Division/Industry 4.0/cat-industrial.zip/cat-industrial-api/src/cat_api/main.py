import time
import uuid
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from src.cat_api.config import settings
from src.cat_api.api.v1.equipment import router as equipment_router
from src.cat_api.api.v1.telemetry import router as telemetry_router
from src.cat_api.api.v1.diagnostics import router as diagnostics_router
from src.cat_api.api.v1.maintenance import router as maintenance_router
from src.cat_api.api.v1.parts import router as parts_router
from src.cat_api.api.v1.rentals import router as rentals_router
from src.cat_api.api.v1.fleets import router as fleets_router
from src.cat_api.api.v1.administration import router as admin_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup sequence: initialize connection pools and telemetry adapters
    yield
    # Shutdown sequence

app = FastAPI(
    title="Caterpillar Industrial Equipment API Platform",
    description="Unified enterprise API platform for Caterpillar heavy industrial machinery, telematics ingestion, diagnostic trouble codes, preventive maintenance, genuine parts inventory, and equipment rental operations.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/api/v1/openapi.json",
    lifespan=lifespan
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request Correlation ID & Performance Middleware
@app.middleware("http")
async def add_correlation_and_timing_headers(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID") or f"req-{uuid.uuid4().hex[:12]}"
    start_time = time.time()

    response = await call_next(request)

    process_time = (time.time() - start_time) * 1000.0
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Process-Time-Ms"] = f"{process_time:.2f}"
    return response

# Standardized Error Handling
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    request_id = request.headers.get("X-Request-ID", "unknown")
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": "INTERNAL_SERVER_ERROR",
                "message": "An unexpected error occurred while processing the industrial operations request.",
                "request_id": request_id
            }
        }
    )

# Register API v1 Routers
app.include_router(equipment_router, prefix=settings.API_V1_STR)
app.include_router(telemetry_router, prefix=settings.API_V1_STR)
app.include_router(diagnostics_router, prefix=settings.API_V1_STR)
app.include_router(maintenance_router, prefix=settings.API_V1_STR)
app.include_router(parts_router, prefix=settings.API_V1_STR)
app.include_router(rentals_router, prefix=settings.API_V1_STR)
app.include_router(fleets_router, prefix=settings.API_V1_STR)
app.include_router(admin_router, prefix=settings.API_V1_STR)

@app.get("/")
async def root():
    return {
        "platform": "Caterpillar Industrial Equipment API Platform",
        "version": "1.0.0",
        "documentation": "/docs",
        "redoc": "/redoc",
        "api_v1": settings.API_V1_STR,
        "status": "OPERATIONAL"
    }
