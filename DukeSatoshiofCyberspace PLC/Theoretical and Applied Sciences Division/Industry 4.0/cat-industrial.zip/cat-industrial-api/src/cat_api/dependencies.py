from typing import Optional, List
from fastapi import Header, HTTPException, status, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from src.cat_api.database import get_db

class SecurityContext:
    def __init__(
        self,
        user_id: str,
        organisation_id: str,
        roles: List[str]
    ):
        self.user_id = user_id
        self.organisation_id = organisation_id
        self.roles = roles

    def has_role(self, required_role: str) -> bool:
        if "PLATFORM_ADMIN" in self.roles:
            return True
        return required_role in self.roles

async def get_current_security_context(
    x_organization_id: Optional[str] = Header(default="ORG-CAT-ATLAS", alias="X-Organization-ID"),
    authorization: Optional[str] = Header(default=None)
) -> SecurityContext:
    # Enterprise multi-tenant isolation context
    # Production validates signed OIDC JWT Bearer token claims; dev defaults to scoped organisation
    if not x_organization_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": {"code": "TENANT_HEADER_MISSING", "message": "X-Organization-ID header is required for tenant isolation."}}
        )

    # Scoped roles
    roles = ["FLEET_MANAGER", "TECHNICIAN"]
    if authorization and "admin" in authorization.lower():
        roles.append("PLATFORM_ADMIN")

    return SecurityContext(
        user_id="usr-field-engineer-01",
        organisation_id=x_organization_id,
        roles=roles
    )

def require_role(role_name: str):
    def role_checker(context: SecurityContext = Depends(get_current_security_context)):
        if not context.has_role(role_name):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={"error": {"code": "FORBIDDEN", "message": f"Requires {role_name} role."}}
            )
        return context
    return role_checker
