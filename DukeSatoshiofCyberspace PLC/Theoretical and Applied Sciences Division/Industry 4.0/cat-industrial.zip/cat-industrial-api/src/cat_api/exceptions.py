from typing import Any, Dict, Optional
from fastapi import HTTPException, status

class CatApiException(HTTPException):
    def __init__(
        self,
        code: str,
        message: str,
        status_code: int = status.HTTP_400_BAD_REQUEST,
        details: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None
    ):
        self.code = code
        self.message = message
        self.details = details or {}
        self.request_id = request_id
        super().__init__(
            status_code=status_code,
            detail={
                "error": {
                    "code": code,
                    "message": message,
                    "details": self.details,
                    "request_id": self.request_id
                }
            }
        )

class EquipmentNotFoundException(CatApiException):
    def __init__(self, equipment_id: str, request_id: Optional[str] = None):
        super().__init__(
            code="EQUIPMENT_NOT_FOUND",
            message=f"The requested equipment record '{equipment_id}' was not found.",
            status_code=status.HTTP_404_NOT_FOUND,
            request_id=request_id
        )

class InsufficientInventoryException(CatApiException):
    def __init__(self, part_number: str, requested: int, available: int, request_id: Optional[str] = None):
        super().__init__(
            code="INSUFFICIENT_INVENTORY",
            message=f"Requested {requested} units for part '{part_number}', but only {available} units are available.",
            status_code=status.HTTP_409_CONFLICT,
            details={"part_number": part_number, "requested": requested, "available": available},
            request_id=request_id
        )

class RentalConflictException(CatApiException):
    def __init__(self, equipment_id: str, request_id: Optional[str] = None):
        super().__init__(
            code="RENTAL_CONFLICT",
            message=f"Equipment '{equipment_id}' already has an active overlapping allocation or reservation.",
            status_code=status.HTTP_409_CONFLICT,
            request_id=request_id
        )
