from sqlalchemy import String, Float, Integer, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column
from src.cat_api.database import Base
from src.cat_api.models.base import TimestampMixin

class Part(Base, TimestampMixin):
    __tablename__ = "parts"

    part_number: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    category: Mapped[str] = mapped_column(String(128), nullable=False)
    unit_price_usd: Mapped[float] = mapped_column(Float, nullable=False)
    compatible_models: Mapped[list] = mapped_column(JSON, default=list)
    lead_time_days: Mapped[int] = mapped_column(Integer, default=1)

class Warehouse(Base, TimestampMixin):
    __tablename__ = "warehouses"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    city: Mapped[str] = mapped_column(String(128), nullable=False)
    region: Mapped[str] = mapped_column(String(64), nullable=False)

class InventoryBalance(Base, TimestampMixin):
    __tablename__ = "inventory_balances"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    part_number: Mapped[str] = mapped_column(String(64), ForeignKey("parts.part_number"), nullable=False, index=True)
    warehouse_id: Mapped[str] = mapped_column(String(64), ForeignKey("warehouses.id"), nullable=False, index=True)
    quantity_on_hand: Mapped[int] = mapped_column(Integer, default=0)
    quantity_reserved: Mapped[int] = mapped_column(Integer, default=0)

    @property
    def quantity_available(self) -> int:
        return max(0, self.quantity_on_hand - self.quantity_reserved)

class InventoryReservation(Base, TimestampMixin):
    __tablename__ = "inventory_reservations"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    part_number: Mapped[str] = mapped_column(String(64), ForeignKey("parts.part_number"), nullable=False)
    warehouse_id: Mapped[str] = mapped_column(String(64), ForeignKey("warehouses.id"), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    work_order_id: Mapped[str] = mapped_column(String(64), nullable=False)
    status: Mapped[str] = mapped_column(String(32), default="CONFIRMED") # CONFIRMED, CONSUMED, RELEASED
