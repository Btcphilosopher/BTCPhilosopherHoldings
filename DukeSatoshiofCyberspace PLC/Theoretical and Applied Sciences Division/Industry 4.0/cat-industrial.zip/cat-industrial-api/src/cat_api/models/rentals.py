from typing import Optional
from sqlalchemy import String, Float, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from src.cat_api.database import Base
from src.cat_api.models.base import TimestampMixin

class Rental(Base, TimestampMixin):
    __tablename__ = "rentals"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    equipment_id: Mapped[str] = mapped_column(String(64), ForeignKey("equipment.id"), nullable=False, index=True)
    customer_organisation_id: Mapped[str] = mapped_column(String(64), ForeignKey("organisations.id"), nullable=False)
    job_site: Mapped[str] = mapped_column(String(255), nullable=False)
    start_date: Mapped[str] = mapped_column(String(32), nullable=False)
    end_date: Mapped[str] = mapped_column(String(32), nullable=False)

    initial_meter_hours: Mapped[float] = mapped_column(Float, nullable=False)
    current_meter_hours: Mapped[float] = mapped_column(Float, nullable=False)
    daily_rate_usd: Mapped[float] = mapped_column(Float, nullable=False)
    status: Mapped[str] = mapped_column(String(32), default="RESERVED") # RESERVED, DISPATCHED, INSPECTION_PENDING, RETURNED
    return_condition_notes: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)
