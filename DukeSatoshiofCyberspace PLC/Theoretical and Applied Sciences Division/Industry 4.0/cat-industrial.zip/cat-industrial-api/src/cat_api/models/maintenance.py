from typing import Optional
from sqlalchemy import String, Float, Integer, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column
from src.cat_api.database import Base
from src.cat_api.models.base import TimestampMixin

class MaintenanceSchedule(Base, TimestampMixin):
    __tablename__ = "maintenance_schedules"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    equipment_id: Mapped[str] = mapped_column(String(64), ForeignKey("equipment.id"), nullable=False, index=True)
    service_title: Mapped[str] = mapped_column(String(255), nullable=False)
    interval_hours: Mapped[int] = mapped_column(Integer, nullable=False) # 250, 500, 1000, 2000
    next_due_hours: Mapped[float] = mapped_column(Float, nullable=False)
    is_active: Mapped[bool] = mapped_column(default=True)

class WorkOrder(Base, TimestampMixin):
    __tablename__ = "work_orders"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    equipment_id: Mapped[str] = mapped_column(String(64), ForeignKey("equipment.id"), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(String(1024), nullable=False)
    priority: Mapped[str] = mapped_column(String(32), default="MEDIUM") # LOW, MEDIUM, HIGH, EMERGENCY
    status: Mapped[str] = mapped_column(String(32), default="SCHEDULED") # SCHEDULED, IN_PROGRESS, AWAITING_PARTS, COMPLETED, CANCELLED

    assigned_technician: Mapped[str] = mapped_column(String(128), nullable=False)
    scheduled_date: Mapped[str] = mapped_column(String(32), nullable=False)
    labor_hours_estimated: Mapped[float] = mapped_column(Float, default=4.0)
    labor_hours_logged: Mapped[float] = mapped_column(Float, default=0.0)

    parts_consumed: Mapped[list] = mapped_column(JSON, default=list)
    technician_sign_off: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    completed_at: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
