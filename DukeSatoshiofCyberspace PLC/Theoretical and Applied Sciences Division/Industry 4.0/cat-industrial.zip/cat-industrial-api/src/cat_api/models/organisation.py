from sqlalchemy import String, Boolean, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from src.cat_api.database import Base
from src.cat_api.models.base import TimestampMixin

class Organisation(Base, TimestampMixin):
    __tablename__ = "organisations"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    org_type: Mapped[str] = mapped_column(String(64), default="CUSTOMER") # CUSTOMER, DEALER, CATERPILLAR_INTERNAL
    tax_id: Mapped[str] = mapped_column(String(64), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    users: Mapped[list["User"]] = relationship("User", back_populates="organisation")

class User(Base, TimestampMixin):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    organisation_id: Mapped[str] = mapped_column(String(64), ForeignKey("organisations.id"), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(64), default="FLEET_MANAGER") # PLATFORM_ADMIN, FLEET_MANAGER, TECHNICIAN, DEALER_MANAGER, READ_ONLY
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    organisation: Mapped["Organisation"] = relationship("Organisation", back_populates="users")

class Dealer(Base, TimestampMixin):
    __tablename__ = "dealers"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    dealer_code: Mapped[str] = mapped_column(String(32), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    region: Mapped[str] = mapped_column(String(128), nullable=False)
    service_capabilities: Mapped[str] = mapped_column(String(512), default="FULL_SERVICE,FIELD_TECH,PARTS_DEPOT")
    contact_phone: Mapped[str] = mapped_column(String(64), nullable=True)
