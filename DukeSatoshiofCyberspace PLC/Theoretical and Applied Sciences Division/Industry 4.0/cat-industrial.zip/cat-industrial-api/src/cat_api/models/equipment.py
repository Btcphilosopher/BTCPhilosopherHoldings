from typing import Optional
from sqlalchemy import String, Float, Integer, Boolean, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from src.cat_api.database import Base
from src.cat_api.models.base import TimestampMixin

class Equipment(Base, TimestampMixin):
    __tablename__ = "equipment"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    serial_number: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    manufacturer: Mapped[str] = mapped_column(String(64), default="Caterpillar")
    model: Mapped[str] = mapped_column(String(128), index=True, nullable=False)
    category: Mapped[str] = mapped_column(String(64), index=True, nullable=False) # EXCAVATOR, ARTICULATED_TRUCK, DOZER, WHEEL_LOADER, MINING_TRUCK, GENERATOR
    product_family: Mapped[str] = mapped_column(String(128), nullable=False)
    model_year: Mapped[int] = mapped_column(Integer, nullable=True)

    owning_organisation_id: Mapped[str] = mapped_column(String(64), ForeignKey("organisations.id"), nullable=False, index=True)
    operating_organisation_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    assigned_dealer_id: Mapped[Optional[str]] = mapped_column(String(64), ForeignKey("dealers.id"), nullable=True)

    operational_status: Mapped[str] = mapped_column(String(64), default="OPERATING") # OPERATING, IDLE, STANDBY, MAINTENANCE_DUE, DERATED, CRITICAL_FAULT
    engine_hours: Mapped[float] = mapped_column(Float, default=0.0)
    odometer_km: Mapped[float] = mapped_column(Float, default=0.0)

    last_service_date: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    next_maintenance_due_hours: Mapped[float] = mapped_column(Float, default=250.0)
    telemetry_connected: Mapped[bool] = mapped_column(Boolean, default=True)

    # Technical Specifications
    specifications: Mapped[dict] = mapped_column(JSON, default=dict)
    # Geo Location
    last_latitude: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    last_longitude: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    current_site_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    # Soft delete / archival policy
    is_archived: Mapped[bool] = mapped_column(Boolean, default=False)

class Fleet(Base, TimestampMixin):
    __tablename__ = "fleets"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    organisation_id: Mapped[str] = mapped_column(String(64), ForeignKey("organisations.id"), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)

class FleetEquipment(Base, TimestampMixin):
    __tablename__ = "fleet_equipment"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    fleet_id: Mapped[str] = mapped_column(String(64), ForeignKey("fleets.id"), nullable=False, index=True)
    equipment_id: Mapped[str] = mapped_column(String(64), ForeignKey("equipment.id"), nullable=False, index=True)
