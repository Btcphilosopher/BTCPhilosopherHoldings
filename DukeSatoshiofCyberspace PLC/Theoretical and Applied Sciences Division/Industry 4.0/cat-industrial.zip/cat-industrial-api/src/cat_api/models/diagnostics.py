from typing import Optional
from sqlalchemy import String, Float, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from src.cat_api.database import Base
from src.cat_api.models.base import TimestampMixin

class DiagnosticFault(Base, TimestampMixin):
    __tablename__ = "diagnostic_faults"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    equipment_id: Mapped[str] = mapped_column(String(64), ForeignKey("equipment.id"), nullable=False, index=True)
    fault_code: Mapped[str] = mapped_column(String(64), nullable=False) # MID 036 - CID 0100 - FMI 01
    description: Mapped[str] = mapped_column(String(512), nullable=False)
    subsystem: Mapped[str] = mapped_column(String(128), default="ENGINE")
    severity: Mapped[str] = mapped_column(String(32), default="WARNING") # INFO, WARNING, DERATE, CRITICAL
    status: Mapped[str] = mapped_column(String(32), default="ACTIVE") # ACTIVE, ACKNOWLEDGED, RESOLVED

    engine_hours_at_fault: Mapped[float] = mapped_column(Float, default=0.0)
    acknowledged_by: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    acknowledged_at: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    resolution_notes: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)
    resolved_at: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    work_order_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
