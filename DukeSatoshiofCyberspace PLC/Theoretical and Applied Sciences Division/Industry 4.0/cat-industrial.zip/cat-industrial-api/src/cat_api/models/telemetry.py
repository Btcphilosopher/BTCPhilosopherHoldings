from datetime import datetime
from sqlalchemy import String, Float, Integer, DateTime, ForeignKey, Index
from sqlalchemy.orm import Mapped, mapped_column
from src.cat_api.database import Base
from src.cat_api.models.base import TimestampMixin

class TelemetryMeasurement(Base, TimestampMixin):
    __tablename__ = "telemetry_measurements"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    equipment_id: Mapped[str] = mapped_column(String(64), ForeignKey("equipment.id"), nullable=False, index=True)
    measurement_time: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)

    engine_hours: Mapped[float] = mapped_column(Float, nullable=False)
    engine_rpm: Mapped[int] = mapped_column(Integer, nullable=False)
    coolant_temp_c: Mapped[float] = mapped_column(Float, nullable=False)
    oil_pressure_kpa: Mapped[float] = mapped_column(Float, nullable=False)
    fuel_level_pct: Mapped[float] = mapped_column(Float, nullable=False)
    fuel_rate_lph: Mapped[float] = mapped_column(Float, nullable=False)
    battery_voltage_v: Mapped[float] = mapped_column(Float, nullable=False)
    hydraulic_pressure_bar: Mapped[float] = mapped_column(Float, default=0.0)
    payload_tonnes: Mapped[float] = mapped_column(Float, default=0.0)

    operating_state: Mapped[str] = mapped_column(String(128), default="NORMAL_OPERATION")
    quality_status: Mapped[str] = mapped_column(String(32), default="GOOD") # GOOD, SUSPECT, SIMULATED
    source_protocol: Mapped[str] = mapped_column(String(32), default="MQTT")
    event_id: Mapped[str] = mapped_column(String(64), unique=True, index=True)

    __table_args__ = (
        Index("ix_eq_measurement_time", "equipment_id", "measurement_time"),
    )
