from typing import Generic, List, TypeVar, Optional
from pydantic import BaseModel, ConfigDict

T = TypeVar("T")

class PaginatedResponse(BaseModel, Generic[T]):
    items: List[T]
    total: int
    page: int
    size: int
    total_pages: int

    model_config = ConfigDict(from_attributes=True)

class ApiSuccessResponse(BaseModel):
    status: str = "SUCCESS"
    message: str
    id: Optional[str] = None
