from typing import Optional
from pydantic import BaseModel, ConfigDict

class DiagnosticFaultCreate(BaseModel):
    equipment_id: str
    fault_code: str
    description: str
    subsystem: str = "ENGINE"
    severity: str = "WARNING"
    engine_hours_at_fault: float

class FaultAcknowledgeRequest(BaseModel):
    acknowledged_by: str
    comment: Optional[str] = None

class FaultResolveRequest(BaseModel):
    resolution_notes: str
    work_order_id: Optional[str] = None

class DiagnosticFaultResponse(BaseModel):
    id: str
    equipment_id: str
    fault_code: str
    description: str
    subsystem: str
    severity: str
    status: str
    engine_hours_at_fault: float
    acknowledged_by: Optional[str] = None
    acknowledged_at: Optional[str] = None
    resolution_notes: Optional[str] = None
    resolved_at: Optional[str] = None
    work_order_id: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)
