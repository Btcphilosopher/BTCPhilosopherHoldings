from typing import List
from pydantic import BaseModel, ConfigDict, Field

class WarehouseStockResponse(BaseModel):
    warehouse_id: str
    warehouse_name: str
    city: str
    quantity_on_hand: int
    quantity_reserved: int
    quantity_available: int

    model_config = ConfigDict(from_attributes=True)

class PartResponse(BaseModel):
    part_number: str
    name: str
    category: str
    unit_price_usd: float
    compatible_models: List[str]
    lead_time_days: int

    model_config = ConfigDict(from_attributes=True)

class PartAvailabilityResponse(PartResponse):
    total_available: int
    stock_by_warehouse: List[WarehouseStockResponse]

class InventoryReservationRequest(BaseModel):
    part_number: str
    warehouse_id: str
    quantity: int = Field(gt=0)
    work_order_id: str

class InventoryReservationResponse(BaseModel):
    reservation_id: str
    part_number: str
    warehouse_id: str
    allocated_quantity: int
    remaining_available: int
    status: str = "CONFIRMED"
