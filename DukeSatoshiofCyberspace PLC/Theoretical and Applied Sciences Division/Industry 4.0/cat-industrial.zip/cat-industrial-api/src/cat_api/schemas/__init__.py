from src.cat_api.schemas.common import PaginatedResponse, ApiSuccessResponse
from src.cat_api.schemas.equipment import EquipmentCreate, EquipmentUpdate, EquipmentResponse
from src.cat_api.schemas.telemetry import TelemetryIngestPayload, TelemetryResponse, TelemetryIngestResult
from src.cat_api.schemas.diagnostics import DiagnosticFaultCreate, FaultAcknowledgeRequest, FaultResolveRequest, DiagnosticFaultResponse
from src.cat_api.schemas.maintenance import WorkOrderCreate, WorkOrderUpdate, WorkOrderCompleteRequest, WorkOrderResponse
from src.cat_api.schemas.parts import PartResponse, PartAvailabilityResponse, InventoryReservationRequest, InventoryReservationResponse
from src.cat_api.schemas.rentals import RentalCreate, RentalReturnRequest, RentalResponse

__all__ = [
    "PaginatedResponse",
    "ApiSuccessResponse",
    "EquipmentCreate",
    "EquipmentUpdate",
    "EquipmentResponse",
    "TelemetryIngestPayload",
    "TelemetryResponse",
    "TelemetryIngestResult",
    "DiagnosticFaultCreate",
    "FaultAcknowledgeRequest",
    "FaultResolveRequest",
    "DiagnosticFaultResponse",
    "WorkOrderCreate",
    "WorkOrderUpdate",
    "WorkOrderCompleteRequest",
    "WorkOrderResponse",
    "PartResponse",
    "PartAvailabilityResponse",
    "InventoryReservationRequest",
    "InventoryReservationResponse",
    "RentalCreate",
    "RentalReturnRequest",
    "RentalResponse"
]
