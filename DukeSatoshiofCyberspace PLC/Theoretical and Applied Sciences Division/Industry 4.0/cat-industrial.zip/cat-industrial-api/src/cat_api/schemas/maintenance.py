from typing import Optional, List
from pydantic import BaseModel, ConfigDict

class WorkOrderCreate(BaseModel):
    equipment_id: str
    title: str
    description: str
    priority: str = "MEDIUM"
    assigned_technician: str
    scheduled_date: str
    labor_hours_estimated: float = 4.0
    parts_consumed: List[str] = []

class WorkOrderUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = None
    assigned_technician: Optional[str] = None
    labor_hours_logged: Optional[float] = None
    parts_consumed: Optional[List[str]] = None

class WorkOrderCompleteRequest(BaseModel):
    technician_sign_off: str
    final_labor_hours: Optional[float] = None
    completion_notes: Optional[str] = None

class WorkOrderResponse(BaseModel):
    id: str
    equipment_id: str
    title: str
    description: str
    priority: str
    status: str
    assigned_technician: str
    scheduled_date: str
    labor_hours_estimated: float
    labor_hours_logged: float
    parts_consumed: List[str]
    technician_sign_off: Optional[str] = None
    completed_at: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)
