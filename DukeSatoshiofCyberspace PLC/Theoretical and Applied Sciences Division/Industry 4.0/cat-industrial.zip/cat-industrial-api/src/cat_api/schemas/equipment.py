from typing import Optional, Dict, Any
from pydantic import BaseModel, ConfigDict, Field

class EquipmentBase(BaseModel):
    model: str
    serial_number: str
    category: str
    product_family: str
    model_year: Optional[int] = None
    owning_organisation_id: str
    operating_organisation_id: Optional[str] = None
    assigned_dealer_id: Optional[str] = None
    operational_status: str = "OPERATING"
    specifications: Dict[str, Any] = Field(default_factory=dict)
    last_latitude: Optional[float] = None
    last_longitude: Optional[float] = None
    current_site_name: Optional[str] = None

class EquipmentCreate(EquipmentBase):
    id: Optional[str] = None

class EquipmentUpdate(BaseModel):
    operational_status: Optional[str] = None
    engine_hours: Optional[float] = None
    odometer_km: Optional[float] = None
    operating_organisation_id: Optional[str] = None
    assigned_dealer_id: Optional[str] = None
    last_latitude: Optional[float] = None
    last_longitude: Optional[float] = None
    current_site_name: Optional[str] = None

class EquipmentResponse(EquipmentBase):
    id: str
    manufacturer: str
    engine_hours: float
    odometer_km: float
    last_service_date: Optional[str] = None
    next_maintenance_due_hours: float
    telemetry_connected: bool
    is_archived: bool

    model_config = ConfigDict(from_attributes=True)
