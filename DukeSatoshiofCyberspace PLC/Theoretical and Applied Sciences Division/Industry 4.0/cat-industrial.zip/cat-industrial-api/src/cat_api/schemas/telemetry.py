from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field

class TelemetryIngestPayload(BaseModel):
    equipment_id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    engine_hours: float = Field(ge=0.0)
    engine_rpm: int = Field(ge=0, le=4000)
    coolant_temp_c: float = Field(ge=-40.0, le=150.0)
    oil_pressure_kpa: float = Field(ge=0.0, le=1000.0)
    fuel_level_pct: float = Field(ge=0.0, le=100.0)
    fuel_rate_lph: float = Field(ge=0.0, le=1500.0)
    battery_voltage_v: float = Field(ge=0.0, le=40.0)
    hydraulic_pressure_bar: float = Field(default=0.0, ge=0.0, le=600.0)
    payload_tonnes: float = Field(default=0.0, ge=0.0)
    operating_state: str = "NORMAL_OPERATION"
    source_protocol: str = "MQTT"
    event_id: Optional[str] = None

class TelemetryResponse(BaseModel):
    id: str
    equipment_id: str
    measurement_time: datetime
    engine_hours: float
    engine_rpm: int
    coolant_temp_c: float
    oil_pressure_kpa: float
    fuel_level_pct: float
    fuel_rate_lph: float
    battery_voltage_v: float
    hydraulic_pressure_bar: float
    payload_tonnes: float
    operating_state: str
    quality_status: str
    source_protocol: str
    event_id: str

    model_config = ConfigDict(from_attributes=True)

class TelemetryIngestResult(BaseModel):
    status: str = "INGESTED"
    event_id: str
    equipment_id: str
    anomaly_detected: bool = False
    ingested_at: datetime = Field(default_factory=datetime.utcnow)
