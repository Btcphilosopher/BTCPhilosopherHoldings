from typing import Optional
from pydantic import BaseModel, ConfigDict, Field

class RentalCreate(BaseModel):
    equipment_id: str
    customer_organisation_id: str
    job_site: str
    start_date: str
    end_date: str
    daily_rate_usd: float = Field(gt=0.0)

class RentalReturnRequest(BaseModel):
    final_meter_hours: float
    inspection_notes: str

class RentalResponse(BaseModel):
    id: str
    equipment_id: str
    customer_organisation_id: str
    job_site: str
    start_date: str
    end_date: str
    initial_meter_hours: float
    current_meter_hours: float
    daily_rate_usd: float
    status: str
    return_condition_notes: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)
