import json
import logging
from typing import Callable, Optional

logger = logging.getLogger("cat_api.mqtt_adapter")

class MqttIndustrialAdapter:
    """
    Adapter for processing incoming MQTT packets from Caterpillar PL542 and
    industrial IoT gateways.
    """
    def __init__(self, broker_host: str = "localhost", broker_port: int = 1883):
        self.broker_host = broker_host
        self.broker_port = broker_port
        self.on_telemetry_received: Optional[Callable[[dict], None]] = None

    def process_incoming_message(self, topic: str, payload_bytes: bytes) -> Optional[dict]:
        try:
            payload_str = payload_bytes.decode("utf-8")
            data = json.loads(payload_str)
            logger.info("Processed MQTT message from topic %s for equipment %s", topic, data.get("equipment_id"))
            if self.on_telemetry_received:
                self.on_telemetry_received(data)
            return data
        except Exception as e:
            logger.error("Failed to parse MQTT message on topic %s: %s", topic, e)
            return None
