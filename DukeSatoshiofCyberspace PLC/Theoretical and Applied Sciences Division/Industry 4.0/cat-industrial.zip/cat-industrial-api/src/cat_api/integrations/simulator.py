"""
Caterpillar Equipment Telemetry Simulator
Generates clearly labelled synthetic/simulated industrial telemetry for evaluation, testing,
and development environments without accessing live customer proprietary machinery.
"""
from datetime import datetime
import random
import uuid
from typing import Dict, Any

class CaterpillarEquipmentSimulator:
    def __init__(self):
        self.supported_models = [
            "Cat 336 Hydraulic Excavator",
            "Cat 745 Articulated Truck",
            "Cat D8T Track-Type Tractor",
            "Cat 988K Large Wheel Loader",
            "Cat 797F Ultra-Class Mining Truck",
            "Cat C32 Industrial Power Generator"
        ]

    def generate_telemetry_event(self, equipment_id: str) -> Dict[str, Any]:
        """
        Generates realistic CAN-bus/PL542 sensor payload.
        Labelled explicitly with 'quality_flag': 'SIMULATED'.
        """
        return {
            "equipment_id": equipment_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "engine_hours": round(3412.5 + random.uniform(0.1, 5.0), 3),
            "engine_rpm": random.randint(1400, 1850),
            "coolant_temp_c": round(random.uniform(84.0, 92.5), 1),
            "oil_pressure_kpa": round(random.uniform(360.0, 420.0), 1),
            "fuel_level_pct": round(random.uniform(45.0, 85.0), 1),
            "fuel_rate_lph": round(random.uniform(22.0, 36.0), 1),
            "battery_voltage_v": round(random.uniform(27.4, 28.2), 1),
            "hydraulic_pressure_bar": round(random.uniform(310.0, 360.0), 1),
            "payload_tonnes": round(random.uniform(0.0, 4.0), 1),
            "operating_state": "ACTIVE_CYCLE",
            "source_protocol": "MQTT_SIMULATOR_V1",
            "quality_flag": "SIMULATED",
            "event_id": f"sim-evt-{uuid.uuid4().hex[:12]}"
        }
