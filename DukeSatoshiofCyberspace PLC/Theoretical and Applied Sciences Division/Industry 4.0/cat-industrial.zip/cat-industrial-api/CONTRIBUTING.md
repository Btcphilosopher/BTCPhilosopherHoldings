# Contributing to Caterpillar Industrial Equipment API Platform

## Code Conventions
- Target Python 3.12+.
- Strict typing with Pydantic v2 and SQLAlchemy 2.0 mapped columns.
- All endpoints must include OpenAPI descriptions, summary tags, and standard error handling.
- All equipment telemetry measurements must enforce valid physical bounds and units.

## Testing Requirements
- Unit tests: `pytest tests/`
- All schema validation and atomic inventory locking must pass integration testing before PR merges.
