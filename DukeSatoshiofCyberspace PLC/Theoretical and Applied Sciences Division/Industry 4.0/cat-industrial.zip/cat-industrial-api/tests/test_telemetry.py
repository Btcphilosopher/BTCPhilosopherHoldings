from fastapi.testclient import TestClient
from src.cat_api.main import app

client = TestClient(app)
AUTH_HEADERS = {
    "X-Organization-ID": "ORG-CAT-ATLAS",
    "Authorization": "Bearer test-dev-token"
}

def test_telemetry_ingestion_and_deduplication():
    payload = {
        "equipment_id": "EQ-CAT-336-01",
        "engine_hours": 3415.0,
        "engine_rpm": 1800,
        "coolant_temp_c": 89.0,
        "oil_pressure_kpa": 400.0,
        "fuel_level_pct": 75.0,
        "fuel_rate_lph": 28.0,
        "battery_voltage_v": 27.8,
        "hydraulic_pressure_bar": 340.0,
        "payload_tonnes": 3.0,
        "operating_state": "ACTIVE_CYCLE",
        "source_protocol": "MQTT",
        "event_id": "evt-unique-test-100"
    }

    # First ingest: accepted
    r1 = client.post("/api/v1/telemetry/ingest", json=payload)
    assert r1.status_code == 202
    assert r1.json()["status"] == "INGESTED"

    # Duplicate ingest: deduplicated
    r2 = client.post("/api/v1/telemetry/ingest", json=payload)
    assert r2.status_code == 202
    assert r2.json()["status"] == "DEDUPLICATED"

def test_get_latest_telemetry():
    response = client.get("/api/v1/equipment/EQ-CAT-336-01/telemetry/latest", headers=AUTH_HEADERS)
    assert response.status_code == 200
    data = response.json()
    assert data["equipment_id"] == "EQ-CAT-336-01"
    assert data["engine_rpm"] > 0
