from fastapi.testclient import TestClient
from src.cat_api.main import app

client = TestClient(app)
AUTH_HEADERS = {
    "X-Organization-ID": "ORG-CAT-ATLAS",
    "Authorization": "Bearer test-dev-token"
}

def test_health_check():
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "HEALTHY"
    assert data["services"]["database"] == "UP"

def test_list_equipment():
    response = client.get("/api/v1/equipment", headers=AUTH_HEADERS)
    assert response.status_code == 200
    data = response.json()
    assert "items" in data
    assert data["total"] >= 1
    assert data["items"][0]["model"] == "Cat 336 Hydraulic Excavator"

def test_equipment_tenant_isolation():
    # Another tenant should see only their equipment
    other_tenant_headers = {"X-Organization-ID": "ORG-OTHER-TENANT"}
    response = client.get("/api/v1/equipment", headers=other_tenant_headers)
    assert response.status_code == 200
    data = response.json()
    assert data["total"] == 0
