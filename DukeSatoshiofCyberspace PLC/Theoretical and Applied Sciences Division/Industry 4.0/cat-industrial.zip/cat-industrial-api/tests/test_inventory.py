from fastapi.testclient import TestClient
from src.cat_api.main import app

client = TestClient(app)
AUTH_HEADERS = {
    "X-Organization-ID": "ORG-CAT-ATLAS",
    "Authorization": "Bearer test-dev-token"
}

def test_parts_availability():
    response = client.get("/api/v1/parts/1R-1808/availability", headers=AUTH_HEADERS)
    assert response.status_code == 200
    data = response.json()
    assert data["part_number"] == "1R-1808"
    assert data["total_available"] > 0
    assert len(data["stock_by_warehouse"]) >= 1

def test_inventory_reservation_success():
    payload = {
        "part_number": "1R-1808",
        "warehouse_id": "WH-PEORIA",
        "quantity": 1,
        "work_order_id": "WO-2026-4401"
    }
    response = client.post("/api/v1/inventory/reservations", json=payload, headers=AUTH_HEADERS)
    assert response.status_code == 201
    data = response.json()
    assert data["status"] == "CONFIRMED"
    assert data["allocated_quantity"] == 1

def test_inventory_reservation_insufficient_stock():
    payload = {
        "part_number": "1R-1808",
        "warehouse_id": "WH-PEORIA",
        "quantity": 99999,
        "work_order_id": "WO-2026-4401"
    }
    response = client.post("/api/v1/inventory/reservations", json=payload, headers=AUTH_HEADERS)
    assert response.status_code == 409
    assert response.json()["error"]["code"] == "INSUFFICIENT_INVENTORY"
