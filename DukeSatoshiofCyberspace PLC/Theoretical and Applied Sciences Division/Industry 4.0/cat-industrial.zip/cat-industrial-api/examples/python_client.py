#!/usr/bin/env python3
"""
Caterpillar Industrial Equipment API Platform - Python Client SDK Example
Demonstrates listing fleet machinery, ingesting real-time CAN-bus telemetry,
managing diagnostic faults, and executing atomic parts reservation.
"""
import json
import httpx

BASE_URL = "http://localhost:8000/api/v1"
HEADERS = {
    "X-Organization-ID": "ORG-CAT-ATLAS",
    "Authorization": "Bearer cat-enterprise-dev-token",
    "Content-Type": "application/json"
}

def main():
    with httpx.Client(base_url=BASE_URL, headers=HEADERS) as client:
        print("=== 1. Health & Platform Status ===")
        health_resp = client.get("/health")
        print("Health:", health_resp.json())

        print("\n=== 2. Retrieve Machinery Fleet ===")
        fleet_resp = client.get("/equipment")
        equipment_list = fleet_resp.json()
        print(f"Total Equipment: {equipment_list['total']}")
        for eq in equipment_list["items"]:
            print(f" - [{eq['id']}] {eq['model']} (S/N: {eq['serial_number']}, Status: {eq['operational_status']}, Hours: {eq['engine_hours']})")

        selected_id = equipment_list["items"][0]["id"]

        print(f"\n=== 3. Ingest Telemetry Packet for {selected_id} ===")
        telemetry_payload = {
            "equipment_id": selected_id,
            "engine_hours": 3412.8,
            "engine_rpm": 1820,
            "coolant_temp_c": 89.4,
            "oil_pressure_kpa": 395.0,
            "fuel_level_pct": 73.5,
            "fuel_rate_lph": 27.2,
            "battery_voltage_v": 27.8,
            "hydraulic_pressure_bar": 348.0,
            "payload_tonnes": 3.4,
            "operating_state": "EXCAVATING_HEAVY_CYCLE",
            "source_protocol": "MQTT"
        }
        ingest_resp = client.post("/telemetry/ingest", json=telemetry_payload)
        print("Ingest Result:", ingest_resp.json())

        print(f"\n=== 4. Check Latest Telemetry ===")
        latest_resp = client.get(f"/equipment/{selected_id}/telemetry/latest")
        print("Latest:", latest_resp.json())

        print("\n=== 5. Check Genuine Cat Parts & Reserve ===")
        parts_resp = client.get("/parts/1R-1808/availability")
        avail = parts_resp.json()
        print(f"Part 1R-1808 Total Avail: {avail['total_available']}")

        reserve_payload = {
            "part_number": "1R-1808",
            "warehouse_id": "WH-PEORIA",
            "quantity": 2,
            "work_order_id": "WO-2026-4401"
        }
        res_resp = client.post("/inventory/reservations", json=reserve_payload)
        print("Reservation Result:", res_resp.json())

if __name__ == "__main__":
    main()
