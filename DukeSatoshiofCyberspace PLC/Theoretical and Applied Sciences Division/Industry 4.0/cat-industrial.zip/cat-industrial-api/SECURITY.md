# Security Policy - Caterpillar Industrial Equipment API Platform

## 1. Safety & Command Boundary
The initial platform is strictly scoped for telemetry monitoring, equipment diagnostics, preventive maintenance scheduling, parts inventory reservation, and authorized operational workflows.

**CRITICAL INDUSTRIAL SAFETY MANDATE**:
- Remote engine start commands, safety-interlock overrides, and direct machine actuation are **strictly prohibited** on this API surface.
- All machinery write interfaces must require multi-signature hardware authorization, isolated CAN gateway firewalls, and manual physical interlocks at the machine level.

## 2. Multi-Tenancy & Tenant Isolation
- Every API request must include a verified OIDC JWT token and an explicit `X-Organization-ID` tenant scope header.
- Cross-tenant data leaks are prevented via strict row-level security and repository scoping. A customer organization cannot access another customer's machinery or service records.

## 3. Reporting Vulnerabilities
To report a security vulnerability, contact security@cat-industrial-platform.local with an encrypted report. Critical vulnerabilities are acknowledged within 24 hours.
