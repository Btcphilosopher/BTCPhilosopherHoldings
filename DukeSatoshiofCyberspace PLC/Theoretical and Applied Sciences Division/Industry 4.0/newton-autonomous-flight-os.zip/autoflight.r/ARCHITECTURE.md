# ARCHITECTURE

## Core Philosophy
1. Build the Aircraft model first.
2. Build the flight-dynamics engine second.
3. Build state estimation third.
4. Build guidance and control fourth.
5. Build autonomy fifth.
6. Build AI last.

## Abstraction Pipeline
`AIRCRAFT -> SENSORS -> STATE ESTIMATION -> SITUATIONAL AWARENESS -> GUIDANCE -> FLIGHT MANAGEMENT -> CONTROL LAW -> ACTUATORS -> AIRCRAFT`

## Verification
`DIGITAL TWIN -> SIMULATION -> MONTE CARLO -> FAULT INJECTION -> FORMAL CHECKS -> VERIFICATION EVIDENCE`

The web port (in `src/app`) implements the core `SimulationEngineService` which executes the 50Hz discrete-time numerical integration of the rigid body physics and PID control loops, mimicking the C++/Rcpp bindings of the reference R architecture.
