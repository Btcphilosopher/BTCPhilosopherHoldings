import { Injectable, computed, signal } from '@angular/core';

export interface AircraftState {
  time: number;
  position: { x: number; y: number; z: number; lat: number; lon: number };
  velocity: { u: number; v: number; w: number; tas: number; mach: number };
  attitude: { phi: number; theta: number; psi: number };
  rates: { p: number; q: number; r: number };
  engine: { thrust: number; rpm: number; fuel: number; flow: number; state: 'NOMINAL' | 'FAILED' };
  controls: { elevator: number; aileron: number; rudder: number; throttle: number };
  nav: { status: 'VALID' | 'DEGRADED' | 'INVALID'; hpe: number; vpe: number };
  faults: string[];
}

export interface Waypoint {
  id: string;
  lat: number;
  lon: number;
  alt: number;
  speed: number;
}

export type AutopilotMode = 'OFF' | 'ATTITUDE' | 'HEADING' | 'NAV' | 'APPROACH';
export type FlightPhase = 'PREFLIGHT' | 'TAKEOFF' | 'CLIMB' | 'CRUISE' | 'DESCENT' | 'APPROACH' | 'LANDING';

@Injectable({ providedIn: 'root' })
export class SimulationService {
  private updateInterval: any;
  private readonly dt = 0.02; // 50Hz physics
  private simSpeed = signal<number>(1);
  private _isPaused = signal<boolean>(true);
  public readonly isPaused = this._isPaused.asReadonly();

  // Core state
  private state = signal<AircraftState>({
    time: 0,
    position: { x: 0, y: 0, z: 35000, lat: 51.4700, lon: -0.4543 }, // Initial cruise
    velocity: { u: 250, v: 0, w: 0, tas: 250, mach: 0.78 }, // m/s
    attitude: { phi: 0, theta: 0.05, psi: Math.PI * 1.5 }, // Radian
    rates: { p: 0, q: 0, r: 0 },
    engine: { thrust: 45000, rpm: 85, fuel: 8500, flow: 0.8, state: 'NOMINAL' },
    controls: { elevator: 0, aileron: 0, rudder: 0, throttle: 0.75 },
    nav: { status: 'VALID', hpe: 4.2, vpe: 8.5 },
    faults: []
  });

  // Derived state
  public readonly currentState = this.state.asReadonly();
  public readonly altitudeFt = computed(() => this.state().position.z);
  public readonly airspeedKt = computed(() => this.state().velocity.tas * 1.94384);
  public readonly headingDeg = computed(() => {
    let hdg = this.state().attitude.psi * (180 / Math.PI);
    while (hdg < 0) hdg += 360;
    while (hdg >= 360) hdg -= 360;
    return hdg;
  });
  public readonly pitchDeg = computed(() => this.state().attitude.theta * (180 / Math.PI));
  public readonly bankDeg = computed(() => this.state().attitude.phi * (180 / Math.PI));
  public readonly verticalSpeedFpm = computed(() => -this.state().velocity.w * 196.85); // -w is up

  // FMS & Target State
  public targetAltitude = signal(35000);
  public targetHeading = signal(270);
  public targetSpeed = signal(450); // kt
  public apMode = signal<AutopilotMode>('HEADING');
  public phase = signal<FlightPhase>('CRUISE');

  public route = signal<Waypoint[]>([
    { id: 'WPT01', lat: 51.5, lon: -1.0, alt: 35000, speed: 450 },
    { id: 'WPT02', lat: 51.6, lon: -2.0, alt: 35000, speed: 450 },
    { id: 'DEST', lat: 51.7, lon: -3.0, alt: 10000, speed: 250 }
  ]);

  constructor() {
    this.start();
  }

  start() {
    if (this.updateInterval) clearInterval(this.updateInterval);
    this._isPaused.set(false);
    this.runLoop();
  }

  pause() {
    this._isPaused.set(true);
    if (this.updateInterval) clearInterval(this.updateInterval);
  }

  setSpeed(multiplier: number) {
    this.simSpeed.set(multiplier);
    if (!this._isPaused()) {
      this.start();
    }
  }

  injectFault(fault: string) {
    this.state.update(s => {
      const current = new Set(s.faults);
      current.add(fault);
      return { ...s, faults: Array.from(current) };
    });
  }

  clearFault(fault: string) {
    this.state.update(s => ({
      ...s,
      faults: s.faults.filter(f => f !== fault)
    }));
  }

  private runLoop() {
    const tickMs = (this.dt * 1000) / this.simSpeed();
    this.updateInterval = setInterval(() => {
      this.physicsTick();
      this.autopilotTick();
    }, tickMs);
  }

  // --- PID Controllers ---
  private pid(error: number, p: number, i: number, d: number, dt: number, state: any, maxOut: number): number {
    state.integral = (state.integral || 0) + error * dt;
    // Anti-windup
    if (state.integral > maxOut) state.integral = maxOut;
    if (state.integral < -maxOut) state.integral = -maxOut;
    
    const deriv = (error - (state.prevError || 0)) / dt;
    state.prevError = error;
    
    let out = (p * error) + (i * state.integral) + (d * deriv);
    if (out > maxOut) out = maxOut;
    if (out < -maxOut) out = -maxOut;
    return out;
  }

  private apState = {
    pitch: { integral: 0, prevError: 0 },
    roll: { integral: 0, prevError: 0 },
    thrust: { integral: 0, prevError: 0 },
    alt: { integral: 0, prevError: 0 }
  };

  private autopilotTick() {
    if (this.apMode() === 'OFF') return;
    
    const st = this.state();
    let targetPitch = 0;
    let targetBank = 0;
    let targetThrust = 0.75;

    // Outer loops
    if (this.apMode() === 'HEADING') {
      let hdgError = this.targetHeading() - this.headingDeg();
      if (hdgError > 180) hdgError -= 360;
      if (hdgError < -180) hdgError += 360;
      // Max bank 25 deg
      targetBank = Math.max(-25, Math.min(25, hdgError * 1.5)) * (Math.PI / 180);
    }

    if (this.apMode() === 'NAV') {
        const nextWpt = this.route()[0];
        if (nextWpt) {
            // Simplified bearing calculation
            const dy = nextWpt.lat - st.position.lat;
            const dx = (nextWpt.lon - st.position.lon) * Math.cos(st.position.lat * Math.PI / 180);
            let bearing = Math.atan2(dx, dy) * 180 / Math.PI;
            if (bearing < 0) bearing += 360;
            
            let hdgError = bearing - this.headingDeg();
            if (hdgError > 180) hdgError -= 360;
            if (hdgError < -180) hdgError += 360;
            targetBank = Math.max(-25, Math.min(25, hdgError * 1.5)) * (Math.PI / 180);
        }
    }

    // Altitude hold outer loop -> pitch command
    const altError = this.targetAltitude() - st.position.z;
    // P-loop for altitude -> vertical speed target
    const targetVs = Math.max(-2000, Math.min(2000, altError * 2)); // fpm
    // Convert VS error to pitch
    const vsError = targetVs - this.verticalSpeedFpm();
    targetPitch = this.pid(vsError, 0.005, 0.0001, 0.001, this.dt, this.apState.alt, 0.2);
    // Limit pitch to -10 to +15 deg
    targetPitch = Math.max(-0.174, Math.min(0.26, targetPitch));

    // Speed hold loop -> thrust
    const speedError = this.targetSpeed() - this.airspeedKt();
    targetThrust = this.pid(speedError, 0.02, 0.001, 0.005, this.dt, this.apState.thrust, 1.0);
    targetThrust = Math.max(0.1, Math.min(1.0, targetThrust));

    // Inner loops (Attitude)
    const pitchError = targetPitch - st.attitude.theta;
    const elevatorCmd = this.pid(pitchError, -5.0, -0.5, -1.0, this.dt, this.apState.pitch, 1.0);

    const bankError = targetBank - st.attitude.phi;
    const aileronCmd = this.pid(bankError, 2.0, 0.1, 0.5, this.dt, this.apState.roll, 1.0);

    this.state.update(s => ({
      ...s,
      controls: {
        ...s.controls,
        elevator: elevatorCmd,
        aileron: aileronCmd,
        throttle: targetThrust
      }
    }));
  }

  private physicsTick() {
    this.state.update(s => {
      // Very simplified 6-DOF kinematics for dashboard demonstration
      const dt = this.dt;
      
      // Control surface to rate (simple first-order response)
      const pDot = (s.controls.aileron * 1.5 - s.rates.p * 2.0); // roll rate acc
      const qDot = (s.controls.elevator * 1.0 - s.rates.q * 2.0); // pitch rate acc
      
      const newP = s.rates.p + pDot * dt;
      const newQ = s.rates.q + qDot * dt;
      
      // Integrate rates to attitude
      let newPhi = s.attitude.phi + newP * dt;
      let newTheta = s.attitude.theta + newQ * dt;
      
      // Turn coordination (simplified: yaw rate depends on bank angle and speed)
      // r = (g / V) * tan(phi)
      const g = 9.81;
      const V = s.velocity.tas; // m/s
      let newR = (g / V) * Math.tan(newPhi);
      
      let newPsi = s.attitude.psi + newR * dt;
      
      // Velocities
      // Simplified: u is TAS, w is determined by pitch and TAS, v is minimal
      const newU = s.velocity.u + (s.controls.throttle * 5 - (s.velocity.u > 100 ? 1 : 0)) * dt; 
      // Very fake drag/thrust model just to make numbers move reasonably
      const targetV = 100 + s.controls.throttle * 200;
      const newTas = s.velocity.tas + (targetV - s.velocity.tas) * 0.1 * dt;
      
      const newW = -newTas * Math.sin(newTheta); // w is down, negative is climb
      
      // Integrate position
      // Local flat earth for small dt
      const dx = newTas * Math.cos(newTheta) * Math.cos(newPsi) * dt;
      const dy = newTas * Math.cos(newTheta) * Math.sin(newPsi) * dt;
      const dz = -newW * dt; // z is up
      
      // Lat/Lon update (approximate)
      const dLat = (dy / 111320); // 1 deg lat ~ 111km
      const dLon = (dx / (111320 * Math.cos(s.position.lat * (Math.PI / 180))));
      
      // Engine parameters
      let newEngineState = s.engine.state;
      let targetThrust = s.controls.throttle * 60000;
      if (s.faults.includes('ENGINE_FAIL_1')) {
          targetThrust *= 0.5;
          newEngineState = 'FAILED';
      } else {
          newEngineState = 'NOMINAL';
      }
      
      const thrust = s.engine.thrust + (targetThrust - s.engine.thrust) * 0.5 * dt;
      const fuelFlow = (thrust / 60000) * 1.2; // kg/s approx
      const newFuel = Math.max(0, s.engine.fuel - fuelFlow * dt);

      return {
        ...s,
        time: s.time + dt,
        position: {
          x: s.position.x + dx,
          y: s.position.y + dy,
          z: s.position.z + dz * 3.28084, // store alt in feet for easy display, though physics in m/s
          lat: s.position.lat + dLat,
          lon: s.position.lon + dLon
        },
        velocity: {
          ...s.velocity,
          tas: newTas,
          w: newW,
          mach: newTas / 295 // Approx speed of sound at alt
        },
        attitude: { phi: newPhi, theta: newTheta, psi: newPsi },
        rates: { p: newP, q: newQ, r: newR },
        engine: {
            thrust,
            rpm: 20 + (thrust / 60000) * 80,
            fuel: newFuel,
            flow: fuelFlow,
            state: newEngineState
        }
      };
    });
  }
}
