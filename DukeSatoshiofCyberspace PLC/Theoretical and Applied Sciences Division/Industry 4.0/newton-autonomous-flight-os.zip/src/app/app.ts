import { Component, inject } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { SimulationService, AutopilotMode } from './core/simulation.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, DecimalPipe],
  templateUrl: './app.html'
})
export class App {
  public sim = inject(SimulationService);
  
  public apModes: AutopilotMode[] = ['OFF', 'ATTITUDE', 'HEADING', 'NAV'];
  public availableFaults: string[] = ['ENGINE_FAIL_1', 'GNSS_LOSS', 'PITOT_BLOCK', 'AIL_JAM'];

  formatTime(seconds: number): string {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }

  togglePause() {
    if (this.isPaused()) {
      this.sim.start();
    } else {
      this.sim.pause();
    }
  }

  isPaused() {
    return this.sim.isPaused();
  }

  setTargetAlt(event: any) {
    this.sim.targetAltitude.set(Number(event.target.value));
  }

  setTargetSpeed(event: any) {
    this.sim.targetSpeed.set(Number(event.target.value));
  }

  setTargetHeading(event: any) {
    this.sim.targetHeading.set(Number(event.target.value));
  }

  setApMode(mode: AutopilotMode) {
    this.sim.apMode.set(mode);
  }

  hasFaults(): boolean {
    return this.sim.currentState().faults.length > 0;
  }

  hasFault(fault: string): boolean {
    return this.sim.currentState().faults.includes(fault);
  }

  toggleFault(fault: string) {
    if (this.hasFault(fault)) {
      this.sim.clearFault(fault);
    } else {
      this.sim.injectFault(fault);
    }
  }
}
