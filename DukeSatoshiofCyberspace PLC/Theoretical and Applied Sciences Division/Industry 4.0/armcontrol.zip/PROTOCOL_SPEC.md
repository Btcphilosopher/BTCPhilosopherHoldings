# Aureom.AI ArmControl - Communication & Adapter Protocol Specification
**Document Version:** 1.2
**Protocol Status:** Production / Reference Implementation

## 1. Architectural Principles

1. **Decoupled Boundary**: The Android operator application issues bounded motion intents. Trajectory interpolation, motor control, kinematic watchdogs, and safety-rated protective functions are strictly owned by the robot controller or simulation gateway.
2. **Asynchronous Non-Realtime Transport**: No hard real-time servo loop is run over Android, Bluetooth, or Wi-Fi.
3. **Independent Robot-Side Watchdog**: The robot controller enforces an independent watchdog cutoff (250 ms). Stale, delayed, or missing command frames cause the robot to safely decelerate to zero velocity automatically without relying on device clocks.
4. **Sequencing and Expiry**: All motion intent frames include monotonically increasing sequence numbers and TTL constraints. Out-of-order, duplicate, or expired packets are unconditionally discarded.

---

## 2. Message Types & JSON Schemas

### 2.1 Handshake Request (`HANDSHAKE_REQ`)
Sent by Android client upon establishing a WebSocket connection.
```json
{
  "type": "HANDSHAKE_REQ",
  "client": "Aureom.AI ArmControl Android",
  "protocolVersion": "1.2",
  "timestamp": 1731139200000
}
```

### 2.2 Robot State Telemetry (`TELEMETRY`)
Broadcast from robot gateway to Android at 30–50 Hz.
```json
{
  "type": "TELEMETRY",
  "timestamp": 1731139200033,
  "joints": [0.00, -25.00, 45.00, 0.00, 70.00, 0.00],
  "jointVelocities": [0.00, 0.00, 0.00, 0.00, 0.00, 0.00],
  "tool": {
    "x": 350.0,
    "y": 0.0,
    "z": 280.0,
    "roll": 0.0,
    "pitch": 90.0,
    "yaw": 0.0
  },
  "gripper": 0.0,
  "state": "READY",
  "watchdogMs": 250,
  "fault": null,
  "seq": 1042
}
```

### 2.3 Motion Intent (`MOTION_INTENT`)
Sent from Android client during manual jogging or playback.
```json
{
  "type": "MOTION_INTENT",
  "sessionId": "a7f9c2d1",
  "seq": 1043,
  "timestamp": 1731139200030,
  "ttlMs": 150,
  "mode": "CARTESIAN_JOG",
  "frame": "BASE",
  "speed": 35.0,
  "enable": true,
  "cartesianVel": {
    "vx": 45.0,
    "vy": 0.0,
    "vz": -12.0,
    "wx": 0.0,
    "wy": 0.0,
    "wz": 15.0
  }
}
```

### 2.4 Gripper Actuation Intent (`GRIPPER_INTENT`)
```json
{
  "type": "GRIPPER_INTENT",
  "sessionId": "a7f9c2d1",
  "close": true,
  "target": 1.0
}
```

### 2.5 Stop / E-Stop Request (`STOP_REQ`)
```json
{
  "type": "STOP_REQ",
  "sessionId": "a7f9c2d1",
  "isEmergency": true,
  "reason": "Operator Emergency Stop Actuator"
}
```

---

## 3. Industrial Robot Adapter Guidance

For integrating with industrial manufacturer controllers (KUKA, ABB, Fanuc, Universal Robots, Yaskawa, ROS/ROS2):
- **Universal Robots**: Bridge RTDE (Real-Time Data Exchange) or URScript `speedj()` / `speedl()` with a 250ms watchdog timeout thread.
- **KUKA**: Integrate via KUKA.EthernetKRL or KUKA Sunrise connectivity.
- **ABB**: Integrate via Robot Web Services (RWS) or PC Interface (EGM - Externally Guided Motion).
- **ROS 2**: Implement a `rclpy` node subscribing to `aureom/motion_intent` and publishing `sensor_msgs/JointState` and `geometry_msgs/TwistStamped`.
