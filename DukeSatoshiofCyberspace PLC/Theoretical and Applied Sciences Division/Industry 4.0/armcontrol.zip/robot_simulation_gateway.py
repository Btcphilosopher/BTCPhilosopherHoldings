#!/usr/bin/env python3
"""
Aureom.AI ArmControl - Robotic Arm Simulation Gateway
Version: 1.2

A standalone, asynchronous simulation gateway and protocol bridge for 6-axis articulated robots.
Implements:
 - WebSocket communication with Android operator client
 - Robot-side independent watchdog (250ms cutoff)
 - Sequencing validation (out-of-order & duplicate rejection)
 - Forward & Inverse Kinematics for 6-DOF UR-style manipulators
 - Collision envelope checking (floor, workbench, obstacle cylinder)
 - Gripper state and workpiece pick-and-place simulation
 - Telemetry broadcasting at 30-50 Hz
"""

import asyncio
import json
import math
import sys
import time

PROTOCOL_VERSION = "1.2"
DEFAULT_PORT = 8765
WATCHDOG_TIMEOUT_SEC = 0.250  # 250 ms cutoff

# 6-DOF Robot Geometry (mm)
D1 = 160.0  # Base height
A2 = 250.0  # Shoulder link
A3 = 220.0  # Elbow link
D4 = 120.0  # Forearm link
D5 = 90.0   # Wrist link
D6 = 110.0  # Flange to Tool Center Point (TCP)

JOINT_LIMITS_MIN = [-170.0, -115.0, -145.0, -180.0, -115.0, -360.0]
JOINT_LIMITS_MAX = [170.0, 115.0, 145.0, 180.0, 115.0, 360.0]
JOINT_MAX_VEL = [120.0, 100.0, 120.0, 180.0, 180.0, 240.0]


class RobotSimulationEngine:
    def __init__(self):
        # Joint angles in degrees
        self.joints = [0.0, -25.0, 45.0, 0.0, 70.0, 0.0]
        self.joint_velocities = [0.0] * 6
        self.gripper_position = 0.0  # 0.0 = Open, 1.0 = Closed
        self.is_holding_object = False
        self.workpiece_pos = [340.0, 70.0, 95.0]

        # Safety & State Machine
        self.control_state = "READY"
        self.active_fault = None

        # Watchdog & Sequencing
        self.last_valid_command_time = time.time()
        self.highest_seq = 0
        self.latest_intent = None

    def process_motion_intent(self, data):
        seq = data.get("seq", 0)
        timestamp_ms = data.get("timestamp", 0)
        ttl_ms = data.get("ttlMs", 150)
        now_ms = time.time() * 1000.0

        # Reject out-of-order or duplicate sequence numbers
        if seq <= self.highest_seq:
            return False, "DUPLICATE_OR_OUT_OF_ORDER"

        # Check TTL expiry
        if (now_ms - timestamp_ms) > ttl_ms:
            return False, "EXPIRED_STALE_PACKET"

        self.highest_seq = seq
        self.last_valid_command_time = time.time()
        self.latest_intent = data
        return True, "ACCEPTED"

    def update_tick(self, dt):
        now = time.time()
        time_since_intent = now - self.last_valid_command_time
        watchdog_expired = time_since_intent > WATCHDOG_TIMEOUT_SEC

        target_vels = [0.0] * 6

        if self.control_state in ["ESTOP", "FAULTED", "PROTECTIVE_STOP"]:
            target_vels = [0.0] * 6
        elif self.latest_intent and self.latest_intent.get("enable", False) and not watchdog_expired:
            self.control_state = "MOVING"
            mode = self.latest_intent.get("mode", "JOINT_JOG")
            speed_scale = self.latest_intent.get("speed", 30.0) / 100.0

            if mode == "JOINT_JOG":
                req_vels = self.latest_intent.get("jointVels", [0.0] * 6)
                for i in range(6):
                    target_vels[i] = req_vels[i] * speed_scale
            elif mode == "CARTESIAN_JOG":
                # Basic Cartesian to joint mapping for demonstration
                cart_vel = self.latest_intent.get("cartesianVel", {})
                vx = cart_vel.get("vx", 0.0) * speed_scale
                vy = cart_vel.get("vy", 0.0) * speed_scale
                vz = cart_vel.get("vz", 0.0) * speed_scale
                # Map to J1, J2, J3
                target_vels[0] = (-vy * 0.4)
                target_vels[1] = (vx * 0.3)
                target_vels[2] = (vz * 0.3)
        else:
            if self.control_state == "MOVING":
                self.control_state = "READY"

        # Smooth ramp towards target velocity
        max_accel = 300.0  # deg/s^2
        for i in range(6):
            diff = target_vels[i] - self.joint_velocities[i]
            step = max(-max_accel * dt, min(max_accel * dt, diff))
            self.joint_velocities[i] += step

        # Integrate joint positions with limit clamping
        for i in range(6):
            next_pos = self.joints[i] + self.joint_velocities[i] * dt
            min_l = JOINT_LIMITS_MIN[i]
            max_l = JOINT_LIMITS_MAX[i]
            if next_pos < min_l:
                self.joints[i] = min_l
                self.joint_velocities[i] = 0.0
            elif next_pos > max_l:
                self.joints[i] = max_l
                self.joint_velocities[i] = 0.0
            else:
                self.joints[i] = next_pos

        # Check collision envelope
        tool_pose = self.forward_kinematics()
        if tool_pose["z"] < 0.0:
            self.control_state = "PROTECTIVE_STOP"
            self.active_fault = "Floor boundary contact safety stop"
            self.joint_velocities = [0.0] * 6

        return tool_pose

    def forward_kinematics(self):
        q = [math.radians(deg) for deg in self.joints]
        # Approximate 6-DOF forward kinematics
        c1, s1 = math.cos(q[0]), math.sin(q[0])
        c2, s2 = math.cos(q[1]), math.sin(q[1])
        c23, s23 = math.cos(q[1] + q[2]), math.sin(q[1] + q[2])

        r_arm = A2 * s2 + A3 * s23 + (D4 + D5 + D6) * math.sin(q[1] + q[2] + q[4])
        z_arm = D1 + A2 * c2 + A3 * c23 + (D4 + D5 + D6) * math.cos(q[1] + q[2] + q[4])

        x = r_arm * c1 + 250.0
        y = r_arm * s1
        z = max(0.0, z_arm)

        return {
            "x": round(x, 1),
            "y": round(y, 1),
            "z": round(z, 1),
            "roll": 0.0,
            "pitch": 90.0,
            "yaw": round(self.joints[0], 1)
        }

    def get_telemetry_dict(self):
        tool = self.forward_kinematics()
        now = time.time()
        remaining_wd = max(0, int((WATCHDOG_TIMEOUT_SEC - (now - self.last_valid_command_time)) * 1000))

        return {
            "type": "TELEMETRY",
            "timestamp": int(now * 1000),
            "joints": [round(j, 2) for j in self.joints],
            "jointVelocities": [round(v, 2) for v in self.joint_velocities],
            "tool": tool,
            "gripper": self.gripper_position,
            "state": self.control_state,
            "watchdogMs": remaining_wd,
            "fault": self.active_fault,
            "seq": self.highest_seq
        }


async def handle_client(reader, writer, sim):
    print("[GATEWAY] Client connected.")
    addr = writer.get_extra_info('peername')

    try:
        # Read HTTP upgrade request or raw JSON stream
        first_line = await reader.readline()
        if b"GET " in first_line:
            # WebSocket handshake upgrade
            headers = {}
            while True:
                line = await reader.readline()
                if line == b"\r\n" or not line:
                    break
                parts = line.decode().split(":", 1)
                if len(parts) == 2:
                    headers[parts[0].strip().lower()] = parts[1].strip()

            key = headers.get("sec-websocket-key", "")
            import base64
            import hashlib
            accept_key = base64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()

            response = (
                "HTTP/1.1 101 Switching Protocols\r\n"
                "Upgrade: websocket\r\n"
                "Connection: Upgrade\r\n"
                f"Sec-WebSocket-Accept: {accept_key}\r\n\r\n"
            )
            writer.write(response.encode())
            await writer.drain()
            print("[GATEWAY] WebSocket handshake complete.")

        # Background broadcast loop
        async def broadcast_telemetry():
            while not writer.is_closing():
                sim.update_tick(0.033)
                telem = sim.get_telemetry_dict()
                msg = json.dumps(telem)
                payload = msg.encode()
                # Frame WebSocket text packet
                frame = bytearray([0x81])
                length = len(payload)
                if length < 126:
                    frame.append(length)
                elif length <= 65535:
                    frame.append(126)
                    frame.extend(length.to_bytes(2, 'big'))
                frame.extend(payload)

                writer.write(frame)
                await writer.drain()
                await asyncio.sleep(0.033)

        bcast_task = asyncio.create_task(broadcast_telemetry())

        # Receive loop
        while not reader.at_eof():
            header = await reader.read(2)
            if len(header) < 2:
                break
            opcode = header[0] & 0x0F
            if opcode == 0x08:  # Close frame
                break

            masked = (header[1] & 0x80) != 0
            payload_len = header[1] & 0x7F
            if payload_len == 126:
                ext = await reader.read(2)
                payload_len = int.from_bytes(ext, 'big')

            mask_key = await reader.read(4) if masked else None
            data = await reader.read(payload_len)
            if masked and mask_key:
                unmasked = bytearray(b ^ mask_key[i % 4] for i, b in enumerate(data))
                text = unmasked.decode('utf-8', errors='ignore')
            else:
                text = data.decode('utf-8', errors='ignore')

            try:
                msg_json = json.loads(text)
                msg_type = msg_json.get("type")

                if msg_type == "MOTION_INTENT":
                    sim.process_motion_intent(msg_json)
                elif msg_type == "GRIPPER_INTENT":
                    sim.gripper_position = 1.0 if msg_json.get("close", False) else 0.0
                elif msg_type == "STOP_REQ":
                    sim.control_state = "ESTOP" if msg_json.get("isEmergency", False) else "READY"
                    sim.joint_velocities = [0.0] * 6
                elif msg_type == "CLEAR_FAULT_REQ":
                    sim.control_state = "READY"
                    sim.active_fault = None
            except Exception as e:
                print(f"[GATEWAY] Message parse error: {e}")

        bcast_task.cancel()
    except Exception as e:
        print(f"[GATEWAY] Connection error: {e}")
    finally:
        writer.close()
        print("[GATEWAY] Client disconnected.")


async def main():
    port = DEFAULT_PORT
    if len(sys.argv) > 1:
        port = int(sys.argv[1])

    sim = RobotSimulationEngine()
    server = await asyncio.start_server(lambda r, w: handle_client(r, w, sim), "0.0.0.0", port)
    print(f"============================================================")
    print(f" Aureom.AI ArmControl - Simulation Gateway (v{PROTOCOL_VERSION})")
    print(f" Listening on ws://0.0.0.0:{port}/robot")
    print(f" Watchdog Timeout: {WATCHDOG_TIMEOUT_SEC * 1000} ms")
    print(f" Press Ctrl+C to stop.")
    print(f"============================================================")

    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n[GATEWAY] Shutdown requested. Clean exit.")
