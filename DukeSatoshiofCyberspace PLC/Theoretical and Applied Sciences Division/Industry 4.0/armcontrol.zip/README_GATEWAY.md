# Aureom.AI ArmControl - Simulation Gateway Instructions

## Running the Python Simulation Gateway

The repository includes `robot_simulation_gateway.py`, a zero-dependency Python 3 gateway that simulates a 6-axis robotic arm with forward kinematics, watchdog enforcement, and WebSocket telemetry.

### Requirements
- Python 3.8+ (no pip dependencies required; uses Python's standard library `asyncio`, `json`, `math`, `time`).

### Starting the Gateway
Run the script from your terminal:
```bash
python3 robot_simulation_gateway.py 8765
```

The gateway will start listening on `ws://0.0.0.0:8765/robot`.

### Connecting from Android
1. Open the **ArmControl** Android app.
2. Navigate to the **Connect** tab.
3. In the **Robot Gateway Adapter** card, select **Python Gateway**.
4. If testing via Android Emulator, the default URL is `ws://10.0.2.2:8765/robot`.
5. If running on a physical Android phone or tablet on the same Wi-Fi network, replace `10.0.2.2` with your host machine's local IP address (e.g. `ws://192.168.1.50:8765/robot`).
6. Tap **Connect** to begin streaming live telemetry.
