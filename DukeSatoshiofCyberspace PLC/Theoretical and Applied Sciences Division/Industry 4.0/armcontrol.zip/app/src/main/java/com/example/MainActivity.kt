package com.example

import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.ui.MainScreen
import com.example.ui.theme.AureomArmTheme
import com.example.viewmodel.ArmControlViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: ArmControlViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      val isDarkTheme by viewModel.isDarkTheme.collectAsState()
      AureomArmTheme(darkTheme = isDarkTheme) {
        MainScreen(viewModel = viewModel)
      }
    }
  }

  /**
   * Intercept raw joystick and analog trigger motion events from gamepads.
   */
  override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
    val handled = viewModel.controllerManager.handleMotionEvent(event)
    return if (handled) true else super.dispatchGenericMotionEvent(event)
  }

  /**
   * Intercept raw button presses from gamepads (A, B, X, Y, Bumpers, Menu, Stop).
   */
  override fun dispatchKeyEvent(event: KeyEvent): Boolean {
    val handled = viewModel.controllerManager.handleKeyEvent(event)
    return if (handled) true else super.dispatchKeyEvent(event)
  }

  /**
   * Safety rule: when app loses foreground focus, immediately halt motion
   * and require neutral stick return before rearming.
   */
  override fun onWindowFocusChanged(hasFocus: Boolean) {
    super.onWindowFocusChanged(hasFocus)
    if (!hasFocus) {
      viewModel.controllerManager.requireNeutralRearm("Foreground focus lost")
      viewModel.requestControlledStop("Focus changed")
    }
  }
}
