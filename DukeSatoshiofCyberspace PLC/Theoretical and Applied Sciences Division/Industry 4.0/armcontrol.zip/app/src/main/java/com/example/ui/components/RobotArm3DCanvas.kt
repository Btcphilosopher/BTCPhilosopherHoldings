package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.kinematics.RobotKinematics
import com.example.kinematics.Vector3
import com.example.model.RobotState
import com.example.ui.theme.AureomGoldPrimary
import com.example.ui.theme.SafetyAmber
import com.example.ui.theme.SafetyBlue
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.SafetyRed
import kotlin.math.cos
import kotlin.math.sin

/**
 * 3D Isometric / Perspective Viewport for the 6-Axis Robotic Arm.
 * Supports interactive orbit, zoom, pan, and real-time visualization of links,
 * joints, tool center point (TCP), coordinate triad, workpiece block, and obstacles.
 */
@Composable
fun RobotArm3DCanvas(
  robotState: RobotState,
  modifier: Modifier = Modifier,
  blockLocation: FloatArray = floatArrayOf(340f, 70f, 95f),
  showTrajectoryTrail: Boolean = true
) {
  // Camera orbit angles (in radians)
  var azimuth by remember { mutableFloatStateOf(0.75f) }    // Horizontal orbit
  var elevation by remember { mutableFloatStateOf(0.45f) }  // Vertical pitch
  var zoomScale by remember { mutableFloatStateOf(1.35f) }  // Zoom multiplier

  // Breadcrumb trajectory history
  val tcpTrail = remember { mutableStateListOf<Vector3>() }

  // Update trail
  val fk = remember(robotState.jointPositionsDeg) {
    RobotKinematics.forwardKinematics(robotState.jointPositionsDeg)
  }

  val currentTcp = fk.jointPositions.last()
  if (tcpTrail.isEmpty() || (currentTcp - tcpTrail.last()).length() > 8f) {
    if (tcpTrail.size > 80) tcpTrail.removeAt(0)
    tcpTrail.add(currentTcp)
  }

  Box(modifier = modifier) {
    Canvas(
      modifier = Modifier
        .fillMaxSize()
        .pointerInput(Unit) {
          detectDragGestures { change, dragAmount ->
            change.consume()
            azimuth += dragAmount.x * 0.006f
            elevation = (elevation + dragAmount.y * 0.006f).coerceIn(0.1f, 1.45f)
          }
        }
        .pointerInput(Unit) {
          detectTransformGestures { _, _, zoom, _ ->
            zoomScale = (zoomScale * zoom).coerceIn(0.6f, 3.0f)
          }
        }
    ) {
      val center = Offset(size.width * 0.5f, size.height * 0.62f)
      val scale = (size.minDimension / 1100f) * zoomScale

      fun project(v: Vector3): Offset {
        // Rotate around Z axis by azimuth
        val cosA = cos(azimuth); val sinA = sin(azimuth)
        val rx = v.x * cosA - v.y * sinA
        val ry = v.x * sinA + v.y * cosA

        // Rotate around horizontal axis by elevation
        val cosE = cos(elevation); val sinE = sin(elevation)
        val px = rx
        val py = ry * sinE - v.z * cosE

        return Offset(
          x = center.x + px * scale,
          y = center.y + py * scale
        )
      }

      // 1. Draw floor grid
      drawFloorGrid(::project)

      // 2. Draw workbench and target drop zone
      drawWorkbench(::project)

      // 3. Draw test obstacle pillar
      drawObstaclePillar(::project)

      // 4. Draw workpiece block
      drawWorkpieceBlock(
        blockPos = Vector3(blockLocation[0], blockLocation[1], blockLocation[2]),
        isHeld = robotState.isGripperHoldingObject,
        project = ::project
      )

      // 5. Draw trajectory trail
      if (showTrajectoryTrail && tcpTrail.size > 1) {
        for (i in 0 until tcpTrail.size - 1) {
          val p1 = project(tcpTrail[i])
          val p2 = project(tcpTrail[i + 1])
          val alpha = (i.toFloat() / tcpTrail.size).coerceIn(0.1f, 0.7f)
          drawLine(
            color = AureomGoldPrimary.copy(alpha = alpha),
            start = p1,
            end = p2,
            strokeWidth = 2.5f,
            cap = StrokeCap.Round
          )
        }
      }

      // 6. Draw Robot Links and Joints
      val jointPts = fk.jointPositions
      drawRobotArmStructure(
        points = jointPts,
        gripperPos = robotState.gripperPosition,
        isHolding = robotState.isGripperHoldingObject,
        isSingular = fk.isSingular,
        project = ::project
      )

      // 7. Draw Tool Center Point (TCP) Coordinate Triad (Red=X, Green=Y, Blue=Z)
      val tcp = jointPts.last()
      val rot = fk.toolRotation
      val triadLen = 45f

      val axisX = tcp + (rot * Vector3(triadLen, 0f, 0f))
      val axisY = tcp + (rot * Vector3(0f, triadLen, 0f))
      val axisZ = tcp + (rot * Vector3(0f, 0f, triadLen))

      val pTcp = project(tcp)
      drawLine(SafetyRed, pTcp, project(axisX), strokeWidth = 4f, cap = StrokeCap.Round)
      drawLine(SafetyGreen, pTcp, project(axisY), strokeWidth = 4f, cap = StrokeCap.Round)
      drawLine(SafetyBlue, pTcp, project(axisZ), strokeWidth = 4f, cap = StrokeCap.Round)
    }

    // Camera view controls overlay
    Surface(
      modifier = Modifier
        .align(Alignment.TopEnd)
        .padding(12.dp),
      color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
      shape = MaterialTheme.shapes.small
    ) {
      Box(modifier = Modifier.padding(4.dp)) {
        FilledIconButton(
          onClick = {
            azimuth = 0.75f
            elevation = 0.45f
            zoomScale = 1.35f
          },
          colors = IconButtonDefaults.filledIconButtonColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
          )
        ) {
          Icon(
            imageVector = Icons.Default.RestartAlt,
            contentDescription = "Reset Camera View",
            tint = AureomGoldPrimary
          )
        }
      }
    }

    // Singularity indicator badge
    if (robotState.isSingularityNear) {
      Surface(
        modifier = Modifier
          .align(Alignment.TopStart)
          .padding(12.dp),
        color = SafetyAmber.copy(alpha = 0.2f),
        shape = MaterialTheme.shapes.small
      ) {
        Text(
          text = "⚠ ${robotState.singularityWarningText ?: "Near Singularity"}",
          color = SafetyAmber,
          fontSize = 11.sp,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
      }
    }
  }
}

private fun DrawScope.drawFloorGrid(project: (Vector3) -> Offset) {
  val gridRange = -500f..500f
  val step = 100f
  val gridColor = Color(0xFF282C36).copy(alpha = 0.6f)

  var v = -500f
  while (v <= 500f) {
    drawLine(gridColor, project(Vector3(v, -500f, 0f)), project(Vector3(v, 500f, 0f)), 1f)
    drawLine(gridColor, project(Vector3(-500f, v, 0f)), project(Vector3(500f, v, 0f)), 1f)
    v += step
  }

  // Base origin triad (World Frame)
  val pOrigin = project(Vector3(0f, 0f, 0f))
  drawLine(SafetyRed.copy(alpha = 0.7f), pOrigin, project(Vector3(70f, 0f, 0f)), 2.5f)
  drawLine(SafetyGreen.copy(alpha = 0.7f), pOrigin, project(Vector3(0f, 70f, 0f)), 2.5f)
  drawLine(SafetyBlue.copy(alpha = 0.7f), pOrigin, project(Vector3(0f, 0f, 70f)), 2.5f)
}

private fun DrawScope.drawWorkbench(project: (Vector3) -> Offset) {
  // Workbench surface: X in [160, 560], Y in [-250, 250], Z = 80mm
  val c1 = project(Vector3(160f, -250f, 80f))
  val c2 = project(Vector3(560f, -250f, 80f))
  val c3 = project(Vector3(560f, 250f, 80f))
  val c4 = project(Vector3(160f, 250f, 80f))

  val tablePath = Path().apply {
    moveTo(c1.x, c1.y)
    lineTo(c2.x, c2.y)
    lineTo(c3.x, c3.y)
    lineTo(c4.x, c4.y)
    close()
  }
  drawPath(tablePath, Color(0xFF1E2128).copy(alpha = 0.95f))
  drawPath(tablePath, Color(0xFF424754), style = Stroke(width = 2f))

  // Target drop zone on table
  val targetCenter = project(Vector3(310f, -140f, 82f))
  drawCircle(SafetyGreen.copy(alpha = 0.4f), radius = 22f, center = targetCenter, style = Stroke(2f))
}

private fun DrawScope.drawObstaclePillar(project: (Vector3) -> Offset) {
  val ox = 320f
  val oy = -180f
  val r = 35f
  val h = 180f

  val b1 = project(Vector3(ox, oy, 0f))
  val t1 = project(Vector3(ox, oy, h))

  drawLine(SafetyAmber.copy(alpha = 0.8f), b1, t1, strokeWidth = 26f, cap = StrokeCap.Round)
  drawCircle(SafetyAmber, radius = 13f, center = t1)
}

private fun DrawScope.drawWorkpieceBlock(
  blockPos: Vector3,
  isHeld: Boolean,
  project: (Vector3) -> Offset
) {
  val p = project(blockPos)
  val blockColor = if (isHeld) AureomGoldPrimary else Color(0xFFE8B65A)
  drawCircle(blockColor, radius = 14f, center = p)
  drawCircle(Color(0xFF2C220E), radius = 14f, center = p, style = Stroke(2.5f))
}

private fun DrawScope.drawRobotArmStructure(
  points: List<Vector3>,
  gripperPos: Float,
  isHolding: Boolean,
  isSingular: Boolean,
  project: (Vector3) -> Offset
) {
  // Mount base (Pedestal)
  val pBase = project(points[0])
  drawCircle(Color(0xFF2B2E38), radius = 28f, center = pBase)
  drawCircle(AureomGoldPrimary, radius = 28f, center = pBase, style = Stroke(3f))

  // Link colors
  val linkDark = Color(0xFF404552)
  val linkHighlight = Color(0xFF5A6072)
  val jointGold = AureomGoldPrimary

  // Draw Arm Links
  // Link 0 -> 1: Pedestal
  drawLine(linkDark, pBase, project(points[1]), strokeWidth = 22f, cap = StrokeCap.Round)

  // Link 1 -> 2: Shoulder
  val p1 = project(points[1])
  val p2 = project(points[2])
  drawLine(linkHighlight, p1, p2, strokeWidth = 20f, cap = StrokeCap.Round)
  drawCircle(jointGold, radius = 12f, center = p1)

  // Link 2 -> 3: Elbow
  val p3 = project(points[3])
  drawLine(linkDark, p2, p3, strokeWidth = 16f, cap = StrokeCap.Round)
  drawCircle(jointGold, radius = 10f, center = p2)

  // Link 3 -> 4: Forearm
  val p4 = project(points[4])
  drawLine(linkHighlight, p3, p4, strokeWidth = 14f, cap = StrokeCap.Round)
  drawCircle(jointGold, radius = 9f, center = p3)

  // Link 4 -> 5: Wrist 1
  val p5 = project(points[5])
  drawLine(linkDark, p4, p5, strokeWidth = 12f, cap = StrokeCap.Round)
  drawCircle(if (isSingular) SafetyAmber else jointGold, radius = 8f, center = p4)

  // Link 5 -> 6: Wrist 2 & Flange
  val p6 = project(points[6])
  drawLine(linkHighlight, p5, p6, strokeWidth = 10f, cap = StrokeCap.Round)
  drawCircle(jointGold, radius = 7f, center = p5)

  // Parallel Gripper fingers
  val fingerSpread = 18f * (1f - gripperPos) + 4f
  val fLeft = p6 + Offset(-fingerSpread, 16f)
  val fRight = p6 + Offset(fingerSpread, 16f)

  drawLine(AureomGoldPrimary, p6, fLeft, strokeWidth = 4f, cap = StrokeCap.Square)
  drawLine(AureomGoldPrimary, p6, fRight, strokeWidth = 4f, cap = StrokeCap.Square)

  if (isHolding) {
    drawCircle(AureomGoldPrimary, radius = 8f, center = p6 + Offset(0f, 14f))
  }
}
