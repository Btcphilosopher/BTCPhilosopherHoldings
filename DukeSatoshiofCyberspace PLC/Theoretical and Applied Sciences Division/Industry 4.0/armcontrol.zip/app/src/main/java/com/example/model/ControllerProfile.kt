package com.example.model

enum class ResponseCurve(val label: String, val description: String) {
  LINEAR("Linear", "Direct proportional output for predictable velocity"),
  QUADRATIC("Quadratic (Smooth Center)", "Gentle control around center with full speed at limits"),
  EXPO_SMOOTH("Exponential Industrial", "Ultra-fine precision trimming near center with rapid travel at perimeter")
}

data class ControllerInputState(
  val deviceName: String = "No Controller Connected",
  val isConnected: Boolean = false,
  // Analog sticks [-1.0f .. 1.0f]
  val leftStickX: Float = 0f,
  val leftStickY: Float = 0f,
  val rightStickX: Float = 0f,
  val rightStickY: Float = 0f,
  // Triggers [0.0f .. 1.0f]
  val leftTrigger: Float = 0f,   // Hold-to-enable (Deadman)
  val rightTrigger: Float = 0f,  // Speed regulator
  // D-pad [-1, 0, 1]
  val dpadX: Int = 0,
  val dpadY: Int = 0,
  // Face and shoulder buttons
  val buttonA: Boolean = false,      // Primary face: Gripper Close
  val buttonB: Boolean = false,      // Secondary face: Gripper Open
  val buttonX: Boolean = false,      // Translation mode toggle / Action
  val buttonY: Boolean = false,      // Frame toggle (Base/Tool)
  val bumperLeft: Boolean = false,   // Joint selection - / Translation Mode
  val bumperRight: Boolean = false,  // Joint selection + / Rotation Mode
  val buttonMenu: Boolean = false,   // Pause
  val buttonStop: Boolean = false,   // Dedicated stop button (e.g. Back/Select/Thumb)
  // Processed flags
  val isDeadmanEngaged: Boolean = false,
  val isNeutralRearmed: Boolean = true,
  val speedScalePercent: Float = 30f
) {
  val isAnyStickActive: Boolean
    get() = kotlin.math.abs(leftStickX) > 0.05f ||
        kotlin.math.abs(leftStickY) > 0.05f ||
        kotlin.math.abs(rightStickX) > 0.05f ||
        kotlin.math.abs(rightStickY) > 0.05f
}

data class ControllerProfile(
  val id: String = "default_xbox",
  val name: String = "Xbox Standard",
  val deviceDescriptor: String = "Generic Gamepad",
  val deadzoneLeft: Float = 0.12f,
  val deadzoneRight: Float = 0.12f,
  val deadzoneTrigger: Float = 0.10f,
  val deadmanActivateThreshold: Float = 0.35f,
  val deadmanReleaseThreshold: Float = 0.20f,
  val responseCurve: ResponseCurve = ResponseCurve.QUADRATIC,
  val invertLeftY: Boolean = true,  // Stick up = +Y
  val invertRightY: Boolean = true  // Stick up = +Z
)
