package com.example.controller

import android.content.Context
import android.hardware.input.InputManager
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import com.example.model.ControllerInputState
import com.example.model.ControllerProfile
import com.example.model.ResponseCurve
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sign

class ControllerManager(
  private val context: Context
) : InputManager.InputDeviceListener {

  private val inputManager = context.getSystemService(Context.INPUT_SERVICE) as? InputManager

  private var activeProfile = ControllerProfile()
  private val neutralRearmManager = NeutralRearmManager(
    deadzoneStick = activeProfile.deadzoneLeft,
    deadmanThreshold = activeProfile.deadmanReleaseThreshold
  )

  private val _inputState = MutableStateFlow(ControllerInputState())
  val inputState: StateFlow<ControllerInputState> = _inputState.asStateFlow()

  // Internal raw states
  private var rawLX = 0f
  private var rawLY = 0f
  private var rawRX = 0f
  private var rawRY = 0f
  private var rawLT = 0f
  private var rawRT = 0f
  private var rawDpadX = 0
  private var rawDpadY = 0

  private var btnA = false
  private var btnB = false
  private var btnX = false
  private var btnY = false
  private var btnL1 = false
  private var btnR1 = false
  private var btnMenu = false
  private var btnStop = false

  // Deadman trigger state with hysteresis
  private var isDeadmanActive = false

  // Orientation mode toggle (true = right stick adjusts tool orientation roll/pitch/yaw, false = translation Z/yaw)
  var isOrientationJogMode: Boolean = false
    private set

  init {
    inputManager?.registerInputDeviceListener(this, null)
    scanConnectedControllers()
    neutralRearmManager.requireRearm("Initial controller setup")
  }

  fun setProfile(profile: ControllerProfile) {
    activeProfile = profile
    neutralRearmManager.updateDeadzone(profile.deadzoneLeft, profile.deadmanReleaseThreshold)
  }

  fun getProfile(): ControllerProfile = activeProfile

  fun toggleOrientationJogMode() {
    isOrientationJogMode = !isOrientationJogMode
    neutralRearmManager.requireRearm("Jog mode changed to ${if (isOrientationJogMode) "Orientation" else "Translation"}")
  }

  fun requireNeutralRearm(reason: String) {
    neutralRearmManager.requireRearm(reason)
    updateState()
  }

  fun scanConnectedControllers() {
    val deviceIds = InputDevice.getDeviceIds()
    var foundController = false
    for (id in deviceIds) {
      val device = InputDevice.getDevice(id) ?: continue
      val sources = device.sources
      if ((sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
        (sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
      ) {
        _inputState.value = _inputState.value.copy(
          deviceName = device.name,
          isConnected = true
        )
        foundController = true
        break
      }
    }
    if (!foundController) {
      _inputState.value = _inputState.value.copy(
        deviceName = "No Controller Detected",
        isConnected = false
      )
      neutralRearmManager.requireRearm("No gamepad connected")
    }
  }

  /**
   * Process MotionEvent from Android activity.
   */
  fun handleMotionEvent(event: MotionEvent): Boolean {
    val device = event.device ?: return false
    val sources = device.sources
    if ((sources and InputDevice.SOURCE_GAMEPAD) != InputDevice.SOURCE_GAMEPAD &&
      (sources and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK
    ) {
      return false
    }

    if (event.action != MotionEvent.ACTION_MOVE) {
      return false
    }

    // Left Stick (X, Y)
    rawLX = event.getAxisValue(MotionEvent.AXIS_X)
    val lyVal = event.getAxisValue(MotionEvent.AXIS_Y)
    rawLY = if (activeProfile.invertLeftY) -lyVal else lyVal

    // Right Stick (Z, RZ)
    rawRX = event.getAxisValue(MotionEvent.AXIS_Z)
    val ryVal = event.getAxisValue(MotionEvent.AXIS_RZ)
    rawRY = if (activeProfile.invertRightY) -ryVal else ryVal

    // Triggers (Handle normalized 0..1 or -1..1)
    val ltVal = event.getAxisValue(MotionEvent.AXIS_LTRIGGER).takeIf { it != 0f }
      ?: event.getAxisValue(MotionEvent.AXIS_BRAKE)
    rawLT = normalizeTrigger(ltVal)

    val rtVal = event.getAxisValue(MotionEvent.AXIS_RTRIGGER).takeIf { it != 0f }
      ?: event.getAxisValue(MotionEvent.AXIS_GAS)
    rawRT = normalizeTrigger(rtVal)

    // Hat / D-pad from motion event
    val hatX = event.getAxisValue(MotionEvent.AXIS_HAT_X).toInt()
    val hatY = event.getAxisValue(MotionEvent.AXIS_HAT_Y).toInt()
    if (hatX != 0 || hatY != 0) {
      rawDpadX = hatX
      rawDpadY = -hatY // Hat Y is inverted in Android
    }

    updateState()
    return true
  }

  /**
   * Process KeyEvent from Android activity.
   */
  fun handleKeyEvent(event: KeyEvent): Boolean {
    val isDown = event.action == KeyEvent.ACTION_DOWN

    when (event.keyCode) {
      KeyEvent.KEYCODE_BUTTON_A -> btnA = isDown
      KeyEvent.KEYCODE_BUTTON_B -> btnB = isDown
      KeyEvent.KEYCODE_BUTTON_X -> btnX = isDown
      KeyEvent.KEYCODE_BUTTON_Y -> btnY = isDown
      KeyEvent.KEYCODE_BUTTON_L1 -> {
        btnL1 = isDown
        if (isDown) toggleOrientationJogMode()
      }
      KeyEvent.KEYCODE_BUTTON_R1 -> btnR1 = isDown
      KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_MENU -> btnMenu = isDown
      KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_BUTTON_THUMBL, KeyEvent.KEYCODE_BUTTON_THUMBR -> {
        btnStop = isDown
      }
      KeyEvent.KEYCODE_DPAD_LEFT -> if (isDown) rawDpadX = -1 else if (rawDpadX == -1) rawDpadX = 0
      KeyEvent.KEYCODE_DPAD_RIGHT -> if (isDown) rawDpadX = 1 else if (rawDpadX == 1) rawDpadX = 0
      KeyEvent.KEYCODE_DPAD_UP -> if (isDown) rawDpadY = 1 else if (rawDpadY == 1) rawDpadY = 0
      KeyEvent.KEYCODE_DPAD_DOWN -> if (isDown) rawDpadY = -1 else if (rawDpadY == -1) rawDpadY = 0
      else -> return false
    }

    updateState()
    return true
  }

  /**
   * Normalizes raw trigger reading (handles -1..1 or 0..1).
   */
  private fun normalizeTrigger(raw: Float): Float {
    return when {
      raw <= 0f -> 0f
      raw > 1f -> 1f
      else -> raw
    }
  }

  /**
   * Apply deadzone and response curves to raw analog axes.
   */
  private fun processAxis(raw: Float, deadzone: Float, curve: ResponseCurve): Float {
    val magnitude = abs(raw)
    if (magnitude <= deadzone) return 0f

    // Rescale from [deadzone..1.0] to [0.0..1.0]
    val normalized = (magnitude - deadzone) / (1f - deadzone)

    val curved = when (curve) {
      ResponseCurve.LINEAR -> normalized
      ResponseCurve.QUADRATIC -> normalized * normalized
      ResponseCurve.EXPO_SMOOTH -> normalized.pow(2.4f)
    }

    return sign(raw) * curved.coerceIn(0f, 1f)
  }

  private fun updateState() {
    val procLX = processAxis(rawLX, activeProfile.deadzoneLeft, activeProfile.responseCurve)
    val procLY = processAxis(rawLY, activeProfile.deadzoneLeft, activeProfile.responseCurve)
    val procRX = processAxis(rawRX, activeProfile.deadzoneRight, activeProfile.responseCurve)
    val procRY = processAxis(rawRY, activeProfile.deadzoneRight, activeProfile.responseCurve)

    // Evaluate deadman trigger with hysteresis
    if (!isDeadmanActive) {
      if (rawLT >= activeProfile.deadmanActivateThreshold) {
        isDeadmanActive = true
      }
    } else {
      if (rawLT <= activeProfile.deadmanReleaseThreshold) {
        isDeadmanActive = false
      }
    }

    // Evaluate neutral stick rearm safety interlock
    val isArmed = neutralRearmManager.evaluate(
      stickLX = procLX,
      stickLY = procLY,
      stickRX = procRX,
      stickRY = procRY,
      deadmanTrigger = rawLT
    )

    // Speed scale from right trigger (default 30% baseline, scales up to 100% when pressed)
    val speedScale = 15f + (rawRT * 85f)

    _inputState.value = _inputState.value.copy(
      leftStickX = procLX,
      leftStickY = procLY,
      rightStickX = procRX,
      rightStickY = procRY,
      leftTrigger = rawLT,
      rightTrigger = rawRT,
      dpadX = rawDpadX,
      dpadY = rawDpadY,
      buttonA = btnA,
      buttonB = btnB,
      buttonX = btnX,
      buttonY = btnY,
      bumperLeft = btnL1,
      bumperRight = btnR1,
      buttonMenu = btnMenu,
      buttonStop = btnStop,
      isDeadmanEngaged = isDeadmanActive,
      isNeutralRearmed = isArmed,
      speedScalePercent = speedScale
    )
  }

  override fun onInputDeviceAdded(deviceId: Int) {
    scanConnectedControllers()
    neutralRearmManager.requireRearm("New controller detected")
  }

  override fun onInputDeviceRemoved(deviceId: Int) {
    scanConnectedControllers()
    neutralRearmManager.requireRearm("Controller disconnected")
    isDeadmanActive = false
    rawLX = 0f; rawLY = 0f; rawRX = 0f; rawRY = 0f
    rawLT = 0f; rawRT = 0f
    updateState()
  }

  override fun onInputDeviceChanged(deviceId: Int) {
    scanConnectedControllers()
  }

  fun cleanup() {
    inputManager?.unregisterInputDeviceListener(this)
  }
}
