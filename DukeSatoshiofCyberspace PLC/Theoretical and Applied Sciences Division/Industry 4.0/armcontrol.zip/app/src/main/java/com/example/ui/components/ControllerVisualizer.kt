package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ControllerInputState
import com.example.ui.theme.AureomGoldPrimary
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.SafetyRed

@Composable
fun ControllerVisualizer(
  inputState: ControllerInputState,
  modifier: Modifier = Modifier
) {
  Surface(
    modifier = modifier.fillMaxWidth(),
    color = MaterialTheme.colorScheme.surfaceVariant,
    shape = RoundedCornerShape(12.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Header: Controller name and connection status
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = inputState.deviceName,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = if (inputState.isConnected) "Status: Online (Active HID)" else "Status: No Gamepad Detected (Touch Mode Available)",
            style = MaterialTheme.typography.bodySmall,
            color = if (inputState.isConnected) SafetyGreen else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Surface(
          color = if (inputState.isDeadmanEngaged) SafetyGreen.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface,
          shape = RoundedCornerShape(4.dp)
        ) {
          Text(
            text = if (inputState.isDeadmanEngaged) "LT DEADMAN: HELD" else "LT DEADMAN: RELEASED",
            color = if (inputState.isDeadmanEngaged) SafetyGreen else MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Trigger Bars (LT: Deadman, RT: Speed)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
      ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Left Trigger (Deadman)", style = MaterialTheme.typography.labelSmall)
            Text("${(inputState.leftTrigger * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = AureomGoldPrimary)
          }
          Spacer(modifier = Modifier.height(4.dp))
          LinearProgressIndicator(
            progress = { inputState.leftTrigger },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
            color = if (inputState.isDeadmanEngaged) SafetyGreen else AureomGoldPrimary,
            trackColor = MaterialTheme.colorScheme.surface
          )
        }

        Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Right Trigger (Speed)", style = MaterialTheme.typography.labelSmall)
            Text("${(inputState.rightTrigger * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = AureomGoldPrimary)
          }
          Spacer(modifier = Modifier.height(4.dp))
          LinearProgressIndicator(
            progress = { inputState.rightTrigger },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
            color = AureomGoldPrimary,
            trackColor = MaterialTheme.colorScheme.surface
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Sticks & Face Buttons Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Left Analog Stick
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("Left Stick (X/Y)", style = MaterialTheme.typography.labelSmall)
          Spacer(modifier = Modifier.height(6.dp))
          AnalogStickDial(x = inputState.leftStickX, y = inputState.leftStickY)
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "X: %.2f Y: %.2f".format(inputState.leftStickX, inputState.leftStickY),
            style = MaterialTheme.typography.bodySmall,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        // D-Pad and Center buttons (Back / Start / Stop)
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("Controls & D-Pad", style = MaterialTheme.typography.labelSmall)
          Spacer(modifier = Modifier.height(6.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ButtonBadge("STOP", isPressed = inputState.buttonStop, activeColor = SafetyRed)
            ButtonBadge("MENU", isPressed = inputState.buttonMenu)
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "D-PAD: X=${inputState.dpadX} Y=${inputState.dpadY}",
            style = MaterialTheme.typography.labelSmall,
            color = if (inputState.dpadX != 0 || inputState.dpadY != 0) AureomGoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        // Right Analog Stick
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("Right Stick (Z/Yaw)", style = MaterialTheme.typography.labelSmall)
          Spacer(modifier = Modifier.height(6.dp))
          AnalogStickDial(x = inputState.rightStickX, y = inputState.rightStickY)
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Z: %.2f Yaw: %.2f".format(inputState.rightStickY, inputState.rightStickX),
            style = MaterialTheme.typography.bodySmall,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        // Face Buttons (A, B, X, Y)
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("Face Buttons", style = MaterialTheme.typography.labelSmall)
          Spacer(modifier = Modifier.height(6.dp))
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            ButtonBadge("Y (Frame)", isPressed = inputState.buttonY)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              ButtonBadge("X", isPressed = inputState.buttonX)
              ButtonBadge("B (Open)", isPressed = inputState.buttonB)
            }
            ButtonBadge("A (Close)", isPressed = inputState.buttonA, activeColor = AureomGoldPrimary)
          }
        }
      }
    }
  }
}

@Composable
private fun AnalogStickDial(
  x: Float,
  y: Float,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .size(70.dp)
      .clip(CircleShape)
      .background(MaterialTheme.colorScheme.surface)
  ) {
    Canvas(modifier = Modifier.fillMaxWidth().height(70.dp)) {
      val center = Offset(size.width * 0.5f, size.height * 0.5f)
      val radius = size.minDimension * 0.44f

      // Perimeter circle
      drawCircle(Color(0xFF3C414D), radius = radius, center = center, style = Stroke(2f))

      // Crosshairs
      drawLine(Color(0xFF3C414D), Offset(center.x - radius, center.y), Offset(center.x + radius, center.y), 1f)
      drawLine(Color(0xFF3C414D), Offset(center.x, center.y - radius), Offset(center.x, center.y + radius), 1f)

      // Active thumb position
      val thumbPos = Offset(
        x = center.x + (x * radius * 0.85f),
        y = center.y - (y * radius * 0.85f) // Invert Y for screen coordinates
      )
      drawCircle(AureomGoldPrimary, radius = 8f, center = thumbPos)
      drawCircle(Color(0xFF201704), radius = 8f, center = thumbPos, style = Stroke(2f))
    }
  }
}

@Composable
private fun ButtonBadge(
  label: String,
  isPressed: Boolean,
  activeColor: Color = AureomGoldPrimary
) {
  Surface(
    color = if (isPressed) activeColor else MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(4.dp)
  ) {
    Text(
      text = label,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      color = if (isPressed) Color(0xFF140F03) else MaterialTheme.colorScheme.onSurfaceVariant,
      modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
    )
  }
}
