package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.adapter.InternalSimulationAdapter
import com.example.adapter.RobotAdapter
import com.example.adapter.SimulatedFault
import com.example.adapter.WebSocketRobotAdapter
import com.example.controller.ControllerManager
import com.example.data.AppDatabase
import com.example.data.RobotRepository
import com.example.kinematics.RobotKinematics
import com.example.model.CartesianVelocity
import com.example.model.ControlMode
import com.example.model.ControlState
import com.example.model.CoordinateFrame
import com.example.model.GripperIntent
import com.example.model.MotionIntent
import com.example.model.PathValidationResult
import com.example.model.Pose3D
import com.example.model.RobotState
import com.example.model.StopRequest
import com.example.model.TeachJob
import com.example.model.TeachWaypoint
import com.example.model.UnitSystem
import com.example.model.ValidationIssue
import com.example.model.ValidationSeverity
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class AppScreen(val label: String) {
  CONNECT("Connect"),
  OPERATE("Operate"),
  TEACH("Teach"),
  JOBS("Jobs"),
  DIAGNOSTICS("Diagnostics")
}

data class DiagnosticLog(
  val timestamp: Long = System.currentTimeMillis(),
  val formattedTime: String = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(timestamp)),
  val level: String, // INFO, WARN, ERROR, SAFETY
  val tag: String,
  val message: String
)

data class JobPlaybackState(
  val isRunning: Boolean = false,
  val isPaused: Boolean = false,
  val activeJobTitle: String? = null,
  val currentWaypointIndex: Int = 0,
  val totalWaypoints: Int = 0,
  val progressPercent: Float = 0f,
  val speedMultiplier: Float = 1.0f,
  val loop: Boolean = false
)

class ArmControlViewModel(application: Application) : AndroidViewModel(application) {

  val controllerManager = ControllerManager(application.applicationContext)

  private val database = AppDatabase.getDatabase(application.applicationContext)
  val repository = RobotRepository(database.teachJobDao(), database.controllerProfileDao())

  // Adapters
  val internalSimAdapter = InternalSimulationAdapter(viewModelScope)
  val webSocketAdapter = WebSocketRobotAdapter(viewModelScope)
  private var activeAdapter: RobotAdapter = internalSimAdapter

  private val _isUsingWebSocket = MutableStateFlow(false)
  val isUsingWebSocket: StateFlow<Boolean> = _isUsingWebSocket.asStateFlow()

  val robotState: StateFlow<RobotState> = internalSimAdapter.observeTelemetry()
  val controllerInput = controllerManager.inputState

  // Navigation
  private val _currentScreen = MutableStateFlow(AppScreen.OPERATE)
  val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

  // Theme & Units
  private val _isDarkTheme = MutableStateFlow(true)
  val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

  private val _unitSystem = MutableStateFlow(UnitSystem.METRIC_MM_DEG)
  val unitSystem: StateFlow<UnitSystem> = _unitSystem.asStateFlow()

  // Touch jog overrides
  private var touchDeadman = false
  private var touchCartesianVel = CartesianVelocity()
  private var touchJointIndex = 0
  private var touchJointVel = 0f
  private var selectedJointIndex = 0

  // Motion Intent Sequencer
  private val sessionId = UUID.randomUUID().toString().take(8)
  private var sequenceCounter = 0L

  // Teach Pendant & Jobs
  val savedJobs: StateFlow<List<TeachJob>> = repository.allJobs
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), repository.getPrebuiltJobs())

  private val _currentTeachWaypoints = MutableStateFlow<List<TeachWaypoint>>(emptyList())
  val currentTeachWaypoints: StateFlow<List<TeachWaypoint>> = _currentTeachWaypoints.asStateFlow()

  private val _pathValidation = MutableStateFlow<PathValidationResult?>(null)
  val pathValidation: StateFlow<PathValidationResult?> = _pathValidation.asStateFlow()

  // Job Playback
  private val _playbackState = MutableStateFlow(JobPlaybackState())
  val playbackState: StateFlow<JobPlaybackState> = _playbackState.asStateFlow()
  private var playbackJob: Job? = null

  // Diagnostic Logs
  private val _logs = MutableStateFlow<List<DiagnosticLog>>(emptyList())
  val logs: StateFlow<List<DiagnosticLog>> = _logs.asStateFlow()

  init {
    addLog("INFO", "SYS", "Aureom.AI ArmControl initialized. Session ID: $sessionId")
    addLog("INFO", "ROBOT", "Demonstration 6-DOF simulator online and ready.")
    startMotionIntentLoop()
  }

  fun setScreen(screen: AppScreen) {
    if (_currentScreen.value != screen) {
      _currentScreen.value = screen
      controllerManager.requireNeutralRearm("Navigated to ${screen.label}")
      addLog("INFO", "NAV", "Switched view to ${screen.label}")
    }
  }

  fun toggleTheme() {
    _isDarkTheme.value = !_isDarkTheme.value
  }

  fun toggleUnitSystem() {
    _unitSystem.value = if (_unitSystem.value == UnitSystem.METRIC_MM_DEG) {
      UnitSystem.METRIC_M_RAD
    } else {
      UnitSystem.METRIC_MM_DEG
    }
  }

  fun switchToInternalSimulator() {
    viewModelScope.launch {
      activeAdapter.disconnect()
      activeAdapter = internalSimAdapter
      internalSimAdapter.connect()
      _isUsingWebSocket.value = false
      controllerManager.requireNeutralRearm("Switched to Built-in Simulator")
      addLog("INFO", "ADAPTER", "Active transport changed to Built-in Simulator")
    }
  }

  fun connectToWebSocketGateway(endpoint: String) {
    viewModelScope.launch {
      activeAdapter.disconnect()
      activeAdapter = webSocketAdapter
      val res = webSocketAdapter.connect(endpoint)
      _isUsingWebSocket.value = true
      if (res.isSuccess) {
        addLog("INFO", "ADAPTER", "Connected to WebSocket gateway at $endpoint")
      } else {
        addLog("ERROR", "ADAPTER", "Failed to connect to $endpoint: ${res.exceptionOrNull()?.message}")
      }
    }
  }

  // --- Manual Jogging & Motion Intent Generation ---

  private fun startMotionIntentLoop() {
    viewModelScope.launch {
      while (isActive) {
        val ctrl = controllerInput.value
        val state = robotState.value

        val isDeadmanActive = ctrl.isDeadmanEngaged || touchDeadman
        val isArmed = ctrl.isNeutralRearmed

        // Only generate motion commands if Deadman is engaged and system is rearmed
        if (isDeadmanActive && isArmed && state.controlState != ControlState.ESTOP && state.controlState != ControlState.FAULTED) {
          sequenceCounter++

          val speedScale = if (touchDeadman) state.requestedSpeedLimitPercent else ctrl.speedScalePercent

          val isCartesian = state.activeMode == ControlMode.CARTESIAN_JOG

          val intent = if (isCartesian) {
            // Determine Cartesian velocity from gamepad or touch
            val cartVel = if (touchDeadman && !touchCartesianVel.isZero) {
              touchCartesianVel
            } else {
              val vx = ctrl.leftStickX * RobotKinematics.MAX_CARTESIAN_LINEAR_VEL_MM_S
              val vy = ctrl.leftStickY * RobotKinematics.MAX_CARTESIAN_LINEAR_VEL_MM_S

              val vz = if (!controllerManager.isOrientationJogMode) {
                ctrl.rightStickY * RobotKinematics.MAX_CARTESIAN_LINEAR_VEL_MM_S
              } else 0f

              val wz = if (!controllerManager.isOrientationJogMode) {
                ctrl.rightStickX * RobotKinematics.MAX_CARTESIAN_ANGULAR_VEL_DEG_S
              } else {
                ctrl.rightStickX * RobotKinematics.MAX_CARTESIAN_ANGULAR_VEL_DEG_S
              }

              val wy = if (controllerManager.isOrientationJogMode) {
                ctrl.rightStickY * RobotKinematics.MAX_CARTESIAN_ANGULAR_VEL_DEG_S
              } else 0f

              CartesianVelocity(vx = vx, vy = vy, vz = vz, wx = 0f, wy = wy, wz = wz)
            }

            MotionIntent(
              sessionId = sessionId,
              sequenceNumber = sequenceCounter,
              controlMode = ControlMode.CARTESIAN_JOG,
              coordinateFrame = state.activeFrame,
              speedScalePercent = speedScale,
              cartesianVelocity = cartVel,
              enableState = true
            )
          } else {
            // Joint Jogging
            val jointVels = FloatArray(6) { 0f }
            if (touchDeadman && touchJointVel != 0f) {
              jointVels[touchJointIndex] = touchJointVel
            } else {
              // Left stick Y jogs selected joint
              val jogVel = ctrl.leftStickY * RobotKinematics.JOINT_MAX_VELOCITY[selectedJointIndex]
              jointVels[selectedJointIndex] = jogVel
            }

            MotionIntent(
              sessionId = sessionId,
              sequenceNumber = sequenceCounter,
              controlMode = ControlMode.JOINT_JOG,
              coordinateFrame = state.activeFrame,
              speedScalePercent = speedScale,
              jointVelocitiesDegPerSec = jointVels,
              enableState = true
            )
          }

          activeAdapter.sendMotionIntent(intent)
        } else {
          // Deadman released: if robot was moving, send zero-speed intent with enable=false
          if (state.controlState == ControlState.MOVING) {
            sequenceCounter++
            activeAdapter.sendMotionIntent(
              MotionIntent(
                sessionId = sessionId,
                sequenceNumber = sequenceCounter,
                controlMode = state.activeMode,
                coordinateFrame = state.activeFrame,
                speedScalePercent = 0f,
                enableState = false
              )
            )
          }
        }

        // Handle gamepad gripper buttons
        if (ctrl.buttonA) {
          activeAdapter.sendGripperIntent(GripperIntent(sessionId = sessionId, closeRequest = true, targetPosition = 1f))
        } else if (ctrl.buttonB) {
          activeAdapter.sendGripperIntent(GripperIntent(sessionId = sessionId, closeRequest = false, targetPosition = 0f))
        }

        // Handle dedicated stop button
        if (ctrl.buttonStop) {
          requestControlledStop("Gamepad Stop Button Pressed")
        }

        delay(30) // 33 Hz command rate
      }
    }
  }

  // --- Touch Jog API ---

  fun setTouchDeadman(held: Boolean) {
    touchDeadman = held
    if (!held) {
      touchCartesianVel = CartesianVelocity()
      touchJointVel = 0f
    }
  }

  fun setTouchCartesianVelocity(vel: CartesianVelocity) {
    touchCartesianVel = vel
  }

  fun setTouchJointJog(jointIndex: Int, velocityDegS: Float) {
    touchJointIndex = jointIndex
    touchJointVel = velocityDegS
  }

  fun setSelectedJointIndex(index: Int) {
    selectedJointIndex = index.coerceIn(0, 5)
  }

  fun setControlMode(mode: ControlMode) {
    controllerManager.requireNeutralRearm("Control mode changed to ${mode.label}")
    addLog("INFO", "MODE", "Active control mode changed to ${mode.label}")
  }

  fun setCoordinateFrame(frame: CoordinateFrame) {
    controllerManager.requireNeutralRearm("Coordinate frame changed to ${frame.name}")
    addLog("INFO", "FRAME", "Coordinate frame changed to ${frame.name}")
  }

  fun toggleGripper(close: Boolean) {
    activeAdapter.sendGripperIntent(
      GripperIntent(sessionId = sessionId, closeRequest = close, targetPosition = if (close) 1.0f else 0.0f)
    )
    addLog("INFO", "TOOL", if (close) "Commanded Gripper CLOSE" else "Commanded Gripper OPEN")
  }

  fun requestControlledStop(reason: String = "Operator Stop") {
    activeAdapter.sendStopRequest(StopRequest(sessionId = sessionId, isEmergency = false, reason = reason))
    controllerManager.requireNeutralRearm("Controlled Stop: $reason")
    addLog("WARN", "SAFETY", "Controlled stop executed: $reason")
  }

  fun triggerEmergencyStop() {
    activeAdapter.sendStopRequest(StopRequest(sessionId = sessionId, isEmergency = true, reason = "Emergency Stop Actuator"))
    controllerManager.requireNeutralRearm("Emergency Stop Triggered")
    addLog("SAFETY", "SAFETY", "EMERGENCY STOP ENGAGED! Hardware motion circuits open.")
  }

  fun clearFault() {
    activeAdapter.clearFault()
    controllerManager.requireNeutralRearm("Fault cleared by operator")
    addLog("INFO", "SAFETY", "Fault interlock cleared. System armed.")
  }

  fun injectSimulatedFault(fault: SimulatedFault) {
    activeAdapter.injectFault(fault)
    addLog("WARN", "DIAG", "Simulated fault injected: ${fault.label}")
  }

  fun resetSimulation() {
    activeAdapter.resetSimulation(homePose = true)
    controllerManager.requireNeutralRearm("Simulation reset to home")
    addLog("INFO", "SIM", "Demonstration manipulator reset to calibrated home pose.")
  }

  // --- Teach Pendant & Trajectory Validation ---

  fun recordCurrentPoseAsWaypoint(name: String) {
    val state = robotState.value
    val wp = TeachWaypoint(
      name = name.ifBlank { "Waypoint ${_currentTeachWaypoints.value.size + 1}" },
      jointPositionsDeg = state.jointPositionsDeg.toList(),
      toolPose = state.toolPose,
      gripperClosed = state.gripperPosition > 0.5f,
      dwellSeconds = 0.5f,
      speedPercent = 30f
    )
    _currentTeachWaypoints.value = _currentTeachWaypoints.value + wp
    validateCurrentPath()
    addLog("INFO", "TEACH", "Recorded waypoint '${wp.name}' at TCP: ${state.toolPose.formatted()}")
  }

  fun removeWaypoint(id: String) {
    _currentTeachWaypoints.value = _currentTeachWaypoints.value.filter { it.id != id }
    validateCurrentPath()
  }

  fun reorderWaypoints(fromIndex: Int, toIndex: Int) {
    val list = _currentTeachWaypoints.value.toMutableList()
    if (fromIndex in list.indices && toIndex in list.indices) {
      val item = list.removeAt(fromIndex)
      list.add(toIndex, item)
      _currentTeachWaypoints.value = list
      validateCurrentPath()
    }
  }

  fun validateCurrentPath() {
    val wps = _currentTeachWaypoints.value
    if (wps.size < 2) {
      _pathValidation.value = PathValidationResult(
        isExecutable = true,
        totalWaypoints = wps.size,
        validSegments = wps.size,
        invalidSegments = 0,
        estimatedDurationSeconds = wps.size * 1.5f
      )
      return
    }

    val issues = mutableListOf<ValidationIssue>()
    var invalidCount = 0

    for (i in 0 until wps.size - 1) {
      val start = wps[i]
      val end = wps[i + 1]

      // Check joint limits on endpoints
      for (j in 0..5) {
        val qVal = end.jointPositionsDeg[j]
        if (qVal < RobotKinematics.JOINT_LIMITS_MIN[j] || qVal > RobotKinematics.JOINT_LIMITS_MAX[j]) {
          issues.add(
            ValidationIssue(
              waypointIndex = i + 1,
              segmentName = "${start.name} -> ${end.name}",
              message = "Joint J${j + 1} position %.1f° violates limit".format(qVal),
              severity = ValidationSeverity.CRITICAL
            )
          )
          invalidCount++
        }
      }

      // Check intermediate Cartesian distance & reachability
      val dx = end.toolPose.x - start.toolPose.x
      val dy = end.toolPose.y - start.toolPose.y
      val dz = end.toolPose.z - start.toolPose.z
      val dist = kotlin.math.sqrt(dx * dx + dy * dy + dz * dz)

      if (dist > 500f) {
        issues.add(
          ValidationIssue(
            waypointIndex = i + 1,
            segmentName = "${start.name} -> ${end.name}",
            message = "Large Cartesian displacement (%.0f mm). Insert intermediate blend point.".format(dist),
            severity = ValidationSeverity.WARNING
          )
        )
      }
    }

    _pathValidation.value = PathValidationResult(
      isExecutable = invalidCount == 0,
      totalWaypoints = wps.size,
      validSegments = (wps.size - 1) - invalidCount,
      invalidSegments = invalidCount,
      estimatedDurationSeconds = wps.sumOf { (it.dwellSeconds + 1.2).toDouble() }.toFloat(),
      issues = issues
    )
  }

  fun saveCurrentTeachJob(title: String, description: String) {
    val job = TeachJob(
      title = title.ifBlank { "Taught Routine ${SimpleDateFormat("MM-dd HH:mm", Locale.US).format(Date())}" },
      description = description.ifBlank { "User taught sequence with ${_currentTeachWaypoints.value.size} steps" },
      waypoints = _currentTeachWaypoints.value
    )
    viewModelScope.launch {
      repository.saveJob(job)
      addLog("INFO", "TEACH", "Saved job '${job.title}' with ${job.waypoints.size} waypoints to database.")
    }
  }

  // --- Job Playback Simulator ---

  fun startJobPlayback(job: TeachJob) {
    playbackJob?.cancel()
    if (job.waypoints.isEmpty()) return

    _playbackState.value = JobPlaybackState(
      isRunning = true,
      isPaused = false,
      activeJobTitle = job.title,
      currentWaypointIndex = 0,
      totalWaypoints = job.waypoints.size
    )

    addLog("INFO", "PLAYBACK", "Commenced simulation playback for '${job.title}'")

    playbackJob = viewModelScope.launch {
      var stepIdx = 0
      while (isActive && stepIdx < job.waypoints.size) {
        _playbackState.value = _playbackState.value.copy(
          currentWaypointIndex = stepIdx,
          progressPercent = (stepIdx + 1).toFloat() / job.waypoints.size
        )

        val targetWp = job.waypoints[stepIdx]

        // Smoothly interpolate to target joint angles over 1.2 seconds
        val startJoints = robotState.value.jointPositionsDeg.clone()
        val targetJoints = targetWp.jointPositionsDeg.toFloatArray()

        val steps = 30
        for (s in 1..steps) {
          if (!isActive) break
          while (_playbackState.value.isPaused) {
            delay(100)
          }

          val frac = s.toFloat() / steps
          val currentInterp = FloatArray(6) { j ->
            startJoints[j] + (targetJoints[j] - startJoints[j]) * frac
          }

          // Calculate synthetic joint velocities
          val vels = FloatArray(6) { j -> (targetJoints[j] - startJoints[j]) * 1.5f }

          sequenceCounter++
          activeAdapter.sendMotionIntent(
            MotionIntent(
              sessionId = sessionId,
              sequenceNumber = sequenceCounter,
              controlMode = ControlMode.JOINT_JOG,
              coordinateFrame = CoordinateFrame.BASE,
              speedScalePercent = targetWp.speedPercent,
              jointVelocitiesDegPerSec = vels,
              enableState = true
            )
          )
          delay(40)
        }

        // Actuate gripper
        activeAdapter.sendGripperIntent(
          GripperIntent(sessionId = sessionId, closeRequest = targetWp.gripperClosed, targetPosition = if (targetWp.gripperClosed) 1f else 0f)
        )

        // Dwell
        delay((targetWp.dwellSeconds * 1000).toLong())

        stepIdx++
        if (stepIdx >= job.waypoints.size && _playbackState.value.loop) {
          stepIdx = 0
        }
      }

      _playbackState.value = _playbackState.value.copy(isRunning = false, progressPercent = 1.0f)
      addLog("INFO", "PLAYBACK", "Job playback completed successfully.")
    }
  }

  fun pausePlayback() {
    _playbackState.value = _playbackState.value.copy(isPaused = !_playbackState.value.isPaused)
  }

  fun stopPlayback() {
    playbackJob?.cancel()
    _playbackState.value = _playbackState.value.copy(isRunning = false, isPaused = false)
    requestControlledStop("Job Playback Halted")
  }

  // --- Diagnostics Log ---

  private fun addLog(level: String, tag: String, message: String) {
    val newLog = DiagnosticLog(level = level, tag = tag, message = message)
    val current = _logs.value.toMutableList()
    if (current.size > 200) current.removeAt(0)
    current.add(newLog)
    _logs.value = current
  }

  override fun onCleared() {
    super.onCleared()
    controllerManager.cleanup()
  }
}
