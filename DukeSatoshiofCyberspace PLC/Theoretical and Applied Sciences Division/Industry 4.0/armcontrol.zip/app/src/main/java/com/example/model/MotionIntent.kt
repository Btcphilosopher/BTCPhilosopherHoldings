package com.example.model

/**
 * Bounded motion intent message sent from the Android operator interface
 * to the robot controller or gateway.
 *
 * Implements strict sequencing, TTL, speed bounds, and explicit deadman enable state.
 */
data class MotionIntent(
  val sessionId: String,
  val sequenceNumber: Long,
  val timestamp: Long = System.currentTimeMillis(),
  val ttlMs: Long = 150L,
  val controlMode: ControlMode,
  val coordinateFrame: CoordinateFrame,
  val speedScalePercent: Float,
  val jointVelocitiesDegPerSec: FloatArray? = null,
  val cartesianVelocity: CartesianVelocity? = null,
  val enableState: Boolean,
  val robotProfileVersion: String = "Aureom-6DOF-v1.0"
) {
  val isExpired: Boolean
    get() = (System.currentTimeMillis() - timestamp) > ttlMs

  override fun equals(other: Any?): Boolean {
    if (this === other) return true
    if (javaClass != other?.javaClass) return false
    other as MotionIntent
    return sessionId == other.sessionId &&
        sequenceNumber == other.sequenceNumber &&
        timestamp == other.timestamp &&
        ttlMs == other.ttlMs &&
        controlMode == other.controlMode &&
        coordinateFrame == other.coordinateFrame &&
        speedScalePercent == other.speedScalePercent &&
        enableState == other.enableState &&
        (jointVelocitiesDegPerSec?.contentEquals(other.jointVelocitiesDegPerSec ?: FloatArray(0)) ?: (other.jointVelocitiesDegPerSec == null)) &&
        cartesianVelocity == other.cartesianVelocity
  }

  override fun hashCode(): Int {
    var result = sessionId.hashCode()
    result = 31 * result + sequenceNumber.hashCode()
    result = 31 * result + timestamp.hashCode()
    result = 31 * result + enableState.hashCode()
    return result
  }
}

/**
 * Request to actuate the tool end-effector.
 */
data class GripperIntent(
  val sessionId: String,
  val timestamp: Long = System.currentTimeMillis(),
  val closeRequest: Boolean,
  val targetPosition: Float // 0.0 = fully open, 1.0 = fully closed
)

/**
 * Request for controlled stop or emergency stop.
 */
data class StopRequest(
  val sessionId: String,
  val timestamp: Long = System.currentTimeMillis(),
  val isEmergency: Boolean = false,
  val reason: String = "Operator Requested Stop"
)
