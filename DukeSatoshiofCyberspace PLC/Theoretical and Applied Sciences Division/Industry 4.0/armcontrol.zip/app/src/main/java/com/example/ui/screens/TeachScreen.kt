package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TeachJob
import com.example.model.TeachWaypoint
import com.example.ui.theme.AureomGoldPrimary
import com.example.ui.theme.SafetyAmber
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.SafetyRed
import com.example.viewmodel.AppScreen
import com.example.viewmodel.ArmControlViewModel

@Composable
fun TeachScreen(
  viewModel: ArmControlViewModel,
  modifier: Modifier = Modifier
) {
  val waypoints by viewModel.currentTeachWaypoints.collectAsState()
  val robotState by viewModel.robotState.collectAsState()
  val pathValidation by viewModel.pathValidation.collectAsState()

  var showSaveDialog by remember { mutableStateOf(false) }
  var newWaypointName by remember { mutableStateOf("") }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Top Action Bar: Record Pose, Save Routine, Path Validation Badge
    Card(
      modifier = Modifier.fillMaxWidth(),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      shape = RoundedCornerShape(12.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "TEACH PENDANT ROUTINE RECORDER",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Jog arm to desired pose and capture waypoints into sequence",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = {
              viewModel.recordCurrentPoseAsWaypoint("Waypoint ${waypoints.size + 1}")
            },
            colors = ButtonDefaults.buttonColors(
              containerColor = AureomGoldPrimary,
              contentColor = Color(0xFF191202)
            ),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.testTag("record_pose_btn")
          ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Record Current Pose", fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }

          Button(
            onClick = { showSaveDialog = true },
            enabled = waypoints.isNotEmpty(),
            colors = ButtonDefaults.buttonColors(
              containerColor = MaterialTheme.colorScheme.surfaceVariant,
              contentColor = MaterialTheme.colorScheme.onSurface
            ),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.testTag("save_job_btn")
          ) {
            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Save as Job", fontSize = 12.sp)
          }
        }
      }
    }

    // Path Validation Summary Banner
    pathValidation?.let { valResult ->
      Surface(
        color = if (valResult.isExecutable) Color(0xFF0F2618) else Color(0xFF381515),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = if (valResult.isExecutable) Icons.Default.CheckCircle else Icons.Default.Warning,
              contentDescription = null,
              tint = if (valResult.isExecutable) SafetyGreen else SafetyRed,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (valResult.isExecutable) "Trajectory Path Validated (${valResult.validSegments} Segments Feasible)"
                else "Trajectory Validation Alert (${valResult.invalidSegments} Invalid Segment)",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium,
                color = if (valResult.isExecutable) SafetyGreen else SafetyRed
              )
              Text(
                text = "Estimated execution time: %.1fs | %d total waypoints".format(
                  valResult.estimatedDurationSeconds,
                  valResult.totalWaypoints
                ),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          if (valResult.isExecutable && waypoints.isNotEmpty()) {
            Button(
              onClick = {
                val tempJob = TeachJob(
                  title = "Live Routine Preview",
                  description = "Simulation playback of taught waypoints",
                  waypoints = waypoints
                )
                viewModel.startJobPlayback(tempJob)
                viewModel.setScreen(AppScreen.JOBS)
              },
              colors = ButtonDefaults.buttonColors(
                containerColor = AureomGoldPrimary,
                contentColor = Color(0xFF1B1403)
              ),
              shape = RoundedCornerShape(4.dp)
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Run in Simulation", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
          }
        }
      }
    }

    // List of Recorded Waypoints
    if (waypoints.isEmpty()) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = "No Waypoints Recorded Yet",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Use the gamepad or touch jog pad to position the arm, then tap 'Record Current Pose'.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        itemsIndexed(waypoints) { index, wp ->
          WaypointCard(
            stepNumber = index + 1,
            waypoint = wp,
            onMoveUp = if (index > 0) { { viewModel.reorderWaypoints(index, index - 1) } } else null,
            onMoveDown = if (index < waypoints.size - 1) { { viewModel.reorderWaypoints(index, index + 1) } } else null,
            onDelete = { viewModel.removeWaypoint(wp.id) }
          )
        }
      }
    }
  }

  // Save Job Dialog
  if (showSaveDialog) {
    var title by remember { mutableStateOf("Taught Sequence ${waypoints.size} Poses") }
    var description by remember { mutableStateOf("Validated 6-DOF pick-and-place routine") }

    AlertDialog(
      onDismissRequest = { showSaveDialog = false },
      title = { Text("Save Teach Routine to Job Library") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Job Title") },
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Description") },
            modifier = Modifier.fillMaxWidth()
          )
          Text(
            text = "Contains ${waypoints.size} waypoints with confirmed kinematic configurations.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.saveCurrentTeachJob(title, description)
            showSaveDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = AureomGoldPrimary, contentColor = Color(0xFF191202))
        ) {
          Text("Save Routine", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showSaveDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }
}

@Composable
private fun WaypointCard(
  stepNumber: Int,
  waypoint: TeachWaypoint,
  onMoveUp: (() -> Unit)?,
  onMoveDown: (() -> Unit)?,
  onDelete: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    shape = RoundedCornerShape(8.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          color = AureomGoldPrimary,
          shape = RoundedCornerShape(4.dp)
        ) {
          Text(
            text = "#$stepNumber",
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = Color(0xFF191202),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
          Text(
            text = waypoint.name,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
          val pose = waypoint.toolPose
          Text(
            text = "TCP: X=%.0f Y=%.0f Z=%.0f | R=%.0f° P=%.0f° Y=%.0f°".format(
              pose.x, pose.y, pose.z, pose.roll, pose.pitch, pose.yaw
            ),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "Gripper: ${if (waypoint.gripperClosed) "CLOSE" else "OPEN"}",
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              color = if (waypoint.gripperClosed) AureomGoldPrimary else SafetyGreen
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "• Dwell: %.1fs • Speed: %.0f%%".format(waypoint.dwellSeconds, waypoint.speedPercent),
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      // Reorder and delete actions
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = { onMoveUp?.invoke() },
          enabled = onMoveUp != null
        ) {
          Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up", modifier = Modifier.size(18.dp))
        }
        IconButton(
          onClick = { onMoveDown?.invoke() },
          enabled = onMoveDown != null
        ) {
          Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down", modifier = Modifier.size(18.dp))
        }
        IconButton(onClick = onDelete) {
          Icon(Icons.Default.Delete, contentDescription = "Delete", tint = SafetyRed, modifier = Modifier.size(18.dp))
        }
      }
    }
  }
}
