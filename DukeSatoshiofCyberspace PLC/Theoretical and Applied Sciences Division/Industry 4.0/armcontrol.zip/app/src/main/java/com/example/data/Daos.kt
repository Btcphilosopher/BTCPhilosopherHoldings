package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TeachJobDao {
  @Query("SELECT * FROM teach_jobs ORDER BY createdAt DESC")
  fun getAllJobs(): Flow<List<TeachJobEntity>>

  @Query("SELECT * FROM teach_jobs WHERE id = :id LIMIT 1")
  suspend fun getJobById(id: String): TeachJobEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertJob(job: TeachJobEntity)

  @Query("DELETE FROM teach_jobs WHERE id = :id")
  suspend fun deleteJobById(id: String)
}

@Dao
interface ControllerProfileDao {
  @Query("SELECT * FROM controller_profiles")
  fun getAllProfiles(): Flow<List<ControllerProfileEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProfile(profile: ControllerProfileEntity)

  @Query("DELETE FROM controller_profiles WHERE id = :id")
  suspend fun deleteProfileById(id: String)
}
