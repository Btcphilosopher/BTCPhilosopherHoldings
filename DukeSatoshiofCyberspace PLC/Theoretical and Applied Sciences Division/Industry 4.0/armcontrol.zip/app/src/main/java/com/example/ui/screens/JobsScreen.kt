package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TeachJob
import com.example.ui.theme.AureomGoldPrimary
import com.example.ui.theme.SafetyAmber
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.SafetyRed
import com.example.viewmodel.AppScreen
import com.example.viewmodel.ArmControlViewModel

@Composable
fun JobsScreen(
  viewModel: ArmControlViewModel,
  modifier: Modifier = Modifier
) {
  val savedJobs by viewModel.savedJobs.collectAsState()
  val playbackState by viewModel.playbackState.collectAsState()
  var selectedJob by remember { mutableStateOf<TeachJob?>(null) }
  var showExportDialog by remember { mutableStateOf(false) }
  var showRealExecuteWarning by remember { mutableStateOf(false) }

  // Select initial job if none selected
  if (selectedJob == null && savedJobs.isNotEmpty()) {
    selectedJob = savedJobs.first()
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Top Active Playback Control Deck
    Card(
      modifier = Modifier.fillMaxWidth(),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      shape = RoundedCornerShape(12.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "TRAJECTORY PLAYBACK DECK",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = if (playbackState.isRunning) {
                "Active Job: ${playbackState.activeJobTitle ?: "Executing"} • Step ${playbackState.currentWaypointIndex + 1} of ${playbackState.totalWaypoints}"
              } else {
                "Ready for simulation playback • Select a job from the library below"
              },
              style = MaterialTheme.typography.bodySmall,
              color = if (playbackState.isRunning) AureomGoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          // Execution Mode Badges
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Surface(
              color = SafetyGreen.copy(alpha = 0.15f),
              shape = RoundedCornerShape(4.dp)
            ) {
              Text(
                text = "SIMULATION VALIDATED",
                color = SafetyGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
              )
            }
            Surface(
              color = SafetyAmber.copy(alpha = 0.15f),
              shape = RoundedCornerShape(4.dp)
            ) {
              Text(
                text = "REAL EXECUTION GATED",
                color = SafetyAmber,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Progress bar
        LinearProgressIndicator(
          progress = { playbackState.progressPercent },
          modifier = Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp)),
          color = AureomGoldPrimary,
          trackColor = MaterialTheme.colorScheme.surfaceVariant
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Playback Action Controls
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // Play / Resume
            Button(
              onClick = {
                selectedJob?.let { job ->
                  viewModel.startJobPlayback(job)
                  viewModel.setScreen(AppScreen.OPERATE)
                }
              },
              colors = ButtonDefaults.buttonColors(
                containerColor = AureomGoldPrimary,
                contentColor = Color(0xFF191202)
              ),
              shape = RoundedCornerShape(6.dp),
              modifier = Modifier.testTag("play_job_btn")
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Run in Simulation", fontWeight = FontWeight.Bold)
            }

            // Pause
            Button(
              onClick = { viewModel.pausePlayback() },
              enabled = playbackState.isRunning,
              colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = MaterialTheme.colorScheme.onSurface
              ),
              shape = RoundedCornerShape(6.dp)
            ) {
              Icon(Icons.Default.Pause, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(if (playbackState.isPaused) "Resume" else "Pause")
            }

            // Stop
            Button(
              onClick = { viewModel.stopPlayback() },
              enabled = playbackState.isRunning,
              colors = ButtonDefaults.buttonColors(
                containerColor = SafetyRed.copy(alpha = 0.2f),
                contentColor = SafetyRed
              ),
              shape = RoundedCornerShape(6.dp)
            ) {
              Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Stop")
            }
          }

          // Real Robot Execution Interlock Button
          OutlinedButton(
            onClick = { showRealExecuteWarning = true },
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.testTag("real_execution_gated_btn")
          ) {
            Icon(Icons.Default.Security, contentDescription = null, tint = SafetyAmber, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Real Robot Execution", color = SafetyAmber, fontSize = 12.sp)
          }
        }
      }
    }

    // Split View: Saved Jobs Library (Left) and Step Inspector (Right)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f),
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Left: Jobs Library
      Card(
        modifier = Modifier
          .weight(0.45f)
          .fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "SAVED ROUTINES",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
            IconButton(onClick = { showExportDialog = true }) {
              Icon(
                imageVector = Icons.Default.FileUpload,
                contentDescription = "Export JSON",
                tint = AureomGoldPrimary,
                modifier = Modifier.size(18.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
          ) {
            items(savedJobs) { job ->
              val isSelected = selectedJob?.id == job.id
              Surface(
                onClick = { selectedJob = job },
                color = if (isSelected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(
                      text = job.title,
                      fontWeight = FontWeight.Bold,
                      fontSize = 13.sp,
                      color = if (isSelected) AureomGoldPrimary else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                      text = "${job.waypoints.size} steps",
                      fontSize = 11.sp,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(
                    text = job.description,
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2
                  )
                }
              }
            }
          }
        }
      }

      // Right: Step Inspector of selected job
      Card(
        modifier = Modifier
          .weight(0.55f)
          .fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        selectedJob?.let { job ->
          Column(modifier = Modifier.padding(14.dp)) {
            Text(
              text = "JOB STEPS: ${job.title.uppercase()}",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = AureomGoldPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
              verticalArrangement = Arrangement.spacedBy(6.dp),
              modifier = Modifier.fillMaxSize()
            ) {
              items(job.waypoints) { wp ->
                Surface(
                  color = MaterialTheme.colorScheme.surfaceVariant,
                  shape = RoundedCornerShape(6.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column {
                      Text(wp.name, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                      Text(
                        "TCP: X=%.0f Y=%.0f Z=%.0f".format(wp.toolPose.x, wp.toolPose.y, wp.toolPose.z),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                      Text(
                        text = if (wp.gripperClosed) "GRIP: CLOSE" else "GRIP: OPEN",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (wp.gripperClosed) AureomGoldPrimary else SafetyGreen
                      )
                      Text("Dwell: %.1fs".format(wp.dwellSeconds), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                  }
                }
              }
            }
          }
        } ?: Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier.fillMaxSize()
        ) {
          Text("Select a job to view sequence steps", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    }
  }

  // Real Execution Safety Warning Dialog
  if (showRealExecuteWarning) {
    AlertDialog(
      onDismissRequest = { showRealExecuteWarning = false },
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Security, contentDescription = null, tint = SafetyAmber)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Real Robot Execution Safeguard")
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            "Direct trajectory execution on physical industrial arms requires certified protective boundaries, physical safety relays, and a hardware-validated robot controller.",
            style = MaterialTheme.typography.bodyMedium
          )
          Text(
            "The connected backend must explicitly report EXECUTION_CAPABILITY_VALIDATED to allow arming physical servos.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            "Please use the Simulator Playback mode to verify all trajectories, singularities, and obstacle clearances safely.",
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = AureomGoldPrimary
          )
        }
      },
      confirmButton = {
        Button(
          onClick = { showRealExecuteWarning = false },
          colors = ButtonDefaults.buttonColors(containerColor = AureomGoldPrimary, contentColor = Color(0xFF191202))
        ) {
          Text("Understood")
        }
      }
    )
  }

  // Export JSON Dialog
  if (showExportDialog) {
    AlertDialog(
      onDismissRequest = { showExportDialog = false },
      title = { Text("Export Job Routine (JSON)") },
      text = {
        Column {
          Text(
            "Standard ISO/Aureom v1.2 Kinematic Routine JSON schema format:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = """
            {
              "jobId": "${selectedJob?.id}",
              "title": "${selectedJob?.title}",
              "profile": "Aureom-6DOF-v1.0",
              "waypointsCount": ${selectedJob?.waypoints?.size ?: 0},
              "status": "VALIDATED"
            }
            """.trimIndent(),
            onValueChange = {},
            readOnly = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = { showExportDialog = false },
          colors = ButtonDefaults.buttonColors(containerColor = AureomGoldPrimary, contentColor = Color(0xFF191202))
        ) {
          Text("Close")
        }
      }
    )
  }
}
