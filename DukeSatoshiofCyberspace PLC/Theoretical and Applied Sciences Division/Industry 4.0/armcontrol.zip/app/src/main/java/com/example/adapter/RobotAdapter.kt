package com.example.adapter

import com.example.model.GripperIntent
import com.example.model.MotionIntent
import com.example.model.RobotState
import com.example.model.StopRequest
import kotlinx.coroutines.flow.StateFlow

/**
 * Standardized interface for robot communication adapters.
 * Keeps manufacturer-specific and transport-specific logic behind replaceable interfaces.
 */
interface RobotAdapter {
  val name: String
  val isConnected: Boolean

  suspend fun connect(endpoint: String = ""): Result<Unit>
  suspend fun disconnect()

  fun sendMotionIntent(intent: MotionIntent)
  fun sendGripperIntent(intent: GripperIntent)
  fun sendStopRequest(request: StopRequest)
  fun clearFault()

  fun observeTelemetry(): StateFlow<RobotState>

  // Diagnostic / Simulation hooks
  fun injectFault(faultType: SimulatedFault)
  fun resetSimulation(homePose: Boolean = true)
}

enum class SimulatedFault(val label: String, val description: String) {
  NONE("None", "Normal operational state"),
  NETWORK_TIMEOUT("Network Dropout", "Cease telemetry and command packets for 3 seconds"),
  JOINT_OVERTEMP("Joint 3 Motor Thermal Limit", "Trigger immediate protective stop on Joint 3"),
  ESTOP_TRIGGERED("Hardware E-Stop Line Open", "Simulate trip of external safety fence interlock"),
  STALE_PACKET_STORM("Stale Packet Rejection", "Inject delayed / out-of-order motion frames")
}
