package com.example.ui.components

import android.view.MotionEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CartesianVelocity
import com.example.model.ControlMode
import com.example.model.CoordinateFrame
import com.example.ui.theme.AureomGoldPrimary
import com.example.ui.theme.SafetyAmber
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.SafetyRed

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun TouchJogControls(
  activeMode: ControlMode,
  activeFrame: CoordinateFrame,
  speedLimitPercent: Float,
  gripperClosed: Boolean,
  selectedJointIndex: Int,
  isDeadmanHeld: Boolean,
  onModeChange: (ControlMode) -> Unit,
  onFrameChange: (CoordinateFrame) -> Unit,
  onJointSelect: (Int) -> Unit,
  onSpeedChange: (Float) -> Unit,
  onDeadmanChange: (Boolean) -> Unit,
  onCartesianJog: (CartesianVelocity) -> Unit,
  onJointJog: (jointIndex: Int, velocityDegS: Float) -> Unit,
  onGripperToggle: (Boolean) -> Unit,
  modifier: Modifier = Modifier
) {
  var isOrientationSubMode by remember { mutableStateOf(false) }

  Surface(
    modifier = modifier.fillMaxWidth(),
    color = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp),
    tonalElevation = 4.dp
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp)
    ) {
      // Top Controls Row: Mode Chips, Frame Toggle, Speed Slider
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        // Mode selector
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          FilterChip(
            selected = activeMode == ControlMode.CARTESIAN_JOG,
            onClick = { onModeChange(ControlMode.CARTESIAN_JOG) },
            label = { Text("Cartesian", fontSize = 11.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = AureomGoldPrimary,
              selectedLabelColor = Color(0xFF1F1703)
            ),
            modifier = Modifier.testTag("mode_cartesian_chip")
          )
          FilterChip(
            selected = activeMode == ControlMode.JOINT_JOG,
            onClick = { onModeChange(ControlMode.JOINT_JOG) },
            label = { Text("Joints", fontSize = 11.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = AureomGoldPrimary,
              selectedLabelColor = Color(0xFF1F1703)
            ),
            modifier = Modifier.testTag("mode_joint_chip")
          )
        }

        // Frame or Translation/Orientation toggle
        if (activeMode == ControlMode.CARTESIAN_JOG) {
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(
              selected = activeFrame == CoordinateFrame.BASE,
              onClick = {
                onFrameChange(if (activeFrame == CoordinateFrame.BASE) CoordinateFrame.TOOL else CoordinateFrame.BASE)
              },
              label = { Text(activeFrame.name, fontSize = 11.sp) },
              leadingIcon = {
                Icon(
                  imageVector = Icons.Default.SwapHoriz,
                  contentDescription = "Toggle Frame",
                  modifier = Modifier.size(14.dp)
                )
              }
            )

            FilterChip(
              selected = isOrientationSubMode,
              onClick = { isOrientationSubMode = !isOrientationSubMode },
              label = { Text(if (isOrientationSubMode) "Rotation" else "Linear", fontSize = 11.sp) }
            )
          }
        }

        // Speed limit slider
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.width(170.dp)
        ) {
          Text(
            text = "${speedLimitPercent.toInt()}%",
            style = MaterialTheme.typography.labelSmall,
            color = AureomGoldPrimary,
            modifier = Modifier.width(36.dp)
          )
          Slider(
            value = speedLimitPercent,
            onValueChange = onSpeedChange,
            valueRange = 5f..100f,
            colors = SliderDefaults.colors(
              thumbColor = AureomGoldPrimary,
              activeTrackColor = AureomGoldPrimary,
              inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
            ),
            modifier = Modifier.height(28.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Main Jog Pad & Hold-To-Enable Deadman
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        // Touch Deadman Button (Must be pressed continuously to jog)
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(width = 130.dp, height = 74.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(
              if (isDeadmanHeld) SafetyGreen else MaterialTheme.colorScheme.surfaceVariant
            )
            .border(
              width = 2.dp,
              color = if (isDeadmanHeld) SafetyGreen else AureomGoldPrimary.copy(alpha = 0.5f),
              shape = RoundedCornerShape(8.dp)
            )
            .pointerInteropFilter { motionEvent ->
              when (motionEvent.action) {
                MotionEvent.ACTION_DOWN -> {
                  onDeadmanChange(true)
                  true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                  onDeadmanChange(false)
                  true
                }
                else -> false
              }
            }
            .testTag("touch_deadman_button")
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              imageVector = Icons.Default.PanTool,
              contentDescription = "Deadman Hold",
              tint = if (isDeadmanHeld) Color(0xFF04210E) else AureomGoldPrimary,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = if (isDeadmanHeld) "DEADMAN ACTIVE" else "HOLD DEADMAN",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = if (isDeadmanHeld) Color(0xFF04210E) else MaterialTheme.colorScheme.onSurface
            )
          }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Center Jog Buttons: Cartesian or Joint
        if (activeMode == ControlMode.CARTESIAN_JOG) {
          CartesianJogButtons(
            isOrientation = isOrientationSubMode,
            onJog = onCartesianJog,
            modifier = Modifier.weight(1f)
          )
        } else {
          JointJogButtons(
            selectedJoint = selectedJointIndex,
            onJointSelect = onJointSelect,
            onJointJog = onJointJog,
            modifier = Modifier.weight(1f)
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Gripper actuation toggle
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = "GRIPPER",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(4.dp))
          Button(
            onClick = { onGripperToggle(!gripperClosed) },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (gripperClosed) AureomGoldPrimary else MaterialTheme.colorScheme.surfaceVariant,
              contentColor = if (gripperClosed) Color(0xFF1F1703) else MaterialTheme.colorScheme.onSurface
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .height(50.dp)
              .testTag("touch_gripper_btn")
          ) {
            Text(
              text = if (gripperClosed) "OPEN" else "CLOSE",
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
private fun CartesianJogButtons(
  isOrientation: Boolean,
  onJog: (CartesianVelocity) -> Unit,
  modifier: Modifier = Modifier
) {
  val velMag = 60f
  val angMag = 30f

  val labels = if (!isOrientation) {
    listOf(Pair("-X", "+X"), Pair("-Y", "+Y"), Pair("-Z", "+Z"))
  } else {
    listOf(Pair("-Roll", "+Roll"), Pair("-Pitch", "+Pitch"), Pair("-Yaw", "+Yaw"))
  }

  Row(
    modifier = modifier,
    horizontalArrangement = Arrangement.SpaceEvenly,
    verticalAlignment = Alignment.CenterVertically
  ) {
    for (i in 0..2) {
      val pair = labels[i]
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        // Minus button
        JogActionButton(
          label = pair.first,
          onPress = {
            if (!isOrientation) {
              when (i) {
                0 -> onJog(CartesianVelocity(vx = -velMag))
                1 -> onJog(CartesianVelocity(vy = -velMag))
                2 -> onJog(CartesianVelocity(vz = -velMag))
              }
            } else {
              when (i) {
                0 -> onJog(CartesianVelocity(wx = -angMag))
                1 -> onJog(CartesianVelocity(wy = -angMag))
                2 -> onJog(CartesianVelocity(wz = -angMag))
              }
            }
          },
          onRelease = { onJog(CartesianVelocity()) }
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Plus button
        JogActionButton(
          label = pair.second,
          onPress = {
            if (!isOrientation) {
              when (i) {
                0 -> onJog(CartesianVelocity(vx = velMag))
                1 -> onJog(CartesianVelocity(vy = velMag))
                2 -> onJog(CartesianVelocity(vz = velMag))
              }
            } else {
              when (i) {
                0 -> onJog(CartesianVelocity(wx = angMag))
                1 -> onJog(CartesianVelocity(wy = angMag))
                2 -> onJog(CartesianVelocity(wz = angMag))
              }
            }
          },
          onRelease = { onJog(CartesianVelocity()) }
        )
      }
    }
  }
}

@Composable
private fun JointJogButtons(
  selectedJoint: Int,
  onJointSelect: (Int) -> Unit,
  onJointJog: (Int, Float) -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier,
    horizontalArrangement = Arrangement.SpaceEvenly,
    verticalAlignment = Alignment.CenterVertically
  ) {
    for (j in 0..5) {
      val isSelected = selectedJoint == j
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(
          onClick = { onJointSelect(j) },
          color = if (isSelected) AureomGoldPrimary else MaterialTheme.colorScheme.surfaceVariant,
          shape = RoundedCornerShape(4.dp),
          modifier = Modifier.padding(bottom = 4.dp)
        ) {
          Text(
            text = "J${j + 1}",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (isSelected) Color(0xFF1D1402) else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
          JogActionButton(
            label = "-",
            onPress = { onJointJog(j, -30f) },
            onRelease = { onJointJog(j, 0f) }
          )
          JogActionButton(
            label = "+",
            onPress = { onJointJog(j, 30f) },
            onRelease = { onJointJog(j, 0f) }
          )
        }
      }
    }
  }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
private fun JogActionButton(
  label: String,
  onPress: () -> Unit,
  onRelease: () -> Unit
) {
  var isPressed by remember { mutableStateOf(false) }

  Box(
    contentAlignment = Alignment.Center,
    modifier = Modifier
      .size(width = 44.dp, height = 34.dp)
      .clip(RoundedCornerShape(4.dp))
      .background(
        if (isPressed) AureomGoldPrimary else MaterialTheme.colorScheme.surfaceVariant
      )
      .pointerInteropFilter { event ->
        when (event.action) {
          MotionEvent.ACTION_DOWN -> {
            isPressed = true
            onPress()
            true
          }
          MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
            isPressed = false
            onRelease()
            true
          }
          else -> false
        }
      }
  ) {
    Text(
      text = label,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      color = if (isPressed) Color(0xFF191202) else MaterialTheme.colorScheme.onSurface
    )
  }
}
