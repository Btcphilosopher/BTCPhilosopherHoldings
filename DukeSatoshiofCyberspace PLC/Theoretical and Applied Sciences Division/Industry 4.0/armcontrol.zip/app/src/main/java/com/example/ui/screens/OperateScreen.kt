package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.kinematics.RobotKinematics
import com.example.model.RobotState
import com.example.model.UnitSystem
import com.example.ui.components.RobotArm3DCanvas
import com.example.ui.components.SafetyBanner
import com.example.ui.components.TouchJogControls
import com.example.ui.theme.AureomGoldPrimary
import com.example.ui.theme.SafetyAmber
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.SafetyRed
import com.example.viewmodel.ArmControlViewModel

@Composable
fun OperateScreen(
  viewModel: ArmControlViewModel,
  modifier: Modifier = Modifier
) {
  val robotState by viewModel.robotState.collectAsState()
  val controllerInput by viewModel.controllerInput.collectAsState()
  val unitSystem by viewModel.unitSystem.collectAsState()

  var isTouchPanelExpanded by remember { mutableStateOf(true) }

  Column(modifier = modifier.fillMaxSize()) {
    // Safety & Interlock Notifications Banner
    SafetyBanner(
      robotState = robotState,
      isNeutralRearmed = controllerInput.isNeutralRearmed,
      isDeadmanEngaged = controllerInput.isDeadmanEngaged,
      onClearFault = { viewModel.clearFault() },
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
    )

    // Center Main Area: 3D Arm Viewport with Overlaid Telemetry HUD
    Box(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
    ) {
      // 3D Canvas
      RobotArm3DCanvas(
        robotState = robotState,
        blockLocation = viewModel.internalSimAdapter.blockLocation,
        modifier = Modifier.fillMaxSize()
      )

      // Top-Left Overlaid HUD: Tool Pose & Units
      Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.90f),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
          .padding(12.dp)
          .align(Alignment.TopStart)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.width(220.dp)
          ) {
            Text(
              text = "TOOL POSE (TCP)",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = AureomGoldPrimary
            )
            Surface(
              onClick = { viewModel.toggleUnitSystem() },
              color = MaterialTheme.colorScheme.surfaceVariant,
              shape = RoundedCornerShape(4.dp)
            ) {
              Text(
                text = "${unitSystem.distanceUnit} / ${unitSystem.angleUnit}",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          val pose = robotState.toolPose
          val lx = pose.x * unitSystem.linearScale
          val ly = pose.y * unitSystem.linearScale
          val lz = pose.z * unitSystem.linearScale

          val ar = pose.roll * unitSystem.angleScale
          val ap = pose.pitch * unitSystem.angleScale
          val ay = pose.yaw * unitSystem.angleScale

          Text(
            text = "X: %.1f  Y: %.1f  Z: %.1f %s".format(lx, ly, lz, unitSystem.distanceUnit),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold
          )
          Text(
            text = "R: %.1f  P: %.1f  Y: %.1f %s".format(ar, ap, ay, unitSystem.angleUnit),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(6.dp))

          // Gripper and Workpiece Status
          Row(verticalAlignment = Alignment.CenterVertically) {
            val gripPct = (robotState.gripperPosition * 100).toInt()
            Text(
              text = "GRIPPER: $gripPct%",
              style = MaterialTheme.typography.labelSmall,
              color = if (robotState.isGripperHoldingObject) SafetyGreen else AureomGoldPrimary
            )
            if (robotState.isGripperHoldingObject) {
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "• HOLDING OBJECT",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = SafetyGreen
              )
            }
          }
        }
      }

      // Top-Right Overlaid HUD: 6-Axis Joint Positions & Limits
      Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.90f),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
          .padding(12.dp)
          .align(Alignment.TopEnd)
      ) {
        Column(modifier = Modifier.padding(10.dp).width(190.dp)) {
          Text(
            text = "JOINT ANGLES (LIMITS)",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = AureomGoldPrimary
          )
          Spacer(modifier = Modifier.height(4.dp))

          for (i in 0..5) {
            val q = robotState.jointPositionsDeg.getOrElse(i) { 0f }
            val minL = RobotKinematics.JOINT_LIMITS_MIN[i]
            val maxL = RobotKinematics.JOINT_LIMITS_MAX[i]
            val frac = ((q - minL) / (maxL - minL)).coerceIn(0f, 1f)
            val isNearLimit = robotState.nearLimitJoints.contains(i)

            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)
            ) {
              Text(
                text = "J${i + 1}",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (isNearLimit) SafetyAmber else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.width(20.dp)
              )
              LinearProgressIndicator(
                progress = { frac },
                modifier = Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = if (isNearLimit) SafetyAmber else AureomGoldPrimary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "%.0f°".format(q),
                fontSize = 10.sp,
                style = MaterialTheme.typography.labelSmall,
                color = if (isNearLimit) SafetyAmber else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.width(36.dp)
              )
            }
          }
        }
      }

      // Bottom-Left Motion Telemetry Vector Bar
      Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
          .padding(12.dp)
          .align(Alignment.BottomStart)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Column {
            Text("REQUESTED MOTION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(robotState.requestedVelocitySummary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = AureomGoldPrimary)
          }
          Column {
            Text("CONFIRMED TELEMETRY", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(robotState.confirmedVelocitySummary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = SafetyGreen)
          }
        }
      }

      // Bottom-Right Quick Controlled Stop button
      Button(
        onClick = { viewModel.requestControlledStop("Touchscreen Controlled Stop") },
        colors = ButtonDefaults.buttonColors(
          containerColor = MaterialTheme.colorScheme.surfaceVariant,
          contentColor = SafetyAmber
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
          .padding(12.dp)
          .align(Alignment.BottomEnd)
          .testTag("controlled_stop_btn")
      ) {
        Icon(Icons.Default.StopCircle, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Controlled Stop", fontWeight = FontWeight.Bold, fontSize = 12.sp)
      }
    }

    // Bottom Touch Jog Cockpit
    TouchJogControls(
      activeMode = robotState.activeMode,
      activeFrame = robotState.activeFrame,
      speedLimitPercent = robotState.requestedSpeedLimitPercent,
      gripperClosed = robotState.gripperPosition > 0.5f,
      selectedJointIndex = robotState.selectedJointIndex,
      isDeadmanHeld = controllerInput.isDeadmanEngaged,
      onModeChange = { viewModel.setControlMode(it) },
      onFrameChange = { viewModel.setCoordinateFrame(it) },
      onJointSelect = { viewModel.setSelectedJointIndex(it) },
      onSpeedChange = { /* Speed adjustable via touch slider */ },
      onDeadmanChange = { viewModel.setTouchDeadman(it) },
      onCartesianJog = { viewModel.setTouchCartesianVelocity(it) },
      onJointJog = { idx, vel -> viewModel.setTouchJointJog(idx, vel) },
      onGripperToggle = { viewModel.toggleGripper(it) }
    )
  }
}
