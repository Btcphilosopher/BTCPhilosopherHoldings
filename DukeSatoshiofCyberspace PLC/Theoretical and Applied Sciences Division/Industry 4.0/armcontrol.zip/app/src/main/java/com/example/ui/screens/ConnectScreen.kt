package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.adapter.SimulatedFault
import com.example.model.ControllerProfile
import com.example.model.ResponseCurve
import com.example.ui.components.ControllerVisualizer
import com.example.ui.theme.AureomGoldPrimary
import com.example.ui.theme.SafetyAmber
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.SafetyRed
import com.example.viewmodel.ArmControlViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectScreen(
  viewModel: ArmControlViewModel,
  modifier: Modifier = Modifier
) {
  val controllerInput by viewModel.controllerInput.collectAsState()
  val robotState by viewModel.robotState.collectAsState()
  val isUsingWebSocket by viewModel.isUsingWebSocket.collectAsState()

  var showCalibWizard by remember { mutableStateOf(false) }
  var gatewayUrl by remember { mutableStateOf("ws://10.0.2.2:8765/robot") }

  var activeProfile by remember { mutableStateOf(viewModel.controllerManager.getProfile()) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Gamepad Discovery & Inspection Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Games,
                contentDescription = "Gamepad",
                tint = AureomGoldPrimary,
                modifier = Modifier.size(24.dp)
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = "OPERATOR CONTROLLER",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "USB & Bluetooth HID Gamepad Detection",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            Row {
              IconButton(onClick = { viewModel.controllerManager.scanConnectedControllers() }) {
                Icon(
                  imageVector = Icons.Default.Refresh,
                  contentDescription = "Rescan Controllers",
                  tint = AureomGoldPrimary
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Button(
                onClick = { showCalibWizard = true },
                colors = ButtonDefaults.buttonColors(
                  containerColor = AureomGoldPrimary,
                  contentColor = Color(0xFF161002)
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.testTag("launch_wizard_btn")
              ) {
                Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Calibration Wizard", fontWeight = FontWeight.Bold, fontSize = 12.sp)
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Live visualizer of controller inputs
          ControllerVisualizer(inputState = controllerInput)

          Spacer(modifier = Modifier.height(12.dp))

          // Controller Tuning (Deadzones & Response Curves)
          Text(
            text = "Controller Tuning & Profile",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
              Text(
                text = "Stick Deadzone: ${(activeProfile.deadzoneLeft * 100).toInt()}%",
                style = MaterialTheme.typography.bodySmall
              )
              Slider(
                value = activeProfile.deadzoneLeft,
                onValueChange = {
                  activeProfile = activeProfile.copy(deadzoneLeft = it, deadzoneRight = it)
                  viewModel.controllerManager.setProfile(activeProfile)
                },
                valueRange = 0.05f..0.30f,
                colors = SliderDefaults.colors(thumbColor = AureomGoldPrimary, activeTrackColor = AureomGoldPrimary)
              )
            }

            Column(modifier = Modifier.weight(1f).padding(start = 8.dp)) {
              Text(
                text = "Deadman Squeeze Threshold: ${(activeProfile.deadmanActivateThreshold * 100).toInt()}%",
                style = MaterialTheme.typography.bodySmall
              )
              Slider(
                value = activeProfile.deadmanActivateThreshold,
                onValueChange = {
                  activeProfile = activeProfile.copy(
                    deadmanActivateThreshold = it,
                    deadmanReleaseThreshold = (it - 0.15f).coerceAtLeast(0.10f)
                  )
                  viewModel.controllerManager.setProfile(activeProfile)
                },
                valueRange = 0.20f..0.60f,
                colors = SliderDefaults.colors(thumbColor = AureomGoldPrimary, activeTrackColor = AureomGoldPrimary)
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          // Response Curve selection
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            ResponseCurve.entries.forEach { curve ->
              FilterChip(
                selected = activeProfile.responseCurve == curve,
                onClick = {
                  activeProfile = activeProfile.copy(responseCurve = curve)
                  viewModel.controllerManager.setProfile(activeProfile)
                },
                label = { Text(curve.label, fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = AureomGoldPrimary,
                  selectedLabelColor = Color(0xFF1B1403)
                )
              )
            }
          }
        }
      }
    }

    // 2. Robot Backend Connection Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Router,
                contentDescription = "Robot Connection",
                tint = AureomGoldPrimary,
                modifier = Modifier.size(24.dp)
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = "ROBOT GATEWAY ADAPTER",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "Select Simulation or Real-Time Python WebSocket Service",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            Surface(
              color = if (robotState.controlState.isSafeToMove || robotState.controlState != com.example.model.ControlState.DISCONNECTED)
                SafetyGreen.copy(alpha = 0.15f) else SafetyRed.copy(alpha = 0.15f),
              shape = RoundedCornerShape(4.dp)
            ) {
              Text(
                text = if (isUsingWebSocket) "GATEWAY: WEBSOCKET" else "BUILT-IN SIMULATOR",
                color = if (robotState.controlState != com.example.model.ControlState.DISCONNECTED) SafetyGreen else SafetyRed,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Button(
              onClick = { viewModel.switchToInternalSimulator() },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (!isUsingWebSocket) AureomGoldPrimary else MaterialTheme.colorScheme.surfaceVariant,
                contentColor = if (!isUsingWebSocket) Color(0xFF1B1403) else MaterialTheme.colorScheme.onSurface
              ),
              shape = RoundedCornerShape(6.dp),
              modifier = Modifier.weight(1f).testTag("select_internal_sim_btn")
            ) {
              Text("Built-in Simulator", fontWeight = FontWeight.Bold)
            }

            Button(
              onClick = { viewModel.connectToWebSocketGateway(gatewayUrl) },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (isUsingWebSocket) AureomGoldPrimary else MaterialTheme.colorScheme.surfaceVariant,
                contentColor = if (isUsingWebSocket) Color(0xFF1B1403) else MaterialTheme.colorScheme.onSurface
              ),
              shape = RoundedCornerShape(6.dp),
              modifier = Modifier.weight(1f).testTag("select_websocket_btn")
            ) {
              Text("Python Gateway", fontWeight = FontWeight.Bold)
            }
          }

          if (isUsingWebSocket) {
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
              value = gatewayUrl,
              onValueChange = { gatewayUrl = it },
              label = { Text("WebSocket Endpoint (ws://<ip>:<port>/robot)") },
              modifier = Modifier.fillMaxWidth()
            )
          }
        }
      }
    }

    // 3. Safety Verification & Fault Injection Suite
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Warning,
              contentDescription = "Fault Suite",
              tint = SafetyAmber,
              modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "INTERLOCK & FAULT INJECTION TEST SUITE",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "Verify safe watchdog cutoff, disconnect halt, and interlock recovery",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedButton(
              onClick = { viewModel.injectSimulatedFault(SimulatedFault.NETWORK_TIMEOUT) },
              modifier = Modifier.weight(1f).testTag("inject_net_drop_btn")
            ) {
              Text("Simulate Net Drop", fontSize = 11.sp)
            }
            OutlinedButton(
              onClick = { viewModel.injectSimulatedFault(SimulatedFault.JOINT_OVERTEMP) },
              modifier = Modifier.weight(1f).testTag("inject_joint_fault_btn")
            ) {
              Text("Simulate Joint Trip", fontSize = 11.sp)
            }
            OutlinedButton(
              onClick = { viewModel.injectSimulatedFault(SimulatedFault.ESTOP_TRIGGERED) },
              modifier = Modifier.weight(1f).testTag("inject_estop_btn")
            ) {
              Text("Simulate E-Stop", fontSize = 11.sp, color = SafetyRed)
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = { viewModel.clearFault() },
              colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = MaterialTheme.colorScheme.onSurface
              ),
              modifier = Modifier.weight(1f).testTag("clear_fault_connect_btn")
            ) {
              Text("Clear Fault", fontSize = 12.sp)
            }

            Button(
              onClick = { viewModel.resetSimulation() },
              colors = ButtonDefaults.buttonColors(
                containerColor = AureomGoldPrimary,
                contentColor = Color(0xFF181102)
              ),
              modifier = Modifier.weight(1f).testTag("reset_sim_home_btn")
            ) {
              Text("Reset Arm to Home", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
          }
        }
      }
    }
  }

  // Calibration Wizard Dialog
  if (showCalibWizard) {
    CalibrationWizardDialog(
      inputState = controllerInput,
      onDismiss = { showCalibWizard = false }
    )
  }
}

@Composable
private fun CalibrationWizardDialog(
  inputState: com.example.model.ControllerInputState,
  onDismiss: () -> Unit
) {
  var currentStep by remember { mutableStateOf(1) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = "Controller Setup & Calibration (Step $currentStep/4)",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        when (currentStep) {
          1 -> {
            Text("Step 1: Neutral Stick Verification")
            Text(
              "Keep both analog sticks released in their center position. Verify both sticks show near 0.00.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              "Left Stick: X=%.2f, Y=%.2f".format(inputState.leftStickX, inputState.leftStickY),
              color = AureomGoldPrimary,
              style = MaterialTheme.typography.labelMedium
            )
            Text(
              "Right Stick: X=%.2f, Y=%.2f".format(inputState.rightStickX, inputState.rightStickY),
              color = AureomGoldPrimary,
              style = MaterialTheme.typography.labelMedium
            )
          }
          2 -> {
            Text("Step 2: Full Stick Deflection")
            Text(
              "Move Left Stick in a full circle to verify X and Y axes range from -1.0 to +1.0.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              "Detected Left Stick Deflection: %.2f".format(
                kotlin.math.sqrt(inputState.leftStickX * inputState.leftStickX + inputState.leftStickY * inputState.leftStickY)
              ),
              color = SafetyGreen,
              style = MaterialTheme.typography.labelMedium
            )
          }
          3 -> {
            Text("Step 3: Hold-to-Enable Deadman Trigger (Left Trigger)")
            Text(
              "Squeeze Left Trigger [LT] past 35% to engage Deadman. Release to ensure immediate cutoff.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              "Trigger Value: ${(inputState.leftTrigger * 100).toInt()}% | State: ${if (inputState.isDeadmanEngaged) "DEADMAN ENGAGED" else "RELEASED"}",
              color = if (inputState.isDeadmanEngaged) SafetyGreen else AureomGoldPrimary,
              style = MaterialTheme.typography.labelMedium
            )
          }
          4 -> {
            Text("Step 4: Speed Trigger (Right Trigger) & Face Buttons")
            Text(
              "Press Face Buttons [A] (Gripper Close) and [B] (Gripper Open). Squeeze Right Trigger for speed scaling.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              "A Pressed: ${inputState.buttonA} | B Pressed: ${inputState.buttonB} | RT: ${(inputState.rightTrigger * 100).toInt()}%",
              color = AureomGoldPrimary,
              style = MaterialTheme.typography.labelMedium
            )
          }
        }
      }
    },
    confirmButton = {
      if (currentStep < 4) {
        Button(
          onClick = { currentStep++ },
          colors = ButtonDefaults.buttonColors(containerColor = AureomGoldPrimary, contentColor = Color(0xFF1B1403))
        ) {
          Text("Next Step", fontWeight = FontWeight.Bold)
        }
      } else {
        Button(
          onClick = onDismiss,
          colors = ButtonDefaults.buttonColors(containerColor = SafetyGreen, contentColor = Color(0xFF03220E))
        ) {
          Text("Complete Setup", fontWeight = FontWeight.Bold)
        }
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}
