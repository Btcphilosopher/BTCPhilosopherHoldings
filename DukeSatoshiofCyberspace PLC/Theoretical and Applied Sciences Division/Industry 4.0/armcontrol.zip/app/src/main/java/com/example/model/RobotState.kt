package com.example.model

/**
 * Coordinate frames for Cartesian jogging and path generation.
 */
enum class CoordinateFrame(val label: String, val description: String) {
  BASE("Base Frame", "Coordinates fixed to the robot mounting base (World)"),
  TOOL("Tool Frame", "Coordinates attached to the moving tool flange / end-effector")
}

/**
 * Control modes for manual and automated operations.
 */
enum class ControlMode(val label: String) {
  JOINT_JOG("Joint Jog"),
  CARTESIAN_JOG("Cartesian Jog"),
  TEACH("Teach Pendant"),
  PLAYBACK("Simulation Playback")
}

/**
 * High-reliability control state machine.
 * Disconnected -> Connected -> Ready -> Enabled -> Moving.
 * Any fault, deadman release, disconnect, or timeout drops back safely.
 */
enum class ControlState(val label: String, val isSafeToMove: Boolean) {
  DISCONNECTED("Disconnected", false),
  CONNECTED("Connected", false),
  READY("Ready (Deadman Disengaged)", false),
  ENABLED("Enabled (Deadman Active)", true),
  MOVING("Moving", true),
  PAUSED("Paused", false),
  FAULTED("Faulted", false),
  PROTECTIVE_STOP("Protective Stop", false),
  ESTOP("Emergency Stop", false)
}

/**
 * 3D Tool Pose in Cartesian space.
 * x, y, z in millimeters.
 * roll, pitch, yaw in degrees (ZYX Euler convention).
 */
data class Pose3D(
  val x: Float = 0f,
  val y: Float = 0f,
  val z: Float = 0f,
  val roll: Float = 0f,
  val pitch: Float = 0f,
  val yaw: Float = 0f
) {
  fun formatted(): String = "X: %.1f Y: %.1f Z: %.1f | R: %.1f° P: %.1f° Y: %.1f°".format(x, y, z, roll, pitch, yaw)
}

/**
 * Cartesian velocity vector.
 * Linear: mm/s. Angular: deg/s.
 */
data class CartesianVelocity(
  val vx: Float = 0f,
  val vy: Float = 0f,
  val vz: Float = 0f,
  val wx: Float = 0f,
  val wy: Float = 0f,
  val wz: Float = 0f
) {
  val isZero: Boolean
    get() = vx == 0f && vy == 0f && vz == 0f && wx == 0f && wy == 0f && wz == 0f
}

/**
 * Units display preference.
 */
enum class UnitSystem(val distanceUnit: String, val angleUnit: String, val linearScale: Float, val angleScale: Float) {
  METRIC_MM_DEG("mm", "°", 1.0f, 1.0f),
  METRIC_M_RAD("m", "rad", 0.001f, (Math.PI / 180.0).toFloat())
}

/**
 * Comprehensive robot telemetry state received from the simulation or real controller.
 */
data class RobotState(
  val timestamp: Long = System.currentTimeMillis(),
  val jointPositionsDeg: FloatArray = floatArrayOf(0f, -20f, 40f, 0f, 70f, 0f),
  val jointVelocitiesDegPerSec: FloatArray = floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f),
  val toolPose: Pose3D = Pose3D(350f, 0f, 280f, 0f, 90f, 0f),
  val gripperPosition: Float = 0f, // 0.0 = Fully open, 1.0 = Fully closed
  val isGripperHoldingObject: Boolean = false,
  val heldObjectName: String? = null,
  val controlState: ControlState = ControlState.READY,
  val activeMode: ControlMode = ControlMode.CARTESIAN_JOG,
  val activeFrame: CoordinateFrame = CoordinateFrame.BASE,
  val selectedJointIndex: Int = 0,
  val requestedSpeedLimitPercent: Float = 30f, // 5% to 100%
  val appliedSpeedPercent: Float = 30f,
  val telemetryAgeMs: Long = 0L,
  val watchdogRemainingMs: Long = 250L,
  val isSingularityNear: Boolean = false,
  val singularityWarningText: String? = null,
  val nearLimitJoints: List<Int> = emptyList(),
  val activeFaultMessage: String? = null,
  val confirmedSequenceNumber: Long = 0L,
  val requestedVelocitySummary: String = "Neutral",
  val confirmedVelocitySummary: String = "Stationary"
) {
  override fun equals(other: Any?): Boolean {
    if (this === other) return true
    if (javaClass != other?.javaClass) return false
    other as RobotState
    return timestamp == other.timestamp &&
        jointPositionsDeg.contentEquals(other.jointPositionsDeg) &&
        toolPose == other.toolPose &&
        controlState == other.controlState &&
        gripperPosition == other.gripperPosition &&
        isGripperHoldingObject == other.isGripperHoldingObject
  }

  override fun hashCode(): Int {
    var result = timestamp.hashCode()
    result = 31 * result + jointPositionsDeg.contentHashCode()
    result = 31 * result + toolPose.hashCode()
    result = 31 * result + controlState.hashCode()
    return result
  }
}
