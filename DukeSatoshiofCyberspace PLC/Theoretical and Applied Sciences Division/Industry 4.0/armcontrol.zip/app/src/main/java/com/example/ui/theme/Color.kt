package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aureom.AI Industrial Graphite & Gold Palette
val AureomGoldPrimary = Color(0xFFE5A93C)
val AureomGoldLight = Color(0xFFFCD782)
val AureomGoldDark = Color(0xFFB57D1E)
val AureomGoldContainer = Color(0xFF302209)
val AureomGoldOnContainer = Color(0xFFFEE8B0)

val AureomSecondary = Color(0xFFD2C4A8)
val AureomSecondaryContainer = Color(0xFF28251E)
val AureomOnSecondaryContainer = Color(0xFFEDE4D2)

val IndustrialBgDark = Color(0xFF121315)
val IndustrialSurfaceDark = Color(0xFF1A1C20)
val IndustrialSurfaceVariantDark = Color(0xFF252830)
val IndustrialSurfaceHighlight = Color(0xFF333742)
val IndustrialOutlineDark = Color(0xFF3E4350)

val TextPrimaryDark = Color(0xFFF4F6FA)
val TextSecondaryDark = Color(0xFFA3AAB8)
val TextMutedDark = Color(0xFF6B7280)

// Status & Safety Colors
val SafetyGreen = Color(0xFF00E676)
val SafetyGreenBg = Color(0xFF0A2B19)
val SafetyAmber = Color(0xFFFFB300)
val SafetyAmberBg = Color(0xFF332400)
val SafetyRed = Color(0xFFFF3838)
val SafetyRedBg = Color(0xFF380D0D)
val SafetyBlue = Color(0xFF29B6F6)
val SafetyBlueBg = Color(0xFF0C2738)

// Light Theme variants (for optional light mode)
val IndustrialBgLight = Color(0xFFF3F4F6)
val IndustrialSurfaceLight = Color(0xFFFFFFFF)
val IndustrialSurfaceVariantLight = Color(0xFFE5E7EB)
val IndustrialOutlineLight = Color(0xFFCBD5E1)
val TextPrimaryLight = Color(0xFF111827)
val TextSecondaryLight = Color(0xFF4B5563)
