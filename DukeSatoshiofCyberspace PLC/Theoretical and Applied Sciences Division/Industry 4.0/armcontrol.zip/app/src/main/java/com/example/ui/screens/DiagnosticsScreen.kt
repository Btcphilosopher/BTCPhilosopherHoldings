package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.adapter.SimulatedFault
import com.example.ui.theme.AureomGoldPrimary
import com.example.ui.theme.SafetyAmber
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.SafetyRed
import com.example.viewmodel.ArmControlViewModel
import kotlin.math.abs

@Composable
fun DiagnosticsScreen(
  viewModel: ArmControlViewModel,
  modifier: Modifier = Modifier
) {
  val robotState by viewModel.robotState.collectAsState()
  val controllerInput by viewModel.controllerInput.collectAsState()
  val logs by viewModel.logs.collectAsState()

  var selectedLogLevel by remember { mutableStateOf("ALL") }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Real-Time Telemetry & Watchdog Telemetry Dashboard
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Speed, contentDescription = null, tint = AureomGoldPrimary, modifier = Modifier.size(22.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("WATCHDOG & MOTION TELEMETRY METRICS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            Surface(
              color = if (robotState.watchdogRemainingMs > 100) SafetyGreen.copy(alpha = 0.15f) else SafetyRed.copy(alpha = 0.15f),
              shape = RoundedCornerShape(4.dp)
            ) {
              Text(
                text = "HEARTBEAT: ${robotState.watchdogRemainingMs}ms",
                color = if (robotState.watchdogRemainingMs > 100) SafetyGreen else SafetyRed,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // 4 Metric cards
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            MetricBadge(
              label = "Confirmed Seq #",
              value = "${robotState.confirmedSequenceNumber}",
              color = AureomGoldPrimary,
              modifier = Modifier.weight(1f)
            )
            MetricBadge(
              label = "Telemetry Age",
              value = "${robotState.telemetryAgeMs} ms",
              color = if (robotState.telemetryAgeMs < 50) SafetyGreen else SafetyAmber,
              modifier = Modifier.weight(1f)
            )
            MetricBadge(
              label = "Watchdog Limit",
              value = "250 ms",
              color = SafetyGreen,
              modifier = Modifier.weight(1f)
            )
            MetricBadge(
              label = "Gripper State",
              value = "${(robotState.gripperPosition * 100).toInt()}%",
              color = AureomGoldPrimary,
              modifier = Modifier.weight(1f)
            )
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Live Joint Velocity Oscilloscope
          Text("Joint Velocity Spectrum (deg/s)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(6.dp))

          for (i in 0..5) {
            val vel = robotState.jointVelocitiesDegPerSec.getOrElse(i) { 0f }
            val velMag = abs(vel)
            val maxVel = com.example.kinematics.RobotKinematics.JOINT_MAX_VELOCITY[i]
            val frac = (velMag / maxVel).coerceIn(0f, 1f)

            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
            ) {
              Text(
                text = "J${i + 1}",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.width(24.dp)
              )
              LinearProgressIndicator(
                progress = { frac },
                modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)),
                color = if (frac > 0.8f) SafetyAmber else AureomGoldPrimary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "%+.1f°/s".format(vel),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.width(55.dp)
              )
            }
          }
        }
      }
    }

    // 2. Safety Interlock & Fault Testing Tools
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.BugReport, contentDescription = null, tint = SafetyAmber, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("FAULT & STOP BEHAVIOR VERIFICATION", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          }

          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Inject physical and network disruptions to observe independent watchdog deceleration and safe stopping behavior.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedButton(
              onClick = { viewModel.injectSimulatedFault(SimulatedFault.NETWORK_TIMEOUT) },
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Default.WifiOff, contentDescription = null, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("3s Net Drop", fontSize = 11.sp)
            }

            OutlinedButton(
              onClick = { viewModel.injectSimulatedFault(SimulatedFault.JOINT_OVERTEMP) },
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Default.Thermostat, contentDescription = null, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Joint Thermal", fontSize = 11.sp)
            }

            OutlinedButton(
              onClick = { viewModel.injectSimulatedFault(SimulatedFault.ESTOP_TRIGGERED) },
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Default.Warning, contentDescription = null, tint = SafetyRed, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Trip E-Stop", fontSize = 11.sp, color = SafetyRed)
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = { viewModel.clearFault() },
              colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = MaterialTheme.colorScheme.onSurface
              ),
              modifier = Modifier.weight(1f)
            ) {
              Text("Clear Fault Interlock", fontSize = 12.sp)
            }

            Button(
              onClick = { viewModel.resetSimulation() },
              colors = ButtonDefaults.buttonColors(
                containerColor = AureomGoldPrimary,
                contentColor = Color(0xFF191202)
              ),
              modifier = Modifier.weight(1f)
            ) {
              Text("Reset Simulator to Home", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
          }
        }
      }
    }

    // 3. Raw Gamepad Input Inspection
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("RAW CONTROLLER AXIS & BUTTON TELEMETRY", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("STICK AXES", style = MaterialTheme.typography.labelSmall, color = AureomGoldPrimary)
              Text("Left Stick X: %+.3f".format(controllerInput.leftStickX), style = MaterialTheme.typography.labelSmall)
              Text("Left Stick Y: %+.3f".format(controllerInput.leftStickY), style = MaterialTheme.typography.labelSmall)
              Text("Right Stick X: %+.3f".format(controllerInput.rightStickX), style = MaterialTheme.typography.labelSmall)
              Text("Right Stick Y: %+.3f".format(controllerInput.rightStickY), style = MaterialTheme.typography.labelSmall)
            }

            Column(modifier = Modifier.weight(1f)) {
              Text("TRIGGERS & D-PAD", style = MaterialTheme.typography.labelSmall, color = AureomGoldPrimary)
              Text("LT (Deadman): %.2f".format(controllerInput.leftTrigger), style = MaterialTheme.typography.labelSmall)
              Text("RT (Speed): %.2f".format(controllerInput.rightTrigger), style = MaterialTheme.typography.labelSmall)
              Text("D-Pad X: ${controllerInput.dpadX}", style = MaterialTheme.typography.labelSmall)
              Text("D-Pad Y: ${controllerInput.dpadY}", style = MaterialTheme.typography.labelSmall)
            }

            Column(modifier = Modifier.weight(1f)) {
              Text("SAFETY INTERLOCKS", style = MaterialTheme.typography.labelSmall, color = AureomGoldPrimary)
              Text("Deadman Active: ${controllerInput.isDeadmanEngaged}", style = MaterialTheme.typography.labelSmall)
              Text("Neutral Rearmed: ${controllerInput.isNeutralRearmed}", style = MaterialTheme.typography.labelSmall)
              Text("Orientation Mode: ${viewModel.controllerManager.isOrientationJogMode}", style = MaterialTheme.typography.labelSmall)
            }
          }
        }
      }
    }

    // 4. Structured Diagnostic Event Log Console
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("STRUCTURED SYSTEM EVENT LOGS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              listOf("ALL", "INFO", "WARN", "SAFETY", "ERROR").forEach { lvl ->
                FilterChip(
                  selected = selectedLogLevel == lvl,
                  onClick = { selectedLogLevel = lvl },
                  label = { Text(lvl, fontSize = 10.sp) },
                  colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = AureomGoldPrimary,
                    selectedLabelColor = Color(0xFF191202)
                  )
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          val filteredLogs = if (selectedLogLevel == "ALL") logs else logs.filter { it.level == selectedLogLevel }

          Surface(
            color = MaterialTheme.colorScheme.background,
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(200.dp)
          ) {
            LazyColumn(
              modifier = Modifier.fillMaxSize().padding(8.dp),
              verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              items(filteredLogs.asReversed()) { log ->
                val levelColor = when (log.level) {
                  "SAFETY" -> SafetyAmber
                  "ERROR" -> SafetyRed
                  "WARN" -> SafetyAmber
                  else -> SafetyGreen
                }

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = log.formattedTime,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.width(70.dp)
                  )
                  Text(
                    text = "[${log.level}]",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = levelColor,
                    modifier = Modifier.width(55.dp)
                  )
                  Text(
                    text = log.message,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun MetricBadge(
  label: String,
  value: String,
  color: Color,
  modifier: Modifier = Modifier
) {
  Surface(
    color = MaterialTheme.colorScheme.surfaceVariant,
    shape = RoundedCornerShape(6.dp),
    modifier = modifier
  ) {
    Column(modifier = Modifier.padding(8.dp)) {
      Text(label, style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
      Spacer(modifier = Modifier.height(2.dp))
      Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = color)
    }
  }
}
