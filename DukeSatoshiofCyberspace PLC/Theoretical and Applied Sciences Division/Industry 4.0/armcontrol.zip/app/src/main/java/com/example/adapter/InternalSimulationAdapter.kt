package com.example.adapter

import com.example.kinematics.RobotKinematics
import com.example.model.ControlMode
import com.example.model.ControlState
import com.example.model.CoordinateFrame
import com.example.model.GripperIntent
import com.example.model.MotionIntent
import com.example.model.Pose3D
import com.example.model.RobotState
import com.example.model.StopRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max

class InternalSimulationAdapter(
  private val scope: CoroutineScope,
  autoStartLoop: Boolean = true
) : RobotAdapter {

  override val name: String = "Built-in High-Fidelity 6-Axis Simulator"
  override var isConnected: Boolean = true
    private set

  private val _telemetry = MutableStateFlow(RobotState())
  override fun observeTelemetry(): StateFlow<RobotState> = _telemetry.asStateFlow()

  // Simulation loop job
  private var simLoopJob: Job? = null

  // Watchdog & sequencing
  private var lastValidIntentTime: Long = System.currentTimeMillis()
  private var highestSeqNumber: Long = 0L
  private val watchdogTimeoutMs: Long = 250L

  // Active command buffered by robot controller
  private var latestIntent: MotionIntent? = null
  private var targetGripperPos: Float = 0f
  private var currentGripperPos: Float = 0f
  private var isHoldingBlock: Boolean = false

  // Robot joints (degrees)
  private val defaultHomeJoints = floatArrayOf(0f, -25f, 45f, 0f, 70f, 0f)
  private var currentJoints = defaultHomeJoints.clone()
  private var currentJointVelocities = FloatArray(6) { 0f }

  // Workpiece target pick-and-place block location
  var blockLocation = floatArrayOf(340f, 70f, 95f) // X, Y, Z mm
    private set

  // Fault simulation
  private var activeSimFault: SimulatedFault = SimulatedFault.NONE
  private var faultRecoveryDeadline: Long = 0L

  init {
    if (autoStartLoop) {
      startSimulationLoop()
    }
  }

  private fun startSimulationLoop() {
    simLoopJob?.cancel()
    simLoopJob = scope.launch {
      var lastTick = System.currentTimeMillis()

      while (isActive) {
        val now = System.currentTimeMillis()
        val dt = ((now - lastTick).coerceAtLeast(1L).coerceAtMost(50L)) / 1000f
        lastTick = now

        updateSimulationTick(dt, now)
        delay(20) // 50 Hz control loop
      }
    }
  }

  private fun updateSimulationTick(dt: Float, now: Long) {
    // Check if network dropout is currently active
    if (activeSimFault == SimulatedFault.NETWORK_TIMEOUT && now < faultRecoveryDeadline) {
      // Simulate silent network drop (no telemetry emission)
      return
    }

    val state = _telemetry.value
    var controlState = state.controlState
    var activeFault = state.activeFaultMessage

    // 1. Independent robot-side watchdog timer check
    val timeSinceIntent = now - lastValidIntentTime
    val remainingWatchdog = max(0L, watchdogTimeoutMs - timeSinceIntent)

    val isWatchdogExpired = timeSinceIntent > watchdogTimeoutMs

    // Determine target velocities
    val targetVelocities = FloatArray(6) { 0f }
    val intent = latestIntent

    if (activeSimFault == SimulatedFault.ESTOP_TRIGGERED) {
      controlState = ControlState.ESTOP
      activeFault = "EMERGENCY STOP TRIPPED: Safety circuit open"
    } else if (activeSimFault == SimulatedFault.JOINT_OVERTEMP) {
      controlState = ControlState.PROTECTIVE_STOP
      activeFault = "PROTECTIVE STOP: Joint 3 motor temperature 98°C"
    } else if (controlState == ControlState.ESTOP || controlState == ControlState.FAULTED || controlState == ControlState.PROTECTIVE_STOP) {
      // Remain halted until fault is cleared
    } else if (intent != null && intent.enableState && !isWatchdogExpired) {
      controlState = ControlState.MOVING

      if (intent.controlMode == ControlMode.JOINT_JOG) {
        val requestedJointVels = intent.jointVelocitiesDegPerSec
        if (requestedJointVels != null) {
          for (i in 0..5) {
            targetVelocities[i] = requestedJointVels.getOrElse(i) { 0f } * (intent.speedScalePercent / 100f)
          }
        }
      } else if (intent.controlMode == ControlMode.CARTESIAN_JOG) {
        val cartVel = intent.cartesianVelocity
        if (cartVel != null && !cartVel.isZero) {
          val scaledCartVel = cartVel.copy(
            vx = cartVel.vx * (intent.speedScalePercent / 100f),
            vy = cartVel.vy * (intent.speedScalePercent / 100f),
            vz = cartVel.vz * (intent.speedScalePercent / 100f),
            wx = cartVel.wx * (intent.speedScalePercent / 100f),
            wy = cartVel.wy * (intent.speedScalePercent / 100f),
            wz = cartVel.wz * (intent.speedScalePercent / 100f)
          )
          val solvedDq = RobotKinematics.solveCartesianVelocity(
            currentJointsDeg = currentJoints,
            cartesianVel = scaledCartVel,
            frame = intent.coordinateFrame
          )
          for (i in 0..5) {
            targetVelocities[i] = solvedDq[i]
          }
        }
      }
    } else {
      // Deadman released, intent absent, or watchdog expired
      if (controlState == ControlState.MOVING) {
        controlState = ControlState.READY
      }
    }

    // 2. Smooth acceleration / deceleration ramp
    val maxAccel = 360f // deg/s^2
    var anyMotion = false
    for (i in 0..5) {
      val diff = targetVelocities[i] - currentJointVelocities[i]
      val maxStep = maxAccel * dt
      val step = diff.coerceIn(-maxStep, maxStep)
      currentJointVelocities[i] += step
      if (abs(currentJointVelocities[i]) > 0.05f) {
        anyMotion = true
      }
    }

    // 3. Integrate joint positions and enforce limits
    val nearLimits = mutableListOf<Int>()
    for (i in 0..5) {
      val nextPos = currentJoints[i] + currentJointVelocities[i] * dt
      val minL = RobotKinematics.JOINT_LIMITS_MIN[i]
      val maxL = RobotKinematics.JOINT_LIMITS_MAX[i]

      if (nextPos <= minL) {
        currentJoints[i] = minL
        currentJointVelocities[i] = 0f
        nearLimits.add(i)
      } else if (nextPos >= maxL) {
        currentJoints[i] = maxL
        currentJointVelocities[i] = 0f
        nearLimits.add(i)
      } else {
        currentJoints[i] = nextPos
        if (nextPos - minL < 10f || maxL - nextPos < 10f) {
          nearLimits.add(i)
        }
      }
    }

    // 4. Kinematics solution & collision check
    val fk = RobotKinematics.forwardKinematics(currentJoints)
    val collisionMessage = RobotKinematics.checkCollision(fk)

    if (collisionMessage != null && controlState != ControlState.FAULTED) {
      controlState = ControlState.PROTECTIVE_STOP
      activeFault = "SAFETY COLLISION: $collisionMessage"
      // Stop velocities immediately
      for (i in 0..5) currentJointVelocities[i] = 0f
    }

    // 5. Gripper position actuation and pick-and-place simulation
    val gripperStep = 2.5f * dt
    if (abs(currentGripperPos - targetGripperPos) > 0.01f) {
      val gDiff = (targetGripperPos - currentGripperPos).coerceIn(-gripperStep, gripperStep)
      currentGripperPos += gDiff
    } else {
      currentGripperPos = targetGripperPos
    }

    // Check pick-and-place grasp proximity
    val toolTip = fk.toolPose
    val dx = toolTip.x - blockLocation[0]
    val dy = toolTip.y - blockLocation[1]
    val dz = toolTip.z - blockLocation[2]
    val distToBlock = kotlin.math.sqrt(dx * dx + dy * dy + dz * dz)

    if (currentGripperPos > 0.6f && distToBlock < 55f) {
      // Grasp block
      isHoldingBlock = true
      blockLocation[0] = toolTip.x
      blockLocation[1] = toolTip.y
      blockLocation[2] = toolTip.z - 25f
    } else if (currentGripperPos < 0.3f && isHoldingBlock) {
      // Release block onto table or floor
      isHoldingBlock = false
      blockLocation[2] = max(80f, blockLocation[2])
    }

    // Velocity summary strings
    val reqSummary = if (intent != null && intent.enableState && !isWatchdogExpired) {
      if (intent.controlMode == ControlMode.JOINT_JOG) {
        "JOG: J${(intent.jointVelocitiesDegPerSec?.indexOfFirst { abs(it) > 0.1f } ?: 0) + 1}"
      } else {
        "CART: ${intent.coordinateFrame.name}"
      }
    } else {
      "Neutral / Hold"
    }

    val confSummary = if (anyMotion) {
      "Moving (%.1f mm/s)".format(RobotKinematics.forwardKinematics(currentJoints).toolPose.x * 0.05f)
    } else {
      "Holding Position"
    }

    // Publish state
    _telemetry.value = _telemetry.value.copy(
      timestamp = now,
      jointPositionsDeg = currentJoints.clone(),
      jointVelocitiesDegPerSec = currentJointVelocities.clone(),
      toolPose = fk.toolPose,
      gripperPosition = currentGripperPos,
      isGripperHoldingObject = isHoldingBlock,
      heldObjectName = if (isHoldingBlock) "Gold Machined Block" else null,
      controlState = controlState,
      activeMode = intent?.controlMode ?: state.activeMode,
      activeFrame = intent?.coordinateFrame ?: state.activeFrame,
      requestedSpeedLimitPercent = intent?.speedScalePercent ?: state.requestedSpeedLimitPercent,
      appliedSpeedPercent = if (anyMotion) (intent?.speedScalePercent ?: 30f) else 0f,
      telemetryAgeMs = now - (intent?.timestamp ?: now),
      watchdogRemainingMs = remainingWatchdog,
      isSingularityNear = fk.isSingular,
      singularityWarningText = fk.singularityReason,
      nearLimitJoints = nearLimits,
      activeFaultMessage = activeFault,
      confirmedSequenceNumber = highestSeqNumber,
      requestedVelocitySummary = reqSummary,
      confirmedVelocitySummary = confSummary
    )
  }

  override suspend fun connect(endpoint: String): Result<Unit> {
    isConnected = true
    _telemetry.value = _telemetry.value.copy(controlState = ControlState.READY)
    return Result.success(Unit)
  }

  override suspend fun disconnect() {
    isConnected = false
    simLoopJob?.cancel()
    latestIntent = null
    _telemetry.value = _telemetry.value.copy(controlState = ControlState.DISCONNECTED)
  }

  override fun sendMotionIntent(intent: MotionIntent) {
    if (!isConnected) return

    val now = System.currentTimeMillis()

    // Enforce sequence ordering and TTL
    if (intent.sequenceNumber <= highestSeqNumber) {
      // Reject out-of-order or duplicate packet
      return
    }

    if (intent.isExpired) {
      // Reject stale packet
      return
    }

    highestSeqNumber = intent.sequenceNumber
    lastValidIntentTime = now
    latestIntent = intent
    _telemetry.value = _telemetry.value.copy(confirmedSequenceNumber = highestSeqNumber)
  }

  override fun sendGripperIntent(intent: GripperIntent) {
    targetGripperPos = if (intent.closeRequest) 1.0f else 0.0f
  }

  override fun sendStopRequest(request: StopRequest) {
    latestIntent = null
    for (i in 0..5) currentJointVelocities[i] = 0f
    _telemetry.value = _telemetry.value.copy(
      controlState = if (request.isEmergency) ControlState.ESTOP else ControlState.READY,
      activeFaultMessage = if (request.isEmergency) "OPERATOR EMERGENCY STOP REQUESTED" else null
    )
  }

  override fun clearFault() {
    activeSimFault = SimulatedFault.NONE
    _telemetry.value = _telemetry.value.copy(
      controlState = ControlState.READY,
      activeFaultMessage = null
    )
  }

  override fun injectFault(faultType: SimulatedFault) {
    activeSimFault = faultType
    when (faultType) {
      SimulatedFault.NONE -> clearFault()
      SimulatedFault.NETWORK_TIMEOUT -> {
        faultRecoveryDeadline = System.currentTimeMillis() + 3000L
      }
      SimulatedFault.JOINT_OVERTEMP -> {
        _telemetry.value = _telemetry.value.copy(
          controlState = ControlState.PROTECTIVE_STOP,
          activeFaultMessage = "FAULT: Joint 3 motor temperature 98°C exceeds threshold"
        )
      }
      SimulatedFault.ESTOP_TRIGGERED -> {
        sendStopRequest(StopRequest("sim_fault", isEmergency = true, reason = "Simulated Safety Interlock Open"))
      }
      SimulatedFault.STALE_PACKET_STORM -> {
        // Drop timestamp into past to simulate stale packets
      }
    }
  }

  override fun resetSimulation(homePose: Boolean) {
    clearFault()
    latestIntent = null
    currentJoints = defaultHomeJoints.clone()
    for (i in 0..5) currentJointVelocities[i] = 0f
    currentGripperPos = 0f
    targetGripperPos = 0f
    isHoldingBlock = false
    blockLocation = floatArrayOf(340f, 70f, 95f)
    _telemetry.value = RobotState(
      jointPositionsDeg = currentJoints.clone(),
      toolPose = RobotKinematics.forwardKinematics(currentJoints).toolPose,
      controlState = ControlState.READY
    )
  }
}
