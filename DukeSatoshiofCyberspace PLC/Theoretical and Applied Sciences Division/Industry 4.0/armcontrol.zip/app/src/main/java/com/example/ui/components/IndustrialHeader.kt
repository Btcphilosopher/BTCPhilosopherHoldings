package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ControlState
import com.example.model.RobotState
import com.example.ui.theme.AureomGoldPrimary
import com.example.ui.theme.SafetyAmber
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.SafetyRed

@Composable
fun IndustrialHeader(
  robotState: RobotState,
  isDarkTheme: Boolean,
  onToggleTheme: () -> Unit,
  onEmergencyStop: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    modifier = modifier.fillMaxWidth(),
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 2.dp
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      // Branding & Title
      Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(10.dp)
              .clip(CircleShape)
              .background(AureomGoldPrimary)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "AUREOM.AI",
            style = MaterialTheme.typography.labelLarge,
            color = AureomGoldPrimary,
            letterSpacing = 1.2.sp
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "ARMCONTROL",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
        Text(
          text = "6-DOF Precision Articulated Manipulator | Profile: v1.0",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      // Middle status telemetry badge
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        // State badge
        ControlStateBadge(robotState.controlState)

        // Telemetry latency / Watchdog
        Column(horizontalAlignment = Alignment.End) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "WD: ${robotState.watchdogRemainingMs}ms",
              style = MaterialTheme.typography.labelSmall,
              color = if (robotState.watchdogRemainingMs < 80) SafetyAmber else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "SEQ #${robotState.confirmedSequenceNumber}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          Spacer(modifier = Modifier.height(4.dp))
          val wdFraction = (robotState.watchdogRemainingMs / 250f).coerceIn(0f, 1f)
          LinearProgressIndicator(
            progress = { wdFraction },
            modifier = Modifier
              .width(90.dp)
              .height(3.dp)
              .clip(RoundedCornerShape(2.dp)),
            color = if (wdFraction < 0.35f) SafetyAmber else AureomGoldPrimary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
          )
        }
      }

      // Action controls: Theme toggle + Emergency Stop
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = onToggleTheme,
          modifier = Modifier.testTag("theme_toggle_btn")
        ) {
          Icon(
            imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
            contentDescription = "Toggle Light/Dark Mode",
            tint = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Large prominent Emergency Stop button
        Button(
          onClick = onEmergencyStop,
          colors = ButtonDefaults.buttonColors(
            containerColor = SafetyRed,
            contentColor = Color.White
          ),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier
            .height(42.dp)
            .testTag("emergency_stop_header_btn")
        ) {
          Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = "E-Stop",
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "E-STOP",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelLarge
          )
        }
      }
    }
  }
}

@Composable
fun ControlStateBadge(state: ControlState) {
  val (bgColor, textColor, text) = when (state) {
    ControlState.DISCONNECTED -> Triple(Color(0xFF333742), Color(0xFFA0A6B2), "DISCONNECTED")
    ControlState.CONNECTED -> Triple(Color(0xFF1E2838), Color(0xFF82B1FF), "CONNECTED")
    ControlState.READY -> Triple(Color(0xFF2C2618), AureomGoldPrimary, "READY (DEADMAN OFF)")
    ControlState.ENABLED -> Triple(Color(0xFF123620), SafetyGreen, "DEADMAN ENGAGED")
    ControlState.MOVING -> Triple(SafetyGreen, Color(0xFF072412), "MOVING")
    ControlState.PAUSED -> Triple(Color(0xFF332A15), SafetyAmber, "PAUSED")
    ControlState.FAULTED, ControlState.PROTECTIVE_STOP -> Triple(Color(0xFF451414), SafetyRed, state.label.uppercase())
    ControlState.ESTOP -> Triple(SafetyRed, Color.White, "EMERGENCY STOP")
  }

  Surface(
    color = bgColor,
    shape = RoundedCornerShape(6.dp)
  ) {
    Text(
      text = text,
      color = textColor,
      fontWeight = FontWeight.Bold,
      style = MaterialTheme.typography.labelSmall,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
    )
  }
}
