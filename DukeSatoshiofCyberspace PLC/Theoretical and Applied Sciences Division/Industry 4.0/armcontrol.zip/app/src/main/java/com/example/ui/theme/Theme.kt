package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AureomDarkColorScheme = darkColorScheme(
  primary = AureomGoldPrimary,
  onPrimary = Color(0xFF191202),
  primaryContainer = AureomGoldContainer,
  onPrimaryContainer = AureomGoldOnContainer,
  secondary = AureomSecondary,
  onSecondary = Color(0xFF1E1A14),
  secondaryContainer = AureomSecondaryContainer,
  onSecondaryContainer = AureomOnSecondaryContainer,
  tertiary = SafetyBlue,
  onTertiary = Color(0xFF00344A),
  background = IndustrialBgDark,
  onBackground = TextPrimaryDark,
  surface = IndustrialSurfaceDark,
  onSurface = TextPrimaryDark,
  surfaceVariant = IndustrialSurfaceVariantDark,
  onSurfaceVariant = TextSecondaryDark,
  outline = IndustrialOutlineDark,
  error = SafetyRed,
  onError = Color.White
)

private val AureomLightColorScheme = lightColorScheme(
  primary = AureomGoldDark,
  onPrimary = Color.White,
  primaryContainer = AureomGoldLight,
  onPrimaryContainer = Color(0xFF291A00),
  secondary = Color(0xFF6A5E48),
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFF3EEDF),
  onSecondaryContainer = Color(0xFF231C0B),
  tertiary = Color(0xFF0277BD),
  onTertiary = Color.White,
  background = IndustrialBgLight,
  onBackground = TextPrimaryLight,
  surface = IndustrialSurfaceLight,
  onSurface = TextPrimaryLight,
  surfaceVariant = IndustrialSurfaceVariantLight,
  onSurfaceVariant = TextSecondaryLight,
  outline = IndustrialOutlineLight,
  error = SafetyRed,
  onError = Color.White
)

@Composable
fun AureomArmTheme(
  darkTheme: Boolean = true, // Default to industrial dark theme
  content: @Composable () -> Unit
) {
  val colorScheme = if (darkTheme) AureomDarkColorScheme else AureomLightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
