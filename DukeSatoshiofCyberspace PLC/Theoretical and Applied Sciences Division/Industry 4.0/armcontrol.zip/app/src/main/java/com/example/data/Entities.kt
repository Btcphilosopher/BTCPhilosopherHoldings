package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "teach_jobs")
data class TeachJobEntity(
  @PrimaryKey val id: String,
  val title: String,
  val description: String,
  val robotProfileId: String,
  val createdAt: Long,
  val waypointsJson: String
)

@Entity(tableName = "controller_profiles")
data class ControllerProfileEntity(
  @PrimaryKey val id: String,
  val name: String,
  val deviceDescriptor: String,
  val deadzoneLeft: Float,
  val deadzoneRight: Float,
  val deadzoneTrigger: Float,
  val responseCurve: String,
  val invertLeftY: Boolean,
  val invertRightY: Boolean
)
