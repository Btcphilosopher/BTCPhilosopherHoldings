package com.example.adapter

import com.example.model.ControlMode
import com.example.model.ControlState
import com.example.model.CoordinateFrame
import com.example.model.GripperIntent
import com.example.model.MotionIntent
import com.example.model.Pose3D
import com.example.model.RobotState
import com.example.model.StopRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class WebSocketRobotAdapter(
  private val scope: CoroutineScope
) : RobotAdapter {

  override val name: String = "External Python WebSocket Gateway"
  override var isConnected: Boolean = false
    private set

  private val _telemetry = MutableStateFlow(RobotState(controlState = ControlState.DISCONNECTED))
  override fun observeTelemetry(): StateFlow<RobotState> = _telemetry.asStateFlow()

  private val client = OkHttpClient.Builder()
    .readTimeout(3, TimeUnit.SECONDS)
    .connectTimeout(3, TimeUnit.SECONDS)
    .build()

  private var webSocket: WebSocket? = null
  private var activeEndpoint: String = "ws://10.0.2.2:8765/robot"

  override suspend fun connect(endpoint: String): Result<Unit> {
    if (endpoint.isNotBlank()) {
      activeEndpoint = endpoint
    }

    return try {
      val request = Request.Builder().url(activeEndpoint).build()
      webSocket?.cancel()

      webSocket = client.newWebSocket(request, object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
          isConnected = true
          // Send handshake
          val handshake = JSONObject().apply {
            put("type", "HANDSHAKE_REQ")
            put("client", "Aureom.AI ArmControl Android")
            put("protocolVersion", "1.2")
            put("timestamp", System.currentTimeMillis())
          }
          webSocket.send(handshake.toString())
          _telemetry.value = _telemetry.value.copy(controlState = ControlState.READY)
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
          handleIncomingMessage(text)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
          isConnected = false
          _telemetry.value = _telemetry.value.copy(
            controlState = ControlState.DISCONNECTED,
            activeFaultMessage = "Gateway connection closed: $reason"
          )
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
          isConnected = false
          _telemetry.value = _telemetry.value.copy(
            controlState = ControlState.DISCONNECTED,
            activeFaultMessage = "Gateway connection error: ${t.localizedMessage ?: "Connection refused"}"
          )
        }
      })
      Result.success(Unit)
    } catch (e: Exception) {
      isConnected = false
      Result.failure(e)
    }
  }

  private fun handleIncomingMessage(text: String) {
    try {
      val json = JSONObject(text)
      val type = json.optString("type")

      if (type == "TELEMETRY" || type == "ROBOT_STATE") {
        val jointsArr = json.optJSONArray("joints")
        val joints = if (jointsArr != null) {
          FloatArray(jointsArr.length()) { i -> jointsArr.getDouble(i).toFloat() }
        } else {
          _telemetry.value.jointPositionsDeg
        }

        val toolObj = json.optJSONObject("tool")
        val toolPose = if (toolObj != null) {
          Pose3D(
            x = toolObj.optDouble("x", 0.0).toFloat(),
            y = toolObj.optDouble("y", 0.0).toFloat(),
            z = toolObj.optDouble("z", 0.0).toFloat(),
            roll = toolObj.optDouble("roll", 0.0).toFloat(),
            pitch = toolObj.optDouble("pitch", 0.0).toFloat(),
            yaw = toolObj.optDouble("yaw", 0.0).toFloat()
          )
        } else {
          _telemetry.value.toolPose
        }

        val stateStr = json.optString("state", "READY")
        val ctrlState = try {
          ControlState.valueOf(stateStr)
        } catch (_: Exception) {
          ControlState.READY
        }

        val gripperPos = json.optDouble("gripper", 0.0).toFloat()
        val watchdogMs = json.optLong("watchdogMs", 250L)
        val faultMsg = json.optString("fault").takeIf { it.isNotBlank() }

        scope.launch {
          _telemetry.value = _telemetry.value.copy(
            timestamp = System.currentTimeMillis(),
            jointPositionsDeg = joints,
            toolPose = toolPose,
            gripperPosition = gripperPos,
            controlState = ctrlState,
            watchdogRemainingMs = watchdogMs,
            activeFaultMessage = faultMsg
          )
        }
      }
    } catch (_: Exception) {
      // Parse exception ignored safely
    }
  }

  override suspend fun disconnect() {
    isConnected = false
    webSocket?.close(1000, "User initiated disconnect")
    webSocket = null
    _telemetry.value = _telemetry.value.copy(controlState = ControlState.DISCONNECTED)
  }

  override fun sendMotionIntent(intent: MotionIntent) {
    if (!isConnected || webSocket == null) return

    val json = JSONObject().apply {
      put("type", "MOTION_INTENT")
      put("sessionId", intent.sessionId)
      put("seq", intent.sequenceNumber)
      put("timestamp", intent.timestamp)
      put("ttlMs", intent.ttlMs)
      put("mode", intent.controlMode.name)
      put("frame", intent.coordinateFrame.name)
      put("speed", intent.speedScalePercent)
      put("enable", intent.enableState)

      if (intent.controlMode == ControlMode.JOINT_JOG && intent.jointVelocitiesDegPerSec != null) {
        val jv = JSONArray()
        for (v in intent.jointVelocitiesDegPerSec) jv.put(v.toDouble())
        put("jointVels", jv)
      } else if (intent.controlMode == ControlMode.CARTESIAN_JOG && intent.cartesianVelocity != null) {
        val cv = JSONObject().apply {
          put("vx", intent.cartesianVelocity.vx.toDouble())
          put("vy", intent.cartesianVelocity.vy.toDouble())
          put("vz", intent.cartesianVelocity.vz.toDouble())
          put("wx", intent.cartesianVelocity.wx.toDouble())
          put("wy", intent.cartesianVelocity.wy.toDouble())
          put("wz", intent.cartesianVelocity.wz.toDouble())
        }
        put("cartesianVel", cv)
      }
    }

    webSocket?.send(json.toString())
  }

  override fun sendGripperIntent(intent: GripperIntent) {
    if (!isConnected || webSocket == null) return
    val json = JSONObject().apply {
      put("type", "GRIPPER_INTENT")
      put("sessionId", intent.sessionId)
      put("close", intent.closeRequest)
      put("target", intent.targetPosition.toDouble())
    }
    webSocket?.send(json.toString())
  }

  override fun sendStopRequest(request: StopRequest) {
    val json = JSONObject().apply {
      put("type", "STOP_REQ")
      put("sessionId", request.sessionId)
      put("isEmergency", request.isEmergency)
      put("reason", request.reason)
    }
    webSocket?.send(json.toString())
  }

  override fun clearFault() {
    val json = JSONObject().apply {
      put("type", "CLEAR_FAULT_REQ")
    }
    webSocket?.send(json.toString())
  }

  override fun injectFault(faultType: SimulatedFault) {
    val json = JSONObject().apply {
      put("type", "INJECT_FAULT")
      put("faultType", faultType.name)
    }
    webSocket?.send(json.toString())
  }

  override fun resetSimulation(homePose: Boolean) {
    val json = JSONObject().apply {
      put("type", "RESET_SIMULATION")
      put("home", homePose)
    }
    webSocket?.send(json.toString())
  }
}
