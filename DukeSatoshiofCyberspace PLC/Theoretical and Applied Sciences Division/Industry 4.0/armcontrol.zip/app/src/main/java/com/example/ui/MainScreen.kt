package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.IndustrialHeader
import com.example.ui.screens.ConnectScreen
import com.example.ui.screens.DiagnosticsScreen
import com.example.ui.screens.JobsScreen
import com.example.ui.screens.OperateScreen
import com.example.ui.screens.TeachScreen
import com.example.ui.theme.AureomGoldPrimary
import com.example.viewmodel.AppScreen
import com.example.viewmodel.ArmControlViewModel

data class NavDestination(
  val screen: AppScreen,
  val icon: ImageVector,
  val testTag: String
)

val NAV_ITEMS = listOf(
  NavDestination(AppScreen.CONNECT, Icons.Default.Cable, "nav_connect"),
  NavDestination(AppScreen.OPERATE, Icons.Default.PrecisionManufacturing, "nav_operate"),
  NavDestination(AppScreen.TEACH, Icons.Default.Gesture, "nav_teach"),
  NavDestination(AppScreen.JOBS, Icons.Default.PlayCircle, "nav_jobs"),
  NavDestination(AppScreen.DIAGNOSTICS, Icons.Default.Analytics, "nav_diagnostics")
)

@Composable
fun MainScreen(viewModel: ArmControlViewModel) {
  val currentScreen by viewModel.currentScreen.collectAsState()
  val robotState by viewModel.robotState.collectAsState()
  val isDarkTheme by viewModel.isDarkTheme.collectAsState()

  BoxWithConstraints(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
    val isWideScreen = maxWidth > 650.dp

    if (isWideScreen) {
      // Landscape Tablet / Wide layout with NavigationRail
      Row(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
        NavigationRail(
          modifier = Modifier.fillMaxHeight(),
          containerColor = MaterialTheme.colorScheme.surface,
          contentColor = MaterialTheme.colorScheme.onSurface
        ) {
          Spacer(modifier = Modifier.height(12.dp))
          NAV_ITEMS.forEach { item ->
            val selected = currentScreen == item.screen
            NavigationRailItem(
              selected = selected,
              onClick = { viewModel.setScreen(item.screen) },
              icon = {
                Icon(
                  imageVector = item.icon,
                  contentDescription = item.screen.label,
                  modifier = Modifier.size(22.dp)
                )
              },
              label = { Text(item.screen.label, fontSize = 11.sp) },
              colors = NavigationRailItemDefaults.colors(
                selectedIconColor = Color(0xFF1B1403),
                selectedTextColor = AureomGoldPrimary,
                indicatorColor = AureomGoldPrimary,
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
              ),
              modifier = Modifier.testTag(item.testTag)
            )
          }
        }

        Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
          IndustrialHeader(
            robotState = robotState,
            isDarkTheme = isDarkTheme,
            onToggleTheme = { viewModel.toggleTheme() },
            onEmergencyStop = { viewModel.triggerEmergencyStop() }
          )

          Box(modifier = Modifier.weight(1f)) {
            ScreenContent(currentScreen = currentScreen, viewModel = viewModel)
          }
        }
      }
    } else {
      // Portrait / Compact layout with Bottom NavigationBar
      Scaffold(
        modifier = Modifier.fillMaxSize().safeDrawingPadding(),
        topBar = {
          IndustrialHeader(
            robotState = robotState,
            isDarkTheme = isDarkTheme,
            onToggleTheme = { viewModel.toggleTheme() },
            onEmergencyStop = { viewModel.triggerEmergencyStop() }
          )
        },
        bottomBar = {
          NavigationBar(
            containerColor = MaterialTheme.colorScheme.surface,
            modifier = Modifier.navigationBarsPadding()
          ) {
            NAV_ITEMS.forEach { item ->
              val selected = currentScreen == item.screen
              NavigationBarItem(
                selected = selected,
                onClick = { viewModel.setScreen(item.screen) },
                icon = {
                  Icon(
                    imageVector = item.icon,
                    contentDescription = item.screen.label,
                    modifier = Modifier.size(20.dp)
                  )
                },
                label = { Text(item.screen.label, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                  selectedIconColor = Color(0xFF1B1403),
                  selectedTextColor = AureomGoldPrimary,
                  indicatorColor = AureomGoldPrimary,
                  unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                  unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier.testTag(item.testTag)
              )
            }
          }
        }
      ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
          ScreenContent(currentScreen = currentScreen, viewModel = viewModel)
        }
      }
    }
  }
}

@Composable
private fun ScreenContent(currentScreen: AppScreen, viewModel: ArmControlViewModel) {
  when (currentScreen) {
    AppScreen.CONNECT -> ConnectScreen(viewModel = viewModel)
    AppScreen.OPERATE -> OperateScreen(viewModel = viewModel)
    AppScreen.TEACH -> TeachScreen(viewModel = viewModel)
    AppScreen.JOBS -> JobsScreen(viewModel = viewModel)
    AppScreen.DIAGNOSTICS -> DiagnosticsScreen(viewModel = viewModel)
  }
}
