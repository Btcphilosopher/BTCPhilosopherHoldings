package com.example.model

/**
 * A recorded or user-programmed teach waypoint.
 */
data class TeachWaypoint(
  val id: String = java.util.UUID.randomUUID().toString(),
  val name: String,
  val jointPositionsDeg: List<Float>,
  val toolPose: Pose3D,
  val gripperClosed: Boolean = false,
  val dwellSeconds: Float = 0.5f,
  val speedPercent: Float = 30f,
  val isValid: Boolean = true,
  val validationMessage: String? = null
)

/**
 * A sequence of waypoints forming a robot job.
 */
data class TeachJob(
  val id: String = java.util.UUID.randomUUID().toString(),
  val title: String,
  val description: String,
  val robotProfileId: String = "Aureom-6DOF-v1.0",
  val createdAt: Long = System.currentTimeMillis(),
  val waypoints: List<TeachWaypoint> = emptyList()
)

enum class ValidationSeverity {
  INFO, WARNING, CRITICAL
}

data class ValidationIssue(
  val waypointIndex: Int,
  val segmentName: String,
  val message: String,
  val severity: ValidationSeverity
)

data class PathValidationResult(
  val isExecutable: Boolean,
  val totalWaypoints: Int,
  val validSegments: Int,
  val invalidSegments: Int,
  val estimatedDurationSeconds: Float,
  val issues: List<ValidationIssue> = emptyList()
)
