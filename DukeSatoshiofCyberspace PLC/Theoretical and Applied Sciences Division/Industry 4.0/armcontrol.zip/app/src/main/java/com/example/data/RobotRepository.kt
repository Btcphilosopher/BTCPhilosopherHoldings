package com.example.data

import com.example.model.ControllerProfile
import com.example.model.Pose3D
import com.example.model.ResponseCurve
import com.example.model.TeachJob
import com.example.model.TeachWaypoint
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

class RobotRepository(
  private val teachJobDao: TeachJobDao,
  private val controllerProfileDao: ControllerProfileDao
) {

  val allJobs: Flow<List<TeachJob>> = teachJobDao.getAllJobs().map { entities ->
    if (entities.isEmpty()) {
      getPrebuiltJobs()
    } else {
      entities.map { entityToJob(it) }
    }
  }

  suspend fun saveJob(job: TeachJob) {
    teachJobDao.insertJob(jobToEntity(job))
  }

  suspend fun deleteJob(id: String) {
    teachJobDao.deleteJobById(id)
  }

  suspend fun seedDefaultDataIfEmpty() {
    // Initial seeding
  }

  // --- Mappers ---

  private fun jobToEntity(job: TeachJob): TeachJobEntity {
    val wpArr = JSONArray()
    for (wp in job.waypoints) {
      val obj = JSONObject().apply {
        put("id", wp.id)
        put("name", wp.name)
        val jArr = JSONArray()
        wp.jointPositionsDeg.forEach { jArr.put(it.toDouble()) }
        put("joints", jArr)
        val pObj = JSONObject().apply {
          put("x", wp.toolPose.x.toDouble())
          put("y", wp.toolPose.y.toDouble())
          put("z", wp.toolPose.z.toDouble())
          put("roll", wp.toolPose.roll.toDouble())
          put("pitch", wp.toolPose.pitch.toDouble())
          put("yaw", wp.toolPose.yaw.toDouble())
        }
        put("toolPose", pObj)
        put("gripperClosed", wp.gripperClosed)
        put("dwellSeconds", wp.dwellSeconds.toDouble())
        put("speedPercent", wp.speedPercent.toDouble())
        put("isValid", wp.isValid)
        put("validationMessage", wp.validationMessage ?: "")
      }
      wpArr.put(obj)
    }

    return TeachJobEntity(
      id = job.id,
      title = job.title,
      description = job.description,
      robotProfileId = job.robotProfileId,
      createdAt = job.createdAt,
      waypointsJson = wpArr.toString()
    )
  }

  private fun entityToJob(entity: TeachJobEntity): TeachJob {
    val waypoints = mutableListOf<TeachWaypoint>()
    try {
      val wpArr = JSONArray(entity.waypointsJson)
      for (i in 0 until wpArr.length()) {
        val obj = wpArr.getJSONObject(i)
        val jArr = obj.getJSONArray("joints")
        val joints = mutableListOf<Float>()
        for (j in 0 until jArr.length()) {
          joints.add(jArr.getDouble(j).toFloat())
        }

        val pObj = obj.getJSONObject("toolPose")
        val pose = Pose3D(
          x = pObj.getDouble("x").toFloat(),
          y = pObj.getDouble("y").toFloat(),
          z = pObj.getDouble("z").toFloat(),
          roll = pObj.getDouble("roll").toFloat(),
          pitch = pObj.getDouble("pitch").toFloat(),
          yaw = pObj.getDouble("yaw").toFloat()
        )

        waypoints.add(
          TeachWaypoint(
            id = obj.getString("id"),
            name = obj.getString("name"),
            jointPositionsDeg = joints,
            toolPose = pose,
            gripperClosed = obj.getBoolean("gripperClosed"),
            dwellSeconds = obj.getDouble("dwellSeconds").toFloat(),
            speedPercent = obj.getDouble("speedPercent").toFloat(),
            isValid = obj.optBoolean("isValid", true),
            validationMessage = obj.optString("validationMessage").takeIf { it.isNotBlank() }
          )
        )
      }
    } catch (_: Exception) {
      // Fallback
    }

    return TeachJob(
      id = entity.id,
      title = entity.title,
      description = entity.description,
      robotProfileId = entity.robotProfileId,
      createdAt = entity.createdAt,
      waypoints = waypoints
    )
  }

  fun getPrebuiltJobs(): List<TeachJob> {
    return listOf(
      TeachJob(
        id = "job_pick_and_place",
        title = "Precision Pick & Place Demo",
        description = "Grasp machined gold block from table, lift over obstacle, and place at target station.",
        waypoints = listOf(
          TeachWaypoint(
            name = "Approach Stage",
            jointPositionsDeg = listOf(0f, -20f, 40f, 0f, 70f, 0f),
            toolPose = Pose3D(350f, 0f, 280f, 0f, 90f, 0f),
            gripperClosed = false,
            dwellSeconds = 0.5f,
            speedPercent = 35f
          ),
          TeachWaypoint(
            name = "Descend to Workpiece",
            jointPositionsDeg = listOf(11.5f, -32f, 58f, 0f, 64f, 11f),
            toolPose = Pose3D(340f, 70f, 115f, 0f, 90f, 11f),
            gripperClosed = false,
            dwellSeconds = 0.8f,
            speedPercent = 20f
          ),
          TeachWaypoint(
            name = "Grip Workpiece",
            jointPositionsDeg = listOf(11.5f, -32f, 58f, 0f, 64f, 11f),
            toolPose = Pose3D(340f, 70f, 115f, 0f, 90f, 11f),
            gripperClosed = true,
            dwellSeconds = 1.0f,
            speedPercent = 15f
          ),
          TeachWaypoint(
            name = "Lift & Clear Envelope",
            jointPositionsDeg = listOf(10f, -12f, 35f, 0f, 67f, 10f),
            toolPose = Pose3D(330f, 60f, 320f, 0f, 90f, 10f),
            gripperClosed = true,
            dwellSeconds = 0.5f,
            speedPercent = 30f
          ),
          TeachWaypoint(
            name = "Transfer Target Station",
            jointPositionsDeg = listOf(-25f, -15f, 38f, 0f, 67f, -25f),
            toolPose = Pose3D(300f, -140f, 310f, 0f, 90f, -25f),
            gripperClosed = true,
            dwellSeconds = 0.5f,
            speedPercent = 35f
          ),
          TeachWaypoint(
            name = "Descend Target Drop",
            jointPositionsDeg = listOf(-25f, -31f, 57f, 0f, 64f, -25f),
            toolPose = Pose3D(310f, -140f, 120f, 0f, 90f, -25f),
            gripperClosed = true,
            dwellSeconds = 0.6f,
            speedPercent = 20f
          ),
          TeachWaypoint(
            name = "Release Workpiece",
            jointPositionsDeg = listOf(-25f, -31f, 57f, 0f, 64f, -25f),
            toolPose = Pose3D(310f, -140f, 120f, 0f, 90f, -25f),
            gripperClosed = false,
            dwellSeconds = 1.0f,
            speedPercent = 15f
          ),
          TeachWaypoint(
            name = "Retract Home",
            jointPositionsDeg = listOf(0f, -25f, 45f, 0f, 70f, 0f),
            toolPose = Pose3D(350f, 0f, 280f, 0f, 90f, 0f),
            gripperClosed = false,
            dwellSeconds = 0.5f,
            speedPercent = 40f
          )
        )
      ),
      TeachJob(
        id = "job_surface_inspection",
        title = "Perimeter Inspection Scan",
        description = "Maintain constant tool normal orientation while tracing surface contour.",
        waypoints = listOf(
          TeachWaypoint(
            name = "Corner A",
            jointPositionsDeg = listOf(-15f, -22f, 44f, 0f, 68f, -15f),
            toolPose = Pose3D(250f, -100f, 200f, 0f, 90f, 0f),
            gripperClosed = false,
            dwellSeconds = 0.5f,
            speedPercent = 30f
          ),
          TeachWaypoint(
            name = "Corner B",
            jointPositionsDeg = listOf(-15f, -28f, 52f, 0f, 66f, -15f),
            toolPose = Pose3D(400f, -100f, 200f, 0f, 90f, 0f),
            gripperClosed = false,
            dwellSeconds = 0.5f,
            speedPercent = 25f
          ),
          TeachWaypoint(
            name = "Corner C",
            jointPositionsDeg = listOf(15f, -28f, 52f, 0f, 66f, 15f),
            toolPose = Pose3D(400f, 100f, 200f, 0f, 90f, 0f),
            gripperClosed = false,
            dwellSeconds = 0.5f,
            speedPercent = 25f
          ),
          TeachWaypoint(
            name = "Corner D",
            jointPositionsDeg = listOf(15f, -22f, 44f, 0f, 68f, 15f),
            toolPose = Pose3D(250f, 100f, 200f, 0f, 90f, 0f),
            gripperClosed = false,
            dwellSeconds = 0.5f,
            speedPercent = 25f
          )
        )
      )
    )
  }
}
