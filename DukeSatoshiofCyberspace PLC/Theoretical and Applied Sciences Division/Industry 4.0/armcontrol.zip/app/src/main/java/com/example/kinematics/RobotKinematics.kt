package com.example.kinematics

import com.example.model.CartesianVelocity
import com.example.model.CoordinateFrame
import com.example.model.Pose3D
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Point in 3D space (mm).
 */
data class Vector3(val x: Float, val y: Float, val z: Float) {
  operator fun plus(other: Vector3) = Vector3(x + other.x, y + other.y, z + other.z)
  operator fun minus(other: Vector3) = Vector3(x - other.x, y - other.y, z - other.z)
  operator fun times(scalar: Float) = Vector3(x * scalar, y * scalar, z * scalar)
  fun length(): Float = sqrt(x * x + y * y + z * z)
  fun normalized(): Vector3 {
    val l = length()
    return if (l > 1e-6f) Vector3(x / l, y / l, z / l) else Vector3(0f, 0f, 1f)
  }
}

/**
 * 3x3 Rotation matrix.
 */
data class Matrix3x3(val m: FloatArray) {
  operator fun times(v: Vector3): Vector3 {
    return Vector3(
      m[0] * v.x + m[1] * v.y + m[2] * v.z,
      m[3] * v.x + m[4] * v.y + m[5] * v.z,
      m[6] * v.x + m[7] * v.y + m[8] * v.z
    )
  }

  operator fun times(o: Matrix3x3): Matrix3x3 {
    val r = FloatArray(9)
    for (i in 0..2) {
      for (j in 0..2) {
        var sum = 0f
        for (k in 0..2) {
          sum += m[i * 3 + k] * o.m[k * 3 + j]
        }
        r[i * 3 + j] = sum
      }
    }
    return Matrix3x3(r)
  }

  fun transpose(): Matrix3x3 {
    return Matrix3x3(
      floatArrayOf(
        m[0], m[3], m[6],
        m[1], m[4], m[7],
        m[2], m[5], m[8]
      )
    )
  }

  companion object {
    val IDENTITY = Matrix3x3(floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f))

    fun fromEulerZYX(rollDeg: Float, pitchDeg: Float, yawDeg: Float): Matrix3x3 {
      val r = rollDeg * (PI.toFloat() / 180f)
      val p = pitchDeg * (PI.toFloat() / 180f)
      val y = yawDeg * (PI.toFloat() / 180f)

      val cy = cos(y); val sy = sin(y)
      val cp = cos(p); val sp = sin(p)
      val cr = cos(r); val sr = sin(r)

      return Matrix3x3(
        floatArrayOf(
          cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr,
          sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr,
          -sp, cp * sr, cp * cr
        )
      )
    }
  }
}

/**
 * Forward Kinematic solution containing link points in world coordinates
 * and the final end-effector Pose3D.
 */
data class KinematicChainState(
  val jointPositions: List<Vector3>,
  val toolPose: Pose3D,
  val toolRotation: Matrix3x3,
  val isSingular: Boolean,
  val singularityReason: String? = null
)

/**
 * Industrial 6-Axis Robot Kinematics Engine.
 * Geometric link structure:
 *  Base -> d1=160 -> J2 -> a2=250 -> J3 -> a3=220 -> J4 -> d4=120 -> J5 -> d5=90 -> J6 -> d6=110 (Tool)
 */
object RobotKinematics {

  const val D1 = 160f   // Base height (mm)
  const val A2 = 250f   // Shoulder arm length (mm)
  const val A3 = 220f   // Elbow arm length (mm)
  const val D4 = 120f   // Forearm extension (mm)
  const val D5 = 90f    // Wrist pivot (mm)
  const val D6 = 110f   // Flange to gripper tip (mm)

  const val MAX_REACH_MM = 750f
  const val MIN_REACH_MM = 120f

  // Joint limits (degrees)
  val JOINT_LIMITS_MIN = floatArrayOf(-170f, -115f, -145f, -180f, -115f, -360f)
  val JOINT_LIMITS_MAX = floatArrayOf(170f, 115f, 145f, 180f, 115f, 360f)

  // Max velocities (deg/s)
  val JOINT_MAX_VELOCITY = floatArrayOf(120f, 100f, 120f, 180f, 180f, 240f)

  // Linear / Angular cartesian limits
  const val MAX_CARTESIAN_LINEAR_VEL_MM_S = 250f
  const val MAX_CARTESIAN_ANGULAR_VEL_DEG_S = 90f

  /**
   * Compute Forward Kinematics for joint angles in degrees.
   */
  fun forwardKinematics(jointsDeg: FloatArray): KinematicChainState {
    val q = jointsDeg.map { it * (PI.toFloat() / 180f) }

    val q1 = q[0]
    val q2 = q[1]
    val q3 = q[2]
    val q4 = q[3]
    val q5 = q[4]
    val q6 = q[5]

    // Origin: Base mounting plate
    val p0 = Vector3(0f, 0f, 0f)

    // J1: Shoulder pivot at base height
    val p1 = Vector3(0f, 0f, D1)

    // Rotation matrices
    // Base rotation around Z
    val rZ1 = Matrix3x3(
      floatArrayOf(
        cos(q1), -sin(q1), 0f,
        sin(q1), cos(q1), 0f,
        0f, 0f, 1f
      )
    )

    // Shoulder angle around local Y
    val rY2 = Matrix3x3(
      floatArrayOf(
        cos(q2), 0f, sin(q2),
        0f, 1f, 0f,
        -sin(q2), 0f, cos(q2)
      )
    )

    // Elbow angle around local Y
    val rY3 = Matrix3x3(
      floatArrayOf(
        cos(q3), 0f, sin(q3),
        0f, 1f, 0f,
        -sin(q3), 0f, cos(q3)
      )
    )

    // Wrist roll around local X
    val rX4 = Matrix3x3(
      floatArrayOf(
        1f, 0f, 0f,
        0f, cos(q4), -sin(q4),
        0f, sin(q4), cos(q4)
      )
    )

    // Wrist pitch around local Y
    val rY5 = Matrix3x3(
      floatArrayOf(
        cos(q5), 0f, sin(q5),
        0f, 1f, 0f,
        -sin(q5), 0f, cos(q5)
      )
    )

    // Flange roll around local Z
    val rZ6 = Matrix3x3(
      floatArrayOf(
        cos(q6), -sin(q6), 0f,
        sin(q6), cos(q6), 0f,
        0f, 0f, 1f
      )
    )

    val rot1 = rZ1
    val rot2 = rot1 * rY2
    val rot3 = rot2 * rY3
    val rot4 = rot3 * rX4
    val rot5 = rot4 * rY5
    val rot6 = rot5 * rZ6

    // Link 2 vector along local Z of shoulder
    val vShoulder = rot2 * Vector3(0f, 0f, A2)
    val p2 = p1 + vShoulder

    // Link 3 vector along local Z of elbow
    val vElbow = rot3 * Vector3(0f, 0f, A3)
    val p3 = p2 + vElbow

    // Forearm extension to wrist
    val vWrist = rot4 * Vector3(0f, 0f, D4)
    val p4 = p3 + vWrist

    // Wrist bend to flange
    val vFlange = rot5 * Vector3(0f, 0f, D5)
    val p5 = p4 + vFlange

    // Flange to Tool center point (TCP)
    val vTool = rot6 * Vector3(0f, 0f, D6)
    val p6 = p5 + vTool

    // Extract Euler angles from rot6 (ZYX convention)
    val m = rot6.m
    val pitchRad = atan2(-m[6], sqrt(m[0] * m[0] + m[3] * m[3]))
    val rollRad = atan2(m[7], m[8])
    val yawRad = atan2(m[3], m[0])

    val toolPose = Pose3D(
      x = p6.x,
      y = p6.y,
      z = p6.z,
      roll = rollRad * (180f / PI.toFloat()),
      pitch = pitchRad * (180f / PI.toFloat()),
      yaw = yawRad * (180f / PI.toFloat())
    )

    // Singularity detection
    val isWristSingular = abs(jointsDeg[4]) < 4f
    val rHorizontal = sqrt(p6.x * p6.x + p6.y * p6.y)
    val isShoulderSingular = rHorizontal < 60f
    val isExtendedSingular = p6.length() > (MAX_REACH_MM - 25f)

    var singularityReason: String? = null
    val isSingular = if (isWristSingular) {
      singularityReason = "Wrist Alignment Singularity (|J5| < 4°)"
      true
    } else if (isShoulderSingular) {
      singularityReason = "Overhead Shoulder Singularity (Radius < 60mm)"
      true
    } else if (isExtendedSingular) {
      singularityReason = "Workspace Boundary Singularity (Near Maximum Reach)"
      true
    } else {
      false
    }

    return KinematicChainState(
      jointPositions = listOf(p0, p1, p2, p3, p4, p5, p6),
      toolPose = toolPose,
      toolRotation = rot6,
      isSingular = isSingular,
      singularityReason = singularityReason
    )
  }

  /**
   * Numerical Inverse Kinematics using Damped Least Squares (DLS) Jacobian pseudo-inverse.
   * Maps Cartesian velocity (linear mm/s, angular deg/s) to Joint velocities (deg/s).
   */
  fun solveCartesianVelocity(
    currentJointsDeg: FloatArray,
    cartesianVel: CartesianVelocity,
    frame: CoordinateFrame
  ): FloatArray {
    if (cartesianVel.isZero) {
      return FloatArray(6) { 0f }
    }

    val fkCurrent = forwardKinematics(currentJointsDeg)

    // Transform velocity from TOOL frame to BASE frame if needed
    val (effectiveLinear, effectiveAngular) = if (frame == CoordinateFrame.TOOL) {
      val vTool = Vector3(cartesianVel.vx, cartesianVel.vy, cartesianVel.vz)
      val wTool = Vector3(cartesianVel.wx, cartesianVel.wy, cartesianVel.wz)
      val vBase = fkCurrent.toolRotation * vTool
      val wBase = fkCurrent.toolRotation * wTool
      Pair(vBase, wBase)
    } else {
      Pair(
        Vector3(cartesianVel.vx, cartesianVel.vy, cartesianVel.vz),
        Vector3(cartesianVel.wx, cartesianVel.wy, cartesianVel.wz)
      )
    }

    // Finite difference Jacobian (6x6)
    val deltaDeg = 0.5f
    val J = Array(6) { FloatArray(6) }

    for (i in 0..5) {
      val perturbed = currentJointsDeg.clone()
      perturbed[i] += deltaDeg
      val fkPerturbed = forwardKinematics(perturbed)

      val deltaPos = fkPerturbed.toolPose
      val basePos = fkCurrent.toolPose

      // Linear velocity column (mm / deg)
      J[0][i] = (deltaPos.x - basePos.x) / deltaDeg
      J[1][i] = (deltaPos.y - basePos.y) / deltaDeg
      J[2][i] = (deltaPos.z - basePos.z) / deltaDeg

      // Angular velocity column (deg / deg)
      var dRoll = deltaPos.roll - basePos.roll
      var dPitch = deltaPos.pitch - basePos.pitch
      var dYaw = deltaPos.yaw - basePos.yaw
      if (dRoll > 180f) dRoll -= 360f else if (dRoll < -180f) dRoll += 360f
      if (dPitch > 180f) dPitch -= 360f else if (dPitch < -180f) dPitch += 360f
      if (dYaw > 180f) dYaw -= 360f else if (dYaw < -180f) dYaw += 360f

      J[3][i] = dRoll / deltaDeg
      J[4][i] = dPitch / deltaDeg
      J[5][i] = dYaw / deltaDeg
    }

    // Desired task velocity vector (6 elements)
    val vTarget = floatArrayOf(
      effectiveLinear.x,
      effectiveLinear.y,
      effectiveLinear.z,
      effectiveAngular.x,
      effectiveAngular.y,
      effectiveAngular.z
    )

    // Damped Least Squares: dq = J^T * (J * J^T + lambda^2 * I)^(-1) * vTarget
    val damping = if (fkCurrent.isSingular) 1.2f else 0.25f
    val lambdaSq = damping * damping

    // Compute A = J * J^T + lambdaSq * I (6x6)
    val A = Array(6) { FloatArray(6) }
    for (r in 0..5) {
      for (c in 0..5) {
        var sum = 0f
        for (k in 0..5) {
          sum += J[r][k] * J[c][k]
        }
        A[r][c] = sum + (if (r == c) lambdaSq else 0f)
      }
    }

    // Solve A * y = vTarget via Gaussian Elimination
    val y = solveLinearSystem6x6(A, vTarget) ?: return FloatArray(6) { 0f }

    // dq = J^T * y
    val dq = FloatArray(6)
    for (i in 0..5) {
      var sum = 0f
      for (r in 0..5) {
        sum += J[r][i] * y[r]
      }
      // Clamp joint speed to safety limits
      val maxVel = JOINT_MAX_VELOCITY[i]
      dq[i] = sum.coerceIn(-maxVel, maxVel)
    }

    return dq
  }

  /**
   * Helper 6x6 linear solver with partial pivoting.
   */
  private fun solveLinearSystem6x6(matrix: Array<FloatArray>, b: FloatArray): FloatArray? {
    val n = 6
    val A = Array(n) { r -> FloatArray(n) { c -> matrix[r][c] } }
    val x = b.clone()

    for (i in 0 until n) {
      var maxRow = i
      for (k in i + 1 until n) {
        if (abs(A[k][i]) > abs(A[maxRow][i])) {
          maxRow = k
        }
      }
      val tempRow = A[i]
      A[i] = A[maxRow]
      A[maxRow] = tempRow

      val tempB = x[i]
      x[i] = x[maxRow]
      x[maxRow] = tempB

      if (abs(A[i][i]) < 1e-5f) {
        // Ill-conditioned / singular
        return null
      }

      for (k in i + 1 until n) {
        val factor = A[k][i] / A[i][i]
        x[k] -= factor * x[i]
        for (j in i until n) {
          A[k][j] -= factor * A[i][j]
        }
      }
    }

    // Back substitution
    val sol = FloatArray(n)
    for (i in n - 1 downTo 0) {
      var sum = 0f
      for (j in i + 1 until n) {
        sum += A[i][j] * sol[j]
      }
      sol[i] = (x[i] - sum) / A[i][i]
    }
    return sol
  }

  /**
   * Check for self-collision and environment collisions (floor, workbench, obstacle cylinder).
   * Returns a description string if in collision, or null if clear.
   */
  fun checkCollision(chainState: KinematicChainState): String? {
    val points = chainState.jointPositions

    // 1. Floor collision check (Z must be >= 0)
    for (i in 1 until points.size) {
      if (points[i].z < -5f) {
        return "Floor boundary contact detected (Z = %.1f mm)".format(points[i].z)
      }
    }

    // 2. Workbench collision check
    // Table is positioned at X in [160, 560], Y in [-250, 250], height Z = 80mm
    val toolPoint = points.last()
    if (toolPoint.x in 160f..560f && toolPoint.y in -250f..250f) {
      if (toolPoint.z < 80f) {
        return "Workbench collision boundary contact (Z = %.1f mm)".format(toolPoint.z)
      }
    }

    // 3. Obstacle pillar check: cylinder at X=320, Y=-180, Radius=45, Height=200
    val pillarX = 320f
    val pillarY = -180f
    val pillarRadius = 45f
    val pillarHeight = 200f

    for (p in points.drop(2)) { // check elbow to tool
      val dx = p.x - pillarX
      val dy = p.y - pillarY
      val distSq = dx * dx + dy * dy
      if (distSq < (pillarRadius * pillarRadius) && p.z in 0f..pillarHeight) {
        return "Proximity safety stop: obstacle pillar envelope"
      }
    }

    return null
  }
}
