package com.example.controller

import kotlin.math.abs

/**
 * Enforces the critical safety rule:
 * Sticks MUST return to neutral (< deadzone) and Deadman trigger must be released
 * before manual motion can be armed or re-enabled following:
 *  - Connection or reconnection
 *  - Mode change (Joint <-> Cartesian <-> Teach)
 *  - Interruption (App paused/backgrounded, network drop)
 *  - Stop or Fault recovery
 */
class NeutralRearmManager(
  private var deadzoneStick: Float = 0.12f,
  private var deadmanThreshold: Float = 0.20f
) {
  // Whether system is currently rearmed and allowed to enable
  private var isRearmed: Boolean = false

  // Explanation if currently locked out
  private var lockoutReason: String = "Sticks must return to neutral center"

  fun updateDeadzone(stickDeadzone: Float, triggerThreshold: Float) {
    this.deadzoneStick = stickDeadzone
    this.deadmanThreshold = triggerThreshold
  }

  /**
   * Called on system reset, connect, mode change, fault, or stop.
   * Forces the operator to rearm before movement is possible.
   */
  fun requireRearm(reason: String) {
    isRearmed = false
    lockoutReason = reason
  }

  /**
   * Process raw/filtered inputs.
   * Only transitions to rearmed when ALL sticks are within the deadzone
   * AND the enable trigger is released.
   */
  fun evaluate(
    stickLX: Float,
    stickLY: Float,
    stickRX: Float,
    stickRY: Float,
    deadmanTrigger: Float
  ): Boolean {
    val isStickNeutral = abs(stickLX) < deadzoneStick &&
        abs(stickLY) < deadzoneStick &&
        abs(stickRX) < deadzoneStick &&
        abs(stickRY) < deadzoneStick

    val isTriggerReleased = deadmanTrigger < deadmanThreshold

    if (!isRearmed) {
      if (isStickNeutral && isTriggerReleased) {
        isRearmed = true
        lockoutReason = ""
      }
    }

    return isRearmed
  }

  val isArmed: Boolean
    get() = isRearmed

  val currentLockoutReason: String
    get() = lockoutReason
}
