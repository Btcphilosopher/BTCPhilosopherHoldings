package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ControlState
import com.example.model.RobotState
import com.example.ui.theme.AureomGoldPrimary
import com.example.ui.theme.SafetyAmber
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.SafetyRed

@Composable
fun SafetyBanner(
  robotState: RobotState,
  isNeutralRearmed: Boolean,
  isDeadmanEngaged: Boolean,
  onClearFault: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(4.dp)
  ) {
    // 1. Critical Fault / Protective Stop / ESTOP Banner
    if (robotState.controlState == ControlState.FAULTED ||
      robotState.controlState == ControlState.PROTECTIVE_STOP ||
      robotState.controlState == ControlState.ESTOP ||
      robotState.activeFaultMessage != null
    ) {
      Surface(
        color = Color(0xFF381010),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Error,
              contentDescription = "Fault",
              tint = SafetyRed,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = robotState.activeFaultMessage ?: "System Interlock Activated",
                color = Color(0xFFFFD4D4),
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium
              )
              Text(
                text = "Manual and automated motions are inhibited. Verify robot envelope before clearing.",
                color = Color(0xFFAFA2A2),
                style = MaterialTheme.typography.bodySmall
              )
            }
          }

          Button(
            onClick = onClearFault,
            colors = ButtonDefaults.buttonColors(
              containerColor = SafetyRed,
              contentColor = Color.White
            ),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.testTag("clear_fault_btn")
          ) {
            Text("CLEAR FAULT", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // 2. Neutral Rearm Interlock Notice
    if (!isNeutralRearmed) {
      Surface(
        color = Color(0xFF33260A),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = "Neutral Rearm Required",
            tint = AureomGoldPrimary,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "NEUTRAL INTERLOCK ACTIVE: Return all sticks to center and release Deadman [LT] to arm movement.",
            color = AureomGoldPrimary,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium
          )
        }
      }
    }

    // 3. Normal Deadman Status banner
    if (robotState.controlState == ControlState.MOVING || isDeadmanEngaged) {
      Surface(
        color = Color(0xFF0F2818),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = "Armed",
            tint = SafetyGreen,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "MANUAL MOTION ARMED & ENABLED (Deadman Active)",
            color = SafetyGreen,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
