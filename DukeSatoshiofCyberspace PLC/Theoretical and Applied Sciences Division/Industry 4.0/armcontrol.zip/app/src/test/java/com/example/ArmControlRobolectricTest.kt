package com.example

import com.example.adapter.InternalSimulationAdapter
import com.example.adapter.SimulatedFault
import com.example.controller.NeutralRearmManager
import com.example.kinematics.RobotKinematics
import com.example.model.CartesianVelocity
import com.example.model.ControlMode
import com.example.model.ControlState
import com.example.model.CoordinateFrame
import com.example.model.MotionIntent
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
@OptIn(ExperimentalCoroutinesApi::class)
class ArmControlRobolectricTest {

  @Test
  fun `test neutral rearming safety interlock requires center before arming`() {
    val rearmManager = NeutralRearmManager(deadzoneStick = 0.12f, deadmanThreshold = 0.20f)
    rearmManager.requireRearm("Test reset")
    assertFalse("Must be locked out initially", rearmManager.isArmed)

    // Deflected stick with deadman held should NOT rearm
    val stillLocked = rearmManager.evaluate(
      stickLX = 0.5f,
      stickLY = 0.0f,
      stickRX = 0.0f,
      stickRY = 0.0f,
      deadmanTrigger = 0.8f
    )
    assertFalse("Deflected stick must not arm", stillLocked)

    // Sticks returned to center AND deadman released -> transitions to rearmed!
    val armed = rearmManager.evaluate(
      stickLX = 0.02f,
      stickLY = 0.01f,
      stickRX = 0.0f,
      stickRY = 0.0f,
      deadmanTrigger = 0.05f
    )
    assertTrue("Neutral stick and released trigger must rearm system", armed)
    assertTrue("System is now armed", rearmManager.isArmed)
  }

  @Test
  fun `test robot kinematics forward kinematics computes valid tool pose`() {
    val homeJoints = floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f)
    val fk = RobotKinematics.forwardKinematics(homeJoints)

    // All links pointing straight up
    assertNotNull(fk.toolPose)
    assertTrue("Z must be positive in vertical configuration", fk.toolPose.z > 500f)
    assertEquals(7, fk.jointPositions.size)
  }

  @Test
  fun `test singularity detection near wrist alignment`() {
    // When J5 is near 0 degrees, wrist singularity is detected
    val singularJoints = floatArrayOf(0f, -20f, 40f, 0f, 1f, 0f) // J5 = 1 deg (< 4 deg)
    val fk = RobotKinematics.forwardKinematics(singularJoints)

    assertTrue("Singularity should be detected when |J5| < 4°", fk.isSingular)
    assertNotNull(fk.singularityReason)
  }

  @Test
  fun `test watchdog and stale motion intent rejection`() = runTest {
    val simAdapter = InternalSimulationAdapter(this, autoStartLoop = false)

    // Send valid intent with sequence number 10
    val now = System.currentTimeMillis()
    val intent1 = MotionIntent(
      sessionId = "test_session",
      sequenceNumber = 10,
      timestamp = now,
      ttlMs = 150,
      controlMode = ControlMode.JOINT_JOG,
      coordinateFrame = CoordinateFrame.BASE,
      speedScalePercent = 30f,
      jointVelocitiesDegPerSec = floatArrayOf(15f, 0f, 0f, 0f, 0f, 0f),
      enableState = true
    )
    simAdapter.sendMotionIntent(intent1)

    // Attempt to send an out-of-order / older sequence number 8
    val staleIntent = MotionIntent(
      sessionId = "test_session",
      sequenceNumber = 8,
      timestamp = now,
      ttlMs = 150,
      controlMode = ControlMode.JOINT_JOG,
      coordinateFrame = CoordinateFrame.BASE,
      speedScalePercent = 30f,
      jointVelocitiesDegPerSec = floatArrayOf(15f, 0f, 0f, 0f, 0f, 0f),
      enableState = true
    )
    simAdapter.sendMotionIntent(staleIntent)

    val telemetry = simAdapter.observeTelemetry().value
    assertEquals("Confirmed sequence number must remain 10 (stale 8 rejected)", 10L, telemetry.confirmedSequenceNumber)
  }

  @Test
  fun `test simulated fault stops motion immediately`() = runTest {
    val simAdapter = InternalSimulationAdapter(this, autoStartLoop = false)

    // Inject Emergency Stop fault
    simAdapter.injectFault(SimulatedFault.ESTOP_TRIGGERED)

    val state = simAdapter.observeTelemetry().value
    assertEquals("Control state must transition to ESTOP", ControlState.ESTOP, state.controlState)
    assertFalse("Safe to move must be false during ESTOP", state.controlState.isSafeToMove)

    // Clear fault recovers state to READY
    simAdapter.clearFault()
    val recoveredState = simAdapter.observeTelemetry().value
    assertEquals("State after clearing fault must be READY", ControlState.READY, recoveredState.controlState)
  }

  @Test
  fun `test inverse kinematics solves cartesian linear motion`() {
    val currentJoints = floatArrayOf(0f, -20f, 40f, 0f, 70f, 0f)
    val cartVel = CartesianVelocity(vx = 50f, vy = 0f, vz = 0f)

    val jointVels = RobotKinematics.solveCartesianVelocity(
      currentJointsDeg = currentJoints,
      cartesianVel = cartVel,
      frame = CoordinateFrame.BASE
    )

    assertEquals(6, jointVels.size)
    // Non-zero cartesian request produces non-zero joint velocity
    val anyNonZero = jointVels.any { kotlin.math.abs(it) > 0.1f }
    assertTrue("Inverse kinematics should generate joint velocities for cartesian displacement", anyNonZero)
  }
}
