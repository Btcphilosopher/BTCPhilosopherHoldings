export interface Material {
  id: string;
  name: string;
  density: number; // g/cm³
  elasticModulus: number; // GPa
  yieldStrength: number; // MPa
  thermalConductivity: number; // W/mK
  specificHeat: number; // J/kgK
  Kt: number; // MPa (tangential coefficient)
  Kr: number; // MPa (radial coefficient)
  Ka: number; // MPa (axial coefficient)
  taylorC: number;
  taylorN: number;
}

export const MATERIALS: Record<string, Material> = {
  'Al-6061': {
    id: 'Al-6061',
    name: 'Aluminium 6061-T6',
    density: 2.7,
    elasticModulus: 68.9,
    yieldStrength: 276,
    thermalConductivity: 167,
    specificHeat: 897,
    Kt: 700,
    Kr: 200,
    Ka: 150,
    taylorC: 120,
    taylorN: 0.25,
  },
  'Al-7075': {
    id: 'Al-7075',
    name: 'Aluminium 7075-T6',
    density: 2.81,
    elasticModulus: 71.7,
    yieldStrength: 503,
    thermalConductivity: 130,
    specificHeat: 960,
    Kt: 850,
    Kr: 260,
    Ka: 180,
    taylorC: 100,
    taylorN: 0.24,
  },
  'Ti-6Al-4V': {
    id: 'Ti-6Al-4V',
    name: 'Titanium Grade 5 (Ti-6Al-4V)',
    density: 4.43,
    elasticModulus: 113.8,
    yieldStrength: 880,
    thermalConductivity: 6.7, // Extremely low conductivity! Heats up fast.
    specificHeat: 526,
    Kt: 1950,
    Kr: 650,
    Ka: 500,
    taylorC: 35,
    taylorN: 0.2,
  },
  'Inconel-718': {
    id: 'Inconel-718',
    name: 'Inconel 718 Superalloy',
    density: 8.19,
    elasticModulus: 200.0,
    yieldStrength: 1030,
    thermalConductivity: 11.4,
    specificHeat: 435,
    Kt: 2400,
    Kr: 900,
    Ka: 750,
    taylorC: 18,
    taylorN: 0.15,
  },
  'SS-316': {
    id: 'SS-316',
    name: 'Stainless Steel 316L',
    density: 8.0,
    elasticModulus: 193.0,
    yieldStrength: 290,
    thermalConductivity: 16.3,
    specificHeat: 500,
    Kt: 1800,
    Kr: 600,
    Ka: 450,
    taylorC: 45,
    taylorN: 0.22,
  },
};

export interface Tool {
  id: string;
  name: string;
  type: 'flat_endmill' | 'ball_nose' | 'bull_nose' | 'drill' | 'face_mill';
  diameter: number; // mm
  flutes: number;
  cuttingLength: number; // mm
  overallLength: number; // mm
  stickout: number; // mm
  helixAngle: number; // deg
  material: 'carbide' | 'hss';
  elasticModulus: number; // GPa
}

export const TOOLS: Record<string, Tool> = {
  'T1_BALL_12': {
    id: 'T1_BALL_12',
    name: 'Ø12mm Carbide Ball Nose',
    type: 'ball_nose',
    diameter: 12,
    flutes: 4,
    cuttingLength: 30,
    overallLength: 75,
    stickout: 45,
    helixAngle: 35,
    material: 'carbide',
    elasticModulus: 600, // Carbide modulus
  },
  'T2_FLAT_12': {
    id: 'T2_FLAT_12',
    name: 'Ø12mm Carbide Flat Endmill',
    type: 'flat_endmill',
    diameter: 12,
    flutes: 4,
    cuttingLength: 35,
    overallLength: 80,
    stickout: 50,
    helixAngle: 30,
    material: 'carbide',
    elasticModulus: 600,
  },
  'T3_BALL_6': {
    id: 'T3_BALL_6',
    name: 'Ø6mm Carbide Ball Nose (Fine)',
    type: 'ball_nose',
    diameter: 6,
    flutes: 2,
    cuttingLength: 15,
    overallLength: 60,
    stickout: 30,
    helixAngle: 35,
    material: 'carbide',
    elasticModulus: 600,
  },
  'T4_DRILL_10': {
    id: 'T4_DRILL_10',
    name: 'Ø10mm High-Speed Steel Drill',
    type: 'drill',
    diameter: 10,
    flutes: 2,
    cuttingLength: 50,
    overallLength: 100,
    stickout: 65,
    helixAngle: 25,
    material: 'hss',
    elasticModulus: 210, // HSS Modulus
  },
};

export interface Fixture {
  id: string;
  name: string;
  type: 'vise' | 'clamp_straps' | 'vacuum_plate';
  height: number; // mm (Z height offset)
  xMin: number;
  xMax: number;
  yMin: number;
  yMax: number;
  clampingForce: number; // kN
}

export const FIXTURES: Record<string, Fixture> = {
  'VISE_STANDARD': {
    id: 'VISE_STANDARD',
    name: 'Kurt Precision CNC Vise 6"',
    type: 'vise',
    height: 45, // stock sits 45mm above table
    xMin: -60,
    xMax: 60,
    yMin: -50,
    yMax: 50,
    clampingForce: 25, // kN
  },
};

export interface Stock {
  materialId: string;
  dx: number; // mm
  dy: number; // mm
  dz: number; // mm
  x0: number; // mm origin
  y0: number;
  z0: number;
}

export interface GCodeState {
  x: number;
  y: number;
  z: number;
  a: number;
  b: number;
  c: number;
  feed: number;
  speed: number;
  coolant: boolean;
  absolute: boolean;
  inches: boolean;
  modalG: string; // 'G00', 'G01', 'G02', 'G03'
  toolId: string;
}

export interface SimulationFrame {
  time: number; // sec
  lineNo: number;
  gcode: string;
  
  // Joint Positions (Machine System)
  x: number;
  y: number;
  z: number;
  b: number;
  c: number;

  // Toolpose in Workpiece coordinate system (Kinematic solver)
  workX: number;
  workY: number;
  workZ: number;
  dirX: number;
  dirY: number;
  dirZ: number;

  // Process Parameters
  feedRate: number; // mm/min
  spindleSpeed: number; // RPM
  mrr: number; // cm³/min
  chipLoad: number; // mm/tooth

  // Mechanical Physics
  forceTangential: number; // N
  forceRadial: number; // N
  forceAxial: number; // N
  forceTotal: number; // N
  spindlePower: number; // kW
  spindleTorque: number; // Nm

  // Structural Physics
  deflection: number; // µm (micro-meters)
  deflectionX: number;
  deflectionY: number;
  deflectionZ: number;

  // Thermal Physics
  temperature: number; // °C
  workpieceTemperature: number; // °C

  // Degradation
  toolWear: number; // mm (flank wear depth)
  remainingLifePercent: number;

  // Surface Generation
  predictedRa: number; // µm
  scallopHeight: number; // µm

  // Alarms
  collision: 'CLEAR' | 'WARNING' | 'COLLISION';
  collisionDetail: string;
  limitViolation: boolean;
  coolant: boolean;
}

export class CNCSimulator {
  // Config parameters
  public material: Material = MATERIALS['Ti-6Al-4V'];
  public tool: Tool = TOOLS['T1_BALL_12'];
  public fixture: Fixture = FIXTURES['VISE_STANDARD'];
  public stock: Stock = {
    materialId: 'Ti-6Al-4V',
    dx: 120,
    dy: 100,
    dz: 80,
    x0: -60,
    y0: -50,
    z0: 45, // stock bottom is sitting on the vise top (45mm height)
  };

  /**
   * Translates absolute machine coordinates to workpiece coordinate systems
   * with full Table-Table 5-axis kinematics (tilted B around Y-axis, rotating C around Z-axis)
   */
  public forwardKinematics(x: number, y: number, z: number, b: number, c: number) {
    const bRad = (b * Math.PI) / 180;
    const cRad = (c * Math.PI) / 180;

    // Table turns by C, then tilts by B.
    // Workpiece position relative to machine table depends on table angles.
    // Tilted coordinate vectors:
    // We compute inverse transformation to get tool point in workpiece coords:
    // P_w = R_z(-C) * R_y(-B) * (P_m - P_center)
    // Assume tilting center is at (0, 0, 0) of the B-C rotary axes:
    
    // Rotation matrices product R = Ry(B)*Rz(C)
    // Inversely:
    // P_w_x = (x * Math.cos(cRad) + y * Math.sin(cRad)) * Math.cos(bRad) - z * Math.sin(bRad);
    // P_w_y = -x * Math.sin(cRad) + y * Math.cos(cRad);
    // P_w_z = (x * Math.cos(cRad) + y * Math.sin(cRad)) * Math.sin(bRad) + z * Math.cos(bRad);

    const cosC = Math.cos(cRad);
    const sinC = Math.sin(cRad);
    const cosB = Math.cos(bRad);
    const sinB = Math.sin(bRad);

    // Apply rotation around Z by -C, then rotation around Y by -B
    // Let's model a standard kinematic chain:
    const workX = (x * cosC + y * sinC) * cosB - (z - this.fixture.height) * sinB;
    const workY = -x * sinC + y * cosC;
    const workZ = (x * cosC + y * sinC) * sinB + (z - this.fixture.height) * cosB;

    // Tool vector in workpiece coordinate system:
    // Standard tool points along vertical Z axis (0, 0, 1) in machine system.
    // In workpiece coordinate system:
    const dirX = sinB * cosC;
    const dirY = sinB * sinC;
    const dirZ = cosB;

    return { workX, workY, workZ, dirX, dirY, dirZ };
  }

  /**
   * Parse a block of G-code program and output sequential high-fidelity time slices
   */
  public simulate(gcodeText: string, solverSteps = 1): SimulationFrame[] {
    const lines = gcodeText.split('\n');
    const frames: SimulationFrame[] = [];
    
    // Initial State of machine
    let state: GCodeState = {
      x: 0,
      y: 0,
      z: 100, // clear height
      a: 0,
      b: 0,
      c: 0,
      feed: 800, // mm/min
      speed: 3000, // RPM
      coolant: false,
      absolute: true,
      inches: false,
      modalG: 'G00',
      toolId: 'T1_BALL_12',
    };

    let totalTime = 0;
    let currentWear = 0.02; // Initial slight break-in flank wear in mm
    let currentTemp = 25.0; // Ambient temp °C
    let currentWorkTemp = 25.0;

    for (let i = 0; i < lines.length; i++) {
      const rawLine = lines[i].trim();
      if (!rawLine || rawLine.startsWith('(') || rawLine.startsWith(';')) {
        continue;
      }

      // Remove comments (parentheses or trailing semicolons)
      const cleanLine = rawLine.replace(/\([^)]*\)/g, '').split(';')[0].trim();
      if (!cleanLine) continue;

      // Tokenize
      const tokens = cleanLine.toUpperCase().match(/[A-Z][-+]?[0-9]*\.?[0-9]*/g) || [];
      
      const nextState = { ...state };

      // Set tool if changed
      for (const tok of tokens) {
        const key = tok[0];
        const val = parseFloat(tok.slice(1));
        
        if (key === 'G') {
          const gVal = Math.floor(val);
          if (gVal === 0 || gVal === 1 || gVal === 2 || gVal === 3) {
            nextState.modalG = 'G0' + gVal;
          } else if (gVal === 90) {
            nextState.absolute = true;
          } else if (gVal === 91) {
            nextState.absolute = false;
          } else if (gVal === 20) {
            nextState.inches = true;
          } else if (gVal === 21) {
            nextState.inches = false;
          }
        } else if (key === 'X') {
          nextState.x = nextState.absolute ? val : nextState.x + val;
        } else if (key === 'Y') {
          nextState.y = nextState.absolute ? val : nextState.y + val;
        } else if (key === 'Z') {
          nextState.z = nextState.absolute ? val : nextState.z + val;
        } else if (key === 'B') {
          nextState.b = nextState.absolute ? val : nextState.b + val;
        } else if (key === 'C') {
          nextState.c = nextState.absolute ? val : nextState.c + val;
        } else if (key === 'F') {
          nextState.feed = val;
        } else if (key === 'S') {
          nextState.speed = val;
        } else if (key === 'T') {
          const tId = 'T' + Math.floor(val);
          if (TOOLS[tId]) {
            this.tool = TOOLS[tId];
            nextState.toolId = tId;
          }
        } else if (key === 'M') {
          const mVal = Math.floor(val);
          if (mVal === 3 || mVal === 4) {
            // Spindle starts
          } else if (mVal === 8) {
            nextState.coolant = true;
          } else if (mVal === 9) {
            nextState.coolant = false;
          }
        }
      }

      // If inches mode, convert dimensions
      if (nextState.inches) {
        // Just scale for simplicity
        nextState.x *= 25.4;
        nextState.y *= 25.4;
        nextState.z *= 25.4;
      }

      // Travel segment vectors
      const dx = nextState.x - state.x;
      const dy = nextState.y - state.y;
      const dz = nextState.z - state.z;
      const db = nextState.b - state.b;
      const dc = nextState.c - state.c;
      const distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
      const isRapid = nextState.modalG === 'G00';

      // Standard linear interpolation
      const steps = solverSteps;
      const segFeed = isRapid ? 8000 : nextState.feed; // rapid at 8000 mm/min
      const duration = (distance / (segFeed / 60)) || 0.1; // in seconds
      const stepDuration = duration / steps;

      for (let s = 1; s <= steps; s++) {
        const tRatio = s / steps;
        totalTime += stepDuration;

        const currentX = state.x + dx * tRatio;
        const currentY = state.y + dy * tRatio;
        const currentZ = state.z + dz * tRatio;
        const currentB = state.b + db * tRatio;
        const currentC = state.c + dc * tRatio;

        // Kinematic mapping
        const { workX, workY, workZ, dirX, dirY, dirZ } = this.forwardKinematics(
          currentX,
          currentY,
          currentZ,
          currentB,
          currentC
        );

        // Engagement calculation: Determine if tool intersects stock boundaries
        const isInStockX = workX >= this.stock.x0 && workX <= this.stock.x0 + this.stock.dx;
        const isInStockY = workY >= this.stock.y0 && workY <= this.stock.y0 + this.stock.dy;
        // The tool tip is cut in. Z goes down.
        const stockZTop = this.stock.z0 + this.stock.dz;
        const depthOfCutZ = stockZTop - workZ; // mm
        const isEngaging = isInStockX && isInStockY && depthOfCutZ > 0 && workZ < stockZTop && !isRapid;

        // Material removal metrics
        let axialDepth = 0;
        let radialDepth = 0;
        let mrr = 0;
        let forceTangential = 0;
        let forceRadial = 0;
        let forceAxial = 0;
        let forceTotal = 0;
        let spindleTorque = 0;
        let spindlePower = 0;
        let chipLoad = 0;

        if (isEngaging) {
          axialDepth = Math.min(depthOfCutZ, this.tool.cuttingLength);
          radialDepth = Math.min(this.tool.diameter * 0.5, this.stock.dy); // engagement stepover approx

          // MRR = Q = a_p * a_e * v_f / 1000  (cm3/min)
          // a_p axial depth, a_e radial stepover, v_f feed rate mm/min
          mrr = (axialDepth * radialDepth * nextState.feed) / 1000;

          // Chip load per tooth: f_z = v_f / (RPM * flutes)
          chipLoad = nextState.feed / (Math.max(10, nextState.speed) * this.tool.flutes);

          // Mechanistic force model
          // Tangential: F_t = K_t * a_p * f_z
          // Radial: F_r = K_r * a_p * f_z
          // Axial: F_a = K_a * a_e * f_z
          // We apply a scale factor for engagement angle
          const thetaRad = Math.asin(Math.min(1.0, radialDepth / (this.tool.diameter * 0.5 || 1)));
          const sinTheta = Math.sin(thetaRad || 0.5);

          forceTangential = this.material.Kt * axialDepth * chipLoad * sinTheta;
          forceRadial = this.material.Kr * axialDepth * chipLoad;
          forceAxial = this.material.Ka * radialDepth * chipLoad;
          
          forceTotal = Math.sqrt(forceTangential * forceTangential + forceRadial * forceRadial + forceAxial * forceAxial);

          // Torque = F_t * R_tool
          spindleTorque = forceTangential * (this.tool.diameter / 2000); // Nm
          // Power = Torque * omega (kW)
          spindlePower = spindleTorque * (2 * Math.PI * nextState.speed / 60) / 1000; // kW
        }

        // Structural Model: Deflection
        // cantilever beam displacement: delta = F * L^3 / (3 * E * I)
        // L is tool stickout, E is tool modulus, I is area moment of inertia
        // I = pi * D^4 / 64 (mm4)
        const inertiaI = (Math.PI * Math.pow(this.tool.diameter, 4)) / 64; // mm^4
        // Convert variables: E to MPa (1 GPa = 1000 MPa), stickout in mm, force in N
        const eModulusMPa = this.tool.elasticModulus * 1000;
        // Deflection in mm
        let deflection = 0;
        if (forceTotal > 0) {
          deflection = (forceTotal * Math.pow(this.tool.stickout, 3)) / (3 * eModulusMPa * inertiaI); // mm
        }
        const deflectionMicrons = deflection * 1000; // µm

        // Distribute deflection in 3D direction
        const speedRad = (nextState.speed * 2 * Math.PI) / 60;
        const angleRot = speedRad * totalTime;
        const deflectionX = deflectionMicrons * Math.cos(angleRot);
        const deflectionY = deflectionMicrons * Math.sin(angleRot);
        const deflectionZ = deflectionMicrons * 0.1; // tiny axial deflection

        // Thermal Model: Heat dissipation
        // Q_gen = Spindle Power * efficiency_factor
        const efficiencyFactor = 0.85; // friction conversion to heat
        const qHeatGen = (spindlePower * 1000) * efficiencyFactor; // Watts (J/s)
        
        // Heat balance: temperature increases due to cutting heat, dissipates by conduction & coolant convection
        // dt * Q / (mass_of_chips * specificHeat) + convection
        const densityKgM3 = this.material.density * 1000;
        const mrrSecM3 = (mrr * 1e-6) / 60; // m3/s
        const massRate = mrrSecM3 * densityKgM3; // kg/s
        const thermalConductionCoeff = this.material.thermalConductivity * 0.05; // simplified conduction model
        const coolingConvectionCoeff = nextState.coolant ? 0.3 : 0.01; // Coolant convective multiplier

        if (isEngaging) {
          const thermalCapacity = Math.max(1, massRate * this.material.specificHeat);
          const dT = (qHeatGen / thermalCapacity) * 0.01; // scaled for tool interface zone
          currentTemp += dT - coolingConvectionCoeff * (currentTemp - 25.0) * stepDuration;
          currentWorkTemp += (dT * 0.1) - thermalConductionCoeff * (currentWorkTemp - 25.0) * stepDuration;
        } else {
          // Cooldown phase
          currentTemp -= (coolingConvectionCoeff * 5) * (currentTemp - 25.0) * stepDuration;
          currentWorkTemp -= (thermalConductionCoeff * 2) * (currentWorkTemp - 25.0) * stepDuration;
        }

        // Clip minimum ambient temp
        currentTemp = Math.max(25.0, currentTemp);
        currentWorkTemp = Math.max(25.0, currentWorkTemp);

        // Degradation Model: Tool Flank Wear (Taylor Life relation)
        // dVb/dt = rate based on temperature and forces
        // Wear depth (mm)
        let wearRate = 0;
        if (isEngaging) {
          // Taylor life with temperature acceleration:
          // Life T_life = (C_w / V_c)^ (1/n)
          // Cutting speed: V_c = pi * D * RPM / 1000 (m/min)
          const cuttingSpeed = (Math.PI * this.tool.diameter * nextState.speed) / 1000;
          const nominalLifeMin = Math.pow(this.material.taylorC / (cuttingSpeed || 1), 1 / (this.material.taylorN || 0.25));
          const nominalLifeSec = nominalLifeMin * 60;
          
          // Accelerated wear due to temperature above 300C
          const thermalAcceleration = currentTemp > 300 ? Math.exp((currentTemp - 300) / 150) : 1.0;
          wearRate = (0.3 / nominalLifeSec) * thermalAcceleration; // 0.3mm is standard flank wear failure criterion
          currentWear += wearRate * stepDuration;
        }
        currentWear = Math.min(0.35, currentWear); // Max flank wear capped at 0.35mm
        const remainingLifePercent = Math.max(0, ((0.3 - currentWear) / 0.3) * 100);

        // Surface roughness Ra = 0.32 * (feed_per_tooth^2) / R_corner
        const toolRadiusCorner = this.tool.type === 'ball_nose' ? this.tool.diameter / 2 : 0.4; // flat mill has 0.4mm corner radius typically
        const predictedRa = isEngaging
          ? Math.max(0.2, (0.032 * Math.pow(chipLoad * 1000, 2)) / toolRadiusCorner) // in micro-meters (µm)
          : 0;

        const stepover = 1.2; // nominal 1.2mm stepover
        const scallopHeight = isEngaging && this.tool.type === 'ball_nose'
          ? Math.max(0.1, Math.pow(stepover, 2) / (8 * (this.tool.diameter / 2))) * 1000 // converted to µm
          : 0;

        // Alarm and collision system
        let collision: 'CLEAR' | 'WARNING' | 'COLLISION' = 'CLEAR';
        let collisionDetail = '';

        // Check fixture keep-out zone (Z level collision)
        if (workZ < this.fixture.height && isEngaging) {
          collision = 'COLLISION';
          collisionDetail = `Cutter crashed into CNC fixture vise jaws! Z=${workZ.toFixed(2)} mm (Limit: ${this.fixture.height} mm)`;
        } else if (workZ < this.fixture.height + 5 && isEngaging) {
          collision = 'WARNING';
          collisionDetail = `Extremely close clearance to fixture. Z=${workZ.toFixed(2)} mm`;
        }

        // Check tool holder clearance.
        // Stickout length controls where the holder starts. Z_holder = workZ + stickout.
        const holderZ = workZ + this.tool.stickout;
        if (holderZ < stockZTop && isEngaging) {
          collision = 'COLLISION';
          collisionDetail = `Crashes: Tool holder stickout overflow! Holder collided with workpiece. HolderZ=${holderZ.toFixed(2)} mm`;
        }

        // Check axis limits travel bounds
        const limitViolation =
          currentX < -350 || currentX > 350 ||
          currentY < -250 || currentY > 250 ||
          currentZ < -100 || currentZ > 300 ||
          currentB < -120 || currentB > 120 ||
          currentC < -360 || currentC > 360;

        frames.push({
          time: totalTime,
          lineNo: i + 1,
          gcode: cleanLine,
          x: currentX,
          y: currentY,
          z: currentZ,
          b: currentB,
          c: currentC,
          workX,
          workY,
          workZ,
          dirX,
          dirY,
          dirZ,
          feedRate: segFeed,
          spindleSpeed: nextState.speed,
          mrr,
          chipLoad,
          forceTangential,
          forceRadial,
          forceAxial,
          forceTotal,
          spindlePower,
          spindleTorque,
          deflection: deflectionMicrons,
          deflectionX,
          deflectionY,
          deflectionZ,
          temperature: currentTemp,
          workpieceTemperature: currentWorkTemp,
          toolWear: currentWear,
          remainingLifePercent,
          predictedRa,
          scallopHeight,
          collision,
          collisionDetail,
          limitViolation,
          coolant: nextState.coolant,
        });
      }

      state = nextState;
    }

    return frames;
  }
}
