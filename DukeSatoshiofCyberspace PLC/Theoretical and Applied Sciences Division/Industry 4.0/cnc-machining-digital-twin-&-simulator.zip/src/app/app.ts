import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild, AfterViewInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import * as THREE from 'three';
import { CNCSimulator, SimulationFrame, MATERIALS, TOOLS, FIXTURES } from './cnc-solver';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('viewportCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;

  // Material & Tool Libraries
  materialsList = Object.values(MATERIALS);
  toolsList = Object.values(TOOLS);
  fixturesList = Object.values(FIXTURES);
  TOOLS = TOOLS;

  // Digital Twin Configuration
  selectedMaterialId = 'Ti-6Al-4V';
  selectedToolId = 'T1_BALL_12';
  selectedFixtureId = 'VISE_STANDARD';
  
  stockDimensions = { dx: 120, dy: 100, dz: 80 };
  stepsPerSegment = 2; // Physics fidelity

  // Operational Presets
  selectedPreset = 'aerospace_pocket';
  gcodeProgram = `(OP1: Ti-6Al-4V Aerospace Rib Pocketing)
G21 G90 G54
T1 M6 (Ø12mm Carbide Ball Nose Cutter)
S2200 M3 (Spindle On - Speed for Titanium)
M8 (Coolant Flood ON)
G00 X-45 Y-35 Z125 (Rapid to start)
G01 Z110 F200 (Slow plunge into stock)
G01 X45 F420 (Linear roughing pass)
G01 Y-15 F420
G01 X-45 F480
G01 Y5 F420
G01 X45 F480
G01 Y25 F420
G01 X-45 F480
G00 Z135 (Clear pocket)
G00 X0 Y0 M9 M5 (Coolant off, spindle off)`;

  presets: Record<string, { name: string; gcode: string; material: string; tool: string }> = {
    aerospace_pocket: {
      name: '1. Titanium Pocket Roughing',
      material: 'Ti-6Al-4V',
      tool: 'T1_BALL_12',
      gcode: `(OP1: Ti-6Al-4V Aerospace Rib Pocketing)
G21 G90 G54
T1 M6 (Ø12mm Carbide Ball Nose Cutter)
S2200 M3 (Spindle On - Speed for Titanium)
M8 (Coolant ON)
G00 X-45 Y-35 Z125 (Rapid to start)
G01 Z110 F200 (Plunge)
G01 X45 F420 (Roughing pass)
G01 Y-15 F420
G01 X-45 F480
G01 Y5 F420
G01 X45 F480
G01 Y25 F420
G01 X-45 F480
G00 Z135 (Clear)
G00 X0 Y0 M9 M5`,
    },
    impeller_5axis: {
      name: '2. Aluminum 5-Axis Waterline Finishing',
      material: 'Al-6061',
      tool: 'T3_BALL_6',
      gcode: `(OP2: 5-Axis Curved Impeller Waterline)
G21 G90 G54
T3 M6 (Ø6mm Fine Ball Nose)
S5500 M3 (High Speed for Aluminum)
M8 (Coolant on)
G00 X-30 Y-30 Z125 B0 C0
G01 Z112 F600
G01 X-20 Y-20 B10 C45 F800 (Simultaneous 5-axis tilt)
G01 X0 Y0 B20 C90 F800
G01 X20 Y20 B15 C135 F800
G01 X30 Y30 B0 C180 F800
G00 Z130 B0 C0 M9 M5`,
    },
    collision_test: {
      name: '3. Fixture Crash Test (Hazard Alarms)',
      material: 'Al-7075',
      tool: 'T2_FLAT_12',
      gcode: `(ERROR: Vise Jaw Collision Block)
G21 G90
T2 M6 (Ø12mm Flat Mill)
S3200 M3
G00 X-50 Y0 Z120 (Position over jaws)
G01 Z35 F500 (Plunges directly into the vise jaw!)
G01 X50 F500 (Crashes along clamping zone!)
G00 Z120 M5`,
    },
    overload_run: {
      name: '4. Titanium Feed Rate Overload (High Deflection)',
      material: 'Ti-6Al-4V',
      tool: 'T2_FLAT_12',
      gcode: `(OP4: High Feed Overload Run - Ti-6Al-4V)
G21 G90
T2 M6 (Ø12mm Carbide Flat)
S3500 M3 M8 (Coolant on)
G00 X-40 Y-20 Z120
G01 Z110 F2200 (Extremely high feed rate for Titanium!)
G01 X40 F2200 (Causes severe tool deflection & chatter!)
G00 Z130 M5`,
    }
  };

  // Simulation Timeline State
  simulationFrames: SimulationFrame[] = [];
  currentFrameIndex = 0;
  isPlaying = false;
  playbackSpeed = 1; // 1x, 2x, 5x, 10x
  playbackTimer: ReturnType<typeof setInterval> | null = null;
  activeTab = 'gcode';

  // Active Telemetry Frame
  activeFrame: SimulationFrame | null = null;
  statistics = {
    machiningTime: 0,
    mrrPeak: 0,
    forcePeak: 0,
    tempPeak: 0,
    deflectionPeak: 0,
    totalMaterialRemoved: 0,
  };

  // AI CAM Specialist State
  aiAnalysisText = '';
  aiOptimizedGcode = '';
  aiRecommendedRpm = 0;
  aiRecommendedFeed = 0;
  aiSafetyMargin = '';
  isAnalyzingAI = false;

  // Probing Interface
  isProbingMode = false;
  probeCoordinates = { x: 0, y: 0, z: 0 };
  probeResults = { nominalZ: 125, actualZ: 125, error: 0, status: 'NO_MEASUREMENT' };

  // What-If Scenario Matrix
  scenarios: {
    id: string;
    material: string;
    tool: string;
    cooling: boolean;
    feedRate: number;
    rpm: number;
    peakForce: number;
    deflection: number;
    timeSec: number;
    wearMm: number;
    temp: number;
    status: string;
  }[] = [];

  // Digital Twin Comparison
  telemetrySource: 'SIMULATED' | 'REAL_CNC_LIVE' = 'SIMULATED';
  realCncFeedNoise = { forceNoise: 0, tempNoise: 0, rpmOffset: 0 };

  // Active Viewport Mode (Visualizes attributes on the stock)
  viewportVisualMode: 'MATERIAL' | 'FORCE' | 'HEAT' | 'DEFLECTION' | 'DEVIATION' = 'MATERIAL';

  // Three.js Scene Variables
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private stockMesh!: THREE.Mesh;
  private viseMesh!: THREE.Mesh;
  private tableMesh!: THREE.Mesh;
  private spindleAssembly!: THREE.Group;
  private cutterMesh!: THREE.Mesh;
  private toolpathLine!: THREE.Line;
  
  // Adaptive Voxel/Heightmap stock grid details
  private stockGridResolution = 50; // 50x50 height vertices
  private initialHeightmap: number[] = [];
  private currentHeightmap: number[] = [];
  private heightmapColors!: Float32Array;

  // Orbit navigation helpers
  private isDragging = false;
  private previousMousePosition = { x: 0, y: 0 };
  private cameraRotation = { phi: Math.PI / 4, theta: Math.PI / 4, radius: 250 };
  private cdr = inject(ChangeDetectorRef);

  ngOnInit() {
    this.runPhysicsSimulation();
    this.initDefaultScenarios();
  }

  ngAfterViewInit() {
    this.initThreeJs();
    this.resetStockHeightmap();
    this.drawToolpathLines();
    this.updateActiveTelemetryFrame();
    this.animate();
  }

  ngOnDestroy() {
    if (this.playbackTimer) clearInterval(this.playbackTimer);
  }

  // Choose preset G-code program
  onPresetChange() {
    const preset = this.presets[this.selectedPreset];
    if (preset) {
      this.gcodeProgram = preset.gcode;
      this.selectedMaterialId = preset.material;
      this.selectedToolId = preset.tool;
      this.runPhysicsSimulation();
    }
  }

  // Trigger main physics solver on the client/server side
  runPhysicsSimulation() {
    const simulator = new CNCSimulator();
    simulator.material = MATERIALS[this.selectedMaterialId] || MATERIALS['Ti-6Al-4V'];
    simulator.tool = TOOLS[this.selectedToolId] || TOOLS['T1_BALL_12'];
    simulator.fixture = FIXTURES[this.selectedFixtureId] || FIXTURES['VISE_STANDARD'];
    simulator.stock = {
      materialId: this.selectedMaterialId,
      dx: this.stockDimensions.dx,
      dy: this.stockDimensions.dy,
      dz: this.stockDimensions.dz,
      x0: -this.stockDimensions.dx / 2,
      y0: -this.stockDimensions.dy / 2,
      z0: simulator.fixture.height,
    };

    // Parse and solve physics steps
    this.simulationFrames = simulator.simulate(this.gcodeProgram, this.stepsPerSegment);
    this.currentFrameIndex = 0;
    this.activeFrame = this.simulationFrames[0] || null;

    // Calculate aggregated physical peak values
    let peakMRR = 0;
    let peakForce = 0;
    let peakTemp = 25.0;
    let peakDeflection = 0;
    let totalRemovedVol = 0;

    for (const f of this.simulationFrames) {
      if (f.mrr > peakMRR) peakMRR = f.mrr;
      if (f.forceTotal > peakForce) peakForce = f.forceTotal;
      if (f.temperature > peakTemp) peakTemp = f.temperature;
      if (f.deflection > peakDeflection) peakDeflection = f.deflection;
      
      // MRR is in cm3/min. Vol = MRR * dt (in minutes)
      const dtMin = (f.feedRate > 0) ? (f.mrr * (0.01 / 60)) : 0;
      totalRemovedVol += dtMin;
    }

    this.statistics = {
      machiningTime: this.simulationFrames.reduce((acc, f) => acc + (f.feedRate > 0 ? 0.05 : 0), 0),
      mrrPeak: peakMRR,
      forcePeak: peakForce,
      tempPeak: peakTemp,
      deflectionPeak: peakDeflection,
      totalMaterialRemoved: totalRemovedVol,
    };

    // Reset ThreeJS stock visual state
    if (this.scene) {
      this.resetStockHeightmap();
      this.drawToolpathLines();
      this.updateActiveTelemetryFrame();
    }
    this.cdr.markForCheck();
  }

  // What-If Scenario comparisons list
  initDefaultScenarios() {
    this.scenarios = [
      {
        id: 'Scenario A (Baseline)',
        material: 'Ti-6Al-4V',
        tool: 'Ø12mm Ball Nose',
        cooling: true,
        feedRate: 420,
        rpm: 2200,
        peakForce: 385,
        deflection: 14.2,
        timeSec: 18.5,
        wearMm: 0.024,
        temp: 345,
        status: 'STABLE',
      },
      {
        id: 'Scenario B (High Speed)',
        material: 'Ti-6Al-4V',
        tool: 'Ø12mm Ball Nose',
        cooling: true,
        feedRate: 850,
        rpm: 4800,
        peakForce: 780,
        deflection: 29.8,
        timeSec: 9.1,
        wearMm: 0.085,
        temp: 610,
        status: 'ELEVATED_WEAR',
      },
      {
        id: 'Scenario C (Dry Cutting)',
        material: 'Ti-6Al-4V',
        tool: 'Ø12mm Ball Nose',
        cooling: false,
        feedRate: 420,
        rpm: 2200,
        peakForce: 440,
        deflection: 16.5,
        timeSec: 18.5,
        wearMm: 0.145,
        temp: 840,
        status: 'CRITICAL_HEAT',
      }
    ];
  }

  // Custom simulation play/pause control loop
  togglePlayback() {
    this.isPlaying = !this.isPlaying;
    if (this.isPlaying) {
      if (this.currentFrameIndex >= this.simulationFrames.length - 1) {
        this.currentFrameIndex = 0;
        this.resetStockHeightmap();
      }
      this.playbackTimer = setInterval(() => {
        this.advanceFrame();
      }, 50 / this.playbackSpeed);
    } else {
      if (this.playbackTimer) {
        clearInterval(this.playbackTimer);
        this.playbackTimer = null;
      }
    }
    this.cdr.markForCheck();
  }

  stepForward() {
    this.isPlaying = false;
    if (this.playbackTimer) {
      clearInterval(this.playbackTimer);
      this.playbackTimer = null;
    }
    this.advanceFrame();
    this.cdr.markForCheck();
  }

  stepBackward() {
    this.isPlaying = false;
    if (this.playbackTimer) {
      clearInterval(this.playbackTimer);
      this.playbackTimer = null;
    }
    if (this.currentFrameIndex > 0) {
      this.currentFrameIndex--;
      this.updateActiveTelemetryFrame();
      this.syncStockVisualWithFrame(this.currentFrameIndex);
    }
    this.cdr.markForCheck();
  }

  advanceFrame() {
    if (this.currentFrameIndex < this.simulationFrames.length - 1) {
      this.currentFrameIndex++;
      this.updateActiveTelemetryFrame();
      this.carveStockAtFrame(this.currentFrameIndex);
    } else {
      this.isPlaying = false;
      if (this.playbackTimer) {
        clearInterval(this.playbackTimer);
        this.playbackTimer = null;
      }
    }
    this.cdr.markForCheck();
  }

  onTimelineChange(event: Event) {
    const target = event.target as HTMLInputElement;
    const idx = parseInt(target.value, 10);
    this.currentFrameIndex = idx;
    this.updateActiveTelemetryFrame();
    this.syncStockVisualWithFrame(idx);
    this.cdr.markForCheck();
  }

  onPlaybackSpeedChange(speed: number) {
    this.playbackSpeed = speed;
    if (this.isPlaying) {
      // restart timer with new speed
      if (this.playbackTimer) {
        clearInterval(this.playbackTimer);
      }
      this.playbackTimer = setInterval(() => {
        this.advanceFrame();
      }, 50 / this.playbackSpeed);
    }
  }

  updateActiveTelemetryFrame() {
    if (!this.simulationFrames || this.simulationFrames.length === 0) return;
    const rawFrame = this.simulationFrames[this.currentFrameIndex];
    if (!rawFrame) return;

    if (this.telemetrySource === 'REAL_CNC_LIVE') {
      // Add micro-noise and drift to mimic physical machine telemetry comparison
      const noiseForce = (Math.random() - 0.5) * 45 + this.realCncFeedNoise.forceNoise;
      const noiseTemp = (Math.random() - 0.5) * 15 + this.realCncFeedNoise.tempNoise;
      this.activeFrame = {
        ...rawFrame,
        forceTotal: Math.max(0, rawFrame.forceTotal + noiseForce),
        temperature: Math.max(25.0, rawFrame.temperature + noiseTemp),
        spindleSpeed: Math.max(0, rawFrame.spindleSpeed + this.realCncFeedNoise.rpmOffset),
      };
    } else {
      this.activeFrame = rawFrame;
    }

    // Move Three.js machine axes and cutting assembly
    this.updateSpindleThreeJsPose();
  }

  // Toggle Live hardware telemetry replay comparison
  toggleTelemetrySource(src: 'SIMULATED' | 'REAL_CNC_LIVE') {
    this.telemetrySource = src;
    if (src === 'REAL_CNC_LIVE') {
      this.realCncFeedNoise = {
        forceNoise: (Math.random() - 0.5) * 60,
        tempNoise: (Math.random() - 0.5) * 20,
        rpmOffset: Math.round((Math.random() - 0.5) * 100),
      };
    }
    this.updateActiveTelemetryFrame();
    this.cdr.markForCheck();
  }

  // Call server-side Gemini 3.8 Flash CAM engineering analysis model
  async analyzeToolpathWithAI() {
    this.isAnalyzingAI = true;
    this.aiAnalysisText = '';
    this.cdr.markForCheck();

    const diagnostics = {
      materialId: this.selectedMaterialId,
      toolId: this.selectedToolId,
      peakForces: this.statistics.forcePeak.toFixed(1) + ' N',
      peakDeflection: this.statistics.deflectionPeak.toFixed(1) + ' µm',
      peakTemperature: this.statistics.tempPeak.toFixed(1) + ' °C',
      hasCollisions: this.simulationFrames.some(f => f.collision === 'COLLISION'),
      chatterIndicator: this.statistics.forcePeak > 800 ? 'HIGH_RISK_OF_CHATTER_REGENERATIVE' : 'STABLE_CUTS',
    };

    try {
      const res = await fetch('/api/ai/optimize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gcode: this.gcodeProgram,
          material: MATERIALS[this.selectedMaterialId],
          tool: TOOLS[this.selectedToolId],
          diagnostics,
        }),
      });
      const data = await res.json();
      if (data.success) {
        this.aiAnalysisText = data.analysis;
        this.aiOptimizedGcode = data.optimizedGcode;
        this.aiRecommendedRpm = data.recommendedRpm;
        this.aiRecommendedFeed = data.recommendedFeed;
        this.aiSafetyMargin = data.safetyMargin || '20% safer';
      } else {
        this.aiAnalysisText = 'Error executing CAM AI Analysis: ' + data.error;
      }
    } catch (err: unknown) {
      const errMsg = err instanceof Error ? err.message : String(err);
      this.aiAnalysisText = 'Failed to communicate with AI server: ' + errMsg;
    } finally {
      this.isAnalyzingAI = false;
      this.cdr.markForCheck();
    }
  }

  applyAIOptimization() {
    if (this.aiOptimizedGcode) {
      this.gcodeProgram = this.aiOptimizedGcode;
      this.runPhysicsSimulation();
      this.aiAnalysisText = 'Optimized parameters and revised safe G-code block have been injected into active buffer!';
      this.cdr.markForCheck();
    }
  }

  // Probing (CMM gauges on nominal geometries)
  toggleProbingMode() {
    this.isProbingMode = !this.isProbingMode;
    if (!this.isProbingMode) {
      this.probeResults = { nominalZ: 125, actualZ: 125, error: 0, status: 'NO_MEASUREMENT' };
    }
    this.cdr.markForCheck();
  }

  // Interactive 3D Canvas initialization
  private initThreeJs() {
    const width = this.canvasRef.nativeElement.clientWidth;
    const height = this.canvasRef.nativeElement.clientHeight;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0f1d);
    
    // Add Fog for realistic workspace depth
    this.scene.fog = new THREE.FogExp2(0x0a0f1d, 0.002);

    this.camera = new THREE.PerspectiveCamera(40, width / height, 1, 1000);
    this.updateCameraPosition();

    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvasRef.nativeElement,
      antialias: true,
      alpha: false,
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(window.devicePixelRatio);
    this.renderer.shadowMap.enabled = true;

    // Professional Three-Point Studio Lighting
    const keyLight = new THREE.DirectionalLight(0xfff5ea, 1.2);
    keyLight.position.set(100, 150, 80);
    keyLight.castShadow = true;
    this.scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xdbeafe, 0.5);
    fillLight.position.set(-100, 100, -50);
    this.scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xffffff, 0.4);
    rimLight.position.set(0, -100, 150);
    this.scene.add(rimLight);

    const ambientLight = new THREE.AmbientLight(0x1e293b, 0.6);
    this.scene.add(ambientLight);

    // Grid Floor
    const gridHelper = new THREE.GridHelper(300, 30, 0x475569, 0x1e293b);
    gridHelper.position.y = -50;
    this.scene.add(gridHelper);

    // Build CNC Machine Structural components
    this.buildMachineComponents();

    // Resize handlers
    window.addEventListener('resize', () => this.onResize());
  }

  private buildMachineComponents() {
    // 1. Machine Table base
    const tableGeom = new THREE.BoxGeometry(200, 15, 160);
    const tableMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6 });
    this.tableMesh = new THREE.Mesh(tableGeom, tableMat);
    this.tableMesh.position.y = -42;
    this.scene.add(this.tableMesh);

    // 2. Vise / Fixture jaws
    const viseGeom = new THREE.BoxGeometry(130, 20, 110);
    const viseMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.4, metalness: 0.6 });
    this.viseMesh = new THREE.Mesh(viseGeom, viseMat);
    this.viseMesh.position.y = -25;
    this.scene.add(this.viseMesh);

    // 3. Build Stock block with heightmap plane geometry
    this.buildStockThreeJsGeometry();

    // 4. Cutting Spindle Column assembly
    this.spindleAssembly = new THREE.Group();
    this.scene.add(this.spindleAssembly);

    // Metal cutter body
    const colGeom = new THREE.CylinderGeometry(20, 20, 60, 16);
    const colMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.2, metalness: 0.8 });
    const column = new THREE.Mesh(colGeom, colMat);
    column.position.y = 50;
    this.spindleAssembly.add(column);

    // Shiny toolholder cone
    const holderGeom = new THREE.CylinderGeometry(14, 6, 25, 16);
    const holderMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.1, metalness: 0.95 });
    const toolholder = new THREE.Mesh(holderGeom, holderMat);
    toolholder.position.y = 125;
    this.spindleAssembly.add(toolholder);

    // The Cutting Tool itself
    const cutterGeom = new THREE.CylinderGeometry(6, 6, 40, 16);
    // Glowing cutting edge
    const cutterMat = new THREE.MeshStandardMaterial({
      color: 0xeab308,
      roughness: 0.3,
      metalness: 0.7,
      emissive: 0x451a03,
    });
    this.cutterMesh = new THREE.Mesh(cutterGeom, cutterMat);
    // Align tool bottom to match position
    this.cutterMesh.position.y = 92;
    this.spindleAssembly.add(this.cutterMesh);

    // Initial positioning of axes
    this.updateSpindleThreeJsPose();
  }

  // Core Stock Material removal visualization using heightfield geometry
  private buildStockThreeJsGeometry() {
    const dx = this.stockDimensions.dx;
    const dy = this.stockDimensions.dy;
    const res = this.stockGridResolution;

    const stockGeom = new THREE.PlaneGeometry(dx, dy, res - 1, res - 1);
    
    // Rotate 90 degrees to lay horizontal
    stockGeom.rotateX(-Math.PI / 2);

    // Initialize height map values
    const vertexCount = stockGeom.attributes['position'].count;
    this.initialHeightmap = [];
    this.currentHeightmap = [];
    this.heightmapColors = new Float32Array(vertexCount * 3);

    const posAttr = stockGeom.attributes['position'];
    for (let i = 0; i < vertexCount; i++) {
      // Set height dimension to the Z thickness of stock
      posAttr.setY(i, this.stockDimensions.dz / 2);
      this.initialHeightmap.push(this.stockDimensions.dz / 2);
      this.currentHeightmap.push(this.stockDimensions.dz / 2);

      // Default material finish: Steel blue/grey titanium
      this.heightmapColors[i * 3] = 0.27; // R
      this.heightmapColors[i * 3 + 1] = 0.35; // G
      this.heightmapColors[i * 3 + 2] = 0.47; // B
    }

    stockGeom.setAttribute('color', new THREE.BufferAttribute(this.heightmapColors, 3));
    stockGeom.computeVertexNormals();

    const stockMat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.5,
      metalness: 0.6,
      side: THREE.DoubleSide,
    });

    if (this.stockMesh) this.scene.remove(this.stockMesh);
    this.stockMesh = new THREE.Mesh(stockGeom, stockMat);
    // Position stock properly seated on the CNC vise (Y offset)
    this.stockMesh.position.y = 5;
    this.scene.add(this.stockMesh);
  }

  resetStockHeightmap() {
    if (!this.stockMesh) return;
    const geom = this.stockMesh.geometry as THREE.BufferGeometry;
    const posAttr = geom.attributes['position'];
    const colAttr = geom.attributes['color'];
    
    for (let i = 0; i < posAttr.count; i++) {
      posAttr.setY(i, this.initialHeightmap[i]);
      this.currentHeightmap[i] = this.initialHeightmap[i];

      // Reset steel colors
      this.heightmapColors[i * 3] = 0.27;
      this.heightmapColors[i * 3 + 1] = 0.35;
      this.heightmapColors[i * 3 + 2] = 0.47;
    }
    
    posAttr.needsUpdate = true;
    if (colAttr) colAttr.needsUpdate = true;
    geom.computeVertexNormals();
  }

  // Physical carving at tool coordinates
  private carveStockAtFrame(frameIdx: number) {
    if (!this.stockMesh) return;
    const frame = this.simulationFrames[frameIdx];
    if (!frame) return;

    const geom = this.stockMesh.geometry as THREE.BufferGeometry;
    const posAttr = geom.attributes['position'];
    const colAttr = geom.attributes['color'];

    const radius = TOOLS[this.selectedToolId]?.diameter / 2 || 6;
    
    // Convert current work pose back to stock coordinate system space
    // workX, workY, workZ
    const toolX = frame.workX;
    const toolY = frame.workY;
    const toolZ = frame.workZ - this.stockMesh.position.y; // Align offsets

    let updated = false;

    for (let i = 0; i < posAttr.count; i++) {
      // Mesh vertices positions relative to stock center
      const vx = posAttr.getX(i);
      const vy = posAttr.getZ(i); // Plane Y is mapped to Z axis locally
      const currHz = posAttr.getY(i);

      // Cartesian horizontal Euclidean distance from vertex to tool centerline
      const dist = Math.sqrt((vx - toolX) * (vx - toolX) + (vy - toolY) * (vy - toolY));

      if (dist < radius) {
        // Tool cuts down. Set coordinate height to match tool cut profile if deeper
        if (toolZ < currHz) {
          posAttr.setY(i, Math.max(-this.stockDimensions.dz / 2, toolZ));
          this.currentHeightmap[i] = toolZ;
          updated = true;

          // Compute heatmap color spectrum based on selected viewport attribute
          this.colorVertexByAttribute(i, frame);
        }
      }
    }

    if (updated) {
      posAttr.needsUpdate = true;
      if (colAttr) colAttr.needsUpdate = true;
      geom.computeVertexNormals();
    }
  }

  // Repaint vertices according to state forces, heats or errors
  private colorVertexByAttribute(idx: number, frame: SimulationFrame) {
    let r = 0.27, g = 0.35, b = 0.47; // Default Titanium steel finish

    if (this.viewportVisualMode === 'HEAT') {
      // Heat color palette: Cold (Steel blue) -> High Temp (Bright Red/Yellow)
      const tRatio = Math.min(1.0, (frame.temperature - 25) / 600); // normalized temp
      r = 0.27 + tRatio * 0.73;
      g = 0.35 * (1 - tRatio);
      b = 0.47 * (1 - tRatio);
    } else if (this.viewportVisualMode === 'FORCE') {
      // Force loading: Low (Green) -> Moderate (Amber) -> Overload (Red)
      const fRatio = Math.min(1.0, frame.forceTotal / 1000);
      r = fRatio > 0.5 ? 1.0 : fRatio * 2;
      g = fRatio > 0.5 ? 1.0 - (fRatio - 0.5) * 2 : 1.0;
      b = 0.2;
    } else if (this.viewportVisualMode === 'DEFLECTION') {
      // Tool bending deflection heatmap
      const dRatio = Math.min(1.0, frame.deflection / 30);
      r = 0.1 + dRatio * 0.9;
      g = 0.2;
      b = 0.7 - dRatio * 0.5;
    } else if (this.viewportVisualMode === 'DEVIATION') {
      // Surface scallop finish deviation
      const devRatio = Math.min(1.0, frame.predictedRa / 5);
      r = devRatio;
      g = 1.0 - devRatio;
      b = 0.3;
    }

    this.heightmapColors[idx * 3] = r;
    this.heightmapColors[idx * 3 + 1] = g;
    this.heightmapColors[idx * 3 + 2] = b;
  }

  syncStockVisualWithFrame(frameIdx: number) {
    this.resetStockHeightmap();
    for (let f = 0; f <= frameIdx; f++) {
      this.carveStockAtFrame(f);
    }
  }

  // Draw continuous toolpath blue routing wireframe
  private drawToolpathLines() {
    if (this.toolpathLine) this.scene.remove(this.toolpathLine);

    const points: THREE.Vector3[] = [];
    for (const frame of this.simulationFrames) {
      // Maps work poses in 3D scene space
      points.push(new THREE.Vector3(frame.workX, frame.workZ - 15, frame.workY));
    }

    const pathGeom = new THREE.BufferGeometry().setFromPoints(points);
    const pathMat = new THREE.LineBasicMaterial({
      color: 0x06b6d4, // Electric cyan line trail
      linewidth: 2,
    });

    this.toolpathLine = new THREE.Line(pathGeom, pathMat);
    this.scene.add(this.toolpathLine);
  }

  // Update physical spindle column coordinate motions
  private updateSpindleThreeJsPose() {
    if (!this.spindleAssembly || !this.activeFrame) return;

    // Direct kinematic linkage position mapping
    // Machine translation coordinates are mapped onto column joints
    const frame = this.activeFrame;
    this.spindleAssembly.position.set(frame.workX, frame.workZ - 10, frame.workY);

    // Apply high frequency rotation animation to mill flutes if speed is active
    if (frame.spindleSpeed > 0 && this.isPlaying) {
      this.cutterMesh.rotation.y += 0.25;
    }
  }

  onVisualModeChange(mode: 'MATERIAL' | 'FORCE' | 'HEAT' | 'DEFLECTION' | 'DEVIATION') {
    this.viewportVisualMode = mode;
    this.syncStockVisualWithFrame(this.currentFrameIndex);
  }

  // Custom high precision probing click handler on workpiece Mesh
  onCanvasClick(event: MouseEvent) {
    if (!this.isProbingMode || !this.stockMesh) return;

    // Simple raycast logic or simulated hover click
    const rect = this.canvasRef.nativeElement.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    // Transform normalized screen coordinates into stock spatial metrics
    // Since we are simulating a high precision gauge, we provide measurement data:
    const randomSeedX = Math.round((x * 40) + (Math.random() - 0.5) * 4);
    const randomSeedY = Math.round((y * 40) + (Math.random() - 0.5) * 4);

    // Ensure within stock grid bounds
    const clampedX = Math.max(-60, Math.min(60, randomSeedX));
    const clampedY = Math.max(-50, Math.min(50, randomSeedY));

    // Resolve the real heightmap depth at that specific pixel intersection
    const gridX = Math.floor(((clampedX + 60) / 120) * this.stockGridResolution);
    const gridY = Math.floor(((clampedY + 50) / 100) * this.stockGridResolution);
    const cellIdx = gridY * this.stockGridResolution + gridX;

    const actualZVal = this.currentHeightmap[cellIdx] !== undefined 
      ? this.currentHeightmap[cellIdx] + 45 // Offset base
      : 125;

    // Compare with the nominal raw block CAD thickness (125mm)
    const errorDev = actualZVal - 125.0;

    this.probeCoordinates = { x: clampedX, y: clampedY, z: actualZVal };
    this.probeResults = {
      nominalZ: 125.0,
      actualZ: actualZVal,
      error: errorDev,
      status: Math.abs(errorDev) < 0.05 ? 'TOLERANCE_VERIFIED' : 'OUT_OF_SPECIFICATION',
    };
    this.cdr.markForCheck();
  }

  // Camera Drag and Rotate handler
  onMouseDown(event: MouseEvent) {
    this.isDragging = true;
    this.previousMousePosition = { x: event.clientX, y: event.clientY };
  }

  onMouseMove(event: MouseEvent) {
    if (!this.isDragging) return;

    const deltaX = event.clientX - this.previousMousePosition.x;
    const deltaY = event.clientY - this.previousMousePosition.y;

    this.cameraRotation.theta -= deltaX * 0.007;
    this.cameraRotation.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, this.cameraRotation.phi + deltaY * 0.007));

    this.previousMousePosition = { x: event.clientX, y: event.clientY };
    this.updateCameraPosition();
  }

  onMouseUp() {
    this.isDragging = false;
  }

  onWheel(event: WheelEvent) {
    this.cameraRotation.radius = Math.max(80, Math.min(450, this.cameraRotation.radius + event.deltaY * 0.4));
    this.updateCameraPosition();
  }

  private updateCameraPosition() {
    const phi = this.cameraRotation.phi;
    const theta = this.cameraRotation.theta;
    const r = this.cameraRotation.radius;

    // Convert spherical coordinates to Cartesian
    const x = r * Math.sin(phi) * Math.sin(theta);
    const y = r * Math.cos(phi);
    const z = r * Math.sin(phi) * Math.cos(theta);

    this.camera.position.set(x, y, z);
    this.camera.lookAt(0, 0, 0);
  }

  private onResize() {
    if (!this.canvasRef) return;
    const width = this.canvasRef.nativeElement.clientWidth;
    const height = this.canvasRef.nativeElement.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  getSparklinePoints(attr: string): string {
    if (!this.simulationFrames || this.simulationFrames.length === 0) return '0,100 100,100';
    
    // Find maximum value to normalize coordinates
    let maxVal = 0.001;
    for (const frame of this.simulationFrames) {
      const val = (frame as unknown as Record<string, number>)[attr] || 0;
      if (val > maxVal) maxVal = val;
    }

    const points: string[] = [];
    const count = this.simulationFrames.length;
    for (let i = 0; i < count; i++) {
      const frame = this.simulationFrames[i];
      const val = (frame as unknown as Record<string, number>)[attr] || 0;
      const x = (i / (count - 1 || 1)) * 100;
      // SVG 0,0 is top-left, so invert Y
      const y = 100 - (val / maxVal) * 90;
      points.push(`${x.toFixed(1)},${y.toFixed(1)}`);
    }

    return points.join(' ');
  }

  private animate() {
    requestAnimationFrame(() => this.animate());
    this.renderer.render(this.scene, this.camera);
  }
}
