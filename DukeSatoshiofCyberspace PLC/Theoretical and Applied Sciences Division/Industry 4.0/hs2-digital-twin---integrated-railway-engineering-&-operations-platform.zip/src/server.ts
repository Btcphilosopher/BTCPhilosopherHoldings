import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());
const angularApp = new AngularNodeAppEngine();

// Typed REST API Endpoints for HS2 Digital Twin
app.get('/api/health', (req, res) => {
  res.json({
    status: 'HEALTHY',
    platform: 'HS2-DIGITAL-TWIN',
    version: '4.2.0-STABLE',
    timestamp: new Date().toISOString(),
    datasetChecksum: 'sha256:7f4a2199b0c6198f12ae019c4bb1',
    standardsCompliance: ['BS EN ISO 19650', 'EN 50126/EN 50128/EN 50129', 'ETCS Baseline 3 Release 2']
  });
});

app.get('/api/twin/metadata', (req, res) => {
  res.json({
    corridor: 'London Euston (CH 0+000) to Birmingham Curzon Street (CH 140+000)',
    designSpeedKmh: 360,
    tractionSystem: '2x25kV AC 50Hz Auto-Transformer',
    signallingSystem: 'ETCS Level 2 with Radio Block Centre (RBC)',
    assetCount: 842,
    sensorCount: 2150,
    disclaimer: 'SYNTHETIC DEMONSTRATION DATA — NOT OFFICIAL HS2 DATA'
  });
});

app.post('/api/twin/scenarios/run', (req, res) => {
  const { scenarioId } = req.body;
  res.json({
    executionId: `SIM-${Date.now()}`,
    scenarioId: scenarioId || 'SCENARIO-HYD-04',
    status: 'COMPLETED',
    simulatedDurationSec: 3600,
    impactResults: {
      affectedAssets: ['CVV-SPAN-28', 'DRN-CULV-042'],
      temporarySpeedRestrictionKmh: 80,
      estimatedDelayMin: 14.5,
      workOrdersGenerated: 1
    }
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
