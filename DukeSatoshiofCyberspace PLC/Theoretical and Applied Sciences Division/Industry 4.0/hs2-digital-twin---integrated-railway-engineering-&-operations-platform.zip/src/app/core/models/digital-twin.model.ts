// Universal Asset and Digital Twin Core Types conforming to BS EN ISO 19650 & Railway Engineering standards

export type AssetClass =
  // Civil
  | 'bridge'
  | 'viaduct'
  | 'tunnel'
  | 'portal'
  | 'cutting'
  | 'embankment'
  | 'retaining_wall'
  | 'earthwork'
  | 'culvert'
  | 'drainage_asset'
  | 'watercourse'
  // Rail
  | 'track'
  | 'rail'
  | 'sleeper'
  | 'slab'
  | 'ballast'
  | 'point'
  | 'crossing'
  | 'rail_joint'
  // Electrification (OLE)
  | 'overhead_line'
  | 'mast'
  | 'portal_gantry'
  | 'cantilever'
  | 'insulator'
  | 'transformer'
  | 'substation'
  | 'switchgear'
  | 'neutral_section'
  // Power
  | 'hv_cable'
  | 'lv_cable'
  | 'switchboard'
  | 'breaker'
  | 'ups'
  | 'battery'
  | 'autotransformer'
  // Signalling
  | 'balise'
  | 'radio_block_centre'
  | 'interlocking'
  | 'axle_counter'
  | 'train_detection'
  | 'signalling_controller'
  | 'movement_authority'
  // Communications
  | 'fibre'
  | 'gsm_r_antenna'
  | 'frmcs_radio'
  | 'network_switch'
  | 'data_centre'
  | 'telecoms_room'
  // Stations & Buildings
  | 'station'
  | 'platform'
  | 'concourse'
  | 'escalator'
  | 'lift'
  | 'door'
  | 'ventilation_fan'
  | 'fire_system'
  | 'mep_system'
  | 'canopy'
  // Environment
  | 'habitat'
  | 'water_body'
  | 'woodland'
  | 'noise_barrier'
  | 'air_quality_sensor'
  | 'weather_station'
  | 'ecological_asset';

export type LifecycleState =
  | 'DESIGNED'
  | 'PLANNED'
  | 'UNDER_CONSTRUCTION'
  | 'AS_BUILT'
  | 'COMMISSIONED'
  | 'OPERATIONAL'
  | 'OUT_OF_SERVICE'
  | 'UNDER_MAINTENANCE'
  | 'DECOMMISSIONED';

export type InformationStatus = 'WIP' | 'SHARED' | 'PUBLISHED' | 'ARCHIVED';

export type ValidationStatus = 'VALIDATED' | 'WARNING' | 'DEFECT' | 'OUTSIDE_ENVELOPE';

export type RelationshipType =
  | 'CONTAINS'
  | 'PART_OF'
  | 'LOCATED_ON'
  | 'CONNECTED_TO'
  | 'POWERED_BY'
  | 'CONTROLLED_BY'
  | 'MONITORED_BY'
  | 'MAINTAINED_BY'
  | 'DEPENDS_ON'
  | 'PROTECTS'
  | 'DRAINS_TO'
  | 'SUPPLIES'
  | 'SERVES'
  | 'ADJACENT_TO'
  | 'INTERFACES_WITH';

export interface AssetRelationship {
  type: RelationshipType;
  targetAssetId: string;
  targetName: string;
  targetClass: AssetClass;
  description?: string;
  criticality: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
}

export interface GeoReference {
  latitude: number;
  longitude: number;
  elevationM: number;
  bngEasting: number;
  bngNorthing: number;
  chainageKm: number;
  chainageFormatted: string;
  routeSection: string;
  trackOffsetM?: number;
}

export interface ProvenanceRecord {
  sourceSystem: string;
  sourceDocument: string;
  sourceObjectId: string;
  revision: string;
  discipline: string;
  author: string;
  organization: string;
  timestamp: string;
  approvalStatus: string;
  dataConfidence: number;
  provenanceChain: {
    stage: string;
    action: string;
    actor: string;
    date: string;
    hash: string;
  }[];
}

export interface SensorTelemetry {
  sensorId: string;
  metric: string;
  unit: string;
  currentValue: number;
  baselineValue: number;
  warningThreshold: number;
  criticalThreshold: number;
  rateOfChange: number;
  trend: 'STABLE' | 'RISING' | 'FALLING' | 'OSCILLATING';
  cusumAnomalyScore: number;
  health: 'GOOD' | 'WARNING' | 'CRITICAL' | 'STALE';
  lastObserved: string;
  sampleHistory: { timestamp: string; value: number }[];
}

export interface AssetDefect {
  defectId: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  title: string;
  description: string;
  dateFound: string;
  foundBy: string;
  status: 'OPEN' | 'UNDER_INVESTIGATION' | 'SCHEDULED_REPAIR' | 'VERIFIED_CLOSED';
  responsibleContractor: string;
  evidenceRef: string;
  resolutionPlan?: string;
}

export interface AssetTestRecord {
  testId: string;
  testCase: string;
  phase: 'FAT' | 'SAT' | 'INTEGRATION' | 'COMMISSIONING' | 'TRIAL_RUNNING';
  result: 'PASS' | 'FAIL' | 'IN_PROGRESS' | 'SCHEDULED';
  dateExecuted: string;
  inspector: string;
  certificateNumber: string;
  evidenceUrl: string;
}

export interface AssetCostCarbon {
  plannedCostGbp: number;
  committedCostGbp: number;
  actualCostGbp: number;
  forecastFinalCostGbp: number;
  costVarianceGbp: number;
  materialQuantity: number;
  materialUnit: string;
  materialType: string;
  embodiedCarbonKgCO2e: number;
  operationalCarbonAnnualKgCO2e: number;
  carbonReductionMeasure: string;
}

export interface Asset {
  assetId: string;
  parentAssetId?: string;
  name: string;
  assetClass: AssetClass;
  discipline: 'CIVIL' | 'TRACK' | 'ELECTRIFICATION' | 'POWER' | 'SIGNALLING' | 'TELECOMS' | 'STATION' | 'ENVIRONMENT' | 'TUNNELS';
  location: GeoReference;
  lifecycleState: LifecycleState;
  informationStatus: InformationStatus;
  validationStatus: ValidationStatus;
  confidence: number;
  
  engineeringParams: Record<string, string | number | boolean>;
  
  costCarbon: AssetCostCarbon;
  provenance: ProvenanceRecord;
  relationships: AssetRelationship[];
  sensors: SensorTelemetry[];
  defects: AssetDefect[];
  tests: AssetTestRecord[];
  
  maintenanceSchedule: {
    lastInspectionDate: string;
    nextInspectionDueDate: string;
    maintenanceFrequencyDays: number;
    conditionScore: number;
    remainingUsefulLifeYears: number;
    maintenanceHistoryCount: number;
  };

  constructionState?: {
    wbsCode: string;
    contractPackage: string;
    plannedStart: string;
    plannedFinish: string;
    actualStart?: string;
    actualFinish?: string;
    percentComplete: number;
    contractor: string;
  };

  geometryRef: {
    bimModelGuid?: string;
    ifcClass?: string;
    meshType: 'BOX' | 'CYLINDER' | 'VIADUCT_PIER' | 'TUNNEL_TUBE' | 'MAST' | 'RAIL_PAIR' | 'BUILDING' | 'SENSOR_POINT';
    dimensions: [number, number, number];
    colorOverride?: string;
  };
}

export interface RouteAlignmentPoint {
  chainageKm: number;
  chainageFormatted: string;
  easting: number;
  northing: number;
  elevationM: number;
  latitude: number;
  longitude: number;
  gradientPercent: number;
  horizontalRadiusM: number;
  appliedCantMm: number;
  equilibriumSpeedKmh: number;
  lineSpeedKmh: number;
  trackCategory: string;
  sectionName: string;
}

export interface TrainUnit {
  trainId: string;
  headcode: string;
  serviceName: string;
  rollingStockType: string;
  carCount: number;
  totalMassTonnes: number;
  lengthM: number;
  maxTractionPowerKw: number;
  maxSpeedKmh: number;
  
  currentChainageKm: number;
  currentSpeedKmh: number;
  targetSpeedKmh: number;
  accelerationMs2: number;
  pantographState: 'RAISED' | 'LOWERED' | 'FAULT';
  catenaryVoltageKv: number;
  tractionCurrentAmps: number;
  instantPowerKw: number;
  regenerativeEnergyKwh: number;
  doorState: 'LOCKED' | 'OPEN' | 'RELEASING';
  etcsMode: 'FULL_SUPERVISION' | 'ON_SIGHT' | 'SHUNTING' | 'STAFF_RESPONSIBLE';
  movementAuthorityDistanceM: number;
  nextStoppingStation: string;
  delayMinutes: number;
  status: 'ON_TIME' | 'DELAYED' | 'RESTRICTED' | 'STATION_DWELL';
}

export interface SubstationNode {
  nodeId: string;
  name: string;
  type: 'ATFS' | 'ATS' | 'MPFS' | 'GRID_FEED';
  chainageKm: number;
  ratedMva: number;
  currentLoadMva: number;
  busVoltageKv: number;
  powerFactor: number;
  thermalMarginPercent: number;
  feederSections: string[];
  operationalStatus: 'NORMAL' | 'HEAVY_LOAD' | 'ISOLATED' | 'TRIPPED';
}

export interface SignallingInterlockingArea {
  areaId: string;
  name: string;
  chainageStartKm: number;
  chainageEndKm: number;
  radioBlockCentreId: string;
  trackCircuits: {
    id: string;
    chainageKm: number;
    lengthM: number;
    occupied: boolean;
    assignedTrainId?: string;
  }[];
  routeLocked: boolean;
  activeMovementAuthorities: number;
  systemHealth: 'HEALTHY' | 'DEGRADED' | 'FAILSAFE_HALT';
}

export interface WeatherEnvironmentalState {
  chainageKm: number;
  locationName: string;
  temperatureC: number;
  rainfallMmHr: number;
  windSpeedKmh: number;
  windGustKmh: number;
  groundwaterTableM: number;
  soilMoistureIndex: number;
  drainageCulvertCapacityPercent: number;
  floodRiskLevel: 'LOW' | 'MODERATE' | 'HIGH' | 'SEVERE';
  noiseDb: number;
  airQualityAqi: number;
}
