import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RailwayPhysicsService {

  // British Standard & High Speed Rail Engineering Constants
  public readonly TRACK_GAUGE_M = 1.435; // Standard gauge
  public readonly GRAVITY_MS2 = 9.80665;
  public readonly OLE_WIRE_TENSION_N = 27000; // 27 kN high-speed tensioned contact wire
  public readonly OLE_WIRE_MASS_KG_M = 1.07; // CuMg contact wire mass per metre
  
  /**
   * Davis Equation: Total Train Resistance Force (N)
   */
  public calculateTrainResistance(
    speedKmh: number,
    massTonnes: number,
    inTunnel = false,
    gradientPercent = 0,
    curveRadiusM = 0
  ): {
    totalResistanceN: number;
    mechanicalRollingN: number;
    aerodynamicDragN: number;
    gradientForceN: number;
    curveResistanceN: number;
    powerRequiredKw: number;
  } {
    const vMs = (speedKmh * 1000) / 3600;
    const massKg = massTonnes * 1000;

    const A = 2.4 * massTonnes + 600;
    const B = 0.08 * massTonnes;
    let C = 0.55; 
    if (inTunnel) {
      C *= 1.38;
    }

    const mechanicalRollingN = A + B * vMs;
    const aerodynamicDragN = C * (vMs * vMs);
    const gradientForceN = massKg * this.GRAVITY_MS2 * (gradientPercent / 100);

    let curveResistanceN = 0;
    if (curveRadiusM > 100) {
      curveResistanceN = (6.8 / (curveRadiusM - 55)) * (massTonnes * this.GRAVITY_MS2);
    }

    const totalResistanceN = Math.max(0, mechanicalRollingN + aerodynamicDragN + gradientForceN + curveResistanceN);
    const powerRequiredKw = (totalResistanceN * vMs) / 1000;

    return {
      totalResistanceN,
      mechanicalRollingN,
      aerodynamicDragN,
      gradientForceN,
      curveResistanceN,
      powerRequiredKw
    };
  }

  /**
   * Cant Deficiency & Equilibrium Speed (EN 13803)
   */
  public calculateCantDynamics(
    speedKmh: number,
    curveRadiusM: number,
    appliedCantMm: number
  ): {
    equilibriumCantMm: number;
    cantDeficiencyMm: number;
    lateralAccelerationMs2: number;
    status: 'OPTIMAL' | 'ACCEPTABLE' | 'EXCESSIVE_DEFICIENCY' | 'EXCESSIVE_CANT';
  } {
    if (curveRadiusM <= 0 || !isFinite(curveRadiusM)) {
      return {
        equilibriumCantMm: 0,
        cantDeficiencyMm: -appliedCantMm,
        lateralAccelerationMs2: 0,
        status: 'OPTIMAL'
      };
    }

    const equilibriumCantMm = (11.82 * Math.pow(speedKmh, 2)) / curveRadiusM;
    const cantDeficiencyMm = equilibriumCantMm - appliedCantMm;
    const lateralAccelerationMs2 = (cantDeficiencyMm / 1000) * (this.GRAVITY_MS2 / this.TRACK_GAUGE_M);

    let status: 'OPTIMAL' | 'ACCEPTABLE' | 'EXCESSIVE_DEFICIENCY' | 'EXCESSIVE_CANT' = 'OPTIMAL';
    if (cantDeficiencyMm > 130) {
      status = 'EXCESSIVE_DEFICIENCY';
    } else if (cantDeficiencyMm < -70) {
      status = 'EXCESSIVE_CANT';
    } else if (Math.abs(cantDeficiencyMm) > 80) {
      status = 'ACCEPTABLE';
    }

    return {
      equilibriumCantMm,
      cantDeficiencyMm,
      lateralAccelerationMs2,
      status
    };
  }

  /**
   * Overhead Catenary Wave Propagation Speed (c = sqrt(T / mu))
   */
  public calculateOLEDynamics(
    trainSpeedKmh: number,
    wireTensionN = this.OLE_WIRE_TENSION_N,
    wireMassKgM = this.OLE_WIRE_MASS_KG_M
  ): {
    waveSpeedKmh: number;
    criticalSpeedRatio: number;
    contactQualityScore: number;
    upliftMm: number;
  } {
    const waveSpeedMs = Math.sqrt(wireTensionN / wireMassKgM);
    const waveSpeedKmh = (waveSpeedMs * 3600) / 1000;
    const criticalSpeedRatio = trainSpeedKmh / waveSpeedKmh;
    const contactQualityScore = Math.max(10, Math.min(100, (1 - (criticalSpeedRatio / 0.85)) * 100 + 20));
    const upliftMm = 20 + 45 * Math.pow(criticalSpeedRatio, 2);

    return {
      waveSpeedKmh,
      criticalSpeedRatio,
      contactQualityScore,
      upliftMm
    };
  }

  /**
   * 2x25kV Auto-Transformer Power System Voltage Drop
   */
  public calculatePowerDrop(
    distanceFromAtfsKm: number,
    loadCurrentAmps: number,
    nominalVoltageKv = 27.5
  ): {
    catenaryVoltageKv: number;
    voltageDropKv: number;
    lineImpedanceOhms: number;
    apparentPowerMva: number;
  } {
    const lineImpedanceOhms = 0.082 * distanceFromAtfsKm;
    const voltageDropKv = (loadCurrentAmps * lineImpedanceOhms) / 1000;
    const catenaryVoltageKv = Math.max(19.0, nominalVoltageKv - voltageDropKv);
    const apparentPowerMva = (catenaryVoltageKv * loadCurrentAmps) / 1000;

    return {
      catenaryVoltageKv,
      voltageDropKv,
      lineImpedanceOhms,
      apparentPowerMva
    };
  }

  /**
   * Statistical CUSUM / EWMA Anomaly Detection
   */
  public calculateCUSUMAnomaly(
    readings: number[],
    baselineMean: number,
    baselineStdDev: number,
    slackK = 0.5,
    thresholdH = 4.0
  ): {
    cusumPos: number;
    cusumNeg: number;
    isAnomaly: boolean;
    severityScore: number;
    explanation: string;
  } {
    if (!readings || readings.length === 0) {
      return { cusumPos: 0, cusumNeg: 0, isAnomaly: false, severityScore: 0, explanation: 'No data' };
    }

    let sPos = 0;
    let sNeg = 0;

    for (const val of readings) {
      const z = (val - baselineMean) / (baselineStdDev || 1);
      sPos = Math.max(0, sPos + z - slackK);
      sNeg = Math.max(0, sNeg - z - slackK);
    }

    const maxCusum = Math.max(sPos, sNeg);
    const isAnomaly = maxCusum >= thresholdH;
    const severityScore = Math.min(100, Math.round((maxCusum / thresholdH) * 75));

    let explanation = `Sensor telemetry within calibrated Gaussian bounds (CUSUM ${maxCusum.toFixed(2)} < ${thresholdH})`;
    if (isAnomaly) {
      explanation = `Statistically significant persistent drift detected! CUSUM statistic (${maxCusum.toFixed(2)}) exceeds decision interval h=${thresholdH}.`;
    }

    return {
      cusumPos: sPos,
      cusumNeg: sNeg,
      isAnomaly,
      severityScore,
      explanation
    };
  }

  public formatChainage(chainageKm: number): string {
    const km = Math.floor(chainageKm);
    const meters = Math.round((chainageKm - km) * 1000);
    const padded = meters.toString().padStart(3, '0');
    return `CH ${km}+${padded}`;
  }

  public parseChainage(str: string): number {
    const cleaned = str.toUpperCase().replace('CH', '').trim();
    const parts = cleaned.split('+');
    if (parts.length === 2) {
      const km = parseFloat(parts[0]) || 0;
      const m = parseFloat(parts[1]) || 0;
      return km + m / 1000;
    }
    return parseFloat(cleaned) || 0;
  }
}
