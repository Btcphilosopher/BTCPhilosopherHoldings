import { Injectable, signal, computed, inject } from '@angular/core';
import {
  Asset,
  LifecycleState,
  RouteAlignmentPoint,
  TrainUnit,
  SubstationNode,
  SignallingInterlockingArea,
  WeatherEnvironmentalState
} from '../models/digital-twin.model';
import { RailwayPhysicsService } from './railway-physics.service';

@Injectable({
  providedIn: 'root'
})
export class DigitalTwinDataService {
  public readonly physics = inject(RailwayPhysicsService);

  // Current global time machine state
  public readonly simTime = signal<Date>(new Date('2026-10-02T10:30:00Z'));
  public readonly activePhase = computed(() => {
    const year = this.simTime().getFullYear();
    if (year < 2025) return 'DESIGN_APPROVAL';
    if (year < 2027) return 'HEAVY_CIVIL_CONSTRUCTION';
    if (year < 2028) return 'RAIL_SYSTEMS_INSTALLATION';
    if (year < 2029) return 'TESTING_AND_COMMISSIONING';
    return 'REVENUE_OPERATIONS';
  });

  // Selected asset / route inspection state
  public readonly selectedAssetId = signal<string | null>('CVV-SPAN-28');
  public readonly activeChainage = signal<number>(26.850);
  public readonly activeFilterDiscipline = signal<string>('ALL');
  public readonly activeFilterLifecycle = signal<string>('ALL');
  public readonly searchQuery = signal<string>('');

  // Primary data arrays
  public readonly assets = signal<Asset[]>([]);
  public readonly routePoints = signal<RouteAlignmentPoint[]>([]);
  public readonly liveTrains = signal<TrainUnit[]>([]);
  public readonly substations = signal<SubstationNode[]>([]);
  public readonly interlockings = signal<SignallingInterlockingArea[]>([]);
  public readonly weatherSensors = signal<WeatherEnvironmentalState[]>([]);
  
  // Real-time telemetry events log
  public readonly eventLog = signal<{
    id: string;
    timestamp: string;
    category: 'TELEMETRY' | 'ALARM' | 'CONSTRUCTION' | 'OPERATIONS' | 'MAINTENANCE';
    severity: 'INFO' | 'WARNING' | 'CRITICAL';
    assetId: string;
    message: string;
  }[]>([]);

  // Active scenario injection (for What-If simulation)
  public readonly activeScenario = signal<{
    id: string;
    name: string;
    active: boolean;
    description: string;
    impactSummary: string;
    speedRestrictionKmh: number;
    culvertFloodPercent: number;
  } | null>(null);

  constructor() {
    this.generateCorridorData();
    this.initTelemetrySimulation();
  }

  public get selectedAsset(): Asset | undefined {
    const id = this.selectedAssetId();
    return this.assets().find(a => a.assetId === id);
  }

  public selectAsset(assetId: string) {
    this.selectedAssetId.set(assetId);
    const asset = this.assets().find(a => a.assetId === assetId);
    if (asset) {
      this.activeChainage.set(asset.location.chainageKm);
    }
  }

  public setChainage(chKm: number) {
    this.activeChainage.set(Math.max(0, Math.min(140, chKm)));
  }

  public setSimDate(date: Date) {
    this.simTime.set(date);
    const year = date.getFullYear();
    this.assets.update(current => 
      current.map(asset => {
        let state: LifecycleState = asset.lifecycleState;
        if (year <= 2024) {
          state = 'DESIGNED';
        } else if (year === 2025 || year === 2026) {
          state = asset.discipline === 'CIVIL' || asset.discipline === 'TUNNELS' ? 'UNDER_CONSTRUCTION' : 'PLANNED';
        } else if (year === 2027) {
          state = asset.discipline === 'CIVIL' || asset.discipline === 'TUNNELS' ? 'AS_BUILT' : 'UNDER_CONSTRUCTION';
        } else if (year === 2028) {
          state = 'COMMISSIONED';
        } else {
          state = 'OPERATIONAL';
        }
        return { ...asset, lifecycleState: state };
      })
    );
  }

  public triggerScenario(scenarioType: 'FLOOD_COLNE_VALLEY' | 'OLE_DEWIRING_RISK' | 'SUBSTATION_OUTAGE' | 'RESET') {
    if (scenarioType === 'RESET') {
      this.activeScenario.set(null);
      this.addEvent('OPERATIONS', 'INFO', 'SYSTEM', 'What-if scenario deactivated. Normal baseline restored.');
      return;
    }

    if (scenarioType === 'FLOOD_COLNE_VALLEY') {
      this.activeScenario.set({
        id: 'SCENARIO-HYD-04',
        name: 'Heavy Precipitation & River Colne Surcharge (CH 26+850)',
        active: true,
        description: 'Simulated 75mm/hr convective storm triggering drainage culvert backup and embankment piezometer pore pressure spike.',
        impactSummary: 'Temporary 80 km/h emergency speed restriction imposed between CH 25+000 and CH 28+500. 4 trains rescheduled.',
        speedRestrictionKmh: 80,
        culvertFloodPercent: 94
      });

      this.assets.update(list => 
        list.map(a => {
          if (a.assetId === 'CVV-SPAN-28' || a.assetId === 'DRN-CULV-042') {
            return {
              ...a,
              validationStatus: 'WARNING',
              sensors: a.sensors.map(s => ({
                ...s,
                currentValue: s.metric.includes('Pore') ? 142.5 : s.metric.includes('Water') ? 3.85 : s.currentValue,
                health: 'WARNING',
                trend: 'RISING'
              }))
            };
          }
          return a;
        })
      );

      this.addEvent('ALARM', 'CRITICAL', 'DRN-CULV-042', 'Hydraulic culvert capacity exceeded (94%). Automatic ETCS temporary speed restriction 80km/h generated.');
      this.addEvent('OPERATIONS', 'WARNING', 'RBC-COLNE-01', 'Radio Block Centre updated Movement Authorities for Trains 1A02, 1A04.');
    }
  }

  private addEvent(
    category: 'TELEMETRY' | 'ALARM' | 'CONSTRUCTION' | 'OPERATIONS' | 'MAINTENANCE',
    severity: 'INFO' | 'WARNING' | 'CRITICAL',
    assetId: string,
    message: string
  ) {
    const newEvent = {
      id: `EVT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString().substring(11, 19),
      category,
      severity,
      assetId,
      message
    };
    this.eventLog.update(logs => [newEvent, ...logs.slice(0, 49)]);
  }

  private generateCorridorData() {
    const points: RouteAlignmentPoint[] = [];
    const generatedAssets: Asset[] = [];

    // 1. Generate Continuous Alignment from CH 0+000 to CH 140+000 (every 500m)
    for (let km = 0; km <= 140; km += 0.5) {
      const chStr = this.physics.formatChainage(km);
      const bngE = 528000 - km * 820 + Math.sin(km / 5) * 450;
      const bngN = 182000 + km * 760 + Math.cos(km / 8) * 320;
      const lat = 51.528 + km * 0.0068;
      const lng = -0.133 - km * 0.0125;
      
      let elev = 35 + Math.sin(km / 6) * 40;
      let grad = Math.cos(km / 6) * 1.8;
      if (km >= 29 && km <= 45) {
        elev = 65 - Math.sin(((km - 29) / 16) * Math.PI) * 55;
        grad = -0.65;
      }

      let radius = 0;
      let cant = 0;
      let lineSpeed = 360;
      if (km < 10) lineSpeed = 230;
      if (km >= 24 && km <= 28) {
        radius = 5600;
        cant = 110;
      } else if (km >= 50 && km <= 55) {
        radius = 7200;
        cant = 85;
      }

      const eqSpeed = radius > 0 ? Math.round(Math.sqrt((cant * radius) / 11.82)) : lineSpeed;

      let section = 'Section 1: London Approaches (S1/S2)';
      if (km > 22 && km <= 48) section = 'Section 2: Chilterns & Colne Valley (C1)';
      else if (km > 48 && km <= 90) section = 'Section 3: North Portal to Calvert (C2/C3)';
      else if (km > 90) section = 'Section 4: Midlands Corridor & Curzon St (N1/N2)';

      points.push({
        chainageKm: km,
        chainageFormatted: chStr,
        easting: Math.round(bngE),
        northing: Math.round(bngN),
        elevationM: Math.round(elev * 10) / 10,
        latitude: lat,
        longitude: lng,
        gradientPercent: Math.round(grad * 100) / 100,
        horizontalRadiusM: radius,
        appliedCantMm: cant,
        equilibriumSpeedKmh: eqSpeed,
        lineSpeedKmh: lineSpeed,
        trackCategory: 'HS2-Dedicated-Slab',
        sectionName: section
      });
    }
    this.routePoints.set(points);

    // 2. Colne Valley Viaduct
    generatedAssets.push({
      assetId: 'CVV-SPAN-28',
      name: 'Colne Valley Viaduct — Pier & Span 28 (Mid-Lake Crossing)',
      assetClass: 'viaduct',
      discipline: 'CIVIL',
      location: {
        latitude: 51.6052,
        longitude: -0.5012,
        elevationM: 48.5,
        bngEasting: 504210,
        bngNorthing: 191340,
        chainageKm: 26.850,
        chainageFormatted: 'CH 26+850',
        routeSection: 'C1 Package — Colne Valley'
      },
      lifecycleState: 'OPERATIONAL',
      informationStatus: 'PUBLISHED',
      validationStatus: 'VALIDATED',
      confidence: 99.4,
      engineeringParams: {
        structureLengthM: 3370,
        spanLengthM: 60.0,
        pierHeightM: 14.2,
        concreteGrade: 'C50/60 Low-Carbon GGBS (65% replacement)',
        deckType: 'Post-Tensioned Segmental Match-Cast Box Girder',
        foundationType: '4x 2.0m Bored Piles into Chalk (35m depth)',
        bearingType: 'Spherical Pot Bearings with PTFE Sliding Plate'
      },
      costCarbon: {
        plannedCostGbp: 14200000,
        committedCostGbp: 14150000,
        actualCostGbp: 13980000,
        forecastFinalCostGbp: 14020000,
        costVarianceGbp: -180000,
        materialQuantity: 1840,
        materialUnit: 'm3 concrete + 320t steel',
        materialType: 'CEM III/B Low Carbon Concrete',
        embodiedCarbonKgCO2e: 482000,
        operationalCarbonAnnualKgCO2e: 1200,
        carbonReductionMeasure: '65% GGBS replacement reduced embodied carbon by 41%.'
      },
      provenance: {
        sourceSystem: 'Bentley ProjectWise CDE / BIM OpenBuildings',
        sourceDocument: 'HS2-C1-STR-CVV-DWG-002841-RevC',
        sourceObjectId: 'IFC4_GUID_3kL98f02aD_P28',
        revision: 'P04.1 APPROVED_AS_BUILT',
        discipline: 'CIVIL_STRUCTURES',
        author: 'Align JV Lead Structural Engineer',
        organization: 'Bouygues / VolkerFitzpatrick / Sir Robert McAlpine JV',
        timestamp: '2026-03-15T14:30:00Z',
        approvalStatus: 'ACCEPTED_BY_HS2_CHIEF_ENGINEER',
        dataConfidence: 99.8,
        provenanceChain: [
          { stage: 'DESIGN', action: 'Approved Detailed Engineering Model', actor: 'Jacobs/Systra Design JV', date: '2023-04-12', hash: 'sha256:d8a2...3f1' },
          { stage: 'CONSTRUCTION', action: 'Segment 28-04 match-cast erected', actor: 'Align Segment Team', date: '2024-11-20', hash: 'sha256:f12a...7c9' },
          { stage: 'AS-BUILT', action: 'Laser Scan Point Cloud Federation verified', actor: 'Fugro Survey Services', date: '2025-08-10', hash: 'sha256:99c1...a1e' }
        ]
      },
      relationships: [
        { type: 'LOCATED_ON', targetAssetId: 'FND-PIER-28', targetName: 'Deep Piled Foundation Pier 28', targetClass: 'earthwork', criticality: 'CRITICAL' },
        { type: 'CONTAINS', targetAssetId: 'TRK-SLAB-26800', targetName: 'Slab Track Section Colne-28', targetClass: 'slab', criticality: 'CRITICAL' }
      ],
      sensors: [
        {
          sensorId: 'SHM-TILT-28A',
          metric: 'Pier Transverse Tilt',
          unit: 'mrad',
          currentValue: 0.12,
          baselineValue: 0.08,
          warningThreshold: 0.85,
          criticalThreshold: 1.50,
          rateOfChange: 0.002,
          trend: 'STABLE',
          cusumAnomalyScore: 0.18,
          health: 'GOOD',
          lastObserved: '2026-10-02T10:29:45Z',
          sampleHistory: [
            { timestamp: '10:00', value: 0.11 },
            { timestamp: '10:10', value: 0.12 },
            { timestamp: '10:20', value: 0.12 },
            { timestamp: '10:30', value: 0.12 }
          ]
        },
        {
          sensorId: 'SHM-STR-BOTDA-28',
          metric: 'Bottom Flange Post-Tensioning Strain',
          unit: 'microstrain',
          currentValue: 342,
          baselineValue: 338,
          warningThreshold: 650,
          criticalThreshold: 900,
          rateOfChange: 0.4,
          trend: 'STABLE',
          cusumAnomalyScore: 0.22,
          health: 'GOOD',
          lastObserved: '2026-10-02T10:29:50Z',
          sampleHistory: [
            { timestamp: '10:00', value: 340 },
            { timestamp: '10:10', value: 341 },
            { timestamp: '10:20', value: 342 },
            { timestamp: '10:30', value: 342 }
          ]
        }
      ],
      defects: [],
      tests: [
        { testId: 'TST-CVV-SAT-01', testCase: 'Dynamic Train Load Test (2x 400m Trains @ 320km/h)', phase: 'TRIAL_RUNNING', result: 'PASS', dateExecuted: '2026-02-14', inspector: 'M. Davies', certificateNumber: 'CERT-CVV-DYN-882', evidenceUrl: '/cde/evidence/CERT-CVV-DYN-882.pdf' }
      ],
      maintenanceSchedule: {
        lastInspectionDate: '2026-08-12',
        nextInspectionDueDate: '2027-02-12',
        maintenanceFrequencyDays: 180,
        conditionScore: 1,
        remainingUsefulLifeYears: 118,
        maintenanceHistoryCount: 3
      },
      geometryRef: {
        meshType: 'VIADUCT_PIER',
        dimensions: [60, 14, 16],
        colorOverride: '#64748b'
      }
    });

    // 3. Chiltern Tunnel South Portal
    generatedAssets.push({
      assetId: 'TUN-CHIL-SOUTH',
      name: 'Chiltern Tunnel — Twin Tube Bore & South Portal',
      assetClass: 'tunnel',
      discipline: 'TUNNELS',
      location: {
        latitude: 51.6210,
        longitude: -0.5280,
        elevationM: 52.0,
        bngEasting: 502100,
        bngNorthing: 193400,
        chainageKm: 29.200,
        chainageFormatted: 'CH 29+200',
        routeSection: 'C1 Package — Chiltern Tunnels'
      },
      lifecycleState: 'OPERATIONAL',
      informationStatus: 'PUBLISHED',
      validationStatus: 'VALIDATED',
      confidence: 99.6,
      engineeringParams: {
        tunnelLengthKm: 16.04,
        internalDiameterM: 9.10,
        liningType: 'Precast Fibre-Reinforced Concrete Rings (7+1 key)',
        tbmUsed: 'Florence & Cecilia (Herrenknecht 10.26m Mixshield)'
      },
      costCarbon: {
        plannedCostGbp: 1250000000,
        committedCostGbp: 1240000000,
        actualCostGbp: 1225000000,
        forecastFinalCostGbp: 1230000000,
        costVarianceGbp: -20000000,
        materialQuantity: 112000,
        materialUnit: 'precast concrete segments',
        materialType: 'Steel Fibre Reinforced Concrete',
        embodiedCarbonKgCO2e: 42000000,
        operationalCarbonAnnualKgCO2e: 185000,
        carbonReductionMeasure: 'Chalk slurry excavation recycled into 127 ha chalk grassland habitat.'
      },
      provenance: {
        sourceSystem: 'Aconex / GIS Enterprise',
        sourceDocument: 'HS2-C1-TUN-CHL-REP-00109-RevE',
        sourceObjectId: 'IFC4_TUN_CHIL_001',
        revision: 'P05 AS_BUILT_VERIFIED',
        discipline: 'TUNNELLING',
        author: 'Chiltern Tunnel Project Director',
        organization: 'Align JV',
        timestamp: '2026-01-20T09:00:00Z',
        approvalStatus: 'APPROVED_BY_REGULATOR',
        dataConfidence: 99.9,
        provenanceChain: []
      },
      relationships: [],
      sensors: [
        {
          sensorId: 'TUN-INGRESS-01',
          metric: 'Water Ingress Sump Flow Rate',
          unit: 'L/s',
          currentValue: 1.45,
          baselineValue: 1.20,
          warningThreshold: 8.00,
          criticalThreshold: 15.00,
          rateOfChange: 0.01,
          trend: 'STABLE',
          cusumAnomalyScore: 0.05,
          health: 'GOOD',
          lastObserved: '2026-10-02T10:29:55Z',
          sampleHistory: [
            { timestamp: '10:00', value: 1.42 },
            { timestamp: '10:10', value: 1.43 },
            { timestamp: '10:20', value: 1.45 },
            { timestamp: '10:30', value: 1.45 }
          ]
        }
      ],
      defects: [],
      tests: [],
      maintenanceSchedule: {
        lastInspectionDate: '2026-09-01',
        nextInspectionDueDate: '2027-03-01',
        maintenanceFrequencyDays: 180,
        conditionScore: 1,
        remainingUsefulLifeYears: 120,
        maintenanceHistoryCount: 4
      },
      geometryRef: {
        meshType: 'TUNNEL_TUBE',
        dimensions: [16040, 10.2, 10.2],
        colorOverride: '#334155'
      }
    });

    // 4. Old Oak Common Super-Hub Station
    generatedAssets.push({
      assetId: 'STN-OOC-01',
      name: 'Old Oak Common Super-Hub Station (14 Platforms)',
      assetClass: 'station',
      discipline: 'STATION',
      location: {
        latitude: 51.5245,
        longitude: -0.2440,
        elevationM: 22.0,
        bngEasting: 521800,
        bngNorthing: 182100,
        chainageKm: 7.450,
        chainageFormatted: 'CH 7+450',
        routeSection: 'S1 Package — Old Oak Common'
      },
      lifecycleState: 'OPERATIONAL',
      informationStatus: 'PUBLISHED',
      validationStatus: 'VALIDATED',
      confidence: 99.2,
      engineeringParams: {
        platformCount: 14,
        hs2UndergroundPlatforms: 6,
        surfaceElizabethLinePlatforms: 8,
        boxExcavationVolumeM3: 1300000,
        dailyPassengerCapacity: 250000
      },
      costCarbon: {
        plannedCostGbp: 1650000000,
        committedCostGbp: 1620000000,
        actualCostGbp: 1610000000,
        forecastFinalCostGbp: 1615000000,
        costVarianceGbp: -35000000,
        materialQuantity: 24000,
        materialUnit: 'tonnes steel roof trusses',
        materialType: 'Structural Recycled Steel',
        embodiedCarbonKgCO2e: 56000000,
        operationalCarbonAnnualKgCO2e: 45000,
        carbonReductionMeasure: '1.8 MWp rooftop solar array.'
      },
      provenance: {
        sourceSystem: 'Autodesk Construction Cloud (ACC)',
        sourceDocument: 'HS2-S1-BIM-OOC-MOD-009912',
        sourceObjectId: 'IFC4_STN_OOC_CENTRAL',
        revision: 'P06 PUBLISHED_AS_BUILT',
        discipline: 'ARCHITECTURE_AND_MEP',
        author: 'BBVS JV Lead',
        organization: 'BBVS JV',
        timestamp: '2026-04-10T11:00:00Z',
        approvalStatus: 'ACCEPTED',
        dataConfidence: 99.5,
        provenanceChain: []
      },
      relationships: [],
      sensors: [],
      defects: [],
      tests: [],
      maintenanceSchedule: {
        lastInspectionDate: '2026-09-15',
        nextInspectionDueDate: '2027-03-15',
        maintenanceFrequencyDays: 180,
        conditionScore: 1,
        remainingUsefulLifeYears: 100,
        maintenanceHistoryCount: 5
      },
      geometryRef: {
        meshType: 'BUILDING',
        dimensions: [420, 120, 32],
        colorOverride: '#0284c7'
      }
    });

    // 5. Culvert Drainage Colne-042
    generatedAssets.push({
      assetId: 'DRN-CULV-042',
      name: 'High-Capacity Attenuation Siphon Culvert Colne-042',
      assetClass: 'culvert',
      discipline: 'CIVIL',
      location: {
        latitude: 51.6045,
        longitude: -0.5005,
        elevationM: 38.2,
        bngEasting: 504260,
        bngNorthing: 191290,
        chainageKm: 26.890,
        chainageFormatted: 'CH 26+890',
        routeSection: 'C1 Package — Drainage & Civils'
      },
      lifecycleState: 'OPERATIONAL',
      informationStatus: 'PUBLISHED',
      validationStatus: 'VALIDATED',
      confidence: 98.9,
      engineeringParams: {
        pipeDiameterMm: 1800,
        hydroBrakeFlowLimiter: 'Active Vortex Flow Control (max 450 L/s)',
        siltTrapCapacityM3: 45
      },
      costCarbon: {
        plannedCostGbp: 820000,
        committedCostGbp: 810000,
        actualCostGbp: 795000,
        forecastFinalCostGbp: 795000,
        costVarianceGbp: -25000,
        materialQuantity: 160,
        materialUnit: 'm3 precast concrete',
        materialType: 'Precast Box Culvert',
        embodiedCarbonKgCO2e: 41200,
        operationalCarbonAnnualKgCO2e: 80,
        carbonReductionMeasure: 'Integrated reed bed swale bio-filtration zone.'
      },
      provenance: {
        sourceSystem: 'GIS Drainage Asset Manager',
        sourceDocument: 'HS2-DRN-CALC-CVV-0042',
        sourceObjectId: 'GIS_CULV_042',
        revision: 'P03 APPROVED',
        discipline: 'DRAINAGE',
        author: 'Hydrology Team Lead',
        organization: 'Align JV',
        timestamp: '2025-11-10T14:00:00Z',
        approvalStatus: 'ACCEPTED',
        dataConfidence: 99.1,
        provenanceChain: []
      },
      relationships: [],
      sensors: [
        {
          sensorId: 'HYD-LVL-042',
          metric: 'Culvert Water Ingress Depth',
          unit: 'm',
          currentValue: 0.62,
          baselineValue: 0.45,
          warningThreshold: 1.40,
          criticalThreshold: 1.80,
          rateOfChange: 0.02,
          trend: 'STABLE',
          cusumAnomalyScore: 0.15,
          health: 'GOOD',
          lastObserved: '2026-10-02T10:30:00Z',
          sampleHistory: [
            { timestamp: '10:00', value: 0.58 },
            { timestamp: '10:10', value: 0.60 },
            { timestamp: '10:20', value: 0.61 },
            { timestamp: '10:30', value: 0.62 }
          ]
        }
      ],
      defects: [],
      tests: [],
      maintenanceSchedule: {
        lastInspectionDate: '2026-06-10',
        nextInspectionDueDate: '2026-12-10',
        maintenanceFrequencyDays: 180,
        conditionScore: 1,
        remainingUsefulLifeYears: 80,
        maintenanceHistoryCount: 4
      },
      geometryRef: {
        meshType: 'CYLINDER',
        dimensions: [25, 2, 2],
        colorOverride: '#06b6d4'
      }
    });

    // 6. Generate Track, Mast, Balise & Signalling assets along corridor
    for (let km = 0; km <= 140; km += 2) {
      const chStr = this.physics.formatChainage(km);
      
      // Track Slab
      generatedAssets.push({
        assetId: `TRK-SLAB-${Math.round(km * 1000)}`,
        name: `High-Speed Porr Slab Track Segment (${chStr})`,
        assetClass: 'slab',
        discipline: 'TRACK',
        location: {
          latitude: 51.528 + km * 0.0068,
          longitude: -0.133 - km * 0.0125,
          elevationM: 35 + Math.sin(km / 6) * 40,
          bngEasting: Math.round(528000 - km * 820),
          bngNorthing: Math.round(182000 + km * 760),
          chainageKm: km,
          chainageFormatted: chStr,
          routeSection: `Section at ${chStr}`
        },
        lifecycleState: 'OPERATIONAL',
        informationStatus: 'PUBLISHED',
        validationStatus: 'VALIDATED',
        confidence: 99.0,
        engineeringParams: {
          railType: 'UIC 60E1 Heat-Treated 350HT',
          trackGaugeMm: 1435,
          slabSystem: 'Porr Slab Track Precast Slab System',
          fastenerType: 'Vossloh 300-1 System'
        },
        costCarbon: {
          plannedCostGbp: 420000,
          committedCostGbp: 415000,
          actualCostGbp: 410000,
          forecastFinalCostGbp: 410000,
          costVarianceGbp: -10000,
          materialQuantity: 84,
          materialUnit: 'm3 precision precast concrete',
          materialType: 'High-durability concrete',
          embodiedCarbonKgCO2e: 18400,
          operationalCarbonAnnualKgCO2e: 120,
          carbonReductionMeasure: 'Continuous welded rail elimination of rail joints.'
        },
        provenance: {
          sourceSystem: 'Railway Track Geometry Database',
          sourceDocument: `HS2-TRK-VER-${Math.round(km)}`,
          sourceObjectId: `TRK_PORR_${Math.round(km)}`,
          revision: 'P03 CERTIFIED',
          discipline: 'PERMANENT_WAY',
          author: 'P-Way Engineering Lead',
          organization: 'HS2 Track Systems Alliance',
          timestamp: '2026-03-01T08:00:00Z',
          approvalStatus: 'ACCEPTED',
          dataConfidence: 99.4,
          provenanceChain: []
        },
        relationships: [],
        sensors: [],
        defects: [],
        tests: [],
        maintenanceSchedule: {
          lastInspectionDate: '2026-09-10',
          nextInspectionDueDate: '2026-12-10',
          maintenanceFrequencyDays: 90,
          conditionScore: 1,
          remainingUsefulLifeYears: 59,
          maintenanceHistoryCount: 4
        },
        geometryRef: {
          meshType: 'RAIL_PAIR',
          dimensions: [2000, 3.4, 0.4],
          colorOverride: '#94a3b8'
        }
      });

      // OLE Mast
      generatedAssets.push({
        assetId: `OLE-MST-${Math.round(km * 1000)}`,
        name: `Series 1 High-Speed OLE Mast & Cantilever (${chStr})`,
        assetClass: 'mast',
        discipline: 'ELECTRIFICATION',
        location: {
          latitude: 51.528 + km * 0.0068 + 0.0001,
          longitude: -0.133 - km * 0.0125,
          elevationM: 35 + Math.sin(km / 6) * 40,
          bngEasting: Math.round(528000 - km * 820 + 3),
          bngNorthing: Math.round(182000 + km * 760),
          chainageKm: km,
          chainageFormatted: chStr,
          routeSection: `OLE Section at ${chStr}`
        },
        lifecycleState: 'OPERATIONAL',
        informationStatus: 'PUBLISHED',
        validationStatus: 'VALIDATED',
        confidence: 99.2,
        engineeringParams: {
          nominalWireHeightM: 5.08,
          wireTensionKn: 27.0,
          spanLengthM: 55.0
        },
        costCarbon: {
          plannedCostGbp: 38000,
          committedCostGbp: 37500,
          actualCostGbp: 37200,
          forecastFinalCostGbp: 37200,
          costVarianceGbp: -800,
          materialQuantity: 1.8,
          materialUnit: 'tonnes steel',
          materialType: 'Structural Steel S355 Galvanized',
          embodiedCarbonKgCO2e: 4900,
          operationalCarbonAnnualKgCO2e: 15,
          carbonReductionMeasure: 'Optimised aerodynamic profile.'
        },
        provenance: {
          sourceSystem: 'BIM Electrification Subsystem',
          sourceDocument: `HS2-OLE-MST-${Math.round(km)}`,
          sourceObjectId: `OLE_MST_${Math.round(km)}`,
          revision: 'P04 AS_BUILT',
          discipline: 'ELECTRIFICATION_OLE',
          author: 'Overhead Line Lead Engineer',
          organization: 'Furrer+Frey / HS2 Alliance',
          timestamp: '2026-03-10T10:00:00Z',
          approvalStatus: 'ACCEPTED',
          dataConfidence: 99.5,
          provenanceChain: []
        },
        relationships: [],
        sensors: [],
        defects: [],
        tests: [],
        maintenanceSchedule: {
          lastInspectionDate: '2026-07-15',
          nextInspectionDueDate: '2027-01-15',
          maintenanceFrequencyDays: 180,
          conditionScore: 1,
          remainingUsefulLifeYears: 50,
          maintenanceHistoryCount: 2
        },
        geometryRef: {
          meshType: 'MAST',
          dimensions: [0.4, 0.4, 7.8],
          colorOverride: '#f59e0b'
        }
      });

      // Eurobalise
      generatedAssets.push({
        assetId: `SIG-BAL-${Math.round(km * 1000)}`,
        name: `ETCS Level 2 Fixed Eurobalise Group (${chStr})`,
        assetClass: 'balise',
        discipline: 'SIGNALLING',
        location: {
          latitude: 51.528 + km * 0.0068,
          longitude: -0.133 - km * 0.0125,
          elevationM: 35 + Math.sin(km / 6) * 40,
          bngEasting: Math.round(528000 - km * 820),
          bngNorthing: Math.round(182000 + km * 760),
          chainageKm: km,
          chainageFormatted: chStr,
          routeSection: `Signalling Block at ${chStr}`
        },
        lifecycleState: 'OPERATIONAL',
        informationStatus: 'PUBLISHED',
        validationStatus: 'VALIDATED',
        confidence: 99.9,
        engineeringParams: {
          etcsBaseline: 'ETCS Baseline 3 Release 2 (MR1)',
          transmissionFrequencyMhz: 27.095,
          telePoweringVoltage: '27V Telepowering from Train BTM Antenna'
        },
        costCarbon: {
          plannedCostGbp: 14500,
          committedCostGbp: 14200,
          actualCostGbp: 14100,
          forecastFinalCostGbp: 14100,
          costVarianceGbp: -400,
          materialQuantity: 0.02,
          materialUnit: 'composite enclosure',
          materialType: 'Polycarbonate UV Resistant Enclosure',
          embodiedCarbonKgCO2e: 85,
          operationalCarbonAnnualKgCO2e: 0,
          carbonReductionMeasure: 'Passive unpowered transponder draws energy solely from passing train.'
        },
        provenance: {
          sourceSystem: 'Hitachi Rail ETCS Engineering Workbench',
          sourceDocument: `HS2-SIG-BAL-${Math.round(km)}`,
          sourceObjectId: `BALISE_${Math.round(km)}`,
          revision: 'P05 SIL4_CERTIFIED',
          discipline: 'SIGNALLING_ETCS',
          author: 'Safety Signalling Lead Engineer',
          organization: 'Hitachi Rail STS',
          timestamp: '2026-04-02T12:00:00Z',
          approvalStatus: 'ACCEPTED',
          dataConfidence: 99.9,
          provenanceChain: []
        },
        relationships: [],
        sensors: [],
        defects: [],
        tests: [],
        maintenanceSchedule: {
          lastInspectionDate: '2026-08-20',
          nextInspectionDueDate: '2027-08-20',
          maintenanceFrequencyDays: 365,
          conditionScore: 1,
          remainingUsefulLifeYears: 25,
          maintenanceHistoryCount: 1
        },
        geometryRef: {
          meshType: 'SENSOR_POINT',
          dimensions: [0.6, 0.4, 0.1],
          colorOverride: '#10b981'
        }
      });
    }

    this.assets.set(generatedAssets);

    // 7. Live Demonstrator Trains
    this.liveTrains.set([
      {
        trainId: 'HS2-TRAIN-001',
        headcode: '1A02',
        serviceName: 'London Euston -> Birmingham Curzon Street Express',
        rollingStockType: 'Hitachi-Alstom HS2 V360 (8-car 200m set)',
        carCount: 8,
        totalMassTonnes: 440,
        lengthM: 200,
        maxTractionPowerKw: 9600,
        maxSpeedKmh: 360,
        currentChainageKm: 27.200,
        currentSpeedKmh: 318,
        targetSpeedKmh: 320,
        accelerationMs2: 0.15,
        pantographState: 'RAISED',
        catenaryVoltageKv: 26.8,
        tractionCurrentAmps: 245,
        instantPowerKw: 6566,
        regenerativeEnergyKwh: 1420,
        doorState: 'LOCKED',
        etcsMode: 'FULL_SUPERVISION',
        movementAuthorityDistanceM: 8400,
        nextStoppingStation: 'Birmingham Interchange (CH 120+000)',
        delayMinutes: 0,
        status: 'ON_TIME'
      },
      {
        trainId: 'HS2-TRAIN-002',
        headcode: '1A04',
        serviceName: 'Birmingham Curzon Street -> London Euston Express',
        rollingStockType: 'Hitachi-Alstom HS2 V360 (16-car 400m coupled set)',
        carCount: 16,
        totalMassTonnes: 880,
        lengthM: 400,
        maxTractionPowerKw: 19200,
        maxSpeedKmh: 360,
        currentChainageKm: 68.400,
        currentSpeedKmh: 324,
        targetSpeedKmh: 330,
        accelerationMs2: 0.08,
        pantographState: 'RAISED',
        catenaryVoltageKv: 26.5,
        tractionCurrentAmps: 480,
        instantPowerKw: 12720,
        regenerativeEnergyKwh: 3200,
        doorState: 'LOCKED',
        etcsMode: 'FULL_SUPERVISION',
        movementAuthorityDistanceM: 12500,
        nextStoppingStation: 'Old Oak Common (CH 7+450)',
        delayMinutes: 0,
        status: 'ON_TIME'
      }
    ]);

    // 8. Substations
    this.substations.set([
      {
        nodeId: 'PWR-ATFS-WEMB',
        name: 'Wembley Main Feeder Substation (MPFS 400/25kV)',
        type: 'MPFS',
        chainageKm: 5.200,
        ratedMva: 160,
        currentLoadMva: 58.4,
        busVoltageKv: 27.6,
        powerFactor: 0.98,
        thermalMarginPercent: 63.5,
        feederSections: ['S1-London-Feeder', 'S2-Northolt-Feeder'],
        operationalStatus: 'NORMAL'
      },
      {
        nodeId: 'PWR-ATFS-AMER',
        name: 'Amersham Auto-Transformer Feeder Substation (ATFS 400/25kV)',
        type: 'ATFS',
        chainageKm: 38.500,
        ratedMva: 120,
        currentLoadMva: 42.8,
        busVoltageKv: 27.4,
        powerFactor: 0.99,
        thermalMarginPercent: 64.3,
        feederSections: ['C1-Colne-Chiltern-North', 'C1-Chiltern-South'],
        operationalStatus: 'NORMAL'
      }
    ]);

    // 9. Signalling RBC Interlockings
    this.interlockings.set([
      {
        areaId: 'RBC-LON-01',
        name: 'London Area Radio Block Centre (Euston to Northolt)',
        chainageStartKm: 0,
        chainageEndKm: 22.5,
        radioBlockCentreId: 'RBC-EUS-SYS01',
        trackCircuits: [
          { id: 'TC-01', chainageKm: 2.5, lengthM: 1500, occupied: false },
          { id: 'TC-02', chainageKm: 7.4, lengthM: 2000, occupied: true, assignedTrainId: 'HS2-TRAIN-001' }
        ],
        routeLocked: true,
        activeMovementAuthorities: 8,
        systemHealth: 'HEALTHY'
      },
      {
        areaId: 'RBC-CHIL-02',
        name: 'Chiltern & Colne Valley Radio Block Centre',
        chainageStartKm: 22.5,
        chainageEndKm: 55.0,
        radioBlockCentreId: 'RBC-CHIL-SYS02',
        trackCircuits: [
          { id: 'TC-04', chainageKm: 27.2, lengthM: 3000, occupied: true, assignedTrainId: 'HS2-TRAIN-001' },
          { id: 'TC-05', chainageKm: 36.0, lengthM: 4000, occupied: false }
        ],
        routeLocked: true,
        activeMovementAuthorities: 12,
        systemHealth: 'HEALTHY'
      }
    ]);
  }

  private initTelemetrySimulation() {
    setInterval(() => {
      this.liveTrains.update(trains =>
        trains.map(train => {
          let speedKmh = train.currentSpeedKmh;
          const scenario = this.activeScenario();
          
          if (scenario && train.currentChainageKm >= 24 && train.currentChainageKm <= 29) {
            speedKmh = Math.min(speedKmh, scenario.speedRestrictionKmh);
          } else {
            if (speedKmh < train.targetSpeedKmh) {
              speedKmh = Math.min(train.targetSpeedKmh, speedKmh + train.accelerationMs2 * 3.6);
            }
          }

          const deltaKm = speedKmh / 3600;
          let nextKm = train.currentChainageKm;
          
          if (train.headcode === '1A02') {
            nextKm = train.currentChainageKm + deltaKm;
            if (nextKm > 138) nextKm = 2;
          } else {
            nextKm = train.currentChainageKm - deltaKm;
            if (nextKm < 4) nextKm = 135;
          }

          const physicsResult = this.physics.calculateTrainResistance(speedKmh, train.totalMassTonnes, nextKm >= 29 && nextKm <= 45);
          const pwrDrop = this.physics.calculatePowerDrop(Math.abs(nextKm - 38.5), train.tractionCurrentAmps);

          return {
            ...train,
            currentChainageKm: Math.round(nextKm * 1000) / 1000,
            currentSpeedKmh: Math.round(speedKmh * 10) / 10,
            instantPowerKw: Math.round(physicsResult.powerRequiredKw),
            catenaryVoltageKv: Math.round(pwrDrop.catenaryVoltageKv * 10) / 10
          };
        })
      );

      this.assets.update(list =>
        list.map(a => {
          if (!a.sensors || a.sensors.length === 0) return a;
          const updatedSensors = a.sensors.map(s => {
            const noise = (Math.random() - 0.5) * 0.02 * s.currentValue;
            const newVal = Math.round((s.currentValue + noise) * 100) / 100;
            return {
              ...s,
              currentValue: newVal,
              lastObserved: new Date().toISOString()
            };
          });
          return { ...a, sensors: updatedSensors };
        })
      );
    }, 1500);
  }
}
