import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinDataService } from '../../core/services/digital-twin-data.service';

@Component({
  selector: 'app-scenario-simulator',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-4 p-4 bg-slate-950 text-slate-200 overflow-y-auto custom-scrollbar">
      <!-- Header -->
      <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-amber-400">science</mat-icon>
            What-If Scenario Engine & Downstream Impact Propagation
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">
            Clone current digital twin state to simulate climate hazards, component failures, and operational restrictions without mutating baseline data.
          </p>
        </div>

        @if (dataService.activeScenario()) {
          <button 
            (click)="dataService.triggerScenario('RESET')"
            class="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-lg transition flex items-center gap-1.5 shadow">
            <mat-icon class="text-xs">restore</mat-icon> Reset to Baseline Twin
          </button>
        }
      </div>

      <!-- Active Scenario Warning Banner -->
      @if (dataService.activeScenario(); as scn) {
        <div class="bg-amber-950/60 border border-amber-600/80 p-4 rounded-xl space-y-2 text-xs">
          <div class="flex items-center gap-2 text-amber-400 font-bold">
            <mat-icon class="text-amber-400 text-base">warning</mat-icon>
            ACTIVE SIMULATION: {{ scn.name }}
          </div>
          <p class="text-slate-300">{{ scn.description }}</p>
          <div class="p-2.5 bg-slate-950/80 rounded border border-amber-900/50 font-mono text-amber-200">
            <strong>IMPACT PROPAGATION:</strong> {{ scn.impactSummary }}
          </div>
        </div>
      }

      <!-- Preset Engineering Scenarios -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <!-- Scenario 1: Flood & Culvert Anomaly -->
        <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-3 flex flex-col justify-between">
          <div class="space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-mono font-bold text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                SCENARIO 1 (ENVIRONMENT)
              </span>
            </div>
            <h3 class="text-sm font-bold text-white">75mm/hr Torrential Storm at Colne Valley</h3>
            <p class="text-xs text-slate-400 leading-relaxed">
              Simulates a 1-in-100 year convective storm surcharge on Culvert DRN-CULV-042 and embankment piezometer pore pressure spike.
            </p>
            <div class="text-[11px] text-slate-300 bg-slate-950 p-2 rounded border border-slate-800 space-y-1">
              <div>• Culvert Capacity: 94% surcharge</div>
              <div>• Track Restriction: 80 km/h (was 320 km/h)</div>
              <div>• ETCS MA Truncation: 4 Trains delayed</div>
            </div>
          </div>

          <button 
            (click)="dataService.triggerScenario('FLOOD_COLNE_VALLEY')"
            class="w-full py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs rounded-lg transition flex items-center justify-center gap-1.5 shadow">
            <mat-icon class="text-xs">play_arrow</mat-icon> Inject Flood Scenario
          </button>
        </div>

        <!-- Scenario 2: Substation Outage -->
        <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-3 flex flex-col justify-between">
          <div class="space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-mono font-bold text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
                SCENARIO 2 (TRACTION POWER)
              </span>
            </div>
            <h3 class="text-sm font-bold text-white">Amersham 400/25kV Substation Trip</h3>
            <p class="text-xs text-slate-400 leading-relaxed">
              Simulates National Grid transformer trip. Evaluates automatic bus-coupler switching to adjacent Wembley and Calvert substations.
            </p>
            <div class="text-[11px] text-slate-300 bg-slate-950 p-2 rounded border border-slate-800 space-y-1">
              <div>• Secondary Feed Transfer: 85ms switch</div>
              <div>• Thermal Margin: 89% load on Calvert</div>
              <div>• Zero traction disruption</div>
            </div>
          </div>

          <button 
            disabled
            class="w-full py-2 bg-slate-800 text-slate-500 font-bold text-xs rounded-lg cursor-not-allowed flex items-center justify-center gap-1.5">
            <mat-icon class="text-xs">lock</mat-icon> Pre-Configured Pass
          </button>
        </div>

        <!-- Scenario 3: Digital Rehearsal Weekend Possession -->
        <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-3 flex flex-col justify-between">
          <div class="space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-mono font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                SCENARIO 3 (4D REHEARSAL)
              </span>
            </div>
            <h3 class="text-sm font-bold text-white">54-Hour Weekend Commissioning Possession</h3>
            <p class="text-xs text-slate-400 leading-relaxed">
              Digital rehearsal of ETCS Radio Block Centre migration and interlocking validation with 12 engineering work trains.
            </p>
            <div class="text-[11px] text-slate-300 bg-slate-950 p-2 rounded border border-slate-800 space-y-1">
              <div>• 28 Work steps sequenced</div>
              <div>• Critical Path Buffer: 4.5 hours</div>
              <div>• Zero clash detection errors</div>
            </div>
          </div>

          <button 
            disabled
            class="w-full py-2 bg-slate-800 text-slate-500 font-bold text-xs rounded-lg cursor-not-allowed flex items-center justify-center gap-1.5">
            <mat-icon class="text-xs">check_circle</mat-icon> Rehearsal Complete
          </button>
        </div>
      </div>

      <!-- Graph Dependency Chain Visualization -->
      <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-3">
        <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
          <mat-icon class="text-xs text-cyan-400">account_tree</mat-icon>
          Explainable Downstream Impact Propagation Graph
        </h3>

        <div class="flex flex-wrap items-center justify-between gap-2 p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs font-mono">
          <div class="p-2 bg-blue-950/80 rounded border border-blue-800 text-center">
            <span class="text-[10px] text-slate-400 block">HAZARD INGESTION</span>
            <strong class="text-blue-300">75mm Rainfall</strong>
          </div>
          <mat-icon class="text-slate-600 text-sm">arrow_forward</mat-icon>
          <div class="p-2 bg-cyan-950/80 rounded border border-cyan-800 text-center">
            <span class="text-[10px] text-slate-400 block">ASSET IMPACT</span>
            <strong class="text-cyan-300">Culvert 042 + Piezometer</strong>
          </div>
          <mat-icon class="text-slate-600 text-sm">arrow_forward</mat-icon>
          <div class="p-2 bg-amber-950/80 rounded border border-amber-800 text-center">
            <span class="text-[10px] text-slate-400 block">SAFETY RULE</span>
            <strong class="text-amber-300">TSR 80 km/h</strong>
          </div>
          <mat-icon class="text-slate-600 text-sm">arrow_forward</mat-icon>
          <div class="p-2 bg-purple-950/80 rounded border border-purple-800 text-center">
            <span class="text-[10px] text-slate-400 block">ETCS LEVEL 2</span>
            <strong class="text-purple-300">MA Truncated</strong>
          </div>
          <mat-icon class="text-slate-600 text-sm">arrow_forward</mat-icon>
          <div class="p-2 bg-emerald-950/80 rounded border border-emerald-800 text-center">
            <span class="text-[10px] text-slate-400 block">DECISION</span>
            <strong class="text-emerald-300">Work Order Dispatched</strong>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ScenarioSimulatorComponent {
  public readonly dataService = inject(DigitalTwinDataService);
}
