import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  effect,
  inject,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { DigitalTwinDataService } from '../../core/services/digital-twin-data.service';

@Component({
  selector: 'app-twin-3d',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full min-h-[560px] bg-slate-950 overflow-hidden flex flex-col rounded-xl border border-slate-800 shadow-2xl">
      <!-- 3D Canvas Container -->
      <div #canvasContainer class="w-full h-full flex-1 relative cursor-grab active:cursor-grabbing">
        <!-- Top Overlay Controls -->
        <div class="absolute top-3 left-3 z-10 flex flex-wrap gap-2 items-center bg-slate-900/85 backdrop-blur-md px-3 py-2 rounded-lg border border-slate-700/60 shadow-lg text-xs">
          <span class="flex items-center gap-1.5 text-cyan-400 font-semibold uppercase tracking-wider">
            <mat-icon class="text-sm">view_in_ar</mat-icon>
            3D High-Speed Twin Viewport
          </span>
          <span class="h-3 w-px bg-slate-700 mx-1"></span>
          
          <!-- Camera Mode Selector -->
          <div class="flex items-center gap-1 bg-slate-950/70 p-1 rounded-md border border-slate-800">
            <button 
              (click)="setCameraMode('ORBIT')"
              [class.bg-cyan-600]="cameraMode() === 'ORBIT'"
              [class.text-white]="cameraMode() === 'ORBIT'"
              [class.text-slate-400]="cameraMode() !== 'ORBIT'"
              class="px-2 py-1 rounded transition-colors flex items-center gap-1 font-medium hover:text-slate-200">
              <mat-icon class="text-xs">travel_explore</mat-icon> Drone Orbit
            </button>
            <button 
              (click)="setCameraMode('CAB_VIEW')"
              [class.bg-cyan-600]="cameraMode() === 'CAB_VIEW'"
              [class.text-white]="cameraMode() === 'CAB_VIEW'"
              [class.text-slate-400]="cameraMode() !== 'CAB_VIEW'"
              class="px-2 py-1 rounded transition-colors flex items-center gap-1 font-medium hover:text-slate-200">
              <mat-icon class="text-xs">train</mat-icon> Cab 320km/h
            </button>
            <button 
              (click)="setCameraMode('TOP_DOWN')"
              [class.bg-cyan-600]="cameraMode() === 'TOP_DOWN'"
              [class.text-white]="cameraMode() === 'TOP_DOWN'"
              [class.text-slate-400]="cameraMode() !== 'TOP_DOWN'"
              class="px-2 py-1 rounded transition-colors flex items-center gap-1 font-medium hover:text-slate-200">
              <mat-icon class="text-xs">layers</mat-icon> Ortho Top
            </button>
          </div>

          <!-- Reset Camera -->
          <button 
            (click)="resetCamera()"
            title="Focus on Selected Asset"
            class="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded flex items-center gap-1 transition">
            <mat-icon class="text-xs">center_focus_strong</mat-icon> Focus Asset
          </button>
        </div>

        <!-- Layer Toggles HUD (Top Right) -->
        <div class="absolute top-3 right-3 z-10 flex flex-col gap-1 bg-slate-900/85 backdrop-blur-md p-2.5 rounded-lg border border-slate-700/60 shadow-lg text-[11px]">
          <span class="text-slate-400 uppercase font-mono tracking-wider mb-1 font-semibold flex items-center gap-1">
            <mat-icon class="text-xs text-amber-400">tune</mat-icon> BIM / GIS Layers
          </span>
          <div class="grid grid-cols-2 gap-x-2 gap-y-1">
            <label class="flex items-center gap-1.5 text-slate-300 hover:text-white cursor-pointer">
              <input type="checkbox" [checked]="layers.civil" (change)="toggleLayer('civil')" class="rounded bg-slate-800 text-cyan-500 text-xs">
              <span>Civils / Bridges</span>
            </label>
            <label class="flex items-center gap-1.5 text-slate-300 hover:text-white cursor-pointer">
              <input type="checkbox" [checked]="layers.track" (change)="toggleLayer('track')" class="rounded bg-slate-800 text-cyan-500 text-xs">
              <span>Track Slab</span>
            </label>
            <label class="flex items-center gap-1.5 text-slate-300 hover:text-white cursor-pointer">
              <input type="checkbox" [checked]="layers.ole" (change)="toggleLayer('ole')" class="rounded bg-slate-800 text-cyan-500 text-xs">
              <span>OLE Catenary</span>
            </label>
            <label class="flex items-center gap-1.5 text-slate-300 hover:text-white cursor-pointer">
              <input type="checkbox" [checked]="layers.sensors" (change)="toggleLayer('sensors')" class="rounded bg-slate-800 text-cyan-500 text-xs">
              <span>SHM Sensors</span>
            </label>
            <label class="flex items-center gap-1.5 text-slate-300 hover:text-white cursor-pointer">
              <input type="checkbox" [checked]="layers.trains" (change)="toggleLayer('trains')" class="rounded bg-slate-800 text-cyan-500 text-xs">
              <span>Live Trains</span>
            </label>
            <label class="flex items-center gap-1.5 text-slate-300 hover:text-white cursor-pointer">
              <input type="checkbox" [checked]="layers.terrain" (change)="toggleLayer('terrain')" class="rounded bg-slate-800 text-cyan-500 text-xs">
              <span>GIS Terrain</span>
            </label>
          </div>
        </div>

        <!-- Telemetry HUD Bottom Left -->
        <div class="absolute bottom-3 left-3 z-10 flex flex-col gap-1 bg-slate-900/85 backdrop-blur-md p-3 rounded-lg border border-slate-700/60 shadow-lg text-xs font-mono text-slate-300">
          <div class="flex items-center gap-2">
            <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span class="text-cyan-400 font-bold">LOD 400 FEDERATED TWIN</span>
          </div>
          <div class="text-[11px] text-slate-400">
            Current Chainage: <strong class="text-white">{{ dataService.physics.formatChainage(dataService.activeChainage()) }}</strong>
          </div>
          <div class="text-[11px] text-slate-400">
            Active Train 1A02 Speed: <strong class="text-emerald-400">{{ dataService.liveTrains()[0]?.currentSpeedKmh || 320 }} km/h</strong>
          </div>
          <div class="text-[11px] text-slate-400">
            Selected: <span class="text-amber-300">{{ dataService.selectedAsset?.name || 'Colne Valley Viaduct' }}</span>
          </div>
        </div>

        <!-- Watermark / Safety Disclaimer -->
        <div class="absolute bottom-3 right-3 z-10 text-right pointer-events-none">
          <span class="text-[10px] font-mono uppercase bg-slate-900/80 px-2 py-1 rounded text-slate-400 border border-slate-800">
            SYNTHETIC DEMONSTRATION DATA — NOT OFFICIAL HS2 DATA
          </span>
        </div>
      </div>
    </div>
  `
})
export class Twin3DComponent implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainer!: ElementRef<HTMLDivElement>;

  public readonly dataService = inject(DigitalTwinDataService);
  public readonly cameraMode = signal<'ORBIT' | 'CAB_VIEW' | 'TOP_DOWN'>('ORBIT');

  public layers = {
    civil: true,
    track: true,
    ole: true,
    sensors: true,
    trains: true,
    terrain: true
  };

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId: number | null = null;
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  private groupTerrain = new THREE.Group();
  private groupCivils = new THREE.Group();
  private groupTrack = new THREE.Group();
  private groupOLE = new THREE.Group();
  private groupSensors = new THREE.Group();
  private groupTrains = new THREE.Group();

  private assetMeshMap = new Map<THREE.Object3D, string>();
  private trainMeshes: (THREE.Group & { trainId?: string })[] = [];

  private isMouseDown = false;
  private prevMousePos = { x: 0, y: 0 };
  private spherical = { radius: 120, theta: 0.8, phi: 1.1 };
  private targetLookAt = new THREE.Vector3(0, 15, 0);

  constructor() {
    effect(() => {
      const asset = this.dataService.selectedAsset;
      if (asset && this.cameraMode() === 'ORBIT') {
        const kmOffset = (asset.location.chainageKm - 26.85) * 60;
        this.targetLookAt.set(kmOffset, asset.location.elevationM * 0.4, 0);
      }
    });
  }

  ngOnInit() {
    this.initThree();
    this.build3DWorld();
    this.setupEventListeners();
    this.animate();
  }

  ngOnDestroy() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  public setCameraMode(mode: 'ORBIT' | 'CAB_VIEW' | 'TOP_DOWN') {
    this.cameraMode.set(mode);
    if (mode === 'TOP_DOWN') {
      this.spherical.theta = 0;
      this.spherical.phi = 0.05;
      this.spherical.radius = 250;
    } else if (mode === 'ORBIT') {
      this.spherical.radius = 120;
      this.spherical.phi = 1.1;
      this.spherical.theta = 0.8;
    }
  }

  public resetCamera() {
    this.setCameraMode('ORBIT');
    const asset = this.dataService.selectedAsset;
    if (asset) {
      const kmOffset = (asset.location.chainageKm - 26.85) * 60;
      this.targetLookAt.set(kmOffset, asset.location.elevationM * 0.4, 0);
    }
  }

  public toggleLayer(layer: keyof typeof this.layers) {
    this.layers[layer] = !this.layers[layer];
    if (layer === 'civil') this.groupCivils.visible = this.layers.civil;
    if (layer === 'track') this.groupTrack.visible = this.layers.track;
    if (layer === 'ole') this.groupOLE.visible = this.layers.ole;
    if (layer === 'sensors') this.groupSensors.visible = this.layers.sensors;
    if (layer === 'trains') this.groupTrains.visible = this.layers.trains;
    if (layer === 'terrain') this.groupTerrain.visible = this.layers.terrain;
  }

  private initThree() {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 560;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x060911);
    this.scene.fog = new THREE.FogExp2(0x060911, 0.0018);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.5, 3000);
    this.camera.position.set(60, 50, 90);
    this.camera.lookAt(this.targetLookAt);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xe0f2fe, 1.6);
    dirLight.position.set(150, 200, 100);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    this.scene.add(dirLight);

    const blueRimLight = new THREE.DirectionalLight(0x0284c7, 0.7);
    blueRimLight.position.set(-150, 80, -100);
    this.scene.add(blueRimLight);

    this.scene.add(this.groupTerrain);
    this.scene.add(this.groupCivils);
    this.scene.add(this.groupTrack);
    this.scene.add(this.groupOLE);
    this.scene.add(this.groupSensors);
    this.scene.add(this.groupTrains);
  }

  private build3DWorld() {
    const terrainGeo = new THREE.PlaneGeometry(1600, 400, 64, 32);
    terrainGeo.rotateX(-Math.PI / 2);
    
    const pos = terrainGeo.attributes['position'];
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      let y = Math.sin(x * 0.008) * 12 + Math.cos(z * 0.015) * 8;
      if (Math.abs(x) < 90) {
        y = -6 + Math.sin(z * 0.02) * 1.5;
      }
      pos.setY(i, y);
    }
    terrainGeo.computeVertexNormals();

    const terrainMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.9,
      metalness: 0.1,
      wireframe: false
    });
    const terrain = new THREE.Mesh(terrainGeo, terrainMat);
    terrain.receiveShadow = true;
    terrain.position.y = -2;
    this.groupTerrain.add(terrain);

    const waterGeo = new THREE.PlaneGeometry(240, 300);
    waterGeo.rotateX(-Math.PI / 2);
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x0369a1,
      transparent: true,
      opacity: 0.65,
      roughness: 0.1,
      metalness: 0.8
    });
    const water = new THREE.Mesh(waterGeo, waterMat);
    water.position.set(0, -4, 0);
    this.groupTerrain.add(water);

    const spanWidth = 28;
    const pierCount = 14;
    const deckMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.4, metalness: 0.2 });
    const pierMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.5, metalness: 0.1 });

    for (let i = -pierCount / 2; i <= pierCount / 2; i++) {
      const px = i * spanWidth;
      
      const pierGroup = new THREE.Group();
      const pierLegGeo = new THREE.CylinderGeometry(1.2, 1.8, 18, 12);
      
      const leg1 = new THREE.Mesh(pierLegGeo, pierMat);
      leg1.position.set(-2.5, 6, 0);
      leg1.rotation.z = 0.12;
      leg1.castShadow = true;
      pierGroup.add(leg1);

      const leg2 = new THREE.Mesh(pierLegGeo, pierMat);
      leg2.position.set(2.5, 6, 0);
      leg2.rotation.z = -0.12;
      leg2.castShadow = true;
      pierGroup.add(leg2);

      const capGeo = new THREE.BoxGeometry(11, 2, 5);
      const cap = new THREE.Mesh(capGeo, deckMat);
      cap.position.set(0, 15, 0);
      pierGroup.add(cap);

      pierGroup.position.set(px, -4, 0);
      this.groupCivils.add(pierGroup);

      if (i < pierCount / 2) {
        const spanGeo = new THREE.BoxGeometry(spanWidth, 2.8, 6.5);
        const deckSpan = new THREE.Mesh(spanGeo, deckMat);
        deckSpan.position.set(px + spanWidth / 2, 12.5, 0);
        deckSpan.castShadow = true;
        deckSpan.receiveShadow = true;
        
        if (i === 0) {
          this.assetMeshMap.set(deckSpan, 'CVV-SPAN-28');
        }
        this.groupCivils.add(deckSpan);
      }
    }

    const portalMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.6 });
    const portalGeo = new THREE.BoxGeometry(16, 22, 28);
    const tunnelPortal = new THREE.Mesh(portalGeo, portalMat);
    tunnelPortal.position.set(240, 8, 0);
    this.assetMeshMap.set(tunnelPortal, 'TUN-CHIL-SOUTH');
    this.groupCivils.add(tunnelPortal);

    const tubeGeo = new THREE.CylinderGeometry(4.5, 4.5, 300, 24, 1, true);
    tubeGeo.rotateZ(Math.PI / 2);
    const tubeMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, side: THREE.DoubleSide });
    const northTube = new THREE.Mesh(tubeGeo, tubeMat);
    northTube.position.set(390, 8, -2.5);
    const southTube = new THREE.Mesh(tubeGeo, tubeMat);
    southTube.position.set(390, 8, 2.5);
    this.groupCivils.add(northTube, southTube);

    const trackLength = 1200;
    const slabGeo = new THREE.BoxGeometry(trackLength, 0.4, 5.8);
    const slabMat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.8 });
    const trackSlab = new THREE.Mesh(slabGeo, slabMat);
    trackSlab.position.set(0, 14.1, 0);
    this.groupTrack.add(trackSlab);

    const railMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9, roughness: 0.2 });
    const railOffsets = [-2.2, -0.8, 0.8, 2.2];
    for (const zOffset of railOffsets) {
      const railGeo = new THREE.BoxGeometry(trackLength, 0.22, 0.12);
      const rail = new THREE.Mesh(railGeo, railMat);
      rail.position.set(0, 14.4, zOffset);
      this.groupTrack.add(rail);
    }

    const mastGeo = new THREE.CylinderGeometry(0.18, 0.22, 7.2, 8);
    const mastMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.7, roughness: 0.3 });
    const armGeo = new THREE.BoxGeometry(0.12, 0.12, 6.4);
    const wireMat = new THREE.LineBasicMaterial({ color: 0xfef08a });

    for (let x = -500; x <= 500; x += 35) {
      const mastGroup = new THREE.Group();
      
      const mastPost = new THREE.Mesh(mastGeo, mastMat);
      mastPost.position.set(0, 3.6, -3.4);
      mastGroup.add(mastPost);

      const cantileverArm = new THREE.Mesh(armGeo, mastMat);
      cantileverArm.position.set(0, 6.8, -0.3);
      mastGroup.add(cantileverArm);

      mastGroup.position.set(x, 14.2, 0);
      this.groupOLE.add(mastGroup);
    }

    const wirePoints: THREE.Vector3[] = [];
    for (let x = -500; x <= 500; x += 10) {
      wirePoints.push(new THREE.Vector3(x, 19.8, -1.5));
    }
    const catenaryLine = new THREE.Line(
      new THREE.BufferGeometry().setFromPoints(wirePoints),
      wireMat
    );
    this.groupOLE.add(catenaryLine);

    this.dataService.assets().forEach(asset => {
      if (asset.sensors && asset.sensors.length > 0) {
        const sensorGeo = new THREE.SphereGeometry(0.8, 16, 16);
        const sensorColor = asset.validationStatus === 'WARNING' ? 0xf59e0b : 0x10b981;
        const sensorMat = new THREE.MeshStandardMaterial({
          color: sensorColor,
          emissive: sensorColor,
          emissiveIntensity: 0.6,
          roughness: 0.2
        });
        const sensorMesh = new THREE.Mesh(sensorGeo, sensorMat);
        const kmOffset = (asset.location.chainageKm - 26.85) * 60;
        sensorMesh.position.set(kmOffset, 15.5, 3.2);
        this.assetMeshMap.set(sensorMesh, asset.assetId);
        this.groupSensors.add(sensorMesh);
      }
    });

    this.createTrainModel('HS2-TRAIN-001', -1.5, 0x0284c7);
    this.createTrainModel('HS2-TRAIN-002', 1.5, 0x059669);
  }

  private createTrainModel(trainId: string, zTrackOffset: number, primaryColorHex: number) {
    const trainGroup: THREE.Group & { trainId?: string } = new THREE.Group();
    
    const noseGeo = new THREE.ConeGeometry(1.6, 6, 16);
    noseGeo.rotateZ(-Math.PI / 2);
    const bodyMat = new THREE.MeshStandardMaterial({
      color: primaryColorHex,
      metalness: 0.6,
      roughness: 0.3
    });
    const nose = new THREE.Mesh(noseGeo, bodyMat);
    nose.position.set(22, 2.2, 0);
    trainGroup.add(nose);

    for (let c = 0; c < 4; c++) {
      const carGeo = new THREE.BoxGeometry(14, 2.6, 2.8);
      const car = new THREE.Mesh(carGeo, bodyMat);
      car.position.set(12 - c * 15, 2.2, 0);
      car.castShadow = true;
      trainGroup.add(car);

      const winGeo = new THREE.BoxGeometry(13.6, 0.6, 2.85);
      const winMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.1 });
      const win = new THREE.Mesh(winGeo, winMat);
      win.position.set(12 - c * 15, 2.4, 0);
      trainGroup.add(win);
    }

    const pantoMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.8 });
    const pantoArm = new THREE.BoxGeometry(0.1, 1.8, 0.1);
    const panto1 = new THREE.Mesh(pantoArm, pantoMat);
    panto1.position.set(4, 4.3, 0);
    panto1.rotation.z = 0.4;
    trainGroup.add(panto1);

    trainGroup.position.set(0, 14.5, zTrackOffset);
    trainGroup.trainId = trainId;
    this.trainMeshes.push(trainGroup);
    this.groupTrains.add(trainGroup);
  }

  private setupEventListeners() {
    const container = this.canvasContainer.nativeElement;

    container.addEventListener('pointerdown', (e) => {
      this.isMouseDown = true;
      this.prevMousePos = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('pointerup', (e) => {
      if (this.isMouseDown) {
        const dx = Math.abs(e.clientX - this.prevMousePos.x);
        const dy = Math.abs(e.clientY - this.prevMousePos.y);
        if (dx < 4 && dy < 4) {
          this.handleRaycast(e);
        }
      }
      this.isMouseDown = false;
    });

    container.addEventListener('pointermove', (e) => {
      if (!this.isMouseDown || this.cameraMode() === 'CAB_VIEW') return;
      const dx = e.clientX - this.prevMousePos.x;
      const dy = e.clientY - this.prevMousePos.y;
      this.prevMousePos = { x: e.clientX, y: e.clientY };

      this.spherical.theta -= dx * 0.006;
      this.spherical.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, this.spherical.phi - dy * 0.006));
    });

    container.addEventListener('wheel', (e) => {
      e.preventDefault();
      if (this.cameraMode() === 'CAB_VIEW') return;
      this.spherical.radius = Math.max(15, Math.min(450, this.spherical.radius + e.deltaY * 0.15));
    }, { passive: false });

    window.addEventListener('resize', () => this.onWindowResize());
  }

  private handleRaycast(event: MouseEvent) {
    const rect = this.canvasContainer.nativeElement.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects([
      ...this.groupCivils.children,
      ...this.groupSensors.children,
      ...this.groupTrack.children
    ], true);

    if (intersects.length > 0) {
      let hitObj: THREE.Object3D | null = intersects[0].object;
      while (hitObj && !this.assetMeshMap.has(hitObj)) {
        hitObj = hitObj.parent;
      }
      if (hitObj && this.assetMeshMap.has(hitObj)) {
        const assetId = this.assetMeshMap.get(hitObj)!;
        this.dataService.selectAsset(assetId);
      }
    }
  }

  private animate = () => {
    this.animationFrameId = requestAnimationFrame(this.animate);

    const trains = this.dataService.liveTrains();
    if (trains.length > 0 && this.trainMeshes.length > 0) {
      const train1 = trains[0];
      const mesh1 = this.trainMeshes[0];
      if (mesh1 && train1) {
        const xPos = (train1.currentChainageKm - 26.85) * 60;
        mesh1.position.x = xPos;

        if (this.cameraMode() === 'CAB_VIEW') {
          this.camera.position.set(xPos + 22, 17.2, -1.5);
          this.camera.lookAt(xPos + 180, 16.5, -1.5);
        }
      }

      const train2 = trains[1];
      const mesh2 = this.trainMeshes[1];
      if (mesh2 && train2) {
        const xPos2 = (train2.currentChainageKm - 26.85) * 60;
        mesh2.position.x = xPos2;
      }
    }

    if (this.cameraMode() !== 'CAB_VIEW') {
      const sinPhiRadius = this.spherical.radius * Math.sin(this.spherical.phi);
      this.camera.position.x = this.targetLookAt.x + sinPhiRadius * Math.sin(this.spherical.theta);
      this.camera.position.y = this.targetLookAt.y + this.spherical.radius * Math.cos(this.spherical.phi);
      this.camera.position.z = this.targetLookAt.z + sinPhiRadius * Math.cos(this.spherical.theta);
      this.camera.lookAt(this.targetLookAt);
    }

    const time = Date.now() * 0.004;
    this.groupSensors.children.forEach((mesh, idx) => {
      const scale = 1.0 + Math.sin(time + idx) * 0.2;
      mesh.scale.set(scale, scale, scale);
    });

    this.renderer.render(this.scene, this.camera);
  };

  private onWindowResize() {
    if (!this.canvasContainer) return;
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth;
    const height = container.clientHeight;
    if (width && height && this.camera && this.renderer) {
      this.camera.aspect = width / height;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(width, height);
    }
  }
}
