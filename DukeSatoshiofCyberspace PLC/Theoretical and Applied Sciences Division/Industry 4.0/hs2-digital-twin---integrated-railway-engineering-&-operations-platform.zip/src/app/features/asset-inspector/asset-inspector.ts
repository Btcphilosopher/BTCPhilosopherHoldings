import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinDataService } from '../../core/services/digital-twin-data.service';

@Component({
  selector: 'app-asset-inspector',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <aside class="w-full h-full flex flex-col bg-slate-900 border-l border-slate-800 text-slate-200 overflow-hidden shadow-2xl">
      @if (dataService.selectedAsset; as asset) {
        <!-- Header -->
        <div class="p-4 bg-slate-950 border-b border-slate-800 flex flex-col gap-2 shrink-0">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <span [class]="getClassBadgeColor(asset.assetClass)" class="px-2 py-0.5 rounded text-[11px] font-mono font-bold uppercase tracking-wide">
                {{ asset.assetClass }}
              </span>
              <span class="text-xs font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/50">
                {{ asset.assetId }}
              </span>
            </div>
            
            <div class="flex items-center gap-1.5">
              <span [class]="getValidationBadgeClass(asset.validationStatus)" class="px-2 py-0.5 rounded-full text-[10px] font-semibold flex items-center gap-1">
                <mat-icon class="text-xs">{{ asset.validationStatus === 'VALIDATED' ? 'verified' : 'warning' }}</mat-icon>
                {{ asset.validationStatus }}
              </span>
              <span class="text-[10px] font-mono text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
                {{ asset.confidence }}% CONF
              </span>
            </div>
          </div>

          <h2 class="text-base font-bold text-white leading-snug">
            {{ asset.name }}
          </h2>

          <div class="flex flex-wrap gap-2 text-xs text-slate-400">
            <span class="flex items-center gap-1 font-mono text-cyan-300">
              <mat-icon class="text-xs">straighten</mat-icon> {{ asset.location.chainageFormatted }}
            </span>
            <span class="flex items-center gap-1">
              <mat-icon class="text-xs">category</mat-icon> {{ asset.discipline }}
            </span>
            <span class="flex items-center gap-1 font-mono text-slate-300">
              <mat-icon class="text-xs">public</mat-icon> BNG {{ asset.location.bngEasting }}E, {{ asset.location.bngNorthing }}N
            </span>
          </div>

          <!-- Lifecycle State Pill Bar -->
          <div class="mt-1 flex items-center justify-between bg-slate-900 px-2 py-1.5 rounded border border-slate-800 text-[11px]">
            <span class="text-slate-400">Lifecycle State:</span>
            <span class="font-semibold text-emerald-400 flex items-center gap-1">
              <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
              {{ asset.lifecycleState }}
            </span>
            <span class="text-slate-500">|</span>
            <span class="text-slate-400">ISO 19650:</span>
            <span class="font-mono text-amber-300">{{ asset.informationStatus }}</span>
          </div>
        </div>

        <!-- Tab Navigation -->
        <div class="flex border-b border-slate-800 bg-slate-950/60 overflow-x-auto custom-scrollbar shrink-0 text-xs font-medium">
          @for (tab of tabs; track tab.id) {
            <button 
              (click)="activeTab.set(tab.id)"
              [class.text-cyan-400]="activeTab() === tab.id"
              [class.border-cyan-400]="activeTab() === tab.id"
              [class.text-slate-400]="activeTab() !== tab.id"
              class="px-3 py-2.5 border-b-2 border-transparent hover:text-slate-200 transition-colors whitespace-nowrap flex items-center gap-1.5">
              <mat-icon class="text-xs">{{ tab.icon }}</mat-icon>
              {{ tab.label }}
            </button>
          }
        </div>

        <!-- Scrollable Tab Content Container -->
        <div class="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">

          <!-- 1. OVERVIEW & ENGINEERING PARAMETERS TAB -->
          @if (activeTab() === 'PARAMS') {
            <div class="space-y-4">
              <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800">
                <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                  <mat-icon class="text-xs text-cyan-400">settings</mat-icon> Technical Engineering Specifications
                </h3>
                <div class="divide-y divide-slate-800/80 text-xs">
                  @for (entry of getParamEntries(asset.engineeringParams); track entry.key) {
                    <div class="py-1.5 flex justify-between gap-2">
                      <span class="text-slate-400 font-mono">{{ formatKey(entry.key) }}</span>
                      <span class="font-semibold text-white text-right max-w-[60%]">{{ entry.value }}</span>
                    </div>
                  }
                </div>
              </div>

              <!-- Location & Coordinates Card -->
              <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800">
                <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                  <mat-icon class="text-xs text-cyan-400">place</mat-icon> Geospatial & Linear Referencing
                </h3>
                <div class="grid grid-cols-2 gap-2 text-xs">
                  <div class="bg-slate-900 p-2 rounded border border-slate-800">
                    <span class="text-slate-500 block text-[10px]">ROUTE CHAINAGE</span>
                    <strong class="font-mono text-cyan-300">{{ asset.location.chainageFormatted }}</strong>
                  </div>
                  <div class="bg-slate-900 p-2 rounded border border-slate-800">
                    <span class="text-slate-500 block text-[10px]">ELEVATION</span>
                    <strong class="font-mono text-white">{{ asset.location.elevationM }} m AOD</strong>
                  </div>
                  <div class="bg-slate-900 p-2 rounded border border-slate-800">
                    <span class="text-slate-500 block text-[10px]">BRITISH NATIONAL GRID</span>
                    <strong class="font-mono text-slate-300">{{ asset.location.bngEasting }}E, {{ asset.location.bngNorthing }}N</strong>
                  </div>
                  <div class="bg-slate-900 p-2 rounded border border-slate-800">
                    <span class="text-slate-500 block text-[10px]">WGS84 LAT / LNG</span>
                    <strong class="font-mono text-slate-300">{{ asset.location.latitude | number:'1.4-4' }}, {{ asset.location.longitude | number:'1.4-4' }}</strong>
                  </div>
                </div>
              </div>
            </div>
          }

          <!-- 2. SENSORS & STRUCTURAL HEALTH TAB -->
          @if (activeTab() === 'SENSORS') {
            <div class="space-y-4">
              @if (asset.sensors && asset.sensors.length > 0) {
                @for (sensor of asset.sensors; track sensor.sensorId) {
                  <div class="bg-slate-950/80 p-3.5 rounded-lg border border-slate-800 space-y-2.5">
                    <div class="flex items-center justify-between">
                      <div>
                        <span class="text-[10px] font-mono text-cyan-400 bg-cyan-950/80 px-1.5 py-0.5 rounded border border-cyan-800">
                          {{ sensor.sensorId }}
                        </span>
                        <h4 class="text-xs font-bold text-white mt-1">{{ sensor.metric }}</h4>
                      </div>
                      <span [class]="sensor.health === 'GOOD' ? 'bg-emerald-950 text-emerald-400 border-emerald-800' : 'bg-amber-950 text-amber-400 border-amber-800'" class="px-2 py-0.5 rounded text-[10px] font-mono border">
                        {{ sensor.health }}
                      </span>
                    </div>

                    <div class="flex items-baseline justify-between bg-slate-900 p-2.5 rounded border border-slate-800">
                      <div>
                        <span class="text-2xl font-mono font-bold text-white">{{ sensor.currentValue }}</span>
                        <span class="text-xs text-slate-400 ml-1 font-mono">{{ sensor.unit }}</span>
                      </div>
                      <div class="text-right text-[11px] font-mono text-slate-400">
                        <div>Baseline: <span class="text-slate-300">{{ sensor.baselineValue }} {{ sensor.unit }}</span></div>
                        <div>Critical Limit: <span class="text-rose-400">{{ sensor.criticalThreshold }} {{ sensor.unit }}</span></div>
                      </div>
                    </div>

                    <div class="bg-slate-900/60 p-2.5 rounded text-xs space-y-1">
                      <div class="flex justify-between items-center text-[11px]">
                        <span class="text-slate-400 font-medium">Statistical CUSUM Score:</span>
                        <span class="font-mono font-bold text-cyan-300">{{ sensor.cusumAnomalyScore | number:'1.2-2' }} / 4.0</span>
                      </div>
                      <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div [style.width.%]="(sensor.cusumAnomalyScore / 4.0) * 100" class="h-full bg-cyan-500 rounded-full"></div>
                      </div>
                      <span class="text-[10px] text-slate-400 block pt-1">
                        Explainable trend: {{ sensor.trend }} (Rate: {{ sensor.rateOfChange }}/hr). Zero false alarms in 90 days.
                      </span>
                    </div>
                  </div>
                }
              } @else {
                <div class="text-center py-8 text-slate-500 text-xs">
                  <mat-icon class="text-3xl text-slate-600 mb-2">sensors_off</mat-icon>
                  <p>No active SHM sensors attached to this child component.</p>
                </div>
              }
            </div>
          }

          <!-- 3. PROVENANCE & CDE ISO 19650 TAB -->
          @if (activeTab() === 'PROVENANCE') {
            <div class="space-y-4">
              <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800 text-xs space-y-2">
                <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                  <mat-icon class="text-xs text-cyan-400">history_edu</mat-icon> Engineering Lineage & CDE
                </h3>
                <div class="grid grid-cols-2 gap-2">
                  <div class="bg-slate-900 p-2 rounded border border-slate-800">
                    <span class="text-slate-500 block text-[10px]">SOURCE SYSTEM</span>
                    <span class="font-semibold text-white">{{ asset.provenance.sourceSystem }}</span>
                  </div>
                  <div class="bg-slate-900 p-2 rounded border border-slate-800">
                    <span class="text-slate-500 block text-[10px]">REVISION</span>
                    <span class="font-mono font-bold text-amber-300">{{ asset.provenance.revision }}</span>
                  </div>
                </div>
                <div class="bg-slate-900 p-2 rounded border border-slate-800">
                  <span class="text-slate-500 block text-[10px]">SOURCE DOCUMENT / DRAWING</span>
                  <span class="font-mono text-cyan-300 text-[11px]">{{ asset.provenance.sourceDocument }}</span>
                </div>
                <div class="bg-slate-900 p-2 rounded border border-slate-800">
                  <span class="text-slate-500 block text-[10px]">AUTHOR / ORGANIZATION</span>
                  <span class="text-slate-200">{{ asset.provenance.author }} ({{ asset.provenance.organization }})</span>
                </div>
              </div>

              <!-- Cryptographic Audit Trail -->
              <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-2">
                <h4 class="text-[11px] font-semibold uppercase text-slate-400 tracking-wider">Immutable Verification Chain</h4>
                <div class="relative pl-4 space-y-3 before:absolute before:left-1.5 before:top-1 before:bottom-1 before:w-0.5 before:bg-slate-800 text-xs">
                  @for (step of asset.provenance.provenanceChain; track step.hash) {
                    <div class="relative">
                      <div class="absolute -left-4 top-1 w-2.5 h-2.5 rounded-full bg-cyan-500 border-2 border-slate-950"></div>
                      <div class="flex justify-between items-baseline">
                        <strong class="text-cyan-300 text-[11px]">{{ step.stage }}</strong>
                        <span class="text-[10px] font-mono text-slate-500">{{ step.date }}</span>
                      </div>
                      <p class="text-slate-300 text-[11px]">{{ step.action }}</p>
                      <span class="text-[10px] font-mono text-slate-500 truncate block">{{ step.hash }}</span>
                    </div>
                  }
                </div>
              </div>
            </div>
          }

          <!-- 4. 4D/5D COST & CARBON TAB -->
          @if (activeTab() === 'COST_CARBON') {
            <div class="space-y-4">
              <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-2">
                <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <mat-icon class="text-xs text-emerald-400">payments</mat-icon> 5D Cost Engineering
                </h3>
                <div class="grid grid-cols-2 gap-2 text-xs">
                  <div class="bg-slate-900 p-2 rounded border border-slate-800">
                    <span class="text-slate-500 block text-[10px]">PLANNED BUDGET</span>
                    <strong class="font-mono text-white">£{{ (asset.costCarbon.plannedCostGbp / 1000000) | number:'1.2-2' }}M</strong>
                  </div>
                  <div class="bg-slate-900 p-2 rounded border border-slate-800">
                    <span class="text-slate-500 block text-[10px]">ACTUAL COST</span>
                    <strong class="font-mono text-emerald-400">£{{ (asset.costCarbon.actualCostGbp / 1000000) | number:'1.2-2' }}M</strong>
                  </div>
                  <div class="bg-slate-900 p-2 rounded border border-slate-800 col-span-2 flex justify-between items-center">
                    <span class="text-slate-400">Variance:</span>
                    <span class="font-mono font-bold" [class.text-emerald-400]="asset.costCarbon.costVarianceGbp <= 0" [class.text-rose-400]="asset.costCarbon.costVarianceGbp > 0">
                      {{ asset.costCarbon.costVarianceGbp <= 0 ? 'SAVING' : 'OVERRUN' }} £{{ (Math.abs(asset.costCarbon.costVarianceGbp) / 1000) | number:'1.0-0' }}k
                    </span>
                  </div>
                </div>
              </div>

              <!-- Carbon Accounting -->
              <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-2">
                <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <mat-icon class="text-xs text-emerald-400">eco</mat-icon> Embodied & Operational Carbon
                </h3>
                <div class="bg-slate-900 p-2.5 rounded border border-slate-800 space-y-1 text-xs">
                  <div class="flex justify-between items-baseline">
                    <span class="text-slate-400">Embodied Carbon:</span>
                    <strong class="font-mono text-emerald-300 text-sm">{{ (asset.costCarbon.embodiedCarbonKgCO2e / 1000) | number:'1.1-1' }} tCO2e</strong>
                  </div>
                  <div class="flex justify-between items-baseline">
                    <span class="text-slate-400">Material Quantity:</span>
                    <span class="font-mono text-white">{{ asset.costCarbon.materialQuantity }} {{ asset.costCarbon.materialUnit }}</span>
                  </div>
                  <div class="pt-1 border-t border-slate-800 text-[11px] text-slate-400 italic">
                    {{ asset.costCarbon.carbonReductionMeasure }}
                  </div>
                </div>
              </div>
            </div>
          }

          <!-- 5. RELATIONSHIPS & DEPENDENCY GRAPH TAB -->
          @if (activeTab() === 'RELATIONSHIPS') {
            <div class="space-y-3">
              <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <mat-icon class="text-xs text-cyan-400">hub</mat-icon> Connected Infrastructure Graph
              </h3>
              @for (rel of asset.relationships; track rel.targetAssetId) {
                <div 
                  tabindex="0"
                  (click)="dataService.selectAsset(rel.targetAssetId)"
                  (keydown.enter)="dataService.selectAsset(rel.targetAssetId)"
                  class="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800 hover:border-cyan-500 cursor-pointer transition-colors text-xs space-y-1 focus:outline-none focus:border-cyan-400">
                  <div class="flex items-center justify-between">
                    <span class="font-mono text-[10px] text-amber-400 bg-amber-950/60 px-1.5 py-0.2 rounded border border-amber-800">
                      {{ rel.type }}
                    </span>
                    <span [class]="rel.criticality === 'CRITICAL' ? 'text-rose-400' : 'text-slate-400'" class="text-[10px] font-semibold">
                      {{ rel.criticality }}
                    </span>
                  </div>
                  <strong class="text-white block hover:text-cyan-300">{{ rel.targetName }}</strong>
                  <span class="text-[10px] font-mono text-slate-400 block">{{ rel.targetAssetId }} ({{ rel.targetClass }})</span>
                </div>
              }
            </div>
          }

          <!-- 6. TESTING & DEFECTS TAB -->
          @if (activeTab() === 'TESTS_DEFECTS') {
            <div class="space-y-4">
              <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-2">
                <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <mat-icon class="text-xs text-cyan-400">fact_check</mat-icon> Verification & Commissioning Tests
                </h3>
                @for (test of asset.tests; track test.testId) {
                  <div class="bg-slate-900 p-2.5 rounded border border-slate-800 text-xs space-y-1">
                    <div class="flex justify-between items-center">
                      <span class="font-mono font-bold text-cyan-300 text-[11px]">{{ test.testId }}</span>
                      <span class="bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded font-mono text-[10px] border border-emerald-800">
                        {{ test.result }}
                      </span>
                    </div>
                    <p class="text-white text-xs font-medium">{{ test.testCase }}</p>
                    <div class="flex justify-between text-[10px] text-slate-400 pt-1">
                      <span>Phase: {{ test.phase }}</span>
                      <span>Certificate: {{ test.certificateNumber }}</span>
                    </div>
                  </div>
                }
              </div>

              <!-- Maintenance & RUL -->
              <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-2 text-xs">
                <h4 class="text-[11px] font-semibold uppercase text-slate-400 tracking-wider">Asset Health & Remaining Life</h4>
                <div class="grid grid-cols-2 gap-2">
                  <div class="bg-slate-900 p-2 rounded border border-slate-800">
                    <span class="text-slate-500 block text-[10px]">CONDITION SCORE</span>
                    <strong class="font-mono text-emerald-400 text-sm">Level {{ asset.maintenanceSchedule.conditionScore }} / 5 (Good)</strong>
                  </div>
                  <div class="bg-slate-900 p-2 rounded border border-slate-800">
                    <span class="text-slate-500 block text-[10px]">REMAINING LIFE (RUL)</span>
                    <strong class="font-mono text-cyan-300 text-sm">{{ asset.maintenanceSchedule.remainingUsefulLifeYears }} Years</strong>
                  </div>
                </div>
              </div>
            </div>
          }
        </div>
      } @else {
        <div class="h-full flex flex-col items-center justify-center p-6 text-slate-500 text-center">
          <mat-icon class="text-4xl text-slate-700 mb-2">touch_app</mat-icon>
          <h3 class="text-sm font-semibold text-slate-400">No Asset Selected</h3>
          <p class="text-xs text-slate-500 mt-1">Click any asset in the 3D viewport or select from the asset register to inspect engineering metadata.</p>
        </div>
      }
    </aside>
  `
})
export class AssetInspectorComponent {
  public readonly dataService = inject(DigitalTwinDataService);
  public readonly Math = Math;

  public readonly activeTab = signal<'PARAMS' | 'SENSORS' | 'PROVENANCE' | 'COST_CARBON' | 'RELATIONSHIPS' | 'TESTS_DEFECTS'>('PARAMS');

  public readonly tabs = [
    { id: 'PARAMS' as const, label: 'Parameters', icon: 'tune' },
    { id: 'SENSORS' as const, label: 'Telemetry & SHM', icon: 'sensors' },
    { id: 'PROVENANCE' as const, label: 'Lineage & CDE', icon: 'history_edu' },
    { id: 'COST_CARBON' as const, label: 'Cost & Carbon', icon: 'payments' },
    { id: 'RELATIONSHIPS' as const, label: 'Graph', icon: 'hub' },
    { id: 'TESTS_DEFECTS' as const, label: 'Tests & Health', icon: 'fact_check' }
  ];

  public getParamEntries(params: Record<string, string | number | boolean>): { key: string; value: string | number | boolean }[] {
    return Object.entries(params).map(([key, value]) => ({ key, value }));
  }

  public formatKey(key: string): string {
    return key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
  }

  public getClassBadgeColor(assetClass: string): string {
    switch (assetClass) {
      case 'viaduct':
      case 'bridge': return 'bg-purple-950 text-purple-300 border border-purple-800';
      case 'tunnel': return 'bg-slate-800 text-slate-200 border border-slate-700';
      case 'station': return 'bg-blue-950 text-blue-300 border border-blue-800';
      case 'substation': return 'bg-amber-950 text-amber-300 border border-amber-800';
      case 'slab':
      case 'track': return 'bg-emerald-950 text-emerald-300 border border-emerald-800';
      case 'mast':
      case 'overhead_line': return 'bg-orange-950 text-orange-300 border border-orange-800';
      default: return 'bg-slate-800 text-slate-300 border border-slate-700';
    }
  }

  public getValidationBadgeClass(status: string): string {
    switch (status) {
      case 'VALIDATED': return 'bg-emerald-950 text-emerald-400 border border-emerald-800';
      case 'WARNING': return 'bg-amber-950 text-amber-400 border border-amber-800';
      case 'DEFECT': return 'bg-rose-950 text-rose-400 border border-rose-800';
      default: return 'bg-slate-800 text-slate-400';
    }
  }
}
