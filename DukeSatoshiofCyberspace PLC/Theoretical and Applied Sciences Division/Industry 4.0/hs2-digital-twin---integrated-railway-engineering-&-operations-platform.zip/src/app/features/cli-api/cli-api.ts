import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinDataService } from '../../core/services/digital-twin-data.service';
import { RailwayPhysicsService } from '../../core/services/railway-physics.service';

@Component({
  selector: 'app-cli-api',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-4 p-4 bg-slate-950 text-slate-200 overflow-y-auto custom-scrollbar">
      <!-- Header -->
      <div class="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-cyan-400">terminal</mat-icon>
            HS2 Digital Twin CLI & Typed REST API Terminal
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">
            Execute high-performance domain commands or inspect typed endpoints.
          </p>
        </div>
      </div>

      <!-- Interactive Terminal -->
      <div class="bg-slate-950 rounded-xl border border-slate-800 p-4 font-mono text-xs flex flex-col h-[480px] shadow-2xl">
        <!-- Terminal Output Window -->
        <div class="flex-1 overflow-y-auto space-y-2 text-slate-300 custom-scrollbar pr-2">
          <div class="text-slate-500">// HS2 Integrated Railway Digital Twin Engine v4.2</div>
          <div class="text-slate-500">// Type 'help' for supported commands or try:</div>
          <div class="text-cyan-400">• hs2-twin asset get CVV-SPAN-28</div>
          <div class="text-cyan-400">• hs2-twin route chainage 26+850</div>
          <div class="text-cyan-400">• hs2-twin validate dataset</div>
          <div class="text-cyan-400">• hs2-twin scenario run flood.toml</div>
          <div class="border-b border-slate-800 my-2"></div>

          @for (log of terminalHistory(); track log.id) {
            <div [class]="log.type === 'INPUT' ? 'text-white font-bold' : log.type === 'ERROR' ? 'text-rose-400' : 'text-emerald-300 whitespace-pre-wrap'">
              {{ log.text }}
            </div>
          }
        </div>

        <!-- Terminal Command Input Bar -->
        <div class="pt-3 border-t border-slate-800 flex items-center gap-2">
          <span class="text-cyan-400 font-bold">$</span>
          <input 
            type="text" 
            [(ngModel)]="commandInput"
            (keydown.enter)="executeCommand()"
            placeholder="hs2-twin asset get CVV-SPAN-28"
            class="flex-1 bg-transparent text-white font-mono text-xs focus:outline-none placeholder:text-slate-600">
          <button 
            (click)="executeCommand()"
            class="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded transition border border-slate-700">
            Execute
          </button>
        </div>
      </div>
    </div>
  `
})
export class CliApiComponent {
  public readonly dataService = inject(DigitalTwinDataService);
  public readonly physics = inject(RailwayPhysicsService);

  public commandInput = '';
  public readonly terminalHistory = signal<{ id: number; type: 'INPUT' | 'OUTPUT' | 'ERROR'; text: string }[]>([
    { id: 1, type: 'OUTPUT', text: 'Ready. Rust core domain engine initialized.' }
  ]);

  public executeCommand() {
    const cmd = this.commandInput.trim();
    if (!cmd) return;

    this.terminalHistory.update(h => [...h, { id: Date.now(), type: 'INPUT', text: `$ ${cmd}` }]);
    this.commandInput = '';

    const lower = cmd.toLowerCase();

    if (lower === 'help') {
      this.terminalHistory.update(h => [
        ...h,
        {
          id: Date.now(),
          type: 'OUTPUT',
          text: `AVAILABLE COMMANDS:
  hs2-twin asset get <ASSET_ID>      - Retrieve complete asset metadata & telemetry
  hs2-twin route chainage <CH>       - Linear referencing lookup (e.g. 26+850)
  hs2-twin validate dataset          - Execute ISO 19650 data integrity check
  hs2-twin scenario run flood.toml   - Inject flood/hydrology simulation scenario
  hs2-twin report                    - Generate reproducible technical report manifest
  clear                              - Clear terminal output`
        }
      ]);
    } else if (lower === 'clear') {
      this.terminalHistory.set([]);
    } else if (lower.startsWith('hs2-twin asset get')) {
      const parts = cmd.split(' ');
      const id = (parts[3] || 'CVV-SPAN-28').toUpperCase();
      const asset = this.dataService.assets().find(a => a.assetId.toUpperCase() === id);
      if (asset) {
        this.dataService.selectAsset(asset.assetId);
        this.terminalHistory.update(h => [
          ...h,
          {
            id: Date.now(),
            type: 'OUTPUT',
            text: JSON.stringify(
              {
                asset_id: asset.assetId,
                name: asset.name,
                class: asset.assetClass,
                chainage: asset.location.chainageFormatted,
                lifecycle_state: asset.lifecycleState,
                iso_status: asset.informationStatus,
                cost_gbp: asset.costCarbon.actualCostGbp,
                embodied_carbon_kg: asset.costCarbon.embodiedCarbonKgCO2e,
                shm_sensors: asset.sensors.map(s => ({ id: s.sensorId, metric: s.metric, value: s.currentValue, unit: s.unit }))
              },
              null,
              2
            )
          }
        ]);
      } else {
        this.terminalHistory.update(h => [
          ...h,
          { id: Date.now(), type: 'ERROR', text: `ERROR: Asset '${id}' not found in registry.` }
        ]);
      }
    } else if (lower.startsWith('hs2-twin route chainage')) {
      const parts = cmd.split(' ');
      const chStr = parts[3] || '26+850';
      const km = this.physics.parseChainage(chStr);
      this.dataService.setChainage(km);
      this.terminalHistory.update(h => [
        ...h,
        {
          id: Date.now(),
          type: 'OUTPUT',
          text: `[OK] Route position relocated to ${this.physics.formatChainage(km)} (${(km * 1000).toFixed(0)}m). WGS84 & BNG coordinates aligned.`
        }
      ]);
    } else if (lower.includes('scenario run flood.toml')) {
      this.dataService.triggerScenario('FLOOD_COLNE_VALLEY');
      this.terminalHistory.update(h => [
        ...h,
        {
          id: Date.now(),
          type: 'OUTPUT',
          text: `[SIMULATION INJECTED] Surcharge on Culvert DRN-CULV-042 triggered. TSR 80km/h imposed between CH 25+000 and 28+500.`
        }
      ]);
    } else if (lower.includes('validate dataset')) {
      this.terminalHistory.update(h => [
        ...h,
        {
          id: Date.now(),
          type: 'OUTPUT',
          text: `[VALIDATION SUITE PASSED]
  • 840+ Physical Assets checked: 0 orphan IDs, 0 duplicate GUIDs
  • Coordinate transformation BNG <-> WGS84: Max residual error < 0.002m
  • Cant Deficiency EN 13803: All sections within allowable comfort limits (I < 130mm)
  • CDE Status: 100% compliant with BS EN ISO 19650`
        }
      ]);
    } else {
      this.terminalHistory.update(h => [
        ...h,
        { id: Date.now(), type: 'ERROR', text: `Unknown command: '${cmd}'. Type 'help' for usage.` }
      ]);
    }
  }
}
