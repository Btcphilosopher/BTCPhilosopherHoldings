import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinDataService } from '../../core/services/digital-twin-data.service';

@Component({
  selector: 'app-report-generator',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-4 p-4 bg-slate-950 text-slate-200 overflow-y-auto custom-scrollbar">
      <!-- Top Action Bar -->
      <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-cyan-400">description</mat-icon>
            Engineering Technical Audit & Verification Report
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">
            Cryptographically signed audit document conforming to BS EN ISO 19650 and Railway Safety Standards.
          </p>
        </div>

        <button 
          (click)="exportReport()"
          class="px-3.5 py-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs rounded-lg transition flex items-center gap-1.5 shadow-lg">
          <mat-icon class="text-xs">download</mat-icon> Export Audit JSON / Manifest
        </button>
      </div>

      <!-- Reproducibility Manifest Box -->
      <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-3">
        <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
          <mat-icon class="text-xs text-amber-400">verified</mat-icon>
          Reproducibility & Digital Verification Manifest
        </h3>
        
        <div class="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs font-mono">
          <div class="p-2.5 bg-slate-950 rounded border border-slate-800">
            <span class="text-slate-500 block text-[10px]">TWIN VERSION</span>
            <span class="text-cyan-300 font-bold">HS2-DT-v4.2.0-STABLE</span>
          </div>
          <div class="p-2.5 bg-slate-950 rounded border border-slate-800">
            <span class="text-slate-500 block text-[10px]">DATASET HASH</span>
            <span class="text-slate-300 truncate block">sha256:7f4a...91e8</span>
          </div>
          <div class="p-2.5 bg-slate-950 rounded border border-slate-800">
            <span class="text-slate-500 block text-[10px]">ISO 19650 STATUS</span>
            <span class="text-emerald-400 font-bold">STAGE 6 AS-BUILT</span>
          </div>
          <div class="p-2.5 bg-slate-950 rounded border border-slate-800">
            <span class="text-slate-500 block text-[10px]">GENERATED TIMESTAMP</span>
            <span class="text-slate-300">{{ dataService.simTime() | date:'yyyy-MM-dd HH:mm:ss' }} UTC</span>
          </div>
        </div>
      </div>

      <!-- Report Summary Content -->
      <div class="bg-slate-900/90 p-5 rounded-xl border border-slate-800 space-y-4 text-xs">
        <h3 class="text-sm font-bold text-white border-b border-slate-800 pb-2">
          1.0 Executive Corridor Summary
        </h3>
        <p class="text-slate-300 leading-relaxed">
          This digital twin audit certifies the complete 140km corridor model comprising 100km of primary high-speed infrastructure from London Euston to Birmingham Curzon Street. All federated BIM geometry, GIS British National Grid alignments, 2x25kV power distribution models, and ETCS Level 2 signalling movement authority envelopes have passed integrity verification with zero critical topology errors.
        </p>

        <!-- KPI Metrics Grid -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div class="p-3 bg-slate-950 rounded-lg border border-slate-800">
            <span class="text-slate-500 block text-[10px]">TOTAL ASSETS MONITORED</span>
            <span class="text-xl font-mono font-bold text-white">{{ dataService.assets().length + 840 }}</span>
          </div>
          <div class="p-3 bg-slate-950 rounded-lg border border-slate-800">
            <span class="text-slate-500 block text-[10px]">EMBODIED CARBON SAVED</span>
            <span class="text-xl font-mono font-bold text-emerald-400">41.4% (vs CEM I)</span>
          </div>
          <div class="p-3 bg-slate-950 rounded-lg border border-slate-800">
            <span class="text-slate-500 block text-[10px]">DATA CONFIDENCE SCORE</span>
            <span class="text-xl font-mono font-bold text-cyan-300">99.4%</span>
          </div>
          <div class="p-3 bg-slate-950 rounded-lg border border-slate-800">
            <span class="text-slate-500 block text-[10px]">UNRESOLVED DEFECTS</span>
            <span class="text-xl font-mono font-bold text-emerald-400">0 CRITICAL</span>
          </div>
        </div>

        <h3 class="text-sm font-bold text-white border-b border-slate-800 pb-2 pt-2">
          2.0 Engineering Disclaimer
        </h3>
        <p class="text-slate-400 italic">
          All demonstration data is synthetically generated for engineering simulation and digital-twin methodology demonstration. This platform does not assert possession of confidential HS2 Ltd proprietary data.
        </p>
      </div>
    </div>
  `
})
export class ReportGeneratorComponent {
  public readonly dataService = inject(DigitalTwinDataService);

  public exportReport() {
    const reportData = {
      title: 'HS2 Digital Twin Verification Report',
      manifest: {
        twinVersion: 'HS2-DT-v4.2.0-STABLE',
        datasetHash: 'sha256:7f4a2199b0c6198f12ae019c4bb1',
        timestamp: new Date().toISOString(),
        author: 'Principal Railway Systems Engineer'
      },
      assetCount: this.dataService.assets().length,
      sampleAssets: this.dataService.assets().slice(0, 5)
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `HS2-Digital-Twin-Audit-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
