import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinDataService } from '../../core/services/digital-twin-data.service';
import { RailwayPhysicsService } from '../../core/services/railway-physics.service';

@Component({
  selector: 'app-operations-console',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-4 p-4 bg-slate-950 text-slate-200 overflow-y-auto custom-scrollbar">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-emerald-400">speed</mat-icon>
            High-Speed Traffic, Signalling & Power Operations Console
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">
            Real-time ETCS Level 2 Full Supervision, 25kV AT Traction Network & Train Aerodynamic Physics
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span class="text-xs font-mono font-bold text-emerald-400">NETWORK STATE: 3 TRAINS IN FULL SUPERVISION</span>
        </div>
      </div>

      <!-- Live Trains Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        @for (train of dataService.liveTrains(); track train.trainId) {
          <div class="bg-slate-900/90 rounded-xl border border-slate-800 p-4 space-y-3 shadow-lg">
            <!-- Train Top Banner -->
            <div class="flex justify-between items-start">
              <div>
                <span class="text-xs font-mono font-bold text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800">
                  {{ train.headcode }}
                </span>
                <h3 class="text-sm font-bold text-white mt-1.5">{{ train.serviceName }}</h3>
                <span class="text-[11px] text-slate-400 block font-mono">{{ train.rollingStockType }}</span>
              </div>
              <span class="bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded font-mono text-[10px] border border-emerald-800 font-semibold">
                {{ train.status }}
              </span>
            </div>

            <!-- Speed & Power Gauges -->
            <div class="grid grid-cols-2 gap-2 bg-slate-950 p-2.5 rounded-lg border border-slate-800/80 text-xs">
              <div>
                <span class="text-slate-500 block text-[10px]">CURRENT SPEED</span>
                <span class="text-2xl font-mono font-bold text-white">{{ train.currentSpeedKmh }}</span>
                <span class="text-slate-400 text-xs ml-1 font-mono">km/h</span>
              </div>
              <div>
                <span class="text-slate-500 block text-[10px]">TRACTION POWER</span>
                <span class="text-2xl font-mono font-bold text-cyan-400">{{ (train.instantPowerKw / 1000) | number:'1.1-1' }}</span>
                <span class="text-slate-400 text-xs ml-1 font-mono">MW</span>
              </div>
            </div>

            <!-- ETCS & Physics Details -->
            <div class="space-y-1.5 text-xs">
              <div class="flex justify-between text-slate-400">
                <span>Location:</span>
                <strong class="font-mono text-cyan-300">{{ physics.formatChainage(train.currentChainageKm) }}</strong>
              </div>
              <div class="flex justify-between text-slate-400">
                <span>ETCS Mode:</span>
                <span class="font-mono text-emerald-400">{{ train.etcsMode }}</span>
              </div>
              <div class="flex justify-between text-slate-400">
                <span>Movement Authority:</span>
                <span class="font-mono text-white">{{ (train.movementAuthorityDistanceM / 1000) | number:'1.1-1' }} km ahead</span>
              </div>
              <div class="flex justify-between text-slate-400">
                <span>Catenary Voltage:</span>
                <span class="font-mono text-amber-300">{{ train.catenaryVoltageKv }} kV (245 A)</span>
              </div>
            </div>

            <!-- Quick Track Focus -->
            <button 
              (click)="dataService.setChainage(train.currentChainageKm)"
              class="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded transition flex items-center justify-center gap-1">
              <mat-icon class="text-xs">my_location</mat-icon> Track Train Position
            </button>
          </div>
        }
      </div>

      <!-- Power Grid Substations & Interlockings Section -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <!-- Substations -->
        <div class="bg-slate-900/90 rounded-xl border border-slate-800 p-4 space-y-3">
          <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <mat-icon class="text-xs text-amber-400">bolt</mat-icon> 2x25kV Auto-Transformer Feeder Substations
          </h3>

          <div class="space-y-2.5">
            @for (sub of dataService.substations(); track sub.nodeId) {
              <div class="p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs space-y-2">
                <div class="flex justify-between items-center">
                  <strong class="text-white">{{ sub.name }}</strong>
                  <span class="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-800">
                    {{ sub.operationalStatus }}
                  </span>
                </div>
                <div class="grid grid-cols-3 gap-2 text-[11px] font-mono">
                  <div>
                    <span class="text-slate-500 block text-[9px]">LOAD / CAPACITY</span>
                    <span class="text-amber-300 font-bold">{{ sub.currentLoadMva }} / {{ sub.ratedMva }} MVA</span>
                  </div>
                  <div>
                    <span class="text-slate-500 block text-[9px]">BUS VOLTAGE</span>
                    <span class="text-white">{{ sub.busVoltageKv }} kV</span>
                  </div>
                  <div>
                    <span class="text-slate-500 block text-[9px]">THERMAL MARGIN</span>
                    <span class="text-emerald-400">{{ sub.thermalMarginPercent }}%</span>
                  </div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- ETCS Signalling Interlockings -->
        <div class="bg-slate-900/90 rounded-xl border border-slate-800 p-4 space-y-3">
          <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <mat-icon class="text-xs text-cyan-400">alt_route</mat-icon> ETCS Level 2 Radio Block Centres (RBC)
          </h3>

          <div class="space-y-2.5">
            @for (area of dataService.interlockings(); track area.areaId) {
              <div class="p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs space-y-2">
                <div class="flex justify-between items-center">
                  <strong class="text-white">{{ area.name }}</strong>
                  <span class="text-[10px] font-mono text-cyan-400 bg-cyan-950 px-1.5 py-0.5 rounded border border-cyan-800">
                    {{ area.systemHealth }}
                  </span>
                </div>
                <div class="flex justify-between text-slate-400 text-[11px]">
                  <span>Zone: CH {{ area.chainageStartKm }}+000 to {{ area.chainageEndKm }}+000</span>
                  <span class="font-mono text-slate-300">Active MAs: {{ area.activeMovementAuthorities }}</span>
                </div>
                <div class="flex gap-1.5 pt-1">
                  @for (tc of area.trackCircuits; track tc.id) {
                    <div 
                      [class.bg-rose-900]="tc.occupied"
                      [class.border-rose-600]="tc.occupied"
                      [class.bg-slate-900]="!tc.occupied"
                      [class.border-slate-700]="!tc.occupied"
                      class="flex-1 py-1 px-2 rounded border text-center font-mono text-[10px]">
                      {{ tc.id }}: {{ tc.occupied ? 'OCCUPIED' : 'CLEAR' }}
                    </div>
                  }
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class OperationsConsoleComponent {
  public readonly dataService = inject(DigitalTwinDataService);
  public readonly physics = inject(RailwayPhysicsService);
}
