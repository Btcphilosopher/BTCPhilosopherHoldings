import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinDataService } from '../../core/services/digital-twin-data.service';
import { RailwayPhysicsService } from '../../core/services/railway-physics.service';

@Component({
  selector: 'app-route-explorer',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-4 p-4 bg-slate-950 text-slate-200 overflow-y-auto custom-scrollbar">
      <!-- Header Bar -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-cyan-400">linear_scale</mat-icon>
            Route Linear Referencing & GIS Alignment
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">
            Continuous 100km corridor from London Euston (CH 0+000) to Birmingham Curzon Street (CH 140+000)
          </p>
        </div>

        <div class="flex items-center gap-3">
          <!-- Chainage Quick Jump -->
          <div class="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-xs">
            <span class="text-slate-400 font-mono">CHAINAGE:</span>
            <input 
              type="text" 
              [value]="physics.formatChainage(dataService.activeChainage())" 
              (change)="onChainageInput($event)"
              class="bg-slate-900 text-cyan-300 font-mono font-bold px-2 py-1 rounded border border-slate-700 w-28 text-center text-xs focus:outline-none focus:border-cyan-500">
          </div>

          <button 
            (click)="jumpToLocation(26.850)"
            class="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition border border-slate-700">
            Colne Valley Viaduct
          </button>
          <button 
            (click)="jumpToLocation(29.200)"
            class="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition border border-slate-700">
            Chiltern Tunnel
          </button>
          <button 
            (click)="jumpToLocation(7.450)"
            class="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition border border-slate-700">
            Old Oak Common
          </button>
        </div>
      </div>

      <!-- Linear Route Chainage Scrubbing Slider -->
      <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-3">
        <div class="flex justify-between items-center text-xs">
          <span class="font-semibold text-slate-300 flex items-center gap-1.5">
            <mat-icon class="text-xs text-cyan-400">tune</mat-icon> Linear Chainage Position
          </span>
          <span class="font-mono text-cyan-400 font-bold text-sm">
            {{ physics.formatChainage(dataService.activeChainage()) }} ({{ (dataService.activeChainage() * 1000) | number:'1.0-0' }}m)
          </span>
        </div>

        <input 
          type="range" 
          min="0" 
          max="140" 
          step="0.1" 
          [value]="dataService.activeChainage()" 
          (input)="onSliderChange($event)"
          class="w-full accent-cyan-400 cursor-pointer h-2 bg-slate-950 rounded-lg">

        <!-- Corridor Milestone Ticks -->
        <div class="flex justify-between text-[10px] font-mono text-slate-500 pt-1 border-t border-slate-800/80">
          <span>Euston (0+000)</span>
          <span>Old Oak (7+450)</span>
          <span>Colne Valley (26+850)</span>
          <span>Chiltern Tunnel (29+200)</span>
          <span>Calvert (72+000)</span>
          <span>Interchange (120+000)</span>
          <span>Curzon St (140+000)</span>
        </div>
      </div>

      <!-- Route Point Engineering Profile -->
      @if (currentPoint(); as pt) {
        <div class="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
            <span class="text-slate-500 block text-[10px] uppercase font-mono">VERTICAL PROFILE</span>
            <div class="flex items-baseline justify-between">
              <strong class="text-lg font-mono text-white">{{ pt.elevationM }} m</strong>
              <span class="font-mono" [class.text-emerald-400]="pt.gradientPercent >= 0" [class.text-amber-400]="pt.gradientPercent < 0">
                {{ pt.gradientPercent > 0 ? '+' : '' }}{{ pt.gradientPercent }}%
              </span>
            </div>
            <span class="text-[10px] text-slate-400 block">Gradient (1 in {{ Math.abs(Math.round(100 / (pt.gradientPercent || 0.001))) }})</span>
          </div>

          <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
            <span class="text-slate-500 block text-[10px] uppercase font-mono">HORIZONTAL CURVATURE</span>
            <div class="flex items-baseline justify-between">
              <strong class="text-lg font-mono text-white">{{ pt.horizontalRadiusM === 0 ? 'Tangent (Straight)' : pt.horizontalRadiusM + ' m' }}</strong>
            </div>
            <span class="text-[10px] text-slate-400 block">Applied Cant: {{ pt.appliedCantMm }} mm</span>
          </div>

          <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
            <span class="text-slate-500 block text-[10px] uppercase font-mono">LINE SPEED ENVELOPE</span>
            <div class="flex items-baseline justify-between">
              <strong class="text-lg font-mono text-cyan-300">{{ pt.lineSpeedKmh }} km/h</strong>
              <span class="text-[10px] font-mono text-slate-400">Eq: {{ pt.equilibriumSpeedKmh }} km/h</span>
            </div>
            <span class="text-[10px] text-slate-400 block">Track: {{ pt.trackCategory }}</span>
          </div>

          <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
            <span class="text-slate-500 block text-[10px] uppercase font-mono">BRITISH NATIONAL GRID</span>
            <div class="flex items-baseline justify-between">
              <strong class="text-sm font-mono text-slate-200">{{ pt.easting }}E, {{ pt.northing }}N</strong>
            </div>
            <span class="text-[10px] font-mono text-slate-400 block">WGS84: {{ pt.latitude | number:'1.4-4' }}, {{ pt.longitude | number:'1.4-4' }}</span>
          </div>
        </div>
      }

      <!-- Nearby Assets Query Results -->
      <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-3 flex-1">
        <div class="flex justify-between items-center">
          <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <mat-icon class="text-xs text-amber-400">radar</mat-icon>
            Assets Located Near Chainage {{ physics.formatChainage(dataService.activeChainage()) }} (±1.5 km window)
          </h3>
          <span class="text-xs font-mono text-slate-400">{{ nearbyAssets().length }} Assets Found</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
          @for (asset of nearbyAssets(); track asset.assetId) {
            <div 
              tabindex="0"
              (click)="dataService.selectAsset(asset.assetId)"
              (keydown.enter)="dataService.selectAsset(asset.assetId)"
              [class.border-cyan-500]="dataService.selectedAssetId() === asset.assetId"
              class="p-3 bg-slate-950 rounded-lg border border-slate-800 hover:border-slate-700 cursor-pointer transition-all space-y-1.5 focus:outline-none focus:border-cyan-400">
              <div class="flex justify-between items-center">
                <span class="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950/80 px-1.5 py-0.5 rounded border border-cyan-800">
                  {{ asset.assetId }}
                </span>
                <span class="text-[10px] font-mono text-slate-400">
                  {{ asset.location.chainageFormatted }}
                </span>
              </div>
              <h4 class="text-xs font-semibold text-white truncate">{{ asset.name }}</h4>
              <div class="flex justify-between text-[11px] text-slate-400">
                <span>{{ asset.discipline }}</span>
                <span class="text-emerald-400 font-medium">{{ asset.lifecycleState }}</span>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class RouteExplorerComponent {
  public readonly dataService = inject(DigitalTwinDataService);
  public readonly physics = inject(RailwayPhysicsService);
  public readonly Math = Math;

  public readonly currentPoint = computed(() => {
    const ch = this.dataService.activeChainage();
    const points = this.dataService.routePoints();
    return points.reduce((prev, curr) => 
      Math.abs(curr.chainageKm - ch) < Math.abs(prev.chainageKm - ch) ? curr : prev
    , points[0]);
  });

  public readonly nearbyAssets = computed(() => {
    const ch = this.dataService.activeChainage();
    return this.dataService.assets().filter(a => Math.abs(a.location.chainageKm - ch) <= 1.5);
  });

  public onSliderChange(event: Event) {
    const target = event.target as HTMLInputElement;
    this.dataService.setChainage(parseFloat(target.value));
  }

  public onChainageInput(event: Event) {
    const target = event.target as HTMLInputElement;
    const km = this.physics.parseChainage(target.value);
    this.dataService.setChainage(km);
  }

  public jumpToLocation(chKm: number) {
    this.dataService.setChainage(chKm);
  }
}
