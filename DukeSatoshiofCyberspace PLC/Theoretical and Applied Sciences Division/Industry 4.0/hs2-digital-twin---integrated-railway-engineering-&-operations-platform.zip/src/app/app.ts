import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinDataService } from './core/services/digital-twin-data.service';
import { RailwayPhysicsService } from './core/services/railway-physics.service';
import { Twin3DComponent } from './features/twin-3d/twin-3d';
import { AssetInspectorComponent } from './features/asset-inspector/asset-inspector';
import { RouteExplorerComponent } from './features/route-explorer/route-explorer';
import { OperationsConsoleComponent } from './features/operations-console/operations-console';
import { ScenarioSimulatorComponent } from './features/scenario-simulator/scenario-simulator';
import { ReportGeneratorComponent } from './features/report-generator/report-generator';
import { CliApiComponent } from './features/cli-api/cli-api';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    FormsModule,
    MatIconModule,
    Twin3DComponent,
    AssetInspectorComponent,
    RouteExplorerComponent,
    OperationsConsoleComponent,
    ScenarioSimulatorComponent,
    ReportGeneratorComponent,
    CliApiComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  public readonly dataService = inject(DigitalTwinDataService);
  public readonly physics = inject(RailwayPhysicsService);

  // Active Main Navigation View
  public readonly currentView = signal<
    'CONTROL_CENTRE' | 'ROUTE_GIS' | 'OPERATIONS' | 'SCENARIOS' | 'ASSETS_TABLE' | 'REPORTS' | 'CLI'
  >('CONTROL_CENTRE');

  // Time machine year state (2024 to 2029)
  public readonly selectedYear = signal<number>(2026);

  public readonly filteredAssets = computed(() => {
    const list = this.dataService.assets();
    const disc = this.dataService.activeFilterDiscipline();
    const query = this.dataService.searchQuery().toLowerCase().trim();

    return list.filter(a => {
      const matchDisc = disc === 'ALL' || a.discipline === disc;
      const matchQuery = !query || a.name.toLowerCase().includes(query) || a.assetId.toLowerCase().includes(query) || a.assetClass.toLowerCase().includes(query);
      return matchDisc && matchQuery;
    });
  });

  public setView(view: 'CONTROL_CENTRE' | 'ROUTE_GIS' | 'OPERATIONS' | 'SCENARIOS' | 'ASSETS_TABLE' | 'REPORTS' | 'CLI') {
    this.currentView.set(view);
  }

  public setYear(year: number) {
    this.selectedYear.set(year);
    this.dataService.setSimDate(new Date(`${year}-10-02T10:30:00Z`));
  }
}
