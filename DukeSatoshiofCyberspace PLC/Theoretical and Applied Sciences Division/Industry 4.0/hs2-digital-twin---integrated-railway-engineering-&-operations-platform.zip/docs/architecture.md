# HS2 Digital Twin — Architecture Overview

## 1. System Architecture

The **HS2 Digital Twin Platform** is engineered as a unified computational data and physics layer connecting physical railway infrastructure to digital engineering representations across the entire lifecycle:

```
REQUIREMENTS → DESIGN → ENGINEERING → CONSTRUCTION → AS-BUILT → COMMISSIONING → OPERATIONS → MAINTENANCE → CONDITION TELEMETRY → EXPLAINABLE ANALYTICS → PREDICTIVE DECISION → UPDATED TWIN
```

### 1.1 Core Principles
1. **The Digital Twin is not just a 3D model**: Geometry is merely one visual projection. The twin federates topological graphs, continuous linear referencing, time series telemetry, finite element structural models, electrical load flows, and ISO 19650 CDE metadata.
2. **Strict Provenance & Immutability**: Every engineering parameter retains its source drawing, revision, author, and cryptographic hash (`sha256`).
3. **No Phantom Precision / Safety Envelope Guardrails**: When data is outside the calibrated envelope, the system flags `OUTSIDE_ENVELOPE` rather than guessing.
4. **Synthetic Data Transparency**: All demonstration data is explicitly labeled as **SYNTHETIC / DEMONSTRATION DATA**.

---

## 2. Federation Architecture

```
┌────────────────────────────────────────────────────────────────────────┐
│                        HS2 DIGITAL TWIN ENGINE                         │
├─────────────────┬─────────────────┬──────────────────┬─────────────────┤
│   BIM LAYER     │    GIS LAYER    │ TELEMETRY / SHM  │ PHYSICS ENGINE  │
│ (IFC4x3 Rail)   │  (BNG / WGS84)  │ (CUSUM / EWMA)   │ (Davis / 2x25kV)│
└────────┬────────┴────────┬────────┴────────┬─────────┴────────┬────────┘
         │                 │                 │                  │
         └─────────────────┼─────────────────┴──────────────────┘
                           ▼
              ┌─────────────────────────┐
              │ UNIVERSAL ASSET GRAPH   │
              │ (ISO 19650 Governance)  │
              └────────────┬────────────┘
                           ▼
              ┌─────────────────────────┐
              │ 3D/4D WEBGL WORKSTATION │
              └─────────────────────────┘
```
