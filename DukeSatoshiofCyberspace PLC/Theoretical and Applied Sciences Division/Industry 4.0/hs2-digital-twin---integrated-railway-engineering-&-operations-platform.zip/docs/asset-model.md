# Universal Asset & Digital Twin Data Model

## 1. Digital Twin Metadata Specification
Every entity in the HS2 Digital Twin contains:
- `physical_entity_id`: Physical barcode / tag on infrastructure (e.g. `CVV-P28-RFID`)
- `digital_entity_id`: Global GUID in Common Data Environment (`GUID_3kL98f02aD_P28`)
- `asset_class`: Civil (`viaduct`, `tunnel`, `bridge`, `culvert`), Rail (`slab`, `rail`, `point`), Electrification (`mast`, `cantilever`, `substation`), Signalling (`balise`, `rbc`), Telecoms, Environment.
- `location`: GeoReference with British National Grid (`Easting`, `Northing`), WGS84 (`Lat`, `Lng`), Elevation (`m AOD`), and Route Chainage (`CH 26+850`).
- `lifecycle_state`: `DESIGNED` | `PLANNED` | `UNDER_CONSTRUCTION` | `AS_BUILT` | `COMMISSIONED` | `OPERATIONAL` | `OUT_OF_SERVICE` | `UNDER_MAINTENANCE` | `DECOMMISSIONED`
- `information_status`: BS EN ISO 19650 compliant (`WIP`, `SHARED`, `PUBLISHED`, `ARCHIVED`)
- `confidence`: Calibrated accuracy index (0-100%)
- `validation_status`: `VALIDATED` | `WARNING` | `DEFECT` | `OUTSIDE_ENVELOPE`
- `provenance`: Traceable origin with revision, author, and sha256 checksums.

## 2. Relational Topology Graph
First-class relationships:
- `CONTAINS` / `PART_OF`
- `LOCATED_ON` (e.g. Slab on Viaduct Deck, Mast on Foundation)
- `POWERED_BY` (e.g. Train by Catenary, Catenary by ATFS Substation)
- `CONTROLLED_BY` (e.g. Track section by Radio Block Centre)
- `MONITORED_BY` (e.g. Viaduct Pier by Fiber Optic BOTDA Strain Sensor)
- `DRAINS_TO` (e.g. Track drainage swale to Culvert DRN-042)
- `PROTECTS` (e.g. Noise barrier to Ancient Woodland Habitat)
