# Structural Health Monitoring & Sensor Analytics

## 1. Sensor Instrumentation Framework
Physical sensors deployed across the corridor:
- **Fiber Optic Distributed Acoustic Sensing (DAS / BOTDA)**: Real-time strain & temperature continuous profiles along the Colne Valley Viaduct deck and Chiltern Tunnel segments.
- **Transverse Tiltmeters (mrad)**: Sub-milliradian precision monitoring on deep piled foundations.
- **Piezometers (kPa)**: Embankment pore-water pressure sensors for slope stability.
- **Hydrological Level Gauges (m)**: Attenuation culverts and watercourses.

## 2. Statistical Anomaly Detection (CUSUM & EWMA)
To avoid false positive alarms, explainable statistical methods are applied:
- **Cumulative Sum (CUSUM)**:
  $$S^+_n = \max(0, S^+_{n-1} + z_n - k)$$
  $$S^-_n = \max(0, S^-_{n-1} - z_n - k)$$
  An anomaly is confirmed only when $S^\pm_n \ge h$ (decision boundary $h=4.0$).
- **Zero Phantom AI**: No opaque non-deterministic black-box calls are made for safety-critical asset approvals.
