# Linear Referencing & Coordinate Systems

## 1. Bi-Directional Coordinate Engine
The HS2 Digital Twin supports continuous conversion between:
1. **Chainage Coordinates**: Linear route displacement formatted as `CH km+mmm` (e.g. `CH 26+850`).
2. **British National Grid (BNG)**: Projected Easting ($E$) and Northing ($N$) in meters.
3. **WGS84 Ellipsoidal**: Latitude and Longitude for global geospatial and satellite overlay.
4. **Engineering Elevation**: Altitude above Ordnance Datum ($Z$ in meters AOD).

```
CHAINAGE (CH km+mmm) ◄──────► BNG (Easting, Northing) ◄──────► WGS84 (Lat, Lng)
```

## 2. Dynamic Alignment Equations
- **Horizontal Curve Radius ($R$) & Cant ($h$)**:
  $$\text{Equilibrium Cant } h_{eq} = \frac{11.82 \cdot V^2}{R} \quad (\text{mm})$$
  $$\text{Cant Deficiency } I = h_{eq} - h \quad (\le 130\text{ mm for high-speed operation})$$
- **Vertical Gradient ($\%$)**:
  $$\text{Grade Incline } = \frac{\Delta Z}{\Delta s} \times 100\%$$
