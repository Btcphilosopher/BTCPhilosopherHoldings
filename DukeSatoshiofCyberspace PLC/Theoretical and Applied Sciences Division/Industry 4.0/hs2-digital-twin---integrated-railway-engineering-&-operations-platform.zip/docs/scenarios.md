# What-If Simulation & Downstream Impact Propagation

## 1. Non-Destructive Twin Cloning
Simulations execute on an in-memory clone of the digital twin, ensuring that live operations and asset registries are never mutated by scenario tests:

```
[LIVE DIGITAL TWIN] ──► [IMMUTABLE SNAPSHOT] ──► [SCENARIO CLONE]
                                                        │
                                                        ▼
                                              [INJECT HAZARDS]
                                                        │
                                                        ▼
                                              [PROPAGATE IMPACT]
                                                        │
                                                        ▼
                                              [GENERATE ACTIONS]
```

## 2. Demonstrated Scenarios
1. **Severe Precipitation & River Colne Surcharge (CH 26+850)**:
   - Hazard: 75mm/hr torrential downpour.
   - Asset Effect: Surcharge on Culvert DRN-CULV-042 (94% capacity) + embankment pore water pressure spike.
   - Propagation: ETCS Level 2 Radio Block Centre automatically updates Movement Authorities to enforce an 80 km/h Temporary Speed Restriction.
   - Operations: Timetable adjusted for 4 active train sets with automatic maintenance intervention work order generation.
