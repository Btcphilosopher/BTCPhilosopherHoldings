export type LifecyclePhase =
  | 'REQUIREMENTS'
  | 'CONCEPT'
  | 'VEHICLE_ARCHITECTURE'
  | 'DESIGN'
  | 'SYSTEM_ENGINEERING'
  | 'SIMULATION'
  | 'MANUFACTURING'
  | 'QUALITY'
  | 'TESTING'
  | 'ASSURANCE'
  | 'CERTIFICATION'
  | 'DELIVERY'
  | 'OPERATION'
  | 'MAINTENANCE'
  | 'REFURBISHMENT'
  | 'END_OF_LIFE';

export type CarType = 
  | 'DRIVING_TRAILER'
  | 'MOTOR_CAR'
  | 'TRAILER'
  | 'POWER_CAR'
  | 'TRANSFORMER_CAR'
  | 'BATTERY_CAR'
  | 'HYDROGEN_CAR'
  | 'SERVICE_CAR';

export interface CarConfig {
  id: string;
  carIndex: number;
  type: CarType;
  designation: string; // e.g. "DT1 - Driving Trailer 1"
  length_m: number;
  tareMass_t: number;
  grossMass_t: number;
  axleCount: number;
  isMotorized: boolean;
  motorPower_kW: number;
  hasPantograph: boolean;
  hasTransformer: boolean;
  batteryCapacity_kWh?: number;
  h2Capacity_kg?: number;
  seatsFirstClass: number;
  seatsStandardClass: number;
  accessibleSpaces: number;
  bogieType: 'MOTOR_BOGIE' | 'TRAILER_BOGIE' | 'JACOBS_BOGIE';
  bogieSpacing_m: number;
  wheelbase_m: number;
  hvacCapacity_kW: number;
  doorsPerSide: number;
}

export interface TrainsetConfiguration {
  id: string;
  name: string;
  code: string;
  type: 'HIGH_SPEED_EMU' | 'REGIONAL_BEMU' | 'INTERCITY_H2MU' | 'PUSH_PULL_LOCO';
  targetSpeed_kmh: number;
  maxDesignSpeed_kmh: number;
  catenaryVoltage: '25kV_50Hz' | '15kV_16.7Hz' | '3kV_DC' | '1.5kV_DC' | 'NON_ELECTRIFIED';
  cars: CarConfig[];
  gauge_mm: number;
  loadingGauge: 'UIC_505_1' | 'G1' | 'GA' | 'GB' | 'GC';
  designAmbientTempMin_C: number;
  designAmbientTempMax_C: number;
  aerodynamicCd: number;
  frontalArea_m2: number;
  totalLength_m: number;
  totalTareMass_t: number;
  totalGrossMass_t: number;
  totalTractionPower_kW: number;
  totalPassengerCapacity: number;
  totalAxleCount: number;
  status: 'CONCEPT' | 'DESIGN_FREEZE' | 'PROTOTYPE_ASSEMBLY' | 'TYPE_TESTING' | 'CERTIFIED' | 'COMMISSIONED';
}

export interface ComponentNode {
  id: string;
  code: string;
  name: string;
  system: string;
  subsystem: string;
  carIndex?: number;
  parentCode?: string;
  supplier: string;
  material: string;
  materialBatch: string;
  mass_kg: number;
  serialNumber: string;
  weldRef?: string;
  inspectionRef?: string;
  testRef?: string;
  requirementRef: string;
  cadModelRef: string;
  softwareVersion?: string;
  silRating?: 'SIL_0' | 'SIL_1' | 'SIL_2' | 'SIL_3' | 'SIL_4';
  healthStatus: 'OPTIMAL' | 'DEGRADED' | 'WARNING' | 'CRITICAL';
  vibrationRms_mms2?: number;
  operatingHours: number;
  mtbf_hours: number;
  mttr_hours: number;
}

export interface EngineeringRequirement {
  id: string;
  title: string;
  description: string;
  source: 'TSI_LOC_PAS' | 'EN_14363' | 'EN_15227' | 'EN_50126' | 'EN_50128' | 'CUSTOMER_SPEC' | 'OPERATOR_SLA';
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  verificationMethod: 'ANALYSIS' | 'INSPECTION' | 'TEST' | 'SIMULATION' | 'CERTIFICATION_REVIEW';
  status: 'VERIFIED' | 'UNDER_REVIEW' | 'EVIDENCE_REQUIRED' | 'NON_COMPLIANT';
  owner: string;
  affectedSystems: string[];
  evidenceDoc: string;
  revision: string;
  linkedTests: string[];
  linkedSimulations: string[];
}

export interface SimulationResult {
  id: string;
  domain: 'AERODYNAMICS' | 'VEHICLE_DYNAMICS' | 'TRACTION' | 'BRAKING' | 'THERMAL' | 'ENERGY' | 'STRUCTURAL';
  title: string;
  runDate: string;
  modelCode: string;
  modelVersion: string;
  status: 'CONVERGED' | 'WARNING' | 'FAILED';
  keyMetrics: Record<string, number | string>;
  dataPoints: { x: number; y1: number; y2?: number; y3?: number; label?: string }[];
  summary: string;
  confidencePct: number;
}

export interface ProductionStation {
  id: string;
  hall: string;
  stationNumber: number;
  name: string;
  taktTime_hrs: number;
  activeCycleTime_hrs: number;
  activeUnit: string;
  assignedOperators: number;
  assignedRobots: number;
  robotState: 'OPERATING' | 'CALIBRATING' | 'IDLE' | 'MAINTENANCE';
  wipQueueCount: number;
  status: 'OPTIMAL' | 'BOTTLENECK' | 'REWORK_HOLD' | 'STARVED';
  qualityFirstPassYield_pct: number;
}

export interface WeldRecord {
  id: string;
  carbodyId: string;
  location: string;
  process: 'ROBOTIC_LASER' | 'MIG_MAG' | 'TIG_MANUAL' | 'FRICTION_STIR';
  material: string;
  materialBatch: string;
  operatorOrRobotId: string;
  ndtMethod: 'ULTRASONIC_PAUT' | 'RADIOGRAPHIC_XRAY' | 'MAGNETIC_PARTICLE' | 'VISUAL_EN_ISO_5817_B';
  ndtResult: 'PASS' | 'ACCEPTABLE_LEVEL_B' | 'REWORK_REQUIRED';
  timestamp: string;
  inspectorId: string;
}

export interface TelemetrySnapshot {
  trainsetId: string;
  trainName: string;
  timestamp: string;
  speed_kmh: number;
  targetSpeed_kmh: number;
  locationKm: number;
  lineVoltage_kV: number;
  catenaryCurrent_A: number;
  tractiveEffort_kN: number;
  bogie1BearingTemp_C: number;
  bogie1Vibration_mms2: number;
  bogie2Vibration_mms2: number;
  wheelsetLateralAccel_ms2: number;
  ambientTemp_C: number;
  cabinTemp_C: number;
  doorCyclesTotal: number;
  brakeAirPressure_bar: number;
  pantographContactForce_N: number;
  batterySoc_pct?: number;
  h2Pressure_bar?: number;
  tcmsAlarmsCount: number;
  status: 'IN_SERVICE' | 'MAINTENANCE_REQUIRED' | 'TESTING' | 'DEPOT';
}

export interface QualityNCR {
  id: string;
  componentCode: string;
  description: string;
  severity: 'MINOR' | 'MAJOR' | 'CRITICAL';
  stage: 'INCOMING_SUPPLY' | 'WELDING' | 'PAINT' | 'ASSEMBLY' | 'COMMISSIONING';
  rootCause: string;
  containmentAction: string;
  correctiveAction: string;
  status: 'OPEN' | '8D_INVESTIGATION' | 'CONTAINED' | 'CLOSED';
  costImpact_EUR: number;
  reportedDate: string;
}

export interface SafetyHazard {
  id: string;
  hazardTitle: string;
  consequence: string;
  initialRisk: 'INTOLERABLE' | 'UNDESIRABLE' | 'TOLERABLE' | 'NEGLIGIBLE';
  mitigationRequirement: string;
  silLevel: 'SIL_4' | 'SIL_3' | 'SIL_2' | 'SIL_1';
  verificationEvidence: string;
  residualRisk: 'TOLERABLE' | 'BROADLY_ACCEPTABLE';
  status: 'CLOSED_VERIFIED' | 'OPEN_AUDIT';
}

export interface TSIStandard {
  code: string;
  name: string;
  version: string;
  jurisdiction: 'ERA_EU' | 'RSSB_UK' | 'FRA_US' | 'INTERNATIONAL';
  complianceStatus: 'VERIFIED' | 'UNDER_REVIEW' | 'NOT_APPLICABLE' | 'EVIDENCE_REQUIRED';
  auditorOrg: string;
  certificateRef: string;
}
