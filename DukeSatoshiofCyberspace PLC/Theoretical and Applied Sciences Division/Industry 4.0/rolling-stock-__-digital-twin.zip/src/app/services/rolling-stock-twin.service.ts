import { Injectable, signal, computed } from '@angular/core';
import {
  CarConfig,
  CarType,
  ComponentNode,
  EngineeringRequirement,
  ProductionStation,
  WeldRecord,
  TelemetrySnapshot,
  QualityNCR,
  SafetyHazard,
  TSIStandard
} from '../models/rolling-stock.model';

@Injectable({
  providedIn: 'root'
})
export class RollingStockTwinService {
  // Active Navigation & View State
  readonly activeTab = signal<string>('command_centre');
  readonly selectedCarIndex = signal<number>(0);
  readonly selectedComponentCode = signal<string>('TRC-00421');
  readonly guidedStepIndex = signal<number>(0);
  readonly isGuidedTourActive = signal<boolean>(false);
  readonly isLiveTelemetryActive = signal<boolean>(true);
  readonly injectedAnomaly = signal<boolean>(false);
  readonly showAiAssistant = signal<boolean>(false);
  readonly showTerminal = signal<boolean>(false);
  readonly showReport = signal<boolean>(false);

  // Reference Program Metadata
  readonly programmeName = signal<string>('RSX-320 Next-Gen High-Speed EMU');
  readonly designFreezePct = signal<number>(82);
  readonly requirementsTotal = signal<number>(1482);
  readonly requirementsVerified = signal<number>(1197);
  readonly openECRs = signal<number>(37);
  readonly simulationRuns = signal<number>(8421);
  readonly manufacturingReadiness = signal<number>(76);
  readonly certificationEvidencePct = signal<number>(68);
  readonly prototypeStatus = signal<string>('P1 — ASSEMBLY');

  // Parametric Dimensions for Reference Vehicle
  readonly carbodyLength_m = signal<number>(25.0);
  readonly carbodyWidth_m = signal<number>(2.92);
  readonly carbodyHeight_m = signal<number>(3.88);
  readonly bogieCentres_m = signal<number>(17.5);
  readonly wheelbase_m = signal<number>(2.5);
  readonly floorHeight_m = signal<number>(1.25);
  readonly noseLength_m = signal<number>(5.8);
  readonly noseCurvatureFactor = signal<number>(0.84);
  readonly aeroCd = signal<number>(0.142);
  readonly frontalArea_m2 = signal<number>(10.8);
  readonly targetMaxSpeed_kmh = signal<number>(320);

  // Active Formation Cars
  readonly cars = signal<CarConfig[]>([
    {
      id: 'car-1',
      carIndex: 1,
      type: 'DRIVING_TRAILER',
      designation: 'DT1 — End Driving Trailer (Cab A)',
      length_m: 25.8,
      tareMass_t: 48.5,
      grossMass_t: 58.2,
      axleCount: 4,
      isMotorized: false,
      motorPower_kW: 0,
      hasPantograph: false,
      hasTransformer: false,
      seatsFirstClass: 42,
      seatsStandardClass: 0,
      accessibleSpaces: 2,
      bogieType: 'TRAILER_BOGIE',
      bogieSpacing_m: 17.5,
      wheelbase_m: 2.5,
      hvacCapacity_kW: 36,
      doorsPerSide: 1
    },
    {
      id: 'car-2',
      carIndex: 2,
      type: 'MOTOR_CAR',
      designation: 'M1 — Motor Car (1st Class)',
      length_m: 24.8,
      tareMass_t: 54.8,
      grossMass_t: 66.4,
      axleCount: 4,
      isMotorized: true,
      motorPower_kW: 2000,
      hasPantograph: true,
      hasTransformer: true,
      seatsFirstClass: 54,
      seatsStandardClass: 0,
      accessibleSpaces: 0,
      bogieType: 'MOTOR_BOGIE',
      bogieSpacing_m: 17.5,
      wheelbase_m: 2.5,
      hvacCapacity_kW: 38,
      doorsPerSide: 2
    },
    {
      id: 'car-3',
      carIndex: 3,
      type: 'MOTOR_CAR',
      designation: 'M2 — Motor Car (Standard Class)',
      length_m: 24.8,
      tareMass_t: 53.2,
      grossMass_t: 66.8,
      axleCount: 4,
      isMotorized: true,
      motorPower_kW: 2000,
      hasPantograph: false,
      hasTransformer: false,
      seatsFirstClass: 0,
      seatsStandardClass: 84,
      accessibleSpaces: 0,
      bogieType: 'MOTOR_BOGIE',
      bogieSpacing_m: 17.5,
      wheelbase_m: 2.5,
      hvacCapacity_kW: 42,
      doorsPerSide: 2
    },
    {
      id: 'car-4',
      carIndex: 4,
      type: 'SERVICE_CAR',
      designation: 'S1 — Bistro / Restaurant Car',
      length_m: 24.8,
      tareMass_t: 49.0,
      grossMass_t: 58.5,
      axleCount: 4,
      isMotorized: false,
      motorPower_kW: 0,
      hasPantograph: false,
      hasTransformer: false,
      seatsFirstClass: 16,
      seatsStandardClass: 18,
      accessibleSpaces: 1,
      bogieType: 'TRAILER_BOGIE',
      bogieSpacing_m: 17.5,
      wheelbase_m: 2.5,
      hvacCapacity_kW: 45,
      doorsPerSide: 2
    },
    {
      id: 'car-5',
      carIndex: 5,
      type: 'TRAILER',
      designation: 'T1 — Trailer Car (Standard Class)',
      length_m: 24.8,
      tareMass_t: 44.5,
      grossMass_t: 58.8,
      axleCount: 4,
      isMotorized: false,
      motorPower_kW: 0,
      hasPantograph: false,
      hasTransformer: false,
      seatsFirstClass: 0,
      seatsStandardClass: 88,
      accessibleSpaces: 2,
      bogieType: 'TRAILER_BOGIE',
      bogieSpacing_m: 17.5,
      wheelbase_m: 2.5,
      hvacCapacity_kW: 40,
      doorsPerSide: 2
    },
    {
      id: 'car-6',
      carIndex: 6,
      type: 'MOTOR_CAR',
      designation: 'M3 — Motor Car (Standard Class)',
      length_m: 24.8,
      tareMass_t: 53.2,
      grossMass_t: 66.8,
      axleCount: 4,
      isMotorized: true,
      motorPower_kW: 2000,
      hasPantograph: false,
      hasTransformer: false,
      seatsFirstClass: 0,
      seatsStandardClass: 84,
      accessibleSpaces: 0,
      bogieType: 'MOTOR_BOGIE',
      bogieSpacing_m: 17.5,
      wheelbase_m: 2.5,
      hvacCapacity_kW: 42,
      doorsPerSide: 2
    },
    {
      id: 'car-7',
      carIndex: 7,
      type: 'MOTOR_CAR',
      designation: 'M4 — Motor Car with Pantograph 2',
      length_m: 24.8,
      tareMass_t: 54.8,
      grossMass_t: 66.4,
      axleCount: 4,
      isMotorized: true,
      motorPower_kW: 2000,
      hasPantograph: true,
      hasTransformer: true,
      seatsFirstClass: 0,
      seatsStandardClass: 80,
      accessibleSpaces: 0,
      bogieType: 'MOTOR_BOGIE',
      bogieSpacing_m: 17.5,
      wheelbase_m: 2.5,
      hvacCapacity_kW: 38,
      doorsPerSide: 2
    },
    {
      id: 'car-8',
      carIndex: 8,
      type: 'DRIVING_TRAILER',
      designation: 'DT2 — End Driving Trailer (Cab B)',
      length_m: 25.8,
      tareMass_t: 48.5,
      grossMass_t: 58.2,
      axleCount: 4,
      isMotorized: false,
      motorPower_kW: 0,
      hasPantograph: false,
      hasTransformer: false,
      seatsFirstClass: 0,
      seatsStandardClass: 68,
      accessibleSpaces: 2,
      bogieType: 'TRAILER_BOGIE',
      bogieSpacing_m: 17.5,
      wheelbase_m: 2.5,
      hvacCapacity_kW: 36,
      doorsPerSide: 1
    }
  ]);

  // Derived Trainset Metrics
  readonly totalLength_m = computed(() => {
    return this.cars().reduce((acc, c) => acc + c.length_m, 0);
  });

  readonly totalTareMass_t = computed(() => {
    return Number((this.cars().reduce((acc, c) => acc + c.tareMass_t, 0)).toFixed(1));
  });

  readonly totalGrossMass_t = computed(() => {
    return Number((this.cars().reduce((acc, c) => acc + c.grossMass_t, 0)).toFixed(1));
  });

  readonly totalTractionPower_MW = computed(() => {
    const totalKW = this.cars().reduce((acc, c) => acc + (c.isMotorized ? c.motorPower_kW : 0), 0);
    return Number((totalKW / 1000).toFixed(2));
  });

  readonly totalSeats = computed(() => {
    return this.cars().reduce((acc, c) => acc + c.seatsFirstClass + c.seatsStandardClass, 0);
  });

  readonly totalAxles = computed(() => {
    return this.cars().reduce((acc, c) => acc + c.axleCount, 0);
  });

  readonly totalPantographs = computed(() => {
    return this.cars().filter(c => c.hasPantograph).length;
  });

  readonly maxAxleLoad_t = computed(() => {
    const gross = this.totalGrossMass_t();
    const axles = this.totalAxles();
    return Number((gross / axles).toFixed(2)); // ~13.6 t/axle (Well below TSI 17.0t limit)
  });

  // Power to Weight Ratio (kW/tonne)
  readonly powerToWeight_kWt = computed(() => {
    const kw = this.totalTractionPower_MW() * 1000;
    const tare = this.totalTareMass_t();
    return Number((kw / tare).toFixed(1));
  });

  // 0-320 km/h acceleration time estimate (seconds)
  readonly accelerationTimeTo320_s = computed(() => {
    const p = this.totalTractionPower_MW();
    const m = this.totalGrossMass_t();
    // Simplified kinematic integral estimation with aero resistance
    const time = 238 * (8.0 / (p || 1)) * (m / 480);
    return Number(time.toFixed(1));
  });

  // Braking distance from 320 km/h (metres)
  readonly emergencyBrakingDistance_m = computed(() => {
    const v = this.targetMaxSpeed_kmh() / 3.6; // 88.89 m/s
    const a = 1.35; // deceleration m/s2
    const dist = (v * v) / (2 * a) + (v * 0.8); // reaction + stopping
    return Math.round(dist);
  });

  // Full BOM Component Tree
  readonly components = signal<ComponentNode[]>([
    {
      id: 'cmp-01',
      code: 'TRC-00421',
      name: 'SiC High-Power 4-Quadrant Traction Converter',
      system: 'Traction',
      subsystem: 'Power Electronics',
      carIndex: 2,
      supplier: 'ABB Rail Power Systems (Baden)',
      material: 'Silicon Carbide (SiC) MOSFET / Copper busbars',
      materialBatch: 'SIC-WAFER-2026-991B',
      mass_kg: 840,
      serialNumber: 'SN-TRC-2026-0814',
      weldRef: 'W-19382',
      inspectionRef: 'I-88291',
      testRef: 'T-3818',
      requirementRef: 'REQ-TRACTION-001',
      cadModelRef: 'CAD-TRC-REV4.step',
      softwareVersion: 'FW-TRC-v6.1.4',
      silRating: 'SIL_2',
      healthStatus: 'OPTIMAL',
      vibrationRms_mms2: 1.4,
      operatingHours: 420,
      mtbf_hours: 120000,
      mttr_hours: 2.5
    },
    {
      id: 'cmp-02',
      code: 'MOT-600',
      name: 'Permanent Magnet Synchronous Traction Motor (1000 kW)',
      system: 'Traction',
      subsystem: 'Traction Motors',
      carIndex: 2,
      supplier: 'Traktionssysteme Austria (TSA)',
      material: 'NdFeB Magnets / Vacoflux Electrical Steel',
      materialBatch: 'MAG-TSA-4482',
      mass_kg: 1450,
      serialNumber: 'SN-MOT-600-019',
      requirementRef: 'REQ-TRACTION-001',
      cadModelRef: 'CAD-MOT-REV6.step',
      silRating: 'SIL_2',
      healthStatus: 'OPTIMAL',
      vibrationRms_mms2: 2.1,
      operatingHours: 420,
      mtbf_hours: 250000,
      mttr_hours: 4.0
    },
    {
      id: 'cmp-03',
      code: 'BOG-201',
      name: 'High-Speed Motor Bogie Frame & Running Gear',
      system: 'Bogies & Running Gear',
      subsystem: 'Bogie Frame',
      carIndex: 2,
      supplier: 'Alstom Transport Bogie Competence Centre (Siegen)',
      material: 'High-Strength Structural Steel S355J2W / S460N',
      materialBatch: 'STL-S355-BATCH-774',
      mass_kg: 3200,
      serialNumber: 'SN-BOG-2026-004',
      weldRef: 'W-09822',
      inspectionRef: 'I-90114',
      testRef: 'T-2041',
      requirementRef: 'REQ-DYNAMICS-002',
      cadModelRef: 'CAD-BOGIE-HS320-v8.step',
      healthStatus: 'OPTIMAL',
      vibrationRms_mms2: 3.2,
      operatingHours: 420,
      mtbf_hours: 500000,
      mttr_hours: 8.0
    },
    {
      id: 'cmp-04',
      code: 'WHL-920',
      name: 'Forged Monobloc High-Speed Wheelset (920mm Dia)',
      system: 'Bogies & Running Gear',
      subsystem: 'Wheelsets & Axleboxes',
      carIndex: 2,
      supplier: 'Lucchini RS (Lovere)',
      material: 'Micro-alloyed Superlos R8T Forged Steel',
      materialBatch: 'LUC-R8T-90921',
      mass_kg: 1880,
      serialNumber: 'SN-WHL-920-0082',
      inspectionRef: 'I-81203',
      testRef: 'T-4402',
      requirementRef: 'REQ-DYNAMICS-003',
      cadModelRef: 'CAD-WHEEL-R8T.step',
      healthStatus: 'OPTIMAL',
      vibrationRms_mms2: 2.8,
      operatingHours: 420,
      mtbf_hours: 1500000,
      mttr_hours: 6.0
    },
    {
      id: 'cmp-05',
      code: 'TCMS-CCU-01',
      name: 'Central Control Unit (CCU) Dual-Redundant TCMS',
      system: 'TCMS',
      subsystem: 'Vehicle Control Architecture',
      carIndex: 1,
      supplier: 'Selectron Systems AG / Siemens Mobility',
      material: 'Industrial Grade SBC / Conformal Coated IP67 Enclosure',
      materialBatch: 'PCB-SEL-9901',
      mass_kg: 24,
      serialNumber: 'SN-CCU-320-001',
      softwareVersion: 'TCMS-OS-v4.8.2-RTOS',
      silRating: 'SIL_3',
      requirementRef: 'REQ-TCMS-001',
      cadModelRef: 'CAD-TCMS-RACK.step',
      healthStatus: 'OPTIMAL',
      operatingHours: 420,
      mtbf_hours: 350000,
      mttr_hours: 0.5
    },
    {
      id: 'cmp-06',
      code: 'PANT-500',
      name: 'Active Aerodynamic High-Speed Pantograph (25kV 50Hz)',
      system: 'Traction',
      subsystem: 'Current Collection',
      carIndex: 2,
      supplier: 'Schunk Carbon Technology / Brecknell Willis',
      material: 'Carbon Current Collector Strips / High-Tensile Steel Arms',
      materialBatch: 'CARB-SCH-2026-302',
      mass_kg: 165,
      serialNumber: 'SN-PANT-HS320-02',
      requirementRef: 'REQ-TRACTION-004',
      cadModelRef: 'CAD-PANT-ACTIVE.step',
      healthStatus: 'OPTIMAL',
      vibrationRms_mms2: 1.8,
      operatingHours: 420,
      mtbf_hours: 180000,
      mttr_hours: 1.5
    },
    {
      id: 'cmp-07',
      code: 'BRK-EBCU-01',
      name: 'Electronic Brake Control Unit (EBCU) Blending Controller',
      system: 'Braking',
      subsystem: 'Brake Control',
      carIndex: 1,
      supplier: 'Knorr-Bremse Rail Vehicle Systems (Munich)',
      material: 'Aluminium Extruded Rack / Mil-Spec Avionics Grade PCBs',
      materialBatch: 'KB-EBCU-8821',
      mass_kg: 38,
      serialNumber: 'SN-KB-EBCU-0091',
      softwareVersion: 'EBCU-BLND-v3.4.1',
      silRating: 'SIL_4',
      requirementRef: 'REQ-BRAKE-001',
      cadModelRef: 'CAD-KB-EBCU.step',
      healthStatus: 'OPTIMAL',
      operatingHours: 420,
      mtbf_hours: 400000,
      mttr_hours: 1.0
    },
    {
      id: 'cmp-08',
      code: 'CB-STR-01',
      name: 'Lightweight Large-Profile Extruded Aluminium Carbody Shell',
      system: 'Structures',
      subsystem: 'Carbody Structural Frame',
      carIndex: 1,
      supplier: 'Northfield Rail Systems (Extrusion Plant A)',
      material: 'EN AW-6005A-T6 Aluminium Alloy',
      materialBatch: 'AL-83921',
      mass_kg: 7850,
      serialNumber: 'CB-001-ALPHA',
      weldRef: 'W-19382',
      inspectionRef: 'I-88291',
      testRef: 'T-3818',
      requirementRef: 'REQ-STRUCT-001',
      cadModelRef: 'CAD-CARBODY-SHELL-25M.step',
      healthStatus: 'OPTIMAL',
      operatingHours: 420,
      mtbf_hours: 3000000,
      mttr_hours: 48.0
    },
    {
      id: 'cmp-09',
      code: 'DOR-SYN-01',
      name: 'Acoustic Flush Plug Door System (EN 14752 Certified)',
      system: 'Doors',
      subsystem: 'Passenger Access',
      carIndex: 2,
      supplier: 'IFE Doors (Knorr-Bremse Group)',
      material: 'Aluminium Sandwich Panel / Brushless DC Servomotor',
      materialBatch: 'IFE-PNL-992',
      mass_kg: 185,
      serialNumber: 'SN-DOR-002-L1',
      softwareVersion: 'DCU-v2.3.1',
      silRating: 'SIL_2',
      requirementRef: 'REQ-DOOR-001',
      cadModelRef: 'CAD-DOOR-PLUG-1400.step',
      healthStatus: 'OPTIMAL',
      operatingHours: 420,
      mtbf_hours: 95000,
      mttr_hours: 1.2
    },
    {
      id: 'cmp-10',
      code: 'HVAC-COP-01',
      name: 'Roof-Mounted Heat Pump HVAC Unit (R290 Eco-Refrigerant)',
      system: 'HVAC',
      subsystem: 'Climate Control',
      carIndex: 2,
      supplier: 'Faiveley Transport / Wabtec',
      material: 'Stainless Steel AISI 304 / Microchannel Aluminium Condensers',
      materialBatch: 'WAB-HVAC-3301',
      mass_kg: 890,
      serialNumber: 'SN-HVAC-38KW-04',
      softwareVersion: 'HVAC-CLIM-v1.9.0',
      requirementRef: 'REQ-HVAC-001',
      cadModelRef: 'CAD-HVAC-ROOF-38.step',
      healthStatus: 'OPTIMAL',
      operatingHours: 420,
      mtbf_hours: 75000,
      mttr_hours: 2.0
    }
  ]);

  // Requirements Database
  readonly requirements = signal<EngineeringRequirement[]>([
    {
      id: 'REQ-TRACTION-001',
      title: 'Maximum Design Speed Acceleration & Tractive Power',
      description: 'The vehicle shall achieve 0 to 320 km/h in ≤ 240 seconds on level tangent track under tare+payload (AW2) at nominal 25 kV AC catenary supply.',
      source: 'TSI_LOC_PAS',
      priority: 'CRITICAL',
      verificationMethod: 'SIMULATION',
      status: 'VERIFIED',
      owner: 'Dr. Klaus Richter (Chief Traction Engineer)',
      affectedSystems: ['Traction', 'TCMS', 'High Voltage', 'Pantograph'],
      evidenceDoc: 'TRAC-SIM-320-REPORT-REV3.pdf',
      revision: 'E',
      linkedTests: ['TEST-TRAC-DYNAMIC-01', 'TEST-TRAC-BENCH-04'],
      linkedSimulations: ['SIM-TRAC-ACCEL-320']
    },
    {
      id: 'REQ-DYNAMICS-002',
      title: 'High-Speed Running Safety and Derailment Coefficient (Y/Q ≤ 0.8)',
      description: 'Under track geometry conditions according to EN 14363, the vehicle shall maintain Prud\'homme lateral force below limit (H_lim = 10 + 2P/3 kN) and derailment coefficient Y/Q < 0.8 at 352 km/h (110% design speed).',
      source: 'EN_14363',
      priority: 'CRITICAL',
      verificationMethod: 'SIMULATION',
      status: 'VERIFIED',
      owner: 'Sarah Jenkins (Vehicle Dynamics Lead)',
      affectedSystems: ['Bogies & Running Gear', 'Structures', 'Suspension'],
      evidenceDoc: 'DYN-MBD-EN14363-REPORT.pdf',
      revision: 'D',
      linkedTests: ['TEST-TRACK-TESTING-HS1-01'],
      linkedSimulations: ['SIM-DYN-CURVE-3000M']
    },
    {
      id: 'REQ-BRAKE-001',
      title: 'Emergency Braking Stopping Distance from 320 km/h',
      description: 'The trainset shall achieve full stop from 320 km/h in ≤ 3,050 metres under degraded rail-wheel adhesion (f=0.08) using blended electrodynamic and pneumatic friction brakes.',
      source: 'TSI_LOC_PAS',
      priority: 'CRITICAL',
      verificationMethod: 'TEST',
      status: 'VERIFIED',
      owner: 'Marco Rossi (Braking Systems Principal)',
      affectedSystems: ['Braking', 'Bogies', 'Traction', 'TCMS'],
      evidenceDoc: 'BRK-CERT-EVIDENCE-320KMH.pdf',
      revision: 'C',
      linkedTests: ['TEST-BRK-EMERGENCY-01'],
      linkedSimulations: ['SIM-BRK-STOPPING-PROFILE']
    },
    {
      id: 'REQ-AERO-001',
      title: 'Aerodynamic Drag Coefficient & Crosswind Overturning Stability',
      description: 'The overall aerodynamic drag coefficient Cx*A shall not exceed 1.54 m² at 320 km/h in free air, and vehicle characteristic wind curve shall conform to EN 14067-6 at 140 km/h gust.',
      source: 'TSI_LOC_PAS',
      priority: 'HIGH',
      verificationMethod: 'SIMULATION',
      status: 'VERIFIED',
      owner: 'Dr. Émilie Laurent (Aerodynamics Lead)',
      affectedSystems: ['Aerodynamics', 'Carbody Nose', 'Pantograph Fairings'],
      evidenceDoc: 'CFD-AERO-RSX320-SUMMARY.pdf',
      revision: 'B',
      linkedTests: ['TEST-WIND-TUNNEL-SCALE-1-10'],
      linkedSimulations: ['SIM-AERO-DRAG-TUNNEL']
    },
    {
      id: 'REQ-STRUCT-001',
      title: 'Carbody Structural Crashworthiness & 1500 kN Compressive Load',
      description: 'The aluminium bodyshell shall withstand static longitudinal compressive load of 1500 kN at coupler level without permanent deformation, meeting EN 12663-1 Category P-I and EN 15227 crash scenarios.',
      source: 'EN_15227',
      priority: 'CRITICAL',
      verificationMethod: 'ANALYSIS',
      status: 'VERIFIED',
      owner: 'Heinrich Weber (Structures Group)',
      affectedSystems: ['Structures', 'Crash Absorbers', 'Underframe'],
      evidenceDoc: 'FEA-CRASH-EN15227-DOSSIER.pdf',
      revision: 'F',
      linkedTests: ['TEST-STATIC-LOAD-1500KN'],
      linkedSimulations: ['SIM-STRUCT-CRASH-DEFORMATION']
    },
    {
      id: 'REQ-RAMS-001',
      title: 'Train Availability Target (Ao ≥ 99.4%) and MTBSF ≥ 120,000 km',
      description: 'The fleet operational reliability shall demonstrate Mean Time Between Service Failures (MTBSF) exceeding 120,000 km with overall fleet operational availability Ao ≥ 99.4% per EN 50126.',
      source: 'EN_50126',
      priority: 'HIGH',
      verificationMethod: 'ANALYSIS',
      status: 'VERIFIED',
      owner: 'Elena Morales (RAMS Manager)',
      affectedSystems: ['All Systems', 'TCMS', 'Traction', 'Doors', 'Braking'],
      evidenceDoc: 'RAMS-CALC-RSX320-REV2.pdf',
      revision: 'C',
      linkedTests: ['TEST-RELIABILITY-DEPOT-MONITORING'],
      linkedSimulations: ['SIM-RAMS-MONTE-CARLO']
    },
    {
      id: 'REQ-CYBER-001',
      title: 'Cybersecurity Network Segmentation & Conformance to TS 50701 / IEC 62443',
      description: 'Onboard Ethernet train backbone (ETB) and vital subsystem networks (TCMS/Brakes/Traction) shall be physically and cryptographically isolated from passenger Wi-Fi and external cellular portals with hardware-enforced firewalls.',
      source: 'EN_50128',
      priority: 'CRITICAL',
      verificationMethod: 'INSPECTION',
      status: 'VERIFIED',
      owner: 'Liam O\'Connor (Security Architect)',
      affectedSystems: ['TCMS', 'Communications', 'Passenger Infotainment'],
      evidenceDoc: 'CYBER-TS50701-AUDIT-CERT.pdf',
      revision: 'B',
      linkedTests: ['TEST-PEN-TEST-TCMS-01'],
      linkedSimulations: []
    }
  ]);

  // Production Stations at Northfield Rail Systems
  readonly productionStations = signal<ProductionStation[]>([
    {
      id: 'STN-01',
      hall: 'Hall 1: Extrusion & Machining',
      stationNumber: 1,
      name: 'Aluminium Extrusion CNC Milling & Beveling',
      taktTime_hrs: 18,
      activeCycleTime_hrs: 16.4,
      activeUnit: 'RSX-320-002 Carbody Floor Structure',
      assignedOperators: 4,
      assignedRobots: 2,
      robotState: 'OPERATING',
      wipQueueCount: 2,
      status: 'OPTIMAL',
      qualityFirstPassYield_pct: 98.6
    },
    {
      id: 'STN-02',
      hall: 'Hall 2: Automated Carbody Welding',
      stationNumber: 2,
      name: 'Robotic Laser-Hybrid Long-Seam Welding (Floor-to-Sidewall)',
      taktTime_hrs: 18,
      activeCycleTime_hrs: 17.8,
      activeUnit: 'RSX-320-002 Car 1 Shell (Weld W-19382)',
      assignedOperators: 2,
      assignedRobots: 4,
      robotState: 'OPERATING',
      wipQueueCount: 1,
      status: 'OPTIMAL',
      qualityFirstPassYield_pct: 96.2
    },
    {
      id: 'STN-03',
      hall: 'Hall 2: Automated Carbody Welding',
      stationNumber: 3,
      name: 'NDT Ultrasonic & Phased-Array Weld Inspection Cell',
      taktTime_hrs: 18,
      activeCycleTime_hrs: 14.5,
      activeUnit: 'RSX-320-002 Car 1 (Inspection I-88291)',
      assignedOperators: 3,
      assignedRobots: 1,
      robotState: 'OPERATING',
      wipQueueCount: 0,
      status: 'OPTIMAL',
      qualityFirstPassYield_pct: 99.1
    },
    {
      id: 'STN-04',
      hall: 'Hall 3: Paint & Surface Treatment',
      stationNumber: 4,
      name: 'Automated Electrostatic Primer & Topcoat Robotics',
      taktTime_hrs: 18,
      activeCycleTime_hrs: 18.2,
      activeUnit: 'RSX-320-001 Car 4 (Bistro Livery)',
      assignedOperators: 2,
      assignedRobots: 2,
      robotState: 'OPERATING',
      wipQueueCount: 1,
      status: 'OPTIMAL',
      qualityFirstPassYield_pct: 94.8
    },
    {
      id: 'STN-05',
      hall: 'Hall 4: Bogie Assembly & Testing',
      stationNumber: 5,
      name: 'Motor Bogie Integration & Dynamic Balancing Rig',
      taktTime_hrs: 12,
      activeCycleTime_hrs: 11.2,
      activeUnit: 'Bogie Frame BOG-201 #004 (Lucchini Wheelsets)',
      assignedOperators: 6,
      assignedRobots: 1,
      robotState: 'OPERATING',
      wipQueueCount: 3,
      status: 'OPTIMAL',
      qualityFirstPassYield_pct: 97.4
    },
    {
      id: 'STN-06',
      hall: 'Hall 5: Underframe & Roof Equipment',
      stationNumber: 6,
      name: 'Traction Converter & Transformer Installation',
      taktTime_hrs: 18,
      activeCycleTime_hrs: 19.5,
      activeUnit: 'RSX-320-001 Car 2 (Converter TRC-00421)',
      assignedOperators: 5,
      assignedRobots: 0,
      robotState: 'IDLE',
      wipQueueCount: 2,
      status: 'BOTTLENECK',
      qualityFirstPassYield_pct: 92.0
    },
    {
      id: 'STN-07',
      hall: 'Hall 6: Interior & Cab Fit-Out',
      stationNumber: 7,
      name: 'Driving Cab Console, Windscreen & TCMS Racks',
      taktTime_hrs: 18,
      activeCycleTime_hrs: 17.0,
      activeUnit: 'RSX-320-001 Car 1 Driving Cab A',
      assignedOperators: 8,
      assignedRobots: 0,
      robotState: 'IDLE',
      wipQueueCount: 1,
      status: 'OPTIMAL',
      qualityFirstPassYield_pct: 95.5
    },
    {
      id: 'STN-08',
      hall: 'Hall 7: Final Assembly & Commissioning',
      stationNumber: 8,
      name: '8-Car Trainset Mechanical & Electrical Gangway Marriage',
      taktTime_hrs: 24,
      activeCycleTime_hrs: 22.8,
      activeUnit: 'RSX-320-001 Full 8-Car Trainset Formation',
      assignedOperators: 12,
      assignedRobots: 0,
      robotState: 'IDLE',
      wipQueueCount: 1,
      status: 'OPTIMAL',
      qualityFirstPassYield_pct: 96.8
    }
  ]);

  // Weld Digital Twin Records
  readonly weldRecords = signal<WeldRecord[]>([
    {
      id: 'W-19382',
      carbodyId: 'CB001-C2',
      location: 'Underframe Traction Converter Mounting Beam (Car 2)',
      process: 'ROBOTIC_LASER',
      material: 'EN AW-6005A-T6 Extrusion',
      materialBatch: 'AL-83921',
      operatorOrRobotId: 'KUKA-LSR-CELL-02',
      ndtMethod: 'ULTRASONIC_PAUT',
      ndtResult: 'PASS',
      timestamp: '2026-08-14 09:42:15',
      inspectorId: 'INSP-4902 (TÜV SÜD)'
    },
    {
      id: 'W-09822',
      carbodyId: 'CB001-BOGIE-04',
      location: 'Primary Suspension Spring Seat Bracket Welds',
      process: 'MIG_MAG',
      material: 'Structural Steel S355J2W',
      materialBatch: 'STL-S355-BATCH-774',
      operatorOrRobotId: 'ABB-ROBOT-BOG-01',
      ndtMethod: 'RADIOGRAPHIC_XRAY',
      ndtResult: 'PASS',
      timestamp: '2026-08-12 14:15:30',
      inspectorId: 'INSP-1108'
    }
  ]);

  // Active Real-Time Telemetry Snapshot (Trainset RSX-320-001 in live service)
  readonly telemetry = signal<TelemetrySnapshot>({
    trainsetId: 'RSX-320-001',
    trainName: 'RSX-320 Trainset 001 (Eurostar Paris-London High-Speed Path)',
    timestamp: new Date().toISOString(),
    speed_kmh: 318.4,
    targetSpeed_kmh: 320.0,
    locationKm: 142.8,
    lineVoltage_kV: 25.4,
    catenaryCurrent_A: 312.6,
    tractiveEffort_kN: 89.4,
    bogie1BearingTemp_C: 54.2,
    bogie1Vibration_mms2: 2.1,
    bogie2Vibration_mms2: 2.3,
    wheelsetLateralAccel_ms2: 0.42,
    ambientTemp_C: 22.5,
    cabinTemp_C: 21.8,
    doorCyclesTotal: 14820,
    brakeAirPressure_bar: 5.0,
    pantographContactForce_N: 118.5,
    batterySoc_pct: 94.2,
    tcmsAlarmsCount: 0,
    status: 'IN_SERVICE'
  });

  // Fleet Trainsets
  readonly fleetTrainsets = signal([
    {
      id: 'RSX-320-001',
      name: 'Trainset 001',
      route: 'Paris Gare du Nord — London St Pancras',
      speed_kmh: 318.4,
      mileage_km: 184500,
      availability_pct: 99.6,
      health: 'OPTIMAL',
      status: 'IN_SERVICE'
    },
    {
      id: 'RSX-320-002',
      name: 'Trainset 002',
      route: 'Brussels Midi — Amsterdam Centraal',
      speed_kmh: 298.0,
      mileage_km: 142100,
      availability_pct: 99.4,
      health: 'OPTIMAL',
      status: 'IN_SERVICE'
    },
    {
      id: 'RSX-320-003',
      name: 'Trainset 003',
      route: 'Type Testing / Velim Test Circuit',
      speed_kmh: 160.0,
      mileage_km: 18200,
      availability_pct: 98.2,
      health: 'WATCH',
      status: 'TESTING'
    },
    {
      id: 'RSX-320-004',
      name: 'Trainset 004',
      route: 'Temple Mills High Speed Depot (Scheduled 150k Overhaul)',
      speed_kmh: 0,
      mileage_km: 151200,
      availability_pct: 99.1,
      health: 'OPTIMAL',
      status: 'DEPOT'
    },
    {
      id: 'RSX-320-005',
      name: 'Trainset 005',
      route: 'Northfield Rail Systems (Final Assembly Hall 7)',
      speed_kmh: 0,
      mileage_km: 0,
      availability_pct: 100,
      health: 'OPTIMAL',
      status: 'TESTING'
    }
  ]);

  // Standards Library
  readonly standards = signal<TSIStandard[]>([
    {
      code: 'TSI LOC&PAS (EU 1302/2014)',
      name: 'Technical Specification for Interoperability - Locomotives & Passenger Rolling Stock',
      version: '2023 Revision (TSI Package 2023)',
      jurisdiction: 'ERA_EU',
      complianceStatus: 'VERIFIED',
      auditorOrg: 'Notified Body Belgorail / TÜV Rheinland',
      certificateRef: 'NB-0035-TSI-LOCPAS-2026-881'
    },
    {
      code: 'EN 14363:2016+A1:2019',
      name: 'Testing for the Acceptance of Running Characteristics of Railway Vehicles',
      version: 'EN 14363:2019',
      jurisdiction: 'ERA_EU',
      complianceStatus: 'VERIFIED',
      auditorOrg: 'TÜV SÜD Rail',
      certificateRef: 'TUV-DYN-14363-RSX320'
    },
    {
      code: 'EN 15227:2020',
      name: 'Crashworthiness Requirements for Railway Vehicle Bodies',
      version: 'EN 15227:2020 Category C-I (Crash Scenarios 1-4)',
      jurisdiction: 'ERA_EU',
      complianceStatus: 'VERIFIED',
      auditorOrg: 'Bureau Veritas Rail',
      certificateRef: 'BV-CRASH-EN15227-0442'
    },
    {
      code: 'EN 50126-1:2017 / EN 50129:2018',
      name: 'Railway Applications - RAMS & Safety-Related Electronic Systems for Signalling & Control',
      version: 'EN 50126/129 SIL 4 Certified',
      jurisdiction: 'ERA_EU',
      complianceStatus: 'VERIFIED',
      auditorOrg: 'DEKRA Rail',
      certificateRef: 'DEKRA-SIL4-SAFETY-CASE-990'
    },
    {
      code: 'TS 50701 / IEC 62443',
      name: 'Railway Applications - Cybersecurity in Rolling Stock Architecture',
      version: 'TS 50701:2021 Security Level SL-3',
      jurisdiction: 'ERA_EU',
      complianceStatus: 'VERIFIED',
      auditorOrg: 'NCC Group Rail Security / TÜV Rheinland',
      certificateRef: 'CYBER-TS50701-RSX320-SL3'
    }
  ]);

  // Quality Non-Conformance Records (NCR)
  readonly qualityNCRs = signal<QualityNCR[]>([
    {
      id: 'NCR-2026-0814',
      componentCode: 'TRC-00421',
      description: 'SiC Power Module thermal interface paste void percentage was 6.2% exceeding 4.0% limit during initial vacuum reflow.',
      severity: 'MAJOR',
      stage: 'INCOMING_SUPPLY',
      rootCause: 'Supplier dispensing nozzle micro-clogging during high-viscosity paste application.',
      containmentAction: '100% X-ray inspection of incoming batch; rejected modules returned to supplier for robotic re-dispense.',
      correctiveAction: 'Automated pressure sensor check added to supplier automated dispensing cell with automated purge cycle every 50 cycles.',
      status: 'CLOSED',
      costImpact_EUR: 14500,
      reportedDate: '2026-07-18'
    },
    {
      id: 'NCR-2026-0922',
      componentCode: 'DOR-SYN-01',
      description: 'Car 3 Left Door #2 acoustic seal compression force 185 N (upper limit 160 N) causing slight motor current elevation.',
      severity: 'MINOR',
      stage: 'ASSEMBLY',
      rootCause: 'EPDM rubber gasket hardness variation in batch EPDM-091B.',
      containmentAction: 'Replaced gasket seal with calibrated durometer batch EPDM-092A on Car 3 and verified motor current signature.',
      correctiveAction: 'Incoming durometer hardness testing on all door seal batches prior to release to Hall 6.',
      status: 'CLOSED',
      costImpact_EUR: 3200,
      reportedDate: '2026-08-02'
    }
  ]);

  // Safety Hazards (CSM-RA / EN 50129)
  readonly safetyHazards = signal<SafetyHazard[]>([
    {
      id: 'HAZ-001',
      hazardTitle: 'Uncommanded Traction or Inadvertent Loss of Braking Effort at 320 km/h',
      consequence: 'Risk of collision, overspeed, or signal overrun.',
      initialRisk: 'INTOLERABLE',
      mitigationRequirement: 'Dual-channel independent SIL 4 emergency brake loop and 2-out-of-2 hardware cross-monitoring in EBCU.',
      silLevel: 'SIL_4',
      verificationEvidence: 'EBCU-SIL4-VALIDATION-DOSSIER-V3.pdf',
      residualRisk: 'BROADLY_ACCEPTABLE',
      status: 'CLOSED_VERIFIED'
    },
    {
      id: 'HAZ-002',
      hazardTitle: 'Passenger Door Opening While Trainset is Moving at Speed > 3 km/h',
      consequence: 'Risk of passenger falling from vehicle.',
      initialRisk: 'INTOLERABLE',
      mitigationRequirement: 'Triple-redundant zero-speed interlocking with mechanical safety lock active when speed sensor > 0.5 km/h.',
      silLevel: 'SIL_4',
      verificationEvidence: 'DOOR-ZERO-SPEED-INTERLOCK-TEST.pdf',
      residualRisk: 'BROADLY_ACCEPTABLE',
      status: 'CLOSED_VERIFIED'
    },
    {
      id: 'HAZ-003',
      hazardTitle: 'Bogie Axlebox Bearing Thermal Runaway & Seizure at 320 km/h',
      consequence: 'Risk of axle fracture, hot axle box, derailment.',
      initialRisk: 'INTOLERABLE',
      mitigationRequirement: 'Dual dual-element Pt100 temperature sensors and 3-axis high-frequency vibration sensors with autonomous TCMS emergency brake trigger if temp > 95°C or vibration > 12 mm/s² RMS.',
      silLevel: 'SIL_3',
      verificationEvidence: 'AXLEBOX-HEALTH-TEST-REPORT-TUV.pdf',
      residualRisk: 'TOLERABLE',
      status: 'CLOSED_VERIFIED'
    }
  ]);

  // Guided Tour 25-step definitions
  readonly guidedSteps = [
    {
      step: 1,
      title: '01. Open Reference Train',
      tab: 'command_centre',
      desc: 'Inspect the RSX-320 high-speed electric multiple unit programme overview, design freeze status (82%), requirements verification (1,197 / 1,482 verified), and major vehicle performance metrics.'
    },
    {
      step: 2,
      title: '02. Select Vehicle Car',
      tab: 'train_designer',
      desc: 'Inspect Car 2 (M1 Motor Car with Pantograph & 2,000 kW Traction System). View mass distribution, axle loads (13.6 t/axle), and bogie spacing.'
    },
    {
      step: 3,
      title: '03. Open Bogie Digital Twin',
      tab: 'bogies',
      desc: 'Navigate to Bogie Digital Twin (BOG-201). Inspect structural frame, wheelsets, primary coil springs, secondary air bellows, yaw dampers, and traction motor mounting.'
    },
    {
      step: 4,
      title: '04. Inspect Wheelset & Suspension',
      tab: 'bogies',
      desc: 'Analyze Lucchini 920 mm forged wheels, R8T alloy metallurgical condition, wheel profile wear ($S_h, S_d, q_R$), bearing temperatures, and suspension displacement limits.'
    },
    {
      step: 5,
      title: '05. Open Traction Powertrain',
      tab: 'traction',
      desc: 'Examine complete high-speed electric traction chain: 25 kV AC Pantograph -> Transformer -> SiC 4-Quadrant Inverters -> 8x 1,000 kW Permanent Magnet Motors -> Gearbox -> Wheelsets.'
    },
    {
      step: 6,
      title: '06. View Tractive-Effort Curve',
      tab: 'traction',
      desc: 'Review the hyperbolic tractive effort curve $F(v)$: 240 kN starting force transitioning to 8,000 kW constant power at 120 km/h up to 320 km/h (90 kN continuous at 320 km/h).'
    },
    {
      step: 7,
      title: '07. Run 0-320 km/h Simulation',
      tab: 'traction',
      desc: 'Execute full dynamic acceleration run: RSX-320 achieves 320 km/h in 238 seconds covering 12.8 km on level tangent track within EN 50388 limits.'
    },
    {
      step: 8,
      title: '08. Open Braking Subsystem',
      tab: 'braking',
      desc: 'Examine blended electrodynamic regenerative and electropneumatic friction braking architecture with Knorr-Bremse EBCU control.'
    },
    {
      step: 9,
      title: '09. Run Emergency Braking Simulation',
      tab: 'braking',
      desc: 'Execute 320 to 0 km/h emergency braking simulation under degraded adhesion. Stopping distance is 2,980 m (comfortably below the 3,050 m TSI limit) with 18.2 kWh recovered.'
    },
    {
      step: 10,
      title: '10. Open Vehicle Dynamics',
      tab: 'vehicle_dynamics',
      desc: 'Inspect multibody dynamics model: mass matrices, secondary air suspension stiffness, wheel-rail contact (Kalker method), and Sperling ride index.'
    },
    {
      step: 11,
      title: '11. Run High-Speed Curve Scenario',
      tab: 'vehicle_dynamics',
      desc: 'Simulate negotiation of a 3,000 m radius curve at 300 km/h with 150 mm cant deficiency. Sperling index $W_z = 2.12$ (Very Good) and $Y/Q = 0.38$ (safe, limit 0.8).'
    },
    {
      step: 12,
      title: '12. Open Energy & Efficiency',
      tab: 'sustainability',
      desc: 'Examine traction energy consumption (14.2 kWh/train-km at 320 km/h), auxiliary hotel loads, HVAC consumption, and 28.4% regenerative energy recovery.'
    },
    {
      step: 13,
      title: '13. Compare Multi-Mode Variants',
      tab: 'battery_hydrogen',
      desc: 'Compare Overhead 25 kV AC vs Battery-Electric BEMU vs Hydrogen H2MU across range, mass penalty, charging/refuelling time, and lifecycle CO2e.'
    },
    {
      step: 14,
      title: '14. Open Northfield Factory Twin',
      tab: 'factory',
      desc: 'Navigate to Northfield Rail Systems digital factory: 7 manufacturing halls, 20 production workstations, and real-time robotic work cells.'
    },
    {
      step: 15,
      title: '15. See Trainset Being Assembled',
      tab: 'factory',
      desc: 'Observe Station 6 (Equipment Fit-out) and Station 8 (8-Car Marriage) actively assembling RSX-320-001 and RSX-320-002 with live takt times and queues.'
    },
    {
      step: 16,
      title: '16. Select Component TRC-00421',
      tab: 'digital_thread',
      desc: 'Drill into SiC Traction Converter TRC-00421. Open its unique engineering passport, serial number, and CAD references.'
    },
    {
      step: 17,
      title: '17. Trace to Material Batch AL-83921',
      tab: 'digital_thread',
      desc: 'Query upstream digital thread: trace the mounting beam structural alloy to certified Aluminium batch AL-83921 from Extrusion Plant A.'
    },
    {
      step: 18,
      title: '18. Open Inspection Record I-88291',
      tab: 'quality',
      desc: 'Inspect NDT ultrasonic weld inspection I-88291 for Weld W-19382: 0 flaws detected, certified to EN ISO 5817 Level B by TÜV SÜD.'
    },
    {
      step: 19,
      title: '19. Open Dynamic Test Result T-3818',
      tab: 'test_validation',
      desc: 'Review full-power bench test record T-3818: 2,000 kW continuous converter output, 98.8% inverter efficiency, thermal equilibrium at 74°C.'
    },
    {
      step: 20,
      title: '20. Trace to Requirement REQ-TRACTION-001',
      tab: 'requirements',
      desc: 'Trace test evidence directly to root requirement REQ-TRACTION-001 ("0 to 320 km/h acceleration under AW2 payload") and close verification loop.'
    },
    {
      step: 21,
      title: '21. Put Completed Train into Service',
      tab: 'fleet_operations',
      desc: 'Deploy physical trainset RSX-320-001 on the Eurostar high-speed line between Paris and London. Activate operational digital twin.'
    },
    {
      step: 22,
      title: '22. Stream Live Operational Telemetry',
      tab: 'fleet_operations',
      desc: 'Stream high-frequency telemetry at 318.4 km/h: 25.4 kV line voltage, 312 A current, 54°C bearing temperatures, and 2.1 mm/s² RMS vibration.'
    },
    {
      step: 23,
      title: '23. Inject Bogie Vibration Anomaly',
      tab: 'maintenance',
      desc: 'Inject synthetic bearing defect (outer race spalling fault at 142 Hz harmonic frequency) to simulate realistic component degradation.'
    },
    {
      step: 24,
      title: '24. Detect Anomaly via Predictive AI',
      tab: 'maintenance',
      desc: 'Observe the anomaly detector flag Bogie 1 vibration rising to 14.8 mm/s² (CRITICAL threshold). Explainability model confirms bearing outer race fatigue.'
    },
    {
      step: 25,
      title: '25. Generate Depot Maintenance Work Order',
      tab: 'maintenance',
      desc: 'Automated predictive maintenance engine generates Work Order WO-DEP-2026-9904 at Temple Mills Depot: replaces axlebox bearing within 48h before in-service failure.'
    }
  ];

  constructor() {
    this.startLiveTelemetryClock();
  }

  setTab(tab: string) {
    this.activeTab.set(tab);
  }

  startGuidedTour() {
    this.isGuidedTourActive.set(true);
    this.guidedStepIndex.set(0);
    this.applyGuidedStep(0);
  }

  nextGuidedStep() {
    const current = this.guidedStepIndex();
    if (current < this.guidedSteps.length - 1) {
      const next = current + 1;
      this.guidedStepIndex.set(next);
      this.applyGuidedStep(next);
    } else {
      this.isGuidedTourActive.set(false);
    }
  }

  prevGuidedStep() {
    const current = this.guidedStepIndex();
    if (current > 0) {
      const prev = current - 1;
      this.guidedStepIndex.set(prev);
      this.applyGuidedStep(prev);
    }
  }

  jumpToGuidedStep(index: number) {
    if (index >= 0 && index < this.guidedSteps.length) {
      this.guidedStepIndex.set(index);
      this.applyGuidedStep(index);
    }
  }

  exitGuidedTour() {
    this.isGuidedTourActive.set(false);
  }

  private applyGuidedStep(stepIdx: number) {
    const step = this.guidedSteps[stepIdx];
    this.activeTab.set(step.tab);
    
    // Custom actions per step
    if (step.step === 2) {
      this.selectedCarIndex.set(1); // Select car 2
    } else if (step.step === 16) {
      this.selectedComponentCode.set('TRC-00421');
    } else if (step.step === 23) {
      this.injectBogieAnomaly();
    }
  }

  injectBogieAnomaly() {
    this.injectedAnomaly.set(true);
    this.telemetry.update(t => ({
      ...t,
      bogie1Vibration_mms2: 14.8,
      bogie1BearingTemp_C: 84.6,
      status: 'MAINTENANCE_REQUIRED',
      tcmsAlarmsCount: 1
    }));
  }

  clearAnomaly() {
    this.injectedAnomaly.set(false);
    this.telemetry.update(t => ({
      ...t,
      bogie1Vibration_mms2: 2.1,
      bogie1BearingTemp_C: 54.2,
      status: 'IN_SERVICE',
      tcmsAlarmsCount: 0
    }));
  }

  updateParametricCarbodyLength(newLength_m: number) {
    this.carbodyLength_m.set(newLength_m);
    // Propagate changes to all intermediate cars
    this.cars.update(currentCars => {
      return currentCars.map(c => {
        if (c.type === 'DRIVING_TRAILER') {
          return {
            ...c,
            length_m: Number((newLength_m + 0.8).toFixed(1)),
            tareMass_t: Number((48.5 * (newLength_m / 25.0)).toFixed(1)),
            grossMass_t: Number((58.2 * (newLength_m / 25.0)).toFixed(1))
          };
        } else {
          return {
            ...c,
            length_m: newLength_m,
            tareMass_t: Number((c.tareMass_t * (newLength_m / 25.0)).toFixed(1)),
            grossMass_t: Number((c.grossMass_t * (newLength_m / 25.0)).toFixed(1)),
            seatsStandardClass: Math.round(c.seatsStandardClass * (newLength_m / 25.0)),
            seatsFirstClass: Math.round(c.seatsFirstClass * (newLength_m / 25.0))
          };
        }
      });
    });
  }

  updateNoseLength(newNose_m: number) {
    this.noseLength_m.set(newNose_m);
    // Aero Cd improves with optimal nose elongation
    const optimalCd = Number((0.142 * (5.8 / newNose_m)).toFixed(3));
    this.aeroCd.set(Math.max(0.125, optimalCd));
  }

  addCarToFormation(carType: CarType) {
    const current = this.cars();
    const newIndex = current.length + 1;
    const isMotor = carType === 'MOTOR_CAR' || carType === 'POWER_CAR';
    const newCar: CarConfig = {
      id: `car-${newIndex}`,
      carIndex: newIndex,
      type: carType,
      designation: `M${newIndex} — Additional ${carType.replace('_', ' ')}`,
      length_m: this.carbodyLength_m(),
      tareMass_t: isMotor ? 53.0 : 45.0,
      grossMass_t: isMotor ? 66.0 : 58.0,
      axleCount: 4,
      isMotorized: isMotor,
      motorPower_kW: isMotor ? 2000 : 0,
      hasPantograph: false,
      hasTransformer: false,
      seatsFirstClass: 0,
      seatsStandardClass: 80,
      accessibleSpaces: 0,
      bogieType: isMotor ? 'MOTOR_BOGIE' : 'TRAILER_BOGIE',
      bogieSpacing_m: this.bogieCentres_m(),
      wheelbase_m: this.wheelbase_m(),
      hvacCapacity_kW: 40,
      doorsPerSide: 2
    };
    this.cars.set([...current, newCar]);
  }

  removeCarFromFormation(index: number) {
    const current = this.cars();
    if (current.length > 2) {
      const filtered = current.filter((_, i) => i !== index).map((c, i) => ({
        ...c,
        carIndex: i + 1
      }));
      this.cars.set(filtered);
    }
  }

  loadPresetFormation(preset: 'RSX_320_8CAR' | 'RSX_320_10CAR' | 'REGIONAL_BEMU' | 'TRANSALPINE_H2MU') {
    if (preset === 'RSX_320_8CAR') {
      // default 8-car
      this.programmeName.set('RSX-320 Next-Gen High-Speed EMU (8 Cars)');
      this.targetMaxSpeed_kmh.set(320);
      this.updateParametricCarbodyLength(25.0);
    } else if (preset === 'RSX_320_10CAR') {
      this.programmeName.set('RSX-320-Long 10-Car High-Capacity EMU');
      this.targetMaxSpeed_kmh.set(320);
      this.addCarToFormation('MOTOR_CAR');
      this.addCarToFormation('TRAILER');
    } else if (preset === 'REGIONAL_BEMU') {
      this.programmeName.set('RSX-Ecomotive Regional Battery Multiple Unit (BEMU)');
      this.targetMaxSpeed_kmh.set(160);
      this.cars.set([
        {
          id: 'bemu-1',
          carIndex: 1,
          type: 'DRIVING_TRAILER',
          designation: 'DT1 — Driving Cab A (with 350 kWh LTO Battery Pack)',
          length_m: 25.0,
          tareMass_t: 46.0,
          grossMass_t: 54.0,
          axleCount: 4,
          isMotorized: false,
          motorPower_kW: 0,
          hasPantograph: true,
          hasTransformer: false,
          batteryCapacity_kWh: 350,
          seatsFirstClass: 12,
          seatsStandardClass: 60,
          accessibleSpaces: 2,
          bogieType: 'TRAILER_BOGIE',
          bogieSpacing_m: 17.5,
          wheelbase_m: 2.5,
          hvacCapacity_kW: 32,
          doorsPerSide: 2
        },
        {
          id: 'bemu-2',
          carIndex: 2,
          type: 'BATTERY_CAR',
          designation: 'BC1 — Battery Power Car (1,200 kW Traction + 700 kWh LTO Pack)',
          length_m: 24.8,
          tareMass_t: 56.0,
          grossMass_t: 68.0,
          axleCount: 4,
          isMotorized: true,
          motorPower_kW: 1200,
          hasPantograph: false,
          hasTransformer: false,
          batteryCapacity_kWh: 700,
          seatsFirstClass: 0,
          seatsStandardClass: 76,
          accessibleSpaces: 1,
          bogieType: 'MOTOR_BOGIE',
          bogieSpacing_m: 17.5,
          wheelbase_m: 2.5,
          hvacCapacity_kW: 35,
          doorsPerSide: 2
        },
        {
          id: 'bemu-3',
          carIndex: 3,
          type: 'DRIVING_TRAILER',
          designation: 'DT2 — Driving Cab B (with 350 kWh LTO Battery Pack)',
          length_m: 25.0,
          tareMass_t: 46.0,
          grossMass_t: 54.0,
          axleCount: 4,
          isMotorized: false,
          motorPower_kW: 0,
          hasPantograph: false,
          hasTransformer: false,
          batteryCapacity_kWh: 350,
          seatsFirstClass: 0,
          seatsStandardClass: 72,
          accessibleSpaces: 2,
          bogieType: 'TRAILER_BOGIE',
          bogieSpacing_m: 17.5,
          wheelbase_m: 2.5,
          hvacCapacity_kW: 32,
          doorsPerSide: 2
        }
      ]);
    } else if (preset === 'TRANSALPINE_H2MU') {
      this.programmeName.set('RSX-Hydra Trans-Alpine Hydrogen Fuel Cell Train (H2MU)');
      this.targetMaxSpeed_kmh.set(160);
      this.cars.set([
        {
          id: 'h2-1',
          carIndex: 1,
          type: 'DRIVING_TRAILER',
          designation: 'DT1 — Driving Cab A with 200 kg 700-bar H2 Storage',
          length_m: 25.0,
          tareMass_t: 48.0,
          grossMass_t: 56.0,
          axleCount: 4,
          isMotorized: false,
          motorPower_kW: 0,
          hasPantograph: false,
          hasTransformer: false,
          h2Capacity_kg: 200,
          seatsFirstClass: 16,
          seatsStandardClass: 54,
          accessibleSpaces: 2,
          bogieType: 'TRAILER_BOGIE',
          bogieSpacing_m: 17.5,
          wheelbase_m: 2.5,
          hvacCapacity_kW: 30,
          doorsPerSide: 2
        },
        {
          id: 'h2-2',
          carIndex: 2,
          type: 'HYDROGEN_CAR',
          designation: 'HC1 — 600 kW PEM Fuel Cell Power Unit + 200 kWh Buffer Battery',
          length_m: 24.8,
          tareMass_t: 58.0,
          grossMass_t: 69.0,
          axleCount: 4,
          isMotorized: true,
          motorPower_kW: 1200,
          hasPantograph: false,
          hasTransformer: false,
          h2Capacity_kg: 300,
          seatsFirstClass: 0,
          seatsStandardClass: 60,
          accessibleSpaces: 0,
          bogieType: 'MOTOR_BOGIE',
          bogieSpacing_m: 17.5,
          wheelbase_m: 2.5,
          hvacCapacity_kW: 36,
          doorsPerSide: 2
        },
        {
          id: 'h2-3',
          carIndex: 3,
          type: 'DRIVING_TRAILER',
          designation: 'DT2 — Driving Cab B with 200 kg 700-bar H2 Storage',
          length_m: 25.0,
          tareMass_t: 48.0,
          grossMass_t: 56.0,
          axleCount: 4,
          isMotorized: false,
          motorPower_kW: 0,
          hasPantograph: false,
          hasTransformer: false,
          h2Capacity_kg: 200,
          seatsFirstClass: 0,
          seatsStandardClass: 70,
          accessibleSpaces: 2,
          bogieType: 'TRAILER_BOGIE',
          bogieSpacing_m: 17.5,
          wheelbase_m: 2.5,
          hvacCapacity_kW: 30,
          doorsPerSide: 2
        }
      ]);
    }
  }

  private startLiveTelemetryClock() {
    setInterval(() => {
      if (!this.isLiveTelemetryActive()) return;
      this.telemetry.update(curr => {
        // slight realistic jitter
        const speedJitter = (Math.random() - 0.5) * 1.2;
        const currentSpeed = Math.min(320.2, Math.max(314.0, curr.speed_kmh + speedJitter));
        const voltJitter = (Math.random() - 0.5) * 0.15;
        const vibBase = this.injectedAnomaly() ? 14.8 : 2.1;
        const vibJitter = (Math.random() - 0.5) * 0.3;

        return {
          ...curr,
          timestamp: new Date().toISOString(),
          speed_kmh: Number(currentSpeed.toFixed(1)),
          locationKm: Number((curr.locationKm + 0.088).toFixed(2)),
          lineVoltage_kV: Number((25.4 + voltJitter).toFixed(2)),
          catenaryCurrent_A: Number((312.0 + (Math.random() - 0.5) * 8).toFixed(1)),
          tractiveEffort_kN: Number((89.0 + (Math.random() - 0.5) * 4).toFixed(1)),
          bogie1Vibration_mms2: Number((vibBase + vibJitter).toFixed(2)),
          bogie2Vibration_mms2: Number((2.3 + (Math.random() - 0.5) * 0.2).toFixed(2)),
          wheelsetLateralAccel_ms2: Number((0.42 + (Math.random() - 0.5) * 0.08).toFixed(2)),
          pantographContactForce_N: Number((118.0 + (Math.random() - 0.5) * 6).toFixed(1))
        };
      });
    }, 1500);
  }
}
