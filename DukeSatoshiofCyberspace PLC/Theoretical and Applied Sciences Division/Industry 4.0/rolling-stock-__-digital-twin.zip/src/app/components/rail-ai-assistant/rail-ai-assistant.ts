import { Component, ChangeDetectionStrategy, inject, signal, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HttpClient } from '@angular/common/http';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

interface AiMessage {
  sender: 'USER' | 'RAIL_AI';
  text: string;
  source?: string;
  model?: string;
  confidence?: number;
  timestamp: string;
}

@Component({
  selector: 'app-rail-ai-assistant',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <!-- Backdrop -->
    <div 
      role="dialog"
      aria-modal="true"
      tabindex="0"
      (click)="closed.emit()" 
      (keydown.escape)="closed.emit()" 
      class="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex justify-end">
      <!-- Drawer Content -->
      <div 
        tabindex="0"
        role="document"
        (click)="$event.stopPropagation()" 
        (keydown)="$event.stopPropagation()"
        class="w-full max-w-xl bg-slate-900 border-l border-slate-800 h-full flex flex-col shadow-2xl">
        <!-- Header -->
        <div class="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-700 flex items-center justify-center text-cyan-400">
              <mat-icon class="text-lg">smart_toy</mat-icon>
            </div>
            <div>
              <div class="flex items-center gap-2">
                <span class="font-bold text-white text-sm font-mono">RAIL.AI</span>
                <span class="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                  Gemini 3.8 Flash Engineering Engine
                </span>
              </div>
              <div class="text-[11px] text-slate-400">Grounding on RSX-320 Digital Thread Data</div>
            </div>
          </div>

          <button (click)="closed.emit()" class="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 cursor-pointer">
            <mat-icon>close</mat-icon>
          </button>
        </div>

        <!-- Quick Engineering Prompt Suggestions -->
        <div class="p-3 bg-slate-950/50 border-b border-slate-800/80 space-y-1.5 overflow-x-auto text-[11px] font-mono">
          <div class="text-[10px] text-slate-500 uppercase font-bold">SUGGESTED ENGINEERING QUERIES:</div>
          <div class="flex gap-2 pb-1">
            <button 
              (click)="sendQuery('Which systems are affected if we increase maximum speed from 300 to 320 km/h?')"
              class="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-slate-700 rounded whitespace-nowrap cursor-pointer transition">
              Max Speed 320 Impact
            </button>
            <button 
              (click)="sendQuery('Which production station is the current bottleneck at Northfield Rail Systems?')"
              class="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-slate-700 rounded whitespace-nowrap cursor-pointer transition">
              Factory Bottlenecks
            </button>
            <button 
              (click)="sendQuery('Which components have the highest predicted maintenance risk in operational telemetry?')"
              class="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-slate-700 rounded whitespace-nowrap cursor-pointer transition">
              Predictive Maintenance
            </button>
          </div>
        </div>

        <!-- Messages Chat Area -->
        <div class="flex-1 overflow-y-auto p-4 space-y-4 font-mono text-xs">
          @for (msg of messages(); track msg.timestamp) {
            <div [class.items-end]="msg.sender === 'USER'" [class.items-start]="msg.sender === 'RAIL_AI'" class="flex flex-col space-y-1">
              <div class="flex items-center gap-1 text-[10px] text-slate-500">
                <span>{{ msg.sender === 'USER' ? 'ENGINEER' : 'RAIL.AI COPILOT' }}</span>
                <span>&bull;</span>
                <span>{{ msg.timestamp }}</span>
              </div>
              <div 
                [class.bg-cyan-950]="msg.sender === 'USER'"
                [class.border-cyan-800]="msg.sender === 'USER'"
                [class.text-cyan-100]="msg.sender === 'USER'"
                [class.bg-slate-950]="msg.sender === 'RAIL_AI'"
                [class.border-slate-800]="msg.sender === 'RAIL_AI'"
                [class.text-slate-200]="msg.sender === 'RAIL_AI'"
                class="p-3.5 rounded-xl border max-w-[90%] whitespace-pre-line leading-relaxed shadow-sm">
                {{ msg.text }}
                @if (msg.source) {
                  <div class="mt-2 pt-2 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
                    <span>Source: {{ msg.source }}</span>
                    <span class="text-emerald-400">Confidence: {{ (msg.confidence || 0.98) * 100 }}%</span>
                  </div>
                }
              </div>
            </div>
          }

          @if (isLoading()) {
            <div class="flex items-center gap-2 text-cyan-400 p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs">
              <mat-icon class="animate-spin text-sm">rotate_right</mat-icon>
              <span>RAIL.AI analyzing digital thread & physics models...</span>
            </div>
          }
        </div>

        <!-- Input Bar -->
        <div class="p-3 border-t border-slate-800 bg-slate-950/80 flex items-center gap-2">
          <input 
            #queryInput 
            (keyup.enter)="sendQuery(queryInput.value); queryInput.value = ''" 
            placeholder="Ask RAIL.AI about RSX-320 systems, telemetry, or manufacturing..."
            class="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500" />
          <button 
            (click)="sendQuery(queryInput.value); queryInput.value = ''"
            class="px-3 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-mono flex items-center gap-1 cursor-pointer">
            <span>Ask</span>
            <mat-icon class="text-xs">send</mat-icon>
          </button>
        </div>
      </div>
    </div>
  `
})
export class RailAiAssistantComponent {
  readonly twin = inject(RollingStockTwinService);
  private readonly http = inject(HttpClient);
  readonly closed = output<void>();

  readonly isLoading = signal<boolean>(false);
  readonly messages = signal<AiMessage[]>([
    {
      sender: 'RAIL_AI',
      text: `Hello Engineer. I am RAIL.AI, your rolling stock digital twin intelligence assistant.
I am continuously synchronized with the RSX-320 design baseline (82% Freeze), requirements database (1,482 requirements), Northfield manufacturing shop floor, and live Eurostar operational telemetry.

How can I assist your engineering evaluation today?`,
      source: 'RSX-320 DIGITAL THREAD KERNEL',
      model: 'gemini-3.8-flash',
      confidence: 1.0,
      timestamp: new Date().toLocaleTimeString()
    }
  ]);

  sendQuery(prompt: string) {
    if (!prompt.trim()) return;

    const userMsg: AiMessage = {
      sender: 'USER',
      text: prompt,
      timestamp: new Date().toLocaleTimeString()
    };
    this.messages.update(m => [...m, userMsg]);
    this.isLoading.set(true);

    this.http.post<{ answer?: string; source?: string; model?: string; confidence?: number }>('/api/rail-ai', { prompt }).subscribe({
      next: (res) => {
        this.isLoading.set(false);
        const aiMsg: AiMessage = {
          sender: 'RAIL_AI',
          text: res.answer || 'Analysis completed.',
          source: res.source,
          model: res.model,
          confidence: res.confidence,
          timestamp: new Date().toLocaleTimeString()
        };
        this.messages.update(m => [...m, aiMsg]);
      },
      error: () => {
        this.isLoading.set(false);
        const aiMsg: AiMessage = {
          sender: 'RAIL_AI',
          text: `**Deterministic Engineering Response:**\n• Systems evaluated for query "${prompt}".\n• Reference vehicle RSX-320 8-car High-Speed EMU operating within nominal TSI LOC&PAS envelope.\n• Digital Thread link intact.`,
          source: 'OFFLINE_ENGINEERING_CORE',
          model: 'fallback-kernel',
          confidence: 0.95,
          timestamp: new Date().toLocaleTimeString()
        };
        this.messages.update(m => [...m, aiMsg]);
      }
    });
  }
}

