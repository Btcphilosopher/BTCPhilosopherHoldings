import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

interface NavItem {
  id: string;
  number: string;
  name: string;
  icon: string;
  badge?: string;
}

interface NavGroup {
  title: string;
  items: NavItem[];
}

@Component({
  selector: 'app-navigation',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <nav class="w-64 bg-slate-950 border-r border-slate-800 flex flex-col h-full shrink-0 select-none">
      <!-- Section Header -->
      <div class="px-3 py-2.5 border-b border-slate-800/80 flex items-center justify-between">
        <div class="text-[11px] font-mono font-semibold uppercase tracking-wider text-slate-400">
          ENGINEERING WORKSTATION
        </div>
        <span class="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-800/50">
          v2026.4
        </span>
      </div>

      <!-- Navigation Tree Scroll Area -->
      <div class="flex-1 overflow-y-auto px-2 py-3 space-y-4 text-xs">
        @for (group of navGroups; track group.title) {
          <div class="space-y-1">
            <div class="px-2 py-1 text-[10px] font-mono font-bold uppercase tracking-wider text-slate-300">
              {{ group.title }}
            </div>
            @for (item of group.items; track item.id) {
              <button 
                (click)="twin.setTab(item.id)"
                [class.bg-cyan-950/70]="twin.activeTab() === item.id"
                [class.text-cyan-300]="twin.activeTab() === item.id"
                [class.border-cyan-500/40]="twin.activeTab() === item.id"
                [class.font-semibold]="twin.activeTab() === item.id"
                [class.text-slate-300]="twin.activeTab() !== item.id"
                [class.border-transparent]="twin.activeTab() !== item.id"
                class="w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-left transition-all duration-150 border hover:bg-slate-900 hover:text-slate-100 cursor-pointer group">
                <div class="flex items-center gap-2 truncate">
                  <span class="font-mono text-[10px] text-slate-300 group-hover:text-slate-100 shrink-0">
                    {{ item.number }}
                  </span>
                  <mat-icon class="text-base text-slate-300 group-hover:text-slate-100 transition-colors shrink-0">
                    {{ item.icon }}
                  </mat-icon>
                  <span class="truncate">{{ item.name }}</span>
                </div>
                @if (item.badge) {
                  <span class="text-[9px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    {{ item.badge }}
                  </span>
                }
              </button>
            }
          </div>
        }
      </div>

      <!-- Footer Digital Twin Thread Summary -->
      <div class="p-3 border-t border-slate-800/80 bg-slate-950/90 text-[11px] font-mono text-slate-400">
        <div class="flex items-center justify-between mb-1">
          <span class="text-slate-500">DIGITAL THREAD</span>
          <span class="text-emerald-400 font-bold">100% LINKED</span>
        </div>
        <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
          <div class="bg-gradient-to-r from-cyan-500 to-emerald-400 h-full rounded-full" style="width: 100%"></div>
        </div>
      </div>
    </nav>
  `
})
export class NavigationComponent {
  readonly twin = inject(RollingStockTwinService);

  readonly navGroups: NavGroup[] = [
    {
      title: '01 // PROGRAMME & ARCHITECTURE',
      items: [
        { id: 'command_centre', number: '01', name: 'Command Centre', icon: 'dashboard' },
        { id: 'train_designer', number: '03', name: 'Train Designer', icon: 'view_carousel', badge: 'Formation' },
        { id: 'parametric_cad', number: '04', name: 'Parametric CAD', icon: 'architecture', badge: 'Geometry' },
        { id: 'systems_engineering', number: '05', name: 'Systems Engineering', icon: 'account_tree', badge: 'N2 Matrix' },
        { id: 'requirements', number: '08', name: 'Requirements & V&V', icon: 'fact_check' },
        { id: 'digital_thread', number: '32', name: 'Digital Thread', icon: 'hub', badge: 'Core' }
      ]
    },
    {
      title: '02 // MULTIPHYSICS & SYSTEMS',
      items: [
        { id: 'aerodynamics', number: '06', name: 'Aerodynamics', icon: 'air' },
        { id: 'vehicle_dynamics', number: '07', name: 'Vehicle Dynamics', icon: 'speed' },
        { id: 'bogies', number: '09', name: 'Bogies & Running Gear', icon: 'tire_repair', badge: 'BOG-201' },
        { id: 'traction', number: '10', name: 'Traction & Powertrain', icon: 'bolt', badge: '8.0 MW' },
        { id: 'braking', number: '11', name: 'Braking & Blending', icon: 'airline_stops' },
        { id: 'battery_hydrogen', number: '13', name: 'Battery & Hydrogen', icon: 'battery_charging_full' },
        { id: 'thermal_hvac', number: '14', name: 'Thermal & HVAC', icon: 'thermostat' },
        { id: 'doors_interior', number: '16', name: 'Doors & Interior', icon: 'meeting_room' },
        { id: 'tcms_cyber', number: '19', name: 'TCMS & Cyber Network', icon: 'memory' }
      ]
    },
    {
      title: '03 // FACTORY & QUALITY',
      items: [
        { id: 'factory', number: '22', name: 'Factory Digital Twin', icon: 'factory', badge: 'Northfield' },
        { id: 'quality', number: '23', name: 'Quality & NDT Welds', icon: 'verified' },
        { id: 'test_validation', number: '24', name: 'Test & Validation', icon: 'biotech' },
        { id: 'rams_safety', number: '25', name: 'RAMS & Safety Case', icon: 'shield' },
        { id: 'certification', number: '26', name: 'Certification & TSI', icon: 'gavel' }
      ]
    },
    {
      title: '04 // OPERATIONS & SCENARIO LAB',
      items: [
        { id: 'fleet_operations', number: '27', name: 'Fleet Operations', icon: 'track_changes', badge: '5 Trains' },
        { id: 'maintenance', number: '28', name: 'Predictive Maintenance', icon: 'build_circle' },
        { id: 'sustainability', number: '30', name: 'Economics & Carbon', icon: 'eco' },
        { id: 'scenario_lab', number: '31', name: 'Scenario Lab & Trades', icon: 'science', badge: 'Pareto' }
      ]
    }
  ];
}
