import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-battery-hydrogen',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">battery_charging_full</mat-icon>
            <span>MODULE 13 // BATTERY-ELECTRIC & HYDROGEN MULTI-MODE TRAINS</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            Alternative Zero-Emission Traction Twins
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            Physics models for Battery Multiple Units (BEMU) and Hydrogen Fuel Cell Multiple Units (H2MU). State of Charge (SOC), State of Health (SOH), 700-bar H2 storage, and duty cycle range calculators.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <button 
            (click)="propulsionMode.set('BATTERY')"
            [class.bg-emerald-600]="propulsionMode() === 'BATTERY'"
            [class.text-white]="propulsionMode() === 'BATTERY'"
            [class.bg-slate-800]="propulsionMode() !== 'BATTERY'"
            [class.text-slate-300]="propulsionMode() !== 'BATTERY'"
            class="px-3 py-1.5 rounded border border-slate-700 transition cursor-pointer">
            Battery-Electric (BEMU)
          </button>
          <button 
            (click)="propulsionMode.set('HYDROGEN')"
            [class.bg-blue-600]="propulsionMode() === 'HYDROGEN'"
            [class.text-white]="propulsionMode() === 'HYDROGEN'"
            [class.bg-slate-800]="propulsionMode() !== 'HYDROGEN'"
            [class.text-slate-300]="propulsionMode() !== 'HYDROGEN'"
            class="px-3 py-1.5 rounded border border-slate-700 transition cursor-pointer">
            Hydrogen Fuel Cell (H2MU)
          </button>
        </div>
      </div>

      @if (propulsionMode() === 'BATTERY') {
        <!-- Battery BEMU Overview -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
          <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
            <div class="text-slate-500">PACK CAPACITY</div>
            <div class="text-2xl font-bold text-emerald-400 mt-1">700 kWh</div>
            <div class="text-[10px] text-slate-400 mt-1">Lithium Titanate (LTO) Cells</div>
          </div>
          <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
            <div class="text-slate-500">STATE OF CHARGE (SOC)</div>
            <div class="text-2xl font-bold text-white mt-1">{{ batterySoc() }}%</div>
            <div class="text-[10px] text-emerald-400 mt-1">Fast 4C Charging Active</div>
          </div>
          <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
            <div class="text-slate-500">OFF-WIRE RANGE</div>
            <div class="text-2xl font-bold text-cyan-300 mt-1">{{ (batterySoc() * 1.25).toFixed(0) }} km</div>
            <div class="text-[10px] text-slate-400 mt-1">Specific: 5.6 kWh/train-km</div>
          </div>
          <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
            <div class="text-slate-500">STATE OF HEALTH (SOH)</div>
            <div class="text-2xl font-bold text-emerald-400 mt-1">98.5%</div>
            <div class="text-[10px] text-slate-400 mt-1">20,000 Cycle Life (LTO)</div>
          </div>
        </div>

        <!-- Battery Technical Architecture -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
            <h3 class="font-bold text-white text-sm font-mono flex items-center gap-2">
              <mat-icon class="text-emerald-400">electric_car</mat-icon>
              <span>LTO BATTERY PACK ENERGY CHAIN</span>
            </h3>
            <div class="space-y-2 text-xs font-mono">
              <div class="p-3 bg-slate-950 rounded border border-slate-800">
                <div class="text-emerald-400 font-bold">Cell Chemistry: Lithium Titanate (LTO)</div>
                <div class="text-slate-300 text-[11px] mt-1">
                  High thermal stability, zero risk of thermal runaway, and ultra-fast 15-minute pantograph station recharging.
                </div>
              </div>
              <div class="p-3 bg-slate-950 rounded border border-slate-800">
                <div class="text-cyan-300 font-bold">DC Link Integration: 750 V DC</div>
                <div class="text-slate-300 text-[11px] mt-1">
                  Direct bidirectional coupling to traction inverters with regenerative braking capture efficiency &gt; 92%.
                </div>
              </div>
            </div>
          </div>

          <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
            <h3 class="font-bold text-white text-sm font-mono flex items-center gap-2">
              <mat-icon class="text-cyan-400">tune</mat-icon>
              <span>INTERACTIVE SOC DISCHARGE SIMULATOR</span>
            </h3>
            <div class="space-y-2 font-mono text-xs">
              <div class="flex justify-between text-slate-300">
                <span>Simulate Battery SOC:</span>
                <span class="font-bold text-cyan-300 text-sm">{{ batterySoc() }}%</span>
              </div>
              <input 
                type="range" 
                min="10" 
                max="100" 
                step="1" 
                [value]="batterySoc()" 
                (input)="batterySoc.set(+($any($event.target).value))"
                class="w-full accent-emerald-500 cursor-pointer" />
            </div>
          </div>
        </div>
      } @else {
        <!-- Hydrogen H2MU Overview -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
          <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
            <div class="text-slate-500">FUEL CELL POWER</div>
            <div class="text-2xl font-bold text-blue-400 mt-1">600 kW</div>
            <div class="text-[10px] text-slate-400 mt-1">Proton Exchange Membrane (PEM)</div>
          </div>
          <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
            <div class="text-slate-500">H2 TANK STORAGE</div>
            <div class="text-2xl font-bold text-white mt-1">700 kg</div>
            <div class="text-[10px] text-slate-400 mt-1">700 bar Type IV COPV Tanks</div>
          </div>
          <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
            <div class="text-slate-500">AUTONOMOUS RANGE</div>
            <div class="text-2xl font-bold text-emerald-400 mt-1">800 km</div>
            <div class="text-[10px] text-emerald-400 mt-1">0.24 kg H2 / train-km</div>
          </div>
          <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
            <div class="text-slate-500">REFUELLING DURATION</div>
            <div class="text-2xl font-bold text-white mt-1">12 min</div>
            <div class="text-[10px] text-slate-400 mt-1">350 / 700 bar Dispenser</div>
          </div>
        </div>
      }
    </div>
  `
})
export class BatteryHydrogenComponent {
  readonly twin = inject(RollingStockTwinService);
  readonly propulsionMode = signal<'BATTERY' | 'HYDROGEN'>('BATTERY');
  readonly batterySoc = signal<number>(94);
}
