import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-fleet-operations',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">track_changes</mat-icon>
            <span>MODULE 27 & 28 // OPERATIONAL DIGITAL TWIN & PREDICTIVE MAINTENANCE</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            Fleet Operations & Real-Time Telemetry Twin
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            Live operational telemetry tracking across the RSX-320 high-speed fleet. Explainable AI anomaly detection for bearings, wheelsets, traction converters, and pantograph contact force.
          </p>
        </div>

        <div class="flex items-center gap-3">
          @if (!twin.injectedAnomaly()) {
            <button 
              (click)="twin.injectBogieAnomaly()"
              class="px-3.5 py-2 bg-amber-950/80 hover:bg-amber-900 text-amber-300 border border-amber-800 rounded-lg text-xs font-mono flex items-center gap-2 shadow-sm transition cursor-pointer">
              <mat-icon class="text-sm text-amber-400">warning</mat-icon>
              <span>Inject Bogie Vibration Anomaly</span>
            </button>
          } @else {
            <button 
              (click)="twin.clearAnomaly()"
              class="px-3.5 py-2 bg-red-950 hover:bg-red-900 text-red-200 border border-red-700 rounded-lg text-xs font-mono flex items-center gap-2 shadow-sm transition cursor-pointer animate-pulse">
              <mat-icon class="text-sm text-red-400">error</mat-icon>
              <span>Vibration Anomaly Active [Click to Clear]</span>
            </button>
          }
        </div>
      </div>

      <!-- Fleet Status Grid (5 Trains) -->
      <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">directions_railway</mat-icon>
            <h2 class="font-bold text-white text-base">RSX-320 Operational Fleet Overview (5 Trainsets)</h2>
          </div>
          <span class="text-xs font-mono text-emerald-400 font-bold">
            Average Availability: 99.4%
          </span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3 text-xs font-mono">
          @for (train of twin.fleetTrainsets(); track train.id) {
            <div class="bg-slate-950 p-3.5 rounded-lg border border-slate-800 flex flex-col justify-between space-y-3">
              <div>
                <div class="flex items-center justify-between">
                  <span class="font-bold text-white">{{ train.id }}</span>
                  <span 
                    [class.bg-emerald-950]="train.status === 'IN_SERVICE'"
                    [class.text-emerald-300]="train.status === 'IN_SERVICE'"
                    [class.border-emerald-800]="train.status === 'IN_SERVICE'"
                    [class.bg-cyan-950]="train.status === 'TESTING'"
                    [class.text-cyan-300]="train.status === 'TESTING'"
                    [class.border-cyan-800]="train.status === 'TESTING'"
                    [class.bg-slate-900]="train.status === 'DEPOT'"
                    [class.text-slate-400]="train.status === 'DEPOT'"
                    [class.border-slate-700]="train.status === 'DEPOT'"
                    class="px-2 py-0.5 rounded border text-[9px] font-bold">
                    {{ train.status }}
                  </span>
                </div>
                <div class="text-[10px] text-slate-400 mt-1 truncate">{{ train.route }}</div>
              </div>

              <div class="space-y-1 text-[11px] pt-2 border-t border-slate-800/80">
                <div class="flex justify-between text-slate-300">
                  <span>Speed:</span>
                  <span class="text-cyan-300 font-bold">{{ train.speed_kmh }} km/h</span>
                </div>
                <div class="flex justify-between text-slate-300">
                  <span>Mileage:</span>
                  <span>{{ train.mileage_km.toLocaleString() }} km</span>
                </div>
                <div class="flex justify-between text-slate-300">
                  <span>Availability:</span>
                  <span class="text-emerald-400 font-bold">{{ train.availability_pct }}%</span>
                </div>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Live High-Speed Telemetry & Predictive Anomaly Console -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Real-Time Telemetry Gauges -->
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400 text-base animate-pulse">sensors</mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">RSX-320-001 REAL-TIME TELEMETRY STREAM</h3>
            </div>
            <span class="text-[10px] font-mono text-emerald-300 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
              100 Hz SAMPLING
            </span>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs font-mono">
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div class="text-slate-500">LINE VELOCITY</div>
              <div class="text-xl font-bold text-emerald-400 mt-1">{{ twin.telemetry().speed_kmh }} <span class="text-xs text-slate-400">km/h</span></div>
              <div class="text-[10px] text-slate-400 mt-1">Target: 320.0 km/h</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div class="text-slate-500">CATENARY VOLTAGE</div>
              <div class="text-xl font-bold text-white mt-1">{{ twin.telemetry().lineVoltage_kV }} <span class="text-xs text-slate-400">kV AC</span></div>
              <div class="text-[10px] text-slate-400 mt-1">Current: {{ twin.telemetry().catenaryCurrent_A }} A</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div class="text-slate-500">TRACTIVE EFFORT</div>
              <div class="text-xl font-bold text-cyan-300 mt-1">{{ twin.telemetry().tractiveEffort_kN }} <span class="text-xs text-slate-400">kN</span></div>
              <div class="text-[10px] text-slate-400 mt-1">Power: 7.94 MW</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div class="text-slate-500">PANTOGRAPH FORCE</div>
              <div class="text-xl font-bold text-white mt-1">{{ twin.telemetry().pantographContactForce_N }} <span class="text-xs text-slate-400">N</span></div>
              <div class="text-[10px] text-emerald-400 mt-1">Nominal (110-130 N)</div>
            </div>
          </div>
        </div>

        <!-- Predictive Maintenance Anomaly & Work Order Engine -->
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon [class.text-red-400]="twin.injectedAnomaly()" [class.text-emerald-400]="!twin.injectedAnomaly()">
                {{ twin.injectedAnomaly() ? 'error' : 'verified_user' }}
              </mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">PREDICTIVE MAINTENANCE ANOMALY DIAGNOSTIC</h3>
            </div>
            <span 
              [class.bg-red-950]="twin.injectedAnomaly()"
              [class.text-red-300]="twin.injectedAnomaly()"
              [class.border-red-800]="twin.injectedAnomaly()"
              [class.bg-emerald-950]="!twin.injectedAnomaly()"
              [class.text-emerald-300]="!twin.injectedAnomaly()"
              [class.border-emerald-800]="!twin.injectedAnomaly()"
              class="text-[10px] font-mono px-2 py-0.5 rounded border font-bold">
              {{ twin.injectedAnomaly() ? 'ALERT: ZONE D CRITICAL' : 'SYSTEM HEALTH: OPTIMAL' }}
            </span>
          </div>

          @if (twin.injectedAnomaly()) {
            <div class="space-y-3 font-mono text-xs">
              <div class="bg-red-950/40 p-3.5 rounded-lg border border-red-800 space-y-2">
                <div class="flex items-center justify-between text-red-300 font-bold">
                  <span>ANOMALY: Bogie 1 Axlebox Bearing Spalling</span>
                  <span>VIB: 14.8 mm/s² RMS</span>
                </div>
                <p class="text-slate-300 text-[11px]">
                  <strong>Explainable AI Diagnosis:</strong> Outer race ball pass frequency (BPFO) harmonic detected at 142.4 Hz with sidebands. Bearing thermal rise to 84.6°C.
                </p>
                <div class="text-[10px] text-red-400">
                  Remaining Useful Life (RUL): <strong>42.5 Operational Hours</strong> (Urgent action required).
                </div>
              </div>

              <!-- Automated Work Order Card -->
              <div class="bg-slate-950 p-3.5 rounded-lg border border-slate-800 space-y-1.5">
                <div class="flex items-center justify-between">
                  <span class="text-cyan-300 font-bold">WORK ORDER: WO-DEP-2026-9904</span>
                  <span class="text-emerald-400 font-bold text-[10px]">DISPATCHED</span>
                </div>
                <div class="text-slate-300">Temple Mills Depot &bull; Track 4 Overhaul Pit</div>
                <div class="text-[10px] text-slate-400">
                  Action: Replace Axlebox 1 Bearing Unit (Part: SKF-BOG-2026-AX1) during scheduled overnight layover.
                </div>
              </div>
            </div>
          } @else {
            <div class="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3 font-mono text-xs text-slate-300">
              <div class="flex items-center gap-2 text-emerald-400 font-bold">
                <mat-icon class="text-base">check_circle</mat-icon>
                <span>All Subsystems Operating within Baseline Tolerances</span>
              </div>
              <p class="text-[11px] text-slate-400">
                Continuous spectral vibration monitoring, motor winding temperatures, and door cycle current waveforms show zero abnormal degradation.
              </p>
              <div class="text-[10px] text-slate-500">
                Click "Inject Bogie Vibration Anomaly" above to test the autonomous predictive maintenance diagnostic loop.
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class FleetOperationsComponent {
  readonly twin = inject(RollingStockTwinService);
}
