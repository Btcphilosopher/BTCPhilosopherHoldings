import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-factory-twin',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">factory</mat-icon>
            <span>MODULE 22 // FACTORY DIGITAL TWIN & PRODUCTION FLOW (NORTHFIELD RAIL SYSTEMS)</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            Northfield Digital Factory & Assembly Line Twin
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            Complete digital shop floor representation across 7 manufacturing halls, 20 production workstations, and automated laser-welding robotic cells. Live takt time tracking and material genealogy.
          </p>
        </div>

        <div class="flex items-center gap-3 font-mono text-xs">
          <span class="px-2.5 py-1 bg-cyan-950 text-cyan-300 border border-cyan-800 rounded">
            TAKT TIME: 18.0 hrs / car
          </span>
          <span class="px-2.5 py-1 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded">
            FPY: 96.4%
          </span>
        </div>
      </div>

      <!-- Factory High-Level Performance Banner -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">ACTIVE PRODUCTION UNITS</div>
          <div class="text-2xl font-bold text-white mt-1">3 Trainsets</div>
          <div class="text-[10px] text-slate-400 mt-1">RSX-320-001, 002, 003</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">PLANT CAPACITY UTILIZATION</div>
          <div class="text-2xl font-bold text-cyan-300 mt-1">84.5%</div>
          <div class="text-[10px] text-emerald-400 mt-1">Optimal Throughput</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">ACTIVE ROBOTIC CELLS</div>
          <div class="text-2xl font-bold text-white mt-1">10 / 10 Active</div>
          <div class="text-[10px] text-emerald-400 mt-1">KUKA Laser Hybrid Cells</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">ACTIVE BOTTLENECK</div>
          <div class="text-2xl font-bold text-amber-400 mt-1">Station 06</div>
          <div class="text-[10px] text-slate-400 mt-1">Underframe Fit-out (+1.5h)</div>
        </div>
      </div>

      <!-- Interactive Production Stations Table & Shop Floor -->
      <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">view_kanban</mat-icon>
            <h2 class="font-bold text-white text-base">Northfield Assembly Stations & Live WIP Status</h2>
          </div>
          <span class="text-xs font-mono text-slate-400">Click Station to Inspect Work Order</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th class="py-2.5 px-3">Station #</th>
                <th class="py-2.5 px-3">Manufacturing Hall</th>
                <th class="py-2.5 px-3">Station Name</th>
                <th class="py-2.5 px-3">Cycle vs Takt</th>
                <th class="py-2.5 px-3">Active WIP Unit</th>
                <th class="py-2.5 px-3">Robots / Staff</th>
                <th class="py-2.5 px-3">Yield FPY</th>
                <th class="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 bg-slate-900/40 text-slate-300">
              @for (stn of twin.productionStations(); track stn.id) {
                <tr class="hover:bg-slate-800/50 transition">
                  <td class="py-2.5 px-3 font-bold text-cyan-300">{{ stn.id }}</td>
                  <td class="py-2.5 px-3 text-slate-400">{{ stn.hall }}</td>
                  <td class="py-2.5 px-3 text-white font-semibold">{{ stn.name }}</td>
                  <td class="py-2.5 px-3">
                    <span [class.text-amber-400]="stn.activeCycleTime_hrs > stn.taktTime_hrs" [class.text-emerald-400]="stn.activeCycleTime_hrs <= stn.taktTime_hrs" class="font-bold">
                      {{ stn.activeCycleTime_hrs }}h
                    </span>
                    <span class="text-slate-500"> / {{ stn.taktTime_hrs }}h</span>
                  </td>
                  <td class="py-2.5 px-3 text-slate-200">{{ stn.activeUnit }}</td>
                  <td class="py-2.5 px-3">{{ stn.assignedRobots }} robots &bull; {{ stn.assignedOperators }} tech</td>
                  <td class="py-2.5 px-3 text-emerald-400 font-bold">{{ stn.qualityFirstPassYield_pct }}%</td>
                  <td class="py-2.5 px-3">
                    @if (stn.status === 'OPTIMAL') {
                      <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px]">
                        OPTIMAL
                      </span>
                    } @else {
                      <span class="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 text-[10px]">
                        BOTTLENECK
                      </span>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Weld Digital Twin & Material Batch Traceability -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Weld Records Card -->
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">flash_on</mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">WELD DIGITAL TWIN & NDT INSPECTION</h3>
            </div>
            <span class="text-[10px] font-mono text-emerald-400 bg-emerald-950 border border-emerald-800 px-2 py-0.5 rounded">
              EN ISO 5817 LEVEL B
            </span>
          </div>

          <div class="space-y-3 text-xs font-mono">
            @for (weld of twin.weldRecords(); track weld.id) {
              <div class="bg-slate-950 p-3.5 rounded-lg border border-slate-800 space-y-2">
                <div class="flex items-center justify-between">
                  <span class="text-cyan-300 font-bold">Weld ID: {{ weld.id }}</span>
                  <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px]">
                    NDT {{ weld.ndtResult }}
                  </span>
                </div>
                <div class="text-slate-300">{{ weld.location }}</div>
                <div class="grid grid-cols-2 gap-2 text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
                  <div>Process: <span class="text-white">{{ weld.process }}</span></div>
                  <div>Material: <span class="text-white">{{ weld.material }}</span></div>
                  <div>Material Batch: <span class="text-cyan-300 font-bold">{{ weld.materialBatch }}</span></div>
                  <div>NDT Method: <span class="text-white">{{ weld.ndtMethod }}</span></div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Material Genealogy & Upstream Traceability -->
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">account_tree</mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">MATERIAL BATCH TO TRAINSET THREAD</h3>
            </div>
            <button 
              (click)="twin.setTab('digital_thread')"
              class="text-xs text-cyan-400 hover:text-cyan-300 font-mono flex items-center gap-1 cursor-pointer">
              <span>View Full Thread</span>
              <mat-icon class="text-xs">arrow_forward</mat-icon>
            </button>
          </div>

          <!-- Traceability Steps -->
          <div class="space-y-2 font-mono text-xs">
            <div class="flex items-center gap-3 p-2 bg-slate-950 rounded border border-slate-800">
              <span class="w-6 h-6 rounded-full bg-cyan-950 border border-cyan-700 flex items-center justify-center text-cyan-300 text-[10px] font-bold">1</span>
              <div>
                <div class="text-slate-200 font-bold">Material Batch: AL-83921</div>
                <div class="text-[10px] text-slate-400">EN AW-6005A-T6 Aluminium Alloy Extrusion Ingot</div>
              </div>
            </div>
            <div class="flex items-center gap-3 p-2 bg-slate-950 rounded border border-slate-800">
              <span class="w-6 h-6 rounded-full bg-cyan-950 border border-cyan-700 flex items-center justify-center text-cyan-300 text-[10px] font-bold">2</span>
              <div>
                <div class="text-slate-200 font-bold">Laser-Hybrid Weld: W-19382</div>
                <div class="text-[10px] text-slate-400">KUKA-LSR-CELL-02 (Underframe Inverter Beam)</div>
              </div>
            </div>
            <div class="flex items-center gap-3 p-2 bg-slate-950 rounded border border-slate-800">
              <span class="w-6 h-6 rounded-full bg-cyan-950 border border-cyan-700 flex items-center justify-center text-cyan-300 text-[10px] font-bold">3</span>
              <div>
                <div class="text-slate-200 font-bold">NDT Ultrasonic Inspection: I-88291</div>
                <div class="text-[10px] text-emerald-400">Zero Defect PASS (TÜV SÜD Certified)</div>
              </div>
            </div>
            <div class="flex items-center gap-3 p-2 bg-slate-950 rounded border border-slate-800">
              <span class="w-6 h-6 rounded-full bg-emerald-950 border border-emerald-700 flex items-center justify-center text-emerald-300 text-[10px] font-bold">4</span>
              <div>
                <div class="text-emerald-300 font-bold">Assembled in Trainset: RSX-320-001 (Car 2)</div>
                <div class="text-[10px] text-slate-400">Integrated with SiC Traction Converter TRC-00421</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class FactoryTwinComponent {
  readonly twin = inject(RollingStockTwinService);
}
