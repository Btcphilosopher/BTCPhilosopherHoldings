import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-braking-system',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">airline_stops</mat-icon>
            <span>MODULE 11 // BRAKE BLENDING & DECELERATION DYNAMICS</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            Braking Systems & Blended Deceleration Twin
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            Integrated electrodynamic regenerative, electropneumatic disc, and magnetic track braking. Knorr-Bremse EBCU electronic blending with SIL 4 emergency safety loops.
          </p>
        </div>

        <div class="flex items-center gap-3">
          <button 
            (click)="runEmergencyBraking()"
            [disabled]="isSimulating()"
            class="px-4 py-2 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white rounded-lg text-xs font-medium font-mono flex items-center gap-2 shadow-sm transition cursor-pointer disabled:opacity-50">
            <mat-icon class="text-sm">emergency</mat-icon>
            <span>{{ isSimulating() ? 'Simulating Emergency Braking...' : 'Run 320&rarr;0 km/h Emergency Stop' }}</span>
          </button>
        </div>
      </div>

      <!-- Key Braking Metrics Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">EMERGENCY STOP (320 KM/H)</div>
          <div class="text-2xl font-bold text-emerald-400 mt-1">{{ twin.emergencyBrakingDistance_m() }} m</div>
          <div class="text-[10px] text-emerald-400 mt-1">TSI Limit &le; 3,050 m (PASS)</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">MEAN DECELERATION</div>
          <div class="text-2xl font-bold text-white mt-1">1.35 m/s²</div>
          <div class="text-[10px] text-slate-400 mt-1">Comfortable Service: 1.05 m/s²</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">REGENERATIVE RECOVERY</div>
          <div class="text-2xl font-bold text-cyan-300 mt-1">84.2%</div>
          <div class="text-[10px] text-slate-400 mt-1">18.2 kWh recovered per stop</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">MAX DISC TEMPERATURE</div>
          <div class="text-2xl font-bold text-amber-400 mt-1">480 °C</div>
          <div class="text-[10px] text-slate-400 mt-1">Limit: 750 °C (Carbon-Steel)</div>
        </div>
      </div>

      <!-- Brake Blending Management & Deceleration Curves -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Brake Blending Mode Visualizer -->
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">tune</mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">KNORR-BREMSE EBCU BLENDING STRATEGY</h3>
            </div>
            <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
              SIL 4 ARCHITECTURE
            </span>
          </div>

          <div class="space-y-3 text-xs font-mono">
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
              <div class="flex justify-between items-center">
                <span class="text-emerald-400 font-bold">1. Electrodynamic Regenerative Brake (ED)</span>
                <span class="text-emerald-300 font-bold">Priority #1 (0-150 kN)</span>
              </div>
              <p class="text-slate-400 text-[11px]">
                Motors act as generators, returning kinetic energy to the 25kV catenary. Zero mechanical wear on pads and discs. Active down to 5 km/h.
              </p>
              <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div class="bg-emerald-500 h-full rounded-full" style="width: 85%"></div>
              </div>
            </div>

            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
              <div class="flex justify-between items-center">
                <span class="text-cyan-400 font-bold">2. Electropneumatic Disc Friction Brake (EP)</span>
                <span class="text-cyan-300 font-bold">Blending Supplement</span>
              </div>
              <p class="text-slate-400 text-[11px]">
                Applied automatically when ED braking reaches adhesion or inverter limits, or below 5 km/h for precision station stop.
              </p>
              <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div class="bg-cyan-500 h-full rounded-full" style="width: 40%"></div>
              </div>
            </div>

            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
              <div class="flex justify-between items-center">
                <span class="text-rose-400 font-bold">3. SIL 4 Hardwired Emergency Brake</span>
                <span class="text-rose-300 font-bold">Full Application</span>
              </div>
              <p class="text-slate-400 text-[11px]">
                De-energize to brake pneumatic line. Overrides all TCMS software commands. Maximum brake cylinder pressure: 3.8 bar.
              </p>
            </div>
          </div>
        </div>

        <!-- Stopping Distance Profile from 320 km/h -->
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-rose-400">speed</mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">320 &rarr; 0 KM/H STOPPING DECELERATION PROFILE</h3>
            </div>
            <span class="text-[11px] font-mono text-emerald-400 font-bold">
              Stopping: {{ twin.emergencyBrakingDistance_m() }} m
            </span>
          </div>

          <!-- Deceleration Curve SVG -->
          <div class="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <svg viewBox="0 0 500 220" class="w-full h-52 select-none font-mono text-[10px]">
              <!-- Grid lines -->
              @for (y of [30, 70, 110, 150, 190]; track y) {
                <line x1="40" [attr.y1]="y" x2="480" [attr.y2]="y" stroke="#1e293b" stroke-dasharray="2 2" />
              }
              <line x1="40" y1="190" x2="480" y2="190" stroke="#475569" stroke-width="1.5" />
              <line x1="40" y1="20" x2="40" y2="190" stroke="#475569" stroke-width="1.5" />

              <!-- Speed axis labels -->
              <text x="35" y="30" fill="#22d3ee" text-anchor="end">320 km/h</text>
              <text x="35" y="110" fill="#64748b" text-anchor="end">160</text>
              <text x="35" y="190" fill="#64748b" text-anchor="end">0</text>

              <text x="40" y="205" fill="#64748b" text-anchor="middle">0m</text>
              <text x="180" y="205" fill="#64748b" text-anchor="middle">1000m</text>
              <text x="320" y="205" fill="#64748b" text-anchor="middle">2000m</text>
              <text x="440" y="205" fill="#10b981" font-weight="bold" text-anchor="middle">2980m (Full Stop)</text>

              <!-- Stopping Curve -->
              <path d="M 40 30 Q 240 60 440 190" fill="none" stroke="#f43f5e" stroke-width="3" />
              <!-- TSI 3050m Limit Line -->
              <line x1="455" y1="20" x2="455" y2="190" stroke="#f59e0b" stroke-width="1.5" stroke-dasharray="4 2" />
              <text x="455" y="15" fill="#f59e0b" font-size="8" text-anchor="middle">TSI Limit (3,050m)</text>

              <circle cx="440" cy="190" r="5" fill="#10b981" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  `
})
export class BrakingSystemComponent {
  readonly twin = inject(RollingStockTwinService);
  readonly isSimulating = signal<boolean>(false);

  runEmergencyBraking() {
    this.isSimulating.set(true);
    setTimeout(() => {
      this.isSimulating.set(false);
    }, 1200);
  }
}
