import { Component, ChangeDetectionStrategy, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-report-modal',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <!-- Modal Backdrop -->
    <div 
      role="dialog"
      aria-modal="true"
      tabindex="0"
      (click)="closed.emit()" 
      (keydown.escape)="closed.emit()" 
      class="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div 
        tabindex="0"
        role="document"
        (click)="$event.stopPropagation()" 
        (keydown)="$event.stopPropagation()"
        class="w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        <!-- Header -->
        <div class="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">description</mat-icon>
            <h2 class="font-bold text-white text-base font-mono">Formal Engineering Verification Report</h2>
          </div>
          <div class="flex items-center gap-2">
            <button 
              (click)="downloadJson()"
              class="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-mono flex items-center gap-1 cursor-pointer">
              <mat-icon class="text-xs">download</mat-icon>
              <span>Export JSON</span>
            </button>
            <button (click)="closed.emit()" class="text-slate-400 hover:text-white cursor-pointer ml-2">
              <mat-icon>close</mat-icon>
            </button>
          </div>
        </div>

        <!-- Report Content -->
        <div class="p-6 overflow-y-auto space-y-6 font-mono text-xs text-slate-300 bg-slate-950/40">
          <!-- Report Title Block -->
          <div class="border-b border-slate-800 pb-4 flex justify-between items-start">
            <div>
              <div class="text-[10px] text-slate-500 uppercase">DOCUMENT REF: RSX320-ENG-REP-2026-V8</div>
              <h1 class="text-lg font-bold text-white mt-0.5">RSX-320 HIGH-SPEED EMU TECHNICAL DESIGN & DIGITAL TWIN DOSSIER</h1>
              <div class="text-[11px] text-cyan-400 mt-1">Programme Authority: Northfield Rail Systems Engineering Directorate</div>
            </div>
            <div class="text-right text-[10px] text-slate-400">
              <div>Date: {{ currentDate }}</div>
              <div>Revision: 8.2 (Design Freeze)</div>
              <div class="text-emerald-400 font-bold">STATUS: AUDITED & SIGNED</div>
            </div>
          </div>

          <!-- Section 1: Vehicle Technical Specifications -->
          <div class="space-y-2">
            <h3 class="text-cyan-400 font-bold uppercase text-xs">1. Reference Vehicle Specifications</h3>
            <div class="bg-slate-950 p-3.5 rounded border border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px]">
              <div><span class="text-slate-500">Vehicle Type:</span> <span class="text-white font-bold">8-Car High-Speed EMU</span></div>
              <div><span class="text-slate-500">Design Speed:</span> <span class="text-white font-bold">320 km/h</span></div>
              <div><span class="text-slate-500">Train Length:</span> <span class="text-white font-bold">{{ twin.totalLength_m() }} m</span></div>
              <div><span class="text-slate-500">Tare Mass:</span> <span class="text-white font-bold">{{ twin.totalTareMass_t() }} t</span></div>
              <div><span class="text-slate-500">Traction Power:</span> <span class="text-white font-bold">{{ twin.totalTractionPower_MW() }} MW</span></div>
              <div><span class="text-slate-500">Max Axle Load:</span> <span class="text-emerald-400 font-bold">{{ twin.maxAxleLoad_t() }} t/axle</span></div>
              <div><span class="text-slate-500">Passenger Seats:</span> <span class="text-white font-bold">{{ twin.totalSeats() }} seats</span></div>
              <div><span class="text-slate-500">TSI Status:</span> <span class="text-emerald-400 font-bold">Compliant (EU 1302)</span></div>
            </div>
          </div>

          <!-- Section 2: Requirements Verification & Traceability -->
          <div class="space-y-2">
            <h3 class="text-cyan-400 font-bold uppercase text-xs">2. Requirements Verification Summary</h3>
            <div class="bg-slate-950 p-3.5 rounded border border-slate-800 space-y-2 text-[11px]">
              <div class="flex justify-between">
                <span>Total Engineering Requirements:</span>
                <span class="text-white font-bold">{{ twin.requirementsTotal() }}</span>
              </div>
              <div class="flex justify-between">
                <span>Verified by Simulation / Testing / Inspection:</span>
                <span class="text-emerald-400 font-bold">{{ twin.requirementsVerified() }} ({{ ((twin.requirementsVerified()/twin.requirementsTotal())*100).toFixed(1) }}%)</span>
              </div>
              <div class="flex justify-between">
                <span>Open Engineering Change Requests (ECRs):</span>
                <span class="text-amber-400 font-bold">{{ twin.openECRs() }}</span>
              </div>
            </div>
          </div>

          <!-- Section 3: Digital Thread Traceability Signature -->
          <div class="space-y-2">
            <h3 class="text-cyan-400 font-bold uppercase text-xs">3. Digital Thread Chain of Custody</h3>
            <div class="bg-slate-950 p-3 rounded border border-slate-800 text-[10px] text-slate-300 leading-relaxed">
              TSI LOC&PAS Mandate &rarr; REQ-TRACTION-001 &rarr; SiC Converter TRC-00421 &rarr; Batch AL-83921 &rarr; Laser Weld W-19382 &rarr; NDT Ultrasonic Inspection I-88291 (TÜV SÜD Pass) &rarr; Dyno Test T-3818 &rarr; Trainset RSX-320-001 &rarr; Operational Telemetry &rarr; Temple Mills Maintenance Record.
            </div>
          </div>
        </div>

        <!-- Footer -->
        <div class="px-5 py-3 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button (click)="closed.emit()" class="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded text-xs font-mono cursor-pointer">
            Close Report
          </button>
        </div>
      </div>
    </div>
  `
})
export class ReportModalComponent {
  readonly twin = inject(RollingStockTwinService);
  readonly closed = output<void>();
  readonly currentDate = new Date().toISOString().split('T')[0];



  downloadJson() {
    const reportData = {
      programme: this.twin.programmeName(),
      designFreezePct: this.twin.designFreezePct(),
      requirements: { total: this.twin.requirementsTotal(), verified: this.twin.requirementsVerified() },
      metrics: {
        maxSpeed_kmh: this.twin.targetMaxSpeed_kmh(),
        length_m: this.twin.totalLength_m(),
        tareMass_t: this.twin.totalTareMass_t(),
        tractionPower_MW: this.twin.totalTractionPower_MW(),
        axleLoad_t: this.twin.maxAxleLoad_t(),
        seats: this.twin.totalSeats()
      },
      digitalThreadRef: 'REQ-TRACTION-001 -> TRC-00421 -> AL-83921 -> W-19382 -> I-88291 -> T-3818',
      generatedAt: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RSX320_Digital_Twin_Report_${this.currentDate}.json`;
    a.click();
    window.URL.revokeObjectURL(url);
  }
}
