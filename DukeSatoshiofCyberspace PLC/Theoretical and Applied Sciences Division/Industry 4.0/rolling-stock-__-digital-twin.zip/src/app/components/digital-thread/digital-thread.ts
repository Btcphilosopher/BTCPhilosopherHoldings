import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-digital-thread',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">hub</mat-icon>
            <span>MODULE 32 // DIGITAL THREAD & END-TO-END SYSTEM TRACEABILITY</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            The Complete Digital Thread
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            "ONE TRAIN. ONE DIGITAL THREAD. ONE ENGINEERING MODEL." Unbroken traceability linking requirements to CAD, manufacturing batch, NDT welds, virtual tests, TSI certification, live operational telemetry, and predictive depot work orders.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="px-2.5 py-1 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded">
            THREAD INTEGRITY: 100%
          </span>
          <span class="px-2.5 py-1 bg-cyan-950 text-cyan-300 border border-cyan-800 rounded">
            AUDIT TRAIL: IMMUTABLE
          </span>
        </div>
      </div>

      <!-- Interactive Digital Thread Pipeline Map -->
      <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
        <div class="flex items-center justify-between">
          <h2 class="font-bold text-white text-sm font-mono flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-base">alt_route</mat-icon>
            <span>INTERACTIVE THREAD PIPELINE (Click any stage to inspect node)</span>
          </h2>
          <span class="text-xs font-mono text-slate-400">Selected: {{ selectedNode().label }}</span>
        </div>

        <!-- Horizontal Flow Nodes -->
        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 text-xs font-mono">
          @for (node of threadNodes; track node.id; let idx = $index) {
            <button 
              (click)="selectedNode.set(node)"
              [class.bg-cyan-950]="selectedNode().id === node.id"
              [class.border-cyan-500]="selectedNode().id === node.id"
              [class.text-cyan-200]="selectedNode().id === node.id"
              [class.bg-slate-950]="selectedNode().id !== node.id"
              [class.border-slate-800]="selectedNode().id !== node.id"
              [class.text-slate-300]="selectedNode().id !== node.id"
              class="p-3 rounded-lg border text-left flex flex-col justify-between transition cursor-pointer hover:border-slate-600 group">
              <div>
                <div class="flex items-center justify-between text-[10px] text-slate-500 group-hover:text-slate-400">
                  <span>STAGE {{ idx + 1 < 10 ? '0' + (idx + 1) : idx + 1 }}</span>
                  <mat-icon class="text-xs text-cyan-400">{{ node.icon }}</mat-icon>
                </div>
                <div class="font-bold text-slate-100 text-xs mt-1 truncate">{{ node.label }}</div>
              </div>
              <div class="text-[10px] text-cyan-400 mt-2 truncate font-semibold">{{ node.code }}</div>
            </button>
          }
        </div>
      </div>

      <!-- Node Detail Inspector Card -->
      <div class="bg-slate-900/90 border border-slate-800 p-6 rounded-xl space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-lg bg-cyan-950 border border-cyan-700 flex items-center justify-center text-cyan-400">
              <mat-icon>{{ selectedNode().icon }}</mat-icon>
            </div>
            <div>
              <div class="text-[11px] font-mono text-cyan-400 font-bold uppercase">{{ selectedNode().stage }}</div>
              <h3 class="text-lg font-bold text-white font-mono">{{ selectedNode().title }}</h3>
            </div>
          </div>
          <span class="px-3 py-1 rounded bg-slate-950 text-slate-200 border border-slate-800 font-mono text-xs">
            Ref: {{ selectedNode().code }}
          </span>
        </div>

        <p class="text-sm text-slate-300">
          {{ selectedNode().description }}
        </p>

        <!-- Technical Metadata Key-Value Matrix -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3 border-t border-slate-800 text-xs font-mono">
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div class="text-slate-500">UPSTREAM ARTIFACT</div>
            <div class="font-bold text-slate-200 mt-1">{{ selectedNode().upstream }}</div>
          </div>
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div class="text-slate-500">DOWNSTREAM CONSUMER</div>
            <div class="font-bold text-cyan-300 mt-1">{{ selectedNode().downstream }}</div>
          </div>
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div class="text-slate-500">GOVERNANCE & CERTIFICATION</div>
            <div class="font-bold text-emerald-400 mt-1">{{ selectedNode().governance }}</div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class DigitalThreadComponent {
  readonly twin = inject(RollingStockTwinService);

  readonly threadNodes = [
    {
      id: 'req',
      stage: '01. REQUIREMENT CAPTURE',
      label: 'Requirement',
      code: 'REQ-TRACTION-001',
      title: 'TSI Acceleration & Tractive Power Mandate',
      icon: 'fact_check',
      description: 'Vehicle must accelerate from 0 to 320 km/h in ≤ 240 seconds under AW2 reference load at nominal 25 kV catenary.',
      upstream: 'TSI LOC&PAS Regulation (EU 1302/2014)',
      downstream: 'Traction Inverter Specification TRC-00421',
      governance: 'Verified via Multiphysics Simulation SIM-TRAC-320'
    },
    {
      id: 'cad',
      stage: '02. CAD & ARCHITECTURE',
      label: 'CAD Model',
      code: 'CAD-TRC-REV4.step',
      title: 'Underframe SiC Inverter Mounting Architecture',
      icon: 'architecture',
      description: '3D CAD volume envelope, weight distribution (840 kg), and dynamic vibration mounts on Car 2 underframe.',
      upstream: 'REQ-TRACTION-001',
      downstream: 'Extruded Aluminium Bodyshell Beam CB-001',
      governance: 'PLM Engineering Freeze 82% (Catia V6 / Teamcenter)'
    },
    {
      id: 'mat',
      stage: '03. RAW MATERIAL',
      label: 'Material Batch',
      code: 'AL-83921',
      title: 'EN AW-6005A-T6 Structural Aluminium Ingot',
      icon: 'category',
      description: 'Certified high-strength extruded aluminium alloy batch with verified yield strength Rp0.2 ≥ 225 MPa.',
      upstream: 'Extrusion Plant A Supplier Specification',
      downstream: 'Laser-Hybrid Weld W-19382',
      governance: 'EN 10204 Type 3.1 Material Certificate'
    },
    {
      id: 'weld',
      stage: '04. ROBOTIC WELD',
      label: 'Weld Seam',
      code: 'W-19382',
      title: 'Robotic Laser-Hybrid Long-Seam Weld (Car 2)',
      icon: 'flash_on',
      description: 'Automated 12.4m longitudinal fillet weld performed by KUKA Laser Cell 02 at Northfield Hall 2.',
      upstream: 'Aluminium Batch AL-83921',
      downstream: 'NDT Ultrasonic Inspection I-88291',
      governance: 'EN 15085-2 CL1 Welding Quality Standard'
    },
    {
      id: 'insp',
      stage: '05. QUALITY NDT',
      label: 'Inspection Record',
      code: 'I-88291',
      title: 'Phased Array Ultrasonic & Visual NDT',
      icon: 'verified',
      description: '100% volumetric inspection of Weld W-19382. 0 porosity defects detected. Certified EN ISO 5817 Level B.',
      upstream: 'Weld W-19382',
      downstream: 'Full Power Dynamic Bench Test T-3818',
      governance: 'TÜV SÜD Rail Notified Body Audit'
    },
    {
      id: 'test',
      stage: '06. TEST & VALIDATION',
      label: 'Test Result',
      code: 'T-3818',
      title: 'Full-Power Dyno Bench Test (2,000 kW)',
      icon: 'biotech',
      description: 'Verified 98.8% inverter efficiency at 320 km/h operating point and thermal equilibrium at 74°C.',
      upstream: 'Converter SN-TRC-2026-0814',
      downstream: 'TSI Vehicle Certificate NB-0035',
      governance: 'IEC 61287-1 Power Converters Test Dossier'
    },
    {
      id: 'ops',
      stage: '07. OPERATIONAL TWIN',
      label: 'Live Telemetry',
      code: 'RSX-320-001',
      title: 'High-Frequency In-Service Sensor Streaming',
      icon: 'sensors',
      description: 'Operational telemetry on Eurostar Paris-London line: 318.4 km/h speed, 25.4 kV line voltage, 54°C bearing temps.',
      upstream: 'Commissioned Trainset RSX-320-001',
      downstream: 'Predictive Anomaly Classifier',
      governance: 'EN 50126 RAMS Fleet Monitoring'
    },
    {
      id: 'maint',
      stage: '08. PREDICTIVE MAINT',
      label: 'Work Order',
      code: 'WO-DEP-2026-9904',
      title: 'Temple Mills Depot Bearing Overhaul',
      icon: 'build_circle',
      description: 'Automated work order triggered by vibration anomaly detection. Scheduled bearing replacement in 48h.',
      upstream: 'Bogie 1 Vibration Telemetry Peak (14.8 mm/s²)',
      downstream: 'Depot Overhaul Release & Thread Closure',
      governance: 'ISO 55001 Asset Management Framework'
    }
  ];

  readonly selectedNode = signal(this.threadNodes[0]);
}
