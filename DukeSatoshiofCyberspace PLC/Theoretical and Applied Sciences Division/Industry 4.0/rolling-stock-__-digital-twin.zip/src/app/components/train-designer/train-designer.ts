import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-train-designer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Title & Formation Presets -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">view_carousel</mat-icon>
            <span>MODULE 03 // TRAIN CONFIGURATOR & FORMATION ARCHITECTURE</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            Formation Architecture & Vehicle Composition
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            Construct and balance trainsets from modular vehicle units. Dynamic auto-calculation of length, tare/gross mass, axle loads, traction power, seats, and braking capacity.
          </p>
        </div>

        <!-- Presets -->
        <div class="flex items-center flex-wrap gap-2">
          <span class="text-xs text-slate-400 font-mono">PRESETS:</span>
          <button 
            (click)="twin.loadPresetFormation('RSX_320_8CAR')"
            class="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-mono transition cursor-pointer">
            RSX-320 (8-Car EMU)
          </button>
          <button 
            (click)="twin.loadPresetFormation('RSX_320_10CAR')"
            class="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-mono transition cursor-pointer">
            RSX-320 (10-Car Long)
          </button>
          <button 
            (click)="twin.loadPresetFormation('REGIONAL_BEMU')"
            class="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-mono transition cursor-pointer">
            Regional BEMU (Battery)
          </button>
          <button 
            (click)="twin.loadPresetFormation('TRANSALPINE_H2MU')"
            class="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-mono transition cursor-pointer">
            Trans-Alpine H2MU (H2)
          </button>
        </div>
      </div>

      <!-- Real-Time Synthesized Metrics Dashboard -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs font-mono">
        <div class="bg-slate-900/90 border border-slate-800 p-3 rounded-lg">
          <div class="text-slate-500">TRAINSET LENGTH</div>
          <div class="text-lg font-bold text-white mt-1">{{ twin.totalLength_m() }} m</div>
          <div class="text-[10px] text-slate-400 mt-0.5">{{ twin.cars().length }} Vehicles</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-3 rounded-lg">
          <div class="text-slate-500">TARE / GROSS MASS</div>
          <div class="text-lg font-bold text-white mt-1">{{ twin.totalTareMass_t() }} / {{ twin.totalGrossMass_t() }} t</div>
          <div class="text-[10px] text-slate-400 mt-0.5">Payload: {{ (twin.totalGrossMass_t() - twin.totalTareMass_t()).toFixed(1) }} t</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-3 rounded-lg">
          <div class="text-slate-500">TOTAL AXLES</div>
          <div class="text-lg font-bold text-white mt-1">{{ twin.totalAxles() }} Axles</div>
          <div class="text-[10px] text-slate-400 mt-0.5">{{ twin.cars().length * 2 }} Bogies</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-3 rounded-lg">
          <div class="text-slate-500">MAX AXLE LOAD</div>
          <div class="text-lg font-bold text-cyan-300 mt-1">{{ twin.maxAxleLoad_t() }} t/axle</div>
          <div class="text-[10px] text-emerald-400 mt-0.5">TSI Limit &le; 17.0 t</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-3 rounded-lg">
          <div class="text-slate-500">TRACTION POWER</div>
          <div class="text-lg font-bold text-white mt-1">{{ twin.totalTractionPower_MW() }} MW</div>
          <div class="text-[10px] text-slate-400 mt-0.5">{{ twin.powerToWeight_kWt() }} kW/tonne</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-3 rounded-lg">
          <div class="text-slate-500">SEAT CAPACITY</div>
          <div class="text-lg font-bold text-white mt-1">{{ twin.totalSeats() }} Seats</div>
          <div class="text-[10px] text-slate-400 mt-0.5">{{ twin.totalPantographs() }} Pantograph(s)</div>
        </div>
      </div>

      <!-- Interactive 2D Train Formation Elevation Visualizer -->
      <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">directions_railway</mat-icon>
            <h2 class="font-bold text-white text-sm font-mono">FORMATION 2D CAD SCHEMATIC (Click Vehicle to Inspect)</h2>
          </div>
          <div class="flex items-center gap-3 text-xs font-mono text-slate-400">
            <span class="flex items-center gap-1"><span class="w-2.5 h-2.5 rounded-sm bg-cyan-500"></span> Motor Bogie</span>
            <span class="flex items-center gap-1"><span class="w-2.5 h-2.5 rounded-sm bg-slate-600"></span> Trailer Bogie</span>
            <span class="flex items-center gap-1"><mat-icon class="text-xs text-amber-400">bolt</mat-icon> Pantograph</span>
          </div>
        </div>

        <!-- SVG 2D Elevation View -->
        <div class="bg-slate-950 p-4 rounded-xl border border-slate-800 overflow-x-auto">
          <div class="min-w-[900px]">
            <svg viewBox="0 0 1000 160" class="w-full h-44 select-none">
              <!-- Rail and Ballast Bed -->
              <rect x="0" y="140" width="1000" height="8" fill="#1e293b" />
              <line x1="0" y1="139" x2="1000" y2="139" stroke="#64748b" stroke-width="2" />
              <!-- Catenary Wire -->
              <line x1="0" y1="18" x2="1000" y2="18" stroke="#334155" stroke-dasharray="8 4" stroke-width="1.5" />

              @let carWidth = 960 / twin.cars().length;
              @for (car of twin.cars(); track car.id; let idx = $index) {
                @let startX = 20 + (idx * carWidth);
                @let isSelected = twin.selectedCarIndex() === idx;

                <g (click)="twin.selectedCarIndex.set(idx)" class="cursor-pointer group">
                  <!-- Carbody Shell -->
                  <rect 
                    [attr.x]="startX + 2" 
                    y="45" 
                    [attr.width]="carWidth - 4" 
                    height="68" 
                    [attr.rx]="idx === 0 || idx === twin.cars().length - 1 ? 12 : 3"
                    [attr.fill]="isSelected ? '#0f3a58' : '#0f172a'" 
                    [attr.stroke]="isSelected ? '#06b6d4' : '#334155'" 
                    stroke-width="2" 
                    class="transition-colors group-hover:stroke-cyan-400" />

                  <!-- Streamlined Cab Nose for End Vehicles -->
                  @if (idx === 0) {
                    <!-- Driving Cab A (Left) -->
                    <path [attr.d]="'M ' + (startX + 2) + ' 113 Q ' + (startX - 8) + ' 113 ' + (startX - 14) + ' 95 Q ' + (startX - 18) + ' 70 ' + (startX + 14) + ' 45 Z'" 
                          [attr.fill]="isSelected ? '#0e4369' : '#1e293b'" 
                          [attr.stroke]="isSelected ? '#06b6d4' : '#334155'" stroke-width="2" />
                    <!-- Windscreen -->
                    <polygon [attr.points]="(startX - 6) + ',78 ' + (startX + 8) + ',55 ' + (startX + 18) + ',55 ' + (startX + 8) + ',78'" fill="#38bdf8" opacity="0.8" />
                  }

                  @if (idx === twin.cars().length - 1) {
                    <!-- Driving Cab B (Right) -->
                    <path [attr.d]="'M ' + (startX + carWidth - 2) + ' 113 Q ' + (startX + carWidth + 8) + ' 113 ' + (startX + carWidth + 14) + ' 95 Q ' + (startX + carWidth + 18) + ' 70 ' + (startX + carWidth - 14) + ' 45 Z'" 
                          [attr.fill]="isSelected ? '#0e4369' : '#1e293b'" 
                          [attr.stroke]="isSelected ? '#06b6d4' : '#334155'" stroke-width="2" />
                    <!-- Windscreen -->
                    <polygon [attr.points]="(startX + carWidth + 6) + ',78 ' + (startX + carWidth - 8) + ',55 ' + (startX + carWidth - 18) + ',55 ' + (startX + carWidth - 8) + ',78'" fill="#38bdf8" opacity="0.8" />
                  }

                  <!-- Windows Strip -->
                  @for (w of [1, 2, 3, 4]; track w) {
                    <rect 
                      [attr.x]="startX + 10 + (w * ((carWidth - 30) / 5))" 
                      y="58" 
                      [attr.width]="(carWidth - 30) / 7" 
                      height="14" 
                      rx="2" 
                      fill="#0284c7" 
                      opacity="0.4" />
                  }

                  <!-- Doors -->
                  <rect [attr.x]="startX + 8" y="52" width="10" height="58" rx="1" fill="#1e293b" stroke="#475569" stroke-width="1" />
                  <rect [attr.x]="startX + carWidth - 18" y="52" width="10" height="58" rx="1" fill="#1e293b" stroke="#475569" stroke-width="1" />

                  <!-- Pantograph (if fitted) -->
                  @if (car.hasPantograph) {
                    <path [attr.d]="'M ' + (startX + (carWidth/2) - 15) + ' 45 L ' + (startX + (carWidth/2)) + ' 22 L ' + (startX + (carWidth/2) + 15) + ' 19'" 
                          stroke="#f59e0b" stroke-width="2.5" fill="none" />
                    <line [attr.x1]="startX + (carWidth/2) - 10" y1="18" [attr.x2]="startX + (carWidth/2) + 20" y2="18" stroke="#f59e0b" stroke-width="3" />
                  }

                  <!-- Roof HVAC Pod -->
                  <rect [attr.x]="startX + 24" y="38" [attr.width]="carWidth - 48" height="7" rx="2" fill="#334155" />

                  <!-- Bogie 1 (Left Wheelset) -->
                  <rect [attr.x]="startX + 12" y="113" width="28" height="8" rx="2" [attr.fill]="car.isMotorized ? '#06b6d4' : '#64748b'" />
                  <circle [attr.cx]="startX + 16" cy="130" r="9" fill="#334155" stroke="#94a3b8" stroke-width="2" />
                  <circle [attr.cx]="startX + 36" cy="130" r="9" fill="#334155" stroke="#94a3b8" stroke-width="2" />

                  <!-- Bogie 2 (Right Wheelset) -->
                  <rect [attr.x]="startX + carWidth - 40" y="113" width="28" height="8" rx="2" [attr.fill]="car.isMotorized ? '#06b6d4' : '#64748b'" />
                  <circle [attr.cx]="startX + carWidth - 36" cy="130" r="9" fill="#334155" stroke="#94a3b8" stroke-width="2" />
                  <circle [attr.cx]="startX + carWidth - 16" cy="130" r="9" fill="#334155" stroke="#94a3b8" stroke-width="2" />

                  <!-- Car Label -->
                  <text [attr.x]="startX + (carWidth / 2)" y="86" text-anchor="middle" fill="#e2e8f0" font-size="10" font-family="monospace" font-weight="bold">
                    C{{ idx + 1 }}
                  </text>
                  <text [attr.x]="startX + (carWidth / 2)" y="98" text-anchor="middle" [attr.fill]="isSelected ? '#38bdf8' : '#94a3b8'" font-size="8" font-family="monospace">
                    {{ car.type === 'MOTOR_CAR' ? '2.0 MW' : (car.type === 'SERVICE_CAR' ? 'BISTRO' : (car.type === 'BATTERY_CAR' ? 'BATT' : 'TRAILER')) }}
                  </text>
                </g>
              }
            </svg>
          </div>
        </div>
      </div>

      <!-- Vehicle Detail Inspector & Formation Modification Controls -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Selected Car Inspector -->
        @let selectedCar = twin.cars()[twin.selectedCarIndex()];
        <div class="lg:col-span-2 bg-slate-900/80 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">tune</mat-icon>
              <h3 class="font-bold text-white text-base">
                Selected Vehicle: Car {{ twin.selectedCarIndex() + 1 }} — {{ selectedCar.designation }}
              </h3>
            </div>
            <div class="flex items-center gap-2">
              <button 
                (click)="twin.setTab('bogies')"
                class="px-2.5 py-1 bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-800 rounded text-xs font-mono flex items-center gap-1 cursor-pointer">
                <mat-icon class="text-xs">tire_repair</mat-icon>
                <span>Inspect Bogie Twin</span>
              </button>
              <button 
                (click)="twin.removeCarFromFormation(twin.selectedCarIndex())"
                [disabled]="twin.cars().length <= 2"
                class="px-2.5 py-1 bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 disabled:opacity-30 rounded text-xs font-mono flex items-center gap-1 cursor-pointer">
                <mat-icon class="text-xs">delete</mat-icon>
                <span>Remove Car</span>
              </button>
            </div>
          </div>

          <!-- Car Technical Parameters -->
          <div class="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs font-mono">
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
              <div class="text-slate-500">CAR TYPE</div>
              <div class="text-sm font-bold text-cyan-300 mt-1">{{ selectedCar.type }}</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
              <div class="text-slate-500">LENGTH OVER BUFFERS</div>
              <div class="text-sm font-bold text-white mt-1">{{ selectedCar.length_m }} m</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
              <div class="text-slate-500">TARE / GROSS MASS</div>
              <div class="text-sm font-bold text-white mt-1">{{ selectedCar.tareMass_t }} t / {{ selectedCar.grossMass_t }} t</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
              <div class="text-slate-500">TRACTION SYSTEM</div>
              <div class="text-sm font-bold text-white mt-1">
                {{ selectedCar.isMotorized ? selectedCar.motorPower_kW + ' kW (4x 500kW Motors)' : 'Non-Powered Trailer' }}
              </div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
              <div class="text-slate-500">PASSENGER SEATING</div>
              <div class="text-sm font-bold text-white mt-1">
                {{ selectedCar.seatsFirstClass }} First / {{ selectedCar.seatsStandardClass }} Standard
              </div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
              <div class="text-slate-500">BOGIE TYPE & PANTOGRAPH</div>
              <div class="text-sm font-bold text-white mt-1">
                {{ selectedCar.bogieType }} &bull; {{ selectedCar.hasPantograph ? 'Active 25kV' : 'None' }}
              </div>
            </div>
          </div>
        </div>

        <!-- Add Vehicle to Formation Panel -->
        <div class="bg-slate-900/80 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center gap-2 border-b border-slate-800 pb-3">
            <mat-icon class="text-emerald-400">add_circle</mat-icon>
            <h3 class="font-bold text-white text-base">Add Vehicle Unit</h3>
          </div>
          <p class="text-xs text-slate-400">
            Append modular vehicle unit into the active trainset formation. Mass balance and traction calculations will instantly recompute.
          </p>

          <div class="space-y-2 font-mono text-xs">
            <button 
              (click)="twin.addCarToFormation('MOTOR_CAR')"
              class="w-full py-2 px-3 bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-cyan-500 rounded text-left flex items-center justify-between cursor-pointer transition">
              <span>+ Motor Car (2,000 kW)</span>
              <span class="text-cyan-400 text-[10px]">53.2 t</span>
            </button>
            <button 
              (click)="twin.addCarToFormation('TRAILER')"
              class="w-full py-2 px-3 bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-cyan-500 rounded text-left flex items-center justify-between cursor-pointer transition">
              <span>+ Standard Trailer Car</span>
              <span class="text-slate-400 text-[10px]">44.5 t</span>
            </button>
            <button 
              (click)="twin.addCarToFormation('SERVICE_CAR')"
              class="w-full py-2 px-3 bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-cyan-500 rounded text-left flex items-center justify-between cursor-pointer transition">
              <span>+ Bistro / Service Car</span>
              <span class="text-slate-400 text-[10px]">49.0 t</span>
            </button>
            <button 
              (click)="twin.addCarToFormation('BATTERY_CAR')"
              class="w-full py-2 px-3 bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-emerald-500 rounded text-left flex items-center justify-between cursor-pointer transition">
              <span>+ Battery Power Car (700 kWh)</span>
              <span class="text-emerald-400 text-[10px]">56.0 t</span>
            </button>
            <button 
              (click)="twin.addCarToFormation('HYDROGEN_CAR')"
              class="w-full py-2 px-3 bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-blue-500 rounded text-left flex items-center justify-between cursor-pointer transition">
              <span>+ Fuel Cell Car (600 kW PEM)</span>
              <span class="text-blue-400 text-[10px]">58.0 t</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TrainDesignerComponent {
  readonly twin = inject(RollingStockTwinService);
}
