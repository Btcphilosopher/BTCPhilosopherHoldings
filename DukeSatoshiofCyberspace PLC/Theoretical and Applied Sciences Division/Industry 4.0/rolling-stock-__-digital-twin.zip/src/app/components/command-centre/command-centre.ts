import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-command-centre',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Title & Lifecycle Bar -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">analytics</mat-icon>
            <span>PROGRAMME COMMAND CENTRE // RSX-320 HIGH-SPEED EMU</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white flex items-center gap-3">
            <span>RSX-320 Digital Twin</span>
            <span class="text-xs font-mono font-normal px-2.5 py-1 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded-full">
              P1 ASSEMBLY ACTIVE
            </span>
          </h1>
          <p class="text-sm text-slate-400 mt-1 max-w-2xl">
            Single integrated computational engineering model spanning 16 lifecycle phases from requirements capture to predictive maintenance.
          </p>
        </div>

        <div class="flex items-center gap-3">
          <button 
            (click)="twin.setTab('digital_thread')"
            class="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-mono flex items-center gap-2 transition cursor-pointer">
            <mat-icon class="text-sm text-cyan-400">hub</mat-icon>
            <span>Inspect Digital Thread</span>
          </button>
          <button 
            (click)="twin.startGuidedTour()"
            class="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-medium flex items-center gap-2 shadow-sm transition cursor-pointer">
            <mat-icon class="text-sm">play_arrow</mat-icon>
            <span>Run 25-Step Demo</span>
          </button>
        </div>
      </div>

      <!-- Lifecycle Stage Progression Ribbon (16 Stages) -->
      <div class="bg-slate-900/60 border border-slate-800 p-4 rounded-xl">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-3 flex items-center justify-between">
          <span>ONE TRAIN &bull; ONE DIGITAL THREAD &bull; LIFECYCLE HORIZON</span>
          <span class="text-cyan-400 font-semibold">STAGE 07/16: MANUFACTURING</span>
        </div>
        <div class="grid grid-cols-4 sm:grid-cols-8 lg:grid-cols-16 gap-1.5 text-center text-[10px] font-mono">
          @for (stage of lifecycleStages; track stage.name; let idx = $index) {
            <div 
              [class.bg-emerald-950]="idx < 6"
              [class.border-emerald-700]="idx < 6"
              [class.text-emerald-300]="idx < 6"
              [class.bg-cyan-950]="idx === 6"
              [class.border-cyan-500]="idx === 6"
              [class.text-cyan-200]="idx === 6"
              [class.bg-slate-900]="idx > 6"
              [class.border-slate-800]="idx > 6"
              [class.text-slate-500]="idx > 6"
              class="p-2 rounded border flex flex-col items-center justify-center transition">
              <span class="text-[9px] opacity-70">{{ idx + 1 < 10 ? '0' + (idx + 1) : idx + 1 }}</span>
              <span class="font-bold truncate w-full mt-0.5">{{ stage.name }}</span>
            </div>
          }
        </div>
      </div>

      <!-- High-Level KPI Matrix -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div class="bg-slate-900/70 border border-slate-800 p-4 rounded-xl">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span class="font-mono uppercase">Design Freeze</span>
            <mat-icon class="text-emerald-400 text-sm">lock_clock</mat-icon>
          </div>
          <div class="mt-2 flex items-baseline gap-2">
            <span class="text-2xl font-bold font-mono text-emerald-400">{{ twin.designFreezePct() }}%</span>
            <span class="text-xs text-slate-500">Target: 85%</span>
          </div>
          <div class="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div class="bg-emerald-500 h-full rounded-full" [style.width.%]="twin.designFreezePct()"></div>
          </div>
        </div>

        <div class="bg-slate-900/70 border border-slate-800 p-4 rounded-xl">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span class="font-mono uppercase">Requirements Verified</span>
            <mat-icon class="text-cyan-400 text-sm">fact_check</mat-icon>
          </div>
          <div class="mt-2 flex items-baseline gap-2">
            <span class="text-2xl font-bold font-mono text-cyan-300">{{ twin.requirementsVerified() }}</span>
            <span class="text-xs text-slate-500">/ {{ twin.requirementsTotal() }}</span>
          </div>
          <div class="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div class="bg-cyan-500 h-full rounded-full" [style.width.%]="(twin.requirementsVerified() / twin.requirementsTotal()) * 100"></div>
          </div>
        </div>

        <div class="bg-slate-900/70 border border-slate-800 p-4 rounded-xl">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span class="font-mono uppercase">Open Changes (ECR)</span>
            <mat-icon class="text-amber-400 text-sm">pending_actions</mat-icon>
          </div>
          <div class="mt-2 flex items-baseline gap-2">
            <span class="text-2xl font-bold font-mono text-amber-300">{{ twin.openECRs() }}</span>
            <span class="text-xs text-slate-500">Active ECRs</span>
          </div>
          <div class="text-[11px] text-slate-400 mt-3 flex items-center gap-1 font-mono">
            <span class="text-emerald-400">32 Approved</span> &bull; <span class="text-amber-400">5 Review</span>
          </div>
        </div>

        <div class="bg-slate-900/70 border border-slate-800 p-4 rounded-xl">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span class="font-mono uppercase">Manufacturing Readiness</span>
            <mat-icon class="text-blue-400 text-sm">precision_manufacturing</mat-icon>
          </div>
          <div class="mt-2 flex items-baseline gap-2">
            <span class="text-2xl font-bold font-mono text-blue-300">{{ twin.manufacturingReadiness() }}%</span>
            <span class="text-xs text-slate-500">Northfield Line 1</span>
          </div>
          <div class="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div class="bg-blue-500 h-full rounded-full" [style.width.%]="twin.manufacturingReadiness()"></div>
          </div>
        </div>
      </div>

      <!-- Core Vehicle Engineering Parameters (Editable/Synoptic) -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Main Vehicle Overview Card -->
        <div class="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">train</mat-icon>
              <h2 class="font-bold text-white text-base">RSX-320 Reference Vehicle Specifications</h2>
            </div>
            <button 
              (click)="twin.setTab('train_designer')"
              class="text-xs text-cyan-400 hover:text-cyan-300 font-mono flex items-center gap-1 cursor-pointer">
              <span>Configure Formation</span>
              <mat-icon class="text-xs">arrow_forward</mat-icon>
            </button>
          </div>

          <!-- Key Metrics Grid -->
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
              <div class="text-slate-500">MAX DESIGN SPEED</div>
              <div class="text-xl font-bold text-white mt-1">{{ twin.targetMaxSpeed_kmh() }} <span class="text-xs text-slate-400 font-normal">km/h</span></div>
              <div class="text-[10px] text-emerald-400 mt-1">TSI Class 1 Certified</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
              <div class="text-slate-500">TRAINSET LENGTH</div>
              <div class="text-xl font-bold text-white mt-1">{{ twin.totalLength_m() }} <span class="text-xs text-slate-400 font-normal">m</span></div>
              <div class="text-[10px] text-slate-400 mt-1">{{ twin.cars().length }} Passenger Cars</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
              <div class="text-slate-500">TOTAL TARE MASS</div>
              <div class="text-xl font-bold text-white mt-1">{{ twin.totalTareMass_t() }} <span class="text-xs text-slate-400 font-normal">t</span></div>
              <div class="text-[10px] text-slate-400 mt-1">Gross: {{ twin.totalGrossMass_t() }} t</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
              <div class="text-slate-500">MAX AXLE LOAD</div>
              <div class="text-xl font-bold text-cyan-300 mt-1">{{ twin.maxAxleLoad_t() }} <span class="text-xs text-slate-400 font-normal">t/axle</span></div>
              <div class="text-[10px] text-emerald-400 mt-1">&lt; 17.0 t (TSI Pass)</div>
            </div>

            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
              <div class="text-slate-500">TRACTION POWER</div>
              <div class="text-xl font-bold text-white mt-1">{{ twin.totalTractionPower_MW() }} <span class="text-xs text-slate-400 font-normal">MW</span></div>
              <div class="text-[10px] text-slate-400 mt-1">8x 1,000 kW PMSM</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
              <div class="text-slate-500">POWER-TO-WEIGHT</div>
              <div class="text-xl font-bold text-white mt-1">{{ twin.powerToWeight_kWt() }} <span class="text-xs text-slate-400 font-normal">kW/t</span></div>
              <div class="text-[10px] text-emerald-400 mt-1">High Specific Power</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
              <div class="text-slate-500">0&rarr;320 KM/H TIME</div>
              <div class="text-xl font-bold text-white mt-1">{{ twin.accelerationTimeTo320_s() }} <span class="text-xs text-slate-400 font-normal">s</span></div>
              <div class="text-[10px] text-slate-400 mt-1">12.8 km run distance</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
              <div class="text-slate-500">PASSENGER SEATS</div>
              <div class="text-xl font-bold text-white mt-1">{{ twin.totalSeats() }} <span class="text-xs text-slate-400 font-normal">seats</span></div>
              <div class="text-[10px] text-slate-400 mt-1">112 First / 472 Std</div>
            </div>
          </div>

          <!-- Quick Car Formation Elevation Preview -->
          <div class="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div class="text-xs font-mono text-slate-400 mb-2 flex items-center justify-between">
              <span>ACTIVE 8-CAR FORMATION SCHEMATIC (RSX-320-001)</span>
              <span class="text-cyan-400">UIC 505-1 Gauge</span>
            </div>
            <div class="flex items-center gap-1 overflow-x-auto py-2">
              @for (car of twin.cars(); track car.id; let idx = $index) {
                <button 
                  (click)="twin.selectedCarIndex.set(idx); twin.setTab('train_designer')"
                  class="shrink-0 w-24 h-14 bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-cyan-500 rounded p-1.5 flex flex-col justify-between text-[10px] font-mono cursor-pointer transition text-left">
                  <div class="flex items-center justify-between w-full">
                    <span class="font-bold text-slate-200">C{{ idx + 1 }}</span>
                    @if (car.hasPantograph) {
                      <mat-icon class="text-[10px] text-amber-400">electric_bolt</mat-icon>
                    }
                  </div>
                  <div class="text-[9px] text-cyan-300 truncate w-full">{{ car.type.replace('_', ' ') }}</div>
                  <div class="text-[8px] text-slate-400 w-full">{{ car.tareMass_t }}t &bull; {{ car.isMotorized ? '2.0MW' : 'Trailer' }}</div>
                </button>
              }
            </div>
          </div>
        </div>

        <!-- Live Operational Telemetry & Health Stream -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-emerald-400 text-base animate-pulse">sensors</mat-icon>
                <h3 class="font-bold text-white text-sm font-mono">RSX-320-001 LIVE TELEMETRY</h3>
              </div>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                ACTIVE
              </span>
            </div>

            <div class="space-y-3 mt-4 text-xs font-mono">
              <div class="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800/80">
                <span class="text-slate-400">Current Velocity:</span>
                <span class="text-emerald-400 font-bold text-sm">{{ twin.telemetry().speed_kmh }} km/h</span>
              </div>
              <div class="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800/80">
                <span class="text-slate-400">Catenary Line Voltage:</span>
                <span class="text-slate-200 font-bold">{{ twin.telemetry().lineVoltage_kV }} kV AC</span>
              </div>
              <div class="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800/80">
                <span class="text-slate-400">Bogie 1 Vibration RMS:</span>
                <span 
                  [class.text-red-400]="twin.telemetry().bogie1Vibration_mms2 > 8"
                  [class.text-emerald-400]="twin.telemetry().bogie1Vibration_mms2 <= 8"
                  class="font-bold flex items-center gap-1">
                  {{ twin.telemetry().bogie1Vibration_mms2 }} mm/s²
                  @if (twin.telemetry().bogie1Vibration_mms2 > 8) {
                    <mat-icon class="text-xs text-red-400 animate-bounce">warning</mat-icon>
                  }
                </span>
              </div>
              <div class="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800/80">
                <span class="text-slate-400">Bogie 1 Bearing Temp:</span>
                <span 
                  [class.text-amber-400]="twin.telemetry().bogie1BearingTemp_C > 75"
                  [class.text-slate-200]="twin.telemetry().bogie1BearingTemp_C <= 75"
                  class="font-bold">
                  {{ twin.telemetry().bogie1BearingTemp_C }} °C
                </span>
              </div>
              <div class="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800/80">
                <span class="text-slate-400">Pantograph Contact Force:</span>
                <span class="text-slate-200 font-bold">{{ twin.telemetry().pantographContactForce_N }} N</span>
              </div>
            </div>
          </div>

          <div class="pt-3 border-t border-slate-800">
            <button 
              (click)="twin.setTab('fleet_operations')"
              class="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-mono text-center flex items-center justify-center gap-1.5 transition cursor-pointer">
              <mat-icon class="text-xs">sensors</mat-icon>
              <span>Open Fleet Operations Telemetry</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CommandCentreComponent {
  readonly twin = inject(RollingStockTwinService);

  readonly lifecycleStages = [
    { name: 'Requirements' },
    { name: 'Concept' },
    { name: 'Architecture' },
    { name: 'CAD Design' },
    { name: 'Systems Eng' },
    { name: 'Simulation' },
    { name: 'Manufacturing' },
    { name: 'Quality & NDT' },
    { name: 'Testing' },
    { name: 'Assurance' },
    { name: 'Certification' },
    { name: 'Delivery' },
    { name: 'Operation' },
    { name: 'Maintenance' },
    { name: 'Refurbishment' },
    { name: 'End of Life' }
  ];
}
