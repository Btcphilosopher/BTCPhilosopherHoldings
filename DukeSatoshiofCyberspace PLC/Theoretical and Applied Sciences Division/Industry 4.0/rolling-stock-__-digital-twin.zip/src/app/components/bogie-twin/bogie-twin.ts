import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-bogie-twin',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">tire_repair</mat-icon>
            <span>MODULE 09 // BOGIE DIGITAL TWIN & WHEELSET WEAR (BOG-201)</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            High-Speed Bogie Twin & Wheel Degradation
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            High-fidelity bogie structure (S355 steel), Lucchini R8T forged monobloc wheelsets, axlebox bearing health, and wheel profile wear life-cycle simulation.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="px-2.5 py-1 bg-cyan-950 text-cyan-300 border border-cyan-800 rounded">
            BOGIE ID: BOG-201-HS320
          </span>
          <span class="px-2.5 py-1 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded">
            HEALTH: {{ twin.injectedAnomaly() ? 'ANOMALY DETECTED' : 'OPTIMAL' }}
          </span>
        </div>
      </div>

      <!-- Bogie Key Telemetry & Specs -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">WHEEL DIAMETER</div>
          <div class="text-2xl font-bold text-white mt-1">{{ currentWheelDia_mm() }} mm</div>
          <div class="text-[10px] text-slate-400 mt-1">New: 920mm / Limit: 840mm</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">WHEEL PROFILE WEAR STATE</div>
          <div class="text-xl font-bold text-cyan-300 mt-1">{{ wheelWearStatus() }}</div>
          <div class="text-[10px] text-slate-400 mt-1">Flange $S_d$: {{ (32.5 - (mileage_km() / 100000)).toFixed(1) }} mm</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">BEARING TEMPERATURE</div>
          <div 
            [class.text-amber-400]="twin.telemetry().bogie1BearingTemp_C > 75"
            [class.text-white]="twin.telemetry().bogie1BearingTemp_C <= 75"
            class="text-2xl font-bold mt-1">
            {{ twin.telemetry().bogie1BearingTemp_C }} °C
          </div>
          <div class="text-[10px] text-slate-400 mt-1">Dual Pt100 Sensors</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">BEARING VIBRATION RMS</div>
          <div 
            [class.text-red-400]="twin.telemetry().bogie1Vibration_mms2 > 8"
            [class.text-emerald-400]="twin.telemetry().bogie1Vibration_mms2 <= 8"
            class="text-2xl font-bold mt-1">
            {{ twin.telemetry().bogie1Vibration_mms2 }} mm/s²
          </div>
          <div class="text-[10px] text-slate-400 mt-1">ISO 10816-3 Zone A (&lt; 4.5)</div>
        </div>
      </div>

      <!-- Interactive 2D Bogie Blueprint & Wear Simulation -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Bogie Visual Blueprint -->
        <div class="lg:col-span-2 bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">precision_manufacturing</mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">BOG-201 HIGH-SPEED MOTOR BOGIE ASSEMBLY</h3>
            </div>
            <span class="text-xs font-mono text-slate-400">Wheelbase: 2.500m</span>
          </div>

          <!-- SVG Bogie CAD Diagram -->
          <div class="bg-slate-950 p-6 rounded-xl border border-slate-800 relative bg-cad-grid">
            <svg viewBox="0 0 600 240" class="w-full h-56 select-none font-mono text-[10px]">
              <!-- Rail Level -->
              <line x1="20" y1="205" x2="580" y2="205" stroke="#475569" stroke-width="3" />

              <!-- Bogie Frame H-Beam -->
              <rect x="100" y="85" width="400" height="24" rx="4" fill="#0f2942" stroke="#06b6d4" stroke-width="2" />
              <rect x="270" y="60" width="60" height="65" rx="3" fill="#0b2034" stroke="#0891b2" stroke-width="1.5" />

              <!-- Secondary Air Suspension Bellows (Left & Right) -->
              <rect x="230" y="50" width="35" height="35" rx="4" fill="#1e293b" stroke="#38bdf8" stroke-width="2" />
              <rect x="335" y="50" width="35" height="35" rx="4" fill="#1e293b" stroke="#38bdf8" stroke-width="2" />
              <text x="247" y="72" fill="#38bdf8" text-anchor="middle" font-size="8">AIR</text>
              <text x="352" y="72" fill="#38bdf8" text-anchor="middle" font-size="8">AIR</text>

              <!-- Yaw Damper Strut -->
              <line x1="220" y1="95" x2="160" y2="45" stroke="#f59e0b" stroke-width="3" />
              <text x="180" y="40" fill="#f59e0b" font-size="8">Yaw Damper (450 kNs/m)</text>

              <!-- Wheelset 1 (Left) -->
              <circle cx="160" cy="165" r="40" fill="#1e293b" stroke="#94a3b8" stroke-width="3" />
              <circle cx="160" cy="165" r="22" fill="#0f172a" stroke="#64748b" stroke-width="2" />
              <!-- Axlebox Sensor Node -->
              <circle cx="160" cy="165" r="10" [attr.fill]="twin.injectedAnomaly() ? '#ef4444' : '#10b981'" />
              <text x="160" y="168" fill="#ffffff" font-size="7" font-weight="bold" text-anchor="middle">S1</text>

              <!-- Wheelset 2 (Right) -->
              <circle cx="440" cy="165" r="40" fill="#1e293b" stroke="#94a3b8" stroke-width="3" />
              <circle cx="440" cy="165" r="22" fill="#0f172a" stroke="#64748b" stroke-width="2" />
              <!-- Axlebox Sensor Node -->
              <circle cx="440" cy="165" r="10" fill="#10b981" />
              <text x="440" y="168" fill="#ffffff" font-size="7" font-weight="bold" text-anchor="middle">S2</text>

              <!-- Traction Motor & Gearbox Pack (Centre-Mounted) -->
              <rect x="215" y="145" width="170" height="38" rx="3" fill="#1e293b" stroke="#0ea5e9" stroke-width="1.5" />
              <text x="300" y="168" fill="#38bdf8" text-anchor="middle" font-size="9" font-weight="bold">TSA MOT-600 (1000 kW)</text>

              <!-- Dimension Callout: Wheelbase 2500mm -->
              <line x1="160" y1="225" x2="440" y2="225" stroke="#06b6d4" stroke-width="1.5" />
              <text x="300" y="235" fill="#22d3ee" text-anchor="middle" font-size="9" font-weight="bold">Wheelbase 2,500 mm</text>
            </svg>
          </div>
        </div>

        <!-- Wheel Mileage & Wear Lifecycle Simulation Slider -->
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="border-b border-slate-800 pb-3">
            <h3 class="font-bold text-white text-sm font-mono flex items-center gap-2">
              <mat-icon class="text-cyan-400 text-base">history</mat-icon>
              <span>WHEEL WEAR SIMULATION</span>
            </h3>
            <p class="text-[11px] text-slate-400 mt-1">
              Simulate operational mileage accumulation and predict required CNC wheel-turning intervals.
            </p>
          </div>

          <!-- Mileage Slider -->
          <div class="space-y-1.5 font-mono text-xs">
            <div class="flex justify-between items-center text-slate-300">
              <span>Accumulated Mileage:</span>
              <span class="font-bold text-cyan-300 text-sm">{{ mileage_km().toLocaleString() }} km</span>
            </div>
            <input 
              type="range" 
              min="0" 
              max="1200000" 
              step="25000" 
              [value]="mileage_km()" 
              (input)="mileage_km.set(+($any($event.target).value))"
              class="w-full accent-cyan-500 cursor-pointer" />
            <div class="flex justify-between text-[10px] text-slate-500">
              <span>0 km (New)</span>
              <span>600,000 km</span>
              <span>1,200,000 km</span>
            </div>
          </div>

          <!-- Calculated Wheel Wear State Card -->
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2 text-xs font-mono">
            <div class="flex justify-between text-slate-300">
              <span>Flange Height (S_h):</span>
              <span class="font-bold text-white">{{ (28.0 + (mileage_km() / 200000)).toFixed(1) }} mm (Limit: 36mm)</span>
            </div>
            <div class="flex justify-between text-slate-300">
              <span>Flange Thickness (S_d):</span>
              <span class="font-bold text-white">{{ (32.5 - (mileage_km() / 150000)).toFixed(1) }} mm (Limit: 26mm)</span>
            </div>
            <div class="flex justify-between text-slate-300">
              <span>q_R Factor:</span>
              <span class="font-bold text-emerald-400">{{ (10.2 - (mileage_km() / 300000)).toFixed(1) }} mm (&gt; 6.5mm)</span>
            </div>
            <div class="pt-2 border-t border-slate-800 flex justify-between items-center">
              <span class="text-slate-400">Next Turning Overhaul:</span>
              <span class="text-cyan-300 font-bold">
                in {{ (300000 - (mileage_km() % 300000)).toLocaleString() }} km
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class BogieTwinComponent {
  readonly twin = inject(RollingStockTwinService);
  readonly mileage_km = signal<number>(184500);

  readonly currentWheelDia_mm = computed(() => {
    const wear = (this.mileage_km() / 100000) * 5.8;
    return Number((920 - wear).toFixed(1));
  });

  readonly wheelWearStatus = computed(() => {
    const dia = this.currentWheelDia_mm();
    if (dia >= 900) return 'NEW / EXCELLENT';
    if (dia >= 870) return 'IN SERVICE (NOMINAL)';
    if (dia >= 850) return 'TURNING SCHEDULED';
    return 'CRITICAL WEAR LIMIT';
  });
}
