import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

interface ScenarioImpactItem {
  title: string;
  massDelta: string;
  costDelta: string;
  benefits: string[];
  risks: string[];
  affectedSystems: string[];
  newTests: string[];
}

@Component({
  selector: 'app-scenario-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `

    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">science</mat-icon>
            <span>MODULE 31 // MULTIDISCIPLINARY SCENARIO LAB & DESIGN TRADE STUDIES</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            Engineering Scenario Lab & Architecture Trades
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            Evaluate multidimensional cascading impacts of engineering changes across aerodynamics, traction, thermal rejection, mass balance, braking, cost delta, and recertification tests.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <button 
            (click)="activeTab.set('SCENARIO')"
            [class.bg-cyan-600]="activeTab() === 'SCENARIO'"
            [class.text-white]="activeTab() === 'SCENARIO'"
            [class.bg-slate-800]="activeTab() !== 'SCENARIO'"
            [class.text-slate-300]="activeTab() !== 'SCENARIO'"
            class="px-3 py-1.5 rounded border border-slate-700 transition cursor-pointer">
            Scenario Impact Lab
          </button>
          <button 
            (click)="activeTab.set('TRADE_STUDY')"
            [class.bg-cyan-600]="activeTab() === 'TRADE_STUDY'"
            [class.text-white]="activeTab() === 'TRADE_STUDY'"
            [class.bg-slate-800]="activeTab() !== 'TRADE_STUDY'"
            [class.text-slate-300]="activeTab() !== 'TRADE_STUDY'"
            class="px-3 py-1.5 rounded border border-slate-700 transition cursor-pointer">
            Architecture Trade Study (Pareto)
          </button>
        </div>
      </div>

      @if (activeTab() === 'SCENARIO') {
        <!-- Scenario Selector -->
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
          <button 
            (click)="selectedScenario.set('SPEED_UPGRADE')"
            [class.border-cyan-500]="selectedScenario() === 'SPEED_UPGRADE'"
            [class.bg-cyan-950/40]="selectedScenario() === 'SPEED_UPGRADE'"
            class="p-3.5 bg-slate-900 border border-slate-800 rounded-xl text-left transition cursor-pointer">
            <div class="text-[10px] text-slate-500">SCENARIO A</div>
            <div class="font-bold text-white text-sm mt-0.5">Speed Upgrade: 300 &rarr; 320 km/h</div>
            <div class="text-[10px] text-cyan-300 mt-1">Traction, Aero, Braking & TSI Recert</div>
          </button>
          <button 
            (click)="selectedScenario.set('CARBON_ROOF')"
            [class.border-cyan-500]="selectedScenario() === 'CARBON_ROOF'"
            [class.bg-cyan-950/40]="selectedScenario() === 'CARBON_ROOF'"
            class="p-3.5 bg-slate-900 border border-slate-800 rounded-xl text-left transition cursor-pointer">
            <div class="text-[10px] text-slate-500">SCENARIO B</div>
            <div class="font-bold text-white text-sm mt-0.5">Carbon Composite Roof Shell</div>
            <div class="text-[10px] text-emerald-400 mt-1">-4.8t Mass Delta &bull; Fire Safety EN 45545</div>
          </button>
          <button 
            (click)="selectedScenario.set('BATTERY_PACK')"
            [class.border-cyan-500]="selectedScenario() === 'BATTERY_PACK'"
            [class.bg-cyan-950/40]="selectedScenario() === 'BATTERY_PACK'"
            class="p-3.5 bg-slate-900 border border-slate-800 rounded-xl text-left transition cursor-pointer">
            <div class="text-[10px] text-slate-500">SCENARIO C</div>
            <div class="font-bold text-white text-sm mt-0.5">Hybrid Battery Pack (700 kWh LTO)</div>
            <div class="text-[10px] text-amber-400 mt-1">+6.2t Mass &bull; 80 km Last-Mile Range</div>
          </button>
        </div>

        <!-- Selected Scenario Evaluation Matrix -->
        @let sc = scenarioData[selectedScenario()];
        <div class="bg-slate-900/90 border border-slate-800 p-6 rounded-xl space-y-5">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <span class="text-[10px] font-mono text-cyan-400 uppercase font-bold">MULTIDISCIPLINARY IMPACT ANALYSIS</span>
              <h2 class="text-lg font-bold text-white font-mono">{{ sc.title }}</h2>
            </div>
            <div class="flex items-center gap-3 font-mono text-xs">
              <span class="px-2.5 py-1 bg-slate-950 text-emerald-400 border border-slate-800 rounded font-bold">
                MASS DELTA: {{ sc.massDelta }}
              </span>
              <span class="px-2.5 py-1 bg-slate-950 text-cyan-300 border border-slate-800 rounded font-bold">
                COST DELTA: {{ sc.costDelta }}
              </span>
            </div>
          </div>

          <!-- Benefits vs Risks Grid -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
            <div class="bg-slate-950 p-4 rounded-xl border border-emerald-900/50 space-y-2">
              <div class="flex items-center gap-2 text-emerald-400 font-bold">
                <mat-icon class="text-sm">trending_up</mat-icon>
                <span>ENGINEERING BENEFITS</span>
              </div>
              <ul class="space-y-1.5 text-slate-300 text-[11px] list-disc list-inside">
                @for (b of sc.benefits; track b) {
                  <li>{{ b }}</li>
                }
              </ul>
            </div>

            <div class="bg-slate-950 p-4 rounded-xl border border-rose-900/50 space-y-2">
              <div class="flex items-center gap-2 text-rose-400 font-bold">
                <mat-icon class="text-sm">warning</mat-icon>
                <span>ENGINEERING RISKS & PENALTIES</span>
              </div>
              <ul class="space-y-1.5 text-slate-300 text-[11px] list-disc list-inside">
                @for (r of sc.risks; track r) {
                  <li>{{ r }}</li>
                }
              </ul>
            </div>
          </div>

          <!-- Affected Systems & Required Verification Tests -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs pt-2">
            <div class="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <div class="text-cyan-400 font-bold">AFFECTED VEHICLE SUBSYSTEMS</div>
              <div class="flex flex-wrap gap-1.5">
                @for (sys of sc.affectedSystems; track sys) {
                  <span class="px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-700 text-[10px]">
                    {{ sys }}
                  </span>
                }
              </div>
            </div>

            <div class="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <div class="text-amber-400 font-bold">RE-CERTIFICATION TESTS REQUIRED</div>
              <div class="space-y-1 text-[11px] text-slate-300">
                @for (t of sc.newTests; track t) {
                  <div class="flex items-center gap-1.5">
                    <mat-icon class="text-xs text-amber-400">arrow_right</mat-icon>
                    <span>{{ t }}</span>
                  </div>
                }
              </div>
            </div>
          </div>
        </div>
      } @else {
        <!-- Architecture Trade Study (Pareto Frontier Comparison) -->
        <div class="bg-slate-900/90 border border-slate-800 p-6 rounded-xl space-y-5">
          <div class="border-b border-slate-800 pb-3">
            <h2 class="text-lg font-bold text-white font-mono">
              Vehicle Architecture Trade Study & Pareto Frontier
            </h2>
            <p class="text-xs text-slate-400 mt-1 font-mono">
              Multi-criteria evaluation comparing 4 fundamental rolling stock propulsion concepts.
            </p>
          </div>

          <!-- Trade Study Comparison Table -->
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs font-mono">
              <thead class="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th class="py-2.5 px-3">Architecture Concept</th>
                  <th class="py-2.5 px-3">Tare Mass</th>
                  <th class="py-2.5 px-3">Installed Power</th>
                  <th class="py-2.5 px-3">Specific Power</th>
                  <th class="py-2.5 px-3">Max Speed</th>
                  <th class="py-2.5 px-3">Passenger Capacity</th>
                  <th class="py-2.5 px-3">Range</th>
                  <th class="py-2.5 px-3">CAPEX Delta</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60 bg-slate-900/40 text-slate-300">
                <tr class="bg-cyan-950/30 border-l-2 border-cyan-500 font-semibold">
                  <td class="py-2.5 px-3 text-cyan-300">A. 8-Car Distributed EMU (RSX-320)</td>
                  <td class="py-2.5 px-3">432.0 t</td>
                  <td class="py-2.5 px-3">8.0 MW</td>
                  <td class="py-2.5 px-3 text-emerald-400">18.5 kW/t</td>
                  <td class="py-2.5 px-3">320 km/h</td>
                  <td class="py-2.5 px-3 text-emerald-400">584 seats</td>
                  <td class="py-2.5 px-3">Catenary</td>
                  <td class="py-2.5 px-3">Baseline</td>
                </tr>
                <tr>
                  <td class="py-2.5 px-3 text-white">B. 2 Power Cars + 8 Trailers (Push-Pull)</td>
                  <td class="py-2.5 px-3">498.0 t</td>
                  <td class="py-2.5 px-3">9.6 MW</td>
                  <td class="py-2.5 px-3">19.2 kW/t</td>
                  <td class="py-2.5 px-3">320 km/h</td>
                  <td class="py-2.5 px-3 text-amber-400">460 seats (-21%)</td>
                  <td class="py-2.5 px-3">Catenary</td>
                  <td class="py-2.5 px-3">+8%</td>
                </tr>
                <tr>
                  <td class="py-2.5 px-3 text-white">C. 3-Car Battery Multiple Unit (BEMU)</td>
                  <td class="py-2.5 px-3">148.0 t</td>
                  <td class="py-2.5 px-3">1.2 MW</td>
                  <td class="py-2.5 px-3">8.1 kW/t</td>
                  <td class="py-2.5 px-3">160 km/h</td>
                  <td class="py-2.5 px-3">208 seats</td>
                  <td class="py-2.5 px-3 text-cyan-300">120 km (Off-Wire)</td>
                  <td class="py-2.5 px-3">-45%</td>
                </tr>
                <tr>
                  <td class="py-2.5 px-3 text-white">D. 3-Car Hydrogen Fuel Cell (H2MU)</td>
                  <td class="py-2.5 px-3">154.0 t</td>
                  <td class="py-2.5 px-3">1.2 MW</td>
                  <td class="py-2.5 px-3">7.8 kW/t</td>
                  <td class="py-2.5 px-3">160 km/h</td>
                  <td class="py-2.5 px-3">200 seats</td>
                  <td class="py-2.5 px-3 text-emerald-400">800 km (Off-Wire)</td>
                  <td class="py-2.5 px-3">-32%</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      }
    </div>
  `
})
export class ScenarioLabComponent {
  readonly twin = inject(RollingStockTwinService);
  readonly activeTab = signal<'SCENARIO' | 'TRADE_STUDY'>('SCENARIO');
  readonly selectedScenario = signal<'SPEED_UPGRADE' | 'CARBON_ROOF' | 'BATTERY_PACK'>('SPEED_UPGRADE');

  readonly scenarioData: Record<string, ScenarioImpactItem> = {
    SPEED_UPGRADE: {
      title: 'High-Speed Operational Upgrade: 300 km/h &rarr; 320 km/h',
      massDelta: '+0.0 t (No structural mass penalty)',
      costDelta: '+€420,000 (Testing & TSI Recertification)',
      benefits: [
        'Paris-London transit time reduced by 9.4 minutes.',
        'Competitive advantage against European airline corridors.',
        'High line capacity slot utilization at peak timetable windows.'
      ],
      risks: [
        'Aerodynamic drag force increases by ~13.8% ($F_{drag} \\propto v^2$).',
        'Disc brake peak thermal dissipation rises to 480°C.',
        'Tunnel entry pressure pulse $\\Delta P$ increases to 1.85 kPa (TSI limit 10.0 kPa).'
      ],
      affectedSystems: ['Traction Converters', 'Aerodynamic Nose', 'Disc Braking Calipers', 'Bogie Yaw Dampers', 'TCMS Software'],
      newTests: [
        'EN 14067-5 Tunnel Pressure Pulse High-Speed Testing',
        'EN 14363 Running Dynamic Acceptance at 352 km/h (110% V_max)',
        'TSI LOC&PAS 320 km/h Emergency Stopping Distance Verification'
      ]
    },
    CARBON_ROOF: {
      title: 'Lightweight Carbon-Composite Roof Fairing & Bodyshell Substitution',
      massDelta: '-4.8 t total tare mass reduction',
      costDelta: '+€680,000 per trainset CAPEX',
      benefits: [
        'Center of gravity lowered by 85 mm, significantly improving curve cant deficiency.',
        'Reduces energy consumption by 2.2% across annual fleet duty cycle.',
        'Maximum axle load reduced from 13.6 t to 13.4 t/axle.'
      ],
      risks: [
        'Complex non-destructive inspection (PAUT) for composite delamination.',
        'Higher raw material and autoclave tooling costs.',
        'Stringent flammability validation required per EN 45545-2 HL3.'
      ],
      affectedSystems: ['Carbody Structures', 'HVAC Mounting', 'Pantograph Fairings', 'Fire Protection'],
      newTests: [
        'EN 45545-2 HL3 Smoke Toxicity & Heat Release Cone Calorimeter',
        'Composite Ultrasonic NDT Delamination Baseline Audit',
        'Static Bodyshell Torsional Stiffness Test (EN 12663)'
      ]
    },
    BATTERY_PACK: {
      title: 'Integration of 700 kWh LTO Battery Pack on Trailer Underframe',
      massDelta: '+6.2 t mass penalty',
      costDelta: '+€950,000 per trainset',
      benefits: [
        '80 km autonomous operation on non-electrified branch lines.',
        'Peak shaving on weak 15 kV AC catenary networks.',
        'Eliminates diesel shunting locomotives inside terminal depots.'
      ],
      risks: [
        'Axle load on Car 5 increases from 13.5 t to 15.0 t/axle (still < 17.0 t TSI limit).',
        'Liquid cooling thermal management required during 3C fast pantograph charging.',
        'Space constraints in underframe equipment bays.'
      ],
      affectedSystems: ['Auxiliary Power', 'Traction DC Link', 'Thermal Liquid Loop', 'TCMS Energy Manager'],
      newTests: [
        'UN 38.3 & EN 50604-1 Rolling Stock Lithium Battery Safety',
        'Thermal Runaway Containment Simulation (TRCS)',
        'Last-Mile 80 km Non-Electrified Route Verification'
      ]
    }
  };
}
