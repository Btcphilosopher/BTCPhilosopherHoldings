import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-slate-900/90 backdrop-blur-md border-b border-slate-800 shrink-0 z-40">
      <!-- Topmost Engineering Programme Bar -->
      <div class="px-4 py-2 flex items-center justify-between border-b border-slate-800/60 text-xs">
        <div class="flex items-center gap-3">
          <div class="flex items-center gap-2 font-mono font-bold tracking-wider text-slate-100 uppercase">
            <span class="inline-block w-2.5 h-2.5 rounded-sm bg-cyan-500 shadow-sm shadow-cyan-500/50"></span>
            <span>ROLLING STOCK</span>
            <span class="text-cyan-400 font-normal">//</span>
            <span class="text-slate-300">DIGITAL TWIN</span>
          </div>
          <span class="bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700 font-mono text-[11px]">
            {{ twin.programmeName() }}
          </span>
          <span class="bg-cyan-950/80 text-cyan-300 border border-cyan-800/80 px-2 py-0.5 rounded font-mono font-semibold text-[11px] flex items-center gap-1">
            <span class="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
            PROTOTYPE {{ twin.prototypeStatus() }}
          </span>
        </div>

        <div class="flex items-center gap-4 font-mono text-[11px]">
          <div class="flex items-center gap-1.5 text-slate-300">
            <span class="text-slate-500">DESIGN FREEZE:</span>
            <span class="font-bold text-emerald-400">{{ twin.designFreezePct() }}%</span>
          </div>
          <div class="h-3 w-px bg-slate-800"></div>
          <div class="flex items-center gap-1.5 text-slate-300">
            <span class="text-slate-500">REQ VERIFIED:</span>
            <span class="font-bold text-cyan-300">{{ twin.requirementsVerified() }} / {{ twin.requirementsTotal() }}</span>
          </div>
          <div class="h-3 w-px bg-slate-800"></div>
          <div class="flex items-center gap-1.5 text-slate-300">
            <span class="text-slate-500">TELEMETRY:</span>
            <span class="text-emerald-400 font-semibold flex items-center gap-1">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
              {{ twin.telemetry().speed_kmh }} km/h
            </span>
          </div>
        </div>
      </div>

      <!-- Main Action & Guided Navigation Ribbon -->
      <div class="px-4 py-2 flex items-center justify-between gap-4">
        <!-- Guided Tour 25-step Controller -->
        <div class="flex items-center gap-2 flex-1 max-w-2xl bg-slate-950/80 border border-slate-800 p-1.5 rounded-lg">
          @if (!twin.isGuidedTourActive()) {
            <button 
              (click)="twin.startGuidedTour()"
              class="px-3 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded font-medium text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer">
              <mat-icon class="text-base scale-90">play_circle</mat-icon>
              <span>Start 25-Step Guided Story</span>
            </button>
            <span class="text-xs text-slate-400 pl-2">
              Walk through complete digital thread: Requirements &rarr; CAD &rarr; Physics &rarr; Factory &rarr; Telemetry &rarr; Maintenance.
            </span>
          } @else {
            <div class="flex items-center justify-between w-full">
              <div class="flex items-center gap-2">
                <span class="bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded font-mono text-xs font-bold border border-cyan-500/30">
                  STEP {{ twin.guidedStepIndex() + 1 }}/25
                </span>
                <span class="text-xs font-semibold text-slate-200 truncate max-w-sm">
                  {{ twin.guidedSteps[twin.guidedStepIndex()].title }}
                </span>
              </div>
              <div class="flex items-center gap-1">
                <button 
                  (click)="twin.prevGuidedStep()"
                  [disabled]="twin.guidedStepIndex() === 0"
                  class="p-1 text-slate-300 hover:text-white disabled:opacity-30 rounded hover:bg-slate-800 cursor-pointer">
                  <mat-icon class="text-sm">chevron_left</mat-icon>
                </button>
                <button 
                  (click)="twin.nextGuidedStep()"
                  class="px-2 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded text-xs font-semibold flex items-center gap-1 cursor-pointer">
                  <span>{{ twin.guidedStepIndex() === 24 ? 'Complete' : 'Next Step' }}</span>
                  <mat-icon class="text-sm">chevron_right</mat-icon>
                </button>
                <button 
                  (click)="twin.exitGuidedTour()"
                  class="p-1 text-slate-400 hover:text-slate-200 rounded hover:bg-slate-800 ml-1 cursor-pointer"
                  title="Exit guided tour">
                  <mat-icon class="text-sm">close</mat-icon>
                </button>
              </div>
            </div>
          }
        </div>

        <!-- Utility Buttons -->
        <div class="flex items-center gap-2 shrink-0">
          <!-- Anomaly Injector Toggle -->
          @if (!twin.injectedAnomaly()) {
            <button 
              (click)="twin.injectBogieAnomaly()"
              class="px-2.5 py-1.5 bg-amber-950/40 hover:bg-amber-900/60 text-amber-300 border border-amber-800/60 rounded text-xs font-mono flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Inject simulated bearing vibration defect (142 Hz harmonic)">
              <mat-icon class="text-sm text-amber-400">warning</mat-icon>
              <span>Inject Bogie Anomaly</span>
            </button>
          } @else {
            <button 
              (click)="twin.clearAnomaly()"
              class="px-2.5 py-1.5 bg-red-950/80 hover:bg-red-900 text-red-200 border border-red-700 rounded text-xs font-mono flex items-center gap-1.5 transition-colors cursor-pointer animate-pulse"
              title="Clear active vibration anomaly">
              <mat-icon class="text-sm text-red-400">error</mat-icon>
              <span>Vibration Anomaly Active [Clear]</span>
            </button>
          }

          <!-- Quick Actions -->
          <button 
            (click)="twin.showTerminal.set(true)"
            class="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-mono flex items-center gap-1 transition-colors cursor-pointer">
            <mat-icon class="text-sm text-cyan-400">terminal</mat-icon>
            <span>CLI</span>
          </button>

          <button 
            (click)="twin.showAiAssistant.set(true)"
            class="px-2.5 py-1.5 bg-gradient-to-r from-blue-900/80 to-indigo-900/80 hover:from-blue-800 hover:to-indigo-800 text-cyan-200 border border-cyan-800/60 rounded text-xs font-medium flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer">
            <mat-icon class="text-sm text-cyan-300">smart_toy</mat-icon>
            <span>RAIL.AI</span>
          </button>

          <button 
            (click)="twin.showReport.set(true)"
            class="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer">
            <mat-icon class="text-sm text-slate-300">description</mat-icon>
            <span>Export Report</span>
          </button>
        </div>
      </div>
    </header>
  `
})
export class HeaderComponent {
  readonly twin = inject(RollingStockTwinService);
}

