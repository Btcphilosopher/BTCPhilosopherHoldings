import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-quality-rams',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">shield</mat-icon>
            <span>MODULE 23, 25 & 26 // QUALITY, RAMS, SAFETY CASES & TSI CERTIFICATION</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            Quality Assurance, RAMS & Certification Evidence
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            EN 50126 RAMS lifecycle management, 8D Non-Conformance investigations, SIL 4 Safety Hazard Case (EN 50129 / CSM-RA), and Technical Specifications for Interoperability (TSI) compliance dossiers.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="px-2.5 py-1 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded font-bold">
            FLEET AVAILABILITY: 99.4% (EN 50126)
          </span>
          <span class="px-2.5 py-1 bg-cyan-950 text-cyan-300 border border-cyan-800 rounded font-bold">
            TSI LOC&PAS: VERIFIED
          </span>
        </div>
      </div>

      <!-- RAMS Key Targets Matrix -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">OPERATIONAL AVAILABILITY (Ao)</div>
          <div class="text-2xl font-bold text-emerald-400 mt-1">99.4%</div>
          <div class="text-[10px] text-emerald-400 mt-1">EN 50126 Target &ge; 99.2%</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">MTBSF (RELIABILITY)</div>
          <div class="text-2xl font-bold text-cyan-300 mt-1">142,500 km</div>
          <div class="text-[10px] text-slate-400 mt-1">Mean Distance Between Failures</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">MEAN TIME TO REPAIR (MTTR)</div>
          <div class="text-2xl font-bold text-white mt-1">1.8 hrs</div>
          <div class="text-[10px] text-emerald-400 mt-1">Rapid Line-Replaceable Units</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">SAFETY INTEGRITY LEVEL</div>
          <div class="text-2xl font-bold text-rose-400 mt-1">SIL 4</div>
          <div class="text-[10px] text-slate-400 mt-1">CSM-RA Verified</div>
        </div>
      </div>

      <!-- Standards & TSI Certification Evidence Dossiers -->
      <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">gavel</mat-icon>
            <h2 class="font-bold text-white text-base">TSI Regulatory Standards & Certification Library</h2>
          </div>
          <span class="text-xs font-mono text-slate-400">European Railway Agency (ERA) & Notified Body Audits</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th class="py-2.5 px-3">Standard Reference</th>
                <th class="py-2.5 px-3">Standard Title</th>
                <th class="py-2.5 px-3">Jurisdiction</th>
                <th class="py-2.5 px-3">Auditing Notified Body</th>
                <th class="py-2.5 px-3">Certificate Ref</th>
                <th class="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 bg-slate-900/40 text-slate-300">
              @for (std of twin.standards(); track std.code) {
                <tr class="hover:bg-slate-800/50 transition">
                  <td class="py-2.5 px-3 font-bold text-cyan-300">{{ std.code }}</td>
                  <td class="py-2.5 px-3 text-slate-200">{{ std.name }}</td>
                  <td class="py-2.5 px-3 text-slate-400">{{ std.jurisdiction }}</td>
                  <td class="py-2.5 px-3 text-slate-300">{{ std.auditorOrg }}</td>
                  <td class="py-2.5 px-3 text-slate-400">{{ std.certificateRef }}</td>
                  <td class="py-2.5 px-3">
                    <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-bold">
                      {{ std.complianceStatus }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Quality NCR 8D Investigation & Safety Hazard Register -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Quality NCR Card -->
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">verified</mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">QUALITY 8D NON-CONFORMANCE LOG</h3>
            </div>
            <span class="text-[10px] font-mono text-emerald-400 bg-emerald-950 border border-emerald-800 px-2 py-0.5 rounded">
              ISO 9001 / IRIS (ISO 22163)
            </span>
          </div>

          <div class="space-y-3 text-xs font-mono">
            @for (ncr of twin.qualityNCRs(); track ncr.id) {
              <div class="bg-slate-950 p-3.5 rounded-lg border border-slate-800 space-y-2">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-cyan-300">{{ ncr.id }} &bull; Component: {{ ncr.componentCode }}</span>
                  <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px]">
                    STATUS: {{ ncr.status }}
                  </span>
                </div>
                <div class="text-slate-300 text-[11px]">{{ ncr.description }}</div>
                <div class="bg-slate-900/60 p-2 rounded border border-slate-800 text-[10px] text-slate-400 space-y-1">
                  <div><strong>Root Cause:</strong> {{ ncr.rootCause }}</div>
                  <div><strong>Corrective Action:</strong> {{ ncr.correctiveAction }}</div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Safety Hazard Register Card (CSM-RA / EN 50129) -->
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-rose-400">security</mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">CSM-RA SAFETY HAZARDS & MITIGATIONS</h3>
            </div>
            <span class="text-[10px] font-mono text-rose-300 bg-rose-950 border border-rose-800 px-2 py-0.5 rounded">
              EN 50129 SIL 4
            </span>
          </div>

          <div class="space-y-3 text-xs font-mono">
            @for (haz of twin.safetyHazards(); track haz.id) {
              <div class="bg-slate-950 p-3.5 rounded-lg border border-slate-800 space-y-2">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-rose-300">{{ haz.id }} &bull; {{ haz.hazardTitle }}</span>
                  <span class="px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 text-[10px] font-bold">
                    {{ haz.silLevel }}
                  </span>
                </div>
                <div class="text-slate-300 text-[11px]"><strong>Consequence:</strong> {{ haz.consequence }}</div>
                <div class="bg-slate-900/60 p-2 rounded border border-slate-800 text-[10px] text-slate-400">
                  <div><strong>Mitigation:</strong> {{ haz.mitigationRequirement }}</div>
                  <div class="mt-1 text-emerald-400">Residual Risk: {{ haz.residualRisk }} (Verified)</div>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class QualityRamsComponent {
  readonly twin = inject(RollingStockTwinService);
}
