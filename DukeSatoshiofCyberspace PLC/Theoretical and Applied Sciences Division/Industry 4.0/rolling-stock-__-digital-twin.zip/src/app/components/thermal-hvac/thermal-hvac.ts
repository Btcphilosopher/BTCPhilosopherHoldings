import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-thermal-hvac',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">thermostat</mat-icon>
            <span>MODULE 14 & 15 // VEHICLE THERMAL NETWORK & HVAC CLIMATE TWIN</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            Thermal Management & Passenger HVAC Twin
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            Multiphysics vehicle thermal network modeling SiC traction converter liquid cooling, transformer oil heat rejection, and passenger compartment HVAC thermal comfort (EN 14750 / EN 13129).
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="px-2.5 py-1 bg-cyan-950 text-cyan-300 border border-cyan-800 rounded">
            REFRIGERANT: R290 (GWP = 3)
          </span>
          <span class="px-2.5 py-1 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded">
            COMFORT: CAT A (EN 14750)
          </span>
        </div>
      </div>

      <!-- Thermal Network Metrics Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">AMBIENT OUTSIDE TEMP</div>
          <div class="text-2xl font-bold text-cyan-300 mt-1">{{ ambientTemp_C() }} °C</div>
          <div class="text-[10px] text-slate-400 mt-1">Design Range: -25°C to +40°C</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">CABIN INTERIOR TEMP</div>
          <div class="text-2xl font-bold text-emerald-400 mt-1">21.8 °C</div>
          <div class="text-[10px] text-emerald-400 mt-1">Target: 22.0°C &plusmn; 0.5°C</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">SiC INVERTER JUNCTION TEMP</div>
          <div class="text-2xl font-bold text-white mt-1">{{ (65 + (ambientTemp_C() * 0.4)).toFixed(1) }} °C</div>
          <div class="text-[10px] text-slate-400 mt-1">Limit: 150 °C (SiC Safe)</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">TOTAL TRAIN HVAC POWER</div>
          <div class="text-2xl font-bold text-white mt-1">{{ hvacPower_kW() }} kW</div>
          <div class="text-[10px] text-slate-400 mt-1">8x 38 kW Heat Pumps</div>
        </div>
      </div>

      <!-- Interactive Thermal Simulation Controls -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <h3 class="font-bold text-white text-sm font-mono flex items-center gap-2">
            <mat-icon class="text-cyan-400">tune</mat-icon>
            <span>AMBIENT TEMPERATURE & SOLAR GAIN SLIDER</span>
          </h3>
          <div class="space-y-3 font-mono text-xs">
            <div class="flex justify-between text-slate-300">
              <span>Outside Ambient Temperature:</span>
              <span class="font-bold text-cyan-300 text-sm">{{ ambientTemp_C() }} °C</span>
            </div>
            <input 
              type="range" 
              min="-25" 
              max="45" 
              step="1" 
              [value]="ambientTemp_C()" 
              (input)="ambientTemp_C.set(+($any($event.target).value))"
              class="w-full accent-cyan-500 cursor-pointer" />
            <div class="flex justify-between text-[10px] text-slate-500">
              <span>-25 °C (Winter Alpine)</span>
              <span>+20 °C (Nominal)</span>
              <span>+45 °C (Extreme Summer)</span>
            </div>
          </div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <h3 class="font-bold text-white text-sm font-mono flex items-center gap-2">
            <mat-icon class="text-emerald-400">water_drop</mat-icon>
            <span>POWERTRAIN LIQUID COOLING LOOPS</span>
          </h3>
          <div class="space-y-2 font-mono text-xs">
            <div class="p-2.5 bg-slate-950 rounded border border-slate-800 flex justify-between">
              <span class="text-slate-300">Inverter Coolant Flow Rate:</span>
              <span class="font-bold text-cyan-300">48 L/min (Water-Glycol)</span>
            </div>
            <div class="p-2.5 bg-slate-950 rounded border border-slate-800 flex justify-between">
              <span class="text-slate-300">Transformer Oil Pump:</span>
              <span class="font-bold text-white">120 L/min (Synthetic Ester)</span>
            </div>
            <div class="p-2.5 bg-slate-950 rounded border border-slate-800 flex justify-between">
              <span class="text-slate-300">Motor Forced Air Blowers:</span>
              <span class="font-bold text-emerald-400">0.85 m³/s per bogie</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ThermalHvacComponent {
  readonly twin = inject(RollingStockTwinService);
  readonly ambientTemp_C = signal<number>(24);

  readonly hvacPower_kW = computed(() => {
    const delta = Math.abs(this.ambientTemp_C() - 22);
    return Math.round(120 + (delta * 4.8));
  });
}
