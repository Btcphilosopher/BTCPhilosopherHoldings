import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-vehicle-dynamics',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">speed</mat-icon>
            <span>MODULE 07 // MULTIBODY VEHICLE DYNAMICS & RUNNING SAFETY (EN 14363)</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            Vehicle Dynamics & Wheel-Rail Interaction Twin
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            Multibody dynamics (MBD) model evaluating wheel-rail contact mechanics (Kalker theory), hunting stability (V_crit = 385 km/h), derailment safety (Y/Q &lt; 0.8), and Sperling ride comfort indices.
          </p>
        </div>

        <!-- Scenario Selector -->
        <div class="flex items-center gap-2 flex-wrap">
          <button 
            (click)="activeScenario.set('CURVE_3000M')"
            [class.bg-cyan-600]="activeScenario() === 'CURVE_3000M'"
            [class.text-white]="activeScenario() === 'CURVE_3000M'"
            [class.bg-slate-800]="activeScenario() !== 'CURVE_3000M'"
            [class.text-slate-300]="activeScenario() !== 'CURVE_3000M'"
            class="px-3 py-1.5 rounded text-xs font-mono border border-slate-700 transition cursor-pointer">
            3,000m Curve (300 km/h)
          </button>
          <button 
            (click)="activeScenario.set('TANGENT_320')"
            [class.bg-cyan-600]="activeScenario() === 'TANGENT_320'"
            [class.text-white]="activeScenario() === 'TANGENT_320'"
            [class.bg-slate-800]="activeScenario() !== 'TANGENT_320'"
            [class.text-slate-300]="activeScenario() !== 'TANGENT_320'"
            class="px-3 py-1.5 rounded text-xs font-mono border border-slate-700 transition cursor-pointer">
            Tangent Track (320 km/h)
          </button>
          <button 
            (click)="activeScenario.set('CROSSWIND')"
            [class.bg-cyan-600]="activeScenario() === 'CROSSWIND'"
            [class.text-white]="activeScenario() === 'CROSSWIND'"
            [class.bg-slate-800]="activeScenario() !== 'CROSSWIND'"
            [class.text-slate-300]="activeScenario() !== 'CROSSWIND'"
            class="px-3 py-1.5 rounded text-xs font-mono border border-slate-700 transition cursor-pointer">
            140 km/h Crosswind Gust
          </button>
        </div>
      </div>

      <!-- Key Dynamics Safety & Comfort Metrics Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">DERAILMENT FACTOR (Y/Q)</div>
          <div class="text-2xl font-bold text-emerald-400 mt-1">0.38</div>
          <div class="text-[10px] text-emerald-400 mt-1">EN 14363 Limit &le; 0.80 (SAFE)</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">SPERLING RIDE INDEX (Wz)</div>
          <div class="text-2xl font-bold text-cyan-300 mt-1">2.12</div>
          <div class="text-[10px] text-emerald-400 mt-1">Target &le; 2.50 (Very Good)</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">HUNTING CRITICAL SPEED</div>
          <div class="text-2xl font-bold text-white mt-1">385 km/h</div>
          <div class="text-[10px] text-slate-400 mt-1">+20% Safety Margin</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div class="text-slate-500">PRUD'HOMME TRACK FORCE</div>
          <div class="text-2xl font-bold text-white mt-1">28.4 kN</div>
          <div class="text-[10px] text-emerald-400 mt-1">Limit: 46.2 kN (Safe)</div>
        </div>
      </div>

      <!-- Dynamics Simulation Visualization & Curve Response -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Multibody Suspension Degrees of Freedom Model -->
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">precision_manufacturing</mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">BOGIE SUSPENSION & YAW DAMPER DYNAMICS</h3>
            </div>
            <span class="text-[10px] font-mono text-cyan-300 bg-cyan-950 border border-cyan-800 px-2 py-0.5 rounded">
              BOG-201 MBD MODEL
            </span>
          </div>

          <div class="space-y-3 text-xs font-mono">
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
              <div class="flex justify-between items-center text-slate-300">
                <span>Primary Suspension (Coil Spring):</span>
                <span class="font-bold text-cyan-300">K_z = 1.15 MN/m (per axlebox)</span>
              </div>
              <div class="flex justify-between items-center text-slate-300">
                <span>Secondary Air Bellows:</span>
                <span class="font-bold text-cyan-300">K_air = 380 kN/m (Level Controlled)</span>
              </div>
              <div class="flex justify-between items-center text-slate-300">
                <span>Hydraulic Yaw Dampers:</span>
                <span class="font-bold text-emerald-400">C_yaw = 450 kNs/m (Anti-Hunting)</span>
              </div>
              <div class="flex justify-between items-center text-slate-300">
                <span>Anti-Roll Bar Stiffness:</span>
                <span class="font-bold text-white">K_roll = 1.85 MNm/rad</span>
              </div>
            </div>

            <!-- Dynamic Track Contact Angle -->
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div class="text-slate-400 font-bold mb-1">Wheel-Rail Contact Profile (EN 13674-1 60E1 / S1002):</div>
              <div class="text-[11px] text-slate-300">
                Equivalent Conicity $\\tan \\gamma_e = 0.082$ under nominal track gauge (1,435 mm). Ensures dynamic stability without flange contact up to 320 km/h.
              </div>
            </div>
          </div>
        </div>

        <!-- Lateral Acceleration & Wheel Unloading Dynamic Response Plot -->
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">show_chart</mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">LATERAL ACCELERATION vs CURVE ENTRY</h3>
            </div>
            <span class="text-[11px] font-mono text-cyan-400">R = 3000m, v = 300 km/h</span>
          </div>

          <!-- SVG Chart -->
          <div class="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <svg viewBox="0 0 500 200" class="w-full h-48 select-none font-mono text-[10px]">
              <!-- Grid lines -->
              @for (y of [30, 70, 110, 150]; track y) {
                <line x1="40" [attr.y1]="y" x2="480" [attr.y2]="y" stroke="#1e293b" stroke-dasharray="2 2" />
              }
              <line x1="40" y1="110" x2="480" y2="110" stroke="#475569" stroke-width="1.5" />
              <line x1="40" y1="20" x2="40" y2="180" stroke="#475569" stroke-width="1.5" />

              <text x="35" y="30" fill="#64748b" text-anchor="end">+1.0 m/s²</text>
              <text x="35" y="110" fill="#64748b" text-anchor="end">0.0</text>
              <text x="35" y="150" fill="#64748b" text-anchor="end">-0.5</text>

              <text x="40" y="195" fill="#64748b" text-anchor="middle">Tangent</text>
              <text x="180" y="195" fill="#64748b" text-anchor="middle">Transition Spiral</text>
              <text x="340" y="195" fill="#64748b" text-anchor="middle">Circular Curve (3000m)</text>

              <!-- Dynamic lateral acceleration curve -->
              <path d="M 40 110 L 140 110 Q 180 110 240 65 L 460 65" fill="none" stroke="#06b6d4" stroke-width="3" />

              <!-- Comfort Limit Line (a_y = 0.8 m/s²) -->
              <line x1="40" y1="45" x2="480" y2="45" stroke="#f59e0b" stroke-dasharray="4 2" stroke-width="1.5" />
              <text x="470" y="40" fill="#f59e0b" font-size="8" text-anchor="end">Uncompensated Lat Accel Limit (0.8 m/s²)</text>

              <!-- Circle Marker in circular curve -->
              <circle cx="340" cy="65" r="4" fill="#06b6d4" />
              <text x="340" y="55" fill="#38bdf8" text-anchor="middle">a_y = 0.48 m/s² (Comfortable)</text>
            </svg>
          </div>
        </div>
      </div>
    </div>
  `
})
export class VehicleDynamicsComponent {
  readonly twin = inject(RollingStockTwinService);
  readonly activeScenario = signal<string>('CURVE_3000M');
}
