import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-requirements-viewer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">fact_check</mat-icon>
            <span>MODULE 08 // REQUIREMENTS ENGINEERING, V&V & TRACEABILITY</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            Requirements Management & Verification Evidence
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            Bidirectional requirements traceability linking customer specifications, TSI standards, physics simulations, manufacturing work orders, and field telemetry.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="px-2.5 py-1 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded font-bold">
            VERIFIED: {{ twin.requirementsVerified() }} / {{ twin.requirementsTotal() }} ({{ ((twin.requirementsVerified() / twin.requirementsTotal()) * 100).toFixed(1) }}%)
          </span>
        </div>
      </div>

      <!-- Requirements Table -->
      <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 class="font-bold text-white text-base font-mono">Formal System Requirements Repository</h2>
          <span class="text-xs font-mono text-slate-400">Click Requirement to Trace Links</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th class="py-2.5 px-3">Req ID</th>
                <th class="py-2.5 px-3">Requirement Title</th>
                <th class="py-2.5 px-3">Source Standard</th>
                <th class="py-2.5 px-3">V&V Method</th>
                <th class="py-2.5 px-3">Evidence Dossier</th>
                <th class="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 bg-slate-900/40 text-slate-300">
              @for (req of twin.requirements(); track req.id) {
                <tr class="hover:bg-slate-800/50 transition">
                  <td class="py-2.5 px-3 font-bold text-cyan-300">{{ req.id }}</td>
                  <td class="py-2.5 px-3 text-white font-semibold">
                    <div>{{ req.title }}</div>
                    <div class="text-[10px] text-slate-400 mt-0.5">{{ req.description }}</div>
                  </td>
                  <td class="py-2.5 px-3 text-slate-300">{{ req.source }}</td>
                  <td class="py-2.5 px-3 text-cyan-400">{{ req.verificationMethod }}</td>
                  <td class="py-2.5 px-3 text-slate-400 underline">{{ req.evidenceDoc }}</td>
                  <td class="py-2.5 px-3">
                    <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-bold">
                      {{ req.status }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class RequirementsViewerComponent {
  readonly twin = inject(RollingStockTwinService);
}
