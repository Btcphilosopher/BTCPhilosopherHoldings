import { Component, ChangeDetectionStrategy, inject, signal, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

interface TerminalLine {
  text: string;
  type: 'CMD' | 'OUTPUT' | 'SUCCESS' | 'ERROR';
}

@Component({
  selector: 'app-cli-terminal',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <!-- Modal Backdrop -->
    <div 
      role="dialog"
      aria-modal="true"
      tabindex="0"
      (click)="closed.emit()" 
      (keydown.escape)="closed.emit()" 
      class="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div 
        tabindex="0"
        role="document"
        (click)="$event.stopPropagation()" 
        (keydown)="$event.stopPropagation()"
        class="w-full max-w-3xl bg-slate-950 border border-slate-700 rounded-xl shadow-2xl overflow-hidden flex flex-col h-[520px]">
        <!-- Terminal Title Bar -->
        <div class="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs font-mono">
          <div class="flex items-center gap-2">
            <span class="w-3 h-3 rounded-full bg-red-500/80 inline-block"></span>
            <span class="w-3 h-3 rounded-full bg-amber-500/80 inline-block"></span>
            <span class="w-3 h-3 rounded-full bg-emerald-500/80 inline-block"></span>
            <span class="text-slate-300 ml-2 font-bold">rollingstock CLI &bull; Railway Engineering Workstation</span>
          </div>
          <button (click)="closed.emit()" class="text-slate-400 hover:text-white cursor-pointer">
            <mat-icon class="text-base">close</mat-icon>
          </button>
        </div>

        <!-- Terminal Output Area -->
        <div class="flex-1 p-4 overflow-y-auto space-y-1.5 font-mono text-xs text-slate-300 bg-slate-950">
          <div class="text-cyan-400">ROLLING STOCK//DIGITAL TWIN (v2026.4.1-rt)</div>
          <div class="text-slate-500">Type 'help' for available commands or 'simulate', 'trace', 'status', 'telemetry', 'clear'.</div>
          <div class="h-2"></div>

          @for (line of lines(); track $index) {
            <div 
              [class.text-cyan-300]="line.type === 'CMD'"
              [class.text-emerald-400]="line.type === 'SUCCESS'"
              [class.text-red-400]="line.type === 'ERROR'"
              [class.text-slate-300]="line.type === 'OUTPUT'"
              class="whitespace-pre-wrap leading-relaxed">
              {{ line.text }}
            </div>
          }
        </div>

        <!-- Terminal Prompt Input -->
        <div class="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2 font-mono text-xs">
          <span class="text-cyan-400 font-bold">rollingstock&gt;</span>
          <input 
            #cmdInput 
            (keyup.enter)="execCommand(cmdInput.value); cmdInput.value = ''" 
            placeholder="e.g. simulate vehicle-dynamics RSX-320"
            class="flex-1 bg-transparent text-slate-100 focus:outline-none placeholder:text-slate-600" />
        </div>
      </div>
    </div>
  `
})
export class CliTerminalComponent {
  readonly twin = inject(RollingStockTwinService);
  readonly closed = output<void>();


  readonly lines = signal<TerminalLine[]>([
    { text: 'rollingstock status RSX-320', type: 'CMD' },
    { text: 'Vehicle: RSX-320 Next-Gen High-Speed EMU (8 Cars)\nMax Speed: 320 km/h | Tare Mass: 432.0 t | Traction: 8.0 MW | Status: P1 ASSEMBLY (82% Freeze)', type: 'OUTPUT' }
  ]);


  execCommand(cmdStr: string) {
    const trimmed = cmdStr.trim();
    if (!trimmed) return;

    this.lines.update(l => [...l, { text: `rollingstock> ${trimmed}`, type: 'CMD' }]);
    const parts = trimmed.split(' ');
    const main = parts[0].toLowerCase();

    if (main === 'clear') {
      this.lines.set([]);
      return;
    }

    if (main === 'help') {
      this.lines.update(l => [...l, {
        text: `Available Commands:
  rollingstock status [vehicle]       - Display vehicle programme health and design freeze
  rollingstock simulate dynamics      - Run vehicle dynamics curve simulation
  rollingstock simulate traction      - Run 0-320 km/h acceleration run
  rollingstock trace [component]      - Query complete upstream & downstream digital thread
  rollingstock telemetry              - Display live operational telemetry stream
  rollingstock report [type]          - Generate engineering verification report
  rollingstock clear                  - Clear terminal screen`,
        type: 'OUTPUT'
      }]);
    } else if (main === 'simulate') {
      const sub = parts[1]?.toLowerCase() || 'traction';
      if (sub.includes('dynamics')) {
        this.lines.update(l => [...l, {
          text: `[SIM-DYN] Executing Multibody Dynamics (EN 14363) on RSX-320...
  Track: R = 3,000m, Cant Deficiency: 150mm, Speed: 300 km/h
  Result: Y/Q = 0.38 (Limit 0.80) - PASS
  Sperling Ride Index Wz = 2.12 (Very Good)`,
          type: 'SUCCESS'
        }]);
      } else {
        this.lines.update(l => [...l, {
          text: `[SIM-TRAC] Executing 0-320 km/h dynamic acceleration run...
  Power: 8.0 MW (8x 1000 kW PMSM) | Inverter: SiC 4QC (98.8% eff)
  Time to 320 km/h: 238.0 s | Distance: 12.82 km | Energy: 384 kWh - CONVERGED`,
          type: 'SUCCESS'
        }]);
      }
    } else if (main === 'trace') {
      this.lines.update(l => [...l, {
        text: `[DIGITAL THREAD] Component TRC-00421 (SiC Traction Converter):
  REQ-TRACTION-001 -> CAD-TRC-REV4 -> Batch AL-83921 -> Weld W-19382 -> NDT I-88291 -> Bench Test T-3818 -> Trainset RSX-320-001 -> Live Telemetry.
  Thread Status: 100% VERIFIED & AUDITED.`,
        type: 'SUCCESS'
      }]);
    } else if (main === 'status') {
      this.lines.update(l => [...l, {
        text: `RSX-320 Programme: 82% Design Freeze | 1,197/1,482 Requirements Verified | 37 Open ECRs | Prototype P1 Assembly`,
        type: 'OUTPUT'
      }]);
    } else if (main === 'telemetry') {
      const t = this.twin.telemetry();
      this.lines.update(l => [...l, {
        text: `RSX-320-001 Live Telemetry:
  Speed: ${t.speed_kmh} km/h | Voltage: ${t.lineVoltage_kV} kV | Bearing Vibration: ${t.bogie1Vibration_mms2} mm/s² | Status: ${t.status}`,
        type: 'OUTPUT'
      }]);
    } else {
      this.lines.update(l => [...l, {
        text: `Command not recognized: '${trimmed}'. Type 'help' for valid rollingstock commands.`,
        type: 'ERROR'
      }]);
    }
  }
}
