import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-parametric-cad',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">architecture</mat-icon>
            <span>MODULE 04 // PARAMETRIC VEHICLE CAD & GEOMETRY PROPAGATION</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            Parametric Vehicle Geometric Engine
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            Real-time multi-attribute parametric propagation. Changing carbody dimensions dynamically updates structural deflection, mass, interior capacity, axle loads, and aerodynamic drag.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="px-2.5 py-1 bg-cyan-950 text-cyan-300 border border-cyan-800 rounded">
            GAUGE: UIC 505-1 GC
          </span>
          <span class="px-2.5 py-1 bg-slate-800 text-slate-300 border border-slate-700 rounded">
            FEA ADAPTER: READY
          </span>
        </div>
      </div>

      <!-- Main Interactive CAD Blueprint & Sliders -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Interactive 2D Blueprint Schematic View -->
        <div class="lg:col-span-2 bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">straighten</mat-icon>
              <h2 class="font-bold text-white text-sm font-mono">TECHNICAL ELEVATION & GAUGING BLUEPRINT</h2>
            </div>
            <span class="text-xs font-mono text-emerald-400 flex items-center gap-1">
              <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              Synchronized with Digital Twin
            </span>
          </div>

          <!-- SVG CAD Blueprint -->
          <div class="bg-slate-950 p-6 rounded-xl border border-slate-800 relative bg-cad-grid">
            <svg viewBox="0 0 800 320" class="w-full h-80 select-none">
              <!-- Grid Lines and Centre Lines -->
              <line x1="40" y1="260" x2="760" y2="260" stroke="#334155" stroke-width="2" />
              <line x1="40" y1="265" x2="760" y2="265" stroke="#475569" stroke-dasharray="4 2" stroke-width="1" />
              <!-- Rail Top Level (TOR) -->
              <text x="50" y="278" fill="#64748b" font-size="9" font-family="monospace">TOR (Top of Rail) = 0.000m</text>

              <!-- Dynamic Scaled Dimensions -->
              @let lengthScale = (twin.carbodyLength_m() / 25.0);
              @let noseScale = (twin.noseLength_m() / 5.8);
              @let startX = 140;
              @let endX = startX + (460 * lengthScale);
              @let bogie1X = startX + 70;
              @let bogie2X = endX - 70;
              @let floorY = 260 - (twin.floorHeight_m() * 50);
              @let roofY = 260 - (twin.carbodyHeight_m() * 45);

              <!-- Nose Streamlining (Cab A) -->
              <path [attr.d]="'M ' + startX + ' ' + floorY + ' Q ' + (startX - (45 * noseScale)) + ' ' + (floorY + 10) + ' ' + (startX - (75 * noseScale)) + ' ' + (floorY - 20) + ' Q ' + (startX - (90 * noseScale)) + ' ' + (floorY - 55) + ' ' + startX + ' ' + roofY + ' Z'" 
                    fill="#0f2942" stroke="#38bdf8" stroke-width="2" />
              <!-- Windscreen Front -->
              <polygon [attr.points]="(startX - (35 * noseScale)) + ',' + (floorY - 35) + ' ' + (startX - 5) + ',' + (roofY + 20) + ' ' + (startX + 30) + ',' + (roofY + 20) + ' ' + (startX) + ',' + (floorY - 35)" 
                       fill="#0284c7" opacity="0.6" stroke="#0ea5e9" stroke-width="1" />

              <!-- Main Carbody Rectangle -->
              <rect [attr.x]="startX" [attr.y]="roofY" [attr.width]="endX - startX" [attr.height]="floorY - roofY" 
                    fill="#091824" stroke="#38bdf8" stroke-width="2" rx="2" />

              <!-- Windows and Passenger Area -->
              @for (w of [1, 2, 3, 4, 5, 6, 7]; track w) {
                <rect [attr.x]="startX + 30 + (w * ((endX - startX - 70) / 8))" [attr.y]="roofY + 35" width="28" height="24" rx="2" fill="#0369a1" opacity="0.5" stroke="#38bdf8" stroke-width="1" />
              }

              <!-- Passenger Doors -->
              <rect [attr.x]="startX + 15" [attr.y]="roofY + 15" width="18" [attr.height]="floorY - roofY - 15" fill="#1e293b" stroke="#06b6d4" stroke-width="1.5" />
              <rect [attr.x]="endX - 35" [attr.y]="roofY + 15" width="18" [attr.height]="floorY - roofY - 15" fill="#1e293b" stroke="#06b6d4" stroke-width="1.5" />

              <!-- Roof Equipment & Active Pantograph -->
              <rect [attr.x]="startX + 80" [attr.y]="roofY - 12" width="220" height="12" rx="2" fill="#1e293b" stroke="#64748b" stroke-width="1.5" />
              <path [attr.d]="'M ' + (startX + 180) + ' ' + (roofY - 12) + ' L ' + (startX + 215) + ' ' + (roofY - 45) + ' L ' + (startX + 250) + ' ' + (roofY - 50)" 
                    fill="none" stroke="#f59e0b" stroke-width="3" />
              <line [attr.x1]="startX + 235" [attr.y1]="roofY - 52" [attr.x2]="startX + 275" [attr.y2]="roofY - 52" stroke="#f59e0b" stroke-width="4" />

              <!-- Bogie 1 -->
              <g>
                <rect [attr.x]="bogie1X - 32" [attr.y]="floorY" width="64" height="14" rx="2" fill="#06b6d4" stroke="#0891b2" stroke-width="1.5" />
                <circle [attr.cx]="bogie1X - 20" cy="245" r="14" fill="#1e293b" stroke="#94a3b8" stroke-width="2.5" />
                <circle [attr.cx]="bogie1X + 20" cy="245" r="14" fill="#1e293b" stroke="#94a3b8" stroke-width="2.5" />
              </g>

              <!-- Bogie 2 -->
              <g>
                <rect [attr.x]="bogie2X - 32" [attr.y]="floorY" width="64" height="14" rx="2" fill="#06b6d4" stroke="#0891b2" stroke-width="1.5" />
                <circle [attr.cx]="bogie2X - 20" cy="245" r="14" fill="#1e293b" stroke="#94a3b8" stroke-width="2.5" />
                <circle [attr.cx]="bogie2X + 20" cy="245" r="14" fill="#1e293b" stroke="#94a3b8" stroke-width="2.5" />
              </g>

              <!-- Dimension Callout: Total Carbody Length -->
              <line [attr.x1]="startX" y1="35" [attr.x2]="endX" y2="35" stroke="#06b6d4" stroke-width="1.5" marker-start="url(#dot)" marker-end="url(#dot)" />
              <text [attr.x]="(startX + endX) / 2" y="28" text-anchor="middle" fill="#22d3ee" font-size="11" font-family="monospace" font-weight="bold">
                L_carbody = {{ twin.carbodyLength_m() }} m
              </text>

              <!-- Dimension Callout: Bogie Centre Distance -->
              <line [attr.x1]="bogie1X" y1="285" [attr.x2]="bogie2X" y2="285" stroke="#e2e8f0" stroke-width="1.5" />
              <text [attr.x]="(bogie1X + bogie2X) / 2" y="302" text-anchor="middle" fill="#e2e8f0" font-size="10" font-family="monospace">
                Bogie Centres = {{ (twin.carbodyLength_m() * 0.7).toFixed(2) }} m
              </text>

              <!-- Dimension Callout: Carbody Height -->
              <line x1="30" [attr.y1]="roofY" x2="30" y2="260" stroke="#a855f7" stroke-width="1.5" />
              <text x="24" [attr.y]="(roofY + 260) / 2" text-anchor="middle" fill="#c084fc" font-size="10" font-family="monospace" transform="rotate(-90 24,150)">
                H = {{ twin.carbodyHeight_m() }} m
              </text>
            </svg>
          </div>
        </div>

        <!-- Parametric Dimensions Controller & Sliders -->
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-5">
          <div class="border-b border-slate-800 pb-3">
            <h3 class="font-bold text-white text-sm font-mono flex items-center gap-2">
              <mat-icon class="text-cyan-400 text-base">sliders</mat-icon>
              <span>PARAMETRIC GEOMETRY CONTROLS</span>
            </h3>
            <p class="text-[11px] text-slate-400 mt-1">
              Modifying these values cascades into structural bending, mass balance, passenger seating, and aerodynamic drag.
            </p>
          </div>

          <!-- Parameter: Carbody Length -->
          <div class="space-y-1.5 font-mono text-xs">
            <div class="flex justify-between items-center text-slate-300">
              <span>Carbody Length:</span>
              <span class="font-bold text-cyan-300 text-sm">{{ twin.carbodyLength_m() }} m</span>
            </div>
            <input 
              type="range" 
              min="20.0" 
              max="28.0" 
              step="0.5" 
              [value]="twin.carbodyLength_m()" 
              (input)="onLengthChange($event)"
              class="w-full accent-cyan-500 cursor-pointer" />
            <div class="flex justify-between text-[10px] text-slate-500">
              <span>20.0 m</span>
              <span>Nominal: 25.0 m</span>
              <span>28.0 m</span>
            </div>
          </div>

          <!-- Parameter: Nose Length -->
          <div class="space-y-1.5 font-mono text-xs">
            <div class="flex justify-between items-center text-slate-300">
              <span>Cab Nose Length (Rake):</span>
              <span class="font-bold text-cyan-300 text-sm">{{ twin.noseLength_m() }} m</span>
            </div>
            <input 
              type="range" 
              min="4.0" 
              max="8.0" 
              step="0.2" 
              [value]="twin.noseLength_m()" 
              (input)="onNoseChange($event)"
              class="w-full accent-cyan-500 cursor-pointer" />
            <div class="flex justify-between text-[10px] text-slate-500">
              <span>4.0 m</span>
              <span>Nominal: 5.8 m</span>
              <span>8.0 m</span>
            </div>
          </div>

          <!-- Parameter: Carbody Width -->
          <div class="space-y-1.5 font-mono text-xs">
            <div class="flex justify-between items-center text-slate-300">
              <span>Carbody Width:</span>
              <span class="font-bold text-white text-sm">{{ twin.carbodyWidth_m() }} m</span>
            </div>
            <input 
              type="range" 
              min="2.80" 
              max="3.10" 
              step="0.02" 
              [value]="twin.carbodyWidth_m()" 
              (input)="twin.carbodyWidth_m.set(+($any($event.target).value))"
              class="w-full accent-cyan-500 cursor-pointer" />
            <div class="flex justify-between text-[10px] text-slate-500">
              <span>2.80 m</span>
              <span>UIC Limit: 2.92 m</span>
              <span>3.10 m</span>
            </div>
          </div>

          <!-- Parameter: Carbody Height -->
          <div class="space-y-1.5 font-mono text-xs">
            <div class="flex justify-between items-center text-slate-300">
              <span>Carbody Height:</span>
              <span class="font-bold text-white text-sm">{{ twin.carbodyHeight_m() }} m</span>
            </div>
            <input 
              type="range" 
              min="3.60" 
              max="4.10" 
              step="0.02" 
              [value]="twin.carbodyHeight_m()" 
              (input)="twin.carbodyHeight_m.set(+($any($event.target).value))"
              class="w-full accent-cyan-500 cursor-pointer" />
          </div>

          <!-- Dynamic Parameter Propagation Matrix (What Changed?) -->
          <div class="pt-3 border-t border-slate-800 space-y-2 text-xs font-mono">
            <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              CASCADING PROPAGATION AUDIT
            </div>
            <div class="bg-slate-950 p-2.5 rounded border border-slate-800/80 space-y-1 text-[11px]">
              <div class="flex justify-between text-slate-300">
                <span>Calculated Drag Area (Cx*A):</span>
                <span class="text-cyan-300 font-bold">{{ (twin.aeroCd() * twin.frontalArea_m2()).toFixed(2) }} m²</span>
              </div>
              <div class="flex justify-between text-slate-300">
                <span>Bodyshell Max Deflection:</span>
                <span class="text-emerald-400 font-bold">{{ (14.2 * (twin.carbodyLength_m() / 25.0)).toFixed(1) }} mm (&lt; 25mm limit)</span>
              </div>
              <div class="flex justify-between text-slate-300">
                <span>Weld Seam Fabrication:</span>
                <span class="text-slate-300 font-bold">{{ (1240 * (twin.carbodyLength_m() / 25.0)).toFixed(0) }} m total welds</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ParametricCadComponent {
  readonly twin = inject(RollingStockTwinService);

  onLengthChange(event: Event) {
    const val = +((event.target as HTMLInputElement).value);
    this.twin.updateParametricCarbodyLength(val);
  }

  onNoseChange(event: Event) {
    const val = +((event.target as HTMLInputElement).value);
    this.twin.updateNoseLength(val);
  }
}
