import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-systems-engineering',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">account_tree</mat-icon>
            <span>MODULE 05 // SYSTEMS ENGINEERING & N2 INTERFACE MATRIX</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            Systems Architecture & Interface Dependencies
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            Formal interface definition and functional decomposition connecting Traction, Braking, TCMS, HVAC, Doors, Auxiliary Power, Bogies, and Safety loops.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="px-2.5 py-1 bg-cyan-950 text-cyan-300 border border-cyan-800 rounded">
            NETWORK: ETB / TRDP (IEC 61375)
          </span>
          <span class="px-2.5 py-1 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded">
            INTERFACES: 48 VERIFIED
          </span>
        </div>
      </div>

      <!-- Systems N2 Matrix -->
      <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">grid_on</mat-icon>
            <h2 class="font-bold text-white text-base">Systems Interface Matrix (N² Diagram)</h2>
          </div>
          <span class="text-xs font-mono text-slate-400">Click any interface cell to view signals</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-center text-xs font-mono border-collapse">
            <thead>
              <tr class="bg-slate-950 text-slate-400">
                <th class="p-2 border border-slate-800 text-left">Subsystem</th>
                @for (sys of systems; track sys) {
                  <th class="p-2 border border-slate-800 truncate max-w-[80px]">{{ sys }}</th>
                }
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 bg-slate-900/40">
              @for (row of systems; track row; let rIdx = $index) {
                <tr>
                  <td class="p-2 border border-slate-800 text-left font-bold text-cyan-300 bg-slate-950/60 truncate max-w-[120px]">
                    {{ row }}
                  </td>
                  @for (col of systems; track col; let cIdx = $index) {
                    <td 
                      [class.bg-slate-800]="rIdx === cIdx"
                      [class.text-slate-500]="rIdx === cIdx"
                      [class.bg-cyan-950/60]="rIdx !== cIdx && hasInterface(row, col)"
                      [class.text-cyan-300]="rIdx !== cIdx && hasInterface(row, col)"
                      [class.border-cyan-800]="rIdx !== cIdx && hasInterface(row, col)"
                      class="p-2 border border-slate-800/80 text-[10px]">
                      @if (rIdx === cIdx) {
                        <span>DIAG</span>
                      } @else if (hasInterface(row, col)) {
                        <span class="font-bold">{{ getInterfaceType(row, col) }}</span>
                      } @else {
                        <span class="text-slate-700">-</span>
                      }
                    </td>
                  }
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- TCMS Train Control & Ethernet Train Backbone Topology -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">memory</mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">TCMS DUAL-REDUNDANT ARCHITECTURE</h3>
            </div>
            <span class="text-[10px] font-mono text-cyan-300 bg-cyan-950 border border-cyan-800 px-2 py-0.5 rounded">
              IEC 61375-2-3 TRDP
            </span>
          </div>

          <div class="space-y-2 text-xs font-mono">
            <div class="bg-slate-950 p-3 rounded border border-slate-800">
              <div class="text-slate-400 font-bold mb-1">Ethernet Train Backbone (ETB):</div>
              <div class="text-[11px] text-slate-300">
                Dual 1 Gbps redundant ring spanning Cars 1 to 8 with sub-millisecond failover bypass relays conforming to IEC 61375-2-5.
              </div>
            </div>
            <div class="bg-slate-950 p-3 rounded border border-slate-800">
              <div class="text-slate-400 font-bold mb-1">Ethernet Consist Network (ECN):</div>
              <div class="text-[11px] text-slate-300">
                100 Mbps deterministic TRDP real-time control protocol between CCU, EBCU brake controllers, and traction inverters.
              </div>
            </div>
          </div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">security</mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">CYBERSECURITY SEGMENTATION (TS 50701)</h3>
            </div>
            <span class="text-[10px] font-mono text-emerald-400 bg-emerald-950 border border-emerald-800 px-2 py-0.5 rounded">
              SECURITY LEVEL SL-3
            </span>
          </div>

          <div class="space-y-2 text-xs font-mono">
            <div class="p-2.5 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
              <div>
                <div class="text-rose-400 font-bold">Zone 1: Safety-Critical Vital Zone</div>
                <div class="text-[10px] text-slate-400">TCMS CCU, EBCU Brakes, Traction Controllers (SIL 4)</div>
              </div>
              <span class="text-[10px] text-rose-300 bg-rose-950 px-2 py-0.5 rounded border border-rose-800 font-bold">AIR-GAPPED</span>
            </div>
            <div class="p-2.5 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
              <div>
                <div class="text-amber-400 font-bold">Zone 2: Operational Non-Vital Zone</div>
                <div class="text-[10px] text-slate-400">HVAC, Doors, Passenger Info PIS, CCTV</div>
              </div>
              <span class="text-[10px] text-amber-300 bg-amber-950 px-2 py-0.5 rounded border border-amber-800 font-bold">FIREWALLED</span>
            </div>
            <div class="p-2.5 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
              <div>
                <div class="text-cyan-400 font-bold">Zone 3: Passenger & External Gateway</div>
                <div class="text-[10px] text-slate-400">Onboard Passenger Wi-Fi, 5G Cellular Gateway</div>
              </div>
              <span class="text-[10px] text-cyan-300 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800 font-bold">PUBLIC</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class SystemsEngineeringComponent {
  readonly twin = inject(RollingStockTwinService);

  readonly systems = [
    'Traction',
    'Braking',
    'TCMS',
    'HVAC',
    'Doors',
    'Aux Power',
    'Bogies',
    'Safety'
  ];

  hasInterface(row: string, col: string): boolean {
    const connected = [
      'Traction-TCMS', 'Traction-Braking', 'Traction-Aux Power', 'Traction-Bogies',
      'Braking-TCMS', 'Braking-Safety', 'Braking-Bogies',
      'TCMS-HVAC', 'TCMS-Doors', 'TCMS-Aux Power', 'TCMS-Safety',
      'Doors-Safety', 'Doors-TCMS',
      'Aux Power-HVAC'
    ];
    return connected.includes(`${row}-${col}`) || connected.includes(`${col}-${row}`);
  }

  getInterfaceType(row: string, col: string): string {
    if ((row === 'Traction' && col === 'TCMS') || (row === 'TCMS' && col === 'Traction')) return 'TRDP';
    if ((row === 'Braking' && col === 'TCMS') || (row === 'TCMS' && col === 'Braking')) return 'SIL4';
    if ((row === 'Braking' && col === 'Safety') || (row === 'Safety' && col === 'Braking')) return 'LOOP';
    if ((row === 'Traction' && col === 'Braking') || (row === 'Braking' && col === 'Traction')) return 'BLND';
    if ((row === 'Traction' && col === 'Aux Power')) return 'DC LINK';
    return 'DATA';
  }
}
