import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from '../../services/rolling-stock-twin.service';

@Component({
  selector: 'app-traction-powertrain',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-7xl mx-auto overflow-y-auto h-full">
      <!-- Top Title Bar -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">bolt</mat-icon>
            <span>MODULE 10 // ELECTRIC TRACTION CHAIN & ACCELERATION DYNAMICS</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white">
            Traction Powertrain & Tractive-Effort Simulation
          </h1>
          <p class="text-xs text-slate-400 mt-1">
            Complete high-voltage propulsion chain: 25 kV AC Catenary &rarr; Transformer &rarr; SiC 4QC Converter &rarr; 8x 1,000 kW PMSM Motors &rarr; Gearbox &rarr; Wheel-Rail Adhesion.
          </p>
        </div>

        <div class="flex items-center gap-3">
          <button 
            (click)="runAccelerationSimulation()"
            [disabled]="isSimulating()"
            class="px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-lg text-xs font-medium font-mono flex items-center gap-2 shadow-sm transition cursor-pointer disabled:opacity-50">
            <mat-icon class="text-sm">{{ isSimulating() ? 'hourglass_top' : 'play_arrow' }}</mat-icon>
            <span>{{ isSimulating() ? 'Simulating 0-320 km/h...' : 'Run 0&rarr;320 km/h Sim' }}</span>
          </button>
        </div>
      </div>

      <!-- Traction Chain Schematic & Power Flow -->
      <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">account_tree</mat-icon>
            <h2 class="font-bold text-white text-sm font-mono">HIGH-VOLTAGE PROPULSION CHAIN (25 kV 50 Hz AC)</h2>
          </div>
          <span class="text-xs font-mono text-cyan-300 bg-cyan-950/80 border border-cyan-800 px-2.5 py-0.5 rounded">
            Total Installed Power: {{ twin.totalTractionPower_MW() }} MW
          </span>
        </div>

        <!-- Visual Architecture Pipeline -->
        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 text-xs font-mono">
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col justify-between text-center">
            <div class="text-slate-500 text-[10px]">CURRENT COLLECTION</div>
            <div class="font-bold text-amber-400 my-1">Pantograph 25kV</div>
            <div class="text-[9px] text-slate-400">PANT-500 Carbon Strip</div>
          </div>
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col justify-between text-center">
            <div class="text-slate-500 text-[10px]">MAIN TRANSFORMER</div>
            <div class="font-bold text-slate-200 my-1">8.8 MVA Multi-Tap</div>
            <div class="text-[9px] text-slate-400">Ester Fluid Cooled</div>
          </div>
          <div class="bg-slate-950 p-3 rounded-lg border border-cyan-500/50 flex flex-col justify-between text-center bg-cyan-950/20">
            <div class="text-cyan-400 text-[10px] font-bold">SiC CONVERTERS</div>
            <div class="font-bold text-cyan-300 my-1">TRC-00421 (4x)</div>
            <div class="text-[9px] text-emerald-400">98.8% Inverter Eff.</div>
          </div>
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col justify-between text-center">
            <div class="text-slate-500 text-[10px]">TRACTION MOTORS</div>
            <div class="font-bold text-slate-200 my-1">8x 1,000 kW PMSM</div>
            <div class="text-[9px] text-slate-400">MOT-600 TSA Austria</div>
          </div>
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col justify-between text-center">
            <div class="text-slate-500 text-[10px]">TRANSMISSION</div>
            <div class="font-bold text-slate-200 my-1">Helical Gearbox</div>
            <div class="text-[9px] text-slate-400">Ratio i = 2.48</div>
          </div>
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col justify-between text-center">
            <div class="text-slate-500 text-[10px]">RUNNING GEAR</div>
            <div class="font-bold text-slate-200 my-1">BOG-201 Motor Bogie</div>
            <div class="text-[9px] text-slate-400">Lucchini R8T Forged</div>
          </div>
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col justify-between text-center">
            <div class="text-slate-500 text-[10px]">WHEEL-RAIL INTERFACE</div>
            <div class="font-bold text-emerald-400 my-1">&mu; = 0.28 (Adhesion)</div>
            <div class="text-[9px] text-slate-400">UIC 60 Rail Track</div>
          </div>
        </div>
      </div>

      <!-- Tractive Effort Hyperbolic Curve F(v) & Dynamic Simulation Plot -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Interactive Tractive-Effort Curve Chart -->
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">show_chart</mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">TRACTIVE EFFORT F(v) & RESISTANCE CURVE</h3>
            </div>
            <span class="text-[11px] font-mono text-slate-400">8.0 MW Envelope</span>
          </div>

          <!-- SVG Chart for Tractive Effort Curve -->
          <div class="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <svg viewBox="0 0 500 240" class="w-full h-56 select-none font-mono text-[10px]">
              <!-- Grid lines -->
              @for (y of [40, 80, 120, 160, 200]; track y) {
                <line x1="40" [attr.y1]="y" x2="480" [attr.y2]="y" stroke="#1e293b" stroke-dasharray="2 2" />
              }
              @for (x of [100, 180, 260, 340, 420]; track x) {
                <line [attr.x1]="x" y1="20" [attr.x2]="x" y2="200" stroke="#1e293b" stroke-dasharray="2 2" />
              }

              <!-- Axes -->
              <line x1="40" y1="200" x2="480" y2="200" stroke="#475569" stroke-width="1.5" />
              <line x1="40" y1="20" x2="40" y2="200" stroke="#475569" stroke-width="1.5" />

              <!-- Axis Labels -->
              <text x="40" y="215" fill="#64748b" text-anchor="middle">0</text>
              <text x="180" y="215" fill="#64748b" text-anchor="middle">100</text>
              <text x="320" y="215" fill="#64748b" text-anchor="middle">200</text>
              <text x="440" y="215" fill="#38bdf8" font-weight="bold" text-anchor="middle">320 km/h</text>
              <text x="480" y="215" fill="#64748b" text-anchor="end">Speed (km/h)</text>

              <text x="35" y="200" fill="#64748b" text-anchor="end">0</text>
              <text x="35" y="140" fill="#64748b" text-anchor="end">100</text>
              <text x="35" y="80" fill="#64748b" text-anchor="end">200</text>
              <text x="35" y="30" fill="#22d3ee" font-weight="bold" text-anchor="end">240 kN</text>

              <!-- Constant Starting Force (0 to 120 km/h) -> Hyperbolic Constant Power (120 to 320 km/h) -->
              <path d="M 40 30 L 208 30 Q 300 80 440 135" fill="none" stroke="#06b6d4" stroke-width="3" />
              <!-- Running Resistance (Davis Formula: R = A + B*v + C*v^2) -->
              <path d="M 40 195 Q 240 190 440 145" fill="none" stroke="#f43f5e" stroke-width="2" stroke-dasharray="4 2" />

              <!-- Legend -->
              <g transform="translate(240, 35)">
                <rect x="0" y="0" width="220" height="42" rx="4" fill="#0f172a" opacity="0.9" stroke="#334155" />
                <line x1="10" y1="14" x2="30" y2="14" stroke="#06b6d4" stroke-width="3" />
                <text x="36" y="17" fill="#e2e8f0" font-size="9">Tractive Effort F_max (kN)</text>
                <line x1="10" y1="28" x2="30" y2="28" stroke="#f43f5e" stroke-width="2" stroke-dasharray="4 2" />
                <text x="36" y="31" fill="#cbd5e1" font-size="9">Total Running Resistance R(v)</text>
              </g>

              <!-- Balancing Speed Point at 320 km/h -->
              <circle cx="440" cy="135" r="4" fill="#06b6d4" />
              <text x="430" y="125" fill="#38bdf8" font-size="9" font-weight="bold">F_net = 90 kN @ 320 km/h</text>
            </svg>
          </div>
        </div>

        <!-- 0-320 km/h Acceleration Dynamic Run Result -->
        <div class="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">timer</mat-icon>
              <h3 class="font-bold text-white text-sm font-mono">0 &rarr; 320 KM/H DYNAMIC RUN PROFILE</h3>
            </div>
            <span class="text-[11px] font-mono text-emerald-400 font-bold">
              Time to 320: {{ twin.accelerationTimeTo320_s() }} s
            </span>
          </div>

          <div class="space-y-3 text-xs font-mono">
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80 grid grid-cols-3 gap-2 text-center">
              <div>
                <div class="text-slate-500 text-[10px]">TIME TO 320 KM/H</div>
                <div class="text-base font-bold text-cyan-300 mt-0.5">{{ twin.accelerationTimeTo320_s() }} s</div>
                <div class="text-[9px] text-emerald-400">&le; 240s (TSI Pass)</div>
              </div>
              <div>
                <div class="text-slate-500 text-[10px]">DISTANCE COVERED</div>
                <div class="text-base font-bold text-white mt-0.5">12.8 km</div>
                <div class="text-[9px] text-slate-400">Tangent Track</div>
              </div>
              <div>
                <div class="text-slate-500 text-[10px]">ENERGY CONSUMED</div>
                <div class="text-base font-bold text-white mt-0.5">384 kWh</div>
                <div class="text-[9px] text-slate-400">30.0 kWh/km</div>
              </div>
            </div>

            <!-- Acceleration Stepped Milestones Table -->
            <div class="border border-slate-800 rounded-lg overflow-hidden">
              <table class="w-full text-left text-[11px]">
                <thead class="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th class="py-1.5 px-3">Target Speed</th>
                    <th class="py-1.5 px-3">Elapsed Time</th>
                    <th class="py-1.5 px-3">Distance</th>
                    <th class="py-1.5 px-3">Tractive Power</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/60 bg-slate-900/40 text-slate-300">
                  <tr>
                    <td class="py-1.5 px-3 text-cyan-300 font-bold">0 &rarr; 100 km/h</td>
                    <td class="py-1.5 px-3">38.4 s</td>
                    <td class="py-1.5 px-3">533 m</td>
                    <td class="py-1.5 px-3">6,650 kW</td>
                  </tr>
                  <tr>
                    <td class="py-1.5 px-3 text-cyan-300 font-bold">0 &rarr; 200 km/h</td>
                    <td class="py-1.5 px-3">94.2 s</td>
                    <td class="py-1.5 px-3">2,850 m</td>
                    <td class="py-1.5 px-3">8,000 kW (Max)</td>
                  </tr>
                  <tr>
                    <td class="py-1.5 px-3 text-cyan-300 font-bold">0 &rarr; 300 km/h</td>
                    <td class="py-1.5 px-3">188.0 s</td>
                    <td class="py-1.5 px-3">8,950 m</td>
                    <td class="py-1.5 px-3">8,000 kW (Max)</td>
                  </tr>
                  <tr>
                    <td class="py-1.5 px-3 text-emerald-400 font-bold">0 &rarr; 320 km/h</td>
                    <td class="py-1.5 px-3 text-emerald-400 font-bold">{{ twin.accelerationTimeTo320_s() }} s</td>
                    <td class="py-1.5 px-3">12,820 m</td>
                    <td class="py-1.5 px-3">8,000 kW</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TractionPowertrainComponent {
  readonly twin = inject(RollingStockTwinService);
  readonly isSimulating = signal<boolean>(false);

  runAccelerationSimulation() {
    this.isSimulating.set(true);
    setTimeout(() => {
      this.isSimulating.set(false);
    }, 1200);
  }
}
