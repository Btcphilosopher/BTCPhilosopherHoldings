import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RollingStockTwinService } from './services/rolling-stock-twin.service';
import { HeaderComponent } from './components/header/header';
import { NavigationComponent } from './components/navigation/navigation';
import { CommandCentreComponent } from './components/command-centre/command-centre';
import { TrainDesignerComponent } from './components/train-designer/train-designer';
import { ParametricCadComponent } from './components/parametric-cad/parametric-cad';
import { TractionPowertrainComponent } from './components/traction-powertrain/traction-powertrain';
import { BrakingSystemComponent } from './components/braking-system/braking-system';
import { VehicleDynamicsComponent } from './components/vehicle-dynamics/vehicle-dynamics';
import { BogieTwinComponent } from './components/bogie-twin/bogie-twin';
import { FactoryTwinComponent } from './components/factory-twin/factory-twin';
import { DigitalThreadComponent } from './components/digital-thread/digital-thread';
import { FleetOperationsComponent } from './components/fleet-operations/fleet-operations';
import { ScenarioLabComponent } from './components/scenario-lab/scenario-lab';
import { SystemsEngineeringComponent } from './components/systems-engineering/systems-engineering';
import { QualityRamsComponent } from './components/quality-rams/quality-rams';
import { BatteryHydrogenComponent } from './components/battery-hydrogen/battery-hydrogen';
import { ThermalHvacComponent } from './components/thermal-hvac/thermal-hvac';
import { RequirementsViewerComponent } from './components/requirements-viewer/requirements-viewer';
import { RailAiAssistantComponent } from './components/rail-ai-assistant/rail-ai-assistant';
import { CliTerminalComponent } from './components/cli-terminal/cli-terminal';
import { ReportModalComponent } from './components/report-modal/report-modal';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    HeaderComponent,
    NavigationComponent,
    CommandCentreComponent,
    TrainDesignerComponent,
    ParametricCadComponent,
    TractionPowertrainComponent,
    BrakingSystemComponent,
    VehicleDynamicsComponent,
    BogieTwinComponent,
    FactoryTwinComponent,
    DigitalThreadComponent,
    FleetOperationsComponent,
    ScenarioLabComponent,
    SystemsEngineeringComponent,
    QualityRamsComponent,
    BatteryHydrogenComponent,
    ThermalHvacComponent,
    RequirementsViewerComponent,
    RailAiAssistantComponent,
    CliTerminalComponent,
    ReportModalComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly twin = inject(RollingStockTwinService);
}

