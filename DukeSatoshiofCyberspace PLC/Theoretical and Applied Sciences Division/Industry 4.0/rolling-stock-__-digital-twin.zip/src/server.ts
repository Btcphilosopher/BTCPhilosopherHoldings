import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {GoogleGenAI} from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());
const angularApp = new AngularNodeAppEngine();

// REST API V1 Endpoints for Rolling Stock Platform
app.get('/api/v1/programmes', (req, res) => {
  res.json({
    programme: 'RSX-320',
    name: 'RSX-320 Next-Gen High-Speed Electric Multiple Unit',
    designFreezePct: 82,
    requirements: { total: 1482, verified: 1197, openECRs: 37 },
    simulationRuns: 8421,
    manufacturingReadinessPct: 76,
    certificationEvidencePct: 68,
    prototypeStatus: 'P1 — ASSEMBLY'
  });
});

app.get('/api/v1/vehicles', (req, res) => {
  res.json({
    code: 'RSX-320-EMU8',
    maxSpeed_kmh: 320,
    length_m: 200.0,
    formation: '8-Car EMU (DT-M-M-S-T-M-M-DT)',
    massTare_t: 432.0,
    seats: 584,
    power_MW: 8.0,
    voltage: '25kV 50Hz AC / 15kV 16.7Hz'
  });
});

app.get('/api/v1/telemetry', (req, res) => {
  res.json({
    trainsetId: 'RSX-320-001',
    speed_kmh: 318.4,
    locationKm: 142.8,
    lineVoltage_kV: 25.4,
    catenaryCurrent_A: 312.6,
    tractiveEffort_kN: 89.4,
    bogie1Vibration_mms2: 2.1,
    status: 'IN_SERVICE',
    timestamp: new Date().toISOString()
  });
});

// RAIL.AI Intelligent Engineering Copilot Endpoint
app.post('/api/rail-ai', async (req, res): Promise<void> => {
  const query = req.body?.prompt || 'Explain RSX-320 digital thread architecture';
  const apiKey = process.env['GEMINI_API_KEY'];

  if (apiKey) {
    try {
      const ai = new GoogleGenAI({ apiKey });
      const systemInstruction = `You are RAIL.AI, an expert Rolling Stock Systems, Multiphysics Simulation, and Manufacturing Digital Twin Copilot embedded in the RSX-320 platform.
You assist railway engineers (mechanical, traction, dynamics, RAMS, manufacturing, quality, certification).
Always refer to synthetic engineering metrics:
- Vehicle: RSX-320 8-car High-Speed EMU, 320 km/h design speed, 200m length, 432 t tare mass, 8.0 MW traction power (8x 1000 kW PMSM motors), 584 seats, 13.6 t/axle load.
- Standards: TSI LOC&PAS (EU 1302/2014), EN 14363 running dynamics (Y/Q limit 0.8), EN 15227 crashworthiness (1500 kN static compressive load), EN 50126 RAMS, TS 50701 Cyber.
- Digital thread: REQ-TRACTION-001 -> Converter TRC-00421 -> Batch AL-83921 -> Weld W-19382 -> NDT Inspection I-88291 -> Bench Test T-3818.
- Factory: Northfield Rail Systems (7 Halls, 20 Stations, Takt Time 18h).
Provide precise, technical, concise railway engineering answers. Never give generic consumer advice. Format in clean bullet points with technical rigor.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: query,
        config: {
          systemInstruction,
          temperature: 0.2,
          maxOutputTokens: 1000,
        }
      });

      res.json({
        answer: response.text || 'Engineering analysis complete.',
        source: 'GEMINI_3.8_FLASH',
        model: 'gemini-3.8-flash',
        confidence: 0.98
      });
      return;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      console.warn('Gemini API error, using deterministic engineering fallback:', msg);
    }
  }

  // Engineering deterministic fallback response
  let answer = `**RAIL.AI Engineering Intelligence Report:**\n\n`;
  const lower = query.toLowerCase();
  if (lower.includes('speed') || lower.includes('320') || lower.includes('increase')) {
    answer += `**Max Speed Impact Analysis (300 km/h -> 320 km/h):**\n• **Aerodynamics:** Drag force increases by ~13.8% ($F_{drag} \\propto v^2$), requiring aerodynamic nose rake refinement ($C_x A \\le 1.54 \\text{ m}^2$).\n• **Traction Power:** Continuous tractive effort demand at 320 km/h is 90 kN (requires 8.0 MW installed traction capacity).\n• **Braking:** Thermal dissipation on wheel-mounted carbon-ceramic discs increases by +14.2%, stopping distance remains 2,980 m (well within TSI limit 3,050 m).\n• **Dynamics:** Sperling ride index $W_z$ is 2.12 (Good), $Y/Q$ derailment factor 0.38 (safe vs 0.80 limit per EN 14363).`;
  } else if (lower.includes('bottleneck') || lower.includes('factory') || lower.includes('production')) {
    answer += `**Factory Line Bottleneck Analysis (Northfield Rail Systems):**\n• Current bottleneck detected at **Station 06: Underframe & Roof Equipment Installation** (Cycle time 19.5h vs 18.0h takt).\n• WIP Queue: 2 cars waiting in buffer.\n• **Recommendation:** Deploy 1 additional dual-crane lifting rig to parallelize SiC converter mounting and reduce cycle time to 16.2h.`;
  } else if (lower.includes('vibration') || lower.includes('anomaly') || lower.includes('maintenance')) {
    answer += `**Predictive Maintenance Health Assessment:**\n• **Signal:** Bogie 1 Axlebox bearing vibration peak monitored at 14.8 mm/s² RMS (ISO 10816-3 Zone D Alert).\n• **Spectral Analysis:** Characteristic outer race ball pass frequency (BPFO) detected at 142.4 Hz.\n• **Action:** Work order WO-DEP-2026-9904 dispatched to Temple Mills Depot for bearing replacement within 48 operational hours.`;
  } else {
    answer += `**Digital Thread State: RSX-320 Programme (P1 Assembly):**\n• Requirements verification: 1,197 / 1,482 verified (80.8%).\n• Digital Thread Continuity: Component TRC-00421 fully traced from Material Batch AL-83921 -> Weld W-19382 -> NDT Inspection I-88291 -> Bench Test T-3818 -> Requirement REQ-TRACTION-001.\n• Fleet Health: 4/5 Trainsets active with 99.4% average availability.`;
  }

  res.json({
    answer,
    source: 'RSX_ENGINEERING_CORE_KNOWLEDGE',
    model: 'deterministic-knowledge-graph',
    confidence: 0.99
  });
  return;
});


/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);

