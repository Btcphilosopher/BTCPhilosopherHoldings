# AUREOM FACTORY — Materials to Finished Goods

An integrated manufacturing platform that follows material from purchased raw stock through production,
quality inspection, finished inventory and dispatch, with one traceable material history and costs at
every step.

* **Workflow:** demand → production plan → material requirements → purchasing → goods receipt →
  inspection → allocation → production → quality checks → finished stock → dispatch; plus
  subassemblies, packaging, scrap, rework, supplier returns, subcontracted operations and recalls.
* **Principles:** planned activity, physical movements, recorded consumption and quality-accepted
  output are kept distinct; journals are append-only; quarantined or rejected material cannot be
  allocated; released orders keep frozen BOM/routing revisions; traceability states its precision
  instead of inventing exact links; costs separate standard, planned, actual, estimate and posted.
* **Stack:** Next.js / React / TypeScript · Python / FastAPI · PostgreSQL 16 · background worker ·
  WebSockets · protected document storage · Docker Compose. A modular monolith.
* **Integrations:** all external adapters (accounting, machines, scales, scanners, suppliers) are
  **simulated** in this release. See [docs/CAPABILITIES.md](docs/CAPABILITIES.md).

## Quick start (Docker Compose)

```bash
cp config/.env.example .env          # set AUREOM_SECRET_KEY and POSTGRES_PASSWORD
docker compose up -d --build         # db, api (:8000, migrates on start), worker, frontend (:3000)
docker compose --profile demo run --rm demo   # DESTRUCTIVE: resets the database, loads and runs the demonstrator
```

Open <http://localhost:3000> and sign in as one of the demo users below. API documentation is at
<http://localhost:8000/docs>.

Run the test-suite in containers (uses a separate `aureom_test` database):

```bash
docker compose --profile test run --rm tests
```

## Local development (without Docker)

Requirements: Python 3.13, PostgreSQL 16 (client tools on `PATH`), Node.js 22.

```bash
# database (role needs CREATEDB for the restore test)
createuser --createdb --pwprompt aureom          # password: aureom (development only)
createdb -O aureom aureom_factory && createdb -O aureom aureom_test

# backend
python3 -m venv .venv && .venv/bin/pip install -r backend/requirements-dev.txt
cd backend
export AUREOM_DATABASE_URL=postgresql+psycopg://aureom:aureom@localhost:5432/aureom_factory
../.venv/bin/alembic upgrade head
../.venv/bin/python -m app.demo.run --reset --out ../docs/DEMO_RESULTS.md   # optional: demonstrator data
../.venv/bin/uvicorn app.main:app --reload --port 8000
../.venv/bin/python -m app.workers.worker          # in another terminal

# front end (another terminal)
cd frontend && npm ci && AUREOM_API_URL=http://localhost:8000 npm run dev
```

Tests (PostgreSQL required; the suite rebuilds the test database's schema):

```bash
cd backend && AUREOM_TEST_DATABASE_URL=postgresql+psycopg://aureom:aureom@localhost:5432/aureom_test ../.venv/bin/python -m pytest -q
```

## Pennine Manufacturing Demonstrator

A fictional West Yorkshire manufacturer producing the **Pennine BL-100 bench-mounted inspection lamp**:
aluminium bar is cut and CNC-machined into housings, anodised by a subcontractor, assembled with a
bought-in LED module, cable and fasteners, electrically tested, packed and shipped. The scenario covers
the 14 required steps, including a rejected bar delivery, a partial and late LED delivery, a CNC
spindle outage, machining scrap with recoverable swarf, three test failures reworked under an NCR, a
mid-run engineering change that does not affect the released order, partial dispatch to two
customers, supplier-lot tracing, planned-versus-actual costs and a simulated recall.

`python -m app.demo.run --reset` writes the step-by-step log to `docs/DEMO_RESULTS.md`, including every
control that correctly **blocked** an invalid action. All organisations and people are fictional.

### Demo users (password `demo` — demonstration only)

| Username | Name | Role | Skills |
|---|---|---|---|
| `admin` | Aureom Administrator | admin | |
| `pshah` | Priya Shah | planner | |
| `gholroyd` | Gareth Holroyd | production_manager | assembly, cnc, saw |
| `mpickles` | Megan Pickles | buyer | |
| `isutcliffe` | Ian Sutcliffe | purchasing_manager | |
| `dackroyd` | Dave Ackroyd | storekeeper | |
| `apatel` | Asha Patel | operator | saw, cnc |
| `lfirth` | Liam Firth | operator | cnc, assembly |
| `sbarraclough` | Sophie Barraclough | operator | assembly, electrical_test, packing |
| `kmensah` | Kofi Mensah | quality_inspector | |
| `hbrierley` | Helen Brierley | quality_manager | |
| `rdesai` | Ravi Desai | engineer | |
| `jcrowther` | Joanne Crowther | engineering_approver | |
| `sgreenwood` | Stuart Greenwood | maintenance | |
| `nrahman` | Nadia Rahman | cost_accountant | |
| `clumb` | Craig Lumb | dispatcher | |
| `viewer` | Read-only Viewer | viewer | |
| `calder_op` | Calder Site Operator | operator + storekeeper at the second site only (shows site scoping) | assembly |

Roles are scoped to the Pennine Works site except `admin`. A `system` account is used by background jobs.

## Repository layout

```
backend/            FastAPI application (app/), Alembic migrations, tests, Dockerfile
  app/core/         sites, users, permissions, audit, jobs, context
  app/modules/      registry, engineering, inventory, purchasing, quality, production, genealogy,
                    planning, maintenance, costing, dispatch, documents
  app/adapters/     typed adapter protocols + simulated implementations
  app/workers/      background worker and job handlers
  app/realtime/     WebSocket hub
  app/demo/         Pennine Manufacturing Demonstrator fixtures and scenario
frontend/           Next.js web application and shop-floor screens
scripts/            backup.sh, restore.sh, export_openapi.py
config/.env.example configuration template
docs/               architecture, API, capabilities, security, operations, regulatory, demo results
docker-compose.yml
```

## Documentation

* [Architecture](docs/ARCHITECTURE.md) — modules, invariants, state machines
* [API reference](docs/API.md) and [OpenAPI document](docs/openapi.json)
* [Capability status](docs/CAPABILITIES.md) — implemented / simulated / integrated / deferred
* [Security](docs/SECURITY.md) — roles, permissions, segregation of duties, documents
* [Operations](docs/OPERATIONS.md) — workers, jobs, backups and tested restoration
* [Regulated manufacturing](docs/REGULATORY.md) — no regulated-sector readiness is claimed
* [Demonstration results](docs/DEMO_RESULTS.md)

## Build and test results

Results recorded in the build environment (details in [docs/TEST_RESULTS.md](docs/TEST_RESULTS.md)):

* **Backend tests: 64 passed, 0 failed** (pytest, real PostgreSQL 16) — unit conversions, BOM cycles, revision
  freezing, concurrent reservations, partial receipts, reversals, genealogy, quarantine, rework, costing,
  permissions/API, imports, offline entries, the full demonstration, and backup → restore.
* **Demonstration:** all 18 steps completed in ~11 s; 18 invalid actions correctly blocked; journal re-check 0 discrepancies.
* **Frontend:** TypeScript clean, `next build` succeeded; every page exercised in headless Chromium with no
  console errors or failed API calls; live WebSocket updates confirmed. Screenshots: `docs/screenshots/`.
* **Not verified here:** Docker images were not built or run (no Docker daemon available); `docker compose config` passes.
* **Status of capabilities** (implemented / simulated / integrated / deferred): [docs/CAPABILITIES.md](docs/CAPABILITIES.md).
  Nothing is integrated with a real external system; regulated-sector readiness is not claimed.
