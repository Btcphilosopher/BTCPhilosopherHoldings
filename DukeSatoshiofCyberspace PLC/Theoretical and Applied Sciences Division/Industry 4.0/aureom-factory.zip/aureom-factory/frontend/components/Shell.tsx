"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import React, { useEffect, useState } from "react";
import { api, clearSession, getUser, Me } from "@/lib/api";
import { useLive } from "@/lib/hooks";

export const NAV = [
  ["Overview", "/", "◧"], ["Materials", "/materials", "▤"], ["Purchasing", "/purchasing", "⇩"], ["Inventory", "/inventory", "▦"],
  ["Products", "/products", "⚙"], ["Planning", "/planning", "▥"], ["Production", "/production", "▶"], ["Quality", "/quality", "✓"],
  ["Maintenance", "/maintenance", "⚒"], ["Costing", "/costing", "£"], ["Dispatch", "/dispatch", "⇨"], ["Reports", "/reports", "⌕"],
] as const;

export default function Shell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const [user, setUser] = useState<Me | null>(null);
  const [site, setSite] = useState<string>("");
  const { connected, events } = useLive();
  useEffect(() => {
    const u = getUser();
    if (!u) { router.replace("/login"); return; }
    setUser(u);
    api<any[]>("/sites").then((s) => setSite(s[0]?.name || "")).catch(() => {});
  }, [router]);
  const current = NAV.find(([, href]) => (href === "/" ? path === "/" : path.startsWith(href)));
  if (!user) return null;
  return (
    <div className="shell">
      <a href="#main" className="skip">Skip to content</a>
      <nav className="nav" aria-label="Main">
        <div className="brand">
          <img src="/aureom-mark.svg" alt="" />
          <div><b>AUREOM</b><small>FACTORY · Materials to Finished Goods</small></div>
        </div>
        <ul>
          {NAV.map(([label, href, ico]) => (
            <li key={href}>
              <Link href={href} aria-current={current?.[1] === href ? "page" : undefined}>
                <span className="ico" aria-hidden>{ico}</span>{label}
              </Link>
            </li>
          ))}
          <li style={{ marginTop: 10 }}><Link href="/shopfloor"><span className="ico" aria-hidden>▣</span>Shop-floor terminal</Link></li>
        </ul>
        <div className="foot">
          <div>{user.full_name}</div>
          <div className="small">{user.roles.map((r) => r.role.replace(/_/g, " ")).join(", ")}</div>
          <button className="btn sm" onClick={() => { clearSession(); router.replace("/login"); }}>Sign out</button>
        </div>
      </nav>
      <div className="main">
        <div className="topbar">
          <div><div className="crumb">{site || "Pennine Works"}</div><b>{current?.[0] || ""}</b></div>
          <div className="row">
            {events[0] && <span className="small muted" title={JSON.stringify(events[0].data)}>Latest: {events[0].topic}</span>}
            <span className={"live" + (connected ? " on" : "")} role="status"><i aria-hidden />{connected ? "Live updates" : "Offline — refresh to update"}</span>
          </div>
        </div>
        <main id="main" className="content">{children}</main>
      </div>
    </div>
  );
}
