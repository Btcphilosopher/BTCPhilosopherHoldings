"use client";
import React, { useEffect, useRef, useState } from "react";
import { api } from "@/lib/api";

export type ScanRecord = { kind: string; value: string; note: string; record: any };

/**
 * Barcode entry. Keyboard-wedge scanners type into the focused field and send Enter, which always works.
 * Camera scanning uses the browser BarcodeDetector API where the browser supports it.
 * A scan IDENTIFIES a lot — it does not establish that the material meets its specification.
 */
export default function Scanner({ onResult, label = "Scan or type a code", autoFocus, big }: { onResult: (r: ScanRecord) => void; label?: string; autoFocus?: boolean; big?: boolean }) {
  const [raw, setRaw] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [camera, setCamera] = useState(false);
  const video = useRef<HTMLVideoElement>(null);
  const supported = typeof window !== "undefined" && "BarcodeDetector" in window;

  const submit = async (code: string) => {
    if (!code.trim()) return;
    setErr(null);
    try { onResult(await api<ScanRecord>("/scan", { body: { raw: code.trim() } })); setRaw(""); }
    catch (e: any) { setErr(e.message); }
  };

  useEffect(() => {
    if (!camera || !video.current) return;
    let stream: MediaStream | null = null;
    let stop = false;
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
        video.current!.srcObject = stream;
        await video.current!.play();
        // @ts-expect-error BarcodeDetector is not yet in lib.dom
        const det = new window.BarcodeDetector({ formats: ["code_128", "qr_code", "data_matrix"] });
        while (!stop) {
          const codes = await det.detect(video.current!);
          if (codes.length) { await submit(codes[0].rawValue); setCamera(false); break; }
          await new Promise((r) => setTimeout(r, 250));
        }
      } catch (e: any) { setErr("Camera unavailable: " + e.message); setCamera(false); }
    })();
    return () => { stop = true; stream?.getTracks().forEach((t) => t.stop()); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [camera]);

  return (
    <div>
      <form className="row" onSubmit={(e) => { e.preventDefault(); submit(raw); }}>
        <label className="f" style={{ flex: 1 }}>{label}
          <input value={raw} onChange={(e) => setRaw(e.target.value)} autoFocus={autoFocus} placeholder="e.g. LOT:PC-LED-M12|LOT-000006"
                 aria-describedby="scan-note" style={big ? { fontSize: 18 } : undefined} autoComplete="off" />
        </label>
        <button className={"btn" + (big ? " big" : "")} type="submit" style={{ alignSelf: "flex-end" }}>Identify</button>
        {supported && <button type="button" className={"btn" + (big ? " big" : "")} style={{ alignSelf: "flex-end" }} onClick={() => setCamera((c) => !c)}>{camera ? "Stop camera" : "Camera"}</button>}
      </form>
      {camera && <video ref={video} style={{ width: "100%", maxWidth: 420, marginTop: 8, borderRadius: 8 }} muted playsInline aria-label="Camera preview" />}
      <div id="scan-note" className="small muted" style={{ marginTop: 4 }}>Identification only — conformity comes from the lot’s recorded quality status.</div>
      {err && <div className="alert failure" style={{ marginTop: 6 }}><span className="tag">FAILURE</span>{err}</div>}
    </div>
  );
}
