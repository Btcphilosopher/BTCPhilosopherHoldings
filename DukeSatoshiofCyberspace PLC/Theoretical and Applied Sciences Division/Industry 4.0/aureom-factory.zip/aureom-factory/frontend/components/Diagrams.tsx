"use client";
import React from "react";
import { Table } from "./ui";

/* ---------------- Material flow (cyan) ---------------- */
type Flow = { nodes: string[]; edges: { from: string; to: string; movements: number; items: string[] }[] };

const COLS: Record<string, number> = {
  Suppliers: 0, "Goods-in": 1, Quarantine: 2, Stores: 2, "At subcontractor": 3, "Work in progress": 3, Production: 4,
  "Finished goods": 5, "Dispatch bay": 6, Customers: 7, "Returns review": 6, Scrap: 5, Adjustment: 0, Reversal: 0,
};

export function FlowDiagram({ flow }: { flow: Flow }) {
  const nodes = flow.nodes;
  const byCol: Record<number, string[]> = {};
  nodes.forEach((n) => { const c = COLS[n] ?? 4; (byCol[c] = byCol[c] || []).push(n); });
  const W = 1060, colW = W / 8, nodeW = 116, nodeH = 34;
  const maxRows = Math.max(...Object.values(byCol).map((v) => v.length), 1);
  const H = Math.max(180, maxRows * 62 + 30);
  const pos: Record<string, { x: number; y: number }> = {};
  Object.entries(byCol).forEach(([c, ns]) => ns.forEach((n, i) => {
    pos[n] = { x: Number(c) * colW + 8, y: 20 + i * 62 + (maxRows - ns.length) * 31 };
  }));
  const maxM = Math.max(...flow.edges.map((e) => e.movements), 1);
  return (
    <div className="flow" style={{ overflowX: "auto" }}>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Material flow between stages">
        <defs>
          <marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="9" markerHeight="9" markerUnits="userSpaceOnUse" orient="auto-start-reverse">
            <path d="M0,0 L10,5 L0,10 z" fill="#0e9cbf" />
          </marker>
        </defs>
        {flow.edges.map((e, i) => {
          const a = pos[e.from], b = pos[e.to];
          if (!a || !b) return null;
          const x1 = a.x + nodeW, y1 = a.y + nodeH / 2, x2 = b.x, y2 = b.y + nodeH / 2;
          const back = x2 <= x1;
          const d = back
            ? `M${a.x + nodeW / 2},${a.y + nodeH} C${a.x + nodeW / 2},${H - 4} ${b.x + nodeW / 2},${H - 4} ${b.x + nodeW / 2},${b.y + nodeH}`
            : `M${x1},${y1} C${x1 + 40},${y1} ${x2 - 40},${y2} ${x2},${y2}`;
          return (
            <g key={i}>
              <path d={d} fill="none" stroke="#0e9cbf" strokeOpacity={back ? 0.45 : 0.85} strokeDasharray={back ? "5 4" : undefined}
                    strokeWidth={1.5 + 5 * (e.movements / maxM)} markerEnd="url(#arr)">
                <title>{`${e.from} → ${e.to}: ${e.movements} movements (${e.items.join(", ")})`}</title>
              </path>
            </g>
          );
        })}
        {nodes.map((n) => (
          <g key={n} transform={`translate(${pos[n].x},${pos[n].y})`}>
            <rect width={nodeW} height={nodeH} rx={5} fill={n === "Production" ? "#fff1e8" : n === "Quarantine" || n === "Returns review" ? "#fff4d6" : n === "Scrap" ? "#fdeceb" : "#e3f6fb"}
                  stroke={n === "Production" ? "#e8641b" : "#0e9cbf"} />
            <text x={nodeW / 2} y={21} textAnchor="middle" fontSize="12" fill="#0f1b33" fontWeight={600}>{n}</text>
          </g>
        ))}
      </svg>
    </div>
  );
}

export function FlowTable({ flow }: { flow: Flow }) {
  return <Table caption="Material flow" rows={flow.edges.map((e, i) => ({ id: i, ...e, items: e.items.join(", ") }))}
                cols={[{ key: "from", label: "From" }, { key: "to", label: "To" }, { key: "movements", label: "Movements", num: true },
                       { key: "items", label: "Items" }]} />;
}

/* ---------------- Gantt timeline ---------------- */
type Bar = { order: string; op: number; name: string; resource: string; operator?: string; start: string; end: string; kind: string; segments?: [string, string][] };

export function Gantt({ bars, dueDates }: { bars: Bar[]; dueDates?: Record<string, string | null> }) {
  if (!bars.length) return <div className="empty">No scheduled operations</div>;
  const resources = Array.from(new Set(bars.map((b) => b.resource))).sort();
  const t0 = Math.min(...bars.map((b) => +new Date(b.start)));
  const t1 = Math.max(...bars.map((b) => +new Date(b.end)), ...Object.values(dueDates || {}).filter(Boolean).map((d) => +new Date(d as string) + 86400000));
  const left = 110, W = 1080, rowH = 30, H = resources.length * rowH + 40;
  const x = (t: number) => left + ((t - t0) / Math.max(t1 - t0, 1)) * (W - left - 10);
  const days: number[] = [];
  for (let d = new Date(t0); +d <= t1; d.setDate(d.getDate() + 1)) { const dd = new Date(d); dd.setHours(0, 0, 0, 0); days.push(+dd); }
  const orders = Array.from(new Set(bars.map((b) => b.order)));
  const palette = ["#e8641b", "#1d3260", "#0e9cbf", "#7a4bb3", "#1d7a46", "#b3261e"];
  const colour = (o: string) => palette[orders.indexOf(o) % palette.length];
  return (
    <div className="gantt">
      <div className="legend" style={{ marginBottom: 6 }}>{orders.map((o) => <span key={o} style={{ ["--c" as any]: colour(o) }}>{o}</span>)}<span style={{ ["--c" as any]: "#b3261e" }}>due date</span></div>
      <svg width={W} height={H} role="img" aria-label="Production schedule timeline by resource">
        {days.map((d) => (
          <g key={d}>
            <line x1={x(d)} x2={x(d)} y1={18} y2={H} stroke="#e8ecf2" />
            <text x={x(d) + 3} y={12} fontSize="10" fill="#6b7690">{new Date(d).toLocaleDateString("en-GB", { day: "2-digit", month: "short" })}</text>
          </g>
        ))}
        {resources.map((r, i) => (
          <g key={r}>
            <text x={4} y={20 + i * rowH + 19} fontSize="12" fill="#0f1b33" fontWeight={600}>{r}</text>
            <line x1={left} x2={W} y1={20 + (i + 1) * rowH} y2={20 + (i + 1) * rowH} stroke="#f0f2f6" />
          </g>
        ))}
        {bars.map((b, j) => {
          const i = resources.indexOf(b.resource);
          const segs = b.segments && b.segments.length ? b.segments : [[b.start, b.end] as [string, string]];
          return segs.map(([s, e], k) => (
            <rect key={`${j}-${k}`} x={x(+new Date(s))} y={20 + i * rowH + 6} width={Math.max(2, x(+new Date(e)) - x(+new Date(s)))} height={rowH - 12}
                  rx={3} fill={colour(b.order)} fillOpacity={b.kind === "subcontract" ? 0.45 : 0.9}>
              <title>{`${b.order} op ${b.op} ${b.name} on ${b.resource}${b.operator ? " (" + b.operator + ")" : ""}: ${new Date(b.start).toLocaleString("en-GB")} → ${new Date(b.end).toLocaleString("en-GB")}`}</title>
            </rect>
          ));
        })}
        {Object.entries(dueDates || {}).map(([o, d]) => d && (
          <g key={o}><line x1={x(+new Date(d) + 86400000 - 1)} x2={x(+new Date(d) + 86400000 - 1)} y1={18} y2={H} stroke="#b3261e" strokeDasharray="4 3" />
            <text x={x(+new Date(d) + 86400000) - 4} y={H - 4} fontSize="10" textAnchor="end" fill="#b3261e">{o} due</text></g>
        ))}
      </svg>
    </div>
  );
}

/* ---------------- Genealogy graph ---------------- */
type GNode = { lot_number: string; item_code: string; depth: number; precision: string };

export function GenealogyGraph({ root, nodes, direction }: { root: { lot_number: string; item_code: string }; nodes: GNode[]; direction: "back" | "forward" }) {
  const byDepth: Record<number, GNode[]> = {};
  nodes.forEach((n) => (byDepth[n.depth] = byDepth[n.depth] || []).push(n));
  const depths = Object.keys(byDepth).map(Number).sort((a, b) => a - b);
  const colW = 210, rowH = 34;
  const maxRows = Math.min(Math.max(...depths.map((d) => byDepth[d].length), 1), 18);
  const W = (depths.length + 1) * colW + 20, H = maxRows * rowH + 30;
  const colX = (d: number) => (direction === "back" ? (depths.length - d) * colW : d * colW) + 10;
  const box = (label: string, sub: string, x: number, y: number, prec?: string, key?: string) => (
    <g key={key || label} transform={`translate(${x},${y})`}>
      <rect width={190} height={26} rx={4} fill={prec === "order_level" ? "#fff4d6" : prec === "unknown" ? "#fdeceb" : "#e3f6fb"}
            stroke={prec === "order_level" ? "#f0b429" : prec === "unknown" ? "#b3261e" : "#0e9cbf"} strokeDasharray={prec === "order_level" ? "4 3" : undefined} />
      <text x={6} y={11} fontSize="9.5" fill="#44506a">{sub}</text>
      <text x={6} y={22} fontSize="11" fill="#0f1b33" fontWeight={600}>{label}</text>
    </g>
  );
  return (
    <div style={{ overflowX: "auto" }}>
      <div className="legend" style={{ marginBottom: 6 }}>
        <span style={{ ["--c" as any]: "#0e9cbf" }}>confirmed (direct record)</span>
        <span style={{ ["--c" as any]: "#f0b429" }}>possible (order-level association)</span>
        <span style={{ ["--c" as any]: "#b3261e" }}>unknown (incomplete history)</span>
      </div>
      <svg width={W} height={H} role="img" aria-label={`Genealogy ${direction === "back" ? "inputs of" : "uses of"} ${root.lot_number}`}>
        {box(root.lot_number, root.item_code, colX(0), H / 2 - 13, "exact", "root")}
        {depths.map((d) => byDepth[d].slice(0, 18).map((n, i) => (
          <g key={`${d}-${n.lot_number}`}>
            <line x1={direction === "back" ? colX(d) + 190 : colX(d - 1) + 190} y1={i * rowH + 28}
                  x2={direction === "back" ? colX(d - 1) : colX(d)} y2={H / 2} stroke="#0e9cbf" strokeOpacity={0.25} />
            {box(n.lot_number, n.item_code, colX(d), i * rowH + 15, n.precision)}
          </g>
        )))}
      </svg>
      {depths.some((d) => byDepth[d].length > 18) && <div className="small muted">Diagram truncated to 18 per level — see table for all.</div>}
    </div>
  );
}
