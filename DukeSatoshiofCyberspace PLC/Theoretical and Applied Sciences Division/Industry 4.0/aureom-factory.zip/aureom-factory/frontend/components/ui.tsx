"use client";
import React, { useMemo, useState } from "react";
import type { ApiError } from "@/lib/api";
import { title } from "@/lib/format";

export function Card({ title: t, actions, children, tight }: { title?: React.ReactNode; actions?: React.ReactNode; children: React.ReactNode; tight?: boolean }) {
  return (
    <section className={"card" + (tight ? " tight" : "")}>
      {(t || actions) && <div className="head">{t ? <h2>{t}</h2> : <span />}{actions && <div className="row">{actions}</div>}</div>}
      {children}
    </section>
  );
}

export function Kpi({ label, value, tone, hint }: { label: string; value: React.ReactNode; tone?: string; hint?: string }) {
  return <div className={"kpi " + (tone || "")} title={hint}><div className="v">{value}</div><div className="l">{label}</div></div>;
}

const STATUS_TONE: Record<string, string> = {
  accepted: "green", completed: "green", closed: "navy", received: "green", delivered: "green", matched: "green", available: "green",
  approved: "green", fulfilled: "green", applied: "green", authorised: "green", conforming: "green", exact: "cyan",
  awaiting_review: "amber", awaiting_inspection: "amber", quarantined: "amber", pending: "amber", paused: "amber", partially_received: "amber",
  restricted: "amber", variance: "amber", open: "orange", order_level: "amber", pending_authorisation: "amber", submitted: "amber",
  partially_shipped: "amber", investigating: "amber", proposed: "amber",
  rejected: "red", down: "red", cancelled: "navy", failed: "red", nonconforming: "red", unknown: "red",
  released: "orange", in_progress: "orange", planned: "navy", draft: "navy", sent: "navy", acknowledged: "navy", dispatched: "cyan",
  picking: "navy", packed: "navy", superseded: "navy", ready: "orange", handed_over: "green",
  scanned: "cyan", measured: "cyan", manual: "navy", calculated: "amber", system: "navy",
};

export function Chip({ v, label, tone }: { v?: string | null; label?: string; tone?: string }) {
  if (!v && !label) return <span className="muted">—</span>;
  const text = label ?? (v === "order_level" ? "possible" : v === "exact" ? "confirmed" : title(String(v)));
  return <span className={"chip " + (tone || STATUS_TONE[String(v)] || "")}>{text}</span>;
}

export function Alert({ kind, children }: { kind: "constraint" | "failure" | "info"; children: React.ReactNode }) {
  const tag = kind === "constraint" ? "CONSTRAINT" : kind === "failure" ? "FAILURE" : "NOTE";
  return <div className={"alert " + kind} role={kind === "failure" ? "alert" : "status"}><span className="tag">{tag}</span><div>{children}</div></div>;
}

export function ErrorBox({ error }: { error: ApiError | null }) {
  if (!error) return null;
  return <Alert kind="failure"><b>{error.code}</b>: {error.message}</Alert>;
}

export function Tabs({ tabs, value, onChange }: { tabs: string[]; value: string; onChange: (t: string) => void }) {
  return (
    <div className="tabs" role="tablist">
      {tabs.map((t) => (
        <button key={t} role="tab" aria-selected={value === t} onClick={() => onChange(t)}>{t}</button>
      ))}
    </div>
  );
}

export type Col<T> = { key: string; label: string; num?: boolean; render?: (row: T) => React.ReactNode; sort?: (row: T) => any; width?: number };

export function Table<T extends Record<string, any>>({ rows, cols, empty, onRow, selected, rowClass, caption, max }:
  { rows: T[] | null | undefined; cols: Col<T>[]; empty?: string; onRow?: (r: T) => void; selected?: (r: T) => boolean; rowClass?: (r: T) => string; caption?: string; max?: number }) {
  const [sort, setSort] = useState<{ key: string; dir: 1 | -1 } | null>(null);
  const sorted = useMemo(() => {
    const r = [...(rows || [])];
    if (sort) {
      const c = cols.find((x) => x.key === sort.key);
      const get = c?.sort || ((x: T) => x[sort.key]);
      r.sort((a, b) => {
        const va = get(a), vb = get(b);
        const na = Number(va), nb = Number(vb);
        const cmp = !isNaN(na) && !isNaN(nb) && va !== "" && vb !== "" ? na - nb : String(va ?? "").localeCompare(String(vb ?? ""));
        return cmp * sort.dir;
      });
    }
    return max ? r.slice(0, max) : r;
  }, [rows, sort, cols, max]);
  if (!rows) return <div className="empty">Loading…</div>;
  if (!rows.length) return <div className="empty">{empty || "Nothing to show"}</div>;
  return (
    <div className="tablewrap">
      <table className="t">
        {caption && <caption className="sr-only">{caption}</caption>}
        <thead><tr>{cols.map((c) => (
          <th key={c.key} className={c.num ? "n" : ""} style={c.width ? { width: c.width } : undefined}
              aria-sort={sort?.key === c.key ? (sort.dir === 1 ? "ascending" : "descending") : undefined}>
            <button onClick={() => setSort((s) => ({ key: c.key, dir: s?.key === c.key && s.dir === 1 ? -1 : 1 }))}>
              {c.label}{sort?.key === c.key ? (sort.dir === 1 ? " ▲" : " ▼") : ""}
            </button>
          </th>))}</tr></thead>
        <tbody>
          {sorted.map((r, i) => (
            <tr key={(r.id ?? r.lot_id ?? i) + "-" + i} onClick={onRow ? () => onRow(r) : undefined} style={onRow ? { cursor: "pointer" } : undefined}
                className={[(selected && selected(r)) ? "sel" : "", rowClass ? rowClass(r) : ""].join(" ")}
                tabIndex={onRow ? 0 : undefined} onKeyDown={onRow ? (e) => { if (e.key === "Enter") onRow(r); } : undefined}>
              {cols.map((c) => <td key={c.key} className={c.num ? "n" : ""}>{c.render ? c.render(r) : r[c.key] ?? "—"}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
      {max && rows.length > max && <div className="small muted" style={{ padding: 8 }}>Showing {max} of {rows.length}</div>}
    </div>
  );
}

export function Toast({ msg }: { msg: { kind: "ok" | "error"; text: string } | null }) {
  if (!msg) return null;
  return <div className={"toast " + msg.kind} role="status" aria-live="polite">{msg.text}</div>;
}

export function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="f">{label}{children}</label>;
}

export function PageHead({ title: t, sub, actions }: { title: string; sub?: string; actions?: React.ReactNode }) {
  return (
    <div className="spread" style={{ marginBottom: 16 }}>
      <div><h1>{t}</h1>{sub && <div className="muted small">{sub}</div>}</div>
      {actions && <div className="row">{actions}</div>}
    </div>
  );
}

/** A diagram with an always-available accessible table alternative. */
export function WithTable({ label, diagram, table }: { label: string; diagram: React.ReactNode; table: React.ReactNode }) {
  const [asTable, setAsTable] = useState(false);
  return (
    <div>
      <div className="row" style={{ justifyContent: "flex-end", marginBottom: 6 }}>
        <button className="btn sm" aria-pressed={asTable} onClick={() => setAsTable((v) => !v)}>
          {asTable ? "Show diagram" : "Show as table"}
        </button>
      </div>
      {asTable ? table : <figure style={{ margin: 0 }} aria-label={label}>{diagram}<figcaption className="sr-only">{label}. A table version is available.</figcaption></figure>}
    </div>
  );
}
