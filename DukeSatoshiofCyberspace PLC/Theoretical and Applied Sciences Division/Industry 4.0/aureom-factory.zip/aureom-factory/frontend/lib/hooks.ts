"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { api, ApiError, getToken, wsUrl } from "./api";

export function useApi<T = any>(path: string | null, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<ApiError | null>(null);
  const [loading, setLoading] = useState(false);
  const load = useCallback(async () => {
    if (!path) return;
    setLoading(true);
    try { setData(await api<T>(path)); setError(null); }
    catch (e) { setError(e as ApiError); }
    finally { setLoading(false); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, ...deps]);
  useEffect(() => { load(); }, [load]);
  return { data, error, loading, reload: load, setData };
}

export type LiveEvent = { topic: string; site_id?: number; data: any; at: string };

/** Subscribe to operational updates (pg_notify → WebSocket). Reconnects with back-off. */
export function useLive(onEvent?: (e: LiveEvent) => void) {
  const [connected, setConnected] = useState(false);
  const [events, setEvents] = useState<LiveEvent[]>([]);
  const cb = useRef(onEvent);
  cb.current = onEvent;
  useEffect(() => {
    let ws: WebSocket | null = null;
    let stop = false;
    let delay = 1000;
    let ping: ReturnType<typeof setInterval> | undefined;
    const connect = () => {
      const token = getToken();
      if (!token || stop) return;
      try { ws = new WebSocket(`${wsUrl()}?token=${encodeURIComponent(token)}`); } catch { return; }
      ws.onopen = () => { setConnected(true); delay = 1000; ping = setInterval(() => ws?.readyState === 1 && ws.send("ping"), 25000); };
      ws.onmessage = (m) => {
        try {
          const e = { ...JSON.parse(m.data), at: new Date().toISOString() } as LiveEvent;
          if (e.topic === "hello") return;
          setEvents((prev) => [e, ...prev].slice(0, 50));
          cb.current?.(e);
        } catch { /* ignore */ }
      };
      ws.onclose = () => { setConnected(false); if (ping) clearInterval(ping); if (!stop) setTimeout(connect, (delay = Math.min(delay * 2, 30000))); };
      ws.onerror = () => ws?.close();
    };
    connect();
    return () => { stop = true; if (ping) clearInterval(ping); ws?.close(); };
  }, []);
  return { connected, events };
}

export function useToast() {
  const [msg, setMsg] = useState<{ kind: "ok" | "error"; text: string } | null>(null);
  useEffect(() => { if (msg) { const t = setTimeout(() => setMsg(null), 6000); return () => clearTimeout(t); } }, [msg]);
  return {
    msg,
    ok: (text: string) => setMsg({ kind: "ok", text }),
    fail: (e: unknown) => setMsg({ kind: "error", text: (e as ApiError)?.message || String(e) }),
  };
}
