"use client";
/* Thin client for the AUREOM FACTORY API. The token lives in sessionStorage (per tab). */

export type ApiError = { status: number; code: string; message: string; details?: unknown };

const TOKEN = "aureom.token";
const USER = "aureom.user";

export function getToken(): string | null {
  try { return sessionStorage.getItem(TOKEN); } catch { return null; }
}
export function getUser(): Me | null {
  try { const u = sessionStorage.getItem(USER); return u ? JSON.parse(u) : null; } catch { return null; }
}
export function setSession(token: string, user: Me) {
  sessionStorage.setItem(TOKEN, token);
  sessionStorage.setItem(USER, JSON.stringify(user));
}
export function clearSession() {
  try { sessionStorage.removeItem(TOKEN); sessionStorage.removeItem(USER); } catch { /* ignore */ }
}

export type Me = {
  id: number; username: string; full_name: string; skills: string[];
  roles: { role: string; site_id: number | null }[]; permissions: string[];
};

export function can(user: Me | null, perm: string): boolean {
  if (!user) return false;
  const p = user.permissions;
  return p.includes("*") || p.includes(perm) || p.includes(perm.split(".")[0] + ".*");
}

export async function api<T = any>(path: string, opts: { method?: string; body?: unknown; idempotencyKey?: string; raw?: boolean } = {}): Promise<T> {
  const headers: Record<string, string> = { Accept: "application/json" };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (opts.body !== undefined && !(opts.body instanceof FormData)) headers["Content-Type"] = "application/json";
  if (opts.idempotencyKey) headers["Idempotency-Key"] = opts.idempotencyKey;
  const res = await fetch(`/api${path}`, {
    method: opts.method || (opts.body !== undefined ? "POST" : "GET"),
    headers,
    body: opts.body === undefined ? undefined : opts.body instanceof FormData ? opts.body : JSON.stringify(opts.body),
    cache: "no-store",
  });
  if (res.status === 401 && typeof window !== "undefined" && !path.startsWith("/auth/login")) {
    clearSession();
    window.location.href = "/login";
  }
  if (!res.ok) {
    let payload: any = {};
    try { payload = await res.json(); } catch { /* not json */ }
    const e = payload.error || {};
    throw { status: res.status, code: e.code || "http_" + res.status, message: e.message || res.statusText, details: e.details } as ApiError;
  }
  if (opts.raw) return (await res.text()) as unknown as T;
  return res.json();
}

/** Open an authenticated HTML report in a new tab (reports need the bearer token, so fetch then blob). */
export async function openReport(path: string) {
  const html = await api<string>(path, { raw: true });
  const url = URL.createObjectURL(new Blob([html], { type: "text/html" }));
  window.open(url, "_blank", "noopener");
}

export function newKey(prefix = "ui"): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export function wsUrl(): string {
  const env = process.env.NEXT_PUBLIC_WS_URL;
  if (env) return env;
  if (typeof window === "undefined") return "";
  const proto = window.location.protocol === "https:" ? "wss" : "ws";
  return `${proto}://${window.location.hostname}:8000/ws`;
}
