import "./globals.css";
import type { Metadata, Viewport } from "next";

export const metadata: Metadata = {
  title: "AUREOM FACTORY",
  description: "Materials to finished goods — purchasing, inventory, production, quality, costing and traceability.",
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#0b1730" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-GB">
      <body>{children}</body>
    </html>
  );
}
