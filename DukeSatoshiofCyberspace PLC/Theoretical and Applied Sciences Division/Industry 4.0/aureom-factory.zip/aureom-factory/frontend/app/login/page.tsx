"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { api, setSession } from "@/lib/api";

const DEMO = [
  ["pshah", "Planner"], ["gholroyd", "Production manager"], ["isutcliffe", "Purchasing manager"], ["mpickles", "Buyer"],
  ["dackroyd", "Storekeeper"], ["sbarraclough", "Operator (assembly/test/pack)"], ["apatel", "Operator (saw/CNC)"],
  ["kmensah", "Quality inspector"], ["hbrierley", "Quality manager"], ["rdesai", "Engineer"], ["jcrowther", "Engineering approver"],
  ["sgreenwood", "Maintenance"], ["nrahman", "Cost accountant"], ["clumb", "Dispatcher"], ["viewer", "Read-only"], ["admin", "Administrator"],
];

export default function Login() {
  const router = useRouter();
  const [username, setU] = useState("pshah");
  const [password, setP] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true); setErr(null);
    try {
      const r = await api<{ token: string; user: any }>("/auth/login", { body: { username, password } });
      setSession(r.token, r.user);
      const op = r.user.roles.some((x: any) => x.role === "operator");
      router.replace(op ? "/shopfloor" : "/");
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };
  return (
    <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", background: "var(--navy-950)" }}>
      <main className="card" style={{ width: 420, maxWidth: "92vw" }}>
        <div className="row" style={{ marginBottom: 16 }}>
          <img src="/aureom-mark.svg" alt="" width={40} height={40} />
          <div><h1 style={{ letterSpacing: ".18em" }}>AUREOM FACTORY</h1><div className="muted small">Materials to Finished Goods</div></div>
        </div>
        <form onSubmit={submit} className="grid">
          <label className="f">User
            <select value={username} onChange={(e) => setU(e.target.value)}>
              {DEMO.map(([u, r]) => <option key={u} value={u}>{u} — {r}</option>)}
            </select>
          </label>
          <label className="f">Password<input type="password" value={password} onChange={(e) => setP(e.target.value)} autoComplete="current-password" required /></label>
          {err && <div className="alert failure"><span className="tag">FAILURE</span>{err}</div>}
          <button className="btn primary" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button>
          <p className="small muted" style={{ margin: 0 }}>Pennine Manufacturing Demonstrator — all demo accounts use the password <code>demo</code>. Synthetic data only.</p>
        </form>
      </main>
    </div>
  );
}
