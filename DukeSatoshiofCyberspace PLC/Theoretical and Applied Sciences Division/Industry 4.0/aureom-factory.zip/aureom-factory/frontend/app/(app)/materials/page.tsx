"use client";
import { useState } from "react";
import { Card, Chip, Table, PageHead, ErrorBox, Alert } from "@/components/ui";
import { useApi } from "@/lib/hooks";
import { num, title } from "@/lib/format";

const TYPES = ["", "raw_material", "purchased_component", "consumable", "wip", "subassembly", "finished_product", "packaging", "recoverable_scrap"];

export default function Materials() {
  const [type, setType] = useState("");
  const [q, setQ] = useState("");
  const [sel, setSel] = useState<number | null>(null);
  const items = useApi<any[]>(`/items?${type ? "item_type=" + type + "&" : ""}${q ? "q=" + encodeURIComponent(q) : ""}`, [type, q]);
  const item = useApi<any>(sel ? `/items/${sel}` : null, [sel]);
  const stock = useApi<any[]>(sel ? `/stock?item_id=${sel}` : null, [sel]);
  const units = useApi<any[]>("/units");
  return (
    <>
      <PageHead title="Materials" sub="Common item registry: raw materials, components, consumables, WIP, subassemblies, finished goods, packaging and recoverable scrap." />
      <ErrorBox error={items.error} />
      <div className="grid g2" style={{ gridTemplateColumns: "minmax(0,1.4fr) minmax(0,1fr)" }}>
        <Card title="Item registry" actions={<>
          <select aria-label="Filter by type" value={type} onChange={(e) => setType(e.target.value)}>{TYPES.map((t) => <option key={t} value={t}>{t ? title(t) : "All types"}</option>)}</select>
          <input aria-label="Search items" placeholder="Search code or description" value={q} onChange={(e) => setQ(e.target.value)} />
        </>}>
          <Table rows={items.data} onRow={(r) => setSel(r.id)} selected={(r) => r.id === sel} cols={[
            { key: "item_code", label: "Code", render: (r) => <b className="mono">{r.item_code}</b> },
            { key: "revision", label: "Rev" },
            { key: "description", label: "Description" },
            { key: "item_type", label: "Type", render: (r) => title(r.item_type) },
            { key: "base_unit", label: "Unit" },
            { key: "lot_or_serial_policy", label: "Tracking" },
            { key: "unknown_specifications", label: "Unknown specs", render: (r) => r.unknown_specifications.length ? <Chip tone="amber" label={`${r.unknown_specifications.length} unknown`} /> : <span className="muted">none</span> },
            { key: "active_status", label: "Status", render: (r) => <Chip v={r.active_status === "active" ? "accepted" : r.active_status} label={r.active_status} /> },
          ]} />
        </Card>
        <div>
          {!item.data && <Card title="Item detail"><div className="muted">Select an item to see its specification, unit conversions, suppliers and stock.</div></Card>}
          {item.data && <>
            <Card title={`${item.data.item_code} rev ${item.data.revision}`}>
              <p style={{ marginTop: 0 }}>{item.data.description}</p>
              <dl className="kv">
                <dt>Type</dt><dd>{title(item.data.item_type)}</dd>
                <dt>Base unit</dt><dd>{item.data.base_unit}</dd>
                <dt>Lot / serial</dt><dd>{item.data.lot_or_serial_policy}</dd>
                <dt>Shelf life</dt><dd>{item.data.shelf_life_applicable ? `${item.data.shelf_life_days} days` : "not applicable"}</dd>
                <dt>Storage</dt><dd>{item.data.storage_requirements || <span className="muted">not specified</span>}</dd>
                <dt>Make / buy</dt><dd>{item.data.make_or_buy} · lead time {item.data.lead_time_days} d</dd>
                <dt>Standard cost</dt><dd>{item.data.standard_cost ? `${item.data.standard_cost} ${item.data.standard_cost_currency}` : "—"}</dd>
                <dt>Record version</dt><dd>{item.data.version}</dd>
              </dl>
              <h3 style={{ marginTop: 14 }}>Specification</h3>
              <Table rows={item.data.specifications.map((s: any, i: number) => ({ id: i, ...s }))} empty="No specification lines" cols={[
                { key: "name", label: "Characteristic" },
                { key: "value", label: "Value", render: (s) => s.status === "specified" ? `${s.value}${s.unit ? " " + s.unit : ""}${s.tolerance ? " (" + s.tolerance + ")" : ""}` : <Chip v={s.status} label={s.status === "unknown" ? "UNKNOWN" : "n/a"} tone={s.status === "unknown" ? "amber" : ""} /> },
                { key: "source", label: "Source", render: (s) => s.source || "—" },
              ]} />
              <Alert kind="info">{item.data.certification_note} Recorded certifications: {item.data.certifications.length ? item.data.certifications.map((c: any) => c.name).join(", ") : "none"}.</Alert>
            </Card>
            <Card title="Approved unit conversions">
              <Table rows={item.data.conversions} empty="No item-specific conversions — only same-dimension conversions (e.g. g↔kg) apply." cols={[
                { key: "from_unit", label: "1 ×" }, { key: "factor", label: "=", num: true, render: (c) => num(c.factor, 6) }, { key: "to_unit", label: "Unit" },
                { key: "status", label: "Status", render: (c) => <Chip v={c.status} /> }, { key: "basis", label: "Basis" },
              ]} />
            </Card>
            <Card title="Supplier references">
              <Table rows={item.data.supplier_refs} empty="Not purchased" cols={[
                { key: "supplier_part_number", label: "Supplier part" }, { key: "purchase_unit", label: "Unit" },
                { key: "price", label: "Price", num: true, render: (r) => `${num(r.price, 4)} ${r.currency}` },
                { key: "lead_time_days", label: "Lead (d)", num: true }, { key: "preferred", label: "Preferred", render: (r) => r.preferred ? "yes" : "" },
              ]} />
            </Card>
            <Card title="Stock">
              <Table rows={stock.data} empty="No stock" cols={[
                { key: "physical", label: "Physical", num: true, render: (r) => num(r.physical) },
                { key: "available", label: "Available", num: true, render: (r) => num(r.available) },
                { key: "reserved", label: "Reserved", num: true, render: (r) => num(r.reserved) },
                { key: "wip", label: "WIP", num: true, render: (r) => num(r.wip) },
                { key: "at_subcontractor", label: "At subcontractor", num: true, render: (r) => num(r.at_subcontractor) },
              ]} />
            </Card>
          </>}
          <Card title="Units of measure">
            <Table rows={units.data} cols={[{ key: "code", label: "Code" }, { key: "name", label: "Name" }, { key: "dimension", label: "Dimension" },
              { key: "factor_to_reference", label: "Factor", num: true, render: (u) => u.factor_to_reference ? num(u.factor_to_reference, 6) : <span className="muted">item-specific</span> }]} />
            <p className="small muted">Kilograms, metres, litres, pieces and packs are never interchanged without an approved item-specific conversion.</p>
          </Card>
        </div>
      </div>
    </>
  );
}
