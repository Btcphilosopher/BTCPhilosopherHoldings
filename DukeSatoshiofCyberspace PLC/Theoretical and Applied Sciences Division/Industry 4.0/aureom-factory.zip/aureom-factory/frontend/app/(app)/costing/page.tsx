"use client";
import { useState } from "react";
import { Card, Chip, Table, PageHead, Alert, Toast } from "@/components/ui";
import { useApi, useToast } from "@/lib/hooks";
import { api, can, getUser } from "@/lib/api";
import { gbp } from "@/lib/format";

const EL = ["materials", "packaging", "labour", "machine", "subcontract", "scrap_material", "overhead", "total"];

export default function Costing() {
  const all = useApi<any[]>("/costing/orders");
  const items = useApi<any[]>("/items?item_type=finished_product");
  const [sel, setSel] = useState<number | null>(null);
  const [itemId, setItemId] = useState<number | null>(null);
  const [lab, setLab] = useState(false);
  const [batch, setBatch] = useState(true);
  const fg = itemId || items.data?.[0]?.id;
  const inc = useApi<any>(fg ? `/costing/incremental/${fg}?labour_variable=${lab}&added_to_existing_batch=${batch}` : null, [fg, lab, batch]);
  const detail = useApi<any>(sel ? `/costing/orders/${sel}` : null, [sel]);
  const toast = useToast();
  const user = getUser();
  const exportIt = async (id: number) => { try { const r = await api(`/costing/orders/${id}/export`, { body: {} }); toast.ok(`${r.batch_ref}: ${r.status}`); all.reload(); } catch (e) { toast.fail(e); } };
  return (
    <>
      <PageHead title="Costing" sub="Standard, planned, recorded actual, estimate at completion and financially posted cost are kept separate. All amounts GBP." />
      <Card title="Orders: planned vs actual">
        <Table rows={(all.data || []).map((c, i) => ({ id: i, ...c }))} onRow={(r) => setSel(Number(r.order_id ?? 0) || null)} cols={[
          { key: "order", label: "Order", render: (c) => <a href="#" onClick={(e) => { e.preventDefault(); setSel(null); api<any[]>("/orders").then((os) => setSel(os.find((o) => o.number === c.order)?.id)); }}>{c.order}</a> },
          { key: "item_code", label: "Item" }, { key: "status", label: "Status", render: (c) => <Chip v={c.status} /> },
          { key: "std", label: "Standard", num: true, render: (c) => c.standard.total_for_target ? gbp(c.standard.total_for_target) : <span className="muted">n/a</span> },
          { key: "planned", label: "Planned", num: true, render: (c) => gbp(c.planned.total) },
          { key: "actual", label: "Actual", num: true, render: (c) => <b>{gbp(c.actual.total)}</b> },
          { key: "eac", label: "Est. at completion", num: true, render: (c) => gbp(c.estimate_at_completion.total) },
          { key: "posted", label: "Posted", num: true, render: (c) => gbp(c.posted.total) },
          { key: "var", label: "Actual − planned", num: true, render: (c) => <span style={{ color: Number(c.variance_actual_vs_planned) > 0 ? "var(--red)" : "var(--green)" }}>{gbp(c.variance_actual_vs_planned)}</span> },
          { key: "unit", label: "Actual / accepted unit", num: true, render: (c) => gbp(c.actual_unit_cost_per_accepted) },
          { key: "x", label: "", render: (c) => c.status === "closed" && Number(c.posted.total) === 0 && can(user, "costing.export") ? <button className="btn sm" onClick={async (e) => { e.stopPropagation(); const os = await api<any[]>("/orders"); exportIt(os.find((o) => o.number === c.order).id); }}>Export</button> : null },
        ]} />
        <p className="small muted">Export sends journal lines to the accounting adapter (simulated CSV). Aureom does not replace a general ledger.</p>
      </Card>
      {detail.data && <Card title={`${detail.data.order} — cost elements`}>
        <Table rows={EL.map((k) => ({ id: k, k, std: detail.data.standard.elements?.[k], p: detail.data.planned[k], a: detail.data.actual[k], e: detail.data.estimate_at_completion[k], po: detail.data.posted[k] }))} cols={[
          { key: "k", label: "Element", render: (r) => <b>{r.k.replace(/_/g, " ")}</b> },
          { key: "std", label: "Standard (per unit)", num: true, render: (r) => r.std != null ? gbp(r.std) : "—" },
          { key: "p", label: "Planned", num: true, render: (r) => gbp(r.p) }, { key: "a", label: "Actual", num: true, render: (r) => gbp(r.a) },
          { key: "e", label: "EAC", num: true, render: (r) => gbp(r.e) }, { key: "po", label: "Posted", num: true, render: (r) => gbp(r.po) }]} />
        <h3 style={{ marginTop: 12 }}>Actual cost sources</h3>
        <ul className="small">{detail.data.actual_detail.detail.map((x: any, i: number) => <li key={i}>{JSON.stringify(x)}</li>)}</ul>
        {detail.data.actual_detail.scrap.length > 0 && <><h3>Scrap</h3><ul className="small">{detail.data.actual_detail.scrap.map((s: any) => <li key={s.number}>{s.number}: {s.quantity} {s.unit} {s.kind} — £{s.value} ({s.note})</li>)}</ul></>}
        <p className="small muted">Calculated (backflushed) consumption value included: {gbp(detail.data.actual_detail.calculated_backflush_value)}</p>
      </Card>}
      <Card title="Incremental cost — one more unit" actions={<>
        <select aria-label="Item" value={fg || ""} onChange={(e) => setItemId(Number(e.target.value))}>{items.data?.map((i) => <option key={i.id} value={i.id}>{i.item_code}</option>)}</select>
        <label className="row small"><input type="checkbox" checked={lab} onChange={(e) => setLab(e.target.checked)} /> labour varies</label>
        <label className="row small"><input type="checkbox" checked={batch} onChange={(e) => setBatch(e.target.checked)} /> added to an existing batch</label></>}>
        {inc.data && <>
          <div className="grid g2" style={{ marginBottom: 12 }}>
            <div className="kpi orange"><div className="v">{gbp(inc.data.incremental_cost_one_more_unit)}</div><div className="l">Incremental cost (changes with one more unit)</div></div>
            <div className="kpi"><div className="v">{gbp(inc.data.fully_allocated_standard_unit_cost)}</div><div className="l">Fully allocated standard unit cost</div></div>
          </div>
          <Alert kind="constraint">{inc.data.warning}</Alert>
          <h3>Assumptions</h3><ul className="small">{inc.data.assumptions.map((a: string) => <li key={a}>{a}</li>)}</ul>
          <Table rows={inc.data.lines.map((l: any, i: number) => ({ id: i, ...l }))} cols={[{ key: "element", label: "Element" }, { key: "item_code", label: "Item" }, { key: "operation", label: "Op" },
            { key: "amount", label: "GBP", num: true, render: (l) => gbp(l.amount) }, { key: "changes", label: "Changes?", render: (l) => l.changes ? <Chip v="accepted" label="yes" /> : <Chip label="no — fixed" /> }, { key: "basis", label: "Basis" }]} />
        </>}
      </Card>
      <Toast msg={toast.msg} />
    </>
  );
}
