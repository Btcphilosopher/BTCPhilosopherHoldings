"use client";
import { useState } from "react";
import { Card, Chip, Table, PageHead, Tabs, Toast, Alert } from "@/components/ui";
import { useApi, useToast } from "@/lib/hooks";
import { api, can, getUser } from "@/lib/api";
import { dt, num } from "@/lib/format";

export default function Quality() {
  const [tab, setTab] = useState("Inspections");
  const [sel, setSel] = useState<number | null>(null);
  const insps = useApi<any[]>("/inspections");
  const insp = useApi<any>(sel ? `/inspections/${sel}` : null, [sel]);
  const queue = useApi<any[]>(tab === "Release queue" ? "/quality/release-queue" : null, [tab]);
  const ncrs = useApi<any[]>(tab === "Nonconformance" ? "/ncrs" : null, [tab]);
  const capa = useApi<any[]>(tab === "Corrective actions" ? "/corrective-actions" : null, [tab]);
  const toast = useToast();
  const user = getUser();
  const decide = async (decision: string) => {
    const note = prompt(`Reason / note for decision "${decision}"`);
    if (!note) return;
    try { await api(`/inspections/${sel}/decide`, { body: { decision, note } }); toast.ok(`Decision recorded: ${decision}`); insp.reload(); insps.reload(); } catch (e) { toast.fail(e); }
  };
  const dispose = async (n: any) => {
    const d = prompt("Disposition: use_as_is, rework, scrap or return_to_supplier");
    if (!d) return;
    const note = prompt("Justification");
    if (!note) return;
    try { await api(`/ncrs/${n.id}/disposition`, { body: { disposition: d, note } }); toast.ok("Dispositioned"); ncrs.reload(); } catch (e) { toast.fail(e); }
  };
  const e = insp.data?.evaluation;
  return (
    <>
      <PageHead title="Quality" sub="Accepted · Quarantined · Rejected · Awaiting review. Inspectors record; only authorised quality staff release or disposition." />
      <Tabs tabs={["Inspections", "Release queue", "Nonconformance", "Corrective actions"]} value={tab} onChange={setTab} />
      {tab === "Inspections" && <div className="grid g2" style={{ gridTemplateColumns: "minmax(0,1fr) minmax(0,1.4fr)" }}>
        <Card title="Inspections">
          <Table rows={insps.data} onRow={(r) => setSel(r.id)} selected={(r) => r.id === sel} cols={[
            { key: "number", label: "No." }, { key: "stage", label: "Stage" }, { key: "item_code", label: "Item" },
            { key: "lots", label: "Lots", render: (r) => <span className="small">{r.lots.join(", ")}{r.lot_count > 5 ? ` +${r.lot_count - 5}` : ""}</span> },
            { key: "sample_size", label: "n", num: true }, { key: "status", label: "Status", render: (r) => <Chip v={r.status === "decided" ? r.decision : r.status} /> },
          ]} />
        </Card>
        <Card title={insp.data ? `${insp.data.number} · ${insp.data.item_code} (${insp.data.stage})` : "Inspection"} actions={insp.data && insp.data.status !== "decided" && <>
          {can(user, "quality.release") && <button className="btn primary" disabled={!e?.conforming} onClick={() => decide("accepted")}>Release</button>}
          {can(user, "quality.record") && <button className="btn" onClick={() => decide("quarantined")}>Hold</button>}
          {can(user, "quality.disposition") && <button className="btn danger" onClick={() => decide("rejected")}>Reject</button>}
        </>}>
          {!insp.data && <div className="muted">Select an inspection.</div>}
          {insp.data && e && <>
            <dl className="kv">
              <dt>Lot quantity</dt><dd>{num(insp.data.lot_quantity)} · sample {e.sample_size} · accept ≤ {e.accept_number} nonconforming</dd>
              <dt>Evaluation</dt><dd>{e.conforming ? <Chip v="conforming" /> : <Chip v="nonconforming" label={e.complete ? "nonconforming" : "incomplete"} />} {e.defects} nonconforming result(s)</dd>
              {insp.data.status === "decided" && <><dt>Decision</dt><dd><Chip v={insp.data.decision} /> {insp.data.decision_note}</dd></>}
            </dl>
            {e.issues.map((i: string, k: number) => <Alert key={k} kind={i.includes("calibration") || i.includes("certificate") ? "failure" : "constraint"}>{i}</Alert>)}
            <Alert kind="info">{e.certification_note}</Alert>
            <Table rows={insp.data.results} rowClass={(r) => (r.superseded ? "struck" : "")} max={150} cols={[
              { key: "characteristic", label: "Characteristic" }, { key: "sample_ref", label: "Sample" },
              { key: "value", label: "Value", render: (r) => r.numeric_value != null ? `${num(r.numeric_value, 4)} ${r.unit || ""}` : r.text_value || (r.conforms ? "OK" : "NOT OK") },
              { key: "conforms", label: "", render: (r) => r.conforms ? <Chip v="conforming" label="OK" /> : <Chip v="nonconforming" label="NC" /> },
              { key: "value_source", label: "Source", render: (r) => <Chip v={r.value_source} /> },
              { key: "calibration_valid", label: "Gauge", render: (r) => r.equipment_id ? (r.calibration_valid ? <span className="small">{r.calibration_ref}</span> : <Chip tone="red" label="out of calibration" />) : "—" },
              { key: "observed_at", label: "Observed", render: (r) => dt(r.observed_at) },
              { key: "recorded_at", label: "Recorded", render: (r) => dt(r.recorded_at) },
              { key: "correction_reason", label: "Correction", render: (r) => r.supersedes_result_id ? <span className="small">corrects #{r.supersedes_result_id}: {r.correction_reason}</span> : r.superseded ? <span className="small">superseded (kept)</span> : "" },
            ]} />
          </>}
        </Card>
      </div>}
      {tab === "Release queue" && <Card title="Physically present, not released">
        <Table rows={queue.data} cols={[{ key: "lot_number", label: "Lot" }, { key: "item_code", label: "Item" }, { key: "quality_status", label: "Status", render: (l) => <Chip v={l.quality_status} /> },
          { key: "origin", label: "Origin" }, { key: "locations", label: "Where", render: (l) => l.locations.map((x: any) => `${x.bin} ${num(x.quantity)}`).join("; ") }]} />
      </Card>}
      {tab === "Nonconformance" && <Card title="Nonconformance reports">
        <Table rows={ncrs.data} cols={[{ key: "number", label: "NCR" }, { key: "source", label: "Source" }, { key: "severity", label: "Severity", render: (n) => <Chip tone={n.severity === "critical" ? "red" : "amber"} label={n.severity} /> },
          { key: "item_code", label: "Item" }, { key: "lots", label: "Lots", render: (n) => <span className="small">{n.lots.join(", ")}</span> },
          { key: "quantity", label: "Qty", num: true, render: (n) => num(n.quantity) }, { key: "description", label: "Description" },
          { key: "status", label: "Status", render: (n) => <Chip v={n.status} /> }, { key: "disposition", label: "Disposition", render: (n) => n.disposition ? <span><b>{n.disposition}</b> <span className="small">{n.disposition_note}</span></span> : "—" },
          { key: "a", label: "", render: (n) => n.status === "open" && can(user, "quality.disposition") ? <button className="btn sm" onClick={() => dispose(n)}>Disposition</button> : null }]} />
      </Card>}
      {tab === "Corrective actions" && <Card title="Corrective actions">
        <Table rows={capa.data} cols={[{ key: "number", label: "CA" }, { key: "problem", label: "Problem" }, { key: "root_cause", label: "Root cause" }, { key: "action", label: "Action" },
          { key: "due_date", label: "Due" }, { key: "status", label: "Status", render: (c) => <Chip v={c.status} /> }]} />
      </Card>}
      <Toast msg={toast.msg} />
    </>
  );
}
