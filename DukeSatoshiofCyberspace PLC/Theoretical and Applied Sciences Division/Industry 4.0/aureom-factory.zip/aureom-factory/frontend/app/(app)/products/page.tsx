"use client";
import { useState } from "react";
import { Card, Chip, Table, PageHead, Alert, ErrorBox } from "@/components/ui";
import { useApi } from "@/lib/hooks";
import { day, gbp, num } from "@/lib/format";

export default function Products() {
  const made = useApi<any[]>("/items");
  const list = (made.data || []).filter((i) => ["wip", "subassembly", "finished_product"].includes(i.item_type));
  const [sel, setSel] = useState<number | null>(null);
  const [qty, setQty] = useState("100");
  const boms = useApi<any[]>(sel ? `/items/${sel}/boms` : null, [sel]);
  const routings = useApi<any[]>(sel ? `/items/${sel}/routings` : null, [sel]);
  const explosion = useApi<any>(sel ? `/items/${sel}/explosion?quantity=${qty || 1}` : null, [sel, qty]);
  const std = useApi<any>(sel ? `/costing/standard/${sel}` : null, [sel]);
  const cycles = useApi<any>("/engineering/cycle-check");
  return (
    <>
      <PageHead title="Products" sub="Versioned bills of materials and routings. Released production orders keep the revision they were planned with." />
      {cycles.data && (cycles.data.cycles.length ? <Alert kind="failure">Circular BOMs detected: {cycles.data.cycles.map((c: string[]) => c.join(" → ")).join("; ")}</Alert>
        : <Alert kind="info">Cycle check: no circular bills of materials among draft and approved revisions.</Alert>)}
      <div className="grid g2" style={{ gridTemplateColumns: "minmax(0,.7fr) minmax(0,2fr)" }}>
        <Card title="Made items">
          <Table rows={list} onRow={(r) => setSel(r.id)} selected={(r) => r.id === sel} cols={[
            { key: "item_code", label: "Code", render: (r) => <b className="mono">{r.item_code}</b> }, { key: "description", label: "Description" },
          ]} />
        </Card>
        <div>
          {!sel && <Card title="Definition"><div className="muted">Select an item.</div></Card>}
          {boms.data?.slice().reverse().map((b) => (
            <Card key={b.id} title={`BOM ${b.item_code} v${b.version}`} actions={<><Chip v={b.status} /><span className="small muted">effective {day(b.effective_from)}{b.effective_to ? ` → ${day(b.effective_to)}` : ""} · yield {num(b.expected_yield_pct)} %</span></>}>
              {b.change_note && <p className="small" style={{ marginTop: 0 }}>{b.change_note}</p>}
              <Table rows={b.lines} cols={[
                { key: "line_no", label: "Line" }, { key: "component_item_code", label: "Component", render: (l) => <span className="mono">{l.component_item_code}</span> },
                { key: "quantity", label: "Qty", num: true, render: (l) => `${num(l.quantity, 4)} ${l.unit}` },
                { key: "loss", label: "Loss handling", render: (l) => l.scrap_basis === "allowance_in_quantity" ? <span><Chip tone="cyan" label="allowance in qty" /> <span className="small">{l.allowance_note}</span></span> : `${num(l.loss_pct)} % expected loss` },
                { key: "gross_per_parent_base", label: "Gross per started", num: true, render: (l) => l.conversion_error ? <Chip tone="red" label="no conversion" /> : `${num(l.gross_per_parent_base, 4)} ${l.base_unit}` },
                { key: "alt", label: "Alternative", render: (l) => l.alternative_group ? `${l.alternative_group} #${l.alternative_priority}${l.alternative_approved ? " (approved)" : ""}` : "" },
                { key: "flags", label: "", render: (l) => <>{l.is_packaging && <Chip label="packaging" />} {l.backflush && <Chip tone="amber" label="backflush" />}</> },
                { key: "operation_seq", label: "Op" },
              ]} />
            </Card>
          ))}
          {routings.data?.map((r) => (
            <Card key={r.id} title={`Routing v${r.version} (${r.kind})`} actions={<Chip v={r.status} />}>
              <Table rows={r.operations} cols={[
                { key: "seq", label: "Op" }, { key: "name", label: "Operation" }, { key: "work_centre", label: "Work centre" },
                { key: "required_equipment_kind", label: "Equipment" }, { key: "required_skill", label: "Skill" },
                { key: "setup_minutes", label: "Setup (min)", num: true, render: (o) => num(o.setup_minutes) },
                { key: "run_minutes_per_unit", label: "Run (min/unit)", num: true, render: (o) => num(o.run_minutes_per_unit) },
                { key: "flags", label: "", render: (o) => <>{o.inspection_point && <Chip tone="cyan" label={`inspect ${o.inspection_plan_code || ""}`} />} {o.subcontracted && <Chip tone="navy" label="subcontract" />} {o.reports_output && <Chip tone="orange" label="output" />}</> },
                { key: "instructions", label: "Instructions", render: (o) => <span className="small">{o.instructions}</span> },
              ]} />
            </Card>
          ))}
          {sel && <div className="grid g2">
            <Card title="Requirements explosion" actions={<label className="row small">Quantity <input value={qty} onChange={(e) => setQty(e.target.value)} size={5} /></label>}>
              <Table rows={explosion.data?.lines?.map((l: any, i: number) => ({ id: i, ...l }))} cols={[
                { key: "level", label: "Lvl" }, { key: "item_code", label: "Item" }, { key: "quantity", label: "Qty", num: true, render: (l) => `${num(l.quantity, 4)} ${l.unit}` },
                { key: "explanation", label: "How calculated", render: (l) => <span className="small">{l.explanation}</span> },
              ]} />
            </Card>
            <Card title="Standard cost roll-up">
              <ErrorBox error={std.error} />
              {std.data && <>
                <div style={{ fontSize: 22, fontWeight: 700 }}>{gbp(std.data.unit_cost)} <span className="small muted">per unit, setup over {num(std.data.batch_size_for_setup)}</span></div>
                <Table rows={Object.entries(std.data.elements || {}).map(([k, v]) => ({ id: k, k, v }))} cols={[{ key: "k", label: "Element" }, { key: "v", label: "GBP", num: true, render: (r) => gbp(r.v) }]} />
              </>}
            </Card>
          </div>}
        </div>
      </div>
    </>
  );
}
