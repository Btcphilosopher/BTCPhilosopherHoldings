"use client";
import { use } from "react";
import { Card, Chip, Table, PageHead, Alert, Toast } from "@/components/ui";
import { useApi, useToast } from "@/lib/hooks";
import { api, can, getUser, openReport } from "@/lib/api";
import { dt, gbp, num } from "@/lib/format";

export default function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const o = useApi<any>(`/orders/${id}`);
  const cost = useApi<any>(`/costing/orders/${id}`);
  const toast = useToast();
  const user = getUser();
  const d = o.data;
  const act = async (path: string, body: any, ok: string) => { try { await api(`/orders/${id}/${path}`, { body }); toast.ok(ok); o.reload(); cost.reload(); } catch (e) { toast.fail(e); } };
  if (!d) return <div className="empty">Loading…</div>;
  const snap = d.snapshot || {};
  return (
    <>
      <PageHead title={`${d.number} · ${d.item_code}`} sub={d.item_description} actions={<>
        <Chip v={d.status} />
        {d.status === "draft" && can(user, "production.plan") && <button className="btn" onClick={() => act("plan", { version: d.version }, "Planned: definitions snapshotted")}>Plan</button>}
        {["planned", "released", "in_progress"].includes(d.status) && can(user, "inventory.reserve") && <button className="btn" onClick={() => act("allocate", {}, "Accepted lots reserved")}>Allocate</button>}
        {d.status === "planned" && can(user, "production.release") && <button className="btn primary" onClick={() => act("release", { version: d.version }, "Released — revision frozen")}>Release</button>}
        {d.status === "completed" && can(user, "production.close") && <button className="btn navy" onClick={() => act("close", { version: d.version }, "Closed")}>Close</button>}
      </>} />
      <div className="grid g4" style={{ marginBottom: 16 }}>
        <div className="kpi orange"><div className="v">{num(d.quantity_target)}</div><div className="l">Target (good)</div></div>
        <div className="kpi"><div className="v">{num(d.quantity_reported)}</div><div className="l">Output reported</div></div>
        <div className="kpi cyan"><div className="v">{num(d.quantity_accepted)}</div><div className="l">Accepted by quality</div></div>
        <div className="kpi red"><div className="v">{num(d.quantity_scrapped)} / {num(d.quantity_nonconforming)}</div><div className="l">Scrapped / nonconforming</div></div>
      </div>
      <Alert kind="info">{d.status_explanation.note} Operations complete: {d.status_explanation.operations_complete ? "yes" : "no"} · reported {num(d.status_explanation.output_reported)} · accepted {num(d.status_explanation.output_accepted_by_quality)} · closed: {d.status_explanation.closed ? "yes" : "no"}.</Alert>
      {d.shortages.map((s: any) => <Alert key={s.material_id} kind="constraint">{s.item_code}: short {num(s.short)} {s.unit} (required {num(s.required)}, covered {num(s.covered)})</Alert>)}
      {d.exceptions.map((x: any) => <Alert key={x.id} kind={x.severity === "failure" ? "failure" : "constraint"}><b>{x.kind}</b> — {x.description}</Alert>)}
      <div className="grid g2">
        <Card title="Frozen definitions">
          <dl className="kv">
            <dt>BOM</dt><dd>{snap.bom?.version ? `v${snap.bom.version} (approved ${dt(snap.bom.approved_at)})` : "— (rework: instructions only)"}</dd>
            <dt>Routing</dt><dd>v{snap.routing?.version} ({snap.routing?.kind})</dd>
            <dt>Captured</dt><dd>{dt(snap.captured_at)}</dd>
            <dt>Frozen at release</dt><dd>{snap.frozen ? dt(snap.frozen_at) : "not yet released"}</dd>
            {d.rework_instructions && <><dt>Rework instructions</dt><dd>{d.rework_instructions}</dd></>}
          </dl>
        </Card>
        <Card title="Cost (GBP)" actions={<a className="btn sm" href="/costing">Costing</a>}>
          {cost.data && <Table rows={["standard", "planned", "actual", "estimate_at_completion", "posted"].map((k) => ({ id: k, k, v: k === "standard" ? cost.data.standard.total_for_target : cost.data[k]?.total }))}
            cols={[{ key: "k", label: "Figure", render: (r) => r.k.replace(/_/g, " ") }, { key: "v", label: "Total", num: true, render: (r) => r.v == null ? "n/a" : gbp(r.v) }]} />}
        </Card>
      </div>
      <Card title="Materials">
        <Table rows={d.materials} cols={[
          { key: "line_no", label: "Line" }, { key: "item_code", label: "Item", render: (m) => <><span className="mono">{m.item_code}</span> {m.additional && <Chip tone="amber" label="additional" />} {m.backflush && <Chip tone="amber" label="backflush" />}</> },
          { key: "required_quantity", label: "Planned", num: true, render: (m) => num(m.required_quantity, 4) },
          { key: "reserved", label: "Reserved", num: true, render: (m) => num(m.reserved, 4) },
          { key: "quantity_issued", label: "Issued (physical)", num: true, render: (m) => num(m.quantity_issued, 4) },
          { key: "quantity_consumed", label: "Consumed (recorded)", num: true, render: (m) => num(m.quantity_consumed, 4) },
          { key: "quantity_consumed_calculated", label: "of which calculated", num: true, render: (m) => Number(m.quantity_consumed_calculated) ? <Chip tone="amber" label={num(m.quantity_consumed_calculated, 4)} /> : "—" },
          { key: "quantity_returned", label: "Returned", num: true, render: (m) => num(m.quantity_returned, 4) },
          { key: "quantity_scrapped", label: "Scrapped", num: true, render: (m) => num(m.quantity_scrapped, 4) },
          { key: "unit", label: "Unit" },
        ]} />
      </Card>
      <Card title="Operations">
        <Table rows={d.operations} cols={[
          { key: "seq", label: "Op" }, { key: "name", label: "Operation" }, { key: "work_centre", label: "WC" }, { key: "status", label: "Status", render: (op) => <Chip v={op.status} /> },
          { key: "quantity_good", label: "Good", num: true, render: (op) => num(op.quantity_good) }, { key: "quantity_scrap", label: "Scrap", num: true, render: (op) => num(op.quantity_scrap) },
          { key: "quantity_rework", label: "Rework", num: true, render: (op) => num(op.quantity_rework) },
          { key: "planned", label: "Planned", render: (op) => op.planned_start ? `${dt(op.planned_start)} → ${dt(op.planned_end)}` : "—" },
          { key: "actual", label: "Actual", render: (op) => op.actual_start ? `${dt(op.actual_start)} → ${dt(op.actual_end)}` : "—" },
          { key: "time", label: "Booked (shift) min", num: true, render: (op) => num(op.time.reduce((s: number, t: any) => s + Number(t.minutes), 0), 0) },
        ]} />
      </Card>
      <div className="grid g2">
        <Card title="Recorded consumption">
          <Table rows={d.consumption} max={60} cols={[{ key: "movement_no", label: "Movement" }, { key: "item_code", label: "Item" }, { key: "lot_number", label: "Lot" },
            { key: "quantity", label: "Qty", num: true, render: (c) => num(c.quantity, 4) }, { key: "value_source", label: "Source", render: (c) => <Chip v={c.value_source} /> },
            { key: "observed_at", label: "Observed", render: (c) => dt(c.observed_at) }, { key: "notes", label: "Note", render: (c) => <span className="small">{c.notes}</span> }]} />
        </Card>
        <Card title="Output">
          <Table rows={d.outputs} max={120} cols={[{ key: "lot_number", label: "Lot / serial", render: (p) => <a href="#" onClick={(e) => { e.preventDefault(); openReport(`/reports/traceability/${p.lot_id}`); }}>{p.lot_number}</a> },
            { key: "quantity", label: "Qty", num: true, render: (p) => num(p.quantity) }, { key: "conformity", label: "Conformity", render: (p) => <Chip v={p.conformity === "good" ? "accepted" : "nonconforming"} label={p.conformity} /> },
            { key: "quality_status", label: "Quality status", render: (p) => <Chip v={p.quality_status} /> }, { key: "observed_at", label: "Observed", render: (p) => dt(p.observed_at) }]} />
        </Card>
      </div>
      <Toast msg={toast.msg} />
    </>
  );
}
