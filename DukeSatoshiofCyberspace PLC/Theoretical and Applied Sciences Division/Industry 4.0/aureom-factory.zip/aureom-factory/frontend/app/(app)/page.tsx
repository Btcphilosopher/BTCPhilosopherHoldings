"use client";
import Link from "next/link";
import { Card, Kpi, Alert, Table, WithTable, PageHead, ErrorBox, Chip } from "@/components/ui";
import { FlowDiagram, FlowTable } from "@/components/Diagrams";
import { useApi, useLive } from "@/lib/hooks";
import { dt, num } from "@/lib/format";

export default function Overview() {
  const ov = useApi<any>("/reports/overview");
  const flow = useApi<any>("/reports/material-flow");
  const orders = useApi<any[]>("/orders");
  const { events } = useLive((e) => { if (e.topic.startsWith("inventory") || e.topic.startsWith("production") || e.topic.startsWith("quality")) ov.reload(); });
  const o = ov.data;
  const by = o?.orders_by_status || {};
  const active = (by.released || 0) + (by.in_progress || 0) + (by.paused || 0);
  return (
    <>
      <PageHead title="Overview" sub="Planned activity, physical stock, recorded consumption and accepted output are shown separately." />
      <ErrorBox error={ov.error} />
      <div className="grid g6" style={{ marginBottom: 16 }}>
        <Kpi label="Orders active" value={active} tone="orange" />
        <Kpi label="Awaiting inspection" value={by.awaiting_inspection || 0} tone="amber" />
        <Kpi label="Lots awaiting release" value={o?.lots_awaiting_release ?? "—"} tone="amber" />
        <Kpi label="Lots quarantined" value={o?.lots_quarantined ?? "—"} tone="amber" />
        <Kpi label="Open nonconformances" value={o?.open_ncrs ?? "—"} tone="red" />
        <Kpi label="Orders closed" value={by.closed || 0} />
      </div>
      <div className="grid g2">
        <Card title="Failures and constraints">
          {o && !o.failures.length && !o.constraints.length && <div className="muted">No open failures or constraints.</div>}
          {o?.failures.map((f: any, i: number) => <Alert key={"f" + i} kind="failure"><b>{f.kind.replace(/_/g, " ")}</b> — {f.text}</Alert>)}
          {o?.constraints.slice(0, 12).map((c: any, i: number) => <Alert key={"c" + i} kind="constraint"><b>{c.kind.replace(/_/g, " ")}</b> — {c.text}</Alert>)}
        </Card>
        <Card title="Production orders" actions={<Link className="btn sm" href="/production">All orders</Link>}>
          <Table rows={orders.data} max={8} cols={[
            { key: "number", label: "Order", render: (r) => <Link href={`/production/${r.id}`}>{r.number}</Link> },
            { key: "item_code", label: "Item" },
            { key: "status", label: "Status", render: (r) => <Chip v={r.status} /> },
            { key: "quantity_target", label: "Target", num: true, render: (r) => num(r.quantity_target) },
            { key: "quantity_reported", label: "Reported", num: true, render: (r) => num(r.quantity_reported) },
            { key: "quantity_accepted", label: "Accepted", num: true, render: (r) => num(r.quantity_accepted) },
          ]} />
        </Card>
      </div>
      <Card title="Material flow (all recorded movements)">
        {flow.data && <WithTable label="Material flow diagram" diagram={<FlowDiagram flow={flow.data} />} table={<FlowTable flow={flow.data} />} />}
        <div className="legend small" style={{ marginTop: 8 }}>
          <span style={{ ["--c" as any]: "#0e9cbf" }}>flow (width ∝ movements)</span>
          <span style={{ ["--c" as any]: "#e8641b" }}>production</span>
          <span style={{ ["--c" as any]: "#f0b429" }}>held / review</span>
          <span style={{ ["--c" as any]: "#b3261e" }}>scrap</span>
        </div>
      </Card>
      <div className="grid g2">
        <Card title="Stock — physical vs available">
          <Table rows={o?.stock} cols={[
            { key: "item_code", label: "Item" },
            { key: "physical", label: "Physical", num: true, render: (r) => num(r.physical) },
            { key: "available", label: "Available", num: true, render: (r) => <b>{num(r.available)}</b> },
            { key: "quarantined", label: "Held", num: true, render: (r) => num(Number(r.quarantined) + Number(r.awaiting_review) + Number(r.rejected)) },
            { key: "wip", label: "WIP", num: true, render: (r) => num(r.wip) },
            { key: "unit", label: "Unit" },
          ]} />
        </Card>
        <Card title="Recent movements">
          <Table rows={o?.recent_movements} cols={[
            { key: "movement_no", label: "No." }, { key: "type", label: "Type" }, { key: "item", label: "Item" },
            { key: "qty", label: "Qty", num: true, render: (r) => num(r.qty) },
            { key: "value_source", label: "Source", render: (r) => <Chip v={r.value_source} /> },
            { key: "observed_at", label: "Observed", render: (r) => dt(r.observed_at) },
          ]} />
          {events.length > 0 && <div className="small muted" style={{ marginTop: 8 }}>{events.length} live event(s) received this session.</div>}
        </Card>
      </div>
    </>
  );
}
