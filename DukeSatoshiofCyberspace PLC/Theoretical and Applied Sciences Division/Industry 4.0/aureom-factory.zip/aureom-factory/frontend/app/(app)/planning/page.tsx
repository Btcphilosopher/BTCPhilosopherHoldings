"use client";
import { useState } from "react";
import { Card, Chip, Table, PageHead, Toast, Alert, Tabs, WithTable, ErrorBox } from "@/components/ui";
import { Gantt } from "@/components/Diagrams";
import { useApi, useToast } from "@/lib/hooks";
import { api, can, getUser } from "@/lib/api";
import { day, dt, num } from "@/lib/format";

export default function Planning() {
  const [tab, setTab] = useState("Material requirements");
  const demands = useApi<any[]>("/demands");
  const mrp = useApi<any>("/mrp/runs/latest");
  const sched = useApi<any>("/schedule/latest");
  const orders = useApi<any[]>("/orders");
  const [open, setOpen] = useState<string | null>(null);
  const toast = useToast();
  const user = getUser();
  const run = async () => { try { await api("/mrp/runs", { body: { horizon_days: 90 } }); toast.ok("MRP run complete — proposals only, nothing released"); mrp.reload(); } catch (e) { toast.fail(e); } };
  const runSched = async () => { try { await api("/schedule/runs", { body: { horizon_days: 30 } }); toast.ok("Schedule recalculated"); sched.reload(); } catch (e) { toast.fail(e); } };
  const decide = async (p: any, ok: boolean) => {
    try {
      if (ok) { const r = await api(`/mrp/proposals/${p.id}/accept`, { body: {} }); toast.ok(r.note); }
      else { const reason = prompt("Reason for rejecting?"); if (!reason) return; await api(`/mrp/proposals/${p.id}/reject`, { body: { reason } }); }
      mrp.reload();
    } catch (e) { toast.fail(e); }
  };
  const due: Record<string, string | null> = {};
  (orders.data || []).forEach((o) => { if (o.due_date) due[o.number] = o.due_date; });
  return (
    <>
      <PageHead title="Planning" sub="Transparent MRP and a finite-capacity scheduling baseline. Proposals never create financial commitments or release work by themselves." />
      <Card title="Demand">
        <Table rows={demands.data} cols={[{ key: "number", label: "Demand" }, { key: "item_code", label: "Item" }, { key: "quantity", label: "Qty", num: true, render: (d) => num(d.quantity) },
          { key: "due_date", label: "Due", render: (d) => day(d.due_date) }, { key: "kind", label: "Kind" }, { key: "status", label: "Status", render: (d) => <Chip v={d.status} /> }]} />
      </Card>
      <Tabs tabs={["Material requirements", "Schedule"]} value={tab} onChange={setTab} />
      {tab === "Material requirements" && <>
        <Card title={mrp.data ? `MRP run ${mrp.data.number} (as of ${day(mrp.data.as_of)})` : "MRP"} actions={can(user, "planning.run") && <button className="btn primary" onClick={run}>Run MRP</button>}>
          {mrp.error && <div className="muted">No MRP run yet.</div>}
          {mrp.data?.warnings?.map((w: string, i: number) => <Alert key={i} kind="constraint">{w}</Alert>)}
          <Table rows={mrp.data?.proposals} cols={[
            { key: "kind", label: "Proposal", render: (p) => <Chip tone={p.kind === "purchase" ? "cyan" : "orange"} label={p.kind} /> },
            { key: "item_code", label: "Item" }, { key: "order_quantity", label: "Quantity", num: true, render: (p) => `${num(p.order_quantity)} ${p.order_unit}` },
            { key: "need_date", label: "Needed", render: (p) => day(p.need_date) }, { key: "release_date", label: "Release", render: (p) => day(p.release_date) },
            { key: "late", label: "Feasibility", render: (p) => p.late ? <Chip tone="amber" label={`late — earliest ${day(p.expected_available)}`} /> : <Chip v="accepted" label="on time" /> },
            { key: "explanation", label: "Why", render: (p) => <details><summary className="small">explain</summary><ul className="small">{p.explanation.map((e: string, i: number) => <li key={i}>{e}</li>)}</ul></details> },
            { key: "status", label: "Status", render: (p) => <Chip v={p.status} /> },
            { key: "a", label: "", render: (p) => p.status === "proposed" && can(user, "planning.accept") ? <span className="row">
              <button className="btn sm primary" onClick={() => decide(p, true)}>Accept</button><button className="btn sm" onClick={() => decide(p, false)}>Reject</button></span> : null },
          ]} />
        </Card>
        <Card title="Netting by item (explanations)">
          {mrp.data?.lines?.map((l: any) => (
            <details key={l.item_code} open={open === l.item_code} onToggle={(e) => (e.target as HTMLDetailsElement).open && setOpen(l.item_code)} style={{ borderBottom: "1px solid var(--mist-2)", padding: "6px 0" }}>
              <summary><b className="mono">{l.item_code}</b> <span className="small muted">level {l.level} · available {num(l.available)} {l.unit} · gross {num(l.gross_total)} · supply {num(l.supply_total)} · planned {l.planned.length}</span></summary>
              <ol className="small mono" style={{ marginTop: 6 }}>{l.explanation.map((e: string, i: number) => <li key={i}>{e}</li>)}</ol>
            </details>
          ))}
        </Card>
      </>}
      {tab === "Schedule" && <Card title={sched.data ? `Schedule ${sched.data.number} from ${dt(sched.data.start_at)}` : "Schedule"} actions={can(user, "production.plan") && <button className="btn primary" onClick={runSched}>Recalculate</button>}>
        <ErrorBox error={sched.error && sched.error.status !== 404 ? sched.error : null} />
        {sched.data && <>
          <p className="small muted" style={{ marginTop: 0 }}>{sched.data.result.method}</p>
          {sched.data.result.orders.filter((o: any) => !o.feasible || (o.late_days ?? 0) > 0).map((o: any) => (
            <Alert key={o.order} kind={o.feasible ? "constraint" : "failure"}><b>{o.order}</b> {o.feasible ? `estimated ${o.late_days} day(s) late` : "not feasible within horizon"} — {o.notes.join("; ")}</Alert>
          ))}
          <WithTable label="Schedule timeline" diagram={<Gantt bars={sched.data.result.bars} dueDates={due} />} table={
            <Table rows={sched.data.result.bars.map((b: any, i: number) => ({ id: i, ...b }))} cols={[{ key: "order", label: "Order" }, { key: "op", label: "Op" }, { key: "name", label: "Operation" },
              { key: "resource", label: "Resource" }, { key: "operator", label: "Operator" }, { key: "start", label: "Start", render: (b) => dt(b.start) }, { key: "end", label: "End", render: (b) => dt(b.end) }]} />} />
          <h3 style={{ marginTop: 14 }}>Orders</h3>
          <Table rows={sched.data.result.orders.map((o: any, i: number) => ({ id: i, ...o }))} cols={[{ key: "order", label: "Order" }, { key: "item", label: "Item" },
            { key: "due_date", label: "Due", render: (o) => day(o.due_date) }, { key: "estimated_finish", label: "Estimated finish", render: (o) => dt(o.estimated_finish) },
            { key: "late_days", label: "Days late", num: true, render: (o) => o.late_days == null ? "—" : o.late_days > 0 ? <Chip tone="amber" label={`+${o.late_days}`} /> : o.late_days },
            { key: "feasible", label: "Feasible", render: (o) => o.feasible ? "yes" : <Chip tone="red" label="no" /> },
            { key: "notes", label: "Constraints", render: (o) => <span className="small">{o.notes.join("; ")}</span> }]} />
        </>}
      </Card>}
      <Toast msg={toast.msg} />
    </>
  );
}
