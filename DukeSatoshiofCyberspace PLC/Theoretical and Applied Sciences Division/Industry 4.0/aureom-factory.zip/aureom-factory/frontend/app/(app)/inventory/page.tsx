"use client";
import { useState } from "react";
import { Card, Chip, Table, PageHead, Tabs, Toast, Alert, ErrorBox } from "@/components/ui";
import Scanner, { ScanRecord } from "@/components/Scanner";
import { useApi, useToast } from "@/lib/hooks";
import { api, can, getUser } from "@/lib/api";
import { dt, num } from "@/lib/format";

export default function Inventory() {
  const [tab, setTab] = useState("Stock");
  const [status, setStatus] = useState("");
  const [lotId, setLotId] = useState<number | null>(null);
  const [scan, setScan] = useState<ScanRecord | null>(null);
  const stock = useApi<any[]>("/stock");
  const lots = useApi<any[]>(`/lots${status ? "?quality_status=" + status : ""}`, [status]);
  const moves = useApi<any[]>(tab === "Movement journal" ? "/movements?limit=300" : null, [tab]);
  const res = useApi<any[]>(tab === "Reservations" ? "/reservations" : null, [tab]);
  const bins = useApi<any[]>(tab === "Locations" ? "/bins" : null, [tab]);
  const lot = useApi<any>(lotId ? `/lots/${lotId}` : null, [lotId]);
  const toast = useToast();
  const user = getUser();

  const reverse = async (m: any) => {
    const reason = prompt(`Reason for reversing ${m.movement_no}?`);
    if (!reason) return;
    try { await api(`/movements/${m.id}/reverse`, { body: { reason } }); toast.ok("Reversal posted (linked to the original)"); moves.reload(); lot.reload(); }
    catch (e) { toast.fail(e); }
  };

  return (
    <>
      <PageHead title="Inventory" sub="Physical stock in every bin (including quarantine, WIP and subcontractors) versus stock available for allocation." />
      <Card title="Scan to identify">
        <Scanner onResult={(r) => { setScan(r); if (r.record?.lot_id) setLotId(r.record.lot_id); }} />
        {scan?.record && scan.kind !== "lot" && scan.kind !== "serial" && <pre className="small mono">{JSON.stringify(scan.record, null, 2)}</pre>}
      </Card>
      <Tabs tabs={["Stock", "Lots", "Movement journal", "Reservations", "Locations"]} value={tab} onChange={setTab} />
      {tab === "Stock" && <Card title="Stock by item">
        <Table rows={stock.data} cols={[
          { key: "item_code", label: "Item", render: (r) => <b className="mono">{r.item_code}</b> }, { key: "description", label: "Description" },
          { key: "physical", label: "Physical", num: true, render: (r) => num(r.physical) },
          { key: "accepted_allocatable", label: "Accepted in stores", num: true, render: (r) => num(r.accepted_allocatable) },
          { key: "reserved", label: "Reserved", num: true, render: (r) => num(r.reserved) },
          { key: "available", label: "Available", num: true, render: (r) => <b>{num(r.available)}</b> },
          { key: "awaiting_review", label: "Awaiting review", num: true, render: (r) => num(r.awaiting_review) },
          { key: "quarantined", label: "Quarantined", num: true, render: (r) => num(r.quarantined) },
          { key: "rejected", label: "Rejected", num: true, render: (r) => num(r.rejected) },
          { key: "wip", label: "WIP", num: true, render: (r) => num(r.wip) },
          { key: "at_subcontractor", label: "At subcon.", num: true, render: (r) => num(r.at_subcontractor) },
          { key: "unit", label: "Unit" },
        ]} />
      </Card>}
      {tab === "Lots" && <div className="grid g2">
        <Card title="Lots and serials" actions={<select aria-label="Quality status" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All statuses</option>{["accepted", "awaiting_review", "quarantined", "rejected"].map((s) => <option key={s}>{s}</option>)}</select>}>
          <Table rows={lots.data} onRow={(r) => setLotId(r.id)} selected={(r) => r.id === lotId} max={300} cols={[
            { key: "lot_number", label: "Lot / serial", render: (r) => <span className="mono">{r.lot_number}</span> }, { key: "item_code", label: "Item" },
            { key: "supplier_lot", label: "Supplier lot", render: (r) => r.supplier_lot || "—" },
            { key: "quality_status", label: "Quality", render: (r) => <Chip v={r.quality_status} /> },
            { key: "on_hand", label: "On hand", num: true, render: (r) => num(r.on_hand) },
            { key: "traceability", label: "Provenance", render: (r) => <Chip v={r.traceability === "complete" ? "accepted" : "unknown"} label={r.traceability} /> },
          ]} />
        </Card>
        <LotDetail lot={lot.data} onReverse={can(user, "inventory.adjust") ? reverse : undefined} />
      </div>}
      {tab === "Movement journal" && <Card title="Append-only movement journal">
        <Alert kind="info">Entries are never edited or deleted (enforced in the database). Corrections are posted as linked reversals.</Alert>
        <MovementTable rows={moves.data} onReverse={can(user, "inventory.adjust") ? reverse : undefined} />
      </Card>}
      {tab === "Reservations" && <Card title="Active reservations">
        <Table rows={res.data} cols={[{ key: "id", label: "#" }, { key: "item_code", label: "Item" }, { key: "lot_number", label: "Lot" }, { key: "bin", label: "Bin" },
          { key: "quantity", label: "Reserved", num: true, render: (r) => num(r.quantity) }, { key: "quantity_issued", label: "Issued", num: true, render: (r) => num(r.quantity_issued) },
          { key: "demand_type", label: "For" }, { key: "demand_id", label: "Demand ID" }]} />
      </Card>}
      {tab === "Locations" && <Card title="Warehouses and bins">
        <Table rows={bins.data} cols={[{ key: "warehouse", label: "Warehouse" }, { key: "code", label: "Bin" }, { key: "kind", label: "Kind" },
          { key: "allocatable", label: "Allocatable", render: (b) => b.allocatable ? <Chip v="accepted" label="yes" /> : <Chip label="no" /> },
          { key: "warehouse_kind", label: "Location type", render: (b) => b.warehouse_kind === "subcontractor" ? <Chip tone="cyan" label="at subcontractor (company-owned)" /> : "internal" },
          { key: "description", label: "Description" }]} />
      </Card>}
      <Toast msg={toast.msg} />
      <ErrorBox error={stock.error} />
    </>
  );
}

function MovementTable({ rows, onReverse }: { rows: any[] | null; onReverse?: (m: any) => void }) {
  return <Table rows={rows} rowClass={(m) => (m.reversed ? "struck" : "")} cols={[
    { key: "movement_no", label: "No.", render: (m) => <span className="mono">{m.movement_no}</span> },
    { key: "movement_type", label: "Type", render: (m) => <>{m.movement_type}{m.reverses_movement_id ? <span className="small muted"> (reverses #{m.reverses_movement_id})</span> : null}</> },
    { key: "item_code", label: "Item" }, { key: "lot_number", label: "Lot", render: (m) => m.lot_number || "—" },
    { key: "from_bin", label: "From", render: (m) => m.from_bin || "—" }, { key: "to_bin", label: "To", render: (m) => m.to_bin || "—" },
    { key: "quantity", label: "Qty", num: true, render: (m) => num(m.quantity) },
    { key: "value_source", label: "Source", render: (m) => <Chip v={m.value_source} /> },
    { key: "observed_at", label: "Observed", render: (m) => dt(m.observed_at) },
    { key: "recorded_at", label: "Recorded", render: (m) => dt(m.recorded_at) },
    { key: "recorded_by_name", label: "By" },
    ...(onReverse ? [{ key: "act", label: "", render: (m: any) => !m.reversed && m.movement_type !== "reversal" ? <button className="btn sm" onClick={(e) => { e.stopPropagation(); onReverse(m); }}>Reverse</button> : null }] : []),
  ]} />;
}

function LotDetail({ lot, onReverse }: { lot: any; onReverse?: (m: any) => void }) {
  if (!lot) return <Card title="Lot detail"><div className="muted">Select or scan a lot.</div></Card>;
  return (
    <Card title={`${lot.item_code} · ${lot.lot_number}`}>
      <dl className="kv">
        <dt>Quality status</dt><dd><Chip v={lot.quality_status} /></dd>
        <dt>Origin</dt><dd>{lot.origin}{lot.batch_ref ? ` · batch ${lot.batch_ref}` : ""}</dd>
        <dt>Supplier lot</dt><dd>{lot.supplier_lot || "—"}</dd>
        <dt>Provenance</dt><dd><Chip v={lot.traceability === "complete" ? "accepted" : "unknown"} label={lot.traceability} /> {lot.traceability_note}</dd>
        <dt>Expiry</dt><dd>{lot.expiry_date || "not applicable"}</dd>
        <dt>Unit cost</dt><dd>{lot.unit_cost ? `£${lot.unit_cost} / ${lot.base_unit}` : "—"} <span className="small muted">{lot.cost_basis}</span></dd>
        <dt>Locations</dt><dd>{lot.locations.map((l: any) => `${l.bin} (${l.bin_kind}): ${num(l.quantity)}`).join("; ") || "none (fully used or shipped)"}</dd>
      </dl>
      <h3 style={{ marginTop: 14 }}>Quality status history</h3>
      <Table rows={lot.status_history} cols={[{ key: "changed_at", label: "When", render: (h) => dt(h.changed_at) },
        { key: "from_status", label: "From", render: (h) => <Chip v={h.from_status} /> }, { key: "to_status", label: "To", render: (h) => <Chip v={h.to_status} /> },
        { key: "reason", label: "Reason" }, { key: "changed_by_name", label: "By" }]} />
      <h3 style={{ marginTop: 14 }}>Movements</h3>
      <MovementTable rows={lot.movements} onReverse={onReverse} />
    </Card>
  );
}
