"use client";
import { useState } from "react";
import { Card, Chip, Table, PageHead, Tabs, Alert } from "@/components/ui";
import { useApi } from "@/lib/hooks";
import { openReport } from "@/lib/api";
import { day, dt, num } from "@/lib/format";

export default function Dispatch() {
  const [tab, setTab] = useState("Customer orders");
  const cos = useApi<any[]>("/customer-orders");
  const ships = useApi<any[]>("/shipments");
  const returns = useApi<any[]>(tab === "Returns" ? "/customer-returns" : null, [tab]);
  const recalls = useApi<any[]>(tab === "Recalls" ? "/recalls" : null, [tab]);
  const [rid, setRid] = useState<number | null>(null);
  const recall = useApi<any>(rid ? `/recalls/${rid}` : null, [rid]);
  const fg = useApi<any[]>("/stock");
  const lamp = fg.data?.find((s) => s.item_type === "finished_product");
  return (
    <>
      <PageHead title="Dispatch" sub="Produced, quality-released, allocated, picked, dispatched and delivered quantities are tracked separately." />
      {lamp && <div className="grid g4" style={{ marginBottom: 16 }}>
        <div className="kpi"><div className="v">{num(lamp.physical)}</div><div className="l">{lamp.item_code} physical</div></div>
        <div className="kpi cyan"><div className="v">{num(lamp.accepted_allocatable)}</div><div className="l">Released, in finished stores</div></div>
        <div className="kpi orange"><div className="v">{num(lamp.available)}</div><div className="l">Available to promise</div></div>
        <div className="kpi amber"><div className="v">{num(Number(lamp.awaiting_review) + Number(lamp.quarantined))}</div><div className="l">Held (review / quarantine)</div></div>
      </div>}
      <Tabs tabs={["Customer orders", "Shipments", "Returns", "Recalls"]} value={tab} onChange={setTab} />
      {tab === "Customer orders" && cos.data?.map((c) => (
        <Card key={c.id} title={`${c.number} — ${c.customer}`} actions={<><Chip v={c.status} /><span className="small muted">ref {c.customer_reference || "—"} · required {day(c.required_date)}</span></>}>
          <Table rows={c.lines} cols={[{ key: "line_no", label: "Line" }, { key: "item_code", label: "Item" },
            ...["ordered", "allocated", "picked", "packed", "dispatched", "delivered", "returned"].map((k) => ({ key: k, label: k[0].toUpperCase() + k.slice(1), num: true, render: (l: any) => num(l["quantity_" + k]) }))]} />
        </Card>
      ))}
      {tab === "Shipments" && <Card title="Shipments">
        <Table rows={ships.data} cols={[{ key: "number", label: "Shipment" }, { key: "order", label: "Order" }, { key: "customer", label: "Customer" },
          { key: "status", label: "Status", render: (s) => <Chip v={s.status} /> }, { key: "units", label: "Units", num: true, render: (s) => num(s.lines.reduce((a: number, l: any) => a + Number(l.quantity), 0)) },
          { key: "carrier", label: "Carrier", render: (s) => `${s.carrier || "—"} ${s.tracking_ref || ""}` }, { key: "dispatched_at", label: "Dispatched", render: (s) => dt(s.dispatched_at) },
          { key: "delivery_ref", label: "Proof of delivery", render: (s) => s.delivery_ref || "—" },
          { key: "doc", label: "", render: (s) => <button className="btn sm" onClick={() => openReport(`/reports/packing-list/${s.id}`)}>Packing list</button> }]} />
      </Card>}
      {tab === "Returns" && <Card title="Customer returns">
        <Alert kind="info">Returned products enter review (awaiting review, returns bin, nonconformance raised). They never become saleable automatically.</Alert>
        <Table rows={returns.data} cols={[{ key: "number", label: "RMA" }, { key: "lot_id", label: "Lot id" }, { key: "quantity", label: "Qty", num: true, render: (r) => num(r.quantity) },
          { key: "reason", label: "Reason" }, { key: "status", label: "Status", render: (r) => <Chip v={r.status === "under_review" ? "awaiting_review" : r.status} label={r.status} /> }, { key: "received_at", label: "Received", render: (r) => dt(r.received_at) }]} />
      </Card>}
      {tab === "Recalls" && <div className="grid g2" style={{ gridTemplateColumns: "minmax(0,.8fr) minmax(0,1.6fr)" }}>
        <Card title="Recalls"><Table rows={recalls.data} onRow={(r) => setRid(r.id)} selected={(r) => r.id === rid} cols={[{ key: "number", label: "No." }, { key: "title", label: "Title" }, { key: "status", label: "Status", render: (r) => <Chip v={r.status} /> }]} /></Card>
        <Card title={recall.data ? `${recall.data.number}: ${recall.data.title}` : "Recall investigation"} actions={recall.data && <button className="btn sm" onClick={() => openReport(`/reports/recall/${rid}`)}>Report</button>}>
          {!recall.data && <div className="muted">Select a recall.</div>}
          {recall.data && <>
            <p style={{ marginTop: 0 }}>{recall.data.description}</p>
            <div className="grid g3" style={{ marginBottom: 10 }}>
              <div className="kpi red"><div className="v">{recall.data.findings.finished_units.confirmed}</div><div className="l">Finished units confirmed</div></div>
              <div className="kpi amber"><div className="v">{recall.data.findings.finished_units.possible}</div><div className="l">Possible (order-level)</div></div>
              <div className="kpi"><div className="v">{recall.data.findings.finished_units.unknown}</div><div className="l">Unknown provenance</div></div>
            </div>
            <Alert kind="constraint">{recall.data.findings.statement}</Alert>
            {Object.entries(recall.data.findings.customers).map(([c, l]: any) => <Alert key={c} kind="failure">Notify <b>{c}</b>: {l.length} unit(s) shipped ({Array.from(new Set(l.map((x: any) => x.shipment))).join(", ")})</Alert>)}
            <Table rows={recall.data.items} max={120} cols={[{ key: "item_code", label: "Item" }, { key: "lot_number", label: "Lot / serial" }, { key: "precision", label: "Link", render: (i) => <Chip v={i.precision} /> },
              { key: "location_kind", label: "Where" }, { key: "customer", label: "Customer" }, { key: "shipment", label: "Shipment" }, { key: "action", label: "Action", render: (i) => <Chip v={i.action === "quarantined" ? "quarantined" : "pending"} label={i.action} /> }]} />
          </>}
        </Card>
      </div>}
    </>
  );
}
