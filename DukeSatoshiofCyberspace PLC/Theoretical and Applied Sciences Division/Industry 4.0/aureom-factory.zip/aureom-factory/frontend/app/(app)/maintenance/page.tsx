"use client";
import { useState } from "react";
import { Card, Chip, Table, PageHead, Toast, Alert } from "@/components/ui";
import { useApi, useToast } from "@/lib/hooks";
import { api, can, getUser } from "@/lib/api";
import { day, dt, num } from "@/lib/format";

export default function Maintenance() {
  const eq = useApi<any[]>("/equipment");
  const [sel, setSel] = useState<number | null>(null);
  const [start, setStart] = useState("2026-11-09T00:00");
  const [end, setEnd] = useState("2026-11-14T00:00");
  const detail = useApi<any>(sel ? `/equipment/${sel}` : null, [sel]);
  const oee = useApi<any>(sel ? `/equipment/${sel}/oee?start=${encodeURIComponent(start + ":00Z")}&end=${encodeURIComponent(end + ":00Z")}` : null, [sel, start, end]);
  const toast = useToast();
  const user = getUser();
  const poll = async () => { try { const r = await api(`/equipment/${sel}/poll`, { body: {} }); toast.ok(`Observation: ${r.observation.state}${r.discrepancy ? " — " + r.discrepancy : ""}`); detail.reload(); } catch (e) { toast.fail(e); } };
  const d = detail.data;
  const pct = (v: number | null) => (v == null ? "n/a" : (v * 100).toFixed(1) + " %");
  return (
    <>
      <PageHead title="Maintenance" sub="Equipment, service schedules, downtime, calibration and read-only machine observations." />
      <Alert kind="info">Machine telemetry is read through a simulated, read-only adapter. Observations are shown beside operator and maintenance records but never overwrite them; machine control is outside this release.</Alert>
      <div className="grid g2" style={{ gridTemplateColumns: "minmax(0,1fr) minmax(0,1.3fr)" }}>
        <Card title="Equipment">
          <Table rows={eq.data} onRow={(r) => setSel(r.id)} selected={(r) => r.id === sel} cols={[
            { key: "code", label: "Code", render: (e) => <b className="mono">{e.code}</b> }, { key: "name", label: "Name" }, { key: "category", label: "Category" },
            { key: "status", label: "Status", render: (e) => <Chip v={e.status} /> },
            { key: "calibration_due", label: "Calibration", render: (e) => e.calibration_required ? (e.calibration_overdue ? <Chip tone="red" label={`OVERDUE ${day(e.calibration_due)}`} /> : `due ${day(e.calibration_due)}`) : "—" },
          ]} />
        </Card>
        <div>
          {!d && <Card title="Equipment detail"><div className="muted">Select equipment.</div></Card>}
          {d && <>
            <Card title={`${d.code} — ${d.name}`} actions={d.adapter_ref && <button className="btn" onClick={poll}>Read machine adapter</button>}>
              {d.status === "down" && <Alert kind="failure">{d.code} is DOWN: {d.status_note}</Alert>}
              <h3>Downtime</h3>
              <Table rows={d.downtime} empty="No downtime recorded" cols={[{ key: "start_at", label: "From", render: (x) => dt(x.start_at) }, { key: "end_at", label: "To", render: (x) => x.end_at ? dt(x.end_at) : <Chip tone="red" label="ongoing" /> },
                { key: "planned", label: "Planned", render: (x) => x.planned ? "yes" : "no" }, { key: "reason", label: "Reason" }, { key: "source", label: "Source" },
                { key: "confirmed", label: "Confirmed", render: (x) => x.confirmed ? "yes" : <Chip tone="amber" label="machine suggestion" /> }]} />
              <h3 style={{ marginTop: 12 }}>Work orders</h3>
              <Table rows={d.work_orders} empty="None" cols={[{ key: "number", label: "No." }, { key: "kind", label: "Kind" }, { key: "description", label: "Description" },
                { key: "status", label: "Status", render: (x) => <Chip v={x.status} /> }, { key: "work_done", label: "Work done" }]} />
              <h3 style={{ marginTop: 12 }}>Calibration</h3>
              <Table rows={d.calibrations} empty="Not calibrated equipment" cols={[{ key: "certificate_ref", label: "Certificate" }, { key: "calibrated_on", label: "On", render: (x) => day(x.calibrated_on) },
                { key: "due_on", label: "Due", render: (x) => day(x.due_on) }, { key: "result", label: "Result", render: (x) => <Chip v={x.result === "fail" ? "rejected" : "accepted"} label={x.result} /> }, { key: "provider", label: "Provider" }]} />
              <h3 style={{ marginTop: 12 }}>Machine observations (read-only)</h3>
              <Table rows={d.observations} max={20} empty="No observations" cols={[{ key: "observed_at", label: "Observed", render: (x) => dt(x.observed_at) }, { key: "received_at", label: "Received", render: (x) => dt(x.received_at) },
                { key: "state", label: "State", render: (x) => <Chip v={x.state === "down" ? "down" : "available"} label={x.state} /> }, { key: "alarm_code", label: "Alarm" }, { key: "cycle_count", label: "Cycles", num: true }, { key: "source", label: "Source" }]} />
            </Card>
            <Card title="Overall equipment effectiveness" actions={<>
              <label className="row small">From <input type="datetime-local" value={start} onChange={(e) => setStart(e.target.value)} /></label>
              <label className="row small">To <input type="datetime-local" value={end} onChange={(e) => setEnd(e.target.value)} /></label></>}>
              {oee.data && <>
                <div className="grid g4" style={{ marginBottom: 10 }}>
                  <div className="kpi cyan"><div className="v">{pct(oee.data.availability)}</div><div className="l">Availability</div></div>
                  <div className="kpi cyan"><div className="v">{pct(oee.data.performance)}</div><div className="l">Performance</div></div>
                  <div className="kpi cyan"><div className="v">{pct(oee.data.quality)}</div><div className="l">Quality</div></div>
                  <div className="kpi orange"><div className="v">{pct(oee.data.oee)}</div><div className="l">OEE</div></div>
                </div>
                <dl className="kv small">
                  <dt>Planned production time</dt><dd>{num(oee.data.planned_production_minutes)} min (planned downtime {num(oee.data.planned_downtime_minutes)} min excluded)</dd>
                  <dt>Run time</dt><dd>{num(oee.data.run_minutes)} min (unplanned downtime {num(oee.data.unplanned_downtime_minutes)} min)</dd>
                  <dt>Counts</dt><dd>total {num(oee.data.total_count)}, good {num(oee.data.good_count)}; ideal cycle {num(oee.data.ideal_cycle_minutes)} min</dd>
                  <dt>Excluded</dt><dd>unconfirmed machine-reported downtime {num(oee.data.unconfirmed_machine_downtime_minutes)} min</dd>
                </dl>
                <details><summary className="small">Definitions</summary><pre className="small" style={{ whiteSpace: "pre-wrap" }}>{oee.data.definitions}</pre></details>
              </>}
            </Card>
          </>}
        </div>
      </div>
      <Toast msg={toast.msg} />
    </>
  );
}
