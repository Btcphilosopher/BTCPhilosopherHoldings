"use client";
import { useState } from "react";
import { Card, Chip, Table, PageHead, WithTable, ErrorBox, Alert } from "@/components/ui";
import { GenealogyGraph } from "@/components/Diagrams";
import Scanner from "@/components/Scanner";
import { useApi } from "@/lib/hooks";
import { api, openReport } from "@/lib/api";
import { dt } from "@/lib/format";

export default function Reports() {
  const [lotId, setLotId] = useState<number | null>(null);
  const [sup, setSup] = useState("");
  const [supLots, setSupLots] = useState<any[] | null>(null);
  const fwd = useApi<any>(lotId ? `/trace/${lotId}/forward` : null, [lotId]);
  const back = useApi<any>(lotId ? `/trace/${lotId}/backward` : null, [lotId]);
  const audit = useApi<any[]>("/audit?limit=60");
  const findSupplierLot = async (e: React.FormEvent) => { e.preventDefault(); setSupLots(await api(`/trace/supplier-lot/${encodeURIComponent(sup)}`)); };
  const s = fwd.data?.summary;
  return (
    <>
      <PageHead title="Reports" sub="Traceability (forward and backward), printable documents and the audit trail." />
      <div className="grid g2">
        <Card title="Find a lot or serial"><Scanner onResult={(r) => r.record?.lot_id && setLotId(r.record.lot_id)} label="Scan or type LOT:/SER: code" /></Card>
        <Card title="Find by supplier lot">
          <form className="row" onSubmit={findSupplierLot}><input aria-label="Supplier lot" value={sup} onChange={(e) => setSup(e.target.value)} placeholder="e.g. LH-24-118" /><button className="btn">Search</button></form>
          <Table rows={supLots ?? undefined} empty="No matching lots" cols={[{ key: "lot_number", label: "Our lot", render: (l) => <a href="#" onClick={(e) => { e.preventDefault(); setLotId(l.id); }}>{l.lot_number}</a> },
            { key: "item_code", label: "Item" }, { key: "quality_status", label: "Status", render: (l) => <Chip v={l.quality_status} /> }]} />
        </Card>
      </div>
      <ErrorBox error={fwd.error} />
      {fwd.data && back.data && <>
        <Card title={`Traceability — ${fwd.data.lot.item_code} ${fwd.data.lot.lot_number}`} actions={<>
          <button className="btn sm" onClick={() => openReport(`/reports/traceability/${lotId}`)}>Printable report</button>
          <button className="btn sm" onClick={() => api(`/reports/label/${lotId}`).then((l) => { const u = URL.createObjectURL(new Blob([l.html], { type: "text/html" })); window.open(u, "_blank"); })}>Label</button></>}>
          <dl className="kv">
            <dt>Quality</dt><dd><Chip v={fwd.data.lot.quality_status} /></dd>
            <dt>Origin</dt><dd>{fwd.data.lot.origin} {fwd.data.lot.supplier ? `· ${fwd.data.lot.supplier} lot ${fwd.data.lot.supplier_lot}` : ""}</dd>
            <dt>Provenance</dt><dd><Chip v={fwd.data.lot.traceability === "complete" ? "accepted" : "unknown"} label={fwd.data.lot.traceability} /> {fwd.data.lot.traceability_note}</dd>
            <dt>Now</dt><dd>{fwd.data.lot.locations.map((l: any) => `${l.bin} ${l.quantity}`).join("; ") || "not in stock"} {fwd.data.lot.shipments.map((x: any) => `· shipped ${x.shipment} → ${x.customer}`).join(" ")}</dd>
          </dl>
          {s && <Alert kind="info">Downstream: {s.finished_units_reached} finished unit(s) — {Object.entries(s.finished_by_precision).map(([k, v]) => `${v} ${k === "exact" ? "confirmed" : k === "order_level" ? "possible" : "unknown"}`).join(", ") || "none"}; shipped {s.finished_shipped}; in stock {s.finished_in_stock}; lots in WIP {s.lots_in_wip}.</Alert>}
          <Alert kind="constraint">Exact links are never inferred. “Possible” means the input was consumed by the same production order without a unit-level record; “unknown” means historical records are incomplete.</Alert>
        </Card>
        <div className="grid g2">
          <Card title="Backward — which inputs contributed?">
            <WithTable label="Backward genealogy" diagram={<GenealogyGraph direction="back" root={fwd.data.lot} nodes={back.data.contributors} />} table={
              <Table rows={back.data.contributors} cols={[{ key: "depth", label: "Lvl" }, { key: "item_code", label: "Item" }, { key: "lot_number", label: "Lot", render: (r) => <a href="#" onClick={(e) => { e.preventDefault(); setLotId(r.lot_id); }}>{r.lot_number}</a> },
                { key: "supplier", label: "Supplier" }, { key: "supplier_lot", label: "Supplier lot" }, { key: "precision", label: "Link", render: (r) => <Chip v={r.precision} /> }]} />} />
          </Card>
          <Card title="Forward — where did it go?">
            <WithTable label="Forward genealogy" diagram={<GenealogyGraph direction="forward" root={fwd.data.lot} nodes={fwd.data.reached} />} table={
              <Table rows={fwd.data.reached} max={200} cols={[{ key: "depth", label: "Lvl" }, { key: "item_code", label: "Item" }, { key: "lot_number", label: "Lot / serial", render: (r) => <a href="#" onClick={(e) => { e.preventDefault(); setLotId(r.lot_id); }}>{r.lot_number}</a> },
                { key: "precision", label: "Link", render: (r) => <Chip v={r.precision} /> }, { key: "quality_status", label: "Quality", render: (r) => <Chip v={r.quality_status} /> },
                { key: "where", label: "Where now", render: (r) => r.shipments.length ? r.shipments.map((x: any) => `${x.customer} (${x.shipment})`).join("; ") : r.locations.map((l: any) => l.bin).join(", ") || "consumed" }]} />} />
          </Card>
        </div>
      </>}
      <Card title="Audit trail (latest)">
        <Table rows={audit.data} cols={[{ key: "recorded_at", label: "When", render: (a) => dt(a.recorded_at) }, { key: "user", label: "Who" }, { key: "action", label: "Action" },
          { key: "entity_type", label: "Entity", render: (a) => `${a.entity_type} #${a.entity_id}` }, { key: "reason", label: "Reason", render: (a) => <span className="small">{a.reason}</span> }]} />
      </Card>
    </>
  );
}
