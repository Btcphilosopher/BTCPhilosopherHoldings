"use client";
import Link from "next/link";
import { Card, Chip, Table, PageHead } from "@/components/ui";
import { useApi } from "@/lib/hooks";
import { day, dt, num } from "@/lib/format";

export default function Production() {
  const orders = useApi<any[]>("/orders");
  const scrap = useApi<any[]>("/scrap");
  const subs = useApi<any[]>("/subcontract-shipments");
  return (
    <>
      <PageHead title="Production" sub="Draft · Planned · Released · In progress · Paused · Awaiting inspection · Completed · Closed · Cancelled"
                actions={<Link className="btn primary" href="/shopfloor">Open shop-floor terminal</Link>} />
      <Card title="Production orders">
        <Table rows={orders.data} cols={[
          { key: "number", label: "Order", render: (r) => <Link href={`/production/${r.id}`}><b>{r.number}</b></Link> },
          { key: "kind", label: "Kind", render: (r) => r.kind === "rework" ? <Chip tone="amber" label="rework" /> : r.kind },
          { key: "item_code", label: "Item" }, { key: "status", label: "Status", render: (r) => <Chip v={r.status} /> },
          { key: "bom_version", label: "BOM/Rtg", render: (r) => `v${r.bom_version ?? "–"} / v${r.routing_version}` },
          { key: "quantity_target", label: "Target", num: true, render: (r) => num(r.quantity_target) },
          { key: "quantity_start", label: "Start", num: true, render: (r) => num(r.quantity_start) },
          { key: "quantity_reported", label: "Reported", num: true, render: (r) => num(r.quantity_reported) },
          { key: "quantity_accepted", label: "Accepted", num: true, render: (r) => <b>{num(r.quantity_accepted)}</b> },
          { key: "quantity_nonconforming", label: "Noncon.", num: true, render: (r) => num(r.quantity_nonconforming) },
          { key: "quantity_scrapped", label: "Scrapped", num: true, render: (r) => num(r.quantity_scrapped) },
          { key: "due_date", label: "Due", render: (r) => day(r.due_date) },
          { key: "planned_end", label: "Est. finish", render: (r) => <>{dt(r.planned_end)} {r.schedule_feasible === false && <Chip tone="amber" label="constraint" />}</> },
        ]} />
      </Card>
      <div className="grid g2">
        <Card title="Scrap register">
          <Table rows={scrap.data} cols={[{ key: "number", label: "No." }, { key: "item_code", label: "Item" }, { key: "quantity", label: "Qty", num: true, render: (s) => `${num(s.quantity)} ${s.unit}` },
            { key: "kind", label: "Kind" }, { key: "reason_code", label: "Reason" }, { key: "recoverable", label: "Recoverable", render: (s) => s.recoverable ? `${num(s.recovered_quantity)} recovered` : "no" },
            { key: "status", label: "Status", render: (s) => <Chip v={s.status} /> }, { key: "cost_value", label: "Value £", num: true, render: (s) => num(s.cost_value) }]} />
        </Card>
        <Card title="Subcontract shipments">
          <Table rows={subs.data} cols={[{ key: "number", label: "No." }, { key: "status", label: "Status", render: (s) => <Chip v={s.status} /> },
            { key: "quantity_sent", label: "Sent", num: true, render: (s) => num(s.quantity_sent) }, { key: "quantity_returned", label: "Returned", num: true, render: (s) => num(s.quantity_returned) },
            { key: "quantity_lost", label: "Lost", num: true, render: (s) => num(s.quantity_lost) }, { key: "loss_explanation", label: "Loss explanation" },
            { key: "supplier_documents", label: "Supplier documents", render: (s) => (s.supplier_documents || []).map((d: any) => `${d.type}: ${d.ref}`).join("; ") }]} />
        </Card>
      </div>
    </>
  );
}
