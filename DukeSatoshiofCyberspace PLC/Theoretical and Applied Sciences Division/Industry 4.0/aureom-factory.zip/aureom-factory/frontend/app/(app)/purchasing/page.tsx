"use client";
import { useState } from "react";
import { Card, Chip, Table, PageHead, Tabs, Toast, Alert } from "@/components/ui";
import { useApi, useToast } from "@/lib/hooks";
import { api, can, getUser, newKey } from "@/lib/api";
import { day, num } from "@/lib/format";

export default function Purchasing() {
  const [tab, setTab] = useState("Purchase orders");
  const [poId, setPoId] = useState<number | null>(null);
  const pos = useApi<any[]>("/purchase-orders");
  const reqs = useApi<any[]>("/requisitions");
  const returns = useApi<any[]>(tab === "Supplier returns" ? "/supplier-returns" : null, [tab]);
  const invoices = useApi<any[]>(tab === "Invoices" ? "/invoices" : null, [tab]);
  const suppliers = useApi<any[]>("/suppliers");
  const po = useApi<any>(poId ? `/purchase-orders/${poId}` : null, [poId]);
  const toast = useToast();
  const user = getUser();
  const supName = (id: number) => suppliers.data?.find((s) => s.id === id)?.name || id;
  const act = async (fn: () => Promise<any>, ok: string) => { try { await fn(); toast.ok(ok); pos.reload(); reqs.reload(); po.reload(); } catch (e) { toast.fail(e); } };

  return (
    <>
      <PageHead title="Purchasing" sub="Requisition → approval → purchase order → acknowledgement → receipt → reconciliation. Ordered, received, accepted and invoiced quantities are kept separate." />
      <Tabs tabs={["Purchase orders", "Requisitions", "Supplier returns", "Invoices", "Suppliers"]} value={tab} onChange={setTab} />
      {tab === "Purchase orders" && <div className="grid g2" style={{ gridTemplateColumns: "minmax(0,1fr) minmax(0,1.3fr)" }}>
        <Card title="Purchase orders">
          <Table rows={pos.data} onRow={(r) => setPoId(r.po.id)} selected={(r) => r.po.id === poId} cols={[
            { key: "n", label: "PO", render: (r) => <b>{r.po.number}</b>, sort: (r) => r.po.number },
            { key: "s", label: "Supplier", render: (r) => r.supplier.name },
            { key: "st", label: "Status", render: (r) => <Chip v={r.po.status} /> },
            { key: "late", label: "", render: (r) => r.lines.some((l: any) => l.late) ? <Chip tone="amber" label="LATE" /> : null },
            { key: "sub", label: "Type", render: (r) => r.po.is_subcontract ? "subcontract" : "supply" },
          ]} />
        </Card>
        <Card title={po.data ? `${po.data.po.number} — ${po.data.supplier.name}` : "Order detail"} actions={po.data && <>
          {po.data.po.status === "draft" && can(user, "purchasing.approve") && <button className="btn primary" onClick={() => act(() => api(`/purchase-orders/${poId}/approve`, { body: { version: po.data.po.version } }), "Approved")}>Approve</button>}
          {po.data.po.status === "approved" && can(user, "purchasing.order") && <button className="btn" onClick={() => act(() => api(`/purchase-orders/${poId}/send`, { body: {} }), "Sent via simulated supplier adapter")}>Send</button>}
          {po.data.po.status === "sent" && can(user, "purchasing.order") && <button className="btn" onClick={() => { const ref = prompt("Supplier acknowledgement reference"); if (ref) act(() => api(`/purchase-orders/${poId}/acknowledge`, { body: { ack_ref: ref } }), "Acknowledged"); }}>Record acknowledgement</button>}
        </>}>
          {!po.data && <div className="muted">Select a purchase order.</div>}
          {po.data && <>
            <Table rows={po.data.lines} cols={[
              { key: "line_no", label: "Line" }, { key: "item_code", label: "Item" },
              { key: "price", label: "Price", num: true, render: (l) => `${num(l.unit_price, 4)} ${l.currency}/${l.unit}` },
              { key: "ordered", label: "Ordered", num: true, render: (l) => num(l.ordered) },
              { key: "received", label: "Received", num: true, render: (l) => num(l.received) },
              { key: "accepted", label: "Accepted", num: true, render: (l) => num(l.accepted) },
              { key: "rejected", label: "Rejected", num: true, render: (l) => num(l.rejected) },
              { key: "returned", label: "Returned", num: true, render: (l) => num(l.returned) },
              { key: "invoiced", label: "Invoiced", num: true, render: (l) => num(l.invoiced) },
              { key: "outstanding", label: "Outstanding", num: true, render: (l) => num(l.outstanding) },
              { key: "expected_delivery", label: "Due", render: (l) => <>{day(l.expected_delivery)} {l.late && <Chip tone="amber" label="late" />}</> },
              { key: "status", label: "Status", render: (l) => <Chip v={l.status} /> },
            ]} />
            {can(user, "purchasing.receive") && ["sent", "acknowledged", "partially_received"].includes(po.data.po.status) && <ReceiveForm po={po.data} onDone={() => { po.reload(); pos.reload(); }} toast={toast} />}
            <h3 style={{ marginTop: 14 }}>Receipts</h3>
            <Table rows={po.data.receipts} empty="No deliveries yet" cols={[{ key: "number", label: "Receipt" }, { key: "received_at", label: "Received", render: (r) => day(r.received_at) },
              { key: "delivery_note_ref", label: "Delivery note" }, { key: "late_days", label: "Days late", num: true },
              { key: "lines", label: "Lines", render: (r) => r.lines.map((l: any) => `${num(l.quantity)} ${l.unit}${Number(l.damaged_quantity) ? ` (${num(l.damaged_quantity)} damaged)` : ""} · lot ${l.supplier_lot || "?"} · ${l.inspection_status}${l.certificate_status === "missing" ? " · CERT MISSING" : ""}`).join("; ") }]} />
          </>}
        </Card>
      </div>}
      {tab === "Requisitions" && <Card title="Purchase requisitions">
        <Alert kind="info">MRP creates requisitions only when a planner accepts a proposal. Approval requires the purchasing manager; nobody approves their own request.</Alert>
        <Table rows={reqs.data} cols={[{ key: "number", label: "No." }, { key: "item_code", label: "Item" }, { key: "quantity", label: "Qty", num: true, render: (r) => `${num(r.quantity)} ${r.unit}` },
          { key: "needed_by", label: "Needed by", render: (r) => day(r.needed_by) }, { key: "source", label: "Source" }, { key: "status", label: "Status", render: (r) => <Chip v={r.status} /> },
          { key: "justification", label: "Justification", render: (r) => <span className="small">{(r.justification || "").slice(0, 120)}</span> },
          { key: "a", label: "", render: (r) => r.status === "submitted" && can(user, "purchasing.approve") ? <span className="row">
            <button className="btn sm primary" onClick={() => act(() => api(`/requisitions/${r.id}/decide`, { body: { approve: true } }), "Approved")}>Approve</button>
            <button className="btn sm danger" onClick={() => act(() => api(`/requisitions/${r.id}/decide`, { body: { approve: false, note: "Rejected" } }), "Rejected")}>Reject</button></span> : null }]} />
      </Card>}
      {tab === "Supplier returns" && <Card title="Supplier returns"><Table rows={returns.data} cols={[{ key: "number", label: "No." }, { key: "supplier_id", label: "Supplier", render: (r) => supName(r.supplier_id) },
        { key: "quantity", label: "Qty", num: true, render: (r) => num(r.quantity) }, { key: "reason", label: "Reason" }, { key: "rma_ref", label: "RMA" }, { key: "status", label: "Status", render: (r) => <Chip v={r.status} /> }]} /></Card>}
      {tab === "Invoices" && <Card title="Supplier invoices — three-way match"><Table rows={invoices.data} cols={[{ key: "invoice_number", label: "Invoice" }, { key: "supplier_id", label: "Supplier", render: (r) => supName(r.supplier_id) },
        { key: "invoice_date", label: "Date", render: (r) => day(r.invoice_date) }, { key: "status", label: "Match", render: (r) => <Chip v={r.status} /> },
        { key: "flags", label: "Flags", render: (r) => (r.match_result?.lines || []).flatMap((l: any) => l.flags).map((f: string, i: number) => <Alert key={i} kind="constraint">{f}</Alert>) }]} /></Card>}
      {tab === "Suppliers" && <Card title="Suppliers"><Table rows={suppliers.data} cols={[{ key: "code", label: "Code" }, { key: "name", label: "Name" }, { key: "currency", label: "Currency" },
        { key: "country", label: "Country" }, { key: "is_subcontractor", label: "Subcontractor", render: (s) => s.is_subcontractor ? "yes" : "" }, { key: "approved", label: "Approved", render: (s) => s.approved ? <Chip v="approved" /> : <Chip v="rejected" label="not approved" /> }]} /></Card>}
      <Toast msg={toast.msg} />
    </>
  );
}

function ReceiveForm({ po, onDone, toast }: { po: any; onDone: () => void; toast: ReturnType<typeof useToast> }) {
  const open = po.lines.filter((l: any) => Number(l.outstanding) > 0);
  const [line, setLine] = useState<number>(open[0]?.po_line_id);
  const [qty, setQty] = useState("");
  const [lotRef, setLot] = useState("");
  const [dmg, setDmg] = useState("0");
  const [dn, setDn] = useState("");
  const [key] = useState(newKey("gr"));
  if (!open.length) return null;
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api(`/purchase-orders/${po.po.id}/receipts`, { idempotencyKey: key, body: { delivery_note_ref: dn || null, lines: [{ po_line_id: line, quantity: qty, supplier_lot: lotRef || null, damaged_quantity: dmg || "0" }] } });
      toast.ok("Received into goods-in (awaiting inspection)"); onDone();
    } catch (er) { toast.fail(er); }
  };
  return (
    <form onSubmit={submit} className="card" style={{ background: "var(--mist)", marginTop: 12 }}>
      <h3>Record delivery</h3>
      <div className="row">
        <label className="f">Line<select value={line} onChange={(e) => setLine(Number(e.target.value))}>{open.map((l: any) => <option key={l.po_line_id} value={l.po_line_id}>{l.line_no} {l.item_code} ({num(l.outstanding)} {l.unit} outstanding)</option>)}</select></label>
        <label className="f">Quantity<input required inputMode="decimal" value={qty} onChange={(e) => setQty(e.target.value)} size={8} /></label>
        <label className="f">Damaged<input inputMode="decimal" value={dmg} onChange={(e) => setDmg(e.target.value)} size={6} /></label>
        <label className="f">Supplier lot<input value={lotRef} onChange={(e) => setLot(e.target.value)} /></label>
        <label className="f">Delivery note<input value={dn} onChange={(e) => setDn(e.target.value)} /></label>
        <button className="btn primary" style={{ alignSelf: "flex-end" }}>Receive</button>
      </div>
      <p className="small muted" style={{ marginBottom: 0 }}>Received stock goes to RCV-01 with status awaiting review; it cannot be allocated until quality releases it.</p>
    </form>
  );
}
