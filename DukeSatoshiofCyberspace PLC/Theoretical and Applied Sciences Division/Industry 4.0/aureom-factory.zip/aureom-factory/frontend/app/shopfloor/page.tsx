"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import Scanner, { ScanRecord } from "@/components/Scanner";
import { Chip } from "@/components/ui";
import { api, clearSession, getUser, Me, newKey } from "@/lib/api";
import { useLive } from "@/lib/hooks";
import { num } from "@/lib/format";

type Work = any;
type Pending = { client_entry_id: string; kind: "consumption" | "quantity" | "event" | "measurement"; payload: any; observed_at: string; label: string };
const QKEY = "aureom.offline";
const loadQ = (): Pending[] => { try { return JSON.parse(localStorage.getItem(QKEY) || "[]"); } catch { return []; } };
const saveQ = (q: Pending[]) => { try { localStorage.setItem(QKEY, JSON.stringify(q)); } catch { /* storage unavailable */ } };
const lineSide = (wc: string) => (wc === "SAW" ? "WIP-SAW" : wc === "CNC" ? "WIP-CNC" : "WIP-ASSY");
const isNetwork = (e: any) => e instanceof TypeError || e?.status === undefined;
const nowLocal = () => { const d = new Date(); d.setSeconds(0, 0); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16); };

export default function ShopFloor() {
  const router = useRouter();
  const [user, setUser] = useState<Me | null>(null);
  const [work, setWork] = useState<Work[] | null>(null);
  const [sel, setSel] = useState<Work | null>(null);
  const [queue, setQueue] = useState<Pending[]>([]);
  const [msg, setMsg] = useState<{ kind: "ok" | "err"; text: string } | null>(null);
  const { connected } = useLive();

  useEffect(() => { const u = getUser(); if (!u) router.replace("/login"); else setUser(u); setQueue(loadQ()); }, [router]);
  const loadWork = useCallback(async () => { try { setWork(await api("/shopfloor/work")); } catch (e: any) { setMsg({ kind: "err", text: e.message }); } }, []);
  useEffect(() => { if (user) loadWork(); }, [user, loadWork]);
  useEffect(() => { if (msg) { const t = setTimeout(() => setMsg(null), 7000); return () => clearTimeout(t); } }, [msg]);

  const enqueue = (p: Omit<Pending, "client_entry_id">) => {
    const q = [...loadQ(), { ...p, client_entry_id: newKey("off") }];
    saveQ(q); setQueue(q);
    setMsg({ kind: "err", text: "No connection — saved on this device as PENDING. It is not recorded until synced and reconciled by a supervisor." });
  };
  const sync = async () => {
    const q = loadQ();
    if (!q.length) return;
    try {
      await api("/shopfloor/offline", { body: { device_id: "tablet-" + (navigator.userAgent.length % 997), entries: q.map(({ label, ...e }) => e) } });
      saveQ([]); setQueue([]);
      setMsg({ kind: "ok", text: `${q.length} entr${q.length === 1 ? "y" : "ies"} uploaded — awaiting supervisor reconciliation (still pending).` });
    } catch (e: any) { setMsg({ kind: "err", text: "Sync failed: " + (e.message || "offline") }); }
  };

  if (!user) return null;
  return (
    <div className="sf">
      <header>
        <div className="row"><img src="/aureom-mark.svg" alt="" width={34} height={34} /><div><b style={{ letterSpacing: ".16em" }}>AUREOM</b> <span className="muted">Shop floor</span></div></div>
        <div className="row">
          <span className={"live" + (connected ? " on" : "")} style={{ color: "#c9d3ea" }}><i />{connected ? "Online" : "No live link"}</span>
          {queue.length > 0 && <button className="btn warn" onClick={sync}>Sync {queue.length} pending</button>}
          <span>{user.full_name}</span>
          <Link className="btn" href="/">Office view</Link>
          <button className="btn" onClick={() => { clearSession(); router.replace("/login"); }}>Sign out</button>
        </div>
      </header>
      <main>
        {msg && <div className={msg.kind === "ok" ? "tile" : "pending"} role="status" style={{ marginBottom: 12 }}>{msg.text}</div>}
        {queue.length > 0 && <div className="pending" style={{ marginBottom: 12 }}>
          <b>Pending on this device (not recorded):</b>
          <ul style={{ margin: "6px 0 0" }}>{queue.map((q) => <li key={q.client_entry_id}>{q.label} — observed {new Date(q.observed_at).toLocaleString("en-GB")}</li>)}</ul>
          <div className="small">Offline entries never reserve stock and are checked again when a supervisor reconciles them.</div>
        </div>}
        {!sel && <>
          <div className="spread" style={{ marginBottom: 12 }}><h1 style={{ color: "#fff" }}>Authorised work</h1><button className="btn big" onClick={loadWork}>Refresh</button></div>
          {!work && <div className="muted">Loading…</div>}
          {work && !work.length && <div className="tile">No released work is ready for you.</div>}
          <div className="work">
            {work?.map((w) => (
              <button key={w.operation_id} onClick={() => setSel(w)} disabled={!w.authorised} aria-label={`${w.order} operation ${w.seq} ${w.name}`}>
                <div className="spread"><b style={{ fontSize: 18 }}>{w.order}</b><Chip v={w.status} /></div>
                <div style={{ fontSize: 16, marginTop: 4 }}>Op {w.seq} · {w.name}</div>
                <div className="muted">{w.item_code} — {w.item_description}</div>
                <div className="muted small" style={{ marginTop: 6 }}>{w.work_centre} · {num(w.quantity_good)} / {num(w.quantity_start)} good {w.kind === "rework" && "· REWORK"}</div>
                {!w.authorised && <div className="small" style={{ color: "#ffb4ab", marginTop: 4 }}>Requires skill “{w.required_skill}”</div>}
              </button>
            ))}
          </div>
        </>}
        {sel && <Operation w={sel} back={() => { setSel(null); loadWork(); }} enqueue={enqueue} setMsg={setMsg} />}
      </main>
    </div>
  );
}

function Operation({ w, back, enqueue, setMsg }: { w: Work; back: () => void; enqueue: (p: Omit<Pending, "client_entry_id">) => void; setMsg: (m: any) => void }) {
  const [order, setOrder] = useState<any>(null);
  const [plans, setPlans] = useState<any[]>([]);
  const [insp, setInsp] = useState<any>(null);
  const [eq, setEq] = useState("");
  const [check, setCheck] = useState<Record<string, boolean>>({ guards_and_fixtures: true, tooling_ok: true, area_clear: true });
  const [ready, setReady] = useState<any>(null);
  const [scan, setScan] = useState<ScanRecord | null>(null);
  const [qty, setQty] = useState("");
  const [src, setSrc] = useState("scanned");
  const [observed, setObserved] = useState(nowLocal());
  const [good, setGood] = useState("");
  const [serials, setSerials] = useState("");
  const [defect, setDefect] = useState("");
  const [meas, setMeas] = useState({ characteristic: "", sample_ref: "", value: "", ok: "true", equipment_code: "" });

  const load = useCallback(async () => {
    const o = await api(`/orders/${w.order_id}`);
    setOrder(o);
    if (w.inspection_point) {
      const all = await api<any[]>("/inspection-plans");
      setPlans(all);
      const open = (await api<any[]>("/inspections?status=open")).find((i) => i.order_operation_id === w.operation_id);
      setInsp(open || null);
    }
  }, [w]);
  useEffect(() => { load().catch((e) => setMsg({ kind: "err", text: e.message })); }, [load, setMsg]);
  const op = order?.operations.find((o: any) => o.id === w.operation_id);
  const plan = useMemo(() => plans.find((p) => p.code === op?.inspection_plan_code), [plans, op]);
  const obsIso = () => new Date(observed).toISOString();

  const call = async (fn: () => Promise<any>, ok: string, offline?: Omit<Pending, "client_entry_id">) => {
    try { const r = await fn(); setMsg({ kind: "ok", text: ok }); await load(); return r; }
    catch (e: any) { if (offline && isNetwork(e)) enqueue(offline); else setMsg({ kind: "err", text: e.message }); }
  };
  const matLine = order?.materials.find((m: any) => scan?.record && m.item_code === scan.record.item_code);

  return (
    <>
      <div className="spread" style={{ marginBottom: 12 }}>
        <div><h1 style={{ color: "#fff" }}>{w.order} · Op {w.seq} {w.name}</h1><div className="muted">{w.item_code} — {w.item_description}</div></div>
        <button className="btn big" onClick={back}>← Work list</button>
      </div>
      <div className="grid g2">
        <div>
          <section className="tile"><h3>Approved instructions</h3>
            <p style={{ fontSize: 16, lineHeight: 1.5 }}>{w.instructions || "No instructions attached."}</p>
            <div className="small muted">From routing v{order?.routing_version} (frozen at release). Status: <Chip v={op?.status} /> · good {num(op?.quantity_good)} · scrap {num(op?.quantity_scrap)}</div>
          </section>
          <section className="tile"><h3>1 · Equipment readiness</h3>
            {w.required_equipment_kind ? <>
              <label className="f">Equipment ({w.required_equipment_kind})<input value={eq} onChange={(e) => setEq(e.target.value.replace(/^EQP:/i, ""))} placeholder="scan EQP: label or type e.g. BENCH-01" /></label>
              <div className="row" style={{ margin: "10px 0" }}>{Object.keys(check).map((k) => (
                <label key={k} className="row" style={{ fontSize: 15 }}><input type="checkbox" checked={check[k]} onChange={(e) => setCheck({ ...check, [k]: e.target.checked })} style={{ width: 22, height: 22 }} />{k.replace(/_/g, " ")}</label>))}</div>
              <button className="btn big" onClick={async () => setReady(await call(() => api(`/operations/${w.operation_id}/check-equipment`, { body: { equipment_code: eq, checklist: check, observed_at: obsIso() } }), "Readiness recorded"))}>Check equipment</button>
              {ready && <div style={{ marginTop: 8 }}>{ready.ready ? <Chip v="accepted" label="READY" /> : <><Chip v="rejected" label="NOT READY" /> {ready.issues.join("; ")}</>}</div>}
            </> : <div className="muted">No equipment required.</div>}
          </section>
          <section className="tile"><h3>2 · Work</h3>
            <label className="f">Observed at (when it happened)<input type="datetime-local" value={observed} onChange={(e) => setObserved(e.target.value)} /></label>
            <p className="small muted">Recording time is added by the server. Each entry stores you as operator.</p>
            <div className="row">
              <button className="btn primary big" onClick={() => call(() => api(`/operations/${w.operation_id}/start`, { body: { equipment_code: eq || null, phase: "setup", observed_at: obsIso() } }), "Setup started")}>Start setup</button>
              <button className="btn primary big" onClick={() => call(() => api(`/operations/${w.operation_id}/${op?.status === "paused" ? "resume" : "start"}`, { body: { equipment_code: eq || null, phase: "run", observed_at: obsIso() } }), "Running")}>{op?.status === "paused" ? "Resume" : "Start run"}</button>
              <button className="btn warn big" onClick={() => { const r = prompt("Reason for pausing"); if (r) call(() => api(`/operations/${w.operation_id}/pause`, { body: { reason: r, observed_at: obsIso() } }), "Paused", { kind: "event", payload: { operation_id: w.operation_id, event: "pause", note: r }, observed_at: obsIso(), label: `Pause: ${r}` }); }}>Pause</button>
              <button className="btn ok big" onClick={() => call(() => api(`/operations/${w.operation_id}/complete`, { body: { observed_at: obsIso() } }), "Operation complete")}>Complete</button>
            </div>
          </section>
          <section className="tile"><h3>Report quantities and output</h3>
            <div className="row">
              <label className="f">Good quantity<input inputMode="decimal" value={good} onChange={(e) => setGood(e.target.value)} size={6} /></label>
              {!w.reports_output && <button className="btn big" style={{ alignSelf: "flex-end" }} onClick={() => call(() => api(`/operations/${w.operation_id}/quantities`, { body: { good, observed_at: obsIso() } }), "Quantity recorded",
                { kind: "quantity", payload: { operation_id: w.operation_id, good }, observed_at: obsIso(), label: `${good} good on op ${w.seq}` })}>Record good</button>}
              <button className="btn big" style={{ alignSelf: "flex-end" }} onClick={() => call(() => api(`/operations/${w.operation_id}/handover`, { body: { quantity: good, observed_at: obsIso() } }), "Handed to next operation")}>Hand over</button>
            </div>
            {w.reports_output && <>
              <label className="f" style={{ marginTop: 8 }}>Serial numbers / lot (one per line for serials)<textarea rows={3} value={serials} onChange={(e) => setSerials(e.target.value)} /></label>
              <button className="btn primary big" style={{ marginTop: 8 }} onClick={() => {
                const list = serials.split(/\s+/).filter(Boolean);
                const isSerial = order?.item_code === "FG-L100" || list.length > 1;
                call(() => api(`/orders/${w.order_id}/output`, { idempotencyKey: newKey("out"), body: { operation_id: w.operation_id, quantity: isSerial ? list.length : good, serials: isSerial ? list : null, lot_number: isSerial ? null : list[0] || null, to_bin: order?.item_code?.startsWith("FG") ? "FG-HOLD" : lineSide(w.work_centre), observed_at: obsIso() } }), "Output reported — awaiting quality review");
              }}>Report output</button>
              <p className="small muted">Output is held for quality review. Completing the order does not release it for sale.</p>
            </>}
          </section>
        </div>
        <div>
          <section className="tile"><h3>3 · Scan and record material use</h3>
            <Scanner big onResult={setScan} label="Scan lot label (LOT: / SER:)" />
            {scan?.record && <div style={{ marginTop: 10 }}>
              <div style={{ fontSize: 16 }}><b>{scan.record.item_code}</b> lot {scan.record.lot_number} <Chip v={scan.record.quality_status} /></div>
              {!scan.record.usable_for_production && <div className="pending" style={{ marginTop: 6 }}>This lot is {scan.record.quality_status?.toUpperCase()} — it cannot be used. Scanning identified it; it did not verify it.</div>}
              {scan.record.usable_for_production && !matLine && <div className="pending" style={{ marginTop: 6 }}>{scan.record.item_code} is not a material of this order.</div>}
              {matLine && scan.record.usable_for_production && <>
                <div className="small muted">Planned {num(matLine.required_quantity)} · issued {num(matLine.quantity_issued)} · consumed {num(matLine.quantity_consumed)} {matLine.unit}</div>
                <div className="row" style={{ marginTop: 8 }}>
                  <label className="f">Quantity used ({matLine.unit})<input inputMode="decimal" value={qty} onChange={(e) => setQty(e.target.value)} size={8} /></label>
                  <label className="f">Value source<select value={src} onChange={(e) => setSrc(e.target.value)}><option value="scanned">counted/scanned</option><option value="measured">measured (scale/length)</option><option value="manual">manual entry</option></select></label>
                  <button className="btn primary big" style={{ alignSelf: "flex-end" }} onClick={() => {
                    const payload = { material_id: matLine.id, lot_id: scan.record.lot_id, quantity: qty, from_bin: lineSide(w.work_centre), value_source: src, observed_at: obsIso(), operation_id: w.operation_id };
                    call(() => api(`/materials/${matLine.id}/consume`, { idempotencyKey: newKey("cons"), body: { lot_id: payload.lot_id, quantity: qty, from_bin: payload.from_bin, value_source: src, observed_at: payload.observed_at, operation_id: w.operation_id } }),
                      "Consumption recorded", { kind: "consumption", payload: { ...payload, from_bin: payload.from_bin }, observed_at: obsIso(), label: `Use ${qty} ${matLine.unit} ${scan.record.item_code} lot ${scan.record.lot_number}` });
                  }}>Record use</button>
                </div>
              </>}
            </div>}
          </section>
          {w.inspection_point && <section className="tile"><h3>Measurements {insp ? `(${insp.number}, n=${insp.sample_size})` : ""}</h3>
            {!insp && <div className="muted">No open inspection for this operation yet (opened when output is reported or by quality).</div>}
            {insp && plan && <>
              <div className="row">
                <label className="f">Characteristic<select value={meas.characteristic} onChange={(e) => setMeas({ ...meas, characteristic: e.target.value })}><option value="">choose…</option>{plan.characteristics.map((c: any) => <option key={c.name} value={c.name}>{c.name}{c.unit ? ` (${c.unit})` : ""}</option>)}</select></label>
                <label className="f">Sample / serial<input value={meas.sample_ref} onChange={(e) => setMeas({ ...meas, sample_ref: e.target.value })} size={14} /></label>
              </div>
              {plan.characteristics.find((c: any) => c.name === meas.characteristic)?.kind === "variable"
                ? <div className="row"><label className="f">Value<input inputMode="decimal" value={meas.value} onChange={(e) => setMeas({ ...meas, value: e.target.value })} size={8} /></label>
                    <label className="f">Gauge<input value={meas.equipment_code} onChange={(e) => setMeas({ ...meas, equipment_code: e.target.value.replace(/^EQP:/i, "") })} placeholder="e.g. PAT-01" size={10} /></label></div>
                : <label className="f">Result<select value={meas.ok} onChange={(e) => setMeas({ ...meas, ok: e.target.value })}><option value="true">Conforms</option><option value="false">Does not conform</option></select></label>}
              <button className="btn primary big" style={{ marginTop: 8 }} onClick={() => {
                const variable = plan.characteristics.find((c: any) => c.name === meas.characteristic)?.kind === "variable";
                const body = { characteristic: meas.characteristic, sample_ref: meas.sample_ref || null, observed_at: obsIso(),
                  ...(variable ? { numeric_value: meas.value, value_source: meas.equipment_code ? "measured" : "manual", equipment_code: meas.equipment_code || null } : { conforms: meas.ok === "true", value_source: "manual" }) };
                call(() => api(`/inspections/${insp.id}/results`, { body }), "Result recorded (limits checked by the server)",
                  { kind: "measurement", payload: { inspection_id: insp.id, ...body }, observed_at: obsIso(), label: `Measurement ${meas.characteristic} ${meas.value}` });
              }}>Record result</button>
              <p className="small muted">Measured = from a gauge (calibration checked); manual = typed reading; the server records which.</p>
            </>}
          </section>}
          <section className="tile"><h3>Raise a defect</h3>
            <label className="f">What is wrong?<input value={defect} onChange={(e) => setDefect(e.target.value)} /></label>
            <button className="btn warn big" style={{ marginTop: 8 }} disabled={!defect} onClick={() => call(() => api(`/operations/${w.operation_id}/defect`, { body: { description: defect, quantity: good || 1 } }), "Nonconformance raised — quality notified")}>Raise defect</button>
          </section>
        </div>
      </div>
    </>
  );
}
