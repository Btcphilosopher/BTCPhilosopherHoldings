#!/usr/bin/env bash
# Back up the AUREOM FACTORY database and protected document store.
#   AUREOM_DB_URL=postgresql://user:pass@host:5432/aureom_factory BACKUP_DIR=./backups scripts/backup.sh
# Produces: aureom_<UTC timestamp>.dump (pg_dump custom format), aureom_<ts>.objects.tar.gz (if the store
# exists) and aureom_<ts>.manifest.json (row counts + SHA-256 checksums) used to verify a restore.
set -euo pipefail
: "${AUREOM_DB_URL:?set AUREOM_DB_URL (postgresql://...)}"
BACKUP_DIR="${BACKUP_DIR:-./backups}"
STORE="${AUREOM_STORAGE_PATH:-./var/objects}"
TS="$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$BACKUP_DIR"
DUMP="$BACKUP_DIR/aureom_${TS}.dump"
pg_dump --format=custom --no-owner --no-privileges --file="$DUMP" "$AUREOM_DB_URL"
OBJ=""
if [ -d "$STORE" ]; then
  OBJ="$BACKUP_DIR/aureom_${TS}.objects.tar.gz"
  tar -czf "$OBJ" -C "$STORE" .
fi
COUNTS=$(psql "$AUREOM_DB_URL" -At -c "SELECT json_object_agg(t, n) FROM (
  SELECT 'items' t, count(*) n FROM items UNION ALL SELECT 'lots', count(*) FROM lots
  UNION ALL SELECT 'stock_movements', count(*) FROM stock_movements UNION ALL SELECT 'genealogy_edges', count(*) FROM genealogy_edges
  UNION ALL SELECT 'audit_log', count(*) FROM audit_log UNION ALL SELECT 'inspection_results', count(*) FROM inspection_results) x")
sha() { sha256sum "$1" | cut -d' ' -f1; }
cat > "$BACKUP_DIR/aureom_${TS}.manifest.json" <<JSON
{"created_utc": "$TS", "dump": "$(basename "$DUMP")", "dump_sha256": "$(sha "$DUMP")",
 "objects": "$( [ -n "$OBJ" ] && basename "$OBJ" )", "objects_sha256": "$( [ -n "$OBJ" ] && sha "$OBJ" )",
 "row_counts": ${COUNTS:-null}}
JSON
echo "Backup written: $DUMP"
