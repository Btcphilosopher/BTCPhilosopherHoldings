#!/usr/bin/env bash
# Restore a backup made by backup.sh into AUREOM_DB_URL and verify it against the manifest.
#   AUREOM_DB_URL=postgresql://user:pass@host:5432/aureom_restore CREATE_DB=1 scripts/restore.sh backups/aureom_<ts>.dump
# CREATE_DB=1 drops and recreates the target database first (never point it at production by mistake).
set -euo pipefail
DUMP="${1:?usage: restore.sh <file.dump>}"
: "${AUREOM_DB_URL:?set AUREOM_DB_URL}"
MANIFEST="${DUMP%.dump}.manifest.json"
if [ -f "$MANIFEST" ]; then
  want=$(python3 -c "import json,sys;print(json.load(open(sys.argv[1]))['dump_sha256'])" "$MANIFEST")
  have=$(sha256sum "$DUMP" | cut -d' ' -f1)
  [ "$want" = "$have" ] || { echo "Checksum mismatch for $DUMP" >&2; exit 3; }
fi
if [ "${CREATE_DB:-0}" = "1" ]; then
  DBNAME="${AUREOM_DB_URL##*/}"; ADMIN_URL="${AUREOM_DB_URL%/*}/postgres"
  psql "$ADMIN_URL" -v ON_ERROR_STOP=1 -q -c "DROP DATABASE IF EXISTS \"$DBNAME\"" -c "CREATE DATABASE \"$DBNAME\""
fi
pg_restore --no-owner --no-privileges --exit-on-error --dbname="$AUREOM_DB_URL" "$DUMP"
OBJ="${DUMP%.dump}.objects.tar.gz"
if [ -f "$OBJ" ] && [ -n "${AUREOM_STORAGE_PATH:-}" ] && [ "${RESTORE_OBJECTS:-0}" = "1" ]; then
  mkdir -p "$AUREOM_STORAGE_PATH" && tar -xzf "$OBJ" -C "$AUREOM_STORAGE_PATH"
fi
if [ -f "$MANIFEST" ]; then
  python3 - "$MANIFEST" "$AUREOM_DB_URL" <<'PY'
import json, subprocess, sys
m = json.load(open(sys.argv[1]))
for table, n in (m.get("row_counts") or {}).items():
    got = int(subprocess.check_output(["psql", sys.argv[2], "-At", "-c", f"SELECT count(*) FROM {table}"]).strip())
    if got != n:
        sys.exit(f"Row count mismatch for {table}: backup {n}, restored {got}")
print("Restore verified against manifest:", m["row_counts"])
PY
fi
