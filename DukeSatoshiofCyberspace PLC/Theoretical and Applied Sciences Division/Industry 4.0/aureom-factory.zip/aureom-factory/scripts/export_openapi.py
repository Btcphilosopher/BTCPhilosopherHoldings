#!/usr/bin/env python3
"""Write the API's OpenAPI document to docs/openapi.json.

    backend/.venv-or-env/bin/python scripts/export_openapi.py [output-path]

Importing the app needs no database connection (the WebSocket LISTEN thread is disabled)."""
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
os.environ.setdefault("AUREOM_DISABLE_LISTENER", "1")

from app.main import app  # noqa: E402

out = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "docs" / "openapi.json"
spec = app.openapi()
out.write_text(json.dumps(spec, indent=2, ensure_ascii=False) + "\n")
print(f"wrote {out} ({len(spec['paths'])} paths)")
