"""Append-only enforcement for journals and records of fact.

UPDATE and DELETE are rejected at database level for the stock-movement journal, audit log,
inspection results, lot status history, operation events and genealogy edges. Corrections are
always new rows (linked reversals, superseding results).

Revision ID: 0002_append_only
Revises: 0001_initial
"""
from alembic import op

revision = "0002_append_only"
down_revision = "0001_initial"
branch_labels = None
depends_on = None

TABLES = ("stock_movements", "audit_log", "inspection_results", "lot_status_history", "operation_events", "genealogy_edges")


def upgrade():
    op.execute("""
    CREATE OR REPLACE FUNCTION aureom_reject_change() RETURNS trigger AS $$
    BEGIN
      RAISE EXCEPTION 'table % is append-only; % is not permitted (post a correcting entry instead)', TG_TABLE_NAME, TG_OP
        USING ERRCODE = 'restrict_violation';
    END; $$ LANGUAGE plpgsql;
    """)
    for t in TABLES:
        op.execute(f"""
        CREATE TRIGGER {t}_append_only BEFORE UPDATE OR DELETE ON {t}
        FOR EACH ROW EXECUTE FUNCTION aureom_reject_change();
        CREATE TRIGGER {t}_no_truncate BEFORE TRUNCATE ON {t}
        FOR EACH STATEMENT EXECUTE FUNCTION aureom_reject_change();
        """)


def downgrade():
    for t in TABLES:
        op.execute(f"DROP TRIGGER IF EXISTS {t}_append_only ON {t}; DROP TRIGGER IF EXISTS {t}_no_truncate ON {t};")
    op.execute("DROP FUNCTION IF EXISTS aureom_reject_change()")
