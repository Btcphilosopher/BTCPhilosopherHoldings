#!/bin/sh
# api    : apply migrations, then serve the API
# worker : run the background worker (does NOT migrate)
# other  : run the given command (e.g. python -m app.demo.run --reset)
set -e
case "$1" in
  api)
    alembic upgrade head
    exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --proxy-headers
    ;;
  worker)
    exec python -m app.workers.worker
    ;;
  *)
    exec "$@"
    ;;
esac
