from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter
from sqlalchemy import select

from ...api_deps import Body, CtxDep
from ...core.context import row_dict
from ..inventory.models import Lot
from ..registry.models import Item
from .models import CorrectiveAction, Inspection, InspectionPlan, Nonconformance, SamplingPlan
from .service import (
    add_corrective_action, close_ncr, correct_result, decide, disposition_ncr, inspection_detail, open_inspection, raise_ncr,
    record_result,
)

router = APIRouter(prefix="/api", tags=["quality"])


class OpenInspectionBody(Body):
    stage: Literal["incoming", "in_process", "final", "return", "rework"]
    item_id: int
    lot_ids: list[int]
    plan_code: str | None = None
    production_order_id: int | None = None


class ResultBody(Body):
    characteristic: str
    numeric_value: Decimal | None = None
    text_value: str | None = None
    conforms: bool | None = None
    sample_ref: str | None = None
    value_source: Literal["measured", "manual", "calculated"] = "manual"
    equipment_code: str | None = None
    observed_at: datetime | None = None


class CorrectBody(Body):
    reason: str
    numeric_value: Decimal | None = None
    text_value: str | None = None
    conforms: bool | None = None


class DecisionBody(Body):
    decision: Literal["accepted", "rejected", "quarantined"]
    note: str


class NcrBody(Body):
    source: str
    item_id: int
    lot_ids: list[int]
    quantity: Decimal
    description: str
    severity: Literal["minor", "major", "critical"] = "major"


class DispositionBody(Body):
    disposition: Literal["use_as_is", "rework", "scrap", "return_to_supplier"]
    note: str


class CapaBody(Body):
    problem: str
    action: str
    owner_user_id: int
    due_date: date | None = None
    root_cause: str | None = None


class NoteBody(Body):
    note: str


@router.get("/inspection-plans")
def plans(ctx: CtxDep):
    ctx.require("quality.read")
    return [{**row_dict(p), "item_code": ctx.db.get(Item, p.item_id).item_code,
             "sampling": row_dict(ctx.db.get(SamplingPlan, p.sampling_plan_id))}
            for p in ctx.db.execute(select(InspectionPlan).order_by(InspectionPlan.code)).scalars()]


@router.get("/inspections")
def inspections(ctx: CtxDep, status: str | None = None, stage: str | None = None):
    ctx.require("quality.read")
    stmt = select(Inspection).order_by(Inspection.id.desc())
    if status:
        stmt = stmt.where(Inspection.status == status)
    if stage:
        stmt = stmt.where(Inspection.stage == stage)
    out = []
    for i in ctx.db.execute(stmt).scalars():
        out.append({**row_dict(i), "item_code": ctx.db.get(Item, i.item_id).item_code,
                    "lots": [ctx.db.get(Lot, l).lot_number for l in i.lot_ids[:5]], "lot_count": len(i.lot_ids)})
    return out


@router.get("/inspections/{iid}")
def get_inspection(iid: int, ctx: CtxDep):
    ctx.require("quality.read")
    return inspection_detail(ctx.db, ctx.get(Inspection, iid))


@router.post("/inspections", status_code=201)
def post_inspection(body: OpenInspectionBody, ctx: CtxDep):
    ctx.require("quality.record")
    plan = ctx.db.execute(select(InspectionPlan).where(InspectionPlan.code == body.plan_code)).scalar_one_or_none() if body.plan_code else None
    lots = [ctx.get(Lot, l) for l in body.lot_ids]
    insp = open_inspection(ctx, body.stage, ctx.get(Item, body.item_id), lots, plan=plan,
                           production_order_id=body.production_order_id)
    return inspection_detail(ctx.db, insp)


@router.post("/inspections/{iid}/results", status_code=201)
def post_result(iid: int, body: ResultBody, ctx: CtxDep):
    return row_dict(record_result(ctx, iid, **body.model_dump()))


@router.post("/inspection-results/{rid}/correct", status_code=201)
def post_correct(rid: int, body: CorrectBody, ctx: CtxDep):
    vals = {k: v for k, v in body.model_dump().items() if k != "reason" and v is not None}
    return row_dict(correct_result(ctx, rid, body.reason, **vals))


@router.post("/inspections/{iid}/decide")
def post_decide(iid: int, body: DecisionBody, ctx: CtxDep):
    return inspection_detail(ctx.db, decide(ctx, iid, body.decision, body.note))


@router.get("/ncrs")
def ncrs(ctx: CtxDep, status: str | None = None):
    ctx.require("quality.read")
    stmt = select(Nonconformance).order_by(Nonconformance.id.desc())
    if status:
        stmt = stmt.where(Nonconformance.status == status)
    return [{**row_dict(n), "item_code": ctx.db.get(Item, n.item_id).item_code,
             "lots": [ctx.db.get(Lot, l).lot_number for l in n.lot_ids[:10]]} for n in ctx.db.execute(stmt).scalars()]


@router.post("/ncrs", status_code=201)
def post_ncr(body: NcrBody, ctx: CtxDep):
    return row_dict(raise_ncr(ctx, **body.model_dump()))


@router.post("/ncrs/{nid}/disposition")
def post_disposition(nid: int, body: DispositionBody, ctx: CtxDep):
    return row_dict(disposition_ncr(ctx, nid, body.disposition, body.note))


@router.post("/ncrs/{nid}/close")
def post_close(nid: int, body: NoteBody, ctx: CtxDep):
    return row_dict(close_ncr(ctx, nid, body.note))


@router.post("/ncrs/{nid}/corrective-actions", status_code=201)
def post_capa(nid: int, body: CapaBody, ctx: CtxDep):
    return row_dict(add_corrective_action(ctx, nid, **body.model_dump()))


@router.get("/corrective-actions")
def capas(ctx: CtxDep):
    ctx.require("quality.read")
    return [row_dict(c) for c in ctx.db.execute(select(CorrectiveAction).order_by(CorrectiveAction.id.desc())).scalars()]


@router.get("/quality/release-queue")
def release_queue(ctx: CtxDep):
    """Lots physically present but not yet released."""
    ctx.require("quality.read")
    from ..inventory.service import lot_locations
    out = []
    for l in ctx.db.execute(select(Lot).where(Lot.quality_status.in_(("awaiting_review", "quarantined"))).order_by(Lot.id)).scalars():
        locs = lot_locations(ctx.db, l.id)
        if locs:
            out.append({**row_dict(l), "item_code": ctx.db.get(Item, l.item_id).item_code, "locations": locs})
    return out
