"""Equipment, maintenance, calibration, downtime and (read-only) machine observations."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import BigInteger, Boolean, Date, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from ...core.models import JSONType
from ...db import Base, Qty, TimestampMixin


class Equipment(Base, TimestampMixin):
    __tablename__ = "equipment"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    code: Mapped[str] = mapped_column(String(32), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    kind: Mapped[str] = mapped_column(String(32))  # bandsaw / cnc_mill / assembly_bench / safety_tester / caliper ...
    category: Mapped[str] = mapped_column(String(16), default="machine")  # machine / gauge / tool / station
    work_centre_id: Mapped[int | None] = mapped_column(ForeignKey("work_centres.id"))
    status: Mapped[str] = mapped_column(String(16), default="available")  # available / restricted / down / retired
    status_note: Mapped[str | None] = mapped_column(Text)
    calibration_required: Mapped[bool] = mapped_column(Boolean, default=False)
    calibration_due: Mapped[date | None] = mapped_column(Date)
    ideal_cycle_seconds: Mapped[Decimal | None] = mapped_column(Qty)  # for OEE performance
    calendar: Mapped[dict[str, Any] | None] = mapped_column(JSONType)  # overrides work centre calendar
    adapter_ref: Mapped[str | None] = mapped_column(String(64))


class ServiceSchedule(Base, TimestampMixin):
    __tablename__ = "service_schedules"
    id: Mapped[int] = mapped_column(primary_key=True)
    equipment_id: Mapped[int] = mapped_column(ForeignKey("equipment.id"))
    description: Mapped[str] = mapped_column(String(200))
    interval_days: Mapped[int] = mapped_column(Integer)
    duration_minutes: Mapped[int] = mapped_column(Integer, default=60)
    last_done: Mapped[date | None] = mapped_column(Date)
    next_due: Mapped[date | None] = mapped_column(Date)


class MaintenanceWorkOrder(Base, TimestampMixin):
    __tablename__ = "maintenance_work_orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    equipment_id: Mapped[int] = mapped_column(ForeignKey("equipment.id"))
    kind: Mapped[str] = mapped_column(String(16))  # preventive / corrective / calibration
    description: Mapped[str] = mapped_column(Text)
    defect: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16), default="open")  # open / in_progress / completed / cancelled
    planned_start: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    planned_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    actual_start: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    actual_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    work_done: Mapped[str | None] = mapped_column(Text)
    raised_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    completed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))


class DowntimeEvent(Base, TimestampMixin):
    __tablename__ = "downtime_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    equipment_id: Mapped[int] = mapped_column(ForeignKey("equipment.id"), index=True)
    start_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    end_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))  # NULL = still down
    planned: Mapped[bool] = mapped_column(Boolean, default=False)
    reason: Mapped[str] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(32), default="operator")  # operator / maintenance / machine_adapter
    work_order_id: Mapped[int | None] = mapped_column(ForeignKey("maintenance_work_orders.id"))
    recorded_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    confirmed: Mapped[bool] = mapped_column(Boolean, default=True)  # machine-reported events need confirmation


class CalibrationRecord(Base, TimestampMixin):
    __tablename__ = "calibration_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    equipment_id: Mapped[int] = mapped_column(ForeignKey("equipment.id"), index=True)
    certificate_ref: Mapped[str] = mapped_column(String(64))
    calibrated_on: Mapped[date] = mapped_column(Date)
    due_on: Mapped[date] = mapped_column(Date)
    result: Mapped[str] = mapped_column(String(16))  # pass / fail / adjusted
    provider: Mapped[str | None] = mapped_column(String(200))
    document_id: Mapped[int | None] = mapped_column(ForeignKey("documents.id"))
    recorded_by: Mapped[int] = mapped_column(ForeignKey("users.id"))


class AvailabilityRestriction(Base, TimestampMixin):
    __tablename__ = "availability_restrictions"
    id: Mapped[int] = mapped_column(primary_key=True)
    equipment_id: Mapped[int] = mapped_column(ForeignKey("equipment.id"))
    start_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    end_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    description: Mapped[str] = mapped_column(Text)
    blocks_scheduling: Mapped[bool] = mapped_column(Boolean, default=True)


class MachineObservation(Base):
    """Telemetry from the (read-only) machine adapter. Observations inform; they never override
    operator records or quality decisions."""

    __tablename__ = "machine_observations"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    equipment_id: Mapped[int] = mapped_column(ForeignKey("equipment.id"), index=True)
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    state: Mapped[str] = mapped_column(String(16))  # running / idle / down / offline
    cycle_count: Mapped[int | None] = mapped_column(Integer)
    spindle_hours: Mapped[Decimal | None] = mapped_column(Qty)
    alarm_code: Mapped[str | None] = mapped_column(String(32))
    source: Mapped[str] = mapped_column(String(64))
    raw: Mapped[dict | None] = mapped_column(JSONType)
