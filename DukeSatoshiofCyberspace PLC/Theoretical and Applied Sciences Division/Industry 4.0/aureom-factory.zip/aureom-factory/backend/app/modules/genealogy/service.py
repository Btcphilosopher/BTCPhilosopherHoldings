"""Traceability queries over the genealogy graph.

Precision rules (never upgraded, only degraded along a path):
* exact        – direct record (scan at output, split, merge, single-lot subcontract return)
* order_level  – the lot went into an order; any output of that order MAY contain it, unless the
                 output has exact records for that component item that name other lots
* unknown      – provenance is incomplete (lot.traceability != complete)
"""
from __future__ import annotations

from collections import defaultdict, deque
from decimal import Decimal

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ...core.numbers import D, ZERO
from ..dispatch.models import Customer, Shipment, ShipmentLine
from ..inventory.models import Bin, Lot, StockBalance
from ..inventory.service import lot_locations
from ..purchasing.models import Supplier
from ..registry.models import Item
from .models import GenealogyEdge

RANK = {"exact": 0, "order_level": 1, "unknown": 2}
LABEL = {"exact": "confirmed", "order_level": "possible (order-level association)", "unknown": "unknown — history incomplete"}
PRODUCE = ("produced_by_order", "rework_output", "subcontract_output")
CONSUME = ("consumed_by_order", "rework_input", "subcontract_input")


def worst(a: str, b: str) -> str:
    return a if RANK[a] >= RANK[b] else b


def _lot_info(db: Session, lot: Lot) -> dict:
    item = db.get(Item, lot.item_id)
    sup = db.get(Supplier, lot.supplier_id) if lot.supplier_id else None
    return {
        "lot_id": lot.id, "lot_number": lot.lot_number, "item_code": item.item_code, "item_type": item.item_type,
        "description": item.description, "is_serial": lot.is_serial, "quality_status": lot.quality_status,
        "origin": lot.origin, "supplier": sup.name if sup else None, "supplier_lot": lot.supplier_lot,
        "traceability": lot.traceability, "traceability_note": lot.traceability_note,
        "production_order_id": lot.production_order_id, "batch_ref": lot.batch_ref,
    }


def _exact_parents_by_item(db: Session, lot_id: int) -> dict[int, list[GenealogyEdge]]:
    out: dict[int, list[GenealogyEdge]] = defaultdict(list)
    for e in db.execute(select(GenealogyEdge).where(GenealogyEdge.child_lot_id == lot_id,
                                                    GenealogyEdge.parent_lot_id.is_not(None))).scalars():
        out[db.get(Lot, e.parent_lot_id).item_id].append(e)
    return out


def backward(db: Session, lot_id: int, max_depth: int = 12) -> dict:
    """Which input lots contributed to this lot/serial?"""
    root = db.get(Lot, lot_id)
    rows, seen = [], set()

    def visit(lot: Lot, depth: int, precision: str, path: list[str]):
        if depth > max_depth or lot.id in seen and depth > 0:
            return
        seen.add(lot.id)
        if lot.traceability != "complete":
            precision = worst(precision, "unknown")
        if depth > 0:
            rows.append({**_lot_info(db, lot), "depth": depth, "precision": precision, "label": LABEL[precision],
                         "path": path})
        exact = _exact_parents_by_item(db, lot.id)
        for iid, edges in exact.items():
            for e in edges:
                visit(db.get(Lot, e.parent_lot_id), depth + 1, worst(precision, e.precision),
                      path + [f"{e.relation}:{db.get(Lot, e.parent_lot_id).lot_number}"])
        for pe in db.execute(select(GenealogyEdge).where(GenealogyEdge.child_lot_id == lot.id,
                                                         GenealogyEdge.relation.in_(PRODUCE))).scalars():
            order_id = pe.parent_order_id
            for ce in db.execute(select(GenealogyEdge).where(GenealogyEdge.child_order_id == order_id,
                                                             GenealogyEdge.relation.in_(CONSUME))).scalars():
                if ce.parent_lot_id == lot.id or ce.relation == "rework_input":
                    continue  # rework preserves unit identity: other units in the same rework order are not inputs
                in_lot = db.get(Lot, ce.parent_lot_id)
                if in_lot.item_id in exact:
                    continue  # exact records exist for this component; they take precedence
                visit(in_lot, depth + 1, worst(precision, "order_level"), path + [f"order {order_id}:{in_lot.lot_number}"])

    visit(root, 0, "exact", [])
    # collapse duplicates keeping best precision
    best: dict[int, dict] = {}
    for r in rows:
        if r["lot_id"] not in best or RANK[r["precision"]] < RANK[best[r["lot_id"]]["precision"]]:
            best[r["lot_id"]] = r
    return {"lot": _lot_info(db, root), "contributors": sorted(best.values(), key=lambda r: (r["depth"], r["item_code"])),
            "note": "‘possible’ means the input was consumed by the producing order without a unit-level record."}


def forward(db: Session, lot_id: int, max_depth: int = 12) -> dict:
    """Where did this lot go? Finished lots/serials, stock, WIP and shipments."""
    root = db.get(Lot, lot_id)
    reached: dict[int, dict] = {}
    queue = deque([(root, "exact" if root.traceability == "complete" else "unknown", 0, [root.lot_number])])
    while queue:
        lot, prec, depth, path = queue.popleft()
        if depth > max_depth:
            continue
        children: list[tuple[Lot, str, str]] = []
        for e in db.execute(select(GenealogyEdge).where(GenealogyEdge.parent_lot_id == lot.id,
                                                        GenealogyEdge.child_lot_id.is_not(None))).scalars():
            children.append((db.get(Lot, e.child_lot_id), e.precision, e.relation))
        for ce in db.execute(select(GenealogyEdge).where(GenealogyEdge.parent_lot_id == lot.id,
                                                         GenealogyEdge.relation.in_(CONSUME))).scalars():
            if ce.relation == "rework_input":
                continue  # the unit comes back out of rework as itself; it does not flow into other units
            for pe in db.execute(select(GenealogyEdge).where(GenealogyEdge.parent_order_id == ce.child_order_id,
                                                             GenealogyEdge.relation.in_(PRODUCE))).scalars():
                out_lot = db.get(Lot, pe.child_lot_id)
                if out_lot.id == lot.id:
                    continue
                exact = _exact_parents_by_item(db, out_lot.id)
                if lot.item_id in exact:
                    continue  # covered (or excluded) by exact records
                children.append((out_lot, "order_level", "via_order"))
        for child, eprec, rel in children:
            p = worst(prec, eprec)
            if child.traceability != "complete":
                p = worst(p, "unknown")
            if child.id in reached and RANK[reached[child.id]["precision"]] <= RANK[p]:
                continue
            reached[child.id] = {**_lot_info(db, child), "depth": depth + 1, "precision": p, "label": LABEL[p],
                                 "relation": rel, "path": path + [child.lot_number]}
            queue.append((child, p, depth + 1, path + [child.lot_number]))
    lots = list(reached.values())
    for r in lots:
        r["locations"] = lot_locations(db, r["lot_id"])
        r["shipments"] = shipments_for_lot(db, r["lot_id"])
    root_loc = lot_locations(db, root.id)
    return {"lot": {**_lot_info(db, root), "locations": root_loc, "shipments": shipments_for_lot(db, root.id)},
            "reached": sorted(lots, key=lambda r: (r["depth"], r["item_code"], r["lot_number"])),
            "summary": summarise(lots)}


def shipments_for_lot(db: Session, lot_id: int) -> list[dict]:
    rows = db.execute(select(ShipmentLine, Shipment, Customer).join(Shipment, Shipment.id == ShipmentLine.shipment_id)
                      .join(Customer, Customer.id == Shipment.customer_id)
                      .where(ShipmentLine.lot_id == lot_id, Shipment.status.in_(("dispatched", "delivered")))).all()
    return [{"shipment": s.number, "shipment_id": s.id, "customer": c.name, "customer_id": c.id,
             "quantity": str(sl.quantity), "dispatched_at": s.dispatched_at.isoformat() if s.dispatched_at else None,
             "delivery_ref": s.delivery_ref, "status": s.status} for sl, s, c in rows]


def summarise(lots: list[dict]) -> dict:
    finished = [l for l in lots if l["item_type"] == "finished_product"]
    by_prec = defaultdict(int)
    for l in finished:
        by_prec[l["precision"]] += 1
    shipped = [l for l in finished if l["shipments"]]
    in_stock = [l for l in finished if any(loc["bin_kind"] in ("finished", "storage", "dispatch", "quarantine", "returns") for loc in l["locations"])]
    wip = [l for l in lots if any(loc["bin_kind"] == "wip" for loc in l["locations"])]
    customers = defaultdict(list)
    for l in shipped:
        for s in l["shipments"]:
            customers[s["customer"]].append({"lot": l["lot_number"], "shipment": s["shipment"], "precision": l["precision"]})
    return {
        "finished_units_reached": len(finished), "finished_by_precision": dict(by_prec),
        "finished_shipped": len(shipped), "finished_in_stock": len(in_stock), "lots_in_wip": len(wip),
        "customers": {k: v for k, v in customers.items()},
    }


def find_lots_by_supplier_lot(db: Session, supplier_lot: str) -> list[Lot]:
    return list(db.execute(select(Lot).where(Lot.supplier_lot == supplier_lot)).scalars())
