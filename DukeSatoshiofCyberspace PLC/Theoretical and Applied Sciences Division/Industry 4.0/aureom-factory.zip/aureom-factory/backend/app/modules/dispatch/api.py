from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from fastapi import APIRouter
from fastapi.responses import HTMLResponse
from pydantic import Field
from sqlalchemy import select

from ...api_deps import Body, CtxDep
from ...core.context import row_dict
from ..inventory.models import Lot
from ..registry.models import Item
from .models import Customer, CustomerOrder, CustomerReturn, Recall, Shipment
from .reports import lot_label, packing_list, recall_report, traceability_report
from .service import (
    allocate_line, confirm_delivery, create_customer_order, create_shipment, dispatch_shipment, open_recall,
    order_line_status, pack, pick, receive_customer_return, recall_findings, shipment_detail,
)

router = APIRouter(prefix="/api", tags=["dispatch"])


class COLine(Body):
    item_id: int
    quantity: Decimal = Field(gt=0)
    unit_price: Decimal | None = None
    currency: str = "GBP"


class COBody(Body):
    customer_id: int
    lines: list[COLine]
    required_date: date | None = None
    customer_reference: str | None = None


class AllocateBody(Body):
    quantity: Decimal | None = None


class ShipLine(Body):
    order_line_id: int
    quantity: Decimal = Field(gt=0)


class ShipmentBody(Body):
    customer_order_id: int
    lines: list[ShipLine]


class PickBody(Body):
    lot_ids: list[int]
    to_bin: str = "DSP-01"


class Package(Body):
    ref: str
    lot_ids: list[int]
    weight_kg: Decimal | None = None


class PackBody(Body):
    packages: list[Package]


class DispatchBody(Body):
    carrier: str
    tracking_ref: str
    dispatched_at: datetime | None = None


class DeliverBody(Body):
    delivery_ref: str
    delivered_at: datetime | None = None


class ReturnBody(Body):
    customer_id: int
    lot_id: int
    quantity: Decimal = Field(gt=0)
    reason: str
    shipment_line_id: int | None = None
    recall_id: int | None = None


class RecallBody(Body):
    title: str
    description: str
    trigger_lot_ids: list[int]
    hold_stock: bool = True


@router.get("/customers")
def customers(ctx: CtxDep):
    ctx.require("dispatch.read")
    return [row_dict(c) for c in ctx.db.execute(select(Customer).order_by(Customer.code)).scalars()]


@router.get("/customer-orders")
def cos(ctx: CtxDep):
    ctx.require("dispatch.read")
    return [{**row_dict(c), "customer": ctx.db.get(Customer, c.customer_id).name, "lines": order_line_status(ctx.db, c)}
            for c in ctx.db.execute(select(CustomerOrder).order_by(CustomerOrder.id.desc())).scalars()]


@router.post("/customer-orders", status_code=201)
def post_co(body: COBody, ctx: CtxDep):
    co = create_customer_order(ctx, ctx.site_id, body.customer_id, [l.model_dump() for l in body.lines],
                               required_date=body.required_date, customer_reference=body.customer_reference)
    return {**row_dict(co), "lines": order_line_status(ctx.db, co)}


@router.get("/customer-orders/{cid}")
def get_co(cid: int, ctx: CtxDep):
    ctx.require("dispatch.read")
    co = ctx.get(CustomerOrder, cid)
    ships = ctx.db.execute(select(Shipment).where(Shipment.customer_order_id == cid)).scalars()
    return {**row_dict(co), "customer": ctx.db.get(Customer, co.customer_id).name, "lines": order_line_status(ctx.db, co),
            "shipments": [shipment_detail(ctx.db, s) for s in ships]}


@router.post("/customer-order-lines/{lid}/allocate")
def post_alloc(lid: int, body: AllocateBody, ctx: CtxDep):
    return [row_dict(r) for r in allocate_line(ctx, lid, body.quantity)]


@router.get("/shipments")
def shipments(ctx: CtxDep):
    ctx.require("dispatch.read")
    return [shipment_detail(ctx.db, s) for s in ctx.db.execute(select(Shipment).order_by(Shipment.id.desc())).scalars()]


@router.post("/shipments", status_code=201)
def post_shipment(body: ShipmentBody, ctx: CtxDep):
    return shipment_detail(ctx.db, create_shipment(ctx, body.customer_order_id, [l.model_dump() for l in body.lines]))


@router.get("/shipments/{sid}")
def get_shipment(sid: int, ctx: CtxDep):
    ctx.require("dispatch.read")
    return shipment_detail(ctx.db, ctx.get(Shipment, sid))


@router.post("/shipments/{sid}/pick")
def post_pick(sid: int, body: PickBody, ctx: CtxDep):
    return shipment_detail(ctx.db, pick(ctx, sid, body.lot_ids, to_bin_code=body.to_bin))


@router.post("/shipments/{sid}/pack")
def post_pack(sid: int, body: PackBody, ctx: CtxDep):
    return shipment_detail(ctx.db, pack(ctx, sid, [p.model_dump() for p in body.packages]))


@router.post("/shipments/{sid}/dispatch")
def post_dispatch(sid: int, body: DispatchBody, ctx: CtxDep):
    return shipment_detail(ctx.db, dispatch_shipment(ctx, sid, body.carrier, body.tracking_ref, body.dispatched_at))


@router.post("/shipments/{sid}/deliver")
def post_deliver(sid: int, body: DeliverBody, ctx: CtxDep):
    return shipment_detail(ctx.db, confirm_delivery(ctx, sid, body.delivery_ref, body.delivered_at))


@router.get("/customer-returns")
def returns(ctx: CtxDep):
    ctx.require("dispatch.read")
    return [row_dict(r) for r in ctx.db.execute(select(CustomerReturn).order_by(CustomerReturn.id.desc())).scalars()]


@router.post("/customer-returns", status_code=201)
def post_return(body: ReturnBody, ctx: CtxDep):
    return row_dict(receive_customer_return(ctx, body.customer_id, body.lot_id, body.quantity, body.reason,
                                            shipment_line_id=body.shipment_line_id, recall_id=body.recall_id))


@router.get("/recalls")
def recalls(ctx: CtxDep):
    ctx.require("dispatch.read")
    return [row_dict(r) for r in ctx.db.execute(select(Recall).order_by(Recall.id.desc())).scalars()]


@router.post("/recalls", status_code=201)
def post_recall(body: RecallBody, ctx: CtxDep):
    rc = open_recall(ctx, body.title, body.description, body.trigger_lot_ids, hold_stock=body.hold_stock)
    return {**row_dict(rc), "items": len(rc.items)}


@router.get("/recalls/{rid}")
def get_recall(rid: int, ctx: CtxDep):
    ctx.require("dispatch.read")
    rc = ctx.get(Recall, rid)
    items = []
    for ri in rc.items:
        lot = ctx.db.get(Lot, ri.lot_id)
        items.append({**row_dict(ri), "lot_number": lot.lot_number, "item_code": ctx.db.get(Item, lot.item_id).item_code,
                      "customer": ctx.db.get(Customer, ri.customer_id).name if ri.customer_id else None,
                      "shipment": ctx.db.get(Shipment, ri.shipment_id).number if ri.shipment_id else None})
    return {**row_dict(rc), "items": items, "findings": rc.findings}


# ------------------------------------------------------------------ printable documents

@router.get("/reports/label/{lot_id}")
def label(lot_id: int, ctx: CtxDep, format: str = "json"):
    ctx.require("reports.read")
    lbl = lot_label(ctx.db, ctx.get(Lot, lot_id))
    return HTMLResponse(lbl["html"]) if format == "html" else lbl


@router.get("/reports/packing-list/{sid}", response_class=HTMLResponse)
def packing(sid: int, ctx: CtxDep):
    ctx.require("reports.read")
    return packing_list(ctx.db, ctx.get(Shipment, sid))


@router.get("/reports/traceability/{lot_id}", response_class=HTMLResponse)
def trace_report(lot_id: int, ctx: CtxDep):
    ctx.require("reports.read")
    ctx.get(Lot, lot_id)
    return traceability_report(ctx.db, lot_id)


@router.get("/reports/recall/{rid}", response_class=HTMLResponse)
def recall_html(rid: int, ctx: CtxDep):
    ctx.require("reports.read")
    return recall_report(ctx.db, ctx.get(Recall, rid))
