"""Customers, customer orders, shipments, customer returns and recalls."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ...core.models import JSONType
from ...db import Base, Money, Qty, TimestampMixin


class Customer(Base, TimestampMixin):
    __tablename__ = "customers"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(32), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    address: Mapped[str | None] = mapped_column(Text)
    country: Mapped[str | None] = mapped_column(String(2))
    contact_email: Mapped[str | None] = mapped_column(String(200))


class CustomerOrder(Base, TimestampMixin):
    __tablename__ = "customer_orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"))
    customer_reference: Mapped[str | None] = mapped_column(String(64))
    required_date: Mapped[date | None] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(24), default="open")  # open / partially_shipped / shipped / closed / cancelled
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    version: Mapped[int] = mapped_column(Integer, default=1)
    __mapper_args__ = {"version_id_col": version}
    lines: Mapped[list["CustomerOrderLine"]] = relationship(back_populates="order", cascade="all, delete-orphan")


class CustomerOrderLine(Base):
    """Produced, quality-released, picked, dispatched and delivered quantities are distinct."""

    __tablename__ = "customer_order_lines"
    __table_args__ = (CheckConstraint("quantity_ordered > 0", name="qty"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("customer_orders.id", ondelete="CASCADE"))
    line_no: Mapped[int] = mapped_column(Integer)
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    quantity_ordered: Mapped[Decimal] = mapped_column(Qty)
    unit_price: Mapped[Decimal | None] = mapped_column(Money)
    currency: Mapped[str] = mapped_column(String(3), default="GBP")
    quantity_allocated: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_picked: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_packed: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_dispatched: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_delivered: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_returned: Mapped[Decimal] = mapped_column(Qty, default=0)
    order: Mapped[CustomerOrder] = relationship(back_populates="lines")


class Shipment(Base, TimestampMixin):
    __tablename__ = "shipments"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    customer_order_id: Mapped[int] = mapped_column(ForeignKey("customer_orders.id"))
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"))
    status: Mapped[str] = mapped_column(String(16), default="picking")  # picking / packed / dispatched / delivered
    carrier: Mapped[str | None] = mapped_column(String(100))
    tracking_ref: Mapped[str | None] = mapped_column(String(100))
    delivery_ref: Mapped[str | None] = mapped_column(String(100))  # proof of delivery reference
    packages: Mapped[list[dict[str, Any]]] = mapped_column(JSONType, default=list)
    dispatched_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    lines: Mapped[list["ShipmentLine"]] = relationship(back_populates="shipment", cascade="all, delete-orphan")


class ShipmentLine(Base):
    __tablename__ = "shipment_lines"
    id: Mapped[int] = mapped_column(primary_key=True)
    shipment_id: Mapped[int] = mapped_column(ForeignKey("shipments.id", ondelete="CASCADE"))
    order_line_id: Mapped[int] = mapped_column(ForeignKey("customer_order_lines.id"))
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"), index=True)
    quantity: Mapped[Decimal] = mapped_column(Qty)
    reservation_id: Mapped[int | None] = mapped_column(ForeignKey("reservations.id"))
    picked: Mapped[bool] = mapped_column(Boolean, default=False)
    package_ref: Mapped[str | None] = mapped_column(String(32))
    shipment: Mapped[Shipment] = relationship(back_populates="lines")


class CustomerReturn(Base, TimestampMixin):
    __tablename__ = "customer_returns"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"))
    shipment_line_id: Mapped[int | None] = mapped_column(ForeignKey("shipment_lines.id"))
    lot_id: Mapped[int] = mapped_column(ForeignKey("lots.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16), default="under_review")  # under_review / dispositioned
    nonconformance_id: Mapped[int | None] = mapped_column(ForeignKey("nonconformances.id"))
    recall_id: Mapped[int | None] = mapped_column(ForeignKey("recalls.id"))
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    received_by: Mapped[int] = mapped_column(ForeignKey("users.id"))


class Recall(Base, TimestampMixin):
    __tablename__ = "recalls"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    title: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text)
    trigger_lot_ids: Mapped[list[int]] = mapped_column(JSONType, default=list)
    status: Mapped[str] = mapped_column(String(16), default="investigating")  # investigating / active / closed
    scope_basis: Mapped[str] = mapped_column(String(32), default="confirmed_and_possible")
    findings: Mapped[dict[str, Any] | None] = mapped_column(JSONType)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    items: Mapped[list["RecallItem"]] = relationship(back_populates="recall", cascade="all, delete-orphan")


class RecallItem(Base):
    __tablename__ = "recall_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    recall_id: Mapped[int] = mapped_column(ForeignKey("recalls.id", ondelete="CASCADE"))
    lot_id: Mapped[int] = mapped_column(ForeignKey("lots.id"))
    precision: Mapped[str] = mapped_column(String(16))  # exact / order_level / unknown
    location_kind: Mapped[str] = mapped_column(String(24))  # in_stock / wip / at_subcontractor / shipped / consumed
    customer_id: Mapped[int | None] = mapped_column(ForeignKey("customers.id"))
    shipment_id: Mapped[int | None] = mapped_column(ForeignKey("shipments.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    action: Mapped[str] = mapped_column(String(32), default="pending")  # pending / quarantined / customer_notified / returned / cleared
    note: Mapped[str | None] = mapped_column(Text)
    recall: Mapped[Recall] = relationship(back_populates="items")
