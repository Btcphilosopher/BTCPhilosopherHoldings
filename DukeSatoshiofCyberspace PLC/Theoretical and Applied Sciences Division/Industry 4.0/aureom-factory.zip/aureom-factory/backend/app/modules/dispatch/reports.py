"""Demonstration labels (Code 128 SVG + ZPL text), packing lists and traceability reports (HTML)."""
from __future__ import annotations

import html
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..genealogy.service import backward, forward
from ..inventory.models import Lot
from ..registry.models import Item
from .models import Customer, CustomerOrder, Recall, Shipment

# Code 128 bar/space width patterns for values 0..106 (106 = stop).
_C128 = (
    "212222 222122 222221 121223 121322 131222 122213 122312 132212 221213 221312 231212 112232 122132 122231 113222 "
    "123122 123221 223211 221132 221231 213212 223112 312131 311222 321122 321221 312212 322112 322211 212123 212321 "
    "232121 111323 131123 131321 112313 132113 132311 211313 231113 231311 112133 112331 132131 113123 113321 133121 "
    "313121 211331 231131 213113 213311 213131 311123 311321 331121 312113 312311 332111 314111 221411 431111 111224 "
    "111422 121124 121421 141122 141221 112214 112412 122114 122411 142112 142211 241211 221114 413111 241112 134111 "
    "111242 121142 121241 114212 124112 124211 411212 421112 421211 212141 214121 412121 111143 111341 131141 114113 "
    "114311 411113 411311 113141 114131 311141 411131 211412 211214 211232 2331112"
).split()


def code128_values(text: str) -> list[int]:
    if any(not (32 <= ord(c) <= 126) for c in text):
        raise ValueError("Code 128-B supports printable ASCII only")
    vals = [104] + [ord(c) - 32 for c in text]
    checksum = (vals[0] + sum(i * v for i, v in enumerate(vals[1:], start=1))) % 103
    return vals + [checksum, 106]


def code128_svg(text: str, height: int = 60, module: float = 1.6, show_text: bool = True) -> str:
    x, bars = 10 * module, []
    for v in code128_values(text):
        for i, w in enumerate(_C128[v]):
            width = int(w) * module
            if i % 2 == 0:
                bars.append(f'<rect x="{x:.2f}" y="0" width="{width:.2f}" height="{height}"/>')
            x += width
    total = x + 10 * module
    label = f'<text x="{total / 2:.1f}" y="{height + 14}" font-family="monospace" font-size="12" text-anchor="middle">{html.escape(text)}</text>' if show_text else ""
    return (f'<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Barcode {html.escape(text)}" '
            f'viewBox="0 0 {total:.1f} {height + (18 if show_text else 0)}" width="{total:.0f}" height="{height + 18}">'
            f'<rect width="100%" height="100%" fill="#fff"/><g fill="#000">{"".join(bars)}</g>{label}</svg>')


_CSS = """body{font-family:Inter,Arial,sans-serif;color:#0b1730;margin:24px}h1{font-size:20px;margin:0 0 4px}
.sub{color:#56627a;font-size:12px;margin-bottom:16px}table{border-collapse:collapse;width:100%;font-size:12px}
th,td{border:1px solid #cfd6e3;padding:4px 6px;text-align:left}th{background:#eef2f7}.tag{display:inline-block;padding:1px 6px;border-radius:3px;font-size:11px}
.exact{background:#d9f3f7;color:#035e6e}.order_level{background:#fff1d6;color:#8a5300}.unknown{background:#fde2e2;color:#9b1c1c}
.demo{border:2px dashed #e8641b;padding:6px 10px;color:#9c3c05;font-size:11px;margin-bottom:12px}"""


def _page(title: str, body: str) -> str:
    return (f"<!doctype html><html lang='en-GB'><head><meta charset='utf-8'><title>{html.escape(title)}</title>"
            f"<style>{_CSS}</style></head><body><div class='demo'>AUREOM FACTORY — demonstration document generated "
            f"{datetime.now().strftime('%d %b %Y %H:%M')}. Synthetic data (Pennine Manufacturing Demonstrator).</div>{body}</body></html>")


def lot_label(db: Session, lot: Lot) -> dict:
    item = db.get(Item, lot.item_id)
    code = f"{'SER' if lot.is_serial else 'LOT'}:{item.item_code}|{lot.lot_number}"
    svg = code128_svg(code)
    zpl = (f"^XA^CF0,30^FO40,30^FD{item.item_code} rev {item.revision}^FS^CF0,22^FO40,70^FD{item.description[:40]}^FS"
           f"^FO40,105^FD{'Serial' if lot.is_serial else 'Lot'}: {lot.lot_number}^FS^FO40,135^FDStatus: {lot.quality_status.upper()}^FS"
           f"^BY2^FO40,170^BCN,80,Y,N,N^FD{code}^FS^XZ")
    body = (f"<h1>{html.escape(item.item_code)} — {html.escape(item.description)}</h1>"
            f"<div class='sub'>{'Serial' if lot.is_serial else 'Lot'} {html.escape(lot.lot_number)} · batch {html.escape(lot.batch_ref or '-')} · "
            f"quality status <b>{lot.quality_status.upper()}</b></div>{svg}"
            "<p style='font-size:11px'>Scanning this label identifies the unit. It does not certify conformity.</p>")
    return {"barcode_text": code, "svg": svg, "zpl": zpl, "html": _page(f"Label {lot.lot_number}", body)}


def packing_list(db: Session, sh: Shipment) -> str:
    cust = db.get(Customer, sh.customer_id)
    co = db.get(CustomerOrder, sh.customer_order_id)
    rows = []
    for l in sorted(sh.lines, key=lambda l: (l.package_ref or "", l.lot_id)):
        lot = db.get(Lot, l.lot_id)
        item = db.get(Item, l.item_id)
        rows.append(f"<tr><td>{html.escape(l.package_ref or '-')}</td><td>{item.item_code}</td><td>{html.escape(item.description)}</td>"
                    f"<td>{lot.lot_number}</td><td>{lot.batch_ref or ''}</td><td>{l.quantity.normalize()}</td></tr>")
    body = (f"<h1>Packing list {sh.number}</h1><div class='sub'>Customer: {html.escape(cust.name)} · Order {co.number}"
            f"{' / ' + html.escape(co.customer_reference) if co.customer_reference else ''} · Carrier {html.escape(sh.carrier or '-')} "
            f"{html.escape(sh.tracking_ref or '')} · Status {sh.status}</div>{code128_svg('SH:' + sh.number, 40)}"
            "<table><thead><tr><th>Package</th><th>Item</th><th>Description</th><th>Serial/Lot</th><th>Batch</th><th>Qty</th></tr></thead>"
            f"<tbody>{''.join(rows)}</tbody></table><p>Total units: {sum(l.quantity for l in sh.lines).normalize()}</p>")
    return _page(f"Packing list {sh.number}", body)


def traceability_report(db: Session, lot_id: int) -> str:
    lot = db.get(Lot, lot_id)
    item = db.get(Item, lot.item_id)
    b, f = backward(db, lot_id), forward(db, lot_id)

    def tag(p):
        return f"<span class='tag {p}'>{ {'exact': 'confirmed', 'order_level': 'possible', 'unknown': 'unknown'}[p]}</span>"

    back_rows = "".join(
        f"<tr><td>{r['depth']}</td><td>{r['item_code']}</td><td>{r['lot_number']}</td><td>{html.escape(r['supplier'] or '-')}</td>"
        f"<td>{html.escape(r['supplier_lot'] or '-')}</td><td>{tag(r['precision'])}</td><td>{html.escape(r['traceability_note'] or '')}</td></tr>"
        for r in b["contributors"])
    fwd_rows = "".join(
        f"<tr><td>{r['depth']}</td><td>{r['item_code']}</td><td>{r['lot_number']}</td><td>{r['quality_status']}</td><td>{tag(r['precision'])}</td>"
        f"<td>{', '.join(l['bin'] + ' ' + l['quantity'] for l in r['locations']) or '-'}</td>"
        f"<td>{', '.join(s['shipment'] + ' → ' + html.escape(s['customer']) for s in r['shipments']) or '-'}</td></tr>"
        for r in f["reached"])
    s = f["summary"]
    body = (f"<h1>Traceability report — {item.item_code} {lot.lot_number}</h1>"
            f"<div class='sub'>{html.escape(item.description)} · origin {lot.origin} · status {lot.quality_status} · "
            f"provenance {lot.traceability}</div>"
            f"<h2>Forward (where used / shipped)</h2><p>Finished units reached: {s['finished_units_reached']} "
            f"({', '.join(f'{k}: {v}' for k, v in s['finished_by_precision'].items()) or 'none'}); shipped: {s['finished_shipped']}; "
            f"in stock: {s['finished_in_stock']}; lots in WIP: {s['lots_in_wip']}</p>"
            "<table><thead><tr><th>Depth</th><th>Item</th><th>Lot/Serial</th><th>Quality</th><th>Link</th><th>Location</th><th>Shipments</th></tr></thead>"
            f"<tbody>{fwd_rows or '<tr><td colspan=7>No downstream use recorded</td></tr>'}</tbody></table>"
            "<h2>Backward (contributing inputs)</h2>"
            "<table><thead><tr><th>Depth</th><th>Item</th><th>Lot</th><th>Supplier</th><th>Supplier lot</th><th>Link</th><th>Notes</th></tr></thead>"
            f"<tbody>{back_rows or '<tr><td colspan=7>No inputs recorded</td></tr>'}</tbody></table>"
            "<p style='font-size:11px'>Confirmed = direct record; possible = consumed by the same production order without a unit-level "
            "record; unknown = provenance incomplete. Exact traceability is never inferred where records do not exist.</p>")
    return _page(f"Traceability {lot.lot_number}", body)


def recall_report(db: Session, rc: Recall) -> str:
    f = rc.findings or {}
    rows = []
    for ri in rc.items:
        lot = db.get(Lot, ri.lot_id)
        item = db.get(Item, lot.item_id)
        cust = db.get(Customer, ri.customer_id).name if ri.customer_id else ""
        sh = db.get(Shipment, ri.shipment_id).number if ri.shipment_id else ""
        rows.append(f"<tr><td>{item.item_code}</td><td>{lot.lot_number}</td><td><span class='tag {ri.precision}'>{ri.precision}</span></td>"
                    f"<td>{ri.location_kind}</td><td>{html.escape(cust)}</td><td>{sh}</td><td>{ri.quantity.normalize()}</td><td>{ri.action}</td></tr>")
    body = (f"<h1>Recall investigation {rc.number}: {html.escape(rc.title)}</h1><div class='sub'>{html.escape(rc.description)}</div>"
            f"<p>Finished units — confirmed: {f.get('finished_units', {}).get('confirmed', 0)}, possible: {f.get('finished_units', {}).get('possible', 0)}, "
            f"unknown: {f.get('finished_units', {}).get('unknown', 0)}</p><p>{html.escape(f.get('statement', ''))}</p>"
            "<table><thead><tr><th>Item</th><th>Lot/Serial</th><th>Link</th><th>Where</th><th>Customer</th><th>Shipment</th><th>Qty</th><th>Action</th></tr></thead>"
            f"<tbody>{''.join(rows)}</tbody></table>")
    return _page(f"Recall {rc.number}", body)
