from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from typing import Literal

from fastapi import APIRouter
from sqlalchemy import select

from ...adapters.registry import adapters
from ...api_deps import Body, CtxDep
from ...core.context import row_dict, utcnow
from .models import (
    AvailabilityRestriction, CalibrationRecord, DowntimeEvent, Equipment, MachineObservation, MaintenanceWorkOrder,
    ServiceSchedule,
)
from .service import (
    complete_work_order, confirm_machine_downtime, create_work_order, end_downtime, ingest_observation, oee,
    record_calibration, record_downtime,
)

router = APIRouter(prefix="/api", tags=["maintenance"])


class DowntimeBody(Body):
    start_at: datetime
    reason: str
    planned: bool = False
    end_at: datetime | None = None


class EndBody(Body):
    end_at: datetime
    note: str | None = None


class ConfirmBody(Body):
    confirm: bool
    note: str


class WorkOrderBody(Body):
    kind: Literal["preventive", "corrective", "calibration"]
    description: str
    defect: str | None = None
    planned_start: datetime | None = None
    planned_end: datetime | None = None


class CompleteWOBody(Body):
    work_done: str
    actual_start: datetime
    actual_end: datetime


class CalibrationBody(Body):
    certificate_ref: str
    calibrated_on: date
    due_on: date
    result: Literal["pass", "fail", "adjusted"]
    provider: str | None = None
    document_id: int | None = None


@router.get("/equipment")
def equipment(ctx: CtxDep):
    ctx.require("maintenance.read")
    out = []
    for e in ctx.db.execute(select(Equipment).order_by(Equipment.code)).scalars():
        open_dt = ctx.db.execute(select(DowntimeEvent).where(DowntimeEvent.equipment_id == e.id, DowntimeEvent.end_at.is_(None))).scalars().all()
        out.append({**row_dict(e), "open_downtime": [row_dict(d) for d in open_dt],
                    "calibration_overdue": bool(e.calibration_required and (e.calibration_due is None or e.calibration_due < date.today()))})
    return out


@router.get("/equipment/{eid}")
def get_equipment(eid: int, ctx: CtxDep):
    ctx.require("maintenance.read")
    e = ctx.get(Equipment, eid)
    q = lambda M, *w: [row_dict(x) for x in ctx.db.execute(select(M).where(*w).order_by(M.id.desc()).limit(100)).scalars()]
    return {**row_dict(e),
            "downtime": q(DowntimeEvent, DowntimeEvent.equipment_id == eid),
            "work_orders": q(MaintenanceWorkOrder, MaintenanceWorkOrder.equipment_id == eid),
            "calibrations": q(CalibrationRecord, CalibrationRecord.equipment_id == eid),
            "service_schedules": q(ServiceSchedule, ServiceSchedule.equipment_id == eid),
            "restrictions": q(AvailabilityRestriction, AvailabilityRestriction.equipment_id == eid),
            "observations": q(MachineObservation, MachineObservation.equipment_id == eid)}


@router.post("/equipment/{eid}/downtime", status_code=201)
def post_downtime(eid: int, body: DowntimeBody, ctx: CtxDep):
    return row_dict(record_downtime(ctx, eid, body.start_at, body.reason, planned=body.planned, end_at=body.end_at,
                                    source="maintenance" if ctx.can("maintenance.edit") else "operator"))


@router.post("/downtime/{did}/end")
def post_end(did: int, body: EndBody, ctx: CtxDep):
    return row_dict(end_downtime(ctx, did, body.end_at, body.note))


@router.post("/downtime/{did}/confirm")
def post_confirm(did: int, body: ConfirmBody, ctx: CtxDep):
    return row_dict(confirm_machine_downtime(ctx, did, body.confirm, body.note))


@router.post("/equipment/{eid}/work-orders", status_code=201)
def post_wo(eid: int, body: WorkOrderBody, ctx: CtxDep):
    return row_dict(create_work_order(ctx, eid, **body.model_dump()))


@router.post("/maintenance-work-orders/{wid}/complete")
def post_complete_wo(wid: int, body: CompleteWOBody, ctx: CtxDep):
    return row_dict(complete_work_order(ctx, wid, body.work_done, body.actual_start, body.actual_end))


@router.post("/equipment/{eid}/calibrations", status_code=201)
def post_cal(eid: int, body: CalibrationBody, ctx: CtxDep):
    return row_dict(record_calibration(ctx, eid, **body.model_dump()))


@router.post("/equipment/{eid}/poll")
def post_poll(eid: int, ctx: CtxDep):
    """Read the (simulated, read-only) machine adapter once."""
    ctx.require("maintenance.read")
    e = ctx.get(Equipment, eid)
    obs = adapters().machine.read_state(e.code)
    return {"observation": obs.__dict__ | {"observed_at": obs.observed_at.isoformat()}, **ingest_observation(ctx, e, obs)}


@router.get("/equipment/{eid}/oee")
def get_oee(eid: int, ctx: CtxDep, start: datetime | None = None, end: datetime | None = None):
    ctx.require("maintenance.read")
    end = end or utcnow()
    start = start or end - timedelta(days=7)
    return oee(ctx.db, ctx.get(Equipment, eid), start, end)
