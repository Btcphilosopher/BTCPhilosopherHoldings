"""Quality management: sampling, inspection plans, inspections and results, nonconformance, CAPA."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import BigInteger, Boolean, CheckConstraint, Date, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ...core.models import JSONType
from ...db import Base, Qty, TimestampMixin

STAGES = ("incoming", "in_process", "final", "return", "rework")


class SamplingPlan(Base, TimestampMixin):
    """Configurable lot-size bands: [{"max_lot": 50, "sample": 8, "accept": 0}, ...].

    This is a configurable table, not a claim of conformity to any sampling standard."""

    __tablename__ = "sampling_plans"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(32), unique=True)
    description: Mapped[str] = mapped_column(String(200))
    kind: Mapped[str] = mapped_column(String(16), default="bands")  # bands / full / fixed
    bands: Mapped[list[dict[str, Any]]] = mapped_column(JSONType, default=list)


class InspectionPlan(Base, TimestampMixin):
    __tablename__ = "inspection_plans"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(32), unique=True)
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    stage: Mapped[str] = mapped_column(String(16))
    sampling_plan_id: Mapped[int] = mapped_column(ForeignKey("sampling_plans.id"))
    # [{"name","kind": variable|attribute|document,"nominal","lower","upper","unit","method","gauge_kind"}]
    characteristics: Mapped[list[dict[str, Any]]] = mapped_column(JSONType, default=list)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Inspection(Base, TimestampMixin):
    __tablename__ = "inspections"
    __table_args__ = (CheckConstraint(f"stage IN {STAGES}", name="stage"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    stage: Mapped[str] = mapped_column(String(16))
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    lot_ids: Mapped[list[int]] = mapped_column(JSONType, default=list)  # lots (or serials) covered
    plan_id: Mapped[int | None] = mapped_column(ForeignKey("inspection_plans.id"))
    receipt_line_id: Mapped[int | None] = mapped_column(ForeignKey("receipt_lines.id"))
    production_order_id: Mapped[int | None] = mapped_column(ForeignKey("production_orders.id"))
    order_operation_id: Mapped[int | None] = mapped_column(ForeignKey("order_operations.id"))
    lot_quantity: Mapped[Decimal] = mapped_column(Qty, default=0)
    sample_size: Mapped[int] = mapped_column(Integer, default=0)
    accept_number: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(16), default="open")  # open / results_complete / decided
    outcome: Mapped[str | None] = mapped_column(String(16))  # conforming / nonconforming (from results)
    decision: Mapped[str | None] = mapped_column(String(16))  # accepted / rejected / quarantined
    decided_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    decision_note: Mapped[str | None] = mapped_column(Text)
    results: Mapped[list["InspectionResult"]] = relationship(order_by="InspectionResult.id")


class InspectionResult(Base):
    """Append-only. A correction is a NEW row that supersedes an earlier one; the original is kept."""

    __tablename__ = "inspection_results"
    __table_args__ = (CheckConstraint("value_source IN ('measured','manual','calculated')", name="value_source"),)
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    inspection_id: Mapped[int] = mapped_column(ForeignKey("inspections.id"), index=True)
    characteristic: Mapped[str] = mapped_column(String(100))
    sample_ref: Mapped[str | None] = mapped_column(String(64))  # sample no. or serial
    numeric_value: Mapped[Decimal | None] = mapped_column(Qty)
    text_value: Mapped[str | None] = mapped_column(Text)
    unit: Mapped[str | None] = mapped_column(String(16))
    conforms: Mapped[bool] = mapped_column(Boolean)
    value_source: Mapped[str] = mapped_column(String(16))
    equipment_id: Mapped[int | None] = mapped_column(ForeignKey("equipment.id"))
    calibration_ref: Mapped[str | None] = mapped_column(String(64))
    calibration_valid: Mapped[bool | None] = mapped_column(Boolean)
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    recorded_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    supersedes_result_id: Mapped[int | None] = mapped_column(ForeignKey("inspection_results.id"), unique=True)
    correction_reason: Mapped[str | None] = mapped_column(Text)


class Nonconformance(Base, TimestampMixin):
    __tablename__ = "nonconformances"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    source: Mapped[str] = mapped_column(String(24))  # incoming / in_process / final / customer_return / recall / shop_floor
    severity: Mapped[str] = mapped_column(String(16), default="major")  # minor / major / critical
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    lot_ids: Mapped[list[int]] = mapped_column(JSONType, default=list)
    quantity: Mapped[Decimal] = mapped_column(Qty)
    description: Mapped[str] = mapped_column(Text)
    inspection_id: Mapped[int | None] = mapped_column(ForeignKey("inspections.id"))
    production_order_id: Mapped[int | None] = mapped_column(ForeignKey("production_orders.id"))
    supplier_id: Mapped[int | None] = mapped_column(ForeignKey("suppliers.id"))
    status: Mapped[str] = mapped_column(String(16), default="open")  # open / dispositioned / closed
    disposition: Mapped[str | None] = mapped_column(String(24))
    # use_as_is / rework / scrap / return_to_supplier / regrade
    disposition_note: Mapped[str | None] = mapped_column(Text)
    disposition_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    disposition_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    raised_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    linked_order_id: Mapped[int | None] = mapped_column(ForeignKey("production_orders.id"))  # rework order
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class CorrectiveAction(Base, TimestampMixin):
    __tablename__ = "corrective_actions"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    nonconformance_id: Mapped[int] = mapped_column(ForeignKey("nonconformances.id"))
    problem: Mapped[str] = mapped_column(Text)
    root_cause: Mapped[str | None] = mapped_column(Text)
    action: Mapped[str] = mapped_column(Text)
    owner_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    due_date: Mapped[date | None] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(16), default="open")  # open / implemented / verified / closed
    verification: Mapped[str | None] = mapped_column(Text)
    verified_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
