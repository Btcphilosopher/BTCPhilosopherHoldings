from __future__ import annotations

from datetime import date

from fastapi import APIRouter
from sqlalchemy import select

from ...api_deps import Body, CtxDep
from ...core.context import row_dict
from ..production.models import ProductionOrder
from .models import CostPosting, FxRate, OverheadRule
from .service import export_order_postings, incremental_cost, order_cost_comparison, standard_cost

router = APIRouter(prefix="/api", tags=["costing"])


class ExportBody(Body):
    posting_date: date | None = None


@router.get("/costing/orders")
def all_orders(ctx: CtxDep):
    ctx.require("costing.read")
    out = []
    for o in ctx.db.execute(select(ProductionOrder).where(ProductionOrder.status.not_in(("draft",))).order_by(ProductionOrder.id)).scalars():
        c = order_cost_comparison(ctx.db, o)
        c.pop("actual_detail"), c.pop("planned_detail")
        out.append(c)
    return out


@router.get("/costing/orders/{oid}")
def order_cost(oid: int, ctx: CtxDep):
    ctx.require("costing.read")
    return order_cost_comparison(ctx.db, ctx.get(ProductionOrder, oid))


@router.get("/costing/standard/{item_id}")
def std(item_id: int, ctx: CtxDep, on: date | None = None):
    ctx.require("costing.read")
    return standard_cost(ctx.db, item_id, on)


@router.get("/costing/incremental/{item_id}")
def incr(item_id: int, ctx: CtxDep, labour_variable: bool = False, added_to_existing_batch: bool = True):
    ctx.require("costing.read")
    return incremental_cost(ctx.db, item_id, labour_variable=labour_variable, added_to_existing_batch=added_to_existing_batch)


@router.post("/costing/orders/{oid}/export")
def export(oid: int, body: ExportBody, ctx: CtxDep):
    return export_order_postings(ctx, oid, body.posting_date)


@router.get("/costing/postings")
def postings(ctx: CtxDep):
    ctx.require("costing.read")
    return [row_dict(p) for p in ctx.db.execute(select(CostPosting).order_by(CostPosting.id)).scalars()]


@router.get("/fx-rates")
def fx(ctx: CtxDep):
    ctx.require("costing.read")
    return [row_dict(r) for r in ctx.db.execute(select(FxRate).order_by(FxRate.currency, FxRate.rate_date)).scalars()]


@router.get("/overhead-rules")
def overheads(ctx: CtxDep):
    ctx.require("costing.read")
    return [row_dict(r) for r in ctx.db.execute(select(OverheadRule).order_by(OverheadRule.code)).scalars()]
