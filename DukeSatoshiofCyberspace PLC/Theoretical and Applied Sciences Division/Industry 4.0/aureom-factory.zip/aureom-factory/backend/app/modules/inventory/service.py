"""Inventory services.

Invariants
----------
* Every physical change is a row in the append-only ``stock_movements`` journal, written in the
  same transaction as the balance update. Corrections are linked reversals, never edits.
* Balances are locked with SELECT … FOR UPDATE (in id order to avoid deadlocks) and can never
  go negative (application check + CHECK constraint).
* PHYSICAL stock = everything in any bin, including quarantine, WIP and subcontractor bins.
  AVAILABLE stock = accepted, unexpired lots in allocatable bins minus unissued reservations.
* Lots that are not ACCEPTED cannot be reserved, issued, consumed, dispatched, or moved into
  an allocatable bin. Scanning a barcode only *identifies* a lot; it never changes its status.
"""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import and_, func, select, text
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from ...core.context import Ctx, row_dict, utcnow
from ...core.errors import Conflict, InsufficientStock, InvalidState, NotFound, QualityHold, ValidationFailed
from ...core.numbers import D, ZERO, fmt, q
from ..genealogy.models import GenealogyEdge
from ..registry.models import Item
from ..registry.service import get_unit, to_base
from .models import Bin, Lot, LotStatusHistory, Reservation, StockBalance, StockMovement, Warehouse

CONSUMING_TYPES = {"issue", "consumption", "dispatch", "subcontract_send"}
NEEDS_ACCEPTED = {"issue", "consumption", "dispatch"}


# --------------------------------------------------------------------------- lookups


def bin_by_code(db: Session, code: str) -> Bin:
    b = db.execute(select(Bin).where(Bin.code == code)).scalar_one_or_none()
    if b is None:
        raise NotFound(f"Bin {code} not found")
    return b


def site_of_bin(db: Session, bin_id: int) -> int:
    return db.execute(
        select(Warehouse.site_id).join(Bin, Bin.warehouse_id == Warehouse.id).where(Bin.id == bin_id)
    ).scalar_one()


def lot_by_number(db: Session, item_id: int, lot_number: str) -> Lot:
    lot = db.execute(select(Lot).where(Lot.item_id == item_id, Lot.lot_number == lot_number)).scalar_one_or_none()
    if lot is None:
        raise NotFound(f"Lot {lot_number} not found for item {item_id}")
    return lot


def is_expired(lot: Lot, on: date | None = None) -> bool:
    return lot.expiry_date is not None and lot.expiry_date < (on or date.today())


# --------------------------------------------------------------------------- lots


def create_lot(ctx: Ctx, item: Item, lot_number: str, origin: str, *, quality_status: str = "awaiting_review",
               supplier_id=None, supplier_lot=None, receipt_line_id=None, production_order_id=None,
               manufactured_on=None, expiry_date=None, traceability="complete", traceability_note=None,
               unit_cost=None, cost_basis=None, batch_ref=None, attributes=None) -> Lot:
    if item.lot_or_serial_policy == "none":
        raise ValidationFailed(f"{item.item_code} is not lot-controlled")
    if item.shelf_life_applicable and expiry_date is None:
        from datetime import timedelta
        expiry_date = (manufactured_on or date.today()) + timedelta(days=item.shelf_life_days)
    lot = Lot(
        item_id=item.id, lot_number=lot_number, is_serial=item.lot_or_serial_policy == "serial", origin=origin,
        quality_status=quality_status, supplier_id=supplier_id, supplier_lot=supplier_lot,
        receipt_line_id=receipt_line_id, production_order_id=production_order_id, manufactured_on=manufactured_on,
        expiry_date=expiry_date, traceability=traceability, traceability_note=traceability_note,
        unit_cost=unit_cost, cost_basis=cost_basis, batch_ref=batch_ref, attributes=attributes or {},
    )
    ctx.db.add(lot)
    ctx.db.flush()
    ctx.db.add(LotStatusHistory(lot_id=lot.id, from_status=None, to_status=quality_status,
                                reason=f"Lot created ({origin})", changed_by=ctx.user.id))
    return lot


STATUS_PERMISSION = {
    "accepted": "quality.release",
    "rejected": "quality.disposition",
    "quarantined": "quality.record",
    "awaiting_review": "quality.record",
}


def set_lot_status(ctx: Ctx, lot: Lot, to_status: str, reason: str, reference_type: str | None = None,
                   reference_id: int | None = None, *, system: bool = False) -> Lot:
    """Change quality status. Release and rejection are restricted to authorised quality staff.

    ``system=True`` is used only for the safe direction (placing stock on hold), e.g. when a
    nonconformance or recall is raised.
    """
    if to_status not in STATUS_PERMISSION:
        raise ValidationFailed(f"Unknown quality status {to_status}")
    if system:
        if to_status not in ("quarantined", "awaiting_review"):
            raise ValidationFailed("Automatic status changes may only place stock on hold")
    else:
        perm = STATUS_PERMISSION[to_status]
        if not (ctx.can(perm) or (to_status == "quarantined" and ctx.can("inventory.move"))):
            ctx.require(perm)
    if not reason:
        raise ValidationFailed("A reason is required for a quality status change")
    if lot.quality_status == to_status:
        return lot
    before = lot.quality_status
    lot.quality_status = to_status
    ctx.db.add(LotStatusHistory(lot_id=lot.id, from_status=before, to_status=to_status, reason=reason,
                                reference_type=reference_type, reference_id=reference_id, changed_by=ctx.user.id))
    if to_status != "accepted":
        for r in ctx.db.execute(select(Reservation).where(Reservation.lot_id == lot.id, Reservation.status == "active")).scalars():
            r.status = "released"
            r.released_reason = f"Lot placed in status {to_status}: {reason}"
            ctx.audit("reservation.release", "reservation", r.id, reason=r.released_reason)
    ctx.audit("lot.status", "lot", lot.id, before={"quality_status": before}, after={"quality_status": to_status},
              reason=reason)
    ctx.emit("quality.lot_status", {"lot_id": lot.id, "lot_number": lot.lot_number, "from": before, "to": to_status})
    return lot


# --------------------------------------------------------------------------- balances


def _lock_balance(db: Session, item_id: int, lot_id: int | None, bin_id: int, ownership: str) -> StockBalance | None:
    return db.execute(
        select(StockBalance).where(
            StockBalance.item_id == item_id, StockBalance.bin_id == bin_id, StockBalance.ownership == ownership,
            StockBalance.lot_id.is_(None) if lot_id is None else StockBalance.lot_id == lot_id,
        ).with_for_update().execution_options(populate_existing=True)
    ).scalar_one_or_none()


def _reserved_unissued(db: Session, lot_id: int | None, bin_id: int, item_id: int, exclude_id: int | None = None) -> Decimal:
    stmt = select(func.coalesce(func.sum(Reservation.quantity - Reservation.quantity_issued), 0)).where(
        Reservation.status == "active", Reservation.bin_id == bin_id, Reservation.item_id == item_id,
        Reservation.lot_id.is_(None) if lot_id is None else Reservation.lot_id == lot_id,
    )
    if exclude_id:
        stmt = stmt.where(Reservation.id != exclude_id)
    return D(db.execute(stmt).scalar())


def post_movement(
    ctx: Ctx, movement_type: str, item: Item, quantity, unit: str, *, lot: Lot | None = None,
    from_bin: Bin | None = None, to_bin: Bin | None = None, ownership: str = "company",
    reference_type: str | None = None, reference_id: int | None = None, reference_line_id: int | None = None,
    reason_code: str | None = None, notes: str | None = None, value_source: str = "manual",
    observed_at: datetime | None = None, idempotency_key: str | None = None,
    fulfils_reservation_id: int | None = None, reverses: StockMovement | None = None,
    unit_cost=None, skip_quality_gate: bool = False,
) -> StockMovement:
    db = ctx.db
    if idempotency_key:
        existing = db.execute(select(StockMovement).where(StockMovement.idempotency_key == idempotency_key)).scalar_one_or_none()
        if existing:
            if existing.item_id != item.id or (lot and existing.lot_id != lot.id) or existing.movement_type != movement_type:
                raise Conflict(f"Idempotency key {idempotency_key} was already used for a different movement")
            return existing
    if from_bin is None and to_bin is None:
        raise ValidationFailed("A movement needs a source or destination bin")
    if from_bin is not None and to_bin is not None and from_bin.id == to_bin.id:
        raise ValidationFailed("Source and destination bins are the same")
    if item.lot_or_serial_policy != "none" and lot is None:
        raise ValidationFailed(f"{item.item_code} is {item.lot_or_serial_policy}-controlled; a lot/serial is required")
    if lot is not None and lot.item_id != item.id:
        raise ValidationFailed(f"Lot {lot.lot_number} does not belong to {item.item_code}")
    base_qty = to_base(db, item, quantity, unit)
    if base_qty <= 0:
        raise ValidationFailed("Quantity must be positive")
    get_unit(db, unit)

    if lot is not None and not skip_quality_gate:
        if movement_type in NEEDS_ACCEPTED and lot.quality_status != "accepted":
            raise QualityHold(
                f"Lot {lot.lot_number} is {lot.quality_status.upper()} and cannot be used for {movement_type}",
                details={"lot": lot.lot_number, "quality_status": lot.quality_status},
            )
        if movement_type in NEEDS_ACCEPTED and is_expired(lot):
            raise QualityHold(f"Lot {lot.lot_number} expired on {lot.expiry_date}")
        if to_bin is not None and to_bin.allocatable and lot.quality_status != "accepted":
            raise QualityHold(
                f"Lot {lot.lot_number} is {lot.quality_status}; it cannot be placed in allocatable bin {to_bin.code}"
            )

    # Lock balances in a deterministic order to avoid deadlocks.
    targets = sorted({b.id for b in (from_bin, to_bin) if b is not None})
    locked = {}
    for bid in targets:
        locked[bid] = _lock_balance(db, item.id, lot.id if lot else None, bid, ownership)

    if from_bin is not None:
        bal = locked[from_bin.id]
        have = D(bal.quantity) if bal else ZERO
        if have < base_qty:
            raise InsufficientStock(
                f"Only {fmt(have)} {item.base_unit} of {item.item_code}"
                + (f" lot {lot.lot_number}" if lot else "") + f" in {from_bin.code}; {fmt(base_qty)} requested",
                details={"on_hand": str(have), "requested": str(base_qty)},
            )
        if from_bin.allocatable:
            reserved_others = _reserved_unissued(db, lot.id if lot else None, from_bin.id, item.id, fulfils_reservation_id)
            if have - base_qty < reserved_others:
                raise InsufficientStock(
                    f"{fmt(reserved_others)} {item.base_unit} of this stock is reserved for other demand; "
                    f"only {fmt(have - reserved_others)} may be moved",
                    code="reserved_stock",
                )
        bal.quantity = q(have - base_qty)

    if to_bin is not None:
        stmt = pg_insert(StockBalance).values(
            item_id=item.id, lot_id=lot.id if lot else None, bin_id=to_bin.id, ownership=ownership, quantity=base_qty
        ).on_conflict_do_update(
            index_elements=["item_id", "lot_id", "bin_id", "ownership"],
            set_={"quantity": StockBalance.quantity + base_qty, "updated_at": func.now()},
        )
        db.execute(stmt)
        # the upsert bypasses the ORM: expire any cached copy so later reads see the new quantity
        for obj in list(db.identity_map.values()):
            if isinstance(obj, StockBalance) and obj.item_id == item.id and obj.bin_id == to_bin.id and \
                    obj.lot_id == (lot.id if lot else None) and obj.ownership == ownership:
                db.expire(obj)

    if lot is not None and lot.is_serial:
        db.flush()
        total = D(db.execute(select(func.coalesce(func.sum(StockBalance.quantity), 0)).where(StockBalance.lot_id == lot.id)).scalar())
        if total > 1:
            raise ValidationFailed(f"Serial {lot.lot_number} would exist more than once (quantity {fmt(total)})")

    mv = StockMovement(
        movement_no=ctx.next_number("MV", 8), movement_type=movement_type, item_id=item.id,
        lot_id=lot.id if lot else None, from_bin_id=from_bin.id if from_bin else None,
        to_bin_id=to_bin.id if to_bin else None, ownership=ownership, quantity=base_qty,
        entered_quantity=D(quantity), entered_unit=unit, value_source=value_source,
        reference_type=reference_type, reference_id=reference_id, reference_line_id=reference_line_id,
        reason_code=reason_code, notes=notes, reverses_movement_id=reverses.id if reverses else None,
        unit_cost=unit_cost if unit_cost is not None else (lot.unit_cost if lot else item.standard_cost),
        observed_at=observed_at or utcnow(), recorded_by=ctx.user.id, idempotency_key=idempotency_key,
    )
    db.add(mv)
    db.flush()
    ctx.emit("inventory.movement", {
        "movement_no": mv.movement_no, "type": movement_type, "item": item.item_code,
        "lot": lot.lot_number if lot else None, "qty": str(base_qty), "unit": item.base_unit,
        "from": from_bin.code if from_bin else None, "to": to_bin.code if to_bin else None,
    })
    return mv


def reverse_movement(ctx: Ctx, movement_id: int, reason: str, observed_at: datetime | None = None) -> StockMovement:
    ctx.require("inventory.adjust")
    orig = ctx.get(StockMovement, movement_id, "Movement")
    if orig.movement_type == "reversal":
        raise InvalidState("A reversal cannot itself be reversed; post a new movement instead")
    already = ctx.db.execute(select(StockMovement.id).where(StockMovement.reverses_movement_id == orig.id)).scalar()
    if already:
        raise InvalidState(f"Movement {orig.movement_no} has already been reversed")
    if not reason:
        raise ValidationFailed("A reason is required to reverse a movement")
    item = ctx.db.get(Item, orig.item_id)
    lot = ctx.db.get(Lot, orig.lot_id) if orig.lot_id else None
    from_bin = ctx.db.get(Bin, orig.to_bin_id) if orig.to_bin_id else None
    to_bin = ctx.db.get(Bin, orig.from_bin_id) if orig.from_bin_id else None
    mv = post_movement(
        ctx, "reversal", item, orig.quantity, item.base_unit, lot=lot, from_bin=from_bin, to_bin=to_bin,
        ownership=orig.ownership, reference_type=orig.reference_type, reference_id=orig.reference_id,
        reference_line_id=orig.reference_line_id, reason_code="reversal", notes=reason, value_source="system",
        observed_at=observed_at, reverses=orig, unit_cost=orig.unit_cost, skip_quality_gate=True,
    )
    ctx.audit("movement.reverse", "stock_movement", orig.id, after={"reversal": mv.movement_no}, reason=reason)
    return mv


def is_reversed(db: Session, movement_id: int) -> bool:
    return db.execute(select(StockMovement.id).where(StockMovement.reverses_movement_id == movement_id)).scalar() is not None


# --------------------------------------------------------------------------- user-level operations


def transfer(ctx: Ctx, item: Item, lot: Lot | None, from_bin: Bin, to_bin: Bin, qty, unit: str, **kw) -> StockMovement:
    ctx.require("inventory.move", site_of_bin(ctx.db, from_bin.id))
    mtype = "quarantine" if to_bin.kind == "quarantine" else "transfer"
    return post_movement(ctx, mtype, item, qty, unit, lot=lot, from_bin=from_bin, to_bin=to_bin, **kw)


def adjust(ctx: Ctx, item: Item, lot: Lot | None, bin_: Bin, delta, unit: str, reason_code: str, notes: str, **kw) -> StockMovement:
    ctx.require("inventory.adjust", site_of_bin(ctx.db, bin_.id))
    if not reason_code or not notes:
        raise ValidationFailed("Stock adjustments need a reason code and an explanation")
    d = D(delta)
    if d == 0:
        raise ValidationFailed("Adjustment of zero")
    if d > 0:
        return post_movement(ctx, "adjustment", item, d, unit, lot=lot, to_bin=bin_, reason_code=reason_code, notes=notes,
                             skip_quality_gate=True, **kw)
    return post_movement(ctx, "adjustment", item, -d, unit, lot=lot, from_bin=bin_, reason_code=reason_code, notes=notes, **kw)


def split_lot(ctx: Ctx, lot: Lot, bin_: Bin, qty, new_lot_number: str, reason: str, new_status: str | None = None) -> Lot:
    """Split part of a lot into a new lot (e.g. to segregate damaged material). Provenance is preserved."""
    ctx.require("inventory.move", site_of_bin(ctx.db, bin_.id))
    item = ctx.db.get(Item, lot.item_id)
    if lot.is_serial:
        raise ValidationFailed("Serials cannot be split")
    child = create_lot(
        ctx, item, new_lot_number, "split", quality_status=lot.quality_status, supplier_id=lot.supplier_id,
        supplier_lot=lot.supplier_lot, receipt_line_id=lot.receipt_line_id, production_order_id=lot.production_order_id,
        manufactured_on=lot.manufactured_on, expiry_date=lot.expiry_date, traceability=lot.traceability,
        traceability_note=f"Split from {lot.lot_number}: {reason}", unit_cost=lot.unit_cost, cost_basis=lot.cost_basis,
        attributes={**(lot.attributes or {}), "split_from": lot.lot_number},
    )
    out = post_movement(ctx, "adjustment", item, qty, item.base_unit, lot=lot, from_bin=bin_, reason_code="lot_split",
                        notes=f"Split to {new_lot_number}: {reason}", value_source="system", skip_quality_gate=True)
    post_movement(ctx, "adjustment", item, qty, item.base_unit, lot=child, to_bin=bin_, reason_code="lot_split",
                  notes=f"Split from {lot.lot_number}: {reason}", value_source="system", skip_quality_gate=True,
                  reference_type="stock_movement", reference_id=out.id)
    ctx.db.add(GenealogyEdge(parent_lot_id=lot.id, child_lot_id=child.id, relation="split", quantity=out.quantity,
                             unit=item.base_unit, precision="exact", source_type="stock_movement", source_id=out.id,
                             recorded_by=ctx.user.id, note=reason))
    if new_status and new_status != child.quality_status:
        set_lot_status(ctx, child, new_status, reason, "lot", lot.id,
                       system=new_status in ("quarantined", "awaiting_review"))
    ctx.audit("lot.split", "lot", lot.id, after={"child": new_lot_number, "quantity": str(out.quantity)}, reason=reason)
    return child


def merge_lots(ctx: Ctx, sources: list[tuple[Lot, Bin, Decimal]], to_bin: Bin, new_lot_number: str, reason: str) -> Lot:
    ctx.require("inventory.move", site_of_bin(ctx.db, to_bin.id))
    if len(sources) < 2:
        raise ValidationFailed("Merging needs at least two source lots")
    items = {l.item_id for l, _, _ in sources}
    statuses = {l.quality_status for l, _, _ in sources}
    if len(items) != 1:
        raise ValidationFailed("Only lots of the same item can be merged")
    if len(statuses) != 1:
        raise QualityHold("Lots with different quality statuses cannot be merged")
    item = ctx.db.get(Item, items.pop())
    trace = "complete" if all(l.traceability == "complete" for l, _, _ in sources) else "partial"
    costs = [(D(l.unit_cost), D(qty)) for l, _, qty in sources if l.unit_cost is not None]
    total_qty = sum(D(qty) for _, _, qty in sources)
    unit_cost = (sum(c * qq for c, qq in costs) / total_qty) if len(costs) == len(sources) else None
    child = create_lot(ctx, item, new_lot_number, "merge", quality_status=statuses.pop(), traceability=trace,
                       traceability_note="Merged from " + ", ".join(l.lot_number for l, _, _ in sources),
                       unit_cost=unit_cost, cost_basis="weighted merge" if unit_cost is not None else "unknown")
    for lot, b, qty in sources:
        mv = post_movement(ctx, "adjustment", item, qty, item.base_unit, lot=lot, from_bin=b, reason_code="lot_merge",
                           notes=f"Merged into {new_lot_number}", value_source="system", skip_quality_gate=True)
        ctx.db.add(GenealogyEdge(parent_lot_id=lot.id, child_lot_id=child.id, relation="merge", quantity=mv.quantity,
                                 unit=item.base_unit, precision="exact", source_type="stock_movement", source_id=mv.id,
                                 recorded_by=ctx.user.id, note=reason))
    post_movement(ctx, "adjustment", item, total_qty, item.base_unit, lot=child, to_bin=to_bin, reason_code="lot_merge",
                  notes=reason, value_source="system", skip_quality_gate=True)
    return child


# --------------------------------------------------------------------------- reservations


def available_rows(db: Session, item_id: int, lot_id: int | None = None, lock: bool = False) -> list[dict]:
    stmt = (
        select(StockBalance, Lot, Bin)
        .join(Bin, Bin.id == StockBalance.bin_id)
        .outerjoin(Lot, Lot.id == StockBalance.lot_id)
        .where(StockBalance.item_id == item_id, Bin.allocatable.is_(True), StockBalance.quantity > 0,
               StockBalance.ownership == "company")
        .order_by(StockBalance.id)
    )
    if lot_id is not None:
        stmt = stmt.where(StockBalance.lot_id == lot_id)
    if lock:
        stmt = stmt.with_for_update(of=StockBalance)
    stmt = stmt.execution_options(populate_existing=True)
    out = []
    for bal, lot, b in db.execute(stmt).all():
        ok = lot is None or (lot.quality_status == "accepted" and not is_expired(lot))
        reserved = _reserved_unissued(db, bal.lot_id, bal.bin_id, item_id)
        out.append({
            "balance": bal, "lot": lot, "bin": b, "on_hand": D(bal.quantity), "reserved": reserved,
            "available": max(ZERO, D(bal.quantity) - reserved) if ok else ZERO, "usable": ok,
        })
    return out


def reserve(ctx: Ctx, item: Item, quantity, demand_type: str, demand_id: int, *, lot: Lot | None = None,
            allowed_lot_ids: set[int] | None = None) -> list[Reservation]:
    """Reserve accepted stock. Concurrent callers serialise on the locked balance rows, so two
    demands can never both be promised the same stock."""
    ctx.require("inventory.reserve")
    need = D(quantity)
    if need <= 0:
        raise ValidationFailed("Reservation quantity must be positive")
    if lot is not None and lot.quality_status != "accepted":
        raise QualityHold(f"Lot {lot.lot_number} is {lot.quality_status.upper()} and cannot be allocated")
    if lot is not None and is_expired(lot):
        raise QualityHold(f"Lot {lot.lot_number} has expired")
    rows = available_rows(ctx.db, item.id, lot.id if lot else None, lock=True)
    if allowed_lot_ids is not None:
        rows = [r for r in rows if r["lot"] is None or r["lot"].id in allowed_lot_ids]
    # FEFO, then FIFO by lot id
    rows.sort(key=lambda r: ((r["lot"].expiry_date or date.max) if r["lot"] else date.max, r["lot"].id if r["lot"] else 0))
    total = sum(r["available"] for r in rows)
    if total < need:
        raise InsufficientStock(
            f"Only {fmt(total)} {item.base_unit} of {item.item_code} available"
            + (f" in lot {lot.lot_number}" if lot else "") + f"; {fmt(need)} requested",
            details={"available": str(total), "requested": str(need)},
        )
    made = []
    for r in rows:
        if need <= 0:
            break
        take = min(need, r["available"])
        if take <= 0:
            continue
        res = Reservation(item_id=item.id, lot_id=r["lot"].id if r["lot"] else None, bin_id=r["bin"].id, quantity=q(take),
                          demand_type=demand_type, demand_id=demand_id, created_by=ctx.user.id)
        ctx.db.add(res)
        made.append(res)
        need -= take
    ctx.db.flush()
    for res in made:
        ctx.audit("reservation.create", "reservation", res.id, after=row_dict(res))
    return made


def release_reservation(ctx: Ctx, reservation: Reservation, reason: str) -> None:
    ctx.require("inventory.reserve")
    if reservation.status != "active":
        return
    reservation.status = "released"
    reservation.released_reason = reason
    ctx.audit("reservation.release", "reservation", reservation.id, reason=reason)


def issue_reserved(ctx: Ctx, reservation: Reservation, qty, to_bin: Bin, *, reference_type: str, reference_id: int,
                   reference_line_id: int | None = None, value_source="scanned", observed_at=None,
                   idempotency_key=None) -> StockMovement:
    if reservation.status != "active":
        raise InvalidState(f"Reservation {reservation.id} is {reservation.status}")
    remaining = D(reservation.quantity) - D(reservation.quantity_issued)
    qty = D(qty)
    if qty > remaining:
        raise ValidationFailed(f"Issue of {fmt(qty)} exceeds remaining reservation {fmt(remaining)}")
    item = ctx.db.get(Item, reservation.item_id)
    lot = ctx.db.get(Lot, reservation.lot_id) if reservation.lot_id else None
    mv = post_movement(
        ctx, "issue", item, qty, item.base_unit, lot=lot, from_bin=ctx.db.get(Bin, reservation.bin_id), to_bin=to_bin,
        reference_type=reference_type, reference_id=reference_id, reference_line_id=reference_line_id,
        value_source=value_source, observed_at=observed_at, fulfils_reservation_id=reservation.id,
        idempotency_key=idempotency_key,
    )
    reservation.quantity_issued = q(D(reservation.quantity_issued) + qty)
    if reservation.quantity_issued >= reservation.quantity:
        reservation.status = "fulfilled"
    return mv


# --------------------------------------------------------------------------- reporting


def stock_summary(db: Session, item_id: int | None = None, site_id: int | None = None) -> list[dict]:
    """Physical vs available, per item."""
    stmt = (
        select(StockBalance, Lot, Bin, Item, Warehouse)
        .join(Bin, Bin.id == StockBalance.bin_id).join(Warehouse, Warehouse.id == Bin.warehouse_id)
        .join(Item, Item.id == StockBalance.item_id).outerjoin(Lot, Lot.id == StockBalance.lot_id)
        .where(StockBalance.quantity > 0)
    )
    if item_id:
        stmt = stmt.where(StockBalance.item_id == item_id)
    if site_id:
        stmt = stmt.where(Warehouse.site_id == site_id)
    agg: dict[int, dict] = {}
    for bal, lot, b, item, wh in db.execute(stmt).all():
        a = agg.setdefault(item.id, {
            "item_id": item.id, "item_code": item.item_code, "description": item.description,
            "item_type": item.item_type, "unit": item.base_unit, "physical": ZERO, "accepted_allocatable": ZERO,
            "quarantined": ZERO, "awaiting_review": ZERO, "rejected": ZERO, "wip": ZERO, "at_subcontractor": ZERO,
            "reserved": ZERO, "available": ZERO, "expired": ZERO,
        })
        qty = D(bal.quantity)
        a["physical"] += qty
        status = lot.quality_status if lot else "accepted"
        if status in ("quarantined", "awaiting_review", "rejected"):
            a[status] += qty
        if b.kind == "wip":
            a["wip"] += qty
        if b.kind == "subcontractor":
            a["at_subcontractor"] += qty
        if lot is not None and is_expired(lot):
            a["expired"] += qty
        elif b.allocatable and status == "accepted" and bal.ownership == "company":
            a["accepted_allocatable"] += qty
    for iid, a in agg.items():
        res = D(db.execute(select(func.coalesce(func.sum(Reservation.quantity - Reservation.quantity_issued), 0))
                           .where(Reservation.item_id == iid, Reservation.status == "active")).scalar())
        a["reserved"] = res
        a["available"] = max(ZERO, a["accepted_allocatable"] - res)
    return [{k: (str(v) if isinstance(v, Decimal) else v) for k, v in a.items()} for a in agg.values()]


def lot_locations(db: Session, lot_id: int) -> list[dict]:
    rows = db.execute(
        select(StockBalance, Bin).join(Bin, Bin.id == StockBalance.bin_id)
        .where(StockBalance.lot_id == lot_id, StockBalance.quantity > 0)
    ).all()
    return [{"bin": b.code, "bin_kind": b.kind, "quantity": str(bal.quantity), "ownership": bal.ownership} for bal, b in rows]


def lot_on_hand(db: Session, lot_id: int, bin_id: int | None = None) -> Decimal:
    stmt = select(func.coalesce(func.sum(StockBalance.quantity), 0)).where(StockBalance.lot_id == lot_id)
    if bin_id:
        stmt = stmt.where(StockBalance.bin_id == bin_id)
    return D(db.execute(stmt).scalar())


def verify_journal(db: Session) -> list[dict]:
    """Recompute balances from the journal and report any discrepancy (used by tests and restore checks)."""
    rows = db.execute(text("""
        WITH j AS (
          SELECT item_id, lot_id, to_bin_id AS bin_id, ownership, quantity AS q FROM stock_movements WHERE to_bin_id IS NOT NULL
          UNION ALL
          SELECT item_id, lot_id, from_bin_id, ownership, -quantity FROM stock_movements WHERE from_bin_id IS NOT NULL
        ), s AS (SELECT item_id, lot_id, bin_id, ownership, SUM(q) AS q FROM j GROUP BY 1,2,3,4)
        SELECT COALESCE(s.item_id,b.item_id), COALESCE(s.lot_id,b.lot_id), COALESCE(s.bin_id,b.bin_id),
               COALESCE(s.q,0), COALESCE(b.quantity,0)
        FROM s FULL OUTER JOIN stock_balances b
          ON b.item_id=s.item_id AND b.bin_id=s.bin_id AND b.ownership=s.ownership
         AND b.lot_id IS NOT DISTINCT FROM s.lot_id
        WHERE COALESCE(s.q,0) <> COALESCE(b.quantity,0)
    """)).all()
    return [{"item_id": r[0], "lot_id": r[1], "bin_id": r[2], "journal": str(r[3]), "balance": str(r[4])} for r in rows]
