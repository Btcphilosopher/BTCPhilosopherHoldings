"""Material genealogy graph.

Nodes are lots (including serials) and production orders. Edges carry quantities and a
*precision* that states how certain the link is:

* exact        – recorded directly (scanned input against a specific output, split, merge)
* order_level  – the lot was consumed by an order; any output of that order MAY contain it
* unknown      – history is incomplete (e.g. opening stock without supplier records)
"""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import BigInteger, CheckConstraint, DateTime, ForeignKey, Index, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from ...db import Base, Qty

RELATIONS = (
    "consumed_by_order", "produced_by_order", "consumed_into", "split", "merge",
    "rework_input", "rework_output", "subcontract_input", "subcontract_output",
)
PRECISIONS = ("exact", "order_level", "unknown")


class GenealogyEdge(Base):
    __tablename__ = "genealogy_edges"
    __table_args__ = (
        CheckConstraint("(parent_lot_id IS NULL) <> (parent_order_id IS NULL)", name="one_parent"),
        CheckConstraint("(child_lot_id IS NULL) <> (child_order_id IS NULL)", name="one_child"),
        CheckConstraint(f"relation IN {RELATIONS}", name="relation"),
        CheckConstraint(f"precision IN {PRECISIONS}", name="precision"),
        Index("ix_gen_parent_lot", "parent_lot_id"), Index("ix_gen_child_lot", "child_lot_id"),
        Index("ix_gen_parent_order", "parent_order_id"), Index("ix_gen_child_order", "child_order_id"),
    )
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    parent_lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"))
    parent_order_id: Mapped[int | None] = mapped_column(ForeignKey("production_orders.id"))
    child_lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"))
    child_order_id: Mapped[int | None] = mapped_column(ForeignKey("production_orders.id"))
    relation: Mapped[str] = mapped_column(String(32))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    unit: Mapped[str] = mapped_column(String(16))
    precision: Mapped[str] = mapped_column(String(16), default="exact")
    source_type: Mapped[str | None] = mapped_column(String(32))
    source_id: Mapped[int | None] = mapped_column(Integer)
    note: Mapped[str | None] = mapped_column(Text)
    recorded_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
