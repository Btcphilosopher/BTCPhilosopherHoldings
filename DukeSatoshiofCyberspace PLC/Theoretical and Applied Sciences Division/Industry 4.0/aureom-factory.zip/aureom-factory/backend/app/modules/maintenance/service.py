"""Maintenance, calibration, downtime, machine observations and OEE."""
from __future__ import annotations

from datetime import date, datetime, timedelta
from decimal import Decimal

from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session

from ...core.context import Ctx, row_dict, utcnow
from ...core.errors import InvalidState, ValidationFailed
from ...core.numbers import D, q
from ..engineering.models import WorkCentre
from ..planning.calendar import intersect, merge, minutes, subtract, working_intervals
from .models import (
    AvailabilityRestriction, CalibrationRecord, DowntimeEvent, Equipment, MachineObservation, MaintenanceWorkOrder,
    ServiceSchedule,
)


def equipment_available(db: Session, eq: Equipment, at: datetime) -> tuple[bool, str | None]:
    if eq.status in ("down", "retired"):
        return False, f"{eq.code} is {eq.status}" + (f": {eq.status_note}" if eq.status_note else "")
    dt = db.execute(select(DowntimeEvent).where(
        DowntimeEvent.equipment_id == eq.id, DowntimeEvent.confirmed.is_(True), DowntimeEvent.start_at <= at,
        or_(DowntimeEvent.end_at.is_(None), DowntimeEvent.end_at > at))).scalars().first()
    if dt:
        return False, f"{eq.code} down: {dt.reason}"
    r = db.execute(select(AvailabilityRestriction).where(
        AvailabilityRestriction.equipment_id == eq.id, AvailabilityRestriction.blocks_scheduling.is_(True),
        AvailabilityRestriction.start_at <= at, AvailabilityRestriction.end_at > at)).scalars().first()
    if r:
        return False, f"{eq.code} restricted: {r.description}"
    return True, None


def blocked_intervals(db: Session, eq: Equipment, start: datetime, end: datetime) -> list[tuple[datetime, datetime]]:
    out = []
    for d in db.execute(select(DowntimeEvent).where(DowntimeEvent.equipment_id == eq.id, DowntimeEvent.confirmed.is_(True),
                                                    DowntimeEvent.start_at < end,
                                                    or_(DowntimeEvent.end_at.is_(None), DowntimeEvent.end_at > start))).scalars():
        out.append((d.start_at, d.end_at or end))
    for r in db.execute(select(AvailabilityRestriction).where(AvailabilityRestriction.equipment_id == eq.id,
                                                              AvailabilityRestriction.blocks_scheduling.is_(True),
                                                              AvailabilityRestriction.start_at < end,
                                                              AvailabilityRestriction.end_at > start)).scalars():
        out.append((r.start_at, r.end_at))
    for w in db.execute(select(MaintenanceWorkOrder).where(MaintenanceWorkOrder.equipment_id == eq.id,
                                                           MaintenanceWorkOrder.status.in_(("open", "in_progress")),
                                                           MaintenanceWorkOrder.planned_start.is_not(None),
                                                           MaintenanceWorkOrder.planned_start < end,
                                                           MaintenanceWorkOrder.planned_end > start)).scalars():
        out.append((w.planned_start, w.planned_end))
    return merge(out)


def record_downtime(ctx: Ctx, equipment_id: int, start_at: datetime, reason: str, *, planned: bool = False,
                    end_at: datetime | None = None, source: str = "operator", confirmed: bool = True) -> DowntimeEvent:
    if not (ctx.can("maintenance.edit") or ctx.can("production.execute")):
        ctx.require("maintenance.edit")
    if planned and not ctx.can("maintenance.edit"):
        ctx.require("maintenance.edit")
    eq = ctx.get(Equipment, equipment_id)
    ev = DowntimeEvent(equipment_id=eq.id, start_at=start_at, end_at=end_at, planned=planned, reason=reason,
                       source=source, recorded_by=ctx.user.id, confirmed=confirmed)
    ctx.db.add(ev)
    if end_at is None and confirmed:
        eq.status, eq.status_note = "down", reason
    ctx.db.flush()
    ctx.audit("equipment.downtime", "equipment", eq.id, after=row_dict(ev))
    ctx.emit("maintenance.downtime", {"equipment": eq.code, "reason": reason, "planned": planned})
    return ev


def end_downtime(ctx: Ctx, downtime_id: int, end_at: datetime, note: str | None = None) -> DowntimeEvent:
    ctx.require("maintenance.edit")
    ev = ctx.get(DowntimeEvent, downtime_id)
    if ev.end_at is not None:
        raise InvalidState("Downtime already ended")
    ev.end_at = end_at
    eq = ctx.db.get(Equipment, ev.equipment_id)
    still = ctx.db.execute(select(DowntimeEvent.id).where(DowntimeEvent.equipment_id == eq.id, DowntimeEvent.end_at.is_(None),
                                                          DowntimeEvent.id != ev.id, DowntimeEvent.confirmed.is_(True))).first()
    if not still:
        eq.status, eq.status_note = "available", None
    ctx.audit("equipment.downtime_end", "equipment", eq.id, after={"downtime_id": ev.id, "end_at": end_at}, reason=note)
    return ev


def confirm_machine_downtime(ctx: Ctx, downtime_id: int, confirm: bool, note: str) -> DowntimeEvent:
    """Machine-reported downtime is a suggestion until a person confirms it."""
    ctx.require("maintenance.edit")
    ev = ctx.get(DowntimeEvent, downtime_id)
    if ev.source != "machine_adapter":
        raise ValidationFailed("Only machine-reported events need confirmation")
    ev.confirmed = confirm
    ctx.audit("equipment.downtime_confirm", "equipment", ev.equipment_id, after={"confirmed": confirm}, reason=note)
    return ev


def create_work_order(ctx: Ctx, equipment_id: int, kind: str, description: str, *, defect: str | None = None,
                      planned_start=None, planned_end=None) -> MaintenanceWorkOrder:
    ctx.require("maintenance.edit")
    wo = MaintenanceWorkOrder(number=ctx.next_number("MWO"), equipment_id=equipment_id, kind=kind, description=description,
                              defect=defect, planned_start=planned_start, planned_end=planned_end, raised_by=ctx.user.id)
    ctx.db.add(wo)
    ctx.db.flush()
    ctx.audit("maintenance.work_order", "maintenance_work_order", wo.id, after=row_dict(wo))
    return wo


def complete_work_order(ctx: Ctx, wo_id: int, work_done: str, actual_start: datetime, actual_end: datetime) -> MaintenanceWorkOrder:
    ctx.require("maintenance.edit")
    wo = ctx.get(MaintenanceWorkOrder, wo_id)
    wo.status, wo.work_done, wo.actual_start, wo.actual_end, wo.completed_by = "completed", work_done, actual_start, actual_end, ctx.user.id
    for s in ctx.db.execute(select(ServiceSchedule).where(ServiceSchedule.equipment_id == wo.equipment_id)).scalars():
        if wo.kind == "preventive":
            s.last_done = actual_end.date()
            s.next_due = actual_end.date() + timedelta(days=s.interval_days)
    ctx.audit("maintenance.work_order_complete", "maintenance_work_order", wo.id, reason=work_done)
    return wo


def record_calibration(ctx: Ctx, equipment_id: int, certificate_ref: str, calibrated_on: date, due_on: date,
                       result: str, provider: str | None = None, document_id: int | None = None) -> CalibrationRecord:
    ctx.require("maintenance.edit")
    if result not in ("pass", "fail", "adjusted"):
        raise ValidationFailed("result must be pass, fail or adjusted")
    eq = ctx.get(Equipment, equipment_id)
    rec = CalibrationRecord(equipment_id=eq.id, certificate_ref=certificate_ref, calibrated_on=calibrated_on, due_on=due_on,
                            result=result, provider=provider, document_id=document_id, recorded_by=ctx.user.id)
    ctx.db.add(rec)
    eq.calibration_due = due_on if result != "fail" else None
    ctx.db.flush()
    ctx.audit("equipment.calibration", "equipment", eq.id, after=row_dict(rec))
    return rec


def ingest_observation(ctx: Ctx, equipment: Equipment, obs) -> dict:
    """Store a machine observation. If the machine reports 'down' and no confirmed downtime is open,
    a downtime is SUGGESTED (unconfirmed) — operator and maintenance records are never overwritten."""
    row = MachineObservation(equipment_id=equipment.id, observed_at=obs.observed_at, state=obs.state,
                             cycle_count=obs.cycle_count, spindle_hours=obs.spindle_hours, alarm_code=obs.alarm_code,
                             source=obs.source, raw=obs.raw)
    ctx.db.add(row)
    discrepancy = None
    if obs.state == "down" and equipment.status != "down":
        discrepancy = f"Machine reports DOWN ({obs.alarm_code}) but equipment record says {equipment.status}"
        open_sugg = ctx.db.execute(select(DowntimeEvent.id).where(DowntimeEvent.equipment_id == equipment.id,
                                                                  DowntimeEvent.source == "machine_adapter",
                                                                  DowntimeEvent.end_at.is_(None))).first()
        if not open_sugg:
            ctx.db.add(DowntimeEvent(equipment_id=equipment.id, start_at=obs.observed_at, reason=f"Machine alarm {obs.alarm_code}",
                                     source="machine_adapter", confirmed=False))
    elif obs.state in ("running", "idle") and equipment.status == "down":
        discrepancy = f"Machine reports {obs.state.upper()} but equipment is recorded DOWN; record not changed"
    ctx.db.flush()
    return {"observation_id": row.id, "discrepancy": discrepancy}


def oee(db: Session, equipment: Equipment, start: datetime, end: datetime) -> dict:
    """OEE with explicit definitions.

    planned production time = calendar working time − planned downtime (planned maintenance)
    run time                = planned production time − confirmed unplanned downtime
    availability            = run time / planned production time
    performance             = (ideal cycle time × total count) / run time   (capped at 100 %)
    quality                 = good count / total count
    Exclusions: unconfirmed machine-reported downtime; time outside the calendar; operations without
    an ideal cycle time. Counts are attributed to equipment by its share of each operation's booked minutes.
    """
    from ..production.models import OrderOperation
    from ..production.service import time_intervals

    wc = db.get(WorkCentre, equipment.work_centre_id) if equipment.work_centre_id else None
    cal = equipment.calendar or (wc.calendar if wc else {})
    work = working_intervals(cal, wc.holidays if wc else [], start, end)
    planned_dt, unplanned_dt, unconfirmed = [], [], []
    for d in db.execute(select(DowntimeEvent).where(DowntimeEvent.equipment_id == equipment.id, DowntimeEvent.start_at < end,
                                                    or_(DowntimeEvent.end_at.is_(None), DowntimeEvent.end_at > start))).scalars():
        iv = (max(d.start_at, start), min(d.end_at or end, end))
        (unconfirmed if not d.confirmed else planned_dt if d.planned else unplanned_dt).append(iv)
    planned_time = subtract(work, planned_dt)
    run_time = subtract(planned_time, unplanned_dt)
    ppt, rt = minutes(planned_time), minutes(run_time)
    total = good = 0.0
    for op in db.execute(select(OrderOperation)).scalars():
        ivs = time_intervals(db, op)
        mine = sum(float(i["minutes"]) for i in ivs if i["equipment_id"] == equipment.id and i["start"] < end and i["end"] > start)
        all_m = sum(float(i["minutes"]) for i in ivs)
        if mine <= 0 or all_m <= 0:
            continue
        share = mine / all_m
        t = float(D(op.quantity_good) + D(op.quantity_scrap) + D(op.quantity_rework))
        total += t * share
        good += float(op.quantity_good) * share
    ideal = float(equipment.ideal_cycle_seconds or 0) / 60
    availability = rt / ppt if ppt else None
    performance = min(1.0, (ideal * total) / rt) if rt and ideal else None
    quality = good / total if total else None
    value = availability * performance * quality if None not in (availability, performance, quality) else None
    r = lambda x: round(x, 4) if x is not None else None
    return {
        "equipment": equipment.code, "window": [start.isoformat(), end.isoformat()],
        "planned_production_minutes": round(ppt, 1), "run_minutes": round(rt, 1),
        "planned_downtime_minutes": round(minutes(intersect(work, planned_dt)), 1),
        "unplanned_downtime_minutes": round(minutes(intersect(planned_time, unplanned_dt)), 1),
        "unconfirmed_machine_downtime_minutes": round(minutes(unconfirmed), 1),
        "total_count": round(total, 2), "good_count": round(good, 2), "ideal_cycle_minutes": ideal,
        "availability": r(availability), "performance": r(performance), "quality": r(quality), "oee": r(value),
        "definitions": oee.__doc__,
    }
