"""Engineering definitions: versioned bills of materials, routings and work centres."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ...core.models import JSONType
from ...db import Base, Money, Qty, TimestampMixin

DEFINITION_STATUSES = ("draft", "approved", "superseded", "obsolete")


class WorkCentre(Base, TimestampMixin):
    __tablename__ = "work_centres"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    code: Mapped[str] = mapped_column(String(32), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    # Shift calendar {"mon": [["07:00","15:30"]], ...}; days missing = closed.
    calendar: Mapped[dict[str, Any]] = mapped_column(JSONType, default=dict)
    holidays: Mapped[list[str]] = mapped_column(JSONType, default=list)  # ISO dates
    labour_rate: Mapped[Decimal] = mapped_column(Money, default=0)  # per operator hour
    machine_rate: Mapped[Decimal] = mapped_column(Money, default=0)  # fully-costed per machine hour
    machine_variable_rate: Mapped[Decimal] = mapped_column(Money, default=0)  # energy/consumables per hour
    rate_currency: Mapped[str] = mapped_column(String(3), default="GBP")
    is_subcontract: Mapped[bool] = mapped_column(Boolean, default=False)


class Bom(Base, TimestampMixin):
    __tablename__ = "boms"
    __table_args__ = (
        UniqueConstraint("item_id", "version"),
        CheckConstraint(f"status IN {DEFINITION_STATUSES}", name="status"),
        CheckConstraint("expected_yield_pct > 0 AND expected_yield_pct <= 100", name="yield"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"), index=True)
    version: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(16), default="draft")
    base_quantity: Mapped[Decimal] = mapped_column(Qty, default=1)  # lines are per base_quantity of parent
    expected_yield_pct: Mapped[Decimal] = mapped_column(Qty, default=100)  # parent-level process yield
    effective_from: Mapped[date | None] = mapped_column(Date)
    effective_to: Mapped[date | None] = mapped_column(Date)
    change_note: Mapped[str | None] = mapped_column(Text)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    approved_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    row_version: Mapped[int] = mapped_column(Integer, default=1)
    __mapper_args__ = {"version_id_col": row_version}
    lines: Mapped[list["BomLine"]] = relationship(
        back_populates="bom", cascade="all, delete-orphan", order_by="BomLine.line_no"
    )


class BomLine(Base):
    """One component of a BOM.

    scrap_basis makes loss handling explicit and prevents double counting:
      * 'net_plus_loss'          → quantity is net; gross = quantity × (1 + loss_pct/100)
      * 'allowance_in_quantity'  → quantity already contains the allowance; loss_pct is informational only
    """

    __tablename__ = "bom_lines"
    __table_args__ = (
        UniqueConstraint("bom_id", "line_no"),
        CheckConstraint("quantity > 0", name="qty"),
        CheckConstraint("loss_pct >= 0 AND loss_pct < 100", name="loss"),
        CheckConstraint("scrap_basis IN ('net_plus_loss','allowance_in_quantity')", name="scrap_basis"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    bom_id: Mapped[int] = mapped_column(ForeignKey("boms.id", ondelete="CASCADE"))
    line_no: Mapped[int] = mapped_column(Integer)
    component_item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    unit: Mapped[str] = mapped_column(ForeignKey("units.code"))
    loss_pct: Mapped[Decimal] = mapped_column(Qty, default=0)
    scrap_basis: Mapped[str] = mapped_column(String(32), default="net_plus_loss")
    allowance_note: Mapped[str | None] = mapped_column(Text)
    is_packaging: Mapped[bool] = mapped_column(Boolean, default=False)
    backflush: Mapped[bool] = mapped_column(Boolean, default=False)
    # Alternatives share an alternative_group; priority 1 = primary. Only approved alternatives may be used.
    alternative_group: Mapped[str | None] = mapped_column(String(32))
    alternative_priority: Mapped[int] = mapped_column(Integer, default=1)
    alternative_approved: Mapped[bool] = mapped_column(Boolean, default=True)
    operation_seq: Mapped[int | None] = mapped_column(Integer)  # operation at which it is consumed
    effective_from: Mapped[date | None] = mapped_column(Date)
    effective_to: Mapped[date | None] = mapped_column(Date)
    bom: Mapped[Bom] = relationship(back_populates="lines")


class Routing(Base, TimestampMixin):
    __tablename__ = "routings"
    __table_args__ = (UniqueConstraint("item_id", "version"), CheckConstraint(f"status IN {DEFINITION_STATUSES}", name="status"))
    id: Mapped[int] = mapped_column(primary_key=True)
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"), index=True)
    version: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(16), default="draft")
    kind: Mapped[str] = mapped_column(String(16), default="standard")  # standard / rework
    effective_from: Mapped[date | None] = mapped_column(Date)
    effective_to: Mapped[date | None] = mapped_column(Date)
    change_note: Mapped[str | None] = mapped_column(Text)
    approved_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    row_version: Mapped[int] = mapped_column(Integer, default=1)
    __mapper_args__ = {"version_id_col": row_version}
    operations: Mapped[list["RoutingOperation"]] = relationship(
        back_populates="routing", cascade="all, delete-orphan", order_by="RoutingOperation.seq"
    )


class RoutingOperation(Base):
    __tablename__ = "routing_operations"
    __table_args__ = (UniqueConstraint("routing_id", "seq"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    routing_id: Mapped[int] = mapped_column(ForeignKey("routings.id", ondelete="CASCADE"))
    seq: Mapped[int] = mapped_column(Integer)
    code: Mapped[str] = mapped_column(String(32))
    name: Mapped[str] = mapped_column(String(200))
    work_centre_id: Mapped[int] = mapped_column(ForeignKey("work_centres.id"))
    required_equipment_kind: Mapped[str | None] = mapped_column(String(64))
    required_skill: Mapped[str | None] = mapped_column(String(64))
    setup_minutes: Mapped[Decimal] = mapped_column(Qty, default=0)
    run_minutes_per_unit: Mapped[Decimal] = mapped_column(Qty, default=0)
    machine_minutes_per_unit: Mapped[Decimal] = mapped_column(Qty, default=0)
    inspection_point: Mapped[bool] = mapped_column(Boolean, default=False)
    inspection_plan_code: Mapped[str | None] = mapped_column(String(32))
    instructions: Mapped[str | None] = mapped_column(Text)
    instruction_document_id: Mapped[int | None] = mapped_column(ForeignKey("documents.id"))
    depends_on: Mapped[list[int]] = mapped_column(JSONType, default=list)  # seq numbers; [] = previous op
    subcontracted: Mapped[bool] = mapped_column(Boolean, default=False)
    subcontract_supplier_id: Mapped[int | None] = mapped_column(ForeignKey("suppliers.id"))
    subcontract_lead_days: Mapped[int] = mapped_column(Integer, default=0)
    reports_output: Mapped[bool] = mapped_column(Boolean, default=False)
    routing: Mapped[Routing] = relationship(back_populates="operations")
