from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from fastapi import APIRouter
from pydantic import Field
from sqlalchemy import select

from ...api_deps import Body, CtxDep, IdemKey, idempotent
from ...core.context import row_dict
from ..registry.models import Item
from .models import (
    GoodsReceipt, PurchaseOrder, PurchaseOrderLine, PurchaseRequisition, SubstitutionRequest, Supplier, SupplierInvoice,
    SupplierReturn,
)
from .service import (
    acknowledge_po, approve_po, create_po, create_requisition, decide_requisition, decide_substitution, po_reconciliation,
    receive, record_invoice, request_substitution, return_to_supplier, send_po,
)

router = APIRouter(prefix="/api", tags=["purchasing"])


class ReqBody(Body):
    item_id: int
    quantity: Decimal = Field(gt=0)
    unit: str
    needed_by: date | None = None
    justification: str | None = None
    suggested_supplier_id: int | None = None


class DecideBody(Body):
    approve: bool
    note: str | None = None


class POLineBody(Body):
    item_id: int
    quantity: Decimal = Field(gt=0)
    unit: str | None = None
    unit_price: Decimal | None = Field(default=None, ge=0)
    currency: str | None = None
    expected_delivery: date | None = None
    specification_ref: str | None = None
    inspection_required: bool | None = None
    certificate_required: bool = False
    production_order_id: int | None = None


class POBody(Body):
    supplier_id: int
    lines: list[POLineBody]
    requisition_ids: list[int] = []
    order_date: date | None = None
    notes: str | None = None
    is_subcontract: bool = False


class VersionBody(Body):
    version: int


class AckBody(Body):
    ack_ref: str
    line_dates: dict[int, date] = {}


class ReceiptLineBody(Body):
    po_line_id: int
    quantity: Decimal = Field(gt=0)
    unit: str | None = None
    item_id: int | None = None
    supplier_lot: str | None = None
    lot_number: str | None = None
    damaged_quantity: Decimal = Field(default=Decimal(0), ge=0)
    certificate_document_id: int | None = None
    manufactured_on: date | None = None
    expiry_date: date | None = None
    serials: list[str] | None = None


class ReceiptBody(Body):
    lines: list[ReceiptLineBody]
    received_at: datetime | None = None
    delivery_note_ref: str | None = None
    carrier: str | None = None
    condition_note: str | None = None


class SubBody(Body):
    po_line_id: int
    proposed_item_id: int
    reason: str


class SupplierReturnBody(Body):
    lot_id: int
    bin: str
    quantity: Decimal = Field(gt=0)
    reason: str
    nonconformance_id: int | None = None
    rma_ref: str | None = None
    replacement_expected: bool = True


class InvoiceLineBody(Body):
    po_line_id: int
    quantity: Decimal = Field(gt=0)
    unit_price: Decimal = Field(ge=0)


class InvoiceBody(Body):
    supplier_id: int
    invoice_number: str
    invoice_date: date
    currency: str
    lines: list[InvoiceLineBody]


@router.get("/suppliers")
def suppliers(ctx: CtxDep):
    ctx.require("purchasing.read")
    return [row_dict(s) for s in ctx.db.execute(select(Supplier).order_by(Supplier.code)).scalars()]


@router.get("/requisitions")
def requisitions(ctx: CtxDep, status: str | None = None):
    ctx.require("purchasing.read")
    stmt = select(PurchaseRequisition).order_by(PurchaseRequisition.id.desc())
    if status:
        stmt = stmt.where(PurchaseRequisition.status == status)
    return [{**row_dict(r), "item_code": ctx.db.get(Item, r.item_id).item_code} for r in ctx.db.execute(stmt).scalars()]


@router.post("/requisitions", status_code=201)
def post_requisition(body: ReqBody, ctx: CtxDep):
    return row_dict(create_requisition(ctx, ctx.site_id, body.item_id, body.quantity, body.unit, body.needed_by,
                                       body.justification, suggested_supplier_id=body.suggested_supplier_id))


@router.post("/requisitions/{rid}/decide")
def post_decide_requisition(rid: int, body: DecideBody, ctx: CtxDep):
    return row_dict(decide_requisition(ctx, rid, body.approve, body.note))


@router.get("/purchase-orders")
def purchase_orders(ctx: CtxDep, status: str | None = None):
    ctx.require("purchasing.read")
    stmt = select(PurchaseOrder).order_by(PurchaseOrder.id.desc())
    if status:
        stmt = stmt.where(PurchaseOrder.status == status)
    return [po_reconciliation(ctx.db, po) for po in ctx.db.execute(stmt).scalars()]


@router.post("/purchase-orders", status_code=201)
def post_po(body: POBody, ctx: CtxDep):
    po = create_po(ctx, ctx.site_id, body.supplier_id, [{k: v for k, v in l.model_dump().items() if v is not None} for l in body.lines],
                   order_date=body.order_date, requisition_ids=body.requisition_ids, notes=body.notes, is_subcontract=body.is_subcontract)
    return po_reconciliation(ctx.db, po)


@router.get("/purchase-orders/{po_id}")
def get_po(po_id: int, ctx: CtxDep):
    ctx.require("purchasing.read")
    po = ctx.get(PurchaseOrder, po_id)
    d = po_reconciliation(ctx.db, po)
    d["receipts"] = [{**row_dict(r), "lines": [row_dict(l) for l in r.lines]}
                     for r in ctx.db.execute(select(GoodsReceipt).where(GoodsReceipt.po_id == po_id)).scalars()]
    d["substitutions"] = [row_dict(s) for s in ctx.db.execute(select(SubstitutionRequest).join(PurchaseOrderLine)
                                                              .where(PurchaseOrderLine.po_id == po_id)).scalars()]
    return d


@router.post("/purchase-orders/{po_id}/approve")
def post_approve_po(po_id: int, body: VersionBody, ctx: CtxDep):
    return row_dict(approve_po(ctx, po_id, body.version))


@router.post("/purchase-orders/{po_id}/send")
def post_send_po(po_id: int, ctx: CtxDep):
    return send_po(ctx, po_id)


@router.post("/purchase-orders/{po_id}/acknowledge")
def post_ack_po(po_id: int, body: AckBody, ctx: CtxDep):
    return row_dict(acknowledge_po(ctx, po_id, body.ack_ref, body.line_dates))


@router.post("/purchase-orders/{po_id}/receipts", status_code=201)
def post_receipt(po_id: int, body: ReceiptBody, ctx: CtxDep, idem: IdemKey = None):
    def run():
        gr = receive(ctx, po_id, [{k: v for k, v in l.model_dump().items() if v is not None} for l in body.lines],
                     received_at=body.received_at, delivery_note_ref=body.delivery_note_ref, carrier=body.carrier,
                     condition_note=body.condition_note, idempotency_key=idem)
        return {**row_dict(gr), "lines": [row_dict(l) for l in gr.lines]}
    return idempotent(ctx, "receipt", idem, body.model_dump(), run)


@router.get("/receipts")
def receipts(ctx: CtxDep):
    ctx.require("purchasing.read")
    return [{**row_dict(r), "lines": [row_dict(l) for l in r.lines]}
            for r in ctx.db.execute(select(GoodsReceipt).order_by(GoodsReceipt.id.desc())).scalars()]


@router.post("/substitutions", status_code=201)
def post_sub(body: SubBody, ctx: CtxDep):
    return row_dict(request_substitution(ctx, body.po_line_id, body.proposed_item_id, body.reason))


@router.post("/substitutions/{sid}/decide")
def post_decide_sub(sid: int, body: DecideBody, ctx: CtxDep):
    return row_dict(decide_substitution(ctx, sid, body.approve, body.note or ""))


@router.get("/supplier-returns")
def supplier_returns(ctx: CtxDep):
    ctx.require("purchasing.read")
    return [row_dict(r) for r in ctx.db.execute(select(SupplierReturn).order_by(SupplierReturn.id.desc())).scalars()]


@router.post("/supplier-returns", status_code=201)
def post_supplier_return(body: SupplierReturnBody, ctx: CtxDep):
    return row_dict(return_to_supplier(ctx, body.lot_id, body.bin, body.quantity, body.reason,
                                       nonconformance_id=body.nonconformance_id, rma_ref=body.rma_ref,
                                       replacement_expected=body.replacement_expected))


@router.get("/invoices")
def invoices(ctx: CtxDep):
    ctx.require("purchasing.read")
    return [row_dict(i) for i in ctx.db.execute(select(SupplierInvoice).order_by(SupplierInvoice.id.desc())).scalars()]


@router.post("/invoices", status_code=201)
def post_invoice(body: InvoiceBody, ctx: CtxDep):
    return row_dict(record_invoice(ctx, body.supplier_id, body.invoice_number, body.invoice_date, body.currency,
                                   [l.model_dump() for l in body.lines]))
