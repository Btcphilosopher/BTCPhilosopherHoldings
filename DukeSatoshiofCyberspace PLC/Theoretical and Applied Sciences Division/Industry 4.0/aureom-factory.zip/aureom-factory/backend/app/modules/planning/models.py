"""Demand, MRP runs/proposals and scheduling runs."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import Date, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ...core.models import JSONType
from ...db import Base, Qty, TimestampMixin


class Demand(Base, TimestampMixin):
    __tablename__ = "demands"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)  # base unit
    due_date: Mapped[date] = mapped_column(Date)
    kind: Mapped[str] = mapped_column(String(16), default="customer_order")  # customer_order / forecast
    customer_id: Mapped[int | None] = mapped_column(ForeignKey("customers.id"))
    customer_order_line_id: Mapped[int | None] = mapped_column(ForeignKey("customer_order_lines.id"))
    status: Mapped[str] = mapped_column(String(16), default="open")  # open / planned / fulfilled / cancelled
    note: Mapped[str | None] = mapped_column(Text)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))


class MrpRun(Base, TimestampMixin):
    __tablename__ = "mrp_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    as_of: Mapped[date] = mapped_column(Date)
    horizon_days: Mapped[int] = mapped_column(Integer, default=90)
    status: Mapped[str] = mapped_column(String(16), default="complete")
    parameters: Mapped[dict[str, Any]] = mapped_column(JSONType, default=dict)
    lines: Mapped[list[dict[str, Any]]] = mapped_column(JSONType, default=list)  # per-item netting explanation
    warnings: Mapped[list[str]] = mapped_column(JSONType, default=list)
    run_by: Mapped[int] = mapped_column(ForeignKey("users.id"))


class MrpProposal(Base, TimestampMixin):
    """A suggestion only. Accepting it creates a requisition or a draft order; nothing is released or approved."""

    __tablename__ = "mrp_proposals"
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("mrp_runs.id"), index=True)
    kind: Mapped[str] = mapped_column(String(16))  # purchase / production
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)  # base unit
    order_quantity: Mapped[Decimal] = mapped_column(Qty)  # in order_unit after lot sizing
    order_unit: Mapped[str] = mapped_column(String(16))
    need_date: Mapped[date] = mapped_column(Date)
    release_date: Mapped[date] = mapped_column(Date)
    supplier_id: Mapped[int | None] = mapped_column(ForeignKey("suppliers.id"))
    late: Mapped[bool] = mapped_column(default=False)
    expected_available: Mapped[date | None] = mapped_column(Date)
    explanation: Mapped[list[str]] = mapped_column(JSONType, default=list)
    status: Mapped[str] = mapped_column(String(16), default="proposed")  # proposed / accepted / rejected
    decided_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_record_type: Mapped[str | None] = mapped_column(String(32))
    created_record_id: Mapped[int | None] = mapped_column(Integer)


class ScheduleRun(Base, TimestampMixin):
    __tablename__ = "schedule_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    start_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    horizon_days: Mapped[int] = mapped_column(Integer)
    result: Mapped[dict[str, Any]] = mapped_column(JSONType)
    run_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
