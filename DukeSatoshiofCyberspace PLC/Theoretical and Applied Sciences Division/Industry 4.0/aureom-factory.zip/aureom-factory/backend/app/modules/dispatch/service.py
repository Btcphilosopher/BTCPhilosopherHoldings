"""Finished goods allocation, picking, packing, dispatch, delivery, customer returns and recalls.

Only ACCEPTED stock in allocatable finished-goods bins can be allocated to customers. Returned
products enter a review workflow (awaiting_review in a returns bin + nonconformance) and never
become saleable automatically.
"""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...core.context import Ctx, check_version, row_dict, utcnow
from ...core.errors import InvalidState, QualityHold, ValidationFailed
from ...core.numbers import D, ZERO, fmt, q
from ..genealogy.service import forward
from ..inventory.models import Bin, Lot, Reservation
from ..inventory.service import (
    bin_by_code, issue_reserved, lot_locations, lot_on_hand, post_movement, release_reservation, reserve, set_lot_status,
)
from ..registry.models import Item
from .models import Customer, CustomerOrder, CustomerOrderLine, CustomerReturn, Recall, RecallItem, Shipment, ShipmentLine


def create_customer_order(ctx: Ctx, site_id: int, customer_id: int, lines: list[dict], *, required_date=None,
                          customer_reference=None) -> CustomerOrder:
    ctx.require("dispatch.order", site_id)
    ctx.get(Customer, customer_id)
    co = CustomerOrder(number=ctx.next_number("SO"), site_id=site_id, customer_id=customer_id, required_date=required_date,
                       customer_reference=customer_reference, created_by=ctx.user.id)
    ctx.db.add(co)
    ctx.db.flush()
    for i, l in enumerate(lines, start=1):
        item = ctx.get(Item, l["item_id"])
        if item.item_type != "finished_product":
            raise ValidationFailed(f"{item.item_code} is not a finished product")
        co.lines.append(CustomerOrderLine(line_no=i * 10, item_id=item.id, quantity_ordered=D(l["quantity"]),
                                          unit_price=l.get("unit_price"), currency=l.get("currency", "GBP")))
    ctx.db.flush()
    ctx.audit("customer_order.create", "customer_order", co.id, after=row_dict(co), site_id=site_id)
    return co


def allocate_line(ctx: Ctx, line_id: int, quantity=None) -> list[Reservation]:
    ctx.require("dispatch.pick")
    line = ctx.get(CustomerOrderLine, line_id)
    qty = D(quantity) if quantity is not None else D(line.quantity_ordered) - D(line.quantity_allocated) - D(line.quantity_dispatched)
    if qty <= 0:
        return []
    item = ctx.db.get(Item, line.item_id)
    res = reserve(ctx, item, qty, "customer_order_line", line.id)
    line.quantity_allocated = q(D(line.quantity_allocated) + qty)
    return res


def create_shipment(ctx: Ctx, customer_order_id: int, lines: list[dict]) -> Shipment:
    """lines: [{order_line_id, quantity}] — picks from the line's reservations (lot by lot)."""
    ctx.require("dispatch.pick")
    co = ctx.get(CustomerOrder, customer_order_id)
    sh = Shipment(number=ctx.next_number("SH"), customer_order_id=co.id, customer_id=co.customer_id, created_by=ctx.user.id)
    ctx.db.add(sh)
    ctx.db.flush()
    for l in lines:
        line = ctx.get(CustomerOrderLine, l["order_line_id"])
        need = D(l["quantity"])
        for r in ctx.db.execute(select(Reservation).where(Reservation.demand_type == "customer_order_line",
                                                          Reservation.demand_id == line.id, Reservation.status == "active")
                                .order_by(Reservation.id)).scalars():
            if need <= 0:
                break
            already = sum((D(x.quantity) for x in ctx.db.execute(select(ShipmentLine).join(Shipment).where(
                ShipmentLine.reservation_id == r.id, Shipment.status == "picking")).scalars()), ZERO)
            avail = D(r.quantity) - D(r.quantity_issued) - already
            take = min(need, avail)
            if take <= 0:
                continue
            sh.lines.append(ShipmentLine(order_line_id=line.id, item_id=line.item_id, lot_id=r.lot_id, quantity=take,
                                         reservation_id=r.id))
            need -= take
        if need > 0:
            raise ValidationFailed(f"Line {line.line_no}: {fmt(need)} more than allocated stock; allocate first")
    ctx.db.flush()
    ctx.audit("shipment.create", "shipment", sh.id, after={"lines": len(sh.lines)})
    return sh


def pick(ctx: Ctx, shipment_id: int, scanned_lot_ids: list[int], *, to_bin_code: str = "DSP-01", observed_at=None) -> Shipment:
    ctx.require("dispatch.pick")
    sh = ctx.get(Shipment, shipment_id)
    if sh.status != "picking":
        raise InvalidState(f"{sh.number} is {sh.status}")
    to_bin = bin_by_code(ctx.db, to_bin_code)
    wanted = {l.lot_id: l for l in sh.lines}
    for lid in scanned_lot_ids:
        sl = wanted.get(lid)
        if sl is None:
            lot = ctx.db.get(Lot, lid)
            raise ValidationFailed(f"Scanned {lot.lot_number if lot else lid} is not on this pick list")
        if sl.picked:
            continue
        r = ctx.db.get(Reservation, sl.reservation_id)
        issue_reserved(ctx, r, sl.quantity, to_bin, reference_type="shipment", reference_id=sh.id,
                       reference_line_id=sl.id, value_source="scanned", observed_at=observed_at)
        sl.picked = True
        col = ctx.db.get(CustomerOrderLine, sl.order_line_id)
        col.quantity_picked = q(D(col.quantity_picked) + D(sl.quantity))
    return sh


def pack(ctx: Ctx, shipment_id: int, packages: list[dict]) -> Shipment:
    ctx.require("dispatch.pick")
    sh = ctx.get(Shipment, shipment_id)
    if any(not l.picked for l in sh.lines):
        raise InvalidState("All lines must be picked before packing")
    by_lot = {l.lot_id: l for l in sh.lines}
    for p in packages:
        for lid in p["lot_ids"]:
            by_lot[lid].package_ref = p["ref"]
    if any(l.package_ref is None for l in sh.lines):
        raise ValidationFailed("Every picked unit must be assigned to a package")
    sh.packages = [{"ref": p["ref"], "weight_kg": p.get("weight_kg"), "units": len(p["lot_ids"])} for p in packages]
    for l in sh.lines:
        col = ctx.db.get(CustomerOrderLine, l.order_line_id)
        col.quantity_packed = q(D(col.quantity_packed) + D(l.quantity))
    sh.status = "packed"
    return sh


def dispatch_shipment(ctx: Ctx, shipment_id: int, carrier: str, tracking_ref: str, dispatched_at=None,
                      from_bin_code: str = "DSP-01") -> Shipment:
    ctx.require("dispatch.ship")
    sh = ctx.get(Shipment, shipment_id)
    if sh.status != "packed":
        raise InvalidState(f"{sh.number} is {sh.status}; pack it first")
    b = bin_by_code(ctx.db, from_bin_code)
    dispatched_at = dispatched_at or utcnow()
    for l in sh.lines:
        lot = ctx.db.get(Lot, l.lot_id)
        if lot.quality_status != "accepted":
            raise QualityHold(f"{lot.lot_number} is {lot.quality_status}; it cannot be dispatched")
        item = ctx.db.get(Item, l.item_id)
        post_movement(ctx, "dispatch", item, l.quantity, item.base_unit, lot=lot, from_bin=b, reference_type="shipment",
                      reference_id=sh.id, reference_line_id=l.id, observed_at=dispatched_at, value_source="scanned")
        col = ctx.db.get(CustomerOrderLine, l.order_line_id)
        col.quantity_dispatched = q(D(col.quantity_dispatched) + D(l.quantity))
    sh.status, sh.carrier, sh.tracking_ref, sh.dispatched_at = "dispatched", carrier, tracking_ref, dispatched_at
    co = ctx.db.get(CustomerOrder, sh.customer_order_id)
    co.status = "shipped" if all(D(l.quantity_dispatched) >= D(l.quantity_ordered) for l in co.lines) else "partially_shipped"
    ctx.audit("shipment.dispatch", "shipment", sh.id, after={"carrier": carrier, "tracking": tracking_ref})
    ctx.emit("dispatch.shipped", {"shipment": sh.number, "units": str(sum(D(l.quantity) for l in sh.lines))})
    return sh


def confirm_delivery(ctx: Ctx, shipment_id: int, delivery_ref: str, delivered_at=None) -> Shipment:
    ctx.require("dispatch.ship")
    sh = ctx.get(Shipment, shipment_id)
    if sh.status != "dispatched":
        raise InvalidState(f"{sh.number} is {sh.status}")
    sh.status, sh.delivery_ref, sh.delivered_at = "delivered", delivery_ref, delivered_at or utcnow()
    for l in sh.lines:
        col = ctx.db.get(CustomerOrderLine, l.order_line_id)
        col.quantity_delivered = q(D(col.quantity_delivered) + D(l.quantity))
    ctx.audit("shipment.delivered", "shipment", sh.id, after={"delivery_ref": delivery_ref})
    return sh


def receive_customer_return(ctx: Ctx, customer_id: int, lot_id: int, quantity, reason: str, *, shipment_line_id=None,
                            recall_id=None, received_at=None, to_bin_code: str = "RTN-01") -> CustomerReturn:
    """Returned goods are held for review: awaiting_review, returns bin, nonconformance raised."""
    ctx.require("dispatch.returns")
    lot = ctx.get(Lot, lot_id)
    item = ctx.db.get(Item, lot.item_id)
    received_at = received_at or utcnow()
    cr = CustomerReturn(number=ctx.next_number("RMA"), customer_id=customer_id, shipment_line_id=shipment_line_id,
                        lot_id=lot.id, quantity=D(quantity), reason=reason, recall_id=recall_id, received_at=received_at,
                        received_by=ctx.user.id)
    ctx.db.add(cr)
    ctx.db.flush()
    post_movement(ctx, "customer_return", item, quantity, item.base_unit, lot=lot, to_bin=bin_by_code(ctx.db, to_bin_code),
                  reference_type="customer_return", reference_id=cr.id, observed_at=received_at, skip_quality_gate=True,
                  notes=reason)
    set_lot_status(ctx, lot, "awaiting_review", f"Customer return {cr.number}: {reason}", "customer_return", cr.id, system=True)
    from ..quality.service import raise_ncr
    ncr = raise_ncr(ctx, source="customer_return", item_id=item.id, lot_ids=[lot.id], quantity=quantity,
                    description=f"Customer return {cr.number}: {reason}", _skip_perm=True)
    cr.nonconformance_id = ncr.id
    if shipment_line_id:
        sl = ctx.db.get(ShipmentLine, shipment_line_id)
        col = ctx.db.get(CustomerOrderLine, sl.order_line_id)
        col.quantity_returned = q(D(col.quantity_returned) + D(quantity))
    ctx.audit("customer_return.receive", "customer_return", cr.id, after=row_dict(cr))
    return cr


# --------------------------------------------------------------------------- recall


def open_recall(ctx: Ctx, title: str, description: str, trigger_lot_ids: list[int], *, hold_stock: bool = True) -> Recall:
    """Investigate a recall: forward-trace each trigger lot, classify every affected lot by where it is
    now, and (optionally) place affected stock on hold. Confirmed and possible links are kept apart."""
    ctx.require("dispatch.recall")
    rc = Recall(number=ctx.next_number("RCL"), title=title, description=description, trigger_lot_ids=trigger_lot_ids,
                created_by=ctx.user.id)
    ctx.db.add(rc)
    ctx.db.flush()
    seen: dict[int, RecallItem] = {}
    traces = []
    for tl in trigger_lot_ids:
        tr = forward(ctx.db, tl)
        traces.append({"trigger": tr["lot"]["lot_number"], "summary": tr["summary"]})
        candidates = [{**tr["lot"], "precision": "exact"}] + tr["reached"]
        for r in candidates:
            lot = ctx.db.get(Lot, r["lot_id"])
            locs = lot_locations(ctx.db, lot.id)
            ships = r.get("shipments") or []
            entries = []
            for s in ships:
                entries.append(("shipped", D(s["quantity"]), s["customer_id"], s["shipment_id"]))
            for loc in locs:
                kind = {"wip": "wip", "subcontractor": "at_subcontractor"}.get(loc["bin_kind"], "in_stock")
                entries.append((kind, D(loc["quantity"]), None, None))
            if not entries:
                entries.append(("consumed", ZERO, None, None))
            for kind, qty, cust, ship in entries:
                key = (lot.id, kind, ship)
                if key in seen:
                    continue
                ri = RecallItem(recall_id=rc.id, lot_id=lot.id, precision=r["precision"], location_kind=kind, customer_id=cust,
                                shipment_id=ship, quantity=qty)
                rc.items.append(ri)
                seen[key] = ri
                if hold_stock and kind in ("in_stock", "wip", "at_subcontractor") and lot.quality_status == "accepted":
                    set_lot_status(ctx, lot, "quarantined", f"Recall {rc.number} investigation ({r['precision']})",
                                   "recall", rc.id, system=True)
                    ri.action = "quarantined"
    ctx.db.flush()
    rc.findings = recall_findings(ctx.db, rc) | {"traces": traces}
    ctx.audit("recall.open", "recall", rc.id, after={"title": title, "items": len(rc.items)})
    ctx.emit("dispatch.recall", {"number": rc.number, "title": title})
    return rc


def recall_findings(db: Session, rc: Recall) -> dict:
    out = {"by_location": {}, "by_precision": {}, "customers": {}, "finished_units": {"confirmed": 0, "possible": 0, "unknown": 0}}
    for ri in rc.items:
        lot = db.get(Lot, ri.lot_id)
        item = db.get(Item, lot.item_id)
        out["by_location"][ri.location_kind] = out["by_location"].get(ri.location_kind, 0) + 1
        out["by_precision"][ri.precision] = out["by_precision"].get(ri.precision, 0) + 1
        if item.item_type == "finished_product" and ri.location_kind != "consumed":
            key = {"exact": "confirmed", "order_level": "possible", "unknown": "unknown"}[ri.precision]
            out["finished_units"][key] += 1
        if ri.customer_id:
            c = db.get(Customer, ri.customer_id)
            sh = db.get(Shipment, ri.shipment_id)
            out["customers"].setdefault(c.name, []).append({"lot": lot.lot_number, "shipment": sh.number,
                                                            "precision": ri.precision, "delivery_ref": sh.delivery_ref})
    out["statement"] = ("Confirmed units are linked by direct records. Possible units share a production order with an "
                        "affected input but have no unit-level record; treat them as in scope unless excluded by inspection.")
    return out


def shipment_detail(db: Session, sh: Shipment) -> dict:
    d = row_dict(sh)
    d["customer"] = db.get(Customer, sh.customer_id).name
    d["order"] = db.get(CustomerOrder, sh.customer_order_id).number
    d["lines"] = [{**row_dict(l), "lot_number": db.get(Lot, l.lot_id).lot_number if l.lot_id else None,
                   "item_code": db.get(Item, l.item_id).item_code} for l in sh.lines]
    return d


def order_line_status(db: Session, co: CustomerOrder) -> list[dict]:
    from ..production.models import ProductionOrder
    out = []
    for l in co.lines:
        item = db.get(Item, l.item_id)
        out.append({**row_dict(l), "item_code": item.item_code,
                    "explanation": "ordered / allocated / picked / packed / dispatched / delivered / returned are separate counts"})
    return out
