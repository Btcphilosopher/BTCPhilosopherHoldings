"""Stock: locations, lots/serials, an append-only movement journal, balances and reservations."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import (
    BigInteger, Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, String, Text,
    UniqueConstraint, func,
)
from sqlalchemy.orm import Mapped, mapped_column

from ...core.models import JSONType
from ...db import Base, Money, Qty, TimestampMixin

QUALITY_STATUSES = ("awaiting_review", "quarantined", "accepted", "rejected")
BIN_KINDS = ("receiving", "storage", "quarantine", "wip", "finished", "dispatch", "scrap", "returns", "subcontractor")
OWNERSHIP = ("company", "customer", "supplier_consignment")
MOVEMENT_TYPES = (
    "receipt", "transfer", "issue", "return", "consumption", "production_output", "quarantine", "scrap",
    "adjustment", "dispatch", "supplier_return", "subcontract_send", "subcontract_return",
    "customer_return", "reversal",
)
VALUE_SOURCES = ("scanned", "manual", "measured", "calculated", "system", "imported")


class Warehouse(Base, TimestampMixin):
    __tablename__ = "warehouses"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    code: Mapped[str] = mapped_column(String(32), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    kind: Mapped[str] = mapped_column(String(16), default="internal")  # internal / subcontractor
    supplier_id: Mapped[int | None] = mapped_column(ForeignKey("suppliers.id"))  # for subcontractor sites


class Bin(Base, TimestampMixin):
    __tablename__ = "bins"
    __table_args__ = (CheckConstraint(f"kind IN {BIN_KINDS}", name="kind"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    warehouse_id: Mapped[int] = mapped_column(ForeignKey("warehouses.id"))
    code: Mapped[str] = mapped_column(String(32), unique=True)
    kind: Mapped[str] = mapped_column(String(16))
    # Only allocatable bins contribute to AVAILABLE stock. Receiving, quarantine, scrap, returns,
    # subcontractor and dispatch bins hold physical stock that cannot be allocated.
    allocatable: Mapped[bool] = mapped_column(Boolean, default=False)
    description: Mapped[str | None] = mapped_column(String(200))


class Lot(Base, TimestampMixin):
    """A lot, batch or (for serial-controlled items) a single serial number."""

    __tablename__ = "lots"
    __table_args__ = (
        UniqueConstraint("item_id", "lot_number"),
        CheckConstraint(f"quality_status IN {QUALITY_STATUSES}", name="quality_status"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"), index=True)
    lot_number: Mapped[str] = mapped_column(String(64))
    is_serial: Mapped[bool] = mapped_column(Boolean, default=False)
    batch_ref: Mapped[str | None] = mapped_column(String(64))  # production batch for serials
    origin: Mapped[str] = mapped_column(String(32))  # purchase / production / split / merge / opening / return / subcontract
    supplier_id: Mapped[int | None] = mapped_column(ForeignKey("suppliers.id"))
    supplier_lot: Mapped[str | None] = mapped_column(String(100), index=True)
    receipt_line_id: Mapped[int | None] = mapped_column(ForeignKey("receipt_lines.id"))
    production_order_id: Mapped[int | None] = mapped_column(ForeignKey("production_orders.id"))
    quality_status: Mapped[str] = mapped_column(String(16), default="awaiting_review")
    expiry_date: Mapped[date | None] = mapped_column(Date)
    manufactured_on: Mapped[date | None] = mapped_column(Date)
    # complete / partial / unknown — honest statement of how much provenance is on record.
    traceability: Mapped[str] = mapped_column(String(16), default="complete")
    traceability_note: Mapped[str | None] = mapped_column(Text)
    unit_cost: Mapped[Decimal | None] = mapped_column(Money)  # base currency per base unit
    cost_basis: Mapped[str | None] = mapped_column(String(64))
    cost_components: Mapped[dict[str, Any] | None] = mapped_column(JSONType)
    attributes: Mapped[dict[str, Any]] = mapped_column(JSONType, default=dict)


class LotStatusHistory(Base):
    """Append-only record of every quality-status change and who authorised it."""

    __tablename__ = "lot_status_history"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    lot_id: Mapped[int] = mapped_column(ForeignKey("lots.id"), index=True)
    from_status: Mapped[str | None] = mapped_column(String(16))
    to_status: Mapped[str] = mapped_column(String(16))
    reason: Mapped[str] = mapped_column(Text)
    reference_type: Mapped[str | None] = mapped_column(String(32))
    reference_id: Mapped[int | None] = mapped_column(Integer)
    changed_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    changed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class StockMovement(Base):
    """Append-only journal (UPDATE/DELETE blocked by trigger). Corrections are linked reversals."""

    __tablename__ = "stock_movements"
    __table_args__ = (
        CheckConstraint("quantity > 0", name="qty_positive"),
        CheckConstraint(f"movement_type IN {MOVEMENT_TYPES}", name="movement_type"),
        CheckConstraint(f"value_source IN {VALUE_SOURCES}", name="value_source"),
        CheckConstraint("from_bin_id IS NOT NULL OR to_bin_id IS NOT NULL", name="has_location"),
        UniqueConstraint("reverses_movement_id"),
        Index("ix_stock_movements_ref", "reference_type", "reference_id"),
    )
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    movement_no: Mapped[str] = mapped_column(String(32), unique=True)
    movement_type: Mapped[str] = mapped_column(String(32))
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"), index=True)
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"), index=True)
    from_bin_id: Mapped[int | None] = mapped_column(ForeignKey("bins.id"))
    to_bin_id: Mapped[int | None] = mapped_column(ForeignKey("bins.id"))
    ownership: Mapped[str] = mapped_column(String(32), default="company")
    quantity: Mapped[Decimal] = mapped_column(Qty)  # base unit, always positive
    entered_quantity: Mapped[Decimal] = mapped_column(Qty)
    entered_unit: Mapped[str] = mapped_column(ForeignKey("units.code"))
    value_source: Mapped[str] = mapped_column(String(16), default="manual")
    reference_type: Mapped[str | None] = mapped_column(String(32))
    reference_id: Mapped[int | None] = mapped_column(Integer)
    reference_line_id: Mapped[int | None] = mapped_column(Integer)
    reason_code: Mapped[str | None] = mapped_column(String(64))
    notes: Mapped[str | None] = mapped_column(Text)
    reverses_movement_id: Mapped[int | None] = mapped_column(ForeignKey("stock_movements.id"))
    unit_cost: Mapped[Decimal | None] = mapped_column(Money)
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))  # when it physically happened
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    recorded_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    idempotency_key: Mapped[str | None] = mapped_column(String(100), unique=True)


class StockBalance(Base):
    """Transactional on-hand balance per item / lot / bin / ownership. Never negative."""

    __tablename__ = "stock_balances"
    __table_args__ = (
        UniqueConstraint("item_id", "lot_id", "bin_id", "ownership", postgresql_nulls_not_distinct=True),
        CheckConstraint("quantity >= 0", name="non_negative"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"), index=True)
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"), index=True)
    bin_id: Mapped[int] = mapped_column(ForeignKey("bins.id"))
    ownership: Mapped[str] = mapped_column(String(32), default="company")
    quantity: Mapped[Decimal] = mapped_column(Qty, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class Reservation(Base, TimestampMixin):
    __tablename__ = "reservations"
    __table_args__ = (CheckConstraint("quantity > 0", name="qty"), CheckConstraint("quantity_issued >= 0", name="issued"))
    id: Mapped[int] = mapped_column(primary_key=True)
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"), index=True)
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"), index=True)
    bin_id: Mapped[int | None] = mapped_column(ForeignKey("bins.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    quantity_issued: Mapped[Decimal] = mapped_column(Qty, default=0)
    demand_type: Mapped[str] = mapped_column(String(32))  # production_material / customer_order_line
    demand_id: Mapped[int] = mapped_column(Integer, index=True)
    status: Mapped[str] = mapped_column(String(16), default="active")  # active / fulfilled / released
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    released_reason: Mapped[str | None] = mapped_column(Text)
