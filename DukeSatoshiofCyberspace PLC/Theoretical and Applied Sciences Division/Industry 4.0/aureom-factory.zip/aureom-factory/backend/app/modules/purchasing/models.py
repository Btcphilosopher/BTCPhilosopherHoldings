"""Procurement: suppliers, requisitions, purchase orders, receipts, invoices and supplier returns."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ...core.models import JSONType
from ...db import Base, Money, Qty, TimestampMixin


class Supplier(Base, TimestampMixin):
    __tablename__ = "suppliers"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(32), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    currency: Mapped[str] = mapped_column(String(3), default="GBP")
    country: Mapped[str | None] = mapped_column(String(2))
    approved: Mapped[bool] = mapped_column(Boolean, default=True)
    is_subcontractor: Mapped[bool] = mapped_column(Boolean, default=False)
    contact_email: Mapped[str | None] = mapped_column(String(200))
    notes: Mapped[str | None] = mapped_column(Text)


class PurchaseRequisition(Base, TimestampMixin):
    __tablename__ = "purchase_requisitions"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    unit: Mapped[str] = mapped_column(ForeignKey("units.code"))
    needed_by: Mapped[date | None] = mapped_column(Date)
    suggested_supplier_id: Mapped[int | None] = mapped_column(ForeignKey("suppliers.id"))
    source: Mapped[str] = mapped_column(String(16), default="manual")  # manual / mrp
    mrp_proposal_id: Mapped[int | None] = mapped_column(ForeignKey("mrp_proposals.id"))
    status: Mapped[str] = mapped_column(String(16), default="draft")  # draft/submitted/approved/rejected/converted/cancelled
    justification: Mapped[str | None] = mapped_column(Text)
    requested_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    approved_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    purchase_order_line_id: Mapped[int | None] = mapped_column(ForeignKey("po_lines.id", use_alter=True))
    __table_args__ = (CheckConstraint("quantity > 0", name="qty"),)


class PurchaseOrder(Base, TimestampMixin):
    __tablename__ = "purchase_orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    supplier_id: Mapped[int] = mapped_column(ForeignKey("suppliers.id"))
    currency: Mapped[str] = mapped_column(String(3))
    status: Mapped[str] = mapped_column(String(24), default="draft")
    # draft / approved / sent / acknowledged / partially_received / received / closed / cancelled
    order_date: Mapped[date | None] = mapped_column(Date)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    approved_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    acknowledged_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    supplier_ack_ref: Mapped[str | None] = mapped_column(String(100))
    is_subcontract: Mapped[bool] = mapped_column(Boolean, default=False)
    notes: Mapped[str | None] = mapped_column(Text)
    version: Mapped[int] = mapped_column(Integer, default=1)
    __mapper_args__ = {"version_id_col": version}
    lines: Mapped[list["PurchaseOrderLine"]] = relationship(back_populates="po", cascade="all, delete-orphan",
                                                            order_by="PurchaseOrderLine.line_no")


class PurchaseOrderLine(Base):
    """Ordered, received, accepted, rejected, returned and invoiced quantities are kept separately (PO unit)."""

    __tablename__ = "po_lines"
    __table_args__ = (
        CheckConstraint("quantity_ordered > 0", name="qty"),
        CheckConstraint("unit_price >= 0", name="price"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    po_id: Mapped[int] = mapped_column(ForeignKey("purchase_orders.id", ondelete="CASCADE"))
    line_no: Mapped[int] = mapped_column(Integer)
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    specification_ref: Mapped[str | None] = mapped_column(String(200))
    quantity_ordered: Mapped[Decimal] = mapped_column(Qty)
    unit: Mapped[str] = mapped_column(ForeignKey("units.code"))
    unit_price: Mapped[Decimal] = mapped_column(Money)
    currency: Mapped[str] = mapped_column(String(3))
    price_date: Mapped[date] = mapped_column(Date)
    expected_delivery: Mapped[date | None] = mapped_column(Date)
    acknowledged_delivery: Mapped[date | None] = mapped_column(Date)
    inspection_required: Mapped[bool] = mapped_column(Boolean, default=True)
    certificate_required: Mapped[bool] = mapped_column(Boolean, default=False)
    quantity_received: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_accepted: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_rejected: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_returned: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_invoiced: Mapped[Decimal] = mapped_column(Qty, default=0)
    status: Mapped[str] = mapped_column(String(24), default="open")  # open / partially_received / received / closed / cancelled
    production_order_id: Mapped[int | None] = mapped_column(ForeignKey("production_orders.id", use_alter=True))
    po: Mapped[PurchaseOrder] = relationship(back_populates="lines")


class SubstitutionRequest(Base, TimestampMixin):
    """A supplier offers a different item/specification. It must be approved before receipt."""

    __tablename__ = "substitution_requests"
    id: Mapped[int] = mapped_column(primary_key=True)
    po_line_id: Mapped[int] = mapped_column(ForeignKey("po_lines.id"))
    proposed_item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16), default="pending")  # pending / approved / rejected
    requested_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    decided_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    decision_note: Mapped[str | None] = mapped_column(Text)


class GoodsReceipt(Base, TimestampMixin):
    __tablename__ = "goods_receipts"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    po_id: Mapped[int] = mapped_column(ForeignKey("purchase_orders.id"))
    supplier_id: Mapped[int] = mapped_column(ForeignKey("suppliers.id"))
    delivery_note_ref: Mapped[str | None] = mapped_column(String(100))
    carrier: Mapped[str | None] = mapped_column(String(100))
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    received_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    late_days: Mapped[int] = mapped_column(Integer, default=0)
    condition_note: Mapped[str | None] = mapped_column(Text)
    idempotency_key: Mapped[str | None] = mapped_column(String(100), unique=True)
    lines: Mapped[list["ReceiptLine"]] = relationship(back_populates="receipt", cascade="all, delete-orphan")


class ReceiptLine(Base):
    __tablename__ = "receipt_lines"
    __table_args__ = (CheckConstraint("quantity > 0", name="qty"), CheckConstraint("damaged_quantity >= 0", name="damaged"))
    id: Mapped[int] = mapped_column(primary_key=True)
    receipt_id: Mapped[int] = mapped_column(ForeignKey("goods_receipts.id", ondelete="CASCADE"))
    po_line_id: Mapped[int] = mapped_column(ForeignKey("po_lines.id"))
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    substitution_request_id: Mapped[int | None] = mapped_column(ForeignKey("substitution_requests.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)  # in PO unit
    unit: Mapped[str] = mapped_column(ForeignKey("units.code"))
    base_quantity: Mapped[Decimal] = mapped_column(Qty)
    damaged_quantity: Mapped[Decimal] = mapped_column(Qty, default=0)  # PO unit, segregated at receipt
    supplier_lot: Mapped[str | None] = mapped_column(String(100))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id", use_alter=True))
    damaged_lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id", use_alter=True))
    certificate_document_id: Mapped[int | None] = mapped_column(ForeignKey("documents.id"))
    certificate_status: Mapped[str] = mapped_column(String(16), default="not_required")  # not_required/missing/received
    inspection_status: Mapped[str] = mapped_column(String(16), default="awaiting_review")
    unit_cost_base: Mapped[Decimal | None] = mapped_column(Money)  # base currency per base unit
    fx_rate: Mapped[Decimal | None] = mapped_column(Qty)
    fx_rate_date: Mapped[date | None] = mapped_column(Date)
    receipt: Mapped[GoodsReceipt] = relationship(back_populates="lines")


class SupplierInvoice(Base, TimestampMixin):
    __tablename__ = "supplier_invoices"
    id: Mapped[int] = mapped_column(primary_key=True)
    supplier_id: Mapped[int] = mapped_column(ForeignKey("suppliers.id"))
    invoice_number: Mapped[str] = mapped_column(String(64))
    invoice_date: Mapped[date] = mapped_column(Date)
    currency: Mapped[str] = mapped_column(String(3))
    status: Mapped[str] = mapped_column(String(16), default="matched")  # matched / variance / exported
    match_result: Mapped[dict | None] = mapped_column(JSONType)
    recorded_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    lines: Mapped[list["SupplierInvoiceLine"]] = relationship(cascade="all, delete-orphan")


class SupplierInvoiceLine(Base):
    __tablename__ = "supplier_invoice_lines"
    id: Mapped[int] = mapped_column(primary_key=True)
    invoice_id: Mapped[int] = mapped_column(ForeignKey("supplier_invoices.id", ondelete="CASCADE"))
    po_line_id: Mapped[int] = mapped_column(ForeignKey("po_lines.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    unit_price: Mapped[Decimal] = mapped_column(Money)


class SupplierReturn(Base, TimestampMixin):
    __tablename__ = "supplier_returns"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    supplier_id: Mapped[int] = mapped_column(ForeignKey("suppliers.id"))
    po_line_id: Mapped[int | None] = mapped_column(ForeignKey("po_lines.id"))
    receipt_line_id: Mapped[int | None] = mapped_column(ForeignKey("receipt_lines.id"))
    lot_id: Mapped[int] = mapped_column(ForeignKey("lots.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)  # base unit
    reason: Mapped[str] = mapped_column(Text)
    nonconformance_id: Mapped[int | None] = mapped_column(ForeignKey("nonconformances.id", use_alter=True))
    rma_ref: Mapped[str | None] = mapped_column(String(64))
    replacement_expected: Mapped[bool] = mapped_column(Boolean, default=True)
    status: Mapped[str] = mapped_column(String(16), default="shipped")  # shipped / credited / replaced
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
