from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from fastapi import APIRouter
from pydantic import Field
from sqlalchemy import select

from ...api_deps import Body, CtxDep
from ...core.context import row_dict
from ...core.errors import NotFound
from ..registry.models import Item
from .models import Demand, MrpProposal, MrpRun, ScheduleRun
from .service import accept_proposal, create_demand, reject_proposal, run_mrp, run_schedule

router = APIRouter(prefix="/api", tags=["planning"])


class DemandBody(Body):
    item_id: int
    quantity: Decimal = Field(gt=0)
    due_date: date
    kind: str = "customer_order"
    customer_id: int | None = None
    customer_order_line_id: int | None = None
    note: str | None = None


class MrpBody(Body):
    as_of: date | None = None
    horizon_days: int = Field(default=90, ge=1, le=365)


class AcceptBody(Body):
    quantity: Decimal | None = None
    supplier_id: int | None = None


class RejectBody(Body):
    reason: str


class ScheduleBody(Body):
    start_at: datetime | None = None
    horizon_days: int = Field(default=30, ge=1, le=120)
    apply: bool = True


def _run(ctx, run: MrpRun) -> dict:
    props = ctx.db.execute(select(MrpProposal).where(MrpProposal.run_id == run.id).order_by(MrpProposal.id)).scalars()
    return {**row_dict(run), "proposals": [{**row_dict(p), "item_code": ctx.db.get(Item, p.item_id).item_code,
                                            "description": ctx.db.get(Item, p.item_id).description} for p in props]}


@router.get("/demands")
def demands(ctx: CtxDep):
    ctx.require("planning.read")
    return [{**row_dict(d), "item_code": ctx.db.get(Item, d.item_id).item_code}
            for d in ctx.db.execute(select(Demand).order_by(Demand.due_date)).scalars()]


@router.post("/demands", status_code=201)
def post_demand(body: DemandBody, ctx: CtxDep):
    return row_dict(create_demand(ctx, ctx.site_id, **body.model_dump()))


@router.post("/mrp/runs", status_code=201)
def post_mrp(body: MrpBody, ctx: CtxDep):
    return _run(ctx, run_mrp(ctx, ctx.site_id, body.as_of, body.horizon_days))


@router.get("/mrp/runs/latest")
def latest_mrp(ctx: CtxDep):
    ctx.require("planning.read")
    run = ctx.db.execute(select(MrpRun).order_by(MrpRun.id.desc())).scalars().first()
    if run is None:
        raise NotFound("No MRP run yet")
    return _run(ctx, run)


@router.get("/mrp/runs/{rid}")
def get_mrp(rid: int, ctx: CtxDep):
    ctx.require("planning.read")
    return _run(ctx, ctx.get(MrpRun, rid))


@router.post("/mrp/proposals/{pid}/accept")
def post_accept(pid: int, body: AcceptBody, ctx: CtxDep):
    return accept_proposal(ctx, pid, quantity=body.quantity, supplier_id=body.supplier_id)


@router.post("/mrp/proposals/{pid}/reject")
def post_reject(pid: int, body: RejectBody, ctx: CtxDep):
    return row_dict(reject_proposal(ctx, pid, body.reason))


@router.post("/schedule/runs", status_code=201)
def post_schedule(body: ScheduleBody, ctx: CtxDep):
    return row_dict(run_schedule(ctx, ctx.site_id, body.start_at, body.horizon_days, body.apply))


@router.get("/schedule/latest")
def latest_schedule(ctx: CtxDep):
    ctx.require("planning.read")
    run = ctx.db.execute(select(ScheduleRun).order_by(ScheduleRun.id.desc())).scalars().first()
    if run is None:
        raise NotFound("No schedule run yet")
    return row_dict(run)
