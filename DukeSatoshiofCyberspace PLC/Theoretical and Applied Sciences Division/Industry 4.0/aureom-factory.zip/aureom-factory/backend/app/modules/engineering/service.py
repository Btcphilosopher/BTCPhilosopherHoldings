"""BOM and routing services: versioning, approval, cycle detection, explosion and snapshots."""
from __future__ import annotations

from datetime import date
from decimal import Decimal

from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session

from ...core.context import Ctx, check_version, jsonable, row_dict, utcnow
from ...core.errors import BomCycleError, InvalidState, NotFound, ValidationFailed
from ...core.numbers import D, q
from ..registry.models import Item
from ..registry.service import conversion_factor, get_unit
from .models import Bom, BomLine, Routing, RoutingOperation, WorkCentre

# --------------------------------------------------------------------------- cycle detection


def _component_graph(db: Session) -> dict[int, set[int]]:
    rows = db.execute(
        select(Bom.item_id, BomLine.component_item_id)
        .join(BomLine, BomLine.bom_id == Bom.id)
        .where(Bom.status.in_(("draft", "approved")))
    ).all()
    graph: dict[int, set[int]] = {}
    for parent, child in rows:
        graph.setdefault(parent, set()).add(child)
    return graph


def find_cycle_path(db: Session, parent_item_id: int, component_item_id: int) -> list[int] | None:
    """Would adding parent → component create a cycle? Returns the offending path if so."""
    if parent_item_id == component_item_id:
        return [parent_item_id, component_item_id]
    graph = _component_graph(db)
    stack = [(component_item_id, [parent_item_id, component_item_id])]
    seen = set()
    while stack:
        node, path = stack.pop()
        if node == parent_item_id:
            return path
        if node in seen:
            continue
        seen.add(node)
        for nxt in graph.get(node, ()):
            stack.append((nxt, path + [nxt]))
    return None


def detect_all_cycles(db: Session) -> list[list[int]]:
    graph = _component_graph(db)
    cycles, colour = [], {}

    def visit(n, path):
        colour[n] = 1
        for m in graph.get(n, ()):
            if colour.get(m) == 1:
                cycles.append(path[path.index(m):] + [m] if m in path else [n, m])
            elif colour.get(m) is None:
                visit(m, path + [m])
        colour[n] = 2

    for node in list(graph):
        if colour.get(node) is None:
            visit(node, [node])
    return cycles


def _codes(db: Session, ids: list[int]) -> list[str]:
    return [db.get(Item, i).item_code for i in ids]


# --------------------------------------------------------------------------- BOMs


def create_bom(ctx: Ctx, item_id: int, data: dict) -> Bom:
    ctx.require("engineering.edit")
    item = ctx.get(Item, item_id)
    if item.item_type not in ("wip", "subassembly", "finished_product"):
        raise ValidationFailed(f"{item.item_code} is a {item.item_type}; only made items have BOMs")
    last = ctx.db.execute(select(Bom.version).where(Bom.item_id == item_id).order_by(Bom.version.desc())).scalar()
    yield_pct = D(data.get("expected_yield_pct", 100))
    if not (0 < yield_pct <= 100):
        raise ValidationFailed("expected_yield_pct must be within (0, 100]")
    bom = Bom(
        item_id=item_id, version=(last or 0) + 1, status="draft",
        base_quantity=D(data.get("base_quantity", 1)), expected_yield_pct=yield_pct,
        effective_from=data.get("effective_from"), effective_to=data.get("effective_to"),
        change_note=data.get("change_note"), created_by=ctx.user.id,
    )
    ctx.db.add(bom)
    ctx.db.flush()
    for i, line in enumerate(data.get("lines", []), start=1):
        add_bom_line(ctx, bom.id, {**line, "line_no": line.get("line_no", i * 10)})
    ctx.audit("bom.create", "bom", bom.id, after=row_dict(bom))
    return bom


def add_bom_line(ctx: Ctx, bom_id: int, data: dict) -> BomLine:
    ctx.require("engineering.edit")
    bom = ctx.get(Bom, bom_id)
    if bom.status != "draft":
        raise InvalidState(f"BOM {bom.id} v{bom.version} is {bom.status}; create a new version to change it")
    comp = ctx.get(Item, data["component_item_id"], "Component item")
    get_unit(ctx.db, data["unit"])
    # The line unit must be convertible to the component's base unit.
    conversion_factor(ctx.db, data["unit"], comp.base_unit, comp.id)
    path = find_cycle_path(ctx.db, bom.item_id, comp.id)
    if path:
        raise BomCycleError(
            "Adding this component would create a circular bill of materials: " + " → ".join(_codes(ctx.db, path)),
            details={"path": _codes(ctx.db, path)},
        )
    basis = data.get("scrap_basis", "net_plus_loss")
    loss = D(data.get("loss_pct", 0))
    if basis == "allowance_in_quantity" and not data.get("allowance_note"):
        raise ValidationFailed("allowance_note is required when the quantity already includes an allowance")
    if basis not in ("net_plus_loss", "allowance_in_quantity"):
        raise ValidationFailed("scrap_basis must be net_plus_loss or allowance_in_quantity")
    line = BomLine(
        bom_id=bom.id, line_no=data["line_no"], component_item_id=comp.id, quantity=D(data["quantity"]),
        unit=data["unit"], loss_pct=loss, scrap_basis=basis, allowance_note=data.get("allowance_note"),
        is_packaging=bool(data.get("is_packaging", comp.item_type == "packaging")),
        backflush=bool(data.get("backflush", False)),
        alternative_group=data.get("alternative_group"), alternative_priority=data.get("alternative_priority", 1),
        alternative_approved=data.get("alternative_approved", True), operation_seq=data.get("operation_seq"),
        effective_from=data.get("effective_from"), effective_to=data.get("effective_to"),
    )
    if line.quantity <= 0:
        raise ValidationFailed("Component quantity must be positive")
    ctx.db.add(line)
    ctx.db.flush()
    return line


def approve_bom(ctx: Ctx, bom_id: int, version: int | None = None) -> Bom:
    ctx.require("engineering.approve")
    bom = ctx.get(Bom, bom_id)
    if version is not None and bom.row_version != version:
        from ...core.errors import Conflict
        raise Conflict(f"BOM {bom.id} changed (version {bom.row_version}, you sent {version})")
    if bom.status != "draft":
        raise InvalidState(f"BOM is {bom.status}")
    if not bom.lines:
        raise ValidationFailed("Cannot approve an empty BOM")
    if bom.created_by == ctx.user.id:
        raise ValidationFailed("Segregation of duties: the author of a BOM cannot approve it")
    for line in bom.lines:
        path = find_cycle_path(ctx.db, bom.item_id, line.component_item_id)
        if path:
            raise BomCycleError("Circular BOM: " + " → ".join(_codes(ctx.db, path)))
    groups: dict[str, list[BomLine]] = {}
    for line in bom.lines:
        if line.alternative_group:
            groups.setdefault(line.alternative_group, []).append(line)
    for g, ls in groups.items():
        if sum(1 for l in ls if l.alternative_priority == 1) != 1:
            raise ValidationFailed(f"Alternative group {g} needs exactly one primary (priority 1) line")
    eff = bom.effective_from or date.today()
    bom.effective_from = eff
    prior = ctx.db.execute(
        select(Bom).where(Bom.item_id == bom.item_id, Bom.status == "approved", Bom.id != bom.id)
    ).scalars().all()
    for p in prior:
        if p.effective_to is None or p.effective_to > eff:
            p.effective_to = eff
            p.status = "superseded"
    bom.status = "approved"
    bom.approved_by = ctx.user.id
    bom.approved_at = utcnow()
    ctx.audit("bom.approve", "bom", bom.id, after=row_dict(bom))
    ctx.emit("engineering.bom_approved", {"bom_id": bom.id, "item_id": bom.item_id, "version": bom.version})
    return bom


def new_bom_version(ctx: Ctx, bom_id: int, change_note: str, effective_from: date | None = None) -> Bom:
    """Engineering change: copy an approved BOM into a new draft version. Released orders keep their snapshot."""
    src = ctx.get(Bom, bom_id)
    data = {
        "base_quantity": src.base_quantity, "expected_yield_pct": src.expected_yield_pct,
        "effective_from": effective_from, "change_note": change_note,
        "lines": [
            {k: getattr(l, k) for k in (
                "line_no", "component_item_id", "quantity", "unit", "loss_pct", "scrap_basis", "allowance_note",
                "is_packaging", "backflush", "alternative_group", "alternative_priority", "alternative_approved",
                "operation_seq", "effective_from", "effective_to")}
            for l in src.lines
        ],
    }
    return create_bom(ctx, src.item_id, data)


def effective_bom(db: Session, item_id: int, on: date | None = None) -> Bom | None:
    on = on or date.today()
    return db.execute(
        select(Bom).where(
            Bom.item_id == item_id, Bom.status.in_(("approved", "superseded")),
            or_(Bom.effective_from.is_(None), Bom.effective_from <= on),
            or_(Bom.effective_to.is_(None), Bom.effective_to > on),
        ).order_by(Bom.version.desc())
    ).scalars().first()


def line_effective(line: BomLine, on: date) -> bool:
    return (line.effective_from is None or line.effective_from <= on) and (
        line.effective_to is None or line.effective_to > on
    )


def gross_per_parent(db: Session, bom: Bom, line: BomLine) -> dict:
    """Quantity of component (in its base unit) per ONE started parent, with the loss logic made explicit."""
    comp = db.get(Item, line.component_item_id)
    factor = conversion_factor(db, line.unit, comp.base_unit, comp.id)
    net = D(line.quantity) * factor / D(bom.base_quantity)
    if line.scrap_basis == "net_plus_loss":
        gross = net * (1 + D(line.loss_pct) / 100)
        note = f"net {q(net)} + {line.loss_pct}% expected loss"
    else:
        gross = net
        note = f"quantity already includes allowance ({line.allowance_note}); loss not added again"
    return {"component": comp, "net": q(net), "gross": q(gross), "note": note, "base_unit": comp.base_unit}


def start_quantity(bom: Bom, good_qty, integral: bool) -> Decimal:
    """Quantity to start to expect good_qty good units at the BOM's parent-level yield."""
    from ...core.numbers import ceil_int

    start = D(good_qty) * 100 / D(bom.expected_yield_pct)
    return ceil_int(start) if integral else q(start)


def explode(db: Session, item_id: int, qty, on: date | None = None, level: int = 0, max_depth: int = 25) -> list[dict]:
    """Multi-level explosion (primary components only), with an explanation per line."""
    on = on or date.today()
    if level > max_depth:
        raise BomCycleError("BOM explosion exceeded maximum depth — probable cycle")
    bom = effective_bom(db, item_id, on)
    if bom is None:
        return []
    parent = db.get(Item, item_id)
    integral = get_unit(db, parent.base_unit).integral
    start = start_quantity(bom, qty, integral)
    out = []
    for line in bom.lines:
        if not line_effective(line, on) or (line.alternative_group and line.alternative_priority != 1):
            continue
        g = gross_per_parent(db, bom, line)
        need = q(g["gross"] * start)
        comp = g["component"]
        out.append({
            "level": level + 1, "parent_item_code": parent.item_code, "item_id": comp.id,
            "item_code": comp.item_code, "description": comp.description, "quantity": need,
            "unit": comp.base_unit, "bom_version": bom.version,
            "explanation": f"{start} started (for {qty} good at {bom.expected_yield_pct}% yield) × {g['gross']} ({g['note']})",
        })
        out.extend(explode(db, comp.id, need, on, level + 1, max_depth))
    return out


# --------------------------------------------------------------------------- routings


def create_routing(ctx: Ctx, item_id: int, data: dict) -> Routing:
    ctx.require("engineering.edit")
    ctx.get(Item, item_id)
    last = ctx.db.execute(
        select(Routing.version).where(Routing.item_id == item_id).order_by(Routing.version.desc())
    ).scalar()
    r = Routing(item_id=item_id, version=(last or 0) + 1, status="draft", kind=data.get("kind", "standard"),
                effective_from=data.get("effective_from"), change_note=data.get("change_note"))
    ctx.db.add(r)
    ctx.db.flush()
    seqs = set()
    for op in data.get("operations", []):
        if op["seq"] in seqs:
            raise ValidationFailed(f"Duplicate operation sequence {op['seq']}")
        seqs.add(op["seq"])
        ctx.get(WorkCentre, op["work_centre_id"], "Work centre")
        for d in op.get("depends_on", []):
            if d not in seqs:
                raise ValidationFailed(f"Operation {op['seq']} depends on {d}, which is not an earlier operation")
        ctx.db.add(RoutingOperation(routing_id=r.id, **op))
    ctx.db.flush()
    if not any(o.reports_output for o in r.operations) and r.operations:
        r.operations[-1].reports_output = True
    ctx.audit("routing.create", "routing", r.id, after=row_dict(r))
    return r


def approve_routing(ctx: Ctx, routing_id: int) -> Routing:
    ctx.require("engineering.approve")
    r = ctx.get(Routing, routing_id)
    if r.status != "draft":
        raise InvalidState(f"Routing is {r.status}")
    if not r.operations:
        raise ValidationFailed("Routing has no operations")
    eff = r.effective_from or date.today()
    r.effective_from = eff
    for p in ctx.db.execute(select(Routing).where(
        Routing.item_id == r.item_id, Routing.status == "approved", Routing.id != r.id, Routing.kind == r.kind
    )).scalars():
        p.effective_to = eff
        p.status = "superseded"
    r.status = "approved"
    r.approved_by = ctx.user.id
    r.approved_at = utcnow()
    ctx.audit("routing.approve", "routing", r.id, after=row_dict(r))
    return r


def effective_routing(db: Session, item_id: int, on: date | None = None, kind: str = "standard") -> Routing | None:
    on = on or date.today()
    return db.execute(
        select(Routing).where(
            Routing.item_id == item_id, Routing.kind == kind, Routing.status.in_(("approved", "superseded")),
            or_(Routing.effective_from.is_(None), Routing.effective_from <= on),
            or_(Routing.effective_to.is_(None), Routing.effective_to > on),
        ).order_by(Routing.version.desc())
    ).scalars().first()


# --------------------------------------------------------------------------- snapshots


def snapshot(db: Session, bom: Bom | None, routing: Routing | None, on: date) -> dict:
    """Frozen copy of the approved definitions used by a production order."""
    snap: dict = {"captured_at": utcnow().isoformat(), "effective_on": on.isoformat()}
    if bom is not None:
        if bom.status not in ("approved", "superseded"):
            raise InvalidState("Only approved BOMs can be used for production")
        lines = []
        for l in bom.lines:
            if not line_effective(l, on):
                continue
            g = gross_per_parent(db, bom, l)
            comp = g["component"]
            lines.append({
                "bom_line_id": l.id, "line_no": l.line_no, "component_item_id": comp.id,
                "component_item_code": comp.item_code, "component_revision": comp.revision,
                "quantity": str(l.quantity), "unit": l.unit, "loss_pct": str(l.loss_pct),
                "scrap_basis": l.scrap_basis, "allowance_note": l.allowance_note,
                "net_per_parent_base": str(g["net"]), "gross_per_parent_base": str(g["gross"]),
                "base_unit": comp.base_unit, "is_packaging": l.is_packaging, "backflush": l.backflush,
                "alternative_group": l.alternative_group, "alternative_priority": l.alternative_priority,
                "alternative_approved": l.alternative_approved, "operation_seq": l.operation_seq,
            })
        snap["bom"] = {
            "bom_id": bom.id, "version": bom.version, "status_at_capture": bom.status,
            "approved_by": bom.approved_by, "approved_at": jsonable(bom.approved_at),
            "base_quantity": str(bom.base_quantity), "expected_yield_pct": str(bom.expected_yield_pct), "lines": lines,
        }
    if routing is not None:
        if routing.status not in ("approved", "superseded"):
            raise InvalidState("Only approved routings can be used for production")
        snap["routing"] = {
            "routing_id": routing.id, "version": routing.version, "kind": routing.kind,
            "approved_by": routing.approved_by, "approved_at": jsonable(routing.approved_at),
            "operations": [
                {k: jsonable(getattr(o, k)) for k in (
                    "seq", "code", "name", "work_centre_id", "required_equipment_kind", "required_skill",
                    "setup_minutes", "run_minutes_per_unit", "machine_minutes_per_unit", "inspection_point",
                    "inspection_plan_code", "instructions", "instruction_document_id", "depends_on",
                    "subcontracted", "subcontract_supplier_id", "subcontract_lead_days", "reports_output")}
                for o in routing.operations
            ],
        }
    return snap


def bom_detail(db: Session, bom: Bom) -> dict:
    d = row_dict(bom)
    d["item_code"] = db.get(Item, bom.item_id).item_code
    d["lines"] = []
    for l in bom.lines:
        ld = row_dict(l)
        comp = db.get(Item, l.component_item_id)
        ld["component_item_code"] = comp.item_code
        ld["component_description"] = comp.description
        try:
            g = gross_per_parent(db, bom, l)
            ld["gross_per_parent_base"] = str(g["gross"])
            ld["base_unit"] = comp.base_unit
            ld["loss_note"] = g["note"]
        except ValidationFailed as e:
            ld["conversion_error"] = e.message
        d["lines"].append(ld)
    return d
