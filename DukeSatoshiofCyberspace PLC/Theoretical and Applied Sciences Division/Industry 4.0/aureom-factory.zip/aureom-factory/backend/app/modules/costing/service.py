"""Manufacturing costs.

Five distinct figures are kept apart:
  standard cost        – roll-up of standard prices and rates per unit (reference)
  planned order cost   – frozen when an order is planned, from its snapshot and the rates on that date
  recorded actual cost – from consumption movements (lot costs), booked time, subcontract prices, scrap
  estimate at completion – actual to date + planned cost of the remaining work
  financially posted   – what has been exported to accounting (cost_postings)

All amounts are in the base currency with the rate date stated. Overhead is an allocation and is
never presented as a marginal cost in incremental scenarios.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ...config import settings
from ...core.context import Ctx, row_dict, utcnow
from ...core.errors import InvalidState, ValidationFailed
from ...core.numbers import D, ZERO, money, q
from ..engineering.models import Bom, Routing, WorkCentre
from ..engineering.service import effective_bom, effective_routing, gross_per_parent
from ..inventory.models import Lot, StockMovement
from ..purchasing.models import PurchaseOrder, PurchaseOrderLine
from ..registry.models import Item, ItemSupplierRef
from .fx import rate_to_base, to_base_currency
from .models import CostPosting, OverheadRule

ELEMENTS = ("materials", "packaging", "labour", "machine", "subcontract", "scrap_material", "overhead")


def _wc(db: Session, wc_id: int) -> WorkCentre:
    return db.get(WorkCentre, wc_id)


def unit_cost_estimate(db: Session, item: Item, on: date) -> tuple[Decimal, str]:
    """Best available unit cost (base currency per base unit) for planning: standard, else preferred supplier price."""
    if item.standard_cost is not None:
        amt, rate, rd = to_base_currency(db, item.standard_cost, item.standard_cost_currency or settings.base_currency, on)
        return D(amt), f"standard {item.standard_cost} {item.standard_cost_currency or settings.base_currency}"
    ref = db.execute(select(ItemSupplierRef).where(ItemSupplierRef.item_id == item.id, ItemSupplierRef.approved.is_(True))
                     .order_by(ItemSupplierRef.preferred.desc())).scalars().first()
    if ref and ref.price is not None:
        from ..registry.service import conversion_factor
        per_base = D(ref.price) / conversion_factor(db, ref.purchase_unit, item.base_unit, item.id)
        amt, rate, rd = to_base_currency(db, per_base, ref.currency, on)
        return D(amt), f"supplier price {ref.price} {ref.currency}/{ref.purchase_unit} @ {rate} ({rd})"
    return ZERO, "no cost on record"


def overhead_rules(db: Session, on: date) -> list[OverheadRule]:
    return list(db.execute(select(OverheadRule).where(OverheadRule.effective_from <= on)).scalars())


def _overhead(db: Session, on: date, labour_h: Decimal, machine_h: Decimal, material: Decimal, units: Decimal,
              wc_ids: set[int]) -> list[dict]:
    out = []
    for r in overhead_rules(db, on):
        if r.effective_to and r.effective_to <= on:
            continue
        if r.work_centre_id and r.work_centre_id not in wc_ids:
            continue
        basis = {"labour_hours": labour_h, "machine_hours": machine_h, "material_cost_pct": material / 100,
                 "per_unit": units}[r.basis]
        out.append({"rule": r.code, "basis": r.basis, "basis_quantity": str(q(basis)), "rate": str(r.rate),
                    "behaviour": r.behaviour, "amount": money(basis * D(r.rate))})
    return out


def _totals(lines: dict[str, Decimal]) -> dict:
    t = {k: str(money(lines.get(k, ZERO))) for k in ELEMENTS}
    t["total"] = str(money(sum(lines.get(k, ZERO) for k in ELEMENTS)))
    return t


# --------------------------------------------------------------------------- standard cost


def standard_cost(db: Session, item_id: int, on: date | None = None, batch_size: Decimal | None = None, depth: int = 0) -> dict:
    on = on or date.today()
    item = db.get(Item, item_id)
    bom, routing = effective_bom(db, item.id, on), effective_routing(db, item.id, on)
    if bom is None or routing is None or depth > 10:
        c, basis = unit_cost_estimate(db, item, on)
        return {"item_code": item.item_code, "unit_cost": str(money(c)), "basis": basis, "elements": {"materials": str(money(c))}}
    batch = D(batch_size or item.standard_batch_quantity or 1) or Decimal(1)
    start_per_good = Decimal(100) / D(bom.expected_yield_pct)
    el: dict[str, Decimal] = defaultdict(Decimal)
    comps = []
    for l in bom.lines:
        if l.alternative_group and l.alternative_priority != 1:
            continue
        g = gross_per_parent(db, bom, l)
        sub = standard_cost(db, l.component_item_id, on, None, depth + 1)
        amt = D(sub["unit_cost"]) * g["gross"] * start_per_good
        el["packaging" if l.is_packaging else "materials"] += amt
        comps.append({"item_code": g["component"].item_code, "qty_per_good_unit": str(q(g["gross"] * start_per_good)),
                      "unit_cost": sub["unit_cost"], "amount": str(money(amt))})
    lab_h = mach_h = ZERO
    wcs = set()
    for o in routing.operations:
        wc = _wc(db, o.work_centre_id)
        wcs.add(wc.id)
        if o.subcontracted:
            ref = db.execute(select(ItemSupplierRef).where(ItemSupplierRef.item_id == item.id,
                                                           ItemSupplierRef.supplier_id == o.subcontract_supplier_id)).scalar_one_or_none()
            if ref and ref.price is not None:
                amt, _, _ = to_base_currency(db, ref.price, ref.currency, on)
                el["subcontract"] += D(amt) * start_per_good
            continue
        lab_min = D(o.setup_minutes) / batch + D(o.run_minutes_per_unit) * start_per_good
        mach_min = (D(o.setup_minutes) / batch + D(o.machine_minutes_per_unit) * start_per_good) if D(o.machine_minutes_per_unit) > 0 else ZERO
        el["labour"] += lab_min / 60 * D(wc.labour_rate)
        el["machine"] += mach_min / 60 * D(wc.machine_rate)
        lab_h += lab_min / 60
        mach_h += mach_min / 60
    oh = _overhead(db, on, lab_h, mach_h, el["materials"], Decimal(1), wcs)
    el["overhead"] = sum((o["amount"] for o in oh), ZERO)
    total = sum(el.values(), ZERO)
    return {"item_code": item.item_code, "unit_cost": str(money(total)), "currency": settings.base_currency,
            "batch_size_for_setup": str(batch), "bom_version": bom.version, "routing_version": routing.version,
            "elements": {k: str(money(v)) for k, v in el.items()}, "components": comps,
            "overhead": [{**o, "amount": str(o["amount"])} for o in oh], "as_of": on.isoformat()}


# --------------------------------------------------------------------------- planned order cost


def planned_order_cost(db: Session, order) -> dict:
    on = date.today()
    el: dict[str, Decimal] = defaultdict(Decimal)
    detail = []
    for m in order.materials:
        item = db.get(Item, m.item_id)
        c, basis = unit_cost_estimate(db, item, on)
        if item.item_type in ("wip", "subassembly"):
            c = D(standard_cost(db, item.id, on)["unit_cost"])
            basis = "standard roll-up"
        amt = c * D(m.required_quantity)
        el["packaging" if m.is_packaging else "materials"] += amt
        detail.append({"element": "packaging" if m.is_packaging else "materials", "item_code": item.item_code,
                       "quantity": str(m.required_quantity), "unit": m.unit, "unit_cost": str(money(c)), "basis": basis,
                       "amount": str(money(amt))})
    lab_h = mach_h = ZERO
    wcs = set()
    for o in order.operations:
        wc = _wc(db, o.work_centre_id)
        wcs.add(wc.id)
        if o.subcontracted:
            ref = db.execute(select(ItemSupplierRef).where(ItemSupplierRef.item_id == order.item_id,
                                                           ItemSupplierRef.supplier_id == o.subcontract_supplier_id)).scalar_one_or_none()
            if ref and ref.price is not None:
                amt, rate, rd = to_base_currency(db, D(ref.price) * D(order.quantity_start), ref.currency, on)
                el["subcontract"] += D(amt)
                detail.append({"element": "subcontract", "operation": o.seq, "amount": str(money(amt)),
                               "basis": f"{ref.price} {ref.currency}/unit @ {rate} ({rd})"})
            continue
        lab_min = D(o.setup_minutes) + D(o.run_minutes_per_unit) * D(order.quantity_start)
        mach_min = D(o.setup_minutes) + D(o.machine_minutes_per_unit) * D(order.quantity_start) if D(o.machine_minutes_per_unit) > 0 else ZERO
        la, ma = lab_min / 60 * D(wc.labour_rate), mach_min / 60 * D(wc.machine_rate)
        el["labour"] += la
        el["machine"] += ma
        lab_h += lab_min / 60
        mach_h += mach_min / 60
        detail.append({"element": "labour+machine", "operation": o.seq, "work_centre": wc.code,
                       "labour_minutes": str(q(lab_min)), "machine_minutes": str(q(mach_min)),
                       "labour_rate": str(wc.labour_rate), "machine_rate": str(wc.machine_rate),
                       "amount": str(money(la + ma))})
    oh = _overhead(db, on, lab_h, mach_h, el["materials"], D(order.quantity_start), wcs)
    el["overhead"] = sum((o["amount"] for o in oh), ZERO)
    return {"as_of": on.isoformat(), "currency": settings.base_currency, "quantity_start": str(order.quantity_start),
            "totals": _totals(el), "detail": detail, "overhead": [{**o, "amount": str(o["amount"])} for o in oh],
            "unit_cost_per_target": str(money(sum(el.values(), ZERO) / D(order.quantity_target)))}


# --------------------------------------------------------------------------- actual cost


def actual_order_cost(db: Session, order) -> dict:
    from ..production.models import OrderMaterial, ScrapRecord, SubcontractShipment
    from ..production.service import time_intervals

    el: dict[str, Decimal] = defaultdict(Decimal)
    detail = []
    mats = {m.id: m for m in order.materials}
    cons = db.execute(select(StockMovement).where(StockMovement.reference_type == "production_order",
                                                  StockMovement.reference_id == order.id,
                                                  StockMovement.movement_type == "consumption")).scalars().all()
    calc_value = ZERO
    for mv in cons:
        m = mats.get(mv.reference_line_id)
        amt = D(mv.quantity) * D(mv.unit_cost or 0)
        key = "packaging" if m is not None and m.is_packaging else "materials"
        el[key] += amt
        if mv.value_source == "calculated":
            calc_value += amt
        if mv.unit_cost is None:
            detail.append({"warning": f"Movement {mv.movement_no} has no unit cost; valued at zero"})
    lab_h = mach_h = ZERO
    wcs = set()
    for o in order.operations:
        wc = _wc(db, o.work_centre_id)
        wcs.add(wc.id)
        ivs = time_intervals(db, o)
        lab_min = sum((D(i["minutes"]) for i in ivs), ZERO)
        mach_min = sum((D(i["minutes"]) for i in ivs if i["equipment_id"] and i["phase"] != "setup"), ZERO) \
            + sum((D(i["minutes"]) for i in ivs if i["equipment_id"] and i["phase"] == "setup"), ZERO)
        if D(o.machine_minutes_per_unit) <= 0:
            mach_min = ZERO
        if o.subcontracted:
            continue
        el["labour"] += lab_min / 60 * D(wc.labour_rate)
        el["machine"] += mach_min / 60 * D(wc.machine_rate)
        lab_h += lab_min / 60
        mach_h += mach_min / 60
        detail.append({"operation": o.seq, "work_centre": wc.code, "labour_minutes": str(q(lab_min)),
                       "machine_minutes": str(q(mach_min)), "source": "operation events (start→pause/complete)"})
    for sh in db.execute(select(SubcontractShipment).where(SubcontractShipment.order_id == order.id)).scalars():
        if sh.po_id:
            po = db.get(PurchaseOrder, sh.po_id)
            for pl in po.lines:
                if pl.production_order_id == order.id:
                    on = (sh.returned_at or utcnow()).date()
                    amt, rate, rd = to_base_currency(db, D(pl.unit_price) * D(sh.quantity_returned), pl.currency, on)
                    el["subcontract"] += D(amt)
                    detail.append({"element": "subcontract", "shipment": sh.number, "quantity": str(sh.quantity_returned),
                                   "price": f"{pl.unit_price} {pl.currency}", "fx": f"{rate} ({rd})", "amount": str(money(amt))})
    scrap_detail = []
    for sr in db.execute(select(ScrapRecord).where(ScrapRecord.order_id == order.id, ScrapRecord.status == "authorised")).scalars():
        if sr.kind == "material":
            el["scrap_material"] += D(sr.cost_value or 0)
        scrap_detail.append({"number": sr.number, "kind": sr.kind, "quantity": str(sr.quantity), "unit": sr.unit,
                             "value": str(sr.cost_value), "included_in_total": sr.kind == "material",
                             "note": "product scrap value is already inside consumed materials and time"
                             if sr.kind == "product" else "scrapped line-side material"})
    oh = _overhead(db, (order.released_at or utcnow()).date(), lab_h, mach_h, el["materials"],
                   D(order.quantity_reported) or D(order.quantity_start), wcs)
    el["overhead"] = sum((o["amount"] for o in oh), ZERO)
    return {"currency": settings.base_currency, "totals": _totals(el), "detail": detail, "scrap": scrap_detail,
            "overhead": [{**o, "amount": str(o["amount"])} for o in oh],
            "calculated_backflush_value": str(money(calc_value)),
            "note": "Recorded actuals; backflushed (calculated) consumption is included and identified separately."}


def estimate_at_completion(db: Session, order) -> dict:
    act = actual_order_cost(db, order)
    plan = order.planned_cost or planned_order_cost(db, order)
    if order.status in ("completed", "closed", "awaiting_inspection", "cancelled"):
        return {"totals": act["totals"], "basis": "order finished: estimate equals recorded actual"}
    remaining: dict[str, Decimal] = defaultdict(Decimal)
    on = date.today()
    for m in order.materials:
        left = max(ZERO, D(m.required_quantity) - D(m.quantity_consumed))
        c, _ = unit_cost_estimate(db, db.get(Item, m.item_id), on)
        remaining["packaging" if m.is_packaging else "materials"] += left * c
    for o in order.operations:
        if o.status == "completed" or o.subcontracted:
            continue
        wc = _wc(db, o.work_centre_id)
        left_units = max(ZERO, D(order.quantity_start) - D(o.quantity_good) - D(o.quantity_scrap) - D(o.quantity_rework))
        setup = D(o.setup_minutes) if o.status in ("pending", "ready") else ZERO
        remaining["labour"] += (setup + D(o.run_minutes_per_unit) * left_units) / 60 * D(wc.labour_rate)
        if D(o.machine_minutes_per_unit) > 0:
            remaining["machine"] += (setup + D(o.machine_minutes_per_unit) * left_units) / 60 * D(wc.machine_rate)
    pt = plan["totals"]
    if D(pt.get("overhead", 0)) > 0:
        frac = 1 - (D(order.quantity_reported) / D(order.quantity_start) if D(order.quantity_start) else ZERO)
        remaining["overhead"] += max(ZERO, D(pt["overhead"]) * frac)
    tot = {k: D(act["totals"][k]) + remaining.get(k, ZERO) for k in ELEMENTS}
    return {"totals": _totals(tot), "remaining": {k: str(money(v)) for k, v in remaining.items()},
            "basis": "recorded actual + planned cost of remaining quantities at current rates"}


def posted_cost(db: Session, order_id: int) -> dict:
    rows = db.execute(select(CostPosting).where(CostPosting.production_order_id == order_id)).scalars().all()
    el = defaultdict(Decimal)
    for r in rows:
        if r.account == "1400-WIP" and D(r.debit) > 0 and r.cost_element in ELEMENTS:
            el[r.cost_element] += D(r.debit)
    return {"totals": _totals(el), "batches": sorted({r.batch_ref for r in rows}),
            "note": "Only amounts exported to accounting through the accounting adapter."}


def order_cost_comparison(db: Session, order) -> dict:
    item = db.get(Item, order.item_id)
    if order.kind == "rework":
        std = {"unit_cost": None, "elements": {}, "note": "not applicable: rework has no standard cost"}
        std_total = None
    else:
        std = standard_cost(db, item.id, (order.released_at or utcnow()).date(), batch_size=order.quantity_start)
        std_total = D(std["unit_cost"]) * D(order.quantity_target)
    act = actual_order_cost(db, order)
    plan = order.planned_cost or planned_order_cost(db, order)
    eac = estimate_at_completion(db, order)
    good = D(order.quantity_accepted) or D(order.quantity_reported)
    return {
        "order": order.number, "item_code": item.item_code, "status": order.status, "currency": settings.base_currency,
        "quantity_target": str(order.quantity_target), "quantity_accepted": str(order.quantity_accepted),
        "standard": {"unit": std["unit_cost"], "total_for_target": str(money(std_total)) if std_total is not None else None,
                     "elements": std["elements"], "note": std.get("note")},
        "planned": plan["totals"], "actual": act["totals"], "estimate_at_completion": eac["totals"],
        "posted": posted_cost(db, order.id)["totals"],
        "actual_unit_cost_per_accepted": str(money(D(act["totals"]["total"]) / good)) if good else None,
        "variance_actual_vs_planned": str(money(D(act["totals"]["total"]) - D(plan["totals"]["total"]))),
        "actual_detail": act, "planned_detail": plan,
    }


# --------------------------------------------------------------------------- scrap valuation and finalisation


def scrap_value(db: Session, sr, order) -> Decimal:
    if sr.kind == "material":
        lot = db.get(Lot, sr.lot_id) if sr.lot_id else None
        return money(D(sr.quantity) * D(lot.unit_cost if lot and lot.unit_cost else 0))
    if order is None:
        return ZERO
    act = actual_order_cost(db, order)
    per = D(act["totals"]["total"]) / D(order.quantity_start) if D(order.quantity_start) else ZERO
    return money(per * D(sr.quantity))


def finalise_order_cost(ctx: Ctx, order) -> dict:
    """At closure: value the order's accepted output lots at recorded actual cost per accepted unit."""
    from ..production.models import ProductionOutput

    act = actual_order_cost(ctx.db, order)
    total = D(act["totals"]["total"])
    outs = ctx.db.execute(select(ProductionOutput).where(ProductionOutput.order_id == order.id,
                                                         ProductionOutput.conformity == "good")).scalars().all()
    good = sum((D(o.quantity) for o in outs), ZERO)
    if good <= 0:
        return act
    per = total / good
    comps = {k: str(money(D(v) / good)) for k, v in act["totals"].items()}
    for o in outs:
        lot = ctx.db.get(Lot, o.lot_id)
        if order.kind == "rework":
            prev = D(lot.unit_cost or 0)
            lot.unit_cost = money(prev + per)
            lot.cost_components = {**(lot.cost_components or {}), "rework": str(money(per))}
            lot.cost_basis = (lot.cost_basis or "") + f"; + rework {order.number}"
        else:
            lot.unit_cost = money(per)
            lot.cost_components = comps
            lot.cost_basis = f"actual cost of {order.number} per good unit (fully absorbed)"
    ctx.audit("order.cost_finalised", "production_order", order.id, after={"unit_cost": str(money(per))})
    return act


# --------------------------------------------------------------------------- incremental scenario


def incremental_cost(db: Session, item_id: int, *, added_to_existing_batch: bool = True, labour_variable: bool = False,
                     on: date | None = None) -> dict:
    """Cost that changes if ONE more unit is made, versus fully allocated unit cost.

    Assumptions are returned with the figures so they can be challenged."""
    on = on or date.today()
    item = db.get(Item, item_id)
    lines, assumptions = [], [
        "Materials, packaging and bought-in components are consumed per unit (including expected loss).",
        "Subcontract operations are priced per unit by the subcontractor.",
        "Machine variable cost (energy, tooling wear, coolant) is charged per machine hour at the variable rate.",
        ("Labour is treated as variable (paid per hour worked)." if labour_variable else
         "Labour is treated as fixed: operators are salaried and the extra unit fits within existing shifts."),
        ("The unit is added to a batch that is already set up, so no extra setup is incurred."
         if added_to_existing_batch else "A separate setup is required for this unit."),
        "Allocated overhead (fixed rules) does not change with one more unit and is excluded.",
    ]

    def walk(it: Item, qty: Decimal, depth: int):
        bom, routing = effective_bom(db, it.id, on), effective_routing(db, it.id, on)
        if bom is None or routing is None or depth > 10:
            c, basis = unit_cost_estimate(db, it, on)
            lines.append({"element": "packaging" if it.item_type == "packaging" else "materials", "item_code": it.item_code,
                          "quantity": str(q(qty)), "amount": money(c * qty), "changes": True, "basis": basis})
            return
        start = qty * 100 / D(bom.expected_yield_pct)
        for l in bom.lines:
            if l.alternative_group and l.alternative_priority != 1:
                continue
            g = gross_per_parent(db, bom, l)
            walk(g["component"], g["gross"] * start, depth + 1)
        for o in routing.operations:
            wc = _wc(db, o.work_centre_id)
            if o.subcontracted:
                ref = db.execute(select(ItemSupplierRef).where(ItemSupplierRef.item_id == it.id,
                                                               ItemSupplierRef.supplier_id == o.subcontract_supplier_id)).scalar_one_or_none()
                if ref and ref.price is not None:
                    amt, _, _ = to_base_currency(db, D(ref.price) * start, ref.currency, on)
                    lines.append({"element": "subcontract", "item_code": it.item_code, "operation": o.code,
                                  "amount": money(amt), "changes": True, "basis": "subcontractor unit price"})
                continue
            mach_min = D(o.machine_minutes_per_unit) * start
            if mach_min > 0:
                lines.append({"element": "machine_variable", "item_code": it.item_code, "operation": o.code,
                              "minutes": str(q(mach_min)), "amount": money(mach_min / 60 * D(wc.machine_variable_rate)),
                              "changes": True, "basis": f"variable rate {wc.machine_variable_rate}/h"})
                lines.append({"element": "machine_fixed", "item_code": it.item_code, "operation": o.code,
                              "amount": money(mach_min / 60 * (D(wc.machine_rate) - D(wc.machine_variable_rate))),
                              "changes": False, "basis": "depreciation/fixed part of machine rate"})
            lab_min = D(o.run_minutes_per_unit) * start
            lines.append({"element": "labour", "item_code": it.item_code, "operation": o.code, "minutes": str(q(lab_min)),
                          "amount": money(lab_min / 60 * D(wc.labour_rate)), "changes": labour_variable,
                          "basis": f"labour rate {wc.labour_rate}/h"})
            if not added_to_existing_batch and D(o.setup_minutes) > 0:
                lines.append({"element": "setup", "item_code": it.item_code, "operation": o.code,
                              "amount": money(D(o.setup_minutes) / 60 * (D(wc.labour_rate) + D(wc.machine_variable_rate))),
                              "changes": True, "basis": "full setup for a one-off unit"})

    walk(item, Decimal(1), 0)
    incremental = sum((l["amount"] for l in lines if l["changes"]), ZERO)
    std = standard_cost(db, item.id, on)
    return {
        "item_code": item.item_code, "currency": settings.base_currency, "as_of": on.isoformat(),
        "incremental_cost_one_more_unit": str(money(incremental)),
        "fully_allocated_standard_unit_cost": std["unit_cost"],
        "lines": [{**l, "amount": str(l["amount"])} for l in lines], "assumptions": assumptions,
        "warning": "Fully allocated cost includes overhead allocations and fixed costs that do not change with one more "
                   "unit. Do not treat it as marginal cost.",
    }


# --------------------------------------------------------------------------- accounting export


def export_order_postings(ctx: Ctx, order_id: int, posting_date: date | None = None) -> dict:
    """Produce journal lines for an order's recorded actual cost and send them to the accounting
    adapter (simulated: writes a CSV/JSON export). This does not replace a general ledger."""
    from ...adapters.registry import adapters
    from ..production.models import ProductionOrder

    ctx.require("costing.export")
    order = ctx.get(ProductionOrder, order_id)
    if order.status != "closed":
        raise InvalidState("Only closed orders are exported (actual cost settled)")
    batch = f"{order.number}-ACT"
    if ctx.db.execute(select(CostPosting.id).where(CostPosting.batch_ref == batch)).first():
        return {"batch_ref": batch, "status": "already_exported"}
    act = actual_order_cost(ctx.db, order)
    pd = posting_date or date.today()
    credit_accounts = {"materials": "1300-RAW", "packaging": "1310-PACK", "labour": "5100-LAB-ABS",
                       "machine": "5200-MCH-ABS", "subcontract": "2100-GRNI", "scrap_material": "1300-RAW",
                       "overhead": "5900-OH-ABS"}
    journal = []
    for el in ELEMENTS:
        amt = D(act["totals"][el])
        if amt <= 0:
            continue
        journal.append({"account": "1400-WIP", "debit": amt, "credit": ZERO, "element": el, "desc": f"{order.number} {el}"})
        journal.append({"account": credit_accounts[el], "debit": ZERO, "credit": amt, "element": el, "desc": f"{order.number} {el}"})
    total = D(act["totals"]["total"])
    journal.append({"account": "1500-FG", "debit": total, "credit": ZERO, "element": "completion", "desc": f"{order.number} to finished/sub-assembly stock"})
    journal.append({"account": "1400-WIP", "debit": ZERO, "credit": total, "element": "completion", "desc": f"{order.number} relieve WIP"})
    result = adapters().accounting.export_journal(batch, pd, settings.base_currency, [
        {**j, "debit": str(money(j["debit"])), "credit": str(money(j["credit"]))} for j in journal])
    for j in journal:
        ctx.db.add(CostPosting(batch_ref=batch, production_order_id=order.id, account=j["account"], description=j["desc"],
                               debit=money(j["debit"]), credit=money(j["credit"]), currency=settings.base_currency,
                               cost_element=j["element"], posting_date=pd, exported_by=ctx.user.id,
                               adapter=result.adapter, external_ref=result.external_ref))
    ctx.audit("costing.export", "production_order", order.id, after={"batch": batch, "file": result.location})
    return {"batch_ref": batch, "status": "exported", "lines": len(journal), "location": result.location,
            "adapter": result.adapter, "balanced": sum(D(j["debit"]) for j in journal) == sum(D(j["credit"]) for j in journal)}
