"""Item registry services and unit conversion.

Conversion rules
----------------
* Same unit: identity.
* Same physical dimension with global factors (g↔kg, mm↔m, mL↔L): converted by factor.
* Across dimensions (m→kg, pack→pc, L→kg): only via an APPROVED item-specific conversion,
  optionally combined with same-dimension global factors on either side.
* Otherwise a UnitConversionError is raised. Kilograms, metres, litres, pieces and packs are
  never interchanged silently.
"""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...core.context import Ctx, check_version, row_dict, utcnow
from ...core.errors import NotFound, UnitConversionError, ValidationFailed
from ...core.numbers import D, q
from .models import ITEM_TYPES, LOT_POLICIES, SPEC_STATUSES, Item, ItemUnitConversion, Unit


def get_unit(db: Session, code: str) -> Unit:
    u = db.get(Unit, code)
    if u is None:
        raise ValidationFailed(f"Unknown unit '{code}'")
    return u


def _global_factor(db: Session, from_code: str, to_code: str) -> Decimal | None:
    if from_code == to_code:
        return Decimal(1)
    a, b = get_unit(db, from_code), get_unit(db, to_code)
    if a.dimension != b.dimension or a.factor_to_reference is None or b.factor_to_reference is None:
        return None
    if a.dimension == "pack":
        return None  # packs have no universal size
    return D(a.factor_to_reference) / D(b.factor_to_reference)


def conversion_factor(db: Session, from_code: str, to_code: str, item_id: int | None = None) -> Decimal:
    """Return f such that qty[from] × f = qty[to]."""
    g = _global_factor(db, from_code, to_code)
    if g is not None:
        return g
    if item_id is not None:
        a, b = get_unit(db, from_code), get_unit(db, to_code)
        convs = db.execute(
            select(ItemUnitConversion).where(
                ItemUnitConversion.item_id == item_id, ItemUnitConversion.status == "approved"
            )
        ).scalars().all()
        for c in convs:
            cf, ct = get_unit(db, c.from_unit), get_unit(db, c.to_unit)
            # forward: from →(global) c.from →(item) c.to →(global) to
            for (src, dst, factor) in ((cf, ct, D(c.factor)), (ct, cf, Decimal(1) / D(c.factor))):
                if src.dimension == a.dimension and dst.dimension == b.dimension:
                    left = Decimal(1) if src.code == a.code else _global_factor(db, a.code, src.code)
                    right = Decimal(1) if dst.code == b.code else _global_factor(db, dst.code, b.code)
                    if left is not None and right is not None:
                        return left * factor * right
    raise UnitConversionError(
        f"No valid conversion from '{from_code}' to '{to_code}'"
        + (f" for item {item_id}" if item_id else "")
        + ". Add and approve an item-specific conversion first.",
        details={"from": from_code, "to": to_code, "item_id": item_id},
    )


def convert(db: Session, qty, from_code: str, to_code: str, item_id: int | None = None) -> Decimal:
    return q(D(qty) * conversion_factor(db, from_code, to_code, item_id))


def to_base(db: Session, item: Item, qty, unit: str) -> Decimal:
    value = convert(db, qty, unit, item.base_unit, item.id)
    base = get_unit(db, item.base_unit)
    if base.integral and value != value.to_integral_value():
        raise ValidationFailed(
            f"{item.item_code} is counted in whole {base.code}; {qty} {unit} = {value} {base.code} is not whole",
            details={"base_qty": str(value)},
        )
    return value


# --------------------------------------------------------------------------- specifications


def validate_specifications(specs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Every specification line must say whether it is specified, unknown or not applicable."""
    out = []
    seen = set()
    for s in specs or []:
        name = (s.get("name") or "").strip()
        if not name:
            raise ValidationFailed("Specification lines need a name")
        if name.lower() in seen:
            raise ValidationFailed(f"Duplicate specification '{name}'")
        seen.add(name.lower())
        status = s.get("status")
        if status not in SPEC_STATUSES:
            raise ValidationFailed(
                f"Specification '{name}' must have status one of {SPEC_STATUSES} (unknowns are recorded explicitly)"
            )
        value = s.get("value")
        if status == "specified" and (value is None or str(value).strip() == ""):
            raise ValidationFailed(f"Specification '{name}' is marked specified but has no value")
        if status != "specified" and value not in (None, ""):
            raise ValidationFailed(f"Specification '{name}' is '{status}' and must not carry a value")
        out.append({
            "name": name, "status": status, "value": value if status == "specified" else None,
            "unit": s.get("unit"), "tolerance": s.get("tolerance"), "source": s.get("source"),
        })
    return out


def unknown_specifications(item: Item) -> list[str]:
    return [s["name"] for s in item.specifications or [] if s.get("status") == "unknown"]


# --------------------------------------------------------------------------- items

EDITABLE = (
    "description", "specifications", "storage_requirements", "shelf_life_applicable", "shelf_life_days",
    "active_status", "lead_time_days", "lot_size_min", "lot_size_multiple", "safety_stock", "standard_batch_quantity",
    "incoming_inspection_required", "standard_cost", "standard_cost_currency", "make_or_buy",
    "recoverable_scrap_item_id",
)


def _validate_item_fields(data: dict) -> None:
    if data.get("item_type") and data["item_type"] not in ITEM_TYPES:
        raise ValidationFailed(f"item_type must be one of {ITEM_TYPES}")
    if data.get("lot_or_serial_policy") and data["lot_or_serial_policy"] not in LOT_POLICIES:
        raise ValidationFailed(f"lot_or_serial_policy must be one of {LOT_POLICIES}")
    if data.get("shelf_life_applicable") and not data.get("shelf_life_days"):
        raise ValidationFailed("shelf_life_days is required when shelf life applies")
    if not data.get("shelf_life_applicable") and data.get("shelf_life_days"):
        raise ValidationFailed("shelf_life_days given but shelf life is marked not applicable")


def create_item(ctx: Ctx, data: dict) -> Item:
    ctx.require("registry.edit")
    _validate_item_fields(data)
    get_unit(ctx.db, data["base_unit"])
    exists = ctx.db.execute(
        select(Item).where(Item.item_code == data["item_code"], Item.revision == data.get("revision", "A"))
    ).scalar_one_or_none()
    if exists:
        raise ValidationFailed(f"Item {data['item_code']} rev {data.get('revision', 'A')} already exists")
    item = Item(
        item_code=data["item_code"], revision=data.get("revision", "A"), description=data["description"],
        item_type=data["item_type"], base_unit=data["base_unit"],
        specifications=validate_specifications(data.get("specifications", [])),
        lot_or_serial_policy=data.get("lot_or_serial_policy", "lot"),
        certifications=data.get("certifications", []),
        **{k: data[k] for k in EDITABLE if k in data and k not in ("specifications", "description")},
    )
    if item.standard_cost is not None:
        item.standard_cost_date = data.get("standard_cost_date") or utcnow()
    ctx.db.add(item)
    ctx.db.flush()
    ctx.audit("item.create", "item", item.id, after=row_dict(item))
    return item


def update_item(ctx: Ctx, item_id: int, version: int | None, changes: dict) -> Item:
    ctx.require("registry.edit")
    item = ctx.get(Item, item_id)
    check_version(item, version)
    before = row_dict(item)
    merged = {**before, **changes}
    _validate_item_fields(merged)
    for k, v in changes.items():
        if k not in EDITABLE:
            raise ValidationFailed(f"Field '{k}' cannot be edited; create a new revision instead")
        if k == "specifications":
            v = validate_specifications(v)
        setattr(item, k, v)
    if "standard_cost" in changes:
        item.standard_cost_date = utcnow()
    ctx.db.flush()
    ctx.audit("item.update", "item", item.id, before=before, after=row_dict(item))
    return item


def propose_conversion(ctx: Ctx, item_id: int, from_unit: str, to_unit: str, factor, basis: str) -> ItemUnitConversion:
    ctx.require("registry.edit")
    item = ctx.get(Item, item_id)
    get_unit(ctx.db, from_unit), get_unit(ctx.db, to_unit)
    if D(factor) <= 0:
        raise ValidationFailed("Conversion factor must be positive")
    if _global_factor(ctx.db, from_unit, to_unit) is not None:
        raise ValidationFailed(f"{from_unit}→{to_unit} is a fixed global conversion and needs no item rule")
    conv = ItemUnitConversion(item_id=item.id, from_unit=from_unit, to_unit=to_unit, factor=q(factor), basis=basis)
    ctx.db.add(conv)
    ctx.db.flush()
    ctx.audit("item.conversion.propose", "item", item.id, after=row_dict(conv))
    return conv


def approve_conversion(ctx: Ctx, conversion_id: int) -> ItemUnitConversion:
    ctx.require("registry.approve_conversion")
    conv = ctx.get(ItemUnitConversion, conversion_id)
    if conv.status != "proposed":
        raise ValidationFailed(f"Conversion is {conv.status}")
    conv.status = "approved"
    conv.approved_by = ctx.user.id
    conv.approved_at = utcnow()
    ctx.audit("item.conversion.approve", "item", conv.item_id, after=row_dict(conv))
    return conv


def find_item(db: Session, code: str, revision: str | None = None) -> Item:
    stmt = select(Item).where(Item.item_code == code)
    if revision:
        stmt = stmt.where(Item.revision == revision)
    else:
        stmt = stmt.where(Item.active_status == "active").order_by(Item.revision.desc())
    item = db.execute(stmt).scalars().first()
    if item is None:
        raise NotFound(f"Item {code} not found")
    return item


def item_summary(item: Item) -> dict:
    d = row_dict(item)
    d["unknown_specifications"] = unknown_specifications(item)
    d["conversions"] = [row_dict(c) for c in item.conversions]
    d["supplier_refs"] = [row_dict(r) for r in item.supplier_refs]
    d["certification_note"] = (
        "Certifications are listed only where evidence is recorded. Passing inspections does not imply certification."
    )
    return d


def as_of(dt: datetime | None) -> datetime:
    return dt or utcnow()
