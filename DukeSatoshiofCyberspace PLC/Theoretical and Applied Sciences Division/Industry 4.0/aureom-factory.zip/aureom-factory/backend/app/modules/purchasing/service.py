"""Procurement workflow: requisition → approval → PO → acknowledgement → receipt → reconciliation."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...core.context import Ctx, check_version, row_dict, utcnow
from ...core.errors import Conflict, InvalidState, QualityHold, ValidationFailed
from ...core.numbers import D, ZERO, fmt, money, q
from ..costing.fx import to_base_currency
from ..inventory.models import Bin, Lot
from ..inventory.service import bin_by_code, create_lot, lot_on_hand, post_movement, set_lot_status
from ..registry.models import Item, ItemSupplierRef
from ..registry.service import conversion_factor, convert, get_unit
from .models import (
    GoodsReceipt, PurchaseOrder, PurchaseOrderLine, PurchaseRequisition, ReceiptLine, SubstitutionRequest,
    Supplier, SupplierInvoice, SupplierInvoiceLine, SupplierReturn,
)

OVER_RECEIPT_TOLERANCE_PCT = Decimal("2")
PRICE_TOLERANCE_PCT = Decimal("0.5")


# --------------------------------------------------------------------------- requisitions


def create_requisition(ctx: Ctx, site_id: int, item_id: int, quantity, unit: str, needed_by: date | None,
                       justification: str | None = None, source="manual", mrp_proposal_id=None,
                       suggested_supplier_id=None) -> PurchaseRequisition:
    ctx.require("purchasing.requisition", site_id)
    item = ctx.get(Item, item_id)
    conversion_factor(ctx.db, unit, item.base_unit, item.id)
    if D(quantity) <= 0:
        raise ValidationFailed("Quantity must be positive")
    pr = PurchaseRequisition(
        number=ctx.next_number("PR"), site_id=site_id, item_id=item_id, quantity=D(quantity), unit=unit,
        needed_by=needed_by, justification=justification, source=source, mrp_proposal_id=mrp_proposal_id,
        suggested_supplier_id=suggested_supplier_id, requested_by=ctx.user.id, status="submitted",
    )
    ctx.db.add(pr)
    ctx.db.flush()
    ctx.audit("requisition.create", "purchase_requisition", pr.id, after=row_dict(pr), site_id=site_id)
    return pr


def decide_requisition(ctx: Ctx, pr_id: int, approve: bool, note: str | None = None) -> PurchaseRequisition:
    pr = ctx.get(PurchaseRequisition, pr_id)
    ctx.require("purchasing.approve", pr.site_id)
    if pr.status != "submitted":
        raise InvalidState(f"Requisition {pr.number} is {pr.status}")
    if pr.requested_by == ctx.user.id:
        raise ValidationFailed("Segregation of duties: you cannot approve your own requisition")
    pr.status = "approved" if approve else "rejected"
    pr.approved_by = ctx.user.id
    pr.approved_at = utcnow()
    ctx.audit("requisition." + pr.status, "purchase_requisition", pr.id, reason=note, site_id=pr.site_id)
    return pr


# --------------------------------------------------------------------------- purchase orders


def _supplier_ref(db: Session, item_id: int, supplier_id: int) -> ItemSupplierRef | None:
    return db.execute(select(ItemSupplierRef).where(
        ItemSupplierRef.item_id == item_id, ItemSupplierRef.supplier_id == supplier_id
    )).scalar_one_or_none()


def create_po(ctx: Ctx, site_id: int, supplier_id: int, lines: list[dict], *, order_date: date | None = None,
              requisition_ids: list[int] | None = None, notes: str | None = None, is_subcontract=False) -> PurchaseOrder:
    ctx.require("purchasing.order", site_id)
    sup = ctx.get(Supplier, supplier_id)
    if not sup.approved:
        raise ValidationFailed(f"Supplier {sup.code} is not approved")
    po = PurchaseOrder(number=ctx.next_number("PO"), site_id=site_id, supplier_id=sup.id, currency=sup.currency,
                       order_date=order_date or date.today(), created_by=ctx.user.id, notes=notes,
                       is_subcontract=is_subcontract)
    ctx.db.add(po)
    ctx.db.flush()
    reqs = [ctx.get(PurchaseRequisition, rid) for rid in (requisition_ids or [])]
    for r in reqs:
        if r.status != "approved":
            raise InvalidState(f"Requisition {r.number} is {r.status}; only approved requisitions can be ordered")
    for i, ld in enumerate(lines, start=1):
        item = ctx.get(Item, ld["item_id"])
        ref = _supplier_ref(ctx.db, item.id, sup.id)
        unit = ld.get("unit") or (ref.purchase_unit if ref else item.base_unit)
        conversion_factor(ctx.db, unit, item.base_unit, item.id)
        price = ld.get("unit_price", ref.price if ref else None)
        if price is None:
            raise ValidationFailed(f"No agreed price for {item.item_code} from {sup.code}")
        currency = ld.get("currency") or (ref.currency if ref and ref.currency else sup.currency)
        if currency != po.currency:
            raise ValidationFailed(f"Line currency {currency} differs from PO currency {po.currency}")
        line = PurchaseOrderLine(
            po_id=po.id, line_no=i * 10, item_id=item.id, specification_ref=ld.get("specification_ref"),
            quantity_ordered=D(ld["quantity"]), unit=unit, unit_price=D(price), currency=currency,
            price_date=ld.get("price_date") or (ref.price_date.date() if ref and ref.price_date else po.order_date),
            expected_delivery=ld.get("expected_delivery"),
            inspection_required=ld.get("inspection_required", item.incoming_inspection_required),
            certificate_required=ld.get("certificate_required", False),
            production_order_id=ld.get("production_order_id"),
        )
        ctx.db.add(line)
        ctx.db.flush()
        for r in reqs:
            if r.item_id == item.id and r.purchase_order_line_id is None:
                r.purchase_order_line_id = line.id
                r.status = "converted"
    ctx.audit("po.create", "purchase_order", po.id, after=row_dict(po), site_id=site_id)
    return po


def approve_po(ctx: Ctx, po_id: int, version: int | None) -> PurchaseOrder:
    po = ctx.get(PurchaseOrder, po_id)
    ctx.require("purchasing.approve", po.site_id)
    check_version(po, version)
    if po.status != "draft":
        raise InvalidState(f"PO {po.number} is {po.status}")
    if po.created_by == ctx.user.id:
        raise ValidationFailed("Segregation of duties: the PO author cannot approve it")
    po.status = "approved"
    po.approved_by = ctx.user.id
    po.approved_at = utcnow()
    ctx.audit("po.approve", "purchase_order", po.id, site_id=po.site_id)
    return po


def send_po(ctx: Ctx, po_id: int) -> dict:
    from ...adapters.registry import adapters

    po = ctx.get(PurchaseOrder, po_id)
    ctx.require("purchasing.order", po.site_id)
    if po.status != "approved":
        raise InvalidState(f"PO {po.number} must be approved before sending (is {po.status})")
    result = adapters().supplier.send_purchase_order(po_payload(ctx.db, po))
    po.status = "sent"
    po.sent_at = utcnow()
    ctx.audit("po.send", "purchase_order", po.id, after={"adapter_result": result.__dict__}, site_id=po.site_id)
    return result.__dict__


def acknowledge_po(ctx: Ctx, po_id: int, ack_ref: str, line_dates: dict[int, date] | None = None,
                   acknowledged_at: datetime | None = None) -> PurchaseOrder:
    po = ctx.get(PurchaseOrder, po_id)
    ctx.require("purchasing.order", po.site_id)
    if po.status not in ("sent", "approved"):
        raise InvalidState(f"PO {po.number} is {po.status}")
    po.status = "acknowledged"
    po.supplier_ack_ref = ack_ref
    po.acknowledged_at = acknowledged_at or utcnow()
    for line in po.lines:
        if line_dates and line.id in line_dates:
            line.acknowledged_delivery = line_dates[line.id]
        elif line.acknowledged_delivery is None:
            line.acknowledged_delivery = line.expected_delivery
    ctx.audit("po.acknowledge", "purchase_order", po.id, after={"ack_ref": ack_ref}, site_id=po.site_id)
    return po


def po_payload(db: Session, po: PurchaseOrder) -> dict:
    sup = db.get(Supplier, po.supplier_id)
    return {
        "number": po.number, "supplier": sup.code, "currency": po.currency,
        "lines": [{
            "line_no": l.line_no, "item_code": db.get(Item, l.item_id).item_code,
            "supplier_part": (_supplier_ref(db, l.item_id, po.supplier_id) or type("x", (), {"supplier_part_number": None})).supplier_part_number,
            "quantity": str(l.quantity_ordered), "unit": l.unit, "unit_price": str(l.unit_price),
            "expected_delivery": l.expected_delivery.isoformat() if l.expected_delivery else None,
        } for l in po.lines],
    }


# --------------------------------------------------------------------------- substitutions


def request_substitution(ctx: Ctx, po_line_id: int, proposed_item_id: int, reason: str) -> SubstitutionRequest:
    line = ctx.get(PurchaseOrderLine, po_line_id)
    ctx.require("purchasing.order", line.po.site_id)
    ctx.get(Item, proposed_item_id)
    sr = SubstitutionRequest(po_line_id=line.id, proposed_item_id=proposed_item_id, reason=reason, requested_by=ctx.user.id)
    ctx.db.add(sr)
    ctx.db.flush()
    ctx.audit("substitution.request", "substitution_request", sr.id, after=row_dict(sr))
    return sr


def decide_substitution(ctx: Ctx, sr_id: int, approve: bool, note: str) -> SubstitutionRequest:
    ctx.require("purchasing.approve_substitution")
    sr = ctx.get(SubstitutionRequest, sr_id)
    if sr.status != "pending":
        raise InvalidState(f"Substitution request is {sr.status}")
    if sr.requested_by == ctx.user.id:
        raise ValidationFailed("Segregation of duties: requester cannot approve substitution")
    sr.status = "approved" if approve else "rejected"
    sr.decided_by, sr.decided_at, sr.decision_note = ctx.user.id, utcnow(), note
    ctx.audit("substitution." + sr.status, "substitution_request", sr.id, reason=note)
    return sr


# --------------------------------------------------------------------------- receipts


def receive(ctx: Ctx, po_id: int, lines: list[dict], *, received_at: datetime | None = None,
            delivery_note_ref: str | None = None, carrier: str | None = None, condition_note: str | None = None,
            receiving_bin_code: str = "RCV-01", quarantine_bin_code: str = "QTN-01",
            idempotency_key: str | None = None) -> GoodsReceipt:
    """Record a (possibly partial) delivery. All received stock lands in a NON-allocatable bin with
    status awaiting_review; nothing becomes available until quality releases it."""
    po = ctx.get(PurchaseOrder, po_id)
    ctx.require("purchasing.receive", po.site_id)
    if idempotency_key:
        existing = ctx.db.execute(select(GoodsReceipt).where(GoodsReceipt.idempotency_key == idempotency_key)).scalar_one_or_none()
        if existing:
            if existing.po_id != po.id:
                raise Conflict("Idempotency key reused for a different purchase order")
            return existing
    if po.status not in ("sent", "acknowledged", "partially_received"):
        raise InvalidState(f"PO {po.number} is {po.status}; goods cannot be received against it")
    received_at = received_at or utcnow()
    rcv_bin, qtn_bin = bin_by_code(ctx.db, receiving_bin_code), bin_by_code(ctx.db, quarantine_bin_code)
    gr = GoodsReceipt(number=ctx.next_number("GR"), site_id=po.site_id, po_id=po.id, supplier_id=po.supplier_id,
                      delivery_note_ref=delivery_note_ref, carrier=carrier, received_at=received_at,
                      received_by=ctx.user.id, condition_note=condition_note, idempotency_key=idempotency_key)
    ctx.db.add(gr)
    ctx.db.flush()
    max_late = 0
    from ..quality.service import open_incoming_inspection

    for ld in lines:
        pol = ctx.get(PurchaseOrderLine, ld["po_line_id"], "PO line")
        if pol.po_id != po.id:
            raise ValidationFailed("PO line does not belong to this order")
        if pol.status in ("closed", "cancelled"):
            raise InvalidState(f"PO line {pol.line_no} is {pol.status}")
        item_id = ld.get("item_id", pol.item_id)
        sub = None
        if item_id != pol.item_id:
            sub = ctx.db.execute(select(SubstitutionRequest).where(
                SubstitutionRequest.po_line_id == pol.id, SubstitutionRequest.proposed_item_id == item_id,
                SubstitutionRequest.status == "approved")).scalar_one_or_none()
            if sub is None:
                raise QualityHold("Delivered item differs from the order and no approved substitution exists")
        item = ctx.get(Item, item_id)
        unit = ld.get("unit", pol.unit)
        qty = D(ld["quantity"])
        damaged = D(ld.get("damaged_quantity", 0))
        if damaged > qty:
            raise ValidationFailed("Damaged quantity exceeds quantity delivered")
        qty_po_unit = convert(ctx.db, qty, unit, pol.unit, item.id) if unit != pol.unit else qty
        limit = D(pol.quantity_ordered) * (1 + OVER_RECEIPT_TOLERANCE_PCT / 100)
        if D(pol.quantity_received) + qty_po_unit > limit:
            raise ValidationFailed(
                f"Receipt would exceed ordered quantity by more than {OVER_RECEIPT_TOLERANCE_PCT}% "
                f"(ordered {fmt(pol.quantity_ordered)}, already received {fmt(pol.quantity_received)})"
            )
        base_qty = convert(ctx.db, qty, unit, item.base_unit, item.id)
        base_damaged = convert(ctx.db, damaged, unit, item.base_unit, item.id)
        # cost in base currency per base unit, at the receipt date's exchange rate
        per_base = D(pol.unit_price) / conversion_factor(ctx.db, pol.unit, item.base_unit, item.id)
        unit_cost, fx, fx_date = to_base_currency(ctx.db, per_base, pol.currency, received_at.date())
        cert_status = "not_required"
        if pol.certificate_required:
            cert_status = "received" if ld.get("certificate_document_id") else "missing"
        rl = ReceiptLine(receipt_id=gr.id, po_line_id=pol.id, item_id=item.id, substitution_request_id=sub.id if sub else None,
                         quantity=qty_po_unit, unit=pol.unit, base_quantity=base_qty, damaged_quantity=convert(ctx.db, damaged, unit, pol.unit, item.id) if damaged else ZERO,
                         supplier_lot=ld.get("supplier_lot"), certificate_document_id=ld.get("certificate_document_id"),
                         certificate_status=cert_status, unit_cost_base=money(unit_cost), fx_rate=q(fx), fx_rate_date=fx_date)
        ctx.db.add(rl)
        ctx.db.flush()
        good_qty = base_qty - base_damaged
        lot_kwargs = dict(supplier_id=po.supplier_id, supplier_lot=ld.get("supplier_lot"), receipt_line_id=rl.id,
                          manufactured_on=ld.get("manufactured_on"), expiry_date=ld.get("expiry_date"),
                          unit_cost=money(unit_cost), cost_basis=f"PO {po.number} price {pol.unit_price} {pol.currency}/{pol.unit} @ {fx} ({fx_date})",
                          traceability="complete" if ld.get("supplier_lot") else "partial",
                          traceability_note=None if ld.get("supplier_lot") else "Supplier did not provide a lot identifier")
        if item.lot_or_serial_policy == "serial":
            serials = ld.get("serials") or []
            if len(serials) != int(good_qty):
                raise ValidationFailed("Serial-controlled items need one serial number per unit received")
            for s in serials:
                lot = create_lot(ctx, item, s, "purchase", **lot_kwargs)
                post_movement(ctx, "receipt", item, 1, item.base_unit, lot=lot, to_bin=rcv_bin, reference_type="receipt_line",
                              reference_id=rl.id, value_source="scanned", observed_at=received_at)
            rl.lot_id = lot.id if serials else None
        elif good_qty > 0:
            lot = create_lot(ctx, item, ld.get("lot_number") or ctx.next_number("LOT"), "purchase", **lot_kwargs)
            rl.lot_id = lot.id
            post_movement(ctx, "receipt", item, good_qty, item.base_unit, lot=lot, to_bin=rcv_bin, reference_type="receipt_line",
                          reference_id=rl.id, value_source=ld.get("value_source", "manual"), observed_at=received_at,
                          idempotency_key=f"{idempotency_key}:{pol.id}" if idempotency_key else None)
        if base_damaged > 0:
            dlot = create_lot(ctx, item, ctx.next_number("LOT") + "-DMG", "purchase", quality_status="quarantined",
                              **{**lot_kwargs, "traceability_note": "Damaged on arrival; segregated at receipt"})
            rl.damaged_lot_id = dlot.id
            post_movement(ctx, "receipt", item, base_damaged, item.base_unit, lot=dlot, to_bin=qtn_bin,
                          reference_type="receipt_line", reference_id=rl.id, reason_code="damaged_on_arrival",
                          observed_at=received_at)
        pol.quantity_received = q(D(pol.quantity_received) + qty_po_unit)
        pol.status = "received" if pol.quantity_received >= pol.quantity_ordered else "partially_received"
        due = pol.acknowledged_delivery or pol.expected_delivery
        if due and received_at.date() > due:
            max_late = max(max_late, (received_at.date() - due).days)
        if rl.lot_id:
            open_incoming_inspection(ctx, ctx.db.get(Lot, rl.lot_id), rl)
    gr.late_days = max_late
    po.status = "received" if all(l.status in ("received", "closed", "cancelled") for l in po.lines) else "partially_received"
    ctx.audit("receipt.create", "goods_receipt", gr.id, after=row_dict(gr), site_id=po.site_id)
    ctx.emit("purchasing.receipt", {"receipt": gr.number, "po": po.number, "late_days": max_late})
    return gr


def record_lot_decision(db: Session, lot: Lot, accepted_base: Decimal, rejected_base: Decimal) -> None:
    """Called by quality when an incoming lot is dispositioned: keep PO accepted/rejected quantities in step."""
    if not lot.receipt_line_id:
        pol_id = (lot.attributes or {}).get("subcontract_po_line_id")
        if pol_id:
            pol = db.get(PurchaseOrderLine, pol_id)
            pol.quantity_accepted = q(D(pol.quantity_accepted) + accepted_base)
            pol.quantity_rejected = q(D(pol.quantity_rejected) + rejected_base)
        return
    rl = db.get(ReceiptLine, lot.receipt_line_id)
    pol = db.get(PurchaseOrderLine, rl.po_line_id)
    item = db.get(Item, rl.item_id)
    f = conversion_factor(db, item.base_unit, pol.unit, item.id)
    pol.quantity_accepted = q(D(pol.quantity_accepted) + accepted_base * f)
    pol.quantity_rejected = q(D(pol.quantity_rejected) + rejected_base * f)
    new = "accepted" if rejected_base == 0 else ("rejected" if accepted_base == 0 else "partial")
    if rl.inspection_status not in ("awaiting_review", new):
        new = "partial"
    rl.inspection_status = new


# --------------------------------------------------------------------------- supplier returns


def return_to_supplier(ctx: Ctx, lot_id: int, bin_code: str, quantity, reason: str, *, nonconformance_id=None,
                       rma_ref=None, replacement_expected=True, observed_at=None) -> SupplierReturn:
    ctx.require("purchasing.return")
    lot = ctx.get(Lot, lot_id)
    if lot.quality_status == "accepted":
        raise QualityHold("Accepted stock must be placed on hold (quarantined/rejected) before return to supplier")
    if lot.supplier_id is None:
        raise ValidationFailed("Lot has no supplier on record")
    item = ctx.db.get(Item, lot.item_id)
    b = bin_by_code(ctx.db, bin_code)
    rl = ctx.db.get(ReceiptLine, lot.receipt_line_id) if lot.receipt_line_id else None
    sr = SupplierReturn(number=ctx.next_number("SRN"), supplier_id=lot.supplier_id, po_line_id=rl.po_line_id if rl else None,
                        receipt_line_id=rl.id if rl else None, lot_id=lot.id, quantity=D(quantity), reason=reason,
                        nonconformance_id=nonconformance_id, rma_ref=rma_ref, replacement_expected=replacement_expected,
                        created_by=ctx.user.id)
    ctx.db.add(sr)
    ctx.db.flush()
    post_movement(ctx, "supplier_return", item, quantity, item.base_unit, lot=lot, from_bin=b, reference_type="supplier_return",
                  reference_id=sr.id, reason_code="return_to_supplier", notes=reason, observed_at=observed_at,
                  skip_quality_gate=True)
    if rl:
        pol = ctx.db.get(PurchaseOrderLine, rl.po_line_id)
        pol.quantity_returned = q(D(pol.quantity_returned) + convert(ctx.db, quantity, item.base_unit, pol.unit, item.id))
        if replacement_expected and pol.status == "received":
            pol.status = "partially_received"  # replacement still outstanding
            pol.po.status = "partially_received"
    ctx.audit("supplier_return.create", "supplier_return", sr.id, after=row_dict(sr), reason=reason)
    return sr


# --------------------------------------------------------------------------- invoices + reconciliation


def record_invoice(ctx: Ctx, supplier_id: int, invoice_number: str, invoice_date: date, currency: str,
                   lines: list[dict]) -> SupplierInvoice:
    ctx.require("purchasing.invoice")
    dup = ctx.db.execute(select(SupplierInvoice).where(SupplierInvoice.supplier_id == supplier_id,
                                                       SupplierInvoice.invoice_number == invoice_number)).scalar_one_or_none()
    if dup:
        raise Conflict(f"Invoice {invoice_number} already recorded for this supplier")
    inv = SupplierInvoice(supplier_id=supplier_id, invoice_number=invoice_number, invoice_date=invoice_date,
                          currency=currency, recorded_by=ctx.user.id)
    ctx.db.add(inv)
    ctx.db.flush()
    results, variance = [], False
    for ld in lines:
        pol = ctx.get(PurchaseOrderLine, ld["po_line_id"])
        if pol.po.supplier_id != supplier_id:
            raise ValidationFailed("Invoice line references another supplier's order")
        if pol.currency != currency:
            raise ValidationFailed("Invoice currency differs from order currency")
        qty, price = D(ld["quantity"]), D(ld["unit_price"])
        ctx.db.add(SupplierInvoiceLine(invoice_id=inv.id, po_line_id=pol.id, quantity=qty, unit_price=price))
        invoiced_total = D(pol.quantity_invoiced) + qty
        payable = D(pol.quantity_accepted)
        flags = []
        if invoiced_total > payable:
            flags.append(f"quantity: invoiced {fmt(invoiced_total)} > accepted {fmt(payable)} {pol.unit}")
        if pol.unit_price and abs(price - D(pol.unit_price)) / D(pol.unit_price) * 100 > PRICE_TOLERANCE_PCT:
            flags.append(f"price: invoiced {price} vs agreed {pol.unit_price} {currency}")
        pol.quantity_invoiced = q(invoiced_total)
        variance = variance or bool(flags)
        results.append({"po_line_id": pol.id, "flags": flags, "ordered": str(pol.quantity_ordered),
                        "received": str(pol.quantity_received), "accepted": str(pol.quantity_accepted),
                        "invoiced": str(pol.quantity_invoiced)})
    inv.status = "variance" if variance else "matched"
    inv.match_result = {"lines": results}
    ctx.audit("invoice.record", "supplier_invoice", inv.id, after={"status": inv.status, "lines": results})
    return inv


def po_reconciliation(db: Session, po: PurchaseOrder, today: date | None = None) -> dict:
    today = today or date.today()
    sup = db.get(Supplier, po.supplier_id)
    lines = []
    for l in po.lines:
        item = db.get(Item, l.item_id)
        outstanding = max(ZERO, D(l.quantity_ordered) - D(l.quantity_received) + D(l.quantity_returned))
        due = l.acknowledged_delivery or l.expected_delivery
        lines.append({
            "po_line_id": l.id, "line_no": l.line_no, "item_code": item.item_code, "description": item.description,
            "unit": l.unit, "unit_price": str(l.unit_price), "currency": l.currency, "price_date": l.price_date.isoformat(),
            "ordered": str(l.quantity_ordered), "received": str(l.quantity_received), "accepted": str(l.quantity_accepted),
            "rejected": str(l.quantity_rejected), "returned": str(l.quantity_returned), "invoiced": str(l.quantity_invoiced),
            "outstanding": str(q(outstanding)), "expected_delivery": due.isoformat() if due else None,
            "late": bool(due and outstanding > 0 and today > due), "status": l.status,
            "line_value": str(money(D(l.quantity_ordered) * D(l.unit_price))),
        })
    return {"po": row_dict(po), "supplier": {"code": sup.code, "name": sup.name}, "lines": lines}
