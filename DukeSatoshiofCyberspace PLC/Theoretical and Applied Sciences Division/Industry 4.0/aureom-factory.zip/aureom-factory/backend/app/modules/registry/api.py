from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Any, Literal

from fastapi import APIRouter
from pydantic import Field
from sqlalchemy import or_, select

from ...api_deps import Body, CtxDep
from ...core.context import row_dict
from .models import Item, ItemUnitConversion, Unit
from .service import (
    approve_conversion, convert, create_item, item_summary, propose_conversion, unknown_specifications, update_item,
)

router = APIRouter(prefix="/api", tags=["materials"])


class Spec(Body):
    name: str
    status: Literal["specified", "unknown", "not_applicable"]
    value: Any = None
    unit: str | None = None
    tolerance: str | None = None
    source: str | None = None


class ItemCreate(Body):
    item_code: str = Field(min_length=2, max_length=64, pattern=r"^[A-Z0-9][A-Z0-9._-]*$")
    revision: str = "A"
    description: str = Field(min_length=3, max_length=300)
    item_type: Literal["raw_material", "purchased_component", "consumable", "wip", "subassembly", "finished_product",
                       "packaging", "recoverable_scrap"]
    base_unit: str
    specifications: list[Spec] = []
    storage_requirements: str | None = None
    lot_or_serial_policy: Literal["none", "lot", "serial"] = "lot"
    shelf_life_applicable: bool = False
    shelf_life_days: int | None = Field(default=None, gt=0)
    make_or_buy: Literal["make", "buy", "subcon"] = "buy"
    lead_time_days: int = Field(default=0, ge=0)
    lot_size_min: Decimal = Field(default=Decimal(0), ge=0)
    lot_size_multiple: Decimal = Field(default=Decimal(0), ge=0)
    safety_stock: Decimal = Field(default=Decimal(0), ge=0)
    standard_batch_quantity: Decimal = Field(default=Decimal(1), gt=0)
    incoming_inspection_required: bool = True
    standard_cost: Decimal | None = Field(default=None, ge=0)
    standard_cost_currency: str | None = None


class ItemPatch(Body):
    version: int
    changes: dict[str, Any]


class ConversionBody(Body):
    from_unit: str
    to_unit: str
    factor: Decimal = Field(gt=0)
    basis: str = Field(min_length=3)


class ConvertBody(Body):
    quantity: Decimal
    from_unit: str
    to_unit: str
    item_id: int | None = None


@router.get("/units")
def units(ctx: CtxDep):
    return [row_dict(u) for u in ctx.db.execute(select(Unit).order_by(Unit.dimension, Unit.code)).scalars()]


@router.get("/items")
def list_items(ctx: CtxDep, item_type: str | None = None, q: str | None = None, active: bool | None = None):
    ctx.require("registry.read")
    stmt = select(Item).order_by(Item.item_type, Item.item_code)
    if item_type:
        stmt = stmt.where(Item.item_type == item_type)
    if q:
        stmt = stmt.where(or_(Item.item_code.ilike(f"%{q}%"), Item.description.ilike(f"%{q}%")))
    if active is not None:
        stmt = stmt.where(Item.active_status == ("active" if active else "inactive"))
    return [{**row_dict(i), "unknown_specifications": unknown_specifications(i)} for i in ctx.db.execute(stmt).scalars()]


@router.post("/items", status_code=201)
def post_item(body: ItemCreate, ctx: CtxDep):
    data = body.model_dump()
    data["specifications"] = [s.model_dump() for s in body.specifications]
    return item_summary(create_item(ctx, data))


@router.get("/items/{item_id}")
def get_item(item_id: int, ctx: CtxDep):
    ctx.require("registry.read")
    return item_summary(ctx.get(Item, item_id))


@router.patch("/items/{item_id}")
def patch_item(item_id: int, body: ItemPatch, ctx: CtxDep):
    return item_summary(update_item(ctx, item_id, body.version, body.changes))


@router.post("/items/{item_id}/conversions", status_code=201)
def post_conversion(item_id: int, body: ConversionBody, ctx: CtxDep):
    return row_dict(propose_conversion(ctx, item_id, body.from_unit, body.to_unit, body.factor, body.basis))


@router.post("/conversions/{conversion_id}/approve")
def post_approve_conversion(conversion_id: int, ctx: CtxDep):
    return row_dict(approve_conversion(ctx, conversion_id))


@router.post("/convert")
def post_convert(body: ConvertBody, ctx: CtxDep):
    ctx.require("registry.read")
    return {"quantity": str(convert(ctx.db, body.quantity, body.from_unit, body.to_unit, body.item_id)), "unit": body.to_unit}
