"""Production orders and their execution records.

Planned activity (order quantities, planned dates, required materials), physical movements
(stock journal), recorded consumption, operation completion and quality-accepted output are
held in separate fields/tables and never inferred from one another.
"""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import BigInteger, Boolean, CheckConstraint, Date, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ...core.models import JSONType
from ...db import Base, Money, Qty, TimestampMixin

ORDER_STATUSES = ("draft", "planned", "released", "in_progress", "paused", "awaiting_inspection",
                  "completed", "closed", "cancelled")


class ProductionOrder(Base, TimestampMixin):
    __tablename__ = "production_orders"
    __table_args__ = (
        CheckConstraint(f"status IN {ORDER_STATUSES}", name="status"),
        CheckConstraint("quantity_target > 0", name="target"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"))
    kind: Mapped[str] = mapped_column(String(16), default="standard")  # standard / rework / subcontract
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    quantity_target: Mapped[Decimal] = mapped_column(Qty)  # good output required (base unit)
    quantity_start: Mapped[Decimal] = mapped_column(Qty)  # planned start quantity after expected yield
    status: Mapped[str] = mapped_column(String(24), default="draft")
    bom_id: Mapped[int | None] = mapped_column(ForeignKey("boms.id"))
    bom_version: Mapped[int | None] = mapped_column(Integer)
    routing_id: Mapped[int | None] = mapped_column(ForeignKey("routings.id"))
    routing_version: Mapped[int | None] = mapped_column(Integer)
    snapshot: Mapped[dict[str, Any] | None] = mapped_column(JSONType)  # frozen at release
    planned_start: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    planned_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    due_date: Mapped[date | None] = mapped_column(Date)
    schedule_feasible: Mapped[bool | None] = mapped_column(Boolean)
    schedule_notes: Mapped[list[str] | None] = mapped_column(JSONType)
    source: Mapped[str] = mapped_column(String(16), default="manual")  # manual / mrp
    mrp_proposal_id: Mapped[int | None] = mapped_column(ForeignKey("mrp_proposals.id"))
    demand_id: Mapped[int | None] = mapped_column(ForeignKey("demands.id"))
    parent_order_id: Mapped[int | None] = mapped_column(ForeignKey("production_orders.id"))
    nonconformance_id: Mapped[int | None] = mapped_column(ForeignKey("nonconformances.id", use_alter=True))
    rework_instructions: Mapped[str | None] = mapped_column(Text)
    # Outcome counters (base unit). accepted is set ONLY by quality release of output lots.
    quantity_reported: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_nonconforming: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_accepted: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_scrapped: Mapped[Decimal] = mapped_column(Qty, default=0)
    planned_cost: Mapped[dict[str, Any] | None] = mapped_column(JSONType)
    released_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    released_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    closed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    cancel_reason: Mapped[str | None] = mapped_column(Text)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    version: Mapped[int] = mapped_column(Integer, default=1)
    __mapper_args__ = {"version_id_col": version}
    materials: Mapped[list["OrderMaterial"]] = relationship(back_populates="order", cascade="all, delete-orphan",
                                                            order_by="OrderMaterial.line_no")
    operations: Mapped[list["OrderOperation"]] = relationship(back_populates="order", cascade="all, delete-orphan",
                                                              order_by="OrderOperation.seq")


class OrderMaterial(Base):
    __tablename__ = "order_materials"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("production_orders.id", ondelete="CASCADE"))
    line_no: Mapped[int] = mapped_column(Integer)
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    alternative_item_ids: Mapped[list[int]] = mapped_column(JSONType, default=list)
    required_quantity: Mapped[Decimal] = mapped_column(Qty)  # planned, base unit
    unit: Mapped[str] = mapped_column(String(16))
    is_packaging: Mapped[bool] = mapped_column(Boolean, default=False)
    backflush: Mapped[bool] = mapped_column(Boolean, default=False)
    operation_seq: Mapped[int | None] = mapped_column(Integer)
    additional: Mapped[bool] = mapped_column(Boolean, default=False)  # added beyond the snapshot (e.g. rework)
    quantity_issued: Mapped[Decimal] = mapped_column(Qty, default=0)  # physically moved to line-side
    quantity_consumed: Mapped[Decimal] = mapped_column(Qty, default=0)  # recorded as used (actual + calculated)
    quantity_consumed_calculated: Mapped[Decimal] = mapped_column(Qty, default=0)  # backflush portion
    quantity_returned: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_scrapped: Mapped[Decimal] = mapped_column(Qty, default=0)
    order: Mapped[ProductionOrder] = relationship(back_populates="materials")


class OrderOperation(Base):
    __tablename__ = "order_operations"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("production_orders.id", ondelete="CASCADE"))
    seq: Mapped[int] = mapped_column(Integer)
    code: Mapped[str] = mapped_column(String(32))
    name: Mapped[str] = mapped_column(String(200))
    work_centre_id: Mapped[int] = mapped_column(ForeignKey("work_centres.id"))
    required_equipment_kind: Mapped[str | None] = mapped_column(String(64))
    required_skill: Mapped[str | None] = mapped_column(String(64))
    setup_minutes: Mapped[Decimal] = mapped_column(Qty, default=0)
    run_minutes_per_unit: Mapped[Decimal] = mapped_column(Qty, default=0)
    machine_minutes_per_unit: Mapped[Decimal] = mapped_column(Qty, default=0)
    inspection_point: Mapped[bool] = mapped_column(Boolean, default=False)
    inspection_plan_code: Mapped[str | None] = mapped_column(String(32))
    instructions: Mapped[str | None] = mapped_column(Text)
    instruction_document_id: Mapped[int | None] = mapped_column(ForeignKey("documents.id"))
    depends_on: Mapped[list[int]] = mapped_column(JSONType, default=list)
    subcontracted: Mapped[bool] = mapped_column(Boolean, default=False)
    subcontract_supplier_id: Mapped[int | None] = mapped_column(ForeignKey("suppliers.id"))
    subcontract_lead_days: Mapped[int] = mapped_column(Integer, default=0)
    reports_output: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(16), default="pending")
    # pending / ready / in_progress / paused / completed / handed_over
    planned_start: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    planned_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    planned_equipment_id: Mapped[int | None] = mapped_column(ForeignKey("equipment.id"))
    planned_operator_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    quantity_good: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_scrap: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_rework: Mapped[Decimal] = mapped_column(Qty, default=0)
    actual_start: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    actual_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    order: Mapped[ProductionOrder] = relationship(back_populates="operations")


class OperationEvent(Base):
    """Append-only shop-floor event log. observed_at = when it happened; recorded_at = when entered."""

    __tablename__ = "operation_events"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    order_operation_id: Mapped[int] = mapped_column(ForeignKey("order_operations.id"), index=True)
    event: Mapped[str] = mapped_column(String(24))
    # equipment_check / start / pause / resume / complete / handover / measurement / defect / note
    operator_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    equipment_id: Mapped[int | None] = mapped_column(ForeignKey("equipment.id"))
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    value_source: Mapped[str] = mapped_column(String(16), default="manual")
    quantity: Mapped[Decimal | None] = mapped_column(Qty)
    data: Mapped[dict[str, Any] | None] = mapped_column(JSONType)
    note: Mapped[str | None] = mapped_column(Text)
    offline_entry_id: Mapped[int | None] = mapped_column(ForeignKey("offline_entries.id"))


class ProductionOutput(Base, TimestampMixin):
    __tablename__ = "production_outputs"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("production_orders.id"), index=True)
    order_operation_id: Mapped[int | None] = mapped_column(ForeignKey("order_operations.id"))
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    lot_id: Mapped[int] = mapped_column(ForeignKey("lots.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    conformity: Mapped[str] = mapped_column(String(16), default="good")  # good / nonconforming
    movement_id: Mapped[int | None] = mapped_column(ForeignKey("stock_movements.id"))
    recorded_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    value_source: Mapped[str] = mapped_column(String(16), default="manual")


class ScrapRecord(Base, TimestampMixin):
    __tablename__ = "scrap_records"
    __table_args__ = (CheckConstraint("quantity > 0", name="qty"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    order_id: Mapped[int | None] = mapped_column(ForeignKey("production_orders.id"), index=True)
    order_operation_id: Mapped[int | None] = mapped_column(ForeignKey("order_operations.id"))
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    unit: Mapped[str] = mapped_column(String(16))
    kind: Mapped[str] = mapped_column(String(16))  # material (input) / product (WIP or output units)
    reason_code: Mapped[str] = mapped_column(String(64))
    reason: Mapped[str] = mapped_column(Text)
    location_bin_id: Mapped[int | None] = mapped_column(ForeignKey("bins.id"))
    recoverable: Mapped[bool] = mapped_column(Boolean, default=False)
    recovered_item_id: Mapped[int | None] = mapped_column(ForeignKey("items.id"))
    recovered_quantity: Mapped[Decimal | None] = mapped_column(Qty)
    recovered_lot_id: Mapped[int | None] = mapped_column(ForeignKey("lots.id"))
    status: Mapped[str] = mapped_column(String(24), default="pending_authorisation")  # pending_authorisation / authorised / rejected
    reported_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    authorised_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    authorised_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    cost_value: Mapped[Decimal | None] = mapped_column(Money)


class OrderException(Base, TimestampMixin):
    __tablename__ = "order_exceptions"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("production_orders.id"), index=True)
    kind: Mapped[str] = mapped_column(String(32))  # equipment_down / material_shortage / defect / schedule / other
    severity: Mapped[str] = mapped_column(String(16), default="constraint")  # constraint (amber) / failure (red)
    description: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16), default="open")
    raised_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    resolution: Mapped[str | None] = mapped_column(Text)


class SubcontractShipment(Base, TimestampMixin):
    """Material sent to a subcontractor for an external operation and what came back."""

    __tablename__ = "subcontract_shipments"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("production_orders.id"))
    order_operation_id: Mapped[int] = mapped_column(ForeignKey("order_operations.id"))
    supplier_id: Mapped[int] = mapped_column(ForeignKey("suppliers.id"))
    po_id: Mapped[int | None] = mapped_column(ForeignKey("purchase_orders.id"))
    status: Mapped[str] = mapped_column(String(16), default="sent")  # sent / partially_returned / returned / closed
    sent_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    sent_lines: Mapped[list[dict[str, Any]]] = mapped_column(JSONType, default=list)  # [{lot_id, item_id, qty}]
    quantity_sent: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_returned: Mapped[Decimal] = mapped_column(Qty, default=0)
    quantity_lost: Mapped[Decimal] = mapped_column(Qty, default=0)
    supplier_documents: Mapped[list[dict[str, Any]]] = mapped_column(JSONType, default=list)
    loss_explanation: Mapped[str | None] = mapped_column(Text)
    returned_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))


class BackflushReconciliation(Base, TimestampMixin):
    __tablename__ = "backflush_reconciliations"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("production_orders.id"))
    order_material_id: Mapped[int] = mapped_column(ForeignKey("order_materials.id"))
    calculated_quantity: Mapped[Decimal] = mapped_column(Qty)
    actual_quantity: Mapped[Decimal] = mapped_column(Qty)  # issued − counted remaining
    variance: Mapped[Decimal] = mapped_column(Qty)
    counted_remaining: Mapped[Decimal] = mapped_column(Qty)
    adjustment_movement_id: Mapped[int | None] = mapped_column(ForeignKey("stock_movements.id"))
    note: Mapped[str | None] = mapped_column(Text)
    reconciled_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
