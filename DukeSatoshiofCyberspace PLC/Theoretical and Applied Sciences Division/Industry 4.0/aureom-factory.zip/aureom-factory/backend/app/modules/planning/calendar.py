"""Working-time calendars and interval arithmetic used by scheduling and OEE."""
from __future__ import annotations

from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

DAYS = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")
TZ = ZoneInfo("Europe/London")

Interval = tuple[datetime, datetime]


def working_intervals(calendar: dict | None, holidays: list[str] | None, start: datetime, end: datetime,
                      tz: ZoneInfo = TZ) -> list[Interval]:
    calendar = calendar or {}
    hol = set(holidays or [])
    out: list[Interval] = []
    d = start.astimezone(tz).date() - timedelta(days=1)
    last = end.astimezone(tz).date()
    while d <= last:
        if d.isoformat() not in hol:
            for s, e in calendar.get(DAYS[d.weekday()], []):
                s_dt = datetime.combine(d, time.fromisoformat(s), tz)
                e_dt = datetime.combine(d, time.fromisoformat(e), tz)
                if e_dt <= s_dt:
                    e_dt += timedelta(days=1)
                lo, hi = max(s_dt, start), min(e_dt, end)
                if hi > lo:
                    out.append((lo, hi))
        d += timedelta(days=1)
    return merge(out)


def merge(intervals: list[Interval]) -> list[Interval]:
    res: list[Interval] = []
    for s, e in sorted(intervals):
        if res and s <= res[-1][1]:
            res[-1] = (res[-1][0], max(res[-1][1], e))
        else:
            res.append((s, e))
    return res


def subtract(base: list[Interval], remove: list[Interval]) -> list[Interval]:
    out = []
    remove = merge(remove)
    for s, e in base:
        cur = s
        for rs, re in remove:
            if re <= cur or rs >= e:
                continue
            if rs > cur:
                out.append((cur, rs))
            cur = max(cur, re)
            if cur >= e:
                break
        if cur < e:
            out.append((cur, e))
    return out


def intersect(a: list[Interval], b: list[Interval]) -> list[Interval]:
    out, i, j = [], 0, 0
    a, b = merge(a), merge(b)
    while i < len(a) and j < len(b):
        lo, hi = max(a[i][0], b[j][0]), min(a[i][1], b[j][1])
        if hi > lo:
            out.append((lo, hi))
        if a[i][1] < b[j][1]:
            i += 1
        else:
            j += 1
    return out


def minutes(intervals: list[Interval]) -> float:
    return sum((e - s).total_seconds() for s, e in intervals) / 60


def allocate(free: list[Interval], earliest: datetime, minutes_needed: float) -> tuple[datetime, datetime, list[Interval]] | None:
    """Consume `minutes_needed` of working time from `free`, starting no earlier than `earliest`.
    Work may span several shifts. Returns (start, end, used_intervals) or None if not enough time."""
    remaining = timedelta(minutes=minutes_needed)
    used: list[Interval] = []
    start = None
    for s, e in free:
        if e <= earliest:
            continue
        s = max(s, earliest)
        if start is None:
            start = s
        avail = e - s
        if avail >= remaining:
            used.append((s, s + remaining))
            return start, s + remaining, used
        used.append((s, e))
        remaining -= avail
    if minutes_needed == 0 and start is None:
        return earliest, earliest, []
    return None
