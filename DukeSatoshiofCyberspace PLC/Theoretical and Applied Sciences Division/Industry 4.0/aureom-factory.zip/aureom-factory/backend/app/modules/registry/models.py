"""Common item registry: one table for every kind of material the factory handles."""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import Boolean, CheckConstraint, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ...core.models import JSONType
from ...db import Base, Money, Qty, TimestampMixin

ITEM_TYPES = (
    "raw_material", "purchased_component", "consumable", "wip", "subassembly",
    "finished_product", "packaging", "recoverable_scrap",
)
LOT_POLICIES = ("none", "lot", "serial")
SPEC_STATUSES = ("specified", "unknown", "not_applicable")
DIMENSIONS = ("mass", "length", "volume", "count", "pack", "time", "area")


class Unit(Base):
    __tablename__ = "units"
    code: Mapped[str] = mapped_column(String(16), primary_key=True)
    name: Mapped[str] = mapped_column(String(64))
    dimension: Mapped[str] = mapped_column(String(16))
    # Factor to the dimension's reference unit (kg, m, L, pc, h, m2). Packs have no global factor.
    factor_to_reference: Mapped[Decimal | None] = mapped_column(Qty)
    integral: Mapped[bool] = mapped_column(Boolean, default=False)  # pieces, packs: whole numbers only
    __table_args__ = (CheckConstraint(f"dimension IN {DIMENSIONS}", name="dimension"),)


class Item(Base, TimestampMixin):
    __tablename__ = "items"
    __table_args__ = (
        UniqueConstraint("item_code", "revision"),
        CheckConstraint(f"item_type IN {ITEM_TYPES}", name="item_type"),
        CheckConstraint(f"lot_or_serial_policy IN {LOT_POLICIES}", name="lot_policy"),
        CheckConstraint("shelf_life_days IS NULL OR shelf_life_days > 0", name="shelf_life"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    item_code: Mapped[str] = mapped_column(String(64), index=True)
    revision: Mapped[str] = mapped_column(String(16), default="A")
    description: Mapped[str] = mapped_column(String(300))
    item_type: Mapped[str] = mapped_column(String(32))
    base_unit: Mapped[str] = mapped_column(ForeignKey("units.code"))
    # [{"name","value","unit","status": specified|unknown|not_applicable,"source","tolerance"}]
    specifications: Mapped[list[dict[str, Any]]] = mapped_column(JSONType, default=list)
    storage_requirements: Mapped[str | None] = mapped_column(Text)
    lot_or_serial_policy: Mapped[str] = mapped_column(String(8), default="lot")
    shelf_life_applicable: Mapped[bool] = mapped_column(Boolean, default=False)
    shelf_life_days: Mapped[int | None] = mapped_column(Integer)
    active_status: Mapped[str] = mapped_column(String(16), default="active")  # active / inactive / obsolete
    make_or_buy: Mapped[str] = mapped_column(String(8), default="buy")  # make / buy / subcon
    lead_time_days: Mapped[int] = mapped_column(Integer, default=0)
    lot_size_min: Mapped[Decimal] = mapped_column(Qty, default=0)
    lot_size_multiple: Mapped[Decimal] = mapped_column(Qty, default=0)
    safety_stock: Mapped[Decimal] = mapped_column(Qty, default=0)
    # Batch size over which setup is amortised in the STANDARD cost roll-up (made items).
    standard_batch_quantity: Mapped[Decimal] = mapped_column(Qty, default=1)
    incoming_inspection_required: Mapped[bool] = mapped_column(Boolean, default=True)
    standard_cost: Mapped[Decimal | None] = mapped_column(Money)
    standard_cost_currency: Mapped[str | None] = mapped_column(String(3))
    standard_cost_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    # Certifications are recorded explicitly with evidence; they are never inferred from checks passing.
    certifications: Mapped[list[dict[str, Any]]] = mapped_column(JSONType, default=list)
    recoverable_scrap_item_id: Mapped[int | None] = mapped_column(ForeignKey("items.id"))
    version: Mapped[int] = mapped_column(Integer, default=1)
    __mapper_args__ = {"version_id_col": version}

    conversions: Mapped[list["ItemUnitConversion"]] = relationship(
        back_populates="item", cascade="all, delete-orphan", foreign_keys="ItemUnitConversion.item_id"
    )
    supplier_refs: Mapped[list["ItemSupplierRef"]] = relationship(back_populates="item", cascade="all, delete-orphan")


class ItemUnitConversion(Base, TimestampMixin):
    """Approved item-specific conversion: 1 from_unit = factor × to_unit (e.g. 1 m bar = 5.301 kg)."""

    __tablename__ = "item_unit_conversions"
    __table_args__ = (UniqueConstraint("item_id", "from_unit", "to_unit"), CheckConstraint("factor > 0", name="factor"))
    id: Mapped[int] = mapped_column(primary_key=True)
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id", ondelete="CASCADE"))
    from_unit: Mapped[str] = mapped_column(ForeignKey("units.code"))
    to_unit: Mapped[str] = mapped_column(ForeignKey("units.code"))
    factor: Mapped[Decimal] = mapped_column(Qty)
    basis: Mapped[str | None] = mapped_column(Text)  # how the factor was established
    status: Mapped[str] = mapped_column(String(16), default="proposed")  # proposed / approved / withdrawn
    approved_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    item: Mapped[Item] = relationship(back_populates="conversions", foreign_keys=[item_id])


class ItemSupplierRef(Base, TimestampMixin):
    __tablename__ = "item_supplier_refs"
    __table_args__ = (UniqueConstraint("item_id", "supplier_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id", ondelete="CASCADE"))
    supplier_id: Mapped[int] = mapped_column(ForeignKey("suppliers.id"))
    supplier_part_number: Mapped[str] = mapped_column(String(100))
    purchase_unit: Mapped[str] = mapped_column(ForeignKey("units.code"))
    price: Mapped[Decimal | None] = mapped_column(Money)
    currency: Mapped[str | None] = mapped_column(String(3))
    price_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    lead_time_days: Mapped[int] = mapped_column(Integer, default=0)
    min_order_qty: Mapped[Decimal] = mapped_column(Qty, default=0)
    preferred: Mapped[bool] = mapped_column(Boolean, default=False)
    approved: Mapped[bool] = mapped_column(Boolean, default=True)
    item: Mapped[Item] = relationship(back_populates="supplier_refs")
