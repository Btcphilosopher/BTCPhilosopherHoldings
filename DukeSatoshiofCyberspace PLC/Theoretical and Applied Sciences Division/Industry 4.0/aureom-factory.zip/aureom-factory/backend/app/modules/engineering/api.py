from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter
from pydantic import Field
from sqlalchemy import select

from ...api_deps import Body, CtxDep
from ...core.context import row_dict
from ..registry.models import Item
from .models import Bom, Routing, WorkCentre
from .service import (
    _codes, add_bom_line, approve_bom, approve_routing, bom_detail, create_bom, create_routing, detect_all_cycles,
    explode, find_cycle_path, new_bom_version,
)

router = APIRouter(prefix="/api", tags=["products"])


class BomLineBody(Body):
    line_no: int | None = None
    component_item_id: int
    quantity: Decimal = Field(gt=0)
    unit: str
    loss_pct: Decimal = Field(default=Decimal(0), ge=0, lt=100)
    scrap_basis: Literal["net_plus_loss", "allowance_in_quantity"] = "net_plus_loss"
    allowance_note: str | None = None
    is_packaging: bool | None = None
    backflush: bool = False
    alternative_group: str | None = None
    alternative_priority: int = 1
    alternative_approved: bool = True
    operation_seq: int | None = None
    effective_from: date | None = None
    effective_to: date | None = None


class BomBody(Body):
    base_quantity: Decimal = Field(default=Decimal(1), gt=0)
    expected_yield_pct: Decimal = Field(default=Decimal(100), gt=0, le=100)
    effective_from: date | None = None
    change_note: str | None = None
    lines: list[BomLineBody] = []


class OpBody(Body):
    seq: int
    code: str
    name: str
    work_centre_id: int
    required_equipment_kind: str | None = None
    required_skill: str | None = None
    setup_minutes: Decimal = Decimal(0)
    run_minutes_per_unit: Decimal = Decimal(0)
    machine_minutes_per_unit: Decimal = Decimal(0)
    inspection_point: bool = False
    inspection_plan_code: str | None = None
    instructions: str | None = None
    instruction_document_id: int | None = None
    depends_on: list[int] = []
    subcontracted: bool = False
    subcontract_supplier_id: int | None = None
    subcontract_lead_days: int = 0
    reports_output: bool = False


class RoutingBody(Body):
    kind: Literal["standard", "rework"] = "standard"
    effective_from: date | None = None
    change_note: str | None = None
    operations: list[OpBody]


class VersionBody(Body):
    version: int | None = None


class NewVersionBody(Body):
    change_note: str
    effective_from: date | None = None


@router.get("/work-centres")
def work_centres(ctx: CtxDep):
    return [row_dict(w) for w in ctx.db.execute(select(WorkCentre).order_by(WorkCentre.code)).scalars()]


@router.get("/items/{item_id}/boms")
def item_boms(item_id: int, ctx: CtxDep):
    ctx.require("engineering.read")
    return [bom_detail(ctx.db, b) for b in ctx.db.execute(select(Bom).where(Bom.item_id == item_id).order_by(Bom.version)).scalars()]


@router.post("/items/{item_id}/boms", status_code=201)
def post_bom(item_id: int, body: BomBody, ctx: CtxDep):
    data = body.model_dump()
    data["lines"] = [{k: v for k, v in l.model_dump().items() if v is not None or k in ("alternative_group",)} for l in body.lines]
    return bom_detail(ctx.db, create_bom(ctx, item_id, data))


@router.get("/boms/{bom_id}")
def get_bom(bom_id: int, ctx: CtxDep):
    ctx.require("engineering.read")
    return bom_detail(ctx.db, ctx.get(Bom, bom_id))


@router.post("/boms/{bom_id}/lines", status_code=201)
def post_bom_line(bom_id: int, body: BomLineBody, ctx: CtxDep):
    bom = ctx.get(Bom, bom_id)
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    data.setdefault("line_no", (max((l.line_no for l in bom.lines), default=0) + 10))
    return row_dict(add_bom_line(ctx, bom_id, data))


@router.post("/boms/{bom_id}/approve")
def post_approve_bom(bom_id: int, body: VersionBody, ctx: CtxDep):
    return bom_detail(ctx.db, approve_bom(ctx, bom_id, body.version))


@router.post("/boms/{bom_id}/new-version", status_code=201)
def post_new_version(bom_id: int, body: NewVersionBody, ctx: CtxDep):
    return bom_detail(ctx.db, new_bom_version(ctx, bom_id, body.change_note, body.effective_from))


@router.get("/items/{item_id}/explosion")
def get_explosion(item_id: int, ctx: CtxDep, quantity: Decimal = Decimal(1), on: date | None = None):
    ctx.require("engineering.read")
    return {"item_id": item_id, "quantity": str(quantity), "lines": explode(ctx.db, item_id, quantity, on)}


@router.get("/engineering/cycle-check")
def cycle_check(ctx: CtxDep, parent_item_id: int | None = None, component_item_id: int | None = None):
    ctx.require("engineering.read")
    if parent_item_id and component_item_id:
        p = find_cycle_path(ctx.db, parent_item_id, component_item_id)
        return {"would_cycle": bool(p), "path": _codes(ctx.db, p) if p else None}
    return {"cycles": [_codes(ctx.db, c) for c in detect_all_cycles(ctx.db)]}


@router.get("/items/{item_id}/routings")
def item_routings(item_id: int, ctx: CtxDep):
    ctx.require("engineering.read")
    out = []
    for r in ctx.db.execute(select(Routing).where(Routing.item_id == item_id).order_by(Routing.kind, Routing.version)).scalars():
        out.append({**row_dict(r), "operations": [{**row_dict(o), "work_centre": ctx.db.get(WorkCentre, o.work_centre_id).code}
                                                  for o in r.operations]})
    return out


@router.post("/items/{item_id}/routings", status_code=201)
def post_routing(item_id: int, body: RoutingBody, ctx: CtxDep):
    data = body.model_dump()
    return row_dict(create_routing(ctx, item_id, data))


@router.post("/routings/{routing_id}/approve")
def post_approve_routing(routing_id: int, ctx: CtxDep):
    return row_dict(approve_routing(ctx, routing_id))
