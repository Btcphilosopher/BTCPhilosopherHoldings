from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, File, Form, UploadFile
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from ...api_deps import CtxDep
from ...core.context import row_dict
from ...db import get_session
from .models import Document
from .service import can_read, download_link, read_with_token, upload

router = APIRouter(prefix="/api", tags=["documents"])


@router.post("/documents", status_code=201)
async def post_document(ctx: CtxDep, file: UploadFile = File(...), kind: str = Form(...), title: str = Form(...),
                        classification: str = Form("internal"), entity_type: str | None = Form(None),
                        entity_id: int | None = Form(None), revision: str | None = Form(None)):
    data = await file.read()
    doc = upload(ctx, data=data, filename=file.filename or "upload.bin", content_type=file.content_type, kind=kind,
                 title=title, classification=classification, entity_type=entity_type, entity_id=entity_id, revision=revision)
    return row_dict(doc)


@router.get("/documents")
def list_documents(ctx: CtxDep, entity_type: str | None = None, entity_id: int | None = None):
    ctx.require("documents.read")
    stmt = select(Document).order_by(Document.id.desc())
    if entity_type:
        stmt = stmt.where(Document.entity_type == entity_type)
    if entity_id:
        stmt = stmt.where(Document.entity_id == entity_id)
    return [{**row_dict(d, ["id", "kind", "title", "filename", "content_type", "size_bytes", "sha256", "classification",
                            "entity_type", "entity_id", "revision", "created_at"]), "readable": can_read(ctx, d)}
            for d in ctx.db.execute(stmt).scalars()]


@router.post("/documents/{doc_id}/link")
def link(doc_id: int, ctx: CtxDep):
    return {"url": f"/api/files/{download_link(ctx, doc_id)}", "expires_in_seconds": 300}


@router.get("/files/{token}")
def file(token: str, db: Annotated[Session, Depends(get_session)]):
    doc, data = read_with_token(db, token)
    return Response(data, media_type=doc.content_type,
                    headers={"Content-Disposition": f'inline; filename="{doc.filename}"', "Cache-Control": "private, no-store",
                             "X-Content-Type-Options": "nosniff", "Content-Security-Policy": "sandbox"})
