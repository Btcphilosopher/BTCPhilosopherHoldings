from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from fastapi import APIRouter, Query
from pydantic import Field
from sqlalchemy import select

from ...adapters.registry import adapters
from ...api_deps import Body, CtxDep, IdemKey, idempotent
from ...core.context import row_dict
from ...core.errors import NotFound
from ...core.models import User
from ..registry.models import Item
from .models import Bin, Lot, LotStatusHistory, Reservation, StockMovement, Warehouse
from .service import (
    adjust, bin_by_code, is_reversed, lot_locations, merge_lots, reverse_movement, split_lot, stock_summary, transfer,
)

router = APIRouter(prefix="/api", tags=["inventory"])


class TransferBody(Body):
    item_id: int
    lot_id: int | None = None
    from_bin: str
    to_bin: str
    quantity: Decimal = Field(gt=0)
    unit: str
    observed_at: datetime | None = None
    value_source: str = "scanned"
    notes: str | None = None


class AdjustBody(Body):
    item_id: int
    lot_id: int | None = None
    bin: str
    delta: Decimal
    unit: str
    reason_code: str
    notes: str


class ReverseBody(Body):
    reason: str = Field(min_length=3)


class SplitBody(Body):
    bin: str
    quantity: Decimal = Field(gt=0)
    new_lot_number: str
    reason: str
    new_status: str | None = None


class MergeSource(Body):
    lot_id: int
    bin: str
    quantity: Decimal = Field(gt=0)


class MergeBody(Body):
    sources: list[MergeSource]
    to_bin: str
    new_lot_number: str
    reason: str


class ScanBody(Body):
    raw: str


def movement_row(db, mv: StockMovement) -> dict:
    d = row_dict(mv)
    d["item_code"] = db.get(Item, mv.item_id).item_code
    d["lot_number"] = db.get(Lot, mv.lot_id).lot_number if mv.lot_id else None
    d["from_bin"] = db.get(Bin, mv.from_bin_id).code if mv.from_bin_id else None
    d["to_bin"] = db.get(Bin, mv.to_bin_id).code if mv.to_bin_id else None
    d["recorded_by_name"] = db.get(User, mv.recorded_by).full_name
    d["reversed"] = is_reversed(db, mv.id)
    return d


@router.get("/stock")
def get_stock(ctx: CtxDep, item_id: int | None = None):
    ctx.require("inventory.read")
    return stock_summary(ctx.db, item_id, ctx.site_id)


@router.get("/bins")
def get_bins(ctx: CtxDep):
    ctx.require("inventory.read")
    out = []
    for b, w in ctx.db.execute(select(Bin, Warehouse).join(Warehouse).order_by(Warehouse.code, Bin.code)).all():
        out.append({**row_dict(b), "warehouse": w.code, "warehouse_kind": w.kind, "site_id": w.site_id})
    return out


@router.get("/lots")
def get_lots(ctx: CtxDep, item_id: int | None = None, quality_status: str | None = None, q: str | None = None,
             limit: int = Query(300, le=2000)):
    ctx.require("inventory.read")
    stmt = select(Lot).order_by(Lot.id.desc()).limit(limit)
    if item_id:
        stmt = stmt.where(Lot.item_id == item_id)
    if quality_status:
        stmt = stmt.where(Lot.quality_status == quality_status)
    if q:
        stmt = stmt.where(Lot.lot_number.ilike(f"%{q}%") | Lot.supplier_lot.ilike(f"%{q}%"))
    out = []
    for l in ctx.db.execute(stmt).scalars():
        locs = lot_locations(ctx.db, l.id)
        out.append({**row_dict(l), "item_code": ctx.db.get(Item, l.item_id).item_code, "locations": locs,
                    "on_hand": str(sum(Decimal(x["quantity"]) for x in locs))})
    return out


@router.get("/lots/{lot_id}")
def get_lot(lot_id: int, ctx: CtxDep):
    ctx.require("inventory.read")
    l = ctx.get(Lot, lot_id)
    hist = ctx.db.execute(select(LotStatusHistory).where(LotStatusHistory.lot_id == lot_id).order_by(LotStatusHistory.id)).scalars()
    mvs = ctx.db.execute(select(StockMovement).where(StockMovement.lot_id == lot_id).order_by(StockMovement.id)).scalars()
    item = ctx.db.get(Item, l.item_id)
    return {**row_dict(l), "item_code": item.item_code, "item_description": item.description, "base_unit": item.base_unit,
            "locations": lot_locations(ctx.db, l.id),
            "status_history": [{**row_dict(h), "changed_by_name": ctx.db.get(User, h.changed_by).full_name} for h in hist],
            "movements": [movement_row(ctx.db, m) for m in mvs],
            "reservations": [row_dict(r) for r in ctx.db.execute(select(Reservation).where(Reservation.lot_id == lot_id)).scalars()]}


@router.get("/movements")
def get_movements(ctx: CtxDep, item_id: int | None = None, lot_id: int | None = None, movement_type: str | None = None,
                  reference_type: str | None = None, reference_id: int | None = None, limit: int = Query(200, le=2000)):
    ctx.require("inventory.read")
    stmt = select(StockMovement).order_by(StockMovement.id.desc()).limit(limit)
    for col, val in ((StockMovement.item_id, item_id), (StockMovement.lot_id, lot_id), (StockMovement.movement_type, movement_type),
                     (StockMovement.reference_type, reference_type), (StockMovement.reference_id, reference_id)):
        if val is not None:
            stmt = stmt.where(col == val)
    return [movement_row(ctx.db, m) for m in ctx.db.execute(stmt).scalars()]


@router.post("/movements/transfer", status_code=201)
def post_transfer(body: TransferBody, ctx: CtxDep, idem: IdemKey = None):
    def run():
        item = ctx.get(Item, body.item_id)
        lot = ctx.get(Lot, body.lot_id) if body.lot_id else None
        mv = transfer(ctx, item, lot, bin_by_code(ctx.db, body.from_bin), bin_by_code(ctx.db, body.to_bin), body.quantity,
                      body.unit, observed_at=body.observed_at, value_source=body.value_source, notes=body.notes)
        return movement_row(ctx.db, mv)
    return idempotent(ctx, "transfer", idem, body.model_dump(), run)


@router.post("/movements/adjust", status_code=201)
def post_adjust(body: AdjustBody, ctx: CtxDep, idem: IdemKey = None):
    def run():
        item = ctx.get(Item, body.item_id)
        lot = ctx.get(Lot, body.lot_id) if body.lot_id else None
        return movement_row(ctx.db, adjust(ctx, item, lot, bin_by_code(ctx.db, body.bin), body.delta, body.unit,
                                           body.reason_code, body.notes))
    return idempotent(ctx, "adjust", idem, body.model_dump(), run)


@router.post("/movements/{movement_id}/reverse", status_code=201)
def post_reverse(movement_id: int, body: ReverseBody, ctx: CtxDep):
    return movement_row(ctx.db, reverse_movement(ctx, movement_id, body.reason))


@router.post("/lots/{lot_id}/split", status_code=201)
def post_split(lot_id: int, body: SplitBody, ctx: CtxDep):
    lot = ctx.get(Lot, lot_id)
    child = split_lot(ctx, lot, bin_by_code(ctx.db, body.bin), body.quantity, body.new_lot_number, body.reason, body.new_status)
    return row_dict(child)


@router.post("/lots/merge", status_code=201)
def post_merge(body: MergeBody, ctx: CtxDep):
    srcs = [(ctx.get(Lot, s.lot_id), bin_by_code(ctx.db, s.bin), s.quantity) for s in body.sources]
    return row_dict(merge_lots(ctx, srcs, bin_by_code(ctx.db, body.to_bin), body.new_lot_number, body.reason))


@router.get("/reservations")
def get_reservations(ctx: CtxDep, status: str = "active"):
    ctx.require("inventory.read")
    out = []
    for r in ctx.db.execute(select(Reservation).where(Reservation.status == status).order_by(Reservation.id.desc())).scalars():
        out.append({**row_dict(r), "item_code": ctx.db.get(Item, r.item_id).item_code,
                    "lot_number": ctx.db.get(Lot, r.lot_id).lot_number if r.lot_id else None,
                    "bin": ctx.db.get(Bin, r.bin_id).code if r.bin_id else None})
    return out


@router.post("/scan")
def post_scan(body: ScanBody, ctx: CtxDep):
    """Resolve a scanned code to a record. Identification only: the response repeats the lot's
    recorded quality status but a scan never changes or establishes conformity."""
    ctx.require("inventory.read")
    s = adapters().scanner.parse(body.raw)
    out = {"kind": s.kind, "value": s.value, "attributes": s.attributes, "note": s.note, "record": None}
    if s.kind in ("lot", "serial"):
        stmt = select(Lot).where(Lot.lot_number == s.value)
        if s.attributes.get("item_code"):
            stmt = stmt.join(Item, Item.id == Lot.item_id).where(Item.item_code == s.attributes["item_code"])
        lot = ctx.db.execute(stmt).scalars().first()
        if lot is None:
            raise NotFound(f"No lot or serial {s.value}")
        item = ctx.db.get(Item, lot.item_id)
        out["record"] = {"lot_id": lot.id, "lot_number": lot.lot_number, "item_id": item.id, "item_code": item.item_code,
                         "description": item.description, "quality_status": lot.quality_status,
                         "usable_for_production": lot.quality_status == "accepted", "locations": lot_locations(ctx.db, lot.id),
                         "expiry_date": lot.expiry_date.isoformat() if lot.expiry_date else None}
    elif s.kind == "bin":
        out["record"] = row_dict(bin_by_code(ctx.db, s.value))
    elif s.kind == "item":
        item = ctx.db.execute(select(Item).where(Item.item_code == s.value)).scalars().first()
        out["record"] = row_dict(item) if item else None
    elif s.kind == "equipment":
        from ..maintenance.models import Equipment
        eq = ctx.db.execute(select(Equipment).where(Equipment.code == s.value)).scalar_one_or_none()
        out["record"] = row_dict(eq) if eq else None
    elif s.kind == "order":
        from ..production.models import ProductionOrder
        o = ctx.db.execute(select(ProductionOrder).where(ProductionOrder.number == s.value)).scalar_one_or_none()
        out["record"] = {"id": o.id, "number": o.number, "status": o.status} if o else None
    return out
