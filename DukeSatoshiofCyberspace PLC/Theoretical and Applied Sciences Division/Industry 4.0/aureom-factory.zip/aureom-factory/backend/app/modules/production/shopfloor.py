"""Shop-floor helpers: authorised work lists and offline-entry reconciliation.

Offline entries are stored as PENDING and have no effect on stock, reservations or quality until a
supervisor reconciles them. Reconciliation runs the normal validated service call with the
entry's client id as idempotency key, so a duplicate submission cannot consume twice.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import select

from ...core.context import Ctx, row_dict, utcnow
from ...core.errors import InvalidState, ValidationFailed
from ...core.models import OfflineEntry
from ..engineering.models import WorkCentre
from ..registry.models import Item
from .models import OrderOperation, ProductionOrder
from . import service as prod

OFFLINE_KINDS = ("consumption", "quantity", "event", "measurement")


def authorised_work(ctx: Ctx) -> list[dict]:
    ctx.require("production.read")
    skills = set(ctx.user.skills or [])
    rows = ctx.db.execute(select(OrderOperation, ProductionOrder).join(ProductionOrder)
                          .where(ProductionOrder.status.in_(("released", "in_progress", "paused")),
                                 OrderOperation.status.in_(("ready", "in_progress", "paused")),
                                 OrderOperation.subcontracted.is_(False))
                          .order_by(OrderOperation.planned_start.nulls_last(), ProductionOrder.due_date)).all()
    out = []
    for op, o in rows:
        if ctx.site_id and o.site_id != ctx.site_id:
            continue
        item = ctx.db.get(Item, o.item_id)
        out.append({
            "operation_id": op.id, "order_id": o.id, "order": o.number, "kind": o.kind, "item_code": item.item_code,
            "item_description": item.description, "seq": op.seq, "name": op.name, "status": op.status,
            "work_centre": ctx.db.get(WorkCentre, op.work_centre_id).code, "required_skill": op.required_skill,
            "required_equipment_kind": op.required_equipment_kind, "authorised": not op.required_skill or op.required_skill in skills,
            "quantity_start": str(o.quantity_start), "quantity_good": str(op.quantity_good),
            "planned_start": op.planned_start.isoformat() if op.planned_start else None,
            "instructions": op.instructions or o.rework_instructions, "inspection_point": op.inspection_point,
            "reports_output": op.reports_output,
        })
    return out


def submit_offline(ctx: Ctx, device_id: str, entries: list[dict]) -> list[dict]:
    ctx.require("production.execute")
    out = []
    for e in entries:
        if e["kind"] not in OFFLINE_KINDS:
            raise ValidationFailed(f"Offline kind {e['kind']} not supported")
        existing = ctx.db.execute(select(OfflineEntry).where(OfflineEntry.client_entry_id == e["client_entry_id"])).scalar_one_or_none()
        if existing:
            out.append({"client_entry_id": existing.client_entry_id, "status": existing.status, "duplicate": True})
            continue
        oe = OfflineEntry(client_entry_id=e["client_entry_id"], device_id=device_id, site_id=ctx.site_id,
                          operator_user_id=ctx.user.id, kind=e["kind"], payload=e["payload"],
                          observed_at=datetime.fromisoformat(e["observed_at"]))
        ctx.db.add(oe)
        ctx.db.flush()
        out.append({"client_entry_id": oe.client_entry_id, "status": "pending", "id": oe.id,
                    "note": "Recorded as pending. Not applied to stock or production until reconciled."})
    return out


def reconcile_offline(ctx: Ctx, entry_id: int, apply: bool, note: str | None = None) -> OfflineEntry:
    ctx.require("production.reconcile_offline")
    oe = ctx.get(OfflineEntry, entry_id)
    if oe.status != "pending":
        raise InvalidState(f"Entry is {oe.status}")
    oe.reconciled_by, oe.reconciled_at = ctx.user.id, utcnow()
    if not apply:
        oe.status, oe.outcome = "rejected", {"note": note}
        ctx.audit("offline.reject", "offline_entry", oe.id, reason=note)
        return oe
    p = oe.payload
    try:
        if oe.kind == "consumption":
            mv = prod.record_consumption(ctx, p["material_id"], p["lot_id"], p["quantity"], p.get("unit"),
                                         from_bin_code=p["from_bin"], value_source=p.get("value_source", "manual"),
                                         observed_at=oe.observed_at, idempotency_key=f"offline:{oe.client_entry_id}",
                                         note=f"offline entry from {oe.device_id}")
            oe.outcome = {"movement": mv.movement_no}
        elif oe.kind == "quantity":
            prod.report_quantities(ctx, p["operation_id"], p.get("good", 0), p.get("rework", 0), observed_at=oe.observed_at)
            oe.outcome = {"reported": p}
        elif oe.kind == "event":
            op = ctx.get(OrderOperation, p["operation_id"])
            prod._event(ctx, op, p["event"], observed_at=oe.observed_at, note=p.get("note"), offline_entry_id=oe.id)
            oe.outcome = {"event": p["event"]}
        else:
            from ..quality.service import record_result
            r = record_result(ctx, p["inspection_id"], p["characteristic"], numeric_value=p.get("numeric_value"),
                              conforms=p.get("conforms"), value_source=p.get("value_source", "manual"),
                              equipment_code=p.get("equipment_code"), observed_at=oe.observed_at, sample_ref=p.get("sample_ref"))
            oe.outcome = {"result_id": r.id}
    except Exception as exc:  # surface the validation failure to the supervisor, keep entry pending
        raise ValidationFailed(f"Offline entry cannot be applied: {getattr(exc, 'message', exc)}") from exc
    oe.status = "applied"
    ctx.audit("offline.apply", "offline_entry", oe.id, after=oe.outcome, reason=note)
    return oe


def list_offline(ctx: Ctx, status: str | None = "pending") -> list[dict]:
    ctx.require("production.read")
    stmt = select(OfflineEntry).order_by(OfflineEntry.id.desc())
    if status:
        stmt = stmt.where(OfflineEntry.status == status)
    return [row_dict(e) for e in ctx.db.execute(stmt).scalars()]
