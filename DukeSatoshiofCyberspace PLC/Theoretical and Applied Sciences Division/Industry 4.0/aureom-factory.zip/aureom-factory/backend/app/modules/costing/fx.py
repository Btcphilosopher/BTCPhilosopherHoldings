"""Currency conversion with explicit rate dates."""
from __future__ import annotations

from datetime import date
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...config import settings
from ...core.errors import ValidationFailed
from ...core.numbers import D
from .models import FxRate


def rate_to_base(db: Session, currency: str, on: date) -> tuple[Decimal, date]:
    """Most recent rate on or before `on`. Returns (rate, rate_date)."""
    if currency == settings.base_currency:
        return Decimal(1), on
    r = db.execute(
        select(FxRate).where(FxRate.currency == currency, FxRate.rate_date <= on).order_by(FxRate.rate_date.desc())
    ).scalars().first()
    if r is None:
        raise ValidationFailed(f"No {currency}→{settings.base_currency} exchange rate on or before {on}")
    return D(r.rate_to_base), r.rate_date


def to_base_currency(db: Session, amount, currency: str, on: date) -> tuple[Decimal, Decimal, date]:
    rate, rd = rate_to_base(db, currency, on)
    return D(amount) * rate, rate, rd
