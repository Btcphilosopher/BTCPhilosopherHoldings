"""Costing reference data and financial postings."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, Date, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ...core.models import JSONType
from ...db import Base, Money, Qty, TimestampMixin


class FxRate(Base):
    """1 unit of `currency` = rate_to_base units of the base currency on rate_date."""

    __tablename__ = "fx_rates"
    __table_args__ = (UniqueConstraint("currency", "rate_date"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    currency: Mapped[str] = mapped_column(String(3))
    rate_date: Mapped[date] = mapped_column(Date)
    rate_to_base: Mapped[Decimal] = mapped_column(Qty)
    source: Mapped[str] = mapped_column(String(64), default="manual")


class OverheadRule(Base, TimestampMixin):
    """Configured overhead allocation. Allocated overhead is a fully-absorbed cost and is
    excluded from incremental (marginal) scenarios unless explicitly marked variable."""

    __tablename__ = "overhead_rules"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(32), unique=True)
    description: Mapped[str] = mapped_column(String(200))
    basis: Mapped[str] = mapped_column(String(32))  # labour_hours / machine_hours / material_cost_pct / per_unit
    rate: Mapped[Decimal] = mapped_column(Money)
    currency: Mapped[str] = mapped_column(String(3), default="GBP")
    behaviour: Mapped[str] = mapped_column(String(16), default="fixed")  # fixed / variable
    work_centre_id: Mapped[int | None] = mapped_column(ForeignKey("work_centres.id"))
    effective_from: Mapped[date] = mapped_column(Date)
    effective_to: Mapped[date | None] = mapped_column(Date)


class CostPosting(Base, TimestampMixin):
    """Costs that have been exported to the accounting system (\"financially posted\")."""

    __tablename__ = "cost_postings"
    id: Mapped[int] = mapped_column(primary_key=True)
    batch_ref: Mapped[str] = mapped_column(String(64), index=True)
    production_order_id: Mapped[int | None] = mapped_column(ForeignKey("production_orders.id"))
    account: Mapped[str] = mapped_column(String(32))
    description: Mapped[str] = mapped_column(String(300))
    debit: Mapped[Decimal] = mapped_column(Money, default=0)
    credit: Mapped[Decimal] = mapped_column(Money, default=0)
    currency: Mapped[str] = mapped_column(String(3))
    cost_element: Mapped[str] = mapped_column(String(32))
    posting_date: Mapped[date] = mapped_column(Date)
    exported_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    adapter: Mapped[str] = mapped_column(String(64))
    external_ref: Mapped[str | None] = mapped_column(String(100))
