"""Material requirements planning (transparent) and finite-capacity scheduling (baseline).

MRP never releases anything: proposals become purchase requisitions (still needing approval) or
draft production orders (still needing planning and release) only when a planner accepts them.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime, time, timedelta
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ...core.context import Ctx, jsonable, row_dict, utcnow
from ...core.errors import InvalidState, ValidationFailed
from ...core.numbers import D, ZERO, ceil_int, ceil_to, fmt, q
from ..engineering.models import Bom, BomLine, WorkCentre
from ..engineering.service import effective_bom, effective_routing, gross_per_parent, start_quantity
from ..inventory.models import Lot, Reservation, StockBalance
from ..inventory.service import available_rows
from ..maintenance.models import Equipment
from ..maintenance.service import blocked_intervals
from ..production.models import OrderMaterial, OrderOperation, ProductionOrder
from ..production.service import material_reserved
from ..purchasing.models import PurchaseOrder, PurchaseOrderLine, PurchaseRequisition, Supplier
from ..registry.models import Item, ItemSupplierRef
from ..registry.service import convert, get_unit
from .calendar import TZ, allocate, intersect, merge, subtract, working_intervals
from .models import Demand, MrpProposal, MrpRun, ScheduleRun

OPEN_ORDER_STATUSES = ("draft", "planned", "released", "in_progress", "paused", "awaiting_inspection")


def create_demand(ctx: Ctx, site_id: int, item_id: int, quantity, due_date: date, *, kind="customer_order",
                  customer_id=None, customer_order_line_id=None, note=None) -> Demand:
    ctx.require("planning.run", site_id)
    item = ctx.get(Item, item_id)
    if D(quantity) <= 0:
        raise ValidationFailed("Demand quantity must be positive")
    d = Demand(number=ctx.next_number("DM"), site_id=site_id, item_id=item.id, quantity=D(quantity), due_date=due_date,
               kind=kind, customer_id=customer_id, customer_order_line_id=customer_order_line_id, note=note,
               created_by=ctx.user.id)
    ctx.db.add(d)
    ctx.db.flush()
    ctx.audit("demand.create", "demand", d.id, after=row_dict(d), site_id=site_id)
    return d


# --------------------------------------------------------------------------- MRP


def low_level_codes(db: Session) -> dict[int, int]:
    edges = db.execute(select(Bom.item_id, BomLine.component_item_id).join(BomLine, BomLine.bom_id == Bom.id)
                       .where(Bom.status.in_(("approved", "superseded")))).all()
    children = defaultdict(set)
    for p, c in edges:
        children[p].add(c)
    level: dict[int, int] = defaultdict(int)
    changed, guard = True, 0
    while changed and guard < 50:
        changed, guard = False, guard + 1
        for p, cs in children.items():
            for c in cs:
                if level[c] < level[p] + 1:
                    level[c] = level[p] + 1
                    changed = True
    return level


def _preferred_ref(db: Session, item_id: int) -> ItemSupplierRef | None:
    return db.execute(select(ItemSupplierRef).where(ItemSupplierRef.item_id == item_id, ItemSupplierRef.approved.is_(True))
                      .order_by(ItemSupplierRef.preferred.desc(), ItemSupplierRef.lead_time_days)).scalars().first()


def lot_size(item: Item, net: Decimal, integral: bool) -> Decimal:
    qty = max(net, D(item.lot_size_min))
    if D(item.lot_size_multiple) > 0:
        qty = ceil_to(qty, D(item.lot_size_multiple))
    return ceil_int(qty) if integral else q(qty)


def run_mrp(ctx: Ctx, site_id: int, as_of: date | None = None, horizon_days: int = 90) -> MrpRun:
    ctx.require("planning.run", site_id)
    db = ctx.db
    as_of = as_of or date.today()
    horizon = as_of + timedelta(days=horizon_days)
    levels = low_level_codes(db)
    gross: dict[int, list[dict]] = defaultdict(list)
    supply: dict[int, list[dict]] = defaultdict(list)
    warnings: list[str] = []

    for d in db.execute(select(Demand).where(Demand.site_id == site_id, Demand.status.in_(("open", "planned")),
                                             Demand.due_date <= horizon)).scalars():
        fulfilled = ZERO
        if d.customer_order_line_id:
            from ..dispatch.models import CustomerOrderLine
            col = db.get(CustomerOrderLine, d.customer_order_line_id)
            fulfilled = D(col.quantity_dispatched)
        rem = D(d.quantity) - fulfilled
        if rem > 0:
            gross[d.item_id].append({"date": d.due_date, "qty": rem, "source": f"demand {d.number}"})

    for o in db.execute(select(ProductionOrder).where(ProductionOrder.site_id == site_id,
                                                      ProductionOrder.status.in_(OPEN_ORDER_STATUSES))).scalars():
        if o.kind == "standard":
            due = o.planned_end.date() if o.planned_end else (o.due_date or as_of)
            rem = D(o.quantity_target) - D(o.quantity_accepted)
            if rem > 0:
                supply[o.item_id].append({"date": due, "qty": rem, "source": f"production order {o.number} ({o.status})"})
        need_on = o.planned_start.date() if o.planned_start else as_of
        if o.materials:
            for m in o.materials:
                rem = D(m.required_quantity) - D(m.quantity_issued) - material_reserved(db, m)
                if rem > 0:
                    gross[m.item_id].append({"date": need_on, "qty": rem, "source": f"{o.number} material line {m.line_no}"})
        elif o.kind == "standard":  # draft order: explode its BOM
            bom = db.get(Bom, o.bom_id)
            for l in bom.lines:
                if l.alternative_group and l.alternative_priority != 1:
                    continue
                g = gross_per_parent(db, bom, l)
                gross[g["component"].id].append({"date": need_on, "qty": q(g["gross"] * D(o.quantity_start)),
                                                 "source": f"{o.number} (draft) BOM v{bom.version}"})

    for pl, po in db.execute(select(PurchaseOrderLine, PurchaseOrder).join(PurchaseOrder, PurchaseOrder.id == PurchaseOrderLine.po_id)
                             .where(PurchaseOrder.site_id == site_id, PurchaseOrder.is_subcontract.is_(False),
                                    PurchaseOrder.status.in_(("draft", "approved", "sent", "acknowledged", "partially_received")),
                                    PurchaseOrderLine.status.in_(("open", "partially_received")))).all():
        item = db.get(Item, pl.item_id)
        out_po = D(pl.quantity_ordered) - D(pl.quantity_received) + D(pl.quantity_returned)
        if out_po > 0:
            supply[pl.item_id].append({"date": pl.acknowledged_delivery or pl.expected_delivery or as_of,
                                       "qty": convert(db, out_po, pl.unit, item.base_unit, item.id),
                                       "source": f"{po.number} line {pl.line_no} ({po.status})"})
    for pr in db.execute(select(PurchaseRequisition).where(PurchaseRequisition.site_id == site_id,
                                                           PurchaseRequisition.status.in_(("submitted", "approved")))).scalars():
        item = db.get(Item, pr.item_id)
        supply[pr.item_id].append({"date": pr.needed_by or as_of, "qty": convert(db, pr.quantity, pr.unit, item.base_unit, item.id),
                                   "source": f"requisition {pr.number} ({pr.status})"})
    for lot, qty in db.execute(select(Lot, func.sum(StockBalance.quantity)).join(StockBalance, StockBalance.lot_id == Lot.id)
                               .where(Lot.quality_status == "awaiting_review", Lot.origin == "purchase")
                               .group_by(Lot.id)).all():
        if D(qty) > 0:
            supply[lot.item_id].append({"date": as_of + timedelta(days=1), "qty": D(qty),
                                        "source": f"lot {lot.lot_number} awaiting incoming inspection (counted; may be rejected)"})

    run = MrpRun(number=ctx.next_number("MRP"), site_id=site_id, as_of=as_of, horizon_days=horizon_days,
                 parameters={"as_of": as_of.isoformat(), "horizon_days": horizon_days}, run_by=ctx.user.id)
    db.add(run)
    db.flush()

    items = set(gross) | set(supply)
    processed: set[int] = set()
    lines_out = []
    while True:
        pending = [i for i in (set(gross) | set(supply)) if i not in processed]
        if not pending:
            break
        iid = min(pending, key=lambda i: (levels.get(i, 0), i))
        processed.add(iid)
        item = db.get(Item, iid)
        integral = get_unit(db, item.base_unit).integral
        avail_rows = available_rows(db, iid)
        on_hand = sum((r["available"] for r in avail_rows), ZERO)
        held = defaultdict(Decimal)
        for bal, lot in db.execute(select(StockBalance, Lot).join(Lot, Lot.id == StockBalance.lot_id)
                                   .where(StockBalance.item_id == iid, StockBalance.quantity > 0)).all():
            if lot.quality_status in ("quarantined", "rejected") or (lot.quality_status == "awaiting_review" and lot.origin != "purchase"):
                held[lot.quality_status] += D(bal.quantity)
        events = sorted([(g["date"], 1, -g["qty"], g["source"]) for g in gross.get(iid, [])] +
                        [(s["date"], 0, s["qty"], s["source"]) for s in supply.get(iid, [])])
        projected = on_hand
        safety = D(item.safety_stock)
        explanation = [f"Available now: {fmt(on_hand)} {item.base_unit} (accepted, unexpired, allocatable, unreserved)"]
        for k, v in held.items():
            explanation.append(f"Not counted: {fmt(v)} {item.base_unit} {k}")
        planned = []
        for dte, _, qty, src in events:
            projected += qty
            explanation.append(f"{dte}: {'+' if qty > 0 else ''}{fmt(qty)} ({src}) → projected {fmt(projected)}")
            if projected < safety:
                net = safety - projected
                make = item.make_or_buy in ("make", "subcon") and effective_bom(db, iid, dte) is not None
                ref = None if make else _preferred_ref(db, iid)
                lead = item.lead_time_days if make else (ref.lead_time_days if ref else item.lead_time_days)
                size = lot_size(item, net, integral)
                release = dte - timedelta(days=lead)
                late = release < as_of
                order_unit, order_qty = item.base_unit, size
                if not make and ref:
                    order_unit = ref.purchase_unit
                    order_qty = convert(db, size, item.base_unit, order_unit, iid)
                    if get_unit(db, order_unit).integral:
                        order_qty = ceil_int(order_qty)
                        size = convert(db, order_qty, order_unit, item.base_unit, iid)
                    if D(ref.min_order_qty) > order_qty:
                        order_qty = D(ref.min_order_qty)
                        size = convert(db, order_qty, order_unit, item.base_unit, iid)
                expl = [
                    f"Shortfall {fmt(net)} {item.base_unit} on {dte}" + (f" (incl. safety stock {fmt(safety)})" if safety else ""),
                    f"Lot sizing: min {fmt(item.lot_size_min)}, multiple {fmt(item.lot_size_multiple)} → {fmt(size)} {item.base_unit}",
                    f"Lead time {lead} days → release {release}",
                ]
                if order_unit != item.base_unit:
                    expl.append(f"Purchase unit {order_unit}: {fmt(order_qty)} {order_unit}")
                if late:
                    expl.append(f"LATE: release date is in the past; earliest availability {as_of + timedelta(days=lead)}")
                prop = MrpProposal(run_id=run.id, kind="production" if make else "purchase", item_id=iid, quantity=size,
                                   order_quantity=order_qty, order_unit=order_unit, need_date=dte,
                                   release_date=max(release, as_of), supplier_id=ref.supplier_id if ref else None, late=late,
                                   expected_available=(as_of + timedelta(days=lead)) if late else dte, explanation=expl)
                db.add(prop)
                db.flush()
                planned.append({"proposal_id": prop.id, "kind": prop.kind, "quantity": str(size), "need_date": dte.isoformat(),
                                "release_date": prop.release_date.isoformat(), "late": late})
                projected += size
                explanation.append(f"  ⇒ planned {prop.kind} of {fmt(size)} {item.base_unit} (proposal {prop.id}) → projected {fmt(projected)}")
                if make:
                    bom = effective_bom(db, iid, release)
                    start = start_quantity(bom, size, integral)
                    for l in bom.lines:
                        if l.alternative_group and l.alternative_priority != 1:
                            continue
                        g = gross_per_parent(db, bom, l)
                        cid = g["component"].id
                        if cid in processed:
                            warnings.append(f"Low-level code conflict for {g['component'].item_code}")
                        gross[cid].append({"date": max(release, as_of), "qty": q(g["gross"] * start),
                                           "source": f"planned {item.item_code} ×{fmt(start)} started (proposal {prop.id}); {g['note']}"})
            if not item.active_status == "active":
                warnings.append(f"{item.item_code} is {item.active_status}")
        lines_out.append({"item_id": iid, "item_code": item.item_code, "description": item.description,
                          "level": levels.get(iid, 0), "unit": item.base_unit, "available": str(on_hand),
                          "gross_total": str(sum((g["qty"] for g in gross.get(iid, [])), ZERO)),
                          "supply_total": str(sum((s["qty"] for s in supply.get(iid, [])), ZERO)),
                          "planned": planned, "explanation": explanation})
    run.lines = jsonable(sorted(lines_out, key=lambda l: (l["level"], l["item_code"])))
    run.warnings = warnings
    ctx.audit("mrp.run", "mrp_run", run.id, after={"proposals": sum(len(l["planned"]) for l in lines_out)}, site_id=site_id)
    ctx.emit("planning.mrp_complete", {"run": run.number})
    return run


def accept_proposal(ctx: Ctx, proposal_id: int, *, quantity=None, supplier_id=None) -> dict:
    ctx.require("planning.accept")
    p = ctx.get(MrpProposal, proposal_id)
    if p.status != "proposed":
        raise InvalidState(f"Proposal is {p.status}")
    run = ctx.db.get(MrpRun, p.run_id)
    latest = ctx.db.execute(select(func.max(MrpRun.id)).where(MrpRun.site_id == run.site_id)).scalar()
    if latest != run.id:
        raise InvalidState("A newer MRP run exists; accept proposals from the latest run")
    from ..production.service import create_order
    from ..purchasing.service import create_requisition

    if p.kind == "purchase":
        pr = create_requisition(ctx, run.site_id, p.item_id, quantity or p.order_quantity, p.order_unit, p.need_date,
                                justification="; ".join(p.explanation), source="mrp", mrp_proposal_id=p.id,
                                suggested_supplier_id=supplier_id or p.supplier_id)
        p.created_record_type, p.created_record_id = "purchase_requisition", pr.id
        result = {"requisition": pr.number, "status": pr.status, "note": "Requisition requires purchasing approval"}
    else:
        o = create_order(ctx, run.site_id, p.item_id, quantity or p.quantity, due_date=p.need_date, source="mrp",
                         mrp_proposal_id=p.id, effective_on=p.release_date)
        p.created_record_type, p.created_record_id = "production_order", o.id
        result = {"production_order": o.number, "status": o.status, "note": "Draft order: plan and release separately"}
    p.status, p.decided_by, p.decided_at = "accepted", ctx.user.id, utcnow()
    ctx.audit("mrp.accept", "mrp_proposal", p.id, after=result)
    return result


def reject_proposal(ctx: Ctx, proposal_id: int, reason: str) -> MrpProposal:
    ctx.require("planning.accept")
    p = ctx.get(MrpProposal, proposal_id)
    p.status, p.decided_by, p.decided_at = "rejected", ctx.user.id, utcnow()
    ctx.audit("mrp.reject", "mrp_proposal", p.id, reason=reason)
    return p


# --------------------------------------------------------------------------- scheduling


def _material_ready(db: Session, order: ProductionOrder, start: datetime, made_here: set[int] = frozenset()) -> tuple[datetime, list[str]]:
    ready, notes = start, []
    for m in order.materials:
        if m.item_id in made_here:
            continue  # supplied by another scheduled order; handled as an order dependency
        covered = D(m.quantity_issued) + material_reserved(db, m)
        short = D(m.required_quantity) - covered
        if short <= 0:
            continue
        item = db.get(Item, m.item_id)
        free = sum((r["available"] for r in available_rows(db, m.item_id)), ZERO)
        if free >= short:
            notes.append(f"{item.item_code}: {fmt(short)} {m.unit} not yet allocated but available")
            continue
        open_lines = db.execute(select(PurchaseOrderLine).join(PurchaseOrder).where(
            PurchaseOrderLine.item_id == m.item_id, PurchaseOrderLine.status.in_(("open", "partially_received")),
            PurchaseOrder.status.in_(("approved", "sent", "acknowledged", "partially_received")))).scalars().all()
        dates = sorted((l.acknowledged_delivery or l.expected_delivery) for l in open_lines if (l.acknowledged_delivery or l.expected_delivery))
        if dates:
            when = datetime.combine(dates[-1], time(9, 0), TZ) + timedelta(days=1)  # +1 day incoming inspection
            notes.append(f"{item.item_code}: waiting for supply due {dates[-1]} (+1 day inspection)")
        else:
            when = start + timedelta(days=item.lead_time_days or 14)
            notes.append(f"{item.item_code}: no open supply — assumed lead time {item.lead_time_days or 14} days")
        ready = max(ready, when)
    return ready, notes


def run_schedule(ctx: Ctx, site_id: int, start_at: datetime | None = None, horizon_days: int = 30,
                 apply: bool = True) -> ScheduleRun:
    """Forward, finite-capacity, earliest-due-date baseline. Shows infeasibility rather than hiding it."""
    ctx.require("production.plan", site_id)
    db = ctx.db
    start_at = (start_at or utcnow()).astimezone(TZ)
    end_at = start_at + timedelta(days=horizon_days)
    from ...core.models import User, UserRole

    equipment = db.execute(select(Equipment).where(Equipment.site_id == site_id, Equipment.category.in_(("machine", "station")),
                                                   Equipment.status != "retired")).scalars().all()
    free_eq: dict[int, list] = {}
    for eq in equipment:
        wc = db.get(WorkCentre, eq.work_centre_id) if eq.work_centre_id else None
        cal = eq.calendar or (wc.calendar if wc else {})
        free_eq[eq.id] = subtract(working_intervals(cal, wc.holidays if wc else [], start_at, end_at),
                                  blocked_intervals(db, eq, start_at, end_at))
    operators = db.execute(select(User).join(UserRole).where(UserRole.role.in_(("operator", "production_manager")),
                                                             User.active.is_(True))).scalars().unique().all()
    free_op = {u.id: working_intervals(u.shift_pattern or {}, [], start_at, end_at) for u in operators}

    orders = db.execute(select(ProductionOrder).where(
        ProductionOrder.site_id == site_id, ProductionOrder.status.in_(("planned", "released", "in_progress", "paused")))
    ).scalars().all()
    orders.sort(key=lambda o: (o.due_date or date.max, o.id))
    result_orders, bars = [], []
    end_by_order: dict[int, datetime] = {}
    # Respect parent/child order dependencies: an order consuming another order's item waits for it.
    produced_by = {o.item_id: o for o in orders}
    for o in orders:
        notes, feasible = [], True
        mat_ready, mnotes = _material_ready(db, o, start_at, set(produced_by))
        notes += mnotes
        for m in o.materials:
            dep = produced_by.get(m.item_id)
            if dep and dep.id != o.id and dep.id in end_by_order:
                if D(m.quantity_issued) + material_reserved(db, m) < D(m.required_quantity):
                    mat_ready = max(mat_ready, end_by_order[dep.id])
                    notes.append(f"waits for {dep.number} ({db.get(Item, dep.item_id).item_code})")
        op_end: dict[int, datetime] = {}
        first_start = None
        for op in sorted(o.operations, key=lambda x: x.seq):
            if op.status == "completed":
                op_end[op.seq] = op.actual_end or start_at
                continue
            preds = op.depends_on or [s for s in op_end][-1:]
            earliest = max([start_at, mat_ready] + [op_end[s] for s in preds if s in op_end])
            remaining = max(ZERO, D(o.quantity_start) - D(op.quantity_good) - D(op.quantity_scrap) - D(op.quantity_rework))
            if op.subcontracted:
                s = earliest
                e = s + timedelta(days=op.subcontract_lead_days or 5)
                op_end[op.seq] = e
                bars.append({"order": o.number, "op": op.seq, "name": op.name, "resource": "subcontractor",
                             "start": s.isoformat(), "end": e.isoformat(), "kind": "subcontract"})
                if apply:
                    op.planned_start, op.planned_end = s, e
                first_start = first_start or s
                continue
            setup = D(op.setup_minutes) if op.status in ("pending", "ready") else ZERO
            dur = float(setup + D(op.run_minutes_per_unit) * remaining)
            cands_eq = [eq for eq in equipment if eq.work_centre_id == op.work_centre_id and
                        (not op.required_equipment_kind or eq.kind == op.required_equipment_kind)]
            cands_op = [u for u in operators if not op.required_skill or op.required_skill in (u.skills or [])]
            if not cands_eq:
                feasible = False
                notes.append(f"op {op.seq} {op.name}: no suitable equipment available")
                continue
            if not cands_op:
                feasible = False
                notes.append(f"op {op.seq} {op.name}: no operator with skill '{op.required_skill}'")
                continue
            down = [eq.code for eq in cands_eq if eq.status == "down"]
            if down:
                notes.append(f"op {op.seq}: {', '.join(down)} down — capacity reduced")
            best = None
            for eq in cands_eq:
                for u in cands_op:
                    slot = allocate(intersect(free_eq[eq.id], free_op[u.id]), earliest, dur)
                    if slot and (best is None or slot[1] < best[0][1]):
                        best = (slot, eq, u)
            if best is None:
                feasible = False
                notes.append(f"op {op.seq} {op.name}: insufficient capacity within {horizon_days}-day horizon")
                continue
            (s, e, used), eq, u = best
            free_eq[eq.id] = subtract(free_eq[eq.id], used)
            free_op[u.id] = subtract(free_op[u.id], used)
            op_end[op.seq] = e
            first_start = first_start or s
            bars.append({"order": o.number, "op": op.seq, "name": op.name, "resource": eq.code, "operator": u.full_name,
                         "start": s.isoformat(), "end": e.isoformat(), "minutes": round(dur, 1),
                         "segments": [[a.isoformat(), b.isoformat()] for a, b in used], "kind": "internal"})
            if apply:
                op.planned_start, op.planned_end = s, e
                op.planned_equipment_id, op.planned_operator_id = eq.id, u.id
        finish = max(op_end.values()) if op_end else None
        if finish:
            end_by_order[o.id] = finish
        late_days = None
        if finish and o.due_date:
            late_days = (finish.astimezone(TZ).date() - o.due_date).days
            if late_days > 0:
                notes.append(f"estimated {late_days} day(s) late against due {o.due_date}")
        if apply:
            o.planned_start, o.planned_end = first_start, finish
            o.schedule_feasible = feasible and (late_days is None or late_days <= 0)
            o.schedule_notes = notes
        result_orders.append({"order": o.number, "item": db.get(Item, o.item_id).item_code, "due_date": jsonable(o.due_date),
                              "estimated_start": jsonable(first_start), "estimated_finish": jsonable(finish),
                              "feasible": feasible, "late_days": late_days, "notes": notes})
    run = ScheduleRun(number=ctx.next_number("SCH"), site_id=site_id, start_at=start_at, horizon_days=horizon_days,
                      result={"orders": result_orders, "bars": bars,
                              "method": "Forward finite-capacity, earliest due date first; work centre/equipment calendars minus "
                                        "downtime, restrictions and planned maintenance; operator shifts and skills; setup; "
                                        "operation sequence; material availability. Baseline heuristic, not an optimiser."},
                      run_by=ctx.user.id)
    db.add(run)
    db.flush()
    ctx.audit("schedule.run", "schedule_run", run.id, after={"orders": len(result_orders)}, site_id=site_id)
    return run
