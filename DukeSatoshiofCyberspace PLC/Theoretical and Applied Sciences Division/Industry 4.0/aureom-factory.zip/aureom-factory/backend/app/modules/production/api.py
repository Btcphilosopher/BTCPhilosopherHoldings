from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter
from pydantic import Field
from sqlalchemy import select

from ...api_deps import Body, CtxDep, IdemKey, idempotent
from ...core.context import row_dict
from ..registry.models import Item
from . import service as svc
from . import shopfloor
from .models import ProductionOrder, ScrapRecord, SubcontractShipment

router = APIRouter(prefix="/api", tags=["production"])


class OrderBody(Body):
    item_id: int
    quantity_target: Decimal = Field(gt=0)
    due_date: date | None = None
    kind: Literal["standard"] = "standard"


class VersionBody(Body):
    version: int


class ReleaseBody(Body):
    version: int
    allow_shortage: bool = False


class AllocationBody(Body):
    material_id: int
    lot_id: int
    quantity: Decimal = Field(gt=0)


class AllocateBody(Body):
    allocations: list[AllocationBody] | None = None


class IssueBody(Body):
    lot_id: int
    quantity: Decimal = Field(gt=0)
    to_bin: str
    value_source: Literal["scanned", "manual"] = "scanned"
    observed_at: datetime | None = None


class ReturnBody(Body):
    lot_id: int
    quantity: Decimal = Field(gt=0)
    from_bin: str
    to_bin: str
    observed_at: datetime | None = None


class ConsumeBody(Body):
    lot_id: int
    quantity: Decimal = Field(gt=0)
    unit: str | None = None
    from_bin: str
    value_source: Literal["scanned", "manual", "measured"] = "manual"
    observed_at: datetime | None = None
    operation_id: int | None = None
    note: str | None = None


class BackflushBody(Body):
    operation_id: int
    good_quantity: Decimal = Field(gt=0)
    from_bin: str
    observed_at: datetime | None = None


class ReconcileBody(Body):
    bin: str
    counted_remaining: dict[int, Decimal]
    note: str | None = None


class EquipmentCheckBody(Body):
    equipment_code: str
    checklist: dict[str, bool] = {}
    observed_at: datetime | None = None


class StartBody(Body):
    equipment_code: str | None = None
    phase: Literal["setup", "run"] = "run"
    observed_at: datetime | None = None


class PauseBody(Body):
    reason: str
    observed_at: datetime | None = None


class QtyBody(Body):
    good: Decimal = Decimal(0)
    rework: Decimal = Decimal(0)
    observed_at: datetime | None = None


class ConsumedInput(Body):
    lot_id: int
    quantity: Decimal


class OutputBody(Body):
    operation_id: int
    quantity: Decimal = Field(gt=0)
    conformity: Literal["good", "nonconforming"] = "good"
    lot_number: str | None = None
    serials: list[str] | None = None
    to_bin: str
    consumed_inputs: list[ConsumedInput] | None = None
    observed_at: datetime | None = None
    defect_description: str | None = None
    nonconformance_id: int | None = None


class CompleteBody(Body):
    observed_at: datetime | None = None
    note: str | None = None


class HandoverBody(Body):
    quantity: Decimal
    note: str | None = None
    observed_at: datetime | None = None


class DefectBody(Body):
    description: str
    quantity: Decimal
    lot_ids: list[int] = []
    severity: Literal["minor", "major", "critical"] = "major"


class ScrapBody(Body):
    order_id: int | None = None
    operation_id: int | None = None
    item_id: int
    quantity: Decimal = Field(gt=0)
    unit: str
    kind: Literal["material", "product"]
    reason_code: str
    reason: str
    lot_id: int | None = None
    bin: str | None = None
    recoverable: bool = False
    recovered_item_id: int | None = None
    recovered_quantity: Decimal | None = None
    observed_at: datetime | None = None


class AuthoriseBody(Body):
    approve: bool = True
    note: str | None = None


class CancelDisposition(Body):
    material_id: int
    lot_id: int
    action: Literal["return", "scrap"]
    quantity: Decimal
    to_bin_code: str | None = None


class CancelBody(Body):
    version: int
    reason: str
    dispositions: list[CancelDisposition] = []


class AdditionalMaterial(Body):
    item_id: int
    quantity: Decimal
    unit: str
    operation_seq: int | None = None


class ReworkBody(Body):
    instructions: str
    additional_materials: list[AdditionalMaterial] = []
    due_date: date | None = None


class ReworkMoveBody(Body):
    lot_ids: list[int]
    from_bin: str
    to_bin: str
    operation_id: int | None = None
    observed_at: datetime | None = None


class SubSendLine(Body):
    material_id: int
    lot_id: int
    quantity: Decimal


class SubSendBody(Body):
    operation_id: int
    lines: list[SubSendLine]
    po_id: int | None = None
    documents: list[dict] = []
    observed_at: datetime | None = None


class SubReceiveBody(Body):
    quantity_returned: Decimal
    quantity_lost: Decimal = Decimal(0)
    loss_explanation: str | None = None
    lot_number: str | None = None
    supplier_documents: list[dict] = []
    observed_at: datetime | None = None


class OfflineEntryBody(Body):
    client_entry_id: str
    kind: Literal["consumption", "quantity", "event", "measurement"]
    payload: dict
    observed_at: str


class OfflineBody(Body):
    device_id: str
    entries: list[OfflineEntryBody]


class ReconcileOfflineBody(Body):
    apply: bool
    note: str | None = None


def _detail(ctx, o):
    return svc.order_detail(ctx.db, o)


@router.get("/orders")
def orders(ctx: CtxDep, status: str | None = None):
    ctx.require("production.read")
    stmt = select(ProductionOrder).order_by(ProductionOrder.id.desc())
    if status:
        stmt = stmt.where(ProductionOrder.status == status)
    out = []
    for o in ctx.db.execute(stmt).scalars():
        item = ctx.db.get(Item, o.item_id)
        out.append({**row_dict(o, ["id", "number", "kind", "status", "quantity_target", "quantity_start", "quantity_reported",
                                   "quantity_accepted", "quantity_scrapped", "quantity_nonconforming", "due_date",
                                   "planned_start", "planned_end", "schedule_feasible", "schedule_notes", "bom_version",
                                   "routing_version", "version", "parent_order_id"]),
                    "item_code": item.item_code, "item_description": item.description})
    return out


@router.post("/orders", status_code=201)
def post_order(body: OrderBody, ctx: CtxDep):
    return _detail(ctx, svc.create_order(ctx, ctx.site_id, body.item_id, body.quantity_target, due_date=body.due_date))


@router.get("/orders/{oid}")
def get_order(oid: int, ctx: CtxDep):
    ctx.require("production.read")
    return _detail(ctx, ctx.get(ProductionOrder, oid))


@router.post("/orders/{oid}/plan")
def post_plan(oid: int, body: VersionBody, ctx: CtxDep):
    return _detail(ctx, svc.plan_order(ctx, oid, body.version))


@router.post("/orders/{oid}/refresh-definitions")
def post_refresh(oid: int, body: VersionBody, ctx: CtxDep):
    return _detail(ctx, svc.refresh_definitions(ctx, oid, body.version))


@router.post("/orders/{oid}/allocate")
def post_allocate(oid: int, body: AllocateBody, ctx: CtxDep):
    allocs = [a.model_dump() for a in body.allocations] if body.allocations else None
    return {"reservations": svc.allocate_materials(ctx, oid, allocs)}


@router.post("/orders/{oid}/release")
def post_release(oid: int, body: ReleaseBody, ctx: CtxDep):
    return _detail(ctx, svc.release_order(ctx, oid, body.version, allow_shortage=body.allow_shortage))


@router.post("/orders/{oid}/pause")
def post_pause(oid: int, body: PauseBody, ctx: CtxDep):
    return _detail(ctx, svc.pause_order(ctx, oid, body.reason))


@router.post("/orders/{oid}/cancel")
def post_cancel(oid: int, body: CancelBody, ctx: CtxDep):
    return _detail(ctx, svc.cancel_order(ctx, oid, body.version, body.reason, [d.model_dump() for d in body.dispositions]))


@router.post("/orders/{oid}/close")
def post_close(oid: int, body: VersionBody, ctx: CtxDep):
    return _detail(ctx, svc.close_order(ctx, oid, body.version))


@router.post("/materials/{mid}/issue", status_code=201)
def post_issue(mid: int, body: IssueBody, ctx: CtxDep, idem: IdemKey = None):
    def run():
        mv = svc.issue_material(ctx, mid, body.lot_id, body.quantity, to_bin_code=body.to_bin, value_source=body.value_source,
                                observed_at=body.observed_at, idempotency_key=idem)
        return row_dict(mv)
    return idempotent(ctx, "issue", idem, {"mid": mid, **body.model_dump()}, run)


@router.post("/materials/{mid}/return", status_code=201)
def post_return(mid: int, body: ReturnBody, ctx: CtxDep):
    return row_dict(svc.return_material(ctx, mid, body.lot_id, body.quantity, from_bin_code=body.from_bin, to_bin_code=body.to_bin,
                                        observed_at=body.observed_at))


@router.post("/materials/{mid}/consume", status_code=201)
def post_consume(mid: int, body: ConsumeBody, ctx: CtxDep, idem: IdemKey = None):
    def run():
        return row_dict(svc.record_consumption(ctx, mid, body.lot_id, body.quantity, body.unit, from_bin_code=body.from_bin,
                                               value_source=body.value_source, observed_at=body.observed_at,
                                               order_operation_id=body.operation_id, idempotency_key=idem, note=body.note))
    return idempotent(ctx, "consume", idem, {"mid": mid, **body.model_dump()}, run)


@router.post("/orders/{oid}/backflush", status_code=201)
def post_backflush(oid: int, body: BackflushBody, ctx: CtxDep):
    mvs = svc.backflush(ctx, oid, body.operation_id, body.good_quantity, from_bin_code=body.from_bin, observed_at=body.observed_at)
    return {"movements": [row_dict(m) for m in mvs], "label": "calculated consumption (backflush) — reconcile before closing"}


@router.post("/materials/{mid}/reconcile-backflush", status_code=201)
def post_reconcile(mid: int, body: ReconcileBody, ctx: CtxDep):
    return row_dict(svc.reconcile_backflush(ctx, mid, body.counted_remaining, bin_code=body.bin, note=body.note))


@router.post("/operations/{op_id}/check-equipment")
def post_check(op_id: int, body: EquipmentCheckBody, ctx: CtxDep):
    return svc.check_equipment(ctx, op_id, body.equipment_code, body.checklist, body.observed_at)


@router.post("/operations/{op_id}/start")
def post_start(op_id: int, body: StartBody, ctx: CtxDep):
    return row_dict(svc.start_operation(ctx, op_id, body.equipment_code, phase=body.phase, observed_at=body.observed_at))


@router.post("/operations/{op_id}/pause")
def post_pause_op(op_id: int, body: PauseBody, ctx: CtxDep):
    return row_dict(svc.pause_operation(ctx, op_id, body.reason, body.observed_at))


@router.post("/operations/{op_id}/resume")
def post_resume(op_id: int, body: StartBody, ctx: CtxDep):
    return row_dict(svc.resume_operation(ctx, op_id, body.equipment_code, body.observed_at, body.phase))


@router.post("/operations/{op_id}/quantities")
def post_qty(op_id: int, body: QtyBody, ctx: CtxDep):
    return row_dict(svc.report_quantities(ctx, op_id, body.good, body.rework, body.observed_at))


@router.post("/orders/{oid}/output", status_code=201)
def post_output(oid: int, body: OutputBody, ctx: CtxDep, idem: IdemKey = None):
    def run():
        lots = svc.report_output(ctx, oid, body.operation_id, body.quantity, conformity=body.conformity,
                                 lot_number=body.lot_number, serials=body.serials, to_bin_code=body.to_bin,
                                 consumed_inputs=[c.model_dump() for c in body.consumed_inputs] if body.consumed_inputs else None,
                                 observed_at=body.observed_at, defect_description=body.defect_description,
                                 nonconformance_id=body.nonconformance_id)
        return {"lots": [{"id": l.id, "lot_number": l.lot_number, "quality_status": l.quality_status} for l in lots],
                "note": "Output awaits quality review; it is not available for sale until released."}
    return idempotent(ctx, "output", idem, {"oid": oid, **body.model_dump()}, run)


@router.post("/operations/{op_id}/complete")
def post_complete(op_id: int, body: CompleteBody, ctx: CtxDep):
    return row_dict(svc.complete_operation(ctx, op_id, body.observed_at, body.note))


@router.post("/operations/{op_id}/handover")
def post_handover(op_id: int, body: HandoverBody, ctx: CtxDep):
    return row_dict(svc.handover(ctx, op_id, body.quantity, body.note, body.observed_at))


@router.post("/operations/{op_id}/defect", status_code=201)
def post_defect(op_id: int, body: DefectBody, ctx: CtxDep):
    return row_dict(svc.raise_defect(ctx, op_id, body.description, body.quantity, body.lot_ids, body.severity))


@router.get("/scrap")
def scrap(ctx: CtxDep, status: str | None = None):
    ctx.require("production.read")
    stmt = select(ScrapRecord).order_by(ScrapRecord.id.desc())
    if status:
        stmt = stmt.where(ScrapRecord.status == status)
    return [{**row_dict(s), "item_code": ctx.db.get(Item, s.item_id).item_code} for s in ctx.db.execute(stmt).scalars()]


@router.post("/scrap", status_code=201)
def post_scrap(body: ScrapBody, ctx: CtxDep):
    d = body.model_dump()
    return row_dict(svc.report_scrap(ctx, order_id=d.pop("order_id"), op_id=d.pop("operation_id"), bin_code=d.pop("bin"), **d))


@router.post("/scrap/{sid}/authorise")
def post_authorise(sid: int, body: AuthoriseBody, ctx: CtxDep):
    return row_dict(svc.authorise_scrap(ctx, sid, body.approve, body.note))


@router.post("/ncrs/{nid}/rework-order", status_code=201)
def post_rework(nid: int, body: ReworkBody, ctx: CtxDep):
    o = svc.create_rework_order(ctx, nid, instructions=body.instructions,
                                additional_materials=[a.model_dump() for a in body.additional_materials], due_date=body.due_date)
    return _detail(ctx, o)


@router.post("/orders/{oid}/rework-issue")
def post_rework_issue(oid: int, body: ReworkMoveBody, ctx: CtxDep):
    svc.issue_for_rework(ctx, oid, body.lot_ids, from_bin_code=body.from_bin, to_bin_code=body.to_bin, observed_at=body.observed_at)
    return {"ok": True}


@router.post("/orders/{oid}/rework-output")
def post_rework_output(oid: int, body: ReworkMoveBody, ctx: CtxDep):
    lots = svc.report_rework_output(ctx, oid, body.operation_id, body.lot_ids, from_bin_code=body.from_bin,
                                    to_bin_code=body.to_bin, observed_at=body.observed_at)
    return {"lots": [l.lot_number for l in lots]}


@router.get("/subcontract-shipments")
def sub_shipments(ctx: CtxDep):
    ctx.require("production.read")
    return [row_dict(s) for s in ctx.db.execute(select(SubcontractShipment).order_by(SubcontractShipment.id.desc())).scalars()]


@router.post("/orders/{oid}/subcontract-shipments", status_code=201)
def post_sub_send(oid: int, body: SubSendBody, ctx: CtxDep):
    return row_dict(svc.send_to_subcontractor(ctx, oid, body.operation_id, [l.model_dump() for l in body.lines], po_id=body.po_id,
                                              documents=body.documents, observed_at=body.observed_at))


@router.post("/subcontract-shipments/{sid}/receive", status_code=201)
def post_sub_receive(sid: int, body: SubReceiveBody, ctx: CtxDep):
    lot = svc.receive_from_subcontractor(ctx, sid, **body.model_dump())
    return row_dict(lot)


@router.get("/shopfloor/work")
def work(ctx: CtxDep):
    return shopfloor.authorised_work(ctx)


@router.post("/shopfloor/offline", status_code=202)
def post_offline(body: OfflineBody, ctx: CtxDep):
    return shopfloor.submit_offline(ctx, body.device_id, [e.model_dump() for e in body.entries])


@router.get("/shopfloor/offline")
def get_offline(ctx: CtxDep, status: str | None = "pending"):
    return shopfloor.list_offline(ctx, status)


@router.post("/shopfloor/offline/{eid}/reconcile")
def post_reconcile_offline(eid: int, body: ReconcileOfflineBody, ctx: CtxDep):
    return row_dict(shopfloor.reconcile_offline(ctx, eid, body.apply, body.note))
