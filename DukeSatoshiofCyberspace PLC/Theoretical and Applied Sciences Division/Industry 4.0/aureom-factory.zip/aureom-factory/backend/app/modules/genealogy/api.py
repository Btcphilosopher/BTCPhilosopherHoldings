"""Traceability endpoints plus the operational overview and material-flow summaries."""
from __future__ import annotations

from collections import defaultdict
from datetime import date
from decimal import Decimal

from fastapi import APIRouter
from sqlalchemy import func, select

from ...api_deps import CtxDep
from ...core.context import row_dict
from ..inventory.models import Bin, Lot, StockMovement
from ..inventory.service import stock_summary
from ..maintenance.models import Equipment
from ..production.models import OrderException, ProductionOrder
from ..purchasing.models import PurchaseOrder, PurchaseOrderLine
from ..quality.models import Inspection, Nonconformance
from ..registry.models import Item
from .service import backward, find_lots_by_supplier_lot, forward

router = APIRouter(prefix="/api", tags=["traceability", "reports"])


@router.get("/trace/{lot_id}/backward")
def trace_back(lot_id: int, ctx: CtxDep):
    ctx.require("reports.read")
    ctx.get(Lot, lot_id)
    return backward(ctx.db, lot_id)


@router.get("/trace/{lot_id}/forward")
def trace_fwd(lot_id: int, ctx: CtxDep):
    ctx.require("reports.read")
    ctx.get(Lot, lot_id)
    return forward(ctx.db, lot_id)


@router.get("/trace/supplier-lot/{supplier_lot}")
def by_supplier_lot(supplier_lot: str, ctx: CtxDep):
    ctx.require("reports.read")
    return [{**row_dict(l), "item_code": ctx.db.get(Item, l.item_id).item_code} for l in find_lots_by_supplier_lot(ctx.db, supplier_lot)]


STAGE = {
    "receiving": "Goods-in", "quarantine": "Quarantine", "storage": "Stores", "wip": "Work in progress",
    "subcontractor": "At subcontractor", "finished": "Finished goods", "dispatch": "Dispatch bay", "scrap": "Scrap",
    "returns": "Returns review",
}


@router.get("/reports/material-flow")
def material_flow(ctx: CtxDep):
    """Quantity-weighted flows between stages (by bin kind), for the cyan flow diagram and its table."""
    ctx.require("reports.read")
    edges: dict[tuple[str, str], dict] = defaultdict(lambda: {"movements": 0, "items": set()})
    bins = {b.id: b for b in ctx.db.execute(select(Bin)).scalars()}
    for mv in ctx.db.execute(select(StockMovement)).scalars():
        src = STAGE[bins[mv.from_bin_id].kind] if mv.from_bin_id else {
            "receipt": "Suppliers", "production_output": "Production", "subcontract_return": "At subcontractor",
            "customer_return": "Customers", "adjustment": "Adjustment", "reversal": "Reversal"}.get(mv.movement_type, mv.movement_type)
        dst = STAGE[bins[mv.to_bin_id].kind] if mv.to_bin_id else {
            "consumption": "Production", "dispatch": "Customers", "scrap": "Scrap", "supplier_return": "Suppliers",
            "adjustment": "Adjustment", "reversal": "Reversal"}.get(mv.movement_type, mv.movement_type)
        if src == dst:
            continue
        e = edges[(src, dst)]
        e["movements"] += 1
        e["items"].add(ctx.db.get(Item, mv.item_id).item_code)
    order = ["Suppliers", "Goods-in", "Quarantine", "Stores", "Work in progress", "Production", "At subcontractor",
             "Finished goods", "Dispatch bay", "Customers", "Returns review", "Scrap", "Adjustment", "Reversal"]
    nodes = [n for n in order if any(n in k for k in edges)]
    return {"nodes": nodes, "edges": [{"from": a, "to": b, "movements": v["movements"], "items": sorted(v["items"])}
                                      for (a, b), v in sorted(edges.items(), key=lambda kv: (order.index(kv[0][0]) if kv[0][0] in order else 99))]}


@router.get("/reports/overview")
def overview(ctx: CtxDep):
    ctx.require("reports.read")
    db = ctx.db
    orders = defaultdict(int)
    for s, n in db.execute(select(ProductionOrder.status, func.count()).group_by(ProductionOrder.status)).all():
        orders[s] = n
    late_pos = []
    for pl, po in db.execute(select(PurchaseOrderLine, PurchaseOrder).join(PurchaseOrder)
                             .where(PurchaseOrderLine.status.in_(("open", "partially_received")),
                                    PurchaseOrder.status.in_(("sent", "acknowledged", "partially_received")))).all():
        due = pl.acknowledged_delivery or pl.expected_delivery
        if due and due < date.today():
            late_pos.append({"po": po.number, "line": pl.line_no, "item": db.get(Item, pl.item_id).item_code, "due": due.isoformat()})
    constraints, failures = [], []
    for e in db.execute(select(Equipment).where(Equipment.status != "available")).scalars():
        (failures if e.status == "down" else constraints).append({"kind": "equipment", "text": f"{e.code} {e.status}: {e.status_note or ''}"})
    for e in db.execute(select(Equipment).where(Equipment.calibration_required.is_(True))).scalars():
        if e.calibration_due is None or e.calibration_due < date.today():
            failures.append({"kind": "calibration", "text": f"{e.code} calibration overdue"})
    for x in db.execute(select(OrderException).where(OrderException.status == "open").order_by(OrderException.id.desc()).limit(20)).scalars():
        o = db.get(ProductionOrder, x.order_id)
        (failures if x.severity == "failure" else constraints).append({"kind": x.kind, "text": f"{o.number}: {x.description}"})
    for o in db.execute(select(ProductionOrder).where(ProductionOrder.schedule_feasible.is_(False))).scalars():
        constraints.append({"kind": "schedule", "text": f"{o.number}: " + "; ".join(o.schedule_notes or [])})
    for p in late_pos:
        constraints.append({"kind": "late_delivery", "text": f"{p['po']} line {p['line']} {p['item']} due {p['due']}"})
    stock = stock_summary(db, None, ctx.site_id)
    return {
        "orders_by_status": dict(orders),
        "open_ncrs": db.execute(select(func.count()).select_from(Nonconformance).where(Nonconformance.status == "open")).scalar(),
        "open_inspections": db.execute(select(func.count()).select_from(Inspection).where(Inspection.status != "decided")).scalar(),
        "lots_awaiting_release": db.execute(select(func.count()).select_from(Lot).where(Lot.quality_status == "awaiting_review")).scalar(),
        "lots_quarantined": db.execute(select(func.count()).select_from(Lot).where(Lot.quality_status == "quarantined")).scalar(),
        "late_purchase_lines": late_pos, "constraints": constraints, "failures": failures,
        "stock": stock,
        "recent_movements": [
            {"movement_no": m.movement_no, "type": m.movement_type, "item": db.get(Item, m.item_id).item_code,
             "qty": str(m.quantity), "observed_at": m.observed_at.isoformat(), "value_source": m.value_source}
            for m in db.execute(select(StockMovement).order_by(StockMovement.id.desc()).limit(15)).scalars()],
    }
