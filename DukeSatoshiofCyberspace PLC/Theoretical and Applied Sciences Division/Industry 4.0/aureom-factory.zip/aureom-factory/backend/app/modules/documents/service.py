"""Protected object storage: content-addressed files on a private volume + signed, short-lived download links."""
from __future__ import annotations

import hashlib
import mimetypes
import os
import re
from pathlib import Path

from ...config import settings
from ...core.context import Ctx, row_dict
from ...core.errors import NotFound, PermissionDenied, ValidationFailed
from ...core.security import sign, unsign
from .models import Document

ALLOWED_TYPES = {
    "application/pdf", "image/png", "image/jpeg", "image/svg+xml", "text/plain", "text/csv",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/dxf", "model/step",
    "application/octet-stream", "text/html",
}
SAFE_NAME = re.compile(r"[^A-Za-z0-9._-]+")


class LocalObjectStore:
    """Files stored by SHA-256 under AUREOM_STORAGE_PATH (a private Docker volume). Never served directly."""

    def __init__(self, root: str | None = None):
        self.root = Path(root or settings.storage_path)
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        if not re.fullmatch(r"[0-9a-f]{64}", key):
            raise ValidationFailed("bad storage key")
        return self.root / key[:2] / key

    def put(self, data: bytes) -> str:
        key = hashlib.sha256(data).hexdigest()
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        if not p.exists():
            tmp = p.with_suffix(".tmp")
            tmp.write_bytes(data)
            os.replace(tmp, p)
        return key

    def get(self, key: str) -> bytes:
        p = self._path(key)
        if not p.exists():
            raise NotFound("Stored object missing")
        return p.read_bytes()


def store() -> LocalObjectStore:
    return LocalObjectStore()


def upload(ctx: Ctx, *, data: bytes, filename: str, content_type: str | None, kind: str, title: str,
           classification: str = "internal", entity_type=None, entity_id=None, revision=None, note=None) -> Document:
    ctx.require("documents.upload")
    if classification == "restricted" and not (ctx.can("engineering.approve") or ctx.can("quality.release")):
        raise PermissionDenied("Only engineering approvers or quality managers may upload restricted documents")
    if len(data) == 0:
        raise ValidationFailed("Empty file")
    if len(data) > settings.max_upload_bytes:
        raise ValidationFailed("File too large")
    content_type = content_type or mimetypes.guess_type(filename)[0] or "application/octet-stream"
    if content_type not in ALLOWED_TYPES:
        raise ValidationFailed(f"File type {content_type} not allowed")
    key = store().put(data)
    doc = Document(kind=kind, title=title, filename=SAFE_NAME.sub("_", filename)[:200], content_type=content_type,
                   size_bytes=len(data), sha256=key, storage_key=key, classification=classification,
                   entity_type=entity_type, entity_id=entity_id, revision=revision, site_id=ctx.site_id,
                   uploaded_by=ctx.user.id, note=note)
    ctx.db.add(doc)
    ctx.db.flush()
    ctx.audit("document.upload", "document", doc.id, after=row_dict(doc))
    return doc


def can_read(ctx: Ctx, doc: Document) -> bool:
    if not ctx.can("documents.read", doc.site_id):
        return False
    if doc.classification == "restricted":
        return ctx.can("engineering.edit") or ctx.can("quality.record") or ctx.can("engineering.approve")
    return True


def download_link(ctx: Ctx, doc_id: int, ttl_seconds: int = 300) -> str:
    doc = ctx.get(Document, doc_id)
    if not can_read(ctx, doc):
        raise PermissionDenied("Not permitted to read this document")
    ctx.audit("document.link", "document", doc.id)
    return sign({"doc": doc.id, "uid": ctx.user.id}, ttl_seconds, purpose="download")


def read_with_token(db, token: str) -> tuple[Document, bytes]:
    body = unsign(token, purpose="download")
    doc = db.get(Document, body["doc"])
    if doc is None:
        raise NotFound("Document not found")
    data = store().get(doc.storage_key)
    if hashlib.sha256(data).hexdigest() != doc.sha256:
        raise ValidationFailed("Stored document failed integrity check")
    return doc, data
