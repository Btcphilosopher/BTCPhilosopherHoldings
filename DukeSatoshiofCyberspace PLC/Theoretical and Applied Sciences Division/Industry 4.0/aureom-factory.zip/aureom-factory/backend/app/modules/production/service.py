"""Production order lifecycle and shop-floor execution.

Status flow:
  draft → planned (definitions snapshotted, materials/operations created)
        → released (snapshot frozen; engineering changes no longer affect it)
        → in_progress ⇄ paused
        → awaiting_inspection (all operations complete; output awaiting quality decision)
        → completed (every output lot has a quality decision)
        → closed (materials reconciled, costs settled)
  draft/planned/released/in_progress/paused → cancelled (controlled; unused material returned)

Completing operations does not accept output; accepting output does not close the order.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ...core.context import Ctx, check_version, row_dict, utcnow
from ...core.errors import InsufficientStock, InvalidState, NotFound, QualityHold, ValidationFailed
from ...core.numbers import D, ZERO, fmt, q
from ..engineering.models import Bom, Routing, WorkCentre
from ..engineering.service import effective_bom, effective_routing, snapshot, start_quantity
from ..genealogy.models import GenealogyEdge
from ..inventory.models import Bin, Lot, Reservation, StockBalance, StockMovement
from ..inventory.service import (
    available_rows, bin_by_code, create_lot, issue_reserved, lot_on_hand, post_movement, release_reservation, reserve,
    set_lot_status,
)
from ..maintenance.models import Equipment
from ..quality.models import Inspection, InspectionPlan, Nonconformance
from ..registry.models import Item
from ..registry.service import get_unit, to_base
from .models import (
    BackflushReconciliation, OperationEvent, OrderException, OrderMaterial, OrderOperation, ProductionOrder,
    ProductionOutput, ScrapRecord, SubcontractShipment,
)

ACTIVE = ("released", "in_progress", "paused")


def _require_any(ctx: Ctx, perms: tuple[str, ...], site_id: int | None) -> None:
    if not any(ctx.can(p, site_id) for p in perms):
        ctx.require(perms[0], site_id)


def _order(ctx: Ctx, order_id: int) -> ProductionOrder:
    return ctx.get(ProductionOrder, order_id, "Production order")


def _op(ctx: Ctx, op_id: int) -> OrderOperation:
    return ctx.get(OrderOperation, op_id, "Operation")


# --------------------------------------------------------------------------- creation and planning


def create_order(ctx: Ctx, site_id: int, item_id: int, quantity_target, *, due_date: date | None = None,
                 source: str = "manual", mrp_proposal_id=None, demand_id=None, kind="standard",
                 effective_on: date | None = None, planned_start=None, planned_end=None) -> ProductionOrder:
    ctx.require("production.create", site_id)
    item = ctx.get(Item, item_id)
    if item.item_type not in ("wip", "subassembly", "finished_product"):
        raise ValidationFailed(f"{item.item_code} is not a manufactured item")
    on = effective_on or date.today()
    bom = effective_bom(ctx.db, item.id, on)
    routing = effective_routing(ctx.db, item.id, on)
    if bom is None or routing is None:
        raise ValidationFailed(f"{item.item_code} has no approved BOM and routing effective on {on}")
    target = to_base(ctx.db, item, quantity_target, item.base_unit)
    integral = get_unit(ctx.db, item.base_unit).integral
    order = ProductionOrder(
        number=ctx.next_number("MO"), site_id=site_id, kind=kind, item_id=item.id, quantity_target=target,
        quantity_start=start_quantity(bom, target, integral), status="draft", bom_id=bom.id, bom_version=bom.version,
        routing_id=routing.id, routing_version=routing.version, due_date=due_date, source=source,
        mrp_proposal_id=mrp_proposal_id, demand_id=demand_id, created_by=ctx.user.id,
        planned_start=planned_start, planned_end=planned_end,
    )
    ctx.db.add(order)
    ctx.db.flush()
    ctx.audit("order.create", "production_order", order.id, after=row_dict(order), site_id=site_id)
    return order


def _build_from_snapshot(ctx: Ctx, order: ProductionOrder) -> None:
    for m in list(order.materials):
        if ctx.db.execute(select(Reservation.id).where(Reservation.demand_type == "production_material",
                                                       Reservation.demand_id == m.id, Reservation.status == "active")).first():
            raise InvalidState("Release existing reservations before rebuilding materials")
    order.materials.clear()
    order.operations.clear()
    ctx.db.flush()
    snap = order.snapshot
    groups: dict[str, list[dict]] = defaultdict(list)
    for l in snap["bom"]["lines"]:
        if l["alternative_group"]:
            groups[l["alternative_group"]].append(l)
    for l in snap["bom"]["lines"]:
        if l["alternative_group"] and l["alternative_priority"] != 1:
            continue
        alts = [a["component_item_id"] for a in groups.get(l["alternative_group"] or "", [])
                if a["alternative_priority"] != 1 and a["alternative_approved"]]
        comp = ctx.db.get(Item, l["component_item_id"])
        req = D(l["gross_per_parent_base"]) * D(order.quantity_start)
        if get_unit(ctx.db, comp.base_unit).integral:
            from ...core.numbers import ceil_int
            req = ceil_int(req)
        order.materials.append(OrderMaterial(
            line_no=l["line_no"], item_id=comp.id, alternative_item_ids=alts, required_quantity=q(req),
            unit=comp.base_unit, is_packaging=l["is_packaging"], backflush=l["backflush"], operation_seq=l["operation_seq"],
        ))
    for o in snap["routing"]["operations"]:
        order.operations.append(OrderOperation(**{k: o[k] for k in (
            "seq", "code", "name", "work_centre_id", "required_equipment_kind", "required_skill", "setup_minutes",
            "run_minutes_per_unit", "machine_minutes_per_unit", "inspection_point", "inspection_plan_code",
            "instructions", "instruction_document_id", "depends_on", "subcontracted", "subcontract_supplier_id",
            "subcontract_lead_days", "reports_output")}))
    ctx.db.flush()


def plan_order(ctx: Ctx, order_id: int, version: int | None, *, effective_on: date | None = None) -> ProductionOrder:
    """Firm the order: snapshot the approved BOM/routing revisions and create material and operation lines."""
    order = _order(ctx, order_id)
    ctx.require("production.plan", order.site_id)
    check_version(order, version)
    if order.status not in ("draft", "planned"):
        raise InvalidState(f"{order.number} is {order.status}; its definitions are frozen")
    on = effective_on or date.today()
    if order.kind == "rework":
        bom = None
    else:
        bom = ctx.db.get(Bom, order.bom_id)
    routing = ctx.db.get(Routing, order.routing_id)
    snap = snapshot(ctx.db, bom, routing, on)
    if bom is None:
        snap["bom"] = {"bom_id": None, "version": None, "lines": [], "expected_yield_pct": "100", "base_quantity": "1"}
    extra = [m for m in order.materials if m.additional]
    extra_data = [row_dict(m, ["item_id", "required_quantity", "unit", "operation_seq"]) for m in extra]
    order.snapshot = snap
    _build_from_snapshot(ctx, order)
    for e in extra_data:
        order.materials.append(OrderMaterial(line_no=900 + len(order.materials), item_id=e["item_id"],
                                             required_quantity=D(e["required_quantity"]), unit=e["unit"],
                                             operation_seq=e["operation_seq"], additional=True))
    order.status = "planned"
    from ..costing.service import planned_order_cost
    order.planned_cost = planned_order_cost(ctx.db, order)
    ctx.audit("order.plan", "production_order", order.id, after={"bom_version": order.bom_version,
                                                                  "routing_version": order.routing_version})
    return order


def refresh_definitions(ctx: Ctx, order_id: int, version: int | None, on: date | None = None) -> ProductionOrder:
    """Explicitly move an unreleased order to the currently effective revisions (never automatic)."""
    order = _order(ctx, order_id)
    ctx.require("production.plan", order.site_id)
    if order.status not in ("draft", "planned"):
        raise InvalidState("Released orders keep their frozen revisions")
    bom, routing = effective_bom(ctx.db, order.item_id, on), effective_routing(ctx.db, order.item_id, on)
    order.bom_id, order.bom_version = bom.id, bom.version
    order.routing_id, order.routing_version = routing.id, routing.version
    order.quantity_start = start_quantity(bom, order.quantity_target, get_unit(ctx.db, ctx.db.get(Item, order.item_id).base_unit).integral)
    ctx.db.flush()
    return plan_order(ctx, order_id, order.version, effective_on=on)


def material_reserved(db: Session, m: OrderMaterial) -> Decimal:
    return D(db.execute(select(func.coalesce(func.sum(Reservation.quantity - Reservation.quantity_issued), 0)).where(
        Reservation.demand_type == "production_material", Reservation.demand_id == m.id, Reservation.status == "active"
    )).scalar())


def allocate_materials(ctx: Ctx, order_id: int, allocations: list[dict] | None = None) -> list[dict]:
    """Reserve accepted lots for the order. Explicit allocations: [{material_id, lot_id, quantity}];
    otherwise each line's outstanding requirement is reserved FEFO/FIFO."""
    order = _order(ctx, order_id)
    ctx.require("inventory.reserve", order.site_id)
    if order.status not in ("planned", "released", "in_progress", "paused"):
        raise InvalidState(f"{order.number} is {order.status}; plan it first")
    out = []
    if allocations:
        for a in allocations:
            m = ctx.get(OrderMaterial, a["material_id"])
            if m.order_id != order.id:
                raise ValidationFailed("Material line belongs to another order")
            lot = ctx.get(Lot, a["lot_id"])
            if lot.item_id != m.item_id and lot.item_id not in (m.alternative_item_ids or []):
                raise ValidationFailed(f"Lot {lot.lot_number} is not the required item or an approved alternative")
            item = ctx.db.get(Item, lot.item_id)
            for r in reserve(ctx, item, a["quantity"], "production_material", m.id, lot=lot):
                out.append({"material_id": m.id, "lot": lot.lot_number, "bin_id": r.bin_id, "quantity": str(r.quantity)})
        return out
    for m in order.materials:
        if m.backflush:
            pass  # backflushed lines are still reserved so that stock is protected
        outstanding = D(m.required_quantity) - D(m.quantity_issued) - material_reserved(ctx.db, m)
        if outstanding <= 0:
            continue
        item = ctx.db.get(Item, m.item_id)
        free = sum((r["available"] for r in available_rows(ctx.db, item.id)), ZERO)
        take = min(outstanding, free)
        if take <= 0:
            out.append({"material_id": m.id, "item": item.item_code, "lot": None, "quantity": "0",
                        "shortage": str(outstanding)})
            continue
        for r in reserve(ctx, item, take, "production_material", m.id):
            lot = ctx.db.get(Lot, r.lot_id) if r.lot_id else None
            out.append({"material_id": m.id, "item": item.item_code, "lot": lot.lot_number if lot else None,
                        "quantity": str(r.quantity)})
    return out


def shortages(db: Session, order: ProductionOrder) -> list[dict]:
    res = []
    for m in order.materials:
        covered = D(m.quantity_issued) + material_reserved(db, m)
        if covered < D(m.required_quantity):
            res.append({"material_id": m.id, "item_code": db.get(Item, m.item_id).item_code,
                        "required": str(m.required_quantity), "covered": str(covered),
                        "short": str(q(D(m.required_quantity) - covered)), "unit": m.unit})
    return res


def release_order(ctx: Ctx, order_id: int, version: int | None, *, allow_shortage: bool = False,
                  released_at: datetime | None = None) -> ProductionOrder:
    order = _order(ctx, order_id)
    ctx.require("production.release", order.site_id)
    check_version(order, version)
    if order.status != "planned":
        raise InvalidState(f"{order.number} is {order.status}; only planned orders can be released")
    if order.kind != "rework":
        bom = ctx.db.get(Bom, order.bom_id)
        if bom.status not in ("approved", "superseded"):
            raise InvalidState(f"BOM v{bom.version} is {bom.status}")
    short = shortages(ctx.db, order)
    if short and not allow_shortage:
        raise InsufficientStock("Materials are not fully allocated: " + ", ".join(
            f"{s['item_code']} short {s['short']} {s['unit']}" for s in short), details=short)
    order.snapshot = {**order.snapshot, "frozen_at": (released_at or utcnow()).isoformat(), "frozen": True}
    order.status = "released"
    order.released_by, order.released_at = ctx.user.id, released_at or utcnow()
    first = min(order.operations, key=lambda o: o.seq)
    first.status = "ready"
    for s in short:
        ctx.db.add(OrderException(order_id=order.id, kind="material_shortage", severity="constraint",
                                  description=f"Released with shortage: {s['item_code']} short {s['short']} {s['unit']}",
                                  raised_by=ctx.user.id))
    ctx.audit("order.release", "production_order", order.id, after={"shortages": short}, site_id=order.site_id)
    ctx.emit("production.order_released", {"number": order.number})
    return order


# --------------------------------------------------------------------------- materials


def issue_material(ctx: Ctx, material_id: int, lot_id: int, quantity, *, to_bin_code: str,
                   value_source: str = "scanned", observed_at=None, idempotency_key=None) -> StockMovement:
    """Physically move reserved material to line-side (WIP) or to a subcontractor."""
    m = ctx.get(OrderMaterial, material_id)
    order = m.order
    _require_any(ctx, ("production.execute", "inventory.move"), order.site_id)
    if order.status not in ACTIVE:
        raise InvalidState(f"{order.number} is {order.status}; material can only be issued to released orders")
    lot = ctx.get(Lot, lot_id)
    if lot.item_id != m.item_id and lot.item_id not in (m.alternative_item_ids or []):
        raise ValidationFailed(f"Scanned lot {lot.lot_number} is not {ctx.db.get(Item, m.item_id).item_code} or an approved alternative")
    to_bin = bin_by_code(ctx.db, to_bin_code)
    need = D(quantity)
    reservations = ctx.db.execute(select(Reservation).where(
        Reservation.demand_type == "production_material", Reservation.demand_id == m.id,
        Reservation.lot_id == lot.id, Reservation.status == "active").order_by(Reservation.id)).scalars().all()
    if not reservations or sum(D(r.quantity) - D(r.quantity_issued) for r in reservations) < need:
        # Not (fully) reserved: reserve now — this re-checks quality status and availability under lock.
        item = ctx.db.get(Item, lot.item_id)
        have = sum((D(r.quantity) - D(r.quantity_issued) for r in reservations), ZERO)
        reservations += reserve(ctx, item, need - have, "production_material", m.id, lot=lot)
    last = None
    mtype_sub = to_bin.kind == "subcontractor"
    for r in reservations:
        if need <= 0:
            break
        take = min(need, D(r.quantity) - D(r.quantity_issued))
        if take <= 0:
            continue
        last = issue_reserved(ctx, r, take, to_bin, reference_type="production_order", reference_id=order.id,
                              reference_line_id=m.id, value_source=value_source, observed_at=observed_at,
                              idempotency_key=f"{idempotency_key}:{r.id}" if idempotency_key else None)
        need -= take
    m.quantity_issued = q(D(m.quantity_issued) + D(quantity))
    ctx.audit("order.issue", "production_order", order.id,
              after={"material_id": m.id, "lot": lot.lot_number, "qty": str(quantity), "to": to_bin.code})
    return last


def return_material(ctx: Ctx, material_id: int, lot_id: int, quantity, *, from_bin_code: str, to_bin_code: str,
                    observed_at=None, reason: str = "unused") -> StockMovement:
    m = ctx.get(OrderMaterial, material_id)
    _require_any(ctx, ("production.execute", "inventory.move"), m.order.site_id)
    lot = ctx.get(Lot, lot_id)
    item = ctx.db.get(Item, lot.item_id)
    mv = post_movement(ctx, "return", item, quantity, item.base_unit, lot=lot, from_bin=bin_by_code(ctx.db, from_bin_code),
                       to_bin=bin_by_code(ctx.db, to_bin_code), reference_type="production_order",
                       reference_id=m.order_id, reference_line_id=m.id, reason_code=reason, observed_at=observed_at)
    m.quantity_returned = q(D(m.quantity_returned) + mv.quantity)
    return mv


def _add_edge(ctx: Ctx, **kw) -> None:
    ctx.db.add(GenealogyEdge(recorded_by=ctx.user.id, **kw))


def record_consumption(ctx: Ctx, material_id: int, lot_id: int, quantity, unit: str | None = None, *,
                       from_bin_code: str, value_source: str = "manual", observed_at=None,
                       order_operation_id: int | None = None, idempotency_key=None, note=None,
                       _caller_checked: bool = False) -> StockMovement:
    """Record material actually used. Only material physically at line-side (issued) can be consumed."""
    m = ctx.get(OrderMaterial, material_id)
    order = m.order
    if not _caller_checked:
        ctx.require("production.execute", order.site_id)
    if order.status not in ("in_progress", "paused", "released"):
        raise InvalidState(f"{order.number} is {order.status}")
    if value_source not in ("scanned", "manual", "measured", "calculated"):
        raise ValidationFailed("value_source must be scanned, manual, measured or calculated")
    lot = ctx.get(Lot, lot_id)
    if lot.item_id != m.item_id and lot.item_id not in (m.alternative_item_ids or []):
        raise ValidationFailed(f"Lot {lot.lot_number} is not valid for this material line")
    item = ctx.db.get(Item, lot.item_id)
    from_bin = bin_by_code(ctx.db, from_bin_code)
    mv = post_movement(ctx, "consumption", item, quantity, unit or item.base_unit, lot=lot, from_bin=from_bin,
                       reference_type="production_order", reference_id=order.id, reference_line_id=m.id,
                       value_source=value_source, observed_at=observed_at, idempotency_key=idempotency_key,
                       notes=note, skip_quality_gate=from_bin.kind == "subcontractor")
    m.quantity_consumed = q(D(m.quantity_consumed) + mv.quantity)
    if value_source == "calculated":
        m.quantity_consumed_calculated = q(D(m.quantity_consumed_calculated) + mv.quantity)
    relation = "subcontract_input" if from_bin.kind == "subcontractor" else "consumed_by_order"
    _add_edge(ctx, parent_lot_id=lot.id, child_order_id=order.id, relation=relation, quantity=mv.quantity,
              unit=item.base_unit, precision="order_level", source_type="stock_movement", source_id=mv.id)
    if D(m.quantity_consumed) > D(m.required_quantity) * Decimal("1.10") and not m.additional:
        ctx.db.add(OrderException(order_id=order.id, kind="over_consumption", severity="constraint",
                                  description=f"{item.item_code}: consumed {fmt(m.quantity_consumed)} vs planned "
                                              f"{fmt(m.required_quantity)} {m.unit}", raised_by=ctx.user.id))
    return mv


def backflush(ctx: Ctx, order_id: int, order_operation_id: int, good_quantity, *, from_bin_code: str,
              observed_at=None) -> list[StockMovement]:
    """Calculated consumption for backflush lines at an operation. Labelled 'calculated' and
    reconciled against counted usage before the order can close."""
    order = _order(ctx, order_id)
    op = _op(ctx, order_operation_id)
    lines = {l["line_no"]: l for l in order.snapshot["bom"]["lines"]}
    out = []
    from_bin = bin_by_code(ctx.db, from_bin_code)
    for m in order.materials:
        if not m.backflush or (m.operation_seq and m.operation_seq != op.seq):
            continue
        per = D(lines[m.line_no]["gross_per_parent_base"]) if m.line_no in lines else ZERO
        need = q(per * D(good_quantity))
        if get_unit(ctx.db, m.unit).integral:
            need = need.to_integral_value()
        rows = ctx.db.execute(select(StockBalance).where(StockBalance.bin_id == from_bin.id,
                                                         StockBalance.item_id == m.item_id, StockBalance.quantity > 0)
                              .order_by(StockBalance.lot_id)).scalars().all()
        for bal in rows:
            if need <= 0:
                break
            take = min(need, D(bal.quantity))
            out.append(record_consumption(ctx, m.id, bal.lot_id, take, from_bin_code=from_bin_code,
                                          value_source="calculated", observed_at=observed_at,
                                          order_operation_id=op.id, note="backflush (calculated)"))
            need -= take
        if need > 0:
            ctx.db.add(OrderException(order_id=order.id, kind="material_shortage", severity="failure",
                                      description=f"Backflush short by {fmt(need)} {m.unit} of "
                                                  f"{ctx.db.get(Item, m.item_id).item_code} at line-side",
                                      raised_by=ctx.user.id))
    return out


def reconcile_backflush(ctx: Ctx, material_id: int, counted_remaining: dict[int, Decimal], *, bin_code: str,
                        note: str | None = None, observed_at=None) -> BackflushReconciliation:
    """Compare calculated consumption with actual usage (issued − returned − counted remaining)."""
    m = ctx.get(OrderMaterial, material_id)
    ctx.require("production.execute", m.order.site_id)
    b = bin_by_code(ctx.db, bin_code)
    item = ctx.db.get(Item, m.item_id)
    total_counted = sum((D(v) for v in counted_remaining.values()), ZERO)
    actual = D(m.quantity_issued) - D(m.quantity_returned) - D(m.quantity_scrapped) - total_counted
    variance = actual - D(m.quantity_consumed)
    adj = None
    for lot_id, counted in counted_remaining.items():
        system = lot_on_hand(ctx.db, int(lot_id), b.id)
        diff = system - D(counted)
        lot = ctx.db.get(Lot, int(lot_id))
        if diff > 0:  # more used than calculated
            adj = record_consumption(ctx, m.id, lot.id, diff, from_bin_code=bin_code, value_source="manual",
                                     observed_at=observed_at, note="backflush reconciliation: counted usage above calculation")
        elif diff < 0:
            raise ValidationFailed(f"Counted {fmt(counted)} exceeds system line-side quantity {fmt(system)} for {lot.lot_number}; "
                                   "investigate before reconciling")
    rec = BackflushReconciliation(order_id=m.order_id, order_material_id=m.id,
                                  calculated_quantity=m.quantity_consumed_calculated, actual_quantity=q(actual),
                                  variance=q(variance), counted_remaining=q(total_counted),
                                  adjustment_movement_id=adj.id if adj else None, note=note, reconciled_by=ctx.user.id)
    ctx.db.add(rec)
    ctx.db.flush()
    ctx.audit("order.backflush_reconcile", "production_order", m.order_id, after=row_dict(rec))
    return rec


# --------------------------------------------------------------------------- shop-floor execution


def _event(ctx: Ctx, op: OrderOperation, event: str, *, observed_at=None, equipment: Equipment | None = None,
           quantity=None, data=None, note=None, value_source="manual", offline_entry_id=None) -> OperationEvent:
    ev = OperationEvent(order_operation_id=op.id, event=event, operator_user_id=ctx.user.id,
                        equipment_id=equipment.id if equipment else None, observed_at=observed_at or utcnow(),
                        quantity=D(quantity) if quantity is not None else None, data=data, note=note,
                        value_source=value_source, offline_entry_id=offline_entry_id)
    ctx.db.add(ev)
    ctx.db.flush()
    ctx.emit("production.operation_event", {"order": op.order.number, "op": op.seq, "event": event,
                                            "operator": ctx.user.username})
    return ev


def _equipment(ctx: Ctx, code: str) -> Equipment:
    eq = ctx.db.execute(select(Equipment).where(Equipment.code == code)).scalar_one_or_none()
    if eq is None:
        raise NotFound(f"Equipment {code} not found")
    return eq


def equipment_readiness(ctx: Ctx, op: OrderOperation, eq: Equipment, at: datetime | None = None) -> dict:
    from ..maintenance.service import equipment_available
    from ..quality.service import calibration_status

    issues = []
    if op.required_equipment_kind and eq.kind != op.required_equipment_kind:
        issues.append(f"{eq.code} is a {eq.kind}; operation needs {op.required_equipment_kind}")
    if eq.work_centre_id and eq.work_centre_id != op.work_centre_id:
        issues.append(f"{eq.code} belongs to another work centre")
    at = at or utcnow()
    avail, why = equipment_available(ctx.db, eq, at)
    if not avail:
        issues.append(why)
    if eq.calibration_required:
        ok, ref = calibration_status(ctx.db, eq, at.date())
        if not ok:
            issues.append(f"{eq.code} calibration not valid")
    return {"ready": not issues, "issues": issues}


def check_equipment(ctx: Ctx, op_id: int, equipment_code: str, checklist: dict | None = None, observed_at=None) -> dict:
    op = _op(ctx, op_id)
    ctx.require("production.execute", op.order.site_id)
    eq = _equipment(ctx, equipment_code)
    r = equipment_readiness(ctx, op, eq, observed_at or utcnow())
    failed = [k for k, v in (checklist or {}).items() if v is False]
    if failed:
        r["ready"] = False
        r["issues"].append("Checklist items failed: " + ", ".join(failed))
    _event(ctx, op, "equipment_check", observed_at=observed_at, equipment=eq,
           data={"checklist": checklist or {}, "ready": r["ready"], "issues": r["issues"]})
    return r


def _predecessors(op: OrderOperation) -> list[OrderOperation]:
    ops = sorted(op.order.operations, key=lambda o: o.seq)
    if op.depends_on:
        return [o for o in ops if o.seq in op.depends_on]
    prev = [o for o in ops if o.seq < op.seq]
    return prev[-1:] if prev else []


def start_operation(ctx: Ctx, op_id: int, equipment_code: str | None, *, phase: str = "run", observed_at=None,
                    offline_entry_id=None) -> OrderOperation:
    op = _op(ctx, op_id)
    order = op.order
    ctx.require("production.execute", order.site_id)
    if order.status not in ("released", "in_progress"):
        raise InvalidState(f"{order.number} is {order.status}; work cannot start")
    if op.subcontracted:
        raise InvalidState("Subcontracted operations are executed through a subcontract shipment")
    if op.required_skill and op.required_skill not in (ctx.user.skills or []):
        raise ValidationFailed(f"{ctx.user.full_name} is not recorded as skilled in '{op.required_skill}'")
    for p in _predecessors(op):
        if p.status not in ("completed", "handed_over") and D(p.quantity_good) <= 0:
            raise InvalidState(f"Operation {p.seq} {p.name} has not handed any work over")
    eq = None
    if op.required_equipment_kind:
        if not equipment_code:
            raise ValidationFailed("This operation requires equipment to be identified")
        eq = _equipment(ctx, equipment_code)
        last_check = ctx.db.execute(select(OperationEvent).where(
            OperationEvent.order_operation_id == op.id, OperationEvent.event == "equipment_check",
            OperationEvent.equipment_id == eq.id).order_by(OperationEvent.id.desc())).scalars().first()
        if last_check is None or not (last_check.data or {}).get("ready"):
            raise InvalidState(f"Equipment {eq.code} has no passed readiness check for this operation")
        r = equipment_readiness(ctx, op, eq, observed_at or utcnow())
        if not r["ready"]:
            raise InvalidState("Equipment not ready: " + "; ".join(r["issues"]))
    _event(ctx, op, "start", observed_at=observed_at, equipment=eq, data={"phase": phase},
           offline_entry_id=offline_entry_id)
    op.status = "in_progress"
    op.actual_start = op.actual_start or observed_at or utcnow()
    if order.status == "released":
        order.status = "in_progress"
    return op


def pause_operation(ctx: Ctx, op_id: int, reason: str, observed_at=None) -> OrderOperation:
    op = _op(ctx, op_id)
    ctx.require("production.execute", op.order.site_id)
    if op.status != "in_progress":
        raise InvalidState(f"Operation is {op.status}")
    _event(ctx, op, "pause", observed_at=observed_at, note=reason)
    if open_work(ctx.db, op) == 0:
        op.status = "paused"
    return op


def resume_operation(ctx: Ctx, op_id: int, equipment_code: str | None = None, observed_at=None, phase="run") -> OrderOperation:
    op = _op(ctx, op_id)
    if op.status not in ("paused", "in_progress"):
        raise InvalidState(f"Operation is {op.status}")
    if op.order.status == "paused":
        op.order.status = "in_progress"
    return start_operation(ctx, op_id, equipment_code, phase=phase, observed_at=observed_at)


def pause_order(ctx: Ctx, order_id: int, reason: str) -> ProductionOrder:
    order = _order(ctx, order_id)
    ctx.require("production.release", order.site_id)
    if order.status != "in_progress":
        raise InvalidState(f"{order.number} is {order.status}")
    for op in order.operations:
        if op.status == "in_progress":
            pause_operation(ctx, op.id, reason)
    order.status = "paused"
    ctx.db.add(OrderException(order_id=order.id, kind="other", severity="constraint", description=f"Paused: {reason}",
                              raised_by=ctx.user.id))
    ctx.audit("order.pause", "production_order", order.id, reason=reason)
    return order


def report_quantities(ctx: Ctx, op_id: int, good=0, rework=0, observed_at=None, value_source="manual") -> OrderOperation:
    """Operation-level counts (for operations that do not create stock)."""
    op = _op(ctx, op_id)
    ctx.require("production.execute", op.order.site_id)
    if op.status not in ("in_progress", "paused"):
        raise InvalidState("Quantities are reported against a started operation")
    op.quantity_good = q(D(op.quantity_good) + D(good))
    op.quantity_rework = q(D(op.quantity_rework) + D(rework))
    _event(ctx, op, "quantity", observed_at=observed_at, quantity=good, data={"good": str(good), "rework": str(rework)},
           value_source=value_source)
    return op


def ensure_operation_inspection(ctx: Ctx, op: OrderOperation, lots: list[Lot] | None = None, quantity=None) -> Inspection:
    insp = ctx.db.execute(select(Inspection).where(Inspection.order_operation_id == op.id, Inspection.status != "decided")).scalars().first()
    if insp:
        return insp
    from ..quality.service import open_inspection
    plan = ctx.db.execute(select(InspectionPlan).where(InspectionPlan.code == op.inspection_plan_code)).scalar_one_or_none() \
        if op.inspection_plan_code else None
    item = ctx.db.get(Item, plan.item_id if plan else op.order.item_id)
    return open_inspection(ctx, "in_process" if op.order.kind != "rework" else "rework", item, lots or [], plan=plan,
                           lot_quantity=quantity if quantity is not None else op.order.quantity_start,
                           production_order_id=op.order_id, order_operation_id=op.id)


def report_output(ctx: Ctx, order_id: int, op_id: int, quantity, *, conformity: str = "good",
                  lot_number: str | None = None, serials: list[str] | None = None, to_bin_code: str,
                  consumed_inputs: list[dict] | None = None, observed_at=None, value_source="manual",
                  defect_description: str | None = None, nonconformance_id: int | None = None) -> list[Lot]:
    """Report produced units. Output is ALWAYS created awaiting quality review (or quarantined if
    nonconforming) in a non-allocatable bin; completing the order does not release it.

    consumed_inputs = [{"lot_id", "quantity"}] scanned for this output: recorded as exact genealogy where
    one lot per component item was used; several lots of the same item are recorded as order-level
    (we know the set, not which unit received which)."""
    order = _order(ctx, order_id)
    op = _op(ctx, op_id)
    ctx.require("production.execute", order.site_id)
    if op.order_id != order.id:
        raise ValidationFailed("Operation does not belong to the order")
    if order.status not in ("in_progress", "paused"):
        raise InvalidState(f"{order.number} is {order.status}")
    if conformity not in ("good", "nonconforming"):
        raise ValidationFailed("conformity must be good or nonconforming")
    if conformity == "good" and not op.reports_output:
        raise ValidationFailed(f"Good output is reported at the output operation, not {op.seq} {op.name}")
    item = ctx.db.get(Item, order.item_id)
    to_bin = bin_by_code(ctx.db, to_bin_code)
    if to_bin.allocatable:
        raise QualityHold("New output must go to a non-allocatable holding bin until quality releases it")
    qty = to_base(ctx.db, item, quantity, item.base_unit)
    observed_at = observed_at or utcnow()
    status = "awaiting_review" if conformity == "good" else "quarantined"
    lots: list[Lot] = []
    if item.lot_or_serial_policy == "serial":
        if not serials or len(serials) != int(qty):
            raise ValidationFailed("Serial-controlled output needs exactly one serial per unit")
        for s in serials:
            lots.append(create_lot(ctx, item, s, "production", quality_status=status, production_order_id=order.id,
                                   manufactured_on=observed_at.date(), batch_ref=order.number))
    else:
        lots.append(create_lot(ctx, item, lot_number or f"{order.number}-{ctx.next_number('B', 3).split('-')[1]}",
                               "production", quality_status=status, production_order_id=order.id,
                               manufactured_on=observed_at.date(), batch_ref=order.number))
    per_lot = qty / len(lots)
    for lot in lots:
        mv = post_movement(ctx, "production_output", item, per_lot, item.base_unit, lot=lot, to_bin=to_bin,
                           reference_type="production_order", reference_id=order.id, value_source=value_source,
                           observed_at=observed_at, skip_quality_gate=True)
        ctx.db.add(ProductionOutput(order_id=order.id, order_operation_id=op.id, item_id=item.id, lot_id=lot.id,
                                    quantity=per_lot, conformity=conformity, movement_id=mv.id, recorded_by=ctx.user.id,
                                    observed_at=observed_at, value_source=value_source))
        _add_edge(ctx, parent_order_id=order.id, child_lot_id=lot.id,
                  relation="rework_output" if order.kind == "rework" else "produced_by_order",
                  quantity=per_lot, unit=item.base_unit, precision="exact", source_type="stock_movement", source_id=mv.id)
    if consumed_inputs:
        by_item: dict[int, list[dict]] = defaultdict(list)
        for ci in consumed_inputs:
            in_lot = ctx.get(Lot, ci["lot_id"])
            by_item[in_lot.item_id].append({**ci, "lot": in_lot})
        for iid, entries in by_item.items():
            precision = "exact" if len(entries) == 1 else "order_level"
            for e in entries:
                for lot in lots:
                    _add_edge(ctx, parent_lot_id=e["lot"].id, child_lot_id=lot.id, relation="consumed_into",
                              quantity=q(D(e["quantity"]) / len(lots)), unit=ctx.db.get(Item, iid).base_unit,
                              precision=precision, source_type="production_order", source_id=order.id,
                              note="scanned at output" + ("" if precision == "exact" else "; several lots of this item in segment"))
    if conformity == "good":
        order.quantity_reported = q(D(order.quantity_reported) + qty)
        op.quantity_good = q(D(op.quantity_good) + qty)
    else:
        order.quantity_nonconforming = q(D(order.quantity_nonconforming) + qty)
        op.quantity_rework = q(D(op.quantity_rework) + qty)
        from ..quality.service import raise_ncr
        if nonconformance_id:
            ncr = ctx.get(Nonconformance, nonconformance_id)
            if ncr.status != "open" or ncr.production_order_id != order.id:
                raise InvalidState(f"{ncr.number} is not an open nonconformance for {order.number}")
            ncr.lot_ids = list(ncr.lot_ids) + [l.id for l in lots]
            ncr.quantity = q(D(ncr.quantity) + qty)
        else:
            raise_ncr(ctx, source="in_process", item_id=item.id, lot_ids=[l.id for l in lots], quantity=qty,
                      description=defect_description or f"Nonconforming output at {op.seq} {op.name}",
                      production_order_id=order.id)
    _event(ctx, op, "output", observed_at=observed_at, quantity=qty, value_source=value_source,
           data={"conformity": conformity, "lots": [l.lot_number for l in lots][:50]})
    return lots


def complete_operation(ctx: Ctx, op_id: int, observed_at=None, note: str | None = None) -> OrderOperation:
    op = _op(ctx, op_id)
    order = op.order
    ctx.require("production.execute", order.site_id)
    if op.status not in ("in_progress", "paused", "ready") and not (op.subcontracted and op.status == "pending"):
        raise InvalidState(f"Operation {op.seq} is {op.status}")
    if op.inspection_point:
        open_insp = ctx.db.execute(select(Inspection).where(Inspection.order_operation_id == op.id)).scalars().all()
        if not open_insp or any(i.status != "decided" and i.outcome is None for i in open_insp):
            if not open_insp or any(i.status == "open" for i in open_insp):
                raise QualityHold(f"Operation {op.seq} is an inspection point; its inspection must be decided first")
    _event(ctx, op, "complete", observed_at=observed_at, note=note)
    op.status = "completed"
    op.actual_end = observed_at or utcnow()
    nxt = [o for o in order.operations if o.seq > op.seq and o.status == "pending"]
    if nxt:
        nxt[0].status = "ready"
    if all(o.status in ("completed", "handed_over") for o in order.operations):
        order.status = "awaiting_inspection"
        refresh_order_outcomes(ctx.db, order)
    return op


def handover(ctx: Ctx, op_id: int, quantity, note: str | None = None, observed_at=None) -> OrderOperation:
    op = _op(ctx, op_id)
    ctx.require("production.execute", op.order.site_id)
    if D(quantity) > D(op.quantity_good):
        raise ValidationFailed(f"Cannot hand over {fmt(quantity)}; only {fmt(op.quantity_good)} good recorded")
    _event(ctx, op, "handover", observed_at=observed_at, quantity=quantity, note=note)
    for o in op.order.operations:
        if o.seq > op.seq and o.status == "pending":
            o.status = "ready"
            break
    return op


def raise_defect(ctx: Ctx, op_id: int, description: str, quantity, lot_ids: list[int] | None = None,
                 severity: str = "major", observed_at=None) -> Nonconformance:
    from ..quality.service import raise_ncr
    op = _op(ctx, op_id)
    ctx.require("quality.raise_ncr", op.order.site_id)
    ncr = raise_ncr(ctx, source="shop_floor", item_id=op.order.item_id, lot_ids=lot_ids or [], quantity=quantity,
                    description=description, severity=severity, production_order_id=op.order_id)
    ctx.db.add(OrderException(order_id=op.order_id, kind="defect", severity="failure",
                              description=f"{ncr.number}: {description}", raised_by=ctx.user.id))
    _event(ctx, op, "defect", observed_at=observed_at, quantity=quantity, data={"ncr": ncr.number}, note=description)
    return ncr


# --------------------------------------------------------------------------- scrap


def report_scrap(ctx: Ctx, *, order_id: int | None, op_id: int | None, item_id: int, quantity, unit: str,
                 kind: str, reason_code: str, reason: str, lot_id: int | None = None, bin_code: str | None = None,
                 recoverable: bool = False, recovered_item_id: int | None = None, recovered_quantity=None,
                 observed_at=None) -> ScrapRecord:
    ctx.require("production.execute")
    if kind not in ("material", "product"):
        raise ValidationFailed("kind must be material (input stock) or product (units in process)")
    item = ctx.get(Item, item_id)
    qty = to_base(ctx.db, item, quantity, unit)
    if kind == "material" and (lot_id is None and item.lot_or_serial_policy != "none" or not bin_code):
        raise ValidationFailed("Material scrap needs the lot and bin it is taken from")
    if recoverable and not recovered_item_id:
        recovered_item_id = item.recoverable_scrap_item_id
        if not recovered_item_id:
            raise ValidationFailed("Recoverable scrap needs a recoverable-scrap item")
    sr = ScrapRecord(number=ctx.next_number("SCR"), order_id=order_id, order_operation_id=op_id, item_id=item.id,
                     lot_id=lot_id, quantity=qty, unit=item.base_unit, kind=kind, reason_code=reason_code, reason=reason,
                     location_bin_id=bin_by_code(ctx.db, bin_code).id if bin_code else None, recoverable=recoverable,
                     recovered_item_id=recovered_item_id, recovered_quantity=D(recovered_quantity) if recovered_quantity else None,
                     reported_by=ctx.user.id, observed_at=observed_at or utcnow())
    ctx.db.add(sr)
    ctx.db.flush()
    ctx.audit("scrap.report", "scrap_record", sr.id, after=row_dict(sr))
    return sr


def authorise_scrap(ctx: Ctx, scrap_id: int, approve: bool = True, note: str | None = None) -> ScrapRecord:
    sr = ctx.get(ScrapRecord, scrap_id)
    order = ctx.db.get(ProductionOrder, sr.order_id) if sr.order_id else None
    ctx.require("production.authorise_scrap", order.site_id if order else None)
    if sr.status != "pending_authorisation":
        raise InvalidState(f"{sr.number} is {sr.status}")
    if sr.reported_by == ctx.user.id:
        raise ValidationFailed("Segregation of duties: scrap must be authorised by someone other than the reporter")
    sr.authorised_by, sr.authorised_at = ctx.user.id, utcnow()
    if not approve:
        sr.status = "rejected"
        ctx.audit("scrap.reject", "scrap_record", sr.id, reason=note)
        return sr
    item = ctx.db.get(Item, sr.item_id)
    lot = ctx.db.get(Lot, sr.lot_id) if sr.lot_id else None
    from ..costing.service import scrap_value
    sr.cost_value = scrap_value(ctx.db, sr, order)
    if sr.kind == "material":
        post_movement(ctx, "scrap", item, sr.quantity, item.base_unit, lot=lot, from_bin=ctx.db.get(Bin, sr.location_bin_id),
                      reference_type="scrap_record", reference_id=sr.id, reason_code=sr.reason_code, notes=sr.reason,
                      observed_at=sr.observed_at, skip_quality_gate=True)
        if order:
            for m in order.materials:
                if m.item_id == item.id:
                    m.quantity_scrapped = q(D(m.quantity_scrapped) + D(sr.quantity))
                    break
    elif order:
        order.quantity_scrapped = q(D(order.quantity_scrapped) + D(sr.quantity))
        if sr.order_operation_id:
            op = ctx.db.get(OrderOperation, sr.order_operation_id)
            op.quantity_scrap = q(D(op.quantity_scrap) + D(sr.quantity))
    if sr.recoverable and sr.recovered_quantity:
        ritem = ctx.db.get(Item, sr.recovered_item_id)
        rlot = create_lot(ctx, ritem, f"{sr.number}-REC", "production", quality_status="rejected",
                          production_order_id=sr.order_id,
                          traceability_note=f"Recoverable scrap from {sr.number}; not for production use")
        post_movement(ctx, "production_output", ritem, sr.recovered_quantity, ritem.base_unit, lot=rlot,
                      to_bin=bin_by_code(ctx.db, "SCR-01"), reference_type="scrap_record", reference_id=sr.id,
                      reason_code="recoverable_scrap", observed_at=sr.observed_at, value_source="measured",
                      skip_quality_gate=True)
        sr.recovered_lot_id = rlot.id
        if order:
            _add_edge(ctx, parent_order_id=order.id, child_lot_id=rlot.id, relation="produced_by_order",
                      quantity=D(sr.recovered_quantity), unit=ritem.base_unit, precision="exact",
                      source_type="scrap_record", source_id=sr.id, note="recoverable scrap")
    sr.status = "authorised"
    ctx.audit("scrap.authorise", "scrap_record", sr.id, after=row_dict(sr), reason=note)
    return sr


# --------------------------------------------------------------------------- outcomes, completion, closure


def refresh_order_outcomes(db: Session, order: ProductionOrder) -> None:
    """quantity_accepted reflects ONLY quality-released output lots."""
    rows = db.execute(select(ProductionOutput, Lot).join(Lot, Lot.id == ProductionOutput.lot_id)
                      .where(ProductionOutput.order_id == order.id)).all()
    accepted = sum((D(po.quantity) for po, lot in rows if lot.quality_status == "accepted" and po.conformity == "good"), ZERO)
    order.quantity_accepted = q(accepted)
    # a hold (quarantined) is not a final decision: only accepted or rejected output counts as decided
    pending = [lot for po, lot in rows if lot.quality_status in ("awaiting_review", "quarantined") and po.conformity == "good"]
    if order.status == "awaiting_inspection" and not pending and rows:
        order.status = "completed"
        order.completed_at = utcnow()


def close_order(ctx: Ctx, order_id: int, version: int | None) -> ProductionOrder:
    order = _order(ctx, order_id)
    ctx.require("production.close", order.site_id)
    check_version(order, version)
    refresh_order_outcomes(ctx.db, order)
    if order.status != "completed":
        raise InvalidState(f"{order.number} is {order.status}; only completed orders (all output decided) can close")
    problems = []
    for m in order.materials:
        open_qty = D(m.quantity_issued) - D(m.quantity_consumed) - D(m.quantity_returned) - D(m.quantity_scrapped)
        if open_qty != 0:
            problems.append(f"{ctx.db.get(Item, m.item_id).item_code}: {fmt(open_qty)} {m.unit} issued but not consumed/returned")
        if m.backflush and D(m.quantity_consumed_calculated) > 0:
            if not ctx.db.execute(select(BackflushReconciliation.id).where(BackflushReconciliation.order_material_id == m.id)).first():
                problems.append(f"{ctx.db.get(Item, m.item_id).item_code}: backflush not reconciled")
    pending_scrap = ctx.db.execute(select(ScrapRecord.id).where(ScrapRecord.order_id == order.id,
                                                                ScrapRecord.status == "pending_authorisation")).first()
    if pending_scrap:
        problems.append("scrap awaiting authorisation")
    if problems:
        raise InvalidState("Cannot close: " + "; ".join(problems), details=problems)
    for m in order.materials:
        for r in ctx.db.execute(select(Reservation).where(Reservation.demand_type == "production_material",
                                                          Reservation.demand_id == m.id, Reservation.status == "active")).scalars():
            release_reservation(ctx, r, f"{order.number} closed")
    from ..costing.service import finalise_order_cost
    finalise_order_cost(ctx, order)
    order.status, order.closed_by, order.closed_at = "closed", ctx.user.id, utcnow()
    ctx.audit("order.close", "production_order", order.id, site_id=order.site_id)
    return order


def line_side_stock(db: Session, order: ProductionOrder) -> list[dict]:
    """Stock issued to this order that is still physically at line-side or at a subcontractor."""
    out = []
    for m in order.materials:
        issued = db.execute(select(StockMovement.lot_id, StockMovement.to_bin_id, func.sum(StockMovement.quantity))
                            .where(StockMovement.reference_type == "production_order", StockMovement.reference_id == order.id,
                                   StockMovement.reference_line_id == m.id, StockMovement.movement_type.in_(("issue",)))
                            .group_by(StockMovement.lot_id, StockMovement.to_bin_id)).all()
        for lot_id, bin_id, _ in issued:
            remaining = lot_on_hand(db, lot_id, bin_id)
            if remaining > 0:
                out.append({"material_id": m.id, "lot_id": lot_id, "bin_id": bin_id, "quantity": remaining})
    return out


def cancel_order(ctx: Ctx, order_id: int, version: int | None, reason: str,
                 dispositions: list[dict] | None = None) -> ProductionOrder:
    """Controlled cancellation. For partially executed orders every quantity of issued-but-unused
    material must be dispositioned: {"material_id","lot_id","action": return|scrap,"quantity","to_bin_code"}."""
    order = _order(ctx, order_id)
    ctx.require("production.cancel", order.site_id)
    check_version(order, version)
    if order.status in ("completed", "closed", "cancelled", "awaiting_inspection"):
        raise InvalidState(f"{order.number} is {order.status} and cannot be cancelled")
    if not reason:
        raise ValidationFailed("Cancellation requires a reason")
    outstanding = line_side_stock(ctx.db, order)
    dispositions = dispositions or []
    covered: dict[tuple, Decimal] = defaultdict(Decimal)
    for d in dispositions:
        covered[(d["material_id"], d["lot_id"])] += D(d["quantity"])
    missing = [o for o in outstanding if covered.get((o["material_id"], o["lot_id"]), ZERO) != o["quantity"]]
    if missing:
        raise ValidationFailed(
            "Partially executed order: disposition all unused line-side material before cancelling",
            details=[{**m, "quantity": str(m["quantity"]), "lot": ctx.db.get(Lot, m["lot_id"]).lot_number} for m in missing],
        )
    for d in dispositions:
        o = next(x for x in outstanding if x["material_id"] == d["material_id"] and x["lot_id"] == d["lot_id"])
        src = ctx.db.get(Bin, o["bin_id"])
        if d["action"] == "return":
            return_material(ctx, d["material_id"], d["lot_id"], d["quantity"], from_bin_code=src.code,
                            to_bin_code=d["to_bin_code"], reason="order_cancelled")
        elif d["action"] == "scrap":
            m = ctx.db.get(OrderMaterial, d["material_id"])
            sr = report_scrap(ctx, order_id=order.id, op_id=None, item_id=m.item_id, quantity=d["quantity"], unit=m.unit,
                              kind="material", reason_code="order_cancelled", reason=reason, lot_id=d["lot_id"], bin_code=src.code)
            sr.status = "pending_authorisation"
        else:
            raise ValidationFailed("action must be return or scrap")
    for m in order.materials:
        for r in ctx.db.execute(select(Reservation).where(Reservation.demand_type == "production_material",
                                                          Reservation.demand_id == m.id, Reservation.status == "active")).scalars():
            release_reservation(ctx, r, f"{order.number} cancelled: {reason}")
    executed = any(D(m.quantity_consumed) > 0 for m in order.materials) or D(order.quantity_reported) > 0
    order.status, order.cancel_reason = "cancelled", reason
    ctx.audit("order.cancel", "production_order", order.id, reason=reason,
              after={"partially_executed": executed, "dispositions": dispositions})
    return order


# --------------------------------------------------------------------------- rework


def create_rework_order(ctx: Ctx, ncr_id: int, *, instructions: str, additional_materials: list[dict] | None = None,
                        due_date: date | None = None, on: date | None = None) -> ProductionOrder:
    """Rework is linked work: approved rework routing, extra materials, cost and re-inspection."""
    ctx.require("production.rework")
    ncr = ctx.get(Nonconformance, ncr_id)
    if ncr.disposition != "rework":
        raise InvalidState(f"{ncr.number} has not been dispositioned for rework")
    if ncr.linked_order_id:
        raise InvalidState(f"{ncr.number} already has rework order")
    routing = effective_routing(ctx.db, ncr.item_id, on, kind="rework")
    if routing is None:
        raise ValidationFailed("No approved rework routing (instructions) exists for this item")
    if not any(o.inspection_point for o in routing.operations):
        raise ValidationFailed("Rework routing must include an inspection point")
    parent = ctx.db.get(ProductionOrder, ncr.production_order_id) if ncr.production_order_id else None
    order = ProductionOrder(
        number=ctx.next_number("MO"), site_id=parent.site_id if parent else ctx.site_id, kind="rework", item_id=ncr.item_id,
        quantity_target=D(ncr.quantity), quantity_start=D(ncr.quantity), status="draft", routing_id=routing.id,
        routing_version=routing.version, due_date=due_date, parent_order_id=parent.id if parent else None,
        nonconformance_id=ncr.id, rework_instructions=instructions, created_by=ctx.user.id, source="manual",
    )
    ctx.db.add(order)
    ctx.db.flush()
    for i, am in enumerate(additional_materials or []):
        it = ctx.get(Item, am["item_id"])
        order.materials.append(OrderMaterial(line_no=900 + i, item_id=it.id, required_quantity=to_base(ctx.db, it, am["quantity"], am["unit"]),
                                             unit=it.base_unit, operation_seq=am.get("operation_seq"), additional=True,
                                             is_packaging=it.item_type == "packaging"))
    ctx.db.flush()
    ncr.linked_order_id = order.id
    ctx.audit("order.create_rework", "production_order", order.id, after={"ncr": ncr.number, "instructions": instructions})
    return order


def issue_for_rework(ctx: Ctx, order_id: int, lot_ids: list[int], *, from_bin_code: str, to_bin_code: str,
                     observed_at=None) -> None:
    """Move nonconforming units into rework. Allowed only for lots listed on the order's NCR."""
    order = _order(ctx, order_id)
    ctx.require("production.execute", order.site_id)
    if order.kind != "rework" or order.status not in ACTIVE:
        raise InvalidState("Not an active rework order")
    ncr = ctx.db.get(Nonconformance, order.nonconformance_id)
    for lid in lot_ids:
        if lid not in ncr.lot_ids:
            raise QualityHold("Lot is not covered by the rework disposition")
        lot = ctx.db.get(Lot, lid)
        item = ctx.db.get(Item, lot.item_id)
        mv = post_movement(ctx, "transfer", item, lot_on_hand(ctx.db, lot.id, bin_by_code(ctx.db, from_bin_code).id), item.base_unit,
                           lot=lot, from_bin=bin_by_code(ctx.db, from_bin_code), to_bin=bin_by_code(ctx.db, to_bin_code),
                           reference_type="production_order", reference_id=order.id, reason_code="rework",
                           observed_at=observed_at, skip_quality_gate=True)
        _add_edge(ctx, parent_lot_id=lot.id, child_order_id=order.id, relation="rework_input", quantity=mv.quantity,
                  unit=item.base_unit, precision="exact", source_type="stock_movement", source_id=mv.id)


def report_rework_output(ctx: Ctx, order_id: int, op_id: int, lot_ids: list[int], *, from_bin_code: str,
                         to_bin_code: str, observed_at=None) -> list[Lot]:
    """Reworked units keep their identity; they return to awaiting_review for re-inspection."""
    order = _order(ctx, order_id)
    op = _op(ctx, op_id)
    ctx.require("production.execute", order.site_id)
    if order.kind != "rework":
        raise InvalidState("Not a rework order")
    lots = []
    for lid in lot_ids:
        lot = ctx.get(Lot, lid)
        item = ctx.db.get(Item, lot.item_id)
        mv = post_movement(ctx, "transfer", item, 1 if lot.is_serial else lot_on_hand(ctx.db, lot.id, bin_by_code(ctx.db, from_bin_code).id),
                           item.base_unit, lot=lot, from_bin=bin_by_code(ctx.db, from_bin_code), to_bin=bin_by_code(ctx.db, to_bin_code),
                           reference_type="production_order", reference_id=order.id, reason_code="rework_complete",
                           observed_at=observed_at, skip_quality_gate=True)
        set_lot_status(ctx, lot, "awaiting_review", f"Reworked under {order.number}; awaiting re-inspection",
                       "production_order", order.id, system=True)
        ctx.db.add(ProductionOutput(order_id=order.id, order_operation_id=op.id, item_id=item.id, lot_id=lot.id,
                                    quantity=mv.quantity, conformity="good", movement_id=mv.id, recorded_by=ctx.user.id,
                                    observed_at=observed_at or utcnow()))
        _add_edge(ctx, parent_order_id=order.id, child_lot_id=lot.id, relation="rework_output", quantity=mv.quantity,
                  unit=item.base_unit, precision="exact", source_type="stock_movement", source_id=mv.id)
        order.quantity_reported = q(D(order.quantity_reported) + mv.quantity)
        op.quantity_good = q(D(op.quantity_good) + mv.quantity)
        lots.append(lot)
    return lots


# --------------------------------------------------------------------------- subcontracting


def send_to_subcontractor(ctx: Ctx, order_id: int, op_id: int, lines: list[dict], *, po_id: int | None = None,
                          documents: list[dict] | None = None, observed_at=None) -> SubcontractShipment:
    """Ship company-owned material to a subcontractor. It stays visible in inventory at the
    subcontractor's bin (ownership: company)."""
    order = _order(ctx, order_id)
    op = _op(ctx, op_id)
    _require_any(ctx, ("production.execute", "inventory.move"), order.site_id)
    if not op.subcontracted:
        raise ValidationFailed("Operation is not subcontracted")
    if order.status not in ACTIVE:
        raise InvalidState(f"{order.number} is {order.status}")
    from ..inventory.models import Warehouse
    wh = ctx.db.execute(select(Warehouse).where(Warehouse.supplier_id == op.subcontract_supplier_id,
                                                Warehouse.kind == "subcontractor")).scalar_one_or_none()
    if wh is None:
        raise ValidationFailed("No subcontractor stock location is configured for this supplier")
    sub_bin = ctx.db.execute(select(Bin).where(Bin.warehouse_id == wh.id)).scalars().first()
    observed_at = observed_at or utcnow()
    sent, total = [], ZERO
    for l in lines:
        mv = issue_material(ctx, l["material_id"], l["lot_id"], l["quantity"], to_bin_code=sub_bin.code,
                            observed_at=observed_at)
        sent.append({"material_id": l["material_id"], "lot_id": l["lot_id"], "quantity": str(mv.quantity),
                     "lot": ctx.db.get(Lot, l["lot_id"]).lot_number})
        total += D(l["quantity"])
    sh = SubcontractShipment(number=ctx.next_number("SCS"), order_id=order.id, order_operation_id=op.id,
                             supplier_id=op.subcontract_supplier_id, po_id=po_id, sent_at=observed_at, sent_lines=sent,
                             quantity_sent=total, supplier_documents=documents or [], created_by=ctx.user.id)
    ctx.db.add(sh)
    op.status = "in_progress"
    op.actual_start = op.actual_start or observed_at
    if order.status == "released":
        order.status = "in_progress"
    _event(ctx, op, "start", observed_at=observed_at, quantity=total, data={"subcontract_shipment": sh.number})
    ctx.db.flush()
    ctx.audit("subcontract.send", "subcontract_shipment", sh.id, after=row_dict(sh))
    return sh


def receive_from_subcontractor(ctx: Ctx, shipment_id: int, *, quantity_returned, quantity_lost=0,
                               loss_explanation: str | None = None, lot_number: str | None = None,
                               supplier_documents: list[dict] | None = None, receiving_bin_code: str = "RCV-01",
                               observed_at=None) -> Lot:
    """Subcontracted work comes back as the order's output item, awaiting incoming inspection.
    Sent material is consumed at the subcontractor's location; losses are recorded explicitly."""
    sh = ctx.get(SubcontractShipment, shipment_id)
    order = ctx.db.get(ProductionOrder, sh.order_id)
    op = ctx.db.get(OrderOperation, sh.order_operation_id)
    ctx.require("purchasing.receive", order.site_id)
    if sh.status not in ("sent", "partially_returned"):
        raise InvalidState(f"{sh.number} is {sh.status}")
    returned, lost = D(quantity_returned), D(quantity_lost)
    if returned + lost > D(sh.quantity_sent) - D(sh.quantity_returned) - D(sh.quantity_lost):
        raise ValidationFailed("Returned + lost exceeds quantity still at the subcontractor")
    if lost > 0 and not loss_explanation:
        raise ValidationFailed("Losses at the subcontractor need an explanation")
    observed_at = observed_at or utcnow()
    from ..inventory.models import Warehouse
    wh = ctx.db.execute(select(Warehouse).where(Warehouse.supplier_id == sh.supplier_id, Warehouse.kind == "subcontractor")).scalar_one()
    sub_bin = ctx.db.execute(select(Bin).where(Bin.warehouse_id == wh.id)).scalars().first()
    # consume the sent material at the subcontractor, lot by lot
    to_consume = returned + lost
    for line in sh.sent_lines:
        if to_consume <= 0:
            break
        here = lot_on_hand(ctx.db, line["lot_id"], sub_bin.id)
        take = min(here, to_consume)
        if take > 0:
            record_consumption(ctx, line["material_id"], line["lot_id"], take, from_bin_code=sub_bin.code,
                               value_source="manual", observed_at=observed_at, note=f"processed at subcontractor ({sh.number})",
                               _caller_checked=True)
            to_consume -= take
    item = ctx.db.get(Item, order.item_id)
    lot = create_lot(ctx, item, lot_number or f"{order.number}-S{ctx.next_number('SB', 3).split('-')[1]}", "subcontract",
                     quality_status="awaiting_review", production_order_id=order.id, supplier_id=sh.supplier_id,
                     manufactured_on=observed_at.date(), batch_ref=order.number,
                     attributes={"subcontract_shipment": sh.number, "subcontract_po_id": sh.po_id})
    mv = post_movement(ctx, "subcontract_return", item, returned, item.base_unit, lot=lot,
                       to_bin=bin_by_code(ctx.db, receiving_bin_code), reference_type="production_order",
                       reference_id=order.id, observed_at=observed_at, skip_quality_gate=True)
    ctx.db.add(ProductionOutput(order_id=order.id, order_operation_id=op.id, item_id=item.id, lot_id=lot.id,
                                quantity=returned, conformity="good", movement_id=mv.id, recorded_by=ctx.user.id,
                                observed_at=observed_at))
    _add_edge(ctx, parent_order_id=order.id, child_lot_id=lot.id, relation="subcontract_output", quantity=returned,
              unit=item.base_unit, precision="exact", source_type="subcontract_shipment", source_id=sh.id)
    for line in sh.sent_lines:
        _add_edge(ctx, parent_lot_id=line["lot_id"], child_lot_id=lot.id, relation="consumed_into",
                  quantity=q(D(line["quantity"]) * returned / D(sh.quantity_sent)), unit=item.base_unit,
                  precision="exact" if len(sh.sent_lines) == 1 else "order_level", source_type="subcontract_shipment",
                  source_id=sh.id, note="returned from subcontractor")
    sh.quantity_returned = q(D(sh.quantity_returned) + returned)
    sh.quantity_lost = q(D(sh.quantity_lost) + lost)
    sh.loss_explanation = loss_explanation or sh.loss_explanation
    sh.supplier_documents = (sh.supplier_documents or []) + (supplier_documents or [])
    sh.returned_at = observed_at
    sh.status = "returned" if D(sh.quantity_returned) + D(sh.quantity_lost) >= D(sh.quantity_sent) else "partially_returned"
    order.quantity_reported = q(D(order.quantity_reported) + returned)
    op.quantity_good = q(D(op.quantity_good) + returned)
    op.quantity_scrap = q(D(op.quantity_scrap) + lost)
    order.quantity_scrapped = q(D(order.quantity_scrapped) + lost)
    if sh.po_id:
        from ..purchasing.models import PurchaseOrder
        po = ctx.db.get(PurchaseOrder, sh.po_id)
        for pl in po.lines:
            if pl.production_order_id == order.id:
                pl.quantity_received = q(D(pl.quantity_received) + returned)
                if pl.quantity_received >= pl.quantity_ordered:
                    pl.status = "received"
                elif sh.status == "returned" and D(pl.quantity_received) + D(sh.quantity_lost) >= D(pl.quantity_ordered):
                    pl.status = "closed"  # shortfall explained by recorded subcontractor losses; nothing more is due
                else:
                    pl.status = "partially_received"
                lot.attributes = {**lot.attributes, "subcontract_po_line_id": pl.id}
        po.status = "received" if all(l.status in ("received", "closed") for l in po.lines) else "partially_received"
    from ..quality.service import open_inspection
    open_inspection(ctx, "incoming", item, [lot])
    if sh.status == "returned":
        _event(ctx, op, "complete", observed_at=observed_at, quantity=returned,
               data={"lost": str(lost), "shipment": sh.number})
        op.status, op.actual_end = "completed", observed_at
        if all(o.status == "completed" for o in order.operations):
            order.status = "awaiting_inspection"
    ctx.audit("subcontract.receive", "subcontract_shipment", sh.id, after=row_dict(sh))
    return lot


# --------------------------------------------------------------------------- time intervals and detail


def time_intervals(db: Session, op: OrderOperation) -> list[dict]:
    """Labour and machine intervals derived from events. Several operators/machines may work an
    operation in parallel: each (operator, equipment) pair has its own interval; a pause closes that
    operator's intervals and completion closes all. Booked minutes are clipped to the work centre's
    shift calendar, so time outside shifts is not charged; elapsed minutes are reported alongside."""
    from ..planning.calendar import minutes as _mins, working_intervals

    wc = db.get(WorkCentre, op.work_centre_id)
    events = db.execute(select(OperationEvent).where(OperationEvent.order_operation_id == op.id)
                        .order_by(OperationEvent.observed_at, OperationEvent.id)).scalars().all()
    out: list[dict] = []
    open_: dict[tuple, OperationEvent] = {}

    def close(ev: OperationEvent, end: datetime) -> dict:
        iv = _interval(ev, end)
        if wc and wc.calendar and end > ev.observed_at:
            iv["minutes"] = q(Decimal(str(_mins(working_intervals(wc.calendar, wc.holidays, ev.observed_at, end)))))
        return iv

    for e in events:
        if e.event == "start":
            key = (e.operator_user_id, e.equipment_id)
            if key in open_:
                out.append(close(open_.pop(key), e.observed_at))
            open_[key] = e
        elif e.event == "pause":
            for key in [k for k in open_ if k[0] == e.operator_user_id]:
                out.append(close(open_.pop(key), e.observed_at))
        elif e.event == "complete":
            for key in list(open_):
                out.append(close(open_.pop(key), e.observed_at))
    for ev in open_.values():
        out.append({**_interval(ev, ev.observed_at), "open": True})
    return out


def open_work(db: Session, op: OrderOperation) -> int:
    return sum(1 for i in time_intervals(db, op) if i.get("open"))


def _interval(start_ev: OperationEvent, end: datetime) -> dict:
    minutes = q(D((end - start_ev.observed_at).total_seconds()) / 60)
    return {"operator_user_id": start_ev.operator_user_id, "equipment_id": start_ev.equipment_id,
            "phase": (start_ev.data or {}).get("phase", "run"), "start": start_ev.observed_at, "end": end,
            "minutes": minutes, "elapsed_minutes": minutes}


def order_detail(db: Session, order: ProductionOrder) -> dict:
    d = row_dict(order)
    item = db.get(Item, order.item_id)
    d["item_code"], d["item_description"] = item.item_code, item.description
    d["materials"] = []
    for m in order.materials:
        md = row_dict(m)
        it = db.get(Item, m.item_id)
        md["item_code"], md["description"] = it.item_code, it.description
        md["reserved"] = str(material_reserved(db, m))
        d["materials"].append(md)
    d["operations"] = []
    for o in order.operations:
        od = row_dict(o)
        od["work_centre"] = db.get(WorkCentre, o.work_centre_id).code
        od["time"] = [{**{k: (str(v) if isinstance(v, Decimal) else v.isoformat() if isinstance(v, datetime) else v)
                          for k, v in t.items()}} for t in time_intervals(db, o)]
        d["operations"].append(od)
    d["outputs"] = [{**row_dict(po), "lot_number": db.get(Lot, po.lot_id).lot_number,
                     "quality_status": db.get(Lot, po.lot_id).quality_status}
                    for po in db.execute(select(ProductionOutput).where(ProductionOutput.order_id == order.id)).scalars()]
    d["scrap"] = [row_dict(s) for s in db.execute(select(ScrapRecord).where(ScrapRecord.order_id == order.id)).scalars()]
    d["exceptions"] = [row_dict(e) for e in db.execute(select(OrderException).where(OrderException.order_id == order.id)).scalars()]
    d["shortages"] = shortages(db, order)
    d["consumption"] = [
        {**row_dict(mv, ["movement_no", "lot_id", "quantity", "value_source", "observed_at", "recorded_at", "reference_line_id", "notes"]),
         "lot_number": db.get(Lot, mv.lot_id).lot_number if mv.lot_id else None,
         "item_code": db.get(Item, mv.item_id).item_code}
        for mv in db.execute(select(StockMovement).where(StockMovement.reference_type == "production_order",
                                                         StockMovement.reference_id == order.id,
                                                         StockMovement.movement_type == "consumption")
                             .order_by(StockMovement.id)).scalars()
    ]
    d["status_explanation"] = {
        "operations_complete": all(o.status in ("completed", "handed_over") for o in order.operations),
        "output_reported": str(order.quantity_reported), "output_accepted_by_quality": str(order.quantity_accepted),
        "closed": order.status == "closed",
        "note": "Operation completion, quality-accepted output and order closure are recorded separately.",
    }
    return d
