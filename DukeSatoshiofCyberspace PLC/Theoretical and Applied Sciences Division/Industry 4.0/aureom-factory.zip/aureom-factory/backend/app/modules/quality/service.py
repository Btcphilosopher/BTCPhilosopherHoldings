"""Quality services.

* Inspectors RECORD results; only authorised quality staff DECIDE (release / reject) and DISPOSITION.
* Results are append-only; corrections are new rows that supersede earlier rows.
* A result taken with a gauge whose calibration was not valid on the observation date is kept
  but cannot support an acceptance.
* Passing checks never sets any certification.
"""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...core.context import Ctx, row_dict, utcnow
from ...core.errors import InvalidState, NotFound, QualityHold, ValidationFailed
from ...core.numbers import D, ZERO
from ..inventory.models import Lot
from ..inventory.service import lot_on_hand, set_lot_status
from ..maintenance.models import CalibrationRecord, Equipment
from ..registry.models import Item
from .models import CorrectiveAction, Inspection, InspectionPlan, InspectionResult, Nonconformance, SamplingPlan


def sample_size(plan: SamplingPlan, lot_qty: Decimal) -> tuple[int, int]:
    n = int(D(lot_qty))
    if plan.kind == "full":
        return n, 0
    for band in plan.bands:
        if band.get("max_lot") is None or n <= band["max_lot"]:
            return min(n, band["sample"]), band.get("accept", 0)
    last = plan.bands[-1]
    return min(n, last["sample"]), last.get("accept", 0)


def plan_for(db: Session, item_id: int, stage: str, code: str | None = None) -> InspectionPlan | None:
    stmt = select(InspectionPlan).where(InspectionPlan.item_id == item_id, InspectionPlan.stage == stage,
                                        InspectionPlan.active.is_(True))
    if code:
        stmt = select(InspectionPlan).where(InspectionPlan.code == code)
    return db.execute(stmt).scalars().first()


def open_inspection(ctx: Ctx, stage: str, item: Item, lots: list[Lot], *, plan: InspectionPlan | None = None,
                    lot_quantity=None, receipt_line_id=None, production_order_id=None, order_operation_id=None) -> Inspection:
    plan = plan or plan_for(ctx.db, item.id, stage)
    qty = D(lot_quantity) if lot_quantity is not None else sum((lot_on_hand(ctx.db, l.id) for l in lots), ZERO)
    n, acc = (0, 0)
    if plan:
        n, acc = sample_size(ctx.db.get(SamplingPlan, plan.sampling_plan_id), qty)
    insp = Inspection(number=ctx.next_number("INS"), stage=stage, item_id=item.id, lot_ids=[l.id for l in lots],
                      plan_id=plan.id if plan else None, receipt_line_id=receipt_line_id,
                      production_order_id=production_order_id, order_operation_id=order_operation_id,
                      lot_quantity=qty, sample_size=n, accept_number=acc)
    ctx.db.add(insp)
    ctx.db.flush()
    ctx.emit("quality.inspection_opened", {"number": insp.number, "stage": stage, "item": item.item_code})
    return insp


def open_incoming_inspection(ctx: Ctx, lot: Lot, receipt_line) -> Inspection:
    item = ctx.db.get(Item, lot.item_id)
    return open_inspection(ctx, "incoming", item, [lot], receipt_line_id=receipt_line.id)


def _characteristic(plan: InspectionPlan | None, name: str) -> dict:
    if plan is None:
        return {"name": name, "kind": "attribute"}
    for c in plan.characteristics:
        if c["name"] == name:
            return c
    raise ValidationFailed(f"Characteristic '{name}' is not in plan {plan.code}")


def calibration_status(db: Session, equipment: Equipment, on: date) -> tuple[bool, str | None]:
    if not equipment.calibration_required:
        return True, None
    rec = db.execute(
        select(CalibrationRecord).where(CalibrationRecord.equipment_id == equipment.id,
                                        CalibrationRecord.calibrated_on <= on)
        .order_by(CalibrationRecord.calibrated_on.desc())
    ).scalars().first()
    if rec is None:
        return False, None
    return (rec.result in ("pass", "adjusted") and rec.due_on >= on), rec.certificate_ref


def record_result(ctx: Ctx, inspection_id: int, characteristic: str, *, numeric_value=None, text_value=None,
                  conforms: bool | None = None, sample_ref: str | None = None, value_source: str = "manual",
                  equipment_code: str | None = None, observed_at: datetime | None = None,
                  _supersedes: InspectionResult | None = None, _reason: str | None = None) -> InspectionResult:
    ctx.require("quality.record")
    insp = ctx.get(Inspection, inspection_id)
    if insp.status == "decided":
        raise InvalidState(f"Inspection {insp.number} has been decided; use a correction instead")
    if value_source not in ("measured", "manual", "calculated"):
        raise ValidationFailed("value_source must be measured, manual or calculated")
    plan = ctx.db.get(InspectionPlan, insp.plan_id) if insp.plan_id else None
    ch = _characteristic(plan, characteristic)
    observed_at = observed_at or utcnow()
    eq, cal_ok, cal_ref = None, None, None
    if equipment_code:
        eq = ctx.db.execute(select(Equipment).where(Equipment.code == equipment_code)).scalar_one_or_none()
        if eq is None:
            raise NotFound(f"Equipment {equipment_code} not found")
        cal_ok, cal_ref = calibration_status(ctx.db, eq, observed_at.date())
    elif ch.get("gauge_kind") and value_source == "measured":
        raise ValidationFailed(f"'{characteristic}' requires the measuring equipment to be identified")
    if ch.get("kind") == "variable":
        if numeric_value is None:
            raise ValidationFailed(f"'{characteristic}' needs a numeric value")
        v = D(numeric_value)
        lo, hi = ch.get("lower"), ch.get("upper")
        computed = (lo is None or v >= D(lo)) and (hi is None or v <= D(hi))
        if conforms is not None and conforms != computed:
            raise ValidationFailed("Stated conformity contradicts the specification limits")
        conforms = computed
    elif conforms is None:
        raise ValidationFailed(f"'{characteristic}' is an attribute check; state whether it conforms")
    res = InspectionResult(
        inspection_id=insp.id, characteristic=characteristic, sample_ref=sample_ref,
        numeric_value=D(numeric_value) if numeric_value is not None else None, text_value=text_value,
        unit=ch.get("unit"), conforms=bool(conforms), value_source=value_source,
        equipment_id=eq.id if eq else None, calibration_ref=cal_ref, calibration_valid=cal_ok,
        observed_at=observed_at, recorded_by=ctx.user.id,
        supersedes_result_id=_supersedes.id if _supersedes else None, correction_reason=_reason,
    )
    ctx.db.add(res)
    ctx.db.flush()
    return res


def correct_result(ctx: Ctx, result_id: int, reason: str, **values) -> InspectionResult:
    """Correct a result. The original row remains; the new row records why it was superseded."""
    ctx.require("quality.correct")
    orig = ctx.get(InspectionResult, result_id)
    if not reason:
        raise ValidationFailed("A correction needs a reason")
    if ctx.db.execute(select(InspectionResult.id).where(InspectionResult.supersedes_result_id == orig.id)).scalar():
        raise InvalidState("That result has already been corrected; correct the latest version")
    insp = ctx.db.get(Inspection, orig.inspection_id)
    if insp.status == "decided":
        raise InvalidState("Inspection already decided; raise a nonconformance or reopen through quality management")
    eq = ctx.db.get(Equipment, orig.equipment_id) if orig.equipment_id else None
    return record_result(
        ctx, orig.inspection_id, orig.characteristic, sample_ref=orig.sample_ref,
        equipment_code=values.pop("equipment_code", eq.code if eq else None),
        observed_at=values.pop("observed_at", orig.observed_at), value_source=values.pop("value_source", orig.value_source),
        _supersedes=orig, _reason=reason, **values,
    )


def all_results(db: Session, insp: Inspection) -> list[InspectionResult]:
    return list(db.execute(select(InspectionResult).where(InspectionResult.inspection_id == insp.id)
                           .order_by(InspectionResult.id)).scalars())


def effective_results(db: Session, insp: Inspection) -> list[InspectionResult]:
    rows = all_results(db, insp)
    superseded = {r.supersedes_result_id for r in rows if r.supersedes_result_id}
    return [r for r in rows if r.id not in superseded]


def evaluate(db: Session, insp: Inspection) -> dict:
    plan = db.get(InspectionPlan, insp.plan_id) if insp.plan_id else None
    results = effective_results(db, insp)
    issues, per_char = [], {}
    chars = plan.characteristics if plan else [{"name": r.characteristic} for r in results]
    for ch in chars:
        rs = [r for r in results if r.characteristic == ch["name"]]
        required = 1 if ch.get("kind") == "document" else max(insp.sample_size, 1)
        defects = sum(1 for r in rs if not r.conforms)
        invalid_cal = sum(1 for r in rs if r.calibration_valid is False)
        per_char[ch["name"]] = {"recorded": len(rs), "required": required, "nonconforming": defects,
                                "invalid_calibration": invalid_cal}
        if len(rs) < required:
            issues.append(f"{ch['name']}: {len(rs)}/{required} results recorded")
        if invalid_cal:
            issues.append(f"{ch['name']}: {invalid_cal} result(s) taken with equipment outside calibration")
    total_defects = sum(v["nonconforming"] for v in per_char.values())
    complete = not any("results recorded" in i for i in issues)
    cert_missing = False
    if insp.receipt_line_id:
        from ..purchasing.models import ReceiptLine
        rl = db.get(ReceiptLine, insp.receipt_line_id)
        cert_missing = rl.certificate_status == "missing"
        if cert_missing:
            issues.append("Required supplier certificate has not been received")
    conforming = complete and total_defects <= insp.accept_number and not any("calibration" in i for i in issues) and not cert_missing
    return {
        "complete": complete, "defects": total_defects, "accept_number": insp.accept_number,
        "sample_size": insp.sample_size, "conforming": conforming, "issues": issues, "characteristics": per_char,
        "certification_note": "Conforming inspection results do not constitute product certification.",
    }


def decide(ctx: Ctx, inspection_id: int, decision: str, note: str, *, decided_at: datetime | None = None) -> Inspection:
    """Release (accepted), reject, or hold (quarantined) the inspected lots."""
    insp = ctx.get(Inspection, inspection_id)
    perm = {"accepted": "quality.release", "rejected": "quality.disposition", "quarantined": "quality.record"}.get(decision)
    if perm is None:
        raise ValidationFailed("decision must be accepted, rejected or quarantined")
    ctx.require(perm)
    if insp.status == "decided":
        raise InvalidState(f"Inspection {insp.number} already decided ({insp.decision})")
    ev = evaluate(ctx.db, insp)
    if decision == "accepted" and not ev["conforming"]:
        raise QualityHold("Cannot release: " + ("; ".join(ev["issues"]) or f"{ev['defects']} nonconforming results"),
                          details=ev)
    if decision == "accepted" and insp.plan_id is None:
        raise QualityHold("Cannot release without an inspection plan defining what was checked")
    insp.outcome = "conforming" if ev["conforming"] else "nonconforming"
    insp.status, insp.decision, insp.decided_by = "decided", decision, ctx.user.id
    insp.decided_at, insp.decision_note = decided_at or utcnow(), note
    from ..purchasing.service import record_lot_decision

    for lid in insp.lot_ids:
        lot = ctx.db.get(Lot, lid)
        set_lot_status(ctx, lot, decision, f"Inspection {insp.number}: {note}", "inspection", insp.id)
        if insp.stage == "incoming":
            qty = lot_on_hand(ctx.db, lot.id)
            record_lot_decision(ctx.db, lot, qty if decision == "accepted" else ZERO,
                                qty if decision == "rejected" else ZERO)
    _refresh_orders(ctx.db, insp.lot_ids)
    if decision == "rejected":
        existing = ctx.db.execute(select(Nonconformance).where(Nonconformance.inspection_id == insp.id)).scalar_one_or_none()
        if existing is None:
            raise_ncr(ctx, source=insp.stage if insp.stage in ("incoming", "in_process", "final") else "in_process",
                      item_id=insp.item_id, lot_ids=insp.lot_ids, quantity=insp.lot_quantity,
                      description=f"Rejected at inspection {insp.number}: {note}", inspection_id=insp.id,
                      production_order_id=insp.production_order_id, _skip_perm=True)
    ctx.audit("inspection.decide", "inspection", insp.id, after={"decision": decision, "evaluation": ev}, reason=note)
    ctx.emit("quality.decision", {"inspection": insp.number, "decision": decision})
    return insp


def _refresh_orders(db: Session, lot_ids: list[int]) -> None:
    """Keep production orders' accepted quantity and completion status in step with quality decisions."""
    from ..production.models import ProductionOrder, ProductionOutput
    from ..production.service import refresh_order_outcomes

    db.flush()
    order_ids = set(db.execute(select(ProductionOutput.order_id).where(ProductionOutput.lot_id.in_(lot_ids))).scalars()) if lot_ids else set()
    for oid in order_ids:
        refresh_order_outcomes(db, db.get(ProductionOrder, oid))


# --------------------------------------------------------------------------- nonconformance


def raise_ncr(ctx: Ctx, *, source: str, item_id: int, lot_ids: list[int], quantity, description: str,
              severity: str = "major", inspection_id=None, production_order_id=None, supplier_id=None,
              _skip_perm: bool = False) -> Nonconformance:
    if not _skip_perm:
        ctx.require("quality.raise_ncr")
    if supplier_id is None and lot_ids:
        supplier_id = ctx.db.get(Lot, lot_ids[0]).supplier_id
    ncr = Nonconformance(number=ctx.next_number("NCR"), source=source, severity=severity, item_id=item_id,
                         lot_ids=lot_ids, quantity=D(quantity), description=description, inspection_id=inspection_id,
                         production_order_id=production_order_id, supplier_id=supplier_id, raised_by=ctx.user.id)
    ctx.db.add(ncr)
    ctx.db.flush()
    for lid in lot_ids:
        lot = ctx.db.get(Lot, lid)
        if lot.quality_status == "accepted":
            set_lot_status(ctx, lot, "quarantined", f"{ncr.number}: {description}", "nonconformance", ncr.id, system=True)
    ctx.audit("ncr.raise", "nonconformance", ncr.id, after=row_dict(ncr))
    ctx.emit("quality.ncr", {"number": ncr.number, "severity": severity, "description": description})
    return ncr


DISPOSITIONS = ("use_as_is", "rework", "scrap", "return_to_supplier")


def disposition_ncr(ctx: Ctx, ncr_id: int, disposition: str, note: str) -> Nonconformance:
    ctx.require("quality.disposition")
    ncr = ctx.get(Nonconformance, ncr_id)
    if ncr.status != "open":
        raise InvalidState(f"{ncr.number} is {ncr.status}")
    if disposition not in DISPOSITIONS:
        raise ValidationFailed(f"disposition must be one of {DISPOSITIONS}")
    if not note:
        raise ValidationFailed("A disposition needs a justification")
    ncr.disposition, ncr.disposition_note = disposition, note
    ncr.disposition_by, ncr.disposition_at, ncr.status = ctx.user.id, utcnow(), "dispositioned"
    for lid in ncr.lot_ids:
        lot = ctx.db.get(Lot, lid)
        if disposition == "use_as_is":
            ctx.require("quality.release")
            set_lot_status(ctx, lot, "accepted", f"Concession under {ncr.number}: {note}", "nonconformance", ncr.id)
        else:
            was = lot.quality_status
            set_lot_status(ctx, lot, "rejected", f"{ncr.number} disposition {disposition}: {note}", "nonconformance", ncr.id)
            if ncr.source == "incoming" and was != "rejected" and ncr.inspection_id is None:
                from ..purchasing.service import record_lot_decision
                record_lot_decision(ctx.db, lot, ZERO, lot_on_hand(ctx.db, lot.id))
    _refresh_orders(ctx.db, ncr.lot_ids)
    ctx.audit("ncr.disposition", "nonconformance", ncr.id, after={"disposition": disposition}, reason=note)
    return ncr


def close_ncr(ctx: Ctx, ncr_id: int, note: str) -> Nonconformance:
    ctx.require("quality.disposition")
    ncr = ctx.get(Nonconformance, ncr_id)
    if ncr.status != "dispositioned":
        raise InvalidState("Only dispositioned nonconformances can be closed")
    ncr.status, ncr.closed_at = "closed", utcnow()
    ctx.audit("ncr.close", "nonconformance", ncr.id, reason=note)
    return ncr


def add_corrective_action(ctx: Ctx, ncr_id: int, problem: str, action: str, owner_user_id: int,
                          due_date: date | None = None, root_cause: str | None = None) -> CorrectiveAction:
    ctx.require("quality.capa")
    ctx.get(Nonconformance, ncr_id)
    ca = CorrectiveAction(number=ctx.next_number("CA"), nonconformance_id=ncr_id, problem=problem, action=action,
                          owner_user_id=owner_user_id, due_date=due_date, root_cause=root_cause)
    ctx.db.add(ca)
    ctx.db.flush()
    ctx.audit("capa.create", "corrective_action", ca.id, after=row_dict(ca))
    return ca


def inspection_detail(db: Session, insp: Inspection) -> dict:
    d = row_dict(insp)
    d["item_code"] = db.get(Item, insp.item_id).item_code
    d["lots"] = [db.get(Lot, l).lot_number for l in insp.lot_ids][:200]
    d["evaluation"] = evaluate(db, insp)
    rows = all_results(db, insp)
    superseded = {r.supersedes_result_id for r in rows if r.supersedes_result_id}
    d["results"] = [{**row_dict(r), "superseded": r.id in superseded} for r in rows]
    return d
