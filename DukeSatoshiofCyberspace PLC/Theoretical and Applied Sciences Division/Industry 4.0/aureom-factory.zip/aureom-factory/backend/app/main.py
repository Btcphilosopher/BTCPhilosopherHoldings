"""AUREOM FACTORY — FastAPI application (modular monolith)."""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm.exc import StaleDataError

from . import models  # noqa: F401  (register all tables)
from .config import settings
from .core import api as core_api
from .core.errors import DomainError
from .modules.costing import api as costing_api
from .modules.dispatch import api as dispatch_api
from .modules.documents import api as documents_api
from .modules.engineering import api as engineering_api
from .modules.genealogy import api as genealogy_api
from .modules.inventory import api as inventory_api
from .modules.maintenance import api as maintenance_api
from .modules.planning import api as planning_api
from .modules.production import api as production_api
from .modules.purchasing import api as purchasing_api
from .modules.quality import api as quality_api
from .modules.registry import api as registry_api
from .realtime.hub import hub, router as ws_router

logging.basicConfig(level=logging.INFO)


@asynccontextmanager
async def lifespan(app: FastAPI):
    if os.getenv("AUREOM_DISABLE_LISTENER") != "1":
        hub.start()
    yield
    hub.stop()


app = FastAPI(
    title="AUREOM FACTORY API",
    version="1.0.0",
    description=("Materials to Finished Goods: item registry, engineering, purchasing, inventory, planning, production, "
                 "quality, maintenance, costing, dispatch and traceability. All adapters in this release are simulated."),
    lifespan=lifespan,
)
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    return resp


@app.exception_handler(DomainError)
async def domain_error(_: Request, exc: DomainError):
    return JSONResponse(status_code=exc.status_code,
                        content={"error": {"code": exc.code, "message": exc.message, "details": exc.details}})


@app.exception_handler(StaleDataError)
async def stale(_: Request, exc: StaleDataError):
    return JSONResponse(status_code=409, content={"error": {"code": "conflict",
                                                            "message": "Record was modified concurrently; reload and retry"}})


@app.exception_handler(IntegrityError)
async def integrity(_: Request, exc: IntegrityError):
    msg = str(exc.orig).split("\n")[0] if exc.orig else "integrity error"
    return JSONResponse(status_code=409, content={"error": {"code": "integrity_error", "message": msg}})


@app.exception_handler(RequestValidationError)
async def validation(_: Request, exc: RequestValidationError):
    return JSONResponse(status_code=422, content={"error": {"code": "invalid_request", "message": "Request validation failed",
                                                            "details": exc.errors()}})


for r in (core_api, registry_api, engineering_api, inventory_api, purchasing_api, quality_api, production_api,
          planning_api, maintenance_api, costing_api, dispatch_api, genealogy_api, documents_api):
    app.include_router(r.router)
app.include_router(ws_router)
