"""Import every module's models so SQLAlchemy metadata (and Alembic) sees the full schema."""
from .core.models import *  # noqa
from .modules.registry.models import *  # noqa
from .modules.engineering.models import *  # noqa
from .modules.inventory.models import *  # noqa
from .modules.purchasing.models import *  # noqa
from .modules.quality.models import *  # noqa
from .modules.production.models import *  # noqa
from .modules.genealogy.models import *  # noqa
from .modules.planning.models import *  # noqa
from .modules.maintenance.models import *  # noqa
from .modules.costing.models import *  # noqa
from .modules.dispatch.models import *  # noqa
from .modules.documents.models import *  # noqa
from .db import Base  # noqa
