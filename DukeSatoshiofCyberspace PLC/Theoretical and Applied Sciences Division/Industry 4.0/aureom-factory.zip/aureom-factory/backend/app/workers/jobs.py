"""Background job handlers: planning, imports, machine polling, notifications and reports."""
from __future__ import annotations

import csv
import hashlib
import io
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import select

from ..adapters.registry import adapters
from ..core.context import Ctx, jsonable
from ..core.errors import ValidationFailed
from ..core.models import IdempotencyRecord, Notification
from ..modules.maintenance.models import Equipment
from ..modules.maintenance.service import ingest_observation
from ..modules.planning.service import run_mrp, run_schedule
from ..modules.purchasing.models import PurchaseOrder, PurchaseOrderLine
from ..modules.quality.models import Inspection
from ..modules.registry.models import Item
from ..modules.registry.service import create_item


def job_mrp_run(ctx: Ctx, payload: dict) -> dict:
    run = run_mrp(ctx, payload["site_id"], date.fromisoformat(payload["as_of"]) if payload.get("as_of") else None,
                  payload.get("horizon_days", 90))
    return {"run": run.number, "run_id": run.id}


def job_schedule_run(ctx: Ctx, payload: dict) -> dict:
    run = run_schedule(ctx, payload["site_id"], datetime.fromisoformat(payload["start_at"]) if payload.get("start_at") else None,
                       payload.get("horizon_days", 30))
    return {"run": run.number, "orders": len(run.result["orders"])}


IMPORT_COLUMNS = ("item_code", "revision", "description", "item_type", "base_unit", "lot_or_serial_policy")


def import_items(ctx: Ctx, csv_text: str, source: str = "upload") -> dict:
    """Idempotent CSV import. The same file imported twice is a no-op; a row that differs from an
    existing item is reported as a conflict and never overwrites it."""
    digest = hashlib.sha256(csv_text.encode()).hexdigest()
    prior = ctx.db.execute(select(IdempotencyRecord).where(IdempotencyRecord.scope == "import_items",
                                                           IdempotencyRecord.key == digest)).scalar_one_or_none()
    if prior:
        return {**prior.response, "replayed": True}
    created, unchanged, conflicts, errors = [], [], [], []
    reader = csv.DictReader(io.StringIO(csv_text))
    missing = [c for c in IMPORT_COLUMNS if c not in (reader.fieldnames or [])]
    if missing:
        raise ValidationFailed(f"Import file missing columns: {missing}")
    for n, row in enumerate(reader, start=2):
        row = {k: (v or "").strip() for k, v in row.items()}
        existing = ctx.db.execute(select(Item).where(Item.item_code == row["item_code"],
                                                     Item.revision == (row["revision"] or "A"))).scalar_one_or_none()
        if existing:
            same = all(str(getattr(existing, c)) == row[c] for c in ("description", "item_type", "base_unit", "lot_or_serial_policy"))
            (unchanged if same else conflicts).append({"line": n, "item_code": row["item_code"]})
            continue
        try:
            with ctx.db.begin_nested():
                create_item(ctx, {**{c: row[c] for c in IMPORT_COLUMNS}, "revision": row["revision"] or "A",
                                  "specifications": [], "lead_time_days": int(row.get("lead_time_days") or 0)})
            created.append(row["item_code"])
        except Exception as exc:
            errors.append({"line": n, "item_code": row.get("item_code"), "error": getattr(exc, "message", str(exc))})
    result = {"source": source, "sha256": digest, "created": created, "unchanged": unchanged, "conflicts": conflicts, "errors": errors}
    ctx.db.add(IdempotencyRecord(scope="import_items", key=digest, request_hash=digest, response=jsonable(result)))
    return result


def job_import_items(ctx: Ctx, payload: dict) -> dict:
    return import_items(ctx, payload["csv"], payload.get("source", "job"))


def job_machine_poll(ctx: Ctx, payload: dict) -> dict:
    out = []
    at = datetime.fromisoformat(payload["at"]) if payload.get("at") else None
    for eq in ctx.db.execute(select(Equipment).where(Equipment.adapter_ref.is_not(None))).scalars():
        obs = adapters().machine.read_state(eq.code, at)
        out.append({"equipment": eq.code, "state": obs.state, **ingest_observation(ctx, eq, obs)})
    return {"polled": out}


def job_notify_overdue(ctx: Ctx, payload: dict) -> dict:
    today = date.fromisoformat(payload["today"]) if payload.get("today") else date.today()
    made = 0
    for pl, po in ctx.db.execute(select(PurchaseOrderLine, PurchaseOrder).join(PurchaseOrder)
                                 .where(PurchaseOrderLine.status.in_(("open", "partially_received")),
                                        PurchaseOrder.status.in_(("sent", "acknowledged", "partially_received")))).all():
        due = pl.acknowledged_delivery or pl.expected_delivery
        if due and due < today:
            ctx.db.add(Notification(site_id=po.site_id, audience_role="buyer", severity="constraint",
                                    title=f"Late delivery: {po.number} line {pl.line_no}",
                                    body=f"Due {due}, {(today - due).days} day(s) late", entity_type="purchase_order",
                                    entity_id=str(po.id), delivered_via=["in_app"]))
            made += 1
    for eq in ctx.db.execute(select(Equipment).where(Equipment.calibration_required.is_(True))).scalars():
        if eq.calibration_due and eq.calibration_due <= today + timedelta(days=14):
            ctx.db.add(Notification(site_id=eq.site_id, audience_role="maintenance",
                                    severity="failure" if eq.calibration_due < today else "constraint",
                                    title=f"Calibration due: {eq.code}", body=f"Due {eq.calibration_due}",
                                    entity_type="equipment", entity_id=str(eq.id), delivered_via=["in_app"]))
            made += 1
    for insp in ctx.db.execute(select(Inspection).where(Inspection.status == "open")).scalars():
        if insp.created_at and insp.created_at.date() < today - timedelta(days=2):
            ctx.db.add(Notification(audience_role="quality_inspector", severity="constraint",
                                    title=f"Inspection {insp.number} open > 2 days", entity_type="inspection",
                                    entity_id=str(insp.id), delivered_via=["in_app"]))
            made += 1
    return {"notifications": made, "channel": "in_app (email/SMS delivery not implemented)"}


def job_report_traceability(ctx: Ctx, payload: dict) -> dict:
    from ..modules.dispatch.reports import traceability_report
    from ..modules.documents.service import upload

    html = traceability_report(ctx.db, payload["lot_id"])
    doc = upload(ctx, data=html.encode(), filename=f"trace_{payload['lot_id']}.html", content_type="text/html",
                 kind="report", title=f"Traceability report lot {payload['lot_id']}", entity_type="lot",
                 entity_id=payload["lot_id"])
    return {"document_id": doc.id}


def job_costing_export(ctx: Ctx, payload: dict) -> dict:
    from ..modules.costing.service import export_order_postings
    return export_order_postings(ctx, payload["order_id"])


HANDLERS = {
    "mrp_run": job_mrp_run, "schedule_run": job_schedule_run, "import_items": job_import_items,
    "machine_poll": job_machine_poll, "notify_overdue": job_notify_overdue, "report_traceability": job_report_traceability,
    "costing_export": job_costing_export,
}
