"""Background worker: claims jobs with FOR UPDATE SKIP LOCKED so several workers can run safely.

    python -m app.workers.worker            # run forever
    python -m app.workers.worker --once     # process the queue once and exit
"""
from __future__ import annotations

import argparse
import logging
import time
import traceback
from datetime import timedelta

from sqlalchemy import select

from .. import models  # noqa: F401
from ..api_deps import load_user
from ..core.context import Ctx, jsonable, utcnow
from ..core.models import Job, User
from ..db import session_factory
from .jobs import HANDLERS

log = logging.getLogger("aureom.worker")


def claim(db):
    return db.execute(select(Job).where(Job.status == "queued", Job.run_after <= utcnow())
                      .order_by(Job.id).limit(1).with_for_update(skip_locked=True)).scalar_one_or_none()


def run_one() -> bool:
    Session = session_factory()
    with Session() as db:
        with db.begin():
            job = claim(db)
            if job is None:
                return False
            job.status, job.started_at, job.attempts = "running", utcnow(), job.attempts + 1
            job_id = job.id
    with Session() as db:
        job = db.get(Job, job_id)
        user_id = job.requested_by or db.execute(select(User.id).where(User.username == "system")).scalar()
        try:
            with db.begin():
                ctx = Ctx(db=db, user=load_user(db, user_id), site_id=job.payload.get("site_id"))
                result = HANDLERS[job.kind](ctx, job.payload)
                job = db.get(Job, job_id)
                job.status, job.result, job.finished_at, job.error = "done", jsonable(result), utcnow(), None
            log.info("job %s %s done", job_id, job.kind)
        except Exception as exc:
            with db.begin():
                job = db.get(Job, job_id)
                job.error = f"{type(exc).__name__}: {getattr(exc, 'message', exc)}\n{traceback.format_exc()[-1500:]}"
                if job.attempts >= job.max_attempts:
                    job.status = "failed"
                else:
                    job.status, job.run_after = "queued", utcnow() + timedelta(seconds=10 * job.attempts)
            log.warning("job %s failed: %s", job_id, exc)
    return True


def main() -> None:
    logging.basicConfig(level=logging.INFO)
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--interval", type=float, default=2.0)
    args = ap.parse_args()
    while True:
        worked = run_one()
        if args.once and not worked:
            break
        if not worked:
            time.sleep(args.interval)


if __name__ == "__main__":
    main()
