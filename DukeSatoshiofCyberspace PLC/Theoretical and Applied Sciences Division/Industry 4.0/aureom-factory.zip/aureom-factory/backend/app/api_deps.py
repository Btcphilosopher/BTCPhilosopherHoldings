"""Shared FastAPI dependencies: authentication, site context and idempotency."""
from __future__ import annotations

import hashlib
import json
from typing import Annotated, Any, Callable

from fastapi import Depends, Header, Request
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from .core.context import Ctx, jsonable
from .core.errors import Conflict, Unauthenticated
from .core.models import IdempotencyRecord, User
from .core.security import unsign
from .db import get_session


class Body(BaseModel):
    """Base for request bodies: unknown fields are rejected."""

    model_config = ConfigDict(extra="forbid")


def load_user(db: Session, user_id: int) -> User:
    user = db.execute(select(User).options(selectinload(User.roles)).where(User.id == user_id)).scalar_one_or_none()
    if user is None or not user.active:
        raise Unauthenticated("User not found or inactive")
    return user


def current_ctx(
    db: Annotated[Session, Depends(get_session)],
    authorization: Annotated[str | None, Header()] = None,
    x_site_id: Annotated[int | None, Header()] = None,
) -> Ctx:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise Unauthenticated("Missing bearer token")
    body = unsign(authorization.split(" ", 1)[1])
    user = load_user(db, body["uid"])
    site = x_site_id
    if site is None:
        scoped = {r.site_id for r in user.roles if r.site_id is not None}
        site = next(iter(scoped)) if len(scoped) == 1 else body.get("site")
    return Ctx(db=db, user=user, site_id=site)


CtxDep = Annotated[Ctx, Depends(current_ctx)]


def idempotent(ctx: Ctx, scope: str, key: str | None, payload: Any, fn: Callable[[], Any]) -> Any:
    """Replay-safe POST: the same Idempotency-Key with the same payload returns the original response."""
    if not key:
        return fn()
    h = hashlib.sha256(json.dumps(jsonable(payload), sort_keys=True, default=str).encode()).hexdigest()
    rec = ctx.db.execute(select(IdempotencyRecord).where(IdempotencyRecord.scope == scope,
                                                         IdempotencyRecord.key == key)).scalar_one_or_none()
    if rec:
        if rec.request_hash != h:
            raise Conflict("Idempotency-Key was already used with a different request")
        return rec.response
    result = jsonable(fn())
    ctx.db.add(IdempotencyRecord(scope=scope, key=key, request_hash=h, response=result))
    return result


IdemKey = Annotated[str | None, Header(alias="Idempotency-Key")]
