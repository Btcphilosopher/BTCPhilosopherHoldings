"""Adapter selection. Only simulated adapters exist in this release; AUREOM_ADAPTER_MODE other than
'simulated' fails loudly rather than pretending to integrate."""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

from ..config import settings
from .base import AccountingAdapter, MachineAdapter, ScaleAdapter, ScannerAdapter, SupplierAdapter
from .simulated import KeyboardWedgeScanner, SimulatedAccounting, SimulatedMachine, SimulatedScale, SimulatedSupplierPortal


@dataclass
class Adapters:
    accounting: AccountingAdapter
    machine: MachineAdapter
    scale: ScaleAdapter
    scanner: ScannerAdapter
    supplier: SupplierAdapter

    def describe(self) -> dict:
        return {k: getattr(self, k).name for k in ("accounting", "machine", "scale", "scanner", "supplier")}


@lru_cache
def adapters() -> Adapters:
    if settings.adapter_mode != "simulated":
        raise RuntimeError(f"Adapter mode '{settings.adapter_mode}' is not implemented; only 'simulated' is available")
    return Adapters(SimulatedAccounting(), SimulatedMachine(), SimulatedScale(), KeyboardWedgeScanner(), SimulatedSupplierPortal())
