"""Typed adapter contracts for external systems.

Initial release ships SIMULATED implementations only (see simulated.py). The machine adapter is
read-only by design: there is no method that writes to, or controls, a machine.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Protocol, runtime_checkable


@dataclass
class ExportResult:
    adapter: str
    external_ref: str
    location: str
    lines: int


@dataclass
class MachineObservationDTO:
    equipment_code: str
    observed_at: datetime
    state: str  # running / idle / down / offline
    cycle_count: int | None = None
    spindle_hours: Decimal | None = None
    alarm_code: str | None = None
    source: str = "machine:simulated"
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class WeightReading:
    scale_id: str
    value: Decimal
    unit: str
    stable: bool
    observed_at: datetime
    source: str = "scale:simulated"


@dataclass
class ScanResult:
    raw: str
    kind: str  # item / lot / serial / bin / order / equipment / po / unknown
    value: str
    attributes: dict[str, str] = field(default_factory=dict)
    note: str = "Identification only — a scan does not establish that material meets specification."


@dataclass
class SupplierAck:
    adapter: str
    po_number: str
    accepted: bool
    ack_ref: str | None
    message: str
    line_dates: dict[int, date] = field(default_factory=dict)


@runtime_checkable
class AccountingAdapter(Protocol):
    name: str

    def export_journal(self, batch_ref: str, posting_date: date, currency: str, lines: list[dict]) -> ExportResult: ...


@runtime_checkable
class MachineAdapter(Protocol):
    """READ-ONLY. No control capability is defined or permitted in this release."""

    name: str

    def read_state(self, equipment_code: str, at: datetime | None = None) -> MachineObservationDTO: ...


@runtime_checkable
class ScaleAdapter(Protocol):
    name: str

    def read_weight(self, scale_id: str) -> WeightReading: ...


@runtime_checkable
class ScannerAdapter(Protocol):
    name: str

    def parse(self, raw: str) -> ScanResult: ...


@runtime_checkable
class SupplierAdapter(Protocol):
    name: str

    def send_purchase_order(self, payload: dict) -> SupplierAck: ...

    def fetch_acknowledgement(self, po_number: str) -> SupplierAck | None: ...
