"""Simulated adapters used for development and the demonstration. They are clearly labelled as
simulated in every result they return."""
from __future__ import annotations

import csv
import hashlib
import json
import os
import re
from datetime import date, datetime, timezone
from decimal import Decimal
from pathlib import Path

from ..config import settings
from .base import ExportResult, MachineObservationDTO, ScanResult, SupplierAck, WeightReading


class SimulatedAccounting:
    name = "accounting:simulated-csv"

    def __init__(self, root: str | None = None):
        self.root = Path(root or settings.export_path)

    def export_journal(self, batch_ref, posting_date, currency, lines) -> ExportResult:
        self.root.mkdir(parents=True, exist_ok=True)
        path = self.root / f"journal_{batch_ref}.csv"
        with path.open("w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["batch_ref", "posting_date", "account", "description", "debit", "credit", "currency", "element"])
            for l in lines:
                w.writerow([batch_ref, posting_date.isoformat(), l["account"], l["desc"], l["debit"], l["credit"], currency,
                            l["element"]])
        ref = "SIM-" + hashlib.sha1(batch_ref.encode()).hexdigest()[:10].upper()
        return ExportResult(adapter=self.name, external_ref=ref, location=str(path), lines=len(lines))


class SimulatedMachine:
    """Deterministic read-only telemetry. A scripted fault can be injected for the demo."""

    name = "machine:simulated"

    def __init__(self):
        self.faults: dict[str, tuple[datetime, datetime | None, str]] = {}
        self.cycles: dict[str, int] = {}

    def inject_fault(self, equipment_code: str, start: datetime, end: datetime | None, alarm: str) -> None:
        self.faults[equipment_code] = (start, end, alarm)

    def read_state(self, equipment_code, at=None) -> MachineObservationDTO:
        at = at or datetime.now(timezone.utc)
        f = self.faults.get(equipment_code)
        if f and f[0] <= at and (f[1] is None or at < f[1]):
            return MachineObservationDTO(equipment_code, at, "down", alarm_code=f[2], source=self.name,
                                         raw={"simulated": True, "alarm": f[2]})
        self.cycles[equipment_code] = self.cycles.get(equipment_code, 1000) + 7
        state = "running" if at.hour % 24 in range(7, 16) else "idle"
        return MachineObservationDTO(equipment_code, at, state, cycle_count=self.cycles[equipment_code],
                                     spindle_hours=Decimal(self.cycles[equipment_code]) / 60, source=self.name,
                                     raw={"simulated": True})


class SimulatedScale:
    name = "scale:simulated"

    def __init__(self):
        self.next_values: dict[str, list[Decimal]] = {}

    def queue(self, scale_id: str, value: Decimal) -> None:
        self.next_values.setdefault(scale_id, []).append(Decimal(value))

    def read_weight(self, scale_id) -> WeightReading:
        vals = self.next_values.get(scale_id) or []
        value = vals.pop(0) if vals else Decimal("0.000")
        return WeightReading(scale_id, value, "kg", True, datetime.now(timezone.utc), self.name)


GS1 = re.compile(r"\((\d{2,4})\)([^()]+)")
PREFIXES = {"ITM": "item", "LOT": "lot", "SER": "serial", "BIN": "bin", "MO": "order", "EQP": "equipment", "PO": "po",
            "OP": "operation"}


class KeyboardWedgeScanner:
    """Parses what a keyboard-wedge or camera scanner emits.

    Formats: 'LOT:<item_code>|<lot>', 'SER:<item_code>|<serial>', 'BIN:<code>', 'MO:<number>', 'EQP:<code>',
    'ITM:<code>' and GS1-style '(01)<gtin>(10)<lot>(21)<serial>'."""

    name = "scanner:keyboard-wedge"

    def parse(self, raw) -> ScanResult:
        raw = (raw or "").strip()
        if raw.startswith("("):
            ais = dict(GS1.findall(raw))
            if "21" in ais:
                return ScanResult(raw, "serial", ais["21"], {"gtin": ais.get("01", ""), "lot": ais.get("10", "")})
            if "10" in ais:
                return ScanResult(raw, "lot", ais["10"], {"gtin": ais.get("01", "")})
            return ScanResult(raw, "unknown", raw)
        if ":" in raw:
            p, v = raw.split(":", 1)
            kind = PREFIXES.get(p.upper())
            if kind:
                attrs = {}
                if "|" in v:
                    item, v = v.split("|", 1)
                    attrs["item_code"] = item
                return ScanResult(raw, kind, v, attrs)
        return ScanResult(raw, "unknown", raw)


class SimulatedSupplierPortal:
    name = "supplier:simulated-portal"

    def __init__(self):
        self.sent: dict[str, dict] = {}

    def send_purchase_order(self, payload) -> SupplierAck:
        self.sent[payload["number"]] = payload
        return SupplierAck(self.name, payload["number"], True, None, "Transmitted to simulated supplier portal (no real supplier contacted)")

    def fetch_acknowledgement(self, po_number) -> SupplierAck | None:
        if po_number not in self.sent:
            return None
        ref = "ACK-" + hashlib.sha1(po_number.encode()).hexdigest()[:6].upper()
        return SupplierAck(self.name, po_number, True, ref, "Simulated acknowledgement")
