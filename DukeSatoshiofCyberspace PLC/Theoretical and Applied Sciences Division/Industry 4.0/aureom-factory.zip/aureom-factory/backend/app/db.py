"""Database engine, session factory and declarative base."""
from __future__ import annotations

import json
from datetime import date, datetime
from decimal import Decimal
from typing import Iterator

from sqlalchemy import DateTime, MetaData, Numeric, create_engine, func
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker

from .config import settings

NAMING = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_N_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

# Quantities are stored with 6 decimal places; money with 4.
Qty = Numeric(18, 6)
Money = Numeric(18, 4)


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING)
    type_annotation_map = {Decimal: Qty, datetime: DateTime(timezone=True)}


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


def _json_default(o):
    if isinstance(o, Decimal):
        return str(o)
    if isinstance(o, (datetime, date)):
        return o.isoformat()
    raise TypeError(f"{type(o).__name__} is not JSON serialisable")


def _dumps(o) -> str:
    return json.dumps(o, default=_json_default)


_engine = None
_SessionLocal: sessionmaker | None = None


def get_engine(url: str | None = None):
    global _engine
    if url is not None:
        return create_engine(url, pool_pre_ping=True, json_serializer=_dumps)
    if _engine is None:
        _engine = create_engine(settings.database_url, pool_pre_ping=True, pool_size=10, max_overflow=20, json_serializer=_dumps)
    return _engine


def configure(url: str) -> None:
    """Point the application at a different database (used by tests and tools)."""
    global _engine, _SessionLocal
    _engine = create_engine(url, pool_pre_ping=True, pool_size=10, max_overflow=20, json_serializer=_dumps)
    _SessionLocal = sessionmaker(bind=_engine, expire_on_commit=False)


def session_factory() -> sessionmaker:
    global _SessionLocal
    if _SessionLocal is None:
        _SessionLocal = sessionmaker(bind=get_engine(), expire_on_commit=False)
    return _SessionLocal


def get_session() -> Iterator[Session]:
    """FastAPI dependency: one transaction per request; commit on success, roll back on error."""
    db = session_factory()()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
