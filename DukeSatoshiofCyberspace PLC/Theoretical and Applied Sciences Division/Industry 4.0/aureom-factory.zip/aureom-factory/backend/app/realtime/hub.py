"""WebSocket hub for operational updates.

Events are published with pg_notify inside the business transaction, so subscribers only ever see
committed changes. A background thread LISTENs on the channel and fans out to connected sockets,
which means events raised by workers or other API processes reach every browser.
"""
from __future__ import annotations

import asyncio
import json
import logging
import threading

import psycopg
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from ..config import settings
from ..core.errors import Unauthenticated
from ..core.security import unsign

log = logging.getLogger("aureom.realtime")
router = APIRouter()


class Hub:
    def __init__(self):
        self.clients: set[tuple[WebSocket, asyncio.AbstractEventLoop]] = set()
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

    def start(self) -> None:
        if self._thread is None:
            self._thread = threading.Thread(target=self._listen, name="pg-listen", daemon=True)
            self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _listen(self) -> None:
        dsn = settings.database_url.replace("postgresql+psycopg://", "postgresql://")
        while not self._stop.is_set():
            try:
                with psycopg.connect(dsn, autocommit=True) as conn:
                    conn.execute("LISTEN aureom_events")
                    for note in conn.notifies(timeout=1.0, stop_after=None):
                        self.broadcast(note.payload)
                        if self._stop.is_set():
                            break
            except Exception as exc:  # reconnect on failure
                log.warning("LISTEN connection error: %s", exc)
                self._stop.wait(2)

    def broadcast(self, payload: str) -> None:
        for ws, loop in list(self.clients):
            asyncio.run_coroutine_threadsafe(self._send(ws, payload), loop)

    async def _send(self, ws: WebSocket, payload: str) -> None:
        try:
            await ws.send_text(payload)
        except Exception:
            self.clients = {c for c in self.clients if c[0] is not ws}


hub = Hub()


@router.websocket("/ws")
async def ws_endpoint(websocket: WebSocket, token: str):
    try:
        unsign(token)
    except Unauthenticated:
        await websocket.close(code=4401)
        return
    await websocket.accept()
    entry = (websocket, asyncio.get_running_loop())
    hub.clients.add(entry)
    await websocket.send_text(json.dumps({"topic": "hello", "data": {"message": "connected to operational updates"}}))
    try:
        while True:
            await websocket.receive_text()  # keepalive pings from client
    except WebSocketDisconnect:
        pass
    finally:
        hub.clients.discard(entry)
