"""Runtime configuration, read from environment variables (see config/.env.example)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field


def _list(value: str) -> list[str]:
    return [v.strip() for v in value.split(",") if v.strip()]


@dataclass(frozen=True)
class Settings:
    database_url: str = os.getenv(
        "AUREOM_DATABASE_URL", "postgresql+psycopg://aureom:aureom@localhost:5432/aureom_factory"
    )
    secret_key: str = os.getenv("AUREOM_SECRET_KEY", "dev-only-change-me-0123456789abcdef")
    token_ttl_minutes: int = int(os.getenv("AUREOM_TOKEN_TTL_MINUTES", "720"))
    storage_path: str = os.getenv("AUREOM_STORAGE_PATH", os.path.abspath("./var/objects"))
    export_path: str = os.getenv("AUREOM_EXPORT_PATH", os.path.abspath("./var/exports"))
    base_currency: str = os.getenv("AUREOM_BASE_CURRENCY", "GBP")
    adapter_mode: str = os.getenv("AUREOM_ADAPTER_MODE", "simulated")
    cors_origins: list[str] = field(
        default_factory=lambda: _list(os.getenv("AUREOM_CORS_ORIGINS", "http://localhost:3000"))
    )
    max_upload_bytes: int = int(os.getenv("AUREOM_MAX_UPLOAD_BYTES", str(20 * 1024 * 1024)))
    environment: str = os.getenv("AUREOM_ENV", "development")


settings = Settings()

if settings.environment == "production" and settings.secret_key.startswith("dev-only"):
    raise RuntimeError("AUREOM_SECRET_KEY must be set to a strong secret in production")
