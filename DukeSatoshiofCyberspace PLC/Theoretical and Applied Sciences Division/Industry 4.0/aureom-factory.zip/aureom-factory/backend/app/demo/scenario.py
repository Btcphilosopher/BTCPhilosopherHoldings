"""Pennine Manufacturing Demonstrator — end-to-end scenario.

Runs every step through the same service layer the API uses, as the appropriate named user, on a
simulated clock (observed times in November 2026; recording times are real). Produces a log of
what happened, including the controls that correctly BLOCKED invalid actions.
"""
from __future__ import annotations

import json
import traceback
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..api_deps import load_user
from ..core.context import Ctx, jsonable
from ..core.errors import DomainError
from ..core.numbers import D, fmt
from ..modules.costing.service import export_order_postings, incremental_cost, order_cost_comparison
from ..modules.dispatch import service as dsp
from ..modules.dispatch.models import Customer, CustomerOrder
from ..modules.documents.service import upload
from ..modules.engineering.models import Bom
from ..modules.engineering.service import approve_bom, effective_bom, new_bom_version
from ..modules.genealogy.service import backward, forward
from ..modules.inventory.models import Bin, Lot, StockBalance
from ..modules.inventory.service import bin_by_code, lot_on_hand, reverse_movement, transfer, verify_journal
from ..modules.maintenance import service as mnt
from ..modules.maintenance.models import Equipment
from ..modules.planning.models import MrpProposal
from ..modules.planning.service import accept_proposal, create_demand, run_mrp, run_schedule
from ..modules.production import service as prod
from ..modules.production import shopfloor
from ..modules.production.models import OrderMaterial, ProductionOrder
from ..modules.purchasing import service as pur
from ..modules.purchasing.models import PurchaseOrder, PurchaseRequisition, Supplier
from ..modules.quality import service as qa
from ..modules.quality.models import Inspection, InspectionPlan, Nonconformance
from ..modules.registry.models import Item
from . import fixtures as fx
from .fixtures import T


class Demo:
    def __init__(self, db: Session, verbose: bool = True):
        self.db = db
        self.log: list[dict] = []
        self.verbose = verbose
        self.ref: dict = {}
        self.items: dict[str, Item] = {}
        self._users: dict[str, int] = {}
        self.site_id: int | None = None

    # ------------------------------------------------------------------ helpers
    def as_(self, username: str) -> Ctx:
        return Ctx(db=self.db, user=load_user(self.db, self._users[username]), site_id=self.site_id)

    def note(self, text: str, **data) -> None:
        self.log[-1]["notes"].append({"text": text, **({"data": jsonable(data)} if data else {})})
        if self.verbose:
            print("   •", text)

    @contextmanager
    def step(self, n, title: str):
        self.log.append({"step": n, "title": title, "notes": []})
        if self.verbose:
            print(f"\n[{n}] {title}")
        try:
            yield
            self.db.commit()
        except Exception:
            self.db.rollback()
            self.log[-1]["error"] = traceback.format_exc()
            raise

    def blocked(self, label: str, fn, *codes: str) -> None:
        """Run an action that MUST be refused; record the refusal."""
        sp = self.db.begin_nested()
        try:
            fn()
        except DomainError as e:
            sp.rollback()
            if codes and e.code not in codes:
                raise AssertionError(f"{label}: expected {codes}, got {e.code}: {e.message}")
            self.note(f"BLOCKED as intended — {label}: [{e.code}] {e.message}")
            return
        sp.rollback()
        raise AssertionError(f"{label}: action was NOT blocked")

    def refresh(self, obj) -> None:
        self.db.flush()
        self.db.refresh(obj)

    def I(self, code: str) -> Item:
        return self.items[code]

    def lot(self, number: str) -> Lot:
        return self.db.execute(select(Lot).where(Lot.lot_number == number)).scalar_one()

    def pass_inspection(self, ctx: Ctx, insp: Inspection, observed_at: datetime, overrides: dict | None = None,
                        sample_refs: list[str] | None = None) -> None:
        """Record conforming results for every characteristic/sample, with optional per-sample overrides."""
        plan = self.db.get(InspectionPlan, insp.plan_id)
        overrides = overrides or {}
        n = max(insp.sample_size, 1)
        refs = sample_refs or [f"S{i + 1}" for i in range(n)]
        gauge = {"caliper": "CAL-DIG-01", "safety_tester": "PAT-01", "coating_gauge": "CTG-01"}
        for ch in plan.characteristics:
            reps = refs[:1] if ch["kind"] == "document" else refs[:n]
            for i, ref in enumerate(reps):
                key = (ch["name"], ref)
                kw = dict(sample_ref=ref, observed_at=observed_at + timedelta(minutes=i))
                if ch["kind"] == "variable":
                    lo, hi = ch.get("lower"), ch.get("upper")
                    mid = (D(lo) + D(hi)) / 2 if lo is not None and hi is not None else (D(hi) * Decimal("0.4") if hi is not None else D(lo) * 50)
                    val = overrides.get(key, mid)
                    g = gauge.get(ch.get("gauge_kind"))
                    qa.record_result(ctx, insp.id, ch["name"], numeric_value=val, value_source="measured" if g else "manual",
                                     equipment_code=g, **kw)
                else:
                    qa.record_result(ctx, insp.id, ch["name"], conforms=overrides.get(key, True), value_source="manual",
                                     text_value="checked", **kw)

    # ------------------------------------------------------------------ run
    def run(self) -> list[dict]:
        db = self.db
        with self.step(0, "Load Pennine Manufacturing Demonstrator master data"):
            self.ref = fx.seed_reference(db)
            db.flush()
            self._users = {k: u.id for k, u in self.ref["users"].items()}
            self.site_id = self.ref["sites"]["PEN"].id
            self.items = fx.seed_items(self.as_("rdesai"), self.ref)
            fx.seed_conversions_and_refs(self.as_("rdesai"), self.as_("jcrowther"), self.items, self.ref)
            self.eng = fx.seed_engineering(self.as_("rdesai"), self.as_("jcrowther"), self.items, self.ref)
            fx.seed_opening_stock(self.as_("dackroyd"), self.items, self.ref)
            self.note(f"{len(self.items)} items, 3 approved BOMs, 4 approved routings (incl. rework), opening stock posted")
            self.note("Unknown specifications recorded explicitly, e.g. FG-L100: " +
                      ", ".join(s["name"] for s in self.I("FG-L100").specifications if s["status"] == "unknown"))
            self.blocked("circular BOM (housing as a component of the machined blank)",
                         lambda: __import__("app.modules.engineering.service", fromlist=["x"]).create_bom(
                             self.as_("rdesai"), self.I("WIP-HSG-L100-MC").id,
                             {"lines": [{"component_item_id": self.I("FG-L100").id, "quantity": 1, "unit": "pc"}]}), "bom_cycle")
            from ..modules.registry.service import convert
            self.blocked("convert kilograms of LED modules to pieces (no approved conversion)",
                         lambda: convert(db, 1, "kg", "pc", self.I("PC-LED-M12").id), "unit_conversion_unavailable")
            self.note(f"0.25 m of Ø50 bar = {convert(db, Decimal('0.25'), 'm', 'kg', self.I('RM-AL6082-50').id)} kg "
                      "(approved item conversion 5.301 kg/m)")

        planner, buyer, pm, store = self.as_("pshah"), self.as_("mpickles"), self.as_("isutcliffe"), self.as_("dackroyd")
        insp_ctx, qm, prodman = self.as_("kmensah"), self.as_("hbrierley"), self.as_("gholroyd")

        # 1 ---------------------------------------------------------------
        with self.step(1, "Enter demand for 100 lamps"):
            co = dsp.create_customer_order(self.as_("clumb"), self.site_id, db.execute(select(Customer).where(Customer.code == "LOI")).scalar_one().id,
                                           [{"item_id": self.I("FG-L100").id, "quantity": 100, "unit_price": Decimal("145.00")}],
                                           required_date=date(2026, 11, 27), customer_reference="LOI-PO-55120")
            self.co = co
            self.demand = create_demand(planner, self.site_id, self.I("FG-L100").id, 100, date(2026, 11, 27),
                                        customer_id=co.customer_id, customer_order_line_id=co.lines[0].id)
            self.note(f"Customer order {co.number} (Luddenden Optical) for 100 × FG-L100 due 27 Nov; demand {self.demand.number}")

        # 2 ---------------------------------------------------------------
        with self.step(2, "Calculate material requirements (MRP)"):
            run = run_mrp(planner, self.site_id, as_of=date(2026, 11, 2), horizon_days=60)
            self.mrp = run
            props = db.execute(select(MrpProposal).where(MrpProposal.run_id == run.id)).scalars().all()
            for p in props:
                self.note(f"{p.kind:10s} {self.db.get(Item, p.item_id).item_code:16s} {fmt(p.order_quantity)} {p.order_unit} "
                          f"need {p.need_date} release {p.release_date}" + (" LATE" if p.late else ""))
            for line in run.lines:
                if line["item_code"] == "RM-AL6082-50":
                    self.note("Explanation for RM-AL6082-50: " + " | ".join(line["explanation"][:6]))
            self.note("No purchase order or production order has been released by MRP — proposals only.")

        # 3 ---------------------------------------------------------------
        with self.step(3, "Create and approve purchasing proposals"):
            props = db.execute(select(MrpProposal).where(MrpProposal.run_id == self.mrp.id)).scalars().all()
            self.prod_orders = {}
            stb = db.execute(select(Supplier).where(Supplier.code == "STB")).scalar_one()
            for p in props:
                code = db.get(Item, p.item_id).item_code
                if p.kind == "purchase":
                    # buyer chooses the quicker second source for bar stock
                    accept_proposal(planner, p.id, supplier_id=stb.id if code == "RM-AL6082-50" else None)
                else:
                    r = accept_proposal(planner, p.id)
                    self.prod_orders[code] = db.execute(select(ProductionOrder).where(ProductionOrder.number == r["production_order"])).scalar_one()
            reqs = db.execute(select(PurchaseRequisition).where(PurchaseRequisition.status == "submitted")).scalars().all()
            self.blocked("planner approving own requisition", lambda: pur.decide_requisition(planner, reqs[0].id, True), "permission_denied")
            for r in reqs:
                pur.decide_requisition(pm, r.id, True, "Within budget for SO " + self.co.number)
            by_sup: dict[int, list] = {}
            for r in reqs:
                by_sup.setdefault(r.suggested_supplier_id, []).append(r)
            self.pos = {}
            lead = {"BRK": 5, "STB": 2, "LMH": 2, "CVC": 2, "HPF": 1, "MYP": 3}
            for sid, rs in by_sup.items():
                s = db.get(Supplier, sid)
                lines = [{"item_id": r.item_id, "quantity": r.quantity, "unit": r.unit,
                          "expected_delivery": date(2026, 11, 2) + timedelta(days=lead.get(s.code, 3)),
                          "certificate_required": db.get(Item, r.item_id).item_code == "RM-AL6082-50"} for r in rs]
                po = pur.create_po(buyer, self.site_id, sid, lines, order_date=date(2026, 11, 2), requisition_ids=[r.id for r in rs])
                self.blocked(f"buyer approving own PO {po.number}", lambda po=po: pur.approve_po(buyer, po.id, po.version), "permission_denied")
                pur.approve_po(pm, po.id, po.version)
                pur.send_po(buyer, po.id)
                ack_dates = {l.id: l.expected_delivery for l in po.lines}
                if s.code == "LMH":
                    ack_dates = {l.id: date(2026, 11, 4) for l in po.lines}
                pur.acknowledge_po(buyer, po.id, f"ACK-{s.code}-{po.number[-3:]}", ack_dates, acknowledged_at=T(2, "15:00"))
                self.pos[s.code] = po
                self.note(f"{po.number} → {s.name}: " + ", ".join(f"{fmt(l.quantity_ordered)} {l.unit} {db.get(Item, l.item_id).item_code} "
                                                                     f"@ {l.unit_price} {l.currency}" for l in po.lines))
            self.note("Requisitions approved by purchasing manager; POs approved by a different person than the author.")

        # 4 ---------------------------------------------------------------
        with self.step(4, "Receive and inspect materials (incl. one rejected delivery and a partial receipt)"):
            cert = upload(store, data=b"MILL CERTIFICATE (synthetic)\nAlloy 6082 Temper T4 Heat STB-24-0871\n", filename="stb_cert.txt",
                          content_type="text/plain", kind="certificate", title="Stoodley mill cert heat STB-24-0871")
            po = self.pos["STB"]
            gr = pur.receive(store, po.id, [{"po_line_id": po.lines[0].id, "quantity": po.lines[0].quantity_ordered,
                                             "supplier_lot": "STB-24-0871", "certificate_document_id": cert.id}],
                             received_at=T(4, "09:10"), delivery_note_ref="STB-DN-4471", idempotency_key="demo-gr-stb-1")
            again = pur.receive(store, po.id, [{"po_line_id": po.lines[0].id, "quantity": po.lines[0].quantity_ordered,
                                                "supplier_lot": "STB-24-0871"}], idempotency_key="demo-gr-stb-1")
            self.note(f"Receipt {gr.number}; replaying the same idempotency key returned the same receipt ({again.number}) — no duplicate stock")
            stb_lot = db.get(Lot, gr.lines[0].lot_id)
            self.blocked("allocating material that is awaiting inspection",
                         lambda: __import__("app.modules.inventory.service", fromlist=["x"]).reserve(
                             store, self.I("RM-AL6082-50"), 10, "production_material", 0, lot=stb_lot), "quality_hold")
            insp = db.execute(select(Inspection).where(Inspection.receipt_line_id == gr.lines[0].id)).scalar_one()
            qa.record_result(insp_ctx, insp.id, "Mill certificate: alloy and temper", conforms=False, value_source="manual",
                             text_value="Certificate states temper T4; order requires T6", observed_at=T(4, "10:00"))
            for i, v in enumerate(("50.02", "49.97", "50.05")):
                qa.record_result(insp_ctx, insp.id, "Diameter", numeric_value=Decimal(v), value_source="measured",
                                 equipment_code="CAL-DIG-01", sample_ref=f"S{i + 1}", observed_at=T(4, "10:05"))
            for i in range(3):
                qa.record_result(insp_ctx, insp.id, "Visual condition", conforms=True, sample_ref=f"S{i + 1}", observed_at=T(4, "10:10"))
            self.blocked("inspector (not quality manager) releasing a lot", lambda: qa.decide(insp_ctx, insp.id, "accepted", "x"), "permission_denied")
            self.blocked("releasing a nonconforming delivery", lambda: qa.decide(qm, insp.id, "accepted", "try"), "quality_hold")
            qa.decide(qm, insp.id, "rejected", "Wrong temper (T4) per mill certificate")
            ncr = db.execute(select(Nonconformance).where(Nonconformance.inspection_id == insp.id)).scalar_one()
            qa.disposition_ncr(qm, ncr.id, "return_to_supplier", "Return for credit; replacement sourced from Brackenholme")
            transfer(store, self.I("RM-AL6082-50"), stb_lot, bin_by_code(db, "RCV-01"), bin_by_code(db, "QTN-01"),
                     lot_on_hand(db, stb_lot.id), "kg", observed_at=T(4, "11:00"))
            srn = pur.return_to_supplier(buyer, stb_lot.id, "QTN-01", lot_on_hand(db, stb_lot.id), "Temper T4 supplied against T6 order",
                                         nonconformance_id=ncr.id, rma_ref="STB-RMA-0192", replacement_expected=False, observed_at=T(5, "08:30"))
            self.note(f"Rejected delivery: {stb_lot.lot_number} (supplier lot STB-24-0871) → {ncr.number} → return {srn.number}")
            # replacement order from preferred supplier (expedited)
            brk = db.execute(select(Supplier).where(Supplier.code == "BRK")).scalar_one()
            req = pur.create_requisition(planner, self.site_id, self.I("RM-AL6082-50").id, po.lines[0].quantity_ordered, "kg", date(2026, 11, 6),
                                         "Replacement for rejected STB delivery " + ncr.number, suggested_supplier_id=brk.id)
            pur.decide_requisition(pm, req.id, True, "Replacement")
            po2 = pur.create_po(buyer, self.site_id, brk.id, [{"item_id": self.I("RM-AL6082-50").id, "quantity": po.lines[0].quantity_ordered,
                                                               "unit": "kg", "expected_delivery": date(2026, 11, 6), "certificate_required": True}],
                                order_date=date(2026, 11, 5), requisition_ids=[req.id])
            pur.approve_po(pm, po2.id, po2.version)
            pur.send_po(buyer, po2.id)
            pur.acknowledge_po(buyer, po2.id, "ACK-BRK-EXP", acknowledged_at=T(5, "10:00"))
            self.pos["BRK"] = po2
            # cable, screws, packaging (on time)
            for code, sup_lot, day in (("CVC", "CV-5530", 4), ("HPF", "HF-7781", 3), ("MYP", "MY-1204", 5)):
                p = self.pos[code]
                pur.receive(store, p.id, [{"po_line_id": l.id, "quantity": l.quantity_ordered, "supplier_lot": f"{sup_lot}-{i}"}
                                          for i, l in enumerate(p.lines)], received_at=T(day, "09:30"), delivery_note_ref=f"{code}-DN-{day}")
            # LED modules: partial (late, with damage) then balance
            p = self.pos["LMH"]
            l0 = p.lines[0]
            pur.receive(store, p.id, [{"po_line_id": l0.id, "quantity": 60, "supplier_lot": "LH-24-118", "damaged_quantity": 2}],
                        received_at=T(5, "13:00"), delivery_note_ref="LMH-LS-77812", condition_note="2 modules with cracked lenses")
            self.note(f"LED partial receipt 60 (2 damaged segregated to quarantine), 1 day late; PO line status {l0.status}")
            pur.receive(store, p.id, [{"po_line_id": l0.id, "quantity": 40, "supplier_lot": "LH-24-131"}], received_at=T(9, "09:00"),
                        delivery_note_ref="LMH-LS-77990")
            cert2 = upload(store, data=b"MILL CERTIFICATE (synthetic)\nAlloy 6082 Temper T6 Heat BRK-HT-2347 UTS 318 MPa\n",
                           filename="brk_cert.txt", content_type="text/plain", kind="certificate", title="Brackenholme cert BRK-HT-2347")
            pur.receive(store, po2.id, [{"po_line_id": po2.lines[0].id, "quantity": po2.lines[0].quantity_ordered, "supplier_lot": "BRK-HT-2347",
                                         "certificate_document_id": cert2.id}], received_at=T(6, "08:45"), delivery_note_ref="BRK-DN-9912")
            # inspect and release everything awaiting review
            for insp in db.execute(select(Inspection).where(Inspection.stage == "incoming", Inspection.status == "open")).scalars().all():
                lot = db.get(Lot, insp.lot_ids[0])
                when = T(9, "11:00") if lot.supplier_lot == "LH-24-131" else T(6, "10:00")
                self.pass_inspection(insp_ctx, insp, when)
                qa.decide(qm, insp.id, "accepted", "Conforms to inspection plan")
                item = db.get(Item, lot.item_id)
                dest = {"raw_material": "RM-A1", "packaging": "PKG-01"}.get(item.item_type, "CMP-01")
                transfer(store, item, lot, bin_by_code(db, "RCV-01"), bin_by_code(db, dest), lot_on_hand(db, lot.id, bin_by_code(db, "RCV-01").id),
                         item.base_unit, observed_at=when + timedelta(hours=1))
                self.note(f"{item.item_code} lot {lot.lot_number} ({lot.supplier_lot}) accepted by {qm.user.full_name}, put away to {dest}")
            dmg = db.execute(select(Lot).where(Lot.lot_number.like("%-DMG"))).scalar_one()
            n2 = qa.raise_ncr(insp_ctx, source="incoming", item_id=dmg.item_id, lot_ids=[dmg.id], quantity=2,
                              description="Cracked lenses on arrival (LMH-LS-77812)")
            qa.disposition_ncr(qm, n2.id, "return_to_supplier", "Return damaged modules for credit")
            pur.return_to_supplier(buyer, dmg.id, "QTN-01", 2, "Damaged on arrival", nonconformance_id=n2.id, replacement_expected=False,
                                   observed_at=T(6, "09:00"))
            inv = pur.record_invoice(self.as_("mpickles"), self.pos["LMH"].supplier_id, "LMH-INV-24-5531", date(2026, 11, 10), "EUR",
                                     [{"po_line_id": l0.id, "quantity": 100, "unit_price": Decimal("18.40")}])
            self.note(f"Invoice LMH-INV-24-5531 three-way match: {inv.status} — {inv.match_result['lines'][0]['flags']}")
            rec = pur.po_reconciliation(db, self.pos["LMH"], date(2026, 11, 10))["lines"][0]
            self.note("LED PO line quantities kept separate: " + ", ".join(f"{k} {rec[k]}" for k in
                      ("ordered", "received", "accepted", "rejected", "returned", "invoiced")))

        o_wip, o_sa, o_fg = self.prod_orders["WIP-HSG-L100-MC"], self.prod_orders["SA-HSG-L100"], self.prod_orders["FG-L100"]
        self.orders = (o_wip, o_sa, o_fg)
        # 5 ---------------------------------------------------------------
        with self.step(5, "Allocate accepted lots"):
            for o in (o_wip, o_sa, o_fg):
                prod.plan_order(prodman, o.id, o.version, effective_on=date(2026, 11, 9))
            res = prod.allocate_materials(store, o_wip.id)
            self.note(f"{o_wip.number}: reserved " + "; ".join(f"{r['lot']} {r['quantity']}" for r in res))
            rejected = self.lot(db.execute(select(Lot.lot_number).where(Lot.supplier_lot == "STB-24-0871")).scalar_one())
            self.blocked("allocating the rejected Stoodley lot", lambda: prod.allocate_materials(
                store, o_wip.id, [{"material_id": o_wip.materials[0].id, "lot_id": rejected.id, "quantity": 1}]), "quality_hold")
            res = prod.allocate_materials(store, o_fg.id)
            self.note(f"{o_fg.number}: reserved {len(res)} lot allocations (LED from OPEN-LED-01 + LH-24-118 + LH-24-131); "
                      f"shortage remaining: {[s['item_code'] for s in prod.shortages(db, o_fg)]}")
            sched = run_schedule(prodman, self.site_id, T(9, "07:00"), 25)
            for r in sched.result["orders"]:
                self.note(f"Schedule {r['order']} ({r['item']}): finish {r['estimated_finish']} feasible={r['feasible']} "
                          f"late_days={r['late_days']} notes={r['notes'][:2]}")

        # 6 ---------------------------------------------------------------
        with self.step(6, "Release production orders (definitions frozen)"):
            prod.release_order(prodman, o_wip.id, o_wip.version, released_at=T(9, "07:15"))
            self.blocked("releasing the lamp order before housings exist", lambda: prod.release_order(prodman, o_fg.id, o_fg.version),
                         "insufficient_stock")
            self.note(f"{o_wip.number} released with BOM v{o_wip.bom_version} / routing v{o_wip.routing_version} frozen in snapshot")

        # 7a ---------------------------------------------------------------
        with self.step("7a", "Housings: cut, machine (with CNC-02 outage), inspect, scrap"):
            asha, liam = self.as_("apatel"), self.as_("lfirth")
            mat = o_wip.materials[0]
            res_lots = [(r.lot_id, r.quantity) for r in db.execute(select(__import__("app.modules.inventory.models", fromlist=["x"]).Reservation)
                        .where(__import__("app.modules.inventory.models", fromlist=["x"]).Reservation.demand_id == mat.id)).scalars()]
            for lot_id, qty in res_lots:
                prod.issue_material(store, mat.id, lot_id, qty, to_bin_code="WIP-SAW", observed_at=T(9, "07:20"))
            cut, mach, ins = sorted(o_wip.operations, key=lambda o: o.seq)
            self.blocked("operator without saw skill starting the cut", lambda: prod.start_operation(self.as_("sbarraclough"), cut.id, "SAW-01"),
                         "validation_failed")
            prod.check_equipment(asha, cut.id, "SAW-01", {"blade_condition": True, "guard_fitted": True, "coolant_level": True}, T(9, "07:25"))
            prod.start_operation(asha, cut.id, "SAW-01", phase="setup", observed_at=T(9, "07:30"))
            prod.start_operation(asha, cut.id, "SAW-01", phase="run", observed_at=T(9, "07:45"))
            prod.report_quantities(asha, cut.id, good=106, observed_at=T(9, "10:30"))
            # weigh-back of offcut ends with the (simulated) scale
            from ..adapters.registry import adapters
            sc = adapters().scale
            brk_lot = self.lot(db.execute(select(Lot.lot_number).where(Lot.supplier_lot == "BRK-HT-2347")).scalar_one())
            open_lot = self.lot("OPEN-AL-01")
            sc.queue("SCALE-01", Decimal("1.920"))
            w = sc.read_weight("SCALE-01")
            prod.record_consumption(asha, mat.id, open_lot.id, 40, "kg", from_bin_code="WIP-SAW", value_source="manual",
                                    observed_at=T(9, "10:35"), note="whole lot used")
            brk_issued = lot_on_hand(db, brk_lot.id, bin_by_code(db, "WIP-SAW").id)
            prod.record_consumption(asha, mat.id, brk_lot.id, brk_issued - w.value, "kg", from_bin_code="WIP-SAW", value_source="measured",
                                    observed_at=T(9, "10:40"), note=f"issued {brk_issued} − weighed remainder {w.value} kg ({w.source})")
            prod.return_material(store, mat.id, brk_lot.id, w.value, from_bin_code="WIP-SAW", to_bin_code="RM-A1", observed_at=T(9, "10:50"))
            prod.complete_operation(asha, cut.id, T(9, "10:55"))
            self.note(f"Cut 106 blanks; consumption {fmt(40 + brk_issued - w.value)} kg measured by weigh-back; "
                      f"{w.value} kg returned to RM-A1")
            # machining on two machines
            for who, eqc in ((asha, "CNC-02"), (liam, "CNC-01")):
                prod.check_equipment(who, mach.id, eqc, {"tool_offsets_verified": True, "first_off_ok": True}, T(9, "11:00"))
                prod.start_operation(who, mach.id, eqc, phase="setup", observed_at=T(9, "11:05"))
                prod.start_operation(who, mach.id, eqc, phase="run", observed_at=T(9, "11:50"))
            # CNC-02 spindle fault, reported by the (read-only) machine adapter and by the operator
            adapters().machine.inject_fault("CNC-02", T(10, "10:20"), T(12, "14:00"), "SP-217 spindle overload")
            cnc2 = db.execute(select(Equipment).where(Equipment.code == "CNC-02")).scalar_one()
            obs = adapters().machine.read_state("CNC-02", T(10, "10:21"))
            ing = mnt.ingest_observation(self.as_("sgreenwood"), cnc2, obs)
            self.note(f"Machine adapter observation: {obs.state} {obs.alarm_code}; discrepancy flagged: {ing['discrepancy']}")
            prod.pause_operation(asha, mach.id, "CNC-02 spindle fault SP-217", T(10, "10:22"))
            dt = mnt.record_downtime(asha, cnc2.id, T(10, "10:20"), "Spindle overload alarm SP-217 (operator report)")
            wo = mnt.create_work_order(self.as_("sgreenwood"), cnc2.id, "corrective", "Investigate spindle overload; replace drive belt",
                                       defect="SP-217 spindle overload")
            self.blocked("starting work on CNC-02 while it is down", lambda: prod.check_equipment(asha, mach.id, "CNC-02", {}, T(10, "13:00")) and
                         prod.start_operation(asha, mach.id, "CNC-02", observed_at=T(10, "13:00")), "invalid_state")
            sched = run_schedule(prodman, self.site_id, T(10, "11:00"), 25)
            r = next(x for x in sched.result["orders"] if x["order"] == o_wip.number)
            self.note(f"Re-schedule during outage: {o_wip.number} finish {r['estimated_finish']} notes {r['notes']}")
            prod.report_quantities(liam, mach.id, good=60, observed_at=T(11, "08:55"))
            prod.pause_operation(liam, mach.id, "Liam's share complete; CNC-01 released for next job", T(11, "09:00"))
            mnt.complete_work_order(self.as_("sgreenwood"), wo.id, "Drive belt replaced, spindle run-in OK", T(12, "08:00"), T(12, "13:30"))
            mnt.end_downtime(self.as_("sgreenwood"), dt.id, T(12, "14:00"), "Returned to service")
            prod.check_equipment(asha, mach.id, "CNC-02", {"tool_offsets_verified": True, "first_off_ok": True}, T(12, "14:05"))
            prod.resume_operation(asha, mach.id, "CNC-02", T(12, "14:10"))
            prod.report_quantities(asha, mach.id, good=43, rework=0, observed_at=T(13, "11:00"))
            sr = prod.report_scrap(liam, order_id=o_wip.id, op_id=mach.id, item_id=self.I("WIP-HSG-L100-MC").id, quantity=3, unit="pc",
                                   kind="product", reason_code="bore_oversize", reason="Bore Ø38.14 — oversize after tool wear",
                                   recoverable=True, recovered_item_id=self.I("SC-AL-SWARF").id, recovered_quantity=Decimal("3.6"),
                                   bin_code="SCR-01", observed_at=T(11, "14:00"))
            self.blocked("operator authorising own scrap", lambda: prod.authorise_scrap(liam, sr.id), "permission_denied")
            prod.authorise_scrap(prodman, sr.id, True, "Tool wear; tool-life counter reduced")
            prod.complete_operation(liam, mach.id, T(13, "11:30"))
            # in-process inspection and output
            prod.start_operation(liam, ins.id, None, observed_at=T(13, "12:00"))
            out = prod.report_output(liam, o_wip.id, ins.id, 103, to_bin_code="WIP-CNC", lot_number="HSG-2611-01", observed_at=T(13, "13:30"))
            insp = prod.ensure_operation_inspection(liam, ins, out, 103)
            # one result accidentally taken with the out-of-calibration caliper → kept but invalid, then re-measured
            bad = qa.record_result(insp_ctx, insp.id, "Bore diameter", numeric_value=Decimal("38.06"), value_source="measured",
                                   equipment_code="CAL-DIG-02", sample_ref="S1", observed_at=T(13, "12:30"))
            self.note(f"Result with CAL-DIG-02 recorded but calibration_valid={bad.calibration_valid} (expired 15 Oct)")
            qa.correct_result(qm, bad.id, "Re-measured with calibrated caliper CAL-DIG-01", numeric_value=Decimal("38.05"),
                              equipment_code="CAL-DIG-01")
            plan = db.get(InspectionPlan, insp.plan_id)
            for i in range(insp.sample_size):
                for ch in plan.characteristics:
                    if ch["name"] == "Bore diameter" and i == 0:
                        continue
                    val = Decimal("38.04") + Decimal(i % 4) / 100 if ch["name"] == "Bore diameter" else Decimal("240.05") - Decimal(i % 3) / 20
                    qa.record_result(insp_ctx, insp.id, ch["name"], numeric_value=val, value_source="measured", equipment_code="CAL-DIG-01",
                                     sample_ref=f"S{i + 1}", observed_at=T(13, "12:40"))
            qa.decide(qm, insp.id, "accepted", "13 samples within tolerance")
            prod.complete_operation(liam, ins.id, T(13, "14:00"))
            transfer(store, self.I("WIP-HSG-L100-MC"), out[0], bin_by_code(db, "WIP-CNC"), bin_by_code(db, "CMP-01"), 103, "pc",
                     observed_at=T(13, "14:15"))
            self.refresh(o_wip)
            self.note(f"{o_wip.number}: 103 good housings (lot HSG-2611-01) accepted; 3 scrapped (3.6 kg swarf recovered); status {o_wip.status}")
            prod.close_order(prodman, o_wip.id, o_wip.version)
            self.note(f"{o_wip.number} closed; actual unit cost {self.lot('HSG-2611-01').unit_cost} GBP")

        # 7b ---------------------------------------------------------------
        with self.step("7b", "Subcontract anodising (material visible at subcontractor)"):
            prod.allocate_materials(store, o_sa.id)
            prod.release_order(prodman, o_sa.id, o_sa.version, released_at=T(13, "14:30"))
            hda = db.execute(select(Supplier).where(Supplier.code == "HDA")).scalar_one()
            spo = pur.create_po(buyer, self.site_id, hda.id, [{"item_id": self.I("SA-HSG-L100").id, "quantity": o_sa.quantity_start,
                                                               "production_order_id": o_sa.id, "expected_delivery": date(2026, 11, 18)}],
                                order_date=date(2026, 11, 13), is_subcontract=True, notes="Anodising service for " + o_sa.number)
            pur.approve_po(pm, spo.id, spo.version)
            pur.send_po(buyer, spo.id)
            op = o_sa.operations[0]
            sh = prod.send_to_subcontractor(store, o_sa.id, op.id, [{"material_id": o_sa.materials[0].id,
                                                                    "lot_id": self.lot("HSG-2611-01").id, "quantity": o_sa.quantity_start}],
                                            po_id=spo.id, documents=[{"type": "despatch_note", "ref": "PMD-DN-3301"}], observed_at=T(13, "15:00"))
            here = lot_on_hand(db, self.lot("HSG-2611-01").id, bin_by_code(db, "SUB-HDA-01").id)
            self.note(f"{sh.number}: {fmt(here)} housings now physically at Hardcastle (bin SUB-HDA-01, company-owned, visible in inventory)")
            lot = prod.receive_from_subcontractor(store, sh.id, quantity_returned=o_sa.quantity_start - 1, quantity_lost=1,
                                                  loss_explanation="One housing damaged in anodising jig (HDA NCR 2211)",
                                                  lot_number="SAH-2611-01", observed_at=T(18, "10:00"),
                                                  supplier_documents=[{"type": "delivery_note", "ref": "HDA-DN-6610"},
                                                                      {"type": "process_record", "ref": "HDA-PR-6610 (bath 3, 19 µm avg)"}])
            insp = db.execute(select(Inspection).where(Inspection.stage == "incoming", Inspection.status == "open")).scalars().first()
            self.pass_inspection(insp_ctx, insp, T(18, "11:00"))
            qa.decide(qm, insp.id, "accepted", "Finish and thickness conform")
            transfer(store, self.I("SA-HSG-L100"), lot, bin_by_code(db, "RCV-01"), bin_by_code(db, "CMP-01"), lot_on_hand(db, lot.id), "pc",
                     observed_at=T(18, "12:00"))
            self.refresh(o_sa)
            prod.close_order(prodman, o_sa.id, o_sa.version)
            self.note(f"{o_sa.number}: returned {fmt(o_sa.quantity_start - 1)}, lost 1 at subcontractor; incoming inspection passed; closed")

        # 7c ---------------------------------------------------------------
        with self.step("7c", "Lamps: release, engineering change, assembly, test, pack (actual + calculated consumption)"):
            prod.allocate_materials(store, o_fg.id)
            prod.release_order(prodman, o_fg.id, o_fg.version, released_at=T(18, "13:00"))
            fg_bom = effective_bom(db, self.I("FG-L100").id, date(2026, 11, 18))
            v2 = new_bom_version(self.as_("rdesai"), fg_bom.id, "ECN-031: cable length 1.80 m for strain relief", date(2026, 11, 19))
            for l in v2.lines:
                if l.component_item_id == self.I("PC-CBL-3C075").id:
                    l.quantity = Decimal("1.80")
            approve_bom(self.as_("jcrowther"), v2.id)
            self.refresh(o_fg)
            self.note(f"BOM v{v2.version} approved effective 19 Nov; {o_fg.number} keeps frozen v{o_fg.snapshot['bom']['version']} "
                      f"(cable {next(l['quantity'] for l in o_fg.snapshot['bom']['lines'] if l['component_item_code'] == 'PC-CBL-3C075')} m)")
            from ..modules.inventory.models import Reservation
            for m in o_fg.materials:
                for r in db.execute(select(Reservation).where(Reservation.demand_type == "production_material", Reservation.demand_id == m.id,
                                                              Reservation.status == "active")).scalars().all():
                    prod.issue_material(store, m.id, r.lot_id, D(r.quantity) - D(r.quantity_issued), to_bin_code="WIP-ASSY",
                                        observed_at=T(18, "13:30"))
            cbl = next(m for m in o_fg.materials if m.item_id == self.I("PC-CBL-3C075").id)
            cv = self.lot(db.execute(select(Lot.lot_number).where(Lot.supplier_lot == "CV-5530-0")).scalar_one())
            prod.issue_material(store, cbl.id, cv.id, 5, to_bin_code="WIP-ASSY", observed_at=T(19, "09:00"))
            self.note("Additional 5 m cable issued to line-side (reserved on issue)")
            asm, tst, pck = sorted(o_fg.operations, key=lambda o: o.seq)
            sophie, liam = self.as_("sbarraclough"), self.as_("lfirth")
            for who, b in ((sophie, "BENCH-01"), (liam, "BENCH-02")):
                prod.check_equipment(who, asm.id, b, {"torque_driver_set_3Nm": True}, T(19, "07:05"))
                prod.start_operation(who, asm.id, b, observed_at=T(19, "07:10"))
            mats = {self.db.get(Item, m.item_id).item_code: m for m in o_fg.materials}
            hsg = self.lot("SAH-2611-01")
            prod.record_consumption(sophie, mats["SA-HSG-L100"].id, hsg.id, 100, from_bin_code="WIP-ASSY", value_source="scanned", observed_at=T(19, "15:00"))
            for lotno, qty in (("OPEN-LED-01", 10),):
                prod.record_consumption(sophie, mats["PC-LED-M12"].id, self.lot(lotno).id, qty, from_bin_code="WIP-ASSY", value_source="scanned", observed_at=T(19, "15:00"))
            led118 = self.lot(db.execute(select(Lot.lot_number).where(Lot.supplier_lot == "LH-24-118", Lot.quality_status == "accepted")).scalar_one())
            led131 = self.lot(db.execute(select(Lot.lot_number).where(Lot.supplier_lot == "LH-24-131")).scalar_one())
            prod.record_consumption(sophie, mats["PC-LED-M12"].id, led118.id, 58, from_bin_code="WIP-ASSY", value_source="scanned", observed_at=T(19, "15:00"))
            prod.record_consumption(liam, mats["PC-LED-M12"].id, led131.id, 32, from_bin_code="WIP-ASSY", value_source="scanned", observed_at=T(20, "11:00"))
            prod.record_consumption(sophie, mats["PC-CBL-3C075"].id, self.lot("OPEN-CBL-01").id, 30, from_bin_code="WIP-ASSY", value_source="measured", observed_at=T(19, "15:00"))
            prod.record_consumption(liam, mats["PC-CBL-3C075"].id, cv.id, Decimal("151.0"), from_bin_code="WIP-ASSY", value_source="measured", observed_at=T(20, "11:00"))
            fst = db.execute(select(StockBalance).where(StockBalance.bin_id == bin_by_code(db, "WIP-ASSY").id,
                                                        StockBalance.item_id == self.I("PC-FST-M5X12").id, StockBalance.quantity > 0)).scalars().all()
            used = Decimal(404)
            for b in fst:
                take = min(used, D(b.quantity))
                if take > 0:
                    prod.record_consumption(liam, mats["PC-FST-M5X12"].id, b.lot_id, take, from_bin_code="WIP-ASSY", value_source="manual", observed_at=T(20, "11:00"))
                    used -= take
            # offline tablet entry: pending until reconciled
            off = shopfloor.submit_offline(sophie, "TABLET-ASSY-2", [{"client_entry_id": "tab2-0001", "kind": "event",
                                           "payload": {"operation_id": asm.id, "event": "note", "note": "Two screws dropped and discarded"},
                                           "observed_at": T(20, "10:15").isoformat()}])
            dup = shopfloor.submit_offline(sophie, "TABLET-ASSY-2", [{"client_entry_id": "tab2-0001", "kind": "event",
                                           "payload": {"operation_id": asm.id, "event": "note"}, "observed_at": T(20, "10:15").isoformat()}])
            self.note(f"Offline tablet entry stored as '{off[0]['status']}'; resubmission flagged duplicate={dup[0]['duplicate']}")
            from ..core.models import OfflineEntry
            shopfloor.reconcile_offline(prodman, db.execute(select(OfflineEntry)).scalars().first().id, True, "Confirmed with operator")
            prod.complete_operation(liam, asm.id, T(20, "11:30"))
            # 100% electrical test: three earth-bond failures
            for who in (sophie,):
                prod.check_equipment(who, tst.id, "PAT-01", {"self_test": True, "test_leads_ok": True}, T(20, "12:00"))
                prod.start_operation(who, tst.id, "PAT-01", observed_at=T(20, "12:05"))
            serials = [f"PMD-L100-{i:06d}" for i in range(1, 101)]
            fails = {23: Decimal("0.38"), 47: Decimal("0.52"), 81: Decimal("0.41")}
            insp = prod.ensure_operation_inspection(sophie, tst, [], 100)
            for i, s in enumerate(serials, start=1):
                t0 = T(20, "12:10") + timedelta(minutes=2 * i)
                qa.record_result(sophie, insp.id, "Earth bond resistance", numeric_value=fails.get(i, Decimal("0.04") + Decimal(i % 5) / 100),
                                 value_source="measured", equipment_code="PAT-01", sample_ref=s, observed_at=t0)
                qa.record_result(sophie, insp.id, "Insulation resistance", numeric_value=Decimal("250"), value_source="measured",
                                 equipment_code="PAT-01", sample_ref=s, observed_at=t0)
                qa.record_result(sophie, insp.id, "Light-up", conforms=True, sample_ref=s, observed_at=t0)
            # output in three segments with scanned inputs → exact genealogy for housing and LED lots
            def inputs(led_lot, n):
                return [{"lot_id": hsg.id, "quantity": n}, {"lot_id": led_lot.id, "quantity": n}]
            seg = [(serials[0:10], self.lot("OPEN-LED-01")), (serials[10:68], led118), (serials[68:100], led131)]
            nc = [serials[i - 1] for i in fails]
            ncr_id = None
            for ss, led in seg:
                bad = [s for s in ss if s in nc]
                if bad:
                    prod.report_output(sophie, o_fg.id, tst.id, len(bad), conformity="nonconforming", serials=bad, to_bin_code="QTN-01",
                                       consumed_inputs=inputs(led, len(bad)), observed_at=T(20, "16:00"),
                                       defect_description="Earth bond resistance above 0.10 Ω (loose earth termination)",
                                       nonconformance_id=ncr_id)
                    ncr_id = ncr_id or db.execute(select(Nonconformance.id).where(Nonconformance.production_order_id == o_fg.id)).scalar()
            qa.decide(qm, insp.id, "quarantined", "97 passed; 3 failed earth bond — segregated under NCR")
            prod.complete_operation(sophie, tst.id, T(20, "16:30"))
            prod.check_equipment(sophie, pck.id, "PACK-01", {}, T(23, "07:00"))
            prod.start_operation(sophie, pck.id, "PACK-01", observed_at=T(23, "07:05"))
            prod.backflush(sophie, o_fg.id, pck.id, 97, from_bin_code="WIP-ASSY", observed_at=T(23, "10:30"))
            self.note("Packaging backflushed for 97 lamps — labelled calculated consumption")
            for ss, led in seg:
                good = [s for s in ss if s not in nc]
                prod.report_output(sophie, o_fg.id, pck.id, len(good), serials=good, to_bin_code="FG-HOLD",
                                   consumed_inputs=inputs(led, len(good)), observed_at=T(23, "10:45"))
            # backflush reconciliation: one carton damaged during packing
            ctn = mats["PK-CTN-L100"]
            ctn_lots = {b.lot_id: D(b.quantity) for b in db.execute(select(StockBalance).where(
                StockBalance.bin_id == bin_by_code(db, "WIP-ASSY").id, StockBalance.item_id == ctn.item_id, StockBalance.quantity > 0)).scalars()}
            counted = dict(ctn_lots)
            k = max(counted)
            counted[k] -= 1
            rec = prod.reconcile_backflush(sophie, ctn.id, counted, bin_code="WIP-ASSY", note="1 carton torn during packing")
            self.note(f"Carton backflush reconciliation: calculated {fmt(rec.calculated_quantity)}, actual {fmt(rec.actual_quantity)}, "
                      f"variance {fmt(rec.variance)} → adjustment recorded")
            for code in ("PK-FOAM-L100", "PK-LBL-L100"):
                m = mats[code]
                left = {b.lot_id: D(b.quantity) for b in db.execute(select(StockBalance).where(
                    StockBalance.bin_id == bin_by_code(db, "WIP-ASSY").id, StockBalance.item_id == m.item_id, StockBalance.quantity > 0)).scalars()}
                prod.reconcile_backflush(sophie, m.id, left, bin_code="WIP-ASSY", note="Counted, matches calculation")
            prod.complete_operation(sophie, pck.id, T(23, "11:00"))
            # return line-side remainders
            for m in o_fg.materials:
                for b in db.execute(select(StockBalance).where(StockBalance.bin_id == bin_by_code(db, "WIP-ASSY").id,
                                                               StockBalance.item_id == m.item_id, StockBalance.quantity > 0)).scalars().all():
                    item = db.get(Item, m.item_id)
                    dest = "PKG-01" if item.item_type == "packaging" else "CMP-01"
                    prod.return_material(store, m.id, b.lot_id, b.quantity, from_bin_code="WIP-ASSY", to_bin_code=dest, observed_at=T(23, "11:30"))
            self.refresh(o_fg)
            self.note(f"{o_fg.number} status '{o_fg.status}': operations complete, 97 lamps reported, 0 accepted yet (awaiting final inspection)")

        # 8 ---------------------------------------------------------------
        with self.step(8, "Report scrap and rework"):
            ncr = db.execute(select(Nonconformance).where(Nonconformance.production_order_id == o_fg.id,
                                                          Nonconformance.source == "in_process")).scalar_one()
            qa.disposition_ncr(qm, ncr.id, "rework", "Re-terminate earth per RW-L100-01")
            qa.add_corrective_action(qm, ncr.id, "Loose earth terminations", "Add torque-marked star washer and earth-bond check at assembly",
                                     self._users["gholroyd"], date(2026, 12, 4), root_cause="Earth nut torque not verified at ASSY")
            rw = prod.create_rework_order(prodman, ncr.id, instructions="RW-L100-01: replace cable, re-terminate earth with new star washer",
                                          additional_materials=[{"item_id": self.I("PC-CBL-3C075").id, "quantity": Decimal("5.4"), "unit": "m", "operation_seq": 10},
                                                                {"item_id": self.I("PK-CTN-L100").id, "quantity": 3, "unit": "pc", "operation_seq": 30},
                                                                {"item_id": self.I("PK-FOAM-L100").id, "quantity": 3, "unit": "pc", "operation_seq": 30},
                                                                {"item_id": self.I("PK-LBL-L100").id, "quantity": 3, "unit": "pc", "operation_seq": 30}])
            prod.plan_order(prodman, rw.id, rw.version)
            prod.allocate_materials(store, rw.id)
            prod.release_order(prodman, rw.id, rw.version, released_at=T(23, "13:00"))
            self.rework = rw
            sophie = self.as_("sbarraclough")
            prod.issue_for_rework(sophie, rw.id, ncr.lot_ids, from_bin_code="QTN-01", to_bin_code="WIP-ASSY", observed_at=T(23, "13:10"))
            for m in rw.materials:
                for r in db.execute(select(__import__("app.modules.inventory.models", fromlist=["x"]).Reservation).where(
                        __import__("app.modules.inventory.models", fromlist=["x"]).Reservation.demand_id == m.id,
                        __import__("app.modules.inventory.models", fromlist=["x"]).Reservation.demand_type == "production_material",
                        __import__("app.modules.inventory.models", fromlist=["x"]).Reservation.status == "active")).scalars().all():
                    prod.issue_material(store, m.id, r.lot_id, r.quantity, to_bin_code="WIP-ASSY", observed_at=T(23, "13:15"))
                    prod.record_consumption(sophie, m.id, r.lot_id, r.quantity, from_bin_code="WIP-ASSY", value_source="manual", observed_at=T(23, "14:30"))
            r1, r2, r3 = sorted(rw.operations, key=lambda o: o.seq)
            prod.check_equipment(sophie, r1.id, "BENCH-01", {}, T(23, "13:20"))
            prod.start_operation(sophie, r1.id, "BENCH-01", observed_at=T(23, "13:20"))
            prod.report_quantities(sophie, r1.id, good=3, observed_at=T(23, "14:00"))
            prod.complete_operation(sophie, r1.id, T(23, "14:00"))
            prod.check_equipment(sophie, r2.id, "PAT-01", {}, T(23, "14:05"))
            prod.start_operation(sophie, r2.id, "PAT-01", observed_at=T(23, "14:05"))
            ri = prod.ensure_operation_inspection(sophie, r2, [], 3)
            nc_serials = [db.get(Lot, l).lot_number for l in ncr.lot_ids]
            for s in nc_serials:
                qa.record_result(sophie, ri.id, "Earth bond resistance", numeric_value=Decimal("0.05"), value_source="measured", equipment_code="PAT-01", sample_ref=s, observed_at=T(23, "14:10"))
                qa.record_result(sophie, ri.id, "Insulation resistance", numeric_value=Decimal("240"), value_source="measured", equipment_code="PAT-01", sample_ref=s, observed_at=T(23, "14:10"))
                qa.record_result(sophie, ri.id, "Light-up", conforms=True, sample_ref=s, observed_at=T(23, "14:10"))
            qa.decide(qm, ri.id, "accepted", "Re-test passed for all three units")
            prod.report_quantities(sophie, r2.id, good=3, observed_at=T(23, "14:20"))
            prod.complete_operation(sophie, r2.id, T(23, "14:20"))
            prod.check_equipment(sophie, r3.id, "PACK-01", {}, T(23, "14:25"))
            prod.start_operation(sophie, r3.id, "PACK-01", observed_at=T(23, "14:25"))
            prod.report_rework_output(sophie, rw.id, r3.id, ncr.lot_ids, from_bin_code="WIP-ASSY", to_bin_code="FG-HOLD", observed_at=T(23, "14:40"))
            prod.complete_operation(sophie, r3.id, T(23, "14:45"))
            self.note(f"Rework order {rw.number} for {', '.join(nc_serials)}: extra cable 5.4 m + packaging consumed; re-test passed; "
                      "units back to awaiting_review (same serial identity, revised genealogy)")
            scr = db.execute(select(__import__("app.modules.production.models", fromlist=["x"]).ScrapRecord)).scalars().all()
            self.note("Scrap register: " + "; ".join(f"{s.number} {fmt(s.quantity)} {s.unit} {s.reason_code} ({s.status}, recoverable={s.recoverable})" for s in scr))

        # 9 ---------------------------------------------------------------
        with self.step(9, "Final inspection (with a corrected result)"):
            fi_plan = db.execute(select(InspectionPlan).where(InspectionPlan.code == "FI-L100")).scalar_one()
            rw_ids = set(db.get(Nonconformance, self.rework.nonconformance_id).lot_ids)
            good_lots = [l for l in db.execute(select(Lot).where(Lot.batch_ref == o_fg.number, Lot.quality_status == "awaiting_review")
                                               .order_by(Lot.lot_number)).scalars() if l.id not in rw_ids]
            fi = qa.open_inspection(insp_ctx, "final", self.I("FG-L100"), good_lots, plan=fi_plan)
            refs = [l.lot_number for l in good_lots][: fi.sample_size]
            self.pass_inspection(insp_ctx, fi, T(23, "13:00"), {("Arm articulation torque", refs[4]): Decimal("15")}, refs)
            from ..modules.quality.models import InspectionResult
            typo = db.execute(select(InspectionResult).where(InspectionResult.inspection_id == fi.id,
                                                             InspectionResult.numeric_value == Decimal("15"))).scalar_one()
            self.blocked("releasing with a nonconforming (mistyped) result", lambda: qa.decide(qm, fi.id, "accepted", "x"), "quality_hold")
            qa.correct_result(qm, typo.id, "Transcription error: 1.5 N·m recorded as 15 (torque gauge display photo on file)",
                              numeric_value=Decimal("1.5"))
            self.note(f"Original result {typo.id} (15 N·m) retained; correction supersedes it")
            # 10
        with self.step(10, "Release accepted finished stock"):
            qa.decide(qm, fi.id, "accepted", f"Sample of {fi.sample_size} conforms")
            rw_lots = db.execute(select(Lot).where(Lot.id.in_(db.get(Nonconformance, self.rework.nonconformance_id).lot_ids))).scalars().all()
            fi2 = qa.open_inspection(insp_ctx, "final", self.I("FG-L100"), rw_lots, plan=fi_plan)
            self.pass_inspection(insp_ctx, fi2, T(24, "09:00"), sample_refs=[l.lot_number for l in rw_lots])
            qa.decide(qm, fi2.id, "accepted", "Reworked units conform")
            for l in good_lots + rw_lots:
                transfer(store, self.I("FG-L100"), l, bin_by_code(db, "FG-HOLD"), bin_by_code(db, "FG-01"), 1, "pc", observed_at=T(24, "10:00"))
            for o in (o_fg, self.rework):
                self.refresh(o)
            prod.close_order(prodman, self.rework.id, self.rework.version)
            self.refresh(o_fg)
            prod.close_order(prodman, o_fg.id, o_fg.version)
            self.note(f"{o_fg.number}: reported {fmt(o_fg.quantity_reported)}, accepted {fmt(o_fg.quantity_accepted)}, "
                      f"nonconforming {fmt(o_fg.quantity_nonconforming)} → rework {self.rework.number} accepted "
                      f"{fmt(db.get(ProductionOrder, self.rework.id).quantity_accepted)}; both closed")
            self.note("Product certification: none recorded — passing inspections does not certify the product.")

        # 11 ---------------------------------------------------------------
        with self.step(11, "Dispatch part of the batch"):
            disp = self.as_("clumb")
            line = self.co.lines[0]
            dsp.allocate_line(disp, line.id, 60)
            sh = dsp.create_shipment(disp, self.co.id, [{"order_line_id": line.id, "quantity": 60}])
            lots = [l.lot_id for l in sh.lines]
            dsp.pick(disp, sh.id, lots, observed_at=T(25, "11:00"))
            dsp.pack(disp, sh.id, [{"ref": f"PKG-{i + 1:02d}", "lot_ids": lots[i * 10:(i + 1) * 10], "weight_kg": Decimal("24.5")} for i in range(6)])
            dsp.dispatch_shipment(disp, sh.id, "Pennine Freight (demo)", "PF-77120045", T(25, "14:00"))
            dsp.confirm_delivery(disp, sh.id, "POD-LOI-26-1188", T(26, "10:20"))
            self.ship1 = sh
            wtl = db.execute(select(Customer).where(Customer.code == "WTL")).scalar_one()
            co2 = dsp.create_customer_order(disp, self.site_id, wtl.id, [{"item_id": self.I("FG-L100").id, "quantity": 5, "unit_price": Decimal("149.00")}],
                                            required_date=date(2026, 11, 26))
            dsp.allocate_line(disp, co2.lines[0].id)
            sh2 = dsp.create_shipment(disp, co2.id, [{"order_line_id": co2.lines[0].id, "quantity": 5}])
            dsp.pick(disp, sh2.id, [l.lot_id for l in sh2.lines], observed_at=T(25, "11:30"))
            dsp.pack(disp, sh2.id, [{"ref": "PKG-01", "lot_ids": [l.lot_id for l in sh2.lines]}])
            dsp.dispatch_shipment(disp, sh2.id, "Pennine Freight (demo)", "PF-77120102", T(25, "15:00"))
            self.refresh(line)
            self.note(f"{sh.number}: 60 lamps to Luddenden, delivered (POD-LOI-26-1188); {sh2.number}: 5 lamps to Wainhouse (dispatched)")
            self.note(f"Order line: ordered {fmt(line.quantity_ordered)}, allocated {fmt(line.quantity_allocated)}, picked {fmt(line.quantity_picked)}, "
                      f"dispatched {fmt(line.quantity_dispatched)}, delivered {fmt(line.quantity_delivered)}")

        # 12 ---------------------------------------------------------------
        with self.step(12, "Trace a supplier lot into finished units and shipments"):
            led118 = self.lot(db.execute(select(Lot.lot_number).where(Lot.supplier_lot == "LH-24-118", Lot.quality_status != "rejected")).scalar_one())
            f = forward(db, led118.id)
            self.note(f"LED supplier lot LH-24-118 ({led118.lot_number}) → {f['summary']['finished_units_reached']} lamps "
                      f"({f['summary']['finished_by_precision']}); shipped {f['summary']['finished_shipped']}, in stock {f['summary']['finished_in_stock']}")
            for cust, lst in f["summary"]["customers"].items():
                self.note(f"  {cust}: {len(lst)} units, e.g. {lst[0]['lot']} via {lst[0]['shipment']}")
            al = self.lot(db.execute(select(Lot.lot_number).where(Lot.supplier_lot == "BRK-HT-2347")).scalar_one())
            f2 = forward(db, al.id)
            self.note(f"Aluminium heat BRK-HT-2347 → {f2['summary']['finished_units_reached']} lamps {f2['summary']['finished_by_precision']} "
                      "(order-level: bar from two heats was cut in one order)")
            b = backward(db, self.lot("PMD-L100-000023").id)
            self.note("Backward from reworked serial PMD-L100-000023: " + "; ".join(
                f"{r['item_code']} {r['lot_number']} [{r['label']}]" for r in b["contributors"]))
            b1 = backward(db, self.lot("PMD-L100-000005").id)
            led = next(r for r in b1["contributors"] if r["item_code"] == "PC-LED-M12")
            self.note(f"Serial PMD-L100-000005 LED source: {led['lot_number']} — {led['label']} ({led['traceability_note']})")

        # 13 ---------------------------------------------------------------
        with self.step(13, "Compare planned and actual costs"):
            for o in (o_wip, o_sa, o_fg, self.rework):
                c = order_cost_comparison(db, db.get(ProductionOrder, o.id))
                self.note(f"{c['order']} {c['item_code']}: standard {c['standard']['total_for_target']} | planned {c['planned']['total']} | "
                          f"actual {c['actual']['total']} | EAC {c['estimate_at_completion']['total']} | variance {c['variance_actual_vs_planned']} GBP")
            nr = self.as_("nrahman")
            for o in (o_wip, o_sa, o_fg, self.rework):
                r = export_order_postings(nr, o.id, date(2026, 11, 26))
                self.note(f"Export {r['batch_ref']}: {r['status']} balanced={r.get('balanced')}")
            inc = incremental_cost(db, self.I("FG-L100").id)
            self.note(f"One more lamp — incremental {inc['incremental_cost_one_more_unit']} GBP vs fully allocated standard "
                      f"{inc['fully_allocated_standard_unit_cost']} GBP (overhead and fixed labour excluded)")
            c = order_cost_comparison(db, db.get(ProductionOrder, o_fg.id))
            self.note(f"Posted (exported) cost for {o_fg.number}: {c['posted']['total']} GBP")

        # 14 ---------------------------------------------------------------
        with self.step(14, "Investigate a simulated recall"):
            rc = dsp.open_recall(qm, "Lumenhaus driver capacitor advisory LH-24-118",
                                 "Supplier advises possible early failure of driver capacitor C7 in module lot LH-24-118.", [led118.id])
            fnd = rc.findings
            self.note(f"{rc.number}: finished units confirmed {fnd['finished_units']['confirmed']}, possible {fnd['finished_units']['possible']}, "
                      f"unknown {fnd['finished_units']['unknown']}; by location {fnd['by_location']}")
            for cust, lst in fnd["customers"].items():
                self.note(f"  notify {cust}: {len(lst)} units")
            held = sum(1 for i in rc.items if i.action == "quarantined")
            self.note(f"{held} affected units/lots still in our stock placed in QUARANTINE")
            loi = db.execute(select(Customer).where(Customer.code == "LOI")).scalar_one()
            ret_lot = next(i for i in rc.items if i.customer_id == loi.id)
            sl = next(l for l in self.ship1.lines if l.lot_id == ret_lot.lot_id)
            cr = dsp.receive_customer_return(self.as_("clumb"), loi.id, ret_lot.lot_id, 1, "Returned under recall " + rc.number,
                                             shipment_line_id=sl.id, recall_id=rc.id, received_at=T(27, "09:30"))
            self.note(f"Customer return {cr.number}: {db.get(Lot, ret_lot.lot_id).lot_number} in RTN-01, status "
                      f"{db.get(Lot, ret_lot.lot_id).quality_status} — not saleable until quality review")
            self.blocked("allocating the returned unit to another customer", lambda: __import__("app.modules.inventory.service", fromlist=["x"]).reserve(
                self.as_("clumb"), self.I("FG-L100"), 1, "customer_order_line", 0, lot=db.get(Lot, ret_lot.lot_id)), "quality_hold")
            oee = mnt.oee(db, db.execute(select(Equipment).where(Equipment.code == "CNC-02")).scalar_one(), T(9, "00:00"), T(14, "00:00"))
            self.note(f"OEE CNC-02 9–13 Nov: availability {oee['availability']}, performance {oee['performance']}, quality {oee['quality']}, "
                      f"OEE {oee['oee']} (unplanned downtime {oee['unplanned_downtime_minutes']} min)")
        # 15 ---------------------------------------------------------------
        with self.step(15, "Leave released work for the shop-floor terminal"):
            follow = prod.create_order(prodman, self.site_id, self.I("FG-L100").id, 1, due_date=date(2026, 12, 4),
                                       effective_on=date(2026, 11, 27))
            prod.plan_order(prodman, follow.id, follow.version, effective_on=date(2026, 11, 27))
            prod.allocate_materials(store, follow.id)
            prod.release_order(prodman, follow.id, follow.version, released_at=T(27, "10:00"))
            self.note(f"{follow.number}: 1 × FG-L100 released with BOM v{follow.bom_version} (cable 1.80 m after ECN-031); "
                      "operation 10 is waiting on the shop-floor terminal")
            problems = verify_journal(db)
            self.note(f"Journal check: balances recomputed from the movement journal — {len(problems)} discrepancies")
        return self.log
