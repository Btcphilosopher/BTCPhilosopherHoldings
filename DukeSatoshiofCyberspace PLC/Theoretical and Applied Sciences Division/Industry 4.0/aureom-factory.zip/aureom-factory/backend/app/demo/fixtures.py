"""Synthetic master data for the Pennine Manufacturing Demonstrator (all names fictional).

Product: Pennine BL-100 bench-mounted inspection lamp (mains powered, Class I, aluminium housing).
"""
from __future__ import annotations

from datetime import date, datetime, time
from decimal import Decimal
from zoneinfo import ZoneInfo

from sqlalchemy.orm import Session

from ..core.context import Ctx
from ..core.models import Site, User, UserRole
from ..core.security import hash_password
from ..modules.costing.models import FxRate, OverheadRule
from ..modules.engineering.models import WorkCentre
from ..modules.engineering.service import add_bom_line, approve_bom, approve_routing, create_bom, create_routing
from ..modules.inventory.models import Bin, Warehouse
from ..modules.inventory.service import create_lot, post_movement
from ..modules.maintenance.models import CalibrationRecord, Equipment, ServiceSchedule
from ..modules.purchasing.models import Supplier
from ..modules.quality.models import InspectionPlan, SamplingPlan
from ..modules.registry.models import Item, ItemSupplierRef, ItemUnitConversion, Unit
from ..modules.dispatch.models import Customer

TZ = ZoneInfo("Europe/London")
DEMO_PASSWORD = "demo"  # documented demo credential — change for any non-demo use
SHIFT = {d: [["07:00", "15:30"]] for d in ("mon", "tue", "wed", "thu", "fri")}


def T(d: int, hm: str = "08:00", month: int = 11) -> datetime:
    """Scenario clock: 2026-11-<d> HH:MM Europe/London."""
    h, m = map(int, hm.split(":"))
    return datetime(2026, month, d, h, m, tzinfo=TZ)


USERS = [
    # username, full name, roles, skills
    ("admin", "Aureom Administrator", ["admin"], []),
    ("system", "System (background jobs)", ["admin"], []),
    ("pshah", "Priya Shah", ["planner"], []),
    ("gholroyd", "Gareth Holroyd", ["production_manager"], ["assembly", "cnc", "saw"]),
    ("mpickles", "Megan Pickles", ["buyer"], []),
    ("isutcliffe", "Ian Sutcliffe", ["purchasing_manager"], []),
    ("dackroyd", "Dave Ackroyd", ["storekeeper"], []),
    ("apatel", "Asha Patel", ["operator"], ["saw", "cnc"]),
    ("lfirth", "Liam Firth", ["operator"], ["cnc", "assembly"]),
    ("sbarraclough", "Sophie Barraclough", ["operator"], ["assembly", "electrical_test", "packing"]),
    ("kmensah", "Kofi Mensah", ["quality_inspector"], []),
    ("hbrierley", "Helen Brierley", ["quality_manager"], []),
    ("rdesai", "Ravi Desai", ["engineer"], []),
    ("jcrowther", "Joanne Crowther", ["engineering_approver"], []),
    ("sgreenwood", "Stuart Greenwood", ["maintenance"], []),
    ("nrahman", "Nadia Rahman", ["cost_accountant"], []),
    ("clumb", "Craig Lumb", ["dispatcher"], []),
    ("viewer", "Read-only Viewer", ["viewer"], []),
]


def seed_reference(db: Session) -> dict:
    """Sites, users, units, suppliers, customers, locations, work centres, equipment, rates."""
    pen = Site(code="PEN", name="Pennine Works (demonstrator)", address="Unit 4, Calder Mill, Pennine Way (fictional)")
    cal = Site(code="CAL", name="Calder Works (second site — used to show site scoping)")
    db.add_all([pen, cal])
    db.flush()
    users = {}
    for uname, name, roles, skills in USERS:
        # the system account is for background jobs only: its password hash can never verify
        pw = "!disabled" if uname == "system" else hash_password(DEMO_PASSWORD)
        u = User(username=uname, full_name=name, password_hash=pw, skills=skills,
                 shift_pattern=SHIFT if "operator" in roles or "production_manager" in roles else None)
        u.roles = [UserRole(role=r, site_id=None if r in ("admin",) else pen.id) for r in roles]
        db.add(u)
        users[uname] = u
    cal_op = User(username="calder_op", full_name="Calder Site Operator", password_hash=hash_password(DEMO_PASSWORD),
                  skills=["assembly"], shift_pattern=None)
    cal_op.roles = [UserRole(role="operator", site_id=cal.id), UserRole(role="storekeeper", site_id=cal.id)]
    db.add(cal_op)
    users["calder_op"] = cal_op

    for code, name, dim, f, integral in [
        ("kg", "kilogram", "mass", "1", False), ("g", "gram", "mass", "0.001", False), ("t", "tonne", "mass", "1000", False),
        ("m", "metre", "length", "1", False), ("mm", "millimetre", "length", "0.001", False),
        ("L", "litre", "volume", "1", False), ("mL", "millilitre", "volume", "0.001", False),
        ("pc", "piece", "count", "1", True), ("pack", "pack", "pack", None, True), ("reel", "reel", "pack", None, True),
        ("box", "box", "pack", None, True), ("h", "hour", "time", "1", False), ("min", "minute", "time", "0.0166666667", False),
    ]:
        db.add(Unit(code=code, name=name, dimension=dim, factor_to_reference=Decimal(f) if f else None, integral=integral))
    db.add_all([FxRate(currency="EUR", rate_date=date(2026, 10, 1), rate_to_base=Decimal("0.8550"), source="demo fixed"),
                FxRate(currency="EUR", rate_date=date(2026, 11, 2), rate_to_base=Decimal("0.8610"), source="demo fixed")])

    sup = {}
    for code, name, cur, country, subcon in [
        ("BRK", "Brackenholme Alloys Ltd", "GBP", "GB", False), ("STB", "Stoodley Bar Stock Ltd", "GBP", "GB", False),
        ("LMH", "Lumenhaus Modulbau GmbH", "EUR", "DE", False), ("CVC", "Cragg Vale Cables Ltd", "GBP", "GB", False),
        ("HPF", "Heptonstall Fixings Ltd", "GBP", "GB", False), ("MYP", "Mytholm Packaging Ltd", "GBP", "GB", False),
        ("HDA", "Hardcastle Anodising Ltd", "GBP", "GB", True), ("LMA", "Lumen Alternates Ltd", "GBP", "GB", False),
    ]:
        s = Supplier(code=code, name=name + " (fictional)", currency=cur, country=country, is_subcontractor=subcon)
        db.add(s)
        sup[code] = s
    for code, name in [("LOI", "Luddenden Optical Instruments Ltd"), ("WTL", "Wainhouse Test Laboratories Ltd")]:
        db.add(Customer(code=code, name=name + " (fictional)", country="GB", address="West Yorkshire (fictional)"))
    db.flush()

    main = Warehouse(site_id=pen.id, code="MAIN", name="Pennine Works main stores")
    subw = Warehouse(site_id=pen.id, code="SUB-HDA", name="Company stock held at Hardcastle Anodising", kind="subcontractor",
                     supplier_id=sup["HDA"].id)
    calw = Warehouse(site_id=cal.id, code="CALDER", name="Calder Works stores")
    db.add_all([main, subw, calw])
    db.flush()
    bins = {}
    for code, kind, alloc, desc, wh in [
        ("RCV-01", "receiving", False, "Goods-in (awaiting inspection)", main),
        ("QTN-01", "quarantine", False, "Quarantine cage", main),
        ("RM-A1", "storage", True, "Bar rack A1", main), ("RM-A2", "storage", True, "Bar rack A2", main),
        ("CMP-01", "storage", True, "Component racking", main), ("PKG-01", "storage", True, "Packaging store", main),
        ("CON-01", "storage", True, "Consumables cabinet", main),
        ("WIP-SAW", "wip", False, "Saw line-side", main), ("WIP-CNC", "wip", False, "Machining line-side", main),
        ("WIP-ASSY", "wip", False, "Assembly/test/pack line-side", main),
        ("FG-HOLD", "finished", False, "Finished goods awaiting quality release", main),
        ("FG-01", "finished", True, "Released finished goods", main),
        ("DSP-01", "dispatch", False, "Dispatch bay", main), ("SCR-01", "scrap", False, "Scrap and recoverable scrap", main),
        ("RTN-01", "returns", False, "Customer returns awaiting review", main),
        ("SUB-HDA-01", "subcontractor", False, "At Hardcastle Anodising (company-owned)", subw),
        ("CAL-ST-01", "storage", True, "Calder stores", calw),
    ]:
        b = Bin(warehouse_id=wh.id, code=code, kind=kind, allocatable=alloc, description=desc)
        db.add(b)
        bins[code] = b
    wc = {}
    for code, name, lab, mach, var, sub in [
        ("SAW", "Bandsaw cell", "32", "18", "4", False), ("CNC", "CNC machining", "32", "45", "9", False),
        ("ASSY", "Assembly benches", "30", "0", "0", False), ("TEST", "Electrical safety test", "30", "12", "1.5", False),
        ("PACK", "Packing", "28", "0", "0", False), ("SUBCON", "Subcontract operations", "0", "0", "0", True),
    ]:
        w = WorkCentre(site_id=pen.id, code=code, name=name, calendar=SHIFT, labour_rate=Decimal(lab), machine_rate=Decimal(mach),
                       machine_variable_rate=Decimal(var), is_subcontract=sub)
        db.add(w)
        wc[code] = w
    db.flush()
    eq = {}
    for code, name, kind, cat, w, calreq, ideal, adapter in [
        ("SAW-01", "Horizontal bandsaw", "bandsaw", "machine", "SAW", False, 72, "sim"),
        ("CNC-01", "CNC vertical machining centre 1", "cnc_mill", "machine", "CNC", False, 840, "sim"),
        ("CNC-02", "CNC vertical machining centre 2", "cnc_mill", "machine", "CNC", False, 840, "sim"),
        ("BENCH-01", "Assembly bench 1", "assembly_bench", "station", "ASSY", False, None, None),
        ("BENCH-02", "Assembly bench 2", "assembly_bench", "station", "ASSY", False, None, None),
        ("PAT-01", "Electrical safety tester (earth bond / insulation)", "safety_tester", "station", "TEST", True, 120, None),
        ("PACK-01", "Packing station", "packing_station", "station", "PACK", False, None, None),
        ("CAL-DIG-01", "Digital caliper 0–300 mm", "caliper", "gauge", None, True, None, None),
        ("CAL-DIG-02", "Digital caliper 0–300 mm (spare)", "caliper", "gauge", None, True, None, None),
        ("BORE-01", "Bore gauge 35–50 mm", "bore_gauge", "gauge", None, True, None, None),
        ("SCALE-01", "Platform scale 150 kg", "scale", "gauge", None, True, None, None),
        ("CTG-01", "Coating thickness gauge", "coating_gauge", "gauge", None, True, None, None),
    ]:
        e = Equipment(site_id=pen.id, code=code, name=name, kind=kind, category=cat, work_centre_id=wc[w].id if w else None,
                      calibration_required=calreq, ideal_cycle_seconds=Decimal(ideal) if ideal else None, adapter_ref=adapter)
        db.add(e)
        eq[code] = e
    db.flush()
    for code, ref, on, due, res in [
        ("PAT-01", "CAL-PAT-2611", date(2026, 9, 1), date(2027, 3, 1), "pass"),
        ("CAL-DIG-01", "CAL-DG1-2604", date(2026, 4, 20), date(2027, 4, 20), "pass"),
        ("CAL-DIG-02", "CAL-DG2-2510", date(2025, 10, 15), date(2026, 10, 15), "pass"),  # EXPIRED before scenario
        ("BORE-01", "CAL-BG1-2606", date(2026, 6, 2), date(2027, 6, 2), "pass"),
        ("SCALE-01", "CAL-SC1-2607", date(2026, 7, 7), date(2027, 7, 7), "pass"),
        ("CTG-01", "CAL-CT1-2608", date(2026, 8, 11), date(2027, 8, 11), "pass"),
    ]:
        db.add(CalibrationRecord(equipment_id=eq[code].id, certificate_ref=ref, calibrated_on=on, due_on=due, result=res,
                                 provider="Pennine Metrology Services (fictional)", recorded_by=users["sgreenwood"].id))
        eq[code].calibration_due = due
    for code in ("CNC-01", "CNC-02"):
        db.add(ServiceSchedule(equipment_id=eq[code].id, description="Monthly spindle and coolant service", interval_days=30,
                               duration_minutes=120, last_done=date(2026, 10, 20), next_due=date(2026, 11, 19)))
    db.add_all([
        OverheadRule(code="OH-PROD", description="Factory overhead (rent, supervision, utilities) per labour hour",
                     basis="labour_hours", rate=Decimal("18.00"), behaviour="fixed", effective_from=date(2026, 1, 1)),
        OverheadRule(code="OH-STORES", description="Materials handling overhead (% of material cost)",
                     basis="material_cost_pct", rate=Decimal("4.0"), behaviour="fixed", effective_from=date(2026, 1, 1)),
    ])
    for code, desc, kind, bands in [
        ("SP-INC", "Incoming attribute sampling (configurable bands, c=0)", "bands",
         [{"max_lot": 15, "sample": 2, "accept": 0}, {"max_lot": 50, "sample": 5, "accept": 0},
          {"max_lot": 150, "sample": 13, "accept": 0}, {"max_lot": 500, "sample": 20, "accept": 0}, {"max_lot": None, "sample": 32, "accept": 0}]),
        ("SP-FIX3", "Fixed sample of 3", "bands", [{"max_lot": None, "sample": 3, "accept": 0}]),
        ("SP-DOC", "Document / single check", "bands", [{"max_lot": None, "sample": 1, "accept": 0}]),
        ("SP-100", "100% inspection", "full", []),
        ("SP-FINAL", "Final sampling (configurable bands, c=0)", "bands",
         [{"max_lot": 8, "sample": 3, "accept": 0}, {"max_lot": 50, "sample": 8, "accept": 0},
          {"max_lot": 150, "sample": 13, "accept": 0}, {"max_lot": None, "sample": 20, "accept": 0}]),
    ]:
        db.add(SamplingPlan(code=code, description=desc, kind=kind, bands=bands))
    db.flush()
    return {"sites": {"PEN": pen, "CAL": cal}, "users": users, "suppliers": sup, "bins": bins, "wc": wc, "eq": eq}


def S(name, value=None, unit=None, status="specified", tol=None, source=None):
    return {"name": name, "value": value, "unit": unit, "status": status, "tolerance": tol, "source": source}


ITEMS = [
    dict(item_code="RM-AL6082-50", description="Aluminium round bar 6082-T6, Ø50 mm", item_type="raw_material", base_unit="kg",
         make_or_buy="buy", lead_time_days=5, lot_size_multiple=Decimal(25), standard_cost=Decimal("4.20"), standard_cost_currency="GBP",
         storage_requirements="Dry rack; keep off floor", specifications=[
             S("Alloy", "6082", source="supplier certificate"), S("Temper", "T6", source="supplier certificate"),
             S("Diameter", "50", "mm", tol="±0.2"), S("Tensile strength (min)", "295", "MPa", source="supplier certificate"),
             S("Surface finish", status="unknown")]),
    dict(item_code="SC-AL-SWARF", description="Aluminium swarf and offcuts (6082), recoverable", item_type="recoverable_scrap",
         base_unit="kg", make_or_buy="make", incoming_inspection_required=False, standard_cost=Decimal("0.90"), standard_cost_currency="GBP"),
    dict(item_code="WIP-HSG-L100-MC", standard_batch_quantity=Decimal(100), description="BL-100 lamp housing, machined (before anodising)", item_type="wip", base_unit="pc",
         make_or_buy="make", lead_time_days=5, specifications=[S("Bore diameter", "38.05", "mm", tol="±0.05"), S("Length", "240", "mm", tol="±0.2")]),
    dict(item_code="SA-HSG-L100", standard_batch_quantity=Decimal(100), description="BL-100 lamp housing, anodised black", item_type="subassembly", base_unit="pc",
         make_or_buy="subcon", lead_time_days=7, specifications=[S("Anodise thickness", "15–25", "µm"), S("Colour", "black"),
                                                                 S("Salt-spray resistance", status="unknown")]),
    dict(item_code="PC-LED-M12", description="LED light module 12 W, 230 V AC integral driver, 5000 K", item_type="purchased_component",
         base_unit="pc", lead_time_days=10, lot_size_min=Decimal(50), lot_size_multiple=Decimal(50), standard_cost=Decimal("18.20"),
         standard_cost_currency="EUR", specifications=[S("Power", "12", "W"), S("Supply", "230 V AC 50 Hz"), S("Colour temperature", "5000", "K"),
                                                       S("CRI (min)", "90"), S("IP rating", status="unknown")]),
    dict(item_code="PC-LED-M12-ALT", description="LED light module 12 W, 230 V AC, 5000 K (approved second source)",
         item_type="purchased_component", base_unit="pc", lead_time_days=14, standard_cost=Decimal("19.90"), standard_cost_currency="GBP",
         specifications=[S("Power", "12", "W"), S("Supply", "230 V AC 50 Hz"), S("Colour temperature", "5000", "K"), S("CRI (min)", "90"),
                         S("IP rating", status="unknown")]),
    dict(item_code="PC-CBL-3C075", description="Flexible cable 3-core 0.75 mm², PVC, grey", item_type="purchased_component",
         base_unit="m", lead_time_days=4, lot_size_multiple=Decimal(50), standard_cost=Decimal("0.62"), standard_cost_currency="GBP",
         specifications=[S("Cores", "3"), S("Conductor size", "0.75", "mm²"), S("Sheath", "PVC grey"), S("Outer diameter", "6.4", "mm", tol="±0.4")]),
    dict(item_code="PC-FST-M5X12", description="Socket cap screw M5×12, A2 stainless", item_type="purchased_component", base_unit="pc",
         lead_time_days=3, lot_size_multiple=Decimal(100), standard_cost=Decimal("0.045"), standard_cost_currency="GBP",
         specifications=[S("Thread", "M5×0.8"), S("Length", "12", "mm"), S("Material", "A2 stainless")]),
    dict(item_code="PK-CTN-L100", description="Shipping carton 320×220×160 mm, printed", item_type="packaging", base_unit="pc",
         lead_time_days=4, lot_size_multiple=Decimal(50), standard_cost=Decimal("0.95"), standard_cost_currency="GBP"),
    dict(item_code="PK-FOAM-L100", description="Foam insert set for BL-100", item_type="packaging", base_unit="pc", lead_time_days=4,
         lot_size_multiple=Decimal(50), standard_cost=Decimal("0.60"), standard_cost_currency="GBP"),
    dict(item_code="PK-LBL-L100", description="Product rating and serial label", item_type="packaging", base_unit="pc", lead_time_days=4,
         lot_size_multiple=Decimal(100), standard_cost=Decimal("0.04"), standard_cost_currency="GBP"),
    dict(item_code="CN-CUTFLUID", description="Water-soluble cutting fluid concentrate", item_type="consumable", base_unit="L",
         lead_time_days=5, shelf_life_applicable=True, shelf_life_days=365, standard_cost=Decimal("6.50"), standard_cost_currency="GBP",
         storage_requirements="5–30 °C, keep sealed"),
    dict(item_code="FG-L100", standard_batch_quantity=Decimal(100), description="Pennine BL-100 bench-mounted inspection lamp", item_type="finished_product", base_unit="pc",
         lot_or_serial_policy="serial", make_or_buy="make", lead_time_days=5, specifications=[
             S("Rated supply", "230 V AC 50 Hz"), S("Protection class", "Class I (earthed housing)"), S("Light output", status="unknown"),
             S("IP rating", status="unknown"), S("Conformity marking", status="unknown",
                                                 source="not assessed — no product certification is recorded")]),
]


def seed_items(ctx: Ctx, ref: dict) -> dict:
    from ..modules.registry.service import approve_conversion, create_item, propose_conversion

    items = {}
    for d in ITEMS:
        items[d["item_code"]] = create_item(ctx, {**d, "lot_or_serial_policy": d.get("lot_or_serial_policy", "lot")})
    items["RM-AL6082-50"].recoverable_scrap_item_id = items["SC-AL-SWARF"].id
    ctx.db.flush()
    return items


def seed_conversions_and_refs(engineer: Ctx, approver: Ctx, items: dict, ref: dict) -> None:
    from ..modules.registry.service import approve_conversion, propose_conversion

    for code, fu, tu, f, basis in [
        ("RM-AL6082-50", "m", "kg", "5.301", "π × (0.025 m)² × 2700 kg/m³ = 5.301 kg/m (nominal density 2.70 g/cm³)"),
        ("PC-CBL-3C075", "reel", "m", "50", "Supplier reel length 50 m (Cragg Vale catalogue)"),
        ("PC-FST-M5X12", "pack", "pc", "100", "Pack of 100 (Heptonstall Fixings)"),
    ]:
        c = propose_conversion(engineer, items[code].id, fu, tu, Decimal(f), basis)
        approve_conversion(approver, c.id)
    s = ref["suppliers"]
    pd = datetime(2026, 10, 1, tzinfo=TZ)
    for code, sup, part, unit, price, cur, lead, moq, pref in [
        ("RM-AL6082-50", "BRK", "BRK-6082T6-50", "kg", "4.35", "GBP", 5, 25, True),
        ("RM-AL6082-50", "STB", "STB-R50-6082", "kg", "4.10", "GBP", 3, 25, False),
        ("PC-LED-M12", "LMH", "LMH-M12-5000-230", "pc", "18.20", "EUR", 10, 50, True),
        ("PC-LED-M12-ALT", "LMA", "LA-12W-5K", "pc", "19.90", "GBP", 14, 10, True),
        ("PC-CBL-3C075", "CVC", "CVC-3075-GRY-50", "reel", "30.50", "GBP", 4, 1, True),
        ("PC-FST-M5X12", "HPF", "HPF-SHCS-M5-12-A2", "pack", "4.20", "GBP", 3, 1, True),
        ("PK-CTN-L100", "MYP", "MYP-CTN-322216", "pc", "0.95", "GBP", 4, 50, True),
        ("PK-FOAM-L100", "MYP", "MYP-FOAM-BL100", "pc", "0.60", "GBP", 4, 50, True),
        ("PK-LBL-L100", "MYP", "MYP-LBL-BL100", "pc", "0.04", "GBP", 4, 100, True),
        ("SA-HSG-L100", "HDA", "HDA-ANOD-BLK-L100", "pc", "3.80", "GBP", 7, 1, True),
    ]:
        engineer.db.add(ItemSupplierRef(item_id=items[code].id, supplier_id=s[sup].id, supplier_part_number=part, purchase_unit=unit,
                                        price=Decimal(price), currency=cur, price_date=pd, lead_time_days=lead,
                                        min_order_qty=Decimal(moq), preferred=pref))
    engineer.db.flush()


def seed_engineering(engineer: Ctx, approver: Ctx, items: dict, ref: dict) -> dict:
    wc, sup = ref["wc"], ref["suppliers"]
    I = lambda c: items[c].id
    eff = date(2026, 10, 1)
    boms = {}
    boms["WIP"] = create_bom(engineer, I("WIP-HSG-L100-MC"), {"expected_yield_pct": Decimal(97), "effective_from": eff,
        "change_note": "Initial release", "lines": [
            {"component_item_id": I("RM-AL6082-50"), "quantity": Decimal("0.25"), "unit": "m", "loss_pct": Decimal(4),
             "scrap_basis": "allowance_in_quantity", "allowance_note": "240 mm finished length + 10 mm saw kerf and facing allowance",
             "operation_seq": 10}]})
    boms["SA"] = create_bom(engineer, I("SA-HSG-L100"), {"expected_yield_pct": Decimal(99), "effective_from": eff, "lines": [
        {"component_item_id": I("WIP-HSG-L100-MC"), "quantity": 1, "unit": "pc", "operation_seq": 10}]})
    boms["FG"] = create_bom(engineer, I("FG-L100"), {"expected_yield_pct": Decimal(100), "effective_from": eff,
        "change_note": "Initial release", "lines": [
            {"component_item_id": I("SA-HSG-L100"), "quantity": 1, "unit": "pc", "operation_seq": 10},
            {"component_item_id": I("PC-LED-M12"), "quantity": 1, "unit": "pc", "operation_seq": 10, "alternative_group": "LED",
             "alternative_priority": 1},
            {"component_item_id": I("PC-LED-M12-ALT"), "quantity": 1, "unit": "pc", "operation_seq": 10, "alternative_group": "LED",
             "alternative_priority": 2, "alternative_approved": True},
            {"component_item_id": I("PC-CBL-3C075"), "quantity": Decimal("1.75"), "unit": "m", "loss_pct": Decimal(3),
             "operation_seq": 10},
            {"component_item_id": I("PC-FST-M5X12"), "quantity": 4, "unit": "pc", "loss_pct": Decimal(2), "operation_seq": 10},
            {"component_item_id": I("PK-CTN-L100"), "quantity": 1, "unit": "pc", "backflush": True, "operation_seq": 30},
            {"component_item_id": I("PK-FOAM-L100"), "quantity": 1, "unit": "pc", "backflush": True, "operation_seq": 30},
            {"component_item_id": I("PK-LBL-L100"), "quantity": 1, "unit": "pc", "backflush": True, "operation_seq": 30},
        ]})
    for b in boms.values():
        approve_bom(approver, b.id)
    rts = {}
    rts["WIP"] = create_routing(engineer, I("WIP-HSG-L100-MC"), {"effective_from": eff, "operations": [
        {"seq": 10, "code": "CUT", "name": "Cut bar to blank length", "work_centre_id": wc["SAW"].id, "required_equipment_kind": "bandsaw",
         "required_skill": "saw", "setup_minutes": Decimal(15), "run_minutes_per_unit": Decimal("1.5"), "machine_minutes_per_unit": Decimal("1.2"),
         "instructions": "Cut 250 mm blanks from Ø50 bar (240 mm + 10 mm allowance). Weigh offcut ends back to stores."},
        {"seq": 20, "code": "MACH", "name": "CNC machine housing", "work_centre_id": wc["CNC"].id, "required_equipment_kind": "cnc_mill",
         "required_skill": "cnc", "setup_minutes": Decimal(45), "run_minutes_per_unit": Decimal(14), "machine_minutes_per_unit": Decimal(14),
         "instructions": "Program PMD-HSG-L100 rev A. Bore Ø38.05 ±0.05; length 240 ±0.2. First-off check before batch."},
        {"seq": 30, "code": "INSP", "name": "In-process dimensional inspection", "work_centre_id": wc["CNC"].id,
         "required_skill": "cnc", "run_minutes_per_unit": Decimal("0.5"), "inspection_point": True,
         "inspection_plan_code": "IP-HSG-DIM", "reports_output": True, "instructions": "Sample per plan IP-HSG-DIM with calibrated gauges."},
    ]})
    rts["SA"] = create_routing(engineer, I("SA-HSG-L100"), {"effective_from": eff, "operations": [
        {"seq": 10, "code": "ANOD", "name": "Black anodise (subcontract)", "work_centre_id": wc["SUBCON"].id, "subcontracted": True,
         "subcontract_supplier_id": sup["HDA"].id, "subcontract_lead_days": 5, "reports_output": True,
         "instructions": "Send machined housings to Hardcastle Anodising; black anodise 15–25 µm; return with delivery note and process record."},
    ]})
    rts["FG"] = create_routing(engineer, I("FG-L100"), {"effective_from": eff, "operations": [
        {"seq": 10, "code": "ASSY", "name": "Assemble lamp", "work_centre_id": wc["ASSY"].id, "required_equipment_kind": "assembly_bench",
         "required_skill": "assembly", "setup_minutes": Decimal(10), "run_minutes_per_unit": Decimal(6),
         "instructions": "Fit LED module, terminate 3-core cable (earth to housing stud), fit 4× M5 screws to 3 N·m."},
        {"seq": 20, "code": "TEST", "name": "Electrical safety test (100%)", "work_centre_id": wc["TEST"].id,
         "required_equipment_kind": "safety_tester", "required_skill": "electrical_test", "setup_minutes": Decimal(5),
         "run_minutes_per_unit": Decimal(2), "machine_minutes_per_unit": Decimal(2), "inspection_point": True,
         "inspection_plan_code": "IP-L100-ELEC", "instructions": "Earth bond ≤ 0.10 Ω; insulation ≥ 2.0 MΩ; light-up."},
        {"seq": 30, "code": "PACK", "name": "Label and pack", "work_centre_id": wc["PACK"].id, "required_equipment_kind": "packing_station",
         "required_skill": "packing", "setup_minutes": Decimal(5), "run_minutes_per_unit": Decimal("1.5"), "reports_output": True,
         "instructions": "Apply rating/serial label, foam insert, carton. Packaging is backflushed (calculated) and counted at end of batch."},
    ]})
    rts["FG-RW"] = create_routing(engineer, I("FG-L100"), {"kind": "rework", "effective_from": eff, "change_note": "Approved rework instructions RW-L100-01",
        "operations": [
        {"seq": 10, "code": "RWK", "name": "Rework: re-terminate earth and replace cable", "work_centre_id": wc["ASSY"].id,
         "required_equipment_kind": "assembly_bench", "required_skill": "assembly", "run_minutes_per_unit": Decimal(12),
         "instructions": "RW-L100-01: remove cable, fit new 1.8 m cable, re-terminate earth to stud with new star washer."},
        {"seq": 20, "code": "RETEST", "name": "Re-test (100%)", "work_centre_id": wc["TEST"].id, "required_equipment_kind": "safety_tester",
         "required_skill": "electrical_test", "run_minutes_per_unit": Decimal(2), "machine_minutes_per_unit": Decimal(2),
         "inspection_point": True, "inspection_plan_code": "IP-L100-ELEC"},
        {"seq": 30, "code": "REPACK", "name": "Re-pack", "work_centre_id": wc["PACK"].id, "required_equipment_kind": "packing_station",
         "required_skill": "packing", "run_minutes_per_unit": Decimal(2), "reports_output": True},
    ]})
    for r in rts.values():
        approve_routing(approver, r.id)

    sp = {p.code: p for p in engineer.db.query(SamplingPlan).all()}
    for code, item, stage, plan, chars in [
        ("INC-AL6082", "RM-AL6082-50", "incoming", "SP-FIX3", [
            {"name": "Mill certificate: alloy and temper", "kind": "document"},
            {"name": "Diameter", "kind": "variable", "nominal": 50, "lower": 49.8, "upper": 50.2, "unit": "mm", "gauge_kind": "caliper"},
            {"name": "Visual condition", "kind": "attribute"}]),
        ("INC-LED", "PC-LED-M12", "incoming", "SP-INC", [
            {"name": "Visual and connector", "kind": "attribute"}, {"name": "Light-up check", "kind": "attribute"}]),
        ("INC-CBL", "PC-CBL-3C075", "incoming", "SP-DOC", [
            {"name": "Cable marking (3G0.75)", "kind": "attribute"},
            {"name": "Outer diameter", "kind": "variable", "lower": 6.0, "upper": 6.8, "unit": "mm", "gauge_kind": "caliper"}]),
        ("INC-FST", "PC-FST-M5X12", "incoming", "SP-DOC", [{"name": "Certificate of conformity", "kind": "document"}]),
        ("INC-CTN", "PK-CTN-L100", "incoming", "SP-DOC", [{"name": "Print and dimensions", "kind": "attribute"}]),
        ("INC-FOAM", "PK-FOAM-L100", "incoming", "SP-DOC", [{"name": "Print and dimensions", "kind": "attribute"}]),
        ("INC-SA-HSG", "SA-HSG-L100", "incoming", "SP-INC", [
            {"name": "Anodise finish visual", "kind": "attribute"},
            {"name": "Coating thickness", "kind": "variable", "lower": 15, "upper": 25, "unit": "µm", "gauge_kind": "coating_gauge"}]),
        ("IP-HSG-DIM", "WIP-HSG-L100-MC", "in_process", "SP-FINAL", [
            {"name": "Bore diameter", "kind": "variable", "nominal": 38.05, "lower": 38.00, "upper": 38.10, "unit": "mm", "gauge_kind": "caliper"},
            {"name": "Overall length", "kind": "variable", "nominal": 240, "lower": 239.8, "upper": 240.2, "unit": "mm", "gauge_kind": "caliper"}]),
        ("IP-L100-ELEC", "FG-L100", "in_process", "SP-100", [
            {"name": "Earth bond resistance", "kind": "variable", "upper": 0.10, "unit": "Ω", "gauge_kind": "safety_tester"},
            {"name": "Insulation resistance", "kind": "variable", "lower": 2.0, "unit": "MΩ", "gauge_kind": "safety_tester"},
            {"name": "Light-up", "kind": "attribute"}]),
        ("FI-L100", "FG-L100", "final", "SP-FINAL", [
            {"name": "Visual finish", "kind": "attribute"}, {"name": "Label legible, serial matches", "kind": "attribute"},
            {"name": "Arm articulation torque", "kind": "variable", "lower": 1.0, "upper": 2.0, "unit": "N·m"},
            {"name": "Functional check", "kind": "attribute"}]),
    ]:
        engineer.db.add(InspectionPlan(code=code, item_id=items[item].id, stage=stage, sampling_plan_id=sp[plan].id, characteristics=chars))
    engineer.db.flush()
    return {"boms": boms, "routings": rts}


OPENING = [
    # item, lot, qty, bin, supplier, supplier_lot, traceability, note, unit cost
    ("RM-AL6082-50", "OPEN-AL-01", "40", "RM-A1", "BRK", "BRK-HT-2291", "complete", None, "4.30"),
    ("PC-LED-M12", "OPEN-LED-01", "10", "CMP-01", None, None, "partial",
     "Pre-system stock: supplier and supplier lot were not recorded in legacy records", "15.50"),
    ("PC-CBL-3C075", "OPEN-CBL-01", "30", "CMP-01", "CVC", "CV-5512", "complete", None, "0.61"),
    ("PC-FST-M5X12", "OPEN-FST-01", "250", "CMP-01", "HPF", "HF-7702", "complete", None, "0.042"),
    ("PK-CTN-L100", "OPEN-CTN-01", "20", "PKG-01", "MYP", "MY-1180", "complete", None, "0.95"),
    ("PK-FOAM-L100", "OPEN-FOAM-01", "20", "PKG-01", "MYP", "MY-1181", "complete", None, "0.60"),
    ("PK-LBL-L100", "OPEN-LBL-01", "200", "PKG-01", "MYP", "MY-1175", "complete", None, "0.04"),
    ("CN-CUTFLUID", "OPEN-CF-01", "10", "CON-01", None, None, "partial", "Legacy stock", "6.50"),
]


def seed_opening_stock(store: Ctx, items: dict, ref: dict) -> None:
    from ..modules.inventory.models import LotStatusHistory

    for code, lot_no, qty, bin_code, sup, slot, trace, note, cost in OPENING:
        item = items[code]
        lot = create_lot(store, item, lot_no, "opening", quality_status="accepted",
                         supplier_id=ref["suppliers"][sup].id if sup else None, supplier_lot=slot, traceability=trace,
                         traceability_note=note or "Opening balance carried from legacy records",
                         unit_cost=Decimal(cost), cost_basis="opening balance valuation", manufactured_on=date(2026, 9, 1))
        post_movement(store, "adjustment", item, Decimal(qty), item.base_unit, lot=lot, to_bin=ref["bins"][bin_code],
                      reason_code="opening_balance", notes="Opening balance (demonstrator data)", observed_at=T(2, "06:30"),
                      skip_quality_gate=True)
