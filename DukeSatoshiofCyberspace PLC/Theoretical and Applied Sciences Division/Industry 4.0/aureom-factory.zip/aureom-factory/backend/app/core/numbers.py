"""Decimal helpers. Floating point is never used for quantities or money."""
from __future__ import annotations

from decimal import ROUND_CEILING, ROUND_HALF_UP, Decimal, InvalidOperation

QTY_PLACES = Decimal("0.000001")
MONEY_PLACES = Decimal("0.0001")
ZERO = Decimal("0")


def D(value) -> Decimal:
    if value is None:
        return ZERO
    if isinstance(value, Decimal):
        return value
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:  # pragma: no cover - defensive
        raise ValueError(f"not a decimal: {value!r}") from exc


def q(value) -> Decimal:
    return D(value).quantize(QTY_PLACES, rounding=ROUND_HALF_UP)


def money(value) -> Decimal:
    return D(value).quantize(MONEY_PLACES, rounding=ROUND_HALF_UP)


def ceil_to(value: Decimal, step: Decimal) -> Decimal:
    """Round value up to a multiple of step (step > 0)."""
    value, step = D(value), D(step)
    if step <= 0:
        return value
    n = (value / step).to_integral_value(rounding=ROUND_CEILING)
    return q(n * step)


def ceil_int(value: Decimal) -> Decimal:
    return D(value).to_integral_value(rounding=ROUND_CEILING)


def fmt(value) -> str:
    """Render a decimal without trailing zeros (for messages)."""
    d = D(value).normalize()
    return format(d, "f")
