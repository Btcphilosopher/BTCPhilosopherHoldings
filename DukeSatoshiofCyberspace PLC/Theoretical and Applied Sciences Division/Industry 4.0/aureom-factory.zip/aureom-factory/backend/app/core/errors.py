"""Domain errors mapped to HTTP responses with stable machine-readable codes."""
from __future__ import annotations

from typing import Any


class DomainError(Exception):
    status_code = 422
    code = "domain_error"

    def __init__(self, message: str, *, code: str | None = None, details: Any = None):
        super().__init__(message)
        self.message = message
        if code:
            self.code = code
        self.details = details


class NotFound(DomainError):
    status_code = 404
    code = "not_found"


class PermissionDenied(DomainError):
    status_code = 403
    code = "permission_denied"


class Unauthenticated(DomainError):
    status_code = 401
    code = "unauthenticated"


class Conflict(DomainError):
    """Optimistic-concurrency or state conflicts."""

    status_code = 409
    code = "conflict"


class InvalidState(DomainError):
    status_code = 409
    code = "invalid_state"


class ValidationFailed(DomainError):
    status_code = 422
    code = "validation_failed"


class UnitConversionError(ValidationFailed):
    code = "unit_conversion_unavailable"


class InsufficientStock(DomainError):
    status_code = 409
    code = "insufficient_stock"


class QualityHold(DomainError):
    status_code = 409
    code = "quality_hold"


class BomCycleError(ValidationFailed):
    code = "bom_cycle"
