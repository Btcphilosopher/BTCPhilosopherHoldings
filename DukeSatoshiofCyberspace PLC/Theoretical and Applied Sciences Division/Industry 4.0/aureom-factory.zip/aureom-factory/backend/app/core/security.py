"""Password hashing, signed bearer tokens, and the role → permission model.

Permissions are site-scoped: a role assignment with site_id NULL applies to every site,
otherwise only to that site. Restricted approvals (engineering approval, quality release
and disposition, purchase approval, production release/cancel, scrap authorisation) are
held only by named roles and are never granted to operators.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import json
import os
import time

from ..config import settings
from .errors import Unauthenticated

# --------------------------------------------------------------------------- passwords


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return "scrypt$" + base64.b64encode(salt).decode() + "$" + base64.b64encode(dk).decode()


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, salt_b64, dk_b64 = stored.split("$")
    except ValueError:
        return False
    if scheme != "scrypt":
        return False
    salt = base64.b64decode(salt_b64)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return hmac.compare_digest(dk, base64.b64decode(dk_b64))


# --------------------------------------------------------------------------- tokens


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def _unb64(data: str) -> bytes:
    return base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))


def sign(payload: dict, ttl_seconds: int | None = None, purpose: str = "auth") -> str:
    body = dict(payload)
    body["exp"] = int(time.time()) + (ttl_seconds or settings.token_ttl_minutes * 60)
    body["pur"] = purpose
    raw = _b64(json.dumps(body, separators=(",", ":"), sort_keys=True).encode())
    mac = hmac.new(settings.secret_key.encode(), raw.encode(), hashlib.sha256).digest()
    return raw + "." + _b64(mac)


def unsign(token: str, purpose: str = "auth") -> dict:
    try:
        raw, mac = token.split(".")
        given = _unb64(mac)
    except (ValueError, binascii.Error) as exc:
        raise Unauthenticated("Malformed token") from exc
    expected = hmac.new(settings.secret_key.encode(), raw.encode(), hashlib.sha256).digest()
    if not hmac.compare_digest(expected, given):
        raise Unauthenticated("Invalid token signature")
    try:
        body = json.loads(_unb64(raw))
    except (ValueError, binascii.Error) as exc:
        raise Unauthenticated("Malformed token") from exc
    if body.get("pur") != purpose:
        raise Unauthenticated("Token not valid for this purpose")
    if body.get("exp", 0) < time.time():
        raise Unauthenticated("Token expired")
    return body


# --------------------------------------------------------------------------- permissions

READ_ALL = {
    "registry.read", "engineering.read", "purchasing.read", "inventory.read", "planning.read",
    "production.read", "quality.read", "maintenance.read", "costing.read", "dispatch.read",
    "reports.read", "documents.read",
}

ROLE_PERMISSIONS: dict[str, set[str]] = {
    "admin": {"*"},
    "viewer": set(READ_ALL),
    "engineer": READ_ALL | {"registry.edit", "engineering.edit", "documents.upload"},
    # Restricted: approval of BOM/routing revisions and unit conversions.
    "engineering_approver": READ_ALL | {"engineering.approve", "registry.approve_conversion"},
    "planner": READ_ALL | {
        "planning.run", "planning.accept", "production.create", "production.plan",
        "purchasing.requisition", "dispatch.order",
    },
    "production_manager": READ_ALL | {
        "planning.run", "planning.accept", "production.create", "production.plan", "production.release",
        "production.cancel", "production.close", "production.authorise_scrap", "production.rework",
        "production.reconcile_offline", "inventory.reserve", "production.execute",
    },
    "buyer": READ_ALL | {"purchasing.requisition", "purchasing.order", "purchasing.invoice", "purchasing.return"},
    "purchasing_manager": READ_ALL | {
        "purchasing.requisition", "purchasing.order", "purchasing.approve", "purchasing.invoice",
        "purchasing.return", "purchasing.approve_substitution",
    },
    "storekeeper": READ_ALL | {
        "purchasing.receive", "inventory.move", "inventory.reserve", "inventory.adjust",
        "dispatch.pick", "purchasing.return", "documents.upload",
    },
    "operator": {
        "registry.read", "engineering.read", "inventory.read", "production.read", "quality.read",
        "maintenance.read", "documents.read", "production.execute", "quality.record", "quality.raise_ncr",
    },
    "quality_inspector": READ_ALL | {"quality.record", "quality.raise_ncr", "documents.upload"},
    # Restricted: release and disposition decisions.
    "quality_manager": READ_ALL | {
        "quality.record", "quality.raise_ncr", "quality.release", "quality.disposition", "quality.capa",
        "quality.correct", "dispatch.recall", "documents.upload",
    },
    "maintenance": READ_ALL | {"maintenance.edit", "documents.upload"},
    "cost_accountant": READ_ALL | {"costing.edit", "costing.export"},
    "dispatcher": READ_ALL | {"dispatch.order", "dispatch.pick", "dispatch.ship", "dispatch.returns", "inventory.reserve"},
}


def role_grants(role: str, permission: str) -> bool:
    perms = ROLE_PERMISSIONS.get(role, set())
    if "*" in perms or permission in perms:
        return True
    module = permission.split(".")[0]
    return f"{module}.*" in perms
