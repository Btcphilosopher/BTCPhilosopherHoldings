"""Authentication, sites, audit trail, notifications, jobs and system information."""
from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..adapters.registry import adapters
from ..api_deps import Body, CtxDep, load_user
from ..config import settings
from ..db import get_session
from .context import row_dict, utcnow
from .errors import NotFound, Unauthenticated
from .models import AuditLog, Job, Notification, OfflineEntry, Site, User
from .security import ROLE_PERMISSIONS, sign, verify_password

router = APIRouter(prefix="/api", tags=["core"])


class LoginBody(Body):
    username: str
    password: str


@router.post("/auth/login")
def login(body: LoginBody, db: Annotated[Session, Depends(get_session)]):
    user = db.execute(select(User).where(User.username == body.username)).scalar_one_or_none()
    if user is None or not user.active or not verify_password(body.password, user.password_hash):
        raise Unauthenticated("Invalid username or password")
    user = load_user(db, user.id)
    sites = sorted({r.site_id for r in user.roles if r.site_id})
    return {"token": sign({"uid": user.id, "site": sites[0] if sites else 1}), "user": _me(user)}


def _me(user: User) -> dict:
    perms = set()
    for r in user.roles:
        perms |= ROLE_PERMISSIONS.get(r.role, set())
    return {"id": user.id, "username": user.username, "full_name": user.full_name, "skills": user.skills,
            "roles": [{"role": r.role, "site_id": r.site_id} for r in user.roles], "permissions": sorted(perms)}


@router.get("/auth/me")
def me(ctx: CtxDep):
    return {**_me(ctx.user), "site_id": ctx.site_id}


@router.get("/sites")
def sites(ctx: CtxDep):
    return [row_dict(s) for s in ctx.db.execute(select(Site).order_by(Site.id)).scalars()]


@router.get("/users")
def users(ctx: CtxDep):
    ctx.require("reports.read")
    return [{"id": u.id, "username": u.username, "full_name": u.full_name, "skills": u.skills}
            for u in ctx.db.execute(select(User).order_by(User.id)).scalars()]


@router.get("/audit")
def audit(ctx: CtxDep, entity_type: str | None = None, entity_id: str | None = None, limit: int = Query(100, le=1000)):
    ctx.require("reports.read")
    stmt = select(AuditLog).order_by(AuditLog.id.desc()).limit(limit)
    if entity_type:
        stmt = stmt.where(AuditLog.entity_type == entity_type)
    if entity_id:
        stmt = stmt.where(AuditLog.entity_id == entity_id)
    out = []
    names = {u.id: u.full_name for u in ctx.db.execute(select(User)).scalars()}
    for a in ctx.db.execute(stmt).scalars():
        out.append({**row_dict(a), "user": names.get(a.user_id)})
    return out


@router.get("/notifications")
def notifications(ctx: CtxDep, limit: int = 50):
    roles = [r.role for r in ctx.user.roles]
    stmt = select(Notification).where((Notification.user_id == ctx.user.id) | (Notification.audience_role.in_(roles)) |
                                      (Notification.audience_role.is_(None) & Notification.user_id.is_(None)))
    return [row_dict(n) for n in ctx.db.execute(stmt.order_by(Notification.id.desc()).limit(limit)).scalars()]


@router.post("/notifications/{nid}/read")
def read_notification(nid: int, ctx: CtxDep):
    n = ctx.get(Notification, nid)
    roles = {r.role for r in ctx.user.roles}
    if n.user_id not in (None, ctx.user.id) or (n.audience_role and n.audience_role not in roles):
        raise NotFound("Notification not found")
    n.read_at = utcnow()
    return {"ok": True}


class JobBody(Body):
    kind: str
    payload: dict = {}
    dedupe_key: str | None = None


ALLOWED_JOBS = {"mrp_run": "planning.run", "schedule_run": "production.plan", "import_items": "registry.edit",
                "machine_poll": "maintenance.read", "report_traceability": "reports.read", "notify_overdue": "reports.read",
                "costing_export": "costing.export"}


@router.post("/jobs")
def enqueue(body: JobBody, ctx: CtxDep):
    if body.kind not in ALLOWED_JOBS:
        raise NotFound(f"Unknown job kind {body.kind}")
    ctx.require(ALLOWED_JOBS[body.kind])
    if body.dedupe_key:
        existing = ctx.db.execute(select(Job).where(Job.dedupe_key == body.dedupe_key)).scalar_one_or_none()
        if existing:
            return row_dict(existing)
    job = Job(kind=body.kind, payload={**body.payload, "site_id": body.payload.get("site_id", ctx.site_id)},
              requested_by=ctx.user.id, dedupe_key=body.dedupe_key)
    ctx.db.add(job)
    ctx.db.flush()
    return row_dict(job)


@router.get("/jobs")
def jobs(ctx: CtxDep, limit: int = 50):
    ctx.require("reports.read")
    return [row_dict(j) for j in ctx.db.execute(select(Job).order_by(Job.id.desc()).limit(limit)).scalars()]


@router.get("/jobs/{job_id}")
def job(job_id: int, ctx: CtxDep):
    ctx.require("reports.read")
    return row_dict(ctx.get(Job, job_id))


@router.get("/system/info")
def info(ctx: CtxDep):
    return {
        "product": "AUREOM FACTORY — Materials to Finished Goods", "environment": settings.environment,
        "base_currency": settings.base_currency, "adapters": adapters().describe(),
        "capabilities": {
            "machine_control": "not available (read-only machine adapter by design)",
            "regulated_sector_readiness": "not assessed — see docs/REGULATORY.md",
            "general_ledger": "not provided — accounting exports only",
        },
    }


@router.get("/health")
def health(db: Annotated[Session, Depends(get_session)]):
    db.execute(select(1))
    return {"status": "ok"}
