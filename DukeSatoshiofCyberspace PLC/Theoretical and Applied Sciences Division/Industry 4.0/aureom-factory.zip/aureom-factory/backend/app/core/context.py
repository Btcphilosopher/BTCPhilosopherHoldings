"""Request/operation context: who is acting, where, and in which transaction.

Every service function takes a Ctx so that permission checks, audit records and
operational events are applied uniformly whether the call comes from the API,
a background worker or the demonstration runner.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from decimal import Decimal
from enum import Enum
from typing import Any

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from .errors import Conflict, NotFound, PermissionDenied
from .models import AuditLog, NumberSequence, User
from .security import role_grants


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def jsonable(value: Any) -> Any:
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, dict):
        return {k: jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [jsonable(v) for v in value]
    return value


def row_dict(obj: Any, fields: list[str] | None = None) -> dict:
    if obj is None:
        return {}
    cols = fields or [c.key for c in obj.__table__.columns]
    return {c: jsonable(getattr(obj, c)) for c in cols}


@dataclass
class Ctx:
    db: Session
    user: User
    site_id: int | None = None
    _events: list[tuple[str, dict]] = field(default_factory=list)

    # ---------------------------------------------------------------- permissions
    def can(self, permission: str, site_id: int | None = None) -> bool:
        target = site_id if site_id is not None else self.site_id
        for r in self.user.roles:
            if r.site_id is not None and target is not None and r.site_id != target:
                continue
            if r.site_id is not None and target is None:
                # site-scoped role but no site context: allow only reads
                if not permission.endswith(".read"):
                    continue
            if role_grants(r.role, permission):
                return True
        return False

    def require(self, permission: str, site_id: int | None = None) -> None:
        if not self.can(permission, site_id):
            raise PermissionDenied(
                f"User '{self.user.username}' lacks permission '{permission}'"
                + (f" at site {site_id}" if site_id else ""),
                details={"permission": permission, "site_id": site_id},
            )

    # ---------------------------------------------------------------- audit + events
    def audit(self, action: str, entity_type: str, entity_id: Any, before: dict | None = None,
              after: dict | None = None, reason: str | None = None, site_id: int | None = None) -> None:
        self.db.add(AuditLog(
            user_id=self.user.id, site_id=site_id or self.site_id, action=action, entity_type=entity_type,
            entity_id=str(entity_id), before=jsonable(before) if before else None,
            after=jsonable(after) if after else None, reason=reason,
        ))

    def emit(self, topic: str, payload: dict) -> None:
        """Queue an operational event. pg_notify is transactional: listeners only see it on commit."""
        body = json.dumps({"topic": topic, "site_id": self.site_id, "data": jsonable(payload)})
        if len(body) > 7900:  # NOTIFY payload limit is 8000 bytes
            body = json.dumps({"topic": topic, "site_id": self.site_id, "data": {"truncated": True}})
        self.db.execute(text("SELECT pg_notify('aureom_events', :b)"), {"b": body})

    # ---------------------------------------------------------------- helpers
    def get(self, model, pk, label: str | None = None):
        obj = self.db.get(model, pk)
        if obj is None:
            raise NotFound(f"{label or model.__name__} {pk} not found")
        return obj

    def next_number(self, prefix: str, width: int = 6) -> str:
        seq = self.db.execute(
            select(NumberSequence).where(NumberSequence.prefix == prefix).with_for_update()
        ).scalar_one_or_none()
        if seq is None:
            seq = NumberSequence(prefix=prefix, next_value=1, width=width)
            self.db.add(seq)
            self.db.flush()
        value = seq.next_value
        seq.next_value = value + 1
        return f"{prefix}-{value:0{seq.width}d}"


def check_version(obj: Any, expected: int | None) -> None:
    """Optimistic concurrency for record edits: caller must send the version it read."""
    if expected is None:
        raise Conflict("A 'version' must be supplied when editing this record")
    if obj.version != expected:
        raise Conflict(
            f"{type(obj).__name__} {obj.id} was changed by someone else (version {obj.version}, you sent {expected})",
            details={"current_version": obj.version},
        )
