from decimal import Decimal

import pytest
from sqlalchemy import text

from app.core.errors import InsufficientStock, InvalidState, QualityHold
from app.modules.genealogy.models import GenealogyEdge
from app.modules.genealogy.service import backward, forward
from app.modules.inventory.service import (
    adjust, bin_by_code, lot_on_hand, merge_lots, reserve, reverse_movement, set_lot_status, split_lot, stock_summary,
    transfer, verify_journal,
)
from tests.helpers import accepted_stock, item, lot


def test_journal_is_append_only(as_user, db):
    l = accepted_stock(as_user("dackroyd"), "PC-FST-M5X12", "T-APP-1", 10)
    db.flush()
    with pytest.raises(Exception) as e:
        with db.begin_nested():
            db.execute(text("UPDATE stock_movements SET quantity = 1 WHERE lot_id = :l"), {"l": l.id})
    assert "append-only" in str(e.value)
    with pytest.raises(Exception):
        with db.begin_nested():
            db.execute(text("DELETE FROM audit_log"))


def test_reversal_is_linked_and_restores_balance(as_user, db):
    store = as_user("dackroyd")
    l = accepted_stock(store, "PC-FST-M5X12", "T-REV-1", 100)
    mv = transfer(store, item(db, "PC-FST-M5X12"), l, bin_by_code(db, "CMP-01"), bin_by_code(db, "QTN-01"), 40, "pc")
    assert lot_on_hand(db, l.id, bin_by_code(db, "QTN-01").id) == 40
    rv = reverse_movement(store, mv.id, "Moved by mistake")
    assert rv.reverses_movement_id == mv.id and rv.movement_type == "reversal"
    assert lot_on_hand(db, l.id, bin_by_code(db, "CMP-01").id) == 100
    with pytest.raises(InvalidState):
        reverse_movement(store, mv.id, "again")
    with pytest.raises(InvalidState):
        reverse_movement(store, rv.id, "reverse the reversal")
    assert verify_journal(db) == []


def test_reversal_cannot_create_negative_stock(as_user, db):
    store = as_user("dackroyd")
    l = accepted_stock(store, "PC-FST-M5X12", "T-REV-2", 10)
    mv = transfer(store, item(db, "PC-FST-M5X12"), l, bin_by_code(db, "CMP-01"), bin_by_code(db, "RM-A2"), 10, "pc")
    transfer(store, item(db, "PC-FST-M5X12"), l, bin_by_code(db, "RM-A2"), bin_by_code(db, "PKG-01"), 6, "pc")
    with pytest.raises(InsufficientStock):
        reverse_movement(store, mv.id, "too late — stock moved on")


def test_negative_stock_is_impossible(as_user, db):
    store = as_user("dackroyd")
    l = accepted_stock(store, "PC-FST-M5X12", "T-NEG-1", 5)
    with pytest.raises(InsufficientStock):
        transfer(store, item(db, "PC-FST-M5X12"), l, bin_by_code(db, "CMP-01"), bin_by_code(db, "RM-A2"), 6, "pc")
    with pytest.raises(InsufficientStock):
        adjust(store, item(db, "PC-FST-M5X12"), l, bin_by_code(db, "CMP-01"), -6, "pc", "count", "stock count")


def test_quarantined_stock_is_physical_but_not_available(as_user, db):
    store, qm = as_user("dackroyd"), as_user("hbrierley")
    led = item(db, "PC-LED-M12")
    before = next(r for r in stock_summary(db, led.id) if r["item_code"] == "PC-LED-M12")
    l = accepted_stock(store, "PC-LED-M12", "T-QTN-1", 20)
    set_lot_status(store, l, "quarantined", "Suspect lens cracks")
    after = next(r for r in stock_summary(db, led.id) if r["item_code"] == "PC-LED-M12")
    assert Decimal(after["physical"]) == Decimal(before["physical"]) + 20
    assert Decimal(after["available"]) == Decimal(before["available"])
    assert Decimal(after["quarantined"]) >= 20
    with pytest.raises(QualityHold):
        reserve(store, led, 1, "production_material", 0, lot=l)
    from app.modules.inventory.service import post_movement
    with pytest.raises(QualityHold):
        post_movement(store, "issue", led, 1, "pc", lot=l, from_bin=bin_by_code(db, "CMP-01"), to_bin=bin_by_code(db, "WIP-ASSY"))
    # moving it to an allocatable bin is also blocked
    transfer(store, led, l, bin_by_code(db, "CMP-01"), bin_by_code(db, "QTN-01"), 20, "pc")
    with pytest.raises(QualityHold):
        transfer(store, led, l, bin_by_code(db, "QTN-01"), bin_by_code(db, "CMP-01"), 20, "pc")
    with pytest.raises(Exception):
        set_lot_status(store, l, "accepted", "storekeeper cannot release")
    set_lot_status(qm, l, "accepted", "Re-inspected OK")
    with pytest.raises(InsufficientStock):  # released, but physically still in a non-allocatable bin
        reserve(store, led, 1, "production_material", 0, lot=l)
    transfer(store, led, l, bin_by_code(db, "QTN-01"), bin_by_code(db, "CMP-01"), 20, "pc")
    assert reserve(store, led, 1, "production_material", 0, lot=l)


def test_quarantine_releases_existing_reservations(as_user, db):
    store, insp = as_user("dackroyd"), as_user("kmensah")
    l = accepted_stock(store, "PC-LED-M12", "T-QTN-2", 10)
    r = reserve(store, item(db, "PC-LED-M12"), 5, "production_material", 0, lot=l)[0]
    set_lot_status(insp, l, "quarantined", "Supplier advisory")
    assert r.status == "released" and "quarantined" in r.released_reason


def test_reserved_stock_cannot_be_moved_away(as_user, db):
    store = as_user("dackroyd")
    l = accepted_stock(store, "PC-FST-M5X12", "T-RES-1", 10)
    reserve(store, item(db, "PC-FST-M5X12"), 8, "production_material", 0, lot=l)
    with pytest.raises(InsufficientStock) as e:
        transfer(store, item(db, "PC-FST-M5X12"), l, bin_by_code(db, "CMP-01"), bin_by_code(db, "RM-A2"), 3, "pc")
    assert e.value.code == "reserved_stock"
    transfer(store, item(db, "PC-FST-M5X12"), l, bin_by_code(db, "CMP-01"), bin_by_code(db, "RM-A2"), 2, "pc")


def test_split_and_merge_preserve_provenance_and_quantities(as_user, db):
    store = as_user("dackroyd")
    a = accepted_stock(store, "PC-CBL-3C075", "T-CBL-A", 50)
    b = accepted_stock(store, "PC-CBL-3C075", "T-CBL-B", 30)
    child = split_lot(store, a, bin_by_code(db, "CMP-01"), 20, "T-CBL-A-1", "Cut length for rework")
    assert lot_on_hand(db, a.id) == 30 and lot_on_hand(db, child.id) == 20
    m = merge_lots(store, [(child, bin_by_code(db, "CMP-01"), Decimal(20)), (b, bin_by_code(db, "CMP-01"), Decimal(30))],
                   bin_by_code(db, "CMP-01"), "T-CBL-M", "Consolidate part reels")
    assert lot_on_hand(db, m.id) == 50
    back = backward(db, m.id)
    nums = {r["lot_number"]: r for r in back["contributors"]}
    assert {"T-CBL-A-1", "T-CBL-B", "T-CBL-A"} <= set(nums)
    assert all(r["precision"] in ("exact", "unknown") for r in nums.values())
    fwd = forward(db, a.id)
    assert "T-CBL-M" in {r["lot_number"] for r in fwd["reached"]}
    edges = db.query(GenealogyEdge).filter(GenealogyEdge.child_lot_id == m.id).all()
    assert sorted(e.quantity for e in edges) == [Decimal(20), Decimal(30)]
    assert verify_journal(db) == []


def test_serial_cannot_exist_twice(as_user, db):
    from app.modules.inventory.service import create_lot, post_movement
    store = as_user("dackroyd")
    fg = item(db, "FG-L100")
    s = create_lot(store, fg, "T-SER-1", "opening", quality_status="accepted")
    post_movement(store, "adjustment", fg, 1, "pc", lot=s, to_bin=bin_by_code(db, "FG-01"), reason_code="t", skip_quality_gate=True)
    with pytest.raises(Exception):
        post_movement(store, "adjustment", fg, 1, "pc", lot=s, to_bin=bin_by_code(db, "FG-01"), reason_code="t", skip_quality_gate=True)
