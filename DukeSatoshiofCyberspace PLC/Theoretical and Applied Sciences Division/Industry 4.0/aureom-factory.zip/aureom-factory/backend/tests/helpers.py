"""Small builders shared by tests."""
from __future__ import annotations

from datetime import date, datetime, timezone
from decimal import Decimal

from sqlalchemy import select

from app.modules.inventory.models import Lot
from app.modules.inventory.service import bin_by_code, create_lot, post_movement
from app.modules.purchasing import service as pur
from app.modules.purchasing.models import Supplier
from app.modules.registry.models import Item


def item(db, code: str) -> Item:
    return db.execute(select(Item).where(Item.item_code == code)).scalar_one()


def lot(db, number: str) -> Lot:
    return db.execute(select(Lot).where(Lot.lot_number == number)).scalar_one()


def supplier(db, code: str) -> Supplier:
    return db.execute(select(Supplier).where(Supplier.code == code)).scalar_one()


def accepted_stock(ctx, code: str, number: str, qty, bin_code: str = "CMP-01", unit_cost="1.00") -> Lot:
    """Directly create accepted stock (test setup only)."""
    it = item(ctx.db, code)
    l = create_lot(ctx, it, number, "opening", quality_status="accepted", unit_cost=Decimal(unit_cost), cost_basis="test")
    post_movement(ctx, "adjustment", it, Decimal(qty), it.base_unit, lot=l, to_bin=bin_by_code(ctx.db, bin_code),
                  reason_code="test_setup", skip_quality_gate=True)
    return l


def open_po(as_user, supplier_code: str, lines: list[dict]):
    buyer, pm = as_user("mpickles"), as_user("isutcliffe")
    po = pur.create_po(buyer, buyer.site_id, supplier(buyer.db, supplier_code).id, lines, order_date=date(2026, 11, 2))
    pur.approve_po(pm, po.id, po.version)
    pur.send_po(buyer, po.id)
    return po


def dt(d: int, h: int = 9) -> datetime:
    return datetime(2026, 11, d, h, 0, tzinfo=timezone.utc)
