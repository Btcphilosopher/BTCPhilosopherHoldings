from datetime import date
from decimal import Decimal

import pytest
from sqlalchemy import select

from app.core.errors import InvalidState, QualityHold, ValidationFailed
from app.modules.inventory.models import Lot
from app.modules.inventory.service import lot_locations, lot_on_hand, stock_summary
from app.modules.purchasing import service as pur
from app.modules.purchasing.models import ReceiptLine
from app.modules.quality import service as qa
from app.modules.quality.models import Inspection
from tests.helpers import dt, item, open_po


def _rcv(as_user, po, qty, **kw):
    return pur.receive(as_user("dackroyd"), po.id, [{"po_line_id": po.lines[0].id, "quantity": qty, **kw}], received_at=dt(5))


def test_partial_receipts_keep_quantities_separate(as_user, db):
    po = open_po(as_user, "CVC", [{"item_id": item(db, "PC-CBL-3C075").id, "quantity": 4, "expected_delivery": date(2026, 11, 4)}])
    line = po.lines[0]
    assert line.unit == "reel"
    gr1 = _rcv(as_user, po, 1, supplier_lot="T-CV-1")
    assert line.quantity_received == 1 and line.status == "partially_received" and po.status == "partially_received"
    rl = gr1.lines[0]
    assert rl.base_quantity == Decimal(50)  # 1 reel = 50 m
    lot = db.get(Lot, rl.lot_id)
    assert lot.quality_status == "awaiting_review"
    assert lot_locations(db, lot.id)[0]["bin"] == "RCV-01"  # never straight into allocatable stock
    assert gr1.late_days == 1
    _rcv(as_user, po, 3, supplier_lot="T-CV-2")
    assert line.quantity_received == 4 and line.status == "received"
    assert line.quantity_accepted == 0 and line.quantity_invoiced == 0
    # quality accepts the first lot
    insp = db.execute(select(Inspection).where(Inspection.receipt_line_id == rl.id)).scalar_one()
    qa.record_result(as_user("kmensah"), insp.id, "Cable marking (3G0.75)", conforms=True)
    qa.record_result(as_user("kmensah"), insp.id, "Outer diameter", numeric_value=Decimal("6.4"), value_source="measured",
                     equipment_code="CAL-DIG-01")
    qa.decide(as_user("hbrierley"), insp.id, "accepted", "ok")
    assert line.quantity_accepted == 1
    inv = pur.record_invoice(as_user("mpickles"), po.supplier_id, "T-INV-1", date(2026, 11, 6), "GBP",
                             [{"po_line_id": line.id, "quantity": 2, "unit_price": Decimal("30.50")}])
    assert inv.status == "variance"  # invoiced 2 reels, only 1 accepted
    assert "quantity" in inv.match_result["lines"][0]["flags"][0]
    rec = pur.po_reconciliation(db, po)["lines"][0]
    assert (rec["ordered"], rec["received"], rec["accepted"], rec["invoiced"]) == ("4.000000", "4.000000", "1.000000", "2.000000")


def test_over_receipt_beyond_tolerance_is_refused(as_user, db):
    po = open_po(as_user, "HPF", [{"item_id": item(db, "PC-FST-M5X12").id, "quantity": 2}])
    with pytest.raises(ValidationFailed):
        _rcv(as_user, po, 3)


def test_receipt_against_unsent_po_refused(as_user, db):
    buyer = as_user("mpickles")
    from tests.helpers import supplier
    po = pur.create_po(buyer, buyer.site_id, supplier(db, "HPF").id, [{"item_id": item(db, "PC-FST-M5X12").id, "quantity": 1}])
    with pytest.raises(InvalidState):
        _rcv(as_user, po, 1)


def test_damaged_goods_segregated_and_returned(as_user, db):
    po = open_po(as_user, "LMH", [{"item_id": item(db, "PC-LED-M12").id, "quantity": 50}])
    gr = _rcv(as_user, po, 50, supplier_lot="T-LH-9", damaged_quantity=3)
    rl = gr.lines[0]
    assert lot_on_hand(db, rl.lot_id) == 47
    dmg = db.get(Lot, rl.damaged_lot_id)
    assert dmg.quality_status == "quarantined" and lot_locations(db, dmg.id)[0]["bin"] == "QTN-01"
    sr = pur.return_to_supplier(as_user("mpickles"), dmg.id, "QTN-01", 3, "Cracked lenses", replacement_expected=True)
    assert po.lines[0].quantity_returned == 3 and po.lines[0].status == "partially_received"
    assert lot_on_hand(db, dmg.id) == 0
    with pytest.raises(QualityHold):  # accepted/awaiting stock must be put on hold first
        good = db.get(Lot, rl.lot_id)
        good.quality_status = "accepted"
        pur.return_to_supplier(as_user("mpickles"), good.id, "RCV-01", 1, "x")


def test_substitution_requires_approval(as_user, db):
    po = open_po(as_user, "LMH", [{"item_id": item(db, "PC-LED-M12").id, "quantity": 50}])
    alt = item(db, "PC-LED-M12-ALT")
    with pytest.raises(QualityHold):
        _rcv(as_user, po, 10, item_id=alt.id)
    sr = pur.request_substitution(as_user("mpickles"), po.lines[0].id, alt.id, "Supplier out of stock")
    with pytest.raises(Exception):
        pur.decide_substitution(as_user("mpickles"), sr.id, True, "self")
    pur.decide_substitution(as_user("isutcliffe"), sr.id, True, "Approved second source")
    gr = _rcv(as_user, po, 10, item_id=alt.id, supplier_lot="T-SUB")
    assert gr.lines[0].item_id == alt.id and gr.lines[0].substitution_request_id == sr.id


def test_receipt_idempotency(as_user, db):
    po = open_po(as_user, "HPF", [{"item_id": item(db, "PC-FST-M5X12").id, "quantity": 2}])
    store = as_user("dackroyd")
    a = pur.receive(store, po.id, [{"po_line_id": po.lines[0].id, "quantity": 1}], idempotency_key="T-IDEM-1")
    b = pur.receive(store, po.id, [{"po_line_id": po.lines[0].id, "quantity": 1}], idempotency_key="T-IDEM-1")
    assert a.id == b.id and po.lines[0].quantity_received == 1


def test_fx_conversion_uses_dated_rate(as_user, db):
    po = open_po(as_user, "LMH", [{"item_id": item(db, "PC-LED-M12").id, "quantity": 50}])
    gr = _rcv(as_user, po, 50, supplier_lot="T-FX")
    rl = gr.lines[0]
    assert rl.fx_rate == Decimal("0.861000") and rl.fx_rate_date == date(2026, 11, 2)
    assert rl.unit_cost_base == Decimal("15.6702")  # 18.20 EUR × 0.861
