from datetime import date, datetime, timezone
from decimal import Decimal

from sqlalchemy import select

from app.modules.costing.service import actual_order_cost, incremental_cost, planned_order_cost, standard_cost
from app.modules.inventory.models import Reservation
from app.modules.production import service as prod
from tests.helpers import item, lot

T = lambda d, h, m=0: datetime(2026, 11, d, h, m, tzinfo=timezone.utc)


def _order(as_user, db):
    pm, store = as_user("gholroyd"), as_user("dackroyd")
    o = prod.create_order(pm, pm.site_id, item(db, "WIP-HSG-L100-MC").id, 10, effective_on=date(2026, 11, 9))
    prod.plan_order(pm, o.id, o.version, effective_on=date(2026, 11, 9))
    prod.allocate_materials(store, o.id)
    prod.release_order(pm, o.id, o.version)
    m = o.materials[0]
    for r in db.execute(select(Reservation).where(Reservation.demand_id == m.id, Reservation.status == "active")).scalars().all():
        prod.issue_material(store, m.id, r.lot_id, r.quantity, to_bin_code="WIP-SAW")
    return o


def test_actual_cost_from_consumption_and_booked_time(as_user, db):
    o = _order(as_user, db)
    asha = as_user("apatel")
    cut = sorted(o.operations, key=lambda x: x.seq)[0]
    prod.check_equipment(asha, cut.id, "SAW-01", {}, T(16, 7, 25))
    prod.start_operation(asha, cut.id, "SAW-01", observed_at=T(16, 7, 30))
    prod.record_consumption(asha, o.materials[0].id, lot(db, "OPEN-AL-01").id, Decimal("10"), "kg", from_bin_code="WIP-SAW")
    prod.report_quantities(asha, cut.id, good=11)
    prod.complete_operation(asha, cut.id, T(16, 8, 30))  # 60 minutes
    c = actual_order_cost(db, o)
    t = c["totals"]
    assert Decimal(t["materials"]) == Decimal("43.0000")  # 10 kg × £4.30 opening lot cost
    assert Decimal(t["labour"]) == Decimal("32.0000")  # 1 h × £32
    assert Decimal(t["machine"]) == Decimal("18.0000")  # 1 h × £18 (saw)
    # overhead: £18/labour hour + 4 % of material cost
    assert Decimal(t["overhead"]) == Decimal("18.0000") + Decimal("1.7200")
    assert Decimal(t["total"]) == sum(Decimal(t[k]) for k in ("materials", "packaging", "labour", "machine", "subcontract",
                                                                 "scrap_material", "overhead"))


def test_booked_time_is_clipped_to_shift_calendar(as_user, db):
    o = _order(as_user, db)
    asha = as_user("apatel")
    cut = sorted(o.operations, key=lambda x: x.seq)[0]
    prod.check_equipment(asha, cut.id, "SAW-01", {}, T(16, 14, 55))
    prod.start_operation(asha, cut.id, "SAW-01", observed_at=T(16, 15, 0))
    prod.report_quantities(asha, cut.id, good=1)
    prod.complete_operation(asha, cut.id, T(17, 8, 0))  # overnight: 30 min + 60 min of shift time
    iv = prod.time_intervals(db, cut)[0]
    assert iv["minutes"] == Decimal("90.000000")
    assert iv["elapsed_minutes"] == Decimal("1020.000000")


def test_planned_cost_states_rates_and_basis(as_user, db):
    o = _order(as_user, db)
    p = o.planned_cost
    assert p["currency"] == "GBP" and Decimal(p["totals"]["total"]) > 0
    mats = [d for d in p["detail"] if d["element"] == "materials"]
    assert mats and "standard" in mats[0]["basis"]
    labour = [d for d in p["detail"] if d["element"] == "labour+machine"]
    assert labour[0]["labour_rate"] == "32.0000"


def test_standard_cost_rollup_uses_fx_and_batch(db):
    std = standard_cost(db, item(db, "FG-L100").id, date(2026, 11, 20))
    led = next(c for c in std["components"] if c["item_code"] == "PC-LED-M12")
    assert Decimal(led["unit_cost"]) == Decimal("15.6702")  # 18.20 EUR × 0.861 (2 Nov rate)
    assert std["batch_size_for_setup"] == "100.000000"


def test_incremental_cost_excludes_allocated_overhead_and_fixed_labour(db):
    inc = incremental_cost(db, item(db, "FG-L100").id)
    assert Decimal(inc["incremental_cost_one_more_unit"]) < Decimal(inc["fully_allocated_standard_unit_cost"])
    assert not any(l["element"] == "overhead" for l in inc["lines"])
    assert all(not l["changes"] for l in inc["lines"] if l["element"] in ("labour", "machine_fixed"))
    assert any("overhead" in a.lower() for a in inc["assumptions"])
    with_labour = incremental_cost(db, item(db, "FG-L100").id, labour_variable=True)
    assert Decimal(with_labour["incremental_cost_one_more_unit"]) > Decimal(inc["incremental_cost_one_more_unit"])
    one_off = incremental_cost(db, item(db, "FG-L100").id, added_to_existing_batch=False)
    assert any(l["element"] == "setup" for l in one_off["lines"])
