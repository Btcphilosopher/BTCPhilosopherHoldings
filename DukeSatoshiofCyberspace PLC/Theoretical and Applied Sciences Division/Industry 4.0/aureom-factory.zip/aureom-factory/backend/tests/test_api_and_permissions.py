"""HTTP-level tests: authentication, site-scoped permissions, validation, optimistic concurrency,
idempotency, protected documents and the WebSocket endpoint."""
import pytest
from fastapi.testclient import TestClient

from app.db import get_session
from app.main import app
from app.core.security import sign
from tests.helpers import item


@pytest.fixture()
def client(db):
    def override():
        yield db
        db.flush()
    app.dependency_overrides[get_session] = override
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


def login(client, username, password="demo"):
    r = client.post("/api/auth/login", json={"username": username, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


def test_authentication(client):
    assert client.post("/api/auth/login", json={"username": "admin", "password": "wrong"}).status_code == 401
    assert client.get("/api/items").status_code == 401
    assert client.get("/api/items", headers={"Authorization": "Bearer nonsense"}).status_code == 401
    h = login(client, "hbrierley")
    me = client.get("/api/auth/me", headers=h).json()
    assert "quality.release" in me["permissions"]
    expired = sign({"uid": me["id"]}, ttl_seconds=-1)
    assert client.get("/api/items", headers={"Authorization": "Bearer " + expired}).status_code == 401


def test_restricted_actions_and_site_scope(client, db):
    viewer = login(client, "viewer")
    r = client.post("/api/items", headers=viewer, json={"item_code": "X-VIEW", "description": "nope", "item_type": "consumable",
                                                        "base_unit": "L"})
    assert r.status_code == 403 and r.json()["error"]["code"] == "permission_denied"
    # Calder storekeeper cannot move Pennine stock
    cal = login(client, "calder_op")
    r = client.post("/api/movements/transfer", headers=cal, json={"item_id": item(db, "PC-FST-M5X12").id, "lot_id": None,
                    "from_bin": "CMP-01", "to_bin": "RM-A2", "quantity": 1, "unit": "pc"})
    assert r.status_code == 403
    # operators cannot release production orders or approve BOMs
    op = login(client, "apatel")
    assert client.post("/api/boms/1/approve", headers=op, json={}).status_code == 403


def test_validation_rejects_unknown_fields_and_bad_values(client):
    h = login(client, "rdesai")
    r = client.post("/api/items", headers=h, json={"item_code": "X-1", "description": "ok desc", "item_type": "consumable",
                                                   "base_unit": "L", "surprise": 1})
    assert r.status_code == 422
    r = client.post("/api/items", headers=h, json={"item_code": "bad code!", "description": "ok desc", "item_type": "consumable",
                                                   "base_unit": "L"})
    assert r.status_code == 422
    r = client.post("/api/items", headers=h, json={"item_code": "X-2", "description": "ok desc", "item_type": "consumable",
                                                   "base_unit": "furlong"})
    assert r.status_code == 422


def test_optimistic_concurrency_on_item_edit(client, db):
    h = login(client, "rdesai")
    it = item(db, "PK-LBL-L100")
    v = client.get(f"/api/items/{it.id}", headers=h).json()["version"]
    ok = client.patch(f"/api/items/{it.id}", headers=h, json={"version": v, "changes": {"storage_requirements": "Dry shelf"}})
    assert ok.status_code == 200 and ok.json()["version"] == v + 1
    stale = client.patch(f"/api/items/{it.id}", headers=h, json={"version": v, "changes": {"storage_requirements": "Other"}})
    assert stale.status_code == 409 and stale.json()["error"]["code"] == "conflict"
    bad = client.patch(f"/api/items/{it.id}", headers=h, json={"version": v + 1, "changes": {"item_type": "wip"}})
    assert bad.status_code == 422


def test_idempotency_key_replays_and_detects_misuse(client, db):
    h = login(client, "dackroyd")
    body = {"item_id": item(db, "PK-LBL-L100").id, "lot_id": None, "bin": "PKG-01", "delta": 1, "unit": "pc",
            "reason_code": "count", "notes": "found label"}
    from tests.helpers import lot
    body["lot_id"] = lot(db, "OPEN-LBL-01").id
    a = client.post("/api/movements/adjust", headers={**h, "Idempotency-Key": "k-1"}, json=body)
    b = client.post("/api/movements/adjust", headers={**h, "Idempotency-Key": "k-1"}, json=body)
    assert a.status_code == b.status_code == 201 and a.json()["movement_no"] == b.json()["movement_no"]
    c = client.post("/api/movements/adjust", headers={**h, "Idempotency-Key": "k-1"}, json={**body, "delta": 2})
    assert c.status_code == 409


def test_scan_identifies_but_does_not_verify(client, db):
    h = login(client, "apatel")
    r = client.post("/api/scan", headers=h, json={"raw": "LOT:PC-LED-M12|OPEN-LED-01"})
    j = r.json()
    assert j["kind"] == "lot" and j["record"]["lot_number"] == "OPEN-LED-01"
    assert "does not establish" in j["note"]
    r = client.post("/api/scan", headers=h, json={"raw": "(01)05012345678900(10)OPEN-LED-01"})
    assert r.json()["kind"] == "lot"


def test_protected_documents(client, db):
    eng = login(client, "rdesai")
    r = client.post("/api/documents", headers=eng, files={"file": ("dwg.txt", b"drawing rev A", "text/plain")},
                    data={"kind": "drawing", "title": "Housing drawing", "entity_type": "item", "entity_id": "1"})
    assert r.status_code == 201
    doc = r.json()
    assert len(doc["sha256"]) == 64 and "storage_key" in doc
    link = client.post(f"/api/documents/{doc['id']}/link", headers=login(client, "apatel")).json()["url"]
    f = client.get(link)
    assert f.status_code == 200 and f.content == b"drawing rev A" and f.headers["cache-control"].startswith("private")
    assert client.get("/api/files/forged.token").status_code == 401
    bad = client.post("/api/documents", headers=eng, files={"file": ("x.exe", b"MZ", "application/x-msdownload")},
                      data={"kind": "drawing", "title": "bad"})
    assert bad.status_code == 422
    restricted = client.post("/api/documents", headers=eng, files={"file": ("r.txt", b"secret", "text/plain")},
                             data={"kind": "drawing", "title": "restricted", "classification": "restricted"})
    assert restricted.status_code == 403  # only approvers/quality managers may classify as restricted


def test_websocket_requires_token(client):
    h = login(client, "viewer")
    token = h["Authorization"].split()[1]
    with client.websocket_connect(f"/ws?token={token}") as ws:
        assert ws.receive_json()["topic"] == "hello"
    with pytest.raises(Exception):
        with client.websocket_connect("/ws?token=bad") as ws:
            ws.receive_json()


def test_openapi_lists_modules(client):
    spec = client.get("/openapi.json").json()
    tags = {t for p in spec["paths"].values() for op in p.values() for t in op.get("tags", [])}
    assert {"materials", "products", "purchasing", "inventory", "planning", "production", "quality", "maintenance",
            "costing", "dispatch", "traceability"} <= tags


def test_system_account_cannot_log_in(client):
    assert client.post("/api/auth/login", json={"username": "system", "password": "demo"}).status_code == 401
    assert client.post("/api/auth/login", json={"username": "system", "password": "!disabled"}).status_code == 401


def test_operator_cannot_read_audit_or_jobs(client):
    op = login(client, "apatel")
    assert client.get("/api/audit", headers=op).status_code == 403
    assert client.get("/api/jobs", headers=op).status_code == 403
