"""Backup and tested restoration using the shipped scripts (scripts/backup.sh, scripts/restore.sh).

Runs after the demo test so the database contains a full scenario. Restores into a separate
database and verifies row counts, the movement journal, and that append-only triggers survive."""
import os
import subprocess
from pathlib import Path

import pytest
from sqlalchemy import create_engine, text

from tests.conftest import TEST_URL

ROOT = Path(__file__).resolve().parents[2]
TABLES = ("items", "lots", "stock_movements", "stock_balances", "genealogy_edges", "inspection_results", "audit_log",
          "production_orders", "shipments", "cost_postings")


def _pg(url: str) -> str:
    return url.replace("postgresql+psycopg://", "postgresql://")


@pytest.mark.skipif(subprocess.call(["which", "pg_dump"], stdout=subprocess.DEVNULL) != 0, reason="pg_dump not installed")
def test_backup_and_restore_roundtrip(engine, tmp_path):
    restore_url = TEST_URL.rsplit("/", 1)[0] + "/aureom_restore_test"
    env = {**os.environ, "AUREOM_DB_URL": _pg(TEST_URL), "BACKUP_DIR": str(tmp_path),
           "AUREOM_STORAGE_PATH": os.environ["AUREOM_STORAGE_PATH"]}
    out = subprocess.run(["bash", str(ROOT / "scripts" / "backup.sh")], env=env, capture_output=True, text=True, check=True)
    dump = next(tmp_path.glob("aureom_*.dump"))
    manifest = next(tmp_path.glob("aureom_*.manifest.json"))
    assert dump.stat().st_size > 0 and manifest.exists(), out.stdout
    env2 = {**env, "AUREOM_DB_URL": _pg(restore_url), "CREATE_DB": "1"}
    subprocess.run(["bash", str(ROOT / "scripts" / "restore.sh"), str(dump)], env=env2, capture_output=True, text=True, check=True)
    src, dst = create_engine(_pg(TEST_URL).replace("postgresql://", "postgresql+psycopg://")), create_engine(restore_url)
    with src.connect() as a, dst.connect() as b:
        for t in TABLES:
            assert a.execute(text(f"SELECT count(*) FROM {t}")).scalar() == b.execute(text(f"SELECT count(*) FROM {t}")).scalar(), t
        q = "SELECT md5(string_agg(movement_no || quantity::text || coalesce(lot_id::text,''), ',' ORDER BY id)) FROM stock_movements"
        assert a.execute(text(q)).scalar() == b.execute(text(q)).scalar()
        trig = b.execute(text("SELECT count(*) FROM pg_trigger WHERE tgname LIKE '%append_only'")).scalar()
        assert trig == 6
        with pytest.raises(Exception):
            b.execute(text("DELETE FROM stock_movements"))
    from app.modules.inventory.service import verify_journal
    from sqlalchemy.orm import Session
    with Session(dst) as s:
        assert verify_journal(s) == []
    src.dispose()
    dst.dispose()
