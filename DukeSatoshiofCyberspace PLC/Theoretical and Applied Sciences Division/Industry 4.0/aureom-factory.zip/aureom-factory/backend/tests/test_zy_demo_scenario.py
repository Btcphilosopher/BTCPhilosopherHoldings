"""Runs the full Pennine demonstration on a freshly migrated database and checks the outcomes.
(Named test_zy_* so it runs after the rollback-based tests; it resets the schema.)"""
from decimal import Decimal

import pytest
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from tests.conftest import TEST_URL


@pytest.fixture(scope="module")
def demo(engine):
    from app.demo.run import reset_database
    from app.demo.scenario import Demo

    engine.dispose()
    reset_database(TEST_URL)
    s = Session(engine)
    d = Demo(s, verbose=False)
    log = d.run()
    yield d, log
    s.close()


def test_all_steps_ran(demo):
    d, log = demo
    assert [s["step"] for s in log] == [0, 1, 2, 3, 4, 5, 6, "7a", "7b", "7c", 8, 9, 10, 11, 12, 13, 14, 15]
    assert not any("error" in s for s in log)
    blocked = [n["text"] for s in log for n in s["notes"] if n["text"].startswith("BLOCKED")]
    assert len(blocked) >= 15


def test_outcomes(demo):
    from app.modules.dispatch.models import Shipment
    from app.modules.genealogy.service import backward, forward
    from app.modules.inventory.models import Lot
    from app.modules.inventory.service import verify_journal
    from app.modules.production.models import ProductionOrder

    d, _ = demo
    db = d.db
    orders = {o.number: o for o in db.execute(select(ProductionOrder)).scalars()}
    statuses = sorted(o.status for o in orders.values())
    assert statuses == ["closed"] * 4 + ["released"]  # four executed orders closed; one follow-on left for the shop floor
    fg = [o for o in orders.values() if o.kind == "standard" and o.quantity_target == 100 and o.bom_version == 1
          and db.get(__import__("app.modules.registry.models", fromlist=["x"]).Item, o.item_id).item_code == "FG-L100"][0]
    assert fg.quantity_reported == 97 and fg.quantity_accepted == 97 and fg.quantity_nonconforming == 3
    rw = [o for o in orders.values() if o.kind == "rework"][0]
    assert rw.quantity_accepted == 3 and rw.parent_order_id == fg.id
    accepted = db.execute(select(func.count()).select_from(Lot).where(Lot.batch_ref == fg.number, Lot.quality_status == "accepted")).scalar()
    held = db.execute(select(func.count()).select_from(Lot).where(Lot.batch_ref == fg.number, Lot.quality_status != "accepted")).scalar()
    assert accepted + held == 100
    assert verify_journal(db) == []
    led = db.execute(select(Lot).where(Lot.supplier_lot == "LH-24-118", Lot.quality_status != "rejected")).scalar_one()
    f = forward(db, led.id)
    assert f["summary"]["finished_by_precision"] == {"exact": 58}
    b = backward(db, db.execute(select(Lot).where(Lot.lot_number == "PMD-L100-000005")).scalar_one().id)
    led_src = [r for r in b["contributors"] if r["item_code"] == "PC-LED-M12"]
    assert len(led_src) == 1 and led_src[0]["precision"] == "unknown"  # opening stock without supplier lot
    shipped = db.execute(select(func.count()).select_from(Shipment).where(Shipment.status.in_(("dispatched", "delivered")))).scalar()
    assert shipped == 2


def test_costs_and_exports(demo):
    from app.modules.costing.models import CostPosting
    from app.modules.costing.service import order_cost_comparison
    from app.modules.production.models import ProductionOrder

    d, _ = demo
    db = d.db
    for o in db.execute(select(ProductionOrder)).scalars():
        if o.status != "closed":
            continue
        c = order_cost_comparison(db, o)
        assert Decimal(c["posted"]["total"]) == Decimal(c["actual"]["total"])
        assert Decimal(c["estimate_at_completion"]["total"]) == Decimal(c["actual"]["total"])  # closed
    debits = db.execute(select(func.sum(CostPosting.debit))).scalar()
    credits = db.execute(select(func.sum(CostPosting.credit))).scalar()
    assert debits == credits


def test_recall_findings(demo):
    from app.modules.dispatch.models import Recall
    d, _ = demo
    rc = d.db.execute(select(Recall)).scalar_one()
    assert rc.findings["finished_units"]["confirmed"] == 58
    assert set(rc.findings["customers"]) == {"Luddenden Optical Instruments Ltd (fictional)", "Wainhouse Test Laboratories Ltd (fictional)"}
