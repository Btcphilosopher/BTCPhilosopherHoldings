"""Two planners reserve the same scarce stock at the same moment: exactly one may succeed."""
import threading
from decimal import Decimal

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.api_deps import load_user
from app.core.context import Ctx
from app.core.errors import InsufficientStock
from app.core.models import Site, User
from app.modules.inventory.models import Reservation
from app.modules.inventory.service import reserve
from tests.helpers import accepted_stock, item


def test_concurrent_reservations_cannot_overcommit(engine):
    with Session(engine) as s:
        site = s.execute(select(Site.id).where(Site.code == "PEN")).scalar()
        uid = s.execute(select(User.id).where(User.username == "dackroyd")).scalar()
        ctx = Ctx(db=s, user=load_user(s, uid), site_id=site)
        lot = accepted_stock(ctx, "PC-LED-M12-ALT", "T-CONC-1", 10)
        s.commit()
        lot_id = lot.id

    barrier = threading.Barrier(2)
    results: list[str] = []

    def worker(n: int):
        with Session(engine) as s:
            c = Ctx(db=s, user=load_user(s, uid), site_id=site)
            it = item(s, "PC-LED-M12-ALT")
            from app.modules.inventory.models import Lot
            l = s.get(Lot, lot_id)
            barrier.wait()
            try:
                reserve(c, it, Decimal(7), "production_material", 9000 + n, lot=l)
                s.commit()
                results.append("ok")
            except InsufficientStock:
                s.rollback()
                results.append("refused")

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(2)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert sorted(results) == ["ok", "refused"]
    with Session(engine) as s:
        total = sum(r.quantity for r in s.execute(select(Reservation).where(Reservation.lot_id == lot_id,
                                                                            Reservation.status == "active")).scalars())
        assert total == Decimal(7)
        s.execute(update(Reservation).where(Reservation.lot_id == lot_id).values(status="released", released_reason="test cleanup"))
        s.commit()
