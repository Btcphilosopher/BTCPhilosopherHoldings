from sqlalchemy import select

from app.core.models import Job, OfflineEntry
from app.modules.registry.models import Item
from app.workers.jobs import import_items, job_notify_overdue
from app.modules.production import shopfloor

CSV = """item_code,revision,description,item_type,base_unit,lot_or_serial_policy
IMP-001,A,Imported washer M5,purchased_component,pc,lot
IMP-002,A,Imported gasket,purchased_component,pc,lot
PK-LBL-L100,A,Product rating and serial label,packaging,pc,lot
"""


def test_import_is_idempotent_and_never_overwrites(as_user, db):
    eng = as_user("rdesai")
    r1 = import_items(eng, CSV, "test.csv")
    assert r1["created"] == ["IMP-001", "IMP-002"] and r1["unchanged"][0]["item_code"] == "PK-LBL-L100"
    r2 = import_items(eng, CSV, "test.csv")
    assert r2.get("replayed") and r2["created"] == r1["created"]
    assert db.execute(select(Item).where(Item.item_code == "IMP-001")).scalars().all().__len__() == 1
    changed = CSV.replace("Imported gasket", "Imported gasket (changed)") + "IMP-003,A,Bad unit,purchased_component,furlong,lot\n"
    r3 = import_items(eng, changed, "test2.csv")
    assert r3["conflicts"][0]["item_code"] == "IMP-002"
    assert db.execute(select(Item).where(Item.item_code == "IMP-002")).scalar_one().description == "Imported gasket"
    assert r3["errors"][0]["item_code"] == "IMP-003"


def test_offline_entries_stay_pending_until_reconciled(as_user, db):
    s = as_user("sbarraclough")
    out = shopfloor.submit_offline(s, "TAB-1", [{"client_entry_id": "t-off-1", "kind": "event",
                                                 "payload": {"operation_id": 1, "event": "note"},
                                                 "observed_at": "2026-11-20T10:00:00+00:00"}])
    assert out[0]["status"] == "pending"
    again = shopfloor.submit_offline(s, "TAB-1", [{"client_entry_id": "t-off-1", "kind": "event", "payload": {},
                                                   "observed_at": "2026-11-20T10:00:00+00:00"}])
    assert again[0]["duplicate"]
    e = db.execute(select(OfflineEntry).where(OfflineEntry.client_entry_id == "t-off-1")).scalar_one()
    assert e.status == "pending"
    import pytest
    with pytest.raises(Exception):
        shopfloor.reconcile_offline(s, e.id, True)  # operators cannot reconcile their own offline entries
    shopfloor.reconcile_offline(as_user("gholroyd"), e.id, False, "duplicate of online entry")
    assert e.status == "rejected"


def test_notification_job(as_user, db):
    r = job_notify_overdue(as_user("admin"), {"today": "2027-04-15"})
    assert r["notifications"] >= 1 and "in_app" in r["channel"]
