from datetime import date, datetime, timezone
from decimal import Decimal

import pytest
from sqlalchemy import select

from app.core.errors import InsufficientStock, InvalidState, QualityHold, ValidationFailed
from app.modules.inventory.models import Reservation
from app.modules.inventory.service import bin_by_code, lot_on_hand
from app.modules.production import service as prod
from app.modules.quality import service as qa
from app.modules.quality.models import InspectionPlan, Nonconformance
from tests.helpers import accepted_stock, item, lot

T = lambda d, h, m=0: datetime(2026, 11, d, h, m, tzinfo=timezone.utc)


def _released_housing_order(as_user, db, qty=10):
    pm, store = as_user("gholroyd"), as_user("dackroyd")
    o = prod.create_order(pm, pm.site_id, item(db, "WIP-HSG-L100-MC").id, qty, effective_on=date(2026, 11, 9))
    prod.plan_order(pm, o.id, o.version, effective_on=date(2026, 11, 9))
    prod.allocate_materials(store, o.id)
    prod.release_order(pm, o.id, o.version, released_at=T(16, 7))
    return o


def _issue_all(as_user, db, o, bin_code="WIP-SAW"):
    store = as_user("dackroyd")
    for m in o.materials:
        for r in db.execute(select(Reservation).where(Reservation.demand_type == "production_material", Reservation.demand_id == m.id,
                                                      Reservation.status == "active")).scalars().all():
            prod.issue_material(store, m.id, r.lot_id, r.quantity - r.quantity_issued, to_bin_code=bin_code, observed_at=T(16, 7, 10))


def test_full_order_keeps_completion_acceptance_and_closure_separate(as_user, db):
    o = _released_housing_order(as_user, db, 10)
    assert o.quantity_start == 11  # 10 / 97 % yield
    mat = o.materials[0]
    assert mat.required_quantity == Decimal("14.577750")  # 11 × 1.32525 kg
    _issue_all(as_user, db, o)
    asha, liam = as_user("apatel"), as_user("lfirth")
    cut, mach, ins = sorted(o.operations, key=lambda x: x.seq)
    with pytest.raises(InvalidState):  # no equipment readiness check yet
        prod.start_operation(asha, cut.id, "SAW-01", observed_at=T(16, 7, 30))
    prod.check_equipment(asha, cut.id, "SAW-01", {"guard_fitted": True}, T(16, 7, 25))
    prod.start_operation(asha, cut.id, "SAW-01", observed_at=T(16, 7, 30))
    with pytest.raises(InvalidState):  # machining cannot start before anything is handed over
        prod.check_equipment(liam, mach.id, "CNC-01", {}, T(16, 7, 35))
        prod.start_operation(liam, mach.id, "CNC-01", observed_at=T(16, 7, 40))
    prod.report_quantities(asha, cut.id, good=11, observed_at=T(16, 8))
    l_open = lot(db, "OPEN-AL-01")
    prod.record_consumption(asha, mat.id, l_open.id, Decimal("14.4"), "kg", from_bin_code="WIP-SAW", value_source="measured",
                            observed_at=T(16, 8))
    prod.complete_operation(asha, cut.id, T(16, 8, 5))
    prod.check_equipment(liam, mach.id, "CNC-01", {}, T(16, 8, 10))
    prod.start_operation(liam, mach.id, "CNC-01", observed_at=T(16, 8, 15))
    prod.report_quantities(liam, mach.id, good=11, observed_at=T(16, 11))
    prod.complete_operation(liam, mach.id, T(16, 11, 5))
    prod.start_operation(liam, ins.id, None, observed_at=T(16, 11, 10))
    with pytest.raises(QualityHold):
        prod.report_output(liam, o.id, ins.id, 11, to_bin_code="CMP-01", lot_number="T-HSG-A")  # allocatable bin refused
    out = prod.report_output(liam, o.id, ins.id, 11, to_bin_code="WIP-CNC", lot_number="T-HSG-A", observed_at=T(16, 11, 30))
    assert out[0].quality_status == "awaiting_review"
    with pytest.raises(QualityHold):  # inspection point: decision required before completing
        prod.complete_operation(liam, ins.id, T(16, 12))
    insp = prod.ensure_operation_inspection(liam, ins, out, 11)
    k = as_user("kmensah")
    for i in range(insp.sample_size):
        qa.record_result(k, insp.id, "Bore diameter", numeric_value=Decimal("38.05"), value_source="measured", equipment_code="CAL-DIG-01", sample_ref=str(i))
        qa.record_result(k, insp.id, "Overall length", numeric_value=Decimal("240.0"), value_source="measured", equipment_code="CAL-DIG-01", sample_ref=str(i))
    # operations done but output not yet accepted
    with pytest.raises(QualityHold):
        prod.complete_operation(liam, ins.id, T(16, 12))
    qa.decide(as_user("hbrierley"), insp.id, "quarantined", "hold pending review")
    prod.complete_operation(liam, ins.id, T(16, 12))
    assert o.status == "awaiting_inspection" and o.quantity_accepted == 0
    with pytest.raises(InvalidState):
        prod.close_order(as_user("gholroyd"), o.id, o.version)
    # open a fresh inspection and release
    insp2 = qa.open_inspection(k, "in_process", item(db, "WIP-HSG-L100-MC"), out, plan=db.get(InspectionPlan, insp.plan_id))
    for i in range(insp2.sample_size):
        qa.record_result(k, insp2.id, "Bore diameter", numeric_value=Decimal("38.05"), value_source="measured", equipment_code="CAL-DIG-01", sample_ref=str(i))
        qa.record_result(k, insp2.id, "Overall length", numeric_value=Decimal("240.0"), value_source="measured", equipment_code="CAL-DIG-01", sample_ref=str(i))
    qa.decide(as_user("hbrierley"), insp2.id, "accepted", "ok")
    assert o.status == "completed" and o.quantity_accepted == 11
    with pytest.raises(InvalidState) as e:  # line-side remainder not yet returned
        prod.close_order(as_user("gholroyd"), o.id, o.version)
    assert "issued but not consumed" in e.value.message
    left = lot_on_hand(db, l_open.id, bin_by_code(db, "WIP-SAW").id)
    prod.return_material(as_user("dackroyd"), mat.id, l_open.id, left, from_bin_code="WIP-SAW", to_bin_code="RM-A1")
    prod.close_order(as_user("gholroyd"), o.id, o.version)
    assert o.status == "closed"
    assert out[0].unit_cost is not None and "actual cost" in out[0].cost_basis


def test_operator_skill_and_permissions(as_user, db):
    o = _released_housing_order(as_user, db, 5)
    cut = sorted(o.operations, key=lambda x: x.seq)[0]
    prod.check_equipment(as_user("sbarraclough"), cut.id, "SAW-01", {}, T(16, 7))
    with pytest.raises(ValidationFailed):
        prod.start_operation(as_user("sbarraclough"), cut.id, "SAW-01", observed_at=T(16, 7, 5))
    with pytest.raises(Exception):
        prod.release_order(as_user("apatel"), o.id, o.version)


def test_cancelling_partially_executed_order_requires_material_disposition(as_user, db):
    o = _released_housing_order(as_user, db, 10)
    _issue_all(as_user, db, o)
    asha = as_user("apatel")
    mat = o.materials[0]
    l_open = lot(db, "OPEN-AL-01")
    prod.record_consumption(asha, mat.id, l_open.id, Decimal("5"), "kg", from_bin_code="WIP-SAW", observed_at=T(16, 8))
    pm = as_user("gholroyd")
    with pytest.raises(ValidationFailed) as e:
        prod.cancel_order(pm, o.id, o.version, "Customer cancelled")
    assert e.value.details  # lists what is still at line-side
    left = lot_on_hand(db, l_open.id, bin_by_code(db, "WIP-SAW").id)
    with pytest.raises(Exception):
        prod.cancel_order(asha, o.id, o.version, "x", [])
    prod.cancel_order(pm, o.id, o.version, "Customer cancelled",
                      [{"material_id": mat.id, "lot_id": l_open.id, "action": "return", "quantity": left, "to_bin_code": "RM-A1"}])
    assert o.status == "cancelled"
    assert lot_on_hand(db, l_open.id, bin_by_code(db, "WIP-SAW").id) == 0
    assert mat.quantity_consumed == 5  # consumption stays recorded
    assert all(r.status != "active" for r in db.execute(select(Reservation).where(Reservation.demand_id == mat.id)).scalars())


def test_backflush_is_calculated_and_reconciled(as_user, db):
    pm, store = as_user("gholroyd"), as_user("dackroyd")
    accepted_stock(store, "SA-HSG-L100", "T-SA-1", 5)
    o = prod.create_order(pm, pm.site_id, item(db, "FG-L100").id, 5, effective_on=date(2026, 11, 9))
    prod.plan_order(pm, o.id, o.version, effective_on=date(2026, 11, 9))
    prod.allocate_materials(store, o.id)
    prod.release_order(pm, o.id, o.version)
    _issue_all(as_user, db, o, "WIP-ASSY")
    pack = sorted(o.operations, key=lambda x: x.seq)[2]
    s = as_user("sbarraclough")
    o.status = "in_progress"
    mvs = prod.backflush(s, o.id, pack.id, 5, from_bin_code="WIP-ASSY")
    assert mvs and all(m.value_source == "calculated" for m in mvs)
    ctn = next(m for m in o.materials if m.item_id == item(db, "PK-CTN-L100").id)
    assert ctn.quantity_consumed_calculated == 5 and ctn.quantity_consumed == 5
    rec = prod.reconcile_backflush(s, ctn.id, {mvs[0].lot_id: Decimal(0)}, bin_code="WIP-ASSY", note="one spare used")
    assert rec.calculated_quantity == 5 and rec.variance == 0


def test_rework_requires_disposition_and_approved_instructions(as_user, db):
    from app.modules.inventory.service import create_lot, post_movement
    store, qm, pm = as_user("dackroyd"), as_user("hbrierley"), as_user("gholroyd")
    fg = item(db, "FG-L100")
    l = create_lot(store, fg, "T-RW-1", "production", quality_status="quarantined")
    post_movement(store, "production_output", fg, 1, "pc", lot=l, to_bin=bin_by_code(db, "QTN-01"), skip_quality_gate=True)
    ncr = qa.raise_ncr(as_user("kmensah"), source="in_process", item_id=fg.id, lot_ids=[l.id], quantity=1, description="earth bond")
    with pytest.raises(InvalidState):
        prod.create_rework_order(pm, ncr.id, instructions="x")
    qa.disposition_ncr(qm, ncr.id, "rework", "RW-L100-01")
    rw = prod.create_rework_order(pm, ncr.id, instructions="RW-L100-01",
                                  additional_materials=[{"item_id": item(db, "PC-CBL-3C075").id, "quantity": "1.8", "unit": "m"}])
    assert rw.kind == "rework" and rw.nonconformance_id == ncr.id and rw.materials[0].additional
    prod.plan_order(pm, rw.id, rw.version)
    assert rw.snapshot["routing"]["kind"] == "rework"
    assert any(o.inspection_point for o in rw.operations)
    with pytest.raises(InvalidState):
        prod.create_rework_order(pm, ncr.id, instructions="again")
