from datetime import date
from decimal import Decimal

import pytest

from app.core.errors import BomCycleError, InvalidState, ValidationFailed
from app.modules.engineering.models import Bom
from app.modules.engineering.service import (
    add_bom_line, approve_bom, create_bom, effective_bom, explode, gross_per_parent, new_bom_version,
)
from app.modules.production import service as prod
from tests.helpers import item


def test_direct_and_indirect_cycles_are_rejected(as_user, db):
    eng = as_user("rdesai")
    with pytest.raises(BomCycleError) as e:
        create_bom(eng, item(db, "WIP-HSG-L100-MC").id, {"lines": [{"component_item_id": item(db, "FG-L100").id, "quantity": 1, "unit": "pc"}]})
    assert "FG-L100" in str(e.value.details["path"])
    with pytest.raises(BomCycleError):
        create_bom(eng, item(db, "FG-L100").id, {"lines": [{"component_item_id": item(db, "FG-L100").id, "quantity": 1, "unit": "pc"}]})


def test_allowance_is_not_double_counted(db):
    wip = item(db, "WIP-HSG-L100-MC")
    bom = effective_bom(db, wip.id, date(2026, 11, 1))
    line = bom.lines[0]
    assert line.scrap_basis == "allowance_in_quantity" and line.loss_pct == Decimal(4)
    g = gross_per_parent(db, bom, line)
    assert g["gross"] == g["net"] == Decimal("1.325250")  # 4 % NOT added again


def test_expected_loss_and_yield_are_separate(db):
    fg = effective_bom(db, item(db, "FG-L100").id, date(2026, 11, 1))
    cable = next(l for l in fg.lines if l.component_item_id == item(db, "PC-CBL-3C075").id)
    assert gross_per_parent(db, fg, cable)["gross"] == Decimal("1.802500")  # 1.75 m × 1.03
    lines = explode(db, item(db, "SA-HSG-L100").id, 100, date(2026, 11, 1))
    wip = next(l for l in lines if l["item_code"] == "WIP-HSG-L100-MC")
    al = next(l for l in lines if l["item_code"] == "RM-AL6082-50")
    assert wip["quantity"] == Decimal("102")  # 100 / 99 % yield, whole pieces
    assert al["quantity"] == Decimal("140.476500")  # 102 / 97 % → 106 started × 1.32525 kg


def test_author_cannot_approve_and_approved_bom_is_immutable(as_user, db):
    eng, appr = as_user("rdesai"), as_user("jcrowther")
    bom = create_bom(eng, item(db, "SA-HSG-L100").id, {"lines": [{"component_item_id": item(db, "WIP-HSG-L100-MC").id,
                                                                  "quantity": 1, "unit": "pc"}]})
    with pytest.raises(Exception):
        approve_bom(eng, bom.id)
    approve_bom(appr, bom.id)
    with pytest.raises(InvalidState):
        add_bom_line(eng, bom.id, {"line_no": 99, "component_item_id": item(db, "PC-FST-M5X12").id, "quantity": 1, "unit": "pc"})


def test_allowance_requires_note(as_user, db):
    eng = as_user("rdesai")
    bom = create_bom(eng, item(db, "SA-HSG-L100").id, {})
    with pytest.raises(ValidationFailed):
        add_bom_line(eng, bom.id, {"line_no": 10, "component_item_id": item(db, "WIP-HSG-L100-MC").id, "quantity": 1,
                                   "unit": "pc", "scrap_basis": "allowance_in_quantity"})


def test_released_order_keeps_frozen_revision(as_user, db):
    pm, store = as_user("gholroyd"), as_user("dackroyd")
    wip = item(db, "WIP-HSG-L100-MC")
    o = prod.create_order(pm, pm.site_id, wip.id, 10, effective_on=date(2026, 11, 9))
    prod.plan_order(pm, o.id, o.version, effective_on=date(2026, 11, 9))
    prod.allocate_materials(store, o.id)
    prod.release_order(pm, o.id, o.version)
    snap_before = dict(o.snapshot)
    required_before = o.materials[0].required_quantity
    # engineering change: new version with a longer blank, approved and effective now
    v1 = effective_bom(db, wip.id, date(2026, 11, 9))
    v2 = new_bom_version(as_user("rdesai"), v1.id, "ECN: 260 mm blank", date(2026, 11, 10))
    v2.lines[0].quantity = Decimal("0.26")
    approve_bom(as_user("jcrowther"), v2.id)
    db.refresh(o)
    assert o.snapshot["bom"]["version"] == v1.version
    assert o.snapshot["bom"]["lines"][0]["quantity"] == snap_before["bom"]["lines"][0]["quantity"]
    assert o.materials[0].required_quantity == required_before
    assert o.snapshot.get("frozen") is True
    with pytest.raises(InvalidState):
        prod.refresh_definitions(pm, o.id, o.version)
    assert effective_bom(db, wip.id, date(2026, 11, 11)).version == v2.version
    assert db.get(Bom, v1.id).status == "superseded"
