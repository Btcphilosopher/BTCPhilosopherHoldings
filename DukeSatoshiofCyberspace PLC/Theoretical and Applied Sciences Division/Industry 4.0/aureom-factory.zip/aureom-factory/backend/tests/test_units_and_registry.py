from decimal import Decimal

import pytest

from app.core.errors import UnitConversionError, ValidationFailed
from app.modules.registry.service import (
    approve_conversion, convert, create_item, propose_conversion, to_base, validate_specifications,
)
from tests.helpers import item


def test_same_dimension_global_conversion(db):
    assert convert(db, Decimal("1500"), "g", "kg") == Decimal("1.500000")
    assert convert(db, Decimal("250"), "mm", "m") == Decimal("0.250000")
    assert convert(db, Decimal("2"), "L", "mL") == Decimal("2000.000000")


def test_cross_dimension_needs_approved_item_conversion(db):
    bar = item(db, "RM-AL6082-50")
    assert convert(db, Decimal("0.25"), "m", "kg", bar.id) == Decimal("1.325250")
    # chained: millimetres → metres (global) → kilograms (item rule)
    assert convert(db, Decimal("250"), "mm", "kg", bar.id) == Decimal("1.325250")
    # inverse direction of the approved rule
    assert convert(db, Decimal("5.301"), "kg", "m", bar.id) == Decimal("1.000000")
    with pytest.raises(UnitConversionError):
        convert(db, 1, "m", "kg")  # no item context → never interchange
    with pytest.raises(UnitConversionError):
        convert(db, 1, "kg", "pc", item(db, "PC-LED-M12").id)
    with pytest.raises(UnitConversionError):
        convert(db, 1, "L", "kg", item(db, "CN-CUTFLUID").id)


def test_packs_are_item_specific(db):
    assert convert(db, 2, "pack", "pc", item(db, "PC-FST-M5X12").id) == Decimal("200.000000")
    assert convert(db, 3, "reel", "m", item(db, "PC-CBL-3C075").id) == Decimal("150.000000")
    with pytest.raises(UnitConversionError):
        convert(db, 1, "pack", "pc", item(db, "PC-LED-M12").id)  # packs have no universal size
    with pytest.raises(UnitConversionError):
        convert(db, 1, "pack", "reel", item(db, "PC-FST-M5X12").id)


def test_proposed_conversion_is_not_usable_until_approved(as_user, db):
    eng, appr = as_user("rdesai"), as_user("jcrowther")
    led = item(db, "PC-LED-M12")
    c = propose_conversion(eng, led.id, "box", "pc", Decimal(20), "Box of 20 modules")
    with pytest.raises(UnitConversionError):
        convert(db, 1, "box", "pc", led.id)
    with pytest.raises(Exception):
        approve_conversion(eng, c.id)  # engineer may not approve
    approve_conversion(appr, c.id)
    assert convert(db, 2, "box", "pc", led.id) == Decimal("40.000000")


def test_integral_units_reject_fractions(db):
    with pytest.raises(ValidationFailed):
        to_base(db, item(db, "PC-LED-M12"), Decimal("1.5"), "pc")
    assert to_base(db, item(db, "PC-FST-M5X12"), 1, "pack") == Decimal("100.000000")


def test_unknown_specifications_are_explicit():
    with pytest.raises(ValidationFailed):
        validate_specifications([{"name": "IP rating"}])  # status missing
    with pytest.raises(ValidationFailed):
        validate_specifications([{"name": "IP rating", "status": "unknown", "value": "IP54"}])
    with pytest.raises(ValidationFailed):
        validate_specifications([{"name": "Power", "status": "specified"}])
    out = validate_specifications([{"name": "IP rating", "status": "unknown"}])
    assert out[0]["status"] == "unknown" and out[0]["value"] is None


def test_item_requires_engineer_and_valid_policy(as_user):
    with pytest.raises(Exception):
        create_item(as_user("apatel"), {"item_code": "X-1", "description": "x", "item_type": "raw_material", "base_unit": "kg"})
    with pytest.raises(ValidationFailed):
        create_item(as_user("rdesai"), {"item_code": "X-2", "description": "Bad shelf life", "item_type": "consumable",
                                        "base_unit": "L", "shelf_life_applicable": True})
