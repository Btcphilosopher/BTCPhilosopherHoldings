from decimal import Decimal

import pytest
from sqlalchemy import select

from app.core.errors import InvalidState, PermissionDenied, QualityHold
from app.modules.quality import service as qa
from app.modules.quality.models import InspectionPlan, InspectionResult
from tests.helpers import accepted_stock, item


def _final(as_user, db, n=2):
    store = as_user("dackroyd")
    lots = []
    from app.modules.inventory.service import create_lot, post_movement, bin_by_code
    fg = item(db, "FG-L100")
    for i in range(n):
        l = create_lot(store, fg, f"T-FI-{i}", "production", quality_status="awaiting_review")
        post_movement(store, "production_output", fg, 1, "pc", lot=l, to_bin=bin_by_code(db, "FG-HOLD"), skip_quality_gate=True)
        lots.append(l)
    plan = db.execute(select(InspectionPlan).where(InspectionPlan.code == "FI-L100")).scalar_one()
    return qa.open_inspection(as_user("kmensah"), "final", fg, lots, plan=plan), lots


def _fill(ctx, insp, torque="1.5"):
    for i in range(insp.sample_size):
        ref = f"S{i}"
        qa.record_result(ctx, insp.id, "Visual finish", conforms=True, sample_ref=ref)
        qa.record_result(ctx, insp.id, "Label legible, serial matches", conforms=True, sample_ref=ref)
        qa.record_result(ctx, insp.id, "Arm articulation torque", numeric_value=Decimal(torque), sample_ref=ref)
        qa.record_result(ctx, insp.id, "Functional check", conforms=True, sample_ref=ref)


def test_only_quality_manager_releases_and_completion_does_not_release(as_user, db):
    insp, lots = _final(as_user, db)
    _fill(as_user("kmensah"), insp)
    assert all(l.quality_status == "awaiting_review" for l in lots)
    for who in ("kmensah", "gholroyd", "dackroyd", "apatel"):
        with pytest.raises(PermissionDenied):
            qa.decide(as_user(who), insp.id, "accepted", "x")
    qa.decide(as_user("hbrierley"), insp.id, "accepted", "ok")
    assert all(l.quality_status == "accepted" for l in lots)
    assert item(db, "FG-L100").certifications == []  # never inferred
    ev = qa.evaluate(db, insp)
    assert "do not constitute product certification" in ev["certification_note"]


def test_corrections_keep_original_results(as_user, db):
    insp, _ = _final(as_user, db)
    _fill(as_user("kmensah"), insp, torque="15")
    with pytest.raises(QualityHold):
        qa.decide(as_user("hbrierley"), insp.id, "accepted", "x")
    bad = db.execute(select(InspectionResult).where(InspectionResult.inspection_id == insp.id,
                                                    InspectionResult.numeric_value == Decimal(15))).scalars().all()
    with pytest.raises(PermissionDenied):
        qa.correct_result(as_user("kmensah"), bad[0].id, "typo", numeric_value=Decimal("1.5"))
    for r in bad:
        qa.correct_result(as_user("hbrierley"), r.id, "typo 15 → 1.5", numeric_value=Decimal("1.5"))
    with pytest.raises(InvalidState):
        qa.correct_result(as_user("hbrierley"), bad[0].id, "again", numeric_value=Decimal("1.6"))
    all_rows = qa.all_results(db, insp)
    assert sum(1 for r in all_rows if r.numeric_value == Decimal(15)) == len(bad)  # originals kept
    assert len(qa.effective_results(db, insp)) == len(all_rows) - len(bad)
    qa.decide(as_user("hbrierley"), insp.id, "accepted", "after correction")


def test_out_of_calibration_gauge_blocks_release(as_user, db):
    from app.modules.inventory.service import create_lot, post_movement, bin_by_code
    store = as_user("dackroyd")
    wip = item(db, "WIP-HSG-L100-MC")
    l = create_lot(store, wip, "T-CAL-1", "production", quality_status="awaiting_review")
    post_movement(store, "production_output", wip, 5, "pc", lot=l, to_bin=bin_by_code(db, "WIP-CNC"), skip_quality_gate=True)
    plan = db.execute(select(InspectionPlan).where(InspectionPlan.code == "IP-HSG-DIM")).scalar_one()
    insp = qa.open_inspection(as_user("kmensah"), "in_process", wip, [l], plan=plan)
    k = as_user("kmensah")
    with pytest.raises(Exception):  # gauge must be identified for measured values
        qa.record_result(k, insp.id, "Bore diameter", numeric_value=Decimal("38.05"), value_source="measured")
    for i in range(insp.sample_size):
        qa.record_result(k, insp.id, "Bore diameter", numeric_value=Decimal("38.05"), value_source="measured",
                         equipment_code="CAL-DIG-02" if i == 0 else "CAL-DIG-01", sample_ref=f"S{i}")
        qa.record_result(k, insp.id, "Overall length", numeric_value=Decimal("240"), value_source="measured",
                         equipment_code="CAL-DIG-01", sample_ref=f"S{i}")
    ev = qa.evaluate(db, insp)
    assert not ev["conforming"] and any("calibration" in i for i in ev["issues"])
    with pytest.raises(QualityHold):
        qa.decide(as_user("hbrierley"), insp.id, "accepted", "x")


def test_ncr_holds_stock_and_disposition_is_restricted(as_user, db):
    l = accepted_stock(as_user("dackroyd"), "PC-LED-M12", "T-NCR-1", 10)
    ncr = qa.raise_ncr(as_user("apatel"), source="shop_floor", item_id=l.item_id, lot_ids=[l.id], quantity=10,
                       description="Flicker observed")
    assert l.quality_status == "quarantined"
    with pytest.raises(PermissionDenied):
        qa.disposition_ncr(as_user("kmensah"), ncr.id, "use_as_is", "x")
    qa.disposition_ncr(as_user("hbrierley"), ncr.id, "use_as_is", "Concession C-12: cosmetic only")
    assert l.quality_status == "accepted"


def test_variable_conformity_computed_from_limits(as_user, db):
    insp, _ = _final(as_user, db)
    r = qa.record_result(as_user("kmensah"), insp.id, "Arm articulation torque", numeric_value=Decimal("2.4"))
    assert r.conforms is False
    with pytest.raises(Exception):
        qa.record_result(as_user("kmensah"), insp.id, "Arm articulation torque", numeric_value=Decimal("2.4"), conforms=True)
