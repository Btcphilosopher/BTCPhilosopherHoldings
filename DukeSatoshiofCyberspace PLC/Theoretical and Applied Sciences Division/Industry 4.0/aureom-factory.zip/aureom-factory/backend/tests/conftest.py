"""Test fixtures. Tests run against a real PostgreSQL database (AUREOM_TEST_DATABASE_URL).

The schema is rebuilt from the Alembic migrations once per session and seeded with the
Pennine master data. Each test runs inside a transaction that is rolled back afterwards.
"""
from __future__ import annotations

import os

os.environ.setdefault("AUREOM_TEST_DATABASE_URL", "postgresql+psycopg://aureom:aureom@localhost:5432/aureom_test")
os.environ["AUREOM_DATABASE_URL"] = os.environ["AUREOM_TEST_DATABASE_URL"]
os.environ.setdefault("AUREOM_DISABLE_LISTENER", "1")
os.environ.setdefault("AUREOM_STORAGE_PATH", "/tmp/aureom-test/objects")
os.environ.setdefault("AUREOM_EXPORT_PATH", "/tmp/aureom-test/exports")

import pytest
from sqlalchemy.orm import Session

from app import db as appdb
from app.api_deps import load_user
from app.core.context import Ctx
from app.core.models import Site, User

TEST_URL = os.environ["AUREOM_TEST_DATABASE_URL"]


@pytest.fixture(scope="session")
def engine():
    from app.demo import fixtures as fx
    from app.demo.run import reset_database

    appdb.configure(TEST_URL)
    reset_database(TEST_URL)
    eng = appdb.get_engine()
    with Session(eng) as s:
        ref = fx.seed_reference(s)
        s.flush()
        users = {k: u.id for k, u in ref["users"].items()}
        site = ref["sites"]["PEN"].id
        mk = lambda name: Ctx(db=s, user=load_user(s, users[name]), site_id=site)
        items = fx.seed_items(mk("rdesai"), ref)
        fx.seed_conversions_and_refs(mk("rdesai"), mk("jcrowther"), items, ref)
        fx.seed_engineering(mk("rdesai"), mk("jcrowther"), items, ref)
        fx.seed_opening_stock(mk("dackroyd"), items, ref)
        s.commit()
    yield eng


@pytest.fixture()
def db(engine):
    conn = engine.connect()
    trans = conn.begin()
    session = Session(bind=conn, join_transaction_mode="create_savepoint", expire_on_commit=False)
    try:
        yield session
    finally:
        session.close()
        if trans.is_active:
            trans.rollback()
        conn.close()


@pytest.fixture()
def as_user(db):
    site = db.query(Site).filter_by(code="PEN").one().id

    def make(username: str, site_id: int | None = None) -> Ctx:
        u = db.query(User).filter_by(username=username).one()
        return Ctx(db=db, user=load_user(db, u.id), site_id=site_id or site)

    return make
