# Operations

## Processes

| Process | Command | Notes |
|---|---|---|
| API | `uvicorn app.main:app --host 0.0.0.0 --port 8000` | Container entrypoint `api` runs `alembic upgrade head` first |
| Worker | `python -m app.workers.worker` (`--once` to drain and exit) | Never migrates; several workers may run concurrently |
| Front end | `node server.js` (Next.js standalone) | Proxies `/api/*` to `AUREOM_API_URL` |
| Database | PostgreSQL 16 | Schema managed only by Alembic (`backend/migrations`) |

## Migrations

```bash
cd backend && AUREOM_DATABASE_URL=postgresql+psycopg://... alembic upgrade head
```

`0001_initial` creates the schema; `0002_append_only` installs the triggers that make the journals
append-only. Do not hand-edit tables protected by those triggers; post correcting entries instead.

## Background jobs

Jobs are rows in `jobs`, enqueued with `POST /api/jobs` (`{"kind": ..., "payload": {...}, "dedupe_key": ...}`)
or by inserting rows directly. The worker claims one job at a time with `FOR UPDATE SKIP LOCKED`, runs it
as the requesting user (or the `system` user), and retries failures up to `max_attempts` (default 3) with
a 10 s × attempt back-off before marking the job `failed` with the error text.

| Kind | Permission to enqueue | Payload | Effect |
|---|---|---|---|
| `mrp_run` | `planning.run` | `site_id`, `as_of?`, `horizon_days?` | MRP run with proposals (never releases anything) |
| `schedule_run` | `production.plan` | `site_id`, `start_at?`, `horizon_days?` | Finite-capacity schedule; writes planned dates |
| `import_items` | `registry.edit` | `csv`, `source?` | Idempotent item import (same file = no-op; differing rows reported as conflicts, never overwritten) |
| `machine_poll` | `maintenance.read` | `at?` | Reads the simulated, read-only machine adapter for equipment with `adapter_ref` |
| `notify_overdue` | `reports.read` | `today?` | In-app notifications for late deliveries, calibration due, inspections open > 2 days |
| `report_traceability` | `reports.read` | `lot_id` | Generates an HTML traceability report into protected storage |
| `costing_export` | `costing.export` | `order_id` | Exports a closed order's actual cost to the simulated accounting adapter |

There is no built-in periodic scheduler: use cron (or a container scheduler) to enqueue recurring jobs
such as `notify_overdue` and `machine_poll`. Email/SMS delivery is not implemented.

## Backups

```bash
AUREOM_DB_URL=postgresql://aureom:PASSWORD@localhost:5432/aureom_factory \
AUREOM_STORAGE_PATH=/data/objects BACKUP_DIR=/backups scripts/backup.sh
```

Produces, with a UTC timestamp:

* `aureom_<ts>.dump` — `pg_dump` custom format (no owners/privileges);
* `aureom_<ts>.objects.tar.gz` — the protected document store (if present);
* `aureom_<ts>.manifest.json` — SHA-256 of both files and row counts of key tables.

With Compose (the backend image includes the PostgreSQL client tools):

```bash
docker compose run --rm -v ./scripts:/scripts:ro \
  -e AUREOM_DB_URL=postgresql://aureom:PASSWORD@db:5432/aureom_factory -e BACKUP_DIR=/exports/backups \
  api sh /scripts/backup.sh
```

The backup lands in the `exports` volume; copy it off the host. Alternatively run the script on the
host with `psql`/`pg_dump` 16 or later installed.

## Restore (tested)

```bash
AUREOM_DB_URL=postgresql://aureom:PASSWORD@localhost:5432/aureom_restore CREATE_DB=1 \
scripts/restore.sh /backups/aureom_<ts>.dump
```

The script verifies the dump checksum against the manifest, optionally drops and recreates the target
database (`CREATE_DB=1` — be certain of the target), runs `pg_restore --exit-on-error`, optionally
restores documents (`RESTORE_OBJECTS=1` with `AUREOM_STORAGE_PATH`), and checks restored row counts
against the manifest. `tests/test_zz_backup_restore.py` runs both scripts against the demonstration
database and additionally checks a checksum of the whole movement journal, recomputes balances from the
journal, and confirms the append-only triggers survive restoration.

Recommended: run `backup.sh` daily, keep copies off-site, and rehearse a restore regularly into a
scratch database.

## Demonstration data

`python -m app.demo.run --reset` (or `docker compose --profile demo run --rm demo`) **drops the
`public` schema of the configured database** and rebuilds it with fictional Pennine Manufacturing
Demonstrator data. Never point it at a database you want to keep. All demo users have the password
`demo`.

## Health and monitoring

* `GET /api/health` checks database connectivity (used by the Compose health check).
* `GET /api/system/info` reports adapters in use (all simulated) and capability caveats.
* `inventory.service.verify_journal` recomputes balances from the journal; it should always return no
  discrepancies.
