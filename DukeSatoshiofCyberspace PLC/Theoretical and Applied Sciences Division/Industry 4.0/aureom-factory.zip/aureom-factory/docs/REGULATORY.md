# Regulated manufacturing — position statement

**AUREOM FACTORY makes no claim of readiness, compliance or validation for any regulated sector**
(food, pharmaceutical, medical device, aerospace, automotive, defence or any other). Nothing in the
platform, its demonstration data or its documentation should be read as such a claim. The Pennine
demonstration product has **no product certification recorded**, and the platform never infers
certification or marking from inspections passing.

Before any such claim could be made, the applicable requirements must be researched for the specific
products, markets and customers, a gap assessment carried out, and the system validated in its intended
use by people competent in that regime.

## Frameworks that would need assessment (non-exhaustive)

| Sector | Examples of requirements to research |
|---|---|
| Pharmaceutical / life sciences | US FDA 21 CFR Part 11 (electronic records and signatures), 21 CFR Parts 210/211; EU GMP Annex 11 (computerised systems) and Annex 15; GAMP 5 guidance on validation |
| Medical devices | US FDA 21 CFR Part 820 (quality management system regulation), ISO 13485, UDI requirements, EU MDR 2017/745 / UK MDR 2002 |
| Aerospace | AS9100 quality management, AS9102 first article inspection, AS9145 (APQP/PPAP), counterfeit-part prevention (AS5553/AS6174), customer flow-downs |
| Automotive | IATF 16949, PPAP, customer-specific requirements |
| Food and food contact | Regulation (EC) 178/2002 (one-step-up/one-step-down traceability) and retained UK equivalent, HACCP-based controls, Regulation (EC) 1935/2004 for food-contact materials, BRCGS/IFS schemes |
| Electrical products (relevant to the demo lamp) | UK Electrical Equipment (Safety) Regulations 2016 and UKCA marking; EU Low Voltage Directive 2014/35/EU and CE marking; harmonised product standards; EMC and RoHS obligations |

## What the platform provides that may be relevant

* Attributed, timestamped, append-only audit trail; append-only stock journal, inspection results,
  lot-status history, operation events and genealogy, enforced by database triggers.
* Corrections recorded as new entries with a reason, keeping the original visible.
* Separation of observation time and recording time; measured / manual / calculated value labelling.
* Role- and site-scoped permissions; restricted release and disposition; segregation-of-duties checks
  for BOM approval, purchase approval, substitution approval and scrap authorisation.
* Calibration references on measurements; results from out-of-calibration equipment cannot support release.
* Frozen BOM and routing revisions per order; lot/serial genealogy with stated precision.
* Backups with checksummed manifests and a tested restore procedure.

## Known gaps (examples)

* No electronic signatures with re-authentication, signature meaning or signature manifestation.
* No computer-system validation package (URS, risk assessment, IQ/OQ/PQ, traceability matrix).
* No formal sampling standard; sampling plans are configurable bands only.
* No document control workflow (review, approval, periodic review, training records) for SOPs and
  instructions; documents are stored and protected but not lifecycle-managed.
* No training/competence records beyond a list of operator skills.
* No complaint handling, deviation/change-control workflows, supplier qualification programme or
  formal CAPA effectiveness review.
* Audit trail review tooling, time synchronisation evidence, data retention and archival policies are
  not defined.
* Single sign-on, MFA and password policies are not implemented.
* All external interfaces (accounting, machines, scales, suppliers) are simulated.
