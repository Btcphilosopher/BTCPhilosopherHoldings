# AUREOM FACTORY — Architecture

AUREOM FACTORY is a **modular monolith**: one FastAPI application and one PostgreSQL database, with each
business area in its own package (`backend/app/modules/<module>/{models,service,api}.py`). Modules call
each other only through service functions, never through another module's API. A background worker and
a Next.js front end complete the system.

```
 Browser (Next.js, :3000) ──/api/* rewrite──▶ FastAPI (:8000) ──▶ PostgreSQL 16
        │                                         │   ▲  pg_notify('aureom_events')
        └────────── WebSocket /ws ◀── realtime hub ┘   │
                                                  Worker (jobs table, FOR UPDATE SKIP LOCKED)
                       private volume /data/objects ◀── documents (never served directly)
```

## Module map

| Module | Responsibility |
|---|---|
| `core` | Sites, users, site-scoped roles, audit log, idempotency records, number sequences, jobs, notifications, offline entries; `Ctx` (who/where/transaction), permission checks, signed tokens |
| `registry` | Common item registry (all eight item types), units, approved item-specific unit conversions, explicit specifications (`specified` / `unknown` / `not_applicable`), supplier references |
| `engineering` | Work centres, versioned BOMs (loss basis, yield, alternatives, packaging, effective dates), routings (operations, equipment, skills, setup/run, inspection points, subcontract), cycle detection, explosion, snapshots |
| `inventory` | Warehouses, bins, lots/serials, quality status history, append-only movement journal, balances, reservations, split/merge |
| `purchasing` | Suppliers, requisitions, purchase orders, acknowledgement, substitutions, goods receipts, invoices (three-way match), supplier returns |
| `quality` | Sampling plans, inspection plans, inspections, results and corrections, nonconformance, disposition, corrective actions |
| `production` | Production orders, materials, operations, shop-floor events, consumption (actual and backflush), output, scrap, rework, subcontract shipments, cancellation, offline reconciliation |
| `genealogy` | Lot/order graph with quantities and precision; backward and forward traceability |
| `planning` | Demand, MRP runs and proposals, finite-capacity scheduling baseline, working calendars |
| `maintenance` | Equipment, service schedules, work orders, downtime, calibration, availability restrictions, machine observations, OEE |
| `costing` | FX rates, overhead rules, standard / planned / actual / estimate-at-completion / posted cost, incremental scenarios, accounting export |
| `dispatch` | Customers, customer orders, allocation, picking, packing, shipment, delivery, customer returns, recalls; labels, packing lists and reports |
| `documents` | Protected object storage (content-addressed local store) and signed download links |
| `adapters` | Typed `Protocol`s for accounting, machine (read-only), scale, scanner and supplier systems; simulated implementations only |
| `workers` | Job handlers: MRP, scheduling, idempotent item import, machine polling, overdue notifications, traceability report, costing export |
| `realtime` | WebSocket hub fed by PostgreSQL `LISTEN aureom_events` |

## Key invariants

1. **Append-only records.** `stock_movements`, `audit_log`, `inspection_results`, `lot_status_history`,
   `operation_events` and `genealogy_edges` reject `UPDATE`, `DELETE` and `TRUNCATE` through database
   triggers (migration `0002_append_only`). Stock corrections are linked reversals
   (`reverses_movement_id`, unique, so a movement can be reversed once); result corrections are new rows
   with `supersedes_result_id` and a reason.
2. **Transactional balances.** Each movement and its balance change are written in the same transaction.
   Balance rows are locked `SELECT … FOR UPDATE` in a deterministic order; a `CHECK (quantity >= 0)`
   backs the application check. Serial numbers can never exceed quantity one.
3. **Physical versus available.** Physical stock is everything in any bin (receiving, quarantine, WIP,
   subcontractor, dispatch). Available stock is accepted, unexpired, company-owned stock in *allocatable*
   bins minus unissued reservations. Stock reserved for one demand cannot be moved away for another.
4. **Quality gating.** Lots that are not `accepted` cannot be reserved, issued, consumed, dispatched or
   placed in an allocatable bin. All receipts and all production output start as `awaiting_review` in a
   non-allocatable bin. Only `quality.release` can accept; only `quality.disposition` can reject. Placing
   stock on hold (quarantine) also releases its reservations. A scan identifies; it never verifies.
5. **Concurrent reservation safety.** Reservation locks the candidate balance rows before reading
   availability, so concurrent requests serialise and cannot both be promised the same stock
   (`tests/test_concurrency.py`).
6. **Frozen definitions.** Planning an order snapshots the approved BOM and routing revisions into the
   order (`snapshot`) and creates its material and operation lines; release marks the snapshot frozen.
   Approving a new BOM version never changes an order already planned or released; moving an unreleased
   order to a newer revision is an explicit `refresh-definitions` action.
7. **Separate outcomes.** Operation completion, reported output, quality-accepted output and order
   closure are separate fields and states. An order reaches `completed` only when every good output lot
   is accepted or rejected (a hold is not a decision), and `closed` only when issued material is fully
   consumed, returned or scrapped, backflush is reconciled and scrap is authorised.
8. **Genealogy precision.** Edges are `exact` (scanned at output, split, merge, single-lot subcontract),
   `order_level` (consumed by the order; any output *may* contain it unless exact records for that item
   name other lots) or `unknown` (lot provenance incomplete). Precision is only ever degraded along a
   path. Rework preserves unit identity: units reworked together are not linked to each other.
9. **Five cost figures.** Standard, planned (frozen at planning), recorded actual (lot costs from
   consumption movements, booked time clipped to shift calendars, subcontract PO prices, authorised
   scrap, configured overhead), estimate at completion, and financially posted (exported). All amounts
   are in the base currency with stated FX rate dates. Incremental (one-more-unit) scenarios exclude
   allocated overhead and state their assumptions.
10. **Read-only machine data.** The machine adapter has no write or control method. Telemetry is stored
    as observations; a machine-reported fault creates only an *unconfirmed* downtime suggestion and a
    discrepancy note, never overriding operator, maintenance or quality records.
11. **Offline entries are pending.** Shop-floor entries captured offline are stored as `pending` and
    have no effect until a supervisor reconciles them, at which point the normal validated service runs
    with the entry id as idempotency key.

## Material flow

```mermaid
flowchart LR
  D[Demand] --> MRP[MRP proposals] --> PR[Requisition] --> PO[Purchase order] --> GR[Goods receipt\nRCV-01 awaiting_review]
  GR --> INC{Incoming inspection}
  INC -- accepted --> ST[Stores\nallocatable]
  INC -- rejected --> QT[Quarantine] --> SR[Supplier return]
  ST -- reserve/issue --> WIP[Line-side WIP]
  WIP -- consumption --> MO[Production order]
  WIP -- subcontract send --> SUB[At subcontractor\ncompany-owned]
  SUB -- return --> GR
  MO -- output --> HOLD[FG hold\nawaiting_review]
  MO -- scrap --> SCR[Scrap / recoverable]
  HOLD --> FI{Final inspection}
  FI -- accepted --> FG[Finished goods\nallocatable]
  FI -- nonconforming --> NCR[NCR] --> RW[Rework order] --> HOLD
  FG -- allocate/pick --> DSP[Dispatch bay] -- dispatch --> C[Customer]
  C -- return --> RTN[Returns review\nawaiting_review]
```

## State machines

**Production order**

```
draft ─plan─▶ planned ─release─▶ released ─start─▶ in_progress ⇄ paused
                                                   │ all operations complete
                                                   ▼
                                           awaiting_inspection ─all output decided─▶ completed ─close─▶ closed
draft / planned / released / in_progress / paused ─cancel (controlled)─▶ cancelled
```

**Lot quality status**: `awaiting_review` → `accepted` | `rejected` | `quarantined`; `accepted` →
`quarantined` (hold, NCR, recall); `quarantined` → `accepted` (release / concession) | `rejected`;
`rejected` → `awaiting_review` only via an authorised rework order; a customer return puts the lot
back to `awaiting_review` in the returns bin. Every change is in
`lot_status_history` with who and why.

**Purchase order**: `draft` → `approved` (by someone other than the author) → `sent` → `acknowledged`
→ `partially_received` → `received`. Returns with replacement expected reopen the line.

## Technology

* Backend: Python 3.13, FastAPI, SQLAlchemy 2, psycopg 3, Alembic, Pydantic 2.
* Database: PostgreSQL 16 (`NULLS NOT DISTINCT` unique constraint on balances; triggers; `LISTEN/NOTIFY`).
* Front end: Next.js 15, React, TypeScript.
* Packaging: Docker Compose (`db`, `api`, `worker`, `frontend`; `demo` and `tests` profiles).
