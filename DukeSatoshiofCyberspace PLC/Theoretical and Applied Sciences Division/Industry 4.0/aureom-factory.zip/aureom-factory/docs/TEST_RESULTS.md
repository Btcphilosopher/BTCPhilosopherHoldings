# Test results

Recorded 2026-11-27 11:09 UTC in the build container: Python 3.13.18, PostgreSQL 16.15, Node 22, Next.js 15.5.29.

Command: `cd backend && python -m pytest -v` against a real PostgreSQL database (`AUREOM_TEST_DATABASE_URL`).

```
tests/test_api_and_permissions.py::test_authentication PASSED
tests/test_api_and_permissions.py::test_restricted_actions_and_site_scope PASSED
tests/test_api_and_permissions.py::test_validation_rejects_unknown_fields_and_bad_values PASSED
tests/test_api_and_permissions.py::test_optimistic_concurrency_on_item_edit PASSED
tests/test_api_and_permissions.py::test_idempotency_key_replays_and_detects_misuse PASSED
tests/test_api_and_permissions.py::test_scan_identifies_but_does_not_verify PASSED
tests/test_api_and_permissions.py::test_protected_documents PASSED
tests/test_api_and_permissions.py::test_websocket_requires_token PASSED
tests/test_api_and_permissions.py::test_openapi_lists_modules PASSED
tests/test_api_and_permissions.py::test_system_account_cannot_log_in PASSED
tests/test_api_and_permissions.py::test_operator_cannot_read_audit_or_jobs PASSED
tests/test_bom_and_revisions.py::test_direct_and_indirect_cycles_are_rejected PASSED
tests/test_bom_and_revisions.py::test_allowance_is_not_double_counted PASSED
tests/test_bom_and_revisions.py::test_expected_loss_and_yield_are_separate PASSED
tests/test_bom_and_revisions.py::test_author_cannot_approve_and_approved_bom_is_immutable PASSED
tests/test_bom_and_revisions.py::test_allowance_requires_note PASSED
tests/test_bom_and_revisions.py::test_released_order_keeps_frozen_revision PASSED
tests/test_concurrency.py::test_concurrent_reservations_cannot_overcommit PASSED
tests/test_costing.py::test_actual_cost_from_consumption_and_booked_time PASSED
tests/test_costing.py::test_booked_time_is_clipped_to_shift_calendar PASSED
tests/test_costing.py::test_planned_cost_states_rates_and_basis PASSED
tests/test_costing.py::test_standard_cost_rollup_uses_fx_and_batch PASSED
tests/test_costing.py::test_incremental_cost_excludes_allocated_overhead_and_fixed_labour PASSED
tests/test_imports_and_jobs.py::test_import_is_idempotent_and_never_overwrites PASSED
tests/test_imports_and_jobs.py::test_offline_entries_stay_pending_until_reconciled PASSED
tests/test_imports_and_jobs.py::test_notification_job PASSED
tests/test_inventory.py::test_journal_is_append_only PASSED
tests/test_inventory.py::test_reversal_is_linked_and_restores_balance PASSED
tests/test_inventory.py::test_reversal_cannot_create_negative_stock PASSED
tests/test_inventory.py::test_negative_stock_is_impossible PASSED
tests/test_inventory.py::test_quarantined_stock_is_physical_but_not_available PASSED
tests/test_inventory.py::test_quarantine_releases_existing_reservations PASSED
tests/test_inventory.py::test_reserved_stock_cannot_be_moved_away PASSED
tests/test_inventory.py::test_split_and_merge_preserve_provenance_and_quantities PASSED
tests/test_inventory.py::test_serial_cannot_exist_twice PASSED
tests/test_production.py::test_full_order_keeps_completion_acceptance_and_closure_separate PASSED
tests/test_production.py::test_operator_skill_and_permissions PASSED
tests/test_production.py::test_cancelling_partially_executed_order_requires_material_disposition PASSED
tests/test_production.py::test_backflush_is_calculated_and_reconciled PASSED
tests/test_production.py::test_rework_requires_disposition_and_approved_instructions PASSED
tests/test_purchasing.py::test_partial_receipts_keep_quantities_separate PASSED
tests/test_purchasing.py::test_over_receipt_beyond_tolerance_is_refused PASSED
tests/test_purchasing.py::test_receipt_against_unsent_po_refused PASSED
tests/test_purchasing.py::test_damaged_goods_segregated_and_returned PASSED
tests/test_purchasing.py::test_substitution_requires_approval PASSED
tests/test_purchasing.py::test_receipt_idempotency PASSED
tests/test_purchasing.py::test_fx_conversion_uses_dated_rate PASSED
tests/test_quality.py::test_only_quality_manager_releases_and_completion_does_not_release PASSED
tests/test_quality.py::test_corrections_keep_original_results PASSED
tests/test_quality.py::test_out_of_calibration_gauge_blocks_release PASSED
tests/test_quality.py::test_ncr_holds_stock_and_disposition_is_restricted PASSED
tests/test_quality.py::test_variable_conformity_computed_from_limits PASSED
tests/test_units_and_registry.py::test_same_dimension_global_conversion PASSED
tests/test_units_and_registry.py::test_cross_dimension_needs_approved_item_conversion PASSED
tests/test_units_and_registry.py::test_packs_are_item_specific PASSED
tests/test_units_and_registry.py::test_proposed_conversion_is_not_usable_until_approved PASSED
tests/test_units_and_registry.py::test_integral_units_reject_fractions PASSED
tests/test_units_and_registry.py::test_unknown_specifications_are_explicit PASSED
tests/test_units_and_registry.py::test_item_requires_engineer_and_valid_policy PASSED
tests/test_zy_demo_scenario.py::test_all_steps_ran PASSED
tests/test_zy_demo_scenario.py::test_outcomes PASSED
tests/test_zy_demo_scenario.py::test_costs_and_exports PASSED
tests/test_zy_demo_scenario.py::test_recall_findings PASSED
tests/test_zz_backup_restore.py::test_backup_and_restore_roundtrip PASSED
======================== 64 passed, 1 warning in 20.54s ========================
```

The single warning is a third-party deprecation notice (Starlette TestClient / httpx), not a project issue.

## Coverage of the required test areas

| Area | Tests |
|---|---|
| Unit conversions | `test_units_and_registry.py` (global, item-specific, chained, packs, approval gate, integral units) |
| BOM cycles | `test_bom_and_revisions.py::test_direct_and_indirect_cycles_are_rejected` |
| Revision preservation | `test_bom_and_revisions.py::test_released_order_keeps_frozen_revision` |
| Concurrent reservations | `test_concurrency.py` (two threads, real commits, exactly one succeeds) |
| Partial receipts | `test_purchasing.py::test_partial_receipts_keep_quantities_separate` |
| Stock reversals | `test_inventory.py::test_reversal_*`, append-only trigger test |
| Batch genealogy | `test_inventory.py::test_split_and_merge_*`, `test_zy_demo_scenario.py::test_outcomes` |
| Quarantine restrictions | `test_inventory.py::test_quarantined_stock_*`, `test_quarantine_releases_existing_reservations` |
| Rework | `test_production.py::test_rework_requires_disposition_*`, demo scenario |
| Cost calculations | `test_costing.py` (actual from consumption + booked time, shift clipping, FX, roll-up, incremental) |
| Permissions | `test_api_and_permissions.py`, plus segregation-of-duties checks across modules |
| Restoration | `test_zz_backup_restore.py` (shipped `backup.sh` → `restore.sh` into a new database; counts, journal checksum, triggers, journal re-verification) |

## Other verification performed

* `python -m app.demo.run --reset` — all 18 demonstration steps completed (see `DEMO_RESULTS.md`); movement journal recomputed with 0 discrepancies.
* Frontend: `tsc --noEmit` clean; `next build` succeeded (18 routes).
* Browser check (headless Chromium against the running API + built frontend): all 12 office pages, order detail, schedule, recall and the tablet shop-floor terminal loaded with no console errors and no failed API calls; live WebSocket update observed after a stock adjustment. Screenshots in `docs/screenshots/`.
* `docker compose config` validated. **Containers were not built or run** — no Docker daemon in the build environment.
