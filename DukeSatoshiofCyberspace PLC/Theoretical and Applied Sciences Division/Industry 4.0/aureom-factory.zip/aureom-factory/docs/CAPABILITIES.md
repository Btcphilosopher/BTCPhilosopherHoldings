# AUREOM FACTORY — capability status

Statuses:

* **Implemented** — working in this release, exercised by tests and/or the Pennine demonstration.
* **Simulated** — the integration point exists behind a typed adapter, but only a simulated
  implementation ships. No external system is contacted.
* **Integrated** — connected to a real external system. **Nothing in this release is integrated.**
* **Deferred** — not built; listed so that nobody assumes it exists.

Claims below were checked against the backend code. Front-end rows describe the Next.js application in
`frontend/`.

## 1. Core workflow

| Capability | Status | Notes |
|---|---|---|
| Demand → MRP → purchasing → receipt → inspection → allocation → production → quality → finished stock → dispatch | Implemented | Whole chain run end to end by `python -m app.demo.run --reset` and `tests/test_zy_demo_scenario.py` |
| Subassemblies, purchased components, packaging | Implemented | Multi-level BOMs; packaging lines flagged and backflushable |
| Scrap, rework, supplier returns, subcontracted operations, recalls | Implemented | See sections 13–16 |
| Planned vs physical vs recorded vs accepted kept distinct | Implemented | Separate fields/tables for each; see ARCHITECTURE.md invariants 3 and 7 |

## 2. Interface

| Capability | Status | Notes |
|---|---|---|
| Navigation Overview · Materials · Purchasing · Inventory · Products · Planning · Production · Quality · Maintenance · Costing · Dispatch · Reports | Implemented (front end) | Midnight-navy navigation, pale workspaces, orange production accents, cyan flow diagrams, amber constraints, red failures |
| Tablet shop-floor screens | Implemented (front end) | Large-target operator views backed by `/api/shopfloor/*` and operation endpoints |
| Barcode scanning: keyboard-wedge scanners | Implemented | Any wedge scanner types into the scan field; `POST /api/scan` parses `LOT:`, `SER:`, `BIN:`, `MO:`, `EQP:`, `ITM:` and GS1-style `(01)(10)(21)` |
| Barcode scanning: device camera | Implemented, browser-dependent | Uses the browser `BarcodeDetector` API where available; otherwise falls back to manual/wedge entry |
| Accessible alternatives to diagrams | Implemented (front end) | Flow and timeline data also rendered as tables (`/api/reports/material-flow` returns tabular edges) |
| Original Aureom branding | Implemented | No third-party brand assets |
| Office-screen actions | Partly implemented (front end) | UI actions: PO approve/send/acknowledge, goods receipt, requisition approval, MRP accept/reject, schedule recalculation, order plan/allocate/release/close, inspection release/hold/reject, NCR disposition, movement reversal, machine-adapter read, cost export. **API-only in this release (UI deferred):** creating/editing items, BOMs and routings, customer-order entry, allocation/picking/packing/dispatch, scrap authorisation, rework-order creation, recall opening — all exercised by the demo and tests through the API/service layer |
| Shop-floor terminal | Implemented (front end) | Authorised work list (skill-checked), frozen instructions, equipment readiness checklist, start/pause/resume/complete with observed time, scan-to-identify, consumption with value source, quantities/output, measurements, defects, handover, offline PENDING queue with sync |
| Genealogy diagram | Implemented (front end) | Backward/forward graph with confirmed/possible/unknown styling and table alternative |

## 3. Architecture

| Capability | Status | Notes |
|---|---|---|
| Next.js / React / TypeScript, Python / FastAPI, PostgreSQL | Implemented | |
| Modular monolith with separate purchasing, stock, engineering, production, quality, costing modules | Implemented | `backend/app/modules/*` |
| Background workers (planning, imports, notifications, reports) | Implemented | `app.workers.worker`, `FOR UPDATE SKIP LOCKED`, retries with back-off; job kinds in OPERATIONS.md |
| WebSockets for operational updates | Implemented | Transactional `pg_notify` → `LISTEN` thread → `/ws` |
| Protected object storage for drawings/certificates | Implemented (local private volume) | Content-addressed, SHA-256 verified, signed 5-minute links, restricted classification |
| S3 / MinIO object storage backend | Deferred | Only `LocalObjectStore` exists |
| Docker Compose | Implemented | Not validated by running containers in the build environment (no Docker daemon); `docker compose config` validated |
| Typed adapters: accounting, machinery, scales, scanners, supplier systems | Simulated | `app/adapters/base.py` Protocols; `simulated.py` implementations; any other `AUREOM_ADAPTER_MODE` fails at start-up |

## 4. Materials and products (item registry)

| Capability | Status | Notes |
|---|---|---|
| Item types: raw, purchased component, consumable, WIP, subassembly, finished, packaging, recoverable scrap | Implemented | DB check constraint |
| item_code, description, type, revision, base unit, approved conversions, specifications, storage, lot/serial policy, shelf life, supplier references, active status | Implemented | |
| Unknown specifications recorded explicitly | Implemented | Every spec line must be `specified`, `unknown` or `not_applicable` |
| No interchange of kg / m / L / pc / packs without valid conversion | Implemented | Cross-dimension and pack conversions only via *approved* item-specific rules; whole-unit check for pieces/packs |
| Optimistic concurrency on item edits | Implemented | `version` → 409 |

## 5. Bills of materials and routings

| Capability | Status | Notes |
|---|---|---|
| Versioned BOMs: components, quantities, units, expected loss, approved alternatives, packaging, effective dates | Implemented | Line- and header-level effective dates; parent yield separate from component loss |
| Avoid double-counting of scrap allowance | Implemented | `scrap_basis = allowance_in_quantity` (note required) vs `net_plus_loss` |
| Routings: sequence, work centre, equipment, skills, setup, run, inspection points, instructions, subcontract | Implemented | Instruction documents linkable; operation dependencies |
| Circular BOM detection | Implemented | On line add and on approval, with the offending path |
| Approval by someone other than the author | Implemented | Restricted to `engineering_approver` |
| Snapshot of approved revisions per order; engineering changes do not rewrite released work | Implemented | Snapshot on planning, frozen at release; `tests/test_bom_and_revisions.py` |
| Formal engineering change order workflow (ECO object with impact analysis) | Deferred | New BOM version carries a change note only |

## 6. Procurement

| Capability | Status | Notes |
|---|---|---|
| Requisition → approval → PO → acknowledgement → receipt → reconciliation | Implemented | Segregation of duties for requisition and PO approval |
| Supplier, item/spec, quantity/unit, agreed price, currency, expected delivery, partial receipts, inspection requirement, certificates, supplier lots | Implemented | |
| Ordered / received / accepted / rejected / returned / invoiced kept separate | Implemented | Three-way match flags quantity and price variances |
| Late deliveries | Implemented | Days late on receipt; overview and `notify_overdue` job |
| Substitutions requiring approval | Implemented | Receipt of a different item is refused without an approved substitution |
| Damaged goods | Implemented | Segregated to a quarantined lot at receipt |
| Supplier returns | Implemented | Requires stock on hold; updates PO returned quantity; replacement optionally expected |
| Supplier transmission / acknowledgement via supplier systems | Simulated | `SimulatedSupplierPortal`; acknowledgement is recorded manually through the API |

## 7. Inventory and warehouse

| Capability | Status | Notes |
|---|---|---|
| Stock by item & revision, site, warehouse, bin, lot/serial, ownership, quality status, expiry | Implemented | Revision is part of the item identity (`item_code`+`revision`) |
| Receipt, transfer, reservation, issue, return, consumption, output, quarantine, scrap, adjustment, dispatch | Implemented | Plus supplier return, subcontract send/return, customer return, reversal |
| Append-only journal with linked reversals | Implemented | Enforced by DB triggers |
| Transactional balances; prevention of incompatible concurrent allocations | Implemented | Row locks; concurrency test |
| Physical vs available; quarantined/rejected never allocated | Implemented | |
| Lot split / merge with provenance | Implemented | |
| Customer-owned and supplier-consignment stock | Partial | `ownership` field and balances support it; no dedicated consignment workflows; allocation uses company-owned stock only |
| Cycle counting programme | Deferred | Adjustments with reason codes only |

## 8. Planning and material requirements

| Capability | Status | Notes |
|---|---|---|
| Transparent MRP: demand, approved BOMs, available stock, reservations, open supply, lead times, lot sizes, yield, effective dates, safety stock | Implemented | Per-item netting explanation; stock awaiting inspection counted and labelled |
| Proposals only; no automatic financial commitment or release | Implemented | Accepting creates a requisition (needs approval) or a draft order |
| Finite-capacity scheduling: machine calendars, staff skills and shifts, maintenance/downtime, setup, dependencies, material availability | Implemented (baseline heuristic) | Forward, earliest-due-date, greedy; **not an optimiser**; reports infeasibility and estimated lateness |
| What-if planning, capacity levelling, optimisation | Deferred | |

## 9–10. Production orders and shop floor

| Capability | Status | Notes |
|---|---|---|
| Statuses draft → planned → released → in progress / paused → awaiting inspection → completed → closed; cancelled | Implemented | |
| Order records: product, target, snapshots, allocations, resources, planned dates, operations, consumption, output, scrap, rework, exceptions | Implemented | |
| Operation completion, accepted output and closure separate | Implemented | |
| Controlled cancellation of partially executed orders with return of unused material | Implemented | Every line-side quantity must be dispositioned |
| Operator screens: authorised work, instructions, lot scanning, equipment readiness, start/pause, measurements, consumption, output and scrap, defects, handover | Implemented | Skill check on start; readiness check (status, downtime, calibration, kind) before start |
| Operator, equipment, observation time and recording time captured | Implemented | `observed_at` vs `recorded_at` on events, movements and results |
| Measured / manual / calculated values distinguished | Implemented | `value_source` on movements, events and results |
| Barcode identification does not establish conformity | Implemented | Status gates apply regardless of scan |
| Backflush labelled as calculated, with reconciliation | Implemented | Closure blocked until reconciled |
| Offline entries kept pending until reconciled | Implemented | Supervisor reconciliation; duplicate client ids detected; no stock promised offline |

## 11. Material genealogy

| Capability | Status | Notes |
|---|---|---|
| Supplier lot → stock → consumption → intermediate → finished batch/serial → shipment | Implemented | |
| Splitting, merging, multiple inputs, subassemblies, rework, returns | Implemented | |
| Backward / forward queries; shipments and remaining stock/WIP | Implemented | `/api/trace/*`, HTML traceability report |
| No fabricated exact traceability | Implemented | `exact` / `order_level` / `unknown` precision, never upgraded |

## 12. Quality

| Capability | Status | Notes |
|---|---|---|
| Incoming, in-process, final inspection; sampling plans; measurement results | Implemented | Sampling plans are **configurable lot-size bands**, not an implementation of any sampling standard |
| Calibration references on results | Implemented | Results with out-of-calibration equipment are kept but block release |
| Nonconformance, disposition, corrective actions | Implemented | Basic CAPA records (no effectiveness review workflow) |
| Accepted / quarantined / rejected / awaiting review separated | Implemented | |
| Release and disposition by authorised quality staff only | Implemented | |
| Completed order does not release goods | Implemented | |
| Original results kept with corrections | Implemented | |
| No certification inferred from passing checks | Implemented | Certifications are a separate, evidence-based list (empty in the demo) |
| Electronic signatures with re-authentication | Deferred | Decisions are attributed to the logged-in user only |

## 13. Scrap, rework, subcontracting

| Capability | Status | Notes |
|---|---|---|
| Scrap: quantity, reason, location, recoverability, authorisation | Implemented | Authoriser must differ from reporter; recoverable scrap creates a lot |
| Rework as linked work: approved instructions (rework routing), additional materials, cost, inspection, revised genealogy | Implemented | |
| Subcontracting: material sent, external operation, returned, supplier documents, losses, acceptance | Implemented | Material at the subcontractor stays visible as company-owned stock |

## 14. Costing

| Capability | Status | Notes |
|---|---|---|
| Standard, planned, recorded actual, estimate at completion, financially posted | Implemented | |
| Materials, labour, machine, subcontract, packaging, scrap, configured overhead | Implemented | Booked time clipped to shift calendars |
| Explicit currencies, price dates, allocation rules | Implemented | FX table with dates; overhead rules with basis |
| Incremental-cost scenarios separate from fully allocated cost | Implemented | Assumptions listed; overhead never treated as marginal |
| Accounting exports | Simulated | CSV journal via `SimulatedAccounting`; balanced debit/credit; recorded as postings |
| General ledger | Deferred by design | Exports only |

## 15. Maintenance and machine data

| Capability | Status | Notes |
|---|---|---|
| Equipment, service schedules, defects, downtime, maintenance work, calibration, availability restrictions | Implemented | Feed scheduling and readiness checks |
| Machine telemetry | Simulated, read-only | Observations never override records; faults create unconfirmed suggestions |
| Machine control | Deferred by design | Not in this release |
| OEE with explicit definitions and exclusions | Implemented | `/api/equipment/{id}/oee` returns definitions with the figures |

## 16. Finished goods and dispatch

| Capability | Status | Notes |
|---|---|---|
| Accepted finished inventory, customer-order allocation, picking, packing, shipment, delivery references, returns | Implemented | |
| Produced / released / dispatched / delivered kept separate | Implemented | |
| Demonstration labels (Code 128 SVG, ZPL text), packing lists, traceability and recall reports | Implemented | Printing to label printers deferred |
| Returns enter review, never directly saleable | Implemented | |
| Carrier integration | Deferred | Carrier and tracking reference recorded manually |

## 17. Security and reliability

| Capability | Status | Notes |
|---|---|---|
| Role- and site-scoped permissions; restricted engineering and quality approvals | Implemented | See SECURITY.md |
| Audit history | Implemented | Append-only `audit_log` |
| Protected documents | Implemented | |
| Input validation | Implemented | Pydantic models reject unknown fields; domain validation in services |
| Idempotent imports and operations | Implemented | Item CSV import by file hash; `Idempotency-Key` header |
| Transactional inventory updates | Implemented | |
| Optimistic concurrency | Implemented | |
| Backups and tested restoration | Implemented | `scripts/backup.sh`, `scripts/restore.sh`, verified by `tests/test_zz_backup_restore.py` |
| Single sign-on, MFA, password policy, account lock-out | Deferred | Local accounts with scrypt hashes only |
| Email / SMS notifications | Deferred | In-app notifications only |
| Rate limiting | Deferred | |
| Regulated-sector readiness | Not claimed | See REGULATORY.md |

## 18. Demonstration

| Capability | Status | Notes |
|---|---|---|
| Pennine Manufacturing Demonstrator (bench-mounted inspection lamp) with all listed items, operations, several supplier lots, one rejected delivery, one machine outage, one rework order | Implemented | All 14 steps; results in `docs/DEMO_RESULTS.md` |
| All organisations and people are fictional | Yes | |
