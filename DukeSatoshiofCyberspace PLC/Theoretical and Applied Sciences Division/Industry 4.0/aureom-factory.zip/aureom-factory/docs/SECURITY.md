# Security model

## Authentication

* Local accounts; passwords hashed with scrypt (`n=2^14, r=8, p=1`, 16-byte salt).
* `POST /api/auth/login` issues an HMAC-SHA-256 signed bearer token (`AUREOM_SECRET_KEY`) with an
  expiry and a purpose; malformed, forged, expired or wrong-purpose tokens return 401.
* The application refuses to start in `AUREOM_ENV=production` with the default secret key.
* **Demo accounts all use the password `demo`.** They exist only in the demonstrator data set.
* Deferred: SSO/OIDC, MFA, password policy, lock-out, token revocation list, rate limiting.

## Authorisation

Permissions are named `<module>.<action>` and granted through roles (`backend/app/core/security.py`).
A role assignment has an optional `site_id`; `NULL` means every site. A request acts at the site given by
`X-Site-Id` (or the user's only scoped site). Site-scoped roles grant write permissions only at their site.

| Role | Reads | Additional permissions |
|---|---|---|
| `admin` | everything (`*`) | everything (`*`) |
| `viewer` | all `*.read` | — |
| `engineer` | all `*.read` | `registry.edit`, `engineering.edit`, `documents.upload` |
| `engineering_approver` | all `*.read` | `engineering.approve`, `registry.approve_conversion` |
| `planner` | all `*.read` | `planning.run`, `planning.accept`, `production.create`, `production.plan`, `purchasing.requisition`, `dispatch.order` |
| `production_manager` | all `*.read` | `planning.run`, `planning.accept`, `production.create`, `production.plan`, `production.release`, `production.cancel`, `production.close`, `production.authorise_scrap`, `production.rework`, `production.reconcile_offline`, `production.execute`, `inventory.reserve` |
| `buyer` | all `*.read` | `purchasing.requisition`, `purchasing.order`, `purchasing.invoice`, `purchasing.return` |
| `purchasing_manager` | all `*.read` | buyer permissions + `purchasing.approve`, `purchasing.approve_substitution` |
| `storekeeper` | all `*.read` | `purchasing.receive`, `inventory.move`, `inventory.reserve`, `inventory.adjust`, `dispatch.pick`, `purchasing.return`, `documents.upload` |
| `operator` | registry, engineering, inventory, production, quality, maintenance, documents | `production.execute`, `quality.record`, `quality.raise_ncr` |
| `quality_inspector` | all `*.read` | `quality.record`, `quality.raise_ncr`, `documents.upload` |
| `quality_manager` | all `*.read` | `quality.record`, `quality.raise_ncr`, `quality.release`, `quality.disposition`, `quality.capa`, `quality.correct`, `dispatch.recall`, `documents.upload` |
| `maintenance` | all `*.read` | `maintenance.edit`, `documents.upload` |
| `cost_accountant` | all `*.read` | `costing.edit`, `costing.export` |
| `dispatcher` | all `*.read` | `dispatch.order`, `dispatch.pick`, `dispatch.ship`, `dispatch.returns`, `inventory.reserve` |

### Restricted decisions

* Engineering: BOM/routing approval (`engineering.approve`), unit-conversion approval.
* Quality: accepting stock (`quality.release`), rejecting and dispositioning (`quality.disposition`),
  correcting recorded results (`quality.correct`). Inspectors and operators can record but not decide.
  Anyone with `inventory.move` or `quality.record` may place stock *on hold* (the safe direction).
* Purchasing: approval of requisitions, purchase orders and substitutions.
* Production: release, cancellation, closure, scrap authorisation, offline reconciliation.

### Segregation of duties enforced in code

* A BOM's author cannot approve it.
* A requisition's requester cannot approve it; a PO's author cannot approve it.
* A substitution's requester cannot approve it.
* Scrap must be authorised by someone other than the person who reported it.
* Operators can start an operation only if their recorded skills include the operation's required skill.

## Data integrity

* Append-only tables protected by triggers (see ARCHITECTURE.md); every mutating service call writes an
  audit record (who, when, site, before/after, reason).
* Optimistic concurrency (`version` columns, SQLAlchemy version counters) → 409 on stale edits.
* `Idempotency-Key` replay protection; imports deduplicated by content hash.
* Pydantic request models reject unknown fields; services validate domain rules (units, states, quality).

## Protected documents

* Stored by SHA-256 on a private volume (`AUREOM_STORAGE_PATH`), never inside a web root; Compose mounts
  the volume only into backend containers.
* Upload requires `documents.upload`; allowed MIME types are whitelisted; size capped by
  `AUREOM_MAX_UPLOAD_BYTES`; `restricted` classification only by engineering approvers or quality managers.
* Download requires `documents.read` (and engineering/quality roles for restricted documents) to obtain a
  signed, 5-minute link; downloads are served `private, no-store`, `nosniff`, `Content-Security-Policy: sandbox`,
  and the hash is re-verified.

## Transport and headers

Run behind a TLS-terminating reverse proxy in any non-local deployment. The API sets
`X-Content-Type-Options`, `Referrer-Policy` and `X-Frame-Options`; CORS is limited to
`AUREOM_CORS_ORIGINS`.

## Known limitations

* `GET /api/jobs`, `GET /api/jobs/{id}`, `GET /api/users` and `POST /api/notifications/{id}/read`
  require authentication but no specific permission.
* Offline shop-floor entries are trusted to the submitting operator's identity; device registration is
  not implemented.
