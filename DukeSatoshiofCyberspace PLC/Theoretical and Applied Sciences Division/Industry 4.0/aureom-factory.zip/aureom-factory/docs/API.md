# AUREOM FACTORY — API reference

The machine-readable specification is [`openapi.json`](openapi.json) (regenerate with
`python scripts/export_openapi.py`). When the API is running, interactive documentation is served at
`http://localhost:8000/docs` (Swagger UI) and `http://localhost:8000/redoc`.

All endpoints are under `/api`. Request and response bodies are JSON unless stated. Quantities and
money are decimal **strings** (e.g. `"140.476500"`); they are never floating point.

## Conventions

### Authentication
1. `POST /api/auth/login` with `{"username": "...", "password": "..."}` returns `{"token": "...", "user": {...}}`.
2. Send `Authorization: Bearer <token>` on every other request. Tokens are HMAC-signed with
   `AUREOM_SECRET_KEY` and expire after `AUREOM_TOKEN_TTL_MINUTES` (default 720).
3. `GET /api/auth/me` returns the user's roles (with site scope) and effective permissions.

### Site context
Permissions are site-scoped. Send `X-Site-Id: <site id>` to act at a specific site. If omitted, a user
whose roles are scoped to exactly one site acts at that site; otherwise the site in the token is used.
`GET /api/sites` lists sites.

### Idempotency
Operations that create stock movements or records that must not be duplicated accept an
`Idempotency-Key` header (transfers, adjustments, receipts, issues, consumption, output). Replaying the
same key with the same body returns the original response; the same key with a different body returns
`409 conflict`. Goods receipts and stock movements also store the key on the record itself.

### Optimistic concurrency
Editable records carry a `version` (items, purchase orders, production orders, customer orders, BOMs via
`row_version`). Edits and state changes on them require the `version` the client last read
(e.g. `PATCH /api/items/{id}` `{"version": 3, "changes": {...}}`, `POST /api/orders/{id}/release`
`{"version": 5}`). A stale version returns `409 conflict` with `details.current_version`.

### Errors
Every error uses one envelope:

```json
{"error": {"code": "quality_hold", "message": "Lot LOT-000001 is REJECTED and cannot be allocated", "details": {...}}}
```

| HTTP | Typical `code` values |
|---|---|
| 401 | `unauthenticated` |
| 403 | `permission_denied` |
| 404 | `not_found` |
| 409 | `conflict`, `invalid_state`, `insufficient_stock`, `reserved_stock`, `quality_hold`, `integrity_error` |
| 422 | `invalid_request` (schema), `validation_failed`, `unit_conversion_unavailable`, `bom_cycle` |

Request bodies reject unknown fields (`422 invalid_request`).

### Planned, physical, recorded and accepted
Responses keep these distinct, for example production orders expose `quantity_target`,
`quantity_start`, `quantity_reported`, `quantity_accepted`, `quantity_scrapped`; PO lines expose ordered,
received, accepted, rejected, returned and invoiced quantities; customer order lines expose ordered,
allocated, picked, packed, dispatched, delivered and returned.

## Real-time updates (WebSocket)

`GET ws://<api-host>:8000/ws?token=<bearer token>` — an invalid token is closed with code `4401`.
The server sends `{"topic": "hello", ...}` on connect, then committed operational events:

```json
{"topic": "inventory.movement", "site_id": 1, "data": {"movement_no": "MV-00000042", "type": "issue", ...}}
```

Topics: `inventory.movement`, `purchasing.receipt`, `quality.inspection_opened`, `quality.lot_status`,
`quality.decision`, `quality.ncr`, `production.order_released`, `production.operation_event`,
`engineering.bom_approved`, `planning.mrp_complete`, `maintenance.downtime`, `dispatch.shipped`,
`dispatch.recall`. Events are published with `pg_notify` inside the business transaction, so a client
never sees an event for a change that was rolled back. Send any text periodically as a keep-alive.

## Protected documents

* Upload: `POST /api/documents` (multipart: `file`, `kind`, `title`, optional `classification`
  `internal|restricted`, `entity_type`, `entity_id`, `revision`). Allowed types are restricted; files are
  stored by SHA-256 on a private volume.
* Download: `POST /api/documents/{id}/link` returns `{"url": "/api/files/<token>", "expires_in_seconds": 300}`.
  `GET /api/files/<token>` serves the file with `Cache-Control: private, no-store` and a sandboxing CSP.
  The token is signed, short-lived and bound to the document; the integrity hash is re-checked on read.

## Printable documents

`GET /api/reports/label/{lot_id}` (JSON with Code 128 SVG and ZPL; `?format=html` for a printable page),
`/api/reports/packing-list/{shipment_id}`, `/api/reports/traceability/{lot_id}`, `/api/reports/recall/{recall_id}` (HTML).
All are marked as demonstration documents.

## Endpoints

Permission column: the permission checked in code (directly in the route or the service it calls).
"any authenticated user" means only a valid token is required.

### core

| Method | Path | Handler | Permission (from code) |
|---|---|---|---|
| GET | `/api/audit` | `audit` | `reports.read` |
| POST | `/api/auth/login` | `login` | public |
| GET | `/api/auth/me` | `me` | any authenticated user |
| GET | `/api/health` | `health` | public |
| GET | `/api/jobs` | `jobs` | any authenticated user |
| POST | `/api/jobs` | `enqueue` | per job kind (e.g. `planning.run` for `mrp_run`, `registry.edit` for `import_items`) |
| GET | `/api/jobs/{job_id}` | `job` | any authenticated user |
| GET | `/api/notifications` | `notifications` | any authenticated user |
| POST | `/api/notifications/{nid}/read` | `read_notification` | any authenticated user |
| GET | `/api/sites` | `sites` | any authenticated user |
| GET | `/api/system/info` | `info` | any authenticated user |
| GET | `/api/users` | `users` | any authenticated user |

### materials

| Method | Path | Handler | Permission (from code) |
|---|---|---|---|
| POST | `/api/conversions/{conversion_id}/approve` | `post_approve_conversion` | `registry.approve_conversion` |
| POST | `/api/convert` | `post_convert` | `registry.read` |
| GET | `/api/items` | `list_items` | `registry.read` |
| POST | `/api/items` | `post_item` | `registry.edit` |
| GET | `/api/items/{item_id}` | `get_item` | `registry.read` |
| PATCH | `/api/items/{item_id}` | `patch_item` | `registry.edit` |
| POST | `/api/items/{item_id}/conversions` | `post_conversion` | `registry.edit` |
| GET | `/api/units` | `units` | any authenticated user |

### products

| Method | Path | Handler | Permission (from code) |
|---|---|---|---|
| GET | `/api/boms/{bom_id}` | `get_bom` | `engineering.read` |
| POST | `/api/boms/{bom_id}/approve` | `post_approve_bom` | `engineering.approve` |
| POST | `/api/boms/{bom_id}/lines` | `post_bom_line` | `engineering.edit` |
| POST | `/api/boms/{bom_id}/new-version` | `post_new_version` | `engineering.edit` |
| GET | `/api/engineering/cycle-check` | `cycle_check` | `engineering.read` |
| GET | `/api/items/{item_id}/boms` | `item_boms` | `engineering.read` |
| POST | `/api/items/{item_id}/boms` | `post_bom` | `engineering.edit` |
| GET | `/api/items/{item_id}/explosion` | `get_explosion` | `engineering.read` |
| GET | `/api/items/{item_id}/routings` | `item_routings` | `engineering.read` |
| POST | `/api/items/{item_id}/routings` | `post_routing` | `engineering.edit` |
| POST | `/api/routings/{routing_id}/approve` | `post_approve_routing` | `engineering.approve` |
| GET | `/api/work-centres` | `work_centres` | any authenticated user |

### purchasing

| Method | Path | Handler | Permission (from code) |
|---|---|---|---|
| GET | `/api/invoices` | `invoices` | `purchasing.read` |
| POST | `/api/invoices` | `post_invoice` | `purchasing.invoice` |
| GET | `/api/purchase-orders` | `purchase_orders` | `purchasing.read` |
| POST | `/api/purchase-orders` | `post_po` | `purchasing.order` |
| GET | `/api/purchase-orders/{po_id}` | `get_po` | `purchasing.read` |
| POST | `/api/purchase-orders/{po_id}/acknowledge` | `post_ack_po` | `purchasing.order` |
| POST | `/api/purchase-orders/{po_id}/approve` | `post_approve_po` | `purchasing.approve` |
| POST | `/api/purchase-orders/{po_id}/receipts` | `post_receipt` | `purchasing.receive` |
| POST | `/api/purchase-orders/{po_id}/send` | `post_send_po` | `purchasing.order` |
| GET | `/api/receipts` | `receipts` | `purchasing.read` |
| GET | `/api/requisitions` | `requisitions` | `purchasing.read` |
| POST | `/api/requisitions` | `post_requisition` | `purchasing.requisition` |
| POST | `/api/requisitions/{rid}/decide` | `post_decide_requisition` | `purchasing.approve` |
| POST | `/api/substitutions` | `post_sub` | `purchasing.order` |
| POST | `/api/substitutions/{sid}/decide` | `post_decide_sub` | `purchasing.approve_substitution` |
| GET | `/api/supplier-returns` | `supplier_returns` | `purchasing.read` |
| POST | `/api/supplier-returns` | `post_supplier_return` | `purchasing.return` |
| GET | `/api/suppliers` | `suppliers` | `purchasing.read` |

### inventory

| Method | Path | Handler | Permission (from code) |
|---|---|---|---|
| GET | `/api/bins` | `get_bins` | `inventory.read` |
| GET | `/api/lots` | `get_lots` | `inventory.read` |
| POST | `/api/lots/merge` | `post_merge` | `inventory.move` |
| GET | `/api/lots/{lot_id}` | `get_lot` | `inventory.read` |
| POST | `/api/lots/{lot_id}/split` | `post_split` | `inventory.move` |
| GET | `/api/movements` | `get_movements` | `inventory.read` |
| POST | `/api/movements/adjust` | `post_adjust` | `inventory.adjust` |
| POST | `/api/movements/transfer` | `post_transfer` | `inventory.move` |
| POST | `/api/movements/{movement_id}/reverse` | `post_reverse` | `inventory.adjust` |
| GET | `/api/reservations` | `get_reservations` | `inventory.read` |
| POST | `/api/scan` | `post_scan` | `inventory.read` |
| GET | `/api/stock` | `get_stock` | `inventory.read` |

### planning

| Method | Path | Handler | Permission (from code) |
|---|---|---|---|
| GET | `/api/demands` | `demands` | `planning.read` |
| POST | `/api/demands` | `post_demand` | `planning.run` |
| POST | `/api/mrp/proposals/{pid}/accept` | `post_accept` | `planning.accept` |
| POST | `/api/mrp/proposals/{pid}/reject` | `post_reject` | `planning.accept` |
| POST | `/api/mrp/runs` | `post_mrp` | `planning.run` |
| GET | `/api/mrp/runs/latest` | `latest_mrp` | `planning.read` |
| GET | `/api/mrp/runs/{rid}` | `get_mrp` | `planning.read` |
| GET | `/api/schedule/latest` | `latest_schedule` | `planning.read` |
| POST | `/api/schedule/runs` | `post_schedule` | `production.plan` |

### production

| Method | Path | Handler | Permission (from code) |
|---|---|---|---|
| POST | `/api/materials/{mid}/consume` | `post_consume` | `production.execute` |
| POST | `/api/materials/{mid}/issue` | `post_issue` | `production.execute` or `inventory.move` (+ `inventory.reserve` if not already reserved) |
| POST | `/api/materials/{mid}/reconcile-backflush` | `post_reconcile` | `production.execute` |
| POST | `/api/materials/{mid}/return` | `post_return` | `production.execute` or `inventory.move` |
| POST | `/api/ncrs/{nid}/rework-order` | `post_rework` | `production.rework` |
| POST | `/api/operations/{op_id}/check-equipment` | `post_check` | `production.execute` |
| POST | `/api/operations/{op_id}/complete` | `post_complete` | `production.execute` |
| POST | `/api/operations/{op_id}/defect` | `post_defect` | `quality.raise_ncr` |
| POST | `/api/operations/{op_id}/handover` | `post_handover` | `production.execute` |
| POST | `/api/operations/{op_id}/pause` | `post_pause_op` | `production.execute` |
| POST | `/api/operations/{op_id}/quantities` | `post_qty` | `production.execute` |
| POST | `/api/operations/{op_id}/resume` | `post_resume` | `production.execute` |
| POST | `/api/operations/{op_id}/start` | `post_start` | `production.execute` |
| GET | `/api/orders` | `orders` | `production.read` |
| POST | `/api/orders` | `post_order` | `production.create` |
| GET | `/api/orders/{oid}` | `get_order` | `production.read` |
| POST | `/api/orders/{oid}/allocate` | `post_allocate` | `inventory.reserve` |
| POST | `/api/orders/{oid}/backflush` | `post_backflush` | `production.execute` |
| POST | `/api/orders/{oid}/cancel` | `post_cancel` | `production.cancel` |
| POST | `/api/orders/{oid}/close` | `post_close` | `production.close` |
| POST | `/api/orders/{oid}/output` | `post_output` | `production.execute` |
| POST | `/api/orders/{oid}/pause` | `post_pause` | `production.release` |
| POST | `/api/orders/{oid}/plan` | `post_plan` | `production.plan` |
| POST | `/api/orders/{oid}/refresh-definitions` | `post_refresh` | `production.plan` |
| POST | `/api/orders/{oid}/release` | `post_release` | `production.release` |
| POST | `/api/orders/{oid}/rework-issue` | `post_rework_issue` | `production.execute` |
| POST | `/api/orders/{oid}/rework-output` | `post_rework_output` | `production.execute` |
| POST | `/api/orders/{oid}/subcontract-shipments` | `post_sub_send` | `production.execute` or `inventory.move` |
| GET | `/api/scrap` | `scrap` | `production.read` |
| POST | `/api/scrap` | `post_scrap` | `production.execute` |
| POST | `/api/scrap/{sid}/authorise` | `post_authorise` | `production.authorise_scrap` |
| GET | `/api/shopfloor/offline` | `get_offline` | `production.read` |
| POST | `/api/shopfloor/offline` | `post_offline` | `production.execute` |
| POST | `/api/shopfloor/offline/{eid}/reconcile` | `post_reconcile_offline` | `production.reconcile_offline` |
| GET | `/api/shopfloor/work` | `work` | `production.read` |
| GET | `/api/subcontract-shipments` | `sub_shipments` | `production.read` |
| POST | `/api/subcontract-shipments/{sid}/receive` | `post_sub_receive` | `purchasing.receive` |

### quality

| Method | Path | Handler | Permission (from code) |
|---|---|---|---|
| GET | `/api/corrective-actions` | `capas` | `quality.read` |
| GET | `/api/inspection-plans` | `plans` | `quality.read` |
| POST | `/api/inspection-results/{rid}/correct` | `post_correct` | `quality.correct` |
| GET | `/api/inspections` | `inspections` | `quality.read` |
| POST | `/api/inspections` | `post_inspection` | `quality.record` |
| GET | `/api/inspections/{iid}` | `get_inspection` | `quality.read` |
| POST | `/api/inspections/{iid}/decide` | `post_decide` | `quality.raise_ncr` |
| POST | `/api/inspections/{iid}/results` | `post_result` | `quality.record` |
| GET | `/api/ncrs` | `ncrs` | `quality.read` |
| POST | `/api/ncrs` | `post_ncr` | `quality.raise_ncr` |
| POST | `/api/ncrs/{nid}/close` | `post_close` | `quality.disposition` |
| POST | `/api/ncrs/{nid}/corrective-actions` | `post_capa` | `quality.capa` |
| POST | `/api/ncrs/{nid}/disposition` | `post_disposition` | `quality.disposition`, `quality.release` |
| GET | `/api/quality/release-queue` | `release_queue` | `quality.read` |

### maintenance

| Method | Path | Handler | Permission (from code) |
|---|---|---|---|
| POST | `/api/downtime/{did}/confirm` | `post_confirm` | `maintenance.edit` |
| POST | `/api/downtime/{did}/end` | `post_end` | `maintenance.edit` |
| GET | `/api/equipment` | `equipment` | `maintenance.read` |
| GET | `/api/equipment/{eid}` | `get_equipment` | `maintenance.read` |
| POST | `/api/equipment/{eid}/calibrations` | `post_cal` | `maintenance.edit` |
| POST | `/api/equipment/{eid}/downtime` | `post_downtime` | `maintenance.edit` |
| GET | `/api/equipment/{eid}/oee` | `get_oee` | `maintenance.read` |
| POST | `/api/equipment/{eid}/poll` | `post_poll` | `maintenance.read` |
| POST | `/api/equipment/{eid}/work-orders` | `post_wo` | `maintenance.edit` |
| POST | `/api/maintenance-work-orders/{wid}/complete` | `post_complete_wo` | `maintenance.edit` |

### costing

| Method | Path | Handler | Permission (from code) |
|---|---|---|---|
| GET | `/api/costing/incremental/{item_id}` | `incr` | `costing.read` |
| GET | `/api/costing/orders` | `all_orders` | `costing.read` |
| GET | `/api/costing/orders/{oid}` | `order_cost` | `costing.read` |
| POST | `/api/costing/orders/{oid}/export` | `export` | `costing.export` |
| GET | `/api/costing/postings` | `postings` | `costing.read` |
| GET | `/api/costing/standard/{item_id}` | `std` | `costing.read` |
| GET | `/api/fx-rates` | `fx` | `costing.read` |
| GET | `/api/overhead-rules` | `overheads` | `costing.read` |

### dispatch

| Method | Path | Handler | Permission (from code) |
|---|---|---|---|
| POST | `/api/customer-order-lines/{lid}/allocate` | `post_alloc` | `dispatch.pick` |
| GET | `/api/customer-orders` | `cos` | `dispatch.read` |
| POST | `/api/customer-orders` | `post_co` | `dispatch.order` |
| GET | `/api/customer-orders/{cid}` | `get_co` | `dispatch.read` |
| GET | `/api/customer-returns` | `returns` | `dispatch.read` |
| POST | `/api/customer-returns` | `post_return` | `dispatch.returns` |
| GET | `/api/customers` | `customers` | `dispatch.read` |
| GET | `/api/recalls` | `recalls` | `dispatch.read` |
| POST | `/api/recalls` | `post_recall` | `dispatch.recall` |
| GET | `/api/recalls/{rid}` | `get_recall` | `dispatch.read` |
| GET | `/api/reports/label/{lot_id}` | `label` | `reports.read` |
| GET | `/api/reports/packing-list/{sid}` | `packing` | `reports.read` |
| GET | `/api/reports/recall/{rid}` | `recall_html` | `reports.read` |
| GET | `/api/reports/traceability/{lot_id}` | `trace_report` | `reports.read` |
| GET | `/api/shipments` | `shipments` | `dispatch.read` |
| POST | `/api/shipments` | `post_shipment` | `dispatch.pick` |
| GET | `/api/shipments/{sid}` | `get_shipment` | `dispatch.read` |
| POST | `/api/shipments/{sid}/deliver` | `post_deliver` | `dispatch.ship` |
| POST | `/api/shipments/{sid}/dispatch` | `post_dispatch` | `dispatch.ship` |
| POST | `/api/shipments/{sid}/pack` | `post_pack` | `dispatch.pick` |
| POST | `/api/shipments/{sid}/pick` | `post_pick` | `dispatch.pick` |

### traceability

| Method | Path | Handler | Permission (from code) |
|---|---|---|---|
| GET | `/api/reports/material-flow` | `material_flow` | `reports.read` |
| GET | `/api/reports/overview` | `overview` | `reports.read` |
| GET | `/api/trace/supplier-lot/{supplier_lot}` | `by_supplier_lot` | `reports.read` |
| GET | `/api/trace/{lot_id}/backward` | `trace_back` | `reports.read` |
| GET | `/api/trace/{lot_id}/forward` | `trace_fwd` | `reports.read` |

### documents

| Method | Path | Handler | Permission (from code) |
|---|---|---|---|
| GET | `/api/documents` | `list_documents` | `documents.read` |
| POST | `/api/documents` | `post_document` | `documents.upload` |
| POST | `/api/documents/{doc_id}/link` | `link` | `documents.read` (restricted documents: engineering/quality roles) |
| GET | `/api/files/{token}` | `file` | signed link token |
