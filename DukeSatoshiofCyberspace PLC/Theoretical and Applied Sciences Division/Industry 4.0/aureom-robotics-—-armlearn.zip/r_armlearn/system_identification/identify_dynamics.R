# AUREOM ROBOTICS — ArmLearn System Identification (Bounded Joint Friction & Compliance)

suppressPackageStartupMessages(library(MASS))

identify_joint_dynamics <- function(train_df) {
  cos_q2 <- cos(train_df$q_meas_1)
  sin_q2_q3 <- sin(train_df$q_meas_1 + train_df$q_meas_2)
  payload_x_cos_q2 <- train_df$payload_est_kg * cos_q2

  results <- list()
  for (j in 0:5) {
    y <- train_df[[paste0("q_ref_", j)]] - train_df[[paste0("q_meas_", j)]]
    dq <- train_df[[paste0("dq_ref_", j)]]
    tanh_dq <- tanh(dq / 0.05)

    reg_df <- data.frame(
      y = y,
      tanh_dq = tanh_dq,
      dq = dq,
      cos_q2 = cos_q2,
      sin_q2_q3 = sin_q2_q3,
      payload_x_cos_q2 = payload_x_cos_q2
    )

    ols_fit <- lm(y ~ tanh_dq + dq + cos_q2 + sin_q2_q3 + payload_x_cos_q2, data = reg_df)
    ols_sum <- summary(ols_fit)
    coefs <- coef(ols_fit)
    ses <- sqrt(diag(vcov(ols_fit)))

    # Guard against singular design matrix on nearly-stationary joints (e.g., J4/J6)
    rlm_fit <- tryCatch(
      MASS::rlm(y ~ tanh_dq + dq + cos_q2 + sin_q2_q3 + payload_x_cos_q2, data = reg_df, maxit = 40),
      error = function(e) NULL
    )
    rlm_coefs <- if (!is.null(rlm_fit)) coef(rlm_fit) else coefs

    get_num <- function(vec, name) {
      val <- unname(vec[name])
      if (is.na(val) || !is.finite(val)) 0.0 else as.numeric(val)
    }

    r2 <- suppressWarnings(as.numeric(ols_sum$r.squared))
    if (is.na(r2) || !is.finite(r2)) r2 <- 0.0
    sigma <- suppressWarnings(as.numeric(ols_sum$sigma))
    if (is.na(sigma) || !is.finite(sigma)) sigma <- sd(y)

    results[[paste0("joint_", j)]] <- list(
      joint_index = as.integer(j),
      ols_coulomb_lag_rad = get_num(coefs, "tanh_dq"),
      ols_coulomb_se = get_num(ses, "tanh_dq"),
      ols_viscous_lag_s = get_num(coefs, "dq"),
      ols_viscous_se = get_num(ses, "dq"),
      ols_gravity_sag_rad = get_num(coefs, "cos_q2"),
      ols_payload_sag_rad_per_kg = get_num(coefs, "payload_x_cos_q2"),
      robust_coulomb_lag_rad = get_num(rlm_coefs, "tanh_dq"),
      robust_viscous_lag_s = get_num(rlm_coefs, "dq"),
      r_squared = r2,
      residual_sd_rad = sigma
    )
  }
  results
}
