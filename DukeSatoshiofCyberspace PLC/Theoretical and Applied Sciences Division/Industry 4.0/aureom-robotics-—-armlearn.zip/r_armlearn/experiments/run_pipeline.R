# AUREOM ROBOTICS — ArmLearn End-to-End R System Identification & ML Pipeline

suppressPackageStartupMessages(library(jsonlite))

resolve_r_root <- function() {
  if (file.exists("r_armlearn/data_validation/validate_dataset.R")) {
    return("r_armlearn")
  }
  if (file.exists("data_validation/validate_dataset.R")) {
    return(".")
  }
  stop("Cannot locate r_armlearn modules from working directory")
}

r_root <- resolve_r_root()
source(file.path(r_root, "data_validation/validate_dataset.R"))
source(file.path(r_root, "system_identification/identify_dynamics.R"))
source(file.path(r_root, "model_training/train_residual_model.R"))
source(file.path(r_root, "uncertainty/uncertainty_analysis.R"))
source(file.path(r_root, "evaluation/evaluate_runs.R"))

artifacts_dir <- if (r_root == "r_armlearn") "artifacts" else "../artifacts"
csv_path <- file.path(artifacts_dir, "baseline_training_telemetry.csv")
model_out <- file.path(artifacts_dir, "residual_model.v1.json")
ref_csv_out <- file.path(artifacts_dir, "r_reference_predictions.csv")
report_out <- file.path(artifacts_dir, "r_pipeline_report.json")

raw_df <- read.csv(csv_path, stringsAsFactors = FALSE)
validated <- validate_and_clean_telemetry(raw_df)
split_obj <- split_by_run_id(validated$data, train_frac = 0.6, val_frac = 0.2, seed = 42L)

sys_id <- identify_joint_dynamics(split_obj$train)
trained <- train_residual_models(split_obj, out_model_path = model_out, out_ref_csv = ref_csv_out)
uncertainty <- analyze_uncertainty(split_obj, trained, n_boot = 25L, seed = 77L)
heldout_eval <- evaluate_heldout_runs(
  split_obj$test,
  trained$pred_test,
  trained$artefact$max_correction_rad
)

report <- list(
  schema_version = "armlearn.r_report.v1",
  r_version = paste(R.version$major, R.version$minor, sep = "."),
  validation = validated$report,
  split = list(
    train_runs = split_obj$train_runs,
    val_runs = split_obj$val_runs,
    test_runs = split_obj$test_runs
  ),
  system_identification = sys_id,
  model_comparison = list(
    ols_val_rmse_rad = trained$ols_val_rmse_rad,
    elastic_val_rmse_rad = trained$elastic_val_rmse_rad
  ),
  uncertainty_decomposition = uncertainty,
  heldout_evaluation = heldout_eval
)

writeLines(
  jsonlite::toJSON(report, auto_unbox = TRUE, digits = 10, pretty = TRUE),
  con = report_out
)
cat(sprintf("R ArmLearn pipeline complete -> %s (SHA-256: %s)\n", model_out, trained$artefact$integrity_sha256))
