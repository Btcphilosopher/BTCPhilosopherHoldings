library(testthat)

root_prefix <- if (file.exists("r_armlearn/data_validation/validate_dataset.R")) {
  "r_armlearn"
} else {
  ".."
}

source(file.path(root_prefix, "data_validation/validate_dataset.R"))
source(file.path(root_prefix, "system_identification/identify_dynamics.R"))
source(file.path(root_prefix, "model_training/train_residual_model.R"))
source(file.path(root_prefix, "uncertainty/uncertainty_analysis.R"))
source(file.path(root_prefix, "evaluation/evaluate_runs.R"))

make_synthetic_df <- function(n_runs = 5L, n_steps = 40L) {
  set.seed(123)
  rows <- list()
  k <- 1L
  for (r in seq_len(n_runs)) {
    rid <- sprintf("syn_run_%02d", r)
    payload <- 0.2 * r
    for (s in seq_len(n_steps)) {
      t_s <- (s - 1L) * 0.01
      row <- list(
        schema_version = "armlearn.telemetry.v1",
        run_id = rid,
        scenario_id = "syn_sc",
        controller_mode = "baseline_pid_ff",
        step = s - 1L,
        time_s = t_s,
        timestamp_ns = 1000000000 + (s - 1L) * 10000000,
        payload_est_kg = payload,
        payload_true_kg = payload,
        motor_temp_c = 38.0 + 0.05 * s
      )
      for (j in 0:5) {
        qref <- 0.3 * sin(t_s * (j + 1) + 0.1 * r)
        dqref <- 0.3 * (j + 1) * cos(t_s * (j + 1) + 0.1 * r)
        lag <- 0.004 * tanh(dqref / 0.05) + 0.002 * dqref + 0.003 * payload * cos(0.3) + rnorm(1, 0, 0.0002)
        row[[paste0("q_ref_", j)]] <- qref
        row[[paste0("dq_ref_", j)]] <- dqref
        row[[paste0("q_meas_", j)]] <- qref - lag
        row[[paste0("dq_meas_", j)]] <- dqref
        row[[paste0("q_true_", j)]] <- qref - lag
        row[[paste0("q_cmd_", j)]] <- qref
      }
      rows[[k]] <- as.data.frame(row, stringsAsFactors = FALSE)
      k <- k + 1L
    }
  }
  do.call(rbind, rows)
}

test_that("run-grouped split keeps runs strictly disjoint", {
  df <- make_synthetic_df(6L, 30L)
  val <- validate_and_clean_telemetry(df)
  sp <- split_by_run_id(val$data)
  expect_equal(length(intersect(sp$train_runs, sp$val_runs)), 0L)
  expect_equal(length(intersect(sp$train_runs, sp$test_runs)), 0L)
  expect_equal(length(intersect(sp$val_runs, sp$test_runs)), 0L)
})

test_that("unit validation rejects degrees or corrupted schema", {
  df <- make_synthetic_df(4L, 20L)
  df$q_meas_0[1] <- 45.0
  expect_error(validate_and_clean_telemetry(df), "3.5 rad")

  df2 <- make_synthetic_df(4L, 20L)
  df2$schema_version[1] <- "wrong.v0"
  expect_error(validate_and_clean_telemetry(df2), "schema mismatch")
})

test_that("system identification, training, SHA-256 export, and uncertainty run end-to-end", {
  df <- make_synthetic_df(6L, 35L)
  df$q_meas_2[5] <- NA_real_
  val <- validate_and_clean_telemetry(df)
  expect_gte(val$report$non_finite_repaired, 1L)

  sp <- split_by_run_id(val$data)
  sys <- identify_joint_dynamics(sp$train)
  expect_equal(length(sys), 6L)

  tmp_json <- tempfile(fileext = ".json")
  tmp_csv <- tempfile(fileext = ".csv")
  trained <- train_residual_models(sp, out_model_path = tmp_json, out_ref_csv = tmp_csv)
  expect_true(file.exists(tmp_json))
  expect_true(file.exists(tmp_csv))
  expect_equal(nchar(trained$artefact$integrity_sha256), 64L)
  expect_equal(length(trained$artefact$feature_names), 30L)

  unc <- analyze_uncertainty(sp, trained, n_boot = 5L)
  expect_equal(length(unc), 6L)
  expect_true(all(vapply(unc, function(x) is.finite(x$total_test_rmse_rad), logical(1L))))

  ev <- evaluate_heldout_runs(sp$test, trained$pred_test, trained$artefact$max_correction_rad)
  expect_lt(ev$residual_corrected_rms_rad_mean, ev$baseline_rms_rad_mean)
})
