# AUREOM ROBOTICS — ArmLearn Held-Out Evaluation

evaluate_heldout_runs <- function(test_df, pred_test, max_correction_rad) {
  base_sq_sum <- 0.0
  corr_sq_sum <- 0.0
  n_total <- nrow(test_df) * 6L

  for (j in 0:5) {
    y_true_err <- as.numeric(test_df[[paste0("target_res_", j)]])
    bound <- max_correction_rad[j + 1L]
    corr <- pmin(pmax(as.numeric(pred_test[, j + 1L]), -bound), bound)
    rem_err <- y_true_err - corr

    base_sq_sum <- base_sq_sum + sum(y_true_err^2)
    corr_sq_sum <- corr_sq_sum + sum(rem_err^2)
  }

  base_rms <- sqrt(base_sq_sum / n_total)
  corr_rms <- sqrt(corr_sq_sum / n_total)
  explained_pct <- if (base_rms > 1e-12) ((base_rms - corr_rms) / base_rms) * 100.0 else 0.0

  list(
    baseline_rms_rad_mean = base_rms,
    residual_corrected_rms_rad_mean = corr_rms,
    relative_error_explained_pct = explained_pct
  )
}
