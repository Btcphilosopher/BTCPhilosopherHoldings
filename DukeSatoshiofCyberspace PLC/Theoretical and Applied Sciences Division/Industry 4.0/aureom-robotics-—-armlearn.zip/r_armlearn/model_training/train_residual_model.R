# AUREOM ROBOTICS — ArmLearn Supervised Residual Model Training & Canonical Export

suppressPackageStartupMessages({
  library(glmnet)
  library(digest)
  library(jsonlite)
})

canonical_feature_names <- function() {
  c(
    paste0("q_", 0:5),
    paste0("dq_", 0:5),
    paste0("tanh_dq_", 0:5),
    "payload_est_kg",
    "cos_q2",
    "sin_q2_q3",
    "payload_x_cos_q2",
    "payload_x_sin_q2_q3",
    "motor_temp_delta_c",
    paste0("prev_err_", 0:5)
  )
}

build_feature_matrix <- function(df) {
  n <- nrow(df)
  X <- matrix(0.0, nrow = n, ncol = 30L)
  colnames(X) <- canonical_feature_names()

  for (j in 0:5) {
    X[, j + 1L] <- as.numeric(df[[paste0("q_meas_", j)]])
    dq_j <- as.numeric(df[[paste0("dq_meas_", j)]])
    X[, 6L + j + 1L] <- dq_j
    X[, 12L + j + 1L] <- tanh(dq_j / 0.05)
    X[, 24L + j + 1L] <- as.numeric(df[[paste0("prev_err_", j)]])
  }

  q2 <- as.numeric(df$q_meas_1)
  q3 <- as.numeric(df$q_meas_2)
  payload <- as.numeric(df$payload_est_kg)
  cos_q2 <- cos(q2)
  sin_q2_q3 <- sin(q2 + q3)

  X[, 19L] <- payload
  X[, 20L] <- cos_q2
  X[, 21L] <- sin_q2_q3
  X[, 22L] <- payload * cos_q2
  X[, 23L] <- payload * sin_q2_q3
  X[, 24L] <- as.numeric(df$motor_temp_c) - 35.0
  X
}

canonical_hash_payload <- function(art) {
  fmt10 <- function(vals) {
    paste0(sprintf("%.10f,", vals), collapse = "")
  }
  weight_str <- paste0(vapply(seq_len(nrow(art$weights)), function(i) {
    paste0(fmt10(art$weights[i, ]), ";")
  }, character(1L)), collapse = "")

  paste0(
    art$schema_version, "|",
    art$model_id, "|",
    art$model_version, "|",
    art$output_units, "|",
    paste(art$feature_names, collapse = ","), "|",
    fmt10(art$normalization$mean), "|",
    fmt10(art$normalization$std), "|",
    fmt10(art$intercepts), "|",
    weight_str, "|",
    fmt10(art$max_correction_rad)
  )
}

predict_linear_matrix <- function(X, mean_vec, std_vec, intercepts, weights) {
  Z <- sweep(sweep(X, 2L, mean_vec, "-"), 2L, std_vec, "/")
  preds <- Z %*% t(weights)
  sweep(preds, 2L, intercepts, "+")
}

train_residual_models <- function(split_obj, out_model_path = NULL, out_ref_csv = NULL) {
  train_df <- split_obj$train
  val_df <- split_obj$val
  test_df <- split_obj$test

  X_train <- build_feature_matrix(train_df)
  X_val <- build_feature_matrix(val_df)
  X_test <- build_feature_matrix(test_df)

  # Compute normalization strictly on training split
  feat_mean <- colMeans(X_train)
  feat_std <- apply(X_train, 2L, sd)
  feat_std[!is.finite(feat_std) | feat_std < 1e-6] <- 1.0

  Z_train <- sweep(sweep(X_train, 2L, feat_mean, "-"), 2L, feat_std, "/")
  Z_val <- sweep(sweep(X_val, 2L, feat_mean, "-"), 2L, feat_std, "/")

  # Run-grouped cross-validation folds
  train_run_factor <- as.integer(factor(train_df$run_id))
  n_folds <- min(max(train_run_factor), 5L)
  foldid <- ((train_run_factor - 1L) %% n_folds) + 1L

  intercepts <- numeric(6L)
  weights <- matrix(0.0, nrow = 6L, ncol = 30L)
  ols_val_rmse <- numeric(6L)
  elastic_val_rmse <- numeric(6L)

  ols_intercepts <- numeric(6L)
  ols_weights <- matrix(0.0, nrow = 6L, ncol = 30L)

  for (j in 0:5) {
    y_tr <- as.numeric(train_df[[paste0("target_res_", j)]])
    y_va <- as.numeric(val_df[[paste0("target_res_", j)]])

    # Baseline OLS on standardized training features
    tr_frame <- as.data.frame(Z_train)
    tr_frame$y <- y_tr
    ols_fit <- lm(y ~ ., data = tr_frame)
    b_ols <- coef(ols_fit)
    b_ols[!is.finite(b_ols)] <- 0.0
    ols_intercepts[j + 1L] <- unname(b_ols[1L])
    ols_weights[j + 1L, ] <- unname(b_ols[-1L])
    pred_ols_val <- ols_intercepts[j + 1L] + as.numeric(Z_val %*% ols_weights[j + 1L, ])
    ols_val_rmse[j + 1L] <- sqrt(mean((y_va - pred_ols_val)^2))

    # Candidate Elastic-Net (glmnet, alpha = 0.05) with run-grouped CV
    if (sd(y_tr) < 1e-10) {
      intercepts[j + 1L] <- mean(y_tr)
      weights[j + 1L, ] <- 0.0
      elastic_val_rmse[j + 1L] <- sqrt(mean((y_va - mean(y_tr))^2))
    } else {
      cv_fit <- cv.glmnet(
        x = Z_train,
        y = y_tr,
        alpha = 0.05,
        foldid = foldid,
        standardize = FALSE,
        thresh = 1e-9
      )
      cf <- as.numeric(coef(cv_fit, s = "lambda.min"))
      intercepts[j + 1L] <- cf[1L]
      weights[j + 1L, ] <- cf[-1L]
      pred_en_val <- intercepts[j + 1L] + as.numeric(Z_val %*% weights[j + 1L, ])
      elastic_val_rmse[j + 1L] <- sqrt(mean((y_va - pred_en_val)^2))
    }
  }

  max_corr_rad <- c(0.030, 0.040, 0.038, 0.022, 0.024, 0.018)

  q_train_mat <- as.matrix(train_df[, paste0("q_meas_", 0:5), drop = FALSE])
  dq_train_mat <- as.matrix(train_df[, paste0("dq_meas_", 0:5), drop = FALSE])
  err_train_mat <- as.matrix(train_df[, paste0("prev_err_", 0:5), drop = FALSE])

  q_min_dom <- apply(q_train_mat, 2L, min) - 0.55
  q_max_dom <- apply(q_train_mat, 2L, max) + 0.55
  dq_abs_dom <- apply(abs(dq_train_mat), 2L, max) * 1.45 + 0.6

  artefact <- list(
    schema_version = "armlearn.model.v1",
    model_id = "aureom_6r_elasticnet_residual",
    model_version = "1.0.0",
    created_at_utc = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
    r_version = paste(R.version$major, R.version$minor, sep = "."),
    target_kind = "JointPositionResidualRad",
    output_units = "rad",
    feature_names = canonical_feature_names(),
    normalization = list(
      mean = as.numeric(feat_mean),
      std = as.numeric(feat_std)
    ),
    intercepts = as.numeric(intercepts),
    weights = weights,
    max_correction_rad = max_corr_rad,
    operating_domain = list(
      q_min_rad = as.numeric(q_min_dom),
      q_max_rad = as.numeric(q_max_dom),
      dq_abs_max_rad_s = as.numeric(dq_abs_dom),
      payload_min_kg = 0.0,
      payload_max_kg = 1.65,
      max_recent_err_rad = max(0.12, max(abs(err_train_mat)) * 2.5),
      temp_min_c = 15.0,
      temp_max_c = 85.0
    ),
    training_run_ids = as.character(split_obj$train_runs),
    validation_rmse_rad = as.numeric(elastic_val_rmse),
    integrity_sha256 = ""
  )

  payload_str <- canonical_hash_payload(artefact)
  artefact$integrity_sha256 <- digest::digest(payload_str, algo = "sha256", serialize = FALSE)

  if (!is.null(out_model_path)) {
    dir.create(dirname(out_model_path), recursive = TRUE, showWarnings = FALSE)
    json_str <- jsonlite::toJSON(artefact, auto_unbox = TRUE, digits = 15, pretty = TRUE)
    writeLines(json_str, con = out_model_path)
  }

  pred_test <- predict_linear_matrix(X_test, feat_mean, feat_std, intercepts, weights)

  if (!is.null(out_ref_csv)) {
    ref_df <- data.frame(
      q_0 = test_df$q_meas_0, q_1 = test_df$q_meas_1, q_2 = test_df$q_meas_2,
      q_3 = test_df$q_meas_3, q_4 = test_df$q_meas_4, q_5 = test_df$q_meas_5,
      dq_0 = test_df$dq_meas_0, dq_1 = test_df$dq_meas_1, dq_2 = test_df$dq_meas_2,
      dq_3 = test_df$dq_meas_3, dq_4 = test_df$dq_meas_4, dq_5 = test_df$dq_meas_5,
      payload_est_kg = test_df$payload_est_kg,
      motor_temp_c = test_df$motor_temp_c,
      prev_err_0 = test_df$prev_err_0, prev_err_1 = test_df$prev_err_1, prev_err_2 = test_df$prev_err_2,
      prev_err_3 = test_df$prev_err_3, prev_err_4 = test_df$prev_err_4, prev_err_5 = test_df$prev_err_5,
      pred_r_0 = pred_test[, 1L], pred_r_1 = pred_test[, 2L], pred_r_2 = pred_test[, 3L],
      pred_r_3 = pred_test[, 4L], pred_r_4 = pred_test[, 5L], pred_r_5 = pred_test[, 6L]
    )
    # Write high-precision CSV so Rust parity (< 1e-9 rad) is exact
    write.csv(format(ref_df, digits = 16, scientific = FALSE, trim = TRUE), out_ref_csv, row.names = FALSE, quote = FALSE)
  }

  list(
    artefact = artefact,
    X_train = X_train,
    X_val = X_val,
    X_test = X_test,
    pred_test = pred_test,
    ols_val_rmse_rad = ols_val_rmse,
    elastic_val_rmse_rad = elastic_val_rmse
  )
}
