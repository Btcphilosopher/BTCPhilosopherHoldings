# AUREOM ROBOTICS — ArmLearn Data Validation & Run-Grouped Splitting

CANONICAL_TELEMETRY_SCHEMA <- "armlearn.telemetry.v1"

required_telemetry_columns <- function() {
  c(
    "schema_version", "run_id", "scenario_id", "controller_mode",
    "step", "time_s", "timestamp_ns",
    paste0("q_ref_", 0:5),
    paste0("dq_ref_", 0:5),
    paste0("q_meas_", 0:5),
    paste0("dq_meas_", 0:5),
    paste0("q_true_", 0:5),
    paste0("q_cmd_", 0:5),
    "payload_est_kg", "payload_true_kg", "motor_temp_c"
  )
}

validate_and_clean_telemetry <- function(df) {
  if (!is.data.frame(df) || nrow(df) == 0L) {
    stop("Telemetry dataset is empty or not a data.frame")
  }

  req_cols <- required_telemetry_columns()
  missing_cols <- setdiff(req_cols, names(df))
  if (length(missing_cols) > 0L) {
    stop(sprintf("Missing required telemetry columns: %s", paste(missing_cols, collapse = ", ")))
  }

  schemas <- unique(as.character(df$schema_version))
  if (!all(schemas == CANONICAL_TELEMETRY_SCHEMA)) {
    stop(sprintf(
      "Telemetry schema mismatch: expected '%s', found '%s'",
      CANONICAL_TELEMETRY_SCHEMA, paste(schemas, collapse = ", ")
    ))
  }

  # Sort deterministically by run_id and timestamp_ns
  df$run_id <- as.character(df$run_id)
  ord <- order(df$run_id, df$timestamp_ns, df$step)
  df <- df[ord, , drop = FALSE]
  rownames(df) <- NULL

  # Remove duplicate timestamps within the same run_id
  dup_key <- paste(df$run_id, df$timestamp_ns, sep = "::")
  dup_mask <- duplicated(dup_key)
  dup_removed <- sum(dup_mask)
  if (dup_removed > 0L) {
    df <- df[!dup_mask, , drop = FALSE]
    rownames(df) <- NULL
  }

  # Handle missing/non-finite numeric values strictly within each run_id
  numeric_cols <- setdiff(req_cols, c("schema_version", "run_id", "scenario_id", "controller_mode"))
  non_finite_repaired <- 0L
  drop_rows <- rep(FALSE, nrow(df))

  for (rid in unique(df$run_id)) {
    idx <- which(df$run_id == rid)
    if (length(idx) < 3L) {
      drop_rows[idx] <- TRUE
      next
    }
    # Enforce monotonic timestamps per run
    ts <- as.numeric(df$timestamp_ns[idx])
    if (any(!is.finite(ts)) || any(diff(ts) <= 0)) {
      stop(sprintf("Non-monotonic or non-finite timestamp detected in run_id '%s'", rid))
    }

    for (col in numeric_cols) {
      vals <- as.numeric(df[[col]][idx])
      bad <- !is.finite(vals)
      if (any(bad)) {
        good <- which(!bad)
        if (length(good) < 2L) {
          drop_rows[idx[bad]] <- TRUE
        } else {
          interp <- approx(x = ts[good], y = vals[good], xout = ts, rule = 2)$y
          df[[col]][idx[bad]] <- interp[bad]
          non_finite_repaired <- non_finite_repaired + sum(bad)
        }
      }
    }
  }

  if (any(drop_rows)) {
    df <- df[!drop_rows, , drop = FALSE]
    rownames(df) <- NULL
  }

  # Physical SI unit & bounds plausibility checks
  q_cols <- paste0("q_meas_", 0:5)
  dq_cols <- paste0("dq_meas_", 0:5)
  q_mat <- as.matrix(df[, q_cols, drop = FALSE])
  dq_mat <- as.matrix(df[, dq_cols, drop = FALSE])

  if (any(abs(q_mat) > 3.5)) {
    stop("Unit check failed: joint position magnitude exceeds 3.5 rad (expected radians, not degrees)")
  }
  if (any(abs(dq_mat) > 10.0)) {
    stop("Unit check failed: joint velocity magnitude exceeds 10.0 rad/s")
  }
  if (any(df$payload_est_kg < 0 | df$payload_est_kg > 5.0)) {
    stop("Unit check failed: payload_est_kg outside plausible [0, 5] kg range")
  }
  if (any(df$motor_temp_c < 0 | df$motor_temp_c > 120.0)) {
    stop("Unit check failed: motor_temp_c outside plausible [0, 120] C range")
  }

  # Build lagged previous tracking error feature STRICTLY within each run_id (0.0 at step 0)
  for (j in 0:5) {
    err_now <- df[[paste0("q_ref_", j)]] - df[[paste0("q_meas_", j)]]
    prev_err <- numeric(nrow(df))
    for (rid in unique(df$run_id)) {
      idx <- which(df$run_id == rid)
      if (length(idx) > 1L) {
        prev_err[idx[-1]] <- err_now[idx[-length(idx)]]
      }
      prev_err[idx[1]] <- 0.0
    }
    df[[paste0("prev_err_", j)]] <- prev_err
    df[[paste0("target_res_", j)]] <- err_now
  }

  list(
    data = df,
    report = list(
      rows = nrow(df),
      runs = length(unique(df$run_id)),
      non_finite_repaired = as.integer(non_finite_repaired),
      duplicate_timestamps_removed = as.integer(dup_removed),
      units_verified = TRUE
    )
  )
}

split_by_run_id <- function(df, train_frac = 0.6, val_frac = 0.2, seed = 42L) {
  runs <- sort(unique(as.character(df$run_id)))
  n_runs <- length(runs)
  if (n_runs < 3L) {
    stop("At least 3 complete runs are required for train/validation/test run-grouped split")
  }

  set.seed(seed)
  perm <- sample(runs, size = n_runs, replace = FALSE)
  n_train <- max(1L, floor(n_runs * train_frac))
  n_val <- max(1L, floor(n_runs * val_frac))
  if (n_train + n_val >= n_runs) {
    n_val <- 1L
    n_train <- max(1L, n_runs - 2L)
  }

  train_runs <- sort(perm[seq_len(n_train)])
  val_runs <- sort(perm[(n_train + 1L):(n_train + n_val)])
  test_runs <- sort(perm[(n_train + n_val + 1L):n_runs])

  # Assert strictly disjoint run_ids across splits
  stopifnot(length(intersect(train_runs, val_runs)) == 0L)
  stopifnot(length(intersect(train_runs, test_runs)) == 0L)
  stopifnot(length(intersect(val_runs, test_runs)) == 0L)

  list(
    train = df[df$run_id %in% train_runs, , drop = FALSE],
    val = df[df$run_id %in% val_runs, , drop = FALSE],
    test = df[df$run_id %in% test_runs, , drop = FALSE],
    train_runs = train_runs,
    val_runs = val_runs,
    test_runs = test_runs
  )
}
