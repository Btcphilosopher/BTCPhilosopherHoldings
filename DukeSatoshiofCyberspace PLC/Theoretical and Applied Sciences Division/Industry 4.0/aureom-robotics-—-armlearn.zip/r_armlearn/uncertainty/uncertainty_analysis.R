# AUREOM ROBOTICS — ArmLearn Uncertainty Decomposition (Sensor Noise vs Parameter Epistemic vs Model Error)

suppressPackageStartupMessages(library(glmnet))

estimate_sensor_noise_sd <- function(df, joint_idx) {
  col <- paste0("q_meas_", joint_idx)
  diffs2 <- numeric(0)
  for (rid in unique(df$run_id)) {
    sub <- df[df$run_id == rid, , drop = FALSE]
    if (nrow(sub) >= 10L) {
      q <- as.numeric(sub[[col]])
      diffs2 <- c(diffs2, diff(q, differences = 2L))
    }
  }
  if (length(diffs2) < 5L) return(0.0)
  # Second-difference noise estimator: Var(q[t] - 2q[t-1] + q[t-2]) = 6 * sigma_noise^2
  # Use MAD for robustness against trajectory curvature corners
  mad_est <- mad(diffs2, constant = 1.4826)
  as.numeric(mad_est / sqrt(6.0))
}

analyze_uncertainty <- function(split_obj, trained, n_boot = 25L, seed = 77L) {
  train_df <- split_obj$train
  test_df <- split_obj$test
  X_train <- trained$X_train
  X_test <- trained$X_test
  mean_vec <- trained$artefact$normalization$mean
  std_vec <- trained$artefact$normalization$std
  Z_train <- sweep(sweep(X_train, 2L, mean_vec, "-"), 2L, std_vec, "/")
  Z_test <- sweep(sweep(X_test, 2L, mean_vec, "-"), 2L, std_vec, "/")

  train_runs <- unique(as.character(train_df$run_id))
  set.seed(seed)

  # Pre-draw run-level block bootstrap samples
  boot_indices <- vector("list", n_boot)
  for (b in seq_len(n_boot)) {
    sampled_runs <- sample(train_runs, size = length(train_runs), replace = TRUE)
    idx_list <- lapply(sampled_runs, function(r) which(train_df$run_id == r))
    boot_indices[[b]] <- unlist(idx_list, use.names = FALSE)
  }

  out <- list()
  for (j in 0:5) {
    y_test <- as.numeric(test_df[[paste0("target_res_", j)]])
    y_train <- as.numeric(train_df[[paste0("target_res_", j)]])
    pred_full <- as.numeric(trained$pred_test[, j + 1L])
    res_test <- y_test - pred_full

    total_rmse <- sqrt(mean(res_test^2))
    sensor_sd <- estimate_sensor_noise_sd(test_df, j)

    # Parameter epistemic uncertainty via run-level block bootstrap of ridge/elastic-net fit
    boot_preds <- matrix(0.0, nrow = nrow(Z_test), ncol = n_boot)
    for (b in seq_len(n_boot)) {
      b_idx <- boot_indices[[b]]
      yb <- y_train[b_idx]
      if (sd(yb) < 1e-10) {
        boot_preds[, b] <- mean(yb)
      } else {
        fit_b <- glmnet(
          x = Z_train[b_idx, , drop = FALSE],
          y = yb,
          alpha = 0.05,
          lambda = 0.002,
          standardize = FALSE
        )
        boot_preds[, b] <- as.numeric(predict(fit_b, newx = Z_test))
      }
    }
    epistemic_sd <- sqrt(mean(apply(boot_preds, 1L, var)))

    unmodeled_var <- max(0.0, total_rmse^2 - sensor_sd^2 - epistemic_sd^2)
    unmodeled_sd <- sqrt(unmodeled_var)
    p95_abs <- as.numeric(quantile(abs(res_test), probs = 0.95, names = FALSE))

    out[[paste0("joint_", j)]] <- list(
      joint_index = as.integer(j),
      total_test_rmse_rad = total_rmse,
      sensor_noise_sd_rad = sensor_sd,
      parameter_epistemic_sd_rad = epistemic_sd,
      unmodeled_dynamics_sd_rad = unmodeled_sd,
      residual_p95_abs_rad = p95_abs
    )
  }
  out
}
