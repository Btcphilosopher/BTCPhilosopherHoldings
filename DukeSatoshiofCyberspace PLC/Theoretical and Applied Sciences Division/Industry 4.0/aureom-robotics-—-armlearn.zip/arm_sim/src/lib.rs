use std::collections::VecDeque;

use arm_model::ArmModel;
use arm_planner::CollisionScene;
use arm_types::{
    ActuatorCommand, GripperCommand, GripperState, JointFrictionParams, JointState, PayloadSpec,
    Pose3, WorkpieceSpec, NUM_JOINTS,
};
use nalgebra::Vector3;
use rand::Rng;
use rand::SeedableRng;
use rand_chacha::ChaCha8Rng;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimScenarioConfig {
    pub scenario_id: String,
    pub seed: u64,
    pub dt_control_s: f64,
    pub physics_substeps: usize,
    pub encoder_noise_std_rad: f64,
    pub velocity_noise_std_rad_s: f64,
    pub command_delay_steps: usize,
    pub friction_scale: f64,
    pub extra_coulomb_nm: [f64; NUM_JOINTS],
    pub compliance_scale: f64,
    pub true_payload_override_kg: Option<f64>,
    pub ambient_temp_c: f64,
    pub workpiece: WorkpieceSpec,
}

impl SimScenarioConfig {
    pub fn nominal(seed: u64) -> Self {
        Self {
            scenario_id: format!("nominal_s{seed}"),
            seed,
            dt_control_s: 0.01,
            physics_substeps: 5,
            encoder_noise_std_rad: 0.00025,
            velocity_noise_std_rad_s: 0.0025,
            command_delay_steps: 1,
            friction_scale: 1.45,
            extra_coulomb_nm: [0.45, 0.85, 0.65, 0.20, 0.18, 0.10],
            compliance_scale: 1.35,
            true_payload_override_kg: None,
            ambient_temp_c: 38.0,
            workpiece: WorkpieceSpec {
                id: "workpiece_a".to_string(),
                mass_kg: 0.55,
                half_extents_m: [0.022, 0.022, 0.022],
                initial_pose: Pose3::from_translation_rpy([0.36, -0.22, 0.082], 0.0, 0.0, 0.0),
                target_place_pose: Pose3::from_translation_rpy([0.34, 0.24, 0.072], 0.0, 0.0, 0.0),
            },
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GraspConditions {
    pub max_tcp_offset_m: f64,
    pub max_orientation_err_rad: f64,
    pub max_tcp_speed_mps: f64,
    pub min_dwell_ticks: u32,
}

impl Default for GraspConditions {
    fn default() -> Self {
        Self {
            max_tcp_offset_m: 0.022,
            max_orientation_err_rad: 0.25,
            max_tcp_speed_mps: 0.08,
            min_dwell_ticks: 3,
        }
    }
}

#[derive(Debug, Clone)]
pub struct SimWorldState {
    pub q_true: [f64; NUM_JOINTS],
    pub dq_true: [f64; NUM_JOINTS],
    pub ddq_true: [f64; NUM_JOINTS],
    pub sim_time_s: f64,
    pub timestamp_ns: u64,
    pub seq: u64,
    pub gripper: GripperState,
    pub workpiece_pose: Pose3,
    pub workpiece_grasped: bool,
    pub place_completed: bool,
    pub motor_temp_c: [f64; NUM_JOINTS],
    pub grasp_dwell_counter: u32,
}

pub struct ArmSimulator {
    pub arm: ArmModel,
    pub scene: CollisionScene,
    pub config: SimScenarioConfig,
    pub grasp_rules: GraspConditions,
    pub state: SimWorldState,
    pub true_friction: Vec<JointFrictionParams>,
    rng: ChaCha8Rng,
    delay_queue: VecDeque<([f64; NUM_JOINTS], [f64; NUM_JOINTS])>,
    active_cmd_q: [f64; NUM_JOINTS],
    active_cmd_dq: [f64; NUM_JOINTS],
    servo_kp: [f64; NUM_JOINTS],
    servo_kd: [f64; NUM_JOINTS],
    gripper_closing_requested: bool,
    gripper_target_width_m: f64,
}

impl ArmSimulator {
    pub fn new(
        arm: ArmModel,
        scene: CollisionScene,
        config: SimScenarioConfig,
        q_init: [f64; NUM_JOINTS],
    ) -> Self {
        let mut true_friction = Vec::with_capacity(NUM_JOINTS);
        for (j, spec) in arm.desc.joints.iter().enumerate() {
            true_friction.push(JointFrictionParams {
                coulomb_nm: spec.nominal_friction.coulomb_nm * config.friction_scale
                    + config.extra_coulomb_nm[j],
                viscous_nms_rad: spec.nominal_friction.viscous_nms_rad * config.friction_scale,
                compliance_rad_per_nm: spec.nominal_friction.compliance_rad_per_nm
                    * config.compliance_scale,
            });
        }
        let mut delay_queue = VecDeque::new();
        for _ in 0..config.command_delay_steps {
            delay_queue.push_back((q_init, [0.0; NUM_JOINTS]));
        }

        let workpiece_pose = config.workpiece.initial_pose;
        let state = SimWorldState {
            q_true: q_init,
            dq_true: [0.0; NUM_JOINTS],
            ddq_true: [0.0; NUM_JOINTS],
            sim_time_s: 0.0,
            timestamp_ns: 1_000_000_000,
            seq: 0,
            gripper: GripperState::Open { width_m: 0.085 },
            workpiece_pose,
            workpiece_grasped: false,
            place_completed: false,
            motor_temp_c: [config.ambient_temp_c; NUM_JOINTS],
            grasp_dwell_counter: 0,
        };

        Self {
            arm,
            scene,
            rng: ChaCha8Rng::seed_from_u64(config.seed),
            config,
            grasp_rules: GraspConditions::default(),
            state,
            true_friction,
            delay_queue,
            active_cmd_q: q_init,
            active_cmd_dq: [0.0; NUM_JOINTS],
            servo_kp: [280.0, 340.0, 290.0, 180.0, 160.0, 120.0],
            servo_kd: [26.0, 34.0, 28.0, 14.0, 12.0, 9.0],
            gripper_closing_requested: false,
            gripper_target_width_m: 0.085,
        }
    }

    pub fn current_true_payload(&self) -> PayloadSpec {
        if !self.state.workpiece_grasped {
            return PayloadSpec::default();
        }
        let m = self
            .config
            .true_payload_override_kg
            .unwrap_or(self.config.workpiece.mass_kg);
        PayloadSpec {
            name: self.config.workpiece.id.clone(),
            mass_kg: m,
            com_in_tcp_m: [0.0, 0.0, 0.015],
        }
    }

    pub fn enqueue_command(&mut self, cmd: &ActuatorCommand) -> Result<(), String> {
        let (q_t, dq_t) = match cmd {
            ActuatorCommand::PositionTarget {
                q_rad,
                dq_ff_rad_s,
                ..
            } => (*q_rad, *dq_ff_rad_s),
            ActuatorCommand::VelocityTarget { .. } => {
                return Err("Simulator configured in position-servo mode; velocity mode disabled".to_string());
            }
            ActuatorCommand::TorqueTarget { .. } => {
                return Err("Position-commanded interface does not accept direct motor torque targets".to_string());
            }
        };

        if self.config.command_delay_steps == 0 {
            self.active_cmd_q = q_t;
            self.active_cmd_dq = dq_t;
        } else {
            self.delay_queue.push_back((q_t, dq_t));
            if let Some((q_del, dq_del)) = self.delay_queue.pop_front() {
                self.active_cmd_q = q_del;
                self.active_cmd_dq = dq_del;
            }
        }
        Ok(())
    }

    pub fn command_gripper(&mut self, cmd: GripperCommand) {
        match cmd {
            GripperCommand::Open => {
                self.gripper_closing_requested = false;
                self.gripper_target_width_m = 0.085;
                self.state.grasp_dwell_counter = 0;
                if self.state.workpiece_grasped {
                    self.state.workpiece_grasped = false;
                    let fk = self.arm.forward_kinematics(&self.state.q_true);
                    let tcp_p = Vector3::from(fk.tcp_world.translation_m);
                    let tgt_p = Vector3::from(self.config.workpiece.target_place_pose.translation_m);
                    let horiz_err = ((tcp_p.x - tgt_p.x).powi(2) + (tcp_p.y - tgt_p.y).powi(2)).sqrt();
                    let dz = tcp_p.z - tgt_p.z;
                    if horiz_err < 0.030 && (-0.015..=0.045).contains(&dz) {
                        self.state.workpiece_pose = Pose3::from_translation_rpy(
                            [tcp_p.x, tcp_p.y, tgt_p.z],
                            0.0,
                            0.0,
                            0.0,
                        );
                        self.state.place_completed = true;
                    } else {
                        self.state.workpiece_pose = Pose3::from_translation_rpy(
                            [tcp_p.x, tcp_p.y, self.config.workpiece.half_extents_m[2]],
                            0.0,
                            0.0,
                            0.0,
                        );
                        self.state.place_completed = false;
                    }
                }
                self.state.gripper = GripperState::Open { width_m: 0.085 };
            }
            GripperCommand::Close {
                target_width_m,
                max_force_n,
            } => {
                self.gripper_closing_requested = true;
                self.gripper_target_width_m = target_width_m;
                if !self.state.workpiece_grasped {
                    self.state.gripper = GripperState::Closed {
                        width_m: target_width_m,
                        force_n: max_force_n,
                        grasped_object_id: None,
                    };
                }
            }
        }
    }

    fn compute_accel(
        &self,
        q: &[f64; NUM_JOINTS],
        dq: &[f64; NUM_JOINTS],
        payload: &PayloadSpec,
    ) -> [f64; NUM_JOINTS] {
        let m_diag = self.arm.effective_inertia_diag(q, payload);
        let tau_g = self.arm.gravity_torques(q, payload);
        let mut ddq = [0.0_f64; NUM_JOINTS];

        for j in 0..NUM_JOINTS {
            let tau_drive = self.servo_kp[j] * (self.active_cmd_q[j] - q[j])
                + self.servo_kd[j] * (self.active_cmd_dq[j] - dq[j]);
            let tau_fric = ArmModel::friction_torque(dq[j], &self.true_friction[j]);
            let compliance_torque = tau_g[j] * (self.true_friction[j].compliance_rad_per_nm * 2200.0);
            let net_tau = (tau_drive - tau_g[j] - compliance_torque - tau_fric).clamp(
                -self.arm.desc.joints[j].limits.torque_max_nm,
                self.arm.desc.joints[j].limits.torque_max_nm,
            );
            ddq[j] = net_tau / m_diag[j];
        }
        ddq
    }

    pub fn step_physics(&mut self) {
        let substeps = self.config.physics_substeps.max(1);
        let h = self.config.dt_control_s / (substeps as f64);
        let payload = self.current_true_payload();

        for _ in 0..substeps {
            let q0 = self.state.q_true;
            let dq0 = self.state.dq_true;

            let k1_v = dq0;
            let k1_a = self.compute_accel(&q0, &dq0, &payload);

            let mut q2 = [0.0; NUM_JOINTS];
            let mut v2 = [0.0; NUM_JOINTS];
            for j in 0..NUM_JOINTS {
                q2[j] = q0[j] + 0.5 * h * k1_v[j];
                v2[j] = dq0[j] + 0.5 * h * k1_a[j];
            }
            let k2_v = v2;
            let k2_a = self.compute_accel(&q2, &v2, &payload);

            let mut q3 = [0.0; NUM_JOINTS];
            let mut v3 = [0.0; NUM_JOINTS];
            for j in 0..NUM_JOINTS {
                q3[j] = q0[j] + 0.5 * h * k2_v[j];
                v3[j] = dq0[j] + 0.5 * h * k2_a[j];
            }
            let k3_v = v3;
            let k3_a = self.compute_accel(&q3, &v3, &payload);

            let mut q4 = [0.0; NUM_JOINTS];
            let mut v4 = [0.0; NUM_JOINTS];
            for j in 0..NUM_JOINTS {
                q4[j] = q0[j] + h * k3_v[j];
                v4[j] = dq0[j] + h * k3_a[j];
            }
            let k4_v = v4;
            let k4_a = self.compute_accel(&q4, &v4, &payload);

            for j in 0..NUM_JOINTS {
                self.state.q_true[j] +=
                    (h / 6.0) * (k1_v[j] + 2.0 * k2_v[j] + 2.0 * k3_v[j] + k4_v[j]);
                self.state.dq_true[j] +=
                    (h / 6.0) * (k1_a[j] + 2.0 * k2_a[j] + 2.0 * k3_a[j] + k4_a[j]);
                self.state.ddq_true[j] = k4_a[j];
                let lim = &self.arm.desc.joints[j].limits;
                if self.state.q_true[j] < lim.pos_min_rad {
                    self.state.q_true[j] = lim.pos_min_rad;
                    self.state.dq_true[j] = self.state.dq_true[j].max(0.0);
                } else if self.state.q_true[j] > lim.pos_max_rad {
                    self.state.q_true[j] = lim.pos_max_rad;
                    self.state.dq_true[j] = self.state.dq_true[j].min(0.0);
                }
            }
        }

        for j in 0..NUM_JOINTS {
            self.state.motor_temp_c[j] = (self.state.motor_temp_c[j]
                + 0.004 * self.state.dq_true[j].abs() * self.config.dt_control_s)
                .min(72.0);
        }

        self.state.sim_time_s += self.config.dt_control_s;
        self.state.timestamp_ns += (self.config.dt_control_s * 1e9).round() as u64;
        self.state.seq += 1;

        self.evaluate_grasp_contact();
    }

    fn evaluate_grasp_contact(&mut self) {
        let fk = self.arm.forward_kinematics(&self.state.q_true);
        if self.state.workpiece_grasped {
            self.state.workpiece_pose = fk.tcp_world;
            return;
        }
        if !self.gripper_closing_requested {
            return;
        }
        let obj_width = self.config.workpiece.half_extents_m[1] * 2.0;
        if self.gripper_target_width_m > obj_width + 0.015 {
            self.state.grasp_dwell_counter = 0;
            return;
        }
        let tcp_p = Vector3::from(fk.tcp_world.translation_m);
        let obj_p = Vector3::from(self.state.workpiece_pose.translation_m);
        let dist = (tcp_p - obj_p).norm();

        let jac = self.arm.geometric_jacobian(&self.state.q_true);
        let dq_v = nalgebra::SVector::<f64, 6>::from_row_slice(&self.state.dq_true);
        let twist = jac * dq_v;
        let tcp_speed = Vector3::new(twist[0], twist[1], twist[2]).norm();

        let tcp_z_world = fk.tcp_world.to_isometry().rotation * Vector3::new(0.0, 0.0, 1.0);
        let ori_err = tcp_z_world.dot(&Vector3::new(0.0, 0.0, -1.0)).clamp(-1.0, 1.0).acos();

        if dist <= self.grasp_rules.max_tcp_offset_m
            && ori_err <= self.grasp_rules.max_orientation_err_rad
            && tcp_speed <= self.grasp_rules.max_tcp_speed_mps
        {
            self.state.grasp_dwell_counter += 1;
            if self.state.grasp_dwell_counter >= self.grasp_rules.min_dwell_ticks {
                self.state.workpiece_grasped = true;
                self.state.gripper = GripperState::Closed {
                    width_m: obj_width,
                    force_n: 35.0,
                    grasped_object_id: Some(self.config.workpiece.id.clone()),
                };
            }
        } else {
            self.state.grasp_dwell_counter = 0;
        }
    }

    pub fn read_sensor_state(&mut self) -> JointState {
        let mut q_meas = [0.0; NUM_JOINTS];
        let mut dq_meas = [0.0; NUM_JOINTS];
        for j in 0..NUM_JOINTS {
            q_meas[j] = self.state.q_true[j] + self.sample_gaussian(self.config.encoder_noise_std_rad);
            dq_meas[j] =
                self.state.dq_true[j] + self.sample_gaussian(self.config.velocity_noise_std_rad_s);
        }
        JointState {
            q: q_meas,
            dq: dq_meas,
            ddq: self.state.ddq_true,
            tau_measured: None,
            motor_temp_c: Some(self.state.motor_temp_c),
            timestamp_ns: self.state.timestamp_ns,
            seq: self.state.seq,
        }
    }

    fn sample_gaussian(&mut self, std_dev: f64) -> f64 {
        if std_dev <= 0.0 {
            return 0.0;
        }
        let u1: f64 = self.rng.gen_range(1e-12_f64..1.0_f64);
        let u2: f64 = self.rng.gen_range(0.0_f64..1.0_f64);
        let z0 = (-2.0 * u1.ln()).sqrt() * (2.0 * std::f64::consts::PI * u2).cos();
        z0 * std_dev
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use arm_planner::MotionPlanner;

    #[test]
    fn grasp_does_not_succeed_when_far_from_object() {
        let arm = ArmModel::default_6r_650();
        let scene = CollisionScene::default_workcell();
        let cfg = SimScenarioConfig::nominal(42);
        let mut sim = ArmSimulator::new(arm, scene, cfg, MotionPlanner::home_configuration());
        sim.command_gripper(GripperCommand::Close {
            target_width_m: 0.044,
            max_force_n: 30.0,
        });
        for _ in 0..10 {
            sim.step_physics();
        }
        assert!(!sim.state.workpiece_grasped);
    }

    #[test]
    fn deterministic_seed_reproduces_identical_trajectories() {
        let run_once = |seed| {
            let arm = ArmModel::default_6r_650();
            let scene = CollisionScene::default_workcell();
            let cfg = SimScenarioConfig::nominal(seed);
            let mut sim = ArmSimulator::new(arm, scene, cfg, MotionPlanner::home_configuration());
            let mut out = Vec::new();
            for k in 0..20 {
                let cmd = ActuatorCommand::PositionTarget {
                    q_rad: [0.05 * (k as f64 / 20.0), 0.25, 1.0, 0.0, 0.35, 0.0],
                    dq_ff_rad_s: [0.0; 6],
                    timestamp_ns: sim.state.timestamp_ns,
                    seq: k,
                };
                sim.enqueue_command(&cmd).unwrap();
                sim.step_physics();
                out.push(sim.read_sensor_state().q);
            }
            out
        };
        assert_eq!(run_once(1234), run_once(1234));
    }
}
