use arm_model::{ArmModel, IkError, IkOptions};
use arm_types::{
    sha256_hex, BoxObstacle, LinkGeometry, Pose3, WorkpieceSpec, NUM_JOINTS,
};
use nalgebra::Vector3;
use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Debug, Error)]
pub enum PlannerError {
    #[error("Start configuration violates joint limits or collision constraints: {0}")]
    InvalidStart(String),
    #[error("Goal configuration violates joint limits or collision constraints: {0}")]
    InvalidGoal(String),
    #[error("Inverse kinematics failure for waypoint '{waypoint}': {source}")]
    IkFailed {
        waypoint: String,
        #[source]
        source: IkError,
    },
    #[error("Collision detected on segment '{segment}' at alpha={alpha:.3}: {detail}")]
    CollisionDetected {
        segment: String,
        alpha: f64,
        detail: String,
    },
    #[error("Joint limit violation along segment '{segment}' at alpha={alpha:.3}, joint {joint}")]
    JointLimitAlongPath {
        segment: String,
        alpha: f64,
        joint: usize,
    },
    #[error("Trajectory plan invalidated: {0}")]
    PlanInvalidated(String),
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CollisionScene {
    pub table_z_m: f64,
    pub obstacles: Vec<BoxObstacle>,
    pub clearance_margin_m: f64,
}

impl CollisionScene {
    pub fn default_workcell() -> Self {
        Self {
            table_z_m: 0.0,
            obstacles: vec![
                BoxObstacle {
                    id: "divider_post".to_string(),
                    center_m: [0.38, 0.0, 0.11],
                    half_extents_m: [0.035, 0.035, 0.11],
                },
                BoxObstacle {
                    id: "pick_pedestal".to_string(),
                    center_m: [0.36, -0.22, 0.03],
                    half_extents_m: [0.06, 0.06, 0.03],
                },
                BoxObstacle {
                    id: "place_pallet".to_string(),
                    center_m: [0.34, 0.24, 0.025],
                    half_extents_m: [0.07, 0.07, 0.025],
                },
            ],
            clearance_margin_m: 0.008,
        }
    }

    pub fn scene_hash(&self) -> String {
        let s = serde_json::to_string(self).unwrap_or_default();
        sha256_hex(s.as_bytes())
    }
}

#[derive(Debug, Clone)]
struct WorldCapsule {
    name: String,
    p1: Vector3<f64>,
    p2: Vector3<f64>,
    radius: f64,
}

#[derive(Debug, Clone, PartialEq)]
pub struct CollisionReport {
    pub collision_free_under_model: bool,
    pub min_clearance_m: f64,
    pub detail: String,
}

pub struct CollisionChecker;

impl CollisionChecker {
    fn link_capsules_world(arm: &ArmModel, q: &[f64; NUM_JOINTS], carried_object_radius_m: Option<f64>) -> Vec<WorldCapsule> {
        let fk = arm.forward_kinematics(q);
        let mut caps = Vec::with_capacity(NUM_JOINTS + 2);
        for i in 0..NUM_JOINTS {
            let iso = fk.link_frames_world[i];
            match &arm.desc.joints[i].link_geometry {
                LinkGeometry::Capsule { p1_m, p2_m, radius_m } => {
                    let p1 = iso.transform_point(&nalgebra::Point3::from(*p1_m)).coords;
                    let p2 = iso.transform_point(&nalgebra::Point3::from(*p2_m)).coords;
                    caps.push(WorldCapsule {
                        name: arm.desc.joints[i].name.clone(),
                        p1,
                        p2,
                        radius: *radius_m,
                    });
                }
                LinkGeometry::Sphere { center_m, radius_m } => {
                    let p = iso.transform_point(&nalgebra::Point3::from(*center_m)).coords;
                    caps.push(WorldCapsule {
                        name: arm.desc.joints[i].name.clone(),
                        p1: p,
                        p2: p,
                        radius: *radius_m,
                    });
                }
            }
        }
        let flange_iso = fk.link_frames_world[NUM_JOINTS - 1];
        if let LinkGeometry::Capsule { p1_m, p2_m, radius_m } = &arm.desc.gripper_capsule_in_flange {
            caps.push(WorldCapsule {
                name: "gripper".to_string(),
                p1: flange_iso.transform_point(&nalgebra::Point3::from(*p1_m)).coords,
                p2: flange_iso.transform_point(&nalgebra::Point3::from(*p2_m)).coords,
                radius: *radius_m,
            });
        }
        if let Some(obj_r) = carried_object_radius_m {
            let tcp_p = Vector3::from(fk.tcp_world.translation_m);
            caps.push(WorldCapsule {
                name: "carried_workpiece".to_string(),
                p1: tcp_p,
                p2: tcp_p,
                radius: obj_r,
            });
        }
        caps
    }

    pub fn check_configuration(
        arm: &ArmModel,
        scene: &CollisionScene,
        q: &[f64; NUM_JOINTS],
        carried_object_radius_m: Option<f64>,
        ignore_table_for_gripper: bool,
    ) -> CollisionReport {
        if !arm.within_joint_limits(q, 0.0) {
            return CollisionReport {
                collision_free_under_model: false,
                min_clearance_m: -1.0,
                detail: "Joint limit exceeded".to_string(),
            };
        }

        let caps = Self::link_capsules_world(arm, q, carried_object_radius_m);
        let mut min_clearance = f64::INFINITY;
        let margin = scene.clearance_margin_m;

        for i in 0..caps.len() {
            for j in (i + 2)..caps.len() {
                if (caps[i].name == "j5_wrist_pitch" && caps[j].name == "gripper")
                    || (caps[i].name == "j6_flange_roll" && caps[j].name == "gripper")
                    || (caps[i].name == "gripper" && caps[j].name == "carried_workpiece")
                    || (caps[i].name == "j6_flange_roll" && caps[j].name == "carried_workpiece")
                    || (caps[i].name == "j5_wrist_pitch" && caps[j].name == "carried_workpiece")
                {
                    continue;
                }
                let dist = segment_segment_distance(caps[i].p1, caps[i].p2, caps[j].p1, caps[j].p2);
                let clearance = dist - (caps[i].radius + caps[j].radius);
                if clearance < min_clearance {
                    min_clearance = clearance;
                }
                if clearance < margin {
                    return CollisionReport {
                        collision_free_under_model: false,
                        min_clearance_m: clearance,
                        detail: format!(
                            "Self-collision between {} and {} (clearance={clearance:.4} m)",
                            caps[i].name, caps[j].name
                        ),
                    };
                }
            }
        }

        for cap in caps.iter().skip(1) {
            let min_z = cap.p1.z.min(cap.p2.z) - cap.radius;
            let clearance = min_z - scene.table_z_m;
            if ignore_table_for_gripper && (cap.name == "gripper" || cap.name == "carried_workpiece") {
                continue;
            }
            if clearance < min_clearance {
                min_clearance = clearance;
            }
            if clearance < 0.002 {
                return CollisionReport {
                    collision_free_under_model: false,
                    min_clearance_m: clearance,
                    detail: format!(
                        "Table clearance violation for {} (z_clearance={clearance:.4} m)",
                        cap.name
                    ),
                };
            }
        }

        for cap in caps.iter().skip(1) {
            for obs in &scene.obstacles {
                if (cap.name == "gripper" || cap.name == "carried_workpiece")
                    && (obs.id == "pick_pedestal" || obs.id == "place_pallet")
                {
                    continue;
                }
                let d_seg_box = segment_aabb_distance(
                    cap.p1,
                    cap.p2,
                    Vector3::from(obs.center_m),
                    Vector3::from(obs.half_extents_m),
                );
                let clearance = d_seg_box - cap.radius;
                if clearance < min_clearance {
                    min_clearance = clearance;
                }
                if clearance < margin {
                    return CollisionReport {
                        collision_free_under_model: false,
                        min_clearance_m: clearance,
                        detail: format!(
                            "Obstacle collision between {} and '{}' (clearance={clearance:.4} m)",
                            cap.name, obs.id
                        ),
                    };
                }
            }
        }

        CollisionReport {
            collision_free_under_model: true,
            min_clearance_m: min_clearance,
            detail: "Collision-free under geometric capsule/AABB model".to_string(),
        }
    }
}

pub fn segment_segment_distance(
    a0: Vector3<f64>,
    a1: Vector3<f64>,
    b0: Vector3<f64>,
    b1: Vector3<f64>,
) -> f64 {
    let u = a1 - a0;
    let v = b1 - b0;
    let w = a0 - b0;
    let a = u.dot(&u);
    let b = u.dot(&v);
    let c = v.dot(&v);
    let d = u.dot(&w);
    let e = v.dot(&w);
    let denom = a * c - b * b;
    let eps = 1e-12;

    let mut s_n: f64;
    let mut s_d = denom;
    let mut t_n: f64;
    let mut t_d = denom;

    if denom < eps {
        s_n = 0.0;
        s_d = 1.0;
        t_n = e;
        t_d = c;
    } else {
        s_n = b * e - c * d;
        t_n = a * e - b * d;
        if s_n < 0.0 {
            s_n = 0.0;
            t_n = e;
            t_d = c;
        } else if s_n > s_d {
            s_n = s_d;
            t_n = e + b;
            t_d = c;
        }
    }

    if t_n < 0.0 {
        t_n = 0.0;
        if -d < 0.0 {
            s_n = 0.0;
        } else if -d > a {
            s_n = s_d;
        } else {
            s_n = -d;
            s_d = a;
        }
    } else if t_n > t_d {
        t_n = t_d;
        if (-d + b) < 0.0 {
            s_n = 0.0;
        } else if (-d + b) > a {
            s_n = s_d;
        } else {
            s_n = -d + b;
            s_d = a;
        }
    }

    let sc = if s_n.abs() < eps { 0.0 } else { s_n / s_d };
    let tc = if t_n.abs() < eps { 0.0 } else { t_n / t_d };
    let dp = w + (sc * u) - (tc * v);
    dp.norm()
}

fn segment_aabb_distance(
    p0: Vector3<f64>,
    p1: Vector3<f64>,
    center: Vector3<f64>,
    half: Vector3<f64>,
) -> f64 {
    let mut best = f64::INFINITY;
    let steps = 12;
    for k in 0..=steps {
        let t = (k as f64) / (steps as f64);
        let p = p0 + t * (p1 - p0);
        let d = point_aabb_distance(p, center, half);
        if d < best {
            best = d;
        }
    }
    best
}

fn point_aabb_distance(p: Vector3<f64>, center: Vector3<f64>, half: Vector3<f64>) -> f64 {
    let rel = p - center;
    let dx = (rel.x.abs() - half.x).max(0.0);
    let dy = (rel.y.abs() - half.y).max(0.0);
    let dz = (rel.z.abs() - half.z).max(0.0);
    Vector3::new(dx, dy, dz).norm()
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SegmentPhase {
    ApproachPick,
    DescendPick,
    DwellCloseGripper,
    RetreatPick,
    TransitHigh,
    ApproachPlace,
    DescendPlace,
    DwellOpenGripper,
    RetreatPlace,
    ReturnHome,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QuinticSegment {
    pub name: String,
    pub phase: SegmentPhase,
    pub q_start: [f64; NUM_JOINTS],
    pub q_end: [f64; NUM_JOINTS],
    pub t_start_s: f64,
    pub duration_s: f64,
    pub gripper_close_after: Option<bool>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrajectorySample {
    pub time_s: f64,
    pub phase: SegmentPhase,
    pub q: [f64; NUM_JOINTS],
    pub dq: [f64; NUM_JOINTS],
    pub ddq: [f64; NUM_JOINTS],
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlannedTrajectory {
    pub robot_config_hash: String,
    pub scene_hash: String,
    pub segments: Vec<QuinticSegment>,
    pub total_duration_s: f64,
    pub validation_step_rad: f64,
    pub min_model_clearance_m: f64,
    pub collision_free_under_model: bool,
}

impl PlannedTrajectory {
    pub fn validate_freshness(&self, arm: &ArmModel, scene: &CollisionScene) -> Result<(), PlannerError> {
        if arm.desc.config_hash() != self.robot_config_hash {
            return Err(PlannerError::PlanInvalidated(
                "Robot configuration hash changed since planning".to_string(),
            ));
        }
        if scene.scene_hash() != self.scene_hash {
            return Err(PlannerError::PlanInvalidated(
                "Collision scene changed since planning".to_string(),
            ));
        }
        Ok(())
    }

    pub fn sample(&self, time_s: f64) -> TrajectorySample {
        if self.segments.is_empty() {
            return TrajectorySample {
                time_s,
                phase: SegmentPhase::ReturnHome,
                q: [0.0; NUM_JOINTS],
                dq: [0.0; NUM_JOINTS],
                ddq: [0.0; NUM_JOINTS],
            };
        }

        let clamped_t = time_s.clamp(0.0, self.total_duration_s);
        let seg = self
            .segments
            .iter()
            .find(|s| clamped_t <= s.t_start_s + s.duration_s + 1e-12)
            .unwrap_or_else(|| self.segments.last().expect("non-empty"));

        let dur = seg.duration_s.max(1e-6);
        let tau = ((clamped_t - seg.t_start_s) / dur).clamp(0.0, 1.0);
        let tau2 = tau * tau;
        let tau3 = tau2 * tau;
        let tau4 = tau3 * tau;
        let tau5 = tau4 * tau;

        let s = 10.0 * tau3 - 15.0 * tau4 + 6.0 * tau5;
        let ds_dtau = 30.0 * tau2 - 60.0 * tau3 + 30.0 * tau4;
        let d2s_dtau2 = 60.0 * tau - 180.0 * tau2 + 120.0 * tau3;

        let mut q = [0.0; NUM_JOINTS];
        let mut dq = [0.0; NUM_JOINTS];
        let mut ddq = [0.0; NUM_JOINTS];
        for i in 0..NUM_JOINTS {
            let delta = seg.q_end[i] - seg.q_start[i];
            q[i] = seg.q_start[i] + delta * s;
            dq[i] = delta * ds_dtau / dur;
            ddq[i] = delta * d2s_dtau2 / (dur * dur);
        }

        TrajectorySample {
            time_s: clamped_t,
            phase: seg.phase,
            q,
            dq,
            ddq,
        }
    }

    pub fn active_segment_index(&self, time_s: f64) -> usize {
        let clamped_t = time_s.clamp(0.0, self.total_duration_s);
        self.segments
            .iter()
            .position(|s| clamped_t <= s.t_start_s + s.duration_s + 1e-12)
            .unwrap_or_else(|| self.segments.len().saturating_sub(1))
    }
}

pub struct MotionPlanner;

impl MotionPlanner {
    pub fn home_configuration() -> [f64; NUM_JOINTS] {
        [0.0, 0.20, 1.05, 0.0, 0.32, 0.0]
    }

    fn compute_segment_duration(
        arm: &ArmModel,
        q0: &[f64; NUM_JOINTS],
        q1: &[f64; NUM_JOINTS],
        speed_scale: f64,
        min_duration_s: f64,
    ) -> f64 {
        let scale = speed_scale.clamp(0.1, 1.0);
        let mut t_req = min_duration_s;
        for i in 0..NUM_JOINTS {
            let dq = (q1[i] - q0[i]).abs();
            if dq < 1e-9 {
                continue;
            }
            let lim = &arm.desc.joints[i].limits;
            let t_v = 1.875 * dq / (lim.vel_max_rad_s * scale);
            let t_a = (5.7735027 * dq / (lim.acc_max_rad_s2 * scale)).sqrt();
            let t_j = (60.0 * dq / (lim.jerk_max_rad_s3 * scale)).cbrt();
            t_req = t_req.max(t_v).max(t_a).max(t_j);
        }
        t_req
    }

    pub fn validate_segment_dense(
        arm: &ArmModel,
        scene: &CollisionScene,
        name: &str,
        q0: &[f64; NUM_JOINTS],
        q1: &[f64; NUM_JOINTS],
        max_step_rad: f64,
        carried_object_radius_m: Option<f64>,
    ) -> Result<f64, PlannerError> {
        let max_delta = q0
            .iter()
            .zip(q1.iter())
            .map(|(a, b)| (b - a).abs())
            .fold(0.0_f64, f64::max);
        let steps = ((max_delta / max_step_rad).ceil() as usize).max(4);
        let mut min_clearance = f64::INFINITY;

        for k in 0..=steps {
            let alpha = (k as f64) / (steps as f64);
            let mut q = [0.0; NUM_JOINTS];
            for i in 0..NUM_JOINTS {
                q[i] = q0[i] + alpha * (q1[i] - q0[i]);
                let lim = &arm.desc.joints[i].limits;
                if q[i] < lim.pos_min_rad || q[i] > lim.pos_max_rad {
                    return Err(PlannerError::JointLimitAlongPath {
                        segment: name.to_string(),
                        alpha,
                        joint: i,
                    });
                }
            }
            let rep = CollisionChecker::check_configuration(
                arm,
                scene,
                &q,
                carried_object_radius_m,
                false,
            );
            if !rep.collision_free_under_model {
                return Err(PlannerError::CollisionDetected {
                    segment: name.to_string(),
                    alpha,
                    detail: rep.detail,
                });
            }
            if rep.min_clearance_m < min_clearance {
                min_clearance = rep.min_clearance_m;
            }
        }
        Ok(min_clearance)
    }

    pub fn plan_pick_and_place(
        arm: &ArmModel,
        scene: &CollisionScene,
        q_start: &[f64; NUM_JOINTS],
        workpiece: &WorkpieceSpec,
        speed_scale: f64,
    ) -> Result<PlannedTrajectory, PlannerError> {
        let start_col = CollisionChecker::check_configuration(arm, scene, q_start, None, false);
        if !start_col.collision_free_under_model {
            return Err(PlannerError::InvalidStart(start_col.detail));
        }

        let ik_opts = IkOptions::default();
        let approach_offset_z = 0.11;
        let transit_z = 0.34;

        let pick_p = workpiece.initial_pose.translation_m;
        let place_p = workpiece.target_place_pose.translation_m;

        let pre_pick = Pose3::from_translation_rpy(
            [pick_p[0], pick_p[1], pick_p[2] + approach_offset_z],
            std::f64::consts::PI,
            0.0,
            0.0,
        );
        let at_pick = Pose3::from_translation_rpy(
            [pick_p[0], pick_p[1], pick_p[2] + 0.004],
            std::f64::consts::PI,
            0.0,
            0.0,
        );
        let high_transit_pick = Pose3::from_translation_rpy(
            [pick_p[0], pick_p[1], transit_z],
            std::f64::consts::PI,
            0.0,
            0.0,
        );
        let high_transit_mid = Pose3::from_translation_rpy(
            [0.34, 0.0, transit_z + 0.04],
            std::f64::consts::PI,
            0.0,
            0.0,
        );
        let high_transit_place = Pose3::from_translation_rpy(
            [place_p[0], place_p[1], transit_z],
            std::f64::consts::PI,
            0.0,
            0.0,
        );
        let pre_place = Pose3::from_translation_rpy(
            [place_p[0], place_p[1], place_p[2] + approach_offset_z],
            std::f64::consts::PI,
            0.0,
            0.0,
        );
        let at_place = Pose3::from_translation_rpy(
            [place_p[0], place_p[1], place_p[2] + 0.006],
            std::f64::consts::PI,
            0.0,
            0.0,
        );

        let solve_wp = |name: &str, pose: &Pose3, seed: &[f64; NUM_JOINTS]| -> Result<[f64; NUM_JOINTS], PlannerError> {
            let sol = arm
                .inverse_kinematics_with_restarts(pose, seed, &ik_opts)
                .map_err(|source| PlannerError::IkFailed {
                    waypoint: name.to_string(),
                    source,
                })?;
            Ok(sol.q)
        };

        let q_pre_pick = solve_wp("pre_pick", &pre_pick, q_start)?;
        let q_at_pick = solve_wp("at_pick", &at_pick, &q_pre_pick)?;
        let q_lift_pick = solve_wp("lift_pick", &high_transit_pick, &q_at_pick)?;
        let q_transit_mid = solve_wp("transit_mid", &high_transit_mid, &q_lift_pick)?;
        let q_transit_place = solve_wp("transit_place", &high_transit_place, &q_transit_mid)?;
        let q_pre_place = solve_wp("pre_place", &pre_place, &q_transit_place)?;
        let q_at_place = solve_wp("at_place", &at_place, &q_pre_place)?;

        let carried_r = Some(
            workpiece
                .half_extents_m
                .iter()
                .copied()
                .fold(0.0_f64, f64::max),
        );

        let raw_segments = vec![
            ("approach_pick", SegmentPhase::ApproachPick, *q_start, q_pre_pick, 0.45, None, None),
            ("descend_pick", SegmentPhase::DescendPick, q_pre_pick, q_at_pick, 0.40, None, None),
            ("dwell_grasp", SegmentPhase::DwellCloseGripper, q_at_pick, q_at_pick, 0.25, Some(true), None),
            ("retreat_pick", SegmentPhase::RetreatPick, q_at_pick, q_lift_pick, 0.45, None, carried_r),
            ("transit_mid", SegmentPhase::TransitHigh, q_lift_pick, q_transit_mid, 0.50, None, carried_r),
            ("transit_place", SegmentPhase::TransitHigh, q_transit_mid, q_transit_place, 0.50, None, carried_r),
            ("approach_place", SegmentPhase::ApproachPlace, q_transit_place, q_pre_place, 0.45, None, carried_r),
            ("descend_place", SegmentPhase::DescendPlace, q_pre_place, q_at_place, 0.40, None, carried_r),
            ("dwell_release", SegmentPhase::DwellOpenGripper, q_at_place, q_at_place, 0.25, Some(false), None),
            ("retreat_place", SegmentPhase::RetreatPlace, q_at_place, q_pre_place, 0.40, None, None),
            ("return_home", SegmentPhase::ReturnHome, q_pre_place, *q_start, 0.60, None, None),
        ];

        let max_step_rad = 0.015;
        let mut segments = Vec::with_capacity(raw_segments.len());
        let mut t_cursor = 0.0;
        let mut min_model_clearance = f64::INFINITY;

        for (name, phase, qa, qb, min_dur, gripper_action, carried) in raw_segments {
            let clearance = Self::validate_segment_dense(
                arm,
                scene,
                name,
                &qa,
                &qb,
                max_step_rad,
                carried,
            )?;
            if clearance < min_model_clearance {
                min_model_clearance = clearance;
            }
            let dur = Self::compute_segment_duration(arm, &qa, &qb, speed_scale, min_dur);
            segments.push(QuinticSegment {
                name: name.to_string(),
                phase,
                q_start: qa,
                q_end: qb,
                t_start_s: t_cursor,
                duration_s: dur,
                gripper_close_after: gripper_action,
            });
            t_cursor += dur;
        }

        Ok(PlannedTrajectory {
            robot_config_hash: arm.desc.config_hash(),
            scene_hash: scene.scene_hash(),
            segments,
            total_duration_s: t_cursor,
            validation_step_rad: max_step_rad,
            min_model_clearance_m: min_model_clearance,
            collision_free_under_model: true,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn planned_pick_and_place_is_c2_continuous_and_collision_free() {
        let arm = ArmModel::default_6r_650();
        let scene = CollisionScene::default_workcell();
        let q_home = MotionPlanner::home_configuration();
        let wp = WorkpieceSpec {
            id: "block_01".to_string(),
            mass_kg: 0.45,
            half_extents_m: [0.022, 0.022, 0.022],
            initial_pose: Pose3::from_translation_rpy([0.36, -0.22, 0.082], 0.0, 0.0, 0.0),
            target_place_pose: Pose3::from_translation_rpy([0.34, 0.24, 0.072], 0.0, 0.0, 0.0),
        };

        let plan = MotionPlanner::plan_pick_and_place(&arm, &scene, &q_home, &wp, 0.85)
            .expect("Pick and place planning should succeed");
        assert!(plan.collision_free_under_model);
        assert!(plan.min_model_clearance_m > 0.008);

        let dt = 0.01;
        let mut prev = plan.sample(0.0);
        let mut t = dt;
        while t <= plan.total_duration_s {
            let cur = plan.sample(t);
            for j in 0..NUM_JOINTS {
                let lim = &arm.desc.joints[j].limits;
                assert!(cur.q[j] >= lim.pos_min_rad && cur.q[j] <= lim.pos_max_rad);
                assert!(cur.dq[j].abs() <= lim.vel_max_rad_s + 1e-4);
                assert!(cur.ddq[j].abs() <= lim.acc_max_rad_s2 + 1e-3);
                assert!((cur.q[j] - prev.q[j]).abs() < 0.05);
            }
            prev = cur;
            t += dt;
        }
    }

    #[test]
    fn dense_segment_check_catches_mid_segment_obstacle_even_when_endpoints_are_clear() {
        let arm = ArmModel::default_6r_650();
        let mut scene = CollisionScene::default_workcell();
        scene.obstacles.push(BoxObstacle {
            id: "mid_blocker".to_string(),
            center_m: [0.38, 0.0, 0.25],
            half_extents_m: [0.08, 0.05, 0.25],
        });
        let q_left = [-0.85, 0.15, 0.90, 0.0, 0.32, 0.0];
        let q_right = [0.85, 0.15, 0.90, 0.0, 0.32, 0.0];
        assert!(CollisionChecker::check_configuration(&arm, &scene, &q_left, None, false).collision_free_under_model);
        assert!(CollisionChecker::check_configuration(&arm, &scene, &q_right, None, false).collision_free_under_model);

        let res = MotionPlanner::validate_segment_dense(&arm, &scene, "sweep", &q_left, &q_right, 0.015, None);
        assert!(matches!(res, Err(PlannerError::CollisionDetected { .. })));
    }

    #[test]
    fn plan_is_invalidated_when_scene_changes() {
        let arm = ArmModel::default_6r_650();
        let mut scene = CollisionScene::default_workcell();
        let q_home = MotionPlanner::home_configuration();
        let wp = WorkpieceSpec {
            id: "block_01".to_string(),
            mass_kg: 0.45,
            half_extents_m: [0.022, 0.022, 0.022],
            initial_pose: Pose3::from_translation_rpy([0.36, -0.22, 0.082], 0.0, 0.0, 0.0),
            target_place_pose: Pose3::from_translation_rpy([0.34, 0.24, 0.072], 0.0, 0.0, 0.0),
        };
        let plan = MotionPlanner::plan_pick_and_place(&arm, &scene, &q_home, &wp, 0.85).unwrap();
        assert!(plan.validate_freshness(&arm, &scene).is_ok());

        scene.obstacles.push(BoxObstacle {
            id: "new_obst".to_string(),
            center_m: [0.1, 0.1, 0.1],
            half_extents_m: [0.02, 0.02, 0.02],
        });
        assert!(matches!(plan.validate_freshness(&arm, &scene), Err(PlannerError::PlanInvalidated(_))));
    }
}
