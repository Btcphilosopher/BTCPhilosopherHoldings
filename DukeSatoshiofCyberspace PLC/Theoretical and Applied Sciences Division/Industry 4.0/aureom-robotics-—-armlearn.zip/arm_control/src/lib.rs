use std::path::Path;

use arm_model::ArmModel;
use arm_types::{
    clamp_vec6, ActuatorCommand, JointState, LearnedResidualModelArtefact, PayloadSpec,
    ResidualTargetKind, NUM_JOINTS, SCHEMA_MODEL_V1,
};
use serde::{Deserialize, Serialize};
use thiserror::Error;

pub const EXPECTED_FEATURE_COUNT: usize = 30;

pub fn canonical_feature_names() -> Vec<String> {
    let mut names = Vec::with_capacity(EXPECTED_FEATURE_COUNT);
    for j in 0..NUM_JOINTS {
        names.push(format!("q_{j}"));
    }
    for j in 0..NUM_JOINTS {
        names.push(format!("dq_{j}"));
    }
    for j in 0..NUM_JOINTS {
        names.push(format!("tanh_dq_{j}"));
    }
    names.push("payload_est_kg".to_string());
    names.push("cos_q2".to_string());
    names.push("sin_q2_q3".to_string());
    names.push("payload_x_cos_q2".to_string());
    names.push("payload_x_sin_q2_q3".to_string());
    names.push("motor_temp_delta_c".to_string());
    for j in 0..NUM_JOINTS {
        names.push(format!("prev_err_{j}"));
    }
    names
}

pub fn build_feature_vector(
    q: &[f64; NUM_JOINTS],
    dq: &[f64; NUM_JOINTS],
    payload_est_kg: f64,
    motor_temp_c: f64,
    prev_err_q: &[f64; NUM_JOINTS],
) -> [f64; EXPECTED_FEATURE_COUNT] {
    let mut x = [0.0_f64; EXPECTED_FEATURE_COUNT];
    for j in 0..NUM_JOINTS {
        x[j] = q[j];
        x[NUM_JOINTS + j] = dq[j];
        x[2 * NUM_JOINTS + j] = (dq[j] / 0.05).tanh();
        x[24 + j] = prev_err_q[j];
    }
    let cos_q2 = q[1].cos();
    let sin_q2_q3 = (q[1] + q[2]).sin();
    x[18] = payload_est_kg;
    x[19] = cos_q2;
    x[20] = sin_q2_q3;
    x[21] = payload_est_kg * cos_q2;
    x[22] = payload_est_kg * sin_q2_q3;
    x[23] = motor_temp_c - 35.0;
    x
}

#[derive(Debug, Error)]
pub enum ModelLoadError {
    #[error("Failed to read model file: {0}")]
    Io(#[from] std::io::Error),
    #[error("Failed to parse model JSON: {0}")]
    Json(#[from] serde_json::Error),
    #[error("Model validation error: {0}")]
    Validation(String),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum FallbackPolicy {
    DeterministicBaseline,
    ControlledStop,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct InferenceOutcome {
    pub correction_rad: [f64; NUM_JOINTS],
    pub raw_prediction_rad: [f64; NUM_JOINTS],
    pub fallback_active: bool,
    pub request_stop: bool,
    pub reason: Option<String>,
}

#[derive(Debug, Clone)]
pub struct ResidualInferenceEngine {
    pub artefact: LearnedResidualModelArtefact,
    pub policy: FallbackPolicy,
}

impl ResidualInferenceEngine {
    pub fn load_and_validate(
        path: &Path,
        policy: FallbackPolicy,
    ) -> Result<Self, ModelLoadError> {
        let content = std::fs::read_to_string(path)?;
        let artefact: LearnedResidualModelArtefact = serde_json::from_str(&content)?;
        Self::from_validated(artefact, policy)
    }

    pub fn from_validated(
        artefact: LearnedResidualModelArtefact,
        policy: FallbackPolicy,
    ) -> Result<Self, ModelLoadError> {
        if artefact.schema_version != SCHEMA_MODEL_V1 {
            return Err(ModelLoadError::Validation(format!(
                "Schema mismatch: got '{}', expected '{}'",
                artefact.schema_version, SCHEMA_MODEL_V1
            )));
        }
        if artefact.target_kind != ResidualTargetKind::JointPositionResidualRad {
            return Err(ModelLoadError::Validation(
                "Unsupported residual target kind".to_string(),
            ));
        }
        if artefact.output_units != "rad" {
            return Err(ModelLoadError::Validation(format!(
                "Output units must be 'rad', got '{}'",
                artefact.output_units
            )));
        }
        let expected_names = canonical_feature_names();
        if artefact.feature_names != expected_names {
            return Err(ModelLoadError::Validation(
                "Feature names/order mismatch against canonical 30-feature contract".to_string(),
            ));
        }
        if artefact.normalization.mean.len() != EXPECTED_FEATURE_COUNT
            || artefact.normalization.std.len() != EXPECTED_FEATURE_COUNT
        {
            return Err(ModelLoadError::Validation(
                "Normalization vector dimensions do not match feature count".to_string(),
            ));
        }
        if artefact.normalization.mean.iter().any(|v| !v.is_finite())
            || artefact.normalization.std.iter().any(|v| !v.is_finite() || *v <= 1e-12)
        {
            return Err(ModelLoadError::Validation(
                "Invalid non-finite or non-positive normalization stats".to_string(),
            ));
        }
        if artefact.weights.len() != NUM_JOINTS
            || artefact
                .weights
                .iter()
                .any(|row| row.len() != EXPECTED_FEATURE_COUNT || row.iter().any(|v| !v.is_finite()))
        {
            return Err(ModelLoadError::Validation(
                "Weight matrix dimensions or values invalid".to_string(),
            ));
        }
        if artefact.intercepts.iter().any(|v| !v.is_finite())
            || artefact
                .max_correction_rad
                .iter()
                .any(|v| !v.is_finite() || *v <= 0.0 || *v > 0.12)
        {
            return Err(ModelLoadError::Validation(
                "Invalid intercepts or correction bounds".to_string(),
            ));
        }
        let expected_hash = artefact.compute_integrity_sha256();
        if artefact.integrity_sha256 != expected_hash {
            return Err(ModelLoadError::Validation(format!(
                "SHA-256 integrity check failed: expected {}, got {}",
                expected_hash, artefact.integrity_sha256
            )));
        }
        Ok(Self { artefact, policy })
    }

    pub fn predict_bounded(
        &self,
        q: &[f64; NUM_JOINTS],
        dq: &[f64; NUM_JOINTS],
        payload_est_kg: f64,
        motor_temp_c: f64,
        prev_err_q: &[f64; NUM_JOINTS],
    ) -> InferenceOutcome {
        let fallback = |reason: String| -> InferenceOutcome {
            InferenceOutcome {
                correction_rad: [0.0; NUM_JOINTS],
                raw_prediction_rad: [0.0; NUM_JOINTS],
                fallback_active: true,
                request_stop: self.policy == FallbackPolicy::ControlledStop,
                reason: Some(reason),
            }
        };

        if q.iter().any(|v| !v.is_finite())
            || dq.iter().any(|v| !v.is_finite())
            || prev_err_q.iter().any(|v| !v.is_finite())
            || !payload_est_kg.is_finite()
            || !motor_temp_c.is_finite()
        {
            return fallback("Non-finite input feature".to_string());
        }

        let dom = &self.artefact.operating_domain;
        for j in 0..NUM_JOINTS {
            if q[j] < dom.q_min_rad[j] || q[j] > dom.q_max_rad[j] {
                return fallback(format!("Joint {j} position {:.3} rad out of model domain", q[j]));
            }
            if dq[j].abs() > dom.dq_abs_max_rad_s[j] {
                return fallback(format!("Joint {j} velocity {:.3} rad/s out of model domain", dq[j]));
            }
            if prev_err_q[j].abs() > dom.max_recent_err_rad {
                return fallback(format!(
                    "Joint {j} tracking error {:.4} rad exceeds model domain {:.4}",
                    prev_err_q[j], dom.max_recent_err_rad
                ));
            }
        }
        if payload_est_kg < dom.payload_min_kg || payload_est_kg > dom.payload_max_kg {
            return fallback(format!(
                "Payload {:.3} kg out of model domain [{:.2}, {:.2}]",
                payload_est_kg, dom.payload_min_kg, dom.payload_max_kg
            ));
        }
        if motor_temp_c < dom.temp_min_c || motor_temp_c > dom.temp_max_c {
            return fallback(format!("Temperature {:.1} C out of model domain", motor_temp_c));
        }

        let x = build_feature_vector(q, dq, payload_est_kg, motor_temp_c, prev_err_q);
        let mut raw = [0.0_f64; NUM_JOINTS];
        let mut bounded = [0.0_f64; NUM_JOINTS];

        for j in 0..NUM_JOINTS {
            let mut acc = self.artefact.intercepts[j];
            for k in 0..EXPECTED_FEATURE_COUNT {
                let z = (x[k] - self.artefact.normalization.mean[k])
                    / self.artefact.normalization.std[k];
                acc += self.artefact.weights[j][k] * z;
            }
            if !acc.is_finite() {
                return fallback(format!("Non-finite raw prediction for joint {j}"));
            }
            raw[j] = acc;
            let bound = self.artefact.max_correction_rad[j];
            bounded[j] = acc.clamp(-bound, bound);
        }

        InferenceOutcome {
            correction_rad: bounded,
            raw_prediction_rad: raw,
            fallback_active: false,
            request_stop: false,
            reason: None,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BaselineControllerConfig {
    pub kp: [f64; NUM_JOINTS],
    pub ki: [f64; NUM_JOINTS],
    pub kd: [f64; NUM_JOINTS],
    pub integral_limit_rad: [f64; NUM_JOINTS],
    pub cmd_offset_limit_rad: [f64; NUM_JOINTS],
    pub ref_filter_alpha: f64,
    pub velocity_ff_gain: f64,
    pub gravity_comp_gain_rad_per_nm: [f64; NUM_JOINTS],
    pub ml_blend_gain: f64,
}

impl Default for BaselineControllerConfig {
    fn default() -> Self {
        Self {
            kp: [0.45, 0.55, 0.50, 0.40, 0.42, 0.35],
            ki: [1.10, 1.35, 1.25, 0.90, 0.95, 0.80],
            kd: [0.015, 0.020, 0.018, 0.012, 0.012, 0.010],
            integral_limit_rad: [0.040, 0.055, 0.050, 0.035, 0.035, 0.030],
            cmd_offset_limit_rad: [0.08, 0.10, 0.09, 0.07, 0.07, 0.06],
            ref_filter_alpha: 0.65,
            velocity_ff_gain: 0.95,
            gravity_comp_gain_rad_per_nm: [0.0, 0.00012, 0.00014, 0.0, 0.00010, 0.0],
            ml_blend_gain: 0.90,
        }
    }
}

#[derive(Debug, Clone)]
pub struct ControlDiagnostics {
    pub pos_err_rad: [f64; NUM_JOINTS],
    pub vel_err_rad_s: [f64; NUM_JOINTS],
    pub integral_state: [f64; NUM_JOINTS],
    pub ml_correction_rad: [f64; NUM_JOINTS],
    pub ml_fallback_active: bool,
    pub ml_request_stop: bool,
    pub ml_fallback_reason: Option<String>,
    pub saturated_joints: [bool; NUM_JOINTS],
}

pub struct JointSpaceController {
    pub config: BaselineControllerConfig,
    integral: [f64; NUM_JOINTS],
    filtered_q_ref: Option<[f64; NUM_JOINTS]>,
    prev_err_q: [f64; NUM_JOINTS],
    seq: u64,
}

impl JointSpaceController {
    pub fn new(config: BaselineControllerConfig) -> Self {
        Self {
            config,
            integral: [0.0; NUM_JOINTS],
            filtered_q_ref: None,
            prev_err_q: [0.0; NUM_JOINTS],
            seq: 0,
        }
    }

    pub fn reset(&mut self) {
        self.integral = [0.0; NUM_JOINTS];
        self.filtered_q_ref = None;
        self.prev_err_q = [0.0; NUM_JOINTS];
    }

    pub fn step_position_command(
        &mut self,
        arm: &ArmModel,
        q_ref_raw: &[f64; NUM_JOINTS],
        dq_ref: &[f64; NUM_JOINTS],
        measured: &JointState,
        payload_est: &PayloadSpec,
        dt_s: f64,
        ml_engine: Option<&ResidualInferenceEngine>,
    ) -> (ActuatorCommand, ControlDiagnostics) {
        let alpha = self.config.ref_filter_alpha.clamp(0.05, 1.0);
        let q_ref = match self.filtered_q_ref {
            Some(prev) => {
                let mut f = [0.0; NUM_JOINTS];
                for j in 0..NUM_JOINTS {
                    f[j] = prev[j] + alpha * (q_ref_raw[j] - prev[j]);
                }
                f
            }
            None => *q_ref_raw,
        };
        self.filtered_q_ref = Some(q_ref);

        let g_nom = arm.gravity_torques(&measured.q, payload_est);
        let mut pos_err = [0.0; NUM_JOINTS];
        let mut vel_err = [0.0; NUM_JOINTS];
        let mut saturated = [false; NUM_JOINTS];
        let mut q_cmd = [0.0; NUM_JOINTS];

        let mut ml_corr = [0.0; NUM_JOINTS];
        let mut ml_fallback = false;
        let mut ml_stop = false;
        let mut ml_reason = None;

        if let Some(engine) = ml_engine {
            let temp_c = measured
                .motor_temp_c
                .map(|t| t.iter().sum::<f64>() / (NUM_JOINTS as f64))
                .unwrap_or(38.0);
            let outcome = engine.predict_bounded(
                &measured.q,
                &measured.dq,
                payload_est.mass_kg,
                temp_c,
                &self.prev_err_q,
            );
            ml_corr = outcome.correction_rad;
            ml_fallback = outcome.fallback_active;
            ml_stop = outcome.request_stop;
            ml_reason = outcome.reason;
        }

        for j in 0..NUM_JOINTS {
            let e = q_ref[j] - measured.q[j];
            let de = dq_ref[j] - measured.dq[j];
            pos_err[j] = e;
            vel_err[j] = de;

            let cand_i = (self.integral[j] + e * dt_s).clamp(
                -self.config.integral_limit_rad[j],
                self.config.integral_limit_rad[j],
            );

            let ff_grav = self.config.gravity_comp_gain_rad_per_nm[j] * g_nom[j];
            let ml_term = self.config.ml_blend_gain * ml_corr[j];
            let raw_offset = self.config.kp[j] * e
                + self.config.ki[j] * cand_i
                + self.config.kd[j] * de
                + ff_grav
                + ml_term;

            let lim_off = self.config.cmd_offset_limit_rad[j];
            let clamped_offset = raw_offset.clamp(-lim_off, lim_off);
            if (raw_offset - clamped_offset).abs() > 1e-12 {
                saturated[j] = true;
                if (raw_offset > lim_off && e < 0.0) || (raw_offset < -lim_off && e > 0.0) {
                    self.integral[j] = cand_i;
                }
            } else {
                self.integral[j] = cand_i;
            }

            q_cmd[j] = q_ref[j] + clamped_offset;
        }

        let min_lims = arm.desc.joints.each_ref().map(|j| j.limits.pos_min_rad);
        let max_lims = arm.desc.joints.each_ref().map(|j| j.limits.pos_max_rad);
        q_cmd = clamp_vec6(q_cmd, min_lims, max_lims);

        self.prev_err_q = pos_err;
        self.seq += 1;

        let mut dq_ff = [0.0; NUM_JOINTS];
        for j in 0..NUM_JOINTS {
            dq_ff[j] = dq_ref[j] * self.config.velocity_ff_gain;
        }

        let cmd = ActuatorCommand::PositionTarget {
            q_rad: q_cmd,
            dq_ff_rad_s: dq_ff,
            timestamp_ns: measured.timestamp_ns,
            seq: self.seq,
        };

        let diag = ControlDiagnostics {
            pos_err_rad: pos_err,
            vel_err_rad_s: vel_err,
            integral_state: self.integral,
            ml_correction_rad: ml_corr,
            ml_fallback_active: ml_fallback,
            ml_request_stop: ml_stop,
            ml_fallback_reason: ml_reason,
            saturated_joints: saturated,
        };

        (cmd, diag)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use arm_types::{NormalizationStats, OperatingDomain};

    fn dummy_artefact() -> LearnedResidualModelArtefact {
        let names = canonical_feature_names();
        let mut art = LearnedResidualModelArtefact {
            schema_version: SCHEMA_MODEL_V1.to_string(),
            model_id: "test_ridge".to_string(),
            model_version: "1.0.0".to_string(),
            created_at_utc: "2026-11-18T00:00:00Z".to_string(),
            r_version: "4.2.2".to_string(),
            target_kind: ResidualTargetKind::JointPositionResidualRad,
            output_units: "rad".to_string(),
            feature_names: names,
            normalization: NormalizationStats {
                mean: vec![0.0; EXPECTED_FEATURE_COUNT],
                std: vec![1.0; EXPECTED_FEATURE_COUNT],
            },
            intercepts: [0.002, 0.005, -0.004, 0.0, 0.001, 0.0],
            weights: vec![vec![0.0; EXPECTED_FEATURE_COUNT]; NUM_JOINTS],
            max_correction_rad: [0.03; NUM_JOINTS],
            operating_domain: OperatingDomain {
                q_min_rad: [-2.8; NUM_JOINTS],
                q_max_rad: [2.8; NUM_JOINTS],
                dq_abs_max_rad_s: [3.5; NUM_JOINTS],
                payload_min_kg: 0.0,
                payload_max_kg: 1.5,
                max_recent_err_rad: 0.15,
                temp_min_c: 15.0,
                temp_max_c: 85.0,
            },
            training_run_ids: vec!["run_01".to_string()],
            validation_rmse_rad: [0.001; NUM_JOINTS],
            integrity_sha256: String::new(),
        };
        art.weights[1][19] = 0.04;
        art.integrity_sha256 = art.compute_integrity_sha256();
        art
    }

    #[test]
    fn rejects_tampered_integrity_hash() {
        let mut art = dummy_artefact();
        art.intercepts[0] += 0.001;
        let res = ResidualInferenceEngine::from_validated(art, FallbackPolicy::DeterministicBaseline);
        assert!(matches!(res, Err(ModelLoadError::Validation(_))));
    }

    #[test]
    fn clamps_prediction_and_triggers_fallback_on_out_of_domain_or_nan() {
        let art = dummy_artefact();
        let engine = ResidualInferenceEngine::from_validated(art, FallbackPolicy::ControlledStop).unwrap();

        let out = engine.predict_bounded(&[0.0; 6], &[0.0; 6], 0.5, 40.0, &[0.0; 6]);
        assert!(!out.fallback_active);
        assert!((out.correction_rad[1] - 0.03).abs() < 1e-12);

        let ood = engine.predict_bounded(&[0.0; 6], &[0.0; 6], 3.0, 40.0, &[0.0; 6]);
        assert!(ood.fallback_active);
        assert!(ood.request_stop);
        assert_eq!(ood.correction_rad, [0.0; 6]);

        let nan_out = engine.predict_bounded(&[f64::NAN, 0.0, 0.0, 0.0, 0.0, 0.0], &[0.0; 6], 0.5, 40.0, &[0.0; 6]);
        assert!(nan_out.fallback_active);
        assert_eq!(nan_out.correction_rad, [0.0; 6]);
    }
}
