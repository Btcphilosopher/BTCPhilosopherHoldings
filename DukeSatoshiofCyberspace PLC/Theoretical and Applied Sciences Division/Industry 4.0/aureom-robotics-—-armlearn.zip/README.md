# AUREOM ROBOTICS — ArmLearn

Machine-learning-assisted control system for an industrial six-axis robotic arm (`Aureom-6R-650`), built with **Rust** for kinematics, planning, deterministic control, runtime supervision, and hardware/simulator adapters, and **R** for telemetry validation, system identification, regularized residual learning, uncertainty analysis, and held-out evaluation.

## Architecture (8 Separated Control & Safety Layers)

1. **Task Definition** (`arm_types`, `arm_cli`): Configurable `WorkpieceSpec`, `SimScenarioConfig`, pick-and-place task goals.
2. **Perception & Object Localisation** (`arm_sim`, `arm_types`): Explicit world/table/workpiece `Pose3` poses with Hamilton `[w, x, y, z]` child-to-parent transforms, sensor noise, and payload estimation distinct from ground truth.
3. **Motion Planning** (`arm_planner`): Numerical damped-least-squares IK with singularity damping and restarts, capsule-capsule self-collision and capsule-AABB obstacle checks, dense joint-step path verification, and plan invalidation via config/scene SHA-256 hashes.
4. **Trajectory Generation** (`arm_planner`): Time-scaled C2-continuous quintic joint-space trajectories respecting velocity, acceleration, and jerk bounds.
5. **Deterministic Feedback Control** (`arm_control`): Joint-space PID with conditional anti-windup, low-pass reference filtering, velocity feedforward, nominal gravity compensation, and per-joint command offset bounds.
6. **Optional Learned Correction** (`arm_control`, `r_armlearn/`): Bounded Elastic-Net residual model (`armlearn.model.v1`, 30 canonical features, output in `rad`) trained in R (`glmnet`) with run-grouped CV, verified with canonical SHA-256 hash and exact R-to-Rust numerical parity (`< 1e-9 rad`), and explicit domain/NaN fallback (`DeterministicBaseline` or `ControlledStop`).
7. **Independent Runtime Constraints & Supervision** (`arm_runtime`): Explicit state machine (`Disconnected -> Initialising -> Ready -> Armed -> Executing -> Paused -> Stopping -> Fault`) preventing auto-motion after fault/restart, independent telemetry age/limit/workspace/command-step checks, bounded non-blocking telemetry channel, and cycle-timing overrun monitor.
8. **Hardware Interface & Telemetry** (`arm_adapters`): `RobotAdapter` trait with `SimulatorAdapter`, `MockHardwareAdapter`, and commissioning-gated `PhysicalHardwareAdapter` (which never fabricates hardware connections and explicitly states that physical E-stop relies on external certified safety relays).

## Workspace Layout

```text
arm_types/        # SI conventions, Pose3, versioned schemas, canonical SHA-256 hashing
arm_model/        # Aureom-6R-650 model, FK, geometric Jacobian, damped IK, dynamics
arm_planner/      # Collision scene, dense capsule/AABB checks, quintic trajectory planner
arm_control/      # Baseline PID+FF controller & bounded ML residual inference engine
arm_sim/          # Deterministic RK4 simulator with delay, noise, friction, compliance, grasp rules
arm_adapters/     # RobotAdapter trait, SimulatorAdapter, MockHardwareAdapter, PhysicalHardwareAdapter
arm_runtime/      # Independent constraint checker, state machine, bounded telemetry, timing monitor
arm_cli/          # CLI runner: generate-data, verify-parity, evaluate, inspect-model, demo
r_armlearn/       # R project (data_validation, system_identification, model_training, uncertainty, evaluation, experiments, tests)
configs/          # Generated aureom_6r_650.json configuration
artifacts/        # Generated datasets, R reports, residual_model.v1.json, demo_summary.json
src/              # Angular 21 SSR + Express console inspecting real generated artifacts
```

## Pinned Dependencies

- **Rust (`Cargo.toml` & `Cargo.lock`)**: `nalgebra 0.33.2`, `serde 1.0.219`, `serde_json 1.0.140`, `thiserror 2.0.12`, `rand 0.8.5`, `rand_chacha 0.3.1`, `sha2 0.10.8`, `clap 4.5.32`, `csv 1.3.1`, `approx 0.5.1`.
- **R (`r_armlearn/r_packages_lock.json`)**: `R 4.2.2`, `jsonlite 1.8.4`, `glmnet 4.1-6`, `MASS 7.3-58.2`, `digest 0.6.31`, `testthat 3.1.6`.

## Reproducible Commands

```bash
# 1. Run Rust unit & integration tests (single build job for low-memory containers)
CARGO_BUILD_JOBS=1 cargo test --workspace -j 1

# 2. Run R testthat suite
Rscript -e "res <- testthat::test_file('r_armlearn/tests/test_armlearn.R'); df <- as.data.frame(res); if (any(df\$failed > 0 | df\$error)) quit(status=1)"

# 3. Run full 12-step demonstration pipeline (Rust data gen -> R sys-id & training -> parity -> held-out eval -> fault demos)
CARGO_BUILD_JOBS=1 cargo run -j 1 -p arm_cli -- demo --out-dir artifacts

# 4. Run Angular SSR + Express inspection UI (port 3000)
npm run build && npm run start
```

## Limitations & Safety Disclaimer

- Inertial parameters in `Aureom-6R-650` carry `InertialProvenance::IllustrativeEstimated` and are not CAD-verified for a physical robot.
- All results are generated from the `ArmSimulator` plant model; no physical robot hardware or fieldbus driver is connected in this build.
- Collision checks verify geometric capsule/AABB clearance under the kinematic model, not physical cell clearance.
- Software runtime stops and state-machine interlocks do not replace certified hardware emergency-stop circuits (ISO 13849 / IEC 62061).
