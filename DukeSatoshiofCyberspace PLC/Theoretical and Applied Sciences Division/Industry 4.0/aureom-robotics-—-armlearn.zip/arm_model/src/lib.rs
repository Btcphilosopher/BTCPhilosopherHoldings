use std::f64::consts::PI;
use std::path::Path;

use arm_types::{
    CommandMode, InertialParams, InertialProvenance, JointFrictionParams, JointLimits, JointSpec,
    JointType, LinkGeometry, PayloadSpec, Pose3, RobotDescription, WorkspaceBounds, NUM_JOINTS,
    SCHEMA_CONFIG_V1,
};
use nalgebra::{Isometry3, Matrix6, UnitQuaternion, Vector3, Vector6};
use thiserror::Error;

#[derive(Debug, Error)]
pub enum ModelError {
    #[error("I/O error loading robot description: {0}")]
    Io(#[from] std::io::Error),
    #[error("JSON parse error in robot description: {0}")]
    Json(#[from] serde_json::Error),
    #[error("Invalid robot description: {0}")]
    Validation(String),
}

#[derive(Debug, Error, Clone, PartialEq)]
pub enum IkError {
    #[error("Target pose is invalid or contains non-finite values")]
    InvalidInput,
    #[error("Target position is outside kinematic reach ({distance_m:.3} m > max reach {max_reach_m:.3} m)")]
    TargetOutOfReach { distance_m: f64, max_reach_m: f64 },
    #[error("IK failed to converge within {max_iters} iterations (pos_err={pos_err_m:.4} m, ori_err={ori_err_rad:.4} rad)")]
    MaxIterationsExceeded {
        max_iters: usize,
        pos_err_m: f64,
        ori_err_rad: f64,
    },
    #[error("IK stalled near singularity or joint limits (pos_err={pos_err_m:.4} m, ori_err={ori_err_rad:.4} rad)")]
    JointLimitsOrSingularityStall { pos_err_m: f64, ori_err_rad: f64 },
}

#[derive(Debug, Clone)]
pub struct KinematicsSolution {
    pub link_frames_world: [Isometry3<f64>; NUM_JOINTS],
    pub joint_origins_world: [Vector3<f64>; NUM_JOINTS],
    pub joint_axes_world: [Vector3<f64>; NUM_JOINTS],
    pub flange_world: Pose3,
    pub tcp_world: Pose3,
}

#[derive(Debug, Clone)]
pub struct SingularityReport {
    pub sigma_min: f64,
    pub sigma_max: f64,
    pub condition_number: f64,
    pub manipulability: f64,
    pub near_singular: bool,
    pub wrist_singular: bool,
    pub elbow_singular: bool,
}

#[derive(Debug, Clone)]
pub struct IkOptions {
    pub max_iters: usize,
    pub pos_tol_m: f64,
    pub ori_tol_rad: f64,
    pub base_damping: f64,
    pub max_step_rad: f64,
}

impl Default for IkOptions {
    fn default() -> Self {
        Self {
            max_iters: 180,
            pos_tol_m: 1e-4,
            ori_tol_rad: 2e-4,
            base_damping: 1e-3,
            max_step_rad: 0.25,
        }
    }
}

#[derive(Debug, Clone)]
pub struct IkSolution {
    pub q: [f64; NUM_JOINTS],
    pub iterations: usize,
    pub pos_err_m: f64,
    pub ori_err_rad: f64,
    pub sigma_min: f64,
}

#[derive(Debug, Clone)]
pub struct ArmModel {
    pub desc: RobotDescription,
}

impl ArmModel {
    pub fn from_description(desc: RobotDescription) -> Result<Self, ModelError> {
        validate_robot_description(&desc)?;
        Ok(Self { desc })
    }

    pub fn load_json(path: &Path) -> Result<Self, ModelError> {
        let content = std::fs::read_to_string(path)?;
        let desc: RobotDescription = serde_json::from_str(&content)?;
        Self::from_description(desc)
    }

    pub fn save_json(&self, path: &Path) -> Result<(), ModelError> {
        let content = serde_json::to_string_pretty(&self.desc)?;
        std::fs::write(path, content)?;
        Ok(())
    }

    pub fn default_6r_650() -> Self {
        let base_in_world = Pose3::from_translation_rpy([0.0, 0.0, 0.02], 0.0, 0.0, 0.0);
        let joints = [
            JointSpec {
                name: "j1_shoulder_yaw".to_string(),
                joint_type: JointType::Revolute,
                origin_in_parent: Pose3::from_translation_rpy([0.0, 0.0, 0.14], 0.0, 0.0, 0.0),
                axis_local: [0.0, 0.0, 1.0],
                limits: JointLimits {
                    pos_min_rad: -2.967,
                    pos_max_rad: 2.967,
                    vel_max_rad_s: 2.8,
                    acc_max_rad_s2: 12.0,
                    jerk_max_rad_s3: 80.0,
                    torque_max_nm: 90.0,
                },
                inertial: InertialParams {
                    mass_kg: 4.2,
                    com_m: [0.0, 0.0, 0.05],
                    inertia_diag_kgm2: [0.035, 0.035, 0.028],
                    provenance: InertialProvenance::IllustrativeEstimated,
                },
                link_geometry: LinkGeometry::Capsule {
                    p1_m: [0.0, 0.0, -0.10],
                    p2_m: [0.0, 0.0, 0.08],
                    radius_m: 0.065,
                },
                nominal_friction: JointFrictionParams {
                    coulomb_nm: 1.4,
                    viscous_nms_rad: 0.35,
                    compliance_rad_per_nm: 0.00018,
                },
            },
            JointSpec {
                name: "j2_shoulder_pitch".to_string(),
                joint_type: JointType::Revolute,
                origin_in_parent: Pose3::from_translation_rpy([0.04, 0.0, 0.08], 0.0, 0.0, 0.0),
                axis_local: [0.0, 1.0, 0.0],
                limits: JointLimits {
                    pos_min_rad: -1.75,
                    pos_max_rad: 2.15,
                    vel_max_rad_s: 2.5,
                    acc_max_rad_s2: 10.0,
                    jerk_max_rad_s3: 70.0,
                    torque_max_nm: 110.0,
                },
                inertial: InertialParams {
                    mass_kg: 5.1,
                    com_m: [0.0, 0.0, 0.16],
                    inertia_diag_kgm2: [0.085, 0.082, 0.022],
                    provenance: InertialProvenance::IllustrativeEstimated,
                },
                link_geometry: LinkGeometry::Capsule {
                    p1_m: [0.0, 0.0, 0.0],
                    p2_m: [0.0, 0.0, 0.32],
                    radius_m: 0.052,
                },
                nominal_friction: JointFrictionParams {
                    coulomb_nm: 2.1,
                    viscous_nms_rad: 0.50,
                    compliance_rad_per_nm: 0.00024,
                },
            },
            JointSpec {
                name: "j3_elbow_pitch".to_string(),
                joint_type: JointType::Revolute,
                origin_in_parent: Pose3::from_translation_rpy([0.0, 0.0, 0.32], 0.0, 0.0, 0.0),
                axis_local: [0.0, 1.0, 0.0],
                limits: JointLimits {
                    pos_min_rad: -2.35,
                    pos_max_rad: 2.35,
                    vel_max_rad_s: 3.0,
                    acc_max_rad_s2: 14.0,
                    jerk_max_rad_s3: 90.0,
                    torque_max_nm: 65.0,
                },
                inertial: InertialParams {
                    mass_kg: 3.1,
                    com_m: [0.14, 0.0, 0.02],
                    inertia_diag_kgm2: [0.015, 0.048, 0.046],
                    provenance: InertialProvenance::IllustrativeEstimated,
                },
                link_geometry: LinkGeometry::Capsule {
                    p1_m: [0.0, 0.0, 0.0],
                    p2_m: [0.28, 0.0, 0.0],
                    radius_m: 0.042,
                },
                nominal_friction: JointFrictionParams {
                    coulomb_nm: 1.5,
                    viscous_nms_rad: 0.32,
                    compliance_rad_per_nm: 0.00028,
                },
            },
            JointSpec {
                name: "j4_wrist_roll".to_string(),
                joint_type: JointType::Revolute,
                origin_in_parent: Pose3::from_translation_rpy([0.28, 0.0, 0.0], 0.0, 0.0, 0.0),
                axis_local: [1.0, 0.0, 0.0],
                limits: JointLimits {
                    pos_min_rad: -3.05,
                    pos_max_rad: 3.05,
                    vel_max_rad_s: 4.2,
                    acc_max_rad_s2: 18.0,
                    jerk_max_rad_s3: 120.0,
                    torque_max_nm: 28.0,
                },
                inertial: InertialParams {
                    mass_kg: 1.4,
                    com_m: [0.04, 0.0, 0.0],
                    inertia_diag_kgm2: [0.004, 0.006, 0.006],
                    provenance: InertialProvenance::IllustrativeEstimated,
                },
                link_geometry: LinkGeometry::Capsule {
                    p1_m: [-0.02, 0.0, 0.0],
                    p2_m: [0.07, 0.0, 0.0],
                    radius_m: 0.032,
                },
                nominal_friction: JointFrictionParams {
                    coulomb_nm: 0.55,
                    viscous_nms_rad: 0.12,
                    compliance_rad_per_nm: 0.00020,
                },
            },
            JointSpec {
                name: "j5_wrist_pitch".to_string(),
                joint_type: JointType::Revolute,
                origin_in_parent: Pose3::from_translation_rpy([0.08, 0.0, 0.0], 0.0, 0.0, 0.0),
                axis_local: [0.0, 1.0, 0.0],
                limits: JointLimits {
                    pos_min_rad: -2.20,
                    pos_max_rad: 2.20,
                    vel_max_rad_s: 4.2,
                    acc_max_rad_s2: 18.0,
                    jerk_max_rad_s3: 120.0,
                    torque_max_nm: 24.0,
                },
                inertial: InertialParams {
                    mass_kg: 1.0,
                    com_m: [0.03, 0.0, 0.0],
                    inertia_diag_kgm2: [0.003, 0.004, 0.004],
                    provenance: InertialProvenance::IllustrativeEstimated,
                },
                link_geometry: LinkGeometry::Capsule {
                    p1_m: [0.0, 0.0, 0.0],
                    p2_m: [0.06, 0.0, 0.0],
                    radius_m: 0.028,
                },
                nominal_friction: JointFrictionParams {
                    coulomb_nm: 0.48,
                    viscous_nms_rad: 0.10,
                    compliance_rad_per_nm: 0.00022,
                },
            },
            JointSpec {
                name: "j6_flange_roll".to_string(),
                joint_type: JointType::Revolute,
                origin_in_parent: Pose3::from_translation_rpy([0.065, 0.0, 0.0], 0.0, 0.0, 0.0),
                axis_local: [1.0, 0.0, 0.0],
                limits: JointLimits {
                    pos_min_rad: -PI,
                    pos_max_rad: PI,
                    vel_max_rad_s: 5.5,
                    acc_max_rad_s2: 24.0,
                    jerk_max_rad_s3: 150.0,
                    torque_max_nm: 15.0,
                },
                inertial: InertialParams {
                    mass_kg: 0.75,
                    com_m: [0.04, 0.0, 0.0],
                    inertia_diag_kgm2: [0.002, 0.002, 0.002],
                    provenance: InertialProvenance::IllustrativeEstimated,
                },
                link_geometry: LinkGeometry::Capsule {
                    p1_m: [0.0, 0.0, 0.0],
                    p2_m: [0.05, 0.0, 0.0],
                    radius_m: 0.025,
                },
                nominal_friction: JointFrictionParams {
                    coulomb_nm: 0.25,
                    viscous_nms_rad: 0.06,
                    compliance_rad_per_nm: 0.00015,
                },
            },
        ];

        let tcp_in_flange = Pose3::from_translation_rpy([0.105, 0.0, 0.0], 0.0, PI / 2.0, 0.0);

        let desc = RobotDescription {
            schema_version: SCHEMA_CONFIG_V1.to_string(),
            model_name: "Aureom-6R-650".to_string(),
            units: "SI (m, kg, rad, s, N*m)".to_string(),
            quaternion_convention: "Hamilton [w, x, y, z], child-to-parent".to_string(),
            base_in_world,
            joints,
            tcp_in_flange,
            gripper_capsule_in_flange: LinkGeometry::Capsule {
                p1_m: [0.01, 0.0, 0.0],
                p2_m: [0.10, 0.0, 0.0],
                radius_m: 0.032,
            },
            nominal_payload: PayloadSpec::default(),
            workspace_bounds: WorkspaceBounds {
                min_m: [-0.72, -0.72, 0.015],
                max_m: [0.72, 0.72, 0.95],
                min_z_clearance_m: 0.012,
            },
            supported_commands: vec![CommandMode::Position],
        };
        Self { desc }
    }

    pub fn max_reach_m(&self) -> f64 {
        0.89
    }

    pub fn forward_kinematics(&self, q: &[f64; NUM_JOINTS]) -> KinematicsSolution {
        let mut current = self.desc.base_in_world.to_isometry();
        let mut link_frames_world = [Isometry3::identity(); NUM_JOINTS];
        let mut joint_origins_world = [Vector3::zeros(); NUM_JOINTS];
        let mut joint_axes_world = [Vector3::z(); NUM_JOINTS];

        for i in 0..NUM_JOINTS {
            let j = &self.desc.joints[i];
            let origin_iso = j.origin_in_parent.to_isometry();
            let joint_frame_before_rot = current * origin_iso;

            let axis_local = Vector3::from(j.axis_local).normalize();
            let axis_world = joint_frame_before_rot.rotation * axis_local;
            joint_origins_world[i] = joint_frame_before_rot.translation.vector;
            joint_axes_world[i] = axis_world;

            let rot = match j.joint_type {
                JointType::Revolute => UnitQuaternion::from_axis_angle(
                    &nalgebra::Unit::new_normalize(axis_local),
                    q[i],
                ),
                JointType::Fixed => UnitQuaternion::identity(),
            };
            current = joint_frame_before_rot * Isometry3::from_parts(Default::default(), rot);
            link_frames_world[i] = current;
        }

        let flange_world = Pose3::from_isometry(&current);
        let tcp_iso = current * self.desc.tcp_in_flange.to_isometry();
        let tcp_world = Pose3::from_isometry(&tcp_iso);

        KinematicsSolution {
            link_frames_world,
            joint_origins_world,
            joint_axes_world,
            flange_world,
            tcp_world,
        }
    }

    pub fn geometric_jacobian(&self, q: &[f64; NUM_JOINTS]) -> Matrix6<f64> {
        let fk = self.forward_kinematics(q);
        let p_tcp = Vector3::from(fk.tcp_world.translation_m);
        let mut jac = Matrix6::<f64>::zeros();

        for i in 0..NUM_JOINTS {
            if self.desc.joints[i].joint_type == JointType::Fixed {
                continue;
            }
            let z_i = fk.joint_axes_world[i];
            let p_i = fk.joint_origins_world[i];
            let v_i = z_i.cross(&(p_tcp - p_i));
            jac[(0, i)] = v_i.x;
            jac[(1, i)] = v_i.y;
            jac[(2, i)] = v_i.z;
            jac[(3, i)] = z_i.x;
            jac[(4, i)] = z_i.y;
            jac[(5, i)] = z_i.z;
        }
        jac
    }

    pub fn singularity_diagnostics(&self, q: &[f64; NUM_JOINTS]) -> SingularityReport {
        let jac = self.geometric_jacobian(q);
        let svd = jac.svd(false, false);
        let s = svd.singular_values;
        let sigma_max = s.iter().copied().fold(0.0_f64, f64::max);
        let sigma_min = s.iter().copied().fold(f64::INFINITY, f64::min);
        let condition_number = if sigma_min > 1e-9 {
            sigma_max / sigma_min
        } else {
            f64::INFINITY
        };
        let manipulability = s.iter().product();
        let wrist_singular = q[4].abs() < 0.06;
        let elbow_singular = q[2].abs() < 0.06;
        let near_singular = sigma_min < 0.025 || condition_number > 120.0;

        SingularityReport {
            sigma_min,
            sigma_max,
            condition_number,
            manipulability,
            near_singular,
            wrist_singular,
            elbow_singular,
        }
    }

    pub fn clamp_to_limits(&self, q: &[f64; NUM_JOINTS]) -> [f64; NUM_JOINTS] {
        let mut out = *q;
        for i in 0..NUM_JOINTS {
            out[i] = out[i].clamp(
                self.desc.joints[i].limits.pos_min_rad,
                self.desc.joints[i].limits.pos_max_rad,
            );
        }
        out
    }

    pub fn within_joint_limits(&self, q: &[f64; NUM_JOINTS], margin_rad: f64) -> bool {
        for i in 0..NUM_JOINTS {
            let lim = &self.desc.joints[i].limits;
            if !q[i].is_finite()
                || q[i] < lim.pos_min_rad - margin_rad
                || q[i] > lim.pos_max_rad + margin_rad
            {
                return false;
            }
        }
        true
    }

    pub fn inverse_kinematics(
        &self,
        target_tcp_world: &Pose3,
        q_seed: &[f64; NUM_JOINTS],
        opts: &IkOptions,
    ) -> Result<IkSolution, IkError> {
        if !target_tcp_world.is_valid() || q_seed.iter().any(|v| !v.is_finite()) {
            return Err(IkError::InvalidInput);
        }

        let shoulder_origin = Vector3::new(
            self.desc.base_in_world.translation_m[0],
            self.desc.base_in_world.translation_m[1],
            self.desc.base_in_world.translation_m[2] + 0.22,
        );
        let target_p = Vector3::from(target_tcp_world.translation_m);
        let dist = (target_p - shoulder_origin).norm();
        let max_r = self.max_reach_m();
        if dist > max_r + 0.02 {
            return Err(IkError::TargetOutOfReach {
                distance_m: dist,
                max_reach_m: max_r,
            });
        }

        let mut q = self.clamp_to_limits(q_seed);
        let eye6 = Matrix6::<f64>::identity();

        let mut last_pos_err = f64::INFINITY;
        let mut last_ori_err = f64::INFINITY;

        for iter in 0..opts.max_iters {
            let fk = self.forward_kinematics(&q);
            let err_arr = Pose3::pose_error_world(&fk.tcp_world, target_tcp_world);
            let pos_err = Vector3::new(err_arr[0], err_arr[1], err_arr[2]).norm();
            let ori_err = Vector3::new(err_arr[3], err_arr[4], err_arr[5]).norm();
            last_pos_err = pos_err;
            last_ori_err = ori_err;

            if pos_err <= opts.pos_tol_m && ori_err <= opts.ori_tol_rad {
                let sing = self.singularity_diagnostics(&q);
                return Ok(IkSolution {
                    q,
                    iterations: iter,
                    pos_err_m: pos_err,
                    ori_err_rad: ori_err,
                    sigma_min: sing.sigma_min,
                });
            }

            let jac = self.geometric_jacobian(&q);
            let err_vec = Vector6::from_row_slice(&err_arr);
            let sing = self.singularity_diagnostics(&q);
            let lambda = if sing.sigma_min < 0.05 {
                opts.base_damping + 0.08 * (1.0 - sing.sigma_min / 0.05)
            } else {
                opts.base_damping
            };

            let jjt = jac * jac.transpose() + (lambda * lambda) * eye6;
            let Some(sol) = jjt.lu().solve(&err_vec) else {
                return Err(IkError::JointLimitsOrSingularityStall {
                    pos_err_m: pos_err,
                    ori_err_rad: ori_err,
                });
            };

            let mut dq = jac.transpose() * sol;
            let dq_norm = dq.norm();
            if dq_norm > opts.max_step_rad {
                dq *= opts.max_step_rad / dq_norm;
            }
            if dq_norm < 1e-9 && (pos_err > opts.pos_tol_m || ori_err > opts.ori_tol_rad) {
                return Err(IkError::JointLimitsOrSingularityStall {
                    pos_err_m: pos_err,
                    ori_err_rad: ori_err,
                });
            }

            let err_cost = pos_err * pos_err + 0.25 * ori_err * ori_err;
            let mut alpha = 1.0;
            let mut accepted = false;
            for _ in 0..8 {
                let mut q_cand = q;
                for i in 0..NUM_JOINTS {
                    q_cand[i] += alpha * dq[i];
                }
                q_cand = self.clamp_to_limits(&q_cand);
                let fk_cand = self.forward_kinematics(&q_cand);
                let e_cand = Pose3::pose_error_world(&fk_cand.tcp_world, target_tcp_world);
                let p_c = Vector3::new(e_cand[0], e_cand[1], e_cand[2]).norm();
                let o_c = Vector3::new(e_cand[3], e_cand[4], e_cand[5]).norm();
                let cost_c = p_c * p_c + 0.25 * o_c * o_c;
                if cost_c < err_cost || alpha < 0.05 {
                    q = q_cand;
                    accepted = true;
                    break;
                }
                alpha *= 0.5;
            }
            if !accepted {
                return Err(IkError::JointLimitsOrSingularityStall {
                    pos_err_m: pos_err,
                    ori_err_rad: ori_err,
                });
            }
        }

        Err(IkError::MaxIterationsExceeded {
            max_iters: opts.max_iters,
            pos_err_m: last_pos_err,
            ori_err_rad: last_ori_err,
        })
    }

    pub fn inverse_kinematics_with_restarts(
        &self,
        target_tcp_world: &Pose3,
        q_seed: &[f64; NUM_JOINTS],
        opts: &IkOptions,
    ) -> Result<IkSolution, IkError> {
        if let Ok(sol) = self.inverse_kinematics(target_tcp_world, q_seed, opts) {
            return Ok(sol);
        }
        let target_yaw = target_tcp_world.translation_m[1]
            .atan2(target_tcp_world.translation_m[0]);
        let alternates = [
            [target_yaw, 0.35, 1.05, 0.0, 0.85, 0.0],
            [target_yaw, -0.35, 1.35, 0.0, 0.55, 0.0],
            [target_yaw, 0.65, 0.80, 0.0, 0.95, 0.0],
        ];
        let mut last_err = IkError::InvalidInput;
        for alt in &alternates {
            match self.inverse_kinematics(target_tcp_world, alt, opts) {
                Ok(sol) => return Ok(sol),
                Err(e) => last_err = e,
            }
        }
        Err(last_err)
    }

    pub fn gravity_torques(&self, q: &[f64; NUM_JOINTS], payload: &PayloadSpec) -> [f64; NUM_JOINTS] {
        let fk = self.forward_kinematics(q);
        let g_world = Vector3::new(0.0, 0.0, -9.80665);
        let mut tau_g = [0.0_f64; NUM_JOINTS];

        for k in 0..NUM_JOINTS {
            let mass = self.desc.joints[k].inertial.mass_kg;
            if mass <= 0.0 {
                continue;
            }
            let com_local = Vector3::from(self.desc.joints[k].inertial.com_m);
            let com_world = fk.link_frames_world[k].transform_point(&nalgebra::Point3::from(com_local)).coords;
            let force_world = mass * g_world;

            for i in 0..=k {
                if self.desc.joints[i].joint_type == JointType::Fixed {
                    continue;
                }
                let j_v = fk.joint_axes_world[i].cross(&(com_world - fk.joint_origins_world[i]));
                tau_g[i] -= j_v.dot(&force_world);
            }
        }

        if payload.mass_kg > 0.0 {
            let tcp_iso = fk.tcp_world.to_isometry();
            let payload_com_world = tcp_iso
                .transform_point(&nalgebra::Point3::from(Vector3::from(payload.com_in_tcp_m)))
                .coords;
            let payload_force = payload.mass_kg * g_world;
            for i in 0..NUM_JOINTS {
                if self.desc.joints[i].joint_type == JointType::Fixed {
                    continue;
                }
                let j_v = fk.joint_axes_world[i].cross(&(payload_com_world - fk.joint_origins_world[i]));
                tau_g[i] -= j_v.dot(&payload_force);
            }
        }

        tau_g
    }

    pub fn effective_inertia_diag(
        &self,
        q: &[f64; NUM_JOINTS],
        payload: &PayloadSpec,
    ) -> [f64; NUM_JOINTS] {
        let fk = self.forward_kinematics(q);
        let mut m_diag = [0.0_f64; NUM_JOINTS];
        let payload_world = fk
            .tcp_world
            .to_isometry()
            .transform_point(&nalgebra::Point3::from(Vector3::from(payload.com_in_tcp_m)))
            .coords;

        for i in 0..NUM_JOINTS {
            let mut eff = 0.08 + self.desc.joints[i].inertial.inertia_diag_kgm2[1];
            let p_i = fk.joint_origins_world[i];
            let z_i = fk.joint_axes_world[i];

            for k in i..NUM_JOINTS {
                let com_k = fk.link_frames_world[k]
                    .transform_point(&nalgebra::Point3::from(Vector3::from(
                        self.desc.joints[k].inertial.com_m,
                    )))
                    .coords;
                let r_k = z_i.cross(&(com_k - p_i));
                eff += self.desc.joints[k].inertial.mass_kg * r_k.norm_squared();
            }
            if payload.mass_kg > 0.0 {
                let r_p = z_i.cross(&(payload_world - p_i));
                eff += payload.mass_kg * r_p.norm_squared();
            }
            m_diag[i] = eff.max(0.05);
        }
        m_diag
    }

    pub fn friction_torque(dq: f64, params: &JointFrictionParams) -> f64 {
        let stiction = params.coulomb_nm * (dq / 0.04).tanh();
        let viscous = params.viscous_nms_rad * dq;
        stiction + viscous
    }
}

pub fn validate_robot_description(desc: &RobotDescription) -> Result<(), ModelError> {
    if desc.schema_version != SCHEMA_CONFIG_V1 {
        return Err(ModelError::Validation(format!(
            "Unsupported schema_version '{}', expected '{}'",
            desc.schema_version, SCHEMA_CONFIG_V1
        )));
    }
    if !desc.base_in_world.is_valid() || !desc.tcp_in_flange.is_valid() {
        return Err(ModelError::Validation(
            "Non-finite or unnormalized base/tcp Pose3".to_string(),
        ));
    }
    for (idx, j) in desc.joints.iter().enumerate() {
        if !j.origin_in_parent.is_valid() {
            return Err(ModelError::Validation(format!(
                "Joint {idx} ({}) has invalid origin_in_parent",
                j.name
            )));
        }
        let axis_norm = Vector3::from(j.axis_local).norm();
        if !axis_norm.is_finite() || (axis_norm - 1.0).abs() > 1e-3 {
            return Err(ModelError::Validation(format!(
                "Joint {idx} ({}) axis_local must be unit length",
                j.name
            )));
        }
        if j.limits.pos_min_rad >= j.limits.pos_max_rad
            || j.limits.vel_max_rad_s <= 0.0
            || j.limits.acc_max_rad_s2 <= 0.0
            || j.limits.jerk_max_rad_s3 <= 0.0
            || j.limits.torque_max_nm <= 0.0
        {
            return Err(ModelError::Validation(format!(
                "Joint {idx} ({}) has invalid limits",
                j.name
            )));
        }
        if j.inertial.mass_kg < 0.0
            || j.inertial.inertia_diag_kgm2.iter().any(|&v| v < 0.0 || !v.is_finite())
        {
            return Err(ModelError::Validation(format!(
                "Joint {idx} ({}) has invalid inertial parameters",
                j.name
            )));
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use approx::assert_relative_eq;

    #[test]
    fn pose3_composition_and_inverse_are_consistent() {
        let a = Pose3::from_translation_rpy([0.3, -0.2, 0.5], 0.25, -0.4, 1.1);
        let b = Pose3::from_translation_rpy([0.1, 0.4, -0.15], -0.3, 0.6, -0.7);
        let ab = a.compose(&b);
        let back = ab.compose(&b.inverse());
        for i in 0..3 {
            assert_relative_eq!(back.translation_m[i], a.translation_m[i], epsilon = 1e-10);
        }
        assert!(back.geodesic_angle_rad(&a) < 1e-10);
    }

    #[test]
    fn forward_kinematics_known_zero_configuration() {
        let arm = ArmModel::default_6r_650();
        let q = [0.0; NUM_JOINTS];
        let fk = arm.forward_kinematics(&q);
        assert_relative_eq!(fk.tcp_world.translation_m[0], 0.570, epsilon = 1e-9);
        assert_relative_eq!(fk.tcp_world.translation_m[1], 0.0, epsilon = 1e-9);
        assert_relative_eq!(fk.tcp_world.translation_m[2], 0.560, epsilon = 1e-9);
    }

    #[test]
    fn analytic_jacobian_matches_central_finite_difference() {
        let arm = ArmModel::default_6r_650();
        let test_configs = [
            [0.3, 0.4, 0.7, -0.2, 0.8, 0.5],
            [-0.8, -0.25, 1.1, 0.6, -0.7, -1.2],
        ];
        let eps = 1e-6;
        for q in &test_configs {
            let j_analytic = arm.geometric_jacobian(q);
            let mut j_fd = Matrix6::<f64>::zeros();
            for col in 0..NUM_JOINTS {
                let mut qp = *q;
                let mut qm = *q;
                qp[col] += eps;
                qm[col] -= eps;
                let fk_p = arm.forward_kinematics(&qp);
                let fk_m = arm.forward_kinematics(&qm);
                let dp = (Vector3::from(fk_p.tcp_world.translation_m)
                    - Vector3::from(fk_m.tcp_world.translation_m))
                    / (2.0 * eps);
                let r_p = fk_p.tcp_world.to_isometry().rotation;
                let r_m = fk_m.tcp_world.to_isometry().rotation;
                let omega = (r_p * r_m.inverse()).scaled_axis() / (2.0 * eps);
                j_fd[(0, col)] = dp.x;
                j_fd[(1, col)] = dp.y;
                j_fd[(2, col)] = dp.z;
                j_fd[(3, col)] = omega.x;
                j_fd[(4, col)] = omega.y;
                j_fd[(5, col)] = omega.z;
            }
            let diff = (j_analytic - j_fd).abs().max();
            assert!(diff < 1e-6, "Jacobian finite-difference mismatch: {diff}");
        }
    }

    #[test]
    fn ik_roundtrip_and_unreachable_target() {
        let arm = ArmModel::default_6r_650();
        let q_true = [0.25, 0.45, 0.85, -0.15, 0.65, 0.3];
        let target = arm.forward_kinematics(&q_true).tcp_world;
        let q_seed = [0.1, 0.25, 0.6, 0.0, 0.5, 0.0];

        let sol = arm
            .inverse_kinematics(&target, &q_seed, &IkOptions::default())
            .expect("IK should solve reachable target");
        assert!(sol.pos_err_m < 1e-4);
        assert!(sol.ori_err_rad < 2e-4);

        let unreachable = Pose3::from_translation_rpy([1.8, 0.0, 0.5], 0.0, PI, 0.0);
        let err = arm
            .inverse_kinematics(&unreachable, &q_seed, &IkOptions::default())
            .expect_err("Unreachable target must fail explicitly");
        assert!(matches!(err, IkError::TargetOutOfReach { .. }));
    }

    #[test]
    fn singularity_diagnostics_flags_wrist_and_elbow_singularities() {
        let arm = ArmModel::default_6r_650();
        let q_sing = [0.0, 0.2, 0.0, 0.1, 0.0, 0.4];
        let report = arm.singularity_diagnostics(&q_sing);
        assert!(report.wrist_singular);
        assert!(report.elbow_singular);
        assert!(report.near_singular);
    }
}
