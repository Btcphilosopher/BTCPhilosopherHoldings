use arm_types::{
    ActuatorCommand, AdapterCapabilities, CommandMode, GripperCommand, GripperState, JointState,
    NUM_JOINTS,
};
use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Debug, Error, Clone, PartialEq)]
pub enum AdapterError {
    #[error("Adapter is not connected")]
    Disconnected,
    #[error("Unsupported command mode '{0:?}' for adapter '{1}'")]
    UnsupportedCommandMode(CommandMode, String),
    #[error("Communication loss or timeout with robot controller")]
    CommunicationLost,
    #[error("Telemetry read failed: {0}")]
    TelemetryError(String),
    #[error("Physical robot commissioning required: {0}")]
    PhysicalCommissioningRequired(String),
    #[error("Command rejected by adapter: {0}")]
    CommandRejected(String),
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct AdapterHealth {
    pub connected: bool,
    pub estop_latched: bool,
    pub missed_heartbeats: u32,
    pub last_rtt_ms: f64,
}

pub trait RobotAdapter {
    fn capabilities(&self) -> AdapterCapabilities;
    fn connect(&mut self) -> Result<(), AdapterError>;
    fn disconnect(&mut self) -> Result<(), AdapterError>;
    fn read_telemetry(&mut self) -> Result<JointState, AdapterError>;
    fn read_gripper(&self) -> Result<GripperState, AdapterError>;
    fn send_command(&mut self, cmd: &ActuatorCommand) -> Result<(), AdapterError>;
    fn command_gripper(&mut self, cmd: GripperCommand) -> Result<(), AdapterError>;
    fn emergency_stop(&mut self) -> Result<(), AdapterError>;
    fn health_status(&self) -> AdapterHealth;
}

pub struct SimulatorAdapter {
    pub sim: arm_sim::ArmSimulator,
    connected: bool,
    estop_latched: bool,
    pub inject_comm_loss: bool,
    pub inject_stale_timestamp_ns: Option<u64>,
}

impl SimulatorAdapter {
    pub fn new(sim: arm_sim::ArmSimulator) -> Self {
        Self {
            sim,
            connected: false,
            estop_latched: false,
            inject_comm_loss: false,
            inject_stale_timestamp_ns: None,
        }
    }
}

impl RobotAdapter for SimulatorAdapter {
    fn capabilities(&self) -> AdapterCapabilities {
        AdapterCapabilities {
            adapter_name: "arm_sim_position_adapter".to_string(),
            supports_position: true,
            supports_velocity: false,
            supports_torque: false,
            supports_gripper: true,
            provides_torque_telemetry: false,
            provides_temperature: true,
            max_command_rate_hz: 1.0 / self.sim.config.dt_control_s,
            is_certified_safety_interface: false,
        }
    }

    fn connect(&mut self) -> Result<(), AdapterError> {
        if self.inject_comm_loss {
            return Err(AdapterError::CommunicationLost);
        }
        self.connected = true;
        self.estop_latched = false;
        Ok(())
    }

    fn disconnect(&mut self) -> Result<(), AdapterError> {
        self.connected = false;
        Ok(())
    }

    fn read_telemetry(&mut self) -> Result<JointState, AdapterError> {
        if !self.connected {
            return Err(AdapterError::Disconnected);
        }
        if self.inject_comm_loss {
            return Err(AdapterError::CommunicationLost);
        }
        let mut js = self.sim.read_sensor_state();
        if let Some(stale) = self.inject_stale_timestamp_ns {
            js.timestamp_ns = stale;
        }
        Ok(js)
    }

    fn read_gripper(&self) -> Result<GripperState, AdapterError> {
        if !self.connected {
            return Err(AdapterError::Disconnected);
        }
        Ok(self.sim.state.gripper.clone())
    }

    fn send_command(&mut self, cmd: &ActuatorCommand) -> Result<(), AdapterError> {
        if !self.connected {
            return Err(AdapterError::Disconnected);
        }
        if self.inject_comm_loss {
            return Err(AdapterError::CommunicationLost);
        }
        if self.estop_latched {
            return Err(AdapterError::CommandRejected(
                "E-stop latched; motion commands blocked".to_string(),
            ));
        }
        if cmd.mode() != CommandMode::Position {
            return Err(AdapterError::UnsupportedCommandMode(
                cmd.mode(),
                self.capabilities().adapter_name,
            ));
        }
        self.sim
            .enqueue_command(cmd)
            .map_err(AdapterError::CommandRejected)?;
        self.sim.step_physics();
        Ok(())
    }

    fn command_gripper(&mut self, cmd: GripperCommand) -> Result<(), AdapterError> {
        if !self.connected {
            return Err(AdapterError::Disconnected);
        }
        if self.estop_latched {
            return Err(AdapterError::CommandRejected("E-stop latched".to_string()));
        }
        self.sim.command_gripper(cmd);
        Ok(())
    }

    fn emergency_stop(&mut self) -> Result<(), AdapterError> {
        self.estop_latched = true;
        let hold = ActuatorCommand::PositionTarget {
            q_rad: self.sim.state.q_true,
            dq_ff_rad_s: [0.0; NUM_JOINTS],
            timestamp_ns: self.sim.state.timestamp_ns,
            seq: self.sim.state.seq,
        };
        let _ = self.sim.enqueue_command(&hold);
        Ok(())
    }

    fn health_status(&self) -> AdapterHealth {
        AdapterHealth {
            connected: self.connected && !self.inject_comm_loss,
            estop_latched: self.estop_latched,
            missed_heartbeats: if self.inject_comm_loss { 3 } else { 0 },
            last_rtt_ms: if self.inject_comm_loss { 999.0 } else { 0.4 },
        }
    }
}

pub struct MockHardwareAdapter {
    connected: bool,
    estop_latched: bool,
    pub simulate_comm_loss: bool,
    pub simulate_stale_telemetry: bool,
    q: [f64; NUM_JOINTS],
    dq: [f64; NUM_JOINTS],
    timestamp_ns: u64,
    seq: u64,
    gripper: GripperState,
}

impl MockHardwareAdapter {
    pub fn new(q_init: [f64; NUM_JOINTS]) -> Self {
        Self {
            connected: false,
            estop_latched: false,
            simulate_comm_loss: false,
            simulate_stale_telemetry: false,
            q: q_init,
            dq: [0.0; NUM_JOINTS],
            timestamp_ns: 1_000_000_000,
            seq: 0,
            gripper: GripperState::Open { width_m: 0.085 },
        }
    }
}

impl RobotAdapter for MockHardwareAdapter {
    fn capabilities(&self) -> AdapterCapabilities {
        AdapterCapabilities {
            adapter_name: "mock_industrial_position_controller".to_string(),
            supports_position: true,
            supports_velocity: false,
            supports_torque: false,
            supports_gripper: true,
            provides_torque_telemetry: false,
            provides_temperature: true,
            max_command_rate_hz: 100.0,
            is_certified_safety_interface: false,
        }
    }

    fn connect(&mut self) -> Result<(), AdapterError> {
        if self.simulate_comm_loss {
            return Err(AdapterError::CommunicationLost);
        }
        self.connected = true;
        self.estop_latched = false;
        Ok(())
    }

    fn disconnect(&mut self) -> Result<(), AdapterError> {
        self.connected = false;
        Ok(())
    }

    fn read_telemetry(&mut self) -> Result<JointState, AdapterError> {
        if !self.connected {
            return Err(AdapterError::Disconnected);
        }
        if self.simulate_comm_loss {
            return Err(AdapterError::CommunicationLost);
        }
        let ts = if self.simulate_stale_telemetry {
            100_000
        } else {
            self.timestamp_ns
        };
        Ok(JointState {
            q: self.q,
            dq: self.dq,
            ddq: [0.0; NUM_JOINTS],
            tau_measured: None,
            motor_temp_c: Some([36.0; NUM_JOINTS]),
            timestamp_ns: ts,
            seq: self.seq,
        })
    }

    fn read_gripper(&self) -> Result<GripperState, AdapterError> {
        if !self.connected {
            return Err(AdapterError::Disconnected);
        }
        Ok(self.gripper.clone())
    }

    fn send_command(&mut self, cmd: &ActuatorCommand) -> Result<(), AdapterError> {
        if !self.connected {
            return Err(AdapterError::Disconnected);
        }
        if self.simulate_comm_loss {
            return Err(AdapterError::CommunicationLost);
        }
        if self.estop_latched {
            return Err(AdapterError::CommandRejected("E-stop latched".to_string()));
        }
        match cmd {
            ActuatorCommand::PositionTarget { q_rad, dq_ff_rad_s, .. } => {
                for j in 0..NUM_JOINTS {
                    self.dq[j] = (q_rad[j] - self.q[j]) / 0.01;
                    self.q[j] = self.q[j] + 0.65 * (q_rad[j] - self.q[j]) + 0.002 * dq_ff_rad_s[j];
                }
                self.timestamp_ns += 10_000_000;
                self.seq += 1;
                Ok(())
            }
            other => Err(AdapterError::UnsupportedCommandMode(
                other.mode(),
                self.capabilities().adapter_name,
            )),
        }
    }

    fn command_gripper(&mut self, cmd: GripperCommand) -> Result<(), AdapterError> {
        if !self.connected {
            return Err(AdapterError::Disconnected);
        }
        self.gripper = match cmd {
            GripperCommand::Open => GripperState::Open { width_m: 0.085 },
            GripperCommand::Close {
                target_width_m,
                max_force_n,
            } => GripperState::Closed {
                width_m: target_width_m,
                force_n: max_force_n,
                grasped_object_id: None,
            },
        };
        Ok(())
    }

    fn emergency_stop(&mut self) -> Result<(), AdapterError> {
        self.estop_latched = true;
        self.dq = [0.0; NUM_JOINTS];
        Ok(())
    }

    fn health_status(&self) -> AdapterHealth {
        AdapterHealth {
            connected: self.connected && !self.simulate_comm_loss,
            estop_latched: self.estop_latched,
            missed_heartbeats: if self.simulate_comm_loss { 5 } else { 0 },
            last_rtt_ms: 1.2,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PhysicalCommissioningConfig {
    pub endpoint_uri: String,
    pub robot_serial: String,
    pub verified_joint_limits: bool,
    pub hardware_estop_circuit_verified: bool,
    pub commissioning_signoff_id: Option<String>,
}

pub struct PhysicalHardwareAdapter {
    pub config: PhysicalCommissioningConfig,
}

impl PhysicalHardwareAdapter {
    pub fn new(config: PhysicalCommissioningConfig) -> Self {
        Self { config }
    }
}

impl RobotAdapter for PhysicalHardwareAdapter {
    fn capabilities(&self) -> AdapterCapabilities {
        AdapterCapabilities {
            adapter_name: "unconfigured_physical_vendor_interface".to_string(),
            supports_position: true,
            supports_velocity: false,
            supports_torque: false,
            supports_gripper: true,
            provides_torque_telemetry: false,
            provides_temperature: false,
            max_command_rate_hz: 125.0,
            is_certified_safety_interface: false,
        }
    }

    fn connect(&mut self) -> Result<(), AdapterError> {
        if !self.config.verified_joint_limits
            || !self.config.hardware_estop_circuit_verified
            || self.config.commissioning_signoff_id.is_none()
        {
            return Err(AdapterError::PhysicalCommissioningRequired(
                "Missing verified limits, hardware E-stop verification, or commissioning sign-off"
                    .to_string(),
            ));
        }
        Err(AdapterError::PhysicalCommissioningRequired(
            "No manufacturer fieldbus/SDK driver compiled in this build; connection never fabricated"
                .to_string(),
        ))
    }

    fn disconnect(&mut self) -> Result<(), AdapterError> {
        Ok(())
    }

    fn read_telemetry(&mut self) -> Result<JointState, AdapterError> {
        Err(AdapterError::Disconnected)
    }

    fn read_gripper(&self) -> Result<GripperState, AdapterError> {
        Err(AdapterError::Disconnected)
    }

    fn send_command(&mut self, _cmd: &ActuatorCommand) -> Result<(), AdapterError> {
        Err(AdapterError::Disconnected)
    }

    fn command_gripper(&mut self, _cmd: GripperCommand) -> Result<(), AdapterError> {
        Err(AdapterError::Disconnected)
    }

    fn emergency_stop(&mut self) -> Result<(), AdapterError> {
        Err(AdapterError::PhysicalCommissioningRequired(
            "Hardware E-stop must be triggered via certified safety relay, not software stub"
                .to_string(),
        ))
    }

    fn health_status(&self) -> AdapterHealth {
        AdapterHealth {
            connected: false,
            estop_latched: true,
            missed_heartbeats: 0,
            last_rtt_ms: 0.0,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn mock_adapter_rejects_unsupported_torque_command() {
        let mut mock = MockHardwareAdapter::new([0.0; NUM_JOINTS]);
        mock.connect().unwrap();
        let torque_cmd = ActuatorCommand::TorqueTarget {
            tau_nm: [1.0; NUM_JOINTS],
            timestamp_ns: 1_000_000_000,
            seq: 1,
        };
        let res = mock.send_command(&torque_cmd);
        assert!(matches!(
            res,
            Err(AdapterError::UnsupportedCommandMode(CommandMode::Torque, _))
        ));
    }

    #[test]
    fn physical_adapter_never_fabricates_connection() {
        let mut phys = PhysicalHardwareAdapter::new(PhysicalCommissioningConfig {
            endpoint_uri: "tcp://192.168.1.50:30003".to_string(),
            robot_serial: "AUR-650-001".to_string(),
            verified_joint_limits: true,
            hardware_estop_circuit_verified: true,
            commissioning_signoff_id: Some("COMM-2026-01".to_string()),
        });
        assert!(matches!(
            phys.connect(),
            Err(AdapterError::PhysicalCommissioningRequired(_))
        ));
    }
}
