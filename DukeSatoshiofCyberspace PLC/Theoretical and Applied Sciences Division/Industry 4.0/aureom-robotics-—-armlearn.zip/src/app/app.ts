import {HttpClient} from '@angular/common/http';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  OnInit,
  signal,
} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {
  ArmLearnSummaryPayload,
  JointSysId,
  JointUncertainty,
  TelemetryPayload,
  TelemetryPoint,
} from './armlearn-types';

interface ProjectedLink {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  label: string;
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  private readonly http = inject(HttpClient);

  protected readonly loading = signal(true);
  protected readonly errorMsg = signal<string | null>(null);
  protected readonly summary = signal<ArmLearnSummaryPayload | null>(null);
  protected readonly telemetry = signal<TelemetryPayload | null>(null);
  protected readonly selectedScenario = signal<string>('eval_01_nominal');
  protected readonly scrubIndex = signal<number>(0);
  protected readonly verifying = signal(false);
  protected readonly verifyStatus = signal<string | null>(null);
  protected readonly hoverIndex = signal<number | null>(null);

  protected readonly scenarios = computed(() => {
    const ev = this.summary()?.evaluation;
    if (!ev) return [];
    return ev.baseline_runs.map((b, idx) => ({
      scenario_id: b.scenario_id,
      base: b,
      learned: ev.learned_runs[idx],
    }));
  });

  protected readonly activeRunPair = computed(() => {
    const id = this.selectedScenario();
    return this.scenarios().find((s) => s.scenario_id === id) ?? null;
  });

  protected readonly sysIdRows = computed(() => {
    const map = this.summary()?.rReport.system_identification;
    const unc = this.summary()?.rReport.uncertainty_decomposition;
    if (!map) return [];
    return [0, 1, 2, 3, 4, 5].map((j) => {
      const key = `joint_${j}`;
      return {
        joint: j + 1,
        sys: map[key] as JointSysId | undefined,
        unc: unc?.[key] as JointUncertainty | undefined,
      };
    });
  });

  protected readonly activeLearnedPoint = computed<TelemetryPoint | null>(() => {
    const tel = this.telemetry();
    if (!tel || tel.learned.length === 0) return null;
    const idx = Math.min(this.scrubIndex(), tel.learned.length - 1);
    return tel.learned[idx];
  });

  protected readonly activeBaselinePoint = computed<TelemetryPoint | null>(() => {
    const tel = this.telemetry();
    if (!tel || tel.baseline.length === 0) return null;
    const idx = Math.min(this.scrubIndex(), tel.baseline.length - 1);
    return tel.baseline[idx];
  });

  protected readonly maxScrubIndex = computed(() =>
    Math.max(0, (this.telemetry()?.learned.length ?? 1) - 1),
  );

  /** Forward-kinematic projection of Aureom-6R-650 into SVG viewport (isometric side+yaw projection). */
  protected readonly armSvgGeometry = computed(() => {
    const pt = this.activeLearnedPoint();
    const q = pt?.q_true ?? [0, 0.2, 1.05, 0, 0.32, 0];

    // Exact Aureom-6R-650 link chain
    const pBase: [number, number, number] = [0, 0, 0.02];
    const pJ1: [number, number, number] = [0, 0, 0.16];
    const c1 = Math.cos(q[0]);
    const s1 = Math.sin(q[0]);

    const rotZ = (v: [number, number, number]): [number, number, number] => [
      c1 * v[0] - s1 * v[1],
      s1 * v[0] + c1 * v[1],
      v[2],
    ];

    // Planar pitch chain in J1 local XZ plane
    const sh: [number, number, number] = [0.04, 0, 0.08];
    const a2 = q[1];
    const a23 = q[1] + q[2];
    const a235 = q[1] + q[2] + q[4];

    // Link 2 starts along +Z (vertical 0.32m rotated by q2 around +Y: dx = L*sin(q2), dz = L*cos(q2))
    const p2Local: [number, number, number] = [
      sh[0] + 0.32 * Math.sin(a2),
      0,
      sh[2] + 0.32 * Math.cos(a2),
    ];
    // Link 3 extends along +X at zero angle (dx = L*cos(a23), dz = -L*sin(a23))
    const p3Local: [number, number, number] = [
      p2Local[0] + 0.28 * Math.cos(a23),
      0,
      p2Local[2] - 0.28 * Math.sin(a23),
    ];
    const p4Local: [number, number, number] = [
      p3Local[0] + 0.08 * Math.cos(a23),
      0,
      p3Local[2] - 0.08 * Math.sin(a23),
    ];
    const p5Local: [number, number, number] = [
      p4Local[0] + 0.065 * Math.cos(a235),
      0,
      p4Local[2] - 0.065 * Math.sin(a235),
    ];
    const pTcpLocal: [number, number, number] = [
      p5Local[0] + 0.105 * Math.cos(a235),
      0,
      p5Local[2] - 0.105 * Math.sin(a235),
    ];

    const add = (a: [number, number, number], b: [number, number, number]): [number, number, number] => [
      a[0] + b[0],
      a[1] + b[1],
      a[2] + b[2],
    ];

    const pts3d: [number, number, number][] = [
      pBase,
      pJ1,
      add(pJ1, rotZ([sh[0], 0, sh[2]])),
      add(pJ1, rotZ(p2Local)),
      add(pJ1, rotZ(p3Local)),
      add(pJ1, rotZ(p4Local)),
      add(pJ1, rotZ(p5Local)),
      add(pJ1, rotZ(pTcpLocal)),
    ];

    // Isometric projection (X right-down, Y right-up, Z up)
    const project = (p: [number, number, number]): {x: number; y: number} => {
      const px = 140 + p[0] * 390 + p[1] * 260;
      const py = 275 - p[2] * 350 - p[1] * 95 + p[0] * 45;
      return {x: px, y: py};
    };

    const proj = pts3d.map(project);
    const links: ProjectedLink[] = [];
    const labels = ['Pedestal', 'Shoulder', 'Upper Arm', 'Forearm', 'Wrist', 'Flange', 'Gripper TCP'];
    for (let i = 0; i < proj.length - 1; i++) {
      links.push({
        x1: proj[i].x,
        y1: proj[i].y,
        x2: proj[i + 1].x,
        y2: proj[i + 1].y,
        label: labels[i],
      });
    }

    const pickStation = project([0.36, -0.22, 0.06]);
    const placeStation = project([0.34, 0.24, 0.05]);
    const dividerTop = project([0.38, 0.0, 0.22]);
    const dividerBot = project([0.38, 0.0, 0.0]);
    const tcpWorld = pts3d[pts3d.length - 1];

    return {
      links,
      joints: proj,
      tcpScreen: proj[proj.length - 1],
      tcpWorld,
      pickStation,
      placeStation,
      dividerTop,
      dividerBot,
      grasped: pt?.grasped ?? false,
    };
  });

  protected readonly chartPaths = computed(() => {
    const tel = this.telemetry();
    if (!tel || tel.baseline.length === 0 || tel.learned.length === 0) {
      return null;
    }
    const w = 640;
    const h = 190;
    const padL = 44;
    const padR = 16;
    const padT = 14;
    const padB = 26;
    const innerW = w - padL - padR;
    const innerH = h - padT - padB;

    const maxT = Math.max(
      tel.baseline[tel.baseline.length - 1].time_s,
      tel.learned[tel.learned.length - 1].time_s,
      0.1,
    );
    const allErrs = [
      ...tel.baseline.map((p) => p.tcp_pos_err_m * 1000),
      ...tel.learned.map((p) => p.tcp_pos_err_m * 1000),
    ];
    const maxY = Math.max(...allErrs, 5.0) * 1.12;

    const toPath = (pts: TelemetryPoint[]) =>
      pts
        .map((p, idx) => {
          const x = padL + (p.time_s / maxT) * innerW;
          const y = padT + innerH - ((p.tcp_pos_err_m * 1000) / maxY) * innerH;
          return `${idx === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
        })
        .join(' ');

    const scrubPt = this.activeLearnedPoint();
    const scrubX = scrubPt ? padL + (scrubPt.time_s / maxT) * innerW : padL;

    return {
      w,
      h,
      padL,
      padT,
      innerW,
      innerH,
      maxT,
      maxY,
      baselinePath: toPath(tel.baseline),
      learnedPath: toPath(tel.learned),
      scrubX,
    };
  });

  ngOnInit(): void {
    this.loadSummary();
  }

  loadSummary(): void {
    this.loading.set(true);
    this.errorMsg.set(null);
    this.http.get<ArmLearnSummaryPayload>('/api/armlearn/summary').subscribe({
      next: (data) => {
        this.summary.set(data);
        this.loading.set(false);
        this.selectScenario(this.selectedScenario());
      },
      error: (err) => {
        this.errorMsg.set(err?.error?.error ?? 'Failed to load ArmLearn artifacts');
        this.loading.set(false);
      },
    });
  }

  selectScenario(scenarioId: string): void {
    this.selectedScenario.set(scenarioId);
    this.http
      .get<TelemetryPayload>(`/api/armlearn/telemetry?scenario=${encodeURIComponent(scenarioId)}`)
      .subscribe({
        next: (tel) => {
          this.telemetry.set(tel);
          const mid = Math.floor((tel.learned.length || 1) * 0.45);
          this.scrubIndex.set(mid);
        },
        error: () => {
          this.telemetry.set(null);
        },
      });
  }

  onScrubChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    if (Number.isFinite(val)) {
      this.scrubIndex.set(val);
    }
  }

  onChartHover(event: MouseEvent): void {
    const tel = this.telemetry();
    const paths = this.chartPaths();
    if (!tel || !paths || tel.learned.length === 0) return;
    const svg = event.currentTarget as SVGSVGElement;
    const rect = svg.getBoundingClientRect();
    const relX = ((event.clientX - rect.left) / rect.width) * paths.w;
    const ratio = Math.max(0, Math.min(1, (relX - paths.padL) / paths.innerW));
    const idx = Math.round(ratio * (tel.learned.length - 1));
    this.hoverIndex.set(idx);
    this.scrubIndex.set(idx);
  }

  onChartLeave(): void {
    this.hoverIndex.set(null);
  }

  runVerifyParity(): void {
    this.verifying.set(true);
    this.verifyStatus.set(null);
    this.http.post<{ok: boolean; parity: {max_abs_diff_rad: number; passed: boolean}}>('/api/armlearn/verify', {}).subscribe({
      next: (res) => {
        this.verifying.set(false);
        this.verifyStatus.set(
          res.parity.passed
            ? `Parity verified: max diff ${res.parity.max_abs_diff_rad.toExponential(2)} rad`
            : 'Parity tolerance exceeded',
        );
        this.loadSummary();
      },
      error: (err) => {
        this.verifying.set(false);
        this.verifyStatus.set(err?.error?.error ?? 'Verification error');
      },
    });
  }

  fmt(v: number | undefined | null, digits = 3): string {
    if (v === undefined || v === null || !Number.isFinite(v)) return '—';
    return v.toFixed(digits);
  }

  fmtExp(v: number | undefined | null): string {
    if (v === undefined || v === null || !Number.isFinite(v)) return '—';
    return v.toExponential(2);
  }
}
