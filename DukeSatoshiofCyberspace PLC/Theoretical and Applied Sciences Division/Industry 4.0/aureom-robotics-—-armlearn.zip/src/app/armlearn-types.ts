export interface TimingStats {
  ticks: number;
  mean_tick_us: number;
  max_tick_us: number;
  jitter_std_us: number;
  deadline_misses: number;
}

export interface ExecutionSummary {
  run_id: string;
  scenario_id: string;
  controller_mode: string;
  final_state: string;
  task_succeeded: boolean;
  grasped: boolean;
  placed: boolean;
  joint_rms_err_rad: number;
  joint_max_err_rad: number;
  tcp_pos_rms_m: number;
  tcp_pos_max_m: number;
  tcp_ori_rms_rad: number;
  command_effort_rad: number;
  constraint_violations: number;
  fallback_activations: number;
  fallback_rate: number;
  stopped_reason: string | null;
  dropped_telemetry_records: number;
  timing: TimingStats;
  execution_time_s: number;
}

export interface ParityReport {
  schema_version: string;
  model_id: string;
  model_version: string;
  rows_verified: number;
  max_abs_diff_rad: number;
  rms_diff_rad: number;
  tolerance_rad: number;
  passed: boolean;
}

export interface ComparisonMetrics {
  baseline_mean_joint_rms_rad: number;
  learned_mean_joint_rms_rad: number;
  joint_rms_reduction_pct: number;
  baseline_mean_tcp_pos_rms_m: number;
  learned_mean_tcp_pos_rms_m: number;
  tcp_rms_reduction_pct: number;
  baseline_constraint_violations: number;
  learned_constraint_violations: number;
  baseline_success_count: number;
  learned_success_count: number;
  total_heldout_runs: number;
}

export interface FaultSafetyDemo {
  ood_payload_stop_triggered: boolean;
  ood_payload_final_state: string;
  ood_payload_reason: string | null;
  stale_telemetry_stop_triggered: boolean;
  stale_telemetry_final_state: string;
  stale_telemetry_reason: string | null;
  delay_spike_violations: number;
  restart_state: string;
  auto_motion_after_restart_blocked: boolean;
}

export interface JointSysId {
  joint_index: number;
  ols_coulomb_lag_rad: number;
  ols_coulomb_se: number;
  ols_viscous_lag_s: number;
  ols_viscous_se: number;
  ols_gravity_sag_rad: number;
  ols_payload_sag_rad_per_kg: number;
  r_squared: number;
  residual_sd_rad: number;
}

export interface JointUncertainty {
  joint_index: number;
  total_test_rmse_rad: number;
  sensor_noise_sd_rad: number;
  parameter_epistemic_sd_rad: number;
  unmodeled_dynamics_sd_rad: number;
  residual_p95_abs_rad: number;
}

export interface ArmLearnSummaryPayload {
  demo: {
    schema_version: string;
    robot_model: string;
    robot_config_hash: string;
    parity_report: ParityReport;
    evaluation_summary: ComparisonMetrics;
    fault_and_safety_demo: FaultSafetyDemo;
    caveats: string[];
  };
  rReport: {
    r_version: string;
    validation: {
      rows: number;
      runs: number;
      non_finite_repaired: number;
      duplicate_timestamps_removed: number;
      units_verified: boolean;
    };
    split: {
      train_runs: string[];
      val_runs: string[];
      test_runs: string[];
    };
    system_identification: Record<string, JointSysId>;
    model_comparison: {
      ols_val_rmse_rad: number[];
      elastic_val_rmse_rad: number[];
    };
    uncertainty_decomposition: Record<string, JointUncertainty>;
    heldout_evaluation: {
      baseline_rms_rad_mean: number;
      residual_corrected_rms_rad_mean: number;
      relative_error_explained_pct: number;
    };
  };
  evaluation: {
    summary: ComparisonMetrics;
    baseline_runs: ExecutionSummary[];
    learned_runs: ExecutionSummary[];
  };
  parity: ParityReport;
  modelSummary: {
    model_id: string;
    model_version: string;
    schema_version: string;
    output_units: string;
    feature_count: number;
    max_correction_rad: number[];
    integrity_sha256: string;
    operating_domain: {
      payload_min_kg: number;
      payload_max_kg: number;
      max_recent_err_rad: number;
      temp_min_c: number;
      temp_max_c: number;
    };
  } | null;
}

export interface TelemetryPoint {
  time_s: number;
  tcp_pos_err_m: number;
  tcp_ori_err_rad: number;
  joint_err_rms_rad: number;
  ml_corr_norm_rad: number;
  q_true: number[];
  grasped: boolean;
  fallback: boolean;
}

export interface TelemetryPayload {
  scenario: string;
  baseline: TelemetryPoint[];
  learned: TelemetryPoint[];
}
