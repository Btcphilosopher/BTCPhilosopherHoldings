import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {execFile} from 'node:child_process';
import {existsSync, readFileSync} from 'node:fs';
import {join} from 'node:path';
import {promisify} from 'node:util';

const execFileAsync = promisify(execFile);
const browserDistFolder = join(import.meta.dirname, '../browser');
const workspaceRoot = process.cwd();
const artifactsDir = join(workspaceRoot, 'artifacts');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

function readJsonArtifact(filename: string): unknown | null {
  const full = join(artifactsDir, filename);
  if (!existsSync(full)) {
    return null;
  }
  return JSON.parse(readFileSync(full, 'utf8'));
}

app.get('/api/armlearn/summary', (_req, res) => {
  const demo = readJsonArtifact('demo_summary.json');
  const rReport = readJsonArtifact('r_pipeline_report.json');
  const evaluation = readJsonArtifact('evaluation_comparison.json');
  const parity = readJsonArtifact('parity_report.json');
  const model = readJsonArtifact('residual_model.v1.json');

  if (!demo || !rReport || !evaluation) {
    res.status(404).json({
      error: 'Artifacts not generated yet. Run `cargo run -p arm_cli -- demo --out-dir artifacts`.',
    });
    return;
  }

  res.json({
    demo,
    rReport,
    evaluation,
    parity,
    modelSummary: model
      ? {
          model_id: (model as Record<string, unknown>)['model_id'],
          model_version: (model as Record<string, unknown>)['model_version'],
          schema_version: (model as Record<string, unknown>)['schema_version'],
          output_units: (model as Record<string, unknown>)['output_units'],
          feature_count: ((model as Record<string, unknown>)['feature_names'] as string[])?.length ?? 0,
          max_correction_rad: (model as Record<string, unknown>)['max_correction_rad'],
          integrity_sha256: (model as Record<string, unknown>)['integrity_sha256'],
          operating_domain: (model as Record<string, unknown>)['operating_domain'],
        }
      : null,
  });
});

app.get('/api/armlearn/telemetry', (req, res) => {
  const scenario = typeof req.query['scenario'] === 'string' ? req.query['scenario'] : 'eval_01_nominal';
  const csvPath = join(artifactsDir, 'heldout_telemetry.csv');
  if (!existsSync(csvPath)) {
    res.status(404).json({error: 'heldout_telemetry.csv not found'});
    return;
  }
  const raw = readFileSync(csvPath, 'utf8');
  const lines = raw.trim().split('\n');
  if (lines.length < 2) {
    res.json({scenario, baseline: [], learned: []});
    return;
  }
  const header = lines[0].split(',');
  const idxScenario = header.indexOf('scenario_id');
  const idxMode = header.indexOf('controller_mode');
  const idxTime = header.indexOf('time_s');
  const idxTcpErr = header.indexOf('tcp_pos_err_m');
  const idxOriErr = header.indexOf('tcp_ori_err_rad');
  const idxFallback = header.indexOf('ml_fallback_active');
  const idxGrasped = header.indexOf('grasped');
  const idxQTrue = [0, 1, 2, 3, 4, 5].map((j) => header.indexOf(`q_true_${j}`));
  const idxQRef = [0, 1, 2, 3, 4, 5].map((j) => header.indexOf(`q_ref_${j}`));
  const idxCorr = [0, 1, 2, 3, 4, 5].map((j) => header.indexOf(`ml_corr_${j}`));

  interface TelemetryPoint {
    time_s: number;
    tcp_pos_err_m: number;
    tcp_ori_err_rad: number;
    joint_err_rms_rad: number;
    ml_corr_norm_rad: number;
    q_true: number[];
    grasped: boolean;
    fallback: boolean;
  }

  const baseline: TelemetryPoint[] = [];
  const learned: TelemetryPoint[] = [];

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(',');
    if (cols[idxScenario] !== scenario) continue;
    const mode = cols[idxMode];
    const qTrue = idxQTrue.map((idx) => Number(cols[idx]));
    const qRef = idxQRef.map((idx) => Number(cols[idx]));
    const corr = idxCorr.map((idx) => Number(cols[idx]));
    const jErrSq = qRef.reduce((acc, r, j) => acc + (r - qTrue[j]) ** 2, 0) / 6;
    const corrNorm = Math.sqrt(corr.reduce((acc, c) => acc + c * c, 0) / 6);

    const pt: TelemetryPoint = {
      time_s: Number(cols[idxTime]),
      tcp_pos_err_m: Number(cols[idxTcpErr]),
      tcp_ori_err_rad: Number(cols[idxOriErr]),
      joint_err_rms_rad: Math.sqrt(jErrSq),
      ml_corr_norm_rad: corrNorm,
      q_true: qTrue,
      grasped: cols[idxGrasped] === '1',
      fallback: cols[idxFallback] === '1',
    };
    if (mode === 'baseline_pid_ff') {
      baseline.push(pt);
    } else if (mode === 'learned_residual') {
      learned.push(pt);
    }
  }

  const stride = Math.max(1, Math.floor(Math.max(baseline.length, learned.length) / 180));
  const thin = (arr: TelemetryPoint[]) => arr.filter((_, idx) => idx % stride === 0 || idx === arr.length - 1);

  res.json({
    scenario,
    baseline: thin(baseline),
    learned: thin(learned),
  });
});

app.post('/api/armlearn/verify', async (_req, res) => {
  try {
    const releaseBin = join(workspaceRoot, 'target/release/arm_cli');
    const debugBin = join(workspaceRoot, 'target/debug/arm_cli');
    const cliBin = existsSync(releaseBin) ? releaseBin : debugBin;
    if (!existsSync(cliBin)) {
      res.status(400).json({error: 'arm_cli binary not built yet'});
      return;
    }
    const {stdout} = await execFileAsync(cliBin, [
      'verify-parity',
      '--model',
      'artifacts/residual_model.v1.json',
      '--reference-csv',
      'artifacts/r_reference_predictions.csv',
      '--out',
      'artifacts/parity_report.json',
    ], {cwd: workspaceRoot});
    res.json({ok: true, parity: JSON.parse(stdout)});
  } catch (err) {
    res.status(500).json({error: err instanceof Error ? err.message : 'Verification failed'});
  }
});

app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
