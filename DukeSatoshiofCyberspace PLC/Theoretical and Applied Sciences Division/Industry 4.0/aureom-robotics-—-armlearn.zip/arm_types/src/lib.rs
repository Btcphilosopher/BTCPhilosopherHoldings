//! AUREOM ROBOTICS — ArmLearn Core Types & Versioned Schemas
//!
//! Conventions (SI Units, Right-Handed Frames):
//! - Length: meters (m)
//! - Mass: kilograms (kg)
//! - Inertia: kg*m^2 about link center of mass, expressed in link frame
//! - Angles: radians (rad), Velocity: rad/s, Acceleration: rad/s^2, Jerk: rad/s^3
//! - Torque: Newton-meters (N*m)
//! - Time: integer nanoseconds (u64 monotonic) and seconds (f64)
//! - Frames: world (+Z up) -> base -> link_1..6 -> flange -> tcp
//! - Transform direction: Pose3 maps points from child frame into parent frame:
//!   p_parent = R(q_wxyz) * p_child + translation_m
//! - Quaternions: Hamilton convention [w, x, y, z], unit-length.

use nalgebra::{Isometry3, Quaternion, Translation3, UnitQuaternion, Vector3};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

pub const NUM_JOINTS: usize = 6;
pub const SCHEMA_CONFIG_V1: &str = "armlearn.config.v1";
pub const SCHEMA_MODEL_V1: &str = "armlearn.model.v1";
pub const SCHEMA_TELEMETRY_V1: &str = "armlearn.telemetry.v1";
pub const SCHEMA_REPORT_V1: &str = "armlearn.report.v1";

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct Pose3 {
    pub translation_m: [f64; 3],
    pub quaternion_wxyz: [f64; 4],
}

impl Default for Pose3 {
    fn default() -> Self {
        Self::identity()
    }
}

impl Pose3 {
    pub fn identity() -> Self {
        Self {
            translation_m: [0.0, 0.0, 0.0],
            quaternion_wxyz: [1.0, 0.0, 0.0, 0.0],
        }
    }

    pub fn from_translation_rpy(t: [f64; 3], roll: f64, pitch: f64, yaw: f64) -> Self {
        let uq = UnitQuaternion::from_euler_angles(roll, pitch, yaw);
        let q = uq.into_inner();
        Self::canonicalize_raw(t, [q.w, q.i, q.j, q.k])
    }

    pub fn from_isometry(iso: &Isometry3<f64>) -> Self {
        let t = [iso.translation.x, iso.translation.y, iso.translation.z];
        let q = iso.rotation.into_inner();
        Self::canonicalize_raw(t, [q.w, q.i, q.j, q.k])
    }

    fn canonicalize_raw(t: [f64; 3], mut q: [f64; 4]) -> Self {
        let norm = (q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]).sqrt();
        if norm > 1e-12 {
            q[0] /= norm;
            q[1] /= norm;
            q[2] /= norm;
            q[3] /= norm;
        } else {
            q = [1.0, 0.0, 0.0, 0.0];
        }
        if q[0] < 0.0 {
            q = [-q[0], -q[1], -q[2], -q[3]];
        }
        Self {
            translation_m: t,
            quaternion_wxyz: q,
        }
    }

    pub fn is_valid(&self) -> bool {
        let all_finite = self.translation_m.iter().all(|v| v.is_finite())
            && self.quaternion_wxyz.iter().all(|v| v.is_finite());
        if !all_finite {
            return false;
        }
        let norm_sq: f64 = self.quaternion_wxyz.iter().map(|v| v * v).sum();
        (norm_sq - 1.0).abs() < 1e-3
    }

    pub fn to_isometry(&self) -> Isometry3<f64> {
        let q = Quaternion::new(
            self.quaternion_wxyz[0],
            self.quaternion_wxyz[1],
            self.quaternion_wxyz[2],
            self.quaternion_wxyz[3],
        );
        let uq = UnitQuaternion::from_quaternion(q);
        Isometry3::from_parts(
            Translation3::new(
                self.translation_m[0],
                self.translation_m[1],
                self.translation_m[2],
            ),
            uq,
        )
    }

    pub fn compose(&self, child: &Pose3) -> Pose3 {
        Pose3::from_isometry(&(self.to_isometry() * child.to_isometry()))
    }

    pub fn inverse(&self) -> Pose3 {
        Pose3::from_isometry(&self.to_isometry().inverse())
    }

    pub fn transform_point(&self, p: [f64; 3]) -> [f64; 3] {
        let res = self.to_isometry().transform_point(&nalgebra::Point3::from(p));
        [res.x, res.y, res.z]
    }

    pub fn pose_error_world(current: &Pose3, target: &Pose3) -> [f64; 6] {
        let cur_iso = current.to_isometry();
        let tgt_iso = target.to_isometry();
        let dp = tgt_iso.translation.vector - cur_iso.translation.vector;
        let r_err = tgt_iso.rotation * cur_iso.rotation.inverse();
        let scaled_axis = r_err.scaled_axis();
        [dp.x, dp.y, dp.z, scaled_axis.x, scaled_axis.y, scaled_axis.z]
    }

    pub fn geodesic_angle_rad(&self, other: &Pose3) -> f64 {
        let dot: f64 = self
            .quaternion_wxyz
            .iter()
            .zip(other.quaternion_wxyz.iter())
            .map(|(a, b)| a * b)
            .sum();
        let clamped = dot.abs().min(1.0);
        2.0 * clamped.acos()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum JointType {
    Revolute,
    Fixed,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum InertialProvenance {
    IllustrativeEstimated,
    SystemIdentified,
    ManufacturerCad,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct InertialParams {
    pub mass_kg: f64,
    pub com_m: [f64; 3],
    pub inertia_diag_kgm2: [f64; 3],
    pub provenance: InertialProvenance,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum LinkGeometry {
    Capsule {
        p1_m: [f64; 3],
        p2_m: [f64; 3],
        radius_m: f64,
    },
    Sphere {
        center_m: [f64; 3],
        radius_m: f64,
    },
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct JointLimits {
    pub pos_min_rad: f64,
    pub pos_max_rad: f64,
    pub vel_max_rad_s: f64,
    pub acc_max_rad_s2: f64,
    pub jerk_max_rad_s3: f64,
    pub torque_max_nm: f64,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct JointFrictionParams {
    pub coulomb_nm: f64,
    pub viscous_nms_rad: f64,
    pub compliance_rad_per_nm: f64,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct JointSpec {
    pub name: String,
    pub joint_type: JointType,
    pub origin_in_parent: Pose3,
    pub axis_local: [f64; 3],
    pub limits: JointLimits,
    pub inertial: InertialParams,
    pub link_geometry: LinkGeometry,
    pub nominal_friction: JointFrictionParams,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PayloadSpec {
    pub name: String,
    pub mass_kg: f64,
    pub com_in_tcp_m: [f64; 3],
}

impl Default for PayloadSpec {
    fn default() -> Self {
        Self {
            name: "empty_gripper".to_string(),
            mass_kg: 0.0,
            com_in_tcp_m: [0.0, 0.0, 0.0],
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WorkspaceBounds {
    pub min_m: [f64; 3],
    pub max_m: [f64; 3],
    pub min_z_clearance_m: f64,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RobotDescription {
    pub schema_version: String,
    pub model_name: String,
    pub units: String,
    pub quaternion_convention: String,
    pub base_in_world: Pose3,
    pub joints: [JointSpec; NUM_JOINTS],
    pub tcp_in_flange: Pose3,
    pub gripper_capsule_in_flange: LinkGeometry,
    pub nominal_payload: PayloadSpec,
    pub workspace_bounds: WorkspaceBounds,
    pub supported_commands: Vec<CommandMode>,
}

impl RobotDescription {
    pub fn config_hash(&self) -> String {
        let json = serde_json::to_string(self).unwrap_or_default();
        sha256_hex(json.as_bytes())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CommandMode {
    Position,
    Velocity,
    Torque,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct JointState {
    pub q: [f64; NUM_JOINTS],
    pub dq: [f64; NUM_JOINTS],
    pub ddq: [f64; NUM_JOINTS],
    pub tau_measured: Option<[f64; NUM_JOINTS]>,
    pub motor_temp_c: Option<[f64; NUM_JOINTS]>,
    pub timestamp_ns: u64,
    pub seq: u64,
}

impl Default for JointState {
    fn default() -> Self {
        Self {
            q: [0.0; NUM_JOINTS],
            dq: [0.0; NUM_JOINTS],
            ddq: [0.0; NUM_JOINTS],
            tau_measured: None,
            motor_temp_c: None,
            timestamp_ns: 0,
            seq: 0,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum ActuatorCommand {
    PositionTarget {
        q_rad: [f64; NUM_JOINTS],
        dq_ff_rad_s: [f64; NUM_JOINTS],
        timestamp_ns: u64,
        seq: u64,
    },
    VelocityTarget {
        dq_rad_s: [f64; NUM_JOINTS],
        timestamp_ns: u64,
        seq: u64,
    },
    TorqueTarget {
        tau_nm: [f64; NUM_JOINTS],
        timestamp_ns: u64,
        seq: u64,
    },
}

impl ActuatorCommand {
    pub fn mode(&self) -> CommandMode {
        match self {
            ActuatorCommand::PositionTarget { .. } => CommandMode::Position,
            ActuatorCommand::VelocityTarget { .. } => CommandMode::Velocity,
            ActuatorCommand::TorqueTarget { .. } => CommandMode::Torque,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum GripperCommand {
    Open,
    Close {
        target_width_m: f64,
        max_force_n: f64,
    },
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum GripperState {
    Open { width_m: f64 },
    Closed {
        width_m: f64,
        force_n: f64,
        grasped_object_id: Option<String>,
    },
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct AdapterCapabilities {
    pub adapter_name: String,
    pub supports_position: bool,
    pub supports_velocity: bool,
    pub supports_torque: bool,
    pub supports_gripper: bool,
    pub provides_torque_telemetry: bool,
    pub provides_temperature: bool,
    pub max_command_rate_hz: f64,
    pub is_certified_safety_interface: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SupervisorState {
    Disconnected,
    Initialising,
    Ready,
    Armed,
    Executing,
    Paused,
    Stopping,
    Fault,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ResidualTargetKind {
    JointPositionResidualRad,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct OperatingDomain {
    pub q_min_rad: [f64; NUM_JOINTS],
    pub q_max_rad: [f64; NUM_JOINTS],
    pub dq_abs_max_rad_s: [f64; NUM_JOINTS],
    pub payload_min_kg: f64,
    pub payload_max_kg: f64,
    pub max_recent_err_rad: f64,
    pub temp_min_c: f64,
    pub temp_max_c: f64,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct NormalizationStats {
    pub mean: Vec<f64>,
    pub std: Vec<f64>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct LearnedResidualModelArtefact {
    pub schema_version: String,
    pub model_id: String,
    pub model_version: String,
    pub created_at_utc: String,
    pub r_version: String,
    pub target_kind: ResidualTargetKind,
    pub output_units: String,
    pub feature_names: Vec<String>,
    pub normalization: NormalizationStats,
    pub intercepts: [f64; NUM_JOINTS],
    pub weights: Vec<Vec<f64>>,
    pub max_correction_rad: [f64; NUM_JOINTS],
    pub operating_domain: OperatingDomain,
    pub training_run_ids: Vec<String>,
    pub validation_rmse_rad: [f64; NUM_JOINTS],
    pub integrity_sha256: String,
}

impl LearnedResidualModelArtefact {
    pub fn canonical_hash_payload(&self) -> String {
        let mut s = String::new();
        s.push_str(&format!(
            "{}|{}|{}|{}|",
            self.schema_version, self.model_id, self.model_version, self.output_units
        ));
        s.push_str(&self.feature_names.join(","));
        s.push('|');
        for v in &self.normalization.mean {
            s.push_str(&format!("{v:.10},"));
        }
        s.push('|');
        for v in &self.normalization.std {
            s.push_str(&format!("{v:.10},"));
        }
        s.push('|');
        for v in &self.intercepts {
            s.push_str(&format!("{v:.10},"));
        }
        s.push('|');
        for row in &self.weights {
            for v in row {
                s.push_str(&format!("{v:.10},"));
            }
            s.push(';');
        }
        s.push('|');
        for v in &self.max_correction_rad {
            s.push_str(&format!("{v:.10},"));
        }
        s
    }

    pub fn compute_integrity_sha256(&self) -> String {
        sha256_hex(self.canonical_hash_payload().as_bytes())
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TelemetryRecord {
    pub schema_version: String,
    pub run_id: String,
    pub scenario_id: String,
    pub controller_mode: String,
    pub step: u64,
    pub time_s: f64,
    pub timestamp_ns: u64,
    pub q_ref: [f64; NUM_JOINTS],
    pub dq_ref: [f64; NUM_JOINTS],
    pub q_meas: [f64; NUM_JOINTS],
    pub dq_meas: [f64; NUM_JOINTS],
    pub q_true: [f64; NUM_JOINTS],
    pub dq_true: [f64; NUM_JOINTS],
    pub q_cmd: [f64; NUM_JOINTS],
    pub ml_correction_rad: [f64; NUM_JOINTS],
    pub ml_fallback_active: bool,
    pub payload_est_kg: f64,
    pub payload_true_kg: f64,
    pub motor_temp_c: f64,
    pub tcp_pos_err_m: f64,
    pub tcp_ori_err_rad: f64,
    pub supervisor_state: SupervisorState,
    pub grasped: bool,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct BoxObstacle {
    pub id: String,
    pub center_m: [f64; 3],
    pub half_extents_m: [f64; 3],
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WorkpieceSpec {
    pub id: String,
    pub mass_kg: f64,
    pub half_extents_m: [f64; 3],
    pub initial_pose: Pose3,
    pub target_place_pose: Pose3,
}

pub fn sha256_hex(bytes: &[u8]) -> String {
    let mut hasher = Sha256::new();
    hasher.update(bytes);
    let result = hasher.finalize();
    result.iter().map(|b| format!("{b:02x}")).collect()
}

pub fn clamp_vec6(v: [f64; NUM_JOINTS], min_v: [f64; NUM_JOINTS], max_v: [f64; NUM_JOINTS]) -> [f64; NUM_JOINTS] {
    let mut out = [0.0; NUM_JOINTS];
    for i in 0..NUM_JOINTS {
        out[i] = v[i].clamp(min_v[i], max_v[i]);
    }
    out
}

pub fn norm_inf(v: &[f64; NUM_JOINTS]) -> f64 {
    v.iter().map(|x| x.abs()).fold(0.0_f64, f64::max)
}

pub fn rms_6(v: &[f64; NUM_JOINTS]) -> f64 {
    let ss: f64 = v.iter().map(|x| x * x).sum();
    (ss / (NUM_JOINTS as f64)).sqrt()
}

pub fn vec3_norm(v: [f64; 3]) -> f64 {
    Vector3::from(v).norm()
}
