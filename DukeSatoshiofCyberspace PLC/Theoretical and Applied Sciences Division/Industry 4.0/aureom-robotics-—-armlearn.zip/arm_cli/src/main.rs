use std::fs::{self, File};
use std::io::{BufWriter, Write};
use std::path::{Path, PathBuf};
use std::process::Command;
use std::thread;

use arm_adapters::SimulatorAdapter;
use arm_control::{
    BaselineControllerConfig, FallbackPolicy, JointSpaceController, ResidualInferenceEngine,
};
use arm_model::ArmModel;
use arm_planner::{CollisionScene, MotionPlanner};
use arm_runtime::{
    execute_supervised_run, BoundedTelemetryTx, ExecutionSummary, RuntimeConstraintsConfig,
    SupervisorEvent, SupervisorStateMachine,
};
use arm_sim::{ArmSimulator, SimScenarioConfig};
use arm_types::{
    PayloadSpec, Pose3, SupervisorState, TelemetryRecord, WorkpieceSpec, NUM_JOINTS,
    SCHEMA_REPORT_V1,
};
use clap::{Parser, Subcommand};
use serde::{Deserialize, Serialize};

#[derive(Parser)]
#[command(name = "arm_cli", about = "AUREOM ROBOTICS — ArmLearn Control & Evaluation CLI")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    GenerateData {
        #[arg(long, default_value = "artifacts")]
        out_dir: PathBuf,
    },
    VerifyParity {
        #[arg(long, default_value = "artifacts/residual_model.v1.json")]
        model: PathBuf,
        #[arg(long, default_value = "artifacts/r_reference_predictions.csv")]
        reference_csv: PathBuf,
        #[arg(long, default_value = "artifacts/parity_report.json")]
        out: PathBuf,
    },
    Evaluate {
        #[arg(long, default_value = "artifacts/residual_model.v1.json")]
        model: PathBuf,
        #[arg(long, default_value = "artifacts")]
        out_dir: PathBuf,
    },
    Demo {
        #[arg(long, default_value = "artifacts")]
        out_dir: PathBuf,
        #[arg(long, default_value_t = false)]
        skip_r: bool,
    },
    InspectModel {
        #[arg(long, default_value = "artifacts/residual_model.v1.json")]
        model: PathBuf,
    },
}

fn true_probe(adapter: &SimulatorAdapter) -> ([f64; NUM_JOINTS], [f64; NUM_JOINTS], f64, bool, bool) {
    let s = &adapter.sim.state;
    (
        s.q_true,
        s.dq_true,
        adapter.sim.current_true_payload().mass_kg,
        s.workpiece_grasped,
        s.place_completed,
    )
}

fn write_telemetry_csv(path: &Path, records: &[TelemetryRecord]) -> Result<(), Box<dyn std::error::Error>> {
    let file = File::create(path)?;
    let mut w = BufWriter::new(file);
    writeln!(
        w,
        "schema_version,run_id,scenario_id,controller_mode,step,time_s,timestamp_ns,\
        q_ref_0,q_ref_1,q_ref_2,q_ref_3,q_ref_4,q_ref_5,\
        dq_ref_0,dq_ref_1,dq_ref_2,dq_ref_3,dq_ref_4,dq_ref_5,\
        q_meas_0,q_meas_1,q_meas_2,q_meas_3,q_meas_4,q_meas_5,\
        dq_meas_0,dq_meas_1,dq_meas_2,dq_meas_3,dq_meas_4,dq_meas_5,\
        q_true_0,q_true_1,q_true_2,q_true_3,q_true_4,q_true_5,\
        q_cmd_0,q_cmd_1,q_cmd_2,q_cmd_3,q_cmd_4,q_cmd_5,\
        ml_corr_0,ml_corr_1,ml_corr_2,ml_corr_3,ml_corr_4,ml_corr_5,\
        ml_fallback_active,payload_est_kg,payload_true_kg,motor_temp_c,tcp_pos_err_m,tcp_ori_err_rad,grasped"
    )?;
    for r in records {
        write!(
            w,
            "{},{},{},{},{},{:.6},{}",
            r.schema_version,
            r.run_id,
            r.scenario_id,
            r.controller_mode,
            r.step,
            r.time_s,
            r.timestamp_ns
        )?;
        for v in &r.q_ref { write!(w, ",{v:.9}")?; }
        for v in &r.dq_ref { write!(w, ",{v:.9}")?; }
        for v in &r.q_meas { write!(w, ",{v:.9}")?; }
        for v in &r.dq_meas { write!(w, ",{v:.9}")?; }
        for v in &r.q_true { write!(w, ",{v:.9}")?; }
        for v in &r.q_cmd { write!(w, ",{v:.9}")?; }
        for v in &r.ml_correction_rad { write!(w, ",{v:.9}")?; }
        writeln!(
            w,
            ",{},{:.6},{:.6},{:.4},{:.8},{:.8},{}",
            if r.ml_fallback_active { 1 } else { 0 },
            r.payload_est_kg,
            r.payload_true_kg,
            r.motor_temp_c,
            r.tcp_pos_err_m,
            r.tcp_ori_err_rad,
            if r.grasped { 1 } else { 0 }
        )?;
    }
    w.flush()?;
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn run_scenario_with_logging(
    run_id: &str,
    scenario: SimScenarioConfig,
    controller_mode: &str,
    arm: &ArmModel,
    scene: &CollisionScene,
    speed_scale: f64,
    payload_est_kg: f64,
    constraints: &RuntimeConstraintsConfig,
    ml_engine: Option<&ResidualInferenceEngine>,
) -> Result<(ExecutionSummary, Vec<TelemetryRecord>), Box<dyn std::error::Error>> {
    let q_home = MotionPlanner::home_configuration();
    let plan = MotionPlanner::plan_pick_and_place(
        arm,
        scene,
        &q_home,
        &scenario.workpiece,
        speed_scale,
    )?;
    let scenario_id = scenario.scenario_id.clone();
    let sim = ArmSimulator::new(arm.clone(), scene.clone(), scenario, q_home);
    let mut adapter = SimulatorAdapter::new(sim);
    let mut controller = JointSpaceController::new(BaselineControllerConfig::default());
    let payload_est = PayloadSpec {
        name: "estimated_workpiece".to_string(),
        mass_kg: payload_est_kg,
        com_in_tcp_m: [0.0, 0.0, 0.015],
    };

    let (tx, rx, _dropped) = BoundedTelemetryTx::new(4096);
    let consumer = thread::spawn(move || {
        let mut collected = Vec::new();
        while let Ok(rec) = rx.recv() {
            collected.push(rec);
        }
        collected
    });

    let summary = execute_supervised_run(
        run_id,
        &scenario_id,
        controller_mode,
        arm,
        &mut adapter,
        &mut controller,
        &plan,
        &payload_est,
        constraints,
        ml_engine,
        &tx,
        Some(&true_probe),
    );
    drop(tx);
    let records = consumer.join().map_err(|_| "Telemetry thread panicked")?;
    Ok((summary, records))
}

fn training_scenarios() -> Vec<(String, SimScenarioConfig, f64)> {
    let configs = [
        ("run_01", 101_u64, 0.25_f64, 0.70_f64, [0.36, -0.22, 0.082], [0.34, 0.24, 0.072], 32.0),
        ("run_02", 102, 0.45, 0.80, [0.38, -0.20, 0.082], [0.35, 0.22, 0.072], 35.0),
        ("run_03", 103, 0.65, 0.85, [0.35, -0.24, 0.082], [0.33, 0.25, 0.072], 37.0),
        ("run_04", 104, 0.85, 0.90, [0.37, -0.19, 0.082], [0.36, 0.21, 0.072], 40.0),
        ("run_05", 105, 1.05, 0.75, [0.34, -0.23, 0.082], [0.34, 0.23, 0.072], 42.0),
        ("run_06", 106, 1.20, 0.85, [0.36, -0.21, 0.082], [0.35, 0.24, 0.072], 44.0),
        ("run_07", 107, 0.35, 0.95, [0.35, -0.21, 0.082], [0.32, 0.22, 0.072], 36.0),
        ("run_08", 108, 0.75, 0.65, [0.37, -0.23, 0.082], [0.35, 0.25, 0.072], 39.0),
        ("run_09", 109, 0.95, 0.82, [0.36, -0.22, 0.082], [0.34, 0.22, 0.072], 41.0),
        ("run_10", 110, 0.55, 0.88, [0.35, -0.20, 0.082], [0.33, 0.24, 0.072], 38.0),
    ];

    configs
        .into_iter()
        .map(|(id, seed, mass, speed, pick_xyz, place_xyz, temp)| {
            let mut sc = SimScenarioConfig::nominal(seed);
            sc.scenario_id = format!("train_{id}");
            sc.ambient_temp_c = temp;
            sc.workpiece = WorkpieceSpec {
                id: format!("wp_{id}"),
                mass_kg: mass,
                half_extents_m: [0.022, 0.022, 0.022],
                initial_pose: Pose3::from_translation_rpy(pick_xyz, 0.0, 0.0, 0.0),
                target_place_pose: Pose3::from_translation_rpy(place_xyz, 0.0, 0.0, 0.0),
            };
            (id.to_string(), sc, speed)
        })
        .collect()
}

fn heldout_scenarios() -> Vec<(String, SimScenarioConfig, f64, f64)> {
    let specs = [
        ("eval_01_nominal", 201_u64, 0.50_f64, 0.50_f64, 0.85_f64, 0.00025, 1, [0.36, -0.22, 0.082], [0.34, 0.24, 0.072]),
        ("eval_02_heavy", 202, 1.10, 1.10, 0.82, 0.00025, 1, [0.37, -0.21, 0.082], [0.35, 0.23, 0.072]),
        ("eval_03_fast_noisy", 203, 0.70, 0.70, 0.94, 0.00060, 1, [0.35, -0.23, 0.082], [0.33, 0.25, 0.072]),
        ("eval_04_payload_mismatch", 204, 0.85, 0.65, 0.80, 0.00035, 1, [0.36, -0.20, 0.082], [0.34, 0.22, 0.072]),
        ("eval_05_comm_delay2", 205, 0.60, 0.60, 0.85, 0.00030, 2, [0.35, -0.22, 0.082], [0.35, 0.24, 0.072]),
        ("eval_06_light_fast", 206, 0.30, 0.30, 0.92, 0.00040, 1, [0.37, -0.22, 0.082], [0.34, 0.23, 0.072]),
    ];
    specs
        .into_iter()
        .map(|(id, seed, true_mass, est_mass, speed, noise, delay, pick_xyz, place_xyz)| {
            let mut sc = SimScenarioConfig::nominal(seed);
            sc.scenario_id = id.to_string();
            sc.encoder_noise_std_rad = noise;
            sc.command_delay_steps = delay;
            sc.workpiece = WorkpieceSpec {
                id: format!("wp_{id}"),
                mass_kg: true_mass,
                half_extents_m: [0.022, 0.022, 0.022],
                initial_pose: Pose3::from_translation_rpy(pick_xyz, 0.0, 0.0, 0.0),
                target_place_pose: Pose3::from_translation_rpy(place_xyz, 0.0, 0.0, 0.0),
            };
            (id.to_string(), sc, speed, est_mass)
        })
        .collect()
}

#[derive(Debug, Deserialize)]
struct RPredictionRow {
    q_0: f64, q_1: f64, q_2: f64, q_3: f64, q_4: f64, q_5: f64,
    dq_0: f64, dq_1: f64, dq_2: f64, dq_3: f64, dq_4: f64, dq_5: f64,
    payload_est_kg: f64,
    motor_temp_c: f64,
    prev_err_0: f64, prev_err_1: f64, prev_err_2: f64, prev_err_3: f64, prev_err_4: f64, prev_err_5: f64,
    pred_r_0: f64, pred_r_1: f64, pred_r_2: f64, pred_r_3: f64, pred_r_4: f64, pred_r_5: f64,
}

#[derive(Debug, Serialize)]
struct ParityReport {
    schema_version: String,
    model_id: String,
    model_version: String,
    rows_verified: usize,
    max_abs_diff_rad: f64,
    rms_diff_rad: f64,
    tolerance_rad: f64,
    passed: bool,
}

fn verify_model_parity(
    model_path: &Path,
    ref_csv: &Path,
    out_path: &Path,
) -> Result<ParityReport, Box<dyn std::error::Error>> {
    let engine = ResidualInferenceEngine::load_and_validate(
        model_path,
        FallbackPolicy::DeterministicBaseline,
    )?;
    let mut rdr = csv::Reader::from_path(ref_csv)?;
    let mut max_diff = 0.0_f64;
    let mut sum_sq = 0.0_f64;
    let mut count = 0_usize;

    for result in rdr.deserialize() {
        let row: RPredictionRow = result?;
        let q = [row.q_0, row.q_1, row.q_2, row.q_3, row.q_4, row.q_5];
        let dq = [row.dq_0, row.dq_1, row.dq_2, row.dq_3, row.dq_4, row.dq_5];
        let prev_err = [
            row.prev_err_0,
            row.prev_err_1,
            row.prev_err_2,
            row.prev_err_3,
            row.prev_err_4,
            row.prev_err_5,
        ];
        let r_preds = [
            row.pred_r_0,
            row.pred_r_1,
            row.pred_r_2,
            row.pred_r_3,
            row.pred_r_4,
            row.pred_r_5,
        ];
        let out = engine.predict_bounded(&q, &dq, row.payload_est_kg, row.motor_temp_c, &prev_err);
        for j in 0..NUM_JOINTS {
            let diff = (out.raw_prediction_rad[j] - r_preds[j]).abs();
            max_diff = max_diff.max(diff);
            sum_sq += diff * diff;
        }
        count += 1;
    }

    let tol = 1e-9;
    let rms = if count > 0 {
        (sum_sq / ((count * NUM_JOINTS) as f64)).sqrt()
    } else {
        f64::INFINITY
    };
    let report = ParityReport {
        schema_version: SCHEMA_REPORT_V1.to_string(),
        model_id: engine.artefact.model_id.clone(),
        model_version: engine.artefact.model_version.clone(),
        rows_verified: count,
        max_abs_diff_rad: max_diff,
        rms_diff_rad: rms,
        tolerance_rad: tol,
        passed: count > 0 && max_diff < tol,
    };
    fs::write(out_path, serde_json::to_string_pretty(&report)?)?;
    Ok(report)
}

#[derive(Debug, Serialize)]
struct ComparisonMetrics {
    baseline_mean_joint_rms_rad: f64,
    learned_mean_joint_rms_rad: f64,
    joint_rms_reduction_pct: f64,
    baseline_mean_tcp_pos_rms_m: f64,
    learned_mean_tcp_pos_rms_m: f64,
    tcp_rms_reduction_pct: f64,
    baseline_constraint_violations: u64,
    learned_constraint_violations: u64,
    baseline_success_count: usize,
    learned_success_count: usize,
    total_heldout_runs: usize,
}

#[derive(Debug, Serialize)]
struct EvaluationComparisonReport {
    schema_version: String,
    summary: ComparisonMetrics,
    baseline_runs: Vec<ExecutionSummary>,
    learned_runs: Vec<ExecutionSummary>,
}

fn run_evaluation(
    model_path: &Path,
    out_dir: &Path,
) -> Result<EvaluationComparisonReport, Box<dyn std::error::Error>> {
    let arm = ArmModel::default_6r_650();
    let scene = CollisionScene::default_workcell();
    let constraints = RuntimeConstraintsConfig::default();
    let engine = ResidualInferenceEngine::load_and_validate(
        model_path,
        FallbackPolicy::DeterministicBaseline,
    )?;

    let mut base_summaries = Vec::new();
    let mut learned_summaries = Vec::new();
    let mut all_telemetry = Vec::new();

    for (run_id, sc, speed, est_mass) in heldout_scenarios() {
        let (b_sum, b_rec) = run_scenario_with_logging(
            &format!("{run_id}_base"),
            sc.clone(),
            "baseline_pid_ff",
            &arm,
            &scene,
            speed,
            est_mass,
            &constraints,
            None,
        )?;
        let (l_sum, l_rec) = run_scenario_with_logging(
            &format!("{run_id}_learned"),
            sc,
            "learned_residual",
            &arm,
            &scene,
            speed,
            est_mass,
            &constraints,
            Some(&engine),
        )?;
        base_summaries.push(b_sum);
        learned_summaries.push(l_sum);
        all_telemetry.extend(b_rec);
        all_telemetry.extend(l_rec);
    }

    let n = base_summaries.len() as f64;
    let b_j_rms = base_summaries.iter().map(|r| r.joint_rms_err_rad).sum::<f64>() / n;
    let l_j_rms = learned_summaries.iter().map(|r| r.joint_rms_err_rad).sum::<f64>() / n;
    let b_t_rms = base_summaries.iter().map(|r| r.tcp_pos_rms_m).sum::<f64>() / n;
    let l_t_rms = learned_summaries.iter().map(|r| r.tcp_pos_rms_m).sum::<f64>() / n;

    let report = EvaluationComparisonReport {
        schema_version: SCHEMA_REPORT_V1.to_string(),
        summary: ComparisonMetrics {
            baseline_mean_joint_rms_rad: b_j_rms,
            learned_mean_joint_rms_rad: l_j_rms,
            joint_rms_reduction_pct: ((b_j_rms - l_j_rms) / b_j_rms) * 100.0,
            baseline_mean_tcp_pos_rms_m: b_t_rms,
            learned_mean_tcp_pos_rms_m: l_t_rms,
            tcp_rms_reduction_pct: ((b_t_rms - l_t_rms) / b_t_rms) * 100.0,
            baseline_constraint_violations: base_summaries.iter().map(|r| r.constraint_violations).sum(),
            learned_constraint_violations: learned_summaries.iter().map(|r| r.constraint_violations).sum(),
            baseline_success_count: base_summaries.iter().filter(|r| r.task_succeeded).count(),
            learned_success_count: learned_summaries.iter().filter(|r| r.task_succeeded).count(),
            total_heldout_runs: base_summaries.len(),
        },
        baseline_runs: base_summaries,
        learned_runs: learned_summaries,
    };

    fs::write(
        out_dir.join("evaluation_comparison.json"),
        serde_json::to_string_pretty(&report)?,
    )?;
    write_telemetry_csv(&out_dir.join("heldout_telemetry.csv"), &all_telemetry)?;
    Ok(report)
}

#[derive(Debug, Serialize)]
struct FaultSafetyDemo {
    ood_payload_stop_triggered: bool,
    ood_payload_final_state: SupervisorState,
    ood_payload_reason: Option<String>,
    stale_telemetry_stop_triggered: bool,
    stale_telemetry_final_state: SupervisorState,
    stale_telemetry_reason: Option<String>,
    delay_spike_violations: u64,
    restart_state: SupervisorState,
    auto_motion_after_restart_blocked: bool,
}

#[derive(Debug, Serialize)]
struct FullDemoReport {
    schema_version: String,
    robot_model: String,
    robot_config_hash: String,
    baseline_training_runs: Vec<ExecutionSummary>,
    parity_report: ParityReport,
    evaluation_summary: ComparisonMetrics,
    fault_and_safety_demo: FaultSafetyDemo,
    caveats: Vec<String>,
}

fn generate_training_data(out_dir: &Path) -> Result<Vec<ExecutionSummary>, Box<dyn std::error::Error>> {
    fs::create_dir_all(out_dir)?;
    fs::create_dir_all("configs")?;
    let arm = ArmModel::default_6r_650();
    arm.save_json(Path::new("configs/aureom_6r_650.json"))?;

    let scene = CollisionScene::default_workcell();
    let constraints = RuntimeConstraintsConfig::default();

    let mut summaries = Vec::new();
    let mut records = Vec::new();
    for (run_id, sc, speed) in training_scenarios() {
        let est_mass = sc.workpiece.mass_kg;
        let (sum, rec) = run_scenario_with_logging(
            &run_id,
            sc,
            "baseline_pid_ff",
            &arm,
            &scene,
            speed,
            est_mass,
            &constraints,
            None,
        )?;
        summaries.push(sum);
        records.extend(rec);
    }

    write_telemetry_csv(&out_dir.join("baseline_training_telemetry.csv"), &records)?;
    fs::write(
        out_dir.join("baseline_runs.json"),
        serde_json::to_string_pretty(&summaries)?,
    )?;
    Ok(summaries)
}

fn run_fault_and_safety_demo(model_path: &Path) -> Result<FaultSafetyDemo, Box<dyn std::error::Error>> {
    let arm = ArmModel::default_6r_650();
    let scene = CollisionScene::default_workcell();
    let constraints = RuntimeConstraintsConfig::default();
    let q_home = MotionPlanner::home_configuration();

    let engine_stop = ResidualInferenceEngine::load_and_validate(
        model_path,
        FallbackPolicy::ControlledStop,
    )?;
    let mut sc_ood = SimScenarioConfig::nominal(901);
    sc_ood.scenario_id = "fault_ood_payload".to_string();
    sc_ood.command_delay_steps = 1;
    sc_ood.workpiece.mass_kg = 2.6;
    let plan_ood = MotionPlanner::plan_pick_and_place(&arm, &scene, &q_home, &sc_ood.workpiece, 0.85)?;
    let sim_ood = ArmSimulator::new(arm.clone(), scene.clone(), sc_ood, q_home);
    let mut adapter_ood = SimulatorAdapter::new(sim_ood);
    let mut ctrl_ood = JointSpaceController::new(BaselineControllerConfig::default());
    let (tx1, _rx1, _) = BoundedTelemetryTx::new(1024);
    let ood_sum = execute_supervised_run(
        "fault_ood_01",
        "fault_ood_payload",
        "learned_controlled_stop",
        &arm,
        &mut adapter_ood,
        &mut ctrl_ood,
        &plan_ood,
        &PayloadSpec {
            name: "unexpected_heavy".to_string(),
            mass_kg: 2.6,
            com_in_tcp_m: [0.0, 0.0, 0.015],
        },
        &constraints,
        Some(&engine_stop),
        &tx1,
        Some(&true_probe),
    );

    let mut sc_delay = SimScenarioConfig::nominal(903);
    sc_delay.scenario_id = "fault_delay_spike".to_string();
    sc_delay.command_delay_steps = 8;
    let plan_delay = MotionPlanner::plan_pick_and_place(&arm, &scene, &q_home, &sc_delay.workpiece, 0.95)?;
    let sim_delay = ArmSimulator::new(arm.clone(), scene.clone(), sc_delay, q_home);
    let mut adapter_delay = SimulatorAdapter::new(sim_delay);
    let mut ctrl_delay = JointSpaceController::new(BaselineControllerConfig::default());
    let (tx_delay, _rx_delay, _) = BoundedTelemetryTx::new(1024);
    let delay_sum = execute_supervised_run(
        "fault_delay_01",
        "fault_delay_spike",
        "baseline_pid_ff",
        &arm,
        &mut adapter_delay,
        &mut ctrl_delay,
        &plan_delay,
        &PayloadSpec::default(),
        &constraints,
        None,
        &tx_delay,
        Some(&true_probe),
    );

    let sc_stale = SimScenarioConfig::nominal(902);
    let plan_stale = MotionPlanner::plan_pick_and_place(&arm, &scene, &q_home, &sc_stale.workpiece, 0.85)?;
    let sim_stale = ArmSimulator::new(arm.clone(), scene, sc_stale, q_home);
    let mut adapter_stale = SimulatorAdapter::new(sim_stale);
    adapter_stale.inject_stale_timestamp_ns = Some(500_000_000);
    let mut ctrl_stale = JointSpaceController::new(BaselineControllerConfig::default());
    let (tx2, _rx2, _) = BoundedTelemetryTx::new(512);
    let stale_sum = execute_supervised_run(
        "fault_stale_01",
        "fault_stale_telemetry",
        "baseline_pid_ff",
        &arm,
        &mut adapter_stale,
        &mut ctrl_stale,
        &plan_stale,
        &PayloadSpec::default(),
        &constraints,
        None,
        &tx2,
        Some(&true_probe),
    );

    let mut sm = SupervisorStateMachine::new();
    sm.transition(SupervisorEvent::ConnectAndInit, true)?;
    sm.transition(SupervisorEvent::InitComplete, true)?;
    sm.transition(SupervisorEvent::Arm, true)?;
    sm.transition(SupervisorEvent::StartExecution, true)?;
    sm.transition(SupervisorEvent::Restart, true)?;
    let restart_state = sm.state();
    let auto_blocked = sm.transition(SupervisorEvent::StartExecution, true).is_err();

    Ok(FaultSafetyDemo {
        ood_payload_stop_triggered: ood_sum.stopped_reason.is_some(),
        ood_payload_final_state: ood_sum.final_state,
        ood_payload_reason: ood_sum.stopped_reason,
        stale_telemetry_stop_triggered: stale_sum.stopped_reason.is_some(),
        stale_telemetry_final_state: stale_sum.final_state,
        stale_telemetry_reason: stale_sum.stopped_reason,
        delay_spike_violations: delay_sum.constraint_violations + stale_sum.constraint_violations,
        restart_state,
        auto_motion_after_restart_blocked: auto_blocked,
    })
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let cli = Cli::parse();
    match cli.command {
        Commands::GenerateData { out_dir } => {
            let sums = generate_training_data(&out_dir)?;
            println!(
                "Generated {} baseline runs -> {}",
                sums.len(),
                out_dir.join("baseline_training_telemetry.csv").display()
            );
        }
        Commands::VerifyParity {
            model,
            reference_csv,
            out,
        } => {
            let report = verify_model_parity(&model, &reference_csv, &out)?;
            println!("{}", serde_json::to_string_pretty(&report)?);
            if !report.passed {
                std::process::exit(2);
            }
        }
        Commands::Evaluate { model, out_dir } => {
            let report = run_evaluation(&model, &out_dir)?;
            println!("{}", serde_json::to_string_pretty(&report.summary)?);
        }
        Commands::InspectModel { model } => {
            let eng = ResidualInferenceEngine::load_and_validate(
                &model,
                FallbackPolicy::DeterministicBaseline,
            )?;
            println!(
                "Model '{}' v{} valid. SHA-256={} | Features={} | Target={}",
                eng.artefact.model_id,
                eng.artefact.model_version,
                eng.artefact.integrity_sha256,
                eng.artefact.feature_names.len(),
                eng.artefact.output_units
            );
        }
        Commands::Demo { out_dir, skip_r } => {
            let arm = ArmModel::default_6r_650();
            let base_sums = generate_training_data(&out_dir)?;

            if !skip_r {
                let status = Command::new("Rscript")
                    .arg("r_armlearn/experiments/run_pipeline.R")
                    .status()?;
                if !status.success() {
                    return Err("R pipeline execution failed".into());
                }
            }

            let model_path = out_dir.join("residual_model.v1.json");
            let ref_csv = out_dir.join("r_reference_predictions.csv");
            let parity = verify_model_parity(&model_path, &ref_csv, &out_dir.join("parity_report.json"))?;
            if !parity.passed {
                return Err(format!("R-Rust parity check failed: max_diff={}", parity.max_abs_diff_rad).into());
            }

            let eval_report = run_evaluation(&model_path, &out_dir)?;
            let fault_demo = run_fault_and_safety_demo(&model_path)?;

            let demo_report = FullDemoReport {
                schema_version: SCHEMA_REPORT_V1.to_string(),
                robot_model: arm.desc.model_name.clone(),
                robot_config_hash: arm.desc.config_hash(),
                baseline_training_runs: base_sums,
                parity_report: parity,
                evaluation_summary: eval_report.summary,
                fault_and_safety_demo: fault_demo,
                caveats: vec![
                    "Simulator evidence only; inertial parameters carry IllustrativeEstimated provenance.".to_string(),
                    "Collision checks verify geometric capsule/AABB clearance under the model, not physical clearance.".to_string(),
                    "Runtime stops are application-level safeguards; certified hardware E-stop circuits remain mandatory for physical deployment.".to_string(),
                ],
            };
            let demo_json = serde_json::to_string_pretty(&demo_report)?;
            fs::write(out_dir.join("demo_summary.json"), &demo_json)?;
            println!("{demo_json}");
        }
    }
    Ok(())
}
