use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::mpsc::{sync_channel, Receiver, SyncSender, TrySendError};
use std::sync::Arc;
use std::time::Instant;

use arm_adapters::{AdapterError, RobotAdapter};
use arm_control::{JointSpaceController, ResidualInferenceEngine};
use arm_model::ArmModel;
use arm_planner::PlannedTrajectory;
use arm_types::{
    norm_inf, ActuatorCommand, GripperCommand, JointState, PayloadSpec, SupervisorState,
    TelemetryRecord, NUM_JOINTS, SCHEMA_TELEMETRY_V1,
};
use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Debug, Error, Clone, PartialEq)]
pub enum TransitionError {
    #[error("Unauthorized state transition from {from:?} to {to:?} ({reason})")]
    Unauthorized {
        from: SupervisorState,
        to: SupervisorState,
        reason: String,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SupervisorEvent {
    ConnectAndInit,
    InitComplete,
    Arm,
    StartExecution,
    Pause,
    Resume,
    RequestStop,
    StopComplete,
    TriggerFault,
    ClearFault,
    Disconnect,
    Restart,
}

#[derive(Debug, Clone)]
pub struct SupervisorStateMachine {
    state: SupervisorState,
    pub last_fault_reason: Option<String>,
    pub requires_rearm_after_reset: bool,
}

impl Default for SupervisorStateMachine {
    fn default() -> Self {
        Self::new()
    }
}

impl SupervisorStateMachine {
    pub fn new() -> Self {
        Self {
            state: SupervisorState::Disconnected,
            last_fault_reason: None,
            requires_rearm_after_reset: true,
        }
    }

    pub fn state(&self) -> SupervisorState {
        self.state
    }

    pub fn transition(
        &mut self,
        event: SupervisorEvent,
        authorised: bool,
    ) -> Result<SupervisorState, TransitionError> {
        if !authorised {
            return Err(TransitionError::Unauthorized {
                from: self.state,
                to: self.state,
                reason: "Operator/system authorisation flag is false".to_string(),
            });
        }
        use SupervisorEvent as E;
        use SupervisorState as S;
        let next = match (self.state, event) {
            (S::Disconnected, E::ConnectAndInit) => S::Initialising,
            (S::Initialising, E::InitComplete) => S::Ready,
            (S::Ready, E::Arm) => {
                self.requires_rearm_after_reset = false;
                S::Armed
            }
            (S::Armed, E::StartExecution) => {
                if self.requires_rearm_after_reset {
                    return Err(TransitionError::Unauthorized {
                        from: self.state,
                        to: S::Executing,
                        reason: "Explicit re-arm required after reset/restart".to_string(),
                    });
                }
                S::Executing
            }
            (S::Executing, E::Pause) => S::Paused,
            (S::Paused, E::Resume) => S::Executing,
            (S::Executing | S::Paused | S::Armed, E::RequestStop) => S::Stopping,
            (S::Stopping, E::StopComplete) => S::Ready,
            (_, E::TriggerFault) => S::Fault,
            (S::Fault, E::ClearFault) => {
                self.requires_rearm_after_reset = true;
                S::Ready
            }
            (_, E::Disconnect | E::Restart) => {
                self.requires_rearm_after_reset = true;
                S::Disconnected
            }
            (from, _) => {
                return Err(TransitionError::Unauthorized {
                    from,
                    to: from,
                    reason: format!("Event {event:?} invalid in state {from:?}"),
                });
            }
        };
        self.state = next;
        Ok(next)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuntimeConstraintsConfig {
    pub max_telemetry_age_ns: u64,
    pub max_tracking_error_rad: f64,
    pub max_command_step_rad: f64,
    pub max_consecutive_comm_failures: u32,
    pub control_period_ns: u64,
    pub deadline_miss_budget_ns: u64,
}

impl Default for RuntimeConstraintsConfig {
    fn default() -> Self {
        Self {
            max_telemetry_age_ns: 40_000_000,
            max_tracking_error_rad: 0.16,
            max_command_step_rad: 0.18,
            max_consecutive_comm_failures: 2,
            control_period_ns: 10_000_000,
            deadline_miss_budget_ns: 12_000_000,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum ConstraintViolation {
    StaleTelemetry { age_ns: u64, max_age_ns: u64 },
    JointPositionLimit { joint: usize, q_rad: f64 },
    JointVelocityLimit { joint: usize, dq_rad_s: f64 },
    JointAccelerationLimit { joint: usize, ddq_rad_s2: f64 },
    CommandMagnitude { joint: usize, step_rad: f64 },
    WorkspaceBounds { tcp_m: [f64; 3] },
    TrackingErrorExceeded { err_rad: f64, max_rad: f64 },
    CommunicationHealthDegraded { missed: u32 },
}

pub struct RuntimeConstraintChecker;

impl RuntimeConstraintChecker {
    pub fn check_telemetry(
        arm: &ArmModel,
        cfg: &RuntimeConstraintsConfig,
        state: &JointState,
        current_time_ns: u64,
        q_ref: &[f64; NUM_JOINTS],
    ) -> Result<(), ConstraintViolation> {
        let age_ns = current_time_ns.saturating_sub(state.timestamp_ns);
        if age_ns > cfg.max_telemetry_age_ns {
            return Err(ConstraintViolation::StaleTelemetry {
                age_ns,
                max_age_ns: cfg.max_telemetry_age_ns,
            });
        }
        for j in 0..NUM_JOINTS {
            let lim = &arm.desc.joints[j].limits;
            if !state.q[j].is_finite()
                || state.q[j] < lim.pos_min_rad - 0.01
                || state.q[j] > lim.pos_max_rad + 0.01
            {
                return Err(ConstraintViolation::JointPositionLimit {
                    joint: j,
                    q_rad: state.q[j],
                });
            }
            if !state.dq[j].is_finite() || state.dq[j].abs() > lim.vel_max_rad_s * 1.15 {
                return Err(ConstraintViolation::JointVelocityLimit {
                    joint: j,
                    dq_rad_s: state.dq[j],
                });
            }
            if !state.ddq[j].is_finite() || state.ddq[j].abs() > lim.acc_max_rad_s2 * 1.50 {
                return Err(ConstraintViolation::JointAccelerationLimit {
                    joint: j,
                    ddq_rad_s2: state.ddq[j],
                });
            }
            let err = (q_ref[j] - state.q[j]).abs();
            if err > cfg.max_tracking_error_rad {
                return Err(ConstraintViolation::TrackingErrorExceeded {
                    err_rad: err,
                    max_rad: cfg.max_tracking_error_rad,
                });
            }
        }

        let fk = arm.forward_kinematics(&state.q);
        let p = fk.tcp_world.translation_m;
        let wb = &arm.desc.workspace_bounds;
        if p[0] < wb.min_m[0]
            || p[0] > wb.max_m[0]
            || p[1] < wb.min_m[1]
            || p[1] > wb.max_m[1]
            || p[2] < wb.min_z_clearance_m
            || p[2] > wb.max_m[2]
        {
            return Err(ConstraintViolation::WorkspaceBounds { tcp_m: p });
        }
        Ok(())
    }

    pub fn check_command(
        arm: &ArmModel,
        cfg: &RuntimeConstraintsConfig,
        cmd: &ActuatorCommand,
        q_meas: &[f64; NUM_JOINTS],
    ) -> Result<(), ConstraintViolation> {
        if let ActuatorCommand::PositionTarget { q_rad, .. } = cmd {
            for j in 0..NUM_JOINTS {
                let lim = &arm.desc.joints[j].limits;
                if !q_rad[j].is_finite() || q_rad[j] < lim.pos_min_rad || q_rad[j] > lim.pos_max_rad {
                    return Err(ConstraintViolation::JointPositionLimit {
                        joint: j,
                        q_rad: q_rad[j],
                    });
                }
                let step = (q_rad[j] - q_meas[j]).abs();
                if step > cfg.max_command_step_rad {
                    return Err(ConstraintViolation::CommandMagnitude {
                        joint: j,
                        step_rad: step,
                    });
                }
            }
        }
        Ok(())
    }
}

pub struct BoundedTelemetryTx {
    tx: SyncSender<TelemetryRecord>,
    dropped: Arc<AtomicU64>,
}

impl BoundedTelemetryTx {
    pub fn new(capacity: usize) -> (Self, Receiver<TelemetryRecord>, Arc<AtomicU64>) {
        let (tx, rx) = sync_channel(capacity.max(1));
        let dropped = Arc::new(AtomicU64::new(0));
        (
            Self {
                tx,
                dropped: Arc::clone(&dropped),
            },
            rx,
            dropped,
        )
    }

    pub fn try_publish(&self, rec: TelemetryRecord) -> bool {
        match self.tx.try_send(rec) {
            Ok(()) => true,
            Err(TrySendError::Full(_)) | Err(TrySendError::Disconnected(_)) => {
                self.dropped.fetch_add(1, Ordering::Relaxed);
                false
            }
        }
    }

    pub fn dropped_count(&self) -> u64 {
        self.dropped.load(Ordering::Relaxed)
    }
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct TimingStats {
    pub ticks: u64,
    pub mean_tick_us: f64,
    pub max_tick_us: f64,
    pub jitter_std_us: f64,
    pub deadline_misses: u64,
}

pub struct TimingMonitor {
    samples_us: Vec<f64>,
    deadline_us: f64,
    deadline_misses: u64,
}

impl TimingMonitor {
    pub fn new(deadline_ns: u64) -> Self {
        Self {
            samples_us: Vec::with_capacity(2048),
            deadline_us: (deadline_ns as f64) / 1000.0,
            deadline_misses: 0,
        }
    }

    pub fn record_ns(&mut self, elapsed_ns: u64) {
        let us = (elapsed_ns as f64) / 1000.0;
        self.samples_us.push(us);
        if us > self.deadline_us {
            self.deadline_misses += 1;
        }
    }

    pub fn summarize(&self) -> TimingStats {
        if self.samples_us.is_empty() {
            return TimingStats::default();
        }
        let n = self.samples_us.len() as f64;
        let mean = self.samples_us.iter().sum::<f64>() / n;
        let max = self.samples_us.iter().copied().fold(0.0_f64, f64::max);
        let var = self
            .samples_us
            .iter()
            .map(|x| (x - mean) * (x - mean))
            .sum::<f64>()
            / n;
        TimingStats {
            ticks: self.samples_us.len() as u64,
            mean_tick_us: mean,
            max_tick_us: max,
            jitter_std_us: var.sqrt(),
            deadline_misses: self.deadline_misses,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionSummary {
    pub run_id: String,
    pub scenario_id: String,
    pub controller_mode: String,
    pub final_state: SupervisorState,
    pub task_succeeded: bool,
    pub grasped: bool,
    pub placed: bool,
    pub joint_rms_err_rad: f64,
    pub joint_max_err_rad: f64,
    pub tcp_pos_rms_m: f64,
    pub tcp_pos_max_m: f64,
    pub tcp_ori_rms_rad: f64,
    pub command_effort_rad: f64,
    pub constraint_violations: u64,
    pub fallback_activations: u64,
    pub fallback_rate: f64,
    pub stopped_reason: Option<String>,
    pub dropped_telemetry_records: u64,
    pub timing: TimingStats,
    pub execution_time_s: f64,
}

#[allow(clippy::too_many_arguments, clippy::type_complexity)]
pub fn execute_supervised_run<A: RobotAdapter>(
    run_id: &str,
    scenario_id: &str,
    controller_mode: &str,
    arm: &ArmModel,
    adapter: &mut A,
    controller: &mut JointSpaceController,
    plan: &PlannedTrajectory,
    payload_est: &PayloadSpec,
    constraints: &RuntimeConstraintsConfig,
    ml_engine: Option<&ResidualInferenceEngine>,
    telemetry_tx: &BoundedTelemetryTx,
    true_state_probe: Option<&dyn Fn(&A) -> ([f64; NUM_JOINTS], [f64; NUM_JOINTS], f64, bool, bool)>,
) -> ExecutionSummary {
    let mut sm = SupervisorStateMachine::new();
    let mut timing = TimingMonitor::new(constraints.deadline_miss_budget_ns);
    let mut violations = 0_u64;
    let mut fallback_count = 0_u64;
    let mut stopped_reason = None;

    if let Err(e) = adapter.connect() {
        let _ = sm.transition(SupervisorEvent::TriggerFault, true);
        return ExecutionSummary {
            run_id: run_id.to_string(),
            scenario_id: scenario_id.to_string(),
            controller_mode: controller_mode.to_string(),
            final_state: sm.state(),
            task_succeeded: false,
            grasped: false,
            placed: false,
            joint_rms_err_rad: 0.0,
            joint_max_err_rad: 0.0,
            tcp_pos_rms_m: 0.0,
            tcp_pos_max_m: 0.0,
            tcp_ori_rms_rad: 0.0,
            command_effort_rad: 0.0,
            constraint_violations: 1,
            fallback_activations: 0,
            fallback_rate: 0.0,
            stopped_reason: Some(format!("Adapter connect failed: {e}")),
            dropped_telemetry_records: 0,
            timing: timing.summarize(),
            execution_time_s: 0.0,
        };
    }

    let _ = sm.transition(SupervisorEvent::ConnectAndInit, true);
    let _ = sm.transition(SupervisorEvent::InitComplete, true);
    let _ = sm.transition(SupervisorEvent::Arm, true);
    let _ = sm.transition(SupervisorEvent::StartExecution, true);

    controller.reset();
    let dt_s = 1.0 / adapter.capabilities().max_command_rate_hz.max(1.0);
    let total_steps = (plan.total_duration_s / dt_s).ceil() as u64;

    let mut sum_sq_joint = 0.0;
    let mut max_joint_err = 0.0_f64;
    let mut sum_sq_tcp_pos = 0.0;
    let mut max_tcp_pos = 0.0_f64;
    let mut sum_sq_tcp_ori = 0.0;
    let mut effort_acc = 0.0;
    let mut last_cmd_q: Option<[f64; NUM_JOINTS]> = None;
    let mut steps_done = 0_u64;
    let mut last_seg_idx = 0usize;
    let mut grasped_ever = false;
    let mut placed_ok = false;
    let mut comm_failures = 0_u32;

    for step in 0..=total_steps {
        let tick_start = Instant::now();
        let t_s = (step as f64) * dt_s;
        let traj = plan.sample(t_s);
        let seg_idx = plan.active_segment_index(t_s);

        if seg_idx != last_seg_idx {
            for idx in last_seg_idx..seg_idx {
                if let Some(close) = plan.segments[idx].gripper_close_after {
                    let gcmd = if close {
                        GripperCommand::Close {
                            target_width_m: 0.044,
                            max_force_n: 35.0,
                        }
                    } else {
                        GripperCommand::Open
                    };
                    let _ = adapter.command_gripper(gcmd);
                }
            }
            last_seg_idx = seg_idx;
        }

        let meas = match adapter.read_telemetry() {
            Ok(m) => {
                comm_failures = 0;
                m
            }
            Err(e) => {
                comm_failures += 1;
                if comm_failures >= constraints.max_consecutive_comm_failures
                    || matches!(e, AdapterError::CommunicationLost)
                {
                    violations += 1;
                    let _ = adapter.emergency_stop();
                    let _ = sm.transition(SupervisorEvent::TriggerFault, true);
                    stopped_reason = Some(format!("Communication failure: {e}"));
                    break;
                }
                continue;
            }
        };

        let expected_now_ns = 1_000_000_000 + step * ((dt_s * 1e9).round() as u64);
        if let Err(v) =
            RuntimeConstraintChecker::check_telemetry(arm, constraints, &meas, expected_now_ns, &traj.q)
        {
            violations += 1;
            let _ = adapter.emergency_stop();
            let _ = sm.transition(SupervisorEvent::RequestStop, true);
            let _ = sm.transition(SupervisorEvent::StopComplete, true);
            stopped_reason = Some(format!("Runtime constraint stop: {v:?}"));
            break;
        }

        let active_payload = if grasped_ever && !placed_ok {
            payload_est.clone()
        } else {
            PayloadSpec::default()
        };

        let (cmd, diag) = controller.step_position_command(
            arm,
            &traj.q,
            &traj.dq,
            &meas,
            &active_payload,
            dt_s,
            ml_engine,
        );

        if diag.ml_fallback_active {
            fallback_count += 1;
        }

        if diag.ml_request_stop {
            let _ = adapter.emergency_stop();
            let _ = sm.transition(SupervisorEvent::RequestStop, true);
            let _ = sm.transition(SupervisorEvent::StopComplete, true);
            stopped_reason = Some(format!(
                "ML fallback policy requested controlled stop: {}",
                diag.ml_fallback_reason.unwrap_or_default()
            ));
            break;
        }

        if let Err(v) = RuntimeConstraintChecker::check_command(arm, constraints, &cmd, &meas.q) {
            violations += 1;
            let _ = adapter.emergency_stop();
            let _ = sm.transition(SupervisorEvent::TriggerFault, true);
            stopped_reason = Some(format!("Command constraint violation: {v:?}"));
            break;
        }

        if let Err(e) = adapter.send_command(&cmd) {
            violations += 1;
            let _ = adapter.emergency_stop();
            let _ = sm.transition(SupervisorEvent::TriggerFault, true);
            stopped_reason = Some(format!("Adapter send_command rejected: {e}"));
            break;
        }

        let (q_true, dq_true, payload_true_kg, grasped_now, placed_now) =
            if let Some(probe) = true_state_probe {
                probe(adapter)
            } else {
                (meas.q, meas.dq, active_payload.mass_kg, false, false)
            };
        if grasped_now {
            grasped_ever = true;
        }
        if placed_now {
            placed_ok = true;
        }

        let fk_ref = arm.forward_kinematics(&traj.q);
        let fk_true = arm.forward_kinematics(&q_true);
        let tcp_err = arm_types::Pose3::pose_error_world(&fk_true.tcp_world, &fk_ref.tcp_world);
        let tcp_pos_err = (tcp_err[0].powi(2) + tcp_err[1].powi(2) + tcp_err[2].powi(2)).sqrt();
        let tcp_ori_err = (tcp_err[3].powi(2) + tcp_err[4].powi(2) + tcp_err[5].powi(2)).sqrt();

        let j_err: [f64; NUM_JOINTS] = std::array::from_fn(|j| traj.q[j] - q_true[j]);
        let j_inf = norm_inf(&j_err);
        max_joint_err = max_joint_err.max(j_inf);
        sum_sq_joint += j_err.iter().map(|x| x * x).sum::<f64>() / (NUM_JOINTS as f64);
        sum_sq_tcp_pos += tcp_pos_err * tcp_pos_err;
        max_tcp_pos = max_tcp_pos.max(tcp_pos_err);
        sum_sq_tcp_ori += tcp_ori_err * tcp_ori_err;

        let q_cmd_arr = match cmd {
            ActuatorCommand::PositionTarget { q_rad, .. } => q_rad,
            _ => meas.q,
        };
        if let Some(prev_q) = last_cmd_q {
            for j in 0..NUM_JOINTS {
                effort_acc += (q_cmd_arr[j] - prev_q[j]).abs();
            }
        }
        last_cmd_q = Some(q_cmd_arr);

        let rec = TelemetryRecord {
            schema_version: SCHEMA_TELEMETRY_V1.to_string(),
            run_id: run_id.to_string(),
            scenario_id: scenario_id.to_string(),
            controller_mode: controller_mode.to_string(),
            step,
            time_s: t_s,
            timestamp_ns: meas.timestamp_ns,
            q_ref: traj.q,
            dq_ref: traj.dq,
            q_meas: meas.q,
            dq_meas: meas.dq,
            q_true,
            dq_true,
            q_cmd: q_cmd_arr,
            ml_correction_rad: diag.ml_correction_rad,
            ml_fallback_active: diag.ml_fallback_active,
            payload_est_kg: active_payload.mass_kg,
            payload_true_kg,
            motor_temp_c: meas.motor_temp_c.map(|t| t[1]).unwrap_or(38.0),
            tcp_pos_err_m: tcp_pos_err,
            tcp_ori_err_rad: tcp_ori_err,
            supervisor_state: sm.state(),
            grasped: grasped_now,
        };
        telemetry_tx.try_publish(rec);

        steps_done += 1;
        let elapsed_ns = tick_start.elapsed().as_nanos() as u64;
        timing.record_ns(elapsed_ns);
    }

    if sm.state() == SupervisorState::Executing {
        let _ = sm.transition(SupervisorEvent::RequestStop, true);
        let _ = sm.transition(SupervisorEvent::StopComplete, true);
    }

    let denom = steps_done.max(1) as f64;
    ExecutionSummary {
        run_id: run_id.to_string(),
        scenario_id: scenario_id.to_string(),
        controller_mode: controller_mode.to_string(),
        final_state: sm.state(),
        task_succeeded: stopped_reason.is_none() && grasped_ever && placed_ok && violations == 0,
        grasped: grasped_ever,
        placed: placed_ok,
        joint_rms_err_rad: (sum_sq_joint / denom).sqrt(),
        joint_max_err_rad: max_joint_err,
        tcp_pos_rms_m: (sum_sq_tcp_pos / denom).sqrt(),
        tcp_pos_max_m: max_tcp_pos,
        tcp_ori_rms_rad: (sum_sq_tcp_ori / denom).sqrt(),
        command_effort_rad: effort_acc,
        constraint_violations: violations,
        fallback_activations: fallback_count,
        fallback_rate: (fallback_count as f64) / denom,
        stopped_reason,
        dropped_telemetry_records: telemetry_tx.dropped_count(),
        timing: timing.summarize(),
        execution_time_s: (steps_done as f64) * dt_s,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use arm_adapters::MockHardwareAdapter;

    #[test]
    fn state_machine_prevents_auto_motion_after_restart_or_fault() {
        let mut sm = SupervisorStateMachine::new();
        assert_eq!(sm.state(), SupervisorState::Disconnected);
        assert!(sm.transition(SupervisorEvent::StartExecution, true).is_err());

        sm.transition(SupervisorEvent::ConnectAndInit, true).unwrap();
        sm.transition(SupervisorEvent::InitComplete, true).unwrap();
        sm.transition(SupervisorEvent::Arm, true).unwrap();
        sm.transition(SupervisorEvent::StartExecution, true).unwrap();
        sm.transition(SupervisorEvent::TriggerFault, true).unwrap();
        assert_eq!(sm.state(), SupervisorState::Fault);

        sm.transition(SupervisorEvent::ClearFault, true).unwrap();
        assert_eq!(sm.state(), SupervisorState::Ready);
        assert!(sm.transition(SupervisorEvent::StartExecution, true).is_err());

        sm.transition(SupervisorEvent::Arm, true).unwrap();
        sm.transition(SupervisorEvent::Restart, true).unwrap();
        assert_eq!(sm.state(), SupervisorState::Disconnected);
        assert!(sm.transition(SupervisorEvent::StartExecution, true).is_err());
    }

    #[test]
    fn stale_telemetry_and_comm_loss_are_detected() {
        let arm = ArmModel::default_6r_650();
        let cfg = RuntimeConstraintsConfig::default();
        let q = arm_planner::MotionPlanner::home_configuration();
        let stale = JointState {
            q,
            dq: [0.0; 6],
            ddq: [0.0; 6],
            tau_measured: None,
            motor_temp_c: Some([36.0; 6]),
            timestamp_ns: 1_000_000_000,
            seq: 1,
        };
        let res = RuntimeConstraintChecker::check_telemetry(&arm, &cfg, &stale, 1_100_000_000, &q);
        assert!(matches!(res, Err(ConstraintViolation::StaleTelemetry { .. })));

        let mut mock = MockHardwareAdapter::new(q);
        mock.connect().unwrap();
        mock.simulate_comm_loss = true;
        assert!(matches!(mock.read_telemetry(), Err(AdapterError::CommunicationLost)));
    }

    #[test]
    fn bounded_telemetry_queue_drops_without_blocking() {
        let (tx, rx, dropped) = BoundedTelemetryTx::new(2);
        let rec = TelemetryRecord {
            schema_version: SCHEMA_TELEMETRY_V1.to_string(),
            run_id: "r1".to_string(),
            scenario_id: "s1".to_string(),
            controller_mode: "baseline".to_string(),
            step: 0,
            time_s: 0.0,
            timestamp_ns: 0,
            q_ref: [0.0; 6],
            dq_ref: [0.0; 6],
            q_meas: [0.0; 6],
            dq_meas: [0.0; 6],
            q_true: [0.0; 6],
            dq_true: [0.0; 6],
            q_cmd: [0.0; 6],
            ml_correction_rad: [0.0; 6],
            ml_fallback_active: false,
            payload_est_kg: 0.0,
            payload_true_kg: 0.0,
            motor_temp_c: 35.0,
            tcp_pos_err_m: 0.0,
            tcp_ori_err_rad: 0.0,
            supervisor_state: SupervisorState::Executing,
            grasped: false,
        };
        assert!(tx.try_publish(rec.clone()));
        assert!(tx.try_publish(rec.clone()));
        assert!(!tx.try_publish(rec));
        assert_eq!(dropped.load(Ordering::Relaxed), 1);
        assert!(rx.try_recv().is_ok());
    }

    #[test]
    fn timing_monitor_records_overruns() {
        let mut tm = TimingMonitor::new(10_000_000);
        tm.record_ns(200_000);
        tm.record_ns(15_000_000);
        let stats = tm.summarize();
        assert_eq!(stats.ticks, 2);
        assert_eq!(stats.deadline_misses, 1);
        assert!(stats.max_tick_us >= 15000.0);
    }

    #[test]
    fn runtime_constraints_enforce_joint_limits_and_command_steps() {
        let arm = ArmModel::default_6r_650();
        let cfg = RuntimeConstraintsConfig::default();
        let q = arm_planner::MotionPlanner::home_configuration();

        let mut bad_q = q;
        bad_q[1] = 3.2;
        let bad_state = JointState {
            q: bad_q,
            dq: [0.0; 6],
            ddq: [0.0; 6],
            tau_measured: None,
            motor_temp_c: Some([36.0; 6]),
            timestamp_ns: 1_000_000_000,
            seq: 1,
        };
        assert!(matches!(
            RuntimeConstraintChecker::check_telemetry(&arm, &cfg, &bad_state, 1_005_000_000, &q),
            Err(ConstraintViolation::JointPositionLimit { joint: 1, .. })
        ));

        let mut jump_q = q;
        jump_q[0] += 0.35;
        let big_cmd = ActuatorCommand::PositionTarget {
            q_rad: jump_q,
            dq_ff_rad_s: [0.0; 6],
            timestamp_ns: 1_005_000_000,
            seq: 2,
        };
        assert!(matches!(
            RuntimeConstraintChecker::check_command(&arm, &cfg, &big_cmd, &q),
            Err(ConstraintViolation::CommandMagnitude { joint: 0, .. })
        ));
    }
}
