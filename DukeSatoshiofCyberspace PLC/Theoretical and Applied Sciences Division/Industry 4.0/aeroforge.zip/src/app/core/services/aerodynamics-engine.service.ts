import { Injectable, computed, inject, signal } from '@angular/core';
import { AeroFidelityLevel, AerodynamicState } from '../models/aircraft.types';
import { AircraftStateService } from './aircraft-state.service';

@Injectable({
  providedIn: 'root',
})
export class AerodynamicsEngineService {
  private aircraftState = inject(AircraftStateService);

  readonly selectedFidelity = signal<AeroFidelityLevel>('LEVEL_2_VORTEX_LATTICE');
  readonly currentMach = signal<number>(0.785);
  readonly currentAltitudeM = signal<number>(10668); // FL350 = 35,000 ft = 10,668 m
  readonly angleOfAttackDeg = signal<number>(2.4); // alpha
  readonly sideslipDeg = signal<number>(0.0); // beta
  readonly flapDeflectionDeg = signal<number>(0.0);
  readonly elevatorDeflectionDeg = signal<number>(-1.2); // trim

  // ISA Atmosphere helper
  private getAtmosphere(altM: number) {
    const T0 = 288.15; // K
    const P0 = 101325; // Pa
    const gamma = 1.4;
    const R = 287.058;

    let T: number;
    let P: number;
    if (altM <= 11000) {
      // Troposphere (lapse rate 6.5 K/km)
      T = T0 - 0.0065 * altM;
      P = P0 * Math.pow(T / T0, 5.2559);
    } else {
      // Stratosphere isothermal up to 20 km
      T = 216.65;
      const P11 = P0 * Math.pow(216.65 / T0, 5.2559);
      P = P11 * Math.exp((-9.80665 * (altM - 11000)) / (R * T));
    }
    const rho = P / (R * T);
    const soundSpeed = Math.sqrt(gamma * R * T);
    return { T, P, rho, soundSpeed };
  }

  // Aerodynamic State computation
  readonly aeroState = computed<AerodynamicState>(() => {
    const fidelity = this.selectedFidelity();
    const M = this.currentMach();
    const alt = this.currentAltitudeM();
    const alpha = this.angleOfAttackDeg();
    const beta = this.sideslipDeg();
    const flap = this.flapDeflectionDeg();
    const elev = this.elevatorDeflectionDeg();

    const span = this.aircraftState.wingSpan();
    const area = this.aircraftState.wingArea();
    const AR = this.aircraftState.aspectRatio();
    const sweep = this.aircraftState.sweepQuarterChord();
    const sweepRad = (sweep * Math.PI) / 180;
    const tc = this.aircraftState.thicknessRatioRoot() / 100;

    const atmos = this.getAtmosphere(alt);
    const V = M * atmos.soundSpeed;
    const mac = area / span; // approximation
    const dynamicViscosity = (1.458e-6 * Math.pow(atmos.T, 1.5)) / (atmos.T + 110.4);
    const reynoldsNumber = (atmos.rho * V * mac) / dynamicViscosity;

    // Lift curve slope dCL/dalpha (Prandtl-Glauert compressibility correction)
    const betaComp = Math.max(0.2, Math.sqrt(Math.max(0.01, 1 - M * M)));
    const etaAirfoil = 0.95;
    const cL_alpha_rad =
      (2 * Math.PI * AR) /
      (2 + Math.sqrt(4 + (Math.pow(AR * betaComp, 2) / Math.pow(etaAirfoil, 2)) * (1 + Math.pow(Math.tan(sweepRad) / betaComp, 2))));
    const cL_alpha_deg = cL_alpha_rad * (Math.PI / 180);

    // Baseline CL: alpha_0 = -1.2 deg (cambered supercritical airfoil)
    const alpha0 = -1.2 - flap * 0.15;
    const liftCoeff = cL_alpha_deg * (alpha - alpha0);

    // Parasite drag CD0
    const cd0_clean = 0.0178;
    const cd0_flaps = flap > 0 ? (flap / 40) * 0.045 : 0;
    const cd0 = cd0_clean + cd0_flaps;

    // Induced drag factor: Oswald efficiency e
    const oswaldEfficiency = 0.86 - 0.012 * AR;
    const cdInduced = Math.pow(liftCoeff, 2) / (Math.PI * AR * oswaldEfficiency);

    // Compressibility wave drag
    // Korn equation: M_div = 0.87 - 0.1 * CL - 0.7 * tc
    const dragDivergenceMach = 0.865 - 0.1 * Math.abs(liftCoeff) - 0.7 * tc + 0.05 * Math.sin(sweepRad);
    const criticalMach = dragDivergenceMach - 0.035;

    let cdWave = 0.0;
    if (M > criticalMach) {
      const deltaM = M - criticalMach;
      cdWave = 0.002 * Math.pow(deltaM / 0.05, 3.5);
    }

    const totalDrag = cd0 + cdInduced + cdWave;
    const liftToDragRatio = liftCoeff / Math.max(0.0001, totalDrag);

    // Pitching moment CM at aerodynamic centre (approx 25% MAC)
    const cm0 = -0.045 - flap * 0.08;
    const cM_alpha = -0.012; // stable static margin
    const cmElevator = -0.025 * elev;
    const pitchingMoment = cm0 + cM_alpha * alpha + cmElevator;

    // Lateral-directional derivatives
    const cl_beta = -0.0018 * this.aircraftState.dihedral(); // Dihedral effect
    const cn_beta = 0.0022; // Directional weathercock stability

    // Spanwise lift distribution (discrete 11 stations from root eta=0 to tip eta=1)
    const spanwiseLift = [];
    for (let i = 0; i <= 10; i++) {
      const eta = i / 10;
      // Supercritical swept wing load distribution: slightly loaded mid-span
      const elliptic = Math.sqrt(Math.max(0, 1 - eta * eta));
      const washoutFactor = 1 - 0.25 * eta;
      const actualDensity = elliptic * washoutFactor * (1 + 0.12 * Math.sin(eta * Math.PI));
      spanwiseLift.push({
        eta,
        liftDensity: Number(actualDensity.toFixed(3)),
        idealElliptic: Number(elliptic.toFixed(3)),
      });
    }

    return {
      fidelity,
      mach: Number(M.toFixed(3)),
      altitude: Math.round(alt),
      angleAtAttackDeg: Number(alpha.toFixed(2)),
      sideslipAngleDeg: Number(beta.toFixed(2)),
      reynoldsNumber: Math.round(reynoldsNumber),
      liftCoefficient: Number(liftCoeff.toFixed(4)),
      dragCoefficient: Number(totalDrag.toFixed(4)),
      pitchingMomentCoefficient: Number(pitchingMoment.toFixed(4)),
      liftToDragRatio: Number(liftToDragRatio.toFixed(2)),
      cd0: Number(cd0.toFixed(4)),
      cdInduced: Number(cdInduced.toFixed(4)),
      cdWave: Number(cdWave.toFixed(4)),
      criticalMach: Number(criticalMach.toFixed(3)),
      dragDivergenceMach: Number(dragDivergenceMach.toFixed(3)),
      cL_alpha: Number(cL_alpha_deg.toFixed(4)),
      cM_alpha: Number(cM_alpha.toFixed(4)),
      cl_beta: Number(cl_beta.toFixed(4)),
      cn_beta: Number(cn_beta.toFixed(4)),
      spanwiseLift,
    };
  });

  // Drag polar series for graph plotting (CL from 0.0 to 1.6)
  readonly dragPolarCurve = computed(() => {
    const AR = this.aircraftState.aspectRatio();
    const M = this.currentMach();
    const tc = this.aircraftState.thicknessRatioRoot() / 100;
    const cd0 = 0.0178;
    const e = 0.84;

    const points: { cl: number; cd: number; ld: number }[] = [];
    for (let cl = 0.0; cl <= 1.4; cl += 0.05) {
      const cdi = Math.pow(cl, 2) / (Math.PI * AR * e);
      const mdiv = 0.865 - 0.1 * cl - 0.7 * tc;
      let cdw = 0;
      if (M > mdiv - 0.035) {
        cdw = 0.002 * Math.pow((M - (mdiv - 0.035)) / 0.05, 3.5);
      }
      const cd = cd0 + cdi + cdw;
      points.push({
        cl: Number(cl.toFixed(2)),
        cd: Number(cd.toFixed(4)),
        ld: Number((cl / Math.max(0.0001, cd)).toFixed(2)),
      });
    }
    return points;
  });

  setFidelity(fidelity: AeroFidelityLevel): void {
    this.selectedFidelity.set(fidelity);
  }

  setFlightConditions(mach: number, altM: number, alphaDeg: number): void {
    this.currentMach.set(mach);
    this.currentAltitudeM.set(altM);
    this.angleOfAttackDeg.set(alphaDeg);
  }
}
