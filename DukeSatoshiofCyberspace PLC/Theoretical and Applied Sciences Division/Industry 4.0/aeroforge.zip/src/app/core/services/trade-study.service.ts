import { Injectable, computed, inject, signal } from '@angular/core';
import { AircraftStateService } from './aircraft-state.service';

export interface ParetoCandidate {
  id: string;
  name: string;
  spanM: number;
  sweepDeg: number;
  thrustKN: number;
  oewKg: number;
  fuelBurnKg: number;
  rangeNm: number;
  wingRootMargin: number;
  isParetoOptimal: boolean;
}

export interface MonteCarloHistogramBin {
  rangeLabel: string;
  frequency: number;
  relativePct: number;
}

@Injectable({
  providedIn: 'root',
})
export class TradeStudyService {
  private aircraftState = inject(AircraftStateService);

  readonly selectedSweepVariable = signal<'SPAN' | 'SWEEP' | 'BYPASS_RATIO' | 'FUSELAGE_STRETCH'>('SPAN');
  readonly isRunningMonteCarlo = signal<boolean>(false);
  readonly monteCarloIterations = signal<number>(1000);

  // MDO Parameter Sweep & Pareto Frontier
  readonly paretoCandidates = computed<ParetoCandidate[]>(() => {
    const list: ParetoCandidate[] = [
      {
        id: 'CFG-01',
        name: 'Config Alpha (Span 34.0m, AR 9.4)',
        spanM: 34.0,
        sweepDeg: 25.0,
        thrustKN: 120.0,
        oewKg: 42450,
        fuelBurnKg: 10480,
        rangeNm: 3320,
        wingRootMargin: 0.22,
        isParetoOptimal: false, // Low mass, but higher induced drag
      },
      {
        id: 'CFG-02',
        name: 'Config Beta (Span 35.8m, AR 10.5 - Baseline)',
        spanM: 35.8,
        sweepDeg: 25.0,
        thrustKN: 120.0,
        oewKg: 43200,
        fuelBurnKg: 10180,
        rangeNm: 3450,
        wingRootMargin: 0.14,
        isParetoOptimal: true, // Balanced optimal trade
      },
      {
        id: 'CFG-03',
        name: 'Config Gamma (Span 36.8m, AR 11.1)',
        spanM: 36.8,
        sweepDeg: 25.0,
        thrustKN: 124.0,
        oewKg: 43780,
        fuelBurnKg: 9940,
        rangeNm: 3560,
        wingRootMargin: 0.10,
        isParetoOptimal: true, // Lower fuel burn, acceptable margin
      },
      {
        id: 'CFG-04',
        name: 'Config Delta (Span 38.0m, AR 11.8)',
        spanM: 38.0,
        sweepDeg: 26.5,
        thrustKN: 128.0,
        oewKg: 44620,
        fuelBurnKg: 9820,
        rangeNm: 3620,
        wingRootMargin: 0.04,
        isParetoOptimal: false, // Gate limit exceeded (>36m Code C) & low margin
      },
      {
        id: 'CFG-05',
        name: 'Config Epsilon (Span 35.8m, Sweep 28.0° High Mach)',
        spanM: 35.8,
        sweepDeg: 28.0,
        thrustKN: 125.0,
        oewKg: 43480,
        fuelBurnKg: 10320,
        rangeNm: 3410,
        wingRootMargin: 0.12,
        isParetoOptimal: false,
      },
    ];
    return list;
  });

  // Monte Carlo 1,000 Iteration Distribution for Mission Fuel Burn (kg)
  readonly monteCarloDistribution = signal<MonteCarloHistogramBin[]>([
    { rangeLabel: '9,700 - 9,850 kg', frequency: 38, relativePct: 3.8 },
    { rangeLabel: '9,850 - 10,000 kg', frequency: 162, relativePct: 16.2 },
    { rangeLabel: '10,000 - 10,150 kg', frequency: 320, relativePct: 32.0 },
    { rangeLabel: '10,150 - 10,300 kg (Nominal)', frequency: 312, relativePct: 31.2 },
    { rangeLabel: '10,300 - 10,450 kg', frequency: 128, relativePct: 12.8 },
    { rangeLabel: '10,450 - 10,600 kg', frequency: 40, relativePct: 4.0 },
  ]);

  // Sensitivity Ranking (Tornado Diagram Data)
  readonly sensitivityRankings = signal([
    { parameter: 'Cruise Specific Fuel Consumption (TSFC)', sensitivityDeltaPercent: 1.18, rank: 1 },
    { parameter: 'Wing Aspect Ratio (AR)', sensitivityDeltaPercent: -0.84, rank: 2 },
    { parameter: 'Operating Empty Weight (OEW)', sensitivityDeltaPercent: 0.72, rank: 3 },
    { parameter: 'Zero-Lift Parasite Drag (CD0)', sensitivityDeltaPercent: 0.61, rank: 4 },
    { parameter: 'Compressibility Wave Drag (CD_wave)', sensitivityDeltaPercent: 0.38, rank: 5 },
    { parameter: 'Cabin Weight Contingency', sensitivityDeltaPercent: 0.19, rank: 6 },
  ]);

  setSweepVariable(v: 'SPAN' | 'SWEEP' | 'BYPASS_RATIO' | 'FUSELAGE_STRETCH'): void {
    this.selectedSweepVariable.set(v);
  }

  async runMonteCarlo(): Promise<void> {
    this.isRunningMonteCarlo.set(true);
    await new Promise((r) => setTimeout(r, 600));

    // Perturb stochastic distribution slightly
    const base = [
      { rangeLabel: '9,700 - 9,850 kg', frequency: 42 + Math.floor(Math.random() * 8) },
      { rangeLabel: '9,850 - 10,000 kg', frequency: 158 + Math.floor(Math.random() * 10) },
      { rangeLabel: '10,000 - 10,150 kg', frequency: 318 + Math.floor(Math.random() * 15) },
      { rangeLabel: '10,150 - 10,300 kg (Nominal)', frequency: 308 + Math.floor(Math.random() * 12) },
      { rangeLabel: '10,300 - 10,450 kg', frequency: 134 + Math.floor(Math.random() * 10) },
      { rangeLabel: '10,450 - 10,600 kg', frequency: 40 + Math.floor(Math.random() * 6) },
    ];
    const total = base.reduce((s, b) => s + b.frequency, 0);
    this.monteCarloDistribution.set(
      base.map((b) => ({
        ...b,
        relativePct: Number(((b.frequency / total) * 100).toFixed(1)),
      })),
    );
    this.isRunningMonteCarlo.set(false);
  }
}
