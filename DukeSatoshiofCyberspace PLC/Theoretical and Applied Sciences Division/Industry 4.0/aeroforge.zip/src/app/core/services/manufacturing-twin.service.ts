import { Injectable, computed, inject, signal } from '@angular/core';
import { AircraftStateService } from './aircraft-state.service';

export interface SerializedPartRecord {
  partNumber: string;
  serialNumber: string;
  revision: string;
  materialHeatLot: string;
  stationId: string;
  machineId: string;
  operatorId: string;
  timestamp: string;
  dimensionCmmDeviationMm: number;
  qualityDisposition: 'RELEASED' | 'CONCESSION' | 'REWORK_REQUIRED';
}

@Injectable({
  providedIn: 'root',
})
export class ManufacturingTwinService {
  private aircraftState = inject(AircraftStateService);

  // Factory Operational Controls
  readonly annualDeliveryTarget = signal<number>(48); // aircraft per year
  readonly falCapacityBoostPercent = signal<number>(0); // e.g. +20% scenario analysis
  readonly activeFactoryShift = signal<'DAY_SHIFT' | 'EVENING_SHIFT' | 'NIGHT_MAINTENANCE'>('DAY_SHIFT');

  // Serialized Parts Tracking
  readonly serializedParts = signal<SerializedPartRecord[]>([
    {
      partNumber: 'AF100-W-SPAR-F01',
      serialNumber: 'SN-2026-0842-A',
      revision: 'Rev C',
      materialHeatLot: 'LOT-AL7050-8914B',
      stationId: 'WS-02 (5-Axis CNC)',
      machineId: 'DMG-MORI-HSC-04',
      operatorId: 'TECH-7142 (E. Jensen)',
      timestamp: '2026-10-03 08:42:15 UTC',
      dimensionCmmDeviationMm: 0.012,
      qualityDisposition: 'RELEASED',
    },
    {
      partNumber: 'AF100-W-SKIN-UP01',
      serialNumber: 'SN-2026-0842-B',
      revision: 'Rev C',
      materialHeatLot: 'LOT-HEXCEL-AS4-551',
      stationId: 'WS-03 (AFP Layup)',
      machineId: 'ELECTROIMPACT-AFP-01',
      operatorId: 'TECH-4409 (L. Chang)',
      timestamp: '2026-10-03 14:15:20 UTC',
      dimensionCmmDeviationMm: 0.045,
      qualityDisposition: 'RELEASED',
    },
    {
      partNumber: 'AF100-FUS-FRM44',
      serialNumber: 'SN-2026-0840-C',
      revision: 'Rev B',
      materialHeatLot: 'LOT-AL7050-7720A',
      stationId: 'WS-05 (Splice Jig)',
      machineId: 'KUKA-ORBITAL-RIVET-02',
      operatorId: 'TECH-5188 (R. Dubois)',
      timestamp: '2026-10-02 19:30:10 UTC',
      dimensionCmmDeviationMm: 0.028,
      qualityDisposition: 'RELEASED',
    },
    {
      partNumber: 'AF100-W-RIB14-TI',
      serialNumber: 'SN-2026-0839-D',
      revision: 'Rev D',
      materialHeatLot: 'LOT-TIMET-64-9902',
      stationId: 'WS-02 (5-Axis CNC)',
      machineId: 'DMG-MORI-HSC-02',
      operatorId: 'TECH-7142 (E. Jensen)',
      timestamp: '2026-10-01 11:22:45 UTC',
      dimensionCmmDeviationMm: 0.018,
      qualityDisposition: 'RELEASED',
    },
  ]);

  // Factory Floor Metrics Computation
  readonly factoryMetrics = computed(() => {
    const workstations = this.aircraftState.workstations();
    const boost = this.falCapacityBoostPercent() / 100;

    // Total factory WIP
    const totalWipUnits = workstations.reduce((sum, ws) => sum + ws.wipUnits, 0);

    // Active bottlenecks: Station 25 (AFP Composite) and Station 40 (Join)
    const bottleneckStation = workstations.find((ws) => ws.isBottleneck);

    // Baseline takt time needed for target annual delivery:
    // 250 working days * 16 working hours = 4,000 hrs / 48 acft = 83.3 hrs per complete airframe
    // Line takt time ~ 18 hours per station
    const effectiveFalCycleTime = 17.5 * (1 - boost * 0.4);
    const projectedAnnualOutput = Math.round(48 * (1 + boost * 0.38));

    const totalRobots = workstations.reduce((sum, ws) => sum + ws.activeRobotsCount, 0);
    const avgUtilization = Math.round(
      workstations.reduce((sum, ws) => sum + ws.utilizationPercent, 0) / workstations.length,
    );

    return {
      totalWipUnits,
      bottleneckStationName: bottleneckStation?.name || 'None',
      bottleneckUtilization: bottleneckStation?.utilizationPercent || 96,
      effectiveFalCycleTimeHours: Number(effectiveFalCycleTime.toFixed(1)),
      projectedAnnualOutput,
      totalActiveRobots: totalRobots,
      factoryAverageUtilizationPercent: avgUtilization,
      firstPassYieldOverall: 98.4,
    };
  });

  setFalCapacityBoost(percent: number): void {
    this.falCapacityBoostPercent.set(percent);
  }

  setShift(shift: 'DAY_SHIFT' | 'EVENING_SHIFT' | 'NIGHT_MAINTENANCE'): void {
    this.activeFactoryShift.set(shift);
  }
}
