import { Injectable, computed, signal } from '@angular/core';
import { DigitalThreadEdge, DigitalThreadNode } from '../models/aircraft.types';

@Injectable({
  providedIn: 'root',
})
export class DigitalThreadService {
  readonly selectedNodeId = signal<string>('COMP-RIB14');
  readonly filterCategory = signal<string>('ALL');

  // Complete Bidirectional Digital Thread Graph Nodes
  readonly nodes = signal<DigitalThreadNode[]>([
    {
      id: 'REQ-01',
      label: 'REQ-STRUC-012',
      category: 'REQUIREMENT',
      status: 'VERIFIED',
      details: '+2.5g Limit Maneuver & Gust Structural Safety Factor (CS 25.337)',
      metadata: { limit: '2.5g / 3.75g ult', verificationMethod: 'ANALYSIS + TEST' },
    },
    {
      id: 'REQ-02',
      label: 'REQ-PERF-001',
      category: 'REQUIREMENT',
      status: 'VERIFIED',
      details: 'Cruise Mach 0.785 at FL350 ISA with 180 Passengers',
      metadata: { speed: 'Mach 0.785', altitude: '35,000 ft' },
    },
    {
      id: 'SYS-WING',
      label: 'Wing System Architecture',
      category: 'SYSTEM',
      status: 'VERIFIED',
      details: 'Supercritical Transonic Aerodynamic Wing with Integrated Composite Skins',
      metadata: { span: '35.8 m', area: '122.4 m²' },
    },
    {
      id: 'ASM-WBOX',
      label: 'Wing Box Major Assembly',
      category: 'ASSEMBLY',
      status: 'VERIFIED',
      details: 'Primary Torquing Structure: Front/Rear Spars, 24 Ribs, Skins',
      metadata: { stationJoin: 'WS-000 to WS-1790', weight: '8,200 kg' },
    },
    {
      id: 'COMP-RIB14',
      label: 'Wing Rib #14 (Pylon Station)',
      category: 'PART',
      status: 'VERIFIED',
      details: 'High-Load Titanium Rib Transferring 120 kN Turbofan Engine Thrust',
      metadata: { partNumber: 'AF100-W-RIB14-TI', station: 'WS-1400', mass: '385 kg' },
    },
    {
      id: 'COMP-SPAR-AFT',
      label: 'Wing Rear Spar Chord & Web',
      category: 'PART',
      status: 'VERIFIED',
      details: 'Monolithic Al 7050 Extruded & Milled Beam Carrying Gear Trunnion',
      metadata: { partNumber: 'AF100-W-SPAR-A01', mass: '2,120 kg' },
    },
    {
      id: 'MAT-TI-64',
      label: 'Ti-6Al-4V Grade 5 Billet',
      category: 'MATERIAL',
      status: 'VERIFIED',
      details: 'Vacuum Arc Remelted (VAR) Titanium Alloy with High Fatigue Resistance',
      metadata: { yieldStrength: '880 MPa', supplier: 'TIMET Aerospace Lot #8912' },
    },
    {
      id: 'MAT-AL-7050',
      label: 'Al 7050-T7451 Plate',
      category: 'MATERIAL',
      status: 'VERIFIED',
      details: 'Stress-Relieved Thick Plate for Overaging Stress Corrosion Immunity',
      metadata: { yieldStrength: '460 MPa', supplier: 'Kaiser Aluminum Lot #7720' },
    },
    {
      id: 'PROC-5AXIS',
      label: '5-Axis High-Speed Milling',
      category: 'PROCESS',
      status: 'VERIFIED',
      details: 'Monolithic pocket hogging with flood cryogenic cooling to avoid distortion',
      metadata: { spindleRpm: '18,000', program: 'CAM-NC-RIB14-REV-C' },
    },
    {
      id: 'MACH-DMG04',
      label: 'DMG Mori HSC-105 Machining Center',
      category: 'MACHINE',
      status: 'VERIFIED',
      details: 'Linear motor driven 5-axis aerospace horizontal machining station',
      metadata: { location: 'Factory Cell 2B', lastCalibration: '2026-09-15' },
    },
    {
      id: 'INSP-CMM',
      label: 'Zeiss Prismo CMM Inspection',
      category: 'INSPECTION',
      status: 'VERIFIED',
      details: '142 Coordinate Points Inspected: Peak Deviation +0.018 mm (Tol ±0.050 mm)',
      metadata: { reportId: 'CMM-2026-8941', status: 'CONFORMING' },
    },
    {
      id: 'SIM-FEA',
      label: 'SIM-FEA-STATIC-003',
      category: 'SIMULATION',
      status: 'VERIFIED',
      details: 'Nastran/Abaqus Sol 101 Static Stress Under 2.5g Pull-Up (MS = +0.22)',
      metadata: { solverVersion: '2026.2', meshElements: '2,480,000' },
    },
    {
      id: 'TEST-FLIGHT',
      label: 'TC-AF100-CRUISE-02',
      category: 'TEST',
      status: 'VERIFIED',
      details: 'Flight Test Card: High-Speed Buffet Margin & Engine Thrust Response',
      metadata: { telemetryHash: 'SHA256:7f83b165', verdict: 'PASS' },
    },
    {
      id: 'CERT-EVID',
      label: 'EVID-CS-25-301-DOC',
      category: 'EVIDENCE',
      status: 'COMPLIANT',
      details: 'Formal Certification Compliance Dossier Signed by DER Structures',
      metadata: { regulation: 'CS 25.301', signatureDate: '2026-09-30' },
    },
  ]);

  // Directed edges connecting the digital thread
  readonly edges: DigitalThreadEdge[] = [
    { from: 'REQ-01', to: 'SYS-WING', relation: 'Governs' },
    { from: 'REQ-02', to: 'SYS-WING', relation: 'Defines Performance' },
    { from: 'SYS-WING', to: 'ASM-WBOX', relation: 'Decomposes Into' },
    { from: 'ASM-WBOX', to: 'COMP-RIB14', relation: 'Contains' },
    { from: 'ASM-WBOX', to: 'COMP-SPAR-AFT', relation: 'Contains' },
    { from: 'COMP-RIB14', to: 'MAT-TI-64', relation: 'Manufactured From' },
    { from: 'COMP-SPAR-AFT', to: 'MAT-AL-7050', relation: 'Manufactured From' },
    { from: 'COMP-RIB14', to: 'PROC-5AXIS', relation: 'Routed Through' },
    { from: 'PROC-5AXIS', to: 'MACH-DMG04', relation: 'Executed On' },
    { from: 'COMP-RIB14', to: 'INSP-CMM', relation: 'Verified By' },
    { from: 'COMP-RIB14', to: 'SIM-FEA', relation: 'Analyzed In' },
    { from: 'SIM-FEA', to: 'TEST-FLIGHT', relation: 'Validated By' },
    { from: 'TEST-FLIGHT', to: 'CERT-EVID', relation: 'Supplies Proof To' },
  ];

  // Active Ancestry & Descendants for selected node
  readonly selectedNodeAncestry = computed(() => {
    const selId = this.selectedNodeId();
    const allNodes = this.nodes();
    const selNode = allNodes.find((n) => n.id === selId);

    // Find direct parents (edges to selId)
    const parentEdges = this.edges.filter((e) => e.to === selId);
    const parents = parentEdges.map((e) => ({
      node: allNodes.find((n) => n.id === e.from)!,
      relation: e.relation,
    })).filter((item) => item.node !== undefined);

    // Find direct children (edges from selId)
    const childEdges = this.edges.filter((e) => e.from === selId);
    const children = childEdges.map((e) => ({
      node: allNodes.find((n) => n.id === e.to)!,
      relation: e.relation,
    })).filter((item) => item.node !== undefined);

    return {
      currentNode: selNode,
      parents,
      children,
    };
  });

  selectNode(nodeId: string): void {
    this.selectedNodeId.set(nodeId);
  }

  setFilter(category: string): void {
    this.filterCategory.set(category);
  }
}
