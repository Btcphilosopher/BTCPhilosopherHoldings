import { Injectable, signal } from '@angular/core';

export interface CfdIterationResidual {
  iteration: number;
  continuity: number;
  xMomentum: number;
  yMomentum: number;
  zMomentum: number;
  turbulentEnergy: number;
  omegaDissipation: number;
  clCurrent: number;
  cdCurrent: number;
}

export interface CfdConfig {
  meshCellsMillion: number;
  boundaryLayerPrisms: number;
  yPlusTarget: number;
  turbulenceModel: 'K_OMEGA_SST' | 'SPALART_ALLMARAS' | 'REYNOLDS_STRESS_RSM';
  machNumber: number;
  altitudeM: number;
  aoaDeg: number;
  maxIterations: number;
  convergenceCriterion: number;
}

@Injectable({
  providedIn: 'root',
})
export class CfdWorkbenchService {
  readonly isRunning = signal<boolean>(false);
  readonly currentIteration = signal<number>(0);
  readonly maxIterations = signal<number>(180);
  readonly convergenceStatus = signal<'IDLE' | 'SOLVING' | 'CONVERGED' | 'DIVERGED'>('CONVERGED');
  readonly wallClockSec = signal<number>(42.8);
  readonly cpuGpuUtil = signal<number>(89); // %

  readonly cfdConfig = signal<CfdConfig>({
    meshCellsMillion: 14.8,
    boundaryLayerPrisms: 24,
    yPlusTarget: 0.95,
    turbulenceModel: 'K_OMEGA_SST',
    machNumber: 0.785,
    altitudeM: 10668,
    aoaDeg: 2.4,
    maxIterations: 180,
    convergenceCriterion: 1e-5,
  });

  // Iteration history
  readonly residualHistory = signal<CfdIterationResidual[]>(this.generateInitialHistory());

  private generateInitialHistory(): CfdIterationResidual[] {
    const list: CfdIterationResidual[] = [];
    let cont = 1.0;
    let xMom = 0.8;
    let yMom = 0.6;
    let zMom = 0.5;
    let k = 0.9;
    let w = 0.85;

    for (let i = 1; i <= 180; i++) {
      // Natural logarithmic convergence with realistic physical oscillations
      const decay = Math.exp(-i / 35);
      const noise = 0.05 * (Math.sin(i * 0.4) + Math.cos(i * 0.7));
      cont = Math.max(1e-6, 1.2 * decay * (1 + noise) + 1.2e-6);
      xMom = Math.max(1e-6, 0.9 * decay * (1 + noise * 0.8) + 8.5e-7);
      yMom = Math.max(1e-6, 0.7 * decay * (1 + noise * 0.6) + 6.2e-7);
      zMom = Math.max(1e-6, 0.5 * decay * (1 + noise * 0.5) + 4.1e-7);
      k = Math.max(1e-6, 0.95 * decay * (1 + noise * 1.1) + 2.1e-6);
      w = Math.max(1e-6, 0.88 * decay * (1 + noise * 0.9) + 1.8e-6);

      // Cl and Cd settling to asymptotic limits
      const cl = 0.518 + 0.08 * Math.exp(-i / 20) * Math.sin(i * 0.3);
      const cd = 0.0291 + 0.005 * Math.exp(-i / 25) * Math.cos(i * 0.25);

      list.push({
        iteration: i,
        continuity: cont,
        xMomentum: xMom,
        yMomentum: yMom,
        zMomentum: zMom,
        turbulentEnergy: k,
        omegaDissipation: w,
        clCurrent: Number(cl.toFixed(4)),
        cdCurrent: Number(cd.toFixed(5)),
      });
    }
    return list;
  }

  // Trigger solver execution
  async runSyntheticSolver(): Promise<void> {
    if (this.isRunning()) return;

    this.isRunning.set(true);
    this.convergenceStatus.set('SOLVING');
    this.currentIteration.set(0);
    this.residualHistory.set([]);

    const max = this.maxIterations();
    const history: CfdIterationResidual[] = [];

    for (let i = 1; i <= max; i += 6) {
      this.currentIteration.set(i);
      this.wallClockSec.set(Number((i * 0.24).toFixed(1)));
      this.cpuGpuUtil.set(Math.round(85 + Math.random() * 12));

      const decay = Math.exp(-i / 35);
      const noise = 0.05 * (Math.sin(i * 0.4) + Math.cos(i * 0.7));
      const cont = Math.max(1e-6, 1.2 * decay * (1 + noise) + 1.2e-6);
      const xMom = Math.max(1e-6, 0.9 * decay * (1 + noise * 0.8) + 8.5e-7);
      const yMom = Math.max(1e-6, 0.7 * decay * (1 + noise * 0.6) + 6.2e-7);
      const zMom = Math.max(1e-6, 0.5 * decay * (1 + noise * 0.5) + 4.1e-7);
      const k = Math.max(1e-6, 0.95 * decay * (1 + noise * 1.1) + 2.1e-6);
      const w = Math.max(1e-6, 0.88 * decay * (1 + noise * 0.9) + 1.8e-6);
      const cl = 0.518 + 0.08 * Math.exp(-i / 20) * Math.sin(i * 0.3);
      const cd = 0.0291 + 0.005 * Math.exp(-i / 25) * Math.cos(i * 0.25);

      history.push({
        iteration: i,
        continuity: cont,
        xMomentum: xMom,
        yMomentum: yMom,
        zMomentum: zMom,
        turbulentEnergy: k,
        omegaDissipation: w,
        clCurrent: Number(cl.toFixed(4)),
        cdCurrent: Number(cd.toFixed(5)),
      });

      this.residualHistory.set([...history]);
      await new Promise((r) => setTimeout(r, 60));
    }

    this.currentIteration.set(max);
    this.convergenceStatus.set('CONVERGED');
    this.isRunning.set(false);
  }
}
