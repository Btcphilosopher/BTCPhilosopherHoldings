import { Injectable, computed, signal } from '@angular/core';
import {
  AircraftVariant,
  CertificationItem,
  CompositeLaminate,
  ConfigurationStatus,
  FlightTestCard,
  MassPropertyBreakdown,
  MaterialSpec,
  NonConformanceReport,
  QualityMetric,
  Requirement,
  StructuralComponent,
  Workstation,
} from '../models/aircraft.types';

@Injectable({
  providedIn: 'root',
})
export class AircraftStateService {
  // Configuration Status & Version
  readonly configRevision = signal<string>('Rev C2 (ENGINEERING)');
  readonly configStatus = signal<ConfigurationStatus>('ENGINEERING');
  readonly configHash = signal<string>('SHA256:7f83b165a2e16d4e');

  // Stale Simulations Tracking
  readonly staleSimulations = signal<string[]>([
    'Aeroelastic Flutter Boundary (SIM-FLUT-019)',
    'CFD High-AoA Buffet Transonic (SIM-CFD-042)',
  ]);

  // Available Variants
  readonly variants: AircraftVariant[] = [
    {
      id: 'AF-100',
      code: 'AF-100',
      name: 'AF-100 Baseline Commercial',
      tagline: 'Standard 180-Passenger Transcontinental Transport',
      mtowKg: 78000,
      maxFuelKg: 24200,
      passengerCapacity: 180,
      cargoPayloadKg: 19500,
      rangeNm: 3450,
      thrustClassKN: 120.0,
      fuselageLengthM: 37.57,
      wingSpanM: 35.8,
      isCertifiedBaseline: true,
    },
    {
      id: 'AF-100ER',
      code: 'AF-100ER',
      name: 'AF-100ER Extended Range',
      tagline: 'High-Gross Weight Transoceanic Configuration with Auxiliary Center Tank',
      mtowKg: 82500,
      maxFuelKg: 28400,
      passengerCapacity: 180,
      cargoPayloadKg: 19500,
      rangeNm: 4100,
      thrustClassKN: 126.0,
      fuselageLengthM: 37.57,
      wingSpanM: 36.2,
      isCertifiedBaseline: false,
    },
    {
      id: 'AF-100LR',
      code: 'AF-100LR',
      name: 'AF-100LR Long Range',
      tagline: 'Dedicated 160-Pax Premium Extended-Span Thin-Route Cruiser',
      mtowKg: 84000,
      maxFuelKg: 31000,
      passengerCapacity: 160,
      cargoPayloadKg: 17200,
      rangeNm: 4650,
      thrustClassKN: 128.5,
      fuselageLengthM: 37.57,
      wingSpanM: 36.8,
      isCertifiedBaseline: false,
    },
    {
      id: 'AF-100F',
      code: 'AF-100F',
      name: 'AF-100F Dedicated Freighter',
      tagline: 'Main-Deck Cargo Door, Reinforced Floor Grid, 28 Tonnes Payload',
      mtowKg: 81000,
      maxFuelKg: 23000,
      passengerCapacity: 0,
      cargoPayloadKg: 28200,
      rangeNm: 2850,
      thrustClassKN: 124.0,
      fuselageLengthM: 37.57,
      wingSpanM: 35.8,
      isCertifiedBaseline: false,
    },
    {
      id: 'AF-100M',
      code: 'AF-100M',
      name: 'AF-100M Combi Multi-Mission',
      tagline: 'Flexible Forward Cabin (96 Pax) & Aft Containerized Freight Area',
      mtowKg: 79500,
      maxFuelKg: 25000,
      passengerCapacity: 96,
      cargoPayloadKg: 23400,
      rangeNm: 3200,
      thrustClassKN: 122.0,
      fuselageLengthM: 37.57,
      wingSpanM: 35.8,
      isCertifiedBaseline: false,
    },
  ];

  readonly activeVariant = signal<AircraftVariant>(this.variants[0]);

  // Parametric Geometry Signals
  readonly fuselageLength = signal<number>(37.57); // m
  readonly fuselageDiameter = signal<number>(3.95); // m
  readonly wingSpan = signal<number>(35.8); // m
  readonly wingArea = signal<number>(122.4); // m²
  readonly sweepQuarterChord = signal<number>(25.0); // deg
  readonly taperRatio = signal<number>(0.28);
  readonly dihedral = signal<number>(5.5); // deg
  readonly thicknessRatioRoot = signal<number>(13.2); // %
  readonly thicknessRatioTip = signal<number>(9.8); // %
  readonly engineThrustClass = signal<number>(120.0); // kN per engine
  readonly cabinSeatsCount = signal<number>(180);

  // Computed Aspect Ratio
  readonly aspectRatio = computed(() => {
    const b = this.wingSpan();
    const s = this.wingArea();
    return Number((Math.pow(b, 2) / s).toFixed(2));
  });

  // Material Library
  readonly materials = signal<MaterialSpec[]>([
    {
      id: 'MAT-AL-7050',
      name: 'Aluminium 7050-T7451 Plate',
      category: 'ALUMINIUM',
      density: 2830,
      yieldStrengthMPa: 460,
      ultimateStrengthMPa: 510,
      elasticModulusGPa: 71.7,
      poissonsRatio: 0.33,
      thermalExpansionPPM: 23.5,
      allowableFatigueCycles: 1e7,
    },
    {
      id: 'MAT-CFRP-AS4',
      name: 'Carbon/Epoxy AS4/8552 UD Prepreg',
      category: 'CARBON_COMPOSITE',
      density: 1580,
      yieldStrengthMPa: 1850,
      ultimateStrengthMPa: 2200,
      elasticModulusGPa: 141.0,
      poissonsRatio: 0.28,
      thermalExpansionPPM: -0.2,
      allowableFatigueCycles: 5e7,
    },
    {
      id: 'MAT-TI-6AL4V',
      name: 'Titanium Ti-6Al-4V Grade 5',
      category: 'TITANIUM',
      density: 4430,
      yieldStrengthMPa: 880,
      ultimateStrengthMPa: 950,
      elasticModulusGPa: 113.8,
      poissonsRatio: 0.34,
      thermalExpansionPPM: 8.6,
      allowableFatigueCycles: 2e7,
    },
    {
      id: 'MAT-STL-300M',
      name: 'High-Strength Steel 300M (Landing Gear)',
      category: 'STEEL',
      density: 7850,
      yieldStrengthMPa: 1620,
      ultimateStrengthMPa: 1930,
      elasticModulusGPa: 205.0,
      poissonsRatio: 0.30,
      thermalExpansionPPM: 11.2,
      allowableFatigueCycles: 1e6,
    },
    {
      id: 'MAT-INC-718',
      name: 'Inconel 718 Nickel Superalloy (Turbine)',
      category: 'NICKEL_ALLOY',
      density: 8190,
      yieldStrengthMPa: 1100,
      ultimateStrengthMPa: 1375,
      elasticModulusGPa: 205.0,
      poissonsRatio: 0.29,
      thermalExpansionPPM: 13.0,
      allowableFatigueCycles: 3e7,
    },
  ]);

  // Structural Components List
  readonly structuralComponents = signal<StructuralComponent[]>([
    {
      id: 'STR-W-SPAR-FWD',
      name: 'Wing Front Spar Assembly (Left & Right)',
      parentSubsystem: 'Wing Structure',
      materialId: 'MAT-AL-7050',
      materialName: 'Aluminium 7050-T7451',
      nominalThicknessMm: 14.5,
      calculatedStressMPa: 298.5,
      allowableStressMPa: 460.0,
      marginOfSafety: 0.18,
      bucklingRatio: 1.42,
      fatigueLifePercentage: 18.2,
      weightKg: 1840,
      inspectionStatus: 'CONFORMING',
    },
    {
      id: 'STR-W-SPAR-AFT',
      name: 'Wing Rear Spar & Landing Gear Trunnion Joint',
      parentSubsystem: 'Wing Structure',
      materialId: 'MAT-AL-7050',
      materialName: 'Aluminium 7050-T7451',
      nominalThicknessMm: 18.0,
      calculatedStressMPa: 342.0,
      allowableStressMPa: 460.0,
      marginOfSafety: 0.14,
      bucklingRatio: 1.35,
      fatigueLifePercentage: 24.5,
      weightKg: 2120,
      inspectionStatus: 'CONFORMING',
    },
    {
      id: 'STR-W-SKIN-UPPER',
      name: 'Wing Upper Compression Skin Panel',
      parentSubsystem: 'Wing Structure',
      materialId: 'MAT-CFRP-AS4',
      materialName: 'Carbon/Epoxy AS4/8552',
      nominalThicknessMm: 12.0,
      calculatedStressMPa: 420.0,
      allowableStressMPa: 1850.0,
      marginOfSafety: 0.85,
      bucklingRatio: 1.88,
      fatigueLifePercentage: 8.5,
      weightKg: 2480,
      inspectionStatus: 'CONFORMING',
    },
    {
      id: 'STR-W-RIB-14',
      name: 'Wing Rib #14 (Pylon Mount Station WS-1400)',
      parentSubsystem: 'Wing Structure',
      materialId: 'MAT-TI-6AL4V',
      materialName: 'Titanium Ti-6Al-4V',
      nominalThicknessMm: 22.0,
      calculatedStressMPa: 610.0,
      allowableStressMPa: 880.0,
      marginOfSafety: 0.22,
      bucklingRatio: 1.65,
      fatigueLifePercentage: 14.1,
      weightKg: 385,
      inspectionStatus: 'CONFORMING',
    },
    {
      id: 'STR-FUS-FRM-44',
      name: 'Fuselage Frame Station 44 (Wing-to-Body Carrythrough)',
      parentSubsystem: 'Fuselage Structure',
      materialId: 'MAT-AL-7050',
      materialName: 'Aluminium 7050-T7451',
      nominalThicknessMm: 16.0,
      calculatedStressMPa: 310.0,
      allowableStressMPa: 460.0,
      marginOfSafety: 0.16,
      bucklingRatio: 1.50,
      fatigueLifePercentage: 19.8,
      weightKg: 780,
      inspectionStatus: 'CONFORMING',
    },
    {
      id: 'STR-LG-TRUNNION',
      name: 'Main Landing Gear Main Cylinder / Trunnion Beam',
      parentSubsystem: 'Landing Gear',
      materialId: 'MAT-STL-300M',
      materialName: 'High-Strength Steel 300M',
      nominalThicknessMm: 35.0,
      calculatedStressMPa: 950.0,
      allowableStressMPa: 1620.0,
      marginOfSafety: 0.24,
      bucklingRatio: 2.10,
      fatigueLifePercentage: 12.0,
      weightKg: 1260,
      inspectionStatus: 'CONFORMING',
    },
  ]);

  // Composite Laminate
  readonly wingLaminate = signal<CompositeLaminate>({
    id: 'LAM-W-SKIN-01',
    partName: 'Wing Box Upper Skin Laminate (Station WS-800 to WS-1600)',
    plyCount: 48,
    plyThicknessMm: 0.185,
    stackingSequence: [0, 45, -45, 90, 0, 45, -45, 90, 0, 0, 45, -45],
    isSymmetric: true,
    isBalanced: true,
    cureCycleHours: 7.5,
    autoclaveTempC: 180,
    autoclavePressureBar: 7.0,
    tsaiWuFailureIndex: 0.42,
    delaminationRiskIndex: 0.11,
  });

  // Requirements Database (Bidirectional Traceability)
  readonly requirements = signal<Requirement[]>([
    {
      id: 'REQ-PERF-001',
      title: 'Design Cruise Mach & Altitude',
      description: 'The aircraft shall sustain economic cruise at Mach 0.785 at or above FL350 ISA conditions with 180 passengers.',
      source: 'Program Mission Specification §3.1',
      rationale: 'Airline fleet scheduling and ATC airway slot interoperability.',
      type: 'PERFORMANCE',
      priority: 'CRITICAL',
      nominalValue: 0.785,
      limitValue: 0.82,
      unit: 'Mach',
      unitAviation: 'Mach',
      verificationMethod: 'SIMULATION',
      status: 'VERIFIED',
      owner: 'Aero Chief Engineer',
      revision: 'Rev C',
      targetObjectId: 'AF-100',
      verifiedBySimulationId: 'SIM-AERO-042',
      evidenceRef: 'EVID-CRUISE-POLAR-01',
    },
    {
      id: 'REQ-PERF-002',
      title: 'Maximum Takeoff Field Length (SL ISA+15°C)',
      description: 'Takeoff distance at MTOW to clear 35 ft obstacle shall not exceed 1,950 m under SL ISA+15°C condition.',
      source: 'Customer Operating Specification §2.4',
      rationale: 'Ensures operation from medium-length regional runways worldwide.',
      type: 'PERFORMANCE',
      priority: 'CRITICAL',
      nominalValue: 1842,
      limitValue: 1950,
      unit: 'm',
      unitAviation: 'ft',
      verificationMethod: 'SIMULATION',
      status: 'COMPLIANT',
      owner: 'Flight Physics Team',
      revision: 'Rev B',
      targetObjectId: 'AF-100',
      verifiedBySimulationId: 'SIM-TO-009',
      evidenceRef: 'EVID-TO-FIELD-09',
    },
    {
      id: 'REQ-STRUC-012',
      title: 'Limit & Ultimate Maneuver Load Factors',
      description: 'Primary airframe structure must withstand limit maneuver loads of +2.5g and -1.0g with 1.5 safety factor.',
      source: 'CS 25.337 / FAR 25.337',
      rationale: 'Structural integrity during severe turbulence and sudden maneuvers.',
      type: 'STRUCTURAL',
      priority: 'CRITICAL',
      nominalValue: 2.5,
      limitValue: 3.75, // ultimate
      unit: 'g',
      unitAviation: 'g',
      verificationMethod: 'ANALYSIS',
      status: 'VERIFIED',
      owner: 'Structures Lead',
      revision: 'Rev D',
      targetObjectId: 'STR-W-SPAR-AFT',
      verifiedBySimulationId: 'SIM-FEA-STATIC-003',
      evidenceRef: 'EVID-FEA-LOADCASE-03',
    },
    {
      id: 'REQ-AIR-008',
      title: 'ICAO Aerodrome Reference Code C Clearance',
      description: 'Maximum wingspan must remain strictly less than 36.00 meters for unrestricted gate access.',
      source: 'ICAO Annex 14 Code C',
      rationale: 'Airport ground handling and taxiway clearance compliance.',
      type: 'MISSION',
      priority: 'HIGH',
      nominalValue: 35.8,
      limitValue: 36.0,
      unit: 'm',
      unitAviation: 'ft',
      verificationMethod: 'INSPECTION',
      status: 'COMPLIANT',
      owner: 'Configuration Manager',
      revision: 'Rev A',
      targetObjectId: 'AF-100',
      evidenceRef: 'EVID-CAD-SPANGATE-01',
    },
    {
      id: 'REQ-PROP-004',
      title: 'Specific Fuel Consumption (TSFC) at Cruise',
      description: 'Cruise TSFC shall be no greater than 0.525 lb/(lbf·hr) [14.88 g/(kN·s)] at M 0.785, FL350.',
      source: 'Engine RFP Baseline 2026',
      rationale: 'Direct operating cost and CO2 emissions guarantee.',
      type: 'PROPULSION',
      priority: 'HIGH',
      nominalValue: 0.518,
      limitValue: 0.525,
      unit: 'lb/(lbf·hr)',
      unitAviation: 'lb/(lbf·hr)',
      verificationMethod: 'TEST',
      status: 'VERIFIED',
      owner: 'Propulsion Lead',
      revision: 'Rev B',
      targetObjectId: 'PROP-ENGINE-01',
      verifiedBySimulationId: 'SIM-THERMO-BRAYTON-01',
      evidenceRef: 'EVID-PROP-TEST-04',
    },
    {
      id: 'REQ-SYS-021',
      title: 'Electrical Triple Redundancy Bus Isolation',
      description: 'Failure of any two electrical power sources shall not depower Essential AC and DC flight control buses.',
      source: 'CS 25.1309 / FAR 25.1309',
      rationale: 'Loss of critical navigation or fly-by-wire computers must be extremely improbable (<10^-9).',
      type: 'SAFETY',
      priority: 'CRITICAL',
      nominalValue: 3,
      limitValue: 3,
      unit: 'sources',
      unitAviation: 'sources',
      verificationMethod: 'DEMONSTRATION',
      status: 'COMPLIANT',
      owner: 'Systems Integration Lead',
      revision: 'Rev C',
      targetObjectId: 'SYS-ELEC-BUS',
      verifiedBySimulationId: 'SIM-ELEC-FAIL-02',
      evidenceRef: 'EVID-SYS-SAFETY-21',
    },
    {
      id: 'REQ-MFG-005',
      title: 'Final Assembly Line Takt Time',
      description: 'Final assembly line cycle time at Station 40 (Join & Systems) must not exceed 18.0 working hours.',
      source: 'Industrial Operations Master Plan',
      rationale: 'Ensures target monthly output rate of 42 aircraft per year per line.',
      type: 'MANUFACTURING',
      priority: 'HIGH',
      nominalValue: 17.2,
      limitValue: 18.0,
      unit: 'hours',
      unitAviation: 'hours',
      verificationMethod: 'SIMULATION',
      status: 'IN_PROGRESS',
      owner: 'Manufacturing Lead',
      revision: 'Rev B',
      targetObjectId: 'FAL-STATION-40',
      evidenceRef: 'EVID-MFG-TAKT-05',
    },
  ]);

  // Mass Properties Computation (Reactive to Geometry & Component Mass)
  readonly massProperties = computed<MassPropertyBreakdown>(() => {
    const variant = this.activeVariant();
    const span = this.wingSpan();
    const area = this.wingArea();
    const fuselageL = this.fuselageLength();

    // Wing mass scales with span, area, and aspect ratio:
    // M_wing ~ k * (span^1.5 * S^0.5)
    const baseWingMass = 8200;
    const spanRatio = span / 35.8;
    const areaRatio = area / 122.4;
    const wingStructuralMass = baseWingMass * Math.pow(spanRatio, 1.45) * Math.pow(areaRatio, 0.4);

    // Fuselage mass scales with length
    const baseFuselageMass = 9600;
    const fusRatio = fuselageL / 37.57;
    const fuselageStructuralMass = baseFuselageMass * Math.pow(fusRatio, 1.15);

    // Empennage & Nacelle structures
    const empennageMass = 2300;
    const nacellesMounts = 1850;

    const structuralMass = wingStructuralMass + fuselageStructuralMass + empennageMass + nacellesMounts;
    const propulsionMass = 6800 + (this.engineThrustClass() - 120) * 18; // 2x engines + systems
    const systemsMass = 5900;
    const interiorsMass = 4600 + (this.cabinSeatsCount() - 180) * 14.5;
    const avionicsMass = 1250;
    const operatingItemsMass = 1950;

    const oew = Math.round(
      structuralMass + propulsionMass + systemsMass + interiorsMass + avionicsMass + operatingItemsMass,
    );

    const mtow = variant.mtowKg;
    const maxFuel = variant.maxFuelKg;
    const maxPayload = variant.cargoPayloadKg;

    // Baseline mission loading
    const currentPayload = 18000; // 180 pax + bags
    const currentFuel = 16800; // 2,500 NM mission fuel
    const currentGrossWeight = oew + currentPayload + currentFuel;
    const mzfw = oew + maxPayload;
    const mlw = Math.round(mtow * 0.865);

    // CG calculations (% MAC)
    const macLength = 4.19;
    const macLeadingEdgeX = 14.85;
    // Wing span increase shifts structural CG slightly aft/outboard
    const cgX = 15.89 + (spanRatio - 1.0) * 0.45;
    const cgMacPercent = Number((((cgX - macLeadingEdgeX) / macLength) * 100).toFixed(1));

    return {
      oew,
      mtow,
      mlw,
      mzfw,
      maxPayload,
      maxFuel,
      currentFuel,
      currentPayload,
      currentGrossWeight,
      structuralMass: Math.round(structuralMass),
      propulsionMass: Math.round(propulsionMass),
      systemsMass: Math.round(systemsMass),
      interiorsMass: Math.round(interiorsMass),
      avionicsMass: Math.round(avionicsMass),
      operatingItemsMass: Math.round(operatingItemsMass),
      cgX: Number(cgX.toFixed(2)),
      cgY: 0.0,
      cgZ: 1.82,
      cgMacPercent,
      macLength,
      macLeadingEdgeX,
      staticMarginPercent: Number((32.0 - cgMacPercent).toFixed(1)),
      ixx: 1850000,
      iyy: 3420000,
      izz: 4980000,
      ixz: 145000,
      baselineOew: 42800,
      currentVarianceKg: oew - 42800,
      reserveBudgetKg: 780,
    };
  });

  // Selected Component for Engineering Inspector
  readonly selectedComponent = signal<StructuralComponent | null>(null);

  // Factory Floor Workstations
  readonly workstations = signal<Workstation[]>([
    {
      id: 'WS-01',
      stationNumber: 1,
      name: 'Station 10: Raw Material Intake & Automated Ingot NDT',
      description: 'High-energy X-ray and ultrasonic scanning of titanium and 7050 billet stock.',
      taktTimeHours: 8.0,
      actualCycleTimeHours: 7.2,
      wipUnits: 4,
      utilizationPercent: 88,
      isBottleneck: false,
      activeRobotsCount: 2,
      defectCountLast10Units: 0,
      status: 'OPTIMAL',
    },
    {
      id: 'WS-02',
      stationNumber: 2,
      name: 'Station 20: 5-Axis High-Speed CNC Machining Cell',
      description: 'Milling of monolithic wing ribs and spar chords with laser tool metrology.',
      taktTimeHours: 14.0,
      actualCycleTimeHours: 13.6,
      wipUnits: 3,
      utilizationPercent: 94,
      isBottleneck: false,
      activeRobotsCount: 4,
      defectCountLast10Units: 1,
      status: 'RUNNING',
    },
    {
      id: 'WS-03',
      stationNumber: 3,
      name: 'Station 25: Automated Fiber Placement (AFP) Composite Layup',
      description: 'Robotic placement of AS4/8552 carbon prepreg tow on curved wing skin tooling.',
      taktTimeHours: 18.0,
      actualCycleTimeHours: 17.8,
      wipUnits: 2,
      utilizationPercent: 96,
      isBottleneck: true,
      activeRobotsCount: 6,
      defectCountLast10Units: 0,
      status: 'CONSTRAINED',
    },
    {
      id: 'WS-04',
      stationNumber: 4,
      name: 'Station 30: Wing Box Major Structural Assembly Jig',
      description: 'Automatic drilling, countersinking, and Hi-Lite fastener insertion across skins and spars.',
      taktTimeHours: 18.0,
      actualCycleTimeHours: 17.2,
      wipUnits: 2,
      utilizationPercent: 92,
      isBottleneck: false,
      activeRobotsCount: 8,
      defectCountLast10Units: 2,
      status: 'RUNNING',
    },
    {
      id: 'WS-05',
      stationNumber: 5,
      name: 'Station 40: Fuselage Barrel Splice & Pressure Bulkhead',
      description: 'Orbital friction-stir and robotic riveted circumferential join of forward, mid, aft barrels.',
      taktTimeHours: 18.0,
      actualCycleTimeHours: 16.9,
      wipUnits: 1,
      utilizationPercent: 89,
      isBottleneck: false,
      activeRobotsCount: 6,
      defectCountLast10Units: 1,
      status: 'RUNNING',
    },
    {
      id: 'WS-06',
      stationNumber: 6,
      name: 'Station 50: Final Assembly Line (FAL) Wing-to-Body Join',
      description: 'Laser-guided crane alignment and high-strength titanium pin installation.',
      taktTimeHours: 18.0,
      actualCycleTimeHours: 17.5,
      wipUnits: 1,
      utilizationPercent: 95,
      isBottleneck: false,
      activeRobotsCount: 4,
      defectCountLast10Units: 0,
      status: 'OPTIMAL',
    },
    {
      id: 'WS-07',
      stationNumber: 7,
      name: 'Station 60: Cabin Interior & Avionics Bay Installation',
      description: 'Wiring harness continuity check, IMA rack seating, seating installation.',
      taktTimeHours: 16.0,
      actualCycleTimeHours: 15.4,
      wipUnits: 2,
      utilizationPercent: 84,
      isBottleneck: false,
      activeRobotsCount: 1,
      defectCountLast10Units: 2,
      status: 'RUNNING',
    },
    {
      id: 'WS-08',
      stationNumber: 8,
      name: 'Station 70: Turbofan Engine Hang & Pylon Integration',
      description: 'Mounting of synthetic 120 kN class engines, hydraulic bleed lines, electrical harness.',
      taktTimeHours: 12.0,
      actualCycleTimeHours: 11.2,
      wipUnits: 1,
      utilizationPercent: 82,
      isBottleneck: false,
      activeRobotsCount: 2,
      defectCountLast10Units: 0,
      status: 'OPTIMAL',
    },
    {
      id: 'WS-09',
      stationNumber: 9,
      name: 'Station 80: High-Bay Robotic Primer & Exterior Livery Paint',
      description: 'Airless electrostatic robotic spray booths with environmental solvent capture.',
      taktTimeHours: 24.0,
      actualCycleTimeHours: 23.5,
      wipUnits: 1,
      utilizationPercent: 91,
      isBottleneck: false,
      activeRobotsCount: 4,
      defectCountLast10Units: 0,
      status: 'RUNNING',
    },
    {
      id: 'WS-10',
      stationNumber: 10,
      name: 'Station 90: Integrated Systems Ground Power & Hydro Testing',
      description: 'Full electrical bus power-up, 5,000 psi hydraulic pressure proof, cabin leak test.',
      taktTimeHours: 14.0,
      actualCycleTimeHours: 13.8,
      wipUnits: 1,
      utilizationPercent: 87,
      isBottleneck: false,
      activeRobotsCount: 0,
      defectCountLast10Units: 1,
      status: 'OPTIMAL',
    },
    {
      id: 'WS-11',
      stationNumber: 11,
      name: 'Station 95: Ultrasonic C-Scan Phase Array & Radiography NDI',
      description: 'Full composite skin delamination verification, automated defect logging.',
      taktTimeHours: 10.0,
      actualCycleTimeHours: 9.4,
      wipUnits: 1,
      utilizationPercent: 78,
      isBottleneck: false,
      activeRobotsCount: 2,
      defectCountLast10Units: 0,
      status: 'OPTIMAL',
    },
    {
      id: 'WS-12',
      stationNumber: 12,
      name: 'Station 100: Pre-Flight Acceptance & Engine Run-Up Bay',
      description: 'APU start, full thrust run, compass swing, pre-delivery flight test prep.',
      taktTimeHours: 16.0,
      actualCycleTimeHours: 15.0,
      wipUnits: 1,
      utilizationPercent: 85,
      isBottleneck: false,
      activeRobotsCount: 0,
      defectCountLast10Units: 0,
      status: 'OPTIMAL',
    },
  ]);

  // Quality & NDI Metrics
  readonly qualityMetrics = signal<QualityMetric[]>([
    {
      featureName: 'Wing Box Spar Hole Diameter (Station WS-1400)',
      nominalMm: 12.7,
      upperToleranceMm: 12.725,
      lowerToleranceMm: 12.685,
      measuredMeanMm: 12.704,
      stdDeviationMm: 0.0042,
      cp: 1.58,
      cpk: 1.51,
      firstPassYieldPercent: 99.4,
      defectRatePPM: 32,
    },
    {
      featureName: 'Composite Wing Skin Thickness Variation',
      nominalMm: 12.0,
      upperToleranceMm: 12.4,
      lowerToleranceMm: 11.6,
      measuredMeanMm: 12.06,
      stdDeviationMm: 0.062,
      cp: 2.15,
      cpk: 1.83,
      firstPassYieldPercent: 99.8,
      defectRatePPM: 14,
    },
    {
      featureName: 'Fuselage Circumferential Splice Step Alignment',
      nominalMm: 0.0,
      upperToleranceMm: 0.5,
      lowerToleranceMm: -0.5,
      measuredMeanMm: 0.08,
      stdDeviationMm: 0.095,
      cp: 1.75,
      cpk: 1.47,
      firstPassYieldPercent: 98.7,
      defectRatePPM: 85,
    },
  ]);

  // Non-Conformance Reports (NCR)
  readonly ncrs = signal<NonConformanceReport[]>([
    {
      ncrId: 'NCR-2026-089',
      partNumber: 'AF100-W-RIB14-TI',
      partName: 'Rib #14 Pylon Attachment Web',
      stationId: 'WS-02 (5-Axis CNC)',
      severity: 'MINOR',
      discrepancy: 'Bore roughness Ra 1.4 µm vs drawing limit Ra 0.8 µm on non-critical tooling hole #4.',
      rootCause: 'Carbide reamer tool wear after 48 parts.',
      disposition: 'USE_AS_IS',
      status: 'CLOSED',
      createdAt: '2026-09-28',
    },
    {
      ncrId: 'NCR-2026-094',
      partNumber: 'AF100-FUS-SKIN-M4',
      partName: 'Mid-Fuselage Al-Li Lower Skin Sheet',
      stationId: 'WS-05 (Splice Cell)',
      severity: 'MAJOR',
      discrepancy: 'Surface scratch depth 0.12 mm exceeding allowable 0.05 mm polish threshold near Frame 38.',
      rootCause: 'Handling dolly rubber pad detachment during transfer.',
      disposition: 'REWORK',
      status: 'INVESTIGATING',
      createdAt: '2026-10-02',
    },
  ]);

  // Certification Items Matrix
  readonly certificationItems = signal<CertificationItem[]>([
    {
      id: 'CERT-CS-25-101',
      regulationCode: 'CS 25.101',
      title: 'General Flight Performance Compliance',
      category: 'PERFORMANCE',
      complianceMethod: 'ANALYSIS',
      associatedRequirementId: 'REQ-PERF-001',
      testCardRef: 'TC-01 (Takeoff Field)',
      analysisReportRef: 'AF-REP-PERF-2026-01',
      complianceStatus: 'COMPLIANT',
      evidenceHash: 'SHA256:d8a2...3f1c',
      complianceOfficer: 'H. Lindemann (EASA DER)',
    },
    {
      id: 'CERT-CS-25-301',
      regulationCode: 'CS 25.301',
      title: 'Loads & Structural Strength Proof',
      category: 'STRUCTURES',
      complianceMethod: 'TEST',
      associatedRequirementId: 'REQ-STRUC-012',
      testCardRef: 'TC-03 (2.5g Pull-Up & Gust)',
      analysisReportRef: 'AF-REP-STRUC-2026-04',
      complianceStatus: 'COMPLIANT',
      evidenceHash: 'SHA256:4b91...7e8a',
      complianceOfficer: 'M. Vance (FAA DER)',
    },
    {
      id: 'CERT-CS-25-571',
      regulationCode: 'CS 25.571',
      title: 'Damage-Tolerance and Fatigue Evaluation of Structure',
      category: 'STRUCTURES',
      complianceMethod: 'ANALYSIS',
      associatedRequirementId: 'REQ-STRUC-012',
      testCardRef: 'TC-07 (Fatigue Cycle Spectrum)',
      analysisReportRef: 'AF-REP-DT-2026-08',
      complianceStatus: 'OPEN_ANALYSIS',
      evidenceHash: 'SHA256:a192...28ec',
      complianceOfficer: 'M. Vance (FAA DER)',
    },
    {
      id: 'CERT-CS-25-1309',
      regulationCode: 'CS 25.1309',
      title: 'Equipment, Systems, and Installations Safety Assessment',
      category: 'SYSTEMS',
      complianceMethod: 'SIMULATION',
      associatedRequirementId: 'REQ-SYS-021',
      testCardRef: 'TC-09 (Dual Generator Out)',
      analysisReportRef: 'AF-REP-FHA-2026-11',
      complianceStatus: 'COMPLIANT',
      evidenceHash: 'SHA256:e77a...5501',
      complianceOfficer: 'K. Patel (DER Systems)',
    },
  ]);

  // Flight Test Cards
  readonly flightTestCards = signal<FlightTestCard[]>([
    {
      id: 'TC-01',
      code: 'TC-AF100-TO-01',
      title: 'Maximum Takeoff Field Length & V1/VR Decision Speed',
      objective: 'Verify balanced field length and single-engine failure rotation dynamics at MTOW (78,000 kg).',
      manoeuvreType: 'TAKEOFF_FIELD',
      targetMach: 0.24,
      targetAltitudeFt: 35,
      predictedMetric: 'BFL 1,824 m',
      simulatedMetric: 'BFL 1,842 m',
      variancePercent: 0.98,
      verdict: 'PASS',
      evidenceHash: 'SHA256:e3b0c442',
    },
    {
      id: 'TC-02',
      code: 'TC-AF100-CRUISE-02',
      title: 'Long-Range Cruise Mach & Drag Divergence Exploration',
      objective: 'Sweep Mach 0.76 to 0.84 at FL370 to establish wave drag onset and buffet boundary.',
      manoeuvreType: 'CRUISE_SPEED',
      targetMach: 0.785,
      targetAltitudeFt: 37000,
      predictedMetric: 'L/D = 17.95',
      simulatedMetric: 'L/D = 17.82',
      variancePercent: -0.72,
      verdict: 'PASS',
      evidenceHash: 'SHA256:7f83b165',
    },
    {
      id: 'TC-03',
      code: 'TC-AF100-DUTCH-03',
      title: 'Lateral-Directional Stability & Dutch Roll Damping',
      objective: 'Rudder doublet input with Yaw Damper OFF to measure natural period and damping ratio zeta.',
      manoeuvreType: 'DUTCH_ROLL_STABILITY',
      targetMach: 0.78,
      targetAltitudeFt: 35000,
      predictedMetric: 'zeta = 0.082 (undamped)',
      simulatedMetric: 'zeta = 0.080 (undamped)',
      variancePercent: -2.4,
      verdict: 'PASS',
      evidenceHash: 'SHA256:2f90a1bc',
    },
    {
      id: 'TC-04',
      code: 'TC-AF100-STALL-04',
      title: 'Clean Configuration High-Altitude Stall Exploration',
      objective: '1 kt/sec deceleration at FL300 to verify natural buffet margin and stick-shaker trigger.',
      manoeuvreType: 'STALL_EXPLORATION',
      targetMach: 0.45,
      targetAltitudeFt: 30000,
      predictedMetric: 'V_stall = 138 KCAS',
      simulatedMetric: 'V_stall = 139 KCAS',
      variancePercent: 0.72,
      verdict: 'PASS',
      evidenceHash: 'SHA256:19b882da',
    },
  ]);

  // Method to select variant
  setVariant(variantCode: AircraftVariant['code']): void {
    const v = this.variants.find((item) => item.code === variantCode);
    if (!v) return;
    this.activeVariant.set(v);
    this.wingSpan.set(v.wingSpanM);
    this.fuselageLength.set(v.fuselageLengthM);
    this.cabinSeatsCount.set(v.passengerCapacity);
    this.engineThrustClass.set(v.thrustClassKN);
    this.markSimulationsStale(`Variant switched to ${v.code}`);
  }

  // Method to update wing span (Step 11 & parametric studies)
  setWingSpan(newSpanM: number): void {
    const clamped = Math.max(30.0, Math.min(45.0, Number(newSpanM.toFixed(2))));
    this.wingSpan.set(clamped);
    this.markSimulationsStale(`Wing span changed to ${clamped} m`);
  }

  // Method to update wing area
  setWingArea(newAreaM2: number): void {
    const clamped = Math.max(100.0, Math.min(160.0, Number(newAreaM2.toFixed(1))));
    this.wingArea.set(clamped);
    this.markSimulationsStale(`Wing area changed to ${clamped} m²`);
  }

  // Method to update sweep
  setSweep(newSweepDeg: number): void {
    const clamped = Math.max(15.0, Math.min(35.0, Number(newSweepDeg.toFixed(1))));
    this.sweepQuarterChord.set(clamped);
    this.markSimulationsStale(`Quarter chord sweep changed to ${clamped}°`);
  }

  // Method to update fuselage length
  setFuselageLength(newLengthM: number): void {
    const clamped = Math.max(32.0, Math.min(48.0, Number(newLengthM.toFixed(2))));
    this.fuselageLength.set(clamped);
    this.markSimulationsStale(`Fuselage length changed to ${clamped} m`);
  }

  // Method to update engine thrust class
  setEngineThrust(newThrustKN: number): void {
    const clamped = Math.max(90.0, Math.min(160.0, Number(newThrustKN.toFixed(1))));
    this.engineThrustClass.set(clamped);
    this.markSimulationsStale(`Engine thrust class updated to ${clamped} kN`);
  }

  // Re-run simulations and clear stale list (Step 13)
  runUpdatedSimulations(): void {
    this.staleSimulations.set([]);
    this.configRevision.update((rev) => {
      const match = rev.match(/Rev C(\d+)/);
      const nextNum = match ? parseInt(match[1], 10) + 1 : 3;
      return `Rev C${nextNum} (VERIFIED)`;
    });
    this.configHash.set(`SHA256:${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}`);
  }

  private markSimulationsStale(_reason: string): void {
    void _reason;
    const existing = this.staleSimulations();
    const staleList = [
      'Aero Drag Polar & L/D (SIM-AERO-042)',
      'Wing Root Bending Moment & Spar Sizing (SIM-STRUC-014)',
      'Aeroelastic Flutter Boundary (SIM-FLUT-019)',
      'Takeoff & Climb Performance (SIM-TO-009)',
      'Wing Assembly Jig Tooling Program (AF100-TL-301)',
    ];
    this.staleSimulations.set(Array.from(new Set([...existing, ...staleList])));
  }

  selectComponent(comp: StructuralComponent | null): void {
    this.selectedComponent.set(comp);
  }
}
