import { Injectable, computed, inject, signal } from '@angular/core';
import { AircraftStateService } from './aircraft-state.service';

export interface UltrasonicScanPoint {
  xMm: number;
  yMm: number;
  amplitudeDb: number;
  tofMicrosec: number;
  depthMm: number;
  hasFlaw: boolean;
  flawType?: 'POROSITY' | 'DELAMINATION' | 'FOREIGN_OBJECT';
}

@Injectable({
  providedIn: 'root',
})
export class QualityEngineService {
  private aircraftState = inject(AircraftStateService);

  readonly selectedInspectionTechnique = signal<'ULTRASONIC_PHASED_ARRAY' | 'XRAY_RADIOGRAPHY' | 'EDDY_CURRENT' | 'THERMOGRAPHY'>('ULTRASONIC_PHASED_ARRAY');
  readonly inspectedComponentId = signal<string>('STR-W-SKIN-UPPER');

  // Synthetic 10x10 C-Scan Matrix for Composite Skin Inspection
  readonly cScanGrid = signal<UltrasonicScanPoint[]>(this.generateCScanGrid());

  private generateCScanGrid(): UltrasonicScanPoint[] {
    const grid: UltrasonicScanPoint[] = [];
    for (let row = 0; row < 10; row++) {
      for (let col = 0; col < 10; col++) {
        const x = col * 50; // mm
        const y = row * 50; // mm

        // Simulate small simulated flaw area at col=6, row=4 (synthetic defect for demonstration)
        const isDefectZone = col === 6 && row === 4;
        const amplitude = isDefectZone ? -18.5 : -2.1 + (Math.sin(row) * 0.4);
        const tof = isDefectZone ? 4.2 : 6.8; // Earlier reflection from delamination
        const depth = isDefectZone ? 3.8 : 12.0;

        grid.push({
          xMm: x,
          yMm: y,
          amplitudeDb: Number(amplitude.toFixed(1)),
          tofMicrosec: Number(tof.toFixed(2)),
          depthMm: Number(depth.toFixed(1)),
          hasFlaw: isDefectZone,
          flawType: isDefectZone ? 'DELAMINATION' : undefined,
        });
      }
    }
    return grid;
  }

  // Statistical Process Control summary
  readonly spcSummary = computed(() => {
    const metrics = this.aircraftState.qualityMetrics();
    const avgCp = Number(
      (metrics.reduce((sum, m) => sum + m.cp, 0) / metrics.length).toFixed(2),
    );
    const avgCpk = Number(
      (metrics.reduce((sum, m) => sum + m.cpk, 0) / metrics.length).toFixed(2),
    );
    const avgFpy = Number(
      (metrics.reduce((sum, m) => sum + m.firstPassYieldPercent, 0) / metrics.length).toFixed(1),
    );
    return {
      averageCp: avgCp,
      averageCpk: avgCpk,
      overallFirstPassYield: avgFpy,
      sixSigmaCompliant: avgCpk >= 1.33,
    };
  });

  setTechnique(technique: 'ULTRASONIC_PHASED_ARRAY' | 'XRAY_RADIOGRAPHY' | 'EDDY_CURRENT' | 'THERMOGRAPHY'): void {
    this.selectedInspectionTechnique.set(technique);
  }
}
