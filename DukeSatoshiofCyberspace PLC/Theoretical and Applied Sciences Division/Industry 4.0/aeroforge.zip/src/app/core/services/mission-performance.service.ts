import { Injectable, computed, inject, signal } from '@angular/core';
import { AircraftStateService } from './aircraft-state.service';

export interface MissionSegment {
  segmentName: string;
  altitudeStartFt: number;
  altitudeEndFt: number;
  mach: number;
  durationMin: number;
  distanceNm: number;
  fuelBurnKg: number;
  segmentGrossWeightEndKg: number;
}

export interface PayloadRangePoint {
  rangeNm: number;
  payloadKg: number;
  label: string;
}

@Injectable({
  providedIn: 'root',
})
export class MissionPerformanceService {
  private aircraftState = inject(AircraftStateService);

  readonly missionDistanceNm = signal<number>(2500); // 2,500 NM standard mission
  readonly passengerCount = signal<number>(180);
  readonly cargoKg = signal<number>(2500);
  readonly internationalReserves = signal<boolean>(true); // 5% contingency + 200 NM alternate + 30 min hold

  // Standard Atmosphere Calculator
  getIsaAtmosphere(altitudeFt: number) {
    const altM = altitudeFt * 0.3048;
    const T0 = 288.15;
    const P0 = 101325;
    const gamma = 1.4;
    const R = 287.058;

    let T: number;
    let P: number;
    if (altM <= 11000) {
      T = T0 - 0.0065 * altM;
      P = P0 * Math.pow(T / T0, 5.2559);
    } else {
      T = 216.65;
      const P11 = P0 * Math.pow(216.65 / T0, 5.2559);
      P = P11 * Math.exp((-9.80665 * (altM - 11000)) / (R * T));
    }
    const rho = P / (R * T);
    const speedOfSoundMps = Math.sqrt(gamma * R * T);
    const speedOfSoundKts = speedOfSoundMps * 1.94384;
    return {
      altitudeM: Math.round(altM),
      tempC: Number((T - 273.15).toFixed(1)),
      pressureKPa: Number((P / 1000).toFixed(2)),
      densityKgM3: Number(rho.toFixed(4)),
      speedOfSoundKts: Math.round(speedOfSoundKts),
    };
  }

  // Payload-Range Diagram Points:
  // Point A: Max Payload, Max Zero Fuel Weight limit
  // Point B: Max Payload, MTOW limit (fuel capacity fills up remaining gross weight)
  // Point C: Full Fuel Tank capacity, Payload backed off to maintain MTOW
  // Point D: Zero Payload, Ferry range with maximum fuel
  readonly payloadRangeDiagram = computed<PayloadRangePoint[]>(() => {
    const weights = this.aircraftState.massProperties();
    const span = this.aircraftState.wingSpan();
    const LD = 17.82 * Math.pow(span / 35.8, 0.4); // aerodynamic efficiency scaling
    const tsfc = 0.518; // lb/lbf-hr
    const V_cruise = 450; // knots

    // Breguet Range Equation factor: R = (V / TSFC) * (L/D) * ln(W_initial / W_final)
    const breguetFactor = (V_cruise / tsfc) * LD * 0.78;

    // Point A: Max Structural Payload at Zero Range
    const maxPayload = weights.maxPayload; // ~19,500 kg

    // Point B: Max Payload at MTOW boundary
    // Fuel at point B = MTOW - OEW - MaxPayload
    const fuelB = Math.min(weights.maxFuel, weights.mtow - weights.oew - maxPayload);
    const wInitB = weights.oew + maxPayload + fuelB;
    const wFinalB = weights.oew + maxPayload;
    const rangeB = Math.round(breguetFactor * Math.log(wInitB / wFinalB));

    // Point C: Full Fuel capacity
    const fuelC = weights.maxFuel;
    const payloadC = Math.max(0, weights.mtow - weights.oew - fuelC);
    const wInitC = weights.mtow;
    const wFinalC = weights.oew + payloadC;
    const rangeC = Math.round(breguetFactor * Math.log(wInitC / wFinalC));

    // Point D: Zero Payload Ferry Range
    const payloadD = 0;
    const wInitD = weights.oew + fuelC;
    const wFinalD = weights.oew;
    const rangeD = Math.round(breguetFactor * Math.log(wInitD / wFinalD));

    return [
      { rangeNm: 0, payloadKg: maxPayload, label: 'Pt A: Max Structural Payload' },
      { rangeNm: rangeB, payloadKg: maxPayload, label: 'Pt B: Max Payload Range (MTOW Limit)' },
      { rangeNm: rangeC, payloadKg: payloadC, label: 'Pt C: Full Fuel Capacity Range' },
      { rangeNm: rangeD, payloadKg: payloadD, label: 'Pt D: Ferry Range (Zero Payload)' },
    ];
  });

  // Mission Profile Simulation
  readonly missionProfile = computed(() => {
    const dist = this.missionDistanceNm();
    const weights = this.aircraftState.massProperties();
    const paxWeight = this.passengerCount() * 100; // 84 kg pax + 16 kg luggage
    const totalPayload = paxWeight + this.cargoKg();
    const initialTOW = weights.oew + totalPayload + 16800; // baseline fuel

    const segments: MissionSegment[] = [
      {
        segmentName: '1. Taxi-Out & APU Ground Ops',
        altitudeStartFt: 0,
        altitudeEndFt: 0,
        mach: 0.02,
        durationMin: 15,
        distanceNm: 2,
        fuelBurnKg: 240,
        segmentGrossWeightEndKg: initialTOW - 240,
      },
      {
        segmentName: '2. Takeoff & Climb to FL100 (250 kt limit)',
        altitudeStartFt: 0,
        altitudeEndFt: 10000,
        mach: 0.42,
        durationMin: 6,
        distanceNm: 28,
        fuelBurnKg: 620,
        segmentGrossWeightEndKg: initialTOW - 860,
      },
      {
        segmentName: '3. Climb to Initial Cruise FL350',
        altitudeStartFt: 10000,
        altitudeEndFt: 35000,
        mach: 0.74,
        durationMin: 18,
        distanceNm: 98,
        fuelBurnKg: 1450,
        segmentGrossWeightEndKg: initialTOW - 2310,
      },
      {
        segmentName: '4. Step 1 Cruise (FL350, Mach 0.785)',
        altitudeStartFt: 35000,
        altitudeEndFt: 35000,
        mach: 0.785,
        durationMin: 142,
        distanceNm: 1080,
        fuelBurnKg: 5280,
        segmentGrossWeightEndKg: initialTOW - 7590,
      },
      {
        segmentName: '5. Step-Climb to FL390 (Lighter Gross Weight)',
        altitudeStartFt: 35000,
        altitudeEndFt: 39000,
        mach: 0.785,
        durationMin: 6,
        distanceNm: 44,
        fuelBurnKg: 280,
        segmentGrossWeightEndKg: initialTOW - 7870,
      },
      {
        segmentName: '6. Step 2 Cruise (FL390, Mach 0.785)',
        altitudeStartFt: 39000,
        altitudeEndFt: 39000,
        mach: 0.785,
        durationMin: 135,
        distanceNm: 1040,
        fuelBurnKg: 4620,
        segmentGrossWeightEndKg: initialTOW - 12490,
      },
      {
        segmentName: '7. Descent & Terminal Area Approach',
        altitudeStartFt: 39000,
        altitudeEndFt: 1500,
        mach: 0.62,
        durationMin: 22,
        distanceNm: 110,
        fuelBurnKg: 480,
        segmentGrossWeightEndKg: initialTOW - 12970,
      },
      {
        segmentName: '8. Final Approach, Landing & Taxi-In',
        altitudeStartFt: 1500,
        altitudeEndFt: 0,
        mach: 0.18,
        durationMin: 8,
        distanceNm: 8,
        fuelBurnKg: 190,
        segmentGrossWeightEndKg: initialTOW - 13160,
      },
    ];

    const totalTripFuelKg = segments.reduce((sum, s) => sum + s.fuelBurnKg, 0);
    const totalDurationMin = segments.reduce((sum, s) => sum + s.durationMin, 0);
    const reserveFuelKg = this.internationalReserves() ? 2850 : 1800;
    const requiredBlockFuelKg = totalTripFuelKg + reserveFuelKg;

    return {
      segments,
      totalTripFuelKg,
      reserveFuelKg,
      requiredBlockFuelKg,
      totalDurationHours: Number((totalDurationMin / 60).toFixed(2)),
      actualDistanceNm: dist,
      landingWeightKg: initialTOW - totalTripFuelKg,
    };
  });

  setMissionDistance(nm: number): void {
    this.missionDistanceNm.set(nm);
  }
}
