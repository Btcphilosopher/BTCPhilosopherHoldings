import { Injectable, signal } from '@angular/core';
import { UnitSystem } from '../models/aircraft.types';

@Injectable({
  providedIn: 'root',
})
export class UnitConverter {
  readonly currentUnitSystem = signal<UnitSystem>('SI');

  setUnitSystem(system: UnitSystem): void {
    this.currentUnitSystem.set(system);
  }

  toggleUnitSystem(): void {
    this.currentUnitSystem.update((u) => (u === 'SI' ? 'AVIATION' : 'SI'));
  }

  // --- Mass: kg <-> lb ---
  formatMass(kg: number): { value: number; formatted: string; unit: string } {
    if (this.currentUnitSystem() === 'AVIATION') {
      const lb = kg * 2.20462;
      return { value: lb, formatted: lb.toLocaleString('en-US', { maximumFractionDigits: 0 }), unit: 'lb' };
    }
    return { value: kg, formatted: kg.toLocaleString('en-US', { maximumFractionDigits: 0 }), unit: 'kg' };
  }

  // --- Length: m <-> ft or in ---
  formatLength(m: number): { value: number; formatted: string; unit: string } {
    if (this.currentUnitSystem() === 'AVIATION') {
      const ft = m * 3.28084;
      return { value: ft, formatted: ft.toFixed(1), unit: 'ft' };
    }
    return { value: m, formatted: m.toFixed(2), unit: 'm' };
  }

  // --- Speed: m/s <-> knots ---
  formatSpeed(mps: number): { value: number; formatted: string; unit: string } {
    if (this.currentUnitSystem() === 'AVIATION') {
      const kts = mps * 1.94384;
      return { value: kts, formatted: kts.toFixed(0), unit: 'kts' };
    }
    return { value: mps, formatted: mps.toFixed(1), unit: 'm/s' };
  }

  // --- Force/Thrust: kN <-> lbf ---
  formatThrust(kN: number): { value: number; formatted: string; unit: string } {
    if (this.currentUnitSystem() === 'AVIATION') {
      const lbf = kN * 224.809;
      return { value: lbf, formatted: lbf.toLocaleString('en-US', { maximumFractionDigits: 0 }), unit: 'lbf' };
    }
    return { value: kN, formatted: kN.toFixed(1), unit: 'kN' };
  }

  // --- Pressure: kPa <-> psi ---
  formatPressure(kPa: number): { value: number; formatted: string; unit: string } {
    if (this.currentUnitSystem() === 'AVIATION') {
      const psi = kPa * 0.145038;
      return { value: psi, formatted: psi.toFixed(1), unit: 'psi' };
    }
    return { value: kPa, formatted: kPa.toFixed(1), unit: 'kPa' };
  }

  // --- Altitude: m <-> ft ---
  formatAltitude(m: number): { value: number; formatted: string; unit: string } {
    if (this.currentUnitSystem() === 'AVIATION') {
      const ft = m * 3.28084;
      return { value: ft, formatted: `${Math.round(ft).toLocaleString()} ft (FL${Math.round(ft / 100)})`, unit: 'ft' };
    }
    return { value: m, formatted: `${Math.round(m).toLocaleString()} m`, unit: 'm' };
  }

  // --- Temperature: °C <-> °F ---
  formatTemperature(c: number): { value: number; formatted: string; unit: string } {
    if (this.currentUnitSystem() === 'AVIATION') {
      const f = c * 1.8 + 32;
      return { value: f, formatted: f.toFixed(1), unit: '°F' };
    }
    return { value: c, formatted: c.toFixed(1), unit: '°C' };
  }
}
