import { Injectable, signal } from '@angular/core';
import { FlightDynamics6DOF, FlightTestCard } from '../models/aircraft.types';

export interface TelemetryPoint {
  timeSec: number;
  altitudeFt: number;
  airspeedKts: number;
  mach: number;
  pitchDeg: number;
  rollDeg: number;
  loadFactorG: number;
  thrustPct: number;
  predictedSpeedKts: number;
  predictedAltitudeFt: number;
}

@Injectable({
  providedIn: 'root',
})
export class FlightDynamicsService {
  readonly isSimulating = signal<boolean>(false);
  readonly activeManoeuvre = signal<FlightTestCard['manoeuvreType']>('CRUISE_SPEED');
  readonly autopilotEngaged = signal<boolean>(true);
  readonly sasEngaged = signal<boolean>(true); // Stability Augmentation System
  readonly pitchTrimDeg = signal<number>(-1.2);
  readonly targetAltitudeFt = signal<number>(37000);
  readonly targetMach = signal<number>(0.785);

  // 6-DOF Live State
  readonly current6DOF = signal<FlightDynamics6DOF>({
    timeSec: 120.0,
    altitudeM: 11277, // FL370 = 37,000 ft
    trueAirspeedMps: 231.5,
    calibratedAirspeedKts: 260.0,
    mach: 0.785,
    pitchAngleDeg: 2.1,
    rollAngleDeg: 0.0,
    yawAngleDeg: 0.0,
    pitchRateDegPerSec: 0.0,
    rollRateDegPerSec: 0.0,
    yawRateDegPerSec: 0.0,
    normalAccelerationG: 1.00,
    lateralAccelerationG: 0.00,
    axialAccelerationG: 0.00,
    elevatorDeflectionDeg: -1.2,
    aileronDeflectionDeg: 0.0,
    rudderDeflectionDeg: 0.0,
    flightPathAngleDeg: 0.0,
  });

  // Recorded Flight Test Telemetry Points (60-second time history)
  readonly telemetryData = signal<TelemetryPoint[]>(this.generateTelemetrySeries('CRUISE_SPEED'));

  private generateTelemetrySeries(manoeuvre: FlightTestCard['manoeuvreType']): TelemetryPoint[] {
    const points: TelemetryPoint[] = [];
    const count = 50;

    for (let i = 0; i <= count; i++) {
      const t = i * 1.5; // 0 to 75 seconds

      let alt = 37000;
      let spd = 260;
      let m = 0.785;
      let pitch = 2.1;
      let roll = 0;
      let g = 1.0;
      let thrust = 84;
      let predSpd = 260;
      let predAlt = 37000;

      if (manoeuvre === 'TAKEOFF_FIELD') {
        alt = Math.min(1800, Math.max(0, Math.pow(Math.max(0, t - 25), 1.8) * 2.2));
        spd = Math.min(175, 12 + t * 4.2);
        m = spd / 661;
        pitch = t < 25 ? 0.5 : Math.min(14.5, (t - 25) * 1.8);
        g = t > 25 && t < 32 ? 1.18 : 1.0;
        thrust = 100;
        predSpd = spd * 0.99;
        predAlt = alt * 0.98;
      } else if (manoeuvre === 'DUTCH_ROLL_STABILITY') {
        // Rudder doublet at t=10s followed by oscillatory decay
        const tPerturb = Math.max(0, t - 10);
        const decay = Math.exp(-tPerturb * 0.08);
        const omega = 1.6; // rad/s
        roll = 14.0 * decay * Math.sin(omega * tPerturb);
        pitch = 2.1 + 1.2 * decay * Math.cos(omega * tPerturb * 0.5);
        g = 1.0 + 0.15 * decay * Math.sin(omega * tPerturb);
        predSpd = spd;
        predAlt = alt;
      } else if (manoeuvre === 'STALL_EXPLORATION') {
        spd = Math.max(138, 240 - t * 2.2);
        pitch = Math.min(18.5, 2.1 + (t / 50) * 16.0);
        g = t > 40 ? 0.88 + 0.12 * Math.sin(t * 3) : 1.0; // buffet oscillations
        alt = 30000 - (t > 40 ? (t - 40) * 25 : 0);
        predSpd = spd - 1.2;
        predAlt = alt;
      } else {
        // Cruise Speed with slight atmospheric wave
        alt = 37000 + 40 * Math.sin(t * 0.08);
        spd = 260 + 2.5 * Math.cos(t * 0.06);
        pitch = 2.1 + 0.3 * Math.sin(t * 0.08);
        predSpd = 260;
        predAlt = 37000;
      }

      points.push({
        timeSec: t,
        altitudeFt: Math.round(alt),
        airspeedKts: Number(spd.toFixed(1)),
        mach: Number(m.toFixed(3)),
        pitchDeg: Number(pitch.toFixed(1)),
        rollDeg: Number(roll.toFixed(1)),
        loadFactorG: Number(g.toFixed(2)),
        thrustPct: Math.round(thrust),
        predictedSpeedKts: Number(predSpd.toFixed(1)),
        predictedAltitudeFt: Math.round(predAlt),
      });
    }
    return points;
  }

  setManoeuvre(type: FlightTestCard['manoeuvreType']): void {
    this.activeManoeuvre.set(type);
    this.telemetryData.set(this.generateTelemetrySeries(type));
  }

  toggleAutopilot(): void {
    this.autopilotEngaged.update((v) => !v);
  }

  toggleSas(): void {
    this.sasEngaged.update((v) => !v);
  }
}
