import { Injectable, computed, signal } from '@angular/core';
import { ElectricalBus, HydraulicCircuit, FuelTank } from '../models/aircraft.types';

@Injectable({
  providedIn: 'root',
})
export class SystemsSimulatorService {
  // Fault Injection States
  readonly idg1Tripped = signal<boolean>(false);
  readonly idg2Tripped = signal<boolean>(false);
  readonly apuRunning = signal<boolean>(false);
  readonly ratDeployed = signal<boolean>(false);
  readonly greenHydraulicLeak = signal<boolean>(false);
  readonly fuelCrossfeedOpen = signal<boolean>(false);
  readonly cabinDepressurization = signal<boolean>(false);

  // Electrical System
  readonly electricalBuses = computed<ElectricalBus[]>(() => {
    const idg1 = !this.idg1Tripped();
    const idg2 = !this.idg2Tripped();
    const apu = this.apuRunning();
    const rat = this.ratDeployed();

    // Source selection logic
    const bus1Source = idg1 ? 'IDG1' : apu ? 'APU' : idg2 ? 'IDG2' : rat ? 'RAT' : 'BATTERY';
    const bus2Source = idg2 ? 'IDG2' : apu ? 'APU' : idg1 ? 'IDG1' : rat ? 'RAT' : 'BATTERY';

    return [
      {
        id: 'AC-BUS-1',
        name: 'AC Bus 1 (115V / 400Hz)',
        voltage: idg1 || apu || idg2 ? 115 : rat ? 110 : 0,
        frequency: 400,
        connectedLoadKW: idg1 || apu ? 42.5 : 22.0, // shed galley load if degraded
        capacityKW: 90.0,
        isEnergized: idg1 || apu || idg2 || rat,
        source: bus1Source,
      },
      {
        id: 'AC-BUS-2',
        name: 'AC Bus 2 (115V / 400Hz)',
        voltage: idg2 || apu || idg1 ? 115 : 0,
        frequency: 400,
        connectedLoadKW: idg2 || apu ? 39.8 : 0,
        capacityKW: 90.0,
        isEnergized: idg2 || apu || idg1,
        source: bus2Source,
      },
      {
        id: 'AC-ESS',
        name: 'AC Essential Bus (Flight Instruments & FBW)',
        voltage: 115,
        frequency: 400,
        connectedLoadKW: 18.2,
        capacityKW: 45.0,
        isEnergized: true,
        source: idg1 ? 'IDG1' : idg2 ? 'IDG2' : apu ? 'APU' : rat ? 'RAT' : 'BATTERY',
      },
      {
        id: 'DC-ESS',
        name: 'DC Essential Bus (28V DC Engine FADEC & Comms)',
        voltage: 28.2,
        frequency: 0,
        connectedLoadKW: 8.5,
        capacityKW: 20.0,
        isEnergized: true,
        source: 'BATTERY',
      },
    ];
  });

  // Shedded Loads
  readonly sheddedLoads = computed<string[]>(() => {
    const list: string[] = [];
    if (this.idg1Tripped() && this.idg2Tripped() && !this.apuRunning()) {
      list.push('Galley Ovens & Chillers (Load Shed 1)');
      list.push('In-Flight Entertainment IFE (Load Shed 2)');
      list.push('Commercial Cargo Heating (Load Shed 3)');
      list.push('Secondary Cabin Lighting (Load Shed 4)');
    } else if (this.idg1Tripped() || this.idg2Tripped()) {
      list.push('Right Main Galley Power (Automatic Tier 1 Shed)');
    }
    return list;
  });

  // Hydraulic System (Green, Blue, Yellow 3,000 / 5,000 psi)
  readonly hydraulicCircuits = computed<HydraulicCircuit[]>(() => {
    const leak = this.greenHydraulicLeak();
    return [
      {
        id: 'GREEN',
        name: 'Green Circuit (Landing Gear & Heavy Flaps)',
        pressurePsi: leak ? 480 : 3000,
        targetPressurePsi: 3000,
        fluidTempC: leak ? 88.0 : 64.0,
        fluidLevelPercent: leak ? 18.0 : 96.0,
        primaryPumpActive: !leak,
        backupPumpActive: leak,
        ptuActive: leak, // Power Transfer Unit kicks in when green pressure drops!
      },
      {
        id: 'BLUE',
        name: 'Blue Circuit (Primary Flight Controls & Spoilers)',
        pressurePsi: 3000,
        targetPressurePsi: 3000,
        fluidTempC: 61.5,
        fluidLevelPercent: 94.0,
        primaryPumpActive: true,
        backupPumpActive: false,
        ptuActive: false,
      },
      {
        id: 'YELLOW',
        name: 'Yellow Circuit (Brakes, Cargo Door, Thrust Reverser #2)',
        pressurePsi: 3000,
        targetPressurePsi: 3000,
        fluidTempC: 63.2,
        fluidLevelPercent: 95.0,
        primaryPumpActive: true,
        backupPumpActive: false,
        ptuActive: leak, // Yellow PTU powers Green actuators
      },
    ];
  });

  // Fuel System (Center + Left/Right Main Wing Tanks)
  readonly fuelTanks = computed<FuelTank[]>(() => {
    return [
      {
        id: 'TANK-LEFT-MAIN',
        name: 'Left Main Wing Tank',
        capacityKg: 7800,
        currentFuelKg: 5900,
        temperatureC: -12.0,
        boostPump1Active: true,
        boostPump2Active: true,
        cgXM: 16.4,
      },
      {
        id: 'TANK-CENTER',
        name: 'Center Fuselage Wing Box Tank',
        capacityKg: 8600,
        currentFuelKg: 4200,
        temperatureC: 4.5,
        boostPump1Active: true,
        boostPump2Active: true,
        cgXM: 15.2,
      },
      {
        id: 'TANK-RIGHT-MAIN',
        name: 'Right Main Wing Tank',
        capacityKg: 7800,
        currentFuelKg: 5900,
        temperatureC: -12.0,
        boostPump1Active: true,
        boostPump2Active: true,
        cgXM: 16.4,
      },
    ];
  });

  // Environmental Control System (ECS) & Cabin
  readonly environmentalState = computed(() => {
    const depress = this.cabinDepressurization();
    return {
      pack1Active: true,
      pack2Active: true,
      cabinAltitudeFt: depress ? 14200 : 7200,
      cabinDeltaPressurePsi: depress ? 2.8 : 8.2,
      cabinTempC: 22.4,
      outflowValvePositionPercent: depress ? 98 : 34,
      oxygenMasksDeployed: depress,
    };
  });

  // Landing gear & braking model
  readonly landingGearState = signal({
    gearPosition: 'UP_AND_LOCKED' as 'DOWN_AND_LOCKED' | 'IN_TRANSIT' | 'UP_AND_LOCKED',
    antiskidActive: true,
    brakeTempC: 185,
    noseWheelSteeringDeg: 0,
    shockAbsorberCompressionMm: 120,
    stoppingDistanceSLWetM: 1420,
  });

  // Fault injection toggles
  toggleIdg1(): void {
    this.idg1Tripped.update((v) => !v);
  }

  toggleIdg2(): void {
    this.idg2Tripped.update((v) => !v);
  }

  toggleApu(): void {
    this.apuRunning.update((v) => !v);
  }

  toggleRat(): void {
    this.ratDeployed.update((v) => !v);
  }

  toggleGreenLeak(): void {
    this.greenHydraulicLeak.update((v) => !v);
  }

  toggleCrossfeed(): void {
    this.fuelCrossfeedOpen.update((v) => !v);
  }

  toggleDepressurization(): void {
    this.cabinDepressurization.update((v) => !v);
  }

  resetAllFaults(): void {
    this.idg1Tripped.set(false);
    this.idg2Tripped.set(false);
    this.apuRunning.set(false);
    this.ratDeployed.set(false);
    this.greenHydraulicLeak.set(false);
    this.fuelCrossfeedOpen.set(false);
    this.cabinDepressurization.set(false);
  }
}
