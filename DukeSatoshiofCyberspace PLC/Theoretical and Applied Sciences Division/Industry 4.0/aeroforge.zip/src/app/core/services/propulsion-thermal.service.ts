import { Injectable, computed, inject, signal } from '@angular/core';
import { PropulsionState, PropulsionStation } from '../models/aircraft.types';
import { AircraftStateService } from './aircraft-state.service';

export interface ThermalNode {
  nodeId: string;
  name: string;
  zone: 'PROPULSION' | 'AVIONICS' | 'HYDRAULIC' | 'CABIN' | 'BATTERY';
  currentTempC: number;
  maxAllowableTempC: number;
  heatDissipationKW: number;
  coolingCapacityKW: number;
  marginC: number;
  status: 'NOMINAL' | 'ELEVATED' | 'CRITICAL';
}

@Injectable({
  providedIn: 'root',
})
export class PropulsionThermalService {
  private aircraftState = inject(AircraftStateService);

  readonly throttleLeverPercent = signal<number>(85.0); // 85% cruise rating
  readonly flightAltitudeM = signal<number>(10668); // FL350
  readonly flightMach = signal<number>(0.785);

  // Thermodynamic Gas Turbine Cycle Computation
  readonly propulsionState = computed<PropulsionState>(() => {
    const throttle = this.throttleLeverPercent() / 100;
    const alt = this.flightAltitudeM();
    const M = this.flightMach();
    const ratedThrustSL = this.aircraftState.engineThrustClass(); // 120 kN baseline

    // Atmospheric density ratio sigma = rho / rho0
    const altKm = alt / 1000;
    const densityRatio = Math.exp(-altKm / 9.2);

    // Thrust lapse: F(h, M) = F_rated * (rho/rho0)^0.8 * (1 - 0.35 * M) * throttle^1.4
    const thrustPerEngineKN = ratedThrustSL * Math.pow(densityRatio, 0.82) * (1 - 0.32 * M) * Math.pow(throttle, 1.35);
    const netThrustTotalKN = Number((thrustPerEngineKN * 2).toFixed(1));

    // Specific Fuel Consumption TSFC
    // TSFC increases with Mach and slight throttle variations
    const tsfc = 0.518 * (1 + 0.18 * M + 0.08 * (1 - throttle));
    const fuelFlowPerEngine = (thrustPerEngineKN * 1000 * (tsfc * 28.32e-6)) / 3600; // kg/s
    const fuelFlowTotal = fuelFlowPerEngine * 2;

    // Spool speeds
    const n1 = 78.5 + 21.5 * throttle;
    const n2 = 82.0 + 17.5 * throttle;
    const titK = 1150 + 580 * throttle; // Turbine Inlet Temperature: up to 1730 K

    // Thermodynamic Stations: 0 (ambient), 2 (fan inlet), 25 (LPC exit), 3 (HPC exit), 4 (burner exit), 45 (HPT exit), 5 (LPT exit), 8 (nozzle)
    const stations: PropulsionStation[] = [
      { stationId: '0', name: 'Ambient Freestream', totalPressureKPa: 23.8, totalTemperatureK: 218.8, mach: M },
      { stationId: '2', name: 'Fan Face Inlet', totalPressureKPa: 35.6, totalTemperatureK: 245.2, mach: 0.52 },
      { stationId: '25', name: 'LPC Exit (Booster)', totalPressureKPa: 88.4, totalTemperatureK: 320.5, mach: 0.38 },
      { stationId: '3', name: 'HPC Delivery (Combustor Inlet)', totalPressureKPa: 1002.5, totalTemperatureK: 785.4, mach: 0.28 },
      { stationId: '4', name: 'Combustor Exit / Turbine Inlet (TIT)', totalPressureKPa: 962.0, totalTemperatureK: Number(titK.toFixed(0)), mach: 0.32 },
      { stationId: '45', name: 'HPT Exit / LPT Inlet', totalPressureKPa: 312.4, totalTemperatureK: 1140.2, mach: 0.44 },
      { stationId: '5', name: 'LPT Exit (Core Exhaust)', totalPressureKPa: 48.2, totalTemperatureK: 685.0, mach: 0.48 },
      { stationId: '8', name: 'Con-Di Propulsion Nozzle', totalPressureKPa: 24.1, totalTemperatureK: 610.5, mach: 0.98 },
    ];

    return {
      engineModel: 'AF-FAN-120A Advanced Geared Turbofan',
      thrustPerEngineKN: Number(thrustPerEngineKN.toFixed(1)),
      netThrustTotalKN,
      bypassRatio: 11.4,
      overallPressureRatio: 42.1,
      fanDiameterM: 1.98,
      turbineInletTempK: Number(titK.toFixed(0)),
      n1FanSpeedPercent: Number(n1.toFixed(1)),
      n2CoreSpeedPercent: Number(n2.toFixed(1)),
      tsfcKgPerKNh: Number(tsfc.toFixed(3)),
      fuelFlowKgPerSec: Number(fuelFlowTotal.toFixed(2)),
      thermalEfficiency: 0.54,
      propulsiveEfficiency: 0.83,
      egtMarginDegC: 48.5,
      stations,
    };
  });

  // Thermal Network Nodes
  readonly thermalNodes = computed<ThermalNode[]>(() => {
    const throttle = this.throttleLeverPercent() / 100;
    const coreTemp = 640 + throttle * 140;
    const nacelleTemp = 115 + throttle * 35;
    const avionicsTemp = 36 + throttle * 4;
    const hydroTemp = 68 + throttle * 12;
    const cabinTemp = 22.4;
    const batteryTemp = 28.5 + throttle * 3;

    return [
      {
        nodeId: 'TH-ENG-CORE',
        name: 'HP Turbine Casing & Core Shroud',
        zone: 'PROPULSION',
        currentTempC: Number(coreTemp.toFixed(1)),
        maxAllowableTempC: 850.0,
        heatDissipationKW: 185.0,
        coolingCapacityKW: 240.0,
        marginC: Number((850.0 - coreTemp).toFixed(1)),
        status: coreTemp > 800 ? 'CRITICAL' : coreTemp > 750 ? 'ELEVATED' : 'NOMINAL',
      },
      {
        nodeId: 'TH-ENG-NACELLE',
        name: 'Engine Nacelle Compartment Air',
        zone: 'PROPULSION',
        currentTempC: Number(nacelleTemp.toFixed(1)),
        maxAllowableTempC: 180.0,
        heatDissipationKW: 42.0,
        coolingCapacityKW: 65.0,
        marginC: Number((180.0 - nacelleTemp).toFixed(1)),
        status: nacelleTemp > 165 ? 'ELEVATED' : 'NOMINAL',
      },
      {
        nodeId: 'TH-AV-RACK',
        name: 'Main E/E Equipment Bay (IMA Cabinets)',
        zone: 'AVIONICS',
        currentTempC: Number(avionicsTemp.toFixed(1)),
        maxAllowableTempC: 55.0,
        heatDissipationKW: 18.5,
        coolingCapacityKW: 28.0,
        marginC: Number((55.0 - avionicsTemp).toFixed(1)),
        status: 'NOMINAL',
      },
      {
        nodeId: 'TH-HYD-HX',
        name: 'Hydraulic Heat Exchanger (Fuel Tank Return)',
        zone: 'HYDRAULIC',
        currentTempC: Number(hydroTemp.toFixed(1)),
        maxAllowableTempC: 95.0,
        heatDissipationKW: 24.0,
        coolingCapacityKW: 35.0,
        marginC: Number((95.0 - hydroTemp).toFixed(1)),
        status: hydroTemp > 85 ? 'ELEVATED' : 'NOMINAL',
      },
      {
        nodeId: 'TH-CABIN-PAX',
        name: 'Passenger Cabin Zone 2 Air Flow',
        zone: 'CABIN',
        currentTempC: cabinTemp,
        maxAllowableTempC: 27.0,
        heatDissipationKW: 34.0,
        coolingCapacityKW: 45.0,
        marginC: 4.6,
        status: 'NOMINAL',
      },
      {
        nodeId: 'TH-BAT-LION',
        name: 'APU Starter Li-Ion Battery Pack',
        zone: 'BATTERY',
        currentTempC: Number(batteryTemp.toFixed(1)),
        maxAllowableTempC: 45.0,
        heatDissipationKW: 3.2,
        coolingCapacityKW: 6.5,
        marginC: Number((45.0 - batteryTemp).toFixed(1)),
        status: 'NOMINAL',
      },
    ];
  });

  setThrottle(percent: number): void {
    this.throttleLeverPercent.set(Math.max(10, Math.min(100, percent)));
  }
}
