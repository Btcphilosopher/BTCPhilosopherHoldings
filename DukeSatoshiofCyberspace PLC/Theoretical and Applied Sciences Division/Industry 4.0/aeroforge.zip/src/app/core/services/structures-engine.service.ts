import { Injectable, computed, inject, signal } from '@angular/core';
import { AircraftStateService } from './aircraft-state.service';

export interface LoadCaseResult {
  code: string;
  name: string;
  nzG: number;
  rootBendingMomentMNm: number;
  rootShearForceKN: number;
  criticalComponentId: string;
  minMarginOfSafety: number;
  status: 'SAFE' | 'WARNING' | 'CRITICAL';
}

@Injectable({
  providedIn: 'root',
})
export class StructuresEngineService {
  private aircraftState = inject(AircraftStateService);

  readonly selectedLoadCase = signal<string>('LC-25G-PULLUP');
  readonly selectedPlyAngle = signal<number>(45);

  // Load cases computation
  readonly loadCases = computed<LoadCaseResult[]>(() => {
    const mass = this.aircraftState.massProperties().mtow; // 78,000 kg
    const span = this.aircraftState.wingSpan();
    const g = 9.80665;
    const wingRelWeight = 0.88; // total weight minus wing inertia relief

    // Semi-span y_cp approx at 42% b/2
    const y_cp = (span / 2) * 0.42;

    // +2.5g Limit Maneuver Load
    const nz25 = 2.5;
    const lift25 = (mass * g * nz25) / 2; // per wing
    const netShear25 = (lift25 * wingRelWeight) / 1000; // kN
    const netMoment25 = (netShear25 * y_cp) / 1000; // MN·m

    // -1.0g Negative Push-over
    const nzNeg = -1.0;
    const liftNeg = (mass * g * Math.abs(nzNeg)) / 2;
    const netShearNeg = (liftNeg * wingRelWeight) / 1000;
    const netMomentNeg = (netShearNeg * y_cp) / 1000;

    // Gust Load Case (Pratt gust factor ~ 2.85g)
    const nzGust = 2.85;
    const liftGust = (mass * g * nzGust) / 2;
    const netShearGust = (liftGust * wingRelWeight) / 1000;
    const netMomentGust = (netShearGust * y_cp) / 1000;

    // Calculate critical margins based on wing root bending moment
    // Baseline moment ~ 14.8 MNm gives MS = +0.14
    const baseMoment = 14.8;
    const ms25 = Number((0.14 - (netMoment25 / baseMoment - 1.0) * 0.28).toFixed(2));
    const msNeg = 0.48;
    const msGust = Number((0.08 - (netMomentGust / (baseMoment * 1.14) - 1.0) * 0.25).toFixed(2));

    return [
      {
        code: 'LC-25G-PULLUP',
        name: '+2.5g Limit Maneuver Pull-Up (CS 25.337)',
        nzG: 2.5,
        rootBendingMomentMNm: Number(netMoment25.toFixed(2)),
        rootShearForceKN: Number(netShear25.toFixed(0)),
        criticalComponentId: 'STR-W-SPAR-AFT',
        minMarginOfSafety: ms25,
        status: ms25 >= 0.1 ? 'SAFE' : ms25 >= 0.0 ? 'WARNING' : 'CRITICAL',
      },
      {
        code: 'LC-10G-DIVE',
        name: '-1.0g Inverted Dive Push-Over (CS 25.337)',
        nzG: -1.0,
        rootBendingMomentMNm: Number(netMomentNeg.toFixed(2)),
        rootShearForceKN: Number(netShearNeg.toFixed(0)),
        criticalComponentId: 'STR-W-SKIN-UPPER',
        minMarginOfSafety: msNeg,
        status: 'SAFE',
      },
      {
        code: 'LC-GUST-56FPS',
        name: 'Discrete Vertical Gust U_ds = 56 ft/s (CS 25.341)',
        nzG: 2.85,
        rootBendingMomentMNm: Number(netMomentGust.toFixed(2)),
        rootShearForceKN: Number(netShearGust.toFixed(0)),
        criticalComponentId: 'STR-W-SPAR-FWD',
        minMarginOfSafety: msGust,
        status: msGust >= 0.1 ? 'SAFE' : msGust >= 0.0 ? 'WARNING' : 'CRITICAL',
      },
    ];
  });

  // Dynamic Natural Modal Frequencies (Wing Bending & Torsion)
  readonly modalFrequencies = computed(() => {
    const span = this.aircraftState.wingSpan();
    // Bending frequency scales inversely with span^2: f1 ~ k / span^2
    const spanRatio = span / 35.8;
    const f1Bending = 2.14 / Math.pow(spanRatio, 1.8);
    const f2Torsion = 6.82 / Math.pow(spanRatio, 1.2);
    const f3InPlane = 9.45 / spanRatio;

    // Flutter speed margin
    const vd = 420; // V_D dive speed in KEAS
    const vFlutter = Math.round(vd * (1.2 + (f2Torsion / 6.82 - 1.0) * 0.3));

    return {
      mode1WingBendingHz: Number(f1Bending.toFixed(2)),
      mode2WingTorsionHz: Number(f2Torsion.toFixed(2)),
      mode3InPlaneHz: Number(f3InPlane.toFixed(2)),
      flutterSpeedKtas: vFlutter,
      flutterMarginPercent: Number((((vFlutter - vd) / vd) * 100).toFixed(1)),
    };
  });

  // Composite Laminate Classical Laminate Theory (CLT) Matrix A, B, D
  readonly cltMatrix = computed(() => {
    const lam = this.aircraftState.wingLaminate();
    const t_ply = lam.plyThicknessMm * 1e-3; // m
    const E11 = 141e9; // Pa
    const E22 = 10.5e9; // Pa
    const G12 = 5.2e9; // Pa

    // In-plane stiffness A11 [MN/m]
    const totalThickness = lam.plyCount * t_ply;
    const A11_MNm = (E11 * 0.45 + E22 * 0.15 + G12 * 0.4) * totalThickness * 1e-6;
    const A22_MNm = A11_MNm * 0.62;
    const D11_Nm = (A11_MNm * 1e6 * Math.pow(totalThickness, 2)) / 12;

    return {
      a11: Number(A11_MNm.toFixed(1)),
      a22: Number(A22_MNm.toFixed(1)),
      a12: Number((A11_MNm * 0.22).toFixed(1)),
      a66: Number((A11_MNm * 0.31).toFixed(1)),
      bMatrixZero: lam.isSymmetric, // Coupling matrix B = 0 for symmetric laminate
      d11: Number(D11_Nm.toFixed(0)),
    };
  });

  setSelectedLoadCase(code: string): void {
    this.selectedLoadCase.set(code);
  }
}
