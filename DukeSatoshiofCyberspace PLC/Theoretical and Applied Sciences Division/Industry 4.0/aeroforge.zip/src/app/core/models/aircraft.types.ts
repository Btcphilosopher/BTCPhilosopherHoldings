/**
 * AEROFORGE ENTERPRISE AEROSPACE DIGITAL TWIN - CORE TYPE DEFINITIONS
 * Strongly typed engineering object models across the entire aircraft lifecycle.
 * In accordance with Section 43 of the Engineering Specification.
 */

export type UnitSystem = 'SI' | 'AVIATION';

export type ConfigurationStatus =
  | 'CONCEPT'
  | 'DRAFT'
  | 'ENGINEERING'
  | 'REVIEW'
  | 'APPROVED'
  | 'RELEASED'
  | 'OBSOLETE';

export type RequirementType =
  | 'MISSION'
  | 'PERFORMANCE'
  | 'STRUCTURAL'
  | 'AERODYNAMIC'
  | 'PROPULSION'
  | 'SYSTEMS'
  | 'SAFETY'
  | 'MANUFACTURING'
  | 'MAINTAINABILITY'
  | 'ENVIRONMENTAL'
  | 'CERTIFICATION'
  | 'COST'
  | 'SCHEDULE';

export type VerificationMethod =
  | 'ANALYSIS'
  | 'INSPECTION'
  | 'TEST'
  | 'DEMONSTRATION'
  | 'SIMULATION';

export type RequirementStatus =
  | 'UNVERIFIED'
  | 'IN_PROGRESS'
  | 'VERIFIED'
  | 'COMPLIANT'
  | 'NON_COMPLIANT';

export interface Requirement {
  id: string;
  title: string;
  description: string;
  source: string; // e.g. CS-25.101, Customer RFP
  rationale: string;
  type: RequirementType;
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  nominalValue: number;
  limitValue: number;
  unit: string;
  unitAviation: string;
  verificationMethod: VerificationMethod;
  status: RequirementStatus;
  owner: string;
  revision: string;
  targetObjectId?: string;
  verifiedBySimulationId?: string;
  evidenceRef?: string;
}

export interface AircraftGeometry {
  fuselageLength: number; // m
  fuselageDiameter: number; // m
  wingSpan: number; // m
  wingArea: number; // m²
  aspectRatio: number; // dimensionless
  sweepLeadingEdge: number; // deg
  sweepQuarterChord: number; // deg
  taperRatio: number; // dimensionless
  dihedral: number; // deg
  thicknessRatioRoot: number; // %
  thicknessRatioTip: number; // %
  horizontalTailSpan: number; // m
  horizontalTailArea: number; // m²
  verticalTailHeight: number; // m
  verticalTailArea: number; // m²
  engineNacelleLength: number; // m
  engineNacelleDiameter: number; // m
  engineCount: number;
  engineThrustClass: number; // kN (per engine)
  cabinSeatsCount: number;
  cabinRowPitch: number; // inches
}

export interface MassPropertyBreakdown {
  oew: number; // kg - Operating Empty Weight
  mtow: number; // kg - Maximum Takeoff Weight
  mlw: number; // kg - Maximum Landing Weight
  mzfw: number; // kg - Maximum Zero Fuel Weight
  maxPayload: number; // kg
  maxFuel: number; // kg
  currentFuel: number; // kg
  currentPayload: number; // kg
  currentGrossWeight: number; // kg

  // Subsystem Mass Breakdown
  structuralMass: number; // kg
  propulsionMass: number; // kg
  systemsMass: number; // kg
  interiorsMass: number; // kg
  avionicsMass: number; // kg
  operatingItemsMass: number; // kg

  // Center of Gravity & Inertia
  cgX: number; // m from nose
  cgY: number; // m from centerline
  cgZ: number; // m from waterline
  cgMacPercent: number; // % Mean Aerodynamic Chord
  macLength: number; // m
  macLeadingEdgeX: number; // m
  staticMarginPercent: number; // % MAC

  // Inertia Tensor [kg·m²]
  ixx: number;
  iyy: number;
  izz: number;
  ixz: number;

  // Mass Growth Tracking
  baselineOew: number;
  currentVarianceKg: number;
  reserveBudgetKg: number;
}

export type AeroFidelityLevel =
  | 'LEVEL_1_ANALYTICAL'
  | 'LEVEL_2_VORTEX_LATTICE'
  | 'LEVEL_3_POTENTIAL_FLOW'
  | 'LEVEL_4_RANS_CFD'
  | 'LEVEL_5_EXTERNAL_SOLVER';

export interface AerodynamicState {
  fidelity: AeroFidelityLevel;
  mach: number;
  altitude: number; // m
  angleAtAttackDeg: number; // alpha
  sideslipAngleDeg: number; // beta
  reynoldsNumber: number;
  liftCoefficient: number; // CL
  dragCoefficient: number; // CD
  pitchingMomentCoefficient: number; // CM
  liftToDragRatio: number; // L/D
  cd0: number; // parasite drag
  cdInduced: number; // induced drag
  cdWave: number; // wave drag
  criticalMach: number;
  dragDivergenceMach: number;

  // Stability Derivatives (per radian or deg)
  cL_alpha: number;
  cM_alpha: number;
  cl_beta: number; // dihedral effect
  cn_beta: number; // directional stability

  // Spanwise lift distribution samples [station 2y/b from 0 to 1, local cl * c / c_avg]
  spanwiseLift: { eta: number; liftDensity: number; idealElliptic: number }[];
}

export interface MaterialSpec {
  id: string;
  name: string;
  category: 'ALUMINIUM' | 'TITANIUM' | 'STEEL' | 'NICKEL_ALLOY' | 'CARBON_COMPOSITE' | 'GLASS_COMPOSITE';
  density: number; // kg/m³
  yieldStrengthMPa: number; // MPa
  ultimateStrengthMPa: number; // MPa
  elasticModulusGPa: number; // GPa
  poissonsRatio: number;
  thermalExpansionPPM: number; // 10^-6 / K
  allowableFatigueCycles: number;
}

export interface StructuralComponent {
  id: string;
  name: string;
  parentSubsystem: string;
  materialId: string;
  materialName: string;
  nominalThicknessMm: number;
  calculatedStressMPa: number;
  allowableStressMPa: number;
  marginOfSafety: number; // (Allowable / (Applied * 1.5)) - 1
  bucklingRatio: number;
  fatigueLifePercentage: number;
  weightKg: number;
  inspectionStatus: 'CONFORMING' | 'MINOR_DEVIATION' | 'NON_CONFORMING';
}

export interface CompositeLaminate {
  id: string;
  partName: string;
  plyCount: number;
  plyThicknessMm: number;
  stackingSequence: number[]; // e.g. [0, 45, 90, -45, -45, 90, 45, 0]
  isSymmetric: boolean;
  isBalanced: boolean;
  cureCycleHours: number;
  autoclaveTempC: number;
  autoclavePressureBar: number;
  tsaiWuFailureIndex: number; // < 1.0 is safe
  delaminationRiskIndex: number; // 0.0 to 1.0
}

export interface PropulsionStation {
  stationId: string;
  name: string;
  totalPressureKPa: number;
  totalTemperatureK: number;
  mach: number;
}

export interface PropulsionState {
  engineModel: string;
  thrustPerEngineKN: number;
  netThrustTotalKN: number;
  bypassRatio: number;
  overallPressureRatio: number;
  fanDiameterM: number;
  turbineInletTempK: number;
  n1FanSpeedPercent: number;
  n2CoreSpeedPercent: number;
  tsfcKgPerKNh: number; // Specific fuel consumption
  fuelFlowKgPerSec: number;
  thermalEfficiency: number;
  propulsiveEfficiency: number;
  egtMarginDegC: number;
  stations: PropulsionStation[];
}

export interface ElectricalBus {
  id: string;
  name: string;
  voltage: number;
  frequency: number; // 400Hz for AC, 0 for DC
  connectedLoadKW: number;
  capacityKW: number;
  isEnergized: boolean;
  source: 'IDG1' | 'IDG2' | 'APU' | 'RAT' | 'BATTERY' | 'GROUND_POWER';
}

export interface HydraulicCircuit {
  id: 'GREEN' | 'BLUE' | 'YELLOW';
  name: string;
  pressurePsi: number;
  targetPressurePsi: number;
  fluidTempC: number;
  fluidLevelPercent: number;
  primaryPumpActive: boolean;
  backupPumpActive: boolean;
  ptuActive: boolean;
}

export interface FuelTank {
  id: string;
  name: string;
  capacityKg: number;
  currentFuelKg: number;
  temperatureC: number;
  boostPump1Active: boolean;
  boostPump2Active: boolean;
  cgXM: number;
}

export interface AircraftSystemsState {
  electrical: {
    idg1Active: boolean;
    idg2Active: boolean;
    apuGenActive: boolean;
    ratDeployed: boolean;
    batteryVoltage: number;
    buses: ElectricalBus[];
    sheddedLoads: string[];
  };
  hydraulic: {
    circuits: HydraulicCircuit[];
  };
  fuel: {
    tanks: FuelTank[];
    crossfeedOpen: boolean;
    jettisonActive: boolean;
  };
  environmental: {
    pack1Active: boolean;
    pack2Active: boolean;
    cabinAltitudeFt: number;
    cabinDeltaPressurePsi: number;
    cabinTempC: number;
    outflowValvePositionPercent: number;
  };
  flightControl: {
    rollTrimDeg: number;
    pitchTrimDeg: number;
    yawTrimDeg: number;
    autopilotEngaged: boolean;
    autopilotMode: 'ALT_HOLD' | 'HDG_SEL' | 'SPD_MACH' | 'LNAV_VNAV' | 'MANUAL';
    sasEngaged: boolean;
  };
}

export interface FlightDynamics6DOF {
  timeSec: number;
  altitudeM: number;
  trueAirspeedMps: number;
  calibratedAirspeedKts: number;
  mach: number;
  pitchAngleDeg: number;
  rollAngleDeg: number;
  yawAngleDeg: number;
  pitchRateDegPerSec: number;
  rollRateDegPerSec: number;
  yawRateDegPerSec: number;
  normalAccelerationG: number; // nz
  lateralAccelerationG: number; // ny
  axialAccelerationG: number; // nx
  elevatorDeflectionDeg: number;
  aileronDeflectionDeg: number;
  rudderDeflectionDeg: number;
  flightPathAngleDeg: number;
}

export interface FlightTestCard {
  id: string;
  code: string;
  title: string;
  objective: string;
  manoeuvreType: 'TAKEOFF_FIELD' | 'CLIMB_SCHEDULE' | 'CRUISE_SPEED' | 'DUTCH_ROLL_STABILITY' | 'STALL_EXPLORATION' | 'OEI_TRIM';
  targetMach: number;
  targetAltitudeFt: number;
  predictedMetric: string;
  simulatedMetric: string;
  variancePercent: number;
  verdict: 'PASS' | 'MARGINAL' | 'FAIL';
  evidenceHash: string;
}

export interface Workstation {
  id: string;
  stationNumber: number;
  name: string;
  description: string;
  taktTimeHours: number;
  actualCycleTimeHours: number;
  wipUnits: number;
  utilizationPercent: number;
  isBottleneck: boolean;
  activeRobotsCount: number;
  defectCountLast10Units: number;
  status: 'OPTIMAL' | 'RUNNING' | 'CONSTRAINED' | 'MAINTENANCE';
}

export interface QualityMetric {
  featureName: string;
  nominalMm: number;
  upperToleranceMm: number;
  lowerToleranceMm: number;
  measuredMeanMm: number;
  stdDeviationMm: number;
  cp: number;
  cpk: number;
  firstPassYieldPercent: number;
  defectRatePPM: number;
}

export interface NonConformanceReport {
  ncrId: string;
  partNumber: string;
  partName: string;
  stationId: string;
  severity: 'CRITICAL' | 'MAJOR' | 'MINOR';
  discrepancy: string;
  rootCause: string;
  disposition: 'USE_AS_IS' | 'REWORK' | 'SCRAP' | 'RETURN_TO_SUPPLIER';
  status: 'OPEN' | 'INVESTIGATING' | 'DISPOSITIONED' | 'CLOSED';
  createdAt: string;
}

export interface CertificationItem {
  id: string;
  regulationCode: string; // e.g. CS 25.101, CS 25.301
  title: string;
  category: 'PERFORMANCE' | 'STRUCTURES' | 'PROPULSION' | 'SYSTEMS' | 'CABIN_SAFETY';
  complianceMethod: VerificationMethod;
  associatedRequirementId: string;
  testCardRef: string;
  analysisReportRef: string;
  complianceStatus: 'COMPLIANT' | 'OPEN_ANALYSIS' | 'PENDING_FLIGHT_TEST' | 'FINDING';
  evidenceHash: string;
  complianceOfficer: string;
}

export interface DigitalThreadNode {
  id: string;
  label: string;
  category:
    | 'REQUIREMENT'
    | 'SYSTEM'
    | 'ASSEMBLY'
    | 'PART'
    | 'MATERIAL'
    | 'PROCESS'
    | 'MACHINE'
    | 'INSPECTION'
    | 'SIMULATION'
    | 'TEST'
    | 'EVIDENCE';
  status: 'VERIFIED' | 'STALE' | 'IN_PROGRESS' | 'COMPLIANT';
  details: string;
  metadata?: Record<string, string | number>;
}

export interface DigitalThreadEdge {
  from: string;
  to: string;
  relation: string;
}

export interface AircraftVariant {
  id: string;
  code: 'AF-100' | 'AF-100ER' | 'AF-100LR' | 'AF-100F' | 'AF-100M';
  name: string;
  tagline: string;
  mtowKg: number;
  maxFuelKg: number;
  passengerCapacity: number;
  cargoPayloadKg: number;
  rangeNm: number;
  thrustClassKN: number;
  fuselageLengthM: number;
  wingSpanM: number;
  isCertifiedBaseline: boolean;
}
