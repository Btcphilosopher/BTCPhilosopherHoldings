import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AircraftStateService } from './core/services/aircraft-state.service';
import { UnitConverter } from './core/services/unit-converter.service';
import { AircraftViewer } from './features/aircraft-viewer/aircraft-viewer';
import { DigitalThreadView } from './features/digital-thread/digital-thread-view';
import { RequirementsView } from './features/requirements/requirements-view';
import { MassPropertiesView } from './features/mass-properties/mass-properties-view';
import { AerodynamicsView } from './features/aerodynamics/aerodynamics-view';
import { StructuresView } from './features/structures/structures-view';
import { PropulsionView } from './features/propulsion/propulsion-view';
import { SystemsView } from './features/systems/systems-view';
import { FlightTestView } from './features/flight-test/flight-test-view';
import { PerformanceView } from './features/performance/performance-view';
import { ManufacturingView } from './features/manufacturing/manufacturing-view';
import { QualityView } from './features/quality/quality-view';
import { TradeStudiesView } from './features/trade-studies/trade-studies-view';
import { CertificationView } from './features/certification/certification-view';
import { AssistantPanel } from './features/assistant/assistant-panel';

export type MainNavModule =
  | 'AIRCRAFT_CONFIG'
  | 'DIGITAL_THREAD'
  | 'REQUIREMENTS'
  | 'MASS_PROPERTIES'
  | 'AERODYNAMICS'
  | 'STRUCTURES'
  | 'PROPULSION'
  | 'SYSTEMS'
  | 'FLIGHT_TEST'
  | 'PERFORMANCE'
  | 'MANUFACTURING'
  | 'QUALITY'
  | 'TRADE_STUDIES'
  | 'CERTIFICATION'
  | 'ASSISTANT';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    MatIconModule,
    AircraftViewer,
    DigitalThreadView,
    RequirementsView,
    MassPropertiesView,
    AerodynamicsView,
    StructuresView,
    PropulsionView,
    SystemsView,
    FlightTestView,
    PerformanceView,
    ManufacturingView,
    QualityView,
    TradeStudiesView,
    CertificationView,
    AssistantPanel,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  aircraftState = inject(AircraftStateService);
  unitConverter = inject(UnitConverter);

  readonly activeModule = signal<MainNavModule>('AIRCRAFT_CONFIG');

  // Section 60: 14-Step First Demonstration Walkthrough
  readonly showDemoBar = signal<boolean>(true);
  readonly currentDemoStep = signal<number>(1);

  readonly demoSteps = [
    { step: 1, title: 'Open AF-100 Digital Aircraft', targetModule: 'AIRCRAFT_CONFIG' as MainNavModule },
    { step: 2, title: 'Show 3D Aircraft & Section View', targetModule: 'AIRCRAFT_CONFIG' as MainNavModule },
    { step: 3, title: 'Open Mass Properties & CG Envelope', targetModule: 'MASS_PROPERTIES' as MainNavModule },
    { step: 4, title: 'Open Aerodynamic Drag Polar & CFD', targetModule: 'AERODYNAMICS' as MainNavModule },
    { step: 5, title: 'Run a 2,500 NM Mission Profile', targetModule: 'PERFORMANCE' as MainNavModule },
    { step: 6, title: 'Show 6-DOF Flight Dynamics & Test Card', targetModule: 'FLIGHT_TEST' as MainNavModule },
    { step: 7, title: 'Open Structural FEA Model & Composites', targetModule: 'STRUCTURES' as MainNavModule },
    { step: 8, title: 'Show Virtual Manufacturing Factory', targetModule: 'MANUFACTURING' as MainNavModule },
    { step: 9, title: 'Trace Wing Component in Digital Thread', targetModule: 'DIGITAL_THREAD' as MainNavModule },
    { step: 10, title: 'Open Certification Evidence Matrix', targetModule: 'CERTIFICATION' as MainNavModule },
    { step: 11, title: 'Modify Wing Span by +3%', targetModule: 'AIRCRAFT_CONFIG' as MainNavModule },
    { step: 12, title: 'Run Impact Analysis (Audit Stale Models)', targetModule: 'ASSISTANT' as MainNavModule },
    { step: 13, title: 'Run Updated Simulations & Re-Baseline', targetModule: 'AIRCRAFT_CONFIG' as MainNavModule },
    { step: 14, title: 'Compare Family Configurations', targetModule: 'TRADE_STUDIES' as MainNavModule },
  ];

  toggleDemoBar(): void {
    this.showDemoBar.update((v) => !v);
  }

  setModule(mod: MainNavModule): void {
    this.activeModule.set(mod);
  }

  // Demonstration Step Execution
  executeStep(stepNumber: number): void {
    const s = this.demoSteps.find((item) => item.step === stepNumber);
    if (!s) return;
    this.currentDemoStep.set(stepNumber);
    this.activeModule.set(s.targetModule);

    // Contextual Step Actions
    if (stepNumber === 11) {
      // Modify Wing Span (+3% from 35.8m -> 36.87m)
      this.aircraftState.setWingSpan(36.87);
    } else if (stepNumber === 13) {
      // Re-run simulations and re-baseline
      this.aircraftState.runUpdatedSimulations();
    }
  }

  nextDemoStep(): void {
    const next = this.currentDemoStep() + 1;
    if (next <= 14) {
      this.executeStep(next);
    } else {
      this.currentDemoStep.set(1);
      this.executeStep(1);
    }
  }

  prevDemoStep(): void {
    const prev = this.currentDemoStep() - 1;
    if (prev >= 1) {
      this.executeStep(prev);
    }
  }

  onSpanSliderChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.aircraftState.setWingSpan(val);
  }

  onFuselageLengthChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.aircraftState.setFuselageLength(val);
  }

  onAreaSliderChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.aircraftState.setWingArea(val);
  }

  onSweepSliderChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.aircraftState.setSweep(val);
  }
}
