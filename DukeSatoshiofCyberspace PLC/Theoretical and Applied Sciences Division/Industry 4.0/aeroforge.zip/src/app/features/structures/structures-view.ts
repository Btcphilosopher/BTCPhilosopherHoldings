import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { AircraftStateService } from '../../core/services/aircraft-state.service';
import { StructuresEngineService } from '../../core/services/structures-engine.service';
import { UnitConverter } from '../../core/services/unit-converter.service';

@Component({
  selector: 'app-structures-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './structures-view.html',
})
export class StructuresView {
  structuresService = inject(StructuresEngineService);
  aircraftState = inject(AircraftStateService);
  unitConverter = inject(UnitConverter);

  selectLoadCase(code: string): void {
    this.structuresService.setSelectedLoadCase(code);
  }
}
