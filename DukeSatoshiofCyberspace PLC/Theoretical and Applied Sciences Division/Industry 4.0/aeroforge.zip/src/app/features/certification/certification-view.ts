import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { AircraftStateService } from '../../core/services/aircraft-state.service';

@Component({
  selector: 'app-certification-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './certification-view.html',
})
export class CertificationView {
  aircraftState = inject(AircraftStateService);

  readonly operationalAhmState = {
    flightHoursTotal: 4820,
    flightCyclesTotal: 2150,
    engine1EgtMarginDegC: 44.5,
    engine2EgtMarginDegC: 46.2,
    nextScheduledCheck: 'A-Check (Due in 180 Flight Hours)',
    cCheckDueHours: 3180,
    dCheckDueHours: 15180,
    structuralHealthStatus: '100% NOMINAL',
  };

  readonly costBreakdown = {
    developmentBillionUSD: 4.8,
    manufacturingPerUnitMillionUSD: 44.2,
    directOperatingCostPerBlockHourUSD: 3620,
    fuelCostFractionPercent: 38.5,
    maintenanceCostFractionPercent: 21.0,
  };
}
