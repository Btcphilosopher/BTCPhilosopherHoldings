import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { FlightTestCard } from '../../core/models/aircraft.types';
import { FlightDynamicsService } from '../../core/services/flight-dynamics.service';
import { UnitConverter } from '../../core/services/unit-converter.service';

@Component({
  selector: 'app-flight-test-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './flight-test-view.html',
})
export class FlightTestView {
  flightService = inject(FlightDynamicsService);
  unitConverter = inject(UnitConverter);

  readonly testCards: {
    type: FlightTestCard['manoeuvreType'];
    title: string;
    description: string;
  }[] = [
    {
      type: 'TAKEOFF_FIELD',
      title: 'TC-01: Takeoff Field Length & Rotation Dynamics',
      description: 'Balanced field length verification and V1 engine-out rotation at MTOW.',
    },
    {
      type: 'CRUISE_SPEED',
      title: 'TC-02: Transonic Cruise Mach & Buffet Boundary',
      description: 'Mach 0.785 at FL370 with wave drag onset tracking and trim stability.',
    },
    {
      type: 'DUTCH_ROLL_STABILITY',
      title: 'TC-03: Dutch Roll Natural Oscillation & SAS Damping',
      description: 'Rudder doublet input with Yaw Damper disabled to verify modal period.',
    },
    {
      type: 'STALL_EXPLORATION',
      title: 'TC-04: High-Altitude Clean Configuration Stall',
      description: '1 kt/sec deceleration at FL300 to measure stick-shaker margin.',
    },
  ];

  selectTestCard(type: FlightTestCard['manoeuvreType']): void {
    this.flightService.setManoeuvre(type);
  }
}
