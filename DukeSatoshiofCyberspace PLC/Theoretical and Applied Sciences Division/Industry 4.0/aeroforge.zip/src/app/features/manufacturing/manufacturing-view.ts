import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { AircraftStateService } from '../../core/services/aircraft-state.service';
import { ManufacturingTwinService } from '../../core/services/manufacturing-twin.service';

@Component({
  selector: 'app-manufacturing-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './manufacturing-view.html',
})
export class ManufacturingView {
  mfgService = inject(ManufacturingTwinService);
  aircraftState = inject(AircraftStateService);

  onCapacityBoostChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.mfgService.setFalCapacityBoost(val);
  }
}
