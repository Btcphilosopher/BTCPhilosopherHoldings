import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { AircraftStateService } from '../../core/services/aircraft-state.service';
import { UnitConverter } from '../../core/services/unit-converter.service';

@Component({
  selector: 'app-mass-properties-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './mass-properties-view.html',
})
export class MassPropertiesView {
  aircraftState = inject(AircraftStateService);
  unitConverter = inject(UnitConverter);

  get mass() {
    return this.aircraftState.massProperties();
  }

  // CG envelope vertices (% MAC vs Weight in kg)
  readonly cgEnvelopePolygon = [
    { cg: 16.0, weight: 42000 },
    { cg: 16.0, weight: 65000 },
    { cg: 22.0, weight: 78000 },
    { cg: 34.0, weight: 78000 },
    { cg: 35.0, weight: 65000 },
    { cg: 34.0, weight: 42000 },
  ];
}
