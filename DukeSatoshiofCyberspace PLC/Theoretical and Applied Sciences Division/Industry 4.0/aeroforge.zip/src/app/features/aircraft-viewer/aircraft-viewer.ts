import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  PLATFORM_ID,
  effect,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { AircraftStateService } from '../../core/services/aircraft-state.service';
import { UnitConverter } from '../../core/services/unit-converter.service';

export type ViewerDisplayMode = 'SURFACE' | 'STRUCTURAL' | 'WIRING' | 'HYDRAULIC' | 'THERMAL';

@Component({
  selector: 'app-aircraft-viewer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './aircraft-viewer.html',
  styleUrl: './aircraft-viewer.css',
})
export class AircraftViewer implements OnInit, OnDestroy {
  private platformId = inject(PLATFORM_ID);
  aircraftState = inject(AircraftStateService);
  unitConverter = inject(UnitConverter);

  readonly canvasContainer = viewChild<ElementRef<HTMLDivElement>>('canvasContainer');

  // Display toggles
  readonly displayMode = signal<ViewerDisplayMode>('SURFACE');
  readonly isExploded = signal<boolean>(false);
  readonly isSectionView = signal<boolean>(false);
  readonly showGrid = signal<boolean>(true);
  readonly activeViewAngle = signal<'ISO' | 'TOP' | 'SIDE' | 'FRONT'>('ISO');

  // Three.js internal objects
  private renderer: THREE.WebGLRenderer | null = null;
  private scene: THREE.Scene | null = null;
  private camera: THREE.PerspectiveCamera | null = null;
  private animFrameId: number | null = null;

  // Assembly groups for exploded view animation
  private aircraftRoot: THREE.Group | null = null;
  private fuselageGroup: THREE.Group | null = null;
  private leftWingGroup: THREE.Group | null = null;
  private rightWingGroup: THREE.Group | null = null;
  private empennageGroup: THREE.Group | null = null;
  private leftEngineGroup: THREE.Group | null = null;
  private rightEngineGroup: THREE.Group | null = null;
  private landingGearGroup: THREE.Group | null = null;
  private internalSystemsGroup: THREE.Group | null = null;

  // Clipping plane for section view
  private sectionClipPlane = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0.2);

  // Mouse interaction & orbit controls
  private isDragging = false;
  private isPanning = false;
  private prevMouseX = 0;
  private prevMouseY = 0;
  private spherical = { radius: 65, theta: Math.PI / 4, phi: Math.PI / 3 };
  private cameraTarget = new THREE.Vector3(0, 2, 0);

  // Raycasting for component clicking
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  constructor() {
    // React to parametric changes (wing span, fuselage length)
    effect(() => {
      const span = this.aircraftState.wingSpan();
      const length = this.aircraftState.fuselageLength();
      if (this.aircraftRoot) {
        this.rebuildAircraftGeometry(span, length);
      }
    });

    // React to display mode changes
    effect(() => {
      const mode = this.displayMode();
      this.applyDisplayMode(mode);
    });

    // React to exploded view
    effect(() => {
      const exploded = this.isExploded();
      this.animateExplode(exploded);
    });

    // React to section view
    effect(() => {
      const section = this.isSectionView();
      if (this.renderer) {
        this.renderer.localClippingEnabled = section;
      }
    });
  }

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      setTimeout(() => this.initThree(), 50);
    }
  }

  ngOnDestroy(): void {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private initThree(): void {
    const container = this.canvasContainer()?.nativeElement;
    if (!container) return;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 560;

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0c1017); // Dark aerospace slate

    // Camera
    this.camera = new THREE.PerspectiveCamera(42, width / height, 0.5, 500);
    this.updateCameraPosition();

    // WebGL Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // Engineering Coordinate Grid & Datum Marks
    const gridHelper = new THREE.GridHelper(80, 40, 0x334155, 0x1e293b);
    gridHelper.position.y = -3.2;
    this.scene.add(gridHelper);

    // Studio & Aerodynamic Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    this.scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xf8fafc, 1.4);
    keyLight.position.set(30, 45, 25);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 2048;
    keyLight.shadow.mapSize.height = 2048;
    this.scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 0.6); // Aerospace sky-blue rim
    rimLight.position.set(-25, 20, -30);
    this.scene.add(rimLight);

    const fillLight = new THREE.DirectionalLight(0x94a3b8, 0.4);
    fillLight.position.set(0, -20, 15);
    this.scene.add(fillLight);

    // Build the parametric 3D aircraft model
    this.rebuildAircraftGeometry(this.aircraftState.wingSpan(), this.aircraftState.fuselageLength());

    // Mouse listeners for orbital rotation & pan
    const dom = this.renderer.domElement;
    dom.addEventListener('mousedown', (e) => this.onMouseDown(e));
    window.addEventListener('mousemove', (e) => this.onMouseMove(e));
    window.addEventListener('mouseup', () => this.onMouseUp());
    dom.addEventListener('wheel', (e) => this.onWheel(e), { passive: false });
    dom.addEventListener('click', (e) => this.onClick(e));

    window.addEventListener('resize', () => this.onResize());

    // Render loop
    this.animate();
  }

  private updateCameraPosition(): void {
    if (!this.camera) return;
    const x = this.cameraTarget.x + this.spherical.radius * Math.sin(this.spherical.phi) * Math.sin(this.spherical.theta);
    const y = this.cameraTarget.y + this.spherical.radius * Math.cos(this.spherical.phi);
    const z = this.cameraTarget.z + this.spherical.radius * Math.sin(this.spherical.phi) * Math.cos(this.spherical.theta);
    this.camera.position.set(x, y, z);
    this.camera.lookAt(this.cameraTarget);
  }

  private animate = () => {
    this.animFrameId = requestAnimationFrame(this.animate);
    if (this.renderer && this.scene && this.camera) {
      this.renderer.render(this.scene, this.camera);
    }
  };

  private rebuildAircraftGeometry(span: number, length: number): void {
    if (!this.scene) return;

    if (this.aircraftRoot) {
      this.scene.remove(this.aircraftRoot);
    }

    this.aircraftRoot = new THREE.Group();
    this.fuselageGroup = new THREE.Group();
    this.leftWingGroup = new THREE.Group();
    this.rightWingGroup = new THREE.Group();
    this.empennageGroup = new THREE.Group();
    this.leftEngineGroup = new THREE.Group();
    this.rightEngineGroup = new THREE.Group();
    this.landingGearGroup = new THREE.Group();
    this.internalSystemsGroup = new THREE.Group();

    // Aerospace Material Master Palette
    const surfaceMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0, // Aeronautical white/aluminum
      metalness: 0.25,
      roughness: 0.35,
      clippingPlanes: this.isSectionView() ? [this.sectionClipPlane] : [],
      clipShadows: true,
    });

    const carbonCompositeMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b, // Dark carbon fiber
      metalness: 0.15,
      roughness: 0.45,
      clippingPlanes: this.isSectionView() ? [this.sectionClipPlane] : [],
    });

    const titaniumPylonMat = new THREE.MeshStandardMaterial({
      color: 0x64748b,
      metalness: 0.6,
      roughness: 0.3,
    });

    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0x0f172a,
      metalness: 0.1,
      roughness: 0.1,
      transmission: 0.75,
      transparent: true,
      opacity: 0.85,
    });

    // 1. Fuselage
    const fusRadius = 1.975; // 3.95m diameter
    const fusCylLength = length * 0.62;
    const noseLength = length * 0.18;
    const tailLength = length * 0.20;

    // Center Cabin Cylinder
    const cabinGeo = new THREE.CylinderGeometry(fusRadius, fusRadius, fusCylLength, 32, 1, false);
    cabinGeo.rotateZ(Math.PI / 2);
    const cabinMesh = new THREE.Mesh(cabinGeo, surfaceMat);
    cabinMesh.userData = { id: 'STR-FUS-CABIN', name: 'Fuselage Main Passenger Cabin' };
    this.fuselageGroup.add(cabinMesh);

    // Cockpit Nose Cone
    const noseGeo = new THREE.ConeGeometry(fusRadius, noseLength, 32);
    noseGeo.rotateZ(-Math.PI / 2);
    const noseMesh = new THREE.Mesh(noseGeo, surfaceMat);
    noseMesh.position.x = fusCylLength / 2 + noseLength / 2;
    noseMesh.userData = { id: 'STR-FUS-NOSE', name: 'Nose Radome & Forward Bulkhead' };
    this.fuselageGroup.add(noseMesh);

    // Cockpit Windshield Visor
    const windshieldGeo = new THREE.BoxGeometry(1.8, 0.7, 1.6);
    const windshieldMesh = new THREE.Mesh(windshieldGeo, glassMat);
    windshieldMesh.position.set(fusCylLength / 2 + 1.2, 0.9, 0);
    this.fuselageGroup.add(windshieldMesh);

    // Aft Tail Cone
    const tailGeo = new THREE.ConeGeometry(fusRadius, tailLength, 32);
    tailGeo.rotateZ(Math.PI / 2);
    const tailMesh = new THREE.Mesh(tailGeo, surfaceMat);
    tailMesh.position.x = -(fusCylLength / 2 + tailLength / 2);
    tailMesh.position.y = 0.35; // Slight upsweep
    tailMesh.userData = { id: 'STR-FUS-TAIL', name: 'Aft Fuselage & APU Compartment' };
    this.fuselageGroup.add(tailMesh);

    // 2. Wings (Parametric Span)
    const semiSpan = span / 2;
    const rootChord = 6.8;
    const sweep = this.aircraftState.sweepQuarterChord();

    // Procedural Swept Wing Geometry using Extrude
    const createWingMesh = (isLeft: boolean) => {
      const wingGroup = new THREE.Group();
      const zDir = isLeft ? 1 : -1;

      // Primary Wing Box Skin (Carbon Composite Upper Skin)
      const wingBoxGeo = new THREE.BoxGeometry(rootChord * 0.65, 0.62, semiSpan);
      wingBoxGeo.rotateY((sweep * Math.PI) / 180 * (isLeft ? 1 : -1));
      wingBoxGeo.rotateZ((5.5 * Math.PI) / 180 * (isLeft ? -1 : 1)); // Dihedral

      const wingMesh = new THREE.Mesh(wingBoxGeo, carbonCompositeMat);
      wingMesh.position.set(-0.5, -0.2, (semiSpan / 2 + 1.2) * zDir);
      wingMesh.userData = {
        id: isLeft ? 'STR-W-BOX-LEFT' : 'STR-W-BOX-RIGHT',
        name: isLeft ? 'Left Wing Box Assembly' : 'Right Wing Box Assembly',
      };
      wingGroup.add(wingMesh);

      // Winglet / Blended Wingtip
      const wingletGeo = new THREE.BoxGeometry(1.2, 2.2, 0.15);
      const wingletMesh = new THREE.Mesh(wingletGeo, surfaceMat);
      wingletMesh.position.set(-2.5, 0.9, (semiSpan + 1.2) * zDir);
      wingletMesh.rotation.x = isLeft ? -0.2 : 0.2;
      wingGroup.add(wingletMesh);

      return wingGroup;
    };

    this.leftWingGroup = createWingMesh(true);
    this.rightWingGroup = createWingMesh(false);

    // 3. Empennage (Vertical & Horizontal Stabilizers)
    // Vertical Fin
    const finGeo = new THREE.BoxGeometry(4.2, 6.2, 0.38);
    finGeo.rotateZ(0.38); // Sweep
    const finMesh = new THREE.Mesh(finGeo, surfaceMat);
    finMesh.position.set(-(fusCylLength / 2 + tailLength * 0.6), 4.2, 0);
    finMesh.userData = { id: 'STR-TAIL-VFIN', name: 'Vertical Stabilizer & Rudder' };
    this.empennageGroup.add(finMesh);

    // Horizontal Stabilizers
    const hStabGeo = new THREE.BoxGeometry(3.1, 0.32, 12.4);
    const hStabMesh = new THREE.Mesh(hStabGeo, surfaceMat);
    hStabMesh.position.set(-(fusCylLength / 2 + tailLength * 0.8), 1.6, 0);
    hStabMesh.userData = { id: 'STR-TAIL-HSTAB', name: 'Horizontal Stabilizer & Elevators' };
    this.empennageGroup.add(hStabMesh);

    // 4. Turbofan Engines & Pylons (120 kN Class)
    const createEngineMesh = (isLeft: boolean) => {
      const engGroup = new THREE.Group();
      const zOffset = (span * 0.29) * (isLeft ? 1 : -1);

      // Nacelle Outer Cowling
      const nacelleGeo = new THREE.CylinderGeometry(1.05, 0.98, 4.2, 24);
      nacelleGeo.rotateZ(Math.PI / 2);
      const nacelleMesh = new THREE.Mesh(nacelleGeo, surfaceMat);
      nacelleMesh.position.set(1.2, -1.6, zOffset);
      nacelleMesh.userData = {
        id: isLeft ? 'PROP-ENG-LEFT' : 'PROP-ENG-RIGHT',
        name: isLeft ? 'Left Turbofan Engine Nacelle' : 'Right Turbofan Engine Nacelle',
      };
      engGroup.add(nacelleMesh);

      // Fan Face (Spinning Fan Disk)
      const fanGeo = new THREE.CylinderGeometry(0.88, 0.88, 0.2, 16);
      fanGeo.rotateZ(Math.PI / 2);
      const fanMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8, roughness: 0.2 });
      const fanMesh = new THREE.Mesh(fanGeo, fanMat);
      fanMesh.position.set(3.0, -1.6, zOffset);
      engGroup.add(fanMesh);

      // Pylon Strut (Titanium Ti-6Al-4V)
      const pylonGeo = new THREE.BoxGeometry(2.4, 0.8, 0.28);
      const pylonMesh = new THREE.Mesh(pylonGeo, titaniumPylonMat);
      pylonMesh.position.set(0.6, -0.85, zOffset);
      pylonMesh.userData = { id: 'STR-W-RIB-14', name: 'Wing Rib #14 (Pylon Mount Station WS-1400)' };
      engGroup.add(pylonMesh);

      return engGroup;
    };

    this.leftEngineGroup = createEngineMesh(true);
    this.rightEngineGroup = createEngineMesh(false);

    // 5. Landing Gear (Nose + Main Twin Bogies)
    const gearMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.7, roughness: 0.3 });
    const tyreMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.9 });

    // Nose Gear
    const noseStrutGeo = new THREE.CylinderGeometry(0.12, 0.12, 2.8, 12);
    const noseStrutMesh = new THREE.Mesh(noseStrutGeo, gearMat);
    noseStrutMesh.position.set(fusCylLength * 0.42, -2.1, 0);
    this.landingGearGroup.add(noseStrutMesh);

    // Main Gears
    const lgGroup = this.landingGearGroup;
    if (lgGroup) {
      [-3.8, 3.8].forEach((z) => {
        const mainStrut = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 3.1, 12), gearMat);
        mainStrut.position.set(-1.2, -2.2, z);
        lgGroup.add(mainStrut);

        // Tyres (Twin Wheels)
        [-0.4, 0.4].forEach((wheelZ) => {
          const tyre = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.35, 16), tyreMat);
          tyre.rotateX(Math.PI / 2);
          tyre.position.set(-1.2, -3.2, z + wheelZ);
          lgGroup.add(tyre);
        });
      });
    }

    // 6. Internal Systems (Electrical Loom & Hydraulic Lines)
    const elecWireMat = new THREE.MeshBasicMaterial({ color: 0xfbbf24 }); // Amber electrical
    const hydGreenMat = new THREE.MeshBasicMaterial({ color: 0x10b981 }); // Green hydro

    const sysGroup = this.internalSystemsGroup;
    if (sysGroup) {
      // Fuselage Central Wire Harness
      const harnessGeo = new THREE.CylinderGeometry(0.04, 0.04, length * 0.7, 8);
      harnessGeo.rotateZ(Math.PI / 2);
      const harnessMesh = new THREE.Mesh(harnessGeo, elecWireMat);
      harnessMesh.position.set(0, 1.2, 0.4);
      sysGroup.add(harnessMesh);

      // Wing Hydraulic Feed Tubes
      [-1, 1].forEach((dir) => {
        const hydGeo = new THREE.CylinderGeometry(0.03, 0.03, semiSpan * 0.85, 8);
        hydGeo.rotateX(Math.PI / 2);
        const hydMesh = new THREE.Mesh(hydGeo, hydGreenMat);
        hydMesh.position.set(-0.8, -0.15, (semiSpan * 0.45) * dir);
        sysGroup.add(hydMesh);
      });
    }

    // Add groups to aircraft root
    if (this.aircraftRoot) {
      if (this.fuselageGroup) this.aircraftRoot.add(this.fuselageGroup);
      if (this.leftWingGroup) this.aircraftRoot.add(this.leftWingGroup);
      if (this.rightWingGroup) this.aircraftRoot.add(this.rightWingGroup);
      if (this.empennageGroup) this.aircraftRoot.add(this.empennageGroup);
      if (this.leftEngineGroup) this.aircraftRoot.add(this.leftEngineGroup);
      if (this.rightEngineGroup) this.aircraftRoot.add(this.rightEngineGroup);
      if (this.landingGearGroup) this.aircraftRoot.add(this.landingGearGroup);
      if (this.internalSystemsGroup) this.aircraftRoot.add(this.internalSystemsGroup);

      this.scene.add(this.aircraftRoot);
      this.applyDisplayMode(this.displayMode());
    }
  }

  private applyDisplayMode(mode: ViewerDisplayMode): void {
    if (!this.aircraftRoot) return;

    this.aircraftRoot.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        const mat = child.material as THREE.MeshStandardMaterial;
        if (!mat) return;

        if (mode === 'STRUCTURAL') {
          mat.wireframe = true;
          if (mat.color) {
            mat.color.setHex(0x38bdf8);
          }
        } else if (mode === 'WIRING') {
          mat.wireframe = false;
          if (child.userData?.['id']?.includes('FUS') || child.userData?.['id']?.includes('WING')) {
            mat.transparent = true;
            mat.opacity = 0.25;
          }
        } else if (mode === 'HYDRAULIC') {
          mat.wireframe = false;
          if (child.userData?.['id']?.includes('FUS') || child.userData?.['id']?.includes('WING')) {
            mat.transparent = true;
            mat.opacity = 0.3;
          }
        } else if (mode === 'THERMAL') {
          mat.wireframe = false;
          mat.transparent = false;
          mat.opacity = 1.0;
          if (child.userData?.['id']?.includes('ENG')) {
            mat.color?.setHex(0xf97316); // Hot orange engine
          } else if (child.userData?.['id']?.includes('NOSE')) {
            mat.color?.setHex(0x0ea5e9); // Cool nose
          } else {
            mat.color?.setHex(0x64748b);
          }
        } else {
          // Standard SURFACE
          mat.wireframe = false;
          mat.transparent = false;
          mat.opacity = 1.0;
          if (child.userData?.['id']?.includes('SKIN') || child.userData?.['id']?.includes('BOX')) {
            mat.color?.setHex(0x1e293b);
          } else {
            mat.color?.setHex(0xe2e8f0);
          }
        }
      }
    });

    if (this.internalSystemsGroup) {
      this.internalSystemsGroup.visible = mode === 'WIRING' || mode === 'HYDRAULIC' || mode === 'STRUCTURAL';
    }
  }

  private animateExplode(exploded: boolean): void {
    const factor = exploded ? 1.0 : 0.0;
    if (this.leftWingGroup) this.leftWingGroup.position.z = 6.0 * factor;
    if (this.rightWingGroup) this.rightWingGroup.position.z = -6.0 * factor;
    if (this.leftEngineGroup) {
      this.leftEngineGroup.position.set(2.0 * factor, -3.0 * factor, 4.0 * factor);
    }
    if (this.rightEngineGroup) {
      this.rightEngineGroup.position.set(2.0 * factor, -3.0 * factor, -4.0 * factor);
    }
    if (this.empennageGroup) this.empennageGroup.position.x = -8.0 * factor;
    if (this.landingGearGroup) this.landingGearGroup.position.y = -3.5 * factor;
  }

  // Predefined camera view changes
  setViewAngle(angle: 'ISO' | 'TOP' | 'SIDE' | 'FRONT'): void {
    this.activeViewAngle.set(angle);
    if (angle === 'ISO') {
      this.spherical = { radius: 65, theta: Math.PI / 4, phi: Math.PI / 3 };
    } else if (angle === 'TOP') {
      this.spherical = { radius: 70, theta: 0, phi: 0.05 };
    } else if (angle === 'SIDE') {
      this.spherical = { radius: 65, theta: Math.PI / 2, phi: Math.PI / 2 };
    } else if (angle === 'FRONT') {
      this.spherical = { radius: 60, theta: 0, phi: Math.PI / 2 };
    }
    this.cameraTarget.set(0, 1.5, 0);
    this.updateCameraPosition();
  }

  // Mouse handlers for Orbit / Pan
  private onMouseDown(e: MouseEvent): void {
    if (e.button === 0) {
      this.isDragging = true;
    } else if (e.button === 2) {
      this.isPanning = true;
    }
    this.prevMouseX = e.clientX;
    this.prevMouseY = e.clientY;
  }

  private onMouseMove(e: MouseEvent): void {
    if (!this.isDragging && !this.isPanning) return;
    const deltaX = e.clientX - this.prevMouseX;
    const deltaY = e.clientY - this.prevMouseY;

    if (this.isDragging) {
      this.spherical.theta -= deltaX * 0.008;
      this.spherical.phi = Math.max(0.1, Math.min(Math.PI - 0.1, this.spherical.phi - deltaY * 0.008));
    } else if (this.isPanning) {
      this.cameraTarget.x -= deltaX * 0.05;
      this.cameraTarget.y += deltaY * 0.05;
    }

    this.prevMouseX = e.clientX;
    this.prevMouseY = e.clientY;
    this.updateCameraPosition();
  }

  private onMouseUp(): void {
    this.isDragging = false;
    this.isPanning = false;
  }

  private onWheel(e: WheelEvent): void {
    e.preventDefault();
    this.spherical.radius = Math.max(15, Math.min(180, this.spherical.radius + e.deltaY * 0.05));
    this.updateCameraPosition();
  }

  private onClick(e: MouseEvent): void {
    if (!this.renderer || !this.camera || !this.scene) return;
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.scene.children, true);

    if (intersects.length > 0) {
      const hit = intersects[0].object;
      const compId = hit.userData?.['id'];
      if (compId) {
        const found = this.aircraftState.structuralComponents().find((c) => c.id === compId);
        if (found) {
          this.aircraftState.selectComponent(found);
        } else {
          // Select default wing component
          this.aircraftState.selectComponent(this.aircraftState.structuralComponents()[0]);
        }
      } else {
        // Fallback default selection
        this.aircraftState.selectComponent(this.aircraftState.structuralComponents()[0]);
      }
    }
  }

  private onResize(): void {
    const container = this.canvasContainer()?.nativeElement;
    if (!container || !this.renderer || !this.camera) return;
    const width = container.clientWidth;
    const height = container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  setDisplayMode(mode: ViewerDisplayMode): void {
    this.displayMode.set(mode);
  }

  toggleExplode(): void {
    this.isExploded.update((v) => !v);
  }

  toggleSection(): void {
    this.isSectionView.update((v) => !v);
  }

  toggleGrid(): void {
    this.showGrid.update((v) => !v);
    const grid = this.scene?.children.find((c) => c instanceof THREE.GridHelper);
    if (grid) grid.visible = this.showGrid();
  }

  resetCamera(): void {
    this.setViewAngle('ISO');
  }
}
