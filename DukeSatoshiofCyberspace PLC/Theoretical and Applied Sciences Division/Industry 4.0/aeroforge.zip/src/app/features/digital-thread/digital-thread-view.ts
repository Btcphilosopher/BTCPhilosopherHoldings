import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { KeyValuePipe } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalThreadService } from '../../core/services/digital-thread.service';

@Component({
  selector: 'app-digital-thread-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, KeyValuePipe],
  templateUrl: './digital-thread-view.html',
})
export class DigitalThreadView {
  threadService = inject(DigitalThreadService);

  readonly categories = [
    'ALL',
    'REQUIREMENT',
    'SYSTEM',
    'ASSEMBLY',
    'PART',
    'MATERIAL',
    'PROCESS',
    'MACHINE',
    'INSPECTION',
    'SIMULATION',
    'TEST',
    'EVIDENCE',
  ];

  filteredNodes() {
    const cat = this.threadService.filterCategory();
    const all = this.threadService.nodes();
    if (cat === 'ALL') return all;
    return all.filter((n) => n.category === cat);
  }

  getBadgeColor(cat: string): string {
    switch (cat) {
      case 'REQUIREMENT':
        return 'text-sky-400';
      case 'SYSTEM':
      case 'ASSEMBLY':
        return 'text-indigo-400';
      case 'PART':
        return 'text-blue-400';
      case 'MATERIAL':
        return 'text-amber-400';
      case 'PROCESS':
      case 'MACHINE':
        return 'text-teal-400';
      case 'INSPECTION':
      case 'TEST':
        return 'text-purple-400';
      case 'SIMULATION':
        return 'text-cyan-400';
      case 'EVIDENCE':
        return 'text-emerald-400';
      default:
        return 'text-slate-400';
    }
  }
}
