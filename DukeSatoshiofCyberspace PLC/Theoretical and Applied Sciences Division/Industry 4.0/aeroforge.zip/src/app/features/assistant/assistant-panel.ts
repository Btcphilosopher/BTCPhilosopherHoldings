import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { GeminiAssistantService } from '../../core/services/gemini-assistant.service';

@Component({
  selector: 'app-assistant-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './assistant-panel.html',
})
export class AssistantPanel {
  assistantService = inject(GeminiAssistantService);

  readonly userInput = signal<string>('');

  readonly sampleQueries: string[] = [
    'What changes across the digital thread if the wing span increases by 3%?',
    'Why did the aircraft mass increase by 420 kg since Concept freeze?',
    'Audit verification gaps for CS-25.571 damage tolerance and ultrasonic NDI',
    'Summarize final assembly line bottlenecks at Station 25 and Station 40',
  ];

  readonly reportTypes: string[] = [
    'Concept',
    'Mass Properties',
    'Aerodynamics',
    'Structures',
    'Propulsion',
    'Manufacturing',
    'Quality & NDI',
    'Flight Test',
    'Verification & Cert',
  ];

  onInputChange(event: Event): void {
    const target = event.target as HTMLInputElement;
    this.userInput.set(target.value);
  }

  send(query?: string): void {
    const q = query || this.userInput();
    if (!q.trim()) return;
    this.assistantService.sendQuery(q, 'AEROFORGE-WORKBENCH');
    this.userInput.set('');
  }

  generateReport(type: string): void {
    this.assistantService.generateReport(type);
  }

  closeModal(): void {
    this.assistantService.closeReportModal();
  }
}
