import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { Requirement } from '../../core/models/aircraft.types';
import { AircraftStateService } from '../../core/services/aircraft-state.service';
import { UnitConverter } from '../../core/services/unit-converter.service';

@Component({
  selector: 'app-requirements-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './requirements-view.html',
})
export class RequirementsView {
  aircraftState = inject(AircraftStateService);
  unitConverter = inject(UnitConverter);

  readonly selectedTypeFilter = signal<string>('ALL');
  readonly searchQuery = signal<string>('');
  readonly selectedRequirement = signal<Requirement | null>(null);

  readonly requirementTypes: string[] = [
    'ALL',
    'MISSION',
    'PERFORMANCE',
    'STRUCTURAL',
    'PROPULSION',
    'SAFETY',
    'MANUFACTURING',
  ];

  filteredRequirements() {
    const list = this.aircraftState.requirements();
    const typeFilter = this.selectedTypeFilter();
    const q = this.searchQuery().toLowerCase().trim();

    return list.filter((r) => {
      const matchesType = typeFilter === 'ALL' || r.type === typeFilter;
      const matchesSearch =
        !q ||
        r.id.toLowerCase().includes(q) ||
        r.title.toLowerCase().includes(q) ||
        r.description.toLowerCase().includes(q) ||
        r.source.toLowerCase().includes(q);
      return matchesType && matchesSearch;
    });
  }

  setTypeFilter(type: string): void {
    this.selectedTypeFilter.set(type);
  }

  onSearch(event: Event): void {
    const target = event.target as HTMLInputElement;
    this.searchQuery.set(target.value);
  }

  selectRequirement(req: Requirement): void {
    this.selectedRequirement.set(req);
  }
}
