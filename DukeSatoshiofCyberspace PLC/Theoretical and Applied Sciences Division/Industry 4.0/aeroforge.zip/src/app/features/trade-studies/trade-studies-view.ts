import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { TradeStudyService } from '../../core/services/trade-study.service';
import { UnitConverter } from '../../core/services/unit-converter.service';

@Component({
  selector: 'app-trade-studies-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './trade-studies-view.html',
})
export class TradeStudiesView {
  tradeService = inject(TradeStudyService);
  unitConverter = inject(UnitConverter);

  runSimulation(): void {
    this.tradeService.runMonteCarlo();
  }
}
