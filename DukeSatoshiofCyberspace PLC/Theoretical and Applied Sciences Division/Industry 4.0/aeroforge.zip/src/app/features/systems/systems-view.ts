import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { SystemsSimulatorService } from '../../core/services/systems-simulator.service';
import { UnitConverter } from '../../core/services/unit-converter.service';

@Component({
  selector: 'app-systems-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './systems-view.html',
})
export class SystemsView {
  sysService = inject(SystemsSimulatorService);
  unitConverter = inject(UnitConverter);
}
