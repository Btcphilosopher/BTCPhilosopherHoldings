import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MissionPerformanceService } from '../../core/services/mission-performance.service';
import { UnitConverter } from '../../core/services/unit-converter.service';

@Component({
  selector: 'app-performance-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './performance-view.html',
})
export class PerformanceView {
  perfService = inject(MissionPerformanceService);
  unitConverter = inject(UnitConverter);

  onDistanceChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.perfService.setMissionDistance(val);
  }
}
