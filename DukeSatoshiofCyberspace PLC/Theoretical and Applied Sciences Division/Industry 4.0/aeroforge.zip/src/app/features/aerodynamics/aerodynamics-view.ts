import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { AeroFidelityLevel } from '../../core/models/aircraft.types';
import { AerodynamicsEngineService } from '../../core/services/aerodynamics-engine.service';
import { AircraftStateService } from '../../core/services/aircraft-state.service';
import { CfdWorkbenchService } from '../../core/services/cfd-workbench.service';

@Component({
  selector: 'app-aerodynamics-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './aerodynamics-view.html',
})
export class AerodynamicsView {
  aeroService = inject(AerodynamicsEngineService);
  cfdService = inject(CfdWorkbenchService);
  aircraftState = inject(AircraftStateService);

  readonly activeAeroTab = signal<'POLARS' | 'CFD_WORKBENCH'>('POLARS');

  readonly fidelityLevels: { key: AeroFidelityLevel; label: string; desc: string }[] = [
    { key: 'LEVEL_1_ANALYTICAL', label: 'Level 1: Analytical', desc: 'Prandtl lifting line + semi-empirical compressibility' },
    { key: 'LEVEL_2_VORTEX_LATTICE', label: 'Level 2: Vortex Lattice', desc: '3D panel vortex ring method on cambered mean surfaces' },
    { key: 'LEVEL_3_POTENTIAL_FLOW', label: 'Level 3: Full Potential', desc: 'Non-linear transonic potential flow approximation' },
    { key: 'LEVEL_4_RANS_CFD', label: 'Level 4: RANS CFD', desc: 'Compressible Navier-Stokes with k-omega SST turbulence' },
  ];

  onFidelityChange(lvl: AeroFidelityLevel): void {
    this.aeroService.setFidelity(lvl);
  }

  onAlphaChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.aeroService.setFlightConditions(this.aeroService.currentMach(), this.aeroService.currentAltitudeM(), val);
  }

  onMachChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.aeroService.setFlightConditions(val, this.aeroService.currentAltitudeM(), this.aeroService.angleOfAttackDeg());
  }
}
