import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { PropulsionThermalService } from '../../core/services/propulsion-thermal.service';
import { UnitConverter } from '../../core/services/unit-converter.service';

@Component({
  selector: 'app-propulsion-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './propulsion-view.html',
})
export class PropulsionView {
  propService = inject(PropulsionThermalService);
  unitConverter = inject(UnitConverter);

  onThrottleChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.propService.setThrottle(val);
  }
}
