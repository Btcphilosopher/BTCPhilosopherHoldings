import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { AircraftStateService } from '../../core/services/aircraft-state.service';
import { QualityEngineService } from '../../core/services/quality-engine.service';

@Component({
  selector: 'app-quality-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './quality-view.html',
})
export class QualityView {
  qualityService = inject(QualityEngineService);
  aircraftState = inject(AircraftStateService);

  readonly techniques: {
    key: 'ULTRASONIC_PHASED_ARRAY' | 'XRAY_RADIOGRAPHY' | 'EDDY_CURRENT' | 'THERMOGRAPHY';
    label: string;
    desc: string;
  }[] = [
    { key: 'ULTRASONIC_PHASED_ARRAY', label: 'Ultrasonic Phased Array (PAUT)', desc: 'Depth & delamination detection in composite laminates' },
    { key: 'XRAY_RADIOGRAPHY', label: 'Digital X-Ray Radiography', desc: 'Internal void, inclusion, and fastener shear inspection' },
    { key: 'EDDY_CURRENT', label: 'Eddy Current High-Freq (EC)', desc: 'Surface & sub-surface micro-crack detection in Al/Ti alloys' },
    { key: 'THERMOGRAPHY', label: 'Pulsed Infrared Thermography', desc: 'Disbond identification in honeycomb sandwich structures' },
  ];
}
