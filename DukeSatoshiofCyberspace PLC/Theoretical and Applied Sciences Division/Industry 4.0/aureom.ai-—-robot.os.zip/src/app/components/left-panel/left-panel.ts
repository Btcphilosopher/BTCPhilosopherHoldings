import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RobotSimulationService } from '../../robot/services/robot-simulation.service';
import { OperatingMode } from '../../robot/models/robot.types';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-left-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <aside class="w-72 h-full bg-slate-950/95 border-r border-slate-800 p-4 flex flex-col gap-4 overflow-y-auto select-none">
      <!-- Panel Header -->
      <div class="flex items-center justify-between pb-2 border-b border-slate-800">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-400 text-lg">tune</mat-icon>
          <span class="text-xs font-bold tracking-wider text-slate-200">ROBOT SUPERVISOR</span>
        </div>
        <span class="text-[10px] font-mono font-medium text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
          RT-60Hz
        </span>
      </div>

      <!-- Execution Environment & Safety Gate (Section 28) -->
      <div class="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col gap-2">
        <div class="flex items-center justify-between">
          <span class="text-xs font-semibold text-slate-300">EXECUTION MODE</span>
          <span
            class="text-[10px] font-mono font-bold px-2 py-0.5 rounded"
            [class.bg-emerald-500/10]="sim.executionEnv() === 'SIMULATION'"
            [class.text-emerald-400]="sim.executionEnv() === 'SIMULATION'"
            [class.bg-rose-500/10]="sim.executionEnv() !== 'SIMULATION'"
            [class.text-rose-400]="sim.executionEnv() !== 'SIMULATION'"
          >
            {{ sim.executionEnv() }}
          </span>
        </div>

        <p class="text-[11px] text-slate-400 leading-snug">
          Simulation mode isolates all motion to the digital twin. Physical hardware bridge is interlocked by safety supervisor.
        </p>

        <!-- Hardware Gate Toggle -->
        <div class="pt-1 flex items-center justify-between border-t border-slate-800/80">
          <span class="text-[11px] text-slate-400">Physical HW Arming:</span>
          <button
            type="button"
            (click)="toggleHardwareMode()"
            class="px-2 py-1 text-[10px] font-mono font-semibold rounded border transition-colors cursor-pointer"
            [class.bg-rose-500/20]="sim.hardwareModeUnlocked()"
            [class.border-rose-500/50]="sim.hardwareModeUnlocked()"
            [class.text-rose-300]="sim.hardwareModeUnlocked()"
            [class.bg-slate-800]="!sim.hardwareModeUnlocked()"
            [class.border-slate-700]="!sim.hardwareModeUnlocked()"
            [class.text-slate-400]="!sim.hardwareModeUnlocked()"
          >
            {{ sim.hardwareModeUnlocked() ? 'HW ENABLED' : 'HW LOCKED (SAFE)' }}
          </button>
        </div>
      </div>

      <!-- Emergency Stop Box (Section 27) -->
      <div class="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col gap-2">
        <div class="flex items-center justify-between">
          <span class="text-xs font-semibold text-slate-300">SAFETY SUPERVISOR</span>
          <span
            class="text-[10px] font-mono font-bold px-2 py-0.5 rounded"
            [class.bg-rose-500/20]="sim.emergencyStopTriggered()"
            [class.text-rose-400]="sim.emergencyStopTriggered()"
            [class.bg-emerald-500/10]="!sim.emergencyStopTriggered()"
            [class.text-emerald-400]="!sim.emergencyStopTriggered()"
          >
            {{ sim.emergencyStopTriggered() ? 'E-STOP ACTIVE' : 'NOMINAL' }}
          </span>
        </div>

        @if (sim.emergencyStopTriggered()) {
          <div class="p-2 bg-rose-950/40 border border-rose-500/30 rounded-lg text-rose-300 text-[11px] leading-tight flex items-start gap-2">
            <mat-icon class="text-rose-400 text-sm mt-0.5">warning</mat-icon>
            <div>
              <p class="font-bold">MOTION INHIBITED</p>
              <p class="text-[10px] text-rose-200/80">Actuator power bus isolated. Software & hardware dead-man triggered.</p>
            </div>
          </div>
          <button
            type="button"
            (click)="sim.resetEmergencyStop()"
            class="w-full py-1.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
          >
            Acknowledge & Clear E-Stop
          </button>
        } @else {
          <button
            type="button"
            (click)="sim.triggerEmergencyStop()"
            class="w-full py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-sm transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <mat-icon class="text-sm">emergency</mat-icon>
            <span>TRIGGER E-STOP</span>
          </button>
        }
      </div>

      <!-- Operating Mode Selector (Section 23) -->
      <div class="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col gap-2">
        <span class="text-xs font-semibold text-slate-300">OPERATING MODE</span>
        <div class="grid grid-cols-2 gap-1.5">
          @for (mode of modes; track mode) {
            <button
              type="button"
              (click)="setMode(mode)"
              [class.bg-amber-500]="sim.operatingMode() === mode"
              [class.text-slate-950]="sim.operatingMode() === mode"
              [class.font-bold]="sim.operatingMode() === mode"
              [class.bg-slate-800]="sim.operatingMode() !== mode"
              [class.text-slate-400]="sim.operatingMode() !== mode"
              class="py-1.5 px-2 text-[10px] rounded-lg transition-colors text-center cursor-pointer"
            >
              {{ mode }}
            </button>
          }
        </div>
      </div>

      <!-- Battery Telemetry (Section 19, 25) -->
      <div class="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col gap-2">
        <div class="flex items-center justify-between">
          <span class="text-xs font-semibold text-slate-300">BATTERY SYSTEM</span>
          <span class="text-xs font-mono font-bold text-amber-400">
            {{ sim.batteryLevel().toFixed(1) }}%
          </span>
        </div>

        <!-- Battery Bar -->
        <div class="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
          <div
            class="h-full bg-emerald-500 transition-all duration-300 rounded-full"
            [style.width.%]="sim.batteryLevel()"
            [class.bg-amber-500]="sim.batteryLevel() < 40"
            [class.bg-rose-500]="sim.batteryLevel() < 15"
          ></div>
        </div>

        <div class="grid grid-cols-2 gap-2 pt-1 text-[11px] font-mono text-slate-400">
          <div>Voltage: <span class="text-slate-200">{{ sim.batteryVoltage().toFixed(1) }} V</span></div>
          <div>Current: <span class="text-slate-200">{{ sim.batteryCurrent().toFixed(2) }} A</span></div>
          <div>Motor T: <span class="text-slate-200">{{ sim.motorTemp().toFixed(1) }} °C</span></div>
          <div>Solar: <span class="text-amber-400">+18 W</span></div>
        </div>
      </div>

      <!-- Robot Kinematic Pose Readout (Section 31) -->
      <div class="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col gap-1.5">
        <span class="text-xs font-semibold text-slate-300">ODOMETRY & POSE</span>
        <div class="text-[11px] font-mono text-slate-400 flex flex-col gap-1">
          <div class="flex justify-between">
            <span>Position X:</span>
            <span class="text-slate-200 font-bold">{{ sim.pose().x.toFixed(3) }} m</span>
          </div>
          <div class="flex justify-between">
            <span>Position Y:</span>
            <span class="text-slate-200 font-bold">{{ sim.pose().y.toFixed(3) }} m</span>
          </div>
          <div class="flex justify-between">
            <span>Heading (Yaw):</span>
            <span class="text-slate-200 font-bold">{{ sim.pose().heading.toFixed(3) }} rad ({{ ((sim.pose().heading * 180) / 3.14159).toFixed(1) }}°)</span>
          </div>
          <div class="flex justify-between">
            <span>Linear Vel (v):</span>
            <span class="text-amber-400 font-bold">{{ sim.pose().linearVelocity.toFixed(2) }} m/s</span>
          </div>
          <div class="flex justify-between">
            <span>Angular Vel (ω):</span>
            <span class="text-amber-400 font-bold">{{ sim.pose().angularVelocity.toFixed(2) }} rad/s</span>
          </div>
          <div class="flex justify-between">
            <span>Left Track:</span>
            <span class="text-slate-300">{{ sim.pose().leftWheelSpeed.toFixed(2) }} m/s</span>
          </div>
          <div class="flex justify-between">
            <span>Right Track:</span>
            <span class="text-slate-300">{{ sim.pose().rightWheelSpeed.toFixed(2) }} m/s</span>
          </div>
        </div>
      </div>
    </aside>
  `,
})
export class LeftPanelComponent {
  public sim = inject(RobotSimulationService);

  public modes: OperatingMode[] = [
    'MANUAL',
    'AUTONOMOUS',
    'ARM_CONTROL',
    'TASK_EXECUTION',
    'IDLE',
    'PAUSED',
  ];

  public setMode(mode: OperatingMode): void {
    this.sim.operatingMode.set(mode);
  }

  public toggleHardwareMode(): void {
    if (!this.sim.hardwareModeUnlocked()) {
      const confirmAuth = window.confirm(
        'HARDWARE MODE SAFETY GATE:\n\n' +
        'Enabling physical hardware control will send motor commands to low-level bridge.\n' +
        'Ensure physical emergency-stop button is wired and testing zone is clear.\n\n' +
        'Proceed with hardware enablement?'
      );
      if (confirmAuth) {
        this.sim.hardwareModeUnlocked.set(true);
        this.sim.executionEnv.set('HARDWARE_GATED');
      }
    } else {
      this.sim.hardwareModeUnlocked.set(false);
      this.sim.executionEnv.set('SIMULATION');
    }
  }
}
