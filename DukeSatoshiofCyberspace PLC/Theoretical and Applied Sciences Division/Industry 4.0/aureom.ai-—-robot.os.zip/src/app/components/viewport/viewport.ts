import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  ViewChild,
  inject,
  signal,
} from '@angular/core';
import { RobotSimulationService } from '../../robot/services/robot-simulation.service';
import { Robot3DScene } from '../../robot/three/robot-scene';
import { CameraViewMode } from '../../robot/models/robot.types';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-viewport',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="relative w-full h-full bg-[#0a0e17] overflow-hidden">
      <!-- 3D Canvas Mounting Node -->
      <div #canvasContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Top Overlay: Camera Mode & Visualization Toggles -->
      <div class="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none z-10">
        <!-- Camera Selector Bar -->
        <div class="flex items-center gap-1 p-1 bg-slate-900/80 backdrop-blur-md border border-slate-800 rounded-xl pointer-events-auto shadow-md">
          <button
            type="button"
            (click)="setCamera('ORBIT')"
            [class.bg-amber-500]="activeCamera() === 'ORBIT'"
            [class.text-slate-950]="activeCamera() === 'ORBIT'"
            [class.text-slate-300]="activeCamera() !== 'ORBIT'"
            class="px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-sm">3d_rotation</mat-icon>
            <span>Orbit</span>
          </button>

          <button
            type="button"
            (click)="setCamera('FOLLOW')"
            [class.bg-amber-500]="activeCamera() === 'FOLLOW'"
            [class.text-slate-950]="activeCamera() === 'FOLLOW'"
            [class.text-slate-300]="activeCamera() !== 'FOLLOW'"
            class="px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-sm">videocam</mat-icon>
            <span>Follow</span>
          </button>

          <button
            type="button"
            (click)="setCamera('HEAD_FPV')"
            [class.bg-amber-500]="activeCamera() === 'HEAD_FPV'"
            [class.text-slate-950]="activeCamera() === 'HEAD_FPV'"
            [class.text-slate-300]="activeCamera() !== 'HEAD_FPV'"
            class="px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-sm">visibility</mat-icon>
            <span>Robot Eyes (FPV)</span>
          </button>

          <button
            type="button"
            (click)="setCamera('TOP_DOWN')"
            [class.bg-amber-500]="activeCamera() === 'TOP_DOWN'"
            [class.text-slate-950]="activeCamera() === 'TOP_DOWN'"
            [class.text-slate-300]="activeCamera() !== 'TOP_DOWN'"
            class="px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-sm">map</mat-icon>
            <span>Top-Down</span>
          </button>

          <button
            type="button"
            (click)="setCamera('ARM_INSPECTION')"
            [class.bg-amber-500]="activeCamera() === 'ARM_INSPECTION'"
            [class.text-slate-950]="activeCamera() === 'ARM_INSPECTION'"
            [class.text-slate-300]="activeCamera() !== 'ARM_INSPECTION'"
            class="px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-sm">precision_manufacturing</mat-icon>
            <span>Arm Inspector</span>
          </button>
        </div>

        <!-- Visual Layer Toggles -->
        <div class="flex items-center gap-1 p-1 bg-slate-900/80 backdrop-blur-md border border-slate-800 rounded-xl pointer-events-auto shadow-md">
          <button
            type="button"
            (click)="toggleAxes()"
            [class.text-amber-400]="showAxes()"
            [class.text-slate-400]="!showAxes()"
            title="Toggle XYZ Coordinate Axes"
            class="px-2 py-1 text-xs rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-sm">open_in_full</mat-icon>
            <span>Axes</span>
          </button>

          <button
            type="button"
            (click)="toggleRays()"
            [class.text-amber-400]="showRays()"
            [class.text-slate-400]="!showRays()"
            title="Toggle Ultrasonic Sensor Rays"
            class="px-2 py-1 text-xs rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-sm">sensors</mat-icon>
            <span>Sensor Rays</span>
          </button>

          <button
            type="button"
            (click)="togglePath()"
            [class.text-amber-400]="showPath()"
            [class.text-slate-400]="!showPath()"
            title="Toggle A* Navigation Path Trail"
            class="px-2 py-1 text-xs rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-sm">route</mat-icon>
            <span>Path</span>
          </button>
        </div>
      </div>

      <!-- Active Autonomous Task Banner -->
      @if (sim.activeTaskName()) {
        <div class="absolute top-16 left-1/2 -translate-x-1/2 px-4 py-2 bg-slate-900/90 border border-amber-500/40 rounded-xl shadow-lg z-20 pointer-events-none flex items-center gap-3 max-w-lg">
          <div class="w-3 h-3 rounded-full bg-amber-400 animate-ping"></div>
          <div class="flex flex-col">
            <span class="text-xs font-bold text-amber-300">{{ sim.activeTaskName() }}</span>
            <span class="text-[11px] text-slate-300">{{ sim.taskStepDescription() }}</span>
          </div>
          @if (sim.taskProgress() > 0) {
            <span class="text-xs font-mono font-bold text-amber-400 ml-auto">{{ sim.taskProgress() }}%</span>
          }
        </div>
      }

      <!-- Bottom-Left Live Telemetry Pill Overlay -->
      <div class="absolute bottom-16 left-4 px-3 py-2 bg-slate-950/80 backdrop-blur-md border border-slate-800/80 rounded-xl text-xs font-mono text-slate-300 pointer-events-none z-10 flex items-center gap-3">
        <div class="flex items-center gap-1 text-amber-400 font-semibold">
          <mat-icon class="text-sm">location_on</mat-icon>
          <span>Pose:</span>
        </div>
        <span>X: {{ sim.pose().x.toFixed(2) }}m</span>
        <span>Y: {{ sim.pose().y.toFixed(2) }}m</span>
        <span>θ: {{ sim.pose().heading.toFixed(2) }} rad ({{ ((sim.pose().heading * 180) / 3.14159).toFixed(0) }}°)</span>
        <span class="text-slate-500">|</span>
        <span>v: {{ sim.pose().linearVelocity.toFixed(2) }} m/s</span>
        <span>ω: {{ sim.pose().angularVelocity.toFixed(2) }} rad/s</span>
      </div>

      <!-- Bottom Floating Simulation Clock Dock -->
      <div class="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 p-1.5 bg-slate-950/90 backdrop-blur-md border border-slate-800 rounded-2xl shadow-xl z-20 pointer-events-auto">
        <!-- Play / Pause -->
        <button
          type="button"
          (click)="togglePlayPause()"
          class="w-8 h-8 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 flex items-center justify-center transition-colors cursor-pointer"
          [title]="sim.isRunning() ? 'Pause Simulation Clock' : 'Start Simulation Clock'"
        >
          <mat-icon class="text-base">{{ sim.isRunning() ? 'pause' : 'play_arrow' }}</mat-icon>
        </button>

        <!-- Single Step -->
        <button
          type="button"
          (click)="sim.stepClock()"
          title="Step Single Simulation Timestep (1/60s)"
          class="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors cursor-pointer"
        >
          <mat-icon class="text-base">skip_next</mat-icon>
        </button>

        <!-- Sim Time Display -->
        <div class="px-2.5 py-1 text-xs font-mono text-slate-300">
          <span>T: </span>
          <span class="font-bold text-amber-400">{{ sim.simulationTime().toFixed(2) }}s</span>
        </div>

        <!-- Speed Multipliers -->
        <div class="flex items-center gap-1 border-l border-slate-800 pl-2">
          @for (speed of [0.5, 1.0, 2.0, 5.0]; track speed) {
            <button
              type="button"
              (click)="sim.setSpeedMultiplier(speed)"
              [class.bg-slate-800]="sim.timeSpeedMultiplier() === speed"
              [class.text-amber-400]="sim.timeSpeedMultiplier() === speed"
              [class.text-slate-400]="sim.timeSpeedMultiplier() !== speed"
              class="px-2 py-0.5 text-[11px] font-mono rounded hover:text-white transition-colors cursor-pointer"
            >
              {{ speed }}x
            </button>
          }
        </div>
      </div>
    </div>
  `,
})
export class ViewportComponent implements AfterViewInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true })
  public containerRef!: ElementRef<HTMLDivElement>;

  public sim = inject(RobotSimulationService);
  private scene3d: Robot3DScene | null = null;
  private syncFrameId = 0;

  public activeCamera = signal<CameraViewMode>('ORBIT');
  public showAxes = signal<boolean>(true);
  public showRays = signal<boolean>(true);
  public showPath = signal<boolean>(true);

  ngAfterViewInit(): void {
    if (this.containerRef) {
      this.scene3d = new Robot3DScene(this.containerRef.nativeElement);
      this.startSyncLoop();
    }
  }

  private startSyncLoop = (): void => {
    if (this.scene3d) {
      const leftAngles = this.sim.leftArm().joints.map((j) => j.angle);
      const rightAngles = this.sim.rightArm().joints.map((j) => j.angle);

      this.scene3d.updateState(
        this.sim.pose(),
        leftAngles,
        rightAngles,
        this.sim.leftArm().gripperAperture,
        this.sim.rightArm().gripperAperture,
        this.sim.head(),
        this.sim.sensors(),
        this.sim.envObjects(),
        this.sim.activePath().map((p) => ({ x: p.x, y: p.y }))
      );
    }
    this.syncFrameId = requestAnimationFrame(this.startSyncLoop);
  };

  public setCamera(mode: CameraViewMode): void {
    this.activeCamera.set(mode);
    this.scene3d?.setCameraView(mode);
  }

  public toggleAxes(): void {
    this.showAxes.update((v) => !v);
    this.updateVisualToggles();
  }

  public toggleRays(): void {
    this.showRays.update((v) => !v);
    this.updateVisualToggles();
  }

  public togglePath(): void {
    this.showPath.update((v) => !v);
    this.updateVisualToggles();
  }

  private updateVisualToggles(): void {
    this.scene3d?.setVisualHelperToggles(
      this.showAxes(),
      this.showRays(),
      false,
      this.showPath()
    );
  }

  public togglePlayPause(): void {
    if (this.sim.isRunning()) {
      this.sim.pauseClock();
    } else {
      this.sim.startClock();
    }
  }

  ngOnDestroy(): void {
    cancelAnimationFrame(this.syncFrameId);
    this.scene3d?.destroy();
    this.scene3d = null;
  }
}
