import { ChangeDetectionStrategy, Component, inject, output, input } from '@angular/core';
import { RobotSimulationService } from '../../robot/services/robot-simulation.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-header',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <header class="flex items-center justify-between gap-8 px-6 py-3 border-b border-slate-800 bg-slate-950/90 select-none z-30">
      <!-- Zone 1: Wordmark -->
      <div class="flex items-center gap-3 shrink-0">
        <div class="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
          <mat-icon class="text-xl">smart_toy</mat-icon>
        </div>
        <div class="flex items-baseline gap-2">
          <span class="text-base font-bold tracking-tight text-white whitespace-nowrap">
            AUREOM.AI
          </span>
          <span class="text-xs font-mono font-semibold text-amber-400 tracking-wider">
            ROBOT.OS
          </span>
        </div>
      </div>

      <!-- Zone 2: Navigation / Tab links -->
      <nav class="hidden md:flex items-center gap-6 text-xs font-medium text-slate-400">
        <button
          type="button"
          (click)="tabSelected.emit('SIMULATION')"
          class="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer"
          [class.text-amber-400]="activeTab() === 'SIMULATION'"
          [class.font-semibold]="activeTab() === 'SIMULATION'"
        >
          <mat-icon class="text-sm">view_in_ar</mat-icon>
          <span>3D Simulation</span>
        </button>

        <button
          type="button"
          (click)="tabSelected.emit('EXPERIMENTS')"
          class="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer"
          [class.text-amber-400]="activeTab() === 'EXPERIMENTS'"
          [class.font-semibold]="activeTab() === 'EXPERIMENTS'"
        >
          <mat-icon class="text-sm">science</mat-icon>
          <span>Experiments (A–H)</span>
        </button>

        <button
          type="button"
          (click)="tabSelected.emit('R_CONSOLE')"
          class="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer"
          [class.text-amber-400]="activeTab() === 'R_CONSOLE'"
          [class.font-semibold]="activeTab() === 'R_CONSOLE'"
        >
          <mat-icon class="text-sm">terminal</mat-icon>
          <span>R Console</span>
        </button>

        <button
          type="button"
          (click)="tabSelected.emit('R_CODEBASE')"
          class="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer"
          [class.text-amber-400]="activeTab() === 'R_CODEBASE'"
          [class.font-semibold]="activeTab() === 'R_CODEBASE'"
        >
          <mat-icon class="text-sm">code</mat-icon>
          <span>R Codebase & Tests</span>
        </button>
      </nav>

      <!-- Zone 3: Primary Action & E-Stop Quick Trigger -->
      <div class="flex items-center gap-3 shrink-0">
        @if (sim.emergencyStopTriggered()) {
          <button
            type="button"
            (click)="sim.resetEmergencyStop()"
            class="px-3.5 py-1.5 text-xs font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 rounded-lg hover:bg-emerald-500/20 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <mat-icon class="text-sm">lock_open</mat-icon>
            <span>Reset E-Stop</span>
          </button>
        } @else {
          <button
            type="button"
            (click)="sim.triggerEmergencyStop()"
            class="px-3.5 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 active:bg-rose-800 rounded-lg transition-colors shadow-sm flex items-center gap-1.5 cursor-pointer"
          >
            <mat-icon class="text-sm">emergency</mat-icon>
            <span>EMERGENCY STOP</span>
          </button>
        }

        <button
          type="button"
          (click)="sim.resetSimulation()"
          title="Reset digital twin pose & environment"
          class="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800/80 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
        >
          <mat-icon class="text-sm">refresh</mat-icon>
          <span>Reset Lab</span>
        </button>
      </div>
    </header>
  `,
})
export class HeaderComponent {
  public sim = inject(RobotSimulationService);
  public activeTab = input<string>('SIMULATION');
  public tabSelected = output<string>();
}
