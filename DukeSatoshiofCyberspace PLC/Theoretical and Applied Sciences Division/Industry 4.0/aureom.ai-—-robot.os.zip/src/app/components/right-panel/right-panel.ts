import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { RobotSimulationService } from '../../robot/services/robot-simulation.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-right-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <aside class="w-84 h-full bg-slate-950/95 border-l border-slate-800 p-4 flex flex-col gap-4 overflow-y-auto select-none">
      <!-- Panel Header & Navigation Switcher -->
      <div class="flex items-center justify-between pb-2 border-b border-slate-800">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-400 text-lg">gamepad</mat-icon>
          <span class="text-xs font-bold tracking-wider text-slate-200">ACTUATORS & SENSORS</span>
        </div>
      </div>

      <!-- Tab Switcher between DRIVE, ARMS, HEAD, SENSORS -->
      <div class="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl">
        <button
          type="button"
          (click)="activeSection.set('DRIVE')"
          [class.bg-amber-500]="activeSection() === 'DRIVE'"
          [class.text-slate-950]="activeSection() === 'DRIVE'"
          [class.font-bold]="activeSection() === 'DRIVE'"
          [class.text-slate-400]="activeSection() !== 'DRIVE'"
          class="flex-1 py-1 text-center text-xs rounded-lg transition-colors cursor-pointer"
        >
          Drive
        </button>
        <button
          type="button"
          (click)="activeSection.set('ARMS')"
          [class.bg-amber-500]="activeSection() === 'ARMS'"
          [class.text-slate-950]="activeSection() === 'ARMS'"
          [class.font-bold]="activeSection() === 'ARMS'"
          [class.text-slate-400]="activeSection() !== 'ARMS'"
          class="flex-1 py-1 text-center text-xs rounded-lg transition-colors cursor-pointer"
        >
          Arms
        </button>
        <button
          type="button"
          (click)="activeSection.set('HEAD')"
          [class.bg-amber-500]="activeSection() === 'HEAD'"
          [class.text-slate-950]="activeSection() === 'HEAD'"
          [class.font-bold]="activeSection() === 'HEAD'"
          [class.text-slate-400]="activeSection() !== 'HEAD'"
          class="flex-1 py-1 text-center text-xs rounded-lg transition-colors cursor-pointer"
        >
          Head
        </button>
        <button
          type="button"
          (click)="activeSection.set('SENSORS')"
          [class.bg-amber-500]="activeSection() === 'SENSORS'"
          [class.text-slate-950]="activeSection() === 'SENSORS'"
          [class.font-bold]="activeSection() === 'SENSORS'"
          [class.text-slate-400]="activeSection() !== 'SENSORS'"
          class="flex-1 py-1 text-center text-xs rounded-lg transition-colors cursor-pointer"
        >
          Sensors
        </button>
      </div>

      <!-- SECTION 1: MOVEMENT & TELEOPERATION (Section 8 & 9) -->
      @if (activeSection() === 'DRIVE') {
        <div class="flex flex-col gap-3">
          <div class="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col gap-3">
            <div class="flex items-center justify-between">
              <span class="text-xs font-semibold text-slate-300">DIFFERENTIAL DRIVE PAD</span>
              <span class="text-[10px] text-slate-400 font-mono">W / A / S / D</span>
            </div>

            <!-- Directional Cross Control -->
            <div class="flex flex-col items-center gap-1.5 py-1">
              <!-- Forward Button -->
              <button
                type="button"
                (mousedown)="onDrivePress('FORWARD')"
                (mouseup)="onDriveRelease()"
                (mouseleave)="onDriveRelease()"
                (touchstart)="onDrivePress('FORWARD')"
                (touchend)="onDriveRelease()"
                class="w-32 py-2.5 bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 hover:border-amber-400 transition-all shadow flex items-center justify-center gap-1 cursor-pointer"
              >
                <mat-icon class="text-sm">arrow_upward</mat-icon>
                <span>FORWARD</span>
              </button>

              <!-- Left, Stop, Right Row -->
              <div class="flex items-center gap-1.5 w-full justify-center">
                <button
                  type="button"
                  (mousedown)="onDrivePress('LEFT')"
                  (mouseup)="onDriveRelease()"
                  (mouseleave)="onDriveRelease()"
                  (touchstart)="onDrivePress('LEFT')"
                  (touchend)="onDriveRelease()"
                  class="w-24 py-2.5 bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 hover:border-amber-400 transition-all shadow flex items-center justify-center gap-1 cursor-pointer"
                >
                  <mat-icon class="text-sm">arrow_back</mat-icon>
                  <span>LEFT</span>
                </button>

                <button
                  type="button"
                  (click)="sim.commandStop()"
                  class="w-20 py-2.5 bg-rose-600/90 hover:bg-rose-500 text-white text-xs font-bold rounded-xl border border-rose-500 transition-all shadow flex items-center justify-center gap-1 cursor-pointer"
                >
                  <mat-icon class="text-sm">stop</mat-icon>
                  <span>STOP</span>
                </button>

                <button
                  type="button"
                  (mousedown)="onDrivePress('RIGHT')"
                  (mouseup)="onDriveRelease()"
                  (mouseleave)="onDriveRelease()"
                  (touchstart)="onDrivePress('RIGHT')"
                  (touchend)="onDriveRelease()"
                  class="w-24 py-2.5 bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 hover:border-amber-400 transition-all shadow flex items-center justify-center gap-1 cursor-pointer"
                >
                  <span>RIGHT</span>
                  <mat-icon class="text-sm">arrow_forward</mat-icon>
                </button>
              </div>

              <!-- Backward Button -->
              <button
                type="button"
                (mousedown)="onDrivePress('BACKWARD')"
                (mouseup)="onDriveRelease()"
                (mouseleave)="onDriveRelease()"
                (touchstart)="onDrivePress('BACKWARD')"
                (touchend)="onDriveRelease()"
                class="w-32 py-2.5 bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 hover:border-amber-400 transition-all shadow flex items-center justify-center gap-1 cursor-pointer"
              >
                <mat-icon class="text-sm">arrow_downward</mat-icon>
                <span>BACKWARD</span>
              </button>
            </div>

            <!-- Quick Step Commands -->
            <div class="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                (click)="sim.commandDistance(0.5)"
                class="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-mono rounded-lg border border-slate-700 cursor-pointer"
              >
                Step +0.5m
              </button>
              <button
                type="button"
                (click)="sim.commandHeadingDelta(1.57)"
                class="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-mono rounded-lg border border-slate-700 cursor-pointer"
              >
                Rotate 90°
              </button>
            </div>
          </div>

          <!-- Autonomous Navigation Shortcut -->
          <div class="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col gap-2">
            <span class="text-xs font-semibold text-slate-300">AUTONOMOUS PATH PLANNER</span>
            <div class="grid grid-cols-2 gap-2">
              <button
                type="button"
                (click)="sim.planAndExecuteNavigation(1.4, 0.9)"
                class="py-2 px-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors flex items-center justify-center gap-1 cursor-pointer"
              >
                <mat-icon class="text-sm">table_restaurant</mat-icon>
                <span>To Table</span>
              </button>
              <button
                type="button"
                (click)="sim.planAndExecuteNavigation(-2.4, -2.0)"
                class="py-2 px-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors flex items-center justify-center gap-1 cursor-pointer"
              >
                <mat-icon class="text-sm">bolt</mat-icon>
                <span>To Charger</span>
              </button>
            </div>
          </div>
        </div>
      }

      <!-- SECTION 2: ROBOTIC ARMS & INVERSE KINEMATICS (Section 10–16) -->
      @if (activeSection() === 'ARMS') {
        <div class="flex flex-col gap-3">
          <!-- Arm Selection: Left vs Right -->
          <div class="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg">
            <button
              type="button"
              (click)="selectedArmRight.set(false)"
              [class.bg-amber-500]="!selectedArmRight()"
              [class.text-slate-950]="!selectedArmRight()"
              [class.font-bold]="!selectedArmRight()"
              [class.text-slate-400]="selectedArmRight()"
              class="flex-1 py-1 text-xs rounded transition-colors cursor-pointer"
            >
              Left Arm (5-DOF)
            </button>
            <button
              type="button"
              (click)="selectedArmRight.set(true)"
              [class.bg-amber-500]="selectedArmRight()"
              [class.text-slate-950]="selectedArmRight()"
              [class.font-bold]="selectedArmRight()"
              [class.text-slate-400]="!selectedArmRight()"
              class="flex-1 py-1 text-xs rounded transition-colors cursor-pointer"
            >
              Right Arm (5-DOF)
            </button>
          </div>

          <!-- Joint Sliders -->
          <div class="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col gap-2.5">
            <div class="flex items-center justify-between">
              <span class="text-xs font-semibold text-slate-300">JOINT ANGLES</span>
              <button
                type="button"
                (click)="sim.resetArmsToStow()"
                class="text-[10px] text-amber-400 hover:underline cursor-pointer"
              >
                Reset to Stow
              </button>
            </div>

            @for (joint of currentArm().joints; track joint.name; let idx = $index) {
              <div class="flex flex-col gap-1">
                <div class="flex justify-between text-[11px] font-mono">
                  <span class="text-slate-300">{{ joint.name }}</span>
                  <span class="text-amber-400">
                    {{ joint.angle.toFixed(2) }} rad ({{ ((joint.angle * 180) / 3.14159).toFixed(0) }}°)
                  </span>
                </div>
                <input
                  type="range"
                  [min]="joint.minAngle"
                  [max]="joint.maxAngle"
                  step="0.02"
                  [value]="joint.angle"
                  (input)="onJointSliderChange(idx, $event)"
                  class="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
              </div>
            }
          </div>

          <!-- Gripper Aperture & Grasp Detection (Section 15) -->
          <div class="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col gap-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-semibold text-slate-300">GRIPPER APERTURE</span>
              <span class="text-xs font-mono font-bold text-amber-400">
                {{ (currentArm().gripperAperture * 100).toFixed(0) }}%
              </span>
            </div>

            <div class="flex items-center gap-2">
              <button
                type="button"
                (click)="sim.setGripperAperture(selectedArmRight(), 1.0)"
                class="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 cursor-pointer"
              >
                OPEN
              </button>
              <button
                type="button"
                (click)="sim.setGripperAperture(selectedArmRight(), 0.0)"
                class="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 cursor-pointer"
              >
                CLOSE / GRASP
              </button>
            </div>

            <!-- Holding Object Status -->
            <div class="pt-1 flex items-center justify-between text-[11px] font-mono text-slate-400 border-t border-slate-800">
              <span>Grasped Payload:</span>
              <span class="font-bold text-slate-200">
                {{ currentArm().gripperHolding ?? 'NONE (EMPTY)' }}
              </span>
            </div>
          </div>

          <!-- End-Effector Forward Kinematics Readout (Section 12) -->
          <div class="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col gap-1.5">
            <span class="text-xs font-semibold text-slate-300">END-EFFECTOR POSITION (FK)</span>
            <div class="grid grid-cols-3 gap-1 text-[11px] font-mono text-slate-400">
              <div class="bg-slate-950/60 p-1.5 rounded">
                <div>X:</div>
                <div class="text-slate-200 font-bold">{{ currentArm().endEffectorChassis.x.toFixed(3) }}m</div>
              </div>
              <div class="bg-slate-950/60 p-1.5 rounded">
                <div>Y:</div>
                <div class="text-slate-200 font-bold">{{ currentArm().endEffectorChassis.y.toFixed(3) }}m</div>
              </div>
              <div class="bg-slate-950/60 p-1.5 rounded">
                <div>Z:</div>
                <div class="text-slate-200 font-bold">{{ currentArm().endEffectorChassis.z.toFixed(3) }}m</div>
              </div>
            </div>
          </div>

          <!-- Inverse Kinematics Target Solver (Section 13) -->
          <div class="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col gap-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-semibold text-slate-300">INVERSE KINEMATICS (IK)</span>
              <span
                class="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded"
                [class.text-emerald-400]="currentArm().ikReachable"
                [class.bg-emerald-500/10]="currentArm().ikReachable"
                [class.text-rose-400]="!currentArm().ikReachable"
                [class.bg-rose-500/10]="!currentArm().ikReachable"
              >
                {{ currentArm().ikReachable ? 'REACHABLE' : 'UNREACHABLE' }}
              </span>
            </div>

            <div class="grid grid-cols-3 gap-2">
              <div class="flex flex-col gap-1">
                <span class="text-[10px] text-slate-400 font-mono">Target X</span>
                <input
                  type="number"
                  step="0.05"
                  [value]="ikX()"
                  (input)="ikX.set(+($any($event.target).value))"
                  class="bg-slate-950 border border-slate-700 text-slate-200 text-xs px-2 py-1 rounded font-mono"
                />
              </div>
              <div class="flex flex-col gap-1">
                <span class="text-[10px] text-slate-400 font-mono">Target Y</span>
                <input
                  type="number"
                  step="0.05"
                  [value]="ikY()"
                  (input)="ikY.set(+($any($event.target).value))"
                  class="bg-slate-950 border border-slate-700 text-slate-200 text-xs px-2 py-1 rounded font-mono"
                />
              </div>
              <div class="flex flex-col gap-1">
                <span class="text-[10px] text-slate-400 font-mono">Target Z</span>
                <input
                  type="number"
                  step="0.05"
                  [value]="ikZ()"
                  (input)="ikZ.set(+($any($event.target).value))"
                  class="bg-slate-950 border border-slate-700 text-slate-200 text-xs px-2 py-1 rounded font-mono"
                />
              </div>
            </div>

            <button
              type="button"
              (click)="solveIK()"
              class="w-full py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg transition-colors cursor-pointer"
            >
              Solve & Move Arm (CCD)
            </button>
          </div>
        </div>
      }

      <!-- SECTION 3: HEAD & PERSONALITY BEHAVIORS (Section 17 & 18) -->
      @if (activeSection() === 'HEAD') {
        <div class="flex flex-col gap-3">
          <div class="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col gap-3">
            <span class="text-xs font-semibold text-slate-300">HEAD SERVOS (PAN & TILT)</span>

            <!-- Head Pan -->
            <div class="flex flex-col gap-1">
              <div class="flex justify-between text-[11px] font-mono">
                <span class="text-slate-300">Head Pan (Yaw)</span>
                <span class="text-amber-400">
                  {{ sim.head().pan.toFixed(2) }} rad ({{ ((sim.head().pan * 180) / 3.14159).toFixed(0) }}°)
                </span>
              </div>
              <input
                type="range"
                min="-1.57"
                max="1.57"
                step="0.05"
                [value]="sim.head().pan"
                (input)="sim.setHeadPan(+($any($event.target).value))"
                class="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
            </div>

            <!-- Head Tilt -->
            <div class="flex flex-col gap-1">
              <div class="flex justify-between text-[11px] font-mono">
                <span class="text-slate-300">Head Tilt (Pitch)</span>
                <span class="text-amber-400">
                  {{ sim.head().tilt.toFixed(2) }} rad ({{ ((sim.head().tilt * 180) / 3.14159).toFixed(0) }}°)
                </span>
              </div>
              <input
                type="range"
                min="-0.6"
                max="0.8"
                step="0.05"
                [value]="sim.head().tilt"
                (input)="sim.setHeadTilt(+($any($event.target).value))"
                class="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
            </div>

            <button
              type="button"
              (click)="sim.setHeadPan(0); sim.setHeadTilt(0)"
              class="py-1 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 cursor-pointer"
            >
              Center Head
            </button>
          </div>

          <!-- Personality Behaviors (Section 18) -->
          <div class="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col gap-2">
            <span class="text-xs font-semibold text-slate-300">EXPRESSIVE PERSONALITY</span>
            <div class="grid grid-cols-2 gap-2">
              <button
                type="button"
                (click)="sim.triggerPersonality('CURIOUS')"
                class="py-2 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg border border-slate-700 flex items-center justify-center gap-1 cursor-pointer"
              >
                <mat-icon class="text-sm">help</mat-icon>
                <span>Curious Tilt</span>
              </button>

              <button
                type="button"
                (click)="sim.triggerPersonality('WAVE')"
                class="py-2 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg border border-slate-700 flex items-center justify-center gap-1 cursor-pointer"
              >
                <mat-icon class="text-sm">waving_hand</mat-icon>
                <span>Greeting Wave</span>
              </button>

              <button
                type="button"
                (click)="sim.triggerPersonality('LOOK_AROUND')"
                class="py-2 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg border border-slate-700 flex items-center justify-center gap-1 cursor-pointer"
              >
                <mat-icon class="text-sm">search</mat-icon>
                <span>Look Around</span>
              </button>

              <button
                type="button"
                (click)="sim.runExperimentPickAndPlace()"
                class="py-2 px-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg border border-amber-400 flex items-center justify-center gap-1 cursor-pointer"
              >
                <mat-icon class="text-sm">play_circle</mat-icon>
                <span>Pick & Place</span>
              </button>
            </div>
          </div>
        </div>
      }

      <!-- SECTION 4: SENSORS TELEMETRY (Section 19 & 21) -->
      @if (activeSection() === 'SENSORS') {
        <div class="flex flex-col gap-2.5">
          <span class="text-xs font-semibold text-slate-300">ULTRASONIC TRANSDUCER ARRAYS</span>

          @for (sensor of sim.sensors(); track sensor.id) {
            <div class="p-2.5 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col gap-1.5">
              <div class="flex items-center justify-between text-[11px] font-mono">
                <span class="text-slate-300">{{ sensor.name }}</span>
                <span
                  class="font-bold px-1.5 py-0.5 rounded text-[10px]"
                  [class.text-emerald-400]="sensor.status === 'CLEAR'"
                  [class.bg-emerald-500/10]="sensor.status === 'CLEAR'"
                  [class.text-amber-400]="sensor.status === 'CAUTION'"
                  [class.bg-amber-500/10]="sensor.status === 'CAUTION'"
                  [class.text-rose-400]="sensor.status === 'DANGER'"
                  [class.bg-rose-500/10]="sensor.status === 'DANGER'"
                >
                  {{ sensor.measuredDistance.toFixed(2) }} m ({{ sensor.status }})
                </span>
              </div>

              <!-- Distance Bar -->
              <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  class="h-full rounded-full transition-all duration-150"
                  [style.width.%]="(sensor.measuredDistance / sensor.range) * 100"
                  [class.bg-emerald-500]="sensor.status === 'CLEAR'"
                  [class.bg-amber-500]="sensor.status === 'CAUTION'"
                  [class.bg-rose-500]="sensor.status === 'DANGER'"
                ></div>
              </div>
            </div>
          }
        </div>
      }
    </aside>
  `,
})
export class RightPanelComponent {
  public sim = inject(RobotSimulationService);

  public activeSection = signal<'DRIVE' | 'ARMS' | 'HEAD' | 'SENSORS'>('DRIVE');
  public selectedArmRight = signal<boolean>(false);

  // IK Inputs
  public ikX = signal<number>(0.25);
  public ikY = signal<number>(0.32);
  public ikZ = signal<number>(0.35);

  public currentArm = () => (this.selectedArmRight() ? this.sim.rightArm() : this.sim.leftArm());

  public onDrivePress(direction: 'FORWARD' | 'BACKWARD' | 'LEFT' | 'RIGHT'): void {
    if (direction === 'FORWARD') this.sim.commandDistance(0.4);
    else if (direction === 'BACKWARD') this.sim.commandDistance(-0.4);
    else if (direction === 'LEFT') this.sim.commandHeadingDelta(0.4);
    else if (direction === 'RIGHT') this.sim.commandHeadingDelta(-0.4);
  }

  public onDriveRelease(): void {
    // Stop commanded motion
    this.sim.commandStop();
  }

  public onJointSliderChange(idx: number, event: Event): void {
    const input = event.target as HTMLInputElement;
    const val = parseFloat(input.value);
    this.sim.setArmJointAngle(this.selectedArmRight(), idx, val);
  }

  public solveIK(): void {
    const target = { x: this.ikX(), y: this.ikY(), z: this.ikZ() };
    this.sim.solveIKTarget(this.selectedArmRight(), target);
  }
}
