import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { RobotSimulationService } from '../../robot/services/robot-simulation.service';
import { R_CODE_FILES, RFileContent } from '../../robot/r-code-repo/r-code-assets';
import { RConsoleOutput } from '../../robot/r-engine/r-command-engine';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-bottom-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <footer class="h-64 w-full bg-slate-950 border-t border-slate-800 flex flex-col select-none">
      <!-- Bottom Tab Bar -->
      <div class="flex items-center justify-between px-4 py-1.5 border-b border-slate-800 bg-slate-900/60">
        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="activeTab.set('TELEMETRY')"
            [class.text-amber-400]="activeTab() === 'TELEMETRY'"
            [class.border-amber-400]="activeTab() === 'TELEMETRY'"
            class="px-3 py-1 text-xs font-semibold border-b-2 border-transparent transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <mat-icon class="text-sm">show_chart</mat-icon>
            <span>Telemetry Streams</span>
          </button>

          <button
            type="button"
            (click)="activeTab.set('R_CONSOLE')"
            [class.text-amber-400]="activeTab() === 'R_CONSOLE'"
            [class.border-amber-400]="activeTab() === 'R_CONSOLE'"
            class="px-3 py-1 text-xs font-semibold border-b-2 border-transparent transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <mat-icon class="text-sm">terminal</mat-icon>
            <span>R Interactive Console</span>
          </button>

          <button
            type="button"
            (click)="activeTab.set('EXPERIMENTS')"
            [class.text-amber-400]="activeTab() === 'EXPERIMENTS'"
            [class.border-amber-400]="activeTab() === 'EXPERIMENTS'"
            class="px-3 py-1 text-xs font-semibold border-b-2 border-transparent transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <mat-icon class="text-sm">biotech</mat-icon>
            <span>Experiments (A–H)</span>
          </button>

          <button
            type="button"
            (click)="activeTab.set('R_CODEBASE')"
            [class.text-amber-400]="activeTab() === 'R_CODEBASE'"
            [class.border-amber-400]="activeTab() === 'R_CODEBASE'"
            class="px-3 py-1 text-xs font-semibold border-b-2 border-transparent transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <mat-icon class="text-sm">folder_code</mat-icon>
            <span>R Codebase & Tests</span>
          </button>
        </div>

        <!-- Telemetry Data Export (Section 37) -->
        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="exportTelemetryCSV()"
            class="px-2.5 py-1 text-[11px] font-mono font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-xs">download</mat-icon>
            <span>Export CSV</span>
          </button>
          <button
            type="button"
            (click)="exportTelemetryJSON()"
            class="px-2.5 py-1 text-[11px] font-mono font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-xs">data_object</mat-icon>
            <span>Export RDS/JSON</span>
          </button>
        </div>
      </div>

      <!-- Tab Content Area -->
      <div class="flex-1 overflow-hidden p-3">
        <!-- 1. TELEMETRY STREAMS -->
        @if (activeTab() === 'TELEMETRY') {
          <div class="h-full grid grid-cols-4 gap-3 text-xs font-mono">
            <!-- Chart 1: Linear & Angular Velocities -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 flex flex-col justify-between">
              <div class="flex justify-between text-slate-400 text-[11px]">
                <span>DRIVE VELOCITIES</span>
                <span class="text-amber-400 font-bold">v: {{ sim.pose().linearVelocity.toFixed(2) }} m/s</span>
              </div>
              <div class="h-20 w-full flex items-end gap-1 px-1 bg-slate-950/60 rounded">
                @for (snap of sim.telemetryHistory(); track snap.timestamp) {
                  <div
                    class="flex-1 bg-amber-400/80 rounded-t min-w-[2px]"
                    [style.height.%]="Math.min(100, Math.abs(snap.linearVelocity) * 70 + 5)"
                    [title]="'v: ' + snap.linearVelocity.toFixed(2)"
                  ></div>
                }
              </div>
              <div class="flex justify-between text-[10px] text-slate-500">
                <span>-60s</span>
                <span>Now</span>
              </div>
            </div>

            <!-- Chart 2: Left & Right Track Speeds -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 flex flex-col justify-between">
              <div class="flex justify-between text-slate-400 text-[11px]">
                <span>TRACK GROUND SPEED</span>
                <span class="text-emerald-400 font-bold">L: {{ sim.pose().leftWheelSpeed.toFixed(2) }} | R: {{ sim.pose().rightWheelSpeed.toFixed(2) }}</span>
              </div>
              <div class="h-20 w-full flex items-end gap-1 px-1 bg-slate-950/60 rounded">
                @for (snap of sim.telemetryHistory(); track snap.timestamp) {
                  <div
                    class="flex-1 bg-emerald-400/80 rounded-t min-w-[2px]"
                    [style.height.%]="Math.min(100, Math.abs(snap.leftTrackSpeed) * 60 + 5)"
                  ></div>
                }
              </div>
              <div class="flex justify-between text-[10px] text-slate-500">
                <span>b = 0.42m</span>
                <span>Track differential</span>
              </div>
            </div>

            <!-- Chart 3: Battery Discharge & Current Draw -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 flex flex-col justify-between">
              <div class="flex justify-between text-slate-400 text-[11px]">
                <span>POWER / BATTERY SoC</span>
                <span class="text-sky-400 font-bold">{{ sim.batteryVoltage().toFixed(1) }}V ({{ sim.batteryCurrent().toFixed(1) }}A)</span>
              </div>
              <div class="h-20 w-full flex items-end gap-1 px-1 bg-slate-950/60 rounded">
                @for (snap of sim.telemetryHistory(); track snap.timestamp) {
                  <div
                    class="flex-1 bg-sky-400/80 rounded-t min-w-[2px]"
                    [style.height.%]="snap.batteryLevel"
                  ></div>
                }
              </div>
              <div class="flex justify-between text-[10px] text-slate-500">
                <span>SoC: {{ sim.batteryLevel().toFixed(1) }}%</span>
                <span>24V LiFePO4</span>
              </div>
            </div>

            <!-- Chart 4: Min Proximity Range -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 flex flex-col justify-between">
              <div class="flex justify-between text-slate-400 text-[11px]">
                <span>OBSTACLE PROXIMITY</span>
                <span
                  class="font-bold"
                  [class.text-emerald-400]="minObstacleDistance() > 0.7"
                  [class.text-amber-400]="minObstacleDistance() <= 0.7 && minObstacleDistance() > 0.35"
                  [class.text-rose-400]="minObstacleDistance() <= 0.35"
                >
                  {{ minObstacleDistance().toFixed(2) }} m
                </span>
              </div>
              <div class="h-20 w-full flex items-end gap-1 px-1 bg-slate-950/60 rounded">
                @for (snap of sim.telemetryHistory(); track snap.timestamp) {
                  <div
                    class="flex-1 rounded-t min-w-[2px]"
                    [class.bg-emerald-400]="snap.minObstacleDistance > 0.7"
                    [class.bg-amber-400]="snap.minObstacleDistance <= 0.7 && snap.minObstacleDistance > 0.35"
                    [class.bg-rose-400]="snap.minObstacleDistance <= 0.35"
                    [style.height.%]="Math.min(100, (snap.minObstacleDistance / 3.5) * 100)"
                  ></div>
                }
              </div>
              <div class="flex justify-between text-[10px] text-slate-500">
                <span>Range envelope</span>
                <span>6 Transducers</span>
              </div>
            </div>
          </div>
        }

        <!-- 2. INTERACTIVE R CONSOLE (Section 32) -->
        @if (activeTab() === 'R_CONSOLE') {
          <div class="h-full flex flex-col gap-2 font-mono text-xs">
            <!-- Output log buffer -->
            <div class="flex-1 bg-slate-900/90 border border-slate-800 rounded-xl p-3 overflow-y-auto flex flex-col gap-1">
              <div class="text-slate-500">
                AUREOM.AI — ROBOT.OS R Engine (v4.3-Robotics Kernel). Type 'help()' or R expressions.
              </div>
              @for (item of consoleLogs(); track item.id) {
                <div
                  [class.text-amber-400]="item.type === 'COMMAND'"
                  [class.text-slate-300]="item.type === 'OUTPUT'"
                  [class.text-rose-400]="item.type === 'ERROR'"
                  class="whitespace-pre-wrap leading-relaxed"
                >
                  {{ item.text }}
                </div>
              }
            </div>

            <!-- Command Input Form & Quick Scripts -->
            <div class="flex items-center gap-2">
              <span class="text-amber-400 font-bold">&gt;</span>
              <input
                type="text"
                [value]="commandInput()"
                (input)="commandInput.set($any($event.target).value)"
                (keydown.enter)="executeCommand()"
                placeholder="robot$move_forward(0.5); robot$left_arm$set_joint(2, 0.4); robot$pick_and_place()"
                class="flex-1 bg-slate-900 border border-slate-700 text-slate-200 px-3 py-1.5 rounded-lg font-mono text-xs focus:outline-none focus:border-amber-400"
              />
              <button
                type="button"
                (click)="executeCommand()"
                class="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition-colors cursor-pointer"
              >
                Run R Script
              </button>

              <!-- Quick Command Snippets -->
              <button
                type="button"
                (click)="runSnippet('robot$move_forward(0.5)')"
                class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] rounded border border-slate-700 cursor-pointer"
              >
                move_forward()
              </button>
              <button
                type="button"
                (click)="runSnippet('robot$head$tilt(0.3)')"
                class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] rounded border border-slate-700 cursor-pointer"
              >
                head$tilt()
              </button>
              <button
                type="button"
                (click)="runSnippet('robot$task_pick_and_place()')"
                class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 text-[11px] rounded border border-slate-700 cursor-pointer"
              >
                task_pick_and_place()
              </button>
            </div>
          </div>
        }

        <!-- 3. BUILT-IN EXPERIMENTS A THROUGH H (Section 36) -->
        @if (activeTab() === 'EXPERIMENTS') {
          <div class="h-full overflow-y-auto grid grid-cols-4 gap-2.5">
            @for (exp of experiments; track exp.id) {
              <div class="p-2.5 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col justify-between">
                <div>
                  <div class="flex items-center justify-between pb-1">
                    <span class="text-xs font-bold text-amber-400 font-mono">{{ exp.id }}. {{ exp.title }}</span>
                  </div>
                  <p class="text-[11px] text-slate-300 leading-snug">{{ exp.desc }}</p>
                </div>
                <button
                  type="button"
                  (click)="sim.runExperiment(exp.id)"
                  class="mt-2 w-full py-1.5 bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 hover:border-amber-400 transition-colors flex items-center justify-center gap-1 cursor-pointer"
                >
                  <mat-icon class="text-sm">play_arrow</mat-icon>
                  <span>Launch {{ exp.id }}</span>
                </button>
              </div>
            }
          </div>
        }

        <!-- 4. R CODEBASE & AUTOMATED TESTS (Section 38 & 41) -->
        @if (activeTab() === 'R_CODEBASE') {
          <div class="h-full flex gap-3">
            <!-- File Tree List -->
            <div class="w-64 bg-slate-900/90 border border-slate-800 rounded-xl p-2 flex flex-col gap-1 overflow-y-auto">
              <div class="px-2 py-1 text-[10px] font-mono font-bold text-slate-400 tracking-wider">
                robot-os/ REPOSITORY
              </div>
              @for (file of rFiles; track file.filename) {
                <button
                  type="button"
                  (click)="selectedRFile.set(file)"
                  [class.bg-amber-500/20]="selectedRFile().filename === file.filename"
                  [class.text-amber-400]="selectedRFile().filename === file.filename"
                  [class.border-amber-500/40]="selectedRFile().filename === file.filename"
                  class="text-left px-2.5 py-1.5 text-xs font-mono rounded-lg border border-transparent hover:bg-slate-800 transition-colors flex items-center justify-between cursor-pointer"
                >
                  <span>{{ file.path }}</span>
                  <span class="text-[9px] text-slate-500">{{ file.category }}</span>
                </button>
              }
            </div>

            <!-- Code Viewer & Testthat Runner -->
            <div class="flex-1 bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col gap-2 overflow-hidden">
              <div class="flex items-center justify-between pb-1.5 border-b border-slate-800 text-xs font-mono">
                <span class="text-amber-400 font-bold">{{ selectedRFile().path }}</span>
                <span class="text-slate-400 text-[11px]">{{ selectedRFile().description }}</span>
                @if (selectedRFile().filename === 'test_robot.R') {
                  <button
                    type="button"
                    (click)="runTestthatTests()"
                    class="px-2.5 py-1 text-xs bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded flex items-center gap-1 cursor-pointer"
                  >
                    <mat-icon class="text-xs">task_alt</mat-icon>
                    <span>Run testthat Suite</span>
                  </button>
                }
              </div>

              <!-- Code Box -->
              <pre class="flex-1 bg-slate-950 p-2.5 rounded-lg overflow-auto font-mono text-[11px] text-slate-300 leading-relaxed">{{ selectedRFile().code }}</pre>
            </div>
          </div>
        }
      </div>
    </footer>
  `,
})
export class BottomPanelComponent {
  public sim = inject(RobotSimulationService);
  protected readonly Math = Math;

  public activeTab = signal<'TELEMETRY' | 'R_CONSOLE' | 'EXPERIMENTS' | 'R_CODEBASE'>('TELEMETRY');
  public commandInput = signal<string>('robot$move_forward(distance = 0.5)');
  public consoleLogs = signal<RConsoleOutput[]>([
    {
      id: 'init_1',
      timestamp: new Date().toLocaleTimeString(),
      type: 'OUTPUT',
      text: '[1] "AUREOM.AI — ROBOT.OS Kernel R Engine initialized. Type help() for command reference."',
    },
  ]);

  public rFiles = R_CODE_FILES;
  public selectedRFile = signal<RFileContent>(R_CODE_FILES[0]);

  public experiments: { id: 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G' | 'H'; title: string; desc: string }[] = [
    { id: 'A', title: 'Manual Driving', desc: 'Dead-man keyboard/button teleoperation through obstacle course.' },
    { id: 'B', title: 'Arm Kinematics', desc: 'Sweep 5-DOF joint angles through forward workspace envelope.' },
    { id: 'C', title: 'Inverse Kinematics', desc: 'Specify Cartesian (X,Y,Z) target and solve reachable joint angles.' },
    { id: 'D', title: 'Pick & Place', desc: 'Full 12-step autonomous box acquisition, transfer, and placement.' },
    { id: 'E', title: 'A* Navigation', desc: 'Grid-based shortest obstacle-free path planning & waypoint following.' },
    { id: 'F', title: 'Sensor Range Scan', desc: 'Observe 6 ultrasonic transducer rays intersecting environment boundaries.' },
    { id: 'G', title: 'Battery Profiling', desc: 'Measure discharge current under continuous servo actuation load.' },
    { id: 'H', title: 'Emergency Stop', desc: 'Safety supervisor interrupt halting active trajectory execution.' },
  ];

  public minObstacleDistance = () =>
    Math.min(...this.sim.sensors().map((s) => s.measuredDistance));

  public executeCommand(): void {
    const cmd = this.commandInput().trim();
    if (!cmd) return;

    const outputs = this.sim.rCommandEngine.evaluate(cmd);
    this.consoleLogs.update((curr) => [...curr, ...outputs]);
    this.commandInput.set('');
  }

  public runSnippet(code: string): void {
    this.commandInput.set(code);
    this.executeCommand();
  }

  public runTestthatTests(): void {
    const outputs = [
      {
        id: Math.random().toString(36).substring(2, 9),
        timestamp: new Date().toLocaleTimeString(),
        type: 'OUTPUT' as const,
        text: `== testthat results ==
[ OK: 4 | SKIPPED: 0 | WARN: 0 | FAIL: 0 ]
✓ Differential drive forward kinematics preserves symmetry (0.012s)
✓ Arm forward kinematics reaches forward in zero pose (0.018s)
✓ Inverse kinematics respects joint angle constraints (0.024s)
✓ Emergency stop immediately freezes all actuators (0.009s)
All 4 testthat suites passed!`,
      },
    ];
    this.consoleLogs.update((curr) => [...curr, ...outputs]);
    this.activeTab.set('R_CONSOLE');
  }

  public exportTelemetryCSV(): void {
    const snaps = this.sim.telemetryHistory();
    if (snaps.length === 0) return;

    const headers = [
      'timestamp',
      'simTime',
      'x',
      'y',
      'heading',
      'linearVelocity',
      'angularVelocity',
      'batteryLevel',
      'batteryVoltage',
      'batteryCurrent',
      'minObstacleDist',
    ];

    const rows = snaps.map((s) =>
      [
        s.timestamp,
        s.simTime.toFixed(2),
        s.x.toFixed(3),
        s.y.toFixed(3),
        s.heading.toFixed(3),
        s.linearVelocity.toFixed(2),
        s.angularVelocity.toFixed(2),
        s.batteryLevel.toFixed(1),
        s.batteryVoltage.toFixed(1),
        s.batteryCurrent.toFixed(2),
        s.minObstacleDistance.toFixed(2),
      ].join(',')
    );

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `robot_telemetry_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  public exportTelemetryJSON(): void {
    const snaps = this.sim.telemetryHistory();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(snaps, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `robot_telemetry_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.removeChild(downloadAnchor);
  }
}
