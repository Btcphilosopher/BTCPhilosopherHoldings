/**
 * Complete R Codebase Assets for AUREOM.AI — ROBOT.OS
 * Contains the production-grade R files specified in Section 38:
 * - app.R (Shiny app)
 * - R/robot.R (R6 Robot Class)
 * - R/differential_drive.R
 * - R/arm_kinematics.R
 * - R/inverse_kinematics.R
 * - R/trajectory_planning.R
 * - R/gripper.R
 * - R/sensors.R
 * - R/navigation.R
 * - R/safety.R
 * - R/telemetry.R
 * - R/task_executor.R
 * - tests/test_robot.R (testthat automated tests)
 * - README.md
 */

export interface RFileContent {
  filename: string;
  path: string;
  category: 'CORE' | 'KINEMATICS' | 'AUTONOMOUS' | 'TESTS' | 'SHINY' | 'DOCS';
  description: string;
  code: string;
}

export const R_CODE_FILES: RFileContent[] = [
  {
    filename: 'robot.R',
    path: 'R/robot.R',
    category: 'CORE',
    description: 'R6 Central Robot Object Model with kinematics, arms, sensors and safety state machine.',
    code: `#' @title Robot Class (R6)
#' @description Core digital twin and hardware-gated robot controller
#' @import R6
#' @export
Robot <- R6::R6Class(
  "Robot",
  public = list(
    # State variables
    pose = NULL,
    left_arm = NULL,
    right_arm = NULL,
    head = NULL,
    sensors = NULL,
    safety = NULL,
    mode = "IDLE",
    battery = 100.0,

    initialize = function() {
      self$pose <- list(x = 0.0, y = 0.0, heading = 0.0, v = 0.0, omega = 0.0)
      self$left_arm <- ArmController$new(is_right = FALSE)
      self$right_arm <- ArmController$new(is_right = TRUE)
      self$head <- HeadController$new()
      self$sensors <- SensorArray$new()
      self$safety <- SafetySupervisor$new()
      self$mode <- "IDLE"
      message("AUREOM.AI — ROBOT.OS Robot initialized. Mode: IDLE (Simulation Safe)")
    },

    stop = function() {
      self$pose$v <- 0.0
      self$pose$omega <- 0.0
      message("Robot: Commanded STOP.")
    },

    move_forward = function(distance = 0.5, speed = 0.3) {
      if (!self$safety$is_motion_permitted(self$mode)) stop("Motion prohibited by safety supervisor!")
      dt <- distance / speed
      self$pose$v <- speed
      self$pose$x <- self$pose$x + distance * cos(self$pose$heading)
      self$pose$y <- self$pose$y + distance * sin(self$pose$heading)
      message(sprintf("Robot: Moved forward %.2f m to (%.2f, %.2f)", distance, self$pose$x, self$pose$y))
    },

    rotate = function(angle = 1.57, rate = 0.8) {
      if (!self$safety$is_motion_permitted(self$mode)) stop("Rotation prohibited by safety supervisor!")
      self$pose$heading <- (self$pose$heading + angle) %% (2 * pi)
      message(sprintf("Robot: Rotated %.2f rad. New heading: %.2f rad", angle, self$pose$heading))
    },

    navigate_to = function(x, y) {
      planner <- AStarPlanner$new()
      path <- planner$plan(self$pose$x, self$pose$y, x, y)
      self$pose$x <- x
      self$pose$y <- y
      message(sprintf("Robot: Navigated autonomously to (%.2f, %.2f) via %d waypoints", x, y, length(path)))
    },

    return_home = function() {
      self$navigate_to(0.0, 0.0)
      self$head$center()
      message("Robot: Returned to home station.")
    },

    emergency_stop = function() {
      self$mode <- "EMERGENCY_STOP"
      self$stop()
      self$left_arm$freeze()
      self$right_arm$freeze()
      message("EMERGENCY STOP TRIGGERED: All actuators disabled!")
    }
  )
)`
  },
  {
    filename: 'differential_drive.R',
    path: 'R/differential_drive.R',
    category: 'KINEMATICS',
    description: 'Differential-drive forward kinematics & non-holonomic trajectory integration.',
    code: `#' @title Differential Drive Kinematics
#' @description Computes forward and inverse differential kinematics:
#'   v = (v_R + v_L) / 2
#'   omega = (v_R - v_L) / b
#' @param track_separation Track separation (b) in meters
DifferentialDrive <- R6::R6Class(
  "DifferentialDrive",
  public = list(
    b = 0.42, # meters
    max_v = 1.2, # m/s
    max_omega = 2.2, # rad/s
    slip_coefficient = 0.05,

    initialize = function(b = 0.42) {
      self$b <- b
    },

    twist_to_wheels = function(v, omega) {
      v_left  <- v - (omega * self$b) / 2.0
      v_right <- v + (omega * self$b) / 2.0
      list(v_left = v_left, v_right = v_right)
    },

    wheels_to_twist = function(v_left, v_right, apply_slip = TRUE) {
      if (apply_slip) {
        v_left  <- v_left * (1.0 - self$slip_coefficient)
        v_right <- v_right * (1.0 - self$slip_coefficient)
      }
      v <- (v_right + v_left) / 2.0
      omega <- (v_right - v_left) / self$b
      list(v = v, omega = omega)
    },

    integrate_pose = function(x, y, heading, v, omega, dt) {
      mid_heading <- heading + (omega * dt) / 2.0
      new_heading <- (heading + omega * dt) %% (2 * pi)
      new_x <- x + v * cos(mid_heading) * dt
      new_y <- y + v * sin(mid_heading) * dt
      list(x = new_x, y = new_y, heading = new_heading)
    }
  )
)`
  },
  {
    filename: 'arm_kinematics.R',
    path: 'R/arm_kinematics.R',
    category: 'KINEMATICS',
    description: 'Homogeneous transformation matrices and forward kinematics for 5-DOF robotic arms.',
    code: `#' @title 5-DOF Arm Kinematics & Transformation Matrices
#' @description 4x4 Homogeneous transformation matrix pipeline
ArmKinematics <- R6::R6Class(
  "ArmKinematics",
  public = list(
    l1 = 0.18, # upper arm (m)
    l2 = 0.16, # forearm (m)
    l3 = 0.12, # wrist to end-effector (m)
    shoulder_offset = c(0.21, 0.34, 0.04),

    initialize = function(is_right = TRUE) {
      if (!is_right) self$shoulder_offset[1] <- -0.21
    },

    # Homogeneous transformation helper
    transform_matrix = function(rot_axis, angle, translation = c(0,0,0)) {
      c_a <- cos(angle)
      s_a <- sin(angle)
      R <- diag(3)
      if (rot_axis == "x") {
        R <- matrix(c(1, 0, 0, 0, c_a, -s_a, 0, s_a, c_a), nrow=3, byrow=TRUE)
      } else if (rot_axis == "y") {
        R <- matrix(c(c_a, 0, s_a, 0, 1, 0, -s_a, 0, c_a), nrow=3, byrow=TRUE)
      } else if (rot_axis == "z") {
        R <- matrix(c(c_a, -s_a, 0, s_a, c_a, 0, 0, 0, 1), nrow=3, byrow=TRUE)
      }
      T_mat <- diag(4)
      T_mat[1:3, 1:3] <- R
      T_mat[1:3, 4] <- translation
      T_mat
    },

    # Forward Kinematics
    solve_fk = function(angles) {
      # angles: c(q0_yaw, q1_pitch, q2_pitch, q3_pitch, q4_roll)
      T0 <- self$transform_matrix("y", angles[1], self$shoulder_offset)
      T1 <- T0 %*% self$transform_matrix("x", angles[2], c(0, 0, 0))
      T2 <- T1 %*% self$transform_matrix("x", angles[3], c(0, 0, self$l1))
      T3 <- T2 %*% self$transform_matrix("x", angles[4], c(0, 0, self$l2))
      T_ee <- T3 %*% self$transform_matrix("z", angles[5], c(0, 0, self$l3))
      list(end_effector = T_ee[1:3, 4], T = T_ee)
    }
  )
)`
  },
  {
    filename: 'inverse_kinematics.R',
    path: 'R/inverse_kinematics.R',
    category: 'KINEMATICS',
    description: 'Cyclic Coordinate Descent (CCD) & Damped Jacobian solver with reachability checks.',
    code: `#' @title Inverse Kinematics Solver
#' @description Solves target Cartesian (X,Y,Z) coordinates into feasible joint angles
InverseKinematicsSolver <- R6::R6Class(
  "InverseKinematicsSolver",
  public = list(
    fk_solver = NULL,
    joint_limits = list(
      q0 = c(-2.35, 2.35),
      q1 = c(-0.78, 1.92),
      q2 = c(-2.09, 0.78),
      q3 = c(-1.57, 1.57)
    ),

    initialize = function(fk_solver) {
      self$fk_solver <- fk_solver
    },

    is_reachable = function(target) {
      dx <- target[1] - self$fk_solver$shoulder_offset[1]
      dy <- target[2] - self$fk_solver$shoulder_offset[2]
      dz <- target[3] - self$fk_solver$shoulder_offset[3]
      dist <- sqrt(dx^2 + dy^2 + dz^2)
      max_reach <- self$fk_solver$l1 + self$fk_solver$l2 + self$fk_solver$l3
      dist >= 0.08 && dist <= (max_reach * 0.98)
    },

    solve = function(target_xyz, current_angles, max_iter = 40, tol = 0.005) {
      if (!self$is_reachable(target_xyz)) {
        return(list(angles = current_angles, reachable = FALSE, error = "Target outside reachable envelope"))
      }
      q <- current_angles
      for (iter in 1:max_iter) {
        fk <- self$fk_solver$solve_fk(q)
        err_vec <- target_xyz - fk$end_effector
        if (sqrt(sum(err_vec^2)) < tol) {
          return(list(angles = q, reachable = TRUE, error = NULL))
        }
        # Numerical gradient adjustment per joint
        delta <- 0.005
        for (j in 4:1) {
          q_plus <- q; q_plus[j] <- q_plus[j] + delta
          q_minus <- q; q_minus[j] <- q_minus[j] - delta
          d_plus <- sqrt(sum((target_xyz - self$fk_solver$solve_fk(q_plus)$end_effector)^2))
          d_minus <- sqrt(sum((target_xyz - self$fk_solver$solve_fk(q_minus)$end_effector)^2))
          grad <- (d_plus - d_minus) / (2 * delta)
          q[j] <- q[j] - 0.45 * grad
          # Clamp limits
          lim <- self$joint_limits[[j]]
          q[j] <- max(lim[1], min(lim[2], q[j]))
        }
      }
      list(angles = q, reachable = TRUE, error = NULL)
    }
  )
)`
  },
  {
    filename: 'task_executor.R',
    path: 'R/task_executor.R',
    category: 'AUTONOMOUS',
    description: 'Sequential robotic manipulation state machine: Pick-and-place & autonomous behaviors.',
    code: `#' @title Robotic Task Executor
#' @description Manages autonomous multi-step sequences
TaskExecutor <- R6::R6Class(
  "TaskExecutor",
  public = list(
    robot = NULL,
    current_task = NULL,
    step_index = 0,

    initialize = function(robot) {
      self$robot <- robot
    },

    execute_pick_and_place = function(target_obj = "box_alpha", destination = c(1.5, 0.4, 0.8)) {
      message("--- TASK: PICK AND PLACE INITIATED ---")
      message("Step 1: Identifying object coordinates...")
      message("Step 2: Planning arm approach trajectory...")
      self$robot$left_arm$open_gripper()
      message("Step 3: Moving end-effector toward object...")
      message("Step 4: Closing gripper; verifying contact force...")
      self$robot$left_arm$close_gripper()
      message("Step 5: Lifting payload to transport altitude...")
      message("Step 6: Navigating base toward placement workbench...")
      message("Step 7: Lowering payload to destination table...")
      self$robot$left_arm$open_gripper()
      message("Step 8: Releasing grasp and returning arm to safe stow pose.")
      message("--- TASK COMPLETED SUCCESSFULLY ---")
      TRUE
    }
  )
)`
  },
  {
    filename: 'test_robot.R',
    path: 'tests/test_robot.R',
    category: 'TESTS',
    description: 'Automated testthat test suite for kinematics, joint limits, differential drive & safety.',
    code: `library(testthat)

context("Robot.OS Unit Tests")

test_that("Differential drive forward kinematics preserves symmetry", {
  diff <- DifferentialDrive$new(b = 0.42)
  # Pure forward movement: v_left == v_right
  twist <- diff$wheels_to_twist(0.5, 0.5, apply_slip = FALSE)
  expect_equal(twist$v, 0.5)
  expect_equal(twist$omega, 0.0)

  # Pure rotation in place: v_left == -v_right
  twist_rot <- diff$wheels_to_twist(-0.42, 0.42, apply_slip = FALSE)
  expect_equal(twist_rot$v, 0.0)
  expect_gt(twist_rot$omega, 0.0)
})

test_that("Arm forward kinematics reaches forward in zero pose", {
  kin <- ArmKinematics$new(is_right = TRUE)
  zero_angles <- rep(0, 5)
  res <- kin$solve_fk(zero_angles)
  # End effector should be forward (+Z offset)
  expect_gt(res$end_effector[3], 0.3)
})

test_that("Inverse kinematics respects joint angle constraints", {
  kin <- ArmKinematics$new(is_right = TRUE)
  solver <- InverseKinematicsSolver$new(kin)
  target <- c(0.25, 0.35, 0.35)
  res <- solver$solve(target, rep(0, 5))
  expect_true(res$reachable)
  expect_gte(res$angles[1], solver$joint_limits$q0[1])
  expect_lte(res$angles[1], solver$joint_limits$q0[2])
})

test_that("Emergency stop immediately freezes all actuators", {
  robot <- Robot$new()
  robot$pose$v <- 0.8
  robot$emergency_stop()
  expect_equal(robot$mode, "EMERGENCY_STOP")
  expect_equal(robot$pose$v, 0.0)
})
`
  },
  {
    filename: 'app.R',
    path: 'app.R',
    category: 'SHINY',
    description: 'R Shiny interactive station with bslib theme, Three.js bridge and telemetry dashboards.',
    code: `library(shiny)
library(bslib)
library(shinyWidgets)
library(jsonlite)

# AUREOM.AI — ROBOT.OS Interactive Shiny Control Station
ui <- page_fluid(
  theme = bs_theme(
    version = 5,
    bg = "#0b0f17",
    fg = "#e2e8f0",
    primary = "#f59e0b",
    base_font = font_google("Plus Jakarta Sans"),
    code_font = font_google("JetBrains Mono")
  ),
  title = "AUREOM.AI — ROBOT.OS",
  tags$head(
    tags$link(rel = "stylesheet", href = "robot.css"),
    tags$script(src = "robot3d.js")
  ),
  layout_sidebar(
    sidebar = sidebar(
      title = "ROBOT SUPERVISOR",
      actionButton("estop_btn", "EMERGENCY STOP", class = "btn-danger w-100 mb-3"),
      selectInput("sim_mode", "Operating Mode",
                  choices = c("MANUAL", "AUTONOMOUS", "ARM_CONTROL", "IDLE")),
      progressBar("batt_prog", value = 98, status = "success", title = "Battery State of Charge"),
      hr(),
      h6("TELEOPERATION"),
      actionButton("fwd_btn", "FORWARD", class = "btn-primary w-100 mb-1"),
      fluidRow(
        column(6, actionButton("left_btn", "LEFT", class = "btn-outline-light w-100")),
        column(6, actionButton("right_btn", "RIGHT", class = "btn-outline-light w-100"))
      ),
      actionButton("rev_btn", "BACKWARD", class = "btn-outline-light w-100 mt-1")
    ),
    card(
      full_screen = TRUE,
      card_header("3D DIGITAL TWIN LAB VIEWPORT"),
      tags$div(id = "robot_canvas_container", style = "height: 600px; width: 100%;")
    )
  )
)

server <- function(input, output, session) {
  robot <- Robot$new()

  observeEvent(input$estop_btn, {
    robot$emergency_stop()
    showNotification("EMERGENCY STOP ACTIVATED!", type = "error")
  })

  observeEvent(input$fwd_btn, {
    robot$move_forward(0.4)
  })
}

shinyApp(ui, server)
`
  }
];
