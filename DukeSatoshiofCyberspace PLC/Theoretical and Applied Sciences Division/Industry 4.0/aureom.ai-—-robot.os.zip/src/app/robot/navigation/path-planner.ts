/**
 * Autonomous Navigation & A* Path Planner
 * Implements occupancy grid mapping, obstacle inflation (safety margin),
 * A* shortest path search, and waypoint follower.
 */

import { PathWaypoint, EnvironmentObject } from '../models/robot.types';

export interface GridCoord {
  gx: number;
  gy: number;
}

export class AStarPathPlanner {
  private gridResolution = 0.2; // 20cm cells
  private worldMinX = -6.0;
  private worldMaxX = 6.0;
  private worldMinY = -6.0;
  private worldMaxY = 6.0;
  private gridWidth = 0;
  private gridHeight = 0;
  private occupancyGrid: Uint8Array; // 0 = free, 1 = obstacle, 2 = inflated safety margin

  constructor() {
    this.gridWidth = Math.round((this.worldMaxX - this.worldMinX) / this.gridResolution);
    this.gridHeight = Math.round((this.worldMaxY - this.worldMinY) / this.gridResolution);
    this.occupancyGrid = new Uint8Array(this.gridWidth * this.gridHeight);
  }

  public worldToGrid(wx: number, wy: number): GridCoord {
    const gx = Math.floor((wx - this.worldMinX) / this.gridResolution);
    const gy = Math.floor((wy - this.worldMinY) / this.gridResolution);
    return {
      gx: Math.max(0, Math.min(this.gridWidth - 1, gx)),
      gy: Math.max(0, Math.min(this.gridHeight - 1, gy)),
    };
  }

  public gridToWorld(gx: number, gy: number): { x: number; y: number } {
    return {
      x: this.worldMinX + (gx + 0.5) * this.gridResolution,
      y: this.worldMinY + (gy + 0.5) * this.gridResolution,
    };
  }

  public updateObstacles(obstacles: EnvironmentObject[], safetyInflationRadius = 0.45): void {
    this.occupancyGrid.fill(0);

    for (const obj of obstacles) {
      if (obj.isPickable) continue; // pickable small boxes are not path blocking

      // Calculate bounding box in grid
      const halfW = (obj.size.x / 2) + safetyInflationRadius;
      const halfD = (obj.size.z / 2) + safetyInflationRadius;

      const minX = obj.position.x - halfW;
      const maxX = obj.position.x + halfW;
      const minY = obj.position.z - halfD;
      const maxY = obj.position.z + halfD;

      const gStart = this.worldToGrid(minX, minY);
      const gEnd = this.worldToGrid(maxX, maxY);

      for (let gy = gStart.gy; gy <= gEnd.gy; gy++) {
        for (let gx = gStart.gx; gx <= gEnd.gx; gx++) {
          const index = gy * this.gridWidth + gx;
          this.occupancyGrid[index] = 1;
        }
      }
    }
  }

  /**
   * Plan A* path from (startX, startY) to (goalX, goalY).
   * Returns list of world-coordinate waypoints.
   */
  public planPath(startX: number, startY: number, goalX: number, goalY: number): PathWaypoint[] {
    const startGrid = this.worldToGrid(startX, startY);
    const goalGrid = this.worldToGrid(goalX, goalY);

    if (startGrid.gx === goalGrid.gx && startGrid.gy === goalGrid.gy) {
      return [{ x: goalX, y: goalY, reached: false }];
    }

    const openSet: number[] = [];
    const cameFrom = new Map<number, number>();
    const gScore = new Map<number, number>();
    const fScore = new Map<number, number>();

    const startIndex = startGrid.gy * this.gridWidth + startGrid.gx;
    const goalIndex = goalGrid.gy * this.gridWidth + goalGrid.gx;

    openSet.push(startIndex);
    gScore.set(startIndex, 0);
    fScore.set(startIndex, this.heuristic(startGrid, goalGrid));

    const closedSet = new Set<number>();

    while (openSet.length > 0) {
      // Find node with lowest fScore
      let lowestIdx = 0;
      let lowestF = fScore.get(openSet[0]) ?? Infinity;
      for (let i = 1; i < openSet.length; i++) {
        const score = fScore.get(openSet[i]) ?? Infinity;
        if (score < lowestF) {
          lowestF = score;
          lowestIdx = i;
        }
      }

      const current = openSet.splice(lowestIdx, 1)[0];
      if (current === goalIndex) {
        return this.reconstructPath(cameFrom, current, goalX, goalY);
      }

      closedSet.add(current);

      const curGx = current % this.gridWidth;
      const curGy = Math.floor(current / this.gridWidth);

      // 8-connected neighbors
      const neighbors = [
        { dx: 1, dy: 0, cost: 1.0 },
        { dx: -1, dy: 0, cost: 1.0 },
        { dx: 0, dy: 1, cost: 1.0 },
        { dx: 0, dy: -1, cost: 1.0 },
        { dx: 1, dy: 1, cost: 1.414 },
        { dx: -1, dy: 1, cost: 1.414 },
        { dx: 1, dy: -1, cost: 1.414 },
        { dx: -1, dy: -1, cost: 1.414 },
      ];

      for (const n of neighbors) {
        const ngx = curGx + n.dx;
        const ngy = curGy + n.dy;

        if (ngx < 0 || ngx >= this.gridWidth || ngy < 0 || ngy >= this.gridHeight) continue;

        const neighborIndex = ngy * this.gridWidth + ngx;
        if (closedSet.has(neighborIndex)) continue;
        if (this.occupancyGrid[neighborIndex] === 1) continue; // blocked by obstacle

        const tentativeG = (gScore.get(current) ?? Infinity) + n.cost;

        if (tentativeG < (gScore.get(neighborIndex) ?? Infinity)) {
          cameFrom.set(neighborIndex, current);
          gScore.set(neighborIndex, tentativeG);
          const h = this.heuristic({ gx: ngx, gy: ngy }, goalGrid);
          fScore.set(neighborIndex, tentativeG + h);

          if (!openSet.includes(neighborIndex)) {
            openSet.push(neighborIndex);
          }
        }
      }
    }

    // Direct fallback if no direct path found
    return [{ x: goalX, y: goalY, reached: false }];
  }

  private heuristic(a: GridCoord, b: GridCoord): number {
    const dx = Math.abs(a.gx - b.gx);
    const dy = Math.abs(a.gy - b.gy);
    return Math.sqrt(dx * dx + dy * dy);
  }

  private reconstructPath(
    cameFrom: Map<number, number>,
    current: number,
    finalX: number,
    finalY: number
  ): PathWaypoint[] {
    const gridPath: number[] = [current];
    let curr = current;
    while (cameFrom.has(curr)) {
      curr = cameFrom.get(curr)!;
      gridPath.unshift(curr);
    }

    // Downsample / simplify path to key waypoints every 3 cells
    const waypoints: PathWaypoint[] = [];
    const step = Math.max(1, Math.floor(gridPath.length / 10));

    for (let i = 0; i < gridPath.length; i += step) {
      const idx = gridPath[i];
      const gx = idx % this.gridWidth;
      const gy = Math.floor(idx / this.gridWidth);
      const w = this.gridToWorld(gx, gy);
      waypoints.push({ x: w.x, y: w.y, reached: false });
    }

    // Ensure final waypoint is exactly the goal
    waypoints.push({ x: finalX, y: finalY, reached: false });
    return waypoints;
  }
}
