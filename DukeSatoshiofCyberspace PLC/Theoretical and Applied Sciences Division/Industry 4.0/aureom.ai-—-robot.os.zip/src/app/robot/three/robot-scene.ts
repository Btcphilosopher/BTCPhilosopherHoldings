/**
 * AUREOM.AI — ROBOT.OS
 * Complete 3D Digital Twin Simulation Engine (Three.js)
 * Implements procedural WALL-E-inspired exploration robot model,
 * multi-DOF articulated arms, movable binocular head, continuous tank treads,
 * sensor rays, laboratory environment, grabbable objects, and multi-camera system.
 */

import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  CameraViewMode,
  EnvironmentObject,
  HeadState,
  RobotPose,
  UltrasonicSensor,
  Vector3D,
} from '../models/robot.types';

export class Robot3DScene {
  private container: HTMLElement;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private controls!: OrbitControls;
  private animFrameId = 0;
  private isDestroyed = false;
  private isSoftwareGl = false;

  // Visual settings & toggles
  public showCoordinateAxes = true;
  public showSensorRays = true;
  public showCollisionBounds = false;
  public showPathTrail = true;
  public activeCameraMode: CameraViewMode = 'ORBIT';

  // Robot 3D Mesh Hierarchy
  private robotRootGroup = new THREE.Group();
  private chassisMeshGroup = new THREE.Group();
  private leftTrackMesh = new THREE.Group();
  private rightTrackMesh = new THREE.Group();
  private neckBase = new THREE.Group();
  private neckUpper = new THREE.Group();
  private headGroup = new THREE.Group();
  private leftEyeMesh = new THREE.Group();
  private rightEyeMesh = new THREE.Group();
  private leftEyelid = new THREE.Group();
  private rightEyelid = new THREE.Group();

  // Left Arm Joint Groups
  private leftArmGroup = new THREE.Group();
  private leftShoulderPan = new THREE.Group();
  private leftShoulderPitch = new THREE.Group();
  private leftElbow = new THREE.Group();
  private leftWristPitch = new THREE.Group();
  private leftWristRoll = new THREE.Group();
  private leftGripperFingerA!: THREE.Mesh;
  private leftGripperFingerB!: THREE.Mesh;

  // Right Arm Joint Groups
  private rightArmGroup = new THREE.Group();
  private rightShoulderPan = new THREE.Group();
  private rightShoulderPitch = new THREE.Group();
  private rightElbow = new THREE.Group();
  private rightWristPitch = new THREE.Group();
  private rightWristRoll = new THREE.Group();
  private rightGripperFingerA!: THREE.Mesh;
  private rightGripperFingerB!: THREE.Mesh;

  // Coordinate axes & helpers
  private axesHelper!: THREE.AxesHelper;
  private leftGripperAxes!: THREE.AxesHelper;
  private rightGripperAxes!: THREE.AxesHelper;
  private sensorRayLinesGroup = new THREE.Group();
  private pathLineMesh!: THREE.Line;
  private collisionBoxesGroup = new THREE.Group();

  // Environment meshes
  private envMeshesMap = new Map<string, THREE.Object3D>();
  private shadowPlane!: THREE.Mesh;

  // Materials Cache for reuse & disposal
  private materials: THREE.Material[] = [];
  private geometries: THREE.BufferGeometry[] = [];

  constructor(container: HTMLElement) {
    this.container = container;
    this.initScene();
  }

  private initScene(): void {
    // Detect software WebGL
    this.isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0e17);
    this.scene.fog = new THREE.FogExp2(0x0a0e17, 0.035);

    // Camera
    const aspect = this.container.clientWidth / (this.container.clientHeight || 1);
    this.camera = new THREE.PerspectiveCamera(48, aspect, 0.1, 100);
    this.camera.position.set(2.8, 2.2, 3.2);

    // Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.container.appendChild(this.renderer.domElement);

    // Orbit Controls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = !this.isSoftwareGl;
    this.controls.dampingFactor = 0.05;
    this.controls.maxPolarAngle = Math.PI / 2 - 0.03; // don't dip below floor
    this.controls.minDistance = 0.5;
    this.controls.maxDistance = 25.0;
    this.controls.target.set(0, 0.35, 0);

    // Studio Environment Reflections
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Lighting
    this.setupLighting();

    // Laboratory Floor & Grid
    this.setupLabFloor();

    // Assemble Procedural Digital Twin Robot
    this.assembleRobotModel();

    // Setup Sensor Rays & Helpers
    this.setupVisualHelpers();

    // Animation Loop
    this.renderLoop();

    // Resize Observer
    window.addEventListener('resize', this.onWindowResize);
  }

  private setupLighting(): void {
    // Ambient / Hemisphere Fill
    const hemiLight = new THREE.HemisphereLight(0xdce7f5, 0x1e293b, 1.2);
    hemiLight.position.set(0, 20, 0);
    this.scene.add(hemiLight);

    // Warm Key Light
    const keyLight = new THREE.DirectionalLight(0xfff5e6, 2.2);
    keyLight.position.set(4, 7, 5);
    keyLight.castShadow = !this.isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.camera.near = 0.5;
      keyLight.shadow.camera.far = 20;
      keyLight.shadow.camera.left = -4;
      keyLight.shadow.camera.right = 4;
      keyLight.shadow.camera.top = 4;
      keyLight.shadow.camera.bottom = -4;
      keyLight.shadow.bias = -0.0004;
    }
    this.scene.add(keyLight);

    // Cool Rim Light
    const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.4);
    rimLight.position.set(-5, 4, -5);
    this.scene.add(rimLight);
  }

  private setupLabFloor(): void {
    // Ground plane
    const floorGeo = new THREE.PlaneGeometry(30, 30);
    this.geometries.push(floorGeo);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x111827,
      roughness: 0.85,
      metalness: 0.2,
    });
    this.materials.push(floorMat);

    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = !this.isSoftwareGl;
    floor.position.y = -0.001;
    this.scene.add(floor);

    // Primary Metric Grid
    const gridMajor = new THREE.GridHelper(30, 30, 0x38bdf8, 0x1e293b);
    gridMajor.position.y = 0.001;
    this.scene.add(gridMajor);

    // Fine coordinate grid
    const gridMinor = new THREE.GridHelper(30, 150, 0x0f172a, 0x0f172a);
    gridMinor.position.y = 0.0005;
    this.scene.add(gridMinor);

    // Soft Radial Contact Shadow beneath robot
    const shadowGeo = new THREE.PlaneGeometry(0.85, 0.85);
    this.geometries.push(shadowGeo);

    // Procedural radial alpha canvas
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext('2d')!;
    const grad = ctx.createRadialGradient(64, 64, 10, 64, 64, 60);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0.75)');
    grad.addColorStop(0.6, 'rgba(0, 0, 0, 0.3)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 128, 128);

    const shadowTex = new THREE.CanvasTexture(canvas);
    shadowTex.colorSpace = THREE.SRGBColorSpace;
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
    });
    this.materials.push(shadowMat);

    this.shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
    this.shadowPlane.rotation.x = -Math.PI / 2;
    this.shadowPlane.position.y = 0.002;
    this.scene.add(this.shadowPlane);
  }

  /**
   * Builds the procedural 3D model of our compact exploration robot.
   * Original friendly exploration robot inspired by classic field robots.
   */
  private assembleRobotModel(): void {
    // Standard Materials
    const chassisMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b, // Warm industrial yellow/amber
      roughness: 0.35,
      metalness: 0.65,
    });
    const darkMetalMat = new THREE.MeshStandardMaterial({
      color: 0x27272a, // Slate/charcoal industrial steel
      roughness: 0.45,
      metalness: 0.85,
    });
    const trackTreadMat = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      roughness: 0.9,
      metalness: 0.1,
    });
    const brassTrimMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      roughness: 0.3,
      metalness: 0.9,
    });
    const solarGlassMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7, // Solar photovoltaic sheen
      roughness: 0.1,
      metalness: 0.95,
    });
    const eyeLensMat = new THREE.MeshPhysicalMaterial({
      color: 0x0f172a,
      roughness: 0.05,
      metalness: 0.9,
      clearcoat: 1.0,
      clearcoatRoughness: 0.05,
    });
    const eyeGlowMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8, // Expressive cyan LED pupil
    });
    const sensorCopperMat = new THREE.MeshStandardMaterial({
      color: 0xb45309,
      roughness: 0.3,
      metalness: 0.8,
    });

    this.materials.push(
      chassisMat,
      darkMetalMat,
      trackTreadMat,
      brassTrimMat,
      solarGlassMat,
      eyeLensMat,
      eyeGlowMat,
      sensorCopperMat
    );

    // 1. Central Chassis Body
    // Compact proportions: 0.36m width, 0.28m height, 0.40m length
    const chassisGeo = new THREE.BoxGeometry(0.36, 0.28, 0.40);
    this.geometries.push(chassisGeo);
    const chassisMesh = new THREE.Mesh(chassisGeo, chassisMat);
    chassisMesh.castShadow = !this.isSoftwareGl;
    chassisMesh.receiveShadow = !this.isSoftwareGl;
    chassisMesh.position.y = 0.26; // elevated above ground for tracks
    this.chassisMeshGroup.add(chassisMesh);

    // Solar Panel on Top of Chassis
    const solarGeo = new THREE.BoxGeometry(0.30, 0.015, 0.32);
    this.geometries.push(solarGeo);
    const solarMesh = new THREE.Mesh(solarGeo, solarGlassMat);
    solarMesh.position.set(0, 0.405, 0.02);
    this.chassisMeshGroup.add(solarMesh);

    // Front Bumper / Compactor Hatch Plate
    const hatchGeo = new THREE.BoxGeometry(0.34, 0.22, 0.02);
    this.geometries.push(hatchGeo);
    const hatchMesh = new THREE.Mesh(hatchGeo, darkMetalMat);
    hatchMesh.position.set(0, 0.26, 0.205);
    this.chassisMeshGroup.add(hatchMesh);

    // Yellow/Black Hazard Stripes on Hatch
    const stripeGeo = new THREE.BoxGeometry(0.32, 0.035, 0.005);
    this.geometries.push(stripeGeo);
    const stripeMesh = new THREE.Mesh(stripeGeo, brassTrimMat);
    stripeMesh.position.set(0, 0.18, 0.218);
    this.chassisMeshGroup.add(stripeMesh);

    // LED Battery Charge Status Bar on Chest
    for (let i = 0; i < 5; i++) {
      const ledGeo = new THREE.BoxGeometry(0.025, 0.008, 0.004);
      this.geometries.push(ledGeo);
      const ledMat = new THREE.MeshBasicMaterial({ color: i < 4 ? 0x10b981 : 0xef4444 });
      this.materials.push(ledMat);
      const led = new THREE.Mesh(ledGeo, ledMat);
      led.position.set(-0.06 + i * 0.03, 0.34, 0.205);
      this.chassisMeshGroup.add(led);
    }

    // 2. Continuous Tank Treads (Left & Right)
    this.leftTrackMesh = this.createTrackAssembly(true, darkMetalMat, trackTreadMat);
    this.leftTrackMesh.position.set(-0.23, 0.16, 0);
    this.chassisMeshGroup.add(this.leftTrackMesh);

    this.rightTrackMesh = this.createTrackAssembly(false, darkMetalMat, trackTreadMat);
    this.rightTrackMesh.position.set(0.23, 0.16, 0);
    this.chassisMeshGroup.add(this.rightTrackMesh);

    // 3. Articulated Neck Mechanism
    this.neckBase.position.set(0, 0.40, -0.06); // top rear of chassis
    const neckBaseGeo = new THREE.CylinderGeometry(0.045, 0.055, 0.04, 16);
    this.geometries.push(neckBaseGeo);
    const neckBaseMesh = new THREE.Mesh(neckBaseGeo, darkMetalMat);
    this.neckBase.add(neckBaseMesh);

    // Neck lower arm
    const neckLowerGeo = new THREE.BoxGeometry(0.03, 0.16, 0.03);
    this.geometries.push(neckLowerGeo);
    const neckLowerMesh = new THREE.Mesh(neckLowerGeo, darkMetalMat);
    neckLowerMesh.position.set(0, 0.08, 0);
    neckLowerMesh.rotation.x = -0.2;
    this.neckBase.add(neckLowerMesh);

    // Upper neck hinge
    this.neckUpper.position.set(0, 0.16, -0.03);
    const neckUpperGeo = new THREE.BoxGeometry(0.028, 0.14, 0.028);
    this.geometries.push(neckUpperGeo);
    const neckUpperMesh = new THREE.Mesh(neckUpperGeo, darkMetalMat);
    neckUpperMesh.position.set(0, 0.07, 0);
    neckUpperMesh.rotation.x = 0.25;
    this.neckUpper.add(neckUpperMesh);
    this.neckBase.add(this.neckUpper);

    // 4. Movable Head Assembly (Binocular Eyes)
    this.headGroup.position.set(0, 0.14, 0.02);

    // Head bridge bracket
    const bridgeGeo = new THREE.BoxGeometry(0.22, 0.04, 0.06);
    this.geometries.push(bridgeGeo);
    const bridgeMesh = new THREE.Mesh(bridgeGeo, darkMetalMat);
    this.headGroup.add(bridgeMesh);

    // Left Binocular Eye
    this.leftEyeMesh = this.createBinocularEye(-0.08, chassisMat, eyeLensMat, eyeGlowMat, darkMetalMat);
    this.headGroup.add(this.leftEyeMesh);

    // Right Binocular Eye
    this.rightEyeMesh = this.createBinocularEye(0.08, chassisMat, eyeLensMat, eyeGlowMat, darkMetalMat);
    this.headGroup.add(this.rightEyeMesh);

    this.neckUpper.add(this.headGroup);
    this.chassisMeshGroup.add(this.neckBase);

    // 5. Left Robotic Arm (5-DOF)
    this.setupArmStructure(
      false,
      this.leftArmGroup,
      this.leftShoulderPan,
      this.leftShoulderPitch,
      this.leftElbow,
      this.leftWristPitch,
      this.leftWristRoll,
      chassisMat,
      darkMetalMat,
      brassTrimMat
    );
    this.leftArmGroup.position.set(-0.21, 0.32, 0.04);
    this.chassisMeshGroup.add(this.leftArmGroup);

    // 6. Right Robotic Arm (5-DOF)
    this.setupArmStructure(
      true,
      this.rightArmGroup,
      this.rightShoulderPan,
      this.rightShoulderPitch,
      this.rightElbow,
      this.rightWristPitch,
      this.rightWristRoll,
      chassisMat,
      darkMetalMat,
      brassTrimMat
    );
    this.rightArmGroup.position.set(0.21, 0.32, 0.04);
    this.chassisMeshGroup.add(this.rightArmGroup);

    // Add chassis to robot root
    this.robotRootGroup.add(this.chassisMeshGroup);
    this.scene.add(this.robotRootGroup);
  }

  private createTrackAssembly(
    isLeft: boolean,
    metalMat: THREE.Material,
    treadMat: THREE.Material
  ): THREE.Group {
    const group = new THREE.Group();

    // Triangular track frame
    const trackWidth = 0.08;
    const trackLength = 0.44;
    const trackHeight = 0.24;

    // Track belt extrusion / box
    const beltGeo = new THREE.BoxGeometry(trackWidth, trackHeight, trackLength);
    this.geometries.push(beltGeo);
    const belt = new THREE.Mesh(beltGeo, treadMat);
    belt.castShadow = !this.isSoftwareGl;
    group.add(belt);

    // Front drive sprocket
    const sprocketGeo = new THREE.CylinderGeometry(0.09, 0.09, trackWidth + 0.01, 16);
    this.geometries.push(sprocketGeo);
    const sprocketF = new THREE.Mesh(sprocketGeo, metalMat);
    sprocketF.rotation.z = Math.PI / 2;
    sprocketF.position.set(0, 0, 0.16);
    group.add(sprocketF);

    // Rear idler wheel
    const sprocketR = new THREE.Mesh(sprocketGeo, metalMat);
    sprocketR.rotation.z = Math.PI / 2;
    sprocketR.position.set(0, 0, -0.16);
    group.add(sprocketR);

    // Road wheels (3 bottom tensioners)
    const wheelGeo = new THREE.CylinderGeometry(0.065, 0.065, trackWidth + 0.005, 12);
    this.geometries.push(wheelGeo);
    for (let i = -1; i <= 1; i++) {
      const rw = new THREE.Mesh(wheelGeo, metalMat);
      rw.rotation.z = Math.PI / 2;
      rw.position.set(0, -0.04, i * 0.11);
      group.add(rw);
    }

    return group;
  }

  private createBinocularEye(
    xOffset: number,
    housingMat: THREE.Material,
    lensMat: THREE.Material,
    pupilMat: THREE.Material,
    darkMat: THREE.Material
  ): THREE.Group {
    const eyeGroup = new THREE.Group();
    eyeGroup.position.set(xOffset, 0.06, 0.08);

    // Teardrop / rounded tapered housing (Box + Cylinders)
    const housingGeo = new THREE.BoxGeometry(0.095, 0.095, 0.12);
    this.geometries.push(housingGeo);
    const housing = new THREE.Mesh(housingGeo, housingMat);
    housing.castShadow = !this.isSoftwareGl;
    eyeGroup.add(housing);

    // Lens Barrel Bezel
    const bezelGeo = new THREE.CylinderGeometry(0.042, 0.044, 0.03, 16);
    this.geometries.push(bezelGeo);
    const bezel = new THREE.Mesh(bezelGeo, darkMat);
    bezel.rotation.x = Math.PI / 2;
    bezel.position.set(0, 0, 0.07);
    eyeGroup.add(bezel);

    // Lens Glass
    const lensGeo = new THREE.SphereGeometry(0.038, 16, 16, 0, Math.PI * 2, 0, Math.PI / 2);
    this.geometries.push(lensGeo);
    const lens = new THREE.Mesh(lensGeo, lensMat);
    lens.rotation.x = Math.PI / 2;
    lens.position.set(0, 0, 0.075);
    eyeGroup.add(lens);

    // Glowing Pupil Dot inside lens
    const pupilGeo = new THREE.CircleGeometry(0.016, 16);
    this.geometries.push(pupilGeo);
    const pupil = new THREE.Mesh(pupilGeo, pupilMat);
    pupil.position.set(0, 0, 0.086);
    eyeGroup.add(pupil);

    // Mechanical Eyelid visor for expressive personality
    const lidGeo = new THREE.BoxGeometry(0.10, 0.02, 0.06);
    this.geometries.push(lidGeo);
    const eyelid = new THREE.Mesh(lidGeo, darkMat);
    eyelid.position.set(0, 0.048, 0.05);
    if (xOffset < 0) {
      this.leftEyelid.add(eyelid);
      eyeGroup.add(this.leftEyelid);
    } else {
      this.rightEyelid.add(eyelid);
      eyeGroup.add(this.rightEyelid);
    }

    return eyeGroup;
  }

  private setupArmStructure(
    isRight: boolean,
    armRoot: THREE.Group,
    shoulderPan: THREE.Group,
    shoulderPitch: THREE.Group,
    elbow: THREE.Group,
    wristPitch: THREE.Group,
    wristRoll: THREE.Group,
    chassisMat: THREE.Material,
    metalMat: THREE.Material,
    brassMat: THREE.Material
  ): void {
    // Shoulder Base Turret (Joint 0: Pan / Yaw)
    const baseMountGeo = new THREE.CylinderGeometry(0.032, 0.032, 0.03, 16);
    this.geometries.push(baseMountGeo);
    const baseMount = new THREE.Mesh(baseMountGeo, metalMat);
    baseMount.rotation.z = Math.PI / 2;
    armRoot.add(baseMount);

    armRoot.add(shoulderPan);

    // Shoulder Pitch Pivot (Joint 1: Elevation)
    const pitchPivGeo = new THREE.SphereGeometry(0.032, 16, 16);
    this.geometries.push(pitchPivGeo);
    const pitchPiv = new THREE.Mesh(pitchPivGeo, brassMat);
    shoulderPan.add(pitchPiv);

    shoulderPan.add(shoulderPitch);

    // Upper Arm Link (L1 = 0.18m)
    const upperArmGeo = new THREE.BoxGeometry(0.036, 0.036, 0.17);
    this.geometries.push(upperArmGeo);
    const upperArmMesh = new THREE.Mesh(upperArmGeo, chassisMat);
    upperArmMesh.castShadow = !this.isSoftwareGl;
    upperArmMesh.position.set(0, 0, 0.09);
    shoulderPitch.add(upperArmMesh);

    // Elbow Joint (Joint 2: Flexion)
    elbow.position.set(0, 0, 0.18);
    const elbowPivGeo = new THREE.CylinderGeometry(0.026, 0.026, 0.044, 16);
    this.geometries.push(elbowPivGeo);
    const elbowPiv = new THREE.Mesh(elbowPivGeo, metalMat);
    elbowPiv.rotation.z = Math.PI / 2;
    elbow.add(elbowPiv);
    shoulderPitch.add(elbow);

    // Forearm Link (L2 = 0.16m)
    const forearmGeo = new THREE.BoxGeometry(0.03, 0.03, 0.15);
    this.geometries.push(forearmGeo);
    const forearmMesh = new THREE.Mesh(forearmGeo, chassisMat);
    forearmMesh.castShadow = !this.isSoftwareGl;
    forearmMesh.position.set(0, 0, 0.08);
    elbow.add(forearmMesh);

    // Wrist Pitch Joint (Joint 3)
    wristPitch.position.set(0, 0, 0.16);
    const wristPitchPivGeo = new THREE.SphereGeometry(0.022, 12, 12);
    this.geometries.push(wristPitchPivGeo);
    const wristPitchPiv = new THREE.Mesh(wristPitchPivGeo, brassMat);
    wristPitch.add(wristPitchPiv);
    elbow.add(wristPitch);

    // Wrist Roll Joint (Joint 4)
    wristPitch.add(wristRoll);

    // Gripper Base & Articulated Fingers (Joint 5: Aperture)
    const gripperBaseGeo = new THREE.BoxGeometry(0.045, 0.025, 0.03);
    this.geometries.push(gripperBaseGeo);
    const gripperBase = new THREE.Mesh(gripperBaseGeo, metalMat);
    gripperBase.position.set(0, 0, 0.02);
    wristRoll.add(gripperBase);

    // Gripper Finger A & B
    const fingerGeo = new THREE.BoxGeometry(0.012, 0.018, 0.08);
    this.geometries.push(fingerGeo);
    const fingerMat = new THREE.MeshStandardMaterial({
      color: 0x3f3f46,
      roughness: 0.3,
      metalness: 0.8,
    });
    this.materials.push(fingerMat);

    const fingerA = new THREE.Mesh(fingerGeo, fingerMat);
    fingerA.position.set(-0.022, 0, 0.06);
    const fingerB = new THREE.Mesh(fingerGeo, fingerMat);
    fingerB.position.set(0.022, 0, 0.06);

    wristRoll.add(fingerA);
    wristRoll.add(fingerB);

    if (isRight) {
      this.rightGripperFingerA = fingerA;
      this.rightGripperFingerB = fingerB;
    } else {
      this.leftGripperFingerA = fingerA;
      this.leftGripperFingerB = fingerB;
    }
  }

  private setupVisualHelpers(): void {
    // World Coordinate Axes Helper
    this.axesHelper = new THREE.AxesHelper(1.2);
    this.axesHelper.position.set(0, 0.01, 0);
    this.scene.add(this.axesHelper);

    // Gripper End-Effector Coordinate Axes
    this.leftGripperAxes = new THREE.AxesHelper(0.12);
    this.leftWristRoll.add(this.leftGripperAxes);

    this.rightGripperAxes = new THREE.AxesHelper(0.12);
    this.rightWristRoll.add(this.rightGripperAxes);

    // Sensor Rays Group
    this.scene.add(this.sensorRayLinesGroup);

    // A* Path visualization ribbon
    const pathGeo = new THREE.BufferGeometry();
    const pathMat = new THREE.LineBasicMaterial({
      color: 0x10b981,
      linewidth: 3,
      transparent: true,
      opacity: 0.85,
    });
    this.materials.push(pathMat);
    this.pathLineMesh = new THREE.Line(pathGeo, pathMat);
    this.scene.add(this.pathLineMesh);

    // Collision Boundaries Group
    this.scene.add(this.collisionBoxesGroup);
  }

  /**
   * Update visual digital twin from simulation state.
   */
  public updateState(
    pose: RobotPose,
    leftArmAngles: number[],
    rightArmAngles: number[],
    leftGripperAperture: number,
    rightGripperAperture: number,
    headState: HeadState,
    sensors: UltrasonicSensor[],
    envObjects: EnvironmentObject[],
    pathWaypoints: { x: number; y: number }[]
  ): void {
    // 1. Robot Chassis Pose
    // Coordinate mapping: 2D plane (x, y) -> Three.js (x, y=ground, z=y)
    this.robotRootGroup.position.set(pose.x, 0, pose.y);
    // Heading in 2D is counterclockwise angle from X axis; in Three.js yaw rotates around Y
    this.robotRootGroup.rotation.y = -pose.heading + Math.PI / 2;

    // Contact shadow follows robot
    this.shadowPlane.position.x = pose.x;
    this.shadowPlane.position.z = pose.y;

    // 2. Head Pan & Tilt
    this.headGroup.rotation.y = headState.pan;
    this.headGroup.rotation.x = -headState.tilt;

    // Eyelid expressions (curious tilt)
    if (headState.expression === 'CURIOUS') {
      this.leftEyelid.rotation.z = 0.25;
      this.rightEyelid.rotation.z = -0.15;
    } else if (headState.expression === 'SLEEP') {
      this.leftEyelid.position.y = -0.02;
      this.rightEyelid.position.y = -0.02;
    } else {
      this.leftEyelid.rotation.z = 0;
      this.rightEyelid.rotation.z = 0;
      this.leftEyelid.position.y = 0;
      this.rightEyelid.position.y = 0;
    }

    // 3. Left Arm Joints
    // [0]: Shoulder Pan, [1]: Shoulder Pitch, [2]: Elbow Pitch, [3]: Wrist Pitch, [4]: Wrist Roll
    if (leftArmAngles.length >= 5) {
      this.leftShoulderPan.rotation.y = leftArmAngles[0];
      this.leftShoulderPitch.rotation.x = leftArmAngles[1];
      this.leftElbow.rotation.x = leftArmAngles[2];
      this.leftWristPitch.rotation.x = leftArmAngles[3];
      this.leftWristRoll.rotation.z = leftArmAngles[4];
    }
    // Left Gripper Aperture (0.0 to 1.0)
    const leftFingerOffset = 0.012 + leftGripperAperture * 0.026;
    if (this.leftGripperFingerA && this.leftGripperFingerB) {
      this.leftGripperFingerA.position.x = -leftFingerOffset;
      this.leftGripperFingerB.position.x = leftFingerOffset;
    }

    // 4. Right Arm Joints
    if (rightArmAngles.length >= 5) {
      this.rightShoulderPan.rotation.y = rightArmAngles[0];
      this.rightShoulderPitch.rotation.x = rightArmAngles[1];
      this.rightElbow.rotation.x = rightArmAngles[2];
      this.rightWristPitch.rotation.x = rightArmAngles[3];
      this.rightWristRoll.rotation.z = rightArmAngles[4];
    }
    // Right Gripper Aperture
    const rightFingerOffset = 0.012 + rightGripperAperture * 0.026;
    if (this.rightGripperFingerA && this.rightGripperFingerB) {
      this.rightGripperFingerA.position.x = -rightFingerOffset;
      this.rightGripperFingerB.position.x = rightFingerOffset;
    }

    // 5. Ultrasonic Sensor Rays
    this.updateSensorRays(sensors, pose);

    // 6. Environment Objects & Pickable Grabs
    this.updateEnvironmentObjects(envObjects);

    // 7. Path Waypoints Line
    this.updatePathLine(pathWaypoints);

    // 8. Dynamic Camera Tracking Modes
    this.updateCameraTracking(pose);
  }

  private updateSensorRays(sensors: UltrasonicSensor[], pose: RobotPose): void {
    // Clear old ray lines
    while (this.sensorRayLinesGroup.children.length > 0) {
      const child = this.sensorRayLinesGroup.children[0];
      this.sensorRayLinesGroup.remove(child);
      if (child instanceof THREE.Line) {
        child.geometry.dispose();
      }
    }

    if (!this.showSensorRays) return;

    for (const s of sensors) {
      const rayPoints: THREE.Vector3[] = [];
      const originWorld = this.sensorToWorld(s.relativePosition, pose);
      rayPoints.push(new THREE.Vector3(originWorld.x, originWorld.y, originWorld.z));

      if (s.hitPoint) {
        rayPoints.push(new THREE.Vector3(s.hitPoint.x, s.hitPoint.y, s.hitPoint.z));
      } else {
        // Max range ray
        const heading = pose.heading + s.relativeOrientation;
        const endX = originWorld.x + Math.cos(heading) * s.range;
        const endZ = originWorld.z + Math.sin(heading) * s.range;
        rayPoints.push(new THREE.Vector3(endX, originWorld.y, endZ));
      }

      const rayGeo = new THREE.BufferGeometry().setFromPoints(rayPoints);
      const color = s.status === 'DANGER' ? 0xef4444 : s.status === 'CAUTION' ? 0xf59e0b : 0x10b981;
      const rayMat = new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.65 });
      const rayLine = new THREE.Line(rayGeo, rayMat);
      this.sensorRayLinesGroup.add(rayLine);

      // Hit point dot
      if (s.hitPoint) {
        const hitGeo = new THREE.SphereGeometry(0.025, 8, 8);
        const hitMat = new THREE.MeshBasicMaterial({ color });
        const hitMesh = new THREE.Mesh(hitGeo, hitMat);
        hitMesh.position.set(s.hitPoint.x, s.hitPoint.y, s.hitPoint.z);
        this.sensorRayLinesGroup.add(hitMesh);
      }
    }
  }

  private sensorToWorld(relPos: Vector3D, pose: RobotPose): Vector3D {
    const cosH = Math.cos(pose.heading);
    const sinH = Math.sin(pose.heading);
    return {
      x: pose.x + (relPos.x * cosH + relPos.z * sinH),
      y: relPos.y,
      z: pose.y + (-relPos.x * sinH + relPos.z * cosH),
    };
  }

  private updateEnvironmentObjects(objects: EnvironmentObject[]): void {
    // Keep environment meshes in sync
    const currentIds = new Set(objects.map((o) => o.id));

    // Remove defunct
    for (const [id, mesh] of this.envMeshesMap.entries()) {
      if (!currentIds.has(id)) {
        this.scene.remove(mesh);
        this.envMeshesMap.delete(id);
      }
    }

    // Add or update
    for (const obj of objects) {
      let mesh = this.envMeshesMap.get(obj.id);
      if (!mesh) {
        mesh = this.createEnvironmentMesh(obj);
        this.envMeshesMap.set(obj.id, mesh);
        this.scene.add(mesh);
      }

      // Update position
      mesh.position.set(obj.position.x, obj.position.y, obj.position.z);
      mesh.rotation.y = obj.rotationY;
    }
  }

  private createEnvironmentMesh(obj: EnvironmentObject): THREE.Object3D {
    const group = new THREE.Group();

    if (obj.type === 'BOX') {
      const geo = new THREE.BoxGeometry(obj.size.x, obj.size.y, obj.size.z);
      this.geometries.push(geo);
      const mat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(obj.color),
        roughness: 0.35,
        metalness: 0.6,
      });
      this.materials.push(mat);
      const m = new THREE.Mesh(geo, mat);
      m.castShadow = !this.isSoftwareGl;
      m.receiveShadow = !this.isSoftwareGl;
      group.add(m);

      // Metallic corner rivets on cargo box
      const rivetGeo = new THREE.BoxGeometry(obj.size.x + 0.005, obj.size.y * 0.2, obj.size.z + 0.005);
      this.geometries.push(rivetGeo);
      const rivetMat = new THREE.MeshStandardMaterial({ color: 0x3f3f46, metalness: 0.9, roughness: 0.2 });
      this.materials.push(rivetMat);
      const rivet = new THREE.Mesh(rivetGeo, rivetMat);
      group.add(rivet);
    } else if (obj.type === 'TABLE') {
      // Table Top
      const topGeo = new THREE.BoxGeometry(obj.size.x, 0.05, obj.size.z);
      this.geometries.push(topGeo);
      const topMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.4, metalness: 0.3 });
      this.materials.push(topMat);
      const top = new THREE.Mesh(topGeo, topMat);
      top.position.y = obj.size.y / 2 - 0.025;
      top.castShadow = !this.isSoftwareGl;
      top.receiveShadow = !this.isSoftwareGl;
      group.add(top);

      // 4 Steel Legs
      const legGeo = new THREE.CylinderGeometry(0.03, 0.03, obj.size.y - 0.05, 8);
      this.geometries.push(legGeo);
      const legMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.8, roughness: 0.3 });
      this.materials.push(legMat);

      const dx = obj.size.x / 2 - 0.06;
      const dz = obj.size.z / 2 - 0.06;
      const legY = 0;

      for (const lx of [-dx, dx]) {
        for (const lz of [-dz, dz]) {
          const leg = new THREE.Mesh(legGeo, legMat);
          leg.position.set(lx, legY, lz);
          leg.castShadow = !this.isSoftwareGl;
          group.add(leg);
        }
      }
    } else if (obj.type === 'CHARGER') {
      // Charging Dock Station
      const dockGeo = new THREE.BoxGeometry(obj.size.x, obj.size.y, obj.size.z);
      this.geometries.push(dockGeo);
      const dockMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.7, roughness: 0.3 });
      this.materials.push(dockMat);
      const dock = new THREE.Mesh(dockGeo, dockMat);
      group.add(dock);

      // Glowing Contact Pads
      const padGeo = new THREE.BoxGeometry(0.12, 0.01, 0.35);
      this.geometries.push(padGeo);
      const padMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      this.materials.push(padMat);
      const pad1 = new THREE.Mesh(padGeo, padMat);
      pad1.position.set(-0.2, obj.size.y / 2 + 0.005, 0);
      const pad2 = new THREE.Mesh(padGeo, padMat);
      pad2.position.set(0.2, obj.size.y / 2 + 0.005, 0);
      group.add(pad1, pad2);
    } else {
      // Obstacle Barrier
      const geo = new THREE.BoxGeometry(obj.size.x, obj.size.y, obj.size.z);
      this.geometries.push(geo);
      const mat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.7, metalness: 0.3 });
      this.materials.push(mat);
      const m = new THREE.Mesh(geo, mat);
      m.castShadow = !this.isSoftwareGl;
      group.add(m);
    }

    return group;
  }

  private updatePathLine(waypoints: { x: number; y: number }[]): void {
    if (!this.showPathTrail || waypoints.length === 0) {
      this.pathLineMesh.visible = false;
      return;
    }

    this.pathLineMesh.visible = true;
    const points: THREE.Vector3[] = waypoints.map((w) => new THREE.Vector3(w.x, 0.015, w.y));
    this.pathLineMesh.geometry.dispose();
    this.pathLineMesh.geometry = new THREE.BufferGeometry().setFromPoints(points);
  }

  private updateCameraTracking(pose: RobotPose): void {
    const rx = pose.x;
    const rz = pose.y;

    if (this.activeCameraMode === 'FOLLOW') {
      // Damped chase camera 1.8m behind robot
      const dist = 1.8;
      const height = 1.2;
      const camX = rx - Math.cos(pose.heading) * dist;
      const camZ = rz - Math.sin(pose.heading) * dist;

      this.camera.position.lerp(new THREE.Vector3(camX, height, camZ), 0.08);
      this.controls.target.lerp(new THREE.Vector3(rx, 0.38, rz), 0.08);
    } else if (this.activeCameraMode === 'HEAD_FPV') {
      // Camera placed right inside binocular eye bridge looking forward
      const eyeHeight = 0.52;
      const forwardOffset = 0.12;
      const eyeX = rx + Math.cos(pose.heading) * forwardOffset;
      const eyeZ = rz + Math.sin(pose.heading) * forwardOffset;
      const lookDist = 4.0;
      const lookX = eyeX + Math.cos(pose.heading) * lookDist;
      const lookZ = eyeZ + Math.sin(pose.heading) * lookDist;

      this.camera.position.set(eyeX, eyeHeight, eyeZ);
      this.controls.target.set(lookX, eyeHeight - 0.15, lookZ);
    } else if (this.activeCameraMode === 'TOP_DOWN') {
      this.camera.position.lerp(new THREE.Vector3(rx, 6.5, rz + 0.01), 0.08);
      this.controls.target.lerp(new THREE.Vector3(rx, 0, rz), 0.08);
    } else if (this.activeCameraMode === 'ARM_INSPECTION') {
      // Focus on front left arm workspace
      const targetPos = new THREE.Vector3(rx + 0.35, 0.40, rz + 0.35);
      const camPos = new THREE.Vector3(rx + 0.85, 0.65, rz + 0.85);
      this.camera.position.lerp(camPos, 0.08);
      this.controls.target.lerp(targetPos, 0.08);
    }
  }

  public setCameraView(mode: CameraViewMode): void {
    this.activeCameraMode = mode;
    if (mode === 'ORBIT') {
      this.controls.enabled = true;
    } else {
      this.controls.enabled = false;
    }
  }

  public setVisualHelperToggles(axes: boolean, rays: boolean, collision: boolean, path: boolean): void {
    this.showCoordinateAxes = axes;
    this.showSensorRays = rays;
    this.showCollisionBounds = collision;
    this.showPathTrail = path;

    this.axesHelper.visible = axes;
    this.leftGripperAxes.visible = axes;
    this.rightGripperAxes.visible = axes;
    this.sensorRayLinesGroup.visible = rays;
    this.pathLineMesh.visible = path;
  }

  private renderLoop = (): void => {
    if (this.isDestroyed) return;

    if (this.controls.enabled) {
      this.controls.update();
    }

    this.renderer.render(this.scene, this.camera);
    this.animFrameId = requestAnimationFrame(this.renderLoop);
  };

  private onWindowResize = (): void => {
    if (!this.container || this.isDestroyed) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / (h || 1);
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  public destroy(): void {
    this.isDestroyed = true;
    cancelAnimationFrame(this.animFrameId);
    window.removeEventListener('resize', this.onWindowResize);

    this.controls.dispose();
    this.renderer.dispose();

    for (const g of this.geometries) g.dispose();
    for (const m of this.materials) m.dispose();

    if (this.renderer.domElement && this.renderer.domElement.parentNode) {
      this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
    }
  }
}
