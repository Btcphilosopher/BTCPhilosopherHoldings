/**
 * AUREOM.AI — ROBOT.OS
 * Mathematical types, robot geometry, kinematics state, and telemetry definitions.
 */

export type OperatingMode =
  | 'IDLE'
  | 'MANUAL'
  | 'AUTONOMOUS'
  | 'ARM_CONTROL'
  | 'TASK_EXECUTION'
  | 'PAUSED'
  | 'FAULT'
  | 'EMERGENCY_STOP';

export type ExecutionEnvironment = 'SIMULATION' | 'HARDWARE_GATED';

export type CameraViewMode = 'ORBIT' | 'FOLLOW' | 'HEAD_FPV' | 'TOP_DOWN' | 'ARM_INSPECTION';

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface RobotPose {
  x: number;          // meters (world coordinate)
  y: number;          // meters (ground plane Y in 2D math, mapped to X/Z in Three.js)
  heading: number;    // radians (yaw)
  linearVelocity: number;   // m/s
  angularVelocity: number;  // rad/s
  leftWheelSpeed: number;   // m/s
  rightWheelSpeed: number;  // m/s
}

export interface ArmJointConfig {
  name: string;
  angle: number;      // radians
  minAngle: number;   // radians
  maxAngle: number;   // radians
  velocityLimit: number; // rad/s
  status: 'NOMINAL' | 'LIMIT_REACHED' | 'OVERTORQUE';
}

export interface ArmState {
  joints: [
    ArmJointConfig, // 0: Shoulder Pan (Yaw)
    ArmJointConfig, // 1: Shoulder Pitch (Elevation)
    ArmJointConfig, // 2: Elbow Pitch (Flexion)
    ArmJointConfig, // 3: Wrist Pitch
    ArmJointConfig  // 4: Wrist Roll
  ];
  gripperAperture: number; // 0.0 (closed) to 1.0 (fully open)
  gripperHolding: string | null; // ID of grabbed object
  endEffectorWorld: Vector3D;
  endEffectorChassis: Vector3D;
  targetIK: Vector3D;
  ikReachable: boolean;
  ikSolving: boolean;
}

export interface HeadState {
  pan: number;  // radians (-1.57 to +1.57)
  tilt: number; // radians (-0.6 to +0.8)
  expression: 'NEUTRAL' | 'CURIOUS' | 'HAPPY' | 'ALERT' | 'SLEEP';
  blinkTimer: number;
}

export interface UltrasonicSensor {
  id: string;
  name: string;
  relativePosition: Vector3D; // chassis frame
  relativeOrientation: number; // heading angle relative to robot (radians)
  range: number;      // meters (max detection 3.5m)
  measuredDistance: number; // current reading in meters
  hitPoint: Vector3D | null;
  status: 'CLEAR' | 'CAUTION' | 'DANGER';
}

export interface TelemetrySnapshot {
  timestamp: number;
  simTime: number;
  x: number;
  y: number;
  heading: number;
  linearVelocity: number;
  angularVelocity: number;
  batteryLevel: number;
  batteryVoltage: number;
  batteryCurrent: number;
  leftTrackSpeed: number;
  rightTrackSpeed: number;
  leftArmEndEffector: Vector3D;
  rightArmEndEffector: Vector3D;
  minObstacleDistance: number;
  activeMode: OperatingMode;
  imuPitch: number;
  imuRoll: number;
  motorTemp: number;
}

export interface EnvironmentObject {
  id: string;
  name: string;
  type: 'BOX' | 'CYLINDER' | 'TABLE' | 'CHARGER' | 'OBSTACLE_WALL';
  position: Vector3D;
  size: Vector3D;
  rotationY: number;
  color: string;
  isPickable: boolean;
  isAttached: boolean;
  attachedToArm?: 'LEFT' | 'RIGHT';
}

export interface PathWaypoint {
  x: number;
  y: number;
  heading?: number;
  reached: boolean;
}

export interface RobotTaskStep {
  id: number;
  description: string;
  action: () => void | Promise<void>;
  status: 'PENDING' | 'EXECUTING' | 'COMPLETED' | 'FAILED';
}

export interface RobotTask {
  id: string;
  name: string;
  description: string;
  steps: RobotTaskStep[];
  currentStepIndex: number;
  status: 'IDLE' | 'RUNNING' | 'PAUSED' | 'COMPLETED' | 'CANCELLED' | 'FAILED';
}
