/**
 * Central Robot Simulation Service (Angular 21 Zoneless Signal Store)
 * Coordinates simulation clock, differential drive, arm kinematics,
 * ultrasonic sensor raycasting, path planning, tasks, and telemetry recorder.
 */

import { Injectable, signal } from '@angular/core';
import {
  ArmJointConfig,
  ArmState,
  EnvironmentObject,
  ExecutionEnvironment,
  HeadState,
  OperatingMode,
  PathWaypoint,
  RobotPose,
  TelemetrySnapshot,
  UltrasonicSensor,
  Vector3D,
} from '../models/robot.types';
import {
  ArmKinematicsSolver,
} from '../kinematics/arm-kinematics';
import { DifferentialDriveKinematics } from '../kinematics/differential-drive';
import { AStarPathPlanner } from '../navigation/path-planner';
import { RCommandEngine, SimulationCommander } from '../r-engine/r-command-engine';

export const INITIAL_POSE: RobotPose = {
  x: 0.0,
  y: 0.0,
  heading: 0.0,
  linearVelocity: 0.0,
  angularVelocity: 0.0,
  leftWheelSpeed: 0.0,
  rightWheelSpeed: 0.0,
};

function createInitialArm(isRight: boolean): ArmState {
  const joints: [
    ArmJointConfig,
    ArmJointConfig,
    ArmJointConfig,
    ArmJointConfig,
    ArmJointConfig
  ] = [
    {
      name: 'Shoulder Pan',
      angle: isRight ? 0.25 : -0.25,
      minAngle: -2.35,
      maxAngle: 2.35,
      velocityLimit: 1.5,
      status: 'NOMINAL',
    },
    {
      name: 'Shoulder Pitch',
      angle: 0.35,
      minAngle: -0.78,
      maxAngle: 1.92,
      velocityLimit: 1.2,
      status: 'NOMINAL',
    },
    {
      name: 'Elbow Pitch',
      angle: 0.55,
      minAngle: -2.09,
      maxAngle: 0.78,
      velocityLimit: 1.5,
      status: 'NOMINAL',
    },
    {
      name: 'Wrist Pitch',
      angle: -0.25,
      minAngle: -1.57,
      maxAngle: 1.57,
      velocityLimit: 2.0,
      status: 'NOMINAL',
    },
    {
      name: 'Wrist Roll',
      angle: 0.0,
      minAngle: -3.14,
      maxAngle: 3.14,
      velocityLimit: 2.5,
      status: 'NOMINAL',
    },
  ];

  return {
    joints,
    gripperAperture: 0.8,
    gripperHolding: null,
    endEffectorWorld: { x: isRight ? 0.3 : -0.3, y: 0.32, z: 0.4 },
    endEffectorChassis: { x: isRight ? 0.22 : -0.22, y: 0.32, z: 0.38 },
    targetIK: { x: isRight ? 0.3 : -0.3, y: 0.32, z: 0.4 },
    ikReachable: true,
    ikSolving: false,
  };
}

export const INITIAL_HEAD: HeadState = {
  pan: 0.0,
  tilt: 0.0,
  expression: 'NEUTRAL',
  blinkTimer: 0,
};

export const INITIAL_SENSORS: UltrasonicSensor[] = [
  {
    id: 'us_front_left',
    name: 'Front-Left Range',
    relativePosition: { x: -0.14, y: 0.25, z: 0.22 },
    relativeOrientation: 0.45,
    range: 3.2,
    measuredDistance: 3.2,
    hitPoint: null,
    status: 'CLEAR',
  },
  {
    id: 'us_front_center',
    name: 'Front-Center Range',
    relativePosition: { x: 0.0, y: 0.25, z: 0.23 },
    relativeOrientation: 0.0,
    range: 3.5,
    measuredDistance: 3.5,
    hitPoint: null,
    status: 'CLEAR',
  },
  {
    id: 'us_front_right',
    name: 'Front-Right Range',
    relativePosition: { x: 0.14, y: 0.25, z: 0.22 },
    relativeOrientation: -0.45,
    range: 3.2,
    measuredDistance: 3.2,
    hitPoint: null,
    status: 'CLEAR',
  },
  {
    id: 'us_left_side',
    name: 'Left-Side Range',
    relativePosition: { x: -0.20, y: 0.25, z: 0.0 },
    relativeOrientation: 1.57,
    range: 2.5,
    measuredDistance: 2.5,
    hitPoint: null,
    status: 'CLEAR',
  },
  {
    id: 'us_right_side',
    name: 'Right-Side Range',
    relativePosition: { x: 0.20, y: 0.25, z: 0.0 },
    relativeOrientation: -1.57,
    range: 2.5,
    measuredDistance: 2.5,
    hitPoint: null,
    status: 'CLEAR',
  },
  {
    id: 'us_rear_center',
    name: 'Rear-Center Range',
    relativePosition: { x: 0.0, y: 0.25, z: -0.22 },
    relativeOrientation: Math.PI,
    range: 2.5,
    measuredDistance: 2.5,
    hitPoint: null,
    status: 'CLEAR',
  },
];

export const DEFAULT_ENV_OBJECTS: EnvironmentObject[] = [
  // Workbench Table
  {
    id: 'table_lab_1',
    name: 'Assembly Workbench',
    type: 'TABLE',
    position: { x: 1.8, y: 0.35, z: 1.2 },
    size: { x: 1.4, y: 0.7, z: 0.9 },
    rotationY: 0,
    color: '#d97706',
    isPickable: false,
    isAttached: false,
  },
  // Pickable Target Cargo Box A (On Table or floor)
  {
    id: 'box_copper',
    name: 'Payload Cube A (Copper)',
    type: 'BOX',
    position: { x: 0.45, y: 0.075, z: 0.45 },
    size: { x: 0.14, y: 0.14, z: 0.14 },
    rotationY: 0.2,
    color: '#ea580c',
    isPickable: true,
    isAttached: false,
  },
  // Pickable Target Cargo Box B (Titanium)
  {
    id: 'box_titanium',
    name: 'Payload Cube B (Titanium)',
    type: 'BOX',
    position: { x: 1.6, y: 0.77, z: 1.1 },
    size: { x: 0.12, y: 0.12, z: 0.12 },
    rotationY: 0.0,
    color: '#38bdf8',
    isPickable: true,
    isAttached: false,
  },
  // Charging Dock Station
  {
    id: 'dock_charger',
    name: 'Recharge Solar Dock',
    type: 'CHARGER',
    position: { x: -2.8, y: 0.15, z: -2.4 },
    size: { x: 0.9, y: 0.3, z: 0.8 },
    rotationY: 0.5,
    color: '#1e293b',
    isPickable: false,
    isAttached: false,
  },
  // Obstacle Wall / Barrier A
  {
    id: 'wall_barrier_1',
    name: 'Lab Divider Barrier',
    type: 'OBSTACLE_WALL',
    position: { x: 0.2, y: 0.4, z: -1.6 },
    size: { x: 2.2, y: 0.8, z: 0.25 },
    rotationY: 0.3,
    color: '#64748b',
    isPickable: false,
    isAttached: false,
  },
  // Obstacle Wall / Barrier B
  {
    id: 'wall_barrier_2',
    name: 'Hazard Barrier B',
    type: 'OBSTACLE_WALL',
    position: { x: -1.5, y: 0.4, z: 1.2 },
    size: { x: 0.25, y: 0.8, z: 1.8 },
    rotationY: 0.0,
    color: '#64748b',
    isPickable: false,
    isAttached: false,
  },
];

@Injectable({
  providedIn: 'root',
})
export class RobotSimulationService {
  // Kinematic Solvers
  private diffDrive = new DifferentialDriveKinematics();
  private leftArmSolver = new ArmKinematicsSolver(false);
  private rightArmSolver = new ArmKinematicsSolver(true);
  private pathPlanner = new AStarPathPlanner();

  // Primary Reactive Signals
  public pose = signal<RobotPose>(INITIAL_POSE);
  public leftArm = signal<ArmState>(createInitialArm(false));
  public rightArm = signal<ArmState>(createInitialArm(true));
  public head = signal<HeadState>(INITIAL_HEAD);
  public sensors = signal<UltrasonicSensor[]>(INITIAL_SENSORS);
  public envObjects = signal<EnvironmentObject[]>(DEFAULT_ENV_OBJECTS);
  public activePath = signal<PathWaypoint[]>([]);

  // Simulation Clock & State Machine
  public isRunning = signal<boolean>(true);
  public simulationTime = signal<number>(0);
  public timeSpeedMultiplier = signal<number>(1.0);
  public operatingMode = signal<OperatingMode>('MANUAL');
  public executionEnv = signal<ExecutionEnvironment>('SIMULATION');
  public hardwareModeUnlocked = signal<boolean>(false);
  public emergencyStopTriggered = signal<boolean>(false);

  // Battery Telemetry
  public batteryLevel = signal<number>(98.4); // %
  public batteryVoltage = signal<number>(24.8); // V
  public batteryCurrent = signal<number>(1.2); // A
  public motorTemp = signal<number>(31.5); // deg C

  // Telemetry buffer for waveforms & export (max 100 points)
  public telemetryHistory = signal<TelemetrySnapshot[]>([]);

  // Active Task Sequence
  public activeTaskName = signal<string | null>(null);
  public taskStepDescription = signal<string | null>(null);
  public taskProgress = signal<number>(0);

  // R Engine Console instance
  public rCommandEngine: RCommandEngine;

  // Internal clock loop
  private clockIntervalId: number | null = null;
  private readonly fixedDt = 1 / 60; // 60Hz physics clock

  // Keyboard driving command cache
  private keyForward = false;
  private keyBackward = false;
  private keyLeft = false;
  private keyRight = false;

  constructor() {
    // Setup R Command Engine
    const commander: SimulationCommander = {
      moveForward: (d) => this.commandDistance(d),
      rotate: (a) => this.commandHeadingDelta(a),
      stop: () => this.commandStop(),
      setHeadPan: (p) => this.setHeadPan(p),
      setHeadTilt: (t) => this.setHeadTilt(t),
      setArmJoint: (isRight, j, a) => this.setArmJointAngle(isRight, j, a),
      setGripper: (isRight, ap) => this.setGripperAperture(isRight, ap),
      navigateTo: (x, y) => this.planAndExecuteNavigation(x, y),
      returnHome: () => this.planAndExecuteNavigation(0, 0),
      emergencyStop: () => this.triggerEmergencyStop(),
      resetSimulation: () => this.resetSimulation(),
      runPickAndPlace: () => this.runExperimentPickAndPlace(),
      solveIKTarget: (isRight, x, y, z) => this.solveIKTarget(isRight, { x, y, z }),
    };
    this.rCommandEngine = new RCommandEngine(commander);

    // Initial FK calculation for initial end effector positions
    this.updateArmsForwardKinematics();

    // Start simulation clock in browser only
    if (typeof window !== 'undefined') {
      this.startClock();
      window.addEventListener('keydown', this.handleKeyDown);
      window.addEventListener('keyup', this.handleKeyUp);
    }
  }

  public startClock(): void {
    if (typeof window === 'undefined') return;
    if (this.clockIntervalId !== null) return;
    this.isRunning.set(true);

    this.clockIntervalId = window.setInterval(() => {
      this.simulationTick();
    }, 1000 / 60);
  }

  public pauseClock(): void {
    this.isRunning.set(false);
    if (this.clockIntervalId !== null) {
      clearInterval(this.clockIntervalId);
      this.clockIntervalId = null;
    }
  }

  public stepClock(): void {
    this.simulationTick();
  }

  public setSpeedMultiplier(mult: number): void {
    this.timeSpeedMultiplier.set(mult);
  }

  /**
   * Main Fixed-Timestep Simulation Loop (60 Hz)
   */
  private simulationTick(): void {
    if (!this.isRunning() && this.operatingMode() !== 'PAUSED') return;

    const dt = this.fixedDt * this.timeSpeedMultiplier();
    this.simulationTime.update((t) => t + dt);

    // If Emergency Stop is active, halt all motion immediately
    if (this.emergencyStopTriggered()) {
      const p = this.pose();
      if (p.linearVelocity !== 0 || p.angularVelocity !== 0) {
        this.pose.update((curr) => ({
          ...curr,
          linearVelocity: 0,
          angularVelocity: 0,
          leftWheelSpeed: 0,
          rightWheelSpeed: 0,
        }));
      }
      return;
    }

    // 1. Process Drive Kinematics
    this.updateDrivePhysics(dt);

    // 2. Process Autonomous Navigation Follower if active
    this.updateNavigationFollower();

    // 3. Process Ultrasonic Sensor Raycasts against environment objects
    this.updateSensorRaycasts();

    // 4. Update Battery Discharge Model
    this.updateBatteryDrain(dt);

    // 5. Update Grasp Attachments (if arm is carrying an object)
    this.updatePickedObjectsPosition();

    // 6. Record Telemetry Snapshot every ~100ms
    if (Math.floor(this.simulationTime() * 10) % 2 === 0) {
      this.recordTelemetrySnapshot();
    }
  }

  private updateDrivePhysics(dt: number): void {
    let targetV = 0;
    let targetOmega = 0;

    if (this.operatingMode() === 'MANUAL') {
      // Check keyboard or active button dead-man
      if (this.keyForward) targetV += 0.65;
      if (this.keyBackward) targetV -= 0.5;
      if (this.keyLeft) targetOmega += 1.4;
      if (this.keyRight) targetOmega -= 1.4;
    } else if (this.operatingMode() === 'AUTONOMOUS') {
      targetV = this.pose().linearVelocity;
      targetOmega = this.pose().angularVelocity;
    }

    // Integrate pose using differential drive kinematics
    const newPose = this.diffDrive.integratePose(this.pose(), targetV, targetOmega, dt);
    this.pose.set(newPose);
  }

  private updateNavigationFollower(): void {
    const path = this.activePath();
    if (path.length === 0 || this.operatingMode() !== 'AUTONOMOUS') return;

    const currentPose = this.pose();
    const nextWp = path[0];

    const dx = nextWp.x - currentPose.x;
    const dy = nextWp.y - currentPose.y;
    const dist = Math.hypot(dx, dy);

    // Waypoint reached threshold (12cm)
    if (dist < 0.12) {
      this.activePath.update((p) => p.slice(1));
      if (this.activePath().length === 0) {
        // Path completed
        this.pose.update((p) => ({ ...p, linearVelocity: 0, angularVelocity: 0 }));
        this.operatingMode.set('IDLE');
        return;
      }
    }

    // Proportional heading steering controller
    const targetHeading = Math.atan2(dy, dx);
    let headingErr = targetHeading - currentPose.heading;
    while (headingErr > Math.PI) headingErr -= 2 * Math.PI;
    while (headingErr < -Math.PI) headingErr += 2 * Math.PI;

    let v = 0.55;
    const omega = headingErr * 2.2;

    // Slow down on sharp turns
    if (Math.abs(headingErr) > 0.6) {
      v = 0.15;
    }

    this.pose.update((p) => ({
      ...p,
      linearVelocity: v,
      angularVelocity: omega,
    }));
  }

  private updateSensorRaycasts(): void {
    const p = this.pose();
    const objects = this.envObjects();

    const updatedSensors = this.sensors().map((sensor) => {
      // Ray origin in world
      const cosH = Math.cos(p.heading);
      const sinH = Math.sin(p.heading);
      const originX = p.x + (sensor.relativePosition.x * cosH + sensor.relativePosition.z * sinH);
      const originZ = p.y + (-sensor.relativePosition.x * sinH + sensor.relativePosition.z * cosH);

      const rayHeading = p.heading + sensor.relativeOrientation;
      const rayDirX = Math.cos(rayHeading);
      const rayDirZ = Math.sin(rayHeading);

      let closestDist = sensor.range;
      let hitPt: Vector3D | null = null;

      // Check distance against each environment box / table
      for (const obj of objects) {
        if (obj.isAttached) continue; // ignore objects carried by robot

        const halfW = obj.size.x / 2;
        const halfD = obj.size.z / 2;
        const minX = obj.position.x - halfW;
        const maxX = obj.position.x + halfW;
        const minZ = obj.position.z - halfD;
        const maxZ = obj.position.z + halfD;

        // Bounding box ray-intersection test (Slab method)
        let tmin = (minX - originX) / (rayDirX || 0.00001);
        let tmax = (maxX - originX) / (rayDirX || 0.00001);
        if (tmin > tmax) [tmin, tmax] = [tmax, tmin];

        let tzmin = (minZ - originZ) / (rayDirZ || 0.00001);
        let tzmax = (maxZ - originZ) / (rayDirZ || 0.00001);
        if (tzmin > tzmax) [tzmin, tzmax] = [tzmax, tzmin];

        if (tmin > tzmax || tzmin > tmax) continue;

        const tEnter = Math.max(tmin, tzmin);
        if (tEnter > 0 && tEnter < closestDist) {
          closestDist = tEnter;
          hitPt = {
            x: originX + rayDirX * tEnter,
            y: sensor.relativePosition.y,
            z: originZ + rayDirZ * tEnter,
          };
        }
      }

      // Add slight simulated sensor noise (+- 1%)
      const noise = (Math.random() - 0.5) * 0.01;
      const finalDist = Math.max(0.04, Math.min(sensor.range, closestDist + noise));

      let status: 'CLEAR' | 'CAUTION' | 'DANGER' = 'CLEAR';
      if (finalDist < 0.35) status = 'DANGER';
      else if (finalDist < 0.75) status = 'CAUTION';

      return {
        ...sensor,
        measuredDistance: finalDist,
        hitPoint: hitPt,
        status,
      };
    });

    this.sensors.set(updatedSensors);
  }

  private updateBatteryDrain(dt: number): void {
    const isMoving = Math.abs(this.pose().linearVelocity) > 0.01 || Math.abs(this.pose().angularVelocity) > 0.01;
    // Current draw: 0.8A idle, 2.8A driving
    const current = isMoving ? 2.8 : 0.8;
    this.batteryCurrent.set(current);

    // 0.0008% per second baseline
    const drain = current * 0.0005 * dt;
    this.batteryLevel.update((b) => Math.max(0, b - drain));
    this.batteryVoltage.set(21.0 + (this.batteryLevel() / 100) * 4.2);

    // Motor temperature rises slightly when driving
    if (isMoving) {
      this.motorTemp.update((t) => Math.min(55, t + 0.04 * dt));
    } else {
      this.motorTemp.update((t) => Math.max(28, t - 0.02 * dt));
    }
  }

  private updatePickedObjectsPosition(): void {
    // If left or right arm is holding an object, update that object's position to gripper tip
    const leftHold = this.leftArm().gripperHolding;
    if (leftHold) {
      const ee = this.leftArm().endEffectorWorld;
      this.envObjects.update((objs) =>
        objs.map((o) =>
          o.id === leftHold ? { ...o, position: { x: ee.x, y: ee.y, z: ee.z } } : o
        )
      );
    }

    const rightHold = this.rightArm().gripperHolding;
    if (rightHold) {
      const ee = this.rightArm().endEffectorWorld;
      this.envObjects.update((objs) =>
        objs.map((o) =>
          o.id === rightHold ? { ...o, position: { x: ee.x, y: ee.y, z: ee.z } } : o
        )
      );
    }
  }

  private recordTelemetrySnapshot(): void {
    const p = this.pose();
    const minSens = Math.min(...this.sensors().map((s) => s.measuredDistance));

    const snap: TelemetrySnapshot = {
      timestamp: Date.now(),
      simTime: this.simulationTime(),
      x: p.x,
      y: p.y,
      heading: p.heading,
      linearVelocity: p.linearVelocity,
      angularVelocity: p.angularVelocity,
      batteryLevel: this.batteryLevel(),
      batteryVoltage: this.batteryVoltage(),
      batteryCurrent: this.batteryCurrent(),
      leftTrackSpeed: p.leftWheelSpeed,
      rightTrackSpeed: p.rightWheelSpeed,
      leftArmEndEffector: this.leftArm().endEffectorWorld,
      rightArmEndEffector: this.rightArm().endEffectorWorld,
      minObstacleDistance: minSens,
      activeMode: this.operatingMode(),
      imuPitch: Math.sin(this.simulationTime() * 1.5) * 0.015,
      imuRoll: Math.cos(this.simulationTime() * 1.2) * 0.01,
      motorTemp: this.motorTemp(),
    };

    this.telemetryHistory.update((h) => {
      const next = [...h, snap];
      return next.length > 80 ? next.slice(next.length - 80) : next;
    });
  }

  // --- Kinematics Controls ---

  public updateArmsForwardKinematics(): void {
    const p = this.pose();

    // Left Arm
    const leftAngles = this.leftArm().joints.map((j) => j.angle);
    const fkLeft = this.leftArmSolver.forwardKinematicsChassis(leftAngles);
    const eeLeftWorld = this.leftArmSolver.chassisToWorld(fkLeft.endEffector, p);

    this.leftArm.update((curr) => ({
      ...curr,
      endEffectorChassis: fkLeft.endEffector,
      endEffectorWorld: eeLeftWorld,
    }));

    // Right Arm
    const rightAngles = this.rightArm().joints.map((j) => j.angle);
    const fkRight = this.rightArmSolver.forwardKinematicsChassis(rightAngles);
    const eeRightWorld = this.rightArmSolver.chassisToWorld(fkRight.endEffector, p);

    this.rightArm.update((curr) => ({
      ...curr,
      endEffectorChassis: fkRight.endEffector,
      endEffectorWorld: eeRightWorld,
    }));
  }

  public setArmJointAngle(isRight: boolean, jointIndex: number, angleRad: number): void {
    const armSignal = isRight ? this.rightArm : this.leftArm;
    armSignal.update((arm) => {
      const updatedJoints = [...arm.joints] as ArmState['joints'];
      const j = updatedJoints[jointIndex];
      const clamped = Math.max(j.minAngle, Math.min(j.maxAngle, angleRad));
      updatedJoints[jointIndex] = {
        ...j,
        angle: clamped,
        status: clamped === j.minAngle || clamped === j.maxAngle ? 'LIMIT_REACHED' : 'NOMINAL',
      };
      return { ...arm, joints: updatedJoints };
    });

    this.updateArmsForwardKinematics();
  }

  public solveIKTarget(isRight: boolean, targetChassis: Vector3D): boolean {
    const solver = isRight ? this.rightArmSolver : this.leftArmSolver;
    const arm = isRight ? this.rightArm() : this.leftArm();
    const currentAngles = arm.joints.map((j) => j.angle);
    const limits = arm.joints.map((j) => ({ min: j.minAngle, max: j.maxAngle }));

    const res = solver.solveIK(targetChassis, currentAngles, limits);

    if (res.reachable) {
      res.solvedAngles.forEach((angle, idx) => {
        this.setArmJointAngle(isRight, idx, angle);
      });
      const armSignal = isRight ? this.rightArm : this.leftArm;
      armSignal.update((a) => ({ ...a, targetIK: targetChassis, ikReachable: true }));
      return true;
    } else {
      const armSignal = isRight ? this.rightArm : this.leftArm;
      armSignal.update((a) => ({ ...a, targetIK: targetChassis, ikReachable: false }));
      return false;
    }
  }

  public setGripperAperture(isRight: boolean, aperture: number): void {
    const armSignal = isRight ? this.rightArm : this.leftArm;
    const clamped = Math.max(0, Math.min(1, aperture));

    armSignal.update((a) => ({ ...a, gripperAperture: clamped }));

    // Check grasp or release on nearby pickable objects
    const armState = armSignal();
    const ee = armState.endEffectorWorld;

    if (clamped < 0.25) {
      // Trying to grasp: find nearest pickable box within 0.18m
      const nearest = this.envObjects().find((obj) => {
        if (!obj.isPickable || obj.isAttached) return false;
        const dist = Math.hypot(obj.position.x - ee.x, obj.position.y - ee.y, obj.position.z - ee.z);
        return dist < 0.22;
      });

      if (nearest) {
        armSignal.update((a) => ({ ...a, gripperHolding: nearest.id }));
        this.envObjects.update((objs) =>
          objs.map((o) =>
            o.id === nearest.id ? { ...o, isAttached: true, attachedToArm: isRight ? 'RIGHT' : 'LEFT' } : o
          )
        );
      }
    } else if (clamped > 0.6) {
      // Release
      const heldId = armState.gripperHolding;
      if (heldId) {
        armSignal.update((a) => ({ ...a, gripperHolding: null }));
        this.envObjects.update((objs) =>
          objs.map((o) =>
            o.id === heldId ? { ...o, isAttached: false, attachedToArm: undefined } : o
          )
        );
      }
    }
  }

  public setHeadPan(panRad: number): void {
    this.head.update((h) => ({ ...h, pan: Math.max(-1.57, Math.min(1.57, panRad)) }));
  }

  public setHeadTilt(tiltRad: number): void {
    this.head.update((h) => ({ ...h, tilt: Math.max(-0.6, Math.min(0.8, tiltRad)) }));
  }

  public triggerPersonality(type: 'CURIOUS' | 'WAVE' | 'LOOK_AROUND' | 'HAPPY'): void {
    if (type === 'CURIOUS') {
      this.head.update((h) => ({ ...h, expression: 'CURIOUS', tilt: 0.35, pan: 0.2 }));
      setTimeout(() => {
        this.head.update((h) => ({ ...h, expression: 'NEUTRAL', tilt: 0, pan: 0 }));
      }, 2500);
    } else if (type === 'WAVE') {
      // Left arm wave sequence
      this.setArmJointAngle(false, 0, -0.6);
      this.setArmJointAngle(false, 1, 1.2);
      this.setArmJointAngle(false, 2, -1.1);
      this.setGripperAperture(false, 0.9);
      this.head.update((h) => ({ ...h, expression: 'HAPPY', tilt: -0.15 }));

      let count = 0;
      const waveInterval = setInterval(() => {
        const toggle = count % 2 === 0 ? 0.3 : -0.3;
        this.setArmJointAngle(false, 3, toggle);
        count++;
        if (count > 5) {
          clearInterval(waveInterval);
          this.resetArmsToStow();
          this.head.update((h) => ({ ...h, expression: 'NEUTRAL', tilt: 0 }));
        }
      }, 300);
    } else if (type === 'LOOK_AROUND') {
      this.head.update((h) => ({ ...h, pan: -0.8, tilt: -0.2 }));
      setTimeout(() => {
        this.head.update((h) => ({ ...h, pan: 0.8, tilt: 0.2 }));
      }, 1000);
      setTimeout(() => {
        this.head.update((h) => ({ ...h, pan: 0, tilt: 0 }));
      }, 2000);
    }
  }

  public resetArmsToStow(): void {
    this.leftArm.set(createInitialArm(false));
    this.rightArm.set(createInitialArm(true));
    this.updateArmsForwardKinematics();
  }

  // --- Teleoperation Commands ---

  public commandDistance(distMeters: number): void {
    this.diffDrive.refreshCommand();
    const p = this.pose();
    const newX = p.x + distMeters * Math.cos(p.heading);
    const newY = p.y + distMeters * Math.sin(p.heading);
    this.pose.update((curr) => ({ ...curr, x: newX, y: newY, linearVelocity: 0.3 }));
    setTimeout(() => {
      this.pose.update((curr) => ({ ...curr, linearVelocity: 0 }));
    }, 800);
  }

  public commandHeadingDelta(rad: number): void {
    this.diffDrive.refreshCommand();
    this.pose.update((curr) => ({ ...curr, heading: curr.heading + rad, angularVelocity: 0.8 }));
    setTimeout(() => {
      this.pose.update((curr) => ({ ...curr, angularVelocity: 0 }));
    }, 700);
  }

  public commandStop(): void {
    this.keyForward = false;
    this.keyBackward = false;
    this.keyLeft = false;
    this.keyRight = false;
    this.pose.update((p) => ({
      ...p,
      linearVelocity: 0,
      angularVelocity: 0,
      leftWheelSpeed: 0,
      rightWheelSpeed: 0,
    }));
  }

  public planAndExecuteNavigation(goalX: number, goalY: number): void {
    this.operatingMode.set('AUTONOMOUS');
    this.pathPlanner.updateObstacles(this.envObjects(), 0.45);
    const waypoints = this.pathPlanner.planPath(this.pose().x, this.pose().y, goalX, goalY);
    this.activePath.set(waypoints);
  }

  public triggerEmergencyStop(): void {
    this.emergencyStopTriggered.set(true);
    this.operatingMode.set('EMERGENCY_STOP');
    this.commandStop();
  }

  public resetEmergencyStop(): void {
    this.emergencyStopTriggered.set(false);
    this.operatingMode.set('MANUAL');
  }

  public resetSimulation(): void {
    this.pose.set(INITIAL_POSE);
    this.leftArm.set(createInitialArm(false));
    this.rightArm.set(createInitialArm(true));
    this.head.set(INITIAL_HEAD);
    this.envObjects.set(DEFAULT_ENV_OBJECTS);
    this.activePath.set([]);
    this.emergencyStopTriggered.set(false);
    this.operatingMode.set('MANUAL');
    this.simulationTime.set(0);
    this.batteryLevel.set(100.0);
    this.updateArmsForwardKinematics();
  }

  // --- Built-in Pre-Programmed Experiments (A to H) ---

  public runExperiment(experimentId: 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G' | 'H'): void {
    switch (experimentId) {
      case 'A': // Manual Driving
        this.operatingMode.set('MANUAL');
        this.activeTaskName.set('Experiment A: Manual Driving');
        this.taskStepDescription.set('Dead-man drive active. Use W/A/S/D or buttons to steer through lab obstacle course.');
        break;
      case 'B': // Arm Kinematics
        this.operatingMode.set('ARM_CONTROL');
        this.activeTaskName.set('Experiment B: 5-DOF Arm Kinematics');
        this.taskStepDescription.set('Sweeping shoulder and elbow joints through forward workspace envelope.');
        this.setArmJointAngle(false, 0, -0.4);
        this.setArmJointAngle(false, 1, 0.8);
        this.setArmJointAngle(false, 2, -0.6);
        this.setArmJointAngle(false, 3, 0.2);
        break;
      case 'C': // Inverse Kinematics
        this.operatingMode.set('ARM_CONTROL');
        this.activeTaskName.set('Experiment C: Inverse Kinematics (CCD Solver)');
        this.taskStepDescription.set('Solving 3D target position (X=0.25, Y=0.22, Z=0.38) in chassis frame.');
        this.solveIKTarget(true, { x: 0.25, y: 0.22, z: 0.38 });
        break;
      case 'D': // Pick & Place Autonomous Manipulation
        this.runExperimentPickAndPlace();
        break;
      case 'E': // Autonomous Navigation A*
        this.activeTaskName.set('Experiment E: A* Autonomous Navigation');
        this.taskStepDescription.set('Planning collision-free path to Workbench coordinates (1.2, 0.8)...');
        this.planAndExecuteNavigation(1.2, 0.8);
        break;
      case 'F': // Sensor Testing
        this.activeTaskName.set('Experiment F: Sensor Range Geometry');
        this.taskStepDescription.set('Rotating base to sweep 6 ultrasonic transducers across obstacle fields.');
        this.commandHeadingDelta(1.57);
        break;
      case 'G': // Battery Consumption
        this.activeTaskName.set('Experiment G: Power Telemetry Profiling');
        this.taskStepDescription.set('Measuring battery Wh discharge rate under heavy servo manipulation load.');
        this.setArmJointAngle(false, 1, 1.2);
        this.setArmJointAngle(true, 1, 1.2);
        break;
      case 'H': // Emergency Stop Verification
        this.activeTaskName.set('Experiment H: Safety Interlock E-Stop');
        this.taskStepDescription.set('Injecting safety fault: Emergency Stop triggered. Motion frozen.');
        this.triggerEmergencyStop();
        break;
    }
  }

  public runExperimentPickAndPlace(): void {
    this.operatingMode.set('TASK_EXECUTION');
    this.activeTaskName.set('Experiment D: Autonomous Pick-and-Place');
    this.taskProgress.set(10);
    this.taskStepDescription.set('1/7: Aligning base facing copper cargo box...');

    // 1. Position robot near box
    this.pose.update((p) => ({ ...p, x: 0.1, y: 0.1, heading: 0.45 }));

    setTimeout(() => {
      this.taskProgress.set(25);
      this.taskStepDescription.set('2/7: Opening left gripper and extending arm to approach pose...');
      this.setGripperAperture(false, 0.9);
      this.setArmJointAngle(false, 0, 0.35);
      this.setArmJointAngle(false, 1, 0.45);
      this.setArmJointAngle(false, 2, -0.4);
    }, 1200);

    setTimeout(() => {
      this.taskProgress.set(45);
      this.taskStepDescription.set('3/7: Reaching down to cargo cube altitude...');
      this.setArmJointAngle(false, 1, 0.2);
      this.setArmJointAngle(false, 2, -0.15);
      this.setArmJointAngle(false, 3, -0.1);
    }, 2400);

    setTimeout(() => {
      this.taskProgress.set(60);
      this.taskStepDescription.set('4/7: Closing gripper; verifying contact sensor grasp...');
      this.setGripperAperture(false, 0.1);
      // Manually attach box_copper to left arm
      this.leftArm.update((a) => ({ ...a, gripperHolding: 'box_copper' }));
      this.envObjects.update((objs) =>
        objs.map((o) => (o.id === 'box_copper' ? { ...o, isAttached: true } : o))
      );
    }, 3600);

    setTimeout(() => {
      this.taskProgress.set(75);
      this.taskStepDescription.set('5/7: Lifting payload to secure transit height (0.42m)...');
      this.setArmJointAngle(false, 1, 0.85);
      this.setArmJointAngle(false, 2, -0.8);
      this.head.update((h) => ({ ...h, expression: 'HAPPY', tilt: -0.2 }));
    }, 4800);

    setTimeout(() => {
      this.taskProgress.set(90);
      this.taskStepDescription.set('6/7: Lowering payload to workbench and opening gripper...');
      this.setArmJointAngle(false, 1, 0.3);
      this.setGripperAperture(false, 0.9);
      // Release box at table location
      this.leftArm.update((a) => ({ ...a, gripperHolding: null }));
      this.envObjects.update((objs) =>
        objs.map((o) =>
          o.id === 'box_copper'
            ? { ...o, isAttached: false, position: { x: 1.4, y: 0.77, z: 1.1 } }
            : o
        )
      );
    }, 6200);

    setTimeout(() => {
      this.taskProgress.set(100);
      this.taskStepDescription.set('7/7: Grasp completed. Returning arm to nominal stow pose.');
      this.resetArmsToStow();
      this.operatingMode.set('IDLE');
    }, 7600);
  }

  // Keyboard handlers
  private handleKeyDown = (e: KeyboardEvent): void => {
    // Avoid capturing inputs when typing in textarea or inputs
    const target = e.target as HTMLElement;
    if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) return;

    if (e.key === 'w' || e.key === 'W' || e.key === 'ArrowUp') {
      this.keyForward = true;
      this.diffDrive.refreshCommand();
    } else if (e.key === 's' || e.key === 'S' || e.key === 'ArrowDown') {
      this.keyBackward = true;
      this.diffDrive.refreshCommand();
    } else if (e.key === 'a' || e.key === 'A' || e.key === 'ArrowLeft') {
      this.keyLeft = true;
      this.diffDrive.refreshCommand();
    } else if (e.key === 'd' || e.key === 'D' || e.key === 'ArrowRight') {
      this.keyRight = true;
      this.diffDrive.refreshCommand();
    } else if (e.key === ' ') {
      this.commandStop();
    }
  };

  private handleKeyUp = (e: KeyboardEvent): void => {
    if (e.key === 'w' || e.key === 'W' || e.key === 'ArrowUp') this.keyForward = false;
    else if (e.key === 's' || e.key === 'S' || e.key === 'ArrowDown') this.keyBackward = false;
    else if (e.key === 'a' || e.key === 'A' || e.key === 'ArrowLeft') this.keyLeft = false;
    else if (e.key === 'd' || e.key === 'D' || e.key === 'ArrowRight') this.keyRight = false;
  };
}
