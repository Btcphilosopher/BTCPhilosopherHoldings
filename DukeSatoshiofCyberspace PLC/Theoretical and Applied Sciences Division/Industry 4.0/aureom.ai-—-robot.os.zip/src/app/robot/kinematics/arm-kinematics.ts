/**
 * Robotic Arm Kinematics:
 * - 4x4 Homogeneous Transformation Matrices
 * - Forward Kinematics (FK)
 * - Inverse Kinematics (CCD & Damped Jacobian with Joint Limits & Reachability)
 * - Trajectory Planning (Quintic polynomial smooth interpolation)
 */

import { Vector3D, RobotPose } from '../models/robot.types';

export interface ArmLinkDimensions {
  shoulderOffsetX: number; // side offset from robot center (e.g. +0.22 for right, -0.22 for left)
  shoulderOffsetY: number; // height from ground (e.g. 0.32m)
  shoulderOffsetZ: number; // forward offset (e.g. 0.05m)
  upperArmLength: number;  // L1 (0.18m)
  forearmLength: number;   // L2 (0.16m)
  wristLength: number;     // L3 to gripper tip (0.12m)
}

export const DEFAULT_ARM_DIMENSIONS: { left: ArmLinkDimensions; right: ArmLinkDimensions } = {
  left: {
    shoulderOffsetX: -0.21,
    shoulderOffsetY: 0.34,
    shoulderOffsetZ: 0.04,
    upperArmLength: 0.18,
    forearmLength: 0.16,
    wristLength: 0.12,
  },
  right: {
    shoulderOffsetX: 0.21,
    shoulderOffsetY: 0.34,
    shoulderOffsetZ: 0.04,
    upperArmLength: 0.18,
    forearmLength: 0.16,
    wristLength: 0.12,
  },
};

export class Matrix4x4 {
  public m: number[] = [
    1, 0, 0, 0,
    0, 1, 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1
  ];

  constructor(elements?: number[]) {
    if (elements && elements.length === 16) {
      this.m = [...elements];
    }
  }

  public static identity(): Matrix4x4 {
    return new Matrix4x4();
  }

  public static translation(x: number, y: number, z: number): Matrix4x4 {
    const mat = new Matrix4x4();
    mat.m[3] = x;
    mat.m[7] = y;
    mat.m[11] = z;
    return mat;
  }

  public static rotationX(rad: number): Matrix4x4 {
    const c = Math.cos(rad);
    const s = Math.sin(rad);
    return new Matrix4x4([
      1, 0,  0, 0,
      0, c, -s, 0,
      0, s,  c, 0,
      0, 0,  0, 1
    ]);
  }

  public static rotationY(rad: number): Matrix4x4 {
    const c = Math.cos(rad);
    const s = Math.sin(rad);
    return new Matrix4x4([
       c, 0, s, 0,
       0, 1, 0, 0,
      -s, 0, c, 0,
       0, 0, 0, 1
    ]);
  }

  public static rotationZ(rad: number): Matrix4x4 {
    const c = Math.cos(rad);
    const s = Math.sin(rad);
    return new Matrix4x4([
      c, -s, 0, 0,
      s,  c, 0, 0,
      0,  0, 1, 0,
      0,  0, 0, 1
    ]);
  }

  public multiply(other: Matrix4x4): Matrix4x4 {
    const r = new Array(16).fill(0);
    const a = this.m;
    const b = other.m;

    for (let row = 0; row < 4; row++) {
      for (let col = 0; col < 4; col++) {
        r[row * 4 + col] =
          a[row * 4 + 0] * b[0 * 4 + col] +
          a[row * 4 + 1] * b[1 * 4 + col] +
          a[row * 4 + 2] * b[2 * 4 + col] +
          a[row * 4 + 3] * b[3 * 4 + col];
      }
    }
    return new Matrix4x4(r);
  }

  public transformPoint(p: Vector3D): Vector3D {
    const a = this.m;
    return {
      x: a[0] * p.x + a[1] * p.y + a[2] * p.z + a[3],
      y: a[4] * p.x + a[5] * p.y + a[6] * p.z + a[7],
      z: a[8] * p.x + a[9] * p.y + a[10] * p.z + a[11],
    };
  }

  public getTranslation(): Vector3D {
    return { x: this.m[3], y: this.m[7], z: this.m[11] };
  }
}

export class ArmKinematicsSolver {
  private dims: ArmLinkDimensions;
  private isRight: boolean;

  constructor(isRight = false) {
    this.isRight = isRight;
    this.dims = isRight ? DEFAULT_ARM_DIMENSIONS.right : DEFAULT_ARM_DIMENSIONS.left;
  }

  /**
   * Calculate Forward Kinematics (FK) for all joints.
   * Returns positions of: Shoulder Base, Shoulder Joint, Elbow Joint, Wrist, End-Effector Tip
   * in the Robot Body/Chassis coordinate frame.
   */
  public forwardKinematicsChassis(angles: number[]): {
    shoulder: Vector3D;
    elbow: Vector3D;
    wrist: Vector3D;
    endEffector: Vector3D;
    transformMatrix: Matrix4x4;
  } {
    const [q0, q1, q2, q3] = angles; // yaw, pitch, pitch, pitch
    const d = this.dims;

    // Base shoulder mount
    const tBase = Matrix4x4.translation(d.shoulderOffsetX, d.shoulderOffsetY, d.shoulderOffsetZ);

    // Shoulder Pan (Yaw - rotation around Y)
    const tYaw = tBase.multiply(Matrix4x4.rotationY(q0));
    const shoulderPos = tYaw.getTranslation();

    // Shoulder Pitch (Elevation - rotation around X)
    const tElevation = tYaw.multiply(Matrix4x4.rotationX(q1));

    // Move along upper arm length (along Z-axis forward or Y depending on zero pose)
    // Here: 0 pose reaches forward along +Z, elbow down
    const tElbow = tElevation.multiply(Matrix4x4.translation(0, 0, d.upperArmLength));
    const elbowPos = tElbow.getTranslation();

    // Elbow Flexion (rotation around X)
    const tForearm = tElbow.multiply(Matrix4x4.rotationX(q2));
    const tWrist = tForearm.multiply(Matrix4x4.translation(0, 0, d.forearmLength));
    const wristPos = tWrist.getTranslation();

    // Wrist Pitch
    const tWristPitch = tWrist.multiply(Matrix4x4.rotationX(q3));
    const tTip = tWristPitch.multiply(Matrix4x4.translation(0, 0, d.wristLength));
    const tipPos = tTip.getTranslation();

    return {
      shoulder: shoulderPos,
      elbow: elbowPos,
      wrist: wristPos,
      endEffector: tipPos,
      transformMatrix: tTip,
    };
  }

  /**
   * Convert end-effector position from Chassis frame to World frame using Robot Pose.
   * Robot heading theta rotates around world Y axis.
   */
  public chassisToWorld(pChassis: Vector3D, pose: RobotPose): Vector3D {
    // In our 3D world: X is right, Y is up, Z is depth
    // Pose: x = world X, y = world Z, heading = rotation around Y
    const cosH = Math.cos(pose.heading);
    const sinH = Math.sin(pose.heading);

    const worldX = pose.x + (pChassis.x * cosH + pChassis.z * sinH);
    const worldY = pChassis.y; // height from ground
    const worldZ = pose.y + (-pChassis.x * sinH + pChassis.z * cosH);

    return { x: worldX, y: worldY, z: worldZ };
  }

  /**
   * Convert world coordinates to robot chassis coordinates.
   */
  public worldToChassis(pWorld: Vector3D, pose: RobotPose): Vector3D {
    const dx = pWorld.x - pose.x;
    const dz = pWorld.z - pose.y;
    const cosH = Math.cos(pose.heading);
    const sinH = Math.sin(pose.heading);

    return {
      x: dx * cosH - dz * sinH,
      y: pWorld.y,
      z: dx * sinH + dz * cosH,
    };
  }

  /**
   * Maximum reach of the arm from shoulder base.
   */
  public getMaxReach(): number {
    return this.dims.upperArmLength + this.dims.forearmLength + this.dims.wristLength;
  }

  /**
   * Check if target point in chassis frame is within reachable workspace envelope.
   */
  public isReachable(targetChassis: Vector3D): boolean {
    const d = this.dims;
    const dx = targetChassis.x - d.shoulderOffsetX;
    const dy = targetChassis.y - d.shoulderOffsetY;
    const dz = targetChassis.z - d.shoulderOffsetZ;
    const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
    const minReach = 0.08;
    const maxReach = this.getMaxReach() * 0.98;
    return dist >= minReach && dist <= maxReach;
  }

  /**
   * Inverse Kinematics solver using Cyclic Coordinate Descent (CCD)
   * with strict joint angle limits and convergence tolerance.
   */
  public solveIK(
    targetChassis: Vector3D,
    currentAngles: number[],
    limits: { min: number; max: number }[],
    maxIterations = 30,
    tolerance = 0.005
  ): { solvedAngles: number[]; reachable: boolean; finalDistance: number } {
    const angles = [...currentAngles];
    const numJoints = 4; // yaw, shoulder pitch, elbow pitch, wrist pitch

    if (!this.isReachable(targetChassis)) {
      return { solvedAngles: angles, reachable: false, finalDistance: 999 };
    }

    for (let iter = 0; iter < maxIterations; iter++) {
      const fk = this.forwardKinematicsChassis(angles);
      const ee = fk.endEffector;
      const dist = Math.hypot(ee.x - targetChassis.x, ee.y - targetChassis.y, ee.z - targetChassis.z);

      if (dist < tolerance) {
        return { solvedAngles: angles, reachable: true, finalDistance: dist };
      }

      // Iterate backwards from wrist to shoulder
      for (let j = numJoints - 1; j >= 0; j--) {
        // Numerical gradient / CCD step
        const delta = 0.005;
        const testAnglesPlus = [...angles];
        testAnglesPlus[j] += delta;
        const fkPlus = this.forwardKinematicsChassis(testAnglesPlus);
        const distPlus = Math.hypot(
          fkPlus.endEffector.x - targetChassis.x,
          fkPlus.endEffector.y - targetChassis.y,
          fkPlus.endEffector.z - targetChassis.z
        );

        const testAnglesMinus = [...angles];
        testAnglesMinus[j] -= delta;
        const fkMinus = this.forwardKinematicsChassis(testAnglesMinus);
        const distMinus = Math.hypot(
          fkMinus.endEffector.x - targetChassis.x,
          fkMinus.endEffector.y - targetChassis.y,
          fkMinus.endEffector.z - targetChassis.z
        );

        const gradient = (distPlus - distMinus) / (2 * delta);
        const stepSize = 0.45;
        angles[j] -= gradient * stepSize;

        // Clamp to joint limits
        angles[j] = Math.max(limits[j].min, Math.min(limits[j].max, angles[j]));
      }
    }

    const finalFk = this.forwardKinematicsChassis(angles);
    const finalDist = Math.hypot(
      finalFk.endEffector.x - targetChassis.x,
      finalFk.endEffector.y - targetChassis.y,
      finalFk.endEffector.z - targetChassis.z
    );

    return {
      solvedAngles: angles,
      reachable: finalDist < 0.03,
      finalDistance: finalDist,
    };
  }

  /**
   * Quintic polynomial smooth trajectory interpolation:
   * s(t) = 10*t^3 - 15*t^4 + 6*t^5 (ensures zero velocity and acceleration at start & end)
   */
  public static interpolateJoints(
    startAngles: number[],
    endAngles: number[],
    progress: number // 0.0 to 1.0
  ): number[] {
    const t = Math.max(0, Math.min(1, progress));
    const smoothT = 10 * Math.pow(t, 3) - 15 * Math.pow(t, 4) + 6 * Math.pow(t, 5);
    return startAngles.map((start, i) => start + (endAngles[i] - start) * smoothT);
  }
}
