/**
 * Differential-Drive Kinematics Engine
 * Implements non-holonomic mobile robot motion equations:
 * v = (v_R + v_L) / 2
 * omega = (v_R - v_L) / b
 * with track slip modeling, acceleration limiting, and dead-man timeout.
 */

import { RobotPose } from '../models/robot.types';

export interface DifferentialDriveConfig {
  trackSeparation: number; // b in meters (e.g. 0.42m)
  maxLinearVelocity: number; // m/s (e.g. 1.2 m/s)
  maxAngularVelocity: number; // rad/s (e.g. 2.0 rad/s)
  maxAcceleration: number; // m/s^2 (e.g. 1.8 m/s^2)
  trackSlipCoefficient: number; // 0.0 = no slip, 0.15 = 15% slip
  deadManTimeoutMs: number; // ms to auto-stop if no command refreshed
}

export const DEFAULT_DIFF_DRIVE_CONFIG: DifferentialDriveConfig = {
  trackSeparation: 0.42,
  maxLinearVelocity: 1.2,
  maxAngularVelocity: 2.2,
  maxAcceleration: 2.0,
  trackSlipCoefficient: 0.05,
  deadManTimeoutMs: 400,
};

export class DifferentialDriveKinematics {
  private config: DifferentialDriveConfig;
  private lastCommandTime = Date.now();
  private isDeadManActive = false;
  private trackSlipEnabled = true;

  constructor(config: Partial<DifferentialDriveConfig> = {}) {
    this.config = { ...DEFAULT_DIFF_DRIVE_CONFIG, ...config };
  }

  public setTrackSlipEnabled(enabled: boolean): void {
    this.trackSlipEnabled = enabled;
  }

  public getTrackSlipEnabled(): boolean {
    return this.trackSlipEnabled;
  }

  public setDeadManActive(active: boolean): void {
    this.isDeadManActive = active;
    if (active) {
      this.lastCommandTime = Date.now();
    }
  }

  public refreshCommand(): void {
    this.lastCommandTime = Date.now();
  }

  /**
   * Convert linear velocity v (m/s) and angular velocity omega (rad/s)
   * to left and right wheel speeds:
   * v_L = v - (omega * b) / 2
   * v_R = v + (omega * b) / 2
   */
  public twistToWheelSpeeds(v: number, omega: number): { vLeft: number; vRight: number } {
    const b = this.config.trackSeparation;
    // Clamp velocities
    const clampedV = Math.max(-this.config.maxLinearVelocity, Math.min(this.config.maxLinearVelocity, v));
    const clampedOmega = Math.max(-this.config.maxAngularVelocity, Math.min(this.config.maxAngularVelocity, omega));

    const vLeft = clampedV - (clampedOmega * b) / 2.0;
    const vRight = clampedV + (clampedOmega * b) / 2.0;

    return { vLeft, vRight };
  }

  /**
   * Forward kinematics from wheel speeds to body twist:
   * v = (v_R + v_L) / 2
   * omega = (v_R - v_L) / b
   */
  public wheelSpeedsToTwist(vLeft: number, vRight: number): { v: number; omega: number } {
    const b = this.config.trackSeparation;
    let actualVLeft = vLeft;
    let actualVRight = vRight;

    if (this.trackSlipEnabled) {
      const slipFactor = 1.0 - this.config.trackSlipCoefficient;
      actualVLeft *= slipFactor;
      actualVRight *= slipFactor;
    }

    const v = (actualVRight + actualVLeft) / 2.0;
    const omega = (actualVRight - actualVLeft) / b;

    return { v, omega };
  }

  /**
   * Integrate pose over dt seconds using Runge-Kutta / exact trigonometric integration:
   * dx = v * cos(heading + omega * dt / 2) * dt
   * dy = v * sin(heading + omega * dt / 2) * dt
   * dtheta = omega * dt
   */
  public integratePose(
    currentPose: RobotPose,
    targetV: number,
    targetOmega: number,
    dt: number
  ): RobotPose {
    const now = Date.now();

    // Check dead-man safety timeout
    let vCmd = targetV;
    let omegaCmd = targetOmega;
    if (this.isDeadManActive && now - this.lastCommandTime > this.config.deadManTimeoutMs) {
      vCmd = 0;
      omegaCmd = 0;
    }

    // Slew rate / acceleration limiting
    const maxDeltaV = this.config.maxAcceleration * dt;
    const vDiff = vCmd - currentPose.linearVelocity;
    const currentV = currentPose.linearVelocity + Math.sign(vDiff) * Math.min(Math.abs(vDiff), maxDeltaV);

    const maxDeltaOmega = this.config.maxAcceleration * 2.5 * dt;
    const omegaDiff = omegaCmd - currentPose.angularVelocity;
    const currentOmega = currentPose.angularVelocity + Math.sign(omegaDiff) * Math.min(Math.abs(omegaDiff), maxDeltaOmega);

    // Calculate wheel speeds
    const { vLeft, vRight } = this.twistToWheelSpeeds(currentV, currentOmega);
    const { v: effectiveV, omega: effectiveOmega } = this.wheelSpeedsToTwist(vLeft, vRight);

    // Heading update
    const midHeading = currentPose.heading + (effectiveOmega * dt) / 2.0;
    const newHeading = this.normalizeAngle(currentPose.heading + effectiveOmega * dt);

    // Position updates (in 2D ground plane: x = forward/world-X, y = world-Z)
    const newX = currentPose.x + effectiveV * Math.cos(midHeading) * dt;
    const newY = currentPose.y + effectiveV * Math.sin(midHeading) * dt;

    return {
      x: newX,
      y: newY,
      heading: newHeading,
      linearVelocity: effectiveV,
      angularVelocity: effectiveOmega,
      leftWheelSpeed: vLeft,
      rightWheelSpeed: vRight,
    };
  }

  private normalizeAngle(angle: number): number {
    while (angle > Math.PI) angle -= 2 * Math.PI;
    while (angle < -Math.PI) angle += 2 * Math.PI;
    return angle;
  }
}
