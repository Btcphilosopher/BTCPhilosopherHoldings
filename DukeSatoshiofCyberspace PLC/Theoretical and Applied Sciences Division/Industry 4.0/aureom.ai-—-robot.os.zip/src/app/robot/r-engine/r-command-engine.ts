/**
 * Interactive R Command Execution Engine
 * Evaluates R syntax commands (e.g. `robot$move_forward(0.5)`, `robot$left_arm$set_joint(2, 0.4)`)
 * and triggers simulation updates, logging output with standard R session semantics.
 */

export interface RConsoleOutput {
  id: string;
  timestamp: string;
  type: 'COMMAND' | 'OUTPUT' | 'WARNING' | 'ERROR';
  text: string;
}

export interface SimulationCommander {
  moveForward: (dist: number) => void;
  rotate: (rad: number) => void;
  stop: () => void;
  setHeadPan: (rad: number) => void;
  setHeadTilt: (rad: number) => void;
  setArmJoint: (isRight: boolean, jointIndex: number, rad: number) => void;
  setGripper: (isRight: boolean, aperture: number) => void;
  navigateTo: (x: number, y: number) => void;
  returnHome: () => void;
  emergencyStop: () => void;
  resetSimulation: () => void;
  runPickAndPlace: () => void;
  solveIKTarget: (isRight: boolean, x: number, y: number, z: number) => boolean;
}

export class RCommandEngine {
  private commander: SimulationCommander;
  private history: string[] = [];

  constructor(commander: SimulationCommander) {
    this.commander = commander;
  }

  public getHistory(): string[] {
    return [...this.history];
  }

  /**
   * Evaluates a line or block of R script code
   */
  public evaluate(rawInput: string): RConsoleOutput[] {
    const trimmed = rawInput.trim();
    if (!trimmed) return [];

    this.history.push(trimmed);
    const results: RConsoleOutput[] = [
      {
        id: Math.random().toString(36).substring(2, 9),
        timestamp: new Date().toLocaleTimeString(),
        type: 'COMMAND',
        text: `> ${trimmed}`,
      },
    ];

    const lines = trimmed.split('\n').map((l) => l.trim()).filter((l) => l && !l.startsWith('#'));

    for (const line of lines) {
      try {
        const out = this.parseAndRunLine(line);
        if (out) {
          results.push({
            id: Math.random().toString(36).substring(2, 9),
            timestamp: new Date().toLocaleTimeString(),
            type: 'OUTPUT',
            text: out,
          });
        }
      } catch (err: unknown) {
        results.push({
          id: Math.random().toString(36).substring(2, 9),
          timestamp: new Date().toLocaleTimeString(),
          type: 'ERROR',
          text: `Error in ${line} : ${(err as Error).message}`,
        });
      }
    }

    return results;
  }

  private parseAndRunLine(line: string): string {
    // Normalise syntax: allow robot$func(...) or robot.func(...)
    const norm = line.replace(/robot\./g, 'robot$');

    // 1. robot$stop()
    if (/^robot\$stop\(\s*\)$/.test(norm)) {
      this.commander.stop();
      return '[1] "Robot: Active drive motors halted. Velocity = 0.0 m/s"';
    }

    // 2. robot$move_forward(distance = 0.5)
    const moveMatch = norm.match(/^robot\$move_forward\((?:distance\s*=\s*)?([-\d.]+)(?:,\s*speed\s*=\s*([-\d.]+))?\)$/);
    if (moveMatch) {
      const dist = parseFloat(moveMatch[1]);
      this.commander.moveForward(dist);
      return `[1] "Robot: Dispatched differential forward trajectory d = ${dist.toFixed(2)} m"`;
    }

    // 3. robot$rotate(angle = 1.57)
    const rotMatch = norm.match(/^robot\$rotate\((?:angle\s*=\s*)?([-\d.]+)\)$/);
    if (rotMatch) {
      const angle = parseFloat(rotMatch[1]);
      this.commander.rotate(angle);
      return `[1] "Robot: Dispatched differential rotation heading delta = ${angle.toFixed(2)} rad"`;
    }

    // 4. robot$head$pan(angle = 0.4)
    const panMatch = norm.match(/^robot\$head\$pan\((?:angle\s*=\s*)?([-\d.]+)\)$/);
    if (panMatch) {
      const rad = parseFloat(panMatch[1]);
      this.commander.setHeadPan(rad);
      return `[1] "Head: Pan servo set to ${rad.toFixed(2)} rad (${((rad * 180) / Math.PI).toFixed(1)}°)"`;
    }

    // 5. robot$head$tilt(angle = -0.2)
    const tiltMatch = norm.match(/^robot\$head\$tilt\((?:angle\s*=\s*)?([-\d.]+)\)$/);
    if (tiltMatch) {
      const rad = parseFloat(tiltMatch[1]);
      this.commander.setHeadTilt(rad);
      return `[1] "Head: Tilt servo set to ${rad.toFixed(2)} rad (${((rad * 180) / Math.PI).toFixed(1)}°)"`;
    }

    // 6. robot$left_arm$set_joint(2, 0.6)
    const armJointMatch = norm.match(/^robot\$(left|right)_arm\$set_joint\((?:joint\s*=\s*)?(\d+),\s*(?:angle\s*=\s*)?([-\d.]+)\)$/);
    if (armJointMatch) {
      const isRight = armJointMatch[1] === 'right';
      const jointIdx = parseInt(armJointMatch[2], 10);
      const rad = parseFloat(armJointMatch[3]);
      this.commander.setArmJoint(isRight, jointIdx, rad);
      return `[1] "${isRight ? 'Right' : 'Left'} Arm: Joint ${jointIdx} commanded to ${rad.toFixed(3)} rad"`;
    }

    // 7. robot$left_arm$open_gripper() or close_gripper()
    const gripMatch = norm.match(/^robot\$(left|right)_arm\$(open|close)_gripper\(\)$/);
    if (gripMatch) {
      const isRight = gripMatch[1] === 'right';
      const isOpen = gripMatch[2] === 'open';
      this.commander.setGripper(isRight, isOpen ? 1.0 : 0.0);
      return `[1] "${isRight ? 'Right' : 'Left'} Gripper: ${isOpen ? 'Opened (1.0)' : 'Closed (0.0)'}"`;
    }

    // 8. robot$navigate_to(x = 2.0, y = 1.0)
    const navMatch = norm.match(/^robot\$navigate_to\((?:x\s*=\s*)?([-\d.]+),\s*(?:y\s*=\s*)?([-\d.]+)\)$/);
    if (navMatch) {
      const x = parseFloat(navMatch[1]);
      const y = parseFloat(navMatch[2]);
      this.commander.navigateTo(x, y);
      return `[1] "Navigation: A* planner computing optimal obstacle-free path to (${x.toFixed(2)}, ${y.toFixed(2)})"`;
    }

    // 9. robot$return_home()
    if (/^robot\$return_home\(\s*\)$/.test(norm)) {
      this.commander.returnHome();
      return '[1] "Navigation: Return to charging dock / home origin initiated."';
    }

    // 10. robot$emergency_stop()
    if (/^robot\$emergency_stop\(\s*\)$/.test(norm)) {
      this.commander.emergencyStop();
      return '[1] "CRITICAL SAFETY: Software Emergency Stop triggered. All motion inhibited."';
    }

    // 11. robot$task_pick_and_place()
    if (/^robot\$task_pick_and_place\(\s*\)$/.test(norm)) {
      this.commander.runPickAndPlace();
      return '[1] "Task Executor: Autonomous Pick-and-Place sequence launched."';
    }

    // 12. Help or diagnostics
    if (/^(help|info|status)\(\s*\)$/.test(norm)) {
      return `[1] "AUREOM.AI — ROBOT.OS Interactive R Session"
Commands supported:
  robot$move_forward(distance = 0.5)
  robot$rotate(angle = 1.57)
  robot$stop()
  robot$head$pan(angle = 0.4)
  robot$head$tilt(angle = -0.2)
  robot$left_arm$set_joint(joint = 2, angle = 0.6)
  robot$left_arm$open_gripper()
  robot$left_arm$close_gripper()
  robot$navigate_to(x = 2.0, y = 1.0)
  robot$return_home()
  robot$task_pick_and_place()
  robot$emergency_stop()`;
    }

    // Unrecognized fallback
    return `[1] "Executed statement: ${line}"`;
  }
}
