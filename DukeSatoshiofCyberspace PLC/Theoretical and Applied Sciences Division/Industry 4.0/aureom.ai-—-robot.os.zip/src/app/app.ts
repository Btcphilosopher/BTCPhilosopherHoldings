import { ChangeDetectionStrategy, Component, signal, ViewChild } from '@angular/core';
import { HeaderComponent } from './components/header/header';
import { ViewportComponent } from './components/viewport/viewport';
import { LeftPanelComponent } from './components/left-panel/left-panel';
import { RightPanelComponent } from './components/right-panel/right-panel';
import { BottomPanelComponent } from './components/bottom-panel/bottom-panel';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    HeaderComponent,
    ViewportComponent,
    LeftPanelComponent,
    RightPanelComponent,
    BottomPanelComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  @ViewChild(BottomPanelComponent)
  public bottomPanel!: BottomPanelComponent;

  public activeNavTab = signal<string>('SIMULATION');

  public onNavTabSelected(tab: string): void {
    this.activeNavTab.set(tab);
    if (tab === 'R_CONSOLE') {
      this.bottomPanel?.activeTab.set('R_CONSOLE');
    } else if (tab === 'EXPERIMENTS') {
      this.bottomPanel?.activeTab.set('EXPERIMENTS');
    } else if (tab === 'R_CODEBASE') {
      this.bottomPanel?.activeTab.set('R_CODEBASE');
    } else if (tab === 'SIMULATION') {
      this.bottomPanel?.activeTab.set('TELEMETRY');
    }
  }
}
