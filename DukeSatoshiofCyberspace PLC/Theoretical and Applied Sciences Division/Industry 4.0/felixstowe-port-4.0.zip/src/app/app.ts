import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { HeaderNavComponent } from './components/header-nav';
import { ObjectInspectorComponent } from './components/object-inspector';
import { AiPortPlannerView } from './components/views/ai-port-planner-view';
import { ControlRoomView } from './components/views/control-room-view';
import { CustomersDocumentsView } from './components/views/customers-documents-view';
import { DigitalTwin3dView } from './components/views/digital-twin-3d-view';
import { EnergyEmissionsView } from './components/views/energy-emissions-view';
import { FleetEquipmentView } from './components/views/fleet-equipment-view';
import { InlandOptimisationView } from './components/views/inland-optimisation-view';
import { Port2dMapView } from './components/views/port-2d-map-view';
import { RailOsView } from './components/views/rail-os-view';
import { ReeferSpecialView } from './components/views/reefer-special-view';
import { RoadGatesView } from './components/views/road-gates-view';
import { SimulationScenariosView } from './components/views/simulation-scenarios-view';
import { VesselsBerthsView } from './components/views/vessels-berths-view';
import { YardOsView } from './components/views/yard-os-view';
import { PortData } from './services/port-data';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    HeaderNavComponent,
    ObjectInspectorComponent,
    ControlRoomView,
    DigitalTwin3dView,
    Port2dMapView,
    VesselsBerthsView,
    YardOsView,
    FleetEquipmentView,
    RailOsView,
    RoadGatesView,
    InlandOptimisationView,
    CustomersDocumentsView,
    ReeferSpecialView,
    EnergyEmissionsView,
    SimulationScenariosView,
    AiPortPlannerView,
  ],
  template: `
    <div class="min-h-screen bg-[#0B101D] text-slate-100 flex flex-col font-sans">
      <!-- Header Navigation Bar -->
      <app-header-nav />

      <!-- Main Operational Viewport Container -->
      <main class="flex-1 p-4 md:p-6 max-w-[1600px] w-full mx-auto">
        @switch (portData.activeView()) {
          @case ('CONTROL_ROOM') {
            <app-control-room-view />
          }
          @case ('DIGITAL_TWIN_3D') {
            <app-digital-twin-3d-view />
          }
          @case ('PORT_2D_MAP') {
            <app-port-2d-map-view />
          }
          @case ('VESSELS_BERTHS') {
            <app-vessels-berths-view />
          }
          @case ('YARD_OS') {
            <app-yard-os-view />
          }
          @case ('FLEET_EQUIPMENT') {
            <app-fleet-equipment-view />
          }
          @case ('RAIL_OS') {
            <app-rail-os-view />
          }
          @case ('ROAD_GATES') {
            <app-road-gates-view />
          }
          @case ('INLAND_OPTIMISATION') {
            <app-inland-optimisation-view />
          }
          @case ('CUSTOMERS_DOCUMENTS') {
            <app-customers-documents-view />
          }
          @case ('REEFER_SPECIAL') {
            <app-reefer-special-view />
          }
          @case ('ENERGY_EMISSIONS') {
            <app-energy-emissions-view />
          }
          @case ('SIMULATION_SCENARIOS') {
            <app-simulation-scenarios-view />
          }
          @case ('AI_PORT_PLANNER') {
            <app-ai-port-planner-view />
          }
        }
      </main>

      <!-- Global Object Telemetry Inspector Drawer -->
      <app-object-inspector />
    </div>
  `,
})
export class App {
  readonly portData = inject(PortData);
}
