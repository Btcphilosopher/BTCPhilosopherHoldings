import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { PortData } from '../../services/port-data';

@Component({
  selector: 'app-vessels-berths-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Top Title -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div>
          <h2 class="text-sm font-mono font-bold uppercase tracking-wider text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">directions_boat</mat-icon>
            Vessel Traffic Control, Berth Planning & Quay Crane Optimiser
          </h2>
          <p class="text-xs text-slate-400 mt-0.5 font-sans">
            Deep-water berth allocation engine for Trinity Terminal and Berths 8 & 9
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <button (click)="recalculatePlan()" class="px-3 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-bold transition-colors flex items-center gap-1">
            <mat-icon class="!w-4 !h-4 !text-base">autorenew</mat-icon>
            Recalculate Berth Schedule
          </button>
        </div>
      </div>

      <!-- Gantt Berth Planner (Visual Timeline) -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4 shadow-sm font-mono">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2">
            <mat-icon class="text-cyan-400">event_note</mat-icon>
            Visual Berth Allocation Timeline (Current Plan vs Optimised Plan)
          </h3>
          <span class="text-xs text-slate-400">48-Hour Horizon</span>
        </div>

        <div class="space-y-2 text-xs">
          @for (berth of portData.berths(); track berth.id) {
            <div class="grid grid-cols-12 gap-2 items-center bg-slate-950 p-2 rounded border border-slate-800/80">
              <div class="col-span-3 font-bold text-slate-200 truncate">
                {{ berth.name }}
                <div class="text-[10px] text-slate-500">{{ berth.lengthM }}m · {{ berth.maxDraftM }}m draft</div>
              </div>
              <div class="col-span-9 relative h-8 bg-slate-900 rounded overflow-hidden border border-slate-800 flex items-center">
                @if (berth.currentVesselId) {
                  <div (click)="portData.inspectObject('BERTH', berth.id, berth)" class="absolute left-2 w-3/4 h-6 rounded bg-gradient-to-r from-cyan-600 to-blue-600 border border-cyan-400/80 px-2 flex items-center justify-between text-white text-[11px] font-bold cursor-pointer hover:opacity-90 shadow-sm">
                    <span class="truncate">{{ berth.currentVesselId }} · WORKING</span>
                    <span>{{ berth.assignedCranes.length }} QC</span>
                  </div>
                } @else {
                  <span class="text-[10px] text-slate-600 ml-4">BERTH AVAILABLE</span>
                }
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Crane Allocation Engine Curve Demo -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono">
        <!-- Quay Crane Diminishing Returns Model -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="border-b border-slate-800 pb-2">
            <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2">
              <mat-icon class="text-amber-400">show_chart</mat-icon>
              Quay Crane Density Optimiser (Diminishing Returns Curve)
            </h3>
            <p class="text-[11px] text-slate-400 font-sans mt-0.5">Calculates optimal crane allocation for Mega Vessel RQ-MSC-SYNTH-24000</p>
          </div>

          <div class="space-y-3">
            <div class="bg-slate-950 p-3 rounded border border-slate-800 space-y-2 text-xs">
              <div class="flex justify-between items-center">
                <span class="text-slate-300 font-bold">PLAN A (4 Cranes):</span>
                <span class="text-amber-400 font-bold">5.8 Hours Completion</span>
              </div>
              <div class="w-full bg-slate-800 h-2 rounded overflow-hidden">
                <div class="bg-amber-500 h-full w-[85%]"></div>
              </div>
            </div>

            <div class="bg-slate-950 p-3 rounded border border-slate-800 space-y-2 text-xs">
              <div class="flex justify-between items-center">
                <span class="text-slate-300 font-bold">PLAN B (6 Cranes):</span>
                <span class="text-cyan-400 font-bold">4.1 Hours Completion</span>
              </div>
              <div class="w-full bg-slate-800 h-2 rounded overflow-hidden">
                <div class="bg-cyan-500 h-full w-[60%]"></div>
              </div>
            </div>

            <div class="bg-slate-950 p-3 rounded border border-emerald-800 bg-emerald-950/20 space-y-2 text-xs">
              <div class="flex justify-between items-center">
                <span class="text-emerald-300 font-bold">PLAN C (8 Cranes - OPTIMAL):</span>
                <span class="text-emerald-400 font-bold">3.6 Hours Completion</span>
              </div>
              <div class="w-full bg-slate-800 h-2 rounded overflow-hidden">
                <div class="bg-emerald-400 h-full w-[40%]"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Vessel Arrival Simulator Inputs -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="border-b border-slate-800 pb-2">
            <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2">
              <mat-icon class="text-cyan-400">tune</mat-icon>
              Vessel Arrival Simulator Parameters
            </h3>
            <p class="text-[11px] text-slate-400 font-sans mt-0.5">Simulate tidal constraints, weather delays & cargo volume spikes</p>
          </div>

          <div class="space-y-3 text-xs">
            <div>
              <label class="text-slate-400 mb-1 block">Tidal Window Constraint (Draft Limit)</label>
              <select class="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200">
                <option>Normal High Tide (+16.5m Draft Window)</option>
                <option>Neap Tide (+14.2m Draft Window - Deepwater restricted)</option>
              </select>
            </div>

            <div>
              <label class="text-slate-400 mb-1 block">Weather & Wind Conditions</label>
              <select class="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200">
                <option>Clear Calm (<15 knots wind)</option>
                <option>Gale Force Warning (>35 knots wind - Crane shutdown risk)</option>
              </select>
            </div>

            <div class="pt-2">
              <button (click)="recalculatePlan()" class="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded font-bold uppercase transition-colors">
                Run Simulation & Update Schedule
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Vessel Control List Table -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4 font-mono shadow-sm">
        <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
          <mat-icon class="text-cyan-400">list_alt</mat-icon>
          Active & Approaching Vessel Roster
        </h3>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs text-slate-300">
            <thead class="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th class="p-2.5">Vessel / IMO</th>
                <th class="p-2.5">Operator</th>
                <th class="p-2.5">Voyage</th>
                <th class="p-2.5">ETA / ETD</th>
                <th class="p-2.5">TEU Import/Export</th>
                <th class="p-2.5">Berth</th>
                <th class="p-2.5">Status</th>
                <th class="p-2.5">Progress</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (v of portData.vessels(); track v.id) {
                <tr (click)="portData.inspectObject('VESSEL', v.id, v)" class="hover:bg-slate-800/50 cursor-pointer transition-colors">
                  <td class="p-2.5 font-bold text-slate-100">
                    {{ v.name }}
                    <div class="text-[10px] text-slate-500 font-normal">{{ v.imo }} · {{ v.lengthM }}m</div>
                  </td>
                  <td class="p-2.5 text-cyan-400 font-semibold">{{ v.operator }}</td>
                  <td class="p-2.5">{{ v.voyage }}</td>
                  <td class="p-2.5 text-[11px]">
                    <div>ETA: {{ v.eta.substring(11, 16) }}</div>
                    <div class="text-slate-500">ETD: {{ v.etd.substring(11, 16) }}</div>
                  </td>
                  <td class="p-2.5">
                    <span class="text-emerald-400">+{{ v.importTeu }}</span> /
                    <span class="text-amber-400">-{{ v.exportTeu }}</span>
                  </td>
                  <td class="p-2.5 font-bold text-amber-300">{{ v.berthId || 'ANCHOR' }}</td>
                  <td class="p-2.5 font-bold" [class.text-emerald-400]="v.status === 'WORKING'" [class.text-cyan-400]="v.status === 'APPROACHING'">
                    {{ v.status }}
                  </td>
                  <td class="p-2.5">
                    <div class="w-24 bg-slate-800 h-2 rounded overflow-hidden">
                      <div class="bg-cyan-400 h-full" [style.width.%]="v.progressPercent"></div>
                    </div>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class VesselsBerthsView {
  readonly portData = inject(PortData);
  readonly planCalculated = signal(false);

  recalculatePlan() {
    this.planCalculated.set(true);
    this.portData.refreshAllData();
  }
}
