import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { PortData } from '../../services/port-data';

@Component({
  selector: 'app-simulation-scenarios-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono">
      <!-- Title -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
        <div>
          <h2 class="text-sm font-bold uppercase tracking-wider text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">science</mat-icon>
            Simulation Scenario Lab & Interactive What-If Engine
          </h2>
          <p class="text-xs text-slate-400 mt-0.5 font-sans">
            Stress-test port resilience against operational shocks and capacity variations
          </p>
        </div>
      </div>

      <!-- Preset Scenarios -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div (click)="run('MEGA_VESSEL')" class="bg-slate-900/80 border border-slate-800 hover:border-cyan-500 p-4 rounded-xl cursor-pointer transition-colors space-y-2">
          <div class="flex items-center gap-2 text-cyan-400 font-bold text-xs uppercase">
            <mat-icon>directions_boat</mat-icon>
            24,000 TEU Mega Vessel Arrival
          </div>
          <p class="text-xs font-sans text-slate-300">Simulate arrival of RQ-MSC-SYNTH-24000 at Berth 9 with 8 quay cranes.</p>
        </div>

        <div (click)="run('PORT_BOTTLENECK')" class="bg-slate-900/80 border border-slate-800 hover:border-amber-500 p-4 rounded-xl cursor-pointer transition-colors space-y-2">
          <div class="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase">
            <mat-icon>warning</mat-icon>
            Yard Saturation Surge (89%)
          </div>
          <p class="text-xs font-sans text-slate-300">Surge yard stack density and calculate rail shift re-balancing plan.</p>
        </div>

        <div (click)="run('CRANE_FAILURE')" class="bg-slate-900/80 border border-slate-800 hover:border-rose-500 p-4 rounded-xl cursor-pointer transition-colors space-y-2">
          <div class="flex items-center gap-2 text-rose-400 font-bold text-xs uppercase">
            <mat-icon>report_problem</mat-icon>
            3-Crane Drive Outage
          </div>
          <p class="text-xs font-sans text-slate-300">Remove QC-01, QC-02, QC-03 at Trinity Berth 1 and recalculate completion hours.</p>
        </div>
      </div>

      <!-- Interactive What-If Sliders -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
          <mat-icon class="text-cyan-400">sliders</mat-icon>
          Interactive What-If Capacity Parameter Controls
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
          <div>
            <div class="flex justify-between mb-1 text-slate-300 font-bold">
              <span>Active Quay Cranes</span>
              <span class="text-cyan-400 font-mono">{{ craneCount() }} Cranes</span>
            </div>
            <input type="range" min="10" max="28" [value]="craneCount()" (input)="updateCrane($event)" class="w-full accent-cyan-500">
          </div>

          <div>
            <div class="flex justify-between mb-1 text-slate-300 font-bold">
              <span>Yard Capacity Cap</span>
              <span class="text-amber-400 font-mono">{{ yardCap() }}% Utilisation</span>
            </div>
            <input type="range" min="50" max="95" [value]="yardCap()" (input)="updateYard($event)" class="w-full accent-amber-500">
          </div>
        </div>

        <!-- Calculated What-If Output -->
        <div class="bg-slate-950 p-4 rounded border border-slate-800 grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div>
            <span class="text-slate-400 text-[10px]">PREDICTED THROUGHPUT</span>
            <div class="text-emerald-400 font-bold text-base mt-0.5">{{ Math.round(craneCount() * 12.2) }} TEU / hr</div>
          </div>
          <div>
            <span class="text-slate-400 text-[10px]">PREDICTED TURNAROUND</span>
            <div class="text-cyan-300 font-bold text-base mt-0.5">{{ (38.5 - craneCount() * 0.8).toFixed(1) }} Hours</div>
          </div>
          <div>
            <span class="text-slate-400 text-[10px]">CONGESTION RISK</span>
            <div class="font-bold text-base mt-0.5" [class.text-emerald-400]="yardCap() < 75" [class.text-amber-400]="yardCap() >= 75 && yardCap() < 85" [class.text-rose-400]="yardCap() >= 85">
              {{ yardCap() >= 85 ? 'HIGH RISK' : yardCap() >= 75 ? 'MODERATE' : 'LOW' }}
            </div>
          </div>
          <div>
            <span class="text-slate-400 text-[10px]">ESTIMATED 24H COST</span>
            <div class="text-amber-300 font-bold text-base mt-0.5">£{{ Math.round(180000 + craneCount() * 2400).toLocaleString() }}</div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class SimulationScenariosView {
  readonly portData = inject(PortData);
  readonly Math = Math;
  readonly craneCount = signal(21);
  readonly yardCap = signal(74);

  run(id: string) {
    this.portData.runScenario(id);
  }

  updateCrane(e: Event) {
    this.craneCount.set(Number((e.target as HTMLInputElement).value));
  }

  updateYard(e: Event) {
    this.yardCap.set(Number((e.target as HTMLInputElement).value));
  }
}
