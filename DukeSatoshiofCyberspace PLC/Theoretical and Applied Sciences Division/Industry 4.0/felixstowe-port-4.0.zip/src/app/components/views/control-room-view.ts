import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { PortData } from '../../services/port-data';

@Component({
  selector: 'app-control-room-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Signature Demos Quick Bar -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 shadow-md flex flex-wrap items-center justify-between gap-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-cyan-400">play_circle_filled</mat-icon>
          <div>
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-cyan-300">Preset Signature Demos</h3>
            <p class="text-[11px] text-slate-400">Trigger deterministic operational scenario simulations</p>
          </div>
        </div>
        <div class="flex flex-wrap items-center gap-2">
          <button
            (click)="portData.runScenario('MEGA_VESSEL')"
            class="px-3 py-1.5 rounded bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-200 text-xs font-mono font-semibold transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-cyan-400">directions_boat</mat-icon>
            Demo 1: Mega Vessel 24k TEU
          </button>
          <button
            (click)="portData.runScenario('PORT_BOTTLENECK')"
            class="px-3 py-1.5 rounded bg-amber-950 hover:bg-amber-900 border border-amber-800 text-amber-200 text-xs font-mono font-semibold transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-amber-400">warning</mat-icon>
            Demo 2: Yard Bottleneck (89%)
          </button>
          <button
            (click)="portData.runScenario('RAIL_FIRST')"
            class="px-3 py-1.5 rounded bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-200 text-xs font-mono font-semibold transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-emerald-400">train</mat-icon>
            Demo 3: Rail-First Intermodal
          </button>
          <button
            (click)="portData.runScenario('CRANE_FAILURE')"
            class="px-3 py-1.5 rounded bg-rose-950 hover:bg-rose-900 border border-rose-800 text-rose-200 text-xs font-mono font-semibold transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-rose-400">report_problem</mat-icon>
            Demo 4: 3-Crane Failure Outage
          </button>
        </div>
      </div>

      <!-- Overview KPI Deck -->
      @if (portData.portStatus(); as status) {
        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl shadow-sm">
            <div class="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
              <span>VESSELS IN PORT</span>
              <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">directions_boat</mat-icon>
            </div>
            <div class="text-2xl font-mono font-extrabold text-white">{{ status.vesselsInPort }}</div>
            <div class="text-[10px] text-slate-400 font-mono mt-1">
              <span class="text-emerald-400 font-bold">{{ status.vesselsAtBerth }}</span> at berth · <span class="text-amber-400 font-bold">{{ status.vesselsApproaching }}</span> approaching
            </div>
          </div>

          <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl shadow-sm">
            <div class="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
              <span>QUAY CRANES</span>
              <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">precision_manufacturing</mat-icon>
            </div>
            <div class="text-2xl font-mono font-extrabold text-white">{{ status.quayCranesActive }} / 28</div>
            <div class="text-[10px] text-slate-400 font-mono mt-1">
              <span class="text-emerald-400 font-bold">{{ status.movesPerHour }}</span> moves / hr
            </div>
          </div>

          <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl shadow-sm">
            <div class="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
              <span>YARD UTILISATION</span>
              <mat-icon class="!w-4 !h-4 !text-base text-amber-400">grid_view</mat-icon>
            </div>
            <div class="text-2xl font-mono font-extrabold" [class.text-amber-400]="status.yardUtilisationPercent < 85" [class.text-rose-400]="status.yardUtilisationPercent >= 85">
              {{ status.yardUtilisationPercent }}%
            </div>
            <div class="text-[10px] text-slate-400 font-mono mt-1">
              {{ status.yardOccupiedTeu.toLocaleString() }} / {{ status.yardCapacityTeu.toLocaleString() }} TEU
            </div>
          </div>

          <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl shadow-sm">
            <div class="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
              <span>TRUCK MOVEMENTS</span>
              <mat-icon class="!w-4 !h-4 !text-base text-blue-400">local_shipping</mat-icon>
            </div>
            <div class="text-2xl font-mono font-extrabold text-white">{{ status.truckMovements24h.toLocaleString() }}</div>
            <div class="text-[10px] text-slate-400 font-mono mt-1">
              Gate Queue: <span class="text-amber-400 font-bold">{{ status.gateQueueLength }}</span> trucks
            </div>
          </div>

          <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl shadow-sm">
            <div class="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
              <span>RAIL MOVEMENTS</span>
              <mat-icon class="!w-4 !h-4 !text-base text-emerald-400">train</mat-icon>
            </div>
            <div class="text-2xl font-mono font-extrabold text-white">{{ status.railMovements24h }}</div>
            <div class="text-[10px] text-slate-400 font-mono mt-1">
              Rail Capacity: <span class="text-emerald-400 font-bold">{{ status.railCapacityUtilisation }}%</span>
            </div>
          </div>

          <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl shadow-sm">
            <div class="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
              <span>CONGESTION INDEX</span>
              <mat-icon class="!w-4 !h-4 !text-base text-rose-400">speed</mat-icon>
            </div>
            <div class="text-2xl font-mono font-extrabold text-white">{{ status.congestionIndex }} / 100</div>
            <div class="text-[10px] text-slate-400 font-mono mt-1">
              TEU/hr throughput: <span class="text-cyan-400 font-bold">{{ status.teuPerHour }}</span>
            </div>
          </div>
        </div>

        <!-- Causal Bottleneck Engine & Operational Flow -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <!-- Bottleneck Analysis & Causal Graph -->
          <div class="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-amber-400">insights</mat-icon>
                <h3 class="font-mono font-bold text-sm text-slate-100 uppercase tracking-wider">
                  Real-time Port Bottleneck & Causal Analysis Engine
                </h3>
              </div>
              <span class="text-xs font-mono px-2 py-0.5 rounded bg-amber-950 border border-amber-800 text-amber-300 font-semibold">
                ACTIVE CONSTRAINT
              </span>
            </div>

            <div class="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3">
              <div class="flex items-center justify-between text-xs font-mono">
                <span class="text-slate-400 uppercase">Primary Constraint Identified:</span>
                <span class="text-amber-400 font-bold text-sm">{{ status.primaryBottleneck }}</span>
              </div>
              <p class="text-xs text-slate-300 leading-relaxed font-sans">
                The continuous bottleneck engine calculates that yard stack density and rehandle operations currently limit overall container velocity. High yard dwell on Trinity Terminal import blocks is creating backpressure on quay crane trolley speeds.
              </p>
            </div>

            <!-- Causal Chain Propagation -->
            <div>
              <h4 class="text-xs font-mono font-bold uppercase text-slate-400 mb-3">Causal Chain Propagation Path</h4>
              <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 text-center text-xs font-mono">
                <div class="bg-slate-950 p-2 rounded border border-slate-800">
                  <div class="text-[10px] text-slate-500">STAGE 1</div>
                  <div class="text-cyan-300 font-bold mt-1">VESSEL SURGE</div>
                </div>
                <div class="bg-slate-950 p-2 rounded border border-slate-800">
                  <div class="text-[10px] text-slate-500">STAGE 2</div>
                  <div class="text-cyan-300 font-bold mt-1">CRANE DEMAND</div>
                </div>
                <div class="bg-slate-950 p-2 rounded border border-amber-800/80 bg-amber-950/30">
                  <div class="text-[10px] text-amber-400 font-bold">STAGE 3 (BOTTLENECK)</div>
                  <div class="text-amber-300 font-extrabold mt-1">YARD PRESSURE</div>
                </div>
                <div class="bg-slate-950 p-2 rounded border border-slate-800">
                  <div class="text-[10px] text-slate-500">STAGE 4</div>
                  <div class="text-slate-300 font-bold mt-1">TRUCK QUEUE</div>
                </div>
                <div class="bg-slate-950 p-2 rounded border border-slate-800">
                  <div class="text-[10px] text-slate-500">STAGE 5</div>
                  <div class="text-slate-300 font-bold mt-1">RAIL PRESSURE</div>
                </div>
                <div class="bg-slate-950 p-2 rounded border border-slate-800">
                  <div class="text-[10px] text-slate-500">STAGE 6</div>
                  <div class="text-slate-300 font-bold mt-1">INLAND DELAY</div>
                </div>
              </div>
            </div>

            <!-- Secondary Bottlenecks -->
            <div class="flex flex-wrap items-center gap-2 pt-2">
              <span class="text-xs font-mono text-slate-400">Secondary Bottlenecks:</span>
              @for (sec of status.secondaryBottlenecks; track sec) {
                <span class="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">
                  {{ sec }}
                </span>
              }
            </div>
          </div>

          <!-- Immutable Container Event Stream -->
          <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-3 flex flex-col justify-between">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-cyan-400">stream</mat-icon>
                <h3 class="font-mono font-bold text-sm text-slate-100 uppercase tracking-wider">
                  Live Container Event Stream
                </h3>
              </div>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-400 font-bold">
                REALTIME
              </span>
            </div>

            <div class="space-y-2 max-h-[320px] overflow-y-auto pr-1">
              @for (evt of portData.events().slice(0, 7); track evt.id) {
                <div (click)="portData.selectContainer(evt.containerId)" class="p-2 rounded bg-slate-950/80 border border-slate-800/80 hover:border-cyan-700/80 cursor-pointer transition-colors text-xs font-mono">
                  <div class="flex justify-between items-center text-[10px] text-slate-400">
                    <span class="text-cyan-400 font-bold">{{ evt.eventType }}</span>
                    <span>{{ evt.timestamp.substring(11, 19) }} Z</span>
                  </div>
                  <div class="text-slate-200 mt-1 font-semibold truncate">{{ evt.containerId }} · {{ evt.location }}</div>
                  <div class="text-[11px] text-slate-400 font-sans mt-0.5 truncate">{{ evt.details }}</div>
                </div>
              }
            </div>

            <button
              (click)="portData.setView('AI_PORT_PLANNER')"
              class="w-full py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all">
              <mat-icon class="!w-4 !h-4 !text-base">psychology</mat-icon>
              Ask PORT 4.0 AI Planner
            </button>
          </div>
        </div>
      }
    </div>
  `,
})
export class ControlRoomView {
  readonly portData = inject(PortData);
}
