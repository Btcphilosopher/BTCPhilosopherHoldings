import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { PortData } from '../../services/port-data';

@Component({
  selector: 'app-customers-documents-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono">
      <!-- Title -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
        <div>
          <h2 class="text-sm font-bold uppercase tracking-wider text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">description</mat-icon>
            Customer Portal & SOLAS Verified Gross Mass (VGM) Document Engine
          </h2>
          <p class="text-xs text-slate-400 mt-0.5 font-sans">
            Container digital thread history, Bill of Lading verification and SOLAS weighing service audit
          </p>
        </div>
      </div>

      <!-- Customer Container Roster -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
          <mat-icon class="text-cyan-400">folder_shared</mat-icon>
          Consignment Tracking & SOLAS VGM Scale Audit
        </h3>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs text-slate-300">
            <thead class="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th class="p-2.5">Container ID</th>
                <th class="p-2.5">Customer</th>
                <th class="p-2.5">Type / Class</th>
                <th class="p-2.5">SOLAS Declared Weight</th>
                <th class="p-2.5">SOLAS Verified Weight</th>
                <th class="p-2.5">Customs Release</th>
                <th class="p-2.5">Yard Slot</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (c of portData.containers().slice(0, 15); track c.id) {
                <tr (click)="portData.selectContainer(c.id)" class="hover:bg-slate-800/50 cursor-pointer transition-colors">
                  <td class="p-2.5 font-bold text-cyan-400">{{ c.id }}</td>
                  <td class="p-2.5 font-semibold text-white">{{ c.customer }}</td>
                  <td class="p-2.5 text-slate-400">{{ c.type }} ({{ c.isoClass }})</td>
                  <td class="p-2.5 text-slate-300">{{ c.grossWeightKg }} kg</td>
                  <td class="p-2.5 font-bold text-emerald-400">{{ c.verifiedWeightKg }} kg (VERIFIED)</td>
                  <td class="p-2.5 font-bold" [class.text-emerald-400]="c.customsReleased" [class.text-rose-400]="!c.customsReleased">
                    {{ c.customsReleased ? 'RELEASED' : 'HOLD' }}
                  </td>
                  <td class="p-2.5 font-bold text-amber-300">{{ c.yardLocation }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class CustomersDocumentsView {
  readonly portData = inject(PortData);
}
