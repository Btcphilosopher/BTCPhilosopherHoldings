import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';
import { PortData } from '../../services/port-data';

@Component({
  selector: 'app-road-gates-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono">
      <!-- Title -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 class="text-sm font-bold uppercase tracking-wider text-slate-100 flex items-center gap-2">
            <mat-icon class="text-amber-400">local_shipping</mat-icon>
            Container Booking System (CBS) & Road Gate OS
          </h2>
          <p class="text-xs text-slate-400 mt-0.5 font-sans">
            Appointment validator, OCR gate inspection and turn-around time optimisation for 4,000 daily haulier movements
          </p>
        </div>

        <div class="flex items-center gap-2 text-xs">
          <span class="px-2.5 py-1 rounded bg-slate-800 border border-slate-700 text-slate-200">Avg Turnaround: 22.4 mins</span>
        </div>
      </div>

      <!-- CBS Appointment Booking Simulator -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
          <mat-icon class="text-cyan-400">event_available</mat-icon>
          Container Booking System (CBS) Appointment Validator
        </h3>

        <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <label class="text-slate-400 mb-1 block">Container ID</label>
            <input type="text" value="GBFX-300002-2" class="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100 font-mono">
          </div>
          <div>
            <label class="text-slate-400 mb-1 block">Haulier Name</label>
            <input type="text" value="Maritime Transport Ltd" class="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100 font-mono">
          </div>
          <div>
            <label class="text-slate-400 mb-1 block">Driver VRN / License</label>
            <input type="text" value="UK-VRN-8821" class="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100 font-mono">
          </div>
          <div class="flex items-end">
            <button (click)="bookAppointment()" class="w-full py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded uppercase transition-colors">
              Validate CBS Appointment
            </button>
          </div>
        </div>

        @if (cbsBooking(); as booking) {
          <div class="p-3 bg-emerald-950/80 border border-emerald-800 rounded text-xs text-emerald-200 space-y-1">
            <div class="font-bold flex items-center gap-1">
              <mat-icon class="!w-4 !h-4 !text-base text-emerald-400">check_circle</mat-icon>
              APPOINTMENT VALIDATED & CONFIRMED: {{ booking.appointmentId }}
            </div>
            <div>Gate Lane Assigned: <span class="font-bold text-white">{{ booking.gateLaneAssigned }}</span> · Security Release Cleared</div>
          </div>
        }
      </div>

      <!-- Inbound Gate Lanes Status Grid -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
          <mat-icon class="text-amber-400">door_front</mat-icon>
          Inbound Gate Lanes 01 - 08 Telemetry
        </h3>

        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          @for (lane of portData.gateLanes(); track lane.id) {
            <div (click)="portData.inspectObject('GATE', lane.id, lane)" class="bg-slate-950 p-3 rounded border border-slate-800 hover:border-cyan-500 cursor-pointer transition-colors space-y-1">
              <div class="flex justify-between font-bold text-slate-200">
                <span>{{ lane.name }}</span>
                <span [class.text-emerald-400]="lane.status === 'OPEN'" [class.text-amber-400]="lane.status === 'INSPECTION'">{{ lane.status }}</span>
              </div>
              <div class="text-slate-400 text-[11px]">Queue: <span class="text-amber-400 font-bold">{{ lane.queueLength }} trucks</span></div>
              <div class="text-slate-400 text-[11px]">24h Processed: <span class="text-white">{{ lane.trucksProcessed24h }}</span></div>
              <div class="text-[10px] text-slate-500">Avg Processing: {{ lane.avgTurnaroundMins }}m</div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class RoadGatesView {
  readonly portData = inject(PortData);
  private http = inject(HttpClient);
  readonly cbsBooking = signal<any | null>(null);

  bookAppointment() {
    this.http.post('/api/appointments', { containerId: 'GBFX-300002-2' }).subscribe(res => {
      this.cbsBooking.set(res);
    });
  }
}
