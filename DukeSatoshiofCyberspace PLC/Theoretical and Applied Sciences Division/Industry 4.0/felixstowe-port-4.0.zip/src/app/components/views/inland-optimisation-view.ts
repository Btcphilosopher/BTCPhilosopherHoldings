import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { IntermodalRouteOption } from '../../../server-engine/types';
import { PortData } from '../../services/port-data';

@Component({
  selector: 'app-inland-optimisation-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono">
      <!-- Title -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 class="text-sm font-bold uppercase tracking-wider text-slate-100 flex items-center gap-2">
            <mat-icon class="text-emerald-400">alt_route</mat-icon>
            PARIS-Inspired Intermodal Freight Routing Engine
          </h2>
          <p class="text-xs text-slate-400 mt-0.5 font-sans">
            Multimodal transport optimization comparing Road, Rail, and Coastal transport possibilities into Britain
          </p>
        </div>

        <button (click)="runOptimisation()" class="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase rounded transition-colors flex items-center gap-1.5">
          <mat-icon class="!w-4 !h-4 !text-base">calculate</mat-icon>
          Run Trade-Off Optimisation
        </button>
      </div>

      <!-- Freight Route Selector Inputs -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
          <mat-icon class="text-cyan-400">tune</mat-icon>
          Inland Destination Hub Trade-off Matrix
        </h3>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div>
            <label class="text-slate-400 mb-1 block">UK Freight Destination</label>
            <select (change)="onDestChange($event)" class="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100">
              <option value="Daventry DIRFT">Daventry DIRFT (Midlands)</option>
              <option value="Birmingham Hams Hall">Birmingham Hams Hall</option>
              <option value="Manchester Trafford Park">Manchester Trafford Park</option>
              <option value="Leeds Freightliner">Leeds Freightliner Terminal</option>
              <option value="Doncaster iPort">Doncaster iPort</option>
            </select>
          </div>

          <div>
            <label class="text-slate-400 mb-1 block">Batch Container Volume</label>
            <input type="number" value="100" class="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100">
          </div>

          <div class="flex items-end">
            <button (click)="runOptimisation()" class="w-full py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded uppercase transition-colors">
              Calculate Optimal Plan
            </button>
          </div>
        </div>
      </div>

      <!-- Intermodal Route Comparison Results Cards -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        @for (opt of routingResults(); track opt.mode) {
          <div
            class="p-5 rounded-xl border transition-all space-y-3"
            [class.bg-emerald-950\/30]="opt.recommended"
            [class.border-emerald-700]="opt.recommended"
            [class.bg-slate-900\/80]="!opt.recommended"
            [class.border-slate-800]="!opt.recommended">

            <div class="flex justify-between items-center border-b border-slate-800 pb-2">
              <span class="font-extrabold text-sm text-white uppercase flex items-center gap-1.5">
                <mat-icon [class.text-emerald-400]="opt.recommended" class="!w-4 !h-4 !text-base">
                  {{ opt.mode === 'RAIL' ? 'train' : opt.mode === 'ROAD' ? 'local_shipping' : 'directions_boat' }}
                </mat-icon>
                {{ opt.mode }} FREIGHT
              </span>
              @if (opt.recommended) {
                <span class="text-[10px] px-2 py-0.5 rounded bg-emerald-900 border border-emerald-600 text-emerald-200 font-bold">
                  OPTIMAL SELECTION
                </span>
              }
            </div>

            <div class="space-y-2 text-xs">
              <div class="flex justify-between"><span class="text-slate-400">Total Transport Cost:</span> <span class="font-bold text-white">£{{ opt.costGbp.toLocaleString() }}</span></div>
              <div class="flex justify-between"><span class="text-slate-400">Transit Duration:</span> <span class="font-bold text-cyan-300">{{ opt.transitHours }} Hours</span></div>
              <div class="flex justify-between"><span class="text-slate-400">Carbon Footprint:</span> <span class="font-bold text-emerald-400">{{ opt.carbonKgCo2e.toLocaleString() }} kg CO₂e</span></div>
              <div class="flex justify-between"><span class="text-slate-400">Reliability Score:</span> <span class="font-bold text-amber-300">{{ opt.reliabilityScore }} / 100</span></div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class InlandOptimisationView {
  readonly portData = inject(PortData);
  readonly selectedDest = signal('Daventry DIRFT');
  readonly routingResults = signal<IntermodalRouteOption[]>([]);

  constructor() {
    this.runOptimisation();
  }

  onDestChange(e: Event) {
    const sel = e.target as HTMLSelectElement;
    this.selectedDest.set(sel.value);
    this.runOptimisation();
  }

  runOptimisation() {
    this.portData.getIntermodalRouting(this.selectedDest(), 100).subscribe(res => {
      this.routingResults.set(res);
    });
  }
}
