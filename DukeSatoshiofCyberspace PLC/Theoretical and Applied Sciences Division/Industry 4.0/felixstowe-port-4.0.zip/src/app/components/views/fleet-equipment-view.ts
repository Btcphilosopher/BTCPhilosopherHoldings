import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { PortData } from '../../services/port-data';

@Component({
  selector: 'app-fleet-equipment-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono">
      <!-- Title -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 class="text-sm font-bold uppercase tracking-wider text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">precision_manufacturing</mat-icon>
            Automated Terminal Fleet & Predictive Maintenance OS
          </h2>
          <p class="text-xs text-slate-400 mt-0.5 font-sans">
            Real-time telemetry and dispatch engine for AGVs, RTGs, Straddle Carriers & Autonomous Trucks
          </p>
        </div>

        <div class="flex items-center gap-2 text-xs">
          <span class="px-2.5 py-1 rounded bg-emerald-950 border border-emerald-800 text-emerald-400 font-bold">50 AGVs Active</span>
          <span class="px-2.5 py-1 rounded bg-cyan-950 border border-cyan-800 text-cyan-400 font-bold">30 RTGs Active</span>
        </div>
      </div>

      <!-- Anomaly Alert Deck -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4 shadow-sm">
        <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
          <mat-icon class="text-amber-400">sensors</mat-icon>
          Predictive Maintenance Anomaly Telemetry (Vibration, Motor Current & Hydraulics)
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div class="bg-slate-950 p-3 rounded border border-rose-800 bg-rose-950/20">
            <div class="flex justify-between items-center text-rose-400 font-bold mb-1">
              <span>RTG-07 (Rubber Tyred Gantry)</span>
              <span>DEGRADED</span>
            </div>
            <div class="text-slate-300">Vibration: <span class="text-rose-400 font-bold">4.8 mm/s</span> (Threshold: 3.2 mm/s)</div>
            <div class="text-slate-300">Hydraulic Temp: <span class="text-amber-400 font-bold">88°C</span></div>
            <div class="text-[10px] text-slate-500 mt-1">Diagnosis: Hydraulic Cylinder Seal Failure. Service scheduled.</div>
          </div>

          <div class="bg-slate-950 p-3 rounded border border-amber-800 bg-amber-950/20">
            <div class="flex justify-between items-center text-amber-400 font-bold mb-1">
              <span>QC-13 (Quay Crane 13)</span>
              <span>WATCH</span>
            </div>
            <div class="text-slate-300">Lift Cycle Count: <span class="text-amber-300 font-bold">153,200</span></div>
            <div class="text-slate-300">Motor Current: <span class="text-slate-200 font-bold">142 A</span></div>
            <div class="text-[10px] text-slate-500 mt-1">Diagnosis: Main Hoist Wire Wear. Scheduled for maintenance.</div>
          </div>

          <div class="bg-slate-950 p-3 rounded border border-emerald-800 bg-emerald-950/20">
            <div class="flex justify-between items-center text-emerald-400 font-bold mb-1">
              <span>AGV-18 (Autonomous Vehicle)</span>
              <span>OPTIMAL</span>
            </div>
            <div class="text-slate-300">Battery Level: <span class="text-emerald-400 font-bold">88%</span></div>
            <div class="text-slate-300">Vibration: <span class="text-slate-200 font-bold">1.2 mm/s</span></div>
            <div class="text-[10px] text-slate-500 mt-1">Status: Transporting Container to Block B02.</div>
          </div>
        </div>
      </div>

      <!-- Equipment Matrix Table -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
          <mat-icon class="text-cyan-400">build</mat-icon>
          Terminal Equipment Roster & Dispatch Matrix
        </h3>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs text-slate-300">
            <thead class="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th class="p-2.5">ID / Type</th>
                <th class="p-2.5">Location</th>
                <th class="p-2.5">Fuel / Battery</th>
                <th class="p-2.5">Current Task</th>
                <th class="p-2.5">Health</th>
                <th class="p-2.5">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (veh of portData.vehicles(); track veh.id) {
                <tr (click)="portData.inspectObject('EQUIPMENT', veh.id, veh)" class="hover:bg-slate-800/50 cursor-pointer transition-colors">
                  <td class="p-2.5 font-bold text-slate-100">
                    {{ veh.id }}
                    <span class="text-[10px] text-slate-500 block">{{ veh.type }}</span>
                  </td>
                  <td class="p-2.5 text-cyan-300">{{ veh.location }}</td>
                  <td class="p-2.5 font-bold" [class.text-emerald-400]="veh.batteryPercent > 50" [class.text-amber-400]="veh.batteryPercent <= 50">
                    {{ veh.batteryPercent }}% ({{ veh.fuelType }})
                  </td>
                  <td class="p-2.5 text-slate-200 truncate max-w-[240px]">{{ veh.currentTask || 'IDLE' }}</td>
                  <td class="p-2.5 font-bold" [class.text-emerald-400]="veh.healthPercent > 80" [class.text-rose-400]="veh.healthPercent <= 80">
                    {{ veh.healthPercent }}%
                  </td>
                  <td class="p-2.5 font-bold" [class.text-emerald-400]="veh.status === 'ASSIGNED' || veh.status === 'TRAVELLING'" [class.text-rose-400]="veh.status === 'FAULT'">
                    {{ veh.status }}
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class FleetEquipmentView {
  readonly portData = inject(PortData);
}
