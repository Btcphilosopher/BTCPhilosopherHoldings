import { AfterViewInit, ChangeDetectionStrategy, Component, ElementRef, OnDestroy, ViewChild, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { PortData } from '../../services/port-data';

@Component({
  selector: 'app-digital-twin-3d-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4">
      <!-- Top Bar Controls -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
        <div class="flex items-center gap-2">
          <mat-icon class="text-cyan-400">3d_rotation</mat-icon>
          <span class="font-bold text-slate-100 uppercase tracking-wider">3D Terminal Spatial Digital Twin</span>
          <span class="text-slate-400">| Engineering Simulation Mode</span>
        </div>

        <div class="flex items-center gap-3">
          <div class="flex items-center gap-2 text-slate-300">
            <span class="w-2.5 h-2.5 rounded-full bg-cyan-500"></span> Vessels
            <span class="w-2.5 h-2.5 rounded-full bg-amber-500"></span> Cranes
            <span class="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Yard Stacks
            <span class="w-2.5 h-2.5 rounded-full bg-blue-500"></span> AGVs/Trucks
            <span class="w-2.5 h-2.5 rounded-full bg-purple-500"></span> Rail Trains
          </div>
          <button (click)="resetCamera()" class="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold transition-colors">
            Reset View
          </button>
        </div>
      </div>

      <!-- Canvas Viewport -->
      <div class="relative w-full h-[640px] bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
        <div #canvasContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

        <!-- Canvas Overlay HUD -->
        <div class="absolute bottom-4 left-4 z-10 bg-slate-900/90 backdrop-blur border border-slate-800 p-3 rounded-lg text-xs font-mono text-slate-300 space-y-1">
          <div class="text-cyan-400 font-bold">RAYCAST OBJECT INSPECTOR READY</div>
          <div>Click any 3D vessel, crane, stack block, AGV, or train wagon to inspect live digital telemetry.</div>
        </div>
      </div>
    </div>
  `,
})
export class DigitalTwin3dView implements AfterViewInit, OnDestroy {
  @ViewChild('canvasContainer') canvasContainer!: ElementRef<HTMLDivElement>;
  readonly portData = inject(PortData);

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animFrameId: number | null = null;
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  // Animated mesh references
  private animatedCranes: THREE.Mesh[] = [];
  private animatedTrucks: THREE.Mesh[] = [];
  private animatedTrain!: THREE.Group;

  ngAfterViewInit() {
    this.initThreeScene();
  }

  ngOnDestroy() {
    if (this.animFrameId) cancelAnimationFrame(this.animFrameId);
    if (this.renderer) this.renderer.dispose();
  }

  private initThreeScene() {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || 1000;
    const height = container.clientHeight || 640;

    // Scene setup
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0b101d); // Deep navy port ground
    this.scene.fog = new THREE.FogExp2(0x0b101d, 0.002);

    // Camera
    this.camera = new THREE.PerspectiveCamera(45, width / height, 1, 1000);
    this.resetCamera();

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = true;
    container.appendChild(this.renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xe2e8f0, 1.2);
    dirLight.position.set(150, 200, 100);
    dirLight.castShadow = true;
    this.scene.add(dirLight);

    // Build Spatial Environment
    this.buildSeaAndDocks();
    this.buildVessels();
    this.buildQuayCranes();
    this.buildYardStacks();
    this.buildTrucksAndAGVs();
    this.buildRailwaysAndTrain();

    // Setup Interaction Listener
    container.addEventListener('click', (e) => this.onCanvasClick(e, container));

    // Animation Loop
    this.animate();
  }

  public resetCamera() {
    if (this.camera) {
      this.camera.position.set(220, 180, 260);
      this.camera.lookAt(0, 0, 0);
    }
  }

  private buildSeaAndDocks() {
    // 1. Sea Plane
    const seaGeo = new THREE.PlaneGeometry(800, 400);
    const seaMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.1, metalness: 0.8 });
    const sea = new THREE.Mesh(seaGeo, seaMat);
    sea.rotation.x = -Math.PI / 2;
    sea.position.set(-150, -1, 0);
    this.scene.add(sea);

    // 2. Quay Concrete Dock
    const quayGeo = new THREE.BoxGeometry(400, 10, 600);
    const quayMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });
    const quay = new THREE.Mesh(quayGeo, quayMat);
    quay.position.set(100, -5, 0);
    this.scene.add(quay);
  }

  private buildVessels() {
    const vesselColors = [0x0284c7, 0x0369a1, 0x0f766e, 0xb45309];
    const vesselPositions = [-180, -60, 60, 180];

    vesselPositions.forEach((posZ, idx) => {
      const vesselGroup = new THREE.Group();

      // Hull
      const hullGeo = new THREE.BoxGeometry(70, 20, 130);
      const hullMat = new THREE.MeshStandardMaterial({ color: vesselColors[idx % vesselColors.length], roughness: 0.4 });
      const hull = new THREE.Mesh(hullGeo, hullMat);
      hull.position.set(-100, 5, posZ);
      hull.userData = { type: 'VESSEL', id: `VES-00${idx + 1}` };
      vesselGroup.add(hull);

      // Stack Container Cubes on Hull
      for (let x = -20; x <= 20; x += 12) {
        for (let y = 18; y <= 30; y += 6) {
          for (let z = posZ - 40; z <= posZ + 40; z += 16) {
            if (Math.random() > 0.15) {
              const boxGeo = new THREE.BoxGeometry(10, 5, 14);
              const boxMat = new THREE.MeshStandardMaterial({ color: (x + z) % 2 === 0 ? 0x0284c7 : 0xeab308 });
              const box = new THREE.Mesh(boxGeo, boxMat);
              box.position.set(-100 + x, y, z);
              box.userData = { type: 'CONTAINER', id: `GBFX-${Math.floor(100000 + Math.random() * 900000)}` };
              vesselGroup.add(box);
            }
          }
        }
      }

      this.scene.add(vesselGroup);
    });
  }

  private buildQuayCranes() {
    for (let z = -220; z <= 220; z += 50) {
      const craneGroup = new THREE.Group();

      // Vertical Legs
      const legMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.3 });
      const legGeo = new THREE.BoxGeometry(4, 50, 4);

      const leg1 = new THREE.Mesh(legGeo, legMat);
      leg1.position.set(-40, 25, z - 10);

      const leg2 = new THREE.Mesh(legGeo, legMat);
      leg2.position.set(-40, 25, z + 10);

      const leg3 = new THREE.Mesh(legGeo, legMat);
      leg3.position.set(-10, 25, z - 10);

      const leg4 = new THREE.Mesh(legGeo, legMat);
      leg4.position.set(-10, 25, z + 10);

      // Boom Arm across quay
      const boomGeo = new THREE.BoxGeometry(100, 4, 6);
      const boom = new THREE.Mesh(boomGeo, legMat);
      boom.position.set(-50, 48, z);

      craneGroup.add(leg1, leg2, leg3, leg4, boom);

      // Spreader Box
      const spreaderGeo = new THREE.BoxGeometry(8, 4, 12);
      const spreaderMat = new THREE.MeshStandardMaterial({ color: 0xef4444 });
      const spreader = new THREE.Mesh(spreaderGeo, spreaderMat);
      spreader.position.set(-50, 30, z);
      spreader.userData = { type: 'CRANE', id: `QC-${Math.floor((z + 250) / 20) + 1}` };
      craneGroup.add(spreader);

      this.animatedCranes.push(spreader);
      this.scene.add(craneGroup);
    }
  }

  private buildYardStacks() {
    const stackColors = [0x0284c7, 0x10b981, 0xf59e0b, 0xef4444, 0x8b5cf6];

    for (let x = 40; x <= 180; x += 35) {
      for (let z = -200; z <= 200; z += 40) {
        const stackHeight = Math.floor(2 + Math.random() * 4);
        for (let y = 0; y < stackHeight; y++) {
          const boxGeo = new THREE.BoxGeometry(12, 6, 24);
          const mat = new THREE.MeshStandardMaterial({ color: stackColors[(x + z + y) % stackColors.length] });
          const box = new THREE.Mesh(boxGeo, mat);
          box.position.set(x, y * 6.5 + 3, z);
          box.userData = { type: 'YARD_BLOCK', id: `BLOCK-X${x}-Z${z}` };
          this.scene.add(box);
        }
      }
    }
  }

  private buildTrucksAndAGVs() {
    for (let i = 0; i < 12; i++) {
      const truckGeo = new THREE.BoxGeometry(6, 4, 16);
      const truckMat = new THREE.MeshStandardMaterial({ color: 0x3b82f6 });
      const truck = new THREE.Mesh(truckGeo, truckMat);
      truck.position.set(10 + (i % 3) * 10, 2, -220 + i * 35);
      truck.userData = { type: 'EQUIPMENT', id: `AGV-${(i + 1).toString().padStart(2, '0')}` };
      this.animatedTrucks.push(truck);
      this.scene.add(truck);
    }
  }

  private buildRailwaysAndTrain() {
    // Railway Line Track
    const trackGeo = new THREE.BoxGeometry(8, 1, 550);
    const trackMat = new THREE.MeshStandardMaterial({ color: 0x475569 });
    const track = new THREE.Mesh(trackGeo, trackMat);
    track.position.set(240, 0.5, 0);
    this.scene.add(track);

    // Train Group
    this.animatedTrain = new THREE.Group();
    for (let w = 0; w < 10; w++) {
      const wagonGeo = new THREE.BoxGeometry(8, 6, 20);
      const wagonMat = new THREE.MeshStandardMaterial({ color: w === 0 ? 0xd97706 : 0x0284c7 });
      const wagon = new THREE.Mesh(wagonGeo, wagonMat);
      wagon.position.set(240, 4, -180 + w * 24);
      wagon.userData = { type: 'TRAIN', id: 'TRN-101' };
      this.animatedTrain.add(wagon);
    }
    this.scene.add(this.animatedTrain);
  }

  private animate = () => {
    this.animFrameId = requestAnimationFrame(this.animate);

    // Animate Quay Cranes Up/Down
    const time = Date.now() * 0.002;
    this.animatedCranes.forEach((spreader, idx) => {
      spreader.position.y = 25 + Math.sin(time + idx) * 12;
    });

    // Animate Trucks/AGVs driving along quay road
    this.animatedTrucks.forEach((truck, idx) => {
      truck.position.z += 0.8;
      if (truck.position.z > 240) truck.position.z = -240;
    });

    // Animate Train moving slowly along tracks
    if (this.animatedTrain) {
      this.animatedTrain.position.z += 0.3;
      if (this.animatedTrain.position.z > 200) this.animatedTrain.position.z = -200;
    }

    if (this.renderer && this.scene && this.camera) {
      this.renderer.render(this.scene, this.camera);
    }
  };

  private onCanvasClick(event: MouseEvent, container: HTMLDivElement) {
    const rect = container.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / container.clientWidth) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / container.clientHeight) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.scene.children, true);

    if (intersects.length > 0) {
      const hit = intersects[0].object;
      if (hit.userData && hit.userData['type']) {
        this.portData.inspectObject(hit.userData['type'], hit.userData['id'], hit.userData);
      }
    }
  }
}
