import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { PortData } from '../../services/port-data';

@Component({
  selector: 'app-rail-os-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono">
      <!-- Title -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 class="text-sm font-bold uppercase tracking-wider text-slate-100 flex items-center gap-2">
            <mat-icon class="text-purple-400">train</mat-icon>
            Rail Operating System & Terminal Digital Twin
          </h2>
          <p class="text-xs text-slate-400 mt-0.5 font-sans">
            Managing 3 dedicated intermodal rail terminals connecting the Port of Felixstowe to UK inland hubs
          </p>
        </div>

        <button (click)="replanRail()" class="px-3.5 py-2 rounded bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs uppercase transition-colors flex items-center gap-1.5 shadow-md">
          <mat-icon class="!w-4 !h-4 !text-base">auto_fix_high</mat-icon>
          Run Rail Capacity Optimiser
        </button>
      </div>

      <!-- Rail Terminals Overview Cards -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-slate-900/80 border border-slate-800 p-4 rounded-xl space-y-2">
          <div class="flex justify-between items-center text-xs font-bold text-purple-300 border-b border-slate-800 pb-2">
            <span>NORTH RAIL TERMINAL</span>
            <span class="text-emerald-400">4 TRACKS</span>
          </div>
          <div class="text-xs text-slate-300">Daily Capacity: <span class="font-bold text-white">22 Trains</span></div>
          <div class="text-xs text-slate-300">Active Loading: <span class="font-bold text-cyan-400">Train 4M52 → DAVENTRY</span></div>
          <div class="text-[10px] text-slate-500 mt-1">Equipment: 2 Rail Gantry Cranes Active</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-4 rounded-xl space-y-2">
          <div class="flex justify-between items-center text-xs font-bold text-purple-300 border-b border-slate-800 pb-2">
            <span>CENTRAL RAIL TERMINAL</span>
            <span class="text-emerald-400">4 TRACKS</span>
          </div>
          <div class="text-xs text-slate-300">Daily Capacity: <span class="font-bold text-white">20 Trains</span></div>
          <div class="text-xs text-slate-300">Active Loading: <span class="font-bold text-emerald-400">Train 4M88 → BIRMINGHAM</span></div>
          <div class="text-[10px] text-slate-500 mt-1">Equipment: 2 Rail Gantry Cranes Active</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-4 rounded-xl space-y-2">
          <div class="flex justify-between items-center text-xs font-bold text-purple-300 border-b border-slate-800 pb-2">
            <span>SOUTH RAIL TERMINAL</span>
            <span class="text-emerald-400">3 TRACKS</span>
          </div>
          <div class="text-xs text-slate-300">Daily Capacity: <span class="font-bold text-white">16 Trains</span></div>
          <div class="text-xs text-slate-300">Active Loading: <span class="font-bold text-amber-400">Train 4E22 → DONCASTER</span></div>
          <div class="text-[10px] text-slate-500 mt-1">Equipment: 2 Rail Gantry Cranes Active</div>
        </div>
      </div>

      <!-- Train Schedule & Wagon Formation Table -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
          <mat-icon class="text-purple-400">alt_route</mat-icon>
          Daily Freightliner / GB Railfreight Train Roster
        </h3>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs text-slate-300">
            <thead class="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th class="p-2.5">Service Code</th>
                <th class="p-2.5">Operator</th>
                <th class="p-2.5">Destination Hub</th>
                <th class="p-2.5">Terminal</th>
                <th class="p-2.5">Arr / Dep</th>
                <th class="p-2.5">TEU Loaded / Cap</th>
                <th class="p-2.5">Utilisation</th>
                <th class="p-2.5">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (t of portData.trains(); track t.id) {
                <tr (click)="portData.inspectObject('TRAIN', t.id, t)" class="hover:bg-slate-800/50 cursor-pointer transition-colors">
                  <td class="p-2.5 font-bold text-white">{{ t.serviceCode }}</td>
                  <td class="p-2.5 text-purple-300 font-semibold">{{ t.operator }}</td>
                  <td class="p-2.5 text-cyan-400 font-bold">{{ t.destination }}</td>
                  <td class="p-2.5 text-slate-400">{{ t.terminalId }}</td>
                  <td class="p-2.5 text-[11px]">{{ t.arrivalTime }} - {{ t.departureTime }}</td>
                  <td class="p-2.5 font-bold text-amber-300">{{ t.loadedTeu }} / {{ t.capacityTeu }} TEU</td>
                  <td class="p-2.5">
                    <div class="w-20 bg-slate-800 h-2 rounded overflow-hidden">
                      <div class="bg-purple-500 h-full" [style.width.%]="(t.loadedTeu / t.capacityTeu) * 100"></div>
                    </div>
                  </td>
                  <td class="p-2.5 font-bold" [class.text-emerald-400]="t.status === 'READY'" [class.text-amber-400]="t.status === 'LOADING'">
                    {{ t.status }}
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class RailOsView {
  readonly portData = inject(PortData);

  replanRail() {
    this.portData.refreshAllData();
  }
}
