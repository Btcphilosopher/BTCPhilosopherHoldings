import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { PortData } from '../../services/port-data';

@Component({
  selector: 'app-reefer-special-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono">
      <!-- Title -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
        <div>
          <h2 class="text-sm font-bold uppercase tracking-wider text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">ac_unit</mat-icon>
            Reefer Control Room, Heavy Cargo & Hazardous Compliance
          </h2>
          <p class="text-xs text-slate-400 mt-0.5 font-sans">
            Continuous temperature monitoring for cold-chain containers, oversized cargo & IMDG hazardous compliance
          </p>
        </div>
      </div>

      <!-- Reefer Power & Temp Telemetry Cards -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-slate-900/80 border border-slate-800 p-4 rounded-xl space-y-2">
          <div class="flex justify-between items-center text-xs font-bold text-cyan-300 border-b border-slate-800 pb-2">
            <span>CONTAINER REEFER-0912</span>
            <span class="text-emerald-400">POWER OK</span>
          </div>
          <div class="text-xs text-slate-300">Setpoint: <span class="font-bold text-white">-18.0°C</span></div>
          <div class="text-xs text-slate-300">Actual Sensor: <span class="font-bold text-emerald-400">-18.2°C</span></div>
          <div class="text-[10px] text-slate-500 mt-1">Location: Block E02 (Trinity Reefer Bay)</div>
        </div>

        <div class="bg-slate-900/80 border border-rose-800 bg-rose-950/20 p-4 rounded-xl space-y-2">
          <div class="flex justify-between items-center text-xs font-bold text-rose-400 border-b border-rose-900 pb-2">
            <span>CONTAINER REEFER-0441</span>
            <span>TEMP DEVIATION ALERT</span>
          </div>
          <div class="text-xs text-slate-300">Setpoint: <span class="font-bold text-white">-20.0°C</span></div>
          <div class="text-xs text-slate-300">Actual Sensor: <span class="font-bold text-rose-400">-14.1°C (+5.9°C High)</span></div>
          <div class="text-[10px] text-slate-400 mt-1">Action: Dispatch technician to inspect power coupling.</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-4 rounded-xl space-y-2">
          <div class="flex justify-between items-center text-xs font-bold text-amber-300 border-b border-slate-800 pb-2">
            <span>HAZARDOUS CONS-8812</span>
            <span class="text-amber-400">IMDG CLASS 3</span>
          </div>
          <div class="text-xs text-slate-300">Declaration: <span class="font-bold text-white font-sans">Flammable Liquids</span></div>
          <div class="text-xs text-slate-300">Location Restriction: <span class="font-bold text-amber-300">Block F01 Segregated Zone</span></div>
          <div class="text-[10px] text-slate-500 mt-1">Status: Safety release verified for export loading.</div>
        </div>
      </div>
    </div>
  `,
})
export class ReeferSpecialView {
  readonly portData = inject(PortData);
}
