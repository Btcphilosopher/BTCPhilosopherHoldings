import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { PortData } from '../../services/port-data';

@Component({
  selector: 'app-energy-emissions-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono">
      <!-- Title -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
        <div>
          <h2 class="text-sm font-bold uppercase tracking-wider text-slate-100 flex items-center gap-2">
            <mat-icon class="text-amber-400">bolt</mat-icon>
            Port Energy Digital Twin, Electrification Simulator & Carbon Ledger
          </h2>
          <p class="text-xs text-slate-400 mt-0.5 font-sans">
            Tracking terminal energy consumption per TEU and modeling decarbonisation pathways
          </p>
        </div>
      </div>

      <!-- Energy Overview Cards -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl">
          <div class="text-slate-400 mb-1">24H POWER CONSUMPTION</div>
          <div class="text-2xl font-bold text-amber-400">82,700 kWh</div>
          <div class="text-[10px] text-slate-500 mt-1">Quay Cranes, RTGs, AGVs & Reefers</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl">
          <div class="text-slate-400 mb-1">ENERGY INTENSITY</div>
          <div class="text-2xl font-bold text-cyan-400">24.3 kWh / TEU</div>
          <div class="text-[10px] text-slate-500 mt-1">Optimised moves lower unit intensity</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl">
          <div class="text-slate-400 mb-1">24H CO2e EMISSIONS</div>
          <div class="text-2xl font-bold text-emerald-400">31.2 Tonnes</div>
          <div class="text-[10px] text-slate-500 mt-1">Verified Scope 1 & Scope 2 footprint</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl">
          <div class="text-slate-400 mb-1">ELECTRIFICATION RATE</div>
          <div class="text-2xl font-bold text-purple-400">68.4%</div>
          <div class="text-[10px] text-slate-500 mt-1">AGVs fully electric, RTGs hybrid</div>
        </div>
      </div>

      <!-- Electrification Scenario Comparison -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
          <mat-icon class="text-emerald-400">nature</mat-icon>
          Electrification Fleet Scenario Comparison (24H CO2e Footprint)
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div class="bg-slate-950 p-4 rounded border border-rose-800/80 space-y-2">
            <div class="font-bold text-rose-400 text-sm">DIESEL FLEET BASELINE</div>
            <div class="text-2xl font-bold text-white">45.8 CO₂e Tonnes</div>
            <div class="text-[11px] text-slate-400 font-sans">High local particulates and diesel fuel expenditure.</div>
          </div>

          <div class="bg-slate-950 p-4 rounded border border-amber-800/80 space-y-2">
            <div class="font-bold text-amber-300 text-sm">HYBRID FLEET (CURRENT STATE)</div>
            <div class="text-2xl font-bold text-amber-400">28.4 CO₂e Tonnes</div>
            <div class="text-[11px] text-slate-400 font-sans">38% reduction achieved via hybrid RTG braking regeneration.</div>
          </div>

          <div class="bg-slate-950 p-4 rounded border border-emerald-800/80 bg-emerald-950/20 space-y-2">
            <div class="font-bold text-emerald-400 text-sm">100% ELECTRIC FLEET PATHWAY</div>
            <div class="text-2xl font-bold text-emerald-300">12.1 CO₂e Tonnes</div>
            <div class="text-[11px] text-slate-300 font-sans">73.5% emissions reduction with onshore grid green tariff.</div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class EnergyEmissionsView {
  readonly portData = inject(PortData);
}
