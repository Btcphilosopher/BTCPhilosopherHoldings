import { KeyValuePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { PortData } from '../../services/port-data';

@Component({
  selector: 'app-ai-port-planner-view',
  imports: [MatIconModule, KeyValuePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono">
      <!-- Title -->
      <div class="bg-gradient-to-r from-cyan-950 via-slate-900 to-slate-900 border border-cyan-800/80 rounded-xl p-4 flex items-center justify-between shadow-lg">
        <div>
          <h2 class="text-sm font-bold uppercase tracking-wider text-cyan-300 flex items-center gap-2">
            <mat-icon class="text-cyan-400">psychology</mat-icon>
            PORT 4.0 INTELLIGENCE — Gemini 3.8 Decision Support Engine
          </h2>
          <p class="text-xs text-slate-300 mt-0.5 font-sans">
            Quantitative port graph analysis for bottleneck identification, schedule optimization and what-if simulation
          </p>
        </div>
      </div>

      <!-- Quick Prompt Suggestions -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-2">
        <span class="text-xs font-bold text-slate-400 uppercase tracking-wider block">Structured Strategic Queries</span>
        <div class="flex flex-wrap gap-2 text-xs">
          <button (click)="ask('Which vessel is currently most at risk of delay?')" class="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 transition-colors">
            Which vessel is at risk of delay?
          </button>
          <button (click)="ask('Why is yard congestion increasing on Trinity Terminal?')" class="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 transition-colors">
            Why is yard congestion increasing?
          </button>
          <button (click)="ask('Which crane allocation reduces completion time on Berth 8?')" class="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 transition-colors">
            Optimal crane allocation for Berth 8
          </button>
          <button (click)="ask('Which containers should be shifted from Road to Rail?')" class="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-purple-300 border border-slate-700 transition-colors">
            Which containers should move to rail?
          </button>
          <button (click)="ask('What happens if rail capacity falls 20%?')" class="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-rose-300 border border-slate-700 transition-colors">
            What if rail capacity falls 20%?
          </button>
        </div>
      </div>

      <!-- Custom Query Input -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex gap-3">
        <input
          #queryInput
          type="text"
          placeholder="Ask PORT 4.0 INTELLIGENCE about current synthetic state, bottlenecks, or crane dispatch..."
          (keyup.enter)="ask(queryInput.value); queryInput.value = ''"
          class="flex-1 bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500">
        <button
          (click)="ask(queryInput.value); queryInput.value = ''"
          [disabled]="loading()"
          class="px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs uppercase rounded transition-colors flex items-center gap-1.5 disabled:opacity-50">
          <mat-icon class="!w-4 !h-4 !text-base">send</mat-icon>
          Analyze
        </button>
      </div>

      <!-- Loading Indicator -->
      @if (loading()) {
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 text-center text-xs text-cyan-400 font-mono flex items-center justify-center gap-3 animate-pulse">
          <mat-icon class="animate-spin">sync</mat-icon>
          Evaluating Port Telemetry Graph & Running Gemini 3.8 Flash Analysis...
        </div>
      }

      <!-- AI Analysis Output Deck -->
      @if (aiResult(); as res) {
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-5 shadow-xl">
          <!-- Answer -->
          <div>
            <h3 class="font-bold text-xs text-cyan-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <mat-icon class="!w-4 !h-4 !text-base">analytics</mat-icon>
              Operational Decision Support Analysis
            </h3>
            <div class="bg-slate-950 p-4 rounded border border-slate-800 text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-line">
              {{ res.answer }}
            </div>
          </div>

          <!-- Recommended Operational Actions -->
          @if (res.recommendedActions && res.recommendedActions.length) {
            <div>
              <h4 class="font-bold text-xs text-emerald-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <mat-icon class="!w-4 !h-4 !text-base">check_circle</mat-icon>
                Recommended Operational Actions
              </h4>
              <div class="space-y-2 text-xs">
                @for (act of res.recommendedActions; track act) {
                  <div class="p-2.5 rounded bg-slate-950 border border-slate-800 text-slate-200 flex items-start gap-2">
                    <span class="w-2 h-2 rounded-full bg-emerald-400 mt-1.5 shrink-0"></span>
                    <span>{{ act }}</span>
                  </div>
                }
              </div>
            </div>
          }

          <!-- Predicted Metrics Impact -->
          @if (res.metricsImpact && (res.metricsImpact | keyvalue); as impacts) {
            <div>
              <h4 class="font-bold text-xs text-amber-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <mat-icon class="!w-4 !h-4 !text-base">trending_up</mat-icon>
                Predicted Key Metric Impact
              </h4>
              <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                @for (imp of impacts; track imp.key) {
                  <div class="bg-slate-950 p-3 rounded border border-slate-800">
                    <span class="text-slate-400 text-[10px] uppercase block">{{ imp.key }}</span>
                    <span class="text-emerald-400 font-extrabold text-sm mt-0.5 block">{{ imp.value }}</span>
                  </div>
                }
              </div>
            </div>
          }
        </div>
      }
    </div>
  `,
})
export class AiPortPlannerView {
  readonly portData = inject(PortData);
  readonly loading = signal(false);
  readonly aiResult = signal<{ answer: string; recommendedActions: string[]; metricsImpact: Record<string, string> } | null>(null);

  constructor() {
    this.ask('Which vessel is currently most at risk of delay?');
  }

  ask(q: string) {
    if (!q || !q.trim()) return;
    this.loading.set(true);
    this.portData.askAiPlanner(q).subscribe({
      next: (res) => {
        this.aiResult.set(res);
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
      },
    });
  }
}
