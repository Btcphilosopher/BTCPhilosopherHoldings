import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { PortData } from '../../services/port-data';

@Component({
  selector: 'app-port-2d-map-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4">
      <!-- Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
        <div class="flex items-center gap-2">
          <mat-icon class="text-cyan-400">map</mat-icon>
          <span class="font-bold text-slate-100 uppercase tracking-wider">Felixstowe Terminal GIS Vector Map (2D)</span>
          <span class="text-slate-400">| Trinity Terminal & Berths 8 & 9</span>
        </div>

        <div class="flex items-center gap-2 text-[11px]">
          <span class="px-2 py-0.5 rounded bg-blue-950 border border-blue-800 text-blue-300">Trinity Terminal</span>
          <span class="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-300">Berths 8 & 9</span>
          <span class="px-2 py-0.5 rounded bg-purple-950 border border-purple-800 text-purple-300">Rail Terminals</span>
          <span class="px-2 py-0.5 rounded bg-amber-950 border border-amber-800 text-amber-300">CBS Main Gates</span>
        </div>
      </div>

      <!-- Vector Map SVG Canvas -->
      <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 shadow-2xl overflow-x-auto">
        <svg viewBox="0 0 1200 650" class="w-full h-auto min-w-[900px] font-mono select-none">
          <!-- Background Grid Lines -->
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" stroke-width="0.5"/>
          </pattern>
          <rect width="1200" height="650" fill="#0b101d"/>
          <rect width="1200" height="650" fill="url(#grid)"/>

          <!-- Sea Water Channel -->
          <rect x="0" y="0" width="1200" height="110" fill="#0f172a" stroke="#1e293b"/>
          <text x="30" y="35" fill="#38bdf8" font-size="12" font-weight="bold">HARWICH HAVEN / DEEPWATER APPROACH CHANNEL</text>

          <!-- Berths 1 to 7 (Trinity Terminal Quay Line) -->
          <rect x="50" y="100" width="700" height="20" fill="#1e293b" stroke="#38bdf8" stroke-width="1.5"/>
          <text x="60" y="114" fill="#f8fafc" font-size="10" font-weight="bold">TRINITY TERMINAL QUAY (BERTHS 1 - 7)</text>

          <!-- Berths 8 & 9 Deepwater Quay Line -->
          <rect x="770" y="100" width="380" height="20" fill="#065f46" stroke="#10b981" stroke-width="1.5"/>
          <text x="780" y="114" fill="#f8fafc" font-size="10" font-weight="bold">BERTHS 8 & 9 DEEPWATER QUAY</text>

          <!-- Moored Vessels in Berths -->
          <!-- Trinity Vessel -->
          <g (click)="portData.inspectObject('VESSEL', 'VES-001', portData.vessels()[0])" class="cursor-pointer hover:opacity-80">
            <rect x="80" y="45" width="220" height="50" rx="6" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="90" y="70" fill="#ffffff" font-size="11" font-weight="bold">MSC EVELYN (VES-001)</text>
            <text x="90" y="85" fill="#bae6fd" font-size="9">DISCHARGING · 62%</text>
          </g>

          <g (click)="portData.inspectObject('VESSEL', 'VES-002', portData.vessels()[1])" class="cursor-pointer hover:opacity-80">
            <rect x="330" y="40" width="280" height="55" rx="6" fill="#0369a1" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="340" y="65" fill="#ffffff" font-size="11" font-weight="bold">COSCO SHIPPING UNIVERSE (VES-002)</text>
            <text x="340" y="80" fill="#bae6fd" font-size="9">WORKING · 41%</text>
          </g>

          <!-- Berths 8 & 9 Vessels -->
          <g (click)="portData.inspectObject('VESSEL', 'VES-005', portData.vessels()[4])" class="cursor-pointer hover:opacity-80">
            <rect x="790" y="35" width="340" height="60" rx="6" fill="#047857" stroke="#34d399" stroke-width="1.5"/>
            <text x="800" y="60" fill="#ffffff" font-size="11" font-weight="bold">OOCL HONG KONG (VES-005)</text>
            <text x="800" y="78" fill="#a7f3d0" font-size="9">21,413 TEU MEGA · 54%</text>
          </g>

          <!-- Quay Cranes Line (QC-01 to QC-28) -->
          @for (qc of portData.cranes(); track qc.id; let idx = $index) {
            <circle
              [attr.cx]="60 + idx * 39"
              cy="125"
              r="6"
              [attr.fill]="qc.status === 'FAULT' ? '#ef4444' : '#f59e0b'"
              stroke="#ffffff"
              stroke-width="1"
              (click)="portData.inspectObject('CRANE', qc.id, qc)"
              class="cursor-pointer hover:r-8 transition-all"/>
          }

          <!-- Container Yard Blocks (A01 to F10) -->
          <!-- Trinity Yard -->
          <rect x="50" y="160" width="700" height="280" fill="#0f172a" stroke="#334155" rx="8"/>
          <text x="60" y="180" fill="#94a3b8" font-size="11" font-weight="bold">TRINITY CONTAINER YARD (BLOCKS A - D)</text>

          @for (block of portData.yardBlocks().slice(0, 30); track block.id; let idx = $index) {
            <g
              (click)="portData.inspectObject('YARD_BLOCK', block.id, block)"
              class="cursor-pointer hover:opacity-90">
              <rect
                [attr.x]="60 + (idx % 6) * 110"
                [attr.y]="195 + Math.floor(idx / 6) * 45"
                width="98"
                height="38"
                rx="4"
                fill="#1e293b"
                [attr.stroke]="block.type === 'REEFER' ? '#06b6d4' : block.type === 'HAZARDOUS' ? '#f59e0b' : '#3b82f6'"
                stroke-width="1.5"/>
              <text [attr.x]="68 + (idx % 6) * 110" [attr.y]="212 + Math.floor(idx / 6) * 45" fill="#f8fafc" font-size="9" font-weight="bold">{{ block.name }}</text>
              <text [attr.x]="68 + (idx % 6) * 110" [attr.y]="225 + Math.floor(idx / 6) * 45" fill="#94a3b8" font-size="8">{{ block.currentTeu }} TEU</text>
            </g>
          }

          <!-- Berths 8 & 9 Yard -->
          <rect x="770" y="160" width="380" height="280" fill="#064e3b" stroke="#047857" rx="8"/>
          <text x="780" y="180" fill="#a7f3d0" font-size="11" font-weight="bold">BERTHS 8 & 9 HIGH-DENSITY AUTOMATED YARD</text>

          @for (block of portData.yardBlocks().slice(30, 48); track block.id; let idx = $index) {
            <g
              (click)="portData.inspectObject('YARD_BLOCK', block.id, block)"
              class="cursor-pointer hover:opacity-90">
              <rect
                [attr.x]="780 + (idx % 3) * 120"
                [attr.y]="195 + Math.floor(idx / 3) * 45"
                width="110"
                height="38"
                rx="4"
                fill="#022c22"
                stroke="#10b981"
                stroke-width="1.5"/>
              <text [attr.x]="788 + (idx % 3) * 120" [attr.y]="212 + Math.floor(idx / 3) * 45" fill="#f8fafc" font-size="9" font-weight="bold">{{ block.name }}</text>
              <text [attr.x]="788 + (idx % 3) * 120" [attr.y]="225 + Math.floor(idx / 3) * 45" fill="#34d399" font-size="8">{{ block.currentTeu }} TEU</text>
            </g>
          }

          <!-- Rail Terminals (North, Central, South) -->
          <rect x="50" y="460" width="1100" height="80" fill="#1e1b4b" stroke="#6366f1" rx="8"/>
          <text x="60" y="480" fill="#c7d2fe" font-size="11" font-weight="bold">PORT DEDICATED RAIL TERMINALS (NORTH, CENTRAL & SOUTH INTERMODAL)</text>

          <!-- Rail Tracks -->
          <line x1="60" y1="500" x2="1130" y2="500" stroke="#818cf8" stroke-width="3" stroke-dasharray="8 4"/>
          <line x1="60" y1="520" x2="1130" y2="520" stroke="#818cf8" stroke-width="3" stroke-dasharray="8 4"/>

          <!-- Trains on Tracks -->
          <g (click)="portData.inspectObject('TRAIN', 'TRN-101', portData.trains()[0])" class="cursor-pointer">
            <rect x="120" y="492" width="280" height="16" rx="3" fill="#4f46e5" stroke="#a5b4fc"/>
            <text x="130" y="504" fill="#ffffff" font-size="9" font-weight="bold">TRAIN 4M52 → DAVENTRY (LOADED 56 TEU)</text>
          </g>

          <g (click)="portData.inspectObject('TRAIN', 'TRN-102', portData.trains()[1])" class="cursor-pointer">
            <rect x="450" y="512" width="310" height="16" rx="3" fill="#4338ca" stroke="#c7d2fe"/>
            <text x="460" y="524" fill="#ffffff" font-size="9" font-weight="bold">TRAIN 4M88 → BIRMINGHAM (LOADED 64 TEU)</text>
          </g>

          <!-- CBS Main Road Gates & Warehouses -->
          <rect x="50" y="560" width="700" height="70" fill="#1e293b" stroke="#f59e0b" rx="8"/>
          <text x="60" y="580" fill="#fcd34d" font-size="11" font-weight="bold">CONTAINER BOOKING SYSTEM (CBS) INBOUND GATES 01 - 08</text>

          @for (lane of portData.gateLanes(); track lane.id; let idx = $index) {
            <g class="cursor-pointer" (click)="portData.inspectObject('GATE', lane.id, lane)">
              <rect [attr.x]="60 + idx * 82" y="590" width="75" height="30" rx="3" fill="#0f172a" stroke="#f59e0b"/>
              <text [attr.x]="65 + idx * 82" y="604" fill="#f8fafc" font-size="8" font-weight="bold">GATE 0{{ idx + 1 }}</text>
              <text [attr.x]="65 + idx * 82" y="615" fill="#fcd34d" font-size="7">Q: {{ lane.queueLength }} trucks</text>
            </g>
          }

          <!-- Logistics Warehouses & Support Facilities -->
          <rect x="770" y="560" width="380" height="70" fill="#1e293b" stroke="#64748b" rx="8"/>
          <text x="780" y="580" fill="#e2e8f0" font-size="11" font-weight="bold">SUPPORT, WAREHOUSING & MAINTENANCE BAYS</text>
          <text x="780" y="605" fill="#94a3b8" font-size="9">Solas VGM Scale 01 & 02 · Reefer Monitoring Bay · AGV Charging Station</text>
        </svg>
      </div>
    </div>
  `,
})
export class Port2dMapView {
  readonly portData = inject(PortData);
  readonly Math = Math;
}
