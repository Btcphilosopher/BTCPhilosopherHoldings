import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { YardBlock } from '../../../server-engine/types';
import { PortData } from '../../services/port-data';

@Component({
  selector: 'app-yard-os-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono">
      <!-- Title & Optimiser Action -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div>
          <h2 class="text-sm font-bold uppercase tracking-wider text-slate-100 flex items-center gap-2">
            <mat-icon class="text-amber-400">grid_view</mat-icon>
            Terminal Yard Operating System & Stacking Optimiser
          </h2>
          <p class="text-xs text-slate-400 mt-0.5 font-sans">
            Grid stack visualizer with rehandle minimization and pre-positioning algorithms
          </p>
        </div>

        <button
          (click)="runYardOptimiser()"
          class="px-3.5 py-2 rounded bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs uppercase transition-colors flex items-center gap-1.5 shadow-md">
          <mat-icon class="!w-4 !h-4 !text-base">auto_fix_high</mat-icon>
          Run Yard Rehandle Optimiser
        </button>
      </div>

      <!-- Yard Optimization Impact Card -->
      @if (optimiserResult(); as opt) {
        <div class="bg-gradient-to-r from-amber-950/80 via-slate-900 to-slate-900 border border-amber-800/80 rounded-xl p-4 shadow-lg flex flex-wrap items-center justify-between gap-4">
          <div class="flex items-center gap-3">
            <mat-icon class="text-amber-400 !w-8 !h-8 !text-3xl">check_circle</mat-icon>
            <div>
              <h3 class="text-xs font-bold uppercase text-amber-300">YARD REHANDLE OPTIMISER EXECUTED</h3>
              <p class="text-[11px] font-sans text-slate-300">Containers re-stacked based on collection appointments and rail departures.</p>
            </div>
          </div>

          <div class="flex items-center gap-6 text-xs">
            <div>
              <span class="text-slate-400 text-[10px] block">REHANDLES SAVED</span>
              <span class="text-emerald-400 font-extrabold text-base">{{ opt.rehandlesSaved }} moves</span>
            </div>
            <div>
              <span class="text-slate-400 text-[10px] block">TRAVEL DISTANCE</span>
              <span class="text-cyan-400 font-extrabold text-base">-{{ opt.distanceReducedKm }} km</span>
            </div>
            <div>
              <span class="text-slate-400 text-[10px] block">NEW OCCUPANCY</span>
              <span class="text-amber-400 font-extrabold text-base">{{ opt.newOccupancyPercent }}%</span>
            </div>
          </div>
        </div>
      }

      <!-- Yard Grid Visualizer -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4 shadow-sm">
        <div class="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 gap-2">
          <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2">
            <mat-icon class="text-cyan-400">view_compact</mat-icon>
            Container Stack Block Grid (Trinity & Berths 8/9)
          </h3>

          <div class="flex items-center gap-3 text-[11px] text-slate-400">
            <span class="flex items-center gap-1"><span class="w-3 h-3 rounded bg-blue-600"></span> Import</span>
            <span class="flex items-center gap-1"><span class="w-3 h-3 rounded bg-amber-500"></span> Export</span>
            <span class="flex items-center gap-1"><span class="w-3 h-3 rounded bg-cyan-500"></span> Reefer</span>
            <span class="flex items-center gap-1"><span class="w-3 h-3 rounded bg-rose-500"></span> Hazardous</span>
          </div>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 lg:grid-cols-10 gap-2">
          @for (block of portData.yardBlocks(); track block.id) {
            <div
              (click)="portData.inspectObject('YARD_BLOCK', block.id, block)"
              class="p-2 rounded bg-slate-950 border border-slate-800 hover:border-cyan-500 cursor-pointer transition-colors text-xs flex flex-col justify-between h-20">
              <div class="flex justify-between items-center text-[10px]">
                <span class="font-bold text-slate-200">{{ block.name.replace('Yard Block ', '') }}</span>
                <span class="w-2 h-2 rounded-full" [class.bg-cyan-400]="block.type === 'REEFER'" [class.bg-rose-400]="block.type === 'HAZARDOUS'" [class.bg-amber-400]="block.type === 'EXPORT'" [class.bg-blue-400]="block.type === 'IMPORT'"></span>
              </div>

              <div class="my-1">
                <div class="flex justify-between text-[10px] text-slate-400 mb-0.5">
                  <span>{{ Math.round((block.currentTeu / block.capacityTeu) * 100) }}%</span>
                  <span>{{ block.currentTeu }} TEU</span>
                </div>
                <div class="w-full h-1.5 bg-slate-800 rounded overflow-hidden">
                  <div
                    class="h-full rounded"
                    [class.bg-emerald-400]="block.currentTeu < 600"
                    [class.bg-amber-400]="block.currentTeu >= 600 && block.currentTeu < 720"
                    [class.bg-rose-400]="block.currentTeu >= 720"
                    [style.width.%]="(block.currentTeu / block.capacityTeu) * 100">
                  </div>
                </div>
              </div>

              <div class="text-[9px] text-slate-500 uppercase truncate">
                {{ block.type }}
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Rehandle Retrieval Simulator -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <div class="border-b border-slate-800 pb-3 flex items-center justify-between">
          <div>
            <h3 class="font-bold text-sm text-slate-100 uppercase tracking-wider flex items-center gap-2">
              <mat-icon class="text-rose-400">alt_route</mat-icon>
              Container Retrieval & Rehandle Simulator
            </h3>
            <p class="text-xs text-slate-400 font-sans mt-0.5">Simulate unstacking steps required to reach bottom container</p>
          </div>
          <button (click)="stepRehandleSim()" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs">
            Simulate Next Unstack Step
          </button>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs text-center">
          <div class="bg-slate-950 p-3 rounded border border-slate-800">
            <div class="text-slate-500 text-[10px]">STEP 1</div>
            <div class="text-slate-200 font-bold mt-1">TARGET CONTAINER</div>
            <div class="text-cyan-400 font-mono text-[11px] mt-0.5">GBFX-300142-2</div>
          </div>
          <div class="bg-slate-950 p-3 rounded border border-slate-800">
            <div class="text-slate-500 text-[10px]">STEP 2</div>
            <div class="text-slate-200 font-bold mt-1">STACK ACCESS</div>
            <div class="text-amber-400 font-mono text-[11px] mt-0.5">Tier 1 (Bottom)</div>
          </div>
          <div class="bg-slate-950 p-3 rounded border border-amber-800 bg-amber-950/20">
            <div class="text-amber-400 text-[10px] font-bold">STEP 3</div>
            <div class="text-amber-300 font-bold mt-1">BLOCKING CONTAINERS</div>
            <div class="text-amber-400 font-mono text-[11px] mt-0.5">3 Containers Above</div>
          </div>
          <div class="bg-slate-950 p-3 rounded border border-slate-800">
            <div class="text-slate-500 text-[10px]">STEP 4</div>
            <div class="text-slate-200 font-bold mt-1">RTG REHANDLES</div>
            <div class="text-rose-400 font-mono text-[11px] mt-0.5">3 Unstack Moves</div>
          </div>
          <div class="bg-slate-950 p-3 rounded border border-slate-800">
            <div class="text-slate-500 text-[10px]">STEP 5</div>
            <div class="text-slate-200 font-bold mt-1">GATE / RAIL DISPATCH</div>
            <div class="text-emerald-400 font-mono text-[11px] mt-0.5">Cleared for Gate-Out</div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class YardOsView {
  readonly portData = inject(PortData);
  readonly Math = Math;
  readonly optimiserResult = signal<{ rehandlesSaved: number; distanceReducedKm: number; newOccupancyPercent: number } | null>(null);

  runYardOptimiser() {
    this.portData.replanYard().subscribe(res => {
      this.optimiserResult.set(res);
      this.portData.refreshAllData();
    });
  }

  stepRehandleSim() {
    this.portData.refreshAllData();
  }
}
