import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { NavView, PortData } from '../services/port-data';

@Component({
  selector: 'app-header-nav',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-[#0F172A] border-b border-slate-800 text-slate-100 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 sticky top-0 z-40 shadow-lg">
      <!-- Zone 1: Single-element Brand Wordmark -->
      <div class="flex items-center gap-3">
        <a (click)="portData.setView('CONTROL_ROOM')" class="flex items-center gap-2 cursor-pointer text-base font-extrabold tracking-tight text-white hover:text-cyan-400 transition-colors">
          <div class="w-7 h-7 rounded bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-sm font-mono font-bold text-xs">
            P4
          </div>
          <span class="font-mono text-sm tracking-wider">FELIXSTOWE PORT 4.0</span>
        </a>
        <span class="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">
          SYNTHETIC OS
        </span>
      </div>

      <!-- Zone 2: Navigation Links -->
      <nav class="hidden xl:flex items-center gap-1 text-xs font-medium text-slate-300 overflow-x-auto max-w-4xl py-1">
        <button
          (click)="portData.setView('CONTROL_ROOM')"
          [class]="getNavClass('CONTROL_ROOM')">
          <mat-icon class="!w-4 !h-4 !text-base">dashboard</mat-icon>
          <span>Control Room</span>
        </button>

        <button
          (click)="portData.setView('DIGITAL_TWIN_3D')"
          [class]="getNavClass('DIGITAL_TWIN_3D')">
          <mat-icon class="!w-4 !h-4 !text-base">3d_rotation</mat-icon>
          <span>3D Twin</span>
        </button>

        <button
          (click)="portData.setView('PORT_2D_MAP')"
          [class]="getNavClass('PORT_2D_MAP')">
          <mat-icon class="!w-4 !h-4 !text-base">map</mat-icon>
          <span>2D Map</span>
        </button>

        <button
          (click)="portData.setView('VESSELS_BERTHS')"
          [class]="getNavClass('VESSELS_BERTHS')">
          <mat-icon class="!w-4 !h-4 !text-base">directions_boat</mat-icon>
          <span>Vessels & Berths</span>
        </button>

        <button
          (click)="portData.setView('YARD_OS')"
          [class]="getNavClass('YARD_OS')">
          <mat-icon class="!w-4 !h-4 !text-base">grid_view</mat-icon>
          <span>Yard OS</span>
        </button>

        <button
          (click)="portData.setView('FLEET_EQUIPMENT')"
          [class]="getNavClass('FLEET_EQUIPMENT')">
          <mat-icon class="!w-4 !h-4 !text-base">precision_manufacturing</mat-icon>
          <span>Equipment & Fleet</span>
        </button>

        <button
          (click)="portData.setView('RAIL_OS')"
          [class]="getNavClass('RAIL_OS')">
          <mat-icon class="!w-4 !h-4 !text-base">train</mat-icon>
          <span>Rail OS</span>
        </button>

        <button
          (click)="portData.setView('ROAD_GATES')"
          [class]="getNavClass('ROAD_GATES')">
          <mat-icon class="!w-4 !h-4 !text-base">local_shipping</mat-icon>
          <span>Road & Gates</span>
        </button>

        <button
          (click)="portData.setView('INLAND_OPTIMISATION')"
          [class]="getNavClass('INLAND_OPTIMISATION')">
          <mat-icon class="!w-4 !h-4 !text-base">alt_route</mat-icon>
          <span>Intermodal</span>
        </button>

        <button
          (click)="portData.setView('REEFER_SPECIAL')"
          [class]="getNavClass('REEFER_SPECIAL')">
          <mat-icon class="!w-4 !h-4 !text-base">ac_unit</mat-icon>
          <span>Reefer & Cargo</span>
        </button>

        <button
          (click)="portData.setView('ENERGY_EMISSIONS')"
          [class]="getNavClass('ENERGY_EMISSIONS')">
          <mat-icon class="!w-4 !h-4 !text-base">bolt</mat-icon>
          <span>Energy</span>
        </button>

        <button
          (click)="portData.setView('SIMULATION_SCENARIOS')"
          [class]="getNavClass('SIMULATION_SCENARIOS')">
          <mat-icon class="!w-4 !h-4 !text-base">science</mat-icon>
          <span>Scenarios</span>
        </button>

        <button
          (click)="portData.setView('AI_PORT_PLANNER')"
          [class]="getNavClass('AI_PORT_PLANNER')">
          <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">psychology</mat-icon>
          <span class="text-cyan-300 font-semibold">AI Planner</span>
        </button>
      </nav>

      <!-- Dropdown for smaller viewports -->
      <div class="xl:hidden flex items-center">
        <select
          [value]="portData.activeView()"
          (change)="onSelectView($event)"
          class="bg-slate-800 text-slate-200 border border-slate-700 rounded px-2 py-1 text-xs font-mono focus:outline-none focus:border-cyan-500">
          <option value="CONTROL_ROOM">1. Control Room</option>
          <option value="DIGITAL_TWIN_3D">2. 3D Digital Twin</option>
          <option value="PORT_2D_MAP">3. 2D Vector Map</option>
          <option value="VESSELS_BERTHS">4. Vessels & Berths</option>
          <option value="YARD_OS">5. Yard Operating System</option>
          <option value="FLEET_EQUIPMENT">6. Fleet & Equipment</option>
          <option value="RAIL_OS">7. Rail Subsystem</option>
          <option value="ROAD_GATES">8. Road & CBS Gates</option>
          <option value="INLAND_OPTIMISATION">9. Intermodal Optimiser</option>
          <option value="CUSTOMERS_DOCUMENTS">10. Customers & SOLAS VGM</option>
          <option value="REEFER_SPECIAL">11. Reefer & Special Cargo</option>
          <option value="ENERGY_EMISSIONS">12. Energy & Electrification</option>
          <option value="SIMULATION_SCENARIOS">13. What-If Scenarios</option>
          <option value="AI_PORT_PLANNER">14. AI Port Planner</option>
        </select>
      </div>

      <!-- Zone 3: Simulation Controls & Status -->
      <div class="flex items-center gap-2">
        <!-- Simulation Clock -->
        <div class="hidden sm:flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs font-mono text-cyan-300">
          <mat-icon class="!w-3.5 !h-3.5 !text-sm text-cyan-400">schedule</mat-icon>
          <span>{{ formatSimTime(portData.simulationState().simulatedTime) }}</span>
        </div>

        <!-- Speed Selector -->
        <div class="flex items-center bg-slate-900 border border-slate-800 rounded p-0.5 text-xs font-mono">
          <button
            (click)="portData.toggleSimulation(true, 1)"
            [class]="portData.simulationState().speedMultiplier === 1 && portData.simulationState().running ? 'bg-cyan-600 text-white rounded px-1.5 py-0.5' : 'text-slate-400 hover:text-white px-1.5 py-0.5'">
            1x
          </button>
          <button
            (click)="portData.toggleSimulation(true, 10)"
            [class]="portData.simulationState().speedMultiplier === 10 && portData.simulationState().running ? 'bg-cyan-600 text-white rounded px-1.5 py-0.5' : 'text-slate-400 hover:text-white px-1.5 py-0.5'">
            10x
          </button>
          <button
            (click)="portData.toggleSimulation(true, 50)"
            [class]="portData.simulationState().speedMultiplier === 50 && portData.simulationState().running ? 'bg-cyan-600 text-white rounded px-1.5 py-0.5' : 'text-slate-400 hover:text-white px-1.5 py-0.5'">
            50x
          </button>
        </div>

        <!-- Pause / Play -->
        <button
          (click)="togglePause()"
          class="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded px-2 py-1 text-xs font-mono transition-colors">
          <mat-icon class="!w-4 !h-4 !text-base">{{ portData.simulationState().running ? 'pause' : 'play_arrow' }}</mat-icon>
          <span class="hidden sm:inline">{{ portData.simulationState().running ? 'PAUSE' : 'RUN' }}</span>
        </button>
      </div>
    </header>
  `,
})
export class HeaderNavComponent {
  readonly portData = inject(PortData);

  getNavClass(view: NavView): string {
    const isCurrent = this.portData.activeView() === view;
    if (isCurrent) {
      return 'flex items-center gap-1.5 px-2.5 py-1 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800/80 transition-colors whitespace-nowrap shrink-0 font-semibold';
    }
    return 'flex items-center gap-1.5 px-2.5 py-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 transition-colors whitespace-nowrap shrink-0';
  }

  onSelectView(event: Event) {
    const target = event.target as HTMLSelectElement;
    this.portData.setView(target.value as NavView);
  }

  togglePause() {
    this.portData.toggleSimulation(!this.portData.simulationState().running);
  }

  formatSimTime(iso: string): string {
    try {
      const d = new Date(iso);
      return d.toISOString().replace('T', ' ').substring(0, 19) + ' Z';
    } catch {
      return iso;
    }
  }
}
