import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { PortData } from '../services/port-data';

@Component({
  selector: 'app-object-inspector',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (portData.selectedObject(); as obj) {
      <div class="fixed bottom-4 right-4 z-50 w-96 max-w-[calc(100vw-2rem)] bg-[#0F172A]/95 backdrop-blur border border-slate-700/80 rounded-xl shadow-2xl overflow-hidden text-slate-100 flex flex-col max-h-[85vh]">
        <!-- Header -->
        <div class="bg-slate-900 border-b border-slate-800 p-3.5 flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span class="p-1 rounded bg-cyan-950 border border-cyan-800 text-cyan-400 font-mono text-xs font-bold uppercase">
              {{ obj.type }}
            </span>
            <span class="font-mono font-bold text-sm text-slate-100 truncate max-w-[200px]">
              {{ obj.id }}
            </span>
          </div>
          <button (click)="portData.closeObjectInspector()" class="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors">
            <mat-icon class="!w-4 !h-4 !text-base">close</mat-icon>
          </button>
        </div>

        <!-- Body Scrollable -->
        <div class="p-4 overflow-y-auto space-y-4 text-xs font-mono">
          <!-- Container Inspector -->
          @if (obj.type === 'CONTAINER') {
            <div class="grid grid-cols-2 gap-2 bg-slate-900/60 p-2.5 rounded border border-slate-800">
              <div><span class="text-slate-400">Customer:</span> <p class="text-slate-200 font-sans font-semibold">{{ obj.data.customer }}</p></div>
              <div><span class="text-slate-400">Status:</span> <p class="text-cyan-400 font-bold">{{ obj.data.status }}</p></div>
              <div><span class="text-slate-400">Type / ISO:</span> <p class="text-slate-200">{{ obj.data.type }} ({{ obj.data.isoClass }})</p></div>
              <div><span class="text-slate-400">Gross Weight:</span> <p class="text-slate-200">{{ obj.data.grossWeightKg }} kg</p></div>
              <div><span class="text-slate-400">VGM Verified:</span> <p class="text-emerald-400 font-bold">{{ obj.data.verifiedWeightKg }} kg (SOLAS)</p></div>
              <div><span class="text-slate-400">Yard Slot:</span> <p class="text-amber-300 font-bold">{{ obj.data.yardLocation }}</p></div>
              <div><span class="text-slate-400">Origin:</span> <p class="text-slate-200 truncate">{{ obj.data.origin }}</p></div>
              <div><span class="text-slate-400">Destination:</span> <p class="text-slate-200 truncate">{{ obj.data.destination }}</p></div>
            </div>

            <!-- Timeline -->
            <div>
              <h4 class="text-slate-300 font-sans font-bold text-xs uppercase tracking-wider mb-2 flex items-center gap-1">
                <mat-icon class="!w-3.5 !h-3.5 !text-sm text-cyan-400">history</mat-icon>
                Immutable Audit Thread
              </h4>
              <div class="space-y-2 border-l-2 border-slate-700 pl-3 ml-1">
                @for (evt of portData.selectedContainerTimeline(); track evt.id) {
                  <div class="relative">
                    <div class="absolute -left-[17px] top-1 w-2 h-2 rounded-full bg-cyan-400"></div>
                    <div class="flex justify-between text-[10px] text-slate-400">
                      <span>{{ evt.eventType }}</span>
                      <span>{{ evt.timestamp.substring(11, 19) }} Z</span>
                    </div>
                    <p class="text-slate-200 font-sans text-xs mt-0.5">{{ evt.details }}</p>
                  </div>
                }
              </div>
            </div>
          }

          <!-- Vessel Inspector -->
          @if (obj.type === 'VESSEL') {
            <div class="space-y-2">
              <div class="bg-slate-900 p-2.5 rounded border border-slate-800 space-y-1.5">
                <div class="flex justify-between"><span class="text-slate-400">IMO ID:</span> <span class="text-slate-200">{{ obj.data.imo }}</span></div>
                <div class="flex justify-between"><span class="text-slate-400">Operator:</span> <span class="text-cyan-400 font-bold">{{ obj.data.operator }}</span></div>
                <div class="flex justify-between"><span class="text-slate-400">Voyage:</span> <span class="text-slate-200">{{ obj.data.voyage }}</span></div>
                <div class="flex justify-between"><span class="text-slate-400">Dimensions:</span> <span class="text-slate-200">{{ obj.data.lengthM }}m x {{ obj.data.beamM }}m (Draft {{ obj.data.draftM }}m)</span></div>
                <div class="flex justify-between"><span class="text-slate-400">TEU Capacity:</span> <span class="text-amber-300 font-bold">{{ obj.data.teuCapacity }} TEU</span></div>
                <div class="flex justify-between"><span class="text-slate-400">Berth Assigned:</span> <span class="text-emerald-400 font-bold">{{ obj.data.berthId || 'ANCHOR' }}</span></div>
              </div>

              <div>
                <div class="flex justify-between text-xs mb-1">
                  <span class="text-slate-400">Discharge / Load Progress</span>
                  <span class="text-cyan-400 font-bold">{{ obj.data.progressPercent.toFixed(1) }}%</span>
                </div>
                <div class="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div class="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 rounded-full transition-all duration-300" [style.width.%]="obj.data.progressPercent"></div>
                </div>
              </div>
            </div>
          }

          <!-- Crane / Equipment Inspector -->
          @if (obj.type === 'EQUIPMENT' || obj.type === 'CRANE') {
            <div class="space-y-2 bg-slate-900 p-2.5 rounded border border-slate-800">
              <div class="flex justify-between"><span class="text-slate-400">Status:</span> <span class="text-emerald-400 font-bold">{{ obj.data.status }}</span></div>
              <div class="flex justify-between"><span class="text-slate-400">Health Index:</span> <span class="text-slate-200 font-bold">{{ obj.data.healthPercent }}%</span></div>
              <div class="flex justify-between"><span class="text-slate-400">Vibration Telemetry:</span> <span class="text-amber-300">{{ obj.data.vibrationMmS || 1.8 }} mm/s</span></div>
              <div class="flex justify-between"><span class="text-slate-400">Motor Current:</span> <span class="text-slate-200">{{ obj.data.motorCurrentA || 120 }} A</span></div>
              <div class="flex justify-between"><span class="text-slate-400">Hydraulic Pressure:</span> <span class="text-slate-200">{{ obj.data.hydraulicBar || 185 }} bar</span></div>
            </div>
          }
        </div>
      </div>
    }
  `,
})
export class ObjectInspectorComponent {
  readonly portData = inject(PortData);
}
