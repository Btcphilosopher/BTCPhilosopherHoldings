import { HttpClient } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import {
  Berth,
  Container,
  ContainerEvent,
  EquipmentVehicle,
  GateLane,
  IntermodalRouteOption,
  PortStatus,
  QuayCrane,
  SimulationState,
  Train,
  Truck,
  Vessel,
  YardBlock,
} from '../../server-engine/types';

export type NavView =
  | 'CONTROL_ROOM'
  | 'DIGITAL_TWIN_3D'
  | 'PORT_2D_MAP'
  | 'VESSELS_BERTHS'
  | 'YARD_OS'
  | 'FLEET_EQUIPMENT'
  | 'RAIL_OS'
  | 'ROAD_GATES'
  | 'INLAND_OPTIMISATION'
  | 'CUSTOMERS_DOCUMENTS'
  | 'REEFER_SPECIAL'
  | 'ENERGY_EMISSIONS'
  | 'SIMULATION_SCENARIOS'
  | 'AI_PORT_PLANNER';

@Injectable({
  providedIn: 'root',
})
export class PortData {
  private http = inject(HttpClient);

  // Core reactive signals
  readonly activeView = signal<NavView>('CONTROL_ROOM');
  readonly portStatus = signal<PortStatus | null>(null);
  readonly vessels = signal<Vessel[]>([]);
  readonly berths = signal<Berth[]>([]);
  readonly cranes = signal<QuayCrane[]>([]);
  readonly containers = signal<Container[]>([]);
  readonly yardBlocks = signal<YardBlock[]>([]);
  readonly vehicles = signal<EquipmentVehicle[]>([]);
  readonly trains = signal<Train[]>([]);
  readonly trucks = signal<Truck[]>([]);
  readonly gateLanes = signal<GateLane[]>([]);
  readonly events = signal<ContainerEvent[]>([]);
  readonly simulationState = signal<SimulationState>({
    running: true,
    speedMultiplier: 1,
    simulatedTime: new Date().toISOString(),
    activeScenario: null,
  });

  readonly selectedContainerId = signal<string | null>(null);
  readonly selectedObject = signal<{ type: string; id: string; data: any } | null>(null);

  // Derived signals
  readonly selectedContainer = computed(() => {
    const id = this.selectedContainerId();
    if (!id) return null;
    return this.containers().find((c) => c.id === id) || null;
  });

  readonly selectedContainerTimeline = signal<ContainerEvent[]>([]);

  private ws: WebSocket | null = null;

  constructor() {
    this.refreshAllData();
    this.initWebSocket();
  }

  public setView(view: NavView) {
    this.activeView.set(view);
  }

  public refreshAllData() {
    this.http.get<PortStatus>('/api/port').subscribe((res) => this.portStatus.set(res));
    this.http.get<Vessel[]>('/api/vessels').subscribe((res) => this.vessels.set(res));
    this.http.get<Berth[]>('/api/berths').subscribe((res) => this.berths.set(res));
    this.http.get<QuayCrane[]>('/api/cranes').subscribe((res) => this.cranes.set(res));
    this.http.get<Container[]>('/api/containers').subscribe((res) => this.containers.set(res));
    this.http.get<YardBlock[]>('/api/yard').subscribe((res) => this.yardBlocks.set(res));
    this.http.get<EquipmentVehicle[]>('/api/equipment').subscribe((res) => this.vehicles.set(res));
    this.http.get<Train[]>('/api/trains').subscribe((res) => this.trains.set(res));
    this.http.get<Truck[]>('/api/trucks').subscribe((res) => this.trucks.set(res));
    this.http.get<GateLane[]>('/api/gates').subscribe((res) => this.gateLanes.set(res));
    this.http.get<ContainerEvent[]>('/api/containers/all/timeline').subscribe({
      next: (res) => this.events.set(res),
      error: () => {
        // Fallback to empty if endpoint not specific
      },
    });
  }

  private initWebSocket() {
    if (typeof window === 'undefined') return;
    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      this.ws = new WebSocket(`${protocol}//${window.location.host}/api/live-stream`);

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'SIM_TICK') {
            if (data.portStatus) this.portStatus.set(data.portStatus);
            if (data.simulationState) this.simulationState.set(data.simulationState);
            if (data.events && Array.isArray(data.events)) {
              this.events.update((prev) => [...data.events, ...prev].slice(0, 100));
            }
          }
        } catch (e) {
          // ignore
        }
      };

      this.ws.onerror = () => {
        // Silent fallback to standard polling
      };
    } catch (e) {
      // ignore
    }
  }

  public selectContainer(id: string) {
    this.selectedContainerId.set(id);
    this.http.get<ContainerEvent[]>(`/api/containers/${id}/timeline`).subscribe((timeline) => {
      this.selectedContainerTimeline.set(timeline);
    });
    const c = this.containers().find((item) => item.id === id);
    if (c) {
      this.selectedObject.set({ type: 'CONTAINER', id: c.id, data: c });
    }
  }

  public inspectObject(type: string, id: string, data: any) {
    this.selectedObject.set({ type, id, data });
  }

  public closeObjectInspector() {
    this.selectedObject.set(null);
  }

  public toggleSimulation(running?: boolean, speed?: 1 | 10 | 50 | 100) {
    const endpoint = running === false ? '/api/simulation/pause' : '/api/simulation/start';
    this.http.post<SimulationState>(endpoint, { speedMultiplier: speed }).subscribe((res) => {
      this.simulationState.set(res);
    });
  }

  public runScenario(scenarioId: string) {
    this.http.post<{ success: boolean; scenario: string }>('/api/scenarios', { scenarioId }).subscribe(() => {
      this.refreshAllData();
    });
  }

  public replanYard() {
    return this.http.post<{ rehandlesSaved: number; distanceReducedKm: number; newOccupancyPercent: number }>('/api/yard/replan', {});
  }

  public askAiPlanner(query: string) {
    return this.http.post<{ answer: string; recommendedActions: string[]; metricsImpact: Record<string, string> }>('/api/ai-planner', { query });
  }

  public getIntermodalRouting(destination: string, containerCount: number) {
    return this.http.post<IntermodalRouteOption[]>('/api/optimisation/run', { destination, containerCount });
  }
}
