import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { createServer } from 'node:http';
import { join } from 'node:path';
import { WebSocket, WebSocketServer } from 'ws';
import { askPortAiPlanner } from './server-engine/gemini-ai';
import { SimulationStore } from './server-engine/simulation-store';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();
const store = new SimulationStore();

// REST API Endpoints
app.get('/api/port', (req, res) => {
  res.json(store.getPortStatus());
});

app.get('/api/vessels', (req, res) => {
  res.json(store.getVessels());
});

app.get('/api/vessels/:id', (req, res) => {
  const v = store.getVesselById(req.params.id);
  if (!v) {
    res.status(404).json({ error: 'Vessel not found' });
    return;
  }
  res.json(v);
});

app.get('/api/berths', (req, res) => {
  res.json(store.getBerths());
});

app.get('/api/cranes', (req, res) => {
  res.json(store.getCranes());
});

app.get('/api/containers', (req, res) => {
  res.json(store.getContainers());
});

app.get('/api/containers/:id', (req, res) => {
  const c = store.getContainerById(req.params.id);
  if (!c) {
    res.status(404).json({ error: 'Container not found' });
    return;
  }
  res.json(c);
});

app.get('/api/containers/:id/timeline', (req, res) => {
  res.json(store.getContainerEvents(req.params.id));
});

app.get('/api/yard', (req, res) => {
  res.json(store.getYardBlocks());
});

app.get('/api/trucks', (req, res) => {
  // Synthesize or return truck list
  res.json([
    { id: 'TRK-901', haulier: 'Maritime Transport', driverNameSynthetic: 'John Davies', containerId: 'GBFX-300002-2', appointmentTime: '09:00', eta: '08:55', gateLane: 'GATE-01', status: 'IN_YARD' },
    { id: 'TRK-902', haulier: 'Turners Soham', driverNameSynthetic: 'Sarah Jenkins', containerId: 'GBFX-300004-4', appointmentTime: '09:15', eta: '09:10', gateLane: 'GATE-02', status: 'AT_GATE' },
    { id: 'TRK-903', haulier: 'Goldstar Transport', driverNameSynthetic: 'Robert Smith', containerId: 'GBFX-300006-6', appointmentTime: '09:30', eta: '09:40', gateLane: 'GATE-03', status: 'QUEUED' }
  ]);
});

app.get('/api/gates', (req, res) => {
  res.json(store.getGateLanes());
});

app.get('/api/trains', (req, res) => {
  res.json(store.getTrains());
});

app.get('/api/rail', (req, res) => {
  res.json({
    terminals: [
      { id: 'North Rail Terminal', tracks: 4, cranes: 2, dailyCapacityTrains: 22 },
      { id: 'Central Rail Terminal', tracks: 4, cranes: 2, dailyCapacityTrains: 20 },
      { id: 'South Rail Terminal', tracks: 3, cranes: 2, dailyCapacityTrains: 16 }
    ],
    trains: store.getTrains()
  });
});

app.get('/api/equipment', (req, res) => {
  res.json(store.getVehicles());
});

app.get('/api/maintenance', (req, res) => {
  const vehicles = store.getVehicles();
  const degraded = vehicles.filter(v => v.healthPercent < 80 || v.vibrationMmS > 3.0);
  res.json({
    totalTracked: vehicles.length,
    degradedCount: degraded.length,
    anomalies: degraded,
    scheduledMaintenance: [
      { equipmentId: 'QC-13', type: 'Quay Crane', date: '2026-10-02', task: 'Main Hoist Wire Replacement' },
      { equipmentId: 'RTG-07', type: 'RTG Crane', date: '2026-10-01', task: 'Hydraulic Cylinder Seal Repair' }
    ]
  });
});

app.get('/api/energy', (req, res) => {
  res.json({
    quayCranesKwh: 34200,
    rtgsKwh: 18400,
    agvsKwh: 9200,
    buildingsKwh: 6100,
    reefersKwh: 14800,
    totalKwh: 82700,
    kwhPerTeu: 24.3,
    co2eTonnes24h: 31.2,
    dieselFleetCo2eTonnes: 45.8,
    hybridFleetCo2eTonnes: 28.4,
    electricFleetCo2eTonnes: 12.1
  });
});

app.get('/api/scenarios', (req, res) => {
  res.json([
    { id: 'MEGA_VESSEL', name: 'Signature Demo 1: Mega Vessel (24,000 TEU)', description: 'Simulate arrival of RQ-MSC-SYNTH-24000 with 8-crane allocation.' },
    { id: 'PORT_BOTTLENECK', name: 'Signature Demo 2: Yard Saturation Surge', description: 'Surge yard utilization to 89% and execute rail-shift optimization.' },
    { id: 'RAIL_FIRST', name: 'Signature Demo 3: Rail-First Intermodal Trade-off', description: 'Optimise 1,000 Midlands container movements comparing Road vs Rail vs Intermodal.' },
    { id: 'CRANE_FAILURE', name: 'Signature Demo 4: Multi-Crane Outage', description: 'Simulate 3 Quay Crane failures at Trinity Berth 1 and recalculate berth schedules.' }
  ]);
});

app.get('/api/optimisation', (req, res) => {
  res.json(store.calculateIntermodalRouting('Daventry DIRFT', 100));
});

// Commands
app.post('/api/appointments', (req, res) => {
  const { containerId, haulier, driverName, slotTime } = req.body;
  res.json({
    appointmentId: `CBS-${Math.floor(100000 + Math.random() * 900000)}`,
    status: 'CONFIRMED',
    containerId: containerId || 'GBFX-300001-1',
    gateLaneAssigned: 'GATE-02',
    slotTime: slotTime || '2026-10-01T10:00:00Z',
    securityVerified: true
  });
});

app.post('/api/scenarios', (req, res) => {
  const { scenarioId } = req.body;
  const result = store.runScenario(scenarioId || 'MEGA_VESSEL');
  res.json(result);
});

app.post('/api/optimisation/run', (req, res) => {
  const { destination, containerCount } = req.body;
  res.json(store.calculateIntermodalRouting(destination || 'Daventry DIRFT', containerCount || 100));
});

app.post('/api/simulation/start', (req, res) => {
  store.setSimulationState(true, req.body.speedMultiplier);
  res.json(store.getSimulationState());
});

app.post('/api/simulation/pause', (req, res) => {
  store.setSimulationState(false);
  res.json(store.getSimulationState());
});

app.post('/api/yard/replan', (req, res) => {
  res.json(store.replanYard());
});

app.post('/api/rail/replan', (req, res) => {
  res.json({ success: true, reallocatedTeu: 450, costSavingGbp: 38000, co2eReductionTonnes: 54 });
});

app.post('/api/ai-planner', async (req, res) => {
  const { query } = req.body;
  const portStatus = store.getPortStatus();
  const aiResult = await askPortAiPlanner(query || 'What is the current bottleneck?', portStatus);
  res.json(aiResult);
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

const server = createServer(app);
const wss = new WebSocketServer({ noServer: true });

// WebSocket connection broadcasting live simulation events
wss.on('connection', (ws: WebSocket) => {
  const interval = setInterval(() => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'SIM_TICK',
        portStatus: store.getPortStatus(),
        simulationState: store.getSimulationState(),
        events: store.getContainerEvents().slice(0, 5)
      }));
    }
  }, 2000);

  ws.on('close', () => {
    clearInterval(interval);
  });
});

// Handle WebSocket upgrade before Angular SSR
server.on('upgrade', (request, socket, head) => {
  if (request.url === '/api/live-stream' || request.headers.upgrade?.toLowerCase() === 'websocket') {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  } else {
    socket.destroy();
  }
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  server.listen(port, () => {
    console.log(`FELIXSTOWE PORT 4.0 Operating System listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
