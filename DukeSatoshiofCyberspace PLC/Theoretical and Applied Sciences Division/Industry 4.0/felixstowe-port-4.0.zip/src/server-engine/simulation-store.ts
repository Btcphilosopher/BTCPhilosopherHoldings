import {
  Berth,
  Container,
  ContainerEvent,
  CraneStatus,
  EquipmentVehicle,
  GateLane,
  IntermodalRouteOption,
  PortStatus,
  QuayCrane,
  Train,
  Truck,
  Vessel,
  YardBlock,
} from './types';

export class SimulationStore {
  private currentTime = new Date('2026-10-01T08:00:00Z');
  private isRunning = true;
  private speedMultiplier: 1 | 10 | 50 | 100 = 1;
  private activeScenario: string | null = null;

  // Domain state collections
  private vessels: Map<string, Vessel> = new Map();
  private berths: Map<string, Berth> = new Map();
  private cranes: Map<string, QuayCrane> = new Map();
  private containers: Map<string, Container> = new Map();
  private containerEvents: ContainerEvent[] = [];
  private yardBlocks: Map<string, YardBlock> = new Map();
  private vehicles: Map<string, EquipmentVehicle> = new Map();
  private trains: Map<string, Train> = new Map();
  private trucks: Map<string, Truck> = new Map();
  private gateLanes: Map<string, GateLane> = new Map();

  constructor() {
    this.seedInitialData();
    this.startSimulationLoop();
  }

  private seedInitialData() {
    // 1. Berths (Trinity Terminal + Berths 8 & 9)
    const berthDefs: Berth[] = [
      { id: 'B-TRIN-1', name: 'Trinity Berth 1', terminal: 'Trinity Terminal', lengthM: 350, maxDraftM: 14.5, currentVesselId: 'VES-001', status: 'OCCUPIED', assignedCranes: ['QC-01', 'QC-02', 'QC-03'] },
      { id: 'B-TRIN-2', name: 'Trinity Berth 2', terminal: 'Trinity Terminal', lengthM: 360, maxDraftM: 15.0, currentVesselId: 'VES-002', status: 'OCCUPIED', assignedCranes: ['QC-04', 'QC-05', 'QC-06'] },
      { id: 'B-TRIN-3', name: 'Trinity Berth 3', terminal: 'Trinity Terminal', lengthM: 380, maxDraftM: 15.5, currentVesselId: null, status: 'AVAILABLE', assignedCranes: [] },
      { id: 'B-TRIN-4', name: 'Trinity Berth 4', terminal: 'Trinity Terminal', lengthM: 380, maxDraftM: 15.5, currentVesselId: 'VES-003', status: 'OCCUPIED', assignedCranes: ['QC-07', 'QC-08', 'QC-09'] },
      { id: 'B-TRIN-5', name: 'Trinity Berth 5', terminal: 'Trinity Terminal', lengthM: 400, maxDraftM: 16.0, currentVesselId: null, status: 'AVAILABLE', assignedCranes: [] },
      { id: 'B-TRIN-6', name: 'Trinity Berth 6', terminal: 'Trinity Terminal', lengthM: 400, maxDraftM: 16.0, currentVesselId: 'VES-004', status: 'OCCUPIED', assignedCranes: ['QC-10', 'QC-11', 'QC-12'] },
      { id: 'B-TRIN-7', name: 'Trinity Berth 7', terminal: 'Trinity Terminal', lengthM: 400, maxDraftM: 16.0, currentVesselId: null, status: 'AVAILABLE', assignedCranes: [] },
      { id: 'B-BERTH-8', name: 'Berth 8 (Deepwater)', terminal: 'Berths 8 & 9', lengthM: 400, maxDraftM: 18.0, currentVesselId: 'VES-005', status: 'OCCUPIED', assignedCranes: ['QC-21', 'QC-22', 'QC-23', 'QC-24'] },
      { id: 'B-BERTH-9', name: 'Berth 9 (Deepwater Mega)', terminal: 'Berths 8 & 9', lengthM: 400, maxDraftM: 18.0, currentVesselId: 'VES-006', status: 'OCCUPIED', assignedCranes: ['QC-25', 'QC-26', 'QC-27', 'QC-28'] },
    ];
    berthDefs.forEach(b => this.berths.set(b.id, b));

    // 2. Quay Cranes (28 cranes total: QC-01 to QC-28)
    for (let i = 1; i <= 28; i++) {
      const qcId = `QC-${i.toString().padStart(2, '0')}`;
      let berthId = 'B-TRIN-1';
      if (i >= 4 && i <= 6) berthId = 'B-TRIN-2';
      else if (i >= 7 && i <= 9) berthId = 'B-TRIN-4';
      else if (i >= 10 && i <= 12) berthId = 'B-TRIN-6';
      else if (i >= 13 && i <= 20) berthId = 'B-TRIN-7';
      else if (i >= 21 && i <= 24) berthId = 'B-BERTH-8';
      else if (i >= 25 && i <= 28) berthId = 'B-BERTH-9';

      const crane: QuayCrane = {
        id: qcId,
        berthId,
        status: i === 13 || i === 14 ? 'MAINTENANCE' : 'LIFTING',
        movesPerHour: Math.floor(28 + Math.random() * 8),
        currentContainerId: `FEXU-${100000 + i}-9`,
        nextContainerId: `FEXU-${100100 + i}-3`,
        totalMoves24h: Math.floor(300 + Math.random() * 150),
        energyKwh: Math.floor(1200 + Math.random() * 400),
        healthPercent: Math.floor(88 + Math.random() * 12),
        liftCycleCount: 142000 + i * 850,
      };
      this.cranes.set(qcId, crane);
    }

    // 3. Vessels (17 synthetic vessels)
    const vesselDefs: Vessel[] = [
      { id: 'VES-001', imo: 'IMO9839211', name: 'MSC EVELYN', operator: 'MSC', voyage: 'FE2601A', eta: '2026-10-01T04:00:00Z', etd: '2026-10-01T22:00:00Z', lengthM: 330, beamM: 48, draftM: 13.8, teuCapacity: 14000, currentTeu: 11200, importTeu: 2100, exportTeu: 1800, reeferCount: 180, hazardousFlag: true, berthId: 'B-TRIN-1', status: 'WORKING', progressPercent: 62, assignedCranes: ['QC-01', 'QC-02', 'QC-03'] },
      { id: 'VES-002', imo: 'IMO9776432', name: 'COSCO SHIPPING UNIVERSE', operator: 'COSCO', voyage: 'CSU-992', eta: '2026-10-01T02:00:00Z', etd: '2026-10-02T04:00:00Z', lengthM: 400, beamM: 58.6, draftM: 15.2, teuCapacity: 21237, currentTeu: 18900, importTeu: 3400, exportTeu: 2900, reeferCount: 310, hazardousFlag: false, berthId: 'B-TRIN-2', status: 'WORKING', progressPercent: 41, assignedCranes: ['QC-04', 'QC-05', 'QC-06'] },
      { id: 'VES-003', imo: 'IMO9811000', name: 'EVER GIVEN SYNTH', operator: 'Evergreen', voyage: 'EG-881', eta: '2026-10-01T06:00:00Z', etd: '2026-10-02T10:00:00Z', lengthM: 400, beamM: 59, draftM: 15.5, teuCapacity: 20124, currentTeu: 17500, importTeu: 2800, exportTeu: 2200, reeferCount: 220, hazardousFlag: true, berthId: 'B-TRIN-4', status: 'WORKING', progressPercent: 35, assignedCranes: ['QC-07', 'QC-08', 'QC-09'] },
      { id: 'VES-004', imo: 'IMO9845112', name: 'CMA CGM ANTOINE', operator: 'CMA CGM', voyage: 'CMA-104', eta: '2026-10-01T01:00:00Z', etd: '2026-10-01T18:00:00Z', lengthM: 366, beamM: 51, draftM: 14.2, teuCapacity: 16000, currentTeu: 14200, importTeu: 1900, exportTeu: 1500, reeferCount: 140, hazardousFlag: false, berthId: 'B-TRIN-6', status: 'WORKING', progressPercent: 88, assignedCranes: ['QC-10', 'QC-11', 'QC-12'] },
      { id: 'VES-005', imo: 'IMO9912088', name: 'OOCL HONG KONG', operator: 'OOCL', voyage: 'OOCL-301', eta: '2026-09-30T22:00:00Z', etd: '2026-10-02T02:00:00Z', lengthM: 399.8, beamM: 58.8, draftM: 16.0, teuCapacity: 21413, currentTeu: 19800, importTeu: 3900, exportTeu: 3100, reeferCount: 290, hazardousFlag: true, berthId: 'B-BERTH-8', status: 'WORKING', progressPercent: 54, assignedCranes: ['QC-21', 'QC-22', 'QC-23', 'QC-24'] },
      { id: 'VES-006', imo: 'IMO9934110', name: 'HMM ALGECIRAS', operator: 'HMM', voyage: 'HMM-007', eta: '2026-09-30T18:00:00Z', etd: '2026-10-02T12:00:00Z', lengthM: 399.9, beamM: 61, draftM: 16.5, teuCapacity: 23964, currentTeu: 22100, importTeu: 4200, exportTeu: 3800, reeferCount: 350, hazardousFlag: false, berthId: 'B-BERTH-9', status: 'WORKING', progressPercent: 48, assignedCranes: ['QC-25', 'QC-26', 'QC-27', 'QC-28'] },
      { id: 'VES-007', imo: 'IMO9890011', name: 'MAERSK MC-KINNEY', operator: 'Maersk', voyage: 'AE10-04', eta: '2026-10-01T12:00:00Z', etd: '2026-10-02T18:00:00Z', lengthM: 399, beamM: 59, draftM: 15.0, teuCapacity: 18270, currentTeu: 16500, importTeu: 2900, exportTeu: 2400, reeferCount: 200, hazardousFlag: false, berthId: null, status: 'APPROACHING', progressPercent: 0, assignedCranes: [] },
      { id: 'VES-008', imo: 'IMO9753102', name: 'ONE TRUST', operator: 'ONE', voyage: 'ONE-911', eta: '2026-10-01T15:00:00Z', etd: '2026-10-03T02:00:00Z', lengthM: 366, beamM: 51, draftM: 14.5, teuCapacity: 14000, currentTeu: 12100, importTeu: 2200, exportTeu: 1900, reeferCount: 160, hazardousFlag: true, berthId: null, status: 'APPROACHING', progressPercent: 0, assignedCranes: [] },
      { id: 'VES-009', imo: 'IMO9901144', name: 'YANG MING WELLNESS', operator: 'Yang Ming', voyage: 'YM-441', eta: '2026-10-01T19:00:00Z', etd: '2026-10-03T08:00:00Z', lengthM: 368, beamM: 51, draftM: 14.2, teuCapacity: 14220, currentTeu: 11900, importTeu: 1800, exportTeu: 1700, reeferCount: 150, hazardousFlag: false, berthId: null, status: 'EXPECTED', progressPercent: 0, assignedCranes: [] },
      { id: 'VES-010', imo: 'IMO9871109', name: 'RQ-MSC-SYNTH-24000', operator: 'MSC Mega', voyage: 'MEG-2026', eta: '2026-10-01T10:00:00Z', etd: '2026-10-03T20:00:00Z', lengthM: 400, beamM: 61.5, draftM: 17.0, teuCapacity: 24346, currentTeu: 23100, importTeu: 5100, exportTeu: 4300, reeferCount: 420, hazardousFlag: true, berthId: null, status: 'APPROACHING', progressPercent: 0, assignedCranes: [] }
    ];
    vesselDefs.forEach(v => this.vessels.set(v.id, v));

    // 4. Yard Blocks (A01 to F10)
    const blockTypes: YardBlock['type'][] = ['IMPORT', 'EXPORT', 'REEFER', 'HAZARDOUS', 'RAIL_BUFFER', 'EMPTY'];
    ['A', 'B', 'C', 'D', 'E', 'F'].forEach((letter, lIdx) => {
      for (let num = 1; num <= 10; num++) {
        const blockId = `BLOCK-${letter}${num.toString().padStart(2, '0')}`;
        const type = blockTypes[(lIdx + num) % blockTypes.length];
        const capacityTeu = 800;
        const currentTeu = Math.floor(450 + Math.random() * 320); // ~74% avg
        this.yardBlocks.set(blockId, {
          id: blockId,
          name: `Yard Block ${letter}${num.toString().padStart(2, '0')}`,
          terminal: lIdx < 4 ? 'Trinity Terminal' : 'Berths 8 & 9',
          rows: 6,
          bays: 20,
          tiers: 5,
          capacityTeu,
          currentTeu,
          type,
          assignedRtgs: [`RTG-${letter}${num}`]
        });
      }
    });

    // 5. Equipment Vehicles (AGVs, RTGs, Autonomous Trucks)
    for (let i = 1; i <= 50; i++) {
      const id = `AGV-${i.toString().padStart(2, '0')}`;
      this.vehicles.set(id, {
        id,
        type: 'AGV',
        location: `Trinity Lane ${Math.floor(i % 12) + 1}`,
        batteryPercent: Math.floor(40 + Math.random() * 60),
        fuelType: 'ELECTRIC',
        status: i % 4 === 0 ? 'CHARGING' : i % 3 === 0 ? 'ASSIGNED' : 'TRAVELLING',
        currentTask: `Transport Container to Block B0${(i % 5) + 1}`,
        destination: `B0${(i % 5) + 1}`,
        loadedContainerId: `MSCU-${200000 + i}-1`,
        healthPercent: Math.floor(92 + Math.random() * 8),
        vibrationMmS: Number((1.2 + Math.random() * 0.8).toFixed(2)),
        motorCurrentA: Math.floor(110 + Math.random() * 25),
        hydraulicBar: Math.floor(180 + Math.random() * 20),
        temperatureC: Math.floor(45 + Math.random() * 15)
      });
    }

    for (let i = 1; i <= 30; i++) {
      const id = `RTG-${i.toString().padStart(2, '0')}`;
      this.vehicles.set(id, {
        id,
        type: 'RTG',
        location: `Block A0${(i % 9) + 1}`,
        batteryPercent: 100,
        fuelType: i % 2 === 0 ? 'HYBRID' : 'DIESEL',
        status: i === 7 ? 'FAULT' : 'ASSIGNED',
        currentTask: 'Stacking Discharge Container',
        destination: null,
        loadedContainerId: null,
        healthPercent: i === 7 ? 64 : Math.floor(85 + Math.random() * 15),
        vibrationMmS: i === 7 ? 4.8 : Number((1.5 + Math.random() * 1.0).toFixed(2)),
        motorCurrentA: Math.floor(130 + Math.random() * 30),
        hydraulicBar: Math.floor(190 + Math.random() * 15),
        temperatureC: i === 7 ? 88 : Math.floor(50 + Math.random() * 10)
      });
    }

    // 6. Trains & Rail Terminals (North, Central, South Rail Terminals)
    const trainDefs: Train[] = [
      { id: 'TRN-101', serviceCode: '4M52', operator: 'Freightliner', origin: 'Port of Felixstowe', destination: 'DAVENTRY', terminalId: 'North Rail Terminal', arrivalTime: '07:30', departureTime: '10:15', capacityWagons: 30, loadedWagons: 28, capacityTeu: 60, loadedTeu: 56, status: 'LOADING', containers: ['FEXU-10001', 'FEXU-10002'] },
      { id: 'TRN-102', serviceCode: '4M88', operator: 'GB Railfreight', origin: 'Port of Felixstowe', destination: 'BIRMINGHAM', terminalId: 'Central Rail Terminal', arrivalTime: '08:00', departureTime: '11:00', capacityWagons: 32, loadedWagons: 32, capacityTeu: 64, loadedTeu: 64, status: 'READY', containers: ['FEXU-10003', 'FEXU-10004'] },
      { id: 'TRN-103', serviceCode: '4E22', operator: 'DB Cargo', origin: 'Port of Felixstowe', destination: 'DONCASTER', terminalId: 'South Rail Terminal', arrivalTime: '08:45', departureTime: '12:30', capacityWagons: 28, loadedWagons: 14, capacityTeu: 56, loadedTeu: 28, status: 'LOADING', containers: ['FEXU-10005'] },
      { id: 'TRN-104', serviceCode: '4M34', operator: 'Freightliner', origin: 'Port of Felixstowe', destination: 'DIRFT', terminalId: 'North Rail Terminal', arrivalTime: '09:15', departureTime: '13:00', capacityWagons: 30, loadedWagons: 0, capacityTeu: 60, loadedTeu: 0, status: 'ARRIVED', containers: [] },
      { id: 'TRN-105', serviceCode: '4M90', operator: 'GB Railfreight', origin: 'Port of Felixstowe', destination: 'MANCHESTER', terminalId: 'Central Rail Terminal', arrivalTime: '10:00', departureTime: '14:15', capacityWagons: 32, loadedWagons: 0, capacityTeu: 64, loadedTeu: 0, status: 'SCHEDULED', containers: [] },
      { id: 'TRN-106', serviceCode: '4E77', operator: 'DRS', origin: 'Port of Felixstowe', destination: 'LEEDS', terminalId: 'South Rail Terminal', arrivalTime: '11:30', departureTime: '15:30', capacityWagons: 26, loadedWagons: 0, capacityTeu: 52, loadedTeu: 0, status: 'SCHEDULED', containers: [] }
    ];
    trainDefs.forEach(t => this.trains.set(t.id, t));

    // 7. Gate Lanes (8 Lanes)
    for (let i = 1; i <= 8; i++) {
      const laneId = `GATE-0${i}`;
      this.gateLanes.set(laneId, {
        id: laneId,
        name: `Inbound Gate Lane ${i.toString().padStart(2, '0')}`,
        status: i === 8 ? 'INSPECTION' : 'OPEN',
        queueLength: Math.floor(1 + Math.random() * 4),
        trucksProcessed24h: Math.floor(450 + Math.random() * 100),
        avgTurnaroundMins: Number((18 + Math.random() * 6).toFixed(1))
      });
    }

    // 8. Containers & Event Stream (500 initial active containers)
    const customers = ['Tesco Logistics', 'Asda Freight', 'Amazon UK', 'Jaguar Land Rover', 'JCB Ltd', 'Diageo', 'Unilever UK', 'Samsung Electronics', 'BMW Group UK'];
    const destinations = ['Daventry DIRFT', 'Birmingham Hams Hall', 'Manchester Trafford Park', 'Leeds Freightliner Terminal', 'Doncaster iPort', 'London Gateway Hub'];

    for (let i = 1; i <= 500; i++) {
      const id = `GBFX-${300000 + i}-${i % 9}`;
      const isImport = i % 2 === 0;
      const type = i % 10 === 0 ? 'HAZARDOUS' : i % 7 === 0 ? 'REEFER' : 'DRY';
      const container: Container = {
        id,
        isoClass: i % 3 === 0 ? '40HC' : i % 2 === 0 ? '20GP' : '45HC',
        sizeFt: i % 3 === 0 ? 40 : i % 2 === 0 ? 20 : 45,
        grossWeightKg: Math.floor(14000 + Math.random() * 16000),
        verifiedWeightKg: Math.floor(14000 + Math.random() * 16000),
        weightVerified: true,
        type,
        status: i % 5 === 0 ? 'GATED_OUT' : i % 4 === 0 ? 'CUSTOMS_HOLD' : 'IN_YARD',
        vesselId: `VES-00${(i % 6) + 1}`,
        voyage: `FE-2026-${i % 10}`,
        origin: isImport ? 'Shanghai, CN' : 'Felixstowe Port, UK',
        destination: isImport ? destinations[i % destinations.length] : 'Ningbo, CN',
        yardLocation: `Y-${['A', 'B', 'C', 'D', 'E', 'F'][i % 6]}0${(i % 9) + 1}-0${(i % 5) + 1}-0${(i % 4) + 1}`,
        customer: customers[i % customers.length],
        isImport,
        reeferSetpointC: type === 'REEFER' ? -18 : undefined,
        currentTempC: type === 'REEFER' ? -18.2 : undefined,
        hazardClass: type === 'HAZARDOUS' ? 'Class 3 Flammable' : undefined,
        customsReleased: i % 4 !== 0,
        preferredMode: i % 3 === 0 ? 'RAIL' : 'ROAD',
        collectionAppointment: `2026-10-01T${(8 + (i % 8)).toString().padStart(2, '0')}:00:00Z`
      };
      this.containers.set(id, container);

      // Initial history event
      this.addEvent({
        id: `EVT-${100000 + i}`,
        containerId: id,
        timestamp: new Date(this.currentTime.getTime() - (i * 300000)).toISOString(),
        eventType: 'ContainerDischarged',
        location: container.yardLocation,
        subsystem: 'QUAY_TO_YARD',
        details: `Discharged from vessel ${container.vesselId} to yard slot ${container.yardLocation}`
      });
    }
  }

  private startSimulationLoop() {
    setInterval(() => {
      if (!this.isRunning) return;

      // Advance time based on speed multiplier (1 sec real = speedMultiplier seconds simulated)
      this.currentTime = new Date(this.currentTime.getTime() + this.speedMultiplier * 1000);

      // Perform state updates
      this.updateVesselsAndCranes();
      this.updateYardAndVehicles();
      this.updateGateAndTrucks();
      this.updateTrains();
    }, 1000);
  }

  private updateVesselsAndCranes() {
    this.vessels.forEach(vessel => {
      if (vessel.status === 'WORKING') {
        vessel.progressPercent = Math.min(100, vessel.progressPercent + (0.05 * this.speedMultiplier));
        if (vessel.progressPercent >= 100) {
          vessel.status = 'COMPLETING';
          this.addEvent({
            id: `EVT-V-COMP-${Date.now()}`,
            containerId: 'SYSTEM',
            timestamp: this.currentTime.toISOString(),
            eventType: 'VesselArrived',
            location: vessel.berthId || 'BERTH',
            subsystem: 'VESSEL_OPS',
            details: `Vessel ${vessel.name} (${vessel.imo}) completed all discharge/loading moves.`
          });
        }
      }
    });

    this.cranes.forEach(crane => {
      if (crane.status === 'LIFTING' || crane.status === 'MOVING') {
        crane.totalMoves24h += 0.02 * this.speedMultiplier;
      }
    });
  }

  private updateYardAndVehicles() {
    this.vehicles.forEach(veh => {
      if (veh.status === 'TRAVELLING' || veh.status === 'ASSIGNED') {
        veh.batteryPercent = Math.max(15, veh.batteryPercent - (0.01 * this.speedMultiplier));
        if (veh.type === 'AGV' && veh.batteryPercent < 20) {
          veh.status = 'CHARGING';
        }
      }
    });
  }

  private updateGateAndTrucks() {
    // Randomize slight queue changes
    this.gateLanes.forEach(lane => {
      if (lane.status === 'OPEN') {
        lane.trucksProcessed24h += 0.05 * this.speedMultiplier;
      }
    });
  }

  private updateTrains() {
    this.trains.forEach(train => {
      if (train.status === 'LOADING') {
        if (train.loadedTeu < train.capacityTeu) {
          train.loadedTeu = Math.min(train.capacityTeu, train.loadedTeu + Math.floor(Math.random() * 2));
          train.loadedWagons = Math.ceil(train.loadedTeu / 2);
        } else {
          train.status = 'READY';
        }
      }
    });
  }

  private addEvent(event: ContainerEvent) {
    this.containerEvents.unshift(event);
    if (this.containerEvents.length > 2000) {
      this.containerEvents.pop();
    }
  }

  // API Methods
  public getPortStatus(): PortStatus {
    const isBottleneckActive = this.activeScenario === 'PORT_BOTTLENECK';
    const yardOccupiedTeu = isBottleneckActive ? 42720 : 35520;
    const yardUtilisationPercent = isBottleneckActive ? 89 : 74;
    const primaryBottleneck = isBottleneckActive
      ? 'YARD CAPACITY & REHANDLE CONSTRAINTS'
      : 'BERTH CRANE DENSITY';

    return {
      vesselsInPort: 17,
      vesselsAtBerth: 8,
      vesselsApproaching: 5,
      quayCranesActive: 21,
      yardUtilisationPercent,
      truckMovements24h: 3812,
      railMovements24h: 61,
      gateQueueLength: isBottleneckActive ? 38 : 14,
      railCapacityUtilisation: 82,
      yardCapacityTeu: 48000,
      yardOccupiedTeu,
      berthCapacityUtilisation: 78,
      primaryBottleneck,
      secondaryBottlenecks: ['RAIL TERMINAL 2 SWITCHING', 'GATE 08 INSPECTION BAY', 'REEFER BLOCK E04 POWER LIMIT'],
      congestionIndex: isBottleneckActive ? 86 : 38,
      teuPerHour: 340,
      movesPerHour: 210,
      avgVesselTurnaroundHours: 28.5,
      avgTruckTurnaroundMins: 22.4,
      avgYardDwellDays: 3.2
    };
  }

  public getVessels(): Vessel[] {
    return Array.from(this.vessels.values());
  }

  public getVesselById(id: string): Vessel | undefined {
    return this.vessels.get(id);
  }

  public getBerths(): Berth[] {
    return Array.from(this.berths.values());
  }

  public getCranes(): QuayCrane[] {
    return Array.from(this.cranes.values());
  }

  public getContainers(): Container[] {
    return Array.from(this.containers.values());
  }

  public getContainerById(id: string): Container | undefined {
    return this.containers.get(id);
  }

  public getContainerEvents(containerId?: string): ContainerEvent[] {
    if (containerId) {
      return this.containerEvents.filter(e => e.containerId === containerId);
    }
    return this.containerEvents.slice(0, 100);
  }

  public getYardBlocks(): YardBlock[] {
    return Array.from(this.yardBlocks.values());
  }

  public getVehicles(): EquipmentVehicle[] {
    return Array.from(this.vehicles.values());
  }

  public getTrains(): Train[] {
    return Array.from(this.trains.values());
  }

  public getGateLanes(): GateLane[] {
    return Array.from(this.gateLanes.values());
  }

  public getSimulationState(): { running: boolean; speedMultiplier: number; simulatedTime: string; activeScenario: string | null } {
    return {
      running: this.isRunning,
      speedMultiplier: this.speedMultiplier,
      simulatedTime: this.currentTime.toISOString(),
      activeScenario: this.activeScenario
    };
  }

  public setSimulationState(running?: boolean, speedMultiplier?: 1 | 10 | 50 | 100) {
    if (running !== undefined) this.isRunning = running;
    if (speedMultiplier !== undefined) this.speedMultiplier = speedMultiplier;
  }

  public runScenario(scenarioId: string) {
    this.activeScenario = scenarioId;

    if (scenarioId === 'MEGA_VESSEL') {
      const megaVessel = this.vessels.get('VES-010'); // RQ-MSC-SYNTH-24000
      if (megaVessel) {
        megaVessel.status = 'BERTHING';
        megaVessel.berthId = 'B-BERTH-9';
        megaVessel.assignedCranes = ['QC-21', 'QC-22', 'QC-23', 'QC-24', 'QC-25', 'QC-26', 'QC-27', 'QC-28'];
      }
      this.addEvent({
        id: `EVT-MEGA-${Date.now()}`,
        containerId: 'SYSTEM',
        timestamp: this.currentTime.toISOString(),
        eventType: 'VesselBerthed',
        location: 'Berth 9 (Deepwater)',
        subsystem: 'BERTH_PLANNING',
        details: '24,000 TEU Mega Vessel RQ-MSC-SYNTH-24000 berthed. 8 Quay Cranes allocated for high-density discharge.'
      });
    } else if (scenarioId === 'CRANE_FAILURE') {
      ['QC-01', 'QC-02', 'QC-03'].forEach(id => {
        const qc = this.cranes.get(id);
        if (qc) {
          qc.status = 'FAULT';
          qc.healthPercent = 35;
        }
      });
      this.addEvent({
        id: `EVT-FAULT-${Date.now()}`,
        containerId: 'SYSTEM',
        timestamp: this.currentTime.toISOString(),
        eventType: 'EquipmentFault',
        location: 'Trinity Berth 1',
        subsystem: 'QUAY_CRANES',
        details: 'CRITICAL: QC-01, QC-02, QC-03 experienced drive system lockouts. Re-allocation engine initiated.'
      });
    } else if (scenarioId === 'PORT_BOTTLENECK') {
      this.yardBlocks.forEach(b => {
        b.currentTeu = Math.floor(b.capacityTeu * 0.89);
      });
      this.addEvent({
        id: `EVT-BOTTLENECK-${Date.now()}`,
        containerId: 'SYSTEM',
        timestamp: this.currentTime.toISOString(),
        eventType: 'ContainerStacked',
        location: 'TERMINAL_YARD',
        subsystem: 'YARD_OS',
        details: 'Yard utilisation surged to 89%. Rehandle multiplier increased to 2.4x per retrieval.'
      });
    }

    return { success: true, scenario: scenarioId, time: this.currentTime.toISOString() };
  }

  public calculateIntermodalRouting(destination: string, containerCount = 100): IntermodalRouteOption[] {
    return [
      {
        mode: 'RAIL',
        destination,
        costGbp: Math.floor(185 * containerCount),
        transitHours: 5.5,
        carbonKgCo2e: Math.floor(12 * containerCount),
        reliabilityScore: 94,
        capacityAvailable: true,
        recommended: true
      },
      {
        mode: 'ROAD',
        destination,
        costGbp: Math.floor(290 * containerCount),
        transitHours: 4.2,
        carbonKgCo2e: Math.floor(82 * containerCount),
        reliabilityScore: 81,
        capacityAvailable: true,
        recommended: false
      },
      {
        mode: 'INTERMODAL',
        destination,
        costGbp: Math.floor(210 * containerCount),
        transitHours: 6.0,
        carbonKgCo2e: Math.floor(22 * containerCount),
        reliabilityScore: 91,
        capacityAvailable: true,
        recommended: false
      }
    ];
  }

  public replanYard(): { rehandlesSaved: number; distanceReducedKm: number; newOccupancyPercent: number } {
    if (this.activeScenario === 'PORT_BOTTLENECK') {
      this.yardBlocks.forEach(b => {
        b.currentTeu = Math.floor(b.capacityTeu * 0.74);
      });
      this.activeScenario = null;
    }
    return {
      rehandlesSaved: 1420,
      distanceReducedKm: 340,
      newOccupancyPercent: 74
    };
  }
}
