import { GoogleGenAI } from '@google/genai';
import { PortStatus } from './types';

export async function askPortAiPlanner(query: string, portStatus: PortStatus): Promise<{ answer: string; recommendedActions: string[]; metricsImpact: Record<string, string> }> {
  const apiKey = process.env['GEMINI_API_KEY'];
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return {
      answer: `[Deterministic Fallback Planner] Port Status Analysis:
Currently, the port is operating at ${portStatus.yardUtilisationPercent}% yard capacity with ${portStatus.vesselsAtBerth} vessels working.
Current Bottleneck: ${portStatus.primaryBottleneck}.
Recommendation for "${query}": Shift export container pre-positioning to Rail Terminal 1 and increase Quay Crane allocation on Berth 8 to clear vessel queue.`,
      recommendedActions: [
        'Dispatch 4 additional AGVs to Berth 8 to prevent crane starvation',
        'Re-route Midlands container demand (1,000 TEU) from Road to Rail',
        'Initiate pre-stack rehandle optimization for upcoming MSC departure'
      ],
      metricsImpact: {
        'Vessel Delay Reduction': '-2.4 hours',
        'Yard Congestion': '-15%',
        'CO2e Emissions Saved': '-68 tonnes'
      }
    };
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    const prompt = `You are PORT 4.0 INTELLIGENCE, an expert quantitative container port decision support engine inspired by the Port of Felixstowe terminal operating system.

Current Synthetic Port Telemetry:
- Vessels in Port: ${portStatus.vesselsInPort} (${portStatus.vesselsAtBerth} at berth, ${portStatus.vesselsApproaching} approaching)
- Active Quay Cranes: ${portStatus.quayCranesActive} / 28
- Yard Utilisation: ${portStatus.yardUtilisationPercent}% (${portStatus.yardOccupiedTeu} / ${portStatus.yardCapacityTeu} TEU)
- Primary Bottleneck: ${portStatus.primaryBottleneck}
- Secondary Bottlenecks: ${portStatus.secondaryBottlenecks.join(', ')}
- Gate Queue: ${portStatus.gateQueueLength} trucks
- Rail Capacity Utilisation: ${portStatus.railCapacityUtilisation}%
- Moves/Hour: ${portStatus.movesPerHour}
- Congestion Index: ${portStatus.congestionIndex}/100

User Operational Query: "${query}"

Provide a concise, highly analytical response formatted as valid JSON with three keys:
1. "answer": Clear, engineering-grade diagnosis and decision justification.
2. "recommendedActions": Array of 3 specific operational commands or plan modifications.
3. "metricsImpact": Object mapping key KPI metrics to predicted changes (e.g. {"Vessel Turnaround": "-3.1h", "Yard Rehandles": "-22%"}).`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });

    const text = response.text || '';
    const parsed = JSON.parse(text);
    return {
      answer: parsed.answer || 'Analysis complete.',
      recommendedActions: parsed.recommendedActions || [],
      metricsImpact: parsed.metricsImpact || {}
    };
  } catch (err: any) {
    console.error('Error calling Gemini AI in Port Planner:', err);
    return {
      answer: `[Deterministic Recovery] System context evaluated for query "${query}". Primary bottleneck identified as ${portStatus.primaryBottleneck}. Recommended immediate intermodal rail shift and crane re-balancing.`,
      recommendedActions: [
        'Re-allocate 2 Quay Cranes from Trinity 4 to Berth 8',
        'Open Gate Lanes 07 and 08 for CBS surge handling',
        'Execute yard rehandle minimization script on Block B03'
      ],
      metricsImpact: {
        'Throughput Gain': '+18 TEU/hr',
        'Turnaround Reduction': '-1.8h'
      }
    };
  }
}
