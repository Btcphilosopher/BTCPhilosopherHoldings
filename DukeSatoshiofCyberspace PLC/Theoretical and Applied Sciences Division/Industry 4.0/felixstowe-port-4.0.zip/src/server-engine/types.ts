export interface PortStatus {
  vesselsInPort: number;
  vesselsAtBerth: number;
  vesselsApproaching: number;
  quayCranesActive: number;
  yardUtilisationPercent: number;
  truckMovements24h: number;
  railMovements24h: number;
  gateQueueLength: number;
  railCapacityUtilisation: number;
  yardCapacityTeu: number;
  yardOccupiedTeu: number;
  berthCapacityUtilisation: number;
  primaryBottleneck: string;
  secondaryBottlenecks: string[];
  congestionIndex: number; // 0 to 100
  teuPerHour: number;
  movesPerHour: number;
  avgVesselTurnaroundHours: number;
  avgTruckTurnaroundMins: number;
  avgYardDwellDays: number;
}

export type VesselStatus =
  | 'EXPECTED'
  | 'APPROACHING'
  | 'ANCHOR'
  | 'PILOTED'
  | 'BERTHING'
  | 'AT_BERTH'
  | 'WORKING'
  | 'COMPLETING'
  | 'DEPARTING'
  | 'SAILED';

export interface Vessel {
  id: string;
  imo: string;
  name: string;
  operator: string;
  voyage: string;
  eta: string;
  etd: string;
  lengthM: number;
  beamM: number;
  draftM: number;
  teuCapacity: number;
  currentTeu: number;
  importTeu: number;
  exportTeu: number;
  reeferCount: number;
  hazardousFlag: boolean;
  berthId: string | null;
  status: VesselStatus;
  progressPercent: number;
  assignedCranes: string[];
}

export interface Berth {
  id: string;
  name: string;
  terminal: 'Trinity Terminal' | 'Berths 8 & 9';
  lengthM: number;
  maxDraftM: number;
  currentVesselId: string | null;
  status: 'OCCUPIED' | 'AVAILABLE' | 'RESERVED' | 'MAINTENANCE';
  assignedCranes: string[];
}

export type CraneStatus =
  | 'IDLE'
  | 'POSITIONING'
  | 'LIFTING'
  | 'MOVING'
  | 'LOWERING'
  | 'WAITING'
  | 'FAULT'
  | 'MAINTENANCE';

export interface QuayCrane {
  id: string;
  berthId: string;
  status: CraneStatus;
  movesPerHour: number;
  currentContainerId: string | null;
  nextContainerId: string | null;
  totalMoves24h: number;
  energyKwh: number;
  healthPercent: number;
  liftCycleCount: number;
}

export type ContainerStatus =
  | 'BOOKED'
  | 'GATED_IN'
  | 'LOADED'
  | 'DISCHARGED'
  | 'IN_YARD'
  | 'CUSTOMS_HOLD'
  | 'READY'
  | 'ALLOCATED'
  | 'GATED_OUT'
  | 'RAIL_LOADED'
  | 'TRUCK_LOADED'
  | 'DELIVERED';

export interface Container {
  id: string;
  isoClass: string; // e.g. 40HC, 20GP, 45HC
  sizeFt: 20 | 40 | 45;
  grossWeightKg: number;
  verifiedWeightKg: number;
  weightVerified: boolean;
  type: 'DRY' | 'REEFER' | 'HAZARDOUS' | 'OVERSIZED' | 'TANK';
  status: ContainerStatus;
  vesselId: string | null;
  voyage: string | null;
  origin: string;
  destination: string;
  yardLocation: string; // e.g. "Y-A03-02-04"
  customer: string;
  isImport: boolean;
  reeferSetpointC?: number;
  currentTempC?: number;
  hazardClass?: string;
  customsReleased: boolean;
  preferredMode: 'ROAD' | 'RAIL' | 'INTERMODAL';
  collectionAppointment?: string;
}

export interface ContainerEvent {
  id: string;
  containerId: string;
  timestamp: string;
  eventType:
    | 'VesselArrived'
    | 'VesselBerthed'
    | 'CraneAssigned'
    | 'ContainerDischarged'
    | 'ContainerMoved'
    | 'ContainerStacked'
    | 'ContainerReleased'
    | 'TruckBooked'
    | 'TruckArrived'
    | 'GateEntered'
    | 'GateExited'
    | 'TrainArrived'
    | 'TrainLoaded'
    | 'TrainDeparted'
    | 'ShipmentDelivered'
    | 'EquipmentFault'
    | 'MaintenanceStarted'
    | 'MaintenanceCompleted';
  location: string;
  subsystem: string;
  details: string;
}

export interface YardBlock {
  id: string;
  name: string;
  terminal: string;
  rows: number;
  bays: number;
  tiers: number;
  capacityTeu: number;
  currentTeu: number;
  type: 'IMPORT' | 'EXPORT' | 'REEFER' | 'HAZARDOUS' | 'EMPTY' | 'RAIL_BUFFER';
  assignedRtgs: string[];
}

export type VehicleStatus =
  | 'IDLE'
  | 'ASSIGNED'
  | 'TRAVELLING'
  | 'LOADING'
  | 'UNLOADING'
  | 'WAITING'
  | 'CHARGING'
  | 'FAULT';

export interface EquipmentVehicle {
  id: string;
  type: 'AGV' | 'RTG' | 'AUTONOMOUS_TRUCK' | 'STRADDLE' | 'TERMINAL_TRACTOR';
  location: string;
  batteryPercent: number;
  fuelType: 'ELECTRIC' | 'DIESEL' | 'HYBRID';
  status: VehicleStatus;
  currentTask: string | null;
  destination: string | null;
  loadedContainerId: string | null;
  healthPercent: number;
  vibrationMmS: number;
  motorCurrentA: number;
  hydraulicBar: number;
  temperatureC: number;
}

export interface Train {
  id: string;
  serviceCode: string;
  operator: 'GB Railfreight' | 'Freightliner' | 'DB Cargo' | 'DRS';
  origin: string;
  destination: string;
  terminalId: string;
  arrivalTime: string;
  departureTime: string;
  capacityWagons: number;
  loadedWagons: number;
  capacityTeu: number;
  loadedTeu: number;
  status: 'SCHEDULED' | 'ARRIVED' | 'LOADING' | 'READY' | 'DEPARTED';
  containers: string[];
}

export interface Truck {
  id: string;
  haulier: string;
  driverNameSynthetic: string;
  containerId: string | null;
  appointmentTime: string;
  eta: string;
  gateLane: string;
  status: 'EN_ROUTE' | 'QUEUED' | 'AT_GATE' | 'IN_YARD' | 'COMPLETED';
}

export interface GateLane {
  id: string;
  name: string;
  status: 'OPEN' | 'INSPECTION' | 'CLOSED';
  queueLength: number;
  trucksProcessed24h: number;
  avgTurnaroundMins: number;
}

export interface IntermodalRouteOption {
  mode: 'ROAD' | 'RAIL' | 'INTERMODAL';
  destination: string;
  costGbp: number;
  transitHours: number;
  carbonKgCo2e: number;
  reliabilityScore: number; // 0-100
  capacityAvailable: boolean;
  recommended: boolean;
}

export interface EnergyMetrics {
  quayCranesKwh: number;
  rtgsKwh: number;
  agvsKwh: number;
  buildingsKwh: number;
  reefersKwh: number;
  totalKwh: number;
  kwhPerTeu: number;
  co2eTonnes24h: number;
  dieselFleetCo2eTonnes: number;
  hybridFleetCo2eTonnes: number;
  electricFleetCo2eTonnes: number;
}

export interface SimulationState {
  running: boolean;
  speedMultiplier: 1 | 10 | 50 | 100;
  simulatedTime: string;
  activeScenario: string | null;
}
