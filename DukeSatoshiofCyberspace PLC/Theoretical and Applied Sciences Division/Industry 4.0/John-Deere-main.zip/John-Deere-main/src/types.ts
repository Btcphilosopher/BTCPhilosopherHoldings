export interface Hotspot {
  id: string;
  title: string;
  category: 'ENGINE' | 'CAB' | 'PRECISION' | 'HYDRAULICS' | 'ATTACHMENTS' | 'DRIVETRAIN';
  x: number; // percentage 0-100
  y: number; // percentage 0-100
  description: string;
  specHighlight: string;
}

export interface EquipmentItem {
  id: string;
  name: string;
  series: string;
  tagline: string;
  category: 'tractors' | 'harvesting' | 'lawn-care' | 'gator-utility' | 'planting' | 'tillage' | 'sprayers' | 'construction';
  horsepower: string;
  engine: string;
  transmission: string;
  hydraulicFlow?: string;
  fuelCapacity?: string;
  startingPrice?: string;
  leaseFrom?: string;
  image: string;
  actionImage?: string;
  description: string;
  keyFeatures: string[];
  hotspots?: Hotspot[];
  badge?: string;
  isFlagship?: boolean;
}

export interface NewsArticle {
  id: string;
  title: string;
  category: 'Innovation' | 'Sustainability' | 'Technology' | 'Customer Story' | 'Equipment';
  readTime: string;
  date: string;
  summary: string;
  image: string;
  featured?: boolean;
  author: string;
}

export interface Dealer {
  id: string;
  name: string;
  city: string;
  state: string;
  zip: string;
  phone: string;
  distance: string;
  address: string;
  hours: string;
  services: string[];
  certifiedPrecisionTech: boolean;
  inStockCount: number;
}

export interface TelemetryData {
  fieldPerformance: number;
  connectedMachines: number;
  acresOptimized: number;
  fuelEfficiencyGain: number;
  soilMoistureIndex: number;
  seedSpacingAccuracy: number;
}
