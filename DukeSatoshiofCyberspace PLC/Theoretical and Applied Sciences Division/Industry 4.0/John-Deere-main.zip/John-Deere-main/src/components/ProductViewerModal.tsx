import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  Check, 
  ChevronRight, 
  DollarSign, 
  ShieldCheck, 
  Compass, 
  Layers, 
  Info, 
  Calendar,
  Send,
  Phone,
  FileCheck2
} from 'lucide-react';
import { EQUIPMENT_DATA } from '../data/equipmentData';
import { Hotspot } from '../types';

interface ProductViewerModalProps {
  equipmentId: string | null;
  onClose: () => void;
  onOpenDealerLocator: () => void;
  onOpenFinancialCalc: (modelPrice?: string) => void;
}

export const ProductViewerModal: React.FC<ProductViewerModalProps> = ({
  equipmentId,
  onClose,
  onOpenDealerLocator,
  onOpenFinancialCalc
}) => {
  const [activeViewMode, setActiveViewMode] = useState<'profile' | 'action'>('profile');
  const [selectedHotspot, setSelectedHotspot] = useState<Hotspot | null>(null);
  const [showQuoteForm, setShowQuoteForm] = useState(false);
  const [quoteSubmitted, setQuoteSubmitted] = useState(false);
  const [quoteForm, setQuoteForm] = useState({
    name: '',
    phone: '',
    email: '',
    acreage: '1000-2500 acres',
    tradeIn: 'Yes, trading older machine'
  });

  if (!equipmentId) return null;

  const equipment = EQUIPMENT_DATA.find(e => e.id === equipmentId) || EQUIPMENT_DATA[0];

  const handleQuoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setQuoteSubmitted(true);
    setTimeout(() => {
      // Auto reset feedback after 4s
    }, 4000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto animate-fade-in select-none">
      <div 
        className="w-full max-w-5xl bg-[#0c130b] border border-[#274024] rounded-3xl shadow-[0_25px_80px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col my-auto max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Navigation Header */}
        <div className="p-5 sm:px-8 border-b border-[#1f331c] flex items-center justify-between bg-[#111c10]">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-extrabold tracking-wider px-2 py-0.5 rounded bg-[#ffde00] text-[#0d2209]">
                {equipment.badge || 'GEN 5 PRECISION'}
              </span>
              <span className="text-xs text-[#8da689]">{equipment.series}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight mt-0.5">
              {equipment.name}
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onOpenFinancialCalc(equipment.startingPrice)}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#192b17] border border-[#2b4427] text-xs font-bold text-[#ffde00] hover:bg-[#223b20] transition-colors"
            >
              <DollarSign className="w-3.5 h-3.5" />
              <span>{equipment.leaseFrom ? `Lease from ${equipment.leaseFrom}` : 'Financing'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-full text-[#8da689] hover:text-white hover:bg-[#1a2b18] transition-colors"
              aria-label="Close Inspector"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Modal Body: Two Columns */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left / Visual Interactive Area (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            
            {/* Main Stage with Interactive Hotspots */}
            <div className="relative w-full aspect-[16/10] rounded-2xl overflow-hidden bg-black/60 border border-[#223920] shadow-inner">
              <img
                src={activeViewMode === 'action' && equipment.actionImage ? equipment.actionImage : equipment.image}
                alt={equipment.name}
                className="w-full h-full object-cover object-center transition-all duration-500"
                referrerPolicy="no-referrer"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 pointer-events-none" />

              {/* View Angle Switcher Controls */}
              <div className="absolute bottom-4 left-4 z-20 flex items-center gap-2 bg-black/70 backdrop-blur-md p-1 rounded-xl border border-white/10">
                <button
                  onClick={() => setActiveViewMode('profile')}
                  className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors ${
                    activeViewMode === 'profile'
                      ? 'bg-[#ffde00] text-[#0d2209]'
                      : 'text-[#9eb89a] hover:text-white'
                  }`}
                >
                  360° Studio View
                </button>
                {equipment.actionImage && (
                  <button
                    onClick={() => setActiveViewMode('action')}
                    className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors ${
                      activeViewMode === 'action'
                        ? 'bg-[#ffde00] text-[#0d2209]'
                        : 'text-[#9eb89a] hover:text-white'
                    }`}
                  >
                    In-Field Action
                  </button>
                )}
              </div>

              {/* Hotspot Markers (Rendered when in profile view) */}
              {activeViewMode === 'profile' && equipment.hotspots && equipment.hotspots.map((hs) => {
                const isSelected = selectedHotspot?.id === hs.id;
                return (
                  <div
                    key={hs.id}
                    style={{ left: `${hs.x}%`, top: `${hs.y}%` }}
                    className="absolute z-30 -translate-x-1/2 -translate-y-1/2"
                  >
                    <button
                      onClick={() => setSelectedHotspot(isSelected ? null : hs)}
                      className={`relative w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
                        isSelected 
                          ? 'bg-[#ffde00] scale-125 shadow-[0_0_20px_#ffde00]' 
                          : 'bg-black/80 hover:bg-[#367c2b] border-2 border-[#ffde00] hover:scale-110 shadow-lg'
                      }`}
                      aria-label={`Hotspot: ${hs.title}`}
                    >
                      <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-black' : 'bg-[#ffde00]'}`} />
                      <span className="absolute inset-0 rounded-full bg-[#ffde00] animate-ping opacity-40 pointer-events-none" />
                    </button>
                  </div>
                );
              })}
            </div>

            {/* Selected Hotspot Detail Card */}
            {selectedHotspot && (
              <div className="p-4 rounded-xl bg-[#142312] border border-[#ffde00]/60 shadow-lg animate-fade-in space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] uppercase font-extrabold bg-[#ffde00] text-[#0d2209]">
                      {selectedHotspot.category}
                    </span>
                    <h4 className="text-sm font-bold text-white">{selectedHotspot.title}</h4>
                  </div>
                  <span className="text-xs font-mono text-[#ffde00] font-bold">
                    {selectedHotspot.specHighlight}
                  </span>
                </div>
                <p className="text-xs text-[#bed5bd] leading-relaxed">
                  {selectedHotspot.description}
                </p>
              </div>
            )}

            {!selectedHotspot && equipment.hotspots && (
              <div className="p-3 rounded-xl bg-[#10180f] border border-[#1d2f1a] text-center text-xs text-[#7f997a] flex items-center justify-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-[#ffde00]" />
                <span>Click any yellow pulsing hotspot on the machine to reveal engineering architecture</span>
              </div>
            )}

          </div>

          {/* Right / Specs & Inquiries Column (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Overview text */}
            <div className="space-y-2">
              <h3 className="text-base font-extrabold text-white">
                Technical Blueprint & Specs
              </h3>
              <p className="text-xs text-[#bed5bd] leading-relaxed">
                {equipment.description}
              </p>
            </div>

            {/* Comprehensive Technical Specifications Grid */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-3 rounded-xl bg-[#121c11] border border-[#1f331d]">
                <span className="text-[10px] uppercase text-[#7f997a] font-semibold block">Horsepower</span>
                <span className="text-sm font-extrabold text-white block mt-0.5">{equipment.horsepower}</span>
              </div>

              <div className="p-3 rounded-xl bg-[#121c11] border border-[#1f331d]">
                <span className="text-[10px] uppercase text-[#7f997a] font-semibold block">Transmission</span>
                <span className="text-sm font-extrabold text-white block mt-0.5">{equipment.transmission.split(' ')[0]}</span>
              </div>

              <div className="p-3 rounded-xl bg-[#121c11] border border-[#1f331d]">
                <span className="text-[10px] uppercase text-[#7f997a] font-semibold block">Engine Model</span>
                <span className="text-sm font-extrabold text-white block mt-0.5">{equipment.engine.split(' ')[0]} 9.0L</span>
              </div>

              <div className="p-3 rounded-xl bg-[#121c11] border border-[#1f331d]">
                <span className="text-[10px] uppercase text-[#7f997a] font-semibold block">Est. MSRP</span>
                <span className="text-sm font-extrabold text-[#ffde00] block mt-0.5">{equipment.startingPrice || 'Call Dealer'}</span>
              </div>
            </div>

            {/* Core Capabilities List */}
            <div className="space-y-2">
              <div className="text-xs uppercase font-extrabold tracking-wider text-[#8da689]">
                Standard Intelligent Features
              </div>
              <ul className="space-y-2">
                {equipment.keyFeatures.map((feat, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-xs text-[#c6dac4]">
                    <div className="w-4 h-4 rounded-full bg-[#367c2b]/30 text-[#4ade80] flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="w-3 h-3" />
                    </div>
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Interactive Quote / Demo Request Toggle */}
            <div className="pt-2">
              {!showQuoteForm ? (
                <div className="space-y-2">
                  <button
                    onClick={() => setShowQuoteForm(true)}
                    className="w-full py-3.5 px-4 rounded-xl bg-[#ffde00] hover:bg-[#ffe633] text-[#0d2209] font-extrabold text-sm flex items-center justify-center gap-2 shadow-[0_4px_16px_rgba(255,222,0,0.3)] transition-transform hover:scale-[1.01]"
                  >
                    <Send className="w-4 h-4" />
                    Request Field Demo / Dealer Quote
                  </button>
                  <button
                    onClick={onOpenDealerLocator}
                    className="w-full py-2.5 px-4 rounded-xl bg-[#142013] hover:bg-[#1b2b1a] border border-[#263e23] text-xs font-bold text-white flex items-center justify-center gap-2 transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5 text-[#ffde00]" />
                    Locate Local Inventory & Test Drive
                  </button>
                </div>
              ) : (
                <form onSubmit={handleQuoteSubmit} className="p-4 rounded-2xl bg-[#142213] border border-[#2e472a] space-y-3 animate-fade-in">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#ffde00] uppercase tracking-wider">Fast Quote & Demo Dispatch</span>
                    <button type="button" onClick={() => setShowQuoteForm(false)} className="text-xs text-[#7f997a] hover:text-white">Cancel</button>
                  </div>

                  {quoteSubmitted ? (
                    <div className="p-4 rounded-xl bg-[#1a3317] text-center space-y-2 text-[#86efac]">
                      <FileCheck2 className="w-8 h-8 text-[#ffde00] mx-auto" />
                      <div className="text-sm font-bold text-white">Quote Request Transmitted</div>
                      <p className="text-xs text-[#cce5ca]">
                        Your local certified dealer has received the configuration specs for <strong>{equipment.name}</strong>. A specialist will call within 2 hours.
                      </p>
                    </div>
                  ) : (
                    <>
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          type="text"
                          required
                          placeholder="Your Full Name"
                          value={quoteForm.name}
                          onChange={(e) => setQuoteForm({ ...quoteForm, name: e.target.value })}
                          className="p-2 rounded-lg bg-[#0e170d] border border-[#233820] text-xs text-white placeholder-[#7f997a] focus:outline-none focus:border-[#ffde00]"
                        />
                        <input
                          type="tel"
                          required
                          placeholder="Mobile Phone"
                          value={quoteForm.phone}
                          onChange={(e) => setQuoteForm({ ...quoteForm, phone: e.target.value })}
                          className="p-2 rounded-lg bg-[#0e170d] border border-[#233820] text-xs text-white placeholder-[#7f997a] focus:outline-none focus:border-[#ffde00]"
                        />
                      </div>
                      <input
                        type="email"
                        required
                        placeholder="Farm / Business Email"
                        value={quoteForm.email}
                        onChange={(e) => setQuoteForm({ ...quoteForm, email: e.target.value })}
                        className="w-full p-2 rounded-lg bg-[#0e170d] border border-[#233820] text-xs text-white placeholder-[#7f997a] focus:outline-none focus:border-[#ffde00]"
                      />
                      <button
                        type="submit"
                        className="w-full py-2.5 rounded-lg bg-[#ffde00] hover:bg-[#ffe633] text-[#0d2209] font-extrabold text-xs flex items-center justify-center gap-1.5 transition-colors"
                      >
                        Transmit Configuration
                      </button>
                    </>
                  )}
                </form>
              )}
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};
