import React, { useState, useEffect } from 'react';
import { Search, X, ArrowRight, Tractor, Sparkles, MapPin, Wrench, FileText } from 'lucide-react';
import { EQUIPMENT_DATA } from '../data/equipmentData';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectEquipment: (id: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectEquipment
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filteredEquipment = query.trim()
    ? EQUIPMENT_DATA.filter(
        item =>
          item.name.toLowerCase().includes(query.toLowerCase()) ||
          item.series.toLowerCase().includes(query.toLowerCase()) ||
          item.tagline.toLowerCase().includes(query.toLowerCase()) ||
          item.horsepower.toLowerCase().includes(query.toLowerCase())
      )
    : EQUIPMENT_DATA.slice(0, 3);

  const quickLinks = [
    { label: '8R Series Tractors', icon: Tractor, action: () => { onSelectEquipment('8r-410'); onClose(); } },
    { label: 'StarFire™ 7500 GPS Receivers', icon: Sparkles, query: 'StarFire' },
    { label: 'Find Local Certified Dealer', icon: MapPin, action: () => { window.location.href = '#dealers'; onClose(); } },
    { label: 'Operations Center Telemetry', icon: FileText, query: 'Operations' },
    { label: 'Order OEM Filters & Parts', icon: Wrench, query: 'Parts' }
  ];

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div 
        className="w-full max-w-2xl bg-[#111710] border border-[#367c2b]/30 rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.8)] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search input header */}
        <div className="flex items-center px-5 py-4 border-b border-[#254020] gap-3">
          <Search className="w-6 h-6 text-[#ffde00]" />
          <input
            type="text"
            placeholder="Search tractors, precision tech, parts, manuals or models..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            className="flex-1 bg-transparent text-white placeholder-[#7f997a] text-lg focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-gray-400 hover:text-white p-1"
            >
              <X className="w-5 h-5" />
            </button>
          )}
          <button
            onClick={onClose}
            className="px-2.5 py-1 text-xs bg-[#1f2e1d] text-[#a4c29e] rounded-md hover:bg-[#2e472a] hover:text-white transition-colors"
          >
            ESC
          </button>
        </div>

        {/* Results Body */}
        <div className="max-h-[60vh] overflow-y-auto p-5 space-y-5">
          {/* Machinery Results */}
          <div>
            <div className="text-xs uppercase tracking-wider text-[#ffde00] font-semibold mb-3 flex items-center gap-1.5">
              <Tractor className="w-3.5 h-3.5" />
              {query ? 'Matching Equipment' : 'Featured Machinery'}
            </div>
            <div className="space-y-2">
              {filteredEquipment.length > 0 ? (
                filteredEquipment.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => {
                      onSelectEquipment(item.id);
                      onClose();
                    }}
                    className="flex items-center justify-between p-3 rounded-xl bg-[#172215] hover:bg-[#20331d] border border-transparent hover:border-[#367c2b]/50 cursor-pointer transition-all group"
                  >
                    <div className="flex items-center gap-4">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-14 h-10 object-cover rounded-lg bg-black/40"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <div className="text-sm font-bold text-white group-hover:text-[#ffde00] transition-colors">
                          {item.name}
                        </div>
                        <div className="text-xs text-[#8da689]">
                          {item.horsepower} • {item.series}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-xs font-semibold text-[#a3c99f] group-hover:text-white">
                      <span>Inspect</span>
                      <ArrowRight className="w-4 h-4 text-[#ffde00] transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-sm text-[#7f997a]">
                  No exact match found for "{query}". Try searching "8R", "Combine", or "Gator".
                </div>
              )}
            </div>
          </div>

          {/* Quick shortcuts */}
          {!query && (
            <div>
              <div className="text-xs uppercase tracking-wider text-[#8da689] font-semibold mb-2">
                Quick Shortcuts
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {quickLinks.map((link, idx) => {
                  const Icon = link.icon;
                  return (
                    <button
                      key={idx}
                      onClick={() => {
                        if (link.action) link.action();
                        else if (link.query) setQuery(link.query);
                      }}
                      className="flex items-center gap-3 p-2.5 rounded-lg bg-[#141d13] hover:bg-[#1c2b1a] text-left text-sm text-[#d4e4d0] hover:text-white transition-colors"
                    >
                      <Icon className="w-4 h-4 text-[#ffde00]" />
                      <span className="truncate">{link.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="px-5 py-3 bg-[#0c120c] border-t border-[#1e301b] flex items-center justify-between text-xs text-[#7f997a]">
          <span>Tip: Press <kbd className="px-1.5 py-0.5 bg-[#172215] text-[#d4e4d0] rounded border border-[#2a4225]">⌘K</kbd> anywhere to search</span>
          <span className="text-[#ffde00]">Live Inventory & Systems Sync</span>
        </div>
      </div>
    </div>
  );
};
