import React from 'react';

interface DeereLogoProps {
  className?: string;
  variant?: 'full' | 'mark' | 'compact';
}

export const DeereLogo: React.FC<DeereLogoProps> = ({ className = 'h-8', variant = 'full' }) => {
  return (
    <div className={`flex items-center gap-3 cursor-pointer select-none group ${className}`}>
      {/* Iconic Shield Mark */}
      <div className="relative w-8 h-8 md:w-9 md:h-9 bg-[#367c2b] border border-[#ffde00]/40 rounded-[6px] flex items-center justify-center shadow-[0_0_15px_rgba(54,124,43,0.35)] transition-transform duration-300 group-hover:scale-105">
        <svg viewBox="0 0 100 100" className="w-6 h-6 md:w-7 md:h-7 fill-[#ffde00]" aria-hidden="true">
          {/* Stylized Leaping Deer inside Shield */}
          <path d="M78 28 C74 24 66 22 58 20 C54 18 52 14 50 10 C49 13 46 17 42 19 C38 21 32 23 28 27 C24 31 22 38 24 45 C25 50 28 54 32 58 L22 72 L32 74 L40 64 C44 65 48 66 52 66 C58 66 64 64 68 60 L78 76 L88 74 L80 54 C82 46 82 36 78 28 Z M48 32 C50 32 52 34 52 36 C52 38 50 40 48 40 C46 40 44 38 44 36 C44 34 46 32 48 32 Z" />
          <polygon points="56,8 60,18 52,16" />
          <polygon points="62,12 68,22 60,20" />
        </svg>
      </div>

      {/* Wordmark */}
      {variant !== 'mark' && (
        <div className="flex flex-col">
          <span className="font-extrabold tracking-[-0.02em] text-lg md:text-xl text-white leading-none font-sans group-hover:text-[#ffde00] transition-colors">
            JOHN DEERE
          </span>
          {variant === 'full' && (
            <span className="text-[9px] uppercase tracking-[0.25em] text-[#9bb097] font-semibold mt-0.5">
              Precision & Power
            </span>
          )}
        </div>
      )}
    </div>
  );
};
