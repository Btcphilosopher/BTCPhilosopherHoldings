import React from 'react';
import { Cpu, Wifi, Wrench, DollarSign, ChevronRight } from 'lucide-react';

interface FeatureStripProps {
  onSelectFeature: (featureKey: string) => void;
}

export const FeatureStrip: React.FC<FeatureStripProps> = ({ onSelectFeature }) => {
  const features = [
    {
      id: 'smart-tech',
      title: 'Smart Technology',
      description: 'Solutions that help you work smarter.',
      icon: Cpu,
      linkText: 'Learn More',
      action: () => onSelectFeature('precision-tech')
    },
    {
      id: 'connected-support',
      title: 'Connected Support™',
      description: 'Always connected. Always optimizing.',
      icon: Wifi,
      linkText: 'Learn More',
      action: () => onSelectFeature('support')
    },
    {
      id: 'parts-service',
      title: 'Parts & Service',
      description: 'Right part. Right now. Right here.',
      icon: Wrench,
      linkText: 'Learn More',
      action: () => onSelectFeature('parts')
    },
    {
      id: 'financial-solutions',
      title: 'Financial Solutions',
      description: 'Flexible financing built for you.',
      icon: DollarSign,
      linkText: 'Learn More',
      action: () => onSelectFeature('financial')
    }
  ];

  return (
    <section id="feature-strip" className="relative w-full bg-[#080d07] border-y border-[#1a2e16] py-6 sm:py-8 select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-0 lg:divide-x divide-[#1f371a]">
          {features.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                onClick={item.action}
                className={`group flex items-start gap-4 p-4 lg:px-6 rounded-xl hover:bg-[#121f10]/80 transition-all duration-300 cursor-pointer ${
                  idx === 0 ? 'lg:pl-2' : ''
                }`}
              >
                {/* Circular Icon with Green Outline */}
                <div className="w-12 h-12 rounded-full bg-[#122410] border border-[#367c2b] flex items-center justify-center text-[#ffde00] shrink-0 shadow-[0_0_12px_rgba(54,124,43,0.3)] group-hover:border-[#ffde00] group-hover:bg-[#1c3818] group-hover:scale-105 transition-all duration-300">
                  <Icon className="w-5 h-5 text-[#ffde00]" />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm sm:text-base font-bold text-[#c7e2c3] group-hover:text-white transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs sm:text-[13px] text-[#86a182] mt-0.5 leading-snug">
                    {item.description}
                  </p>
                  <div className="inline-flex items-center gap-1 mt-2 text-xs font-bold text-[#367c2b] group-hover:text-[#ffde00] transition-colors">
                    <span>{item.linkText}</span>
                    <ChevronRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
