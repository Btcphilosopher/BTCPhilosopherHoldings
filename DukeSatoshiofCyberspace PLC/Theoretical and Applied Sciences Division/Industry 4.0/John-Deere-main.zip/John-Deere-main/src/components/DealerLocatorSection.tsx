import React, { useState } from 'react';
import { 
  MapPin, 
  Search, 
  Phone, 
  Clock, 
  ShieldCheck, 
  Navigation as NavIcon, 
  Check, 
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { DEALERS_DATA } from '../data/dealersData';
import { Dealer } from '../types';

export const DealerLocatorSection: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('Des Moines, IA');
  const [filteredDealers, setFilteredDealers] = useState<Dealer[]>(DEALERS_DATA);
  const [selectedDealer, setSelectedDealer] = useState<Dealer>(DEALERS_DATA[0]);
  const [isLocating, setIsLocating] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchTerm.trim()) {
      setFilteredDealers(DEALERS_DATA);
      return;
    }
    const filtered = DEALERS_DATA.filter(
      d =>
        d.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
        d.state.toLowerCase().includes(searchTerm.toLowerCase()) ||
        d.zip.includes(searchTerm) ||
        d.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredDealers(filtered.length > 0 ? filtered : DEALERS_DATA);
    if (filtered.length > 0) setSelectedDealer(filtered[0]);
  };

  const handleAutoLocate = () => {
    setIsLocating(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        () => {
          setIsLocating(false);
          setSearchTerm('Current Location (Midwest Region)');
          setFilteredDealers(DEALERS_DATA);
        },
        () => {
          setIsLocating(false);
          setSearchTerm('Des Moines, IA');
        }
      );
    } else {
      setIsLocating(false);
    }
  };

  return (
    <section id="dealers" className="w-full bg-[#0d1e0c] py-16 sm:py-24 border-t border-[#23401c] select-none text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl space-y-3 mb-10">
          <span className="text-[11px] font-extrabold uppercase tracking-[0.2em] text-[#ffde00]">
            EXPERIENCE IN PERSON
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight">
            Find Your John Deere Dealer
          </h2>
          <p className="text-sm sm:text-base text-[#c4dcc1]">
            Locate certified agricultural machinery centers, test drive next-generation equipment, order factory parts, and consult with precision ag specialists.
          </p>
        </div>

        {/* Search & Filter Bar */}
        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3 mb-10 max-w-2xl">
          <div className="relative flex-1">
            <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#ffde00]" />
            <input
              type="text"
              placeholder="Enter Postal Code, City, or State..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3.5 rounded-xl bg-[#091508] border border-[#274620] text-white text-sm placeholder-[#7f997a] focus:outline-none focus:border-[#ffde00]"
            />
          </div>

          <button
            type="submit"
            className="px-6 py-3.5 rounded-xl bg-[#ffde00] hover:bg-[#ffe633] text-[#0a1c08] font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg transition-transform hover:scale-[1.02]"
          >
            <Search className="w-4 h-4" />
            <span>Search Dealers</span>
          </button>

          <button
            type="button"
            onClick={handleAutoLocate}
            className="px-4 py-3.5 rounded-xl bg-[#142911] hover:bg-[#1b3817] border border-[#2b4c23] text-xs font-bold text-[#c7dfc4] flex items-center justify-center gap-1.5 transition-colors"
            title="Use current GPS location"
          >
            <NavIcon className={`w-4 h-4 text-[#ffde00] ${isLocating ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Use GPS</span>
          </button>
        </form>

        {/* Dealer Results + Interactive Map Simulation */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Dealer Cards List (5 cols) */}
          <div className="lg:col-span-5 space-y-3 max-h-[500px] overflow-y-auto pr-1">
            {filteredDealers.map((dealer) => {
              const isSelected = selectedDealer?.id === dealer.id;
              return (
                <div
                  key={dealer.id}
                  onClick={() => setSelectedDealer(dealer)}
                  className={`p-5 rounded-2xl transition-all duration-200 cursor-pointer border ${
                    isSelected
                      ? 'bg-[#183614] border-[#ffde00] shadow-[0_4px_20px_rgba(54,124,43,0.4)]'
                      : 'bg-[#10230f] border-[#1f3a1d] hover:bg-[#142d13] text-[#bed5bd]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="text-base font-bold text-white leading-tight">
                        {dealer.name}
                      </h4>
                      <p className="text-xs text-[#9eb89a] mt-1">{dealer.address}</p>
                    </div>
                    <span className="px-2 py-0.5 rounded text-xs font-mono font-bold bg-[#ffde00]/20 text-[#ffde00] shrink-0 border border-[#ffde00]/40">
                      {dealer.distance}
                    </span>
                  </div>

                  <div className="mt-3 pt-3 border-t border-[#234220] flex items-center justify-between text-xs text-[#8da689]">
                    <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5 text-[#ffde00]" /> {dealer.phone}</span>
                    <span className="text-[#86efac] font-semibold">{dealer.inStockCount} Units in Stock</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Selected Dealer Detail & Map Simulation (7 cols) */}
          <div className="lg:col-span-7 rounded-3xl bg-[#091508] border border-[#274620] p-6 sm:p-8 flex flex-col justify-between space-y-6">
            
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1c3619] pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#4ade80]" />
                    <span className="text-xs font-bold text-[#86efac]">OPEN TODAY</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-extrabold text-white mt-1">
                    {selectedDealer.name}
                  </h3>
                </div>

                {selectedDealer.certifiedPrecisionTech && (
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-[#367c2b] text-white">
                    <ShieldCheck className="w-4 h-4 text-[#ffde00]" />
                    Certified Precision Ag Center
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-3.5 rounded-xl bg-[#112410] border border-[#203c1d] space-y-1">
                  <span className="text-[#8da689] block font-semibold">Location & Contact</span>
                  <p className="text-white font-bold">{selectedDealer.address}</p>
                  <a href={`tel:${selectedDealer.phone}`} className="text-[#ffde00] font-bold block pt-1 hover:underline">
                    {selectedDealer.phone}
                  </a>
                </div>

                <div className="p-3.5 rounded-xl bg-[#112410] border border-[#203c1d] space-y-1">
                  <span className="text-[#8da689] block font-semibold">Depot Operating Hours</span>
                  <p className="text-white">{selectedDealer.hours}</p>
                  <span className="text-[#4ade80] font-semibold block pt-1">24/7 Harvest Service Available</span>
                </div>
              </div>

              {/* Certified Capabilities */}
              <div className="space-y-2">
                <span className="text-xs uppercase font-extrabold tracking-wider text-[#8da689]">
                  Available On-Site Services
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {selectedDealer.services.map((srv, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-[#c4dcc1]">
                      <div className="w-4 h-4 rounded-full bg-[#367c2b]/30 text-[#4ade80] flex items-center justify-center shrink-0">
                        <Check className="w-3 h-3" />
                      </div>
                      <span>{srv}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Direct Action Buttons */}
            <div className="pt-4 border-t border-[#1c3619] flex flex-wrap items-center gap-3">
              <a
                href={`https://maps.google.com/?q=${encodeURIComponent(selectedDealer.address)}`}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-3 px-4 rounded-xl bg-[#ffde00] hover:bg-[#ffe633] text-[#0a1c08] font-extrabold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-md text-center"
              >
                <NavIcon className="w-4 h-4" />
                <span>Get Turn-by-Turn Directions</span>
              </a>

              <a
                href={`tel:${selectedDealer.phone}`}
                className="py-3 px-5 rounded-xl bg-[#173014] hover:bg-[#20401c] border border-[#2d5024] text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors"
              >
                <Phone className="w-4 h-4 text-[#ffde00]" />
                <span>Call Store Direct</span>
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
