import React from 'react';
import { ArrowRight, ChevronRight, Sparkles } from 'lucide-react';
import tractor8rImg from '../assets/images/tractor_8r_action_1787232411694.jpg';
import fieldWideImg from '../assets/images/equipment_field_wide_1787232447575.jpg';
import precisionDisplayImg from '../assets/images/precision_ag_display_1787232423130.jpg';
import financialSignImg from '../assets/images/john_deere_financial_1787232435958.jpg';

interface FeaturedEditorialGridProps {
  onSelectEquipment: (id: string) => void;
  onExploreAllEquipment: () => void;
  onOpenPrecisionTech: () => void;
  onOpenFinancial: () => void;
}

export const FeaturedEditorialGrid: React.FC<FeaturedEditorialGridProps> = ({
  onSelectEquipment,
  onExploreAllEquipment,
  onOpenPrecisionTech,
  onOpenFinancial
}) => {
  return (
    <section id="featured-solutions" className="w-full bg-[#0b100a] py-12 sm:py-16 lg:py-20 select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Bento Grid matching Reference Design */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6 items-stretch">
          
          {/* Card 1 — Featured 8R Series Tractors (Spans 5 cols on lg) */}
          <div 
            onClick={() => onSelectEquipment('8r-410')}
            className="lg:col-span-5 group relative rounded-2xl overflow-hidden bg-[#111910] border border-[#263e23] hover:border-[#367c2b] shadow-xl hover:shadow-[0_12px_40px_rgba(0,0,0,0.8)] transition-all duration-500 cursor-pointer flex flex-col justify-between min-h-[440px]"
          >
            {/* Top Text Content */}
            <div className="relative z-10 p-6 sm:p-8 space-y-2">
              <span className="text-[11px] font-extrabold uppercase tracking-[0.18em] text-[#ffde00]">
                FEATURED
              </span>
              <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                8R Series Tractors
              </h3>
              <p className="text-sm text-[#bed5bd] leading-relaxed max-w-sm">
                More power. More comfort. More control.
              </p>

              {/* Action Button */}
              <div className="pt-3">
                <button className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-black/80 hover:bg-[#1a2d18] text-white border border-white/20 text-xs font-bold transition-colors group-hover:border-[#ffde00]/60 group-hover:text-[#ffde00]">
                  <span>Explore 8R Series</span>
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                </button>
              </div>
            </div>

            {/* Bottom Image Area */}
            <div className="relative w-full h-56 sm:h-64 overflow-hidden mt-auto">
              <img
                src={tractor8rImg}
                alt="John Deere 8R Series high power row crop tractor"
                className="w-full h-full object-cover object-center transform group-hover:scale-105 transition-transform duration-700 ease-out"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#111910] via-transparent to-[#111910]/40 pointer-events-none" />
            </div>
          </div>

          {/* Card 2 — Equipment Solutions (Spans 3.5 cols on lg) */}
          <div 
            onClick={onExploreAllEquipment}
            className="lg:col-span-3 group relative rounded-2xl overflow-hidden bg-[#111910] border border-[#263e23] hover:border-[#367c2b] shadow-xl hover:shadow-[0_12px_40px_rgba(0,0,0,0.8)] transition-all duration-500 cursor-pointer flex flex-col justify-between min-h-[440px]"
          >
            {/* Top Text Content */}
            <div className="relative z-10 p-6 sm:p-7 space-y-2">
              <span className="text-[11px] font-extrabold uppercase tracking-[0.18em] text-[#ffde00]">
                BUILT FOR YOUR LAND
              </span>
              <h3 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight leading-snug">
                Equipment Solutions
              </h3>
              <p className="text-xs sm:text-sm text-[#bed5bd] leading-relaxed">
                Find the right equipment for your operation.
              </p>
              <div className="pt-2">
                <span className="inline-flex items-center gap-1 text-xs font-bold text-white group-hover:text-[#ffde00] transition-colors">
                  <span>View All Equipment</span>
                  <ChevronRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </div>

            {/* Bottom Image Area */}
            <div className="relative w-full h-48 sm:h-52 overflow-hidden mt-auto">
              <img
                src={fieldWideImg}
                alt="John Deere equipment working across vast farmland"
                className="w-full h-full object-cover object-center transform group-hover:scale-105 transition-transform duration-700 ease-out"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#111910] via-transparent to-transparent pointer-events-none" />
            </div>
          </div>

          {/* Right Column: Stacked Card 3 & Card 4 (Spans 4 cols on lg) */}
          <div className="lg:col-span-4 flex flex-col gap-6 justify-between">
            
            {/* Card 3 — Precision Upgrades */}
            <div 
              onClick={onOpenPrecisionTech}
              className="group relative rounded-2xl overflow-hidden bg-[#111910] border border-[#263e23] hover:border-[#367c2b] shadow-xl hover:shadow-[0_12px_40px_rgba(0,0,0,0.8)] transition-all duration-500 cursor-pointer p-6 flex flex-row items-center justify-between gap-4 flex-1"
            >
              <div className="space-y-1.5 z-10 flex-1">
                <span className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#ffde00]">
                  PRECISION UPGRADES
                </span>
                <h3 className="text-lg font-extrabold text-white tracking-tight leading-tight">
                  Unleash More From Every Acre
                </h3>
                <p className="text-xs text-[#bed5bd] line-clamp-2">
                  See how precision tech can transform your operation.
                </p>
                <div className="pt-1">
                  <span className="inline-flex items-center gap-1 text-xs font-bold text-white group-hover:text-[#ffde00] transition-colors">
                    <span>Learn More</span>
                    <ChevronRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                  </span>
                </div>
              </div>

              <div className="w-28 sm:w-32 h-24 rounded-xl overflow-hidden shrink-0 border border-[#2a4527]">
                <img
                  src={precisionDisplayImg}
                  alt="John Deere Gen 5 In-Cab touchscreen console"
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

            {/* Card 4 — John Deere Financial */}
            <div 
              onClick={onOpenFinancial}
              className="group relative rounded-2xl overflow-hidden bg-[#111910] border border-[#263e23] hover:border-[#367c2b] shadow-xl hover:shadow-[0_12px_40px_rgba(0,0,0,0.8)] transition-all duration-500 cursor-pointer p-6 flex flex-row items-center justify-between gap-4 flex-1"
            >
              <div className="space-y-1.5 z-10 flex-1">
                <span className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#ffde00]">
                  JOHN DEERE FINANCIAL
                </span>
                <h3 className="text-lg font-extrabold text-white tracking-tight leading-tight">
                  Built to Work. Financed to Fit.
                </h3>
                <p className="text-xs text-[#bed5bd] line-clamp-2">
                  Solutions as reliable as your equipment.
                </p>
                <div className="pt-1">
                  <span className="inline-flex items-center gap-1 text-xs font-bold text-white group-hover:text-[#ffde00] transition-colors">
                    <span>Explore Options</span>
                    <ChevronRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                  </span>
                </div>
              </div>

              <div className="w-28 sm:w-32 h-24 rounded-xl overflow-hidden shrink-0 border border-[#2a4527]">
                <img
                  src={financialSignImg}
                  alt="John Deere Financial corporate landmark sign"
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
