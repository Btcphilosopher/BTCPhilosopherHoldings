import React, { useState, useEffect } from 'react';
import { DeereLogo } from './DeereLogo';
import { 
  Search, 
  MapPin, 
  User, 
  Menu, 
  X, 
  ChevronDown, 
  Tractor, 
  Cpu, 
  Wrench, 
  DollarSign, 
  Globe2, 
  ArrowRight,
  ShieldCheck,
  Wheat,
  Trees,
  Truck
} from 'lucide-react';

interface NavigationProps {
  onOpenSearch: () => void;
  onOpenAccount: () => void;
  onOpenDealerLocator: () => void;
  onOpenFinancialCalc: () => void;
  onSelectCategory: (catId: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  onOpenSearch,
  onOpenAccount,
  onOpenDealerLocator,
  onOpenFinancialCalc,
  onSelectCategory
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currentRegion, setCurrentRegion] = useState('US — Midwest');

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    {
      id: 'equipment',
      label: 'Equipment',
      megaMenu: (
        <div className="grid grid-cols-4 gap-6 p-6 bg-[#0f170e]/95 backdrop-blur-xl border border-[#2d472a] rounded-2xl shadow-2xl">
          <div className="space-y-3 border-r border-[#20331e] pr-4">
            <div className="text-xs uppercase tracking-wider font-bold text-[#ffde00] flex items-center gap-2">
              <Tractor className="w-4 h-4" />
              Agriculture & Turf
            </div>
            <ul className="space-y-2 text-sm text-[#d1e4cf]">
              <li>
                <button 
                  onClick={() => { onSelectCategory('tractors'); setActiveDropdown(null); }}
                  className="hover:text-[#ffde00] transition-colors flex items-center justify-between w-full text-left"
                >
                  <span>Tractors (8R, 9R, 7R, 6R)</span>
                  <span className="text-xs text-[#7f997a]">48 models</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { onSelectCategory('harvesting'); setActiveDropdown(null); }}
                  className="hover:text-[#ffde00] transition-colors flex items-center justify-between w-full text-left"
                >
                  <span>Combines & Headers (X9, S700)</span>
                  <span className="text-xs text-[#7f997a]">18 models</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { onSelectCategory('planting'); setActiveDropdown(null); }}
                  className="hover:text-[#ffde00] transition-colors flex items-center justify-between w-full text-left"
                >
                  <span>Planting & ExactEmerge™</span>
                  <span className="text-xs text-[#7f997a]">22 models</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { onSelectCategory('sprayers'); setActiveDropdown(null); }}
                  className="hover:text-[#ffde00] transition-colors flex items-center justify-between w-full text-left"
                >
                  <span>See & Spray™ Sprayers</span>
                  <span className="text-xs text-[#7f997a]">12 models</span>
                </button>
              </li>
            </ul>
          </div>

          <div className="space-y-3 border-r border-[#20331e] pr-4">
            <div className="text-xs uppercase tracking-wider font-bold text-[#ffde00] flex items-center gap-2">
              <Trees className="w-4 h-4" />
              Lawn & Gator™ Utility
            </div>
            <ul className="space-y-2 text-sm text-[#d1e4cf]">
              <li>
                <button 
                  onClick={() => { onSelectCategory('lawn-care'); setActiveDropdown(null); }}
                  className="hover:text-[#ffde00] transition-colors flex items-center justify-between w-full text-left"
                >
                  <span>Commercial ZTrak™ Mowers</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { onSelectCategory('lawn-care'); setActiveDropdown(null); }}
                  className="hover:text-[#ffde00] transition-colors flex items-center justify-between w-full text-left"
                >
                  <span>Lawn & Garden Tractors</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { onSelectCategory('gator-utility'); setActiveDropdown(null); }}
                  className="hover:text-[#ffde00] transition-colors flex items-center justify-between w-full text-left"
                >
                  <span>Gator™ XUV Crossover UTVs</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { onSelectCategory('construction'); setActiveDropdown(null); }}
                  className="hover:text-[#ffde00] transition-colors flex items-center justify-between w-full text-left"
                >
                  <span>Compact Track Loaders</span>
                </button>
              </li>
            </ul>
          </div>

          <div className="col-span-2 bg-[#172516] p-4 rounded-xl border border-[#2f4a2b] flex flex-col justify-between">
            <div>
              <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-[#ffde00] text-[#0d2209]">
                2027 Flagship Preview
              </span>
              <h4 className="text-base font-extrabold text-white mt-2">
                The Next-Gen 8R 410 Wheel & Track
              </h4>
              <p className="text-xs text-[#a3bfa0] mt-1 line-clamp-2">
                Uncompromising horsepower meets intelligent autonomy, eAutoPowr™ brushless electric drive, and the quiet luxury of CommandView 4.
              </p>
            </div>
            <div className="pt-3 flex items-center justify-between border-t border-[#294226]">
              <span className="text-xs font-semibold text-[#ffde00]">Explore 8R Series Specs</span>
              <button 
                onClick={() => { onSelectCategory('tractors'); setActiveDropdown(null); }}
                className="p-1.5 rounded-lg bg-[#ffde00] text-[#0f240d] hover:bg-[#ffe633] transition-transform hover:translate-x-1"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'technology',
      label: 'Technology',
      megaMenu: (
        <div className="grid grid-cols-3 gap-6 p-6 bg-[#0f170e]/95 backdrop-blur-xl border border-[#2d472a] rounded-2xl shadow-2xl">
          <div className="p-4 rounded-xl bg-[#142013] border border-[#263e24]">
            <div className="w-8 h-8 rounded-lg bg-[#367c2b]/30 flex items-center justify-center text-[#ffde00] mb-3">
              <Cpu className="w-4 h-4" />
            </div>
            <h4 className="text-sm font-bold text-white mb-1">Precision Ag & GPS</h4>
            <p className="text-xs text-[#8ea88a] mb-3">
              StarFire™ 7500 receivers with sub-inch SF-RTK repeatability, AutoTrac™ Turn Automation, and swath control.
            </p>
            <a href="#precision-tech" onClick={() => setActiveDropdown(null)} className="text-xs text-[#ffde00] font-bold hover:underline">
              View Precision Tech →
            </a>
          </div>

          <div className="p-4 rounded-xl bg-[#142013] border border-[#263e24]">
            <div className="w-8 h-8 rounded-lg bg-[#367c2b]/30 flex items-center justify-center text-[#ffde00] mb-3">
              <Globe2 className="w-4 h-4" />
            </div>
            <h4 className="text-sm font-bold text-white mb-1">Operations Center™</h4>
            <p className="text-xs text-[#8ea88a] mb-3">
              Connect your machines, fields, and agronomic advisors to turn real-time data into profitable seasonal prescriptions.
            </p>
            <button onClick={() => { onOpenAccount(); setActiveDropdown(null); }} className="text-xs text-[#ffde00] font-bold hover:underline">
              Launch Portal →
            </button>
          </div>

          <div className="p-4 rounded-xl bg-[#142013] border border-[#263e24]">
            <div className="w-8 h-8 rounded-lg bg-[#367c2b]/30 flex items-center justify-center text-[#ffde00] mb-3">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <h4 className="text-sm font-bold text-white mb-1">Autonomous Systems</h4>
            <p className="text-xs text-[#8ea88a] mb-3">
              6-camera AI vision arrays for 24/7 continuous autonomous tillage with millisecond fail-safe perimeter stopping.
            </p>
            <a href="#precision-tech" onClick={() => setActiveDropdown(null)} className="text-xs text-[#ffde00] font-bold hover:underline">
              See Autonomous R&D →
            </a>
          </div>
        </div>
      )
    },
    {
      id: 'parts-service',
      label: 'Parts & Service',
      megaMenu: (
        <div className="grid grid-cols-3 gap-6 p-6 bg-[#0f170e]/95 backdrop-blur-xl border border-[#2d472a] rounded-2xl shadow-2xl">
          <div className="space-y-2">
            <h4 className="text-xs uppercase font-bold text-[#ffde00] tracking-wider">Parts Catalog</h4>
            <ul className="space-y-1.5 text-sm text-[#c8dac6]">
              <li><a href="#feature-strip" onClick={() => setActiveDropdown(null)} className="hover:text-[#ffde00]">OEM Plus-50™ II Engine Oils</a></li>
              <li><a href="#feature-strip" onClick={() => setActiveDropdown(null)} className="hover:text-[#ffde00]">ExactRate™ Liquid Tubes & Tips</a></li>
              <li><a href="#feature-strip" onClick={() => setActiveDropdown(null)} className="hover:text-[#ffde00]">Camso Heavy-Duty Track Belts</a></li>
              <li><a href="#feature-strip" onClick={() => setActiveDropdown(null)} className="hover:text-[#ffde00]">Hydraulic Cylinders & Valves</a></li>
            </ul>
          </div>
          <div className="space-y-2">
            <h4 className="text-xs uppercase font-bold text-[#ffde00] tracking-wider">Connected Support™</h4>
            <ul className="space-y-1.5 text-sm text-[#c8dac6]">
              <li><a href="#feature-strip" onClick={() => setActiveDropdown(null)} className="hover:text-[#ffde00]">Expert Alerts Diagnostic Monitoring</a></li>
              <li><a href="#feature-strip" onClick={() => setActiveDropdown(null)} className="hover:text-[#ffde00]">Service Advisor Remote Diagnostic</a></li>
              <li><a href="#feature-strip" onClick={() => setActiveDropdown(null)} className="hover:text-[#ffde00]">Remote Display Access (RDA)</a></li>
              <li><a href="#feature-strip" onClick={() => setActiveDropdown(null)} className="hover:text-[#ffde00]">Preventive Maintenance Plans</a></li>
            </ul>
          </div>
          <div className="p-4 rounded-xl bg-[#182816] border border-[#304e2c] flex flex-col justify-between">
            <div>
              <div className="text-xs font-bold text-[#ffde00]">24/7 Harvest Uptime Guarantee</div>
              <p className="text-xs text-[#a2bba0] mt-1">
                If a critical breakdown halts your harvest, participating certified dealers deliver a replacement unit within 12 hours.
              </p>
            </div>
            <button 
              onClick={() => { onOpenDealerLocator(); setActiveDropdown(null); }}
              className="mt-3 py-1.5 px-3 rounded-lg bg-[#367c2b] text-white text-xs font-bold hover:bg-[#439636] transition-colors"
            >
              Locate Nearest Depot
            </button>
          </div>
        </div>
      )
    },
    {
      id: 'solutions',
      label: 'Solutions',
      target: '#featured-solutions'
    },
    {
      id: 'financial',
      label: 'Financial',
      action: onOpenFinancialCalc
    },
    {
      id: 'company',
      label: 'Company',
      target: '#latest-news'
    }
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#090e09]/90 backdrop-blur-md border-b border-[#21351e]/80 py-3 shadow-[0_10px_30px_rgba(0,0,0,0.6)]'
            : 'bg-gradient-to-b from-black/85 via-black/40 to-transparent py-4 md:py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Logo */}
          <a href="#" className="flex items-center">
            <DeereLogo variant="full" />
          </a>

          {/* Desktop Center Navigation */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navItems.map((item) => (
              <div
                key={item.id}
                className="relative"
                onMouseEnter={() => item.megaMenu && setActiveDropdown(item.id)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                {item.action ? (
                  <button
                    onClick={item.action}
                    className="px-3.5 py-2 text-sm font-semibold text-[#f0f5ee] hover:text-[#ffde00] transition-colors flex items-center gap-1 rounded-lg hover:bg-white/5"
                  >
                    <span>{item.label}</span>
                  </button>
                ) : item.target ? (
                  <a
                    href={item.target}
                    className="px-3.5 py-2 text-sm font-semibold text-[#f0f5ee] hover:text-[#ffde00] transition-colors flex items-center gap-1 rounded-lg hover:bg-white/5"
                  >
                    <span>{item.label}</span>
                  </a>
                ) : (
                  <button
                    onClick={() => setActiveDropdown(activeDropdown === item.id ? null : item.id)}
                    className={`px-3.5 py-2 text-sm font-semibold transition-colors flex items-center gap-1 rounded-lg ${
                      activeDropdown === item.id
                        ? 'text-[#ffde00] bg-white/10'
                        : 'text-[#f0f5ee] hover:text-[#ffde00] hover:bg-white/5'
                    }`}
                  >
                    <span>{item.label}</span>
                    <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${
                      activeDropdown === item.id ? 'rotate-180 text-[#ffde00]' : 'text-[#8da689]'
                    }`} />
                  </button>
                )}

                {/* Mega Menu Dropdown */}
                {item.megaMenu && activeDropdown === item.id && (
                  <div className="absolute top-full left-1/2 -translate-x-1/2 pt-3 w-[720px] xl:w-[820px] animate-fade-in">
                    {item.megaMenu}
                  </div>
                )}
              </div>
            ))}
          </nav>

          {/* Right Action Icons & Find a Dealer CTA */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Search */}
            <button
              onClick={onOpenSearch}
              className="p-2 text-[#d4e4d0] hover:text-[#ffde00] hover:bg-white/10 rounded-full transition-colors relative group"
              title="Search (⌘K)"
              aria-label="Search"
            >
              <Search className="w-5 h-5" />
              <span className="hidden sm:inline-block absolute -bottom-7 left-1/2 -translate-x-1/2 px-1.5 py-0.5 bg-black/90 text-[10px] text-[#ffde00] rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap border border-[#2b4427]">
                Search ⌘K
              </span>
            </button>

            {/* Region / Location Selector */}
            <div className="relative group hidden sm:block">
              <button
                className="p-2 text-[#d4e4d0] hover:text-[#ffde00] hover:bg-white/10 rounded-full transition-colors flex items-center gap-1 text-xs"
                title="Select Region"
                aria-label="Region"
              >
                <MapPin className="w-5 h-5" />
              </button>
            </div>

            {/* MyJohnDeere Account */}
            <button
              onClick={onOpenAccount}
              className="p-2 text-[#d4e4d0] hover:text-[#ffde00] hover:bg-white/10 rounded-full transition-colors relative"
              title="MyJohnDeere Account"
              aria-label="MyJohnDeere Account"
            >
              <User className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#ffde00]" />
            </button>

            {/* Find a Dealer — Iconic Yellow Button */}
            <button
              onClick={onOpenDealerLocator}
              className="relative inline-flex items-center gap-2 px-4 sm:px-5 py-2 sm:py-2.5 rounded-full bg-[#ffde00] hover:bg-[#ffe633] text-[#0b1c09] font-extrabold text-xs sm:text-sm tracking-tight transition-all duration-200 shadow-[0_4px_16px_rgba(255,222,0,0.35)] hover:shadow-[0_6px_22px_rgba(255,222,0,0.55)] hover:scale-[1.02] active:scale-[0.98]"
            >
              <MapPin className="w-4 h-4 text-[#0b1c09]" />
              <span>Find a Dealer</span>
            </button>

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-white hover:text-[#ffde00] rounded-lg hover:bg-white/10 transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Slide-Over Navigation */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden bg-black/80 backdrop-blur-lg pt-20 px-5 pb-8 overflow-y-auto animate-fade-in">
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-[#152214] border border-[#2c472a] space-y-3">
              <div className="text-xs uppercase font-bold text-[#ffde00]">Equipment Categories</div>
              <div className="grid grid-cols-2 gap-2">
                <button 
                  onClick={() => { onSelectCategory('tractors'); setMobileMenuOpen(false); }}
                  className="p-2.5 rounded-lg bg-[#0e170d] text-left text-xs font-semibold text-white flex items-center gap-2"
                >
                  <Tractor className="w-4 h-4 text-[#ffde00]" />
                  Tractors (8R, 9R)
                </button>
                <button 
                  onClick={() => { onSelectCategory('harvesting'); setMobileMenuOpen(false); }}
                  className="p-2.5 rounded-lg bg-[#0e170d] text-left text-xs font-semibold text-white flex items-center gap-2"
                >
                  <Wheat className="w-4 h-4 text-[#ffde00]" />
                  Combines (X9)
                </button>
                <button 
                  onClick={() => { onSelectCategory('lawn-care'); setMobileMenuOpen(false); }}
                  className="p-2.5 rounded-lg bg-[#0e170d] text-left text-xs font-semibold text-white flex items-center gap-2"
                >
                  <Trees className="w-4 h-4 text-[#ffde00]" />
                  Lawn Care
                </button>
                <button 
                  onClick={() => { onSelectCategory('gator-utility'); setMobileMenuOpen(false); }}
                  className="p-2.5 rounded-lg bg-[#0e170d] text-left text-xs font-semibold text-white flex items-center gap-2"
                >
                  <Truck className="w-4 h-4 text-[#ffde00]" />
                  Gator™ UTVs
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <a
                href="#precision-tech"
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-between p-3 rounded-lg text-white font-semibold text-sm hover:bg-[#1c2c1a]"
              >
                <span>Precision Agriculture Technology</span>
                <ChevronDown className="w-4 h-4 -rotate-90 text-[#8da689]" />
              </a>
              <button
                onClick={() => { onOpenFinancialCalc(); setMobileMenuOpen(false); }}
                className="flex items-center justify-between w-full p-3 rounded-lg text-white font-semibold text-sm hover:bg-[#1c2c1a] text-left"
              >
                <span>John Deere Financial Calculator</span>
                <DollarSign className="w-4 h-4 text-[#ffde00]" />
              </button>
              <a
                href="#latest-news"
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-between p-3 rounded-lg text-white font-semibold text-sm hover:bg-[#1c2c1a]"
              >
                <span>Latest News & Innovation</span>
                <ChevronDown className="w-4 h-4 -rotate-90 text-[#8da689]" />
              </a>
              <button
                onClick={() => { onOpenAccount(); setMobileMenuOpen(false); }}
                className="flex items-center justify-between w-full p-3 rounded-lg text-white font-semibold text-sm hover:bg-[#1c2c1a] text-left"
              >
                <span>MyJohnDeere Portal</span>
                <User className="w-4 h-4 text-[#ffde00]" />
              </button>
            </div>

            <div className="pt-4 border-t border-[#223820]">
              <button
                onClick={() => { onOpenDealerLocator(); setMobileMenuOpen(false); }}
                className="w-full py-3 rounded-xl bg-[#ffde00] text-[#0d2209] font-extrabold text-sm flex items-center justify-center gap-2"
              >
                <MapPin className="w-4 h-4" />
                Find a Dealer Nearby
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
