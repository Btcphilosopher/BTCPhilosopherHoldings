import React, { useState, useEffect } from 'react';
import { 
  X, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize2, 
  Activity, 
  Compass, 
  Sparkles,
  RotateCcw,
  CheckCircle2
} from 'lucide-react';
import heroTractor from '../assets/images/hero_tractor_field_1787232401942.jpg';
import combineHarvest from '../assets/images/combine_x9_harvest_1787232459081.jpg';
import autoTractor from '../assets/images/autonomous_tractor_1787232481586.jpg';

interface VideoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({ isOpen, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(15);
  const [currentChapter, setCurrentChapter] = useState(0);
  const [showTelemetryHUD, setShowTelemetryHUD] = useState(true);

  const chapters = [
    { title: '01. Dawn in the Heartland', duration: '0:42', image: heroTractor, subtitle: 'Flagship 8R 410 Wheel & Track in Golden Hour Tillage' },
    { title: '02. Dual Rotor X9 Capacity', duration: '1:14', image: combineHarvest, subtitle: 'Harvesting 100+ Metric Tons per Hour at 0.4% Grain Loss' },
    { title: '03. 24/7 Autonomous Perception', duration: '0:44', image: autoTractor, subtitle: 'Multi-Stereo Vision and Millisecond Boundary Stopping' }
  ];

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isOpen && isPlaying) {
      timer = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            setCurrentChapter((ch) => (ch + 1) % chapters.length);
            return 0;
          }
          return prev + 1;
        });
      }, 300);
    }
    return () => clearInterval(timer);
  }, [isOpen, isPlaying, chapters.length]);

  if (!isOpen) return null;

  const currentChData = chapters[currentChapter];

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 sm:p-6 bg-black/90 backdrop-blur-xl animate-fade-in select-none">
      <div 
        className="w-full max-w-5xl bg-[#090e08] border border-[#2b4427] rounded-3xl overflow-hidden shadow-[0_25px_90px_rgba(0,0,0,0.95)] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Video Top Bar */}
        <div className="p-4 sm:px-6 bg-[#0f170e] border-b border-[#21351e] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-[#ffde00] animate-ping" />
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-[#ffde00]">
                John Deere Cinematic Stream • 4K HDR
              </div>
              <div className="text-sm font-extrabold text-white">
                {currentChData.title}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowTelemetryHUD(!showTelemetryHUD)}
              className={`px-3 py-1 text-xs font-bold rounded-lg border transition-colors ${
                showTelemetryHUD
                  ? 'bg-[#367c2b]/40 border-[#ffde00] text-[#ffde00]'
                  : 'bg-[#141f13] border-[#223520] text-[#8da689]'
              }`}
            >
              Telemetry HUD {showTelemetryHUD ? 'ON' : 'OFF'}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-[#8da689] hover:text-white hover:bg-[#1a2b18] transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Video Canvas Stage */}
        <div className="relative aspect-[16/9] w-full bg-black overflow-hidden group">
          <img
            src={currentChData.image}
            alt={currentChData.title}
            className="w-full h-full object-cover transition-all duration-1000 transform scale-105"
            referrerPolicy="no-referrer"
          />

          {/* Ambient Lighting Gradients */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 pointer-events-none" />

          {/* Real-Time Telemetry HUD Overlay */}
          {showTelemetryHUD && (
            <div className="absolute top-4 left-4 right-4 flex items-start justify-between pointer-events-none animate-fade-in">
              <div className="p-3 rounded-xl bg-black/60 backdrop-blur-md border border-white/10 text-xs font-mono space-y-1">
                <div className="text-[#ffde00] font-bold flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5" />
                  <span>JDLink™ CAN-BUS FEED</span>
                </div>
                <div className="text-white">ENGINE LOAD: <strong className="text-[#86efac]">76.4%</strong></div>
                <div className="text-white">GROUND SPEED: <strong>5.8 MPH</strong></div>
                <div className="text-white">SF-RTK DRIFT: <strong className="text-[#38bdf8]">&lt; 0.4 CM</strong></div>
              </div>

              <div className="p-3 rounded-xl bg-black/60 backdrop-blur-md border border-white/10 text-right text-xs font-mono">
                <div className="text-[#8da689]">LOCATION</div>
                <div className="text-white font-bold">DES MOINES VALLEY, IA</div>
                <div className="text-[#ffde00] text-[10px]">ELEVATION 980 FT</div>
              </div>
            </div>
          )}

          {/* Subtitle Bar */}
          <div className="absolute bottom-16 left-6 right-6 text-center pointer-events-none">
            <span className="inline-block px-4 py-1.5 rounded-xl bg-black/75 backdrop-blur-md text-sm text-[#f0f5ee] font-medium border border-white/10 shadow-lg">
              {currentChData.subtitle}
            </span>
          </div>

          {/* Player Controls Bar */}
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black via-black/80 to-transparent flex items-center justify-between gap-4">
            
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="w-10 h-10 rounded-full bg-[#ffde00] text-[#0a1c08] flex items-center justify-center hover:scale-105 transition-transform"
              >
                {isPlaying ? <Pause className="w-5 h-5 fill-[#0a1c08]" /> : <Play className="w-5 h-5 fill-[#0a1c08] translate-x-0.5" />}
              </button>

              <button
                onClick={() => setIsMuted(!isMuted)}
                className="p-2 rounded-lg text-white hover:text-[#ffde00] transition-colors"
              >
                {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
              </button>

              <span className="text-xs font-mono text-[#8da689]">
                0:{Math.floor(progress * 0.42).toString().padStart(2, '0')} / {currentChData.duration}
              </span>
            </div>

            {/* Scrubber Bar */}
            <div className="flex-1 max-w-md mx-4 h-1.5 bg-white/20 rounded-full overflow-hidden cursor-pointer">
              <div 
                className="h-full bg-[#ffde00] transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>

            {/* Chapter Selection Pills */}
            <div className="hidden sm:flex items-center gap-2">
              {chapters.map((ch, idx) => (
                <button
                  key={idx}
                  onClick={() => { setCurrentChapter(idx); setProgress(0); }}
                  className={`px-2.5 py-1 text-[11px] font-bold rounded-md transition-colors ${
                    currentChapter === idx
                      ? 'bg-[#367c2b] text-white border border-[#ffde00]/50'
                      : 'bg-white/10 text-[#a3bfa0] hover:text-white'
                  }`}
                >
                  Ch. {idx + 1}
                </button>
              ))}
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
