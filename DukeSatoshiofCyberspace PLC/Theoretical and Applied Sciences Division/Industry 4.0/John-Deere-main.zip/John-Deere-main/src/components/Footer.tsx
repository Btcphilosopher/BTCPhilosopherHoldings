import React, { useState } from 'react';
import { DeereLogo } from './DeereLogo';
import { Globe, ArrowUp, Shield, HelpCircle } from 'lucide-react';

interface FooterProps {
  onOpenSearch: () => void;
  onOpenDealerLocator: () => void;
  onOpenFinancialCalc: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenSearch,
  onOpenDealerLocator,
  onOpenFinancialCalc
}) => {
  const [selectedRegion, setSelectedRegion] = useState('United States (English)');

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const footerLinks = {
    equipment: [
      { label: '8R & 9R Tractors', href: '#equipment-explorer' },
      { label: 'X9 Combine Harvesters', href: '#equipment-explorer' },
      { label: 'ExactEmerge™ Planters', href: '#equipment-explorer' },
      { label: 'Gator™ Utility Vehicles', href: '#equipment-explorer' },
      { label: 'Commercial Turf Mowers', href: '#equipment-explorer' }
    ],
    technology: [
      { label: 'StarFire™ 7500 GNSS', href: '#precision-tech' },
      { label: 'See & Spray™ Ultimate', href: '#precision-tech' },
      { label: 'Operations Center™ PRO', href: '#precision-tech' },
      { label: 'Autonomous Fleet Systems', href: '#precision-tech' },
      { label: 'JDLink™ Telemetry', href: '#precision-tech' }
    ],
    services: [
      { label: 'Connected Support™', href: '#feature-strip' },
      { label: 'Expert Alerts Monitoring', href: '#feature-strip' },
      { label: 'Genuine OEM Parts Depot', href: '#feature-strip' },
      { label: 'Seasonal Maintenance Plans', href: '#dealers' },
      { label: 'Safety & Training Manuals', href: '#dealers' }
    ],
    financial: [
      { label: 'Lease & Loan Programs', action: onOpenFinancialCalc },
      { label: 'Multi-Use Ag Accounts', action: onOpenFinancialCalc },
      { label: 'Pre-Season Harvest Terms', action: onOpenFinancialCalc },
      { label: 'Crop Insurance Solutions', action: onOpenFinancialCalc }
    ],
    company: [
      { label: 'About John Deere', href: '#latest-news' },
      { label: 'Sustainability & ESG', href: '#latest-news' },
      { label: 'News & Media Center', href: '#latest-news' },
      { label: 'Careers & Engineering R&D', href: '#latest-news' },
      { label: 'Investor Relations', href: '#latest-news' }
    ]
  };

  return (
    <footer className="w-full bg-[#050804] text-[#8ea88a] border-t border-[#1a2d17] pt-16 pb-12 select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Footer Tier: Brand & Back to Top */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 pb-12 border-b border-[#182916]">
          <DeereLogo variant="full" />

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#0d160c] border border-[#1f331b] text-xs text-[#bed5bd]">
              <Globe className="w-3.5 h-3.5 text-[#ffde00]" />
              <select 
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
                className="bg-transparent text-white focus:outline-none cursor-pointer"
              >
                <option value="United States (English)" className="bg-[#0f160e]">United States (English)</option>
                <option value="Canada (English / Français)" className="bg-[#0f160e]">Canada (English / Français)</option>
                <option value="Europe (English)" className="bg-[#0f160e]">Europe (English)</option>
                <option value="Australia & New Zealand" className="bg-[#0f160e]">Australia & New Zealand</option>
                <option value="Latin America (Español / Português)" className="bg-[#0f160e]">Latin America</option>
              </select>
            </div>

            <button
              onClick={scrollToTop}
              className="p-2.5 rounded-lg bg-[#111d10] hover:bg-[#1a2e18] text-white border border-[#21351e] transition-colors"
              title="Scroll to top"
              aria-label="Scroll to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Middle Footer Tier: Navigation Columns */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 py-12 border-b border-[#182916]">
          
          <div className="space-y-3">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-white">
              Equipment
            </h4>
            <ul className="space-y-2 text-xs">
              {footerLinks.equipment.map((item, idx) => (
                <li key={idx}>
                  <a href={item.href} className="hover:text-[#ffde00] transition-colors">
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-white">
              Technology
            </h4>
            <ul className="space-y-2 text-xs">
              {footerLinks.technology.map((item, idx) => (
                <li key={idx}>
                  <a href={item.href} className="hover:text-[#ffde00] transition-colors">
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-white">
              Parts & Service
            </h4>
            <ul className="space-y-2 text-xs">
              {footerLinks.services.map((item, idx) => (
                <li key={idx}>
                  <a href={item.href} className="hover:text-[#ffde00] transition-colors">
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-white">
              Financial
            </h4>
            <ul className="space-y-2 text-xs">
              {footerLinks.financial.map((item, idx) => (
                <li key={idx}>
                  <button onClick={item.action} className="hover:text-[#ffde00] transition-colors text-left">
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-white">
              Company & Impact
            </h4>
            <ul className="space-y-2 text-xs">
              {footerLinks.company.map((item, idx) => (
                <li key={idx}>
                  <a href={item.href} className="hover:text-[#ffde00] transition-colors">
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

        </div>

        {/* Bottom Footer Tier: Legal & Compliance */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-[#70856d]">
          <div className="flex flex-wrap items-center gap-4">
            <span>© {new Date().getFullYear()} Deere & Company. All Rights Reserved.</span>
            <a href="#" className="hover:text-white">Privacy & Data Governance</a>
            <a href="#" className="hover:text-white">Terms of Use</a>
            <a href="#" className="hover:text-white">Accessibility</a>
            <a href="#" className="hover:text-white">Security & Vulnerability Disclosure</a>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-[#ffde00]">
            <Shield className="w-3.5 h-3.5" />
            <span>ISO 27001 Certified Ag Data Privacy</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
