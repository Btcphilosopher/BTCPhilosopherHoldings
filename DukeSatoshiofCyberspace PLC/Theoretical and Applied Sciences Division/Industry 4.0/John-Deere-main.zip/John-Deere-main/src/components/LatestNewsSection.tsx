import React, { useState } from 'react';
import { ArrowRight, Calendar, Clock, BookOpen, ChevronRight, Sparkles } from 'lucide-react';
import { NEWS_ARTICLES } from '../data/newsData';
import { NewsArticle } from '../types';

export const LatestNewsSection: React.FC = () => {
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);

  const featured = NEWS_ARTICLES.find(n => n.featured) || NEWS_ARTICLES[0];
  const sideArticles = NEWS_ARTICLES.filter(n => n.id !== featured.id);

  return (
    <section id="latest-news" className="w-full bg-[#0b100a] py-16 sm:py-24 border-t border-[#182a15] select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with "View All News →" */}
        <div className="flex items-end justify-between gap-4 mb-10 border-b border-[#1f331c] pb-5">
          <div className="space-y-1">
            <span className="text-[11px] uppercase font-extrabold tracking-[0.2em] text-[#ffde00]">
              WHAT'S NEW
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Latest From John Deere
            </h2>
          </div>

          <a 
            href="#latest-news" 
            className="inline-flex items-center gap-1.5 text-xs font-bold text-[#bed5bd] hover:text-[#ffde00] transition-colors"
          >
            <span>View All News</span>
            <ChevronRight className="w-4 h-4" />
          </a>
        </div>

        {/* Editorial Articles Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Main Featured Article (Spans 7 cols) */}
          <div 
            onClick={() => setSelectedArticle(featured)}
            className="lg:col-span-7 group rounded-3xl bg-[#10190f] border border-[#21351e] hover:border-[#367c2b] shadow-xl overflow-hidden cursor-pointer transition-all duration-300 flex flex-col justify-between"
          >
            <div className="relative w-full aspect-[16/10] overflow-hidden bg-black">
              <img
                src={featured.image}
                alt={featured.title}
                className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700 ease-out"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#10190f] via-transparent to-transparent pointer-events-none" />
              
              <div className="absolute top-4 left-4">
                <span className="px-3 py-1 rounded-full text-xs font-extrabold uppercase bg-[#ffde00] text-[#0d2209]">
                  {featured.category}
                </span>
              </div>
            </div>

            <div className="p-6 sm:p-8 space-y-3">
              <div className="flex items-center gap-4 text-xs text-[#8da689]">
                <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> {featured.date}</span>
                <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {featured.readTime}</span>
              </div>

              <h3 className="text-xl sm:text-2xl font-extrabold text-white group-hover:text-[#ffde00] transition-colors leading-tight">
                {featured.title}
              </h3>

              <p className="text-sm text-[#bed5bd] leading-relaxed line-clamp-3">
                {featured.summary}
              </p>

              <div className="pt-3">
                <span className="inline-flex items-center gap-1 text-xs font-bold text-[#ffde00] group-hover:underline">
                  <span>Read In-Depth Story</span>
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </div>
          </div>

          {/* Secondary Articles Stack (Spans 5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            {sideArticles.map((article) => (
              <div
                key={article.id}
                onClick={() => setSelectedArticle(article)}
                className="group p-5 rounded-2xl bg-[#10190f] border border-[#21351e] hover:border-[#367c2b] shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer flex gap-4 items-center"
              >
                <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-xl overflow-hidden shrink-0 bg-black/50 border border-[#263e23]">
                  <img
                    src={article.image}
                    alt={article.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="flex-1 min-w-0 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] text-[#8da689]">
                    <span className="font-bold text-[#ffde00] uppercase">{article.category}</span>
                    <span>{article.readTime}</span>
                  </div>

                  <h4 className="text-sm font-bold text-white group-hover:text-[#ffde00] transition-colors line-clamp-2 leading-snug">
                    {article.title}
                  </h4>

                  <p className="text-xs text-[#a3bfa0] line-clamp-2">
                    {article.summary}
                  </p>
                </div>
              </div>
            ))}
          </div>

        </div>

        {/* Read Article Modal View */}
        {selectedArticle && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-fade-in">
            <div 
              className="w-full max-w-3xl bg-[#0e160d] border border-[#2e472a] rounded-3xl overflow-hidden shadow-2xl p-6 sm:p-8 space-y-6 max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between border-b border-[#223820] pb-4">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#ffde00] text-[#0d2209]">
                  {selectedArticle.category}
                </span>
                <button 
                  onClick={() => setSelectedArticle(null)}
                  className="text-xs text-[#8da689] hover:text-white px-2.5 py-1 rounded-lg bg-[#152313]"
                >
                  Close
                </button>
              </div>

              <div className="space-y-3">
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                  {selectedArticle.title}
                </h2>
                <div className="text-xs text-[#8da689] flex items-center gap-3">
                  <span>By {selectedArticle.author}</span>
                  <span>•</span>
                  <span>{selectedArticle.date}</span>
                  <span>•</span>
                  <span>{selectedArticle.readTime}</span>
                </div>
              </div>

              <div className="rounded-2xl overflow-hidden max-h-72">
                <img
                  src={selectedArticle.image}
                  alt={selectedArticle.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="prose prose-invert text-sm text-[#c8dac6] leading-relaxed space-y-4">
                <p>{selectedArticle.summary}</p>
                <p>
                  As agricultural operations expand to meet global food security goals, John Deere continues to engineer hardware and cloud solutions that multiply per-acre productivity while reducing fuel, chemical inputs, and operator fatigue.
                </p>
                <p>
                  Connect with your regional John Deere dealer today or open the Operations Center portal to explore these breakthroughs on your own fields.
                </p>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
