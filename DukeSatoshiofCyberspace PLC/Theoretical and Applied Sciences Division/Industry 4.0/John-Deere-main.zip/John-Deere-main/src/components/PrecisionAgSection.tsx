import React, { useState, useEffect } from 'react';
import { 
  Cpu, 
  Wifi, 
  ShieldCheck, 
  Activity, 
  Map, 
  Zap, 
  Eye, 
  TrendingUp, 
  Sliders, 
  Layers,
  ChevronRight,
  Compass
} from 'lucide-react';
import displayImg from '../assets/images/precision_ag_display_1787232423130.jpg';
import autoTractorImg from '../assets/images/autonomous_tractor_1787232481586.jpg';

export const PrecisionAgSection: React.FC = () => {
  const [activeTech, setActiveTech] = useState<'guidance' | 'spray' | 'cloud' | 'autonomous'>('guidance');
  const [liveMetrics, setLiveMetrics] = useState({
    fieldPerformance: 94.7,
    connectedMachines: 18,
    acresOptimized: 2480,
    fuelGain: 14.2
  });

  // Simulated live telemetry fluctuation
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveMetrics(prev => ({
        ...prev,
        fieldPerformance: Number((94.5 + Math.random() * 0.4).toFixed(1)),
        acresOptimized: prev.acresOptimized + Math.floor(Math.random() * 2)
      }));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const techFeatures = [
    {
      id: 'guidance',
      title: 'AutoTrac™ & StarFire™ 7500',
      subtitle: 'Sub-inch Satellite Guidance',
      badge: '0.6-INCH REPEATABILITY',
      description: 'Multi-constellation GNSS receiver pulls in SF-RTK correction signal in under 60 seconds, eliminating overlap and reducing input waste by up to 12% per acre.',
      icon: Compass,
      stats: [
        { label: 'Pass-to-Pass Accuracy', value: '< 1.5 cm' },
        { label: 'Pull-in Signal Time', value: '< 45 sec' },
        { label: 'Overlap Reduction', value: '11.8%' }
      ]
    },
    {
      id: 'spray',
      title: 'See & Spray™ Ultimate',
      subtitle: 'Targeted AI Computer Vision',
      badge: 'DUAL PRODUCT SYSTEM',
      description: '36 high-resolution cameras running 50 frames per second identify emerging weeds in milliseconds, spraying herbicide only where needed and saving over 65% in chemical costs.',
      icon: Eye,
      stats: [
        { label: 'Herbicide Reduction', value: 'Up to 67%' },
        { label: 'Camera Array Frame Rate', value: '50 FPS' },
        { label: 'Operational Speed', value: '12 MPH' }
      ]
    },
    {
      id: 'cloud',
      title: 'John Deere Operations Center™',
      subtitle: 'Connected Cloud Ecosystem',
      badge: 'REAL-TIME DATA STREAM',
      description: 'Seamless machine-to-cloud sync wirelessly delivers agronomic prescriptions, yield metrics, and fuel telemetry to your phone, tablet, and trusted agronomist instantly.',
      icon: Wifi,
      stats: [
        { label: 'Wireless Sync Delay', value: '< 800 ms' },
        { label: 'Connected Farm Apps', value: '250+' },
        { label: 'Data Security', value: 'ISO 27001' }
      ]
    },
    {
      id: 'autonomous',
      title: 'Autonomous 24/7 Field Platform',
      subtitle: 'Unattended Robotic Operations',
      badge: 'ZERO IN-CAB OPERATOR',
      description: 'Equipped with 6 stereo camera pairs and continuous neural network classification to navigate boundaries, avoid unmapped obstacles, and till fields around the clock.',
      icon: Cpu,
      stats: [
        { label: 'Obstacle Detection', value: '360° LiDAR' },
        { label: 'Field Runtime', value: '24 Hours/Day' },
        { label: 'Safety Response', value: '< 100 ms' }
      ]
    }
  ];

  const currentFeature = techFeatures.find(t => t.id === activeTech) || techFeatures[0];

  return (
    <section id="precision-tech" className="relative w-full bg-[#070b06] py-16 sm:py-24 border-t border-[#1b3118] overflow-hidden select-none">
      
      {/* Background Technology Grid and Subtle Radar Accent */}
      <div className="absolute inset-0 tech-grid opacity-20 pointer-events-none" />
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#367c2b]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 lg:mb-16">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#172d14] border border-[#ffde00]/40 text-[#ffde00] text-xs font-extrabold tracking-wider">
              <Zap className="w-3.5 h-3.5" />
              <span>COMPUTATIONAL AGRICULTURE PLATFORM</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight leading-none">
              PRECISION AGRICULTURE
            </h2>
            <p className="text-base sm:text-lg text-[#bed5bd] font-normal leading-relaxed">
              More intelligence. More control. More from every acre.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="px-3.5 py-1.5 rounded-lg bg-[#142312] border border-[#274224] text-xs text-[#8da689] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#4ade80] animate-pulse" />
              <span>Global Telemetry: <strong>Active</strong></span>
            </div>
          </div>
        </div>

        {/* Live Telemetry Metrics Display Grid (Matching Requirement 13) */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-12">
          
          <div className="p-5 sm:p-6 rounded-2xl bg-[#0f180e] border border-[#263e23] shadow-lg relative overflow-hidden group">
            <div className="text-xs uppercase font-extrabold tracking-wider text-[#ffde00] flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5" />
              FIELD PERFORMANCE
            </div>
            <div className="text-3xl sm:text-4xl font-extrabold text-white mt-2">
              {liveMetrics.fieldPerformance}%
            </div>
            <p className="text-[11px] text-[#7f997a] mt-1">Real-time guidance accuracy score</p>
            <div className="absolute top-0 right-0 w-16 h-16 bg-[#367c2b]/15 rounded-bl-full pointer-events-none" />
          </div>

          <div className="p-5 sm:p-6 rounded-2xl bg-[#0f180e] border border-[#263e23] shadow-lg relative overflow-hidden group">
            <div className="text-xs uppercase font-extrabold tracking-wider text-[#ffde00] flex items-center gap-1.5">
              <Wifi className="w-3.5 h-3.5" />
              CONNECTED MACHINES
            </div>
            <div className="text-3xl sm:text-4xl font-extrabold text-white mt-2">
              {liveMetrics.connectedMachines}
            </div>
            <p className="text-[11px] text-[#7f997a] mt-1">JDLink™ synchronized fleet units</p>
            <div className="absolute top-0 right-0 w-16 h-16 bg-[#367c2b]/15 rounded-bl-full pointer-events-none" />
          </div>

          <div className="p-5 sm:p-6 rounded-2xl bg-[#0f180e] border border-[#263e23] shadow-lg relative overflow-hidden group">
            <div className="text-xs uppercase font-extrabold tracking-wider text-[#ffde00] flex items-center gap-1.5">
              <Map className="w-3.5 h-3.5" />
              ACRES OPTIMIZED
            </div>
            <div className="text-3xl sm:text-4xl font-extrabold text-white mt-2">
              {liveMetrics.acresOptimized.toLocaleString()}+
            </div>
            <p className="text-[11px] text-[#7f997a] mt-1">Active season field mapping</p>
            <div className="absolute top-0 right-0 w-16 h-16 bg-[#367c2b]/15 rounded-bl-full pointer-events-none" />
          </div>

          <div className="p-5 sm:p-6 rounded-2xl bg-[#0f180e] border border-[#263e23] shadow-lg relative overflow-hidden group">
            <div className="text-xs uppercase font-extrabold tracking-wider text-[#ffde00] flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5" />
              FUEL EFFICIENCY GAIN
            </div>
            <div className="text-3xl sm:text-4xl font-extrabold text-[#4ade80] mt-2">
              +{liveMetrics.fuelGain}%
            </div>
            <p className="text-[11px] text-[#7f997a] mt-1">Via automated throttle & gear matching</p>
            <div className="absolute top-0 right-0 w-16 h-16 bg-[#367c2b]/15 rounded-bl-full pointer-events-none" />
          </div>

        </div>

        {/* Interactive Technology Experience Module */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center rounded-3xl bg-[#0e160d] border border-[#223820] p-6 sm:p-8 lg:p-10 shadow-2xl">
          
          {/* Left Column: Tech Selector Tabs */}
          <div className="lg:col-span-5 space-y-3">
            <div className="text-xs uppercase tracking-wider font-extrabold text-[#8da689] mb-4">
              Explore Technology Pillars
            </div>

            {techFeatures.map((tech) => {
              const Icon = tech.icon;
              const isSelected = activeTech === tech.id;
              return (
                <button
                  key={tech.id}
                  onClick={() => setActiveTech(tech.id as any)}
                  className={`w-full text-left p-4 rounded-xl transition-all duration-300 flex items-start gap-4 border ${
                    isSelected
                      ? 'bg-[#182915] border-[#ffde00] text-white shadow-[0_4px_20px_rgba(54,124,43,0.3)]'
                      : 'bg-[#121c11] border-[#1e301c] text-[#a4bea0] hover:bg-[#162415] hover:text-white'
                  }`}
                >
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${
                    isSelected ? 'bg-[#ffde00] text-[#0a1c08]' : 'bg-[#1b2b1a] text-[#8da689]'
                  }`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm sm:text-base font-bold text-white leading-tight">
                        {tech.title}
                      </h4>
                      {isSelected && (
                        <span className="w-2 h-2 rounded-full bg-[#ffde00]" />
                      )}
                    </div>
                    <p className="text-xs text-[#8da689] mt-0.5">{tech.subtitle}</p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Column: Interactive Detail & Simulated Screen HUD */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Visual Screen Container with In-cab display / Autonomous view */}
            <div className="relative rounded-2xl overflow-hidden border border-[#2b4427] bg-black aspect-[16/10] shadow-inner group">
              <img
                src={activeTech === 'autonomous' ? autoTractorImg : displayImg}
                alt={currentFeature.title}
                className="w-full h-full object-cover brightness-90 contrast-105 transition-all duration-700"
                referrerPolicy="no-referrer"
              />
              
              {/* HUD Telemetry Graphic Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 pointer-events-none" />

              <div className="absolute top-4 left-4 z-10">
                <span className="px-2.5 py-1 rounded-md text-[10px] uppercase font-extrabold tracking-wider bg-black/80 text-[#ffde00] border border-[#ffde00]/40 backdrop-blur-md">
                  {currentFeature.badge}
                </span>
              </div>

              {/* Dynamic Telemetry HUD in Corner */}
              <div className="absolute bottom-4 left-4 right-4 z-10 p-3 rounded-xl bg-black/70 backdrop-blur-md border border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-[#4ade80] animate-ping" />
                  <span className="text-xs font-bold text-white">{currentFeature.title}</span>
                </div>
                <div className="text-xs font-mono text-[#ffde00]">
                  LAT: 41.5868° N | LON: 93.6250° W
                </div>
              </div>
            </div>

            {/* Description & Key Specs */}
            <div className="space-y-4">
              <p className="text-sm sm:text-base text-[#d1e4cf] leading-relaxed">
                {currentFeature.description}
              </p>

              <div className="grid grid-cols-3 gap-3 pt-2">
                {currentFeature.stats.map((stat, i) => (
                  <div key={i} className="p-3 rounded-xl bg-[#121d11] border border-[#20331d] text-center">
                    <div className="text-xs sm:text-sm font-extrabold text-white">{stat.value}</div>
                    <div className="text-[10px] sm:text-[11px] text-[#7f997a] mt-0.5">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
