import React, { useState, useEffect } from 'react';
import { 
  Tractor, 
  Wheat, 
  Trees, 
  Truck, 
  Wrench, 
  LayoutGrid, 
  ArrowRight, 
  Play, 
  Sparkles,
  ChevronRight
} from 'lucide-react';
import heroImage from '../assets/images/hero_tractor_field_1787232401942.jpg';

interface HeroSectionProps {
  onExploreEquipment: () => void;
  onSeeWhatsNew: () => void;
  onPlayVideo: () => void;
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExploreEquipment,
  onSeeWhatsNew,
  onPlayVideo,
  selectedCategory,
  onSelectCategory
}) => {
  const [scrollY, setScrollY] = useState(0);
  const [headlightsLit, setHeadlightsLit] = useState(false);

  useEffect(() => {
    // Parallax scroll listener
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });

    // Staggered load animation: headlights illuminate after 600ms
    const timer = setTimeout(() => {
      setHeadlightsLit(true);
    }, 600);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      clearTimeout(timer);
    };
  }, []);

  const categoryRail = [
    { id: 'tractors', label: 'Tractors', icon: Tractor },
    { id: 'harvesting', label: 'Harvesting', icon: Wheat },
    { id: 'lawn-care', label: 'Lawn Care', icon: Trees },
    { id: 'gator-utility', label: 'Gator™ Utility', icon: Truck },
    { id: 'planting', label: 'Attachments', icon: Wrench },
    { id: 'all', label: 'View All', icon: LayoutGrid }
  ];

  return (
    <section className="relative w-full min-h-[92vh] xl:min-h-screen flex items-center overflow-hidden bg-[#0a0f0a] select-none pt-20 md:pt-0">
      {/* Background Image Container with Parallax & Lighting Effect */}
      <div 
        className="absolute inset-0 z-0 overflow-hidden"
        style={{
          transform: `scale(${1 + Math.min(scrollY * 0.0004, 0.12)}) translateY(${scrollY * 0.15}px)`
        }}
      >
        <img
          src={heroImage}
          alt="John Deere 8RX Flagship Tractor operating in agricultural field at sunset"
          className="w-full h-full object-cover object-[65%_center] md:object-center brightness-[0.88] contrast-[1.08] transition-all duration-1000 ease-out"
          referrerPolicy="no-referrer"
        />

        {/* Ambient Gradient Overlays for Cinematic Atmosphere and Text Legibility */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-transparent pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#090e08] via-transparent to-black/60 pointer-events-none" />
        <div className="absolute inset-0 bg-radial from-transparent via-black/20 to-black/70 pointer-events-none" />

        {/* Illuminated Headlight Glow Simulation */}
        <div 
          className={`absolute top-[40%] right-[32%] md:right-[38%] w-32 h-32 rounded-full bg-[#ffea75]/25 blur-3xl pointer-events-none transition-opacity duration-1000 ${
            headlightsLit ? 'opacity-100' : 'opacity-0'
          }`}
        />
        <div 
          className={`absolute top-[42%] right-[44%] md:right-[48%] w-24 h-24 rounded-full bg-[#ffea75]/20 blur-2xl pointer-events-none transition-opacity duration-1000 ${
            headlightsLit ? 'opacity-100' : 'opacity-0'
          }`}
        />

        {/* Dynamic Subtle Golden Hour Dust Particles */}
        <div className="absolute inset-0 bg-[radial-gradient(#ffde00_1px,transparent_1px)] [background-size:64px_64px] opacity-10 pointer-events-none" />
      </div>

      {/* Main Hero Container */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-stretch md:items-center justify-between min-h-[85vh] py-12 md:py-24">
        
        {/* Left Side Category Rail (Desktop) */}
        <div className="hidden lg:flex flex-col gap-1 py-4 px-2 rounded-2xl bg-black/40 backdrop-blur-xl border border-white/10 shadow-2xl z-20 self-center">
          {categoryRail.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`group relative flex flex-col items-center justify-center w-20 py-3.5 rounded-xl transition-all duration-300 ${
                  isSelected 
                    ? 'bg-[#1b3815] text-[#ffde00] shadow-[0_0_20px_rgba(54,124,43,0.5)] border border-[#ffde00]/40' 
                    : 'text-[#9eb89a] hover:text-white hover:bg-white/10'
                }`}
              >
                {/* Active Indicator Bar */}
                {isSelected && (
                  <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-7 bg-[#ffde00] rounded-r-full shadow-[0_0_8px_#ffde00]" />
                )}
                
                <Icon className={`w-5 h-5 mb-1.5 transition-transform duration-300 ${
                  isSelected ? 'scale-115 text-[#ffde00]' : 'group-hover:scale-110 group-hover:text-white'
                }`} />
                
                <span className="text-[11px] font-semibold tracking-tight text-center leading-tight">
                  {cat.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Center / Left Hero Headline & Content */}
        <div className="max-w-2xl lg:ml-8 xl:ml-12 self-center text-left space-y-6 md:space-y-8 pt-8 md:pt-0">
          
          {/* Subtle Technology Eyebrow */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1b3815]/80 backdrop-blur-md border border-[#ffde00]/30 text-[#ffde00] text-xs font-bold tracking-wide">
            <span className="w-2 h-2 rounded-full bg-[#ffde00] animate-pulse" />
            <span>2027 NEXT-GEN FLEET INTELLIGENCE</span>
          </div>

          {/* Massive Iconic Headline */}
          <div className="space-y-2">
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-[-0.03em] text-white leading-[1.02] uppercase font-sans drop-shadow-[0_4px_24px_rgba(0,0,0,0.8)]">
              NOTHING<br />
              <span className="text-white drop-shadow-[0_0_30px_rgba(255,255,255,0.2)]">RUNS LIKE</span><br />
              <span className="text-[#ffde00] drop-shadow-[0_0_35px_rgba(255,222,0,0.4)]">A DEERE</span>
            </h1>
            <p className="text-lg sm:text-xl md:text-2xl text-[#d7e7d4] font-normal max-w-xl leading-relaxed drop-shadow-md">
              Power, precision, and performance built for the way you work.
            </p>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center gap-4 pt-2">
            {/* Primary Yellow Button */}
            <button
              onClick={onExploreEquipment}
              className="inline-flex items-center justify-center gap-3 px-7 py-4 rounded-full bg-[#ffde00] hover:bg-[#ffe633] text-[#0a1b08] font-extrabold text-base tracking-tight shadow-[0_8px_30px_rgba(255,222,0,0.4)] hover:shadow-[0_12px_40px_rgba(255,222,0,0.6)] hover:scale-[1.03] active:scale-[0.98] transition-all duration-200 group"
            >
              <span>Explore Equipment</span>
              <ArrowRight className="w-5 h-5 text-[#0a1b08] transition-transform duration-200 group-hover:translate-x-1" />
            </button>

            {/* Secondary Glass Outline Button */}
            <button
              onClick={onSeeWhatsNew}
              className="inline-flex items-center justify-center px-7 py-4 rounded-full bg-black/30 hover:bg-white/15 backdrop-blur-md border border-white/30 hover:border-white/60 text-white font-bold text-base tracking-tight shadow-lg hover:scale-[1.02] active:scale-[0.98] transition-all duration-200"
            >
              <span>See What's New</span>
            </button>
          </div>

          {/* Quick Metrics Bar on Mobile / Tablet */}
          <div className="flex items-center gap-6 pt-4 border-t border-white/10 text-xs text-[#9eb89a]">
            <div>
              <span className="font-bold text-white text-sm">410–690 HP</span>
              <span className="block text-[11px]">Flagship Range</span>
            </div>
            <div className="w-px h-6 bg-white/20" />
            <div>
              <span className="font-bold text-[#ffde00] text-sm">0.6 inch</span>
              <span className="block text-[11px]">SF-RTK Accuracy</span>
            </div>
            <div className="w-px h-6 bg-white/20" />
            <div>
              <span className="font-bold text-white text-sm">24/7 Support</span>
              <span className="block text-[11px]">Harvest Guarantee</span>
            </div>
          </div>
        </div>

        {/* Lower Right: Interactive Play Video Control */}
        <div className="mt-8 md:mt-0 self-end z-20">
          <button
            onClick={onPlayVideo}
            className="group flex items-center gap-3.5 p-2 pr-5 rounded-full bg-black/40 hover:bg-black/70 backdrop-blur-xl border border-white/20 hover:border-[#ffde00]/60 shadow-[0_10px_30px_rgba(0,0,0,0.6)] transition-all duration-300 cursor-pointer hover:scale-105"
            aria-label="Play cinematic documentary video"
          >
            {/* Pulsing Play Button */}
            <div className="relative w-12 h-12 rounded-full bg-[#ffde00] text-[#0a1c08] flex items-center justify-center shadow-[0_0_20px_rgba(255,222,0,0.5)] group-hover:bg-white transition-colors">
              <span className="absolute inset-0 rounded-full bg-[#ffde00] animate-ping opacity-30" />
              <Play className="w-5 h-5 fill-[#0a1c08] translate-x-0.5" />
            </div>
            <div className="text-left">
              <span className="block text-sm font-extrabold text-white group-hover:text-[#ffde00] transition-colors">
                Play Video
              </span>
              <span className="block text-[11px] text-[#9eb89a]">
                Cinematic 4K Experience (2:40)
              </span>
            </div>
          </button>
        </div>

      </div>

      {/* Bottom Glow Separation Line */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#367c2b]/60 to-transparent" />
    </section>
  );
};
