import React, { useState } from 'react';
import { X, DollarSign, Calculator, Check, ArrowRight, ShieldCheck, Sparkles, FileCheck2 } from 'lucide-react';
import { EQUIPMENT_DATA } from '../data/equipmentData';

interface FinancialCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPrice?: string;
}

export const FinancialCalculatorModal: React.FC<FinancialCalculatorModalProps> = ({
  isOpen,
  onClose,
  initialPrice
}) => {
  const [selectedModel, setSelectedModel] = useState<string>(EQUIPMENT_DATA[0].id);
  const [price, setPrice] = useState<number>(485000);
  const [downPaymentPercent, setDownPaymentPercent] = useState<number>(20);
  const [termMonths, setTermMonths] = useState<number>(60);
  const [apr, setApr] = useState<number>(3.9);
  const [schedule, setSchedule] = useState<'monthly' | 'annual' | 'semi-annual'>('annual');
  const [isPreApproved, setIsPreApproved] = useState(false);

  if (!isOpen) return null;

  const downPaymentAmount = (price * downPaymentPercent) / 100;
  const loanPrincipal = price - downPaymentAmount;
  const monthlyRate = (apr / 100) / 12;
  const monthlyPayment = (loanPrincipal * (monthlyRate * Math.pow(1 + monthlyRate, termMonths))) / (Math.pow(1 + monthlyRate, termMonths) - 1);
  
  const estimatedPayment = schedule === 'annual' ? monthlyPayment * 12 : schedule === 'semi-annual' ? monthlyPayment * 6 : monthlyPayment;

  const handleSelectModel = (modelId: string) => {
    setSelectedModel(modelId);
    const item = EQUIPMENT_DATA.find(e => e.id === modelId);
    if (item && item.startingPrice) {
      const numeric = parseInt(item.startingPrice.replace(/[^0-9]/g, ''), 10);
      if (numeric) setPrice(numeric);
    }
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-fade-in select-none">
      <div 
        className="w-full max-w-4xl bg-[#0c140b] border border-[#274223] rounded-3xl overflow-hidden shadow-[0_25px_80px_rgba(0,0,0,0.9)] max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:px-8 bg-[#111c10] border-b border-[#21351e] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#367c2b]/30 border border-[#ffde00]/40 flex items-center justify-center text-[#ffde00]">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs uppercase font-extrabold tracking-wider text-[#ffde00]">
                John Deere Financial
              </div>
              <h3 className="text-lg sm:text-xl font-extrabold text-white">
                Equipment Lease & Payment Estimator
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-[#8da689] hover:text-white hover:bg-[#1a2b18] transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Calculator Controls (7 cols) */}
          <div className="lg:col-span-7 space-y-5">
            
            {/* Quick Model Selector */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#c7dfc4] uppercase tracking-wider block">
                Choose Equipment Model
              </label>
              <select
                value={selectedModel}
                onChange={(e) => handleSelectModel(e.target.value)}
                className="w-full p-3 rounded-xl bg-[#142013] border border-[#263e23] text-white text-sm focus:outline-none focus:border-[#ffde00]"
              >
                {EQUIPMENT_DATA.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name} — {item.startingPrice || 'Custom Quote'}
                  </option>
                ))}
              </select>
            </div>

            {/* Price Slider */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-[#8da689]">Equipment Purchase Value</span>
                <span className="font-mono font-bold text-[#ffde00] text-sm">${price.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="20000"
                max="900000"
                step="5000"
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-full accent-[#ffde00] cursor-pointer"
              />
            </div>

            {/* Down Payment Slider */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-[#8da689]">Down Payment / Trade-In ({downPaymentPercent}%)</span>
                <span className="font-mono font-bold text-white text-sm">${downPaymentAmount.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="0"
                max="50"
                step="5"
                value={downPaymentPercent}
                onChange={(e) => setDownPaymentPercent(Number(e.target.value))}
                className="w-full accent-[#ffde00] cursor-pointer"
              />
            </div>

            {/* Term Length & APR */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs text-[#8da689] block">Term Duration</label>
                <select
                  value={termMonths}
                  onChange={(e) => setTermMonths(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl bg-[#142013] border border-[#263e23] text-white text-xs"
                >
                  <option value={36}>36 Months (3 Yrs)</option>
                  <option value={48}>48 Months (4 Yrs)</option>
                  <option value={60}>60 Months (5 Yrs)</option>
                  <option value={72}>72 Months (6 Yrs)</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-[#8da689] block">Payment Schedule</label>
                <select
                  value={schedule}
                  onChange={(e) => setSchedule(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl bg-[#142013] border border-[#263e23] text-white text-xs"
                >
                  <option value="annual">Annual Post-Harvest</option>
                  <option value="semi-annual">Semi-Annual</option>
                  <option value="monthly">Monthly</option>
                </select>
              </div>
            </div>

          </div>

          {/* Right Calculation Breakdown Card (5 cols) */}
          <div className="lg:col-span-5 rounded-2xl bg-[#132212] border border-[#2b4827] p-6 flex flex-col justify-between space-y-6">
            
            <div className="space-y-4">
              <div>
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#ffde00]">
                  ESTIMATED {schedule.toUpperCase()} PAYMENT
                </span>
                <div className="text-3xl sm:text-4xl font-extrabold text-white mt-1">
                  ${Math.round(estimatedPayment).toLocaleString()}
                  <span className="text-xs text-[#8da689] font-normal block mt-0.5">
                    per {schedule === 'annual' ? 'year (Harvest aligned)' : schedule === 'semi-annual' ? '6 months' : 'month'}
                  </span>
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-[#20361f] text-xs">
                <div className="flex justify-between text-[#c4dcc1]">
                  <span>Financed Principal:</span>
                  <span className="font-mono font-bold">${loanPrincipal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-[#c4dcc1]">
                  <span>Promotional APR:</span>
                  <span className="font-mono font-bold text-[#86efac]">{apr}% Fixed</span>
                </div>
                <div className="flex justify-between text-[#c4dcc1]">
                  <span>Total Payments ({termMonths / 12} Yrs):</span>
                  <span className="font-mono font-bold">${Math.round(monthlyPayment * termMonths).toLocaleString()}</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#0e170d] border border-[#1e301c] text-[11px] text-[#8da689]">
                <ShieldCheck className="w-4 h-4 text-[#367c2b] inline mr-1" />
                Payments align directly with seasonal grain sales cycles. Zero prepayment penalties.
              </div>
            </div>

            {/* Pre-Approval CTA */}
            <div>
              {!isPreApproved ? (
                <button
                  onClick={() => setIsPreApproved(true)}
                  className="w-full py-3 px-4 rounded-xl bg-[#ffde00] hover:bg-[#ffe633] text-[#0a1c08] font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg transition-transform hover:scale-[1.02]"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Start Fast Pre-Approval Online</span>
                </button>
              ) : (
                <div className="p-3.5 rounded-xl bg-[#193617] border border-[#367c2b] text-center space-y-1 animate-fade-in text-[#86efac]">
                  <FileCheck2 className="w-6 h-6 text-[#ffde00] mx-auto" />
                  <div className="text-xs font-bold text-white">Pre-Approval Form Initialized</div>
                  <p className="text-[11px] text-[#bed5bd]">Reference #JD-FIN-2026-9884. An underwriter is reviewing your credit packet.</p>
                </div>
              )}
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};
