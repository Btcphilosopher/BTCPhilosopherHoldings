import React, { useState } from 'react';
import { X, User, ShieldCheck, Activity, Wifi, Clock, ChevronRight, CheckCircle2, AlertTriangle, Key } from 'lucide-react';

interface AccountDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AccountDrawer: React.FC<AccountDrawerProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'fleet' | 'support'>('overview');
  const [isLoggedIn, setIsLoggedIn] = useState(true);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex justify-end bg-black/70 backdrop-blur-sm animate-fade-in">
      <div 
        className="w-full max-w-md bg-[#0f160e] border-l border-[#2e472a] h-full flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="p-5 border-b border-[#223820] flex items-center justify-between bg-[#141f13]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#367c2b]/30 border border-[#ffde00]/40 flex items-center justify-center text-[#ffde00]">
              <User className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-white flex items-center gap-2">
                MyJohnDeere™ Portal
                <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#367c2b] text-white font-medium">PRO</span>
              </div>
              <div className="text-xs text-[#8da689]">
                {isLoggedIn ? 'Prairie Ridge Farms LLC' : 'Sign in to access your fleet'}
              </div>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#8da689] hover:text-white hover:bg-[#20331d] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#223820] bg-[#111a10]">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider transition-colors border-b-2 ${
              activeTab === 'overview'
                ? 'border-[#ffde00] text-[#ffde00] bg-[#172416]'
                : 'border-transparent text-[#8da689] hover:text-white'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('fleet')}
            className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider transition-colors border-b-2 ${
              activeTab === 'fleet'
                ? 'border-[#ffde00] text-[#ffde00] bg-[#172416]'
                : 'border-transparent text-[#8da689] hover:text-white'
            }`}
          >
            Active Fleet (4)
          </button>
          <button
            onClick={() => setActiveTab('support')}
            className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider transition-colors border-b-2 ${
              activeTab === 'support'
                ? 'border-[#ffde00] text-[#ffde00] bg-[#172416]'
                : 'border-transparent text-[#8da689] hover:text-white'
            }`}
          >
            Service Desk
          </button>
        </div>

        {/* Drawer Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {activeTab === 'overview' && (
            <>
              {/* Operations Center Status */}
              <div className="p-4 rounded-xl bg-[#152313] border border-[#2d472a] space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-[#ffde00]" />
                    <span className="text-xs uppercase font-bold text-[#e1eee0] tracking-wider">Operations Center Live</span>
                  </div>
                  <span className="inline-flex items-center gap-1 text-[11px] text-[#4ade80] font-semibold">
                    <span className="w-2 h-2 rounded-full bg-[#4ade80] animate-ping" />
                    Connected
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="p-3 bg-[#0d160c] rounded-lg border border-[#1f331b]">
                    <div className="text-[11px] text-[#8ea88a]">Season Field Coverage</div>
                    <div className="text-xl font-extrabold text-white">4,820 <span className="text-xs text-[#ffde00]">Acres</span></div>
                  </div>
                  <div className="p-3 bg-[#0d160c] rounded-lg border border-[#1f331b]">
                    <div className="text-[11px] text-[#8ea88a]">Active JDLink™ Units</div>
                    <div className="text-xl font-extrabold text-white">4 / 4 <span className="text-xs text-[#4ade80]">Online</span></div>
                  </div>
                </div>
              </div>

              {/* StarFire Subscription Status */}
              <div className="p-4 rounded-xl bg-[#141e12] border border-[#263e24] space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#367c2b]" />
                    <span className="text-xs font-bold text-white">SF-RTK Accuracy License</span>
                  </div>
                  <span className="text-xs text-[#38bdf8] font-bold">ACTIVE</span>
                </div>
                <p className="text-xs text-[#8da689]">
                  0.6-inch pass-to-pass repeatability active through Nov 2027 on all StarFire 7500 receivers.
                </p>
              </div>

              {/* Quick Actions */}
              <div className="space-y-2">
                <div className="text-xs uppercase tracking-wider text-[#8da689] font-bold">Quick Launchpad</div>
                <a 
                  href="#precision-tech" 
                  onClick={onClose}
                  className="flex items-center justify-between p-3 rounded-lg bg-[#141f13] hover:bg-[#1b2b1a] border border-[#223820] text-sm text-[#e1eee0] transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Wifi className="w-4 h-4 text-[#ffde00]" />
                    <span>Launch Field Prescription Planner</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#8da689]" />
                </a>
                <a 
                  href="#dealers" 
                  onClick={onClose}
                  className="flex items-center justify-between p-3 rounded-lg bg-[#141f13] hover:bg-[#1b2b1a] border border-[#223820] text-sm text-[#e1eee0] transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Clock className="w-4 h-4 text-[#ffde00]" />
                    <span>Schedule 500-Hour Maintenance</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#8da689]" />
                </a>
              </div>
            </>
          )}

          {activeTab === 'fleet' && (
            <div className="space-y-3">
              {[
                { name: '8R 410 Wheel Tractor (Unit #101)', status: 'In Field — AutoTrac Engaged', speed: '5.8 mph', fuel: '78%', health: 'Optimal' },
                { name: 'X9 1100 Combine (Unit #204)', status: 'Idle in Shop — Field Ready', speed: '0.0 mph', fuel: '92%', health: 'Optimal' },
                { name: 'Gator XUV835M (Unit #003)', status: 'In Transit — North Pasture', speed: '14 mph', fuel: '64%', health: 'Optimal' },
                { name: 'Autonomous 8R Dev (Unit #A9)', status: 'Autonomous Tillage Active', speed: '6.2 mph', fuel: '84%', health: 'Optimal' },
              ].map((machine, i) => (
                <div key={i} className="p-3.5 rounded-xl bg-[#141f13] border border-[#233821] space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">{machine.name}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-[#367c2b]/30 text-[#86efac] font-medium border border-[#367c2b]">
                      {machine.health}
                    </span>
                  </div>
                  <div className="text-xs text-[#a2bba0] flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#ffde00]" />
                    {machine.status}
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-[#7f997a] pt-1 border-t border-[#1c2c1b]">
                    <span>Speed: {machine.speed}</span>
                    <span>Fuel Tank: {machine.fuel}</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'support' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#192b17] border border-[#367c2b]/50">
                <div className="flex items-center gap-2 text-sm font-bold text-[#ffde00] mb-1">
                  <CheckCircle2 className="w-4 h-4" />
                  Expert Connected Support™
                </div>
                <p className="text-xs text-[#d1e4cf] leading-relaxed">
                  Your primary dealer <strong className="text-white">Midwest Ag & Turf Equipment</strong> has Expert Alerts enabled. 
                  Machine telemetry is actively monitored for preventive maintenance.
                </p>
                <div className="mt-3 pt-3 border-t border-[#294524] flex items-center justify-between">
                  <span className="text-xs text-[#a2bba0]">Emergency Hotline:</span>
                  <a href="tel:5155550140" className="text-xs font-bold text-[#ffde00] hover:underline">
                    (515) 555-0140
                  </a>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#141d13] border border-[#223320] text-xs text-[#8da689]">
                <div className="font-bold text-white mb-1 flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-[#ffde00]" />
                  Authorized Operator Keys
                </div>
                2 SmartKey RFID fobs linked with customizable engine torque limits for crew operators.
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#223820] bg-[#0c120c] flex items-center justify-between">
          <button 
            onClick={() => setIsLoggedIn(!isLoggedIn)}
            className="text-xs text-[#8da689] hover:text-[#ffde00] underline"
          >
            {isLoggedIn ? 'Sign Out of Account' : 'Sign in to MyJohnDeere'}
          </button>
          <span className="text-[11px] text-[#556952]">Encrypted TLS 1.3</span>
        </div>
      </div>
    </div>
  );
};
