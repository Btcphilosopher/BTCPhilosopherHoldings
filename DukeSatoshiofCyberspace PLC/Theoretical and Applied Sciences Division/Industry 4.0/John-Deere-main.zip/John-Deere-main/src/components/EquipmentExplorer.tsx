import React, { useState } from 'react';
import { 
  Tractor, 
  Wheat, 
  Trees, 
  Truck, 
  Sprout, 
  Grid, 
  Droplets, 
  HardHat, 
  ArrowRight, 
  Zap, 
  Sparkles,
  SlidersHorizontal
} from 'lucide-react';
import { EQUIPMENT_DATA, EQUIPMENT_CATEGORIES } from '../data/equipmentData';
import { EquipmentItem } from '../types';

interface EquipmentExplorerProps {
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  onInspectEquipment: (id: string) => void;
  onOpenFinancial: () => void;
}

export const EquipmentExplorer: React.FC<EquipmentExplorerProps> = ({
  selectedCategory,
  onSelectCategory,
  onInspectEquipment,
  onOpenFinancial
}) => {
  const [filterHp, setFilterHp] = useState<'all' | 'high' | 'utility'>('all');

  const filteredEquipment = EQUIPMENT_DATA.filter(item => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    if (!matchesCategory) return false;
    if (filterHp === 'high') {
      return item.horsepower.includes('400') || item.horsepower.includes('410') || item.horsepower.includes('690');
    }
    return true;
  });

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Tractor': return Tractor;
      case 'Wheat': return Wheat;
      case 'Trees': return Trees;
      case 'Truck': return Truck;
      case 'Sprout': return Sprout;
      case 'Grid': return Grid;
      case 'Droplets': return Droplets;
      case 'HardHat': return HardHat;
      default: return Tractor;
    }
  };

  return (
    <section id="equipment-explorer" className="w-full bg-[#0a0f09] py-16 sm:py-24 border-t border-[#1a2c17] select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div className="space-y-2 max-w-2xl">
            <div className="text-xs uppercase font-extrabold tracking-wider text-[#ffde00]">
              NEXT-GEN MACHINERY LINEUP
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight leading-none">
              EQUIPMENT DISCOVERY
            </h2>
            <p className="text-sm sm:text-base text-[#bed5bd]">
              Filter by operational category, analyze technical specifications, and inspect high-resolution models.
            </p>
          </div>

          {/* Quick Stats or Actions */}
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenFinancial}
              className="px-4 py-2.5 rounded-xl bg-[#142213] border border-[#2b4428] text-xs font-bold text-[#ffde00] hover:bg-[#1a2d19] transition-colors"
            >
              Lease & Finance Rates
            </button>
          </div>
        </div>

        {/* Category Pill Buttons Horizontal Scroll */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar">
          <button
            onClick={() => onSelectCategory('all')}
            className={`px-4 py-2.5 rounded-full text-xs font-bold whitespace-nowrap transition-all duration-200 ${
              selectedCategory === 'all'
                ? 'bg-[#ffde00] text-[#0d2209] shadow-[0_2px_12px_rgba(255,222,0,0.3)]'
                : 'bg-[#121c11] text-[#9eb89a] hover:text-white hover:bg-[#182617] border border-[#1e301c]'
            }`}
          >
            All Machinery ({EQUIPMENT_DATA.length})
          </button>

          {EQUIPMENT_CATEGORIES.map((cat) => {
            const Icon = getCategoryIcon(cat.icon);
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-full text-xs font-bold whitespace-nowrap transition-all duration-200 ${
                  isSelected
                    ? 'bg-[#ffde00] text-[#0d2209] shadow-[0_2px_12px_rgba(255,222,0,0.3)]'
                    : 'bg-[#121c11] text-[#9eb89a] hover:text-white hover:bg-[#182617] border border-[#1e301c]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Equipment Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEquipment.map((item) => (
            <div
              key={item.id}
              className="group relative rounded-2xl bg-[#10190f] border border-[#21351e] hover:border-[#367c2b] shadow-xl overflow-hidden flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_16px_40px_rgba(0,0,0,0.7)]"
            >
              {/* Top Image Preview */}
              <div className="relative w-full h-56 overflow-hidden bg-black/40">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#10190f] via-transparent to-black/30 pointer-events-none" />

                {/* Badge */}
                {item.badge && (
                  <div className="absolute top-3 left-3">
                    <span className="px-2.5 py-1 rounded-md text-[10px] uppercase font-extrabold tracking-wider bg-black/80 text-[#ffde00] border border-[#ffde00]/40 backdrop-blur-md">
                      {item.badge}
                    </span>
                  </div>
                )}

                {item.hotspots && item.hotspots.length > 0 && (
                  <div className="absolute top-3 right-3">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#367c2b]/90 text-white backdrop-blur-md">
                      <Sparkles className="w-3 h-3 text-[#ffde00]" />
                      360° Hotspots
                    </span>
                  </div>
                )}
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-[#8da689]">
                    {item.series}
                  </div>
                  <h3 className="text-xl font-extrabold text-white tracking-tight mt-1 group-hover:text-[#ffde00] transition-colors">
                    {item.name}
                  </h3>
                  <p className="text-xs text-[#bed5bd] mt-1.5 line-clamp-2">
                    {item.tagline}
                  </p>
                </div>

                {/* Key Technical Metadata Pills */}
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#1c2c1a]">
                  <div className="p-2 rounded-lg bg-[#141f13] border border-[#1f311c]">
                    <div className="text-[10px] uppercase text-[#7f997a] font-semibold">Horsepower</div>
                    <div className="text-xs font-bold text-white truncate">{item.horsepower}</div>
                  </div>
                  <div className="p-2 rounded-lg bg-[#141f13] border border-[#1f311c]">
                    <div className="text-[10px] uppercase text-[#7f997a] font-semibold">Engine Platform</div>
                    <div className="text-xs font-bold text-white truncate">{item.engine.split(' ')[0]} {item.engine.split(' ')[1] || ''}</div>
                  </div>
                </div>

                {/* Card Action Controls */}
                <div className="pt-2 flex items-center gap-3">
                  <button
                    onClick={() => onInspectEquipment(item.id)}
                    className="flex-1 py-2.5 px-4 rounded-xl bg-[#ffde00] hover:bg-[#ffe633] text-[#0d2209] font-extrabold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-[0_2px_10px_rgba(255,222,0,0.25)]"
                  >
                    <span>Inspect Model</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={onOpenFinancial}
                    className="p-2.5 rounded-xl bg-[#141f13] hover:bg-[#1d2d1b] border border-[#263e23] text-xs font-bold text-[#bed5bd] hover:text-white transition-colors"
                    title="Estimate Monthly Payments"
                  >
                    Estimate
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
