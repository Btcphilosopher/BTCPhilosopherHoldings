import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { HeroSection } from './components/HeroSection';
import { FeatureStrip } from './components/FeatureStrip';
import { FeaturedEditorialGrid } from './components/FeaturedEditorialGrid';
import { PrecisionAgSection } from './components/PrecisionAgSection';
import { EquipmentExplorer } from './components/EquipmentExplorer';
import { LatestNewsSection } from './components/LatestNewsSection';
import { DealerLocatorSection } from './components/DealerLocatorSection';
import { Footer } from './components/Footer';
import { SearchModal } from './components/SearchModal';
import { AccountDrawer } from './components/AccountDrawer';
import { VideoModal } from './components/VideoModal';
import { ProductViewerModal } from './components/ProductViewerModal';
import { FinancialCalculatorModal } from './components/FinancialCalculatorModal';

export default function App() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAccountOpen, setIsAccountOpen] = useState(false);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const [isFinancialOpen, setIsFinancialOpen] = useState(false);
  const [selectedEquipmentId, setSelectedEquipmentId] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('tractors');

  const handleExploreEquipment = () => {
    const el = document.getElementById('equipment-explorer');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSeeWhatsNew = () => {
    const el = document.getElementById('latest-news');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectFeatureStrip = (featureKey: string) => {
    if (featureKey === 'precision-tech') {
      const el = document.getElementById('precision-tech');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (featureKey === 'financial') {
      setIsFinancialOpen(true);
    } else if (featureKey === 'support') {
      setIsAccountOpen(true);
    } else if (featureKey === 'parts') {
      const el = document.getElementById('dealers');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0f09] text-[#f4f6f0] flex flex-col font-sans selection:bg-[#ffde00] selection:text-[#0b1c09]">
      {/* Top Compacting Sticky Navigation */}
      <Navigation
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAccount={() => setIsAccountOpen(true)}
        onOpenDealerLocator={() => {
          const el = document.getElementById('dealers');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        onOpenFinancialCalc={() => setIsFinancialOpen(true)}
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          handleExploreEquipment();
        }}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Full-width Cinematic Hero Section */}
        <HeroSection
          onExploreEquipment={handleExploreEquipment}
          onSeeWhatsNew={handleSeeWhatsNew}
          onPlayVideo={() => setIsVideoModalOpen(true)}
          selectedCategory={selectedCategory}
          onSelectCategory={(cat) => {
            setSelectedCategory(cat);
            handleExploreEquipment();
          }}
        />

        {/* Four-Benefit Feature Strip with Dividers */}
        <FeatureStrip onSelectFeature={handleSelectFeatureStrip} />

        {/* Featured Editorial Grid matching reference cards */}
        <FeaturedEditorialGrid
          onSelectEquipment={(id) => setSelectedEquipmentId(id)}
          onExploreAllEquipment={handleExploreEquipment}
          onOpenPrecisionTech={() => {
            const el = document.getElementById('precision-tech');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          onOpenFinancial={() => setIsFinancialOpen(true)}
        />

        {/* Precision Agriculture Showcase with Live Telemetry */}
        <PrecisionAgSection />

        {/* Interactive Equipment Discovery & Models Grid */}
        <EquipmentExplorer
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          onInspectEquipment={(id) => setSelectedEquipmentId(id)}
          onOpenFinancial={() => setIsFinancialOpen(true)}
        />

        {/* Editorial News, Innovation & Customer Stories */}
        <LatestNewsSection />

        {/* Dealer Locator Conversion Section */}
        <DealerLocatorSection />
      </main>

      {/* Comprehensive Premium Footer */}
      <Footer
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenDealerLocator={() => {
          const el = document.getElementById('dealers');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        onOpenFinancialCalc={() => setIsFinancialOpen(true)}
      />

      {/* Global Modals & Drawers */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectEquipment={(id) => setSelectedEquipmentId(id)}
      />

      <AccountDrawer
        isOpen={isAccountOpen}
        onClose={() => setIsAccountOpen(false)}
      />

      <VideoModal
        isOpen={isVideoModalOpen}
        onClose={() => setIsVideoModalOpen(false)}
      />

      <ProductViewerModal
        equipmentId={selectedEquipmentId}
        onClose={() => setSelectedEquipmentId(null)}
        onOpenDealerLocator={() => {
          setSelectedEquipmentId(null);
          const el = document.getElementById('dealers');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        onOpenFinancialCalc={() => {
          setSelectedEquipmentId(null);
          setIsFinancialOpen(true);
        }}
      />

      <FinancialCalculatorModal
        isOpen={isFinancialOpen}
        onClose={() => setIsFinancialOpen(false)}
      />
    </div>
  );
}
