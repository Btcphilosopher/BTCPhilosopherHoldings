import { EquipmentItem } from '../types';
import heroTractor from '../assets/images/hero_tractor_field_1787232401942.jpg';
import tractor8r from '../assets/images/tractor_8r_action_1787232411694.jpg';
import precisionAg from '../assets/images/precision_ag_display_1787232423130.jpg';
import combineX9 from '../assets/images/combine_x9_harvest_1787232459081.jpg';
import gatorXuv from '../assets/images/gator_xuv_action_1787232470875.jpg';
import autonomousTractor from '../assets/images/autonomous_tractor_1787232481586.jpg';
import fieldWide from '../assets/images/equipment_field_wide_1787232447575.jpg';

export const EQUIPMENT_DATA: EquipmentItem[] = [
  {
    id: '8r-410',
    name: '8R 410 Wheel & Track Tractor',
    series: '8R Series',
    tagline: 'More power. More comfort. More control.',
    category: 'tractors',
    horsepower: '410 HP (Max 443 HP)',
    engine: 'John Deere PowerTech™ 9.0L PSS 6-Cylinder',
    transmission: 'AutoPowr™ / IVT™ Infinite Variable Transmission',
    hydraulicFlow: '85 gpm (321 L/min) Dual Pump',
    fuelCapacity: '177 Gallons (670 L)',
    startingPrice: '$485,000',
    leaseFrom: '$3,890 / mo',
    image: tractor8r,
    actionImage: heroTractor,
    description: 'Engineered for relentless row-crop performance and high-draft loads. The 8R Series blends brutal mechanical stamina with advanced automation, CommandView™ 4 luxury cab isolation, and precision guidance.',
    badge: 'FLAGSHIP ROW CROP',
    isFlagship: true,
    keyFeatures: [
      'CommandView™ 4 Cab with ActiveSeat™ II pneumatic massage & heating',
      'Integrated StarFire™ 7500 receiver with 0.6-inch SF-RTK repeatability',
      'Gen 5 CommandCenter™ 12.8-inch high-resolution touchscreen',
      'ExactRate™ fertilizer injection and AutoTrac™ Turn Automation',
      'eAutoPowr™ Electric Variable Transmission with dual brushless motors'
    ],
    hotspots: [
      {
        id: 'engine-1',
        title: 'PowerTech™ 9.0L PSS Engine',
        category: 'ENGINE',
        x: 48,
        y: 44,
        description: 'Twin sequential turbochargers deliver immediate low-end torque rise with peak fuel efficiency and Stage V clean emissions.',
        specHighlight: '410 HP | 1,825 Nm Peak Torque'
      },
      {
        id: 'cab-1',
        title: 'CommandView™ 4 Luxury Cab',
        category: 'CAB',
        x: 62,
        y: 28,
        description: 'Laminated acoustic safety glass with 40-degree swivel ActiveSeat II, active climate zones, and touchscreen Generation 5 command console.',
        specHighlight: '64 dB(A) Acoustic Rating'
      },
      {
        id: 'precision-1',
        title: 'Integrated StarFire™ 7500',
        category: 'PRECISION',
        x: 61,
        y: 12,
        description: 'Multi-constellation GNSS receiver with satellite-delivered SF-RTK accuracy with 75% faster pull-in time.',
        specHighlight: '< 0.6 inch (<1.5 cm) Repeatability'
      },
      {
        id: 'drivetrain-1',
        title: 'Heavy-Duty 4-Track System',
        category: 'DRIVETRAIN',
        x: 68,
        y: 68,
        description: 'Four dedicated track assemblies float over damp soils, reducing compaction to 0.4 bar while delivering 100% mechanical tractive force.',
        specHighlight: '30-inch Camso Belts | 0.4 bar ground psi'
      },
      {
        id: 'hydraulics-1',
        title: 'High-Flow Electro-Hydraulic Stack',
        category: 'HYDRAULICS',
        x: 82,
        y: 58,
        description: 'Dual variable-displacement pumps power high-capacity air seeders and large folding implements without pressure drop.',
        specHighlight: '85 gpm (321 L/min) @ 2,900 PSI'
      }
    ]
  },
  {
    id: 'x9-1100',
    name: 'X9 1100 Combine Harvester',
    series: 'X Series Harvesters',
    tagline: 'Harvest more than 100 metric tons of wheat per hour.',
    category: 'harvesting',
    horsepower: '690 HP (Max 700 HP)',
    engine: 'John Deere PowerTech™ 13.6L Twin Turbo',
    transmission: 'ProDrive™ XL 2-Speed Transmission',
    hydraulicFlow: '60 gpm (227 L/min)',
    fuelCapacity: '330 Gallons (1,250 L)',
    startingPrice: '$860,000',
    leaseFrom: '$6,450 / mo',
    image: combineX9,
    actionImage: combineX9,
    description: 'Designed for large-acre grain producers who need maximum harvesting capacity without compromising grain quality or fuel efficiency in tough, green-stem conditions.',
    badge: 'HIGH CAPACITY',
    keyFeatures: [
      'Dual-Rotor X-Series separator with 23% wider active threshing area',
      'Dyna-Flo™ Plus Cleaning Shoe with 4-way slope leveling system',
      'Combine Advisor™ with ActiveVision™ AI cameras for real-time loss correction',
      'Fast-folding 460-bushel grain tank with 4.5 bu/sec high-speed unload rate'
    ],
    hotspots: [
      {
        id: 'harvest-engine',
        title: 'PowerTech 13.6L Engine',
        category: 'ENGINE',
        x: 52,
        y: 35,
        description: 'Optimized fuel mapping with low RPM cruising and massive reserve torque during high-volume unloading.',
        specHighlight: '690 HP @ 1,900 RPM'
      },
      {
        id: 'active-vision',
        title: 'ActiveVision™ Loss AI Cameras',
        category: 'PRECISION',
        x: 65,
        y: 48,
        description: 'Continuous multispectral analysis of clean grain and tailings monitors broken kernels and automatically adjusts concave clearance.',
        specHighlight: '99.8% Grain Cleanliness Rating'
      }
    ]
  },
  {
    id: 'gator-xuv835m',
    name: 'Gator™ XUV835M Crossover Utility',
    series: 'Gator™ Crossover',
    tagline: 'Rugged terrain dominance with all-season climate comfort.',
    category: 'gator-utility',
    horsepower: '54 HP 812cc EFI Engine',
    engine: '3-Cylinder 4-Cycle Gasoline EFI',
    transmission: 'CVT with On-Demand True 4WD',
    hydraulicFlow: 'Optional Power Lift',
    fuelCapacity: '11.2 Gallons (42.4 L)',
    startingPrice: '$23,499',
    leaseFrom: '$289 / mo',
    image: gatorXuv,
    actionImage: gatorXuv,
    description: 'Three-passenger quiet cab with automotive heating, air conditioning, 1,000 lb cargo box capacity, and heavy-duty 4-wheel independent suspension.',
    badge: 'VERSATILITY',
    keyFeatures: [
      'Factory-installed quiet cab with automotive grade HVAC',
      '1,000 lb (454 kg) cargo box capacity with hydraulic power lift',
      'True 4WD with selectable rear differential lock and downhill engine braking',
      'Max speed up to 45 mph (72 km/h) with smooth dual A-arm suspension'
    ]
  },
  {
    id: 'autonomous-8r',
    name: 'Autonomous 8R System',
    series: 'Precision Robotics',
    tagline: 'Unattended 24/7 tillage and autonomous field operations.',
    category: 'tractors',
    horsepower: '410 HP Electric-Assisted',
    engine: 'PowerTech™ 9.0L Hybrid + Perception AI',
    transmission: 'eAutoPowr™ Smart Drive',
    startingPrice: 'Contact Dealer for Fleet Allocation',
    image: autonomousTractor,
    actionImage: autonomousTractor,
    description: 'Six pairs of stereo cameras and deep learning obstacle detection enable the machine to navigate geofenced fields 24 hours a day with zero human presence in the cab.',
    badge: 'AUTONOMOUS AI',
    keyFeatures: [
      '360-degree stereo perception system detecting obstacles down to centimeters',
      'John Deere Operations Center mobile dispatch and live video telemetry feed',
      'Geofence auto-boundary safety perimeter with millisecond fail-safe braking',
      'Cloud job automation: automated depth management, turn logic, and anomaly alerts'
    ]
  },
  {
    id: 'z994r-diesel',
    name: 'Z994R Diesel ZTrak™ Mower',
    series: 'Commercial Lawn Care',
    tagline: 'Maximum productivity for commercial turf management.',
    category: 'lawn-care',
    horsepower: '24.7 HP Final Tier 4 Diesel',
    engine: '3-Cylinder Liquid-Cooled Diesel',
    transmission: 'Dual Hydrostatic Drive 13.5 mph',
    fuelCapacity: '11.5 Gallons',
    startingPrice: '$18,950',
    image: fieldWide,
    description: 'Built for high-hour commercial mowing with 7-Iron™ PRO deep-deck stamping, Michelin® X® Tweel® airless radial tires, and ComfortGlide™ suspension.',
    badge: 'COMMERCIAL TURF',
    keyFeatures: [
      '7-Iron™ PRO 60-inch or 72-inch 7-gauge stamped steel mower deck',
      'Michelin® X® Tweel® Turf airless radial tires prevent flats and downtime',
      'ComfortGlide™ fore/aft seat suspension absorbs harsh bump impacts',
      'Brake-N-Go foot starting system for fast operational convenience'
    ]
  },
  {
    id: 'exactemerge-planter',
    name: 'ExactEmerge™ High-Speed Planter',
    series: 'Planting & Seeding',
    tagline: 'Flawless seed placement at speeds up to 10 mph.',
    category: 'planting',
    horsepower: 'Requires 250+ HP Tractor',
    engine: 'BrushBelt™ Electric Direct Delivery',
    transmission: 'Electric Drive Row Units',
    startingPrice: '$210,000',
    image: precisionAg,
    description: 'Eliminates seed roll and bounce through patented BrushBelt delivery, ensuring uniform emergence and maximizing yield across every acre.',
    badge: 'HIGH-SPEED PLANTING',
    keyFeatures: [
      'BrushBelt™ technology delivers seed to bottom of trench at matching ground speed',
      'Individual electric brushless drive motors on every single row unit',
      'Curve compensation maintains uniform spacing around curves and contours',
      'Hydraulic downforce sensor adjusts in milliseconds per row'
    ]
  }
];

export const EQUIPMENT_CATEGORIES = [
  { id: 'tractors', label: 'Tractors', icon: 'Tractor', count: 48 },
  { id: 'harvesting', label: 'Harvesting', icon: 'Wheat', count: 18 },
  { id: 'lawn-care', label: 'Lawn Care', icon: 'Trees', count: 32 },
  { id: 'gator-utility', label: 'Gator™ Utility', icon: 'Truck', count: 14 },
  { id: 'planting', label: 'Planting & Seeding', icon: 'Sprout', count: 22 },
  { id: 'tillage', label: 'Tillage', icon: 'Grid', count: 16 },
  { id: 'sprayers', label: 'Sprayers & Application', icon: 'Droplets', count: 12 },
  { id: 'construction', label: 'Compact Construction', icon: 'HardHat', count: 26 }
];
