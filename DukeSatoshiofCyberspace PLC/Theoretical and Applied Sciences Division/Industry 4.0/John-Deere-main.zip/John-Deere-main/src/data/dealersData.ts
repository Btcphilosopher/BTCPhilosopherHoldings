import { Dealer } from '../types';

export const DEALERS_DATA: Dealer[] = [
  {
    id: 'd-1',
    name: 'Midwest Ag & Turf Equipment — Central Hub',
    city: 'Des Moines',
    state: 'IA',
    zip: '50309',
    phone: '(515) 555-0140',
    distance: '4.2 miles',
    address: '4820 Precision Parkway, Des Moines, IA 50309',
    hours: 'Mon - Fri: 7:00 AM - 6:00 PM | Sat: 8:00 AM - 2:00 PM',
    services: [
      '24/7 Harvest Mobile Service',
      'Certified Precision Ag & RTK Support',
      'Comprehensive Parts Depot',
      'Equipment Demonstrations'
    ],
    certifiedPrecisionTech: true,
    inStockCount: 42
  },
  {
    id: 'd-2',
    name: 'Prairie State Tractor & Fleet Solutions',
    city: 'Ames',
    state: 'IA',
    zip: '50010',
    phone: '(515) 555-0188',
    distance: '18.6 miles',
    address: '1100 Agronomy Drive, Ames, IA 50010',
    hours: 'Mon - Fri: 7:30 AM - 5:30 PM | Sat: 8:00 AM - 12:00 PM',
    services: [
      'Dyno Testing & Engine Rebuilds',
      'StarFire™ Calibration Lab',
      'Used Equipment Inspections',
      'Finance & Leasing Desk'
    ],
    certifiedPrecisionTech: true,
    inStockCount: 29
  },
  {
    id: 'd-3',
    name: 'Cedar Valley Machinery & Implement',
    city: 'Cedar Rapids',
    state: 'IA',
    zip: '52404',
    phone: '(319) 555-0122',
    distance: '34.1 miles',
    address: '890 Harvest Way, Cedar Rapids, IA 52404',
    hours: 'Mon - Fri: 7:00 AM - 5:00 PM | Sat: 7:30 AM - 1:00 PM',
    services: [
      'Hydraulic Hose Fabrication',
      'Combine Optimization Clinic',
      'Express Parts Pickup Lockers'
    ],
    certifiedPrecisionTech: false,
    inStockCount: 19
  },
  {
    id: 'd-4',
    name: 'Heartland Precision Equipment Co.',
    city: 'Fort Dodge',
    state: 'IA',
    zip: '50501',
    phone: '(515) 555-0199',
    distance: '48.5 miles',
    address: '2240 Frontier Road, Fort Dodge, IA 50501',
    hours: 'Mon - Fri: 7:00 AM - 6:00 PM | Sat: 8:00 AM - 2:00 PM',
    services: [
      'Autonomous Systems Integration',
      'See & Spray™ Upgrades',
      'Seasonal In-Field Technicians'
    ],
    certifiedPrecisionTech: true,
    inStockCount: 35
  }
];
