import { NewsArticle } from '../types';
import autonomousImg from '../assets/images/autonomous_tractor_1787232481586.jpg';
import displayImg from '../assets/images/precision_ag_display_1787232423130.jpg';
import combineImg from '../assets/images/combine_x9_harvest_1787232459081.jpg';
import tractorImg from '../assets/images/tractor_8r_action_1787232411694.jpg';
import financialImg from '../assets/images/john_deere_financial_1787232435958.jpg';

export const NEWS_ARTICLES: NewsArticle[] = [
  {
    id: 'news-1',
    title: 'Autonomous Field Operations: How 24/7 Unattended Tillage Is Transforming Large-Acre Yields',
    category: 'Technology',
    readTime: '4 min read',
    date: 'August 18, 2026',
    author: 'Precision Agriculture R&D',
    summary: 'With advanced multi-stereo perception, AI boundary detection, and live Operations Center telemetry, farmers are running continuous overnight operations while optimizing fuel economy by 16%.',
    image: autonomousImg,
    featured: true
  },
  {
    id: 'news-2',
    title: 'Gen 5 CommandCenter™ Software Update Brings Millisecond Machine-to-Cloud Sync',
    category: 'Innovation',
    readTime: '3 min read',
    date: 'August 12, 2026',
    author: 'Connected Fleet Systems',
    summary: 'Direct satellite-linked wireless data transfer now streams yield maps, fuel utilization, and prescription plans in sub-second latency across mixed fleets.',
    image: displayImg
  },
  {
    id: 'news-3',
    title: 'High-Moisture Grain Handling: Setting New Harvesting Benchmarks with the X9 1100',
    category: 'Equipment',
    readTime: '5 min read',
    date: 'August 04, 2026',
    author: 'Harvesting Solutions',
    summary: 'Examining test data from over 50,000 acres in the Midwest: how dual-rotor separation delivered sub-0.5% grain damage in challenging wet-stem conditions.',
    image: combineImg
  },
  {
    id: 'news-4',
    title: '2026 Fall Pre-Season Financing Programs Announced with Low APR and Flexible Terms',
    category: 'Sustainability',
    readTime: '2 min read',
    date: 'July 29, 2026',
    author: 'John Deere Financial',
    summary: 'Tailored payment structures designed around crop harvest cash cycles allow operations to lock in cutting-edge 8R and 9R machinery before the next season.',
    image: financialImg
  }
];
