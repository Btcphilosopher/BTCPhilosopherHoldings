"""Routing policies: static never reacts, adaptive fails over, hysteresis limits oscillation."""

from vhfnet.simulation.engine import Simulation
from vhfnet.simulation.topology import Graph


def test_candidate_paths_sorted(demo_cfg):
    g = Graph(demo_cfg.topology)
    paths = g.candidate_paths("ue-1", "cloud-1", 4)
    assert paths[0] == ("ue-1", "ran-a", "edge-1", "core-1", "cloud-1")
    assert all(p[0] == "ue-1" and p[-1] == "cloud-1" and len(set(p)) == len(p) for p in paths)
    delays = [g.path_prop_s(p) + g.path_proc_s(p) for p in paths]
    assert delays == sorted(delays)


def test_static_never_switches_and_adaptive_fails_over(demo_cfg):
    cfg = demo_cfg.model_copy(update={"duration_s": 7.0})  # outage starts at t=4 s
    static = Simulation(cfg, "path_outage", "baseline", 1).run()
    adaptive = Simulation(cfg, "path_outage", "adaptive", 1).run()
    assert static["totals"]["route_changes"] == 0
    reasons = {c["reason"] for c in adaptive["routes"]["changes"]}
    assert any(r.startswith("failover") for r in reasons)
    assert adaptive["totals"]["deadline_miss_ratio"] < static["totals"]["deadline_miss_ratio"]


def test_hysteresis_reduces_route_changes(demo_cfg):
    cfg = demo_cfg.model_copy(update={"duration_s": 7.0})  # capacity drop starts at t=4 s
    ld = Simulation(cfg, "capacity_drop", "least_delay", 2).run()
    ad = Simulation(cfg, "capacity_drop", "adaptive", 2).run()
    assert ld["totals"]["route_changes"] > ad["totals"]["route_changes"]
    for c in ad["routes"]["changes"]:
        assert c["reason"].startswith(("failover", "lower-cost-beyond-hysteresis"))
