"""Control API (FastAPI) incl. bounded simulation runs and the static report."""

import json

import pytest
from fastapi.testclient import TestClient

from vhfnet.api.app import create_app
from vhfnet.experiments.runner import run_experiment

from .conftest import DEMO


@pytest.fixture(scope="module")
def client(tmp_path_factory, demo_cfg):
    root = tmp_path_factory.mktemp("results")
    cfg = demo_cfg.model_copy(update={"duration_s": 2.0})
    run_experiment(cfg, root / "demo", scenarios=["baseline", "path_outage"], policies=["baseline", "adaptive"],
                   seeds=[1, 2], workers=2, progress=None)
    return TestClient(create_app(root, DEMO, enable_live=False)), root


def test_meta_topology_experiments(client):
    c, _ = client
    assert c.get("/api/meta").json()["modes"] == ["SIMULATION", "LIVE TEST"]
    topo = c.get("/api/topology").json()
    assert {n["id"] for n in topo["nodes"]} >= {"ue-1", "edge-1", "edge-2", "cloud-1"}
    exps = c.get("/api/experiments").json()
    assert exps[0]["name"] == "demo" and exps[0]["mode"] == "SIMULATION"
    cmp = c.get("/api/experiments/demo/comparison").json()
    assert cmp["reference"] == "baseline" and "adaptive" in cmp["scoreboard"]
    run = c.get("/api/experiments/demo/run/path_outage/adaptive/1").json()
    assert run["meta"]["mode"] == "SIMULATION" and len(run["timeseries"]["t"]) <= 200
    assert c.get("/api/experiments/../etc/manifest").status_code == 404


def test_simulate_is_bounded(client):
    c, root = client
    r = c.post("/api/simulate", json={"scenario": "baseline", "policy": "adaptive", "seed": 3, "duration_s": 2})
    assert r.status_code == 200 and r.json()["meta"]["mode"] == "SIMULATION"
    assert c.post("/api/simulate", json={"duration_s": 3600}).status_code == 422
    assert c.post("/api/simulate", json={"scenario": "nope"}).status_code == 400


def test_analytic_endpoints(client):
    c, _ = client
    mc = c.post("/api/montecarlo", json={"draws": 5000, "seed": 1}).json()
    assert mc["draws"] == 5000 and mc["seed"] == 1 and mc["mcse_mean"] > 0 and mc["sensitivity"]
    bz = c.post("/api/bayes", json={"events_a": 2, "trials_a": 500, "events_b": 9, "trials_b": 500}).json()
    assert bz["comparison"]["prob_a_lower"] > 0.9
    pl = c.post("/api/placement", json={"input_bytes": 5_000_000}).json()
    assert pl["rows"][0]["node"].startswith("ue-1")


def test_live_disabled_flag(client):
    c, _ = client
    assert c.post("/api/live", json={"preset": "loopback_udp"}).status_code == 403


def test_static_report(client, tmp_path):
    from vhfnet.dashboard.report import build_report

    _, root = client
    p = build_report(root, tmp_path / "report", DEMO)
    html = p.read_text()
    assert "window.VHF_STATIC=" in html and "SIMULATION" in html
    assert (tmp_path / "report" / "plotly.min.js").exists()
