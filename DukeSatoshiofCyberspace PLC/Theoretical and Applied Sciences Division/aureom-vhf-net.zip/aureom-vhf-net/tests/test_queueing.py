"""Queueing behaviour: bounded buffers, tail drop, M/D/1 sanity check, outage vs interruption."""

import math

import pytest

from vhfnet.scheduling import FIFOQueue
from vhfnet.simulation.engine import Simulation
from vhfnet.traffic.packet import Packet


def pkt(seq, size=1000, flow=0, deadline=math.inf, weight=1.0):
    return Packet(flow, seq, seq, 0, 1, size, 0, 0.0, deadline, 0, weight, ("A", "B"))


def test_fifo_bounded_tail_drop():
    q = FIFOQueue(3500)
    dropped = [q.enqueue(pkt(i), 0.0) for i in range(5)]
    assert [len(d) for d in dropped] == [0, 0, 0, 1, 1]
    assert q.bytes == 3000 and len(q) == 3
    assert [q.dequeue(0).seq for _ in range(3)] == [0, 1, 2]
    assert q.dequeue(0) is None and q.bytes == 0


def test_md1_mean_waiting_time(mini):
    """Poisson arrivals, fixed 1000 B packets at 8 Mb/s (service 1 ms), rho = 0.7.
    Pollaczek-Khinchine for M/D/1: W = rho / (2 mu (1 - rho))."""
    rho, mu = 0.7, 1000.0
    flows = [{"id": "f", "kind": "constant_rate", "src": "A", "dst": "B", "size": {"bytes": 1000},
              "arrival": {"model": "poisson", "rate_mps": rho * mu}, "max_rate_mbps": 1000}]
    cfg = mini(cap_mbps=8, flows=flows, duration_s=60, buffer_bytes=10_000_000)
    sim = Simulation(cfg, "s", "static", 11)
    sim.run()
    arr = sim.log.arrays()
    w = arr["t_queue"].mean()
    expected = rho / (2 * mu * (1 - rho))
    assert w == pytest.approx(expected, rel=0.12)
    assert arr["t_tx"].mean() == pytest.approx(1e-3, rel=1e-9)


def _cbr(mini, events):
    flows = [{"id": "f", "kind": "constant_rate", "src": "A", "dst": "B", "size": {"bytes": 1000},
              "arrival": {"model": "constant", "rate_mps": 500}, "max_rate_mbps": 100}]
    return mini(cap_mbps=10, flows=flows, events=events, duration_s=4)


def test_handover_interruption_buffers_without_loss(mini):
    res = Simulation(_cbr(mini, [{"at_s": 1.0, "kind": "handover", "target": "ab", "interruption_ms": 100}]),
                     "s", "static", 1).run()
    f = res["flows"][0]
    ab = next(l for l in res["links"] if l["link"] == "ab:A>B")
    assert sum(ab["drops"].values()) == 0
    assert f["packet_loss_ratio"] == 0
    assert f["messages"]["latency_ms"]["max"] >= 99.0  # packets waited out the interruption


def test_outage_drops_and_counts(mini):
    res = Simulation(_cbr(mini, [{"at_s": 1.0, "kind": "outage", "target": "ab", "duration_s": 0.5}]),
                     "s", "static", 1).run()
    f = res["flows"][0]
    ab = next(l for l in res["links"] if l["link"] == "ab:A>B")
    assert ab["drops"]["outage"] == pytest.approx(250, abs=2)
    assert f["messages"]["incomplete"] == ab["drops"]["outage"]
    assert f["deadline_miss_ratio"] is None  # no deadline configured
