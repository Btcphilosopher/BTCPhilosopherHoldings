from __future__ import annotations

from pathlib import Path

import pytest

from vhfnet.config import ExperimentConfig, load_experiment

ROOT = Path(__file__).resolve().parents[1]
DEMO = ROOT / "configs" / "experiments" / "demo.yaml"


@pytest.fixture(scope="session")
def demo_cfg() -> ExperimentConfig:
    cfg = load_experiment(DEMO)
    return cfg.model_copy(update={"duration_s": 4.0, "drain_s": 1.0})


def mini_config(cap_mbps: float = 10.0, prop_ms: float = 1.0, buffer_bytes: int = 200_000, discipline: str = "fifo",
                flows: list[dict] | None = None, events: list[dict] | None = None, duration_s: float = 5.0,
                loss: dict | None = None, policies: list[dict] | None = None, header_bytes: int = 0,
                mtu: int = 1000) -> ExperimentConfig:
    """Two hosts joined by one bottleneck link (A -> B), plus a fast alternative path via R."""
    return ExperimentConfig.model_validate({
        "name": "mini", "duration_s": duration_s, "drain_s": 2.0, "sample_interval_ms": 50, "seeds": [1],
        "mtu_payload_bytes": mtu, "header_bytes": header_bytes,
        "topology": {"name": "mini", "nodes": [
            {"id": "A", "kind": "client", "processing_delay_us": 0},
            {"id": "B", "kind": "cloud", "processing_delay_us": 0},
            {"id": "R", "kind": "core", "processing_delay_us": 0}],
            "links": [
                {"id": "ab", "a": "A", "b": "B", "capacity_mbps": cap_mbps, "propagation_delay_ms": prop_ms,
                 "queue": {"discipline": discipline, "buffer_bytes": buffer_bytes}, "loss": loss or {"model": "none"}},
                {"id": "ar", "a": "A", "b": "R", "capacity_mbps": cap_mbps, "propagation_delay_ms": prop_ms * 3,
                 "queue": {"discipline": discipline, "buffer_bytes": buffer_bytes}},
                {"id": "rb", "a": "R", "b": "B", "capacity_mbps": cap_mbps, "propagation_delay_ms": prop_ms * 3,
                 "queue": {"discipline": discipline, "buffer_bytes": buffer_bytes}}]},
        "flows": flows or [],
        "scenarios": [{"id": "s", "name": "s", "events": events or []}],
        "policies": policies or [{"id": "static", "label": "static", "routing": "static", "placement": "cloud"}],
    })


@pytest.fixture
def mini():
    return mini_config
