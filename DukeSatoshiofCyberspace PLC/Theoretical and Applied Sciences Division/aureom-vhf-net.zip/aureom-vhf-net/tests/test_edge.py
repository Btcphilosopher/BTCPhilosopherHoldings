"""Edge compute: explicit queueing; completion = input + wait + processing + output; edge not always best."""

import pytest
import simpy

from vhfnet.config import ComputeConfig
from vhfnet.edge import ComputeServer, Job, analytic_placement, erlang_c_wait_s, queue_wait_estimate_s
from vhfnet.simulation.engine import Simulation


def test_compute_server_queue_and_rejection():
    env = simpy.Environment()
    srv = ComputeServer(env, "e", ComputeConfig(cores=1, gops_per_core=10, queue_limit=2))
    jobs = [Job(i, "e", 1.0, 0.0) for i in range(4)]
    accepted = [srv.submit(j) for j in jobs]
    assert accepted == [True, True, True, False]
    env.run()
    assert [j.end_t for j in jobs[:3]] == pytest.approx([0.1, 0.2, 0.3])
    assert jobs[2].wait_s == pytest.approx(0.2)
    assert srv.finish(0.3)["jobs_rejected"] == 1


def test_erlang_c_reduces_to_mm1():
    lam, svc = 8.0, 0.1  # rho = 0.8
    assert erlang_c_wait_s(lam, svc, 1) == pytest.approx(0.8 / (10 - 8))
    assert erlang_c_wait_s(12.0, svc, 1) == float("inf")
    assert queue_wait_estimate_s(0, 0, 4, 0.1) == 0.0
    assert queue_wait_estimate_s(3, 4, 4, 0.1) > 0


def _cands(edge_bg=0.0):
    local = {"cores": 2, "gops_per_core": 15}
    edge = {"cores": 4, "gops_per_core": 80, "service_overhead_ms": 2}
    cloud = {"cores": 32, "gops_per_core": 150, "service_overhead_ms": 5}
    return [{"node": "local", "compute": local, "local": True, "path_delay_s": 0, "bottleneck_bps": 1e12},
            {"node": "edge", "compute": edge, "path_delay_s": 0.0005, "bottleneck_bps": 20e6,
             "background_rate_jobs_per_s": edge_bg},
            {"node": "cloud", "compute": cloud, "path_delay_s": 0.015, "bottleneck_bps": 20e6}]


def test_edge_wins_small_jobs_but_not_large_uploads_or_overload():
    assert analytic_placement(20_000, 2000, 3.0, _cands())[0]["node"] == "edge"
    # a 5 MB upload over a 20 Mb/s access link dominates: local execution wins
    assert analytic_placement(5_000_000, 2000, 3.0, _cands())[0]["node"] == "local"
    # an overloaded edge (rho ~ 0.99) makes the cloud faster despite the longer path
    best = analytic_placement(20_000, 2000, 3.0, _cands(edge_bg=104))[0]
    assert best["node"] == "cloud"


def test_simulated_completion_decomposition(demo_cfg):
    res = Simulation(demo_cfg, "edge_overload", "baseline", 1).run()
    inf = res["requests"]["inference"]
    b = inf["breakdown_mean_ms"]
    assert all(v is not None and v >= 0 for v in b.values())
    assert sum(inf["status"].values()) == inf["total"]
    edge1 = next(c for c in res["compute"] if c["node"] == "edge-1")
    assert edge1["background_completed"] > 0
    busy = res["timeseries"]["compute"]["edge-1"]["busy_cores"]
    assert max(busy) == edge1["cores"] and edge1["queue_max_jobs"] > 0  # overload saturates the worker
