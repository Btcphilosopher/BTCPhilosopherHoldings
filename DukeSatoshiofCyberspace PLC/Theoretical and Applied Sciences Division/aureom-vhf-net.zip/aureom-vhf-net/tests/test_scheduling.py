"""Scheduling disciplines and their fairness / starvation behaviour."""

import math

import pytest

from vhfnet.scheduling import EDFQueue, FIFOQueue, WFQQueue
from vhfnet.simulation.engine import Simulation
from vhfnet.traffic.packet import Packet


def pkt(seq, flow=0, size=1000, deadline=math.inf, weight=1.0):
    return Packet(flow, seq, seq, 0, 1, size, 0, 0.0, deadline, 0, weight, ("A", "B"))


def test_wfq_weighted_share_when_backlogged():
    q = WFQQueue(10**9)
    for i in range(300):
        q.enqueue(pkt(i, flow=0, weight=3.0), 0)
        q.enqueue(pkt(1000 + i, flow=1, weight=1.0), 0)
    served = [q.dequeue(0).flow_idx for _ in range(200)]
    share = served.count(0) / len(served)
    assert share == pytest.approx(0.75, abs=0.02)


def test_wfq_longest_queue_drop_protects_light_flow():
    q = WFQQueue(10_000)
    for i in range(10):
        q.enqueue(pkt(i, flow=0), 0)  # heavy flow fills the buffer
    dropped = q.enqueue(pkt(100, flow=1), 0)
    assert len(dropped) == 1 and dropped[0].flow_idx == 0
    assert q.bytes <= 10_000


def test_edf_order_and_ties():
    q = EDFQueue(10**6)
    for seq, dl in [(0, 5.0), (1, 1.0), (2, math.inf), (3, 1.0)]:
        q.enqueue(pkt(seq, deadline=dl), 0)
    assert [q.dequeue(0).seq for _ in range(4)] == [1, 3, 0, 2]


def test_edf_pushes_out_latest_deadline_when_full():
    q = EDFQueue(3000)
    for i in range(3):
        q.enqueue(pkt(i, deadline=math.inf), 0)  # buffer full of no-deadline packets
    dropped = q.enqueue(pkt(10, deadline=1.0), 0)
    assert [d.seq for d in dropped] == [2]  # latest deadline (inf, newest) pushed out
    assert q.enqueue(pkt(11, deadline=math.inf), 0)[0].seq == 11  # cannot push out an earlier deadline
    assert [q.dequeue(0).seq for _ in range(3)] == [10, 0, 1]
    assert q.bytes == 0 and len(q) == 0


def test_fifo_preserves_order():
    q = FIFOQueue(10**6)
    for i in range(50):
        q.enqueue(pkt(i, flow=i % 3), 0)
    assert [q.dequeue(0).seq for _ in range(50)] == list(range(50))


def _two_flows(mini, discipline):
    flows = [
        {"id": "urgent", "kind": "constant_rate", "src": "A", "dst": "B", "size": {"bytes": 1000}, "priority": 1,
         "deadline_ms": 20, "arrival": {"model": "poisson", "rate_mps": 1230}, "max_rate_mbps": 100},
        {"id": "background", "kind": "constant_rate", "src": "A", "dst": "B", "size": {"bytes": 1000}, "priority": 6,
         "arrival": {"model": "poisson", "rate_mps": 600}, "max_rate_mbps": 100},
    ]
    pol = [{"id": "p", "label": "p", "routing": "static", "scheduling": discipline, "placement": "cloud"}]
    return mini(cap_mbps=10, flows=flows, policies=pol, buffer_bytes=100_000, duration_s=6)


def test_starvation_is_reported_for_edf_under_overload(mini):
    """Offered 14.6 Mb/s into 10 Mb/s. EDF serves deadline traffic first, so the no-deadline flow
    starves; WFQ shares by weight. Both outcomes are visible in the fairness report."""
    edf = Simulation(_two_flows(mini, "edf"), "s", "p", 1).run()
    wfq = Simulation(_two_flows(mini, "wfq"), "s", "p", 1).run()
    bg_edf = next(f for f in edf["flows"] if f["id"] == "background")
    bg_wfq = next(f for f in wfq["flows"] if f["id"] == "background")
    assert bg_edf["delivery_ratio_bytes"] < 0.1 and bg_edf["starved"]
    assert "background" in edf["fairness"]["starved_flows"]
    assert bg_wfq["delivery_ratio_bytes"] > 0.4 and not bg_wfq["starved"]
    assert wfq["fairness"]["jain_delivery_ratio"] > edf["fairness"]["jain_delivery_ratio"]
    # per-class view exposes the trade-off rather than an aggregate hiding it
    assert edf["classes"]["1"]["deadline_miss_ratio"] < wfq["classes"]["1"]["deadline_miss_ratio"]
