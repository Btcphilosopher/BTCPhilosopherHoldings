"""Capacity conservation: no link carries more bits than the integral of its capacity."""

import math

import numpy as np
import pytest

from vhfnet.simulation.engine import Simulation
from vhfnet.simulation.timeline import LinkTimeline
from vhfnet.units import serialization_delay_s


def test_serialization_delay_constant_capacity():
    tl = LinkTimeline.constant(10e6)
    t_end, tx, interrupted = tl.transmit(1.0, 12_000)
    assert not interrupted
    assert t_end == pytest.approx(1.0 + 12_000 / 10e6)
    assert tx == pytest.approx(serialization_delay_s(1500, 10e6))


def test_transmit_integrates_over_capacity_change():
    tl = LinkTimeline([0.0, 1.0], [8e6, 2e6], [True, True])
    # 8 Mbit/s for the last 0.5 s before t=1 carries 4 Mbit; the remaining 2 Mbit at 2 Mbit/s takes 1 s.
    t_end, tx, _ = tl.transmit(0.5, 6e6)
    assert t_end == pytest.approx(2.0)
    assert tl.integral(0.5, t_end) == pytest.approx(6e6)


def test_zero_capacity_stalls_without_counting_as_transmission():
    tl = LinkTimeline([0.0, 1.0, 1.5], [1e6, 0.0, 1e6], [True, True, True])
    t_end, tx, interrupted = tl.transmit(0.9, 2e5)
    assert not interrupted
    assert t_end == pytest.approx(1.6)  # 0.1 s at 1 Mb/s, 0.5 s stall, 0.1 s at 1 Mb/s
    assert tx == pytest.approx(0.2)


def test_outage_interrupts_transmission():
    tl = LinkTimeline([0.0, 1.0, 2.0], [1e6, 1e6, 1e6], [True, False, True])
    t_end, _, interrupted = tl.transmit(0.95, 1e5)
    assert interrupted and t_end == pytest.approx(1.0)
    assert tl.next_transmittable(1.2) == pytest.approx(2.0)
    assert tl.integral(0, 3) == pytest.approx(2e6)


def _overloaded(mini, **kw):
    flows = [{"id": "f", "kind": "constant_rate", "src": "A", "dst": "B", "size": {"bytes": 1000},
              "arrival": {"model": "poisson", "rate_mps": 2500}, "max_rate_mbps": 100}]
    return mini(cap_mbps=10, flows=flows, **kw)


@pytest.mark.parametrize("events", [
    [],
    [{"at_s": 1.0, "kind": "capacity_scale", "target": "ab", "factor": 0.3, "duration_s": 2.0}],
    [{"at_s": 1.0, "kind": "outage", "target": "ab", "duration_s": 1.0},
     {"at_s": 3.0, "kind": "handover", "target": "ab", "interruption_ms": 200}],
])
def test_link_never_exceeds_capacity_integral(mini, events):
    cfg = _overloaded(mini, events=events)
    sim = Simulation(cfg, "s", "static", 3, trace_links=True)
    res = sim.run()
    assert res["integrity"]["capacity_conserved"]
    for link in sim.network.by_id.values():
        log = np.asarray(link.tx_log, dtype=float)
        if not log.size:
            continue
        # single transmitter: intervals never overlap
        assert np.all(log[1:, 0] >= log[:-1, 1] - 1e-12)
        # each packet's bits equal the capacity integral over its transmission interval
        for s, e, bits in log:
            assert link.timeline.integral(s, e) == pytest.approx(bits, rel=1e-9)
        # any window: bits fully transmitted inside it <= capacity integral of the window
        for w0 in np.arange(0, 6, 0.25):
            inside = (log[:, 0] >= w0) & (log[:, 1] <= w0 + 0.5)
            assert log[inside, 2].sum() <= link.timeline.integral(w0, w0 + 0.5) * (1 + 1e-9) + 1
    ab = next(l for l in res["links"] if l["link"] == "ab:A>B")
    assert ab["utilisation"] <= 1.0 + 1e-9
    assert ab["drops"]["buffer"] > 0  # offered 20 Mb/s into 10 Mb/s: overflow is reported, not hidden


def test_demo_run_integrity(demo_cfg):
    res = Simulation(demo_cfg, "path_outage", "adaptive", 2).run()
    I = res["integrity"]
    assert I["capacity_conserved"]
    assert I["delay_identity_max_abs_error_s"] < 1e-9
    assert I["packets_injected"] == I["packets_delivered_incl_duplicates"] + I["packets_dropped"] + I["packets_in_flight_at_end"]
    for l in res["links"]:
        assert l["tx_bits"] <= l["capacity_integral_bits"] * (1 + 1e-9) + 1
