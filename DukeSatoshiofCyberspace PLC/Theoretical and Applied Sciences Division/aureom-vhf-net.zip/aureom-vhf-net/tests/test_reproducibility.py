"""Seeded reproducibility and common random numbers across policies."""

from vhfnet.config import load_experiment
from vhfnet.experiments.runner import run_experiment
from vhfnet.simulation.engine import Simulation


def test_same_seed_same_fingerprint(demo_cfg):
    a = Simulation(demo_cfg, "bursty", "adaptive", 4).run()
    b = Simulation(demo_cfg, "bursty", "adaptive", 4).run()
    c = Simulation(demo_cfg, "bursty", "adaptive", 5).run()
    assert a["fingerprint"] == b["fingerprint"]
    assert a["fingerprint"] != c["fingerprint"]
    assert a["totals"] == b["totals"]


def test_common_random_numbers_across_policies(demo_cfg):
    """Equivalent workloads: every policy sees the same offered application traffic per seed.
    (Adaptive media bitrate and request rejection legitimately change *admitted* bytes.)"""
    runs = {p.id: Simulation(demo_cfg, "baseline", p.id, 3).run() for p in demo_cfg.policies}
    for fid in ("telemetry", "twin", "bulk"):
        offered = {pid: next(f for f in r["flows"] if f["id"] == fid)["offered_bytes"] for pid, r in runs.items()}
        assert len(set(offered.values())) == 1, offered
    msgs = {pid: next(f for f in r["flows"] if f["id"] == "api")["messages"]["offered"] for pid, r in runs.items()}
    assert len(set(msgs.values())) == 1


def test_runner_is_reproducible_across_worker_counts(tmp_path, demo_cfg):
    cfg = demo_cfg.model_copy(update={"duration_s": 2.0})
    m1 = run_experiment(cfg, tmp_path / "a", scenarios=["baseline"], policies=["baseline", "adaptive"], seeds=[1, 2],
                        workers=1, progress=None)
    m2 = run_experiment(cfg, tmp_path / "b", scenarios=["baseline"], policies=["baseline", "adaptive"], seeds=[1, 2],
                        workers=2, progress=None)
    assert m1["fingerprints"] == m2["fingerprints"]
    for f in ("runs.csv", "flows.csv", "links.csv", "aggregate.csv", "comparison.json", "manifest.json"):
        assert (tmp_path / "a" / f).exists()
