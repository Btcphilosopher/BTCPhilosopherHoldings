"""Metric definitions and traffic accounting."""

import numpy as np
import pytest

from vhfnet.simulation.engine import Simulation
from vhfnet.telemetry import metrics as M


def test_jitter_rfc3550_constant_transit_is_zero():
    s = np.arange(100) * 0.01
    assert M.jitter_rfc3550(s, s + 0.005) == pytest.approx(0.0)


def test_jitter_rfc3550_alternating():
    s = np.arange(2000) * 0.01
    r = s + np.where(np.arange(2000) % 2 == 0, 0.010, 0.012)  # |D| = 2 ms every packet
    assert M.jitter_rfc3550(s, r) == pytest.approx(0.002, rel=0.02)  # J converges to |D|
    assert np.allclose(M.ipdv(s, r), 0.002)
    assert np.percentile(M.pdv(r - s), 99) == pytest.approx(0.002)


def test_reordering_and_jain_and_gap():
    assert M.count_reordered([0, 1, 3, 2, 4, 6, 5]) == 2
    assert M.jain_index([1, 1, 1, 1]) == pytest.approx(1.0)
    assert M.jain_index([1, 0, 0, 0]) == pytest.approx(0.25)
    assert M.max_gap([1.0, 1.5, 4.0], 0.0, 5.0) == pytest.approx(2.5)


def test_age_of_information_periodic():
    # updates generated every 1 s, delivered 0.2 s later: age ramps 0.2 -> 1.2, mean 0.7
    g = np.arange(0, 10, 1.0)
    assert M.age_of_information(g, g + 0.2, 1.2, 9.2) == pytest.approx(0.7, rel=1e-6)


def test_percentiles_empty():
    p = M.percentiles([])
    assert p["count"] == 0 and p["p99"] is None


def test_accounting_levels(mini):
    flows = [{"id": "f", "kind": "constant_rate", "src": "A", "dst": "B", "size": {"bytes": 2500},
              "arrival": {"model": "constant", "rate_mps": 200}, "max_rate_mbps": 20}]
    cfg = mini(cap_mbps=20, flows=flows, header_bytes=64, mtu=1000,
               loss={"model": "bernoulli", "p": 0.02}, duration_s=4)
    f = Simulation(cfg, "s", "static", 5).run()["flows"][0]
    # 2500 B messages -> 3 packets (1000, 1000, 500) each with 64 B header
    assert f["header_overhead_ratio"] == pytest.approx(3 * 64 / (2500 + 3 * 64), rel=1e-9)
    assert f["offered_bytes"] == 800 * 2500
    assert f["transmitted_wire_bytes"] >= f["delivered_wire_bytes"]
    assert f["unique_payload_bytes"] <= f["offered_bytes"]
    assert f["useful_bytes"] <= f["unique_payload_bytes"]
    assert f["network_drops"]["channel"] > 0
    assert f["packet_loss_ratio"] == pytest.approx(0.02, abs=0.01)
    assert f["messages"]["offered"] == f["messages"]["completed"] + f["messages"]["incomplete"] + f["messages"]["rejected_backpressure"]


def test_backpressure_rejections_are_reported(mini):
    flows = [{"id": "f", "kind": "constant_rate", "src": "A", "dst": "B", "size": {"bytes": 50_000},
              "arrival": {"model": "constant", "rate_mps": 100}, "max_rate_mbps": 10, "send_buffer_bytes": 200_000}]
    f = Simulation(mini(cap_mbps=100, flows=flows, duration_s=3), "s", "static", 1).run()["flows"][0]
    # offered 40 Mb/s, paced at <= 10 Mb/s with a bounded 200 kB buffer: most messages are rejected
    assert f["messages"]["rejected_backpressure"] > 0
    assert f["rejected_bytes_backpressure"] == f["messages"]["rejected_backpressure"] * 50_000
    horizon = 3 + 2  # generation window + drain: pacing bounds the rate over the whole sending period
    assert f["transmitted_wire_bytes"] * 8 <= 10e6 * horizon * 1.01


def test_retransmissions_and_duplicates_accounted(mini):
    flows = [{"id": "f", "kind": "constant_rate", "src": "A", "dst": "B", "size": {"bytes": 1000},
              "arrival": {"model": "constant", "rate_mps": 500}, "max_rate_mbps": 20,
              "reliability": {"mode": "reliable", "max_retx": 4}}]
    cfg = mini(cap_mbps=20, flows=flows, loss={"model": "bernoulli", "p": 0.05}, duration_s=4)
    f = Simulation(cfg, "s", "static", 9).run()["flows"][0]
    assert f["retransmitted_packets"] > 0
    assert f["packet_loss_ratio"] < 0.002  # ARQ recovers nearly all (experimental, not TCP)
    assert f["goodput_bps"] <= f["offered_bps"] + 1e-6  # duplicates never count as goodput
