"""Live transports on loopback (real sockets, bounded)."""

import asyncio
import time

import pytest

from vhfnet.config import LiveTestConfig
from vhfnet.transport.framing import FLAG_ECHO_REQ, FrameHeader
from vhfnet.transport.framing import encode_frame, pack_header, unpack_header
from vhfnet.transport.native import PythonCodec, conformance_check, load_codec
from vhfnet.transport.tcp import TCPClientAdapter, TCPServer
from vhfnet.transport.udp import UDPClientAdapter, UDPServer

pytestmark = pytest.mark.live


def test_frame_roundtrip_and_codec_conformance():
    h = FrameHeader(FLAG_ECHO_REQ, 7, 2**40 + 1, 99, 1, 3, 123456789, 1200, 64)
    assert unpack_header(pack_header(h)) == h
    assert len(encode_frame(h, b"\0" * 1200, length_prefix=True)) == 4 + 40 + 1200
    assert conformance_check(PythonCodec())
    assert conformance_check(load_codec())


def test_tcp_echo_and_server_stats():
    async def main():
        srv = TCPServer("127.0.0.1", 0)
        port = await srv.start()
        ad = TCPClientAdapter("127.0.0.1", port)
        await ad.connect()
        rtts = []
        for i in range(50):
            rtt, n = await ad.request(FrameHeader(FLAG_ECHO_REQ, 3, i, i, 0, 1, time.monotonic_ns(), 100, 500),
                                      b"\0" * 100, 2.0)
            assert n == 500
            rtts.append(rtt)
        stats = await ad.fin(one_way_valid=True)
        await ad.close()
        await srv.close()
        return rtts, stats

    rtts, stats = asyncio.run(main())
    assert all(0 < r < 1 for r in rtts)
    s = stats["3"]
    assert s["unique"] == 50 and s["duplicates"] == 0 and s["owd_ms"]["count"] == 50


def test_udp_stream_feedback_and_counts():
    async def main():
        srv = UDPServer("127.0.0.1", 0, feedback_interval_s=0.01)
        port = await srv.start()
        ad = UDPClientAdapter("127.0.0.1", port)
        await ad.connect()
        fbs = []
        ad.feedback_handlers[1] = fbs.append
        for i in range(300):
            ad.send_nowait(FrameHeader(0, 1, i, i, 0, 1, time.monotonic_ns(), 1200), b"\0" * 1200)
            if i % 20 == 0:
                await asyncio.sleep(0.002)
        ad.send_nowait(FrameHeader(0, 1, 5, 5, 0, 1, time.monotonic_ns(), 1200), b"\0" * 1200)  # duplicate
        await asyncio.sleep(0.1)
        stats = await ad.fin(one_way_valid=True)
        await ad.close()
        await srv.close()
        return fbs, stats

    fbs, stats = asyncio.run(main())
    s = stats["1"]
    assert s["unique"] >= 295 and s["duplicates"] >= 1  # loopback UDP may still drop under load: counted
    assert fbs and fbs[-1]["highest"] == 299


def _cfg(transport, flows, ceiling=100):
    return LiveTestConfig.model_validate({"name": "t", "transport": transport, "endpoint": {"host": "127.0.0.1", "port": 0},
                                          "rate_ceiling_mbps": ceiling, "max_duration_s": 10, "flows": flows})


def test_live_runner_udp_bounded_rate():
    from vhfnet.transport.live import run_live

    res = run_live(_cfg("udp", [{"id": "p", "pattern": "constant_rate", "payload_bytes": 1200, "rate_mbps": 20,
                                 "duration_s": 1.0}]))
    f = res["flows"][0]
    assert res["meta"]["mode"] == "LIVE TEST"
    assert f["achieved_send_wire_rate_mbps_est"] <= 20 * 1.05  # never above the configured rate
    assert f["owd_ms"] is not None  # same-host clock
    assert res["totals"]["budget_bytes_used"] <= res["meta"]["limits"]["max_total_bytes"]


def test_live_runner_tcp_request_response_with_tls():
    from vhfnet.transport.live import run_live

    cfg = _cfg("tcp", [{"id": "r", "pattern": "request_response", "payload_bytes": 200, "response_bytes": 800,
                        "rate_mbps": 2, "concurrency": 8, "duration_s": 1.0, "timeout_ms": 1000}])
    cfg = cfg.model_copy(update={"tls": True})
    res = run_live(cfg)
    f = res["flows"][0]
    assert res["meta"]["tls"] is True
    assert f["requests"]["ok"] + f["requests"]["late"] > 100
    assert f["requests"]["completed"] == f["requests"]["issued"]


def test_live_runner_quic():
    pytest.importorskip("aioquic")
    from vhfnet.transport.live import run_live

    res = run_live(_cfg("quic", [{"id": "r", "pattern": "request_response", "payload_bytes": 200, "response_bytes": 400,
                                  "rate_mbps": 1, "concurrency": 4, "duration_s": 1.0, "timeout_ms": 1000}]))
    assert res["flows"][0]["requests"]["ok"] > 50
