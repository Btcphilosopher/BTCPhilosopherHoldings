"""Inference tools: Beta-Bernoulli (independent and dependence-aware), route comparison, VOI, Monte Carlo."""

import math

import numpy as np
import pytest

from vhfnet.optimisation import (PATH_MODEL_ASSUMPTIONS, BetaPosterior, UncertainInput, beta_bernoulli,
                                 block_bootstrap_ci, compare_routes, effective_sample_size, path_latency_model,
                                 run_monte_carlo, value_of_information, windowed_rates)
from vhfnet.optimisation.bayes import deadline_miss_posterior


def bursty_series(n=20000, seed=0):
    rng = np.random.default_rng(seed)
    x = np.zeros(n)
    i = 0
    while i < n:
        if rng.random() < 0.002:
            x[i:i + rng.integers(5, 30)] = 1
            i += 30
        i += 1
    return x


def test_conjugate_update():
    p = beta_bernoulli([1, 0, 0, 1, 0], prior=(1, 1))
    assert (p.a, p.b) == (3, 4)
    assert p.mean == pytest.approx(3 / 7)
    lo, hi = p.interval(0.95)
    assert lo < p.mean < hi
    assert BetaPosterior(1, 1).update(2, 10).a == 3


def test_ess_detects_correlation():
    iid = (np.random.default_rng(1).random(20000) < 0.03).astype(float)
    assert effective_sample_size(iid) == pytest.approx(20000, rel=0.15)
    x = bursty_series()
    assert effective_sample_size(x) < 0.2 * x.size


def test_dependence_aware_posteriors_are_wider():
    x = bursty_series()
    ind = beta_bernoulli(x)
    for m in ("ess", "blocks"):
        dep = beta_bernoulli(x, method=m)
        assert dep.sd > 2 * ind.sd
        assert dep.mean == pytest.approx(ind.mean, abs=0.005)


def test_block_bootstrap_and_windows():
    x = bursty_series()
    ci = block_bootstrap_ci(x, block=200, seed=3)
    assert ci["ci"][0] < ci["mean"] < ci["ci"][1]
    w = windowed_rates(np.arange(x.size) * 0.001, x, 1.0)
    assert len(w["rate"]) == 20


def test_deadline_miss_counts_failures():
    p = deadline_miss_posterior([0.01, 0.02, 0.2], 0.1, failures=2, method="independent")
    assert (p.a, p.b) == (1 + 3, 1 + 2)


def test_route_comparison_and_voi():
    a = beta_bernoulli([1] * 3 + [0] * 997)
    b = beta_bernoulli([1] * 30 + [0] * 970)
    c = compare_routes(a, b, seed=1)
    assert c["prob_a_lower"] > 0.99
    v = value_of_information(a, b, 500, 1e5, seed=1)
    assert v["evpi_per_message"] >= v["evsi_per_message"] >= -1e-6
    assert v["current_choice"] == "A"
    close = value_of_information(beta_bernoulli([1] * 5 + [0] * 995), beta_bernoulli([1] * 6 + [0] * 994), 2000, 1e6)
    assert close["evsi_per_message"] > v["evsi_per_message"]  # measuring helps more when routes are close


def _inputs():
    return [UncertainInput("cap_0", "lognormal", (80e6, 0.3)), UncertainInput("load_0", "uniform", (30e6, 70e6)),
            UncertainInput("prop_0", "fixed", (0.001,)), UncertainInput("loss_0", "beta", (2, 2000))]


def test_monte_carlo_report_contents_and_reproducibility():
    model = path_latency_model(1, 60000)
    r1 = run_monte_carlo(_inputs(), model, draws=20000, seed=5, thresholds=[0.05], assumptions=PATH_MODEL_ASSUMPTIONS)
    r2 = run_monte_carlo(_inputs(), model, draws=20000, seed=5, thresholds=[0.05])
    assert r1.quantiles == r2.quantiles and r1.draws == 20000 and r1.seed == 5
    assert r1.mcse_mean > 0 and all(v >= 0 or math.isinf(v) for v in r1.mcse_quantiles.values())
    assert 0 < r1.nonfinite_fraction < 0.2  # some draws have load > capacity: unstable, kept as +inf
    assert math.isinf(r1.quantiles["p99"])
    assert {s["input"] for s in r1.sensitivity} == {"cap_0", "load_0", "loss_0"}
    assert r1.assumptions == PATH_MODEL_ASSUMPTIONS
    assert r1.exceedance["0.05"]["prob"] >= r1.nonfinite_fraction
