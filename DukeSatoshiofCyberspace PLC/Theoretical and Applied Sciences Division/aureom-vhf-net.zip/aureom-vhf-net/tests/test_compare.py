"""Paired comparison verdicts respect metric direction and uncertainty."""

from vhfnet.experiments.compare import compare_policies, paired_test


def test_lower_is_better_direction():
    ref = [0.30, 0.31, 0.29, 0.30, 0.32, 0.30]
    assert paired_test(ref, [0.02, 0.03, 0.02, 0.01, 0.03, 0.02], -1)["verdict"] == "better"
    assert paired_test(ref, [0.50, 0.52, 0.49, 0.51, 0.55, 0.50], -1)["verdict"] == "worse"


def test_higher_is_better_direction():
    ref = [10.0, 11.0, 9.0, 10.5, 10.0]
    assert paired_test(ref, [12.0, 13.0, 11.5, 12.0, 12.5], +1)["verdict"] == "better"
    assert paired_test(ref, [8.0, 9.0, 7.5, 8.0, 8.5], +1)["verdict"] == "worse"


def test_ci_straddling_zero_is_inconclusive():
    ref = [0.020, 0.025, 0.022, 0.021, 0.024, 0.023, 0.020, 0.026]
    alt = [0.010, 0.030, 0.015, 0.028, 0.012, 0.030, 0.018, 0.027]
    t = paired_test(ref, alt, -1)
    assert t["ci95"][0] < 0 < t["ci95"][1]
    assert t["verdict"] == "inconclusive"


def test_identical_and_missing():
    assert paired_test([1, 2, 3], [1, 2, 3], -1)["verdict"] == "no-difference"
    assert paired_test([None, None], [1, 2], -1)["verdict"] == "insufficient-data"


def test_compare_policies_flags_class_degradation():
    runs = []
    for seed in range(6):
        runs.append({"scenario": "s", "policy": "ref", "seed": seed,
                     "headline": {"deadline_miss_ratio": 0.3, "class6_goodput_mbps": 10.0 + 0.01 * seed}})
        runs.append({"scenario": "s", "policy": "alt", "seed": seed,
                     "headline": {"deadline_miss_ratio": 0.05, "class6_goodput_mbps": 4.0 + 0.01 * seed}})
    cmp = compare_policies(runs, "ref")
    assert cmp["scenarios"]["s"]["alt"]["deadline_miss_ratio"]["verdict"] == "better"
    assert any(d["metric"] == "class6_goodput_mbps" for d in cmp["degradations"])
    assert any(s.startswith("DEGRADATION") for s in cmp["statements"])
