"""Timeouts, failures and resource limits: failures are counted, never silently dropped."""

import asyncio
import threading

import pytest

from vhfnet.simulation.engine import Simulation, SimulationCancelled, SimulationLimitExceeded
from vhfnet.transport.framing import FLAG_ECHO_REQ, FrameHeader
from vhfnet.transport.safety import Budget, BudgetExceeded
from vhfnet.transport.tcp import TCPClientAdapter


def _rr(mini, events, timeout_ms=300):
    flows = [{"id": "rpc", "kind": "request_response", "src": "A", "dst": "B", "size": {"bytes": 500},
              "response_size": {"bytes": 2000}, "arrival": {"model": "poisson", "rate_mps": 100},
              "deadline_ms": 50, "timeout_ms": timeout_ms, "max_rate_mbps": 50}]
    return mini(cap_mbps=10, flows=flows, events=events, duration_s=4)


def test_request_failures_are_counted(mini):
    res = Simulation(_rr(mini, [{"at_s": 1.0, "kind": "outage", "target": "ab", "duration_s": 1.0}]),
                     "s", "static", 2).run()
    rq = res["requests"]["rpc"]
    assert sum(rq["status"].values()) == rq["total"]
    assert rq["status"].get("timeout", 0) >= 80  # ~1 s of requests at 100/s hit the outage
    assert rq["failure_ratio"] > 0.15
    assert rq["p99_including_failures_ms"] is None  # >1% failed: p99 is unbounded, not hidden
    assert res["totals"]["request_failures"] == rq["total"] - rq["status"].get("ok", 0) - rq["status"].get("late", 0)
    f = next(x for x in res["flows"] if x["id"] == "rpc")
    assert f["deadline_miss_ratio"] == pytest.approx(1 - rq["on_time_ratio"])


def test_event_limit_enforced(mini):
    cfg = _rr(mini, [])
    cfg = cfg.model_copy(update={"limits": cfg.limits.model_copy(update={"max_events": 2_000})})
    with pytest.raises(SimulationLimitExceeded):
        Simulation(cfg, "s", "static", 1).run()


def test_cancellation(mini):
    ev = threading.Event()
    ev.set()
    with pytest.raises(SimulationCancelled):
        Simulation(_rr(mini, []), "s", "static", 1, cancel=ev).run()


def test_budget_enforced():
    b = Budget(max_bytes=1000, max_duration_s=10)
    b.charge(600)
    with pytest.raises(BudgetExceeded):
        b.charge(600)
    assert b.exhausted and b.reason == "max_total_bytes reached"


@pytest.mark.live
def test_live_tcp_request_timeout():
    async def main():
        async def silent(reader, writer):  # accepts and reads but never answers
            try:
                while await reader.read(65536):
                    pass
            finally:
                writer.close()

        srv = await asyncio.start_server(silent, "127.0.0.1", 0)
        port = srv.sockets[0].getsockname()[1]
        ad = TCPClientAdapter("127.0.0.1", port)
        await ad.connect()
        with pytest.raises(asyncio.TimeoutError):
            await ad.request(FrameHeader(FLAG_ECHO_REQ, 1, 0, 0, 0, 1, 0, 3, 16), b"abc", 0.2)
        await ad.close()
        srv.close()
        await srv.wait_closed()

    asyncio.run(main())
