"""Config validation, unit separation and live-test guard rails."""

import pytest
from pydantic import ValidationError

from vhfnet.config import LiveTestConfig, load_live
from vhfnet.simulation.wireless import capacity_bps, link_budget, noise_dbm
from vhfnet.transport.safety import EndpointNotAllowed, resolve_endpoint
from vhfnet.units import gbps_to_bps, mbps_to_bps, serialization_delay_s

BASE = {"name": "t", "transport": "udp", "endpoint": {"host": "127.0.0.1", "port": 9400},
        "flows": [{"id": "f", "pattern": "constant_rate", "rate_mbps": 10, "duration_s": 2}]}


def live(**kw):
    d = {**BASE, **kw}
    return LiveTestConfig.model_validate(d)


def test_live_limits_validated():
    with pytest.raises(ValidationError):
        live(max_duration_s=10_000)
    with pytest.raises(ValidationError):
        live(rate_ceiling_mbps=5)  # flow asks for 10
    with pytest.raises(ValidationError):
        live(flows=[{"id": "f", "pattern": "constant_rate", "rate_mbps": 10, "duration_s": 60}])
    with pytest.raises(ValidationError):
        live(authorised=True)  # needs an authorisation note
    with pytest.raises(ValidationError):
        live(allowed_networks=["10.0.0.0/8"])  # needs authorised
    with pytest.raises(ValidationError):
        live(clock_sync="ntp")  # needs an error bound


def test_endpoint_policy():
    assert resolve_endpoint(live()).loopback
    with pytest.raises(EndpointNotAllowed):
        resolve_endpoint(live(endpoint={"host": "192.0.2.10", "port": 9}))
    with pytest.raises(EndpointNotAllowed):
        resolve_endpoint(live(endpoint={"host": "224.0.0.1", "port": 9}, authorised=True,
                              authorisation_note="x", allowed_networks=["224.0.0.0/4"]))
    ok = resolve_endpoint(live(endpoint={"host": "192.0.2.10", "port": 9}, authorised=True,
                               authorisation_note="lab bench", allowed_networks=["192.0.2.0/24"]))
    assert not ok.loopback and ok.ip == "192.0.2.10"


def test_example_configs_load():
    for name in ("loopback_tcp", "loopback_udp", "loopback_quic", "authorised_remote.example"):
        load_live(f"configs/live/{name}.yaml")


def test_units_kept_separate(demo_cfg):
    assert mbps_to_bps(80) == 80e6 and gbps_to_bps(1) == 1e9
    assert serialization_delay_s(1500, 12e6) == pytest.approx(1e-3)
    lb = demo_cfg.topology.links[0].wireless.link_budget
    r = link_budget(lb)
    assert r.carrier_freq_hz == 140e9 and r.channel_bw_hz == 2e9  # Hz, not bit/s
    # capacity (bit/s) is derived, capped by spectral efficiency and the slice share
    assert r.link_capacity_bps <= lb.slice_share * r.channel_bw_hz * lb.spectral_efficiency_cap_bps_hz + 1
    # doubling bandwidth raises noise power by 3 dB
    assert noise_dbm(2e9, 0) - noise_dbm(1e9, 0) == pytest.approx(3.0103, abs=1e-3)
    # blockage reduces capacity; a large attenuation drops below min SINR -> 0
    c0, *_ = capacity_bps(lb, 40.0, 0.0)
    c1, *_ = capacity_bps(lb, 40.0, 25.0)
    c2, *_ = capacity_bps(lb, 40.0, 60.0)
    assert c0 > c1 > c2 == 0.0
