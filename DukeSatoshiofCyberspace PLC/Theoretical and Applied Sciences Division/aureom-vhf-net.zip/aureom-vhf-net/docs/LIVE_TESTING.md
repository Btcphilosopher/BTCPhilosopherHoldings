# LIVE TEST mode

Live tests send real traffic, so they are bounded and explicit by construction.

## Rules enforced by the code

1. **Explicit endpoint only.** One `host:port` from the config. No discovery, scanning or address ranges as targets.
2. **Loopback by default.** Any other address requires `authorised: true`, an `authorisation_note`, and membership of a CIDR listed in `allowed_networks`. Multicast, broadcast, unspecified and reserved addresses are always refused.
3. **Finite and capped.** Each flow has a duration ≤ `max_duration_s` (hard max 300 s); the sum of flow rates ≤ `rate_ceiling_mbps` (hard max 2000); total bytes ≤ `max_total_bytes` (hard max 20 GiB). The budget is charged on every send and the whole test runs under a hard timeout.
4. **Pacing never exceeds the configured rate.** UDP adaptation (bounded AIMD) can only lower the rate.
5. **Bounded servers.** Test servers bind to loopback unless `--allow-nonlocal-bind` is given, have a maximum lifetime, a peer/connection limit, idle timeouts and frame-size limits.
6. **Encryption uses established libraries.** TCP+TLS via Python's `ssl` (OpenSSL); QUIC via `aioquic` (TLS 1.3). Self-signed certificates are generated only for local tests.

## Running

```bash
vhfnet live run configs/live/loopback_udp.yaml     # spawns a loopback server process, runs, writes results/live/*.json
vhfnet live run configs/live/loopback_tcp.yaml
vhfnet live run configs/live/loopback_quic.yaml    # needs aioquic
```

Between two machines you control (example in `configs/live/authorised_remote.example.yaml`):

```bash
# on the server machine
vhfnet live serve --transport udp --host 0.0.0.0 --port 9400 --lifetime 120 --allow-nonlocal-bind
# on the client machine (clock_sync: none -> RTT only, no one-way delay)
vhfnet live run my_authorised_config.yaml --no-spawn
```

## What the numbers mean

On loopback, results characterise Python/asyncio and the OS network stack on
that host — useful for knowing the generator's own limits before trusting a
remote measurement. They are not network hardware performance. Every live flow
reports target vs achieved rate, generator lag and a `generator_limited` flag.

## Experimental reliability (UDP)

`udp.experimental_reliability: true` enables NACK-based retransmission (the
receiver lists missing sequence numbers in its feedback, each at most three
times; the sender retransmits up to `max_retx` from a bounded buffer). It is an
experiment for studying retransmission and duplicate accounting. It provides no
ordering, flow-control or congestion-control guarantees and does not inherit
TCP or QUIC semantics.
