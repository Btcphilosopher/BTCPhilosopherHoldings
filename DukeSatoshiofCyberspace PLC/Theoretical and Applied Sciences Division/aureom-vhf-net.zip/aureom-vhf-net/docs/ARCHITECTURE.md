# Architecture

```
            ┌──────────────────────────── configs/ (YAML, validated by Pydantic) ───────────────────────────┐
            │ topologies/  workloads/  scenarios/  policies/  experiments/  live/                            │
            └──────────────┬───────────────────────────────────────────────────────────┬────────────────────┘
                           │ SIMULATION (virtual time)                                 │ LIVE TEST (real clocks)
                           ▼                                                           ▼
  traffic/ ──► transport/simulated.py ──► simulation/network.py ──► telemetry/   transport/{tcp,udp,quic}.py
  (arrival      (fragmentation, pacing,     (SimPy links: bounded     (metrics,      + transport/live.py
   schedules,    bounded send buffer,        queue → transmitter →     export,        (safety, budget, paced
   sizes)        per-destination AIMD,       loss → propagation)       SQLite)         generators, servers)
                 experimental ARQ)                ▲
                           ▲                      │ capacity/availability timelines
                 routing/ (control plane,   simulation/conditions.py ◄── simulation/wireless.py
                 static / least-delay /     (scenario events, random     (link budget, shadowing,
                 adaptive)                   outages, handovers)          mobility, blockage, INR)
                 scheduling/ (FIFO/WFQ/EDF)
                 edge/ (compute servers, placement, migration)
                           │
                           ▼
  experiments/ (seeded grids in a bounded process pool, paired comparison, benchmarks)
                           │
                           ▼
  api/ (FastAPI, bounded & cancellable runs) ──► dashboard/ (Plotly console, static report)
  optimisation/ (Beta–Bernoulli, dependence-aware variants, VOI, Monte Carlo, rate control)  ← independent of the simulator
```

## Module responsibilities

| Package | Responsibility |
|---|---|
| `vhfnet.config` | Pydantic models for every config; unit-suffixed field names; hard live-test ceilings. |
| `vhfnet.units` | Unit conversions; documents the separation of packet rate / carrier frequency / bandwidth / throughput. |
| `vhfnet.traffic` | Arrival models (constant, Poisson, periodic, ON/OFF, backlogged), size models (fixed, uniform, lognormal, video GOP), `Packet` and `Message` with sequence numbers, timestamps and delay components. |
| `vhfnet.transport` | `simulated.py` (virtual-time adapter), `tcp.py`, `udp.py`, `quic.py` (aioquic), `framing.py` (VHF frame), `native.py` (extension interface), `safety.py`, `live.py`, `tlsutil.py`. |
| `vhfnet.simulation` | Topology graph and candidate paths, capacity timelines, wireless abstraction, loss processes, SimPy links/network, the engine, and result summarisation. |
| `vhfnet.routing` | Delayed control-plane reports; static, least-estimated-delay and adaptive routers with an auditable route-change log. |
| `vhfnet.scheduling` | Byte-bounded FIFO (tail drop), WFQ/SCFQ (longest-queue drop), EDF (deadline push-out). |
| `vhfnet.edge` | Compute servers (cores + bounded FIFO queue), placement estimates, Erlang-C what-if calculator. Service migration lives in the engine. |
| `vhfnet.telemetry` | Metric definitions, clock policy, CPU/memory/event-loop sampling, SQLite metadata store, JSON/CSV export. |
| `vhfnet.optimisation` | Beta–Bernoulli (independent / ESS / blocks), block bootstrap, windowed rates, route comparison, value of information, Monte Carlo propagation, bounded AIMD. |
| `vhfnet.experiments` | Experiment runner (bounded `ProcessPoolExecutor`), paired-seed comparison, benchmarks. |
| `vhfnet.api` | FastAPI app: experiment browsing, bounded simulation runs, loopback live presets, analytic endpoints. |
| `vhfnet.dashboard` | Static console (HTML/CSS/JS + Plotly) and the self-contained report builder. |

## Event model (simulation)

Each configured link is two directional `SimLink`s. A packet costs two scheduled
events per hop: end of serialisation, and arrival at the next node after
propagation + that node's processing delay. The transmitter integrates bits
over the link's piecewise-constant capacity timeline, so time-varying capacity,
handover interruptions (capacity 0, link up → buffering) and outages (link down
→ in-flight loss, queue flush, arrival drops) are exact rather than sampled.

Routers never read ground truth: they consume `ControlView` snapshots (interval-
averaged queue, smoothed loss, carried rate, capacity, up/down) published every
`report_interval_ms` with `report_delay_ms` staleness, plus the flow's own
end-to-end feedback (one-way delay and loss per path), plus the device's own
assigned demand (local knowledge).

## Bounded resources

* Queues: every link buffer, sender buffer and compute queue has an explicit bound; overflow is counted by cause.
* Simulation: `limits.max_events`, `max_wall_s`, `max_packets`, `max_duration_s`; cooperative cancellation via `threading.Event`.
* API: one simulation at a time, ≤ 30 s virtual / ≤ 120 s wall; one live test at a time, loopback presets only.
* Experiments: worker pool capped at `min(cpu_count, 8)`.
* Live tests: hard ceilings on duration (300 s), aggregate rate (2 Gb/s) and bytes (20 GiB), checked on every send; server processes have bounded lifetimes, peers and frame sizes.
