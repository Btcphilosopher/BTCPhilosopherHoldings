# Modelling assumptions

Everything below is a modelling choice. Results are conditional on these choices
and on the configured parameters; none of them is a claim about a real network.

## Two modes, never mixed

| | SIMULATION | LIVE TEST |
|---|---|---|
| Time | virtual (SimPy) | `time.monotonic_ns()` |
| Traffic | modelled packets | real TCP/UDP/QUIC sockets |
| What results mean | outputs of the stated model | measurements of this host's software stack and the configured path |
| Labelled | `meta.mode = "SIMULATION"`, gold banner | `meta.mode = "LIVE TEST"`, blue banner |

Simulated throughput is never reported as hardware performance. The simulator's
own speed (events/s) is reported separately under `resources` and labelled
"software cost".

## Links (packet simulation)

* Directional, single transmitter, byte-bounded buffer with the configured discipline.
* Serialisation delay = bits / capacity, integrated over capacity changes.
* Propagation delay is fixed per link. Node processing is a fixed per-packet delay (no forwarding-rate limit).
* Loss models (Bernoulli, Gilbert–Elliott) act after serialisation: lost packets consumed capacity.
* Outage: the packet being serialised is lost, the queue is flushed, arrivals are dropped until the link is up.
* Interruption (handover): capacity 0 while up — packets wait in the queue (buffering).
* Random availability: exponential up-times (MTBF) and repair times (MTTR) when configured.
* Wire overhead: `header_bytes` per packet is an assumption (demo: 64 B ≈ 28 B IPv4+UDP + 36 B of transport fields). The live adapters' VHF frame header is 40 B (+ 4 B length prefix on stream transports), and their IP/transport overhead is estimated (28 B UDP, 40 B TCP).

## Radio abstraction (`simulation/wireless.py`)

* Log-distance path loss anchored to free-space loss at 1 m; no atmospheric/molecular absorption model (relevant at sub-THz, deliberately omitted and stated).
* SINR from explicit transmit power, antenna gains, noise figure, implementation loss and an *assumed* interference-to-noise ratio.
* Capacity = `slice_share × min(η·B·log2(1+SINR), B·SE_max)`, zero below `min_sinr_db`.
* Shadowing: Gaussian AR(1) in dB; blockage: extra attenuation during windows; mobility: constant speed with hard handovers at the cell edge.
* No fading, MCS tables, HARQ, scheduling within the cell, or beam management.
* Prospective 6G values (e.g. 140 GHz carrier, 2 GHz channel) are scenario parameters. A per-client `slice_share` maps cell capacity to lab-scale link capacity so packet-level simulation stays tractable in Python.

## Transport (simulated)

* Paced, rate-based sender; per-destination rate controller (bounded AIMD or fixed); bounded send buffer.
* Feedback (ack reports) every `feedback_interval_ms`, returning over the reverse path with propagation + processing delay only (reverse-path queueing is not modelled).
* Loss detection: QUIC-style time threshold (9/8 RTT) and packet threshold (3, first transmissions), plus RTO for tail losses.
* ARQ for `reliability.mode: reliable` is EXPERIMENTAL: no ordering guarantees, no congestion window, deadline-aware (no retransmission after a message's deadline).

## Routing

* Source routing over up to `max_paths` loop-free candidates ordered by propagation + processing delay.
* Control-plane reports: every 100 ms, published 20 ms later (configurable); queue is interval-averaged, loss is EWMA-smoothed.
* Adaptive cost combines estimated delay (model blended with measurements), loss, buffer occupancy, capacity shortfall (using the device's own assigned demand), and an exponential-tail deadline-miss approximation, plus a switching penalty; hysteresis and minimum dwell apply except on failover.
* A route switch holds the flow's sender for `switch_interrupt_ms` (physical switching cost) for every policy that switches.

## Edge compute

* Work in abstract giga-operations; service time = overhead + work / per-core speed; FIFO queue with a hard limit (rejections are failures).
* Completion = input transfer + waiting + processing + output transfer, each measured in simulation.
* Placement estimates use stale queue reports plus the client's own in-transit requests; the placement keeps its current target unless another is >10% better.
* Service migration: state is transferred over the network (reliable, half the path's nominal bottleneck rate), then a fixed downtime; updates arriving meanwhile complete only after the service resumes.

## Energy and cost

* Link energy = bits × `energy_per_bit_nj` + idle power × time; compute energy = idle power × time + active power per busy core-second.
* All energy numbers are ESTIMATES from these assumptions. Monetary costs appear only when the user configures `cost_per_core_s`.

## Traffic

* Arrival schedules are pre-generated per flow from named random streams (common random numbers across policies).
* Media flows may adapt frame size to the sender's current rate (`app_adaptive`), which changes *offered* load; this is reported (`app_rate_scale_mean`).
* File transfers are a backlog of 1 MB objects; useful goodput counts completed objects.
