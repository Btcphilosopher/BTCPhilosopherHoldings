# Performance boundaries and the native-extension interface

Python coordinates experiments and implements the reference algorithms. It is
not a line-rate packet engine, and VHF.NET does not pretend otherwise:

* The pure-Python VHF header codec (`struct`) is benchmarked by `vhfnet bench`
  (see `results/bench/benchmarks.json`) — typically 10^6 headers/s per core on a
  modern CPU, before any socket I/O.
* asyncio socket I/O adds per-datagram/per-write overhead; live tests flag
  `generator_limited` when the target rate is not achieved.
* The discrete-event simulator processes roughly 10^5 events/s (≈ 2·10^4
  simulated packets/s with ~5 hops); experiments therefore use lab-scale
  capacities (tens to hundreds of Mbit/s) and the simulator enforces event,
  packet and wall-clock limits.

## Extension points

A compiled module named `vhfnet_native` (C, Rust/PyO3, Cython…) may provide:

```python
class FrameCodec:
    name: str
    def pack(self, flags, flow_id, seq, msg_id, frag_idx, frag_cnt, send_ts_ns, payload_len, aux) -> bytes  # 40 B
    def unpack(self, buf, offset=0) -> tuple   # (flags, flow_id, seq, msg_id, frag_idx, frag_cnt, send_ts_ns, payload_len, aux)
    def pack_batch(self, rows) -> bytes        # concatenated headers

class Pacer:                                   # token bucket, ns resolution
    def __init__(self, rate_bps: float, burst_bytes: int): ...
    def due(self, now_ns: int, size_bytes: int) -> bool: ...
    def set_rate(self, rate_bps: float) -> None: ...
```

`vhfnet.transport.native.load_codec()` imports the module if present and runs
`conformance_check()` against golden vectors produced by the pure-Python
reference; a non-conforming extension is ignored. Natural further candidates
(not yet defined as interfaces): batched `sendmmsg`/`recvmmsg` I/O with GSO/GRO,
and a compiled event core for the link transmitter loop.

No native module is shipped. Claims about any native speed-up must come from
benchmarks run with the module installed.
