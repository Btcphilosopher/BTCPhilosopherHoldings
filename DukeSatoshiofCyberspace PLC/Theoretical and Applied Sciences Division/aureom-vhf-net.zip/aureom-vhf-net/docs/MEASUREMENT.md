# Measurement integrity

## Accounting levels (per flow and in totals)

| Level | Definition |
|---|---|
| offered | application payload generated (bytes; rate over the flow's generation window) |
| admitted | offered bytes accepted into the bounded send buffer; the rest is `rejected_backpressure` |
| transmitted | wire bytes handed to the first link: payload + headers, including retransmissions |
| delivered | wire bytes arriving at the destination, including duplicates |
| goodput | unique application payload delivered |
| useful | payload of messages completed by their deadline (all completed messages when no deadline). For request/response: request + response bytes of on-time requests |

Rates are normalised by the flow's generation window. Bytes delivered during the
drain period count toward the window, so a flow can show a small goodput
excess over offered only through rounding — duplicates never count.

## Latency

* **Simulation:** each delivered packet carries `t_app + t_queue + t_tx + t_prop + t_proc = recv − created`; the identity is checked for every packet (`integrity.delay_identity_max_abs_error_s`, ~1e-15 s). One-way delay is exact because there is a single virtual clock.
* **Live test:** RTT from `time.monotonic_ns()` on the client. One-way delay only when the clock policy allows it:
  * `same_host` — client and server share `CLOCK_MONOTONIC` (loopback),
  * `ptp` / `ntp` — reported together with the declared error bound,
  * `none` — not reported; timestamp differences would contain an unknown offset.
  A `same_host` policy with a non-loopback endpoint is downgraded to `none` with a warning.

## Jitter (explicit definitions)

* `jitter_rfc3550_ms`: time-average of the RFC 3550 estimator `J += (|D| − J)/16`, D = change of transit time between consecutive packets in arrival order.
* `ipdv_p95_ms`: 95th percentile of |transit_i − transit_{i−1}| (RFC 3393).
* `pdv_p99_ms`: 99th percentile of transit − min(transit) (RFC 5481).

## Loss, reordering, duplicates

* `packet_loss_ratio`: 1 − unique sequence numbers delivered / unique sequence numbers sent (end-to-end, after retransmissions).
* `network_drops`: per cause — `buffer`, `channel`, `outage`, `expired`, `stalled` — never hidden.
* Reordered: a unique packet with sequence number below the highest already received. Duplicates are counted separately and excluded from goodput.

## Failures are not discarded

Requests end as `ok`, `late`, `timeout`, `rejected` or `incomplete`. Latency
percentiles cover completed requests; the failure ratio is always shown next to
them, `p99_including_failures_ms` is `null` when more than 1% failed (the p99 is
unbounded), and the deadline-miss ratio counts late + failed over *offered*
requests.

## Queues, fairness, starvation

* Queue occupancy is integrated exactly over time (mean) and sampled for histories.
* Link utilisation = bits serialised / ∫capacity dt — ≤ 1 by construction (`integrity.capacity_conserved`).
* Fairness: Jain's index over per-flow delivery ratios; a flow is *starved* if it delivers < 10% (configurable) of its offered payload; `max_delivery_gap_s` reports the longest silence.
* Per-priority-class metrics accompany every aggregate; the comparison lists any class that got significantly worse.

## Host resources

* CPU and RSS of the live-test client via psutil (250 ms samples); the loopback server runs in a separate process.
* Event-loop delay: overshoot of `asyncio.sleep(5 ms)`, p50/p99/max.
* Generator limits: every live flow reports achieved vs target rate and the lag between scheduled and actual send times; `generator_limited` is set when a constant-rate flow achieves < 95% of target (or lag p99 > 10 ms).
* Simulator cost: wall/CPU time, events/s, simulated packets/s — software cost, not network performance.

## Statistics across runs

* Seeds are paired across policies (common random numbers); differences are analysed per seed.
* Summary across seeds: mean, SD, Monte Carlo standard error (SD/√n), p10/p50/p90.
* Verdicts: paired bootstrap 95% CI of the mean difference must exclude zero *and* ≥ 75% of seeds must agree in direction; Wilcoxon signed-rank p is reported for reference.
