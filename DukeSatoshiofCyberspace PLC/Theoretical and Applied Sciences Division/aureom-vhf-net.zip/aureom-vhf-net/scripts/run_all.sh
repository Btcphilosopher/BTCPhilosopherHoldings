#!/usr/bin/env bash
# Reproduce every bundled result: demo, ablations, 6G what-if, live loopback tests, benchmarks, report.
set -euo pipefail
cd "$(dirname "$0")/.."
W="${WORKERS:-4}"
vhfnet demo --config configs/experiments/demo.yaml --out results/demo --seeds 1,2,3,4,5,6,7,8 --workers "$W"
vhfnet experiment --config configs/experiments/ablation_routing.yaml --out results/ablation_routing \
  --scenarios capacity_drop,bursty,handover,path_outage,adaptive_recovery --workers "$W"
vhfnet experiment --config configs/experiments/ablation_scheduling.yaml --out results/ablation_scheduling \
  --scenarios baseline,bursty,capacity_drop --workers "$W"
vhfnet experiment --config configs/experiments/ablation_placement.yaml --out results/ablation_placement \
  --scenarios baseline,edge_overload,capacity_drop,path_outage --workers "$W"
vhfnet experiment --config configs/experiments/6g_prospective.yaml --out results/6g_prospective --workers "$W"
for t in tcp udp quic; do vhfnet live run "configs/live/loopback_${t}.yaml"; done
vhfnet bench --out results/bench
vhfnet report --results results --out results/report
python scripts/verify_reproducibility.py results/demo --samples 4
