"""Re-run a sample of runs from a results directory and compare fingerprints with its manifest.

Usage: python scripts/verify_reproducibility.py results/demo [--samples 4] [--all]

Fingerprints are SHA-256 over each run's canonical result (excluding host-dependent resource
figures). Identical fingerprints mean the run is bit-for-bit reproducible from config + seed.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

from vhfnet.config import ExperimentConfig
from vhfnet.simulation.engine import Simulation


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--samples", type=int, default=4)
    ap.add_argument("--all", action="store_true")
    a = ap.parse_args()
    root = Path(a.results)
    man = json.loads((root / "manifest.json").read_text())
    cfg = ExperimentConfig.model_validate(json.loads((root / "config.resolved.json").read_text()))
    keys = sorted(man["fingerprints"])
    pick = keys if a.all else random.Random(0).sample(keys, min(a.samples, len(keys)))
    ok = True
    for k in pick:
        scen, pol, seed = k.split("/")
        fp = Simulation(cfg, scen, pol, int(seed)).run()["fingerprint"]
        same = fp == man["fingerprints"][k]
        ok &= same
        print(f"{'OK ' if same else 'MISMATCH'} {k}: {fp[:16]}…")
    print("reproducible" if ok else "NOT reproducible (different code version or platform floating-point?)")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
