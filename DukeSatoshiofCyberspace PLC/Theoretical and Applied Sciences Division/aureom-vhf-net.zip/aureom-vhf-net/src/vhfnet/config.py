"""Pydantic configuration models for VHF.NET.

Every physical quantity in a config file carries its unit in the field name
(``capacity_mbps``, ``propagation_delay_ms``, ``carrier_freq_ghz`` ...). The
simulator converts to SI exactly once (see :mod:`vhfnet.units`).

Two strictly separated modes exist:

* ``ExperimentConfig``  -> SIMULATION (virtual time, discrete-event, SimPy).
* ``LiveTestConfig``    -> LIVE TEST  (real sockets, real monotonic clocks,
  bounded duration/rate/bytes, explicitly configured endpoints only).
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

# Hard safety ceilings for LIVE TEST mode. A config file cannot raise these.
LIVE_HARD_MAX_DURATION_S = 300.0
LIVE_HARD_MAX_RATE_MBPS = 2000.0
LIVE_HARD_MAX_TOTAL_BYTES = 20 * 1024**3


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=False)


# =============================================================================
# Topology (network digital twin)
# =============================================================================

NodeKind = Literal["client", "base_station", "edge", "core", "cloud"]
LinkKind = Literal["access", "fronthaul", "backhaul", "core", "cloud", "inter_edge", "other"]
Discipline = Literal["fifo", "wfq", "edf"]


class ComputeConfig(StrictModel):
    """Compute capacity of a node (client device, edge worker or cloud service).

    Work is expressed in abstract giga-operations (GOP); speed in GOP/s per core.
    """

    cores: int = Field(1, ge=1, le=4096)
    gops_per_core: float = Field(..., gt=0, description="GOP/s per core")
    queue_limit: int = Field(64, ge=0, description="max jobs waiting (bounded queue)")
    service_overhead_ms: float = Field(0.0, ge=0, description="fixed per-job dispatch overhead")
    idle_power_w: float = Field(0.0, ge=0, description="ASSUMED idle power")
    active_power_w_per_core: float = Field(0.0, ge=0, description="ASSUMED incremental power per busy core")
    cost_per_core_s: float = Field(0.0, ge=0, description="optional user-configured monetary cost")


class NodeConfig(StrictModel):
    id: str
    kind: NodeKind
    label: str | None = None
    processing_delay_us: float = Field(10.0, ge=0, description="per-packet forwarding/processing delay")
    position: tuple[float, float] = (0.0, 0.0)
    compute: ComputeConfig | None = None


class LossConfig(StrictModel):
    """Packet-loss model applied *after* a packet is serialised onto a link."""

    model: Literal["none", "bernoulli", "gilbert_elliott"] = "none"
    p: float = Field(0.0, ge=0, le=1, description="Bernoulli loss probability")
    p_good_to_bad: float = Field(0.0, ge=0, le=1)
    p_bad_to_good: float = Field(0.3, gt=0, le=1)
    loss_good: float = Field(0.0, ge=0, le=1)
    loss_bad: float = Field(0.5, ge=0, le=1)


class QueueConfig(StrictModel):
    discipline: Discipline = "fifo"
    buffer_bytes: int = Field(256_000, ge=1)
    drop_expired: bool = Field(False, description="EDF only: drop packets already past deadline")


class AvailabilityConfig(StrictModel):
    """Random up/down process (exponential MTBF / MTTR). None = always up."""

    mtbf_s: float | None = Field(None, gt=0)
    mttr_s: float | None = Field(None, gt=0)

    @model_validator(mode="after")
    def _both_or_neither(self) -> "AvailabilityConfig":
        if (self.mtbf_s is None) != (self.mttr_s is None):
            raise ValueError("availability needs both mtbf_s and mttr_s, or neither")
        return self


class EnergyConfig(StrictModel):
    """Energy *assumptions*. All energy figures produced are ESTIMATES."""

    energy_per_bit_nj: float = Field(0.0, ge=0)
    idle_power_w: float = Field(0.0, ge=0)


class LinkBudgetConfig(StrictModel):
    """Simplified link budget. Units are explicit; accuracy is NOT physical-layer grade.

    Received power  P_rx = P_tx + G_tx + G_rx - PL(d) - L_impl - L_block      [dBm]
    Path loss       PL(d) = FSPL(1 m, f_c) + 10 n log10(d / 1 m)               [dB]
    Noise           N = -174 dBm/Hz + 10 log10(B) + NF                         [dBm]
    Capacity        C = share * min(eta * B * log2(1 + SINR), B * SE_max)     [bit/s]
    """

    carrier_freq_ghz: float = Field(..., gt=0)
    channel_bw_mhz: float = Field(..., gt=0)
    tx_power_dbm: float
    tx_gain_dbi: float = 0.0
    rx_gain_dbi: float = 0.0
    noise_figure_db: float = Field(7.0, ge=0)
    path_loss_exponent: float = Field(2.0, ge=1.5, le=6)
    distance_m: float = Field(..., gt=0)
    implementation_loss_db: float = Field(3.0, ge=0)
    shannon_efficiency: float = Field(0.75, gt=0, le=1)
    spectral_efficiency_cap_bps_hz: float = Field(7.4, gt=0)
    min_sinr_db: float = -5.0
    slice_share: float = Field(1.0, gt=0, le=1, description="fraction of cell capacity given to this link")


class MobilityConfig(StrictModel):
    speed_mps: float = Field(0.0, ge=0)
    cell_radius_m: float = Field(100.0, gt=0)
    reset_distance_m: float = Field(10.0, gt=0)
    handover_interruption_ms: float = Field(50.0, ge=0)


class BlockageConfig(StrictModel):
    rate_per_s: float = Field(0.0, ge=0)
    mean_duration_s: float = Field(0.3, gt=0)
    attenuation_db: float = Field(20.0, ge=0)


class InterferenceConfig(StrictModel):
    """Interference is represented ONLY through this explicit assumption."""

    inr_db: float = Field(..., description="interference-to-noise ratio assumed at receiver")


class WirelessConfig(StrictModel):
    model: Literal["markov", "link_budget"]
    coherence_interval_ms: float = Field(10.0, gt=0)
    markov_factors: list[float] = Field(default_factory=lambda: [1.0, 0.5])
    markov_mean_dwell_s: list[float] = Field(default_factory=lambda: [2.0, 0.5])
    link_budget: LinkBudgetConfig | None = None
    shadowing_sigma_db: float = Field(0.0, ge=0)
    shadowing_corr_s: float = Field(0.5, gt=0)
    mobility: MobilityConfig | None = None
    blockage: BlockageConfig | None = None
    interference: InterferenceConfig | None = None
    assumptions: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _check(self) -> "WirelessConfig":
        if self.model == "link_budget" and self.link_budget is None:
            raise ValueError("wireless.model=link_budget requires a link_budget block")
        if self.model == "markov":
            if len(self.markov_factors) != len(self.markov_mean_dwell_s) or not self.markov_factors:
                raise ValueError("markov_factors and markov_mean_dwell_s must be equal-length, non-empty")
            if any(f < 0 for f in self.markov_factors):
                raise ValueError("markov factors must be >= 0")
        return self


class LinkConfig(StrictModel):
    """Bidirectional link. ``capacity_mbps`` is a->b, ``capacity_mbps_reverse`` is b->a."""

    id: str
    a: str
    b: str
    kind: LinkKind = "other"
    capacity_mbps: float = Field(..., gt=0)
    capacity_mbps_reverse: float | None = Field(None, gt=0)
    propagation_delay_ms: float = Field(..., ge=0)
    queue: QueueConfig = Field(default_factory=QueueConfig)
    loss: LossConfig = Field(default_factory=LossConfig)
    availability: AvailabilityConfig = Field(default_factory=AvailabilityConfig)
    energy: EnergyConfig = Field(default_factory=EnergyConfig)
    wireless: WirelessConfig | None = None


class TopologyConfig(StrictModel):
    name: str
    description: str = ""
    fictional: bool = True
    nodes: list[NodeConfig]
    links: list[LinkConfig]

    @model_validator(mode="after")
    def _check_refs(self) -> "TopologyConfig":
        ids = [n.id for n in self.nodes]
        if len(set(ids)) != len(ids):
            raise ValueError("duplicate node ids")
        lids = [lk.id for lk in self.links]
        if len(set(lids)) != len(lids):
            raise ValueError("duplicate link ids")
        idset = set(ids)
        for lk in self.links:
            if lk.a not in idset or lk.b not in idset:
                raise ValueError(f"link {lk.id} references unknown node")
            if lk.a == lk.b:
                raise ValueError(f"link {lk.id} is a self-loop")
        return self

    def node(self, node_id: str) -> NodeConfig:
        for n in self.nodes:
            if n.id == node_id:
                return n
        raise KeyError(node_id)


# =============================================================================
# Traffic
# =============================================================================

FlowKind = Literal[
    "constant_rate",
    "bursty",
    "request_response",
    "telemetry",
    "file_transfer",
    "media",
    "inference",
    "twin_update",
]


class ArrivalConfig(StrictModel):
    """Message arrival process. Rates are in *messages per second* (not bit/s, not Hz)."""

    model: Literal["constant", "poisson", "onoff", "periodic", "backlogged"]
    rate_mps: float | None = Field(None, gt=0)
    period_ms: float | None = Field(None, gt=0)
    jitter_ms: float = Field(0.0, ge=0)
    on_mean_s: float = Field(0.5, gt=0)
    off_mean_s: float = Field(0.5, gt=0)

    @model_validator(mode="after")
    def _check(self) -> "ArrivalConfig":
        if self.model in ("constant", "poisson", "onoff") and self.rate_mps is None:
            raise ValueError(f"arrival model {self.model} requires rate_mps")
        if self.model == "periodic" and self.period_ms is None:
            raise ValueError("periodic arrivals require period_ms")
        return self


class SizeConfig(StrictModel):
    dist: Literal["fixed", "uniform", "lognormal", "video"] = "fixed"
    bytes: int = Field(1000, ge=1)
    min_bytes: int = Field(1, ge=1)
    max_bytes: int = Field(10_000_000, ge=1)
    sigma: float = Field(0.5, gt=0)
    keyframe_interval: int = Field(30, ge=1)
    keyframe_ratio: float = Field(4.0, ge=1)


class ReliabilityConfig(StrictModel):
    """Reliability *objective*. ``target_delivery_ratio`` is reported against, never assumed met."""

    mode: Literal["best_effort", "reliable"] = "best_effort"
    target_delivery_ratio: float = Field(0.99, gt=0, le=1)
    max_retx: int = Field(3, ge=0, le=16)
    min_rto_ms: float = Field(40.0, gt=0)


class FlowConfig(StrictModel):
    id: str
    kind: FlowKind
    src: str
    dst: str = Field(..., description="node id, 'placement' (inference) or 'service:<id>'")
    size: SizeConfig = Field(default_factory=SizeConfig)
    arrival: ArrivalConfig
    start_s: float = Field(0.0, ge=0)
    duration_s: float | None = Field(None, gt=0)
    priority: int = Field(4, ge=0, le=7, description="0 = most urgent")
    deadline_ms: float | None = Field(None, gt=0)
    reliability: ReliabilityConfig = Field(default_factory=ReliabilityConfig)
    max_rate_mbps: float = Field(..., gt=0, description="hard ceiling on this flow's wire rate")
    min_rate_mbps: float = Field(0.1, gt=0)
    rate_adaptive: bool = True
    app_adaptive: bool = False
    weight: float | None = Field(None, gt=0)
    send_buffer_bytes: int = Field(2_000_000, ge=1)
    response_size: SizeConfig | None = None
    server_time_ms: float = Field(0.0, ge=0)
    work_gop: float | None = Field(None, gt=0)
    file_bytes: int | None = Field(None, ge=1)
    chunk_bytes: int = Field(1_000_000, ge=1, description="file_transfer: object/chunk size")
    timeout_ms: float | None = Field(None, gt=0)

    @model_validator(mode="after")
    def _check(self) -> "FlowConfig":
        if self.min_rate_mbps > self.max_rate_mbps:
            raise ValueError(f"flow {self.id}: min_rate_mbps > max_rate_mbps")
        if self.kind == "inference" and self.work_gop is None:
            raise ValueError(f"flow {self.id}: inference flows need work_gop")
        if self.kind == "file_transfer" and self.file_bytes is None:
            raise ValueError(f"flow {self.id}: file_transfer flows need file_bytes")
        if self.kind in ("request_response", "inference") and self.response_size is None:
            raise ValueError(f"flow {self.id}: {self.kind} needs response_size")
        return self

    @property
    def effective_weight(self) -> float:
        return self.weight if self.weight is not None else float(8 - self.priority)


class ServiceConfig(StrictModel):
    """A migratable edge service (target of ``dst: service:<id>``)."""

    id: str
    host: str
    state_bytes: int = Field(1_000_000, ge=0)
    migration_downtime_ms: float = Field(20.0, ge=0)


# =============================================================================
# Scenarios and policies
# =============================================================================

EventKind = Literal[
    "capacity_scale",
    "capacity_set",
    "outage",
    "handover",
    "blockage",
    "compute_load",
    "migrate_service",
]


class ScenarioEvent(StrictModel):
    at_s: float = Field(..., ge=0)
    kind: EventKind
    target: str
    duration_s: float | None = Field(None, gt=0)
    factor: float | None = Field(None, ge=0)
    capacity_mbps: float | None = Field(None, ge=0)
    attenuation_db: float | None = Field(None, ge=0)
    interruption_ms: float | None = Field(None, ge=0)
    rate_jobs_per_s: float | None = Field(None, gt=0)
    work_gop: float | None = Field(None, gt=0)
    to: str | None = None
    note: str = ""

    @model_validator(mode="after")
    def _check(self) -> "ScenarioEvent":
        need = {
            "capacity_scale": "factor",
            "capacity_set": "capacity_mbps",
            "handover": "interruption_ms",
            "compute_load": "rate_jobs_per_s",
            "migrate_service": "to",
        }
        if self.kind in need and getattr(self, need[self.kind]) is None:
            raise ValueError(f"event {self.kind} requires '{need[self.kind]}'")
        if self.kind == "compute_load" and self.work_gop is None:
            raise ValueError("compute_load requires work_gop")
        if self.kind == "blockage" and self.attenuation_db is None and self.factor is None:
            raise ValueError("blockage requires attenuation_db (link_budget links) or factor")
        return self


class ScenarioConfig(StrictModel):
    id: str
    name: str
    description: str = ""
    events: list[ScenarioEvent] = Field(default_factory=list)
    extra_flows: list[FlowConfig] = Field(default_factory=list)
    disable_wireless_variation: bool = False


class RoutingParams(StrictModel):
    decision_interval_ms: float = Field(50.0, gt=0)
    hysteresis: float = Field(0.15, ge=0, lt=1)
    min_dwell_ms: float = Field(500.0, ge=0)
    switch_penalty_ms: float = Field(5.0, ge=0)
    switch_interrupt_ms: float = Field(2.0, ge=0, description="physical hold after a route switch")
    w_loss: float = Field(1.0, ge=0)
    w_occupancy: float = Field(1.0, ge=0)
    w_deadline: float = Field(1.0, ge=0)
    w_capacity: float = Field(1.0, ge=0)
    max_paths: int = Field(4, ge=1, le=16)


class AIMDParams(StrictModel):
    feedback_interval_ms: float = Field(50.0, gt=0)
    additive_increase_mbps_per_s: float = Field(5.0, gt=0)
    multiplicative_decrease: float = Field(0.7, gt=0, lt=1)
    loss_threshold: float = Field(0.02, ge=0, le=1)
    delay_threshold_ms: float = Field(30.0, gt=0)


class PlacementWeights(StrictModel):
    seconds_per_joule: float = Field(0.0, ge=0, description="latency-equivalent of 1 J (assumption)")
    seconds_per_currency_unit: float = Field(0.0, ge=0)


class PolicyConfig(StrictModel):
    id: str
    label: str
    routing: Literal["static", "least_delay", "adaptive"]
    routing_params: RoutingParams = Field(default_factory=RoutingParams)
    scheduling: Discipline | None = Field(None, description="override every link's discipline")
    placement: Literal["local", "nearest_edge", "cloud", "least_completion", "weighted"] = "nearest_edge"
    placement_weights: PlacementWeights = Field(default_factory=PlacementWeights)
    rate_control: Literal["fixed", "aimd"] = "fixed"
    aimd: AIMDParams = Field(default_factory=AIMDParams)


class ControlPlaneConfig(StrictModel):
    report_interval_ms: float = Field(100.0, gt=0)
    report_delay_ms: float = Field(20.0, ge=0)
    capacity_report_noise: float = Field(0.0, ge=0, description="relative sd of reported capacity")


class LimitsConfig(StrictModel):
    max_events: int = Field(40_000_000, gt=0)
    max_wall_s: float = Field(900.0, gt=0)
    max_packets: int = Field(5_000_000, gt=0)
    max_duration_s: float = Field(600.0, gt=0)


class ExperimentConfig(StrictModel):
    name: str
    description: str = ""
    mode: Literal["simulation"] = "simulation"
    duration_s: float = Field(..., gt=0)
    drain_s: float = Field(2.0, ge=0)
    sample_interval_ms: float = Field(50.0, gt=0)
    seeds: list[int] = Field(default_factory=lambda: [1])
    mtu_payload_bytes: int = Field(1200, ge=64, le=65_000)
    header_bytes: int = Field(64, ge=0, description="per-packet IP/UDP/VHF header bytes")
    starvation_fraction: float = Field(0.1, gt=0, lt=1)
    control_plane: ControlPlaneConfig = Field(default_factory=ControlPlaneConfig)
    limits: LimitsConfig = Field(default_factory=LimitsConfig)
    topology: TopologyConfig
    flows: list[FlowConfig]
    services: list[ServiceConfig] = Field(default_factory=list)
    scenarios: list[ScenarioConfig] = Field(default_factory=list)
    policies: list[PolicyConfig] = Field(default_factory=list)

    @model_validator(mode="after")
    def _check(self) -> "ExperimentConfig":
        if self.duration_s > self.limits.max_duration_s:
            raise ValueError("duration_s exceeds limits.max_duration_s")
        nodes = {n.id for n in self.topology.nodes}
        links = {lk.id for lk in self.topology.links}
        svcs = {s.id for s in self.services}
        for s in self.services:
            if s.host not in nodes:
                raise ValueError(f"service {s.id} hosted on unknown node {s.host}")
        all_flows = list(self.flows) + [f for sc in self.scenarios for f in sc.extra_flows]
        fids = [f.id for f in self.flows]
        if len(set(fids)) != len(fids):
            raise ValueError("duplicate flow ids")
        for f in all_flows:
            if f.src not in nodes:
                raise ValueError(f"flow {f.id}: unknown src {f.src}")
            if f.dst == "placement":
                if f.kind != "inference":
                    raise ValueError(f"flow {f.id}: dst=placement only valid for inference flows")
            elif f.dst.startswith("service:"):
                if f.dst.split(":", 1)[1] not in svcs:
                    raise ValueError(f"flow {f.id}: unknown service {f.dst}")
            elif f.dst not in nodes:
                raise ValueError(f"flow {f.id}: unknown dst {f.dst}")
        for sc in self.scenarios:
            for ev in sc.events:
                if ev.kind in ("capacity_scale", "capacity_set", "outage", "handover", "blockage"):
                    if ev.target not in links:
                        raise ValueError(f"scenario {sc.id}: event targets unknown link {ev.target}")
                elif ev.kind == "compute_load":
                    if ev.target not in nodes:
                        raise ValueError(f"scenario {sc.id}: compute_load on unknown node {ev.target}")
                elif ev.kind == "migrate_service":
                    if ev.target not in svcs or ev.to not in nodes:
                        raise ValueError(f"scenario {sc.id}: bad migrate_service event")
        pids = [p.id for p in self.policies]
        if len(set(pids)) != len(pids):
            raise ValueError("duplicate policy ids")
        return self

    def scenario(self, sid: str) -> ScenarioConfig:
        for s in self.scenarios:
            if s.id == sid:
                return s
        if sid == "baseline" and not self.scenarios:
            return ScenarioConfig(id="baseline", name="Baseline")
        raise KeyError(f"unknown scenario {sid}")

    def policy(self, pid: str) -> PolicyConfig:
        for p in self.policies:
            if p.id == pid:
                return p
        raise KeyError(f"unknown policy {pid}")


# =============================================================================
# Live test (real sockets) -- bounded and explicitly authorised
# =============================================================================


class LiveEndpoint(StrictModel):
    host: str = Field(..., description="IP literal or hostname listed explicitly in config")
    port: int = Field(..., ge=0, le=65535, description="0 = ephemeral; only with a locally spawned loopback server")


class LiveFlow(StrictModel):
    id: str
    pattern: Literal["constant_rate", "bursty", "request_response"]
    payload_bytes: int = Field(1200, ge=1, le=60_000)
    rate_mbps: float = Field(10.0, gt=0, description="target offered rate (payload)")
    duration_s: float = Field(5.0, gt=0)
    response_bytes: int = Field(64, ge=0, le=1_000_000)
    concurrency: int = Field(8, ge=1, le=1024, description="max outstanding requests")
    on_s: float = Field(0.2, gt=0)
    off_s: float = Field(0.2, gt=0)
    timeout_ms: float = Field(1000.0, gt=0)
    deadline_ms: float | None = Field(None, gt=0)


class UDPParams(StrictModel):
    feedback_interval_ms: float = Field(20.0, gt=0)
    adaptive: bool = True
    aimd: AIMDParams = Field(default_factory=AIMDParams)
    experimental_reliability: bool = Field(False, description="EXPERIMENTAL NACK retransmission")
    max_retx: int = Field(2, ge=0, le=8)
    retx_buffer_packets: int = Field(4096, ge=0, le=1_000_000)
    drain_s: float = Field(0.5, ge=0, le=10)


class LiveTestConfig(StrictModel):
    name: str
    mode: Literal["live"] = "live"
    transport: Literal["tcp", "udp", "quic"]
    endpoint: LiveEndpoint
    authorised: bool = Field(False, description="must be true for any non-loopback endpoint")
    authorisation_note: str | None = None
    allowed_networks: list[str] = Field(default_factory=list, description="CIDRs beyond loopback")
    max_duration_s: float = Field(30.0, gt=0, le=LIVE_HARD_MAX_DURATION_S)
    rate_ceiling_mbps: float = Field(200.0, gt=0, le=LIVE_HARD_MAX_RATE_MBPS)
    max_total_bytes: int = Field(2 * 1024**3, gt=0, le=LIVE_HARD_MAX_TOTAL_BYTES)
    clock_sync: Literal["same_host", "ptp", "ntp", "none"] = "same_host"
    clock_error_bound_ms: float | None = Field(None, gt=0)
    tls: bool = Field(False, description="TCP only: wrap in TLS via Python's ssl module")
    flows: list[LiveFlow]
    udp: UDPParams = Field(default_factory=UDPParams)

    @model_validator(mode="after")
    def _check(self) -> "LiveTestConfig":
        total = 0.0
        for f in self.flows:
            if f.duration_s > self.max_duration_s:
                raise ValueError(f"live flow {f.id}: duration exceeds max_duration_s")
            if f.rate_mbps > self.rate_ceiling_mbps:
                raise ValueError(f"live flow {f.id}: rate exceeds rate_ceiling_mbps")
            total += f.rate_mbps
        if total > self.rate_ceiling_mbps:
            raise ValueError("sum of live flow rates exceeds rate_ceiling_mbps")
        if self.allowed_networks and not self.authorised:
            raise ValueError("allowed_networks requires authorised: true")
        if self.authorised and not self.authorisation_note:
            raise ValueError("authorised: true requires an authorisation_note")
        if self.clock_sync in ("ptp", "ntp") and self.clock_error_bound_ms is None:
            raise ValueError("ptp/ntp clock_sync requires clock_error_bound_ms")
        return self


# =============================================================================
# Loading
# =============================================================================


def _read_yaml(path: Path) -> Any:
    with open(path, encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def _resolve_includes(data: dict[str, Any], base: Path) -> dict[str, Any]:
    out = dict(data)
    if "topology_file" in out:
        out["topology"] = _read_yaml(base / out.pop("topology_file"))
    if "workload_file" in out:
        wl = _read_yaml(base / out.pop("workload_file"))
        out.setdefault("flows", wl.get("flows", []))
        out.setdefault("services", wl.get("services", []))
    if "scenarios_file" in out:
        out["scenarios"] = _read_yaml(base / out.pop("scenarios_file"))["scenarios"]
    if "policies_file" in out:
        out["policies"] = _read_yaml(base / out.pop("policies_file"))["policies"]
    return out


def load_experiment(path: str | Path, **overrides: Any) -> ExperimentConfig:
    path = Path(path)
    data = _read_yaml(path)
    if "experiment" in data:
        data = data["experiment"]
    data = _resolve_includes(data, path.parent)
    data.update({k: v for k, v in overrides.items() if v is not None})
    return ExperimentConfig.model_validate(data)


def load_live(path: str | Path) -> LiveTestConfig:
    data = _read_yaml(Path(path))
    if "live" in data:
        data = data["live"]
    return LiveTestConfig.model_validate(data)


def finite_or_none(x: float) -> float | None:
    return None if (x is None or not math.isfinite(x)) else float(x)
