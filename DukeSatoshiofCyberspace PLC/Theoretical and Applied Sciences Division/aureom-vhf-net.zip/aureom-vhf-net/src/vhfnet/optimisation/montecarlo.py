"""Monte Carlo propagation of uncertain link conditions.

Reports always include: draw count, seed, outcome quantiles, Monte Carlo standard
errors (mean: sd/sqrt(N); quantiles: batch means over 20 batches), the model's
assumptions, and sensitivity of the outcome to each uncertain input (Spearman
rank correlation and a one-at-a-time p10/p90 swing).

The default analytic path model is deliberately simple and separate from the
discrete-event simulator; use it for fast what-if exploration and uncertainty
budgeting, and use the simulator for dynamics.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable

import numpy as np
from scipy import stats


@dataclass(frozen=True)
class UncertainInput:
    name: str
    dist: str  # fixed | uniform | normal | lognormal | beta | triangular
    params: tuple[float, ...]
    unit: str = ""
    description: str = ""

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        p = self.params
        if self.dist == "fixed":
            return np.full(n, p[0], dtype=float)
        if self.dist == "uniform":
            return rng.uniform(p[0], p[1], n)
        if self.dist == "normal":
            return rng.normal(p[0], p[1], n)
        if self.dist == "lognormal":  # (median, sigma_log)
            return rng.lognormal(math.log(p[0]), p[1], n)
        if self.dist == "beta":
            return rng.beta(p[0], p[1], n)
        if self.dist == "triangular":
            return rng.triangular(p[0], p[1], p[2], n)
        raise ValueError(self.dist)

    def quantile(self, q: float) -> float:
        p = self.params
        if self.dist == "fixed":
            return p[0]
        if self.dist == "uniform":
            return p[0] + q * (p[1] - p[0])
        if self.dist == "normal":
            return float(stats.norm.ppf(q, p[0], p[1]))
        if self.dist == "lognormal":
            return float(p[0] * math.exp(p[1] * stats.norm.ppf(q)))
        if self.dist == "beta":
            return float(stats.beta.ppf(q, p[0], p[1]))
        if self.dist == "triangular":
            a, c, b = p
            return float(stats.triang.ppf(q, (c - a) / (b - a), loc=a, scale=b - a))
        raise ValueError(self.dist)


@dataclass
class MonteCarloResult:
    outcome: str
    unit: str
    draws: int
    seed: int
    mean: float
    sd: float
    mcse_mean: float
    quantiles: dict
    mcse_quantiles: dict
    exceedance: dict
    sensitivity: list
    assumptions: list
    inputs: list
    nonfinite_fraction: float
    samples_preview: list = field(default_factory=list)
    note: str = "JSON null in quantiles/MCSE means +inf (outcome unbounded, e.g. unstable queue, in that tail)"

    def to_dict(self) -> dict:
        return dict(self.__dict__)


def run_monte_carlo(inputs: list[UncertainInput], model: Callable[[dict[str, np.ndarray]], np.ndarray], *,
                    draws: int = 20000, seed: int = 0, outcome: str = "outcome", unit: str = "",
                    thresholds: list[float] | None = None, assumptions: list[str] | None = None,
                    qs=(5, 25, 50, 75, 95, 99), batches: int = 20) -> MonteCarloResult:
    if draws < batches * 10:
        raise ValueError("draws too small for batch-means MCSE")
    rng = np.random.default_rng(seed)
    X = {inp.name: inp.sample(draws, rng) for inp in inputs}
    y = np.asarray(model(X), dtype=float)
    finite = np.isfinite(y)
    nonfinite = 1.0 - finite.mean()
    yq = np.where(finite, y, np.inf)  # unstable/infinite outcomes stay in quantiles as +inf
    mean = float(y[finite].mean()) if finite.any() else math.inf
    sd = float(y[finite].std(ddof=1)) if finite.sum() > 1 else math.nan
    # 'inverted_cdf' picks an actual draw, so +inf (unstable) draws propagate into upper quantiles
    quant = {f"p{q}": float(np.percentile(yq, q, method="inverted_cdf")) for q in qs}
    bsz = draws // batches
    bq = np.array([[np.percentile(yq[i * bsz:(i + 1) * bsz], q, method="inverted_cdf") for q in qs]
                   for i in range(batches)])
    with np.errstate(invalid="ignore"):
        mcse_q = {}
        for j, q in enumerate(qs):
            col = bq[:, j]
            mcse_q[f"p{q}"] = float(np.std(col, ddof=1) / math.sqrt(batches)) if np.all(np.isfinite(col)) else math.inf
    exc = {}
    for t in thresholds or []:
        p = float(np.mean(yq > t))
        exc[str(t)] = {"prob": p, "mcse": math.sqrt(p * (1 - p) / draws)}
    sens = []
    med = {inp.name: inp.quantile(0.5) for inp in inputs}
    for inp in inputs:
        if inp.dist == "fixed":
            continue
        rho = stats.spearmanr(X[inp.name], np.where(finite, y, np.nanmax(y[finite]) * 10 if finite.any() else 0)).statistic
        lo_in = {k: np.array([v]) for k, v in med.items()}
        hi_in = dict(lo_in)
        lo_in[inp.name] = np.array([inp.quantile(0.1)])
        hi_in[inp.name] = np.array([inp.quantile(0.9)])
        y_lo, y_hi = float(model(lo_in)[0]), float(model(hi_in)[0])
        sens.append({"input": inp.name, "spearman_rho": float(rho), "output_at_p10": y_lo, "output_at_p90": y_hi,
                     "swing": (y_hi - y_lo) if math.isfinite(y_hi) and math.isfinite(y_lo) else math.inf})
    sens.sort(key=lambda s: -abs(s["swing"]) if math.isfinite(s["swing"]) else -math.inf)
    return MonteCarloResult(
        outcome=outcome, unit=unit, draws=draws, seed=seed, mean=mean, sd=sd,
        mcse_mean=sd / math.sqrt(finite.sum()) if finite.sum() > 1 else math.nan,
        quantiles=quant, mcse_quantiles=mcse_q, exceedance=exc, sensitivity=sens,
        assumptions=list(assumptions or []),
        inputs=[{"name": i.name, "dist": i.dist, "params": list(i.params), "unit": i.unit,
                 "description": i.description} for i in inputs],
        nonfinite_fraction=float(nonfinite),
        samples_preview=np.sort(yq)[:: max(1, draws // 400)].tolist(),
    )


# ---------------------------------------------------------------------------
# Analytic path model (M/M/1 per link -- an explicit, conservative assumption)
# ---------------------------------------------------------------------------

PATH_MODEL_ASSUMPTIONS = [
    "Each link is an independent M/M/1 queue (Poisson arrivals, exponential service) - conservative for paced traffic.",
    "Message latency = sum over links of (propagation + serialisation of the message + mean waiting time).",
    "Utilisation >= 1 is unstable: latency is +inf and counted as a deadline miss.",
    "Loss adds one retransmission timeout (rto_s) with probability 1-(1-p)^n_packets.",
    "Inputs are sampled independently (no correlation between links unless encoded in the model).",
]


def path_latency_model(n_links: int, message_bytes: float, packet_bytes: float = 1264.0, rto_s: float = 0.2):
    """Return a vectorised model(X) -> message latency (s) for inputs named
    cap_i (bit/s), load_i (bit/s), prop_i (s), loss_i (probability), i = 0..n_links-1."""

    def model(X: dict[str, np.ndarray]) -> np.ndarray:
        n = len(next(iter(X.values())))
        lat = np.zeros(n)
        ok = np.ones(n)
        npk = max(1.0, math.ceil(message_bytes / packet_bytes))
        for i in range(n_links):
            cap = X[f"cap_{i}"]
            load = X[f"load_{i}"]
            prop = X[f"prop_{i}"]
            loss = X.get(f"loss_{i}", np.zeros(n))
            rho = load / cap
            mu = cap / (packet_bytes * 8)
            with np.errstate(divide="ignore", invalid="ignore"):
                wait = np.where(rho < 1, rho / (mu * (1 - rho)), np.inf)
            lat = lat + prop + message_bytes * 8 / cap + wait
            ok = ok * (1 - loss) ** npk
        return lat + (1 - ok) * rto_s

    return model


def deadline_miss_probability_mm1(X: dict[str, np.ndarray], n_links: int, deadline_s: float,
                                  packet_bytes: float = 1264.0) -> np.ndarray:
    """Per-draw P(sum of M/M/1 sojourn times + prop > deadline), sojourns approximated by the
    slowest link's exponential tail (an upper-bound style approximation)."""
    n = len(next(iter(X.values())))
    prop = np.zeros(n)
    rate = np.full(n, np.inf)
    for i in range(n_links):
        cap, load = X[f"cap_{i}"], X[f"load_{i}"]
        mu = cap / (packet_bytes * 8)
        lam = load / (packet_bytes * 8)
        rate = np.minimum(rate, mu - lam)
        prop = prop + X[f"prop_{i}"]
    slack = deadline_s - prop
    with np.errstate(over="ignore", invalid="ignore"):
        p = np.where(rate <= 0, 1.0, np.where(slack <= 0, 1.0, np.minimum(1.0, n_links * np.exp(-rate * slack))))
    return p


def seed_summary(values) -> dict:
    """Summary of a metric across repeated seeded simulation runs."""
    v = np.asarray([x for x in values if x is not None and np.isfinite(x)], dtype=float)
    n = v.size
    if n == 0:
        return {"n": 0, "mean": None, "sd": None, "mcse": None, "p10": None, "p50": None, "p90": None}
    sd = float(v.std(ddof=1)) if n > 1 else 0.0
    return {"n": int(n), "mean": float(v.mean()), "sd": sd, "mcse": sd / math.sqrt(n) if n > 1 else None,
            "p10": float(np.percentile(v, 10)), "p50": float(np.percentile(v, 50)), "p90": float(np.percentile(v, 90)),
            "min": float(v.min()), "max": float(v.max())}
