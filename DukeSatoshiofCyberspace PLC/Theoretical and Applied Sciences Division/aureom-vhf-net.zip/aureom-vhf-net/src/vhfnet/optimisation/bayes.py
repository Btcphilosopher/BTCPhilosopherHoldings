"""Bayesian monitoring of binary network outcomes (loss, deadline miss).

These functions are independent of the simulator: they take observations (from a
simulation export or a live test) and return posteriors with stated assumptions.

Binary outcome definitions (choose one explicitly):
* packet loss      : 1 if a sent sequence number was never delivered, else 0
* deadline miss    : 1 if a message/request did not complete by its deadline
                     (late, lost, rejected and timed-out all count), else 0

Independence vs dependence
--------------------------
The plain Beta-Bernoulli update assumes exchangeable, independent outcomes.
Network outcomes are usually *correlated in time* (loss bursts, congestion
episodes), so the plain posterior is over-confident. Two dependence-aware
alternatives are provided:

1. ``method="ess"``: discount the likelihood by n_eff / n (a power-likelihood
   approximation), where n_eff is the effective sample size from the series'
   autocorrelation (Geyer initial-positive-sequence estimator).
2. ``method="blocks"``: treat non-overlapping blocks (time windows) as the
   observation unit: each block contributes its event *fraction* with weight
   chosen so the posterior variance matches the between-block variance
   (batch means). Use when windows are long relative to correlation time.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy import stats


@dataclass(frozen=True)
class BetaPosterior:
    a: float
    b: float
    n_obs: float = 0.0
    n_effective: float = 0.0
    method: str = "independent"

    @property
    def mean(self) -> float:
        return self.a / (self.a + self.b)

    @property
    def sd(self) -> float:
        a, b = self.a, self.b
        return math.sqrt(a * b / ((a + b) ** 2 * (a + b + 1)))

    def interval(self, level: float = 0.95) -> tuple[float, float]:
        lo = (1 - level) / 2
        return float(stats.beta.ppf(lo, self.a, self.b)), float(stats.beta.ppf(1 - lo, self.a, self.b))

    def prob_greater(self, threshold: float) -> float:
        return float(stats.beta.sf(threshold, self.a, self.b))

    def update(self, events: float, trials: float) -> "BetaPosterior":
        return BetaPosterior(self.a + events, self.b + trials - events, self.n_obs + trials,
                             self.n_effective + trials, self.method)

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        return rng.beta(self.a, self.b, size=n)

    def to_dict(self, level: float = 0.95, threshold: float | None = None) -> dict:
        lo, hi = self.interval(level)
        d = {"alpha": self.a, "beta": self.b, "mean": self.mean, "sd": self.sd,
             f"ci{int(level*100)}": [lo, hi], "n_obs": self.n_obs, "n_effective": self.n_effective,
             "method": self.method}
        if threshold is not None:
            d["prob_exceeds_threshold"] = self.prob_greater(threshold)
            d["threshold"] = threshold
        return d


def autocorrelation(x: np.ndarray, max_lag: int | None = None) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    n = x.size
    if n < 2 or np.var(x) == 0:
        return np.ones(1)
    max_lag = min(n - 1, max_lag or min(n - 1, 2000))
    xc = x - x.mean()
    f = np.fft.rfft(xc, n=2 * n)
    acf = np.fft.irfft(f * np.conj(f))[: max_lag + 1]
    return acf / acf[0]


def effective_sample_size(x) -> float:
    """Geyer's initial positive sequence estimator: n / (1 + 2 sum rho_k)."""
    x = np.asarray(x, dtype=float)
    n = x.size
    if n < 4 or np.var(x) == 0:
        return float(n)
    rho = autocorrelation(x)
    s = 0.0
    k = 1
    while k + 1 < rho.size:
        pair = rho[k] + rho[k + 1]
        if pair <= 0:
            break
        s += pair
        k += 2
    tau = max(1.0, 1.0 + 2.0 * s)
    return float(n / tau)


def beta_bernoulli(outcomes, prior: tuple[float, float] = (1.0, 1.0), method: str = "independent",
                   block_size: int | None = None) -> BetaPosterior:
    """Posterior for P(event) from a binary series (1 = event).

    ``method``: ``independent`` (plain conjugate update), ``ess`` (autocorrelation
    discount) or ``blocks`` (batch means over blocks of ``block_size``).
    """
    x = np.asarray(outcomes, dtype=float)
    n = float(x.size)
    k = float(x.sum())
    a0, b0 = prior
    if method == "independent" or n == 0:
        return BetaPosterior(a0 + k, b0 + n - k, n, n, "independent")
    if method == "ess":
        ne = effective_sample_size(x)
        w = ne / n
        return BetaPosterior(a0 + k * w, b0 + (n - k) * w, n, ne, "ess")
    if method == "blocks":
        bs = block_size or max(1, int(round(n / max(effective_sample_size(x), 1.0))) * 2)
        nb = int(n // bs)
        if nb < 2:
            return beta_bernoulli(x, prior, "ess")
        fr = x[: nb * bs].reshape(nb, bs).mean(axis=1)
        p = fr.mean()
        v = fr.var(ddof=1) / nb
        if v <= 0 or p <= 0 or p >= 1:
            # no between-block variation: fall back to one observation per block
            return BetaPosterior(a0 + p * nb, b0 + (1 - p) * nb, n, float(nb), "blocks")
        conc = p * (1 - p) / v - 1  # moment-matched concentration
        conc = max(conc, 1.0)
        return BetaPosterior(a0 + p * conc, b0 + (1 - p) * conc, n, float(conc), f"blocks(size={bs})")
    raise ValueError(method)


def windowed_rates(times, outcomes, window_s: float, t0: float | None = None, t1: float | None = None) -> dict:
    """Event rate per time window (for correlated outcomes: inspect instead of pooling)."""
    t = np.asarray(times, dtype=float)
    x = np.asarray(outcomes, dtype=float)
    if t.size == 0:
        return {"window_s": window_s, "t": [], "rate": [], "n": []}
    t0 = t.min() if t0 is None else t0
    t1 = t.max() if t1 is None else t1
    edges = np.arange(t0, t1 + window_s, window_s)
    idx = np.clip(np.digitize(t, edges) - 1, 0, len(edges) - 2)
    n = np.bincount(idx, minlength=len(edges) - 1)
    k = np.bincount(idx, weights=x, minlength=len(edges) - 1)
    with np.errstate(invalid="ignore", divide="ignore"):
        rate = np.where(n > 0, k / np.maximum(n, 1), np.nan)
    return {"window_s": window_s, "t": edges[:-1].tolist(), "rate": rate.tolist(), "n": n.tolist()}


def block_bootstrap_ci(outcomes, block: int, n_boot: int = 2000, level: float = 0.95, seed: int = 0) -> dict:
    """Moving-block bootstrap CI for the event rate of a correlated binary series."""
    x = np.asarray(outcomes, dtype=float)
    n = x.size
    if n == 0:
        return {"mean": None, "ci": [None, None]}
    rng = np.random.default_rng(seed)
    block = max(1, min(block, n))
    nb = int(math.ceil(n / block))
    starts = rng.integers(0, n - block + 1, size=(n_boot, nb))
    csum = np.concatenate([[0.0], np.cumsum(x)])
    sums = (csum[starts + block] - csum[starts]).sum(axis=1)
    rates = sums / (nb * block)
    lo = (1 - level) / 2
    return {"mean": float(x.mean()), "ci": [float(np.quantile(rates, lo)), float(np.quantile(rates, 1 - lo))],
            "block": block, "n_boot": n_boot, "seed": seed}


def deadline_miss_posterior(latencies_s, deadline_s: float, failures: int = 0, prior=(1.0, 1.0),
                            method: str = "ess") -> BetaPosterior:
    """Deadline-miss probability; ``failures`` (timeouts/rejections) count as misses, never dropped."""
    lat = np.asarray(latencies_s, dtype=float)
    miss = np.concatenate([(~np.isfinite(lat)) | (lat > deadline_s), np.ones(int(failures), dtype=bool)])
    return beta_bernoulli(miss.astype(float), prior, method)


def compare_routes(post_a: BetaPosterior, post_b: BetaPosterior, draws: int = 20000, seed: int = 0) -> dict:
    """P(route A has the lower event probability) by Monte Carlo from both posteriors."""
    rng = np.random.default_rng(seed)
    pa, pb = post_a.sample(draws, rng), post_b.sample(draws, rng)
    d = pa - pb
    better = (pa < pb).astype(float)
    p = better.mean()
    return {"prob_a_lower": float(p), "mcse": float(math.sqrt(p * (1 - p) / draws)),
            "diff_mean": float(d.mean()), "diff_ci95": [float(np.quantile(d, 0.025)), float(np.quantile(d, 0.975))],
            "draws": draws, "seed": seed,
            "assumption": "posteriors treated as independent between routes"}


def value_of_information(post_a: BetaPosterior, post_b: BetaPosterior, n_extra: int, future_messages: float,
                         cost_per_measurement: float = 0.0, draws: int = 20000, seed: int = 0) -> dict:
    """Is it worth taking ``n_extra`` more (effective) observations on each route
    before committing ``future_messages`` messages to one of them?

    Loss function: expected number of events (e.g. deadline misses) among future
    messages on the chosen route. EVPI bounds the value of any measurement; EVSI is
    the expected reduction from ``n_extra`` observations per route (preposterior
    analysis by simulation). With correlated observations, ``n_extra`` should be an
    *effective* sample size, not a raw packet count.
    """
    rng = np.random.default_rng(seed)
    pa, pb = post_a.sample(draws, rng), post_b.sample(draws, rng)
    now = min(post_a.mean, post_b.mean)
    evpi = now - np.minimum(pa, pb).mean()
    ka = rng.binomial(n_extra, pa)
    kb = rng.binomial(n_extra, pb)
    ma = (post_a.a + ka) / (post_a.a + post_a.b + n_extra)
    mb = (post_b.a + kb) / (post_b.a + post_b.b + n_extra)
    chosen = np.where(ma <= mb, pa, pb)
    evsi = now - chosen.mean()
    evsi_total = evsi * future_messages
    cost = cost_per_measurement * 2 * n_extra
    return {
        "current_choice": "A" if post_a.mean <= post_b.mean else "B",
        "expected_event_rate_now": now,
        "evpi_per_message": float(evpi),
        "evsi_per_message": float(evsi),
        "evsi_total_events_avoided": float(evsi_total),
        "measurement_cost": cost,
        "recommend_more_measurements": bool(evsi_total > cost),
        "n_extra_per_route": n_extra,
        "draws": draws,
        "seed": seed,
    }
