"""Bounded, feedback-driven sending-rate adaptation (shared by SIMULATION and LIVE TEST).

``BoundedAIMD`` is a deliberately simple reference controller:

* additive increase of ``ai_bps_per_s`` while feedback shows no congestion,
* multiplicative decrease by ``md`` when the interval loss fraction exceeds
  ``loss_threshold`` *or* the RTT exceeds the minimum observed RTT by more than
  ``delay_threshold_s``; at most one decrease per smoothed RTT,
* the rate is ALWAYS clamped to ``[min_bps, max_bps]`` -- the configured ceiling
  can never be exceeded, whatever the feedback says.

It is not a replacement for production congestion control (BBR, CUBIC, ...).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field


@dataclass
class RTTEstimator:
    """RFC 6298-style smoothed RTT and variance."""

    srtt: float = math.nan
    rttvar: float = math.nan
    min_rtt: float = math.inf
    latest: float = math.nan
    samples: int = 0

    def update(self, rtt: float) -> None:
        if not (rtt >= 0) or math.isinf(rtt):
            return
        self.latest = rtt
        self.min_rtt = min(self.min_rtt, rtt)
        if self.samples == 0:
            self.srtt, self.rttvar = rtt, rtt / 2
        else:
            self.rttvar = 0.75 * self.rttvar + 0.25 * abs(self.srtt - rtt)
            self.srtt = 0.875 * self.srtt + 0.125 * rtt
        self.samples += 1

    def rto(self, min_rto: float, extra: float = 0.0) -> float:
        if self.samples == 0:
            return max(min_rto, 0.2) + extra
        return max(min_rto, self.srtt + 4 * self.rttvar) + extra


@dataclass
class BoundedAIMD:
    min_bps: float
    max_bps: float
    rate_bps: float
    ai_bps_per_s: float
    md: float = 0.7
    loss_threshold: float = 0.02
    delay_threshold_s: float = 0.03
    last_update_t: float = 0.0
    last_decrease_t: float = -math.inf
    decreases: int = 0
    history: list[tuple[float, float]] = field(default_factory=list)
    max_history: int = 20_000

    def __post_init__(self) -> None:
        if self.min_bps <= 0 or self.max_bps < self.min_bps:
            raise ValueError("require 0 < min_bps <= max_bps")
        self.rate_bps = min(max(self.rate_bps, self.min_bps), self.max_bps)

    def on_feedback(self, now: float, loss_fraction: float, rtt_s: float, min_rtt_s: float,
                    srtt_s: float | None = None) -> float:
        dt = max(0.0, now - self.last_update_t)
        self.last_update_t = now
        congested = loss_fraction > self.loss_threshold or (
            math.isfinite(rtt_s) and math.isfinite(min_rtt_s) and rtt_s - min_rtt_s > self.delay_threshold_s)
        guard = srtt_s if (srtt_s is not None and math.isfinite(srtt_s)) else 0.0
        if congested:
            if now - self.last_decrease_t >= guard:
                self.rate_bps *= self.md
                self.last_decrease_t = now
                self.decreases += 1
        else:
            self.rate_bps += self.ai_bps_per_s * dt
        self.rate_bps = min(max(self.rate_bps, self.min_bps), self.max_bps)
        if len(self.history) < self.max_history:
            self.history.append((now, self.rate_bps))
        return self.rate_bps


class FixedRate:
    """No adaptation: always the configured ceiling."""

    def __init__(self, rate_bps: float) -> None:
        self.rate_bps = rate_bps
        self.max_bps = rate_bps
        self.decreases = 0
        self.history: list[tuple[float, float]] = []

    def on_feedback(self, now, loss_fraction, rtt_s, min_rtt_s, srtt_s=None) -> float:
        return self.rate_bps
