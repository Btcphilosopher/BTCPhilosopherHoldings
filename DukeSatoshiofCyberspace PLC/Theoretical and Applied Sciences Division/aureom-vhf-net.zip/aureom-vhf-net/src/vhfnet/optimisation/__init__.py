"""Inference and optimisation tools, independent of the simulator:
Beta-Bernoulli monitoring, dependence-aware variants, Monte Carlo propagation,
value of information, and bounded rate control."""

from .bayes import (BetaPosterior, beta_bernoulli, block_bootstrap_ci, compare_routes, deadline_miss_posterior,
                    effective_sample_size, value_of_information, windowed_rates)
from .montecarlo import (PATH_MODEL_ASSUMPTIONS, UncertainInput, path_latency_model, run_monte_carlo,
                         seed_summary)
from .rate_control import BoundedAIMD, FixedRate, RTTEstimator

__all__ = ["BetaPosterior", "beta_bernoulli", "block_bootstrap_ci", "compare_routes", "deadline_miss_posterior",
           "effective_sample_size", "value_of_information", "windowed_rates", "PATH_MODEL_ASSUMPTIONS",
           "UncertainInput", "path_latency_model", "run_monte_carlo", "seed_summary", "BoundedAIMD", "FixedRate",
           "RTTEstimator"]
