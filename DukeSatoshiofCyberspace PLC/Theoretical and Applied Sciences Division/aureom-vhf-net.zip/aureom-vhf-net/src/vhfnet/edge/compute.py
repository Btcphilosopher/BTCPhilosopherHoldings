"""Compute servers with explicit cores and a bounded FIFO job queue (virtual time)."""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field
from typing import Callable

from ..config import ComputeConfig


@dataclass
class Job:
    job_id: int
    node: str
    work_gop: float
    arrival_t: float
    background: bool = False
    flow_idx: int = -1
    request_id: int = -1
    start_t: float = math.nan
    end_t: float = math.nan
    rejected: bool = False
    on_done: Callable[["Job"], None] | None = field(default=None, repr=False)

    @property
    def wait_s(self) -> float:
        return self.start_t - self.arrival_t

    @property
    def service_s(self) -> float:
        return self.end_t - self.start_t


class ComputeServer:
    def __init__(self, env, node_id: str, cfg: ComputeConfig) -> None:
        self.env = env
        self.node = node_id
        self.cfg = cfg
        self.cores = cfg.cores
        self.busy = 0
        self.queue: deque[Job] = deque()
        self.busy_area = 0.0
        self.q_area = 0.0
        self.last_t = 0.0
        self.completed = 0
        self.rejected = 0
        self.completed_bg = 0
        self.rejected_bg = 0
        self.q_max = 0
        self.samples: list[tuple[float, int, int]] = []

    def service_time(self, work_gop: float) -> float:
        return self.cfg.service_overhead_ms / 1e3 + work_gop / self.cfg.gops_per_core

    def _touch(self) -> None:
        now = self.env.now
        dt = now - self.last_t
        self.busy_area += self.busy * dt
        self.q_area += len(self.queue) * dt
        self.last_t = now

    def submit(self, job: Job) -> bool:
        self._touch()
        if self.busy < self.cores:
            self._start(job)
            return True
        if len(self.queue) < self.cfg.queue_limit:
            self.queue.append(job)
            self.q_max = max(self.q_max, len(self.queue))
            return True
        job.rejected = True
        if job.background:
            self.rejected_bg += 1
        else:
            self.rejected += 1
        return False

    def _start(self, job: Job) -> None:
        self.busy += 1
        job.start_t = self.env.now
        ev = self.env.timeout(self.service_time(job.work_gop), job)
        ev.callbacks.append(self._finish)

    def _finish(self, ev) -> None:
        job: Job = ev.value
        self._touch()
        self.busy -= 1
        job.end_t = self.env.now
        if job.background:
            self.completed_bg += 1
        else:
            self.completed += 1
        if self.queue:
            self._start(self.queue.popleft())
        if job.on_done is not None:
            job.on_done(job)

    def finish(self, horizon: float) -> dict:
        self._touch()
        busy_core_s = self.busy_area
        energy = self.cfg.idle_power_w * horizon + self.cfg.active_power_w_per_core * busy_core_s
        return {
            "node": self.node,
            "cores": self.cores,
            "gops_per_core": self.cfg.gops_per_core,
            "utilisation": busy_core_s / (self.cores * horizon) if horizon > 0 else 0.0,
            "queue_mean_jobs": self.q_area / horizon if horizon > 0 else 0.0,
            "queue_max_jobs": self.q_max,
            "queue_limit": self.cfg.queue_limit,
            "jobs_completed": self.completed,
            "jobs_rejected": self.rejected,
            "background_completed": self.completed_bg,
            "background_rejected": self.rejected_bg,
            "busy_core_seconds": busy_core_s,
            "energy_estimated_j": energy,
            "monetary_cost": busy_core_s * self.cfg.cost_per_core_s,
        }
