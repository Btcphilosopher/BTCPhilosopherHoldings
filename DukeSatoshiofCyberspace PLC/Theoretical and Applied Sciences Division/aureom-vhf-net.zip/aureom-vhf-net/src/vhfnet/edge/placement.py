"""Edge-compute placement: local vs edge vs cloud.

Total completion time = input transfer + waiting + processing + output transfer.

Nothing here assumes the edge is faster: a large upload over a weak access link,
an overloaded edge queue or a migration in progress all show up in the estimate
(and, in simulation, in the measured completion time).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy import special

from ..config import ComputeConfig, PlacementWeights

INF = math.inf


@dataclass(frozen=True)
class PlacementEstimate:
    node: str
    input_transfer_s: float
    wait_s: float
    processing_s: float
    output_transfer_s: float
    energy_j: float
    money: float

    @property
    def completion_s(self) -> float:
        return self.input_transfer_s + self.wait_s + self.processing_s + self.output_transfer_s

    def weighted_cost(self, w: PlacementWeights) -> float:
        return self.completion_s + w.seconds_per_joule * self.energy_j + w.seconds_per_currency_unit * self.money


def transfer_time_s(size_bytes: float, path_delay_s: float, bottleneck_bps: float, mtu_payload: int = 1200,
                    header_bytes: int = 64) -> float:
    """Approximate message transfer: path delay + wire bits / bottleneck rate."""
    if bottleneck_bps <= 0 or math.isinf(path_delay_s):
        return INF
    n = max(1, math.ceil(size_bytes / mtu_payload))
    return path_delay_s + (size_bytes + n * header_bytes) * 8 / bottleneck_bps


def queue_wait_estimate_s(queue_len: int, busy: int, cores: int, service_s: float) -> float:
    """Expected wait for a newly arriving job given the (reported) queue state,
    assuming FIFO and deterministic service of ``service_s``."""
    ahead = queue_len + busy - cores + 1
    if ahead <= 0:
        return 0.0
    return (ahead - 0.5) * service_s / cores


def erlang_c_wait_s(arrival_rate: float, service_s: float, cores: int) -> float:
    """Mean waiting time in M/M/c (Erlang C). INF if the system is unstable."""
    if arrival_rate <= 0:
        return 0.0
    mu = 1.0 / service_s
    a = arrival_rate / mu
    rho = a / cores
    if rho >= 1:
        return INF
    k = np.arange(cores)
    log_terms = k * math.log(a) - special.gammaln(k + 1)
    log_last = cores * math.log(a) - special.gammaln(cores + 1) - math.log(1 - rho)
    m = max(log_terms.max(), log_last)
    pc = math.exp(log_last - m) / (np.exp(log_terms - m).sum() + math.exp(log_last - m))
    return pc / (cores * mu - arrival_rate)


def analytic_placement(input_bytes: float, output_bytes: float, work_gop: float, candidates: list[dict],
                       weights: PlacementWeights | None = None) -> list[dict]:
    """Stand-alone what-if calculator used by the API/dashboard (no packet simulation).

    Each candidate: {node, compute: ComputeConfig-like dict, path_delay_s, bottleneck_bps,
    background_rate_jobs_per_s, background_work_gop, energy_per_bit_nj}. Waiting time uses
    an M/M/c approximation for the background load plus this job.
    """
    weights = weights or PlacementWeights()
    out = []
    for c in candidates:
        comp = ComputeConfig.model_validate(c["compute"])
        svc = comp.service_overhead_ms / 1e3 + work_gop / comp.gops_per_core
        bg_rate = c.get("background_rate_jobs_per_s", 0.0)
        bg_svc = comp.service_overhead_ms / 1e3 + c.get("background_work_gop", work_gop) / comp.gops_per_core
        local = c.get("local", False)
        up = 0.0 if local else transfer_time_s(input_bytes, c["path_delay_s"], c["bottleneck_bps"])
        down = 0.0 if local else transfer_time_s(output_bytes, c["path_delay_s"], c.get("bottleneck_down_bps", c["bottleneck_bps"]))
        wait = erlang_c_wait_s(bg_rate, bg_svc, comp.cores)
        epb = c.get("energy_per_bit_nj", 0.0)
        energy = (0 if local else (input_bytes + output_bytes) * 8 * epb * 1e-9) + comp.active_power_w_per_core * svc
        est = PlacementEstimate(c["node"], up, wait, svc, down, energy, svc * comp.cost_per_core_s)
        out.append({"node": c["node"], "input_transfer_s": up, "wait_s": wait, "processing_s": svc,
                    "output_transfer_s": down, "completion_s": est.completion_s, "energy_estimated_j": energy,
                    "money": est.money, "weighted_cost": est.weighted_cost(weights),
                    "utilisation": bg_rate * bg_svc / comp.cores})
    return sorted(out, key=lambda r: r["weighted_cost"])
