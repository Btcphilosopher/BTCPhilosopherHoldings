"""TLS material for *local* tests only, using established libraries.

VHF.NET never implements cryptography itself: TCP uses Python's ``ssl`` module
(OpenSSL) and QUIC uses ``aioquic`` (TLS 1.3). For loopback tests a throw-away
self-signed certificate for ``localhost``/127.0.0.1 is generated with the
``cryptography`` package. Do not reuse it beyond local testing.
"""

from __future__ import annotations

import datetime
import ipaddress
import ssl
import tempfile
from pathlib import Path


def self_signed_localhost(dirpath: str | None = None) -> tuple[str, str]:
    try:
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.x509.oid import NameOID
    except ImportError as e:  # pragma: no cover
        raise RuntimeError("TLS self-signed generation needs the 'cryptography' package") from e
    d = Path(dirpath or tempfile.mkdtemp(prefix="vhfnet-tls-"))
    key = ec.generate_private_key(ec.SECP256R1())
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "localhost")])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(now - datetime.timedelta(minutes=5))
            .not_valid_after(now + datetime.timedelta(days=1))
            .add_extension(x509.SubjectAlternativeName([x509.DNSName("localhost"),
                                                        x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]),
                           critical=False)
            .sign(key, hashes.SHA256()))
    cf, kf = d / "cert.pem", d / "key.pem"
    cf.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    kf.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                     serialization.NoEncryption()))
    return str(cf), str(kf)


def server_context(certfile: str, keyfile: str) -> ssl.SSLContext:
    ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(certfile, keyfile)
    return ctx


def client_context(cafile: str) -> ssl.SSLContext:
    ctx = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile=cafile)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    return ctx
