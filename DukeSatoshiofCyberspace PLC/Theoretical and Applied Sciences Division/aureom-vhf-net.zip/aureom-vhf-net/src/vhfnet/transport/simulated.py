"""Simulated transport adapter (SIMULATION mode, virtual time).

Implements, for one (sub)flow:

* fragmentation of application messages into MTU-sized packets with sequence
  numbers and timestamps,
* a bounded send buffer with explicit backpressure (messages that do not fit
  are *rejected* and counted, never silently dropped),
* pacing at the current rate, which is always <= the flow's ``max_rate_mbps``,
* per-destination congestion state (RTT estimator + rate controller), as a real
  transport keeps per-connection state: a flow whose requests are placed on
  different servers must not confuse one server's base RTT with congestion,
* optional EXPERIMENTAL ARQ (``reliability.mode = reliable``): time/packet-
  threshold loss detection and retransmission up to ``max_retx``; deadline-
  aware (no retransmission after the message deadline). This is NOT TCP/QUIC
  and does not inherit their guarantees,
* feedback processing (ack reports) for RTT estimation, rate adaptation and
  per-path observations for the router.

Accounting fields match the live adapters' ``TransportStats``.
"""

from __future__ import annotations

import math
from collections import defaultdict, deque
from typing import Callable

from ..optimisation.rate_control import RTTEstimator
from ..simulation.flowstate import FlowRuntime
from ..traffic.packet import Message, Packet

INF = math.inf


class _DestState:
    __slots__ = ("ctrl", "rtt", "largest_acked_sent_t", "largest_acked_seq")

    def __init__(self, ctrl) -> None:
        self.ctrl = ctrl
        self.rtt = RTTEstimator()
        self.largest_acked_sent_t = -INF
        self.largest_acked_seq = -1


def _key(route) -> str:
    return route if isinstance(route, str) else ">".join(route)


class SimulatedTransportAdapter:
    def __init__(self, env, fr: FlowRuntime, network, route_fn: Callable, mtu_payload: int, header_bytes: int,
                 controller_factory: Callable[[], object], feedback_interval_s: float, switch_hold_s: float,
                 observe_fn: Callable | None = None, buffer_bytes: int | None = None,
                 backlogged: bool = False) -> None:
        self.env = env
        self.fr = fr
        self.network = network
        self.route_fn = route_fn
        self.mtu = mtu_payload
        self.hdr = header_bytes
        self.factory = controller_factory
        self.fb_interval = feedback_interval_s
        self.switch_hold = switch_hold_s
        self.observe_fn = observe_fn
        self.buffer_bytes = buffer_bytes if buffer_bytes is not None else fr.cfg.send_buffer_bytes
        self.backlogged = backlogged
        self.backlog: deque[list] = deque()  # [msg, route, next_frag]
        self.backlog_bytes = 0
        self.retx_q: deque[list] = deque()
        self.outstanding: dict[int, list] = {}  # seq -> [sent_t, tx_count, msg_id, frag, payload, route, path, key]
        self.lost_seqs: set[int] = set()
        self.declared_seqs: set[int] = set()
        self._tx_counts: dict[int, int] = {}
        self.dest: dict[str, _DestState] = {}
        self.active_key: str | None = None
        self.next_seq = 0
        self.next_send_t = 0.0
        self.hold_until = 0.0
        self.last_path: dict = {}
        self.route_switch_holds = 0
        self._wake = None
        self.rate_samples: list[tuple[float, float]] = []
        self._template = controller_factory()
        env.process(self._pump())
        env.process(self._scan())

    # ------------------------------------------------------------------ state
    def _dest(self, key: str) -> _DestState:
        d = self.dest.get(key)
        if d is None:
            d = self.dest[key] = _DestState(self.factory())
        return d

    @property
    def rate_bps(self) -> float:
        """Rate of the destination currently being served (or the initial rate)."""
        if self.active_key is not None and self.active_key in self.dest:
            return self.dest[self.active_key].ctrl.rate_bps
        return self._template.rate_bps

    @property
    def rtt(self) -> RTTEstimator:
        if self.active_key is not None and self.active_key in self.dest:
            return self.dest[self.active_key].rtt
        return RTTEstimator()

    # ------------------------------------------------------------------ app side
    def submit(self, msg: Message, route) -> bool:
        fr = self.fr
        fr.offered_msgs += 1
        fr.offered_bytes += msg.size_bytes
        if not self.backlogged and self.backlog_bytes + msg.size_bytes > self.buffer_bytes:
            msg.admitted = False
            fr.rejected_msgs += 1
            fr.rejected_bytes += msg.size_bytes
            return False
        fr.admitted_msgs += 1
        fr.admitted_bytes += msg.size_bytes
        self.backlog.append([msg, route, 0])
        self.backlog_bytes += msg.size_bytes
        self._kick()
        return True

    def _kick(self) -> None:
        w = self._wake
        if w is not None and not w.triggered:
            w.succeed()

    # ------------------------------------------------------------------ pacing
    def _pump(self):
        env = self.env
        fr = self.fr
        while True:
            if not self.retx_q and not self.backlog:
                self._wake = env.event()
                yield self._wake
                self._wake = None
                continue
            now = env.now
            wait = max(self.next_send_t, self.hold_until) - now
            if wait > 1e-12:
                yield env.timeout(wait)
                continue
            if self.retx_q:
                item = self.retx_q[0]
                seq, msg_id, frag, payload, route = item
                msg = fr.messages[msg_id]
                if msg.complete or seq not in self.lost_seqs or now > msg.deadline_abs:
                    self.retx_q.popleft()
                    self.lost_seqs.discard(seq)
                    if not msg.complete:
                        fr.gave_up_packets += 1
                    continue
            else:
                item = self.backlog[0]
                route = item[1]
            path = self.route_fn(route, now)
            if path is None:
                yield env.timeout(0.01)
                continue
            rkey = route if isinstance(route, str) else None
            prev = self.last_path.get(rkey)
            if prev is not None and prev != path and self.switch_hold > 0:
                self.last_path[rkey] = path
                self.hold_until = now + self.switch_hold
                self.route_switch_holds += 1
                continue
            self.last_path[rkey] = path
            if self.retx_q:
                seq, msg_id, frag, payload, route = self.retx_q.popleft()
                self.lost_seqs.discard(seq)
                msg = fr.messages[msg_id]
                tx_count = self._tx_counts.pop(seq, 1) + 1
                is_retx = True
                fr.retx_packets += 1
            else:
                msg, route, frag = item
                payload = min(self.mtu, msg.size_bytes - frag * self.mtu)
                item[2] += 1
                if item[2] >= msg.n_frags:
                    self.backlog.popleft()
                self.backlog_bytes -= payload
                seq = self.next_seq
                self.next_seq += 1
                fr.unique_seqs_sent += 1
                tx_count = 1
                is_retx = False
            key = _key(route)
            ds = self._dest(key)
            self.active_key = key
            pkt = Packet(fr.idx, seq, msg.msg_id, frag, msg.n_frags, payload, self.hdr, msg.created_t,
                         msg.deadline_abs, fr.priority, fr.weight, path, sent_t=now, is_retx=is_retx,
                         tx_count=tx_count, t_app=now - msg.created_t)
            self.outstanding[seq] = [now, tx_count, msg.msg_id, frag, payload, route, path, key]
            fr.tx_packets += 1
            fr.tx_wire_bytes += payload + self.hdr
            fr.tx_payload_bytes += payload
            self.network.inject(pkt)
            self.next_send_t = max(self.next_send_t, now) + (payload + self.hdr) * 8.0 / ds.ctrl.rate_bps

    # ------------------------------------------------------------------ feedback
    def on_report(self, report: list[tuple], report_t: float) -> None:
        """Ack report from the receiver: (seq, sent_t, recv_t, path) tuples."""
        now = self.env.now
        acked: dict[str, int] = defaultdict(int)
        for seq, sent_t, recv_t, path in report:
            ent = self.outstanding.get(seq)
            if ent is None or ent[0] != sent_t:
                if seq in self.declared_seqs:
                    self.fr.spurious_loss_declarations += 1
                    self.declared_seqs.discard(seq)
                continue
            del self.outstanding[seq]
            key = ent[7]
            ds = self._dest(key)
            acked[key] += 1
            ds.rtt.update(now - sent_t - (report_t - recv_t))
            if sent_t > ds.largest_acked_sent_t:
                ds.largest_acked_sent_t = sent_t
            if ent[1] == 1 and seq > ds.largest_acked_seq:
                ds.largest_acked_seq = seq
            if self.observe_fn is not None:
                self.observe_fn(ent[5], path, recv_t - sent_t, False, now)
        lost = self._detect_losses(now, by_threshold=True)
        for key in set(acked) | set(lost):
            a, l = acked.get(key, 0), lost.get(key, 0)
            ds = self.dest[key]
            ds.ctrl.on_feedback(now, l / (a + l), ds.rtt.latest, ds.rtt.min_rtt, ds.rtt.srtt)
            if key == self.active_key:
                self.rate_samples.append((now, ds.ctrl.rate_bps))

    def _detect_losses(self, now: float, by_threshold: bool) -> dict[str, int]:
        """QUIC-style loss detection per destination: time threshold (9/8 RTT) or
        packet threshold (3, first transmissions only); or RTO for tail losses."""
        lost: dict[str, int] = defaultdict(int)
        if not self.outstanding:
            return lost
        victims = []
        for seq, ent in self.outstanding.items():
            ds = self.dest[ent[7]]
            if by_threshold:
                if ds.largest_acked_sent_t == -INF or ent[0] >= ds.largest_acked_sent_t:
                    continue
                r = ds.rtt
                thr = 1.125 * max(r.srtt if r.samples else 0.0, r.latest if r.samples else 0.0)
                if ent[0] < ds.largest_acked_sent_t - thr or (ent[1] == 1 and seq <= ds.largest_acked_seq - 3):
                    victims.append(seq)
            else:
                if ent[0] < now - ds.rtt.rto(self.fr.min_rto_s, self.fb_interval):
                    victims.append(seq)
        for seq in victims:
            key = self.outstanding[seq][7]
            self._declare_lost(seq, now)
            lost[key] += 1
        return lost

    def _declare_lost(self, seq: int, now: float) -> None:
        ent = self.outstanding.pop(seq)
        sent_t, tx_count, msg_id, frag, payload, route, path, key = ent
        fr = self.fr
        fr.declared_lost += 1
        self.declared_seqs.add(seq)
        if self.observe_fn is not None:
            self.observe_fn(route, path, INF, True, now)
        msg = fr.messages[msg_id]
        if fr.reliable and tx_count <= fr.max_retx and not msg.complete and now <= msg.deadline_abs:
            self.lost_seqs.add(seq)
            self._tx_counts[seq] = tx_count
            self.retx_q.append([seq, msg_id, frag, payload, route])
            self._kick()
        elif not msg.complete:
            fr.gave_up_packets += 1

    def _scan(self):
        """Retransmission-timeout scan (tail-loss detection), every feedback interval."""
        env = self.env
        while True:
            yield env.timeout(self.fb_interval)
            if self.outstanding:
                lost = self._detect_losses(env.now, by_threshold=False)
                for key in lost:
                    ds = self.dest[key]
                    ds.ctrl.on_feedback(env.now, 1.0, ds.rtt.latest, ds.rtt.min_rtt, ds.rtt.srtt)

    def stats(self) -> dict:
        fr = self.fr
        rtts = {k: {"srtt_ms": d.rtt.srtt * 1e3 if d.rtt.samples else None,
                    "min_rtt_ms": d.rtt.min_rtt * 1e3 if d.rtt.samples else None,
                    "final_rate_mbps": d.ctrl.rate_bps / 1e6, "rate_decreases": d.ctrl.decreases}
                for k, d in sorted(self.dest.items())}
        return {
            "flow": fr.name,
            "transport": "simulated",
            "packets_sent": fr.tx_packets,
            "wire_bytes_sent": fr.tx_wire_bytes,
            "payload_bytes_sent": fr.tx_payload_bytes,
            "header_bytes_sent": fr.tx_wire_bytes - fr.tx_payload_bytes,
            "retransmissions": fr.retx_packets,
            "declared_lost": fr.declared_lost,
            "spurious_loss_declarations": fr.spurious_loss_declarations,
            "gave_up_packets": fr.gave_up_packets,
            "route_switch_holds": self.route_switch_holds,
            "per_destination": rtts,
            "outstanding_at_end": len(self.outstanding),
            "backlog_bytes_at_end": self.backlog_bytes,
        }
