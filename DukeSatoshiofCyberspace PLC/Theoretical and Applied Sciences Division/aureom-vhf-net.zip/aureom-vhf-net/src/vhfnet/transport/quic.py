"""Optional QUIC adapter via ``aioquic`` (https://github.com/aiortc/aioquic).

QUIC (RFC 9000) with TLS 1.3 is provided entirely by aioquic; VHF.NET only
frames messages on one bidirectional stream (same length-prefixed VHF frames as
TCP). Install with ``pip install aioquic`` (extra: ``vhfnet[quic]``).
"""

from __future__ import annotations

import asyncio
import json
import time

from .framing import (FLAG_CONTROL, FLAG_ECHO_REQ, FLAG_FIN, FLAG_RESPONSE, HEADER_SIZE, LEN_PREFIX,
                      FrameError, FrameHeader, encode_frame, unpack_header)
from .rx import RxTracker

ALPN = ["vhf-test"]
QUIC_OVERHEAD_EST = 28 + 25  # IPv4+UDP + approximate short-header + STREAM frame overhead

try:
    from aioquic.asyncio import QuicConnectionProtocol, connect, serve
    from aioquic.quic.configuration import QuicConfiguration
    from aioquic.quic.connection import QuicConnection
    from aioquic.quic.events import StreamDataReceived
    AVAILABLE = True
except ImportError:  # pragma: no cover
    AVAILABLE = False
    QuicConnectionProtocol = object  # type: ignore


class TransportUnavailable(RuntimeError):
    pass


def _require() -> None:
    if not AVAILABLE:
        raise TransportUnavailable("QUIC adapter needs aioquic: pip install aioquic")


def _frames(buf: bytearray):
    while len(buf) >= 4:
        (n,) = LEN_PREFIX.unpack_from(buf, 0)
        if len(buf) < 4 + n:
            return
        body = bytes(buf[4:4 + n])
        del buf[:4 + n]
        yield unpack_header(body), body, n + 4


class _ServerProto(QuicConnectionProtocol):  # type: ignore[misc]
    def __init__(self, *a, **k) -> None:
        super().__init__(*a, **k)
        self._bufs: dict[int, bytearray] = {}
        self._trackers: dict[int, RxTracker] = {}

    def quic_event_received(self, event) -> None:
        if not isinstance(event, StreamDataReceived):
            return
        buf = self._bufs.setdefault(event.stream_id, bytearray())
        buf += event.data
        try:
            for hdr, body, wire in _frames(buf):
                if hdr.flags & FLAG_CONTROL and hdr.flags & FLAG_FIN:
                    stats = {str(k): t.summary(bool(hdr.aux & 1)) for k, t in self._trackers.items()}
                    p = json.dumps(stats).encode()
                    self._quic.send_stream_data(event.stream_id, encode_frame(
                        FrameHeader(FLAG_CONTROL | FLAG_RESPONSE, 0, hdr.seq, 0, 0, 1, hdr.send_ts_ns, len(p)), p, True))
                    continue
                tr = self._trackers.get(hdr.flow_id)
                if tr is None:
                    tr = self._trackers[hdr.flow_id] = RxTracker(hdr.flow_id, QUIC_OVERHEAD_EST)
                tr.on_frame(hdr.seq, hdr.send_ts_ns, hdr.payload_len, wire)
                if hdr.flags & FLAG_ECHO_REQ:
                    n = min(hdr.aux, 1_048_576)
                    self._quic.send_stream_data(event.stream_id, encode_frame(
                        FrameHeader(FLAG_RESPONSE, hdr.flow_id, hdr.seq, hdr.msg_id, 0, 1, hdr.send_ts_ns, n),
                        b"\0" * n, True))
        except FrameError:
            self._quic.close(error_code=0x1, reason_phrase="bad frame")
        self.transmit()


class QUICServer:
    def __init__(self, host: str, port: int, certfile: str, keyfile: str) -> None:
        _require()
        self.host, self.port = host, port
        self.cfg = QuicConfiguration(is_client=False, alpn_protocols=ALPN, max_datagram_frame_size=None)
        self.cfg.load_cert_chain(certfile, keyfile)
        self.server = None

    async def start(self) -> int:
        self.server = await serve(self.host, self.port, configuration=self.cfg, create_protocol=_ServerProto)
        self.port = self.server._transport.get_extra_info("sockname")[1]
        return self.port

    async def close(self) -> None:
        if self.server:
            self.server.close()


class _ClientProto(QuicConnectionProtocol):  # type: ignore[misc]
    def __init__(self, *a, **k) -> None:
        super().__init__(*a, **k)
        self.buf = bytearray()
        self.pending: dict[tuple[int, int], asyncio.Future] = {}
        self.control: asyncio.Future | None = None

    def quic_event_received(self, event) -> None:
        if not isinstance(event, StreamDataReceived):
            return
        self.buf += event.data
        for hdr, body, _ in _frames(self.buf):
            if hdr.flags & FLAG_CONTROL:
                if self.control and not self.control.done():
                    self.control.set_result(body[HEADER_SIZE:])
            elif hdr.flags & FLAG_RESPONSE:
                fut = self.pending.get((hdr.flow_id, hdr.seq))
                if fut and not fut.done():
                    fut.set_result(hdr.payload_len)


class QUICClientAdapter:
    name = "quic"
    wire_overhead = QUIC_OVERHEAD_EST

    def __init__(self, ip: str, port: int, cafile: str, server_name: str = "localhost") -> None:
        _require()
        self.ip, self.port = ip, port
        self.cfg = QuicConfiguration(is_client=True, alpn_protocols=ALPN, server_name=server_name)
        self.cfg.load_verify_locations(cafile)
        self.frames_sent = 0
        self.bytes_sent = 0
        self.payload_sent = 0
        self.errors = 0

    async def connect(self) -> None:
        # aioquic's connect() always opens an IPv6 dual-stack socket; for IPv4 targets we open
        # an AF_INET UDP endpoint ourselves. All QUIC/TLS logic remains aioquic's QuicConnection.
        loop = asyncio.get_running_loop()
        conn = QuicConnection(configuration=self.cfg)
        self._transport, self.proto = await loop.create_datagram_endpoint(
            lambda: _ClientProto(conn), local_addr=("0.0.0.0" if ":" not in self.ip else "::", 0))
        self.proto.connect((self.ip, self.port), transmit=True)
        await asyncio.wait_for(self.proto.wait_connected(), 5.0)
        self.stream_id = self.proto._quic.get_next_available_stream_id()

    async def send(self, hdr: FrameHeader, payload: bytes) -> int:
        frame = encode_frame(hdr, payload, True)
        self.proto._quic.send_stream_data(self.stream_id, frame)
        self.proto.transmit()
        self.frames_sent += 1
        self.bytes_sent += len(frame)
        self.payload_sent += len(payload)
        await asyncio.sleep(0)
        return len(frame) + self.wire_overhead

    async def request(self, hdr: FrameHeader, payload: bytes, timeout_s: float) -> tuple[float, int]:
        fut = asyncio.get_running_loop().create_future()
        key = (hdr.flow_id, hdr.seq)
        self.proto.pending[key] = fut
        t0 = time.monotonic_ns()
        try:
            await self.send(hdr, payload)
            n = await asyncio.wait_for(fut, timeout_s)
            return (time.monotonic_ns() - t0) / 1e9, n
        finally:
            self.proto.pending.pop(key, None)

    async def fin(self, one_way_valid: bool, timeout_s: float = 5.0) -> dict:
        self.proto.control = asyncio.get_running_loop().create_future()
        await self.send(FrameHeader(FLAG_CONTROL | FLAG_FIN, 0, 0, 0, 0, 1, time.monotonic_ns(), 0,
                                    1 if one_way_valid else 0), b"")
        return json.loads(await asyncio.wait_for(self.proto.control, timeout_s))

    async def close(self) -> None:
        try:
            self.proto.close()
            await asyncio.wait_for(self.proto.wait_closed(), 2.0)
        except Exception:
            pass
        finally:
            self._transport.close()
