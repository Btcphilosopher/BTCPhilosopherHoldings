"""TCP adapter (asyncio streams) and VHF sink/echo server.

Backpressure: the client never lets the kernel+transport write buffer grow past
``write_high_water``; above it, ``send`` awaits ``drain()``. Reliability, ordering
and congestion control are TCP's (the OS stack), optionally wrapped in TLS.
"""

from __future__ import annotations

import asyncio
import json
import ssl
import time

from .framing import (FLAG_CONTROL, FLAG_ECHO_REQ, FLAG_FIN, FLAG_RESPONSE, HEADER_SIZE, IPV4_TCP_OVERHEAD,
                      LEN_PREFIX, MAX_FRAME_PAYLOAD, FrameError, FrameHeader, encode_frame, unpack_header)
from .rx import RxTracker

MAX_RESPONSE = 1_048_576


async def read_frame(reader: asyncio.StreamReader):
    raw = await reader.readexactly(4)
    (n,) = LEN_PREFIX.unpack(raw)
    if n < HEADER_SIZE or n > HEADER_SIZE + MAX_FRAME_PAYLOAD:
        raise FrameError(f"bad frame length {n}")
    body = await reader.readexactly(n)
    return unpack_header(body), body, n + 4


class TCPServer:
    """Bounded sink/echo server. Limits: max connections, idle timeout, frame size."""

    def __init__(self, host: str = "127.0.0.1", port: int = 0, ssl_ctx: ssl.SSLContext | None = None,
                 max_connections: int = 64, idle_timeout_s: float = 30.0) -> None:
        self.host, self.port, self.ssl_ctx = host, port, ssl_ctx
        self.max_conn = max_connections
        self.idle = idle_timeout_s
        self.active = 0
        self.refused = 0
        self.server: asyncio.base_events.Server | None = None

    async def start(self) -> int:
        self.server = await asyncio.start_server(self._handle, self.host, self.port, ssl=self.ssl_ctx,
                                                 limit=MAX_FRAME_PAYLOAD + 1024)
        self.port = self.server.sockets[0].getsockname()[1]
        return self.port

    async def close(self) -> None:
        if self.server:
            self.server.close()
            await self.server.wait_closed()

    async def _handle(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        if self.active >= self.max_conn:
            self.refused += 1
            writer.close()
            return
        self.active += 1
        trackers: dict[int, RxTracker] = {}
        try:
            while True:
                hdr, body, wire = await asyncio.wait_for(read_frame(reader), self.idle)
                if hdr.flags & FLAG_CONTROL and hdr.flags & FLAG_FIN:
                    stats = {str(k): t.summary(one_way_valid=bool(hdr.aux & 1)) for k, t in trackers.items()}
                    payload = json.dumps(stats).encode()
                    writer.write(encode_frame(FrameHeader(FLAG_CONTROL | FLAG_RESPONSE, 0, hdr.seq, 0, 0, 1,
                                                          hdr.send_ts_ns, len(payload)), payload, True))
                    await writer.drain()
                    break
                tr = trackers.get(hdr.flow_id)
                if tr is None:
                    tr = trackers[hdr.flow_id] = RxTracker(hdr.flow_id, IPV4_TCP_OVERHEAD)
                tr.on_frame(hdr.seq, hdr.send_ts_ns, hdr.payload_len, wire)
                if hdr.flags & FLAG_ECHO_REQ:
                    n = min(hdr.aux, MAX_RESPONSE)
                    writer.write(encode_frame(FrameHeader(FLAG_RESPONSE, hdr.flow_id, hdr.seq, hdr.msg_id, 0, 1,
                                                          hdr.send_ts_ns, n), b"\0" * n, True))
                    if writer.transport.get_write_buffer_size() > (1 << 20):
                        await writer.drain()
        except (asyncio.IncompleteReadError, asyncio.TimeoutError, ConnectionError, FrameError):
            pass
        finally:
            self.active -= 1
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass


class TCPClientAdapter:
    name = "tcp"
    wire_overhead = IPV4_TCP_OVERHEAD

    def __init__(self, ip: str, port: int, ssl_ctx: ssl.SSLContext | None = None, server_hostname: str | None = None,
                 connect_timeout_s: float = 5.0, write_high_water: int = 1 << 20) -> None:
        self.ip, self.port = ip, port
        self.ssl_ctx, self.server_hostname = ssl_ctx, server_hostname
        self.connect_timeout = connect_timeout_s
        self.high = write_high_water
        self.pending: dict[tuple[int, int], asyncio.Future] = {}
        self.control: asyncio.Future | None = None
        self.frames_sent = 0
        self.bytes_sent = 0
        self.payload_sent = 0
        self.drain_waits = 0
        self.responses = 0
        self.errors = 0
        self._rx: asyncio.Task | None = None

    async def connect(self) -> None:
        self.reader, self.writer = await asyncio.wait_for(
            asyncio.open_connection(self.ip, self.port, ssl=self.ssl_ctx,
                                    server_hostname=self.server_hostname if self.ssl_ctx else None,
                                    limit=MAX_FRAME_PAYLOAD + 1024),
            self.connect_timeout)
        self._rx = asyncio.get_running_loop().create_task(self._recv_loop())

    async def send(self, hdr: FrameHeader, payload: bytes) -> int:
        frame = encode_frame(hdr, payload, True)
        self.writer.write(frame)
        self.frames_sent += 1
        self.bytes_sent += len(frame)
        self.payload_sent += len(payload)
        if self.writer.transport.get_write_buffer_size() > self.high:
            self.drain_waits += 1
            await self.writer.drain()  # explicit backpressure
        return len(frame) + self.wire_overhead

    async def request(self, hdr: FrameHeader, payload: bytes, timeout_s: float) -> tuple[float, int]:
        fut = asyncio.get_running_loop().create_future()
        key = (hdr.flow_id, hdr.seq)
        self.pending[key] = fut
        t0 = time.monotonic_ns()
        try:
            await self.send(hdr, payload)
            n = await asyncio.wait_for(fut, timeout_s)
            return (time.monotonic_ns() - t0) / 1e9, n
        finally:
            self.pending.pop(key, None)

    async def _recv_loop(self) -> None:
        try:
            while True:
                hdr, body, _ = await read_frame(self.reader)
                if hdr.flags & FLAG_CONTROL:
                    if self.control and not self.control.done():
                        self.control.set_result(body[HEADER_SIZE:])
                    continue
                if hdr.flags & FLAG_RESPONSE:
                    self.responses += 1
                    fut = self.pending.get((hdr.flow_id, hdr.seq))
                    if fut and not fut.done():
                        fut.set_result(hdr.payload_len)
        except (asyncio.IncompleteReadError, ConnectionError, FrameError, asyncio.CancelledError):
            pass

    async def fin(self, one_way_valid: bool, timeout_s: float = 5.0) -> dict:
        self.control = asyncio.get_running_loop().create_future()
        await self.send(FrameHeader(FLAG_CONTROL | FLAG_FIN, 0, 0, 0, 0, 1, time.monotonic_ns(), 0,
                                    1 if one_way_valid else 0), b"")
        await self.writer.drain()
        raw = await asyncio.wait_for(self.control, timeout_s)
        return json.loads(raw)

    async def close(self) -> None:
        if self._rx:
            self._rx.cancel()
        try:
            self.writer.close()
            await self.writer.wait_closed()
        except Exception:
            pass
