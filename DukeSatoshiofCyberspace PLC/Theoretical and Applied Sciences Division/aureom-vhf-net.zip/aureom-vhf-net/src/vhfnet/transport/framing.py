"""VHF frame format (the "VHF" high-rate message-processing wire header).

Layout (network byte order, 40 bytes)::

    magic      2s  b"VH"
    version    B   1
    flags      B   RETX | RESPONSE | FEEDBACK | ECHO_REQ | FIN | CONTROL
    flow_id    I
    seq        Q   per-flow transport sequence number
    msg_id     I   application message id
    frag_idx   H
    frag_cnt   H
    send_ts_ns Q   sender CLOCK_MONOTONIC timestamp (ns)
    payload    I   payload length in bytes
    aux        I   requested response length (ECHO_REQ) or control data

Stream transports (TCP, QUIC streams) prefix each frame with a 4-byte length.
Wire-overhead *estimates* for accounting: IPv4+UDP = 28 B, IPv4+TCP = 40 B
(no options); actual on-wire bytes depend on the OS, MTU, TSO/GSO, TLS records.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass

MAGIC = b"VH"
VERSION = 1
HEADER = struct.Struct("!2sBBIQIHHQII")
HEADER_SIZE = HEADER.size  # 40
LEN_PREFIX = struct.Struct("!I")

FLAG_RETX = 0x01
FLAG_RESPONSE = 0x02
FLAG_FEEDBACK = 0x04
FLAG_ECHO_REQ = 0x08
FLAG_FIN = 0x10
FLAG_CONTROL = 0x20

IPV4_UDP_OVERHEAD = 28
IPV4_TCP_OVERHEAD = 40
MAX_FRAME_PAYLOAD = 1_048_576


class FrameError(ValueError):
    pass


@dataclass(slots=True)
class FrameHeader:
    flags: int
    flow_id: int
    seq: int
    msg_id: int
    frag_idx: int
    frag_cnt: int
    send_ts_ns: int
    payload_len: int
    aux: int = 0


def pack_header(h: FrameHeader) -> bytes:
    return HEADER.pack(MAGIC, VERSION, h.flags, h.flow_id, h.seq, h.msg_id, h.frag_idx, h.frag_cnt,
                       h.send_ts_ns, h.payload_len, h.aux)


def unpack_header(buf, offset: int = 0) -> FrameHeader:
    if len(buf) - offset < HEADER_SIZE:
        raise FrameError("short frame")
    magic, ver, flags, flow, seq, msg, fi, fc, ts, plen, aux = HEADER.unpack_from(buf, offset)
    if magic != MAGIC or ver != VERSION:
        raise FrameError("bad magic/version")
    if plen > MAX_FRAME_PAYLOAD:
        raise FrameError("payload too large")
    return FrameHeader(flags, flow, seq, msg, fi, fc, ts, plen, aux)


def encode_frame(h: FrameHeader, payload: bytes = b"", length_prefix: bool = False) -> bytes:
    if len(payload) != h.payload_len:
        h.payload_len = len(payload)
    body = pack_header(h) + payload
    return LEN_PREFIX.pack(len(body)) + body if length_prefix else body
