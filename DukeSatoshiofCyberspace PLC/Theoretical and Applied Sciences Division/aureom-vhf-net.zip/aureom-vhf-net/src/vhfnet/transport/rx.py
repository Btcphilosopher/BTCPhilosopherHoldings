"""Receiver-side measurement shared by all live servers."""

from __future__ import annotations

import time

import numpy as np

from ..telemetry import metrics as M

MAX_SAMPLES = 400_000


class RxTracker:
    """Per-flow receive statistics: unique/duplicate/reordered frames, bytes, OWD."""

    def __init__(self, flow_id: int, header_overhead: int) -> None:
        self.flow_id = flow_id
        self.overhead = header_overhead
        self.highest = -1
        self.unique = 0
        self.dups = 0
        self.reordered = 0
        self.frames = 0
        self.wire_bytes = 0
        self.payload_unique = 0
        self.seen: set[int] = set()
        self.floor = 0
        self.send_ts: list[int] = []
        self.recv_ts: list[int] = []
        self.first_ns: int | None = None
        self.last_ns: int | None = None
        self.last_send_ts = 0
        self.last_recv_ns = 0
        self.nack_reported: dict[int, int] = {}

    def on_frame(self, seq: int, send_ts_ns: int, payload_len: int, wire_len: int, recv_ns: int | None = None) -> bool:
        now = recv_ns if recv_ns is not None else time.monotonic_ns()
        self.frames += 1
        self.wire_bytes += wire_len + self.overhead
        if self.first_ns is None:
            self.first_ns = now
        self.last_ns = now
        if seq < self.floor or seq in self.seen:
            self.dups += 1
            return False
        self.seen.add(seq)
        if seq < self.highest:
            self.reordered += 1
        else:
            self.highest = seq
        self.unique += 1
        self.payload_unique += payload_len
        self.last_send_ts, self.last_recv_ns = send_ts_ns, now
        if len(self.send_ts) < MAX_SAMPLES:
            self.send_ts.append(send_ts_ns)
            self.recv_ts.append(now)
        if len(self.seen) > 200_000:  # bound memory: forget sequence numbers far below the highest
            cut = self.highest - 100_000
            self.seen = {s for s in self.seen if s >= cut}
            self.floor = cut
        return True

    def missing(self, limit: int = 64, window: int = 4096) -> list[int]:
        lo = max(self.floor, self.highest - window)
        out = []
        for s in range(lo, self.highest):
            if s not in self.seen:
                out.append(s)
                if len(out) >= limit:
                    break
        return out

    def summary(self, one_way_valid: bool) -> dict:
        s = np.asarray(self.send_ts, dtype=np.int64)
        r = np.asarray(self.recv_ts, dtype=np.int64)
        d = {
            "flow_id": self.flow_id, "frames": self.frames, "unique": self.unique, "duplicates": self.dups,
            "reordered": self.reordered, "highest_seq": self.highest, "wire_bytes_est": self.wire_bytes,
            "unique_payload_bytes": self.payload_unique,
            "active_s": ((self.last_ns - self.first_ns) / 1e9) if self.first_ns and self.last_ns else 0.0,
        }
        if one_way_valid and s.size:
            transit = (r - s) / 1e6
            order = np.argsort(r, kind="stable")
            d["owd_ms"] = M.percentiles(transit)
            d["jitter_rfc3550_ms"] = M.jitter_rfc3550(s[order] / 1e6, r[order] / 1e6)
            d["pdv_p99_ms"] = float(np.percentile(transit - transit.min(), 99))
        else:
            d["owd_ms"] = None
            d["owd_note"] = "not reported: clocks not on a common time base"
        return d
