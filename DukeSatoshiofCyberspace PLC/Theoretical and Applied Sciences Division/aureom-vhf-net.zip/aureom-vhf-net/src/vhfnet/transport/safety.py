"""LIVE TEST guard rails: explicit endpoints, finite duration, rate and byte ceilings.

* No discovery or scanning: only the single host/port written in the config.
* Loopback endpoints are allowed by default. Anything else requires
  ``authorised: true``, an ``authorisation_note`` and membership of an explicitly
  listed CIDR in ``allowed_networks``.
* Multicast, broadcast, unspecified and reserved addresses are always refused.
* Duration, aggregate rate and total bytes are capped by hard limits that a
  config file cannot raise (see ``vhfnet.config.LIVE_HARD_*``).
"""

from __future__ import annotations

import ipaddress
import socket
import time
from dataclasses import dataclass

from ..config import LiveTestConfig


class EndpointNotAllowed(PermissionError):
    pass


class BudgetExceeded(RuntimeError):
    pass


@dataclass(frozen=True)
class ResolvedEndpoint:
    host: str
    ip: str
    port: int
    family: int
    loopback: bool


def resolve_endpoint(cfg: LiveTestConfig, sock_type: int = socket.SOCK_STREAM) -> ResolvedEndpoint:
    host, port = cfg.endpoint.host, cfg.endpoint.port
    try:
        infos = socket.getaddrinfo(host, port, type=sock_type)
    except socket.gaierror as e:
        raise EndpointNotAllowed(f"cannot resolve configured host {host!r}: {e}") from e
    nets = [ipaddress.ip_network(n, strict=False) for n in cfg.allowed_networks]
    chosen = None
    for fam, _, _, _, sa in infos:
        ip = ipaddress.ip_address(sa[0])
        if ip.is_multicast or ip.is_unspecified or ip.is_reserved or (
                isinstance(ip, ipaddress.IPv4Address) and ip == ipaddress.IPv4Address("255.255.255.255")):
            raise EndpointNotAllowed(f"{ip} is multicast/broadcast/unspecified/reserved: refused")
        if ip.is_loopback:
            ok = True
        else:
            ok = cfg.authorised and any(ip in n for n in nets)
        if not ok:
            raise EndpointNotAllowed(
                f"{host} resolves to {ip}, which is not loopback. Live tests to other hosts need "
                "authorised: true, an authorisation_note and the address inside allowed_networks.")
        if chosen is None:
            chosen = ResolvedEndpoint(host, str(ip), port, fam, ip.is_loopback)
    if chosen is None:
        raise EndpointNotAllowed(f"no addresses for {host}")
    return chosen


class Budget:
    """Shared byte/time budget for one live test (enforced on every send)."""

    def __init__(self, max_bytes: int, max_duration_s: float) -> None:
        self.max_bytes = max_bytes
        self.max_duration_s = max_duration_s
        self.sent = 0
        self.t0 = time.monotonic()
        self.exhausted = False
        self.reason: str | None = None

    def charge(self, nbytes: int) -> None:
        self.sent += nbytes
        if self.sent > self.max_bytes:
            self.exhausted = True
            self.reason = "max_total_bytes reached"
            raise BudgetExceeded(self.reason)
        if time.monotonic() - self.t0 > self.max_duration_s:
            self.exhausted = True
            self.reason = "max_duration_s reached"
            raise BudgetExceeded(self.reason)
