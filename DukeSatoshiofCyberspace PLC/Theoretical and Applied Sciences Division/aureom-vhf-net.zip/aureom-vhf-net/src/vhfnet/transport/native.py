"""Optional native-extension interface for hot paths.

Pure Python cannot sustain arbitrary line-rate packet processing: on a typical
host the struct-based codec below handles on the order of 10^5-10^6 headers/s
per core (measure with ``vhfnet bench``), and asyncio socket I/O adds per-
datagram overhead. VHF.NET therefore defines narrow interfaces that a compiled
extension (C, Rust/PyO3, Cython...) may implement. None is shipped; the pure-
Python reference implementation is always available and is the conformance
oracle.

Extension contract (module name ``vhfnet_native``):

    class FrameCodec:
        name: str
        def pack(self, flags, flow_id, seq, msg_id, frag_idx, frag_cnt,
                 send_ts_ns, payload_len, aux) -> bytes        # 40 bytes
        def unpack(self, buf, offset=0) -> tuple                # 9-tuple
        def pack_batch(self, rows: Sequence[tuple]) -> bytes    # concatenated headers

    class Pacer:
        def __init__(self, rate_bps: float, burst_bytes: int)
        def due(self, now_ns: int, size_bytes: int) -> bool     # token bucket
        def set_rate(self, rate_bps: float) -> None

``load_codec()`` verifies any native codec against golden vectors before use.
"""

from __future__ import annotations

import importlib
import math
from typing import Protocol, Sequence

from .framing import HEADER, MAGIC, VERSION, FrameError


class FrameCodec(Protocol):
    name: str

    def pack(self, flags: int, flow_id: int, seq: int, msg_id: int, frag_idx: int, frag_cnt: int,
             send_ts_ns: int, payload_len: int, aux: int) -> bytes: ...

    def unpack(self, buf, offset: int = 0) -> tuple: ...

    def pack_batch(self, rows: Sequence[tuple]) -> bytes: ...


class PythonCodec:
    name = "python-struct"

    def __init__(self) -> None:
        self._s = HEADER

    def pack(self, flags, flow_id, seq, msg_id, frag_idx, frag_cnt, send_ts_ns, payload_len, aux=0) -> bytes:
        return self._s.pack(MAGIC, VERSION, flags, flow_id, seq, msg_id, frag_idx, frag_cnt, send_ts_ns,
                            payload_len, aux)

    def unpack(self, buf, offset: int = 0) -> tuple:
        t = self._s.unpack_from(buf, offset)
        if t[0] != MAGIC or t[1] != VERSION:
            raise FrameError("bad magic/version")
        return t[2:]

    def pack_batch(self, rows) -> bytes:
        p = self._s.pack
        return b"".join(p(MAGIC, VERSION, *r) for r in rows)


class TokenBucketPacer:
    """Reference pacer (pure Python)."""

    def __init__(self, rate_bps: float, burst_bytes: int) -> None:
        self.rate = rate_bps
        self.burst = burst_bytes
        self.tokens = float(burst_bytes)
        self.last_ns: int | None = None

    def set_rate(self, rate_bps: float) -> None:
        self.rate = rate_bps

    def due(self, now_ns: int, size_bytes: int) -> bool:
        if self.last_ns is None:
            self.last_ns = now_ns
        self.tokens = min(self.burst, self.tokens + (now_ns - self.last_ns) * 1e-9 * self.rate / 8)
        self.last_ns = now_ns
        if self.tokens >= size_bytes:
            self.tokens -= size_bytes
            return True
        return False

    def wait_s(self, size_bytes: int) -> float:
        deficit = size_bytes - self.tokens
        return 0.0 if deficit <= 0 else deficit * 8 / self.rate if self.rate > 0 else math.inf


GOLDEN = [
    ((0, 1, 0, 0, 0, 1, 0, 0, 0), bytes.fromhex("56480100000000010000000000000000000000000000000100000000000000000000000000000000")),
    ((0x09, 7, 2**40 + 3, 99, 2, 5, 123456789012, 1200, 64),
     None),
]


def conformance_check(codec) -> bool:
    ref = PythonCodec()
    for args, expected in GOLDEN:
        want = expected if expected is not None else ref.pack(*args)
        if codec.pack(*args) != want:
            return False
        if tuple(codec.unpack(want)) != tuple(args):
            return False
    rows = [a for a, _ in GOLDEN]
    return codec.pack_batch(rows) == ref.pack_batch(rows)


def load_codec(prefer_native: bool = True) -> FrameCodec:
    if prefer_native:
        try:
            mod = importlib.import_module("vhfnet_native")
            codec = mod.FrameCodec()
            if conformance_check(codec):
                return codec
        except Exception:
            pass
    return PythonCodec()
