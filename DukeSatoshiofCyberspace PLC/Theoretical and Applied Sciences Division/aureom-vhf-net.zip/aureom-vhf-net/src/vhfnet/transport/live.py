"""LIVE TEST runner: bounded traffic between explicitly configured endpoints.

Guarantees enforced here (in addition to config validation):
* endpoint resolved once from the config and checked by ``safety.resolve_endpoint``,
* every flow has a finite duration; the whole test is wrapped in a hard timeout,
* a shared byte budget is charged on every send,
* pacing never exceeds the flow's rate (itself <= the test's rate ceiling),
* elapsed times use the monotonic clock; one-way delay is reported only when the
  clock policy supports it.

Rates: ``rate_mbps`` is the target *estimated wire* rate (payload + VHF header +
IP/transport header estimate). Goodput is reported separately.
"""

from __future__ import annotations

import asyncio
import math
import multiprocessing as mp
import random
import time
from collections import OrderedDict
from dataclasses import dataclass, field

import numpy as np

from .. import __version__
from ..config import LiveFlow, LiveTestConfig
from ..optimisation.rate_control import BoundedAIMD, RTTEstimator
from ..telemetry import metrics as M
from ..telemetry.clocks import ClockPolicy
from ..telemetry.resources import LoopLagMonitor, ResourceSampler, host_info
from .framing import FLAG_ECHO_REQ, FLAG_RETX, HEADER_SIZE, FrameHeader
from .safety import Budget, BudgetExceeded, resolve_endpoint
from .udp import AUX_WANT_NACK

LIVE_DISCLAIMER = ("LIVE TEST: measured with real sockets and monotonic clocks on this host. Loopback results "
                   "characterise the Python/asyncio + OS network stack, not network hardware or a real path.")


# =============================================================================
# servers
# =============================================================================

async def start_server(transport: str, host: str, port: int, tls: tuple[str, str] | None = None,
                       feedback_interval_s: float = 0.02):
    if transport == "tcp":
        from .tcp import TCPServer
        from .tlsutil import server_context
        srv = TCPServer(host, port, ssl_ctx=server_context(*tls) if tls else None)
    elif transport == "udp":
        from .udp import UDPServer
        srv = UDPServer(host, port, feedback_interval_s=feedback_interval_s)
    elif transport == "quic":
        from .quic import QUICServer
        if tls is None:
            from .tlsutil import self_signed_localhost
            tls = self_signed_localhost()
        srv = QUICServer(host, port, *tls)
    else:
        raise ValueError(transport)
    await srv.start()
    return srv


def _server_main(transport, host, port, tls, fb, lifetime_s, conn) -> None:  # pragma: no cover - child process
    async def main():
        srv = await start_server(transport, host, port, tls, fb)
        conn.send(srv.port)
        loop = asyncio.get_running_loop()
        stop = loop.create_future()
        loop.add_reader(conn.fileno(), lambda: stop.done() or stop.set_result(None))
        try:
            await asyncio.wait_for(stop, lifetime_s)
        except asyncio.TimeoutError:
            pass
        await srv.close()

    asyncio.run(main())


class LocalServerProcess:
    """Loopback server in a separate process (own event loop, own GIL), bounded lifetime."""

    def __init__(self, transport: str, port: int = 0, tls: tuple[str, str] | None = None,
                 feedback_interval_s: float = 0.02, lifetime_s: float = 330.0) -> None:
        ctx = mp.get_context("spawn")
        self.parent, child = ctx.Pipe()
        self.proc = ctx.Process(target=_server_main, args=(transport, "127.0.0.1", port, tls, feedback_interval_s,
                                                           lifetime_s, child), daemon=True)
        self.port: int | None = None

    def __enter__(self) -> "LocalServerProcess":
        self.proc.start()
        if not self.parent.poll(20):
            self.proc.terminate()
            raise RuntimeError("local server did not start")
        self.port = self.parent.recv()
        return self

    def __exit__(self, *exc) -> None:
        try:
            self.parent.send("stop")
        except Exception:
            pass
        self.proc.join(5)
        if self.proc.is_alive():
            self.proc.terminate()


# =============================================================================
# client-side flow statistics
# =============================================================================

@dataclass
class FlowStats:
    flow: LiveFlow
    fid: int
    frames: int = 0
    unique_frames: int = 0
    payload: int = 0
    wire: int = 0
    retx: int = 0
    lags: list = field(default_factory=list)
    rtts: list = field(default_factory=list)
    ok: int = 0
    late: int = 0
    timeouts: int = 0
    errors: int = 0
    t_start: float = 0.0
    t_end: float = 0.0
    rate_history: list = field(default_factory=list)
    stopped_by_budget: bool = False
    nacks_received: int = 0


async def _paced(send_coro, flow: LiveFlow, st: FlowStats, budget: Budget, rate_fn, overhead: int,
                 rng: random.Random, max_burst: int = 64) -> None:
    """Send frames on a schedule at ``rate_fn()`` (wire bit/s) for flow.duration_s."""
    t0 = time.monotonic()
    st.t_start = t0
    t_end = t0 + flow.duration_s
    nxt = t0
    on_until = t_end
    if flow.pattern == "bursty":
        on_until = t0 + rng.expovariate(1 / flow.on_s)
    wire_bits = (flow.payload_bytes + HEADER_SIZE + overhead) * 8
    try:
        while True:
            now = time.monotonic()
            if now >= t_end:
                break
            if flow.pattern == "bursty" and now >= on_until:
                off = rng.expovariate(1 / flow.off_s)
                await asyncio.sleep(min(off, max(0.0, t_end - now)))
                now = time.monotonic()
                on_until = now + rng.expovariate(1 / flow.on_s)
                nxt = now
                continue
            n = 0
            while nxt <= now and n < max_burst:
                st.lags.append(now - nxt)
                await send_coro()
                n += 1
                nxt += wire_bits / rate_fn()
            await asyncio.sleep(max(0.0, min(nxt - time.monotonic(), 0.002)))
    except BudgetExceeded:
        st.stopped_by_budget = True
    st.t_end = time.monotonic()


async def _flow_stream(adapter, flow: LiveFlow, fid: int, budget: Budget, cfg: LiveTestConfig,
                       rng: random.Random) -> FlowStats:
    st = FlowStats(flow, fid)
    payload = b"\0" * flow.payload_bytes
    is_udp = adapter.name == "udp"
    seq = 0
    ctrl = None
    rtt = RTTEstimator()
    retx_buf: OrderedDict[int, int] = OrderedDict()
    retx_count: dict[int, int] = {}
    retx_q: list[int] = []
    want_nack = is_udp and cfg.udp.experimental_reliability
    if is_udp and cfg.udp.adaptive:
        a = cfg.udp.aimd
        ctrl = BoundedAIMD(min_bps=min(0.5e6, flow.rate_mbps * 1e6), max_bps=flow.rate_mbps * 1e6,
                           rate_bps=flow.rate_mbps * 1e6, ai_bps_per_s=a.additive_increase_mbps_per_s * 1e6,
                           md=a.multiplicative_decrease, loss_threshold=a.loss_threshold,
                           delay_threshold_s=a.delay_threshold_ms / 1e3)
        last = {"exp": 0, "uniq": 0}

        def on_fb(fb: dict) -> None:
            now = time.monotonic_ns()
            if fb["echo_ts_ns"]:
                rtt.update((now - fb["echo_ts_ns"] - fb["hold_ns"]) / 1e9)
            exp = fb["highest"] + 1
            d_exp, d_u = exp - last["exp"], fb["unique"] - last["uniq"]
            last["exp"], last["uniq"] = exp, fb["unique"]
            loss = max(0.0, (d_exp - d_u) / d_exp) if d_exp > 0 else 0.0
            ctrl.on_feedback(time.monotonic() - st.t_start, loss, rtt.latest, rtt.min_rtt, rtt.srtt)
            st.rate_history.append((time.monotonic() - st.t_start, ctrl.rate_bps))
            if want_nack:
                st.nacks_received += len(fb["nacks"])
                for s in fb["nacks"]:
                    if s in retx_buf and retx_count.get(s, 0) < cfg.udp.max_retx:
                        retx_q.append(s)

        adapter.feedback_handlers[fid] = on_fb

    async def send_one() -> None:
        nonlocal seq
        if retx_q:
            s = retx_q.pop(0)
            if s in retx_buf:
                retx_count[s] = retx_count.get(s, 0) + 1
                h = FrameHeader(FLAG_RETX, fid, s, s, 0, 1, time.monotonic_ns(), len(payload), AUX_WANT_NACK)
                budget.charge(len(payload) + HEADER_SIZE + adapter.wire_overhead)
                st.wire += await adapter.send(h, payload)
                st.retx += 1
                st.frames += 1
                return
        h = FrameHeader(0, fid, seq, seq, 0, 1, time.monotonic_ns(), len(payload), AUX_WANT_NACK if want_nack else 0)
        budget.charge(len(payload) + HEADER_SIZE + adapter.wire_overhead)
        st.wire += await adapter.send(h, payload)
        if want_nack:
            retx_buf[seq] = 1
            if len(retx_buf) > cfg.udp.retx_buffer_packets:
                retx_buf.popitem(last=False)
        seq += 1
        st.frames += 1
        st.unique_frames += 1
        st.payload += len(payload)

    rate_fn = (lambda: ctrl.rate_bps) if ctrl else (lambda: flow.rate_mbps * 1e6)
    await _paced(send_one, flow, st, budget, rate_fn, adapter.wire_overhead, rng)
    return st


async def _flow_rr(adapter, flow: LiveFlow, fid: int, budget: Budget) -> FlowStats:
    st = FlowStats(flow, fid)
    payload = b"\0" * flow.payload_bytes
    sem = asyncio.Semaphore(flow.concurrency)
    interval = (flow.payload_bytes + HEADER_SIZE + adapter.wire_overhead) * 8 / (flow.rate_mbps * 1e6)
    tasks: set[asyncio.Task] = set()
    deadline = flow.deadline_ms / 1e3 if flow.deadline_ms else math.inf

    async def one(seq: int) -> None:
        try:
            h = FrameHeader(FLAG_ECHO_REQ, fid, seq, seq, 0, 1, time.monotonic_ns(), len(payload), flow.response_bytes)
            rtt, _ = await adapter.request(h, payload, flow.timeout_ms / 1e3)
            st.rtts.append(rtt)
            if rtt <= deadline:
                st.ok += 1
            else:
                st.late += 1
        except asyncio.TimeoutError:
            st.timeouts += 1
        except BudgetExceeded:
            st.stopped_by_budget = True
        except Exception:
            st.errors += 1
        finally:
            sem.release()

    t0 = time.monotonic()
    st.t_start = t0
    nxt = t0
    seq = 0
    try:
        while time.monotonic() < t0 + flow.duration_s:
            now = time.monotonic()
            if now < nxt:
                await asyncio.sleep(nxt - now)
            await sem.acquire()
            now = time.monotonic()
            st.lags.append(max(0.0, now - nxt))
            budget.charge(len(payload) + HEADER_SIZE + adapter.wire_overhead)
            st.frames += 1
            st.unique_frames += 1
            st.payload += len(payload)
            st.wire += len(payload) + HEADER_SIZE + 4 + adapter.wire_overhead
            t = asyncio.get_running_loop().create_task(one(seq))
            tasks.add(t)
            t.add_done_callback(tasks.discard)
            seq += 1
            nxt += interval
    except BudgetExceeded:
        st.stopped_by_budget = True
    if tasks:
        await asyncio.wait(tasks, timeout=flow.timeout_ms / 1e3 + 1)
    st.t_end = time.monotonic()
    return st


def _summarise_flow(st: FlowStats, server: dict | None, clock: ClockPolicy, transport: str) -> dict:
    f = st.flow
    dur = max(st.t_end - st.t_start, 1e-9)
    lags = np.asarray(st.lags) * 1e3
    sent_wire_mbps = st.wire * 8 / dur / 1e6
    target = f.rate_mbps
    lag_p99 = float(np.percentile(lags, 99)) if lags.size else None
    gen_limited = sent_wire_mbps < 0.95 * target if f.pattern == "constant_rate" else (
        (lag_p99 or 0) > 10.0)
    row = {
        "id": f.id, "pattern": f.pattern, "flow_id": st.fid, "duration_s": dur,
        "target_wire_rate_mbps": target,
        "achieved_send_wire_rate_mbps_est": sent_wire_mbps,
        "achieved_send_payload_rate_mbps": st.payload * 8 / dur / 1e6,
        "generator_limited": bool(gen_limited),
        "generator_lag_ms": {"p50": float(np.percentile(lags, 50)) if lags.size else None, "p99": lag_p99,
                             "max": float(lags.max()) if lags.size else None},
        "frames_sent": st.frames, "unique_frames_sent": st.unique_frames, "retransmissions": st.retx,
        "payload_bytes_sent": st.payload, "wire_bytes_sent_est": st.wire,
        "stopped_by_budget": st.stopped_by_budget,
    }
    if f.pattern == "request_response":
        total = st.ok + st.late + st.timeouts + st.errors
        rt = np.asarray(st.rtts)
        row["requests"] = {"issued": st.frames, "completed": total, "ok": st.ok, "late": st.late,
                           "timeouts": st.timeouts, "errors": st.errors,
                           "success_ratio": (st.ok + st.late) / total if total else None,
                           "on_time_ratio": st.ok / total if total else None,
                           "failure_ratio": (st.timeouts + st.errors) / total if total else None}
        row["rtt_ms"] = M.percentiles(rt * 1e3)
        row["rtt_ipdv_p95_ms"] = float(np.percentile(np.abs(np.diff(rt)) * 1e3, 95)) if rt.size > 2 else None
        row["rtt_note"] = "RTT = monotonic time from request send to response receipt (includes server turnaround)"
    if server:
        uniq_payload = server.get("unique_payload_bytes", 0)
        row["server"] = server
        row["goodput_mbps"] = uniq_payload * 8 / dur / 1e6
        if transport == "udp" and f.pattern != "request_response":
            row["loss_ratio"] = 1 - server.get("unique", 0) / st.unique_frames if st.unique_frames else None
            row["duplicates"] = server.get("duplicates")
            row["reordered"] = server.get("reordered")
        if clock.one_way_valid and server.get("owd_ms"):
            row["owd_ms"] = server["owd_ms"]
            row["jitter_rfc3550_ms"] = server.get("jitter_rfc3550_ms")
            row["owd_basis"] = clock.describe()
        else:
            row["owd_ms"] = None
            row["owd_basis"] = clock.describe()
    if st.rate_history:
        row["rate_history_mbps"] = [(t, r / 1e6) for t, r in st.rate_history[:: max(1, len(st.rate_history) // 300)]]
    if st.nacks_received:
        row["nacks_received"] = st.nacks_received
    return row


# =============================================================================
# orchestration
# =============================================================================

async def _make_adapter(cfg: LiveTestConfig, ip: str, port: int, tls: tuple[str, str] | None):
    if cfg.transport == "tcp":
        from .tcp import TCPClientAdapter
        from .tlsutil import client_context
        ad = TCPClientAdapter(ip, port, ssl_ctx=client_context(tls[0]) if tls else None, server_hostname="localhost")
    elif cfg.transport == "udp":
        from .udp import UDPClientAdapter
        ad = UDPClientAdapter(ip, port)
    else:
        from .quic import QUICClientAdapter
        ad = QUICClientAdapter(ip, port, cafile=tls[0])
    await ad.connect()
    return ad


async def run_live_async(cfg: LiveTestConfig, port_override: int | None = None,
                         tls: tuple[str, str] | None = None, seed: int = 0) -> dict:
    sock_type = 2 if cfg.transport in ("udp", "quic") else 1
    ep = resolve_endpoint(cfg, sock_type)
    port = port_override or ep.port
    clock = ClockPolicy(cfg.clock_sync, cfg.clock_error_bound_ms)
    warnings = []
    if cfg.clock_sync == "same_host" and not ep.loopback:
        clock = ClockPolicy("none")
        warnings.append("clock_sync=same_host but endpoint is not loopback: one-way delay disabled")
    budget = Budget(cfg.max_total_bytes, cfg.max_duration_s)
    lag = LoopLagMonitor()
    res = ResourceSampler()
    lag.start()
    res.start()
    rng = random.Random(seed)
    t0 = time.monotonic()
    adapters = []
    results = []
    try:
        async def run_flow(i: int, flow: LiveFlow):
            ad = await _make_adapter(cfg, ep.ip, port, tls)
            adapters.append(ad)
            if flow.pattern == "request_response":
                st = await _flow_rr(ad, flow, i + 1, budget)
            else:
                st = await _flow_stream(ad, flow, i + 1, budget, cfg, random.Random(rng.random()))
            if cfg.transport == "udp" and flow.pattern != "request_response":
                await asyncio.sleep(cfg.udp.drain_s)
            try:
                server = (await ad.fin(clock.one_way_valid)).get(str(i + 1))
            except Exception as e:  # stats unavailable: say so, do not invent
                server = None
                warnings.append(f"flow {flow.id}: server stats unavailable ({type(e).__name__})")
            return st, server

        coro = asyncio.gather(*(run_flow(i, f) for i, f in enumerate(cfg.flows)))
        outs = await asyncio.wait_for(coro, cfg.max_duration_s + 15)
        for st, server in outs:
            results.append(_summarise_flow(st, server, clock, cfg.transport))
    finally:
        for ad in adapters:
            await ad.close()
        loop_lag = await lag.stop()
        resources = await res.stop()
    totals = {
        "wire_bytes_sent_est": sum(r["wire_bytes_sent_est"] for r in results),
        "payload_bytes_sent": sum(r["payload_bytes_sent"] for r in results),
        "goodput_mbps": sum(r.get("goodput_mbps") or 0 for r in results),
        "request_failures": sum(r.get("requests", {}).get("timeouts", 0) + r.get("requests", {}).get("errors", 0)
                                for r in results),
        "generator_limited_flows": [r["id"] for r in results if r["generator_limited"]],
        "budget_bytes_used": budget.sent,
        "budget_exhausted": budget.exhausted,
        "elapsed_s": time.monotonic() - t0,
    }
    return {
        "meta": {"mode": "LIVE TEST", "disclaimer": LIVE_DISCLAIMER, "name": cfg.name, "transport": cfg.transport,
                 "tls": bool(tls) and cfg.transport in ("tcp", "quic"),
                 "endpoint": {"host": ep.host, "ip": ep.ip, "port": port, "loopback": ep.loopback},
                 "clock": {"policy": clock.sync, "one_way_valid": clock.one_way_valid, "basis": clock.describe()},
                 "limits": {"max_duration_s": cfg.max_duration_s, "rate_ceiling_mbps": cfg.rate_ceiling_mbps,
                            "max_total_bytes": cfg.max_total_bytes},
                 "udp": cfg.udp.model_dump() if cfg.transport == "udp" else None,
                 "experimental_reliability": cfg.transport == "udp" and cfg.udp.experimental_reliability,
                 "vhfnet_version": __version__, "host": host_info(), "warnings": warnings,
                 "rate_semantics": "rate_mbps = target estimated wire rate (payload + 40 B VHF header + IP/transport estimate)"},
        "flows": results,
        "totals": totals,
        "resources": {"event_loop_delay": loop_lag, "process": resources,
                      "note": "client process only; the loopback server runs in a separate process"},
    }


def run_live(cfg: LiveTestConfig, spawn_local_server: bool = True, seed: int = 0) -> dict:
    """Run a live test. With ``spawn_local_server`` a loopback server is started in a
    separate process (only allowed for loopback endpoints)."""
    tls = None
    if cfg.transport == "quic" or (cfg.transport == "tcp" and cfg.tls):
        from .tlsutil import self_signed_localhost
        tls = self_signed_localhost()
    if spawn_local_server:
        ep = resolve_endpoint(cfg)
        if not ep.loopback:
            raise PermissionError("spawn_local_server is only allowed for loopback endpoints")
        with LocalServerProcess(cfg.transport, cfg.endpoint.port, tls, cfg.udp.feedback_interval_ms / 1e3,
                                lifetime_s=cfg.max_duration_s + 30) as srv:
            return asyncio.run(run_live_async(cfg, srv.port, tls, seed))
    if cfg.endpoint.port == 0:
        raise ValueError("endpoint.port 0 (ephemeral) is only valid with a locally spawned server")
    return asyncio.run(run_live_async(cfg, None, tls, seed))
