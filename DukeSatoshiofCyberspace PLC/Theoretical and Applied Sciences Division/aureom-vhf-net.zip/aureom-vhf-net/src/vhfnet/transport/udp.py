"""Bounded UDP test adapter and server.

* Explicit pacing (token schedule) at a rate that never exceeds the configured
  flow rate, which itself is capped by the live test's ``rate_ceiling_mbps``.
* Receiver feedback every ``feedback_interval`` (highest seq, unique count,
  duplicates, reordering, timestamp echo + hold time for RTT, optional NACKs).
* Bounded AIMD rate adaptation from that feedback (``optimisation.rate_control``).
* EXPERIMENTAL NACK-based retransmission (off by default). It provides no
  ordering, no congestion-control guarantees and none of TCP's or QUIC's
  semantics; it exists to study retransmission/duplicate accounting.
* Accounting includes an IPv4+UDP header estimate (28 B), retransmissions and
  duplicates.
"""

from __future__ import annotations

import asyncio
import json
import struct
import time

from .framing import (FLAG_CONTROL, FLAG_ECHO_REQ, FLAG_FEEDBACK, FLAG_FIN, FLAG_RESPONSE, HEADER_SIZE,
                      IPV4_UDP_OVERHEAD, FrameError, FrameHeader, encode_frame, unpack_header)
from .rx import RxTracker

FEEDBACK = struct.Struct("!QQIIQQH")
MAX_UDP_PAYLOAD = 60_000
AUX_WANT_NACK = 0x1


class _Proto(asyncio.DatagramProtocol):
    def __init__(self, owner) -> None:
        self.owner = owner

    def connection_made(self, transport) -> None:
        self.owner.transport = transport

    def datagram_received(self, data, addr) -> None:
        self.owner.on_datagram(data, addr)

    def error_received(self, exc) -> None:
        self.owner.errors += 1


class _Peer:
    def __init__(self) -> None:
        self.flows: dict[int, RxTracker] = {}
        self.dirty: set[int] = set()
        self.want_nack: set[int] = set()
        self.last_seen = time.monotonic()


class UDPServer:
    def __init__(self, host: str = "127.0.0.1", port: int = 0, feedback_interval_s: float = 0.02,
                 max_peers: int = 64, idle_timeout_s: float = 30.0) -> None:
        self.host, self.port = host, port
        self.fb_interval = feedback_interval_s
        self.max_peers = max_peers
        self.idle = idle_timeout_s
        self.peers: dict[tuple, _Peer] = {}
        self.transport = None
        self.errors = 0
        self.bad = 0
        self.refused = 0
        self._task: asyncio.Task | None = None

    async def start(self) -> int:
        loop = asyncio.get_running_loop()
        await loop.create_datagram_endpoint(lambda: _Proto(self), local_addr=(self.host, self.port))
        self.port = self.transport.get_extra_info("sockname")[1]
        self._task = loop.create_task(self._feedback_loop())
        return self.port

    async def close(self) -> None:
        if self._task:
            self._task.cancel()
        if self.transport:
            self.transport.close()

    def on_datagram(self, data: bytes, addr) -> None:
        try:
            hdr = unpack_header(data)
        except FrameError:
            self.bad += 1
            return
        peer = self.peers.get(addr)
        if peer is None:
            if len(self.peers) >= self.max_peers:
                self.refused += 1
                return
            peer = self.peers[addr] = _Peer()
        peer.last_seen = time.monotonic()
        if hdr.flags & FLAG_CONTROL and hdr.flags & FLAG_FIN:
            stats = {str(k): t.summary(one_way_valid=bool(hdr.aux & 1)) for k, t in peer.flows.items()}
            payload = json.dumps(stats).encode()[:MAX_UDP_PAYLOAD]
            self.transport.sendto(encode_frame(FrameHeader(FLAG_CONTROL | FLAG_RESPONSE, 0, hdr.seq, 0, 0, 1,
                                                           hdr.send_ts_ns, len(payload)), payload), addr)
            return
        tr = peer.flows.get(hdr.flow_id)
        if tr is None:
            tr = peer.flows[hdr.flow_id] = RxTracker(hdr.flow_id, IPV4_UDP_OVERHEAD)
        tr.on_frame(hdr.seq, hdr.send_ts_ns, hdr.payload_len, len(data))
        if hdr.flags & FLAG_ECHO_REQ:
            n = min(hdr.aux, MAX_UDP_PAYLOAD)
            self.transport.sendto(encode_frame(FrameHeader(FLAG_RESPONSE, hdr.flow_id, hdr.seq, hdr.msg_id, 0, 1,
                                                           hdr.send_ts_ns, n), b"\0" * n), addr)
            return
        peer.dirty.add(hdr.flow_id)
        if hdr.aux & AUX_WANT_NACK:
            peer.want_nack.add(hdr.flow_id)

    async def _feedback_loop(self) -> None:
        while True:
            await asyncio.sleep(self.fb_interval)
            now_mono = time.monotonic()
            now = time.monotonic_ns()
            for addr, peer in list(self.peers.items()):
                if now_mono - peer.last_seen > self.idle:
                    del self.peers[addr]
                    continue
                for fid in list(peer.dirty):
                    tr = peer.flows[fid]
                    nacks = []
                    if fid in peer.want_nack:
                        for s in tr.missing(limit=64):
                            c = tr.nack_reported.get(s, 0)
                            if c < 3:
                                tr.nack_reported[s] = c + 1
                                nacks.append(s)
                    body = FEEDBACK.pack(max(tr.highest, 0), tr.unique, tr.dups, tr.reordered, tr.last_send_ts,
                                         now - tr.last_recv_ns, len(nacks)) + b"".join(struct.pack("!Q", s) for s in nacks)
                    self.transport.sendto(encode_frame(FrameHeader(FLAG_FEEDBACK, fid, 0, 0, 0, 1, now, len(body)),
                                                       body), addr)
                peer.dirty.clear()


def parse_feedback(payload: bytes) -> dict:
    highest, unique, dups, reord, echo_ts, hold_ns, n = FEEDBACK.unpack_from(payload, 0)
    nacks = [struct.unpack_from("!Q", payload, FEEDBACK.size + 8 * i)[0] for i in range(n)]
    return {"highest": highest, "unique": unique, "dups": dups, "reordered": reord, "echo_ts_ns": echo_ts,
            "hold_ns": hold_ns, "nacks": nacks}


class UDPClientAdapter:
    name = "udp"
    wire_overhead = IPV4_UDP_OVERHEAD

    def __init__(self, ip: str, port: int, write_high_water: int = 1 << 20) -> None:
        self.ip, self.port = ip, port
        self.high = write_high_water
        self.transport = None
        self.pending: dict[tuple[int, int], tuple[asyncio.Future, int]] = {}
        self.feedback_handlers: dict[int, callable] = {}
        self.control: asyncio.Future | None = None
        self.frames_sent = 0
        self.bytes_sent = 0
        self.payload_sent = 0
        self.errors = 0
        self.backpressure_waits = 0
        self.feedback_frames = 0

    async def connect(self) -> None:
        loop = asyncio.get_running_loop()
        await loop.create_datagram_endpoint(lambda: _Proto(self), remote_addr=(self.ip, self.port))

    def send_nowait(self, hdr: FrameHeader, payload: bytes) -> int:
        frame = encode_frame(hdr, payload)
        self.transport.sendto(frame)
        self.frames_sent += 1
        self.bytes_sent += len(frame)
        self.payload_sent += len(payload)
        return len(frame) + self.wire_overhead

    async def send(self, hdr: FrameHeader, payload: bytes) -> int:
        n = self.send_nowait(hdr, payload)
        while self.transport.get_write_buffer_size() > self.high:  # explicit backpressure
            self.backpressure_waits += 1
            await asyncio.sleep(0.001)
        return n

    async def request(self, hdr: FrameHeader, payload: bytes, timeout_s: float) -> tuple[float, int]:
        fut = asyncio.get_running_loop().create_future()
        key = (hdr.flow_id, hdr.seq)
        t0 = time.monotonic_ns()
        self.pending[key] = (fut, t0)
        try:
            await self.send(hdr, payload)
            n = await asyncio.wait_for(fut, timeout_s)
            return (time.monotonic_ns() - t0) / 1e9, n
        finally:
            self.pending.pop(key, None)

    def on_datagram(self, data: bytes, addr) -> None:
        try:
            hdr = unpack_header(data)
        except FrameError:
            self.errors += 1
            return
        if hdr.flags & FLAG_CONTROL:
            if self.control and not self.control.done():
                self.control.set_result(data[HEADER_SIZE:])
        elif hdr.flags & FLAG_FEEDBACK:
            self.feedback_frames += 1
            h = self.feedback_handlers.get(hdr.flow_id)
            if h:
                h(parse_feedback(data[HEADER_SIZE:]))
        elif hdr.flags & FLAG_RESPONSE:
            ent = self.pending.get((hdr.flow_id, hdr.seq))
            if ent and not ent[0].done():
                ent[0].set_result(hdr.payload_len)

    async def fin(self, one_way_valid: bool, timeout_s: float = 1.0, retries: int = 3) -> dict:
        for _ in range(retries):
            self.control = asyncio.get_running_loop().create_future()
            self.send_nowait(FrameHeader(FLAG_CONTROL | FLAG_FIN, 0, 0, 0, 0, 1, time.monotonic_ns(), 0,
                                         1 if one_way_valid else 0), b"")
            try:
                raw = await asyncio.wait_for(self.control, timeout_s)
                return json.loads(raw)
            except asyncio.TimeoutError:
                continue
        return {"error": "no FIN response from server (stats unavailable)"}

    async def close(self) -> None:
        if self.transport:
            self.transport.close()
