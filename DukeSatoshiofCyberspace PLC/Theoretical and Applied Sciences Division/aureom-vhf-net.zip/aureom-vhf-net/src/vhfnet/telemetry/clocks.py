"""Clock discipline for LIVE TEST measurements.

* Elapsed times and RTTs always use the monotonic clock (``time.monotonic_ns`` /
  ``time.perf_counter_ns``), never wall-clock time.
* One-way delay requires sender and receiver timestamps on a *common* time base.
  - ``same_host``: CLOCK_MONOTONIC is shared by all processes on one host, so
    receiver_ts - sender_ts is a valid one-way delay.
  - ``ptp`` / ``ntp``: reported only together with the user-declared error bound.
  - ``none`` (unsynchronised machines): timestamp differences contain an unknown
    clock offset and are NOT reported as latency; only RTT is reported.
"""

from __future__ import annotations

import time
from dataclasses import dataclass


def mono_ns() -> int:
    return time.monotonic_ns()


@dataclass(frozen=True)
class ClockPolicy:
    sync: str  # same_host | ptp | ntp | none
    error_bound_ms: float | None = None

    @property
    def one_way_valid(self) -> bool:
        return self.sync in ("same_host", "ptp", "ntp")

    def describe(self) -> str:
        if self.sync == "same_host":
            return "one-way delay valid: sender and receiver share CLOCK_MONOTONIC on one host"
        if self.sync in ("ptp", "ntp"):
            return f"one-way delay reported with declared {self.sync.upper()} error bound +/- {self.error_bound_ms} ms"
        return "clocks unsynchronised: one-way delay NOT reported; RTT only"
