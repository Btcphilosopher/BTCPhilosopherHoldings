"""JSON/CSV export helpers (NaN/inf -> null, NumPy -> Python)."""

from __future__ import annotations

import csv
import hashlib
import io
import json
import math
from pathlib import Path
from typing import Any, Iterable

import numpy as np


def to_jsonable(x: Any) -> Any:
    if isinstance(x, dict):
        return {str(k): to_jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [to_jsonable(v) for v in x]
    if isinstance(x, np.ndarray):
        return [to_jsonable(v) for v in x.tolist()]
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (float, np.floating)):
        v = float(x)
        return v if math.isfinite(v) else None
    if hasattr(x, "model_dump"):
        return to_jsonable(x.model_dump())
    return x


def round_floats(x: Any, digits: int = 9) -> Any:
    if isinstance(x, dict):
        return {k: round_floats(v, digits) for k, v in x.items()}
    if isinstance(x, list):
        return [round_floats(v, digits) for v in x]
    if isinstance(x, float):
        return float(f"{x:.{digits}g}")
    return x


def fingerprint(obj: Any, exclude: Iterable[str] = ("resources",)) -> str:
    """SHA-256 over the canonical JSON of a result, excluding host-dependent sections."""
    if isinstance(obj, dict):
        obj = {k: v for k, v in obj.items() if k not in set(exclude) and k != "fingerprint"}
    blob = json.dumps(round_floats(to_jsonable(obj)), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode()).hexdigest()


def write_json(path: str | Path, obj: Any, digits: int | None = 7) -> None:
    """Write JSON; floats rounded to ``digits`` significant digits (exported precision, not
    simulation precision -- fingerprints are computed before export)."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    data = to_jsonable(obj)
    if digits:
        data = round_floats(data, digits)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=None, separators=(",", ":"), sort_keys=False)


def rows_to_csv(rows: list[dict], path: str | Path | None = None) -> str:
    if not rows:
        text = ""
    else:
        cols: list[str] = []
        for r in rows:
            for k in r:
                if k not in cols:
                    cols.append(k)
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: _cell(r.get(k)) for k in cols})
        text = buf.getvalue()
    if path is not None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(text, encoding="utf-8")
    return text


def _cell(v: Any) -> Any:
    v = to_jsonable(v)
    if isinstance(v, (dict, list)):
        return json.dumps(v, sort_keys=True)
    return "" if v is None else v


def flatten(d: dict, prefix: str = "") -> dict:
    out = {}
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(flatten(v, key + "."))
        else:
            out[key] = v
    return out
