"""SQLite store for experiment metadata (not bulk data: results live in JSON/CSV files)."""

from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from typing import Any

SCHEMA = """
CREATE TABLE IF NOT EXISTS experiments (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    mode TEXT NOT NULL CHECK (mode IN ('SIMULATION', 'LIVE TEST')),
    created_at REAL NOT NULL,
    finished_at REAL,
    status TEXT NOT NULL,
    description TEXT,
    results_dir TEXT,
    config_json TEXT,
    host_json TEXT,
    summary_json TEXT
);
CREATE TABLE IF NOT EXISTS runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    experiment_id TEXT NOT NULL REFERENCES experiments(id),
    mode TEXT NOT NULL,
    scenario TEXT,
    policy TEXT,
    seed INTEGER,
    fingerprint TEXT,
    wall_s REAL,
    headline_json TEXT,
    result_path TEXT,
    created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS runs_exp ON runs(experiment_id);
"""


class ExperimentStore:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._db = sqlite3.connect(str(self.path), check_same_thread=False, timeout=30)
        self._db.row_factory = sqlite3.Row
        with self._lock:
            self._db.executescript(SCHEMA)
            self._db.commit()

    def close(self) -> None:
        with self._lock:
            self._db.close()

    def create_experiment(self, name: str, mode: str, config: Any = None, description: str = "",
                          results_dir: str | None = None, host: dict | None = None) -> str:
        eid = time.strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:6]
        with self._lock:
            self._db.execute(
                "INSERT INTO experiments (id, name, mode, created_at, status, description, results_dir, config_json, host_json)"
                " VALUES (?,?,?,?,?,?,?,?,?)",
                (eid, name, mode, time.time(), "running", description, results_dir,
                 json.dumps(config, default=str) if config is not None else None,
                 json.dumps(host) if host else None))
            self._db.commit()
        return eid

    def add_run(self, experiment_id: str, mode: str, scenario: str | None, policy: str | None, seed: int | None,
                fingerprint: str | None, wall_s: float | None, headline: dict, result_path: str | None) -> int:
        with self._lock:
            cur = self._db.execute(
                "INSERT INTO runs (experiment_id, mode, scenario, policy, seed, fingerprint, wall_s, headline_json,"
                " result_path, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (experiment_id, mode, scenario, policy, seed, fingerprint, wall_s, json.dumps(headline, default=str),
                 result_path, time.time()))
            self._db.commit()
            return int(cur.lastrowid)

    def finish_experiment(self, experiment_id: str, status: str, summary: dict | None = None) -> None:
        with self._lock:
            self._db.execute("UPDATE experiments SET status=?, finished_at=?, summary_json=? WHERE id=?",
                             (status, time.time(), json.dumps(summary, default=str) if summary else None,
                              experiment_id))
            self._db.commit()

    def list_experiments(self, limit: int = 100) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                "SELECT e.id, e.name, e.mode, e.created_at, e.finished_at, e.status, e.description, e.results_dir,"
                " (SELECT COUNT(*) FROM runs r WHERE r.experiment_id = e.id) AS n_runs"
                " FROM experiments e ORDER BY e.created_at DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    def get_experiment(self, experiment_id: str) -> dict | None:
        with self._lock:
            r = self._db.execute("SELECT * FROM experiments WHERE id=?", (experiment_id,)).fetchone()
        if r is None:
            return None
        d = dict(r)
        for k in ("config_json", "host_json", "summary_json"):
            if d.get(k):
                d[k[:-5]] = json.loads(d.pop(k))
            else:
                d.pop(k, None)
        return d

    def list_runs(self, experiment_id: str) -> list[dict]:
        with self._lock:
            rows = self._db.execute("SELECT * FROM runs WHERE experiment_id=? ORDER BY id", (experiment_id,)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["headline"] = json.loads(d.pop("headline_json") or "{}")
            out.append(d)
        return out
