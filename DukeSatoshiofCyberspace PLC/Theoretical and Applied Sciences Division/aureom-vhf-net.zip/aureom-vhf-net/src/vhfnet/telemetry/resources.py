"""Host resource measurement: CPU, memory, asyncio event-loop delay."""

from __future__ import annotations

import asyncio
import os
import platform
import resource
import sys
import time

import numpy as np

try:  # optional
    import psutil
except ImportError:  # pragma: no cover
    psutil = None


def peak_rss_mb() -> float:
    r = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return r / 1024.0 if sys.platform != "darwin" else r / 1024.0 / 1024.0


def host_info() -> dict:
    info = {
        "python": sys.version.split()[0],
        "implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    try:
        import numpy, scipy, simpy, pydantic  # noqa: E401
        info.update(numpy=numpy.__version__, scipy=scipy.__version__, simpy=simpy.__version__,
                    pydantic=pydantic.__version__)
    except Exception:  # pragma: no cover
        pass
    return info


class ResourceSampler:
    """Samples process CPU% and RSS while a live test runs."""

    def __init__(self, interval_s: float = 0.25) -> None:
        self.interval = interval_s
        self.samples: list[tuple[float, float, float]] = []
        self._task: asyncio.Task | None = None
        self._proc = psutil.Process() if psutil else None
        self._cpu0 = time.process_time()
        self._t0 = time.monotonic()

    async def _run(self) -> None:
        if self._proc:
            self._proc.cpu_percent(None)
        while True:
            await asyncio.sleep(self.interval)
            if self._proc:
                cpu = self._proc.cpu_percent(None)
                rss = self._proc.memory_info().rss / 2**20
            else:
                cpu, rss = float("nan"), peak_rss_mb()
            self.samples.append((time.monotonic() - self._t0, cpu, rss))

    def start(self) -> None:
        self._task = asyncio.get_running_loop().create_task(self._run())

    async def stop(self) -> dict:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        cpu_s = time.process_time() - self._cpu0
        wall = time.monotonic() - self._t0
        cpus = np.array([s[1] for s in self.samples]) if self.samples else np.array([np.nan])
        rss = np.array([s[2] for s in self.samples]) if self.samples else np.array([peak_rss_mb()])
        return {
            "cpu_time_s": cpu_s,
            "wall_s": wall,
            "cpu_util_mean_pct": float(np.nanmean(cpus)) if np.isfinite(cpus).any() else None,
            "cpu_util_max_pct": float(np.nanmax(cpus)) if np.isfinite(cpus).any() else None,
            "rss_max_mb": float(np.nanmax(rss)),
            "samples": [list(s) for s in self.samples[:: max(1, len(self.samples) // 200)]],
        }


class LoopLagMonitor:
    """Event-loop delay: how late ``asyncio.sleep(interval)`` wakes up (monotonic clock)."""

    def __init__(self, interval_s: float = 0.005) -> None:
        self.interval = interval_s
        self.lags: list[float] = []
        self._task: asyncio.Task | None = None

    async def _run(self) -> None:
        while True:
            t0 = time.perf_counter()
            await asyncio.sleep(self.interval)
            self.lags.append(max(0.0, time.perf_counter() - t0 - self.interval))

    def start(self) -> None:
        self._task = asyncio.get_running_loop().create_task(self._run())

    async def stop(self) -> dict:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        lag = np.asarray(self.lags) * 1e3
        if lag.size == 0:
            return {"samples": 0}
        return {"samples": int(lag.size), "p50_ms": float(np.percentile(lag, 50)),
                "p99_ms": float(np.percentile(lag, 99)), "max_ms": float(lag.max()),
                "definition": f"wake-up overshoot of asyncio.sleep({self.interval*1e3:.1f} ms)"}
