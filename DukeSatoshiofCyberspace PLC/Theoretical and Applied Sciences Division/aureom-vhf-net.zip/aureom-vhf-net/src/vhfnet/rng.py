"""Named, order-independent random streams.

Every stochastic component draws from its own stream derived from
``(experiment seed, component name)``. Adding a flow or changing a routing policy
therefore does not perturb the random draws of unrelated components, which lets
policy comparisons use *common random numbers* (identical traffic and channel
realisations for every policy under the same seed).
"""

from __future__ import annotations

import hashlib

import numpy as np


def stable_hash(name: str) -> int:
    return int.from_bytes(hashlib.blake2b(name.encode("utf-8"), digest_size=8).digest(), "little")


def stream(seed: int, *names: str) -> np.random.Generator:
    key = [int(seed) & 0xFFFFFFFFFFFFFFFF] + [stable_hash(n) for n in names]
    return np.random.Generator(np.random.PCG64(np.random.SeedSequence(key)))


class UniformBuffer:
    """Block-buffered scalar uniforms (avoids per-call NumPy overhead in hot loops)."""

    __slots__ = ("_rng", "_buf", "_i", "_block")

    def __init__(self, rng: np.random.Generator, block: int = 4096) -> None:
        self._rng = rng
        self._block = block
        self._buf = rng.random(block)
        self._i = 0

    def __call__(self) -> float:
        if self._i >= self._block:
            self._buf = self._rng.random(self._block)
            self._i = 0
        v = self._buf[self._i]
        self._i += 1
        return float(v)
