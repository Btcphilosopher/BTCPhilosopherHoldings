"""Aureom.AI VHF.NET -- an inspectable internet-performance laboratory.

"VHF" is the product label for the high-rate message-processing pipeline; it is
not a radio band. See :mod:`vhfnet.units` for how packet frequency, carrier
frequency, channel bandwidth and throughput are kept separate.
"""

__version__ = "0.9.0"
PRODUCT = "Aureom.AI VHF.NET"
