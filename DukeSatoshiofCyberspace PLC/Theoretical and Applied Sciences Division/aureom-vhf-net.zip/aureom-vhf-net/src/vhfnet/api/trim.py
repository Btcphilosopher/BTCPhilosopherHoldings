"""Shapes shared by the API and the static report (topology view, trimmed runs)."""

from __future__ import annotations

from ..config import ExperimentConfig


def topology_view(cfg: ExperimentConfig) -> dict:
    t = cfg.topology
    return {
        "name": t.name, "fictional": t.fictional, "description": t.description,
        "nodes": [{"id": n.id, "kind": n.kind, "label": n.label or n.id, "x": n.position[0], "y": n.position[1],
                   "processing_delay_us": n.processing_delay_us,
                   "compute": n.compute.model_dump() if n.compute else None} for n in t.nodes],
        "links": [{"id": lk.id, "a": lk.a, "b": lk.b, "kind": lk.kind, "capacity_mbps": lk.capacity_mbps,
                   "capacity_mbps_reverse": lk.capacity_mbps_reverse or lk.capacity_mbps,
                   "propagation_delay_ms": lk.propagation_delay_ms, "discipline": lk.queue.discipline,
                   "buffer_bytes": lk.queue.buffer_bytes, "loss_model": lk.loss.model,
                   "wireless": None if lk.wireless is None else {
                       "model": lk.wireless.model,
                       "carrier_freq_ghz": lk.wireless.link_budget.carrier_freq_ghz if lk.wireless.link_budget else None,
                       "channel_bw_mhz": lk.wireless.link_budget.channel_bw_mhz if lk.wireless.link_budget else None,
                       "assumptions": lk.wireless.assumptions},
                   "energy_per_bit_nj": lk.energy.energy_per_bit_nj} for lk in t.links],
        "flows": [{"id": f.id, "kind": f.kind, "src": f.src, "dst": f.dst, "priority": f.priority,
                   "deadline_ms": f.deadline_ms, "max_rate_mbps": f.max_rate_mbps,
                   "reliability": f.reliability.mode} for f in cfg.flows],
        "services": [s.model_dump() for s in cfg.services],
        "scenarios": [{"id": s.id, "name": s.name, "description": s.description} for s in cfg.scenarios],
        "policies": [{"id": p.id, "label": p.label} for p in cfg.policies],
    }


def _stride(n: int, target: int) -> int:
    return max(1, -(-n // target))  # ceil: never more than ``target`` points


def trim_run(run: dict, max_points: int = 160, max_changes: int = 600, max_jobs: int = 400) -> dict:
    out = {k: v for k, v in run.items() if k not in ("timeseries", "routes", "jobs_sample")}
    ts = run.get("timeseries")
    if ts:
        s = _stride(len(ts["t"]), max_points)
        out["timeseries"] = {
            "t": ts["t"][::s],
            "stride": s,
            "links": {k: {m: v[::s] for m, v in d.items()} for k, d in ts["links"].items()},
            "flows": {k: {m: v[::s] for m, v in d.items()} for k, d in ts["flows"].items()},
            "compute": {k: {m: v[::s] for m, v in d.items()} for k, d in ts["compute"].items()},
            "rate_history": {k: v[:: _stride(len(v), max_points)] for k, v in ts.get("rate_history", {}).items()},
        }
    r = run.get("routes")
    if r:
        out["routes"] = {"count": r["count"], "per_flow": r["per_flow"], "changes": r.get("changes", [])[:max_changes]}
    js = run.get("jobs_sample")
    if js:
        out["jobs_sample"] = js[:: _stride(len(js), max_jobs)]
    for f in out.get("flows", []):
        f.pop("transport", None)
    return out
