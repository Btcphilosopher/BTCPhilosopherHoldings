"""FastAPI control API (also serves the dashboard)."""
