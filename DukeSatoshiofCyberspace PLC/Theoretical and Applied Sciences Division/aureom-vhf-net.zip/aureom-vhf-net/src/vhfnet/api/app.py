"""FastAPI control API + dashboard host.

Every response that carries results states its mode (``SIMULATION`` or
``LIVE TEST``). Simulation requests are bounded (duration, concurrency, wall
time) and cancellable; live requests are limited to loopback presets.
"""

from __future__ import annotations

import asyncio
import csv
import json
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Literal

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .. import PRODUCT, __version__
from ..config import ExperimentConfig, LinkBudgetConfig, PlacementWeights, load_experiment, load_live
from ..edge.placement import analytic_placement
from ..optimisation.bayes import beta_bernoulli, compare_routes, value_of_information
from ..optimisation.montecarlo import PATH_MODEL_ASSUMPTIONS, UncertainInput, path_latency_model, run_monte_carlo
from ..simulation.wireless import link_budget
from ..telemetry.export import to_jsonable, write_json
from .trim import topology_view, trim_run

STATIC_DIR = Path(__file__).resolve().parent.parent / "dashboard" / "static"
MAX_API_SIM_DURATION_S = 30.0
MAX_API_SIM_WALL_S = 120.0


class SimulateRequest(BaseModel):
    scenario: str = "baseline"
    policy: str = "adaptive"
    seed: int = Field(1, ge=0, le=2**31)
    duration_s: float | None = Field(None, gt=0, le=MAX_API_SIM_DURATION_S)


class LiveRequest(BaseModel):
    preset: Literal["loopback_tcp", "loopback_udp", "loopback_quic"] = "loopback_udp"
    duration_scale: float = Field(1.0, gt=0, le=1.0, description="shorten preset flows (never lengthen)")


class MonteCarloRequest(BaseModel):
    draws: int = Field(20000, ge=1000, le=200_000)
    seed: int = 0
    message_bytes: float = Field(60000, gt=0)
    deadline_ms: float = Field(100, gt=0)
    links: list[dict] = Field(default_factory=lambda: [
        {"name": "access", "cap_mbps": [80, 0.25], "load_mbps": [30, 60], "prop_ms": [0.05, 0.05], "loss": [2, 2000]},
        {"name": "backhaul", "cap_mbps": [200, 0.1], "load_mbps": [40, 120], "prop_ms": [2, 3], "loss": [1, 20000]},
        {"name": "cloud", "cap_mbps": [400, 0.1], "load_mbps": [50, 200], "prop_ms": [10, 14], "loss": [1, 50000]},
    ])


class BayesRequest(BaseModel):
    events_a: int = Field(..., ge=0)
    trials_a: int = Field(..., ge=1)
    events_b: int = Field(..., ge=0)
    trials_b: int = Field(..., ge=1)
    prior: tuple[float, float] = (1.0, 1.0)
    n_extra: int = Field(500, ge=1, le=10_000_000)
    future_messages: float = Field(100_000, gt=0)
    cost_per_measurement: float = Field(0.0, ge=0)
    seed: int = 0


class PlacementRequest(BaseModel):
    input_bytes: float = Field(60000, gt=0)
    output_bytes: float = Field(4000, ge=0)
    work_gop: float = Field(3.0, gt=0)
    edge_background_jobs_per_s: float = Field(0.0, ge=0)
    access_mbps: float = Field(80.0, gt=0)
    weights: PlacementWeights = Field(default_factory=PlacementWeights)


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with open(path, newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    out = []
    for r in rows:
        d = {}
        for k, v in r.items():
            if v == "":
                d[k] = None
                continue
            try:
                d[k] = float(v) if any(c in v for c in ".eE") or v.lstrip("-").isdigit() else v
                if isinstance(d[k], float) and d[k].is_integer() and v.lstrip("-").isdigit():
                    d[k] = int(v)
            except ValueError:
                d[k] = {"True": True, "False": False}.get(v, v)
        out.append(d)
    return out


def create_app(results_dir: str | Path = "results", config_path: str | Path = "configs/experiments/demo.yaml",
               live_config_dir: str | Path = "configs/live", enable_live: bool = True) -> FastAPI:
    results = Path(results_dir).resolve()
    results.mkdir(parents=True, exist_ok=True)
    cfg_path = Path(config_path)
    live_dir = Path(live_config_dir)
    app = FastAPI(title=f"{PRODUCT} control API", version=__version__)
    sim_lock = asyncio.Semaphore(1)
    live_lock = asyncio.Semaphore(1)
    state: dict[str, Any] = {"cfg": None}

    def cfg() -> ExperimentConfig:
        if state["cfg"] is None:
            state["cfg"] = load_experiment(cfg_path)
        return state["cfg"]

    def exp_dir(name: str) -> Path:
        d = (results / name).resolve()
        if results not in d.parents or not (d / "manifest.json").exists():
            raise HTTPException(404, f"unknown experiment {name}")
        return d

    @app.get("/api/health")
    def health():
        return {"ok": True, "version": __version__}

    @app.get("/api/meta")
    def meta():
        return {"product": PRODUCT, "version": __version__, "modes": ["SIMULATION", "LIVE TEST"],
                "live_enabled": enable_live, "static": False,
                "vhf_label": "VHF = high-rate message-processing pipeline label (not a radio band)",
                "units": {"packet_rate": "pkt/s", "carrier_frequency": "Hz", "channel_bandwidth": "Hz",
                          "throughput": "bit/s"}}

    @app.get("/api/topology")
    def topology():
        return topology_view(cfg())

    @app.get("/api/experiments")
    def experiments():
        out = []
        for m in sorted(results.glob("*/manifest.json")):
            man = json.loads(m.read_text())
            out.append({"name": m.parent.name, "title": man.get("name"), "mode": man.get("mode"),
                        "runs": man.get("runs"), "seeds": man.get("seeds"), "created_unix": man.get("created_unix"),
                        "scenarios": man.get("scenarios"), "policies": man.get("policies"),
                        "reference_policy": man.get("reference_policy")})
        return out

    @app.get("/api/experiments/{name}/manifest")
    def manifest(name: str):
        return json.loads((exp_dir(name) / "manifest.json").read_text())

    @app.get("/api/experiments/{name}/comparison")
    def comparison(name: str):
        return json.loads((exp_dir(name) / "comparison.json").read_text())

    @app.get("/api/experiments/{name}/aggregate")
    def aggregate(name: str):
        return _read_csv(exp_dir(name) / "aggregate.csv")

    @app.get("/api/experiments/{name}/runs")
    def runs(name: str):
        return _read_csv(exp_dir(name) / "runs.csv")

    @app.get("/api/experiments/{name}/run/{scenario}/{policy}/{seed}")
    def run(name: str, scenario: str, policy: str, seed: int, full: bool = False):
        p = (exp_dir(name) / "runs" / scenario / policy / f"seed{seed}.json").resolve()
        if results not in p.parents or not p.exists():
            raise HTTPException(404, "run not found")
        data = json.loads(p.read_text())
        return data if full else trim_run(data)

    @app.post("/api/simulate")
    async def simulate(req: SimulateRequest):
        from ..simulation.engine import Simulation, SimulationCancelled, SimulationLimitExceeded

        c = cfg()
        try:
            c.scenario(req.scenario)
            c.policy(req.policy)
        except KeyError as e:
            raise HTTPException(400, str(e))
        bounded = c.model_copy(update={"limits": c.limits.model_copy(update={"max_wall_s": MAX_API_SIM_WALL_S})})
        if sim_lock.locked():
            raise HTTPException(429, "a simulation is already running (concurrency limit 1)")
        cancel = threading.Event()
        async with sim_lock:
            try:
                sim = Simulation(bounded, req.scenario, req.policy, req.seed, cancel=cancel,
                                 duration_s=req.duration_s or min(c.duration_s, MAX_API_SIM_DURATION_S))
                res = await asyncio.wait_for(asyncio.to_thread(sim.run), MAX_API_SIM_WALL_S + 5)
            except asyncio.TimeoutError:
                cancel.set()
                raise HTTPException(504, "simulation exceeded wall-time limit and was cancelled")
            except (SimulationLimitExceeded, SimulationCancelled) as e:
                raise HTTPException(422, str(e))
        rid = time.strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:6]
        write_json(results / "api_runs" / f"{rid}.json", res)
        out = trim_run(res)
        out["api_run_id"] = rid
        return JSONResponse(to_jsonable(out))

    @app.get("/api/live")
    def live_list():
        d = results / "live"
        out = []
        for p in sorted(d.glob("*.json")):
            r = json.loads(p.read_text())
            out.append({"id": p.stem, "name": r["meta"]["name"], "transport": r["meta"]["transport"],
                        "mode": r["meta"]["mode"], "totals": r["totals"]})
        return out

    @app.get("/api/live/{rid}")
    def live_get(rid: str):
        p = (results / "live" / f"{rid}.json").resolve()
        if results not in p.parents or not p.exists():
            raise HTTPException(404, "live result not found")
        return json.loads(p.read_text())

    @app.post("/api/live")
    async def live_run(req: LiveRequest):
        if not enable_live:
            raise HTTPException(403, "live tests disabled on this server (--no-live)")
        from ..transport.live import run_live

        lc = load_live(live_dir / f"{req.preset}.yaml")
        if req.duration_scale < 1.0:
            lc = lc.model_copy(update={"flows": [f.model_copy(update={"duration_s": f.duration_s * req.duration_scale})
                                                 for f in lc.flows]})
        if live_lock.locked():
            raise HTTPException(429, "a live test is already running")
        async with live_lock:
            res = await asyncio.wait_for(asyncio.to_thread(run_live, lc, True), lc.max_duration_s + 60)
        rid = time.strftime("%Y%m%dT%H%M%S") + f"-{lc.transport}"
        write_json(results / "live" / f"{rid}.json", res)
        res["id"] = rid
        return JSONResponse(to_jsonable(res))

    @app.post("/api/montecarlo")
    def montecarlo(req: MonteCarloRequest):
        inputs = []
        for i, lk in enumerate(req.links):
            inputs += [
                UncertainInput(f"cap_{i}", "lognormal", (lk["cap_mbps"][0] * 1e6, lk["cap_mbps"][1]), "bit/s",
                               f"{lk['name']} capacity (median, log-sd)"),
                UncertainInput(f"load_{i}", "uniform", (lk["load_mbps"][0] * 1e6, lk["load_mbps"][1] * 1e6), "bit/s",
                               f"{lk['name']} background load"),
                UncertainInput(f"prop_{i}", "uniform", (lk["prop_ms"][0] / 1e3, lk["prop_ms"][1] / 1e3 + 1e-12), "s",
                               f"{lk['name']} propagation delay"),
                UncertainInput(f"loss_{i}", "beta", tuple(lk["loss"]), "probability", f"{lk['name']} loss"),
            ]
        model = path_latency_model(len(req.links), req.message_bytes)
        r = run_monte_carlo(inputs, lambda X: model(X) * 1e3, draws=req.draws, seed=req.seed,
                            outcome="message latency", unit="ms", thresholds=[req.deadline_ms],
                            assumptions=PATH_MODEL_ASSUMPTIONS)
        return to_jsonable({"mode": "ANALYTIC MODEL (Monte Carlo)", **r.to_dict()})

    @app.post("/api/bayes")
    def bayes(req: BayesRequest):
        a = beta_bernoulli([1] * req.events_a + [0] * (req.trials_a - req.events_a), req.prior)
        b = beta_bernoulli([1] * req.events_b + [0] * (req.trials_b - req.events_b), req.prior)
        return to_jsonable({
            "assumption": "independent Bernoulli outcomes; use method=ess/blocks on raw series when correlated",
            "route_a": a.to_dict(), "route_b": b.to_dict(), "comparison": compare_routes(a, b, seed=req.seed),
            "value_of_information": value_of_information(a, b, req.n_extra, req.future_messages,
                                                         req.cost_per_measurement, seed=req.seed)})

    @app.post("/api/linkbudget")
    def linkbudget(lb: LinkBudgetConfig, extra_loss_db: float = 0.0, inr_db: float | None = None):
        import numpy as np

        ds = np.geomspace(max(1.0, lb.distance_m / 20), lb.distance_m * 20, 60)
        rows = [link_budget(lb, float(d), extra_loss_db, inr_db).__dict__ for d in ds]
        return to_jsonable({"mode": "ANALYTIC MODEL (link budget)", "rows": rows,
                            "nominal": link_budget(lb, None, extra_loss_db, inr_db).__dict__})

    @app.post("/api/placement")
    def placement(req: PlacementRequest):
        c = cfg()
        nodes = {n.id: n for n in c.topology.nodes}
        acc = req.access_mbps * 1e6
        cands = [
            {"node": "ue-1 (local)", "compute": nodes["ue-1"].compute.model_dump(), "local": True,
             "path_delay_s": 0, "bottleneck_bps": 1e12},
            {"node": "edge-1", "compute": nodes["edge-1"].compute.model_dump(), "path_delay_s": 0.0004,
             "bottleneck_bps": acc, "background_rate_jobs_per_s": req.edge_background_jobs_per_s,
             "energy_per_bit_nj": 22},
            {"node": "cloud-1", "compute": nodes["cloud-1"].compute.model_dump(), "path_delay_s": 0.0145,
             "bottleneck_bps": acc, "energy_per_bit_nj": 37},
        ]
        return to_jsonable({"mode": "ANALYTIC MODEL (M/M/c placement estimate)",
                            "rows": analytic_placement(req.input_bytes, req.output_bytes, req.work_gop, cands,
                                                       req.weights)})

    vendor = _plotly_js()

    @app.get("/static/vendor/plotly.min.js")
    def plotly_js():
        if vendor is None:
            raise HTTPException(404, "plotly package not installed")
        return FileResponse(vendor, media_type="application/javascript")

    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    @app.get("/", response_class=HTMLResponse)
    def index():
        return HTMLResponse((STATIC_DIR / "index.html").read_text(encoding="utf-8"))

    return app


def _plotly_js() -> Path | None:
    try:
        import plotly

        p = Path(plotly.__file__).parent / "package_data" / "plotly.min.js"
        return p if p.exists() else None
    except ImportError:  # pragma: no cover
        return None
