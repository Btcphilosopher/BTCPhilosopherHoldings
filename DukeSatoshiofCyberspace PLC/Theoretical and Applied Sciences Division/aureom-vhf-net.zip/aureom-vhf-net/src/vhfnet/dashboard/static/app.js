/* Aureom.AI VHF.NET console. Works against the FastAPI server or a static bundle (window.VHF_STATIC). */
(() => {
  "use strict";
  const STATIC = window.VHF_STATIC || null;
  const C = {
    text: "#f1ead9", text2: "#c6bfad", muted: "#8f8a7c", hair: "#2b3038", hair2: "#3a404a", surface: "#17191d",
    gold: "#c9a45c", blue: "#3987e5",
    series: ["#3987e5", "#d95926", "#199e70", "#c98500", "#d55181", "#008300", "#9085e9", "#e66767"],
    good: "#0ca30c", warning: "#fab219", serious: "#ec835a", critical: "#d03b3b",
    seq: ["#1f2632", "#184f95", "#1c5cab", "#256abf", "#2a78d6", "#3987e5", "#5598e7", "#6da7ec", "#86b6ef", "#9ec5f4", "#cde2fb"],
  };
  const MONO = '"IBM Plex Mono","JetBrains Mono","SFMono-Regular",Menlo,Consolas,monospace';
  const STATUS = { ok: C.good, late: C.warning, timeout: C.serious, rejected: C.critical, incomplete: C.muted };
  const VERDICT = { better: ["▲", "better", "v-better"], worse: ["▼", "worse", "v-worse"],
    inconclusive: ["◆", "inconclusive", "v-inconclusive"], "no-difference": ["=", "identical", "v-same"],
    "insufficient-data": ["·", "n/a", "v-same"] };

  const state = { mode: "SIMULATION", tab: "topology", meta: null, topo: null, exps: [], exp: null, manifest: null,
    comparison: null, aggregate: null, runsTable: null, scen: null, pol: null, seed: null, run: null, runCache: {},
    live: [], liveSel: null, liveRun: null, apiRun: null, metric: "deadline_miss_ratio", altPol: null };

  // ------------------------------------------------------------------ data access
  const cache = {};
  async function api(path, opts) {
    if (STATIC) {
      if (opts && opts.method && opts.method !== "GET") throw new Error("Interactive runs need the API server (vhfnet serve). This is a static report.");
      if (!(path in STATIC.routes)) throw new Error("not included in this static report: " + path);
      return STATIC.routes[path];
    }
    if (!opts && cache[path]) return cache[path];
    const r = await fetch(path, opts);
    if (!r.ok) { let m = r.statusText; try { m = (await r.json()).detail || m; } catch (e) { /* ignore */ } throw new Error(`${r.status}: ${m}`); }
    const j = await r.json();
    if (!opts) cache[path] = j;
    return j;
  }
  const post = (path, body) => api(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });

  // ------------------------------------------------------------------ helpers
  function el(tag, attrs, ...kids) {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === "class") n.className = v; else if (k === "html") n.innerHTML = v;
      else if (k.startsWith("on")) n.addEventListener(k.slice(2), v); else n.setAttribute(k, v === true ? "" : v);
    }
    for (const kid of kids.flat()) { if (kid == null || kid === false) continue; n.append(kid instanceof Node ? kid : document.createTextNode(String(kid))); }
    return n;
  }
  function card(title, sub, span, ...body) {
    return el("div", { class: `card ${span ? "span-" + span : ""}` }, el("h3", {}, title), sub ? el("p", { class: "sub" }, sub) : null, ...body);
  }
  const chart = (cls) => el("div", { class: "chart " + (cls || "") });
  const isNum = (x) => typeof x === "number" && isFinite(x);
  const fmt = (x, d = 2) => (isNum(x) ? (Math.abs(x) >= 1e4 ? x.toExponential(2) : x.toFixed(d)) : "—");
  const pct = (x, d = 1) => (isNum(x) ? (100 * x).toFixed(d) + "%" : "—");
  const mbps = (bps, d = 2) => (isNum(bps) ? (bps / 1e6).toFixed(d) : "—");
  const shortPath = (p) => (p || "").split(">").join(" › ");
  function tile(k, v, u, n) { return el("div", { class: "tile" }, el("div", { class: "k" }, k), el("div", { class: "v" }, v, u ? el("span", { class: "u" }, u) : null), n ? el("div", { class: "n" }, n) : null); }
  function table(cols, rows) {
    const thead = el("thead", {}, el("tr", {}, cols.map((c) => el("th", { class: c.num ? "num" : "" , title: c.title || null}, c.label))));
    const tbody = el("tbody", {}, rows.map((r) => el("tr", {}, cols.map((c) => { const v = c.get(r); return el("td", { class: (c.num ? "num " : "") + (c.cls ? c.cls(r) : "") }, v instanceof Node ? v : v); }))));
    return el("div", { class: "table-wrap" }, el("table", { class: "data" }, thead, tbody));
  }
  function empty(msg) { return el("div", { class: "empty" }, msg); }
  function swatch(color) { return el("span", { class: "sw", style: `background:${color}` }); }
  function legendRow(items) { return el("div", { class: "legend-row" }, items.map(([c, l]) => el("span", {}, swatch(c), l))); }

  function baseLayout(extra) {
    const ax = { gridcolor: C.hair, zerolinecolor: C.hair, linecolor: C.hair2, tickcolor: C.hair2, tickfont: { color: C.muted, size: 11 }, title: { font: { color: C.text2, size: 12 } }, automargin: true };
    const L = {
      paper_bgcolor: "rgba(0,0,0,0)", plot_bgcolor: "rgba(0,0,0,0)", font: { family: "system-ui, sans-serif", color: C.text2, size: 12 },
      margin: { l: 56, r: 16, t: 10, b: 44 }, hovermode: "closest", showlegend: true,
      legend: { orientation: "h", x: 0, y: 1.14, font: { color: C.text2, size: 11 }, bgcolor: "rgba(0,0,0,0)" },
      hoverlabel: { bgcolor: "#1f2227", bordercolor: C.hair2, font: { color: C.text, family: MONO, size: 12 } },
      xaxis: { ...ax }, yaxis: { ...ax }, bargap: 0.35, bargroupgap: 0.08,
    };
    return deepMerge(L, extra || {});
  }
  function deepMerge(a, b) { for (const [k, v] of Object.entries(b)) { if (v && typeof v === "object" && !Array.isArray(v) && a[k] && typeof a[k] === "object") a[k] = deepMerge({ ...a[k] }, v); else a[k] = v; } return a; }
  const PCFG = { displaylogo: false, responsive: true, modeBarButtonsToRemove: ["lasso2d", "select2d", "autoScale2d", "toggleSpikelines"] };
  function plot(node, traces, layout) { Plotly.react(node, traces, baseLayout(layout), PCFG); }
  // topology links keep a visible floor (step 1) so idle links remain readable on the graphite surface
  function seqColor(u) { if (!isNum(u)) return C.hair2; const i = Math.max(1, Math.min(C.seq.length - 1, Math.round(u * (C.seq.length - 1)))); return C.seq[i]; }
  const SEQ_SCALE = C.seq.map((c, i) => [i / (C.seq.length - 1), c]);

  function flowColor(id) {
    const flows = (state.topo && state.topo.flows) || [];
    let i = flows.findIndex((f) => f.id === id);
    if (i < 0) i = flows.length + (id.length % 2);
    return C.series[i % C.series.length];
  }
  function policyIds() { return state.manifest ? state.manifest.policies.map((p) => p.id) : (state.topo ? state.topo.policies.map((p) => p.id) : []); }
  function policyColor(id) { const i = policyIds().indexOf(id); return [C.series[0], C.series[3], C.series[2], C.series[4], C.series[6]][Math.max(0, i) % 5]; }
  function policyLabel(id) { const p = (state.manifest ? state.manifest.policies : []).find((x) => x.id === id); return p ? p.label : id; }
  function scenName(id) { const s = (state.manifest ? state.manifest.scenarios : []).find((x) => x.id === id); return s ? s.name : id; }

  // ------------------------------------------------------------------ mode & controls
  function setMode(mode) {
    state.mode = mode;
    const live = mode === "LIVE TEST";
    document.querySelectorAll(".mode-btn").forEach((b) => { const on = b.dataset.mode === mode; b.classList.toggle("active", on); b.setAttribute("aria-selected", on); });
    const strip = document.getElementById("mode-strip");
    strip.className = "mode-strip " + (live ? "live" : "sim");
    document.getElementById("strip-badge").textContent = mode;
    document.getElementById("strip-text").textContent = live
      ? "Real sockets and monotonic clocks on explicitly configured endpoints; bounded duration, rate and bytes. Loopback results characterise this host's software stack."
      : "Discrete-event model in virtual time — outputs of stated assumptions, not measured hardware performance.";
    ["ctl-exp", "ctl-scen", "ctl-pol", "ctl-seed", "ctl-note"].forEach((id) => document.getElementById(id).classList.toggle("hidden", live));
    document.getElementById("ctl-live").classList.toggle("hidden", !live);
    renderActive();
  }

  function fillSelect(sel, items, value) {
    sel.innerHTML = "";
    for (const [v, label] of items) sel.append(el("option", { value: v }, label));
    if (value != null && items.some(([v]) => String(v) === String(value))) sel.value = value;
  }

  async function loadExperiment(name) {
    state.exp = name;
    state.runCache = {};
    if (!name) return;
    const [man, cmp, agg, runs] = await Promise.all([
      api(`/api/experiments/${name}/manifest`), api(`/api/experiments/${name}/comparison`),
      api(`/api/experiments/${name}/aggregate`), api(`/api/experiments/${name}/runs`)]);
    state.manifest = man; state.comparison = cmp; state.aggregate = agg; state.runsTable = runs;
    fillSelect(document.getElementById("sel-scen"), man.scenarios.map((s) => [s.id, s.name]), state.scen);
    fillSelect(document.getElementById("sel-pol"), man.policies.map((p) => [p.id, p.id]), state.pol || "adaptive");
    const detailSeeds = [...new Set(man.detail_runs.map((p) => +p.match(/seed(\d+)/)[1]))];
    fillSelect(document.getElementById("sel-seed"), detailSeeds.map((s) => [s, `seed ${s}`]), state.seed);
    state.scen = document.getElementById("sel-scen").value;
    state.pol = document.getElementById("sel-pol").value;
    state.seed = +document.getElementById("sel-seed").value;
    document.getElementById("ctl-note").textContent = `${man.runs} runs · seeds ${man.seeds.join(", ")} · detail views use the representative seed; statistics use all seeds.`;
  }
  async function getRun(scen, pol, seed) {
    const key = `${scen}/${pol}/${seed}`;
    if (!state.runCache[key]) state.runCache[key] = await api(`/api/experiments/${state.exp}/run/${scen}/${pol}/${seed}`);
    return state.runCache[key];
  }
  async function loadRun() {
    if (!state.exp) { state.run = null; return; }
    try { state.run = await getRun(state.scen, state.pol, state.seed); } catch (e) { state.run = null; console.warn(e); }
  }
  async function loadLiveList() {
    try { state.live = await api("/api/live"); } catch (e) { state.live = []; }
    fillSelect(document.getElementById("sel-live"), state.live.map((l) => [l.id, `${l.transport.toUpperCase()} · ${l.name} · ${l.id}`]), state.liveSel);
    state.liveSel = document.getElementById("sel-live").value || null;
    state.liveRun = state.liveSel ? await api(`/api/live/${state.liveSel}`) : null;
  }

  // ------------------------------------------------------------------ rendering dispatch
  const RENDER = {};
  function renderActive() {
    const panel = document.getElementById("tab-" + state.tab);
    panel.innerHTML = "";
    try { RENDER[state.tab](panel); } catch (e) { console.error(e); panel.append(empty("Render error: " + e.message)); }
  }
  function grid(panel) { const g = el("div", { class: "grid" }); panel.append(g); return g; }
  function liveOnlyNote(panel, what) {
    panel.append(el("p", { class: "callout live" }, `${what} is not observable in LIVE TEST mode: live tests measure end hosts only (rates, RTT, one-way delay where clocks allow, loss, CPU, event-loop delay). Switch to SIMULATION for network internals.`));
  }
  function needRun(panel) {
    if (!state.run) { panel.append(empty(state.exp ? "No detailed run for this selection." : "No simulation results found. Run `vhfnet demo` (or `make demo`) and reload.")); return false; }
    return true;
  }

  // ================================================================== TOPOLOGY
  RENDER.topology = (panel) => {
    if (state.mode === "LIVE TEST") return liveTopology(panel);
    const topo = state.topo;
    if (!topo) return panel.append(empty("Topology unavailable."));
    const g = grid(panel);
    const run = state.run;
    const tsT = run && run.timeseries ? run.timeseries.t : [];
    const div = chart("tall");
    const slider = el("input", { type: "range", min: 0, max: Math.max(0, tsT.length - 1), value: Math.max(0, tsT.length - 1), "aria-label": "time" });
    const tlabel = el("span", {}, "");
    const modeSel = el("select", { "aria-label": "link colour" }, el("option", { value: "mean" }, "mean utilisation (run)"), el("option", { value: "t" }, "utilisation at time t"));
    const c = card("Network topology", `${topo.name}${topo.fictional ? " (fictional)" : ""} · links coloured by utilisation (busier = brighter blue); outage = red ✕. ${run ? scenName(state.scen) + " · " + state.pol : ""}`, 8,
      div, el("div", { class: "slider-row" }, modeSel, slider, tlabel));
    g.append(c);
    const draw = () => {
      const nodes = Object.fromEntries(topo.nodes.map((n) => [n.id, n]));
      const traces = [];
      const ann = [];
      const useT = modeSel.value === "t" && tsT.length;
      const ti = +slider.value;
      tlabel.textContent = useT ? `t = ${tsT[ti].toFixed(2)} s` : "whole run";
      for (const lk of topo.links) {
        const a = nodes[lk.a], b = nodes[lk.b];
        let u = null, up = true, info = "";
        if (run) {
          const dirs = run.links.filter((l) => l.link_id === lk.id);
          if (useT) {
            const vals = dirs.map((d) => run.timeseries.links[d.link]).filter(Boolean);
            u = Math.max(...vals.map((s) => s.utilisation[ti] || 0));
            up = vals.every((s) => s.up[ti] !== false);
          } else u = Math.max(...dirs.map((d) => d.utilisation || 0));
          info = dirs.map((d) => `${d.src}→${d.dst}: util ${pct(d.utilisation)} · q̄ ${fmt(d.queue_mean_bytes / 1000, 1)} kB · drops ${Object.values(d.drops).reduce((x, y) => x + y, 0)}`).join("<br>");
        }
        const col = !up ? C.critical : seqColor(u);
        traces.push({ x: [a.x, b.x], y: [a.y, b.y], mode: "lines", line: { color: col, width: 2 + 5 * (u || 0) }, hoverinfo: "skip", showlegend: false });
        traces.push({ x: [(a.x + b.x) / 2], y: [(a.y + b.y) / 2], mode: "markers", marker: { size: 16, color: "rgba(0,0,0,0)" }, showlegend: false,
          hovertemplate: `<b>${lk.id}</b> (${lk.kind})<br>${lk.capacity_mbps} / ${lk.capacity_mbps_reverse} Mbit/s · ${lk.propagation_delay_ms} ms · ${lk.discipline.toUpperCase()}` +
            (lk.wireless ? `<br>radio: ${lk.wireless.model}${lk.wireless.carrier_freq_ghz ? ` · fc ${lk.wireless.carrier_freq_ghz} GHz · B ${lk.wireless.channel_bw_mhz} MHz` : ""}` : "") + (info ? "<br>" + info : "") + "<extra></extra>" });
        if (!up) ann.push({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, text: "✕ outage", showarrow: false, font: { color: C.critical, size: 12 }, yshift: 14 });
      }
      const sym = { client: "circle", base_station: "triangle-up", edge: "square", core: "diamond", cloud: "hexagon" };
      for (const kind of Object.keys(sym)) {
        const ns = topo.nodes.filter((n) => n.kind === kind);
        if (!ns.length) continue;
        traces.push({ x: ns.map((n) => n.x), y: ns.map((n) => n.y), mode: "markers+text", name: kind.replace("_", " "),
          text: ns.map((n) => n.id), textposition: "bottom center", textfont: { color: C.text, family: MONO, size: 11 },
          marker: { symbol: sym[kind], size: 22, color: C.surface, line: { color: ns.map((n) => (n.compute ? C.gold : C.text2)), width: 2 } },
          hovertemplate: ns.map((n) => `<b>${n.label}</b><br>${n.kind} · proc ${n.processing_delay_us} µs` + (n.compute ? `<br>compute ${n.compute.cores}×${n.compute.gops_per_core} GOP/s, queue ≤ ${n.compute.queue_limit}` : "") + "<extra></extra>") });
      }
      traces.push({ x: [null], y: [null], mode: "markers", showlegend: false, hoverinfo: "skip",
        marker: { color: [0], cmin: 0, cmax: 1, colorscale: SEQ_SCALE, showscale: true, colorbar: { title: { text: "utilisation", font: { color: C.muted, size: 11 } }, tickformat: ".0%", thickness: 10, len: 0.6, outlinewidth: 0, tickfont: { color: C.muted, size: 10 } } } });
      plot(div, traces, { xaxis: { visible: false }, yaxis: { visible: false, scaleanchor: "x" }, annotations: ann, legend: { y: 1.06 }, margin: { l: 10, r: 10, t: 24, b: 10 } });
    };
    slider.addEventListener("input", () => { modeSel.value = "t"; draw(); });
    modeSel.addEventListener("change", draw);
    draw();

    const side = card("Run summary", run ? `${scenName(state.scen)} · ${policyLabel(state.pol)} · seed ${state.seed}` : "", 4);
    if (run) {
      const T = run.totals, I = run.integrity;
      side.append(el("div", { class: "tiles" },
        tile("Offered", mbps(T.offered_bps, 1), "Mb/s"), tile("Goodput", mbps(T.goodput_bps, 1), "Mb/s"),
        tile("Useful (on time)", mbps(T.useful_goodput_bps, 1), "Mb/s"), tile("Deadline misses", pct(T.deadline_miss_ratio, 2), "", `${T.deadline_misses} of ${T.deadline_messages}`),
        tile("Route changes", T.route_changes), tile("Request failures", T.request_failures, "", `of ${T.requests_total}`)));
      side.append(el("p", { class: "sub", style: "margin-top:12px" }, `Integrity: capacity conserved ${I.capacity_conserved ? "✓" : "✗"} · delay identity error ${I.delay_identity_max_abs_error_s.toExponential(1)} s · packets injected ${I.packets_injected}, delivered ${I.packets_delivered_incl_duplicates}, dropped ${I.packets_dropped}, in flight at end ${I.packets_in_flight_at_end}.`));
      const evs = run.meta.scenario.events || [];
      side.append(el("h3", { style: "margin-top:10px" }, "Scenario events"), evs.length ? el("ul", { class: "notes" }, evs.map((e) => el("li", {}, `t=${e.at_s}s ${e.kind} on ${e.target}${e.duration_s ? ` for ${e.duration_s}s` : ""}${e.factor != null ? ` ×${e.factor}` : ""}${e.attenuation_db ? ` +${e.attenuation_db} dB` : ""}${e.interruption_ms ? ` ${e.interruption_ms} ms` : ""}${e.to ? ` → ${e.to}` : ""}`))) : el("p", { class: "sub" }, run.meta.scenario.description || "none"));
    } else side.append(empty("No run selected."));
    g.append(side);

    if (run) {
      const rows = run.links.filter((l) => l.tx_bits > 0 || Object.values(l.drops).some((x) => x > 0));
      g.append(card("Directional links", "Utilisation = bits serialised / ∫capacity dt (≤ 1 by construction). Drops by cause are never hidden.", 12, table([
        { label: "link", get: (l) => l.link }, { label: "disc.", get: (l) => l.discipline.toUpperCase() },
        { label: "nominal Mb/s", num: 1, get: (l) => mbps(l.nominal_capacity_bps, 0) },
        { label: "mean cap Mb/s", num: 1, get: (l) => mbps(l.timeline.mean_capacity_bps, 1) },
        { label: "util", num: 1, get: (l) => pct(l.utilisation) }, { label: "q̄ kB", num: 1, get: (l) => fmt(l.queue_mean_bytes / 1e3, 1) },
        { label: "q max kB", num: 1, get: (l) => fmt(l.queue_max_bytes / 1e3, 1) },
        { label: "buffer", num: 1, get: (l) => drop0(l.drops.buffer) }, { label: "channel", num: 1, get: (l) => drop0(l.drops.channel) },
        { label: "outage", num: 1, get: (l) => drop0(l.drops.outage) }, { label: "downtime s", num: 1, get: (l) => fmt(l.timeline.downtime_s, 2) },
        { label: "energy J (est.)", num: 1, get: (l) => fmt(l.energy_estimated_j, 1) },
      ], rows.sort((a, b) => b.utilisation - a.utilisation))));
    }
  };
  const drop0 = (x) => (x ? x : "·");

  function liveTopology(panel) {
    const r = state.liveRun;
    if (!r) return panel.append(empty("No live tests recorded yet. Use Experiments → Live test (loopback) or `vhfnet live run configs/live/loopback_udp.yaml`."));
    const g = grid(panel);
    const div = chart("short");
    g.append(card("Live test endpoints", `${r.meta.transport.toUpperCase()} ${r.meta.tls ? "with TLS " : ""}to ${r.meta.endpoint.ip}:${r.meta.endpoint.port} (${r.meta.endpoint.loopback ? "loopback" : "authorised remote"}) · clock: ${r.meta.clock.basis}`, 8, div));
    const traces = [{ x: [0, 1], y: [0, 0], mode: "lines", line: { color: C.blue, width: 3 }, hoverinfo: "skip", showlegend: false },
      { x: [0, 1], y: [0, 0], mode: "markers+text", text: ["client (this process)", `server ${r.meta.endpoint.ip}`], textposition: "bottom center", textfont: { color: C.text, family: MONO },
        marker: { size: 26, symbol: ["circle", "hexagon"], color: C.surface, line: { color: C.gold, width: 2 } }, showlegend: false, hoverinfo: "text" }];
    plot(div, traces, { xaxis: { visible: false, range: [-0.3, 1.3] }, yaxis: { visible: false, range: [-1, 0.8] }, annotations: [{ x: 0.5, y: 0.25, text: `${r.meta.transport.toUpperCase()} · ${r.flows.length} flows`, showarrow: false, font: { color: C.text2 } }] });
    g.append(card("Limits enforced", "", 4, el("div", { class: "tiles" }, tile("Max duration", r.meta.limits.max_duration_s, "s"), tile("Rate ceiling", r.meta.limits.rate_ceiling_mbps, "Mb/s"),
      tile("Byte budget", fmt(r.meta.limits.max_total_bytes / 1e9, 2), "GB", `used ${fmt(r.totals.budget_bytes_used / 1e6, 1)} MB`)), r.meta.warnings.length ? el("ul", { class: "notes" }, r.meta.warnings.map((w) => el("li", {}, w))) : null));
  }

  // ================================================================== TRAFFIC
  RENDER.traffic = (panel) => {
    if (state.mode === "LIVE TEST") return liveTraffic(panel);
    if (!needRun(panel)) return;
    const run = state.run, flows = run.flows, g = grid(panel);
    g.append(card("Flow accounting", "offered → transmitted (wire, incl. headers & retransmissions) → delivered (wire, incl. duplicates) → goodput (unique payload) → useful (on-time payload). Rates over each flow's generation window.", 12,
      table([
        { label: "flow", get: (f) => el("span", {}, swatch(flowColor(f.id)), " ", f.id) }, { label: "kind", get: (f) => f.kind },
        { label: "prio", num: 1, get: (f) => f.priority }, { label: "deadline ms", num: 1, get: (f) => f.deadline_ms ?? "—" },
        { label: "offered", num: 1, get: (f) => mbps(f.offered_bps) }, { label: "transmitted", num: 1, get: (f) => mbps(f.transmitted_wire_bps) },
        { label: "delivered", num: 1, get: (f) => mbps(f.delivered_wire_bps) }, { label: "goodput", num: 1, get: (f) => mbps(f.goodput_bps) },
        { label: "useful", num: 1, get: (f) => mbps(f.useful_goodput_bps) }, { label: "loss", num: 1, get: (f) => pct(f.packet_loss_ratio, 2) },
        { label: "retx", num: 1, get: (f) => f.retransmitted_packets }, { label: "dup", num: 1, get: (f) => f.duplicate_packets },
        { label: "reord", num: 1, get: (f) => f.reordered_packets }, { label: "miss", num: 1, get: (f) => pct(f.deadline_miss_ratio, 2) },
        { label: "p50 ms", num: 1, get: (f) => latency(f, run, "p50") }, { label: "p99 ms", num: 1, get: (f) => latency(f, run, "p99") },
        { label: "jitter ms", num: 1, title: "RFC 3550 estimator, time-averaged", get: (f) => fmt(f.jitter_rfc3550_ms, 3) },
        { label: "starved", get: (f) => (f.starved ? "yes" : "no") },
      ], flows)));
    const b = chart();
    g.append(card("Offered vs goodput vs useful", "Mbit/s per flow. Gaps reveal loss, rejection (backpressure) or lateness.", 6, b));
    plot(b, [
      { type: "bar", name: "offered", x: flows.map((f) => f.id), y: flows.map((f) => f.offered_bps / 1e6), marker: { color: C.series[0] }, hovertemplate: "%{x}: %{y:.2f} Mb/s offered<extra></extra>" },
      { type: "bar", name: "goodput", x: flows.map((f) => f.id), y: flows.map((f) => f.goodput_bps / 1e6), marker: { color: C.series[3] }, hovertemplate: "%{x}: %{y:.2f} Mb/s goodput<extra></extra>" },
      { type: "bar", name: "useful", x: flows.map((f) => f.id), y: flows.map((f) => f.useful_goodput_bps / 1e6), marker: { color: C.series[2] }, hovertemplate: "%{x}: %{y:.2f} Mb/s useful<extra></extra>" },
    ], { barmode: "group", yaxis: { title: { text: "Mbit/s" } } });
    const d = chart();
    g.append(card("One-way delay decomposition", "Share of the mean per-packet delay; total (ms) at the bar end. application + queueing + transmission + propagation + processing = total (identity checked per packet).", 6, d));
    const comps = [["application", C.series[4]], ["queueing", C.series[1]], ["transmission", C.series[3]], ["propagation", C.series[0]], ["processing", C.series[6]]];
    const tot = flows.map((f) => (f.delay_breakdown_ms ? Object.values(f.delay_breakdown_ms).reduce((a, b) => a + b, 0) : 0));
    plot(d, comps.map(([k, col]) => ({ type: "bar", orientation: "h", name: k, y: flows.map((f) => f.id),
      x: flows.map((f, i) => (f.delay_breakdown_ms && tot[i] > 0 ? f.delay_breakdown_ms[k] / tot[i] : 0)),
      customdata: flows.map((f) => (f.delay_breakdown_ms ? f.delay_breakdown_ms[k] : 0)),
      marker: { color: col, line: { color: C.surface, width: 2 } }, hovertemplate: `%{y} ${k}: %{customdata:.3f} ms (%{x:.0%})<extra></extra>` })),
      { barmode: "stack", xaxis: { tickformat: ".0%", range: [0, 1.22] }, yaxis: { autorange: "reversed" }, margin: { l: 80 },
        annotations: flows.map((f, i) => ({ x: 1.01, y: f.id, xanchor: "left", text: `${fmt(tot[i], tot[i] >= 100 ? 0 : 1)} ms`, showarrow: false, font: { color: C.text2, family: MONO, size: 11 } })) });
    const ts = run.timeseries;
    const gp = chart();
    g.append(card("Goodput over time", "Unique payload delivered per sample interval (request direction; responses shown dotted).", 7, gp));
    const tr = [];
    for (const [name, s] of Object.entries(ts.flows)) {
      tr.push({ x: ts.t, y: s.goodput_bps.map((v) => v / 1e6), name, mode: "lines", line: { color: flowColor(name), width: 2 }, hovertemplate: `${name}: %{y:.2f} Mb/s @ %{x:.2f}s<extra></extra>` });
      if (s.response_goodput_bps && s.response_goodput_bps.some((v) => v > 0)) tr.push({ x: ts.t, y: s.response_goodput_bps.map((v) => v / 1e6), name: name + " (resp.)", mode: "lines", line: { color: flowColor(name), width: 1.5, dash: "dot" }, hovertemplate: `${name} responses: %{y:.2f} Mb/s<extra></extra>` });
    }
    plot(gp, tr, { xaxis: { title: { text: "virtual time (s)" } }, yaxis: { title: { text: "Mbit/s" } }, hovermode: "x unified" });
    const ec = chart();
    g.append(card("Latency distribution (ECDF)", "Message / request completion latency. Requests include failures only via the miss ratio; failed requests have no latency.", 5, ec));
    const ecdf = [];
    for (const f of flows) {
      const q = run.requests && run.requests[f.id] ? run.requests[f.id].completion_quantiles_ms : f.messages.latency_quantiles_ms;
      if (!q || f.kind === "file_transfer") continue;
      ecdf.push({ x: q, y: q.map((_, i) => i / (q.length - 1)), name: f.id, mode: "lines", line: { color: flowColor(f.id), width: 2, shape: "hv" }, hovertemplate: `${f.id}: %{y:.0%} ≤ %{x:.1f} ms<extra></extra>` });
    }
    plot(ec, ecdf, { xaxis: { title: { text: "latency (ms, log)" }, type: "log" }, yaxis: { title: { text: "fraction" }, tickformat: ".0%", range: [0, 1.02] } });
  };
  function latency(f, run, p) {
    const r = run.requests && run.requests[f.id];
    const v = r ? r.completion_ms[p] : f.messages.latency_ms[p];
    if (f.kind === "file_transfer") return f.flow_completion_time_s ? `FCT ${fmt(f.flow_completion_time_s, 2)} s` : `${pct(f.file_progress, 0)} done`;
    return fmt(v, 1);
  }

  function liveTraffic(panel) {
    const r = state.liveRun;
    if (!r) return panel.append(empty("No live test selected."));
    const g = grid(panel);
    g.append(el("p", { class: "callout live", style: "grid-column: span 12" }, r.meta.disclaimer));
    g.append(card("Live flows", `${r.meta.rate_semantics}. Generator-limited flows did not achieve their target and are flagged.`, 12, table([
      { label: "flow", get: (f) => f.id }, { label: "pattern", get: (f) => f.pattern },
      { label: "target Mb/s", num: 1, get: (f) => fmt(f.target_wire_rate_mbps, 1) }, { label: "sent Mb/s (wire est.)", num: 1, get: (f) => fmt(f.achieved_send_wire_rate_mbps_est, 1) },
      { label: "goodput Mb/s", num: 1, get: (f) => fmt(f.goodput_mbps, 1) }, { label: "gen. limited", get: (f) => (f.generator_limited ? "YES" : "no") },
      { label: "lag p99 ms", num: 1, get: (f) => fmt(f.generator_lag_ms.p99, 2) }, { label: "loss", num: 1, get: (f) => pct(f.loss_ratio, 3) },
      { label: "retx", num: 1, get: (f) => f.retransmissions }, { label: "dup", num: 1, get: (f) => f.duplicates ?? "—" },
      { label: "OWD p50/p99 ms", num: 1, get: (f) => (f.owd_ms ? `${fmt(f.owd_ms.p50, 3)} / ${fmt(f.owd_ms.p99, 3)}` : "not valid") },
      { label: "RTT p50/p99 ms", num: 1, get: (f) => (f.rtt_ms && f.rtt_ms.count ? `${fmt(f.rtt_ms.p50, 3)} / ${fmt(f.rtt_ms.p99, 3)}` : "—") },
      { label: "requests ok/late/timeout/err", get: (f) => (f.requests ? `${f.requests.ok}/${f.requests.late}/${f.requests.timeouts}/${f.requests.errors}` : "—") },
    ], r.flows)));
    const a = chart();
    g.append(card("Target vs achieved", "Mbit/s. Bursty flows average over ON and OFF periods.", 6, a));
    plot(a, [
      { type: "bar", name: "target (wire)", x: r.flows.map((f) => f.id), y: r.flows.map((f) => f.target_wire_rate_mbps), marker: { color: C.series[0] } },
      { type: "bar", name: "sent (wire est.)", x: r.flows.map((f) => f.id), y: r.flows.map((f) => f.achieved_send_wire_rate_mbps_est), marker: { color: C.series[3] } },
      { type: "bar", name: "goodput", x: r.flows.map((f) => f.id), y: r.flows.map((f) => f.goodput_mbps || 0), marker: { color: C.series[2] } },
    ], { barmode: "group", yaxis: { title: { text: "Mbit/s" } } });
    const l = chart();
    g.append(card("Delay percentiles", "One-way delay (only when clocks share a time base) and RTT (always valid, monotonic clock).", 6, l));
    const tr = [];
    r.flows.forEach((f, i) => {
      const col = C.series[i % 8];
      if (f.owd_ms) tr.push({ x: ["p50", "p90", "p99", "max"], y: [f.owd_ms.p50, f.owd_ms.p90, f.owd_ms.p99, f.owd_ms.max], name: f.id + " OWD", mode: "lines+markers", line: { color: col, width: 2 }, marker: { size: 8 } });
      if (f.rtt_ms && f.rtt_ms.count) tr.push({ x: ["p50", "p90", "p99", "max"], y: [f.rtt_ms.p50, f.rtt_ms.p90, f.rtt_ms.p99, f.rtt_ms.max], name: f.id + " RTT", mode: "lines+markers", line: { color: col, width: 2, dash: "dot" }, marker: { size: 8, symbol: "square" } });
    });
    plot(l, tr, { yaxis: { title: { text: "ms (log)" }, type: "log" } });
    const rh = r.flows.filter((f) => f.rate_history_mbps);
    if (rh.length) {
      const c2 = chart("short");
      g.append(card("UDP rate adaptation (bounded AIMD)", "Sending rate set by receiver feedback; never above the flow's configured rate.", 12, c2));
      plot(c2, rh.map((f, i) => ({ x: f.rate_history_mbps.map((p) => p[0]), y: f.rate_history_mbps.map((p) => p[1]), name: f.id, mode: "lines", line: { color: C.series[i], width: 2 } })), { xaxis: { title: { text: "s" } }, yaxis: { title: { text: "Mbit/s" } } });
    }
  }

  // ================================================================== LINKS
  RENDER.links = (panel) => {
    if (state.mode === "LIVE TEST") return liveOnlyNote(panel, "Per-link queueing and utilisation");
    if (!needRun(panel)) return;
    const run = state.run, ts = run.timeseries, g = grid(panel);
    const active = run.links.filter((l) => l.tx_bits > 0).sort((a, b) => b.utilisation - a.utilisation);
    const hm = chart("tall");
    g.append(card("Link utilisation over time", "Bits serialised per interval / ∫capacity over the interval. Empty cells = zero capacity (interruption or outage).", 12, hm));
    plot(hm, [{ type: "heatmap", x: ts.t, y: active.map((l) => l.link), z: active.map((l) => ts.links[l.link].utilisation), zmin: 0, zmax: 1, colorscale: SEQ_SCALE,
      colorbar: { tickformat: ".0%", thickness: 10, outlinewidth: 0, tickfont: { color: C.muted } }, hovertemplate: "%{y}<br>t=%{x:.2f}s · %{z:.1%}<extra></extra>", xgap: 0, ygap: 2 }],
      { margin: { l: 170 }, xaxis: { title: { text: "virtual time (s)" } }, yaxis: { autorange: "reversed", tickfont: { family: MONO, size: 10 } } });
    const top = [...run.links].sort((a, b) => b.queue_max_bytes - a.queue_max_bytes).slice(0, 5).filter((l) => l.queue_max_bytes > 0);
    const q = chart();
    g.append(card("Queue occupancy history", "Top links by peak queue (kB, sampled). Buffer limits shown in the table on Topology.", 6, q));
    plot(q, top.map((l, i) => ({ x: ts.t, y: ts.links[l.link].queue_bytes.map((v) => v / 1e3), name: l.link, mode: "lines", line: { color: C.series[i], width: 2 }, hovertemplate: `${l.link}: %{y:.1f} kB<extra></extra>` })),
      { xaxis: { title: { text: "virtual time (s)" } }, yaxis: { title: { text: "kB" } }, hovermode: "x unified", legend: { y: 1.2 } });
    const acc = run.links.filter((l) => l.link.startsWith("acc-") && l.src.startsWith("ue")).slice(0, 2);
    for (const l of acc) {
      const c = chart("short");
      g.append(card(`${l.link_id} uplink: capacity vs carried`, "Capacity timeline (piecewise constant, from radio abstraction + scenario events) and carried throughput, both bit/s.", 3, c));
      const s = ts.links[l.link];
      plot(c, [{ x: ts.t, y: s.capacity_bps.map((v) => v / 1e6), name: "capacity", mode: "lines", line: { color: C.text2, width: 1.5, shape: "hv" } },
        { x: ts.t, y: s.throughput_bps.map((v) => v / 1e6), name: "carried", mode: "lines", line: { color: C.blue, width: 2 } }], { yaxis: { title: { text: "Mbit/s" } }, hovermode: "x unified", legend: { y: 1.25 }, margin: { t: 30 } });
    }
    const cond = run.conditions || {};
    const rows = Object.entries(cond).filter(([, c]) => c.handover_times.length || c.blockage_windows.length || c.outage_windows.length || c.radio_assumptions.length);
    g.append(card("Radio abstraction & conditions", "Explicit assumptions behind every capacity timeline. Not a physical-layer simulation.", 12,
      rows.length ? el("div", {}, rows.map(([lid, c]) => el("div", { style: "margin-bottom:10px" }, el("div", { class: "mono" }, lid),
        el("div", { class: "sub" }, `handovers: ${c.handover_times.map((t) => t.toFixed(2)).join(", ") || "none"} · blockage windows: ${c.blockage_windows.length} · outages: ${c.outage_windows.map((w) => `${w[0].toFixed(2)}–${w[1].toFixed(2)} s`).join(", ") || "none"}`),
        c.radio_assumptions.length ? el("ul", { class: "notes" }, c.radio_assumptions.map((a) => el("li", {}, a))) : null))) : empty("No wireless links or scenario conditions in this run.")));
  };

  // ================================================================== ROUTING
  RENDER.routing = (panel) => {
    if (state.mode === "LIVE TEST") return liveOnlyNote(panel, "Routing state");
    if (!needRun(panel)) return;
    const run = state.run, g = grid(panel);
    const ch = (run.routes && run.routes.changes) || [];
    const sc = chart();
    const reasons = [...new Set(ch.map((c) => c.reason.split(":")[0]))];
    const rcol = { failover: C.series[1], "lower-cost-beyond-hysteresis": C.series[0], "lower-estimated-delay": C.series[3], "current-path-unavailable": C.series[4] };
    g.append(card("Route changes", `${ch.length} changes in this run (${state.pol}). Each point: a flow/destination switching path, with the logged reason and estimated costs.`, 7, ch.length ? sc : empty("No route changes (static routing, or no better path found).")));
    if (ch.length) plot(sc, reasons.map((r) => { const cs = ch.filter((c) => c.reason.split(":")[0] === r); return { x: cs.map((c) => c.t), y: cs.map((c) => `${c.flow} → ${c.dst}`), mode: "markers", name: r, marker: { size: 9, color: rcol[r] || C.series[6], line: { color: C.surface, width: 2 } },
      text: cs.map((c) => `${shortPath(c.from_path)}<br>→ ${shortPath(c.to_path)}<br>cost ${fmt(c.cost_from * 1e3, 1)} → ${fmt(c.cost_to * 1e3, 1)} ms-eq.`), hovertemplate: "t=%{x:.3f}s %{y}<br>%{text}<extra></extra>" }; }),
      { xaxis: { title: { text: "virtual time (s)" }, range: [0, run.meta.horizon_s] }, yaxis: { tickfont: { family: MONO, size: 10 } }, margin: { l: 150 } });
    const pu = chart();
    g.append(card("Paths used", "Fraction of each flow's unique delivered packets per path.", 5, pu));
    const paths = [...new Set(run.flows.flatMap((f) => Object.keys(f.paths_used || {})))];
    plot(pu, paths.slice(0, 8).map((p, i) => ({ type: "bar", orientation: "h", name: shortPath(p), y: run.flows.map((f) => f.id), x: run.flows.map((f) => (f.paths_used || {})[p] || 0), marker: { color: C.series[i], line: { color: C.surface, width: 2 } }, hovertemplate: `%{y}: %{x:.1%} via ${shortPath(p)}<extra></extra>` })),
      { barmode: "stack", xaxis: { tickformat: ".0%", range: [0, 1] }, yaxis: { autorange: "reversed" }, legend: { y: -0.25, orientation: "h", font: { size: 10 } }, margin: { l: 80, b: 120 } });
    const rh = run.timeseries.rate_history || {};
    const rc = chart("short");
    g.append(card("Sending-rate adaptation", "Rate of each flow's active destination (bounded AIMD or fixed). Never exceeds the flow's max_rate.", 7, Object.keys(rh).length ? rc : empty("Fixed-rate policy: no adaptation history.")));
    if (Object.keys(rh).length) plot(rc, Object.entries(rh).map(([n, pts]) => ({ x: pts.map((p) => p[0]), y: pts.map((p) => p[1] / 1e6), name: n, mode: "lines", line: { color: flowColor(n), width: 2, shape: "hv" } })), { xaxis: { title: { text: "virtual time (s)" } }, yaxis: { title: { text: "Mbit/s" } } });
    const agg = chart("short");
    g.append(card("Route changes across seeds", "Mean ± MCSE per scenario and policy (all seeds). Fewer changes = more stable, not necessarily better.", 5, agg));
    plot(agg, policyIds().map((p) => { const rows = state.aggregate.filter((r) => r.policy === p); return { type: "bar", name: p, x: rows.map((r) => r.scenario), y: rows.map((r) => r["route_changes.mean"]), error_y: { type: "data", array: rows.map((r) => r["route_changes.mcse"] || 0), color: C.muted, thickness: 1 }, marker: { color: policyColor(p) } }; }), { barmode: "group", yaxis: { title: { text: "changes / run" } } });
  };

  // ================================================================== EDGE
  RENDER.edge = (panel) => {
    if (state.mode === "LIVE TEST") return liveOnlyNote(panel, "Edge-compute placement");
    if (!needRun(panel)) return;
    const run = state.run, g = grid(panel), ts = run.timeseries;
    for (const c of run.compute) {
      const d = chart("short");
      g.append(card(`${c.node}: queue & busy cores`, `${c.cores} cores × ${c.gops_per_core} GOP/s · utilisation ${pct(c.utilisation)} · completed ${c.jobs_completed}, rejected ${c.jobs_rejected} (+ background ${c.background_completed}/${c.background_rejected}) · energy ≈ ${fmt(c.energy_estimated_j, 0)} J (estimate)`, 6, d));
      const s = ts.compute[c.node];
      plot(d, [{ x: ts.t, y: s.busy_cores, name: "busy cores", mode: "lines", line: { color: C.blue, width: 2, shape: "hv" } },
        { x: ts.t, y: s.queue_jobs, name: "queued jobs", mode: "lines", line: { color: C.series[3], width: 2, shape: "hv" } }], { yaxis: { title: { text: "count" }, rangemode: "tozero" }, hovermode: "x unified", legend: { y: 1.25 }, margin: { t: 30 } });
    }
    const inf = run.requests && run.requests.inference;
    if (inf) {
      const pl = chart();
      g.append(card("Inference placement & outcome", "Where each request ran and how it ended. Status colours carry labels; failures are counted, never dropped.", 6, pl));
      const nodes = Object.keys(inf.placement);
      plot(pl, ["ok", "late", "timeout", "rejected"].map((s) => ({ type: "bar", name: s, x: nodes, y: nodes.map((n) => inf.placement[n][s] || 0), marker: { color: STATUS[s], line: { color: C.surface, width: 2 } }, hovertemplate: `%{x}: %{y} ${s}<extra></extra>` })), { barmode: "stack", yaxis: { title: { text: "requests" } } });
    }
    const bd = chart();
    const card2 = card("Completion-time breakdown by policy", "Inference: input transfer + waiting + processing + output transfer (mean ms, successful requests). Same scenario & seed.", 6, bd);
    g.append(card2);
    Promise.all(policyIds().map((p) => getRun(state.scen, p, state.seed).catch(() => null))).then((runs) => {
      const parts = [["input_transfer", C.series[0]], ["waiting", C.series[1]], ["processing", C.series[3]], ["output_transfer", C.series[2]]];
      const pols = policyIds().filter((_, i) => runs[i] && runs[i].requests && runs[i].requests.inference);
      const rr = runs.filter((r) => r && r.requests && r.requests.inference);
      plot(bd, parts.map(([k, col]) => ({ type: "bar", name: k.replace("_", " "), x: pols, y: rr.map((r) => r.requests.inference.breakdown_mean_ms[k] || 0), marker: { color: col, line: { color: C.surface, width: 2 } }, hovertemplate: `%{x} ${k}: %{y:.1f} ms<extra></extra>` })),
        { barmode: "stack", yaxis: { title: { text: "ms" } }, annotations: rr.map((r, i) => ({ x: pols[i], y: Object.values(r.requests.inference.breakdown_mean_ms).reduce((a, b) => a + (b || 0), 0), text: `on time ${pct(r.requests.inference.on_time_ratio, 0)}`, showarrow: false, yshift: 10, font: { color: C.text2, size: 11 } })) });
    });
    if (run.migrations && run.migrations.length) {
      g.append(card("Service migrations", "State transfer over the network, then downtime; messages arriving meanwhile wait for the service.", 6, table([
        { label: "service", get: (m) => m.service }, { label: "from → to", get: (m) => `${m.from} → ${m.to}` }, { label: "state MB", num: 1, get: (m) => fmt(m.state_bytes / 1e6, 1) },
        { label: "start s", num: 1, get: (m) => fmt(m.start_t, 3) }, { label: "transfer done s", num: 1, get: (m) => fmt(m.transfer_done_t, 3) }, { label: "end s", num: 1, get: (m) => fmt(m.end_t, 3) }], run.migrations)));
    }
    const out = chart("short"), status = el("div", { class: "status-line" });
    const inputs = { input_bytes: 60000, output_bytes: 4000, work_gop: 3, edge_background_jobs_per_s: 0, access_mbps: 80 };
    const form = el("div", { class: "form" }, Object.entries(inputs).map(([k, v]) => el("label", {}, k.replace(/_/g, " "), el("input", { type: "number", value: v, step: "any", "data-k": k }))),
      el("button", { class: "btn primary", disabled: !!STATIC, onclick: async () => {
        const body = {}; form.querySelectorAll("input").forEach((i) => (body[i.dataset.k] = +i.value));
        status.textContent = "computing…";
        try { const r = await post("/api/placement", body); status.textContent = r.mode;
          plot(out, [["input_transfer_s", C.series[0]], ["wait_s", C.series[1]], ["processing_s", C.series[3]], ["output_transfer_s", C.series[2]]].map(([k, col]) => ({ type: "bar", orientation: "h", name: k.replace(/_s$/, "").replace("_", " "), y: r.rows.map((x) => x.node), x: r.rows.map((x) => x[k] * 1e3), marker: { color: col, line: { color: C.surface, width: 2 } } })), { barmode: "stack", xaxis: { title: { text: "ms" } }, margin: { l: 90 } });
        } catch (e) { status.textContent = e.message; } } }, "Estimate"));
    g.append(card("What-if: analytic placement (M/M/c)", "Not simulation: closed-form estimate. Try a large upload or heavy edge background load — the edge is not always faster.", 12, form, out, status));
    if (STATIC) { status.textContent = "Static report: run `vhfnet serve` for interactive estimates."; out.classList.add("hidden"); }
    else form.querySelector("button").click();
  };

  // ================================================================== EXPERIMENTS
  const METRICS = { deadline_miss_ratio: "Deadline-miss ratio", useful_goodput_mbps: "Useful goodput (Mb/s)", goodput_mbps: "Goodput (Mb/s)", media_p99_ms: "Media p99 (ms)",
    inference_on_time_ratio: "Inference on time", api_on_time_ratio: "API on time", twin_aoi_ms: "Twin age of information (ms)", bulk_progress: "Bulk progress",
    jain_delivery_ratio: "Jain fairness", min_delivery_ratio: "Worst flow delivery ratio", starved_flows: "Starved flows", route_changes: "Route changes", energy_estimated_j: "Energy (J, estimate)" };
  RENDER.experiments = (panel) => {
    const g = grid(panel);
    if (state.mode === "LIVE TEST") return liveExperiments(g);
    if (!state.manifest) { g.append(card("No experiments", "", 12, empty("Run `vhfnet demo` to create results."))); simLauncher(g); return; }
    const m = state.manifest;
    g.append(card(m.name, m.description, 12, el("div", { class: "tiles" },
      tile("Runs", m.runs), tile("Scenarios", m.scenarios.length), tile("Policies", m.policies.length), tile("Seeds", m.seeds.length, "", m.seeds.join(", ")),
      tile("Capacity conserved", m.integrity_all_capacity_conserved ? "all ✓" : "✗"), tile("Max delay-identity error", m.max_delay_identity_error_s.toExponential(1), "s"),
      tile("Simulator wall time", fmt(m.simulator_cost.total_sim_wall_s, 0), "s", "software cost, not network performance"), tile("Host", m.host.cpu_count + " CPU", "", `Python ${m.host.python}`))));
    const msel = el("select", { "aria-label": "metric" }, Object.entries(METRICS).map(([k, l]) => el("option", { value: k }, l)));
    msel.value = state.metric;
    const strip = chart("tall");
    const tblHost = el("div");
    const c = card("Per-seed results", "Every dot is one seeded run (common random numbers across policies). Means ± Monte Carlo standard error in the table.", 12, el("div", { class: "form" }, el("label", {}, "metric", msel)), strip, tblHost);
    g.append(c);
    const draw = () => {
      state.metric = msel.value;
      const k = msel.value;
      const pols = policyIds();
      plot(strip, pols.map((p, i) => { const rows = state.runsTable.filter((r) => r.policy === p); return { type: "box", name: p, x: rows.map((r) => scenName(r.scenario)), y: rows.map((r) => r[k]), boxpoints: "all", jitter: 0.4, pointpos: 0, marker: { color: policyColor(p), size: 7, line: { color: C.surface, width: 1 } }, line: { color: policyColor(p), width: 1 }, fillcolor: "rgba(0,0,0,0)", hovertemplate: `${p} seed %{text}: %{y:.4g}<extra></extra>`, text: rows.map((r) => r.seed) }; }),
        { boxmode: "group", yaxis: { title: { text: METRICS[k] } }, xaxis: { tickfont: { size: 10 } } });
      tblHost.innerHTML = "";
      tblHost.append(table([{ label: "scenario", get: (s) => s.name }, ...pols.map((p) => ({ label: p, num: 1, get: (s) => { const r = state.aggregate.find((a) => a.scenario === s.id && a.policy === p); return r ? `${fmt(r[k + ".mean"], 4)} ± ${fmt(r[k + ".mcse"], 4)}` : "—"; } }))], m.scenarios));
    };
    msel.addEventListener("change", draw);
    draw();
    simLauncher(g);
  };
  function simLauncher(g) {
    const topo = state.topo || { scenarios: [], policies: [] };
    const s = el("select", {}, topo.scenarios.map((x) => el("option", { value: x.id }, x.name)));
    const p = el("select", {}, topo.policies.map((x) => el("option", { value: x.id }, x.id)));
    const seed = el("input", { type: "number", value: 42 }), dur = el("input", { type: "number", value: 10, min: 1, max: 30 });
    const status = el("div", { class: "status-line" });
    const btn = el("button", { class: "btn primary", disabled: !!STATIC, onclick: async () => {
      btn.disabled = true; status.textContent = "running in virtual time (bounded: ≤30 s virtual, ≤120 s wall)…";
      try { const r = await post("/api/simulate", { scenario: s.value, policy: p.value, seed: +seed.value, duration_s: +dur.value });
        state.run = r; state.apiRun = r.api_run_id; status.textContent = `SIMULATION run ${r.api_run_id} done in ${fmt(r.resources.wall_s, 1)} s wall · fingerprint ${r.fingerprint.slice(0, 12)}… — shown in Topology/Traffic/Links/Routing/Edge until you change the selectors.`;
      } catch (e) { status.textContent = e.message; } finally { btn.disabled = !!STATIC; } } }, "Run simulation");
    g.append(card("Launch a single simulation", "Runs through the control API with explicit resource limits and cancellation. Results are SIMULATION outputs.", 12,
      el("div", { class: "form" }, el("label", {}, "scenario", s), el("label", {}, "policy", p), el("label", {}, "seed", seed), el("label", {}, "duration s", dur), btn), status));
    if (STATIC) status.textContent = "Static report: start `vhfnet serve` to launch runs.";
  }
  function liveExperiments(g) {
    const preset = el("select", {}, ["loopback_udp", "loopback_tcp", "loopback_quic"].map((x) => el("option", { value: x }, x)));
    const status = el("div", { class: "status-line" });
    const btn = el("button", { class: "btn primary", disabled: !!STATIC || (state.meta && !state.meta.live_enabled), onclick: async () => {
      btn.disabled = true; status.textContent = "LIVE TEST running on loopback (bounded duration/rate/bytes)…";
      try { const r = await post("/api/live", { preset: preset.value, duration_scale: 1.0 }); cache["/api/live"] = undefined; delete cache["/api/live"]; state.liveSel = r.id; await loadLiveList(); status.textContent = `done: ${r.id}`; renderActive(); }
      catch (e) { status.textContent = e.message; } finally { btn.disabled = !!STATIC; } } }, "Run live test");
    g.append(card("Live test (loopback presets)", "Starts a bounded local server process and client. Only loopback presets can be launched from the console; remote endpoints need an explicit, authorised config on the CLI.", 12,
      el("div", { class: "form" }, el("label", {}, "preset", preset), btn), status));
    if (STATIC) status.textContent = "Static report: start `vhfnet serve` to run live tests.";
    g.append(card("Recorded live tests", "", 12, state.live.length ? table([{ label: "id", get: (l) => l.id }, { label: "transport", get: (l) => l.transport }, { label: "name", get: (l) => l.name },
      { label: "goodput Mb/s", num: 1, get: (l) => fmt(l.totals.goodput_mbps, 1) }, { label: "generator-limited", get: (l) => l.totals.generator_limited_flows.join(", ") || "none" }, { label: "request failures", num: 1, get: (l) => l.totals.request_failures }], state.live) : empty("None yet.")));
  }

  // ================================================================== RESULTS
  RENDER.results = (panel) => {
    const g = grid(panel);
    if (state.mode === "LIVE TEST") { liveResults(g); return; }
    const cmp = state.comparison;
    if (!cmp) return g.append(card("Results", "", 12, empty("No comparison available.")));
    const ref = cmp.reference;
    const alts = policyIds().filter((p) => p !== ref);
    if (!state.altPol || !alts.includes(state.altPol)) state.altPol = alts.includes(state.pol) ? state.pol : alts[alts.length - 1];
    const asel = el("select", {}, alts.map((p) => el("option", { value: p }, `${p} vs ${ref}`)));
    asel.value = state.altPol;
    asel.addEventListener("change", () => { state.altPol = asel.value; renderActive(); });
    const keys = Object.keys(METRICS).filter((k) => k !== "route_changes");
    const sb = cmp.scoreboard[state.altPol] || {};
    const tbl = table([{ label: "scenario", get: (s) => s.name }, ...keys.map((k) => ({ label: METRICS[k].replace(/ \(.*\)/, ""), title: METRICS[k], get: (s) => {
      const t = ((cmp.scenarios[s.id] || {})[state.altPol] || {})[k];
      if (!t || t.n === 0) return "·";
      const [ic, , cls] = VERDICT[t.verdict] || ["?", "", ""];
      const rel = isNum(t.rel_change) ? ` ${t.rel_change > 0 ? "+" : ""}${(100 * t.rel_change).toFixed(0)}%` : "";
      return el("span", { class: `verdict ${cls}`, title: `${ref}: ${fmt(t.ref_mean, 4)} → ${state.altPol}: ${fmt(t.alt_mean, 4)}\n95% CI of paired diff [${t.ci95 ? fmt(t.ci95[0], 4) + ", " + fmt(t.ci95[1], 4) : "—"}]\nWilcoxon p=${fmt(t.wilcoxon_p, 3)} · n=${t.n}` }, ic + rel);
    }, cls: (s) => "" }))], state.manifest.scenarios);
    g.append(card("Policy comparison verdicts", `Paired by seed against the reference policy “${ref}”. ▲ better · ▼ worse · ◆ inconclusive · = identical (hover a cell for means, CI and p-value). Rule: ${cmp.rule}`, 12,
      el("div", { class: "form" }, el("label", {}, "comparison", asel), el("span", { class: "pill" }, `▲ ${sb.better || 0}`), el("span", { class: "pill" }, `▼ ${sb.worse || 0}`), el("span", { class: "pill" }, `◆ ${sb.inconclusive || 0}`), el("span", { class: "pill" }, `= ${sb["no-difference"] || 0}`)),
      tbl));
    const stm = (cmp.statements || []);
    g.append(card("Findings (generated from verdicts only)", "No finding is stated unless the paired analysis supports it.", 7,
      el("ul", { class: "notes" }, stm.filter((s) => !s.startsWith("DEGRADATION")).map((s) => el("li", {}, s)))));
    const degs = cmp.degradations.filter((d) => d.policy === state.altPol);
    g.append(card("Per-class degradations", "Priority classes that got significantly worse — an improvement elsewhere must not hide these.", 5,
      degs.length ? el("ul", { class: "notes" }, degs.map((d) => el("li", { class: "deg" }, `${scenName(d.scenario)} · ${d.metric}: ${fmt(d.ref_mean, 4)} → ${fmt(d.alt_mean, 4)}`))) : empty("None detected for this policy.")));
    const en = chart("short");
    g.append(card("Estimated energy by policy", "From configured per-bit and per-core power ASSUMPTIONS (not measured). Mean over seeds.", 6, en));
    plot(en, policyIds().map((p) => { const rows = state.aggregate.filter((r) => r.policy === p); return { type: "bar", name: p, x: rows.map((r) => r.scenario), y: rows.map((r) => r["energy_estimated_j.mean"]), marker: { color: policyColor(p) } }; }), { barmode: "group", yaxis: { title: { text: "J (estimate)" } } });
    const rs = chart("short");
    g.append(card("Simulator resource consumption", "Wall-clock seconds per run on the host that produced these results (software cost, not network performance).", 6, rs));
    plot(rs, policyIds().map((p) => { const rows = state.runsTable.filter((r) => r.policy === p); return { type: "box", name: p, y: rows.map((r) => r.sim_wall_s), marker: { color: policyColor(p) }, line: { color: policyColor(p), width: 1 }, boxpoints: "all", jitter: 0.4, pointpos: 0, fillcolor: "rgba(0,0,0,0)" }; }), { yaxis: { title: { text: "wall s / run" } }, showlegend: false });
    uncertaintyWidgets(g);
  };

  function uncertaintyWidgets(g) {
    const mc = chart(), mcInfo = el("div"), mcStatus = el("div", { class: "status-line" });
    const draws = el("input", { type: "number", value: 20000, min: 1000, max: 200000 }), seed = el("input", { type: "number", value: 7 }), dl = el("input", { type: "number", value: 100 }), mb = el("input", { type: "number", value: 60000 });
    const runMc = async () => {
      mcStatus.textContent = "sampling…";
      try {
        const r = STATIC ? STATIC.routes["/static/montecarlo"] : await post("/api/montecarlo", { draws: +draws.value, seed: +seed.value, deadline_ms: +dl.value, message_bytes: +mb.value });
        mcStatus.textContent = `${r.mode} · ${r.draws} draws · seed ${r.seed}`;
        const xs = r.samples_preview.filter(isNum);
        plot(mc, [{ x: xs, y: xs.map((_, i) => i / (xs.length - 1)), mode: "lines", name: "ECDF", line: { color: C.blue, width: 2, shape: "hv" }, hovertemplate: "%{y:.0%} ≤ %{x:.1f} ms<extra></extra>" }],
          { xaxis: { title: { text: "message latency (ms, log)" }, type: "log" }, yaxis: { tickformat: ".0%", title: { text: "fraction of draws" } }, showlegend: false,
            shapes: [{ type: "line", x0: +dl.value, x1: +dl.value, y0: 0, y1: 1, line: { color: C.gold, width: 1 } }], annotations: [{ x: Math.log10(+dl.value), y: 1, text: "deadline", showarrow: false, font: { color: C.gold, size: 11 }, yshift: 8 }] });
        mcInfo.innerHTML = "";
        mcInfo.append(table([{ label: "quantile", get: (q) => q }, { label: "ms", num: 1, get: (q) => (r.quantiles[q] == null ? "∞ (unstable)" : fmt(r.quantiles[q], 2)) }, { label: "MCSE", num: 1, get: (q) => (r.mcse_quantiles[q] == null ? "—" : fmt(r.mcse_quantiles[q], 3)) }], Object.keys(r.quantiles)),
          el("p", { class: "sub" }, `P(latency > ${dl.value} ms) = ${fmt(Object.values(r.exceedance)[0].prob, 4)} ± ${fmt(Object.values(r.exceedance)[0].mcse, 4)} · unstable draws ${pct(r.nonfinite_fraction, 2)} · mean ${fmt(r.mean, 2)} ± ${fmt(r.mcse_mean, 3)} ms`),
          el("h3", {}, "Sensitivity"), table([{ label: "input", get: (s) => s.input }, { label: "Spearman ρ", num: 1, get: (s) => fmt(s.spearman_rho, 2) }, { label: "p10→p90 swing ms", num: 1, get: (s) => fmt(s.swing, 2) }], r.sensitivity.slice(0, 6)),
          el("h3", { style: "margin-top:8px" }, "Assumptions"), el("ul", { class: "notes" }, r.assumptions.map((a) => el("li", {}, a))));
      } catch (e) { mcStatus.textContent = e.message; }
    };
    g.append(card("Monte Carlo: uncertain link conditions", "Analytic M/M/1 path model, separate from the simulator. Reports draws, seed, quantiles, MCSE, sensitivity and assumptions.", 7,
      el("div", { class: "form" }, el("label", {}, "draws", draws), el("label", {}, "seed", seed), el("label", {}, "deadline ms", dl), el("label", {}, "message bytes", mb), el("button", { class: "btn primary", onclick: runMc }, STATIC ? "Show bundled example" : "Run")), mc, mcStatus, mcInfo));
    const bz = chart("short"), bInfo = el("div"), bStatus = el("div", { class: "status-line" });
    const f = { events_a: 3, trials_a: 1000, events_b: 8, trials_b: 1000, n_extra: 500, future_messages: 100000 };
    const inputs = Object.fromEntries(Object.entries(f).map(([k, v]) => [k, el("input", { type: "number", value: v })]));
    const runB = async () => {
      try {
        const body = Object.fromEntries(Object.entries(inputs).map(([k, i]) => [k, +i.value]));
        const r = STATIC ? STATIC.routes["/static/bayes"] : await post("/api/bayes", body);
        bStatus.textContent = r.assumption;
        const dens = (a, b) => { const xs = [], ys = []; const lb = lgamma(a + b) - lgamma(a) - lgamma(b); const hi = Math.min(1, (a / (a + b)) * 4 + 0.01); for (let i = 1; i < 200; i++) { const x = (hi * i) / 200; xs.push(x); ys.push(Math.exp(lb + (a - 1) * Math.log(x) + (b - 1) * Math.log(1 - x))); } return [xs, ys]; };
        const [xa, ya] = dens(r.route_a.alpha, r.route_a.beta), [xb, yb] = dens(r.route_b.alpha, r.route_b.beta);
        plot(bz, [{ x: xa, y: ya, name: "route A", mode: "lines", line: { color: C.series[0], width: 2 } }, { x: xb, y: yb, name: "route B", mode: "lines", line: { color: C.series[3], width: 2 } }], { xaxis: { title: { text: "event probability (e.g. deadline miss)" }, tickformat: ".1%" }, yaxis: { title: { text: "posterior density" } } });
        const v = r.value_of_information;
        bInfo.innerHTML = "";
        bInfo.append(el("p", { class: "sub" }, `P(A lower) = ${fmt(r.comparison.prob_a_lower, 3)} ± ${fmt(r.comparison.mcse, 3)} (${r.comparison.draws} draws, seed ${r.comparison.seed}). A: ${pct(r.route_a.mean, 2)} [${pct(r.route_a.ci95[0], 2)}, ${pct(r.route_a.ci95[1], 2)}] · B: ${pct(r.route_b.mean, 2)} [${pct(r.route_b.ci95[0], 2)}, ${pct(r.route_b.ci95[1], 2)}].`),
          el("p", { class: "sub" }, `Value of information: EVPI ${fmt(v.evpi_per_message * 1e6, 2)} and EVSI ${fmt(v.evsi_per_message * 1e6, 2)} events per million messages for ${v.n_extra_per_route} more effective observations per route → ${v.recommend_more_measurements ? "more measurement is worth it" : "decide now"} (total ≈ ${fmt(v.evsi_total_events_avoided, 2)} events avoided).`));
      } catch (e) { bStatus.textContent = e.message; }
    };
    g.append(card("Bayesian route comparison", "Beta–Bernoulli posteriors (independence assumed here; the library also offers ESS- and block-based dependence-aware updates for correlated series).", 5,
      el("div", { class: "form" }, Object.entries(inputs).map(([k, i]) => el("label", {}, k.replace(/_/g, " "), i)), el("button", { class: "btn primary", onclick: runB }, STATIC ? "Show bundled example" : "Compute")), bz, bStatus, bInfo));
    runMc(); runB();
  }
  function lgamma(z) { // Lanczos approximation
    const g = 7, p = [0.99999999999980993, 676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059, 12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7];
    if (z < 0.5) return Math.log(Math.PI / Math.sin(Math.PI * z)) - lgamma(1 - z);
    z -= 1; let x = p[0]; for (let i = 1; i < g + 2; i++) x += p[i] / (z + i); const t = z + g + 0.5;
    return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(x);
  }
  function liveResults(g) {
    const r = state.liveRun;
    if (!r) return g.append(card("Live results", "", 12, empty("No live test recorded.")));
    g.append(card(`LIVE TEST · ${r.meta.name}`, r.meta.disclaimer, 12, el("div", { class: "tiles" },
      tile("Transport", r.meta.transport.toUpperCase() + (r.meta.tls ? " + TLS" : "")), tile("Goodput (sum)", fmt(r.totals.goodput_mbps, 1), "Mb/s"),
      tile("Wire sent (est.)", fmt(r.totals.wire_bytes_sent_est / 1e6, 1), "MB"), tile("Request failures", r.totals.request_failures),
      tile("Generator-limited", r.totals.generator_limited_flows.length ? r.totals.generator_limited_flows.join(", ") : "none"),
      tile("Event-loop delay p99", fmt(r.resources.event_loop_delay.p99_ms, 2), "ms", r.resources.event_loop_delay.definition),
      tile("Client CPU (mean)", fmt(r.resources.process.cpu_util_mean_pct, 0), "%", "of one core"), tile("Client RSS (max)", fmt(r.resources.process.rss_max_mb, 0), "MB")),
      el("p", { class: "sub", style: "margin-top:10px" }, `Clock: ${r.meta.clock.basis}. Experimental reliability: ${r.meta.experimental_reliability ? "ON (NACK retransmissions; EXPERIMENTAL, not TCP/QUIC semantics)" : "off"}.`)));
    const cpu = chart("short");
    g.append(card("Client process CPU & memory", "Sampled every 250 ms with psutil (monotonic time base).", 12, cpu));
    const s = r.resources.process.samples || [];
    plot(cpu, [{ x: s.map((p) => p[0]), y: s.map((p) => p[1]), name: "CPU %", mode: "lines", line: { color: C.blue, width: 2 } }], { xaxis: { title: { text: "s" } }, yaxis: { title: { text: "CPU % (one core = 100)" } } });
  }

  // ------------------------------------------------------------------ boot
  async function boot() {
    try { state.meta = await api("/api/meta"); } catch (e) { state.meta = { version: "?" }; }
    document.getElementById("foot-version").textContent = `VHF.NET ${state.meta.version}${STATIC ? " · static report " + (STATIC.generated || "") : ""}`;
    try { state.topo = await api("/api/topology"); } catch (e) { state.topo = null; }
    try { state.exps = await api("/api/experiments"); } catch (e) { state.exps = []; }
    fillSelect(document.getElementById("sel-exp"), state.exps.map((x) => [x.name, `${x.name} (${x.runs} runs)`]), state.exps.find((x) => x.name === "demo") ? "demo" : null);
    if (state.exps.length) await loadExperiment(document.getElementById("sel-exp").value);
    await loadRun();
    await loadLiveList();
    document.getElementById("sel-exp").addEventListener("change", async (e) => { await loadExperiment(e.target.value); await loadRun(); renderActive(); });
    for (const [id, key] of [["sel-scen", "scen"], ["sel-pol", "pol"], ["sel-seed", "seed"]]) {
      document.getElementById(id).addEventListener("change", async (e) => { state[key] = key === "seed" ? +e.target.value : e.target.value; await loadRun(); renderActive(); });
    }
    document.getElementById("sel-live").addEventListener("change", async (e) => { state.liveSel = e.target.value; state.liveRun = await api(`/api/live/${state.liveSel}`); renderActive(); });
    document.querySelectorAll(".mode-btn").forEach((b) => b.addEventListener("click", () => setMode(b.dataset.mode)));
    document.querySelectorAll(".tab").forEach((t) => t.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((x) => x.classList.toggle("active", x === t));
      document.querySelectorAll(".panel").forEach((p) => p.classList.toggle("active", p.id === "tab-" + t.dataset.tab));
      state.tab = t.dataset.tab; renderActive();
    }));
    const hash = new URLSearchParams(location.hash.slice(1));
    let reload = false;
    for (const [k, id] of [["scen", "sel-scen"], ["pol", "sel-pol"], ["seed", "sel-seed"]]) {
      const v = hash.get(k), sel = document.getElementById(id);
      if (v != null && [...sel.options].some((o) => o.value === v)) { sel.value = v; state[k] = k === "seed" ? +v : v; reload = true; }
    }
    if (reload) await loadRun();
    if (hash.get("tab")) document.querySelector(`.tab[data-tab="${hash.get("tab")}"]`)?.click();
    if (hash.get("mode") === "live") setMode("LIVE TEST"); else renderActive();
    window.__vhfReady = true;
  }
  boot();
})();
