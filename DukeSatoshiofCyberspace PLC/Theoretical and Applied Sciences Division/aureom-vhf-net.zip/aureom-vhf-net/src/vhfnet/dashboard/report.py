"""Static, self-contained dashboard snapshot (no server needed to view).

The report is a snapshot of the API's GET routes (taken through FastAPI's test
client, so the data is byte-for-byte what the live console would show) plus one
bundled Monte Carlo and one Bayesian example. Interactive POST features are
disabled in the static file.
"""

from __future__ import annotations

import json
import shutil
import time
from pathlib import Path

from fastapi.testclient import TestClient

from ..api.app import STATIC_DIR, _plotly_js, create_app


def build_report(results_dir: str | Path, out_dir: str | Path, config_path: str | Path,
                 live_config_dir: str | Path = "configs/live", include_plotly: bool = True,
                 detail_experiments: tuple[str, ...] | None = ("demo",)) -> Path:
    """``detail_experiments``: experiments whose per-run detail (time series) is embedded;
    others are included with manifests, aggregates and comparisons only (keeps the file small).
    ``None`` embeds detail for every experiment."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    app = create_app(results_dir, config_path, live_config_dir, enable_live=False)
    cl = TestClient(app)
    routes: dict = {}

    def get(path: str):
        r = cl.get(path)
        r.raise_for_status()
        routes[path] = r.json()
        return routes[path]

    meta = get("/api/meta")
    meta["static"] = True
    meta["live_enabled"] = False
    get("/api/topology")
    for e in get("/api/experiments"):
        name = e["name"]
        man = get(f"/api/experiments/{name}/manifest")
        for sub in ("comparison", "aggregate", "runs"):
            get(f"/api/experiments/{name}/{sub}")
        if detail_experiments is not None and name not in detail_experiments:
            continue
        for p in man.get("detail_runs", []):
            _, scen, pol, seed = p.split("/")
            get(f"/api/experiments/{name}/run/{scen}/{pol}/{seed.replace('seed', '').replace('.json', '')}")
    for lv in get("/api/live"):
        get(f"/api/live/{lv['id']}")
    routes["/static/montecarlo"] = cl.post("/api/montecarlo", json={"draws": 20000, "seed": 7}).json()
    routes["/static/bayes"] = cl.post("/api/bayes", json={"events_a": 3, "trials_a": 1000, "events_b": 8,
                                                          "trials_b": 1000}).json()
    bundle = {"generated": time.strftime("%Y-%m-%d %H:%M"), "routes": routes}
    html = (STATIC_DIR / "index.html").read_text(encoding="utf-8")
    css = (STATIC_DIR / "styles.css").read_text(encoding="utf-8")
    js = (STATIC_DIR / "app.js").read_text(encoding="utf-8")
    data = json.dumps(bundle, separators=(",", ":")).replace("</", "<\\/")
    html = html.replace('<link rel="stylesheet" href="/static/styles.css">', f"<style>{css}</style>")
    html = html.replace("<!--VHF_STATIC_DATA-->", f"<script>window.VHF_STATIC={data};</script>")
    html = html.replace('<script src="/static/app.js"></script>', f"<script>{js}</script>")
    plotly = _plotly_js()
    if include_plotly and plotly is not None:
        shutil.copy(plotly, out / "plotly.min.js")
        html = html.replace('<script src="/static/vendor/plotly.min.js"></script>', '<script src="plotly.min.js"></script>')
    (out / "index.html").write_text(html, encoding="utf-8")
    return out / "index.html"
