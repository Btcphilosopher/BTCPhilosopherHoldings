"""Packets and application messages with measurement fields.

Delay accounting identity (checked by tests) for every delivered packet::

    recv_t - created_t == t_app + t_queue + t_tx + t_prop + t_proc

* ``t_app``   : application/transport wait before the packet entered the network
                (send-buffer wait, pacing, retransmission timers, route-switch hold)
* ``t_queue`` : waiting in link queues (including zero-capacity stalls)
* ``t_tx``    : serialisation time = bits / capacity, integrated over capacity changes
* ``t_prop``  : propagation delay of traversed links
* ``t_proc``  : per-node forwarding / receive processing delay
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

INF = math.inf


@dataclass(slots=True)
class Packet:
    flow_idx: int
    seq: int
    msg_id: int
    frag_idx: int
    frag_count: int
    payload_bytes: int
    header_bytes: int
    created_t: float
    deadline_abs: float
    priority: int
    weight: float
    path: tuple[str, ...]
    sent_t: float = 0.0
    hop: int = 0
    is_retx: bool = False
    tx_count: int = 1
    enq_t: float = 0.0
    t_app: float = 0.0
    t_queue: float = 0.0
    t_tx: float = 0.0
    t_prop: float = 0.0
    t_proc: float = 0.0
    sched_tag: float = 0.0

    @property
    def wire_bytes(self) -> int:
        return self.payload_bytes + self.header_bytes

    @property
    def dst(self) -> str:
        return self.path[-1]


@dataclass(slots=True)
class Message:
    """Application data unit (frame, request, file, update...)."""

    flow_idx: int
    msg_id: int
    created_t: float
    size_bytes: int
    deadline_abs: float
    n_frags: int
    role: str = "data"  # data | request | response | job_input | job_output | migration
    received: int = 0
    complete_t: float = math.nan
    admitted: bool = True
    request_id: int = -1
    got: set[int] | None = field(default=None)

    @property
    def complete(self) -> bool:
        return not math.isnan(self.complete_t)
