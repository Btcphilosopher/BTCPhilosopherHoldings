"""Pre-generated application arrival schedules.

Schedules are generated *before* the simulation from a per-flow random stream,
so every routing/scheduling policy sees exactly the same offered workload for a
given seed (common random numbers).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..config import FlowConfig, SizeConfig


@dataclass
class Schedule:
    times: np.ndarray  # message creation times (s)
    sizes: np.ndarray  # message payload sizes (bytes)

    def __len__(self) -> int:
        return int(self.times.size)

    @property
    def offered_bytes(self) -> int:
        return int(self.sizes.sum())


def arrival_times(flow: FlowConfig, t_end: float, rng: np.random.Generator) -> np.ndarray:
    a = flow.arrival
    t0 = flow.start_s
    t1 = min(t_end, t0 + flow.duration_s) if flow.duration_s else t_end
    if t1 <= t0:
        return np.empty(0)
    span = t1 - t0
    if a.model == "constant":
        n = int(math.floor(span * a.rate_mps - 1e-9)) + 1
        return t0 + np.arange(n) / a.rate_mps
    if a.model == "periodic":
        period = a.period_ms / 1e3
        n = int(math.floor(span / period - 1e-9)) + 1
        base = t0 + np.arange(n) * period
        if a.jitter_ms > 0:
            j = a.jitter_ms / 1e3
            base = base + rng.uniform(-j, j, size=n)
            base = np.sort(np.clip(base, t0, t1 - 1e-12))
        return base
    if a.model == "poisson":
        return _poisson(t0, t1, a.rate_mps, rng)
    if a.model == "onoff":
        out = []
        t = t0
        on = rng.random() < a.on_mean_s / (a.on_mean_s + a.off_mean_s)
        while t < t1:
            dur = rng.exponential(a.on_mean_s if on else a.off_mean_s)
            if on:
                out.append(_poisson(t, min(t + dur, t1), a.rate_mps, rng))
            t += dur
            on = not on
        return np.concatenate(out) if out else np.empty(0)
    if a.model == "backlogged":
        return np.array([t0])
    raise ValueError(a.model)


def _poisson(t0: float, t1: float, rate: float, rng: np.random.Generator) -> np.ndarray:
    expected = (t1 - t0) * rate
    n = int(expected + 6 * math.sqrt(expected + 1) + 16)
    gaps = rng.exponential(1.0 / rate, size=n)
    t = t0 + np.cumsum(gaps)
    while t.size and t[-1] < t1:
        more = t[-1] + np.cumsum(rng.exponential(1.0 / rate, size=n))
        t = np.concatenate([t, more])
    return t[t < t1]


def message_sizes(size: SizeConfig, n: int, rng: np.random.Generator) -> np.ndarray:
    if n == 0:
        return np.empty(0, dtype=np.int64)
    if size.dist == "fixed":
        s = np.full(n, size.bytes, dtype=float)
    elif size.dist == "uniform":
        s = rng.uniform(size.min_bytes, size.max_bytes, size=n)
    elif size.dist == "lognormal":
        mu = math.log(size.bytes) - 0.5 * size.sigma**2
        s = rng.lognormal(mu, size.sigma, size=n)
    elif size.dist == "video":
        # P-frames of ~bytes, an I-frame every keyframe_interval frames (keyframe_ratio x larger)
        k = np.arange(n)
        s = np.where(k % size.keyframe_interval == 0, size.bytes * size.keyframe_ratio, size.bytes)
        s = s * rng.lognormal(-0.5 * 0.15**2, 0.15, size=n)
    else:
        raise ValueError(size.dist)
    return np.clip(np.rint(s), size.min_bytes, size.max_bytes).astype(np.int64)


def build_schedule(flow: FlowConfig, t_end: float, rng: np.random.Generator) -> Schedule:
    times = arrival_times(flow, t_end, rng)
    if flow.kind == "file_transfer":
        if times.size == 0:
            return Schedule(times=np.empty(0), sizes=np.empty(0, dtype=np.int64))
        n = math.ceil(flow.file_bytes / flow.chunk_bytes)
        sizes = np.full(n, flow.chunk_bytes, dtype=np.int64)
        sizes[-1] = flow.file_bytes - flow.chunk_bytes * (n - 1)
        times = np.full(n, times[0])
    else:
        sizes = message_sizes(flow.size, times.size, rng)
    return Schedule(times=np.asarray(times, dtype=float), sizes=sizes)


def offered_rate_bps(flow: FlowConfig, sched: Schedule, t_end: float) -> float:
    t1 = min(t_end, flow.start_s + flow.duration_s) if flow.duration_s else t_end
    span = max(t1 - flow.start_s, 1e-9)
    return sched.offered_bytes * 8 / span
