"""Experimental wireless *abstraction* (not a physical-layer simulator).

This module converts explicit, user-stated radio assumptions into a capacity
time series (bit/s) for the packet simulator. Boundaries:

* Radio abstraction (this file): SINR -> capacity via a capped, derated Shannon
  bound. No fading channel model, no MCS tables, no HARQ, no beam management.
* Packet simulation (``network.py``): consumes only the resulting piecewise-
  constant capacity/availability timeline.
* Application execution (``engine.py`` / ``edge``): never sees radio quantities.

Prospective 6G figures (e.g. sub-THz carriers, multi-GHz channels) are scenario
*parameters*; nothing here predicts deployed performance.

Units: carrier frequency and channel bandwidth in Hz, powers in dBm, gains and
losses in dB, distance in metres, capacity in bit/s.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..config import LinkBudgetConfig

SPEED_OF_LIGHT_M_S = 299_792_458.0
THERMAL_NOISE_DBM_PER_HZ = -174.0  # kT at ~290 K


@dataclass(frozen=True)
class LinkBudgetResult:
    carrier_freq_hz: float
    channel_bw_hz: float
    distance_m: float
    path_loss_db: float
    rx_power_dbm: float
    noise_dbm: float
    interference_dbm: float
    sinr_db: float
    spectral_efficiency_bps_hz: float
    cell_capacity_bps: float
    link_capacity_bps: float  # after slice_share
    assumptions: tuple[str, ...]


def fspl_1m_db(carrier_freq_hz: float) -> float:
    """Free-space path loss at 1 m reference distance (dB)."""
    return 20.0 * math.log10(4.0 * math.pi * carrier_freq_hz / SPEED_OF_LIGHT_M_S)


def path_loss_db(carrier_freq_hz, distance_m, exponent: float):
    d = np.maximum(np.asarray(distance_m, dtype=float), 1.0)
    return fspl_1m_db(carrier_freq_hz) + 10.0 * exponent * np.log10(d)


def noise_dbm(channel_bw_hz: float, noise_figure_db: float) -> float:
    return THERMAL_NOISE_DBM_PER_HZ + 10.0 * math.log10(channel_bw_hz) + noise_figure_db


def capacity_bps(lb: LinkBudgetConfig, distance_m=None, extra_loss_db=0.0, inr_db: float | None = None):
    """Vectorised capacity for the given distances / extra losses (blockage, shadowing)."""
    fc = lb.carrier_freq_ghz * 1e9
    bw = lb.channel_bw_mhz * 1e6
    d = lb.distance_m if distance_m is None else distance_m
    pl = path_loss_db(fc, d, lb.path_loss_exponent)
    prx = lb.tx_power_dbm + lb.tx_gain_dbi + lb.rx_gain_dbi - pl - lb.implementation_loss_db - np.asarray(extra_loss_db)
    n_dbm = noise_dbm(bw, lb.noise_figure_db)
    n_lin = 10 ** (n_dbm / 10)
    i_lin = 0.0 if inr_db is None else n_lin * 10 ** (inr_db / 10)
    sinr_lin = 10 ** (prx / 10) / (n_lin + i_lin)
    sinr_db = 10 * np.log10(sinr_lin)
    se = np.minimum(lb.shannon_efficiency * np.log2(1.0 + sinr_lin), lb.spectral_efficiency_cap_bps_hz)
    se = np.where(sinr_db < lb.min_sinr_db, 0.0, se)
    cell = bw * se
    return cell * lb.slice_share, sinr_db, prx, pl


def link_budget(lb: LinkBudgetConfig, distance_m: float | None = None, extra_loss_db: float = 0.0,
                inr_db: float | None = None) -> LinkBudgetResult:
    fc = lb.carrier_freq_ghz * 1e9
    bw = lb.channel_bw_mhz * 1e6
    d = lb.distance_m if distance_m is None else float(distance_m)
    cap, sinr, prx, pl = capacity_bps(lb, d, extra_loss_db, inr_db)
    n_dbm = noise_dbm(bw, lb.noise_figure_db)
    i_dbm = -math.inf if inr_db is None else n_dbm + inr_db
    se = float(cap) / lb.slice_share / bw
    return LinkBudgetResult(
        carrier_freq_hz=fc,
        channel_bw_hz=bw,
        distance_m=d,
        path_loss_db=float(pl),
        rx_power_dbm=float(prx),
        noise_dbm=n_dbm,
        interference_dbm=i_dbm,
        sinr_db=float(sinr),
        spectral_efficiency_bps_hz=se,
        cell_capacity_bps=float(cap) / lb.slice_share,
        link_capacity_bps=float(cap),
        assumptions=ASSUMPTIONS,
    )


ASSUMPTIONS = (
    "Log-distance path loss anchored to free-space loss at 1 m; no frequency-specific absorption model.",
    "Capacity = slice_share * min(eta * B * log2(1+SINR), B * SE_max); eta and SE_max are user assumptions.",
    "Interference enters only via an explicit interference-to-noise ratio (INR) assumption.",
    "Shadowing is a Gaussian AR(1) process in dB; no small-scale fading, MCS tables, HARQ or beam tracking.",
    "Blockage is an extra attenuation in dB during blockage intervals.",
    "Radio results are symmetric for both link directions; each direction is then capped at its configured capacity.",
    "Prospective 6G values are scenario parameters, not predictions of deployed performance.",
)


def ar1_shadowing_db(n: int, dt: float, sigma_db: float, corr_s: float, rng: np.random.Generator) -> np.ndarray:
    """Stationary Gaussian AR(1) shadowing process sampled every ``dt`` seconds."""
    if n == 0 or sigma_db == 0:
        return np.zeros(n)
    rho = math.exp(-dt / corr_s)
    e = rng.normal(0.0, sigma_db * math.sqrt(1 - rho**2), size=n)
    x = np.empty(n)
    x[0] = rng.normal(0.0, sigma_db)
    for i in range(1, n):
        x[i] = rho * x[i - 1] + e[i]
    return x


def sawtooth_distance(t: np.ndarray, d0: float, speed: float, radius: float, reset: float):
    """Distance to serving cell under constant-speed mobility with hard handovers
    at the cell edge. Returns (distance(t), handover_times)."""
    if speed <= 0:
        return np.full_like(t, d0, dtype=float), []
    handovers = []
    first = (radius - d0) / speed if d0 < radius else 0.0
    period = (radius - reset) / speed
    if period <= 0:
        raise ValueError("mobility.reset_distance_m must be < cell_radius_m")
    if t.size:
        tk = first
        while tk <= t[-1]:
            handovers.append(tk)
            tk += period
    d = np.where(t < first, d0 + speed * t, reset + speed * np.mod(t - first, period))
    return d, handovers
