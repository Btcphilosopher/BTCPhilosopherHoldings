"""Per-link random loss processes (applied after serialisation)."""

from __future__ import annotations

from ..config import LossConfig
from ..rng import UniformBuffer


class NoLoss:
    def lost(self) -> bool:
        return False


class BernoulliLoss:
    def __init__(self, p: float, u: UniformBuffer) -> None:
        self.p, self.u = p, u

    def lost(self) -> bool:
        return self.u() < self.p


class GilbertElliottLoss:
    """Two-state Markov loss (good/bad), state advanced once per packet."""

    def __init__(self, cfg: LossConfig, u: UniformBuffer) -> None:
        self.cfg, self.u = cfg, u
        self.bad = False

    def lost(self) -> bool:
        c = self.cfg
        if self.bad:
            if self.u() < c.p_bad_to_good:
                self.bad = False
        elif self.u() < c.p_good_to_bad:
            self.bad = True
        return self.u() < (c.loss_bad if self.bad else c.loss_good)


def make_loss(cfg: LossConfig, u: UniformBuffer):
    if cfg.model == "none" or (cfg.model == "bernoulli" and cfg.p == 0):
        return NoLoss()
    if cfg.model == "bernoulli":
        return BernoulliLoss(cfg.p, u)
    return GilbertElliottLoss(cfg, u)
