"""Per-(sub)flow runtime state and counters shared by sender and receiver."""

from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field

from ..config import FlowConfig
from ..traffic.packet import Message


@dataclass(eq=False)
class FlowRuntime:
    idx: int
    name: str
    cfg: FlowConfig
    role: str  # data | response | migration
    parent: int
    src: str
    deadline_s: float | None
    priority: int
    weight: float
    reliable: bool
    max_retx: int
    min_rto_s: float
    gen_start: float = 0.0
    gen_end: float = 0.0
    offered_rate_bps: float = 0.0
    messages: list[Message] = field(default_factory=list)
    # sender-side accounting
    offered_msgs: int = 0
    offered_bytes: int = 0
    admitted_msgs: int = 0
    admitted_bytes: int = 0
    rejected_msgs: int = 0
    rejected_bytes: int = 0
    tx_packets: int = 0
    tx_wire_bytes: int = 0
    tx_payload_bytes: int = 0
    retx_packets: int = 0
    unique_seqs_sent: int = 0
    gave_up_packets: int = 0
    spurious_loss_declarations: int = 0
    declared_lost: int = 0
    drops: dict[str, int] = field(default_factory=lambda: defaultdict(int))
    app_scale_sum: float = 0.0
    app_scale_n: int = 0
    # receiver-side accounting
    rx_packets: int = 0
    rx_wire_bytes: int = 0
    dup_packets: int = 0
    reordered_packets: int = 0
    unique_payload_bytes: int = 0
    max_seq: int = -1
    seen: set[int] = field(default_factory=set)
    pending_acks: list[tuple] = field(default_factory=list)
    sample_payload: int = 0
    last_path: tuple[str, ...] | None = None
    sender: object | None = None

    @property
    def is_sub(self) -> bool:
        return self.role != "data"

    @property
    def deadline_abs_for(self):
        d = self.deadline_s
        return (lambda t: t + d) if d else (lambda t: math.inf)
