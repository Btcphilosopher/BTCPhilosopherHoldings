"""Piecewise-constant capacity/availability timeline of one directional link.

The timeline is the single source of truth for what a link *can* carry. Every
transmission integrates capacity over its interval, so a link can never deliver
more bits over any interval than the integral of its capacity (tested).

Semantics:
* ``cap == 0`` and ``up``: interruption (e.g. handover) - the transmitter stalls,
  queued packets wait (buffering).
* ``not up``: outage - in-flight transmission is lost, the queue is flushed and
  arrivals are dropped until the link is up again.
"""

from __future__ import annotations

import bisect
import math

import numpy as np

INF = math.inf


class LinkTimeline:
    __slots__ = ("times", "caps", "up", "_eff", "_cum", "_t_list", "n")

    def __init__(self, times, caps, up) -> None:
        t = np.asarray(times, dtype=float)
        c = np.asarray(caps, dtype=float)
        u = np.asarray(up, dtype=bool)
        if t.size == 0 or t[0] != 0.0:
            raise ValueError("timeline must start at t=0")
        if np.any(np.diff(t) <= 0):
            raise ValueError("timeline breakpoints must be strictly increasing")
        if np.any(c < 0):
            raise ValueError("capacity must be >= 0")
        # merge identical consecutive segments
        keep = np.ones(t.size, dtype=bool)
        keep[1:] = (c[1:] != c[:-1]) | (u[1:] != u[:-1])
        self.times = t[keep]
        self.caps = c[keep]
        self.up = u[keep]
        self.n = self.times.size
        self._eff = np.where(self.up, self.caps, 0.0)
        seg = np.diff(self.times)
        self._cum = np.concatenate([[0.0], np.cumsum(self._eff[:-1] * seg)])
        self._t_list = self.times.tolist()

    @classmethod
    def constant(cls, cap_bps: float) -> "LinkTimeline":
        return cls([0.0], [cap_bps], [True])

    def index(self, t: float) -> int:
        return bisect.bisect_right(self._t_list, t) - 1

    def capacity_at(self, t: float) -> float:
        return float(self.caps[self.index(t)])

    def is_up(self, t: float) -> bool:
        return bool(self.up[self.index(t)])

    def integral(self, t0: float, t1: float) -> float:
        """Bits the link could carry in [t0, t1] (capacity integrated while up)."""
        if t1 <= t0:
            return 0.0
        return self._cum_at(t1) - self._cum_at(t0)

    def _cum_at(self, t: float) -> float:
        i = self.index(t)
        return float(self._cum[i] + self._eff[i] * (t - self.times[i]))

    def next_transmittable(self, t: float) -> float:
        """Earliest time >= t at which the link is up with capacity > 0."""
        i = self.index(t)
        if self.up[i] and self.caps[i] > 0:
            return t
        for j in range(i + 1, self.n):
            if self.up[j] and self.caps[j] > 0:
                return float(self.times[j])
        return INF

    def transmit(self, t0: float, bits: float) -> tuple[float, float, bool]:
        """Serialise ``bits`` starting at ``t0``.

        Returns ``(t_end, tx_time, interrupted)``; ``tx_time`` excludes zero-capacity
        stalls; ``interrupted`` is True if an outage began before completion (then
        ``t_end`` is the outage start and the packet is lost).
        """
        i = self.index(t0)
        t = t0
        remaining = float(bits)
        tx_time = 0.0
        times, caps, up, n = self._t_list, self.caps, self.up, self.n
        while True:
            seg_end = times[i + 1] if i + 1 < n else INF
            if not up[i]:
                return t, tx_time, True
            c = caps[i]
            if c > 0:
                avail = c * (seg_end - t)
                if remaining <= avail * (1 + 1e-12):
                    dt = remaining / c
                    return t + dt, tx_time + dt, False
                remaining -= avail
                tx_time += seg_end - t
            if seg_end == INF:
                return INF, tx_time, False
            t = seg_end
            i += 1

    def down_transitions(self) -> list[float]:
        out = []
        for j in range(self.n):
            if not self.up[j] and (j == 0 or self.up[j - 1]):
                out.append(float(self.times[j]))
        return out

    def summary(self, horizon: float) -> dict:
        down = float(sum(
            (min(self.times[j + 1] if j + 1 < self.n else horizon, horizon) - self.times[j])
            for j in range(self.n) if not self.up[j] and self.times[j] < horizon))
        return {
            "segments": int(self.n),
            "mean_capacity_bps": self.integral(0, horizon) / horizon if horizon > 0 else 0.0,
            "min_capacity_bps": float(self.caps[self.times < horizon].min()),
            "max_capacity_bps": float(self.caps[self.times < horizon].max()),
            "downtime_s": down,
        }

    def sample(self, ts: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        idx = np.searchsorted(self.times, ts, side="right") - 1
        return self.caps[idx], self.up[idx]
