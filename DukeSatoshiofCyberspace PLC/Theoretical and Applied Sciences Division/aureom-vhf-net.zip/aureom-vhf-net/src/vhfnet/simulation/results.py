"""Turn a finished ``Simulation`` into a self-describing result dictionary.

Every number carries its definition (see :mod:`vhfnet.telemetry.metrics`) and the
result states ``mode = SIMULATION``: these are model outputs in virtual time, not
measurements of hardware or of any real network.
"""

from __future__ import annotations

import math
from collections import Counter, defaultdict

import numpy as np

from .. import __version__
from ..telemetry import metrics as M
from ..telemetry.export import fingerprint, to_jsonable
from ..telemetry.resources import peak_rss_mb

QUANTILE_POINTS = np.linspace(0, 100, 101)

SIM_DISCLAIMER = ("SIMULATION: discrete-event model in virtual time. Throughput, latency and loss figures are "
                  "outputs of the stated model assumptions, not measured hardware or network performance.")


def _ms(x):
    return None if x is None else x * 1e3


def _pct_ms(x) -> dict:
    p = M.percentiles(np.asarray(x) * 1e3)
    return p


def _quantiles_ms(x) -> list | None:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return None
    return (np.percentile(x, QUANTILE_POINTS) * 1e3).tolist()


def _packet_stats(arr: dict, mask: np.ndarray, paths_inv: dict) -> dict:
    uniq = mask & ~arr["dup"]
    if not uniq.any():
        return {"unique_packets": 0}
    sent, recv, created = arr["sent"][uniq], arr["recv"][uniq], arr["created"][uniq]
    order = np.argsort(recv, kind="stable")
    transit = (recv - sent)[order]
    s_ord, r_ord = sent[order], recv[order]
    comps = {c: float(arr[c][uniq].mean() * 1e3) for c in ("t_app", "t_queue", "t_tx", "t_prop", "t_proc")}
    path_counts = Counter(arr["path"][uniq].tolist())
    n = int(uniq.sum())
    return {
        "unique_packets": n,
        "owd_ms": _pct_ms(transit),
        "e2e_packet_ms": _pct_ms(recv - created),
        "delay_breakdown_ms": {"application": comps["t_app"], "queueing": comps["t_queue"],
                               "transmission": comps["t_tx"], "propagation": comps["t_prop"],
                               "processing": comps["t_proc"]},
        "jitter_rfc3550_ms": M.jitter_rfc3550(s_ord, r_ord) * 1e3,
        "ipdv_p95_ms": float(np.percentile(M.ipdv(s_ord, r_ord), 95) * 1e3) if n > 2 else None,
        "pdv_p99_ms": float(np.percentile(M.pdv(transit), 99) * 1e3) if n > 1 else None,
        "paths_used": {paths_inv[k]: v / n for k, v in sorted(path_counts.items())},
    }


def _message_stats(fr, horizon: float) -> dict:
    msgs = fr.messages
    total = len(msgs)
    completed = [m for m in msgs if m.complete]
    on_time = [m for m in completed if m.complete_t <= m.deadline_abs]
    rejected = sum(1 for m in msgs if not m.admitted)
    lat = np.array([m.complete_t - m.created_t for m in completed])
    return {
        "offered": total,
        "completed": len(completed),
        "on_time": len(on_time),
        "late": len(completed) - len(on_time),
        "rejected_backpressure": rejected,
        "incomplete": total - len(completed) - rejected,
        "delivery_ratio": M.safe_ratio(len(completed), total),
        "on_time_ratio": M.safe_ratio(len(on_time), total),
        "latency_ms": _pct_ms(lat),
        "latency_quantiles_ms": _quantiles_ms(lat),
        "useful_bytes": int(sum(m.size_bytes for m in on_time)),
        "_complete_times": [m.complete_t for m in completed],
        "_created_on_time": [(m.created_t, m.complete_t) for m in on_time],
    }


def _request_stats(sim, fr) -> dict | None:
    recs = [r for r in sim.requests if r.flow_idx == fr.idx]
    if not recs:
        return None
    st = Counter(r.status() for r in recs)
    succ = [r for r in recs if r.status() in ("ok", "late")]
    comp = np.array([r.complete_t - r.created_t for r in succ])
    fail_frac = 1 - len(succ) / len(recs)

    def mean_ms(vals):
        v = np.asarray([x for x in vals if x is not None and math.isfinite(x)])
        return float(v.mean() * 1e3) if v.size else None

    inp = [r.input_done_t - r.created_t for r in succ]
    wait = [r.job_start_t - r.input_done_t for r in succ if not math.isnan(r.job_start_t)]
    proc = [r.job_end_t - r.job_start_t for r in succ if not math.isnan(r.job_start_t)]
    out = [r.complete_t - (r.job_end_t if not math.isnan(r.job_end_t) else r.input_done_t) for r in succ]
    est_err = [abs(r.placement_estimate_s - (r.complete_t - r.created_t)) for r in succ
               if r.placement_estimate_s is not None and math.isfinite(r.placement_estimate_s)]
    p = M.percentiles(comp * 1e3)
    p99_with_failures = p["p99"] if fail_frac <= 0.01 else None
    by_node = defaultdict(lambda: Counter())
    for r in recs:
        by_node[r.node][r.status()] += 1
    return {
        "total": len(recs),
        "status": dict(st),
        "success_ratio": len(succ) / len(recs),
        "on_time_ratio": st.get("ok", 0) / len(recs),
        "failure_ratio": fail_frac,
        "completion_ms": p,
        "completion_quantiles_ms": _quantiles_ms(comp),
        "p99_including_failures_ms": p99_with_failures,
        "p99_including_failures_note": "null when >1% of requests failed (p99 unbounded)",
        "breakdown_mean_ms": {"input_transfer": mean_ms(inp), "waiting": mean_ms(wait),
                              "processing": mean_ms(proc), "output_transfer": mean_ms(out)},
        "placement": {k: dict(v) for k, v in sorted(by_node.items())},
        "placement_estimate_abs_error_ms": mean_ms(est_err),
    }


def summarise(sim, wall_s: float, cpu_s: float) -> dict:
    cfg, horizon, duration = sim.cfg, sim.horizon, sim.duration
    arr = sim.log.arrays()
    n_log = arr["flow"].size
    if n_log == 0:
        arr = {k: np.empty(0, dtype=bool if k in ("dup", "retx", "reord") else float) for k in sim.log.FIELDS}
        arr["flow"] = np.empty(0, dtype=int)
        arr["path"] = np.empty(0, dtype=int)
    paths_inv = {v: ">".join(k) for k, v in sim.log.paths.items()}
    route_changes = sim.router.changes
    rc_per_flow = Counter(c.flow for c in route_changes)

    flows_out = []
    class_acc: dict[int, dict] = defaultdict(lambda: defaultdict(float))
    class_lat: dict[int, list] = defaultdict(list)
    totals = defaultdict(float)
    deliv_ratios, goodputs = [], []
    requests_out = {}
    for fr in sim.flows:
        if fr.role != "data":
            continue
        f = fr.cfg
        window = max(fr.gen_end - fr.gen_start, 1e-9)
        subs = [x for x in sim.flows if x.role == "response" and x.parent == fr.idx]
        group = [fr] + subs
        offered_b = sum(x.offered_bytes for x in group)
        tx_wire = sum(x.tx_wire_bytes for x in group)
        tx_payload = sum(x.tx_payload_bytes for x in group)
        rx_wire = sum(x.rx_wire_bytes for x in group)
        uniq_payload = sum(x.unique_payload_bytes for x in group)
        mstats = _message_stats(fr, horizon)
        useful = mstats["useful_bytes"]
        req = _request_stats(sim, fr)
        if req is not None:
            requests_out[fr.name] = req
            useful = sum(r.input_bytes + r.output_bytes for r in sim.requests
                         if r.flow_idx == fr.idx and r.status() == "ok")
        mask = arr["flow"] == fr.idx
        pstats = _packet_stats(arr, mask, paths_inv)
        unique_sent = sum(x.unique_seqs_sent for x in group)
        unique_recv = sum(len(x.seen) for x in group)
        drops = Counter()
        for x in group:
            drops.update(x.drops)
        delivered_ratio = (uniq_payload / offered_b) if offered_b else None
        recv_times = arr["recv"][mask & ~arr["dup"]]
        gap = M.max_gap(recv_times, fr.gen_start, fr.gen_end) if offered_b else None
        starved = bool(delivered_ratio is not None and delivered_ratio < cfg.starvation_fraction)
        snd = fr.sender
        aoi = None
        if f.kind == "twin_update":
            ct = mstats["_created_on_time"]
            comp_pairs = [(m.created_t, m.complete_t) for m in fr.messages if m.complete]
            if comp_pairs:
                g, r = zip(*comp_pairs)
                aoi = M.age_of_information(g, r, fr.gen_start, fr.gen_end)
        fct = None
        file_progress = None
        if f.kind == "file_transfer" and fr.messages:
            done = [m for m in fr.messages if m.complete]
            file_progress = sum(m.size_bytes for m in done) / max(1, sum(m.size_bytes for m in fr.messages))
            if len(done) == len(fr.messages):
                fct = max(m.complete_t for m in done) - fr.messages[0].created_t
        deadline_flow = f.deadline_ms is not None
        if req is not None:
            n_msgs, n_miss = req["total"], req["total"] - req["status"].get("ok", 0)
        else:
            n_msgs, n_miss = mstats["offered"], mstats["offered"] - mstats["on_time"]
        row = {
            "id": fr.name, "kind": f.kind, "src": f.src, "dst": f.dst, "priority": f.priority,
            "deadline_ms": f.deadline_ms, "reliability_mode": f.reliability.mode,
            "target_delivery_ratio": f.reliability.target_delivery_ratio, "max_rate_mbps": f.max_rate_mbps,
            "window_s": window,
            "offered_bytes": offered_b, "offered_bps": offered_b * 8 / window,
            "admitted_bytes": sum(x.admitted_bytes for x in group),
            "rejected_bytes_backpressure": sum(x.rejected_bytes for x in group),
            "transmitted_wire_bytes": tx_wire, "transmitted_wire_bps": tx_wire * 8 / window,
            "header_overhead_ratio": M.safe_ratio(tx_wire - tx_payload, tx_wire),
            "retransmitted_packets": sum(x.retx_packets for x in group),
            "delivered_wire_bytes": rx_wire, "delivered_wire_bps": rx_wire * 8 / window,
            "duplicate_packets": sum(x.dup_packets for x in group),
            "reordered_packets": sum(x.reordered_packets for x in group),
            "unique_payload_bytes": uniq_payload, "goodput_bps": uniq_payload * 8 / window,
            "useful_bytes": useful, "useful_goodput_bps": useful * 8 / window,
            "packet_loss_ratio": (1 - unique_recv / unique_sent) if unique_sent else None,
            "network_drops": dict(sorted(drops.items())),
            "delivery_ratio_bytes": delivered_ratio,
            "messages": {k: v for k, v in mstats.items() if not k.startswith("_")},
            "deadline_miss_ratio": (n_miss / n_msgs) if (deadline_flow and n_msgs) else None,
            "meets_reliability_objective": (
                (req["success_ratio"] if req else (mstats["delivery_ratio"] or 0.0))
                >= f.reliability.target_delivery_ratio) if n_msgs else None,
            "max_delivery_gap_s": gap,
            "starved": starved,
            "age_of_information_ms": _ms(aoi),
            "flow_completion_time_s": fct,
            "file_progress": file_progress,
            "app_rate_scale_mean": (fr.app_scale_sum / fr.app_scale_n) if fr.app_scale_n else None,
            "route_changes": rc_per_flow.get(fr.name, 0),
            "transport": snd.stats() if snd else None,
            **pstats,
        }
        flows_out.append(row)
        if delivered_ratio is not None:
            deliv_ratios.append(min(delivered_ratio, 1.0))
            goodputs.append(row["goodput_bps"])
        ca = class_acc[f.priority]
        ca["flows"] += 1
        ca["offered_bps"] += row["offered_bps"]
        ca["goodput_bps"] += row["goodput_bps"]
        ca["useful_goodput_bps"] += row["useful_goodput_bps"]
        if deadline_flow:
            ca["deadline_msgs"] += n_msgs
            ca["deadline_misses"] += n_miss
        if req is not None and req["completion_quantiles_ms"]:
            class_lat[f.priority].extend([r.complete_t - r.created_t for r in sim.requests
                                          if r.flow_idx == fr.idx and r.status() in ("ok", "late")])
        else:
            class_lat[f.priority].extend([m.complete_t - m.created_t for m in fr.messages if m.complete])
        for k in ("offered_bps", "goodput_bps", "useful_goodput_bps"):
            totals[k] += row[k]
        totals["transmitted_wire_bytes"] += tx_wire
        totals["transmitted_payload_bytes"] += tx_payload
        totals["delivered_wire_bytes"] += rx_wire
        totals["retx_packets"] += row["retransmitted_packets"]
        totals["tx_packets"] += sum(x.tx_packets for x in group)
        totals["dup_packets"] += row["duplicate_packets"]
        if deadline_flow:
            totals["deadline_msgs"] += n_msgs
            totals["deadline_misses"] += n_miss
        totals["starved_flows"] += int(starved)

    classes = {}
    for prio in sorted(class_acc):
        ca = class_acc[prio]
        lat = np.asarray(class_lat[prio])
        classes[str(prio)] = {
            "flows": int(ca["flows"]), "offered_bps": ca["offered_bps"], "goodput_bps": ca["goodput_bps"],
            "useful_goodput_bps": ca["useful_goodput_bps"],
            "deadline_miss_ratio": (ca["deadline_misses"] / ca["deadline_msgs"]) if ca["deadline_msgs"] else None,
            "latency_p99_ms": float(np.percentile(lat, 99) * 1e3) if lat.size else None,
            "latency_p50_ms": float(np.percentile(lat, 50) * 1e3) if lat.size else None,
        }

    links_out = [link.finish(horizon) for link in sim.network.by_id.values()]
    compute_out = [srv.finish(horizon) for srv in sim.compute.values()]
    conserved = all(l["tx_bits"] <= l["capacity_integral_bits"] * (1 + 1e-9) + 1.0 for l in links_out)

    # delay identity check on all logged packets
    if n_log:
        ident = arr["recv"] - arr["created"] - (arr["t_app"] + arr["t_queue"] + arr["t_tx"] + arr["t_prop"] + arr["t_proc"])
        ident_err = float(np.max(np.abs(ident)))
    else:
        ident_err = 0.0
    total_drops = sum(sum(l["drops"].values()) for l in links_out)
    rx_total = sum(fr.rx_packets for fr in sim.flows)
    in_flight = sim.network.injected - rx_total - total_drops

    jobs = [j for j in sim.jobs if not j.background]
    jobs_sample = [{"job": j.job_id, "node": j.node, "flow": sim.flows[j.flow_idx].name if j.flow_idx >= 0 else None,
                    "arrival_t": j.arrival_t, "start_t": j.start_t, "end_t": j.end_t, "rejected": j.rejected}
                   for j in jobs[:: max(1, len(jobs) // 1500)]]

    energy_links = sum(l["energy_estimated_j"] for l in links_out)
    energy_compute = sum(c["energy_estimated_j"] for c in compute_out)
    window = duration
    tot = {
        "offered_bps": totals["offered_bps"],
        "transmitted_wire_bps": totals["transmitted_wire_bytes"] * 8 / window,
        "delivered_wire_bps": totals["delivered_wire_bytes"] * 8 / window,
        "goodput_bps": totals["goodput_bps"],
        "useful_goodput_bps": totals["useful_goodput_bps"],
        "header_overhead_ratio": M.safe_ratio(totals["transmitted_wire_bytes"] - totals["transmitted_payload_bytes"],
                                              totals["transmitted_wire_bytes"]),
        "retransmission_ratio": M.safe_ratio(totals["retx_packets"], totals["tx_packets"]),
        "duplicate_packets": int(totals["dup_packets"]),
        "deadline_messages": int(totals["deadline_msgs"]),
        "deadline_misses": int(totals["deadline_misses"]),
        "deadline_miss_ratio": M.safe_ratio(totals["deadline_misses"], totals["deadline_msgs"]),
        "requests_total": sum(r["total"] for r in requests_out.values()),
        "request_failures": sum(r["total"] - r["status"].get("ok", 0) - r["status"].get("late", 0)
                                for r in requests_out.values()),
        "route_changes": len(route_changes),
        "starved_flows": int(totals["starved_flows"]),
        "energy_estimated_j": {"links": energy_links, "compute": energy_compute, "total": energy_links + energy_compute,
                               "note": "ESTIMATE from configured energy assumptions; not measured"},
    }
    fairness = {
        "jain_delivery_ratio": M.jain_index(deliv_ratios),
        "jain_goodput": M.jain_index(goodputs),
        "min_delivery_ratio": min(deliv_ratios) if deliv_ratios else None,
        "starved_flows": [r["id"] for r in flows_out if r["starved"]],
        "definition": ("Jain index over per-flow delivery ratio (unique payload delivered / offered); a flow is "
                       f"starved if its delivery ratio < {cfg.starvation_fraction}"),
    }

    ts = sim.ts
    timeseries = {
        "t": ts["t"],
        "links": {k: dict(v) for k, v in ts["links"].items()},
        "flows": {k: dict(v) for k, v in ts["flows"].items()},
        "compute": {k: dict(v) for k, v in ts["compute"].items()},
        "rate_history": {fr.name: fr.sender.rate_samples[:: max(1, len(fr.sender.rate_samples) // 400)]
                         for fr in sim.flows if fr.role == "data" and fr.sender and fr.sender.rate_samples},
    }
    conditions = {lid: {"handover_times": c.handover_times, "blockage_windows": c.blockage_windows,
                        "outage_windows": c.outage_windows, "radio_assumptions": list(c.radio_assumptions)}
                  for lid, c in sim.conditions.items()}
    sc, pol = sim.scenario, sim.policy
    result = {
        "meta": {
            "mode": "SIMULATION",
            "disclaimer": SIM_DISCLAIMER,
            "experiment": cfg.name,
            "topology": cfg.topology.name,
            "topology_fictional": cfg.topology.fictional,
            "scenario": {"id": sc.id, "name": sc.name, "description": sc.description,
                         "events": [e.model_dump(exclude_none=True) for e in sc.events]},
            "policy": pol.model_dump(),
            "seed": sim.seed,
            "duration_s": duration,
            "drain_s": cfg.drain_s,
            "horizon_s": horizon,
            "mtu_payload_bytes": cfg.mtu_payload_bytes,
            "header_bytes": cfg.header_bytes,
            "sample_interval_ms": cfg.sample_interval_ms,
            "vhfnet_version": __version__,
            "metric_definitions": {**M.JITTER_DEFINITIONS,
                                   "goodput_bps": "unique payload bits delivered / flow generation window",
                                   "useful_goodput_bps": "payload bits of messages (requests: request+response) "
                                                         "completed on time / generation window",
                                   "owd_ms": "packet network transit (recv - first-hop send); exact in simulation "
                                             "(single virtual clock)",
                                   "deadline_miss_ratio": "(late + incomplete + rejected) / offered messages "
                                                          "(requests for request/response flows)"},
            "assumptions": [
                "Feedback (acks) returns over the reverse path with propagation+processing delay only.",
                "Routers see link state through periodic, delayed control-plane reports.",
                "Node forwarding is a fixed per-packet processing delay (no forwarding-capacity limit).",
                "Compute work is in abstract giga-operations; service time = overhead + work / per-core speed.",
                "Energy figures are estimates from configured per-bit and per-core power assumptions.",
            ],
        },
        "totals": tot,
        "fairness": fairness,
        "classes": classes,
        "flows": flows_out,
        "requests": requests_out,
        "links": links_out,
        "compute": compute_out,
        "jobs_sample": jobs_sample,
        "routes": {"count": len(route_changes),
                   "changes": [c.__dict__ for c in route_changes[:2000]],
                   "per_flow": dict(rc_per_flow)},
        "migrations": sim.migration_log,
        "conditions": conditions,
        "integrity": {
            "capacity_conserved": conserved,
            "max_link_utilisation": max((l["utilisation"] for l in links_out), default=0.0),
            "delay_identity_max_abs_error_s": ident_err,
            "packets_injected": sim.network.injected,
            "packets_delivered_incl_duplicates": rx_total,
            "packets_dropped": total_drops,
            "packets_in_flight_at_end": in_flight,
            "control_plane_reports": sim.control.reports,
        },
        "timeseries": timeseries,
    }
    result = to_jsonable(result)
    result["fingerprint"] = fingerprint(result)
    result["resources"] = {
        "note": "Simulator software cost on this host (NOT network performance).",
        "wall_s": wall_s,
        "cpu_s": cpu_s,
        "events": sim.events_processed,
        "events_per_wall_s": sim.events_processed / wall_s if wall_s > 0 else None,
        "simulated_packets_per_wall_s": sim.network.injected / wall_s if wall_s > 0 else None,
        "virtual_to_wall_ratio": horizon / wall_s if wall_s > 0 else None,
        "peak_rss_mb": peak_rss_mb(),
    }
    return result
