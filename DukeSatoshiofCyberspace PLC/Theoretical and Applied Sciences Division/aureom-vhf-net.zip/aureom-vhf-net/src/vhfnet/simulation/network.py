"""Discrete-event packet network (SimPy, virtual time).

A ``SimLink`` is one *direction* of a configured link: a bounded queue (FIFO,
WFQ or EDF) feeding a single transmitter whose service rate follows the link's
capacity timeline, followed by a loss process and propagation delay. Each hop
costs exactly two scheduled events per packet (end of serialisation, arrival
at the next node after propagation + node processing).
"""

from __future__ import annotations

import math
from collections import defaultdict
from typing import Callable

import simpy

from ..config import ExperimentConfig, QueueConfig
from ..scheduling import make_queue
from ..traffic.packet import Packet
from .timeline import LinkTimeline
from .topology import DirLinkSpec, Graph

INF = math.inf

DROP_CAUSES = ("buffer", "channel", "outage", "expired", "stalled")


class SimLink:
    def __init__(self, env: simpy.Environment, spec: DirLinkSpec, timeline: LinkTimeline, qcfg: QueueConfig,
                 discipline: str, loss, dst_proc_s: float, network: "Network", trace: bool = False,
                 energy_per_bit_nj: float = 0.0, idle_power_w: float = 0.0) -> None:
        self.env = env
        self.spec = spec
        self.id = spec.dir_id
        self.timeline = timeline
        self.queue = make_queue(discipline, qcfg.buffer_bytes)
        self.discipline = discipline
        self.buffer_bytes = qcfg.buffer_bytes
        self.drop_expired = qcfg.drop_expired
        self.loss = loss
        self.prop_s = spec.prop_s
        self.dst_proc_s = dst_proc_s
        self.network = network
        self.energy_per_bit_nj = energy_per_bit_nj
        self.idle_power_w = idle_power_w
        self._waiting: simpy.Event | None = None
        # statistics
        self.offered_packets = 0
        self.tx_packets = 0
        self.tx_bits = 0.0
        self.partial_bits = 0.0
        self.delivered_packets = 0
        self.drops: dict[str, int] = defaultdict(int)
        self.drop_bytes: dict[str, int] = defaultdict(int)
        self.q_area = 0.0
        self.q_last_t = 0.0
        self.q_max = 0
        self.busy_time = 0.0
        self.trace = trace
        self.tx_log: list[tuple[float, float, int]] = []
        # interval counters (control plane / sampler read and reset these)
        self.iv_offered = 0
        self.iv_drops = 0
        self.iv_bits = 0.0
        self.sample_bits = 0.0
        env.process(self._run())
        if timeline.down_transitions():
            env.process(self._outage_watch())

    # -- queue occupancy integral ------------------------------------------------
    def _q_touch(self, now: float) -> None:
        self.q_area += self.queue.bytes * (now - self.q_last_t)
        self.q_last_t = now

    def _drop(self, pkt: Packet, cause: str) -> None:
        self.drops[cause] += 1
        self.drop_bytes[cause] += pkt.payload_bytes + pkt.header_bytes
        self.iv_drops += 1
        self.network.on_drop(self, pkt, cause)

    def offer(self, pkt: Packet) -> None:
        now = self.env.now
        self.offered_packets += 1
        self.iv_offered += 1
        if not self.timeline.is_up(now):
            self._drop(pkt, "outage")
            return
        pkt.enq_t = now
        self._q_touch(now)
        for d in self.queue.enqueue(pkt, now):
            if d is not pkt:
                d.t_queue += now - d.enq_t
            self._drop(d, "buffer")
        if self.queue.bytes > self.q_max:
            self.q_max = self.queue.bytes
        w = self._waiting
        if w is not None and not w.triggered:
            w.succeed()

    def _run(self):
        env = self.env
        tl = self.timeline
        while True:
            if len(self.queue) == 0:
                self._waiting = env.event()
                yield self._waiting
                self._waiting = None
                continue
            now = env.now
            t_ok = tl.next_transmittable(now)
            if t_ok > now:
                if t_ok == INF:
                    self._waiting = env.event()
                    yield self._waiting
                    self._waiting = None
                else:
                    yield env.timeout(t_ok - now)
                continue
            self._q_touch(now)
            pkt = self.queue.dequeue(now)
            if pkt is None:
                continue
            pkt.t_queue += now - pkt.enq_t
            if self.drop_expired and pkt.deadline_abs < now:
                self._drop(pkt, "expired")
                continue
            bits = (pkt.payload_bytes + pkt.header_bytes) * 8.0
            t_end, tx_time, interrupted = tl.transmit(now, bits)
            if t_end == INF:
                self._drop(pkt, "stalled")
                continue
            yield env.timeout(t_end - now)
            self.busy_time += t_end - now
            if interrupted:
                self.partial_bits += tl.integral(now, t_end)
                pkt.t_queue += t_end - now
                self._drop(pkt, "outage")
                continue
            pkt.t_tx += tx_time
            pkt.t_queue += (t_end - now) - tx_time
            self.tx_packets += 1
            self.tx_bits += bits
            self.iv_bits += bits
            self.sample_bits += bits
            if self.trace:
                self.tx_log.append((now, t_end, int(bits)))
            if self.loss.lost():
                self._drop(pkt, "channel")
                continue
            self.delivered_packets += 1
            pkt.t_prop += self.prop_s
            pkt.t_proc += self.dst_proc_s
            ev = env.timeout(self.prop_s + self.dst_proc_s, pkt)
            ev.callbacks.append(self.network.arrive)

    def _outage_watch(self):
        env = self.env
        for t in self.timeline.down_transitions():
            if t > env.now:
                yield env.timeout(t - env.now)
            now = env.now
            self._q_touch(now)
            for pkt in self.queue.flush():
                pkt.t_queue += now - pkt.enq_t
                self._drop(pkt, "outage")

    def finish(self, horizon: float) -> dict:
        self._q_touch(horizon)
        cap_bits = self.timeline.integral(0.0, horizon)
        energy_j = self.tx_bits * self.energy_per_bit_nj * 1e-9 + self.idle_power_w * horizon
        return {
            "link": self.id,
            "link_id": self.spec.link_id,
            "src": self.spec.src,
            "dst": self.spec.dst,
            "discipline": self.discipline,
            "nominal_capacity_bps": self.spec.capacity_bps,
            "capacity_integral_bits": cap_bits,
            "tx_bits": self.tx_bits,
            "partial_bits_lost_to_outage": self.partial_bits,
            "utilisation": (self.tx_bits / cap_bits) if cap_bits > 0 else 0.0,
            "busy_fraction": self.busy_time / horizon if horizon > 0 else 0.0,
            "offered_packets": self.offered_packets,
            "tx_packets": self.tx_packets,
            "delivered_packets": self.delivered_packets,
            "drops": {c: int(self.drops.get(c, 0)) for c in DROP_CAUSES},
            "drop_bytes": {c: int(self.drop_bytes.get(c, 0)) for c in DROP_CAUSES},
            "queue_mean_bytes": self.q_area / horizon if horizon > 0 else 0.0,
            "queue_max_bytes": int(self.q_max),
            "buffer_bytes": self.buffer_bytes,
            "energy_estimated_j": energy_j,
            "timeline": self.timeline.summary(horizon),
        }


class Network:
    """Holds directional links and forwards packets along their source route."""

    def __init__(self, env: simpy.Environment, cfg: ExperimentConfig, graph: Graph,
                 timelines: dict[str, LinkTimeline], losses: dict[str, object],
                 discipline_override: str | None, trace: bool = False) -> None:
        self.env = env
        self.graph = graph
        self.links: dict[tuple[str, str], SimLink] = {}
        self.by_id: dict[str, SimLink] = {}
        lcfg = {lk.id: lk for lk in cfg.topology.links}
        for (src, dst), spec in graph.dirlinks.items():
            lk = lcfg[spec.link_id]
            disc = discipline_override or lk.queue.discipline
            link = SimLink(env, spec, timelines[spec.dir_id], lk.queue, disc, losses[spec.dir_id],
                           graph.nodes[dst].processing_delay_us / 1e6, self, trace=trace,
                           energy_per_bit_nj=lk.energy.energy_per_bit_nj,
                           idle_power_w=lk.energy.idle_power_w / 2.0)
            self.links[(src, dst)] = link
            self.by_id[spec.dir_id] = link
        self.on_deliver: Callable[[Packet], None] = lambda p: None
        self.on_drop_cb: Callable[[SimLink, Packet, str], None] = lambda l, p, c: None
        self.injected = 0

    def inject(self, pkt: Packet) -> None:
        """Hand a packet to the network at its source node (after source processing)."""
        self.injected += 1
        src_proc = self.graph.nodes[pkt.path[0]].processing_delay_us / 1e6
        pkt.hop = 0
        pkt.t_proc += src_proc
        if len(pkt.path) == 1:
            ev = self.env.timeout(src_proc, pkt)
            ev.callbacks.append(lambda e: self.on_deliver(e.value))
            return
        link = self.links[(pkt.path[0], pkt.path[1])]
        if src_proc > 0:
            ev = self.env.timeout(src_proc, pkt)
            ev.callbacks.append(lambda e, l=link: l.offer(e.value))
        else:
            link.offer(pkt)

    def arrive(self, ev) -> None:
        pkt: Packet = ev.value
        pkt.hop += 1
        if pkt.hop >= len(pkt.path) - 1:
            self.on_deliver(pkt)
            return
        self.links[(pkt.path[pkt.hop], pkt.path[pkt.hop + 1])].offer(pkt)

    def on_drop(self, link: SimLink, pkt: Packet, cause: str) -> None:
        self.on_drop_cb(link, pkt, cause)
