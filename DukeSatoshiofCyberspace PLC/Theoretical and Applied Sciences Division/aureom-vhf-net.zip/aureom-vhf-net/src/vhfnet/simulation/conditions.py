"""Build per-direction link timelines from configuration + scenario events.

Order of composition at each breakpoint ``t`` (documented, deterministic):

1. nominal direction capacity (config)
2. wireless model: Markov factor, or ``min(nominal, link-budget capacity)``
3. scenario ``capacity_scale`` factors (multiplicative), then ``capacity_set`` overrides
4. ``blockage`` on non-link-budget links (multiplicative factor)
5. handover interruptions (mobility-driven or scenario) -> capacity 0, link up (buffering)
6. outages (scenario or random MTBF/MTTR) -> link down (drop)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ..config import LinkConfig, ScenarioEvent
from ..rng import stream
from . import wireless as wl
from .timeline import LinkTimeline

INF = math.inf


@dataclass
class LinkConditions:
    forward: LinkTimeline
    reverse: LinkTimeline
    handover_times: list[float] = field(default_factory=list)
    blockage_windows: list[tuple[float, float, float]] = field(default_factory=list)
    outage_windows: list[tuple[float, float]] = field(default_factory=list)
    radio_assumptions: tuple[str, ...] = ()


def _windows(events, kind):
    out = []
    for ev in events:
        if ev.kind == kind:
            end = INF if ev.duration_s is None else ev.at_s + ev.duration_s
            out.append((ev.at_s, end, ev))
    return out


def _random_downtime(mtbf, mttr, horizon, rng):
    out = []
    t = 0.0
    while True:
        t += rng.exponential(mtbf)
        if t >= horizon:
            return out
        d = rng.exponential(mttr)
        out.append((t, t + d))
        t += d


def build_link_conditions(link: LinkConfig, events: list[ScenarioEvent], horizon: float, seed: int,
                          disable_wireless_variation: bool = False) -> LinkConditions:
    evs = [e for e in events if e.target == link.id]
    caps = (link.capacity_mbps * 1e6, (link.capacity_mbps_reverse or link.capacity_mbps) * 1e6)
    bps: set[float] = {0.0}
    w = link.wireless
    info = LinkConditions(LinkTimeline.constant(caps[0]), LinkTimeline.constant(caps[1]))

    # ---- wireless model -------------------------------------------------------
    markov_times = markov_factors = None
    grid_dt = None
    radio_fn = None
    zero_windows: list[tuple[float, float]] = []
    lb_block: list[tuple[float, float, float]] = []
    if w is not None and w.model == "markov" and not disable_wireless_variation:
        rng = stream(seed, "link", link.id, "markov")
        dwell = np.asarray(w.markov_mean_dwell_s)
        p0 = dwell / dwell.sum()
        s = int(rng.choice(len(dwell), p=p0))
        t = 0.0
        ts, fs = [], []
        while t < horizon:
            ts.append(t)
            fs.append(w.markov_factors[s])
            t += rng.exponential(dwell[s])
            if len(dwell) > 1:
                s = int(rng.choice([k for k in range(len(dwell)) if k != s]))
        markov_times, markov_factors = np.asarray(ts), np.asarray(fs)
        bps.update(ts)
    elif w is not None and w.model == "link_budget":
        lb = w.link_budget
        info.radio_assumptions = wl.ASSUMPTIONS + tuple(w.assumptions)
        grid_dt = w.coherence_interval_ms / 1e3
        grid = np.arange(0.0, horizon + grid_dt, grid_dt)
        inr = w.interference.inr_db if w.interference else None
        if disable_wireless_variation:
            shadow = np.zeros(grid.size)
            dist = np.full(grid.size, lb.distance_m)
        else:
            shadow = wl.ar1_shadowing_db(grid.size, grid_dt, w.shadowing_sigma_db, w.shadowing_corr_s,
                                         stream(seed, "link", link.id, "shadowing"))
            if w.mobility is not None:
                dist, hos = wl.sawtooth_distance(grid, lb.distance_m, w.mobility.speed_mps,
                                                 w.mobility.cell_radius_m, w.mobility.reset_distance_m)
                info.handover_times = [float(h) for h in hos if h < horizon]
                hi = w.mobility.handover_interruption_ms / 1e3
                zero_windows += [(h, h + hi) for h in info.handover_times if hi > 0]
            else:
                dist = np.full(grid.size, lb.distance_m)
            if w.blockage is not None and w.blockage.rate_per_s > 0:
                rng = stream(seed, "link", link.id, "blockage")
                t = 0.0
                while True:
                    t += rng.exponential(1.0 / w.blockage.rate_per_s)
                    if t >= horizon:
                        break
                    d = rng.exponential(w.blockage.mean_duration_s)
                    lb_block.append((t, t + d, w.blockage.attenuation_db))
        bps.update(grid[grid < horizon].tolist())

        def radio_fn(ts: np.ndarray, extra_db: np.ndarray) -> np.ndarray:
            gi = np.minimum((ts / grid_dt).astype(int), grid.size - 1)
            cap, _, _, _ = wl.capacity_bps(lb, dist[gi], shadow[gi] + extra_db, inr)
            return cap

    # ---- scenario windows -----------------------------------------------------
    scale_w = _windows(evs, "capacity_scale")
    set_w = _windows(evs, "capacity_set")
    out_w = [(s, e) for s, e, _ in _windows(evs, "outage")]
    for s, e, ev in _windows(evs, "handover"):
        zero_windows.append((s, s + ev.interruption_ms / 1e3))
        info.handover_times.append(s)
    block_factor_w = []
    for s, e, ev in _windows(evs, "blockage"):
        if radio_fn is not None and ev.attenuation_db is not None:
            lb_block.append((s, e, ev.attenuation_db))
        else:
            block_factor_w.append((s, e, ev.factor if ev.factor is not None else 0.1))
    if link.availability.mtbf_s is not None:
        out_w += _random_downtime(link.availability.mtbf_s, link.availability.mttr_s, horizon,
                                  stream(seed, "link", link.id, "availability"))
    info.outage_windows = [(s, min(e, horizon)) for s, e in out_w]
    info.blockage_windows = [(s, min(e, horizon), a) for s, e, a in lb_block] + \
                            [(s, min(e, horizon), f) for s, e, f in block_factor_w]
    for s, e, *_ in scale_w + set_w + lb_block + block_factor_w:
        bps.add(s)
        bps.add(e)
    for s, e in zero_windows + out_w:
        bps.add(s)
        bps.add(e)

    t = np.array(sorted(x for x in bps if 0.0 <= x < INF))
    t = t[t <= horizon + 1.0] if t.size else np.array([0.0])

    def active(windows):
        m = np.zeros(t.size, dtype=bool)
        for s, e, *_ in windows:
            m |= (t >= s) & (t < e)
        return m

    extra_db = np.zeros(t.size)
    for s, e, a in lb_block:
        extra_db += np.where((t >= s) & (t < e), a, 0.0)
    radio = radio_fn(t, extra_db) if radio_fn is not None else None
    up = ~active([(s, e) for s, e in out_w])
    zero = active(zero_windows)

    tls = []
    for base in caps:
        c = np.full(t.size, base)
        if markov_times is not None:
            idx = np.searchsorted(markov_times, t, side="right") - 1
            c = c * markov_factors[idx]
        if radio is not None:
            c = np.minimum(c, radio)
        for s, e, ev in scale_w:
            c = np.where((t >= s) & (t < e), c * ev.factor, c)
        for s, e, ev in set_w:
            c = np.where((t >= s) & (t < e), ev.capacity_mbps * 1e6, c)
        for s, e, f in block_factor_w:
            c = np.where((t >= s) & (t < e), c * f, c)
        c = np.where(zero, 0.0, c)
        tls.append(LinkTimeline(t, c, up))
    info.forward, info.reverse = tls
    return info
