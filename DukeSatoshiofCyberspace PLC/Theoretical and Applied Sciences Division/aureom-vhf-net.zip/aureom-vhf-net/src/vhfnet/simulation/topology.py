"""Graph view of the topology and candidate-path enumeration."""

from __future__ import annotations

from dataclasses import dataclass

from ..config import TopologyConfig


@dataclass(frozen=True)
class DirLinkSpec:
    dir_id: str
    link_id: str
    src: str
    dst: str
    capacity_bps: float
    prop_s: float


class Graph:
    def __init__(self, topo: TopologyConfig) -> None:
        self.topo = topo
        self.nodes = {n.id: n for n in topo.nodes}
        self.adj: dict[str, list[DirLinkSpec]] = {n.id: [] for n in topo.nodes}
        self.dirlinks: dict[tuple[str, str], DirLinkSpec] = {}
        for lk in topo.links:
            for src, dst, cap in ((lk.a, lk.b, lk.capacity_mbps),
                                  (lk.b, lk.a, lk.capacity_mbps_reverse or lk.capacity_mbps)):
                spec = DirLinkSpec(f"{lk.id}:{src}>{dst}", lk.id, src, dst, cap * 1e6, lk.propagation_delay_ms / 1e3)
                self.adj[src].append(spec)
                self.dirlinks[(src, dst)] = spec
        self._paths: dict[tuple[str, str, int], list[tuple[str, ...]]] = {}

    def link(self, a: str, b: str) -> DirLinkSpec:
        return self.dirlinks[(a, b)]

    def path_prop_s(self, path: tuple[str, ...]) -> float:
        return sum(self.dirlinks[(path[i], path[i + 1])].prop_s for i in range(len(path) - 1))

    def path_proc_s(self, path: tuple[str, ...]) -> float:
        return sum(self.nodes[n].processing_delay_us for n in path) / 1e6

    def candidate_paths(self, src: str, dst: str, k: int = 4, max_hops: int = 8) -> list[tuple[str, ...]]:
        """Up to k loop-free paths, ordered by (propagation + processing delay, hops, name)."""
        key = (src, dst, k)
        if key in self._paths:
            return self._paths[key]
        if src == dst:
            self._paths[key] = [(src,)]
            return self._paths[key]
        found: list[tuple[str, ...]] = []
        stack = [(src, (src,))]
        while stack:
            node, path = stack.pop()
            if len(path) - 1 >= max_hops:
                continue
            for spec in self.adj[node]:
                if spec.dst in path:
                    continue
                # never transit through clients
                if spec.dst != dst and self.nodes[spec.dst].kind == "client":
                    continue
                p = path + (spec.dst,)
                if spec.dst == dst:
                    found.append(p)
                else:
                    stack.append((spec.dst, p))
        found.sort(key=lambda p: (round(self.path_prop_s(p) + self.path_proc_s(p), 12), len(p), p))
        self._paths[key] = found[:k]
        return self._paths[key]
