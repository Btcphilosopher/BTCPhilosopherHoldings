"""SIMULATION engine: one (scenario, policy, seed) run in virtual time.

Pipeline: generate traffic -> traverse simulated links -> collect measurements.

Resource limits (events, wall-clock, packets) are enforced in the event loop, and
an optional ``threading.Event`` allows cooperative cancellation (used by the API).
"""

from __future__ import annotations

import math
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field

import numpy as np
import simpy

from ..config import ExperimentConfig, FlowConfig, ScenarioEvent
from ..edge.compute import ComputeServer, Job
from ..edge.placement import PlacementEstimate, queue_wait_estimate_s, transfer_time_s
from ..optimisation.rate_control import BoundedAIMD, FixedRate
from ..rng import UniformBuffer, stream
from ..routing.control_plane import ControlPlane
from ..routing.policies import make_router
from ..traffic.generator import build_schedule, message_sizes, offered_rate_bps
from ..traffic.packet import Message, Packet
from ..transport.simulated import SimulatedTransportAdapter
from .conditions import build_link_conditions
from .flowstate import FlowRuntime
from .loss import make_loss
from .network import Network
from .topology import Graph

INF = math.inf


class SimulationLimitExceeded(RuntimeError):
    pass


class SimulationCancelled(RuntimeError):
    pass


@dataclass
class RequestRecord:
    req_id: int
    flow_idx: int
    created_t: float
    deadline_abs: float
    timeout_abs: float
    node: str
    input_bytes: int
    output_bytes: int
    work_gop: float | None
    input_done_t: float = math.nan
    job_start_t: float = math.nan
    job_end_t: float = math.nan
    complete_t: float = math.nan
    rejected: str | None = None
    placement_estimate_s: float | None = None
    in_transit: bool = False

    def status(self) -> str:
        if self.rejected:
            return "rejected"
        if math.isnan(self.complete_t):
            return "timeout" if math.isfinite(self.timeout_abs) else "incomplete"
        if self.complete_t > self.timeout_abs:
            return "timeout"
        if self.complete_t > self.deadline_abs:
            return "late"
        return "ok"


@dataclass
class ServiceState:
    id: str
    host: str
    state_bytes: int
    downtime_s: float
    migrating: bool = False
    pending: list = field(default_factory=list)
    migrations: list = field(default_factory=list)


class PacketLog:
    """Columnar log of every packet arrival at its destination (incl. duplicates)."""

    FIELDS = ("flow", "seq", "msg", "created", "sent", "recv", "payload", "retx", "dup", "reord",
              "t_app", "t_queue", "t_tx", "t_prop", "t_proc", "path")

    def __init__(self) -> None:
        self.cols: dict[str, list] = {f: [] for f in self.FIELDS}
        self.paths: dict[tuple[str, ...], int] = {}

    def add(self, pkt: Packet, now: float, dup: bool, reord: bool) -> None:
        c = self.cols
        pid = self.paths.setdefault(pkt.path, len(self.paths))
        c["flow"].append(pkt.flow_idx)
        c["seq"].append(pkt.seq)
        c["msg"].append(pkt.msg_id)
        c["created"].append(pkt.created_t)
        c["sent"].append(pkt.sent_t)
        c["recv"].append(now)
        c["payload"].append(pkt.payload_bytes)
        c["retx"].append(pkt.is_retx)
        c["dup"].append(dup)
        c["reord"].append(reord)
        c["t_app"].append(pkt.t_app)
        c["t_queue"].append(pkt.t_queue)
        c["t_tx"].append(pkt.t_tx)
        c["t_prop"].append(pkt.t_prop)
        c["t_proc"].append(pkt.t_proc)
        c["path"].append(pid)

    def arrays(self) -> dict[str, np.ndarray]:
        return {k: np.asarray(v) for k, v in self.cols.items()}


class Simulation:
    def __init__(self, cfg: ExperimentConfig, scenario_id: str, policy_id: str, seed: int, *,
                 trace_links: bool = False, cancel: threading.Event | None = None,
                 duration_s: float | None = None) -> None:
        self.cfg = cfg
        self.scenario = cfg.scenario(scenario_id)
        self.policy = cfg.policy(policy_id)
        self.seed = int(seed)
        self.duration = float(duration_s or cfg.duration_s)
        if self.duration > cfg.limits.max_duration_s:
            raise SimulationLimitExceeded("duration exceeds limits.max_duration_s")
        self.horizon = self.duration + cfg.drain_s
        self.cancel = cancel
        self.trace_links = trace_links
        self.env = simpy.Environment()
        self.graph = Graph(cfg.topology)
        self.mtu = cfg.mtu_payload_bytes
        self.hdr = cfg.header_bytes
        self.flows: list[FlowRuntime] = []
        self.senders: list[SimulatedTransportAdapter] = []
        self.requests: list[RequestRecord] = []
        self.jobs: list[Job] = []
        self.resp_flows: dict[tuple[int, str], FlowRuntime] = {}
        self.log = PacketLog()
        self.ts: dict = {"t": [], "links": defaultdict(lambda: defaultdict(list)),
                         "flows": defaultdict(lambda: defaultdict(list)),
                         "compute": defaultdict(lambda: defaultdict(list))}
        self.events_processed = 0
        self.migration_log: list[dict] = []
        self._msg_callbacks: dict[tuple[int, int], object] = {}
        self.in_transit: dict[str, int] = defaultdict(int)  # requests whose input is still on the way
        self.place_current: dict[int, str] = {}
        self._build()

    # ===================================================================== build
    def _build(self) -> None:
        cfg, env, seed = self.cfg, self.env, self.seed
        self.conditions = {}
        timelines = {}
        losses = {}
        for lk in cfg.topology.links:
            cond = build_link_conditions(lk, self.scenario.events, self.horizon, seed,
                                         self.scenario.disable_wireless_variation)
            self.conditions[lk.id] = cond
            fwd = self.graph.link(lk.a, lk.b).dir_id
            rev = self.graph.link(lk.b, lk.a).dir_id
            timelines[fwd], timelines[rev] = cond.forward, cond.reverse
            for d in (fwd, rev):
                losses[d] = make_loss(lk.loss, UniformBuffer(stream(seed, "loss", d)))
        self.network = Network(env, cfg, self.graph, timelines, losses, self.policy.scheduling,
                               trace=self.trace_links)
        self.network.on_deliver = self._on_deliver
        self.network.on_drop_cb = self._on_drop
        self.compute = {n.id: ComputeServer(env, n.id, n.compute) for n in cfg.topology.nodes if n.compute}
        cp = cfg.control_plane
        self.control = ControlPlane(env, self.network, self.compute, cp.report_interval_ms / 1e3,
                                    cp.report_delay_ms / 1e3, cp.capacity_report_noise,
                                    stream(seed, "control-plane"))
        self.router = make_router(self.policy.routing, self.graph, self.control, self.policy.routing_params,
                                  self.mtu + self.hdr)
        self.services = {s.id: ServiceState(s.id, s.host, s.state_bytes, s.migration_downtime_ms / 1e3)
                         for s in cfg.services}
        for f in list(cfg.flows) + list(self.scenario.extra_flows):
            self._add_data_flow(f)
        for ev in self.scenario.events:
            if ev.kind == "compute_load":
                env.process(self._background_load(ev))
            elif ev.kind == "migrate_service":
                env.process(self._migration(ev))
        env.process(self._sampler())

    def _controller(self, f: FlowConfig, max_bps: float | None = None):
        """Factory of per-destination rate controllers for flow ``f``."""
        max_bps = max_bps or f.max_rate_mbps * 1e6
        if self.policy.rate_control == "aimd" and f.rate_adaptive:
            a = self.policy.aimd
            return lambda: BoundedAIMD(min_bps=min(f.min_rate_mbps * 1e6, max_bps), max_bps=max_bps,
                                       rate_bps=max_bps, ai_bps_per_s=a.additive_increase_mbps_per_s * 1e6,
                                       md=a.multiplicative_decrease, loss_threshold=a.loss_threshold,
                                       delay_threshold_s=a.delay_threshold_ms / 1e3)
        return lambda: FixedRate(max_bps)

    def _new_runtime(self, f: FlowConfig, name: str, role: str, parent: int, src: str) -> FlowRuntime:
        fr = FlowRuntime(idx=len(self.flows), name=name, cfg=f, role=role, parent=parent if parent >= 0 else len(self.flows),
                         src=src, deadline_s=(f.deadline_ms / 1e3) if f.deadline_ms else None,
                         priority=f.priority, weight=f.effective_weight,
                         reliable=f.reliability.mode == "reliable", max_retx=f.reliability.max_retx,
                         min_rto_s=f.reliability.min_rto_ms / 1e3)
        self.flows.append(fr)
        return fr

    def _attach_sender(self, fr: FlowRuntime, controller, backlogged: bool = False,
                       buffer_bytes: int | None = None) -> SimulatedTransportAdapter:
        router = self.router
        idx, src = fr.idx, fr.src

        def route_fn(route, now):
            if isinstance(route, tuple):
                return route
            return router.path_for(idx, src, route, now)

        def observe(route, path, owd, lost, now):
            if isinstance(route, str):
                router.observe(idx, route, path, owd, lost, now)

        rp = self.policy.routing_params
        snd = SimulatedTransportAdapter(self.env, fr, self.network, route_fn, self.mtu, self.hdr, controller,
                                        self.policy.aimd.feedback_interval_ms / 1e3, rp.switch_interrupt_ms / 1e3,
                                        observe, buffer_bytes=buffer_bytes, backlogged=backlogged)
        self.senders.append(snd)
        fr.sender = snd
        router.register_flow(idx, fr.name, fr.deadline_s,
                             lambda s=snd, f=fr: min(s.rate_bps, f.offered_rate_bps) if f.offered_rate_bps else s.rate_bps)
        self.env.process(self._feedback(fr, snd))
        return snd

    def _add_data_flow(self, f: FlowConfig) -> None:
        fr = self._new_runtime(f, f.id, "data", -1, f.src)
        rng = stream(self.seed, "flow", f.id)
        sched = build_schedule(f, self.duration, rng)
        fr.gen_start = f.start_s
        fr.gen_end = min(self.duration, f.start_s + f.duration_s) if f.duration_s else self.duration
        fr.offered_rate_bps = offered_rate_bps(f, sched, self.duration)
        snd = self._attach_sender(fr, self._controller(f), backlogged=f.kind == "file_transfer")
        resp_sizes = None
        if f.response_size is not None:
            resp_sizes = message_sizes(f.response_size, len(sched), stream(self.seed, "flow", f.id, "response"))
        self.env.process(self._arrivals(fr, snd, sched, resp_sizes))

    def _response_flow(self, parent: FlowRuntime, node: str) -> FlowRuntime:
        key = (parent.idx, node)
        fr = self.resp_flows.get(key)
        if fr is None:
            fr = self._new_runtime(parent.cfg, f"{parent.name}/resp@{node}", "response", parent.idx, node)
            fr.gen_start, fr.gen_end = parent.gen_start, parent.gen_end
            fr.offered_rate_bps = 0.0
            self._attach_sender(fr, lambda r=parent.cfg.max_rate_mbps * 1e6: FixedRate(r))
            self.resp_flows[key] = fr
        return fr

    # ================================================================= traffic
    def _resolve_dst(self, f: FlowConfig) -> str:
        if f.dst.startswith("service:"):
            return self.services[f.dst.split(":", 1)[1]].host
        return f.dst

    def _new_message(self, fr: FlowRuntime, now: float, size: int, role: str, request_id: int = -1) -> Message:
        dl = now + fr.deadline_s if fr.deadline_s else INF
        msg = Message(fr.idx, len(fr.messages), now, int(size), dl, max(1, math.ceil(size / self.mtu)),
                      role=role, request_id=request_id)
        fr.messages.append(msg)
        return msg

    def _arrivals(self, fr: FlowRuntime, snd: SimulatedTransportAdapter, sched, resp_sizes):
        env = self.env
        f = fr.cfg
        for i in range(len(sched)):
            t = float(sched.times[i])
            if t > env.now:
                yield env.timeout(t - env.now)
            size = int(sched.sizes[i])
            now = env.now
            if f.app_adaptive:
                scale = min(1.0, max(0.25, snd.rate_bps / (f.max_rate_mbps * 1e6)))
                size = max(1, int(round(size * scale)))
                fr.app_scale_sum += scale
                fr.app_scale_n += 1
            if f.kind in ("request_response", "inference"):
                self._new_request(fr, snd, now, size, int(resp_sizes[i]))
            else:
                msg = self._new_message(fr, now, size, "data")
                snd.submit(msg, self._resolve_dst(f))

    def _new_request(self, fr: FlowRuntime, snd, now: float, in_bytes: int, out_bytes: int) -> None:
        f = fr.cfg
        dl = now + fr.deadline_s if fr.deadline_s else INF
        to = now + f.timeout_ms / 1e3 if f.timeout_ms else INF
        if f.kind == "inference":
            node, est = self._place(fr, in_bytes, out_bytes, f.work_gop)
        else:
            node, est = f.dst, None
        rec = RequestRecord(len(self.requests), fr.idx, now, dl, to, node, in_bytes, out_bytes, f.work_gop,
                            placement_estimate_s=est)
        self.requests.append(rec)
        if node == fr.src:  # local execution: no network transfer
            rec.input_done_t = now
            self._submit_job(fr, rec, path_up=None)
            fr.offered_msgs += 1
            fr.offered_bytes += in_bytes
            fr.admitted_msgs += 1
            fr.admitted_bytes += in_bytes
            return
        msg = self._new_message(fr, now, in_bytes, "request", rec.req_id)
        if not snd.submit(msg, node):
            rec.rejected = "send-buffer-full"
        else:
            rec.in_transit = True
            self.in_transit[node] += 1

    def _place(self, fr: FlowRuntime, in_b: int, out_b: int, work: float) -> tuple[str, float | None]:
        pol = self.policy.placement
        nodes = self.graph.nodes
        if pol == "local":
            if fr.src not in self.compute:
                raise ValueError("placement=local but client has no compute")
            return fr.src, None
        edges = [n for n in self.compute if nodes[n].kind == "edge"]
        clouds = [n for n in self.compute if nodes[n].kind == "cloud"]
        if pol == "nearest_edge":
            best = min(edges, key=lambda n: (self.graph.path_prop_s(self.graph.candidate_paths(fr.src, n, 1)[0]), n))
            return best, None
        if pol == "cloud":
            return clouds[0], None
        ests = [self._estimate(fr, n, in_b, out_b, work) for n in sorted(self.compute)]
        if pol == "weighted":
            w = self.policy.placement_weights
            cost = lambda e: e.weighted_cost(w)  # noqa: E731
        else:
            cost = lambda e: e.completion_s  # noqa: E731
        best = min(ests, key=cost)
        cur = self.place_current.get(fr.idx)
        if cur is not None and cur != best.node:  # stickiness: move only for a >10% gain
            cur_est = next(e for e in ests if e.node == cur)
            if not cost(best) < 0.9 * cost(cur_est):
                best = cur_est
        self.place_current[fr.idx] = best.node
        return best.node, best.completion_s

    def _estimate(self, fr: FlowRuntime, node: str, in_b: int, out_b: int, work: float) -> PlacementEstimate:
        server = self.compute[node]
        rep = self.control.view.compute.get(node)
        svc = server.service_time(work)
        queued = (rep.queue_len if rep else 0) + self.in_transit.get(node, 0)
        wait = queue_wait_estimate_s(queued, rep.busy_cores if rep else 0, server.cores, svc)
        if node == fr.src:
            return PlacementEstimate(node, 0.0, wait, svc, 0.0, server.cfg.active_power_w_per_core * svc,
                                     svc * server.cfg.cost_per_core_s)
        st = self.router.state(fr.idx, fr.src, node)
        path = st.paths[st.current]
        up = self._transfer_est(path, in_b, fr)
        down = self._transfer_est(tuple(reversed(path)), out_b, None)
        epb = sum(self._link_epb(path[i], path[i + 1]) for i in range(len(path) - 1))
        energy = (in_b + out_b) * 8 * epb * 1e-9 + server.cfg.active_power_w_per_core * svc
        return PlacementEstimate(node, up, wait, svc, down, energy, svc * server.cfg.cost_per_core_s)

    def _link_epb(self, a: str, b: str) -> float:
        lid = self.graph.link(a, b).link_id
        return next(lk.energy.energy_per_bit_nj for lk in self.cfg.topology.links if lk.id == lid)

    def _transfer_est(self, path: tuple[str, ...], size: int, fr: FlowRuntime | None) -> float:
        """Message transfer estimate: path delay + bits / min(bottleneck residual, sender pacing rate)."""
        d = self.router.est_delay(path)
        if math.isinf(d):
            return INF
        view = self.control.view.links
        own = self.router.own_load()
        cur = set()
        if fr is not None and fr.idx in self.router.active_dst:
            st = self.router.states.get((fr.idx, self.router.active_dst[fr.idx]))
            if st is not None:
                p = st.paths[st.current]
                cur = {self.graph.link(p[i], p[i + 1]).dir_id for i in range(len(p) - 1)}
        bott = fr.sender.rate_bps if fr is not None else INF
        for i in range(len(path) - 1):
            lid = self.graph.link(path[i], path[i + 1]).dir_id
            r = view[lid]
            res = self.router.residual_bps(fr.idx, lid, lid in cur, own) if fr is not None else \
                max(0.0, r.capacity_bps - r.rate_bps)
            bott = min(bott, max(res, 0.1 * r.capacity_bps))
        return transfer_time_s(size, d, bott, self.mtu, self.hdr)

    # ================================================================ receive
    def _on_drop(self, link, pkt: Packet, cause: str) -> None:
        self.flows[pkt.flow_idx].drops[cause] += 1

    def _on_deliver(self, pkt: Packet) -> None:
        fr = self.flows[pkt.flow_idx]
        now = self.env.now
        fr.rx_packets += 1
        fr.rx_wire_bytes += pkt.payload_bytes + pkt.header_bytes
        fr.pending_acks.append((pkt.seq, pkt.sent_t, now, pkt.path))
        fr.last_path = pkt.path
        if pkt.seq in fr.seen:
            fr.dup_packets += 1
            self.log.add(pkt, now, True, False)
            return
        fr.seen.add(pkt.seq)
        reord = pkt.seq < fr.max_seq
        if reord:
            fr.reordered_packets += 1
        else:
            fr.max_seq = pkt.seq
        fr.unique_payload_bytes += pkt.payload_bytes
        fr.sample_payload += pkt.payload_bytes
        self.log.add(pkt, now, False, reord)
        msg = fr.messages[pkt.msg_id]
        msg.received += 1
        if msg.received == msg.n_frags:
            self._message_arrived(fr, msg, pkt.path, now)

    def _message_arrived(self, fr: FlowRuntime, msg: Message, path, now: float) -> None:
        f = fr.cfg
        if fr.role == "data" and f.dst.startswith("service:"):
            svc = self.services[f.dst.split(":", 1)[1]]
            if svc.migrating:
                svc.pending.append((fr, msg, path))
                return
        msg.complete_t = now
        self._message_complete(fr, msg, path)

    def _message_complete(self, fr: FlowRuntime, msg: Message, path) -> None:
        if msg.role == "request":
            rec = self.requests[msg.request_id]
            rec.input_done_t = msg.complete_t
            if rec.in_transit:
                rec.in_transit = False
                self.in_transit[rec.node] -= 1
            if fr.cfg.kind == "inference":
                self._submit_job(fr, rec, path)
            else:
                st = fr.cfg.server_time_ms / 1e3
                rec.job_start_t = msg.complete_t
                rec.job_end_t = msg.complete_t + st
                if st > 0:
                    ev = self.env.timeout(st)
                    ev.callbacks.append(lambda e, r=rec, p=path: self._send_response(r, p))
                else:
                    self._send_response(rec, path)
        elif msg.role == "response":
            self.requests[msg.request_id].complete_t = msg.complete_t
        elif msg.role == "migration":
            cb = self._msg_callbacks.pop((fr.idx, msg.msg_id), None)
            if cb:
                cb()

    def _submit_job(self, fr: FlowRuntime, rec: RequestRecord, path_up) -> None:
        server = self.compute[rec.node]
        job = Job(len(self.jobs), rec.node, rec.work_gop, self.env.now, flow_idx=fr.idx, request_id=rec.req_id)
        self.jobs.append(job)

        def done(j: Job, rec=rec, path_up=path_up):
            rec.job_start_t, rec.job_end_t = j.start_t, j.end_t
            if path_up is None:  # local
                rec.complete_t = j.end_t
            else:
                self._send_response(rec, path_up)

        job.on_done = done
        if not server.submit(job):
            rec.rejected = "compute-queue-full"

    def _send_response(self, rec: RequestRecord, path_up) -> None:
        parent = self.flows[rec.flow_idx]
        rf = self._response_flow(parent, rec.node)
        now = self.env.now
        msg = Message(rf.idx, len(rf.messages), now, rec.output_bytes, rec.deadline_abs,
                      max(1, math.ceil(rec.output_bytes / self.mtu)), role="response", request_id=rec.req_id)
        msg.created_t = now
        rf.messages.append(msg)
        if not rf.sender.submit(msg, tuple(reversed(path_up))):
            rec.rejected = "response-buffer-full"

    def _feedback(self, fr: FlowRuntime, snd: SimulatedTransportAdapter):
        """Receiver -> sender ack reports every feedback interval. Feedback travels the
        reverse path with propagation + processing delay only (ASSUMPTION: the
        reverse path is lightly loaded; reverse queueing is not modelled)."""
        env = self.env
        iv = self.policy.aimd.feedback_interval_ms / 1e3
        cache: dict = {}
        while True:
            yield env.timeout(iv)
            if not fr.pending_acks:
                continue
            rep = fr.pending_acks
            fr.pending_acks = []
            path = rep[-1][3]
            d = cache.get(path)
            if d is None:
                rp = tuple(reversed(path))
                d = cache[path] = self.graph.path_prop_s(rp) + self.graph.path_proc_s(rp)
            ev = env.timeout(d, (rep, env.now))
            ev.callbacks.append(lambda e, s=snd: s.on_report(e.value[0], e.value[1]))

    # ============================================================ scenarios
    def _background_load(self, ev: ScenarioEvent):
        env = self.env
        server = self.compute.get(ev.target)
        if server is None:
            return
        rng = stream(self.seed, "bgload", ev.target, f"{ev.at_s:.6f}")
        end = min(self.duration, ev.at_s + ev.duration_s) if ev.duration_s else self.duration
        t = ev.at_s
        while True:
            t += rng.exponential(1.0 / ev.rate_jobs_per_s)
            if t >= end:
                return
            yield env.timeout(t - env.now)
            job = Job(len(self.jobs), ev.target, ev.work_gop, env.now, background=True)
            server.submit(job)

    def _migration(self, ev: ScenarioEvent):
        env = self.env
        yield env.timeout(ev.at_s)
        svc = self.services[ev.target]
        if svc.host == ev.to:
            return
        rec = {"service": svc.id, "from": svc.host, "to": ev.to, "start_t": env.now, "state_bytes": svc.state_bytes,
               "transfer_done_t": None, "end_t": None}
        self.migration_log.append(rec)
        svc.migrating = True
        path = self.graph.candidate_paths(svc.host, ev.to, 1)[0]
        bott = min(self.graph.link(path[i], path[i + 1]).capacity_bps for i in range(len(path) - 1))
        f = FlowConfig(id=f"migration:{svc.id}", kind="file_transfer", src=svc.host, dst=ev.to,
                       arrival={"model": "backlogged"}, file_bytes=max(1, svc.state_bytes), priority=2,
                       max_rate_mbps=0.5 * bott / 1e6, reliability={"mode": "reliable", "max_retx": 8})
        fr = self._new_runtime(f, f.id, "migration", -1, svc.host)
        fr.gen_start, fr.gen_end = env.now, env.now
        snd = self._attach_sender(fr, lambda: FixedRate(0.5 * bott), backlogged=True)
        msg = self._new_message(fr, env.now, max(1, svc.state_bytes), "migration")
        done = env.event()
        self._msg_callbacks[(fr.idx, msg.msg_id)] = lambda: done.succeed() if not done.triggered else None
        snd.submit(msg, path)
        yield done
        rec["transfer_done_t"] = env.now
        yield env.timeout(svc.downtime_s)
        svc.host = ev.to
        svc.migrating = False
        rec["end_t"] = env.now
        now = env.now
        for fr2, m, p in svc.pending:
            m.complete_t = now
            self._message_complete(fr2, m, p)
        svc.pending.clear()

    # ============================================================== sampling
    def _sampler(self):
        env = self.env
        dt = self.cfg.sample_interval_ms / 1e3
        ts = self.ts
        last = 0.0
        while True:
            yield env.timeout(dt)
            now = env.now
            ts["t"].append(now)
            for lid, link in self.network.by_id.items():
                cap_bits = link.timeline.integral(last, now)
                s = ts["links"][lid]
                s["queue_bytes"].append(link.queue.bytes)
                s["capacity_bps"].append(link.timeline.capacity_at(now))
                s["up"].append(link.timeline.is_up(now))
                s["utilisation"].append(link.sample_bits / cap_bits if cap_bits > 0 else None)
                s["throughput_bps"].append(link.sample_bits / dt)
                link.sample_bits = 0.0
            resp_acc: dict[int, int] = defaultdict(int)
            for fr in self.flows:
                if fr.role == "response":
                    resp_acc[fr.parent] += fr.sample_payload
            for fr in self.flows:
                if fr.role == "data":
                    s = ts["flows"][fr.name]
                    s["goodput_bps"].append(fr.sample_payload * 8 / dt)
                    s["response_goodput_bps"].append(resp_acc[fr.idx] * 8 / dt)
                    s["rate_bps"].append(fr.sender.rate_bps)
                fr.sample_payload = 0
            for nid, srv in self.compute.items():
                c = ts["compute"][nid]
                c["queue_jobs"].append(len(srv.queue))
                c["busy_cores"].append(srv.busy)
            last = now

    # =================================================================== run
    def run(self) -> dict:
        from .results import summarise  # local import keeps module graph acyclic

        env = self.env
        lim = self.cfg.limits
        t_wall0 = time.perf_counter()
        t_cpu0 = time.process_time()
        end = self.horizon
        peek, step = env.peek, env.step
        n = 0
        if self.cancel is not None and self.cancel.is_set():
            raise SimulationCancelled("cancelled before start")
        while peek() <= end:
            step()
            n += 1
            if not (n & 0x3FF):
                if n > lim.max_events:
                    raise SimulationLimitExceeded(f"max_events {lim.max_events} exceeded")
                if time.perf_counter() - t_wall0 > lim.max_wall_s:
                    raise SimulationLimitExceeded(f"max_wall_s {lim.max_wall_s} exceeded")
                if self.network.injected > lim.max_packets:
                    raise SimulationLimitExceeded(f"max_packets {lim.max_packets} exceeded")
                if self.cancel is not None and self.cancel.is_set():
                    raise SimulationCancelled("cancelled")
        self.events_processed = n
        wall = time.perf_counter() - t_wall0
        cpu = time.process_time() - t_cpu0
        return summarise(self, wall_s=wall, cpu_s=cpu)


def run_simulation(cfg: ExperimentConfig, scenario: str, policy: str, seed: int, **kw) -> dict:
    return Simulation(cfg, scenario, policy, seed, **kw).run()
