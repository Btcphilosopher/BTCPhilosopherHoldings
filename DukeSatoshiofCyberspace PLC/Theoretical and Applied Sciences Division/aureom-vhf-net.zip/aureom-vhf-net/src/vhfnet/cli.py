"""Command-line interface: ``vhfnet <command>`` (or ``python -m vhfnet``)."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import PRODUCT, __version__

DEFAULT_CONFIG = "configs/experiments/demo.yaml"


def _csv_list(s: str | None, cast=str):
    return [cast(x) for x in s.split(",")] if s else None


def cmd_simulate(a) -> int:
    from .config import load_experiment
    from .simulation.engine import Simulation
    from .telemetry.export import write_json

    cfg = load_experiment(a.config)
    res = Simulation(cfg, a.scenario, a.policy, a.seed, duration_s=a.duration, trace_links=a.trace).run()
    out = Path(a.out or f"results/single/{a.scenario}-{a.policy}-seed{a.seed}.json")
    write_json(out, res)
    t = res["totals"]
    print(f"SIMULATION  {a.scenario} / {a.policy} / seed {a.seed}")
    print(f"  offered {t['offered_bps']/1e6:.2f} Mb/s · goodput {t['goodput_bps']/1e6:.2f} Mb/s · useful "
          f"{t['useful_goodput_bps']/1e6:.2f} Mb/s · deadline misses {t['deadline_miss_ratio']:.4f} · route changes "
          f"{t['route_changes']}")
    print(f"  integrity: capacity conserved={res['integrity']['capacity_conserved']} delay identity err="
          f"{res['integrity']['delay_identity_max_abs_error_s']:.1e}s · fingerprint {res['fingerprint'][:16]}")
    print(f"  wrote {out}")
    return 0


def cmd_experiment(a) -> int:
    from .config import load_experiment
    from .experiments.runner import run_experiment

    cfg = load_experiment(a.config)
    m = run_experiment(cfg, a.out, scenarios=_csv_list(a.scenarios), policies=_csv_list(a.policies),
                       seeds=_csv_list(a.seeds, int), workers=a.workers, reference=a.reference, detail=a.detail)
    print("\nFindings (from paired verdicts only):")
    for s in m["statements"]:
        print("  -", s)
    print(f"\nWrote {a.out}/ (runs.csv, flows.csv, links.csv, aggregate.csv, comparison.csv/json, manifest.json)")
    if a.report:
        from .dashboard.report import build_report

        p = build_report(Path(a.out).parent, Path(a.out).parent / "report", a.config)
        print(f"Static dashboard: {p}")
    return 0


def cmd_serve(a) -> int:
    import uvicorn

    from .api.app import create_app

    if a.host not in ("127.0.0.1", "localhost", "::1") and not a.allow_remote:
        print("Refusing to bind the console to a non-loopback address without --allow-remote.", file=sys.stderr)
        return 2
    app = create_app(a.results, a.config, a.live_configs, enable_live=not a.no_live)
    print(f"{PRODUCT} console on http://{a.host}:{a.port}/  (results: {a.results})")
    uvicorn.run(app, host=a.host, port=a.port, log_level="warning")
    return 0


def cmd_report(a) -> int:
    from .dashboard.report import build_report

    p = build_report(a.results, a.out, a.config, a.live_configs)
    print(f"Static dashboard written to {p} (open it in a browser; no server needed)")
    return 0


def cmd_live_run(a) -> int:
    import time

    from .config import load_live
    from .telemetry.export import write_json
    from .transport.live import run_live

    cfg = load_live(a.config)
    res = run_live(cfg, spawn_local_server=not a.no_spawn, seed=a.seed)
    rid = time.strftime("%Y%m%dT%H%M%S") + f"-{cfg.transport}"
    out = Path(a.out) / f"{rid}.json"
    write_json(out, res)
    print(f"LIVE TEST  {cfg.name} over {cfg.transport.upper()} to {res['meta']['endpoint']['ip']}:"
          f"{res['meta']['endpoint']['port']}  ({res['meta']['clock']['basis']})")
    for f in res["flows"]:
        line = (f"  {f['id']:<14s} target {f['target_wire_rate_mbps']:7.1f} Mb/s  sent {f['achieved_send_wire_rate_mbps_est']:7.1f}"
                f"  goodput {f.get('goodput_mbps') or 0:7.1f}  gen-limited={f['generator_limited']}")
        if f.get("rtt_ms") and f["rtt_ms"].get("count"):
            line += f"  RTT p50/p99 {f['rtt_ms']['p50']:.3f}/{f['rtt_ms']['p99']:.3f} ms"
            r = f["requests"]
            line += f"  ok {r['ok']} late {r['late']} timeouts {r['timeouts']} errors {r['errors']}"
        if f.get("owd_ms"):
            line += f"  OWD p50/p99 {f['owd_ms']['p50']:.3f}/{f['owd_ms']['p99']:.3f} ms"
        if f.get("loss_ratio") is not None:
            line += f"  loss {f['loss_ratio']:.4%}"
        print(line)
    for w in res["meta"]["warnings"]:
        print("  warning:", w)
    print(f"  wrote {out}")
    return 0


def cmd_live_serve(a) -> int:
    import asyncio

    from .transport.live import start_server

    if a.host not in ("127.0.0.1", "localhost", "::1") and not a.allow_nonlocal_bind:
        print("Refusing to bind a test server to a non-loopback address without --allow-nonlocal-bind.",
              file=sys.stderr)
        return 2
    tls = None
    if a.transport == "quic" or a.tls:
        from .transport.tlsutil import self_signed_localhost
        tls = (a.cert, a.key) if a.cert else self_signed_localhost()
        print(f"TLS certificate: {tls[0]}")

    async def main():
        srv = await start_server(a.transport, a.host, a.port, tls)
        print(f"{a.transport.upper()} VHF test server on {a.host}:{srv.port} for at most {a.lifetime:.0f} s")
        try:
            await asyncio.sleep(a.lifetime)
        finally:
            await srv.close()

    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
    return 0


def cmd_bench(a) -> int:
    from .experiments.bench import run_benchmarks

    r = run_benchmarks(a.config, a.out, quick=a.quick, live=not a.no_live)
    print(json.dumps({"codec": {k: {kk: round(vv) for kk, vv in v.items() if isinstance(vv, float)}
                                for k, v in r["codec"].items()},
                      "simulator_reproducible": r["simulator"]["reproducible_same_seed"]}, indent=1))
    for row in r.get("live_loopback", []):
        print(f"  {row['flow']:<18s} target {row['target_wire_mbps']:7.1f}  sent {row['sent_wire_mbps_est']:7.1f}  "
              f"goodput {row['goodput_mbps'] or 0:7.1f}  gen-limited={row['generator_limited']}")
    print(f"Wrote {a.out}/benchmarks.json")
    return 0


def cmd_montecarlo(a) -> int:
    from fastapi.testclient import TestClient

    from .api.app import create_app

    cl = TestClient(create_app(a.results, a.config))
    r = cl.post("/api/montecarlo", json={"draws": a.draws, "seed": a.seed, "deadline_ms": a.deadline_ms,
                                          "message_bytes": a.message_bytes}).json()
    print(json.dumps({k: r[k] for k in ("mode", "draws", "seed", "mean", "mcse_mean", "quantiles", "mcse_quantiles",
                                        "exceedance", "nonfinite_fraction")}, indent=1))
    print("sensitivity:", [(s["input"], round(s["spearman_rho"], 3)) for s in r["sensitivity"]])
    print("assumptions:", *r["assumptions"], sep="\n  - ")
    return 0


def cmd_linkbudget(a) -> int:
    from .config import load_experiment
    from .simulation.wireless import ASSUMPTIONS, link_budget

    cfg = load_experiment(a.config)
    lk = next((x for x in cfg.topology.links if x.id == a.link), None)
    if lk is None or lk.wireless is None or lk.wireless.link_budget is None:
        print(f"link {a.link} has no link_budget model", file=sys.stderr)
        return 2
    lb = lk.wireless.link_budget
    inr = lk.wireless.interference.inr_db if lk.wireless.interference else None
    print(f"Link budget for {a.link}: carrier {lb.carrier_freq_ghz} GHz, channel bandwidth {lb.channel_bw_mhz} MHz, "
          f"slice share {lb.slice_share} (carrier frequency and bandwidth in Hz are NOT throughput)")
    print(f"{'distance m':>10} {'extra dB':>8} {'SINR dB':>8} {'SE b/s/Hz':>9} {'cell Gb/s':>10} {'link Mb/s':>10}")
    for d in (5, 10, 20, 40, 80, 160, 320):
        for extra in (0, 25):
            r = link_budget(lb, d, extra, inr)
            print(f"{d:>10} {extra:>8} {r.sinr_db:>8.1f} {r.spectral_efficiency_bps_hz:>9.2f} "
                  f"{r.cell_capacity_bps/1e9:>10.3f} {r.link_capacity_bps/1e6:>10.1f}")
    print("Assumptions:", *ASSUMPTIONS, sep="\n  - ")
    return 0


def cmd_validate(a) -> int:
    from .config import load_experiment, load_live

    for p in a.configs:
        try:
            import yaml

            data = yaml.safe_load(Path(p).read_text()) or {}
            if "live" in data or data.get("mode") == "live":
                c = load_live(p)
                print(f"OK  {p}: LIVE TEST config '{c.name}' ({c.transport}, {len(c.flows)} flows)")
            else:
                c = load_experiment(p)
                print(f"OK  {p}: SIMULATION config '{c.name}' ({len(c.flows)} flows, {len(c.scenarios)} scenarios, "
                      f"{len(c.policies)} policies)")
        except Exception as e:
            print(f"ERR {p}: {e}")
            return 1
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="vhfnet", description=f"{PRODUCT} {__version__} - inspectable internet-performance lab")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("simulate", help="one SIMULATION run (scenario, policy, seed)")
    s.add_argument("--config", default=DEFAULT_CONFIG)
    s.add_argument("--scenario", default="baseline")
    s.add_argument("--policy", default="adaptive")
    s.add_argument("--seed", type=int, default=1)
    s.add_argument("--duration", type=float)
    s.add_argument("--trace", action="store_true", help="record per-link transmission intervals")
    s.add_argument("--out")
    s.set_defaults(fn=cmd_simulate)

    for name, hlp in (("demo", "the 7-scenario demonstration (all policies, repeated seeds)"),
                      ("experiment", "any scenario x policy x seed grid")):
        e = sub.add_parser(name, help=hlp)
        e.add_argument("--config", default=DEFAULT_CONFIG)
        e.add_argument("--out", default="results/demo")
        e.add_argument("--scenarios")
        e.add_argument("--policies")
        e.add_argument("--seeds", help="comma-separated, e.g. 1,2,3,4,5")
        e.add_argument("--workers", type=int)
        e.add_argument("--reference", help="reference policy for paired comparison (default: first)")
        e.add_argument("--detail", choices=["first", "all", "none"], default="first")
        e.add_argument("--report", action="store_true", help="also build the static dashboard")
        e.set_defaults(fn=cmd_experiment)

    v = sub.add_parser("serve", help="FastAPI control API + dashboard")
    v.add_argument("--results", default="results")
    v.add_argument("--config", default=DEFAULT_CONFIG)
    v.add_argument("--live-configs", default="configs/live")
    v.add_argument("--host", default="127.0.0.1")
    v.add_argument("--port", type=int, default=8765)
    v.add_argument("--no-live", action="store_true")
    v.add_argument("--allow-remote", action="store_true")
    v.set_defaults(fn=cmd_serve)

    r = sub.add_parser("report", help="static self-contained dashboard snapshot")
    r.add_argument("--results", default="results")
    r.add_argument("--out", default="results/report")
    r.add_argument("--config", default=DEFAULT_CONFIG)
    r.add_argument("--live-configs", default="configs/live")
    r.set_defaults(fn=cmd_report)

    lv = sub.add_parser("live", help="LIVE TEST mode (bounded, explicit endpoints)")
    lsub = lv.add_subparsers(dest="live_cmd", required=True)
    lr = lsub.add_parser("run", help="run a live test from a config file")
    lr.add_argument("config")
    lr.add_argument("--no-spawn", action="store_true", help="do not start a local loopback server")
    lr.add_argument("--out", default="results/live")
    lr.add_argument("--seed", type=int, default=0)
    lr.set_defaults(fn=cmd_live_run)
    ls = lsub.add_parser("serve", help="run a bounded VHF test server")
    ls.add_argument("--transport", choices=["tcp", "udp", "quic"], default="udp")
    ls.add_argument("--host", default="127.0.0.1")
    ls.add_argument("--port", type=int, default=9400)
    ls.add_argument("--lifetime", type=float, default=300.0)
    ls.add_argument("--tls", action="store_true", help="TCP: enable TLS (self-signed unless --cert/--key)")
    ls.add_argument("--cert")
    ls.add_argument("--key")
    ls.add_argument("--allow-nonlocal-bind", action="store_true")
    ls.set_defaults(fn=cmd_live_serve)

    b = sub.add_parser("bench", help="reproducible benchmarks (simulator, codec, loopback transports)")
    b.add_argument("--config", default=DEFAULT_CONFIG)
    b.add_argument("--out", default="results/bench")
    b.add_argument("--quick", action="store_true")
    b.add_argument("--no-live", action="store_true")
    b.set_defaults(fn=cmd_bench)

    m = sub.add_parser("montecarlo", help="Monte Carlo latency study over uncertain link conditions")
    m.add_argument("--draws", type=int, default=20000)
    m.add_argument("--seed", type=int, default=7)
    m.add_argument("--deadline-ms", type=float, default=100)
    m.add_argument("--message-bytes", type=float, default=60000)
    m.add_argument("--results", default="results")
    m.add_argument("--config", default=DEFAULT_CONFIG)
    m.set_defaults(fn=cmd_montecarlo)

    lb = sub.add_parser("linkbudget", help="tabulate the simplified link budget of a radio link")
    lb.add_argument("--config", default=DEFAULT_CONFIG)
    lb.add_argument("--link", default="acc-a")
    lb.set_defaults(fn=cmd_linkbudget)

    va = sub.add_parser("validate", help="validate config files")
    va.add_argument("configs", nargs="+")
    va.set_defaults(fn=cmd_validate)

    a = p.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
