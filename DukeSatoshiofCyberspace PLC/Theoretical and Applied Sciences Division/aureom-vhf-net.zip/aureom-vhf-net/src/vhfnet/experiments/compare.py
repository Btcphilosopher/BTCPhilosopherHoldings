"""Paired, seed-matched policy comparison.

Every policy is run on the same seeds; because traffic and channel realisations
come from component-named random streams, run (scenario, seed) offers the same
workload and conditions to every policy (common random numbers). Differences
are therefore analysed *paired by seed*.

Verdict rule (deliberately conservative):
  better/worse  : the 95% paired-bootstrap CI of the mean difference excludes 0
                  AND at least 75% of seeds individually move in that direction
  no-difference : all paired differences are exactly 0
  inconclusive  : otherwise
With few seeds the bootstrap CI is approximate; the Wilcoxon signed-rank p-value
is reported alongside for reference (with n=5 its minimum two-sided p is 0.0625).
"""

from __future__ import annotations

import math
from collections import defaultdict

import numpy as np
from scipy import stats

from ..rng import stable_hash

# metric key -> (label, direction: +1 higher is better, -1 lower is better, unit)
HEADLINE_METRICS = {
    "deadline_miss_ratio": ("Deadline-miss ratio (all deadline traffic)", -1, "ratio"),
    "useful_goodput_mbps": ("Useful goodput (on-time payload)", +1, "Mbit/s"),
    "goodput_mbps": ("Goodput (unique payload)", +1, "Mbit/s"),
    "media_p99_ms": ("Media frame latency p99", -1, "ms"),
    "inference_on_time_ratio": ("Inference requests on time", +1, "ratio"),
    "api_on_time_ratio": ("API requests on time", +1, "ratio"),
    "twin_aoi_ms": ("Digital-twin age of information", -1, "ms"),
    "bulk_progress": ("Bulk transfer progress by end", +1, "fraction"),
    "jain_delivery_ratio": ("Jain fairness (delivery ratio)", +1, "index"),
    "min_delivery_ratio": ("Worst flow delivery ratio", +1, "ratio"),
    "starved_flows": ("Starved flows", -1, "count"),
    "route_changes": ("Route changes", -1, "count"),
    "energy_estimated_j": ("Estimated energy (assumption-based)", -1, "J"),
}


def headline(result: dict) -> dict:
    """Compact per-run metrics used for comparison and the runs table."""
    T = result["totals"]
    flows = {f["id"]: f for f in result["flows"]}
    req = result.get("requests", {})
    h = {
        "deadline_miss_ratio": T["deadline_miss_ratio"],
        "useful_goodput_mbps": T["useful_goodput_bps"] / 1e6,
        "goodput_mbps": T["goodput_bps"] / 1e6,
        "offered_mbps": T["offered_bps"] / 1e6,
        "transmitted_wire_mbps": T["transmitted_wire_bps"] / 1e6,
        "delivered_wire_mbps": T["delivered_wire_bps"] / 1e6,
        "retransmission_ratio": T["retransmission_ratio"],
        "jain_delivery_ratio": result["fairness"]["jain_delivery_ratio"],
        "min_delivery_ratio": result["fairness"]["min_delivery_ratio"],
        "starved_flows": T["starved_flows"],
        "route_changes": T["route_changes"],
        "request_failures": T["request_failures"],
        "energy_estimated_j": T["energy_estimated_j"]["total"],
    }
    if "media" in flows:
        h["media_p99_ms"] = flows["media"]["messages"]["latency_ms"]["p99"]
        h["media_miss_ratio"] = flows["media"]["deadline_miss_ratio"]
    if "inference" in req:
        h["inference_on_time_ratio"] = req["inference"]["on_time_ratio"]
        h["inference_p99_ms"] = req["inference"]["completion_ms"]["p99"]
    if "api" in req:
        h["api_on_time_ratio"] = req["api"]["on_time_ratio"]
        h["api_p99_ms"] = req["api"]["completion_ms"]["p99"]
    if "twin" in flows:
        h["twin_aoi_ms"] = flows["twin"]["age_of_information_ms"]
        h["twin_miss_ratio"] = flows["twin"]["deadline_miss_ratio"]
    if "telemetry" in flows:
        h["telemetry_miss_ratio"] = flows["telemetry"]["deadline_miss_ratio"]
    if "bulk" in flows:
        h["bulk_progress"] = flows["bulk"]["file_progress"]
        h["bulk_fct_s"] = flows["bulk"]["flow_completion_time_s"]
    for prio, c in result.get("classes", {}).items():
        h[f"class{prio}_miss_ratio"] = c["deadline_miss_ratio"]
        h[f"class{prio}_goodput_mbps"] = c["goodput_bps"] / 1e6
        h[f"class{prio}_p99_ms"] = c["latency_p99_ms"]
    return h


def class_metric_direction(key: str) -> int | None:
    if key.startswith("class"):
        if key.endswith("_miss_ratio") or key.endswith("_p99_ms"):
            return -1
        if key.endswith("_goodput_mbps"):
            return +1
    return None


def paired_test(ref: list[float], alt: list[float], direction: int, n_boot: int = 10000, seed: int = 0) -> dict:
    pairs = [(r, a) for r, a in zip(ref, alt)
             if r is not None and a is not None and math.isfinite(r) and math.isfinite(a)]
    n = len(pairs)
    if n == 0:
        return {"n": 0, "verdict": "insufficient-data"}
    d = np.array([a - r for r, a in pairs])
    ref_mean = float(np.mean([r for r, _ in pairs]))
    alt_mean = float(np.mean([a for _, a in pairs]))
    out = {"n": n, "ref_mean": ref_mean, "alt_mean": alt_mean, "diff_mean": float(d.mean()),
           "rel_change": (float(d.mean()) / abs(ref_mean)) if ref_mean else None}
    if np.all(d == 0):
        out.update(ci95=[0.0, 0.0], wilcoxon_p=1.0, frac_improved=0.0, verdict="no-difference")
        return out
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, n, size=(n_boot, n))
    boots = d[idx].mean(axis=1)
    lo, hi = float(np.quantile(boots, 0.025)), float(np.quantile(boots, 0.975))
    try:
        p = float(stats.wilcoxon(d, zero_method="zsplit").pvalue) if n >= 2 else None
    except ValueError:
        p = None
    improved = np.mean(direction * d > 0)
    worsened = np.mean(direction * d < 0)
    # CI of the improvement direction*d: [min(dir*lo, dir*hi), max(...)]
    imp_lo, imp_hi = sorted((direction * lo, direction * hi))
    if imp_lo > 0 and improved >= 0.75:
        verdict = "better"
    elif imp_hi < 0 and worsened >= 0.75:
        verdict = "worse"
    else:
        verdict = "inconclusive"
    out.update(ci95=[lo, hi], wilcoxon_p=p, frac_improved=float(improved), frac_worsened=float(worsened),
               verdict=verdict)
    return out


def compare_policies(runs: list[dict], reference: str) -> dict:
    """``runs``: list of {scenario, policy, seed, headline}. Returns per-scenario comparisons."""
    by = defaultdict(dict)
    for r in runs:
        by[(r["scenario"], r["policy"])][r["seed"]] = r["headline"]
    scenarios = sorted({r["scenario"] for r in runs}, key=lambda s: [x["scenario"] for x in runs].index(s))
    policies = []
    for r in runs:
        if r["policy"] not in policies:
            policies.append(r["policy"])
    out = {"reference": reference, "scenarios": {}, "scoreboard": {}, "degradations": [],
           "rule": __doc__.split("Verdict rule")[1].split("With few seeds")[0].strip()}
    score = defaultdict(lambda: defaultdict(int))
    for sc in scenarios:
        ref_runs = by.get((sc, reference), {})
        out["scenarios"][sc] = {}
        for pol in policies:
            if pol == reference:
                continue
            alt_runs = by.get((sc, pol), {})
            seeds = sorted(set(ref_runs) & set(alt_runs))
            res = {}
            keys = list(HEADLINE_METRICS) + sorted({k for s in seeds for k in alt_runs[s] if k.startswith("class")})
            for key in keys:
                direction = HEADLINE_METRICS[key][1] if key in HEADLINE_METRICS else class_metric_direction(key)
                if direction is None:
                    continue
                t = paired_test([ref_runs[s].get(key) for s in seeds], [alt_runs[s].get(key) for s in seeds],
                                direction, seed=stable_hash(f"{sc}|{pol}|{key}") & 0xFFFFFFFF)
                t["direction"] = "higher-is-better" if direction > 0 else "lower-is-better"
                res[key] = t
                if key in HEADLINE_METRICS and key != "route_changes":
                    score[pol][t["verdict"]] += 1
                if key.startswith("class") and t["verdict"] == "worse":
                    out["degradations"].append({"scenario": sc, "policy": pol, "metric": key,
                                                "ref_mean": t["ref_mean"], "alt_mean": t["alt_mean"],
                                                "ci95": t.get("ci95")})
            out["scenarios"][sc][pol] = res
    out["scoreboard"] = {p: dict(v) for p, v in score.items()}
    out["statements"] = statements(out)
    return out


def statements(cmp: dict) -> list[str]:
    """Plain-language findings generated strictly from the verdicts (no editorialising)."""
    lines = []
    ref = cmp["reference"]
    for pol, sc in cmp["scoreboard"].items():
        b, w, i = sc.get("better", 0), sc.get("worse", 0), sc.get("inconclusive", 0)
        nd = sc.get("no-difference", 0)
        lines.append(f"{pol} vs {ref}: better on {b}, worse on {w}, inconclusive on {i}, identical on {nd} "
                     f"scenario-metric pairs (headline metrics, excluding route-change counts).")
    for scen, pols in cmp["scenarios"].items():
        for pol, res in pols.items():
            for key in ("deadline_miss_ratio", "media_p99_ms", "inference_on_time_ratio"):
                t = res.get(key)
                if t and t.get("verdict") in ("better", "worse"):
                    lines.append(f"[{scen}] {pol}: {HEADLINE_METRICS[key][0]} {t['verdict']} than {ref} "
                                 f"({t['ref_mean']:.4g} -> {t['alt_mean']:.4g}, paired diff 95% CI "
                                 f"[{t['ci95'][0]:.3g}, {t['ci95'][1]:.3g}], n={t['n']}).")
    for d in cmp["degradations"]:
        lines.append(f"DEGRADATION [{d['scenario']}] {d['policy']}: {d['metric']} worse "
                     f"({d['ref_mean']:.4g} -> {d['alt_mean']:.4g}).")
    return lines
