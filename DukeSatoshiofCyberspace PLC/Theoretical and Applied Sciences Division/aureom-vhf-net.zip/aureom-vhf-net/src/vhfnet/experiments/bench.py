"""Reproducible benchmarks.

Every number is labelled with what it measures:
* SIMULATOR (software cost of the discrete-event engine on this host),
* CODEC (pure-Python VHF header pack/unpack rate on this host),
* LIVE TEST loopback (Python asyncio + OS stack on this host, real sockets),
* REPRODUCIBILITY (identical fingerprints for identical seeds).
None of them is a measurement of network hardware.
"""

from __future__ import annotations

import time
from pathlib import Path

from ..config import LiveTestConfig, load_experiment
from ..simulation.engine import Simulation
from ..telemetry.export import rows_to_csv, write_json
from ..telemetry.resources import host_info
from ..transport.native import PythonCodec, load_codec


def bench_codec(n: int = 200_000) -> dict:
    out = {}
    for codec in {load_codec().name: load_codec(), "python-struct": PythonCodec()}.values():
        t0 = time.perf_counter()
        for i in range(n):
            codec.pack(0, 1, i, i, 0, 1, i, 1200, 0)
        t_pack = time.perf_counter() - t0
        buf = codec.pack(0, 1, 7, 7, 0, 1, 7, 1200, 0)
        t0 = time.perf_counter()
        for _ in range(n):
            codec.unpack(buf)
        t_unpack = time.perf_counter() - t0
        rows = [(0, 1, i, i, 0, 1, i, 1200, 0) for i in range(1000)]
        t0 = time.perf_counter()
        for _ in range(n // 1000):
            codec.pack_batch(rows)
        t_batch = time.perf_counter() - t0
        out[codec.name] = {"label": "CODEC (software, this host)", "n": n, "pack_per_s": n / t_pack,
                           "unpack_per_s": n / t_unpack, "batch_pack_per_s": n / t_batch,
                           "implied_max_pps_at_1_core_pack_only": n / t_pack}
    return out


def bench_simulator(config: str, seeds=(1, 2, 3), scenario: str = "baseline", policy: str = "baseline") -> dict:
    cfg = load_experiment(config)
    rows = []
    fps = []
    for s in seeds:
        r = Simulation(cfg, scenario, policy, s).run()
        rows.append({"seed": s, **r["resources"], "packets": r["integrity"]["packets_injected"]})
        fps.append(r["fingerprint"])
    again = Simulation(cfg, scenario, policy, seeds[0]).run()["fingerprint"]
    return {"label": "SIMULATOR (software cost, this host)", "scenario": scenario, "policy": policy, "runs": rows,
            "reproducible_same_seed": again == fps[0], "fingerprint_seed0": fps[0],
            "distinct_seeds_distinct_fingerprints": len(set(fps)) == len(fps)}


def _live_cfg(transport: str, flows: list[dict], ceiling: float) -> LiveTestConfig:
    return LiveTestConfig.model_validate({
        "name": f"bench-{transport}", "transport": transport, "endpoint": {"host": "127.0.0.1", "port": 0},
        "max_duration_s": 30, "rate_ceiling_mbps": ceiling, "max_total_bytes": 4 * 1024**3,
        "clock_sync": "same_host", "udp": {"adaptive": False}, "flows": flows})


def bench_live(duration_s: float = 3.0, quick: bool = False) -> list[dict]:
    from ..transport.live import run_live

    rows = []
    tcp_rates = [50, 400] if quick else [50, 200, 800, 1600]
    udp_rates = [50, 200] if quick else [50, 200, 500, 1000]
    plan = [("tcp", r, {"id": f"tcp-stream-{r}", "pattern": "constant_rate", "payload_bytes": 16000, "rate_mbps": r,
                        "duration_s": duration_s}) for r in tcp_rates]
    plan += [("udp", r, {"id": f"udp-paced-{r}", "pattern": "constant_rate", "payload_bytes": 1200, "rate_mbps": r,
                         "duration_s": duration_s}) for r in udp_rates]
    plan += [("tcp", 10, {"id": "tcp-rpc", "pattern": "request_response", "payload_bytes": 256, "response_bytes": 1024,
                          "rate_mbps": 10, "concurrency": 16, "duration_s": duration_s, "timeout_ms": 1000})]
    plan += [("udp", 10, {"id": "udp-rpc", "pattern": "request_response", "payload_bytes": 256, "response_bytes": 1024,
                          "rate_mbps": 10, "concurrency": 16, "duration_s": duration_s, "timeout_ms": 1000})]
    try:
        from ..transport import quic  # noqa: F401
        if quic.AVAILABLE:
            plan += [("quic", 5, {"id": "quic-rpc", "pattern": "request_response", "payload_bytes": 256,
                                  "response_bytes": 1024, "rate_mbps": 5, "concurrency": 16, "duration_s": duration_s,
                                  "timeout_ms": 1000})]
    except Exception:
        pass
    for transport, rate, flow in plan:
        res = run_live(_live_cfg(transport, [flow], max(rate, 10)))
        f = res["flows"][0]
        rows.append({
            "label": "LIVE TEST loopback (this host's software stack)", "transport": transport, "flow": f["id"],
            "target_wire_mbps": f["target_wire_rate_mbps"], "sent_wire_mbps_est": f["achieved_send_wire_rate_mbps_est"],
            "goodput_mbps": f.get("goodput_mbps"), "generator_limited": f["generator_limited"],
            "gen_lag_p99_ms": f["generator_lag_ms"]["p99"], "loss_ratio": f.get("loss_ratio"),
            "owd_p50_ms": (f.get("owd_ms") or {}).get("p50"), "owd_p99_ms": (f.get("owd_ms") or {}).get("p99"),
            "rtt_p50_ms": (f.get("rtt_ms") or {}).get("p50"), "rtt_p99_ms": (f.get("rtt_ms") or {}).get("p99"),
            "requests_ok": (f.get("requests") or {}).get("ok"), "request_failures":
                ((f.get("requests") or {}).get("timeouts", 0) + (f.get("requests") or {}).get("errors", 0)) if f.get("requests") else None,
            "client_cpu_mean_pct": res["resources"]["process"]["cpu_util_mean_pct"],
            "loop_delay_p99_ms": res["resources"]["event_loop_delay"].get("p99_ms")})
    return rows


def run_benchmarks(config: str, out_dir: str | Path, quick: bool = False, live: bool = True,
                   progress=print) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    report = {"host": host_info(), "created_unix": time.time(),
              "note": "Benchmarks characterise this host's software (simulator, Python codec, asyncio + OS loopback). "
                      "They are not measurements of network hardware or of any real network path."}
    progress("codec micro-benchmark…")
    report["codec"] = bench_codec(50_000 if quick else 200_000)
    progress("simulator throughput & reproducibility…")
    report["simulator"] = bench_simulator(config, seeds=(1, 2) if quick else (1, 2, 3))
    if live:
        progress("live loopback transports…")
        report["live_loopback"] = bench_live(2.0 if quick else 3.0, quick)
        rows_to_csv(report["live_loopback"], out / "live_loopback.csv")
    write_json(out / "benchmarks.json", report)
    rows_to_csv([{"seed": r["seed"], "wall_s": r["wall_s"], "events": r["events"],
                  "events_per_wall_s": r["events_per_wall_s"], "packets": r["packets"],
                  "simulated_packets_per_wall_s": r["simulated_packets_per_wall_s"]}
                 for r in report["simulator"]["runs"]], out / "simulator.csv")
    return report
