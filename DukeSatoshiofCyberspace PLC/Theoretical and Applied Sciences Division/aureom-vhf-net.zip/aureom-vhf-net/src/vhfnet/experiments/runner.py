"""Reproducible experiment grids: scenarios x policies x seeds.

Runs execute in a bounded process pool. Each run writes a compact JSON summary;
the first seed of every (scenario, policy) also keeps full detail (time series,
route log, job sample) for the dashboard. Aggregates are exported as CSV/JSON
and registered in the SQLite metadata store.
"""

from __future__ import annotations

import json
import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Callable

from .. import __version__
from ..config import ExperimentConfig
from ..optimisation.montecarlo import seed_summary
from ..telemetry.export import rows_to_csv, write_json
from ..telemetry.resources import host_info
from ..telemetry.store import ExperimentStore
from .compare import HEADLINE_METRICS, compare_policies, headline

DETAIL_KEYS = ("timeseries", "routes", "jobs_sample", "conditions", "migrations")


def _compact(result: dict) -> dict:
    out = {k: v for k, v in result.items() if k not in DETAIL_KEYS}
    out["routes"] = {"count": result["routes"]["count"], "per_flow": result["routes"]["per_flow"]}
    return out


def _run_one(cfg_dict: dict, scenario: str, policy: str, seed: int, out_dir: str, keep_detail: bool) -> dict:
    from ..simulation.engine import Simulation

    cfg = ExperimentConfig.model_validate(cfg_dict)
    res = Simulation(cfg, scenario, policy, seed).run()
    run_dir = Path(out_dir) / "runs" / scenario / policy
    run_dir.mkdir(parents=True, exist_ok=True)
    path = run_dir / f"seed{seed}.json"
    write_json(path, res if keep_detail else _compact(res))
    return {"scenario": scenario, "policy": policy, "seed": seed, "fingerprint": res["fingerprint"],
            "wall_s": res["resources"]["wall_s"], "path": str(path.relative_to(out_dir)),
            "headline": headline(res), "detail": keep_detail,
            "flows": [{k: f.get(k) for k in FLOW_COLUMNS} for f in res["flows"]],
            "links": [{k: l.get(k) for k in LINK_COLUMNS} for l in res["links"]],
            "integrity": res["integrity"], "resources": res["resources"]}


FLOW_COLUMNS = ("id", "kind", "priority", "deadline_ms", "offered_bps", "transmitted_wire_bps", "delivered_wire_bps",
                "goodput_bps", "useful_goodput_bps", "packet_loss_ratio", "deadline_miss_ratio",
                "retransmitted_packets", "duplicate_packets", "reordered_packets", "jitter_rfc3550_ms",
                "ipdv_p95_ms", "pdv_p99_ms", "age_of_information_ms", "flow_completion_time_s", "file_progress",
                "route_changes", "starved", "max_delivery_gap_s", "delivery_ratio_bytes")
LINK_COLUMNS = ("link", "discipline", "utilisation", "busy_fraction", "tx_bits", "capacity_integral_bits",
                "queue_mean_bytes", "queue_max_bytes", "drops", "energy_estimated_j")


def run_experiment(cfg: ExperimentConfig, out_dir: str | Path, *, scenarios: list[str] | None = None,
                   policies: list[str] | None = None, seeds: list[int] | None = None, workers: int | None = None,
                   reference: str | None = None, store: ExperimentStore | None = None,
                   detail: str = "first", progress: Callable[[str], None] | None = print) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    scenarios = scenarios or [s.id for s in cfg.scenarios] or ["baseline"]
    policies = policies or [p.id for p in cfg.policies]
    seeds = seeds or list(cfg.seeds)
    reference = reference or policies[0]
    workers = max(1, min(workers or os.cpu_count() or 1, 8))
    tasks = [(s, p, seed) for s in scenarios for p in policies for seed in seeds]
    store = store or ExperimentStore(out / "experiments.sqlite")
    host = host_info()
    eid = store.create_experiment(cfg.name, "SIMULATION", cfg.model_dump(), cfg.description, str(out), host)
    t0 = time.time()
    cfg_dict = cfg.model_dump()
    results = []
    with ProcessPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(_run_one, cfg_dict, s, p, seed, str(out),
                          detail == "all" or (detail == "first" and seed == seeds[0])): (s, p, seed)
                for s, p, seed in tasks}
        for i, fut in enumerate(as_completed(futs), 1):
            r = fut.result()
            results.append(r)
            store.add_run(eid, "SIMULATION", r["scenario"], r["policy"], r["seed"], r["fingerprint"], r["wall_s"],
                          r["headline"], r["path"])
            if progress:
                progress(f"[{i}/{len(tasks)}] {r['scenario']:>18s} {r['policy']:>12s} seed={r['seed']:<3d} "
                         f"miss={_fmt(r['headline']['deadline_miss_ratio'])} "
                         f"useful={_fmt(r['headline']['useful_goodput_mbps'])}Mb/s wall={r['wall_s']:.1f}s")
    order = {(s, p, seed): i for i, (s, p, seed) in enumerate(tasks)}
    results.sort(key=lambda r: order[(r["scenario"], r["policy"], r["seed"])])

    # ---- exports ---------------------------------------------------------------
    runs_rows = [{"scenario": r["scenario"], "policy": r["policy"], "seed": r["seed"], "fingerprint": r["fingerprint"],
                  "capacity_conserved": r["integrity"]["capacity_conserved"],
                  "delay_identity_err_s": r["integrity"]["delay_identity_max_abs_error_s"],
                  "sim_wall_s": r["wall_s"], **r["headline"]} for r in results]
    rows_to_csv(runs_rows, out / "runs.csv")
    rows_to_csv([{"scenario": r["scenario"], "policy": r["policy"], "seed": r["seed"], **f}
                 for r in results for f in r["flows"]], out / "flows.csv")
    rows_to_csv([{"scenario": r["scenario"], "policy": r["policy"], "seed": r["seed"], **l}
                 for r in results for l in r["links"]], out / "links.csv")
    agg = []
    for s in scenarios:
        for p in policies:
            rs = [r for r in results if r["scenario"] == s and r["policy"] == p]
            row = {"scenario": s, "policy": p, "n_seeds": len(rs)}
            for key in list(HEADLINE_METRICS) + ["inference_p99_ms", "api_p99_ms", "media_miss_ratio",
                                                  "twin_miss_ratio", "telemetry_miss_ratio", "request_failures"]:
                ss = seed_summary([r["headline"].get(key) for r in rs])
                row[f"{key}.mean"] = ss["mean"]
                row[f"{key}.mcse"] = ss["mcse"]
                row[f"{key}.p10"] = ss["p10"]
                row[f"{key}.p90"] = ss["p90"]
            agg.append(row)
    rows_to_csv(agg, out / "aggregate.csv")
    cmp = compare_policies([{"scenario": r["scenario"], "policy": r["policy"], "seed": r["seed"],
                             "headline": r["headline"]} for r in results], reference)
    write_json(out / "comparison.json", cmp)
    cmp_rows = []
    for sc, pols in cmp["scenarios"].items():
        for pol, metrics in pols.items():
            for key, t in metrics.items():
                cmp_rows.append({"scenario": sc, "policy": pol, "reference": reference, "metric": key,
                                 "label": HEADLINE_METRICS.get(key, (key,))[0], "direction": t.get("direction"),
                                 "n": t.get("n"), "ref_mean": t.get("ref_mean"), "alt_mean": t.get("alt_mean"),
                                 "diff_mean": t.get("diff_mean"), "ci95_lo": (t.get("ci95") or [None, None])[0],
                                 "ci95_hi": (t.get("ci95") or [None, None])[1], "wilcoxon_p": t.get("wilcoxon_p"),
                                 "verdict": t.get("verdict")})
    rows_to_csv(cmp_rows, out / "comparison.csv")
    elapsed = time.time() - t0
    integrity_ok = all(r["integrity"]["capacity_conserved"] for r in results)
    manifest = {
        "mode": "SIMULATION",
        "experiment_id": eid,
        "name": cfg.name,
        "description": cfg.description,
        "vhfnet_version": __version__,
        "created_unix": t0,
        "elapsed_wall_s": elapsed,
        "workers": workers,
        "scenarios": [{"id": sc.id, "name": sc.name, "description": sc.description}
                      for sc in cfg.scenarios if sc.id in scenarios],
        "policies": [{"id": p.id, "label": p.label} for p in cfg.policies if p.id in policies],
        "reference_policy": reference,
        "seeds": seeds,
        "runs": len(results),
        "integrity_all_capacity_conserved": integrity_ok,
        "max_delay_identity_error_s": max(r["integrity"]["delay_identity_max_abs_error_s"] for r in results),
        "fingerprints": {f"{r['scenario']}/{r['policy']}/{r['seed']}": r["fingerprint"] for r in results},
        "detail_runs": [r["path"] for r in results if r["detail"]],
        "host": host,
        "simulator_cost": {"total_sim_wall_s": sum(r["wall_s"] for r in results),
                           "note": "software cost of the simulator, not network performance"},
        "statements": cmp["statements"],
        "files": ["runs.csv", "flows.csv", "links.csv", "aggregate.csv", "comparison.csv", "comparison.json",
                  "experiments.sqlite", "runs/<scenario>/<policy>/seed<k>.json"],
    }
    write_json(out / "manifest.json", manifest)
    with open(out / "config.resolved.json", "w", encoding="utf-8") as fh:
        json.dump(cfg.model_dump(), fh, indent=1)
    store.finish_experiment(eid, "complete", {"runs": len(results), "elapsed_wall_s": elapsed,
                                              "scoreboard": cmp["scoreboard"]})
    return manifest


def _fmt(x) -> str:
    return "  n/a" if x is None else f"{x:.3f}"
