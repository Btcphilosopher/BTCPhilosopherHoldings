"""Explicit units and quantity conventions for VHF.NET.

"VHF" in this project is a *product label* for the high-rate message-processing
pipeline (framing, pacing, scheduling of many small messages). It does NOT refer
to the 30-300 MHz "very high frequency" radio band.

Four quantities are often conflated in networking marketing material. This code
base keeps them strictly separate, by name and by unit:

==========================  =========  ==================================================
Quantity                    Unit       Naming convention in code
==========================  =========  ==================================================
Packet / message frequency  1/s        ``*_pps`` (packets per second), ``*_mps``
                                       (messages per second)
Radio carrier frequency     Hz         ``carrier_freq_hz``
Radio channel bandwidth     Hz         ``channel_bw_hz``
Link capacity / throughput  bit/s      ``*_bps`` internally; ``*_mbps`` in config files
==========================  =========  ==================================================

Internally every quantity is SI: seconds, bits (for rates) and bytes (for sizes).
Configuration files use human-friendly units whose names carry the unit suffix
(``capacity_mbps``, ``propagation_delay_ms``, ``buffer_bytes``) and are converted
exactly once, at load time, by the helpers below.
"""

from __future__ import annotations

import math

BITS_PER_BYTE = 8

# --- rate conversions (bit/s) -------------------------------------------------

def mbps_to_bps(mbps: float) -> float:
    return float(mbps) * 1e6


def bps_to_mbps(bps: float) -> float:
    return float(bps) / 1e6


def gbps_to_bps(gbps: float) -> float:
    return float(gbps) * 1e9


# --- time conversions (s) -----------------------------------------------------

def ms_to_s(ms: float) -> float:
    return float(ms) / 1e3


def us_to_s(us: float) -> float:
    return float(us) / 1e6


def s_to_ms(s: float) -> float:
    return float(s) * 1e3


# --- radio-side quantities (Hz, dB) ------------------------------------------

def ghz_to_hz(ghz: float) -> float:
    return float(ghz) * 1e9


def mhz_to_hz(mhz: float) -> float:
    return float(mhz) * 1e6


def db_to_linear(db: float) -> float:
    return 10.0 ** (float(db) / 10.0)


def linear_to_db(x: float) -> float:
    if x <= 0:
        return -math.inf
    return 10.0 * math.log10(x)


def dbm_to_watts(dbm: float) -> float:
    return 10.0 ** ((float(dbm) - 30.0) / 10.0)


def watts_to_dbm(w: float) -> float:
    if w <= 0:
        return -math.inf
    return 10.0 * math.log10(w) + 30.0


# --- serialisation ------------------------------------------------------------

def serialization_delay_s(size_bytes: int, capacity_bps: float) -> float:
    """Time to clock ``size_bytes`` onto a link of constant ``capacity_bps``.

    This is the *transmission* (serialisation) delay, distinct from propagation
    delay (distance / signal speed) and queueing delay (waiting for the link).
    """
    if capacity_bps <= 0:
        return math.inf
    return size_bytes * BITS_PER_BYTE / capacity_bps


def bytes_to_bits(n: int | float) -> float:
    return float(n) * BITS_PER_BYTE
