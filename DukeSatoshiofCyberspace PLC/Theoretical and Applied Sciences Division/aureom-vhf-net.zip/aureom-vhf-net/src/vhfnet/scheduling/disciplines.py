"""Bounded queue disciplines: FIFO, weighted fair queueing (SCFQ) and EDF.

All disciplines share one byte-bounded buffer. ``enqueue`` returns the list of
packets dropped as a result (possibly the arriving packet itself), so callers can
attribute every drop. Nothing is ever silently discarded.
"""

from __future__ import annotations

import heapq
from collections import deque
from typing import Protocol

from ..traffic.packet import Packet


class QueueDiscipline(Protocol):
    name: str
    buffer_bytes: int
    bytes: int

    def enqueue(self, pkt: Packet, now: float) -> list[Packet]: ...

    def dequeue(self, now: float) -> Packet | None: ...

    def flush(self) -> list[Packet]: ...

    def __len__(self) -> int: ...


class FIFOQueue:
    """First-in first-out with tail drop."""

    name = "fifo"

    def __init__(self, buffer_bytes: int) -> None:
        self.buffer_bytes = int(buffer_bytes)
        self.bytes = 0
        self._q: deque[Packet] = deque()

    def __len__(self) -> int:
        return len(self._q)

    def enqueue(self, pkt: Packet, now: float) -> list[Packet]:
        size = pkt.payload_bytes + pkt.header_bytes
        if self.bytes + size > self.buffer_bytes:
            return [pkt]
        self._q.append(pkt)
        self.bytes += size
        return []

    def dequeue(self, now: float) -> Packet | None:
        if not self._q:
            return None
        pkt = self._q.popleft()
        self.bytes -= pkt.payload_bytes + pkt.header_bytes
        return pkt

    def flush(self) -> list[Packet]:
        out = list(self._q)
        self._q.clear()
        self.bytes = 0
        return out


class EDFQueue:
    """Earliest-deadline-first with deadline-aware push-out.

    Packets without a deadline have deadline +inf (served only when no deadline
    traffic is queued -- they may starve; starvation is reported). Ties are FIFO.
    When the buffer is full, the queued packet(s) with the *latest* deadline are
    pushed out if the arriving packet has an earlier deadline; otherwise the
    arriving packet is dropped. (Plain tail drop would let no-deadline packets
    hog the shared buffer and cause deadline packets to be dropped.)
    """

    name = "edf"

    def __init__(self, buffer_bytes: int) -> None:
        self.buffer_bytes = int(buffer_bytes)
        self.bytes = 0
        self._h: list[tuple[float, int, Packet]] = []
        self._late: list[tuple[float, int]] = []  # max-heap on (deadline, arrival) via negation
        self._gone: set[int] = set()
        self._by_id: dict[int, Packet] = {}
        self._n = 0
        self._count = 0

    def __len__(self) -> int:
        return self._count

    def _latest(self):
        while self._late and -self._late[0][1] in self._gone:
            self._gone.discard(-heapq.heappop(self._late)[1])
        return self._late[0] if self._late else None

    def enqueue(self, pkt: Packet, now: float) -> list[Packet]:
        size = pkt.payload_bytes + pkt.header_bytes
        dropped: list[Packet] = []
        while self.bytes + size > self.buffer_bytes:
            top = self._latest()
            if top is None or -top[0] <= pkt.deadline_abs:
                dropped.append(pkt)
                return dropped
            dropped.append(self._remove(-top[1]))
        self._n += 1
        heapq.heappush(self._h, (pkt.deadline_abs, self._n, pkt))
        heapq.heappush(self._late, (-pkt.deadline_abs, -self._n))
        self._by_id[self._n] = pkt
        self.bytes += size
        self._count += 1
        return dropped

    def _remove(self, n: int) -> Packet:
        heapq.heappop(self._late)
        pkt = self._by_id.pop(n)
        self._gone.add(n)
        self.bytes -= pkt.payload_bytes + pkt.header_bytes
        self._count -= 1
        return pkt

    def dequeue(self, now: float) -> Packet | None:
        while self._h:
            _, n, pkt = heapq.heappop(self._h)
            if n not in self._by_id:
                self._gone.discard(n)
                continue  # pushed out earlier
            del self._by_id[n]
            self._gone.add(n)
            self.bytes -= pkt.payload_bytes + pkt.header_bytes
            self._count -= 1
            return pkt
        return None

    def flush(self) -> list[Packet]:
        out = list(self._by_id.values())
        self._h.clear()
        self._late.clear()
        self._gone.clear()
        self._by_id.clear()
        self.bytes = 0
        self._count = 0
        return out


class WFQQueue:
    """Weighted fair queueing via Self-Clocked Fair Queueing (Golestani 1994).

    Finish tag F = max(V, F_prev(flow)) + bits / weight, where V is the tag of the
    packet in service. Per-flow FIFOs; a heap orders head-of-line packets.
    Buffer overflow uses *longest-queue drop*: the tail packet of the flow holding
    the most bytes is dropped (protects light flows from heavy ones).
    """

    name = "wfq"

    def __init__(self, buffer_bytes: int) -> None:
        self.buffer_bytes = int(buffer_bytes)
        self.bytes = 0
        self._flows: dict[int, deque[tuple[float, int, Packet]]] = {}
        self._fbytes: dict[int, int] = {}
        self._last: dict[int, float] = {}
        self._heap: list[tuple[float, int, int]] = []
        self._n = 0
        self._count = 0
        self.vtime = 0.0

    def __len__(self) -> int:
        return self._count

    def _key(self, pkt: Packet) -> int:
        return pkt.flow_idx

    def enqueue(self, pkt: Packet, now: float) -> list[Packet]:
        size = pkt.payload_bytes + pkt.header_bytes
        key = self._key(pkt)
        dropped: list[Packet] = []
        while self.bytes + size > self.buffer_bytes:
            victim = None
            vbytes = self._fbytes.get(key, 0) + size
            for k, b in self._fbytes.items():
                if b > vbytes:
                    victim, vbytes = k, b
            if victim is None:
                dropped.append(pkt)
                return dropped
            dropped.append(self._drop_tail(victim))
        self._n += 1
        start = max(self.vtime, self._last.get(key, 0.0))
        finish = start + size * 8.0 / max(pkt.weight, 1e-9)
        pkt.sched_tag = finish
        self._last[key] = finish
        q = self._flows.get(key)
        if q is None:
            q = self._flows[key] = deque()
        q.append((finish, self._n, pkt))
        if len(q) == 1:
            heapq.heappush(self._heap, (finish, self._n, key))
        self._fbytes[key] = self._fbytes.get(key, 0) + size
        self.bytes += size
        self._count += 1
        return dropped

    def _drop_tail(self, key: int) -> Packet:
        q = self._flows[key]
        _, _, pkt = q.pop()
        size = pkt.payload_bytes + pkt.header_bytes
        self._fbytes[key] -= size
        self.bytes -= size
        self._count -= 1
        if q:
            self._last[key] = q[-1][0]
        else:
            self._last.pop(key, None)
            del self._fbytes[key]
            del self._flows[key]
        return pkt

    def dequeue(self, now: float) -> Packet | None:
        while self._heap:
            finish, n, key = heapq.heappop(self._heap)
            q = self._flows.get(key)
            if not q or q[0][1] != n:
                continue  # stale heap entry (head was dropped)
            _, _, pkt = q.popleft()
            size = pkt.payload_bytes + pkt.header_bytes
            self._fbytes[key] -= size
            self.bytes -= size
            self._count -= 1
            self.vtime = finish
            if q:
                heapq.heappush(self._heap, (q[0][0], q[0][1], key))
            else:
                del self._flows[key]
                del self._fbytes[key]
            if self._count == 0:
                self.vtime = 0.0
                self._last.clear()
                self._heap.clear()
            return pkt
        return None

    def flush(self) -> list[Packet]:
        out = [p for q in self._flows.values() for _, _, p in q]
        self._flows.clear()
        self._fbytes.clear()
        self._last.clear()
        self._heap.clear()
        self.bytes = 0
        self._count = 0
        self.vtime = 0.0
        return out


def make_queue(discipline: str, buffer_bytes: int) -> QueueDiscipline:
    if discipline == "fifo":
        return FIFOQueue(buffer_bytes)
    if discipline == "wfq":
        return WFQQueue(buffer_bytes)
    if discipline == "edf":
        return EDFQueue(buffer_bytes)
    raise ValueError(f"unknown discipline {discipline}")
