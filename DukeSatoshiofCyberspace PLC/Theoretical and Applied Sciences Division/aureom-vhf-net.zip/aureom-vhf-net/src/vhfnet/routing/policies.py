"""Routing policies: static shortest path, least-estimated-delay, adaptive.

All policies choose among the same candidate paths (loop-free, ordered by
propagation + processing delay). Decisions are per (flow, destination) and are
logged with the reason and estimated costs, so route changes are auditable.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..config import RoutingParams
from ..simulation.topology import Graph
from .control_plane import ControlPlane

INF = math.inf


@dataclass
class PathObs:
    """End-to-end measurements of one path by one flow (from feedback reports)."""

    owd_ewma: float = math.nan
    owd_var: float = 0.0
    loss_ewma: float = 0.0
    last_t: float = -INF
    samples: int = 0


@dataclass
class RouteState:
    paths: list[tuple[str, ...]]
    current: int = 0
    last_eval: float = -INF
    last_switch: float = -INF
    switches: int = 0
    obs: dict[int, PathObs] = field(default_factory=dict)


@dataclass
class RouteChange:
    t: float
    flow: str
    dst: str
    from_path: str
    to_path: str
    reason: str
    cost_from: float
    cost_to: float


def path_str(p: tuple[str, ...]) -> str:
    return ">".join(p)


class Router:
    name = "base"

    def __init__(self, graph: Graph, control: ControlPlane, params: RoutingParams, mtu_wire_bytes: int) -> None:
        self.graph = graph
        self.control = control
        self.p = params
        self.mtu_bits = mtu_wire_bytes * 8
        self.states: dict[tuple[int, str], RouteState] = {}
        self.changes: list[RouteChange] = []
        self.flow_names: dict[int, str] = {}
        self.flow_meta: dict[int, dict] = {}
        self.active_dst: dict[int, str] = {}

    # -- registry --------------------------------------------------------------
    def register_flow(self, flow_idx: int, name: str, deadline_s: float | None, rate_fn) -> None:
        self.flow_names[flow_idx] = name
        self.flow_meta[flow_idx] = {"deadline": deadline_s, "rate_fn": rate_fn}

    def state(self, flow_idx: int, src: str, dst: str) -> RouteState:
        key = (flow_idx, dst)
        st = self.states.get(key)
        if st is None:
            paths = self.graph.candidate_paths(src, dst, self.p.max_paths)
            if not paths:
                raise ValueError(f"no path {src}->{dst}")
            st = self.states[key] = RouteState(paths=paths)
        return st

    # -- estimates -------------------------------------------------------------
    def est_delay(self, path: tuple[str, ...]) -> float:
        """Model-based one-way delay estimate from (stale) control-plane reports."""
        view = self.control.view.links
        d = 0.0
        for i in range(len(path) - 1):
            spec = self.graph.dirlinks[(path[i], path[i + 1])]
            r = view.get(spec.dir_id)
            if r is None or not r.up or r.capacity_bps <= 0:
                return INF
            d += spec.prop_s + (r.queue_bytes * 8 + self.mtu_bits) / r.capacity_bps
        return d + self.graph.path_proc_s(path)

    def observe(self, flow_idx: int, dst: str, path: tuple[str, ...], owd: float, lost: bool, now: float) -> None:
        st = self.states.get((flow_idx, dst))
        if st is None:
            return
        try:
            k = st.paths.index(path)
        except ValueError:
            return
        o = st.obs.setdefault(k, PathObs())
        a = 0.1
        if not lost and math.isfinite(owd):
            if o.samples == 0 or math.isnan(o.owd_ewma):
                o.owd_ewma = owd
            else:
                diff = owd - o.owd_ewma
                o.owd_ewma += a * diff
                o.owd_var = (1 - a) * (o.owd_var + a * diff * diff)
            o.samples += 1
        o.loss_ewma = (1 - a) * o.loss_ewma + a * (1.0 if lost else 0.0)
        o.last_t = now

    # -- decision --------------------------------------------------------------
    def demand(self, flow_idx: int) -> float:
        fn = self.flow_meta.get(flow_idx, {}).get("rate_fn")
        return fn() if fn else 0.0

    def own_load(self) -> dict[str, float]:
        """Demand this device has assigned to each directional link (local knowledge,
        not stale): sum over flows of demand on the links of their active path."""
        load: dict[str, float] = {}
        for fidx, dst in self.active_dst.items():
            st = self.states.get((fidx, dst))
            if st is None:
                continue
            d = self.demand(fidx)
            p = st.paths[st.current]
            for i in range(len(p) - 1):
                lid = self.graph.dirlinks[(p[i], p[i + 1])].dir_id
                load[lid] = load.get(lid, 0.0) + d
        return load

    def residual_bps(self, flow_idx: int, dir_id: str, on_current: bool, own: dict[str, float]) -> float:
        """Capacity left for ``flow_idx`` on a link: reported capacity minus the larger of the
        (stale) measured rate and this device's assigned demand, excluding the flow itself."""
        r = self.control.view.links[dir_id]
        mine = self.demand(flow_idx) if on_current else 0.0
        load = max(r.rate_bps - mine, own.get(dir_id, 0.0) - mine, 0.0)
        return max(0.0, r.capacity_bps - load)

    def path_for(self, flow_idx: int, src: str, dst: str, now: float) -> tuple[str, ...]:
        self.active_dst[flow_idx] = dst
        st = self.state(flow_idx, src, dst)
        if len(st.paths) > 1 and now - st.last_eval >= self.p.decision_interval_ms / 1e3:
            st.last_eval = now
            self.decide(flow_idx, dst, st, now)
        return st.paths[st.current]

    def decide(self, flow_idx: int, dst: str, st: RouteState, now: float) -> None:
        pass

    def _switch(self, flow_idx: int, dst: str, st: RouteState, new: int, now: float, reason: str,
                c_old: float, c_new: float) -> None:
        self.changes.append(RouteChange(now, self.flow_names.get(flow_idx, str(flow_idx)), dst,
                                        path_str(st.paths[st.current]), path_str(st.paths[new]), reason,
                                        c_old, c_new))
        st.current = new
        st.last_switch = now
        st.switches += 1


class StaticShortestPath(Router):
    """Always the lowest propagation+processing-delay path. Never reacts (baseline)."""

    name = "static"


class LeastEstimatedDelay(Router):
    """Switch to the path with the lowest estimated delay at every decision epoch.
    No hysteresis, no dwell time: prone to oscillation under stale information."""

    name = "least_delay"

    def decide(self, flow_idx, dst, st, now):
        costs = [self.est_delay(p) for p in st.paths]
        best = min(range(len(costs)), key=lambda k: (costs[k], k != st.current))
        if best != st.current and costs[best] < costs[st.current]:
            reason = "current-path-unavailable" if math.isinf(costs[st.current]) else "lower-estimated-delay"
            self._switch(flow_idx, dst, st, best, now, reason, costs[st.current], costs[best])


class AdaptiveRouter(Router):
    """Multi-criteria adaptive routing with hysteresis and minimum dwell time.

    cost(p) = D(p) + ref * [ w_loss * L(p) + w_occ * O(p) + w_cap * S(p) + w_deadline * M(p) ]
              + switch_penalty * [p != current]

    D: estimated one-way delay (model from reports, blended with the flow's own
       measurements on paths it has used recently)
    L: path loss estimate (reported link drop ratios, combined with measured loss)
    O: max buffer occupancy fraction along the path
    S: capacity shortfall fraction = max(0, demand - residual) / demand
    M: approximate deadline-miss probability = exp(-slack / queueing-delay scale)
    ref: the flow's deadline, or 100 ms for flows without one

    A switch happens only if cost(best) < (1 - hysteresis) * cost(current) and the
    current path has been held >= min_dwell, except when the current path is
    unavailable (infinite cost), which triggers an immediate failover.
    """

    name = "adaptive"

    def path_cost(self, flow_idx: int, st: RouteState, k: int, now: float) -> float:
        path = st.paths[k]
        view = self.control.view.links
        d_model = self.est_delay(path)
        if math.isinf(d_model):
            return INF
        o = st.obs.get(k)
        fresh = o is not None and o.samples > 0 and now - o.last_t < 4 * self.p.decision_interval_ms / 1e3
        d = 0.5 * d_model + 0.5 * o.owd_ewma if fresh and not math.isnan(o.owd_ewma) else d_model
        meta = self.flow_meta.get(flow_idx, {})
        deadline = meta.get("deadline")
        ref = deadline if deadline else 0.1
        ok = 1.0
        occ = 0.0
        shortfall = 0.0
        qdelay = 0.0
        demand = self.demand(flow_idx)
        own = self._own if self._own is not None else self.own_load()
        cur_links = set(self._path_links(st.paths[st.current]))
        for i in range(len(path) - 1):
            spec = self.graph.dirlinks[(path[i], path[i + 1])]
            r = view[spec.dir_id]
            ok *= 1.0 - min(r.loss_ratio, 1.0)
            occ = max(occ, r.queue_bytes / max(r.buffer_bytes, 1))
            qdelay += r.queue_bytes * 8 / r.capacity_bps
            if demand > 0:
                residual = self.residual_bps(flow_idx, spec.dir_id, spec.dir_id in cur_links, own)
                shortfall = max(shortfall, max(0.0, demand - residual) / demand)
        loss = 1.0 - ok
        if fresh:
            loss = 0.5 * loss + 0.5 * o.loss_ewma
        miss = 0.0
        if deadline:
            slack = deadline - d
            jitter = math.sqrt(o.owd_var) if fresh else 0.0
            scale = max(qdelay + 2 * jitter, 1e-3)
            miss = 1.0 if slack <= 0 else math.exp(-slack / scale)
        p = self.p
        cost = d + ref * (p.w_loss * loss + p.w_occupancy * occ + p.w_capacity * shortfall + p.w_deadline * miss)
        if k != st.current:
            cost += p.switch_penalty_ms / 1e3
        return cost

    _own: dict[str, float] | None = None

    def _path_links(self, p: tuple[str, ...]) -> list[str]:
        return [self.graph.dirlinks[(p[i], p[i + 1])].dir_id for i in range(len(p) - 1)]

    def decide(self, flow_idx, dst, st, now):
        self._own = self.own_load()
        try:
            costs = [self.path_cost(flow_idx, st, k, now) for k in range(len(st.paths))]
        finally:
            self._own = None
        cur = st.current
        best = min(range(len(costs)), key=lambda k: (costs[k], k != cur))
        if best == cur:
            return
        if math.isinf(costs[cur]):
            if math.isfinite(costs[best]):
                self._switch(flow_idx, dst, st, best, now, "failover:current-path-unavailable", costs[cur], costs[best])
            return
        if now - st.last_switch < self.p.min_dwell_ms / 1e3:
            return
        if costs[best] < (1.0 - self.p.hysteresis) * costs[cur]:
            self._switch(flow_idx, dst, st, best, now, "lower-cost-beyond-hysteresis", costs[cur], costs[best])


class FixedRoute:
    """Fixed path (used for response sub-flows that retrace the request path)."""

    def __init__(self, path: tuple[str, ...]) -> None:
        self.path = path


def make_router(kind: str, graph: Graph, control: ControlPlane, params: RoutingParams, mtu_wire: int) -> Router:
    if kind == "static":
        return StaticShortestPath(graph, control, params, mtu_wire)
    if kind == "least_delay":
        return LeastEstimatedDelay(graph, control, params, mtu_wire)
    if kind == "adaptive":
        return AdaptiveRouter(graph, control, params, mtu_wire)
    raise ValueError(kind)
