"""Delayed, periodic link/compute state reports used by routing and placement.

Routers never read the simulator's ground truth. They see snapshots taken every
``report_interval`` and published ``report_delay`` later (stale information is
what makes naive least-delay routing oscillate).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass(frozen=True)
class LinkReport:
    capacity_bps: float
    up: bool
    queue_bytes: float  # time-averaged queue over the last report interval
    queue_bytes_now: int  # instantaneous queue at the snapshot
    buffer_bytes: int
    loss_ratio: float  # EWMA (alpha=0.3) of per-interval drop ratio
    rate_bps: float  # measured carried rate during the last interval


@dataclass(frozen=True)
class ComputeReport:
    queue_len: int
    busy_cores: int
    cores: int


@dataclass
class ControlView:
    t_measured: float = 0.0
    links: dict[str, LinkReport] = field(default_factory=dict)
    compute: dict[str, ComputeReport] = field(default_factory=dict)


class ControlPlane:
    def __init__(self, env, network, compute: dict, interval_s: float, delay_s: float,
                 capacity_noise: float = 0.0, rng: np.random.Generator | None = None) -> None:
        self.env = env
        self.network = network
        self.compute = compute
        self.interval = interval_s
        self.delay = delay_s
        self.noise = capacity_noise
        self.rng = rng
        self._q_area: dict[str, float] = {}
        self._loss: dict[str, float] = {}
        self.view = self._snapshot(first=True)
        self.reports = 0
        env.process(self._run())

    def _snapshot(self, first: bool = False) -> ControlView:
        now = self.env.now
        links = {}
        for lid, link in self.network.by_id.items():
            cap = link.timeline.capacity_at(now)
            if self.noise > 0 and self.rng is not None and cap > 0:
                cap = max(0.0, cap * (1 + self.rng.normal(0, self.noise)))
            offered = link.iv_offered
            prev = self._loss.get(lid, 0.0)
            loss = (0.7 * prev + 0.3 * link.iv_drops / offered) if offered else prev
            self._loss[lid] = loss
            rate = 0.0 if first else link.iv_bits / self.interval
            link._q_touch(now)
            area0 = self._q_area.get(lid, 0.0)
            self._q_area[lid] = link.q_area
            q_mean = link.queue.bytes if first else (link.q_area - area0) / self.interval
            links[lid] = LinkReport(cap, link.timeline.is_up(now), q_mean, link.queue.bytes, link.buffer_bytes,
                                    loss, rate)
            link.iv_offered = link.iv_drops = 0
            link.iv_bits = 0.0
        comp = {nid: ComputeReport(len(s.queue), s.busy, s.cores) for nid, s in self.compute.items()}
        return ControlView(now, links, comp)

    def _run(self):
        env = self.env
        while True:
            yield env.timeout(self.interval)
            snap = self._snapshot()
            if self.delay > 0:
                ev = env.timeout(self.delay, snap)
                ev.callbacks.append(self._publish)
            else:
                self.view = snap
                self.reports += 1

    def _publish(self, ev) -> None:
        if ev.value.t_measured >= self.view.t_measured:
            self.view = ev.value
            self.reports += 1
