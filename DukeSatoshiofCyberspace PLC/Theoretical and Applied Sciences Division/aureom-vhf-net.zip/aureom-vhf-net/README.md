# Aureom.AI VHF.NET

An inspectable internet-performance laboratory in Python: controlled traffic,
a discrete-event network digital twin with an explicit wireless abstraction,
routing / scheduling / edge-placement policies, bounded live transport tests,
Bayesian and Monte Carlo uncertainty tools, reproducible experiments and an
interactive technical console.

> **“VHF”** is the product label for the high-rate message-processing pipeline
> (VHF frames, pacing, scheduling of many small messages). It is **not** the
> 30–300 MHz radio band. Packet/message frequency (pkt/s), radio carrier
> frequency (Hz), channel bandwidth (Hz) and throughput (bit/s) are separate
> quantities everywhere in the code (`src/vhfnet/units.py`).

Screenshots of the console: `docs/screenshots/` (topology, traffic, routing, experiments, ablation results, live test).

## Two modes, clearly separated

| | **SIMULATION** | **LIVE TEST** |
|---|---|---|
| Clock | virtual time (SimPy) | `time.monotonic_ns()` |
| Traffic | modelled packets over a fictional, lab-scaled network | real TCP / UDP / QUIC sockets |
| Endpoints | — | one explicitly configured host:port; loopback unless authorised |
| Bounds | event / packet / wall-clock limits, cancellation | duration ≤ 300 s, rate and byte ceilings, budget checked on every send |
| Results mean | outputs of stated assumptions | this host's software stack (loopback) or the authorised path |

Simulated throughput is never presented as measured hardware performance. Every
result file, API response and dashboard view carries its mode.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"          # Python ≥ 3.10; [dev] adds pytest and aioquic (optional QUIC)
python -m pytest                 # 68 tests: capacity conservation, queueing, scheduling, timeouts, metrics, reproducibility, …
vhfnet demo --seeds 1,2,3,4,5,6,7,8 --out results/demo     # 7 scenarios × 3 policies × 8 seeds (~3 min on 4 cores)
vhfnet serve                     # console at http://127.0.0.1:8765/
```

The archive already contains the results produced when this build was made
(`results/`), so `vhfnet serve` works immediately, and `results/report/index.html`
is a static snapshot that opens without a server.

Other entry points:

```bash
vhfnet simulate --scenario path_outage --policy adaptive --seed 3        # one run → JSON
vhfnet experiment --config configs/experiments/ablation_routing.yaml --out results/ablation_routing
vhfnet live run configs/live/loopback_udp.yaml                           # bounded loopback live test
vhfnet live run configs/live/loopback_tcp.yaml                           # (set tls: true for TCP+TLS)
vhfnet live run configs/live/loopback_quic.yaml                          # needs aioquic
vhfnet bench                                                             # codec, simulator, loopback transports
vhfnet montecarlo --draws 50000 --seed 7                                 # uncertainty propagation
vhfnet linkbudget --link acc-a                                           # simplified link budget table
vhfnet report                                                            # static dashboard snapshot
python scripts/verify_reproducibility.py results/demo --samples 6        # re-run & compare fingerprints
python scripts/summarise_results.py results docs/RESULTS.md              # regenerate the results summary
bash scripts/run_all.sh                                                  # reproduce everything bundled
```

## The pipeline

**Generate traffic → traverse simulated links → collect measurements → compare policies → display.**

1. `traffic/` pre-generates arrival schedules from per-flow random streams (constant-rate, bursty ON/OFF,
   request–response, periodic telemetry, large file transfer, interactive media, AI inference, digital-twin updates).
   Each flow has payload size, arrival model, duration, destination, priority, deadline, reliability objective
   and a maximum sending rate.
2. `transport/simulated.py` fragments messages into sequence-numbered, timestamped packets, paces them
   (never above `max_rate_mbps`), applies per-destination bounded AIMD, optional experimental ARQ, and a bounded
   send buffer whose overflow is reported as backpressure rejection.
3. `simulation/` moves packets over directional links: bounded FIFO / WFQ / EDF queues, serialisation integrated
   over a piecewise-constant capacity timeline, loss, propagation, node processing. Timelines come from the
   wireless abstraction and scenario events (capacity drops, handovers, blockage, outages, random MTBF/MTTR).
4. `routing/`, `edge/` decide paths and compute placement from *delayed* control-plane reports.
5. `telemetry/` + `simulation/results.py` produce offered → transmitted → delivered → goodput → useful accounting,
   latency decomposition, jitter, loss, reordering, duplicates, deadline misses, fairness, starvation,
   queue occupancy, utilisation, energy estimates and integrity checks.
6. `experiments/` runs seeded grids in a bounded process pool and compares policies paired by seed.
7. `api/` + `dashboard/` serve the console: Topology · Traffic · Links · Routing · Edge Compute · Experiments · Results.

## Demonstration (fictional “Aureom Lab Metro”)

* **Topology** (`configs/topologies/lab_metro.yaml`): client `ue-1`; access A = a slice of a *prospective* sub-THz
  small cell (140 GHz, 2 GHz channel — scenario parameters) capped at 80/160 Mb/s; access B = mid-band macro
  35/70 Mb/s; two edge workers (4 × 80 GOP/s); core; one cloud service (32 × 150 GOP/s, +12 ms).
* **Workload** (`configs/workloads/demo_mix.yaml`): telemetry, 60 fps media (adaptive bitrate), digital-twin
  updates to a migratable edge service, AI inference with placement, API request–response, and a 25 MB bulk upload.
* **Scenarios** (`configs/scenarios/demo_scenarios.yaml`): 1 stable baseline · 2 sudden capacity reduction ·
  3 bursty competing traffic · 4 handover interruption + service migration · 5 edge-server overload ·
  6 complete path outage · 7 degradation, outage and recovery.
* **Policy bundles** (`configs/policies/demo_policies.yaml`): `baseline` (static shortest path, FIFO, nearest edge,
  fixed rate), `least_delay` (least-estimated-delay routing, FIFO, least-completion placement, AIMD), `adaptive`
  (hysteresis + dwell routing, WFQ, least-completion placement, AIMD).
* **Ablations** isolate one component at a time: `ablation_routing`, `ablation_scheduling`, `ablation_placement`.

### What the bundled results show

See **`docs/RESULTS.md`** (generated from the result files) and the Results tab. In short, and only as far as the
paired analysis supports it:

* **Stable baseline:** the adaptive bundle does not beat static routing. Deadline misses are statistically
  indistinguishable (0.003 vs 0.003), and useful goodput is slightly *lower* (51.3 → 50.2 Mb/s, verdict ▼).
  Adapting has a cost when nothing goes wrong.
* **Disruptions** (capacity drop, bursty competition, edge overload, path outage, degradation + recovery): the
  adaptive bundle cuts the deadline-miss ratio by 89–98% in each of those five scenarios (e.g. path outage
  0.301 → 0.024, capacity drop 0.386 → 0.019; n = 8 paired seeds), and more inference requests finish on time in all five.
* **Not uniformly better:** media p99 latency is *worse* under the path outage (37.7 → 42.2 ms), and inconclusive
  under handover (47.5 → 59.9 ms) and recovery. Useful goodput is worse in the handover scenario. Estimated energy is higher
  in most disruption scenarios. Large-file (priority 6) chunk latency is worse in every scenario: this per-class
  degradation is listed rather than hidden by the aggregate gains.
* **Least-estimated-delay routing without hysteresis** also reduces misses, but it churns (up to ≈ 134 route changes
  per 10 s run under the capacity drop, vs ≈ 29 for the adaptive router) and worsens media p99 in 5 of 7 scenarios.
* **Ablations attribute much of the gain to single components:** WFQ/EDF scheduling alone (bursty: miss
  0.145 → 0.003) and least-completion placement alone (edge overload: inference on-time 0.50 → 0.998). Rate
  adaptation (AIMD) was not ablated separately, so its share is not claimed.
  *Routing alone* (FIFO, fixed rates) helps under bursty traffic and capacity drops, barely moves a full path
  outage (0.300 → 0.285, because fixed-rate senders overload the smaller path), and is **worse** than static routing
  during handovers (0.023 → 0.089). Hysteresis and dwell mainly cut route churn (≈ 150–320 → 18–55 changes per run)
  rather than deadline misses.
* **Placement:** on-device execution misses every inference deadline (≈ 200 ms of compute against a 150 ms deadline).
  The cloud matches the edge on the stable baseline at lower *estimated* energy but higher p99. The edge is not
  always the right answer.
* **Live loopback benchmarks** (this host, Python/asyncio + Linux): paced TCP up to 1.6 Gb/s and UDP up to 1 Gb/s
  achieved their targets, but UDP showed 2.6% loss at 1 Gb/s (socket-buffer overflow). These figures characterise
  the software stack, not network hardware.

## Measurement integrity

* Delay identity per packet: `recv − created = application + queueing + transmission + propagation + processing`
  (checked; max error ~1e-15 s).
* Capacity conservation: bits serialised on every link ≤ ∫capacity dt (checked per run and by tests that verify
  non-overlapping transmissions and per-packet capacity integrals).
* Failed requests (timeouts, rejections, losses) are counted, shown next to latency percentiles, and included in
  deadline-miss ratios. One-way delay is reported only when clocks share a time base. Jitter definitions are explicit.
* Details: `docs/MEASUREMENT.md`. Assumptions: `docs/ASSUMPTIONS.md`.

## Uncertainty

`vhfnet.optimisation` (independent of the simulator):
Beta–Bernoulli monitoring with an independence assumption **or** dependence-aware variants (effective sample size
from autocorrelation; block/batch means), moving-block bootstrap, windowed rates, posterior route comparison,
expected value of (sample/perfect) information to decide whether more measurements are worthwhile, and Monte Carlo
propagation of uncertain link conditions reporting draw count, seed, quantiles, Monte Carlo standard errors,
assumptions and sensitivity (Spearman + p10/p90 swings).

## Live testing

Bounded and explicit by construction — see `docs/LIVE_TESTING.md`. TCP (asyncio streams, optional TLS via `ssl`),
bounded UDP (pacing, receiver feedback, bounded AIMD, EXPERIMENTAL NACK retransmission), optional QUIC via aioquic
(TLS 1.3). No endpoint discovery, no unrestricted flooding; cryptography is only from established libraries.

## Outputs

Each experiment directory contains `manifest.json` (seeds, host, versions, fingerprints, findings),
`config.resolved.json`, `runs.csv`, `flows.csv`, `links.csv`, `aggregate.csv` (mean ± MCSE, p10/p90 across seeds),
`comparison.csv` / `comparison.json` (paired verdicts, CIs, Wilcoxon p, per-class degradations),
`experiments.sqlite` (metadata) and `runs/<scenario>/<policy>/seed<k>.json` (full detail for the representative seed).

## Layout

```
src/vhfnet/   traffic/ transport/ simulation/ routing/ scheduling/ edge/ telemetry/ optimisation/ api/ dashboard/ experiments/
configs/      topologies/ workloads/ scenarios/ policies/ experiments/ live/
docs/         ARCHITECTURE.md ASSUMPTIONS.md MEASUREMENT.md LIVE_TESTING.md NATIVE.md RESULTS.md
scripts/      run_all.sh verify_reproducibility.py summarise_results.py
tests/        pytest suite
results/      bundled results from the build host (regenerable)
```

## Limitations (read before citing a number)

* The network, its capacities and workloads are fictional and lab-scaled; radio behaviour is a stated abstraction,
  not a physical-layer model; 6G figures are scenario parameters.
* Pure Python cannot sustain arbitrary line rates; see `docs/NATIVE.md` for measured limits and the extension interface.
* The adaptive policy is a reference design with tunable weights; its advantages and disadvantages are scenario-
  and parameter-dependent and are reported as such.
* Feedback ignores reverse-path queueing; node forwarding has no capacity limit; energy figures are estimates.
* Bundled results come from one host; re-run `scripts/run_all.sh` to reproduce on yours (fingerprints should match
  on the same code version; floating-point differences across platforms are possible).
