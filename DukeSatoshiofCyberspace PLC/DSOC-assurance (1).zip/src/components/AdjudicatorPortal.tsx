/**
 * Duke Satoshi of Cyberspace Insurance - Adjudication Workbench
 * Developed by Aureom.AI | RhinoMutual Engine
 */

import React, { useState } from 'react';
import { AdjudicationDecision, Claim, TrackAReport, TrackBReport } from '../types';
import { 
  Scale, 
  CheckCircle2, 
  AlertTriangle, 
  GitMerge, 
  ArrowRight, 
  FileCheck2, 
  Building2, 
  CreditCard,
  ShieldAlert,
  HelpCircle,
  Gavel,
  Crown
} from 'lucide-react';

interface AdjudicatorPortalProps {
  claims: Claim[];
  onAuthorizeClaim: (claimId: string, decision: AdjudicationDecision) => void;
  onResolveAppeal: (
    claimId: string,
    determination: 'upheld' | 'modified' | 'reversed',
    revisedAmount: number,
    deliberation: string
  ) => void;
}

export const AdjudicatorPortal: React.FC<AdjudicatorPortalProps> = ({
  claims,
  onAuthorizeClaim,
  onResolveAppeal,
}) => {
  const [selectedClaimId, setSelectedClaimId] = useState<string>(
    claims.find((c) => c.state === 'assessed')?.id || claims[0]?.id || ''
  );

  const selectedClaim = claims.find((c) => c.id === selectedClaimId) || claims[0];

  // Adjudication form state
  const [payoutChannel, setPayoutChannel] = useState<'direct_repair_facility' | 'claimant_reimbursement'>('direct_repair_facility');
  const [repairVendorName, setRepairVendorName] = useState('Certified OEM Factory Service');
  const [adjudicatorNotes, setAdjudicatorNotes] = useState(
    'Reconciled Track A forensic verification with Track B contractual coverage. Applied contractual deductible of €1,500. Straight-line 15% depreciation calculated per Policy v1.2 §6.1. Payout routed directly to certified repair vendor.'
  );
  const [manualAdjustedAmount, setManualAdjustedAmount] = useState<number>(0);
  const [isAmountManuallyEdited, setIsAmountManuallyEdited] = useState(false);

  // Appeal Resolution State
  const [appealDetermination, setAppealDetermination] = useState<'upheld' | 'modified' | 'reversed'>('modified');
  const [appealRevisedAmount, setAppealRevisedAmount] = useState<number>(94500);
  const [appealDeliberationNotes, setAppealDeliberationNotes] = useState(
    'Senior panel reviewed Policy v1.2 Section 6.4 rider. Accelerators with active OEM service contracts are subject to market replacement benchmarks rather than standard 15% bulk rate. Revised net authorized payment to €94,500.'
  );

  // Extract revealed reports from selected claim
  const revealedTrackA = selectedClaim?.trackACommitments?.find((c) => c.status === 'revealed')?.revealedReport as TrackAReport | undefined;
  const revealedTrackB = selectedClaim?.trackBCommitments?.find((c) => c.status === 'revealed')?.revealedReport as TrackBReport | undefined;

  // Compute recommended reconciled amount
  const recommendedAmount = revealedTrackB
    ? revealedTrackB.proposedNetSettlement
    : Math.max(0, (selectedClaim?.claimedAmount || 0) - 1500);

  const finalAuthorizedAmount = isAmountManuallyEdited ? manualAdjustedAmount : recommendedAmount;

  const handleAuthorize = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClaim) return;

    const decision: AdjudicationDecision = {
      adjudicatorId: 'ADJ-01',
      adjudicatorName: 'Dr. Gregory Vance, Senior Loss Adjudication Council',
      decidedAt: new Date().toISOString(),
      tracksReconciled: true,
      bothTracksAligned: Boolean(revealedTrackA && revealedTrackB),
      trackAFinding: revealedTrackA ? revealedTrackA.findingsSummary : 'Manual forensics audit passed',
      trackBFinding: revealedTrackB ? revealedTrackB.reasonedAssessment : 'Contractual terms verified',
      reconciledAmount: finalAuthorizedAmount,
      deductibleApplied: 1500,
      depreciationDeducted: revealedTrackB ? revealedTrackB.depreciationAdjustment : 0,
      payoutChannel,
      repairVendorName: payoutChannel === 'direct_repair_facility' ? repairVendorName : undefined,
      reasoning: adjudicatorNotes,
      factualCorrections: [],
      decisionOutcome: 'authorised',
    };

    onAuthorizeClaim(selectedClaim.id, decision);
  };

  const handleResolveAppealSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClaim) return;
    onResolveAppeal(selectedClaim.id, appealDetermination, appealRevisedAmount, appealDeliberationNotes);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="border-b border-[#B89355]/20 pb-4">
        <span className="text-xs font-mono uppercase tracking-wider text-[#B89355] font-semibold">
          Adjudication Operations
        </span>
        <h2 className="font-serif-brand text-2xl font-bold text-white tracking-tight">
          Two-Track Claim Reconciliation & Sovereign Adjudication
        </h2>
        <p className="text-xs text-slate-400 mt-1 max-w-3xl">
          Track A examines what can be proven empirically. Track B applies contractual policy law. The adjudicator evaluates independent corroboration, resolves discrepancies, and authorizes disbursements.
        </p>
      </div>

      {/* Claim Selector Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        <span className="text-xs font-mono text-[#B89355] uppercase font-semibold whitespace-nowrap">
          Select Docket:
        </span>
        {claims.map((c) => (
          <button
            key={c.id}
            onClick={() => {
              setSelectedClaimId(c.id);
              setIsAmountManuallyEdited(false);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-colors whitespace-nowrap cursor-pointer ${
              selectedClaim?.id === c.id
                ? 'bg-[#B89355] text-[#070D18] font-bold shadow-sm'
                : 'bg-[#0A1424] text-slate-300 hover:text-white border border-[#B89355]/20'
            }`}
          >
            {c.claimNumber} ({c.state})
          </button>
        ))}
      </div>

      {selectedClaim && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Claim Summary & Track Comparison Matrix (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Incident Summary Card */}
            <div className="bg-[#0A1424] border border-[#B89355]/20 rounded-xl p-5 space-y-3 shadow-lg">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-slate-400">
                  Equipment: <strong className="text-white font-serif-brand">{selectedClaim.equipmentName}</strong>
                </span>
                <span className="text-xs font-mono text-[#DEC58B] font-bold">
                  Claimed: €{selectedClaim.claimedAmount.toLocaleString()}
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {selectedClaim.incidentDescription}
              </p>
              <div className="flex flex-wrap items-center gap-3 text-[11px] font-mono text-slate-400 pt-2 border-t border-[#B89355]/15">
                <span>Serial: {selectedClaim.equipmentSerial}</span>
                <span aria-hidden="true" className="text-[#B89355]">·</span>
                <span>Policy: {selectedClaim.policyVersion}</span>
                <span aria-hidden="true" className="text-[#B89355]">·</span>
                <span>State: <strong className="text-[#DEC58B] capitalize">{selectedClaim.state.replace('_', ' ')}</strong></span>
              </div>
            </div>

            {/* Side-by-Side Track Reconciliation */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-serif-brand text-sm font-bold text-white flex items-center gap-2">
                  <GitMerge className="w-4 h-4 text-[#B89355]" />
                  Two-Track Corroboration Comparison
                </h3>
                <span className="text-[11px] font-mono text-emerald-400 font-semibold">
                  Independent Assignees
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Track A: Forensics Box */}
                <div className="bg-[#0A1424] border border-[#B89355]/20 rounded-xl p-4 space-y-3 text-xs shadow-md">
                  <div className="flex items-center justify-between border-b border-[#B89355]/20 pb-2">
                    <span className="font-bold text-white font-serif-brand">Track A: Evidence Forensics</span>
                    <span className="font-mono text-[10px] text-[#B89355]">Hardware & Telemetry</span>
                  </div>

                  {revealedTrackA ? (
                    <div className="space-y-2.5">
                      <div className="space-y-1 font-mono text-[11px]">
                        <div className="flex justify-between">
                          <span className="text-slate-400">File & EXIF Integrity:</span>
                          <span className="text-emerald-400 font-semibold">
                            {revealedTrackA.fileIntegrityVerified ? '✓ Verified' : '✗ Failed'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Equipment Serial Match:</span>
                          <span className="text-emerald-400 font-semibold">
                            {revealedTrackA.equipmentIdentityMatch ? '✓ Verified' : '✗ Failed'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Duplicate Check:</span>
                          <span className="text-emerald-400 font-semibold">
                            {!revealedTrackA.duplicateSubmissionDetected ? '✓ No Duplicates' : '⚠ Flagged'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Uncertainty Factor:</span>
                          <span className="text-[#DEC58B] font-bold">{revealedTrackA.uncertaintyFactor.toFixed(2)}</span>
                        </div>
                      </div>

                      <div className="bg-[#060B14] p-2.5 rounded-lg text-[11px] text-slate-300 border border-[#B89355]/15">
                        <p>{revealedTrackA.findingsSummary}</p>
                      </div>

                      <div className="text-[10px] font-mono text-slate-500">
                        Status: <strong className="text-emerald-400 uppercase font-bold">{revealedTrackA.recommendation}</strong>
                      </div>
                    </div>
                  ) : (
                    <div className="py-6 text-center text-slate-500 font-mono text-[11px]">
                      Track A assessment is still sealed under commit-reveal or in progress.
                    </div>
                  )}
                </div>

                {/* Track B: Coverage Box */}
                <div className="bg-[#0A1424] border border-[#B89355]/20 rounded-xl p-4 space-y-3 text-xs shadow-md">
                  <div className="flex items-center justify-between border-b border-[#B89355]/20 pb-2">
                    <span className="font-bold text-white font-serif-brand">Track B: Contractual Coverage</span>
                    <span className="font-mono text-[10px] text-[#B89355]">Policy Law & Valuation</span>
                  </div>

                  {revealedTrackB ? (
                    <div className="space-y-2.5">
                      <div className="space-y-1 font-mono text-[11px]">
                        <div className="flex justify-between">
                          <span className="text-slate-400">Policy in Force:</span>
                          <span className="text-emerald-400 font-semibold">
                            {revealedTrackB.policyInForce ? '✓ Verified' : '✗ Lapsed'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Covered Peril:</span>
                          <span className="text-emerald-400 font-semibold">
                            {revealedTrackB.perilCovered ? '✓ Covered' : '✗ Excluded'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Deductible Applied:</span>
                          <span className="text-slate-300">-€{revealedTrackB.applicableDeductible}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Depreciation:</span>
                          <span className="text-slate-300">-€{revealedTrackB.depreciationAdjustment}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Salvage Recovery:</span>
                          <span className="text-slate-300">-€{revealedTrackB.salvageRecoveryOffset}</span>
                        </div>
                      </div>

                      <div className="bg-[#060B14] p-2.5 rounded-lg text-[11px] text-slate-300 border border-[#B89355]/15">
                        <p>{revealedTrackB.reasonedAssessment}</p>
                      </div>

                      <div className="flex items-center justify-between text-[11px] font-mono">
                        <span className="text-slate-400">Proposed Net:</span>
                        <span className="text-[#DEC58B] font-bold">
                          €{revealedTrackB.proposedNetSettlement.toLocaleString()}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="py-6 text-center text-slate-500 font-mono text-[11px]">
                      Track B assessment is still sealed under commit-reveal or in progress.
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Existing Adjudication Decision if completed */}
            {selectedClaim.adjudication && (
              <div className="bg-[#0A1424] border border-[#B89355]/40 rounded-xl p-5 space-y-3 shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <h4 className="font-serif-brand text-sm font-bold text-white">Prior Adjudication Authorization</h4>
                  </div>
                  <span className="font-mono text-xs text-[#DEC58B] font-bold">
                    Authorized: €{selectedClaim.adjudication.reconciledAmount.toLocaleString()}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {selectedClaim.adjudication.reasoning}
                </p>
                <div className="flex items-center gap-4 text-[11px] font-mono text-slate-400 pt-2 border-t border-[#B89355]/15">
                  <span>Adjudicator: {selectedClaim.adjudication.adjudicatorName}</span>
                  <span aria-hidden="true" className="text-[#B89355]">·</span>
                  <span>Channel: {selectedClaim.adjudication.payoutChannel}</span>
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Action Panel / Decision Builder (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            {/* If Claim is Appealed -> Appeal Resolution Panel */}
            {selectedClaim.state === 'appealed' && selectedClaim.appeal ? (
              <div className="bg-[#0A1424] border border-[#B89355]/35 rounded-2xl p-6 space-y-5 shadow-xl">
                <div className="flex items-center gap-2 border-b border-[#B89355]/20 pb-3">
                  <Gavel className="w-5 h-5 text-[#B89355]" />
                  <div>
                    <span className="text-xs font-mono text-[#B89355] font-semibold">Senior Arbitration Guild</span>
                    <h3 className="font-serif-brand text-base font-bold text-white">Adjudicate Open Appeal</h3>
                  </div>
                </div>

                <div className="bg-[#080E1A] p-4 rounded-xl text-xs space-y-2 border border-[#B89355]/20">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-400">Grounds:</span>
                    <span className="text-white capitalize font-semibold">{selectedClaim.appeal.grounds.replace('_', ' ')}</span>
                  </div>
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-400">Original Authorized:</span>
                    <span className="text-slate-300">€{selectedClaim.appeal.originalAuthorizedAmount.toLocaleString()}</span>
                  </div>
                  <p className="text-slate-300 pt-1 text-[11px] leading-relaxed">
                    <strong>Appellant Statement:</strong> {selectedClaim.appeal.appellantStatement}
                  </p>
                </div>

                <form onSubmit={handleResolveAppealSubmit} className="space-y-4 text-xs">
                  <div>
                    <label className="block text-slate-400 mb-1">Final Determination</label>
                    <select
                      value={appealDetermination}
                      onChange={(e) =>
                        setAppealDetermination(e.target.value as 'upheld' | 'modified' | 'reversed')
                      }
                      className="w-full bg-[#080E1A] border border-[#B89355]/25 rounded-lg px-3 py-2 text-white"
                    >
                      <option value="modified">Modified (Adjust Depreciation / Valuation Schedule)</option>
                      <option value="upheld">Upheld (Original Decision Confirmed Factually Correct)</option>
                      <option value="reversed">Reversed (Overturn Prior Determination)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Revised Settlement Amount (€)</label>
                    <input
                      type="number"
                      value={appealRevisedAmount}
                      onChange={(e) => setAppealRevisedAmount(Number(e.target.value))}
                      className="w-full bg-[#080E1A] border border-[#B89355]/25 rounded-lg px-3 py-2 text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Deliberation Rationale</label>
                    <textarea
                      rows={4}
                      value={appealDeliberationNotes}
                      onChange={(e) => setAppealDeliberationNotes(e.target.value)}
                      className="w-full bg-[#080E1A] border border-[#B89355]/25 rounded-lg p-2.5 text-white leading-relaxed"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 text-xs font-bold text-[#070D18] bg-[#B89355] hover:bg-[#CBA768] rounded transition-colors shadow-md cursor-pointer"
                  >
                    Execute Binding Appeal Judgment
                  </button>
                </form>
              </div>
            ) : (
              /* Standard First-Instance Adjudication Form */
              <div className="bg-[#0A1424] border border-[#B89355]/25 rounded-2xl p-6 space-y-5 shadow-xl">
                <div className="border-b border-[#B89355]/20 pb-3">
                  <span className="text-xs font-mono text-[#B89355] font-semibold">Adjudicator Council</span>
                  <h3 className="font-serif-brand text-base font-bold text-white">Reconcile & Authorize Settlement</h3>
                </div>

                <form onSubmit={handleAuthorize} className="space-y-4 text-xs">
                  <div>
                    <label className="block text-slate-400 mb-1">
                      Authorized Net Settlement (€)
                    </label>
                    <input
                      type="number"
                      value={finalAuthorizedAmount}
                      onChange={(e) => {
                        setManualAdjustedAmount(Number(e.target.value));
                        setIsAmountManuallyEdited(true);
                      }}
                      className="w-full bg-[#080E1A] border border-[#B89355]/25 rounded-lg px-3 py-2 text-white font-mono text-sm font-bold"
                    />
                    <span className="text-[10px] text-slate-500 font-mono mt-0.5 block">
                      Recommended from Track B: €{recommendedAmount.toLocaleString()}
                    </span>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Disbursement Channel</label>
                    <select
                      value={payoutChannel}
                      onChange={(e) =>
                        setPayoutChannel(
                          e.target.value as 'direct_repair_facility' | 'claimant_reimbursement'
                        )
                      }
                      className="w-full bg-[#080E1A] border border-[#B89355]/25 rounded-lg px-3 py-2 text-white"
                    >
                      <option value="direct_repair_facility">
                        Direct to Certified OEM Repair Facility (Anti-Moral Hazard)
                      </option>
                      <option value="claimant_reimbursement">
                        Direct Member Reimbursement (Requires Proof of Incurred Loss)
                      </option>
                    </select>
                  </div>

                  {payoutChannel === 'direct_repair_facility' && (
                    <div>
                      <label className="block text-slate-400 mb-1">Repair Facility Name</label>
                      <input
                        type="text"
                        value={repairVendorName}
                        onChange={(e) => setRepairVendorName(e.target.value)}
                        className="w-full bg-[#080E1A] border border-[#B89355]/25 rounded-lg px-3 py-2 text-white"
                      />
                    </div>
                  )}

                  <div>
                    <label className="block text-slate-400 mb-1">
                      Reasoned Adjudication Rationale
                    </label>
                    <textarea
                      rows={4}
                      value={adjudicatorNotes}
                      onChange={(e) => setAdjudicatorNotes(e.target.value)}
                      className="w-full bg-[#080E1A] border border-[#B89355]/25 rounded-lg p-2.5 text-white leading-relaxed"
                    />
                  </div>

                  <div className="bg-[#080E1A] p-3 rounded-lg text-[11px] text-slate-400 border border-[#B89355]/15">
                    Authorization will lock double-entry reserve holds and prepare settlement block for mining.
                  </div>

                  <button
                    type="submit"
                    disabled={selectedClaim.state === 'paid'}
                    className={`w-full py-2.5 text-xs font-bold rounded transition-colors shadow-sm cursor-pointer ${
                      selectedClaim.state === 'paid'
                        ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        : 'text-[#070D18] bg-[#B89355] hover:bg-[#CBA768]'
                    }`}
                  >
                    {selectedClaim.state === 'paid'
                      ? 'Claim Already Settled & Paid'
                      : 'Authorize Payment & Mine Settlement'}
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
