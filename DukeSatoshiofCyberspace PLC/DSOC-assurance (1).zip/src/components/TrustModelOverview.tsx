/**
 * Duke Satoshi of Cyberspace Insurance - Trust Model Overview
 * Developed by Aureom.AI | RhinoMutual Engine
 */

import React from 'react';
import { 
  ShieldCheck, 
  FileCheck2, 
  Scale, 
  Database, 
  ArrowRight, 
  Lock, 
  Layers, 
  AlertTriangle,
  EyeOff,
  GitBranch,
  Coins,
  Crown
} from 'lucide-react';

interface TrustModelProps {
  onNavigate: (tab: string) => void;
  onOpenTour: () => void;
}

export const TrustModelOverview: React.FC<TrustModelProps> = ({ onNavigate, onOpenTour }) => {
  return (
    <div className="space-y-12">
      {/* Hero Visual Section featuring the Duke Satoshi of Cyberspace Crest */}
      <div className="relative rounded-2xl overflow-hidden border border-[#B89355]/30 bg-gradient-to-br from-[#070D18] via-[#0A1424] to-[#0E1D33] shadow-2xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch min-h-[420px]">
          {/* Left Text Zone */}
          <div className="lg:col-span-7 p-8 lg:p-12 flex flex-col justify-between z-10 space-y-6">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#070D18]/80 border border-[#B89355]/40 text-xs text-[#DEC58B] font-mono tracking-widest uppercase">
                <Crown className="w-3.5 h-3.5 text-[#B89355]" />
                <span>Duke Satoshi Sovereign Syndicate</span>
                <span aria-hidden="true">·</span>
                <span>Cyberspace Mutual Risk Protocol</span>
              </div>
              
              <div className="space-y-1">
                <h1 className="font-serif-brand text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
                  DUKE SATOSHI
                </h1>
                <div className="font-serif-brand text-xl sm:text-2xl text-[#DEC58B] font-medium tracking-widest uppercase">
                  OF CYBERSPACE INSURANCE
                </div>
              </div>

              <div className="w-24 h-0.5 bg-gradient-to-r from-[#B89355] to-transparent" />

              <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
                Reinventing mutual risk-pooling for high-value enterprise hardware and sovereign compute clusters. Combining bonded validator performance stakes, double-blind commit-reveal forensic analysis, and immutable double-entry ledger settlement.
              </p>
            </div>

            <div className="pt-6 flex flex-wrap items-center gap-4">
              <button
                onClick={onOpenTour}
                className="px-5 py-2.5 text-xs font-bold text-[#070D18] bg-[#B89355] hover:bg-[#CBA768] rounded transition-all shadow-md cursor-pointer tracking-wider uppercase font-mono"
              >
                Launch Sovereign Walkthrough
              </button>
              <button
                onClick={() => onNavigate('adjudication')}
                className="px-5 py-2.5 text-xs font-semibold text-slate-200 bg-[#0F1E36] hover:bg-[#1C365C] border border-[#B89355]/30 rounded transition-colors cursor-pointer"
              >
                Inspect 2-Track Adjudication
              </button>
            </div>
          </div>

          {/* Right Image Media Zone displaying Duke Satoshi Crest */}
          <div className="lg:col-span-5 relative bg-[#FAF8F2] flex items-center justify-center p-8 lg:p-12 overflow-hidden">
            <div className="relative z-10 w-full max-w-sm flex flex-col items-center justify-center space-y-4">
              <img
                src="/public/assets/aistudio/9c80afcd-f966-4358-9148-04f8088a21bc_de7dbe40.png"
                alt="Duke Satoshi of Cyberspace Insurance Crest"
                className="w-64 sm:w-72 h-auto object-contain drop-shadow-xl hover:scale-[1.02] transition-transform duration-300"
              />
              <div className="text-center font-mono text-[10px] tracking-widest uppercase text-[#0A1424] opacity-75 font-semibold">
                Sovereign Cybernetic Assurance · Est. 2026
              </div>
            </div>
            {/* Subtle background radial glow */}
            <div className="absolute inset-0 bg-radial from-white/60 to-transparent pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Trust Model Constitution: Separation of Four Functions */}
      <section className="space-y-6">
        <div>
          <span className="text-xs font-mono uppercase tracking-wider text-[#B89355]">
            01. Sovereign Trust Architecture
          </span>
          <h2 className="font-serif-brand text-2xl font-bold text-white tracking-tight mt-1">
            Separation of Four Independent Governance Functions
          </h2>
          <p className="text-sm text-slate-400 mt-1 max-w-3xl">
            Proof-of-stake consensus establishes agreement about state records; it does not establish whether an industrial accident occurred. Duke Satoshi strictly decouples physical forensics from contractual law and ledger settlement.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Function 1 */}
          <div className="bg-[#0A1424] border border-[#B89355]/20 rounded-xl p-6 space-y-4 hover:border-[#B89355]/50 transition-colors shadow-lg">
            <div className="w-10 h-10 rounded-lg bg-[#0F1E36] border border-[#B89355]/30 flex items-center justify-center text-[#DEC58B]">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] text-[#B89355] font-mono uppercase tracking-wider">Function I</span>
              <h3 className="text-base font-serif-brand font-bold text-white">Policy Administration</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Determines contractual terms: in-force dates, covered perils, waiting periods, deductibles, and depreciation formulas. Locked immutably via canonical SHA-256 policy wording hashes.
            </p>
            <div className="text-[11px] font-mono text-slate-400 pt-2 border-t border-[#B89355]/15">
              Output: Immutable Contract Wording Hash
            </div>
          </div>

          {/* Function 2 */}
          <div className="bg-[#0A1424] border border-[#B89355]/20 rounded-xl p-6 space-y-4 hover:border-[#B89355]/50 transition-colors shadow-lg">
            <div className="w-10 h-10 rounded-lg bg-[#0F1E36] border border-[#B89355]/30 flex items-center justify-center text-[#DEC58B]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] text-[#B89355] font-mono uppercase tracking-wider">Function II</span>
              <h3 className="text-base font-serif-brand font-bold text-white">Evidence Forensics</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Examines what can be empirically established: cryptographic image hashes, EXIF sensors, machine telemetry, serial cross-checks, quote authenticity, and duplicate invoice detection.
            </p>
            <div className="text-[11px] font-mono text-slate-400 pt-2 border-t border-[#B89355]/15">
              Output: Track A Integrity Findings & Uncertainty
            </div>
          </div>

          {/* Function 3 */}
          <div className="bg-[#0A1424] border border-[#B89355]/20 rounded-xl p-6 space-y-4 hover:border-[#B89355]/50 transition-colors shadow-lg">
            <div className="w-10 h-10 rounded-lg bg-[#0F1E36] border border-[#B89355]/30 flex items-center justify-center text-[#DEC58B]">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] text-[#B89355] font-mono uppercase tracking-wider">Function III</span>
              <h3 className="text-base font-serif-brand font-bold text-white">Claim Adjudication</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Applies policy terms to supported facts. Reconciles Track A and Track B, calculates straight-line depreciation and salvage credits, and produces auditable reasoned decisions.
            </p>
            <div className="text-[11px] font-mono text-slate-400 pt-2 border-t border-[#B89355]/15">
              Output: Reconciled Net Settlement Authorization
            </div>
          </div>

          {/* Function 4 */}
          <div className="bg-[#0A1424] border border-[#B89355]/20 rounded-xl p-6 space-y-4 hover:border-[#B89355]/50 transition-colors shadow-lg">
            <div className="w-10 h-10 rounded-lg bg-[#0F1E36] border border-[#B89355]/30 flex items-center justify-center text-[#DEC58B]">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] text-[#B89355] font-mono uppercase tracking-wider">Function IV</span>
              <h3 className="text-base font-serif-brand font-bold text-white">Ledger Consensus</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Records authorised state transitions on an append-only double-entry ledger. Cryptographic hash chains ensure immutability without speculative volatile token economies.
            </p>
            <div className="text-[11px] font-mono text-slate-400 pt-2 border-t border-[#B89355]/15">
              Output: Double-Entry Block Commitments
            </div>
          </div>
        </div>
      </section>

      {/* Double Proof & Double-Blind Architecture */}
      <section className="bg-[#0A1424] border border-[#B89355]/25 rounded-2xl p-8 space-y-6 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-[#0F1E36] border border-[#B89355]/40 flex items-center justify-center">
            <Crown className="w-4 h-4 text-[#B89355]" />
          </div>
          <div>
            <span className="text-xs font-mono uppercase tracking-wider text-[#B89355]">
              02. Sovereign Protocols
            </span>
            <h2 className="font-serif-brand text-xl font-bold text-white tracking-tight">
              Operational Definitions: Double Proof & Double Blind
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-2">
          {/* Double Proof */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <GitBranch className="w-4 h-4 text-[#DEC58B]" />
              <h3 className="font-serif-brand">Two Independent Validation Tracks ("Double Proof")</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              A single false invoice can trick an adjuster; two approvals based on the same false document do not represent independent corroboration. Duke Satoshi splits review into two separately reported tracks assigned to distinct validator entities:
            </p>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <span className="text-[#DEC58B] font-mono font-bold">A.</span>
                <span><strong>Track A (Forensics):</strong> Analyzes file SHA-256 hashes, device EXIF, serial markings, duplicate claims cross-check, and quote tampering.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#DEC58B] font-mono font-bold">B.</span>
                <span><strong>Track B (Contractual Coverage):</strong> Analyzes policy wording in force, peril classifications, exclusion triggers, deductible subtractions, and depreciation schedules.</span>
              </li>
            </ul>
          </div>

          {/* Double Blind */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <EyeOff className="w-4 h-4 text-[#DEC58B]" />
              <h3 className="font-serif-brand">Double-Blind Commit-Reveal Protocol</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Prevents herd mentality, vote copying, and claimant intimidation:
            </p>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <span className="text-[#DEC58B] font-mono font-bold">1.</span>
                <span><strong>Blinded Evidence Packets:</strong> Names, logos, emails, and tax IDs are masked before reviewer dispatch while preserving diagnostic telemetry.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#DEC58B] font-mono font-bold">2.</span>
                <span><strong>Commitment Stage:</strong> Reviewers submit <code className="font-mono text-[#DEC58B]">SHA256(report + nonce)</code> before the deadline.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#DEC58B] font-mono font-bold">3.</span>
                <span><strong>Reveal Stage:</strong> Nonces are published after commitments close. An escrow recovery policy prevents non-reveal gridlock.</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Moral Hazard Hypothesis Table */}
      <section className="space-y-4">
        <div>
          <span className="text-xs font-mono uppercase tracking-wider text-[#B89355]">
            03. Sovereign Game Theory
          </span>
          <h2 className="font-serif-brand text-xl font-bold text-white tracking-tight mt-1">
            Multi-Party Moral Hazard & Adverse Incentives Matrix
          </h2>
          <p className="text-xs text-slate-400">
            Moral hazard is an empirical hypothesis to measure and counter, not a problem automatically solved by staking or blockchain.
          </p>
        </div>

        <div className="overflow-x-auto border border-[#B89355]/20 rounded-xl shadow-lg">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-[#0A1424] text-[#DEC58B] font-mono text-[11px] border-b border-[#B89355]/25">
              <tr>
                <th className="py-3 px-4 font-serif-brand">Stakeholder</th>
                <th className="py-3 px-4">Adverse Incentive / Moral Hazard</th>
                <th className="py-3 px-4">Duke Satoshi Counter-Mechanism</th>
                <th className="py-3 px-4">Observable Metric</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#B89355]/15 bg-[#080E1A]">
              <tr className="hover:bg-white/[0.02]">
                <td className="py-3.5 px-4 font-semibold text-white font-serif-brand">Claimant</td>
                <td className="py-3.5 px-4 text-slate-400">Exaggerating loss, inflating repair invoices, submitting pre-existing damage.</td>
                <td className="py-3.5 px-4">Pre-coverage registration proof, Track A serial forensic check, direct repairer disbursement.</td>
                <td className="py-3.5 px-4 font-mono text-emerald-400 font-semibold">Fraud Paid &lt; 2.5%</td>
              </tr>
              <tr className="hover:bg-white/[0.02]">
                <td className="py-3.5 px-4 font-semibold text-white font-serif-brand">Validator</td>
                <td className="py-3.5 px-4 text-slate-400">Rubber-stamping to harvest fees quickly, colluding with friendly claimants.</td>
                <td className="py-3.5 px-4">Fixed fee (€180) independent of verdict, bonded stake at risk for demonstrable fraud, random audits.</td>
                <td className="py-3.5 px-4 font-mono text-emerald-400 font-semibold">Collusion Loss &lt; 1.0%</td>
              </tr>
              <tr className="hover:bg-white/[0.02]">
                <td className="py-3.5 px-4 font-semibold text-white font-serif-brand">Pool Operator</td>
                <td className="py-3.5 px-4 text-slate-400">Suppressing payouts to artificially preserve reserves or maximize fee take.</td>
                <td className="py-3.5 px-4">Operator cannot vote on claims; transparent double-entry reserves and independent appeal escalation.</td>
                <td className="py-3.5 px-4 font-mono text-emerald-400 font-semibold">Legit Denied &lt; 3.0%</td>
              </tr>
              <tr className="hover:bg-white/[0.02]">
                <td className="py-3.5 px-4 font-semibold text-white font-serif-brand">Repair Facility</td>
                <td className="py-3.5 px-4 text-slate-400">Inflating spare parts pricing or replacing undamaged sub-assemblies.</td>
                <td className="py-3.5 px-4">Track A quote cross-check against OEM parts catalogs; salvage core return credits.</td>
                <td className="py-3.5 px-4 font-mono text-emerald-400 font-semibold">Salvage Recovery €4.2k+</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
