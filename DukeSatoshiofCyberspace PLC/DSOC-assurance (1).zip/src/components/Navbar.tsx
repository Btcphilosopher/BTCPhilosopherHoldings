/**
 * Duke Satoshi of Cyberspace Insurance - Top Bar Navigation
 * Developed by Aureom.AI | RhinoMutual Engine
 */

import React from 'react';
import { UserRole } from '../types';
import { 
  Shield, 
  Crown, 
  Lock, 
  Compass
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  activeRole: UserRole;
  setActiveRole: (role: UserRole) => void;
  onOpenGuidedTour: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  activeRole,
  setActiveRole,
  onOpenGuidedTour,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#070D18]/95 backdrop-blur-md border-b border-[#B89355]/20 text-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-18">
          {/* Zone 1: Single Brand Zone with Duke Satoshi Emblem & Typography */}
          <div className="flex items-center gap-3.5 shrink-0">
            <button
              onClick={() => setCurrentTab('overview')}
              className="flex items-center gap-3 text-left group transition-all cursor-pointer"
            >
              <div className="w-10 h-10 rounded bg-[#0A1424] border border-[#B89355]/40 flex items-center justify-center shadow-md p-1 overflow-hidden group-hover:border-[#B89355] transition-colors">
                <img
                  src="/public/assets/aistudio/9c80afcd-f966-4358-9148-04f8088a21bc_de7dbe40.png"
                  alt="Duke Satoshi of Cyberspace Emblem"
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <div className="font-serif-brand text-[15px] sm:text-base font-extrabold tracking-wider text-white group-hover:text-[#DEC58B] transition-colors leading-tight">
                  DUKE SATOSHI
                </div>
                <div className="text-[9px] tracking-[0.24em] uppercase text-[#B89355] font-semibold -mt-0.5">
                  OF CYBERSPACE INSURANCE
                </div>
              </div>
            </button>
          </div>

          {/* Zone 2: Navigation Links (single-line, clean unboxed with hover underlines) */}
          <nav className="hidden lg:flex items-center gap-6 text-xs font-medium text-slate-300">
            <button
              onClick={() => setCurrentTab('overview')}
              className={`hover:text-[#DEC58B] transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                currentTab === 'overview' ? 'text-[#DEC58B] font-semibold border-b-2 border-[#B89355]' : ''
              }`}
            >
              Trust Model
            </button>
            <button
              onClick={() => setCurrentTab('member')}
              className={`hover:text-[#DEC58B] transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                currentTab === 'member' ? 'text-[#DEC58B] font-semibold border-b-2 border-[#B89355]' : ''
              }`}
            >
              Member Portal
            </button>
            <button
              onClick={() => setCurrentTab('validator')}
              className={`hover:text-[#DEC58B] transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                currentTab === 'validator' ? 'text-[#DEC58B] font-semibold border-b-2 border-[#B89355]' : ''
              }`}
            >
              Validator Network
            </button>
            <button
              onClick={() => setCurrentTab('pools')}
              className={`hover:text-[#DEC58B] transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                currentTab === 'pools' ? 'text-[#DEC58B] font-semibold border-b-2 border-[#B89355]' : ''
              }`}
            >
              Pool Reserves
            </button>
            <button
              onClick={() => setCurrentTab('adjudication')}
              className={`hover:text-[#DEC58B] transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                currentTab === 'adjudication' ? 'text-[#DEC58B] font-semibold border-b-2 border-[#B89355]' : ''
              }`}
            >
              2-Track Adjudication
            </button>
            <button
              onClick={() => setCurrentTab('ledger')}
              className={`hover:text-[#DEC58B] transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                currentTab === 'ledger' ? 'text-[#DEC58B] font-semibold border-b-2 border-[#B89355]' : ''
              }`}
            >
              Audit Ledger & ZK
            </button>
            <button
              onClick={() => setCurrentTab('simulation')}
              className={`hover:text-[#DEC58B] transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                currentTab === 'simulation' ? 'text-[#DEC58B] font-semibold border-b-2 border-[#B89355]' : ''
              }`}
            >
              Simulation Lab
            </button>
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenGuidedTour}
              className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold text-[#070D18] bg-[#B89355] hover:bg-[#CBA768] rounded transition-colors whitespace-nowrap shadow-sm cursor-pointer"
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Guided Demo Tour</span>
            </button>
          </div>
        </div>

        {/* Secondary Role Persona Bar */}
        <div className="border-t border-[#B89355]/15 py-2 flex flex-wrap items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase tracking-wider text-[#B89355] font-mono font-semibold">
              Active Persona:
            </span>
            <div className="inline-flex rounded bg-[#0A1424] p-0.5 border border-[#B89355]/25">
              {(['member', 'validator', 'operator', 'adjudicator', 'auditor'] as UserRole[]).map(
                (role) => (
                  <button
                    key={role}
                    onClick={() => {
                      setActiveRole(role);
                      if (role === 'member') setCurrentTab('member');
                      if (role === 'validator') setCurrentTab('validator');
                      if (role === 'operator') setCurrentTab('pools');
                      if (role === 'adjudicator') setCurrentTab('adjudication');
                      if (role === 'auditor') setCurrentTab('ledger');
                    }}
                    className={`px-2.5 py-1 rounded text-[11px] font-medium capitalize transition-colors cursor-pointer ${
                      activeRole === role
                        ? 'bg-[#1C365C] text-[#F5EFE4] shadow-xs font-semibold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {role}
                  </button>
                )
              )}
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-4 font-mono text-[11px] text-slate-400">
            <span className="flex items-center gap-1.5 text-[#DEC58B]">
              <Lock className="w-3 h-3 text-[#B89355]" />
              Double-Blind Sovereign Protocol
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>Policy: v1.2-2026.1</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>Ledger: Block #1044</span>
          </div>
        </div>
      </div>
    </header>
  );
};
