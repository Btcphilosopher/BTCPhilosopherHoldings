/**
 * Duke Satoshi of Cyberspace Insurance - Validator Network Portal
 * Developed by Aureom.AI | RhinoMutual Engine
 */

import React, { useState } from 'react';
import { 
  Claim, 
  ReviewCommitment, 
  TrackAReport, 
  TrackBReport, 
  Validator 
} from '../types';
import { createCommitment, syncSha256, verifyCommitment } from '../services/cryptoLedger';
import { 
  Shield, 
  Lock, 
  Unlock, 
  Key, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  FileSearch, 
  Sliders, 
  Database,
  EyeOff,
  UserCheck,
  Crown
} from 'lucide-react';

interface ValidatorPortalProps {
  validators: Validator[];
  claims: Claim[];
  onSubmitCommitment: (claimId: string, commitment: ReviewCommitment) => void;
  onRevealCommitment: (claimId: string, validatorId: string, nonce: string) => void;
  onTriggerRevealEscrow: (claimId: string, validatorId: string) => void;
}

export const ValidatorPortal: React.FC<ValidatorPortalProps> = ({
  validators,
  claims,
  onSubmitCommitment,
  onRevealCommitment,
  onTriggerRevealEscrow,
}) => {
  const [selectedValidator, setSelectedValidator] = useState<Validator>(validators[0]);
  const [activeReviewClaim, setActiveReviewClaim] = useState<Claim | null>(null);
  const [reviewTrack, setReviewTrack] = useState<'track_a' | 'track_b'>('track_a');

  // Interactive Commit Generator State
  const [nonceInput, setNonceInput] = useState<string>('rnd_nonce_' + Math.floor(10000 + Math.random() * 90000));
  
  // Track A Form State
  const [fileIntegrity, setFileIntegrity] = useState(true);
  const [serialMatch, setSerialMatch] = useState(true);
  const [chronologyCheck, setChronologyCheck] = useState(true);
  const [duplicateCheck, setDuplicateCheck] = useState(false);
  const [quoteAuthentic, setQuoteAuthentic] = useState(true);
  const [uncertaintyFactor, setUncertaintyFactor] = useState(0.05);
  const [trackAFindings, setTrackAFindings] = useState(
    'Hardware telemetry timestamps correlate with CNC inverter fault registers. Serial plaque casting matches pool registry. Vendor repair invoice verified authentic with authorized OEM service branch.'
  );

  // Track B Form State
  const [policyInForce, setPolicyInForce] = useState(true);
  const [perilCovered, setPerilCovered] = useState(true);
  const [exclusionTriggered, setExclusionTriggered] = useState(false);
  const [depreciationAmount, setDepreciationAmount] = useState(2400);
  const [salvageOffset, setSalvageOffset] = useState(1200);
  const [trackBReasoning, setTrackBReasoning] = useState(
    'Incident qualifies under Clause 4.1 Sudden Electrical Surge. Applied contractual deductible of €1,500. Straight-line 15% depreciation deducted on consumable spindle component. Core exchange salvage credit offset applied.'
  );

  // Reveal state
  const [revealNonceInput, setRevealNonceInput] = useState<{ [key: string]: string }>({});

  const claimsPendingReview = claims.filter(
    (c) => c.state === 'review_assigned' || c.state === 'committed' || c.state === 'revealed'
  );

  const handleGenerateCommitment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeReviewClaim) return;

    let report: TrackAReport | TrackBReport;
    if (reviewTrack === 'track_a') {
      report = {
        trackType: 'track_a_evidence',
        validatorId: selectedValidator.id,
        fileIntegrityVerified: fileIntegrity,
        equipmentIdentityMatch: serialMatch,
        chronologyConsistent: chronologyCheck,
        duplicateSubmissionDetected: duplicateCheck,
        vendorQuoteAuthentic: quoteAuthentic,
        quoteAuthenticityScore: 98,
        uncertaintyFactor,
        discrepancies: duplicateCheck ? ['Duplicate invoice hash flagged'] : [],
        findingsSummary: trackAFindings,
        recommendation: fileIntegrity && serialMatch && !duplicateCheck ? 'verified' : 'suspect',
      };
    } else {
      const netPayout = Math.max(
        0,
        activeReviewClaim.claimedAmount - 1500 - depreciationAmount - salvageOffset
      );
      report = {
        trackType: 'track_b_coverage',
        validatorId: selectedValidator.id,
        policyInForce,
        perilCovered,
        exclusionTriggered,
        claimedLossAmount: activeReviewClaim.claimedAmount,
        applicableDeductible: 1500,
        depreciationAdjustment: depreciationAmount,
        salvageRecoveryOffset: salvageOffset,
        proposedNetSettlement: netPayout,
        settlementOption: 'direct_repair_facility',
        reasonedAssessment: trackBReasoning,
        recommendation: policyInForce && perilCovered && !exclusionTriggered ? 'eligible' : 'ineligible',
      };
    }

    const commitmentHash = createCommitment(report, nonceInput);

    const newCommitment: ReviewCommitment = {
      validatorId: selectedValidator.id,
      validatorAlias: `Blinded_Validator_${selectedValidator.id.replace('VAL-', '')}`,
      track: reviewTrack,
      commitmentHash,
      committedAt: new Date().toISOString(),
      revealDeadline: new Date(Date.now() + 48 * 3600 * 1000).toISOString(),
      nonce: nonceInput,
      revealedReport: report,
      status: 'committed',
      hashMatches: true,
    };

    onSubmitCommitment(activeReviewClaim.id, newCommitment);
    setActiveReviewClaim(null);
  };

  const handleReveal = (claimId: string, commitment: ReviewCommitment) => {
    const nonce = revealNonceInput[`${claimId}-${commitment.validatorId}`] || commitment.nonce || '';
    onRevealCommitment(claimId, commitment.validatorId, nonce);
  };

  return (
    <div className="space-y-10">
      {/* Header */}
      <div className="border-b border-[#B89355]/20 pb-4">
        <span className="text-xs font-mono uppercase tracking-wider text-[#B89355] font-semibold">
          Validator Operations
        </span>
        <h2 className="font-serif-brand text-2xl font-bold text-white tracking-tight">
          Stake-Backed Validator Registry & Blinded Queue
        </h2>
        <p className="text-xs text-slate-400 mt-1 max-w-3xl">
          Reviewers bond performance stakes in segregated escrow. Review compensation is strictly fixed (€180 per review) regardless of verdict to eliminate denial-bias incentives.
        </p>
      </div>

      {/* Validator Registry Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-serif-brand text-sm font-bold text-white">Bonded Validator Guild (7 Active Entities)</h3>
          <span className="text-xs font-mono text-[#DEC58B]">Concentration Cap: Max 15.0% Voting Weight</span>
        </div>

        <div className="overflow-x-auto border border-[#B89355]/20 rounded-xl shadow-lg">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-[#0A1424] text-[#DEC58B] font-mono text-[11px] border-b border-[#B89355]/25">
              <tr>
                <th className="py-3 px-4 font-serif-brand">Validator Entity</th>
                <th className="py-3 px-4">Domain Expertise</th>
                <th className="py-3 px-4">Bonded Stake</th>
                <th className="py-3 px-4">Voting Share</th>
                <th className="py-3 px-4">Reviews Done</th>
                <th className="py-3 px-4">Consensus Alignment</th>
                <th className="py-3 px-4">Fixed Fee</th>
                <th className="py-3 px-4">Slashed Stake</th>
                <th className="py-3 px-4">Disclosed Conflicts</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#B89355]/15 bg-[#080E1A]">
              {validators.map((val) => (
                <tr
                  key={val.id}
                  onClick={() => setSelectedValidator(val)}
                  className={`hover:bg-white/[0.03] cursor-pointer transition-colors ${
                    selectedValidator.id === val.id ? 'bg-[#0F1E36]/80' : ''
                  }`}
                >
                  <td className="py-3 px-4 font-semibold text-white">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono text-[#B89355]">{val.id}</span>
                      <span>{val.orgName}</span>
                    </div>
                    <span className="block text-[11px] text-slate-400 font-normal">{val.leadAnalyst}</span>
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    {val.expertiseAreas.slice(0, 2).join(' · ')}
                  </td>
                  <td className="py-3 px-4 font-mono text-emerald-400 font-bold">
                    €{val.bondedStake.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-300">
                    {val.consensusStakeSharePct.toFixed(1)}%
                  </td>
                  <td className="py-3 px-4 font-mono">{val.completedReviews}</td>
                  <td className="py-3 px-4 font-mono text-[#DEC58B] font-semibold">{val.consensusAlignmentPct}%</td>
                  <td className="py-3 px-4 font-mono text-slate-300">€{val.fixedReviewFee}</td>
                  <td className="py-3 px-4 font-mono text-slate-400">
                    {val.slashedAmount === 0 ? '€0 (Clean)' : `€${val.slashedAmount}`}
                  </td>
                  <td className="py-3 px-4 text-slate-500 max-w-xs truncate">
                    {val.disclosedConflicts.length > 0 ? val.disclosedConflicts[0] : 'None recorded'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Anti-Slashing & Misconduct Constitution */}
      <section className="bg-[#0A1424] border border-[#B89355]/25 rounded-2xl p-6 space-y-4 shadow-xl">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-[#B89355]" />
          <h3 className="font-serif-brand text-base font-bold text-white">
            Objective Misconduct Slashing Constitution (§5.0)
          </h3>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed max-w-4xl">
          To protect decentralized independence, validators are <strong>never penalized or slashed</strong> for good-faith dissenting opinions or when an appeal overturns a prior decision. Bond exposure is restricted strictly to objectively verifiable bad-faith misconduct:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
          <div className="bg-[#080E1A] p-3.5 rounded-xl border border-[#B89355]/20 space-y-1">
            <span className="text-[#DEC58B] font-bold">1. Equivocation</span>
            <p className="text-slate-400 font-sans text-[11px]">
              Cryptographically signing two conflicting commitments for the same claim packet.
            </p>
          </div>
          <div className="bg-[#080E1A] p-3.5 rounded-xl border border-[#B89355]/20 space-y-1">
            <span className="text-[#DEC58B] font-bold">2. Unauthorized Disclosure</span>
            <p className="text-slate-400 font-sans text-[11px]">
              Leaking blinded claimant records or unredacted evidence hashes prior to adjudication.
            </p>
          </div>
          <div className="bg-[#080E1A] p-3.5 rounded-xl border border-[#B89355]/20 space-y-1">
            <span className="text-[#DEC58B] font-bold">3. Undisclosed Conflicts</span>
            <p className="text-slate-400 font-sans text-[11px]">
              Reviewing a claim involving a claimant entity in which the validator holds &gt; 0.5% equity.
            </p>
          </div>
          <div className="bg-[#080E1A] p-3.5 rounded-xl border border-[#B89355]/20 space-y-1">
            <span className="text-[#DEC58B] font-bold">4. Fabricated Records</span>
            <p className="text-slate-400 font-sans text-[11px]">
              Submitting simulated OEM calibration certs or forged laboratory test vouchers.
            </p>
          </div>
        </div>
      </section>

      {/* Active Blinded Claims Queue & Commit-Reveal Interface */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-serif-brand text-base font-bold text-white">
              Assigned Blinded Review Queue
            </h3>
            <p className="text-xs text-slate-400">
              Active validator: <span className="text-white font-semibold">{selectedValidator.orgName}</span>
            </p>
          </div>
          <span className="text-xs font-mono text-emerald-400 font-semibold">
            Escrow Reveal Protection Active
          </span>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {claimsPendingReview.map((claim) => (
            <div
              key={claim.id}
              className="bg-[#0A1424] border border-[#B89355]/20 rounded-xl p-5 space-y-4 shadow-lg"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-3 text-xs font-mono text-slate-400">
                    <span className="text-white font-bold text-sm font-serif-brand">{claim.claimNumber}</span>
                    <span aria-hidden="true" className="text-[#B89355]">·</span>
                    <span className="text-[#DEC58B] font-bold">Claimed: €{claim.claimedAmount.toLocaleString()}</span>
                    <span aria-hidden="true" className="text-[#B89355]">·</span>
                    <span className="text-slate-500">Equipment: {claim.equipmentSerial}</span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 max-w-3xl">
                    {claim.incidentDescription}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono px-2 py-1 rounded bg-[#0F1E36] text-[#DEC58B] border border-[#B89355]/30">
                    State: {claim.state}
                  </span>
                  {claim.state === 'review_assigned' && (
                    <button
                      onClick={() => setActiveReviewClaim(claim)}
                      className="px-3.5 py-1.5 text-xs font-bold text-[#070D18] bg-[#B89355] hover:bg-[#CBA768] rounded transition-colors cursor-pointer shadow-sm"
                    >
                      Generate Commitment
                    </button>
                  )}
                </div>
              </div>

              {/* Commitments Display */}
              <div className="bg-[#060B14] p-4 rounded-xl border border-[#B89355]/15 space-y-3 text-xs">
                <div className="flex items-center justify-between text-slate-400 font-mono text-[11px]">
                  <span className="text-[#DEC58B] font-semibold">Track A & Track B Commitments</span>
                  <span>Commit-Reveal Cryptographic Chain</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Track A Commitments */}
                  <div className="space-y-2">
                    <span className="text-[11px] font-semibold text-slate-300 font-mono">
                      Track A: Evidence Forensics
                    </span>
                    {claim.trackACommitments.length === 0 ? (
                      <p className="text-slate-600 font-mono text-[11px]">No commitment submitted yet</p>
                    ) : (
                      claim.trackACommitments.map((cmt, idx) => (
                        <div key={idx} className="bg-[#0A1424] p-3 rounded-lg border border-[#B89355]/20 space-y-2">
                          <div className="flex items-center justify-between font-mono text-[10px]">
                            <span className="text-[#DEC58B] font-semibold">{cmt.validatorAlias}</span>
                            <span className="text-slate-400">{cmt.status}</span>
                          </div>
                          <div className="font-mono text-[10px] text-slate-400 break-all">
                            Commitment Hash: {cmt.commitmentHash}
                          </div>
                          {cmt.status === 'committed' && (
                            <div className="pt-2 flex items-center gap-2">
                              <input
                                type="text"
                                placeholder="Enter secret nonce to reveal"
                                value={revealNonceInput[`${claim.id}-${cmt.validatorId}`] || ''}
                                onChange={(e) =>
                                  setRevealNonceInput({
                                    ...revealNonceInput,
                                    [`${claim.id}-${cmt.validatorId}`]: e.target.value,
                                  })
                                }
                                className="bg-[#060B14] border border-[#B89355]/25 rounded px-2 py-1 text-[11px] text-white font-mono flex-1"
                              />
                              <button
                                onClick={() => handleReveal(claim.id, cmt)}
                                className="px-2.5 py-1 text-[11px] font-bold text-[#070D18] bg-[#B89355] hover:bg-[#CBA768] rounded cursor-pointer whitespace-nowrap"
                              >
                                Reveal Assessment
                              </button>
                              <button
                                onClick={() => onTriggerRevealEscrow(claim.id, cmt.validatorId)}
                                title="If validator is offline, recover assessment via encrypted reveal escrow key"
                                className="px-2 py-1 text-[11px] font-medium text-slate-300 bg-[#0F1E36] hover:bg-[#1C365C] rounded cursor-pointer whitespace-nowrap"
                              >
                                Escrow Fallback
                              </button>
                            </div>
                          )}
                          {cmt.status === 'revealed' && cmt.revealedReport && (
                            <div className="bg-[#080E1A] p-2.5 rounded text-[11px] text-slate-300 space-y-1 border border-[#B89355]/20">
                              <span className="text-emerald-400 font-mono block font-semibold">
                                ✓ Hash verified against secret nonce
                              </span>
                              <p>{(cmt.revealedReport as TrackAReport).findingsSummary}</p>
                            </div>
                          )}
                        </div>
                      ))
                    )}
                  </div>

                  {/* Track B Commitments */}
                  <div className="space-y-2">
                    <span className="text-[11px] font-semibold text-slate-300 font-mono">
                      Track B: Contractual Coverage
                    </span>
                    {claim.trackBCommitments.length === 0 ? (
                      <p className="text-slate-600 font-mono text-[11px]">No commitment submitted yet</p>
                    ) : (
                      claim.trackBCommitments.map((cmt, idx) => (
                        <div key={idx} className="bg-[#0A1424] p-3 rounded-lg border border-[#B89355]/20 space-y-2">
                          <div className="flex items-center justify-between font-mono text-[10px]">
                            <span className="text-[#DEC58B] font-semibold">{cmt.validatorAlias}</span>
                            <span className="text-slate-400">{cmt.status}</span>
                          </div>
                          <div className="font-mono text-[10px] text-slate-400 break-all">
                            Commitment Hash: {cmt.commitmentHash}
                          </div>
                          {cmt.status === 'committed' && (
                            <div className="pt-2 flex items-center gap-2">
                              <input
                                type="text"
                                placeholder="Enter secret nonce to reveal"
                                value={revealNonceInput[`${claim.id}-${cmt.validatorId}`] || ''}
                                onChange={(e) =>
                                  setRevealNonceInput({
                                    ...revealNonceInput,
                                    [`${claim.id}-${cmt.validatorId}`]: e.target.value,
                                  })
                                }
                                className="bg-[#060B14] border border-[#B89355]/25 rounded px-2 py-1 text-[11px] text-white font-mono flex-1"
                              />
                              <button
                                onClick={() => handleReveal(claim.id, cmt)}
                                className="px-2.5 py-1 text-[11px] font-bold text-[#070D18] bg-[#B89355] hover:bg-[#CBA768] rounded cursor-pointer whitespace-nowrap"
                              >
                                Reveal Assessment
                              </button>
                            </div>
                          )}
                          {cmt.status === 'revealed' && cmt.revealedReport && (
                            <div className="bg-[#080E1A] p-2.5 rounded text-[11px] text-slate-300 space-y-1 border border-[#B89355]/20">
                              <span className="text-emerald-400 font-mono block font-semibold">
                                ✓ Hash verified against secret nonce
                              </span>
                              <p>{(cmt.revealedReport as TrackBReport).reasonedAssessment}</p>
                              <span className="font-mono text-[#DEC58B] font-bold block">
                                Proposed Settlement: €{(cmt.revealedReport as TrackBReport).proposedNetSettlement.toLocaleString()}
                              </span>
                            </div>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Interactive Commit Generator Modal */}
      {activeReviewClaim && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#070D18] border border-[#B89355]/40 rounded-2xl max-w-2xl w-full p-6 space-y-5 max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#B89355]/20 pb-3">
              <div>
                <span className="text-xs font-mono text-[#B89355] uppercase font-semibold">
                  Commit-Reveal Submission
                </span>
                <h3 className="font-serif-brand text-lg font-bold text-white">
                  Submit Assessment for {activeReviewClaim.claimNumber}
                </h3>
              </div>
              <button
                onClick={() => setActiveReviewClaim(null)}
                className="text-slate-400 hover:text-white text-xs font-mono cursor-pointer"
              >
                [CLOSE]
              </button>
            </div>

            {/* Track Selector */}
            <div className="flex items-center gap-2 p-1 bg-[#0A1424] rounded-lg border border-[#B89355]/25">
              <button
                type="button"
                onClick={() => setReviewTrack('track_a')}
                className={`flex-1 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
                  reviewTrack === 'track_a' ? 'bg-[#1C365C] text-[#F5EFE4] shadow-xs font-semibold' : 'text-slate-400'
                }`}
              >
                Track A: Evidence Forensics
              </button>
              <button
                type="button"
                onClick={() => setReviewTrack('track_b')}
                className={`flex-1 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
                  reviewTrack === 'track_b' ? 'bg-[#1C365C] text-[#F5EFE4] shadow-xs font-semibold' : 'text-slate-400'
                }`}
              >
                Track B: Contractual Coverage & Valuation
              </button>
            </div>

            <form onSubmit={handleGenerateCommitment} className="space-y-4 text-xs">
              {reviewTrack === 'track_a' ? (
                /* Track A Form */
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <label className="flex items-center gap-2 bg-[#0A1424] p-2.5 rounded-lg border border-[#B89355]/20 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={fileIntegrity}
                        onChange={(e) => setFileIntegrity(e.target.checked)}
                      />
                      <span>File SHA-256 & EXIF Verified</span>
                    </label>
                    <label className="flex items-center gap-2 bg-[#0A1424] p-2.5 rounded-lg border border-[#B89355]/20 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={serialMatch}
                        onChange={(e) => setSerialMatch(e.target.checked)}
                      />
                      <span>Equipment Serial Matches Registry</span>
                    </label>
                    <label className="flex items-center gap-2 bg-[#0A1424] p-2.5 rounded-lg border border-[#B89355]/20 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={chronologyCheck}
                        onChange={(e) => setChronologyCheck(e.target.checked)}
                      />
                      <span>Event Chronology Consistent</span>
                    </label>
                    <label className="flex items-center gap-2 bg-[#0A1424] p-2.5 rounded-lg border border-[#B89355]/20 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={quoteAuthentic}
                        onChange={(e) => setQuoteAuthentic(e.target.checked)}
                      />
                      <span>Vendor Repair Quote Verified</span>
                    </label>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">
                      Uncertainty Factor (0 = High Confidence, 1 = Uncorroborated)
                    </label>
                    <input
                      type="range"
                      min="0.0"
                      max="1.0"
                      step="0.05"
                      value={uncertaintyFactor}
                      onChange={(e) => setUncertaintyFactor(Number(e.target.value))}
                      className="w-full"
                    />
                    <div className="flex justify-between font-mono text-[10px] text-slate-500">
                      <span>0.00 (Empirically Proven)</span>
                      <span className="text-[#DEC58B] font-bold">{uncertaintyFactor.toFixed(2)}</span>
                      <span>1.00 (Unverified)</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Structured Forensics Findings</label>
                    <textarea
                      rows={3}
                      value={trackAFindings}
                      onChange={(e) => setTrackAFindings(e.target.value)}
                      className="w-full bg-[#0A1424] border border-[#B89355]/25 rounded-lg p-2.5 text-white"
                    />
                  </div>
                </div>
              ) : (
                /* Track B Form */
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <label className="flex items-center gap-2 bg-[#0A1424] p-2.5 rounded-lg border border-[#B89355]/20 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={policyInForce}
                        onChange={(e) => setPolicyInForce(e.target.checked)}
                      />
                      <span>Policy Active & Waiting Period Met</span>
                    </label>
                    <label className="flex items-center gap-2 bg-[#0A1424] p-2.5 rounded-lg border border-[#B89355]/20 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={perilCovered}
                        onChange={(e) => setPerilCovered(e.target.checked)}
                      />
                      <span>Covered Peril Confirmed</span>
                    </label>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-400 mb-1">Depreciation Adjustment (€)</label>
                      <input
                        type="number"
                        value={depreciationAmount}
                        onChange={(e) => setDepreciationAmount(Number(e.target.value))}
                        className="w-full bg-[#0A1424] border border-[#B89355]/25 rounded-lg px-3 py-2 text-white font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">Salvage Recovery Offset (€)</label>
                      <input
                        type="number"
                        value={salvageOffset}
                        onChange={(e) => setSalvageOffset(Number(e.target.value))}
                        className="w-full bg-[#0A1424] border border-[#B89355]/25 rounded-lg px-3 py-2 text-white font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Contractual Reasoning</label>
                    <textarea
                      rows={3}
                      value={trackBReasoning}
                      onChange={(e) => setTrackBReasoning(e.target.value)}
                      className="w-full bg-[#0A1424] border border-[#B89355]/25 rounded-lg p-2.5 text-white"
                    />
                  </div>
                </div>
              )}

              {/* Nonce Generator & Live Hash Preview */}
              <div className="bg-[#0A1424] p-3.5 rounded-xl border border-[#B89355]/25 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-white">Cryptographic Salt Nonce</span>
                  <button
                    type="button"
                    onClick={() =>
                      setNonceInput('rnd_nonce_' + Math.floor(10000 + Math.random() * 90000))
                    }
                    className="text-[#DEC58B] hover:underline text-[11px] font-mono cursor-pointer"
                  >
                    Generate Fresh Nonce
                  </button>
                </div>
                <input
                  type="text"
                  value={nonceInput}
                  onChange={(e) => setNonceInput(e.target.value)}
                  className="w-full bg-[#060B14] border border-[#B89355]/25 rounded-lg px-2.5 py-1.5 text-white font-mono text-[11px]"
                />
                <div className="pt-1 text-[11px] text-slate-400">
                  <span className="block font-mono text-[10px] text-slate-500">
                    Live Hash: {syncSha256(`${reviewTrack}:${nonceInput}`)}
                  </span>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveReviewClaim(null)}
                  className="px-4 py-2 text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-[#070D18] bg-[#B89355] hover:bg-[#CBA768] rounded transition-colors shadow-sm cursor-pointer"
                >
                  Submit Hash Commitment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
