/**
 * RhinoMutual Assurance - Domain Types
 * Developed by Aureom.AI
 */

export type UserRole = 'member' | 'validator' | 'operator' | 'adjudicator' | 'auditor';

export type ClaimState =
  | 'submitted'
  | 'eligibility_checked'
  | 'evidence_requested'
  | 'review_assigned'
  | 'committed'
  | 'revealed'
  | 'assessed'
  | 'authorised'
  | 'payment_pending'
  | 'paid'
  | 'referred'
  | 'disputed'
  | 'withdrawn'
  | 'reopened'
  | 'appealed';

export interface Equipment {
  id: string;
  serialNumber: string;
  name: string;
  category: 'Robotics & CNC' | 'Cinema & Optical' | 'Enterprise Compute' | 'Analytical Instruments' | 'Precision AgTech';
  manufacturer: string;
  model: string;
  purchaseDate: string;
  purchaseValue: number;
  replacementValue: number;
  depreciationRatePct: number; // e.g. 15% per year
  currentDepreciatedValue: number;
  location: string;
  ownerId: string;
  ownerName: string;
  registrationProofHash: string;
  status: 'registered' | 'coverage_active' | 'claim_pending' | 'decommissioned';
  activePolicyId?: string;
  registeredDate: string;
}

export interface PolicyVersion {
  version: string; // e.g. "v1.2-2026.1"
  effectiveDate: string;
  wordingHash: string; // SHA-256 of canonical legal terms
  termsSummary: string;
  coveredPerils: string[];
  exclusions: string[];
  waitingPeriodDays: number;
  notificationWindowDays: number;
  maxCoverageLimit: number;
  deductibleAmount: number;
  depreciationFormula: string;
  repairFacilityPreference: 'direct_repair_preferred' | 'claimant_reimbursement';
}

export interface P2PPool {
  id: string;
  name: string;
  code: string;
  category: string;
  description: string;
  totalMembers: number;
  activeEquipmentUnits: number;
  totalExposure: number;
  claimsReserveBalance: number;
  operatingReserve: number;
  liquidityRatioPct: number;
  targetSolvencyPct: number;
  annualContributions: number;
  surplusAllocation: {
    claimsFreeRebatePct: number;
    reserveCushionPct: number;
    safetyPoolTransferPct: number;
  };
  policyTerms: PolicyVersion;
  status: 'solvent' | 'caution' | 'capital_call_required';
}

export interface EvidenceItem {
  id: string;
  title: string;
  filename: string;
  fileType: string;
  sha256Hash: string;
  uploadTimestamp: string;
  exifTimestamp?: string;
  exifDevice?: string;
  classification: 'incident_photo' | 'vendor_repair_quote' | 'purchase_invoice' | 'telemetry_log' | 'police_report';
  redactedPreviewUrl: string;
  rawUrl: string;
  isPIIRedacted: boolean;
  redactedFields: string[];
  redactionAuditNote: string;
  independentAttestation?: {
    attestor: string;
    attestationHash: string;
    timestamp: string;
    status: 'valid' | 'inconclusive';
  };
}

export interface TrackAReport {
  trackType: 'track_a_evidence';
  validatorId: string;
  fileIntegrityVerified: boolean;
  equipmentIdentityMatch: boolean;
  chronologyConsistent: boolean;
  duplicateSubmissionDetected: boolean;
  vendorQuoteAuthentic: boolean;
  quoteAuthenticityScore: number; // 0-100
  uncertaintyFactor: number; // 0.0 to 1.0 (0 = high confidence, 1 = uncorroborated)
  discrepancies: string[];
  findingsSummary: string;
  recommendation: 'verified' | 'suspect' | 'inconclusive' | 'compromised';
}

export interface TrackBReport {
  trackType: 'track_b_coverage';
  validatorId: string;
  policyInForce: boolean;
  perilCovered: boolean;
  exclusionTriggered: boolean;
  exclusionNotes?: string;
  claimedLossAmount: number;
  applicableDeductible: number;
  depreciationAdjustment: number;
  salvageRecoveryOffset: number;
  proposedNetSettlement: number;
  settlementOption: 'direct_repair_facility' | 'claimant_reimbursement' | 'replacement_equipment';
  reasonedAssessment: string;
  recommendation: 'eligible' | 'partial' | 'ineligible';
}

export interface ReviewCommitment {
  validatorId: string;
  validatorAlias: string; // Pseudonymous identifier for blinding
  track: 'track_a' | 'track_b';
  commitmentHash: string; // SHA-256 of report JSON + nonce
  committedAt: string;
  revealDeadline: string;
  revealedAt?: string;
  nonce?: string;
  revealedReport?: TrackAReport | TrackBReport;
  status: 'committed' | 'revealed' | 'escrow_recovered' | 'timed_out';
  hashMatches: boolean;
}

export interface AdjudicationDecision {
  adjudicatorId: string;
  adjudicatorName: string;
  decidedAt: string;
  tracksReconciled: boolean;
  bothTracksAligned: boolean;
  trackAFinding: string;
  trackBFinding: string;
  reconciledAmount: number;
  deductibleApplied: number;
  depreciationDeducted: number;
  payoutChannel: 'direct_repair_facility' | 'claimant_reimbursement';
  repairVendorName?: string;
  reasoning: string;
  factualCorrections: string[];
  decisionOutcome: 'authorised' | 'referred' | 'disputed' | 'denied';
}

export interface AppealRecord {
  id: string;
  claimId: string;
  appealedAt: string;
  grounds: 'factual_misinterpretation' | 'procedural_irregularity' | 'new_corroborating_evidence' | 'valuation_dispute';
  originalAuthorizedAmount: number;
  claimedLossAmount: number;
  appellantStatement: string;
  newEvidenceReferences: string[];
  seniorPanelValidatorIds: string[];
  deliberationSummary?: string;
  finalDetermination?: 'upheld' | 'modified' | 'reversed';
  revisedAmount?: number;
  concludedAt?: string;
  status: 'open' | 'in_deliberation' | 'decided';
}

export interface ClaimTimelineEvent {
  timestamp: string;
  state: ClaimState;
  actorRole: UserRole | 'system';
  actorName: string;
  description: string;
  hashProof?: string;
}

export interface ZKProofRecord {
  scheme: string; // "Groth16 / BN254"
  statement: string; // "Proves active pool membership & non-lapsed coverage without revealing claimant PII or identity"
  publicInputs: {
    poolIdHash: string;
    timestampEpoch: number;
    nullifierHash: string;
    minActiveDays: number;
  };
  proofHash: string;
  isMock: boolean;
  mockNotice: string;
  verified: boolean;
}

export interface Claim {
  id: string;
  claimNumber: string;
  claimantId: string;
  claimantName: string; // Pseudonymized in blinded review packets
  equipmentId: string;
  equipmentName: string;
  equipmentSerial: string;
  poolId: string;
  poolName: string;
  policyVersion: string;
  policyWordingHash: string;
  incidentDate: string;
  submissionDate: string;
  incidentType: 'electrical_surge' | 'mechanical_failure' | 'transit_drop' | 'accidental_impact' | 'water_damage' | 'operator_mishap';
  incidentDescription: string;
  claimedAmount: number;
  state: ClaimState;
  timeline: ClaimTimelineEvent[];
  evidence: EvidenceItem[];
  trackACommitments: ReviewCommitment[];
  trackBCommitments: ReviewCommitment[];
  adjudication?: AdjudicationDecision;
  appeal?: AppealRecord;
  zkProof?: ZKProofRecord;
  ledgerTxId?: string;
}

export interface Validator {
  id: string;
  orgName: string;
  leadAnalyst: string;
  expertiseAreas: string[];
  bondedStake: number; // fiat EUR/USD bonded
  consensusStakeSharePct: number; // capped to prevent concentration
  maxConcurrentReviews: number;
  activeReviews: number;
  completedReviews: number;
  consensusAlignmentPct: number;
  timelyRevealPct: number;
  reputationScore: number; // 0-100
  slashedAmount: number;
  slashEventsCount: number;
  suspensionStatus: 'active' | 'under_inquiry' | 'suspended';
  disclosedConflicts: string[];
  fixedReviewFee: number; // e.g. €180 fixed compensation regardless of outcome
  lastAuditDate: string;
}

export interface LedgerEntry {
  id: string;
  blockHeight: number;
  timestamp: string;
  txType:
    | 'member_contribution'
    | 'reserve_lock'
    | 'claim_settlement'
    | 'validator_fee'
    | 'bond_deposit'
    | 'bond_slashed'
    | 'salvage_recovery'
    | 'surplus_rebate';
  debitAccount: string;
  creditAccount: string;
  amount: number;
  currency: string;
  referenceId: string;
  referenceDescription: string;
  prevHash: string;
  entryHash: string;
  merkleRoot: string;
}

export interface SimulationParams {
  numClaims: number;
  fraudRatePct: number;
  reviewerCollusionRatePct: number;
  auditRatePct: number;
  reviewerErrorRatePct: number;
  correlatedLossShock: boolean;
  stakeSlashPenaltyMultiplier: number;
}

export interface SimulationModelResult {
  modelName: string;
  fraudPaidPct: number;
  legitimateDeniedPct: number;
  medianTurnaroundDays: number;
  costPerClaim: number;
  appealReversalPct: number;
  reviewerConcentrationGini: number;
  poolFundingShortfallPct: number;
  claimantEffortIndex: number; // 1-10 scale
}
