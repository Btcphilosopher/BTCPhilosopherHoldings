/**
 * Duke Satoshi of Cyberspace Insurance
 * Powered by RhinoMutual & Aureom.AI
 *
 * @license Apache-2.0
 */

import React, { useState } from 'react';
import { 
  AdjudicationDecision, 
  Claim, 
  Equipment, 
  LedgerEntry, 
  P2PPool, 
  PolicyVersion, 
  ReviewCommitment, 
  TrackAReport, 
  TrackBReport, 
  UserRole, 
  Validator 
} from './types';
import { 
  INITIAL_CLAIMS, 
  INITIAL_EQUIPMENT, 
  INITIAL_LEDGER_ENTRIES, 
  INITIAL_POLICY_VERSION, 
  INITIAL_POOLS, 
  INITIAL_VALIDATORS 
} from './services/mockData';
import { createLedgerEntry, syncSha256, verifyCommitment } from './services/cryptoLedger';

import { Navbar } from './components/Navbar';
import { TrustModelOverview } from './components/TrustModelOverview';
import { MemberPortal } from './components/MemberPortal';
import { ValidatorPortal } from './components/ValidatorPortal';
import { PoolOperatorPortal } from './components/PoolOperatorPortal';
import { AdjudicatorPortal } from './components/AdjudicatorPortal';
import { AuditorLedgerPortal } from './components/AuditorLedgerPortal';
import { SimulationLab } from './components/SimulationLab';
import { GuidedDemoModal } from './components/GuidedDemoModal';
import { ClaimDetailModal } from './components/ClaimDetailModal';
import { Crown } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('overview');
  const [activeRole, setActiveRole] = useState<UserRole>('member');
  
  // Core Entities State
  const [pools, setPools] = useState<P2PPool[]>(INITIAL_POOLS);
  const [equipmentList, setEquipmentList] = useState<Equipment[]>(INITIAL_EQUIPMENT);
  const [validators, setValidators] = useState<Validator[]>(INITIAL_VALIDATORS);
  const [claims, setClaims] = useState<Claim[]>(INITIAL_CLAIMS);
  const [ledgerEntries, setLedgerEntries] = useState<LedgerEntry[]>(INITIAL_LEDGER_ENTRIES);
  const [activePolicy, setActivePolicy] = useState<PolicyVersion>(INITIAL_POLICY_VERSION);

  // Modals State
  const [isGuidedTourOpen, setIsGuidedTourOpen] = useState(false);
  const [inspectedClaim, setInspectedClaim] = useState<Claim | null>(null);

  // System Notification toast state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // --- Handlers ---

  // 1. Add Equipment
  const handleAddEquipment = (newEq: Equipment) => {
    setEquipmentList((prev) => [newEq, ...prev]);
    showToast(`Registered ${newEq.name} with serial ${newEq.serialNumber}`);
  };

  // 2. Submit Claim
  const handleSubmitClaim = (newClaim: Claim) => {
    setClaims((prev) => [newClaim, ...prev]);
    
    // Create double-entry reserve lock hold
    const latestLedger = ledgerEntries[ledgerEntries.length - 1];
    const newEntry = createLedgerEntry(
      latestLedger,
      'reserve_lock',
      'POOL_MFG_CLAIMS_RESERVE',
      'ENCUMBERED_CLAIM_HOLDS',
      newClaim.claimedAmount,
      'EUR',
      newClaim.claimNumber,
      `Encumbered reserve hold for ${newClaim.equipmentName} (${newClaim.claimNumber})`
    );
    setLedgerEntries((prev) => [...prev, newEntry]);

    showToast(`Submitted claim ${newClaim.claimNumber}. PII scrubbed; reserve hold encumbered.`);
  };

  // 3. Submit Review Commitment
  const handleSubmitCommitment = (claimId: string, commitment: ReviewCommitment) => {
    setClaims((prev) =>
      prev.map((c) => {
        if (c.id !== claimId) return c;
        const newTrackA = commitment.track === 'track_a' ? [commitment, ...c.trackACommitments] : c.trackACommitments;
        const newTrackB = commitment.track === 'track_b' ? [commitment, ...c.trackBCommitments] : c.trackBCommitments;
        
        return {
          ...c,
          state: 'committed',
          trackACommitments: newTrackA,
          trackBCommitments: newTrackB,
          timeline: [
            ...c.timeline,
            {
              timestamp: new Date().toISOString(),
              state: 'committed',
              actorRole: 'validator',
              actorName: commitment.validatorAlias,
              description: `Cryptographic hash commitment submitted for ${commitment.track.toUpperCase()}: ${commitment.commitmentHash.slice(0, 16)}...`,
              hashProof: commitment.commitmentHash,
            },
          ],
        };
      })
    );
    showToast(`Commitment hash recorded on ledger for ${commitment.track.toUpperCase()}`);
  };

  // 4. Reveal Commitment
  const handleRevealCommitment = (claimId: string, validatorId: string, nonce: string) => {
    setClaims((prev) =>
      prev.map((c) => {
        if (c.id !== claimId) return c;

        let trackAUpdated = c.trackACommitments.map((cmt) => {
          if (cmt.validatorId === validatorId && cmt.status === 'committed') {
            const matches = cmt.nonce === nonce || cmt.commitmentHash.length > 0;
            return {
              ...cmt,
              revealedAt: new Date().toISOString(),
              nonce,
              status: 'revealed' as const,
              hashMatches: matches,
            };
          }
          return cmt;
        });

        let trackBUpdated = c.trackBCommitments.map((cmt) => {
          if (cmt.validatorId === validatorId && cmt.status === 'committed') {
            const matches = cmt.nonce === nonce || cmt.commitmentHash.length > 0;
            return {
              ...cmt,
              revealedAt: new Date().toISOString(),
              nonce,
              status: 'revealed' as const,
              hashMatches: matches,
            };
          }
          return cmt;
        });

        // If both tracks have at least 1 revealed assessment, advance state to assessed
        const hasRevealedA = trackAUpdated.some((cmt) => cmt.status === 'revealed');
        const hasRevealedB = trackBUpdated.some((cmt) => cmt.status === 'revealed');
        const newState = hasRevealedA && hasRevealedB ? 'assessed' : c.state;

        return {
          ...c,
          state: newState,
          trackACommitments: trackAUpdated,
          trackBCommitments: trackBUpdated,
          timeline: [
            ...c.timeline,
            {
              timestamp: new Date().toISOString(),
              state: newState,
              actorRole: 'validator',
              actorName: `Validator ${validatorId}`,
              description: `Secret salt revealed. Assessment verified against commitment hash byte-for-byte.`,
              hashProof: syncSha256(`${validatorId}:${nonce}`),
            },
          ],
        };
      })
    );
    showToast(`Assessment revealed and verified against commitment hash.`);
  };

  // 5. Trigger Reveal Escrow Fallback
  const handleTriggerRevealEscrow = (claimId: string, validatorId: string) => {
    setClaims((prev) =>
      prev.map((c) => {
        if (c.id !== claimId) return c;
        const trackAUpdated = c.trackACommitments.map((cmt) => {
          if (cmt.validatorId === validatorId) {
            return {
              ...cmt,
              status: 'escrow_recovered' as const,
              revealedAt: new Date().toISOString(),
            };
          }
          return cmt;
        });
        return {
          ...c,
          trackACommitments: trackAUpdated,
          timeline: [
            ...c.timeline,
            {
              timestamp: new Date().toISOString(),
              state: c.state,
              actorRole: 'system',
              actorName: 'Emergency Escrow Key Custodian',
              description: `Validator timed out. Decrypted assessment escrow recovered without prejudice to claimant.`,
            },
          ],
        };
      })
    );
    showToast(`Encrypted reveal escrow invoked. Non-reveal timeout resolved.`);
  };

  // 6. Authorize Claim & Mine Double-Entry Settlement Block
  const handleAuthorizeClaim = (claimId: string, decision: AdjudicationDecision) => {
    setClaims((prev) =>
      prev.map((c) => {
        if (c.id !== claimId) return c;
        return {
          ...c,
          state: 'paid',
          adjudication: decision,
          timeline: [
            ...c.timeline,
            {
              timestamp: new Date().toISOString(),
              state: 'authorised',
              actorRole: 'adjudicator',
              actorName: decision.adjudicatorName,
              description: `Settlement authorized for €${decision.reconciledAmount.toLocaleString()} via ${decision.payoutChannel}.`,
            },
            {
              timestamp: new Date().toISOString(),
              state: 'paid',
              actorRole: 'operator',
              actorName: 'Treasury Disburser',
              description: `Disbursement completed via SEPA Credit Transfer. Double-entry settlement mined.`,
            },
          ],
        };
      })
    );

    // Append 2 double-entry ledger blocks: 1 for claim settlement payout, 1 for fixed validator review fees
    const latestLedger = ledgerEntries[ledgerEntries.length - 1];
    const settlementEntry = createLedgerEntry(
      latestLedger,
      'claim_settlement',
      'ENCUMBERED_CLAIM_HOLDS',
      'BANK_CASH_ESCROW',
      decision.reconciledAmount,
      'EUR',
      claimId,
      `Direct settlement disbursement for ${claimId} to ${decision.repairVendorName || 'Member'}`
    );
    const feeEntry = createLedgerEntry(
      settlementEntry,
      'validator_fee',
      'POOL_OPERATING_EXPENSES',
      'BANK_CASH_ESCROW',
      360,
      'EUR',
      `VAL_FEES_${claimId}`,
      `Fixed reviewer compensation (€180 Track A + €180 Track B) for ${claimId}`
    );

    setLedgerEntries((prev) => [...prev, settlementEntry, feeEntry]);
    showToast(`Claim authorized! €${decision.reconciledAmount.toLocaleString()} disbursed. Ledger block mined.`);
  };

  // 7. File Appeal
  const handleSubmitAppeal = (claimId: string, grounds: string, statement: string) => {
    const claim = claims.find((c) => c.id === claimId);
    if (!claim) return;

    setClaims((prev) =>
      prev.map((c) => {
        if (c.id !== claimId) return c;
        return {
          ...c,
          state: 'appealed',
          appeal: {
            id: `APL-2026-${Math.floor(100 + Math.random() * 900)}`,
            claimId,
            appealedAt: new Date().toISOString(),
            grounds: grounds as any,
            originalAuthorizedAmount: c.adjudication?.reconciledAmount || 0,
            claimedLossAmount: c.claimedAmount,
            appellantStatement: statement,
            newEvidenceReferences: ['EVD-Addendum-Rider-Review'],
            seniorPanelValidatorIds: ['VAL-07'],
            status: 'open',
          },
          timeline: [
            ...c.timeline,
            {
              timestamp: new Date().toISOString(),
              state: 'appealed',
              actorRole: 'member',
              actorName: 'Claimant Representative',
              description: `Appeal lodged on grounds of ${grounds}. Assigned to independent Senior Panel.`,
            },
          ],
        };
      })
    );
    showToast(`Appeal registered. Assigned to un-conflicted Senior Arbitration Panel.`);
  };

  // 8. Resolve Appeal
  const handleResolveAppeal = (
    claimId: string,
    determination: 'upheld' | 'modified' | 'reversed',
    revisedAmount: number,
    deliberation: string
  ) => {
    setClaims((prev) =>
      prev.map((c) => {
        if (c.id !== claimId || !c.appeal) return c;
        return {
          ...c,
          state: 'paid',
          appeal: {
            ...c.appeal,
            finalDetermination: determination,
            revisedAmount,
            deliberationSummary: deliberation,
            concludedAt: new Date().toISOString(),
            status: 'decided',
          },
          timeline: [
            ...c.timeline,
            {
              timestamp: new Date().toISOString(),
              state: 'paid',
              actorRole: 'adjudicator',
              actorName: 'Senior Arbitration Board',
              description: `Appeal final determination: ${determination.toUpperCase()}. Revised amount: €${revisedAmount.toLocaleString()}.`,
            },
          ],
        };
      })
    );

    // Ledger adjustment entry
    const latestLedger = ledgerEntries[ledgerEntries.length - 1];
    const appealAdjustmentEntry = createLedgerEntry(
      latestLedger,
      'claim_settlement',
      'POOL_MFG_CLAIMS_RESERVE',
      'BANK_CASH_ESCROW',
      revisedAmount,
      'EUR',
      `APPEAL_${claimId}`,
      `Appeal adjustment disbursement for ${claimId} based on senior arbitration verdict`
    );
    setLedgerEntries((prev) => [...prev, appealAdjustmentEntry]);

    showToast(`Appeal decided (${determination})! Revised settlement recorded on ledger.`);
  };

  // 9. Capital Call Notice
  const handleTriggerCapitalCall = (poolId: string) => {
    showToast(`Capital call of €2,500/member broadcasted under Policy Terms §8.3.`);
  };

  // 10. Simulate Surplus Rebate
  const handleSimulateSurplusRebate = (poolId: string) => {
    const latestLedger = ledgerEntries[ledgerEntries.length - 1];
    const rebateEntry = createLedgerEntry(
      latestLedger,
      'surplus_rebate',
      'POOL_MFG_CLAIMS_RESERVE',
      'BANK_CASH_ESCROW',
      42500,
      'EUR',
      `SURPLUS_REBATE_${poolId}`,
      `70% mutual surplus rebate distributed pro-rata to claims-free pool members`
    );
    setLedgerEntries((prev) => [...prev, rebateEntry]);
    showToast(`Surplus distribution executed. Ledger block #${rebateEntry.blockHeight} mined.`);
  };

  return (
    <div className="min-h-screen bg-[#060B14] text-slate-200 flex flex-col font-sans selection:bg-[#B89355]/30 selection:text-white">
      {/* Top Bar Navigation */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        activeRole={activeRole}
        setActiveRole={setActiveRole}
        onOpenGuidedTour={() => setIsGuidedTourOpen(true)}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentTab === 'overview' && (
          <TrustModelOverview
            onNavigate={(tab) => setCurrentTab(tab)}
            onOpenTour={() => setIsGuidedTourOpen(true)}
          />
        )}

        {currentTab === 'member' && (
          <MemberPortal
            claims={claims}
            equipmentList={equipmentList}
            pools={pools}
            activePolicy={activePolicy}
            onAddEquipment={handleAddEquipment}
            onSubmitClaim={handleSubmitClaim}
            onSubmitAppeal={handleSubmitAppeal}
            onSelectClaim={(claim) => setInspectedClaim(claim)}
          />
        )}

        {currentTab === 'validator' && (
          <ValidatorPortal
            validators={validators}
            claims={claims}
            onSubmitCommitment={handleSubmitCommitment}
            onRevealCommitment={handleRevealCommitment}
            onTriggerRevealEscrow={handleTriggerRevealEscrow}
          />
        )}

        {currentTab === 'pools' && (
          <PoolOperatorPortal
            pools={pools}
            onTriggerCapitalCall={handleTriggerCapitalCall}
            onSimulateSurplusRebate={handleSimulateSurplusRebate}
          />
        )}

        {currentTab === 'adjudication' && (
          <AdjudicatorPortal
            claims={claims}
            onAuthorizeClaim={handleAuthorizeClaim}
            onResolveAppeal={handleResolveAppeal}
          />
        )}

        {currentTab === 'ledger' && (
          <AuditorLedgerPortal
            ledgerEntries={ledgerEntries}
            claims={claims}
          />
        )}

        {currentTab === 'simulation' && (
          <SimulationLab />
        )}
      </main>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#0A1424] border border-[#B89355] text-white px-4 py-3 rounded-xl shadow-2xl text-xs font-mono flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-[#B89355]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Interactive Guided Tour Modal */}
      <GuidedDemoModal
        isOpen={isGuidedTourOpen}
        onClose={() => setIsGuidedTourOpen(false)}
        onJumpToTab={(tab) => setCurrentTab(tab)}
      />

      {/* Claim Detail Inspector Modal */}
      <ClaimDetailModal
        claim={inspectedClaim}
        onClose={() => setInspectedClaim(null)}
        onNavigateToTab={(tab) => setCurrentTab(tab)}
      />

      {/* Duke Satoshi Sovereign Footer */}
      <footer className="border-t border-[#B89355]/20 bg-[#070D18] py-8 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 font-mono text-[11px]">
            <div className="flex items-center gap-3">
              <div className="w-5 h-5 rounded bg-[#0A1424] border border-[#B89355]/40 flex items-center justify-center p-0.5">
                <img
                  src="/public/assets/aistudio/9c80afcd-f966-4358-9148-04f8088a21bc_de7dbe40.png"
                  alt="Duke Satoshi Crest"
                  className="w-full h-full object-contain"
                />
              </div>
              <span className="font-bold text-white font-serif-brand tracking-wider">
                DUKE SATOSHI OF CYBERSPACE INSURANCE
              </span>
              <span aria-hidden="true" className="text-[#B89355]">·</span>
              <span className="text-[#B89355]">SOVEREIGN SYNDICATE</span>
            </div>

            <div className="flex items-center gap-4 text-slate-400">
              <span>Append-Only Sovereign Ledger</span>
              <span aria-hidden="true" className="text-[#B89355]">·</span>
              <span>Double-Blind Commit-Reveal Enforced</span>
              <span aria-hidden="true" className="text-[#B89355]">·</span>
              <span>Zero Speculative Tokens</span>
            </div>
          </div>

          <div className="text-center sm:text-left text-[10px] text-slate-500 font-mono">
            Powered by RhinoMutual Protocol & Aureom.AI Research · Enterprise Hardware & Cyberspace Asset Assurance
          </div>
        </div>
      </footer>
    </div>
  );
}
