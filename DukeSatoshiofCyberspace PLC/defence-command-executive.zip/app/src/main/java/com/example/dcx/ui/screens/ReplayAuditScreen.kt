package com.example.dcx.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dcx.data.SyntheticData
import com.example.dcx.db.AuditEntity
import com.example.dcx.model.CommandEvent
import com.example.ui.theme.DcxGreen
import com.example.ui.theme.DcxOutline
import com.example.ui.theme.DcxPrimary
import com.example.ui.theme.DcxSurface

@Composable
fun ReplayAuditScreen(
    eventsStream: List<CommandEvent>,
    auditStream: List<AuditEntity>,
    modifier: Modifier = Modifier
) {
    var selectedReplayDate by remember { mutableStateOf("2026-10-06 05:45:00") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "HISTORICAL REPLAY & IMMUTABLE AUDIT ENGINE",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = DcxPrimary
                    )
                    Text(
                        text = "TIME-TRAVEL RECONSTRUCTION OF DEFENCE STATE & DECISION CONTEXT",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray,
                        fontSize = 9.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "REPLAY DATE / TIME POINT: $selectedReplayDate",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = DcxGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }

        item {
            Text(
                text = "COMMAND EVENT BUS STREAM",
                style = MaterialTheme.typography.titleSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        val allEvents = if (eventsStream.isNotEmpty()) eventsStream else SyntheticData.INITIAL_EVENTS

        items(allEvents) { evt ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "[${evt.eventId}] ${evt.source}",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = DcxPrimary,
                            fontSize = 10.sp
                        )
                        Text(
                            text = evt.timestamp,
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = Color.Gray,
                            fontSize = 9.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${evt.entityType}:${evt.entityId} | STATE: ${evt.previousState} → ${evt.newState}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "ACTOR: ${evt.actor} | REASON: ${evt.reason}",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp
                    )
                }
            }
        }

        if (auditStream.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "IMMUTABLE AUDIT TRAIL LOGS",
                    style = MaterialTheme.typography.titleSmall,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            items(auditStream) { aud ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DcxSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = aud.auditId, style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = DcxPrimary, fontSize = 9.sp)
                            Text(text = aud.timestamp, style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = Color.Gray, fontSize = 9.sp)
                        }
                        Text(text = "ACTION: ${aud.action} ON ${aud.targetObject}", style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace, color = Color.White, fontSize = 10.sp)
                        Text(text = "USER: ${aud.userName} (${aud.userRole}) | JUSTIFICATION: ${aud.justification}", style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontSize = 9.sp)
                    }
                }
            }
        }
    }
}
