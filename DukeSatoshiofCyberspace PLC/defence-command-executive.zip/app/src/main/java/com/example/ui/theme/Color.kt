package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// DCX Command Palette - MOD Terminal Aesthetic
val DcxBackground = Color(0xFF0B0F17)
val DcxSurface = Color(0xFF111827)
val DcxSurfaceVariant = Color(0xFF1E293B)
val DcxOutline = Color(0xFF334155)

val DcxPrimary = Color(0xFF38BDF8) // Tactical Command Cyan
val DcxOnPrimary = Color(0xFF0F172A)
val DcxSecondary = Color(0xFF94A3B8)
val DcxTertiary = Color(0xFF64748B)

// Defence Status Indicators
val DcxGreen = Color(0xFF22C55E)
val DcxGreenContainer = Color(0xFF064E3B)
val DcxAmber = Color(0xFFF59E0B)
val DcxAmberContainer = Color(0xFF78350F)
val DcxRed = Color(0xFFEF4444)
val DcxRedContainer = Color(0xFF7F1D1D)

val DcxTextPrimary = Color(0xFFF8FAFC)
val DcxTextSecondary = Color(0xFF94A3B8)
val DcxTextMuted = Color(0xFF64748B)

val DcxGoldAccent = Color(0xFFEAB308)
