package com.example.dcx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dcx.data.SyntheticData
import com.example.dcx.engine.DigitalTwinEngine
import com.example.dcx.model.ScenarioSimulationResult
import com.example.ui.theme.DcxAmber
import com.example.ui.theme.DcxGreen
import com.example.ui.theme.DcxOutline
import com.example.ui.theme.DcxPrimary
import com.example.ui.theme.DcxRed
import com.example.ui.theme.DcxSurface

@Composable
fun LogisticsDigitalTwinScreen(modifier: Modifier = Modifier) {
    var activeScenario by remember { mutableStateOf<ScenarioSimulationResult?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "DEFENCE LOGISTICS & SUPPLY-CHAIN DIGITAL TWIN",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = DcxPrimary
                    )
                    Text(
                        text = "DEPOT INVENTORY & BOUNDED RIPPLE EFFECT SIMULATION",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray,
                        fontSize = 9.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "RUN SUPPLY CHAIN EXPERIMENT:",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = { activeScenario = DigitalTwinEngine.runScenario("SUPPLIER_DELAY_90") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("run_supplier_delay_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DcxPrimary),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                        ) {
                            Text("90d Supplier Delay", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = DcxPrimary)
                        }

                        Button(
                            onClick = { activeScenario = DigitalTwinEngine.runScenario("FUEL_PRICE_SHOCK_30") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("run_fuel_shock_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DcxAmber),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                        ) {
                            Text("30% Fuel Shock", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = DcxAmber)
                        }
                    }
                }
            }
        }

        // SCENARIO EXPERIMENT RESULT BOX
        activeScenario?.let { sim ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B4B)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DcxPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "DIGITAL TWIN SIMULATION: ${sim.scenarioName}",
                            style = MaterialTheme.typography.titleMedium,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = DcxPrimary,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = sim.summaryNarrative,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("P50 Readiness: ${sim.p50Readiness}%", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = DcxGreen, fontSize = 10.sp)
                            Text("P75 Readiness: ${sim.p75Readiness}%", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = DcxAmber, fontSize = 10.sp)
                            Text("P90 Readiness: ${sim.p90Readiness}%", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = DcxRed, fontSize = 10.sp)
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "ESTIMATED LOGISTICS RECOVERY DELAY: ${sim.logisticsDelayDays} DAYS",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = DcxAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "DEPOT & CENTRAL INVENTORY STATUS",
                style = MaterialTheme.typography.titleSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        items(SyntheticData.LOGISTICS_INVENTORY) { inv ->
            val statusColor = when (inv.status) {
                "OPTIMAL" -> DcxGreen
                "WARNING" -> DcxAmber
                else -> DcxRed
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = inv.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "${inv.depotName} | ${inv.category}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF94A3B8),
                                fontSize = 9.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .background(statusColor.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                .border(1.dp, statusColor, RoundedCornerShape(3.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = inv.status,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = statusColor,
                                fontSize = 9.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "ON HAND: ${inv.onHand} ${inv.unitOfMeasure}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = Color.White, fontSize = 10.sp)
                        Text(text = "RESERVED: ${inv.reserved}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = Color.Gray, fontSize = 10.sp)
                        Text(text = "IN TRANSIT: ${inv.inTransit}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = DcxPrimary, fontSize = 10.sp)
                    }

                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "BACKORDERED: ${inv.backordered} | MIN THRESHOLD: ${inv.minThreshold}",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = if (inv.onHand < inv.minThreshold) DcxAmber else Color.Gray,
                        fontSize = 9.sp
                    )
                }
            }
        }
    }
}
