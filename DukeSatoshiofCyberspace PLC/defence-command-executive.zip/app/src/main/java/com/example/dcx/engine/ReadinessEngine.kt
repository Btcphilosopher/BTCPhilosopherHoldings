package com.example.dcx.engine

import com.example.dcx.data.SyntheticData
import com.example.dcx.model.OrganisationUnit
import com.example.dcx.model.ReadinessDimension
import com.example.dcx.model.ReadinessStatus

object ReadinessEngine {

    fun calculateOverallReadiness(): Int {
        val dimensions = SyntheticData.READINESS_DIMENSIONS
        if (dimensions.isEmpty()) return 0
        return dimensions.map { it.score }.average().toInt()
    }

    fun getOverallReadinessStatus(score: Int): ReadinessStatus {
        return when {
            score >= 90 -> ReadinessStatus.HIGH_READINESS
            score >= 80 -> ReadinessStatus.READY
            score >= 70 -> ReadinessStatus.PARTIALLY_READY
            score >= 50 -> ReadinessStatus.LIMITED
            else -> ReadinessStatus.NOT_READY
        }
    }

    fun getReadinessByCommand(): Map<String, Int> {
        return SyntheticData.ORGANISATION_UNITS.associate { unit ->
            unit.name to unit.readinessScore
        }
    }

    fun getReadinessExceptions(): List<ReadinessDimension> {
        return SyntheticData.READINESS_DIMENSIONS.filter {
            it.status == ReadinessStatus.LIMITED || it.status == ReadinessStatus.NOT_READY || it.score < 75
        }
    }
}
