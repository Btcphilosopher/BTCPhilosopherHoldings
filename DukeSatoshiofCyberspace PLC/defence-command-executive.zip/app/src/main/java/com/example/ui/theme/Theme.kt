package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DcxColorScheme = darkColorScheme(
    primary = DcxPrimary,
    onPrimary = DcxOnPrimary,
    primaryContainer = DcxSurfaceVariant,
    onPrimaryContainer = DcxTextPrimary,
    secondary = DcxSecondary,
    onSecondary = DcxOnPrimary,
    tertiary = DcxGoldAccent,
    background = DcxBackground,
    onBackground = DcxTextPrimary,
    surface = DcxSurface,
    onSurface = DcxTextPrimary,
    surfaceVariant = DcxSurfaceVariant,
    onSurfaceVariant = DcxTextSecondary,
    outline = DcxOutline,
    outlineVariant = DcxOutline
)

@Composable
fun DcxTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DcxColorScheme,
        typography = DcxTypography,
        content = content
    )
}
