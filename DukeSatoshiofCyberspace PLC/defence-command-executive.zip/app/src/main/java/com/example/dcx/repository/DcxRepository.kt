package com.example.dcx.repository

import com.example.dcx.data.SyntheticData
import com.example.dcx.db.AuditEntity
import com.example.dcx.db.DcxDao
import com.example.dcx.db.DecisionEntity
import com.example.dcx.db.EventEntity
import com.example.dcx.db.RiskEntity
import com.example.dcx.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DcxRepository(private val dao: DcxDao) {

    fun getEventsStream(): Flow<List<CommandEvent>> {
        return dao.getAllEvents().map { dbEvents ->
            val initial = SyntheticData.INITIAL_EVENTS
            val converted = dbEvents.map { e ->
                CommandEvent(
                    eventId = e.eventId,
                    timestamp = e.timestamp,
                    source = e.source,
                    classification = ClassificationLevel.valueOf(e.classification),
                    actor = e.actor,
                    entityType = e.entityType,
                    entityId = e.entityId,
                    previousState = e.previousState,
                    newState = e.newState,
                    reason = e.reason
                )
            }
            (converted + initial).sortedByDescending { it.timestamp }
        }
    }

    suspend fun recordEvent(
        source: String,
        actor: String,
        entityType: String,
        entityId: String,
        previousState: String,
        newState: String,
        reason: String
    ) {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.UK).format(Date())
        val event = EventEntity(
            eventId = "EVT-${System.currentTimeMillis()}",
            timestamp = now,
            source = source,
            classification = ClassificationLevel.OFFICIAL_SENSITIVE.name,
            actor = actor,
            entityType = entityType,
            entityId = entityId,
            previousState = previousState,
            newState = newState,
            reason = reason
        )
        dao.insertEvent(event)
        recordAudit(
            userRole = actor,
            userName = "Commander",
            action = "STATE_TRANSITION",
            targetObject = "$entityType:$entityId",
            previousValue = previousState,
            newValue = newState,
            justification = reason
        )
    }

    suspend fun recordAudit(
        userRole: String,
        userName: String,
        action: String,
        targetObject: String,
        previousValue: String,
        newValue: String,
        justification: String
    ) {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.UK).format(Date())
        val audit = AuditEntity(
            auditId = "AUD-${System.currentTimeMillis()}",
            timestamp = now,
            userRole = userRole,
            userName = userName,
            action = action,
            targetObject = targetObject,
            previousValue = previousValue,
            newValue = newValue,
            justification = justification,
            classification = ClassificationLevel.OFFICIAL_SENSITIVE.name
        )
        dao.insertAuditRecord(audit)
    }

    fun getAuditStream(): Flow<List<AuditEntity>> {
        return dao.getAllAuditRecords()
    }

    suspend fun approveDecision(decisionId: String, approvedBy: String) {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.UK).format(Date())
        dao.updateDecisionStatus(decisionId, DecisionStatus.APPROVED.name, approvedBy, now)
        recordEvent(
            source = "EXECUTIVE_DECISION_ENGINE",
            actor = approvedBy,
            entityType = "DECISION",
            entityId = decisionId,
            previousState = DecisionStatus.AWAITING_DECISION.name,
            newState = DecisionStatus.APPROVED.name,
            reason = "Approved by Senior Defence Commander"
        )
    }

    fun getDecisionsStream(): Flow<List<DecisionRecord>> {
        return dao.getAllDecisions().map { dbDecisions ->
            val initial = SyntheticData.EXECUTIVE_DECISIONS
            val map = initial.associateBy { it.id }.toMutableMap()

            dbDecisions.forEach { db ->
                val status = try { DecisionStatus.valueOf(db.status) } catch (e: Exception) { DecisionStatus.AWAITING_DECISION }
                map[db.id] = DecisionRecord(
                    id = db.id,
                    title = db.title,
                    owner = db.owner,
                    deadline = db.deadline,
                    recommendation = db.recommendation,
                    status = status,
                    financialImpactM = db.financialImpactM,
                    capabilityImpact = db.capabilityImpact,
                    riskImpact = db.riskImpact,
                    dependencies = db.dependencies,
                    options = emptyList(),
                    approvedBy = db.approvedBy,
                    approvalTimestamp = db.approvalTimestamp,
                    contextSummary = db.contextSummary
                )
            }
            map.values.toList()
        }
    }
}
