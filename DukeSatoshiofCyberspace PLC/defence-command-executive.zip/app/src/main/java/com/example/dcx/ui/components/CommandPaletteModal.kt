package com.example.dcx.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.DcxOutline
import com.example.ui.theme.DcxPrimary
import com.example.ui.theme.DcxSurface

data class CommandPaletteItem(
    val title: String,
    val category: String,
    val targetScreenId: String,
    val shortcut: String? = null
)

val COMMAND_PALETTE_ITEMS = listOf(
    CommandPaletteItem("Open Executive Home", "NAVIGATION", "EXECUTIVE"),
    CommandPaletteItem("Open Readiness Engine", "NAVIGATION", "READINESS"),
    CommandPaletteItem("Open Command Hierarchy", "NAVIGATION", "COMMAND_HIERARCHY"),
    CommandPaletteItem("Open Equipment & Fleet", "NAVIGATION", "EQUIPMENT"),
    CommandPaletteItem("Open Maintenance Work Orders", "NAVIGATION", "EQUIPMENT"),
    CommandPaletteItem("Open Logistics & Supply Chain", "NAVIGATION", "LOGISTICS"),
    CommandPaletteItem("Open Personnel Workforce", "NAVIGATION", "PERSONNEL"),
    CommandPaletteItem("Open Finance & Procurement", "NAVIGATION", "FINANCE"),
    CommandPaletteItem("Open Risk Register Matrix", "NAVIGATION", "RISKS"),
    CommandPaletteItem("Open Executive Decision Docket", "NAVIGATION", "DECISIONS"),
    CommandPaletteItem("Open Digital Twin Scenario Engine", "NAVIGATION", "SCENARIOS"),
    CommandPaletteItem("Open Replay & Audit Log", "NAVIGATION", "REPLAY"),
    CommandPaletteItem("Open Base Infrastructure Map", "NAVIGATION", "MAP"),
    CommandPaletteItem("Open DCX Analyst AI Assistant", "NAVIGATION", "ANALYST"),
    CommandPaletteItem("Run Budget Reduction (-10%) Scenario", "ACTION", "SCENARIOS"),
    CommandPaletteItem("Review 155mm Ammunition Shortage", "SEARCH", "LOGISTICS"),
    CommandPaletteItem("Review Challenger 3 Fleet Status", "SEARCH", "EQUIPMENT")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommandPaletteModal(
    onDismiss: () -> Unit,
    onNavigateToScreen: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredItems = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            COMMAND_PALETTE_ITEMS
        } else {
            COMMAND_PALETTE_ITEMS.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                        it.category.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .border(1.dp, DcxPrimary, RoundedCornerShape(8.dp)),
            color = DcxSurface,
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "COMMAND PALETTE [ CTRL + K ]",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = DcxPrimary
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            "Type command or query...",
                            style = MaterialTheme.typography.bodyMedium,
                            fontFamily = FontFamily.Monospace,
                            color = Color.Gray
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = DcxPrimary
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("command_palette_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DcxPrimary,
                        unfocusedBorderColor = DcxOutline
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier.heightIn(max = 320.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(filteredItems) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onNavigateToScreen(item.targetScreenId)
                                    onDismiss()
                                }
                                .background(Color(0xFF1E293B), RoundedCornerShape(4.dp))
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color.White,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = item.category,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF94A3B8),
                                    fontSize = 9.sp
                                )
                            }
                            Text(
                                text = "ENTER ↵",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = DcxPrimary,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
