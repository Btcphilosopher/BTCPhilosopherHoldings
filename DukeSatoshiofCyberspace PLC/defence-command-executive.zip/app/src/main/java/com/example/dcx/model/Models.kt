package com.example.dcx.model

import java.util.UUID

enum class ClassificationLevel(val code: String, val label: String) {
    OFFICIAL("OFFICIAL", "OFFICIAL"),
    OFFICIAL_SENSITIVE("OFFICIAL_SENSITIVE", "OFFICIAL // SENSITIVE"),
    NATO_UNCLASSIFIED("NATO_UNCLASSIFIED", "NATO UNCLASSIFIED"),
    NATO_RESTRICTED("NATO_RESTRICTED", "NATO RESTRICTED")
}

enum class ReadinessStatus(val code: String, val label: String) {
    NOT_READY("NOT_READY", "NOT READY"),
    LIMITED("LIMITED", "LIMITED"),
    PARTIALLY_READY("PARTIALLY_READY", "PARTIALLY READY"),
    READY("READY", "READY"),
    HIGH_READINESS("HIGH_READINESS", "HIGH READINESS")
}

enum class ServiceType(val code: String, val label: String) {
    STRATEGIC_COMMAND("STRATEGIC", "Strategic Command"),
    LAND("LAND", "Land Command"),
    MARITIME("MARITIME", "Maritime Command"),
    AIR("AIR", "Air Command"),
    JOINT("JOINT", "Joint Operations"),
    LOGISTICS("LOGISTICS", "Defence Logistics"),
    MEDICAL("MEDICAL", "Defence Medical"),
    INFRASTRUCTURE("INFRASTRUCTURE", "Defence Infrastructure Organisation"),
    DIGITAL("DIGITAL", "Defence Digital")
}

enum class CommandLevel {
    STRATEGIC, OPERATIONAL, FORMATION, UNIT, SUBUNIT, SUPPORT
}

data class OrganisationUnit(
    val id: String,
    val name: String,
    val code: String,
    val parentId: String?,
    val service: ServiceType,
    val commandLevel: CommandLevel,
    val commanderName: String,
    val commanderRank: String,
    val personnelCount: Int,
    val readinessStatus: ReadinessStatus,
    val readinessScore: Int, // 0..100
    val region: String
)

data class ReadinessDimension(
    val name: String, // e.g. Personnel, Equipment, Maintenance, Training, Logistics, Ammunition, Infrastructure, Command, Comms, Medical, Digital
    val score: Int, // 0..100
    val status: ReadinessStatus,
    val details: String,
    val trend: String, // "+2%", "-4%", "STABLE"
    val lastVerified: String
)

data class ReadinessTransition(
    val transitionId: String = UUID.randomUUID().toString(),
    val timestamp: String,
    val unitName: String,
    val previousState: ReadinessStatus,
    val newState: ReadinessStatus,
    val reason: String,
    val author: String,
    val evidenceRef: String
)

enum class EquipmentCategory(val label: String) {
    LAND("Land Vehicle"),
    MARITIME("Maritime Vessel"),
    AIR("Aircraft"),
    ENGINEERING("Engineering Equipment"),
    COMMUNICATIONS("Comms & C2"),
    MEDICAL("Medical Support"),
    LOGISTICS("Transport & Supply"),
    DIGITAL("Digital & Radar")
}

data class EquipmentAsset(
    val assetId: String,
    val name: String,
    val category: EquipmentCategory,
    val platformType: String,
    val serialReference: String,
    val owningUnit: String,
    val locationRegion: String,
    val status: String, // "Available", "Under Maintenance", "Awaiting Parts", "Training", "Inspection"
    val serviceHours: Int,
    val mtbfHours: Int,
    val mttrHours: Int,
    val readinessContribution: Int // 0..100
)

data class MaintenanceWorkOrder(
    val orderId: String,
    val assetId: String,
    val assetName: String,
    val type: String, // "Scheduled", "Preventive", "Corrective", "Inspection"
    val priority: String, // "CRITICAL", "HIGH", "MEDIUM", "ROUTINE"
    val status: String, // "IN_PROGRESS", "AWAITING_PARTS", "QUEUED", "COMPLETED"
    val technicianTeam: String,
    val hoursSpent: Int,
    val expectedCompletion: String,
    val partDependencies: List<String>
)

data class InventoryItem(
    val itemId: String,
    val name: String,
    val depotName: String,
    val category: String,
    val onHand: Int,
    val reserved: Int,
    val inTransit: Int,
    val backordered: Int,
    val minThreshold: Int,
    val unitOfMeasure: String,
    val status: String // "OPTIMAL", "WARNING", "CRITICAL_SHORTAGE"
)

data class SupplyChainImpact(
    val scenarioName: String,
    val affectedUnits: List<String>,
    val inventoryDepletionDays: Int,
    val expectedDelayDays: Int,
    val financialImpactM: Double,
    val alternativeSources: String,
    val recoveryTimeDays: Int
)

data class PersonnelMetric(
    val category: String,
    val manningPct: Int,
    val vacancies: Int,
    val qualCoveragePct: Int,
    val deploymentAvailabilityPct: Int,
    val specialistShortageCount: Int
)

data class FinanceBudgetCategory(
    val name: String,
    val budgetM: Double,
    val committedM: Double,
    val spentM: Double,
    val forecastM: Double,
    val variancePct: Double
)

enum class ContractStatus(val label: String) {
    DRAFT("Draft"),
    TENDER("Tender"),
    EVALUATION("Evaluation"),
    AWARDED("Awarded"),
    ACTIVE("Active"),
    DELIVERY("Delivery"),
    ACCEPTANCE("Acceptance"),
    DISPUTED("Disputed")
}

data class ProcurementProgramme(
    val id: String,
    val title: String,
    val category: String,
    val supplier: String,
    val budgetM: Double,
    val spentM: Double,
    val status: ContractStatus,
    val timeHealth: String, // "GREEN", "AMBER", "RED"
    val costHealth: String,
    val scopeHealth: String,
    val qualityHealth: String,
    val riskHealth: String,
    val nextMilestone: String,
    val milestoneDate: String
)

enum class RiskCategory(val label: String) {
    STRATEGIC("Strategic"),
    FINANCIAL("Financial"),
    PERSONNEL("Personnel"),
    EQUIPMENT("Equipment"),
    SUPPLY_CHAIN("Supply Chain"),
    CYBER("Cyber"),
    INFRASTRUCTURE("Infrastructure"),
    PROGRAMME("Programme")
}

data class RiskItem(
    val id: String,
    val category: RiskCategory,
    val title: String,
    val description: String,
    val probability: Int, // 1..5
    val impact: Int, // 1..5
    val velocity: String, // "HIGH", "MEDIUM", "LOW"
    val owner: String,
    val mitigation: String,
    val status: String, // "ACTIVE", "MONITORED", "MITIGATED"
    val reviewDate: String
)

enum class DecisionStatus(val label: String) {
    DRAFT("DRAFT"),
    UNDER_REVIEW("UNDER REVIEW"),
    AWAITING_DECISION("AWAITING DECISION"),
    APPROVED("APPROVED"),
    REJECTED("REJECTED"),
    DEFERRED("DEFERRED"),
    IMPLEMENTING("IMPLEMENTING")
}

data class DecisionOption(
    val optionId: String, // "Option A", "Option B", "Option C"
    val title: String,
    val costM: Double,
    val benefit: String,
    val risk: String,
    val timeline: String
)

data class DecisionRecord(
    val id: String,
    val title: String,
    val owner: String,
    val deadline: String,
    val recommendation: String,
    val status: DecisionStatus,
    val financialImpactM: Double,
    val capabilityImpact: String,
    val riskImpact: String,
    val dependencies: String,
    val options: List<DecisionOption>,
    val approvedBy: String? = null,
    val approvalTimestamp: String? = null,
    val contextSummary: String
)

data class BaseFacility(
    val id: String,
    val name: String,
    val type: String, // "Base", "Depot", "Airfield", "Port", "Training Area", "Data Centre"
    val region: String,
    val conditionScore: Int, // 0..100
    val capacityPct: Int,
    val energyResilienceDays: Int,
    val status: String
)

data class CommandEvent(
    val eventId: String = UUID.randomUUID().toString(),
    val timestamp: String,
    val source: String,
    val classification: ClassificationLevel = ClassificationLevel.OFFICIAL_SENSITIVE,
    val actor: String,
    val entityType: String,
    val entityId: String,
    val previousState: String,
    val newState: String,
    val reason: String
)

data class ScenarioSimulationResult(
    val scenarioName: String,
    val p50Readiness: Int,
    val p75Readiness: Int,
    val p90Readiness: Int,
    val budgetDeltaM: Double,
    val personnelShortagePct: Int,
    val logisticsDelayDays: Int,
    val summaryNarrative: String
)
