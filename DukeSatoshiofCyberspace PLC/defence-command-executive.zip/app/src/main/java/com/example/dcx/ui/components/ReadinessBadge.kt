package com.example.dcx.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dcx.model.ReadinessStatus
import com.example.ui.theme.DcxAmber
import com.example.ui.theme.DcxGreen
import com.example.ui.theme.DcxRed

@Composable
fun ReadinessBadge(
    status: ReadinessStatus,
    modifier: Modifier = Modifier
) {
    val colorPair = when (status) {
        ReadinessStatus.HIGH_READINESS, ReadinessStatus.READY -> Pair(Color(0xFF064E3B), DcxGreen)
        ReadinessStatus.PARTIALLY_READY, ReadinessStatus.LIMITED -> Pair(Color(0xFF78350F), DcxAmber)
        ReadinessStatus.NOT_READY -> Pair(Color(0xFF7F1D1D), DcxRed)
    }
    val badgeBg = colorPair.first
    val textFg = colorPair.second

    Box(
        modifier = modifier
            .background(badgeBg, RoundedCornerShape(3.dp))
            .border(1.dp, textFg, RoundedCornerShape(3.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = status.label,
            style = MaterialTheme.typography.labelSmall,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = textFg,
            fontSize = 9.sp
        )
    }
}
