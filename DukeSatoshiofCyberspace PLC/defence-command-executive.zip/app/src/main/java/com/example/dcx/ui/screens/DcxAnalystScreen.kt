package com.example.dcx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dcx.engine.AnalystResponse
import com.example.dcx.engine.DcxAnalystEngine
import com.example.ui.theme.DcxAmber
import com.example.ui.theme.DcxGreen
import com.example.ui.theme.DcxOutline
import com.example.ui.theme.DcxPrimary
import com.example.ui.theme.DcxSurface

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DcxAnalystScreen(modifier: Modifier = Modifier) {
    var queryText by remember { mutableStateOf("") }
    var activeResponse by remember { mutableStateOf<AnalystResponse?>(null) }

    val presetQueries = listOf(
        "Why did readiness decline?",
        "Which programmes are behind schedule?",
        "Where are the largest equipment availability problems?",
        "What decisions are waiting for approval?",
        "Which risks require executive attention?"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color(0xFFEAB308),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "DCX ANALYST — EXECUTIVE AI ASSISTANT",
                            style = MaterialTheme.typography.titleMedium,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = DcxPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "TRANSPARENT PROVENANCE, DATA SOURCES & SAFETY BOUNDARY ENFORCEMENT",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray,
                        fontSize = 9.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = queryText,
                        onValueChange = { queryText = it },
                        placeholder = {
                            Text("Ask executive question...", style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace, color = Color.Gray)
                        },
                        trailingIcon = {
                            IconButton(
                                onClick = {
                                    if (queryText.isNotBlank()) {
                                        activeResponse = DcxAnalystEngine.processQuery(queryText)
                                    }
                                },
                                modifier = Modifier.testTag("submit_analyst_query_btn")
                            ) {
                                Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = DcxPrimary)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("analyst_query_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = DcxPrimary,
                            unfocusedBorderColor = DcxOutline
                        )
                    )
                }
            }
        }

        item {
            Text(
                text = "PRESET EXECUTIVE QUERIES:",
                style = MaterialTheme.typography.titleSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        items(presetQueries) { preset ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        queryText = preset
                        activeResponse = DcxAnalystEngine.processQuery(preset)
                    }
                    .background(Color(0xFF1E293B), RoundedCornerShape(4.dp))
                    .border(1.dp, DcxOutline, RoundedCornerShape(4.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "▶ $preset",
                    style = MaterialTheme.typography.bodyMedium,
                    fontFamily = FontFamily.Monospace,
                    color = Color.White,
                    fontSize = 11.sp
                )
            }
        }

        activeResponse?.let { resp ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DcxPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "QUERY: \"${resp.query}\"",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = Color.Gray,
                            fontSize = 10.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = resp.summaryAnswer,
                            style = MaterialTheme.typography.bodyLarge,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = DcxOutline)
                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "CALCULATION PROVENANCE & TRANSPARENCY:",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = DcxPrimary,
                            fontSize = 10.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(text = "DATA SOURCES: ${resp.dataSources.joinToString()}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = Color(0xFFCBD5E1), fontSize = 9.sp)
                        Text(text = "TIME PERIOD: ${resp.timePeriod}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = Color(0xFFCBD5E1), fontSize = 9.sp)
                        Text(text = "CALCULATION: ${resp.calculationMethod}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = Color(0xFFCBD5E1), fontSize = 9.sp)
                        Text(text = "ASSUMPTIONS: ${resp.assumptions.joinToString()}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = Color(0xFFCBD5E1), fontSize = 9.sp)
                        Text(text = "CONFIDENCE: ${resp.confidenceRating}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = DcxGreen, fontSize = 9.sp)
                        Text(text = "LIMITATIONS: ${resp.limitations}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = DcxAmber, fontSize = 9.sp)
                    }
                }
            }
        }
    }
}
