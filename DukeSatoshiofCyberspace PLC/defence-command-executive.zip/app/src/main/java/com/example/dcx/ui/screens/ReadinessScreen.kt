package com.example.dcx.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dcx.data.SyntheticData
import com.example.dcx.engine.ReadinessEngine
import com.example.dcx.ui.components.ReadinessBadge
import com.example.dcx.ui.components.StatusProgressBar
import com.example.ui.theme.DcxAmber
import com.example.ui.theme.DcxGreen
import com.example.ui.theme.DcxOutline
import com.example.ui.theme.DcxPrimary
import com.example.ui.theme.DcxSurface

@Composable
fun ReadinessScreen(modifier: Modifier = Modifier) {
    val overallScore = remember { ReadinessEngine.calculateOverallReadiness() }
    val overallStatus = remember { ReadinessEngine.getOverallReadinessStatus(overallScore) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "DEFENCE READINESS ENGINE",
                                style = MaterialTheme.typography.titleMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = DcxPrimary
                            )
                            Text(
                                text = "MULTIDIMENSIONAL AGGREGATION MODEL",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Gray,
                                fontSize = 9.sp
                            )
                        }
                        ReadinessBadge(status = overallStatus)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    StatusProgressBar(label = "OVERALL DEFENCE READINESS INDEX", score = overallScore)
                }
            }
        }

        item {
            Text(
                text = "10 DEFENCE READINESS DIMENSIONS",
                style = MaterialTheme.typography.titleSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        items(SyntheticData.READINESS_DIMENSIONS) { dim ->
            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = dim.name,
                            style = MaterialTheme.typography.bodyLarge,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = dim.trend,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = if (dim.trend.startsWith("+")) DcxGreen else if (dim.trend.startsWith("-")) DcxAmber else Color.Gray,
                                fontSize = 10.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            ReadinessBadge(status = dim.status)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    StatusProgressBar(label = "Dimension Score", score = dim.score)

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = dim.details,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFFCBD5E1),
                        fontSize = 11.sp
                    )
                    Text(
                        text = "LAST VERIFIED: ${dim.lastVerified}",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF64748B),
                        fontSize = 9.sp
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "READINESS STATE TRANSITION HISTORY",
                style = MaterialTheme.typography.titleSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        items(SyntheticData.READINESS_TRANSITIONS) { tr ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = tr.unitName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = DcxPrimary
                        )
                        Text(
                            text = tr.timestamp,
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = Color.Gray,
                            fontSize = 9.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ReadinessBadge(status = tr.previousState)
                        Text("→", color = Color.White, fontFamily = FontFamily.Monospace)
                        ReadinessBadge(status = tr.newState)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Reason: ${tr.reason}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "Author: ${tr.author} | Evidence Ref: ${tr.evidenceRef}",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp
                    )
                }
            }
        }
    }
}
