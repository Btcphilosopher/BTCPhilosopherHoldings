package com.example.dcx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dcx.data.SyntheticData
import com.example.dcx.ui.components.StatusProgressBar
import com.example.ui.theme.DcxAmber
import com.example.ui.theme.DcxGreen
import com.example.ui.theme.DcxOutline
import com.example.ui.theme.DcxPrimary
import com.example.ui.theme.DcxRed
import com.example.ui.theme.DcxSurface

@Composable
fun EquipmentMaintenanceScreen(modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "EQUIPMENT FLEET & MAINTENANCE ENGINE",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = DcxPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF1E293B), RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "ℹ️ PREDICTIVE MAINTENANCE NOTICE: INSUFFICIENT HISTORICAL DATA FOR AUTONOMOUS PREDICTIVE MODELLING. DISPLAYING VERIFIED OBSERVED TELEMETRY & MWOs.",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = DcxAmber,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "FLEET ASSETS & AVAILABILITY",
                style = MaterialTheme.typography.titleSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        items(SyntheticData.EQUIPMENT_ASSETS) { asset ->
            val statusColor = when (asset.status) {
                "Available" -> DcxGreen
                "Under Maintenance" -> DcxAmber
                else -> DcxRed
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = asset.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "${asset.category.label} | ${asset.serialReference} | ${asset.owningUnit}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF94A3B8),
                                fontSize = 9.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .background(statusColor.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                .border(1.dp, statusColor, RoundedCornerShape(3.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = asset.status,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = statusColor,
                                fontSize = 9.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "SERVICE HRS: ${asset.serviceHours}h", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = Color.Gray, fontSize = 10.sp)
                        Text(text = "MTBF: ${asset.mtbfHours}h", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = Color.Gray, fontSize = 10.sp)
                        Text(text = "MTTR: ${asset.mttrHours}h", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = Color.Gray, fontSize = 10.sp)
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    StatusProgressBar(label = "Readiness Contribution", score = asset.readinessContribution)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "ACTIVE MAINTENANCE WORK ORDERS (MWO)",
                style = MaterialTheme.typography.titleSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        items(SyntheticData.MAINTENANCE_WORK_ORDERS) { mwo ->
            val priorityColor = when (mwo.priority) {
                "CRITICAL" -> DcxRed
                "HIGH" -> DcxAmber
                else -> DcxGreen
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "[${mwo.orderId}] ${mwo.assetName}",
                            style = MaterialTheme.typography.bodyLarge,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = DcxPrimary,
                            fontSize = 12.sp
                        )
                        Box(
                            modifier = Modifier
                                .background(priorityColor.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                .border(1.dp, priorityColor, RoundedCornerShape(3.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = mwo.priority,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = priorityColor,
                                fontSize = 9.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "TYPE: ${mwo.type} | STATUS: ${mwo.status} | ETA: ${mwo.expectedCompletion}",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "TEAM: ${mwo.technicianTeam} (${mwo.hoursSpent} hrs logged)",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp
                    )

                    if (mwo.partDependencies.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "PARTS DEPENDENCY: ${mwo.partDependencies.joinToString()}",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = DcxAmber,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }
    }
}
