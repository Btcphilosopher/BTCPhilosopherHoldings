package com.example.dcx.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DcxAmber
import com.example.ui.theme.DcxGreen
import com.example.ui.theme.DcxRed

@Composable
fun StatusProgressBar(
    label: String,
    score: Int,
    modifier: Modifier = Modifier
) {
    val statusColor = when {
        score >= 80 -> DcxGreen
        score >= 65 -> DcxAmber
        else -> DcxRed
    }

    val totalBlocks = 10
    val filledBlocks = (score / 10.0).toInt().coerceIn(0, totalBlocks)
    val emptyBlocks = totalBlocks - filledBlocks
    val asciiBar = "█".repeat(filledBlocks) + "░".repeat(emptyBlocks)

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontSize = 12.sp
            )
            Text(
                text = "$score%",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = statusColor,
                fontSize = 12.sp
            )
        }
        Spacer(modifier = Modifier.height(3.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = asciiBar,
                style = MaterialTheme.typography.bodyMedium,
                fontFamily = FontFamily.Monospace,
                color = statusColor,
                letterSpacing = 1.sp,
                fontSize = 13.sp
            )
        }
    }
}
