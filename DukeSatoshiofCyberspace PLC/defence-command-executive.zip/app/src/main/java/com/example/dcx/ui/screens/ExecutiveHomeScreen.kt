package com.example.dcx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dcx.ui.components.StatusProgressBar
import com.example.ui.theme.DcxAmber
import com.example.ui.theme.DcxGreen
import com.example.ui.theme.DcxOutline
import com.example.ui.theme.DcxPrimary
import com.example.ui.theme.DcxRed
import com.example.ui.theme.DcxSurface

data class StatusItem(val label: String, val statusText: String, val color: Color)
data class PriorityItem(val num: String, val text: String, val targetScreen: String)
data class TodayStatItem(val label: String, val count: String, val color: Color)

@Composable
fun ExecutiveHomeScreen(
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // TOP STATUS GRID
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "DEFENCE STATUS SUMMARY",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = DcxPrimary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val statusList = listOf(
                        StatusItem("READINESS", "GREEN", DcxGreen),
                        StatusItem("PERSONNEL", "AMBER", DcxAmber),
                        StatusItem("EQUIPMENT", "GREEN", DcxGreen),
                        StatusItem("LOGISTICS", "AMBER", DcxAmber),
                        StatusItem("TRAINING", "GREEN", DcxGreen),
                        StatusItem("FINANCE", "AMBER", DcxAmber),
                        StatusItem("PROCUREMENT", "RED", DcxRed),
                        StatusItem("INFRASTRUCTURE", "AMBER", DcxAmber),
                        StatusItem("DIGITAL", "GREEN", DcxGreen),
                        StatusItem("CYBER", "AMBER", DcxAmber)
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        statusList.chunked(2).forEach { row ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                row.forEach { item ->
                                    Row(
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(horizontal = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = item.label.padEnd(14, ' '),
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontFamily = FontFamily.Monospace,
                                            color = Color(0xFFCBD5E1),
                                            fontSize = 11.sp
                                        )
                                        Text(
                                            text = item.statusText,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = item.color,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // EXECUTIVE PRIORITIES
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "EXECUTIVE PRIORITIES REQUIRING ATTENTION",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = DcxPrimary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val priorities = listOf(
                        PriorityItem("01", "Critical procurement decision (£280M Munitions Stockpile)", "DECISIONS"),
                        PriorityItem("02", "Equipment availability variance (Challenger 3 & A400M)", "EQUIPMENT"),
                        PriorityItem("03", "Logistics capacity constraint (155mm shell stockpile)", "LOGISTICS"),
                        PriorityItem("04", "Personnel shortfall (Nuclear engineer & Cyber retention)", "PERSONNEL"),
                        PriorityItem("05", "Infrastructure programme delay (Devonport Dock 9 power grid)", "MAP")
                    )

                    priorities.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { onNavigate(item.targetScreen) }
                                .background(Color(0xFF1E293B), RoundedCornerShape(4.dp))
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.num,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = DcxPrimary,
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = item.text,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color.White,
                                    fontSize = 11.sp
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Drill down",
                                tint = DcxPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        // TODAY METRICS
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "TODAY SUMMARY & EXCEPTIONS",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = DcxPrimary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val todayStats = listOf(
                        TodayStatItem("Decisions required", "12", DcxAmber),
                        TodayStatItem("Critical risks", "4", DcxRed),
                        TodayStatItem("Overdue actions", "8", DcxAmber),
                        TodayStatItem("Major programme changes", "3", DcxPrimary),
                        TodayStatItem("Readiness exceptions", "17", DcxRed)
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        todayStats.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = item.label,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = item.count,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = item.color,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // COMMAND VIEW
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "COMMAND READINESS VIEW",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = DcxPrimary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    StatusProgressBar(label = "LAND", score = 74)
                    Spacer(modifier = Modifier.height(6.dp))
                    StatusProgressBar(label = "MARITIME", score = 82)
                    Spacer(modifier = Modifier.height(6.dp))
                    StatusProgressBar(label = "AIR", score = 84)
                    Spacer(modifier = Modifier.height(6.dp))
                    StatusProgressBar(label = "JOINT", score = 70)
                    Spacer(modifier = Modifier.height(6.dp))
                    StatusProgressBar(label = "SUPPORT", score = 88)
                }
            }
        }
    }
}
