package com.example.dcx.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DcxDao {
    @Query("SELECT * FROM command_events ORDER BY timestamp DESC")
    fun getAllEvents(): Flow<List<EventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: EventEntity)

    @Query("SELECT * FROM audit_records ORDER BY timestamp DESC")
    fun getAllAuditRecords(): Flow<List<AuditEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditRecord(audit: AuditEntity)

    @Query("SELECT * FROM user_decisions ORDER BY deadline ASC")
    fun getAllDecisions(): Flow<List<DecisionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDecision(decision: DecisionEntity)

    @Query("UPDATE user_decisions SET status = :status, approvedBy = :approvedBy, approvalTimestamp = :timestamp WHERE id = :id")
    suspend fun updateDecisionStatus(id: String, status: String, approvedBy: String, timestamp: String)

    @Query("SELECT * FROM custom_risks ORDER BY (probability * impact) DESC")
    fun getAllRisks(): Flow<List<RiskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRisk(risk: RiskEntity)
}
