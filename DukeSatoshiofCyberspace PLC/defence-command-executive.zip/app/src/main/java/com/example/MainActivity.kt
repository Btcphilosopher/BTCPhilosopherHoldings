package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.dcx.ui.components.ClassificationBanner
import com.example.dcx.ui.components.CommandPaletteModal
import com.example.dcx.ui.components.ExecutiveTopHeader
import com.example.dcx.ui.screens.*
import com.example.dcx.viewmodel.DcxViewModel
import com.example.ui.theme.DcxPrimary
import com.example.ui.theme.DcxSurface
import com.example.ui.theme.DcxTheme

class MainActivity : ComponentActivity() {

    private val viewModel: DcxViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DcxTheme {
                val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
                val isCommandPaletteOpen by viewModel.isCommandPaletteOpen.collectAsStateWithLifecycle()

                val eventsStream by viewModel.eventsStream.collectAsStateWithLifecycle()
                val decisionsStream by viewModel.decisionsStream.collectAsStateWithLifecycle()
                val auditStream by viewModel.auditStream.collectAsStateWithLifecycle()

                if (currentScreen != "EXECUTIVE") {
                    BackHandler {
                        viewModel.navigateTo("EXECUTIVE")
                    }
                }

                Scaffold(
                    topBar = {
                        Column {
                            ClassificationBanner()
                            ExecutiveTopHeader(
                                currentRole = "CHIEF OF THE DEFENCE STAFF",
                                onOpenCommandPalette = { viewModel.toggleCommandPalette(true) },
                                onOpenAnalyst = { viewModel.navigateTo("ANALYST") }
                            )
                        }
                    },
                    bottomBar = {
                        DcxBottomNavigationBar(
                            currentScreen = currentScreen,
                            onSelectScreen = { viewModel.navigateTo(it) }
                        )
                    },
                    containerColor = MaterialTheme.colorScheme.background,
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentScreen) {
                            "EXECUTIVE" -> ExecutiveHomeScreen(onNavigate = { viewModel.navigateTo(it) })
                            "READINESS" -> ReadinessScreen()
                            "COMMAND_HIERARCHY" -> CommandHierarchyScreen()
                            "EQUIPMENT" -> EquipmentMaintenanceScreen()
                            "LOGISTICS" -> LogisticsDigitalTwinScreen()
                            "PERSONNEL" -> PersonnelTrainingScreen()
                            "FINANCE" -> FinanceProcurementScreen()
                            "RISKS" -> RiskRegisterScreen()
                            "DECISIONS" -> DecisionManagementScreen(
                                decisions = decisionsStream,
                                onApproveDecision = { viewModel.approveDecision(it) }
                            )
                            "SCENARIOS" -> ScenarioDigitalTwinScreen()
                            "REPLAY" -> ReplayAuditScreen(
                                eventsStream = eventsStream,
                                auditStream = auditStream
                            )
                            "MAP" -> ExecutiveMapScreen()
                            "ANALYST" -> DcxAnalystScreen()
                            else -> ExecutiveHomeScreen(onNavigate = { viewModel.navigateTo(it) })
                        }
                    }

                    if (isCommandPaletteOpen) {
                        CommandPaletteModal(
                            onDismiss = { viewModel.toggleCommandPalette(false) },
                            onNavigateToScreen = { screen ->
                                viewModel.navigateTo(screen)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DcxBottomNavigationBar(
    currentScreen: String,
    onSelectScreen: (String) -> Unit
) {
    val navItems = listOf(
        Triple("EXECUTIVE", "Home", Icons.Default.Dashboard),
        Triple("READINESS", "Readiness", Icons.Default.Verified),
        Triple("EQUIPMENT", "Fleet", Icons.Default.Build),
        Triple("LOGISTICS", "Logistics", Icons.Default.LocalShipping),
        Triple("RISKS", "Risks", Icons.Default.Warning),
        Triple("DECISIONS", "Decisions", Icons.Default.Gavel),
        Triple("SCENARIOS", "Twin", Icons.Default.Memory),
        Triple("ANALYST", "Analyst", Icons.Default.AutoAwesome)
    )

    NavigationBar(
        containerColor = DcxSurface,
        tonalElevation = 8.dp,
        modifier = Modifier.height(64.dp)
    ) {
        navItems.forEach { (id, label, icon) ->
            val isSelected = currentScreen == id
            NavigationBarItem(
                selected = isSelected,
                onClick = { onSelectScreen(id) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        modifier = Modifier.size(18.dp)
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 9.sp,
                        maxLines = 1
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = DcxPrimary,
                    selectedTextColor = DcxPrimary,
                    unselectedIconColor = Color.Gray,
                    unselectedTextColor = Color.Gray,
                    indicatorColor = Color(0xFF1E293B)
                ),
                modifier = Modifier.testTag("nav_item_$id")
            )
        }
    }
}
