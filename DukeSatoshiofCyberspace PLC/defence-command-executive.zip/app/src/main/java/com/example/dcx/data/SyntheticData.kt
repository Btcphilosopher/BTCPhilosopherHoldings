package com.example.dcx.data

import com.example.dcx.model.*

object SyntheticData {

    val ORGANISATION_UNITS = listOf(
        OrganisationUnit(
            id = "ORG-MOD-01",
            name = "Ministry of Defence Main Building",
            code = "MOD-HQ",
            parentId = null,
            service = ServiceType.STRATEGIC_COMMAND,
            commandLevel = CommandLevel.STRATEGIC,
            commanderName = "Chief of the Defence Staff",
            commanderRank = "Gen / Adm / Air Chf Mshl",
            personnelCount = 3800,
            readinessStatus = ReadinessStatus.HIGH_READINESS,
            readinessScore = 92,
            region = "Whitehall, London"
        ),
        OrganisationUnit(
            id = "ORG-STRAT-01",
            name = "Strategic Command HQ",
            code = "STRATCOM",
            parentId = "ORG-MOD-01",
            service = ServiceType.STRATEGIC_COMMAND,
            commandLevel = CommandLevel.STRATEGIC,
            commanderName = "Gen Sir James Hockenhull",
            commanderRank = "General (4-Star)",
            personnelCount = 14200,
            readinessStatus = ReadinessStatus.READY,
            readinessScore = 88,
            region = "Northwood Headquarters"
        ),
        OrganisationUnit(
            id = "ORG-LAND-01",
            name = "Land Command HQ",
            code = "LAND-HQ",
            parentId = "ORG-MOD-01",
            service = ServiceType.LAND,
            commandLevel = CommandLevel.OPERATIONAL,
            commanderName = "Lt Gen Sir Ralph Wooddisse",
            commanderRank = "Lieutenant General (3-Star)",
            personnelCount = 74500,
            readinessStatus = ReadinessStatus.PARTIALLY_READY,
            readinessScore = 74,
            region = "Marlborough Lines, Andover"
        ),
        OrganisationUnit(
            id = "ORG-MARITIME-01",
            name = "Navy Command HQ",
            code = "MARITIME-HQ",
            parentId = "ORG-MOD-01",
            service = ServiceType.MARITIME,
            commandLevel = CommandLevel.OPERATIONAL,
            commanderName = "Adm Sir Ben Key",
            commanderRank = "Admiral (4-Star)",
            personnelCount = 33800,
            readinessStatus = ReadinessStatus.READY,
            readinessScore = 82,
            region = "HMS Excellent, Portsmouth"
        ),
        OrganisationUnit(
            id = "ORG-AIR-01",
            name = "Air Command HQ",
            code = "AIR-HQ",
            parentId = "ORG-MOD-01",
            service = ServiceType.AIR,
            commandLevel = CommandLevel.OPERATIONAL,
            commanderName = "Air Chf Mshl Sir Harvey Smyth",
            commanderRank = "Air Chief Marshal (4-Star)",
            personnelCount = 32900,
            readinessStatus = ReadinessStatus.READY,
            readinessScore = 84,
            region = "RAF High Wycombe"
        ),
        OrganisationUnit(
            id = "ORG-LOG-01",
            name = "Defence Logistics Command",
            code = "DE&S-LOG",
            parentId = "ORG-STRAT-01",
            service = ServiceType.LOGISTICS,
            commandLevel = CommandLevel.FORMATION,
            commanderName = "Air Mshl Richard Maddison",
            commanderRank = "Air Marshal",
            personnelCount = 11200,
            readinessStatus = ReadinessStatus.LIMITED,
            readinessScore = 69,
            region = "Abbey Wood, Bristol"
        ),
        OrganisationUnit(
            id = "ORG-DIGITAL-01",
            name = "Defence Digital & Cyber Command",
            code = "DEF-DIGITAL",
            parentId = "ORG-STRAT-01",
            service = ServiceType.DIGITAL,
            commandLevel = CommandLevel.FORMATION,
            commanderName = "Maj Gen Tom Copinger-Symes",
            commanderRank = "Major General",
            personnelCount = 6800,
            readinessStatus = ReadinessStatus.READY,
            readinessScore = 86,
            region = "MOD Corsham, Wiltshire"
        )
    )

    val READINESS_DIMENSIONS = listOf(
        ReadinessDimension("Personnel", 82, ReadinessStatus.READY, "Manning targets at 94%, key specialist gaps in cyber and engineering", "+1.2%", "2026-10-06 04:00"),
        ReadinessDimension("Equipment Availability", 71, ReadinessStatus.PARTIALLY_READY, "Challenger 3 upgrade queue & Wildcat rotor assembly backlogs", "-3.5%", "2026-10-06 05:15"),
        ReadinessDimension("Maintenance Burden", 68, ReadinessStatus.LIMITED, "Depot throughput bottleneck at Bovington and Devonport Yard 9", "-2.1%", "2026-10-06 03:30"),
        ReadinessDimension("Training Compliance", 88, ReadinessStatus.READY, "Ex Marion Strike completed, pilots meeting annual flying hours", "+4.0%", "2026-10-05 18:00"),
        ReadinessDimension("Logistics & Munitions", 69, ReadinessStatus.LIMITED, "155mm artillery shell stockpile drawdown & contractor lead times", "-5.0%", "2026-10-06 02:45"),
        ReadinessDimension("Ammunition Stockpiles", 64, ReadinessStatus.LIMITED, "Precision guided munition reserves undergoing replenishment contracts", "-1.8%", "2026-10-05 22:10"),
        ReadinessDimension("Infrastructure Condition", 78, ReadinessStatus.READY, "RAF Marham runway resurfaced; Faslane jetty maintenance on track", "STABLE", "2026-10-06 01:00"),
        ReadinessDimension("C4ISR & Communications", 91, ReadinessStatus.HIGH_READINESS, "Skynet 5 satellite constellation operational, Bowman tactical radio stable", "+0.5%", "2026-10-06 05:30"),
        ReadinessDimension("Medical Readiness", 85, ReadinessStatus.READY, "Role 3 hospital deployed exercises compliant; trauma supply stock optimal", "STABLE", "2026-10-05 19:40"),
        ReadinessDimension("Cyber & Digital Health", 89, ReadinessStatus.HIGH_READINESS, "Zero-Trust architecture active; threat telemetry clear in Sector 4", "+1.1%", "2026-10-06 05:45")
    )

    val READINESS_TRANSITIONS = listOf(
        ReadinessTransition("TR-901", "2026-10-06 04:12", "Navy Command HQ", ReadinessStatus.PARTIALLY_READY, ReadinessStatus.READY, "HMS Queen Elizabeth completed maintenance sea trials", "Fleet Commander", "RPT-RN-2026-88"),
        ReadinessTransition("TR-902", "2026-10-05 21:30", "Defence Logistics Command", ReadinessStatus.READY, ReadinessStatus.LIMITED, "Tier-1 supplier delay on Challenger 3 hydraulic sub-assemblies", "Director Logistics", "DE&S-RA-4091"),
        ReadinessTransition("TR-903", "2026-10-05 14:05", "Air Command HQ", ReadinessStatus.PARTIALLY_READY, ReadinessStatus.READY, "Typhoon Tranche 3 radar software update verified across No. 1 Group", "Air Officer Commanding 1Gp", "RAF-AC-7721"),
        ReadinessTransition("TR-904", "2026-10-04 11:50", "Land Command HQ", ReadinessStatus.LIMITED, ReadinessStatus.PARTIALLY_READY, "12th Armoured Armoured Infantry Brigade exercise validation", "Commander Field Army", "LAND-EV-3310")
    )

    val EQUIPMENT_ASSETS = listOf(
        EquipmentAsset("EQ-LND-001", "Challenger 3 MBT (Fleet Batch A)", EquipmentCategory.LAND, "Main Battle Tank", "CR3-SN-4011", "3rd (UK) Division", "Bovington Depot", "Under Maintenance", 1420, 380, 72, 65),
        EquipmentAsset("EQ-LND-002", "Ajax Armoured Vehicle (CT40)", EquipmentCategory.LAND, "Reconnaissance", "AJX-SN-1092", "1st Deep Reconnaissance Strike Bde", "Tidworth Garrison", "Available", 850, 520, 36, 88),
        EquipmentAsset("EQ-MAR-001", "HMS Queen Elizabeth (R08)", EquipmentCategory.MARITIME, "Fleet Aircraft Carrier", "R08-RN-001", "Navy Command Fleet", "Portsmouth Naval Base", "Available", 18400, 1200, 240, 95),
        EquipmentAsset("EQ-MAR-002", "HMS Vanguard (S28)", EquipmentCategory.MARITIME, "Vanguard SSBN", "S28-RN-002", "Submarine Service", "Faslane Naval Base", "Available", 32100, 2500, 360, 99),
        EquipmentAsset("EQ-MAR-003", "HMS Dauntless (Type 45 Destroyer)", EquipmentCategory.MARITIME, "Guided Missile Destroyer", "D33-RN-003", "Surface Flotilla", "Devonport Dockyard", "Under Maintenance", 12800, 890, 180, 70),
        EquipmentAsset("EQ-AIR-001", "F-35B Lightning II (617 Sqn Batch)", EquipmentCategory.AIR, "Stealth Multi-Role Fighter", "F35-UK-104", "No. 1 Group RAF", "RAF Marham", "Available", 1150, 450, 24, 92),
        EquipmentAsset("EQ-AIR-002", "Eurofighter Typhoon FGR4", EquipmentCategory.AIR, "Multi-Role Fighter", "TYP-UK-308", "No. 1 Group RAF", "RAF Lossiemouth", "Available", 3400, 610, 30, 90),
        EquipmentAsset("EQ-AIR-003", "A400M Atlas C1 Transport", EquipmentCategory.AIR, "Strategic Tactical Airlift", "A400-UK-012", "No. 2 Group RAF", "RAF Brize Norton", "Awaiting Parts", 2800, 410, 96, 60),
        EquipmentAsset("EQ-DIG-001", "Skynet 5D Military Comms Sat", EquipmentCategory.DIGITAL, "Geostationary Comms", "SAT-SK5D-01", "Strategic Command Digital", "Orbit Sector 3", "Available", 45000, 10000, 12, 98),
        EquipmentAsset("EQ-LOG-001", "MAN SV 8x8 Support Vehicle Fleet", EquipmentCategory.LOGISTICS, "Heavy Logistics Transport", "MAN-UK-8840", "104 Operational Sustainment Bde", "Donnington Logistics Hub", "Available", 8900, 750, 18, 85)
    )

    val MAINTENANCE_WORK_ORDERS = listOf(
        MaintenanceWorkOrder("MWO-2026-104", "EQ-LND-001", "Challenger 3 Fleet Batch A", "Corrective", "CRITICAL", "AWAITING_PARTS", "RME 4th Armoured Battalion", 48, "2026-10-14", listOf("Hydraulic Pump Assembly #H-88", "Turret Ring Bearing B-2")),
        MaintenanceWorkOrder("MWO-2026-092", "EQ-MAR-003", "HMS Dauntless (Type 45)", "Scheduled", "HIGH", "IN_PROGRESS", "Devonport Yard Engineer Team 3", 140, "2026-10-22", listOf("Power Improvement Package (PIP) Diesel Generator")),
        MaintenanceWorkOrder("MWO-2026-118", "EQ-AIR-003", "A400M Atlas C1 Transport", "Corrective", "HIGH", "QUEUED", "RAF Brize Norton Engineering Wing", 12, "2026-10-10", listOf("Main Landing Gear Actuator Assembly")),
        MaintenanceWorkOrder("MWO-2026-085", "EQ-LND-002", "Ajax CT40 Reconnaissance", "Inspection", "MEDIUM", "IN_PROGRESS", "ATDU Bovington Test Team", 28, "2026-10-08", listOf("Acoustic Sensor Dampening Bracket"))
    )

    val LOGISTICS_INVENTORY = listOf(
        InventoryItem("INV-155-SHELL", "155mm High Explosive Artillery Rounds", "Donnington Central Ammunition Depot", "Ammunition", 14200, 3200, 1800, 4500, 15000, "Rounds", "WARNING"),
        InventoryItem("INV-CH3-POWER", "Challenger 3 Power Pack Assemblies", "Bovington Armoured Depot", "Spares", 18, 6, 2, 8, 20, "Units", "WARNING"),
        InventoryItem("INV-F35-TIRE", "F-35B Main Landing Gear Tires", "RAF Marham Logistics Depot", "Aviation Spares", 64, 16, 20, 0, 40, "Tires", "OPTIMAL"),
        InventoryItem("INV-DIESEL-N5", "F-76 Naval Distillate Fuel", "Portsmouth Fuel Depot", "Fuel & Oils", 85000, 22000, 15000, 0, 50000, "Metric Tonnes", "OPTIMAL"),
        InventoryItem("INV-NLAW-MIS", "NLAW Anti-Tank Guided Missiles", "KinetiQ Ordnance Storage", "Guided Munitions", 2800, 400, 600, 1200, 3000, "Missiles", "WARNING")
    )

    val PERSONNEL_METRICS = listOf(
        PersonnelMetric("Land Command Regulars", 91, 4200, 84, 88, 680),
        PersonnelMetric("Royal Navy Regulars", 95, 1400, 89, 92, 210),
        PersonnelMetric("Royal Air Force Regulars", 96, 1100, 91, 94, 180),
        PersonnelMetric("Strategic & Cyber Command", 88, 920, 82, 85, 410),
        PersonnelMetric("Army Reserve Force", 78, 6500, 72, 70, 1250)
    )

    val FINANCE_CATEGORIES = listOf(
        FinanceBudgetCategory("Equipment Procurement", 12400.0, 11200.0, 8900.0, 12650.0, 2.02),
        FinanceBudgetCategory("Equipment Support & Maintenance", 8200.0, 7900.0, 6100.0, 8350.0, 1.83),
        FinanceBudgetCategory("Personnel Costs & Pensions", 14800.0, 14800.0, 11100.0, 14800.0, 0.0),
        FinanceBudgetCategory("Infrastructure & Estates (DIO)", 4600.0, 4300.0, 3200.0, 4850.0, 5.43),
        FinanceBudgetCategory("Research, Technology & Innovation", 2200.0, 1950.0, 1400.0, 2180.0, -0.91),
        FinanceBudgetCategory("Digital, IT & Cyber Services", 3100.0, 2950.0, 2200.0, 3120.0, 0.65)
    )

    val PROCUREMENT_PROGRAMMES = listOf(
        ProcurementProgramme("PRG-AJAX", "Ajax Armoured Cavalry Fleet", "Land Capability", "General Dynamics UK", 5500.0, 4200.0, ContractStatus.DELIVERY, "AMBER", "RED", "AMBER", "GREEN", "AMBER", "Full Operating Capability Batch 2", "2026-11-15"),
        ProcurementProgramme("PRG-T31", "Type 31 Inspiration Class Frigates", "Maritime Capability", "Babcock International", 2000.0, 1450.0, ContractStatus.ACTIVE, "GREEN", "GREEN", "GREEN", "GREEN", "GREEN", "HMS Venturer Sea Trials", "2026-12-01"),
        ProcurementProgramme("PRG-FCAS", "Global Combat Air Programme (Tempest)", "Air Capability", "BAE Systems / Leonardo / MBDA", 12000.0, 2800.0, ContractStatus.ACTIVE, "GREEN", "GREEN", "GREEN", "GREEN", "AMBER", "Demonstrator First Flight Prep", "2027-03-30"),
        ProcurementProgramme("PRG-CR3", "Challenger 3 Main Battle Tank Upgrade", "Land Capability", "Rheinmetall BAE Systems Land", 1300.0, 820.0, ContractStatus.DELIVERY, "AMBER", "AMBER", "GREEN", "GREEN", "AMBER", "Prototype 8 Live Fire Validation", "2026-10-28"),
        ProcurementProgramme("PRG-SK6", "Skynet 6A Military Satellite Comms", "Digital Capability", "Airbus Defence & Space", 500.0, 380.0, ContractStatus.DELIVERY, "GREEN", "GREEN", "GREEN", "GREEN", "GREEN", "Satellite Launch Vehicle Integration", "2026-12-10")
    )

    val RISK_REGISTER = listOf(
        RiskItem("RSK-SUP-01", RiskCategory.SUPPLY_CHAIN, "Critical Munition Component Supply Bottleneck", "Single-source contractor lead time for energetics exceeded 18 months, impacting 155mm & NLAW replenishment.", 4, 5, "HIGH", "Director Logistics (DE&S)", "Contractual diversification & dual-sourcing framework with BAE Ordnance.", "ACTIVE", "2026-10-15"),
        RiskItem("RSK-PER-02", RiskCategory.PERSONNEL, "Nuclear Submarine Engineer & Tech Specialist Retention", "High industry competition for senior nuclear engineers leading to 14% voluntary outflow at Faslane.", 4, 4, "MEDIUM", "First Sea Lord", "Targeted retention bonuses & enhanced career progression pathways implemented.", "ACTIVE", "2026-10-20"),
        RiskItem("RSK-CYB-01", RiskCategory.CYBER, "Tier-1 Defence Supply Chain Cyber Vulnerability", "Third-party digital access vectors in sub-tier suppliers vulnerable to state-sponsored APT intrusions.", 3, 5, "HIGH", "Chief Information Officer", "Mandatory Zero-Trust security certification required for all DE&S contractors.", "MONITORED", "2026-10-12"),
        RiskItem("RSK-INF-03", RiskCategory.INFRASTRUCTURE, "Aging Dry Dock Infrastructure Resilience at Devonport", "Dock 9 crane electrical grid requiring capital refurbishment; potential delay to SSBN maintenance schedule.", 3, 4, "MEDIUM", "Chief Executive DIO", "Capital expenditure realignment of £45M approved for emergency power grid overhaul.", "ACTIVE", "2026-10-25")
    )

    val EXECUTIVE_DECISIONS = listOf(
        DecisionRecord(
            id = "DEC-2026-088",
            title = "Munition Stockpile Accelerated Procurement Framework (£280M)",
            owner = "Minister for Defence Procurement / Chief of the Defence Staff",
            deadline = "2026-10-12 17:00",
            recommendation = "Approve Option A: Multi-year guaranteed off-take agreement with UK munitions industry to double 155mm production lines within 12 months.",
            status = DecisionStatus.AWAITING_DECISION,
            financialImpactM = 280.0,
            capabilityImpact = "Restores 155mm artillery reserves to High Readiness status (+18% Land Readiness contribution).",
            riskImpact = "Mitigates RSK-SUP-01 (High Probability, Severe Impact) down to Medium.",
            dependencies = "DE&S Commercial approval and Treasury Reserve funding clearance.",
            options = listOf(
                DecisionOption("Option A", "Multi-year fixed contract (£280M)", 280.0, "+18% Land Readiness, 12-month delivery", "Medium financial commitment", "12 Months"),
                DecisionOption("Option B", "Spot purchase from international stock (£195M)", 195.0, "+8% Immediate stock, 3-month delivery", "High price volatility & lower quality assurance", "3 Months"),
                DecisionOption("Option C", "Maintain existing delivery schedule (£0M)", 0.0, "No additional cost", "Severe stockpile deficit remains for 24 months", "24 Months")
            ),
            contextSummary = "Senior decision requested following Strategic Command readiness review highlighting 155mm ammunition drawdown limits."
        ),
        DecisionRecord(
            id = "DEC-2026-092",
            title = "Devonport Dry Dock 9 Emergency Grid Investment (£45M)",
            owner = "Chief Executive DIO / First Sea Lord",
            deadline = "2026-10-15 12:00",
            recommendation = "Approve Option A: Reallocate DIO capital budget to fund urgent power grid upgrade for Submarine Maintenance.",
            status = DecisionStatus.AWAITING_DECISION,
            financialImpactM = 45.0,
            capabilityImpact = "Ensures uninterrupted maintenance schedule for Vanguard & Astute SSBN/SSN fleet.",
            riskImpact = "Eliminates single point of failure risk at Devonport Dockyard.",
            dependencies = "DIO Works Order Authorization.",
            options = listOf(
                DecisionOption("Option A", "Full Grid Refurbishment (£45M)", 45.0, "30-year operational life, zero outage risk", "Requires capital reallocation from estate repairs", "6 Months"),
                DecisionOption("Option B", "Temporary Diesel Generator Backups (£12M)", 12.0, "Immediate 12-month mitigation", "High operational fuel cost and ongoing reliability risk", "1 Month")
            ),
            contextSummary = "Infrastructure assessment flagged power fluctuation risks at Devonport Yard."
        )
    )

    val BASE_FACILITIES = listOf(
        BaseFacility("FAC-NWD-01", "Northwood Headquarters", "Base", "Greater London / Hertfordshire", 92, 85, 30, "OPERATIONAL"),
        BaseFacility("FAC-PTS-01", "Portsmouth Naval Base (HMS Nelson)", "Port", "Hampshire", 88, 90, 14, "OPERATIONAL"),
        BaseFacility("FAC-BZN-01", "RAF Brize Norton", "Airfield", "Oxfordshire", 84, 92, 21, "OPERATIONAL"),
        BaseFacility("FAC-BOV-01", "Bovington Armoured Logistics Depot", "Depot", "Dorset", 72, 98, 10, "CAPACITY_CONSTRAINED"),
        BaseFacility("FAC-COR-01", "MOD Corsham (Defence Digital)", "Data Centre", "Wiltshire", 96, 78, 60, "OPERATIONAL"),
        BaseFacility("FAC-FAS-01", "HMNB Clyde (Faslane)", "Port", "Argyll & Bute, Scotland", 90, 88, 45, "OPERATIONAL")
    )

    val INITIAL_EVENTS = listOf(
        CommandEvent(
            eventId = "EVT-2026-1001",
            timestamp = "2026-10-06 05:42:10",
            source = "DEFENCE-DIGITAL-C2",
            classification = ClassificationLevel.OFFICIAL_SENSITIVE,
            actor = "SYS_MONITOR",
            entityType = "READINESS",
            entityId = "MARITIME-HQ",
            previousState = "PARTIALLY_READY",
            newState = "READY",
            reason = "HMS Queen Elizabeth completed sea trial certification"
        ),
        CommandEvent(
            eventId = "EVT-2026-1002",
            timestamp = "2026-10-06 04:15:33",
            source = "DE&S-LOGISTICS-BUS",
            classification = ClassificationLevel.OFFICIAL_SENSITIVE,
            actor = "DIR_LOGISTICS",
            entityType = "EQUIPMENT",
            entityId = "EQ-LND-001",
            previousState = "AVAILABLE",
            newState = "UNDER_MAINTENANCE",
            reason = "Challenger 3 power pack hydraulic seal maintenance required"
        ),
        CommandEvent(
            eventId = "EVT-2026-1003",
            timestamp = "2026-10-06 02:30:00",
            source = "EXECUTIVE-DECISION-ENGINE",
            classification = ClassificationLevel.OFFICIAL_SENSITIVE,
            actor = "CDS_STAFF",
            entityType = "DECISION",
            entityId = "DEC-2026-088",
            previousState = "DRAFT",
            newState = "AWAITING_DECISION",
            reason = "Briefing pack generated for CDS decision review"
        )
    )
}
