package com.example.dcx.engine

import com.example.dcx.model.ScenarioSimulationResult
import kotlin.random.Random

object DigitalTwinEngine {

    fun runScenario(scenarioName: String, seed: Long = 12345L): ScenarioSimulationResult {
        val random = Random(seed)

        return when (scenarioName) {
            "BUDGET_REDUCTION_10" -> {
                val p50 = 68 + random.nextInt(-1, 2)
                val p75 = 62 + random.nextInt(-2, 2)
                val p90 = 55 + random.nextInt(-3, 2)
                ScenarioSimulationResult(
                    scenarioName = "10% Budget Reduction (£4.6B Cuts)",
                    p50Readiness = p50,
                    p75Readiness = p75,
                    p90Readiness = p90,
                    budgetDeltaM = -4600.0,
                    personnelShortagePct = 6,
                    logisticsDelayDays = 45,
                    summaryNarrative = "10% overall budget cut forces immediate procurement deferrals for Challenger 3 and Ajax Batch 2, reducing equipment availability by 14% and pushing overall Land readiness down to 68% (P50)."
                )
            }
            "BUDGET_REDUCTION_20" -> {
                val p50 = 58 + random.nextInt(-2, 2)
                val p75 = 51 + random.nextInt(-2, 2)
                val p90 = 44 + random.nextInt(-3, 2)
                ScenarioSimulationResult(
                    scenarioName = "20% Budget Reduction (£9.2B Cuts)",
                    p50Readiness = p50,
                    p75Readiness = p75,
                    p90Readiness = p90,
                    budgetDeltaM = -9200.0,
                    personnelShortagePct = 14,
                    logisticsDelayDays = 90,
                    summaryNarrative = "20% deep budget reduction triggers fleet size contractions, early retirement of older escorts, and 14% personnel gaps. High risk of NOT_READY status across 2 frontline brigades."
                )
            }
            "SUPPLIER_DELAY_90" -> {
                val p50 = 71 + random.nextInt(-1, 2)
                val p75 = 65 + random.nextInt(-2, 2)
                val p90 = 58 + random.nextInt(-2, 2)
                ScenarioSimulationResult(
                    scenarioName = "90-Day Tier-1 Supplier Disruption",
                    p50Readiness = p50,
                    p75Readiness = p75,
                    p90Readiness = p90,
                    budgetDeltaM = 320.0,
                    personnelShortagePct = 2,
                    logisticsDelayDays = 90,
                    summaryNarrative = "90-day delay in energetics and hydraulic component supply causes maintenance queue backlogs to surge by +42%, leading to 18 additional vehicles in AWAITING_PARTS status."
                )
            }
            "PERSONNEL_SHORTAGE_10" -> {
                val p50 = 70 + random.nextInt(-1, 2)
                val p75 = 64 + random.nextInt(-2, 2)
                val p90 = 59 + random.nextInt(-2, 2)
                ScenarioSimulationResult(
                    scenarioName = "10% Specialist Personnel Outflow",
                    p50Readiness = p50,
                    p75Readiness = p75,
                    p90Readiness = p90,
                    budgetDeltaM = 150.0,
                    personnelShortagePct = 10,
                    logisticsDelayDays = 25,
                    summaryNarrative = "10% shortage in nuclear engineers, cyber specialists, and avionics technicians increases maintenance turnaround times by 35% and reduces sortie rates."
                )
            }
            "FUEL_PRICE_SHOCK_30" -> {
                val p50 = 76 + random.nextInt(-1, 2)
                val p75 = 72 + random.nextInt(-1, 2)
                val p90 = 66 + random.nextInt(-2, 2)
                ScenarioSimulationResult(
                    scenarioName = "30% Energy & F-76 Fuel Cost Surge",
                    p50Readiness = p50,
                    p75Readiness = p75,
                    p90Readiness = p90,
                    budgetDeltaM = 480.0,
                    personnelShortagePct = 0,
                    logisticsDelayDays = 15,
                    summaryNarrative = "Fuel price surge requires £480M budget absorption or a 12% reduction in steaming/flying exercise hours across Royal Navy and RAF."
                )
            }
            else -> {
                ScenarioSimulationResult(
                    scenarioName = "Baseline Defence Operational Twin",
                    p50Readiness = 78,
                    p75Readiness = 75,
                    p90Readiness = 71,
                    budgetDeltaM = 0.0,
                    personnelShortagePct = 4,
                    logisticsDelayDays = 12,
                    summaryNarrative = "Baseline simulation under current force structure and budget commitments. Steady state readiness expected at 78%."
                )
            }
        }
    }
}
