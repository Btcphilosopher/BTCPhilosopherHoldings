package com.example.dcx.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "command_events")
data class EventEntity(
    @PrimaryKey val eventId: String,
    val timestamp: String,
    val source: String,
    val classification: String,
    val actor: String,
    val entityType: String,
    val entityId: String,
    val previousState: String,
    val newState: String,
    val reason: String
)

@Entity(tableName = "audit_records")
data class AuditEntity(
    @PrimaryKey val auditId: String,
    val timestamp: String,
    val userRole: String,
    val userName: String,
    val action: String,
    val targetObject: String,
    val previousValue: String,
    val newValue: String,
    val justification: String,
    val classification: String
)

@Entity(tableName = "user_decisions")
data class DecisionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val owner: String,
    val deadline: String,
    val recommendation: String,
    val status: String,
    val financialImpactM: Double,
    val capabilityImpact: String,
    val riskImpact: String,
    val dependencies: String,
    val approvedBy: String?,
    val approvalTimestamp: String?,
    val contextSummary: String,
    val optionsJson: String
)

@Entity(tableName = "custom_risks")
data class RiskEntity(
    @PrimaryKey val id: String,
    val category: String,
    val title: String,
    val description: String,
    val probability: Int,
    val impact: Int,
    val velocity: String,
    val owner: String,
    val mitigation: String,
    val status: String,
    val reviewDate: String
)
