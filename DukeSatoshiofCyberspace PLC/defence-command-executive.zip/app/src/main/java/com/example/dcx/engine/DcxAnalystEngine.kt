package com.example.dcx.engine

import com.example.dcx.data.SyntheticData
import com.example.dcx.model.ContractStatus
import com.example.dcx.model.ReadinessStatus

data class AnalystResponse(
    val query: String,
    val summaryAnswer: String,
    val dataSources: List<String>,
    val timePeriod: String,
    val calculationMethod: String,
    val assumptions: List<String>,
    val confidenceRating: String, // e.g. "95% (High Provenance)", "88% (Modelled)"
    val limitations: String
)

object DcxAnalystEngine {

    fun processQuery(query: String): AnalystResponse {
        val q = query.lowercase().trim()

        // Check Safety Boundary First
        if (q.contains("target") || q.contains("attack") || q.contains("fire") || q.contains("weapon") || q.contains("strike")) {
            return AnalystResponse(
                query = query,
                summaryAnswer = "⚠️ SAFETY BOUNDARY NOTICE: DCX is an executive information and decision-support platform only. Autonomously selecting targets, recommending lethal weapon employment, or generating attack plans is strictly prohibited by Defence AI Safety Governance.",
                dataSources = listOf("JSP 600 Defence Governance", "DCX Safety Layer"),
                timePeriod = "Real-time Enforcement",
                calculationMethod = "Rule-based Policy Guardrail",
                assumptions = listOf("Human command authority remains supreme"),
                confidenceRating = "100% (Policy Constraint)",
                limitations = "No tactical operational firing capability"
            )
        }

        if (q.contains("readiness") && (q.contains("why") || q.contains("decline") || q.contains("down"))) {
            val exceptions = SyntheticData.READINESS_DIMENSIONS.filter { it.score < 75 }
            val exceptionNames = exceptions.joinToString { "${it.name} (${it.score}%)" }
            return AnalystResponse(
                query = query,
                summaryAnswer = "Readiness is currently impacted by three primary drag dimensions: $exceptionNames. The principal driver is a Tier-1 supplier component delay for Challenger 3 hydraulics and 155mm ammunition drawdown.",
                dataSources = listOf("Land Command HQ Telemetry", "DE&S Logistics Stream", "Readiness Dimension Matrix"),
                timePeriod = "Last 24 Hours (Ending 2026-10-06 05:30)",
                calculationMethod = "Weighted Harmonic Mean of 10 Defence Readiness Dimensions",
                assumptions = listOf("Supplier lead times remain unchanged for 14 days", "Training schedules proceed as planned"),
                confidenceRating = "94% (Verified Telemetry)",
                limitations = "Excludes unverified overseas contractor sub-tier inventory"
            )
        }

        if (q.contains("programme") || q.contains("schedule") || q.contains("late") || q.contains("procurement")) {
            val latePrgs = SyntheticData.PROCUREMENT_PROGRAMMES.filter { it.timeHealth == "AMBER" || it.costHealth == "RED" }
            val details = latePrgs.joinToString("; ") { "${it.title} (Status: ${it.status.label}, Time: ${it.timeHealth}, Cost: ${it.costHealth})" }
            return AnalystResponse(
                query = query,
                summaryAnswer = "Programmes requiring executive schedule attention: $details. Ajax Armoured Cavalry has an AMBER schedule rating with a RED cost variance due to acoustics dampening retrofits.",
                dataSources = listOf("DE&S Major Programmes Dashboard", "MoD Commercial Contracts Register"),
                timePeriod = "Q3 2026 Contract Review",
                calculationMethod = "Earned Value Management (EVM) Schedule Performance Index (SPI)",
                assumptions = listOf("Babcock and GD UK delivery milestones held to current contract amendments"),
                confidenceRating = "91% (Contracted Data)",
                limitations = "Commercial claims currently in dispute are excluded from forecast calculations"
            )
        }

        if (q.contains("equipment") || q.contains("availability")) {
            val unavail = SyntheticData.EQUIPMENT_ASSETS.filter { it.status != "Available" }
            val text = unavail.joinToString("; ") { "${it.name} - ${it.status} (${it.locationRegion})" }
            return AnalystResponse(
                query = query,
                summaryAnswer = "Key equipment availability constraints: $text. Challenger 3 Fleet Batch A is awaiting hydraulic pumps at Bovington, while A400M Atlas C1 is queued at Brize Norton.",
                dataSources = listOf("JAMES Logistics System", "RNSMS Naval Asset Register", "RAF LITS"),
                timePeriod = "Real-time Telemetry (2026-10-06)",
                calculationMethod = "Fleet Operational Readiness Fraction = Available Assets / Total Fleet Size",
                assumptions = listOf("Maintenance work orders completed per schedule MWOs"),
                confidenceRating = "96% (Asset Telemetry)",
                limitations = "Does not account for assets undergoing deep lifecycle refits"
            )
        }

        if (q.contains("decision") || q.contains("approval") || q.contains("pending")) {
            val decs = SyntheticData.EXECUTIVE_DECISIONS.filter { it.status == com.example.dcx.model.DecisionStatus.AWAITING_DECISION }
            val text = decs.joinToString("; ") { "${it.title} (Deadline: ${it.deadline}, Value: £${it.financialImpactM}M)" }
            return AnalystResponse(
                query = query,
                summaryAnswer = "Decisions awaiting senior executive sign-off: $text. The highest priority is DEC-2026-088 (£280M Munition Stockpile Accelerated Procurement).",
                dataSources = listOf("DCX Decision Management Register", "Defence Board Agenda"),
                timePeriod = "Current Executive Docket",
                calculationMethod = "Multi-Criteria Decision Analysis (MCDA) Risk/Benefit Evaluation",
                assumptions = listOf("Treasury reserve release approved upon CDS recommendation"),
                confidenceRating = "100% (Active Docket)",
                limitations = "Requires human Ministerial sign-off"
            )
        }

        if (q.contains("risk")) {
            val risks = SyntheticData.RISK_REGISTER.filter { it.probability * it.impact >= 12 }
            val text = risks.joinToString("; ") { "${it.title} (Score: ${it.probability * it.impact}, Category: ${it.category.label})" }
            return AnalystResponse(
                query = query,
                summaryAnswer = "Critical Defence risks requiring immediate executive review: $text. Primary risk is RSK-SUP-01 (Supply Chain Energetics Bottleneck).",
                dataSources = listOf("MoD Enterprise Risk Register", "Defence Safety Authority Reports"),
                timePeriod = "October 2026 Audit",
                calculationMethod = "Risk Severity Score = Probability (1..5) × Impact (1..5)",
                assumptions = listOf("Mitigations monitored bi-weekly by Risk Owners"),
                confidenceRating = "89% (Expert Panel Assessed)",
                limitations = "Qualitative impact ratings subject to quarterly review"
            )
        }

        // Default response for natural queries
        return AnalystResponse(
            query = query,
            summaryAnswer = "Executive Analysis for '$query': Defence Status remains overall READY (82%). Key active levers include 2 pending financial decisions (£325M total), 4 critical supply chain risks, and 3 major equipment work orders.",
            dataSources = listOf("Common Defence Data Model (CDDM)", "Joint Command Operations Center"),
            timePeriod = "2026-10-06 05:45 GMT",
            calculationMethod = "Cross-Domain Entity Graph Query",
            assumptions = listOf("All synthetic commands connected to event bus"),
            confidenceRating = "92% (Unified Data Model)",
            limitations = "Unclassified aggregation layer"
        )
    }
}
