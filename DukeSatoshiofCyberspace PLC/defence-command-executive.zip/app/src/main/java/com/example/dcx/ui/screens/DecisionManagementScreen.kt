package com.example.dcx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dcx.model.DecisionRecord
import com.example.dcx.model.DecisionStatus
import com.example.ui.theme.DcxAmber
import com.example.ui.theme.DcxGreen
import com.example.ui.theme.DcxOutline
import com.example.ui.theme.DcxPrimary
import com.example.ui.theme.DcxSurface

@Composable
fun DecisionManagementScreen(
    decisions: List<DecisionRecord>,
    onApproveDecision: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "EXECUTIVE DECISION MANAGEMENT & BRIEFS",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = DcxPrimary
                    )
                    Text(
                        text = "SENIOR COMMAND DOCKET & AUDITABLE APPROVAL AUTHORITY",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray,
                        fontSize = 9.sp
                    )
                }
            }
        }

        items(decisions) { dec ->
            val statusColor = when (dec.status) {
                DecisionStatus.APPROVED -> DcxGreen
                DecisionStatus.AWAITING_DECISION -> DcxAmber
                else -> Color.Gray
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "[${dec.id}] ${dec.title}",
                                style = MaterialTheme.typography.titleMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "OWNER: ${dec.owner} | DEADLINE: ${dec.deadline}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF94A3B8),
                                fontSize = 9.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .background(statusColor.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                .border(1.dp, statusColor, RoundedCornerShape(3.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = dec.status.label,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = statusColor,
                                fontSize = 10.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "RECOMMENDATION: ${dec.recommendation}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = DcxGreen,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "OPTION ANALYSIS PACK:",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White,
                        fontSize = 10.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    dec.options.forEach { opt ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .background(Color(0xFF1E293B), RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${opt.optionId}: ${opt.title}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = DcxPrimary,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = "£${opt.costM}M",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = FontFamily.Monospace,
                                        color = Color.White,
                                        fontSize = 11.sp
                                    )
                                }
                                Text(text = "Benefit: ${opt.benefit}", style = MaterialTheme.typography.labelSmall, color = Color(0xFFCBD5E1), fontSize = 10.sp)
                                Text(text = "Risk: ${opt.risk} | Timeline: ${opt.timeline}", style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontSize = 9.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (dec.status == DecisionStatus.AWAITING_DECISION) {
                        Button(
                            onClick = { onApproveDecision(dec.id) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("approve_decision_${dec.id}"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF166534)),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "AUTHORISE & SIGN DECISION (CHIEF OF DEFENCE STAFF)",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 11.sp
                            )
                        }
                    } else if (dec.status == DecisionStatus.APPROVED) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF064E3B), RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "SIGNED & AUTHORISED BY ${dec.approvedBy ?: "CDS"} AT ${dec.approvalTimestamp ?: "TODAY"}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = DcxGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
