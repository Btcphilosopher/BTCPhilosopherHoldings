package com.example.dcx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dcx.engine.DigitalTwinEngine
import com.example.dcx.model.ScenarioSimulationResult
import com.example.ui.theme.DcxAmber
import com.example.ui.theme.DcxGreen
import com.example.ui.theme.DcxOutline
import com.example.ui.theme.DcxPrimary
import com.example.ui.theme.DcxRed
import com.example.ui.theme.DcxSurface

@Composable
fun ScenarioDigitalTwinScreen(modifier: Modifier = Modifier) {
    val scenarioOptions = listOf(
        "BUDGET_REDUCTION_10" to "10% Budget Reduction (£4.6B Cuts)",
        "BUDGET_REDUCTION_20" to "20% Deep Budget Reduction (£9.2B Cuts)",
        "SUPPLIER_DELAY_90" to "90-Day Tier-1 Supplier Disruption",
        "PERSONNEL_SHORTAGE_10" to "10% Specialist Personnel Outflow",
        "FUEL_PRICE_SHOCK_30" to "30% Energy & Fuel Price Shock"
    )

    var selectedKey by remember { mutableStateOf("BUDGET_REDUCTION_10") }
    var currentResult by remember(selectedKey) {
        mutableStateOf(DigitalTwinEngine.runScenario(selectedKey))
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "STRATEGIC DIGITAL TWIN SIMULATION ENGINE",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = DcxPrimary
                    )
                    Text(
                        text = "BOUNDED MONTE CARLO PROBABILITY DISTRIBUTIONS (P50 / P75 / P90)",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray,
                        fontSize = 9.sp
                    )
                }
            }
        }

        item {
            Text(
                text = "SELECT SCENARIO EXPERIMENT:",
                style = MaterialTheme.typography.titleSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        items(scenarioOptions) { pair ->
            val key = pair.first
            val label = pair.second
            val isSelected = key == selectedKey
            Card(
                colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFF1E293B) else DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) DcxPrimary else DcxOutline),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        selectedKey = key
                        currentResult = DigitalTwinEngine.runScenario(key)
                    }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodyMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) DcxPrimary else Color.White,
                        fontSize = 12.sp
                    )
                    Text(
                        text = if (isSelected) "RUNNING ▶" else "SELECT",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = if (isSelected) DcxGreen else Color.Gray,
                        fontSize = 10.sp
                    )
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "SIMULATION OUTPUT: ${currentResult.scenarioName}",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = DcxPrimary,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = currentResult.summaryNarrative,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "MONTE CARLO READINESS DISTRIBUTIONS:",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Gray,
                        fontSize = 10.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        PercentileBox("P50 (Median)", "${currentResult.p50Readiness}%", DcxGreen)
                        PercentileBox("P75 (Stress)", "${currentResult.p75Readiness}%", DcxAmber)
                        PercentileBox("P90 (Severe)", "${currentResult.p90Readiness}%", DcxRed)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "BUDGET DELTA: £${currentResult.budgetDeltaM}M",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = if (currentResult.budgetDeltaM < 0) DcxAmber else DcxGreen,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "PERSONNEL GAP: ${currentResult.personnelShortagePct}%",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = DcxAmber,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "LOGISTICS DELAY: ${currentResult.logisticsDelayDays}d",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = DcxRed,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PercentileBox(label: String, value: String, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
            .border(1.dp, color, RoundedCornerShape(4.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, color = Color.Gray, fontSize = 9.sp)
            Text(text = value, style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = color, fontSize = 16.sp)
        }
    }
}
