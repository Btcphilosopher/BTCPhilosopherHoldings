package com.example.dcx.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dcx.data.SyntheticData
import com.example.dcx.ui.components.StatusProgressBar
import com.example.ui.theme.DcxAmber
import com.example.ui.theme.DcxGreen
import com.example.ui.theme.DcxOutline
import com.example.ui.theme.DcxPrimary
import com.example.ui.theme.DcxSurface

@Composable
fun PersonnelTrainingScreen(modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "WORKFORCE & TRAINING ENGINE",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = DcxPrimary
                    )
                    Text(
                        text = "INSTITUTIONAL PERSONNEL MANNING & QUALIFICATION COVERAGE",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray,
                        fontSize = 9.sp
                    )
                }
            }
        }

        items(SyntheticData.PERSONNEL_METRICS) { pm ->
            Card(
                colors = CardDefaults.cardColors(containerColor = DcxSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DcxOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = pm.category,
                            style = MaterialTheme.typography.titleMedium,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "VACANCIES: ${pm.vacancies}",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = if (pm.vacancies > 2000) DcxAmber else Color.Gray,
                            fontSize = 10.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    StatusProgressBar(label = "Manning Target Fulfillment", score = pm.manningPct)

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "QUAL COVERAGE: ${pm.qualCoveragePct}%",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = DcxGreen,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "DEPLOYMENT AVAIL: ${pm.deploymentAvailabilityPct}%",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = DcxPrimary,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "SPECIALIST GAPS: ${pm.specialistShortageCount}",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = DcxAmber,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}
