package com.example.dcx.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [EventEntity::class, AuditEntity::class, DecisionEntity::class, RiskEntity::class],
    version = 1,
    exportSchema = false
)
abstract class DcxDatabase : RoomDatabase() {
    abstract fun dcxDao(): DcxDao

    companion object {
        @Volatile
        private var INSTANCE: DcxDatabase? = null

        fun getDatabase(context: Context): DcxDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DcxDatabase::class.java,
                    "defence_command_executive.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
