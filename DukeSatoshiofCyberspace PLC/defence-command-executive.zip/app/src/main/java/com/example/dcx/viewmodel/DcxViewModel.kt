package com.example.dcx.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.dcx.db.DcxDatabase
import com.example.dcx.model.CommandEvent
import com.example.dcx.model.DecisionRecord
import com.example.dcx.repository.DcxRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DcxViewModel(application: Application) : AndroidViewModel(application) {

    private val db = DcxDatabase.getDatabase(application)
    private val repository = DcxRepository(db.dcxDao())

    private val _currentScreen = MutableStateFlow("EXECUTIVE")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    private val _isCommandPaletteOpen = MutableStateFlow(false)
    val isCommandPaletteOpen: StateFlow<Boolean> = _isCommandPaletteOpen.asStateFlow()

    val eventsStream: StateFlow<List<CommandEvent>> = repository.getEventsStream()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val decisionsStream: StateFlow<List<DecisionRecord>> = repository.getDecisionsStream()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditStream = repository.getAuditStream()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun navigateTo(screenId: String) {
        _currentScreen.value = screenId
    }

    fun toggleCommandPalette(open: Boolean) {
        _isCommandPaletteOpen.value = open
    }

    fun approveDecision(decisionId: String) {
        viewModelScope.launch {
            repository.approveDecision(decisionId, "Chief of the Defence Staff")
        }
    }
}
