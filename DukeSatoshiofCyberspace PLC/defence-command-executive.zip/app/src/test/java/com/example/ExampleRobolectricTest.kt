package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.dcx.engine.DigitalTwinEngine
import com.example.dcx.engine.ReadinessEngine
import com.example.dcx.model.ReadinessStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Defence Command Executive", appName)
  }

  @Test
  fun `test readiness engine calculation`() {
    val score = ReadinessEngine.calculateOverallReadiness()
    assertTrue("Overall readiness should be between 0 and 100", score in 0..100)
    val status = ReadinessEngine.getOverallReadinessStatus(score)
    assertNotNull("Readiness status should not be null", status)
  }

  @Test
  fun `test digital twin scenario engine`() {
    val sim = DigitalTwinEngine.runScenario("BUDGET_REDUCTION_10")
    assertNotNull(sim)
    assertTrue("P50 readiness should be valid", sim.p50Readiness in 0..100)
    assertEquals(-4600.0, sim.budgetDeltaM, 0.1)
  }
}
