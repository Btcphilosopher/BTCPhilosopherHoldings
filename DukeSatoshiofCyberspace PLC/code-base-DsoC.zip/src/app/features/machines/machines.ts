import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EstateService } from '../../core/services/estate.service';

@Component({
  selector: 'app-machines',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './machines.html',
})
export class MachinesComponent {
  estateService = inject(EstateService);
}
