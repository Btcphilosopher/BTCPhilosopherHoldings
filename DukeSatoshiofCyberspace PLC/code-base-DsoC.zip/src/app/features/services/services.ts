import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EstateService } from '../../core/services/estate.service';

@Component({
  selector: 'app-services',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './services.html',
})
export class ServicesComponent {
  estateService = inject(EstateService);

  rollback(depId: string) {
    if (confirm('Are you sure you want to perform an instant zero-downtime rollback for this deployment?')) {
      this.estateService.rollbackDeployment(depId);
    }
  }
}
