import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { EstateService } from '../../core/services/estate.service';

interface ChangedFile {
  path: string;
  staged: boolean;
  status: 'MODIFIED' | 'UNTRACKED' | 'DELETED';
  additions: number;
  deletions: number;
}

@Component({
  selector: 'app-commit-studio',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  templateUrl: './commit-studio.html',
})
export class CommitStudioComponent {
  estateService = inject(EstateService);

  commitType = signal<string>('feat');
  commitScope = signal<string>('simd');
  commitSummary = signal<string>('Optimized vector matrix transformation for AVX-512');
  commitBody = signal<string>('Aligned Vector4SIMD struct on 64-byte boundary for lock-free memory access.');
  isGeneratingAi = signal<boolean>(false);

  changedFiles = signal<ChangedFile[]>([
    { path: 'src/math/simd_avx.rs', staged: true, status: 'MODIFIED', additions: 142, deletions: 18 },
    { path: 'src/math/vector.rs', staged: true, status: 'MODIFIED', additions: 12, deletions: 4 },
    { path: 'tests/vector_bench.rs', staged: false, status: 'UNTRACKED', additions: 45, deletions: 0 },
  ]);

  toggleStage(file: ChangedFile) {
    this.changedFiles.update((list) =>
      list.map((f) => (f.path === file.path ? { ...f, staged: !f.staged } : f))
    );
  }

  stageAll() {
    this.changedFiles.update((list) => list.map((f) => ({ ...f, staged: true })));
  }

  async generateAiCommitMessage() {
    this.isGeneratingAi.set(true);
    const staged = this.changedFiles().filter((f) => f.staged);
    const prompt = `Generate a standard conventional commit message for staged files: ${staged.map((s) => s.path).join(', ')}`;

    const res = await this.estateService.askDukeAI(prompt, 'COMMIT_MSG');
    if (res.reply) {
      this.commitSummary.set(res.reply.slice(0, 80));
    }
    this.isGeneratingAi.set(false);
  }

  async doCommit() {
    const fullMsg = `[${this.commitType()}(${this.commitScope()})]: ${this.commitSummary()}\n\n${this.commitBody()}`;
    const cmd = `git commit -m "${fullMsg.replace(/"/g, '\\"')}"`;

    await this.estateService.executeGitCommand(cmd);
    alert(`Commit created successfully:\n\n${fullMsg}`);
  }
}
