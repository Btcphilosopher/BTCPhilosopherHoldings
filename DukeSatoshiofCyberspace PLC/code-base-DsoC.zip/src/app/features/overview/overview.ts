import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EstateService, NavigationTab } from '../../core/services/estate.service';

@Component({
  selector: 'app-overview',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './overview.html',
})
export class OverviewComponent {
  estateService = inject(EstateService);

  navigateTo(tab: NavigationTab) {
    this.estateService.setTab(tab);
  }

  selectProject(slug: string) {
    this.estateService.selectProject(slug);
    this.estateService.setTab('projects');
  }

  selectRepo(slug: string) {
    this.estateService.selectRepository(slug);
    this.estateService.setTab('repositories');
  }
}
