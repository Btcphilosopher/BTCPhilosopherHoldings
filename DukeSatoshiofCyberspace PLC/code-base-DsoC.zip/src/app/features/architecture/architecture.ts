import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EstateService } from '../../core/services/estate.service';

@Component({
  selector: 'app-architecture',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './architecture.html',
})
export class ArchitectureComponent {
  estateService = inject(EstateService);
}
