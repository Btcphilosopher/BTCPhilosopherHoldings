import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { EstateService } from '../../core/services/estate.service';

interface TerminalLine {
  cmd: string;
  output: string;
  isError?: boolean;
  time: string;
}

@Component({
  selector: 'app-terminal',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  templateUrl: './terminal.html',
})
export class TerminalComponent {
  estateService = inject(EstateService);

  commandInput = signal<string>('');
  isExecuting = signal<boolean>(false);

  terminalHistory = signal<TerminalLine[]>([
    {
      cmd: 'duke-satoshi estate status',
      output: '[DUKE SATOSHI SOVEREIGN ENGINE v3.8]\nHostname: LINUX-WORKSTATION\nOS: Ubuntu 24.04 LTS (Noble Numbat)\nKernel: 6.8.0-40-generic x86_64\n142 Repositories Indexed. Security Perimeter: SECURE.',
      time: '06:14:00 UTC',
    },
  ]);

  readonly quickCommands = [
    'git status',
    'git log -n 3 --oneline',
    'uname -a',
    'cargo --version',
    'cat /etc/os-release',
    'ls -la',
  ];

  async executeCommand(cmdToRun?: string) {
    const cmd = cmdToRun || this.commandInput().trim();
    if (!cmd) return;

    this.isExecuting.set(true);
    const result = await this.estateService.executeTerminalCommand(cmd);

    this.terminalHistory.update((list) => [
      ...list,
      {
        cmd,
        output: result.stdout || result.stderr || 'Command executed with no output.',
        isError: result.exitCode !== 0,
        time: new Date().toUTCString().split(' ')[4] + ' UTC',
      },
    ]);

    this.commandInput.set('');
    this.isExecuting.set(false);
  }

  runQuickCommand(cmd: string) {
    this.executeCommand(cmd);
  }

  clearTerminal() {
    this.terminalHistory.set([]);
  }
}
