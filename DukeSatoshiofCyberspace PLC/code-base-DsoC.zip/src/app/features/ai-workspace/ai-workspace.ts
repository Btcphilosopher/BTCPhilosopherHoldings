import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { EstateService } from '../../core/services/estate.service';

interface ChatMessage {
  sender: 'USER' | 'DUKE_AI';
  text: string;
  time: string;
  model?: string;
}

@Component({
  selector: 'app-ai-workspace',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  templateUrl: './ai-workspace.html',
})
export class AiWorkspaceComponent {
  estateService = inject(EstateService);

  userPrompt = signal<string>('');
  selectedMode = signal<string>('ARCHITECT');
  selectedModel = signal<'flash' | 'pro'>('flash');
  permissionLevel = signal<'READ_ONLY' | 'WRITE_FILES' | 'RUN_TESTS' | 'RUN_COMMANDS'>('READ_ONLY');
  isThinking = signal<boolean>(false);

  messages = signal<ChatMessage[]>([
    {
      sender: 'DUKE_AI',
      text: 'DUKE SATOSHI SOVEREIGN AI AGENT INITIALIZED.\nHow may I assist with repository architecture, code review, or SIMD optimization today?',
      time: '06:14 UTC',
      model: 'gemini-3.8-flash',
    },
  ]);

  readonly quickPrompts = [
    'Audit AVX-512 SIMD vector math kernels in aureom-kernel',
    'Evaluate lock-free ring buffer WAL compaction safety',
    'Generate unit test suite for Graphene DSP audio normalizer',
    'Check security vulnerabilities in Cargo dependencies',
  ];

  async sendPrompt(customPrompt?: string) {
    const promptText = customPrompt || this.userPrompt().trim();
    if (!promptText) return;

    const userMsg: ChatMessage = {
      sender: 'USER',
      text: promptText,
      time: new Date().toUTCString().split(' ')[4] + ' UTC',
    };

    this.messages.update((list) => [...list, userMsg]);
    this.userPrompt.set('');
    this.isThinking.set(true);

    const res = await this.estateService.askDukeAI(promptText, this.selectedMode(), {
      name: this.estateService.currentRepository()?.name,
    });

    const aiMsg: ChatMessage = {
      sender: 'DUKE_AI',
      text: res.reply || 'No response generated.',
      time: new Date().toUTCString().split(' ')[4] + ' UTC',
      model: res.modelUsed || 'gemini-3.8-flash',
    };

    this.messages.update((list) => [...list, aiMsg]);
    this.isThinking.set(false);
  }

  runQuickPrompt(p: string) {
    this.sendPrompt(p);
  }
}
