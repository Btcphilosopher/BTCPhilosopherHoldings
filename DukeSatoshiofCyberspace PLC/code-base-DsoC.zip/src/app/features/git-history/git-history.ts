import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EstateService } from '../../core/services/estate.service';
import { Commit } from '../../core/models/estate.models';

@Component({
  selector: 'app-git-history',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './git-history.html',
})
export class GitHistoryComponent {
  estateService = inject(EstateService);

  selectedCommit = signal<Commit>(this.estateService.commits()[0]);

  diffSample = [
    { type: 'context', line: ' #[repr(C, align(64))]' },
    { type: 'context', line: ' pub struct Vector4SIMD {' },
    { type: 'delete', line: '-    pub x: f64,' },
    { type: 'delete', line: '-    pub y: f64,' },
    { type: 'add', line: '+    pub x: f32,' },
    { type: 'add', line: '+    pub y: f32,' },
    { type: 'context', line: '     pub z: f32,' },
    { type: 'context', line: '     pub w: f32,' },
    { type: 'context', line: ' }' },
  ];

  selectCommit(c: Commit) {
    this.selectedCommit.set(c);
  }
}
