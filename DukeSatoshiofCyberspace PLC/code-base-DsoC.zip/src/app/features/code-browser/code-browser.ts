import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { EstateService } from '../../core/services/estate.service';
import { FileNode } from '../../core/models/estate.models';

interface OpenTab {
  path: string;
  name: string;
  content: string;
  language: string;
}

@Component({
  selector: 'app-code-browser',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  templateUrl: './code-browser.html',
})
export class CodeBrowserComponent {
  estateService = inject(EstateService);

  searchQuery = signal<string>('');
  aiAnalysisOutput = signal<string>('');
  isAnalyzingWithAi = signal<boolean>(false);

  // File Tree Data Structure
  fileTree: FileNode[] = [
    {
      name: 'src',
      path: 'src',
      type: 'directory',
      children: [
        {
          name: 'math',
          path: 'src/math',
          type: 'directory',
          children: [
            {
              name: 'simd_avx.rs',
              path: 'src/math/simd_avx.rs',
              type: 'file',
              language: 'rust',
              content: `// DUKE SATOSHI OF CYBERSPACE - AUREOM GAME OS KERNEL
// AVX-512 Matrix Vector Math Kernel
// ISO C-ABI Compatible

#[repr(C, align(64))]
pub struct Vector4SIMD {
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub w: f32,
}

impl Vector4SIMD {
    #[inline(always)]
    pub unsafe fn transform_avx512(&mut self, matrix: &[f32; 16]) {
        use std::arch::x86_64::*;

        // Ensure 64-byte memory boundary alignment
        let v_in = _mm128_load_ps(&self.x as *const f32);
        let m_col0 = _mm128_load_ps(matrix.as_ptr());
        
        // Fast Fused Multiply-Add
        let res = _mm128_fmadd_ps(v_in, m_col0, _mm128_setzero_ps());
        _mm128_store_ps(&mut self.x as *mut f32, res);
    }
}

#[no_mangle]
pub extern "C" fn aureom_kernel_vector_transform(vec_ptr: *mut Vector4SIMD, mat_ptr: *const f32) -> i32 {
    if vec_ptr.is_null() || mat_ptr.is_null() {
        return -1;
    }
    unsafe {
        (*vec_ptr).transform_avx512(&*(mat_ptr as *const [f32; 16]));
    }
    0
}`,
            },
            {
              name: 'vector.rs',
              path: 'src/math/vector.rs',
              type: 'file',
              language: 'rust',
              content: `pub struct Vec3 { pub x: f32, pub y: f32, pub z: f32 }\nimpl Vec3 {\n  pub fn dot(&self, other: &Vec3) -> f32 {\n    self.x * other.x + self.y * other.y + self.z * other.z\n  }\n}`,
            },
          ],
        },
        {
          name: 'wal',
          path: 'src/wal',
          type: 'directory',
          children: [
            {
              name: 'compactor.rs',
              path: 'src/wal/compactor.rs',
              type: 'file',
              language: 'rust',
              content: `// SilicaFlux Lock-Free LSM-Tree Compactor\nuse std::sync::atomic::{AtomicPtr, Ordering};\n\npub struct LockFreeWALBuffer {\n    write_ptr: AtomicPtr<u8>,\n}\n\nimpl LockFreeWALBuffer {\n    pub fn flush(&self) {\n        // Memory fence for cross-thread WAL write sync\n        std::sync::atomic::fence(Ordering::SeqCst);\n    }\n}`,
            },
          ],
        },
      ],
    },
    {
      name: 'Cargo.toml',
      path: 'Cargo.toml',
      type: 'file',
      language: 'toml',
      content: `[package]\nname = "aureom-kernel"\nversion = "3.8.2"\nedition = "2021"\n\n[dependencies]\ncfg-if = "1.0"`,
    },
  ];

  openTabs = signal<OpenTab[]>([
    {
      path: 'src/math/simd_avx.rs',
      name: 'simd_avx.rs',
      language: 'rust',
      content: `// DUKE SATOSHI OF CYBERSPACE - AUREOM GAME OS KERNEL
// AVX-512 Matrix Vector Math Kernel
// ISO C-ABI Compatible

#[repr(C, align(64))]
pub struct Vector4SIMD {
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub w: f32,
}

impl Vector4SIMD {
    #[inline(always)]
    pub unsafe fn transform_avx512(&mut self, matrix: &[f32; 16]) {
        use std::arch::x86_64::*;

        // Ensure 64-byte memory boundary alignment
        let v_in = _mm128_load_ps(&self.x as *const f32);
        let m_col0 = _mm128_load_ps(matrix.as_ptr());
        
        // Fast Fused Multiply-Add
        let res = _mm128_fmadd_ps(v_in, m_col0, _mm128_setzero_ps());
        _mm128_store_ps(&mut self.x as *mut f32, res);
    }
}

#[no_mangle]
pub extern "C" fn aureom_kernel_vector_transform(vec_ptr: *mut Vector4SIMD, mat_ptr: *const f32) -> i32 {
    if vec_ptr.is_null() || mat_ptr.is_null() {
        return -1;
    }
    unsafe {
        (*vec_ptr).transform_avx512(&*(mat_ptr as *const [f32; 16]));
    }
    0
}`,
    },
  ]);

  activeTabPath = signal<string>('src/math/simd_avx.rs');

  currentActiveTab = computed(() => {
    return this.openTabs().find((t) => t.path === this.activeTabPath()) || this.openTabs()[0];
  });

  codeLines = computed(() => {
    const tab = this.currentActiveTab();
    if (!tab) return [];
    return tab.content.split('\n');
  });

  selectFile(node: FileNode) {
    if (node.type === 'directory') return;

    const existing = this.openTabs().find((t) => t.path === node.path);
    if (!existing) {
      this.openTabs.update((tabs) => [
        ...tabs,
        {
          path: node.path,
          name: node.name,
          language: node.language || 'rust',
          content: node.content || '// Content unavailable',
        },
      ]);
    }
    this.activeTabPath.set(node.path);
  }

  closeTab(path: string, event: MouseEvent) {
    event.stopPropagation();
    this.openTabs.update((tabs) => tabs.filter((t) => t.path !== path));
    if (this.activeTabPath() === path && this.openTabs().length > 0) {
      this.activeTabPath.set(this.openTabs()[0].path);
    }
  }

  async runAiAnalysis() {
    this.isAnalyzingWithAi.set(true);
    const tab = this.currentActiveTab();
    const prompt = `Perform a comprehensive security, memory-safety, and SIMD optimization code review for file ${tab.path}:\n\n${tab.content}`;

    const res = await this.estateService.askDukeAI(prompt, 'REVIEW', { name: this.estateService.currentRepository()?.name });
    this.aiAnalysisOutput.set(res.reply);
    this.isAnalyzingWithAi.set(false);
  }
}
