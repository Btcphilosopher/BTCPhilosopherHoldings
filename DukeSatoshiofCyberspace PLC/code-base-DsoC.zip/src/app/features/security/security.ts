import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { EstateService } from '../../core/services/estate.service';
import { SecretItem } from '../../core/models/estate.models';

@Component({
  selector: 'app-security',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  templateUrl: './security.html',
})
export class SecurityComponent {
  estateService = inject(EstateService);

  showNewSecretModal = signal<boolean>(false);
  newSecretName = signal<string>('');
  newSecretType = signal<SecretItem['type']>('API_KEY');

  rotateSecret(id: string) {
    this.estateService.rotateSecret(id);
  }

  createSecret() {
    if (!this.newSecretName().trim()) return;
    this.estateService.addSecret(this.newSecretName(), this.newSecretType());
    this.newSecretName.set('');
    this.showNewSecretModal.set(false);
  }
}
