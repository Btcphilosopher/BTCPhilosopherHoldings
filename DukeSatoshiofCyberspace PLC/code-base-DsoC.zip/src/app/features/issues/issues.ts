import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { EstateService } from '../../core/services/estate.service';
import { IssueStatus, IssuePriority, IssueType } from '../../core/models/estate.models';

@Component({
  selector: 'app-issues',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  templateUrl: './issues.html',
})
export class IssuesComponent {
  estateService = inject(EstateService);

  showNewIssueModal = signal<boolean>(false);

  newTitle = signal<string>('');
  newDescription = signal<string>('');
  newPriority = signal<IssuePriority>('HIGH');
  newType = signal<IssueType>('BUG');

  readonly columns: IssueStatus[] = ['BACKLOG', 'TODO', 'IN_PROGRESS', 'BLOCKED', 'REVIEW', 'DONE'];

  getIssuesByStatus(status: IssueStatus) {
    return this.estateService.issues().filter((i) => i.status === status);
  }

  updateStatus(issueId: string, status: IssueStatus) {
    this.estateService.updateIssueStatus(issueId, status);
  }

  createIssue() {
    if (!this.newTitle().trim()) return;

    this.estateService.addIssue({
      title: this.newTitle(),
      description: this.newDescription(),
      status: 'TODO',
      priority: this.newPriority(),
      type: this.newType(),
      repoSlug: this.estateService.selectedRepoSlug(),
      projectSlug: this.estateService.selectedProjectSlug(),
      author: 'Duke Satoshi',
      labels: [this.newType().toLowerCase()],
    });

    this.newTitle.set('');
    this.newDescription.set('');
    this.showNewIssueModal.set(false);
  }
}
