import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { EstateService } from '../../core/services/estate.service';

@Component({
  selector: 'app-knowledge',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  templateUrl: './knowledge.html',
})
export class KnowledgeComponent {
  estateService = inject(EstateService);

  showNewNoteModal = signal<boolean>(false);
  newNoteTitle = signal<string>('');
  newNoteContent = signal<string>('');
  newNoteTags = signal<string>('rust, simd');

  createNote() {
    if (!this.newNoteTitle().trim()) return;

    this.estateService.addNote({
      title: this.newNoteTitle(),
      content: this.newNoteContent(),
      targetType: 'REPOSITORY',
      targetId: this.estateService.selectedRepoSlug(),
      tags: this.newNoteTags().split(',').map((t) => t.trim()),
    });

    this.newNoteTitle.set('');
    this.newNoteContent.set('');
    this.showNewNoteModal.set(false);
  }

  exportSnapshot() {
    window.open('/api/backup/export', '_blank');
  }
}
