import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { EstateService, NavigationTab } from '../../core/services/estate.service';
import { RepositoryCategory } from '../../core/models/estate.models';

@Component({
  selector: 'app-repositories',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  templateUrl: './repositories.html',
})
export class RepositoriesComponent {
  estateService = inject(EstateService);

  searchQuery = signal<string>('');
  selectedCategory = signal<string>('ALL');
  viewMode = signal<'grid' | 'table'>('grid');

  readonly categories: Array<{ id: string; label: string }> = [
    { id: 'ALL', label: 'All Repositories' },
    { id: 'KERNEL', label: 'Kernel' },
    { id: 'SYSTEMS', label: 'Systems' },
    { id: 'AI', label: 'AI & Neural' },
    { id: 'MOBILE', label: 'Mobile & Audio' },
    { id: 'SERVICE', label: 'Services' },
    { id: 'RESEARCH', label: 'Research' },
  ];

  filteredRepositories = computed(() => {
    const q = this.searchQuery().toLowerCase().trim();
    const cat = this.selectedCategory();

    return this.estateService.repositories().filter((r) => {
      const matchesCategory = cat === 'ALL' || r.category === cat;
      const matchesQuery =
        !q ||
        r.name.toLowerCase().includes(q) ||
        r.description.toLowerCase().includes(q) ||
        r.language.toLowerCase().includes(q);
      return matchesCategory && matchesQuery;
    });
  });

  selectCategory(catId: string) {
    this.selectedCategory.set(catId);
  }

  toggleViewMode() {
    this.viewMode.update((v) => (v === 'grid' ? 'table' : 'grid'));
  }

  openRepository(slug: string) {
    this.estateService.selectRepository(slug);
    this.estateService.setTab('code-browser');
  }

  scanLocalGit() {
    this.estateService.scanLocalGitRepository();
  }
}
