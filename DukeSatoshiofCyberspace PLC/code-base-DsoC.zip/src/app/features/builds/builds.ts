import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EstateService } from '../../core/services/estate.service';
import { PipelineStep } from '../../core/models/estate.models';

@Component({
  selector: 'app-builds',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './builds.html',
})
export class BuildsComponent {
  estateService = inject(EstateService);

  isRunningPipeline = signal<boolean>(false);
  pipelineOutput = signal<PipelineStep[]>([
    { name: 'CHECKOUT', status: 'PASSED', durationSec: 0.8, output: 'Switched to branch main\nCommit 8a7c21e: Optimized vector math kernels' },
    { name: 'DEPENDENCY_INSTALL', status: 'PASSED', durationSec: 1.2, output: 'Cargo dependencies verified. 0 missing crates.' },
    { name: 'FORMAT_AND_LINT', status: 'PASSED', durationSec: 1.1, output: 'Cargo clippy: 0 warnings, 0 errors.' },
    { name: 'UNIT_TESTS', status: 'PASSED', durationSec: 3.4, output: 'Running 148 unit tests...\nResult: 148 passed; 0 failed.' },
    { name: 'SECURITY_SCAN', status: 'PASSED', durationSec: 0.9, output: 'Vulnerability audit: 0 critical vulnerabilities.' },
    { name: 'BUILD_ARTIFACT', status: 'PASSED', durationSec: 4.2, output: 'Package aureom-kernel-v3.8.2.tar.gz generated. SHA256 verified.' },
  ]);

  async triggerRun() {
    this.isRunningPipeline.set(true);
    try {
      const res = await this.estateService.runPipeline('aureom-kernel-pipeline');
      if (res.steps) {
        this.pipelineOutput.set(res.steps);
      }
    } finally {
      this.isRunningPipeline.set(false);
    }
  }
}
