import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EstateService } from './core/services/estate.service';

import { HeaderComponent } from './shared/components/header/header';
import { SidebarComponent } from './shared/components/sidebar/sidebar';
import { IntelligencePanelComponent } from './shared/components/intelligence-panel/intelligence-panel';
import { CommandPaletteComponent } from './shared/components/command-palette/command-palette';

import { OverviewComponent } from './features/overview/overview';
import { RepositoriesComponent } from './features/repositories/repositories';
import { CodeBrowserComponent } from './features/code-browser/code-browser';
import { GitHistoryComponent } from './features/git-history/git-history';
import { CommitStudioComponent } from './features/commit-studio/commit-studio';
import { IssuesComponent } from './features/issues/issues';
import { BuildsComponent } from './features/builds/builds';
import { TerminalComponent } from './features/terminal/terminal';
import { MachinesComponent } from './features/machines/machines';
import { ServicesComponent } from './features/services/services';
import { ArchitectureComponent } from './features/architecture/architecture';
import { SecurityComponent } from './features/security/security';
import { AiWorkspaceComponent } from './features/ai-workspace/ai-workspace';
import { KnowledgeComponent } from './features/knowledge/knowledge';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    SidebarComponent,
    IntelligencePanelComponent,
    CommandPaletteComponent,
    OverviewComponent,
    RepositoriesComponent,
    CodeBrowserComponent,
    GitHistoryComponent,
    CommitStudioComponent,
    IssuesComponent,
    BuildsComponent,
    TerminalComponent,
    MachinesComponent,
    ServicesComponent,
    ArchitectureComponent,
    SecurityComponent,
    AiWorkspaceComponent,
    KnowledgeComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  estateService = inject(EstateService);
}
