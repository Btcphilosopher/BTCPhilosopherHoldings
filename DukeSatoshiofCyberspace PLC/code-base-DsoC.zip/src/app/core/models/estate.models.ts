export type VisibilityType = 'PRIVATE' | 'SOVEREIGN' | 'INTERNAL' | 'PUBLIC_READONLY';

export type RepositoryCategory =
  | 'APPLICATION'
  | 'LIBRARY'
  | 'SERVICE'
  | 'KERNEL'
  | 'SIMULATOR'
  | 'MOBILE'
  | 'WEB'
  | 'AI'
  | 'DATA'
  | 'HARDWARE'
  | 'SYSTEMS'
  | 'RESEARCH'
  | 'DOCUMENTATION'
  | 'EXPERIMENT'
  | 'ARCHIVE';

export type BuildStatus = 'PASSING' | 'FAILING' | 'BUILDING' | 'QUEUED' | 'UNKNOWN';
export type SecurityStatus = 'CLEAN' | 'WARNING' | 'CRITICAL_ALERT';
export type DeploymentStatus = 'STAGING' | 'PRODUCTION' | 'NOT_DEPLOYED' | 'ROLLBACK';
export type IssueStatus = 'BACKLOG' | 'TODO' | 'IN_PROGRESS' | 'BLOCKED' | 'REVIEW' | 'DONE' | 'ARCHIVED';
export type IssuePriority = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
export type IssueType = 'BUG' | 'FEATURE' | 'RESEARCH' | 'DESIGN' | 'PERFORMANCE' | 'SECURITY' | 'TECH_DEBT' | 'DOCUMENTATION' | 'IDEA';
export type ProjectStatus = 'IDEA' | 'PROTOTYPE' | 'ACTIVE' | 'BETA' | 'RELEASED' | 'MAINTENANCE' | 'ARCHIVED';

export interface Repository {
  id: string;
  name: string;
  slug: string;
  description: string;
  visibility: VisibilityType;
  localPath: string;
  remoteUrl: string;
  defaultBranch: string;
  language: string;
  languages: { [lang: string]: number }; // percentage or bytes
  license: string;
  createdAt: string;
  updatedAt: string;
  lastCommitHash: string;
  lastCommitMessage: string;
  sizeMb: number;
  gitStatus: 'CLEAN' | 'MODIFIED' | 'AHEAD' | 'BEHIND';
  buildStatus: BuildStatus;
  deploymentStatus: DeploymentStatus;
  securityStatus: SecurityStatus;
  category: RepositoryCategory;
  projectSlug?: string;
  stars?: number;
  openIssuesCount?: number;
}

export interface Commit {
  hash: string;
  author: string;
  email: string;
  date: string;
  message: string;
  parentHash?: string;
  branch: string;
  repoSlug: string;
  insertions: number;
  deletions: number;
  filesChanged: string[];
}

export interface Branch {
  name: string;
  repoSlug: string;
  ahead: number;
  behind: number;
  lastCommitHash: string;
  lastCommitMsg: string;
  buildStatus: BuildStatus;
  isDefault: boolean;
  isProtected: boolean;
}

export interface FileNode {
  name: string;
  path: string;
  type: 'file' | 'directory';
  size?: number;
  language?: string;
  children?: FileNode[];
  content?: string;
}

export interface SymbolItem {
  id: string;
  name: string;
  kind: 'class' | 'function' | 'method' | 'interface' | 'type' | 'struct' | 'enum' | 'module';
  filePath: string;
  line: number;
  repoSlug: string;
  referencesCount: number;
  definedIn: string;
  callers?: string[];
  callees?: string[];
}

export interface Issue {
  id: string;
  title: string;
  description: string;
  status: IssueStatus;
  priority: IssuePriority;
  type: IssueType;
  repoSlug: string;
  projectSlug: string;
  author: string;
  createdAt: string;
  updatedAt: string;
  labels: string[];
  assignee?: string;
}

export interface Project {
  id: string;
  name: string;
  slug: string;
  description: string;
  status: ProjectStatus;
  primaryLanguage: string;
  reposCount: number;
  issuesCount: number;
  healthScore: number; // 0 - 100
  repositories: string[];
  subsystems: { name: string; type: string; tech: string }[];
  milestone: string;
  createdYear: number;
}

export interface PullRequest {
  id: string;
  title: string;
  branch: string;
  baseBranch: string;
  repoSlug: string;
  author: string;
  status: 'OPEN' | 'DRAFT' | 'APPROVED' | 'MERGED' | 'CLOSED' | 'REVIEW';
  diffStats: { insertions: number; deletions: number; filesChangedCount: number };
  buildStatus: BuildStatus;
  selfReviewCompleted: boolean;
  selfReviewNotes?: string;
  createdAt: string;
}

export interface PipelineStep {
  name: string;
  status: 'PASSED' | 'FAILED' | 'RUNNING' | 'QUEUED';
  durationSec: number;
  output: string;
}

export interface BuildRun {
  id: string;
  repoSlug: string;
  commitHash: string;
  branch: string;
  environment: string;
  status: 'PASSED' | 'FAILED' | 'RUNNING' | 'QUEUED';
  startTime: string;
  durationSec: number;
  steps: PipelineStep[];
  artifacts: string[];
}

export interface Machine {
  id: string;
  hostname: string;
  os: string;
  arch: string;
  cpu: string;
  ramGb: number;
  gpu?: string;
  storageTb: number;
  ip: string;
  status: 'ONLINE' | 'OFFLINE' | 'DEGRADED';
  cpuUsagePct: number;
  ramUsagePct: number;
  tempC?: number;
  loadAvg: string;
  uptimeDays: number;
  lastSeen: string;
}

export interface ServiceItem {
  id: string;
  name: string;
  host: string;
  port: number;
  protocol: string;
  version: string;
  status: 'HEALTHY' | 'DEGRADED' | 'UNHEALTHY' | 'STOPPED';
  repoSlug: string;
  lastDeployment: string;
  healthEndpoint: string;
}

export interface Deployment {
  id: string;
  serviceId: string;
  serviceName: string;
  version: string;
  commitHash: string;
  environment: 'STAGING' | 'PRODUCTION';
  timestamp: string;
  status: 'LIVE' | 'STAGED' | 'ROLLED_BACK' | 'FAILED';
  artifactSha256: string;
}

export interface PackageItem {
  id: string;
  name: string;
  version: string;
  registryType: 'CRATE' | 'NPM' | 'WHEEL' | 'CONTAINER' | 'APK';
  repoSlug: string;
  publishedDate: string;
  downloadsCount: number;
  sizeMb: number;
  checksumSha256: string;
}

export interface SecretItem {
  id: string;
  name: string;
  refToken: string;
  type: 'API_KEY' | 'DEPLOY_TOKEN' | 'DB_PASS' | 'SIGNING_KEY';
  lastRotated: string;
  accessedByCount: number;
  maskedValue: string;
}

export interface Vulnerability {
  id: string;
  package: string;
  version: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  cve: string;
  description: string;
  repoSlug: string;
  fixVersion: string;
}

export interface ArchitectureNode {
  id: string;
  label: string;
  category: 'SYSTEM' | 'SUBSYSTEM' | 'SERVICE' | 'MODULE' | 'DATABASE' | 'UI' | 'CORE';
  tech: string;
  repoSlug?: string;
}

export interface ArchitectureEdge {
  from: string;
  to: string;
  type: 'DEPENDS_ON' | 'IMPLEMENTS' | 'GENERATES' | 'DEPLOYS' | 'TESTS';
}

export interface ArchitectureADR {
  id: string;
  title: string;
  status: 'ACCEPTED' | 'PROPOSED' | 'DEPRECATED' | 'REJECTED';
  date: string;
  context: string;
  decision: string;
  consequences: string;
  repoSlug: string;
}

export interface PersonalNote {
  id: string;
  title: string;
  content: string;
  targetType: 'REPOSITORY' | 'COMMIT' | 'ISSUE' | 'FILE' | 'MACHINE' | 'ARCHITECTURE';
  targetId: string;
  createdAt: string;
  tags: string[];
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  actor: string;
  machine: string;
  action: string;
  target: string;
  result: 'SUCCESS' | 'DENIED' | 'FAILURE';
}

export interface AITask {
  id: string;
  task: string;
  repoSlug: string;
  branch: string;
  prompt: string;
  agent: 'ARCHITECT' | 'CODER' | 'TEST' | 'REVIEW' | 'SECURITY' | 'DOCUMENTATION' | 'RESEARCH';
  status: 'QUEUED' | 'RUNNING' | 'WAITING_APPROVAL' | 'COMPLETED' | 'FAILED';
  filesAffected: string[];
  permissionLevel: 'READ_ONLY' | 'WRITE_FILES' | 'RUN_TESTS' | 'RUN_COMMANDS';
  timeSec: number;
  model: string;
  resultSummary?: string;
  diffPreview?: string;
}

export interface ActivityItem {
  id: string;
  timestamp: string;
  timeFormatted: string;
  projectName: string;
  repoSlug: string;
  type: 'BUILD_PASSED' | 'BUILD_FAILED' | 'COMMIT_CREATED' | 'DEPLOYED' | 'SECURITY_ALERT' | 'NOTE_ADDED' | 'PR_MERGED';
  title: string;
  details: string;
}
