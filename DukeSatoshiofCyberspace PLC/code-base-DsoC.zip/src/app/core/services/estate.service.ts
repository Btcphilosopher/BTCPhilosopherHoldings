import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import {
  Project,
  Repository,
  Commit,
  Branch,
  Issue,
  PullRequest,
  Machine,
  ServiceItem,
  Deployment,
  PackageItem,
  SecretItem,
  Vulnerability,
  ArchitectureNode,
  ArchitectureEdge,
  ArchitectureADR,
  PersonalNote,
  AuditEvent,
  AITask,
  ActivityItem,
  SymbolItem,
} from '../models/estate.models';
import {
  INITIAL_PROJECTS,
  INITIAL_REPOSITORIES,
  INITIAL_COMMITS,
  INITIAL_BRANCHES,
  INITIAL_ISSUES,
  INITIAL_PULL_REQUESTS,
  INITIAL_MACHINES,
  INITIAL_SERVICES,
  INITIAL_DEPLOYMENTS,
  INITIAL_PACKAGES,
  INITIAL_SECRETS,
  INITIAL_VULNERABILITIES,
  INITIAL_ARCHITECTURE_NODES,
  INITIAL_ARCHITECTURE_EDGES,
  INITIAL_ADRS,
  INITIAL_NOTES,
  INITIAL_AUDIT_LOGS,
  INITIAL_AI_TASKS,
  INITIAL_ACTIVITIES,
  SYNTHETIC_SYMBOLS,
} from '../data/synthetic-estate.data';

export type NavigationTab =
  | 'overview'
  | 'repositories'
  | 'projects'
  | 'code-browser'
  | 'git-history'
  | 'branches'
  | 'diff-engine'
  | 'commit-studio'
  | 'issues'
  | 'pull-requests'
  | 'builds'
  | 'terminal'
  | 'machines'
  | 'services'
  | 'deployments'
  | 'packages'
  | 'architecture'
  | 'data-model'
  | 'api-explorer'
  | 'security'
  | 'secrets'
  | 'ai-workspace'
  | 'ai-agents'
  | 'knowledge-graph'
  | 'notes'
  | 'software-catalogue'
  | 'software-map'
  | 'timeline'
  | 'backup'
  | 'audit';

export type EstateTheme = 'DUKE_DARK' | 'DUKE_LIGHT' | 'ARCHIVE' | 'TERMINAL';

@Injectable({
  providedIn: 'root',
})
export class EstateService {
  private http = inject(HttpClient);

  // State Signals
  readonly activeTab = signal<NavigationTab>('overview');
  readonly currentTheme = signal<EstateTheme>('DUKE_DARK');
  readonly commandPaletteOpen = signal<boolean>(false);
  readonly selectedRepoSlug = signal<string>('aureom-kernel');
  readonly selectedProjectSlug = signal<string>('aureom-game-os');
  readonly selectedFilePath = signal<string>('src/math/simd_avx.rs');

  readonly projects = signal<Project[]>(INITIAL_PROJECTS);
  readonly repositories = signal<Repository[]>(INITIAL_REPOSITORIES);
  readonly commits = signal<Commit[]>(INITIAL_COMMITS);
  readonly branches = signal<Branch[]>(INITIAL_BRANCHES);
  readonly issues = signal<Issue[]>(INITIAL_ISSUES);
  readonly pullRequests = signal<PullRequest[]>(INITIAL_PULL_REQUESTS);
  readonly machines = signal<Machine[]>(INITIAL_MACHINES);
  readonly services = signal<ServiceItem[]>(INITIAL_SERVICES);
  readonly deployments = signal<Deployment[]>(INITIAL_DEPLOYMENTS);
  readonly packages = signal<PackageItem[]>(INITIAL_PACKAGES);
  readonly secrets = signal<SecretItem[]>(INITIAL_SECRETS);
  readonly vulnerabilities = signal<Vulnerability[]>(INITIAL_VULNERABILITIES);
  readonly architectureNodes = signal<ArchitectureNode[]>(INITIAL_ARCHITECTURE_NODES);
  readonly architectureEdges = signal<ArchitectureEdge[]>(INITIAL_ARCHITECTURE_EDGES);
  readonly adrs = signal<ArchitectureADR[]>(INITIAL_ADRS);
  readonly notes = signal<PersonalNote[]>(INITIAL_NOTES);
  readonly auditLogs = signal<AuditEvent[]>(INITIAL_AUDIT_LOGS);
  readonly aiTasks = signal<AITask[]>(INITIAL_AI_TASKS);
  readonly activities = signal<ActivityItem[]>(INITIAL_ACTIVITIES);
  readonly symbols = signal<SymbolItem[]>(SYNTHETIC_SYMBOLS);

  // Local Git & System Info from Server
  readonly localGitWorkspace = signal<{
    workspacePath?: string;
    isGitRepo?: boolean;
    branch?: string;
    statusOutput?: string;
    recentCommits?: Array<{ hash: string; author: string; date: string; message: string }>;
  } | null>(null);

  // Computed Properties
  readonly currentRepository = computed(() => {
    return this.repositories().find((r) => r.slug === this.selectedRepoSlug()) || this.repositories()[0];
  });

  readonly currentProject = computed(() => {
    return this.projects().find((p) => p.slug === this.selectedProjectSlug()) || this.projects()[0];
  });

  readonly activeProjectsCount = computed(() => this.projects().filter((p) => p.status === 'ACTIVE').length);
  readonly totalRepositoriesCount = computed(() => this.repositories().length);
  readonly openIssuesCount = computed(() => this.issues().filter((i) => i.status !== 'DONE' && i.status !== 'ARCHIVED').length);
  readonly onlineMachinesCount = computed(() => this.machines().filter((m) => m.status === 'ONLINE').length);
  readonly healthyServicesCount = computed(() => this.services().filter((s) => s.status === 'HEALTHY').length);
  readonly criticalVulnerabilitiesCount = computed(() => this.vulnerabilities().filter((v) => v.severity === 'CRITICAL').length);

  constructor() {
    this.scanLocalGitRepository();
  }

  setTab(tab: NavigationTab) {
    this.activeTab.set(tab);
  }

  setTheme(theme: EstateTheme) {
    this.currentTheme.set(theme);
  }

  toggleCommandPalette() {
    this.commandPaletteOpen.update((v) => !v);
  }

  selectRepository(slug: string) {
    this.selectedRepoSlug.set(slug);
  }

  selectProject(slug: string) {
    this.selectedProjectSlug.set(slug);
  }

  // Real Backend API Calls
  async scanLocalGitRepository() {
    try {
      const res = await firstValueFrom(this.http.get<any>('/api/git/scan'));
      this.localGitWorkspace.set(res);
    } catch {
      // Graceful fallback
    }
  }

  async executeGitCommand(command: string): Promise<{ stdout: string; stderr: string; exitCode: number }> {
    try {
      return await firstValueFrom(this.http.post<any>('/api/git/exec', { command }));
    } catch (err: any) {
      return { stdout: '', stderr: err.message || 'Execution error', exitCode: 1 };
    }
  }

  async executeTerminalCommand(command: string): Promise<{ stdout: string; stderr: string; exitCode: number }> {
    try {
      const result = await firstValueFrom(this.http.post<any>('/api/terminal/exec', { command }));
      this.logAudit('TERMINAL_EXEC', 'LINUX-WORKSTATION', `Command: ${command}`, result.exitCode === 0 ? 'SUCCESS' : 'FAILURE');
      return result;
    } catch (err: any) {
      return { stdout: '', stderr: err.message || 'Terminal error', exitCode: 1 };
    }
  }

  async runPipeline(pipelineName: string): Promise<any> {
    try {
      const result = await firstValueFrom(this.http.post<any>('/api/pipeline/run', { pipelineName }));
      this.logAudit('BUILD_PIPELINE', 'LINUX-WORKSTATION', `Pipeline: ${pipelineName}`, 'SUCCESS');
      return result;
    } catch (err: any) {
      throw err;
    }
  }

  async askDukeAI(prompt: string, mode: string = 'EXPLAIN', repositoryContext?: any): Promise<any> {
    try {
      const result = await firstValueFrom(
        this.http.post<any>('/api/ai/ask', {
          prompt,
          mode,
          repositoryContext: repositoryContext || { name: this.currentRepository()?.name },
        })
      );
      this.logAudit('AI_INTERACTION', 'DUKE_AI', `Prompt: ${prompt.slice(0, 40)}...`, 'SUCCESS');
      return result;
    } catch (err: any) {
      return {
        reply: `[DUKE SATOSHI LOCAL AGENT]\n\nExecution analysis for mode: ${mode}.\nPrompt: "${prompt}".\nUnable to reach backend model server: ${err.message}`,
        modelUsed: 'local-fallback',
      };
    }
  }

  // Mutations
  addIssue(issue: Omit<Issue, 'id' | 'createdAt' | 'updatedAt'>) {
    const newIssue: Issue = {
      ...issue,
      id: `ISSUE-${Math.floor(100 + Math.random() * 900)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.issues.update((list) => [newIssue, ...list]);
    this.logAudit('ISSUE_CREATED', 'LINUX-WORKSTATION', `Issue: ${newIssue.title}`, 'SUCCESS');
  }

  updateIssueStatus(id: string, status: Issue['status']) {
    this.issues.update((list) =>
      list.map((i) => (i.id === id ? { ...i, status, updatedAt: new Date().toISOString() } : i))
    );
  }

  addNote(note: Omit<PersonalNote, 'id' | 'createdAt'>) {
    const newNote: PersonalNote = {
      ...note,
      id: `note-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    this.notes.update((list) => [newNote, ...list]);
    this.logAudit('NOTE_CREATED', 'LINUX-WORKSTATION', `Note: ${newNote.title}`, 'SUCCESS');
  }

  addSecret(name: string, type: SecretItem['type']) {
    const newSec: SecretItem = {
      id: `sec-${Date.now()}`,
      name,
      refToken: `sec_ref_${Math.random().toString(36).substring(2, 7)}`,
      type,
      lastRotated: new Date().toISOString().split('T')[0],
      accessedByCount: 0,
      maskedValue: '••••••••••••••••••••' + Math.random().toString(36).substring(2, 6),
    };
    this.secrets.update((list) => [newSec, ...list]);
    this.logAudit('SECRET_CREATED', 'LINUX-WORKSTATION', `Secret: ${name}`, 'SUCCESS');
  }

  rotateSecret(id: string) {
    this.secrets.update((list) =>
      list.map((s) =>
        s.id === id
          ? {
              ...s,
              lastRotated: new Date().toISOString().split('T')[0],
              maskedValue: '••••••••••••••••••••' + Math.random().toString(36).substring(2, 6),
            }
          : s
      )
    );
    this.logAudit('SECRET_ROTATED', 'LINUX-WORKSTATION', `Secret ID: ${id}`, 'SUCCESS');
  }

  rollbackDeployment(id: string) {
    this.deployments.update((list) =>
      list.map((d) => (d.id === id ? { ...d, status: 'ROLLED_BACK' } : d))
    );
    this.logAudit('DEPLOYMENT_ROLLED_BACK', 'LINUX-WORKSTATION', `Deployment ID: ${id}`, 'SUCCESS');
  }

  private logAudit(action: string, machine: string, target: string, result: 'SUCCESS' | 'DENIED' | 'FAILURE') {
    const event: AuditEvent = {
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString(),
      actor: 'Duke Satoshi',
      machine,
      action,
      target,
      result,
    };
    this.auditLogs.update((list) => [event, ...list.slice(0, 99)]);
  }
}
