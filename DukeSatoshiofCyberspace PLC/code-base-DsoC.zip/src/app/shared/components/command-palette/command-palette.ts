import { Component, inject, signal, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { EstateService, NavigationTab } from '../../../core/services/estate.service';

interface SearchResultItem {
  id: string;
  category: 'NAVIGATION' | 'REPOSITORY' | 'PROJECT' | 'COMMAND';
  title: string;
  subtitle: string;
  icon: string;
  action: () => void;
}

@Component({
  selector: 'app-command-palette',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  templateUrl: './command-palette.html',
})
export class CommandPaletteComponent {
  estateService = inject(EstateService);
  searchQuery = signal<string>('');

  @HostListener('window:keydown', ['$event'])
  handleKeyDown(event: KeyboardEvent) {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      this.estateService.toggleCommandPalette();
    } else if (event.key === 'Escape' && this.estateService.commandPaletteOpen()) {
      this.estateService.commandPaletteOpen.set(false);
    }
  }

  get items(): SearchResultItem[] {
    const q = this.searchQuery().toLowerCase().trim();
    const allItems: SearchResultItem[] = [];

    // Navigation Items
    const navs: { tab: NavigationTab; title: string; subtitle: string; icon: string }[] = [
      { tab: 'overview', title: 'Estate Overview', subtitle: 'View system health & repository metrics', icon: 'dashboard' },
      { tab: 'repositories', title: 'Repositories Engine', subtitle: 'Browse all 142 estate repositories', icon: 'folder' },
      { tab: 'code-browser', title: 'Code Browser', subtitle: 'Multi-tab syntax file inspector', icon: 'code' },
      { tab: 'git-history', title: 'Git History & Commits', subtitle: 'Inspect commit graphs & diffs', icon: 'history_edu' },
      { tab: 'commit-studio', title: 'Commit Studio', subtitle: 'Stage changes & AI commit message generator', icon: 'commit' },
      { tab: 'issues', title: 'Engineering Issues Board', subtitle: 'Kanban board & issue tracking', icon: 'bug_report' },
      { tab: 'builds', title: 'CI Pipeline Runner', subtitle: 'Execute local build scripts & tests', icon: 'precision_manufacturing' },
      { tab: 'terminal', title: 'Integrated Terminal', subtitle: 'Run safe shell commands', icon: 'terminal' },
      { tab: 'ai-workspace', title: 'Duke AI Workspace', subtitle: 'Interact with Gemini 3.8 Flash / 3.1 Pro AI Agent', icon: 'psychology' },
      { tab: 'security', title: 'Security Centre & Secrets', subtitle: 'Vulnerability scanner & secret vault', icon: 'shield' },
    ];

    navs.forEach((n) => {
      allItems.push({
        id: `nav-${n.tab}`,
        category: 'NAVIGATION',
        title: n.title,
        subtitle: n.subtitle,
        icon: n.icon,
        action: () => {
          this.estateService.setTab(n.tab);
          this.estateService.commandPaletteOpen.set(false);
        },
      });
    });

    // Repositories
    this.estateService.repositories().forEach((r) => {
      allItems.push({
        id: `repo-${r.slug}`,
        category: 'REPOSITORY',
        title: r.name,
        subtitle: `${r.language} • ${r.category} • ${r.localPath}`,
        icon: 'folder_zip',
        action: () => {
          this.estateService.selectRepository(r.slug);
          this.estateService.setTab('repositories');
          this.estateService.commandPaletteOpen.set(false);
        },
      });
    });

    // Commands
    allItems.push({
      id: 'cmd-scan-git',
      category: 'COMMAND',
      title: 'Scan Local Git Directory',
      subtitle: 'Scan workspace filesystem for local .git repositories',
      icon: 'radar',
      action: () => {
        this.estateService.scanLocalGitRepository();
        this.estateService.setTab('repositories');
        this.estateService.commandPaletteOpen.set(false);
      },
    });

    allItems.push({
      id: 'cmd-export-backup',
      category: 'COMMAND',
      title: 'Export Estate Snapshot',
      subtitle: 'Download complete JSON snapshot of estate configuration & history',
      icon: 'download',
      action: () => {
        window.open('/api/backup/export', '_blank');
        this.estateService.commandPaletteOpen.set(false);
      },
    });

    if (!q) return allItems.slice(0, 8);

    return allItems
      .filter((i) => i.title.toLowerCase().includes(q) || i.subtitle.toLowerCase().includes(q) || i.category.toLowerCase().includes(q))
      .slice(0, 10);
  }

  close() {
    this.estateService.commandPaletteOpen.set(false);
  }
}
