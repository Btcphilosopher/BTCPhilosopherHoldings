import { Component, inject, signal, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EstateService, EstateTheme } from '../../../core/services/estate.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './header.html',
})
export class HeaderComponent implements OnDestroy {
  estateService = inject(EstateService);

  utcTime = signal<string>(this.getFormattedUtcTime());
  private timer = setInterval(() => {
    this.utcTime.set(this.getFormattedUtcTime());
  }, 1000);

  ngOnDestroy() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  private getFormattedUtcTime(): string {
    const now = new Date();
    return now.toUTCString().replace('GMT', 'UTC').split(' ').slice(4, 5)[0] + ' UTC';
  }

  onCommandPalette() {
    this.estateService.toggleCommandPalette();
  }

  setTheme(theme: EstateTheme) {
    this.estateService.setTheme(theme);
  }
}
