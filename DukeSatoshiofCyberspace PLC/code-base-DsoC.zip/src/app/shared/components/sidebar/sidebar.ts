import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EstateService, NavigationTab } from '../../../core/services/estate.service';

interface NavGroup {
  title: string;
  items: {
    tab: NavigationTab;
    label: string;
    icon: string;
    badge?: number | string;
  }[];
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './sidebar.html',
})
export class SidebarComponent {
  estateService = inject(EstateService);

  get navGroups(): NavGroup[] {
    return [
      {
        title: 'ESTATE',
        items: [
          { tab: 'overview', label: 'Overview', icon: 'dashboard' },
          { tab: 'repositories', label: 'Repositories', icon: 'folder', badge: this.estateService.repositories().length },
          { tab: 'projects', label: 'Projects', icon: 'account_tree', badge: this.estateService.projects().length },
          { tab: 'software-catalogue', label: 'Software Catalogue', icon: 'inventory_2' },
          { tab: 'software-map', label: 'Software Map', icon: 'map' },
          { tab: 'timeline', label: 'Software History', icon: 'history' },
        ],
      },
      {
        title: 'DEVELOPMENT',
        items: [
          { tab: 'code-browser', label: 'Code Browser', icon: 'code' },
          { tab: 'git-history', label: 'Git History', icon: 'history_edu' },
          { tab: 'branches', label: 'Branches', icon: 'alt_route' },
          { tab: 'diff-engine', label: 'Diff Engine', icon: 'difference' },
          { tab: 'commit-studio', label: 'Commit Studio', icon: 'commit', badge: 'UNSTAGED' },
          { tab: 'pull-requests', label: 'Pull Requests', icon: 'merge_type', badge: this.estateService.pullRequests().length },
          { tab: 'issues', label: 'Issues', icon: 'bug_report', badge: this.estateService.openIssuesCount() },
          { tab: 'builds', label: 'Builds & CI', icon: 'precision_manufacturing' },
        ],
      },
      {
        title: 'INFRASTRUCTURE',
        items: [
          { tab: 'terminal', label: 'Integrated Terminal', icon: 'terminal' },
          { tab: 'machines', label: 'Machine Registry', icon: 'dns', badge: this.estateService.onlineMachinesCount() },
          { tab: 'services', label: 'Services', icon: 'cloud_done', badge: this.estateService.healthyServicesCount() },
          { tab: 'deployments', label: 'Deployments', icon: 'rocket_launch' },
          { tab: 'packages', label: 'Package Vault', icon: 'inventory' },
        ],
      },
      {
        title: 'KNOWLEDGE',
        items: [
          { tab: 'architecture', label: 'Architecture Graph', icon: 'hub' },
          { tab: 'data-model', label: 'Data Model Visualizer', icon: 'schema' },
          { tab: 'api-explorer', label: 'API Explorer', icon: 'api' },
          { tab: 'knowledge-graph', label: 'Knowledge Graph', icon: 'auto_graph' },
          { tab: 'notes', label: 'Engineering Notes', icon: 'note_alt' },
        ],
      },
      {
        title: 'SECURITY',
        items: [
          { tab: 'security', label: 'Security Centre', icon: 'shield' },
          { tab: 'secrets', label: 'Secret Vault', icon: 'lock', badge: this.estateService.secrets().length },
          { tab: 'audit', label: 'Audit Log', icon: 'receipt_long' },
        ],
      },
      {
        title: 'AI',
        items: [
          { tab: 'ai-workspace', label: 'Duke AI Workspace', icon: 'psychology' },
          { tab: 'ai-agents', label: 'AI Agents & Queue', icon: 'smart_toy', badge: this.estateService.aiTasks().length },
        ],
      },
      {
        title: 'SYSTEM',
        items: [
          { tab: 'backup', label: 'Backup & Snapshots', icon: 'backup' },
        ],
      },
    ];
  }

  selectTab(tab: NavigationTab) {
    this.estateService.setTab(tab);
  }
}
