import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EstateService } from '../../../core/services/estate.service';

@Component({
  selector: 'app-intelligence-panel',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './intelligence-panel.html',
})
export class IntelligencePanelComponent {
  estateService = inject(EstateService);
  collapsed = signal<boolean>(false);

  toggleCollapse() {
    this.collapsed.update((v) => !v);
  }
}
