"""Mock of The Code Exchange storefront publishing API (v1) and customer download library.

This is a local stand-in for the real shop, used by the Product Foundry demonstration and tests.
It behaves like a careful production API:
  * products/editions are upserted by the publisher's external reference (no duplicates on retry);
  * every mutating call honours an ``Idempotency-Key`` and replays the stored response;
  * release packages are immutable: re-uploading different bytes for a published version is refused;
  * customer downloads are gated by the purchased entitlement and the edition's update policy;
  * ``POST /_faults`` injects failures (before or *after* committing) to exercise publisher retries.

State is persisted to a JSON file (STOREFRONT_DATA, default ./var/storefront/state.json).
"""
from __future__ import annotations

import hashlib
import json
import os
import secrets
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import Body, Depends, FastAPI, Header, HTTPException, Request, Response
from fastapi.responses import JSONResponse

DATA = Path(os.environ.get("STOREFRONT_DATA", "./var/storefront/state.json"))
BLOBS = DATA.parent / "packages"
TOKEN = os.environ.get("STOREFRONT_TOKEN", "storefront-dev-token")
LOCK = threading.RLock()

app = FastAPI(title="The Code Exchange storefront (mock)", version="1.0.0")


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _empty() -> dict:
    return {"seq": 0, "products": {}, "editions": {}, "releases": {}, "pointers": {}, "pointer_history": {},
            "idempotency": {}, "customers": {}, "orders": {}, "entitlements": {}, "keys": {}, "tickets": {},
            "advisories": {}, "notifications": [], "faults": [], "calls": []}


def load() -> dict:
    if DATA.exists():
        return json.loads(DATA.read_text())
    return _empty()


def save(state: dict) -> None:
    DATA.parent.mkdir(parents=True, exist_ok=True)
    tmp = DATA.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=1, sort_keys=True))
    tmp.replace(DATA)


def new_id(state: dict, prefix: str) -> str:
    state["seq"] += 1
    return f"{prefix}_{state['seq']:05d}"


def publisher(authorization: str = Header(default="")) -> None:
    if authorization != f"Bearer {TOKEN}":
        raise HTTPException(401, "publisher token required")


def _fault(state: dict, op: str, when: str) -> bool:
    for f in state["faults"]:
        if f["op"] == op and f["when"] == when and f["remaining"] > 0:
            f["remaining"] -= 1
            return True
    return False


def mutate(op: str, request: Request, idem: str | None, fn):
    """Run fn(state) with idempotency, fault injection and persistence."""
    with LOCK:
        state = load()
        state["calls"].append({"op": op, "path": request.url.path, "at": now(), "idempotency_key": idem})
        key = f"{request.method} {request.url.path} {idem}" if idem else None
        if key and key in state["idempotency"]:
            save(state)
            return JSONResponse(state["idempotency"][key], headers={"Idempotent-Replayed": "true"})
        if _fault(state, op, "before"):
            save(state)
            return JSONResponse({"detail": f"injected failure before {op}"}, status_code=503)
        result = fn(state)
        if key:
            state["idempotency"][key] = result
        lost = _fault(state, op, "after")
        save(state)
        if lost:  # the change is committed but the response is "lost"
            return JSONResponse({"detail": f"injected failure after committing {op}"}, status_code=503)
        return result


# ------------------------------------------------------------------ publisher API
@app.put("/v1/products/{ref}", dependencies=[Depends(publisher)])
def upsert_product(ref: str, request: Request, body: dict = Body(...), idempotency_key: str | None = Header(None)):
    def fn(state):
        existing = next((p for p in state["products"].values() if p["ref"] == ref), None)
        pid = existing["id"] if existing else new_id(state, "prod")
        state["products"][pid] = {"id": pid, "ref": ref, **{k: v for k, v in body.items() if k != "ref"},
                                  "updated_at": now()}
        return {"id": pid, "created": existing is None}
    return mutate("product", request, idempotency_key, fn)


@app.put("/v1/products/{pid}/editions/{ref}", dependencies=[Depends(publisher)])
def upsert_edition(pid: str, ref: str, request: Request, body: dict = Body(...),
                   idempotency_key: str | None = Header(None)):
    def fn(state):
        if pid not in state["products"]:
            raise HTTPException(404, "product not found")
        existing = next((e for e in state["editions"].values() if e["ref"] == ref), None)
        eid = existing["id"] if existing else new_id(state, "ed")
        state["editions"][eid] = {"id": eid, "ref": ref, "product_id": pid,
                                  **{k: v for k, v in body.items() if k != "ref"}, "updated_at": now()}
        return {"id": eid, "created": existing is None}
    return mutate("edition", request, idempotency_key, fn)


@app.put("/v1/editions/{eid}/releases/{version}/package", dependencies=[Depends(publisher)])
async def upload_package(eid: str, version: str, request: Request, x_content_sha256: str = Header(...),
                         idempotency_key: str | None = Header(None)):
    data = await request.body()
    digest = hashlib.sha256(data).hexdigest()
    if digest != x_content_sha256:
        raise HTTPException(422, f"checksum mismatch: header {x_content_sha256}, body {digest}")

    def fn(state):
        if eid not in state["editions"]:
            raise HTTPException(404, "edition not found")
        key = f"{eid}@{version}"
        rel = state["releases"].get(key)
        if rel and rel.get("package_sha256") and rel["package_sha256"] != digest:
            raise HTTPException(409, "a different package is already stored for this version; packages are immutable")
        BLOBS.mkdir(parents=True, exist_ok=True)
        (BLOBS / digest).write_bytes(data)
        state["releases"][key] = {**(rel or {"edition_id": eid, "version": version, "status": "staged"}),
                                  "package_sha256": digest, "package_size": len(data)}
        return {"sha256": digest, "size": len(data)}
    return mutate("package", request, idempotency_key, fn)


@app.put("/v1/editions/{eid}/releases/{version}", dependencies=[Depends(publisher)])
def put_release(eid: str, version: str, request: Request, body: dict = Body(...),
                idempotency_key: str | None = Header(None)):
    def fn(state):
        key = f"{eid}@{version}"
        rel = state["releases"].get(key)
        if not rel or not rel.get("package_sha256"):
            raise HTTPException(409, "upload the package first")
        if body.get("package", {}).get("sha256") not in (None, rel["package_sha256"]):
            raise HTTPException(409, "release metadata references a different package")
        rel_id = rel.get("id") or new_id(state, "rel")
        state["releases"][key] = {**rel, **body, "id": rel_id, "edition_id": eid, "version": version,
                                  "status": "withdrawn" if rel.get("status") == "withdrawn" else "available",
                                  "available_at": rel.get("available_at") or now()}
        return {"id": rel_id}
    return mutate("release", request, idempotency_key, fn)


@app.put("/v1/editions/{eid}/pointer", dependencies=[Depends(publisher)])
def set_pointer(eid: str, request: Request, body: dict = Body(...), idempotency_key: str | None = Header(None)):
    def fn(state):
        key = f"{eid}@{body['version']}"
        rel = state["releases"].get(key)
        if not rel or rel.get("status") != "available":
            raise HTTPException(409, f"version {body['version']} is not available for this edition")
        state["pointers"][eid] = body["version"]
        state["pointer_history"].setdefault(eid, []).append({"version": body["version"], "at": now(),
                                                            "reason": body.get("reason", "")})
        return {"current": body["version"], "history": state["pointer_history"][eid]}
    return mutate("pointer", request, idempotency_key, fn)


@app.post("/v1/editions/{eid}/releases/{version}/withdraw", dependencies=[Depends(publisher)])
def withdraw(eid: str, version: str, request: Request, body: dict = Body(...), idempotency_key: str | None = Header(None)):
    def fn(state):
        rel = state["releases"].get(f"{eid}@{version}")
        if not rel:
            raise HTTPException(404, "release not found")
        rel["status"], rel["withdrawn_reason"], rel["withdrawn_at"] = "withdrawn", body.get("reason", ""), now()
        return {"withdrawn": version}
    return mutate("withdraw", request, idempotency_key, fn)


@app.post("/v1/advisories", dependencies=[Depends(publisher)])
def advisory(request: Request, body: dict = Body(...), idempotency_key: str | None = Header(None)):
    def fn(state):
        aid = new_id(state, "adv")
        state["advisories"][aid] = {"id": aid, **body, "published_at": now()}
        notified = 0
        if body.get("notify_entitled_customers"):
            for ent in state["entitlements"].values():
                if body["edition_id"] in _ent_editions(state, ent):
                    state["notifications"].append({"customer_id": ent["customer_id"], "advisory_id": aid,
                                                   "title": body["title"], "at": now()})
                    notified += 1
        return {"id": aid, "notified": notified}
    return mutate("advisory", request, idempotency_key, fn)


@app.post("/v1/editions/{eid}/keys", dependencies=[Depends(publisher)])
def key_batch(eid: str, request: Request, body: dict = Body(...), idempotency_key: str | None = Header(None)):
    def fn(state):
        if eid not in state["editions"]:
            raise HTTPException(404, "edition not found")
        keys = []
        for _ in range(min(int(body.get("count", 1)), 1000)):
            k = "-".join(secrets.token_hex(2).upper() for _ in range(4))
            state["keys"][k] = {"edition_id": eid, "redeemed_by": None}
            keys.append(k)
        return {"keys": keys}
    return mutate("keys", request, idempotency_key, fn)


@app.get("/v1/entitlements", dependencies=[Depends(publisher)])
def entitlements():
    state = load()
    return {"entitlements": [{k: v for k, v in e.items() if k != "customer_email"} | {"customer_ref": e["customer_id"]}
                             for e in state["entitlements"].values()]}


@app.get("/v1/support/tickets", dependencies=[Depends(publisher)])
def tickets():
    return {"tickets": list(load()["tickets"].values())}


@app.get("/v1/retail/catalogue")
def retail_catalogue():
    """Feed for physical shops: boxed/USB editions with an allocated GTIN and print-ready artwork only."""
    state = load()
    items = [e for e in state["editions"].values() if e.get("kind") in ("boxed-key", "usb-collector")
             and e.get("gtin") and e.get("print_ready") and e["id"] in state["pointers"]]
    return {"items": [{"sku": e["sku"], "gtin": e["gtin"], "name": e["name"], "version": state["pointers"][e["id"]]}
                      for e in items],
            "excluded": [{"sku": e["sku"], "reason": "no allocated GTIN" if not e.get("gtin") else "no print-ready artwork"}
                         for e in state["editions"].values() if e.get("kind") in ("boxed-key", "usb-collector")
                         and not (e.get("gtin") and e.get("print_ready"))]}


# ------------------------------------------------------------------ public shop & customer library
@app.get("/v1/shop")
def shop():
    state = load()
    out = []
    for e in state["editions"].values():
        ver = state["pointers"].get(e["id"])
        if not ver:
            continue
        rel = state["releases"][f"{e['id']}@{ver}"]
        p = state["products"][e["product_id"]]
        out.append({"edition_id": e["id"], "product": p["title"], "edition": e["name"], "kind": e["kind"],
                    "price": e.get("price"), "version": ver, "licence": (e.get("licence") or {}).get("title"),
                    "requirements": rel.get("requirements"), "included_files": rel.get("included_files")})
    return {"items": out, "advisories": list(state["advisories"].values())}


def customer(x_customer_token: str = Header(...)) -> str:
    state = load()
    for cid, c in state["customers"].items():
        if c["token"] == x_customer_token:
            return cid
    raise HTTPException(401, "unknown customer token")


@app.post("/v1/customers")
def create_customer(body: dict = Body(...)):
    with LOCK:
        state = load()
        cid = new_id(state, "cus")
        token = secrets.token_urlsafe(16)
        state["customers"][cid] = {"id": cid, "email": body["email"], "name": body.get("name", ""), "token": token}
        save(state)
    return {"customer_id": cid, "customer_token": token}


def _grant(state: dict, cid: str, eid: str, order_ref: str, source: str) -> dict:
    ed = state["editions"][eid]
    ver = state["pointers"].get(eid)
    if not ver:
        raise HTTPException(409, "edition has no published release")
    ent_id = new_id(state, "ent")
    ent = {"id": ent_id, "customer_id": cid, "edition_id": eid, "order_ref": order_ref, "purchased_at": now(),
           "purchased_version": ver, "update_policy": ed.get("update_policy", {}), "status": "active", "source": source,
           "bundle_edition_ids": [x for x in ed.get("bundle_of_external", [])]}
    state["entitlements"][ent_id] = ent
    return ent


@app.post("/v1/orders")
def order(request: Request, body: dict = Body(...), cid: str = Depends(customer),
          idempotency_key: str | None = Header(None)):
    """Simulated checkout. No payment is taken; an order immediately grants the entitlement."""
    def fn(state):
        if body["edition_id"] not in state["editions"]:
            raise HTTPException(404, "edition not found")
        oid = new_id(state, "ord")
        ed = state["editions"][body["edition_id"]]
        state["orders"][oid] = {"id": oid, "customer_id": cid, "edition_id": body["edition_id"], "at": now(),
                                "price": ed.get("price"), "payment": "SIMULATED"}
        ent = _grant(state, cid, body["edition_id"], oid, "purchase")
        return {"order_id": oid, "entitlement": ent}
    return mutate("order", request, idempotency_key, fn)


@app.post("/v1/library/redeem")
def redeem(request: Request, body: dict = Body(...), cid: str = Depends(customer)):
    def fn(state):
        k = state["keys"].get(body["key"])
        if not k:
            raise HTTPException(404, "unknown key")
        if k["redeemed_by"]:
            raise HTTPException(409, "key already redeemed")
        k["redeemed_by"] = cid
        return {"entitlement": _grant(state, cid, k["edition_id"], f"key:{body['key']}", "boxed-key")}
    return mutate("redeem", request, None, fn)


def _vkey(v: str):
    return tuple(int(x) for x in v.split("-")[0].split("."))


def _ent_editions(state, ent) -> list[str]:
    return [ent["edition_id"]] + list(ent.get("bundle_edition_ids") or [])


def eligibility(state: dict, ent: dict, eid: str, version: str) -> tuple[bool, str]:
    """Mirror of Product Foundry's entitlement rule: purchased edition only, covered majors, update window."""
    if ent["status"] != "active":
        return False, "entitlement not active"
    if eid not in _ent_editions(state, ent):
        return False, "not part of the purchased edition"
    rel = state["releases"].get(f"{eid}@{version}")
    if not rel or rel.get("status") != "available":
        return False, "release not available (withdrawn or unpublished)"
    if version == ent["purchased_version"]:
        return True, "purchased version"
    pol = ent.get("update_policy") or {}
    if pol.get("covered_major_versions") and _vkey(version)[0] not in pol["covered_major_versions"]:
        return False, "major version not covered by this licence"
    if pol.get("patch_updates_only") and _vkey(version)[:2] != _vkey(ent["purchased_version"])[:2]:
        return False, "only patch updates are included"
    if _vkey(version) < _vkey(ent["purchased_version"]):
        return False, "older than the purchased version"
    window = datetime.fromisoformat(ent["purchased_at"]) + timedelta(days=int(pol.get("updates_for_days", 0)))
    if datetime.fromisoformat(rel["available_at"]) > window:
        return False, "released after the update entitlement ended"
    return True, "update included in entitlement"


@app.get("/v1/library")
def library(cid: str = Depends(customer)):
    state = load()
    out = []
    for ent in state["entitlements"].values():
        if ent["customer_id"] != cid:
            continue
        items = []
        for key, rel in state["releases"].items():
            eid, ver = key.split("@")
            if eid not in _ent_editions(state, ent):
                continue
            ok, why = eligibility(state, ent, eid, ver)
            items.append({"edition_id": eid, "version": ver, "downloadable": ok, "reason": why,
                          "sha256": rel.get("package_sha256")})
        out.append({"entitlement": ent, "edition": state["editions"][ent["edition_id"]]["name"],
                    "releases": sorted(items, key=lambda x: _vkey(x["version"]))})
    notes = [n for n in state["notifications"] if n["customer_id"] == cid]
    return {"entitlements": out, "notifications": notes}


@app.get("/v1/library/download/{eid}/{version}")
def download(eid: str, version: str, cid: str = Depends(customer)):
    state = load()
    reasons = []
    for ent in state["entitlements"].values():
        if ent["customer_id"] == cid:
            ok, why = eligibility(state, ent, eid, version)
            if ok:
                rel = state["releases"][f"{eid}@{version}"]
                data = (BLOBS / rel["package_sha256"]).read_bytes()
                return Response(data, media_type="application/zip", headers={
                    "X-Content-SHA256": rel["package_sha256"],
                    "Content-Disposition": f'attachment; filename="{eid}-{version}.zip"'})
            reasons.append(why)
    raise HTTPException(403, {"message": "not entitled to this download", "reasons": reasons})


@app.post("/v1/support/tickets")
def open_ticket(body: dict = Body(...), cid: str = Depends(customer)):
    with LOCK:
        state = load()
        tid = new_id(state, "tkt")
        c = state["customers"][cid]
        state["tickets"][tid] = {"id": tid, "customer_id": cid, "customer_email": c["email"],
                                 "customer_name": c["name"], "edition_id": body["edition_id"],
                                 "version": body.get("version"), "subject": body["subject"], "body": body["body"],
                                 "severity": body.get("severity", "unknown"), "kind": body.get("kind", "bug"),
                                 "opened_at": now()}
        save(state)
    return {"ticket_id": tid}


# ------------------------------------------------------------------ test controls
@app.post("/_faults")
def add_fault(body: dict = Body(...)):
    with LOCK:
        state = load()
        state["faults"].append({"op": body["op"], "when": body.get("when", "after"), "remaining": int(body.get("count", 1))})
        save(state)
    return {"faults": state["faults"]}


@app.get("/_state")
def dump_state():
    state = load()
    return {k: v for k, v in state.items() if k not in ("idempotency",)} | {"idempotency_keys": len(state["idempotency"])}


@app.post("/_reset")
def reset():
    with LOCK:
        save(_empty())
    return {"ok": True}


@app.get("/health")
def health():
    return {"status": "ok"}
