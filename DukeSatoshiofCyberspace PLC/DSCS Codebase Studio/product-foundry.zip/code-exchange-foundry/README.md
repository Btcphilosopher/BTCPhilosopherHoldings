# The Code Exchange — Product Foundry

Product Foundry is The Code Exchange's internal workshop for turning a source-code project into a product
that has been tested, documented, licensed and packaged, and is ready to sell:

```
Idea → repository → development → testing → product preparation → release approval → packaging
     → storefront publication → updates and support
```

It is a modular monolith with a separate build worker:

| Part | Technology | Directory |
|---|---|---|
| Internal interface | Next.js 16, React 19, TypeScript | `web/` |
| API and workflow orchestration | Python 3.13, FastAPI | `backend/foundry/` |
| Authoritative records | PostgreSQL (Alembic migrations) | `backend/migrations/` |
| Build outputs, documents, artwork, packages | S3-compatible storage (SeaweedFS in Compose; local disk for development) | `backend/foundry/storage.py` |
| Durable background jobs | PostgreSQL queue (`FOR UPDATE SKIP LOCKED`, bounded retries, dead-lettering) | `backend/foundry/jobs.py` |
| Isolated build workers | Docker sandbox (default in Compose) or a local namespace sandbox | `backend/foundry/sandbox.py`, `worker.py` |
| Git adapters | Local Git (working); GitHub and GitLab REST (implemented, not tested against live services) | `backend/foundry/gitadapter.py` |
| Mock storefront | FastAPI publishing API, customer library, fault injection | `storefront_mock/` |
| Sample product | **CSV Workshop**, an original Python CLI that validates and summarises CSV files | `sample/csv-workshop/` |

The full account of what is implemented, simulated, integrated and tested is in
**[docs/STATUS.md](docs/STATUS.md)**. Architecture: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md). Security model and
permissions: [docs/SECURITY.md](docs/SECURITY.md). API: [docs/API.md](docs/API.md) and `docs/openapi.json`.
A recorded run of the demonstration is in [docs/demo-transcript.txt](docs/demo-transcript.txt), and
screenshots of the interface with the demonstration data are in [docs/screenshots/](docs/screenshots/).

---

## Option A: Docker Compose

Requirements: Docker Engine 24+ with Compose v2, and outbound access to Docker Hub, PyPI and npm for the
first build.

```bash
cp .env.example .env
```

```bash
docker pull python:3.13-slim
```

```bash
docker compose up --build -d
```

```bash
docker compose exec api python /app/scripts/demo.py
```

Then open http://localhost:3000 and sign in as any demonstration user (password `foundry-demo`):
`pat` (product manager), `dana` (developer), `ravi` (reviewer), `quinn` (quality), `devi` (documentation),
`lena` (licences), `rowan` (release manager), `cass` (catalogue), `sam` (support), `alex` (administrator), each
`@codeexchange.example`. API docs: http://localhost:8000/api/docs. Mock storefront: http://localhost:8100/v1/shop.

The `python:3.13-slim` image is the build sandbox: each pipeline stage runs in a new container created from
it. The worker reaches Docker only through `docker-proxy`, a filtered socket proxy. Build containers get no
socket, no bind mounts and no secrets.

To reset everything:

```bash
docker compose down -v
```

## Option B: directly on a Linux host (development)

Requirements: Python 3.11+ (3.13 tested), git, util-linux (`unshare`, `setpriv`), PostgreSQL 14+ (16 tested),
and Node 20+ (22 tested) for the web interface.

Create the database once:

```bash
sudo -u postgres psql -c "CREATE USER foundry WITH PASSWORD 'foundry' CREATEDB;" -c "CREATE DATABASE foundry OWNER foundry;"
```

Run the API, worker, storefront and demonstration. The script ends by serving the web interface on port 3000:

```bash
sudo ./scripts/run-local.sh
```

With the local sandbox, build commands run in a new network namespace as uid 65534, under rlimits. That
needs root. Without root, or for a real filesystem boundary, use Docker instead:

```bash
FOUNDRY_SANDBOX=docker ./scripts/run-local.sh
```

Run the web interface on its own:

```bash
cd web && npm ci && npm run dev
```

The interface proxies `/api/v1` to `FOUNDRY_API_INTERNAL_URL` (default `http://localhost:8000`).

## Tests

The suite needs a PostgreSQL database it may drop and recreate (default
`postgresql+psycopg://foundry:foundry@localhost:5432/foundry_test`):

```bash
sudo -u postgres psql -c "CREATE DATABASE foundry_test OWNER foundry;"
```

```bash
sudo ./scripts/test.sh
```

It contains 75 tests across build isolation, permissions, artefact integrity, immutable releases, approval rules,
publication retries, entitlement mapping, requirement states, documentation gates, jobs and audit. The last test
runs the whole demonstration over real HTTP. Set `FOUNDRY_SKIP_E2E=1` to skip it. The Docker sandbox test is
skipped automatically when no Docker daemon is available.

## What the demonstration does

`scripts/demo.py` drives the system through the public API, as the interface does:

1. Creates the CSV Workshop project. It records 9 requirements with acceptance criteria, tasks, costs, two
   commercial licence versions with explicit rights, and three editions: digital, source and boxed.
2. Creates a local Git repository, connects it, and records provenance.
3. Commits a change (a median statistic) with a bug.
4. Runs the pipeline. One test fails. Dependent stages are skipped and independent ones still run.
5. Fixes the bug and rebuilds; the failed build stays on record. It also runs and **cancels** a slow
   experimental build. The SBOM stage raises a **licence review** for an icon of unknown origin; the icon is
   rejected, replaced and rebuilt.
6. Creates release 1.0.0. Approval is **blocked by unsupported platform claims** (Windows and macOS have no
   evidence). The claim is narrowed, macOS verification is recorded, and documents are generated (examples
   executed in the sandbox), reviewed and approved. An accessibility gap is accepted as a documented
   exception with an owner and an expiry.
7. Freezes the candidate: application, source archive and starter kit; digital, source and boxed edition
   packages; manifests with hashes.
8. Renders box artwork mockups. The print-ready export is refused because no GTIN is allocated.
9. Reviews release evidence. Each check links to its evidence.
10. Approves the release, which is then immutable. The creator cannot approve it, and edits are refused.
11. Publishes through the mock storefront with injected failures. The publication job is **retried** and
    nothing is duplicated.
12. Runs a simulated purchase and an entitled download whose checksum matches the approved manifest. It
    checks that the purchaser is denied an edition they did not buy, and redeems a boxed-edition key.
13. Imports a customer report (contact details redacted) and publishes bug-fix release 1.0.1. 1.0.0 is
    superseded, the catalogue pointer is rolled back and forward, and 1.0.0 is withdrawn with customer
    notification.

## Repository layout

```
backend/            FastAPI app, worker, models, migrations, tests
  foundry/api/      HTTP routers (core, projects, engineering, release, commerce)
storefront_mock/    Mock storefront publishing API and customer library
sample/csv-workshop Source of the sample product (copied into a Git repo by the demo)
web/                Next.js internal interface
wheelhouse/         Vetted dependency cache offered to builds (tabulate 0.10.0, MIT)
deploy/             Object-store configuration
scripts/            demo.py, run-local.sh, test.sh, fetch-wheelhouse.sh
docs/               Architecture, security, status, API reference, demo transcript
```
