#!/usr/bin/env bash
# Backend test suite against PostgreSQL (database is dropped and recreated).
#   TEST_DATABASE_URL=postgresql+psycopg://foundry:foundry@localhost:5432/foundry_test ./scripts/test.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/backend"
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate
pip install -q -r requirements-dev.txt
FOUNDRY_TEST_WHEELHOUSE="$ROOT/wheelhouse" python -m pytest -q "$@"
(cd "$ROOT/web" && npm ci --no-audit --no-fund >/dev/null && npx tsc --noEmit && echo "web: typecheck ok")
