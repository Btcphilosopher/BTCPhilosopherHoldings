#!/usr/bin/env bash
# Rebuild the vetted wheelhouse offered to build sandboxes (builds themselves have no network).
# Every wheel is pinned by hash in the sample's requirements.lock; pip refuses mismatches.
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m pip download --only-binary=:all: --no-deps --require-hashes -r sample/csv-workshop/requirements.lock -d wheelhouse
ls -l wheelhouse
