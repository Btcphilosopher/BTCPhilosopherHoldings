#!/usr/bin/env python3
"""End-to-end demonstration of Product Foundry with the CSV Workshop sample product.

Talks to the running services over HTTP exactly as the web interface does:
    FOUNDRY_API          (default http://localhost:8000)
    FOUNDRY_STOREFRONT   (default http://localhost:8100)
    DEMO_REPO_ROOT       directory inside FOUNDRY_REPO_ROOTS where the local Git repository is created

Run after `python -m foundry.seed` with a worker running. Every step prints what happened; the script
exits non-zero if an expectation fails.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import date, timedelta
from pathlib import Path

import httpx

API = os.environ.get("FOUNDRY_API", "http://localhost:8000").rstrip("/") + "/api/v1"
SHOP = os.environ.get("FOUNDRY_STOREFRONT", "http://localhost:8100").rstrip("/")
REPO_ROOT = Path(os.environ.get("DEMO_REPO_ROOT", "./var/repos")).resolve()
SAMPLE = Path(os.environ.get("DEMO_SAMPLE", Path(__file__).resolve().parent.parent / "sample" / "csv-workshop"))
PASSWORD = "foundry-demo"
TIMEOUT = float(os.environ.get("DEMO_WAIT_SECONDS", "300"))

USERS = {"pm": "pat", "dev": "dana", "reviewer": "ravi", "qe": "quinn", "docs": "devi", "licence": "lena",
         "rm": "rowan", "cat": "cass", "support": "sam", "admin": "alex"}


class DemoFailure(Exception):
    pass


def step(n, title):
    print(f"\n\033[1;35m== {n}. {title}\033[0m")


def note(msg):
    print(f"   {msg}")


def expect(cond, msg):
    if not cond:
        raise DemoFailure(msg)
    print(f"   \033[32m✓\033[0m {msg}")


class Api:
    def __init__(self):
        self.http = httpx.Client(timeout=60)
        self.tokens = {}
        for role, name in USERS.items():
            r = self.http.post(f"{API}/auth/login", json={"email": f"{name}@codeexchange.example", "password": PASSWORD})
            r.raise_for_status()
            self.tokens[role] = r.json()["token"]

    def call(self, who, method, path, ok=(200,), **kw):
        r = self.http.request(method, f"{API}{path}", headers={"Authorization": f"Bearer {self.tokens[who]}"}, **kw)
        if r.status_code not in ok:
            raise DemoFailure(f"{who} {method} {path} -> {r.status_code}: {r.text[:800]}")
        ct = r.headers.get("content-type", "")
        return r.json() if "json" in ct else r.text

    def get(self, who, path, **kw):
        return self.call(who, "GET", path, **kw)

    def post(self, who, path, body=None, **kw):
        return self.call(who, "POST", path, json=body if body is not None else {}, **kw)

    def patch(self, who, path, body, **kw):
        return self.call(who, "PATCH", path, json=body, **kw)

    def put(self, who, path, body, **kw):
        return self.call(who, "PUT", path, json=body, **kw)

    def wait_build(self, bid, until=("passed", "failed", "cancelled", "error")):
        t0 = time.time()
        while time.time() - t0 < TIMEOUT:
            b = self.get("dev", f"/builds/{bid}")
            if b["status"] in until:
                return b
            time.sleep(1)
        raise DemoFailure(f"build {bid} did not reach {until}")

    def wait_job(self, jid, until=("succeeded", "dead", "cancelled")):
        t0 = time.time()
        while time.time() - t0 < TIMEOUT:
            js = [j for j in self.get("admin", "/jobs?limit=500") if j["id"] == jid]
            if js and js[0]["status"] in until:
                return js[0]
            time.sleep(0.5)
        raise DemoFailure(f"job {jid} did not finish")

    def wait_publication(self, pid):
        t0 = time.time()
        while time.time() - t0 < TIMEOUT:
            p = self.get("cat", f"/publication-jobs/{pid}")
            if p["status"] in ("succeeded", "dead"):
                return p
            time.sleep(0.5)
        raise DemoFailure("publication did not finish")


# ------------------------------------------------------------------ git helpers (the developer's machine)
def git(repo: Path, *args, env=None):
    e = {**os.environ, "GIT_AUTHOR_NAME": "Dana Okafor", "GIT_AUTHOR_EMAIL": "dana@codeexchange.example",
         "GIT_COMMITTER_NAME": "Dana Okafor", "GIT_COMMITTER_EMAIL": "dana@codeexchange.example", **(env or {})}
    return subprocess.run(["git", "-C", str(repo), *args], check=True, capture_output=True, text=True, env=e).stdout.strip()


def edit(repo: Path, path: str, old: str, new: str):
    p = repo / path
    text = p.read_text()
    if old not in text:
        raise DemoFailure(f"demo edit anchor not found in {path}")
    p.write_text(text.replace(old, new, 1))


def commit(repo: Path, message: str) -> str:
    git(repo, "add", "-A")
    git(repo, "commit", "-q", "-m", message)
    return git(repo, "rev-parse", "HEAD")


MEDIAN_BUGGY = '''

def median(numbers):
    ordered = sorted(numbers)
    return ordered[len(ordered) // 2]
'''
MEDIAN_FIXED = '''

def median(numbers):
    ordered = sorted(numbers)
    mid = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[mid]
    return (ordered[mid - 1] + ordered[mid]) / 2
'''
MEDIAN_TEST = '''
    def test_median_even_and_odd(self):
        """Requirement: REQ-002"""
        path = write_csv("v\\n1\\n2\\n3\\n4\\n")
        try:
            col = summarise(path)["columns"][0]
            self.assertEqual(col["median"], 2.5)
        finally:
            cleanup(path)
        path = write_csv("v\\n5\\n1\\n3\\n")
        try:
            self.assertEqual(summarise(path)["columns"][0]["median"], 3.0)
        finally:
            cleanup(path)
'''
SLOW_TEST = '''import time
import unittest


class SlowImportTests(unittest.TestCase):
    def test_large_import_soak(self):
        """Experimental soak test: deliberately long-running."""
        time.sleep(120)


if __name__ == "__main__":
    unittest.main()
'''
NEW_ICON = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" role="img" aria-label="CSV Workshop">'
            '<rect width="64" height="64" rx="12" fill="#1d1c1f"/><rect x="12" y="14" width="40" height="36" rx="3" '
            'fill="none" stroke="#c8006e" stroke-width="4"/><path d="M12 26h40M12 38h40M26 14v36M39 14v36" '
            'stroke="#f6f1e7" stroke-width="2.5"/></svg>\n')
NEW_ASSETS = json.dumps([{
    "path": "assets/icon.svg", "kind": "artwork",
    "origin": "Drawn in-house by Dana Okafor (employee) on 2026-11-20; replaces the unverified prototype icon",
    "licence": "LicenceRef-TCX-Owned",
    "attribution": "Copyright The Code Exchange Ltd"}], indent=2) + "\n"
BOM_TEST = '''
    def test_byte_order_mark_is_ignored(self):
        """Requirement: REQ-001"""
        path = write_csv("\\ufeffname,age\\nAda,36\\n")
        try:
            report = validate(path)
            self.assertTrue(report.ok)
            from csv_workshop.reader import read_table
            self.assertEqual(read_table(path)[0][0], "name")
        finally:
            cleanup(path)
'''

REQUIREMENTS = [
    ("REQ-001", "workflow", "Validate a CSV file and report structural problems with row numbers",
     "Given a file with an inconsistent field count, `validate` exits 1 and names each offending row."),
    ("REQ-002", "functional", "Summarise each column (type, missing, unique, min/max/mean/median)",
     "`summarise` reports inferred type and counts for every column and numeric statistics for numeric columns."),
    ("REQ-003", "functional", "Validate against a JSON schema of required columns and types",
     "Missing required columns and values of the wrong type are reported."),
    ("REQ-004", "environment", "Run on Python 3.10+ with no additional installation",
     "The single-file application runs with a stock interpreter on every claimed platform."),
    ("REQ-005", "performance", "Summarise 100,000 rows in under 5 seconds on the reference worker",
     "Automated performance test passes on the build worker."),
    ("REQ-006", "accessibility", "All output usable as plain text or JSON without colour",
     "No ANSI escape codes; every result available in text and JSON."),
    ("REQ-007", "installation", "Install by copying one file; upgrade by replacing it",
     "Installation test runs the packaged file from a clean directory."),
    ("REQ-008", "data", "Export summaries as JSON with a stable schema",
     "JSON keys are stable and documented."),
    ("REQ-009", "support", "Support covers documented commands on verified platforms; files over 2 GB are out of scope",
     "Support documentation states the boundary."),
]


def main() -> int:
    api = Api()
    shop = httpx.Client(base_url=SHOP, timeout=30)
    users = {u["email"].split("@")[0]: u for u in api.get("admin", "/users")}

    # ------------------------------------------------------------------ 1
    step(1, "Create the project, its acceptance criteria, licences and editions")
    proj = api.post("pm", "/projects", {
        "slug": "csv-workshop", "name": "CSV Workshop",
        "idea": "A dependable command-line tool that checks CSV exports before they reach a database or report.",
        "intended_customers": "Data analysts, small finance teams and developers who receive CSV files from others.",
        "problem_statement": "CSV files arrive with broken rows, duplicated headers and mistyped values that are only "
                             "noticed after an import fails.",
        "supported_platforms": ["linux-x86_64", "macos-arm64", "windows-x86_64"],
        "tech_stack": ["Python 3.10+", "tabulate"], "intended_licence": "The Code Exchange Standard Licence",
        "source_distribution_model": "binary + optional source edition", "status": "development",
        "support_owner_id": users["sam"]["id"], "dependencies_note": "tabulate (MIT) for table output"})
    pid = proj["id"]
    note(f"project #{pid} '{proj['name']}' claims platforms {proj['supported_platforms']}")
    for uid, resp in ((users["dana"]["id"], "lead developer"), (users["quinn"]["id"], "quality"),
                      (users["devi"]["id"], "documentation")):
        api.post("pm", f"/projects/{pid}/members", {"user_id": uid, "responsibility": resp})
    reqs = {}
    for key, cat, title, ac in REQUIREMENTS:
        reqs[key] = api.post("pm", f"/projects/{pid}/requirements", {"key": key, "category": cat, "title": title,
                                                                     "acceptance_criteria": ac})
    expect(len(reqs) == 9, "9 requirements with acceptance criteria recorded as 'proposed'")
    ms = api.post("pm", f"/projects/{pid}/milestones", {"title": "1.0 general availability",
                                                       "due_on": str(date.today() + timedelta(days=30))})
    tasks = {}
    for key in reqs:
        tasks[key] = api.post("pm", f"/projects/{pid}/tasks", {"title": f"Implement {key}", "milestone_id": ms["id"],
                                                              "assignee_id": users["dana"]["id"],
                                                              "requirement_ids": [reqs[key]["id"]]})
    api.post("pm", f"/projects/{pid}/costs", {"kind": "estimate", "amount": 4800, "description": "Engineering, 8 days"})
    api.post("pm", f"/projects/{pid}/costs", {"kind": "estimate", "amount": 900, "category": "packaging",
                                              "description": "Box design and print proofs"})
    api.post("dev", f"/projects/{pid}/contributors", {"name": "Dana Okafor", "relationship": "employee",
                                                      "ownership": "Work for hire; owned by The Code Exchange Ltd",
                                                      "agreement_ref": "EMP-0142", "verified": True})
    std_rights = {"binary_distribution": True, "source_access": False, "permission_to_modify": False,
                  "redistribution": False, "commercial_deployment": "internal business use, unlimited users at one organisation",
                  "update_entitlement": "per edition update policy", "support_entitlement": "per edition support terms",
                  "copyright_transfer": False}
    lic_std = api.post("licence", "/licence-versions", {
        "project_id": pid, "code": "TCX-STD", "version": "1.0", "title": "The Code Exchange Standard Licence",
        "summary": "Use the application inside one organisation. No redistribution. Copyright stays with The Code Exchange.",
        "text": "1. Grant. You may install and use the Software for your organisation's internal purposes.\n"
                "2. Restrictions. You may not redistribute, sublicense or modify the Software.\n"
                "3. Ownership. The Software is licensed, not sold; all intellectual property remains with the licensor.\n"
                "4. Updates and support are provided as described for the edition purchased.\n",
        "rights": std_rights})
    bad = api.call("licence", "POST", "/licence-versions", ok=(422,), json={
        "project_id": pid, "code": "TCX-SRC", "version": "0.9", "title": "Draft source licence", "summary": "x",
        "text": "x", "rights": {**std_rights, "source_access": True, "redistribution": "unlimited"}})
    expect("redistribution" in json.dumps(bad), "source access with unlimited redistribution is refused by the backend")
    lic_src = api.post("licence", "/licence-versions", {
        "project_id": pid, "code": "TCX-SRC", "version": "1.0", "title": "The Code Exchange Source Licence",
        "summary": "Read, build and modify the source for internal use. Modified binaries may be deployed internally only. "
                   "No copyright transfer and no redistribution of source.",
        "text": "1. Grant. You may access, build and modify the Source Code for your organisation's internal use.\n"
                "2. Deployment. You may deploy binaries built from modified source within your organisation.\n"
                "3. Restrictions. You may not redistribute the Source Code or binaries outside your organisation.\n"
                "4. Ownership. Purchasing source access does not transfer copyright or other ownership.\n",
        "rights": {**std_rights, "source_access": True, "permission_to_modify": True,
                   "redistribution": "modified-binaries-internal-only"}})
    for lv in (lic_std, lic_src):
        api.post("licence", f"/licence-versions/{lv['id']}/approve")
    expect(True, "commercial licences TCX-STD 1.0 and TCX-SRC 1.0 approved with explicit, separate rights")
    product = api.post("pm", f"/projects/{pid}/products", {
        "slug": "csv-workshop", "name": "CSV Workshop", "tagline": "Check CSV files before they cause trouble.",
        "description": "CSV Workshop validates the structure of CSV files, checks them against a simple schema and "
                       "summarises every column, from the command line, in text or JSON."})
    prid = product["id"]
    policy = {"covered_major_versions": [1], "updates_for_days": 365, "includes_future_editions": False}
    ed_digital = api.post("pm", f"/products/{prid}/editions", {
        "code": "digital", "name": "Digital Edition", "kind": "digital-download", "licence_version_id": lic_std["id"],
        "sku": "TCX-CSVW-DIG", "price": {"currency": "GBP", "amount": "19.00", "tax_inclusive": True},
        "delivery_method": "download", "update_policy": policy,
        "support_terms": "Email support for 12 months from purchase.", "support_days": 365})
    ed_source = api.post("pm", f"/products/{prid}/editions", {
        "code": "source", "name": "Source Code Edition", "kind": "source-archive", "licence_version_id": lic_src["id"],
        "sku": "TCX-CSVW-SRC", "price": {"currency": "GBP", "amount": "79.00", "tax_inclusive": True},
        "delivery_method": "download", "update_policy": policy,
        "support_terms": "Email support for 12 months, including build questions.", "support_days": 365})
    ed_boxed = api.post("pm", f"/products/{prid}/editions", {
        "code": "boxed", "name": "Boxed Edition (download key)", "kind": "boxed-key", "licence_version_id": lic_std["id"],
        "sku": "TCX-CSVW-BOX", "price": {"currency": "GBP", "amount": "29.00", "tax_inclusive": True},
        "delivery_method": "download-key",
        "update_policy": {"covered_major_versions": [1], "updates_for_days": 365, "patch_updates_only": True},
        "support_terms": "Email support for 12 months from key redemption.", "support_days": 365,
        "physical": {"template": "dvd-style-box"}})
    expect(True, "editions: digital (TCX-STD), source archive (TCX-SRC), boxed download-key (TCX-STD, patch updates only)")

    # ------------------------------------------------------------------ 2
    step(2, "Connect a local Git repository")
    repo = REPO_ROOT / "csv-workshop"
    if repo.exists():
        shutil.rmtree(repo)
    shutil.copytree(SAMPLE, repo, ignore=shutil.ignore_patterns("__pycache__", ".deps", "dist", "build", "reports"))
    git(repo, "init", "-q", "-b", "main")
    c0 = commit(repo, "Initial CSV Workshop: validate and summarise")
    r = api.post("dev", f"/projects/{pid}/repositories", {"provider": "local", "name": "csv-workshop",
                                                          "location": str(repo), "protected_branches": ["main"],
                                                          "scopes": ["read", "assistant-branches"]})
    rid = r["id"]
    expect(r["origin"]["root_commit"] == c0, f"repository #{rid} connected; provenance root commit {c0[:12]}")
    tree = api.get("dev", f"/repositories/{rid}/tree?ref=main")
    note("tree: " + ", ".join(e["name"] for e in tree["entries"]))
    outside = api.call("dev", "POST", f"/projects/{pid}/repositories", ok=(422,),
                       json={"provider": "local", "name": "etc", "location": "/etc"})
    expect("outside" in json.dumps(outside), "connecting a path outside the permitted repository roots is refused")

    # ------------------------------------------------------------------ 3 & 4
    step(3, "Introduce a code change (median statistic)")
    edit(repo, "src/csv_workshop/summary.py", "\n\ndef summarise(", MEDIAN_BUGGY + "\n\ndef summarise(")
    edit(repo, "src/csv_workshop/summary.py", '            col["mean"] = round(sum(numbers) / len(numbers), 6)\n',
         '            col["mean"] = round(sum(numbers) / len(numbers), 6)\n            col["median"] = median(numbers)\n')
    edit(repo, "tests/test_summary.py", "\n    def test_infer_type_empty(self):", MEDIAN_TEST + "\n    def test_infer_type_empty(self):")
    edit(repo, "tests/test_cli.py", '"top", "min", "max", "mean"]', '"top", "min", "max", "mean",\n                        "median"]')
    edit(repo, "docs/REFERENCE.md", "minimum, maximum and mean.", "minimum, maximum, mean and median.")
    c1 = commit(repo, "Add median to column summaries")
    note(f"commit {c1[:12]}: Add median to column summaries")
    for key in reqs:
        api.patch("dev", f"/tasks/{tasks[key]['id']}", {"status": "done"})
        api.patch("dev", f"/requirements/{reqs[key]['id']}", {"status": "implemented"})
    rq = api.get("pm", f"/projects/{pid}/requirements")
    expect(all(x["status"] == "implemented" and x["tasks_done"] for x in rq),
           "all tasks done; requirements are 'implemented' — completing tasks did not mark anything tested or accepted")

    step(4, "Run the pipeline: one failing test")
    b1 = api.post("dev", f"/repositories/{rid}/builds", {"ref": "main"})
    b1 = api.wait_build(b1["id"])
    failed = [t for t in b1["tests"] if t["status"] != "passed"]
    expect(b1["status"] == "failed" and len(failed) == 1,
           f"build #{b1['number']} at {b1['commit_sha'][:12]} failed: {failed[0]['suite']}.{failed[0]['name']}")
    note("failure: " + failed[0]["message"].splitlines()[-1][:120])
    stages = {s["name"]: s["status"] for s in b1["stages"]}
    note(f"stages: {stages}")
    expect(stages["package"] == "skipped" and stages["dependency-audit"] == "passed",
           "dependent stages skipped; independent stages still ran and their results were kept")
    expect(b1["worker_env"]["network"] in ("isolated namespace", "none"),
           f"sandbox: {b1['worker_env']['sandbox']} network={b1['worker_env']['network']} memory={b1['worker_env']['memory_mb']}MB")

    # ------------------------------------------------------------------ 5
    step(5, "Correct the issue and build again; cancel an experimental build; resolve a licence review")
    edit(repo, "src/csv_workshop/summary.py", MEDIAN_BUGGY, MEDIAN_FIXED)
    c2 = commit(repo, "Fix median for even-length columns")
    b2 = api.wait_build(api.post("dev", f"/repositories/{rid}/builds", {"ref": "main"})["id"])
    expect(b2["status"] == "passed", f"build #{b2['number']} at {c2[:12]} passed "
                                      f"({sum(t['status'] == 'passed' for t in b2['tests'])} tests)")
    old = api.get("dev", f"/builds/{b1['id']}")
    expect(old["status"] == "failed", f"build #{b1['number']} is still recorded as failed (not replaced)")
    for a in b2["artifacts"]:
        note(f"artefact {a['role']:<12} {a['filename']:<40} sha256 {a['sha256'][:16]}…")

    git(repo, "checkout", "-q", "-b", "experiment/soak-test")
    (repo / "tests" / "test_soak.py").write_text(SLOW_TEST)
    c_slow = commit(repo, "Experimental soak test")
    git(repo, "checkout", "-q", "main")
    bs = api.post("dev", f"/repositories/{rid}/builds", {"ref": "experiment/soak-test"})
    t0 = time.time()
    while time.time() - t0 < TIMEOUT:
        cur = api.get("dev", f"/builds/{bs['id']}")
        if any(s["name"] == "test" and s["status"] == "running" for s in cur.get("stages", [])):
            break
        time.sleep(0.5)
    time.sleep(1.5)
    api.post("dev", f"/builds/{bs['id']}/cancel")
    bs = api.wait_build(bs["id"])
    expect(bs["status"] == "cancelled", f"build #{bs['number']} ({c_slow[:12]}) cancelled during the test stage; "
                                        "the running stage was killed and the remaining stages marked cancelled")

    reviews = api.get("licence", f"/projects/{pid}/licence-reviews")
    icon = [x for x in reviews if x["subject_ref"].startswith("assets/icon.svg") and x["status"] == "open"]
    expect(len(icon) == 1, f"licence review opened by the SBOM stage: {icon[0]['subject_ref']} — {icon[0]['issue'][:70]}…")
    sbom = api.get("licence", f"/builds/{b2['id']}/sbom")
    note("SBOM components: " + ", ".join(f"{c['name']} {c['version']} ({c['licence_declared']})" for c in sbom["components"]))
    api.post("licence", f"/licence-reviews/{icon[0]['id']}/decide", {
        "status": "rejected", "decision": "Origin unverified and no licence; must be replaced before release."})
    (repo / "assets" / "icon.svg").write_text(NEW_ICON)
    (repo / "assets" / "ASSETS.json").write_text(NEW_ASSETS)
    c3 = commit(repo, "Replace prototype icon with original artwork")
    b3 = api.wait_build(api.post("dev", f"/repositories/{rid}/builds", {"ref": "main"})["id"])
    expect(b3["status"] == "passed", f"build #{b3['number']} at {c3[:12]} passed with the in-house icon")
    reviews = api.get("licence", f"/projects/{pid}/licence-reviews")
    expect(not [x for x in reviews if x["status"] == "open"],
           "no open licence reviews: the replaced asset is first-party (LicenceRef-TCX-Owned) and tabulate is MIT")

    for key in ("REQ-004", "REQ-009"):
        api.post("qe", f"/requirements/{reqs[key]['id']}/evidence", {
            "kind": "manual" if key == "REQ-004" else "document", "result": "passed",
            "reference": "QA-2026-118 install matrix" if key == "REQ-004" else "support.md (release documentation)",
            "note": "Recorded by quality engineering."})
    rq = {x["key"]: x for x in api.get("pm", f"/projects/{pid}/requirements")}
    expect(all(x["status"] == "tested" for x in rq.values()), "all requirements 'tested' from linked evidence")
    for key, x in rq.items():
        api.post("reviewer", f"/requirements/{x['id']}/accept")
    expect(True, "reviewer accepted all 9 requirements against their evidence")

    # ------------------------------------------------------------------ 6, 7, 8, 9 (first attempt)
    step(6, "Create release 1.0.0 and try to take it straight to approval")
    rel = api.post("dev", f"/products/{prid}/releases", {"version": "1.0.0", "build_id": b3["id"],
                                                         "notes": "First release of CSV Workshop."})
    relid = rel["id"]
    note(f"release 1.0.0 (draft) from build #{b3['number']} commit {rel['commit_sha'][:12]}; "
         f"claims {rel['platform_claims']}")
    api.post("rm", f"/releases/{relid}/candidate")
    api.post("rm", f"/releases/{relid}/validation")
    ready = api.get("rm", f"/releases/{relid}/readiness")
    note("blocking checks: " + ", ".join(ready["blocking"]))
    plat = next(c for c in ready["checks"] if c["key"] == "platforms")
    expect(plat["status"] == "failed", f"platform check: {plat['summary']}")
    denied = api.call("rm", "POST", f"/releases/{relid}/approve", ok=(409,), json={"comment": "try"})
    expect("platforms" in json.dumps(denied), "approval refused while claimed platforms lack verification")
    api.post("rm", f"/releases/{relid}/return-to-draft", {"reason": "Unverified platform claims and missing evidence"})

    step(7, "Fix the claims, record verification and reviews, produce documentation")
    api.patch("rm", f"/releases/{relid}", {"platform_claims": ["linux-x86_64", "macos-arm64"],
                                           "end_of_support_on": str(date.today() + timedelta(days=540))})
    note("windows-x86_64 removed from 1.0.0's claims (no verification evidence exists)")
    api.post("qe", f"/releases/{relid}/platform-verifications", {
        "platform": "macos-arm64", "result": "passed",
        "evidence": "SIMULATED manual QA record for the demo: installation test suite run on macOS 15 (arm64), log QA-2026-118"})
    api.post("qe", f"/releases/{relid}/reviews", {"check_key": "support", "result": "passed",
                                                  "evidence": "Support owner briefed; macros and known-issue page prepared"})
    api.post("qe", f"/releases/{relid}/reviews", {"check_key": "accessibility", "result": "failed",
                                                  "evidence": "CLI output passes (plain text/JSON). HTML docs code blocks: "
                                                              "comment colour contrast 3.9:1, below WCAG AA."})
    exc = api.post("rm", f"/releases/{relid}/exceptions", {
        "check_key": "accessibility", "owner_id": users["devi"]["id"],
        "reason": "Low-contrast comment colour in HTML documentation code blocks; application output is unaffected. "
                  "Fix scheduled for 1.0.1.", "scope": "1.0.0 HTML documentation only",
        "expires_on": str(date.today() + timedelta(days=60))})
    expect(bool(exc["id"]), f"documented exception #{exc['id']}: owner Devi Laurent, expires {exc['expires_on']}")
    docs_ = api.post("docs", f"/releases/{relid}/documents/generate", {})
    expect(len(docs_) == 11, "11 documents generated from versioned templates for this release")
    flagged = [d for d in docs_ if d["flags"]]
    note(f"documents with flags: {[(d['kind'], [f['text'] for f in d['flags']]) for d in flagged] or 'none'}")
    qs = next(d for d in docs_ if d["kind"] == "quick-start")
    job = api.post("docs", f"/documents/{qs['id']}/check-examples")
    api.wait_job(job["job_id"])
    qs = api.get("docs", f"/documents/{qs['id']}")
    expect(qs["example_results"] and all(x["result"] == "passed" for x in qs["example_results"]),
           f"quick-start: {len(qs['example_results'])} executable example(s) ran against the built application and passed")
    for d in api.get("docs", f"/releases/{relid}/documents"):
        for i, f in enumerate(d["flags"] or []):
            if not f.get("resolved"):
                api.post("docs", f"/documents/{d['id']}/flags/{i}/resolve", {"note": "Checked against release record"})
        api.post("docs", f"/documents/{d['id']}/submit")
        api.post("docs", f"/documents/{d['id']}/approve")
    expect(True, "documentation editor approved all documents")

    step(8, "Freeze the candidate: application and source packages, digital and boxed editions")
    cand = api.post("rm", f"/releases/{relid}/candidate")
    note(f"manifest sha256 {cand['manifest_sha256']}")
    for e in cand["editions"]:
        m = e["manifest"]
        note(f"edition {e['edition']:<8} {m['package']['filename']:<36} includes {[f['path'] for f in m['includes']]}")
    tmpl = {t["kind"]: t for t in api.get("pm", "/packaging-templates")}["dvd-style-box"]
    mock = api.post("cat", f"/releases/{relid}/editions/{ed_boxed['id']}/artwork", {"template_id": tmpl["id"], "purpose": "mockup"})
    expect(mock["status"] == "valid", f"boxed mockup rendered ({mock['validation']['with_bleed_mm']} mm incl. bleed); "
                                      f"warnings: {mock['validation']['warnings']}")
    printa = api.post("cat", f"/releases/{relid}/editions/{ed_boxed['id']}/artwork", {"template_id": tmpl["id"], "purpose": "print"})
    expect(printa["status"] == "invalid", f"print-ready export refused: {printa['validation']['errors'][0][:90]}…")

    step(9, "Review release evidence")
    api.post("rm", f"/releases/{relid}/validation")
    ready = api.get("rm", f"/releases/{relid}/readiness")
    for c in ready["checks"]:
        note(f"{c['status']:<9} {c['title']}: {c['summary'][:95]}")
    expect(ready["ready"], "all checks passed or carry a documented exception")

    step(10, "Approve the immutable release")
    integ = api.get("rm", f"/releases/{relid}/integrity")
    expect(all(a["ok"] for a in integ["artifacts"]), f"{len(integ['artifacts'])} frozen artefacts re-verified against object storage")
    self_approve = api.call("dev", "POST", f"/releases/{relid}/approve", ok=(403,), json={})
    expect(True, "the developer who created the release cannot approve it")
    appr = api.post("rm", f"/releases/{relid}/approve", {"comment": "Evidence reviewed; exception noted for HTML docs."})
    expect(appr["status"] == "approved", f"release 1.0.0 approved by {appr['approved_by_name']}")
    immut = api.call("rm", "PATCH", f"/releases/{relid}", ok=(409,), json={"notes": "edit after approval"})
    expect(True, "editing the approved release is refused (409)")

    # ------------------------------------------------------------------ 11
    step(11, "Publish through the mock storefront (with injected failures and a retried job)")
    shop.post("/_reset")
    listings = {}
    for ed in (ed_digital, ed_source, ed_boxed):
        prev = api.post("cat", f"/editions/{ed['id']}/listing/prepare", {"release_id": relid})
        listings[ed["code"]] = prev["listing_id"]
        note(f"{ed['code']:<8} preview: {len(prev['changes'])} field change(s), e.g. "
             + ", ".join(f"{c['field']}" for c in prev["changes"][:3]))
    unapproved = api.call("cat", "POST", f"/listings/{listings['digital']}/publish", ok=(409,))
    expect(True, "publishing before public-listing approval is refused")
    rm_listing = api.call("rm", "POST", f"/listings/{listings['digital']}/approve", ok=(403,), json={})
    expect(True, "the release manager cannot approve the public listing (separate approval)")
    for code, lid in listings.items():
        api.post("cat", f"/listings/{lid}/approve", {"comment": "Copy, price and artwork checked"})
    shop.post("/_faults", json={"op": "edition", "when": "before", "count": 1})
    shop.post("/_faults", json={"op": "pointer", "when": "after", "count": 1})
    note("injected: edition upsert fails once before committing; pointer update commits but its response is lost once")
    pubs = {}
    for code, lid in listings.items():
        pubs[code] = api.post("cat", f"/listings/{lid}/publish")
    again = api.post("cat", f"/listings/{listings['digital']}/publish")
    expect(again["id"] == pubs["digital"]["id"], "a repeated publish request returns the same publication job")
    for code, pj in pubs.items():
        done = api.wait_publication(pj["id"])
        expect(done["status"] == "succeeded", f"{code}: published after {done['attempts']} attempt(s); "
                                              f"steps {list(done['steps'])}")
    attempts = {code: api.get("cat", f"/publication-jobs/{pj['id']}")["attempts"] for code, pj in pubs.items()}
    expect(sum(attempts.values()) > len(attempts), f"injected failures were retried by the durable job: {attempts}")
    state = shop.get("/_state").json()
    expect(len(state["products"]) == 1 and len(state["editions"]) == 3 and len(state["releases"]) == 3,
           f"storefront has 1 product, 3 editions, 3 releases — no duplicates after retries")
    rel_now = api.get("rm", f"/releases/{relid}")
    expect(rel_now["status"] == "published", "release 1.0.0 is published")
    stored = {r["package_sha256"] for r in state["releases"].values()}
    frozen = {e["manifest"]["package"]["sha256"] for e in rel_now["editions"]}
    expect(stored == frozen, "storefront holds exactly the approved package checksums (nothing rebuilt)")

    # ------------------------------------------------------------------ 12
    step(12, "Simulated purchase and entitled download")
    ada = shop.post("/v1/customers", json={"email": "ada@example.net", "name": "Ada Lovelace"}).json()
    hdr = {"X-Customer-Token": ada["customer_token"]}
    eid_digital = next(e["id"] for e in state["editions"].values() if e["code"] == "digital")
    eid_source = next(e["id"] for e in state["editions"].values() if e["code"] == "source")
    eid_boxed = next(e["id"] for e in state["editions"].values() if e["code"] == "boxed")
    order = shop.post("/v1/orders", json={"edition_id": eid_digital}, headers={**hdr, "Idempotency-Key": "demo-order-1"}).json()
    dup = shop.post("/v1/orders", json={"edition_id": eid_digital}, headers={**hdr, "Idempotency-Key": "demo-order-1"}).json()
    expect(order["order_id"] == dup["order_id"], f"order {order['order_id']} (simulated payment); retry did not double-charge")
    dl = shop.get(f"/v1/library/download/{eid_digital}/1.0.0", headers=hdr)
    digital_pkg = next(e for e in rel_now["editions"] if e["edition"] == "digital")["manifest"]["package"]["sha256"]
    expect(dl.status_code == 200 and hashlib.sha256(dl.content).hexdigest() == digital_pkg,
           f"downloaded {len(dl.content)} bytes; sha256 matches the approved release manifest")
    denied = shop.get(f"/v1/library/download/{eid_source}/1.0.0", headers=hdr)
    expect(denied.status_code == 403, "the digital purchaser is not entitled to the Source Code Edition")
    keys = shop.post(f"/v1/editions/{eid_boxed}/keys", json={"count": 2},
                     headers={"Authorization": "Bearer " + os.environ.get("FOUNDRY_STOREFRONT_TOKEN", "storefront-dev-token")}).json()["keys"]
    bob = shop.post("/v1/customers", json={"email": "bob@example.net", "name": "Bob Byte"}).json()
    hdr_b = {"X-Customer-Token": bob["customer_token"]}
    shop.post("/v1/library/redeem", json={"key": keys[0]}, headers=hdr_b).raise_for_status()
    expect(shop.get(f"/v1/library/download/{eid_boxed}/1.0.0", headers=hdr_b).status_code == 200,
           f"boxed-edition key {keys[0]} redeemed; download entitled")

    # ------------------------------------------------------------------ 13
    step(13, "Customer report, bug fix release 1.0.1, and catalogue update")
    shop.post("/v1/support/tickets", headers=hdr, json={
        "edition_id": eid_digital, "version": "1.0.0", "severity": "high",
        "subject": "Validation fails on files exported from Excel",
        "body": "My file /home/ada/exports/orders.csv says column 'name' missing although it is there. "
                "Contact me at ada@example.net or +44 20 7946 0958. It starts with a byte order mark I think."})
    api.wait_job(api.post("support", "/support/import")["job_id"])
    issue = api.get("dev", "/support/issues")[0]
    expect("ada@example.net" not in json.dumps(issue) and "/home/ada" not in issue["reproduction_steps"],
           f"ticket imported as {issue['external_ref']}; redacted: {issue['redactions']}")
    private = api.call("dev", "GET", f"/support/issues/{issue['id']}/contact", ok=(403,))
    expect(True, "developers cannot read the customer's contact details")
    api.patch("qe", f"/support/issues/{issue['id']}", {"severity_reviewed": "medium", "owner_id": users["dana"]["id"],
                                                        "status": "in-progress"})
    edit(repo, "src/csv_workshop/reader.py", 'def read_table(path, delimiter=None, encoding="utf-8"):',
         'def read_table(path, delimiter=None, encoding="utf-8-sig"):')
    edit(repo, "src/csv_workshop/__init__.py", '__version__ = "1.0.0"', '__version__ = "1.0.1"')
    edit(repo, "tests/test_validate.py", "\n    def test_semicolon_delimiter_detected(self):",
         BOM_TEST + "\n    def test_semicolon_delimiter_detected(self):")
    c4 = commit(repo, "Ignore a UTF-8 byte order mark at the start of a file")
    b4 = api.wait_build(api.post("dev", f"/repositories/{rid}/builds", {"ref": "main"})["id"])
    expect(b4["status"] == "passed", f"build #{b4['number']} at {c4[:12]} passed")
    rq = {x["key"]: x for x in api.get("pm", f"/projects/{pid}/requirements")}
    for key in ("REQ-004", "REQ-009"):
        api.post("qe", f"/requirements/{rq[key]['id']}/evidence", {"kind": "manual", "result": "passed",
                                                                  "reference": "QA-2026-131 install matrix 1.0.1"})
    rel2 = api.post("dev", f"/products/{prid}/releases", {"version": "1.0.1", "build_id": b4["id"],
                                                          "notes": "Bug-fix release."})
    r2 = rel2["id"]
    api.patch("rm", f"/releases/{r2}", {"platform_claims": ["linux-x86_64", "macos-arm64"],
                                        "end_of_support_on": str(date.today() + timedelta(days=720)),
                                        "compatibility": {"replaces": "1.0.0", "data_format": "unchanged",
                                                          "minimum_python": "3.10"}})
    api.patch("support", f"/support/issues/{issue['id']}", {"fix_release_id": r2, "status": "fixed",
                                                             "customer_note": "Files that begin with a UTF-8 byte "
                                                                              "order mark are now read correctly."})
    api.post("qe", f"/releases/{r2}/platform-verifications", {"platform": "macos-arm64", "result": "passed",
                                                              "evidence": "SIMULATED manual QA record: QA-2026-131 on macOS 15"})
    for key, ev in (("support", "Support notes updated for the BOM fix"),
                    ("accessibility", "HTML documentation re-checked: code comment contrast now 7.1:1")):
        api.post("qe", f"/releases/{r2}/reviews", {"check_key": key, "result": "passed", "evidence": ev})
    for d in api.post("docs", f"/releases/{r2}/documents/generate", {}):
        if "```console-test" in api.get("docs", f"/documents/{d['id']}")["body"]:
            api.wait_job(api.post("docs", f"/documents/{d['id']}/check-examples")["job_id"])
        api.post("docs", f"/documents/{d['id']}/submit")
        api.post("docs", f"/documents/{d['id']}/approve")
    notes_doc = next(d for d in api.get("docs", f"/releases/{r2}/documents") if d["kind"] == "release-notes")
    body = api.get("docs", f"/documents/{notes_doc['id']}")["body"]
    expect("byte order mark" in body, "release notes include the customer-facing fix note and the change summary")
    api.post("rm", f"/releases/{r2}/candidate")
    api.post("cat", f"/releases/{r2}/editions/{ed_boxed['id']}/artwork", {"template_id": tmpl["id"], "purpose": "mockup"})
    api.post("rm", f"/releases/{r2}/validation")
    api.post("rm", f"/releases/{r2}/approve", {"comment": "Bug-fix release"})
    for code, lid in listings.items():
        prev = api.post("cat", f"/editions/{ {'digital': ed_digital, 'source': ed_source, 'boxed': ed_boxed}[code]['id'] }/listing/prepare",
                        {"release_id": r2})
        changed = [c["field"] for c in prev["changes"]]
        note(f"{code:<8} field changes: {', '.join(changed[:6])}{'…' if len(changed) > 6 else ''}")
        api.post("cat", f"/listings/{lid}/approve", {"comment": "1.0.1 listing reviewed"})
        done = api.wait_publication(api.post("cat", f"/listings/{lid}/publish")["id"])
        expect(done["status"] == "succeeded", f"{code} now points at 1.0.1")
    rel1 = api.get("rm", f"/releases/{relid}")
    expect(rel1["status"] == "superseded", "1.0.0 is superseded by 1.0.1")
    lib = shop.get("/v1/library", headers=hdr).json()
    vers = {(r["version"], r["downloadable"]) for e in lib["entitlements"] for r in e["releases"]}
    expect(("1.0.1", True) in vers, "Ada's digital entitlement includes the 1.0.1 update")
    api.wait_job(api.post("support", "/entitlements/sync")["job_id"])
    ents = api.get("support", "/entitlements")
    for e in ents:
        note(f"entitlement {e['external_id']} {e['edition_code']}: eligible {e['eligible_versions']}")
    expect(all("1.0.1" in e["eligible_versions"] for e in ents), "Foundry's entitlement mapping agrees with the storefront")

    rb = api.post("cat", f"/listings/{listings['boxed']}/rollback", {"reason": "Box insert proof shows 1.0.1 artwork "
                                                                                "awaiting print sign-off"})
    api.wait_job(rb["job_id"])
    expect(shop.get("/_state").json()["pointers"][eid_boxed] == "1.0.0",
           "boxed listing pointer rolled back to 1.0.0")
    note(rb["notice"])
    fwd = api.post("cat", f"/listings/{listings['boxed']}/rollback", {"reason": "Print sign-off received",
                                                                       "target_release_id": r2})
    api.wait_job(fwd["job_id"])
    expect(shop.get("/_state").json()["pointers"][eid_boxed] == "1.0.1", "boxed listing pointer restored to 1.0.1")

    wd = api.post("rm", f"/releases/{relid}/withdraw", {"reason": "1.0.0 misreads files that start with a byte order "
                                                                   "mark. Please download 1.0.1."})
    for j in wd["sync_jobs"]:
        api.wait_job(j)
    lib = shop.get("/v1/library", headers=hdr).json()
    v100 = [r for e in lib["entitlements"] for r in e["releases"] if r["version"] == "1.0.0"]
    expect(v100 and not v100[0]["downloadable"] and lib["notifications"],
           f"1.0.0 withdrawn: no longer downloadable; Ada notified ({lib['notifications'][0]['title']})")
    note(wd["advisory"]["body"].splitlines()[-1])

    step("✓", "Audit trail")
    chain = api.get("admin", "/audit/verify")
    expect(chain["valid"], f"audit chain verified across {chain['checked']} events")
    print("\nDemonstration complete.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except DemoFailure as exc:
        print(f"\n\033[31mDEMO FAILED: {exc}\033[0m")
        sys.exit(1)
