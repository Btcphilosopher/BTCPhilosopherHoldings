#!/usr/bin/env bash
# Run Product Foundry directly on a Linux host (no containers) and execute the demonstration.
# Requires: Python 3.11+, git, PostgreSQL reachable at FOUNDRY_DATABASE_URL, Node 20+ for the web UI,
# util-linux (unshare, setpriv). Run as root for the uid-dropping local sandbox, or set FOUNDRY_SANDBOX=docker.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VAR="${FOUNDRY_VAR:-/var/lib/foundry}"
mkdir -p "$VAR"/{repos,work,objects,storefront}
chmod 755 "$VAR" "$VAR/work"
export FOUNDRY_DATABASE_URL="${FOUNDRY_DATABASE_URL:-postgresql+psycopg://foundry:foundry@localhost:5432/foundry}"
export FOUNDRY_STORAGE_BACKEND="${FOUNDRY_STORAGE_BACKEND:-local}" FOUNDRY_STORAGE_ROOT="$VAR/objects"
export FOUNDRY_REPO_ROOTS="$VAR/repos" FOUNDRY_WORK_ROOT="$VAR/work" FOUNDRY_WHEELHOUSE="$ROOT/wheelhouse"
export FOUNDRY_SANDBOX="${FOUNDRY_SANDBOX:-local}" FOUNDRY_SECRET_KEY="${FOUNDRY_SECRET_KEY:-local-$(hostname)-change-me-0123456789abcdef}"
export FOUNDRY_STOREFRONT_URL=http://127.0.0.1:8100 STOREFRONT_DATA="$VAR/storefront/state.json"
export FOUNDRY_API=http://127.0.0.1:8000 FOUNDRY_STOREFRONT=http://127.0.0.1:8100 DEMO_REPO_ROOT="$VAR/repos"

cd "$ROOT/backend"
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate
pip install -q -r requirements-dev.txt
alembic upgrade head
python -m foundry.seed
uvicorn foundry.main:app --port 8000 > "$VAR/api.log" 2>&1 &
(cd "$ROOT/storefront_mock" && uvicorn app:app --port 8100 > "$VAR/storefront.log" 2>&1 &)
python -m foundry.worker > "$VAR/worker.log" 2>&1 &
trap 'kill $(jobs -p) 2>/dev/null || true' EXIT
sleep 3
python "$ROOT/scripts/demo.py"
if command -v npm >/dev/null; then
  (cd "$ROOT/web" && npm ci --no-audit --no-fund && npm run build && FOUNDRY_API_INTERNAL_URL=http://127.0.0.1:8000 npx next start -p 3000) &
  echo "Web interface: http://localhost:3000  (password for every demo user: foundry-demo)"
fi
echo "API docs: http://localhost:8000/api/docs  — press Ctrl+C to stop"
wait
