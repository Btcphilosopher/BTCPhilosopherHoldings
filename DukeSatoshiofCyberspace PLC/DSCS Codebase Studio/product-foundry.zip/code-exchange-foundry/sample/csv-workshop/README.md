# CSV Workshop

A small command-line utility that validates and summarises CSV files.

    python3 csv-workshop.pyz validate data.csv
    python3 csv-workshop.pyz validate data.csv --schema schema.json
    python3 csv-workshop.pyz summarise data.csv --format json

CSV Workshop is the sample product used by The Code Exchange Product Foundry demonstration.
