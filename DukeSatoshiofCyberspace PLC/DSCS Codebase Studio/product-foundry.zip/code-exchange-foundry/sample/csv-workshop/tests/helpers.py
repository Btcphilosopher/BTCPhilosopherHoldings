import os
import tempfile


def write_csv(text, suffix=".csv"):
    handle = tempfile.NamedTemporaryFile("w", suffix=suffix, delete=False, encoding="utf-8", newline="")
    handle.write(text)
    handle.close()
    return handle.name


def cleanup(path):
    if os.path.exists(path):
        os.unlink(path)
