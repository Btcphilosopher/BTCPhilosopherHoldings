import time
import unittest

from csv_workshop.summary import infer_type, summarise
from helpers import cleanup, write_csv


class SummaryTests(unittest.TestCase):
    def test_types_and_counts(self):
        """Requirement: REQ-002"""
        path = write_csv("name,score,when\nAda,3,2024-01-01\nGrace,,2024-02-01\nLin,5.5,2024-03-01\n")
        try:
            cols = {c["name"]: c for c in summarise(path)["columns"]}
            self.assertEqual(cols["name"]["type"], "string")
            self.assertEqual(cols["score"]["type"], "number")
            self.assertEqual(cols["score"]["missing"], 1)
            self.assertEqual(cols["when"]["type"], "date")
            self.assertEqual(cols["score"]["min"], 3.0)
            self.assertEqual(cols["score"]["max"], 5.5)
            self.assertAlmostEqual(cols["score"]["mean"], 4.25)
        finally:
            cleanup(path)

    def test_infer_type_empty(self):
        """Requirement: REQ-002"""
        self.assertEqual(infer_type(["", " "]), "empty")
        self.assertEqual(infer_type(["1", "2"]), "integer")

    def test_performance_100k_rows(self):
        """Requirement: REQ-005"""
        lines = ["id,value,label"] + [f"{i},{i * 0.5},row{i % 97}" for i in range(100_000)]
        path = write_csv("\n".join(lines) + "\n")
        try:
            start = time.perf_counter()
            result = summarise(path)
            elapsed = time.perf_counter() - start
            self.assertEqual(result["rows"], 100_000)
            self.assertLess(elapsed, 5.0, f"summarise took {elapsed:.2f}s")
        finally:
            cleanup(path)


if __name__ == "__main__":
    unittest.main()
