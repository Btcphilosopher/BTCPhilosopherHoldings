import json
import os
import unittest

from csv_workshop.validate import validate
from helpers import cleanup, write_csv


class ValidateTests(unittest.TestCase):
    def test_valid_file_has_no_issues(self):
        """Requirement: REQ-001"""
        path = write_csv("name,age\nAda,36\nGrace,45\n")
        try:
            report = validate(path)
            self.assertTrue(report.ok)
            self.assertEqual(report.rows, 2)
        finally:
            cleanup(path)

    def test_field_count_reported_with_row_number(self):
        """Requirement: REQ-001"""
        path = write_csv("a,b,c\n1,2,3\n4,5\n")
        try:
            report = validate(path, delimiter=",")
            self.assertEqual([(i.row, i.code) for i in report.issues], [(3, "field-count")])
        finally:
            cleanup(path)

    def test_duplicate_and_empty_headers(self):
        """Requirement: REQ-001"""
        path = write_csv("id,,id\n1,2,3\n")
        try:
            codes = sorted(i.code for i in validate(path, delimiter=",").issues)
            self.assertEqual(codes, ["duplicate-header", "empty-header"])
        finally:
            cleanup(path)

    def test_schema_types_and_required_columns(self):
        """Requirement: REQ-003"""
        path = write_csv("id,joined\n1,2024-01-02\nx,yesterday\n")
        schema_path = write_csv(json.dumps({"columns": [
            {"name": "id", "type": "integer"}, {"name": "joined", "type": "date"},
            {"name": "email", "type": "string", "required": True}]}), suffix=".json")
        try:
            from csv_workshop.validate import load_schema
            report = validate(path, schema=load_schema(schema_path))
            codes = sorted(i.code for i in report.issues)
            self.assertEqual(codes, ["missing-column", "type", "type"])
        finally:
            cleanup(path)
            cleanup(schema_path)

    def test_semicolon_delimiter_detected(self):
        """Requirement: REQ-001"""
        path = write_csv("a;b\n1;2\n3;4\n")
        try:
            report = validate(path)
            self.assertTrue(report.ok)
            self.assertEqual(report.columns, 2)
        finally:
            cleanup(path)


if __name__ == "__main__":
    unittest.main()
