import io
import json
import unittest

from csv_workshop.cli import main
from helpers import cleanup, write_csv


class CliTests(unittest.TestCase):
    def run_cli(self, *argv):
        out = io.StringIO()
        code = main(list(argv), out=out)
        return code, out.getvalue()

    def test_json_summary_has_stable_keys(self):
        """Requirement: REQ-008"""
        path = write_csv("a,b\n1,x\n2,y\n")
        try:
            code, text = self.run_cli("summarise", path, "--format", "json")
            self.assertEqual(code, 0)
            data = json.loads(text)
            self.assertEqual(sorted(data), ["columns", "path", "rows"])
            expected = ["name", "type", "non_empty", "missing", "unique", "top", "min", "max", "mean"]
            self.assertEqual(sorted(data["columns"][0]), sorted(expected))
        finally:
            cleanup(path)

    def test_output_is_plain_text_without_escape_codes(self):
        """Requirement: REQ-006"""
        path = write_csv("a,b\n1,2\n3\n")
        try:
            code, text = self.run_cli("validate", path)
            self.assertEqual(code, 1)
            self.assertNotIn("\x1b[", text)
            self.assertIn("row 3", text)
            code, text = self.run_cli("summarise", path)
            self.assertNotIn("\x1b[", text)
        finally:
            cleanup(path)

    def test_exit_codes(self):
        """Requirement: REQ-001"""
        path = write_csv("a\n1\n")
        try:
            self.assertEqual(self.run_cli("validate", path)[0], 0)
            self.assertEqual(self.run_cli("validate", path + ".missing")[0], 2)
        finally:
            cleanup(path)


if __name__ == "__main__":
    unittest.main()
