`csv-workshop validate FILE [--schema SCHEMA] [--delimiter D] [--format text|json]`
: Checks the header row, field counts and, with `--schema`, required columns and value types
  (`string`, `integer`, `number`, `date` as YYYY-MM-DD). Exit code 0 when no issues are found, 1 when
  issues are reported, 2 when the command cannot run.

`csv-workshop summarise FILE [--delimiter D] [--format table|json]`
: Describes each column: inferred type, number of values, missing values, distinct values and, for
  numeric columns, minimum, maximum and mean. `summarize` is accepted as an alias.

`csv-workshop --version`
: Prints the installed version.

Output is plain text or JSON and never relies on colour.
