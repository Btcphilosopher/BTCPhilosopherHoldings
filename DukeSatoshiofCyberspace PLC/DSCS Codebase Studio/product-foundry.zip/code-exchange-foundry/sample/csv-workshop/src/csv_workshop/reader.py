"""Reading CSV files with delimiter detection."""
import csv

CANDIDATE_DELIMITERS = ",;\t|"


class CsvReadError(Exception):
    pass


def read_table(path, delimiter=None, encoding="utf-8"):
    """Return (headers, rows) where rows are lists of strings."""
    try:
        with open(path, newline="", encoding=encoding) as handle:
            text = handle.read()
    except FileNotFoundError:
        raise CsvReadError(f"file not found: {path}")
    except UnicodeDecodeError as exc:
        raise CsvReadError(f"file is not valid {encoding}: {exc.reason} at byte {exc.start}")
    if not text.strip():
        return [], []
    if delimiter is None:
        try:
            delimiter = csv.Sniffer().sniff(text[:8192], delimiters=CANDIDATE_DELIMITERS).delimiter
        except csv.Error:
            delimiter = ","
    rows = list(csv.reader(text.splitlines(), delimiter=delimiter))
    return rows[0], rows[1:]
