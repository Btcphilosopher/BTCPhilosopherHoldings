import sys

from csv_workshop.cli import main

sys.exit(main())
