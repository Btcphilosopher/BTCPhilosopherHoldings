"""Column summaries."""
from collections import Counter

from csv_workshop.reader import read_table
from csv_workshop.validate import value_matches


def infer_type(values):
    present = [v for v in values if v.strip()]
    if not present:
        return "empty"
    for kind in ("integer", "number", "date"):
        if all(value_matches(v.strip(), kind) for v in present):
            return kind
    return "string"


def summarise(path, delimiter=None):
    headers, rows = read_table(path, delimiter=delimiter)
    columns = []
    for index, name in enumerate(headers):
        values = [row[index] if index < len(row) else "" for row in rows]
        present = [v.strip() for v in values if v.strip()]
        kind = infer_type(values)
        col = {
            "name": name,
            "type": kind,
            "non_empty": len(present),
            "missing": len(values) - len(present),
            "unique": len(set(present)),
            "top": Counter(present).most_common(3),
        }
        if kind in ("integer", "number"):
            numbers = [float(v) for v in present]
            col["min"] = min(numbers)
            col["max"] = max(numbers)
            col["mean"] = round(sum(numbers) / len(numbers), 6)
        columns.append(col)
    return {"path": str(path), "rows": len(rows), "columns": columns}
