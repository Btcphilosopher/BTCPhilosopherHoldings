"""Structural and schema validation."""
import json
import re
from dataclasses import asdict, dataclass, field

from csv_workshop.reader import read_table

DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
TYPES = ("string", "integer", "number", "date")


@dataclass
class Issue:
    row: int
    column: str
    code: str
    message: str


@dataclass
class ValidationReport:
    path: str
    rows: int = 0
    columns: int = 0
    issues: list = field(default_factory=list)

    @property
    def ok(self):
        return not self.issues

    def as_dict(self):
        data = asdict(self)
        data["ok"] = self.ok
        return data


def value_matches(value, kind):
    if kind == "string":
        return True
    if kind == "integer":
        return re.fullmatch(r"[+-]?\d+", value) is not None
    if kind == "number":
        try:
            float(value)
            return True
        except ValueError:
            return False
    if kind == "date":
        return DATE_RE.match(value) is not None
    raise ValueError(f"unknown type {kind}")


def load_schema(path):
    with open(path, encoding="utf-8") as handle:
        schema = json.load(handle)
    for col in schema.get("columns", []):
        if col.get("type", "string") not in TYPES:
            raise ValueError(f"schema column {col.get('name')}: type must be one of {TYPES}")
    return schema


def validate(path, schema=None, delimiter=None):
    headers, rows = read_table(path, delimiter=delimiter)
    report = ValidationReport(path=str(path), rows=len(rows), columns=len(headers))
    if not headers:
        report.issues.append(Issue(0, "", "empty-file", "the file contains no header row"))
        return report
    seen = set()
    for index, name in enumerate(headers, start=1):
        if not name.strip():
            report.issues.append(Issue(1, f"#{index}", "empty-header", f"column {index} has no name"))
        elif name in seen:
            report.issues.append(Issue(1, name, "duplicate-header", f"column name '{name}' is repeated"))
        seen.add(name)
    for number, row in enumerate(rows, start=2):
        if len(row) != len(headers):
            report.issues.append(Issue(number, "", "field-count",
                                       f"expected {len(headers)} fields, found {len(row)}"))
    if schema:
        _check_schema(report, headers, rows, schema)
    return report


def _check_schema(report, headers, rows, schema):
    positions = {name: i for i, name in enumerate(headers)}
    for col in schema.get("columns", []):
        name = col["name"]
        if name not in positions:
            if col.get("required", True):
                report.issues.append(Issue(1, name, "missing-column", f"required column '{name}' is absent"))
            continue
        pos = positions[name]
        kind = col.get("type", "string")
        for number, row in enumerate(rows, start=2):
            if pos >= len(row):
                continue
            value = row[pos].strip()
            if not value:
                if not col.get("nullable", True):
                    report.issues.append(Issue(number, name, "null", f"'{name}' must not be empty"))
                continue
            if not value_matches(value, kind):
                report.issues.append(Issue(number, name, "type",
                                           f"'{value}' is not a valid {kind}"))
