"""CSV Workshop: validate and summarise CSV files from the command line."""

__version__ = "1.0.0"
