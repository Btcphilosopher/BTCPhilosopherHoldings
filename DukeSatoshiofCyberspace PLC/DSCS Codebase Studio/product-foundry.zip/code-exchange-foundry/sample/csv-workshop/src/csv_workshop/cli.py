"""Command-line interface. Output is plain text or JSON; no colour is used."""
import argparse
import json
import sys

from csv_workshop import __version__
from csv_workshop.reader import CsvReadError
from csv_workshop.summary import summarise
from csv_workshop.validate import load_schema, validate


def build_parser():
    parser = argparse.ArgumentParser(prog="csv-workshop",
                                     description="Validate and summarise CSV files.")
    parser.add_argument("--version", action="version", version=f"csv-workshop {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)
    val = sub.add_parser("validate", help="check structure and, optionally, a JSON schema")
    val.add_argument("file")
    val.add_argument("--schema", help="JSON schema describing expected columns")
    val.add_argument("--delimiter", help="field delimiter (detected when omitted)")
    val.add_argument("--format", choices=("text", "json"), default="text")
    summ = sub.add_parser("summarise", aliases=["summarize"], help="describe each column")
    summ.add_argument("file")
    summ.add_argument("--delimiter")
    summ.add_argument("--format", choices=("table", "json"), default="table")
    return parser


def _print_validation(report, fmt, out):
    if fmt == "json":
        print(json.dumps(report.as_dict(), indent=2), file=out)
        return
    if report.ok:
        print(f"OK: {report.path}: {report.rows} rows, {report.columns} columns, no issues found.", file=out)
        return
    print(f"FAILED: {report.path}: {len(report.issues)} issue(s)", file=out)
    for issue in report.issues:
        where = f"row {issue.row}" + (f", column {issue.column}" if issue.column else "")
        print(f"  {where}: {issue.message} ({issue.code})", file=out)


def _print_summary(summary, fmt, out):
    if fmt == "json":
        print(json.dumps(summary, indent=2), file=out)
        return
    from tabulate import tabulate
    table = []
    for col in summary["columns"]:
        table.append([col["name"], col["type"], col["non_empty"], col["missing"], col["unique"],
                      col.get("min", ""), col.get("max", ""), col.get("mean", "")])
    print(f"{summary['path']}: {summary['rows']} rows", file=out)
    print(tabulate(table, headers=["column", "type", "values", "missing", "unique", "min", "max", "mean"]),
          file=out)


def main(argv=None, out=None):
    out = out or sys.stdout
    args = build_parser().parse_args(argv)
    try:
        if args.command == "validate":
            schema = load_schema(args.schema) if args.schema else None
            report = validate(args.file, schema=schema, delimiter=args.delimiter)
            _print_validation(report, args.format, out)
            return 0 if report.ok else 1
        summary = summarise(args.file, delimiter=args.delimiter)
        _print_summary(summary, args.format, out)
        return 0
    except (CsvReadError, ValueError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
