"""Compile sources and record build information."""
import compileall
import json
import os
import sys

sys.path.insert(0, "src")
from csv_workshop import __version__  # noqa: E402

if not compileall.compile_dir("src", quiet=1, legacy=False, force=True):
    sys.exit(1)
os.makedirs("build", exist_ok=True)
info = {"name": "csv-workshop", "version": __version__, "commit": os.environ.get("FOUNDRY_COMMIT", "unknown"),
        "python": sys.version.split()[0]}
with open("build/BUILDINFO.json", "w", encoding="utf-8") as handle:
    json.dump(info, handle, indent=2)
print(json.dumps(info))
