"""Produce deterministic release packages.

dist/csv-workshop-<v>.pyz              single-file application (with tabulate and notices)
dist/csv-workshop-<v>-src.tar.gz       source-code archive
dist/csv-workshop-<v>-starter-kit.zip  developer starter kit (examples, schema templates, build guide)
"""
import io
import os
import sys
import tarfile
import zipfile
from pathlib import Path

sys.path.insert(0, "src")
from csv_workshop import __version__  # noqa: E402

EPOCH = (2023, 11, 14, 22, 13, 20)
DIST = Path("dist")
SOURCE_PATHS = ["src", "tests", "tools", "examples", "assets", "README.md", "BUILDING.md", "pyproject.toml",
                "requirements.lock", ".foundry/pipeline.toml"]


def files_under(paths):
    out = []
    for item in paths:
        p = Path(item)
        if p.is_file():
            out.append(p)
        elif p.is_dir():
            out += [f for f in sorted(p.rglob("*")) if f.is_file() and "__pycache__" not in f.parts]
    return out


def add(zf, arcname, data):
    info = zipfile.ZipInfo(arcname, EPOCH)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o644 << 16
    zf.writestr(info, data)


def build_pyz(target):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        add(zf, "__main__.py", b"import sys\nfrom csv_workshop.cli import main\nsys.exit(main())\n")
        for f in files_under(["src/csv_workshop"]):
            add(zf, str(f.relative_to("src")), f.read_bytes())
        for f in files_under([".deps/tabulate"]):
            add(zf, str(f.relative_to(".deps")), f.read_bytes())
        notices = Path("build/THIRD_PARTY_NOTICES.txt")
        if not notices.exists():
            sys.exit("build/THIRD_PARTY_NOTICES.txt missing: the sbom stage must run first")
        add(zf, "THIRD_PARTY_NOTICES.txt", notices.read_bytes())
    target.write_bytes(b"#!/usr/bin/env python3\n" + buf.getvalue())


def build_source(target):
    prefix = f"csv-workshop-{__version__}"
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w", format=tarfile.PAX_FORMAT) as tf:
        for f in files_under(SOURCE_PATHS):
            info = tf.gettarinfo(str(f), arcname=f"{prefix}/{f}")
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            info.mtime = 1700000000
            with open(f, "rb") as handle:
                tf.addfile(info, handle)
    import gzip
    target.write_bytes(gzip.compress(buf.getvalue(), mtime=0))


def build_starter_kit(target):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for f in files_under(["examples", "BUILDING.md"]):
            add(zf, f"starter-kit/{f}", f.read_bytes())
        add(zf, "starter-kit/README.txt", (
            f"CSV Workshop {__version__} developer starter kit\n\n"
            "examples/        sample data and a schema template\n"
            "BUILDING.md      how to build and test from source\n").encode())
    target.write_bytes(buf.getvalue())


def main():
    DIST.mkdir(exist_ok=True)
    pyz = DIST / f"csv-workshop-{__version__}.pyz"
    build_pyz(pyz)
    os.chmod(pyz, 0o755)
    (DIST / "csv-workshop.pyz").write_bytes(pyz.read_bytes())
    build_source(DIST / f"csv-workshop-{__version__}-src.tar.gz")
    build_starter_kit(DIST / f"csv-workshop-{__version__}-starter-kit.zip")
    for f in sorted(DIST.iterdir()):
        print(f"{f}  {f.stat().st_size} bytes")


if __name__ == "__main__":
    main()
