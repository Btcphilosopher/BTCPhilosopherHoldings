"""Formatting and static checks with the standard library only."""
import ast
import sys
from pathlib import Path

MAX_LINE = 110


def check(path):
    problems = []
    text = path.read_text(encoding="utf-8")
    try:
        tree = ast.parse(text, filename=str(path))
    except SyntaxError as exc:
        return [f"{path}:{exc.lineno}: syntax error: {exc.msg}"]
    for number, line in enumerate(text.splitlines(), start=1):
        if len(line) > MAX_LINE:
            problems.append(f"{path}:{number}: line longer than {MAX_LINE} characters")
        if line != line.rstrip():
            problems.append(f"{path}:{number}: trailing whitespace")
        if "\t" in line:
            problems.append(f"{path}:{number}: tab character")
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler) and node.type is None:
            problems.append(f"{path}:{node.lineno}: bare 'except:'")
    return problems


def main(paths):
    files = [p for root in paths for p in sorted(Path(root).rglob("*.py"))]
    problems = [msg for f in files for msg in check(f)]
    for msg in problems:
        print(msg)
    print(f"checked {len(files)} files, {len(problems)} problem(s)")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:] or ["src", "tests", "tools"]))
