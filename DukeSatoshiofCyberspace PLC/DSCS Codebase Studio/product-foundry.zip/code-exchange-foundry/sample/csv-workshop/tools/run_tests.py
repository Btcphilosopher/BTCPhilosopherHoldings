"""Run the unittest suite and write a JUnit XML report with requirement links.

A test declares the requirements it provides evidence for in its docstring:
    \"\"\"Requirement: REQ-001, REQ-003\"\"\"
"""
import argparse
import os
import re
import sys
import time
import unittest
import xml.etree.ElementTree as ET

REQ_RE = re.compile(r"Requirement[s]?:\s*([A-Z]+-\d+(?:\s*,\s*[A-Z]+-\d+)*)")


class RecordingResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.records = []
        self._start = 0.0

    def startTest(self, test):
        self._start = time.perf_counter()
        super().startTest(test)

    def _record(self, test, status, detail=""):
        doc = test._testMethodDoc or ""
        match = REQ_RE.search(doc)
        reqs = [r.strip() for r in match.group(1).split(",")] if match else []
        self.records.append((test, status, detail, time.perf_counter() - self._start, reqs))

    def addSuccess(self, test):
        super().addSuccess(test)
        self._record(test, "passed")

    def addFailure(self, test, err):
        super().addFailure(test, err)
        self._record(test, "failure", self._exc_info_to_string(err, test))

    def addError(self, test, err):
        super().addError(test, err)
        self._record(test, "error", self._exc_info_to_string(err, test))

    def addSkip(self, test, reason):
        super().addSkip(test, reason)
        self._record(test, "skipped", reason)


def write_junit(records, path):
    suite = ET.Element("testsuite", name="csv-workshop", tests=str(len(records)),
                       failures=str(sum(r[1] == "failure" for r in records)),
                       errors=str(sum(r[1] == "error" for r in records)))
    for test, status, detail, elapsed, reqs in records:
        classname = type(test).__module__ + "." + type(test).__name__
        case = ET.SubElement(suite, "testcase", classname=classname, name=test._testMethodName,
                             time=f"{elapsed:.4f}")
        if reqs:
            props = ET.SubElement(case, "properties")
            for req in reqs:
                ET.SubElement(props, "property", name="requirement", value=req)
        if status in ("failure", "error", "skipped"):
            message = detail.strip().splitlines()[-1] if detail.strip() else status
            el = ET.SubElement(case, status, message=message)
            el.text = detail
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    ET.ElementTree(suite).write(path, encoding="utf-8", xml_declaration=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--junit", default="reports/junit.xml")
    parser.add_argument("--start", default="tests")
    args = parser.parse_args()
    sys.path.insert(0, os.path.abspath(args.start))
    suite = unittest.defaultTestLoader.discover(args.start, top_level_dir=args.start)
    runner = unittest.TextTestRunner(verbosity=2, resultclass=RecordingResult, stream=sys.stdout)
    result = runner.run(suite)
    write_junit(result.records, args.junit)
    print(f"JUnit report written to {args.junit}")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
