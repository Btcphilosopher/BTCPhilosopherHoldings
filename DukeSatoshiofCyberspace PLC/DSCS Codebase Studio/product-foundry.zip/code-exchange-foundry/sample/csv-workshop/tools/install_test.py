"""Installation test: run the packaged application from a clean directory with an isolated interpreter.

Writes reports/install-junit.xml so results are recorded as evidence.
"""
import os
import shutil
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET

sys.path.insert(0, "src")
from csv_workshop import __version__  # noqa: E402

PYZ = os.path.abspath(f"dist/csv-workshop-{__version__}.pyz")
SAMPLE = os.path.abspath("examples/sample.csv")
CASES = [
    ("version_reports_release", [PYZ, "--version"], 0, f"csv-workshop {__version__}"),
    ("validate_sample", [PYZ, "validate", SAMPLE], 0, "OK:"),
    ("summarise_sample", [PYZ, "summarise", SAMPLE], 0, "rows"),
]


def main():
    suite = ET.Element("testsuite", name="installation")
    failed = 0
    with tempfile.TemporaryDirectory() as clean:
        target = os.path.join(clean, "csv-workshop.pyz")
        shutil.copy(PYZ, target)  # "installation" is copying the single file
        for name, argv, code, expect in CASES:
            argv = [target if a == PYZ else a for a in argv]
            start = time.perf_counter()
            proc = subprocess.run([sys.executable, "-I", *argv], capture_output=True, text=True, cwd=clean)
            case = ET.SubElement(suite, "testcase", classname="install", name=name,
                                 time=f"{time.perf_counter() - start:.4f}")
            props = ET.SubElement(case, "properties")
            ET.SubElement(props, "property", name="requirement", value="REQ-007")
            ok = proc.returncode == code and expect in proc.stdout
            print(f"{'PASS' if ok else 'FAIL'} {name}: exit {proc.returncode}: {proc.stdout.strip()[:120]}")
            if not ok:
                failed += 1
                el = ET.SubElement(case, "failure", message=f"exit {proc.returncode}")
                el.text = proc.stdout + proc.stderr
    os.makedirs("reports", exist_ok=True)
    ET.ElementTree(suite).write("reports/install-junit.xml", encoding="utf-8", xml_declaration=True)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
