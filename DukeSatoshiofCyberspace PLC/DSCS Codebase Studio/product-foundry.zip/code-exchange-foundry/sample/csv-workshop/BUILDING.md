# Building CSV Workshop from source

Requirements: Python 3.10 or later.

    python3 -m pip install --target .deps -r requirements.lock
    PYTHONPATH=src:.deps python3 tools/lint.py src tests tools
    PYTHONPATH=src:.deps python3 tools/run_tests.py --junit reports/junit.xml
    PYTHONPATH=src:.deps python3 tools/package.py   # needs build/THIRD_PARTY_NOTICES.txt

The packaging step expects `build/THIRD_PARTY_NOTICES.txt`, which Product Foundry generates from the
installed dependencies. When building outside Foundry, create it from the licence files in `.deps`.
