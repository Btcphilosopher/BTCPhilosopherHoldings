# Status: implemented, simulated, integrated and tested

Verified on 2026-11-27 with Python 3.13.18, PostgreSQL 16.4, Docker Engine 29.9, SeaweedFS 4.55, Node 22.23
and Next.js 16.4.6.

## Verification performed

| What | How | Result |
|---|---|---|
| Backend test suite (75 tests) | `pytest` against PostgreSQL 16, local sandbox, Docker sandbox test included | **75 passed** |
| End-to-end demonstration, local sandbox | `scripts/demo.py` against API, worker and storefront processes over HTTP | all 13 steps passed |
| End-to-end demonstration, Docker sandbox and S3 | the same script with `FOUNDRY_SANDBOX=docker` and artefacts in SeaweedFS S3 | all steps passed (transcript in `demo-transcript.txt`) |
| Web interface | `next build` (strict TypeScript); pages exercised in Chromium against the demo data | builds cleanly; no runtime console errors |
| Database migrations | `alembic upgrade head` on an empty PostgreSQL database | creates all 43 tables |
| Docker Compose images | **not built in this environment** (Docker Hub rate limiting, and container builds had no route to package mirrors) | the Compose file and Dockerfiles are standard but unverified as images; their runtime paths (Docker sandbox, S3, PostgreSQL) were exercised directly on the host |

## Implemented and tested

- **Project records.** Idea, customers, problem, claimed platforms, stack, repositories, owner and members,
  requirements with acceptance criteria, tasks, milestones, intended licence and distribution model,
  dependencies, estimated and recorded costs, release history, support owner. Project, product, edition and
  release are separate records.
- **Requirements.** Proposed, implemented, tested and accepted are separate states. Completing tasks changes
  nothing. Only passing evidence (tests linked by requirement key, or manual or document evidence) moves a
  requirement to tested. Acceptance needs a reviewer, and failing evidence withdraws it. *Tested.*
- **Local Git adapter.** Repository roots enforced, ref and path validation, branches, commits, tree, read-only
  file viewer, diffs and change summaries, provenance capture, `git archive` checkout without hooks, protected
  branches for assistant writes, and "Open in editor" through a configurable `vscode://` (or other) URL
  template. *Tested.*
- **Pipelines.** Version-controlled TOML with explicit commands, dependencies (`needs`), network mode, bounded
  retries, lockfiles, JUnit reports and artefact globs. Records commit, pipeline hash, worker environment,
  lockfile hashes, exit codes, logs, test results, artefact checksums, timing and resource use. Failed results
  are preserved, retries create new builds, and builds can be cancelled. *Tested, including cancellation of a
  running stage in both sandboxes.*
- **Isolation.** Docker and local sandboxes as described in SECURITY.md. *Tested:* no network (including to
  the worker's localhost), no worker secrets in the environment, uid 65534, cannot write outside the
  workspace, memory limit, timeout, process-group kill, a read-only root and no Docker socket in containers.
- **Quality evidence.** 11 readiness checks with linked evidence: requirements, tests, installation, platforms,
  known defects, accessibility, dependency and vulnerability findings, documentation, licences, support and
  packaging. Exceptions carry an owner, reason, scope and optional expiry, and can be revoked. *Tested,
  including expired and revoked exceptions.*
- **Scanners.** Built-in dependency audit (local advisory snapshot) and secret scan. Each records tool version,
  database version, timestamp, scope and limitations, and the interface never presents "no findings" as
  "secure". *Tested.*
- **Documentation.** 11 versioned templates (quick start, installation, user guide, administrator guide,
  command/API reference, build instructions, troubleshooting, system requirements, release notes,
  third-party notices, support) and release-bound revisions. Editing creates a new revision. Web preview,
  downloadable HTML and PDF (ReportLab). Flags for unsupported platform mentions and absolute claims;
  executable `console-test` examples run in the sandbox against the built application; a review and approval
  gate. *Tested.*
- **Licensing and provenance.** Contributors and ownership, assets and source origins, CycloneDX 1.6 SBOM built
  from the dependencies actually installed, third-party notices with licence texts, and licence classification
  that routes unknown, copyleft or unpinned items and unknown-licence assets to human review. Commercial
  licence versions state eight rights separately. The backend refuses copyright transfer and refuses source
  access with unlimited redistribution. Approved licence versions are immutable. *Tested.*
- **Editions and packaging.** Digital download, source archive, developer starter kit, boxed download key,
  USB collector and bundle kinds. Deterministic per-edition zip packages with an inner manifest, licence text
  and activation note. Box artwork (front, spine, back, bleed, safe area) in SVG from print templates; mockups
  are separate from print-ready exports, which require an allocated, check-digit-valid GTIN. *Tested:* GTIN
  validation, EAN-13 encoding, print export refused without GTIN.
- **Release management.** Full state machine, candidate freeze with manifest hash, integrity re-verification
  at approval, separation of duties, immutability enforced in the ORM layer, corrections only as new versions,
  supersession, withdrawal with advisory, end-of-support dates. *Tested.*
- **Catalogue publication.** Payload preview with a field-level diff, listing approval separate from release
  approval, idempotent step-recorded jobs, recovery from partial failures (failures before and after commit at
  every step), operator resume of dead jobs, refusal of payloads changed after approval, rollback and roll-forward
  of the catalogue pointer with the "already downloaded copies are unaffected" notice, withdrawal sync with
  customer notification. *Tested.*
- **Customer updates and support.** Ticket import with redaction, private contacts with audited access,
  severity review, owner, fix version, customer-facing note fed into release notes, advisories, entitlement
  import, and eligibility derived from the purchased edition and update policy (major versions, update window,
  patch-only, bundles, refunds, withdrawals). *Tested, including agreement between the Foundry and storefront
  rules.*
- **Roles and audit.** 10 human roles plus the assistant service identity, backend enforcement, administrators
  without approval powers, and a hash-chained audit trail with verification. *Tested, including tamper
  detection.*
- **Assistant (offline provider).** Explain code, propose tasks, draft tests, draft documentation. It works on
  an explicit file scope, records an input manifest of hashes (no contents) and its model configuration, commits
  to an `assistant/run-N` branch with a stored patch and a linked build, and never touches protected branches.
  *Tested.*

## Simulated

- **The storefront** is a local mock (`storefront_mock/`) of the documented `/v1` contract, including checkout,
  customer library, download keys, tickets and notifications. **No payment is taken.** Orders are marked
  `payment: SIMULATED`.
- **macOS verification** in the demonstration is a manually recorded QA entry labelled "SIMULATED". No macOS
  machine was used. Only `linux-x86_64` is verified by the build worker itself.
- **The advisory database** contains a single fictional fixture entry (`FDY-FIXTURE-0001` for a non-existent
  package), so the demo correctly reports no dependency findings.
- **Physical shops** are represented by the storefront's `/v1/retail/catalogue` feed, which lists only
  boxed or USB editions that have an allocated GTIN and print-ready artwork. No shop system is integrated.
- **The offline assistant** is deterministic and rule-based (AST summaries, smoke-test drafts). It cannot write
  real fixes; `suggest-patch` explains that a model provider is needed.

## Integrated but not tested against live services

- **GitHub and GitLab adapters** (`gitadapter.py`): branches, commits, tree, raw file, archive, pull or merge
  requests and issues over the REST APIs. Tokens come from named secrets. They were written from the providers'
  public REST documentation, but the official documentation sites could not be reached from this environment to
  re-verify them, and no live repository was used.
- **The Claude assistant provider** (`FOUNDRY_ASSISTANT_PROVIDER=anthropic`) uses the official `anthropic`
  Python SDK with model `claude-opus-5-5` (configurable), `effort: medium` and server-side refusal fallbacks. It
  was not called; no API key was available, and the `anthropic` package is optional (`requirements-dev.txt`).
- **The S3 adapter** was tested against SeaweedFS only. AWS S3 and other S3-compatible stores should work but
  were not tried.

## Not implemented

- A web IDE. The interface offers a read-only viewer and an "Open in editor" link by design.
- Single sign-on and httpOnly cookie sessions (see SECURITY.md).
- Real payment, tax and invoicing; email delivery of notifications (recorded by the mock storefront only).
- Raster artwork upload and DPI checking. The templates are vector-only, so the 300 dpi minimum is recorded
  but never exercised.
- Multi-platform build workers (macOS, Windows). The pipeline declares a platform, and only Linux workers exist.
- Webhooks from Git hosts (builds are triggered from the interface or API).
