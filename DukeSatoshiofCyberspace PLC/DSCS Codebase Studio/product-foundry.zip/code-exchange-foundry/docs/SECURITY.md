# Security model

## Untrusted build code

Project code, its tests and its build scripts are treated as untrusted.

**Docker sandbox** (`FOUNDRY_SANDBOX=docker`, the default in Compose). Every pipeline stage gets a new container
that is removed afterwards:

- `--network none`. Dependencies come from a vetted wheelhouse copied into the workspace and are hash-pinned by
  the project's lockfile. A stage can request `network = "egress"` only if an operator configures
  `FOUNDRY_SANDBOX_EGRESS_NETWORK`, intended to be a proxy-only network.
- `--read-only` root filesystem and a small `noexec` tmpfs at `/tmp`.
- `--cap-drop ALL`, `--security-opt no-new-privileges`, `--user 65534:65534`.
- `--memory` with matching `--memory-swap` (no swap), `--cpus`, `--pids-limit`, and a wall-clock timeout.
- **No bind mounts.** The workspace is copied in and out with `docker cp`, so no host path, secret or Docker socket
  is visible inside the build.
- The environment is built from an allow-list. Names such as `FOUNDRY_SECRET_*`, `AWS_*`,
  `FOUNDRY_DATABASE*` and `FOUNDRY_S3*` are refused outright.

The worker talks to Docker through `tecnativa/docker-socket-proxy`. It exposes only the container, image and
volume APIs (no exec, networks, swarm or secrets). This limits what a compromised *worker* could ask Docker to
do. The worker is trusted code; builds never receive the proxy address.

**Local sandbox** (`FOUNDRY_SANDBOX=local`, for development and the test suite):

- a new network namespace via `unshare --net` (only a down loopback interface);
- the privilege drop to uid 65534 with `setpriv --no-new-privs` when the worker runs as root;
- `RLIMIT_AS`, `RLIMIT_CPU`, `RLIMIT_FSIZE`, `RLIMIT_NPROC` and no core dumps;
- its own session, killed as a process group on timeout or cancellation;
- a throwaway directory.

It is **not** a filesystem boundary: files that are world-readable on the worker host remain readable. Use Docker
for untrusted code.

Repository hooks never run. Git is invoked with `core.hooksPath=/dev/null`, and builds receive `git archive`
output rather than a working copy.

## Secrets

- The database stores no repository credentials. A repository records `credential_ref` (a name). The token is
  read from `FOUNDRY_SECRET_<NAME>` in the API or worker environment and is never returned by the API.
- The storefront token, database URL, S3 keys and JWT secret are configuration only (`.env`). The assistant
  identity cannot read them, and builds never receive them.

## Authentication and authorisation

- Passwords are hashed with bcrypt. Tokens are HS256 JWTs with an expiry. The user and roles are reloaded from
  the database on every request, so deactivation and role changes take effect immediately.
- Every route declares the permission it needs (`security.PERMISSIONS`) and the API enforces it. The interface
  only hides controls you cannot use.
- **Administrators are not superusers.** They manage users and settings but cannot approve releases, listings,
  documents, requirements or licence decisions.
- **Separation of duties** (`FOUNDRY_REQUIRE_SEPARATE_APPROVER=true`): the person who created a release cannot
  approve it, and the release approver cannot approve that release's public listing.
- The AI assistant acts as a service identity with no permissions. It cannot log in. Its only write path creates
  `assistant/run-N` branches through a Git plumbing call that refuses protected branches.

| Permission group | Roles |
|---|---|
| Projects, costs, editions | product manager |
| Requirements: edit / accept / evidence | product manager, quality engineer / product manager, reviewer / quality engineer, reviewer |
| Repositories: connect | developer, administrator |
| Builds: run / cancel | developer, quality engineer, release manager |
| Documentation: edit / approve / templates | documentation editor, developer / documentation editor / documentation editor |
| Licences: edit, approve, review decisions | licence reviewer |
| Releases: create / transition, approve, withdraw, exceptions | developer, release manager / release manager |
| Catalogue: edit, approve listing / publish, rollback | catalogue editor / catalogue editor, release manager |
| Support: triage / import, private contact | support agent, quality engineer, product manager, developer / support agent |
| Users, settings / audit, jobs | administrator / administrator, release manager |

The authoritative table is served at `GET /api/v1/roles`.

## Audit

Repository connections and disconnections, build queueing, completion and cancellation, requirement acceptance
and regressions, documentation approvals, licence drafts, changes, approvals and review decisions, readiness
exceptions, release transitions and approvals, listing approvals, publication attempts and outcomes,
rollbacks, withdrawals, role changes and every view of private customer contact details are recorded. Each event
stores the SHA-256 of the previous event. `GET /api/v1/audit/verify` detects any altered or removed row. On
PostgreSQL, appends are serialised with an advisory lock.

## Customer data

Support tickets are imported with email addresses, phone numbers, card-like numbers, home-directory paths and
the customer's name redacted from the text. The raw contact sits in `customer_contacts`, readable only with
`support.private`, and each read is audited. Issues carry a pseudonymous customer reference only. Developer
logs never include ticket bodies.

## Artefact integrity

Objects are content addressed (`objects/sha256/…`). Writing different bytes under an existing key raises an
error, on local disk and on S3. Downloads, approvals, packaging and publication all re-verify SHA-256. Artefacts
referenced by a candidate are locked, and the ORM guard refuses to change or delete them.

## Known limitations

- The web interface keeps the access token in `sessionStorage`. A production deployment should move to an
  httpOnly session cookie issued by a backend-for-frontend and add CSRF protection.
- The local sandbox is not a filesystem boundary (see above).
- The socket proxy narrows the Docker API but does not inspect `create` options. The worker is trusted not to
  request privileged containers; a policy plugin or rootless Docker or Podman strengthens this further.
- Scanners report what they detected. The bundled advisory database is a local snapshot containing one
  fictional fixture entry; connect a real feed before relying on dependency findings.
