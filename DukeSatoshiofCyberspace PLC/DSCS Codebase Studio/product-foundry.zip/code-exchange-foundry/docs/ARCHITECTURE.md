# Architecture

## Shape

A **modular monolith** API, a separate **worker**, and adapters at every external boundary.

```
 Browser ──► web (Next.js) ──/api/v1 proxy──► api (FastAPI) ──► PostgreSQL (records, job queue, audit chain)
                                                  │                  ▲
                                                  ├──► S3 object store (content-addressed artefacts)
                                                  │                  │
                                              worker(s) ─────────────┘
                                                  │ claims jobs (SKIP LOCKED), heartbeats, retries
                                                  ├──► Git adapter (local / GitHub / GitLab, read-only)
                                                  ├──► Sandbox: disposable container per stage (docker-proxy)
                                                  └──► Storefront adapter (/v1, idempotent steps)
```

The API server never runs project code. It records intent: builds, documentation example checks,
publications, entitlement syncs and support imports are enqueued as durable jobs, and a worker executes them.

## Modules (`backend/foundry/`)

| Module | Responsibility |
|---|---|
| `models.py` | All authoritative records (43 tables). It keeps **project** (development effort), **product** (what customers recognise), **edition** (a purchasable configuration with its own contents and licence) and **release** (an immutable version from one commit) distinct. |
| `jobs.py` | Durable queue: idempotency keys, bounded exponential backoff, dead-lettering with full attempt history, cancellation, recovery of jobs whose worker stopped heartbeating. |
| `gitadapter.py` | Git access by argument vector, with refs and paths validated and hooks never run. Builds receive `git archive` of an immutable commit id. The assistant's only write path refuses protected branches. |
| `pipeline.py` | Parses the version-controlled `.foundry/pipeline.toml`: stages, `needs`, network mode, bounded retries, lockfiles, JUnit reports, artefact globs and builtins. |
| `sandbox.py` | `DockerSandbox` (new container per stage: no network, read-only root, all capabilities dropped, `no-new-privileges`, uid 65534, memory/CPU/PID limits, no bind mounts) and `LocalSandbox` (network namespace, uid drop, rlimits, scrubbed environment, process-group kill). |
| `builder.py` | Executes a build: checkout at the commit, stage execution, log capture, test parsing, artefact checksums, timing and resource use. It preserves failed results, records requirement evidence, and runs the trusted builtins (SBOM, dependency audit, secret scan). |
| `scanners.py`, `licensing.py` | Scanner runs with tool version, database version, timestamp and stated limitations. SBOM (CycloneDX 1.6) from installed metadata, third-party notices, licence classification and routing to human review. |
| `docs.py` | Versioned templates and release-bound document revisions. Unsupported-statement flags, executable examples (run in the sandbox), HTML and PDF output. |
| `packaging.py` | Edition manifests and deterministic packages, box artwork (front/spine/back, bleed, safe area), mockup vs print-ready validation, and an EAN-13 encoder for allocated GTINs only. |
| `releases.py` | State machine, candidate freeze (manifest hash), readiness evaluation, documented exceptions, approval with separation of duties and integrity re-verification, immutability guard (`before_flush`). |
| `catalogue.py` | Storefront adapter: payload build, field-level diff, separate listing approval, idempotent step-recorded publication, rollback of catalogue pointers, withdrawal sync, entitlement import. |
| `support.py` | Ticket import with redaction, private contact storage, update-eligibility rules. |
| `assistant.py` | Optional assistant with explicit scope, review branches, input manifests and model configuration records. |
| `audit.py` | Append-only audit trail; each event carries the hash of the previous one. |
| `security.py` | Authentication (bcrypt, HS256 tokens) and the role → permission map enforced on every route. |

## Key flows

### Build

1. `POST /repositories/{id}/builds {ref}` resolves the ref to a 40-character commit id, records the build and
   enqueues `build.run`.
2. The worker claims the job. It extracts `git archive <commit>` (no `.git`, no hooks), reads the pipeline from
   that commit, hashes the pipeline and the lockfiles, and copies the vetted wheelhouse in.
3. Each stage runs in a fresh sandbox. Its log is stored content-addressed, and its exit code, timing and
   resources are recorded. Dependents of a failed stage are skipped; independent stages still run.
4. JUnit reports become test results. Tests declare requirement keys, which become requirement evidence at
   that commit.
5. Declared artefacts are stored by SHA-256. A retry is a **new build** of the same commit; the earlier result is
   never overwritten.

### Release

`draft → candidate → validation → approved → published → superseded | withdrawn`

* **Candidate** freezes the artefacts of one passing build, the latest approved revision of each document
  (rendered to HTML and PDF), the approved licence versions, and a manifest and package per edition. The release
  manifest hash covers all of them.
* **Validation** evaluates 11 readiness checks. Each check links to its evidence. Failed checks can be covered
  only by an active, unexpired exception that names an owner, a reason and the affected scope.
* **Approval** re-reads every frozen artefact from object storage and verifies its checksum. It also
  re-verifies the manifest hash and readiness, and enforces separation of duties.
* After approval the ORM guard refuses changes to release contents, frozen artefacts and locked documents. Only
  status, publication timestamps, supersession, withdrawal and end-of-support dates may change.

### Publication

A listing per edition. `prepare` builds the storefront payload from the approved release and shows a
field-level diff against the live listing. A catalogue editor approves that exact payload (by hash), and that
approval is separate from release approval. `publish` creates a publication job whose idempotency key is
derived from listing, release and payload hash. The job's steps are product → edition → package → release →
pointer. Each step is an upsert by external reference or carries an `Idempotency-Key`, and each records its
external id as soon as it succeeds. After a partial failure the job resumes from the next step. Package bytes
are read from storage and checked against the frozen checksum; they are never rebuilt. The storefront refuses
different bytes for a stored version.

### Updates and entitlements

Entitlements come from the storefront. Eligibility is computed from the purchased edition (bundles include
their component editions), the covered major versions, the patch-only rule and the update window. Withdrawn
releases are never offered. The storefront mock enforces the same rule at download time, and a test checks that
the two implementations agree.

## Background jobs

| Kind | Handler | Retries |
|---|---|---|
| `build.run` | `builder.run_build` | 2 attempts (stage-level retries are separate and bounded to 2) |
| `docs.check_examples` | `docs._check_examples` | 2 |
| `catalogue.publish` | `catalogue._publish` | 5, then dead; an operator retry resumes recorded steps |
| `catalogue.pointer`, `catalogue.withdraw` | rollback / withdrawal sync | 5 |
| `entitlements.sync`, `support.import` | imports | 3 |

## Scaling notes

Run more workers to scale; they coordinate only through PostgreSQL row locks. The API is stateless. Object keys
are content addressed, so storage is deduplicated and can safely be cached.
