# Product Foundry API reference

Base path: `/api/v1` (versioned). Authentication: `Authorization: Bearer <token>` from `POST /api/v1/auth/login`.
Interactive documentation is served at `/api/docs`; the machine-readable schema is [`openapi.json`](openapi.json).
Permissions are enforced by the API; see `GET /api/v1/roles` or the permission table in SECURITY.md.

Error format: `{"detail": ...}` with 401 (not signed in), 403 (permission or separation of duties), 404, 409 (state/immutability/readiness conflict), 422 (validation).

## admin

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/v1/audit` | Audit Log |
| GET | `/api/v1/audit/verify` | Audit Verify |
| GET | `/api/v1/jobs` | List Jobs |
| POST | `/api/v1/jobs/{jid}/retry` | Retry Job |
| GET | `/api/v1/roles` | Roles |
| GET | `/api/v1/settings` | Get Settings |
| PUT | `/api/v1/settings/{key}` | Put Setting |
| GET | `/api/v1/users` | List Users |
| POST | `/api/v1/users` | Create User |
| PATCH | `/api/v1/users/{uid}` | Patch User |

## auth

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/v1/auth/login` | Login |
| GET | `/api/v1/auth/me` | Me |

## catalogue & support

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/v1/advisories` | Advisories |
| POST | `/api/v1/advisories` | Create Advisory |
| POST | `/api/v1/assistant/runs/{aid}/accept-tasks` | Accept Tasks |
| GET | `/api/v1/catalogue/listings` | Listings |
| POST | `/api/v1/editions/{eid}/listing/prepare` | Prepare |
| GET | `/api/v1/entitlements` | Entitlements |
| POST | `/api/v1/entitlements/sync` | Sync Entitlements |
| POST | `/api/v1/listings/{lid}/approve` | Approve |
| GET | `/api/v1/listings/{lid}/preview` | Preview |
| POST | `/api/v1/listings/{lid}/publish` | Publish |
| POST | `/api/v1/listings/{lid}/rollback` | Rollback |
| POST | `/api/v1/projects/{pid}/assistant` | Run Assistant |
| GET | `/api/v1/projects/{pid}/assistant/runs` | Assistant Runs |
| GET | `/api/v1/publication-jobs` | Publication Jobs |
| GET | `/api/v1/publication-jobs/{pid}` | Publication Job |
| POST | `/api/v1/support/import` | Import Support |
| GET | `/api/v1/support/issues` | Issues |
| PATCH | `/api/v1/support/issues/{iid}` | Patch Issue |
| GET | `/api/v1/support/issues/{iid}/contact` | Issue Contact |

## engineering

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/v1/artifacts/{aid}` | Artifact Meta |
| GET | `/api/v1/artifacts/{aid}/download` | Artifact Download |
| GET | `/api/v1/builds` | All Builds |
| GET | `/api/v1/builds/{bid}` | Get Build |
| POST | `/api/v1/builds/{bid}/cancel` | Cancel Build |
| POST | `/api/v1/builds/{bid}/retry` | A retry is a NEW build of the same immutable commit; the earlier result is preserved. |
| GET | `/api/v1/builds/{bid}/stages/{sid}/log` | Stage Log |
| PATCH | `/api/v1/findings/{fid}` | Patch Finding |
| GET | `/api/v1/projects/{pid}/builds` | List Builds |
| GET | `/api/v1/projects/{pid}/repositories` | List Repos |
| POST | `/api/v1/projects/{pid}/repositories` | Connect Repo |
| GET | `/api/v1/repositories` | All Repos |
| DELETE | `/api/v1/repositories/{rid}` | Disconnect Repo |
| GET | `/api/v1/repositories/{rid}/branches` | Branches |
| POST | `/api/v1/repositories/{rid}/builds` | Trigger Build |
| GET | `/api/v1/repositories/{rid}/commits` | Commits |
| GET | `/api/v1/repositories/{rid}/diff` | Diff |
| GET | `/api/v1/repositories/{rid}/file` | File |
| GET | `/api/v1/repositories/{rid}/links` | Links |
| GET | `/api/v1/repositories/{rid}/tree` | Tree |

## overview

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/v1/overview` | What are we building, what is blocking release, and what is ready to sell? |

## projects

| Method | Path | Purpose |
|---|---|---|
| PATCH | `/api/v1/editions/{eid}` | Patch Edition |
| GET | `/api/v1/products` | All Products |
| PATCH | `/api/v1/products/{prid}` | Patch Product |
| GET | `/api/v1/products/{prid}/editions` | List Editions |
| POST | `/api/v1/products/{prid}/editions` | Add Edition |
| GET | `/api/v1/projects` | List Projects |
| POST | `/api/v1/projects` | Create Project |
| GET | `/api/v1/projects/{pid}` | Get Project |
| PATCH | `/api/v1/projects/{pid}` | Patch Project |
| GET | `/api/v1/projects/{pid}/costs` | Costs |
| POST | `/api/v1/projects/{pid}/costs` | Add Cost |
| POST | `/api/v1/projects/{pid}/members` | Add Member |
| GET | `/api/v1/projects/{pid}/milestones` | Milestones |
| POST | `/api/v1/projects/{pid}/milestones` | Add Milestone |
| GET | `/api/v1/projects/{pid}/products` | List Products |
| POST | `/api/v1/projects/{pid}/products` | Add Product |
| GET | `/api/v1/projects/{pid}/requirements` | List Requirements |
| POST | `/api/v1/projects/{pid}/requirements` | Add Requirement |
| GET | `/api/v1/projects/{pid}/tasks` | List Tasks |
| POST | `/api/v1/projects/{pid}/tasks` | Add Task |
| PATCH | `/api/v1/requirements/{rid}` | Patch Requirement |
| POST | `/api/v1/requirements/{rid}/accept` | Accept Requirement |
| POST | `/api/v1/requirements/{rid}/evidence` | Add Evidence |
| PATCH | `/api/v1/tasks/{tid}` | Patch Task |

## releases

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/v1/artworks/{awid}/svg` | Artwork Svg |
| GET | `/api/v1/builds/{bid}/sbom` | Sbom |
| GET | `/api/v1/doc-templates` | Templates |
| POST | `/api/v1/doc-templates` | New Template |
| GET | `/api/v1/documents/{did}` | Get Doc |
| PUT | `/api/v1/documents/{did}` | Edit Doc |
| POST | `/api/v1/documents/{did}/approve` | Approve Doc |
| POST | `/api/v1/documents/{did}/check-examples` | Check Examples |
| POST | `/api/v1/documents/{did}/flags/{index}/resolve` | Resolve Flag |
| GET | `/api/v1/documents/{did}/pdf` | Pdf Doc |
| GET | `/api/v1/documents/{did}/preview` | Preview Doc |
| POST | `/api/v1/documents/{did}/submit` | Submit Doc |
| GET | `/api/v1/editions/{eid}/artworks` | Artworks |
| DELETE | `/api/v1/exceptions/{xid}` | Revoke Exception |
| POST | `/api/v1/licence-reviews/{rid}/decide` | Decide |
| GET | `/api/v1/licence-versions` | Licence Versions |
| POST | `/api/v1/licence-versions` | Create Licence |
| PATCH | `/api/v1/licence-versions/{lid}` | Patch Licence |
| POST | `/api/v1/licence-versions/{lid}/approve` | Approve Licence |
| GET | `/api/v1/packaging-templates` | Packaging Templates |
| POST | `/api/v1/products/{prid}/releases` | Create Release |
| GET | `/api/v1/projects/{pid}/assets` | Assets |
| GET | `/api/v1/projects/{pid}/contributors` | Contributors |
| POST | `/api/v1/projects/{pid}/contributors` | Add Contributor |
| GET | `/api/v1/projects/{pid}/licence-reviews` | Licence Reviews |
| GET | `/api/v1/projects/{pid}/releases` | Project Releases |
| GET | `/api/v1/releases` | All Releases |
| GET | `/api/v1/releases/{rid}` | Get Release |
| PATCH | `/api/v1/releases/{rid}` | Patch Release |
| POST | `/api/v1/releases/{rid}/approve` | Approve |
| POST | `/api/v1/releases/{rid}/candidate` | To Candidate |
| GET | `/api/v1/releases/{rid}/documents` | Release Docs |
| POST | `/api/v1/releases/{rid}/documents/generate` | Generate Docs |
| POST | `/api/v1/releases/{rid}/editions/{eid}/artwork` | Make Artwork |
| POST | `/api/v1/releases/{rid}/end-of-support` | Support dates remain editable after publication; contents do not. |
| POST | `/api/v1/releases/{rid}/exceptions` | Add Exception |
| GET | `/api/v1/releases/{rid}/integrity` | Integrity |
| POST | `/api/v1/releases/{rid}/platform-verifications` | Add Verification |
| GET | `/api/v1/releases/{rid}/readiness` | Readiness |
| POST | `/api/v1/releases/{rid}/return-to-draft` | To Draft |
| POST | `/api/v1/releases/{rid}/reviews` | Add Review |
| POST | `/api/v1/releases/{rid}/validation` | To Validation |
| POST | `/api/v1/releases/{rid}/withdraw` | Withdraw |

## service

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Health |

## Storefront publishing API (mock, `storefront_mock/app.py`)

The catalogue adapter (`backend/foundry/catalogue.py`) targets this versioned contract. Publisher calls use
`Authorization: Bearer <FOUNDRY_STOREFRONT_TOKEN>` and an `Idempotency-Key`; repeated keys replay the stored response.

| Method | Path | Purpose |
|---|---|---|
| PUT | `/v1/products/{ref}` | Upsert a product by the publisher's external reference |
| PUT | `/v1/products/{id}/editions/{ref}` | Upsert an edition (price, licence, update policy, artwork) |
| PUT | `/v1/editions/{id}/releases/{version}/package` | Upload package bytes; `X-Content-SHA256` must match; different bytes for a stored version → 409 |
| PUT | `/v1/editions/{id}/releases/{version}` | Release metadata (manifest hashes, included files, requirements, docs) |
| PUT | `/v1/editions/{id}/pointer` | Point the listing at a version (publish or roll back) |
| POST | `/v1/editions/{id}/releases/{version}/withdraw` | Stop new downloads of a version |
| POST | `/v1/advisories` | Customer advisory; `notify_entitled_customers` notifies affected owners |
| POST | `/v1/editions/{id}/keys` | Allocate download keys for boxed editions |
| GET | `/v1/entitlements` | Entitlements for import into Foundry (pseudonymous customer ids) |
| GET | `/v1/support/tickets` | Support tickets for import (contains private contact data) |
| GET | `/v1/retail/catalogue` | Physical-shop feed: only boxed/USB editions with an allocated GTIN and print-ready artwork |
| GET | `/v1/shop` | Public catalogue view |
| POST | `/v1/customers`, `/v1/orders` | Simulated customer account and checkout (no payment is taken) |
| GET | `/v1/library`, `/v1/library/download/{edition}/{version}` | Customer library; downloads gated by entitlement |
| POST | `/v1/library/redeem` | Redeem a boxed-edition key |
| POST | `/_faults`, GET `/_state`, POST `/_reset` | Test controls: inject failures before/after commit, inspect, reset |
