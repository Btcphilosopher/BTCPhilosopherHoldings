"use client";

import Link from "next/link";
import { useState } from "react";
import { useUser } from "@/components/Shell";
import { Card, ErrorBanner, Field, Loading, PageHead, Status, Table } from "@/components/ui";
import { act, api, can, fmtDate, short, useApi } from "@/lib/api";

export default function Releases() {
  const user = useUser();
  const { data, error, reload } = useApi<any[]>("/releases");
  const products = useApi<any[]>("/products");
  const [prod, setProd] = useState("");
  const product = products.data?.find((p) => String(p.id) === prod);
  const builds = useApi<any[]>(product ? `/projects/${product.project_id}/builds` : null);
  const [form, setForm] = useState({ version: "", build_id: "", notes: "" });
  return (
    <>
      <PageHead title="Releases" intro="Draft → Candidate → Validation → Approved → Published → Superseded or Withdrawn. Approved releases are immutable." />
      <ErrorBanner error={error} />
      <div className="grid cols-3">
        <div style={{ gridColumn: "span 2" }}>
          <Card>
            {!data ? <Loading /> : <Table head={["Release", "Status", "Build", "Commit", "Manifest", "Published"]}
              rows={data.map((r) => [<Link key="l" href={`/releases/${r.id}`}><strong>{r.product} {r.version}</strong></Link>, <Status key="s" value={r.status} />,
                r.build_number ? <Link key="b" href={`/builds/${r.build_id}`}>#{r.build_number}</Link> : "—",
                <span key="c" className="sha">{short(r.commit_sha, 12)}</span>, <span key="m" className="sha">{short(r.manifest_sha256, 12)}</span>,
                fmtDate(r.published_at)])} />}
          </Card>
        </div>
        {can(user, "release.create") && <Card title="New release draft" sub="From a passing build; the version must match the built artefact.">
          <form className="form" onSubmit={async (e) => {
            e.preventDefault();
            const r = await act(() => api(`/products/${prod}/releases`, { body: { ...form, build_id: Number(form.build_id) } }), "Release draft created");
            if (r) reload();
          }}>
            <Field label="Product"><select value={prod} onChange={(e) => setProd(e.target.value)} required>
              <option value="">Choose…</option>{products.data?.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
            <Field label="Build"><select value={form.build_id} onChange={(e) => setForm({ ...form, build_id: e.target.value })} required>
              <option value="">Choose…</option>{builds.data?.filter((b) => b.status === "passed").map((b) =>
                <option key={b.id} value={b.id}>#{b.number} {short(b.commit_sha)} {b.commit_message}</option>)}</select></Field>
            <Field label="Version"><input value={form.version} onChange={(e) => setForm({ ...form, version: e.target.value })} placeholder="1.0.0" required /></Field>
            <Field label="Release notes"><textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
            <button className="btn">Create draft</button>
          </form>
        </Card>}
      </div>
    </>
  );
}
