"use client";

import Link from "next/link";
import { use, useState } from "react";
import { useUser } from "@/components/Shell";
import { Card, Code, ErrorBanner, Field, KV, Loading, PageHead, Status, Table, Tabs } from "@/components/ui";
import { act, api, can, fmtDate, short, useApi } from "@/lib/api";
import { Readiness } from "@/components/Readiness";

const FLOW = ["draft", "candidate", "validation", "approved", "published"];

export default function ReleasePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const user = useUser();
  const r = useApi<any>(`/releases/${id}`);
  const [tab, setTab] = useState("summary");
  const [claims, setClaims] = useState<string | null>(null);
  if (!r.data) return <><ErrorBanner error={r.error} /><Loading /></>;
  const rel = r.data;
  const go = async (path: string, body: any = {}, msg = "Done") => { await act(() => api(`/releases/${id}/${path}`, { body }), msg); r.reload(); };
  const rm = can(user, "release.transition");
  return (
    <>
      <PageHead title={`${rel.product} ${rel.version}`} intro={rel.notes}>
        <Status value={rel.status} />
        {rel.status === "draft" && rm && <button className="btn" onClick={() => go("candidate", {}, "Candidate frozen")}>Freeze candidate</button>}
        {rel.status === "candidate" && rm && <button className="btn" onClick={() => go("validation", {}, "Validation started")}>Start validation</button>}
        {["candidate", "validation"].includes(rel.status) && rm && <button className="btn secondary" onClick={() => {
          const reason = prompt("Why return to draft?"); if (reason) go("return-to-draft", { reason });
        }}>Return to draft</button>}
        {rel.status === "validation" && can(user, "release.approve") && <button className="btn" onClick={() => go("approve", { comment: "" }, "Release approved")}>Approve</button>}
        {["approved", "published", "superseded"].includes(rel.status) && can(user, "release.withdraw") && <button className="btn danger" onClick={() => {
          const reason = prompt("Reason for withdrawal (shown to customers)"); if (reason) go("withdraw", { reason }, "Release withdrawn; advisory queued");
        }}>Withdraw</button>}
      </PageHead>
      <ol className="row" aria-label="Release lifecycle" style={{ listStyle: "none", padding: 0, margin: "0 0 16px" }}>
        {FLOW.map((s) => <li key={s}><Status value={s === rel.status ? rel.status : FLOW.indexOf(s) < FLOW.indexOf(rel.status) ? "passed" : "pending"} label={s} /></li>)}
        {["superseded", "withdrawn"].includes(rel.status) && <li><Status value={rel.status} /></li>}
      </ol>
      <Tabs value={tab} onChange={setTab} tabs={[{ id: "summary", label: "Summary" }, { id: "readiness", label: "Readiness" },
        { id: "contents", label: "Frozen contents" }, { id: "history", label: "History & approvals" }]} />
      {tab === "summary" && <div className="grid cols-2">
        <Card title="Source and build">
          <KV items={[["Commit", <span key="c" className="mono">{rel.commit_sha}</span>], ["Build", <Link key="b" href={`/builds/${rel.build_id}`}>#{rel.build_number}</Link>],
            ["Manifest sha256", <span key="m" className="mono small">{rel.manifest_sha256 ?? "not frozen"}</span>],
            ["Created by", rel.created_by_name], ["Approved by", rel.approved_by_name ? `${rel.approved_by_name} · ${fmtDate(rel.approved_at)}` : "—"],
            ["End of support", rel.end_of_support_on], ["Compatibility", <span key="x" className="small">{JSON.stringify(rel.compatibility)}</span>]]} />
        </Card>
        <Card title="Platform claims" sub="Every claim needs verification evidence before approval.">
          <Table head={["Platform", "Verification"]} rows={rel.platform_claims.map((p: string) => {
            const v = rel.platform_verifications.filter((x: any) => x.platform === p).slice(-1)[0];
            return [p, v ? <span key="v"><Status value={v.result} /> <span className="small">{v.method}: {v.evidence}</span></span> : <Status key="u" value="unverified" />];
          })} />
          {rel.status === "draft" && can(user, "release.create") && <form className="row" style={{ marginTop: 10 }} onSubmit={async (e) => {
            e.preventDefault();
            await act(() => api(`/releases/${id}`, { method: "PATCH", body: { platform_claims: (claims ?? rel.platform_claims.join(", ")).split(",").map((s: string) => s.trim()).filter(Boolean) } }), "Claims updated");
            r.reload();
          }}>
            <input aria-label="Platform claims" value={claims ?? rel.platform_claims.join(", ")} onChange={(e) => setClaims(e.target.value)} style={{ flex: 1 }} />
            <button className="btn small">Update claims</button>
          </form>}
        </Card>
      </div>}
      {tab === "readiness" && <Readiness rid={id} />}
      {tab === "contents" && <div className="grid">
        <Card title="Artefacts">
          <Table head={["Role", "File", "SHA-256", "Size"]} rows={rel.artifacts.map((a: any) => [a.release_role, a.filename, <span key="h" className="sha">{a.sha256}</span>, `${a.size} B`])}
                 empty="Not frozen yet: artefacts are fixed when the candidate is created." />
        </Card>
        {rel.editions.map((e: any) => (
          <Card key={e.edition_id} title={`Edition: ${e.edition}`} sub={`${e.kind} · manifest ${short(e.manifest_sha256, 16)}`}>
            {e.manifest?.package ? <>
              <KV items={[["Package", `${e.manifest.package.filename} (${e.manifest.package.size} B)`], ["Package sha256", <span key="p" className="mono small">{e.manifest.package.sha256}</span>],
                ["Licence", `${e.manifest.licence.title} v${e.manifest.licence.version}`]]} />
              <Code label="Edition manifest" text={JSON.stringify(e.manifest.includes.map((f: any) => `${f.path}  ${f.sha256.slice(0, 16)}…`), null, 1)} />
            </> : <p className="muted">No manifest until the candidate is frozen.</p>}
          </Card>))}
      </div>}
      {tab === "history" && <div className="grid cols-2">
        <Card title="Approvals">
          <Table head={["Kind", "By", "Decision", "When", "Readiness hash"]} rows={rel.approvals.map((a: any) => [a.kind, a.user, <Status key="d" value={a.decision} />, fmtDate(a.at), <span key="h" className="sha">{short(a.readiness_sha256, 12)}</span>])} />
        </Card>
        <Card title="Lifecycle history">
          <Table head={["When", "By", "Action"]} rows={(rel.history || []).map((h: any) => [fmtDate(h.at), h.by, <span key="a">{h.action}{h.reason ? ` — ${h.reason}` : ""}</span>])} />
          {rel.withdrawn_reason && <div className="banner bad" style={{ marginTop: 10 }}>Withdrawn: {rel.withdrawn_reason}</div>}
        </Card>
      </div>}
    </>
  );
}
