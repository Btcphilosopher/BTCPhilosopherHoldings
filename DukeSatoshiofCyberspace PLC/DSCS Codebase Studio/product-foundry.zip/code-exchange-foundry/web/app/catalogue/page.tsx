"use client";

import { useState } from "react";
import { useUser } from "@/components/Shell";
import { Card, Empty, Field, Loading, PageHead, Status, Table } from "@/components/ui";
import { act, api, can, fmtDate, money, useApi } from "@/lib/api";

function Preview({ lid, onDone }: { lid: number; onDone: () => void }) {
  const user = useUser();
  const p = useApi<any>(`/listings/${lid}/preview`);
  if (!p.data) return <Loading />;
  const pl = p.data.payload;
  return (
    <Card title="Publication preview" sub={`payload sha256 ${p.data.payload_sha256?.slice(0, 16)}… · ${p.data.changes.length} field change(s) against the live listing`}
          actions={<div className="row">
            {p.data.status === "pending-approval" && can(user, "catalogue.approve") && <button className="btn small" onClick={() =>
              act(() => api(`/listings/${lid}/approve`, { body: { comment: "Reviewed in preview" } }), "Listing approved").then(() => { p.reload(); onDone(); })}>Approve listing</button>}
            {["approved", "failed"].includes(p.data.status) && can(user, "catalogue.publish") && <button className="btn small" onClick={() =>
              act(() => api(`/listings/${lid}/publish`, { body: {} }), "Publication job queued").then(onDone)}>Publish</button>}
          </div>}>
      {pl && <div className="grid cols-2">
        <div>
          <h3 style={{ margin: "0 0 4px" }}>{pl.product.title}</h3>
          <p className="muted" style={{ margin: 0 }}>{pl.product.tagline}</p>
          <p className="small">{pl.product.description}</p>
          <p className="small"><strong>{pl.edition.name}</strong> · {money(pl.edition.price)} · {pl.edition.delivery_method} · SKU {pl.edition.sku}</p>
          <p className="small">Licence: {pl.edition.licence?.title} v{pl.edition.licence?.version} — {pl.edition.licence?.summary}</p>
          <p className="small">Requires Python {pl.release.requirements.python}+ · verified on {pl.release.requirements.verified_platforms.join(", ")}</p>
          <p className="small">Version {pl.release.version} · supported until {pl.release.end_of_support ?? "—"} · {pl.edition.support_terms}</p>
          <p className="small">Included: {pl.release.included_files.map((f: any) => f.path).join(", ")}</p>
        </div>
        <div className="table-wrap" style={{ maxHeight: 360, overflow: "auto" }}>
          <table className="data"><thead><tr><th>Field</th><th>Before</th><th>After</th></tr></thead>
            <tbody>{p.data.changes.map((c: any) => <tr key={c.field}><td className="mono small">{c.field}</td>
              <td className="small diff-del">{c.before === undefined || c.before === null ? "—" : String(c.before).slice(0, 60)}</td>
              <td className="small diff-add">{c.after === undefined || c.after === null ? "—" : String(c.after).slice(0, 60)}</td></tr>)}</tbody></table>
        </div>
      </div>}
    </Card>
  );
}

export default function Catalogue() {
  const user = useUser();
  const listings = useApi<any[]>("/catalogue/listings", 4000);
  const jobs = useApi<any[]>("/publication-jobs", 4000);
  const products = useApi<any[]>("/products");
  const releases = useApi<any[]>("/releases");
  const [sel, setSel] = useState<number | null>(null);
  const [prep, setPrep] = useState({ edition: "", release: "" });
  const editions = products.data?.flatMap((p) => p.editions.map((e: any) => ({ ...e, product: p.name }))) ?? [];
  return (
    <>
      <PageHead title="Catalogue" intro="Publish approved releases to The Code Exchange storefront. Internal release approval and public-listing approval are separate decisions." />
      <div className="grid cols-3">
        <div style={{ gridColumn: "span 2" }}>
          <Card title="Listings">
            {!listings.data ? <Loading /> : <Table head={["Edition", "Channel", "Status", "Live version", "Draft version", "Storefront ids", ""]}
              rows={listings.data.map((l) => [<span key="e"><strong>{l.product}</strong> {l.edition.name}</span>, l.channel, <Status key="s" value={l.status} />,
                l.current_version ?? "—", l.draft_version ?? "—", <span key="x" className="mono small">{l.external_edition_id ?? "—"}</span>,
                <div key="a" className="row">
                  <button className="btn small secondary" onClick={() => setSel(l.id)}>Preview</button>
                  {l.status === "published" && can(user, "catalogue.rollback") && <button className="btn small secondary" onClick={() => {
                    const reason = prompt("Reason for moving the catalogue pointer back to the previous release"); if (reason)
                      act(() => api(`/listings/${l.id}/rollback`, { body: { reason } }), "Rollback queued. Customers who already downloaded or installed are not affected.").then(listings.reload);
                  }}>Roll back</button>}
                </div>])} />}
          </Card>
        </div>
        {can(user, "catalogue.edit") && <Card title="Prepare listing" sub="Builds the storefront payload from an approved release">
          <form className="form" onSubmit={async (e) => { e.preventDefault();
            const r = await act(() => api(`/editions/${prep.edition}/listing/prepare`, { body: { release_id: Number(prep.release) } }), "Listing prepared");
            if (r) { listings.reload(); setSel(r.listing_id); } }}>
            <Field label="Edition"><select value={prep.edition} onChange={(e) => setPrep({ ...prep, edition: e.target.value })} required>
              <option value="">Choose…</option>{editions.map((e: any) => <option key={e.id} value={e.id}>{e.product} — {e.name}</option>)}</select></Field>
            <Field label="Release"><select value={prep.release} onChange={(e) => setPrep({ ...prep, release: e.target.value })} required>
              <option value="">Choose…</option>{releases.data?.filter((r) => ["approved", "published"].includes(r.status)).map((r) =>
                <option key={r.id} value={r.id}>{r.product} {r.version} ({r.status})</option>)}</select></Field>
            <button className="btn">Prepare</button>
          </form>
        </Card>}
      </div>
      <div style={{ marginTop: 16 }}>{sel ? <Preview key={sel} lid={sel} onDone={() => { listings.reload(); jobs.reload(); }} /> : null}</div>
      <div style={{ marginTop: 16 }}>
        <Card title="Publication jobs" sub="Idempotent, step-recorded jobs. Retries continue from the last completed step without duplicating storefront records.">
          {!jobs.data ? <Loading /> : jobs.data.length === 0 ? <Empty>No publications yet.</Empty> :
            <Table head={["Job", "Action", "Status", "Attempts", "Steps", "Last error", "Finished"]}
              rows={jobs.data.map((j) => [j.id, j.action, <Status key="s" value={j.status} />, j.attempts,
                <span key="st" className="small">{Object.entries(j.steps || {}).filter(([k]) => k !== "reason").map(([k, v]: any) => `${k}${v.status === "done" ? " ✓" : ""}`).join(" → ")}</span>,
                <span key="e" className="small">{j.last_error?.slice(0, 90)}</span>, fmtDate(j.finished_at)])} />}
        </Card>
      </div>
    </>
  );
}
