"use client";

import Link from "next/link";
import { Card, ErrorBanner, Empty, Loading, PageHead, Status } from "@/components/ui";
import { fmtDate, money, short, useApi } from "@/lib/api";

export default function Overview() {
  const { data, error } = useApi<any>("/overview", 10000);
  const builds = useApi<any[]>("/builds?limit=8", 10000);
  return (
    <>
      <PageHead title="Overview" intro="What we are building, what is blocking release, and what is ready to sell." />
      <ErrorBanner error={error} />
      {!data ? <Loading /> : (
        <div className="grid cols-3">
          <Card title="What are we building?" className="accent" sub={`${data.building.length} project(s) in development`}>
            {data.building.length === 0 ? <Empty>No active projects. <Link href="/projects">Start one</Link>.</Empty> :
              data.building.map((b: any) => (
                <div key={b.project.id} style={{ padding: "8px 0", borderBottom: "1px solid var(--ivory-200)" }}>
                  <div className="row">
                    <Link href={`/projects/${b.project.id}`}><strong>{b.project.name}</strong></Link>
                    <Status value={b.project.status} />
                  </div>
                  <div className="small muted">
                    {b.latest_build ? <>Latest build <Link href={`/builds/${b.latest_build.id}`}>#{b.latest_build.number}</Link>{" "}
                      <Status value={b.latest_build.status} /> <span className="sha">{short(b.latest_build.commit_sha)}</span></>
                      : "No builds yet"}
                  </div>
                </div>
              ))}
          </Card>
          <Card title="What is blocking release?" className="accent"
                sub={`${data.blocking.length} release(s) in preparation`}>
            {data.blocking.length === 0 ? <Empty>No releases in preparation.</Empty> :
              data.blocking.map((b: any) => (
                <div key={b.release.id} style={{ padding: "8px 0", borderBottom: "1px solid var(--ivory-200)" }}>
                  <div className="row">
                    <Link href={`/releases/${b.release.id}`}><strong>{b.product} {b.release.version}</strong></Link>
                    <Status value={b.release.status} />
                  </div>
                  {b.blocking.length === 0 ? <div className="small"><Status value="ready" /> all checks pass</div> :
                    <ul className="evidence">
                      {b.checks.filter((c: any) => c.status === "failed").map((c: any) => (
                        <li key={c.key}><strong>{c.key}</strong>: {c.summary}</li>
                      ))}
                    </ul>}
                </div>
              ))}
          </Card>
          <Card title="What is ready to sell?" className="accent" sub="Catalogue listings and approved releases">
            {data.ready_to_sell.length === 0 && data.approved_releases.length === 0 ? <Empty>Nothing approved yet.</Empty> : null}
            {data.ready_to_sell.map((l: any) => (
              <div key={l.listing_id} style={{ padding: "6px 0", borderBottom: "1px solid var(--ivory-200)" }}>
                <div className="row"><strong>{l.product}</strong> <span className="muted">{l.edition}</span><span className="spacer" />
                  <Status value={l.status} /></div>
                <div className="small muted">{l.sku} · {money(l.price)} · {l.release ? `v${l.release}` : "no release"}</div>
              </div>
            ))}
            {data.approved_releases.filter((r: any) => r.status === "approved").map((r: any) => (
              <div key={r.id} className="small" style={{ padding: "6px 0" }}>
                <Link href={`/releases/${r.id}`}>{r.product} {r.version}</Link> approved — awaiting listing
              </div>
            ))}
          </Card>
        </div>
      )}
      <div className="grid cols-2" style={{ marginTop: 16 }}>
        <Card title="Recent builds">
          {!builds.data ? <Loading /> : builds.data.length === 0 ? <Empty>No builds.</Empty> :
            <div className="table-wrap"><table className="data"><thead><tr><th>Build</th><th>Project</th><th>Commit</th><th>Status</th><th>When</th></tr></thead>
              <tbody>{builds.data.map((b) => (
                <tr key={b.id}><td><Link href={`/builds/${b.id}`}>#{b.number}</Link></td><td>{b.project}</td>
                  <td><span className="sha">{short(b.commit_sha)}</span> <span className="small">{b.commit_message}</span></td>
                  <td><Status value={b.status} /></td><td className="small">{fmtDate(b.created_at)}</td></tr>
              ))}</tbody></table></div>}
        </Card>
        <Card title="Background work">
          {data && <div className="grid cols-3">
            {["queued", "running", "failed", "dead", "succeeded"].map((s) => (
              <div key={s}><div className="stat">{data.jobs[s] ?? 0}</div><div className="stat-label">{s} jobs</div></div>
            ))}
            {["passed", "failed", "cancelled"].map((s) => (
              <div key={"b" + s}><div className="stat">{data.build_counts[s] ?? 0}</div><div className="stat-label">{s} builds</div></div>
            ))}
          </div>}
        </Card>
      </div>
    </>
  );
}
