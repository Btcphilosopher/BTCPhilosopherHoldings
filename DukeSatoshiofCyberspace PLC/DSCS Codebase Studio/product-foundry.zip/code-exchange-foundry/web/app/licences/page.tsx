"use client";

import { useState } from "react";
import { useUser } from "@/components/Shell";
import { Card, Code, Empty, Field, Loading, PageHead, Status, Table, Tabs } from "@/components/ui";
import { act, api, can, fmtDate, useApi } from "@/lib/api";

const RIGHTS = ["binary_distribution", "source_access", "permission_to_modify", "redistribution", "commercial_deployment",
                "update_entitlement", "support_entitlement", "copyright_transfer"];

function show(v: any) { return v === true ? "yes" : v === false ? "no" : String(v); }

export default function Licences() {
  const user = useUser();
  const projects = useApi<any[]>("/projects");
  const [pid, setPid] = useState("");
  const eff = pid || (projects.data?.[0] ? String(projects.data[0].id) : "");
  const [tab, setTab] = useState("commercial");
  const lv = useApi<any[]>("/licence-versions");
  const reviews = useApi<any[]>(eff ? `/projects/${eff}/licence-reviews` : null);
  const assets = useApi<any[]>(eff ? `/projects/${eff}/assets` : null);
  const contributors = useApi<any[]>(eff ? `/projects/${eff}/contributors` : null);
  const builds = useApi<any[]>(eff ? `/projects/${eff}/builds` : null);
  const lastPassed = builds.data?.find((b) => b.status === "passed");
  const sbom = useApi<any>(lastPassed ? `/builds/${lastPassed.id}/sbom` : null);
  return (
    <>
      <PageHead title="Licences" intro="Ownership, provenance, third-party components and commercial licence versions. Automated analysis routes uncertain rights to a reviewer; it is not legal clearance.">
        <Field label="Project"><select value={eff} onChange={(e) => setPid(e.target.value)}>
          {projects.data?.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
      </PageHead>
      <Tabs value={tab} onChange={setTab} tabs={[{ id: "commercial", label: "Commercial licences" }, { id: "reviews", label: `Reviews${reviews.data?.some((r) => r.status === "open") ? " •" : ""}` },
        { id: "sbom", label: "Components & SBOM" }, { id: "provenance", label: "Provenance" }]} />
      {tab === "commercial" && <Card title="Licence versions" sub="Each right is stated separately. Buying source access never transfers copyright or implies unlimited redistribution. Approved versions are immutable.">
        {!lv.data ? <Loading /> : <div className="table-wrap"><table className="data">
          <thead><tr><th>Right</th>{lv.data.map((l) => <th key={l.id}>{l.code} v{l.version} <Status value={l.status} /></th>)}</tr></thead>
          <tbody>{RIGHTS.map((k) => <tr key={k}><td>{k.replace(/_/g, " ")}</td>{lv.data!.map((l) => <td key={l.id}>{show(l.rights[k])}</td>)}</tr>)}
            <tr><td>Summary</td>{lv.data.map((l) => <td key={l.id} className="small">{l.summary}</td>)}</tr>
            <tr><td></td>{lv.data.map((l) => <td key={l.id}>{l.status === "draft" && can(user, "licence.approve") &&
              <button className="btn small" onClick={() => act(() => api(`/licence-versions/${l.id}/approve`, { body: {} }), "Licence approved").then(lv.reload)}>Approve</button>}
              <span className="sha">text {l.text_sha256.slice(0, 10)}</span></td>)}</tr>
          </tbody></table></div>}
      </Card>}
      {tab === "reviews" && <Card title="Licence review queue">
        {!reviews.data ? <Loading /> : <Table head={["Subject", "Issue", "Raised by", "Status", "Decision", ""]}
          rows={reviews.data.map((r) => [<span key="s" className="mono small">{r.subject_ref}</span>, <span key="i" className="small">{r.issue}</span>, r.raised_by,
            <Status key="st" value={r.status} />, <span key="d" className="small">{r.decision}{r.decided_at ? ` (${fmtDate(r.decided_at)})` : ""}</span>,
            ["open", "rejected"].includes(r.status) && can(user, "licence.review") ? <div key="a" className="row">
              {["cleared", "rejected", "remediated"].map((s) => <button key={s} className="btn small secondary" onClick={() => {
                const decision = prompt(`Decision record for "${s}"`); if (decision) act(() => api(`/licence-reviews/${r.id}/decide`, { body: { status: s, decision } }), "Decision recorded").then(reviews.reload);
              }}>{s}</button>)}</div> : null])} />}
      </Card>}
      {tab === "sbom" && <div className="grid cols-2">
        <Card title={lastPassed ? `Components in build #${lastPassed.number}` : "Components"} sub="From the dependencies actually installed for the build">
          {!sbom.data ? <Empty>No passing build yet.</Empty> : <Table head={["Component", "Version", "Declared licence", "Origin", "Attribution"]}
            rows={sbom.data.components.map((c: any) => [c.name, c.version, c.licence_declared, <span key="o" className="small">{c.origin}</span>, <span key="a" className="small">{c.attribution}</span>])} />}
        </Card>
        <Card title="CycloneDX SBOM">{sbom.data?.document ? <Code text={sbom.data.document} label="SBOM JSON" /> : <Empty>—</Empty>}</Card>
      </div>}
      {tab === "provenance" && <div className="grid cols-2">
        <Card title="Contributors and ownership">
          {!contributors.data ? <Loading /> : <Table head={["Name", "Relationship", "Ownership", "Agreement", "Verified"]}
            rows={contributors.data.map((c) => [c.name, c.relationship, c.ownership, c.agreement_ref, c.verified ? "yes" : "no"])} />}
        </Card>
        <Card title="Assets and source origins">
          {!assets.data ? <Loading /> : <Table head={["Path", "Kind", "Licence", "Origin", "Status"]}
            rows={assets.data.map((a) => [<span key="p" className="mono small">{a.path}</span>, a.kind, a.licence, <span key="o" className="small">{a.origin}</span>, <Status key="s" value={a.status} />])} />}
        </Card>
      </div>}
    </>
  );
}
