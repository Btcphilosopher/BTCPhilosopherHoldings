"use client";

import { useState } from "react";
import { ReleasePicker } from "@/components/ReleasePicker";
import { useUser } from "@/components/Shell";
import { AuthImage, Card, Empty, Field, KV, Loading, PageHead, Status, Table } from "@/components/ui";
import { act, api, can, money, short, useApi } from "@/lib/api";

function EditionArt({ rid, edition }: { rid: string; edition: any }) {
  const user = useUser();
  const art = useApi<any[]>(`/editions/${edition.edition_id}/artworks`);
  const templates = useApi<any[]>("/packaging-templates");
  const [tpl, setTpl] = useState("");
  const forRelease = art.data?.filter((a) => String(a.release_id) === rid) ?? [];
  const mock = forRelease.find((a) => a.purpose === "mockup" && a.artifact_id);
  const print = forRelease.find((a) => a.purpose === "print");
  const make = (purpose: string) => act(() => api(`/releases/${rid}/editions/${edition.edition_id}/artwork`, {
    body: { template_id: Number(tpl || templates.data?.[0]?.id), purpose } }), `${purpose} generated`).then(art.reload);
  return (
    <div className="grid cols-2">
      <div className="boxart">
        {mock ? <AuthImage path={`/artworks/${mock.id}/svg`} alt={`${edition.edition} box mockup: front, spine and back`} /> :
          <p style={{ color: "#ccc" }}>No mockup yet.</p>}
      </div>
      <div>
        {can(user, "packaging.edit") && <div className="row" style={{ marginBottom: 10 }}>
          <Field label="Template"><select value={tpl} onChange={(e) => setTpl(e.target.value)}>
            {templates.data?.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></Field>
          <button className="btn small" onClick={() => make("mockup")}>Generate mockup</button>
          <button className="btn small secondary" onClick={() => make("print")}>Export print-ready</button>
        </div>}
        <p className="small muted">Mockups show bleed (red) and safe areas (green), a watermark and a barcode placeholder. Print-ready export is a separate,
          validated file and is refused without an allocated GTIN — the Foundry never invents barcode numbers.</p>
        {[mock, print].filter(Boolean).map((a: any) => (
          <div key={a.id} className={`banner ${a.validation.valid ? "ok" : "bad"}`}>
            <strong>{a.purpose}</strong> <Status value={a.status} /> · trim {a.validation.trim_mm?.join(" × ")} mm · with bleed {a.validation.with_bleed_mm?.join(" × ")} mm ·
            bleed {a.validation.bleed_mm} mm · safe {a.validation.safe_mm} mm
            {a.validation.errors.map((e: string, i: number) => <div key={i}>✗ {e}</div>)}
            {a.validation.warnings.map((w: string, i: number) => <div key={i} className="small">! {w}</div>)}
          </div>))}
      </div>
    </div>
  );
}

export default function Packaging() {
  const [rid, setRid] = useState("");
  const rel = useApi<any>(rid ? `/releases/${rid}` : null);
  const products = useApi<any[]>("/products");
  return (
    <>
      <PageHead title="Packaging" intro="Edition manifests list exactly what each purchasable edition contains. Physical editions get box artwork from print templates.">
        <ReleasePicker value={rid} onChange={setRid} />
      </PageHead>
      {!rel.data ? <Loading /> : rel.data.editions.length === 0 ? <Empty>This release has no editions.</Empty> : (
        <div className="grid">
          {rel.data.editions.map((e: any) => {
            const ed = products.data?.flatMap((p) => p.editions).find((x: any) => x.id === e.edition_id);
            return (
              <Card key={e.edition_id} title={`${ed?.name ?? e.edition}`} sub={`${e.kind} · SKU ${ed?.sku ?? "—"} · GTIN ${ed?.gtin ?? "not allocated"} · ${money(ed?.price)}`}>
                {e.manifest?.package ? <>
                  <KV items={[["Package", `${e.manifest.package.filename} · ${e.manifest.package.size} B · sha256 ${short(e.manifest.package.sha256, 16)}`],
                    ["Licence", `${e.manifest.licence.title} v${e.manifest.licence.version}`], ["Delivery", e.manifest.edition.delivery_method],
                    ["Update policy", JSON.stringify(e.manifest.update_policy)], ["Manifest sha256", short(e.manifest_sha256, 24)]]} />
                  <details style={{ margin: "8px 0" }}><summary>Included files ({e.manifest.includes.length})</summary>
                    <Table head={["Path", "Role", "SHA-256", "Size"]} rows={e.manifest.includes.map((f: any) => [f.path, f.role, <span key="h" className="sha">{short(f.sha256, 16)}</span>, `${f.size} B`])} />
                  </details>
                </> : <p className="muted">Manifest is created when the release candidate is frozen.</p>}
                {["boxed-key", "usb-collector"].includes(e.kind) && <EditionArt rid={rid} edition={e} />}
              </Card>);
          })}
        </div>)}
    </>
  );
}
