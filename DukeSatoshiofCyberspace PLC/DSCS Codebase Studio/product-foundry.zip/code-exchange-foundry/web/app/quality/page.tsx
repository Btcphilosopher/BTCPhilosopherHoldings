"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { ReleasePicker } from "@/components/ReleasePicker";
import { Readiness } from "@/components/Readiness";
import { Empty, Loading, PageHead } from "@/components/ui";

function Quality() {
  const params = useSearchParams();
  const [rid, setRid] = useState(params.get("release") ?? "");
  return (
    <>
      <PageHead title="Quality" intro="Release readiness with linked evidence. Scanner results show what a tool reported; they are not a guarantee of security.">
        <ReleasePicker value={rid} onChange={setRid} />
      </PageHead>
      {rid ? <Readiness key={rid} rid={rid} /> : <Empty>No releases yet.</Empty>}
    </>
  );
}

export default function Page() { return <Suspense fallback={<Loading />}><Quality /></Suspense>; }
