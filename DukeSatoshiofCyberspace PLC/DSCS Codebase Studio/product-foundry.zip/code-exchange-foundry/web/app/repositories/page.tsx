"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useUser } from "@/components/Shell";
import { Card, Code, ErrorBanner, Field, KV, Loading, PageHead, Status, Table } from "@/components/ui";
import { act, api, can, fmtDate, short, useApi } from "@/lib/api";

function Browser({ id }: { id: string }) {
  const user = useUser();
  const [ref, setRef] = useState<string>("");
  const [path, setPath] = useState<string>("");
  const [file, setFile] = useState<string | null>(null);
  const branches = useApi<any[]>(`/repositories/${id}/branches`);
  const effRef = ref || branches.data?.find((b) => b.name === "main")?.name || branches.data?.[0]?.name || "";
  const commits = useApi<any[]>(effRef ? `/repositories/${id}/commits?ref=${encodeURIComponent(effRef)}&limit=30` : null);
  const tree = useApi<any>(effRef ? `/repositories/${id}/tree?ref=${encodeURIComponent(effRef)}&path=${encodeURIComponent(path)}` : null);
  const content = useApi<any>(file ? `/repositories/${id}/file?ref=${encodeURIComponent(effRef)}&path=${encodeURIComponent(file)}` : null);
  const links = useApi<any>(`/repositories/${id}/links`);
  const [diff, setDiff] = useState<any>(null);

  return (
    <div className="grid">
      <div className="row">
        <Field label="Branch"><select value={effRef} onChange={(e) => { setRef(e.target.value); setPath(""); setFile(null); }}>
          {branches.data?.map((b) => <option key={b.name} value={b.name}>{b.name}</option>)}</select></Field>
        {links.data && <a className="btn secondary" href={links.data.editor_link}>Open in editor</a>}
        {can(user, "build.run") && effRef && <button className="btn" onClick={() =>
          act(() => api(`/repositories/${id}/builds`, { body: { ref: effRef } }), `Build queued for ${effRef}`)}>Build {effRef}</button>}
      </div>
      <div className="grid cols-2">
        <Card title="Files" sub={tree.data ? `at ${short(tree.data.commit, 12)} / ${path || "(root)"}` : undefined}>
          {path && <button className="btn small secondary" onClick={() => setPath(path.split("/").slice(0, -1).join("/"))}>.. up</button>}
          {!tree.data ? <Loading /> : (
            <ul className="tree" style={{ listStyle: "none", padding: 0 }}>
              {tree.data.entries.map((e: any) => (
                <li key={e.path}>
                  <button className="btn small secondary" style={{ margin: "2px 0" }}
                          onClick={() => e.type === "tree" ? (setPath(e.path), setFile(null)) : setFile(e.path)}>
                    {e.type === "tree" ? "📁" : "📄"} {e.name}
                  </button> {e.size != null && <span className="small muted">{e.size} B</span>}
                </li>))}
            </ul>)}
        </Card>
        <Card title={file ?? "Read-only viewer"} actions={content.data && <a className="btn small secondary" href={content.data.editor_link}>Open in editor</a>}>
          {!file ? <p className="muted">Select a file. The viewer is read-only; edit code in your editor and push commits.</p> :
            !content.data ? <Loading /> : content.data.binary ? <p>Binary file ({content.data.size} bytes)</p> :
              content.data.truncated ? <p>File too large to display.</p> : <Code text={content.data.content} label={file} />}
        </Card>
      </div>
      <Card title="Commits" sub="Every build is identified by an immutable commit id">
        {!commits.data ? <Loading /> : <Table head={["Commit", "Subject", "Author", "Date", "Build", ""]}
          rows={commits.data.map((c, i) => [<span key="s" className="sha">{short(c.sha, 12)}</span>, c.subject, c.author, fmtDate(c.authored_at),
            c.build ? <Link key="b" href={`/builds/${c.build.id}`}>#{c.build.number} <Status value={c.build.status} /></Link> : "—",
            i < commits.data!.length - 1 ? <button key="d" className="btn small secondary" onClick={async () =>
              setDiff(await api(`/repositories/${id}/diff?base=${commits.data![i + 1].sha}&head=${c.sha}`))}>Changes</button> : null])} />}
      </Card>
      {diff && <Card title={`Change summary ${short(diff.base)}..${short(diff.head)}`} actions={<button className="btn small secondary" onClick={() => setDiff(null)}>Close</button>}>
        <Table head={["File", "Added", "Removed"]} rows={diff.files.map((f: any) => [f.path,
          <span key="a" className="diff-add">+{f.added ?? "bin"}</span>, <span key="r" className="diff-del">-{f.removed ?? "bin"}</span>])} />
        <Code text={diff.patch} label="Patch" />
      </Card>}
      {links.data && <Card title="Pull requests & issues">
        {links.data.supported ? <Table head={["#", "Title", "State"]} rows={[...links.data.pull_requests, ...links.data.issues].map((x: any) =>
          [x.number, <a key="u" href={x.url}>{x.title}</a>, x.state])} /> : <p className="muted">{links.data.note}</p>}
      </Card>}
    </div>
  );
}

function Repositories() {
  const user = useUser();
  const params = useSearchParams();
  const router = useRouter();
  const id = params.get("id");
  const repos = useApi<any[]>("/repositories");
  const projects = useApi<any[]>("/projects");
  const [form, setForm] = useState({ project_id: "", provider: "local", name: "", location: "", credential_ref: "", assistant: false });
  const selected = repos.data?.find((r) => String(r.id) === id);
  return (
    <>
      <PageHead title="Repositories" intro="Connected Git repositories. Local repositories are read through a scoped adapter; hosted providers use a named credential that never leaves the server." />
      <ErrorBanner error={repos.error} />
      <div className="grid cols-3">
        <div style={{ gridColumn: "span 2" }}>
          <Card title="Connected repositories">
            {!repos.data ? <Loading /> : <Table head={["Repository", "Project", "Provider", "Default branch", "Scopes", "Connected"]}
              rows={repos.data.map((r) => [<button key="n" className="btn small secondary" onClick={() => router.push(`/repositories?id=${r.id}`)}>{r.name}</button>,
                r.project, r.provider, r.default_branch, r.scopes.join(", "), fmtDate(r.connected_at)])} />}
          </Card>
        </div>
        {can(user, "repo.connect") && <Card title="Connect repository">
          <form className="form" onSubmit={async (e) => {
            e.preventDefault();
            const r = await act(() => api(`/projects/${form.project_id}/repositories`, { body: {
              provider: form.provider, name: form.name, location: form.location, credential_ref: form.credential_ref || null,
              scopes: form.assistant ? ["read", "assistant-branches"] : ["read"] } }), "Repository connected");
            if (r) repos.reload();
          }}>
            <Field label="Project"><select value={form.project_id} onChange={(e) => setForm({ ...form, project_id: e.target.value })} required>
              <option value="">Choose…</option>{projects.data?.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
            <Field label="Provider"><select value={form.provider} onChange={(e) => setForm({ ...form, provider: e.target.value })}>
              <option value="local">Local Git</option><option value="github">GitHub</option><option value="gitlab">GitLab</option></select></Field>
            <Field label="Name"><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></Field>
            <Field label={form.provider === "local" ? "Path (inside permitted roots)" : "owner/name"}>
              <input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} required /></Field>
            {form.provider !== "local" && <Field label="Credential name (server secret FOUNDRY_SECRET_<NAME>)">
              <input value={form.credential_ref} onChange={(e) => setForm({ ...form, credential_ref: e.target.value })} /></Field>}
            <label className="small"><input type="checkbox" checked={form.assistant} onChange={(e) => setForm({ ...form, assistant: e.target.checked })} /> Allow the assistant to create review branches</label>
            <button className="btn">Connect</button>
          </form>
        </Card>}
      </div>
      {selected && <div style={{ marginTop: 16 }}>
        <Card title={selected.name} sub={`${selected.provider}: ${selected.location}`}>
          <KV items={[["Provenance", <span key="p" className="mono small">{JSON.stringify(selected.origin)}</span>],
            ["Protected branches", selected.protected_branches.join(", ")], ["Credential", selected.credential_ref ?? "none (local)"]]} />
        </Card>
        <div style={{ marginTop: 16 }}><Browser id={String(selected.id)} /></div>
      </div>}
    </>
  );
}

export default function Page() {
  return <Suspense fallback={<Loading />}><Repositories /></Suspense>;
}
