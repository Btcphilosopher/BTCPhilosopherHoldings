"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api, errorText, setSession } from "@/lib/api";

const DEMO = [
  ["pat", "Product manager"], ["dana", "Developer"], ["ravi", "Reviewer"], ["quinn", "Quality engineer"],
  ["devi", "Documentation editor"], ["lena", "Licence reviewer"], ["rowan", "Release manager"],
  ["cass", "Catalogue editor"], ["sam", "Support agent"], ["alex", "Administrator"],
];

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState("rowan@codeexchange.example");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const r = await api("/auth/login", { body: { email, password } });
      const me = { ...r.user };
      setSession(r.token, me);
      router.replace("/");
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="login-wrap">
      <main className="login" aria-labelledby="login-title">
        <h1 id="login-title" style={{ marginTop: 0 }}>Product Foundry</h1>
        <p className="muted">The Code Exchange internal workshop. Sign in with your Foundry account.</p>
        {error && <div className="banner bad" role="alert">{error}</div>}
        <form className="form" onSubmit={submit}>
          <label className="field" htmlFor="email">Email
            <input id="email" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </label>
          <label className="field" htmlFor="pw">Password
            <input id="pw" type="password" autoComplete="current-password" value={password}
                   onChange={(e) => setPassword(e.target.value)} required />
          </label>
          <button className="btn" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button>
        </form>
        <details style={{ marginTop: 16 }}>
          <summary className="small">Demonstration accounts (password <code>foundry-demo</code>)</summary>
          <ul className="small">
            {DEMO.map(([u, role]) => (
              <li key={u}>
                <button type="button" className="btn secondary small" style={{ margin: "2px 0" }}
                        onClick={() => setEmail(`${u}@codeexchange.example`)}>{u}</button> {role}
              </li>
            ))}
          </ul>
        </details>
      </main>
    </div>
  );
}
