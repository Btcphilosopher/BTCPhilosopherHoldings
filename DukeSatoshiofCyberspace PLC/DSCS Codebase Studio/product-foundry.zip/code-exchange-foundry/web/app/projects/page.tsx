"use client";

import Link from "next/link";
import { useState } from "react";
import { useUser } from "@/components/Shell";
import { Card, ErrorBanner, Field, Loading, PageHead, Status, Table } from "@/components/ui";
import { act, api, can, useApi } from "@/lib/api";

export default function Projects() {
  const user = useUser();
  const { data, error, reload } = useApi<any[]>("/projects");
  const [form, setForm] = useState({ slug: "", name: "", idea: "", intended_customers: "", problem_statement: "",
                                     supported_platforms: "linux-x86_64", tech_stack: "" });
  const set = (k: string) => (e: any) => setForm({ ...form, [k]: e.target.value });
  async function create(e: React.FormEvent) {
    e.preventDefault();
    const r = await act(() => api("/projects", { body: {
      ...form, supported_platforms: form.supported_platforms.split(",").map((s) => s.trim()).filter(Boolean),
      tech_stack: form.tech_stack.split(",").map((s) => s.trim()).filter(Boolean), status: "idea" } }), "Project created");
    if (r) { reload(); setForm({ ...form, slug: "", name: "" }); }
  }
  return (
    <>
      <PageHead title="Projects" intro="Development projects. Each can produce one or more commercial products and purchasable editions." />
      <ErrorBanner error={error} />
      <div className="grid cols-3">
        <div style={{ gridColumn: "span 2" }}>
          <Card title="All projects">
            {!data ? <Loading /> : <Table head={["Project", "Status", "Platforms (claimed)", "Stack", "Licence intent"]}
              rows={data.map((p) => [<Link key="l" href={`/projects/${p.id}`}><strong>{p.name}</strong></Link>,
                <Status key="s" value={p.status} />, p.supported_platforms.join(", "), p.tech_stack.join(", "),
                p.intended_licence || "—"])} />}
          </Card>
        </div>
        {can(user, "project.create") && (
          <Card title="New project">
            <form className="form" onSubmit={create}>
              <Field label="Name"><input value={form.name} onChange={set("name")} required /></Field>
              <Field label="Slug (lowercase, hyphens)"><input value={form.slug} onChange={set("slug")} pattern="[a-z0-9][a-z0-9-]+" required /></Field>
              <Field label="Product idea"><textarea value={form.idea} onChange={set("idea")} /></Field>
              <Field label="Intended customers"><input value={form.intended_customers} onChange={set("intended_customers")} /></Field>
              <Field label="Problem statement"><textarea value={form.problem_statement} onChange={set("problem_statement")} /></Field>
              <Field label="Supported platforms (comma separated)"><input value={form.supported_platforms} onChange={set("supported_platforms")} /></Field>
              <Field label="Technical stack"><input value={form.tech_stack} onChange={set("tech_stack")} /></Field>
              <button className="btn">Create project</button>
            </form>
          </Card>
        )}
      </div>
    </>
  );
}
