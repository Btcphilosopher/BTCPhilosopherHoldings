"use client";

import Link from "next/link";
import { use, useState } from "react";
import { useUser } from "@/components/Shell";
import { Card, ErrorBanner, Field, KV, Loading, PageHead, Status, Table, Tabs } from "@/components/ui";
import { act, api, can, fmtDate, money, useApi } from "@/lib/api";

const CATS = ["workflow", "environment", "functional", "performance", "accessibility", "installation", "data", "support"];

export default function ProjectPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const user = useUser();
  const [tab, setTab] = useState("overview");
  const p = useApi<any>(`/projects/${id}`);
  const reqs = useApi<any[]>(`/projects/${id}/requirements`);
  const tasks = useApi<any[]>(`/projects/${id}/tasks`);
  const costs = useApi<any[]>(`/projects/${id}/costs`);
  const [rq, setRq] = useState({ key: "", category: "functional", title: "", acceptance_criteria: "" });

  if (!p.data) return <><ErrorBanner error={p.error} /><Loading /></>;
  const proj = p.data;
  return (
    <>
      <PageHead title={proj.name} intro={proj.idea}>
        <Status value={proj.status} />
        <Link className="btn secondary" href={`/development?project=${id}`}>Development</Link>
      </PageHead>
      <Tabs value={tab} onChange={setTab} tabs={[{ id: "overview", label: "Overview" }, { id: "requirements", label: "Requirements" },
        { id: "tasks", label: "Tasks" }, { id: "products", label: "Products & editions" }, { id: "releases", label: "Release history" },
        { id: "costs", label: "Team & costs" }]} />
      {tab === "overview" && (
        <div className="grid cols-2">
          <Card title="Product intent">
            <KV items={[["Intended customers", proj.intended_customers], ["Problem", proj.problem_statement],
              ["Platforms claimed", proj.supported_platforms.join(", ")], ["Technical stack", proj.tech_stack.join(", ")],
              ["Dependencies", proj.dependencies_note], ["Intended licence", proj.intended_licence],
              ["Source distribution", proj.source_distribution_model]]} />
          </Card>
          <Card title="Ownership">
            <KV items={[["Product owner", proj.owner_name], ["Support owner", proj.support_owner_name],
              ["Repositories", proj.repositories.map((r: any) => <div key={r.id}><Link href={`/repositories?id=${r.id}`}>{r.name}</Link>{" "}
                <span className="muted small">{r.provider}</span></div>)],
              ["Members", proj.members.map((m: any) => <div key={m.user.id}>{m.user.name} <span className="muted small">{m.responsibility}</span></div>)]]} />
            <p className="small muted" style={{ marginTop: 12 }}>
              A <strong>project</strong> is the development effort; a <strong>product</strong> is what customers recognise; an
              <strong> edition</strong> is a purchasable configuration with its own contents and licence; a <strong>release</strong> is
              an immutable version built from one commit.
            </p>
          </Card>
        </div>
      )}
      {tab === "requirements" && (
        <div className="grid cols-3">
          <div style={{ gridColumn: "span 2" }}>
            <Card title="Requirements and acceptance criteria"
                  sub="Proposed → implemented → tested (only from evidence) → accepted (by a reviewer). Finishing tasks never marks a requirement tested.">
              {!reqs.data ? <Loading /> : <Table head={["Key", "Requirement", "Status", "Evidence", "Tasks", ""]}
                rows={reqs.data.map((r) => [<strong key="k">{r.key}</strong>,
                  <div key="t">{r.title}<div className="small muted">{r.category} · {r.acceptance_criteria}</div></div>,
                  <Status key="s" value={r.status} />,
                  <ul key="e" className="evidence">{r.evidence.slice(0, 3).map((e: any) => (
                    <li key={e.id}><Status value={e.result} /> {e.kind}: <span className="small">{e.reference}</span></li>))}</ul>,
                  <span key="tk" className="small">{r.tasks.length} task(s){r.tasks_done ? " · all done" : ""}</span>,
                  <div key="a" className="row">
                    {r.status === "proposed" && can(user, "task.edit") &&
                      <button className="btn small secondary" onClick={() => act(() => api(`/requirements/${r.id}`, { method: "PATCH", body: { status: "implemented" } }), "Marked implemented").then(reqs.reload)}>Implemented</button>}
                    {r.status === "tested" && can(user, "requirement.accept") &&
                      <button className="btn small" onClick={() => act(() => api(`/requirements/${r.id}/accept`, { body: {} }), "Accepted").then(reqs.reload)}>Accept</button>}
                    {can(user, "evidence.record") && ["implemented", "tested", "accepted"].includes(r.status) &&
                      <button className="btn small secondary" onClick={() => {
                        const ref = prompt("Evidence reference (e.g. QA record)"); if (!ref) return;
                        const ok = confirm("Did the check pass? OK = passed, Cancel = failed");
                        act(() => api(`/requirements/${r.id}/evidence`, { body: { kind: "manual", reference: ref, result: ok ? "passed" : "failed" } }), "Evidence recorded").then(reqs.reload);
                      }}>Record evidence</button>}
                  </div>])} />}
            </Card>
          </div>
          {can(user, "requirement.edit") && <Card title="Add requirement">
            <form className="form" onSubmit={async (e) => {
              e.preventDefault();
              if (await act(() => api(`/projects/${id}/requirements`, { body: rq }), "Requirement added")) { reqs.reload(); setRq({ ...rq, key: "", title: "", acceptance_criteria: "" }); }
            }}>
              <Field label="Key (e.g. REQ-010)"><input value={rq.key} onChange={(e) => setRq({ ...rq, key: e.target.value })} required /></Field>
              <Field label="Category"><select value={rq.category} onChange={(e) => setRq({ ...rq, category: e.target.value })}>
                {CATS.map((c) => <option key={c}>{c}</option>)}</select></Field>
              <Field label="Title"><input value={rq.title} onChange={(e) => setRq({ ...rq, title: e.target.value })} required /></Field>
              <Field label="Acceptance criteria"><textarea value={rq.acceptance_criteria} onChange={(e) => setRq({ ...rq, acceptance_criteria: e.target.value })} /></Field>
              <button className="btn">Add</button>
            </form>
          </Card>}
        </div>
      )}
      {tab === "tasks" && (
        <Card title="Tasks">
          {!tasks.data ? <Loading /> : <Table head={["Task", "Assignee", "Status", "Branch / link", ""]}
            rows={tasks.data.map((t) => [t.title + (t.proposed_by_assistant ? " (assistant proposal)" : ""), t.assignee_name ?? "—",
              <Status key="s" value={t.status} />, t.external_url ? <a key="u" href={t.external_url}>{t.external_url}</a> : (t.branch ?? "—"),
              can(user, "task.edit") ? <select key="c" aria-label={`Status of ${t.title}`} value={t.status}
                onChange={(e) => act(() => api(`/tasks/${t.id}`, { method: "PATCH", body: { status: e.target.value } })).then(tasks.reload)}>
                {["todo", "in_progress", "review", "done"].map((s) => <option key={s}>{s}</option>)}</select> : null])} />}
        </Card>
      )}
      {tab === "products" && (
        <div className="grid">
          {proj.products.map((pr: any) => (
            <Card key={pr.id} title={pr.name} sub={pr.tagline}>
              <Table head={["Edition", "Kind", "SKU / GTIN", "Price", "Delivery", "Update policy"]}
                rows={pr.editions.map((e: any) => [e.name, e.kind, <span key="s" className="mono">{e.sku} / {e.gtin ?? "no GTIN allocated"}</span>,
                  money(e.price), e.delivery_method, <span key="u" className="small">{JSON.stringify(e.update_policy)}</span>])} />
            </Card>
          ))}
          {proj.products.length === 0 && <Card><p className="muted">No commercial products defined yet.</p></Card>}
        </div>
      )}
      {tab === "releases" && (
        <Card title="Release history">
          <Table head={["Version", "Status", "Commit", "Created", "Published"]}
            rows={proj.releases.map((r: any) => [<Link key="v" href={`/releases/${r.id}`}>{r.version}</Link>, <Status key="s" value={r.status} />,
              <span key="c" className="sha">{r.commit_sha?.slice(0, 12)}</span>, fmtDate(r.created_at), fmtDate(r.published_at)])} />
        </Card>
      )}
      {tab === "costs" && (
        <div className="grid cols-2">
          <Card title="Development costs" sub={`Estimated ${proj.cost_totals.estimate ?? 0} · Recorded ${proj.cost_totals.recorded ?? 0}`}>
            {!costs.data ? <Loading /> : <Table head={["Kind", "Category", "Amount", "Description"]}
              rows={costs.data.map((c) => [<Status key="k" value={c.kind === "estimate" ? "proposed" : "done"} label={c.kind} />, c.category,
                `${c.currency} ${c.amount}`, c.description])} />}
            {can(user, "cost.edit") && <form className="row" style={{ marginTop: 12 }} onSubmit={async (e: any) => {
              e.preventDefault();
              const f = new FormData(e.target);
              await act(() => api(`/projects/${id}/costs`, { body: { kind: f.get("kind"), amount: Number(f.get("amount")), description: f.get("description") } }), "Cost recorded");
              costs.reload(); p.reload();
            }}>
              <select name="kind" aria-label="Cost kind"><option>estimate</option><option>recorded</option></select>
              <input name="amount" type="number" step="0.01" aria-label="Amount" placeholder="Amount" required />
              <input name="description" aria-label="Description" placeholder="Description" />
              <button className="btn small">Add</button>
            </form>}
          </Card>
          <Card title="Team">
            {proj.members.map((m: any) => <div key={m.user.id}>{m.user.name} — <span className="muted">{m.responsibility}</span></div>)}
          </Card>
        </div>
      )}
    </>
  );
}
