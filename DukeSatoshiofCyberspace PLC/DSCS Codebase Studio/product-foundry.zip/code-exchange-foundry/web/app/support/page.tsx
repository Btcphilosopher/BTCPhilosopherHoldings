"use client";

import { useState } from "react";
import { useUser } from "@/components/Shell";
import { Card, Field, KV, Loading, PageHead, Status, Table, Tabs } from "@/components/ui";
import { act, api, can, fmtDate, useApi } from "@/lib/api";

function Issue({ issue, onChange }: { issue: any; onChange: () => void }) {
  const user = useUser();
  const releases = useApi<any[]>("/releases");
  const users = useApi<any[]>("/users");
  const [contact, setContact] = useState<any>(null);
  const [f, setF] = useState({ severity_reviewed: issue.severity_reviewed ?? "", owner_id: issue.owner_id ?? "", status: issue.status,
                               fix_release_id: issue.fix_release_id ?? "", customer_note: issue.customer_note ?? "" });
  return (
    <Card title={`${issue.external_ref}: ${issue.title}`} sub={`${issue.product} · reported on ${issue.reported_version || "unknown version"} · ${fmtDate(issue.created_at)}`}>
      <KV items={[["Reproduction steps (redacted)", <span key="r" style={{ whiteSpace: "pre-wrap" }}>{issue.reproduction_steps}</span>],
        ["Redactions", issue.redactions.join(", ") || "none"], ["Reported severity", issue.severity_reported], ["Customer", <span key="c" className="mono small">{issue.customer_ref}</span>]]} />
      {can(user, "support.private") && <div style={{ margin: "8px 0" }}>
        {contact ? <div className="banner info">Contact: {contact.name} &lt;{contact.email}&gt; (access audited)</div> :
          <button className="btn small secondary" onClick={async () => setContact(await api(`/support/issues/${issue.id}/contact`))}>Reveal contact (audited)</button>}
      </div>}
      {can(user, "support.triage") && <form className="form" style={{ marginTop: 10 }} onSubmit={async (e) => { e.preventDefault();
        const body: any = { ...f, owner_id: f.owner_id ? Number(f.owner_id) : null, fix_release_id: f.fix_release_id ? Number(f.fix_release_id) : null,
                            severity_reviewed: f.severity_reviewed || null };
        Object.keys(body).forEach((k) => body[k] === null && delete body[k]);
        if (await act(() => api(`/support/issues/${issue.id}`, { method: "PATCH", body }), "Issue updated")) onChange(); }}>
        <div className="grid cols-2">
          <Field label="Reviewed severity"><select value={f.severity_reviewed} onChange={(e) => setF({ ...f, severity_reviewed: e.target.value })}>
            <option value="">Not reviewed</option>{["critical", "high", "medium", "low"].map((s) => <option key={s}>{s}</option>)}</select></Field>
          <Field label="Owner"><select value={f.owner_id} onChange={(e) => setF({ ...f, owner_id: e.target.value })}>
            <option value="">Unassigned</option>{users.data?.filter((u) => !u.is_service).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</select></Field>
          <Field label="Status"><select value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })}>
            {["new", "triaged", "in-progress", "fixed", "closed"].map((s) => <option key={s}>{s}</option>)}</select></Field>
          <Field label="Fix version"><select value={f.fix_release_id} onChange={(e) => setF({ ...f, fix_release_id: e.target.value })}>
            <option value="">—</option>{releases.data?.filter((r) => r.product_id === issue.product_id).map((r) => <option key={r.id} value={r.id}>{r.version} ({r.status})</option>)}</select></Field>
        </div>
        <Field label="Customer-facing release note"><input value={f.customer_note} onChange={(e) => setF({ ...f, customer_note: e.target.value })} /></Field>
        <button className="btn">Save</button>
      </form>}
    </Card>
  );
}

export default function Support() {
  const user = useUser();
  const [tab, setTab] = useState("issues");
  const issues = useApi<any[]>("/support/issues");
  const ents = useApi<any[]>("/entitlements");
  const adv = useApi<any[]>("/advisories");
  const [sel, setSel] = useState<number | null>(null);
  const issue = issues.data?.find((i) => i.id === sel);
  return (
    <>
      <PageHead title="Support" intro="Customer reports linked to products and releases. Contact details are kept out of engineering views; update eligibility follows each purchased entitlement.">
        {can(user, "support.import") && <>
          <button className="btn secondary" onClick={() => act(() => api("/support/import", { body: {} }), "Import queued").then(() => setTimeout(issues.reload, 1500))}>Import tickets</button>
          <button className="btn secondary" onClick={() => act(() => api("/entitlements/sync", { body: {} }), "Entitlement sync queued").then(() => setTimeout(ents.reload, 1500))}>Sync entitlements</button>
        </>}
      </PageHead>
      <Tabs value={tab} onChange={setTab} tabs={[{ id: "issues", label: "Issues" }, { id: "entitlements", label: "Entitlements" }, { id: "advisories", label: "Advisories" }]} />
      {tab === "issues" && <div className="grid cols-2">
        <Card title="Issues">
          {!issues.data ? <Loading /> : <Table head={["Ref", "Title", "Version", "Severity", "Status", "Fix", ""]}
            rows={issues.data.map((i) => [i.external_ref, i.title, i.reported_version, <Status key="v" value={i.severity_reviewed ? "triaged" : "unreviewed"} label={i.severity_reviewed ?? "unreviewed"} />,
              <Status key="s" value={i.status} />, i.fix_version ?? "—", <button key="o" className="btn small secondary" onClick={() => setSel(i.id)}>Open</button>])} />}
        </Card>
        {issue && <Issue key={issue.id} issue={issue} onChange={issues.reload} />}
      </div>}
      {tab === "entitlements" && <Card title="Entitlements" sub="Imported from the storefront. Eligible versions are computed from the purchased edition and its update policy — never every future edition.">
        {!ents.data ? <Loading /> : <Table head={["Entitlement", "Customer", "Edition", "Purchased", "Policy", "Support until", "Eligible versions"]}
          rows={ents.data.map((e) => [e.external_id, <span key="c" className="mono small">{e.customer_ref}</span>, e.edition, fmtDate(e.purchased_at),
            <span key="p" className="small">{JSON.stringify(e.update_policy)}</span>, e.support_until, e.eligible_versions.join(", ") || "none"])} />}
      </Card>}
      {tab === "advisories" && <Card title="Customer advisories">
        {!adv.data ? <Loading /> : <Table head={["Kind", "Title", "Published", "Created"]}
          rows={adv.data.map((a) => [<Status key="k" value={a.kind === "withdrawal" ? "withdrawn" : "info"} label={a.kind} />,
            <details key="t"><summary>{a.title}</summary><p className="small" style={{ whiteSpace: "pre-wrap" }}>{a.body}</p></details>,
            a.published ? "yes" : "no", fmtDate(a.created_at)])} />}
      </Card>}
    </>
  );
}
