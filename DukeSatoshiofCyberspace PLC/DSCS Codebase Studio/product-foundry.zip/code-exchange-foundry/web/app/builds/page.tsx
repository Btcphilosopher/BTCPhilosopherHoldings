"use client";

import Link from "next/link";
import { Card, ErrorBanner, Loading, PageHead, Status, Table } from "@/components/ui";
import { fmtDate, short, useApi } from "@/lib/api";

export default function Builds() {
  const { data, error } = useApi<any[]>("/builds?limit=200", 5000);
  return (
    <>
      <PageHead title="Builds" intro="Every build runs a version-controlled pipeline in a disposable, network-isolated sandbox. Failed results are kept; retries create new builds." />
      <ErrorBanner error={error} />
      <Card>
        {!data ? <Loading /> : <Table head={["Build", "Project", "Commit", "Ref", "Status", "Tests", "Trigger", "Started", "Duration"]}
          rows={data.map((b) => [<Link key="l" href={`/builds/${b.id}`}><strong>#{b.number}</strong></Link>, b.project,
            <span key="c"><span className="sha">{short(b.commit_sha, 12)}</span><div className="small">{b.commit_message}</div></span>,
            b.ref || "—", <Status key="s" value={b.status} />,
            b.summary?.tests ? Object.entries(b.summary.tests).map(([k, v]) => `${v} ${k}`).join(", ") : "—",
            b.trigger + (b.retry_of_id ? ` (retry of #${b.retry_of_id})` : ""), fmtDate(b.started_at),
            b.resources?.wall_ms ? `${(b.resources.wall_ms / 1000).toFixed(1)} s` : "—"])} />}
      </Card>
    </>
  );
}
