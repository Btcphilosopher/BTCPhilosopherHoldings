"use client";

import Link from "next/link";
import { use, useEffect, useState } from "react";
import { useUser } from "@/components/Shell";
import { Card, ErrorBanner, KV, Loading, Log, PageHead, Status, Table, Tabs, download } from "@/components/ui";
import { act, api, can, fmtDate, useApi } from "@/lib/api";

export default function BuildPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const user = useUser();
  const b = useApi<any>(`/builds/${id}`, 2500);
  const [stage, setStage] = useState<number | null>(null);
  const [log, setLog] = useState<string>("");
  const [tab, setTab] = useState("stages");
  const build = b.data;
  const sel = build?.stages.find((s: any) => s.id === stage) ?? build?.stages.find((s: any) => s.status === "failed") ?? build?.stages[0];

  useEffect(() => {
    if (!sel) return;
    if (sel.log_key) api<string>(`/builds/${id}/stages/${sel.id}/log`).then(setLog).catch(() => setLog(sel.log_tail));
    else setLog(sel.log_tail || "(no output yet)");
  }, [sel?.id, sel?.log_key, sel?.log_tail, id]);

  if (!build) return <><ErrorBanner error={b.error} /><Loading /></>;
  const failedTests = build.tests.filter((t: any) => t.status !== "passed");
  return (
    <>
      <PageHead title={`Build #${build.number}`} intro={build.commit_message}>
        <Status value={build.status} />
        {can(user, "build.cancel") && ["queued", "running"].includes(build.status) &&
          <button className="btn danger" onClick={() => act(() => api(`/builds/${id}/cancel`, { body: {} }), "Cancellation requested").then(b.reload)}>Cancel</button>}
        {can(user, "build.run") && !["queued", "running"].includes(build.status) &&
          <button className="btn secondary" onClick={() => act(() => api(`/builds/${id}/retry`, { body: {} }), "New build of the same commit queued")}>Rebuild same commit</button>}
      </PageHead>
      <div className="grid cols-2">
        <Card title="Inputs">
          <KV items={[["Commit", <span key="c" className="mono">{build.commit_sha}</span>], ["Ref", build.ref || "—"],
            ["Pipeline", <span key="p" className="mono small">.foundry/pipeline.toml sha256 {build.pipeline_sha256?.slice(0, 16)}…</span>],
            ["Lockfiles", Object.entries(build.lockfiles || {}).map(([k, v]) => <div key={k} className="mono small">{k}: {String(v).slice(0, 16)}…</div>)],
            ["Triggered", `${build.trigger} by ${build.triggered_by_name ?? "system"} · ${fmtDate(build.created_at)}`],
            ["Retry of", build.retry_of_id ? <Link key="r" href={`/builds/${build.retry_of_id}`}>build {build.retry_of_id}</Link> : "—"]]} />
        </Card>
        <Card title="Worker environment">
          <KV items={Object.entries(build.worker_env || {}).map(([k, v]) => [k.replace(/_/g, " "), String(v)])} />
        </Card>
      </div>
      <div style={{ marginTop: 16 }}>
        <Tabs value={tab} onChange={setTab} tabs={[{ id: "stages", label: "Stages & logs" }, { id: "tests", label: `Tests (${build.tests.length})` },
          { id: "artifacts", label: `Artefacts (${build.artifacts.length})` }, { id: "security", label: "Security & SBOM" }]} />
        {tab === "stages" && (
          <Card>
            <div className="stages" role="group" aria-label="Pipeline stages">
              {build.stages.map((s: any) => (
                <button key={s.id} className={`stage ${s.status}`} aria-pressed={sel?.id === s.id} onClick={() => setStage(s.id)}>
                  {s.name} · {s.status}{s.exit_code != null ? ` (${s.exit_code})` : ""}
                </button>))}
            </div>
            {sel && <div style={{ marginTop: 12 }}>
              <p className="small muted">{sel.kind === "builtin" ? "Trusted builtin run by the worker" : `$ ${sel.command}`} · network {sel.network} ·
                attempts {sel.attempts} · {sel.duration_ms != null ? `${sel.duration_ms} ms` : "—"} · {JSON.stringify(sel.resources)}</p>
              <Log text={log} />
            </div>}
          </Card>)}
        {tab === "tests" && (
          <Card sub={failedTests.length ? `${failedTests.length} failing` : "All tests passed"}>
            <Table head={["Test", "Status", "Requirements", "Time", "Message"]}
              rows={[...failedTests, ...build.tests.filter((t: any) => t.status === "passed")].map((t: any) => [
                <span key="n" className="mono small">{t.suite}.{t.name}</span>, <Status key="s" value={t.status} />,
                (t.requirement_keys || []).join(", "), `${t.duration_ms} ms`,
                t.message ? <pre key="m" className="code" style={{ maxHeight: 160 }}>{t.message.split("\n").slice(-6).join("\n")}</pre> : ""])} />
          </Card>)}
        {tab === "artifacts" && (
          <Card sub="Content-addressed outputs; checksums are verified on every download">
            <Table head={["Role", "File", "SHA-256", "Size", ""]}
              rows={build.artifacts.map((a: any) => [a.role, a.filename, <span key="h" className="sha">{a.sha256}</span>, `${a.size} B`,
                <button key="d" className="btn small secondary" onClick={() => download(`/artifacts/${a.id}/download`, a.filename)}>Download</button>])} />
          </Card>)}
        {tab === "security" && (
          <div className="grid cols-2">
            <Card title="Scanner runs" sub="Findings are what each tool reported at that time. No findings is not a guarantee of security.">
              {build.scans.map((s: any) => (
                <div key={s.id} style={{ marginBottom: 12 }}>
                  <strong>{s.tool} {s.tool_version}</strong> <span className="small muted">db {s.database_version} · {fmtDate(s.scanned_at)}</span>
                  <div className="small">{s.finding_count} finding(s) · scope: {s.scope}</div>
                  <div className="small muted">{s.limitations}</div>
                  {s.findings.map((f: any) => <div key={f.id} className="small"><Status value={f.severity === "high" ? "failed" : "warning"} label={f.severity} /> {f.identifier} {f.component}: {f.title}</div>)}
                </div>))}
            </Card>
            <Card title="Software bill of materials" sub="Generated from the dependencies actually installed for this build">
              <Table head={["Component", "Version", "Licence (declared)", "Source"]}
                rows={build.sbom.map((c: any) => [c.name, c.version, c.licence_declared, <span key="s" className="small">{c.licence_source}</span>])} />
            </Card>
          </div>)}
      </div>
    </>
  );
}
