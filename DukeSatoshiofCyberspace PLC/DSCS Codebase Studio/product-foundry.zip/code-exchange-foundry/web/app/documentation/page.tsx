"use client";

import { useState } from "react";
import { ReleasePicker } from "@/components/ReleasePicker";
import { useUser } from "@/components/Shell";
import { AuthFrame, Card, Empty, Field, Loading, PageHead, Status, Table, Tabs, download } from "@/components/ui";
import { act, api, can, fmtDate, useApi } from "@/lib/api";

function DocEditor({ id, onChange }: { id: number; onChange: () => void }) {
  const user = useUser();
  const d = useApi<any>(`/documents/${id}`, 4000);
  const [body, setBody] = useState<string | null>(null);
  const [view, setView] = useState("preview");
  if (!d.data) return <Loading />;
  const doc = d.data;
  const refresh = () => { d.reload(); onChange(); setBody(null); };
  return (
    <Card title={`${doc.title} · revision ${doc.revision}`} sub={`${doc.origin} · ${doc.status}${doc.locked ? " · locked by release candidate" : ""}`}
          actions={<div className="row">
            <button className="btn small secondary" onClick={() => download(`/documents/${id}/pdf`, `${doc.kind}.pdf`)}>PDF</button>
            {doc.status === "draft" && can(user, "docs.edit") && <button className="btn small" onClick={() => act(() => api(`/documents/${id}/submit`, { body: {} }), "Submitted for review").then(refresh)}>Submit for review</button>}
            {doc.status === "in-review" && can(user, "docs.approve") && <button className="btn small" onClick={() => act(() => api(`/documents/${id}/approve`, { body: {} }), "Approved").then(refresh)}>Approve</button>}
          </div>}>
      {(doc.flags || []).length > 0 && <div className="banner warn">
        <strong>Statements needing attention</strong>
        <ul style={{ margin: "6px 0 0" }}>{doc.flags.map((f: any, i: number) => (
          <li key={i}><Status value={f.resolved ? "cleared" : f.severity} /> {f.text}{f.resolved ? ` — resolved: ${f.resolution}` :
            can(user, "docs.approve") && !doc.locked ? <> <button className="btn small secondary" onClick={() => {
              const note = prompt("How was this statement verified or corrected?"); if (note) act(() => api(`/documents/${id}/flags/${i}/resolve`, { body: { note } }), "Flag resolved").then(refresh);
            }}>Resolve</button></> : null}</li>))}</ul>
      </div>}
      {doc.body.includes("```console-test") && <div className="banner info">
        Executable examples: {doc.example_results?.length ? doc.example_results.map((x: any, i: number) => <span key={i}> <Status value={x.result} /> <code>{x.command}</code></span>) : "not yet checked"}
        {!doc.locked && can(user, "docs.edit") && <> <button className="btn small secondary" onClick={() => act(() => api(`/documents/${id}/check-examples`, { body: {} }), "Example check queued (runs in the build sandbox)")}>Run examples</button></>}
      </div>}
      <Tabs value={view} onChange={setView} tabs={[{ id: "preview", label: "Web preview" }, { id: "source", label: "Source" }]} />
      {view === "preview" ? <AuthFrame path={`/documents/${id}/preview`} title={`${doc.title} preview`} /> : (
        <form className="form" onSubmit={async (e) => { e.preventDefault();
          if (await act(() => api(`/documents/${id}`, { method: "PUT", body: { body: body ?? doc.body } }), "New revision saved")) refresh(); }}>
          <textarea className="code" aria-label="Document source (Markdown)" value={body ?? doc.body} onChange={(e) => setBody(e.target.value)} readOnly={doc.locked || !can(user, "docs.edit")} />
          {!doc.locked && can(user, "docs.edit") && <button className="btn">Save as new revision</button>}
        </form>)}
    </Card>
  );
}

export default function Documentation() {
  const user = useUser();
  const [rid, setRid] = useState("");
  const [tab, setTab] = useState("release");
  const [sel, setSel] = useState<number | null>(null);
  const docs = useApi<any[]>(rid ? `/releases/${rid}/documents` : null);
  const templates = useApi<any[]>("/doc-templates");
  const [tpl, setTpl] = useState<any>(null);
  return (
    <>
      <PageHead title="Documentation" intro="Versioned templates produce release-bound documents. Unsupported statements are flagged; executable examples run against the built application.">
        <ReleasePicker value={rid} onChange={(v) => { setRid(v); setSel(null); }} />
      </PageHead>
      <Tabs value={tab} onChange={setTab} tabs={[{ id: "release", label: "Release documents" }, { id: "templates", label: "Templates" }]} />
      {tab === "release" && <div className="grid cols-3">
        <Card title="Documents" actions={can(user, "docs.edit") && rid ? <button className="btn small" onClick={() =>
          act(() => api(`/releases/${rid}/documents/generate`, { body: {} }), "Documents generated from current templates").then(docs.reload)}>Generate</button> : null}>
          {!docs.data ? <Loading /> : docs.data.length === 0 ? <Empty>No documents for this release.</Empty> :
            <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>{docs.data.map((d) => (
              <li key={d.id} style={{ padding: "4px 0" }}>
                <button className={`btn small ${sel === d.id ? "" : "secondary"}`} onClick={() => setSel(d.id)}>{d.title}</button>{" "}
                <Status value={d.status} /> <span className="small muted">r{d.revision}{d.flags?.some((f: any) => !f.resolved) ? " · flagged" : ""}</span>
              </li>))}</ul>}
        </Card>
        <div style={{ gridColumn: "span 2" }}>{sel ? <DocEditor key={sel} id={sel} onChange={docs.reload} /> : <Empty>Select a document.</Empty>}</div>
      </div>}
      {tab === "templates" && <div className="grid cols-2">
        <Card title="Templates (latest version first)">
          {!templates.data ? <Loading /> : <Table head={["Kind", "Version", "Title", "Created", ""]}
            rows={templates.data.map((t) => [t.kind, `v${t.version}`, t.title, fmtDate(t.created_at),
              <button key="e" className="btn small secondary" onClick={() => setTpl({ ...t })}>Open</button>])} />}
        </Card>
        {tpl && <Card title={`${tpl.kind} template v${tpl.version}`} sub="Saving creates a new template version; existing documents keep the version they were generated from.">
          <form className="form" onSubmit={async (e) => { e.preventDefault();
            if (await act(() => api("/doc-templates", { body: { kind: tpl.kind, title: tpl.title, body: tpl.body } }), "Template version saved")) { templates.reload(); setTpl(null); } }}>
            <Field label="Title"><input value={tpl.title} onChange={(e) => setTpl({ ...tpl, title: e.target.value })} /></Field>
            <textarea className="code" aria-label="Template body" value={tpl.body} onChange={(e) => setTpl({ ...tpl, body: e.target.value })} readOnly={!can(user, "docs.template")} />
            {can(user, "docs.template") && <button className="btn">Save new version</button>}
          </form>
        </Card>}
      </div>}
    </>
  );
}
