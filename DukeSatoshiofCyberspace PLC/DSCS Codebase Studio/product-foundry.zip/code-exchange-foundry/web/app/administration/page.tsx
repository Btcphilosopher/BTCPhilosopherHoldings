"use client";

import { useState } from "react";
import { useUser } from "@/components/Shell";
import { Card, Code, Field, KV, Loading, PageHead, Status, Table, Tabs } from "@/components/ui";
import { act, api, can, fmtDate, useApi } from "@/lib/api";

export default function Administration() {
  const user = useUser();
  const [tab, setTab] = useState("users");
  const users = useApi<any[]>("/users");
  const roles = useApi<any>("/roles");
  const settings = useApi<any>("/settings");
  const jobs = useApi<any[]>("/jobs?limit=100", 5000);
  const auditOk = can(user, "audit.read");
  const audit = useApi<any[]>(auditOk ? "/audit?limit=200" : null);
  const [verify, setVerify] = useState<any>(null);
  const [nu, setNu] = useState({ email: "", name: "", password: "", roles: [] as string[] });
  return (
    <>
      <PageHead title="Administration" intro="People and roles, separation of duties, background jobs and the tamper-evident audit trail. Administrators manage access; they cannot approve releases, listings or licences." />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: "users", label: "Users & roles" }, { id: "permissions", label: "Permissions" },
        { id: "jobs", label: "Jobs & workers" }, { id: "audit", label: "Audit trail" }, { id: "settings", label: "Settings" }]} />
      {tab === "users" && <div className="grid cols-3">
        <div style={{ gridColumn: "span 2" }}><Card>
          {!users.data ? <Loading /> : <Table head={["Name", "Email", "Roles", "Active"]}
            rows={users.data.map((u) => [u.name + (u.is_service ? " (service)" : ""), u.email,
              can(user, "admin.users") && !u.is_service ? <select key="r" multiple aria-label={`Roles for ${u.name}`} value={u.roles} size={3}
                onChange={(e) => act(() => api(`/users/${u.id}`, { method: "PATCH", body: { roles: Array.from(e.target.selectedOptions).map((o) => o.value) } }), "Roles updated").then(users.reload)}>
                {roles.data && Object.entries(roles.data.roles).filter(([k]) => k !== "assistant").map(([k, v]: any) => <option key={k} value={k}>{v}</option>)}</select>
                : u.roles.join(", "),
              <Status key="a" value={u.active ? "active" : "cancelled"} label={u.active ? "active" : "inactive"} />])} />}
        </Card></div>
        {can(user, "admin.users") && <Card title="Add user">
          <form className="form" onSubmit={async (e) => { e.preventDefault(); if (await act(() => api("/users", { body: nu }), "User created")) users.reload(); }}>
            <Field label="Name"><input value={nu.name} onChange={(e) => setNu({ ...nu, name: e.target.value })} required /></Field>
            <Field label="Email"><input type="email" value={nu.email} onChange={(e) => setNu({ ...nu, email: e.target.value })} required /></Field>
            <Field label="Initial password"><input type="password" value={nu.password} onChange={(e) => setNu({ ...nu, password: e.target.value })} required minLength={10} /></Field>
            <Field label="Roles"><select multiple value={nu.roles} onChange={(e) => setNu({ ...nu, roles: Array.from(e.target.selectedOptions).map((o) => o.value) })}>
              {roles.data && Object.entries(roles.data.roles).filter(([k]) => k !== "assistant").map(([k, v]: any) => <option key={k} value={k}>{v}</option>)}</select></Field>
            <button className="btn">Create</button>
          </form>
        </Card>}
      </div>}
      {tab === "permissions" && <Card title="Backend-enforced permissions" sub="The interface hides actions you cannot take, but every rule is enforced by the API.">
        {!roles.data ? <Loading /> : <Table head={["Permission", "Roles"]} rows={Object.entries(roles.data.permissions).map(([p, r]: any) => [<code key="p">{p}</code>, r.join(", ")])} />}
      </Card>}
      {tab === "jobs" && <Card title="Durable jobs" sub="Builds, documentation checks, publications and imports run in workers, never in the API server.">
        {!jobs.data ? <Loading /> : <Table head={["Job", "Kind", "Status", "Attempts", "Worker", "Created", "Error", ""]}
          rows={jobs.data.map((j) => [j.id, j.kind, <Status key="s" value={j.status} />, `${j.attempts}/${j.max_attempts}`, j.locked_by ?? "—", fmtDate(j.created_at),
            <span key="e" className="small">{j.last_error?.split("\n")[0]?.slice(0, 80)}</span>,
            j.status === "dead" && can(user, "jobs.manage") ? <button key="r" className="btn small secondary" onClick={() => act(() => api(`/jobs/${j.id}/retry`, { body: {} }), "Requeued").then(jobs.reload)}>Retry</button> : null])} />}
      </Card>}
      {tab === "audit" && (auditOk ? <Card title="Audit trail" sub="Hash-chained: altering any past event breaks verification."
          actions={<button className="btn small" onClick={async () => setVerify(await api("/audit/verify"))}>Verify chain</button>}>
        {verify && <div className={`banner ${verify.valid ? "ok" : "bad"}`}>{verify.valid ? `Chain intact across ${verify.checked} events` : `Chain broken at event ${verify.broken_at}`}</div>}
        {!audit.data ? <Loading /> : <Table head={["When", "Actor", "Action", "Entity", "Detail"]}
          rows={audit.data.map((e) => [fmtDate(e.at), e.actor_label, <code key="a">{e.action}</code>, `${e.entity_type} ${e.entity_id}`,
            <span key="d" className="small mono">{JSON.stringify(e.detail).slice(0, 140)}</span>])} />}
      </Card> : <Card><p className="muted">Your role cannot read the audit trail.</p></Card>)}
      {tab === "settings" && <Card title="Runtime configuration">
        {!settings.data ? <Loading /> : <><KV items={Object.entries(settings.data.runtime).map(([k, v]) => [k.replace(/_/g, " "), String(v)])} />
          <h3 style={{ marginTop: 16 }}>Stored settings</h3><Code text={JSON.stringify(settings.data.stored, null, 2)} /></>}
      </Card>}
    </>
  );
}
