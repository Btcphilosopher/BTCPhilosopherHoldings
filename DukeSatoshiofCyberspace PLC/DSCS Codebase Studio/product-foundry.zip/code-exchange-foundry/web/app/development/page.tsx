"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useUser } from "@/components/Shell";
import { Card, Code, Empty, Field, Loading, PageHead, Status, Table } from "@/components/ui";
import { act, api, can, fmtDate, short, useApi } from "@/lib/api";

const COLS = [["todo", "To do"], ["in_progress", "In progress"], ["review", "In review"], ["done", "Done"]];

function Dev() {
  const user = useUser();
  const params = useSearchParams();
  const projects = useApi<any[]>("/projects");
  const [pid, setPid] = useState<string>(params.get("project") ?? "");
  const eff = pid || (projects.data?.[0]?.id ? String(projects.data[0].id) : "");
  const tasks = useApi<any[]>(eff ? `/projects/${eff}/tasks` : null);
  const proj = useApi<any>(eff ? `/projects/${eff}` : null);
  const builds = useApi<any[]>(eff ? `/projects/${eff}/builds?limit=10` : null, 8000);
  const runs = useApi<any[]>(eff ? `/projects/${eff}/assistant/runs` : null);
  const repo = proj.data?.repositories?.[0];
  const commits = useApi<any[]>(repo ? `/repositories/${repo.id}/commits?limit=15` : null);
  const [ai, setAi] = useState({ action: "explain", paths: "src/csv_workshop/summary.py", instruction: "" });
  const [out, setOut] = useState<any>(null);

  const lastRelease = proj.data?.releases?.find((r: any) => ["published", "approved", "superseded"].includes(r.status));
  return (
    <>
      <PageHead title="Development" intro="Task assignment, development status, change summaries and the optional assistant.">
        <Field label="Project"><select value={eff} onChange={(e) => setPid(e.target.value)}>
          {projects.data?.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
      </PageHead>
      {!tasks.data ? <Loading /> : (
        <div className="board" aria-label="Task board">
          {COLS.map(([k, label]) => (
            <section key={k} className="col" aria-label={label}>
              <h3>{label} ({tasks.data!.filter((t) => t.status === k).length})</h3>
              {tasks.data!.filter((t) => t.status === k).map((t) => (
                <div key={t.id} className="item">
                  <div>{t.title}</div>
                  <div className="small muted">{t.assignee_name ?? "unassigned"}{t.proposed_by_assistant ? " · assistant proposal" : ""}</div>
                  {can(user, "task.edit") && <select aria-label={`Move ${t.title}`} value={t.status} style={{ marginTop: 4 }}
                    onChange={(e) => act(() => api(`/tasks/${t.id}`, { method: "PATCH", body: { status: e.target.value } })).then(tasks.reload)}>
                    {COLS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>}
                </div>))}
            </section>))}
        </div>)}
      <div className="grid cols-2" style={{ marginTop: 16 }}>
        <Card title="Change summary" sub={lastRelease ? `Commits since release ${lastRelease.version}` : "Recent commits"}>
          {!commits.data ? <Loading /> : <Table head={["Commit", "Change", "Build"]}
            rows={commits.data.filter((c) => !lastRelease || c.sha !== lastRelease.commit_sha).map((c) => [
              <span key="s" className="sha">{short(c.sha)}</span>, c.subject,
              c.build ? <Link key="b" href={`/builds/${c.build.id}`}><Status value={c.build.status} /></Link> : "not built"])} />}
        </Card>
        <Card title="Build history">
          {!builds.data ? <Loading /> : <Table head={["Build", "Ref", "Status", "Trigger", "When"]}
            rows={builds.data.map((b) => [<Link key="l" href={`/builds/${b.id}`}>#{b.number}</Link>, b.ref || short(b.commit_sha),
              <Status key="s" value={b.status} />, b.trigger, fmtDate(b.created_at)])} />}
        </Card>
      </div>
      <div className="grid cols-2" style={{ marginTop: 16 }}>
        <Card title="Development assistant (optional)"
              sub="Works only on the files you list. Generated changes go to a new assistant/* branch with a linked build; it cannot merge, approve, publish or change licences.">
          {!can(user, "assistant.use") ? <p className="muted">Your role cannot use the assistant.</p> : !repo ? <Empty>Connect a repository first.</Empty> : (
            <form className="form" onSubmit={async (e) => {
              e.preventDefault();
              const r = await act(() => api(`/projects/${eff}/assistant`, { body: { action: ai.action, repository_id: repo.id, commit: repo.default_branch,
                paths: ai.paths.split(",").map((s) => s.trim()).filter(Boolean), instruction: ai.instruction } }), "Assistant finished");
              if (r) { setOut(r); runs.reload(); tasks.reload(); }
            }}>
              <Field label="Action"><select value={ai.action} onChange={(e) => setAi({ ...ai, action: e.target.value })}>
                <option value="explain">Explain code</option><option value="propose-tasks">Propose tasks</option>
                <option value="draft-tests">Draft tests (branch + build)</option><option value="draft-docs">Draft documentation</option>
                <option value="suggest-patch">Suggest patch (branch + build)</option></select></Field>
              <Field label="Repository scope: paths (comma separated)"><input value={ai.paths} onChange={(e) => setAi({ ...ai, paths: e.target.value })} /></Field>
              <Field label="Instruction"><textarea value={ai.instruction} onChange={(e) => setAi({ ...ai, instruction: e.target.value })} /></Field>
              <button className="btn">Run assistant</button>
            </form>)}
        </Card>
        <Card title="Assistant output">
          {!out ? <p className="muted">Run the assistant to see its output. Output must be reviewed before use.</p> : (
            <>
              <p className="small">Provider <strong>{out.model_config.provider}</strong>{out.model_config.model ? ` · ${out.model_config.model}` : ""} ·
                inputs recorded as checksums only ({out.inputs_manifest.length} file(s))</p>
              {out.branch && <div className="banner info">Changes committed to <code>{out.branch}</code>; <Link href={`/builds/${out.build_id}`}>build queued</Link>. Review and merge outside the assistant.</div>}
              {out.output.text && <Code text={out.output.text} label="Assistant text" />}
              {out.output.tasks && <><Table head={["Proposed task", "Requirement"]} rows={out.output.tasks.map((t: any) => [t.title, t.requirement_key])} />
                {can(user, "task.edit") && out.output.tasks.length > 0 && <button className="btn small" style={{ marginTop: 8 }} onClick={() =>
                  act(() => api(`/assistant/runs/${out.id}/accept-tasks`, { body: { indexes: out.output.tasks.map((_: any, i: number) => i) } }), "Tasks created").then(tasks.reload)}>
                  Accept all as tasks</button>}</>}
            </>)}
          {runs.data && runs.data.length > 0 && <details style={{ marginTop: 12 }}><summary className="small">Previous runs ({runs.data.length})</summary>
            <Table head={["Run", "Action", "Provider", "Branch", "When"]} rows={runs.data.map((r) => [r.id, r.action, r.provider, r.branch ?? "—", fmtDate(r.created_at)])} />
          </details>}
        </Card>
      </div>
    </>
  );
}

export default function Page() { return <Suspense fallback={<Loading />}><Dev /></Suspense>; }
