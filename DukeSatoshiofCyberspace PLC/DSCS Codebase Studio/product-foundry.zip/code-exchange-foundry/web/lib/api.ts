"use client";

import { useCallback, useEffect, useRef, useState } from "react";

export const API_BASE = "/api/v1";
const TOKEN_KEY = "foundry.token";
const USER_KEY = "foundry.user";

export type User = { id: number; email: string; name: string; roles: string[]; permissions: string[] };

export class ApiError extends Error {
  constructor(public status: number, public detail: unknown) {
    super(typeof detail === "string" ? detail : JSON.stringify(detail));
  }
}

function safeGet(key: string): string | null {
  try { return window.sessionStorage.getItem(key); } catch { return null; }
}
function safeSet(key: string, value: string | null) {
  try {
    if (value === null) window.sessionStorage.removeItem(key);
    else window.sessionStorage.setItem(key, value);
  } catch { /* storage unavailable: session lasts for this page only */ }
}

let memoryToken: string | null = null;
export function getToken(): string | null { return memoryToken ?? safeGet(TOKEN_KEY); }
export function getUser(): User | null {
  const raw = safeGet(USER_KEY);
  return raw ? (JSON.parse(raw) as User) : null;
}
export function setSession(token: string | null, user: User | null) {
  memoryToken = token;
  safeSet(TOKEN_KEY, token);
  safeSet(USER_KEY, user ? JSON.stringify(user) : null);
}

export async function api<T = any>(path: string, opts: { method?: string; body?: unknown; raw?: boolean } = {}): Promise<T> {
  const headers: Record<string, string> = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (opts.body !== undefined) headers["Content-Type"] = "application/json";
  const res = await fetch(API_BASE + path, {
    method: opts.method ?? (opts.body !== undefined ? "POST" : "GET"),
    headers, body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined, cache: "no-store",
  });
  if (res.status === 401 && typeof window !== "undefined" && !path.startsWith("/auth/login")) {
    setSession(null, null);
    window.location.href = "/login";
  }
  if (!res.ok) {
    let detail: unknown = res.statusText;
    try { detail = (await res.json()).detail; } catch { /* not json */ }
    throw new ApiError(res.status, detail);
  }
  if (opts.raw) return res as unknown as T;
  const ct = res.headers.get("content-type") ?? "";
  return (ct.includes("json") ? res.json() : res.text()) as Promise<T>;
}

export function errorText(e: unknown): string {
  if (e instanceof ApiError) {
    const d = e.detail as any;
    if (typeof d === "string") return d;
    if (d?.message) return `${d.message}${d.blocking ? `: ${d.blocking.join(", ")}` : ""}`;
    if (Array.isArray(d)) return d.map((x) => x.msg ?? JSON.stringify(x)).join("; ");
    return JSON.stringify(d);
  }
  return e instanceof Error ? e.message : String(e);
}

/** Load data from the API; re-runs when `path` changes. `poll` refreshes while the page is visible. */
export function useApi<T = any>(path: string | null, poll?: number) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const pathRef = useRef(path);
  pathRef.current = path;
  const load = useCallback(async () => {
    if (!pathRef.current) return;
    setLoading(true);
    try {
      const d = await api<T>(pathRef.current);
      setData(d);
      setError(null);
    } catch (e) {
      setError(errorText(e));
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { setData(null); load(); }, [path, load]);
  useEffect(() => {
    if (!poll) return;
    const t = setInterval(() => { if (document.visibilityState === "visible") load(); }, poll);
    return () => clearInterval(t);
  }, [poll, load]);
  return { data, error, loading, reload: load, setData };
}

/** Run an API mutation and report the outcome through the shared toast. */
export async function act<T = any>(fn: () => Promise<T>, success?: string): Promise<T | undefined> {
  try {
    const r = await fn();
    if (success) toast(success);
    return r;
  } catch (e) {
    toast(errorText(e), true);
    return undefined;
  }
}

type ToastListener = (msg: string, bad: boolean) => void;
const listeners = new Set<ToastListener>();
export function toast(msg: string, bad = false) { listeners.forEach((l) => l(msg, bad)); }
export function onToast(l: ToastListener) { listeners.add(l); return () => { listeners.delete(l); }; }

export function can(user: User | null, permission: string) { return !!user?.permissions.includes(permission); }

export function fmtDate(v?: string | null) {
  if (!v) return "—";
  const d = new Date(v);
  return isNaN(d.getTime()) ? v : d.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}
export function short(sha?: string | null, n = 10) { return sha ? sha.slice(0, n) : "—"; }
export function money(p?: { currency?: string; amount?: string }) {
  return p?.amount ? `${p.currency ?? ""} ${p.amount}` : "—";
}
