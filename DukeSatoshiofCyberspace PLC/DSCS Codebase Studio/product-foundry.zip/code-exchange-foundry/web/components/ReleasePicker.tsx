"use client";

import { useEffect } from "react";
import { Field } from "./ui";
import { useApi } from "@/lib/api";

export function ReleasePicker({ value, onChange }: { value: string; onChange: (id: string) => void }) {
  const { data } = useApi<any[]>("/releases");
  useEffect(() => {
    if (!value && data?.length) onChange(String(data[0].id));
  }, [data, value, onChange]);
  return (
    <Field label="Release">
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        {data?.map((r) => <option key={r.id} value={r.id}>{r.product} {r.version} — {r.status}</option>)}
      </select>
    </Field>
  );
}
