"use client";

import Link from "next/link";
import { useState } from "react";
import { useUser } from "@/components/Shell";
import { Card, ErrorBanner, Field, Loading, Status } from "@/components/ui";
import { act, api, can, fmtDate, useApi } from "@/lib/api";

const EVIDENCE_LINK: Record<string, (id: number) => string> = {
  build: (id) => `/builds/${id}`, document: () => `/documentation`, "licence-review": () => `/licences`,
  issue: () => `/support`, edition: () => `/packaging`,
};

export function Readiness({ rid }: { rid: string }) {
  const user = useUser();
  const r = useApi<any>(`/releases/${rid}/readiness`);
  const rel = useApi<any>(`/releases/${rid}`);
  const users = useApi<any[]>("/users");
  const [exc, setExc] = useState({ check_key: "", owner_id: "", reason: "", scope: "", expires_on: "" });
  const [rev, setRev] = useState({ check_key: "accessibility", result: "passed", evidence: "" });
  const [plat, setPlat] = useState({ platform: "", result: "passed", evidence: "" });
  const refresh = () => { r.reload(); rel.reload(); };
  if (!r.data || !rel.data) return <><ErrorBanner error={r.error} /><Loading what="Evaluating readiness" /></>;
  const frozen = ["approved", "published", "superseded", "withdrawn"].includes(rel.data.status);
  return (
    <div className="grid cols-3">
      <div style={{ gridColumn: "span 2" }}>
        <Card title={`Release readiness — ${rel.data.product} ${rel.data.version}`}
              sub={`${r.data.frozen ? "Snapshot recorded at approval" : "Evaluated"} ${fmtDate(r.data.evaluated_at)} for commit ${r.data.commit?.slice(0, 12)}`}
              actions={<Status value={r.data.ready ? "ready" : "blocked"} label={r.data.frozen ? "approved snapshot" : r.data.ready ? "ready to approve" : `${r.data.blocking.length} blocking`} />}>
          {r.data.checks.map((c: any) => (
            <div key={c.key} className="check">
              <div><Status value={c.status} /></div>
              <div>
                <h3>{c.title}</h3>
                <div className="small">{c.summary}</div>
                {c.exception && <div className="banner warn small" style={{ margin: "6px 0" }}>
                  Exception #{c.exception.id}: {c.exception.reason} — scope: {c.exception.scope}; expires {c.exception.expires_on ?? "never"}</div>}
                {c.evidence.length > 0 && <ul className="evidence">
                  {c.evidence.slice(0, 12).map((e: any, i: number) => (
                    <li key={i}>{EVIDENCE_LINK[e.type] && e.id ? <Link href={EVIDENCE_LINK[e.type](e.id)}>{e.label}</Link> : e.label}
                      {e.status && <> <Status value={e.status} /></>}{e.detail && <span className="muted"> — {e.detail}</span>}</li>))}
                </ul>}
              </div>
            </div>))}
        </Card>
      </div>
      <div className="grid" style={{ alignContent: "start" }}>
        {frozen ? <Card><p className="muted">This release is {rel.data.status}; its evidence is frozen.</p></Card> : <>
          {can(user, "quality.review") && <Card title="Record platform verification">
            <form className="form" onSubmit={async (e) => { e.preventDefault(); await act(() => api(`/releases/${rid}/platform-verifications`, { body: plat }), "Recorded"); refresh(); }}>
              <Field label="Platform"><select value={plat.platform} onChange={(e) => setPlat({ ...plat, platform: e.target.value })} required>
                <option value="">Choose…</option>{rel.data.platform_claims.map((p: string) => <option key={p}>{p}</option>)}</select></Field>
              <Field label="Result"><select value={plat.result} onChange={(e) => setPlat({ ...plat, result: e.target.value })}><option>passed</option><option>failed</option></select></Field>
              <Field label="Evidence (test record, log reference)"><textarea value={plat.evidence} onChange={(e) => setPlat({ ...plat, evidence: e.target.value })} required minLength={10} /></Field>
              <button className="btn">Record</button>
            </form></Card>}
          {can(user, "quality.review") && <Card title="Record review">
            <form className="form" onSubmit={async (e) => { e.preventDefault(); await act(() => api(`/releases/${rid}/reviews`, { body: rev }), "Review recorded"); refresh(); }}>
              <Field label="Check"><select value={rev.check_key} onChange={(e) => setRev({ ...rev, check_key: e.target.value })}>
                <option>accessibility</option><option>support</option><option>installation</option></select></Field>
              <Field label="Result"><select value={rev.result} onChange={(e) => setRev({ ...rev, result: e.target.value })}><option>passed</option><option>failed</option></select></Field>
              <Field label="Evidence"><textarea value={rev.evidence} onChange={(e) => setRev({ ...rev, evidence: e.target.value })} required minLength={10} /></Field>
              <button className="btn">Record</button>
            </form></Card>}
          {can(user, "exception.create") && <Card title="Documented exception" sub="Needs an owner, a reason and the affected scope; may expire.">
            <form className="form" onSubmit={async (e) => { e.preventDefault();
              await act(() => api(`/releases/${rid}/exceptions`, { body: { ...exc, owner_id: Number(exc.owner_id), expires_on: exc.expires_on || null } }), "Exception recorded"); refresh(); }}>
              <Field label="Check"><select value={exc.check_key} onChange={(e) => setExc({ ...exc, check_key: e.target.value })} required>
                <option value="">Choose…</option>{r.data.checks.map((c: any) => <option key={c.key} value={c.key}>{c.title}</option>)}</select></Field>
              <Field label="Owner"><select value={exc.owner_id} onChange={(e) => setExc({ ...exc, owner_id: e.target.value })} required>
                <option value="">Choose…</option>{users.data?.filter((u) => !u.is_service).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</select></Field>
              <Field label="Reason"><textarea value={exc.reason} onChange={(e) => setExc({ ...exc, reason: e.target.value })} required minLength={10} /></Field>
              <Field label="Affected release scope"><input value={exc.scope} onChange={(e) => setExc({ ...exc, scope: e.target.value })} required /></Field>
              <Field label="Expires on"><input type="date" value={exc.expires_on} onChange={(e) => setExc({ ...exc, expires_on: e.target.value })} /></Field>
              <button className="btn">Record exception</button>
            </form></Card>}
        </>}
      </div>
    </div>
  );
}

