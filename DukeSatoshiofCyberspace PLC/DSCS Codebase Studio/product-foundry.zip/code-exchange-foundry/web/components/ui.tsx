"use client";

import React, { useEffect, useId, useRef, useState } from "react";
import { api, onToast } from "@/lib/api";

const TONE: Record<string, string> = {
  passed: "ok", succeeded: "ok", approved: "ok", published: "ok", accepted: "ok", cleared: "ok", valid: "ok",
  active: "ok", done: "ok", fixed: "ok", ready: "ok", tested: "info", implemented: "info", running: "info",
  queued: "info", publishing: "info", candidate: "info", validation: "info", "in-review": "info",
  "pending-approval": "warn", draft: "neutral", proposed: "neutral", todo: "neutral", pending: "neutral",
  skipped: "neutral", superseded: "neutral", unlisted: "neutral", in_progress: "info", review: "warn",
  excepted: "warn", warning: "warn", open: "warn", new: "warn", triaged: "info", "in-progress": "info",
  failed: "bad", error: "bad", dead: "bad", rejected: "bad", withdrawn: "bad", cancelled: "neutral",
  invalid: "bad", blocked: "bad", unreviewed: "warn", unverified: "bad", missing: "bad", unsupported: "bad",
};

export function Status({ value, label }: { value?: string | null; label?: string }) {
  const v = value ?? "unknown";
  return <span className={`pill ${TONE[v] ?? "neutral"}`}>{label ?? v.replace(/_/g, " ")}</span>;
}

export function PageHead({ title, intro, children }: { title: string; intro?: string; children?: React.ReactNode }) {
  return (
    <div className="page-head">
      <div><h1>{title}</h1>{intro && <p>{intro}</p>}</div>
      <div className="row">{children}</div>
    </div>
  );
}

export function Card({ title, sub, children, className = "", actions }: {
  title?: React.ReactNode; sub?: React.ReactNode; children?: React.ReactNode; className?: string; actions?: React.ReactNode;
}) {
  return (
    <section className={`card ${className}`}>
      {(title || actions) && (
        <div className="row" style={{ marginBottom: 8 }}>
          {title && <h2 style={{ margin: 0 }}>{title}</h2>}<span className="spacer" />{actions}
        </div>
      )}
      {sub && <p className="sub">{sub}</p>}
      {children}
    </section>
  );
}

export function ErrorBanner({ error }: { error?: string | null }) {
  if (!error) return null;
  return <div className="banner bad" role="alert">{error}</div>;
}

export function Empty({ children }: { children: React.ReactNode }) {
  return <div className="empty">{children}</div>;
}

export function Loading({ what = "Loading" }: { what?: string }) {
  return <p className="muted" aria-live="polite">{what}…</p>;
}

export function Table({ head, rows, empty = "Nothing here yet." }: {
  head: React.ReactNode[]; rows: React.ReactNode[][]; empty?: string;
}) {
  if (!rows.length) return <Empty>{empty}</Empty>;
  return (
    <div className="table-wrap">
      <table className="data">
        <thead><tr>{head.map((h, i) => <th key={i} scope="col">{h}</th>)}</tr></thead>
        <tbody>{rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}>{c}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}

export function Tabs({ tabs, value, onChange }: { tabs: { id: string; label: string }[]; value: string; onChange: (id: string) => void }) {
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  const onKey = (e: React.KeyboardEvent, i: number) => {
    let n = i;
    if (e.key === "ArrowRight") n = (i + 1) % tabs.length;
    else if (e.key === "ArrowLeft") n = (i - 1 + tabs.length) % tabs.length;
    else if (e.key === "Home") n = 0;
    else if (e.key === "End") n = tabs.length - 1;
    else return;
    e.preventDefault();
    onChange(tabs[n].id);
    refs.current[n]?.focus();
  };
  return (
    <div className="tabs" role="tablist">
      {tabs.map((t, i) => (
        <button key={t.id} role="tab" ref={(el) => { refs.current[i] = el; }} aria-selected={t.id === value}
                tabIndex={t.id === value ? 0 : -1} onClick={() => onChange(t.id)} onKeyDown={(e) => onKey(e, i)}>
          {t.label}
        </button>
      ))}
    </div>
  );
}

export function Field({ label, children }: { label: string; children: React.ReactElement }) {
  const id = useId();
  return (
    <label className="field" htmlFor={id}>
      {label}
      {React.cloneElement(children as React.ReactElement<any>, { id })}
    </label>
  );
}

export function Log({ text }: { text: string }) {
  const lines = (text || "").split("\n");
  return (
    <pre className="log" tabIndex={0} aria-label="Build log">
      {lines.map((l, i) => (
        <div key={i}><span className="ln">{i + 1}</span>{l}</div>
      ))}
    </pre>
  );
}

export function Code({ text, label = "Code" }: { text: string; label?: string }) {
  return <pre className="code" tabIndex={0} aria-label={label}>{text}</pre>;
}

export function KV({ items }: { items: [string, React.ReactNode][] }) {
  return (
    <dl className="kv">
      {items.map(([k, v]) => (<React.Fragment key={k}><dt>{k}</dt><dd>{v ?? "—"}</dd></React.Fragment>))}
    </dl>
  );
}

export function Toasts() {
  const [msg, setMsg] = useState<{ text: string; bad: boolean } | null>(null);
  useEffect(() => onToast((text, bad) => {
    setMsg({ text, bad });
    const t = setTimeout(() => setMsg(null), bad ? 9000 : 4000);
    return () => clearTimeout(t);
  }), []);
  return (
    <div aria-live="assertive" role="status">
      {msg && <div className={`toast ${msg.bad ? "bad" : ""}`}>{msg.text}</div>}
    </div>
  );
}

/** Fetch an authenticated binary (SVG artwork, HTML preview) and display it. */
export function AuthImage({ path, alt }: { path: string; alt: string }) {
  const [src, setSrc] = useState<string | null>(null);
  useEffect(() => {
    let url: string | null = null;
    api<Response>(path, { raw: true }).then(async (r) => {
      url = URL.createObjectURL(await r.blob());
      setSrc(url);
    }).catch(() => setSrc(null));
    return () => { if (url) URL.revokeObjectURL(url); };
  }, [path]);
  return src ? <img src={src} alt={alt} /> : <p className="muted">Loading artwork…</p>;
}

export function AuthFrame({ path, title }: { path: string; title: string }) {
  const [html, setHtml] = useState<string>("");
  useEffect(() => { api<string>(path).then(setHtml).catch(() => setHtml("<p>Preview unavailable</p>")); }, [path]);
  return <iframe title={title} srcDoc={html} sandbox="" style={{ width: "100%", height: 560, border: "1px solid var(--ivory-300)", borderRadius: 8, background: "#fff" }} />;
}

export async function download(path: string, filename: string) {
  const r = await api<Response>(path, { raw: true });
  const blob = await r.blob();
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
