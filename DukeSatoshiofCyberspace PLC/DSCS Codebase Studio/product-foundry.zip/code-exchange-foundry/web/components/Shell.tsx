"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import React, { createContext, useContext, useEffect, useState } from "react";
import { getUser, setSession, User } from "@/lib/api";
import { Toasts } from "./ui";

export const NAV = [
  ["/", "Overview"], ["/projects", "Projects"], ["/repositories", "Repositories"], ["/development", "Development"],
  ["/builds", "Builds"], ["/quality", "Quality"], ["/documentation", "Documentation"], ["/licences", "Licences"],
  ["/packaging", "Packaging"], ["/releases", "Releases"], ["/catalogue", "Catalogue"], ["/support", "Support"],
  ["/administration", "Administration"],
] as const;

const UserCtx = createContext<User | null>(null);
export const useUser = () => useContext(UserCtx);

function Mark() {
  return (
    <svg width="30" height="30" viewBox="0 0 64 64" aria-hidden="true">
      <rect width="64" height="64" rx="12" fill="#c8006e" />
      <path d="M22 20 10 32l12 12M42 20l12 12-12 12M36 16l-8 32" stroke="#fff" strokeWidth="5" fill="none"
            strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Shell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const u = getUser();
    setUser(u);
    setReady(true);
    if (!u && pathname !== "/login") router.replace("/login");
  }, [pathname, router]);
  useEffect(() => setOpen(false), [pathname]);

  if (pathname === "/login") return <>{children}<Toasts /></>;
  if (!ready || !user) return <div className="login-wrap"><p style={{ color: "#fff" }}>Loading…</p></div>;

  const active = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));
  return (
    <UserCtx.Provider value={user}>
      <a className="skip-link" href="#main">Skip to content</a>
      <div className="shell">
        <nav className={`nav ${open ? "open" : ""}`} aria-label="Product Foundry">
          <div className="brand">
            <Link href="/" className="brand-mark"><Mark /><span>The Code Exchange<small>Product Foundry</small></span></Link>
            <button className="btn ghost small nav-toggle" aria-expanded={open} aria-controls="nav-list"
                    onClick={() => setOpen(!open)}>Menu</button>
          </div>
          <ul id="nav-list">
            {NAV.map(([href, label]) => (
              <li key={href}><Link href={href} aria-current={active(href) ? "page" : undefined}>{label}</Link></li>
            ))}
          </ul>
          <div className="who">
            <strong>{user.name}</strong>
            <span>{user.roles.map((r) => r.replace(/_/g, " ")).join(", ")}</span>
            <div>
              <button className="btn ghost small" onClick={() => { setSession(null, null); router.replace("/login"); }}>
                Sign out
              </button>
            </div>
          </div>
        </nav>
        <main id="main" className="workspace" tabIndex={-1}>{children}</main>
      </div>
      <Toasts />
    </UserCtx.Provider>
  );
}
