"""Approval rules, immutable releases and artefact integrity."""
from datetime import date, timedelta
from pathlib import Path

import pytest
from sqlalchemy import select

from foundry import config
from foundry.db import session_scope
from foundry.models import Artifact, Release, ReleaseArtifact
from foundry.releases import ImmutableError
from foundry.storage import IntegrityError, LocalStorage, read_verified, store_blob
from tests.conftest import new_product, prepare_release


def test_release_requires_passing_build_and_matching_version(api, built):
    pr, eds = new_product(api, built)
    api.post("dev", f"/products/{pr['id']}/releases", {"version": "2.0.0", "build_id": built["build"]["id"]}, expect=409)
    api.post("dev", f"/products/{pr['id']}/releases", {"version": "one", "build_id": built["build"]["id"]}, expect=422)


def test_unverified_platform_claim_blocks_approval(api, built):
    pr, eds = new_product(api, built)
    rid = prepare_release(api, built, pr, eds, claims=("linux-x86_64", "windows-x86_64"))
    ready = api.get("rm", f"/releases/{rid}/readiness")
    assert ready["blocking"] == ["platforms"]
    r = api.post("rm", f"/releases/{rid}/approve", {}, expect=409)
    assert "platforms" in str(r)


def test_documented_exception_allows_approval_but_expired_or_revoked_does_not(api, built):
    pr, eds = new_product(api, built)
    rid = prepare_release(api, built, pr, eds, claims=("linux-x86_64", "windows-x86_64"))
    owner = api.user_id("qe")
    api.post("rm", f"/releases/{rid}/exceptions", {"check_key": "platforms", "owner_id": owner,
                                                   "reason": "Windows verification lab unavailable", "scope": "x",
                                                   "expires_on": str(date.today() - timedelta(days=1))}, expect=422)
    api.post("rm", f"/releases/{rid}/return-to-draft", {"reason": "add exception"})
    x = api.post("rm", f"/releases/{rid}/exceptions", {"check_key": "platforms", "owner_id": owner,
                                                       "reason": "Windows verification lab unavailable this week",
                                                       "scope": "Windows claim on this release only",
                                                       "expires_on": str(date.today() + timedelta(days=7))})
    api.req("rm", "DELETE", f"/exceptions/{x['id']}")
    api.post("rm", f"/releases/{rid}/candidate")
    api.post("rm", f"/releases/{rid}/validation")
    assert api.get("rm", f"/releases/{rid}/readiness")["blocking"] == ["platforms"]  # revoked exception ignored
    api.post("rm", f"/releases/{rid}/return-to-draft", {"reason": "re-add"})
    api.post("rm", f"/releases/{rid}/exceptions", {"check_key": "platforms", "owner_id": owner,
                                                   "reason": "Windows verification lab unavailable this week",
                                                   "scope": "Windows claim on this release only",
                                                   "expires_on": str(date.today() + timedelta(days=7))})
    api.post("rm", f"/releases/{rid}/candidate")
    api.post("rm", f"/releases/{rid}/validation")
    ready = api.get("rm", f"/releases/{rid}/readiness")
    plat = next(c for c in ready["checks"] if c["key"] == "platforms")
    assert plat["status"] == "excepted" and plat["exception"]["scope"]
    assert api.post("rm", f"/releases/{rid}/approve", {})["status"] == "approved"


def test_release_creator_cannot_approve(api, built):
    pr, eds = new_product(api, built)
    rid = prepare_release(api, built, pr, eds, creator="rm")
    r = api.post("rm", f"/releases/{rid}/approve", {}, expect=403)
    assert "separation of duties" in str(r)


def test_illegal_transitions_refused(api, built):
    pr, eds = new_product(api, built)
    rid = prepare_release(api, built, pr, eds, to="draft")
    api.post("rm", f"/releases/{rid}/approve", {}, expect=409)
    api.post("rm", f"/releases/{rid}/validation", expect=409)


@pytest.fixture
def approved(api, built):
    pr, eds = new_product(api, built)
    rid = prepare_release(api, built, pr, eds)
    rel = api.post("rm", f"/releases/{rid}/approve", {"comment": "ok"})
    assert rel["status"] == "approved"
    return rel


def test_approved_release_is_immutable_through_api(api, approved):
    rid = approved["id"]
    api.patch("rm", f"/releases/{rid}", {"notes": "changed"}, expect=409)
    api.post("rm", f"/releases/{rid}/return-to-draft", {"reason": "nope"}, expect=409)
    api.post("qe", f"/releases/{rid}/reviews", {"check_key": "support", "result": "failed", "evidence": "late review"},
             expect=409)
    doc = api.get("docs", f"/releases/{rid}/documents")[0]
    api.req("docs", "PUT", f"/documents/{doc['id']}", expect=409, json={"body": "rewrite"})


def test_approved_release_is_immutable_at_the_orm_layer(approved):
    rid = approved["id"]
    with pytest.raises(ImmutableError):
        with session_scope() as db:
            db.get(Release, rid).manifest = {"tampered": True}
    with pytest.raises(ImmutableError):
        with session_scope() as db:
            ra = db.execute(select(ReleaseArtifact).where(ReleaseArtifact.release_id == rid)).scalars().first()
            db.get(Artifact, ra.artifact_id).sha256 = "0" * 64
    with pytest.raises(ImmutableError):
        with session_scope() as db:
            ra = db.execute(select(ReleaseArtifact).where(ReleaseArtifact.release_id == rid)).scalars().first()
            db.delete(ra)
    with pytest.raises(ImmutableError):
        with session_scope() as db:
            ra = db.execute(select(ReleaseArtifact).where(ReleaseArtifact.release_id == rid)).scalars().first()
            db.delete(db.get(Artifact, ra.artifact_id))
    with session_scope() as db:  # the permitted after-approval change: support dates
        db.get(Release, rid).end_of_support_on = date.today() + timedelta(days=900)


def test_corrections_require_a_new_version(api, approved):
    api.post("dev", f"/products/{approved['product_id']}/releases",
             {"version": approved["version"], "build_id": approved["build_id"]}, expect=409)


def test_manifest_hash_covers_contents(api, approved):
    integ = api.get("rm", f"/releases/{approved['id']}/integrity")
    assert integ["manifest_matches"] and all(a["ok"] for a in integ["artifacts"])
    rel = api.get("rm", f"/releases/{approved['id']}")
    assert rel["manifest"]["source"]["commit"] == rel["commit_sha"]
    roles = {a["role"] for a in rel["manifest"]["artifacts"]}
    assert {"application", "sbom", "notices", "docs-html", "docs-pdf"} <= roles


def test_storage_refuses_overwrite_and_detects_tampering(tmp_path):
    st = LocalStorage(tmp_path)
    st.put("objects/k", b"one")
    st.put("objects/k", b"one")  # identical bytes are a no-op
    with pytest.raises(IntegrityError):
        st.put("objects/k", b"two")
    with pytest.raises(ValueError):
        st.put("../escape", b"x")


def test_tampered_artefact_blocks_approval_and_download(api, built):
    pr, eds = new_product(api, built)
    rid = prepare_release(api, built, pr, eds)
    rel = api.get("rm", f"/releases/{rid}")
    app = next(a for a in rel["artifacts"] if a["role"] == "application")
    path = Path(config.settings.storage_root).resolve() / app["storage_key"]
    original = path.read_bytes()
    try:
        path.write_bytes(original + b"tamper")
        with pytest.raises(IntegrityError):
            read_verified(app["storage_key"], app["sha256"])
        r = api.post("rm", f"/releases/{rid}/approve", {}, expect=409)
        assert "integrity" in str(r)
        api.get("dev", f"/artifacts/{app['id']}/download", expect=500)
    finally:
        path.write_bytes(original)
    assert api.post("rm", f"/releases/{rid}/approve", {})["status"] == "approved"


def test_content_addressed_keys(tmp_path):
    key, digest = store_blob(b"hello")
    assert digest in key and read_verified(key, digest) == b"hello"
