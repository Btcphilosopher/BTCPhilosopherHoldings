"""Runs scripts/demo.py end-to-end against live API, worker and storefront servers (real HTTP)."""
import importlib.util
import os
import threading

import pytest

from foundry import config, jobs
from tests.conftest import ROOT, TMP, _serve, free_port, load_storefront, reset_database


@pytest.mark.skipif(os.environ.get("FOUNDRY_SKIP_E2E") == "1", reason="FOUNDRY_SKIP_E2E=1")
def test_full_demonstration():
    if not list((TMP / "wheelhouse").glob("tabulate-*.whl")):
        pytest.skip("wheelhouse required")
    reset_database()
    from foundry.main import app
    api_port, shop_port = free_port(), free_port()
    os.environ["STOREFRONT_DATA"] = str(TMP / "storefront" / "e2e.json")
    shop = load_storefront()
    servers = [_serve(app, api_port), _serve(shop.app, shop_port)]
    config.settings.storefront_url = f"http://127.0.0.1:{shop_port}"
    stop = threading.Event()

    def worker():
        while not stop.is_set():
            if jobs.run_one("e2e-worker") is None:
                stop.wait(0.2)
    t = threading.Thread(target=worker, daemon=True)
    t.start()
    os.environ.update({"FOUNDRY_API": f"http://127.0.0.1:{api_port}", "FOUNDRY_STOREFRONT": f"http://127.0.0.1:{shop_port}",
                       "DEMO_REPO_ROOT": str(TMP / "repos")})
    spec = importlib.util.spec_from_file_location("demo", ROOT / "scripts" / "demo.py")
    demo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(demo)
    try:
        assert demo.main() == 0
    finally:
        stop.set()
        t.join(timeout=30)
        for s in servers:
            s.should_exit = True
