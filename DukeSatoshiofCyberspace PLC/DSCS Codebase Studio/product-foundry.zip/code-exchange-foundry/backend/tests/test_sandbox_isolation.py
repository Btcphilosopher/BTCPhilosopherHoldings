"""Build isolation: network, environment, identity, filesystem, resource limits, timeout, cancellation."""
import os
import socket
import threading
import time
import uuid
from pathlib import Path

import pytest

from foundry import config
from foundry.sandbox import DockerSandbox, LocalSandbox, SandboxUnavailable, build_env


@pytest.fixture
def ws():
    d = config.settings.work_root.resolve() / f"iso-{uuid.uuid4().hex[:8]}" / "ws"
    d.mkdir(parents=True)
    yield d


def run(cmd, ws, **kw):
    sb = LocalSandbox()
    sb.prepare(ws)
    log = ws.parent / "log.txt"
    res = sb.run(cmd, ws, log, **kw)
    return res, log.read_text(errors="replace")


def test_no_network_even_to_worker_localhost(ws):
    srv = socket.socket()
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    port = srv.getsockname()[1]
    threading.Thread(target=lambda: srv.accept(), daemon=True).start()
    code = ("import socket,sys\n"
            "for host in [('127.0.0.1', %d), ('1.1.1.1', 80)]:\n"
            "    s=socket.socket(); s.settimeout(2)\n"
            "    try: s.connect(host); print('CONNECTED', host)\n"
            "    except OSError as e: print('BLOCKED', host, e.errno)\n") % port
    (ws / "net.py").write_text(code)
    res, out = run("python3 net.py", ws)
    srv.close()
    assert "CONNECTED" not in out
    assert out.count("BLOCKED") == 2


def test_worker_secrets_not_visible(ws, monkeypatch):
    monkeypatch.setenv("FOUNDRY_SECRET_KEY", "super-secret-value")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "aws-secret-value")
    monkeypatch.setenv("FOUNDRY_SECRET_GITHUB", "ghp_tokenvalue")
    res, out = run("env", ws)
    assert res.status == "passed"
    for value in ("super-secret-value", "aws-secret-value", "ghp_tokenvalue", "FOUNDRY_DATABASE_URL"):
        assert value not in out


def test_build_env_refuses_secret_variables():
    for name in ("FOUNDRY_SECRET_X", "AWS_ACCESS_KEY_ID", "FOUNDRY_DATABASE_URL", "FOUNDRY_S3_SECRET_KEY"):
        with pytest.raises(ValueError):
            build_env({name: "x"}, "/w")


@pytest.mark.skipif(os.geteuid() != 0, reason="privilege drop only applies when the worker runs as root")
def test_runs_unprivileged_and_cannot_write_outside_workspace(ws):
    target = config.settings.storage_root.resolve() / "escape.txt"
    res, out = run(f"id -u; echo pwned > {target}; echo rc=$?", ws)
    assert out.splitlines()[2].strip() == "65534" or "65534" in out
    assert not target.exists()
    assert "Permission denied" in out


def test_memory_limit_enforced(ws):
    sb = LocalSandbox(memory_mb=128)
    sb.prepare(ws)
    log = ws.parent / "mem.log"
    res = sb.run("python3 -c \"b = bytearray(512 * 1024 * 1024); print('ALLOC' + 'ATED')\"", ws, log)
    assert res.status == "failed"
    assert "ALLOCATED" not in log.read_text() and "MemoryError" in log.read_text()


def test_timeout_kills_stage(ws):
    t = time.monotonic()
    res, out = run("sleep 30", ws, timeout_s=1)
    assert res.status == "timeout"
    assert time.monotonic() - t < 10
    assert "process group killed" in out


def test_cancellation_kills_whole_process_group(ws):
    marker = f"foundry-cancel-{uuid.uuid4().hex[:6]}"
    start = time.monotonic()
    res, out = run(f"sh -c 'exec -a {marker} sleep 60' & sleep 60", ws,
                   should_cancel=lambda: time.monotonic() - start > 0.8)
    assert res.status == "cancelled"
    time.sleep(0.3)
    ps = os.popen("ps -eo args").read()
    assert marker not in ps


def test_workspace_is_disposable(ws):
    sb = LocalSandbox()
    sb.prepare(ws)
    (ws / "artefact").write_text("x")
    sb.cleanup(ws.parent)
    assert not ws.exists()


def test_local_sandbox_refuses_network_grant(ws):
    sb = LocalSandbox()
    with pytest.raises(SandboxUnavailable):
        sb.run("true", ws, ws.parent / "l", network="egress")


def _docker_ok():
    try:
        DockerSandbox()
        return os.system(f"docker image inspect {config.settings.sandbox_image} >/dev/null 2>&1") == 0
    except SandboxUnavailable:
        return False


@pytest.mark.skipif(not _docker_ok(), reason="docker daemon or sandbox image unavailable")
def test_docker_sandbox_restrictions(ws):
    sb = DockerSandbox()
    sb.prepare(ws)
    (ws / "probe.py").write_text(
        "import os, socket\n"
        "print('uid', os.getuid())\n"
        "try:\n    open('/usr/escape', 'w')\nexcept OSError as e:\n    print('rootfs', e.errno)\n"
        "s = socket.socket(); s.settimeout(2)\n"
        "try:\n    s.connect(('1.1.1.1', 80)); print('net open')\nexcept OSError:\n    print('net blocked')\n"
        "print('socket', os.path.exists('/var/run/docker.sock'))\n"
        "open('out.txt', 'w').write('ok')\n")
    log = ws.parent / "docker.log"
    res = sb.run("python3 probe.py", ws, log)
    out = log.read_text()
    assert res.status == "passed", out
    assert "uid 65534" in out and "net blocked" in out and "socket False" in out and "rootfs" in out
    assert (ws / "out.txt").read_text() == "ok"  # outputs copied back out of the disposable container
    assert sb.describe()["bind_mounts"] == []
