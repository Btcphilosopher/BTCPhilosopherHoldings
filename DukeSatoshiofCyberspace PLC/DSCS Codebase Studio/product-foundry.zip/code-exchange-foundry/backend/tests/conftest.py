"""Test configuration.

Tests run against a real PostgreSQL database (TEST_DATABASE_URL, default
postgresql+psycopg://foundry:foundry@localhost:5432/foundry_test) and the local sandbox.
The database is dropped and recreated at the start of the session.
"""
from __future__ import annotations

import importlib.util
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
TMP = Path(os.environ.get("FOUNDRY_TEST_TMP", "/var/tmp/foundry-tests"))
if TMP.exists():
    shutil.rmtree(TMP)
for sub in ("repos", "work", "objects", "storefront", "wheelhouse"):
    (TMP / sub).mkdir(parents=True, exist_ok=True)
os.chmod(TMP, 0o755)
os.chmod(TMP / "work", 0o755)

os.environ.update({
    "FOUNDRY_DATABASE_URL": os.environ.get("TEST_DATABASE_URL",
                                           "postgresql+psycopg://foundry:foundry@localhost:5432/foundry_test"),
    "FOUNDRY_STORAGE_BACKEND": "local", "FOUNDRY_STORAGE_ROOT": str(TMP / "objects"),
    "FOUNDRY_REPO_ROOTS": str(TMP / "repos"), "FOUNDRY_WORK_ROOT": str(TMP / "work"),
    "FOUNDRY_WHEELHOUSE": str(TMP / "wheelhouse"), "FOUNDRY_SANDBOX": "local",
    "FOUNDRY_SECRET_KEY": "test-secret-key-0123456789abcdef0123456789", "STOREFRONT_DATA": str(TMP / "storefront" / "state.json"),
    "FOUNDRY_WORKER_POLL_SECONDS": "0.2",
})

# The vetted wheelhouse: copy from FOUNDRY_TEST_WHEELHOUSE or ./var/wheelhouse if present.
for candidate in (os.environ.get("FOUNDRY_TEST_WHEELHOUSE"), ROOT / "var" / "wheelhouse", ROOT / "wheelhouse"):
    if candidate and Path(candidate).is_dir():
        for whl in Path(candidate).glob("*.whl"):
            shutil.copy(whl, TMP / "wheelhouse")

from foundry import config  # noqa: E402

config.reload_settings()

from foundry import bootstrap, jobs, seed  # noqa: E402
from foundry.db import reset_engine  # noqa: E402
from foundry.storage import reset_storage  # noqa: E402

SAMPLE = ROOT / "sample" / "csv-workshop"
PASSWORD = "foundry-demo"


def reset_database() -> None:
    reset_engine()
    reset_storage()
    bootstrap.drop_all()
    bootstrap.create_all()
    seed.seed()


@pytest.fixture(scope="session", autouse=True)
def database():
    reset_database()
    yield


@pytest.fixture(scope="session")
def client(database):
    from fastapi.testclient import TestClient
    from foundry.main import app
    with TestClient(app) as c:
        yield c


class Api:
    USERS = {"pm": "pat", "dev": "dana", "reviewer": "ravi", "qe": "quinn", "docs": "devi", "licence": "lena",
             "rm": "rowan", "cat": "cass", "support": "sam", "admin": "alex"}

    def __init__(self, client):
        self.c = client
        self.tokens = {}

    def token(self, who):
        if who not in self.tokens:
            r = self.c.post("/api/v1/auth/login", json={"email": f"{self.USERS[who]}@codeexchange.example",
                                                        "password": PASSWORD})
            assert r.status_code == 200, r.text
            self.tokens[who] = r.json()["token"]
        return self.tokens[who]

    def req(self, who, method, path, expect=200, **kw):
        headers = {"Authorization": f"Bearer {self.token(who)}"} if who else {}
        r = self.c.request(method, "/api/v1" + path, headers=headers, **kw)
        if expect is not None:
            assert r.status_code == expect, f"{method} {path}: {r.status_code} {r.text[:600]}"
        try:
            return r.json()
        except ValueError:
            return r.text

    def get(self, who, path, expect=200):
        return self.req(who, "GET", path, expect)

    def post(self, who, path, body=None, expect=200):
        return self.req(who, "POST", path, expect, json=body or {})

    def patch(self, who, path, body, expect=200):
        return self.req(who, "PATCH", path, expect, json=body)

    def user_id(self, who):
        return self.get(who, "/auth/me")["id"]


@pytest.fixture(scope="session")
def api(client):
    return Api(client)


def git(repo: Path, *args):
    env = {**os.environ, "GIT_AUTHOR_NAME": "Test", "GIT_AUTHOR_EMAIL": "t@example.invalid",
           "GIT_COMMITTER_NAME": "Test", "GIT_COMMITTER_EMAIL": "t@example.invalid"}
    return subprocess.run(["git", "-C", str(repo), *args], check=True, capture_output=True, text=True, env=env).stdout.strip()


def make_repo(name: str) -> Path:
    repo = TMP / "repos" / name
    if repo.exists():
        shutil.rmtree(repo)
    shutil.copytree(SAMPLE, repo, ignore=shutil.ignore_patterns("__pycache__", ".deps", "dist", "build", "reports"))
    git(repo, "init", "-q", "-b", "main")
    git(repo, "add", "-A")
    git(repo, "commit", "-q", "-m", "initial")
    return repo


def drain(**kw):
    return jobs.drain(include_delayed=True, **kw)


STD_RIGHTS = {"binary_distribution": True, "source_access": False, "permission_to_modify": False,
              "redistribution": False, "commercial_deployment": "internal", "update_entitlement": "per edition",
              "support_entitlement": "per edition", "copyright_transfer": False}


@pytest.fixture(scope="session")
def built(api):
    """One real pipeline build of the sample product, shared by tests that need release inputs."""
    if not list((TMP / "wheelhouse").glob("tabulate-*.whl")):
        pytest.skip("wheelhouse with tabulate is required (see README: scripts/fetch-wheelhouse.sh)")
    proj = api.post("pm", "/projects", {"slug": "fixture-csv", "name": "Fixture CSV", "status": "development",
                                        "supported_platforms": ["linux-x86_64"],
                                        "support_owner_id": api.user_id("support")})
    pid = proj["id"]
    repo = make_repo("fixture-csv")
    # replace the unverified icon so the fixture build is licence-clean
    (repo / "assets" / "ASSETS.json").write_text('[{"path": "assets/icon.svg", "kind": "artwork", '
                                                 '"origin": "in-house", "licence": "LicenceRef-TCX-Owned"}]\n')
    git(repo, "commit", "-qam", "own icon")
    r = api.post("dev", f"/projects/{pid}/repositories", {"provider": "local", "name": "fixture", "location": str(repo),
                                                          "scopes": ["read", "assistant-branches"]})
    reqs = []
    for key, cat in (("REQ-001", "workflow"), ("REQ-007", "installation")):
        rq = api.post("pm", f"/projects/{pid}/requirements", {"key": key, "category": cat, "title": key})
        api.patch("dev", f"/requirements/{rq['id']}", {"status": "implemented"})
        reqs.append(rq)
    b = api.post("dev", f"/repositories/{r['id']}/builds", {"ref": "main"})
    drain()
    b = api.get("dev", f"/builds/{b['id']}")
    assert b["status"] == "passed", [(s["name"], s["status"], s["log_tail"][-400:]) for s in b["stages"]]
    for rq in reqs:
        api.post("reviewer", f"/requirements/{rq['id']}/accept")
    lic = api.post("licence", "/licence-versions", {"project_id": pid, "code": "FIX-STD", "version": "1.0",
                                                    "title": "Fixture licence", "summary": "s", "text": "t",
                                                    "rights": STD_RIGHTS})
    api.post("licence", f"/licence-versions/{lic['id']}/approve")
    return {"project_id": pid, "repo_id": r["id"], "repo": repo, "build": b, "licence_id": lic["id"]}


_counter = [0]


def new_product(api, built, kinds=("digital-download",), policy=None):
    _counter[0] += 1
    n = _counter[0]
    pr = api.post("pm", f"/projects/{built['project_id']}/products",
                  {"slug": f"fixture-product-{n}", "name": f"Fixture Product {n}", "description": "A fixture product."})
    eds = []
    for i, kind in enumerate(kinds):
        eds.append(api.post("pm", f"/products/{pr['id']}/editions", {
            "code": f"{kind[:6]}-{i}", "name": f"{kind} edition", "kind": kind, "licence_version_id": built["licence_id"],
            "sku": f"FIX-{n}-{i}", "price": {"currency": "GBP", "amount": "10.00"},
            "delivery_method": "download-key" if kind == "boxed-key" else "download",
            "update_policy": policy or {"covered_major_versions": [1], "updates_for_days": 365}}))
    return pr, eds


def prepare_release(api, built, product, editions, version="1.0.0", claims=("linux-x86_64",), creator="dev",
                    to="validation"):
    """Drive a release from draft to `to` ('draft' | 'candidate' | 'validation')."""
    from datetime import date, timedelta
    rel = api.post(creator, f"/products/{product['id']}/releases", {"version": version, "build_id": built["build"]["id"]})
    rid = rel["id"]
    api.patch("rm", f"/releases/{rid}", {"platform_claims": list(claims),
                                         "end_of_support_on": str(date.today() + timedelta(days=365))})
    for key in ("support", "accessibility"):
        api.post("qe", f"/releases/{rid}/reviews", {"check_key": key, "result": "passed", "evidence": "fixture review ok"})
    for d in api.post("docs", f"/releases/{rid}/documents/generate", {}):
        full = api.get("docs", f"/documents/{d['id']}")
        for i, f in enumerate(full["flags"] or []):
            api.post("docs", f"/documents/{d['id']}/flags/{i}/resolve", {"note": "fixture resolution"})
        if "```console-test" in full["body"]:
            api.post("docs", f"/documents/{d['id']}/check-examples")
            drain(kinds=["docs.check_examples"])
        api.post("docs", f"/documents/{d['id']}/submit")
        api.post("docs", f"/documents/{d['id']}/approve")
    if to == "draft":
        return rid
    api.post("rm", f"/releases/{rid}/candidate")
    tmpl = api.get("pm", "/packaging-templates")[0]
    for e in editions:
        if e["kind"] in ("boxed-key", "usb-collector"):
            api.post("cat", f"/releases/{rid}/editions/{e['id']}/artwork", {"template_id": tmpl["id"], "purpose": "mockup"})
    if to == "candidate":
        return rid
    api.post("rm", f"/releases/{rid}/validation")
    return rid


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _serve(app, port):
    import uvicorn
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
    t = threading.Thread(target=server.run, daemon=True)
    t.start()
    for _ in range(100):
        try:
            socket.create_connection(("127.0.0.1", port), timeout=0.2).close()
            return server
        except OSError:
            time.sleep(0.05)
    raise RuntimeError("server did not start")


def load_storefront():
    spec = importlib.util.spec_from_file_location("storefront_app", ROOT / "storefront_mock" / "app.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


@pytest.fixture(scope="session")
def storefront():
    mod = load_storefront()
    port = free_port()
    server = _serve(mod.app, port)
    url = f"http://127.0.0.1:{port}"
    os.environ["FOUNDRY_STOREFRONT_URL"] = url
    config.settings.storefront_url = url
    import httpx
    yield httpx.Client(base_url=url, timeout=30)
    server.should_exit = True
