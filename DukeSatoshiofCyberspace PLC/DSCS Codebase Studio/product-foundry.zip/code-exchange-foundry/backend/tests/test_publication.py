"""Catalogue publication: separate approval, idempotent retries, partial-failure recovery."""
from sqlalchemy import select

from foundry.db import session_scope
from foundry.models import CatalogueListing
from tests.conftest import drain, new_product, prepare_release


def _approved_listing(api, built, kinds=("digital-download",)):
    pr, eds = new_product(api, built, kinds=kinds)
    rid = prepare_release(api, built, pr, eds)
    api.post("rm", f"/releases/{rid}/approve", {})
    prev = api.post("cat", f"/editions/{eds[0]['id']}/listing/prepare", {"release_id": rid})
    return pr, eds, rid, prev


def _state(storefront):
    return storefront.get("/_state").json()


def test_listing_requires_its_own_approval(api, built, storefront):
    pr, eds = new_product(api, built)
    rid = prepare_release(api, built, pr, eds)
    api.post("cat", f"/editions/{eds[0]['id']}/listing/prepare", {"release_id": rid}, expect=409)  # not approved yet
    api.post("rm", f"/releases/{rid}/approve", {})
    prev = api.post("cat", f"/editions/{eds[0]['id']}/listing/prepare", {"release_id": rid})
    assert prev["changes"] and all(c["change"] == "added" for c in prev["changes"])
    api.post("cat", f"/listings/{prev['listing_id']}/publish", expect=409)
    api.post("rm", f"/listings/{prev['listing_id']}/approve", {}, expect=403)


def test_retry_after_partial_failures_does_not_duplicate(api, built, storefront):
    storefront.post("/_reset")
    pr, eds, rid, prev = _approved_listing(api, built)
    lid = prev["listing_id"]
    api.post("cat", f"/listings/{lid}/approve", {})
    for op, when in (("product", "after"), ("package", "before"), ("release", "after"), ("pointer", "after")):
        storefront.post("/_faults", json={"op": op, "when": when, "count": 1})
    pj = api.post("cat", f"/listings/{lid}/publish")
    assert api.post("cat", f"/listings/{lid}/publish")["id"] == pj["id"]
    drain()
    pj = api.get("cat", f"/publication-jobs/{pj['id']}")
    assert pj["status"] == "succeeded" and pj["attempts"] == 5
    st = _state(storefront)
    assert len(st["products"]) == 1 and len(st["editions"]) == 1 and len(st["releases"]) == 1
    rel = list(st["releases"].values())[0]
    manifest = api.get("rm", f"/releases/{rid}")["editions"][0]["manifest"]
    assert rel["package_sha256"] == manifest["package"]["sha256"]
    assert api.get("rm", f"/releases/{rid}")["status"] == "published"
    history = [h for h in pj["job"]["history"]]
    assert sum(h["status"] == "error" for h in history) == 4  # every failed attempt preserved


def test_exhausted_publication_can_be_resumed_without_duplicates(api, built, storefront):
    storefront.post("/_reset")
    pr, eds, rid, prev = _approved_listing(api, built)
    lid = prev["listing_id"]
    api.post("cat", f"/listings/{lid}/approve", {})
    storefront.post("/_faults", json={"op": "release", "when": "before", "count": 5})
    pj = api.post("cat", f"/listings/{lid}/publish")
    drain()
    pj = api.get("cat", f"/publication-jobs/{pj['id']}")
    assert pj["status"] == "dead" and pj["steps"]["package"]["status"] == "done"
    assert api.get("cat", "/catalogue/listings")[-1]["status"] in ("failed", "publishing")
    again = api.post("cat", f"/listings/{lid}/publish")  # operator retry resumes the same publication
    assert again["id"] == pj["id"]
    drain()
    pj = api.get("cat", f"/publication-jobs/{pj['id']}")
    assert pj["status"] == "succeeded"
    assert len(_state(storefront)["releases"]) == 1


def test_payload_changed_after_approval_is_not_published(api, built, storefront):
    pr, eds, rid, prev = _approved_listing(api, built)
    lid = prev["listing_id"]
    api.post("cat", f"/listings/{lid}/approve", {})
    with session_scope() as db:
        lst = db.get(CatalogueListing, lid)
        lst.draft_payload = {**lst.draft_payload, "product": {**lst.draft_payload["product"], "title": "Changed"}}
    pj = api.post("cat", f"/listings/{lid}/publish")
    drain()
    assert api.get("cat", f"/publication-jobs/{pj['id']}")["status"] == "dead"


def test_storefront_refuses_different_bytes_for_published_version(storefront):
    import hashlib
    tok = {"Authorization": "Bearer storefront-dev-token"}
    p = storefront.put("/v1/products/t-ref", json={"title": "t"}, headers=tok).json()
    e = storefront.put(f"/v1/products/{p['id']}/editions/t-ed", json={"name": "e"}, headers=tok).json()
    a = b"package-a"
    ok = storefront.put(f"/v1/editions/{e['id']}/releases/9.9.9/package", content=a,
                        headers={**tok, "X-Content-SHA256": hashlib.sha256(a).hexdigest()})
    assert ok.status_code == 200
    b = b"package-b"
    r = storefront.put(f"/v1/editions/{e['id']}/releases/9.9.9/package", content=b,
                       headers={**tok, "X-Content-SHA256": hashlib.sha256(b).hexdigest()})
    assert r.status_code == 409


def test_rollback_moves_pointer_and_explains_limits(api, built, storefront):
    storefront.post("/_reset")
    pr, eds = new_product(api, built)
    r1 = prepare_release(api, built, pr, eds, version="1.0.0")
    api.post("rm", f"/releases/{r1}/approve", {})
    lid = api.post("cat", f"/editions/{eds[0]['id']}/listing/prepare", {"release_id": r1})["listing_id"]
    api.post("cat", f"/listings/{lid}/approve", {})
    api.post("cat", f"/listings/{lid}/publish")
    drain()
    # second release from the same build is not allowed (version must match artefact), so roll back requires history;
    # with a single published release there is nothing to roll back to
    api.post("cat", f"/listings/{lid}/rollback", {"reason": "test rollback"}, expect=409)
