"""Requirement states, documentation review, licence decisions, jobs and audit."""
from datetime import timedelta

import pytest
from sqlalchemy import update

from foundry import audit, jobs, licensing, scanners, support
from foundry.db import session_scope, utcnow
from foundry.models import AuditEvent, Job
from foundry.packaging import ean13_bits, gtin_check_digit, valid_gtin13
from tests.conftest import new_product, prepare_release


def test_requirement_states_are_distinct(api):
    p = api.post("pm", "/projects", {"slug": "req-states", "name": "Req states"})
    r = api.post("pm", f"/projects/{p['id']}/requirements", {"key": "REQ-100", "category": "functional", "title": "x"})
    t = api.post("pm", f"/projects/{p['id']}/tasks", {"title": "do x", "requirement_ids": [r["id"]]})
    api.patch("dev", f"/tasks/{t['id']}", {"status": "done"})
    req = api.get("pm", f"/projects/{p['id']}/requirements")[0]
    assert req["status"] == "proposed" and req["tasks_done"]  # finishing the task proves nothing
    api.patch("pm", f"/requirements/{r['id']}", {"status": "tested"}, expect=409)
    api.patch("pm", f"/requirements/{r['id']}", {"status": "accepted"}, expect=409)
    api.post("reviewer", f"/requirements/{r['id']}/accept", expect=409)
    api.patch("dev", f"/requirements/{r['id']}", {"status": "implemented"})
    api.post("qe", f"/requirements/{r['id']}/evidence", {"kind": "manual", "result": "passed", "reference": "QA-1"})
    assert api.post("reviewer", f"/requirements/{r['id']}/accept")["status"] == "accepted"
    after = api.post("qe", f"/requirements/{r['id']}/evidence", {"kind": "manual", "result": "failed", "reference": "QA-2"})
    assert after["status"] == "implemented"  # failing evidence withdraws acceptance


def test_failed_build_preserved_and_retry_is_new_build(api, built):
    b = built["build"]
    retry = api.post("dev", f"/builds/{b['id']}/retry")
    assert retry["id"] != b["id"] and retry["retry_of_id"] == b["id"] and retry["commit_sha"] == b["commit_sha"]
    api.post("dev", f"/builds/{retry['id']}/cancel")
    assert api.get("dev", f"/builds/{retry['id']}")["status"] == "cancelled"
    assert api.get("dev", f"/builds/{b['id']}")["status"] == "passed"


def test_build_records_provenance(api, built):
    b = api.get("dev", f"/builds/{built['build']['id']}")
    assert len(b["commit_sha"]) == 40 and b["pipeline_sha256"] and b["lockfiles"]["requirements.lock"] != "MISSING"
    assert b["worker_env"]["sandbox"] == "local" and b["worker_env"]["network"] == "isolated namespace"
    for s in b["stages"]:
        assert s["status"] == "passed" and s["log_key"] and s["duration_ms"] is not None
    assert all(len(a["sha256"]) == 64 for a in b["artifacts"])
    assert {s["tool"] for s in b["scans"]} == {"foundry-dependency-audit", "foundry-secret-scan"}
    assert all(s["tool_version"] and s["scanned_at"] and "not" in s["limitations"] for s in b["scans"])
    assert [c["name"] for c in b["sbom"]] == ["tabulate"] and b["sbom"][0]["licence_declared"] == "MIT"


def test_documentation_flags_and_examples_gate_approval(api, built):
    pr, eds = new_product(api, built)
    rid = api.post("dev", f"/products/{pr['id']}/releases", {"version": "1.0.0", "build_id": built["build"]["id"]})["id"]
    api.patch("rm", f"/releases/{rid}", {"platform_claims": ["linux-x86_64", "windows-x86_64"]})
    docs = {d["kind"]: d for d in api.post("docs", f"/releases/{rid}/documents/generate", {})}
    sysreq = docs["system-requirements"]
    assert any(f["severity"] == "unsupported" and "windows" in f["text"] for f in sysreq["flags"])
    api.post("docs", f"/documents/{sysreq['id']}/submit")
    api.post("docs", f"/documents/{sysreq['id']}/approve", expect=409)
    qs = docs["quick-start"]
    api.post("docs", f"/documents/{qs['id']}/submit")
    r = api.post("docs", f"/documents/{qs['id']}/approve", expect=409)
    assert "examples" in str(r)
    new = api.req("docs", "PUT", f"/documents/{qs['id']}", json={"body": qs["body"] + "\nOur tool is 100% secure.\n"})
    assert new["revision"] == qs["revision"] + 1 and any("100% secure" in f["text"] for f in new["flags"])


def test_assistant_changes_go_to_a_reviewable_branch(api, built):
    run = api.post("dev", f"/projects/{built['project_id']}/assistant", {
        "action": "draft-tests", "repository_id": built["repo_id"], "commit": "main",
        "paths": ["src/csv_workshop/summary.py"]})
    assert run["branch"].startswith("assistant/run-") and run["build_id"] and run["patch_artifact_id"]
    assert run["inputs_manifest"][0]["sha256"] and "content" not in str(run["inputs_manifest"])
    assert run["model_config"]["provider"] == "offline"
    b = api.get("dev", f"/builds/{run['build_id']}")
    assert b["trigger"] == "assistant"
    from foundry.gitadapter import LocalGitAdapter
    ad = LocalGitAdapter(str(built["repo"]))
    assert ad.resolve("main") == built["build"]["commit_sha"]  # protected branch untouched
    api.post("dev", f"/projects/{built['project_id']}/assistant", {"action": "explain", "repository_id": built["repo_id"],
                                                                   "paths": []}, expect=422)
    api.post("pm", f"/projects/{built['project_id']}/assistant", {"action": "explain"}, expect=403)


def test_licence_rules():
    assert licensing.classify("MIT") == "permissive"
    assert licensing.classify("GPL-3.0-only") == "strong-copyleft"
    assert licensing.classify("MIT OR GPL-3.0-only") == "permissive"
    assert licensing.classify("NOASSERTION") == "unknown"
    assert licensing.route("strong-copyleft", "binary-only")
    assert licensing.route("unknown", "binary-only")
    assert licensing.route("permissive", "binary-only") is None


def test_licence_versions_never_transfer_copyright_and_freeze_on_approval(api):
    from tests.conftest import STD_RIGHTS
    api.post("licence", "/licence-versions", {"code": "BAD", "version": "1", "title": "t", "summary": "s", "text": "t",
                                              "rights": {**STD_RIGHTS, "copyright_transfer": True}}, expect=422)
    api.post("licence", "/licence-versions", {"code": "BAD2", "version": "1", "title": "t", "summary": "s", "text": "t",
                                              "rights": {"binary_distribution": True}}, expect=422)
    lv = api.post("licence", "/licence-versions", {"code": "OK", "version": "1", "title": "t", "summary": "s",
                                                   "text": "t", "rights": STD_RIGHTS})
    api.post("licence", f"/licence-versions/{lv['id']}/approve")
    api.patch("licence", f"/licence-versions/{lv['id']}", {"text": "changed"}, expect=409)


def test_dependency_audit_reports_tool_and_never_claims_safety(tmp_path):
    (tmp_path / "req.lock").write_text("foundry-fixture-vulnerable==1.0.0\nother==2.0\n")
    rep = scanners.dependency_audit(tmp_path, ["req.lock"])
    assert rep["findings"][0]["identifier"] == "FDY-FIXTURE-0001"
    assert rep["tool_version"] and rep["database_version"] and "not evidence" in rep["limitations"]
    (tmp_path / "k.txt").write_text("key = AKIAABCDEFGHIJKLMNOP\n")
    assert scanners.secret_scan(tmp_path)["findings"][0]["identifier"] == "aws-access-key"


def test_redaction():
    text, kinds = support.redact("Mail ada@example.net or +44 20 7946 0958; file /home/ada/x.csv by Ada Lovelace",
                                 ["Ada Lovelace"])
    assert "ada@example.net" not in text and "7946" not in text and "/home/ada" not in text and "Lovelace" not in text
    assert set(kinds) == {"email", "phone", "user-path", "customer-name"}


def test_gtin_validation_and_encoding():
    assert gtin_check_digit("590123412345") == 7
    assert valid_gtin13("5901234123457") and not valid_gtin13("5901234123458")
    bits = ean13_bits("5901234123457")
    assert len(bits) == 95 and bits.startswith("101") and bits.endswith("101")


def test_jobs_bounded_retries_and_dead_letter():
    @jobs.handler("test.always_fails")
    def _fail(db, job):
        raise RuntimeError("boom")
    with session_scope() as db:
        jid = jobs.enqueue(db, "test.always_fails", {}, max_attempts=3).id
    jobs.drain(kinds=["test.always_fails"], include_delayed=True)
    with session_scope() as db:
        j = db.get(Job, jid)
        assert j.status == "dead" and j.attempts == 3 and len(j.history) == 3


def test_jobs_idempotency_and_stale_recovery():
    with session_scope() as db:
        a = jobs.enqueue(db, "test.noop", {}, idempotency_key="same")
        b = jobs.enqueue(db, "test.noop", {}, idempotency_key="same")
        assert a.id == b.id
        a.status, a.heartbeat_at = "running", utcnow() - timedelta(minutes=10)
    with session_scope() as db:
        assert jobs.recover_stale(db) >= 1
        assert db.get(Job, a.id).status == "failed"
        db.get(Job, a.id).status = "cancelled"


def test_audit_chain_detects_tampering(api):
    with session_scope() as db:
        assert audit.verify_chain(db)["valid"]
        ev = db.query(AuditEvent).order_by(AuditEvent.id).first()
        original = ev.detail
        db.execute(update(AuditEvent).where(AuditEvent.id == ev.id).values(detail={"forged": True}))
    with session_scope() as db:
        res = audit.verify_chain(db)
        assert not res["valid"] and res["broken_at"] == ev.id
        db.execute(update(AuditEvent).where(AuditEvent.id == ev.id).values(detail=original))
    with session_scope() as db:
        assert audit.verify_chain(db)["valid"]
