"""Update eligibility comes only from the purchased entitlement."""
from datetime import datetime, timedelta, timezone

import itertools

import pytest

from foundry.db import session_scope
from foundry.models import Edition, Entitlement, Product, Release, ReleaseEdition
from foundry.support import eligible_release_ids

NOW = datetime.now(timezone.utc)
_SEQ = itertools.count(1)


@pytest.fixture
def catalogue():
    with session_scope() as db:
        from foundry.models import Project
        n = next(_SEQ)
        p = Project(slug=f"ent-project-{n}", name="Entitlement fixture")
        db.add(p)
        db.flush()
        prod = Product(project_id=p.id, slug=f"ent-product-{n}", name="Ent")
        db.add(prod)
        db.flush()
        eds = {}
        for code, kind in (("dig", "digital-download"), ("src", "source-archive")):
            e = Edition(product_id=prod.id, code=code, name=code, kind=kind, sku=f"ENT-{code}-{prod.id}")
            db.add(e)
            db.flush()
            eds[code] = e.id
        bundle = Edition(product_id=prod.id, code="bun", name="bundle", kind="bundle", sku=f"ENT-bun-{prod.id}",
                         bundle_edition_ids=[eds["dig"], eds["src"]])
        db.add(bundle)
        db.flush()
        eds["bun"] = bundle.id
        rels = {}
        for v, days_ago, status, in_eds in (("1.0.0", 400, "superseded", ["dig", "src"]),
                                            ("1.1.0", 200, "superseded", ["dig", "src"]),
                                            ("1.1.1", 100, "withdrawn", ["dig", "src"]),
                                            ("1.2.0", 10, "published", ["dig"]),
                                            ("2.0.0", 5, "published", ["dig", "src"])):
            r = Release(project_id=p.id, product_id=prod.id, version=v, status="draft")
            db.add(r)
            db.flush()
            for code in in_eds:
                db.add(ReleaseEdition(release_id=r.id, edition_id=eds[code]))
            db.flush()
            r.status, r.published_at = status, NOW - timedelta(days=days_ago)
            rels[v] = r.id
    return eds, rels


def ent(db, edition, purchased_version_id, days_ago, policy, status="active"):
    e = Entitlement(external_id=f"t-{next(_SEQ)}", customer_ref="c", edition_id=edition,
                    purchased_release_id=purchased_version_id, order_ref="o",
                    purchased_at=NOW - timedelta(days=days_ago), update_policy=policy, status=status)
    db.add(e)
    db.flush()
    return e


def versions(db, ids):
    return [db.get(Release, i).version for i in ids]


def test_major_versions_and_window(catalogue):
    eds, rels = catalogue
    with session_scope() as db:
        e = ent(db, eds["dig"], rels["1.1.0"], 200, {"covered_major_versions": [1], "updates_for_days": 365})
        assert versions(db, eligible_release_ids(db, e)) == ["1.1.0", "1.2.0"]  # no 1.0.0 (older), 1.1.1 withdrawn, 2.0 not covered


def test_update_window_expiry(catalogue):
    eds, rels = catalogue
    with session_scope() as db:
        e = ent(db, eds["dig"], rels["1.0.0"], 400, {"covered_major_versions": [1], "updates_for_days": 30})
        assert versions(db, eligible_release_ids(db, e)) == ["1.0.0"]


def test_other_editions_never_included(catalogue):
    eds, rels = catalogue
    with session_scope() as db:
        e = ent(db, eds["src"], rels["1.1.0"], 200, {"covered_major_versions": [1, 2], "updates_for_days": 365})
        assert versions(db, eligible_release_ids(db, e)) == ["1.1.0", "2.0.0"]  # 1.2.0 shipped only in the digital edition


def test_patch_only_policy(catalogue):
    eds, rels = catalogue
    with session_scope() as db:
        e = ent(db, eds["dig"], rels["1.1.0"], 200, {"covered_major_versions": [1], "updates_for_days": 365,
                                                       "patch_updates_only": True})
        assert versions(db, eligible_release_ids(db, e)) == ["1.1.0"]


def test_bundle_includes_component_editions(catalogue):
    eds, rels = catalogue
    with session_scope() as db:
        e = ent(db, eds["bun"], rels["1.1.0"], 200, {"covered_major_versions": [1, 2], "updates_for_days": 365})
        assert versions(db, eligible_release_ids(db, e)) == ["1.1.0", "1.2.0", "2.0.0"]


def test_refunded_entitlement_gets_nothing(catalogue):
    eds, rels = catalogue
    with session_scope() as db:
        e = ent(db, eds["dig"], rels["1.1.0"], 10, {"covered_major_versions": [1]}, status="refunded")
        assert eligible_release_ids(db, e) == []


def test_storefront_rule_matches_foundry_rule():
    from tests.conftest import load_storefront
    sf = load_storefront()
    state = {"editions": {}, "releases": {"ed1@1.0.0": {"status": "available", "available_at": NOW.isoformat()},
                                         "ed1@2.0.0": {"status": "available", "available_at": NOW.isoformat()},
                                         "ed1@1.0.1": {"status": "withdrawn", "available_at": NOW.isoformat()}}}
    e = {"status": "active", "edition_id": "ed1", "purchased_version": "1.0.0", "purchased_at": NOW.isoformat(),
         "update_policy": {"covered_major_versions": [1], "updates_for_days": 365}}
    assert sf.eligibility(state, e, "ed1", "1.0.0")[0]
    assert not sf.eligibility(state, e, "ed1", "2.0.0")[0]
    assert not sf.eligibility(state, e, "ed1", "1.0.1")[0]
    assert not sf.eligibility(state, e, "ed2", "1.0.0")[0]
