"""Permissions are enforced by the backend, and approval duties are separated."""
import pytest

from foundry.security import PERMISSIONS


def test_unauthenticated_requests_are_rejected(api):
    assert api.req(None, "GET", "/projects", expect=401)
    api.req(None, "GET", "/overview", expect=401)


def test_bad_token_rejected(client):
    r = client.get("/api/v1/projects", headers={"Authorization": "Bearer not-a-token"})
    assert r.status_code == 401


@pytest.mark.parametrize("perm", ["release.approve", "catalogue.approve", "licence.approve", "licence.review",
                                  "docs.approve", "requirement.accept", "catalogue.publish", "release.withdraw"])
def test_administrators_are_not_superusers_for_decisions(perm):
    assert "administrator" not in PERMISSIONS[perm]
    assert "assistant" not in PERMISSIONS[perm]


def test_assistant_identity_has_no_permissions():
    assert not any("assistant" in roles for roles in PERMISSIONS.values())


def test_service_identity_cannot_log_in(api):
    api.req(None, "POST", "/auth/login", expect=401, json={"email": "assistant@foundry.invalid", "password": "!"})


def test_role_boundaries_on_endpoints(api):
    api.post("dev", "/projects", {"slug": "dev-cannot", "name": "x"}, expect=403)
    api.post("admin", "/licence-versions", {"code": "A", "version": "1", "title": "t", "summary": "s", "text": "t",
                                            "rights": {}}, expect=403)
    api.post("cat", "/releases/1/approve", {}, expect=403)
    api.post("dev", "/users", {"email": "x@y.z", "name": "x", "password": "p", "roles": ["administrator"]}, expect=403)
    api.post("admin", "/users", {"email": "bot@y.z", "name": "x", "password": "p", "roles": ["assistant"]}, expect=422)


def test_private_customer_contact_restricted(api):
    for who in ("dev", "pm", "admin", "qe"):
        api.get(who, "/support/issues/1/contact", expect=403)


def test_role_change_is_audited(api):
    u = api.post("admin", "/users", {"email": "temp.dev@codeexchange.example", "name": "Temp", "password": "pw-123456",
                                     "roles": ["developer"]})
    api.patch("admin", f"/users/{u['id']}", {"roles": ["developer", "reviewer"]})
    events = api.get("admin", f"/audit?entity_type=user&entity_id={u['id']}")
    assert any(e["action"] == "user.roles_changed" for e in events)
