import pytest

from foundry.gitadapter import GitError, LocalGitAdapter, allowed_local_path
from foundry.pipeline import PipelineError, parse
from tests.conftest import make_repo

GOOD = """
version = 1
[[stages]]
name = "deps"
run = "true"
lockfiles = ["requirements.lock"]
[[stages]]
name = "test"
needs = ["deps"]
run = "true"
reports = { junit = "r.xml" }
artifacts = [{ path = "dist/*.pyz", role = "application" }]
"""


def test_pipeline_parses_and_hashes_stably():
    p = parse(GOOD)
    assert [s.name for s in p.stages] == ["deps", "test"]
    assert p.lockfiles() == ["requirements.lock"]
    assert p.sha256() == parse(GOOD).sha256()


@pytest.mark.parametrize("text,msg", [
    ("version = 2\n[[stages]]\nname='a'\nrun='x'", "version"),
    ("version = 1\n[[stages]]\nname='a'\nrun='x'\nneeds=['b']", "declared earlier"),
    ("version = 1\n[[stages]]\nname='a'\nrun='x'\nretries=9", "retries"),
    ("version = 1\n[[stages]]\nname='a'\nrun='x'\nnetwork='host'", "network"),
    ("version = 1\n[[stages]]\nname='a'\nuses='evil/tool'", "builtin"),
    ("version = 1\n[[stages]]\nname='a'\nrun='x'\nartifacts=[{path='../x',role='application'}]", "relative"),
])
def test_pipeline_rejects_unsafe_definitions(text, msg):
    with pytest.raises(PipelineError, match=msg):
        parse(text)


def test_repository_roots_enforced():
    with pytest.raises(GitError, match="outside"):
        allowed_local_path("/etc")


def test_refs_and_paths_validated():
    repo = make_repo("git-validate")
    ad = LocalGitAdapter(str(repo))
    for bad in ("--upload-pack=evil", "main..other", "a b"):
        with pytest.raises(GitError):
            ad.resolve(bad)
    with pytest.raises(GitError):
        ad.read_file("main", "../../etc/passwd")


def test_build_identity_is_immutable_commit_and_archive_has_no_git(tmp_path):
    repo = make_repo("git-archive")
    ad = LocalGitAdapter(str(repo))
    sha = ad.resolve("main")
    assert len(sha) == 40
    ad.archive_to(sha, tmp_path / "out")
    assert (tmp_path / "out" / ".foundry" / "pipeline.toml").exists()
    assert not (tmp_path / "out" / ".git").exists()


def test_assistant_writes_refuse_protected_branches():
    repo = make_repo("git-protect")
    ad = LocalGitAdapter(str(repo))
    sha = ad.resolve("main")
    with pytest.raises(GitError, match="protected"):
        ad.commit_files_to_branch(sha, "main", {"x.txt": "x"}, "m", "bot", ["main"])
    new = ad.commit_files_to_branch(sha, "assistant/t1", {"x.txt": "x"}, "m", "bot", ["main"])
    assert ad.resolve("main") == sha  # protected branch untouched
    assert ad.read_file(new, "x.txt")["content"] == "x"
