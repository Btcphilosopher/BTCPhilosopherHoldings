"""Restricted, disposable execution of untrusted project commands.

Two implementations share one interface:

DockerSandbox (production / docker compose)
    Every stage runs in a brand-new container that is removed afterwards:
    ``--network none`` (unless the stage is granted the egress network), read-only root
    filesystem, all capabilities dropped, ``no-new-privileges``, non-root uid 65534, memory,
    CPU and PID limits, a small tmpfs, and no bind mounts at all. The workspace is copied in
    and out with ``docker cp`` so no host path, secret or container socket is ever visible to
    the build. The worker talks to Docker through a filtered socket proxy; builds never do.

LocalSandbox (development and the test suite)
    A fresh network namespace (``unshare --net``: no interfaces except a down loopback),
    privileges dropped to uid 65534 via ``setpriv --no-new-privs`` when the worker runs as
    root, POSIX rlimits for address space / CPU / file size / processes, a scrubbed
    environment, its own process group (killed on timeout or cancellation) and a throwaway
    working directory. It is NOT a filesystem boundary equivalent to a container: files that
    are world-readable on the worker host remain readable. Use Docker for untrusted code.
"""
from __future__ import annotations

import io
import os
import resource
import shutil
import signal
import subprocess
import tarfile
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from foundry import config

NOBODY = 65534
CONTAINER_WS = "/workspace/ws"
SAFE_ENV_KEYS = ("LANG", "LC_ALL", "TZ")


class SandboxUnavailable(Exception):
    pass


@dataclass
class StageResult:
    exit_code: int | None
    status: str  # passed | failed | timeout | cancelled | error
    duration_ms: int
    resources: dict = field(default_factory=dict)
    error: str | None = None


def build_env(extra: dict[str, str] | None, workdir: str) -> dict[str, str]:
    """Only an allow-listed environment reaches build commands — never the worker's own."""
    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": f"{workdir}/.home", "TMPDIR": f"{workdir}/.tmp",
           "PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "0", "SOURCE_DATE_EPOCH": "1700000000",
           "CI": "true", "FOUNDRY_WORKSPACE": workdir}
    for k in SAFE_ENV_KEYS:
        if k in os.environ:
            env[k] = os.environ[k]
    for k, v in (extra or {}).items():
        if k.upper().startswith(("FOUNDRY_SECRET", "AWS_", "FOUNDRY_DATABASE", "FOUNDRY_S3")):
            raise ValueError(f"environment variable {k} may not be passed to builds")
        env[k] = str(v)
    return env


class LocalSandbox:
    name = "local"

    def __init__(self, memory_mb: int | None = None, timeout_s: int | None = None, max_procs: int | None = None):
        s = config.settings
        self.memory_mb = memory_mb or s.sandbox_memory_mb
        self.timeout_s = timeout_s or s.sandbox_timeout_s
        self.max_procs = max_procs or s.sandbox_pids
        self.is_root = os.geteuid() == 0
        self.unshare = shutil.which("unshare")
        self.setpriv = shutil.which("setpriv")
        self.netns = self._probe_netns()
        if not self.netns and config.settings.sandbox_require_netns:
            raise SandboxUnavailable("network namespaces unavailable; set FOUNDRY_SANDBOX=docker "
                                     "or FOUNDRY_SANDBOX_REQUIRE_NETNS=false (development only)")

    def _probe_netns(self) -> str | None:
        if not self.unshare:
            return None
        for args in (["--net"], ["--user", "--map-root-user", "--net"]):
            try:
                if subprocess.run([self.unshare, *args, "true"], capture_output=True, timeout=5).returncode == 0:
                    return " ".join(args)
            except Exception:
                continue
        return None

    def describe(self) -> dict:
        return {"sandbox": "local", "network": "isolated namespace" if self.netns else "NOT ISOLATED",
                "netns_mode": self.netns, "uid": NOBODY if (self.is_root and self.setpriv) else os.geteuid(),
                "memory_mb": self.memory_mb, "timeout_s": self.timeout_s, "max_procs": self.max_procs,
                "python": shutil.which("python3"), "kernel": os.uname().release,
                "filesystem_boundary": False}

    def prepare(self, workdir: Path) -> None:
        for sub in (".home", ".tmp"):
            (workdir / sub).mkdir(exist_ok=True)
        if self.is_root and self.setpriv:
            for anc in list(workdir.resolve().parents)[1:]:
                if not os.stat(anc).st_mode & 0o001:
                    raise SandboxUnavailable(f"{anc} is not traversable by the unprivileged build user; "
                                             "set FOUNDRY_WORK_ROOT to a directory such as /var/lib/foundry/work")
            for root, dirs, files in os.walk(workdir):
                os.chown(root, NOBODY, NOBODY)
                for f in files:
                    os.lchown(os.path.join(root, f), NOBODY, NOBODY)
            os.chown(workdir, NOBODY, NOBODY)
            os.chmod(workdir, 0o700)
            # parent must be traversable for uid 65534
            os.chmod(workdir.parent, 0o711)

    def _limits(self):
        mem = self.memory_mb * 1024 * 1024
        cpu = self.timeout_s
        nproc = self.max_procs

        def apply():
            os.setsid()
            resource.setrlimit(resource.RLIMIT_AS, (mem, mem))
            resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu))
            resource.setrlimit(resource.RLIMIT_FSIZE, (256 * 1024 * 1024, 256 * 1024 * 1024))
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            try:
                resource.setrlimit(resource.RLIMIT_NPROC, (nproc, nproc))
            except (ValueError, OSError):
                pass
        return apply

    def run(self, command: str, workdir: Path, log_path: Path, *, network: str = "none",
            env: dict | None = None, should_cancel: Callable[[], bool] = lambda: False,
            timeout_s: int | None = None) -> StageResult:
        if network != "none":
            # The local sandbox never grants network access; dependencies come from the wheelhouse.
            raise SandboxUnavailable(f"network mode {network!r} not supported by the local sandbox")
        argv: list[str] = []
        if self.netns:
            argv += [self.unshare, *self.netns.split()]
            if "--user" not in self.netns:
                argv += ["--"]
        if self.is_root and self.setpriv:
            argv += [self.setpriv, f"--reuid={NOBODY}", f"--regid={NOBODY}", "--clear-groups", "--no-new-privs"]
        argv += ["/bin/sh", "-c", command]
        timeout_s = timeout_s or self.timeout_s
        before = resource.getrusage(resource.RUSAGE_CHILDREN)
        start = time.monotonic()
        with open(log_path, "ab") as log:
            proc = subprocess.Popen(argv, cwd=workdir, env=build_env(env, str(workdir)), stdout=log,
                                    stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, preexec_fn=self._limits())
            status = None
            while proc.poll() is None:
                if time.monotonic() - start > timeout_s:
                    status = "timeout"
                elif should_cancel():
                    status = "cancelled"
                if status:
                    _kill_group(proc)
                    log.write(f"\n[foundry] stage {status}; process group killed\n".encode())
                    break
                time.sleep(0.1)
            proc.wait()
        after = resource.getrusage(resource.RUSAGE_CHILDREN)
        dur = int((time.monotonic() - start) * 1000)
        res = {"wall_ms": dur, "user_cpu_ms": int((after.ru_utime - before.ru_utime) * 1000),
               "system_cpu_ms": int((after.ru_stime - before.ru_stime) * 1000),
               "max_rss_kb": after.ru_maxrss}
        if status:
            return StageResult(proc.returncode, status, dur, res)
        return StageResult(proc.returncode, "passed" if proc.returncode == 0 else "failed", dur, res)

    def cleanup(self, workdir: Path) -> None:
        shutil.rmtree(workdir, ignore_errors=True)


def _kill_group(proc: subprocess.Popen) -> None:
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    except PermissionError:
        proc.kill()


def _tar_dir(src: Path, uid: int = NOBODY) -> bytes:
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w") as tf:
        def owner(ti: tarfile.TarInfo):
            ti.uid = ti.gid = uid
            ti.uname = ti.gname = ""
            return ti
        tf.add(str(src), arcname="ws", filter=owner)
    return buf.getvalue()


class DockerSandbox:
    name = "docker"

    def __init__(self, image: str | None = None):
        s = config.settings
        self.image = image or s.sandbox_image
        self.docker = shutil.which("docker")
        if not self.docker:
            raise SandboxUnavailable("docker CLI not found")
        probe = subprocess.run([self.docker, "version", "--format", "{{.Server.Version}}"], capture_output=True)
        if probe.returncode != 0:
            raise SandboxUnavailable("docker daemon not reachable: " + probe.stderr.decode()[:200])
        self.server_version = probe.stdout.decode().strip()
        self.egress_network = os.environ.get("FOUNDRY_SANDBOX_EGRESS_NETWORK")  # e.g. a proxy-only network
        self.s = s

    def _image_digest(self) -> str:
        r = subprocess.run([self.docker, "image", "inspect", "--format", "{{index .RepoDigests 0}}", self.image],
                           capture_output=True)
        return r.stdout.decode().strip() or self.image

    def describe(self) -> dict:
        return {"sandbox": "docker", "image": self.image, "image_digest": self._image_digest(),
                "docker_server": self.server_version, "network": "none", "read_only_rootfs": True,
                "cap_drop": "ALL", "no_new_privileges": True, "user": f"{NOBODY}:{NOBODY}",
                "memory_mb": self.s.sandbox_memory_mb, "cpus": self.s.sandbox_cpus, "pids": self.s.sandbox_pids,
                "timeout_s": self.s.sandbox_timeout_s, "bind_mounts": [], "filesystem_boundary": True}

    def prepare(self, workdir: Path) -> None:
        for sub in (".home", ".tmp"):
            (workdir / sub).mkdir(exist_ok=True)

    def run(self, command: str, workdir: Path, log_path: Path, *, network: str = "none",
            env: dict | None = None, should_cancel: Callable[[], bool] = lambda: False,
            timeout_s: int | None = None) -> StageResult:
        net = "none"
        if network == "egress":
            if not self.egress_network:
                raise SandboxUnavailable("stage requests egress but no FOUNDRY_SANDBOX_EGRESS_NETWORK is configured")
            net = self.egress_network
        name = f"foundry-stage-{uuid.uuid4().hex[:12]}"
        envargs: list[str] = []
        for k, v in build_env(env, CONTAINER_WS).items():
            envargs += ["-e", f"{k}={v}"]
        create = [self.docker, "create", "--name", name, "--network", net, "--read-only",
                  "--tmpfs", "/tmp:rw,noexec,nosuid,size=64m", "--cap-drop", "ALL",
                  "--security-opt", "no-new-privileges", "--pids-limit", str(self.s.sandbox_pids),
                  "--memory", f"{self.s.sandbox_memory_mb}m", "--memory-swap", f"{self.s.sandbox_memory_mb}m",
                  "--cpus", str(self.s.sandbox_cpus), "--user", f"{NOBODY}:{NOBODY}", "-v", "/workspace",
                  "-w", CONTAINER_WS, "--label", "foundry.sandbox=1", *envargs, self.image, "/bin/sh", "-c", command]
        start = time.monotonic()
        timeout_s = timeout_s or self.s.sandbox_timeout_s
        try:
            r = subprocess.run(create, capture_output=True)
            if r.returncode != 0:
                return StageResult(None, "error", 0, error=r.stderr.decode()[:500])
            # the read-only root cannot receive files; the anonymous volume can. The workspace goes in a
            # subdirectory owned by the build user (the volume root itself stays root-owned).
            cp = subprocess.run([self.docker, "cp", "-", f"{name}:/workspace"], input=_tar_dir(workdir),
                                capture_output=True)
            if cp.returncode != 0:
                return StageResult(None, "error", 0, error=cp.stderr.decode()[:500])
            status = None
            with open(log_path, "ab") as log:
                proc = subprocess.Popen([self.docker, "start", "-a", name], stdout=log, stderr=subprocess.STDOUT)
                while proc.poll() is None:
                    if time.monotonic() - start > timeout_s:
                        status = "timeout"
                    elif should_cancel():
                        status = "cancelled"
                    if status:
                        subprocess.run([self.docker, "kill", name], capture_output=True)
                        log.write(f"\n[foundry] stage {status}; container killed\n".encode())
                        break
                    time.sleep(0.2)
                proc.wait()
            insp = subprocess.run([self.docker, "inspect", "--format",
                                   "{{.State.ExitCode}} {{.State.OOMKilled}}", name], capture_output=True)
            code_s, oom = (insp.stdout.decode().split() + ["0", "false"])[:2]
            code = int(code_s)
            # copy the workspace back so later stages and artefact collection see outputs
            out = subprocess.run([self.docker, "cp", f"{name}:{CONTAINER_WS}/.", "-"], capture_output=True)
            if out.returncode == 0:
                shutil.rmtree(workdir)
                workdir.mkdir()
                with tarfile.open(fileobj=io.BytesIO(out.stdout)) as tf:
                    for m in tf.getmembers():
                        if m.name in (".", "./"):
                            continue
                        m.name = m.name[2:] if m.name.startswith("./") else m.name
                        tf.extract(m, workdir, filter="data")
            dur = int((time.monotonic() - start) * 1000)
            res = {"wall_ms": dur, "oom_killed": oom == "true",
                   "memory_limit_mb": self.s.sandbox_memory_mb, "cpus": self.s.sandbox_cpus}
            if status:
                return StageResult(code, status, dur, res)
            return StageResult(code, "passed" if code == 0 else "failed", dur, res)
        finally:
            subprocess.run([self.docker, "rm", "-f", "-v", name], capture_output=True)

    def cleanup(self, workdir: Path) -> None:
        shutil.rmtree(workdir, ignore_errors=True)


def get_sandbox():
    if config.settings.sandbox == "docker":
        return DockerSandbox()
    return LocalSandbox()
