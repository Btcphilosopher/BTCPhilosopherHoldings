"""Durable background jobs stored in PostgreSQL.

Workers claim jobs with ``SELECT ... FOR UPDATE SKIP LOCKED`` so several workers can run
safely. Failures are retried with bounded exponential backoff; when attempts are exhausted
the job becomes ``dead`` and keeps its error history. Jobs whose worker stops heartbeating are
returned to the queue.
"""
from __future__ import annotations

import logging
import socket
import traceback
from datetime import timedelta
from typing import Callable

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from foundry.db import session_scope, utcnow
from foundry.models import Job

log = logging.getLogger("foundry.jobs")

HANDLERS: dict[str, Callable[[Session, Job], dict | None]] = {}
STALE_AFTER = timedelta(minutes=5)


class Cancelled(Exception):
    pass


class PermanentFailure(Exception):
    """Raise from a handler when retrying cannot help."""


def handler(kind: str):
    def deco(fn):
        HANDLERS[kind] = fn
        return fn
    return deco


def enqueue(db: Session, kind: str, payload: dict, *, idempotency_key: str | None = None,
            max_attempts: int = 3, delay_s: float = 0) -> Job:
    if idempotency_key:
        existing = db.execute(select(Job).where(Job.idempotency_key == idempotency_key)).scalar_one_or_none()
        if existing:
            return existing
    job = Job(kind=kind, payload=payload, idempotency_key=idempotency_key, max_attempts=max_attempts,
              run_after=utcnow() + timedelta(seconds=delay_s), history=[])
    db.add(job)
    db.flush()
    return job


def backoff_seconds(attempt: int) -> float:
    return min(2 ** attempt, 60)


def claim(db: Session, worker_id: str, kinds: list[str] | None = None) -> Job | None:
    q = (select(Job).where(Job.status.in_(["queued", "failed"]), Job.run_after <= utcnow(),
                           Job.cancel_requested.is_(False))
         .order_by(Job.id).limit(1).with_for_update(skip_locked=True))
    if kinds:
        q = q.where(Job.kind.in_(kinds))
    job = db.execute(q).scalar_one_or_none()
    if job is None:
        return None
    job.status = "running"
    job.attempts += 1
    job.locked_by = worker_id
    job.locked_at = job.heartbeat_at = utcnow()
    db.flush()
    return job


def heartbeat(job_id: int) -> bool:
    """Returns True when cancellation was requested."""
    with session_scope() as db:
        job = db.get(Job, job_id)
        if job is None:
            return True
        job.heartbeat_at = utcnow()
        return bool(job.cancel_requested)


def request_cancel(db: Session, job: Job) -> None:
    job.cancel_requested = True
    if job.status in ("queued", "failed"):
        job.status = "cancelled"
        job.finished_at = utcnow()


def recover_stale(db: Session) -> int:
    cutoff = utcnow() - STALE_AFTER
    res = db.execute(update(Job).where(Job.status == "running", Job.heartbeat_at < cutoff)
                     .values(status="failed", locked_by=None, last_error="worker heartbeat lost"))
    return res.rowcount or 0


def _finish(job_id: int, status: str, *, result: dict | None = None, error: str | None = None) -> None:
    with session_scope() as db:
        job = db.get(Job, job_id)
        hist = list(job.history or [])
        hist.append({"attempt": job.attempts, "status": status, "at": utcnow().isoformat(),
                     "error": (error or "")[-2000:] or None})
        job.history = hist
        job.locked_by = None
        if status == "succeeded":
            job.status, job.result, job.finished_at = "succeeded", result, utcnow()
        elif status == "cancelled":
            job.status, job.finished_at, job.last_error = "cancelled", utcnow(), error
        elif status == "permanent" or job.attempts >= job.max_attempts:
            job.status, job.finished_at, job.last_error = "dead", utcnow(), error
        else:
            job.status, job.last_error = "failed", error
            job.run_after = utcnow() + timedelta(seconds=backoff_seconds(job.attempts))


def run_one(worker_id: str | None = None, kinds: list[str] | None = None) -> Job | None:
    """Claim and execute a single job. Returns the claimed job (detached) or None."""
    worker_id = worker_id or f"{socket.gethostname()}"
    with session_scope() as db:
        job = claim(db, worker_id, kinds)
        if job is None:
            return None
        job_id, kind = job.id, job.kind
    fn = HANDLERS.get(kind)
    try:
        if fn is None:
            raise PermanentFailure(f"no handler for job kind {kind}")
        with session_scope() as db:
            job = db.get(Job, job_id)
            result = fn(db, job)
        _finish(job_id, "succeeded", result=result or {})
    except Cancelled as exc:
        _finish(job_id, "cancelled", error=str(exc) or "cancelled")
    except PermanentFailure as exc:
        log.warning("job %s permanently failed: %s", job_id, exc)
        _finish(job_id, "permanent", error=str(exc))
    except Exception as exc:  # noqa: BLE001 - recorded and retried
        log.exception("job %s failed", job_id)
        _finish(job_id, "error", error=f"{exc}\n{traceback.format_exc()}")
    with session_scope() as db:
        return db.get(Job, job_id)


def drain(kinds: list[str] | None = None, limit: int = 100, include_delayed: bool = False) -> int:
    """Run queued jobs until none are ready (used by tests and the demo's in-process mode)."""
    n = 0
    while n < limit:
        if include_delayed:
            with session_scope() as db:
                db.execute(update(Job).where(Job.status.in_(["queued", "failed"]))
                           .values(run_after=utcnow()))
        if run_one(kinds=kinds) is None:
            break
        n += 1
    return n
