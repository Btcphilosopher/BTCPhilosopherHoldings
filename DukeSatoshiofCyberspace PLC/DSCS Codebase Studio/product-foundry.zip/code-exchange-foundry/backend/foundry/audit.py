"""Append-only, hash-chained audit log."""
from __future__ import annotations

import hashlib
import json
from typing import Any

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from foundry.models import AuditEvent, User

GENESIS = "0" * 64


def _digest(prev: str, ev: AuditEvent) -> str:
    body = json.dumps({
        "prev": prev, "at": ev.at.isoformat(), "actor": ev.actor_id, "actor_label": ev.actor_label,
        "action": ev.action, "entity_type": ev.entity_type, "entity_id": ev.entity_id,
        "project_id": ev.project_id, "detail": ev.detail,
    }, sort_keys=True, default=str)
    return hashlib.sha256(body.encode()).hexdigest()


def record(db: Session, actor: User | None, action: str, entity_type: str, entity_id: Any,
           project_id: int | None = None, **detail: Any) -> AuditEvent:
    if db.bind is not None and db.bind.dialect.name == "postgresql":
        db.execute(text("SELECT pg_advisory_xact_lock(727274)"))  # serialise chain appends
    last = db.execute(select(AuditEvent).order_by(AuditEvent.id.desc()).limit(1)).scalar_one_or_none()
    prev = last.hash if last else GENESIS
    from foundry.db import utcnow
    ev = AuditEvent(at=utcnow(), actor_id=actor.id if actor else None,
                    actor_label=(actor.email if actor else "system"), action=action,
                    entity_type=entity_type, entity_id=str(entity_id), project_id=project_id,
                    detail=json.loads(json.dumps(detail, default=str)), prev_hash=prev, hash="")
    ev.hash = _digest(prev, ev)
    db.add(ev)
    db.flush()
    return ev


def verify_chain(db: Session) -> dict:
    prev = GENESIS
    count = 0
    for ev in db.execute(select(AuditEvent).order_by(AuditEvent.id)).scalars():
        if ev.prev_hash != prev or _digest(prev, ev) != ev.hash:
            return {"valid": False, "broken_at": ev.id, "checked": count}
        prev = ev.hash
        count += 1
    return {"valid": True, "checked": count, "head": prev}
