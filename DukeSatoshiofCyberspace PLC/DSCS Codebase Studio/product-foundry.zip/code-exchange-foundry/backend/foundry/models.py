"""Authoritative records for Product Foundry.

Vocabulary (kept deliberately distinct):
  Project   - the development effort (repositories, requirements, tasks, builds).
  Product   - the commercial thing customers recognise ("CSV Workshop").
  Edition   - a purchasable configuration of a product (digital, source, boxed, ...),
              each with its own contents manifest and licence version.
  Release   - an immutable, versioned set of artefacts built from one fixed commit.
"""
from __future__ import annotations

from datetime import date, datetime
from typing import Any, Optional

from sqlalchemy import (JSON, Boolean, Date, DateTime, Float, ForeignKey, Integer, Numeric, String, Text,
                        UniqueConstraint, Index)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from foundry.db import Base, utcnow

TS = DateTime(timezone=True)


def _created() -> Mapped[datetime]:
    return mapped_column(TS, default=utcnow, nullable=False)


# ---------------------------------------------------------------- identity & audit
class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(200), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    password_hash: Mapped[str] = mapped_column(String(200))
    roles: Mapped[list] = mapped_column(JSON, default=list)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_service: Mapped[bool] = mapped_column(Boolean, default=False)  # e.g. the AI assistant identity
    created_at: Mapped[datetime] = _created()


class AuditEvent(Base):
    """Append-only, hash-chained audit trail."""
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    at: Mapped[datetime] = _created()
    actor_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    actor_label: Mapped[str] = mapped_column(String(200), default="system")
    action: Mapped[str] = mapped_column(String(100), index=True)
    entity_type: Mapped[str] = mapped_column(String(60))
    entity_id: Mapped[str] = mapped_column(String(60))
    project_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, index=True)
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    prev_hash: Mapped[str] = mapped_column(String(64))
    hash: Mapped[str] = mapped_column(String(64))


class Setting(Base):
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[Any] = mapped_column(JSON)


# ---------------------------------------------------------------- durable jobs
class Job(Base):
    __tablename__ = "jobs"
    id: Mapped[int] = mapped_column(primary_key=True)
    kind: Mapped[str] = mapped_column(String(60), index=True)
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(20), default="queued", index=True)
    # queued | running | succeeded | failed (will retry) | dead (retries exhausted) | cancelled
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, default=3)
    run_after: Mapped[datetime] = mapped_column(TS, default=utcnow)
    idempotency_key: Mapped[Optional[str]] = mapped_column(String(200), unique=True, nullable=True)
    locked_by: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    locked_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    heartbeat_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    cancel_requested: Mapped[bool] = mapped_column(Boolean, default=False)
    last_error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    result: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    history: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = _created()
    finished_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)


# ---------------------------------------------------------------- projects
class Project(Base):
    __tablename__ = "projects"
    id: Mapped[int] = mapped_column(primary_key=True)
    slug: Mapped[str] = mapped_column(String(80), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    idea: Mapped[str] = mapped_column(Text, default="")
    intended_customers: Mapped[str] = mapped_column(Text, default="")
    problem_statement: Mapped[str] = mapped_column(Text, default="")
    supported_platforms: Mapped[list] = mapped_column(JSON, default=list)  # claimed platforms
    tech_stack: Mapped[list] = mapped_column(JSON, default=list)
    owner_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    support_owner_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    intended_licence: Mapped[str] = mapped_column(String(200), default="")
    source_distribution_model: Mapped[str] = mapped_column(String(60), default="binary-only")
    status: Mapped[str] = mapped_column(String(30), default="idea")  # idea|development|release-prep|on-sale|retired
    dependencies_note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = _created()

    members: Mapped[list["ProjectMember"]] = relationship(cascade="all, delete-orphan")


class ProjectMember(Base):
    __tablename__ = "project_members"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    responsibility: Mapped[str] = mapped_column(String(100), default="contributor")
    __table_args__ = (UniqueConstraint("project_id", "user_id"),)


class CostEntry(Base):
    __tablename__ = "cost_entries"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    kind: Mapped[str] = mapped_column(String(20))  # estimate | recorded
    category: Mapped[str] = mapped_column(String(60), default="engineering")
    amount: Mapped[float] = mapped_column(Numeric(12, 2))
    currency: Mapped[str] = mapped_column(String(3), default="GBP")
    description: Mapped[str] = mapped_column(Text, default="")
    incurred_on: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    created_at: Mapped[datetime] = _created()


class Milestone(Base):
    __tablename__ = "milestones"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    title: Mapped[str] = mapped_column(String(200))
    due_on: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="open")


class Requirement(Base):
    """States: proposed -> implemented -> tested -> accepted (or rejected).

    'tested' is only reachable through passing evidence; 'accepted' only by a reviewer
    while the latest evidence passes. Completing tasks never changes this record.
    """
    __tablename__ = "requirements"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    key: Mapped[str] = mapped_column(String(30))
    category: Mapped[str] = mapped_column(String(30))
    # workflow|environment|functional|performance|accessibility|installation|data|support
    title: Mapped[str] = mapped_column(String(300))
    description: Mapped[str] = mapped_column(Text, default="")
    acceptance_criteria: Mapped[str] = mapped_column(Text, default="")
    required_for_release: Mapped[bool] = mapped_column(Boolean, default=True)
    status: Mapped[str] = mapped_column(String(20), default="proposed")
    accepted_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    accepted_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    created_at: Mapped[datetime] = _created()
    __table_args__ = (UniqueConstraint("project_id", "key"),)


class RequirementEvidence(Base):
    __tablename__ = "requirement_evidence"
    id: Mapped[int] = mapped_column(primary_key=True)
    requirement_id: Mapped[int] = mapped_column(ForeignKey("requirements.id"), index=True)
    kind: Mapped[str] = mapped_column(String(30))  # test | manual | document | build
    build_id: Mapped[Optional[int]] = mapped_column(ForeignKey("builds.id"), nullable=True)
    commit_sha: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    reference: Mapped[str] = mapped_column(String(400))
    result: Mapped[str] = mapped_column(String(20))  # passed | failed | skipped | observed
    note: Mapped[str] = mapped_column(Text, default="")
    recorded_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    recorded_at: Mapped[datetime] = _created()


class Task(Base):
    __tablename__ = "tasks"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    milestone_id: Mapped[Optional[int]] = mapped_column(ForeignKey("milestones.id"), nullable=True)
    title: Mapped[str] = mapped_column(String(300))
    description: Mapped[str] = mapped_column(Text, default="")
    assignee_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="todo")  # todo|in_progress|review|done
    requirement_ids: Mapped[list] = mapped_column(JSON, default=list)
    branch: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    external_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)  # PR / issue link
    proposed_by_assistant: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = _created()


# ---------------------------------------------------------------- repositories
class Repository(Base):
    __tablename__ = "repositories"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    provider: Mapped[str] = mapped_column(String(20))  # local | github | gitlab
    name: Mapped[str] = mapped_column(String(200))
    location: Mapped[str] = mapped_column(String(500))  # local path or owner/name
    web_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    default_branch: Mapped[str] = mapped_column(String(200), default="main")
    protected_branches: Mapped[list] = mapped_column(JSON, default=lambda: ["main"])
    credential_ref: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)  # name of a secret, never the value
    scopes: Mapped[list] = mapped_column(JSON, default=list)
    origin: Mapped[dict] = mapped_column(JSON, default=dict)  # provenance captured at connection time
    connected_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    connected_at: Mapped[datetime] = _created()
    active: Mapped[bool] = mapped_column(Boolean, default=True)


# ---------------------------------------------------------------- builds
class Build(Base):
    __tablename__ = "builds"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    repository_id: Mapped[int] = mapped_column(ForeignKey("repositories.id"))
    number: Mapped[int] = mapped_column(Integer)
    commit_sha: Mapped[str] = mapped_column(String(64), index=True)  # immutable identity of the input
    ref: Mapped[str] = mapped_column(String(200), default="")
    commit_message: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(20), default="queued")
    # queued|running|passed|failed|cancelled|error
    trigger: Mapped[str] = mapped_column(String(30), default="manual")
    triggered_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    retry_of_id: Mapped[Optional[int]] = mapped_column(ForeignKey("builds.id"), nullable=True)
    job_id: Mapped[Optional[int]] = mapped_column(ForeignKey("jobs.id"), nullable=True)
    pipeline: Mapped[dict] = mapped_column(JSON, default=dict)  # snapshot of the version-controlled pipeline
    pipeline_sha256: Mapped[str] = mapped_column(String(64), default="")
    worker_env: Mapped[dict] = mapped_column(JSON, default=dict)
    lockfiles: Mapped[dict] = mapped_column(JSON, default=dict)  # path -> sha256
    resources: Mapped[dict] = mapped_column(JSON, default=dict)
    summary: Mapped[dict] = mapped_column(JSON, default=dict)
    error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    cancel_requested: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = _created()
    started_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    finished_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    __table_args__ = (UniqueConstraint("project_id", "number"),)


class BuildStage(Base):
    __tablename__ = "build_stages"
    id: Mapped[int] = mapped_column(primary_key=True)
    build_id: Mapped[int] = mapped_column(ForeignKey("builds.id"), index=True)
    position: Mapped[int] = mapped_column(Integer)
    name: Mapped[str] = mapped_column(String(100))
    kind: Mapped[str] = mapped_column(String(20), default="command")  # command|builtin
    command: Mapped[str] = mapped_column(Text, default="")
    network: Mapped[str] = mapped_column(String(20), default="none")
    status: Mapped[str] = mapped_column(String(20), default="pending")
    # pending|running|passed|failed|skipped|cancelled|error
    exit_code: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    log_key: Mapped[Optional[str]] = mapped_column(String(300), nullable=True)
    log_tail: Mapped[str] = mapped_column(Text, default="")
    resources: Mapped[dict] = mapped_column(JSON, default=dict)
    started_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    finished_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    duration_ms: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)


class TestResult(Base):
    __tablename__ = "test_results"
    __test__ = False  # not a pytest class
    id: Mapped[int] = mapped_column(primary_key=True)
    build_id: Mapped[int] = mapped_column(ForeignKey("builds.id"), index=True)
    suite: Mapped[str] = mapped_column(String(200))
    name: Mapped[str] = mapped_column(String(300))
    status: Mapped[str] = mapped_column(String(20))  # passed|failed|error|skipped
    duration_ms: Mapped[int] = mapped_column(Integer, default=0)
    message: Mapped[str] = mapped_column(Text, default="")
    requirement_keys: Mapped[list] = mapped_column(JSON, default=list)
    platform: Mapped[Optional[str]] = mapped_column(String(60), nullable=True)


class Artifact(Base):
    """Content-addressed build output. Bytes are never overwritten once stored."""
    __tablename__ = "artifacts"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    build_id: Mapped[Optional[int]] = mapped_column(ForeignKey("builds.id"), nullable=True, index=True)
    role: Mapped[str] = mapped_column(String(40))
    # application|source|docs-html|docs-pdf|notices|sbom|starter-kit|artwork|edition-package|log
    filename: Mapped[str] = mapped_column(String(300))
    storage_key: Mapped[str] = mapped_column(String(400))
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    size: Mapped[int] = mapped_column(Integer)
    media_type: Mapped[str] = mapped_column(String(100), default="application/octet-stream")
    produced_by: Mapped[str] = mapped_column(String(100), default="pipeline")
    locked: Mapped[bool] = mapped_column(Boolean, default=False)  # set when referenced by an approved release
    created_at: Mapped[datetime] = _created()


class ScanRun(Base):
    __tablename__ = "scan_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    build_id: Mapped[int] = mapped_column(ForeignKey("builds.id"), index=True)
    tool: Mapped[str] = mapped_column(String(100))
    tool_version: Mapped[str] = mapped_column(String(60))
    database_version: Mapped[str] = mapped_column(String(100), default="")
    scanned_at: Mapped[datetime] = _created()
    finding_count: Mapped[int] = mapped_column(Integer, default=0)
    scope: Mapped[str] = mapped_column(Text, default="")
    limitations: Mapped[str] = mapped_column(Text, default="")


class ScanFinding(Base):
    __tablename__ = "scan_findings"
    id: Mapped[int] = mapped_column(primary_key=True)
    scan_run_id: Mapped[int] = mapped_column(ForeignKey("scan_runs.id"), index=True)
    build_id: Mapped[int] = mapped_column(ForeignKey("builds.id"), index=True)
    severity: Mapped[str] = mapped_column(String(20))
    identifier: Mapped[str] = mapped_column(String(100))
    component: Mapped[str] = mapped_column(String(200))
    title: Mapped[str] = mapped_column(String(400))
    detail: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(20), default="open")  # open|accepted-risk|fixed|false-positive


class SbomComponent(Base):
    __tablename__ = "sbom_components"
    id: Mapped[int] = mapped_column(primary_key=True)
    build_id: Mapped[int] = mapped_column(ForeignKey("builds.id"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    version: Mapped[str] = mapped_column(String(60))
    purl: Mapped[str] = mapped_column(String(300))
    licence_declared: Mapped[str] = mapped_column(String(200), default="NOASSERTION")
    licence_source: Mapped[str] = mapped_column(String(200), default="")
    origin: Mapped[str] = mapped_column(String(300), default="")
    sha256: Mapped[str] = mapped_column(String(64), default="")
    scope: Mapped[str] = mapped_column(String(20), default="runtime")  # runtime|build|test
    licence_text_key: Mapped[Optional[str]] = mapped_column(String(400), nullable=True)
    attribution: Mapped[str] = mapped_column(Text, default="")


# ---------------------------------------------------------------- licensing & provenance
class Contributor(Base):
    __tablename__ = "contributors"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    relationship_: Mapped[str] = mapped_column("relationship", String(40))  # employee|contractor|external
    ownership: Mapped[str] = mapped_column(String(200))  # e.g. "assigned to The Code Exchange Ltd"
    agreement_ref: Mapped[str] = mapped_column(String(200), default="")
    verified: Mapped[bool] = mapped_column(Boolean, default=False)


class ProvenanceAsset(Base):
    """Source origins and non-code assets (artwork, fonts, sample data)."""
    __tablename__ = "provenance_assets"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    path: Mapped[str] = mapped_column(String(400))
    kind: Mapped[str] = mapped_column(String(30))  # source|artwork|font|data|documentation
    origin: Mapped[str] = mapped_column(String(400))
    licence: Mapped[str] = mapped_column(String(200))
    attribution: Mapped[str] = mapped_column(Text, default="")
    restrictions: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(20), default="unreviewed")  # unreviewed|cleared|blocked|replaced


class LicenceVersion(Base):
    """A commercial licence text with explicit, separate rights. Immutable once approved."""
    __tablename__ = "licence_versions"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[Optional[int]] = mapped_column(ForeignKey("projects.id"), nullable=True)
    code: Mapped[str] = mapped_column(String(60))
    version: Mapped[str] = mapped_column(String(20))
    title: Mapped[str] = mapped_column(String(200))
    summary: Mapped[str] = mapped_column(Text, default="")
    text: Mapped[str] = mapped_column(Text, default="")
    rights: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(20), default="draft")  # draft|approved|retired
    text_sha256: Mapped[str] = mapped_column(String(64), default="")
    approved_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    approved_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    created_at: Mapped[datetime] = _created()
    __table_args__ = (UniqueConstraint("code", "version"),)


class LicenceReview(Base):
    __tablename__ = "licence_reviews"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    subject_type: Mapped[str] = mapped_column(String(30))  # component|asset|licence|contributor
    subject_ref: Mapped[str] = mapped_column(String(300))
    issue: Mapped[str] = mapped_column(Text)
    raised_by: Mapped[str] = mapped_column(String(100), default="licence-analyser")
    status: Mapped[str] = mapped_column(String(20), default="open")  # open|cleared|rejected|remediated
    decision: Mapped[str] = mapped_column(Text, default="")
    reviewer_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    decided_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    created_at: Mapped[datetime] = _created()


# ---------------------------------------------------------------- products & editions
class Product(Base):
    __tablename__ = "products"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    slug: Mapped[str] = mapped_column(String(80), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    tagline: Mapped[str] = mapped_column(String(300), default="")
    description: Mapped[str] = mapped_column(Text, default="")
    category: Mapped[str] = mapped_column(String(80), default="Developer tools")
    screenshots: Mapped[list] = mapped_column(JSON, default=list)  # artifact ids
    created_at: Mapped[datetime] = _created()


class Edition(Base):
    __tablename__ = "editions"
    id: Mapped[int] = mapped_column(primary_key=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), index=True)
    code: Mapped[str] = mapped_column(String(60))
    name: Mapped[str] = mapped_column(String(200))
    kind: Mapped[str] = mapped_column(String(30))
    # digital-download|source-archive|developer-kit|boxed-key|usb-collector|bundle
    licence_version_id: Mapped[Optional[int]] = mapped_column(ForeignKey("licence_versions.id"), nullable=True)
    contents: Mapped[list] = mapped_column(JSON, default=list)  # artefact roles included, e.g. ["application","docs-html"]
    bundle_edition_ids: Mapped[list] = mapped_column(JSON, default=list)
    sku: Mapped[str] = mapped_column(String(60), unique=True)
    gtin: Mapped[Optional[str]] = mapped_column(String(14), nullable=True)  # only a configured, allocated number
    price: Mapped[dict] = mapped_column(JSON, default=dict)  # {"currency":"GBP","amount":"29.00","tax_inclusive":true}
    delivery_method: Mapped[str] = mapped_column(String(40), default="download")  # download|download-key|physical
    update_policy: Mapped[dict] = mapped_column(JSON, default=dict)
    # {"covered_major_versions":[1], "updates_for_days": 365, "includes_future_editions": false}
    support_terms: Mapped[str] = mapped_column(Text, default="")
    support_days: Mapped[int] = mapped_column(Integer, default=365)
    physical: Mapped[dict] = mapped_column(JSON, default=dict)  # packaging template id, media, etc.
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    __table_args__ = (UniqueConstraint("product_id", "code"),)


# ---------------------------------------------------------------- documentation
class DocTemplate(Base):
    __tablename__ = "doc_templates"
    id: Mapped[int] = mapped_column(primary_key=True)
    kind: Mapped[str] = mapped_column(String(40))
    version: Mapped[int] = mapped_column(Integer)
    title: Mapped[str] = mapped_column(String(200))
    body: Mapped[str] = mapped_column(Text)
    created_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = _created()
    __table_args__ = (UniqueConstraint("kind", "version"),)


class Document(Base):
    __tablename__ = "documents"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    release_id: Mapped[Optional[int]] = mapped_column(ForeignKey("releases.id"), nullable=True)
    kind: Mapped[str] = mapped_column(String(40))
    title: Mapped[str] = mapped_column(String(200))
    revision: Mapped[int] = mapped_column(Integer, default=1)
    body: Mapped[str] = mapped_column(Text)
    template_id: Mapped[Optional[int]] = mapped_column(ForeignKey("doc_templates.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="draft")  # draft|in-review|approved
    origin: Mapped[str] = mapped_column(String(20), default="template")  # template|human|assistant
    flags: Mapped[list] = mapped_column(JSON, default=list)  # unsupported statements etc.
    example_results: Mapped[list] = mapped_column(JSON, default=list)
    reviewed_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    html_artifact_id: Mapped[Optional[int]] = mapped_column(ForeignKey("artifacts.id"), nullable=True)
    pdf_artifact_id: Mapped[Optional[int]] = mapped_column(ForeignKey("artifacts.id"), nullable=True)
    locked: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = _created()
    updated_at: Mapped[datetime] = _created()


# ---------------------------------------------------------------- packaging artwork
class PackagingTemplate(Base):
    __tablename__ = "packaging_templates"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    kind: Mapped[str] = mapped_column(String(40))  # dvd-style-box|usb-tin|key-card
    dimensions: Mapped[dict] = mapped_column(JSON)
    # {"front_w_mm":135,"h_mm":190,"spine_mm":14,"bleed_mm":3,"safe_mm":5,"min_dpi":300}


class Artwork(Base):
    __tablename__ = "artworks"
    id: Mapped[int] = mapped_column(primary_key=True)
    edition_id: Mapped[int] = mapped_column(ForeignKey("editions.id"), index=True)
    release_id: Mapped[Optional[int]] = mapped_column(ForeignKey("releases.id"), nullable=True)
    template_id: Mapped[int] = mapped_column(ForeignKey("packaging_templates.id"))
    purpose: Mapped[str] = mapped_column(String(20))  # mockup|print
    artifact_id: Mapped[Optional[int]] = mapped_column(ForeignKey("artifacts.id"), nullable=True)
    validation: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(20), default="draft")  # draft|valid|invalid
    created_at: Mapped[datetime] = _created()


# ---------------------------------------------------------------- releases
class Release(Base):
    __tablename__ = "releases"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), index=True)
    version: Mapped[str] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(20), default="draft")
    # draft|candidate|validation|approved|published|superseded|withdrawn
    build_id: Mapped[Optional[int]] = mapped_column(ForeignKey("builds.id"), nullable=True)
    commit_sha: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    compatibility: Mapped[dict] = mapped_column(JSON, default=dict)
    platform_claims: Mapped[list] = mapped_column(JSON, default=list)
    licence_version_ids: Mapped[list] = mapped_column(JSON, default=list)
    manifest: Mapped[dict] = mapped_column(JSON, default=dict)  # frozen at candidate
    manifest_sha256: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    readiness_snapshot: Mapped[dict] = mapped_column(JSON, default=dict)
    created_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    approved_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    approved_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    published_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    superseded_by_id: Mapped[Optional[int]] = mapped_column(ForeignKey("releases.id"), nullable=True)
    withdrawn_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    end_of_support_on: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    history: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = _created()
    __table_args__ = (UniqueConstraint("product_id", "version"),)


class ReleaseArtifact(Base):
    __tablename__ = "release_artifacts"
    id: Mapped[int] = mapped_column(primary_key=True)
    release_id: Mapped[int] = mapped_column(ForeignKey("releases.id"), index=True)
    artifact_id: Mapped[int] = mapped_column(ForeignKey("artifacts.id"))
    role: Mapped[str] = mapped_column(String(40))
    __table_args__ = (UniqueConstraint("release_id", "artifact_id"),)


class ReleaseEdition(Base):
    __tablename__ = "release_editions"
    id: Mapped[int] = mapped_column(primary_key=True)
    release_id: Mapped[int] = mapped_column(ForeignKey("releases.id"), index=True)
    edition_id: Mapped[int] = mapped_column(ForeignKey("editions.id"))
    manifest: Mapped[dict] = mapped_column(JSON, default=dict)
    manifest_sha256: Mapped[str] = mapped_column(String(64), default="")
    package_artifact_id: Mapped[Optional[int]] = mapped_column(ForeignKey("artifacts.id"), nullable=True)
    __table_args__ = (UniqueConstraint("release_id", "edition_id"),)


class PlatformVerification(Base):
    __tablename__ = "platform_verifications"
    id: Mapped[int] = mapped_column(primary_key=True)
    release_id: Mapped[int] = mapped_column(ForeignKey("releases.id"), index=True)
    platform: Mapped[str] = mapped_column(String(60))
    method: Mapped[str] = mapped_column(String(30))  # build-worker|manual
    result: Mapped[str] = mapped_column(String(20))  # passed|failed
    evidence: Mapped[str] = mapped_column(Text, default="")
    build_id: Mapped[Optional[int]] = mapped_column(ForeignKey("builds.id"), nullable=True)
    recorded_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    recorded_at: Mapped[datetime] = _created()


class ReviewRecord(Base):
    """Human reviews feeding release readiness: accessibility, support readiness, installation."""
    __tablename__ = "review_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    release_id: Mapped[int] = mapped_column(ForeignKey("releases.id"), index=True)
    check_key: Mapped[str] = mapped_column(String(40))
    result: Mapped[str] = mapped_column(String(20))  # passed|failed
    evidence: Mapped[str] = mapped_column(Text)
    reviewer_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    recorded_at: Mapped[datetime] = _created()


class ReadinessException(Base):
    __tablename__ = "readiness_exceptions"
    id: Mapped[int] = mapped_column(primary_key=True)
    release_id: Mapped[int] = mapped_column(ForeignKey("releases.id"), index=True)
    check_key: Mapped[str] = mapped_column(String(60))
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    reason: Mapped[str] = mapped_column(Text)
    scope: Mapped[str] = mapped_column(Text)  # affected release scope, e.g. "1.0.x digital editions only"
    expires_on: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = _created()


class Approval(Base):
    __tablename__ = "approvals"
    id: Mapped[int] = mapped_column(primary_key=True)
    release_id: Mapped[Optional[int]] = mapped_column(ForeignKey("releases.id"), nullable=True, index=True)
    listing_id: Mapped[Optional[int]] = mapped_column(ForeignKey("catalogue_listings.id"), nullable=True)
    kind: Mapped[str] = mapped_column(String(30))  # release|public-listing
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    decision: Mapped[str] = mapped_column(String(20))  # approved|rejected
    comment: Mapped[str] = mapped_column(Text, default="")
    readiness_sha256: Mapped[str] = mapped_column(String(64), default="")
    at: Mapped[datetime] = _created()


# ---------------------------------------------------------------- catalogue
class CatalogueListing(Base):
    __tablename__ = "catalogue_listings"
    id: Mapped[int] = mapped_column(primary_key=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), index=True)
    edition_id: Mapped[int] = mapped_column(ForeignKey("editions.id"), unique=True)
    channel: Mapped[str] = mapped_column(String(30), default="online")  # online|retail
    status: Mapped[str] = mapped_column(String(30), default="draft")
    # draft|pending-approval|approved|publishing|published|failed|unlisted
    draft_release_id: Mapped[Optional[int]] = mapped_column(ForeignKey("releases.id"), nullable=True)
    current_release_id: Mapped[Optional[int]] = mapped_column(ForeignKey("releases.id"), nullable=True)
    pointer_history: Mapped[list] = mapped_column(JSON, default=list)
    draft_payload: Mapped[dict] = mapped_column(JSON, default=dict)
    draft_payload_sha256: Mapped[str] = mapped_column(String(64), default="")
    published_payload: Mapped[dict] = mapped_column(JSON, default=dict)
    approved_payload_sha256: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    approved_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    external_product_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    external_edition_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    updated_at: Mapped[datetime] = _created()


class PublicationJob(Base):
    __tablename__ = "publication_jobs"
    id: Mapped[int] = mapped_column(primary_key=True)
    listing_id: Mapped[int] = mapped_column(ForeignKey("catalogue_listings.id"), index=True)
    release_id: Mapped[int] = mapped_column(ForeignKey("releases.id"))
    action: Mapped[str] = mapped_column(String(20), default="publish")  # publish|rollback|unlist
    idempotency_key: Mapped[str] = mapped_column(String(200), unique=True)
    payload_sha256: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(20), default="queued")  # queued|running|succeeded|failed|dead
    steps: Mapped[dict] = mapped_column(JSON, default=dict)  # step -> {status, external_id, at}
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    last_error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    job_id: Mapped[Optional[int]] = mapped_column(ForeignKey("jobs.id"), nullable=True)
    requested_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = _created()
    finished_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)


class Advisory(Base):
    __tablename__ = "advisories"
    id: Mapped[int] = mapped_column(primary_key=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), index=True)
    release_id: Mapped[Optional[int]] = mapped_column(ForeignKey("releases.id"), nullable=True)
    kind: Mapped[str] = mapped_column(String(30))  # withdrawal|defect|security|end-of-support|rollback
    title: Mapped[str] = mapped_column(String(300))
    body: Mapped[str] = mapped_column(Text)
    published: Mapped[bool] = mapped_column(Boolean, default=False)
    external_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    created_at: Mapped[datetime] = _created()


# ---------------------------------------------------------------- support & entitlements
class SupportIssue(Base):
    __tablename__ = "support_issues"
    id: Mapped[int] = mapped_column(primary_key=True)
    external_ref: Mapped[str] = mapped_column(String(100), unique=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), index=True)
    release_id: Mapped[Optional[int]] = mapped_column(ForeignKey("releases.id"), nullable=True)
    edition_id: Mapped[Optional[int]] = mapped_column(ForeignKey("editions.id"), nullable=True)
    reported_version: Mapped[str] = mapped_column(String(40), default="")
    kind: Mapped[str] = mapped_column(String(20), default="bug")  # bug|question|feature
    title: Mapped[str] = mapped_column(String(300))
    reproduction_steps: Mapped[str] = mapped_column(Text, default="")  # redacted on import
    severity_reported: Mapped[str] = mapped_column(String(20), default="unknown")
    severity_reviewed: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    reviewed_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    owner_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="new")  # new|triaged|in-progress|fixed|closed
    fix_release_id: Mapped[Optional[int]] = mapped_column(ForeignKey("releases.id"), nullable=True)
    customer_note: Mapped[str] = mapped_column(Text, default="")  # customer-facing release-note text
    customer_ref: Mapped[str] = mapped_column(String(64))  # pseudonymous reference only
    redactions: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = _created()


class CustomerContact(Base):
    """Private customer data, readable only by support roles. Never joined into project views."""
    __tablename__ = "customer_contacts"
    id: Mapped[int] = mapped_column(primary_key=True)
    customer_ref: Mapped[str] = mapped_column(String(64), unique=True)
    email: Mapped[str] = mapped_column(String(200))
    name: Mapped[str] = mapped_column(String(200), default="")


class Entitlement(Base):
    __tablename__ = "entitlements"
    id: Mapped[int] = mapped_column(primary_key=True)
    external_id: Mapped[str] = mapped_column(String(100), unique=True)
    customer_ref: Mapped[str] = mapped_column(String(64), index=True)
    edition_id: Mapped[int] = mapped_column(ForeignKey("editions.id"))
    licence_version_id: Mapped[Optional[int]] = mapped_column(ForeignKey("licence_versions.id"), nullable=True)
    purchased_release_id: Mapped[Optional[int]] = mapped_column(ForeignKey("releases.id"), nullable=True)
    order_ref: Mapped[str] = mapped_column(String(100))
    purchased_at: Mapped[datetime] = mapped_column(TS)
    update_policy: Mapped[dict] = mapped_column(JSON, default=dict)  # copied at purchase time
    support_until: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="active")  # active|refunded|revoked


# ---------------------------------------------------------------- assistant
class AssistantRun(Base):
    __tablename__ = "assistant_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    repository_id: Mapped[Optional[int]] = mapped_column(ForeignKey("repositories.id"), nullable=True)
    requested_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(String(30))  # propose-tasks|explain|draft-tests|draft-docs|suggest-patch
    scope: Mapped[dict] = mapped_column(JSON)  # {"commit":..., "paths":[...]} explicit repository scope
    provider: Mapped[str] = mapped_column(String(30))
    model_config_: Mapped[dict] = mapped_column("model_config", JSON, default=dict)
    inputs_manifest: Mapped[list] = mapped_column(JSON, default=list)  # [{path, sha256, bytes}] not contents
    output: Mapped[dict] = mapped_column(JSON, default=dict)
    branch: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    patch_artifact_id: Mapped[Optional[int]] = mapped_column(ForeignKey("artifacts.id"), nullable=True)
    build_id: Mapped[Optional[int]] = mapped_column(ForeignKey("builds.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="completed")
    created_at: Mapped[datetime] = _created()


Index("ix_audit_entity", AuditEvent.entity_type, AuditEvent.entity_id)
