"""Build execution (runs in the worker process, never in the API server)."""
from __future__ import annotations

import fnmatch
import hashlib
import json
import platform
import shutil
import socket
import sys
import time
import uuid
import xml.etree.ElementTree as ET
from pathlib import Path

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from foundry import audit, config, jobs, licensing, scanners
from foundry.db import session_scope, utcnow
from foundry.gitadapter import adapter_for
from foundry.models import (Artifact, Build, BuildStage, Job, Project, ProvenanceAsset, Repository, Requirement,
                            RequirementEvidence, SbomComponent, ScanFinding, ScanRun, TestResult, LicenceReview)
from foundry.pipeline import PIPELINE_PATH, Pipeline, PipelineError, Stage, parse
from foundry.sandbox import CONTAINER_WS, SandboxUnavailable, get_sandbox
from foundry.storage import get_storage, store_blob

LOG_TAIL = 6000


# ------------------------------------------------------------------ scheduling (called by the API)
def create_build(db: Session, project: Project, repo: Repository, ref: str, user, trigger: str = "manual",
                 retry_of: Build | None = None) -> Build:
    ad = adapter_for(repo)
    sha = ad.resolve(ref)
    commit = ad.commits(sha, 1)[0]
    number = (db.execute(select(func.max(Build.number)).where(Build.project_id == project.id)).scalar() or 0) + 1
    b = Build(project_id=project.id, repository_id=repo.id, number=number, commit_sha=sha,
              ref=ref if ref != sha else "", commit_message=commit["subject"], status="queued", trigger=trigger,
              triggered_by=user.id if user else None, retry_of_id=retry_of.id if retry_of else None)
    db.add(b)
    db.flush()
    job = jobs.enqueue(db, "build.run", {"build_id": b.id}, max_attempts=2)
    b.job_id = job.id
    audit.record(db, user, "build.queued", "build", b.id, project.id, commit=sha, ref=ref, number=number,
                 retry_of=retry_of.id if retry_of else None)
    return b


def request_cancel(db: Session, build: Build, user) -> None:
    if build.status not in ("queued", "running"):
        raise ValueError(f"build is {build.status}")
    build.cancel_requested = True
    if build.job_id:
        jobs.request_cancel(db, db.get(Job, build.job_id))
    if build.status == "queued":
        build.status = "cancelled"
        build.finished_at = utcnow()
    audit.record(db, user, "build.cancel_requested", "build", build.id, build.project_id)


# ------------------------------------------------------------------ helpers
def _stage_update(stage_id: int, **fields) -> None:
    with session_scope() as db:
        st = db.get(BuildStage, stage_id)
        for k, v in fields.items():
            setattr(st, k, v)


def _cancel_requested(build_id: int) -> bool:
    with session_scope() as db:
        b = db.get(Build, build_id)
        return bool(b.cancel_requested)


def _tail(path: Path) -> str:
    if not path.exists():
        return ""
    data = path.read_bytes()
    return data[-LOG_TAIL:].decode("utf-8", errors="replace")


def _safe_glob(ws: Path, pattern: str) -> list[Path]:
    out = []
    for p in ws.rglob("*"):
        rel = p.relative_to(ws).as_posix()
        if fnmatch.fnmatch(rel, pattern) and p.is_file() and not p.is_symlink():
            if ws.resolve() in p.resolve().parents:
                out.append(p)
    return sorted(out)


def parse_junit(path: Path) -> list[dict]:
    root = ET.fromstring(path.read_bytes()[:5_000_000])
    cases = []
    suites = [root] if root.tag == "testsuite" else root.findall("testsuite")
    for suite in suites:
        for tc in suite.findall("testcase"):
            status, message = "passed", ""
            for tag in ("failure", "error", "skipped"):
                el = tc.find(tag)
                if el is not None:
                    status = {"failure": "failed", "error": "error", "skipped": "skipped"}[tag]
                    message = ((el.get("message") or "") + "\n" + (el.text or "")).strip()[:4000]
                    break
            reqs = [p.get("value") for p in tc.findall("properties/property") if p.get("name") == "requirement"]
            cases.append({"suite": tc.get("classname") or suite.get("name", ""), "name": tc.get("name", ""),
                          "status": status, "duration_ms": int(float(tc.get("time") or 0) * 1000),
                          "message": message, "requirements": [r for r in reqs if r]})
    return cases


def store_artifact(db: Session, project_id: int, build_id: int | None, role: str, filename: str, data: bytes,
                   media_type: str = "application/octet-stream", produced_by: str = "pipeline") -> Artifact:
    key, digest = store_blob(data, media_type)
    a = Artifact(project_id=project_id, build_id=build_id, role=role, filename=filename, storage_key=key,
                 sha256=digest, size=len(data), media_type=media_type, produced_by=produced_by)
    db.add(a)
    db.flush()
    return a


def _media_type(name: str) -> str:
    for ext, mt in ((".pyz", "application/zip"), (".zip", "application/zip"), (".tar.gz", "application/gzip"),
                    (".html", "text/html"), (".pdf", "application/pdf"), (".json", "application/json"),
                    (".txt", "text/plain"), (".svg", "image/svg+xml")):
        if name.endswith(ext):
            return mt
    return "application/octet-stream"


# ------------------------------------------------------------------ builtins
def _run_builtin(stage: Stage, ws: Path, build_id: int, project_id: int, pipe: Pipeline, log) -> int:
    if stage.uses == "foundry/dependency-audit":
        rep = scanners.dependency_audit(ws, pipe.lockfiles())
    elif stage.uses == "foundry/secret-scan":
        rep = scanners.secret_scan(ws)
    elif stage.uses == "foundry/sbom":
        return _run_sbom(ws, build_id, project_id, pipe, log)
    else:
        raise PipelineError(stage.uses)
    with session_scope() as db:
        run = ScanRun(build_id=build_id, tool=rep["tool"], tool_version=rep["tool_version"],
                      database_version=rep["database_version"], finding_count=len(rep["findings"]),
                      scope=rep["scope"], limitations=rep["limitations"])
        db.add(run)
        db.flush()
        for f in rep["findings"]:
            db.add(ScanFinding(scan_run_id=run.id, build_id=build_id, **f))
    log.write(f"{rep['tool']} {rep['tool_version']} (db {rep['database_version']}) scope: {rep['scope']}\n".encode())
    log.write(f"{len(rep['findings'])} finding(s) reported.\n".encode())
    for f in rep["findings"]:
        log.write(f"  [{f['severity']}] {f['identifier']} {f['component']}: {f['title']}\n".encode())
    log.write(f"Note: {rep['limitations']}\n".encode())
    high = [f for f in rep["findings"] if f["severity"] in ("high", "critical")]
    return 1 if high else 0


def _run_sbom(ws: Path, build_id: int, project_id: int, pipe: Pipeline, log) -> int:
    lock = {}
    for lf in pipe.lockfiles():
        p = ws / lf
        if p.is_file():
            lock.update(licensing.parse_lockfile(p.read_text()))
    deps_dir = pipe.env.get("FOUNDRY_DEPS_DIR", ".deps")
    comps = licensing.scan_installed(ws, deps_dir, lock)
    assets = licensing.asset_manifest(ws)
    with session_scope() as db:
        b = db.get(Build, build_id)
        proj = db.get(Project, project_id)
        bom = licensing.cyclonedx({"name": proj.name}, b.commit_sha, comps)
        sbom_art = store_artifact(db, project_id, build_id, "sbom", "sbom.cdx.json",
                                  json.dumps(bom, indent=2).encode(), "application/json", "foundry/sbom")
        notices = licensing.notices_text(proj.name, comps, assets)
        store_artifact(db, project_id, build_id, "notices", "THIRD_PARTY_NOTICES.txt", notices.encode(),
                       "text/plain", "foundry/sbom")
        (ws / "build").mkdir(exist_ok=True)
        (ws / "build" / "THIRD_PARTY_NOTICES.txt").write_text(notices)
        issues = 0
        for c in comps:
            lic_key = None
            if c["licence_texts"]:
                lic_key, _ = store_blob("\n\n".join(c["licence_texts"].values()).encode(), "text/plain")
            db.add(SbomComponent(build_id=build_id, name=c["name"], version=c["version"], purl=c["purl"],
                                 licence_declared=c["licence_declared"], licence_source=c["licence_source"],
                                 origin=c["origin"], sha256=c["sha256"], scope=c["scope"], licence_text_key=lic_key,
                                 attribution=c.get("author", "")))
            problem = licensing.route(licensing.classify(c["licence_declared"]), proj.source_distribution_model)
            if not c["in_lockfile"]:
                problem = (problem + " " if problem else "") + "Installed component is not pinned in the lockfile."
            if problem:
                issues += 1
                _open_review(db, project_id, "component", f"{c['purl']}#{c['licence_declared']}", problem)
        # provenance assets declared in-repo
        for a in assets:
            existing = db.execute(select(ProvenanceAsset).where(ProvenanceAsset.project_id == project_id,
                                                                ProvenanceAsset.path == a["path"])).scalar_one_or_none()
            if existing is None:
                existing = ProvenanceAsset(project_id=project_id, path=a["path"], kind=a.get("kind", "artwork"),
                                           origin=a.get("origin", ""), licence=a.get("licence", "UNKNOWN"),
                                           attribution=a.get("attribution", ""), restrictions=a.get("restrictions", ""))
                db.add(existing)
            elif existing.licence != a.get("licence") or existing.origin != a.get("origin"):
                existing.licence, existing.origin = a.get("licence", "UNKNOWN"), a.get("origin", "")
                existing.status = "unreviewed"
            if licensing.classify(a.get("licence", "UNKNOWN")) == "unknown" and existing.status != "cleared":
                issues += 1
                _open_review(db, project_id, "asset", f"{a['path']}#{a.get('licence', 'UNKNOWN')}",
                             f"Asset licence is '{a.get('licence', 'UNKNOWN')}' (origin: {a.get('origin', 'unrecorded')}). "
                             "Rights to distribute it commercially are not established.")
        b.summary = {**(b.summary or {}), "assets": [
            {"path": a["path"], "licence": a.get("licence", "UNKNOWN"), "origin": a.get("origin", "")} for a in assets],
            "components": [{"purl": c["purl"], "licence": c["licence_declared"]} for c in comps]}
        log.write(f"{licensing.TOOL} {licensing.TOOL_VERSION}: {len(comps)} component(s), {len(assets)} asset(s); "
                  f"SBOM artefact {sbom_art.sha256[:12]}; {issues} item(s) routed to licence review.\n".encode())
        log.write(b"Automated licence classification is not legal clearance.\n")
    return 0


def _open_review(db: Session, project_id: int, subject_type: str, ref: str, issue: str) -> None:
    # one review per (subject, licence) fingerprint: a changed licence or origin raises a fresh review
    exists = db.execute(select(LicenceReview).where(LicenceReview.project_id == project_id,
                                                    LicenceReview.subject_ref == ref)).scalars().first()
    if exists is None:
        db.add(LicenceReview(project_id=project_id, subject_type=subject_type, subject_ref=ref, issue=issue))


# ------------------------------------------------------------------ evidence
def record_test_evidence(db: Session, build: Build) -> None:
    reqs = {r.key: r for r in db.execute(select(Requirement).where(Requirement.project_id == build.project_id)).scalars()}
    per_req: dict[str, list[str]] = {}
    for tr in db.execute(select(TestResult).where(TestResult.build_id == build.id)).scalars():
        for key in tr.requirement_keys or []:
            if key in reqs:
                db.add(RequirementEvidence(requirement_id=reqs[key].id, kind="test", build_id=build.id,
                                           commit_sha=build.commit_sha, reference=f"{tr.suite}.{tr.name}",
                                           result="passed" if tr.status == "passed" else "failed",
                                           note=tr.message[:500]))
                per_req.setdefault(key, []).append(tr.status)
    for key, statuses in per_req.items():
        r = reqs[key]
        if all(s == "passed" for s in statuses):
            if r.status == "implemented":
                r.status = "tested"
        elif r.status in ("tested", "accepted"):
            r.status = "implemented"  # regression: acceptance no longer holds
            r.accepted_at = None
            r.accepted_by = None
            audit.record(db, None, "requirement.regressed", "requirement", r.id, build.project_id,
                         build=build.number, key=key)


# ------------------------------------------------------------------ the job handler
@jobs.handler("build.run")
def run_build(_db: Session, job: Job) -> dict:
    build_id = job.payload["build_id"]
    with session_scope() as db:
        b = db.get(Build, build_id)
        if b.status in ("cancelled", "passed", "failed"):
            return {"skipped": b.status}
        repo = db.get(Repository, b.repository_id)
        project_id, commit, repo_loc = b.project_id, b.commit_sha, (repo.provider, repo.location, repo.credential_ref)
        b.status, b.started_at = "running", utcnow()
        # a previous attempt may have left stage rows behind; keep them (history) but renumber new ones
        prior = db.execute(select(func.max(BuildStage.position)).where(BuildStage.build_id == build_id)).scalar()
        base_pos = (prior + 1) if prior is not None else 0

    workdir = config.settings.work_root.resolve() / f"build-{build_id}-{uuid.uuid4().hex[:8]}"
    ws = workdir / "ws"
    logs = workdir / "logs"
    logs.mkdir(parents=True)
    ws.mkdir()
    try:
        sandbox = get_sandbox()
    except SandboxUnavailable as exc:
        _finish_build(build_id, "error", f"sandbox unavailable: {exc}")
        raise jobs.PermanentFailure(str(exc))

    try:
        return _execute(build_id, project_id, commit, workdir, ws, logs, sandbox, base_pos, job.id)
    finally:
        sandbox.cleanup(workdir)


def _finish_build(build_id: int, status: str, error: str | None = None, **summary) -> None:
    with session_scope() as db:
        b = db.get(Build, build_id)
        b.status, b.finished_at, b.error = status, utcnow(), error
        b.summary = {**(b.summary or {}), **summary}
        audit.record(db, None, f"build.{status}", "build", b.id, b.project_id, number=b.number, commit=b.commit_sha)
        if status in ("passed", "failed"):
            record_test_evidence(db, b)


def _execute(build_id, project_id, commit, workdir: Path, ws: Path, logs: Path, sandbox, base_pos: int,
             job_id: int) -> dict:
    t0 = time.monotonic()
    with session_scope() as db:
        b = db.get(Build, build_id)
        repo = db.get(Repository, b.repository_id)
        ad = adapter_for(repo)
        # ---- checkout (worker-side, from the immutable commit id; no hooks, no .git)
        co = BuildStage(build_id=build_id, position=base_pos, name="checkout", kind="builtin",
                        command=f"git archive {commit}", status="running", started_at=utcnow(), attempts=1)
        db.add(co)
        db.flush()
        co_id = co.id
    co_log = logs / "checkout.log"
    try:
        ad.archive_to(commit, ws)
        resolved = ad.resolve(commit)
        assert resolved == commit, "commit id changed during checkout"
        files = [p for p in ws.rglob("*") if p.is_file()]
        co_log.write_text(f"Checked out {commit} ({len(files)} files) from {repo.provider}:{repo.location}\n"
                          "Repository hooks are not executed; .git metadata is not included.\n")
        pipe_text = (ws / PIPELINE_PATH).read_text() if (ws / PIPELINE_PATH).is_file() else None
        if pipe_text is None:
            raise PipelineError(f"{PIPELINE_PATH} not found at {commit[:12]}")
        pipe = parse(pipe_text)
        lockfiles = {}
        for lf in pipe.lockfiles():
            p = ws / lf
            lockfiles[lf] = hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else "MISSING"
        co_log.write_text(co_log.read_text() + f"Pipeline {PIPELINE_PATH} sha256={pipe.sha256()}\n"
                          + "".join(f"Lockfile {k}: {v}\n" for k, v in lockfiles.items()))
        # vetted dependency cache: copied in, never fetched from the internet by the build
        wh = config.settings.wheelhouse
        if wh.is_dir():
            shutil.copytree(wh, ws / ".foundry" / "wheelhouse", dirs_exist_ok=True)
        sandbox.prepare(ws)
        key, _ = store_blob(co_log.read_bytes(), "text/plain")
        _stage_update(co_id, status="passed", exit_code=0, finished_at=utcnow(), log_key=key,
                      log_tail=_tail(co_log), duration_ms=int((time.monotonic() - t0) * 1000))
    except Exception as exc:  # noqa: BLE001
        co_log.write_text((co_log.read_text() if co_log.exists() else "") + f"checkout failed: {exc}\n")
        key, _ = store_blob(co_log.read_bytes(), "text/plain")
        _stage_update(co_id, status="failed", exit_code=1, finished_at=utcnow(), log_key=key, log_tail=_tail(co_log))
        _finish_build(build_id, "failed", f"checkout/pipeline error: {exc}")
        return {"status": "failed"}

    env_desc = sandbox.describe()
    env_desc.update({"worker_host": socket.gethostname(), "worker_python": sys.version.split()[0],
                     "worker_platform": f"{platform.system().lower()}-{platform.machine()}",
                     "pipeline_platform": pipe.platform})
    with session_scope() as db:
        b = db.get(Build, build_id)
        b.pipeline, b.pipeline_sha256, b.worker_env, b.lockfiles = pipe.as_dict(), pipe.sha256(), env_desc, lockfiles
        stage_ids = {}
        for i, st in enumerate(pipe.stages, start=1):
            row = BuildStage(build_id=build_id, position=base_pos + i, name=st.name, kind=st.kind,
                             command=st.run or st.uses, network=st.network, status="pending")
            db.add(row)
            db.flush()
            stage_ids[st.name] = row.id

    results: dict[str, str] = {"checkout": "passed"}
    cancelled = False
    env = dict(pipe.env)
    env["FOUNDRY_WHEELHOUSE"] = (str(ws) if sandbox.name == "local" else CONTAINER_WS) + "/.foundry/wheelhouse"
    env["FOUNDRY_COMMIT"] = commit
    last_tail_push = [0.0]

    for st in pipe.stages:
        sid = stage_ids[st.name]
        if cancelled or _cancel_requested(build_id) or jobs.heartbeat(job_id):
            cancelled = True
            _stage_update(sid, status="cancelled")
            results[st.name] = "cancelled"
            continue
        blocked = [n for n in st.needs if results.get(n) not in ("passed",)]
        if blocked:
            _stage_update(sid, status="skipped", log_tail=f"skipped: dependency {', '.join(blocked)} did not pass")
            results[st.name] = "skipped"
            continue
        log_path = logs / f"{st.name}.log"
        _stage_update(sid, status="running", started_at=utcnow())
        attempt, res = 0, None
        while True:
            attempt += 1
            with open(log_path, "ab") as lg:
                lg.write(f"[foundry] stage {st.name} attempt {attempt}/{st.retries + 1} "
                         f"network={st.network}\n$ {st.run or st.uses}\n".encode())
            if st.kind == "builtin":
                t = time.monotonic()
                try:
                    with open(log_path, "ab") as lg:
                        code = _run_builtin(st, ws, build_id, project_id, pipe, lg)
                    sandbox.prepare(ws)  # files written by trusted builtins must stay writable for the build user
                    status = "passed" if code == 0 else "failed"
                    res_d = {"wall_ms": int((time.monotonic() - t) * 1000), "executed_by": "worker (trusted builtin)"}
                    res = type("R", (), {"exit_code": code, "status": status, "resources": res_d,
                                         "duration_ms": res_d["wall_ms"]})()
                except Exception as exc:  # noqa: BLE001
                    with open(log_path, "ab") as lg:
                        lg.write(f"builtin error: {exc}\n".encode())
                    res = type("R", (), {"exit_code": None, "status": "error", "resources": {}, "duration_ms": 0})()
            else:
                def should_cancel(sid=sid, log_path=log_path):
                    now = time.monotonic()
                    if now - last_tail_push[0] > 1.5:
                        last_tail_push[0] = now
                        _stage_update(sid, log_tail=_tail(log_path))
                        return _cancel_requested(build_id) or jobs.heartbeat(job_id)
                    return False
                try:
                    res = sandbox.run(st.run, ws, log_path, network=st.network, env=env,
                                      should_cancel=should_cancel, timeout_s=st.timeout_s)
                except SandboxUnavailable as exc:
                    with open(log_path, "ab") as lg:
                        lg.write(f"[foundry] sandbox refused stage: {exc}\n".encode())
                    res = type("R", (), {"exit_code": None, "status": "error", "resources": {}, "duration_ms": 0})()
            if res.status in st.retry_on and attempt <= st.retries:
                with open(log_path, "ab") as lg:
                    lg.write(f"[foundry] attempt {attempt} ended '{res.status}'; retrying (bounded)\n".encode())
                continue
            break
        final = res.status
        if final == "timeout":
            final = "failed"
        if final == "failed" and st.allow_failure:
            final = "passed"
            with open(log_path, "ab") as lg:
                lg.write(b"[foundry] failure allowed by pipeline (allow_failure = true)\n")
        with open(log_path, "ab") as lg:
            lg.write(f"[foundry] exit code {res.exit_code}; status {res.status}; {res.duration_ms} ms\n".encode())
        # reports and artefacts are collected even when the stage failed (failed results are preserved)
        _collect(st, ws, build_id, project_id, log_path, final)
        key, _ = store_blob(log_path.read_bytes(), "text/plain")
        _stage_update(sid, status=final, exit_code=res.exit_code, finished_at=utcnow(), attempts=attempt,
                      duration_ms=res.duration_ms, resources=res.resources, log_key=key, log_tail=_tail(log_path))
        results[st.name] = final
        if final == "cancelled":
            cancelled = True

    status = "cancelled" if cancelled else ("passed" if all(v == "passed" for v in results.values()) else "failed")
    with session_scope() as db:
        tests = db.execute(select(TestResult.status, func.count()).where(TestResult.build_id == build_id)
                           .group_by(TestResult.status)).all()
        arts = db.execute(select(Artifact).where(Artifact.build_id == build_id)).scalars().all()
        b = db.get(Build, build_id)
        b.resources = {"wall_ms": int((time.monotonic() - t0) * 1000)}
    _finish_build(build_id, status, None, stages=results, tests={s: n for s, n in tests},
                  artifacts=[{"role": a.role, "filename": a.filename, "sha256": a.sha256, "size": a.size} for a in arts])
    return {"status": status}


def _collect(st: Stage, ws: Path, build_id: int, project_id: int, log_path: Path, stage_status: str) -> None:
    with session_scope() as db:
        junit = st.reports.get("junit")
        if junit:
            p = ws / junit
            if p.is_file() and not p.is_symlink():
                try:
                    cases = parse_junit(p)
                except ET.ParseError as exc:
                    cases = []
                    with open(log_path, "ab") as lg:
                        lg.write(f"[foundry] could not parse JUnit report: {exc}\n".encode())
                for c in cases:
                    db.add(TestResult(build_id=build_id, suite=c["suite"], name=c["name"], status=c["status"],
                                      duration_ms=c["duration_ms"], message=c["message"],
                                      requirement_keys=c["requirements"], platform=platform.machine()))
                with open(log_path, "ab") as lg:
                    lg.write(f"[foundry] recorded {len(cases)} test result(s) from {junit}\n".encode())
            else:
                with open(log_path, "ab") as lg:
                    lg.write(f"[foundry] JUnit report {junit} was not produced\n".encode())
        if stage_status != "passed":
            return
        for spec in st.artifacts:
            matches = _safe_glob(ws, spec.path)
            if not matches:
                with open(log_path, "ab") as lg:
                    lg.write(f"[foundry] WARNING: no files matched artefact pattern {spec.path}\n".encode())
            for m in matches:
                a = store_artifact(db, project_id, build_id, spec.role, m.name, m.read_bytes(), _media_type(m.name))
                with open(log_path, "ab") as lg:
                    lg.write(f"[foundry] artefact {spec.role}: {m.name} sha256={a.sha256} ({a.size} bytes)\n".encode())
