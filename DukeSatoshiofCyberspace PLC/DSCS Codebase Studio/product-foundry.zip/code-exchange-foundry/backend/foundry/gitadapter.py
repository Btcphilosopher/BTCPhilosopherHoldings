"""Git adapters.

LocalGitAdapter is fully working and used by the demonstration. It shells out to ``git`` with
an argument list (never a shell string), refuses paths outside the configured repository roots,
and never executes repository hooks: builds receive ``git archive`` output, not a checkout.

GitHubAdapter / GitLabAdapter implement the same read interface over the providers' REST APIs
using a token looked up by *name* (``credential_ref``) from the worker/API environment; tokens are
never stored in the database or returned by the API. They are implemented against the official
REST documentation but are not exercised against live services by the test suite.
"""
from __future__ import annotations

import io
import os
import re
import subprocess
import tarfile
from dataclasses import dataclass
from pathlib import Path

from foundry import config

SHA_RE = re.compile(r"^[0-9a-f]{40}([0-9a-f]{24})?$")
SAFE_REF = re.compile(r"^[A-Za-z0-9._/\-]{1,200}$")
MAX_FILE_BYTES = 512 * 1024


class GitError(Exception):
    pass


@dataclass
class Commit:
    sha: str
    author: str
    authored_at: str
    subject: str
    body: str = ""

    def as_dict(self) -> dict:
        return self.__dict__.copy()


def _check_ref(ref: str) -> str:
    if not SAFE_REF.match(ref) or ".." in ref or ref.startswith("-"):
        raise GitError(f"unsafe ref {ref!r}")
    return ref


def _check_path(path: str) -> str:
    path = path.strip("/")
    if path.startswith("-") or ".." in Path(path).parts:
        raise GitError("unsafe path")
    return path


def allowed_local_path(path: str) -> Path:
    p = Path(path).expanduser().resolve()
    roots = config.settings.repo_roots
    if not any(p == r or r in p.parents for r in roots):
        raise GitError(f"{p} is outside the permitted repository roots ({', '.join(map(str, roots))})")
    if not (p / ".git").exists() and not (p / "HEAD").exists():
        raise GitError(f"{p} is not a Git repository")
    return p


class LocalGitAdapter:
    provider = "local"

    def __init__(self, path: str):
        self.path = allowed_local_path(path)

    def _git(self, *args: str, input_: bytes | None = None, env: dict | None = None) -> bytes:
        base_env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": "/nonexistent",
                    "GIT_CONFIG_NOSYSTEM": "1", "GIT_TERMINAL_PROMPT": "0", "LC_ALL": "C"}
        base_env.update(env or {})
        proc = subprocess.run(["git", "-c", "core.hooksPath=/dev/null", "-c", "safe.directory=*",
                               "-C", str(self.path), *args],
                              input=input_, capture_output=True, env=base_env, timeout=60)
        if proc.returncode != 0:
            raise GitError(proc.stderr.decode(errors="replace").strip() or f"git {args[0]} failed")
        return proc.stdout

    # ---- read interface
    def origin(self) -> dict:
        info = {"provider": "local", "path": str(self.path)}
        try:
            info["remote_url"] = self._git("config", "--get", "remote.origin.url").decode().strip()
        except GitError:
            info["remote_url"] = None
        try:
            info["root_commit"] = self._git("rev-list", "--max-parents=0", "HEAD").decode().split()[0]
            info["head"] = self.resolve("HEAD")
        except GitError:
            pass
        return info

    def default_branch(self) -> str:
        try:
            return self._git("symbolic-ref", "--short", "HEAD").decode().strip()
        except GitError:
            return "main"

    def branches(self) -> list[dict]:
        out = self._git("for-each-ref", "--format=%(refname:short)%09%(objectname)%09%(committerdate:iso8601-strict)",
                        "refs/heads").decode()
        res = []
        for line in out.splitlines():
            name, sha, date = line.split("\t")
            res.append({"name": name, "sha": sha, "updated_at": date})
        return res

    def resolve(self, ref: str) -> str:
        if not SHA_RE.match(ref):
            _check_ref(ref)
        sha = self._git("rev-parse", "--verify", f"{ref}^{{commit}}").decode().strip()
        if not SHA_RE.match(sha):
            raise GitError("could not resolve to an immutable commit id")
        return sha

    def commits(self, ref: str, limit: int = 50) -> list[dict]:
        sha = self.resolve(ref)
        out = self._git("log", f"-n{min(limit, 500)}", "--format=%H%x1f%an%x1f%aI%x1f%s%x1f%b%x1e", sha).decode()
        res = []
        for rec in out.split("\x1e"):
            rec = rec.strip("\n")
            if not rec:
                continue
            parts = rec.split("\x1f")
            res.append(Commit(parts[0], parts[1], parts[2], parts[3], parts[4].strip()).as_dict())
        return res

    def commit(self, sha: str) -> dict:
        return self.commits(sha, 1)[0]

    def tree(self, sha: str, path: str = "") -> list[dict]:
        sha = self.resolve(sha)
        path = _check_path(path)
        spec = f"{sha}:{path}" if path else f"{sha}"
        out = self._git("ls-tree", "-l", spec).decode()
        res = []
        for line in out.splitlines():
            meta, name = line.split("\t", 1)
            mode, typ, obj, size = meta.split()
            res.append({"name": name, "path": f"{path}/{name}".strip("/"), "type": typ,
                        "size": None if size == "-" else int(size), "object": obj})
        return sorted(res, key=lambda e: (e["type"] != "tree", e["name"]))

    def read_file(self, sha: str, path: str) -> dict:
        sha = self.resolve(sha)
        path = _check_path(path)
        size = int(self._git("cat-file", "-s", f"{sha}:{path}").decode().strip())
        if size > MAX_FILE_BYTES:
            return {"path": path, "size": size, "binary": False, "truncated": True, "content": ""}
        data = self._git("cat-file", "blob", f"{sha}:{path}")
        binary = b"\x00" in data[:8000]
        return {"path": path, "size": size, "binary": binary, "truncated": False,
                "content": "" if binary else data.decode("utf-8", errors="replace")}

    def read_bytes(self, sha: str, path: str) -> bytes:
        return self._git("cat-file", "blob", f"{self.resolve(sha)}:{_check_path(path)}")

    def list_files(self, sha: str) -> list[str]:
        return self._git("ls-tree", "-r", "--name-only", self.resolve(sha)).decode().splitlines()

    def diff_summary(self, base: str, head: str) -> dict:
        b, h = self.resolve(base), self.resolve(head)
        files = []
        for line in self._git("diff", "--numstat", b, h).decode().splitlines():
            add, rem, name = line.split("\t", 2)
            files.append({"path": name, "added": None if add == "-" else int(add),
                          "removed": None if rem == "-" else int(rem)})
        commits = self._git("log", "--format=%H%x1f%s", f"{b}..{h}").decode().splitlines()
        return {"base": b, "head": h, "files": files,
                "commits": [dict(zip(("sha", "subject"), c.split("\x1f", 1))) for c in commits]}

    def diff_patch(self, base: str, head: str) -> str:
        return self._git("diff", self.resolve(base), self.resolve(head)).decode(errors="replace")

    def archive_to(self, sha: str, dest: Path) -> None:
        """Materialise the exact tree of an immutable commit without .git metadata or hooks."""
        sha = self.resolve(sha)
        data = self._git("archive", "--format=tar", sha)
        dest.mkdir(parents=True, exist_ok=True)
        with tarfile.open(fileobj=io.BytesIO(data)) as tf:
            tf.extractall(dest, filter="data")

    def archive_bytes(self, sha: str, prefix: str, fmt: str = "tar.gz") -> bytes:
        sha = self.resolve(sha)
        return self._git("archive", f"--format={fmt}", f"--prefix={prefix}/", sha)

    # ---- controlled write path used only by the assistant (never protected branches)
    def commit_files_to_branch(self, base_sha: str, branch: str, files: dict[str, str], message: str,
                               author: str, protected: list[str]) -> str:
        _check_ref(branch)
        if branch in protected or branch == self.default_branch():
            raise GitError(f"branch {branch} is protected")
        if any(b["name"] == branch for b in self.branches()):
            raise GitError(f"branch {branch} already exists")
        base_sha = self.resolve(base_sha)
        index = self.path / ".git" / f"foundry-index-{os.getpid()}"
        env = {"GIT_INDEX_FILE": str(index), "GIT_AUTHOR_NAME": author, "GIT_AUTHOR_EMAIL": "assistant@foundry.invalid",
               "GIT_COMMITTER_NAME": author, "GIT_COMMITTER_EMAIL": "assistant@foundry.invalid"}
        try:
            self._git("read-tree", base_sha, env=env)
            for path, content in files.items():
                path = _check_path(path)
                blob = self._git("hash-object", "-w", "--stdin", input_=content.encode()).decode().strip()
                self._git("update-index", "--add", "--cacheinfo", f"100644,{blob},{path}", env=env)
            tree = self._git("write-tree", env=env).decode().strip()
            new = self._git("commit-tree", tree, "-p", base_sha, "-m", message, env=env).decode().strip()
            self._git("update-ref", f"refs/heads/{branch}", new, "0" * 40)
            return new
        finally:
            index.unlink(missing_ok=True)

    def editor_link(self, path: str = "") -> str:
        target = str(self.path / _check_path(path)) if path else str(self.path)
        return config.settings.editor_url_template.format(path=target)


class _HttpAdapter:
    """Shared plumbing for hosted providers. Token resolved from env var FOUNDRY_SECRET_<REF>."""
    provider = "http"

    def __init__(self, location: str, credential_ref: str | None, base_url: str):
        import httpx
        self.location = location
        token = os.environ.get(f"FOUNDRY_SECRET_{(credential_ref or '').upper()}") if credential_ref else None
        self.client = httpx.Client(base_url=base_url, timeout=30, headers=self._headers(token))

    def _headers(self, token: str | None) -> dict:
        return {}

    def _get(self, path: str, **params):
        r = self.client.get(path, params=params)
        if r.status_code >= 400:
            raise GitError(f"{self.provider} API {r.status_code}: {r.text[:200]}")
        return r


class GitHubAdapter(_HttpAdapter):
    provider = "github"
    API_VERSION = "2022-11-28"

    def __init__(self, location: str, credential_ref: str | None = None, base_url: str = "https://api.github.com"):
        super().__init__(location, credential_ref, base_url)

    def _headers(self, token):
        h = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": self.API_VERSION}
        if token:
            h["Authorization"] = f"Bearer {token}"
        return h

    def branches(self):
        return [{"name": b["name"], "sha": b["commit"]["sha"]}
                for b in self._get(f"/repos/{self.location}/branches", per_page=100).json()]

    def resolve(self, ref: str) -> str:
        if SHA_RE.match(ref):
            return ref
        return self._get(f"/repos/{self.location}/commits/{_check_ref(ref)}").json()["sha"]

    def commits(self, ref: str, limit: int = 50):
        data = self._get(f"/repos/{self.location}/commits", sha=_check_ref(ref), per_page=min(limit, 100)).json()
        return [Commit(c["sha"], c["commit"]["author"]["name"], c["commit"]["author"]["date"],
                       c["commit"]["message"].split("\n", 1)[0]).as_dict() for c in data]

    def tree(self, sha: str, path: str = ""):
        data = self._get(f"/repos/{self.location}/contents/{_check_path(path)}", ref=self.resolve(sha)).json()
        return [{"name": e["name"], "path": e["path"], "type": "tree" if e["type"] == "dir" else "blob",
                 "size": e.get("size")} for e in data]

    def read_file(self, sha: str, path: str):
        r = self.client.get(f"/repos/{self.location}/contents/{_check_path(path)}", params={"ref": self.resolve(sha)},
                            headers={"Accept": "application/vnd.github.raw+json"})
        if r.status_code >= 400:
            raise GitError(f"github API {r.status_code}")
        return {"path": path, "size": len(r.content), "binary": b"\x00" in r.content[:8000], "truncated": False,
                "content": r.content.decode("utf-8", errors="replace")}

    def archive_to(self, sha: str, dest: Path) -> None:
        r = self.client.get(f"/repos/{self.location}/tarball/{self.resolve(sha)}", follow_redirects=True)
        if r.status_code >= 400:
            raise GitError(f"github API {r.status_code}")
        _extract_single_root(r.content, dest)

    def pull_requests(self):
        return [{"number": p["number"], "title": p["title"], "url": p["html_url"], "state": p["state"]}
                for p in self._get(f"/repos/{self.location}/pulls", state="open", per_page=50).json()]

    def issues(self):
        return [{"number": i["number"], "title": i["title"], "url": i["html_url"], "state": i["state"]}
                for i in self._get(f"/repos/{self.location}/issues", state="open", per_page=50).json()
                if "pull_request" not in i]

    def editor_link(self, path: str = "") -> str:
        return f"https://github.dev/{self.location}"


class GitLabAdapter(_HttpAdapter):
    provider = "gitlab"

    def __init__(self, location: str, credential_ref: str | None = None, base_url: str = "https://gitlab.com/api/v4"):
        super().__init__(location, credential_ref, base_url)
        from urllib.parse import quote
        self.pid = quote(location, safe="")

    def _headers(self, token):
        return {"PRIVATE-TOKEN": token} if token else {}

    def branches(self):
        return [{"name": b["name"], "sha": b["commit"]["id"]}
                for b in self._get(f"/projects/{self.pid}/repository/branches", per_page=100).json()]

    def resolve(self, ref: str) -> str:
        if SHA_RE.match(ref):
            return ref
        from urllib.parse import quote
        return self._get(f"/projects/{self.pid}/repository/commits/{quote(_check_ref(ref), safe='')}").json()["id"]

    def commits(self, ref: str, limit: int = 50):
        data = self._get(f"/projects/{self.pid}/repository/commits", ref_name=_check_ref(ref),
                         per_page=min(limit, 100)).json()
        return [Commit(c["id"], c["author_name"], c["authored_date"], c["title"]).as_dict() for c in data]

    def tree(self, sha: str, path: str = ""):
        data = self._get(f"/projects/{self.pid}/repository/tree", ref=self.resolve(sha), path=_check_path(path),
                         per_page=100).json()
        return [{"name": e["name"], "path": e["path"], "type": e["type"], "size": None} for e in data]

    def read_file(self, sha: str, path: str):
        from urllib.parse import quote
        r = self._get(f"/projects/{self.pid}/repository/files/{quote(_check_path(path), safe='')}/raw",
                      ref=self.resolve(sha))
        return {"path": path, "size": len(r.content), "binary": b"\x00" in r.content[:8000], "truncated": False,
                "content": r.content.decode("utf-8", errors="replace")}

    def archive_to(self, sha: str, dest: Path) -> None:
        r = self._get(f"/projects/{self.pid}/repository/archive.tar.gz", sha=self.resolve(sha))
        _extract_single_root(r.content, dest)

    def pull_requests(self):
        return [{"number": m["iid"], "title": m["title"], "url": m["web_url"], "state": m["state"]}
                for m in self._get(f"/projects/{self.pid}/merge_requests", state="opened").json()]

    def issues(self):
        return [{"number": i["iid"], "title": i["title"], "url": i["web_url"], "state": i["state"]}
                for i in self._get(f"/projects/{self.pid}/issues", state="opened").json()]

    def editor_link(self, path: str = "") -> str:
        return f"https://gitlab.com/-/ide/project/{self.location}/edit/main/-/"


def _extract_single_root(data: bytes, dest: Path) -> None:
    import shutil
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        with tarfile.open(fileobj=io.BytesIO(data)) as tf:
            tf.extractall(tmp, filter="data")
        roots = list(Path(tmp).iterdir())
        src = roots[0] if len(roots) == 1 and roots[0].is_dir() else Path(tmp)
        dest.mkdir(parents=True, exist_ok=True)
        for item in src.iterdir():
            shutil.move(str(item), dest / item.name)


def adapter_for(repo) -> LocalGitAdapter | GitHubAdapter | GitLabAdapter:
    if repo.provider == "local":
        return LocalGitAdapter(repo.location)
    if repo.provider == "github":
        return GitHubAdapter(repo.location, repo.credential_ref)
    if repo.provider == "gitlab":
        return GitLabAdapter(repo.location, repo.credential_ref)
    raise GitError(f"unknown provider {repo.provider}")
