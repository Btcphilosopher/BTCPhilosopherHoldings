"""Seed users for every role plus default documentation and packaging templates.

    python -m foundry.seed
Demo password for every seeded user: foundry-demo  (change before any shared deployment)
"""
from __future__ import annotations

from sqlalchemy import select

from foundry import docs, packaging
from foundry.db import session_scope
from foundry.models import User
from foundry.security import hash_password

DEMO_PASSWORD = "foundry-demo"
USERS = [
    ("pat@codeexchange.example", "Pat Morgan", ["product_manager"]),
    ("dana@codeexchange.example", "Dana Okafor", ["developer"]),
    ("ravi@codeexchange.example", "Ravi Shah", ["reviewer"]),
    ("quinn@codeexchange.example", "Quinn Adeyemi", ["quality_engineer"]),
    ("devi@codeexchange.example", "Devi Laurent", ["documentation_editor"]),
    ("lena@codeexchange.example", "Lena Fischer", ["licence_reviewer"]),
    ("rowan@codeexchange.example", "Rowan Hale", ["release_manager"]),
    ("cass@codeexchange.example", "Cass Brennan", ["catalogue_editor"]),
    ("sam@codeexchange.example", "Sam Ortiz", ["support_agent"]),
    ("alex@codeexchange.example", "Alex Kim", ["administrator"]),
]


def seed() -> None:
    with session_scope() as db:
        pw = hash_password(DEMO_PASSWORD)
        for email, name, roles in USERS:
            if not db.execute(select(User).where(User.email == email)).first():
                db.add(User(email=email, name=name, password_hash=pw, roles=roles))
        docs.ensure_default_templates(db)
        packaging.ensure_templates(db)
        from foundry.assistant import assistant_user
        assistant_user(db)
    print(f"seeded {len(USERS)} users (password: {DEMO_PASSWORD}), documentation and packaging templates")


if __name__ == "__main__":
    seed()
