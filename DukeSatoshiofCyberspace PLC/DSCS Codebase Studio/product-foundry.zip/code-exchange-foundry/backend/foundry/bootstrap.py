"""Create the schema directly from the models (tests only; deployments use Alembic migrations)."""
from foundry import models  # noqa: F401
from foundry.db import Base, get_engine


def create_all() -> None:
    Base.metadata.create_all(get_engine())


def drop_all() -> None:
    Base.metadata.drop_all(get_engine())
