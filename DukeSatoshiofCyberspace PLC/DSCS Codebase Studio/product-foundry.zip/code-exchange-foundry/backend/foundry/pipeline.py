"""Version-controlled pipeline definitions (``.foundry/pipeline.toml`` in the repository).

Example::

    version = 1
    [env]
    PYTHONPATH = "src:.deps"

    [[stages]]
    name = "dependencies"
    run = "python3 -m pip install --no-index --find-links \"$FOUNDRY_WHEELHOUSE\" --target .deps -r requirements.lock"
    lockfiles = ["requirements.lock"]

    [[stages]]
    name = "test"
    needs = ["dependencies"]
    run = "python3 tools/run_tests.py --junit reports/junit.xml"
    reports = { junit = "reports/junit.xml" }
"""
from __future__ import annotations

import hashlib
import json
import re
import tomllib
from dataclasses import asdict, dataclass, field

PIPELINE_PATH = ".foundry/pipeline.toml"
BUILTINS = {"foundry/dependency-audit", "foundry/secret-scan", "foundry/sbom"}
NAME_RE = re.compile(r"^[a-z][a-z0-9-]{0,40}$")
ROLES = {"application", "source", "starter-kit", "docs-html", "docs-pdf", "other"}
MAX_RETRIES = 2


class PipelineError(ValueError):
    pass


@dataclass
class ArtifactSpec:
    path: str
    role: str


@dataclass
class Stage:
    name: str
    run: str = ""
    uses: str = ""
    needs: list[str] = field(default_factory=list)
    network: str = "none"
    timeout_s: int | None = None
    retries: int = 0
    retry_on: list[str] = field(default_factory=lambda: ["error"])
    lockfiles: list[str] = field(default_factory=list)
    reports: dict = field(default_factory=dict)
    artifacts: list[ArtifactSpec] = field(default_factory=list)
    allow_failure: bool = False

    @property
    def kind(self) -> str:
        return "builtin" if self.uses else "command"


@dataclass
class Pipeline:
    version: int
    stages: list[Stage]
    env: dict[str, str] = field(default_factory=dict)
    platform: str = "linux-x86_64"

    def as_dict(self) -> dict:
        return asdict(self)

    def sha256(self) -> str:
        return hashlib.sha256(json.dumps(self.as_dict(), sort_keys=True).encode()).hexdigest()

    def lockfiles(self) -> list[str]:
        out: list[str] = []
        for s in self.stages:
            out += [p for p in s.lockfiles if p not in out]
        return out


def parse(text: str) -> Pipeline:
    try:
        data = tomllib.loads(text)
    except tomllib.TOMLDecodeError as exc:
        raise PipelineError(f"invalid TOML: {exc}") from exc
    if data.get("version") != 1:
        raise PipelineError("pipeline version must be 1")
    raw_stages = data.get("stages") or []
    if not raw_stages:
        raise PipelineError("pipeline defines no stages")
    stages: list[Stage] = []
    seen: set[str] = set()
    for raw in raw_stages:
        name = raw.get("name", "")
        if not NAME_RE.match(name) or name == "checkout":
            raise PipelineError(f"invalid stage name {name!r}")
        if name in seen:
            raise PipelineError(f"duplicate stage {name}")
        run, uses = raw.get("run", ""), raw.get("uses", "")
        if bool(run) == bool(uses):
            raise PipelineError(f"stage {name}: exactly one of 'run' or 'uses' is required")
        if uses and uses not in BUILTINS:
            raise PipelineError(f"stage {name}: unknown builtin {uses}")
        needs = list(raw.get("needs", []))
        for n in needs:
            if n not in seen:
                raise PipelineError(f"stage {name} needs {n!r}, which must be declared earlier")
        network = raw.get("network", "none")
        if network not in ("none", "egress"):
            raise PipelineError(f"stage {name}: network must be 'none' or 'egress'")
        retries = int(raw.get("retries", 0))
        if not 0 <= retries <= MAX_RETRIES:
            raise PipelineError(f"stage {name}: retries must be between 0 and {MAX_RETRIES}")
        arts = []
        for a in raw.get("artifacts", []):
            if a.get("role") not in ROLES:
                raise PipelineError(f"stage {name}: artifact role must be one of {sorted(ROLES)}")
            if a["path"].startswith("/") or ".." in a["path"]:
                raise PipelineError(f"stage {name}: artifact path must be relative")
            arts.append(ArtifactSpec(a["path"], a["role"]))
        stages.append(Stage(name=name, run=run, uses=uses, needs=needs, network=network,
                            timeout_s=raw.get("timeout_s"), retries=retries,
                            retry_on=list(raw.get("retry_on", ["error"])), lockfiles=list(raw.get("lockfiles", [])),
                            reports=dict(raw.get("reports", {})), artifacts=arts,
                            allow_failure=bool(raw.get("allow_failure", False))))
        seen.add(name)
    env = {str(k): str(v) for k, v in (data.get("env") or {}).items()}
    return Pipeline(version=1, stages=stages, env=env, platform=data.get("platform", "linux-x86_64"))
