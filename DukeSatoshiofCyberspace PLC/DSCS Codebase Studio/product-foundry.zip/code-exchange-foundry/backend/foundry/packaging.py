"""Edition manifests and packages, and physical packaging artwork.

Mockups (with guides, watermark and barcode placeholder) are kept strictly separate from print-ready
artwork. Print-ready export is refused unless the edition carries a configured GTIN with a valid check
digit: the Foundry never invents a barcode allocation.
"""
from __future__ import annotations

import html
import io
import json
import zipfile
from textwrap import wrap

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from foundry.models import (Artifact, Artwork, Document, Edition, LicenceVersion, PackagingTemplate,
                            PlatformVerification, Product, Release, ReleaseEdition)
from foundry.storage import read_verified

EPOCH = (2023, 11, 14, 22, 13, 20)
KIND_CONTENTS = {
    "digital-download": ["application", "docs-html", "notices"],
    "source-archive": ["source", "docs-html", "notices", "sbom"],
    "developer-kit": ["application", "source", "starter-kit", "docs-html", "docs-pdf", "notices", "sbom"],
    "boxed-key": ["application", "docs-pdf", "notices"],
    "usb-collector": ["application", "source", "starter-kit", "docs-html", "docs-pdf", "notices", "sbom"],
}
DEFAULT_TEMPLATES = [
    {"name": "Standard software box (DVD-style case insert)", "kind": "dvd-style-box",
     "dimensions": {"front_w_mm": 130, "h_mm": 184, "spine_mm": 14, "bleed_mm": 3, "safe_mm": 5, "min_dpi": 300}},
    {"name": "USB collector tin sleeve", "kind": "usb-tin",
     "dimensions": {"front_w_mm": 95, "h_mm": 65, "spine_mm": 20, "bleed_mm": 2, "safe_mm": 4, "min_dpi": 300}},
]


# ------------------------------------------------------------------ edition packages
def _zip_add(zf: zipfile.ZipFile, name: str, data: bytes) -> None:
    info = zipfile.ZipInfo(name, EPOCH)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o644 << 16
    zf.writestr(info, data)


def edition_roles(db: Session, e: Edition) -> list[str]:
    if e.kind == "bundle":
        roles: list[str] = []
        for bid in e.bundle_edition_ids or []:
            for r in edition_roles(db, db.get(Edition, bid)):
                if r not in roles:
                    roles.append(r)
        return roles
    return list(e.contents or KIND_CONTENTS.get(e.kind, ["application"]))


def build_edition_package(db: Session, rel: Release, e: Edition, frozen: list[Artifact], docs: list[Document]):
    from foundry.builder import store_artifact
    product = db.get(Product, rel.product_id)
    lic = db.get(LicenceVersion, e.licence_version_id)
    roles = edition_roles(db, e)
    chosen = [a for a in frozen if a.role in roles]
    # documentation is optional at packaging time (readiness enforces it); software artefacts are not
    missing = [r for r in roles if r not in {a.role for a in chosen} and not r.startswith("docs")]
    if missing:
        raise HTTPException(409, f"edition {e.code} requires artefact roles not produced for this release: {missing}")
    root = f"{product.slug}-{rel.version}-{e.code}"
    files = []
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for a in sorted(chosen, key=lambda x: (x.role, x.filename)):
            data = read_verified(a.storage_key, a.sha256)
            sub = "docs/" if a.role.startswith("docs") else ""
            _zip_add(zf, f"{root}/{sub}{a.filename}", data)
            files.append({"path": f"{sub}{a.filename}", "role": a.role, "sha256": a.sha256, "size": a.size})
        lic_text = f"{lic.title} — version {lic.version}\n\n{lic.text}\n".encode()
        _zip_add(zf, f"{root}/LICENCE.txt", lic_text)
        if e.delivery_method == "download-key":
            _zip_add(zf, f"{root}/ACTIVATION.txt", (
                "Redeem the download key printed inside your box at your Code Exchange library.\n"
                "The key entitles you to this edition under the licence above; see the update policy in MANIFEST.json.\n"
            ).encode())
        inner = {"product": product.slug, "version": rel.version, "edition": e.code, "files": files,
                 "licence": {"code": lic.code, "version": lic.version, "text_sha256": lic.text_sha256}}
        _zip_add(zf, f"{root}/MANIFEST.json", json.dumps(inner, indent=2, sort_keys=True).encode())
    data = buf.getvalue()
    pkg = store_artifact(db, rel.project_id, None, "edition-package", f"{root}.zip", data, "application/zip",
                         "foundry/packaging")
    manifest = {
        "product": product.slug, "release": rel.version, "commit": rel.commit_sha,
        "edition": {"code": e.code, "name": e.name, "kind": e.kind, "sku": e.sku, "gtin": e.gtin,
                    "delivery_method": e.delivery_method},
        "includes": files, "includes_roles": roles,
        "licence": {"code": lic.code, "version": lic.version, "title": lic.title, "rights": lic.rights,
                    "text_sha256": lic.text_sha256},
        "update_policy": e.update_policy, "support": {"days": e.support_days, "terms": e.support_terms},
        "package": {"filename": pkg.filename, "sha256": pkg.sha256, "size": pkg.size},
        "bundle_of": e.bundle_edition_ids or [],
    }
    return manifest, pkg


# ------------------------------------------------------------------ barcode (EAN-13 / GTIN-13)
L = ["0001101", "0011001", "0010011", "0111101", "0100011", "0110001", "0101111", "0111011", "0110111", "0001011"]
G = ["0100111", "0110011", "0011011", "0100001", "0011101", "0111001", "0000101", "0010001", "0001001", "0010111"]
R = ["1110010", "1100110", "1101100", "1000010", "1011100", "1001110", "1010000", "1000100", "1001000", "1110100"]
PARITY = ["LLLLLL", "LLGLGG", "LLGGLG", "LLGGGL", "LGLLGG", "LGGLLG", "LGGGLL", "LGLGLG", "LGLGGL", "LGGLGL"]


def gtin_check_digit(body: str) -> int:
    # weights from the right: 3,1,3,1... over the 12-digit body
    total = sum(int(d) * (3 if i % 2 == 0 else 1) for i, d in enumerate(reversed(body)))
    return (10 - total % 10) % 10


def valid_gtin13(code: str | None) -> bool:
    return bool(code and len(code) == 13 and code.isdigit() and gtin_check_digit(code[:12]) == int(code[12]))


def ean13_bits(code: str) -> str:
    if not valid_gtin13(code):
        raise ValueError("not a valid GTIN-13")
    first, left, right = int(code[0]), code[1:7], code[7:]
    bits = "101"
    for d, p in zip(left, PARITY[first]):
        bits += (L if p == "L" else G)[int(d)]
    bits += "01010"
    for d in right:
        bits += R[int(d)]
    return bits + "101"


# ------------------------------------------------------------------ artwork
GRAPHITE, MAGENTA, IVORY, INK = "#1d1c1f", "#c8006e", "#f6f1e7", "#f3efe6"


def _text_block(x, y, width_mm, lines_in, size_pt, color, weight="400", max_lines=None):
    """Lay out wrapped text; returns (svg, height_mm, overflowed_lines)."""
    size_mm = size_pt * 0.3528
    chars = max(8, int(width_mm / (size_mm * 0.55)))
    lines = []
    for raw in lines_in:
        lines += wrap(raw, chars) or [""]
    overflow = 0
    if max_lines is not None and len(lines) > max_lines:
        overflow = len(lines) - max_lines
        lines = lines[:max_lines]
    lh = size_mm * 1.3
    out = [f'<text x="{x:.2f}" y="{y + size_mm:.2f}" font-family="Inter, Helvetica, Arial, sans-serif" '
           f'font-size="{size_mm:.2f}" font-weight="{weight}" fill="{color}">']
    for i, ln in enumerate(lines):
        out.append(f'<tspan x="{x:.2f}" dy="{0 if i == 0 else lh:.2f}">{html.escape(ln)}</tspan>')
    out.append("</text>")
    return "".join(out), lh * len(lines), overflow


def render_box(db: Session, edition: Edition, rel: Release, template: PackagingTemplate, purpose: str) -> tuple[str, dict]:
    if purpose not in ("mockup", "print"):
        raise ValueError("purpose must be mockup or print")
    product = db.get(Product, edition.product_id)
    lic = db.get(LicenceVersion, edition.licence_version_id) if edition.licence_version_id else None
    d = template.dimensions
    fw, h, sp, bl, sf = d["front_w_mm"], d["h_mm"], d["spine_mm"], d["bleed_mm"], d["safe_mm"]
    total_w, total_h = 2 * fw + sp + 2 * bl, h + 2 * bl
    back_x, spine_x, front_x = bl, bl + fw, bl + fw + sp
    errors, warnings = [], []
    verified = [v.platform for v in db.execute(select(PlatformVerification).where(
        PlatformVerification.release_id == rel.id, PlatformVerification.result == "passed")).scalars()]
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{total_w}mm" height="{total_h}mm" '
             f'viewBox="0 0 {total_w} {total_h}" role="img" aria-label="{html.escape(product.name)} box artwork">',
             f'<rect x="0" y="0" width="{total_w}" height="{total_h}" fill="{GRAPHITE}"/>',
             f'<rect x="{front_x}" y="0" width="{fw + bl}" height="{bl + 18}" fill="{MAGENTA}"/>',
             f'<rect x="{spine_x}" y="0" width="{sp}" height="{total_h}" fill="#2a282d"/>']
    # front panel
    pad = 2  # keep text clear of the safe-area line
    inner_w = fw - 2 * sf - 2 * pad
    y = bl + sf + 18
    for txt, size, weight, color, ml in ((product.name, 26, "800", INK, 2), (product.tagline, 10, "400", "#d9d2c4", 3),
                                         (f"{edition.name}", 12, "700", MAGENTA, 2),
                                         (f"Version {rel.version}", 10, "600", INK, 1)):
        svg, hh, ov = _text_block(front_x + sf + pad, y, inner_w, [txt], size, color, weight, ml)
        parts.append(svg)
        y += hh + 5
        if ov:
            errors.append(f"front text '{txt[:30]}' overflows its area by {ov} line(s)")
    # stylised product mark (original artwork drawn from primitives)
    cx, cy = front_x + fw / 2, bl + h * 0.68
    parts.append(f'<g transform="translate({cx - 25},{cy - 25})"><rect width="50" height="50" rx="7" fill="{MAGENTA}"/>'
                 '<path d="M10 13h30v5H10zm0 10h30v5H10zm0 10h20v5H10z" fill="#fff"/></g>')
    # spine (rotated)
    parts.append(f'<text transform="translate({spine_x + sp / 2 + 1.5},{bl + sf + 4}) rotate(90)" '
                 f'font-family="Inter, Helvetica, Arial, sans-serif" font-size="{min(sp * 0.45, 5.5):.2f}" font-weight="700" '
                 f'fill="{INK}">{html.escape(product.name)} · {html.escape(edition.code)} · {html.escape(rel.version)}</text>')
    # back panel
    y = bl + sf + pad
    blocks = [([product.description], 8, "400", INK, 9),
              (["System requirements: Python 3.10 or later."] +
               [f"Verified: {', '.join(verified) or 'none recorded'}"], 7, "400", "#d9d2c4", 4),
              ([f"Licence: {lic.title} v{lic.version}." if lic else "Licence: NOT SET", (lic.summary if lic else "")],
               7, "400", "#d9d2c4", 6),
              (["Download: redeem the key inside this box at your Code Exchange library."
                if edition.delivery_method == "download-key" else "Contents: USB media with the files listed in the manifest."],
               7, "600", INK, 3)]
    for lines, size, weight, color, ml in blocks:
        svg, hh, ov = _text_block(back_x + sf + pad, y, fw - 2 * sf - 2 * pad, lines, size, color, weight, ml)
        parts.append(svg)
        y += hh + 4
        if ov:
            errors.append(f"back text block overflows by {ov} line(s)")
    if not lic:
        errors.append("edition has no licence version")
    # SKU and barcode area
    bx, by, bw, bh = back_x + sf + pad, bl + h - sf - pad - 26, 42, 26
    parts.append(f'<rect x="{bx}" y="{by}" width="{bw}" height="{bh}" fill="#ffffff"/>')
    if valid_gtin13(edition.gtin):
        bits = ean13_bits(edition.gtin)
        mod = (bw - 8) / len(bits)
        for i, b in enumerate(bits):
            if b == "1":
                parts.append(f'<rect x="{bx + 4 + i * mod:.3f}" y="{by + 2}" width="{mod:.3f}" height="{bh - 8}" fill="#000"/>')
        parts.append(f'<text x="{bx + bw / 2}" y="{by + bh - 1.5}" font-size="3" text-anchor="middle" '
                     f'font-family="monospace">{edition.gtin}</text>')
    else:
        parts.append(f'<text x="{bx + bw / 2}" y="{by + 11}" font-size="2.6" text-anchor="middle" fill="#a3005c" '
                     f'font-family="monospace">BARCODE PLACEHOLDER</text><text x="{bx + bw / 2}" y="{by + 15}" '
                     'font-size="2.2" text-anchor="middle" fill="#a3005c" font-family="monospace">NO GTIN ALLOCATED</text>')
        if edition.gtin:
            errors.append(f"configured GTIN {edition.gtin} has an invalid check digit")
        elif purpose == "print":
            errors.append("no GTIN is configured for this edition; allocate one through GS1 before print export "
                          "(Product Foundry never generates barcode numbers)")
        else:
            warnings.append("no GTIN configured: mockup shows a placeholder")
    parts.append(f'<text x="{bx + bw + 3}" y="{by + 6}" font-size="3" fill="{INK}" font-family="monospace">'
                 f'SKU {html.escape(edition.sku)}</text>')
    if purpose == "mockup":
        parts.append(f'<rect x="{bl}" y="{bl}" width="{total_w - 2 * bl}" height="{h}" fill="none" stroke="#ff3b30" '
                     'stroke-width="0.3" stroke-dasharray="2 1"/>')
        for px in (back_x, front_x):
            parts.append(f'<rect x="{px + sf}" y="{bl + sf}" width="{fw - 2 * sf}" height="{h - 2 * sf}" fill="none" '
                         'stroke="#34c759" stroke-width="0.25" stroke-dasharray="1 1"/>')
        parts.append(f'<text x="{total_w / 2}" y="{total_h / 2}" font-size="9" fill="#ffffff" fill-opacity="0.25" '
                     f'text-anchor="middle" transform="rotate(-20 {total_w / 2} {total_h / 2})" '
                     'font-family="sans-serif" font-weight="800">MOCKUP — NOT FOR PRINT</text>')
    else:
        for (x0, y0) in ((bl, bl), (total_w - bl, bl), (bl, total_h - bl), (total_w - bl, total_h - bl)):
            parts.append(f'<path d="M{x0 - 2} {y0}h-1M{x0} {y0 - 2}v-1" stroke="#000" stroke-width="0.2"/>')
        warnings.append("SVG uses RGB colour; convert to the printer's CMYK profile and embed fonts at prepress")
    if sp < 8:
        warnings.append("spine narrower than 8 mm; spine text may be illegible")
    parts.append("</svg>")
    validation = {"purpose": purpose, "template": template.name, "trim_mm": [2 * fw + sp, h],
                  "with_bleed_mm": [total_w, total_h], "bleed_mm": bl, "safe_mm": sf,
                  "errors": errors, "warnings": warnings, "valid": not errors,
                  "panels": {"back": [back_x, fw], "spine": [spine_x, sp], "front": [front_x, fw]}}
    return "".join(parts), validation


def create_artwork(db: Session, edition: Edition, rel: Release, template: PackagingTemplate, purpose: str) -> Artwork:
    from foundry.builder import store_artifact
    svg, validation = render_box(db, edition, rel, template, purpose)
    if purpose == "print" and not validation["valid"]:
        aw = Artwork(edition_id=edition.id, release_id=rel.id, template_id=template.id, purpose=purpose,
                     artifact_id=None, validation=validation, status="invalid")
        db.add(aw)
        db.flush()
        return aw
    art = store_artifact(db, rel.project_id, None, "artwork", f"{edition.code}-{rel.version}-{purpose}.svg",
                         svg.encode(), "image/svg+xml", "foundry/packaging")
    aw = Artwork(edition_id=edition.id, release_id=rel.id, template_id=template.id, purpose=purpose,
                 artifact_id=art.id, validation=validation, status="valid" if validation["valid"] else "invalid")
    db.add(aw)
    db.flush()
    return aw


def ensure_templates(db: Session) -> None:
    for t in DEFAULT_TEMPLATES:
        if not db.execute(select(PackagingTemplate).where(PackagingTemplate.kind == t["kind"])).first():
            db.add(PackagingTemplate(**t))


def manifests_for_release(db: Session, rel: Release) -> list[dict]:
    out = []
    for re_ in db.execute(select(ReleaseEdition).where(ReleaseEdition.release_id == rel.id)).scalars():
        e = db.get(Edition, re_.edition_id)
        out.append({"edition_id": e.id, "edition": e.code, "kind": e.kind, "manifest": re_.manifest,
                    "manifest_sha256": re_.manifest_sha256, "package_artifact_id": re_.package_artifact_id})
    return out
