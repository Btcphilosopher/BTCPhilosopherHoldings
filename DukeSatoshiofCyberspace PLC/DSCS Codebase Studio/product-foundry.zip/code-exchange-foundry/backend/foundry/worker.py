"""Background worker: claims durable jobs and runs builds in disposable sandboxes.

    python -m foundry.worker            # run forever
    python -m foundry.worker --drain    # run until the queue is empty (tests / demo)
"""
from __future__ import annotations

import argparse
import logging
import signal
import socket
import time
import uuid

from foundry import builder, catalogue, config, docs, jobs, support  # noqa: F401  (register handlers)
from foundry.db import session_scope

log = logging.getLogger("foundry.worker")
_stop = False


def _sig(*_):
    global _stop
    _stop = True


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--drain", action="store_true")
    ap.add_argument("--kinds", nargs="*")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    signal.signal(signal.SIGTERM, _sig)
    signal.signal(signal.SIGINT, _sig)
    worker_id = f"{socket.gethostname()}-{uuid.uuid4().hex[:6]}"
    log.info("worker %s started (sandbox=%s)", worker_id, config.settings.sandbox)
    last_recover = 0.0
    while not _stop:
        if time.monotonic() - last_recover > 60:
            with session_scope() as db:
                n = jobs.recover_stale(db)
                if n:
                    log.warning("requeued %s stale job(s)", n)
            last_recover = time.monotonic()
        job = jobs.run_one(worker_id, args.kinds)
        if job is not None:
            log.info("job %s %s -> %s", job.id, job.kind, job.status)
            continue
        if args.drain:
            break
        time.sleep(config.settings.worker_poll_seconds)
    log.info("worker %s stopped", worker_id)


if __name__ == "__main__":
    main()
