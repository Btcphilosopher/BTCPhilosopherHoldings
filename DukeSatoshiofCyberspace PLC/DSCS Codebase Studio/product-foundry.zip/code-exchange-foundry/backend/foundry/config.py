"""Runtime configuration, read from environment variables (see .env.example)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass
class Settings:
    database_url: str = field(default_factory=lambda: os.environ.get(
        "FOUNDRY_DATABASE_URL", "postgresql+psycopg://foundry:foundry@localhost:5432/foundry"))
    secret_key: str = field(default_factory=lambda: os.environ.get("FOUNDRY_SECRET_KEY", "dev-only-change-me"))
    token_ttl_minutes: int = field(default_factory=lambda: int(os.environ.get("FOUNDRY_TOKEN_TTL_MINUTES", "720")))

    # Object storage. "s3" uses any S3-compatible endpoint; "local" stores under storage_root.
    storage_backend: str = field(default_factory=lambda: os.environ.get("FOUNDRY_STORAGE_BACKEND", "local"))
    storage_root: Path = field(default_factory=lambda: Path(os.environ.get("FOUNDRY_STORAGE_ROOT", "./var/objects")))
    s3_endpoint: str | None = field(default_factory=lambda: os.environ.get("FOUNDRY_S3_ENDPOINT"))
    s3_bucket: str = field(default_factory=lambda: os.environ.get("FOUNDRY_S3_BUCKET", "foundry"))
    s3_region: str = field(default_factory=lambda: os.environ.get("FOUNDRY_S3_REGION", "us-east-1"))
    s3_access_key: str | None = field(default_factory=lambda: os.environ.get("FOUNDRY_S3_ACCESS_KEY"))
    s3_secret_key: str | None = field(default_factory=lambda: os.environ.get("FOUNDRY_S3_SECRET_KEY"))

    # Local Git repositories that may be connected. Paths outside these roots are refused.
    repo_roots: list[Path] = field(default_factory=lambda: [
        Path(p).resolve() for p in os.environ.get("FOUNDRY_REPO_ROOTS", "./var/repos").split(os.pathsep) if p])
    work_root: Path = field(default_factory=lambda: Path(os.environ.get("FOUNDRY_WORK_ROOT", "./var/work")))

    # Build sandbox: "docker" (recommended) or "local" (unshare + rlimits; development only).
    sandbox: str = field(default_factory=lambda: os.environ.get("FOUNDRY_SANDBOX", "local"))
    sandbox_image: str = field(default_factory=lambda: os.environ.get("FOUNDRY_SANDBOX_IMAGE", "python:3.13-slim"))
    sandbox_memory_mb: int = field(default_factory=lambda: int(os.environ.get("FOUNDRY_SANDBOX_MEMORY_MB", "512")))
    sandbox_cpus: float = field(default_factory=lambda: float(os.environ.get("FOUNDRY_SANDBOX_CPUS", "1.0")))
    sandbox_pids: int = field(default_factory=lambda: int(os.environ.get("FOUNDRY_SANDBOX_PIDS", "128")))
    sandbox_timeout_s: int = field(default_factory=lambda: int(os.environ.get("FOUNDRY_SANDBOX_TIMEOUT_S", "600")))
    sandbox_require_netns: bool = field(default_factory=lambda: _bool("FOUNDRY_SANDBOX_REQUIRE_NETNS", True))
    # Vetted, read-only dependency cache offered to the dependency stage instead of internet access.
    wheelhouse: Path = field(default_factory=lambda: Path(os.environ.get("FOUNDRY_WHEELHOUSE", "./var/wheelhouse")))

    storefront_url: str = field(default_factory=lambda: os.environ.get("FOUNDRY_STOREFRONT_URL", "http://localhost:8100"))
    storefront_token: str = field(default_factory=lambda: os.environ.get("FOUNDRY_STOREFRONT_TOKEN", "storefront-dev-token"))

    # Optional AI assistant. "offline" is a deterministic local drafter; "anthropic" calls the Claude API.
    assistant_provider: str = field(default_factory=lambda: os.environ.get("FOUNDRY_ASSISTANT_PROVIDER", "offline"))
    assistant_model: str = field(default_factory=lambda: os.environ.get("FOUNDRY_ASSISTANT_MODEL", "claude-opus-5-5"))

    # Separation of duties: the release creator may not approve it, and listing approval needs a catalogue editor.
    require_separate_approver: bool = field(default_factory=lambda: _bool("FOUNDRY_REQUIRE_SEPARATE_APPROVER", True))
    worker_poll_seconds: float = field(default_factory=lambda: float(os.environ.get("FOUNDRY_WORKER_POLL_SECONDS", "1.0")))
    editor_url_template: str = field(default_factory=lambda: os.environ.get(
        "FOUNDRY_EDITOR_URL_TEMPLATE", "vscode://file{path}"))


settings = Settings()


def reload_settings() -> Settings:
    global settings
    settings = Settings()
    return settings
