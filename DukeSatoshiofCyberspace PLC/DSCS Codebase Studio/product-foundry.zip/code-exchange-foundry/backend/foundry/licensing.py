"""SBOM generation from actual build inputs, third-party notices, and licence routing.

Nothing in this module establishes legal clearance. It classifies declared licence metadata
and routes anything uncertain or potentially incompatible to a human licence reviewer.
"""
from __future__ import annotations

import email.parser
import json
import re
import uuid
from pathlib import Path

from foundry.db import utcnow

TOOL = "foundry-sbom"
TOOL_VERSION = "1.0.0"

PERMISSIVE = {"MIT", "BSD-2-Clause", "BSD-3-Clause", "Apache-2.0", "ISC", "PSF-2.0", "Python-2.0", "Zlib",
              "0BSD", "Unlicense", "CC0-1.0", "MIT-0", "CC-BY-4.0"}
WEAK_COPYLEFT = {"LGPL-2.1-only", "LGPL-2.1-or-later", "LGPL-3.0-only", "LGPL-3.0-or-later", "MPL-2.0", "EPL-2.0"}
STRONG_COPYLEFT = {"GPL-2.0-only", "GPL-2.0-or-later", "GPL-3.0-only", "GPL-3.0-or-later", "AGPL-3.0-only",
                   "AGPL-3.0-or-later"}
NAME_ALIASES = {"mit license": "MIT", "mit": "MIT", "bsd": "NOASSERTION", "apache 2.0": "Apache-2.0",
                "apache software license": "Apache-2.0", "bsd license": "NOASSERTION",
                "python software foundation license": "PSF-2.0"}
CLASSIFIER_MAP = {"License :: OSI Approved :: MIT License": "MIT",
                  "License :: OSI Approved :: Apache Software License": "Apache-2.0",
                  "License :: OSI Approved :: BSD License": "NOASSERTION",
                  "License :: OSI Approved :: ISC License (ISCL)": "ISC",
                  "License :: OSI Approved :: Mozilla Public License 2.0 (MPL 2.0)": "MPL-2.0",
                  "License :: OSI Approved :: GNU General Public License v3 (GPLv3)": "GPL-3.0-only",
                  "License :: OSI Approved :: GNU Lesser General Public License v3 (LGPLv3)": "LGPL-3.0-only"}


def classify(spdx: str) -> str:
    if (spdx or "").startswith("LicenceRef-TCX-"):
        return "first-party"  # owned by The Code Exchange per contributor records
    ids = [p for p in re.split(r"\s+(?:AND|OR|WITH)\s+|[()]", spdx or "") if p.strip()]
    if not ids or any(i in ("NOASSERTION", "UNKNOWN") for i in ids):
        return "unknown"
    if " OR " in spdx and any(i in PERMISSIVE for i in ids):
        return "permissive"  # a permissive option exists; the reviewer still confirms the election
    if any(i in STRONG_COPYLEFT for i in ids):
        return "strong-copyleft"
    if any(i in WEAK_COPYLEFT for i in ids):
        return "weak-copyleft"
    if all(i in PERMISSIVE for i in ids):
        return "permissive"
    return "unknown"


def route(category: str, distribution: str) -> str | None:
    """Return a review issue for a component in a proprietary commercial product, or None."""
    if category in ("permissive", "first-party"):
        return None
    if category == "unknown":
        return "Licence could not be determined from package metadata; a reviewer must confirm the terms."
    if category == "weak-copyleft":
        return ("Weak-copyleft licence: obligations depend on how the component is linked and distributed "
                f"({distribution}). Reviewer must confirm relinking/source-offer requirements.")
    return ("Strong-copyleft licence is likely incompatible with proprietary binary distribution. "
            "Reviewer must decide; do not ship until resolved.")


def _metadata_licence(meta) -> tuple[str, str]:
    expr = meta.get("License-Expression")
    if expr:
        return expr.strip(), "License-Expression"
    for c in meta.get_all("Classifier") or []:
        if c in CLASSIFIER_MAP:
            return CLASSIFIER_MAP[c], f"classifier: {c}"
    lic = (meta.get("License") or "").strip()
    if lic:
        return NAME_ALIASES.get(lic.lower(), "NOASSERTION"), f"License field: {lic[:60]}"
    return "NOASSERTION", "no licence metadata"


def parse_lockfile(text: str) -> dict[str, dict]:
    """requirements-style lockfile: ``name==version --hash=sha256:...`` per line."""
    pins: dict[str, dict] = {}
    for line in text.splitlines():
        line = line.split("#", 1)[0].strip()
        if not line or line.startswith("-"):
            continue
        m = re.match(r"^([A-Za-z0-9_.\-]+)==([A-Za-z0-9_.+\-!]+)(.*)$", line)
        if not m:
            raise ValueError(f"lockfile entry is not pinned: {line}")
        hashes = re.findall(r"--hash=sha256:([0-9a-f]{64})", m.group(3))
        pins[m.group(1).lower().replace("_", "-")] = {"version": m.group(2), "hashes": hashes}
    return pins


def scan_installed(workspace: Path, deps_dir: str, lock: dict[str, dict]) -> list[dict]:
    """Read *.dist-info of what was actually installed for this build."""
    comps = []
    base = workspace / deps_dir
    for dist in sorted(base.glob("*.dist-info")) if base.exists() else []:
        meta_path = dist / "METADATA"
        if not meta_path.is_file() or meta_path.is_symlink():
            continue
        meta = email.parser.Parser().parsestr(meta_path.read_text(errors="replace")[:200_000], headersonly=True)
        name = (meta.get("Name") or dist.name.split("-")[0]).strip()
        version = (meta.get("Version") or "").strip()
        spdx, source = _metadata_licence(meta)
        lic_files = [p for p in dist.rglob("*") if p.is_file() and not p.is_symlink()
                     and re.match(r"(LICEN[CS]E|COPYING|NOTICE)", p.name, re.I)]
        key = name.lower().replace("_", "-")
        pinned = lock.get(key)
        comps.append({
            "name": name, "version": version, "purl": f"pkg:pypi/{key}@{version}",
            "licence_declared": spdx, "licence_source": source, "scope": "runtime",
            "origin": f"wheelhouse (lockfile pin {pinned['version']})" if pinned else "installed but NOT in lockfile",
            "sha256": (pinned or {}).get("hashes", [""])[0] if pinned and pinned.get("hashes") else "",
            "in_lockfile": bool(pinned), "lock_version_matches": bool(pinned and pinned["version"] == version),
            "licence_texts": {p.name: p.read_text(errors="replace")[:100_000] for p in lic_files},
            "author": (meta.get("Author-email") or meta.get("Author") or "").strip(),
        })
    return comps


def cyclonedx(project: dict, commit: str, components: list[dict]) -> dict:
    return {
        "bomFormat": "CycloneDX", "specVersion": "1.6", "serialNumber": f"urn:uuid:{uuid.uuid4()}", "version": 1,
        "metadata": {"timestamp": utcnow().isoformat(), "tools": {"components": [
            {"type": "application", "name": TOOL, "version": TOOL_VERSION}]},
            "component": {"type": "application", "name": project["name"], "version": project.get("version", commit[:12]),
                          "bom-ref": "root", "properties": [{"name": "foundry:commit", "value": commit}]}},
        "components": [{
            "type": "library", "bom-ref": c["purl"], "name": c["name"], "version": c["version"], "purl": c["purl"],
            "licenses": [{"expression": c["licence_declared"]}] if c["licence_declared"] != "NOASSERTION" else [],
            "hashes": [{"alg": "SHA-256", "content": c["sha256"]}] if c["sha256"] else [],
            "properties": [{"name": "foundry:licence-source", "value": c["licence_source"]},
                           {"name": "foundry:origin", "value": c["origin"]}],
        } for c in components],
        "dependencies": [{"ref": "root", "dependsOn": [c["purl"] for c in components]}],
    }


def notices_text(product_name: str, components: list[dict], assets: list[dict]) -> str:
    lines = [f"THIRD-PARTY NOTICES for {product_name}", "=" * 60, "",
             "This product includes the following third-party software. Each component is provided under",
             "its own licence, reproduced below. These notices were generated from the build's installed",
             "dependency metadata and must be reviewed by a licence reviewer before release.", ""]
    for c in components:
        lines += [f"--- {c['name']} {c['version']} ({c['licence_declared']})", f"Package URL: {c['purl']}"]
        if c.get("author"):
            lines.append(f"Copyright holder (from metadata): {c['author']}")
        for fname, text in c.get("licence_texts", {}).items():
            lines += ["", f"[{fname}]", text.strip()]
        lines.append("")
    if assets:
        lines += ["--- Assets", ""]
        for a in assets:
            lines.append(f"{a['path']}: {a['licence']} — {a.get('attribution') or a['origin']}")
    return "\n".join(lines) + "\n"


def asset_manifest(workspace: Path) -> list[dict]:
    p = workspace / "assets" / "ASSETS.json"
    if not p.is_file() or p.is_symlink():
        return []
    try:
        return json.loads(p.read_text())[:500]
    except json.JSONDecodeError:
        return [{"path": "assets/ASSETS.json", "licence": "UNKNOWN", "origin": "unparseable manifest"}]
