"""Optional AI development assistant.

Guarantees, enforced here and by the permission model:
* Repository access requires an explicit scope: one commit and a list of paths. Nothing outside the
  scope is read or sent to a model.
* Generated changes are committed to a new ``assistant/<run>`` branch (never a protected branch) and a
  build is queued for that commit; a human reviews and merges outside the assistant.
* The assistant identity has no permission to publish releases, approve anything, change licence terms
  or read production credentials. It cannot merge.
* Each run records the provider/model configuration and a manifest of inputs (path, sha256, size) -
  not the file contents - so generated changes can be understood without retaining source text.

Providers: ``offline`` (deterministic local drafter, default, no network) and ``anthropic``
(Claude via the official ``anthropic`` SDK, enabled with ANTHROPIC_API_KEY and
FOUNDRY_ASSISTANT_PROVIDER=anthropic).
"""
from __future__ import annotations

import ast
import hashlib
import json
import re

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from foundry import audit, config
from foundry.builder import create_build, store_artifact
from foundry.gitadapter import adapter_for
from foundry.models import AssistantRun, Project, Repository, Requirement, Task, User

ACTIONS = ("propose-tasks", "explain", "draft-tests", "draft-docs", "suggest-patch")
MAX_SCOPE_FILES = 20
MAX_SCOPE_BYTES = 200_000
SYSTEM = ("You assist engineers at The Code Exchange. Work only from the files and verified project facts provided. "
          "Mark any statement you cannot support from them with [UNVERIFIED]. Never claim platforms, performance or "
          "security properties that are not stated in the facts.")


def assistant_user(db: Session) -> User:
    u = db.execute(select(User).where(User.email == "assistant@foundry.invalid")).scalar_one_or_none()
    if u is None:
        u = User(email="assistant@foundry.invalid", name="Foundry assistant", password_hash="!", roles=["assistant"],
                 is_service=True)
        db.add(u)
        db.flush()
    return u


def _load_scope(repo: Repository, commit: str, paths: list[str]) -> tuple[str, dict[str, str], list[dict]]:
    if not paths:
        raise HTTPException(422, "an explicit list of repository paths is required")
    if len(paths) > MAX_SCOPE_FILES:
        raise HTTPException(422, f"scope limited to {MAX_SCOPE_FILES} files")
    ad = adapter_for(repo)
    sha = ad.resolve(commit)
    files, manifest, total = {}, [], 0
    for p in paths:
        f = ad.read_file(sha, p)
        if f["binary"] or f["truncated"]:
            raise HTTPException(422, f"{p} is binary or too large for assistant scope")
        total += f["size"]
        if total > MAX_SCOPE_BYTES:
            raise HTTPException(422, "scope exceeds size limit")
        files[p] = f["content"]
        manifest.append({"path": p, "sha256": hashlib.sha256(f["content"].encode()).hexdigest(), "bytes": f["size"]})
    return sha, files, manifest


# ------------------------------------------------------------------ offline provider
def _offline(action: str, files: dict[str, str], facts: dict) -> dict:
    if action == "explain":
        out = []
        for path, text in files.items():
            if not path.endswith(".py"):
                out.append(f"{path}: {len(text.splitlines())} lines (non-Python file; not analysed).")
                continue
            tree = ast.parse(text)
            doc = ast.get_docstring(tree) or "no module docstring"
            items = []
            for n in tree.body:
                if isinstance(n, ast.FunctionDef):
                    items.append(f"function `{n.name}({', '.join(a.arg for a in n.args.args)})` - "
                                 f"{(ast.get_docstring(n) or 'undocumented').splitlines()[0]}")
                elif isinstance(n, ast.ClassDef):
                    items.append(f"class `{n.name}` with {sum(isinstance(m, ast.FunctionDef) for m in n.body)} method(s)")
            imports = sorted({a.name for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names} |
                             {n.module for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) and n.module})
            out.append(f"### {path}\n{doc}\n\n" + "\n".join(f"- {i}" for i in items) + f"\n\nImports: {', '.join(imports)}")
        return {"text": "\n\n".join(out)}
    if action == "propose-tasks":
        return {"tasks": [{"title": f"Implement and test {r['key']}: {r['title']}", "requirement_key": r["key"],
                           "rationale": "Requirement has no linked task."} for r in facts["untasked_requirements"]]}
    if action == "draft-tests":
        new_files = {}
        for path, text in files.items():
            if not path.endswith(".py") or not path.startswith("src/"):
                continue
            mod = path[4:-3].replace("/", ".")
            funcs = [n.name for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and not n.name.startswith("_")]
            if not funcs:
                continue
            name = mod.split(".")[-1]
            lines = ["import unittest", "", f"import {mod}", "", "",
                     f"class Draft{name.title().replace('_', '')}Tests(unittest.TestCase):",
                     '    """Assistant-drafted smoke tests. Review, then replace with behavioural assertions."""', ""]
            for fn in funcs:
                lines += [f"    def test_{fn}_is_callable(self):",
                          f"        self.assertTrue(callable({mod}.{fn}))", ""]
            lines += ["", 'if __name__ == "__main__":', "    unittest.main()", ""]
            new_files[f"tests/test_assistant_{name}.py"] = "\n".join(lines)
        return {"files": new_files, "text": f"Drafted {len(new_files)} test module(s)."}
    if action == "draft-docs":
        body = [f"# {facts['product']} — draft overview", "", facts.get("idea", ""), "",
                "## Verified facts used", *[f"- {k}: {v}" for k, v in facts.items() if isinstance(v, str)],
                "", "## Statements needing evidence",
                "- [UNVERIFIED] Performance on very large files beyond the tested 100,000 rows."]
        return {"text": "\n".join(body)}
    if action == "suggest-patch":
        return {"text": "The offline provider does not generate code changes. Configure the Anthropic provider "
                        "(FOUNDRY_ASSISTANT_PROVIDER=anthropic) to request a reviewable patch.", "files": {}}
    raise HTTPException(422, "unknown action")


# ------------------------------------------------------------------ Claude provider
def _anthropic(action: str, files: dict[str, str], facts: dict, instruction: str) -> tuple[dict, dict]:
    try:
        import anthropic
    except ImportError as exc:  # pragma: no cover - optional dependency
        raise HTTPException(503, "install the 'anthropic' package to use this provider") from exc
    model = config.settings.assistant_model
    cfg = {"provider": "anthropic", "model": model, "effort": "medium", "fallbacks": "default", "max_tokens": 16000}
    sources = "\n\n".join(f'<file path="{p}">\n{t}\n</file>' for p, t in files.items())
    want_files = action in ("draft-tests", "suggest-patch")
    task = {"explain": "Explain what this code does and how the parts fit together.",
            "propose-tasks": "Propose implementation tasks for the untasked requirements, one line each.",
            "draft-tests": "Write unittest test modules for this code.",
            "draft-docs": "Draft user documentation from the verified facts.",
            "suggest-patch": "Propose a minimal change that addresses the instruction."}[action]
    fmt = ('Respond with JSON only: {"text": "<explanation>", "files": {"<path>": "<complete new file content>"}}'
           if want_files else 'Respond with JSON only: {"text": "<markdown>"}')
    client = anthropic.Anthropic()
    try:
        resp = client.beta.messages.create(
            model=model, max_tokens=16000, betas=["server-side-fallback-2026-07-01"], fallbacks="default",
            output_config={"effort": "medium"}, system=SYSTEM,
            messages=[{"role": "user", "content": f"{task}\n{instruction}\n\nVerified facts:\n{json.dumps(facts)}\n\n"
                                                  f"{sources}\n\n{fmt}"}])
    except anthropic.RateLimitError as exc:
        raise HTTPException(429, "assistant rate limited; retry later") from exc
    except anthropic.APIStatusError as exc:
        raise HTTPException(502, f"assistant provider error {exc.status_code}") from exc
    except anthropic.APIConnectionError as exc:
        raise HTTPException(502, "assistant provider unreachable") from exc
    if resp.stop_reason == "refusal":
        return {"text": "The model declined this request.", "files": {}}, cfg | {"stop_reason": "refusal"}
    text = "".join(b.text for b in resp.content if b.type == "text")
    m = re.search(r"\{.*\}", text, re.S)
    try:
        data = json.loads(m.group(0)) if m else {"text": text}
    except json.JSONDecodeError:
        data = {"text": text}
    cfg["served_by"] = resp.model
    return data, cfg


# ------------------------------------------------------------------ entry point
def run(db: Session, project: Project, repo: Repository | None, user: User, action: str, scope: dict,
        instruction: str = "") -> AssistantRun:
    if action not in ACTIONS:
        raise HTTPException(422, f"action must be one of {ACTIONS}")
    files, manifest, commit = {}, [], None
    if action != "propose-tasks":
        if repo is None:
            raise HTTPException(422, "a repository is required")
        commit, files, manifest = _load_scope(repo, scope.get("commit") or repo.default_branch, scope.get("paths", []))
    reqs = db.execute(select(Requirement).where(Requirement.project_id == project.id)).scalars().all()
    tasked = {rid for t in db.execute(select(Task).where(Task.project_id == project.id)).scalars()
              for rid in (t.requirement_ids or [])}
    facts = {"product": project.name, "idea": project.idea, "platforms_claimed": ", ".join(project.supported_platforms),
             "untasked_requirements": [{"key": r.key, "title": r.title} for r in reqs if r.id not in tasked]}
    if config.settings.assistant_provider == "anthropic":
        out, cfg = _anthropic(action, files, facts, instruction)
    else:
        out, cfg = _offline(action, files, facts), {"provider": "offline", "version": "1.0"}
    bot = assistant_user(db)
    ar = AssistantRun(project_id=project.id, repository_id=repo.id if repo else None, requested_by=user.id,
                      action=action, scope={"commit": commit, "paths": scope.get("paths", []),
                                            "instruction_sha256": hashlib.sha256(instruction.encode()).hexdigest()},
                      provider=cfg["provider"], model_config_=cfg, inputs_manifest=manifest,
                      output={k: v for k, v in out.items() if k != "files"} | {"files": sorted((out.get("files") or {}))})
    db.add(ar)
    db.flush()
    new_files = out.get("files") or {}
    if new_files and repo is not None:
        ad = adapter_for(repo)
        branch = f"assistant/run-{ar.id}"
        sha = ad.commit_files_to_branch(commit, branch, new_files,
                                        f"Assistant draft ({action}) for review\n\nFoundry assistant run {ar.id}",
                                        "Foundry Assistant", repo.protected_branches or [])
        patch = ad.diff_patch(commit, sha)
        art = store_artifact(db, project.id, None, "other", f"assistant-run-{ar.id}.patch", patch.encode(),
                             "text/x-diff", "assistant")
        ar.branch, ar.patch_artifact_id = branch, art.id
        build = create_build(db, project, repo, sha, bot, trigger="assistant")
        ar.build_id = build.id
    audit.record(db, user, "assistant.run", "assistant_run", ar.id, project.id, assistant_action=action,
                 provider=cfg["provider"], model=cfg.get("model"), inputs=len(manifest), branch=ar.branch)
    return ar
