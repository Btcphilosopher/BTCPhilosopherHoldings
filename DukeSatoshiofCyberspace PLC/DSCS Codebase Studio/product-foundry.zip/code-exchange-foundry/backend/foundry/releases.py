"""Release management: Draft -> Candidate -> Validation -> Approved -> Published -> Superseded | Withdrawn.

* A candidate freezes the commit, artefacts, documentation revisions, licence versions and the
  per-edition manifests/packages. The manifest hash covers all of them.
* Approval re-verifies every frozen artefact against object storage and requires every readiness
  check to pass or carry an active documented exception.
* From approval onward the release and its artefacts are immutable (enforced in ``before_flush``).
  Corrections require a new release or an explicit withdrawal.
"""
from __future__ import annotations

import hashlib
import json
import re
from datetime import date, timedelta

from fastapi import HTTPException
from sqlalchemy import event, inspect, select
from sqlalchemy.orm import Session

from foundry import audit, config
from foundry.db import utcnow
from foundry.models import (Advisory, Approval, Artifact, Artwork, Build, BuildStage, Document, Edition,
                            LicenceReview, LicenceVersion, PlatformVerification, Product, Project,
                            ReadinessException, Release, ReleaseArtifact, ReleaseEdition, Requirement,
                            RequirementEvidence, ReviewRecord, ScanFinding, ScanRun, SupportIssue, TestResult)
from foundry.storage import IntegrityError, read_verified

TRANSITIONS = {
    "draft": {"candidate"},
    "candidate": {"validation", "draft"},
    "validation": {"approved", "draft"},
    "approved": {"published", "withdrawn"},
    "published": {"superseded", "withdrawn"},
    "superseded": {"withdrawn"},
    "withdrawn": set(),
}
FROZEN = {"approved", "published", "superseded", "withdrawn"}
MUTABLE_AFTER_APPROVAL = {"status", "published_at", "superseded_by_id", "withdrawn_reason", "history",
                          "end_of_support_on"}
RELEASE_ARTEFACT_ROLES = ("application", "source", "starter-kit", "sbom", "notices")
REQUIRED_DOCS = ("quick-start", "installation", "user-guide", "system-requirements", "release-notes",
                 "third-party-notices", "support")
SEMVER = re.compile(r"^\d+\.\d+\.\d+(?:-[0-9A-Za-z.]+)?$")


class ImmutableError(Exception):
    pass


# ------------------------------------------------------------------ immutability guard
@event.listens_for(Session, "before_flush")
def _guard(session: Session, flush_context, instances) -> None:
    for obj in session.dirty:
        if isinstance(obj, Release):
            st = inspect(obj)
            prev_status = st.attrs.status.history.deleted
            committed_status = prev_status[0] if prev_status else obj.status
            if committed_status in FROZEN:
                changed = {a.key for a in st.attrs if a.history.has_changes()}
                illegal = changed - MUTABLE_AFTER_APPROVAL
                if illegal:
                    raise ImmutableError(f"release {obj.version} is {committed_status}; cannot change {sorted(illegal)}")
        elif isinstance(obj, Artifact):
            st = inspect(obj)
            if obj.locked or (st.attrs.locked.history.deleted or [False])[0]:
                changed = {a.key for a in st.attrs if a.history.has_changes()} - {"locked"}
                if changed:
                    raise ImmutableError(f"artefact {obj.id} is locked by a release; cannot change {sorted(changed)}")
                if st.attrs.locked.history.deleted and st.attrs.locked.history.deleted[0] and not obj.locked:
                    raise ImmutableError("artefacts cannot be unlocked")
        elif isinstance(obj, Document) and obj.locked:
            st = inspect(obj)
            changed = {a.key for a in st.attrs if a.history.has_changes()} - {"locked"}
            if changed and not st.attrs.locked.history.added:
                raise ImmutableError("document revision is locked by a release; create a new revision")
    for obj in list(session.new) + list(session.deleted):
        if isinstance(obj, (ReleaseArtifact, ReleaseEdition)):
            rel = session.get(Release, obj.release_id)
            if rel is not None and rel.status in FROZEN:
                raise ImmutableError(f"release {rel.version} is {rel.status}; its contents cannot change")
    for obj in session.deleted:
        if isinstance(obj, Artifact) and obj.locked:
            raise ImmutableError("locked artefacts cannot be deleted")
        if isinstance(obj, Release) and obj.status in FROZEN:
            raise ImmutableError("frozen releases cannot be deleted")


# ------------------------------------------------------------------ helpers
def _hist(rel: Release, user, action: str, **extra) -> None:
    rel.history = list(rel.history or []) + [{"at": utcnow().isoformat(), "by": getattr(user, "email", "system"),
                                              "action": action, **extra}]


def _transition(db: Session, rel: Release, to: str, user, **extra) -> None:
    if to not in TRANSITIONS[rel.status]:
        raise HTTPException(409, f"cannot move release from {rel.status} to {to}")
    frm = rel.status
    rel.status = to
    _hist(rel, user, f"{frm}->{to}", **extra)
    audit.record(db, user, f"release.{to}", "release", rel.id, rel.project_id, version=rel.version, frm=frm, **extra)


def canonical_sha(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def _major(version: str) -> int:
    return int(version.split(".")[0])


# ------------------------------------------------------------------ draft
def create_release(db: Session, product: Product, version: str, build: Build, user, notes: str = "") -> Release:
    if not SEMVER.match(version):
        raise HTTPException(422, "version must be semantic (MAJOR.MINOR.PATCH)")
    if build.status != "passed":
        raise HTTPException(409, f"build #{build.number} is {build.status}; releases need a passing build")
    if build.project_id != product.project_id:
        raise HTTPException(422, "build belongs to another project")
    app = db.execute(select(Artifact).where(Artifact.build_id == build.id, Artifact.role == "application")).scalars().all()
    if not app:
        raise HTTPException(409, "build produced no application artefact")
    if not any(version in a.filename for a in app):
        raise HTTPException(409, f"application artefact {app[0].filename} does not carry version {version}; "
                                 "the release version must match the built software")
    project = db.get(Project, product.project_id)
    rel = Release(project_id=product.project_id, product_id=product.id, version=version, status="draft",
                  build_id=build.id, commit_sha=build.commit_sha, notes=notes,
                  platform_claims=list(project.supported_platforms or []), created_by=user.id, history=[],
                  compatibility={"replaces": None, "data_format": "unchanged", "minimum_python": "3.10"})
    db.add(rel)
    db.flush()
    for ed in db.execute(select(Edition).where(Edition.product_id == product.id, Edition.active.is_(True))).scalars():
        db.add(ReleaseEdition(release_id=rel.id, edition_id=ed.id))
    _hist(rel, user, "created", build=build.number, commit=build.commit_sha)
    auto_verify_platforms(db, rel)
    audit.record(db, user, "release.created", "release", rel.id, rel.project_id, version=version,
                 build=build.id, commit=build.commit_sha)
    return rel


def update_draft(db: Session, rel: Release, user, **fields) -> Release:
    if rel.status != "draft":
        raise HTTPException(409, f"release is {rel.status}; return it to draft to change its claims or contents")
    for k in ("notes", "platform_claims", "compatibility", "end_of_support_on"):
        if k in fields and fields[k] is not None:
            setattr(rel, k, fields[k])
    if "edition_ids" in fields and fields["edition_ids"] is not None:
        for re_ in db.execute(select(ReleaseEdition).where(ReleaseEdition.release_id == rel.id)).scalars():
            db.delete(re_)
        db.flush()
        for eid in fields["edition_ids"]:
            db.add(ReleaseEdition(release_id=rel.id, edition_id=eid))
    _hist(rel, user, "draft-updated", fields=sorted(k for k, v in fields.items() if v is not None))
    audit.record(db, user, "release.updated", "release", rel.id, rel.project_id,
                 fields={k: v for k, v in fields.items() if v is not None})
    return rel


# ------------------------------------------------------------------ candidate
def freeze_candidate(db: Session, rel: Release, user) -> Release:
    from foundry import docs as docs_mod
    from foundry import packaging

    if rel.status != "draft":
        raise HTTPException(409, "only drafts can become candidates")
    build = db.get(Build, rel.build_id)
    arts = {a.role: a for a in db.execute(select(Artifact).where(Artifact.build_id == build.id,
                                                                 Artifact.role.in_(RELEASE_ARTEFACT_ROLES))).scalars()}
    for required in ("application", "sbom", "notices"):
        if required not in arts:
            raise HTTPException(409, f"build is missing required artefact role '{required}'")
    editions = [db.get(Edition, re_.edition_id) for re_ in
                db.execute(select(ReleaseEdition).where(ReleaseEdition.release_id == rel.id)).scalars()]
    if not editions:
        raise HTTPException(409, "a release needs at least one edition")
    lic_ids = sorted({e.licence_version_id for e in editions if e.licence_version_id})
    for e in editions:
        if not e.licence_version_id:
            raise HTTPException(409, f"edition {e.code} has no licence version")
        lv = db.get(LicenceVersion, e.licence_version_id)
        if lv.status != "approved":
            raise HTTPException(409, f"licence {lv.code} v{lv.version} for edition {e.code} is not approved")

    # documentation: latest approved revision of each kind for this release, rendered and stored
    doc_rows = docs_mod.latest_for_release(db, rel.id, approved_only=True)
    for d in doc_rows:
        docs_mod.render_artifacts(db, d)
        d.locked = True
    # clean previous candidate links when re-freezing after a return to draft
    for ra in db.execute(select(ReleaseArtifact).where(ReleaseArtifact.release_id == rel.id)).scalars():
        db.delete(ra)
    db.flush()
    frozen: list[Artifact] = list(arts.values())
    for d in doc_rows:
        for aid in (d.html_artifact_id, d.pdf_artifact_id):
            if aid:
                frozen.append(db.get(Artifact, aid))
    for a in frozen:
        db.add(ReleaseArtifact(release_id=rel.id, artifact_id=a.id, role=a.role))
        a.locked = True
    db.flush()

    edition_entries = []
    for e in editions:
        re_ = db.execute(select(ReleaseEdition).where(ReleaseEdition.release_id == rel.id,
                                                      ReleaseEdition.edition_id == e.id)).scalar_one()
        manifest, pkg = packaging.build_edition_package(db, rel, e, frozen, doc_rows)
        re_.manifest, re_.manifest_sha256, re_.package_artifact_id = manifest, canonical_sha(manifest), pkg.id
        pkg.locked = True
        edition_entries.append({"edition": e.code, "kind": e.kind, "manifest_sha256": re_.manifest_sha256,
                                "package": {"filename": pkg.filename, "sha256": pkg.sha256, "size": pkg.size}})
    lic_entries = []
    for lid in lic_ids:
        lv = db.get(LicenceVersion, lid)
        lic_entries.append({"code": lv.code, "version": lv.version, "text_sha256": lv.text_sha256})
    rel.licence_version_ids = lic_ids
    manifest = {
        "product": db.get(Product, rel.product_id).slug, "version": rel.version,
        "source": {"repository_id": build.repository_id, "commit": build.commit_sha,
                   "pipeline_sha256": build.pipeline_sha256, "build": build.number, "lockfiles": build.lockfiles},
        "artifacts": sorted([{"role": a.role, "filename": a.filename, "sha256": a.sha256, "size": a.size}
                             for a in frozen], key=lambda x: (x["role"], x["filename"])),
        "documents": [{"kind": d.kind, "revision": d.revision, "id": d.id} for d in doc_rows],
        "licences": lic_entries, "editions": edition_entries, "platform_claims": rel.platform_claims,
    }
    rel.manifest, rel.manifest_sha256 = manifest, canonical_sha(manifest)
    _transition(db, rel, "candidate", user, manifest_sha256=rel.manifest_sha256)
    return rel


def start_validation(db: Session, rel: Release, user) -> Release:
    if rel.status != "candidate":
        raise HTTPException(409, "release must be a candidate")
    auto_verify_platforms(db, rel)
    _transition(db, rel, "validation", user)
    db.flush()
    rel.readiness_snapshot = evaluate(db, rel)
    return rel


def auto_verify_platforms(db: Session, rel: Release) -> None:
    """The build worker's own platform is verified by the release build itself (incl. installation test)."""
    build = db.get(Build, rel.build_id)
    worker_platform = (build.worker_env or {}).get("pipeline_platform")
    worker_actual = (build.worker_env or {}).get("worker_platform", "").replace("amd64", "x86_64")
    if worker_platform and worker_platform in (rel.platform_claims or []) and worker_actual == worker_platform:
        exists = db.execute(select(PlatformVerification).where(PlatformVerification.release_id == rel.id,
                                                               PlatformVerification.platform == worker_platform)).first()
        if not exists:
            db.add(PlatformVerification(release_id=rel.id, platform=worker_platform, method="build-worker",
                                        result="passed" if build.status == "passed" else "failed", build_id=build.id,
                                        evidence=f"Build #{build.number} pipeline including installation test ran on "
                                                 f"a {worker_actual} worker ({(build.worker_env or {}).get('sandbox')} sandbox)"))
            db.flush()


def return_to_draft(db: Session, rel: Release, user, reason: str) -> Release:
    _transition(db, rel, "draft", user, reason=reason)
    rel.manifest_sha256 = None
    return rel


# ------------------------------------------------------------------ readiness
def _check(key, title, status, summary, evidence=None):
    return {"key": key, "title": title, "status": status, "summary": summary, "evidence": evidence or []}


def evaluate(db: Session, rel: Release) -> dict:
    build = db.get(Build, rel.build_id)
    project = db.get(Project, rel.project_id)
    checks = []

    # 1. required workflows / requirements
    reqs = db.execute(select(Requirement).where(Requirement.project_id == rel.project_id,
                                                Requirement.required_for_release.is_(True))).scalars().all()
    problems, ev = [], []
    for r in reqs:
        evid = db.execute(select(RequirementEvidence).where(RequirementEvidence.requirement_id == r.id)
                          .order_by(RequirementEvidence.id.desc())).scalars().all()
        at_commit = [e for e in evid if e.commit_sha == build.commit_sha or e.kind in ("manual", "document")]
        latest_fail = [e for e in at_commit if e.result == "failed"]
        passing = [e for e in at_commit if e.result == "passed"]
        ev.append({"type": "requirement", "id": r.id, "label": f"{r.key} {r.title}", "status": r.status,
                   "evidence": [{"id": e.id, "kind": e.kind, "ref": e.reference, "result": e.result} for e in at_commit[:5]]})
        if r.status != "accepted":
            problems.append(f"{r.key} is {r.status}, not accepted")
        elif latest_fail and not passing:
            problems.append(f"{r.key} has failing evidence at this commit")
        elif not passing:
            problems.append(f"{r.key} has no passing evidence at commit {build.commit_sha[:10]}")
    checks.append(_check("requirements", "Required workflows and acceptance criteria",
                         "passed" if reqs and not problems else "failed",
                         "; ".join(problems) if problems else f"{len(reqs)} required requirement(s) accepted with evidence",
                         ev))

    # 2. tests
    trs = db.execute(select(TestResult).where(TestResult.build_id == build.id)).scalars().all()
    failed = [t for t in trs if t.status in ("failed", "error")]
    checks.append(_check("tests", "Automated test results",
                         "passed" if trs and not failed and build.status == "passed" else "failed",
                         f"{len(trs) - len(failed)}/{len(trs)} passed in build #{build.number} at {build.commit_sha[:10]}",
                         [{"type": "build", "id": build.id, "label": f"Build #{build.number}"}] +
                         [{"type": "test", "id": t.id, "label": f"{t.name}: {t.status}"} for t in failed]))

    # 3. installation
    install = db.execute(select(BuildStage).where(BuildStage.build_id == build.id,
                                                  BuildStage.name == "validate-package")).scalars().all()
    inst_ok = any(s.status == "passed" for s in install)
    manual = _review(db, rel, "installation")
    checks.append(_check("installation", "Installation and upgrade tests",
                         "passed" if inst_ok and (manual is None or manual.result == "passed") else "failed",
                         ("Packaged application installed and executed in a clean sandbox" if inst_ok
                          else "validate-package stage did not pass") +
                         (f"; manual review: {manual.result}" if manual else ""),
                         [{"type": "stage", "id": s.id, "label": f"validate-package: {s.status}"} for s in install] +
                         ([{"type": "review", "id": manual.id, "label": manual.evidence[:80]}] if manual else [])))

    # 4. platforms
    plat_ev, missing = [], []
    for p in rel.platform_claims or []:
        v = db.execute(select(PlatformVerification).where(PlatformVerification.release_id == rel.id,
                                                          PlatformVerification.platform == p)
                       .order_by(PlatformVerification.id.desc())).scalars().first()
        if v is None or v.result != "passed":
            missing.append(p)
        plat_ev.append({"type": "platform", "label": p, "status": v.result if v else "unverified",
                        "detail": v.evidence if v else "No verification recorded", "id": v.id if v else None})
    checks.append(_check("platforms", "Supported-platform verification",
                         "passed" if rel.platform_claims and not missing else "failed",
                         (f"Claimed platform(s) without verification: {', '.join(missing)}. "
                          "Remove the claim or record verification evidence.") if missing
                         else f"{len(rel.platform_claims or [])} claimed platform(s) verified", plat_ev))

    # 5. known defects
    defects = db.execute(select(SupportIssue).where(SupportIssue.product_id == rel.product_id,
                                                    SupportIssue.kind == "bug",
                                                    SupportIssue.status.notin_(["fixed", "closed"]))).scalars().all()
    blocking = [d for d in defects if (d.severity_reviewed or "") in ("critical", "high")]
    unreviewed = [d for d in defects if not d.severity_reviewed]
    checks.append(_check("defects", "Known defects",
                         "failed" if blocking or unreviewed else "passed",
                         f"{len(defects)} open defect(s); {len(blocking)} high/critical; {len(unreviewed)} awaiting severity review",
                         [{"type": "issue", "id": d.id, "label": f"{d.external_ref} [{d.severity_reviewed or 'unreviewed'}] {d.title}"}
                          for d in defects]))

    # 6. accessibility
    acc = _review(db, rel, "accessibility")
    checks.append(_check("accessibility", "Accessibility review",
                         "passed" if acc and acc.result == "passed" else "failed",
                         acc.evidence[:200] if acc else "No accessibility review recorded",
                         [{"type": "review", "id": acc.id, "label": acc.evidence[:80]}] if acc else []))

    # 7. dependency & vulnerability findings
    runs = db.execute(select(ScanRun).where(ScanRun.build_id == build.id)).scalars().all()
    findings = db.execute(select(ScanFinding).where(ScanFinding.build_id == build.id,
                                                    ScanFinding.status == "open")).scalars().all()
    serious = [f for f in findings if f.severity in ("high", "critical")]
    checks.append(_check("security", "Dependency and vulnerability findings",
                         "failed" if serious or not runs else ("warning" if findings else "passed"),
                         (f"{len(findings)} open finding(s) from {len(runs)} scan(s). " if runs else "No scans recorded. ") +
                         "Scanners report what they detected; no findings is not a guarantee of security.",
                         [{"type": "scan", "id": r.id, "label": f"{r.tool} {r.tool_version} (db {r.database_version}) "
                                                               f"at {r.scanned_at:%Y-%m-%d %H:%M} UTC: {r.finding_count} finding(s)"}
                          for r in runs] +
                         [{"type": "finding", "id": f.id, "label": f"[{f.severity}] {f.identifier} {f.component}"} for f in findings]))

    # 8. documentation
    from foundry import docs as docs_mod
    docs_ = {d.kind: d for d in docs_mod.latest_for_release(db, rel.id, approved_only=False)}
    doc_problems = []
    for kind in REQUIRED_DOCS:
        d = docs_.get(kind)
        if d is None:
            doc_problems.append(f"{kind} missing")
        elif d.status != "approved":
            doc_problems.append(f"{kind} is {d.status}")
        elif any(f.get("severity") == "unsupported" and not f.get("resolved") for f in d.flags or []):
            doc_problems.append(f"{kind} has unresolved unsupported statements")
        elif any(x.get("result") == "failed" for x in d.example_results or []):
            doc_problems.append(f"{kind} has failing executable examples")
    frozen_doc_ids = {x["id"] for x in (rel.manifest or {}).get("documents", [])}
    if rel.status in ("candidate", "validation") and {d.id for d in docs_.values() if d.status == "approved"} - frozen_doc_ids:
        doc_problems.append("approved documentation differs from the frozen candidate; return to draft to refreeze")
    checks.append(_check("documentation", "Documentation", "failed" if doc_problems else "passed",
                         "; ".join(doc_problems) if doc_problems else f"{len(REQUIRED_DOCS)} required documents approved",
                         [{"type": "document", "id": d.id, "label": f"{d.kind} r{d.revision}: {d.status}"} for d in docs_.values()]))

    # 9. licences & provenance
    lic_problems, lic_ev = [], []
    fingerprints = [f"{c['purl']}#{c['licence']}" for c in (build.summary or {}).get("components", [])] + \
                   [f"{a['path']}#{a['licence']}" for a in (build.summary or {}).get("assets", [])]
    for fp in fingerprints:
        rv = db.execute(select(LicenceReview).where(LicenceReview.project_id == rel.project_id,
                                                    LicenceReview.subject_ref == fp)).scalars().first()
        if rv:
            lic_ev.append({"type": "licence-review", "id": rv.id, "label": f"{fp}: {rv.status}"})
            if rv.status not in ("cleared",):
                lic_problems.append(f"{fp} review is {rv.status}")
    for lid in rel.licence_version_ids or []:
        lv = db.get(LicenceVersion, lid)
        lic_ev.append({"type": "licence", "id": lv.id, "label": f"{lv.code} v{lv.version}: {lv.status}"})
        if lv.status != "approved":
            lic_problems.append(f"{lv.code} v{lv.version} not approved")
    if not (build.summary or {}).get("components") and not any(
            a.role == "sbom" for a in db.execute(select(Artifact).where(Artifact.build_id == build.id)).scalars()):
        lic_problems.append("no SBOM for this build")
    checks.append(_check("licences", "Licence and provenance review", "failed" if lic_problems else "passed",
                         ("; ".join(lic_problems) if lic_problems else
                          "All routed items cleared by a licence reviewer and licence versions approved") +
                         ". Automated analysis is not legal clearance.", lic_ev))

    # 10. support readiness
    sup = _review(db, rel, "support")
    sup_problems = []
    if not project.support_owner_id:
        sup_problems.append("no support owner")
    if not rel.end_of_support_on:
        sup_problems.append("no end-of-support date")
    if not sup or sup.result != "passed":
        sup_problems.append("support readiness review not passed")
    checks.append(_check("support", "Support readiness", "failed" if sup_problems else "passed",
                         "; ".join(sup_problems) if sup_problems else
                         f"Support owner assigned; supported until {rel.end_of_support_on}",
                         [{"type": "review", "id": sup.id, "label": sup.evidence[:80]}] if sup else []))

    # 11. packaging / editions
    pk_problems, pk_ev = [], []
    for re_ in db.execute(select(ReleaseEdition).where(ReleaseEdition.release_id == rel.id)).scalars():
        e = db.get(Edition, re_.edition_id)
        if not re_.package_artifact_id:
            pk_problems.append(f"{e.code}: no package")
        pk_ev.append({"type": "edition", "id": e.id, "label": f"{e.code}: manifest {re_.manifest_sha256[:12] or 'none'}"})
        if e.kind in ("boxed-key", "usb-collector"):
            mock = db.execute(select(Artwork).where(Artwork.edition_id == e.id, Artwork.release_id == rel.id,
                                                    Artwork.purpose == "mockup").order_by(Artwork.id.desc())).scalars().first()
            if not mock or mock.status != "valid":
                pk_problems.append(f"{e.code}: no valid packaging mockup")
    checks.append(_check("packaging", "Editions, manifests and packaging", "failed" if pk_problems else "passed",
                         "; ".join(pk_problems) if pk_problems else "Every edition has a manifest and package", pk_ev))

    # apply documented exceptions
    today = date.today()
    excs = db.execute(select(ReadinessException).where(ReadinessException.release_id == rel.id,
                                                       ReadinessException.revoked.is_(False))).scalars().all()
    for c in checks:
        for x in excs:
            if x.check_key == c["key"] and c["status"] == "failed" and (x.expires_on is None or x.expires_on >= today):
                c["status"] = "excepted"
                c["exception"] = {"id": x.id, "owner_id": x.owner_id, "reason": x.reason, "scope": x.scope,
                                  "expires_on": x.expires_on.isoformat() if x.expires_on else None}
    blocking = [c["key"] for c in checks if c["status"] == "failed"]
    result = {"release_id": rel.id, "version": rel.version, "evaluated_at": utcnow().isoformat(),
              "commit": build.commit_sha, "manifest_sha256": rel.manifest_sha256, "checks": checks,
              "blocking": blocking, "ready": not blocking}
    result["sha256"] = canonical_sha({k: v for k, v in result.items() if k != "evaluated_at"})
    return result


def _review(db: Session, rel: Release, key: str):
    return db.execute(select(ReviewRecord).where(ReviewRecord.release_id == rel.id, ReviewRecord.check_key == key)
                      .order_by(ReviewRecord.id.desc())).scalars().first()


def verify_integrity(db: Session, rel: Release) -> list[dict]:
    out = []
    ids = [ra.artifact_id for ra in db.execute(select(ReleaseArtifact).where(ReleaseArtifact.release_id == rel.id)).scalars()]
    ids += [re_.package_artifact_id for re_ in db.execute(select(ReleaseEdition).where(ReleaseEdition.release_id == rel.id)).scalars()
            if re_.package_artifact_id]
    for aid in ids:
        a = db.get(Artifact, aid)
        try:
            read_verified(a.storage_key, a.sha256)
            out.append({"artifact": a.filename, "sha256": a.sha256, "ok": True})
        except (IntegrityError, FileNotFoundError, Exception) as exc:  # noqa: BLE001
            out.append({"artifact": a.filename, "sha256": a.sha256, "ok": False, "error": str(exc)[:200]})
    return out


# ------------------------------------------------------------------ approval
def approve(db: Session, rel: Release, user, comment: str = "") -> Release:
    if rel.status != "validation":
        raise HTTPException(409, "release must be in validation")
    if config.settings.require_separate_approver and rel.created_by == user.id:
        raise HTTPException(403, "separation of duties: the person who created a release cannot approve it")
    integrity = verify_integrity(db, rel)
    if not integrity or not all(i["ok"] for i in integrity):
        raise HTTPException(409, f"artefact integrity check failed: {[i for i in integrity if not i['ok']]}")
    if rel.manifest_sha256 != canonical_sha(rel.manifest):
        raise HTTPException(409, "release manifest does not match its recorded hash")
    readiness = evaluate(db, rel)
    if not readiness["ready"]:
        raise HTTPException(409, {"message": "release is not ready", "blocking": readiness["blocking"],
                                  "readiness": readiness})
    rel.readiness_snapshot = readiness
    db.add(Approval(release_id=rel.id, kind="release", user_id=user.id, decision="approved", comment=comment,
                    readiness_sha256=readiness["sha256"]))
    rel.approved_by, rel.approved_at = user.id, utcnow()
    _transition(db, rel, "approved", user, readiness_sha256=readiness["sha256"], manifest_sha256=rel.manifest_sha256)
    return rel


# ------------------------------------------------------------------ publication outcomes
def mark_published(db: Session, rel: Release, user=None) -> None:
    if rel.status == "approved":
        rel.published_at = utcnow()
        _transition(db, rel, "published", user)
        older = db.execute(select(Release).where(Release.product_id == rel.product_id, Release.id != rel.id,
                                                 Release.status == "published")).scalars().all()
        for o in older:
            if _version_key(o.version) < _version_key(rel.version):
                o.superseded_by_id = rel.id
                _transition(db, o, "superseded", user, superseded_by=rel.version)


def _version_key(v: str):
    return tuple(int(x) for x in v.split("-")[0].split("."))


def withdraw(db: Session, rel: Release, user, reason: str) -> Advisory:
    if not reason.strip():
        raise HTTPException(422, "a withdrawal needs a reason")
    _transition(db, rel, "withdrawn", user, reason=reason)
    rel.withdrawn_reason = reason
    adv = Advisory(product_id=rel.product_id, release_id=rel.id, kind="withdrawal",
                   title=f"Version {rel.version} has been withdrawn",
                   body=(f"{reason}\n\nWithdrawing a release stops new downloads and removes it from the catalogue. "
                         "It does not remove copies that customers have already downloaded or installed; "
                         "follow the guidance in this advisory for installed copies."))
    db.add(adv)
    db.flush()
    return adv


def end_of_support_default(days: int = 365) -> date:
    return date.today() + timedelta(days=days)
