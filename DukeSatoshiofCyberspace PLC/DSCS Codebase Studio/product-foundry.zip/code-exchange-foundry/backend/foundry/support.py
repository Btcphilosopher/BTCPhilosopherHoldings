"""Customer support import, redaction, triage and update-eligibility rules."""
from __future__ import annotations

import hashlib
import re
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from foundry import audit, config, jobs
from foundry.db import session_scope
from foundry.models import (CatalogueListing, CustomerContact, Edition, Entitlement, Product, Release, SupportIssue)

EMAIL = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
PHONE = re.compile(r"(?<!\w)(?:\+?\d[\d\s().\-]{8,}\d)(?!\w)")
HOME_PATH = re.compile(r"(/home/|/Users/|C:\\\\Users\\\\|C:\\Users\\)([^/\\\s]+)")
CARD = re.compile(r"\b(?:\d[ -]?){13,19}\b")


def customer_ref(email: str) -> str:
    """Stable pseudonymous reference; the raw address lives only in CustomerContact."""
    return hashlib.sha256((config.settings.secret_key + ":" + email.strip().lower()).encode()).hexdigest()[:24]


def redact(text: str, known: list[str] = ()) -> tuple[str, list[str]]:
    kinds = []
    for name, rx, repl in (("email", EMAIL, "[email redacted]"), ("card-number", CARD, "[number redacted]"),
                           ("phone", PHONE, "[phone redacted]")):
        if rx.search(text):
            kinds.append(name)
            text = rx.sub(repl, text)
    if HOME_PATH.search(text):
        kinds.append("user-path")
        text = HOME_PATH.sub(lambda m: m.group(1) + "[user]", text)
    for k in known:
        if k and len(k) > 2 and k in text:
            kinds.append("customer-name")
            text = text.replace(k, "[customer]")
    return text, sorted(set(kinds))


# ------------------------------------------------------------------ entitlements
def _vkey(v: str):
    return tuple(int(x) for x in v.split("-")[0].split("."))


def eligible_release_ids(db: Session, ent: Entitlement) -> list[int]:
    """Which releases the customer may download, derived only from the purchased entitlement.

    * Only the purchased edition (or editions inside a purchased bundle) - never other editions.
    * Only major versions the policy covers.
    * Only releases published within the update window (the purchased release is always included).
    * Withdrawn releases are never offered; refunded/revoked entitlements receive nothing.
    """
    if ent.status != "active":
        return []
    edition = db.get(Edition, ent.edition_id)
    edition_ids = [edition.id] + list(edition.bundle_edition_ids or [])
    policy = ent.update_policy or {}
    majors = set(policy.get("covered_major_versions") or [])
    window_end = ent.purchased_at + timedelta(days=int(policy.get("updates_for_days", 0)))
    patch_only = policy.get("patch_updates_only", False)
    purchased = db.get(Release, ent.purchased_release_id) if ent.purchased_release_id else None
    out = []
    from foundry.models import ReleaseEdition
    for rel in db.execute(select(Release).where(Release.product_id == edition.product_id,
                                                Release.status.in_(["published", "superseded"]))).scalars():
        in_edition = db.execute(select(ReleaseEdition).where(ReleaseEdition.release_id == rel.id,
                                                             ReleaseEdition.edition_id.in_(edition_ids))).first()
        if not in_edition:
            continue
        if purchased and rel.id == purchased.id:
            out.append(rel.id)
            continue
        if majors and _vkey(rel.version)[0] not in majors:
            continue
        if patch_only and purchased and _vkey(rel.version)[:2] != _vkey(purchased.version)[:2]:
            continue
        if rel.published_at is None or rel.published_at > window_end:
            continue
        if purchased and _vkey(rel.version) < _vkey(purchased.version):
            continue
        out.append(rel.id)
    return sorted(out)


# ------------------------------------------------------------------ import
@jobs.handler("support.import")
def _import(_db: Session, job) -> dict:
    from foundry.catalogue import client
    data = client().support_tickets()
    imported = 0
    with session_scope() as db:
        listings = {l.external_edition_id: l for l in db.execute(select(CatalogueListing)).scalars()}
        for t in data.get("tickets", []):
            if db.execute(select(SupportIssue).where(SupportIssue.external_ref == t["id"])).first():
                continue
            listing = listings.get(t.get("edition_id"))
            if listing is None:
                continue
            product = db.get(Product, listing.product_id)
            ref = t.get("customer_id") or customer_ref(t["customer_email"])
            if not db.execute(select(CustomerContact).where(CustomerContact.customer_ref == ref)).first():
                db.add(CustomerContact(customer_ref=ref, email=t["customer_email"], name=t.get("customer_name", "")))
            steps, kinds = redact(t.get("body", ""), [t.get("customer_name", "")])
            title, k2 = redact(t.get("subject", ""), [t.get("customer_name", "")])
            rel = db.execute(select(Release).where(Release.product_id == product.id,
                                                   Release.version == t.get("version"))).scalar_one_or_none()
            db.add(SupportIssue(external_ref=t["id"], product_id=product.id, release_id=rel.id if rel else None,
                                edition_id=listing.edition_id, reported_version=t.get("version", ""),
                                kind=t.get("kind", "bug"), title=title[:300], reproduction_steps=steps,
                                severity_reported=t.get("severity", "unknown"), customer_ref=ref,
                                redactions=sorted(set(kinds + k2))))
            imported += 1
        audit.record(db, None, "support.imported", "support_issue", "batch", None, imported=imported)
    return {"imported": imported}
