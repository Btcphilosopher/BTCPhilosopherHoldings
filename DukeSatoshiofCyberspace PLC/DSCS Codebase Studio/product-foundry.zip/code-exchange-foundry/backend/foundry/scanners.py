"""Built-in scanners run by the worker against the build workspace.

Every run records tool name, tool version, database version and timestamp. An empty result
means only that *this tool, with this database, at this time* reported nothing — it is never
presented as a guarantee of security.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from foundry.licensing import parse_lockfile

DEP_TOOL, DEP_VERSION = "foundry-dependency-audit", "1.0.0"
SECRET_TOOL, SECRET_VERSION = "foundry-secret-scan", "1.0.0"
ADVISORY_DB = Path(__file__).parent / "data" / "advisories.json"
LIMITATIONS = ("Matches pinned versions against a locally curated advisory snapshot only. It does not detect "
               "unknown vulnerabilities, vulnerable code patterns, or issues in transitive dependencies that are "
               "not pinned. Absence of findings is not evidence that the software is secure.")
SECRET_LIMITATIONS = ("Pattern-based search for common credential formats in the checked-out tree. It cannot find "
                      "encoded, split or novel secret formats.")

SECRET_PATTERNS = {
    "private-key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    "aws-access-key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "github-token": re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36,}\b"),
    "generic-api-key": re.compile(r"(?i)\b(api[_-]?key|secret[_-]?key)\s*[:=]\s*['\"][A-Za-z0-9_\-]{24,}['\"]"),
}


def _version_tuple(v: str) -> tuple:
    return tuple(int(x) if x.isdigit() else 0 for x in re.split(r"[.\-+]", v)[:4])


def load_advisories() -> dict:
    return json.loads(ADVISORY_DB.read_text())


def dependency_audit(workspace: Path, lockfiles: list[str]) -> dict:
    db = load_advisories()
    findings, scope = [], []
    for lf in lockfiles:
        p = workspace / lf
        if not p.is_file() or p.is_symlink():
            continue
        scope.append(lf)
        for name, pin in parse_lockfile(p.read_text()).items():
            for adv in db["advisories"]:
                if adv["package"] != name:
                    continue
                if any(_version_tuple(lo) <= _version_tuple(pin["version"]) < _version_tuple(hi)
                       for lo, hi in adv["affected_ranges"]):
                    findings.append({"severity": adv["severity"], "identifier": adv["id"],
                                     "component": f"{name}=={pin['version']}", "title": adv["summary"],
                                     "detail": f"Fixed in {adv.get('fixed_in', 'unknown')}"})
    return {"tool": DEP_TOOL, "tool_version": DEP_VERSION, "database_version": db["database_version"],
            "scope": ", ".join(scope) or "no lockfiles", "limitations": LIMITATIONS, "findings": findings}


def secret_scan(workspace: Path, max_bytes: int = 1_000_000) -> dict:
    findings = []
    skip = {".deps", ".git", ".home", ".tmp", ".foundry"}
    for p in workspace.rglob("*"):
        if any(part in skip for part in p.relative_to(workspace).parts):
            continue
        if not p.is_file() or p.is_symlink() or p.stat().st_size > max_bytes:
            continue
        text = p.read_bytes()[:max_bytes].decode("utf-8", errors="ignore")
        for kind, rx in SECRET_PATTERNS.items():
            for m in rx.finditer(text):
                line = text.count("\n", 0, m.start()) + 1
                findings.append({"severity": "high", "identifier": kind, "component": f"{p.relative_to(workspace)}:{line}",
                                 "title": f"Possible {kind.replace('-', ' ')}", "detail": "value redacted"})
    return {"tool": SECRET_TOOL, "tool_version": SECRET_VERSION, "database_version": "patterns-2026.11",
            "scope": "source tree at commit", "limitations": SECRET_LIMITATIONS, "findings": findings}
