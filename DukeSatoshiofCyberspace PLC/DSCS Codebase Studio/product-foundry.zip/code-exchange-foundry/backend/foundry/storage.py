"""Object storage for build outputs, documentation, artwork and release packages.

Keys are content-addressed (``objects/sha256/<aa>/<digest>``) so an artefact's bytes can never
be silently replaced: writing a different payload under an existing key is an error.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

from foundry import config


class IntegrityError(Exception):
    pass


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def content_key(digest: str) -> str:
    return f"objects/sha256/{digest[:2]}/{digest}"


class LocalStorage:
    def __init__(self, root: Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        p = (self.root / key).resolve()
        if self.root not in p.parents:
            raise ValueError("key escapes storage root")
        return p

    def exists(self, key: str) -> bool:
        return self._path(key).exists()

    def put(self, key: str, data: bytes, content_type: str = "application/octet-stream") -> None:
        p = self._path(key)
        if p.exists():
            if p.read_bytes() != data:
                raise IntegrityError(f"refusing to overwrite immutable object {key}")
            return
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".tmp")
        tmp.write_bytes(data)
        tmp.replace(p)

    def put_mutable(self, key: str, data: bytes, content_type: str = "text/plain") -> None:
        """For logs that stream while a build runs (never artefacts)."""
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)

    def get(self, key: str) -> bytes:
        return self._path(key).read_bytes()


class S3Storage:
    def __init__(self):
        import boto3
        from botocore.config import Config
        s = config.settings
        self.bucket = s.s3_bucket
        self.client = boto3.client(
            "s3", endpoint_url=s.s3_endpoint, region_name=s.s3_region,
            aws_access_key_id=s.s3_access_key, aws_secret_access_key=s.s3_secret_key,
            config=Config(s3={"addressing_style": "path"}, retries={"max_attempts": 5, "mode": "standard"}))
        try:
            self.client.head_bucket(Bucket=self.bucket)
        except Exception:
            self.client.create_bucket(Bucket=self.bucket)

    def exists(self, key: str) -> bool:
        from botocore.exceptions import ClientError
        try:
            self.client.head_object(Bucket=self.bucket, Key=key)
            return True
        except ClientError:
            return False

    def put(self, key: str, data: bytes, content_type: str = "application/octet-stream") -> None:
        if self.exists(key):
            if sha256_bytes(self.get(key)) != sha256_bytes(data):
                raise IntegrityError(f"refusing to overwrite immutable object {key}")
            return
        self.client.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type,
                               Metadata={"sha256": sha256_bytes(data)})

    def put_mutable(self, key: str, data: bytes, content_type: str = "text/plain") -> None:
        self.client.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type)

    def get(self, key: str) -> bytes:
        return self.client.get_object(Bucket=self.bucket, Key=key)["Body"].read()


_storage = None


def get_storage():
    global _storage
    if _storage is None:
        if config.settings.storage_backend == "s3":
            _storage = S3Storage()
        else:
            _storage = LocalStorage(config.settings.storage_root)
    return _storage


def reset_storage() -> None:
    global _storage
    _storage = None


def store_blob(data: bytes, content_type: str = "application/octet-stream") -> tuple[str, str]:
    digest = sha256_bytes(data)
    key = content_key(digest)
    get_storage().put(key, data, content_type)
    return key, digest


def read_verified(key: str, expected_sha256: str) -> bytes:
    data = get_storage().get(key)
    actual = sha256_bytes(data)
    if actual != expected_sha256:
        raise IntegrityError(f"checksum mismatch for {key}: expected {expected_sha256}, got {actual}")
    return data
