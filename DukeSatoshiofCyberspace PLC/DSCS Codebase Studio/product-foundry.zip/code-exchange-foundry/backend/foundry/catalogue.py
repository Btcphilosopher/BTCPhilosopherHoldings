"""Catalogue adapter: Product Foundry -> The Code Exchange storefront (versioned API, /v1).

Publication is a durable job made of idempotent steps (product, edition, package, release, pointer).
Each step records the storefront's external identifier as soon as it succeeds, and every request uses
upsert-by-external-reference or an Idempotency-Key, so a retry after a partial failure continues
where it stopped without duplicating products, editions, releases or entitlements.
"""
from __future__ import annotations

import hashlib
import json

import httpx
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from foundry import audit, config, jobs, releases
from foundry.db import session_scope, utcnow
from foundry.models import (Advisory, Approval, Artifact, Artwork, CatalogueListing, Document, Edition,
                            Entitlement, LicenceVersion, PlatformVerification, Product, PublicationJob, Release,
                            ReleaseEdition, User)
from foundry.storage import read_verified

API_VERSION = "v1"
STEPS = ("product", "edition", "package", "release", "pointer")


class StorefrontError(Exception):
    pass


class StorefrontClient:
    def __init__(self, base_url: str | None = None, token: str | None = None, transport=None):
        self.client = httpx.Client(base_url=(base_url or config.settings.storefront_url).rstrip("/") + f"/{API_VERSION}",
                                   headers={"Authorization": f"Bearer {token or config.settings.storefront_token}",
                                            "User-Agent": "product-foundry/1.0"},
                                   timeout=30, transport=transport)

    def _call(self, method: str, path: str, *, idem: str | None = None, **kw):
        headers = kw.pop("headers", {})
        if idem:
            headers["Idempotency-Key"] = idem
        try:
            r = self.client.request(method, path, headers=headers, **kw)
        except httpx.HTTPError as exc:
            raise StorefrontError(f"{method} {path}: {exc}") from exc
        if r.status_code >= 400:
            raise StorefrontError(f"{method} {path}: HTTP {r.status_code} {r.text[:300]}")
        return r.json() if r.content else {}

    def upsert_product(self, ref: str, body: dict, idem: str):
        return self._call("PUT", f"/products/{ref}", json=body, idem=idem)

    def upsert_edition(self, product_id: str, ref: str, body: dict, idem: str):
        return self._call("PUT", f"/products/{product_id}/editions/{ref}", json=body, idem=idem)

    def upload_package(self, edition_id: str, version: str, data: bytes, sha: str, idem: str):
        return self._call("PUT", f"/editions/{edition_id}/releases/{version}/package", content=data, idem=idem,
                          headers={"Content-Type": "application/zip", "X-Content-SHA256": sha})

    def put_release(self, edition_id: str, version: str, body: dict, idem: str):
        return self._call("PUT", f"/editions/{edition_id}/releases/{version}", json=body, idem=idem)

    def set_pointer(self, edition_id: str, version: str, idem: str, reason: str = "publish"):
        return self._call("PUT", f"/editions/{edition_id}/pointer", json={"version": version, "reason": reason}, idem=idem)

    def withdraw_release(self, edition_id: str, version: str, reason: str, idem: str):
        return self._call("POST", f"/editions/{edition_id}/releases/{version}/withdraw", json={"reason": reason}, idem=idem)

    def post_advisory(self, body: dict, idem: str):
        return self._call("POST", "/advisories", json=body, idem=idem)

    def entitlements(self):
        return self._call("GET", "/entitlements")

    def support_tickets(self):
        return self._call("GET", "/support/tickets")


def client() -> StorefrontClient:
    return StorefrontClient()


# ------------------------------------------------------------------ payloads
def _sha(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def build_payload(db: Session, listing: CatalogueListing, rel: Release) -> dict:
    product = db.get(Product, listing.product_id)
    e = db.get(Edition, listing.edition_id)
    lic = db.get(LicenceVersion, e.licence_version_id) if e.licence_version_id else None
    re_ = db.execute(select(ReleaseEdition).where(ReleaseEdition.release_id == rel.id,
                                                  ReleaseEdition.edition_id == e.id)).scalar_one_or_none()
    if re_ is None or not re_.manifest:
        raise HTTPException(409, f"release {rel.version} has no frozen manifest for edition {e.code}")
    verified = sorted(v.platform for v in db.execute(select(PlatformVerification).where(
        PlatformVerification.release_id == rel.id, PlatformVerification.result == "passed")).scalars())
    artwork = db.execute(select(Artwork).where(Artwork.edition_id == e.id, Artwork.release_id == rel.id,
                                               Artwork.purpose == "mockup", Artwork.status == "valid")
                         .order_by(Artwork.id.desc())).scalars().first()
    print_art = db.execute(select(Artwork).where(Artwork.edition_id == e.id, Artwork.release_id == rel.id,
                                                 Artwork.purpose == "print", Artwork.status == "valid")).scalars().first()
    shots = [db.get(Artifact, aid) for aid in product.screenshots or []]
    docs = [d for d in db.execute(select(Document).where(Document.release_id == rel.id, Document.status == "approved",
                                                         Document.locked.is_(True))).scalars()]
    return {
        "api_version": API_VERSION,
        "product": {"ref": f"foundry-product-{product.id}", "slug": product.slug, "title": product.name,
                    "tagline": product.tagline, "description": product.description, "category": product.category,
                    "screenshots": [{"filename": a.filename, "sha256": a.sha256} for a in shots if a]},
        "edition": {"ref": f"foundry-edition-{e.id}", "code": e.code, "name": e.name, "kind": e.kind, "sku": e.sku,
                    "gtin": e.gtin, "price": e.price, "delivery_method": e.delivery_method,
                    "update_policy": e.update_policy, "support_terms": e.support_terms, "support_days": e.support_days,
                    "box_artwork": ({"filename": db.get(Artifact, artwork.artifact_id).filename,
                                     "sha256": db.get(Artifact, artwork.artifact_id).sha256, "purpose": "mockup"}
                                    if artwork else None),
                    "print_ready": print_art is not None,
                    "licence": ({"code": lic.code, "version": lic.version, "title": lic.title, "summary": lic.summary,
                                 "rights": lic.rights, "text_sha256": lic.text_sha256} if lic else None)},
        "release": {"version": rel.version, "commit": rel.commit_sha, "release_manifest_sha256": rel.manifest_sha256,
                    "edition_manifest_sha256": re_.manifest_sha256, "package": re_.manifest["package"],
                    "included_files": [{"path": f["path"], "sha256": f["sha256"], "size": f["size"]}
                                       for f in re_.manifest["includes"]],
                    "requirements": {"python": (rel.compatibility or {}).get("minimum_python", "3.10"),
                                     "verified_platforms": verified},
                    "notes": rel.notes, "compatibility": rel.compatibility,
                    "end_of_support": rel.end_of_support_on.isoformat() if rel.end_of_support_on else None,
                    "documentation": sorted([{"kind": d.kind, "revision": d.revision} for d in docs],
                                            key=lambda x: x["kind"])},
    }


def _flatten(obj, prefix=""):
    out = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            out.update(_flatten(v, f"{prefix}.{k}" if prefix else k))
    elif isinstance(obj, list) and obj and all(isinstance(x, dict) for x in obj):
        for i, v in enumerate(obj):
            out.update(_flatten(v, f"{prefix}[{i}]"))
    else:
        out[prefix] = obj
    return out


def field_diff(old: dict, new: dict) -> list[dict]:
    a, b = _flatten(old or {}), _flatten(new or {})
    changes = []
    for k in sorted(set(a) | set(b)):
        if a.get(k) != b.get(k):
            changes.append({"field": k, "before": a.get(k), "after": b.get(k),
                            "change": "added" if k not in a else ("removed" if k not in b else "changed")})
    return changes


def ensure_listing(db: Session, edition: Edition) -> CatalogueListing:
    lst = db.execute(select(CatalogueListing).where(CatalogueListing.edition_id == edition.id)).scalar_one_or_none()
    if lst is None:
        lst = CatalogueListing(product_id=edition.product_id, edition_id=edition.id,
                               channel="retail" if edition.kind in ("boxed-key", "usb-collector") else "online",
                               pointer_history=[])
        db.add(lst)
        db.flush()
    return lst


def prepare(db: Session, listing: CatalogueListing, rel: Release, user: User) -> dict:
    if rel.status not in ("approved", "published"):
        raise HTTPException(409, f"release {rel.version} is {rel.status}; only approved releases can be listed")
    payload = build_payload(db, listing, rel)
    sha = _sha(payload)
    if sha != listing.draft_payload_sha256:
        listing.draft_payload, listing.draft_payload_sha256 = payload, sha
        listing.draft_release_id = rel.id
        listing.status = "pending-approval"
        listing.approved_payload_sha256 = None  # any change needs fresh listing approval
        listing.updated_at = utcnow()
        audit.record(db, user, "listing.prepared", "listing", listing.id, rel.project_id, release=rel.version,
                     payload_sha256=sha)
    return preview(db, listing)


def preview(db: Session, listing: CatalogueListing) -> dict:
    return {"listing_id": listing.id, "status": listing.status, "payload": listing.draft_payload,
            "payload_sha256": listing.draft_payload_sha256,
            "changes": field_diff(listing.published_payload, listing.draft_payload),
            "current_release_id": listing.current_release_id, "draft_release_id": listing.draft_release_id}


def approve_listing(db: Session, listing: CatalogueListing, user: User, comment: str = "") -> None:
    if listing.status != "pending-approval":
        raise HTTPException(409, f"listing is {listing.status}")
    rel = db.get(Release, listing.draft_release_id)
    if config.settings.require_separate_approver and rel.approved_by == user.id:
        raise HTTPException(403, "separation of duties: the release approver cannot also approve its public listing")
    listing.status = "approved"
    listing.approved_payload_sha256 = listing.draft_payload_sha256
    listing.approved_by = user.id
    db.add(Approval(listing_id=listing.id, release_id=rel.id, kind="public-listing", user_id=user.id,
                    decision="approved", comment=comment, readiness_sha256=listing.draft_payload_sha256))
    audit.record(db, user, "listing.approved", "listing", listing.id, rel.project_id,
                 payload_sha256=listing.draft_payload_sha256)


def request_publish(db: Session, listing: CatalogueListing, user: User) -> PublicationJob:
    if listing.status not in ("approved", "failed", "publishing"):
        raise HTTPException(409, f"listing is {listing.status}; it needs listing approval first")
    if listing.approved_payload_sha256 != listing.draft_payload_sha256:
        raise HTTPException(409, "the listing changed after approval")
    rel = db.get(Release, listing.draft_release_id)
    if rel.status not in ("approved", "published"):
        raise HTTPException(409, f"release is {rel.status}")
    key = f"publish:{listing.id}:{rel.id}:{listing.approved_payload_sha256[:16]}"
    pj = db.execute(select(PublicationJob).where(PublicationJob.idempotency_key == key)).scalar_one_or_none()
    if pj and pj.status in ("queued", "running", "succeeded", "failed"):
        return pj  # idempotent: repeated requests do not create a second publication
    if pj and pj.status == "dead":
        pj.status, pj.last_error = "queued", None  # explicit operator retry keeps recorded step progress
        job = jobs.enqueue(db, "catalogue.publish", {"publication_id": pj.id}, max_attempts=5)
        pj.job_id = job.id
    else:
        pj = PublicationJob(listing_id=listing.id, release_id=rel.id, action="publish", idempotency_key=key,
                            payload_sha256=listing.approved_payload_sha256, steps={}, requested_by=user.id)
        db.add(pj)
        db.flush()
        job = jobs.enqueue(db, "catalogue.publish", {"publication_id": pj.id}, idempotency_key=key, max_attempts=5)
        pj.job_id = job.id
    listing.status = "publishing"
    audit.record(db, user, "listing.publish_requested", "publication", pj.id, rel.project_id, release=rel.version)
    return pj


def _step_done(pub_id: int, step: str, **info) -> None:
    with session_scope() as db:
        pj = db.get(PublicationJob, pub_id)
        steps = dict(pj.steps or {})
        steps[step] = {"status": "done", "at": utcnow().isoformat(), **info}
        pj.steps = steps


@jobs.handler("catalogue.publish")
def _publish(_db: Session, job) -> dict:
    pub_id = job.payload["publication_id"]
    with session_scope() as db:
        pj = db.get(PublicationJob, pub_id)
        pj.status, pj.attempts = "running", pj.attempts + 1
        listing = db.get(CatalogueListing, pj.listing_id)
        rel = db.get(Release, pj.release_id)
        payload = listing.draft_payload
        changed = listing.approved_payload_sha256 != pj.payload_sha256 or _sha(payload) != pj.payload_sha256
        re_ = db.execute(select(ReleaseEdition).where(ReleaseEdition.release_id == rel.id,
                                                      ReleaseEdition.edition_id == listing.edition_id)).scalar_one()
        pkg = db.get(Artifact, re_.package_artifact_id)
        pkg_key, pkg_sha, version, steps = pkg.storage_key, pkg.sha256, rel.version, dict(pj.steps or {})
        idem_base = pj.idempotency_key
    if changed:
        with session_scope() as db:
            pj = db.get(PublicationJob, pub_id)
            pj.status, pj.last_error, pj.finished_at = "dead", "listing payload changed since approval", utcnow()
            db.get(CatalogueListing, pj.listing_id).status = "pending-approval"
            audit.record(db, None, "listing.publish_refused", "publication", pj.id, None, reason="payload changed")
        raise jobs.PermanentFailure("listing payload changed since approval; publication refused")
    sf = client()
    try:
        done = lambda s: steps.get(s, {}).get("status") == "done"  # noqa: E731
        if not done("product"):
            r = sf.upsert_product(payload["product"]["ref"], payload["product"], f"{idem_base}:product")
            steps["product"] = {"status": "done", "external_id": r["id"]}
            _step_done(pub_id, "product", external_id=r["id"])
        product_id = steps["product"]["external_id"]
        if not done("edition"):
            r = sf.upsert_edition(product_id, payload["edition"]["ref"], payload["edition"], f"{idem_base}:edition")
            steps["edition"] = {"status": "done", "external_id": r["id"]}
            _step_done(pub_id, "edition", external_id=r["id"])
        edition_id = steps["edition"]["external_id"]
        if not done("package"):
            # the approved bytes, verified against the frozen checksum - never rebuilt
            data = read_verified(pkg_key, pkg_sha)
            r = sf.upload_package(edition_id, version, data, pkg_sha, f"{idem_base}:package")
            if r.get("sha256") != pkg_sha:
                raise jobs.PermanentFailure("storefront stored a different checksum than the approved package")
            steps["package"] = {"status": "done", "sha256": pkg_sha}
            _step_done(pub_id, "package", sha256=pkg_sha)
        if not done("release"):
            r = sf.put_release(edition_id, version, payload["release"], f"{idem_base}:release")
            steps["release"] = {"status": "done", "external_id": r["id"]}
            _step_done(pub_id, "release", external_id=r["id"])
        if not done("pointer"):
            r = sf.set_pointer(edition_id, version, f"{idem_base}:pointer")
            _step_done(pub_id, "pointer", current=r.get("current"))
    except StorefrontError as exc:
        with session_scope() as db:
            pj = db.get(PublicationJob, pub_id)
            pj.last_error = str(exc)
            pj.status = "failed" if job.attempts < job.max_attempts else "dead"
            listing = db.get(CatalogueListing, pj.listing_id)
            listing.status = "failed" if pj.status == "dead" else "publishing"
            audit.record(db, None, "listing.publish_attempt_failed", "publication", pj.id, None,
                         attempt=job.attempts, error=str(exc)[:300])
        raise
    with session_scope() as db:
        pj = db.get(PublicationJob, pub_id)
        pj.status, pj.finished_at, pj.last_error = "succeeded", utcnow(), None
        listing = db.get(CatalogueListing, pj.listing_id)
        rel = db.get(Release, pj.release_id)
        listing.external_product_id, listing.external_edition_id = product_id, edition_id
        if listing.current_release_id != rel.id:
            listing.pointer_history = list(listing.pointer_history or []) + [
                {"release_id": rel.id, "version": rel.version, "at": utcnow().isoformat(), "reason": "publish"}]
        listing.current_release_id = rel.id
        listing.published_payload = listing.draft_payload
        listing.status = "published"
        releases.mark_published(db, rel)
        audit.record(db, None, "listing.published", "listing", listing.id, rel.project_id, release=rel.version,
                     attempts=pj.attempts, payload_sha256=pj.payload_sha256)
    return {"published": version}


# ------------------------------------------------------------------ rollback & withdrawal
ROLLBACK_NOTICE = ("Reverting the catalogue listing changes which version new customers download. It does not "
                   "uninstall, downgrade or recall copies that customers have already downloaded or installed.")


def rollback(db: Session, listing: CatalogueListing, user: User, reason: str,
             target_release_id: int | None = None) -> PublicationJob:
    """Move the catalogue pointer to another release this listing has published (default: the previous one)."""
    if listing.status != "published":
        raise HTTPException(409, "listing is not published")
    history = [h for h in listing.pointer_history or [] if h["release_id"] != listing.current_release_id]
    target = None
    for h in reversed(history):
        r = db.get(Release, h["release_id"])
        if r.status in ("published", "superseded") and (target_release_id in (None, r.id)):
            target = r
            break
    if target is None:
        raise HTTPException(409, "no other published release of this listing to point to")
    key = f"rollback:{listing.id}:{listing.current_release_id}->{target.id}:{len(listing.pointer_history)}"
    pj = PublicationJob(listing_id=listing.id, release_id=target.id, action="rollback", idempotency_key=key,
                        payload_sha256=listing.approved_payload_sha256 or "", steps={"reason": {"text": reason}},
                        requested_by=user.id)
    db.add(pj)
    db.flush()
    pj.job_id = jobs.enqueue(db, "catalogue.pointer", {"publication_id": pj.id}, idempotency_key=key,
                             max_attempts=5).id
    audit.record(db, user, "listing.rollback_requested", "listing", listing.id, target.project_id,
                 to=target.version, reason=reason)
    return pj


@jobs.handler("catalogue.pointer")
def _pointer(_db: Session, job) -> dict:
    with session_scope() as db:
        pj = db.get(PublicationJob, job.payload["publication_id"])
        pj.attempts += 1
        listing = db.get(CatalogueListing, pj.listing_id)
        rel = db.get(Release, pj.release_id)
        reason = (pj.steps or {}).get("reason", {}).get("text", "rollback")
        eid, version, key = listing.external_edition_id, rel.version, pj.idempotency_key
    sf = client()
    sf.set_pointer(eid, version, f"{key}:pointer", reason=reason)
    sf.post_advisory({"edition_id": eid, "kind": "rollback", "title": f"Catalogue reverted to version {version}",
                      "body": f"{reason}\n\n{ROLLBACK_NOTICE}"}, f"{key}:advisory")
    with session_scope() as db:
        pj = db.get(PublicationJob, job.payload["publication_id"])
        listing = db.get(CatalogueListing, pj.listing_id)
        rel = db.get(Release, pj.release_id)
        listing.current_release_id = rel.id
        listing.pointer_history = list(listing.pointer_history or []) + [
            {"release_id": rel.id, "version": rel.version, "at": utcnow().isoformat(), "reason": f"rollback: {reason}"}]
        pj.status, pj.finished_at = "succeeded", utcnow()
        db.add(Advisory(product_id=listing.product_id, release_id=rel.id, kind="rollback",
                        title=f"Catalogue reverted to version {rel.version}", body=f"{reason}\n\n{ROLLBACK_NOTICE}",
                        published=True))
        audit.record(db, None, "listing.rolled_back", "listing", listing.id, rel.project_id, to=rel.version)
    return {"pointer": version}


def request_withdrawal_sync(db: Session, rel: Release, advisory: Advisory, user: User) -> list[int]:
    ids = []
    for listing in db.execute(select(CatalogueListing).where(CatalogueListing.product_id == rel.product_id,
                                                             CatalogueListing.external_edition_id.isnot(None))).scalars():
        job = jobs.enqueue(db, "catalogue.withdraw", {"listing_id": listing.id, "release_id": rel.id,
                                                      "advisory_id": advisory.id},
                           idempotency_key=f"withdraw:{listing.id}:{rel.id}", max_attempts=5)
        ids.append(job.id)
    return ids


@jobs.handler("catalogue.withdraw")
def _withdraw(_db: Session, job) -> dict:
    with session_scope() as db:
        listing = db.get(CatalogueListing, job.payload["listing_id"])
        rel = db.get(Release, job.payload["release_id"])
        adv = db.get(Advisory, job.payload["advisory_id"])
        eid, version, reason, title, body = listing.external_edition_id, rel.version, rel.withdrawn_reason, adv.title, adv.body
        fallback = None
        if listing.current_release_id == rel.id:
            for h in reversed(listing.pointer_history or []):
                r = db.get(Release, h["release_id"])
                if r.id != rel.id and r.status in ("published", "superseded"):
                    fallback = r
                    break
        fb_version = fallback.version if fallback else None
    sf = client()
    key = f"withdraw:{job.payload['listing_id']}:{job.payload['release_id']}"
    sf.withdraw_release(eid, version, reason or "", f"{key}:withdraw")
    if fb_version:
        sf.set_pointer(eid, fb_version, f"{key}:pointer", reason=f"withdrawal of {version}")
    r = sf.post_advisory({"edition_id": eid, "kind": "withdrawal", "title": title, "body": body,
                          "release": version, "notify_entitled_customers": True}, f"{key}:advisory")
    with session_scope() as db:
        listing = db.get(CatalogueListing, job.payload["listing_id"])
        adv = db.get(Advisory, job.payload["advisory_id"])
        adv.published, adv.external_id = True, r.get("id")
        if fb_version:
            listing.current_release_id = fallback.id
            listing.pointer_history = list(listing.pointer_history or []) + [
                {"release_id": fallback.id, "version": fb_version, "at": utcnow().isoformat(),
                 "reason": f"withdrawal of {version}"}]
        elif listing.current_release_id == job.payload["release_id"]:
            listing.status = "unlisted"
        audit.record(db, None, "listing.withdrawal_synced", "listing", listing.id, None, release=version,
                     notified=r.get("notified", 0))
    return {"withdrawn": version, "fallback": fb_version}


# ------------------------------------------------------------------ entitlement import
@jobs.handler("entitlements.sync")
def _sync_entitlements(_db: Session, job) -> dict:
    data = client().entitlements()
    created = 0
    with session_scope() as db:
        by_ext = {l.external_edition_id: l for l in db.execute(select(CatalogueListing)).scalars() if l.external_edition_id}
        for ent in data.get("entitlements", []):
            if db.execute(select(Entitlement).where(Entitlement.external_id == ent["id"])).first():
                continue
            listing = by_ext.get(ent["edition_id"])
            if listing is None:
                continue
            edition = db.get(Edition, listing.edition_id)
            rel = db.execute(select(Release).where(Release.product_id == edition.product_id,
                                                   Release.version == ent.get("purchased_version"))).scalar_one_or_none()
            from datetime import datetime, timedelta
            purchased = datetime.fromisoformat(ent["purchased_at"])
            db.add(Entitlement(external_id=ent["id"], customer_ref=ent["customer_ref"], edition_id=edition.id,
                               licence_version_id=edition.licence_version_id,
                               purchased_release_id=rel.id if rel else None, order_ref=ent["order_ref"],
                               purchased_at=purchased, update_policy=ent.get("update_policy") or edition.update_policy,
                               support_until=(purchased + timedelta(days=edition.support_days)).date(),
                               status=ent.get("status", "active")))
            created += 1
        audit.record(db, None, "entitlements.synced", "entitlement", "batch", None, created=created)
    return {"created": created}
