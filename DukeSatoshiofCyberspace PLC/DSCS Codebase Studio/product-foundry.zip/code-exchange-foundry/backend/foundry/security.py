"""Authentication, roles and backend-enforced permissions."""
from __future__ import annotations

from datetime import timedelta

import bcrypt
import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from foundry import config
from foundry.db import get_db, utcnow
from foundry.models import User

ROLES = {
    "product_manager": "Product manager",
    "developer": "Developer",
    "reviewer": "Reviewer",
    "quality_engineer": "Quality engineer",
    "documentation_editor": "Documentation editor",
    "licence_reviewer": "Licence reviewer",
    "release_manager": "Release manager",
    "catalogue_editor": "Catalogue editor",
    "support_agent": "Support agent",
    "administrator": "Administrator",
    "assistant": "AI assistant (service identity)",
}

# Administrators manage people and configuration; they are deliberately NOT a superuser
# for approvals, licence decisions or publication.
PERMISSIONS: dict[str, set[str]] = {
    "project.create": {"product_manager", "administrator"},
    "project.edit": {"product_manager"},
    "requirement.edit": {"product_manager", "quality_engineer"},
    "requirement.accept": {"product_manager", "reviewer"},
    "evidence.record": {"quality_engineer", "reviewer"},
    "task.edit": {"product_manager", "developer"},
    "cost.edit": {"product_manager"},
    "repo.connect": {"developer", "administrator"},
    "build.run": {"developer", "quality_engineer", "release_manager"},
    "build.cancel": {"developer", "quality_engineer", "release_manager"},
    "quality.review": {"quality_engineer", "reviewer"},
    "exception.create": {"release_manager"},
    "docs.edit": {"documentation_editor", "developer"},
    "docs.approve": {"documentation_editor"},
    "docs.template": {"documentation_editor"},
    "licence.edit": {"licence_reviewer"},
    "licence.approve": {"licence_reviewer"},
    "licence.review": {"licence_reviewer"},
    "provenance.edit": {"licence_reviewer", "developer", "product_manager"},
    "product.edit": {"product_manager", "catalogue_editor"},
    "edition.edit": {"product_manager"},
    "packaging.edit": {"product_manager", "catalogue_editor"},
    "release.create": {"release_manager", "developer"},
    "release.transition": {"release_manager"},
    "release.approve": {"release_manager"},
    "release.withdraw": {"release_manager"},
    "catalogue.edit": {"catalogue_editor"},
    "catalogue.approve": {"catalogue_editor"},
    "catalogue.publish": {"catalogue_editor", "release_manager"},
    "catalogue.rollback": {"catalogue_editor", "release_manager"},
    "support.triage": {"support_agent", "quality_engineer", "product_manager", "developer"},
    "support.import": {"support_agent"},
    "support.private": {"support_agent"},
    "advisory.publish": {"release_manager", "support_agent"},
    "admin.users": {"administrator"},
    "admin.settings": {"administrator"},
    "audit.read": {"administrator", "release_manager"},
    "jobs.manage": {"administrator", "release_manager"},
    "assistant.use": {"developer", "documentation_editor", "quality_engineer"},
}

bearer = HTTPBearer(auto_error=False)


def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt(rounds=10)).decode()


def verify_password(pw: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(pw.encode(), hashed.encode())
    except ValueError:
        return False


def issue_token(user: User) -> str:
    now = utcnow()
    payload = {"sub": str(user.id), "iat": int(now.timestamp()),
               "exp": int((now + timedelta(minutes=config.settings.token_ttl_minutes)).timestamp())}
    return jwt.encode(payload, config.settings.secret_key, algorithm="HS256")


def has_permission(user: User, permission: str) -> bool:
    allowed = PERMISSIONS.get(permission)
    if allowed is None:
        raise KeyError(f"unknown permission {permission}")
    return bool(set(user.roles or []) & allowed)


def current_user(creds: HTTPAuthorizationCredentials | None = Depends(bearer), db: Session = Depends(get_db)) -> User:
    if creds is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "authentication required")
    try:
        data = jwt.decode(creds.credentials, config.settings.secret_key, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid or expired token")
    user = db.get(User, int(data["sub"]))
    if user is None or not user.active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "user inactive")
    return user


def require(permission: str):
    def dep(user: User = Depends(current_user)) -> User:
        if not has_permission(user, permission):
            raise HTTPException(status.HTTP_403_FORBIDDEN, f"permission '{permission}' required "
                                f"(one of: {', '.join(sorted(PERMISSIONS[permission]))})")
        return user
    return dep


def check(user: User, permission: str) -> None:
    if not has_permission(user, permission):
        raise HTTPException(status.HTTP_403_FORBIDDEN, f"permission '{permission}' required")
