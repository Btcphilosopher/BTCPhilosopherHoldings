"""Releases, quality evidence, documentation, licensing and packaging."""
from __future__ import annotations

import hashlib
from datetime import date

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import HTMLResponse, Response
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from foundry import audit, catalogue, docs, packaging, releases
from foundry.api.common import get_or_404, to_dict
from foundry.db import get_db, utcnow
from foundry.models import (Approval, Artifact, Artwork, Build, Contributor, DocTemplate, Document, Edition,
                            LicenceReview, LicenceVersion, PackagingTemplate, PlatformVerification, Product,
                            ProvenanceAsset, ReadinessException, Release, ReleaseArtifact, ReleaseEdition,
                            ReviewRecord, SbomComponent, User)
from foundry.security import current_user, require
from foundry.storage import get_storage, read_verified

router = APIRouter(tags=["releases"])


def _rel(db: Session, r: Release, full: bool = False) -> dict:
    d = to_dict(r, exclude=set() if full else {"manifest", "readiness_snapshot", "history"})
    d["product"] = db.get(Product, r.product_id).name
    b = db.get(Build, r.build_id) if r.build_id else None
    d["build_number"] = b.number if b else None
    if full:
        d["artifacts"] = [to_dict(db.get(Artifact, ra.artifact_id), release_role=ra.role) for ra in
                          db.execute(select(ReleaseArtifact).where(ReleaseArtifact.release_id == r.id)).scalars()]
        d["editions"] = packaging.manifests_for_release(db, r)
        d["approvals"] = [to_dict(a, user=db.get(User, a.user_id).name) for a in
                          db.execute(select(Approval).where(Approval.release_id == r.id)).scalars()]
        d["platform_verifications"] = [to_dict(v) for v in db.execute(select(PlatformVerification).where(
            PlatformVerification.release_id == r.id)).scalars()]
        d["reviews"] = [to_dict(v) for v in db.execute(select(ReviewRecord).where(ReviewRecord.release_id == r.id)).scalars()]
        d["exceptions"] = [to_dict(x, owner=db.get(User, x.owner_id).name) for x in db.execute(
            select(ReadinessException).where(ReadinessException.release_id == r.id)).scalars()]
        d["created_by_name"] = db.get(User, r.created_by).name if r.created_by else None
        d["approved_by_name"] = db.get(User, r.approved_by).name if r.approved_by else None
    return d


@router.get("/releases")
def all_releases(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [_rel(db, r) for r in db.execute(select(Release).order_by(Release.id.desc())).scalars()]


@router.get("/projects/{pid}/releases")
def project_releases(pid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [_rel(db, r) for r in db.execute(select(Release).where(Release.project_id == pid)
                                            .order_by(Release.id.desc())).scalars()]


class ReleaseIn(BaseModel):
    version: str
    build_id: int
    notes: str = ""


@router.post("/products/{prid}/releases")
def create_release(prid: int, body: ReleaseIn, db: Session = Depends(get_db), user: User = Depends(require("release.create"))):
    pr = get_or_404(db, Product, prid)
    if db.execute(select(Release).where(Release.product_id == prid, Release.version == body.version)).first():
        raise HTTPException(409, f"version {body.version} already exists; corrections need a new version")
    r = releases.create_release(db, pr, body.version, get_or_404(db, Build, body.build_id), user, body.notes)
    db.commit()
    return _rel(db, r, True)


@router.get("/releases/{rid}")
def get_release(rid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return _rel(db, get_or_404(db, Release, rid), True)


class ReleasePatch(BaseModel):
    notes: str | None = None
    platform_claims: list[str] | None = None
    compatibility: dict | None = None
    end_of_support_on: date | None = None
    edition_ids: list[int] | None = None


@router.patch("/releases/{rid}")
def patch_release(rid: int, body: ReleasePatch, db: Session = Depends(get_db), user: User = Depends(require("release.create"))):
    r = get_or_404(db, Release, rid)
    releases.update_draft(db, r, user, **body.model_dump())
    db.commit()
    return _rel(db, r, True)


class EosIn(BaseModel):
    end_of_support_on: date


@router.post("/releases/{rid}/end-of-support")
def set_end_of_support(rid: int, body: EosIn, db: Session = Depends(get_db), user: User = Depends(require("release.transition"))):
    """Support dates remain editable after publication; contents do not."""
    r = get_or_404(db, Release, rid)
    r.end_of_support_on = body.end_of_support_on
    audit.record(db, user, "release.end_of_support", "release", r.id, r.project_id, date=body.end_of_support_on)
    db.commit()
    return _rel(db, r)


@router.post("/releases/{rid}/candidate")
def to_candidate(rid: int, db: Session = Depends(get_db), user: User = Depends(require("release.transition"))):
    r = get_or_404(db, Release, rid)
    releases.freeze_candidate(db, r, user)
    db.commit()
    return _rel(db, r, True)


@router.post("/releases/{rid}/validation")
def to_validation(rid: int, db: Session = Depends(get_db), user: User = Depends(require("release.transition"))):
    r = get_or_404(db, Release, rid)
    releases.start_validation(db, r, user)
    db.commit()
    return _rel(db, r, True)


class ReasonIn(BaseModel):
    reason: str = Field(min_length=3)


@router.post("/releases/{rid}/return-to-draft")
def to_draft(rid: int, body: ReasonIn, db: Session = Depends(get_db), user: User = Depends(require("release.transition"))):
    r = get_or_404(db, Release, rid)
    releases.return_to_draft(db, r, user, body.reason)
    db.commit()
    return _rel(db, r, True)


class CommentIn(BaseModel):
    comment: str = ""


@router.post("/releases/{rid}/approve")
def approve(rid: int, body: CommentIn, db: Session = Depends(get_db), user: User = Depends(require("release.approve"))):
    r = get_or_404(db, Release, rid)
    releases.approve(db, r, user, body.comment)
    db.commit()
    return _rel(db, r, True)


@router.post("/releases/{rid}/withdraw")
def withdraw(rid: int, body: ReasonIn, db: Session = Depends(get_db), user: User = Depends(require("release.withdraw"))):
    r = get_or_404(db, Release, rid)
    adv = releases.withdraw(db, r, user, body.reason)
    jobs = catalogue.request_withdrawal_sync(db, r, adv, user)
    db.commit()
    return _rel(db, r, True) | {"advisory": to_dict(adv), "sync_jobs": jobs}


@router.get("/releases/{rid}/readiness")
def readiness(rid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    r = get_or_404(db, Release, rid)
    if r.status in releases.FROZEN and r.readiness_snapshot:
        return r.readiness_snapshot | {"frozen": True}
    return releases.evaluate(db, r)


@router.get("/releases/{rid}/integrity")
def integrity(rid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    r = get_or_404(db, Release, rid)
    return {"manifest_sha256": r.manifest_sha256,
            "manifest_matches": bool(r.manifest) and releases.canonical_sha(r.manifest) == r.manifest_sha256,
            "artifacts": releases.verify_integrity(db, r)}


class VerificationIn(BaseModel):
    platform: str
    result: str = Field(pattern="^(passed|failed)$")
    evidence: str = Field(min_length=10)


@router.post("/releases/{rid}/platform-verifications")
def add_verification(rid: int, body: VerificationIn, db: Session = Depends(get_db),
                     user: User = Depends(require("quality.review"))):
    r = get_or_404(db, Release, rid)
    if r.status in releases.FROZEN:
        raise HTTPException(409, "release is frozen")
    v = PlatformVerification(release_id=rid, method="manual", recorded_by=user.id, **body.model_dump())
    db.add(v)
    audit.record(db, user, "release.platform_verified", "release", rid, r.project_id, **body.model_dump())
    db.commit()
    return to_dict(v)


class ReviewIn(BaseModel):
    check_key: str = Field(pattern="^(accessibility|support|installation)$")
    result: str = Field(pattern="^(passed|failed)$")
    evidence: str = Field(min_length=10)


@router.post("/releases/{rid}/reviews")
def add_review(rid: int, body: ReviewIn, db: Session = Depends(get_db), user: User = Depends(require("quality.review"))):
    r = get_or_404(db, Release, rid)
    if r.status in releases.FROZEN:
        raise HTTPException(409, "release is frozen")
    rv = ReviewRecord(release_id=rid, reviewer_id=user.id, **body.model_dump())
    db.add(rv)
    audit.record(db, user, "release.review_recorded", "release", rid, r.project_id, **body.model_dump())
    db.commit()
    return to_dict(rv)


class ExceptionIn(BaseModel):
    check_key: str
    owner_id: int
    reason: str = Field(min_length=10)
    scope: str = Field(min_length=3)
    expires_on: date | None = None


@router.post("/releases/{rid}/exceptions")
def add_exception(rid: int, body: ExceptionIn, db: Session = Depends(get_db), user: User = Depends(require("exception.create"))):
    r = get_or_404(db, Release, rid)
    if r.status in releases.FROZEN:
        raise HTTPException(409, "release is frozen")
    get_or_404(db, User, body.owner_id)
    if body.expires_on and body.expires_on < date.today():
        raise HTTPException(422, "expiry is in the past")
    x = ReadinessException(release_id=rid, created_by=user.id, **body.model_dump())
    db.add(x)
    db.flush()
    audit.record(db, user, "release.exception_granted", "release", rid, r.project_id, exception=x.id, **body.model_dump())
    db.commit()
    return to_dict(x)


@router.delete("/exceptions/{xid}")
def revoke_exception(xid: int, db: Session = Depends(get_db), user: User = Depends(require("exception.create"))):
    x = get_or_404(db, ReadinessException, xid)
    x.revoked = True
    audit.record(db, user, "release.exception_revoked", "release", x.release_id, None, exception=x.id)
    db.commit()
    return to_dict(x)


# ------------------------------------------------------------------ documentation
@router.get("/doc-templates")
def templates(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(t) for t in db.execute(select(DocTemplate).order_by(DocTemplate.kind, DocTemplate.version.desc())).scalars()]


class TemplateIn(BaseModel):
    kind: str
    title: str
    body: str


@router.post("/doc-templates")
def new_template(body: TemplateIn, db: Session = Depends(get_db), user: User = Depends(require("docs.template"))):
    if body.kind not in docs.KINDS:
        raise HTTPException(422, f"kind must be one of {docs.KINDS}")
    t = docs.new_template_version(db, body.kind, body.title, body.body, user)
    db.commit()
    return to_dict(t)


class GenerateIn(BaseModel):
    kinds: list[str] | None = None


@router.post("/releases/{rid}/documents/generate")
def generate_docs(rid: int, body: GenerateIn, db: Session = Depends(get_db), user: User = Depends(require("docs.edit"))):
    r = get_or_404(db, Release, rid)
    if r.status != "draft":
        raise HTTPException(409, "documentation is prepared while the release is a draft")
    created = docs.generate_for_release(db, r, user, body.kinds)
    db.commit()
    return [to_dict(d) for d in created]


@router.get("/releases/{rid}/documents")
def release_docs(rid: int, all_revisions: bool = False, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if all_revisions:
        rows = db.execute(select(Document).where(Document.release_id == rid).order_by(Document.kind, Document.revision)).scalars()
        return [to_dict(d, exclude={"body"}) for d in rows]
    return [to_dict(d, exclude={"body"}) for d in docs.latest_for_release(db, rid, approved_only=False)]


@router.get("/documents/{did}")
def get_doc(did: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return to_dict(get_or_404(db, Document, did))


class DocBody(BaseModel):
    body: str


@router.put("/documents/{did}")
def edit_doc(did: int, body: DocBody, db: Session = Depends(get_db), user: User = Depends(require("docs.edit"))):
    d = get_or_404(db, Document, did)
    rel = db.get(Release, d.release_id)
    if rel and rel.status != "draft":
        raise HTTPException(409, "release documentation is frozen; return the release to draft to revise it")
    new = docs.edit(db, d, body.body, user)
    db.commit()
    return to_dict(new)


@router.post("/documents/{did}/submit")
def submit_doc(did: int, db: Session = Depends(get_db), user: User = Depends(require("docs.edit"))):
    d = docs.submit(db, get_or_404(db, Document, did), user)
    db.commit()
    return to_dict(d)


@router.post("/documents/{did}/approve")
def approve_doc(did: int, db: Session = Depends(get_db), user: User = Depends(require("docs.approve"))):
    d = docs.approve(db, get_or_404(db, Document, did), user)
    db.commit()
    return to_dict(d)


@router.post("/documents/{did}/check-examples")
def check_examples(did: int, db: Session = Depends(get_db), user: User = Depends(require("docs.edit"))):
    job = docs.request_example_check(db, get_or_404(db, Document, did), user)
    db.commit()
    return {"job_id": job.id}


class FlagIn(BaseModel):
    note: str = Field(min_length=5)


@router.post("/documents/{did}/flags/{index}/resolve")
def resolve_flag(did: int, index: int, body: FlagIn, db: Session = Depends(get_db), user: User = Depends(require("docs.approve"))):
    d = docs.resolve_flag(db, get_or_404(db, Document, did), index, body.note, user)
    db.commit()
    return to_dict(d)


@router.get("/documents/{did}/preview", response_class=HTMLResponse)
def preview_doc(did: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    d = get_or_404(db, Document, did)
    rel = db.get(Release, d.release_id)
    return docs.to_html(d, db.get(Product, rel.product_id).name, rel.version)


@router.get("/documents/{did}/pdf")
def pdf_doc(did: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    d = get_or_404(db, Document, did)
    rel = db.get(Release, d.release_id)
    if d.pdf_artifact_id:
        a = db.get(Artifact, d.pdf_artifact_id)
        data = read_verified(a.storage_key, a.sha256)
    else:
        data = docs.to_pdf(d, db.get(Product, rel.product_id).name, rel.version)
    return Response(data, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{d.kind}-{rel.version}.pdf"'})


# ------------------------------------------------------------------ licensing & provenance
RIGHT_KEYS = ("binary_distribution", "source_access", "permission_to_modify", "redistribution",
              "commercial_deployment", "update_entitlement", "support_entitlement", "copyright_transfer")


class LicenceIn(BaseModel):
    project_id: int | None = None
    code: str
    version: str
    title: str
    summary: str
    text: str
    rights: dict


def _validate_rights(rights: dict) -> None:
    missing = [k for k in RIGHT_KEYS if k not in rights]
    if missing:
        raise HTTPException(422, f"every right must be stated explicitly; missing {missing}")
    if rights.get("copyright_transfer") is not False:
        raise HTTPException(422, "product licences never transfer copyright ownership (copyright_transfer must be false)")
    if rights.get("source_access") and rights.get("redistribution") not in (False, "none", "modified-binaries-internal-only"):
        # source purchasers do not automatically get unlimited redistribution
        if rights.get("redistribution") in (True, "unlimited"):
            raise HTTPException(422, "source access does not imply unlimited redistribution; state a bounded right")


@router.get("/licence-versions")
def licence_versions(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(l) for l in db.execute(select(LicenceVersion).order_by(LicenceVersion.code, LicenceVersion.version)).scalars()]


@router.post("/licence-versions")
def create_licence(body: LicenceIn, db: Session = Depends(get_db), user: User = Depends(require("licence.edit"))):
    _validate_rights(body.rights)
    lv = LicenceVersion(**body.model_dump(), text_sha256=hashlib.sha256(body.text.encode()).hexdigest())
    db.add(lv)
    db.flush()
    audit.record(db, user, "licence.drafted", "licence_version", lv.id, body.project_id, code=lv.code,
                 version=lv.version, rights=lv.rights)
    db.commit()
    return to_dict(lv)


class LicencePatch(BaseModel):
    title: str | None = None
    summary: str | None = None
    text: str | None = None
    rights: dict | None = None


@router.patch("/licence-versions/{lid}")
def patch_licence(lid: int, body: LicencePatch, db: Session = Depends(get_db), user: User = Depends(require("licence.edit"))):
    lv = get_or_404(db, LicenceVersion, lid)
    if lv.status != "draft":
        raise HTTPException(409, "approved licence versions are immutable; create a new version")
    data = body.model_dump(exclude_none=True)
    if "rights" in data:
        _validate_rights(data["rights"])
    for k, v in data.items():
        setattr(lv, k, v)
    lv.text_sha256 = hashlib.sha256(lv.text.encode()).hexdigest()
    audit.record(db, user, "licence.changed", "licence_version", lv.id, lv.project_id, fields=sorted(data))
    db.commit()
    return to_dict(lv)


@router.post("/licence-versions/{lid}/approve")
def approve_licence(lid: int, db: Session = Depends(get_db), user: User = Depends(require("licence.approve"))):
    lv = get_or_404(db, LicenceVersion, lid)
    if lv.status != "draft":
        raise HTTPException(409, f"licence is {lv.status}")
    lv.status, lv.approved_by, lv.approved_at = "approved", user.id, utcnow()
    audit.record(db, user, "licence.approved", "licence_version", lv.id, lv.project_id, code=lv.code,
                 version=lv.version, text_sha256=lv.text_sha256)
    db.commit()
    return to_dict(lv)


@router.get("/projects/{pid}/contributors")
def contributors(pid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(c) for c in db.execute(select(Contributor).where(Contributor.project_id == pid)).scalars()]


class ContributorIn(BaseModel):
    name: str
    relationship: str = Field(pattern="^(employee|contractor|external)$")
    ownership: str
    agreement_ref: str = ""
    verified: bool = False


@router.post("/projects/{pid}/contributors")
def add_contributor(pid: int, body: ContributorIn, db: Session = Depends(get_db), user: User = Depends(require("provenance.edit"))):
    data = body.model_dump()
    c = Contributor(project_id=pid, relationship_=data.pop("relationship"), **data)
    db.add(c)
    db.flush()
    audit.record(db, user, "provenance.contributor", "contributor", c.id, pid, name=c.name, ownership=c.ownership)
    db.commit()
    return to_dict(c)


@router.get("/projects/{pid}/assets")
def assets(pid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(a) for a in db.execute(select(ProvenanceAsset).where(ProvenanceAsset.project_id == pid)).scalars()]


@router.get("/projects/{pid}/licence-reviews")
def licence_reviews(pid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(r) for r in db.execute(select(LicenceReview).where(LicenceReview.project_id == pid)
                                           .order_by(LicenceReview.id)).scalars()]


class DecisionIn(BaseModel):
    status: str = Field(pattern="^(cleared|rejected|remediated)$")
    decision: str = Field(min_length=10)


@router.post("/licence-reviews/{rid}/decide")
def decide(rid: int, body: DecisionIn, db: Session = Depends(get_db), user: User = Depends(require("licence.review"))):
    rv = get_or_404(db, LicenceReview, rid)
    if rv.status not in ("open", "rejected"):
        raise HTTPException(409, f"review is {rv.status}")
    rv.status, rv.decision, rv.reviewer_id, rv.decided_at = body.status, body.decision, user.id, utcnow()
    if rv.subject_type == "asset":
        path = rv.subject_ref.split("#", 1)[0]
        a = db.execute(select(ProvenanceAsset).where(ProvenanceAsset.project_id == rv.project_id,
                                                     ProvenanceAsset.path == path)).scalar_one_or_none()
        if a and body.status in ("cleared", "rejected"):
            a.status = "cleared" if body.status == "cleared" else "blocked"
    audit.record(db, user, "licence.review_decided", "licence_review", rv.id, rv.project_id, status=body.status,
                 subject=rv.subject_ref, decision=body.decision)
    db.commit()
    return to_dict(rv)


@router.get("/builds/{bid}/sbom")
def sbom(bid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    comps = [to_dict(c) for c in db.execute(select(SbomComponent).where(SbomComponent.build_id == bid)).scalars()]
    art = db.execute(select(Artifact).where(Artifact.build_id == bid, Artifact.role == "sbom")).scalars().first()
    notices = db.execute(select(Artifact).where(Artifact.build_id == bid, Artifact.role == "notices")).scalars().first()
    return {"components": comps, "sbom_artifact": to_dict(art), "notices_artifact": to_dict(notices),
            "document": read_verified(art.storage_key, art.sha256).decode() if art else None}


# ------------------------------------------------------------------ packaging
@router.get("/packaging-templates")
def packaging_templates(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(t) for t in db.execute(select(PackagingTemplate)).scalars()]


class ArtworkIn(BaseModel):
    template_id: int
    purpose: str = Field(pattern="^(mockup|print)$")


@router.post("/releases/{rid}/editions/{eid}/artwork")
def make_artwork(rid: int, eid: int, body: ArtworkIn, db: Session = Depends(get_db),
                 user: User = Depends(require("packaging.edit"))):
    r = get_or_404(db, Release, rid)
    e = get_or_404(db, Edition, eid)
    t = get_or_404(db, PackagingTemplate, body.template_id)
    if not db.execute(select(ReleaseEdition).where(ReleaseEdition.release_id == rid, ReleaseEdition.edition_id == eid)).first():
        raise HTTPException(422, "edition is not part of this release")
    aw = packaging.create_artwork(db, e, r, t, body.purpose)
    audit.record(db, user, "packaging.artwork", "artwork", aw.id, r.project_id, purpose=body.purpose,
                 valid=aw.validation["valid"], errors=aw.validation["errors"])
    db.commit()
    return to_dict(aw)


@router.get("/editions/{eid}/artworks")
def artworks(eid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(a) for a in db.execute(select(Artwork).where(Artwork.edition_id == eid).order_by(Artwork.id.desc())).scalars()]


@router.get("/artworks/{awid}/svg")
def artwork_svg(awid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    aw = get_or_404(db, Artwork, awid)
    if not aw.artifact_id:
        raise HTTPException(404, "no artwork file (export failed validation)")
    a = db.get(Artifact, aw.artifact_id)
    return Response(read_verified(a.storage_key, a.sha256), media_type="image/svg+xml")
