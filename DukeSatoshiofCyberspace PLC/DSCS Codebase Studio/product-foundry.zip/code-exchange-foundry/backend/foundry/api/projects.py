"""Projects, requirements, tasks, milestones, costs, products and editions."""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from foundry import audit
from foundry.api.common import get_or_404, to_dict
from foundry.db import get_db, utcnow
from foundry.models import (CostEntry, Edition, LicenceVersion, Milestone, Product, Project, ProjectMember, Release,
                            Repository, Requirement, RequirementEvidence, Task, User)
from foundry.security import check, current_user, require

router = APIRouter(tags=["projects"])
REQ_CATEGORIES = {"workflow", "environment", "functional", "performance", "accessibility", "installation", "data",
                  "support"}
EDITION_KINDS = {"digital-download", "source-archive", "developer-kit", "boxed-key", "usb-collector", "bundle"}


class ProjectIn(BaseModel):
    slug: str = Field(pattern=r"^[a-z0-9][a-z0-9-]{1,60}$")
    name: str
    idea: str = ""
    intended_customers: str = ""
    problem_statement: str = ""
    supported_platforms: list[str] = []
    tech_stack: list[str] = []
    intended_licence: str = ""
    source_distribution_model: str = "binary-only"
    support_owner_id: int | None = None
    dependencies_note: str = ""
    status: str = "idea"


class ProjectPatch(BaseModel):
    name: str | None = None
    idea: str | None = None
    intended_customers: str | None = None
    problem_statement: str | None = None
    supported_platforms: list[str] | None = None
    tech_stack: list[str] | None = None
    intended_licence: str | None = None
    source_distribution_model: str | None = None
    support_owner_id: int | None = None
    owner_id: int | None = None
    status: str | None = None
    dependencies_note: str | None = None


@router.get("/projects")
def list_projects(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(p) for p in db.execute(select(Project).order_by(Project.id)).scalars()]


@router.post("/projects")
def create_project(body: ProjectIn, db: Session = Depends(get_db), user: User = Depends(require("project.create"))):
    if db.execute(select(Project).where(Project.slug == body.slug)).first():
        raise HTTPException(409, "slug already used")
    p = Project(**body.model_dump(), owner_id=user.id)
    db.add(p)
    db.flush()
    db.add(ProjectMember(project_id=p.id, user_id=user.id, responsibility="product owner"))
    audit.record(db, user, "project.created", "project", p.id, p.id, slug=p.slug)
    db.commit()
    return to_dict(p)


@router.get("/projects/{pid}")
def get_project(pid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    p = get_or_404(db, Project, pid)
    members = [{"user": to_dict(db.get(User, m.user_id), exclude={"roles"}), "responsibility": m.responsibility}
               for m in db.execute(select(ProjectMember).where(ProjectMember.project_id == pid)).scalars()]
    costs = {k: str(v) for k, v in db.execute(select(CostEntry.kind, func.sum(CostEntry.amount))
                                              .where(CostEntry.project_id == pid).group_by(CostEntry.kind)).all()}
    products = []
    for pr in db.execute(select(Product).where(Product.project_id == pid)).scalars():
        eds = [to_dict(e) for e in db.execute(select(Edition).where(Edition.product_id == pr.id)).scalars()]
        products.append(to_dict(pr, editions=eds))
    rels = [to_dict(r, exclude={"manifest", "readiness_snapshot"}) for r in
            db.execute(select(Release).where(Release.project_id == pid).order_by(Release.id.desc())).scalars()]
    repos = [to_dict(r) for r in db.execute(select(Repository).where(Repository.project_id == pid)).scalars()]
    owner = db.get(User, p.owner_id) if p.owner_id else None
    support = db.get(User, p.support_owner_id) if p.support_owner_id else None
    return to_dict(p, members=members, cost_totals=costs, products=products, releases=rels, repositories=repos,
                   owner_name=owner.name if owner else None, support_owner_name=support.name if support else None)


@router.patch("/projects/{pid}")
def patch_project(pid: int, body: ProjectPatch, db: Session = Depends(get_db), user: User = Depends(require("project.edit"))):
    p = get_or_404(db, Project, pid)
    changes = body.model_dump(exclude_none=True)
    for k, v in changes.items():
        setattr(p, k, v)
    audit.record(db, user, "project.updated", "project", p.id, p.id, fields=sorted(changes))
    db.commit()
    return to_dict(p)


class MemberIn(BaseModel):
    user_id: int
    responsibility: str = "contributor"


@router.post("/projects/{pid}/members")
def add_member(pid: int, body: MemberIn, db: Session = Depends(get_db), user: User = Depends(require("project.edit"))):
    get_or_404(db, Project, pid)
    get_or_404(db, User, body.user_id)
    db.add(ProjectMember(project_id=pid, user_id=body.user_id, responsibility=body.responsibility))
    audit.record(db, user, "project.member_added", "project", pid, pid, user_id=body.user_id)
    db.commit()
    return {"ok": True}


# ------------------------------------------------------------------ costs & milestones
class CostIn(BaseModel):
    kind: str = Field(pattern="^(estimate|recorded)$")
    category: str = "engineering"
    amount: float
    currency: str = "GBP"
    description: str = ""
    incurred_on: date | None = None


@router.get("/projects/{pid}/costs")
def costs(pid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(c) for c in db.execute(select(CostEntry).where(CostEntry.project_id == pid).order_by(CostEntry.id)).scalars()]


@router.post("/projects/{pid}/costs")
def add_cost(pid: int, body: CostIn, db: Session = Depends(get_db), user: User = Depends(require("cost.edit"))):
    c = CostEntry(project_id=pid, **body.model_dump())
    db.add(c)
    db.commit()
    return to_dict(c)


class MilestoneIn(BaseModel):
    title: str
    due_on: date | None = None


@router.get("/projects/{pid}/milestones")
def milestones(pid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(m) for m in db.execute(select(Milestone).where(Milestone.project_id == pid)).scalars()]


@router.post("/projects/{pid}/milestones")
def add_milestone(pid: int, body: MilestoneIn, db: Session = Depends(get_db), user: User = Depends(require("task.edit"))):
    m = Milestone(project_id=pid, **body.model_dump())
    db.add(m)
    db.commit()
    return to_dict(m)


# ------------------------------------------------------------------ requirements
class RequirementIn(BaseModel):
    key: str = Field(pattern=r"^[A-Z]+-\d{3,}$")
    category: str
    title: str
    description: str = ""
    acceptance_criteria: str = ""
    required_for_release: bool = True


class RequirementPatch(BaseModel):
    title: str | None = None
    description: str | None = None
    acceptance_criteria: str | None = None
    required_for_release: bool | None = None
    status: str | None = None


def _req(db: Session, r: Requirement) -> dict:
    ev = db.execute(select(RequirementEvidence).where(RequirementEvidence.requirement_id == r.id)
                    .order_by(RequirementEvidence.id.desc()).limit(10)).scalars().all()
    tasks = [to_dict(t) for t in db.execute(select(Task).where(Task.project_id == r.project_id)).scalars()
             if r.id in (t.requirement_ids or [])]
    return to_dict(r, evidence=[to_dict(e) for e in ev], tasks=tasks,
                   tasks_done=bool(tasks) and all(t["status"] == "done" for t in tasks))


@router.get("/projects/{pid}/requirements")
def list_requirements(pid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [_req(db, r) for r in db.execute(select(Requirement).where(Requirement.project_id == pid)
                                            .order_by(Requirement.key)).scalars()]


@router.post("/projects/{pid}/requirements")
def add_requirement(pid: int, body: RequirementIn, db: Session = Depends(get_db),
                    user: User = Depends(require("requirement.edit"))):
    if body.category not in REQ_CATEGORIES:
        raise HTTPException(422, f"category must be one of {sorted(REQ_CATEGORIES)}")
    r = Requirement(project_id=pid, **body.model_dump())
    db.add(r)
    db.flush()
    audit.record(db, user, "requirement.created", "requirement", r.id, pid, key=r.key)
    db.commit()
    return _req(db, r)


@router.patch("/requirements/{rid}")
def patch_requirement(rid: int, body: RequirementPatch, db: Session = Depends(get_db), user: User = Depends(current_user)):
    r = get_or_404(db, Requirement, rid)
    data = body.model_dump(exclude_none=True)
    status = data.pop("status", None)
    if data:
        check(user, "requirement.edit")
        if r.status in ("tested", "accepted") and ({"acceptance_criteria", "description"} & set(data)):
            r.status = "implemented"  # changed criteria invalidate earlier acceptance
            r.accepted_by = r.accepted_at = None
        for k, v in data.items():
            setattr(r, k, v)
    if status:
        # Only proposed <-> implemented (and rejected) are set by hand. 'tested' comes from evidence,
        # 'accepted' from the accept endpoint. Finishing tasks never changes this.
        allowed = {("proposed", "implemented"), ("implemented", "proposed"), ("proposed", "rejected"),
                   ("rejected", "proposed")}
        if (r.status, status) not in allowed:
            raise HTTPException(409, f"cannot set requirement from {r.status} to {status} directly")
        check(user, "task.edit" if status == "implemented" else "requirement.edit")
        r.status = status
    audit.record(db, user, "requirement.updated", "requirement", r.id, r.project_id, fields=sorted(body.model_dump(exclude_none=True)))
    db.commit()
    return _req(db, r)


class EvidenceIn(BaseModel):
    kind: str = Field(pattern="^(manual|document)$")
    reference: str
    result: str = Field(pattern="^(passed|failed)$")
    note: str = ""


@router.post("/requirements/{rid}/evidence")
def add_evidence(rid: int, body: EvidenceIn, db: Session = Depends(get_db), user: User = Depends(require("evidence.record"))):
    r = get_or_404(db, Requirement, rid)
    db.add(RequirementEvidence(requirement_id=r.id, recorded_by=user.id, **body.model_dump()))
    if body.result == "passed" and r.status == "implemented":
        r.status = "tested"
    elif body.result == "failed" and r.status in ("tested", "accepted"):
        r.status, r.accepted_by, r.accepted_at = "implemented", None, None
    audit.record(db, user, "requirement.evidence", "requirement", r.id, r.project_id, result=body.result,
                 reference=body.reference)
    db.commit()
    return _req(db, r)


@router.post("/requirements/{rid}/accept")
def accept_requirement(rid: int, db: Session = Depends(get_db), user: User = Depends(require("requirement.accept"))):
    r = get_or_404(db, Requirement, rid)
    if r.status != "tested":
        raise HTTPException(409, f"requirement is {r.status}; it needs passing evidence (tested) before acceptance")
    latest = db.execute(select(RequirementEvidence).where(RequirementEvidence.requirement_id == r.id)
                        .order_by(RequirementEvidence.id.desc())).scalars().first()
    if latest is None or latest.result != "passed":
        raise HTTPException(409, "latest evidence is not passing")
    r.status, r.accepted_by, r.accepted_at = "accepted", user.id, utcnow()
    audit.record(db, user, "requirement.accepted", "requirement", r.id, r.project_id, key=r.key)
    db.commit()
    return _req(db, r)


# ------------------------------------------------------------------ tasks
class TaskIn(BaseModel):
    title: str
    description: str = ""
    assignee_id: int | None = None
    milestone_id: int | None = None
    requirement_ids: list[int] = []
    branch: str | None = None
    external_url: str | None = None


class TaskPatch(BaseModel):
    title: str | None = None
    status: str | None = Field(default=None, pattern="^(todo|in_progress|review|done)$")
    assignee_id: int | None = None
    branch: str | None = None
    external_url: str | None = None
    requirement_ids: list[int] | None = None


@router.get("/projects/{pid}/tasks")
def list_tasks(pid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    out = []
    for t in db.execute(select(Task).where(Task.project_id == pid).order_by(Task.id)).scalars():
        a = db.get(User, t.assignee_id) if t.assignee_id else None
        out.append(to_dict(t, assignee_name=a.name if a else None))
    return out


@router.post("/projects/{pid}/tasks")
def add_task(pid: int, body: TaskIn, db: Session = Depends(get_db), user: User = Depends(require("task.edit"))):
    t = Task(project_id=pid, **body.model_dump())
    db.add(t)
    db.flush()
    audit.record(db, user, "task.created", "task", t.id, pid)
    db.commit()
    return to_dict(t)


@router.patch("/tasks/{tid}")
def patch_task(tid: int, body: TaskPatch, db: Session = Depends(get_db), user: User = Depends(require("task.edit"))):
    t = get_or_404(db, Task, tid)
    for k, v in body.model_dump(exclude_none=True).items():
        setattr(t, k, v)
    audit.record(db, user, "task.updated", "task", t.id, t.project_id, **body.model_dump(exclude_none=True))
    db.commit()
    return to_dict(t)


# ------------------------------------------------------------------ products & editions
class ProductIn(BaseModel):
    slug: str = Field(pattern=r"^[a-z0-9][a-z0-9-]{1,60}$")
    name: str
    tagline: str = ""
    description: str = ""
    category: str = "Developer tools"


@router.get("/projects/{pid}/products")
def list_products(pid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(p) for p in db.execute(select(Product).where(Product.project_id == pid)).scalars()]


@router.get("/products")
def all_products(db: Session = Depends(get_db), user: User = Depends(current_user)):
    out = []
    for p in db.execute(select(Product)).scalars():
        eds = [to_dict(e) for e in db.execute(select(Edition).where(Edition.product_id == p.id)).scalars()]
        out.append(to_dict(p, editions=eds))
    return out


@router.post("/projects/{pid}/products")
def add_product(pid: int, body: ProductIn, db: Session = Depends(get_db), user: User = Depends(require("product.edit"))):
    p = Product(project_id=pid, **body.model_dump())
    db.add(p)
    db.flush()
    audit.record(db, user, "product.created", "product", p.id, pid, slug=p.slug)
    db.commit()
    return to_dict(p)


class ProductPatch(BaseModel):
    name: str | None = None
    tagline: str | None = None
    description: str | None = None
    category: str | None = None
    screenshots: list[int] | None = None


@router.patch("/products/{prid}")
def patch_product(prid: int, body: ProductPatch, db: Session = Depends(get_db), user: User = Depends(require("product.edit"))):
    p = get_or_404(db, Product, prid)
    for k, v in body.model_dump(exclude_none=True).items():
        setattr(p, k, v)
    audit.record(db, user, "product.updated", "product", p.id, p.project_id)
    db.commit()
    return to_dict(p)


class EditionIn(BaseModel):
    code: str = Field(pattern=r"^[a-z0-9][a-z0-9-]{1,40}$")
    name: str
    kind: str
    licence_version_id: int | None = None
    contents: list[str] = []
    bundle_edition_ids: list[int] = []
    sku: str
    gtin: str | None = None
    price: dict = {}
    delivery_method: str = "download"
    update_policy: dict = {}
    support_terms: str = ""
    support_days: int = 365
    physical: dict = {}


class EditionPatch(BaseModel):
    name: str | None = None
    licence_version_id: int | None = None
    price: dict | None = None
    gtin: str | None = None
    update_policy: dict | None = None
    support_terms: str | None = None
    active: bool | None = None


@router.get("/products/{prid}/editions")
def list_editions(prid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(e) for e in db.execute(select(Edition).where(Edition.product_id == prid)).scalars()]


@router.post("/products/{prid}/editions")
def add_edition(prid: int, body: EditionIn, db: Session = Depends(get_db), user: User = Depends(require("edition.edit"))):
    pr = get_or_404(db, Product, prid)
    if body.kind not in EDITION_KINDS:
        raise HTTPException(422, f"kind must be one of {sorted(EDITION_KINDS)}")
    if body.gtin:
        from foundry.packaging import valid_gtin13
        if not valid_gtin13(body.gtin):
            raise HTTPException(422, "GTIN must be a GS1-allocated 13-digit number with a valid check digit")
    if body.licence_version_id:
        get_or_404(db, LicenceVersion, body.licence_version_id)
    e = Edition(product_id=prid, **body.model_dump())
    db.add(e)
    db.flush()
    audit.record(db, user, "edition.created", "edition", e.id, pr.project_id, code=e.code, kind=e.kind)
    db.commit()
    return to_dict(e)


@router.patch("/editions/{eid}")
def patch_edition(eid: int, body: EditionPatch, db: Session = Depends(get_db), user: User = Depends(require("edition.edit"))):
    e = get_or_404(db, Edition, eid)
    data = body.model_dump(exclude_none=True)
    if "gtin" in data and data["gtin"]:
        from foundry.packaging import valid_gtin13
        if not valid_gtin13(data["gtin"]):
            raise HTTPException(422, "GTIN check digit is invalid")
    if "licence_version_id" in data and e.licence_version_id and data["licence_version_id"] != e.licence_version_id:
        # changing the licence terms of an existing edition is a licence decision
        check(user, "licence.edit")
    for k, v in data.items():
        setattr(e, k, v)
    audit.record(db, user, "edition.updated", "edition", e.id, db.get(Product, e.product_id).project_id, **data)
    db.commit()
    return to_dict(e)
