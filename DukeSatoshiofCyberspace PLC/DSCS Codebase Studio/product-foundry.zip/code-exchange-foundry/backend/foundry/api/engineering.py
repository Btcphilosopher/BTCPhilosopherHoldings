"""Repositories, Git browsing, builds and artefacts."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import PlainTextResponse, Response
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from foundry import audit, builder
from foundry.api.common import get_or_404, to_dict
from foundry.db import get_db
from foundry.gitadapter import GitError, adapter_for, allowed_local_path, LocalGitAdapter
from foundry.models import (Artifact, Build, BuildStage, Project, Repository, SbomComponent, ScanFinding, ScanRun,
                            TestResult, User)
from foundry.security import current_user, require
from foundry.storage import IntegrityError, get_storage, read_verified

router = APIRouter(tags=["engineering"])


class RepoIn(BaseModel):
    provider: str = "local"
    name: str
    location: str
    web_url: str | None = None
    credential_ref: str | None = None
    protected_branches: list[str] = ["main"]
    scopes: list[str] = ["read"]


def _repo_or_404(db, rid) -> Repository:
    return get_or_404(db, Repository, rid)


def _git(fn):
    try:
        return fn()
    except GitError as exc:
        raise HTTPException(422, str(exc))


@router.get("/projects/{pid}/repositories")
def list_repos(pid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(r) for r in db.execute(select(Repository).where(Repository.project_id == pid)).scalars()]


@router.get("/repositories")
def all_repos(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(r, project=db.get(Project, r.project_id).name) for r in db.execute(select(Repository)).scalars()]


@router.post("/projects/{pid}/repositories")
def connect_repo(pid: int, body: RepoIn, db: Session = Depends(get_db), user: User = Depends(require("repo.connect"))):
    get_or_404(db, Project, pid)
    if body.provider not in ("local", "github", "gitlab"):
        raise HTTPException(422, "provider must be local, github or gitlab")
    if body.scopes != ["read"] and set(body.scopes) - {"read", "assistant-branches"}:
        raise HTTPException(422, "only 'read' and 'assistant-branches' scopes may be granted")
    if body.provider == "local":
        path = str(_git(lambda: allowed_local_path(body.location)))
        ad = LocalGitAdapter(path)
        origin = _git(ad.origin)
        default = ad.default_branch()
    else:
        if body.credential_ref and not body.credential_ref.replace("_", "").isalnum():
            raise HTTPException(422, "credential_ref must name a secret (letters, digits, underscore)")
        path, origin, default = body.location, {"provider": body.provider, "location": body.location}, "main"
    r = Repository(project_id=pid, provider=body.provider, name=body.name, location=path, web_url=body.web_url,
                   default_branch=default, protected_branches=body.protected_branches, credential_ref=body.credential_ref,
                   scopes=body.scopes, origin=origin, connected_by=user.id)
    db.add(r)
    db.flush()
    audit.record(db, user, "repository.connected", "repository", r.id, pid, provider=r.provider, location=path,
                 scopes=body.scopes, credential_ref=body.credential_ref, origin=origin)
    db.commit()
    return to_dict(r)


@router.delete("/repositories/{rid}")
def disconnect_repo(rid: int, db: Session = Depends(get_db), user: User = Depends(require("repo.connect"))):
    r = _repo_or_404(db, rid)
    r.active = False
    audit.record(db, user, "repository.disconnected", "repository", r.id, r.project_id)
    db.commit()
    return {"ok": True}


@router.get("/repositories/{rid}/branches")
def branches(rid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    r = _repo_or_404(db, rid)
    return _git(lambda: adapter_for(r).branches())


@router.get("/repositories/{rid}/commits")
def commits(rid: int, ref: str | None = None, limit: int = 50, db: Session = Depends(get_db),
            user: User = Depends(current_user)):
    r = _repo_or_404(db, rid)
    out = _git(lambda: adapter_for(r).commits(ref or r.default_branch, limit))
    built = {b.commit_sha: b for b in db.execute(select(Build).where(Build.repository_id == rid)).scalars()}
    for c in out:
        b = built.get(c["sha"])
        c["build"] = {"id": b.id, "number": b.number, "status": b.status} if b else None
    return out


@router.get("/repositories/{rid}/tree")
def tree(rid: int, ref: str | None = None, path: str = "", db: Session = Depends(get_db), user: User = Depends(current_user)):
    r = _repo_or_404(db, rid)
    ad = adapter_for(r)
    sha = _git(lambda: ad.resolve(ref or r.default_branch))
    return {"commit": sha, "path": path, "entries": _git(lambda: ad.tree(sha, path))}


@router.get("/repositories/{rid}/file")
def file(rid: int, path: str, ref: str | None = None, db: Session = Depends(get_db), user: User = Depends(current_user)):
    r = _repo_or_404(db, rid)
    ad = adapter_for(r)
    sha = _git(lambda: ad.resolve(ref or r.default_branch))
    return {"commit": sha, **_git(lambda: ad.read_file(sha, path)), "editor_link": ad.editor_link(path)}


@router.get("/repositories/{rid}/diff")
def diff(rid: int, base: str, head: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    r = _repo_or_404(db, rid)
    ad = adapter_for(r)
    summary = _git(lambda: ad.diff_summary(base, head))
    patch = _git(lambda: ad.diff_patch(base, head)) if isinstance(ad, LocalGitAdapter) else ""
    return {**summary, "patch": patch[:200_000]}


@router.get("/repositories/{rid}/links")
def links(rid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    r = _repo_or_404(db, rid)
    ad = adapter_for(r)
    if r.provider == "local":
        return {"pull_requests": [], "issues": [], "supported": False,
                "note": "Local repositories have no pull requests or issues; link tasks to external URLs instead.",
                "editor_link": ad.editor_link()}
    return {"pull_requests": _git(ad.pull_requests), "issues": _git(ad.issues), "supported": True,
            "editor_link": ad.editor_link()}


# ------------------------------------------------------------------ builds
class BuildIn(BaseModel):
    ref: str


def _build(db: Session, b: Build, full: bool = False) -> dict:
    d = to_dict(b, exclude=set() if full else {"pipeline", "worker_env"})
    trig = db.get(User, b.triggered_by) if b.triggered_by else None
    d["triggered_by_name"] = trig.name if trig else None
    if full:
        d["stages"] = [to_dict(s) for s in db.execute(select(BuildStage).where(BuildStage.build_id == b.id)
                                                      .order_by(BuildStage.position)).scalars()]
        d["tests"] = [to_dict(t) for t in db.execute(select(TestResult).where(TestResult.build_id == b.id)).scalars()]
        d["artifacts"] = [to_dict(a) for a in db.execute(select(Artifact).where(Artifact.build_id == b.id)).scalars()]
        d["scans"] = [to_dict(s, findings=[to_dict(f) for f in db.execute(select(ScanFinding).where(
            ScanFinding.scan_run_id == s.id)).scalars()]) for s in
            db.execute(select(ScanRun).where(ScanRun.build_id == b.id)).scalars()]
        d["sbom"] = [to_dict(c) for c in db.execute(select(SbomComponent).where(SbomComponent.build_id == b.id)).scalars()]
        d["retries"] = [{"id": x.id, "number": x.number, "status": x.status} for x in
                        db.execute(select(Build).where(Build.retry_of_id == b.id)).scalars()]
    return d


@router.post("/repositories/{rid}/builds")
def trigger_build(rid: int, body: BuildIn, db: Session = Depends(get_db), user: User = Depends(require("build.run"))):
    r = _repo_or_404(db, rid)
    if not r.active:
        raise HTTPException(409, "repository is disconnected")
    b = _git(lambda: builder.create_build(db, db.get(Project, r.project_id), r, body.ref, user))
    db.commit()
    return _build(db, b)


@router.get("/projects/{pid}/builds")
def list_builds(pid: int, limit: int = 100, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [_build(db, b) for b in db.execute(select(Build).where(Build.project_id == pid)
                                              .order_by(Build.id.desc()).limit(limit)).scalars()]


@router.get("/builds")
def all_builds(limit: int = 100, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [_build(db, b) | {"project": db.get(Project, b.project_id).name}
            for b in db.execute(select(Build).order_by(Build.id.desc()).limit(limit)).scalars()]


@router.get("/builds/{bid}")
def get_build(bid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return _build(db, get_or_404(db, Build, bid), full=True)


@router.get("/builds/{bid}/stages/{sid}/log", response_class=PlainTextResponse)
def stage_log(bid: int, sid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    st = get_or_404(db, BuildStage, sid)
    if st.build_id != bid:
        raise HTTPException(404, "stage not in build")
    if st.log_key:
        return get_storage().get(st.log_key).decode(errors="replace")
    return st.log_tail or ""


@router.post("/builds/{bid}/cancel")
def cancel_build(bid: int, db: Session = Depends(get_db), user: User = Depends(require("build.cancel"))):
    b = get_or_404(db, Build, bid)
    try:
        builder.request_cancel(db, b, user)
    except ValueError as exc:
        raise HTTPException(409, str(exc))
    db.commit()
    return _build(db, b)


@router.post("/builds/{bid}/retry")
def retry_build(bid: int, db: Session = Depends(get_db), user: User = Depends(require("build.run"))):
    """A retry is a NEW build of the same immutable commit; the earlier result is preserved."""
    b = get_or_404(db, Build, bid)
    if b.status in ("queued", "running"):
        raise HTTPException(409, "build still in progress")
    new = builder.create_build(db, db.get(Project, b.project_id), db.get(Repository, b.repository_id), b.commit_sha,
                               user, trigger="retry", retry_of=b)
    db.commit()
    return _build(db, new)


class FindingPatch(BaseModel):
    status: str


@router.patch("/findings/{fid}")
def patch_finding(fid: int, body: FindingPatch, db: Session = Depends(get_db), user: User = Depends(require("quality.review"))):
    f = get_or_404(db, ScanFinding, fid)
    if body.status not in ("open", "accepted-risk", "fixed", "false-positive"):
        raise HTTPException(422, "invalid status")
    audit.record(db, user, "finding.status", "finding", f.id, None, before=f.status, after=body.status)
    f.status = body.status
    db.commit()
    return to_dict(f)


# ------------------------------------------------------------------ artefacts
@router.get("/artifacts/{aid}")
def artifact_meta(aid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return to_dict(get_or_404(db, Artifact, aid))


@router.get("/artifacts/{aid}/download")
def artifact_download(aid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    a = get_or_404(db, Artifact, aid)
    try:
        data = read_verified(a.storage_key, a.sha256)
    except IntegrityError as exc:
        raise HTTPException(500, f"integrity failure: {exc}")
    return Response(data, media_type=a.media_type, headers={
        "Content-Disposition": f'attachment; filename="{a.filename}"', "X-Content-SHA256": a.sha256})
