from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy import inspect
from sqlalchemy.orm import Session

HIDDEN = {"password_hash"}


def to_dict(obj, exclude: set[str] = frozenset(), **extra) -> dict:
    if obj is None:
        return None
    out = {}
    for attr in inspect(obj).mapper.column_attrs:
        k = attr.key
        if k in HIDDEN or k in exclude:
            continue
        v = getattr(obj, k)
        if isinstance(v, (datetime, date)):
            v = v.isoformat()
        elif isinstance(v, Decimal):
            v = str(v)
        out[k.rstrip("_")] = v
    out.update(extra)
    return out


def get_or_404(db: Session, model, ident):
    obj = db.get(model, ident)
    if obj is None:
        raise HTTPException(404, f"{model.__name__} {ident} not found")
    return obj
