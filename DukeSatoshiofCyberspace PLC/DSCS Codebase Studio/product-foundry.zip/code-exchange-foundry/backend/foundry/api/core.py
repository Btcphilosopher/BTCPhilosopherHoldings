"""Authentication, administration, audit, jobs and the overview page."""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from foundry import audit, jobs, releases
from foundry.api.common import get_or_404, to_dict
from foundry.db import get_db
from foundry.models import (AuditEvent, Build, CatalogueListing, Edition, Job, Product, Project, Release,
                            Setting, User)
from foundry.security import (PERMISSIONS, ROLES, current_user, has_permission, hash_password, issue_token,
                              require, verify_password)

router = APIRouter()


class LoginIn(BaseModel):
    email: str
    password: str


@router.post("/auth/login", tags=["auth"])
def login(body: LoginIn, db: Session = Depends(get_db)):
    u = db.execute(select(User).where(User.email == body.email.lower())).scalar_one_or_none()
    if u is None or u.is_service or not u.active or not verify_password(body.password, u.password_hash):
        raise HTTPException(401, "invalid credentials")
    return {"token": issue_token(u), "user": _user(u)}


def _user(u: User) -> dict:
    return to_dict(u, permissions=sorted(p for p in PERMISSIONS if has_permission(u, p)))


@router.get("/auth/me", tags=["auth"])
def me(user: User = Depends(current_user)):
    return _user(user)


@router.get("/roles", tags=["admin"])
def roles(user: User = Depends(current_user)):
    return {"roles": ROLES, "permissions": {k: sorted(v) for k, v in PERMISSIONS.items()}}


@router.get("/users", tags=["admin"])
def list_users(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(u) for u in db.execute(select(User).order_by(User.id)).scalars()]


class UserIn(BaseModel):
    email: str
    name: str
    password: str
    roles: list[str]


@router.post("/users", tags=["admin"])
def create_user(body: UserIn, db: Session = Depends(get_db), user: User = Depends(require("admin.users"))):
    bad = [r for r in body.roles if r not in ROLES or r == "assistant"]
    if bad:
        raise HTTPException(422, f"unknown or reserved roles: {bad}")
    u = User(email=body.email.lower(), name=body.name, password_hash=hash_password(body.password), roles=body.roles)
    db.add(u)
    db.flush()
    audit.record(db, user, "user.created", "user", u.id, roles=body.roles)
    db.commit()
    return to_dict(u)


class UserPatch(BaseModel):
    roles: list[str] | None = None
    active: bool | None = None


@router.patch("/users/{uid}", tags=["admin"])
def patch_user(uid: int, body: UserPatch, db: Session = Depends(get_db), user: User = Depends(require("admin.users"))):
    u = get_or_404(db, User, uid)
    if u.is_service:
        raise HTTPException(409, "service identities are managed by the system")
    if body.roles is not None:
        if any(r not in ROLES or r == "assistant" for r in body.roles):
            raise HTTPException(422, "unknown or reserved role")
        audit.record(db, user, "user.roles_changed", "user", u.id, before=u.roles, after=body.roles)
        u.roles = body.roles
    if body.active is not None:
        u.active = body.active
        audit.record(db, user, "user.active_changed", "user", u.id, active=body.active)
    db.commit()
    return to_dict(u)


@router.get("/audit", tags=["admin"])
def audit_log(entity_type: str | None = None, entity_id: str | None = None, project_id: int | None = None,
              limit: int = 200, db: Session = Depends(get_db), user: User = Depends(require("audit.read"))):
    q = select(AuditEvent).order_by(AuditEvent.id.desc()).limit(min(limit, 1000))
    if entity_type:
        q = q.where(AuditEvent.entity_type == entity_type)
    if entity_id:
        q = q.where(AuditEvent.entity_id == entity_id)
    if project_id:
        q = q.where(AuditEvent.project_id == project_id)
    return [to_dict(e) for e in db.execute(q).scalars()]


@router.get("/audit/verify", tags=["admin"])
def audit_verify(db: Session = Depends(get_db), user: User = Depends(require("audit.read"))):
    return audit.verify_chain(db)


@router.get("/jobs", tags=["admin"])
def list_jobs(status: str | None = None, kind: str | None = None, limit: int = 100, db: Session = Depends(get_db),
              user: User = Depends(current_user)):
    q = select(Job).order_by(Job.id.desc()).limit(min(limit, 500))
    if status:
        q = q.where(Job.status == status)
    if kind:
        q = q.where(Job.kind == kind)
    return [to_dict(j) for j in db.execute(q).scalars()]


@router.post("/jobs/{jid}/retry", tags=["admin"])
def retry_job(jid: int, db: Session = Depends(get_db), user: User = Depends(require("jobs.manage"))):
    j = get_or_404(db, Job, jid)
    if j.status != "dead":
        raise HTTPException(409, "only dead jobs can be retried manually")
    j.status, j.max_attempts, j.finished_at = "queued", j.attempts + 1, None
    audit.record(db, user, "job.manual_retry", "job", j.id, kind=j.kind)
    db.commit()
    return to_dict(j)


@router.get("/settings", tags=["admin"])
def get_settings(db: Session = Depends(get_db), user: User = Depends(current_user)):
    from foundry import config
    stored = {s.key: s.value for s in db.execute(select(Setting)).scalars()}
    s = config.settings
    return {"stored": stored, "runtime": {"sandbox": s.sandbox, "sandbox_image": s.sandbox_image,
                                          "sandbox_memory_mb": s.sandbox_memory_mb, "storage_backend": s.storage_backend,
                                          "require_separate_approver": s.require_separate_approver,
                                          "assistant_provider": s.assistant_provider, "storefront_url": s.storefront_url,
                                          "repo_roots": [str(r) for r in s.repo_roots]}}


class SettingIn(BaseModel):
    value: Any


@router.put("/settings/{key}", tags=["admin"])
def put_setting(key: str, body: SettingIn, db: Session = Depends(get_db), user: User = Depends(require("admin.settings"))):
    s = db.get(Setting, key) or Setting(key=key, value=None)
    audit.record(db, user, "setting.changed", "setting", key, before=s.value, after=body.value)
    s.value = body.value
    db.add(s)
    db.commit()
    return {"key": key, "value": s.value}


@router.get("/overview", tags=["overview"])
def overview(db: Session = Depends(get_db), user: User = Depends(current_user)):
    """What are we building, what is blocking release, and what is ready to sell?"""
    building = []
    for p in db.execute(select(Project).where(Project.status.in_(["idea", "development", "release-prep"]))).scalars():
        last = db.execute(select(Build).where(Build.project_id == p.id).order_by(Build.id.desc()).limit(1)).scalar_one_or_none()
        building.append({"project": to_dict(p, exclude={"idea", "problem_statement"}),
                         "latest_build": to_dict(last, exclude={"pipeline", "worker_env"}) if last else None})
    blocking = []
    for rel in db.execute(select(Release).where(Release.status.in_(["draft", "candidate", "validation"]))).scalars():
        r = releases.evaluate(db, rel) if rel.build_id else {"blocking": ["no build"], "checks": []}
        blocking.append({"release": to_dict(rel, exclude={"manifest", "readiness_snapshot", "history"}),
                         "product": db.get(Product, rel.product_id).name, "blocking": r["blocking"],
                         "checks": [{"key": c["key"], "status": c["status"], "summary": c["summary"]} for c in r["checks"]
                                    if c["status"] in ("failed", "excepted", "warning")]})
    ready = []
    for lst in db.execute(select(CatalogueListing)).scalars():
        e = db.get(Edition, lst.edition_id)
        rel = db.get(Release, lst.current_release_id or lst.draft_release_id) if (lst.current_release_id or lst.draft_release_id) else None
        ready.append({"listing_id": lst.id, "status": lst.status, "edition": e.name, "sku": e.sku, "kind": e.kind,
                      "price": e.price, "product": db.get(Product, e.product_id).name,
                      "release": rel.version if rel else None, "release_status": rel.status if rel else None})
    approved = [to_dict(r, exclude={"manifest", "readiness_snapshot", "history"}, product=db.get(Product, r.product_id).name)
                for r in db.execute(select(Release).where(Release.status.in_(["approved", "published"]))).scalars()]
    counts = {s: n for s, n in db.execute(select(Build.status, func.count()).group_by(Build.status)).all()}
    return {"building": building, "blocking": blocking, "ready_to_sell": ready, "approved_releases": approved,
            "build_counts": counts,
            "jobs": {s: n for s, n in db.execute(select(Job.status, func.count()).group_by(Job.status)).all()}}
