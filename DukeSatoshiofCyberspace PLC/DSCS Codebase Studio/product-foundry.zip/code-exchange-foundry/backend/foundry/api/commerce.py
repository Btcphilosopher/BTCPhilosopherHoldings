"""Catalogue publication, entitlements, advisories, customer support and the assistant."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from foundry import assistant, audit, catalogue, jobs, support
from foundry.api.common import get_or_404, to_dict
from foundry.db import get_db
from foundry.models import (Advisory, AssistantRun, CatalogueListing, CustomerContact, Edition, Entitlement, Product,
                            Project, PublicationJob, Release, Repository, SupportIssue, Task, User)
from foundry.security import check, current_user, require

router = APIRouter(tags=["catalogue & support"])


def _listing(db: Session, l: CatalogueListing) -> dict:
    e = db.get(Edition, l.edition_id)
    cur = db.get(Release, l.current_release_id) if l.current_release_id else None
    drf = db.get(Release, l.draft_release_id) if l.draft_release_id else None
    return to_dict(l, exclude={"draft_payload", "published_payload"}, edition=to_dict(e),
                   product=db.get(Product, l.product_id).name, current_version=cur.version if cur else None,
                   draft_version=drf.version if drf else None)


@router.get("/catalogue/listings")
def listings(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [_listing(db, l) for l in db.execute(select(CatalogueListing).order_by(CatalogueListing.id)).scalars()]


class PrepareIn(BaseModel):
    release_id: int


@router.post("/editions/{eid}/listing/prepare")
def prepare(eid: int, body: PrepareIn, db: Session = Depends(get_db), user: User = Depends(require("catalogue.edit"))):
    e = get_or_404(db, Edition, eid)
    rel = get_or_404(db, Release, body.release_id)
    lst = catalogue.ensure_listing(db, e)
    out = catalogue.prepare(db, lst, rel, user)
    db.commit()
    return out


@router.get("/listings/{lid}/preview")
def preview(lid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return catalogue.preview(db, get_or_404(db, CatalogueListing, lid))


class CommentIn(BaseModel):
    comment: str = ""


@router.post("/listings/{lid}/approve")
def approve(lid: int, body: CommentIn, db: Session = Depends(get_db), user: User = Depends(require("catalogue.approve"))):
    lst = get_or_404(db, CatalogueListing, lid)
    catalogue.approve_listing(db, lst, user, body.comment)
    db.commit()
    return _listing(db, lst)


@router.post("/listings/{lid}/publish")
def publish(lid: int, db: Session = Depends(get_db), user: User = Depends(require("catalogue.publish"))):
    lst = get_or_404(db, CatalogueListing, lid)
    pj = catalogue.request_publish(db, lst, user)
    db.commit()
    return to_dict(pj)


class ReasonIn(BaseModel):
    reason: str = Field(min_length=5)
    target_release_id: int | None = None


@router.post("/listings/{lid}/rollback")
def rollback(lid: int, body: ReasonIn, db: Session = Depends(get_db), user: User = Depends(require("catalogue.rollback"))):
    pj = catalogue.rollback(db, get_or_404(db, CatalogueListing, lid), user, body.reason, body.target_release_id)
    db.commit()
    return to_dict(pj) | {"notice": catalogue.ROLLBACK_NOTICE}


@router.get("/publication-jobs")
def publication_jobs(listing_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(current_user)):
    q = select(PublicationJob).order_by(PublicationJob.id.desc())
    if listing_id:
        q = q.where(PublicationJob.listing_id == listing_id)
    return [to_dict(p) for p in db.execute(q).scalars()]


@router.get("/publication-jobs/{pid}")
def publication_job(pid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    pj = get_or_404(db, PublicationJob, pid)
    from foundry.models import Job
    return to_dict(pj, job=to_dict(db.get(Job, pj.job_id)) if pj.job_id else None)


# ------------------------------------------------------------------ entitlements & advisories
@router.post("/entitlements/sync")
def sync_entitlements(db: Session = Depends(get_db), user: User = Depends(require("support.import"))):
    job = jobs.enqueue(db, "entitlements.sync", {}, max_attempts=3)
    db.commit()
    return {"job_id": job.id}


@router.get("/entitlements")
def entitlements(customer_ref: str | None = None, db: Session = Depends(get_db), user: User = Depends(current_user)):
    q = select(Entitlement).order_by(Entitlement.id)
    if customer_ref:
        q = q.where(Entitlement.customer_ref == customer_ref)
    out = []
    for e in db.execute(q).scalars():
        ed = db.get(Edition, e.edition_id)
        ids = support.eligible_release_ids(db, e)
        out.append(to_dict(e, edition=ed.name, edition_code=ed.code,
                           eligible_versions=[db.get(Release, i).version for i in ids]))
    return out


@router.get("/advisories")
def advisories(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(a) for a in db.execute(select(Advisory).order_by(Advisory.id.desc())).scalars()]


class AdvisoryIn(BaseModel):
    product_id: int
    release_id: int | None = None
    kind: str = Field(pattern="^(defect|security|end-of-support|info)$")
    title: str
    body: str


@router.post("/advisories")
def create_advisory(body: AdvisoryIn, db: Session = Depends(get_db), user: User = Depends(require("advisory.publish"))):
    adv = Advisory(**body.model_dump(), published=False)
    db.add(adv)
    db.flush()
    lst = db.execute(select(CatalogueListing).where(CatalogueListing.product_id == body.product_id,
                                                    CatalogueListing.external_edition_id.isnot(None))).scalars().first()
    if lst:
        try:
            r = catalogue.client().post_advisory({"edition_id": lst.external_edition_id, "kind": body.kind,
                                                  "title": body.title, "body": body.body}, f"advisory:{adv.id}")
            adv.published, adv.external_id = True, r.get("id")
        except catalogue.StorefrontError as exc:
            raise HTTPException(502, f"storefront unavailable: {exc}")
    audit.record(db, user, "advisory.created", "advisory", adv.id, None, kind=body.kind, published=adv.published)
    db.commit()
    return to_dict(adv)


# ------------------------------------------------------------------ support
@router.post("/support/import")
def import_support(db: Session = Depends(get_db), user: User = Depends(require("support.import"))):
    job = jobs.enqueue(db, "support.import", {}, max_attempts=3)
    db.commit()
    return {"job_id": job.id}


@router.get("/support/issues")
def issues(product_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(current_user)):
    q = select(SupportIssue).order_by(SupportIssue.id.desc())
    if product_id:
        q = q.where(SupportIssue.product_id == product_id)
    out = []
    for i in db.execute(q).scalars():
        fix = db.get(Release, i.fix_release_id) if i.fix_release_id else None
        owner = db.get(User, i.owner_id) if i.owner_id else None
        out.append(to_dict(i, fix_version=fix.version if fix else None, owner_name=owner.name if owner else None,
                           product=db.get(Product, i.product_id).name))
    return out


class IssuePatch(BaseModel):
    severity_reviewed: str | None = Field(default=None, pattern="^(critical|high|medium|low)$")
    owner_id: int | None = None
    status: str | None = Field(default=None, pattern="^(new|triaged|in-progress|fixed|closed)$")
    fix_release_id: int | None = None
    customer_note: str | None = None


@router.patch("/support/issues/{iid}")
def patch_issue(iid: int, body: IssuePatch, db: Session = Depends(get_db), user: User = Depends(require("support.triage"))):
    i = get_or_404(db, SupportIssue, iid)
    data = body.model_dump(exclude_none=True)
    if "severity_reviewed" in data:
        i.reviewed_by = user.id
        if i.status == "new":
            i.status = "triaged"
    if data.get("status") == "fixed" and not (data.get("fix_release_id") or i.fix_release_id):
        raise HTTPException(422, "a fixed issue needs a fix version")
    for k, v in data.items():
        setattr(i, k, v)
    audit.record(db, user, "support.issue_updated", "support_issue", i.id, None, **data)
    db.commit()
    return to_dict(i)


@router.get("/support/issues/{iid}/contact")
def issue_contact(iid: int, db: Session = Depends(get_db), user: User = Depends(require("support.private"))):
    i = get_or_404(db, SupportIssue, iid)
    c = db.execute(select(CustomerContact).where(CustomerContact.customer_ref == i.customer_ref)).scalar_one_or_none()
    audit.record(db, user, "support.contact_viewed", "support_issue", i.id, None)  # access to private data is audited
    db.commit()
    return to_dict(c) if c else {}


# ------------------------------------------------------------------ assistant
class AssistantIn(BaseModel):
    action: str
    repository_id: int | None = None
    commit: str | None = None
    paths: list[str] = []
    instruction: str = ""


@router.post("/projects/{pid}/assistant")
def run_assistant(pid: int, body: AssistantIn, db: Session = Depends(get_db), user: User = Depends(require("assistant.use"))):
    project = get_or_404(db, Project, pid)
    repo = get_or_404(db, Repository, body.repository_id) if body.repository_id else None
    if repo and repo.project_id != pid:
        raise HTTPException(422, "repository belongs to another project")
    if body.action in ("draft-tests", "suggest-patch") and repo and "assistant-branches" not in (repo.scopes or []):
        raise HTTPException(403, "this repository connection does not grant the 'assistant-branches' scope")
    ar = assistant.run(db, project, repo, user, body.action, {"commit": body.commit, "paths": body.paths}, body.instruction)
    db.commit()
    return to_dict(ar)


@router.get("/projects/{pid}/assistant/runs")
def assistant_runs(pid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [to_dict(a) for a in db.execute(select(AssistantRun).where(AssistantRun.project_id == pid)
                                           .order_by(AssistantRun.id.desc())).scalars()]


class AcceptTasksIn(BaseModel):
    indexes: list[int]


@router.post("/assistant/runs/{aid}/accept-tasks")
def accept_tasks(aid: int, body: AcceptTasksIn, db: Session = Depends(get_db), user: User = Depends(require("task.edit"))):
    from foundry.models import Requirement
    ar = get_or_404(db, AssistantRun, aid)
    proposals = (ar.output or {}).get("tasks", [])
    created = []
    for i in body.indexes:
        p = proposals[i]
        req = db.execute(select(Requirement).where(Requirement.project_id == ar.project_id,
                                                   Requirement.key == p.get("requirement_key"))).scalar_one_or_none()
        t = Task(project_id=ar.project_id, title=p["title"], description=p.get("rationale", ""),
                 requirement_ids=[req.id] if req else [], proposed_by_assistant=True)
        db.add(t)
        created.append(t)
    db.flush()
    audit.record(db, user, "assistant.tasks_accepted", "assistant_run", ar.id, ar.project_id, count=len(created))
    db.commit()
    return [to_dict(t) for t in created]
