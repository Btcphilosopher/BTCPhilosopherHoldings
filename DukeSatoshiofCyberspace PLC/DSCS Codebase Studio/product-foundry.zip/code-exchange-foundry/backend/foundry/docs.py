"""Documentation production: versioned templates, release-bound documents, HTML/PDF output,
executable example checks and unsupported-statement flags."""
from __future__ import annotations

import html
import io
import re
import shutil
import uuid
from pathlib import Path

import markdown as md
from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from foundry import audit, config, jobs
from foundry.db import session_scope, utcnow
from foundry.gitadapter import adapter_for
from foundry.models import (Artifact, Build, DocTemplate, Document, Edition, LicenceVersion, PlatformVerification,
                            Product, Project, Release, ReleaseArtifact, Repository, Requirement, SupportIssue, User)
from foundry.storage import get_storage, read_verified

KINDS = ["quick-start", "installation", "user-guide", "administrator-guide", "api-reference", "build-instructions",
         "troubleshooting", "system-requirements", "release-notes", "third-party-notices", "support"]
PLACEHOLDER = re.compile(r"\{\{\s*([a-z_:./A-Z0-9\-]+)\s*\}\}")
PLATFORM_WORDS = {"windows": "windows-x86_64", "macos": "macos-arm64", "mac os": "macos-arm64", "linux": "linux-x86_64"}
RISKY = re.compile(r"\b(guarantee[sd]?|100% secure|fully secure|certified|unhackable|never fails|bug-free)\b", re.I)

DEFAULT_TEMPLATES: dict[str, tuple[str, str]] = {
    "quick-start": ("Quick start", """# {{product_name}} {{version}} — Quick start

{{tagline}}

1. Download `{{application_file}}` from your Code Exchange library.
2. Run it with Python {{minimum_python}} or later:

```console-test
$ csv-workshop --version
csv-workshop {{version}}
$ csv-workshop validate examples/sample.csv
OK: examples/sample.csv: 5 rows, 4 columns, no issues found.
```

See the user guide for schemas and JSON output.
"""),
    "installation": ("Installation", """# Installing {{product_name}} {{version}}

{{product_name}} is delivered as a single file, `{{application_file}}` (SHA-256 `{{application_sha256}}`).

## Install
Copy the file to any directory and run `python3 {{application_file}}`. No other packages are required.

## Upgrade
Replace the file with the newer release. There is no configuration or data to migrate.

## Uninstall
Delete the file.

## Verify your download
Compare the SHA-256 checksum of the file with the value above.
"""),
    "user-guide": ("User guide", """# {{product_name}} user guide

{{description}}

## Commands
{{repo_file:docs/REFERENCE.md}}

## What the product does
{{requirements_list}}
"""),
    "administrator-guide": ("Administrator guide", """# Administrator guide

{{product_name}} keeps no configuration, service or database. Administrators distributing it to teams should:

- place `{{application_file}}` on a shared, read-only location;
- verify the published checksum `{{application_sha256}}` before distribution;
- confirm their licence ({{licence_title}}) permits the number of users and the deployment model.

{{rights_table}}
"""),
    "api-reference": ("Command reference", """# Command reference — {{product_name}} {{version}}

{{repo_file:docs/REFERENCE.md}}
"""),
    "build-instructions": ("Building from source", """# Building {{product_name}} from source

Source revision: `{{commit}}` (build #{{build_number}}).

{{repo_file:BUILDING.md}}
"""),
    "troubleshooting": ("Troubleshooting", """# Troubleshooting

**`error: file is not valid utf-8`** — re-save the file as UTF-8.

**Columns are split incorrectly** — pass `--delimiter` explicitly, for example `--delimiter ';'`.

**Exit codes** — 0 means no issues, 1 means validation issues were found, 2 means the command could not run.
"""),
    "system-requirements": ("System requirements", """# System requirements — {{product_name}} {{version}}

- Python {{minimum_python}} or later.
- Verified platforms for this release:
{{verified_platforms}}

Platforms not listed have not been verified for this release.
"""),
    "release-notes": ("Release notes", """# {{product_name}} {{version}} — release notes

Released from commit `{{commit}}`.

{{release_notes}}

## Changes in this release
{{change_summary}}

## Fixed customer-reported issues
{{fixed_issues}}

## Compatibility
{{compatibility}}
"""),
    "third-party-notices": ("Third-party notices", """# Third-party notices

The following text is generated from the dependencies actually installed for build #{{build_number}}.

```text
{{notices}}
```
"""),
    "support": ("Support", """# Support for {{product_name}}

{{support_terms}}

- Support for version {{version}} ends on **{{end_of_support}}**.
- Support covers the documented commands on the verified platforms listed in the system requirements.
- Report problems through your Code Exchange account. Please include the command you ran and a small sample file
  without personal data.
"""),
}


# ------------------------------------------------------------------ templates
def ensure_default_templates(db: Session) -> None:
    for kind, (title, body) in DEFAULT_TEMPLATES.items():
        if not db.execute(select(DocTemplate).where(DocTemplate.kind == kind)).first():
            db.add(DocTemplate(kind=kind, version=1, title=title, body=body))


def latest_template(db: Session, kind: str) -> DocTemplate:
    t = db.execute(select(DocTemplate).where(DocTemplate.kind == kind).order_by(DocTemplate.version.desc())).scalars().first()
    if t is None:
        raise HTTPException(404, f"no template for {kind}")
    return t


def new_template_version(db: Session, kind: str, title: str, body: str, user: User) -> DocTemplate:
    cur = db.execute(select(func.max(DocTemplate.version)).where(DocTemplate.kind == kind)).scalar() or 0
    t = DocTemplate(kind=kind, version=cur + 1, title=title, body=body, created_by=user.id)
    db.add(t)
    db.flush()
    audit.record(db, user, "doc_template.versioned", "doc_template", t.id, None, kind=kind, version=t.version)
    return t


# ------------------------------------------------------------------ context
def release_context(db: Session, rel: Release) -> dict[str, str]:
    product = db.get(Product, rel.product_id)
    project = db.get(Project, rel.project_id)
    build = db.get(Build, rel.build_id)
    arts = {a.role: a for a in db.execute(select(Artifact).where(Artifact.build_id == build.id)).scalars()}
    app = arts.get("application")
    verified = []
    for p in rel.platform_claims or []:
        v = db.execute(select(PlatformVerification).where(PlatformVerification.release_id == rel.id,
                                                          PlatformVerification.platform == p,
                                                          PlatformVerification.result == "passed")).first()
        verified.append(f"  - {p}" + ("" if v else " (claimed — verification pending)"))
    reqs = db.execute(select(Requirement).where(Requirement.project_id == project.id).order_by(Requirement.key)).scalars().all()
    editions = db.execute(select(Edition).where(Edition.product_id == product.id)).scalars().all()
    lic = db.get(LicenceVersion, editions[0].licence_version_id) if editions and editions[0].licence_version_id else None
    rights = (lic.rights if lic else {}) or {}
    rights_table = "| Right | Granted |\n|---|---|\n" + "\n".join(
        f"| {k.replace('_', ' ')} | {'yes' if v is True else ('no' if v is False else v)} |" for k, v in rights.items())
    fixed = db.execute(select(SupportIssue).where(SupportIssue.fix_release_id == rel.id)).scalars().all()
    prev = db.execute(select(Release).where(Release.product_id == rel.product_id, Release.id != rel.id,
                                            Release.status.in_(["published", "superseded", "approved"]))
                      .order_by(Release.id.desc())).scalars().first()
    change = "- Initial release."
    repo = db.get(Repository, build.repository_id)
    if prev and prev.commit_sha:
        try:
            ds = adapter_for(repo).diff_summary(prev.commit_sha, build.commit_sha)
            change = "\n".join(f"- {c['subject']}" for c in ds["commits"]) or "- No source changes."
        except Exception:  # noqa: BLE001
            change = "- (change summary unavailable)"
    notices = ""
    if "notices" in arts:
        notices = read_verified(arts["notices"].storage_key, arts["notices"].sha256).decode(errors="replace")
    ctx = {
        "product_name": product.name, "tagline": product.tagline, "description": product.description,
        "version": rel.version, "commit": build.commit_sha, "build_number": str(build.number),
        "application_file": "csv-workshop.pyz" if app is None else app.filename,
        "application_sha256": app.sha256 if app else "(no application artefact)",
        "minimum_python": (rel.compatibility or {}).get("minimum_python", "3.10"),
        "verified_platforms": "\n".join(verified) or "  - (none)",
        "requirements_list": "\n".join(f"- {r.title}" for r in reqs if r.category in ("workflow", "functional", "data")),
        "licence_title": f"{lic.title} v{lic.version}" if lic else "(licence not set)",
        "rights_table": rights_table,
        "release_notes": rel.notes or "",
        "change_summary": change,
        "fixed_issues": "\n".join(f"- {i.customer_note or i.title} ({i.external_ref})" for i in fixed) or "- None.",
        "compatibility": "\n".join(f"- {k.replace('_', ' ')}: {v}" for k, v in (rel.compatibility or {}).items()),
        "notices": notices.strip() or "(notices not generated)",
        "support_terms": (editions[0].support_terms if editions else "") or "",
        "end_of_support": rel.end_of_support_on.isoformat() if rel.end_of_support_on else "{{UNSET:end_of_support}}",
    }
    ctx["_repo"] = (repo, build.commit_sha)
    return ctx


def render_template(body: str, ctx: dict) -> tuple[str, list[dict]]:
    flags: list[dict] = []
    repo, commit = ctx.get("_repo", (None, None))

    def sub(m):
        key = m.group(1)
        if key.startswith("repo_file:"):
            path = key.split(":", 1)[1]
            try:
                return adapter_for(repo).read_file(commit, path)["content"].strip()
            except Exception:  # noqa: BLE001
                flags.append({"severity": "missing", "text": f"repository file {path} not found at {commit[:10]}"})
                return f"[MISSING: {path}]"
        if key in ctx and isinstance(ctx[key], str):
            return ctx[key]
        flags.append({"severity": "missing", "text": f"no verified value for '{key}'"})
        return f"[MISSING: {key}]"
    out = PLACEHOLDER.sub(sub, body)
    for m in re.finditer(r"\{\{UNSET:([a-z_]+)\}\}", out):
        flags.append({"severity": "missing", "text": f"{m.group(1)} is not set"})
    return out, flags


def flag_unsupported(text: str, verified_platforms: list[str]) -> list[dict]:
    """Flag statements the verified project record does not support."""
    flags = []
    lower = text.lower()
    for word, plat in PLATFORM_WORDS.items():
        if word in lower and plat not in verified_platforms:
            flags.append({"severity": "unsupported", "text": f"mentions {word!r} but {plat} is not a verified platform"})
    for m in RISKY.finditer(text):
        flags.append({"severity": "unsupported", "text": f"absolute claim {m.group(0)!r} cannot be verified"})
    return flags


def verified_platforms(db: Session, rel: Release) -> list[str]:
    return [v.platform for v in db.execute(select(PlatformVerification).where(
        PlatformVerification.release_id == rel.id, PlatformVerification.result == "passed")).scalars()]


# ------------------------------------------------------------------ documents
def latest_for_release(db: Session, release_id: int, approved_only: bool) -> list[Document]:
    rows = db.execute(select(Document).where(Document.release_id == release_id)
                      .order_by(Document.kind, Document.revision.desc())).scalars().all()
    out: dict[str, Document] = {}
    for d in rows:
        if approved_only and d.status != "approved":
            continue
        out.setdefault(d.kind, d)
    return list(out.values())


def generate_for_release(db: Session, rel: Release, user: User, kinds: list[str] | None = None) -> list[Document]:
    ctx = release_context(db, rel)
    vp = verified_platforms(db, rel)
    created = []
    for kind in kinds or KINDS:
        t = latest_template(db, kind)
        body, flags = render_template(t.body, ctx)
        flags += flag_unsupported(body if kind != "third-party-notices" else "", vp)
        cur = db.execute(select(func.max(Document.revision)).where(Document.release_id == rel.id,
                                                                     Document.kind == kind)).scalar() or 0
        d = Document(project_id=rel.project_id, release_id=rel.id, kind=kind, title=t.title, revision=cur + 1,
                     body=body, template_id=t.id, status="draft", origin="template", flags=flags)
        db.add(d)
        created.append(d)
    db.flush()
    audit.record(db, user, "docs.generated", "release", rel.id, rel.project_id, kinds=[d.kind for d in created])
    return created


def edit(db: Session, doc: Document, body: str, user: User) -> Document:
    """Editing never mutates a locked or approved revision; it creates the next revision."""
    rel = db.get(Release, doc.release_id) if doc.release_id else None
    vp = verified_platforms(db, rel) if rel else []
    new = Document(project_id=doc.project_id, release_id=doc.release_id, kind=doc.kind, title=doc.title,
                   revision=doc.revision + 1, body=body, template_id=doc.template_id, status="draft", origin="human",
                   flags=flag_unsupported(body if doc.kind != "third-party-notices" else "", vp)
                   + [{"severity": "missing", "text": f"placeholder for {m} is still present"}
                      for m in re.findall(r"\[MISSING: ([^\]]+)\]", body)])
    db.add(new)
    db.flush()
    audit.record(db, user, "doc.revised", "document", new.id, doc.project_id, kind=doc.kind, revision=new.revision)
    return new


def resolve_flag(db: Session, doc: Document, index: int, note: str, user: User) -> Document:
    if doc.locked:
        raise HTTPException(409, "document is locked")
    flags = list(doc.flags or [])
    flags[index] = {**flags[index], "resolved": True, "resolution": note, "resolved_by": user.email}
    doc.flags = flags
    return doc


def submit(db: Session, doc: Document, user: User) -> Document:
    if doc.status != "draft":
        raise HTTPException(409, "only drafts can be submitted")
    doc.status = "in-review"
    doc.updated_at = utcnow()
    return doc


def approve(db: Session, doc: Document, user: User) -> Document:
    if doc.status != "in-review":
        raise HTTPException(409, "document must be in review")
    open_flags = [f for f in doc.flags or [] if not f.get("resolved")]
    if open_flags:
        raise HTTPException(409, {"message": "resolve flagged statements before approval", "flags": open_flags})
    if "```console-test" in doc.body and not doc.example_results:
        raise HTTPException(409, "executable examples have not been checked")
    if any(x.get("result") == "failed" for x in doc.example_results or []):
        raise HTTPException(409, "executable examples are failing")
    doc.status, doc.reviewed_by, doc.updated_at = "approved", user.id, utcnow()
    audit.record(db, user, "doc.approved", "document", doc.id, doc.project_id, kind=doc.kind, revision=doc.revision)
    return doc


# ------------------------------------------------------------------ output formats
PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title><style>
body{{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;max-width:46rem;margin:2rem auto;padding:0 1rem;line-height:1.6;color:#1b1a19;background:#fbf8f1}}
code,pre{{font-family:ui-monospace,"SFMono-Regular",Menlo,monospace}} pre{{background:#1d1c1f;color:#f3efe6;padding:1rem;overflow:auto;border-radius:6px}}
table{{border-collapse:collapse}} td,th{{border:1px solid #cfc8b8;padding:.3rem .6rem}} a{{color:#a3005c}}
header{{border-bottom:3px solid #c8006e;margin-bottom:1rem;font-size:.85rem;color:#57534e}}
</style></head><body><header>The Code Exchange · {product} {version} · {kind} r{rev}</header><main id="content">{body}</main></body></html>"""


def to_html(doc: Document, product: str, version: str) -> str:
    body = doc.body.replace("```console-test", "```console")
    rendered = md.markdown(body, extensions=["fenced_code", "tables"], output_format="html")
    return PAGE.format(title=html.escape(doc.title), product=html.escape(product), version=html.escape(version),
                       kind=html.escape(doc.kind), rev=doc.revision, body=rendered)


def to_pdf(doc: Document, product: str, version: str) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, Preformatted, SimpleDocTemplate, Spacer
    styles = getSampleStyleSheet()
    buf = io.BytesIO()
    pdf = SimpleDocTemplate(buf, pagesize=A4, title=doc.title, author="The Code Exchange",
                            subject=f"{product} {version}", invariant=1)
    story, code, in_code = [], [], False
    for line in doc.body.splitlines():
        if line.startswith("```"):
            if in_code:
                story.append(Preformatted("\n".join(code), styles["Code"]))
                code = []
            in_code = not in_code
            continue
        if in_code:
            code.append(line)
            continue
        esc = html.escape(line)
        esc = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", esc)
        esc = re.sub(r"`(.+?)`", r"<font face='Courier'>\1</font>", esc)
        if line.startswith("# "):
            story.append(Paragraph(esc[2:], styles["Title"]))
        elif line.startswith("## "):
            story.append(Paragraph(esc[3:], styles["Heading2"]))
        elif line.startswith(("- ", "  - ")) or re.match(r"^\d+\. ", line):
            story.append(Paragraph("• " + re.sub(r"^\s*(-|\d+\.)\s", "", esc), styles["BodyText"]))
        elif line.strip():
            story.append(Paragraph(esc, styles["BodyText"]))
        else:
            story.append(Spacer(1, 6))
    if code:
        story.append(Preformatted("\n".join(code), styles["Code"]))
    pdf.build(story)
    return buf.getvalue()


def render_artifacts(db: Session, doc: Document) -> None:
    from foundry.builder import store_artifact
    rel = db.get(Release, doc.release_id)
    product = db.get(Product, rel.product_id)
    if not doc.html_artifact_id:
        a = store_artifact(db, doc.project_id, None, "docs-html", f"{doc.kind}-{rel.version}.html",
                           to_html(doc, product.name, rel.version).encode(), "text/html", "foundry/docs")
        doc.html_artifact_id = a.id
    if not doc.pdf_artifact_id:
        a = store_artifact(db, doc.project_id, None, "docs-pdf", f"{doc.kind}-{rel.version}.pdf",
                           to_pdf(doc, product.name, rel.version), "application/pdf", "foundry/docs")
        doc.pdf_artifact_id = a.id


# ------------------------------------------------------------------ executable examples
EXAMPLE_BLOCK = re.compile(r"```console-test\n(.*?)```", re.S)


def parse_examples(body: str) -> list[dict]:
    examples = []
    for block in EXAMPLE_BLOCK.findall(body):
        cur = None
        for line in block.splitlines():
            if line.startswith("$ "):
                cur = {"command": line[2:].strip(), "expected": []}
                examples.append(cur)
            elif cur is not None and line.strip():
                cur["expected"].append(line.rstrip())
    return examples


def request_example_check(db: Session, doc: Document, user: User):
    if doc.locked:
        raise HTTPException(409, "document is locked")
    job = jobs.enqueue(db, "docs.check_examples", {"document_id": doc.id}, max_attempts=2)
    audit.record(db, user, "doc.examples_requested", "document", doc.id, doc.project_id, job=job.id)
    return job


@jobs.handler("docs.check_examples")
def _check_examples(_db: Session, job) -> dict:
    from foundry.sandbox import get_sandbox
    with session_scope() as db:
        doc = db.get(Document, job.payload["document_id"])
        rel = db.get(Release, doc.release_id)
        build = db.get(Build, rel.build_id)
        repo = db.get(Repository, build.repository_id)
        app = db.execute(select(Artifact).where(Artifact.build_id == build.id, Artifact.role == "application")).scalars().first()
        examples = parse_examples(doc.body)
        app_bytes = read_verified(app.storage_key, app.sha256)
        commit, body_kind = build.commit_sha, doc.kind
    work = config.settings.work_root.resolve() / f"docs-{job.id}-{uuid.uuid4().hex[:6]}"
    ws = work / "ws"
    ws.mkdir(parents=True)
    results = []
    try:
        adapter_for(repo).archive_to(commit, ws)
        (ws / "csv-workshop.pyz").write_bytes(app_bytes)
        sandbox = get_sandbox()
        sandbox.prepare(ws)
        for i, ex in enumerate(examples):
            cmd = re.sub(r"^csv-workshop\b", "python3 -I csv-workshop.pyz", ex["command"])
            log = work / f"ex{i}.log"
            r = sandbox.run(cmd, ws, log, timeout_s=60)
            output = log.read_text(errors="replace") if log.exists() else ""
            missing = [e for e in ex["expected"] if e.strip() != "..." and e.strip() not in output]
            results.append({"command": ex["command"], "exit_code": r.exit_code,
                            "result": "passed" if not missing and r.status == "passed" else "failed",
                            "missing_output": missing, "output": output[-1500:]})
    finally:
        shutil.rmtree(work, ignore_errors=True)
    with session_scope() as db:
        doc = db.get(Document, job.payload["document_id"])
        doc.example_results = results
        audit.record(db, None, "doc.examples_checked", "document", doc.id, doc.project_id,
                     passed=sum(r["result"] == "passed" for r in results), total=len(results), kind=body_kind)
    return {"examples": len(results)}
