"""Product Foundry API server (FastAPI). Build execution never happens in this process."""
from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text

from foundry import catalogue, docs, support, builder  # noqa: F401  (register job handlers for enqueue-only use)
from foundry.api import commerce, core, engineering, projects, release
from foundry.db import get_engine
from foundry.releases import ImmutableError
from foundry.storage import IntegrityError

API_PREFIX = "/api/v1"

app = FastAPI(title="The Code Exchange — Product Foundry API", version="1.0.0",
              description="Internal API for turning source-code projects into tested, documented, licensed, "
                          "packaged products. Versioned under /api/v1.",
              docs_url="/api/docs", openapi_url="/api/openapi.json")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
                   allow_methods=["*"], allow_headers=["*"], allow_credentials=False)

for r in (core.router, projects.router, engineering.router, release.router, commerce.router):
    app.include_router(r, prefix=API_PREFIX)


@app.exception_handler(ImmutableError)
async def immutable(_: Request, exc: ImmutableError):
    return JSONResponse({"detail": f"immutable: {exc}"}, status_code=409)


@app.exception_handler(IntegrityError)
async def integrity(_: Request, exc: IntegrityError):
    return JSONResponse({"detail": f"artefact integrity: {exc}"}, status_code=500)


@app.get("/health")
def health():
    with get_engine().connect() as c:
        c.execute(text("select 1"))
    return {"status": "ok", "api": API_PREFIX}
