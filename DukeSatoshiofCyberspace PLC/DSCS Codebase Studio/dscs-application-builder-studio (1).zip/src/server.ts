import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { exec, execSync } from 'node:child_process';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');
const app = express();
const angularApp = new AngularNodeAppEngine();

// Parse JSON bodies
app.use(express.json({ limit: '10mb' }));

// Initialize GoogleGenAI server-side with telemetry User-Agent header lazily
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env['GEMINI_API_KEY'];
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Toolchain discovery endpoint
app.get('/api/toolchains', (_req, res) => {
  const checkTool = (cmd: string): { installed: boolean; version?: string } => {
    try {
      const output = execSync(cmd, { encoding: 'utf-8', timeout: 3000 }).trim();
      return { installed: true, version: output.split('\n')[0] };
    } catch {
      return { installed: false };
    }
  };

  const toolchains = {
    node: checkTool('node --version'),
    npm: checkTool('npm --version'),
    git: checkTool('git --version'),
    rustc: checkTool('rustc --version'),
    cargo: checkTool('cargo --version'),
    python3: checkTool('python3 --version'),
    r: checkTool('R --version | head -n 1'),
    docker: checkTool('docker --version'),
    make: checkTool('make --version | head -n 1'),
    gcc: checkTool('gcc --version | head -n 1'),
  };

  res.json({
    status: 'ok',
    system: {
      platform: process.platform,
      arch: process.arch,
      nodeVersion: process.version,
      uptime: process.uptime(),
    },
    toolchains,
  });
});

// Workspace command execution endpoint
app.post('/api/terminal/exec', (req, res) => {
  const { command, cwd } = req.body;
  if (!command || typeof command !== 'string') {
    res.status(400).json({ error: 'Command string is required.' });
    return;
  }

  // Security check: block dangerous root-level destruction
  const blockedPatterns = [
    /rm\s+-rf\s+\/($|\s)/,
    /mkfs/,
    />\s*\/dev\/sd/,
    /dd\s+if=.*of=\/dev/,
    /:(){ :\|:& };:/,
  ];

  if (blockedPatterns.some((pattern) => pattern.test(command))) {
    res.status(403).json({
      stdout: '',
      stderr: 'DSCS Security Violation: Destructive command rejected by host policy.',
      exitCode: 126,
      durationMs: 0,
    });
    return;
  }

  const startTime = Date.now();
  const workDir = cwd || process.cwd();

  exec(
    command,
    {
      cwd: workDir,
      timeout: 30000,
      maxBuffer: 2 * 1024 * 1024,
      env: {
        ...process.env,
        PAGER: 'cat',
        CI: 'true',
        TERM: 'xterm-256color',
      },
    },
    (error, stdout, stderr) => {
      const durationMs = Date.now() - startTime;
      const exitCode = error ? (error.code ?? 1) : 0;
      res.json({
        stdout: stdout || '',
        stderr: stderr || (error ? error.message : ''),
        exitCode,
        durationMs,
      });
    },
  );
});

// Product Architect AI endpoint
app.post('/api/ai/architect', async (req, res) => {
  const { prompt, currentSpec } = req.body;
  if (!prompt) {
    res.status(400).json({ error: 'Prompt is required' });
    return;
  }

  const ai = getGeminiClient();
  if (!ai) {
    // Deterministic fallback response when no API key is provided
    res.json({
      status: 'fallback',
      message: 'Generated using DSCS Local Deterministic Architect Engine (offline mode).',
      specification: createFallbackSpecification(prompt),
    });
    return;
  }

  try {
    const systemPrompt = `You are the Lead Systems Architect at Duke Satoshi Cyberspace (DSCS).
Your task is to transform a natural language product prompt into an authoritative, complete JSON specification.
Return ONLY valid JSON matching this schema without markdown codeblocks:
{
  "productName": "string",
  "purpose": "string",
  "targetAudience": "string",
  "supportedPlatforms": ["Web", "Desktop (Linux)", "Android"],
  "primaryWorkflows": [{"id": "wf-1", "name": "string", "description": "string", "steps": ["step 1", "step 2"]}],
  "userRoles": [{"id": "role-1", "role": "Customer", "permissions": ["browse", "checkout"]}],
  "screens": [{"id": "scr-1", "title": "Storefront", "route": "/", "purpose": "Catalog view"}],
  "features": [{"id": "feat-1", "title": "string", "category": "Core", "description": "string", "priority": "must-have"}],
  "dataEntities": [{"id": "ent-1", "name": "Product", "description": "Catalog item", "fields": [{"name": "id", "type": "string", "required": true, "primaryKey": true}]}],
  "apiRequirements": [{"id": "api-1", "path": "/api/v1/resource", "method": "GET", "description": "Fetch resources", "authRequired": false}],
  "authModel": {"provider": "Session / JWT", "roles": ["Customer", "Admin"], "tokenType": "Bearer", "sessionExpiry": "7d"},
  "performanceRequirements": ["P99 latency < 150ms", "Cold start < 1.2s"],
  "securityRequirements": ["CSRF tokens", "RBAC authorization", "SQL injection mitigation"],
  "accessibilityRequirements": ["WCAG 2.1 AA compliance", "Keyboard navigation"],
  "designDirection": {"theme": "Graphite Dark", "primaryColor": "Emerald / Steel Blue", "typography": "Plus Jakarta Sans & JetBrains Mono", "density": "High density"},
  "acceptanceCriteria": [{"id": "ac-1", "description": "Users can complete primary flow end-to-end", "verified": true}],
  "deploymentTargets": ["Static Web", "Linux Native Binary", "Docker Container"],
  "unresolvedDecisions": [{"id": "dec-1", "question": "Should payments support offline cache?", "defaultOption": "No, live verification required", "status": "resolved", "chosenOption": "No, live verification required"}]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Create the complete DSCS engineering specification for this request: "${prompt}".
${currentSpec ? `Incorporate or evolve existing spec: ${JSON.stringify(currentSpec)}` : ''}`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    const spec = JSON.parse(text);
    res.json({
      status: 'ok',
      specification: spec,
    });
  } catch (error: unknown) {
    const err = error as { message?: string };
    console.error('Gemini Architect Error:', err);
    res.json({
      status: 'fallback',
      message: `Gemini API fallback engaged (${err.message || 'Error'}). Used local architecture rules.`,
      specification: createFallbackSpecification(prompt),
    });
  }
});

// AI Code Generation endpoint
app.post('/api/ai/generate', async (req, res) => {
  const { prompt, projectContext, targetFile } = req.body;
  const ai = getGeminiClient();

  if (!ai) {
    res.json({
      status: 'fallback',
      code: `// Generated deterministically by DSCS Engine for: ${prompt}\nexport const generatedFeature = {\n  status: 'active',\n  timestamp: new Date().toISOString(),\n  description: '${prompt.replace(/'/g, "\\'")}'\n};\n`,
    });
    return;
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Generate clean, production-grade source code for target file "${targetFile || 'generated.ts'}".
User request: ${prompt}
Project Context: ${projectContext ? JSON.stringify(projectContext) : 'Standard TypeScript/Modern Stack'}.
Return ONLY the raw code for the file without markdown backticks or commentary.`,
    });

    let code = response.text || '';
    if (code.startsWith('```')) {
      code = code.replace(/^```[a-zA-Z]*\n/, '').replace(/```$/, '');
    }

    res.json({ status: 'ok', code });
  } catch (error: unknown) {
    console.error('AI Generate Error:', error);
    res.json({
      status: 'fallback',
      code: `// Fallback code generated for: ${prompt}\nexport const fallback = true;`,
    });
  }
});

// AI Failure Diagnosis & Repair endpoint
app.post('/api/ai/repair', async (req, res) => {
  const { testError, sourceCode, filePath } = req.body;
  const ai = getGeminiClient();

  if (!ai) {
    res.json({
      status: 'fallback',
      diagnosis: 'Failure diagnosed: Assertion mismatch or missing null check.',
      explanation: 'Identified syntax or logic discrepancy in test suite execution.',
      suggestedPatch: `// Proposed DSCS patch for ${filePath || 'source'}\n// Ensure defensive null guards and boundary checks`,
    });
    return;
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Diagnose the following test failure and propose an exact repair patch.
File: ${filePath}
Error Output:
${testError}

Current Source:
${sourceCode}

Respond in JSON matching:
{
  "diagnosis": "concise root cause",
  "explanation": "detailed architectural rationale",
  "suggestedPatch": "repaired source code"
}`,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json({ status: 'ok', ...parsed });
  } catch (error: unknown) {
    console.error('AI Repair Error:', error);
    res.json({
      status: 'fallback',
      diagnosis: 'Type check or runtime assertion failed.',
      explanation: 'Resolved by applying strict boundary validations and null coalescing.',
      suggestedPatch: sourceCode || '// Verified clean code',
    });
  }
});

// Mock demonstration e-commerce store backend for interactive live preview
const demoStore = {
  products: [
    {
      id: 'prod-001',
      name: 'Titanium Edge Workstation Key',
      category: 'Security Hardware',
      price: 249.0,
      stock: 38,
      rating: 4.9,
      badge: 'Bestseller',
      description: 'Zero-trust cryptographic physical hardware token with dual FIDO2/U2F interface.',
      specs: 'ARM Cortex-M4 · IP68 Certified · 256-bit AES Hardware Cryptoprocessor',
    },
    {
      id: 'prod-002',
      name: 'DSCS Quantum Shielded Enclosure',
      category: 'Systems Enclosure',
      price: 680.0,
      stock: 14,
      rating: 4.8,
      badge: 'Industrial',
      description: 'Milled aluminum desktop chassis with EMI/RF attenuation for sensitive systems.',
      specs: '6061-T6 Aerospace Aluminum · Passive Thermal Radiator · 10Gbps SFP+ Pass-through',
    },
    {
      id: 'prod-003',
      name: 'High-Density NVMe Expansion Blade',
      category: 'Storage',
      price: 430.0,
      stock: 52,
      rating: 5.0,
      badge: 'High Throughput',
      description: 'PCIe 5.0 quad M.2 carrier card with active thermal copper vapor chamber.',
      specs: 'Up to 28,000 MB/s sequential read · Bifurcation x16 · Smart telemetry LED',
    },
    {
      id: 'prod-004',
      name: 'Low-Noise Linear Precision PSU',
      category: 'Power Systems',
      price: 310.0,
      stock: 22,
      rating: 4.7,
      badge: 'Precision',
      description: 'Clean DC supply with ripple under 1.5mV for precision data-acquisition devices.',
      specs: 'Triple isolated rails 12V/5V/3.3V · Overvoltage OVP/OCP/SCP · Gold terminals',
    },
    {
      id: 'prod-005',
      name: 'Satoshi Stream Micro-Controller Node',
      category: 'Compute Modules',
      price: 185.0,
      stock: 90,
      rating: 4.9,
      badge: 'Edge Node',
      description: 'Dual-core RISC-V edge computing unit running bare-metal Rust firmware.',
      specs: '64-bit RV64GC · 512MB ECC RAM · Dual Gigabit Ethernet · CAN-FD Bus',
    },
    {
      id: 'prod-006',
      name: 'Fiber Optic Isolation Link',
      category: 'Networking',
      price: 120.0,
      stock: 64,
      rating: 4.6,
      badge: 'Galvanic Safe',
      description: 'Complete optical galvanic isolation for hostile industrial ground loop rejection.',
      specs: 'Single-mode LC 1310nm · 20km range · < 2ns jitter · Industrial DIN Rail',
    },
  ],
  orders: [
    {
      id: 'ORD-8921',
      customer: 'Astra Dynamics Lab',
      email: 'procurement@astradyn.io',
      itemsCount: 3,
      total: 988.0,
      status: 'Shipped',
      date: '2026-10-27 14:22',
      items: ['Titanium Edge Workstation Key (2)', 'DSCS Quantum Shielded Enclosure (1)'],
    },
    {
      id: 'ORD-8920',
      customer: 'Helios Research Institute',
      email: 'dr.vogel@helios.edu',
      itemsCount: 4,
      total: 1285.0,
      status: 'Processing',
      date: '2026-10-27 11:05',
      items: ['High-Density NVMe Expansion Blade (2)', 'Low-Noise Linear Precision PSU (1)', 'Fiber Optic Isolation Link (1)'],
    },
    {
      id: 'ORD-8919',
      customer: 'Vanguard Cybernetics',
      email: 'ops@vanguardcyber.net',
      itemsCount: 5,
      total: 925.0,
      status: 'Delivered',
      date: '2026-10-26 18:40',
      items: ['Satoshi Stream Micro-Controller Node (5)'],
    },
  ],
};

app.get('/api/demo/products', (_req, res) => {
  res.json({ products: demoStore.products });
});

interface DemoCheckoutItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

app.post('/api/demo/checkout', (req, res) => {
  const { items, customerName, email, shippingAddress } = req.body as {
    items?: DemoCheckoutItem[];
    customerName?: string;
    email?: string;
    shippingAddress?: string;
  };

  if (!items || !items.length) {
    res.status(400).json({ error: 'Cart is empty' });
    return;
  }

  const orderId = `ORD-${Math.floor(1000 + Math.random() * 9000)}`;
  const total = items.reduce((acc: number, item: DemoCheckoutItem) => acc + (item.price * item.quantity), 0);
  
  const newOrder = {
    id: orderId,
    customer: customerName || 'Verified Guest',
    email: email || 'guest@dscs.local',
    shippingAddress: shippingAddress || 'Sector 7 Aerospace Park',
    itemsCount: items.reduce((acc: number, item: DemoCheckoutItem) => acc + item.quantity, 0),
    total,
    status: 'Processing',
    date: new Date().toISOString().replace('T', ' ').substring(0, 16),
    items: items.map((i: DemoCheckoutItem) => `${i.name} (${i.quantity})`),
  };

  demoStore.orders.unshift(newOrder);

  // Decrement stock
  for (const item of items) {
    const p = demoStore.products.find((prod) => prod.id === item.id);
    if (p) {
      p.stock = Math.max(0, p.stock - item.quantity);
    }
  }

  res.json({
    status: 'success',
    orderId,
    total,
    receiptNumber: `DSCS-TXN-${Date.now().toString(36).toUpperCase()}`,
    order: newOrder,
  });
});

app.get('/api/demo/orders', (_req, res) => {
  res.json({ orders: demoStore.orders });
});

// Deterministic specification generator fallback
function createFallbackSpecification(prompt: string) {
  const isRust = /rust|systems|memory|stream/i.test(prompt);
  const isR = /statistical|analytics|forecast|regression/i.test(prompt);
  const isAndroid = /android|mobile|apk/i.test(prompt);

  const name = prompt.split(' ')[0] ? `${prompt.split(' ')[0]} Studio` : 'DSCS Engineering Project';

  return {
    productName: name,
    purpose: `Engineered implementation for: ${prompt}`,
    targetAudience: 'Software Engineers, Systems Architects, and Technical Stakeholders',
    supportedPlatforms: isAndroid
      ? ['Android 14+ (ARM64)', 'Linux (Debian/Ubuntu)']
      : isRust
        ? ['Linux Native (ELF x86_64)', 'macOS (Darwin)', 'Windows (x86_64)']
        : isR
          ? ['R Environment 4.3+', 'Linux Server', 'Shiny Runtime']
          : ['Web Application (Modern Browsers)', 'Linux Desktop (Tauri)', 'Docker Container'],
    primaryWorkflows: [
      {
        id: 'wf-1',
        name: 'Initialization and Authentication',
        description: 'Establish workspace session and verify authorization boundaries.',
        steps: ['Validate environment profile', 'Authenticate identity credentials', 'Load operational context'],
      },
      {
        id: 'wf-2',
        name: 'Primary Processing Pipeline',
        description: 'Execute core operational data transactions with full audit logging.',
        steps: ['Ingest input vector', 'Run invariant validation', 'Persist mutation', 'Publish telemetry event'],
      },
      {
        id: 'wf-3',
        name: 'Reporting and Verification',
        description: 'Inspect execution diagnostics and generate verified audit certificates.',
        steps: ['Aggregate metrics', 'Evaluate acceptance criteria', 'Export signed manifest'],
      },
    ],
    userRoles: [
      { id: 'role-admin', role: 'System Administrator', permissions: ['manage:system', 'deploy:release', 'audit:logs'] },
      { id: 'role-operator', role: 'Staff Operator', permissions: ['read:catalog', 'write:orders', 'execute:jobs'] },
      { id: 'role-auditor', role: 'Compliance Auditor', permissions: ['read:audit', 'read:metrics', 'export:traceability'] },
    ],
    screens: [
      { id: 'scr-main', title: 'Operational Overview', route: '/', purpose: 'Primary monitoring and interactive interface' },
      { id: 'scr-catalog', title: 'Catalog & Inventory', route: '/catalog', purpose: 'Item inspection, search, and parameter configuration' },
      { id: 'scr-analytics', title: 'System Diagnostics', route: '/diagnostics', purpose: 'Throughput metrics and audit ledger' },
      { id: 'scr-admin', title: 'Administration Panel', route: '/admin', purpose: 'Access control and release management' },
    ],
    features: [
      { id: 'feat-1', title: 'High-Throughput State Engine', category: 'Core Engine', description: 'Deterministic state machine with transactional consistency.', priority: 'must-have' },
      { id: 'feat-2', title: 'Full-Stack REST & IPC Interface', category: 'Connectivity', description: 'Type-safe contracts for inter-process and external API communication.', priority: 'must-have' },
      { id: 'feat-3', title: 'Automated Diagnostic Prober', category: 'Verification', description: 'Self-healing health checks and latency monitoring.', priority: 'should-have' },
      { id: 'feat-4', title: 'Multi-Target Package Compiler', category: 'DevOps', description: 'Reproducible builds with SHA-256 integrity verification.', priority: 'must-have' },
    ],
    dataEntities: [
      {
        id: 'ent-1',
        name: 'SystemEntity',
        description: 'Primary domain record with version control.',
        fields: [
          { name: 'id', type: 'UUID', required: true, primaryKey: true, description: 'Immutable unique identifier' },
          { name: 'name', type: 'VARCHAR(255)', required: true, description: 'Human-readable designation' },
          { name: 'state', type: 'ENUM', required: true, description: 'Current operational lifecycle stage' },
          { name: 'created_at', type: 'TIMESTAMPTZ', required: true, description: 'Creation timestamp' },
          { name: 'checksum', type: 'CHAR(64)', required: true, description: 'Cryptographic data integrity hash' },
        ],
      },
      {
        id: 'ent-2',
        name: 'AuditLog',
        description: 'Append-only event journal.',
        fields: [
          { name: 'log_id', type: 'BIGINT', required: true, primaryKey: true, description: 'Sequential record ID' },
          { name: 'actor_id', type: 'VARCHAR(64)', required: true, description: 'Originating identity' },
          { name: 'action', type: 'VARCHAR(128)', required: true, description: 'Operation executed' },
          { name: 'timestamp', type: 'TIMESTAMPTZ', required: true, description: 'Execution moment' },
        ],
      },
    ],
    apiRequirements: [
      { id: 'api-1', path: '/api/v1/entities', method: 'GET', description: 'Paginated query of active entities', authRequired: true },
      { id: 'api-2', path: '/api/v1/entities', method: 'POST', description: 'Create and validate new entity', authRequired: true },
      { id: 'api-3', path: '/api/v1/health', method: 'GET', description: 'Readiness and liveness probe', authRequired: false },
    ],
    authModel: {
      provider: 'DSCS Zero-Trust JWT & Session Guardian',
      roles: ['Administrator', 'Operator', 'Auditor'],
      tokenType: 'Bearer Ed25519-Signed',
      sessionExpiry: '8 Hours (Automatic Renewal on Activity)',
    },
    performanceRequirements: [
      'P99 API Latency < 65ms on local loopback',
      'Memory footprint < 128MB baseline',
      'Zero unhandled thread panics across 10,000 synthetic transactions',
    ],
    securityRequirements: [
      'Strict input sanitization against SQLi, XSS, and path traversal',
      'Non-root container execution profile',
      'Constant-time cryptographic key comparison',
    ],
    accessibilityRequirements: [
      'WCAG 2.1 AA compliant color contrast (> 4.5:1 text, > 3:1 graphical)',
      'Complete keyboard tab index traversal',
      'Explicit ARIA live regions for asynchronous status notifications',
    ],
    designDirection: {
      theme: 'DSCS Graphite & Near-Black Engineering Workstation',
      primaryColor: 'Muted Steel Blue (#3b82f6) & Amber Warning (#d97706)',
      typography: 'Plus Jakarta Sans (Interface) & JetBrains Mono (Telemetry/Code)',
      density: 'High-density tabular layout with 36px data rows',
    },
    acceptanceCriteria: [
      { id: 'ac-1', description: 'End-to-end data processing workflow executes without error', verified: true, testId: 'e2e-01' },
      { id: 'ac-2', description: 'Database migrations apply idempotently to fresh SQLite/Postgres instances', verified: true, testId: 'db-01' },
      { id: 'ac-3', description: 'Type checking and linting pass with zero fatal diagnostics', verified: true, testId: 'lint-01' },
      { id: 'ac-4', description: 'Packaging engine outputs verifiable release binary with valid checksum', verified: true, testId: 'rel-01' },
    ],
    deploymentTargets: [
      'Linux Native Binary (x86_64 / aarch64)',
      'Web Application Bundle (Static / SSR)',
      'OCI Container Image (Docker / Podman)',
    ],
    unresolvedDecisions: [
      {
        id: 'dec-1',
        question: 'Should the persistence engine use SQLite for local storage or require PostgreSQL?',
        defaultOption: 'SQLite default with optional PostgreSQL connection string adapter',
        status: 'resolved',
        chosenOption: 'SQLite default with optional PostgreSQL connection string adapter',
      },
    ],
  };
}

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`DSCS Studio Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
