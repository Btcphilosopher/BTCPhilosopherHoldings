export type StudioEnvironment =
  | 'architect'
  | 'designer'
  | 'codegen'
  | 'workbench'
  | 'runtime'
  | 'quality'
  | 'release';

export type ProjectType =
  | 'fullstack-web'
  | 'web-app'
  | 'rust-systems'
  | 'r-analytics'
  | 'android-kotlin'
  | 'desktop-tauri'
  | 'python-service';

export interface WorkflowStep {
  id: string;
  name: string;
  description: string;
  steps: string[];
}

export interface UserRole {
  id: string;
  role: string;
  permissions: string[];
}

export interface ScreenSpec {
  id: string;
  title: string;
  route: string;
  purpose: string;
}

export interface FeatureSpec {
  id: string;
  title: string;
  category: string;
  description: string;
  priority: 'must-have' | 'should-have' | 'optional';
}

export interface DataField {
  name: string;
  type: string;
  required: boolean;
  primaryKey?: boolean;
  description?: string;
}

export interface DataEntity {
  id: string;
  name: string;
  description: string;
  fields: DataField[];
}

export interface ApiRequirement {
  id: string;
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  description: string;
  authRequired: boolean;
  requestBody?: string;
  responseBody?: string;
}

export interface AcceptanceCriterion {
  id: string;
  description: string;
  verified: boolean;
  testId?: string;
}

export interface UnresolvedDecision {
  id: string;
  question: string;
  defaultOption: string;
  status: 'open' | 'resolved';
  chosenOption?: string;
}

export interface ProjectSpecification {
  productName: string;
  purpose: string;
  targetAudience: string;
  supportedPlatforms: string[];
  primaryWorkflows: WorkflowStep[];
  userRoles: UserRole[];
  screens: ScreenSpec[];
  features: FeatureSpec[];
  dataEntities: DataEntity[];
  apiRequirements: ApiRequirement[];
  authModel: {
    provider: string;
    roles: string[];
    tokenType: string;
    sessionExpiry: string;
  };
  performanceRequirements: string[];
  securityRequirements: string[];
  accessibilityRequirements: string[];
  designDirection: {
    theme: string;
    primaryColor: string;
    typography: string;
    density: string;
  };
  acceptanceCriteria: AcceptanceCriterion[];
  deploymentTargets: string[];
  unresolvedDecisions: UnresolvedDecision[];
}

export interface ArchitectureModule {
  id: string;
  name: string;
  path: string;
  layer: 'presentation' | 'domain' | 'infrastructure' | 'persistence' | 'api';
  status: 'implemented' | 'planned' | 'optional';
  dependencies: string[];
}

export interface DatabaseTable {
  name: string;
  columns: { name: string; type: string; constraints: string[] }[];
  foreignKeys: { from: string; to: string }[];
}

export interface ProjectArchitecture {
  moduleBoundaries: ArchitectureModule[];
  databaseSchema: {
    name: string;
    dialect: 'sqlite' | 'postgres';
    tables: DatabaseTable[];
  };
  apiContract: {
    openApiVersion: string;
    endpoints: {
      path: string;
      method: string;
      summary: string;
      tags: string[];
    }[];
  };
  buildStrategy: {
    toolchain: string;
    buildCommand: string;
    testCommand: string;
    packageCommand: string;
    artifactPath: string;
  };
}

export interface DesignerComponent {
  id: string;
  type:
    | 'navbar'
    | 'hero'
    | 'search-bar'
    | 'catalog-grid'
    | 'product-card'
    | 'cart-drawer'
    | 'checkout-form'
    | 'admin-stats'
    | 'orders-table'
    | 'button'
    | 'input'
    | 'data-table';
  name: string;
  label: string;
  screenId: string;
  props: Record<string, string | number | boolean | string[] | Record<string, unknown>>;
  children?: string[];
}

export interface DesignerScreen {
  id: string;
  name: string;
  route: string;
  componentIds: string[];
  breakpoint: 'desktop' | 'tablet' | 'mobile';
}

export interface ProjectFileNode {
  path: string;
  name: string;
  type: 'file' | 'directory';
  children?: ProjectFileNode[];
  content?: string;
  language?: string;
  isModified?: boolean;
}

export interface AgentTask {
  id: string;
  role: 'architect' | 'frontend' | 'backend' | 'data' | 'testing' | 'review' | 'release';
  goal: string;
  status: 'queued' | 'running' | 'completed' | 'failed' | 'requires-approval';
  allowedFiles: string[];
  diffs?: { filePath: string; oldContent: string; newContent: string }[];
  progressPercent: number;
  outputLog?: string;
  createdAt: string;
}

export interface RuntimeProfile {
  status: 'stopped' | 'starting' | 'running' | 'error';
  port: number;
  healthUrl: string;
  isHealthy: boolean;
  logs: { timestamp: string; level: 'info' | 'warn' | 'error'; message: string }[];
  uptimeSeconds: number;
  metrics: { cpuPercent: number; memoryMb: number; requestsCount: number };
}

export interface TestResultItem {
  id: string;
  name: string;
  suite: string;
  status: 'passed' | 'failed' | 'skipped';
  durationMs: number;
  errorMessage?: string;
  stackTrace?: string;
  requirementId?: string;
}

export interface TraceabilityItem {
  requirementId: string;
  requirementTitle: string;
  implementationModule: string;
  verificationTest: string;
  status: 'verified' | 'unverified' | 'failed';
}

export interface ReleaseArtifact {
  id: string;
  target: 'linux-binary' | 'web-bundle' | 'android-apk' | 'docker-container' | 'cargo-crate' | 'r-package';
  name: string;
  version: string;
  profile: 'debug' | 'release';
  sizeBytes: number;
  sha256: string;
  createdAt: string;
  downloadUrl?: string;
  ready: boolean;
}

export interface Project {
  id: string;
  name: string;
  slug: string;
  type: ProjectType;
  description: string;
  specification: ProjectSpecification;
  architecture: ProjectArchitecture;
  screens: DesignerScreen[];
  components: DesignerComponent[];
  files: ProjectFileNode[];
  activeFilePath: string;
  runtimeProfile: RuntimeProfile;
  agentTasks: AgentTask[];
  testResults: TestResultItem[];
  traceabilityMatrix: TraceabilityItem[];
  releaseArtifacts: ReleaseArtifact[];
  git: {
    currentBranch: string;
    branches: string[];
    modifiedCount: number;
    stagedCount: number;
    commits: { id: string; message: string; author: string; date: string }[];
  };
  created: string;
  updated: string;
}

export interface ToolchainStatus {
  installed: boolean;
  version?: string;
}

export interface ToolchainMap {
  node: ToolchainStatus;
  npm: ToolchainStatus;
  git: ToolchainStatus;
  rustc: ToolchainStatus;
  cargo: ToolchainStatus;
  python3: ToolchainStatus;
  r: ToolchainStatus;
  docker: ToolchainStatus;
  make: ToolchainStatus;
  gcc: ToolchainStatus;
}
