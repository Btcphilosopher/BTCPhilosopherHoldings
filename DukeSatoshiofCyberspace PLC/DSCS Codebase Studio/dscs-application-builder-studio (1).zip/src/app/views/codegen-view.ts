import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { StudioService } from '../services/studio.service';
import { MatIconModule } from '@angular/material/icon';
import { AgentTask } from '../models/studio.models';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { UpperCasePipe } from '@angular/common';

@Component({
  selector: 'app-codegen-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, ReactiveFormsModule, UpperCasePipe],
  template: `
    <div class="h-full flex flex-col bg-neutral-950 text-neutral-100 font-sans overflow-hidden">
      <!-- Header Toolbar -->
      <div class="px-6 py-4 border-b border-neutral-800 bg-neutral-900/40 flex items-center justify-between gap-4 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono uppercase tracking-wider text-blue-400 font-semibold">Environment C</span>
            <span class="text-xs text-neutral-500">·</span>
            <h1 class="text-base font-bold text-white tracking-tight">Code Generation Engine</h1>
          </div>
          <div class="text-xs text-neutral-400 mt-0.5">
            Role-specialized AI engineering agents with reviewable diffs, atomic writes, and safety gates.
          </div>
        </div>

        <div class="flex items-center gap-2 text-xs font-mono text-neutral-500">
          <span>Active Context:</span>
          <span class="text-neutral-300 font-medium">{{ studio.activeProject().name }}</span>
        </div>
      </div>

      <!-- Main Generation Workspace: 2 Column Layout -->
      <div class="flex-1 flex overflow-hidden">
        <!-- Left: Agent Dispatcher & Roles -->
        <div class="w-96 border-r border-neutral-800 bg-neutral-950 p-5 flex flex-col justify-between shrink-0 overflow-y-auto space-y-6">
          <div class="space-y-5">
            <div>
              <div class="text-[10px] font-mono text-neutral-500 uppercase tracking-wider mb-2">1. Select Specialized Agent Role</div>
              <div class="grid grid-cols-2 gap-2 text-xs">
                @for (role of agentRoles; track role.id) {
                  <button
                    type="button"
                    (click)="selectedRole.set(role.id)"
                    [class]="selectedRole() === role.id ? 'p-2.5 rounded-lg bg-blue-950/40 border border-blue-500/50 text-left transition' : 'p-2.5 rounded-lg bg-neutral-900/60 border border-neutral-800 text-left hover:border-neutral-700 transition text-neutral-400'"
                  >
                    <div class="flex items-center gap-1.5 font-semibold" [class]="selectedRole() === role.id ? 'text-blue-300' : 'text-neutral-200'">
                      <mat-icon class="text-sm">{{ role.icon }}</mat-icon>
                      <span>{{ role.name }}</span>
                    </div>
                    <div class="text-[10px] text-neutral-500 mt-1 line-clamp-2 leading-tight">{{ role.desc }}</div>
                  </button>
                }
              </div>
            </div>

            <!-- Task Goal Input -->
            <div class="space-y-2">
              <div class="text-[10px] font-mono text-neutral-500 uppercase tracking-wider">2. Define Engineering Goal</div>
              <textarea
                [formControl]="goalControl"
                rows="4"
                placeholder="Specify precise feature, refactoring, or bug repair..."
                class="w-full p-3 bg-neutral-900 border border-neutral-800 rounded-lg text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-blue-500 font-sans leading-relaxed resize-none"
              ></textarea>

              <!-- Quick Presets -->
              <div class="space-y-1.5">
                <div class="text-[10px] text-neutral-500 font-mono">Quick Task Presets:</div>
                <div class="flex flex-wrap gap-1.5">
                  @for (preset of presets; track preset) {
                    <button
                      type="button"
                      (click)="goalControl.setValue(preset)"
                      class="text-[11px] px-2 py-1 bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 rounded text-neutral-400 hover:text-neutral-200 text-left truncate max-w-full"
                    >
                      {{ preset }}
                    </button>
                  }
                </div>
              </div>
            </div>
          </div>

          <!-- Dispatch Button -->
          <div class="pt-4 border-t border-neutral-800">
            <button
              type="button"
              (click)="dispatchTask()"
              [disabled]="!goalControl.value.trim()"
              class="w-full py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow transition disabled:opacity-50"
            >
              <mat-icon class="text-sm">bolt</mat-icon>
              <span>Dispatch Agent [{{ selectedRole() | uppercase }}]</span>
            </button>
          </div>
        </div>

        <!-- Right: Task Queue & Reviewable Diffs -->
        <div class="flex-1 overflow-y-auto p-6 space-y-6">
          <div class="flex items-center justify-between">
            <div>
              <h2 class="text-sm font-bold text-white uppercase tracking-wider font-mono">Agent Task Queue & Diffs</h2>
              <div class="text-xs text-neutral-400 mt-0.5">Traceable code mutations requiring explicit engineer sign-off</div>
            </div>

            <div class="text-xs font-mono text-neutral-500">
              {{ studio.activeProject().agentTasks.length }} tasks logged
            </div>
          </div>

          <!-- Tasks List -->
          <div class="space-y-4">
            @for (task of studio.activeProject().agentTasks; track task.id) {
              <div class="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 space-y-3">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2.5">
                    <span class="w-2 h-2 rounded-full" [class]="task.status === 'completed' ? 'bg-emerald-400' : task.status === 'requires-approval' ? 'bg-blue-400 animate-pulse' : task.status === 'running' ? 'bg-amber-400 animate-spin' : 'bg-neutral-500'"></span>
                    <span class="font-mono text-xs font-bold text-white">{{ task.id }}</span>
                    <span class="px-2 py-0.5 rounded bg-neutral-800 font-mono text-[10px] uppercase text-neutral-300">
                      {{ task.role }}
                    </span>
                  </div>

                  <div class="flex items-center gap-3">
                    <span [class]="task.status === 'completed' ? 'text-emerald-400 text-xs font-mono' : task.status === 'requires-approval' ? 'text-blue-400 text-xs font-mono font-semibold' : 'text-neutral-400 text-xs font-mono'">
                      {{ task.status | uppercase }}
                    </span>
                    <span class="text-[11px] font-mono text-neutral-500">{{ task.createdAt }}</span>
                  </div>
                </div>

                <div class="text-xs text-neutral-200 font-medium">
                  {{ task.goal }}
                </div>

                <div class="flex items-center justify-between text-xs text-neutral-500 pt-2 border-t border-neutral-800/80">
                  <div class="flex items-center gap-2">
                    <mat-icon class="text-xs">description</mat-icon>
                    <span>Target: {{ task.allowedFiles.join(', ') }}</span>
                  </div>

                  @if (task.status === 'requires-approval') {
                    <button
                      type="button"
                      (click)="reviewDiff(task)"
                      class="px-3 py-1 rounded-md bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs flex items-center gap-1 shadow-sm transition"
                    >
                      <mat-icon class="text-xs">difference</mat-icon>
                      <span>Review & Approve Diff</span>
                    </button>
                  } @else if (task.status === 'completed') {
                    <span class="text-emerald-400 text-xs flex items-center gap-1 font-mono">
                      <mat-icon class="text-xs">done_all</mat-icon> Applied
                    </span>
                  }
                </div>
              </div>
            } @empty {
              <div class="py-20 text-center text-neutral-500 space-y-2">
                <mat-icon class="text-4xl text-neutral-600">psychology</mat-icon>
                <div class="text-xs">No tasks queued yet. Select an agent role on the left to generate code.</div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class CodeGenerationView {
  readonly studio = inject(StudioService);

  readonly selectedRole = signal<AgentTask['role']>('backend');
  readonly goalControl = new FormControl('', { nonNullable: true });

  readonly agentRoles = [
    { id: 'architect' as const, name: 'Architect', icon: 'account_tree', desc: 'Plans modules, boundaries & contracts' },
    { id: 'frontend' as const, name: 'Frontend', icon: 'web', desc: 'UI components, styling & reactive bindings' },
    { id: 'backend' as const, name: 'Backend', icon: 'dns', desc: 'REST endpoints, controllers & services' },
    { id: 'data' as const, name: 'Data', icon: 'database', desc: 'Schemas, SQLite tables & migrations' },
    { id: 'testing' as const, name: 'Testing', icon: 'biotech', desc: 'Unit, integration & assertion suites' },
    { id: 'review' as const, name: 'Review', icon: 'policy', desc: 'Safety audit, diff checks & linting' },
    { id: 'release' as const, name: 'Release', icon: 'inventory_2', desc: 'Build configurations & manifests' },
  ];

  readonly presets = [
    'Add cryptographic voucher discount verification to checkout',
    'Implement SQLite migration for customer loyalty tiers',
    'Generate unit tests for checkout edge cases and stock boundaries',
    'Refactor error handling to use strict Result type pattern',
  ];

  dispatchTask() {
    const goal = this.goalControl.value.trim();
    if (!goal) return;
    this.studio.queueAgentTask(this.selectedRole(), goal);
    this.goalControl.setValue('');
  }

  reviewDiff(task: AgentTask) {
    this.studio.activeDiffTask.set(task);
    this.studio.diffReviewModalOpen.set(true);
  }
}
