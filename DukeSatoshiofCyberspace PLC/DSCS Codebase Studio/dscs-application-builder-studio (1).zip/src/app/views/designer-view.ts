import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { StudioService } from '../services/studio.service';
import { MatIconModule } from '@angular/material/icon';
import { DesignerComponent } from '../models/studio.models';

@Component({
  selector: 'app-designer-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="h-full flex flex-col bg-neutral-950 text-neutral-100 font-sans overflow-hidden">
      <!-- Designer Header Toolbar -->
      <div class="px-6 py-3 border-b border-neutral-800 bg-neutral-900/40 flex items-center justify-between gap-4 shrink-0">
        <div class="flex items-center gap-3">
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono uppercase tracking-wider text-blue-400 font-semibold">Environment B</span>
            <span class="text-xs text-neutral-500">·</span>
            <h1 class="text-base font-bold text-white tracking-tight">Application Designer</h1>
          </div>
          <span class="text-xs text-neutral-500">|</span>
          <div class="text-xs text-neutral-400">
            Visual screen builder with bi-directional source code synchronization
          </div>
        </div>

        <!-- Viewport Breakpoints & Actions -->
        <div class="flex items-center gap-3">
          <div class="flex items-center bg-neutral-950 p-1 rounded-lg border border-neutral-800 text-xs">
            <button
              type="button"
              (click)="studio.previewBreakpoint.set('desktop')"
              [class]="studio.previewBreakpoint() === 'desktop' ? 'bg-neutral-800 text-blue-400 font-medium px-2.5 py-1 rounded flex items-center gap-1' : 'text-neutral-400 hover:text-white px-2.5 py-1 flex items-center gap-1'"
            >
              <mat-icon class="text-sm">desktop_windows</mat-icon>
              <span>1440px</span>
            </button>
            <button
              type="button"
              (click)="studio.previewBreakpoint.set('tablet')"
              [class]="studio.previewBreakpoint() === 'tablet' ? 'bg-neutral-800 text-blue-400 font-medium px-2.5 py-1 rounded flex items-center gap-1' : 'text-neutral-400 hover:text-white px-2.5 py-1 flex items-center gap-1'"
            >
              <mat-icon class="text-sm">tablet</mat-icon>
              <span>768px</span>
            </button>
            <button
              type="button"
              (click)="studio.previewBreakpoint.set('mobile')"
              [class]="studio.previewBreakpoint() === 'mobile' ? 'bg-neutral-800 text-blue-400 font-medium px-2.5 py-1 rounded flex items-center gap-1' : 'text-neutral-400 hover:text-white px-2.5 py-1 flex items-center gap-1'"
            >
              <mat-icon class="text-sm">smartphone</mat-icon>
              <span>375px</span>
            </button>
          </div>

          <button
            type="button"
            (click)="syncToSource()"
            class="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition"
          >
            <mat-icon class="text-sm">code</mat-icon>
            <span>Sync Code to Workbench</span>
          </button>
        </div>
      </div>

      <!-- Designer Workspace: 3-column split -->
      <div class="flex-1 flex overflow-hidden">
        <!-- Left: Screens & Component Library Palette -->
        <div class="w-64 border-r border-neutral-800 bg-neutral-950 p-3 flex flex-col justify-between shrink-0 overflow-y-auto">
          <div class="space-y-4">
            <!-- Screen Switcher -->
            <div class="space-y-1.5">
              <div class="flex items-center justify-between text-[10px] font-mono text-neutral-500 uppercase tracking-wider px-2">
                <span>Screens ({{ studio.activeProject().screens.length }})</span>
                <span class="text-blue-400">+ New</span>
              </div>
              @for (screen of studio.activeProject().screens; track screen.id) {
                <button
                  type="button"
                  (click)="studio.selectedScreenId.set(screen.id)"
                  [class]="studio.selectedScreenId() === screen.id ? 'w-full text-left px-3 py-2 rounded-lg bg-neutral-800/80 text-white font-medium border border-neutral-700 text-xs flex items-center justify-between' : 'w-full text-left px-3 py-2 rounded-lg text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900/60 text-xs flex items-center justify-between'"
                >
                  <div class="truncate">
                    <div>{{ screen.name }}</div>
                    <div class="text-[10px] font-mono text-neutral-500">{{ screen.route }}</div>
                  </div>
                  <mat-icon class="text-sm text-neutral-500">chevron_right</mat-icon>
                </button>
              }
            </div>

            <!-- Component Palette -->
            <div class="space-y-2 pt-3 border-t border-neutral-800/80">
              <div class="text-[10px] font-mono text-neutral-500 uppercase tracking-wider px-2">Component Palette</div>
              <div class="space-y-1">
                @for (item of palette; track item.type) {
                  <button
                    type="button"
                    (click)="insertComponent(item.type, item.name)"
                    class="w-full text-left px-2.5 py-1.5 rounded-lg bg-neutral-900/60 border border-neutral-850 hover:border-neutral-700 text-xs text-neutral-300 flex items-center justify-between transition group"
                  >
                    <div class="flex items-center gap-2">
                      <mat-icon class="text-sm text-neutral-500 group-hover:text-blue-400">{{ item.icon }}</mat-icon>
                      <span>{{ item.name }}</span>
                    </div>
                    <mat-icon class="text-xs text-neutral-600 group-hover:text-neutral-300">add</mat-icon>
                  </button>
                }
              </div>
            </div>
          </div>

          <!-- Component Tree in Current Screen -->
          <div class="pt-4 border-t border-neutral-800/80">
            <div class="text-[10px] font-mono text-neutral-500 uppercase tracking-wider mb-2">Screen Hierarchy</div>
            <div class="space-y-1 text-xs">
              @for (comp of screenComponents(); track comp.id) {
                <button
                  type="button"
                  (click)="studio.selectedComponentId.set(comp.id)"
                  [class]="studio.selectedComponentId() === comp.id ? 'w-full text-left px-2.5 py-1.5 rounded bg-blue-950/40 border border-blue-500/40 text-blue-300 font-medium truncate flex items-center gap-1.5' : 'w-full text-left px-2.5 py-1.5 text-neutral-400 hover:text-neutral-200 truncate flex items-center gap-1.5'"
                >
                  <mat-icon class="text-xs text-neutral-500">widgets</mat-icon>
                  <span class="truncate">{{ comp.name }}</span>
                </button>
              }
            </div>
          </div>
        </div>

        <!-- Center: Visual Canvas -->
        <div class="flex-1 bg-neutral-900/30 overflow-auto p-6 flex flex-col items-center">
          <!-- Canvas Boundary -->
          <div
            [class]="studio.previewBreakpoint() === 'desktop' ? 'w-full max-w-5xl' : studio.previewBreakpoint() === 'tablet' ? 'w-[768px]' : 'w-[375px]'"
            class="min-h-[640px] bg-neutral-950 border border-neutral-800 rounded-xl shadow-2xl overflow-hidden transition-all duration-300 flex flex-col"
          >
            <!-- Canvas Browser Chrome Bar -->
            <div class="px-4 py-2 bg-neutral-900 border-b border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
              <div class="flex items-center gap-1.5">
                <div class="w-2.5 h-2.5 rounded-full bg-neutral-700"></div>
                <div class="w-2.5 h-2.5 rounded-full bg-neutral-700"></div>
                <div class="w-2.5 h-2.5 rounded-full bg-neutral-700"></div>
              </div>
              <div class="font-mono text-[11px] text-neutral-500 bg-neutral-950 px-4 py-0.5 rounded border border-neutral-800/80">
                https://dscs-preview.internal{{ studio.activeScreen()?.route || '/' }}
              </div>
              <div class="text-[10px] text-neutral-500 uppercase font-mono">
                {{ studio.previewBreakpoint() }}
              </div>
            </div>

            <!-- Canvas Component Rendering Area -->
            <div class="flex-1 p-5 space-y-4 overflow-y-auto">
              @for (comp of screenComponents(); track comp.id) {
                <div
                  role="button"
                  tabindex="0"
                  (keydown.enter)="studio.selectedComponentId.set(comp.id)"
                  (click)="studio.selectedComponentId.set(comp.id)"
                  [class]="studio.selectedComponentId() === comp.id ? 'relative ring-2 ring-blue-500 rounded-xl cursor-pointer transition' : 'relative hover:ring-1 hover:ring-neutral-700 rounded-xl cursor-pointer transition'"
                >
                  <!-- Selection Badge -->
                  @if (studio.selectedComponentId() === comp.id) {
                    <div class="absolute -top-2.5 left-3 bg-blue-600 text-white font-mono text-[9px] px-1.5 py-0.5 rounded uppercase font-bold tracking-wider z-10 shadow-sm">
                      {{ comp.name }} (Active)
                    </div>
                  }

                  <!-- Render Component Preview -->
                  @switch (comp.type) {
                    @case ('navbar') {
                      <div class="p-3 bg-neutral-900 border border-neutral-800 rounded-xl flex items-center justify-between">
                        <div class="font-bold text-sm tracking-wide text-white">{{ comp.props['brand'] || 'DSCS APP' }}</div>
                        <div class="flex items-center gap-4 text-xs text-neutral-400">
                          @for (link of (comp.props['links'] || ['Home', 'Catalog']); track link) {
                            <span class="hover:text-white">{{ link }}</span>
                          }
                        </div>
                      </div>
                    }

                    @case ('hero') {
                      <div class="p-6 bg-gradient-to-r from-neutral-900 to-neutral-850 border border-neutral-800 rounded-xl space-y-2">
                        <h2 class="text-xl font-bold text-white tracking-tight">{{ comp.props['headline'] || comp.label }}</h2>
                        <p class="text-xs text-neutral-400 max-w-xl">{{ comp.props['subtext'] || 'High-reliability software and hardware architectures.' }}</p>
                      </div>
                    }

                    @case ('search-bar') {
                      <div class="p-3 bg-neutral-900 border border-neutral-800 rounded-xl flex items-center gap-2">
                        <mat-icon class="text-neutral-500 text-sm">search</mat-icon>
                        <span class="text-xs text-neutral-500">{{ comp.props['placeholder'] || 'Search catalog items...' }}</span>
                      </div>
                    }

                    @case ('catalog-grid') {
                      <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div class="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800 space-y-1">
                          <div class="text-[10px] text-blue-400 font-mono">Security Hardware</div>
                          <div class="text-xs font-semibold text-white">Titanium Edge Workstation Key</div>
                          <div class="text-xs font-bold font-mono text-emerald-400 mt-1">$249.00</div>
                        </div>
                        <div class="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800 space-y-1">
                          <div class="text-[10px] text-blue-400 font-mono">Systems Enclosure</div>
                          <div class="text-xs font-semibold text-white">DSCS Quantum Shielded Chassis</div>
                          <div class="text-xs font-bold font-mono text-emerald-400 mt-1">$680.00</div>
                        </div>
                        <div class="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800 space-y-1">
                          <div class="text-[10px] text-blue-400 font-mono">Storage</div>
                          <div class="text-xs font-semibold text-white">High-Density NVMe Expansion Blade</div>
                          <div class="text-xs font-bold font-mono text-emerald-400 mt-1">$430.00</div>
                        </div>
                      </div>
                    }

                    @case ('admin-stats') {
                      <div class="grid grid-cols-4 gap-2">
                        <div class="p-3 bg-neutral-900 border border-neutral-800 rounded-lg">
                          <div class="text-[10px] text-neutral-500">Revenue</div>
                          <div class="text-sm font-bold font-mono text-emerald-400">$2,273.00</div>
                        </div>
                        <div class="p-3 bg-neutral-900 border border-neutral-800 rounded-lg">
                          <div class="text-[10px] text-neutral-500">Orders</div>
                          <div class="text-sm font-bold font-mono text-white">2 Active</div>
                        </div>
                        <div class="p-3 bg-neutral-900 border border-neutral-800 rounded-lg">
                          <div class="text-[10px] text-neutral-500">Stock</div>
                          <div class="text-sm font-bold font-mono text-blue-400">280 Units</div>
                        </div>
                        <div class="p-3 bg-neutral-900 border border-neutral-800 rounded-lg">
                          <div class="text-[10px] text-neutral-500">Telemetry</div>
                          <div class="text-sm font-bold font-mono text-emerald-400">NOMINAL</div>
                        </div>
                      </div>
                    }

                    @default {
                      <div class="p-4 bg-neutral-900/80 border border-neutral-800 rounded-xl flex items-center justify-between">
                        <div class="space-y-1">
                          <div class="text-xs font-semibold text-white">{{ comp.name }}</div>
                          <div class="text-[10px] font-mono text-neutral-500">Type: {{ comp.type }}</div>
                        </div>
                        <span class="text-xs text-blue-400">Configured</span>
                      </div>
                    }
                  }
                </div>
              } @empty {
                <div class="py-24 text-center text-neutral-500 space-y-2">
                  <mat-icon class="text-4xl text-neutral-600">dashboard_customize</mat-icon>
                  <div class="text-xs">This screen has no components. Click a palette item to insert.</div>
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Right: Property & Design Tokens Inspector -->
        <div class="w-72 border-l border-neutral-800 bg-neutral-950 p-4 shrink-0 overflow-y-auto space-y-6 text-xs">
          @if (studio.selectedComponent(); as comp) {
            <div>
              <div class="text-[10px] font-mono text-neutral-500 uppercase tracking-wider">Component Inspector</div>
              <div class="text-sm font-bold text-white mt-1">{{ comp.name }}</div>
              <div class="text-[11px] font-mono text-blue-400">ID: {{ comp.id }}</div>
            </div>

            <!-- Property Inputs -->
            <div class="space-y-3 pt-3 border-t border-neutral-800">
              <div class="text-[10px] font-mono text-neutral-500 uppercase tracking-wider">Properties & Attributes</div>
              <div>
                <label for="prop-label-input" class="block text-[11px] text-neutral-400 mb-1">Display Label</label>
                <input
                  id="prop-label-input"
                  type="text"
                  [value]="comp.label"
                  (input)="onUpdateLabel(comp.id, $event)"
                  class="w-full px-3 py-1.5 bg-neutral-900 border border-neutral-800 rounded text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              @if (comp.props['headline'] !== undefined) {
                <div>
                  <label for="prop-headline-input" class="block text-[11px] text-neutral-400 mb-1">Headline Text</label>
                  <input
                    id="prop-headline-input"
                    type="text"
                    [value]="comp.props['headline']"
                    (input)="onUpdateProp(comp.id, 'headline', $event)"
                    class="w-full px-3 py-1.5 bg-neutral-900 border border-neutral-800 rounded text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              }

              @if (comp.props['brand'] !== undefined) {
                <div>
                  <label for="prop-brand-input" class="block text-[11px] text-neutral-400 mb-1">Brand Wordmark</label>
                  <input
                    id="prop-brand-input"
                    type="text"
                    [value]="comp.props['brand']"
                    (input)="onUpdateProp(comp.id, 'brand', $event)"
                    class="w-full px-3 py-1.5 bg-neutral-900 border border-neutral-800 rounded text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              }

              @if (comp.props['placeholder'] !== undefined) {
                <div>
                  <label for="prop-placeholder-input" class="block text-[11px] text-neutral-400 mb-1">Input Placeholder</label>
                  <input
                    id="prop-placeholder-input"
                    type="text"
                    [value]="comp.props['placeholder']"
                    (input)="onUpdateProp(comp.id, 'placeholder', $event)"
                    class="w-full px-3 py-1.5 bg-neutral-900 border border-neutral-800 rounded text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              }
            </div>

            <!-- Code Generation Representation -->
            <div class="pt-4 border-t border-neutral-800 space-y-2">
              <div class="text-[10px] font-mono text-neutral-500 uppercase tracking-wider">Generated Code Binding</div>
              <pre class="p-3 rounded-lg bg-neutral-900/90 border border-neutral-800 text-[11px] font-mono text-neutral-300 overflow-x-auto leading-relaxed">&lt;app-{{ comp.type }}
  [label]="'{{ comp.label }}'"
  [screen]="'{{ comp.screenId }}'"
/&gt;</pre>
            </div>
          } @else {
            <div class="py-16 text-center text-neutral-500 space-y-2">
              <mat-icon class="text-3xl text-neutral-600">touch_app</mat-icon>
              <div class="text-xs">Select a component on the canvas to configure properties and design tokens.</div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class ApplicationDesignerView {
  readonly studio = inject(StudioService);

  readonly palette = [
    { type: 'navbar' as const, name: 'Navbar', icon: 'navigation' },
    { type: 'hero' as const, name: 'Hero Section', icon: 'view_agenda' },
    { type: 'search-bar' as const, name: 'Search & Filters', icon: 'search' },
    { type: 'catalog-grid' as const, name: 'Catalog Grid', icon: 'grid_view' },
    { type: 'cart-drawer' as const, name: 'Cart Basket', icon: 'shopping_cart' },
    { type: 'checkout-form' as const, name: 'Checkout Form', icon: 'payment' },
    { type: 'admin-stats' as const, name: 'Admin Stats KPI', icon: 'analytics' },
    { type: 'orders-table' as const, name: 'Orders Ledger Table', icon: 'table_chart' },
  ];

  readonly screenComponents = () => {
    const screenId = this.studio.selectedScreenId();
    return this.studio.activeProject().components.filter((c) => c.screenId === screenId);
  };

  insertComponent(type: DesignerComponent['type'], name: string) {
    const screenId = this.studio.selectedScreenId();
    this.studio.addComponentToScreen(screenId, type, name);
  }

  onUpdateLabel(id: string, event: Event) {
    const val = (event.target as HTMLInputElement).value;
    this.studio.updateComponentProp(id, 'label', val);
  }

  onUpdateProp(id: string, propKey: string, event: Event) {
    const val = (event.target as HTMLInputElement).value;
    this.studio.updateComponentProp(id, propKey, val);
  }

  syncToSource() {
    this.studio.addNotification('success', 'Visual bindings synchronized with project source files.');
    this.studio.setEnvironment('workbench');
  }
}
