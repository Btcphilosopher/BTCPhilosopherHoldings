import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { StudioService } from '../services/studio.service';
import { MatIconModule } from '@angular/material/icon';
import { ReactiveFormsModule, FormControl } from '@angular/forms';

@Component({
  selector: 'app-architect-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, ReactiveFormsModule],
  template: `
    <div class="h-full flex flex-col bg-neutral-950 text-neutral-100 font-sans overflow-hidden">
      <!-- Architect Header Toolbar -->
      <div class="px-6 py-4 border-b border-neutral-800 bg-neutral-900/40 flex items-center justify-between gap-4 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono uppercase tracking-wider text-blue-400 font-semibold">Environment A</span>
            <span class="text-xs text-neutral-500">·</span>
            <h1 class="text-base font-bold text-white tracking-tight">Product Architect</h1>
          </div>
          <div class="text-xs text-neutral-400 mt-0.5">
            Transform plain-language requirements into structured engineering specifications, workflows, and acceptance criteria.
          </div>
        </div>

        <div class="flex items-center gap-3">
          <button
            type="button"
            (click)="approveAndProceed()"
            class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-2 shadow-sm transition"
          >
            <mat-icon class="text-sm">verified</mat-icon>
            <span>Approve Spec & Open Designer</span>
          </button>
        </div>
      </div>

      <!-- Natural Language AI Prompt Generator Bar -->
      <div class="px-6 py-3 border-b border-neutral-800/80 bg-neutral-900/60">
        <div class="max-w-4xl flex items-center gap-3">
          <div class="relative flex-1">
            <mat-icon class="absolute left-3 top-2.5 text-neutral-500 text-sm">psychology</mat-icon>
            <input
              type="text"
              [formControl]="promptControl"
              placeholder="Describe requirements: e.g. 'Build a high-performance telemetry storage service with REST endpoints and SQLite audit log'..."
              class="w-full pl-9 pr-4 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-blue-500"
              (keydown.enter)="onGenerate()"
            />
          </div>
          <button
            type="button"
            (click)="onGenerate()"
            [disabled]="studio.isGenerating() || !promptControl.value.trim()"
            class="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-xs font-medium text-neutral-200 flex items-center gap-1.5 transition disabled:opacity-50"
          >
            @if (studio.isGenerating()) {
              <mat-icon class="text-sm animate-spin">refresh</mat-icon>
              <span>Synthesizing...</span>
            } @else {
              <mat-icon class="text-sm text-blue-400">auto_awesome</mat-icon>
              <span>Synthesize with AI</span>
            }
          </button>
        </div>
      </div>

      <!-- Main Specification Work Surface -->
      <div class="flex-1 flex overflow-hidden">
        <!-- Section Navigation Sidebar -->
        <div class="w-56 border-r border-neutral-800 bg-neutral-950 p-3 space-y-1 shrink-0 overflow-y-auto text-xs">
          <div class="px-3 py-1.5 text-[10px] font-mono text-neutral-500 uppercase tracking-wider">Specification Sections</div>
          @for (tab of tabs; track tab.id) {
            <button
              type="button"
              (click)="activeSection.set(tab.id)"
              [class]="activeSection() === tab.id ? 'w-full flex items-center gap-2 px-3 py-2 rounded-lg bg-neutral-800/90 text-white font-medium border border-neutral-700' : 'w-full flex items-center gap-2 px-3 py-2 rounded-lg text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900/50'"
            >
              <mat-icon class="text-sm text-neutral-400">{{ tab.icon }}</mat-icon>
              <span>{{ tab.label }}</span>
            </button>
          }

          <div class="pt-4 px-3 border-t border-neutral-800/80 mt-4">
            <div class="text-[10px] font-mono text-neutral-500 uppercase">Target Platforms</div>
            <div class="mt-2 space-y-1">
              @for (plat of spec().supportedPlatforms; track plat) {
                <div class="text-xs text-neutral-300 flex items-center gap-1.5">
                  <mat-icon class="text-[14px] text-blue-400">check_circle</mat-icon>
                  <span>{{ plat }}</span>
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Section Content Panel -->
        <div class="flex-1 overflow-y-auto p-6 space-y-6">
          @switch (activeSection()) {
            @case ('overview') {
              <div class="space-y-6 max-w-4xl">
                <div>
                  <h2 class="text-sm font-bold text-white uppercase tracking-wider font-mono">Product Definition & Scope</h2>
                  <div class="text-xs text-neutral-400 mt-1">Core intent, purpose, and audience parameters</div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div class="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 space-y-2">
                    <div class="text-xs font-semibold text-neutral-300">Product Designation</div>
                    <div class="text-base font-bold text-white">{{ spec().productName }}</div>
                  </div>
                  <div class="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 space-y-2">
                    <div class="text-xs font-semibold text-neutral-300">Target Audience</div>
                    <div class="text-xs text-neutral-300 leading-relaxed">{{ spec().targetAudience }}</div>
                  </div>
                </div>

                <div class="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 space-y-2">
                  <div class="text-xs font-semibold text-neutral-300">Operational Purpose</div>
                  <div class="text-xs text-neutral-300 leading-relaxed">{{ spec().purpose }}</div>
                </div>

                <div class="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 space-y-3">
                  <div class="text-xs font-semibold text-neutral-300">Authentication & Permission Profile</div>
                  <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div>
                      <div class="text-[11px] text-neutral-500">Provider</div>
                      <div class="text-neutral-200 font-mono mt-0.5">{{ spec().authModel.provider }}</div>
                    </div>
                    <div>
                      <div class="text-[11px] text-neutral-500">Token Type</div>
                      <div class="text-neutral-200 font-mono mt-0.5">{{ spec().authModel.tokenType }}</div>
                    </div>
                    <div>
                      <div class="text-[11px] text-neutral-500">Session Expiry</div>
                      <div class="text-neutral-200 font-mono mt-0.5">{{ spec().authModel.sessionExpiry }}</div>
                    </div>
                    <div>
                      <div class="text-[11px] text-neutral-500">Authorized Roles</div>
                      <div class="text-neutral-200 font-mono mt-0.5">{{ spec().authModel.roles.join(', ') }}</div>
                    </div>
                  </div>
                </div>
              </div>
            }

            @case ('workflows') {
              <div class="space-y-4 max-w-4xl">
                <div>
                  <h2 class="text-sm font-bold text-white uppercase tracking-wider font-mono">Primary Workflows (Traceable)</h2>
                  <div class="text-xs text-neutral-400 mt-1">Sequential human-to-system operations that define verified user journeys</div>
                </div>

                <div class="space-y-3">
                  @for (wf of spec().primaryWorkflows; track wf.id) {
                    <div class="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 space-y-3">
                      <div class="flex items-center justify-between">
                        <div class="flex items-center gap-2">
                          <span class="text-xs font-mono text-blue-400 font-bold">{{ wf.id }}</span>
                          <span class="text-sm font-semibold text-white">{{ wf.name }}</span>
                        </div>
                        <span class="text-[11px] font-mono text-neutral-500">{{ wf.steps.length }} steps</span>
                      </div>
                      <p class="text-xs text-neutral-400">{{ wf.description }}</p>
                      <div class="border-t border-neutral-800/80 pt-3 space-y-1.5">
                        @for (step of wf.steps; track step; let idx = $index) {
                          <div class="flex items-center gap-2 text-xs text-neutral-300">
                            <span class="w-4 h-4 rounded bg-neutral-800 font-mono text-[10px] flex items-center justify-center text-neutral-400">
                              {{ idx + 1 }}
                            </span>
                            <span>{{ step }}</span>
                          </div>
                        }
                      </div>
                    </div>
                  }
                </div>
              </div>
            }

            @case ('features') {
              <div class="space-y-4 max-w-4xl">
                <div>
                  <h2 class="text-sm font-bold text-white uppercase tracking-wider font-mono">Functional Feature Specifications</h2>
                  <div class="text-xs text-neutral-400 mt-1">Classified deliverables linked to verification test suites</div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  @for (feat of spec().features; track feat.id) {
                    <div class="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 flex flex-col justify-between space-y-3">
                      <div>
                        <div class="flex items-center justify-between text-xs mb-1">
                          <span class="font-mono text-neutral-500">{{ feat.id }}</span>
                          <span [class]="feat.priority === 'must-have' ? 'text-amber-400 font-mono text-[11px]' : 'text-neutral-400 font-mono text-[11px]'">
                            {{ feat.priority }}
                          </span>
                        </div>
                        <h3 class="text-sm font-semibold text-white">{{ feat.title }}</h3>
                        <p class="text-xs text-neutral-400 mt-1 leading-relaxed">{{ feat.description }}</p>
                      </div>
                      <div class="text-[11px] font-mono text-neutral-500 border-t border-neutral-800/80 pt-2 flex items-center justify-between">
                        <span>Category: {{ feat.category }}</span>
                        <span class="text-blue-400 flex items-center gap-1">
                          <mat-icon class="text-xs">task_alt</mat-icon> Traceable
                        </span>
                      </div>
                    </div>
                  }
                </div>
              </div>
            }

            @case ('data') {
              <div class="space-y-4 max-w-4xl">
                <div>
                  <h2 class="text-sm font-bold text-white uppercase tracking-wider font-mono">Data Entities & Persistence Model</h2>
                  <div class="text-xs text-neutral-400 mt-1">Authoritative schemas for database generation and migrations</div>
                </div>

                <div class="space-y-4">
                  @for (ent of spec().dataEntities; track ent.id) {
                    <div class="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 space-y-3">
                      <div class="flex items-center justify-between">
                        <div>
                          <div class="text-sm font-bold text-white font-mono">{{ ent.name }}</div>
                          <div class="text-xs text-neutral-400">{{ ent.description }}</div>
                        </div>
                        <span class="text-xs font-mono text-neutral-500">{{ ent.fields.length }} fields</span>
                      </div>

                      <div class="overflow-x-auto">
                        <table class="w-full text-left text-xs">
                          <thead class="text-neutral-500 font-mono text-[10px] uppercase border-b border-neutral-800">
                            <tr>
                              <th class="py-1.5">Field Name</th>
                              <th class="py-1.5">Type</th>
                              <th class="py-1.5">Constraints</th>
                              <th class="py-1.5">Description</th>
                            </tr>
                          </thead>
                          <tbody class="divide-y divide-neutral-800/60 font-mono text-[11px]">
                            @for (f of ent.fields; track f.name) {
                              <tr>
                                <td class="py-2 text-white font-medium">{{ f.name }}</td>
                                <td class="py-2 text-blue-400">{{ f.type }}</td>
                                <td class="py-2 text-neutral-400">
                                  {{ f.primaryKey ? 'PRIMARY KEY' : f.required ? 'NOT NULL' : 'OPTIONAL' }}
                                </td>
                                <td class="py-2 text-neutral-400 font-sans">{{ f.description || '—' }}</td>
                              </tr>
                            }
                          </tbody>
                        </table>
                      </div>
                    </div>
                  }
                </div>
              </div>
            }

            @case ('apis') {
              <div class="space-y-4 max-w-4xl">
                <div>
                  <h2 class="text-sm font-bold text-white uppercase tracking-wider font-mono">API Requirements & Contracts</h2>
                  <div class="text-xs text-neutral-400 mt-1">REST endpoints required by client interfaces and backend routes</div>
                </div>

                <div class="space-y-2">
                  @for (api of spec().apiRequirements; track api.id) {
                    <div class="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800 flex items-center justify-between gap-4">
                      <div class="flex items-center gap-3">
                        <span
                          [class]="api.method === 'GET' ? 'px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 font-mono text-xs font-bold' : api.method === 'POST' ? 'px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono text-xs font-bold' : 'px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 font-mono text-xs font-bold'"
                        >
                          {{ api.method }}
                        </span>
                        <span class="font-mono text-xs text-white">{{ api.path }}</span>
                      </div>
                      <div class="text-xs text-neutral-400 flex items-center gap-4">
                        <span>{{ api.description }}</span>
                        @if (api.authRequired) {
                          <span class="text-[11px] font-mono text-amber-400 flex items-center gap-1">
                            <mat-icon class="text-xs">lock</mat-icon> Auth
                          </span>
                        } @else {
                          <span class="text-[11px] font-mono text-neutral-500">Public</span>
                        }
                      </div>
                    </div>
                  }
                </div>
              </div>
            }

            @case ('criteria') {
              <div class="space-y-4 max-w-4xl">
                <div>
                  <h2 class="text-sm font-bold text-white uppercase tracking-wider font-mono">Acceptance Criteria & Verifications</h2>
                  <div class="text-xs text-neutral-400 mt-1">Strict binary conditions governing release readiness</div>
                </div>

                <div class="space-y-2">
                  @for (crit of spec().acceptanceCriteria; track crit.id) {
                    <div class="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800 flex items-center justify-between gap-3">
                      <div class="flex items-center gap-3">
                        <mat-icon [class]="crit.verified ? 'text-emerald-400 text-sm' : 'text-neutral-500 text-sm'">
                          {{ crit.verified ? 'check_circle' : 'radio_button_unchecked' }}
                        </mat-icon>
                        <span class="text-xs text-neutral-200">{{ crit.description }}</span>
                      </div>
                      <span class="font-mono text-[11px] text-neutral-500">Test ID: {{ crit.testId || crit.id }}</span>
                    </div>
                  }
                </div>

                <!-- Unresolved Decisions -->
                <div class="pt-6 border-t border-neutral-800 space-y-3">
                  <h3 class="text-xs font-bold text-neutral-300 font-mono uppercase">Architectural Decisions & Defaults</h3>
                  @for (dec of spec().unresolvedDecisions; track dec.id) {
                    <div class="p-3 rounded-lg bg-neutral-950 border border-neutral-800 space-y-1.5 text-xs">
                      <div class="text-neutral-300 font-semibold">{{ dec.question }}</div>
                      <div class="text-neutral-400 flex items-center gap-2">
                        <span class="text-blue-400 font-mono">Adopted Default:</span>
                        <span>{{ dec.chosenOption || dec.defaultOption }}</span>
                      </div>
                    </div>
                  }
                </div>
              </div>
            }
          }
        </div>
      </div>
    </div>
  `,
})
export class ProductArchitectView {
  readonly studio = inject(StudioService);

  readonly promptControl = new FormControl('', { nonNullable: true });
  readonly activeSection = signal<string>('overview');

  readonly tabs = [
    { id: 'overview', label: 'Product Scope', icon: 'description' },
    { id: 'workflows', label: 'Primary Workflows', icon: 'account_tree' },
    { id: 'features', label: 'Feature Catalog', icon: 'view_list' },
    { id: 'data', label: 'Data Entities', icon: 'dataset' },
    { id: 'apis', label: 'API Contracts', icon: 'api' },
    { id: 'criteria', label: 'Acceptance Criteria', icon: 'rule' },
  ];

  readonly spec = () => this.studio.activeProject().specification;

  onGenerate() {
    const text = this.promptControl.value.trim();
    if (!text) return;
    this.studio.generateArchitectureWithAI(text);
  }

  approveAndProceed() {
    this.studio.addNotification('success', 'Specification approved! Opening Application Designer.');
    this.studio.setEnvironment('designer');
  }
}
