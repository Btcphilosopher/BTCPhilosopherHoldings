import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { StudioService } from '../services/studio.service';
import { MatIconModule } from '@angular/material/icon';
import { UpperCasePipe } from '@angular/common';
import { DemoCommerceApp } from './demo-commerce-app';

@Component({
  selector: 'app-runtime-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, DemoCommerceApp, UpperCasePipe],
  template: `
    <div class="h-full flex flex-col bg-neutral-950 text-neutral-100 font-sans overflow-hidden">
      <!-- Runtime Supervision Header -->
      <div class="px-6 py-3 border-b border-neutral-800 bg-neutral-900/50 flex flex-wrap items-center justify-between gap-4 shrink-0">
        <div class="flex items-center gap-3">
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono uppercase tracking-wider text-blue-400 font-semibold">Environment E</span>
            <span class="text-xs text-neutral-500">·</span>
            <h1 class="text-base font-bold text-white tracking-tight">Runtime Studio</h1>
          </div>
          <span class="text-xs text-neutral-600">|</span>
          <div class="flex items-center gap-2 font-mono text-xs">
            <span class="w-2.5 h-2.5 rounded-full" [class]="profile().status === 'running' ? 'bg-emerald-400' : 'bg-neutral-600'"></span>
            <span [class]="profile().status === 'running' ? 'text-emerald-400 font-bold' : 'text-neutral-400'">
              {{ profile().status | uppercase }}
            </span>
            <span class="text-neutral-500">· Port {{ profile().port }}</span>
          </div>
        </div>

        <!-- Telemetry & Process Controls -->
        <div class="flex items-center gap-4">
          <!-- Real-Time Metrics -->
          <div class="hidden md:flex items-center gap-4 text-xs font-mono text-neutral-400 border-r border-neutral-800 pr-4">
            <div>
              <span class="text-neutral-500">CPU:</span>
              <span class="text-white ml-1 font-mono-nums">{{ profile().metrics.cpuPercent }}%</span>
            </div>
            <div>
              <span class="text-neutral-500">RAM:</span>
              <span class="text-white ml-1 font-mono-nums">{{ profile().metrics.memoryMb }} MB</span>
            </div>
            <div>
              <span class="text-neutral-500">Requests:</span>
              <span class="text-blue-400 ml-1 font-mono-nums">{{ profile().metrics.requestsCount }}</span>
            </div>
          </div>

          <!-- Controls -->
          <div class="flex items-center gap-2">
            <button
              type="button"
              (click)="studio.toggleRuntime()"
              [class]="profile().status === 'running' ? 'px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 text-amber-400 font-medium text-xs flex items-center gap-1.5' : 'px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs flex items-center gap-1.5'"
            >
              <mat-icon class="text-sm">{{ profile().status === 'running' ? 'stop' : 'play_arrow' }}</mat-icon>
              <span>{{ profile().status === 'running' ? 'Stop Service' : 'Start Service' }}</span>
            </button>
            <button
              type="button"
              (click)="studio.restartRuntime()"
              [disabled]="profile().status !== 'running'"
              class="px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 text-neutral-300 font-medium text-xs flex items-center gap-1.5 disabled:opacity-50"
            >
              <mat-icon class="text-sm">refresh</mat-icon>
              <span>Restart</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Main Runtime Workspace: Left Live Interactive Preview, Right Server Logs -->
      <div class="flex-1 flex flex-col lg:flex-row overflow-hidden">
        <!-- Live Application Preview Frame -->
        <div class="flex-1 flex flex-col bg-neutral-950 border-r border-neutral-800 overflow-hidden">
          <!-- Preview Chrome Bar -->
          <div class="px-4 py-2 bg-neutral-900 border-b border-neutral-800 flex items-center justify-between text-xs text-neutral-400 shrink-0">
            <div class="flex items-center gap-2 font-mono text-[11px]">
              <span class="text-neutral-500">Target:</span>
              <span class="text-blue-400 font-medium">http://localhost:{{ profile().port }}</span>
              <span class="text-neutral-600">·</span>
              <span class="text-emerald-400 flex items-center gap-1">
                <mat-icon class="text-[12px]">check_circle</mat-icon> Health 200 OK
              </span>
            </div>

            <div class="flex items-center gap-2 text-xs">
              <span class="text-[10px] font-mono bg-neutral-800 text-neutral-300 px-2 py-0.5 rounded">
                Live Interactive Sandbox
              </span>
            </div>
          </div>

          <!-- Preview Content Switcher -->
          <div class="flex-1 overflow-hidden relative">
            @if (profile().status === 'running') {
              @if (studio.activeProject().type === 'fullstack-web' || studio.activeProject().type === 'web-app') {
                <app-demo-commerce-app class="w-full h-full block overflow-hidden"></app-demo-commerce-app>
              } @else if (studio.activeProject().type === 'rust-systems') {
                <!-- Rust Crypto Stream Live Telemetry Preview -->
                <div class="p-6 h-full flex flex-col justify-between font-mono text-xs space-y-4 overflow-y-auto">
                  <div class="space-y-4">
                    <div class="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
                      <div class="flex items-center justify-between text-neutral-400">
                        <span class="text-amber-400 font-bold">[RUST CARGO RUNTIME ENGINE]</span>
                        <span>PID 4821</span>
                      </div>
                      <div class="text-lg font-bold text-white">SIMD ChaCha20-Poly1305 Crypto Pipeline</div>
                      <div class="text-neutral-400 text-xs">Zero-heap allocation critical loop · Kernel io_uring ring-buffer</div>
                    </div>

                    <div class="grid grid-cols-3 gap-3">
                      <div class="p-3 rounded-lg bg-neutral-900 border border-neutral-800">
                        <div class="text-[10px] text-neutral-500">Throughput</div>
                        <div class="text-base font-bold text-emerald-400 mt-1">14.82M ops/s</div>
                      </div>
                      <div class="p-3 rounded-lg bg-neutral-900 border border-neutral-800">
                        <div class="text-[10px] text-neutral-500">P99 Latency</div>
                        <div class="text-base font-bold text-blue-400 mt-1">390 ns</div>
                      </div>
                      <div class="p-3 rounded-lg bg-neutral-900 border border-neutral-800">
                        <div class="text-[10px] text-neutral-500">Memory Allocation</div>
                        <div class="text-base font-bold text-white mt-1">0 Bytes / op</div>
                      </div>
                    </div>
                  </div>

                  <div class="p-4 rounded-lg bg-black border border-neutral-800 text-emerald-400 text-xs font-mono space-y-1">
                    <div>[stream-worker-0] Initialized SIMD registers via AVX2 instruction set.</div>
                    <div>[stream-worker-1] Ring buffer capacity: 65,536 cache-aligned frames.</div>
                    <div>[stream-worker-2] 5,000,000 synthetic cryptograms authenticated without loss.</div>
                    <div class="text-neutral-500">// Ingestion daemon operating nominally at 100% capacity</div>
                  </div>
                </div>
              } @else {
                <!-- R Analytics Visualizer Preview -->
                <div class="p-6 h-full flex flex-col justify-between font-mono text-xs space-y-4 overflow-y-auto">
                  <div class="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
                    <div class="text-emerald-400 font-bold">[R STATISTICAL FORECAST RUNTIME]</div>
                    <div class="text-lg font-bold text-white">Automated ARIMA & Volatility Modeling</div>
                    <div class="text-neutral-400 text-xs">AIC Minimization Model Selection · 95% Confidence Trajectories</div>
                  </div>

                  <div class="p-5 rounded-xl bg-neutral-900/60 border border-neutral-800 space-y-3">
                    <div class="text-xs font-semibold text-neutral-300">Telemetry Density & Prediction Curve</div>
                    <div class="h-32 rounded bg-neutral-950 border border-neutral-800/80 flex items-end p-2 gap-1.5 justify-between">
                      <div class="w-full bg-blue-500/20 h-16 rounded-t"></div>
                      <div class="w-full bg-blue-500/30 h-24 rounded-t"></div>
                      <div class="w-full bg-blue-500/50 h-20 rounded-t"></div>
                      <div class="w-full bg-blue-500/70 h-28 rounded-t"></div>
                      <div class="w-full bg-blue-500 h-22 rounded-t"></div>
                      <div class="w-full bg-emerald-500/80 h-26 rounded-t border-t border-emerald-300"></div>
                      <div class="w-full bg-emerald-500/60 h-30 rounded-t border-t border-emerald-300"></div>
                      <div class="w-full bg-emerald-500/40 h-28 rounded-t border-t border-emerald-300"></div>
                    </div>
                    <div class="flex items-center justify-between text-[11px] text-neutral-500">
                      <span>Historical Observations (t0 -> t100)</span>
                      <span class="text-emerald-400 font-medium">95% Confidence Horizon (t101 -> t112)</span>
                    </div>
                  </div>

                  <div class="p-3 rounded-lg bg-neutral-900 border border-neutral-800 text-[11px] space-y-1">
                    <div>Ljung-Box Test for White Noise: <span class="text-emerald-400 font-bold">p = 0.082 (Passed, p > 0.05)</span></div>
                    <div>Model Parameters: ARIMA(1,1,1) · Residual standard error: 0.428</div>
                  </div>
                </div>
              }
            } @else {
              <div class="h-full flex flex-col items-center justify-center text-center p-6 space-y-3">
                <mat-icon class="text-5xl text-neutral-600">power_settings_new</mat-icon>
                <div class="text-sm font-semibold text-neutral-300">Runtime Process is Stopped</div>
                <p class="text-xs text-neutral-500 max-w-sm">
                  Click "Start Service" above to spin up the local development supervisor, open network ports, and initiate readiness health checks.
                </p>
                <button
                  type="button"
                  (click)="studio.toggleRuntime()"
                  class="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
                >
                  Start Service Now
                </button>
              </div>
            }
          </div>
        </div>

        <!-- Right: Server Logs Stream Panel -->
        <div class="w-full lg:w-96 border-t lg:border-t-0 lg:border-l border-neutral-800 bg-neutral-950 flex flex-col shrink-0 text-xs">
          <div class="px-4 py-2.5 bg-neutral-900 border-b border-neutral-800 flex items-center justify-between shrink-0">
            <div class="font-mono text-xs font-bold text-neutral-300">Service Logs Stream</div>
            <div class="flex items-center gap-1.5">
              <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span class="font-mono text-[10px] text-neutral-400">Tail ({{ profile().logs.length }})</span>
            </div>
          </div>

          <div class="flex-1 overflow-y-auto p-3 space-y-2 font-mono text-[11px]">
            @for (log of profile().logs; track $index) {
              <div class="p-2 rounded bg-neutral-900/60 border border-neutral-850 space-y-0.5">
                <div class="flex items-center justify-between text-[10px] text-neutral-500">
                  <span>{{ log.timestamp }}</span>
                  <span [class]="log.level === 'warn' ? 'text-amber-400' : log.level === 'error' ? 'text-red-400' : 'text-blue-400'">
                    [{{ log.level | uppercase }}]
                  </span>
                </div>
                <div class="text-neutral-200 select-text">{{ log.message }}</div>
              </div>
            } @empty {
              <div class="py-12 text-center text-neutral-600">No logs emitted.</div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class RuntimeView {
  readonly studio = inject(StudioService);

  readonly profile = () => this.studio.activeProject().runtimeProfile;
}
