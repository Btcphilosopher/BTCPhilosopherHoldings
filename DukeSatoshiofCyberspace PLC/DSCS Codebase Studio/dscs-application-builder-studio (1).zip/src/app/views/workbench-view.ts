import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { StudioService } from '../services/studio.service';
import { MatIconModule } from '@angular/material/icon';
import { FormControl, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-workbench-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, ReactiveFormsModule],
  template: `
    <div class="h-full flex flex-col bg-neutral-950 text-neutral-100 font-sans overflow-hidden">
      <!-- Workbench Header Toolbar -->
      <div class="px-5 py-2.5 border-b border-neutral-800 bg-neutral-900/50 flex items-center justify-between gap-4 shrink-0 text-xs">
        <div class="flex items-center gap-3">
          <div class="flex items-center gap-2">
            <span class="font-mono uppercase tracking-wider text-blue-400 font-semibold text-[10px]">Environment D</span>
            <span class="text-neutral-500">·</span>
            <span class="font-bold text-white tracking-tight">Engineering Workbench</span>
          </div>
          <span class="text-neutral-600">|</span>
          <div class="font-mono text-neutral-400 flex items-center gap-2">
            <mat-icon class="text-xs text-neutral-500">source</mat-icon>
            <span>{{ studio.activeProject().name }}</span>
            <span class="text-neutral-600">/</span>
            <span class="text-blue-400">{{ studio.activeFilePath() }}</span>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="onSaveFile()"
            class="px-3 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white font-medium flex items-center gap-1.5 transition"
          >
            <mat-icon class="text-xs">save</mat-icon>
            <span>Save</span>
          </button>
          <button
            type="button"
            (click)="studio.executeCommand('git status')"
            class="px-3 py-1 rounded bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 text-neutral-300 flex items-center gap-1.5 transition"
          >
            <mat-icon class="text-xs">sync_alt</mat-icon>
            <span>Git Status</span>
          </button>
        </div>
      </div>

      <!-- Main Editor Surface: Sidebar + Code Editor + Bottom Dock -->
      <div class="flex-1 flex overflow-hidden">
        <!-- Left Sidebar: File Tree & Git -->
        <div class="w-64 border-r border-neutral-800 bg-neutral-950 flex flex-col justify-between shrink-0 overflow-y-auto text-xs">
          <div class="p-3 space-y-4">
            <!-- File Tree Header -->
            <div>
              <div class="flex items-center justify-between text-[10px] font-mono text-neutral-500 uppercase tracking-wider px-1 mb-2">
                <span>Workspace Files</span>
                <button
                  type="button"
                  (click)="promptNewFile()"
                  class="text-blue-400 hover:text-blue-300 flex items-center gap-0.5"
                >
                  <mat-icon class="text-xs">note_add</mat-icon>
                  <span>+ File</span>
                </button>
              </div>

              <!-- Files List -->
              <div class="space-y-0.5 font-mono text-xs">
                @for (file of studio.activeProject().files; track file.path) {
                  <button
                    type="button"
                    (click)="studio.openFile(file.path)"
                    [class]="studio.activeFilePath() === file.path ? 'w-full px-2 py-1.5 rounded bg-neutral-850 text-white font-medium flex items-center justify-between cursor-pointer border border-neutral-750 text-left' : 'w-full px-2 py-1.5 rounded text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900 cursor-pointer flex items-center justify-between text-left'"
                  >
                    <div class="flex items-center gap-2 truncate">
                      <mat-icon class="text-sm text-neutral-500">
                        {{ file.name.endsWith('.ts') ? 'javascript' : file.name.endsWith('.sql') ? 'database' : file.name.endsWith('.rs') ? 'precision_manufacturing' : 'description' }}
                      </mat-icon>
                      <span class="truncate">{{ file.name }}</span>
                    </div>

                    @if (file.isModified) {
                      <span class="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
                    }
                  </button>
                }
              </div>
            </div>

            <!-- Git Working Tree Status -->
            <div class="pt-3 border-t border-neutral-800/80 space-y-2">
              <div class="text-[10px] font-mono text-neutral-500 uppercase tracking-wider px-1">Source Control (Git)</div>
              <div class="p-2 rounded-lg bg-neutral-900/60 border border-neutral-800 space-y-2">
                <div class="flex items-center justify-between text-neutral-300">
                  <div class="flex items-center gap-1.5">
                    <mat-icon class="text-xs text-blue-400">fork_right</mat-icon>
                    <span class="font-mono">{{ studio.activeProject().git.currentBranch }}</span>
                  </div>
                  <span class="text-[10px] font-mono text-neutral-500">
                    {{ studio.activeProject().git.modifiedCount }} modified
                  </span>
                </div>
                <div class="text-[10px] font-mono text-neutral-500 truncate">
                  Latest: {{ studio.activeProject().git.commits[0]?.message || 'Initial commit' }}
                </div>
              </div>
            </div>

            <!-- Host Toolchains Status -->
            <div class="pt-3 border-t border-neutral-800/80 space-y-2">
              <div class="text-[10px] font-mono text-neutral-500 uppercase tracking-wider px-1">Host Toolchains</div>
              <div class="space-y-1 font-mono text-[11px]">
                @if (studio.toolchains(); as tc) {
                  <div class="flex items-center justify-between text-neutral-400">
                    <span>Node.js:</span>
                    <span class="text-emerald-400">{{ tc.node.installed ? tc.node.version : 'Not detected' }}</span>
                  </div>
                  <div class="flex items-center justify-between text-neutral-400">
                    <span>Git:</span>
                    <span class="text-emerald-400">{{ tc.git.installed ? (tc.git.version || 'Ready') : 'Not detected' }}</span>
                  </div>
                  <div class="flex items-center justify-between text-neutral-400">
                    <span>Rust / Cargo:</span>
                    <span [class]="tc.cargo.installed ? 'text-emerald-400' : 'text-neutral-500'">{{ tc.cargo.installed ? 'Ready' : 'Optional' }}</span>
                  </div>
                  <div class="flex items-center justify-between text-neutral-400">
                    <span>Python 3:</span>
                    <span [class]="tc.python3.installed ? 'text-emerald-400' : 'text-neutral-500'">{{ tc.python3.installed ? 'Ready' : 'Optional' }}</span>
                  </div>
                } @else {
                  <div class="text-neutral-500">Probing environment...</div>
                }
              </div>
            </div>
          </div>
        </div>

        <!-- Center & Bottom: Tabs, Editor, and Terminal Panel -->
        <div class="flex-1 flex flex-col overflow-hidden">
          <!-- File Tabs Bar -->
          <div class="h-9 border-b border-neutral-800 bg-neutral-900/80 flex items-center overflow-x-auto shrink-0">
            @for (tabPath of studio.openTabs(); track tabPath) {
              <div
                class="h-full border-r border-neutral-800 flex items-center"
                [class]="studio.activeFilePath() === tabPath ? 'bg-neutral-950 border-t-2 border-t-blue-500' : 'bg-transparent'"
              >
                <button
                  type="button"
                  (click)="studio.openFile(tabPath)"
                  class="h-full px-3 text-xs flex items-center gap-1.5 font-mono"
                  [class]="studio.activeFilePath() === tabPath ? 'text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'"
                >
                  <span>{{ getFilename(tabPath) }}</span>
                </button>
                <button
                  type="button"
                  (click)="closeTab(tabPath, $event)"
                  class="text-neutral-500 hover:text-white pr-2.5 p-0.5 rounded"
                >
                  <mat-icon class="text-[12px] leading-none">close</mat-icon>
                </button>
              </div>
            }
          </div>

          <!-- Code Editor Area -->
          <div class="flex-1 flex overflow-hidden bg-neutral-950 font-mono text-xs">
            <!-- Line Numbers Gutter -->
            <div class="w-12 py-3 bg-neutral-950 border-r border-neutral-900 text-neutral-600 select-none text-right pr-3 shrink-0 font-mono-nums leading-relaxed">
              @for (num of lineNumbers(); track num) {
                <div>{{ num }}</div>
              }
            </div>

            <!-- Code Text Area -->
            <div class="flex-1 overflow-auto relative p-0">
              <textarea
                [value]="editorContent()"
                (input)="onEditorInput($event)"
                spellcheck="false"
                class="w-full h-full p-3 bg-transparent text-neutral-200 font-mono text-xs leading-relaxed focus:outline-none resize-none border-none selection:bg-blue-600/30 whitespace-pre"
              ></textarea>
            </div>
          </div>

          <!-- Bottom Dockable Engineering Panel (Terminal & Problems) -->
          <div class="h-56 border-t border-neutral-800 bg-neutral-950 flex flex-col shrink-0">
            <!-- Bottom Tabs -->
            <div class="h-8 border-b border-neutral-800/80 bg-neutral-900/60 px-4 flex items-center justify-between text-xs shrink-0">
              <div class="flex items-center gap-4">
                <button
                  type="button"
                  (click)="bottomTab.set('terminal')"
                  [class]="bottomTab() === 'terminal' ? 'text-white font-medium border-b-2 border-blue-500 pb-1' : 'text-neutral-400 hover:text-neutral-200 pb-1'"
                >
                  Integrated Terminal
                </button>
                <button
                  type="button"
                  (click)="bottomTab.set('diagnostics')"
                  [class]="bottomTab() === 'diagnostics' ? 'text-white font-medium border-b-2 border-blue-500 pb-1' : 'text-neutral-400 hover:text-neutral-200 pb-1'"
                >
                  Diagnostics & Problems (0)
                </button>
              </div>

              <!-- Quick Command Presets -->
              <div class="flex items-center gap-2">
                <button
                  type="button"
                  (click)="runPreset('git status -s')"
                  class="px-2 py-0.5 rounded bg-neutral-850 hover:bg-neutral-800 text-[11px] font-mono text-neutral-300"
                >
                  git status
                </button>
                <button
                  type="button"
                  (click)="runPreset('node -v && npm -v')"
                  class="px-2 py-0.5 rounded bg-neutral-850 hover:bg-neutral-800 text-[11px] font-mono text-neutral-300"
                >
                  node -v
                </button>
                <button
                  type="button"
                  (click)="runPreset('uname -a')"
                  class="px-2 py-0.5 rounded bg-neutral-850 hover:bg-neutral-800 text-[11px] font-mono text-neutral-300"
                >
                  uname -a
                </button>
                <button
                  type="button"
                  (click)="studio.clearTerminal()"
                  class="text-neutral-500 hover:text-neutral-300 ml-2"
                >
                  <mat-icon class="text-xs">delete_sweep</mat-icon>
                </button>
              </div>
            </div>

            <!-- Terminal Output / Diagnostics View -->
            @if (bottomTab() === 'terminal') {
              <div class="flex-1 flex flex-col overflow-hidden p-2 font-mono text-[11px]">
                <div class="flex-1 overflow-y-auto space-y-0.5 px-2 text-neutral-300 select-text leading-relaxed">
                  @for (log of studio.terminalLogs(); track $index) {
                    <div [class]="log.startsWith('$') ? 'text-blue-400 font-semibold' : log.startsWith('[stderr]') ? 'text-red-400' : log.includes('error') ? 'text-red-300' : 'text-neutral-300'">
                      {{ log }}
                    </div>
                  }
                </div>

                <!-- Terminal Command Input Bar -->
                <div class="pt-2 px-2 border-t border-neutral-850 flex items-center gap-2 shrink-0">
                  <span class="text-blue-400 font-bold">$</span>
                  <input
                    type="text"
                    [formControl]="terminalCommandControl"
                    placeholder="Enter bash / git / cargo command..."
                    class="flex-1 bg-transparent text-white font-mono text-[11px] focus:outline-none placeholder-neutral-600"
                    (keydown.enter)="onExecuteCustomCommand()"
                  />
                  @if (studio.terminalRunning()) {
                    <mat-icon class="text-xs text-amber-400 animate-spin">refresh</mat-icon>
                  }
                </div>
              </div>
            } @else {
              <!-- Diagnostics Tab -->
              <div class="flex-1 overflow-y-auto p-4 text-xs space-y-2">
                <div class="flex items-center gap-2 text-emerald-400 font-medium">
                  <mat-icon class="text-sm">check_circle</mat-icon>
                  <span>No syntax, type, or linting errors detected across workspace.</span>
                </div>
                <div class="text-neutral-500 text-[11px] font-mono">
                  All compilation bounds verified: 0 errors · 0 warnings · TypeScript strict mode active.
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class WorkbenchView {
  readonly studio = inject(StudioService);

  readonly bottomTab = signal<'terminal' | 'diagnostics'>('terminal');
  readonly terminalCommandControl = new FormControl('', { nonNullable: true });

  readonly editorContent = () => this.studio.activeFile()?.content || '';

  readonly lineNumbers = () => {
    const lines = (this.editorContent().split('\n').length) || 1;
    return Array.from({ length: Math.min(lines, 300) }, (_, i) => i + 1);
  };

  getFilename(path: string): string {
    return path.split('/').pop() || path;
  }

  closeTab(path: string, event: Event) {
    event.stopPropagation();
    this.studio.closeFile(path);
  }

  onEditorInput(event: Event) {
    const val = (event.target as HTMLTextAreaElement).value;
    this.studio.updateFileContent(this.studio.activeFilePath(), val);
  }

  onSaveFile() {
    this.studio.addNotification('success', `Saved ${this.getFilename(this.studio.activeFilePath())}`);
  }

  promptNewFile() {
    const name = window.prompt('Enter file path (e.g. /src/utils/crypto.ts):');
    if (name) {
      this.studio.createFile(name, '// Created in DSCS Studio\n');
    }
  }

  runPreset(cmd: string) {
    this.studio.executeCommand(cmd);
  }

  onExecuteCustomCommand() {
    const cmd = this.terminalCommandControl.value.trim();
    if (!cmd) return;
    this.studio.executeCommand(cmd);
    this.terminalCommandControl.setValue('');
  }
}
