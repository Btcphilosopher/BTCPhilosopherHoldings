import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { StudioService } from '../services/studio.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-release-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="h-full flex flex-col bg-neutral-950 text-neutral-100 font-sans overflow-hidden">
      <!-- Release Header Toolbar -->
      <div class="px-6 py-4 border-b border-neutral-800 bg-neutral-900/40 flex items-center justify-between gap-4 shrink-0">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono uppercase tracking-wider text-blue-400 font-semibold">Environment G</span>
            <span class="text-xs text-neutral-500">·</span>
            <h1 class="text-base font-bold text-white tracking-tight">Release & Deployment Centre</h1>
          </div>
          <div class="text-xs text-neutral-400 mt-0.5">
            Multi-target compilation, artifact checksum verification, and configured deployment adapters.
          </div>
        </div>

        <div class="flex items-center gap-2 text-xs font-mono text-neutral-400">
          <span>Target Platform:</span>
          <span class="text-white font-bold bg-neutral-900 px-2 py-1 rounded border border-neutral-800">
            {{ activeTargetLabel() }}
          </span>
        </div>
      </div>

      <!-- Main Release Workspace -->
      <div class="flex-1 overflow-y-auto p-6 space-y-6">
        <!-- Target Profiles Grid -->
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <h2 class="text-xs font-bold text-neutral-300 uppercase tracking-wider font-mono">1. Select Build & Packaging Target</h2>
            <span class="text-xs text-neutral-500 font-mono">Profile: Release (--opt-level=3)</span>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            @for (target of availableTargets; track target.id) {
              <div class="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 flex flex-col justify-between space-y-3 hover:border-neutral-700 transition">
                <div>
                  <div class="flex items-center justify-between text-xs mb-1">
                    <span class="font-mono text-blue-400 font-semibold">{{ target.category }}</span>
                    <mat-icon class="text-neutral-500 text-sm">{{ target.icon }}</mat-icon>
                  </div>
                  <h3 class="text-sm font-semibold text-white">{{ target.name }}</h3>
                  <p class="text-xs text-neutral-400 mt-1 leading-relaxed">{{ target.description }}</p>
                </div>

                <div class="pt-2 border-t border-neutral-800/80 flex items-center justify-between">
                  <span class="text-[10px] font-mono text-neutral-500">{{ target.format }}</span>
                  <button
                    type="button"
                    (click)="studio.buildReleasePackage(target.id)"
                    class="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-750 text-white font-medium text-xs flex items-center gap-1.5 border border-neutral-700 transition"
                  >
                    <mat-icon class="text-xs">build</mat-icon>
                    <span>Package</span>
                  </button>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Produced Release Artifacts Ledger -->
        <div class="rounded-xl bg-neutral-900/60 border border-neutral-800 overflow-hidden space-y-0">
          <div class="px-5 py-3.5 border-b border-neutral-800 flex items-center justify-between">
            <div>
              <div class="text-sm font-bold text-white tracking-tight font-mono uppercase">Compiled Release Artifacts</div>
              <div class="text-xs text-neutral-400">Cryptographically verified binaries with reproducible SHA-256 provenance hashes.</div>
            </div>
            <span class="font-mono text-xs text-neutral-500">{{ artifacts().length }} artifacts ready</span>
          </div>

          <div class="divide-y divide-neutral-800/80 text-xs font-mono">
            @for (art of artifacts(); track art.id) {
              <div class="px-5 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-neutral-850/40 transition">
                <div class="space-y-1">
                  <div class="flex items-center gap-2">
                    <mat-icon class="text-blue-400 text-sm">inventory_2</mat-icon>
                    <span class="text-white font-semibold text-xs">{{ art.name }}</span>
                    <span class="px-1.5 py-0.5 rounded bg-neutral-800 text-[10px] text-neutral-400 uppercase">{{ art.profile }}</span>
                  </div>
                  <div class="text-[11px] text-neutral-500 flex items-center gap-3">
                    <span>Size: {{ (art.sizeBytes / 1024 / 1024).toFixed(2) }} MB</span>
                    <span>·</span>
                    <span class="truncate max-w-sm">SHA-256: {{ art.sha256 }}</span>
                  </div>
                </div>

                <div class="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    (click)="downloadArtifact(art.name)"
                    class="px-3 py-1 rounded bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 text-neutral-300 text-xs flex items-center gap-1"
                  >
                    <mat-icon class="text-xs">download</mat-icon>
                    <span>Download</span>
                  </button>
                  <button
                    type="button"
                    (click)="deployArtifact(art.name)"
                    class="px-3 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1"
                  >
                    <mat-icon class="text-xs">cloud_upload</mat-icon>
                    <span>Deploy</span>
                  </button>
                </div>
              </div>
            } @empty {
              <div class="py-12 text-center text-neutral-500">
                No artifacts compiled. Click "Package" on one of the targets above.
              </div>
            }
          </div>
        </div>

        <!-- Deployment Adapters & Secrets Management -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <!-- Deployment Adapter Selector -->
          <div class="p-5 rounded-xl bg-neutral-900/60 border border-neutral-800 space-y-4">
            <div>
              <h3 class="text-xs font-bold text-white uppercase tracking-wider font-mono">Deployment Adapters</h3>
              <div class="text-xs text-neutral-400 mt-0.5">Explicit, configured delivery destinations</div>
            </div>

            <div class="space-y-2 text-xs">
              <label class="flex items-center gap-3 p-3 rounded-lg bg-neutral-950 border border-neutral-800 cursor-pointer">
                <input type="radio" name="deployAdapter" checked class="text-blue-500" />
                <div>
                  <div class="font-semibold text-neutral-200">Local-Only / Air-Gapped Mode (Active)</div>
                  <div class="text-neutral-500 text-[11px]">Keep all artifacts within local file storage; zero external cloud egress.</div>
                </div>
              </label>
              <label class="flex items-center gap-3 p-3 rounded-lg bg-neutral-950 border border-neutral-800 cursor-pointer">
                <input type="radio" name="deployAdapter" class="text-blue-500" />
                <div>
                  <div class="font-semibold text-neutral-200">SSH Linux Server Adapter</div>
                  <div class="text-neutral-500 text-[11px]">Deploy over SSH with systemd daemon restart on remote Debian/Ubuntu host.</div>
                </div>
              </label>
              <label class="flex items-center gap-3 p-3 rounded-lg bg-neutral-950 border border-neutral-800 cursor-pointer">
                <input type="radio" name="deployAdapter" class="text-blue-500" />
                <div>
                  <div class="font-semibold text-neutral-200">OCI Container Registry</div>
                  <div class="text-neutral-500 text-[11px]">Push tagged multi-architecture image to configured private registry.</div>
                </div>
              </label>
            </div>
          </div>

          <!-- Secret Redaction & Environment Variables -->
          <div class="p-5 rounded-xl bg-neutral-900/60 border border-neutral-800 space-y-4">
            <div>
              <h3 class="text-xs font-bold text-white uppercase tracking-wider font-mono">Environment Configuration & Secrets</h3>
              <div class="text-xs text-neutral-400 mt-0.5">Zero plain-text credential leaks · Automatic redaction</div>
            </div>

            <div class="space-y-2 font-mono text-xs">
              <div class="p-2.5 rounded-lg bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                <span class="text-neutral-400">NODE_ENV:</span>
                <span class="text-emerald-400">production</span>
              </div>
              <div class="p-2.5 rounded-lg bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                <span class="text-neutral-400">DATABASE_DIALECT:</span>
                <span class="text-blue-400">sqlite</span>
              </div>
              <div class="p-2.5 rounded-lg bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                <span class="text-neutral-400">GEMINI_API_KEY:</span>
                <span class="text-amber-400 flex items-center gap-1">
                  <mat-icon class="text-xs">lock</mat-icon>
                  <span>•••••••••••••••• (Injected via Secrets)</span>
                </span>
              </div>
              <div class="p-2.5 rounded-lg bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                <span class="text-neutral-400">PORT:</span>
                <span class="text-white">3000</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ReleaseView {
  readonly studio = inject(StudioService);

  readonly availableTargets = [
    {
      id: 'linux-binary' as const,
      name: 'Linux Native Executable (Tauri / ELF)',
      category: 'Desktop Systems',
      icon: 'terminal',
      description: 'Compiled native x86_64 binary optimized for Ubuntu, Debian, and Linux workstations.',
      format: 'ELF 64-bit LSB executable',
    },
    {
      id: 'web-bundle' as const,
      name: 'Web Application Distribution Bundle',
      category: 'Full-Stack Web',
      icon: 'web',
      description: 'Compressed production bundle containing client assets and Node.js SSR server.',
      format: 'tar.gz Archive',
    },
    {
      id: 'docker-container' as const,
      name: 'OCI Container Image (Dockerfile)',
      category: 'Cloud & Containers',
      icon: 'layers',
      description: 'Hermetic minimal container image configured with non-root execution policy.',
      format: 'OCI v1 Image Spec',
    },
    {
      id: 'android-apk' as const,
      name: 'Android Package (APK / AAB)',
      category: 'Mobile Android',
      icon: 'smartphone',
      description: 'Signed mobile package compiled with Kotlin, Gradle, and Android SDK.',
      format: 'Android App Bundle',
    },
    {
      id: 'cargo-crate' as const,
      name: 'Rust Cargo Crate Archive',
      category: 'Rust Systems',
      icon: 'precision_manufacturing',
      description: 'Pre-compiled crate with Cargo metadata and zero-dependency linkage.',
      format: 'Cargo .crate bundle',
    },
    {
      id: 'r-package' as const,
      name: 'R Analytical Package (tar.gz)',
      category: 'Data Science',
      icon: 'insights',
      description: 'Reproducible R analytical package compliant with CRAN check standards.',
      format: 'R Source Package',
    },
  ];

  readonly artifacts = () => this.studio.activeProject().releaseArtifacts;

  readonly activeTargetLabel = () => {
    const type = this.studio.activeProject().type;
    return type === 'rust-systems' ? 'Linux x86_64 (Cargo)' : type === 'r-analytics' ? 'R 4.3+ Runtime' : 'Linux / Web / Container';
  };

  downloadArtifact(name: string) {
    this.studio.addNotification('info', `Simulating download of verified artifact: ${name}`);
  }

  deployArtifact(name: string) {
    const confirm = window.confirm(`Confirm deployment of ${name} to selected adapter?`);
    if (confirm) {
      this.studio.addNotification('success', `Deployed ${name} successfully! Health check passed.`);
    }
  }
}
