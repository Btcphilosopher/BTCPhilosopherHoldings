import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';

interface ProductItem {
  id: string;
  name: string;
  category: string;
  price: number;
  stock: number;
  rating: number;
  badge?: string;
  description: string;
  specs: string;
}

interface CartItem extends ProductItem {
  quantity: number;
}

interface OrderItem {
  id: string;
  customer: string;
  email: string;
  itemsCount: number;
  total: number;
  status: string;
  date: string;
  items: string[];
}

@Component({
  selector: 'app-demo-commerce-app',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, ReactiveFormsModule],
  template: `
    <div class="h-full flex flex-col bg-neutral-950 text-neutral-100 font-sans overflow-hidden">
      <!-- Store Header -->
      <header class="border-b border-neutral-800 bg-neutral-900/80 backdrop-blur px-5 py-3 flex items-center justify-between gap-4 shrink-0">
        <div class="flex items-center gap-3">
          <div class="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 font-bold text-sm tracking-wider">
            DS
          </div>
          <div>
            <div class="text-sm font-semibold tracking-wide text-neutral-100">DSCS COMMERCE</div>
            <div class="text-xs text-neutral-500">Mission-Critical Systems Procurement</div>
          </div>
        </div>

        <!-- Mode Switcher -->
        <div class="flex items-center bg-neutral-950 p-1 rounded-lg border border-neutral-800 text-xs">
          <button
            type="button"
            (click)="activeTab.set('store')"
            [class]="activeTab() === 'store' ? 'bg-neutral-800 text-blue-400 font-medium px-3 py-1.5 rounded-md' : 'text-neutral-400 hover:text-neutral-200 px-3 py-1.5'"
          >
            Storefront
          </button>
          <button
            type="button"
            (click)="activeTab.set('admin')"
            [class]="activeTab() === 'admin' ? 'bg-neutral-800 text-amber-400 font-medium px-3 py-1.5 rounded-md' : 'text-neutral-400 hover:text-neutral-200 px-3 py-1.5'"
          >
            Admin Dashboard
          </button>
        </div>

        <!-- Cart Button -->
        <button
          type="button"
          (click)="cartOpen.set(true)"
          class="relative flex items-center gap-2 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-750 text-xs text-neutral-200 border border-neutral-700 transition"
        >
          <mat-icon class="text-base leading-none">shopping_cart</mat-icon>
          <span>Basket</span>
          @if (totalCartItems() > 0) {
            <span class="w-5 h-5 rounded-full bg-blue-500 text-white font-mono-nums text-[10px] flex items-center justify-center font-bold">
              {{ totalCartItems() }}
            </span>
          }
        </button>
      </header>

      <!-- Storefront View -->
      @if (activeTab() === 'store') {
        <div class="flex-1 overflow-y-auto p-5 space-y-6">
          <!-- Banner -->
          <div class="p-5 rounded-xl bg-gradient-to-r from-neutral-900 to-neutral-850 border border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="space-y-1">
              <div class="text-xs font-mono uppercase tracking-wider text-blue-400">Verified Hardware Catalog</div>
              <h2 class="text-xl font-bold text-white tracking-tight">Zero-Trust Cryptographic Hardware & Compute</h2>
              <p class="text-xs text-neutral-400 max-w-xl">
                Aerospace-grade enclosures, hardware security keys, and RISC-V edge controllers tested for mission-critical reliability.
              </p>
            </div>
            <div class="text-xs bg-amber-500/10 border border-amber-500/30 text-amber-300 px-3 py-2 rounded-lg shrink-0">
              <span class="font-semibold">TEST ENVIRONMENT:</span> Real payments disabled · Safe simulated settlement
            </div>
          </div>

          <!-- Filter & Search Toolbar -->
          <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div class="relative flex-1 max-w-md">
              <mat-icon class="absolute left-3 top-2.5 text-neutral-500 text-sm">search</mat-icon>
              <input
                type="text"
                [value]="searchQuery()"
                (input)="onSearchInput($event)"
                placeholder="Search by hardware name, category, or specs..."
                class="w-full pl-9 pr-4 py-2 bg-neutral-900 border border-neutral-800 rounded-lg text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            <!-- Category Pills -->
            <div class="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 text-xs text-neutral-400">
              @for (cat of categories; track cat) {
                <button
                  type="button"
                  (click)="selectedCategory.set(cat)"
                  [class]="selectedCategory() === cat ? 'bg-neutral-800 text-white font-medium px-2.5 py-1.5 rounded-md border border-neutral-700' : 'hover:text-neutral-200 px-2.5 py-1.5 rounded-md'"
                >
                  {{ cat }}
                </button>
              }
            </div>
          </div>

          <!-- Product Grid -->
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            @for (product of filteredProducts(); track product.id) {
              <div class="rounded-xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 transition flex flex-col justify-between p-4 space-y-4">
                <div>
                  <div class="flex items-center justify-between gap-2 text-xs text-neutral-500 mb-1">
                    <span>{{ product.category }}</span>
                    @if (product.badge) {
                      <span class="text-blue-400 font-mono text-[10px]">{{ product.badge }}</span>
                    }
                  </div>
                  <h3 class="text-sm font-semibold text-neutral-100">{{ product.name }}</h3>
                  <p class="text-xs text-neutral-400 mt-1 line-clamp-2">{{ product.description }}</p>
                  <div class="mt-2 text-[11px] font-mono text-neutral-500 border-t border-neutral-800/80 pt-2">
                    {{ product.specs }}
                  </div>
                </div>

                <div class="flex items-center justify-between pt-2 border-t border-neutral-800">
                  <div>
                    <div class="text-lg font-bold font-mono-nums text-white">
                      \${{ product.price.toFixed(2) }}
                    </div>
                    <div class="text-[10px] text-neutral-500">
                      {{ product.stock }} units available
                    </div>
                  </div>

                  <button
                    type="button"
                    (click)="addToCart(product)"
                    [disabled]="product.stock === 0"
                    class="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium flex items-center gap-1.5 transition disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <mat-icon class="text-sm leading-none">add_shopping_cart</mat-icon>
                    <span>Add to Basket</span>
                  </button>
                </div>
              </div>
            } @empty {
              <div class="col-span-full py-12 text-center text-neutral-500 space-y-2">
                <mat-icon class="text-4xl text-neutral-600">inventory_2</mat-icon>
                <div class="text-sm">No hardware items match your search.</div>
              </div>
            }
          </div>
        </div>
      }

      <!-- Admin View -->
      @if (activeTab() === 'admin') {
        <div class="flex-1 overflow-y-auto p-5 space-y-6">
          <div class="flex items-center justify-between">
            <div>
              <h2 class="text-lg font-bold text-white tracking-tight">Operations & Fulfillment Console</h2>
              <div class="text-xs text-neutral-400">Live order queue, inventory reservation, and dispatch records</div>
            </div>
            <button
              type="button"
              (click)="refreshOrders()"
              class="px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 hover:bg-neutral-800 text-xs text-neutral-300 flex items-center gap-1.5"
            >
              <mat-icon class="text-sm">refresh</mat-icon>
              <span>Refresh Ledger</span>
            </button>
          </div>

          <!-- KPI Cards -->
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div class="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800">
              <div class="text-xs text-neutral-500">Total Settled Revenue</div>
              <div class="text-xl font-bold font-mono-nums text-emerald-400 mt-1">\${{ totalRevenue().toFixed(2) }}</div>
              <div class="text-[11px] text-neutral-500 mt-0.5">Across all confirmed dispatches</div>
            </div>
            <div class="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800">
              <div class="text-xs text-neutral-500">Active Orders</div>
              <div class="text-xl font-bold font-mono-nums text-white mt-1">{{ orders().length }}</div>
              <div class="text-[11px] text-neutral-500 mt-0.5">Processing and in-transit</div>
            </div>
            <div class="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800">
              <div class="text-xs text-neutral-500">Inventory Units</div>
              <div class="text-xl font-bold font-mono-nums text-blue-400 mt-1">{{ totalStock() }}</div>
              <div class="text-[11px] text-neutral-500 mt-0.5">Warehouse reserve balance</div>
            </div>
            <div class="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800">
              <div class="text-xs text-neutral-500">System Telemetry</div>
              <div class="text-xl font-bold font-mono-nums text-emerald-400 mt-1">NOMINAL</div>
              <div class="text-[11px] text-neutral-500 mt-0.5">Zero-error audit trail</div>
            </div>
          </div>

          <!-- Orders Table -->
          <div class="rounded-xl bg-neutral-900/60 border border-neutral-800 overflow-hidden">
            <div class="px-4 py-3 border-b border-neutral-800 flex items-center justify-between">
              <div class="text-xs font-semibold text-neutral-200">Recent Customer Transactions</div>
              <div class="text-xs font-mono text-neutral-500">{{ orders().length }} records</div>
            </div>

            <div class="overflow-x-auto">
              <table class="w-full text-left text-xs">
                <thead class="bg-neutral-950/60 text-neutral-400 border-b border-neutral-800 uppercase font-mono text-[10px]">
                  <tr>
                    <th class="px-4 py-2.5">Order ID</th>
                    <th class="px-4 py-2.5">Customer & Entity</th>
                    <th class="px-4 py-2.5">Purchased Assets</th>
                    <th class="px-4 py-2.5">Amount</th>
                    <th class="px-4 py-2.5">Status</th>
                    <th class="px-4 py-2.5">Timestamp</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-neutral-800/80">
                  @for (order of orders(); track order.id) {
                    <tr class="hover:bg-neutral-850/50 transition">
                      <td class="px-4 py-3 font-mono font-medium text-blue-400">{{ order.id }}</td>
                      <td class="px-4 py-3">
                        <div class="font-medium text-neutral-200">{{ order.customer }}</div>
                        <div class="text-neutral-500 text-[11px]">{{ order.email }}</div>
                      </td>
                      <td class="px-4 py-3 text-neutral-400">
                        {{ order.items.join(', ') }}
                      </td>
                      <td class="px-4 py-3 font-mono font-semibold text-neutral-100">
                        \${{ order.total.toFixed(2) }}
                      </td>
                      <td class="px-4 py-3">
                        <span [class]="order.status === 'Shipped' ? 'text-blue-400' : order.status === 'Delivered' ? 'text-emerald-400' : 'text-amber-400'">
                          {{ order.status }}
                        </span>
                      </td>
                      <td class="px-4 py-3 font-mono text-neutral-500 text-[11px]">
                        {{ order.date }}
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>
        </div>
      }

      <!-- Cart Drawer Overlay -->
      @if (cartOpen()) {
        <div class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex justify-end">
          <div class="w-full max-w-md bg-neutral-900 border-l border-neutral-800 h-full flex flex-col justify-between shadow-2xl p-6">
            <div class="space-y-4 flex-1 overflow-y-auto">
              <div class="flex items-center justify-between pb-4 border-b border-neutral-800">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-blue-400">shopping_bag</mat-icon>
                  <h3 class="text-base font-bold text-white">Procurement Basket</h3>
                </div>
                <button
                  type="button"
                  (click)="cartOpen.set(false)"
                  class="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800"
                >
                  <mat-icon>close</mat-icon>
                </button>
              </div>

              <!-- Cart Items -->
              @if (cart().length > 0) {
                <div class="space-y-3">
                  @for (item of cart(); track item.id) {
                    <div class="p-3 rounded-lg bg-neutral-950 border border-neutral-800 flex items-center justify-between gap-3">
                      <div class="flex-1 min-w-0">
                        <div class="text-xs font-semibold text-neutral-200 truncate">{{ item.name }}</div>
                        <div class="text-[11px] font-mono text-neutral-500">\${{ item.price.toFixed(2) }} each</div>
                      </div>

                      <div class="flex items-center gap-2">
                        <button
                          type="button"
                          (click)="updateQuantity(item.id, -1)"
                          class="w-6 h-6 rounded bg-neutral-800 hover:bg-neutral-700 text-xs flex items-center justify-center text-white"
                        >
                          -
                        </button>
                        <span class="font-mono text-xs text-white px-1">{{ item.quantity }}</span>
                        <button
                          type="button"
                          (click)="updateQuantity(item.id, 1)"
                          class="w-6 h-6 rounded bg-neutral-800 hover:bg-neutral-700 text-xs flex items-center justify-center text-white"
                        >
                          +
                        </button>
                        <button
                          type="button"
                          (click)="removeFromCart(item.id)"
                          class="p-1 text-neutral-500 hover:text-red-400 ml-1"
                        >
                          <mat-icon class="text-sm">delete</mat-icon>
                        </button>
                      </div>
                    </div>
                  }
                </div>

                <!-- Checkout Form -->
                <form [formGroup]="checkoutForm" (ngSubmit)="submitCheckout()" class="space-y-3 pt-3 border-t border-neutral-800">
                  <div class="text-xs font-semibold text-neutral-300">Dispatch Destination (Test Settlement)</div>
                  <div>
                    <label for="checkout-name" class="block text-[11px] text-neutral-400 mb-1">Customer / Organization Name</label>
                    <input
                      id="checkout-name"
                      type="text"
                      formControlName="customerName"
                      placeholder="e.g. Apex Defense Dynamics"
                      class="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-xs text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label for="checkout-email" class="block text-[11px] text-neutral-400 mb-1">Confirmation Email</label>
                    <input
                      id="checkout-email"
                      type="email"
                      formControlName="email"
                      placeholder="procurement@apexdefense.com"
                      class="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-xs text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label for="checkout-address" class="block text-[11px] text-neutral-400 mb-1">Facility Address</label>
                    <input
                      id="checkout-address"
                      type="text"
                      formControlName="shippingAddress"
                      placeholder="Sector 7 Aerospace Park, Cleanroom B"
                      class="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-xs text-neutral-100 placeholder-neutral-600 focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <button
                    type="submit"
                    [disabled]="checkoutForm.invalid || isSubmitting()"
                    class="w-full py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center justify-center gap-2 transition disabled:opacity-50"
                  >
                    <mat-icon class="text-sm">verified</mat-icon>
                    <span>Confirm Test Checkout ($\{{ cartSubtotal().toFixed(2) }})</span>
                  </button>
                </form>
              } @else {
                <div class="py-16 text-center text-neutral-500 space-y-2">
                  <mat-icon class="text-4xl text-neutral-600">remove_shopping_cart</mat-icon>
                  <div class="text-xs">Your basket is currently empty.</div>
                </div>
              }
            </div>

            <!-- Receipt Modal Confirmation -->
            @if (receipt()) {
              <div class="mt-4 p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 space-y-2 text-xs">
                <div class="flex items-center gap-1.5 font-bold text-emerald-300">
                  <mat-icon class="text-sm">check_circle</mat-icon>
                  <span>Order Transacted Successfully</span>
                </div>
                <div>Reference: <span class="font-mono text-white">{{ receipt()?.orderId }}</span></div>
                <div>Cryptographic Receipt: <span class="font-mono text-[11px] text-emerald-400">{{ receipt()?.receiptNumber }}</span></div>
                <div class="text-[11px] text-neutral-400">Inventory updated in live database ledger.</div>
                <button
                  type="button"
                  (click)="receipt.set(null); cartOpen.set(false)"
                  class="w-full mt-2 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium"
                >
                  Dismiss Receipt
                </button>
              </div>
            }
          </div>
        </div>
      }
    </div>
  `,
})
export class DemoCommerceApp {
  private http = inject(HttpClient);

  readonly activeTab = signal<'store' | 'admin'>('store');
  readonly cartOpen = signal<boolean>(false);
  readonly searchQuery = signal<string>('');
  readonly selectedCategory = signal<string>('All');
  readonly isSubmitting = signal<boolean>(false);
  readonly receipt = signal<{ orderId: string; receiptNumber: string } | null>(null);

  readonly categories = ['All', 'Security Hardware', 'Systems Enclosure', 'Storage', 'Power Systems', 'Compute Modules', 'Networking'];

  readonly products = signal<ProductItem[]>([
    {
      id: 'prod-001',
      name: 'Titanium Edge Workstation Key',
      category: 'Security Hardware',
      price: 249.0,
      stock: 38,
      rating: 4.9,
      badge: 'Bestseller',
      description: 'Zero-trust cryptographic physical hardware token with dual FIDO2/U2F interface.',
      specs: 'ARM Cortex-M4 · IP68 Certified · 256-bit AES Hardware Cryptoprocessor',
    },
    {
      id: 'prod-002',
      name: 'DSCS Quantum Shielded Enclosure',
      category: 'Systems Enclosure',
      price: 680.0,
      stock: 14,
      rating: 4.8,
      badge: 'Industrial',
      description: 'Milled aluminum desktop chassis with EMI/RF attenuation for sensitive systems.',
      specs: '6061-T6 Aerospace Aluminum · Passive Thermal Radiator · 10Gbps SFP+ Pass-through',
    },
    {
      id: 'prod-003',
      name: 'High-Density NVMe Expansion Blade',
      category: 'Storage',
      price: 430.0,
      stock: 52,
      rating: 5.0,
      badge: 'High Throughput',
      description: 'PCIe 5.0 quad M.2 carrier card with active thermal copper vapor chamber.',
      specs: 'Up to 28,000 MB/s sequential read · Bifurcation x16 · Smart telemetry LED',
    },
    {
      id: 'prod-004',
      name: 'Low-Noise Linear Precision PSU',
      category: 'Power Systems',
      price: 310.0,
      stock: 22,
      rating: 4.7,
      badge: 'Precision',
      description: 'Clean DC supply with ripple under 1.5mV for precision data-acquisition devices.',
      specs: 'Triple isolated rails 12V/5V/3.3V · Overvoltage OVP/OCP/SCP · Gold terminals',
    },
    {
      id: 'prod-005',
      name: 'Satoshi Stream Micro-Controller Node',
      category: 'Compute Modules',
      price: 185.0,
      stock: 90,
      rating: 4.9,
      badge: 'Edge Node',
      description: 'Dual-core RISC-V edge computing unit running bare-metal Rust firmware.',
      specs: '64-bit RV64GC · 512MB ECC RAM · Dual Gigabit Ethernet · CAN-FD Bus',
    },
    {
      id: 'prod-006',
      name: 'Fiber Optic Isolation Link',
      category: 'Networking',
      price: 120.0,
      stock: 64,
      rating: 4.6,
      badge: 'Galvanic Safe',
      description: 'Complete optical galvanic isolation for hostile industrial ground loop rejection.',
      specs: 'Single-mode LC 1310nm · 20km range · < 2ns jitter · Industrial DIN Rail',
    },
  ]);

  readonly cart = signal<CartItem[]>([]);
  readonly orders = signal<OrderItem[]>([
    {
      id: 'ORD-8921',
      customer: 'Astra Dynamics Lab',
      email: 'procurement@astradyn.io',
      itemsCount: 3,
      total: 988.0,
      status: 'Shipped',
      date: '2026-10-27 14:22',
      items: ['Titanium Edge Workstation Key (2)', 'DSCS Quantum Shielded Enclosure (1)'],
    },
    {
      id: 'ORD-8920',
      customer: 'Helios Research Institute',
      email: 'dr.vogel@helios.edu',
      itemsCount: 4,
      total: 1285.0,
      status: 'Processing',
      date: '2026-10-27 11:05',
      items: ['High-Density NVMe Expansion Blade (2)', 'Low-Noise Linear Precision PSU (1)'],
    },
  ]);

  readonly checkoutForm = new FormGroup({
    customerName: new FormControl('Duke Satoshi Cybernetics', { nonNullable: true, validators: [Validators.required] }),
    email: new FormControl('engineering@dscs.cyberspace', { nonNullable: true, validators: [Validators.required, Validators.email] }),
    shippingAddress: new FormControl('Building 4, Cybernetics Campus, Sector 9', { nonNullable: true, validators: [Validators.required] }),
  });

  readonly filteredProducts = computed(() => {
    const q = this.searchQuery().toLowerCase().trim();
    const cat = this.selectedCategory();
    return this.products().filter((p) => {
      const matchesCat = cat === 'All' || p.category === cat;
      const matchesQuery = !q || p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q) || p.specs.toLowerCase().includes(q);
      return matchesCat && matchesQuery;
    });
  });

  readonly totalCartItems = computed(() => this.cart().reduce((acc, item) => acc + item.quantity, 0));
  readonly cartSubtotal = computed(() => this.cart().reduce((acc, item) => acc + item.price * item.quantity, 0));
  readonly totalStock = computed(() => this.products().reduce((acc, p) => acc + p.stock, 0));
  readonly totalRevenue = computed(() => this.orders().reduce((acc, o) => acc + o.total, 0));

  onSearchInput(event: Event) {
    const target = event.target as HTMLInputElement;
    this.searchQuery.set(target.value);
  }

  addToCart(product: ProductItem) {
    this.cart.update((items) => {
      const existing = items.find((i) => i.id === product.id);
      if (existing) {
        return items.map((i) => (i.id === product.id ? { ...i, quantity: i.quantity + 1 } : i));
      }
      return [...items, { ...product, quantity: 1 }];
    });
  }

  updateQuantity(id: string, delta: number) {
    this.cart.update((items) =>
      items
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null),
    );
  }

  removeFromCart(id: string) {
    this.cart.update((items) => items.filter((i) => i.id !== id));
  }

  submitCheckout() {
    if (this.checkoutForm.invalid || this.cart().length === 0) return;
    this.isSubmitting.set(true);

    const body = {
      items: this.cart(),
      customerName: this.checkoutForm.value.customerName,
      email: this.checkoutForm.value.email,
      shippingAddress: this.checkoutForm.value.shippingAddress,
    };

    this.http.post<{ status: string; orderId: string; receiptNumber: string; order?: OrderItem }>('/api/demo/checkout', body).subscribe({
      next: (res) => {
        this.isSubmitting.set(false);
        this.receipt.set({ orderId: res.orderId, receiptNumber: res.receiptNumber });

        // Update local orders list and stock
        if (res.order) {
          this.orders.update((list) => [res.order!, ...list]);
        }
        for (const item of this.cart()) {
          this.products.update((prods) =>
            prods.map((p) => (p.id === item.id ? { ...p, stock: Math.max(0, p.stock - item.quantity) } : p)),
          );
        }
        this.cart.set([]);
      },
      error: () => {
        this.isSubmitting.set(false);
        // Fallback local simulation if backend unavailable
        const orderId = `ORD-${Math.floor(1000 + Math.random() * 9000)}`;
        const receiptNumber = `DSCS-TXN-${Date.now().toString(36).toUpperCase()}`;
        this.receipt.set({ orderId, receiptNumber });
        const newOrder: OrderItem = {
          id: orderId,
          customer: this.checkoutForm.value.customerName || 'Verified Guest',
          email: this.checkoutForm.value.email || 'guest@dscs.local',
          itemsCount: this.totalCartItems(),
          total: this.cartSubtotal(),
          status: 'Processing',
          date: new Date().toISOString().replace('T', ' ').substring(0, 16),
          items: this.cart().map((i) => `${i.name} (${i.quantity})`),
        };
        this.orders.update((list) => [newOrder, ...list]);
        this.cart.set([]);
      },
    });
  }

  refreshOrders() {
    this.http.get<{ orders: OrderItem[] }>('/api/demo/orders').subscribe({
      next: (res) => {
        if (res.orders) {
          this.orders.set(res.orders);
        }
      },
    });
  }
}
