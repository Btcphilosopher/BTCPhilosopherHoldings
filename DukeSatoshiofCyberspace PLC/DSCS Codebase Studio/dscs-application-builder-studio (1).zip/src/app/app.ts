import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { StudioService } from './services/studio.service';
import { MatIconModule } from '@angular/material/icon';
import { StudioEnvironment } from './models/studio.models';

import { ProductArchitectView } from './views/architect-view';
import { ApplicationDesignerView } from './views/designer-view';
import { CodeGenerationView } from './views/codegen-view';
import { WorkbenchView } from './views/workbench-view';
import { RuntimeView } from './views/runtime-view';
import { QualityView } from './views/quality-view';
import { ReleaseView } from './views/release-view';

import { CommandPaletteComponent } from './components/command-palette';
import { NewProjectModalComponent } from './components/new-project-modal';
import { DiffReviewModalComponent } from './components/diff-review-modal';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    MatIconModule,
    ProductArchitectView,
    ApplicationDesignerView,
    CodeGenerationView,
    WorkbenchView,
    RuntimeView,
    QualityView,
    ReleaseView,
    CommandPaletteComponent,
    NewProjectModalComponent,
    DiffReviewModalComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
  host: {
    '(window:keydown)': 'onKeydown($event)',
  },
})
export class App {
  readonly studio = inject(StudioService);

  readonly projectMenuOpen = signal<boolean>(false);

  readonly environments: { id: StudioEnvironment; label: string; icon: string; envLetter: string }[] = [
    { id: 'architect', label: 'Architect', icon: 'description', envLetter: 'A' },
    { id: 'designer', label: 'Designer', icon: 'dashboard', envLetter: 'B' },
    { id: 'codegen', label: 'Generate', icon: 'auto_awesome', envLetter: 'C' },
    { id: 'workbench', label: 'Workbench', icon: 'terminal', envLetter: 'D' },
    { id: 'runtime', label: 'Runtime', icon: 'play_circle', envLetter: 'E' },
    { id: 'quality', label: 'Quality', icon: 'verified', envLetter: 'F' },
    { id: 'release', label: 'Release', icon: 'inventory_2', envLetter: 'G' },
  ];

  selectEnvironment(env: StudioEnvironment) {
    this.studio.setEnvironment(env);
  }

  toggleProjectMenu() {
    this.projectMenuOpen.update((v) => !v);
  }

  onSelectProject(id: string) {
    this.studio.selectProject(id);
    this.projectMenuOpen.set(false);
  }

  openNewProjectModal() {
    this.studio.newProjectModalOpen.set(true);
    this.projectMenuOpen.set(false);
  }

  openCommandPalette() {
    this.studio.commandPaletteOpen.set(true);
  }

  onKeydown(event: KeyboardEvent) {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      this.studio.commandPaletteOpen.update((v) => !v);
    }
  }
}
