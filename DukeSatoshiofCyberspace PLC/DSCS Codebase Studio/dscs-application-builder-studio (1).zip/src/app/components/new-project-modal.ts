import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { StudioService } from '../services/studio.service';
import { MatIconModule } from '@angular/material/icon';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ProjectType } from '../models/studio.models';

@Component({
  selector: 'app-new-project-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, ReactiveFormsModule],
  template: `
    @if (studio.newProjectModalOpen()) {
      <div
        role="presentation"
        tabindex="-1"
        class="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-6"
        (keydown.escape)="studio.newProjectModalOpen.set(false)"
        (click)="closeOnBackdrop($event)"
      >
        <div class="w-full max-w-2xl bg-neutral-900 border border-neutral-750 rounded-xl shadow-2xl overflow-hidden font-sans text-xs flex flex-col max-h-[85vh]">
          <!-- Header -->
          <div class="px-5 py-3.5 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between shrink-0">
            <div class="flex items-center gap-2">
              <mat-icon class="text-blue-400 text-base">create_new_folder</mat-icon>
              <span class="font-bold text-white text-sm">Create New Engineering Project</span>
            </div>
            <button
              type="button"
              (click)="studio.newProjectModalOpen.set(false)"
              class="text-neutral-500 hover:text-white p-1"
            >
              <mat-icon class="text-sm">close</mat-icon>
            </button>
          </div>

          <!-- Form Body -->
          <form [formGroup]="form" (ngSubmit)="onSubmit()" class="flex-1 overflow-y-auto p-6 space-y-5">
            <!-- Project Archetype Templates -->
            <div class="space-y-2">
              <div class="block text-xs font-mono uppercase text-neutral-400 font-bold">1. Select Project Archetype</div>
              <div class="grid grid-cols-2 sm:grid-cols-3 gap-2">
                @for (arch of archetypes; track arch.type) {
                  <button
                    type="button"
                    (click)="selectedType.set(arch.type)"
                    [class]="selectedType() === arch.type ? 'p-3 rounded-lg bg-blue-950/40 border border-blue-500/50 text-left transition' : 'p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-left hover:border-neutral-700 transition text-neutral-400'"
                  >
                    <div class="flex items-center gap-1.5 font-semibold text-white">
                      <mat-icon class="text-sm text-blue-400">{{ arch.icon }}</mat-icon>
                      <span class="truncate">{{ arch.title }}</span>
                    </div>
                    <div class="text-[10px] text-neutral-500 mt-1 line-clamp-2 leading-tight">{{ arch.desc }}</div>
                  </button>
                }
              </div>
            </div>

            <!-- Project Name -->
            <div class="space-y-1">
              <label for="new-project-name" class="block text-xs font-semibold text-neutral-300">Project Name</label>
              <input
                id="new-project-name"
                type="text"
                formControlName="name"
                placeholder="e.g. Satoshi Secure Vault"
                class="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-blue-500 font-sans"
              />
            </div>

            <!-- Plain Language Specification Prompt -->
            <div class="space-y-1">
              <label for="new-project-prompt" class="block text-xs font-semibold text-neutral-300">Product Specification / Engineering Prompt</label>
              <textarea
                id="new-project-prompt"
                formControlName="prompt"
                rows="4"
                placeholder="Describe your desired application, target users, primary features, and database requirements..."
                class="w-full p-3 bg-neutral-950 border border-neutral-800 rounded-lg text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-blue-500 font-sans leading-relaxed resize-none"
              ></textarea>
              <p class="text-[11px] text-neutral-500">
                The DSCS Product Architect engine will synthesize requirements, screen hierarchies, and test suites automatically.
              </p>
            </div>

            <!-- Submit Button -->
            <div class="pt-3 border-t border-neutral-800 flex items-center justify-end gap-3">
              <button
                type="button"
                (click)="studio.newProjectModalOpen.set(false)"
                class="px-4 py-2 rounded-lg bg-neutral-850 hover:bg-neutral-800 text-neutral-300 text-xs font-medium"
              >
                Cancel
              </button>
              <button
                type="submit"
                [disabled]="form.invalid"
                class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition disabled:opacity-50"
              >
                <mat-icon class="text-xs">rocket_launch</mat-icon>
                <span>Scaffold Project Workspace</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    }
  `,
})
export class NewProjectModalComponent {
  readonly studio = inject(StudioService);

  readonly selectedType = signal<ProjectType>('fullstack-web');

  readonly archetypes: { type: ProjectType; title: string; icon: string; desc: string }[] = [
    { type: 'fullstack-web', title: 'Full-Stack Web', icon: 'web', desc: 'Frontend + Express backend + SQLite ledger' },
    { type: 'web-app', title: 'Web App SPA', icon: 'language', desc: 'Client reactive interface & OpenAPI client' },
    { type: 'rust-systems', title: 'Rust Systems', icon: 'precision_manufacturing', desc: 'Cargo crate with SIMD & zero-allocation engine' },
    { type: 'r-analytics', title: 'R Analytics', icon: 'insights', desc: 'Reproducible R statistical modeling package' },
    { type: 'desktop-tauri', title: 'Desktop (Tauri)', icon: 'terminal', desc: 'Linux native shell with Rust core engine' },
    { type: 'android-kotlin', title: 'Android Kotlin', icon: 'smartphone', desc: 'Gradle mobile app with Jetpack Compose' },
  ];

  readonly form = new FormGroup({
    name: new FormControl('Satoshi Edge Telemetry', { nonNullable: true, validators: [Validators.required] }),
    prompt: new FormControl('Build an edge telemetry collection and processing node with cryptographic signing and SQLite ledger.', { nonNullable: true, validators: [Validators.required] }),
  });

  closeOnBackdrop(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.studio.newProjectModalOpen.set(false);
    }
  }

  onSubmit() {
    if (this.form.invalid) return;
    const name = this.form.value.name || 'DSCS Project';
    const prompt = this.form.value.prompt || '';

    // Create custom spec
    const spec = {
      productName: name,
      purpose: prompt,
      targetAudience: 'Systems Engineers and Analysts',
      supportedPlatforms: ['Linux', 'Web', 'Container'],
      primaryWorkflows: [
        { id: 'wf-1', name: 'Operational Ingestion', description: 'Receive data and run cryptographic validation', steps: ['Ingest packet', 'Validate signature', 'Persist to ledger'] },
      ],
      userRoles: [{ id: 'role-admin', role: 'Administrator', permissions: ['all'] }],
      screens: [{ id: 'scr-1', title: 'Dashboard', route: '/', purpose: 'Primary operations console' }],
      features: [{ id: 'feat-1', title: 'Core Processing Engine', category: 'Core', description: 'Reliable transaction processing', priority: 'must-have' as const }],
      dataEntities: [],
      apiRequirements: [{ id: 'api-1', path: '/api/v1/health', method: 'GET' as const, description: 'Health check probe', authRequired: false }],
      authModel: { provider: 'DSCS Session Token', roles: ['Admin'], tokenType: 'Bearer', sessionExpiry: '24h' },
      performanceRequirements: ['Sub-millisecond processing'],
      securityRequirements: ['Non-root execution'],
      accessibilityRequirements: ['WCAG AA compliant'],
      designDirection: { theme: 'Graphite Dark', primaryColor: 'Steel Blue', typography: 'Plus Jakarta Sans', density: 'High density' },
      acceptanceCriteria: [{ id: 'ac-1', description: 'All unit test suites pass without warnings', verified: true }],
      deploymentTargets: ['Linux Native Binary'],
      unresolvedDecisions: [],
    };

    this.studio.createNewProject(spec, this.selectedType());
    this.studio.newProjectModalOpen.set(false);
  }
}
