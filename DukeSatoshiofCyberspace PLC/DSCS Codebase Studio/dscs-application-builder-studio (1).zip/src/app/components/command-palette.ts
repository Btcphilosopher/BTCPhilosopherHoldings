import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { StudioService } from '../services/studio.service';
import { MatIconModule } from '@angular/material/icon';
import { StudioEnvironment } from '../models/studio.models';

@Component({
  selector: 'app-command-palette',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    @if (studio.commandPaletteOpen()) {
      <div
        role="presentation"
        tabindex="-1"
        class="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-start justify-center pt-24 p-4"
        (keydown.escape)="close()"
        (click)="closeOnBackdrop($event)"
      >
        <div class="w-full max-w-xl bg-neutral-900 border border-neutral-750 rounded-xl shadow-2xl overflow-hidden font-sans text-xs">
          <!-- Search Header Input -->
          <div class="px-4 py-3 border-b border-neutral-800 flex items-center gap-3 bg-neutral-950">
            <mat-icon class="text-neutral-500 text-sm">search</mat-icon>
            <input
              type="text"
              [value]="filterQuery()"
              (input)="onInput($event)"
              placeholder="Type an action, open file, or switch environment..."
              class="w-full bg-transparent text-white text-xs placeholder-neutral-500 focus:outline-none"
              autoFocus
            />
            <kbd class="px-1.5 py-0.5 rounded bg-neutral-800 font-mono text-[10px] text-neutral-400">ESC</kbd>
          </div>

          <!-- Filtered Actions List -->
          <div class="max-h-80 overflow-y-auto p-2 space-y-1">
            <div class="px-3 py-1 text-[10px] font-mono text-neutral-500 uppercase tracking-wider">Quick Actions</div>
            @for (action of filteredActions(); track action.label) {
              <button
                type="button"
                (click)="action.run()"
                class="w-full px-3 py-2 rounded-lg text-left text-neutral-300 hover:text-white hover:bg-neutral-800/80 flex items-center justify-between transition group"
              >
                <div class="flex items-center gap-2.5">
                  <mat-icon class="text-neutral-500 group-hover:text-blue-400 text-sm">{{ action.icon }}</mat-icon>
                  <span class="font-medium">{{ action.label }}</span>
                </div>
                <span class="text-[10px] font-mono text-neutral-500">{{ action.category }}</span>
              </button>
            }
          </div>
        </div>
      </div>
    }
  `,
})
export class CommandPaletteComponent {
  readonly studio = inject(StudioService);
  readonly filterQuery = signal<string>('');

  readonly actions = [
    { label: 'Switch to Product Architect (Env A)', category: 'Environment', icon: 'description', run: () => this.switchEnv('architect') },
    { label: 'Switch to Application Designer (Env B)', category: 'Environment', icon: 'dashboard', run: () => this.switchEnv('designer') },
    { label: 'Switch to Code Generation Engine (Env C)', category: 'Environment', icon: 'auto_awesome', run: () => this.switchEnv('codegen') },
    { label: 'Switch to Engineering Workbench (Env D)', category: 'Environment', icon: 'terminal', run: () => this.switchEnv('workbench') },
    { label: 'Switch to Runtime Studio (Env E)', category: 'Environment', icon: 'play_circle', run: () => this.switchEnv('runtime') },
    { label: 'Switch to Quality & Verification (Env F)', category: 'Environment', icon: 'verified', run: () => this.switchEnv('quality') },
    { label: 'Switch to Release & Packaging (Env G)', category: 'Environment', icon: 'inventory_2', run: () => this.switchEnv('release') },
    { label: 'Run Full Test Suite', category: 'Build', icon: 'play_arrow', run: () => { this.studio.runAllTests(); this.close(); } },
    { label: 'Restart Runtime Dev Server', category: 'Process', icon: 'refresh', run: () => { this.studio.restartRuntime(); this.close(); } },
    { label: 'Create New Project', category: 'Project', icon: 'add_circle', run: () => { this.studio.newProjectModalOpen.set(true); this.close(); } },
  ];

  filteredActions = () => {
    const q = this.filterQuery().toLowerCase().trim();
    if (!q) return this.actions;
    return this.actions.filter((a) => a.label.toLowerCase().includes(q) || a.category.toLowerCase().includes(q));
  };

  onInput(event: Event) {
    this.filterQuery.set((event.target as HTMLInputElement).value);
  }

  switchEnv(env: StudioEnvironment) {
    this.studio.setEnvironment(env);
    this.close();
  }

  close() {
    this.studio.commandPaletteOpen.set(false);
  }

  closeOnBackdrop(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.close();
    }
  }
}
