import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join, resolve, basename, dirname, extname, relative } from 'node:path';
import { existsSync, promises as fs } from 'node:fs';
import { spawn, execFile, ChildProcess } from 'node:child_process';
import http from 'node:http';
import os from 'node:os';

const browserDistFolder = join(import.meta.dirname, '../browser');
const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json({ limit: '10mb' }));

// -------------------------------------------------------------
// DSCS CODEBASE STUDIO — IN-MEMORY STATE & JOB SUPERVISOR
// -------------------------------------------------------------

export interface ToolchainInfo {
  id: string;
  name: string;
  category: 'compiler' | 'runtime' | 'vcs' | 'build-tool';
  version: string | null;
  executablePath: string | null;
  available: boolean;
  statusText: string;
  verifiedAt: string;
}

export interface BuildJob {
  id: string;
  workspacePath: string;
  command: string;
  args: string[];
  status: 'running' | 'success' | 'failed' | 'cancelled';
  startTime: string;
  endTime?: string;
  durationMs?: number;
  exitCode?: number | null;
  logs: Array<{ stream: 'stdout' | 'stderr' | 'system'; text: string; time: string }>;
  diagnostics: Array<{ file?: string; line?: number; col?: number; severity: 'error' | 'warning' | 'info'; message: string }>;
}

export interface ManagedProcess {
  id: string;
  workspacePath: string;
  name: string;
  command: string;
  args: string[];
  pid: number | null;
  port: number;
  healthPath: string;
  status: 'stopped' | 'starting' | 'ready' | 'unhealthy' | 'failed';
  startTime?: string;
  exitCode?: number | null;
  logs: Array<{ stream: 'stdout' | 'stderr' | 'system'; text: string; time: string }>;
  lastHealthCheck?: { time: string; ok: boolean; status: number; latencyMs: number; error?: string };
}

const jobHistory: BuildJob[] = [];
let activeBuildProcess: { job: BuildJob; process: ChildProcess } | null = null;
let managedProcess: { model: ManagedProcess; process: ChildProcess | null; proberTimer?: NodeJS.Timeout } | null = null;

// Helper: Run command safely and get output
function execPromise(cmd: string, args: string[], cwd: string = process.cwd(), timeoutMs = 15000): Promise<{ stdout: string; stderr: string; exitCode: number }> {
  return new Promise((res) => {
    try {
      const fullPath = `${process.env['PATH'] || ''}:/root/.cargo/bin:/usr/bin:/usr/local/bin`;
      execFile(cmd, args, { cwd, timeout: timeoutMs, env: { ...process.env, PATH: fullPath } }, (error, stdout, stderr) => {
        res({
          stdout: stdout ? stdout.toString() : '',
          stderr: stderr ? stderr.toString() : '',
          exitCode: error ? ((error.code as number) || 1) : 0,
        });
      });
    } catch (e: any) {
      res({ stdout: '', stderr: e.message, exitCode: 1 });
    }
  });
}

// -------------------------------------------------------------
// 1. TOOLCHAIN INVENTORY
// -------------------------------------------------------------
app.get('/api/toolchains', async (req, res): Promise<void> => {
  const tools = [
    { id: 'rustc', name: 'Rust Compiler (rustc)', category: 'compiler' as const, cmd: 'rustc', arg: '--version' },
    { id: 'cargo', name: 'Cargo Build System & Package Manager', category: 'build-tool' as const, cmd: 'cargo', arg: '--version' },
    { id: 'r', name: 'R Statistical Runtime', category: 'runtime' as const, cmd: 'R', arg: '--version' },
    { id: 'rscript', name: 'Rscript Execution Binary', category: 'runtime' as const, cmd: 'Rscript', arg: '--version' },
    { id: 'python3', name: 'Python 3 Environment', category: 'runtime' as const, cmd: 'python3', arg: '--version' },
    { id: 'git', name: 'Git Version Control System', category: 'vcs' as const, cmd: 'git', arg: '--version' },
    { id: 'node', name: 'Node.js JavaScript/TypeScript Engine', category: 'runtime' as const, cmd: 'node', arg: '-v' },
    { id: 'npm', name: 'Node Package Manager (npm)', category: 'build-tool' as const, cmd: 'npm', arg: '-v' },
    { id: 'gcc', name: 'GNU Compiler Collection (gcc)', category: 'compiler' as const, cmd: 'gcc', arg: '--version' },
  ];

  const results: ToolchainInfo[] = [];

  for (const t of tools) {
    const which = await execPromise('which', [t.cmd]);
    const binPath = which.exitCode === 0 ? which.stdout.trim() : null;
    let versionStr: string | null = null;
    let available = false;

    if (binPath) {
      const ver = await execPromise(t.cmd, [t.arg]);
      if (ver.exitCode === 0) {
        available = true;
        versionStr = ver.stdout.split('\n')[0].trim();
      }
    }

    results.push({
      id: t.id,
      name: t.name,
      category: t.category,
      version: versionStr,
      executablePath: binPath,
      available,
      statusText: available ? 'Installed and verified' : 'Not installed / not in PATH',
      verifiedAt: new Date().toISOString(),
    });
  }

  res.json({ toolchains: results });
});

// -------------------------------------------------------------
// 2. WORKSPACE MANAGEMENT & ARCHITECTURE DETECTION
// -------------------------------------------------------------
const DEFAULT_WORKSPACES = [
  {
    id: 'rust-web',
    name: 'rust-web',
    path: resolve('/app/applet/workspaces/rust-web'),
    description: 'Linux-native Rust HTTP microservice with health endpoints, JSON metrics, and unit tests',
    type: 'rust',
  },
  {
    id: 'r-analysis',
    name: 'r-analysis',
    path: resolve('/app/applet/workspaces/r-analysis'),
    description: 'R computational pipeline, statistical regression modeling, and vector SVG plot generator',
    type: 'r',
  },
  {
    id: 'static-site',
    name: 'static-site',
    path: resolve('/app/applet/workspaces/static-site'),
    description: 'High-performance static telemetry visualizer with canvas charting and live simulation',
    type: 'static',
  },
];

app.get('/api/workspaces', async (req, res): Promise<void> => {
  const verifiedList = [];
  for (const ws of DEFAULT_WORKSPACES) {
    verifiedList.push({
      ...ws,
      exists: existsSync(ws.path),
    });
  }
  res.json({ workspaces: verifiedList });
});

// Detect architecture and propose launch plan
async function detectWorkspaceArchitecture(wsPath: string) {
  const signals: Array<{ file: string; significance: string }> = [];
  let projectType = 'generic';
  let primaryLanguage = 'unknown';

  const hasCargo = existsSync(join(wsPath, 'Cargo.toml'));
  const hasRproj = existsSync(join(wsPath, 'DESCRIPTION')) || existsSync(join(wsPath, 'app.R'));
  const hasPkgJson = existsSync(join(wsPath, 'package.json'));
  const hasIndexHtml = existsSync(join(wsPath, 'index.html'));

  let buildCommand = '';
  let buildArgs: string[] = [];
  let testCommand = '';
  let testArgs: string[] = [];
  let startCommand = '';
  let startArgs: string[] = [];
  let defaultPort = 8080;
  let healthPath = '/health';
  let requiredToolchains: string[] = [];

  if (hasCargo) {
    signals.push({ file: 'Cargo.toml', significance: 'Rust crate manifest detected. Cargo is the build system.' });
    projectType = 'rust-web';
    primaryLanguage = 'Rust';
    requiredToolchains = ['cargo', 'rustc'];
    buildCommand = 'cargo';
    buildArgs = ['build'];
    testCommand = 'cargo';
    testArgs = ['test'];

    startCommand = `cargo`;
    startArgs = ['run'];
    defaultPort = 8080;
    healthPath = '/health';
  } else if (hasRproj || existsSync(join(wsPath, 'scripts', 'analysis.R'))) {
    signals.push({ file: existsSync(join(wsPath, 'app.R')) ? 'app.R' : 'DESCRIPTION', significance: 'R project environment detected.' });
    projectType = 'r-analytics';
    primaryLanguage = 'R';
    requiredToolchains = ['R', 'Rscript'];
    buildCommand = 'Rscript';
    buildArgs = ['-e', "cat('[R-VALIDATE] Checking syntax...\\n'); parse('app.R'); cat('[R-VALIDATE] Syntax valid.\\n')"];
    testCommand = 'Rscript';
    testArgs = ['scripts/analysis.R'];
    startCommand = 'Rscript';
    startArgs = ['app.R'];
    defaultPort = 8081;
    healthPath = '/health';
  } else if (hasPkgJson) {
    signals.push({ file: 'package.json', significance: 'Node.js manifest detected.' });
    projectType = 'node-web';
    primaryLanguage = 'JavaScript/TypeScript';
    requiredToolchains = ['node', 'npm'];
    buildCommand = 'npm';
    buildArgs = ['run', 'build'];
    testCommand = 'npm';
    testArgs = ['test'];
    startCommand = 'npm';
    startArgs = ['start'];
    defaultPort = 8082;
    healthPath = '/';
  } else if (hasIndexHtml) {
    signals.push({ file: 'index.html', significance: 'Static HTML application detected.' });
    projectType = 'static-web';
    primaryLanguage = 'HTML/CSS/JS';
    requiredToolchains = ['node', 'python3'];
    buildCommand = 'echo';
    buildArgs = ['Static project verified. No compilation required.'];
    testCommand = 'echo';
    testArgs = ['Static integrity check passed.'];
    startCommand = 'python3';
    startArgs = ['-m', 'http.server', '8082'];
    defaultPort = 8082;
    healthPath = '/';
  }

  return {
    projectType,
    primaryLanguage,
    signals,
    launchPlan: {
      requiredToolchains,
      buildCommand,
      buildArgs,
      testCommand,
      testArgs,
      startCommand,
      startArgs,
      port: defaultPort,
      healthPath,
      workingDir: wsPath,
      shutdownSignal: 'SIGTERM',
    },
  };
}

// Inspect workspace
app.post('/api/workspace/inspect', async (req, res): Promise<void> => {
  try {
    const rawPath = req.body?.path || DEFAULT_WORKSPACES[0].path;
    const wsPath = resolve(rawPath);

    if (!existsSync(wsPath)) {
      res.status(404).json({ error: `Path does not exist: ${wsPath}` });
      return;
    }

    const arch = await detectWorkspaceArchitecture(wsPath);

    // Read top-level summary
    const entries = await fs.readdir(wsPath, { withFileTypes: true });
    const fileCount = entries.filter((e) => e.isFile()).length;
    const dirCount = entries.filter((e) => e.isDirectory()).length;

    res.json({
      path: wsPath,
      name: basename(wsPath),
      fileCount,
      dirCount,
      ...arch,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// -------------------------------------------------------------
// 3. FILE SYSTEM TREE & OPERATIONS
// -------------------------------------------------------------
const IGNORE_DIRS = new Set(['.git', 'target', 'node_modules', '.Rproj.user', '.venv', '__pycache__']);

async function getDirTree(dirPath: string, rootPath: string, depth = 0): Promise<any[]> {
  if (depth > 6) return [];
  const entries = await fs.readdir(dirPath, { withFileTypes: true });
  const result: any[] = [];

  for (const entry of entries) {
    if (IGNORE_DIRS.has(entry.name)) continue;
    const fullPath = join(dirPath, entry.name);
    const relPath = relative(rootPath, fullPath);

    if (entry.isDirectory()) {
      const children = await getDirTree(fullPath, rootPath, depth + 1);
      result.push({
        name: entry.name,
        path: fullPath,
        relPath,
        type: 'directory',
        children,
      });
    } else if (entry.isFile()) {
      const stats = await fs.stat(fullPath);
      result.push({
        name: entry.name,
        path: fullPath,
        relPath,
        type: 'file',
        size: stats.size,
        modifiedAt: stats.mtime.toISOString(),
        extension: extname(entry.name).toLowerCase(),
      });
    }
  }

  result.sort((a, b) => {
    if (a.type !== b.type) return a.type === 'directory' ? -1 : 1;
    return a.name.localeCompare(b.name);
  });

  return result;
}

app.get('/api/fs/tree', async (req, res): Promise<void> => {
  try {
    const wsPath = resolve((req.query['path'] as string) || DEFAULT_WORKSPACES[0].path);
    if (!existsSync(wsPath)) {
      res.status(404).json({ error: 'Workspace path not found' });
      return;
    }
    const tree = await getDirTree(wsPath, wsPath);
    res.json({ root: wsPath, tree });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/fs/read', async (req, res): Promise<void> => {
  try {
    const filePath = resolve(req.query['path'] as string);
    if (!existsSync(filePath)) {
      res.status(404).json({ error: 'File not found' });
      return;
    }
    const stats = await fs.stat(filePath);
    if (stats.size > 2 * 1024 * 1024) {
      res.status(400).json({ error: 'File exceeds 2MB limit for editor viewing' });
      return;
    }

    const ext = extname(filePath).toLowerCase();
    const isBinary = ['.png', '.jpg', '.jpeg', '.gif', '.ico', '.pdf', '.wasm'].includes(ext);

    if (isBinary) {
      const buffer = await fs.readFile(filePath);
      res.json({
        path: filePath,
        isBinary: true,
        base64: buffer.toString('base64'),
        size: stats.size,
      });
      return;
    }

    const content = await fs.readFile(filePath, 'utf-8');
    const lines = content.split('\n').length;
    res.json({
      path: filePath,
      name: basename(filePath),
      isBinary: false,
      content,
      size: stats.size,
      lines,
      extension: ext,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/fs/write', async (req, res): Promise<void> => {
  try {
    const { path: filePath, content } = req.body;
    if (!filePath || content === undefined) {
      res.status(400).json({ error: 'Missing path or content' });
      return;
    }
    const target = resolve(filePath);
    await fs.writeFile(target, content, 'utf-8');
    res.json({ ok: true, path: target, savedAt: new Date().toISOString() });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/fs/create', async (req, res): Promise<void> => {
  try {
    const { path: targetPath, type } = req.body;
    const target = resolve(targetPath);
    if (type === 'directory') {
      await fs.mkdir(target, { recursive: true });
    } else {
      await fs.mkdir(dirname(target), { recursive: true });
      await fs.writeFile(target, '', 'utf-8');
    }
    res.json({ ok: true, path: target });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/fs/delete', async (req, res): Promise<void> => {
  try {
    const { path: targetPath } = req.body;
    const target = resolve(targetPath);
    if (!existsSync(target)) {
      res.status(404).json({ error: 'Path not found' });
      return;
    }
    const stats = await fs.stat(target);
    if (stats.isDirectory()) {
      await fs.rm(target, { recursive: true, force: true });
    } else {
      await fs.unlink(target);
    }
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// -------------------------------------------------------------
// 4. BUILD ENGINE & JOB ORCHESTRATOR
// -------------------------------------------------------------
app.get('/api/build/jobs', (req, res): void => {
  res.json({ jobs: jobHistory.slice(-20).reverse() });
});

app.post('/api/build/run', async (req, res): Promise<void> => {
  try {
    const { workspacePath, command, args } = req.body;
    if (!command) {
      res.status(400).json({ error: 'Missing command' });
      return;
    }

    const ws = resolve(workspacePath || DEFAULT_WORKSPACES[0].path);
    const jobId = `job_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const job: BuildJob = {
      id: jobId,
      workspacePath: ws,
      command,
      args: Array.isArray(args) ? args : [],
      status: 'running',
      startTime: new Date().toISOString(),
      logs: [],
      diagnostics: [],
    };

    job.logs.push({
      stream: 'system',
      text: `[BUILD-ENGINE] Initiating job ${jobId}: ${command} ${job.args.join(' ')}`,
      time: new Date().toISOString(),
    });
    job.logs.push({
      stream: 'system',
      text: `[BUILD-ENGINE] Working Directory: ${ws}`,
      time: new Date().toISOString(),
    });

    jobHistory.push(job);

    const child = spawn(command, job.args, {
      cwd: ws,
      env: {
        ...process.env,
        PATH: `${process.env['PATH'] || ''}:/root/.cargo/bin:/usr/bin:/usr/local/bin`,
        RUST_BACKTRACE: '1',
        CI: 'true',
        FORCE_COLOR: '0',
      },
    });

    activeBuildProcess = { job, process: child };
    const startTimeMs = Date.now();

    child.stdout?.on('data', (data) => {
      const text = data.toString();
      job.logs.push({ stream: 'stdout', text, time: new Date().toISOString() });
      parseCompilerDiagnostics(text, job);
    });

    child.stderr?.on('data', (data) => {
      const text = data.toString();
      job.logs.push({ stream: 'stderr', text, time: new Date().toISOString() });
      parseCompilerDiagnostics(text, job);
    });

    child.on('close', (code) => {
      job.exitCode = code;
      job.status = code === 0 ? 'success' : 'failed';
      job.endTime = new Date().toISOString();
      job.durationMs = Date.now() - startTimeMs;
      job.logs.push({
        stream: 'system',
        text: `[BUILD-ENGINE] Process exited with code ${code} (${job.status.toUpperCase()}) in ${job.durationMs}ms`,
        time: new Date().toISOString(),
      });
      activeBuildProcess = null;
    });

    child.on('error', (err) => {
      job.status = 'failed';
      job.exitCode = -1;
      job.endTime = new Date().toISOString();
      job.durationMs = Date.now() - startTimeMs;
      job.logs.push({
        stream: 'system',
        text: `[BUILD-ENGINE] Fatal execution error: ${err.message}`,
        time: new Date().toISOString(),
      });
      activeBuildProcess = null;
    });

    res.json({ ok: true, jobId, job });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

function parseCompilerDiagnostics(text: string, job: BuildJob) {
  const lines = text.split('\n');
  for (const line of lines) {
    const rustMatch = line.match(/(error|warning)(?:\[E\d+\])?: (.*)/i);
    if (rustMatch) {
      job.diagnostics.push({
        severity: rustMatch[1].toLowerCase() as any,
        message: rustMatch[2].trim(),
      });
    }
  }
}

app.post('/api/build/cancel', (req, res): void => {
  if (activeBuildProcess && activeBuildProcess.process) {
    activeBuildProcess.process.kill('SIGTERM');
    activeBuildProcess.job.status = 'cancelled';
    activeBuildProcess.job.endTime = new Date().toISOString();
    activeBuildProcess.job.logs.push({
      stream: 'system',
      text: '[BUILD-ENGINE] Job cancelled by operator (SIGTERM)',
      time: new Date().toISOString(),
    });
    activeBuildProcess = null;
    res.json({ ok: true, message: 'Build job cancelled' });
    return;
  }
  res.json({ ok: false, message: 'No active build job running' });
});

// -------------------------------------------------------------
// 5. MANAGED WEB PROCESS SUPERVISOR & READINESS PROBER
// -------------------------------------------------------------
app.get('/api/process/status', (req, res): void => {
  if (!managedProcess) {
    res.json({ process: null });
    return;
  }
  res.json({ process: managedProcess.model });
});

app.post('/api/process/start', async (req, res): Promise<void> => {
  try {
    const { workspacePath, command, args, port = 8080, healthPath = '/health' } = req.body;
    if (!command) {
      res.status(400).json({ error: 'Missing start command' });
      return;
    }

    const ws = resolve(workspacePath || DEFAULT_WORKSPACES[0].path);

    if (managedProcess && managedProcess.process) {
      try {
        managedProcess.process.kill('SIGTERM');
      } catch (e) {}
      if (managedProcess.proberTimer) clearInterval(managedProcess.proberTimer);
    }

    const procModel: ManagedProcess = {
      id: `proc_${Date.now()}`,
      workspacePath: ws,
      name: basename(ws),
      command,
      args: Array.isArray(args) ? args : [],
      pid: null,
      port,
      healthPath,
      status: 'starting',
      startTime: new Date().toISOString(),
      logs: [],
    };

    procModel.logs.push({
      stream: 'system',
      text: `[SUPERVISOR] Starting service: ${command} ${procModel.args.join(' ')} on port ${port}`,
      time: new Date().toISOString(),
    });

    const child = spawn(command, procModel.args, {
      cwd: ws,
      env: {
        ...process.env,
        PATH: `${process.env['PATH'] || ''}:/root/.cargo/bin:/usr/bin:/usr/local/bin`,
        PORT: String(port),
        RUST_BACKTRACE: '1',
      },
    });

    procModel.pid = child.pid || null;

    child.stdout?.on('data', (d) => {
      procModel.logs.push({ stream: 'stdout', text: d.toString(), time: new Date().toISOString() });
    });

    child.stderr?.on('data', (d) => {
      procModel.logs.push({ stream: 'stderr', text: d.toString(), time: new Date().toISOString() });
    });

    child.on('close', (code) => {
      procModel.status = 'stopped';
      procModel.exitCode = code;
      procModel.logs.push({
        stream: 'system',
        text: `[SUPERVISOR] Process terminated with exit code ${code}`,
        time: new Date().toISOString(),
      });
      if (managedProcess?.proberTimer) clearInterval(managedProcess.proberTimer);
    });

    child.on('error', (err) => {
      procModel.status = 'failed';
      procModel.logs.push({
        stream: 'system',
        text: `[SUPERVISOR] Process error: ${err.message}`,
        time: new Date().toISOString(),
      });
      if (managedProcess?.proberTimer) clearInterval(managedProcess.proberTimer);
    });

    let probeCount = 0;
    const proberTimer = setInterval(async () => {
      probeCount++;
      if (procModel.status === 'stopped' || procModel.status === 'failed') {
        clearInterval(proberTimer);
        return;
      }

      const probeUrl = `http://127.0.0.1:${port}${healthPath}`;
      const startMs = Date.now();
      try {
        const response = await fetch(probeUrl, { signal: AbortSignal.timeout(2000) });
        const latencyMs = Date.now() - startMs;
        const ok = response.ok;
        procModel.lastHealthCheck = {
          time: new Date().toISOString(),
          ok,
          status: response.status,
          latencyMs,
        };

        if (ok) {
          procModel.status = 'ready';
          procModel.logs.push({
            stream: 'system',
            text: `[READINESS-PROBER] Endpoint ${healthPath} responded 200 OK (${latencyMs}ms). Service is READY.`,
            time: new Date().toISOString(),
          });
          clearInterval(proberTimer);
        } else {
          procModel.status = 'unhealthy';
        }
      } catch (err: any) {
        procModel.lastHealthCheck = {
          time: new Date().toISOString(),
          ok: false,
          status: 0,
          latencyMs: Date.now() - startMs,
          error: err.message,
        };
        if (probeCount > 25) {
          procModel.status = 'unhealthy';
          clearInterval(proberTimer);
        }
      }
    }, 1000);

    managedProcess = { model: procModel, process: child, proberTimer };
    res.json({ ok: true, process: procModel });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/process/stop', (req, res): void => {
  if (managedProcess && managedProcess.process) {
    try {
      managedProcess.process.kill('SIGTERM');
      managedProcess.model.status = 'stopped';
      if (managedProcess.proberTimer) clearInterval(managedProcess.proberTimer);
      res.json({ ok: true, message: 'Process stopped' });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  } else {
    res.json({ ok: true, message: 'No process running' });
  }
});

// -------------------------------------------------------------
// 6. EMBEDDED WEB PREVIEW REVERSE PROXY
// -------------------------------------------------------------
app.use('/api/proxy/:port', async (req, res): Promise<void> => {
  const port = parseInt(req.params.port, 10);
  if (isNaN(port) || port < 1024 || port > 65535) {
    res.status(400).send('Invalid port');
    return;
  }

  const targetPath = req.url.startsWith('/') ? req.url : '/' + req.url;
  const targetUrl = `http://127.0.0.1:${port}${targetPath}`;

  try {
    const proxyReq = http.request(
      targetUrl,
      {
        method: req.method,
        headers: {
          ...req.headers,
          host: `127.0.0.1:${port}`,
          'accept-encoding': 'identity',
        },
      },
      (proxyRes) => {
        const contentType = proxyRes.headers['content-type'] || 'text/html';
        res.status(proxyRes.statusCode || 200);

        for (const [key, val] of Object.entries(proxyRes.headers)) {
          if (key.toLowerCase() !== 'content-security-policy') {
            res.setHeader(key, val as any);
          }
        }

        if (contentType.includes('text/html')) {
          let body = '';
          proxyRes.setEncoding('utf-8');
          proxyRes.on('data', (chunk) => {
            body += chunk;
          });
          proxyRes.on('end', () => {
            if (!body.includes('<base ') && body.includes('<head>')) {
              body = body.replace('<head>', `<head><base href="/api/proxy/${port}/">`);
            }
            res.send(body);
          });
        } else {
          proxyRes.pipe(res);
        }
      }
    );

    proxyReq.on('error', (err) => {
      res.status(502).send(`
        <div style="font-family: monospace; padding: 2rem; background: #0f172a; color: #f87171; height: 100vh;">
          <h3>502 Bad Gateway: Target Service Not Responding</h3>
          <p>Could not connect to port <strong>${port}</strong> at <code>${targetPath}</code>.</p>
          <p style="color: #94a3b8;">Ensure the service has built and been launched via the <strong>Web Runtime</strong> panel.</p>
          <pre style="background: #020617; padding: 1rem; border-radius: 6px; border: 1px solid #1e293b;">${err.message}</pre>
        </div>
      `);
    });

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      req.pipe(proxyReq);
    } else {
      proxyReq.end();
    }
  } catch (e: any) {
    res.status(500).send(`Proxy exception: ${e.message}`);
  }
});

// -------------------------------------------------------------
// 7. GIT INTEGRATION
// -------------------------------------------------------------
app.get('/api/git/status', async (req, res): Promise<void> => {
  try {
    const ws = resolve((req.query['path'] as string) || DEFAULT_WORKSPACES[0].path);
    const branchRes = await execPromise('git', ['branch', '--show-current'], ws);
    const statusRes = await execPromise('git', ['status', '--porcelain', '-b'], ws);
    const logRes = await execPromise('git', ['log', '-n', '8', '--pretty=format:%h|%an|%ar|%s'], ws);

    const commits = logRes.stdout.split('\n').filter(Boolean).map((line) => {
      const [hash, author, date, message] = line.split('|');
      return { hash, author, date, message };
    });

    const statusLines = statusRes.stdout.split('\n').filter((l) => l && !l.startsWith('##'));
    const changedFiles = statusLines.map((l) => {
      const code = l.substring(0, 2).trim();
      const file = l.substring(3).trim();
      return { code, file };
    });

    res.json({
      branch: branchRes.stdout.trim() || 'main',
      changedFiles,
      commits,
      clean: changedFiles.length === 0,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/git/commit', async (req, res): Promise<void> => {
  try {
    const { path: wsPath, message } = req.body;
    if (!message) {
      res.status(400).json({ error: 'Commit message required' });
      return;
    }
    const ws = resolve(wsPath || DEFAULT_WORKSPACES[0].path);

    await execPromise('git', ['add', '-A'], ws);
    const commitRes = await execPromise('git', ['commit', '-m', message], ws);

    res.json({
      ok: commitRes.exitCode === 0,
      output: commitRes.stdout || commitRes.stderr,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// -------------------------------------------------------------
// 8. R COMPUTATIONAL WORKSPACE (STATISTICAL & PLOT EVALUATION)
// -------------------------------------------------------------
app.post('/api/r/eval', async (req, res): Promise<void> => {
  try {
    const { code, workspacePath } = req.body;
    if (!code) {
      res.status(400).json({ error: 'Missing R code' });
      return;
    }
    const ws = resolve(workspacePath || DEFAULT_WORKSPACES[1].path);

    const tmpScript = join(os.tmpdir(), `r_eval_${Date.now()}.R`);
    await fs.writeFile(tmpScript, code, 'utf-8');

    const result = await execPromise('Rscript', [tmpScript], ws, 10000);
    await fs.unlink(tmpScript).catch(() => {});

    res.json({
      stdout: result.stdout,
      stderr: result.stderr,
      exitCode: result.exitCode,
      success: result.exitCode === 0,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/r/plot-svg', async (req, res): Promise<void> => {
  try {
    const ws = resolve((req.query['path'] as string) || DEFAULT_WORKSPACES[1].path);
    const svgPath = join(ws, 'output_plot.svg');

    if (!existsSync(svgPath)) {
      await execPromise('Rscript', ['scripts/plot.R'], ws);
    }

    if (existsSync(svgPath)) {
      const svg = await fs.readFile(svgPath, 'utf-8');
      res.setHeader('Content-Type', 'image/svg+xml');
      res.send(svg);
      return;
    }
    res.status(404).send('Plot SVG not generated');
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// -------------------------------------------------------------
// 9. SYSTEM DIAGNOSTICS & TELEMETRY
// -------------------------------------------------------------
app.get('/api/diagnostics', async (req, res): Promise<void> => {
  const mem = process.memoryUsage();
  res.json({
    platform: os.platform(),
    release: os.release(),
    architecture: os.arch(),
    cpus: os.cpus().length,
    totalMemMb: Math.round(os.totalmem() / 1024 / 1024),
    freeMemMb: Math.round(os.freemem() / 1024 / 1024),
    processUptimeSec: Math.round(process.uptime()),
    nodeVersion: process.version,
    memoryUsageMb: {
      rss: Math.round(mem.rss / 1024 / 1024),
      heapTotal: Math.round(mem.heapTotal / 1024 / 1024),
      heapUsed: Math.round(mem.heapUsed / 1024 / 1024),
    },
    activeJobsCount: jobHistory.filter((j) => j.status === 'running').length,
    activeProcessRunning: !!(managedProcess && managedProcess.model.status === 'ready'),
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
