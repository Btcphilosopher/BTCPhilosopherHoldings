import { Injectable, signal, computed, PLATFORM_ID, inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

export interface Toolchain {
  id: string;
  name: string;
  category: 'compiler' | 'runtime' | 'vcs' | 'build-tool';
  version: string | null;
  executablePath: string | null;
  available: boolean;
  statusText: string;
  verifiedAt: string;
}

export interface WorkspaceItem {
  id: string;
  name: string;
  path: string;
  description: string;
  type: string;
  exists?: boolean;
}

export interface FileNode {
  name: string;
  path: string;
  relPath: string;
  type: 'file' | 'directory';
  size?: number;
  modifiedAt?: string;
  extension?: string;
  children?: FileNode[];
  isExpanded?: boolean;
}

export interface OpenTab {
  path: string;
  name: string;
  content: string;
  originalContent: string;
  isDirty: boolean;
  extension: string;
  isBinary?: boolean;
  base64?: string;
  lines?: number;
  size?: number;
}

export interface LaunchPlan {
  requiredToolchains: string[];
  buildCommand: string;
  buildArgs: string[];
  testCommand: string;
  testArgs: string[];
  startCommand: string;
  startArgs: string[];
  port: number;
  healthPath: string;
  workingDir: string;
  shutdownSignal: string;
}

export interface ArchitectureInfo {
  path: string;
  name: string;
  projectType: string;
  primaryLanguage: string;
  fileCount: number;
  dirCount: number;
  signals: Array<{ file: string; significance: string }>;
  launchPlan: LaunchPlan;
}

export interface BuildJob {
  id: string;
  workspacePath: string;
  command: string;
  args: string[];
  status: 'running' | 'success' | 'failed' | 'cancelled';
  startTime: string;
  endTime?: string;
  durationMs?: number;
  exitCode?: number | null;
  logs: Array<{ stream: 'stdout' | 'stderr' | 'system'; text: string; time: string }>;
  diagnostics: Array<{ file?: string; line?: number; col?: number; severity: 'error' | 'warning' | 'info'; message: string }>;
}

export interface ManagedProcess {
  id: string;
  workspacePath: string;
  name: string;
  command: string;
  args: string[];
  pid: number | null;
  port: number;
  healthPath: string;
  status: 'stopped' | 'starting' | 'ready' | 'unhealthy' | 'failed';
  startTime?: string;
  exitCode?: number | null;
  logs: Array<{ stream: 'stdout' | 'stderr' | 'system'; text: string; time: string }>;
  lastHealthCheck?: { time: string; ok: boolean; status: number; latencyMs: number; error?: string };
}

export interface GitInfo {
  branch: string;
  changedFiles: Array<{ code: string; file: string }>;
  commits: Array<{ hash: string; author: string; date: string; message: string }>;
  clean: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class StudioService {
  // Signals for state management
  readonly workspaces = signal<WorkspaceItem[]>([]);
  readonly currentWorkspacePath = signal<string>('/app/applet/workspaces/rust-web');
  readonly architecture = signal<ArchitectureInfo | null>(null);
  readonly fileTree = signal<FileNode[]>([]);
  readonly openTabs = signal<OpenTab[]>([]);
  readonly activeTabPath = signal<string | null>(null);

  readonly toolchains = signal<Toolchain[]>([]);
  readonly activeBuildJob = signal<BuildJob | null>(null);
  readonly jobHistory = signal<BuildJob[]>([]);
  readonly managedProcess = signal<ManagedProcess | null>(null);
  readonly gitStatus = signal<GitInfo | null>(null);
  readonly rPlotSvg = signal<string | null>(null);
  readonly systemDiagnostics = signal<any>(null);

  // UI layout signals
  readonly activeBottomTab = signal<'runtime' | 'build' | 'tests' | 'terminal' | 'r-analytics' | 'git'>('runtime');
  readonly bottomTrayExpanded = signal<boolean>(true);
  readonly sidebarTab = signal<'files' | 'git' | 'toolchains'>('files');
  readonly previewViewport = signal<'desktop' | 'tablet' | 'mobile'>('desktop');
  readonly isSidebarOpen = signal<boolean>(true);
  readonly isInspectorOpen = signal<boolean>(true);

  // Derived state
  readonly activeTab = computed(() => {
    const p = this.activeTabPath();
    if (!p) return null;
    return this.openTabs().find((t) => t.path === p) || null;
  });

  readonly isProcessRunning = computed(() => {
    const p = this.managedProcess();
    return p && (p.status === 'ready' || p.status === 'starting');
  });

  private readonly platformId = inject(PLATFORM_ID);

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      this.refreshAll();
    }
  }

  async refreshAll() {
    await this.fetchToolchains();
    await this.fetchWorkspaces();
    await this.openWorkspace(this.currentWorkspacePath());
    await this.fetchProcessStatus();
    await this.fetchDiagnostics();
  }

  async fetchToolchains() {
    try {
      const res = await fetch('/api/toolchains');
      const data = await res.json();
      if (data.toolchains) {
        this.toolchains.set(data.toolchains);
      }
    } catch (e) {
      console.error('Failed to load toolchains', e);
    }
  }

  async fetchWorkspaces() {
    try {
      const res = await fetch('/api/workspaces');
      const data = await res.json();
      if (data.workspaces) {
        this.workspaces.set(data.workspaces);
      }
    } catch (e) {
      console.error('Failed to load workspaces', e);
    }
  }

  async openWorkspace(path: string) {
    this.currentWorkspacePath.set(path);
    try {
      // 1. Inspect architecture & launch plan
      const res = await fetch('/api/workspace/inspect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path }),
      });
      const data = await res.json();
      this.architecture.set(data);

      // 2. Fetch File Tree
      await this.fetchFileTree(path);

      // 3. Fetch Git status
      await this.fetchGitStatus(path);

      // 4. If R project, try fetching plot
      if (data.projectType === 'r-analytics') {
        this.fetchRPlot(path);
      }

      // 5. Auto open primary file (e.g. main.rs, app.R, or index.html)
      this.autoOpenPrimaryFile();
    } catch (e) {
      console.error('Failed to inspect workspace', e);
    }
  }

  async fetchFileTree(path: string) {
    try {
      const res = await fetch(`/api/fs/tree?path=${encodeURIComponent(path)}`);
      const data = await res.json();
      if (data.tree) {
        this.fileTree.set(data.tree);
      }
    } catch (e) {
      console.error('Failed to fetch file tree', e);
    }
  }

  async fetchGitStatus(path: string) {
    try {
      const res = await fetch(`/api/git/status?path=${encodeURIComponent(path)}`);
      const data = await res.json();
      this.gitStatus.set(data);
    } catch (e) {
      console.error('Failed to fetch git status', e);
    }
  }

  async openFile(filePath: string) {
    const existing = this.openTabs().find((t) => t.path === filePath);
    if (existing) {
      this.activeTabPath.set(filePath);
      return;
    }

    try {
      const res = await fetch(`/api/fs/read?path=${encodeURIComponent(filePath)}`);
      const data = await res.json();
      if (data.error) {
        alert(data.error);
        return;
      }

      const newTab: OpenTab = {
        path: filePath,
        name: data.name,
        content: data.content || '',
        originalContent: data.content || '',
        isDirty: false,
        extension: data.extension || '',
        isBinary: data.isBinary,
        base64: data.base64,
        lines: data.lines,
        size: data.size,
      };

      this.openTabs.update((tabs) => [...tabs, newTab]);
      this.activeTabPath.set(filePath);
    } catch (e) {
      console.error('Failed to open file', e);
    }
  }

  closeTab(filePath: string) {
    const tabs = this.openTabs();
    const tab = tabs.find((t) => t.path === filePath);
    if (tab?.isDirty) {
      if (!confirm(`Save changes to ${tab.name} before closing?`)) {
        return;
      }
    }

    const filtered = tabs.filter((t) => t.path !== filePath);
    this.openTabs.set(filtered);

    if (this.activeTabPath() === filePath) {
      this.activeTabPath.set(filtered.length > 0 ? filtered[filtered.length - 1].path : null);
    }
  }

  updateActiveTabContent(newContent: string) {
    const currentPath = this.activeTabPath();
    if (!currentPath) return;

    this.openTabs.update((tabs) =>
      tabs.map((tab) => {
        if (tab.path === currentPath) {
          return {
            ...tab,
            content: newContent,
            isDirty: newContent !== tab.originalContent,
            lines: newContent.split('\n').length,
          };
        }
        return tab;
      })
    );
  }

  async saveActiveTab() {
    const tab = this.activeTab();
    if (!tab || !tab.isDirty) return;

    try {
      const res = await fetch('/api/fs/write', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: tab.path, content: tab.content }),
      });
      const data = await res.json();
      if (data.ok) {
        this.openTabs.update((tabs) =>
          tabs.map((t) => (t.path === tab.path ? { ...t, originalContent: t.content, isDirty: false } : t))
        );
        await this.fetchGitStatus(this.currentWorkspacePath());
      }
    } catch (e) {
      console.error('Failed to save file', e);
    }
  }

  async createNewFile(relPath: string, isDirectory: boolean) {
    const ws = this.currentWorkspacePath();
    const fullPath = `${ws}/${relPath}`;
    try {
      const res = await fetch('/api/fs/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: fullPath, type: isDirectory ? 'directory' : 'file' }),
      });
      const data = await res.json();
      if (data.ok) {
        await this.fetchFileTree(ws);
        if (!isDirectory) {
          await this.openFile(fullPath);
        }
      }
    } catch (e) {
      console.error('Failed to create file', e);
    }
  }

  async deleteFile(targetPath: string) {
    if (!confirm(`Are you sure you want to delete ${targetPath}?`)) return;
    try {
      const res = await fetch('/api/fs/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: targetPath }),
      });
      const data = await res.json();
      if (data.ok) {
        this.closeTab(targetPath);
        await this.fetchFileTree(this.currentWorkspacePath());
      }
    } catch (e) {
      console.error('Failed to delete file', e);
    }
  }

  // Build & Run Workflows
  async executeBuild(command: string, args: string[]) {
    this.activeBottomTab.set('build');
    this.bottomTrayExpanded.set(true);

    try {
      const res = await fetch('/api/build/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workspacePath: this.currentWorkspacePath(),
          command,
          args,
        }),
      });
      const data = await res.json();
      if (data.ok && data.job) {
        this.activeBuildJob.set(data.job);
        this.pollActiveJob(data.jobId);
      }
    } catch (e) {
      console.error('Build execution error', e);
    }
  }

  private pollActiveJob(jobId: string) {
    const interval = setInterval(async () => {
      try {
        const res = await fetch('/api/build/jobs');
        const data = await res.json();
        const found = data.jobs?.find((j: BuildJob) => j.id === jobId);
        if (found) {
          this.activeBuildJob.set(found);
          this.jobHistory.set(data.jobs);
          if (found.status !== 'running') {
            clearInterval(interval);
          }
        }
      } catch (e) {
        clearInterval(interval);
      }
    }, 600);
  }

  async cancelBuild() {
    try {
      await fetch('/api/build/cancel', { method: 'POST' });
    } catch (e) {
      console.error('Cancel build error', e);
    }
  }

  // Web Process Supervisor
  async startWebProcess() {
    const arch = this.architecture();
    if (!arch) return;

    this.activeBottomTab.set('runtime');
    this.bottomTrayExpanded.set(true);

    const plan = arch.launchPlan;
    try {
      const res = await fetch('/api/process/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workspacePath: this.currentWorkspacePath(),
          command: plan.startCommand,
          args: plan.startArgs,
          port: plan.port,
          healthPath: plan.healthPath,
        }),
      });
      const data = await res.json();
      if (data.ok && data.process) {
        this.managedProcess.set(data.process);
        this.startProcessStatusPolling();
      }
    } catch (e) {
      console.error('Process start error', e);
    }
  }

  async stopWebProcess() {
    try {
      await fetch('/api/process/stop', { method: 'POST' });
      await this.fetchProcessStatus();
    } catch (e) {
      console.error('Process stop error', e);
    }
  }

  startProcessStatusPolling() {
    const timer = setInterval(async () => {
      const p = await this.fetchProcessStatus();
      if (!p || p.status === 'stopped' || p.status === 'failed') {
        clearInterval(timer);
      }
    }, 1000);
  }

  async fetchProcessStatus(): Promise<ManagedProcess | null> {
    try {
      const res = await fetch('/api/process/status');
      const data = await res.json();
      this.managedProcess.set(data.process);
      return data.process;
    } catch (e) {
      return null;
    }
  }

  async fetchRPlot(wsPath: string) {
    try {
      const res = await fetch(`/api/r/plot-svg?path=${encodeURIComponent(wsPath)}`);
      if (res.ok) {
        const svg = await res.text();
        this.rPlotSvg.set(svg);
      }
    } catch (e) {}
  }

  async executeREval(code: string) {
    try {
      const res = await fetch('/api/r/eval', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workspacePath: this.currentWorkspacePath(),
          code,
        }),
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, stderr: e.message };
    }
  }

  async fetchDiagnostics() {
    try {
      const res = await fetch('/api/diagnostics');
      const data = await res.json();
      this.systemDiagnostics.set(data);
    } catch (e) {}
  }

  private autoOpenPrimaryFile() {
    const tree = this.fileTree();
    const ws = this.currentWorkspacePath();
    if (tree.length === 0) return;

    // Check for standard primary files
    const targets = ['src/main.rs', 'src/lib.rs', 'app.R', 'scripts/analysis.R', 'index.html', 'Cargo.toml'];
    for (const t of targets) {
      const full = `${ws}/${t}`;
      this.openFile(full);
      break;
    }
  }
}
