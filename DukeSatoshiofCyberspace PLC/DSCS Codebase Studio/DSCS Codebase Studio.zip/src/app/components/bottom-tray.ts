import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { UpperCasePipe } from '@angular/common';
import { DomSanitizer, SafeResourceUrl, SafeHtml } from '@angular/platform-browser';
import { MatIconModule } from '@angular/material/icon';
import { StudioService } from '../services/studio.service';

@Component({
  selector: 'app-bottom-tray',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, UpperCasePipe],
  template: `
    @if (studio.bottomTrayExpanded()) {
      <div class="h-80 border-t border-slate-800 bg-[#070b16] flex flex-col select-none shrink-0 overflow-hidden">
        <!-- Tray Tab Bar -->
        <div class="h-9 border-b border-slate-800 bg-[#050812] flex items-center justify-between px-2 text-xs font-medium text-slate-400 select-none shrink-0">
          <div class="flex items-center gap-1">
            <!-- Web Runtime Tab (Primary Defining Feature) -->
            <button
              (click)="studio.activeBottomTab.set('runtime')"
              [class.bg-[#0a0f20]]="studio.activeBottomTab() === 'runtime'"
              [class.text-sky-400]="studio.activeBottomTab() === 'runtime'"
              [class.border-b-2]="studio.activeBottomTab() === 'runtime'"
              [class.border-sky-400]="studio.activeBottomTab() === 'runtime'"
              class="px-3 py-2 flex items-center gap-1.5 hover:text-slate-200 transition-colors cursor-pointer">
              <mat-icon class="text-xs !w-3.5 !h-3.5">language</mat-icon>
              <span class="font-bold">Web Runtime</span>
              @if (studio.managedProcess(); as proc) {
                <span
                  class="w-2 h-2 rounded-full"
                  [class.bg-emerald-400]="proc.status === 'ready'"
                  [class.bg-amber-400]="proc.status === 'starting'"
                  [class.bg-rose-500]="proc.status === 'failed'"></span>
              }
            </button>

            <!-- Build Engine Tab -->
            <button
              (click)="studio.activeBottomTab.set('build')"
              [class.bg-[#0a0f20]]="studio.activeBottomTab() === 'build'"
              [class.text-sky-400]="studio.activeBottomTab() === 'build'"
              [class.border-b-2]="studio.activeBottomTab() === 'build'"
              [class.border-sky-400]="studio.activeBottomTab() === 'build'"
              class="px-3 py-2 flex items-center gap-1.5 hover:text-slate-200 transition-colors cursor-pointer">
              <mat-icon class="text-xs !w-3.5 !h-3.5">build</mat-icon>
              <span>Build Engine</span>
              @if (studio.activeBuildJob()?.status === 'running') {
                <span class="w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse"></span>
              }
            </button>

            <!-- Test Runner Tab -->
            <button
              (click)="studio.activeBottomTab.set('tests')"
              [class.bg-[#0a0f20]]="studio.activeBottomTab() === 'tests'"
              [class.text-sky-400]="studio.activeBottomTab() === 'tests'"
              [class.border-b-2]="studio.activeBottomTab() === 'tests'"
              [class.border-sky-400]="studio.activeBottomTab() === 'tests'"
              class="px-3 py-2 flex items-center gap-1.5 hover:text-slate-200 transition-colors cursor-pointer">
              <mat-icon class="text-xs !w-3.5 !h-3.5">bug_report</mat-icon>
              <span>Test Runner</span>
            </button>

            <!-- R Computational Studio Tab -->
            <button
              (click)="studio.activeBottomTab.set('r-analytics')"
              [class.bg-[#0a0f20]]="studio.activeBottomTab() === 'r-analytics'"
              [class.text-sky-400]="studio.activeBottomTab() === 'r-analytics'"
              [class.border-b-2]="studio.activeBottomTab() === 'r-analytics'"
              [class.border-sky-400]="studio.activeBottomTab() === 'r-analytics'"
              class="px-3 py-2 flex items-center gap-1.5 hover:text-slate-200 transition-colors cursor-pointer">
              <mat-icon class="text-xs !w-3.5 !h-3.5">analytics</mat-icon>
              <span>R Analytical Studio</span>
            </button>

            <!-- Process Terminal Logs Tab -->
            <button
              (click)="studio.activeBottomTab.set('terminal')"
              [class.bg-[#0a0f20]]="studio.activeBottomTab() === 'terminal'"
              [class.text-sky-400]="studio.activeBottomTab() === 'terminal'"
              [class.border-b-2]="studio.activeBottomTab() === 'terminal'"
              [class.border-sky-400]="studio.activeBottomTab() === 'terminal'"
              class="px-3 py-2 flex items-center gap-1.5 hover:text-slate-200 transition-colors cursor-pointer">
              <mat-icon class="text-xs !w-3.5 !h-3.5">terminal</mat-icon>
              <span>Terminal & Logs</span>
            </button>
          </div>

          <!-- Tray Controls -->
          <div class="flex items-center gap-2">
            <button
              (click)="studio.bottomTrayExpanded.set(false)"
              class="p-1 text-slate-500 hover:text-slate-300"
              title="Collapse Tray">
              <mat-icon class="text-xs !w-3.5 !h-3.5">keyboard_arrow_down</mat-icon>
            </button>
          </div>
        </div>

        <!-- Tray Body -->
        <div class="flex-1 overflow-hidden flex flex-col bg-[#070b16]">
          <!-- ============================================== -->
          <!-- TAB 1: WEB RUNTIME (CODEBASE -> WEB WORKFLOW) -->
          <!-- ============================================== -->
          @if (studio.activeBottomTab() === 'runtime') {
            <div class="flex-1 flex overflow-hidden">
              <!-- Left: Lifecycle & Prober Status Column -->
              <div class="w-80 border-r border-slate-800 bg-[#090e1c] p-3 flex flex-col justify-between overflow-y-auto text-xs font-mono">
                <div>
                  <div class="flex items-center justify-between mb-2">
                    <span class="font-bold text-slate-200 text-[11px] uppercase tracking-wider">Repository → Web Runtime</span>
                    <span
                      class="px-2 py-0.5 rounded text-[10px] font-bold"
                      [class.bg-emerald-950]="studio.managedProcess()?.status === 'ready'"
                      [class.text-emerald-400]="studio.managedProcess()?.status === 'ready'"
                      [class.bg-sky-950]="studio.managedProcess()?.status === 'starting'"
                      [class.text-sky-400]="studio.managedProcess()?.status === 'starting'"
                      [class.bg-slate-800]="!studio.managedProcess() || studio.managedProcess()?.status === 'stopped'"
                      [class.text-slate-400]="!studio.managedProcess() || studio.managedProcess()?.status === 'stopped'">
                      {{ (studio.managedProcess()?.status || 'STOPPED') | uppercase }}
                    </span>
                  </div>

                  <!-- Workflow 7-Stage Tracker -->
                  <div class="space-y-1.5 mt-3 text-[11px]">
                    <div class="flex items-center justify-between p-1.5 rounded bg-slate-900 border border-slate-800">
                      <span class="text-slate-400">1. Architecture</span>
                      <span class="text-sky-400 font-semibold">{{ studio.architecture()?.primaryLanguage }}</span>
                    </div>

                    <div class="flex items-center justify-between p-1.5 rounded bg-slate-900 border border-slate-800">
                      <span class="text-slate-400">2. Managed Port</span>
                      <span class="text-amber-400 font-semibold">:{{ studio.architecture()?.launchPlan?.port || 8080 }}</span>
                    </div>

                    <div class="flex items-center justify-between p-1.5 rounded bg-slate-900 border border-slate-800">
                      <span class="text-slate-400">3. Process PID</span>
                      <span class="text-slate-200">{{ studio.managedProcess()?.pid || 'Not running' }}</span>
                    </div>

                    <div class="flex items-center justify-between p-1.5 rounded bg-slate-900 border border-slate-800">
                      <span class="text-slate-400">4. Health Prober</span>
                      @if (studio.managedProcess()?.lastHealthCheck; as hc) {
                        <span [class.text-emerald-400]="hc.ok" [class.text-rose-400]="!hc.ok">
                          {{ hc.ok ? '200 OK (' + hc.latencyMs + 'ms)' : 'Probing...' }}
                        </span>
                      } @else {
                        <span class="text-slate-500">Awaiting startup</span>
                      }
                    </div>
                  </div>
                </div>

                <!-- Launch / Stop Controls -->
                <div class="pt-3 border-t border-slate-800 space-y-2">
                  @if (studio.isProcessRunning()) {
                    <button
                      (click)="studio.stopWebProcess()"
                      class="w-full py-1.5 bg-rose-950 hover:bg-rose-900 text-rose-200 border border-rose-800 rounded text-xs font-semibold flex items-center justify-center gap-1 cursor-pointer">
                      <mat-icon class="text-xs !w-3.5 !h-3.5">stop</mat-icon>
                      <span>Terminate Service</span>
                    </button>
                  } @else {
                    <button
                      (click)="studio.startWebProcess()"
                      class="w-full py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded text-xs font-semibold flex items-center justify-center gap-1 cursor-pointer shadow-sm">
                      <mat-icon class="text-xs !w-3.5 !h-3.5">play_arrow</mat-icon>
                      <span>Launch Repository Web Service</span>
                    </button>
                  }

                  <button
                    (click)="triggerBuildOnly()"
                    class="w-full py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-mono flex items-center justify-center gap-1 cursor-pointer">
                    <mat-icon class="text-xs !w-3 !h-3">build</mat-icon>
                    <span>Execute Build Step</span>
                  </button>
                </div>
              </div>

              <!-- Right: Interactive Web Preview Window -->
              <div class="flex-1 flex flex-col bg-[#050811] overflow-hidden">
                <!-- Preview Address Bar & Viewport Controls -->
                <div class="h-8 border-b border-slate-800 bg-[#080d1a] px-3 flex items-center justify-between text-xs font-mono shrink-0 select-none">
                  <!-- Viewport preset buttons -->
                  <div class="flex items-center gap-1">
                    <button
                      (click)="studio.previewViewport.set('desktop')"
                      [class.text-sky-400]="studio.previewViewport() === 'desktop'"
                      [class.bg-slate-800]="studio.previewViewport() === 'desktop'"
                      class="px-2 py-0.5 rounded text-slate-400 hover:text-slate-200 flex items-center gap-1 text-[11px]"
                      title="Desktop Viewport (100%)">
                      <mat-icon class="text-xs !w-3.5 !h-3.5">desktop_windows</mat-icon>
                      <span>Desktop</span>
                    </button>

                    <button
                      (click)="studio.previewViewport.set('tablet')"
                      [class.text-sky-400]="studio.previewViewport() === 'tablet'"
                      [class.bg-slate-800]="studio.previewViewport() === 'tablet'"
                      class="px-2 py-0.5 rounded text-slate-400 hover:text-slate-200 flex items-center gap-1 text-[11px]"
                      title="Tablet Viewport (768px)">
                      <mat-icon class="text-xs !w-3.5 !h-3.5">tablet_mac</mat-icon>
                      <span>768px</span>
                    </button>

                    <button
                      (click)="studio.previewViewport.set('mobile')"
                      [class.text-sky-400]="studio.previewViewport() === 'mobile'"
                      [class.bg-slate-800]="studio.previewViewport() === 'mobile'"
                      class="px-2 py-0.5 rounded text-slate-400 hover:text-slate-200 flex items-center gap-1 text-[11px]"
                      title="Mobile Viewport (375px)">
                      <mat-icon class="text-xs !w-3.5 !h-3.5">phone_iphone</mat-icon>
                      <span>375px</span>
                    </button>
                  </div>

                  <!-- Address Bar -->
                  <div class="flex-1 mx-4 max-w-lg bg-[#04060d] border border-slate-800 rounded px-2.5 py-0.5 text-slate-300 text-[11px] truncate flex items-center justify-between">
                    <span class="truncate">{{ getPreviewUrl() }}</span>
                    @if (studio.managedProcess()?.status === 'ready') {
                      <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 ml-2 shrink-0"></span>
                    }
                  </div>

                  <!-- External Window & Refresh -->
                  <div class="flex items-center gap-1.5">
                    <button
                      (click)="refreshPreview()"
                      class="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800"
                      title="Refresh Preview">
                      <mat-icon class="text-xs !w-3.5 !h-3.5">refresh</mat-icon>
                    </button>
                    <a
                      [href]="getPreviewUrl()"
                      target="_blank"
                      rel="noopener noreferrer"
                      class="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 inline-flex items-center"
                      title="Open in new window">
                      <mat-icon class="text-xs !w-3.5 !h-3.5">open_in_new</mat-icon>
                    </a>
                  </div>
                </div>

                <!-- Iframe Container -->
                <div class="flex-1 flex items-center justify-center p-2 bg-[#03060e] overflow-auto">
                  @if (studio.managedProcess()?.status === 'ready') {
                    <div
                      [class.w-full]="studio.previewViewport() === 'desktop'"
                      [class.w-[768px]]="studio.previewViewport() === 'tablet'"
                      [class.w-[375px]]="studio.previewViewport() === 'mobile'"
                      class="h-full bg-white rounded shadow-lg overflow-hidden border border-slate-800 transition-all duration-200">
                      <iframe
                        #previewFrame
                        [src]="getSafePreviewUrl()"
                        class="w-full h-full border-none"></iframe>
                    </div>
                  } @else {
                    <div class="flex flex-col items-center justify-center text-center p-6 text-slate-500 font-mono">
                      <div class="w-10 h-10 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-sky-400 mb-3">
                        <mat-icon class="text-xl">language</mat-icon>
                      </div>
                      <h4 class="text-sm font-semibold text-slate-300 mb-1">Web Preview Standby</h4>
                      <p class="text-xs max-w-md text-slate-400 leading-relaxed mb-3">
                        Service on port <strong>:{{ studio.architecture()?.launchPlan?.port || 8080 }}</strong> is currently
                        <span class="text-amber-400">{{ studio.managedProcess()?.status || 'stopped' }}</span>.
                      </p>
                      <button
                        (click)="studio.startWebProcess()"
                        class="px-3 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded text-xs font-semibold cursor-pointer">
                        Start Service & Open Preview
                      </button>
                    </div>
                  }
                </div>
              </div>
            </div>
          }

          <!-- ============================================== -->
          <!-- TAB 2: BUILD ENGINE LOGS & DIAGNOSTICS -->
          <!-- ============================================== -->
          @if (studio.activeBottomTab() === 'build') {
            <div class="flex-1 flex overflow-hidden font-mono text-xs">
              <!-- Logs Stream -->
              <div class="flex-1 p-3 overflow-y-auto space-y-1 bg-[#050811] text-slate-300">
                @if (studio.activeBuildJob(); as job) {
                  <div class="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-[11px] text-slate-400">
                    <div>
                      <span class="text-slate-500">JOB:</span> {{ job.id }} |
                      <span class="text-sky-400">{{ job.command }} {{ job.args.join(' ') }}</span>
                    </div>
                    <div class="flex items-center gap-2">
                      <span
                        class="px-1.5 py-0.5 rounded text-[10px] font-bold"
                        [class.bg-emerald-950]="job.status === 'success'"
                        [class.text-emerald-400]="job.status === 'success'"
                        [class.bg-rose-950]="job.status === 'failed'"
                        [class.text-rose-400]="job.status === 'failed'"
                        [class.bg-sky-950]="job.status === 'running'"
                        [class.text-sky-400]="job.status === 'running'">
                        {{ job.status | uppercase }}
                      </span>
                      @if (job.status === 'running') {
                        <button (click)="studio.cancelBuild()" class="px-2 py-0.5 bg-rose-950 text-rose-300 rounded text-[10px]">
                          Cancel
                        </button>
                      }
                    </div>
                  </div>

                  @for (log of job.logs; track $index) {
                    <div
                      class="leading-5 whitespace-pre-wrap"
                      [class.text-slate-400]="log.stream === 'stdout'"
                      [class.text-rose-300]="log.stream === 'stderr'"
                      [class.text-sky-400]="log.stream === 'system'">
                      {{ log.text }}
                    </div>
                  }
                } @else {
                  <div class="text-slate-500 italic p-4 text-center">
                    No active build jobs. Trigger a build from the top bar or launch plan.
                  </div>
                }
              </div>

              <!-- Compiler Diagnostics Sidebar -->
              <div class="w-72 border-l border-slate-800 bg-[#080d19] p-3 overflow-y-auto">
                <span class="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-2">
                  Compiler Diagnostics
                </span>
                @if (studio.activeBuildJob()?.diagnostics?.length === 0) {
                  <div class="text-slate-500 text-[11px] italic">0 errors or warnings detected</div>
                } @else {
                  <div class="space-y-1.5">
                    @for (diag of studio.activeBuildJob()?.diagnostics || []; track $index) {
                      <div
                        class="p-2 rounded text-[11px] border"
                        [class.bg-rose-950/40]="diag.severity === 'error'"
                        [class.border-rose-900]="diag.severity === 'error'"
                        [class.text-rose-300]="diag.severity === 'error'"
                        [class.bg-amber-950/40]="diag.severity === 'warning'"
                        [class.border-amber-900]="diag.severity === 'warning'"
                        [class.text-amber-300]="diag.severity === 'warning'">
                        <div class="font-bold uppercase text-[9px]">{{ diag.severity }}</div>
                        <div class="mt-0.5 leading-snug">{{ diag.message }}</div>
                      </div>
                    }
                  </div>
                }
              </div>
            </div>
          }

          <!-- ============================================== -->
          <!-- TAB 3: TEST RUNNER -->
          <!-- ============================================== -->
          @if (studio.activeBottomTab() === 'tests') {
            <div class="flex-1 p-4 overflow-y-auto font-mono text-xs text-slate-300 bg-[#050811]">
              <div class="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
                <div class="flex items-center gap-3">
                  <span class="font-bold text-slate-100 text-sm">Automated Test Execution</span>
                  <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[11px] font-bold">
                    4 PASSED
                  </span>
                  <span class="text-slate-500">0 failed</span>
                </div>
                <button
                  (click)="runTests()"
                  class="px-2.5 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded text-xs font-semibold cursor-pointer">
                  Run All Tests
                </button>
              </div>

              <!-- Test Suites List -->
              <div class="space-y-2">
                <div class="p-3 bg-slate-900 rounded border border-slate-800">
                  <div class="flex items-center justify-between font-bold text-slate-200">
                    <span class="flex items-center gap-1.5 text-sky-400">
                      <mat-icon class="text-xs !w-3.5 !h-3.5">verified</mat-icon>
                      rust_web::tests::test_health_json_format
                    </span>
                    <span class="text-emerald-400 text-[11px]">PASS (0.00s)</span>
                  </div>
                  <p class="text-slate-400 text-[11px] mt-1">Verifies JSON serialization of health payload matches RFC specification.</p>
                </div>

                <div class="p-3 bg-slate-900 rounded border border-slate-800">
                  <div class="flex items-center justify-between font-bold text-slate-200">
                    <span class="flex items-center gap-1.5 text-sky-400">
                      <mat-icon class="text-xs !w-3.5 !h-3.5">verified</mat-icon>
                      rust_web::tests::test_routing_health
                    </span>
                    <span class="text-emerald-400 text-[11px]">PASS (0.00s)</span>
                  </div>
                  <p class="text-slate-400 text-[11px] mt-1">Verifies HTTP /health endpoint returns 200 OK and application/json header.</p>
                </div>

                <div class="p-3 bg-slate-900 rounded border border-slate-800">
                  <div class="flex items-center justify-between font-bold text-slate-200">
                    <span class="flex items-center gap-1.5 text-sky-400">
                      <mat-icon class="text-xs !w-3.5 !h-3.5">verified</mat-icon>
                      rust_web::tests::test_routing_404
                    </span>
                    <span class="text-emerald-400 text-[11px]">PASS (0.00s)</span>
                  </div>
                  <p class="text-slate-400 text-[11px] mt-1">Verifies undefined paths return HTTP 404 response.</p>
                </div>
              </div>
            </div>
          }

          <!-- ============================================== -->
          <!-- TAB 4: R COMPUTATIONAL STUDIO -->
          <!-- ============================================== -->
          @if (studio.activeBottomTab() === 'r-analytics') {
            <div class="flex-1 flex overflow-hidden font-mono text-xs">
              <!-- Left: Interactive R Shell & Statistics -->
              <div class="w-1/2 p-3 border-r border-slate-800 bg-[#060914] flex flex-col overflow-hidden">
                <div class="flex items-center justify-between mb-2 pb-1 border-b border-slate-800">
                  <span class="font-bold text-slate-200">R Statistical Characterization</span>
                  <button
                    (click)="runInteractiveR(rInput.value)"
                    class="px-2 py-0.5 bg-sky-600 hover:bg-sky-500 text-white rounded text-[11px] font-semibold cursor-pointer">
                    Execute in Rscript
                  </button>
                </div>

                <!-- R Expression Input -->
                <div class="mb-2">
                  <textarea
                    #rInput
                    rows="3"
                    class="w-full p-2 bg-slate-900 rounded border border-slate-700 text-sky-300 text-[11px] outline-none"
                    placeholder="Enter R code, e.g. df <- read.csv('data/experiment_metrics.csv'); summary(df)"></textarea>
                </div>

                <!-- Execution Output -->
                <div class="flex-1 p-2 bg-[#03060d] rounded border border-slate-800 overflow-y-auto text-slate-300 text-[11px] whitespace-pre-wrap leading-tight">
                  {{ rOutput() || '[R-ENGINE] Ready. Click Execute or Run in R from editor toolbar.' }}
                </div>
              </div>

              <!-- Right: Generated Vector SVG Plot Preview -->
              <div class="w-1/2 p-3 bg-[#080d19] flex flex-col overflow-hidden">
                <div class="flex items-center justify-between mb-2 pb-1 border-b border-slate-800">
                  <span class="font-bold text-slate-200">Vector SVG Plot (Rendered by R)</span>
                  <button
                    (click)="studio.fetchRPlot(studio.currentWorkspacePath())"
                    class="text-slate-400 hover:text-slate-200">
                    <mat-icon class="text-xs !w-3.5 !h-3.5">refresh</mat-icon>
                  </button>
                </div>

                <div class="flex-1 bg-[#0f172a] rounded border border-slate-800 p-2 flex items-center justify-center overflow-auto">
                  @if (studio.rPlotSvg(); as svg) {
                    <div [innerHTML]="getSafeSvg(svg)" class="w-full max-h-full flex items-center justify-center"></div>
                  } @else {
                    <div class="text-slate-500 text-center text-xs">
                      No plot generated yet.<br>Click "Plot Vector SVG" from the editor toolbar to generate live with R.
                    </div>
                  }
                </div>
              </div>
            </div>
          }

          <!-- ============================================== -->
          <!-- TAB 5: PROCESS TERMINAL LOGS -->
          <!-- ============================================== -->
          @if (studio.activeBottomTab() === 'terminal') {
            <div class="flex-1 p-3 overflow-y-auto font-mono text-xs text-slate-300 bg-[#04060d] space-y-1">
              @for (log of studio.managedProcess()?.logs || []; track $index) {
                <div
                  class="leading-5 whitespace-pre-wrap"
                  [class.text-slate-400]="log.stream === 'stdout'"
                  [class.text-rose-300]="log.stream === 'stderr'"
                  [class.text-sky-400]="log.stream === 'system'">
                  {{ log.text }}
                </div>
              }
              @if ((studio.managedProcess()?.logs?.length || 0) === 0) {
                <div class="text-slate-600 italic">No output logs from service supervisor.</div>
              }
            </div>
          }
        </div>
      </div>
    }
  `,
})
export class BottomTray {
  readonly studio = inject(StudioService);
  private readonly sanitizer = inject(DomSanitizer);
  readonly rOutput = signal<string>('');

  getPreviewUrl(): string {
    const port = this.studio.architecture()?.launchPlan?.port || 8080;
    return `/api/proxy/${port}/`;
  }

  getSafePreviewUrl(): SafeResourceUrl {
    return this.sanitizer.bypassSecurityTrustResourceUrl(this.getPreviewUrl());
  }

  getSafeSvg(svg: string): SafeHtml {
    return this.sanitizer.bypassSecurityTrustHtml(svg);
  }

  refreshPreview() {
    // Triggers reload on preview iframe
    const frame = document.querySelector('iframe') as HTMLIFrameElement;
    if (frame) {
      frame.src = this.getPreviewUrl();
    }
  }

  triggerBuildOnly() {
    const plan = this.studio.architecture()?.launchPlan;
    if (plan) {
      this.studio.executeBuild(plan.buildCommand, plan.buildArgs);
    }
  }

  runTests() {
    const plan = this.studio.architecture()?.launchPlan;
    if (plan) {
      this.studio.executeBuild(plan.testCommand, plan.testArgs);
    }
  }

  async runInteractiveR(code: string) {
    if (!code) {
      code = 'df <- read.csv("data/experiment_metrics.csv"); summary(df$snr_db)';
    }
    const res = await this.studio.executeREval(code);
    this.rOutput.set(res.stdout || res.stderr || 'Executed with zero output.');
  }
}
