import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StudioService } from '../services/studio.service';

@Component({
  selector: 'app-topbar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <header class="h-12 border-b border-slate-800 bg-[#0a0f1d] flex items-center justify-between px-4 gap-4 select-none shrink-0 z-20">
      <!-- Zone 1: Brand & Workspace Switcher -->
      <div class="flex items-center gap-3 shrink-0">
        <div class="flex items-center gap-2">
          <div class="w-6 h-6 rounded bg-sky-600/20 border border-sky-500/40 flex items-center justify-center text-sky-400 font-bold text-xs tracking-wider">
            DS
          </div>
          <span class="font-bold text-sm tracking-tight text-slate-100 whitespace-nowrap">
            DSCS CODEBASE STUDIO
          </span>
          <span class="text-xs text-slate-500 font-mono hidden md:inline">| Linux Workstation</span>
        </div>

        <div class="h-4 w-px bg-slate-800 mx-1"></div>

        <!-- Workspace Selector -->
        <div class="flex items-center gap-1.5 bg-[#0e1627] border border-slate-800 rounded px-2 py-1 text-xs text-slate-300">
          <mat-icon class="text-xs !w-4 !h-4 text-sky-400">folder</mat-icon>
          <select
            [value]="studio.currentWorkspacePath()"
            (change)="onWorkspaceChange($event)"
            class="bg-transparent text-slate-200 outline-none text-xs font-mono cursor-pointer pr-1">
            @for (ws of studio.workspaces(); track ws.id) {
              <option [value]="ws.path" class="bg-slate-900 text-slate-200">
                {{ ws.name }} ({{ ws.type }})
              </option>
            }
          </select>
        </div>
      </div>

      <!-- Zone 2: Detected Architecture & Active Toolchain Indicators -->
      <div class="hidden lg:flex items-center gap-3 text-xs text-slate-400 font-mono">
        @if (studio.architecture(); as arch) {
          <div class="flex items-center gap-1.5 px-2 py-0.5 rounded bg-slate-900/80 border border-slate-800">
            <span class="text-slate-500">ARCH:</span>
            <span class="text-sky-300 font-medium">{{ arch.primaryLanguage }}</span>
            <span class="text-slate-600">/</span>
            <span class="text-slate-300">{{ arch.projectType }}</span>
          </div>
        }

        <div class="flex items-center gap-2 text-slate-400">
          @for (tool of primaryToolchains(); track tool.id) {
            <span class="flex items-center gap-1 text-[11px]" [title]="tool.statusText">
              <span class="w-1.5 h-1.5 rounded-full" [class.bg-emerald-400]="tool.available" [class.bg-rose-500]="!tool.available"></span>
              {{ tool.name.split(' ')[0] }}
            </span>
          }
        </div>
      </div>

      <!-- Zone 3: Primary Workstation Actions -->
      <div class="flex items-center gap-2 shrink-0">
        <!-- Quick Cargo / Build Action -->
        <button
          (click)="triggerBuild()"
          class="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 active:bg-slate-900 border border-slate-700 rounded transition-colors whitespace-nowrap cursor-pointer">
          <mat-icon class="text-xs !w-3.5 !h-3.5 text-amber-400">build</mat-icon>
          <span>Build</span>
        </button>

        <!-- Start / Stop Web Runtime Action -->
        @if (studio.isProcessRunning()) {
          <button
            (click)="studio.stopWebProcess()"
            class="flex items-center gap-1.5 px-3 py-1 text-xs font-medium text-rose-200 bg-rose-950/80 hover:bg-rose-900 border border-rose-700/60 rounded transition-colors whitespace-nowrap cursor-pointer">
            <mat-icon class="text-xs !w-3.5 !h-3.5 text-rose-400">stop</mat-icon>
            <span>Stop Service</span>
          </button>
        } @else {
          <button
            (click)="studio.startWebProcess()"
            class="flex items-center gap-1.5 px-3 py-1 text-xs font-medium text-white bg-sky-600 hover:bg-sky-500 active:bg-sky-700 rounded transition-colors whitespace-nowrap cursor-pointer shadow-sm">
            <mat-icon class="text-xs !w-3.5 !h-3.5 text-sky-100">play_arrow</mat-icon>
            <span>Launch Web</span>
          </button>
        }

        <div class="h-4 w-px bg-slate-800 mx-1"></div>

        <!-- Toggle Inspector & Bottom Output -->
        <button
          (click)="toggleBottomTray()"
          class="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          [title]="studio.bottomTrayExpanded() ? 'Collapse Terminal & Web Tray' : 'Expand Terminal & Web Tray'">
          <mat-icon class="text-sm !w-4 !h-4">dock</mat-icon>
        </button>

        <button
          (click)="toggleInspector()"
          class="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          [title]="studio.isInspectorOpen() ? 'Hide Inspector' : 'Show Inspector'">
          <mat-icon class="text-sm !w-4 !h-4">tune</mat-icon>
        </button>
      </div>
    </header>
  `,
})
export class Topbar {
  readonly studio = inject(StudioService);

  primaryToolchains() {
    return this.studio.toolchains().filter((t) => ['rustc', 'cargo', 'r', 'git'].includes(t.id));
  }

  onWorkspaceChange(event: Event) {
    const target = event.target as HTMLSelectElement;
    if (target.value) {
      this.studio.openWorkspace(target.value);
    }
  }

  triggerBuild() {
    const arch = this.studio.architecture();
    if (arch && arch.launchPlan) {
      this.studio.executeBuild(arch.launchPlan.buildCommand, arch.launchPlan.buildArgs);
    }
  }

  toggleBottomTray() {
    this.studio.bottomTrayExpanded.update((v) => !v);
  }

  toggleInspector() {
    this.studio.isInspectorOpen.update((v) => !v);
  }
}
