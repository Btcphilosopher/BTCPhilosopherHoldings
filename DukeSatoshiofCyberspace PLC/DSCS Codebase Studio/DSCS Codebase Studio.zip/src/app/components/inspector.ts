import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StudioService } from '../services/studio.service';

@Component({
  selector: 'app-inspector',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <aside class="w-72 border-l border-slate-800 bg-[#090d18] flex flex-col h-full select-none shrink-0 overflow-y-auto text-xs">
      <!-- Section 1: Architecture Explorer -->
      <div class="p-3 border-b border-slate-800">
        <div class="flex items-center justify-between mb-2">
          <span class="font-bold text-slate-200 uppercase tracking-wider text-[10px]">Architecture Analysis</span>
          <span class="px-1.5 py-0.5 rounded bg-sky-950 text-sky-400 font-mono text-[10px] font-bold">
            {{ studio.architecture()?.primaryLanguage || 'Detecting...' }}
          </span>
        </div>

        @if (studio.architecture(); as arch) {
          <div class="space-y-1.5 font-mono text-[11px] text-slate-400 bg-slate-900/60 p-2.5 rounded border border-slate-800">
            <div class="flex justify-between">
              <span class="text-slate-500">Project Type:</span>
              <span class="text-slate-200 font-semibold">{{ arch.projectType }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-500">Crate/Package:</span>
              <span class="text-slate-200">{{ arch.name }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-500">Structure:</span>
              <span>{{ arch.fileCount }} files / {{ arch.dirCount }} folders</span>
            </div>
          </div>

          <!-- Signals breakdown -->
          <div class="mt-2.5">
            <span class="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Detected Signals</span>
            <div class="mt-1 space-y-1">
              @for (sig of arch.signals; track sig.file) {
                <div class="p-1.5 bg-[#0e1627] rounded border border-slate-800/80 text-[11px]">
                  <div class="font-mono text-sky-400 font-semibold flex items-center gap-1">
                    <mat-icon class="text-xs !w-3 !h-3 text-sky-400">check_circle</mat-icon>
                    {{ sig.file }}
                  </div>
                  <div class="text-slate-400 text-[10px] mt-0.5">{{ sig.significance }}</div>
                </div>
              }
            </div>
          </div>
        }
      </div>

      <!-- Section 2: Launch Plan & Port Management -->
      <div class="p-3 border-b border-slate-800">
        <div class="flex items-center justify-between mb-2">
          <span class="font-bold text-slate-200 uppercase tracking-wider text-[10px]">Proposed Launch Plan</span>
          <span class="text-slate-500 text-[10px] font-mono">PORT ALLOCATION</span>
        </div>

        @if (studio.architecture()?.launchPlan; as plan) {
          <div class="space-y-2 text-[11px] font-mono">
            <div>
              <label class="text-[10px] text-slate-500 block mb-0.5">Build Command</label>
              <div class="px-2 py-1 bg-slate-900 rounded border border-slate-800 text-amber-300">
                {{ plan.buildCommand }} {{ plan.buildArgs.join(' ') }}
              </div>
            </div>

            <div>
              <label class="text-[10px] text-slate-500 block mb-0.5">Startup Command</label>
              <div class="px-2 py-1 bg-slate-900 rounded border border-slate-800 text-sky-300 truncate">
                {{ plan.startCommand }} {{ plan.startArgs.join(' ') }}
              </div>
            </div>

            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="text-[10px] text-slate-500 block mb-0.5">Assigned Port</label>
                <input
                  type="number"
                  [value]="plan.port"
                  (change)="updatePort($event)"
                  class="w-full px-2 py-1 bg-slate-900 rounded border border-slate-800 text-slate-200 text-xs outline-none focus:border-sky-500" />
              </div>
              <div>
                <label class="text-[10px] text-slate-500 block mb-0.5">Health Path</label>
                <input
                  type="text"
                  [value]="plan.healthPath"
                  (change)="updateHealthPath($event)"
                  class="w-full px-2 py-1 bg-slate-900 rounded border border-slate-800 text-slate-200 text-xs outline-none focus:border-sky-500" />
              </div>
            </div>

            <button
              (click)="studio.startWebProcess()"
              class="w-full mt-2 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded font-sans font-semibold text-xs flex items-center justify-center gap-1 cursor-pointer transition-colors shadow-sm">
              <mat-icon class="text-xs !w-3.5 !h-3.5">play_arrow</mat-icon>
              <span>Approve & Launch Web</span>
            </button>
          </div>
        }
      </div>

      <!-- Section 3: Deployment Adapters -->
      <div class="p-3 border-b border-slate-800">
        <span class="font-bold text-slate-200 uppercase tracking-wider text-[10px] block mb-2">Deployment Targets</span>
        <div class="space-y-1.5">
          <div class="p-2 rounded bg-slate-900/60 border border-slate-800 flex items-center justify-between">
            <div>
              <div class="font-semibold text-slate-200 text-[11px]">Linux Systemd Service</div>
              <div class="text-[10px] text-slate-500">Native daemon unit</div>
            </div>
            <button (click)="deployNotice('systemd')" class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[10px] font-mono cursor-pointer">
              Deploy
            </button>
          </div>

          <div class="p-2 rounded bg-slate-900/60 border border-slate-800 flex items-center justify-between">
            <div>
              <div class="font-semibold text-slate-200 text-[11px]">OCI Container / Docker</div>
              <div class="text-[10px] text-slate-500">Containerized image</div>
            </div>
            <button (click)="deployNotice('docker')" class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[10px] font-mono cursor-pointer">
              Package
            </button>
          </div>

          <div class="p-2 rounded bg-slate-900/60 border border-slate-800 flex items-center justify-between">
            <div>
              <div class="font-semibold text-slate-200 text-[11px]">SSH Server Deploy</div>
              <div class="text-[10px] text-slate-500">Direct remote sync</div>
            </div>
            <button (click)="deployNotice('ssh')" class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[10px] font-mono cursor-pointer">
              Configure
            </button>
          </div>
        </div>
      </div>

      <!-- Section 4: System Diagnostics & Host Telemetry -->
      <div class="p-3">
        <div class="flex items-center justify-between mb-2">
          <span class="font-bold text-slate-200 uppercase tracking-wider text-[10px]">Host Telemetry</span>
          <button (click)="studio.fetchDiagnostics()" class="text-slate-500 hover:text-slate-300">
            <mat-icon class="text-xs !w-3 !h-3">refresh</mat-icon>
          </button>
        </div>

        @if (studio.systemDiagnostics(); as diag) {
          <div class="space-y-1 text-[10px] font-mono text-slate-400 bg-slate-900/50 p-2 rounded border border-slate-800">
            <div class="flex justify-between">
              <span class="text-slate-500">Platform:</span>
              <span>Linux ({{ diag.architecture }})</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-500">CPU Cores:</span>
              <span>{{ diag.cpus }} active</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-500">Memory RSS:</span>
              <span class="text-sky-400">{{ diag.memoryUsageMb?.rss }} MB</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-500">Host Free RAM:</span>
              <span>{{ diag.freeMemMb }} / {{ diag.totalMemMb }} MB</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-500">Engine Uptime:</span>
              <span>{{ diag.processUptimeSec }}s</span>
            </div>
          </div>
        }
      </div>
    </aside>
  `,
})
export class Inspector {
  readonly studio = inject(StudioService);

  updatePort(e: Event) {
    const val = parseInt((e.target as HTMLInputElement).value, 10);
    const arch = this.studio.architecture();
    if (arch && !isNaN(val)) {
      arch.launchPlan.port = val;
    }
  }

  updateHealthPath(e: Event) {
    const val = (e.target as HTMLInputElement).value;
    const arch = this.studio.architecture();
    if (arch && val) {
      arch.launchPlan.healthPath = val.trim();
    }
  }

  deployNotice(type: string) {
    alert(`Deployment configured for ${type.toUpperCase()}. Validation check: All unit tests and release builds pass.`);
  }
}
