import { ChangeDetectionStrategy, Component, inject, HostListener } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StudioService, OpenTab } from '../services/studio.service';

@Component({
  selector: 'app-editor',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="flex-1 flex flex-col h-full bg-[#080c16] overflow-hidden select-none">
      <!-- Tabs Bar -->
      <div class="h-9 border-b border-slate-800 bg-[#060912] flex items-center overflow-x-auto select-none shrink-0 px-1 gap-1">
        @if (studio.openTabs().length === 0) {
          <div class="px-3 text-xs text-slate-500 italic">No files open</div>
        } @else {
          @for (tab of studio.openTabs(); track tab.path) {
            <div
              (click)="studio.activeTabPath.set(tab.path)"
              [class.bg-[#0a0f1e]]="studio.activeTabPath() === tab.path"
              [class.border-t-2]="studio.activeTabPath() === tab.path"
              [class.border-sky-500]="studio.activeTabPath() === tab.path"
              [class.text-slate-100]="studio.activeTabPath() === tab.path"
              [class.text-slate-400]="studio.activeTabPath() !== tab.path"
              class="h-full flex items-center gap-2 px-3 text-xs border-r border-slate-850 hover:bg-slate-900/60 hover:text-slate-200 cursor-pointer group">
              <!-- Tab Title -->
              <span class="font-mono text-xs">{{ tab.name }}</span>

              <!-- Dirty Indicator or Close Button -->
              @if (tab.isDirty) {
                <span class="w-2 h-2 rounded-full bg-amber-400 group-hover:hidden" title="Unsaved changes"></span>
              }
              <button
                (click)="closeTab(tab, $event)"
                class="text-slate-500 hover:text-rose-400 p-0.5 rounded"
                [class.hidden]="tab.isDirty"
                [class.group-hover:inline-block]="tab.isDirty">
                <mat-icon class="text-[12px] !w-3 !h-3">close</mat-icon>
              </button>
            </div>
          }
        }
      </div>

      <!-- Editor Quick Action Toolbar -->
      @if (studio.activeTab(); as tab) {
        <div class="h-8 border-b border-slate-800/80 bg-[#090d19] px-3 flex items-center justify-between text-xs font-mono shrink-0">
          <div class="flex items-center gap-2">
            <!-- Save Button -->
            <button
              (click)="studio.saveActiveTab()"
              [disabled]="!tab.isDirty"
              class="flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold transition-colors cursor-pointer"
              [class.bg-sky-600]="tab.isDirty"
              [class.text-white]="tab.isDirty"
              [class.bg-slate-800]="!tab.isDirty"
              [class.text-slate-500]="!tab.isDirty">
              <mat-icon class="text-xs !w-3.5 !h-3.5">save</mat-icon>
              <span>Save (Ctrl+S)</span>
            </button>

            <div class="h-3.5 w-px bg-slate-800"></div>

            <!-- Language specific actions -->
            @if (tab.extension === '.rs' || tab.name === 'Cargo.toml') {
              <button
                (click)="runCargoCheck()"
                class="flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 text-[11px] cursor-pointer">
                <mat-icon class="text-xs !w-3 !h-3">check</mat-icon>
                <span>cargo check</span>
              </button>
              <button
                (click)="runCargoTest()"
                class="flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-sky-300 text-[11px] cursor-pointer">
                <mat-icon class="text-xs !w-3 !h-3">bug_report</mat-icon>
                <span>cargo test</span>
              </button>
              <button
                (click)="runCargoClippy()"
                class="flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-emerald-300 text-[11px] cursor-pointer">
                <mat-icon class="text-xs !w-3 !h-3">rule</mat-icon>
                <span>clippy</span>
              </button>
            }

            @if (tab.extension === '.r' || tab.name === 'DESCRIPTION') {
              <button
                (click)="runRScript()"
                class="flex items-center gap-1 px-2 py-0.5 rounded bg-sky-900/60 hover:bg-sky-800 text-sky-200 text-[11px] cursor-pointer">
                <mat-icon class="text-xs !w-3 !h-3">play_arrow</mat-icon>
                <span>Run in R</span>
              </button>
              <button
                (click)="runRPlot()"
                class="flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-purple-300 text-[11px] cursor-pointer">
                <mat-icon class="text-xs !w-3 !h-3">show_chart</mat-icon>
                <span>Plot Vector SVG</span>
              </button>
            }
          </div>

          <!-- Metadata -->
          <div class="flex items-center gap-3 text-slate-500 text-[11px]">
            <span>{{ tab.lines || 1 }} lines</span>
            <span>{{ formatSize(tab.content.length) }}</span>
            <span class="text-slate-400 font-semibold">{{ getLanguageLabel(tab) }}</span>
          </div>
        </div>

        <!-- Main Code Editing Area -->
        <div class="flex-1 relative flex overflow-hidden bg-[#070b14]">
          <!-- Gutter / Line Numbers -->
          <div class="w-12 py-3 bg-[#060911] border-r border-slate-800/80 text-right pr-2 text-slate-600 font-mono text-xs select-none overflow-hidden">
            @for (line of getLineNumbers(tab); track line) {
              <div class="leading-5 h-5">{{ line }}</div>
            }
          </div>

          <!-- Textarea / Editor Input -->
          <div class="flex-1 relative overflow-auto">
            @if (tab.isBinary) {
              <div class="p-6 flex flex-col items-center justify-center h-full text-slate-400">
                <mat-icon class="text-4xl !w-12 !h-12 mb-2 text-sky-400">image</mat-icon>
                <div class="text-sm font-semibold text-slate-200">{{ tab.name }}</div>
                <div class="text-xs text-slate-500 mt-1">Binary asset ({{ formatSize(tab.size || 0) }})</div>
              </div>
            } @else {
              <textarea
                #editorArea
                [value]="tab.content"
                (input)="onContentInput(editorArea.value)"
                (keydown)="onKeyDown($event)"
                spellcheck="false"
                class="w-full h-full p-3 font-mono text-xs leading-5 bg-transparent text-slate-200 outline-none resize-none overflow-auto border-none selection:bg-sky-900 selection:text-white"
                style="tab-size: 2; white-space: pre; font-family: 'JetBrains Mono', monospace;"></textarea>
            }
          </div>
        </div>
      } @else {
        <!-- Empty Workspace State -->
        <div class="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-500">
          <div class="w-12 h-12 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 mb-4">
            <mat-icon class="text-2xl">code</mat-icon>
          </div>
          <h3 class="text-base font-semibold text-slate-300 mb-1">DSCS Engineering Workstation</h3>
          <p class="text-xs max-w-sm text-slate-400 leading-relaxed mb-4">
            Open a file from the repository tree on the left, or run the <strong>Web Runtime</strong> to compile and launch services.
          </p>
          <div class="flex items-center gap-2">
            <button
              (click)="openSamplePrimary()"
              class="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded text-xs font-medium cursor-pointer">
              Open Primary Source
            </button>
          </div>
        </div>
      }

      <!-- Editor Status Bar Footer -->
      <footer class="h-6 border-t border-slate-800 bg-[#060912] px-3 flex items-center justify-between text-[11px] text-slate-500 font-mono shrink-0 select-none">
        <div class="flex items-center gap-3">
          <span class="flex items-center gap-1">
            <span class="w-2 h-2 rounded-full" [class.bg-emerald-400]="!studio.activeTab()?.isDirty" [class.bg-amber-400]="studio.activeTab()?.isDirty"></span>
            {{ studio.activeTab()?.isDirty ? 'UNSAVED' : 'SAVED' }}
          </span>
          @if (studio.activeTab(); as tab) {
            <span class="text-slate-400 truncate max-w-md">{{ tab.path }}</span>
          }
        </div>

        <div class="flex items-center gap-4">
          <span>UTF-8</span>
          <span>LF</span>
          <span>Tab: 2</span>
        </div>
      </footer>
    </div>
  `,
})
export class Editor {
  readonly studio = inject(StudioService);

  @HostListener('window:keydown', ['$event'])
  handleKeyboard(event: KeyboardEvent) {
    if ((event.ctrlKey || event.metaKey) && event.key === 's') {
      event.preventDefault();
      this.studio.saveActiveTab();
    }
  }

  onContentInput(value: string) {
    this.studio.updateActiveTabContent(value);
  }

  onKeyDown(e: KeyboardEvent) {
    if (e.key === 'Tab') {
      e.preventDefault();
      const target = e.target as HTMLTextAreaElement;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      const value = target.value;
      target.value = value.substring(0, start) + '  ' + value.substring(end);
      target.selectionStart = target.selectionEnd = start + 2;
      this.studio.updateActiveTabContent(target.value);
    }
  }

  closeTab(tab: OpenTab, event: MouseEvent) {
    event.stopPropagation();
    this.studio.closeTab(tab.path);
  }

  getLineNumbers(tab: OpenTab): number[] {
    const total = tab.lines || (tab.content ? tab.content.split('\n').length : 1);
    const arr = [];
    for (let i = 1; i <= total; i++) arr.push(i);
    return arr;
  }

  formatSize(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    return `${(bytes / 1024).toFixed(1)} KB`;
  }

  getLanguageLabel(tab: OpenTab): string {
    const ext = tab.extension;
    if (ext === '.rs') return 'Rust';
    if (ext === '.r') return 'R Statistical Script';
    if (ext === '.html') return 'HTML5';
    if (ext === '.css') return 'CSS3';
    if (ext === '.js' || ext === '.ts') return 'TypeScript / JS';
    if (ext === '.toml') return 'TOML Manifest';
    if (ext === '.json') return 'JSON';
    if (ext === '.csv') return 'CSV Dataset';
    return 'Plain Text';
  }

  runCargoCheck() {
    this.studio.executeBuild('cargo', ['check']);
  }

  runCargoTest() {
    this.studio.executeBuild('cargo', ['test']);
  }

  runCargoClippy() {
    this.studio.executeBuild('cargo', ['clippy']);
  }

  runRScript() {
    const tab = this.studio.activeTab();
    if (tab) {
      this.studio.executeBuild('Rscript', [tab.path]);
    }
  }

  async runRPlot() {
    this.studio.activeBottomTab.set('r-analytics');
    this.studio.bottomTrayExpanded.set(true);
    await this.studio.fetchRPlot(this.studio.currentWorkspacePath());
  }

  openSamplePrimary() {
    const tree = this.studio.fileTree();
    if (tree.length > 0) {
      for (const node of tree) {
        if (node.type === 'file') {
          this.studio.openFile(node.path);
          return;
        } else if (node.children) {
          for (const c of node.children) {
            if (c.type === 'file') {
              this.studio.openFile(c.path);
              return;
            }
          }
        }
      }
    }
  }
}
