import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StudioService, FileNode } from '../services/studio.service';

@Component({
  selector: 'app-sidebar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <aside class="w-64 border-r border-slate-800 bg-[#090d18] flex flex-col h-full select-none shrink-0 overflow-hidden">
      <!-- Sidebar Tab Switcher -->
      <div class="flex items-center border-b border-slate-800 bg-[#070a12] text-xs font-medium text-slate-400">
        <button
          (click)="studio.sidebarTab.set('files')"
          [class.text-sky-400]="studio.sidebarTab() === 'files'"
          [class.border-b-2]="studio.sidebarTab() === 'files'"
          [class.border-sky-400]="studio.sidebarTab() === 'files'"
          [class.bg-[#090d18]]="studio.sidebarTab() === 'files'"
          class="flex-1 py-2 px-3 flex items-center justify-center gap-1.5 hover:text-slate-200 transition-colors cursor-pointer">
          <mat-icon class="text-xs !w-3.5 !h-3.5">folder</mat-icon>
          <span>Files</span>
        </button>

        <button
          (click)="studio.sidebarTab.set('git')"
          [class.text-sky-400]="studio.sidebarTab() === 'git'"
          [class.border-b-2]="studio.sidebarTab() === 'git'"
          [class.border-sky-400]="studio.sidebarTab() === 'git'"
          [class.bg-[#090d18]]="studio.sidebarTab() === 'git'"
          class="flex-1 py-2 px-3 flex items-center justify-center gap-1.5 hover:text-slate-200 transition-colors cursor-pointer">
          <mat-icon class="text-xs !w-3.5 !h-3.5">commit</mat-icon>
          <span>Git</span>
          @if (studio.gitStatus() && !studio.gitStatus()!.clean) {
            <span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
          }
        </button>

        <button
          (click)="studio.sidebarTab.set('toolchains')"
          [class.text-sky-400]="studio.sidebarTab() === 'toolchains'"
          [class.border-b-2]="studio.sidebarTab() === 'toolchains'"
          [class.border-sky-400]="studio.sidebarTab() === 'toolchains'"
          [class.bg-[#090d18]]="studio.sidebarTab() === 'toolchains'"
          class="flex-1 py-2 px-3 flex items-center justify-center gap-1.5 hover:text-slate-200 transition-colors cursor-pointer">
          <mat-icon class="text-xs !w-3.5 !h-3.5">dns</mat-icon>
          <span>Tools</span>
        </button>
      </div>

      <!-- Tab Content: File Explorer -->
      @if (studio.sidebarTab() === 'files') {
        <div class="flex-1 flex flex-col overflow-hidden">
          <!-- Explorer Header & Action Bar -->
          <div class="px-3 py-2 flex items-center justify-between text-xs text-slate-400 border-b border-slate-850 bg-[#0a0f1d]">
            <span class="font-semibold uppercase tracking-wider text-[10px] text-slate-400">
              {{ studio.architecture()?.name || 'Workspace' }}
            </span>
            <div class="flex items-center gap-1">
              <button
                (click)="promptCreateFile(false)"
                class="p-0.5 rounded hover:text-slate-200 hover:bg-slate-800"
                title="New File">
                <mat-icon class="text-xs !w-3.5 !h-3.5">note_add</mat-icon>
              </button>
              <button
                (click)="promptCreateFile(true)"
                class="p-0.5 rounded hover:text-slate-200 hover:bg-slate-800"
                title="New Folder">
                <mat-icon class="text-xs !w-3.5 !h-3.5">create_new_folder</mat-icon>
              </button>
              <button
                (click)="studio.fetchFileTree(studio.currentWorkspacePath())"
                class="p-0.5 rounded hover:text-slate-200 hover:bg-slate-800"
                title="Refresh File Tree">
                <mat-icon class="text-xs !w-3.5 !h-3.5">refresh</mat-icon>
              </button>
            </div>
          </div>

          <!-- Tree View -->
          <div class="flex-1 overflow-y-auto py-1 text-xs font-mono">
            @if (studio.fileTree().length === 0) {
              <div class="p-4 text-center text-slate-500 text-xs">
                No files found in workspace
              </div>
            } @else {
              @for (node of studio.fileTree(); track node.path) {
                <div class="flex flex-col">
                  <!-- Directory Node -->
                  @if (node.type === 'directory') {
                    <div
                      (click)="toggleDir(node)"
                      class="flex items-center gap-1.5 px-3 py-1 text-slate-300 hover:bg-slate-800/60 cursor-pointer font-medium">
                      <mat-icon class="text-xs !w-3.5 !h-3.5 text-slate-500">
                        {{ isExpanded(node.path) ? 'folder_open' : 'folder' }}
                      </mat-icon>
                      <span class="truncate">{{ node.name }}</span>
                    </div>

                    @if (isExpanded(node.path)) {
                      <div class="pl-4 border-l border-slate-800/80 ml-4">
                        @for (child of node.children || []; track child.path) {
                          <div
                            (click)="onNodeClick(child)"
                            [class.bg-sky-950/60]="studio.activeTabPath() === child.path"
                            [class.text-sky-300]="studio.activeTabPath() === child.path"
                            [class.text-slate-400]="studio.activeTabPath() !== child.path"
                            class="group flex items-center justify-between px-2 py-0.5 hover:bg-slate-800/50 hover:text-slate-200 cursor-pointer rounded">
                            <div class="flex items-center gap-1.5 truncate">
                              <mat-icon class="text-xs !w-3.5 !h-3.5 shrink-0" [class]="getFileColorClass(child)">
                                {{ getFileIcon(child) }}
                              </mat-icon>
                              <span class="truncate">{{ child.name }}</span>
                            </div>
                            <button
                              (click)="deleteItem(child, $event)"
                              class="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-rose-400 p-0.5"
                              title="Delete file">
                              <mat-icon class="text-[10px] !w-3 !h-3">close</mat-icon>
                            </button>
                          </div>
                        }
                      </div>
                    }
                  } @else {
                    <!-- Top-Level File Node -->
                    <div
                      (click)="onNodeClick(node)"
                      [class.bg-sky-950/60]="studio.activeTabPath() === node.path"
                      [class.text-sky-300]="studio.activeTabPath() === node.path"
                      [class.text-slate-400]="studio.activeTabPath() !== node.path"
                      class="group flex items-center justify-between px-3 py-1 hover:bg-slate-800/50 hover:text-slate-200 cursor-pointer">
                      <div class="flex items-center gap-1.5 truncate">
                        <mat-icon class="text-xs !w-3.5 !h-3.5 shrink-0" [class]="getFileColorClass(node)">
                          {{ getFileIcon(node) }}
                        </mat-icon>
                        <span class="truncate">{{ node.name }}</span>
                      </div>
                      <button
                        (click)="deleteItem(node, $event)"
                        class="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-rose-400 p-0.5"
                        title="Delete file">
                        <mat-icon class="text-[10px] !w-3 !h-3">close</mat-icon>
                      </button>
                    </div>
                  }
                </div>
              }
            }
          </div>

          <!-- Bottom Workspace Stats -->
          <div class="p-2 border-t border-slate-800 bg-[#080c16] text-[11px] text-slate-500 font-mono flex items-center justify-between">
            <span>{{ studio.architecture()?.fileCount || 0 }} files</span>
            <span>Linux UTF-8</span>
          </div>
        </div>
      }

      <!-- Tab Content: Git -->
      @if (studio.sidebarTab() === 'git') {
        <div class="flex-1 flex flex-col p-3 overflow-y-auto text-xs">
          <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
            <span class="font-bold text-slate-200 flex items-center gap-1">
              <mat-icon class="text-xs !w-4 !h-4 text-sky-400">commit</mat-icon>
              {{ studio.gitStatus()?.branch || 'main' }}
            </span>
            <span class="text-[10px] text-slate-500 font-mono">
              {{ studio.gitStatus()?.clean ? 'CLEAN' : 'DIRTY' }}
            </span>
          </div>

          <!-- Changed Files -->
          <div class="mb-4">
            <span class="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Changes</span>
            @if (studio.gitStatus()?.changedFiles?.length === 0) {
              <div class="py-2 text-slate-500 italic">No uncommitted changes</div>
            } @else {
              <div class="mt-1 space-y-1 font-mono">
                @for (change of studio.gitStatus()?.changedFiles || []; track change.file) {
                  <div class="flex items-center justify-between px-2 py-1 bg-slate-900 rounded border border-slate-800">
                    <span class="truncate text-slate-300">{{ change.file }}</span>
                    <span class="text-[10px] text-amber-400 font-bold">{{ change.code }}</span>
                  </div>
                }
              </div>

              <!-- Quick Commit -->
              <div class="mt-3">
                <input
                  type="text"
                  #commitMsg
                  placeholder="Commit message..."
                  class="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded text-slate-200 text-xs mb-2 outline-none focus:border-sky-500" />
                <button
                  (click)="doCommit(commitMsg.value); commitMsg.value = ''"
                  class="w-full py-1 bg-sky-600 hover:bg-sky-500 text-white rounded text-xs font-semibold cursor-pointer">
                  Commit Changes
                </button>
              </div>
            }
          </div>

          <!-- Commit History -->
          <div>
            <span class="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Recent Commits</span>
            <div class="mt-1 space-y-2">
              @for (c of studio.gitStatus()?.commits || []; track c.hash) {
                <div class="p-2 bg-slate-900/60 rounded border border-slate-800/80">
                  <div class="flex items-center justify-between text-[10px] font-mono text-slate-500">
                    <span class="text-sky-400">{{ c.hash }}</span>
                    <span>{{ c.date }}</span>
                  </div>
                  <div class="text-slate-300 text-xs mt-1 truncate">{{ c.message }}</div>
                </div>
              }
            </div>
          </div>
        </div>
      }

      <!-- Tab Content: Toolchains -->
      @if (studio.sidebarTab() === 'toolchains') {
        <div class="flex-1 p-3 overflow-y-auto text-xs font-mono">
          <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
            <span class="font-bold text-slate-200">Installed Toolchains</span>
            <button
              (click)="studio.fetchToolchains()"
              class="text-slate-400 hover:text-slate-200">
              <mat-icon class="text-xs !w-3.5 !h-3.5">refresh</mat-icon>
            </button>
          </div>

          <div class="space-y-2">
            @for (tool of studio.toolchains(); track tool.id) {
              <div class="p-2 bg-slate-900/80 rounded border border-slate-800">
                <div class="flex items-center justify-between">
                  <span class="font-semibold text-slate-200 text-[11px]">{{ tool.name }}</span>
                  <span
                    class="text-[9px] px-1 rounded font-bold"
                    [class.bg-emerald-950]="tool.available"
                    [class.text-emerald-400]="tool.available"
                    [class.bg-rose-950]="!tool.available"
                    [class.text-rose-400]="!tool.available">
                    {{ tool.available ? 'AVAILABLE' : 'MISSING' }}
                  </span>
                </div>
                <div class="text-[10px] text-slate-400 mt-1 truncate">
                  {{ tool.version || 'Version unavailable' }}
                </div>
                <div class="text-[9px] text-slate-600 truncate mt-0.5">
                  {{ tool.executablePath || 'Not found in PATH' }}
                </div>
              </div>
            }
          </div>
        </div>
      }
    </aside>
  `,
})
export class Sidebar {
  readonly studio = inject(StudioService);
  private expandedPaths = signal<Set<string>>(new Set(['/app/applet/workspaces/rust-web/src', '/app/applet/workspaces/r-analysis/scripts']));

  isExpanded(path: string): boolean {
    return this.expandedPaths().has(path);
  }

  toggleDir(node: FileNode) {
    this.expandedPaths.update((set) => {
      const copy = new Set(set);
      if (copy.has(node.path)) {
        copy.delete(node.path);
      } else {
        copy.add(node.path);
      }
      return copy;
    });
  }

  onNodeClick(node: FileNode) {
    if (node.type === 'file') {
      this.studio.openFile(node.path);
    } else {
      this.toggleDir(node);
    }
  }

  deleteItem(node: FileNode, event: MouseEvent) {
    event.stopPropagation();
    this.studio.deleteFile(node.path);
  }

  promptCreateFile(isDirectory: boolean) {
    const name = prompt(isDirectory ? 'Enter new folder name:' : 'Enter new file name:');
    if (name) {
      this.studio.createNewFile(name.trim(), isDirectory);
    }
  }

  async doCommit(msg: string) {
    if (!msg.trim()) return;
    try {
      await fetch('/api/git/commit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: this.studio.currentWorkspacePath(), message: msg.trim() }),
      });
      await this.studio.fetchGitStatus(this.studio.currentWorkspacePath());
    } catch (e) {
      console.error(e);
    }
  }

  getFileIcon(node: FileNode): string {
    const ext = node.extension;
    if (ext === '.rs') return 'code';
    if (ext === '.r') return 'analytics';
    if (ext === '.html') return 'language';
    if (ext === '.css') return 'palette';
    if (ext === '.js' || ext === '.ts') return 'javascript';
    if (ext === '.json' || ext === '.toml') return 'data_object';
    if (ext === '.csv') return 'table_chart';
    if (ext === '.svg' || ext === '.png') return 'image';
    return 'insert_drive_file';
  }

  getFileColorClass(node: FileNode): string {
    const ext = node.extension;
    if (ext === '.rs') return 'text-amber-500';
    if (ext === '.r') return 'text-sky-400';
    if (ext === '.html') return 'text-orange-400';
    if (ext === '.css') return 'text-blue-400';
    if (ext === '.js' || ext === '.ts') return 'text-yellow-400';
    if (ext === '.csv') return 'text-emerald-400';
    if (ext === '.svg') return 'text-purple-400';
    return 'text-slate-400';
  }
}
