import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { Topbar } from './components/topbar';
import { Sidebar } from './components/sidebar';
import { Editor } from './components/editor';
import { Inspector } from './components/inspector';
import { BottomTray } from './components/bottom-tray';
import { StudioService } from './services/studio.service';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [Topbar, Sidebar, Editor, Inspector, BottomTray],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly studio = inject(StudioService);
}
