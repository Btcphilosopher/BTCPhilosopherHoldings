# DSCS R Analytics Pipeline: Statistical Characterization
# Computational Environment: Linux x86_64 / R Runtime

cat("[R-ENGINE] Reading telemetry dataset...\n")
data_path <- file.path(getwd(), "data", "experiment_metrics.csv")
if (!file.exists(data_path)) {
  # fallback for relative path inside scripts/
  data_path <- "../data/experiment_metrics.csv"
}

df <- read.csv(data_path, stringsAsFactors = FALSE)
cat(sprintf("[R-ENGINE] Loaded %d rows and %d variables.\n", nrow(df), ncol(df)))

cat("\n=== SUMMARY STATISTICS: SNR & LATENCY ===\n")
snr_summary <- summary(df$snr_db)
print(snr_summary)

cat("\n=== CORRELATION MATRIX (Numeric Metrics) ===\n")
num_cols <- df[, c("sample_rate_khz", "snr_db", "execution_latency_ms", "thermal_deg_c")]
cor_matrix <- cor(num_cols)
print(round(cor_matrix, 3))

cat("\n=== LINEAR MODEL: Latency ~ Sample Rate + Thermal ===\n")
fit <- lm(execution_latency_ms ~ sample_rate_khz + thermal_deg_c, data = df)
print(summary(fit)$coefficients)

cat("\n[R-ENGINE] Statistical pipeline execution completed successfully.\n")
