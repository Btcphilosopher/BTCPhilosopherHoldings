# DSCS R Plot Generator: Visualizing Telemetry Distribution
data_path <- file.path(getwd(), "data", "experiment_metrics.csv")
if (!file.exists(data_path)) {
  data_path <- "../data/experiment_metrics.csv"
}
df <- read.csv(data_path, stringsAsFactors = FALSE)

output_svg <- file.path(getwd(), "output_plot.svg")
svg(output_svg, width = 8, height = 5, bg = "#0f172a")

par(bg = "#0f172a", fg = "#94a3b8", col.axis = "#94a3b8", col.lab = "#38bdf8", col.main = "#e2e8f0", family = "mono")
plot(
  df$sample_rate_khz,
  df$snr_db,
  col = ifelse(df$status == "optimal", "#38bdf8", ifelse(df$status == "nominal", "#22c55e", "#f59e0b")),
  pch = 19,
  cex = 1.8,
  xlab = "Sample Rate (kHz)",
  ylab = "Signal-to-Noise Ratio (dB)",
  main = "Telemetry Distribution: SNR vs Sample Rate",
  grid()
)
abline(lm(snr_db ~ sample_rate_khz, data = df), col = "#38bdf8", lty = 2, lwd = 2)
legend(
  "topleft",
  legend = c("Optimal", "Nominal", "Degraded"),
  col = c("#38bdf8", "#22c55e", "#f59e0b"),
  pch = 19,
  text.col = "#e2e8f0",
  bty = "n"
)
dev.off()
cat(sprintf("[R-ENGINE] Generated vector SVG plot at %s\n", output_svg))
