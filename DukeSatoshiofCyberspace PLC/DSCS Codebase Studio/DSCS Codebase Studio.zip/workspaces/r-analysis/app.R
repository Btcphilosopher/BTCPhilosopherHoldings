# DSCS R Analytics Web Server (Base R HTTP Server)
# Listens on configured PORT, responds with statistical dashboard and /health

port <- as.integer(Sys.getenv("PORT", "8081"))
cat(sprintf("[R-WEB] Initializing R analytical web server on port %d...\n", port))

data_file <- "data/experiment_metrics.csv"
if (!file.exists(data_file)) {
  data_file <- file.path(getwd(), "data", "experiment_metrics.csv")
}
df <- read.csv(data_file, stringsAsFactors = FALSE)
start_time <- Sys.time()

server <- tryCatch({
  serverSocket(port)
}, error = function(e) {
  cat(sprintf("[R-WEB] Error binding to port %d: %s\n", port, e$message))
  quit(status = 1)
})

cat(sprintf("[R-WEB] Listening on http://0.0.0.0:%d\n", port))
cat(sprintf("[R-WEB] Health prober available on http://0.0.0.0:%d/health\n", port))

while (TRUE) {
  con <- socketAccept(server, open = "a+b", blocking = TRUE)
  lines <- readLines(con, n = 1, warn = FALSE)
  if (length(lines) > 0) {
    req_parts <- strsplit(lines[1], " ")[[1]]
    path <- if (length(req_parts) >= 2) req_parts[2] else "/"
    
    if (path == "/health") {
      uptime <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
      body <- sprintf('{"status":"healthy","service":"r-analytics-daemon","uptime_seconds":%.1f,"records_loaded":%d,"engine":"R-%s"}',
                      uptime, nrow(df), paste(R.version$major, R.version$minor, sep="."))
      headers <- paste(
        "HTTP/1.1 200 OK",
        "Content-Type: application/json",
        sprintf("Content-Length: %d", nchar(body)),
        "Connection: close",
        "Access-Control-Allow-Origin: *",
        "\r\n", sep = "\r\n"
      )
      writeLines(paste0(headers, body), con)
    } else {
      mean_snr <- mean(df$snr_db, na.rm = TRUE)
      mean_lat <- mean(df$execution_latency_ms, na.rm = TRUE)
      
      body <- sprintf('<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>R Computational Analytics — DSCS</title>
  <style>
    body { background: #0b1120; color: #e2e8f0; font-family: -apple-system, monospace; padding: 2.5rem; margin: 0; }
    .card { background: #111827; border: 1px solid #1f2937; border-radius: 8px; padding: 1.75rem; max-width: 800px; margin: 0 auto; }
    h1 { color: #38bdf8; font-size: 1.4rem; margin: 0 0 1rem 0; }
    .metric-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin: 1.5rem 0; }
    .metric { background: #030712; padding: 1rem; border-radius: 6px; border: 1px solid #1f2937; }
    .metric-val { font-size: 1.5rem; font-weight: 700; color: #38bdf8; font-family: monospace; }
    .metric-lbl { font-size: 0.75rem; color: #9ca3af; text-transform: uppercase; margin-top: 0.25rem; }
    table { width: 100%; border-collapse: collapse; margin-top: 1rem; font-size: 0.85rem; font-family: monospace; }
    th { text-align: left; background: #1f2937; color: #9ca3af; padding: 0.5rem; }
    td { padding: 0.5rem; border-bottom: 1px solid #1f2937; }
  </style>
</head>
<body>
  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <h1>R Computational Workstation</h1>
      <span style="background:#0284c7; color:#fff; font-size:0.75rem; padding:0.25rem 0.5rem; border-radius:4px; font-weight:600;">ACTIVE</span>
    </div>
    <p style="color:#94a3b8; font-size:0.9rem;">
      Real-time descriptive statistical summary generated directly by Linux R runtime (version %s).
    </p>
    <div class="metric-grid">
      <div class="metric">
        <div class="metric-val">%.2f dB</div>
        <div class="metric-lbl">Mean Signal-to-Noise</div>
      </div>
      <div class="metric">
        <div class="metric-val">%.2f ms</div>
        <div class="metric-lbl">Mean Execution Latency</div>
      </div>
      <div class="metric">
        <div class="metric-val">%d</div>
        <div class="metric-lbl">Ingested Records</div>
      </div>
    </div>
    <h3 style="color:#cbd5e1; font-size:0.95rem; margin-top:1.5rem;">Sample Telemetry Observations</h3>
    <table>
      <thead>
        <tr><th>ID</th><th>Batch</th><th>Rate (kHz)</th><th>SNR (dB)</th><th>Latency (ms)</th><th>Status</th></tr>
      </thead>
      <tbody>
        <tr><td>1</td><td>Batch-A</td><td>48</td><td>28.4</td><td>4.2</td><td><span style="color:#22c55e;">nominal</span></td></tr>
        <tr><td>2</td><td>Batch-A</td><td>48</td><td>27.9</td><td>4.5</td><td><span style="color:#22c55e;">nominal</span></td></tr>
        <tr><td>3</td><td>Batch-A</td><td>96</td><td>32.1</td><td>6.8</td><td><span style="color:#38bdf8;">optimal</span></td></tr>
        <tr><td>4</td><td>Batch-B</td><td>96</td><td>30.4</td><td>7.2</td><td><span style="color:#38bdf8;">optimal</span></td></tr>
        <tr><td>5</td><td>Batch-C</td><td>192</td><td>36.5</td><td>11.2</td><td><span style="color:#38bdf8;">optimal</span></td></tr>
      </tbody>
    </table>
    <div style="margin-top:1.5rem; font-size:0.8rem; color:#64748b; font-family:monospace;">
      Prober: <a href="/health" style="color:#38bdf8; text-decoration:none;">/health</a> | Runtime: R-4.2.2 Linux x86_64
    </div>
  </div>
</body>
</html>', paste(R.version$major, R.version$minor, sep="."), mean_snr, mean_lat, nrow(df))

      headers <- paste(
        "HTTP/1.1 200 OK",
        "Content-Type: text/html; charset=utf-8",
        sprintf("Content-Length: %d", nchar(body, type = "bytes")),
        "Connection: close",
        "Access-Control-Allow-Origin: *",
        "\r\n", sep = "\r\n"
      )
      writeLines(paste0(headers, body), con)
    }
  }
  close(con)
}
