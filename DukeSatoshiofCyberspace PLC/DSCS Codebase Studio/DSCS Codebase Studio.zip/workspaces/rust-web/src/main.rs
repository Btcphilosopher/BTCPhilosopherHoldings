use std::env;
use std::io::{BufRead, BufReader, Write};
use std::net::TcpListener;
use std::sync::Arc;
use rust_web::{route_request, ServiceState};

fn main() {
    let port = env::var("PORT").unwrap_or_else(|_| "8080".to_string());
    let addr = format!("0.0.0.0:{}", port);
    
    println!("[rust-web] Binding HTTP listener on {}", addr);
    let listener = match TcpListener::bind(&addr) {
        Ok(l) => l,
        Err(e) => {
            eprintln!("[rust-web] Fatal error binding to {}: {}", addr, e);
            std::process::exit(1);
        }
    };

    println!("[rust-web] Service running on http://{}", addr);
    println!("[rust-web] Ready for health probes on http://{}/health", addr);

    let state = Arc::new(ServiceState::new());

    for stream in listener.incoming() {
        match stream {
            Ok(mut stream) => {
                let state_clone = Arc::clone(&state);
                let mut reader = BufReader::new(&stream);
                let mut first_line = String::new();
                if reader.read_line(&mut first_line).is_ok() {
                    let parts: Vec<&str> = first_line.split_whitespace().collect();
                    let path = parts.get(1).copied().unwrap_or("/");
                    
                    let (status_code, content_type, body) = route_request(path, &state_clone);
                    let status_text = match status_code {
                        200 => "OK",
                        404 => "Not Found",
                        _ => "Internal Server Error",
                    };

                    let response = format!(
                        "HTTP/1.1 {} {}\r\nContent-Type: {}\r\nContent-Length: {}\r\nConnection: close\r\nAccess-Control-Allow-Origin: *\r\n\r\n{}",
                        status_code,
                        status_text,
                        content_type,
                        body.as_bytes().len(),
                        body
                    );

                    let _ = stream.write_all(response.as_bytes());
                    let _ = stream.flush();
                }
            }
            Err(e) => {
                eprintln!("[rust-web] Incoming connection error: {}", e);
            }
        }
    }
}
