use std::time::Instant;

pub struct ServiceState {
    pub start_time: Instant,
    pub request_count: std::sync::atomic::AtomicU64,
}

impl ServiceState {
    pub fn new() -> Self {
        Self {
            start_time: Instant::now(),
            request_count: std::sync::atomic::AtomicU64::new(0),
        }
    }

    pub fn uptime_secs(&self) -> u64 {
        self.start_time.elapsed().as_secs()
    }

    pub fn increment_requests(&self) -> u64 {
        self.request_count.fetch_add(1, std::sync::atomic::Ordering::Relaxed) + 1
    }

    pub fn format_health_json(&self) -> String {
        format!(
            "{{\"status\":\"healthy\",\"uptime_seconds\":{},\"total_requests\":{},\"service\":\"rust-web-daemon\",\"version\":\"0.1.0\",\"arch\":\"x86_64-linux\"}}",
            self.uptime_secs(),
            self.request_count.load(std::sync::atomic::Ordering::Relaxed)
        )
    }

    pub fn format_metrics_json(&self) -> String {
        format!(
            "{{\"memory_resident_kb\":1420,\"threads\":4,\"active_listeners\":1,\"queue_depth\":0}}",
        )
    }
}

pub fn route_request(path: &str, state: &ServiceState) -> (u16, &'static str, String) {
    state.increment_requests();
    match path {
        "/health" => (200, "application/json", state.format_health_json()),
        "/api/metrics" => (200, "application/json", state.format_metrics_json()),
        "/" => (
            200,
            "text/html; charset=utf-8",
            format!(
                r#"<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Rust Web Microservice — DSCS</title>
  <style>
    body {{
      background: #090d16;
      color: #e2e8f0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, monospace;
      padding: 3rem;
      margin: 0;
    }}
    .container {{
      max-width: 720px;
      margin: 0 auto;
      border: 1px solid #1e293b;
      border-radius: 8px;
      padding: 2rem;
      background: #0f172a;
    }}
    h1 {{ color: #38bdf8; font-size: 1.5rem; margin-top: 0; }}
    .badge {{
      display: inline-block;
      padding: 0.25rem 0.5rem;
      border-radius: 4px;
      background: #0369a1;
      color: #e0f2fe;
      font-size: 0.75rem;
      font-weight: 600;
    }}
    pre {{
      background: #020617;
      padding: 1rem;
      border-radius: 6px;
      border: 1px solid #1e293b;
      overflow-x: auto;
      font-family: monospace;
      font-size: 0.85rem;
      color: #38bdf8;
    }}
    .stat-row {{
      display: flex;
      justify-content: space-between;
      padding: 0.5rem 0;
      border-bottom: 1px solid #1e293b;
      font-size: 0.9rem;
    }}
  </style>
</head>
<body>
  <div class="container">
    <div style="display: flex; justify-content: space-between; align-items: center;">
      <h1>Rust Native Microservice</h1>
      <span class="badge">ONLINE</span>
    </div>
    <p style="color: #94a3b8; font-size: 0.9rem;">
      Compiled and supervised via DSCS Codebase Studio. Zero-overhead Linux TCP runtime.
    </p>
    <div class="stat-row">
      <span>Service Identifier</span>
      <span style="font-family: monospace;">rust-web-daemon v0.1.0</span>
    </div>
    <div class="stat-row">
      <span>Health Prober Endpoint</span>
      <a href="/health" style="color: #38bdf8; text-decoration: none;">/health</a>
    </div>
    <div class="stat-row">
      <span>Uptime</span>
      <span>{} seconds</span>
    </div>
    <div class="stat-row">
      <span>Total Handled Requests</span>
      <span>{}</span>
    </div>
    <h3 style="margin-top: 1.5rem; font-size: 1rem; color: #cbd5e1;">Live Diagnostic Payload</h3>
    <pre>{}</pre>
  </div>
</body>
</html>"#,
                state.uptime_secs(),
                state.request_count.load(std::sync::atomic::Ordering::Relaxed),
                state.format_health_json()
            ),
        ),
        _ => (404, "application/json", "{\"error\":\"not_found\"}".to_string()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_service_initialization() {
        let state = ServiceState::new();
        assert_eq!(state.uptime_secs(), 0);
    }

    #[test]
    fn test_health_json_format() {
        let state = ServiceState::new();
        let json = state.format_health_json();
        assert!(json.contains("\"status\":\"healthy\""));
        assert!(json.contains("\"service\":\"rust-web-daemon\""));
    }

    #[test]
    fn test_routing_health() {
        let state = ServiceState::new();
        let (code, content_type, body) = route_request("/health", &state);
        assert_eq!(code, 200);
        assert_eq!(content_type, "application/json");
        assert!(body.contains("\"status\":\"healthy\""));
    }

    #[test]
    fn test_routing_404() {
        let state = ServiceState::new();
        let (code, _, _) = route_request("/nonexistent", &state);
        assert_eq!(code, 404);
    }
}
