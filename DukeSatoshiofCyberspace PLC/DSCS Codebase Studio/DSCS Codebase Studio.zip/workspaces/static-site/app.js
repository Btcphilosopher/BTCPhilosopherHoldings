const canvas = document.getElementById('telemetryCanvas');
const ctx = canvas.getContext('2d');
const fpsEl = document.getElementById('fps-val');
const cyclesEl = document.getElementById('cycles-val');
const toggleBtn = document.getElementById('btn-toggle');
const resetBtn = document.getElementById('btn-reset');

let running = true;
let cycles = 128490;
let points = [];
const maxPoints = 80;

for (let i = 0; i < maxPoints; i++) {
  points.push(Math.sin(i * 0.15) * 40 + Math.random() * 8 + 110);
}

let lastTime = performance.now();
let frames = 0;
let fps = 60;

function draw() {
  if (!running) return;
  frames++;
  const now = performance.now();
  if (now - lastTime >= 1000) {
    fps = frames;
    frames = 0;
    lastTime = now;
    if (fpsEl) fpsEl.textContent = fps;
  }

  cycles += Math.floor(Math.random() * 15 + 5);
  if (cyclesEl) cyclesEl.textContent = cycles.toLocaleString();

  // Shift points
  points.shift();
  const last = points[points.length - 1];
  const next = Math.max(30, Math.min(190, last + (Math.random() - 0.5) * 16));
  points.push(next);

  // Render canvas
  ctx.fillStyle = '#020617';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Grid
  ctx.strokeStyle = '#1e293b';
  ctx.lineWidth = 1;
  for (let x = 0; x < canvas.width; x += 50) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }
  for (let y = 0; y < canvas.height; y += 40) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }

  // Waveform
  ctx.beginPath();
  const step = canvas.width / (maxPoints - 1);
  for (let i = 0; i < points.length; i++) {
    const x = i * step;
    const y = points[i];
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.strokeStyle = '#38bdf8';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // Area under curve
  ctx.lineTo(canvas.width, canvas.height);
  ctx.lineTo(0, canvas.height);
  ctx.closePath();
  const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
  gradient.addColorStop(0, 'rgba(56, 189, 248, 0.25)');
  gradient.addColorStop(1, 'rgba(56, 189, 248, 0.0)');
  ctx.fillStyle = gradient;
  ctx.fill();

  requestAnimationFrame(draw);
}

requestAnimationFrame(draw);

toggleBtn.addEventListener('click', () => {
  running = !running;
  toggleBtn.textContent = running ? 'Pause Simulation' : 'Resume Simulation';
  if (running) {
    lastTime = performance.now();
    requestAnimationFrame(draw);
  }
});

resetBtn.addEventListener('click', () => {
  cycles = 0;
  points = [];
  for (let i = 0; i < maxPoints; i++) {
    points.push(110);
  }
  if (cyclesEl) cyclesEl.textContent = '0';
});
