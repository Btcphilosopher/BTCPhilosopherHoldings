import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6.QtWidgets", exc_type=ImportError)
pytestmark = pytest.mark.gui


@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    app = QApplication.instance() or QApplication([])
    yield app


def test_main_window_pages_render_and_execution_disabled_without_isolation(qapp, foundry, example):
    from aureom_foundry.desktop.main_window import NAV, MainWindow

    project, _ = foundry.projects.import_path(example("csv-analysis-cli"))
    win = MainWindow(foundry)
    win.set_project(project)
    for name in NAV:
        win.go(name)
        qapp.processEvents()
        assert win.stack.currentWidget() is win.pages[name]
    assert "NO ISOLATION" in win.chip_env.text()
    win.go("Build")
    assert not win.pages["Build"].b_build.isEnabled()
    assert project.name in win.chip_project.text()
    assert win.chip_cp.text().startswith("Checkpoint: ")
    win.close()


def test_themes(qapp, foundry):
    from aureom_foundry.desktop.main_window import MainWindow

    win = MainWindow(foundry)
    for theme in ("light", "dark"):
        foundry.settings.theme = theme
        win.apply_theme()
        assert win.palette.name == theme
    from aureom_foundry.desktop.theme import LIGHT, stylesheet

    assert LIGHT.copper in stylesheet(LIGHT) and LIGHT.cyan in stylesheet(LIGHT)
    win.close()
