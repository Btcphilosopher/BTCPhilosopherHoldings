from aureom_foundry.builds.errors import classify
from aureom_foundry.builds.models import ErrorCategory as C

CASES = [
    ('Traceback (most recent call last):\n  File "/work/src/app.py", line 3, in <module>\nModuleNotFoundError: No module named \'tabulate\'', C.missing_dependency),
    ('  File "/work/src/x.py", line 2\n    def f(:\nSyntaxError: invalid syntax', C.syntax),
    ("ERROR: Error loading ASGI app. Attribute \"app\" not found in module \"svc.main\".", C.invalid_entry_point),
    ("error: command '/usr/bin/gcc' failed with exit code 1", C.compiler_failure),
    ("ERROR Backend subprocess exited when trying to invoke build_wheel", C.packaging_failure),
    ("urllib.error.URLError: <urlopen error [Errno -3] Temporary failure in name resolution>", C.network_denied),
    ("Traceback (most recent call last):\nZeroDivisionError: division by zero", C.runtime_exception),
    ("ERROR: No matching distribution found for nonexistent-pkg-xyz", C.missing_dependency),
    ("certificate verify failed: self-signed certificate in certificate chain (_ssl.c:1011)", C.configuration),
    ("something odd happened", C.unknown),
]


def test_categories():
    for text, cat in CASES:
        assert classify(text, "build").category == cat, text


def test_missing_module_and_location():
    d = classify(CASES[0][0], "smoke")
    assert d.module == "tabulate" and d.path == "app.py" and d.line == 3 and d.signature


def test_timeouts_and_test_failures():
    assert classify("", "smoke", timed_out=True).category == C.timeout
    assert classify("FAILED tests/test_a.py::test_x - assert 1 == 2", "test", test_failures=1).category == C.test_failure
    assert classify("E   ModuleNotFoundError: No module named 'yaml'", "test", test_failures=2).category == C.missing_dependency


def test_evidence_is_redacted():
    token = "ghp_" + "z" * 36
    d = classify(f"Traceback (most recent call last):\nValueError: bad token {token}", "smoke")
    assert token not in " ".join(d.evidence)
