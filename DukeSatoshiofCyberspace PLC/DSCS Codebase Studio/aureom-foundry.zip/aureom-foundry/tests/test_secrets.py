import logging

from aureom_foundry.diagnostics.logging import RedactingFilter
from aureom_foundry.inspection.secrets import is_sensitive_filename, redact, scan_text

AWS = "AKIA" + "ABCDEFGHIJKLMNOP"
GH = "ghp_" + "a" * 36
SRC = f'''
AWS_KEY = "{AWS}"
token = "{GH}"
password = "changeme"
api_key = "Zx9!kq2LmP0wQ7rT"
DB = "postgres://admin:s3cr3tpass@db/app"
'''


def test_scan_reports_location_but_never_the_value():
    findings = scan_text(SRC, "app/settings.py")
    detectors = {f.detector for f in findings}
    assert {"aws-access-key-id", "github-token", "generic-secret-assignment", "url-credentials"} <= detectors
    dumped = " ".join(f.model_dump_json() for f in findings)
    assert AWS not in dumped and GH not in dumped and "s3cr3tpass" not in dumped
    assert all(f.line > 0 and len(f.fingerprint) == 12 for f in findings)


def test_placeholders_are_not_reported():
    assert not [f for f in scan_text('password = "changeme"\napi_key = "<your-key>"', "x") if f.detector == "generic-secret-assignment"]


def test_redact_masks_values():
    out = redact(SRC)
    assert AWS not in out and GH not in out and "s3cr3tpass" not in out
    assert "[REDACTED:" in out


def test_private_key_block_detected():
    assert scan_text("-----BEGIN RSA PRIVATE KEY-----\nabc\n", "id_rsa")


def test_sensitive_filenames():
    for n in (".env", ".env.production", "id_rsa", "server.pem", "creds/credentials.json", ".npmrc"):
        assert is_sensitive_filename(n), n
    for n in (".env.example", "main.py", "README.md"):
        assert not is_sensitive_filename(n), n


def test_logging_filter_redacts(caplog):
    logger = logging.getLogger("aureom_foundry.test_redaction")
    logger.addFilter(RedactingFilter())
    with caplog.at_level(logging.INFO, logger="aureom_foundry.test_redaction"):
        logger.info("leaked %s", GH)
    assert GH not in caplog.text and "REDACTED" in caplog.text
