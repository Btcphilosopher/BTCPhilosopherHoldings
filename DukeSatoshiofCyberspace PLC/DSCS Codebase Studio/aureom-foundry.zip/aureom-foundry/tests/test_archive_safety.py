import stat
import zipfile

import pytest

from aureom_foundry.config import ImportLimits
from aureom_foundry.inspection.archive import ArchiveRejected, audit_zip, safe_copy_tree, safe_extract_zip


def make_zip(path, entries):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in entries:
            if isinstance(name, zipfile.ZipInfo):
                zf.writestr(name, data)
            else:
                zf.writestr(name, data)
    return path


def test_clean_archive_extracts(tmp_path):
    z = make_zip(tmp_path / "ok.zip", [("proj/main.py", "print(1)\n"), ("proj/pkg/__init__.py", "")])
    rep = safe_extract_zip(z, tmp_path / "out", ImportLimits())
    assert rep.accepted_files == 2
    assert (tmp_path / "out" / "proj" / "main.py").read_text() == "print(1)\n"


@pytest.mark.parametrize("name", ["../evil.txt", "proj/../../evil.txt", "/etc/passwd", "C:/Windows/evil.txt", "..\\evil.txt"])
def test_traversal_and_absolute_paths_rejected(tmp_path, name):
    z = make_zip(tmp_path / "bad.zip", [("proj/main.py", "x"), (name, "pwned")])
    with pytest.raises(ArchiveRejected) as exc:
        safe_extract_zip(z, tmp_path / "out", ImportLimits())
    assert any("unsafe path" in r for r in exc.value.reasons)
    assert not (tmp_path / "evil.txt").exists()
    assert not (tmp_path / "out").exists() or not any((tmp_path / "out").rglob("*"))


def test_symlink_entry_rejected(tmp_path):
    info = zipfile.ZipInfo("proj/link")
    info.create_system = 3
    info.external_attr = (stat.S_IFLNK | 0o777) << 16
    z = make_zip(tmp_path / "link.zip", [("proj/a.py", "x"), (info, "/home")])
    reasons = audit_zip(z, ImportLimits())
    assert any("symbolic link" in r for r in reasons)


def test_bomb_ratio_and_size_limits(tmp_path):
    z = make_zip(tmp_path / "bomb.zip", [("proj/zeros.txt", "0" * 3_000_000)])
    assert any("compression ratio" in r for r in audit_zip(z, ImportLimits()))
    assert any("exceeds" in r for r in audit_zip(z, ImportLimits(max_file_mb=1, max_compression_ratio=100000)))


def test_file_count_limit(tmp_path):
    z = make_zip(tmp_path / "many.zip", [(f"p/{i}.py", "x") for i in range(30)])
    assert any("files; limit" in r for r in audit_zip(z, ImportLimits(max_files=10)))


def test_case_collision_rejected(tmp_path):
    z = make_zip(tmp_path / "case.zip", [("p/Readme.md", "a"), ("p/README.md", "b")])
    assert any("collision" in r for r in audit_zip(z, ImportLimits()))


def test_extracted_files_lose_exec_bits(tmp_path):
    info = zipfile.ZipInfo("p/run.sh")
    info.create_system = 3
    info.external_attr = (stat.S_IFREG | 0o4755) << 16
    z = make_zip(tmp_path / "x.zip", [(info, "#!/bin/sh\n")])
    safe_extract_zip(z, tmp_path / "out", ImportLimits())
    mode = (tmp_path / "out" / "p" / "run.sh").stat().st_mode
    assert not mode & (stat.S_ISUID | stat.S_IXUSR)


def test_folder_copy_skips_symlinks_and_caches(tmp_path):
    src = tmp_path / "src"
    (src / "pkg").mkdir(parents=True)
    (src / "pkg" / "a.py").write_text("x")
    (src / "__pycache__").mkdir()
    (src / "__pycache__" / "a.pyc").write_bytes(b"\0")
    (src / "secret-link").symlink_to("/etc/hostname")
    (src / "dirlink").symlink_to(tmp_path)
    rep = safe_copy_tree(src, tmp_path / "dest", ImportLimits())
    assert (tmp_path / "dest" / "pkg" / "a.py").exists()
    assert not (tmp_path / "dest" / "secret-link").exists()
    assert not (tmp_path / "dest" / "dirlink").exists()
    assert set(rep.symlinks) == {"secret-link", "dirlink"}
    assert not (tmp_path / "dest" / "__pycache__").exists()


def test_malicious_fixture_rejected_by_project_import(foundry, tmp_path):
    import sys

    from conftest import EXAMPLES
    from aureom_foundry.projects.service import ImportFailed

    sys.path.insert(0, str(EXAMPLES / "fixtures"))
    import make_malicious_zip

    z = tmp_path / "m.zip"
    make_malicious_zip.build(str(z))
    with pytest.raises(ImportFailed) as exc:
        foundry.projects.import_path(z)
    text = " ".join(exc.value.reasons)
    assert "unsafe path" in text and "symbolic link" in text and "compression ratio" in text
    assert foundry.projects.list() == []
    assert not list(foundry.settings.projects_dir.iterdir())
