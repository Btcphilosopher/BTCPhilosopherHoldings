from pathlib import Path

import pytest

from aureom_foundry.ai.actions import Operation, OperationRejected, build_changeset
from aureom_foundry.ai.guard import check
from aureom_foundry.ai.proposals import ProposalError


def _project(foundry, example):
    project, _ = foundry.projects.import_path(example("csv-analysis-cli"))
    return project


def test_apply_then_revert_restores_exact_content(foundry, example):
    project = _project(foundry, example)
    root = Path(project.root)
    before = (root / "pyproject.toml").read_text()
    head_before = foundry.projects.repo(project).head()
    prop = foundry.proposals.create(project, "Add dep", "test", [Operation(op="add_dependency", name="tabulate")], source="test")
    assert prop.status == "proposed" and '+dependencies = ["tabulate"]' in prop.diff
    assert (root / "pyproject.toml").read_text() == before  # nothing applied before review
    applied = foundry.proposals.apply(prop.id)
    assert '"tabulate"' in (root / "pyproject.toml").read_text()
    kinds = [c.kind for c in foundry.projects.checkpoints(project.id)]
    assert "apply" in kinds
    change = foundry.db.one("SELECT before_commit, after_commit FROM applied_changes WHERE proposal_id = ?", (prop.id,))
    assert change["before_commit"] == head_before and change["after_commit"] == applied.applied_commit
    reverted = foundry.proposals.revert(applied.id)
    assert reverted.status == "reverted"
    assert (root / "pyproject.toml").read_text() == before
    assert foundry.projects.repo(project).head() != head_before  # revert is a new, auditable commit
    with pytest.raises(ProposalError):
        foundry.proposals.revert(applied.id)


def test_every_applied_patch_can_be_reverted_out_of_order(foundry, example):
    project = _project(foundry, example)
    root = Path(project.root)
    p1 = foundry.proposals.create(project, "readme", "", [Operation(op="edit_file", path="README.md", content="# new readme\n")], source="test")
    p2 = foundry.proposals.create(project, "dep", "", [Operation(op="add_dependency", name="rich")], source="test")
    foundry.proposals.apply(p1.id)
    foundry.proposals.apply(p2.id)
    foundry.proposals.revert(p1.id)  # revert the older change first
    assert "csv-insight" in (root / "README.md").read_text()
    assert '"rich"' in (root / "pyproject.toml").read_text()
    foundry.proposals.revert(p2.id)
    assert '"rich"' not in (root / "pyproject.toml").read_text()


def test_stale_proposal_is_not_applied(foundry, example):
    project = _project(foundry, example)
    root = Path(project.root)
    prop = foundry.proposals.create(project, "edit", "", [Operation(op="edit_file", path="README.md", content="# A\n")], source="test")
    (root / "README.md").write_text("changed by the user\n")
    foundry.projects.checkpoint(project, "user edit")
    with pytest.raises(ProposalError):
        foundry.proposals.apply(prop.id)
    assert foundry.proposals.get(prop.id).status == "stale"


@pytest.mark.parametrize(
    "ops,violation",
    [
        ([Operation(op="edit_file", path="tests/test_stats.py", content="def test_x():\n    pass\n")], "assertion"),
        ([Operation(op="edit_file", path="tests/test_cli.py", content="import pytest\n\n@pytest.mark.skip\ndef test_summary_output():\n    assert main([]) == 0\n")], "skip"),
        ([Operation(op="edit_file", path="tests/test_cli.py", content="")], "empties"),
        ([Operation(op="edit_file", path="src/csv_insight/cli.py", content="try:\n    import x\nexcept Exception:\n    pass\n")], "silently"),
        ([Operation(op="edit_file", path="foundry.yaml", content="schema_version: 1\nproject:\n  name: csv-insight\n  type: python-cli\npermissions:\n  network: true\n")], "permissions"),
    ],
)
def test_guard_blocks_weakening_changes(foundry, example, ops, violation):
    project = _project(foundry, example)
    prop = foundry.proposals.create(project, "bad", "", ops, source="test")
    assert prop.status == "blocked"
    assert any(violation in v for v in prop.violations), prop.violations
    with pytest.raises(ProposalError):
        foundry.proposals.apply(prop.id)


def test_ai_proposals_cannot_delete_or_escape(foundry, example):
    project = _project(foundry, example)
    root = Path(project.root)
    with pytest.raises(OperationRejected):
        build_changeset(root, [Operation(op="delete_file", path="tests/test_cli.py")])
    for path in ("../outside.py", "/etc/passwd", ".git/config", "a\\b.py"):
        with pytest.raises(OperationRejected):
            build_changeset(root, [Operation(op="create_file", path=path, content="x")])
    blocked = foundry.proposals.create(project, "del", "", [Operation(op="delete_file", path="README.md")], source="anthropic:model", allow_delete=True)
    assert blocked.status == "blocked"  # only Foundry's scaffolder may delete


def test_guard_allows_genuine_fix(tmp_path):
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_a.py").write_text("def test_a():\n    assert f() == 2\n")
    cs = build_changeset(tmp_path, [Operation(op="edit_file", path="tests/test_a.py", content="def test_a():\n    assert f() == 2\n    assert f() > 0\n")])
    assert check(cs).ok
