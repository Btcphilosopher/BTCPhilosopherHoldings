"""End-to-end builds with dependency retrieval.

Needs a container runtime, the worker image and registry access, so it runs only when
AUREOM_FOUNDRY_RUN_INTEGRATION=1 (set AUREOM_FOUNDRY_REGISTRY_CA if a TLS-inspecting proxy is in the way).
"""

import hashlib
from pathlib import Path

import pytest

from aureom_foundry.builds.repair import RepairService
from conftest import integration_enabled

pytestmark = [pytest.mark.isolation, pytest.mark.network, pytest.mark.skipif(not integration_enabled(), reason="set AUREOM_FOUNDRY_RUN_INTEGRATION=1")]


def test_cli_import_build_run_export(docker_foundry, example):
    f = docker_foundry
    project, rep = f.projects.import_path(example("csv-analysis-cli"))
    rec = f.builds.run(project)
    assert rec.status.value == "succeeded" and rec.tests_status.value == "passed" and rec.smoke_status.value == "passed"
    assert rec.verified and rec.dependency_lock_reference and rec.toolchain_versions.get("python")
    art_dir = f.builds.build_dir(rec.build_id) / "artefacts"
    for path, digest in rec.artefact_hashes.items():
        assert hashlib.sha256((art_dir / path).read_bytes()).hexdigest() == digest
    con = f.previews.run_cli(rec.build_id, ["summary", "data/sample.csv"])
    assert con.exit_code == 0 and "rows: 6" in con.project_output and "Successfully installed" not in con.project_output
    e = f.exports.export(rec.build_id)
    assert e.verified and Path(e.zip_path).exists()


def test_missing_dependency_repair_cycle(docker_foundry, example):
    f = docker_foundry
    src = example("csv-analysis-cli")
    cli = src / "src" / "csv_insight" / "cli.py"
    text = cli.read_text().replace("from __future__ import annotations\n", "from __future__ import annotations\n\nimport tabulate  # new feature dependency, not declared\n", 1)
    cli.write_text(text)
    project, rep = f.projects.import_path(src)
    assert any(i.code == "undeclared-dependency" for i in rep.all_issues())
    bad = f.builds.run(project)
    assert not bad.verified and bad.diagnosis.category.value == "missing-dependency"
    out = RepairService(f).propose(bad)
    assert out.proposal and out.proposal.status == "proposed"
    f.proposals.apply(out.proposal.id)
    good = f.builds.run(project)
    assert good.verified
    f.proposals.revert(out.proposal.id)
    assert '"tabulate"' not in (Path(project.root) / "pyproject.toml").read_text()


def test_timeout_and_network_fixtures(docker_foundry):
    from conftest import EXAMPLES

    f = docker_foundry
    hang, _ = f.projects.import_path(EXAMPLES / "fixtures" / "hang-cli")
    rec = f.builds.run(hang, "quick")
    assert rec.status.value == "succeeded" and rec.smoke_status.value == "timed_out" and not rec.verified
    phone, _ = f.projects.import_path(EXAMPLES / "fixtures" / "phone-home-cli")
    rec2 = f.builds.run(phone, "quick")
    assert rec2.smoke_status.value == "failed" and rec2.diagnosis.category.value == "network-denied"
    log = Path(rec2.logs["smoke"]).read_text()
    assert "sent!" not in log and "environment secrets visible: []" in log


def test_static_site_build_and_preview(docker_foundry, example):
    f = docker_foundry
    project, _ = f.projects.import_path(example("product-website"))
    rec = f.builds.run(project)
    assert rec.verified
    s = f.previews.start_web(rec.build_id)
    try:
        assert s.readiness.ready
        status, _ = f.previews.request(s, "GET", "/specs.html")
        assert status == 200
    finally:
        s.stop()
