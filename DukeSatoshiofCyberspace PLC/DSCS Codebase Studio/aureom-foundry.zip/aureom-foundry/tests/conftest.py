import os
import shutil
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
EXAMPLES = ROOT / "examples"

from aureom_foundry.config import FoundrySettings  # noqa: E402
from aureom_foundry.isolation.runtime import UnavailableRuntime, detect_runtime  # noqa: E402

IMAGE = os.environ.get("AUREOM_FOUNDRY_PYTHON_IMAGE", "python:3.12-slim")


@pytest.fixture
def settings(tmp_path):
    s = FoundrySettings(data_dir=tmp_path / "foundry-data", runtime="none", python_image=IMAGE)
    ca = os.environ.get("AUREOM_FOUNDRY_REGISTRY_CA")
    if ca:
        s.registry.ca_bundle = ca
    s.ensure_dirs()
    return s


@pytest.fixture
def foundry(settings):
    from aureom_foundry.foundry import Foundry

    f = Foundry(settings, runtime=UnavailableRuntime("disabled for unit tests"))
    yield f
    f.close()


def _real_runtime(settings):
    rt = detect_runtime("auto", [settings.data_dir], [Path(settings.registry.ca_bundle)] if settings.registry.ca_bundle else [])
    if not rt.status().available:
        pytest.skip(f"container runtime unavailable: {rt.status().reason}")
    if not rt.image_present(IMAGE):
        pytest.skip(f"worker image {IMAGE} not present (docker pull it, or set AUREOM_FOUNDRY_PYTHON_IMAGE)")
    return rt


@pytest.fixture
def runtime(settings):
    return _real_runtime(settings)


@pytest.fixture
def docker_foundry(settings):
    from aureom_foundry.foundry import Foundry

    rt = _real_runtime(settings)
    f = Foundry(settings, runtime=rt)
    yield f
    f.close()


@pytest.fixture
def example(tmp_path):
    def copy(name: str) -> Path:
        dest = tmp_path / "src-" / name
        shutil.copytree(EXAMPLES / name, dest)
        return dest

    return copy


def integration_enabled() -> bool:
    return os.environ.get("AUREOM_FOUNDRY_RUN_INTEGRATION") == "1"
