import os
import sys
import threading
import time

from aureom_foundry.isolation.process import CancellationToken, minimal_env, run_process


def test_timeout_kills_process_group(tmp_path):
    marker = tmp_path / "child.pid"
    code = f"import subprocess,sys,time; p=subprocess.Popen([sys.executable,'-c','import time; time.sleep(60)']); open({str(marker)!r},'w').write(str(p.pid)); time.sleep(60)"
    start = time.monotonic()
    res = run_process([sys.executable, "-c", code], timeout_s=1.5)
    assert res.timed_out and not res.ok
    assert time.monotonic() - start < 10
    time.sleep(0.3)
    child = int(marker.read_text())
    try:
        os.kill(child, 0)
        alive = True
    except ProcessLookupError:
        alive = False
    if alive:  # may be a zombie briefly; check state
        with open(f"/proc/{child}/stat") as f:
            alive = f.read().split()[2] != "Z"
    assert not alive, "grandchild survived the timeout"


def test_cancellation():
    tok = CancellationToken()
    threading.Timer(0.5, tok.cancel).start()
    res = run_process([sys.executable, "-c", "import time; time.sleep(30)"], timeout_s=20, cancel=tok)
    assert res.cancelled and not res.ok and res.duration_s < 10


def test_environment_not_inherited(monkeypatch):
    monkeypatch.setenv("MY_API_TOKEN", "leak-me")
    res = run_process([sys.executable, "-c", "import os; print(sorted(os.environ))"], env=minimal_env())
    assert "MY_API_TOKEN" not in res.stdout


def test_output_is_capped():
    res = run_process([sys.executable, "-c", "print('x' * 500000)"], max_output=1000)
    assert res.truncated and len(res.stdout) < 1200


def test_no_shell_interpretation(tmp_path):
    target = tmp_path / "pwned"
    res = run_process(["echo", f"; touch {target}"])
    assert res.ok and not target.exists()
