from pathlib import Path

from aureom_foundry.ai.adapter import AITask, AnthropicAdapter, OfflineAdapter, adapter_for
from aureom_foundry.ai.consent import build_share_preview
from aureom_foundry.builds.models import Diagnosis, ErrorCategory

SCRIPT = '''import argparse
import os
import yaml
import mystery_lib


def main():
    p = argparse.ArgumentParser()
    p.add_argument("path")
    a = p.parse_args()
    print(yaml.safe_load(open(a.path)), os.environ.get("APP_MODE"))


if __name__ == "__main__":
    main()
'''


def test_scaffold_wraps_code_verbatim_and_asks_instead_of_guessing(foundry):
    project, rep = foundry.projects.import_paste(SCRIPT, "yaml-viewer")
    assert project.needs_scaffold and rep.detected_type.value == "python-cli"
    tid, _ = foundry.scaffolder.suggest_template(project)
    assert tid == "python-cli"
    plan, prop = foundry.scaffolder.propose(project, tid)
    files = {o.path: o.content for o in plan.operations if o.op == "create_file"}
    assert files["src/yaml_viewer/app.py"] == SCRIPT  # moved unchanged
    assert '"PyYAML"' in files["pyproject.toml"]
    assert "mystery" not in files["pyproject.toml"]
    assert any("mystery_lib" in q for q in plan.questions)
    assert "app.main()" in files["src/yaml_viewer/__main__.py"]  # only calls user code
    assert 'APP_MODE = ""' in files["config.example.toml"]
    assert {"README.md", "foundry.yaml", "src/yaml_viewer/__init__.py"} <= set(files)
    assert prop.status == "proposed" and "deleted file mode" in prop.diff
    assert (Path(project.root) / "main.py").exists()  # preview only, nothing written yet
    foundry.proposals.apply(prop.id)
    rep2 = foundry.projects.inspect(foundry.projects.get(project.id))
    assert rep2.manifest is not None and rep2.manifest.project.entrypoint == "src/yaml_viewer/__main__.py"
    assert not foundry.projects.get(project.id).needs_scaffold
    assert any(i.code == "unresolved-import" for i in rep2.all_issues())


def test_scaffold_web_api_uses_existing_app(foundry):
    code = "from fastapi import FastAPI\napi = FastAPI()\n\n@api.get('/ping')\ndef ping():\n    return {'pong': True}\n"
    project, _ = foundry.projects.import_paste(code, "ping-api", "server.py")
    plan, prop = foundry.scaffolder.propose(project, "web-api")
    files = {o.path: o.content for o in plan.operations if o.op == "create_file"}
    assert files["src/ping_api/main.py"] == code
    assert "ping_api.main:api" in files["foundry.yaml"]


def test_offline_adapter_fix_and_refusal_to_guess(settings):
    from aureom_foundry.inspection.report import InspectionReport

    rep = InspectionReport(root=str(settings.data_dir))
    ok = OfflineAdapter().run(AITask(kind="propose_fix", diagnosis=Diagnosis(category=ErrorCategory.missing_dependency, summary="", stage="smoke", module="yaml")), rep)
    assert [(o.op, o.name) for o in ok.operations] == [("add_dependency", "PyYAML")]
    unknown = OfflineAdapter().run(AITask(kind="propose_fix", diagnosis=Diagnosis(category=ErrorCategory.missing_dependency, summary="", stage="smoke", module="pyyml")), rep)
    assert unknown.insufficient_evidence and not unknown.operations
    syntax = OfflineAdapter().run(AITask(kind="propose_fix", diagnosis=Diagnosis(category=ErrorCategory.syntax, summary="", stage="build")), rep)
    assert syntax.insufficient_evidence


def test_external_ai_requires_project_level_opt_in(foundry, example):
    project, _ = foundry.projects.import_path(example("csv-analysis-cli"))
    foundry.settings.ai.provider = "anthropic"
    assert isinstance(adapter_for(foundry.settings, project), OfflineAdapter)
    foundry.projects.set_ai_sharing(project, True)
    assert isinstance(adapter_for(foundry.settings, foundry.projects.get(project.id)), AnthropicAdapter)


def test_share_preview_excludes_and_redacts(foundry, example):
    src = example("csv-analysis-cli")
    token = "ghp_" + "k" * 36
    (src / ".env").write_text(f"T={token}\n")
    (src / "src" / "csv_insight" / "keys.py").write_text(f'KEY = "{token}"\n')
    project, rep = foundry.projects.import_path(src)
    prev = build_share_preview(Path(project.root), rep, 200_000)
    assert ".env" in [p for p, _ in prev.excluded]
    shared = {f.path: f for f in prev.files}
    assert shared["src/csv_insight/keys.py"].redactions == 1
    assert token not in "".join(prev.payload().values())


def test_repair_stops_when_evidence_insufficient_and_is_bounded(foundry, example):
    from aureom_foundry.builds.models import BuildRecord, BuildStatus
    from aureom_foundry.builds.repair import RepairService
    from aureom_foundry.persistence.db import now

    project, _ = foundry.projects.import_path(example("csv-analysis-cli"))
    base = dict(project_id=project.id, project_name=project.name, project_type=project.type, adapter="python-package", source_checkpoint="x", source_hash="y", manifest_version=1, build_profile="p", started_at=now(), status=BuildStatus.failed)
    unknown = BuildRecord(build_id="b1", diagnosis=Diagnosis(category=ErrorCategory.unknown, summary="?", stage="build"), **base)
    out = RepairService(foundry).propose(unknown)
    assert out.stopped and out.proposal is None
    d = Diagnosis(category=ErrorCategory.missing_dependency, summary="", stage="smoke", module="yaml", signature="sig1")
    rec = BuildRecord(build_id="b2", diagnosis=d, **base)
    svc = RepairService(foundry)
    first = svc.propose(rec)
    assert first.proposal and first.proposal.status == "proposed"
    foundry.settings.max_repair_attempts = 1
    again = svc.propose(rec)
    assert again.stopped and "limit" in again.reason
