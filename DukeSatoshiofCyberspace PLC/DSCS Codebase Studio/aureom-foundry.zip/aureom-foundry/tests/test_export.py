import hashlib
import json
import zipfile
from pathlib import Path

import pytest

from aureom_foundry.adapters.base import sha256_file
from aureom_foundry.builds.models import Artefact, BuildRecord, BuildStatus, StageStatus, TestReport
from aureom_foundry.packaging.export import ExportBlocked
from aureom_foundry.persistence.db import now

TOKEN = "ghp_" + "q" * 36


def fake_build(foundry, example, *, verified=True, build_id="bld_fake01"):
    """A build record + artefacts created without running workers (export is pure file work)."""

    src = example("csv-analysis-cli")
    (src / ".env").write_text(f"GITHUB_TOKEN={TOKEN}\n")
    (src / "config.example.toml").write_text(f'delimiter = ","\napi_token = "{TOKEN}"\n')
    project, _ = foundry.projects.import_path(src)
    bdir = foundry.builds.build_dir(build_id)
    cp = foundry.projects.checkpoint(project, "x")
    foundry.projects.repo(project).archive_to(cp.commit_sha, bdir / "source")
    dist = bdir / "artefacts" / "dist"
    dist.mkdir(parents=True)
    whl = dist / "csv_insight-1.0.0-py3-none-any.whl"
    with zipfile.ZipFile(whl, "w") as zf:
        zf.writestr("csv_insight-1.0.0.dist-info/METADATA", "Metadata-Version: 2.1\nName: csv-insight\nVersion: 1.0.0\nLicense: MIT\n")
    art = Artefact(path="dist/" + whl.name, sha256=sha256_file(whl), size=whl.stat().st_size, kind="wheel")
    rec = BuildRecord(
        build_id=build_id, project_id=project.id, project_name=project.name, project_type=project.type, adapter="python-package",
        source_checkpoint=cp.commit_sha, source_hash="h", manifest_version=1, build_profile="local-release", started_at=now(), completed_at=now(),
        status=BuildStatus.succeeded, tests_status=StageStatus.passed if verified else StageStatus.failed,
        smoke_status=StageStatus.passed, artefacts=[art], artefact_hashes={art.path: art.sha256},
        tests=TestReport(total=2, passed=2 if verified else 1, failed=0 if verified else 1, status=StageStatus.passed if verified else StageStatus.failed),
    )
    foundry.builds._save(rec, insert=True)
    return project, rec, bdir


def test_export_contents_checksums_and_secret_exclusion(foundry, example):
    project, rec, bdir = fake_build(foundry, example)
    e = foundry.exports.export(rec.build_id)
    root = Path(e.path)
    names = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    for required in ("artefacts/csv_insight-1.0.0-py3-none-any.whl", "CHECKSUMS.sha256", "dependency-inventory.json", "LICENSES.md", "RUN.md", "LIMITATIONS.md", "BUILD-SUMMARY.md", "build-record.json", "export-manifest.json", "config.example.toml"):
        assert required in names, required
    assert not any(".env" == Path(n).name for n in names)
    everything = "".join(p.read_text("utf-8", "replace") for p in root.rglob("*") if p.is_file() and p.suffix != ".whl")
    assert TOKEN not in everything
    assert 'api_token = ""' in (root / "config.example.toml").read_text()
    assert "MIT" in (root / "LICENSES.md").read_text()
    for line in (root / "CHECKSUMS.sha256").read_text().splitlines():
        digest, rel = line.split("  ", 1)
        assert hashlib.sha256((root / rel).read_bytes()).hexdigest() == digest
    excluded = json.loads((root / "export-manifest.json").read_text())["excluded"]
    assert any(x["path"] == "source:.env" for x in excluded)
    assert hashlib.sha256(Path(e.zip_path).read_bytes()).hexdigest() == e.zip_sha256
    with zipfile.ZipFile(e.zip_path) as zf:
        assert not any(n.endswith(".env") for n in zf.namelist())


def test_tampered_artefact_blocks_export(foundry, example):
    _, rec, bdir = fake_build(foundry, example, build_id="bld_fake02")
    whl = next((bdir / "artefacts" / "dist").glob("*.whl"))
    whl.write_bytes(whl.read_bytes() + b"tampered")
    with pytest.raises(ExportBlocked, match="hash mismatch"):
        foundry.exports.export(rec.build_id)


def test_unverified_requires_explicit_choice_and_is_labelled(foundry, example):
    _, rec, _ = fake_build(foundry, example, verified=False, build_id="bld_fake03")
    with pytest.raises(ExportBlocked, match="not verified"):
        foundry.exports.export(rec.build_id)
    e = foundry.exports.export(rec.build_id, allow_unverified=True)
    assert not e.verified
    assert "UNVERIFIED" in (Path(e.path) / "LIMITATIONS.md").read_text()


def test_failed_build_cannot_be_exported(foundry, example):
    _, rec, _ = fake_build(foundry, example, build_id="bld_fake04")
    foundry.db.execute("UPDATE builds SET status = 'interrupted' WHERE id = ?", (rec.build_id,))
    with pytest.raises(ExportBlocked, match="interrupted"):
        foundry.exports.export(rec.build_id, allow_unverified=True)
