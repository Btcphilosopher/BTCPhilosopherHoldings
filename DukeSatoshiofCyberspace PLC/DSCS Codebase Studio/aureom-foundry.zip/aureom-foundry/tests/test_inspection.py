from aureom_foundry.inspection.report import inspect_project
from aureom_foundry.manifests.propose import propose_manifest
from conftest import EXAMPLES


def test_example_types_detected(settings):
    expected = {"csv-analysis-cli": "python-cli", "inventory-api": "python-fastapi", "notes-desktop": "python-pyside6", "product-website": "static-site"}
    for name, t in expected.items():
        rep = inspect_project(EXAMPLES / name, settings)
        assert rep.detected_type.value == t, name
        assert not rep.has_errors(), [i.label() for i in rep.all_issues()]


def test_inspection_never_executes_code(tmp_path, settings):
    marker = tmp_path / "executed.txt"
    (tmp_path / "p").mkdir()
    (tmp_path / "p" / "main.py").write_text(f"open({str(marker)!r}, 'w').write('ran')\nif __name__ == '__main__':\n    pass\n")
    (tmp_path / "p" / "setup.py").write_text(f"open({str(marker)!r}, 'w').write('ran')\n")
    (tmp_path / "p" / "conftest.py").write_text(f"open({str(marker)!r}, 'w').write('ran')\n")
    rep = inspect_project(tmp_path / "p", settings)
    assert not marker.exists()
    assert any(i.code == "legacy-manifest" for i in rep.all_issues())


def test_undeclared_and_unresolved_imports(tmp_path, settings):
    p = tmp_path / "p"
    p.mkdir()
    (p / "app.py").write_text("import yaml\nimport frobnicator_x\nimport json\nif __name__ == '__main__':\n    pass\n")
    (p / "requirements.txt").write_text("requests==2.31.0\n")
    rep = inspect_project(p, settings)
    d = rep.dependencies
    assert d.undeclared_imports == {"yaml": "PyYAML"}
    assert "frobnicator_x" in d.unresolved_imports
    codes = {i.code for i in d.issues}
    assert {"undeclared-dependency", "unresolved-import"} <= codes


def test_missing_entry_point_manifest_and_syntax_error(tmp_path, settings):
    p = tmp_path / "p"
    p.mkdir()
    (p / "lib.py").write_text("def f(:\n  pass\n")
    rep = inspect_project(p, settings)
    codes = {i.code for i in rep.all_issues()}
    assert {"syntax-error", "missing-entry-point", "missing-manifest", "missing-foundry-manifest"} <= codes


def test_static_missing_asset_and_proposal(tmp_path, settings):
    p = tmp_path / "site"
    p.mkdir()
    (p / "index.html").write_text('<html lang="en"><head><title>x</title><link href="css/missing.css" rel="stylesheet"></head></html>')
    rep = inspect_project(p, settings)
    assert any(i.code == "missing-asset" for i in rep.all_issues())
    prop = propose_manifest(rep, "My Site!")
    assert prop.manifest and prop.manifest.project.type.value == "static-site" and prop.manifest.project.name == "My-Site"


def test_secrets_flagged_without_values(tmp_path, settings):
    p = tmp_path / "p"
    p.mkdir()
    token = "ghp_" + "b" * 36
    (p / "main.py").write_text(f'TOKEN = "{token}"\nif __name__ == "__main__":\n    print(1)\n')
    (p / ".env").write_text("X=1\n")
    rep = inspect_project(p, settings)
    assert rep.secrets and rep.sensitive_files == [".env"]
    assert token not in rep.model_dump_json()


def test_unknown_project_asks_question(tmp_path, settings):
    p = tmp_path / "p"
    p.mkdir()
    (p / "notes.txt").write_text("hello")
    prop = propose_manifest(inspect_project(p, settings), "p")
    assert prop.manifest is None and prop.questions
