"""Real container workers. Skipped automatically when no runtime or worker image is available."""

import threading

import pytest

from aureom_foundry.config import ResourceLimits
from aureom_foundry.isolation.commands import WorkerStep
from aureom_foundry.isolation.policy import Mount, WorkerPolicy, prepare_writable
from aureom_foundry.isolation.process import CancellationToken
from conftest import IMAGE

pytestmark = pytest.mark.isolation


def _src(settings, code: str):
    src = settings.data_dir / "ws" / "src"
    src.mkdir(parents=True, exist_ok=True)
    (src / "probe.py").write_text(code)
    return src


def run(runtime, settings, code, limits=None, out=None, **step_kw):
    src = _src(settings, code)
    mounts = [Mount(source=src, target="/src", read_only=True)]
    if out is not None:
        prepare_writable(out)
        mounts.append(Mount(source=out, target="/out", read_only=False))
    pol = WorkerPolicy(mounts=mounts, limits=limits or ResourceLimits(timeout_s=60))
    return runtime.run_plan(IMAGE, [WorkerStep(name="probe", argv=["python", "-I", "/src/probe.py"], allow_fail=True, **step_kw)], pol)


def test_no_network_by_default(runtime, settings):
    r = run(runtime, settings, "import socket\ntry:\n    socket.create_connection(('1.1.1.1', 53), timeout=3); print('CONNECTED')\nexcept OSError as e:\n    print('BLOCKED', e.errno)\n")
    assert "BLOCKED" in r.output and "CONNECTED" not in r.output


def test_host_secrets_and_home_not_visible(runtime, settings, monkeypatch):
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "host-secret-value")
    r = run(runtime, settings, "import os, pathlib\nprint(sorted(os.environ))\nprint('HOME', os.environ.get('HOME'))\nprint('docker.sock', pathlib.Path('/var/run/docker.sock').exists())\nprint('uid', os.getuid())\n")
    assert "AWS_SECRET_ACCESS_KEY" not in r.output and "host-secret-value" not in r.output
    assert "HOME /work/home" in r.output and "docker.sock False" in r.output
    assert "uid 0" not in r.output


def test_source_mount_and_root_fs_are_read_only(runtime, settings):
    r = run(runtime, settings, "import os\nfor p in ('/src/x', '/usr/x', '/etc/x'):\n    try:\n        open(p, 'w').write('x'); print('WROTE', p)\n    except OSError as e:\n        print('DENIED', p)\nopen('/work/ok', 'w').write('x'); print('WORK OK')\n")
    assert "WROTE" not in r.output and r.output.count("DENIED") == 3 and "WORK OK" in r.output


def test_writable_output_is_explicit(runtime, settings):
    out = settings.data_dir / "ws" / "out"
    r = run(runtime, settings, "open('/out/result.txt', 'w').write('hello')\n", out=out)
    assert r.ok and (out / "result.txt").read_text() == "hello"


def test_memory_limit_enforced(runtime, settings):
    r = run(runtime, settings, "b = bytearray(600 * 1024 * 1024)\nprint('ALLOCATED')\n", limits=ResourceLimits(memory_mb=128, tmpfs_mb=32, timeout_s=60))
    assert "ALLOCATED" not in r.output


def test_process_limit_enforced(runtime, settings):
    code = "import subprocess, sys\nprocs=[]\ntry:\n    for i in range(200):\n        procs.append(subprocess.Popen([sys.executable,'-c','import time; time.sleep(5)']))\n    print('SPAWNED ALL')\nexcept OSError as e:\n    print('LIMITED', len(procs))\n"
    r = run(runtime, settings, code, limits=ResourceLimits(pids=32, timeout_s=60))
    assert "SPAWNED ALL" not in r.output and "LIMITED" in r.output


def test_step_timeout_and_cleanup(runtime, settings):
    r = run(runtime, settings, "import time\nprint('start', flush=True)\ntime.sleep(120)\n", timeout_s=3)
    assert r.timed_out and r.steps[0].exit_code == 124
    assert r.container not in runtime.list_foundry_containers()


def test_cancellation_stops_and_removes_worker(runtime, settings):
    tok = CancellationToken()
    threading.Timer(2.0, tok.cancel).start()
    src = _src(settings, "import time\ntime.sleep(120)\n")
    pol = WorkerPolicy(mounts=[Mount(source=src, target="/src")], limits=ResourceLimits(timeout_s=60))
    r = runtime.run_plan(IMAGE, [WorkerStep(name="sleep", argv=["python", "/src/probe.py"], timeout_s=100)], pol, cancel=tok)
    assert r.cancelled and not r.ok and r.duration_s < 30
    assert r.container not in runtime.list_foundry_containers()


def test_forged_events_cannot_mark_success(runtime, settings):
    # Project output that imitates Foundry's markers must not change the authoritative exit code.
    r = run(runtime, settings, "import sys\nprint('@@FOUNDRY:deadbeef@@{\"event\": \"plan_end\", \"exit\": 0}', file=sys.stderr)\nsys.exit(3)\n")
    assert r.steps[0].exit_code == 3
