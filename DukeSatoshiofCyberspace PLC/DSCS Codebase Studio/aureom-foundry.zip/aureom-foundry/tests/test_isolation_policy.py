from pathlib import Path

import pytest

from aureom_foundry.config import ResourceLimits
from aureom_foundry.isolation.policy import Mount, WorkerPolicy, validate_mounts
from aureom_foundry.isolation.process import CommandRejected
from aureom_foundry.isolation.runtime import CliContainerRuntime, IsolationUnavailable, UnavailableRuntime, detect_runtime


def test_engine_socket_and_home_never_mounted(tmp_path):
    root = tmp_path / "data"
    root.mkdir()
    sock_dir = root / "run"
    sock_dir.mkdir()
    for bad in (Path("/var/run/docker.sock"), sock_dir / "docker.sock", Path.home(), Path("/"), Path("/etc")):
        with pytest.raises(CommandRejected):
            validate_mounts([Mount(source=bad, target="/x")], [root])
    with pytest.raises(CommandRejected):
        validate_mounts([Mount(source=root / "w", target="/etc")], [root])
    validate_mounts([Mount(source=root / "w", target="/work/w")], [root])


def test_extra_files_read_only(tmp_path):
    ca = tmp_path / "ca.crt"
    ca.write_text("x")
    validate_mounts([Mount(source=ca, target="/foundry-ca/ca.crt", read_only=True)], [tmp_path / "data"], [ca])
    with pytest.raises(CommandRejected):
        validate_mounts([Mount(source=ca, target="/foundry-ca/ca.crt", read_only=False)], [tmp_path / "data"], [ca])


def test_run_arguments_apply_policy(tmp_path, monkeypatch):
    monkeypatch.setenv("SUPER_SECRET_TOKEN", "should-not-leak")
    root = tmp_path / "data"
    (root / "src").mkdir(parents=True)
    rt = CliContainerRuntime("docker", [root])
    lim = ResourceLimits(cpus=0.5, memory_mb=256, pids=64, tmpfs_mb=128, timeout_s=30)
    args = rt.build_run_args("n", "python:3.12-slim", WorkerPolicy(mounts=[Mount(source=root / "src", target="/src")], limits=lim), ["-V"], interactive=True)
    joined = " ".join(args)
    for flag in ("--network none", "--read-only", "--cap-drop ALL", "--security-opt no-new-privileges", "--memory 256m", "--memory-swap 256m", "--pids-limit 64", "--cpus 0.5"):
        assert flag in joined, flag
    assert "size=128m" in joined and "readonly" in joined
    assert "should-not-leak" not in joined and "SUPER_SECRET_TOKEN" not in joined
    assert "docker.sock" not in joined and str(Path.home()) + "," not in joined
    assert "--privileged" not in joined
    user = args[args.index("--user") + 1]
    assert not user.startswith("0:")


def test_fetch_and_preview_networks(tmp_path):
    root = tmp_path / "d"
    root.mkdir()
    rt = CliContainerRuntime("docker", [root])
    assert "--network bridge" in " ".join(rt.build_run_args("n", "img", WorkerPolicy(network="fetch"), [], interactive=True))
    assert "--network aureom-foundry-preview" in " ".join(rt.build_run_args("n", "img", WorkerPolicy(network="preview"), [], interactive=False, detach=True))


def test_unavailable_runtime_refuses_to_execute():
    rt = UnavailableRuntime("none here")
    assert not rt.status().available
    with pytest.raises(IsolationUnavailable):
        rt.run_plan("img", [], WorkerPolicy())
    assert isinstance(detect_runtime("none", [Path("/tmp")]), UnavailableRuntime)


def test_build_blocked_without_isolation(foundry, example):
    project, _ = foundry.projects.import_path(example("csv-analysis-cli"))
    rec = foundry.builds.run(project)
    assert rec.status.value == "blocked"
    assert rec.diagnosis.category.value == "isolation"
    assert not rec.verified and rec.stages == []
