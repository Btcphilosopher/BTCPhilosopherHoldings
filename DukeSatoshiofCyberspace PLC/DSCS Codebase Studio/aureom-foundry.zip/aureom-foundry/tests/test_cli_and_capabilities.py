from aureom_foundry.adapters.base import Support, capability_matrix


def test_capability_matrix_is_honest():
    rows = {r.project_type: r for r in capability_matrix()}
    for t in ("python-cli", "python-fastapi", "python-pyside6", "static-site"):
        assert rows[t].build == Support.implemented
    for t in ("node-app", "rust-binary", "kotlin-android", "mixed"):
        assert rows[t].detect == Support.detected_only and rows[t].build == Support.unsupported
    assert rows["python-pyside6"].smoke == Support.partial
    assert "not a desktop app" in rows["static-site"].outputs


def test_cli_import_inspect_and_capabilities(settings, capsys, monkeypatch, example):
    from aureom_foundry import cli

    monkeypatch.setenv("AUREOM_FOUNDRY_HOME", str(settings.data_dir))
    monkeypatch.setenv("AUREOM_FOUNDRY_RUNTIME", "none")
    assert cli.main(["capabilities"]) == 0
    assert "detected only" in capsys.readouterr().out
    assert cli.main(["import", str(example("product-website")), "--name", "site"]) == 0
    out = capsys.readouterr().out
    assert "static-site" in out
    assert cli.main(["inspect", "site"]) == 0
    assert "entry points" in capsys.readouterr().out
    assert cli.main(["build", "site"]) == 1  # blocked: no isolation
    assert "blocked" in capsys.readouterr().out
    assert cli.main(["doctor"]) == 2
