from pathlib import Path

from aureom_foundry.builds.models import BuildRecord, BuildStatus
from aureom_foundry.foundry import Foundry
from aureom_foundry.isolation.runtime import UnavailableRuntime
from aureom_foundry.persistence.db import now
from aureom_foundry.persistence.recovery import InstanceLock, recover


def test_interrupted_build_is_never_success(foundry, example, settings):
    project, _ = foundry.projects.import_path(example("csv-analysis-cli"))
    rec = BuildRecord(build_id="bld_crash1", project_id=project.id, project_name=project.name, project_type=project.type, adapter="python-package",
                      source_checkpoint="abc", source_hash="def", manifest_version=1, build_profile="local-release", started_at=now(), status=BuildStatus.running)
    foundry.builds._save(rec, insert=True)
    # Simulate crash debris.
    (settings.tmp_dir / "zip-staging").mkdir(parents=True)
    (settings.tmp_dir / "zip-staging" / "f.py").write_text("x")
    partial = settings.data_dir / "cache" / "wheelhouse" / "partial"
    partial.mkdir(parents=True)
    complete = settings.data_dir / "cache" / "wheelhouse" / "complete"
    complete.mkdir(parents=True)
    (complete / ".complete").write_text("x")
    (complete / "foundry.lock.json").write_text("{}")
    export = settings.exports_dir / "keep.zip"
    export.write_text("export")
    foundry.close()

    f2 = Foundry(settings, runtime=UnavailableRuntime())
    try:
        assert "bld_crash1" in f2.recovery.interrupted_builds
        got = f2.builds.get("bld_crash1")
        assert got.status == BuildStatus.interrupted and not got.verified
        assert not (settings.tmp_dir / "zip-staging").exists()
        assert not partial.exists() and complete.exists()
        assert export.exists()
        assert Path(project.root).exists() and (Path(project.root) / "pyproject.toml").exists()
        assert any(a["kind"] == "recovery" for a in f2.db.activity())
    finally:
        f2.close()


def test_second_instance_skips_destructive_recovery(settings):
    from aureom_foundry.persistence.db import Database

    lock = InstanceLock(settings.data_dir / "foundry.instance.lock")
    assert lock.acquire()
    other = InstanceLock(settings.data_dir / "foundry.instance.lock")
    assert not other.acquire()
    rep = recover(settings, Database(settings.db_path), None, have_lock=other.acquire())
    assert rep.skipped_reason
    lock.release()
