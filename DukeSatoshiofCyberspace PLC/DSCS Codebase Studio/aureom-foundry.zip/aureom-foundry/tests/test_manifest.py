import pytest

from aureom_foundry.manifests.effective import compute_effective
from aureom_foundry.manifests.loader import ManifestError, load_manifest, parse_manifest_text
from conftest import EXAMPLES

BASE = """
schema_version: 1
project:
  name: demo
  type: python-cli
  entrypoint: src/demo/__main__.py
"""


@pytest.mark.parametrize("name", ["csv-analysis-cli", "inventory-api", "notes-desktop", "product-website", "fixtures/hang-cli", "fixtures/phone-home-cli"])
def test_example_manifests_validate(name):
    m = load_manifest(EXAMPLES / name)
    assert m is not None and m.schema_version == 1


@pytest.mark.parametrize(
    "bad",
    [
        BASE.replace("src/demo/__main__.py", "/etc/passwd"),
        BASE.replace("src/demo/__main__.py", "../outside.py"),
        BASE.replace("python-cli", "cobol-mainframe"),
        BASE.replace("schema_version: 1", "schema_version: 7"),
        BASE + "surprise: true\n",
        BASE + "output:\n  directory: /tmp/out\n",
        BASE + "smoke:\n  http_path: https://evil.example/\n",
        "!!python/object/apply:os.system ['echo pwned']",
        "- just\n- a list\n",
    ],
)
def test_invalid_manifests_rejected(bad):
    with pytest.raises(ManifestError):
        parse_manifest_text(bad)


def test_permissions_are_requests_not_grants(settings):
    m = parse_manifest_text(BASE + "permissions:\n  network: true\n  host_filesystem: true\n")
    eff = compute_effective(m, settings, {}, "docker", True)
    assert eff.execution_network.requested and not eff.execution_network.allowed
    assert eff.host_filesystem.requested and not eff.host_filesystem.allowed
    granted = compute_effective(m, settings, {"execution_network": True}, "docker", True)
    assert granted.execution_network.allowed
    assert not granted.host_filesystem.allowed  # never grantable


def test_grant_without_request_does_not_enable_network(settings):
    m = parse_manifest_text(BASE)
    assert not compute_effective(m, settings, {"execution_network": True}, "docker", True).execution_network.allowed


def test_execution_disabled_without_isolation(settings):
    eff = compute_effective(parse_manifest_text(BASE), settings, {}, "none", False)
    assert eff.execution_enabled is False
    assert dict(eff.rows())["Untrusted execution"] == "DISABLED"
