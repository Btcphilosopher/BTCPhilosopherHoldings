"""Render every desktop page offscreen and save PNG screenshots.

Usage: QT_QPA_PLATFORM=offscreen python scripts/screenshots.py OUTPUT_DIR [light|dark]
Uses the Foundry data directory from AUREOM_FOUNDRY_HOME.
"""

import sys
from pathlib import Path

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from aureom_foundry.desktop.main_window import NAV, MainWindow  # noqa: E402
from aureom_foundry.foundry import Foundry  # noqa: E402


def main() -> int:
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "screenshots")
    out.mkdir(parents=True, exist_ok=True)
    app = QApplication(sys.argv[:1])
    f = Foundry()
    if len(sys.argv) > 2:
        f.settings.theme = sys.argv[2]
    win = MainWindow(f)
    win.resize(1440, 900)
    win.show()
    projects = f.projects.list()
    target = next((p for p in projects if p.name == "csv-insight"), projects[0] if projects else None)
    if target:
        win.set_project(target)
    names = sys.argv[3].split(",") if len(sys.argv) > 3 else NAV
    for name in names:
        win.go(name)
        for _ in range(20):
            app.processEvents()
        path = out / f"{f.settings.theme}-{NAV.index(name) + 1:02d}-{name.lower()}.png"
        win.grab().save(str(path))
        print(path)
    QTimer.singleShot(0, app.quit)
    app.exec()
    return 0


if __name__ == "__main__":
    sys.exit(main())
