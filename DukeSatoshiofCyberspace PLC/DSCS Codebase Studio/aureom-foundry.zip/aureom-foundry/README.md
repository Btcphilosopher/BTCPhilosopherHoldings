# AUREOM FOUNDRY — Code to Application

**Drop your code here. Build what comes next.**

Aureom Foundry is a desktop workbench (Python + PySide6) that takes source code you supply,
tells you what it is and what it needs, and turns it into a traceable software package through a
controlled workflow:

```
Drop code → inspect → configure → preview → build → test → package → export
```

Every build runs in a constrained container worker. Every change is a reviewable diff with a Git
checkpoint and can be reverted. Every export carries checksums, a dependency inventory, licence
information and an honest build/test/smoke summary.

![Build page](docs/screenshots/light-06-build.png)

---

## What "make software" means here

Foundry distinguishes five activities and never blurs them:

| Activity | What Foundry does | What it does **not** do |
| --- | --- | --- |
| **Import** | Copies a folder, files, ZIP, local Git repo, pasted code or a written brief into a managed working copy, and inspects it *without executing anything*. | Modify or run your original files. |
| **Generate** | Scaffolds a minimal project around loose code (source layout, `pyproject.toml`, entry point, README, run instructions, build profile, config example). Optionally asks an AI provider for requested features. | Invent business logic to make a build look successful. Unknowns become questions. |
| **Repair** | Classifies a failure, proposes a bounded patch as a diff, checkpoints, applies on approval, reruns the checks. | Delete/skip/weaken tests, swallow errors, guess package names, or loop forever. |
| **Build** | Runs the language's own toolchain (pip, `build`, pytest, uvicorn, PyInstaller…) inside isolated workers. | Reimplement compilers, or run untrusted code on the host. |
| **Package** | Collects allowlisted artefacts with SHA-256 checksums, lock file, licences, run instructions and limitations. | Sign, notarise, publish or deploy — those are separate steps. |

Arbitrary code cannot automatically become a complete application. Foundry detects what is
missing (entry point, manifest, undeclared dependencies, unsupported runtime, missing assets…) and
explains what you must supply.

## Status at a glance

| Capability | Status | Notes |
| --- | --- | --- |
| Python CLI: import → inspect → isolated build → test → run → export | **Implemented, verified** | wheel + sdist, console preview |
| FastAPI service: build, test, HTTP readiness smoke, preview, API explorer | **Implemented, verified** | optional OCI image (built with `--network none`) |
| PySide6 desktop app: build, test, offscreen launch check | **Implemented, verified** with the Qt worker image | without that image the check reports *unsupported* instead of passing |
| PySide6 Linux desktop executable (PyInstaller) | **Implemented, verified** with the Qt worker image | Linux x86_64 only; no signing/installers |
| Static website: validate, link/asset checks, served preview, ZIP export | **Implemented, verified** | static website export — not a desktop app |
| Node.js, Rust, Kotlin Android, mixed projects | **Detected only** | inspected and classified; no build adapter (see `docs/adapters.md`) |
| Loose-code scaffolding (4 templates) | **Implemented** | previewed as a diff, revertible |
| Offline AI assistant (heuristics) | **Implemented** | explains errors, proposes dependency fixes, drafts README |
| Claude AI adapter (`anthropic` SDK) | **Implemented, not exercised live** | tested with a stubbed client; needs your API key and per-project consent |
| Desktop screenshot of a running GUI in a virtual display (Xvfb) | **Deferred** | launch checks use Qt's offscreen platform |
| Registry-only egress filtering for the fetch stage | **Deferred** | fetch uses the default bridge network; see `docs/isolation.md` |
| Deployment, signing, notarisation, app-store submission | **Out of scope** | deliberately separate from local packaging |

Nothing in this repository simulates a result. The demonstration report and test results quoted
in `docs/` come from real runs (see `docs/demo-report.md` and `docs/testing.md`).

## Install

Requirements: Python 3.11+, Git, and Docker or Podman for isolated execution.

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install ".[desktop]"          # desktop UI (PySide6)
pip install ".[desktop,ai,dev]"   # + optional Claude adapter + pytest
```

Pull the default worker image (or point Foundry at a mirror in Settings):

```bash
docker pull python:3.12-slim
```

Optional, for PySide6 launch checks and desktop executables:

```bash
docker build -t aureom-foundry/worker-python-qt:1 -f docker/worker-python-qt.Dockerfile docker
```

Check the setup:

```bash
aureom-foundry doctor
```

If no container runtime is reachable, Foundry still imports, inspects and edits projects, but
builds, tests and previews of untrusted code are **disabled** — it never falls back to the host.
See [`docs/isolation.md`](docs/isolation.md) for Docker/Podman setup, rootless mode, TLS-inspecting
proxies and platform limitations.

## Use

Desktop:

```bash
aureom-foundry-desktop        # or: aureom-foundry gui
```

Navigation: **Projects · Import · Editor · Dependencies · Preview · Build · Tests · Packages ·
Activity · Settings**. The header always shows the selected project, active build profile,
execution environment and latest checkpoint. Light and dark themes are in Settings.

Command line (same services, useful for CI):

```bash
aureom-foundry import examples/csv-analysis-cli --name csv-insight
aureom-foundry inspect csv-insight
aureom-foundry manifest csv-insight            # effective settings (requests vs. grants)
aureom-foundry build csv-insight
aureom-foundry run <build-id> summary data/sample.csv
aureom-foundry export <build-id>
aureom-foundry repair <failed-build-id>        # propose → review with `show` → `apply` / `revert`
```

Run the scripted 12-step demonstration plus the three security fixtures:

```bash
aureom-foundry demo --report demo-report.md
```

## Repository layout

```
aureom-foundry/
├── pyproject.toml           packaging (wheel ships templates as data files)
├── src/aureom_foundry/
│   ├── desktop/             PySide6 UI: theme, widgets, ten pages, review dialog
│   ├── projects/            import service, managed working copies, Git checkpoints
│   ├── inspection/          archive safety, inventory, AST analysis, secrets, reports
│   ├── manifests/           foundry.yaml schema, loader, proposals, effective settings
│   ├── scaffolding/         loose-code scaffolder
│   ├── editor/              path-contained file access
│   ├── dependencies/        manifest parsers, analysis, fetch/lock/offline install
│   ├── isolation/           process runner, command validation, policy, container runtime, worker
│   ├── adapters/            Python CLI / FastAPI / PySide6 / static site + detected-only extensions
│   ├── builds/              orchestration, records, error classification, repair workflow
│   ├── previews/            readiness checks, console/web/API/desktop previews
│   ├── testing/             JUnit result parsing (tests reported separately from builds)
│   ├── packaging/           export with allowlists, checksums, licences, summaries
│   ├── ai/                  adapters, consent/share preview, operations, guard, proposals
│   ├── persistence/         SQLite store, crash recovery
│   └── diagnostics/         issues, redacting logging
├── templates/               python-cli, web-api, desktop-utility, static-site
├── examples/                four demo projects + security fixtures
├── docker/                  worker image Dockerfiles
├── scripts/                 screenshot renderer
├── tests/                   unit, isolation and end-to-end tests
└── docs/                    architecture, isolation, security, AI, manifest, adapters, demo, testing
```

## Documentation

* [Architecture](docs/architecture.md) — modules, pipeline, records, persistence
* [Isolation](docs/isolation.md) — worker policy, setup, platform limitations
* [Security model](docs/security.md) — untrusted inputs, secrets, guards, what is *not* protected
* [Manifest reference](docs/manifest.md) — `foundry.yaml`
* [Capability matrix](docs/capability-matrix.md)
* [AI assistance](docs/ai.md) — consent, redaction, bounded operations
* [Adapters](docs/adapters.md) — extension interface for new languages
* [Demonstration](docs/demo.md) and the [actual demo report](docs/demo-report.md)
* [Testing](docs/testing.md) — how to run, and actual results
* [Dependencies and licences](docs/dependencies.md)
* [Known limitations](docs/limitations.md)
