import pytest

from quick_notes.storage import NoteBook


def test_add_save_reload(tmp_path):
    path = tmp_path / "notes.json"
    book = NoteBook(path)
    book.add("Groceries", "milk, eggs")
    book.add("Ideas", "a notes app")
    book.save()
    again = NoteBook(path)
    assert [n.title for n in again.notes] == ["Groceries", "Ideas"]


def test_search_and_remove(tmp_path):
    book = NoteBook(tmp_path / "n.json")
    book.add("Alpha", "first")
    book.add("Beta", "second alpha mention")
    assert book.search("alpha") == [0, 1]
    book.remove(0)
    assert [n.title for n in book.notes] == ["Beta"]


def test_empty_title_rejected(tmp_path):
    with pytest.raises(ValueError):
        NoteBook(tmp_path / "n.json").add("   ")
