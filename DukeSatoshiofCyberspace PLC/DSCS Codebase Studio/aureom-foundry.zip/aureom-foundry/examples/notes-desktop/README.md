# quick-notes

A PySide6 desktop notes app. Notes are stored in a JSON file in the user's data
directory (`QUICK_NOTES_FILE` overrides the location).

```bash
python -m quick_notes
```

The note storage model (`quick_notes.storage`) has no Qt dependency and is unit-tested.
