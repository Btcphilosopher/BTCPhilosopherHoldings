"""Entry point for quick-notes."""

import os
import sys

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

from .window import NotesWindow


def main() -> int:
    app = QApplication(sys.argv)
    window = NotesWindow()
    window.show()
    smoke = os.environ.get("FOUNDRY_SMOKE_SECONDS")
    if smoke:  # used by Foundry's launch check to exit cleanly
        QTimer.singleShot(int(float(smoke) * 1000), app.quit)
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
