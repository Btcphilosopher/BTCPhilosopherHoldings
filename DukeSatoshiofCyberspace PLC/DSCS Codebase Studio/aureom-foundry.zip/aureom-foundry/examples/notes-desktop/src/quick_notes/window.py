"""Main window."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QHBoxLayout, QLineEdit, QListWidget, QMainWindow, QMessageBox, QPlainTextEdit, QPushButton, QVBoxLayout, QWidget,
)

from .storage import NoteBook


class NotesWindow(QMainWindow):
    def __init__(self, book: NoteBook | None = None) -> None:
        super().__init__()
        self.setWindowTitle("Quick Notes")
        self.resize(760, 480)
        self.book = book or NoteBook()
        self.search = QLineEdit(placeholderText="Search notes")
        self.list = QListWidget()
        self.title = QLineEdit(placeholderText="Title")
        self.body = QPlainTextEdit()
        new_btn, save_btn, del_btn = QPushButton("New"), QPushButton("Save"), QPushButton("Delete")
        left = QVBoxLayout()
        left.addWidget(self.search)
        left.addWidget(self.list)
        buttons = QHBoxLayout()
        for b in (new_btn, save_btn, del_btn):
            buttons.addWidget(b)
        right = QVBoxLayout()
        right.addWidget(self.title)
        right.addWidget(self.body)
        right.addLayout(buttons)
        root = QHBoxLayout()
        root.addLayout(left, 1)
        root.addLayout(right, 2)
        container = QWidget()
        container.setLayout(root)
        self.setCentralWidget(container)
        new_btn.clicked.connect(self.new_note)
        save_btn.clicked.connect(self.save_note)
        del_btn.clicked.connect(self.delete_note)
        self.list.currentRowChanged.connect(self.show_note)
        self.search.textChanged.connect(self.refresh)
        self.refresh()

    def refresh(self) -> None:
        self.list.clear()
        indices = self.book.search(self.search.text()) if self.search.text() else range(len(self.book.notes))
        self._visible = list(indices)
        for i in self._visible:
            self.list.addItem(self.book.notes[i].title)

    def show_note(self, row: int) -> None:
        if 0 <= row < len(self._visible):
            note = self.book.notes[self._visible[row]]
            self.title.setText(note.title)
            self.body.setPlainText(note.body)

    def new_note(self) -> None:
        self.list.clearSelection()
        self.title.clear()
        self.body.clear()
        self.title.setFocus()

    def save_note(self) -> None:
        row = self.list.currentRow()
        try:
            if 0 <= row < len(self._visible):
                self.book.update(self._visible[row], self.title.text(), self.body.toPlainText())
            else:
                self.book.add(self.title.text(), self.body.toPlainText())
            self.book.save()
        except ValueError as exc:
            QMessageBox.warning(self, "Quick Notes", str(exc))
        self.refresh()

    def delete_note(self) -> None:
        row = self.list.currentRow()
        if 0 <= row < len(self._visible):
            self.book.remove(self._visible[row])
            self.book.save()
            self.refresh()
