"""JSON-backed note storage (no Qt dependency)."""

from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path


@dataclass
class Note:
    title: str
    body: str = ""
    updated: float = field(default_factory=time.time)


def default_path() -> Path:
    env = os.environ.get("QUICK_NOTES_FILE")
    if env:
        return Path(env)
    base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return base / "quick-notes" / "notes.json"


class NoteBook:
    def __init__(self, path: Path | None = None) -> None:
        self.path = path or default_path()
        self.notes: list[Note] = []
        if self.path.exists():
            data = json.loads(self.path.read_text("utf-8"))
            self.notes = [Note(**n) for n in data.get("notes", [])]

    def add(self, title: str, body: str = "") -> Note:
        if not title.strip():
            raise ValueError("title must not be empty")
        note = Note(title=title.strip(), body=body)
        self.notes.append(note)
        return note

    def update(self, index: int, title: str, body: str) -> None:
        note = self.notes[index]
        note.title, note.body, note.updated = title.strip() or note.title, body, time.time()

    def remove(self, index: int) -> None:
        del self.notes[index]

    def search(self, text: str) -> list[int]:
        t = text.lower()
        return [i for i, n in enumerate(self.notes) if t in n.title.lower() or t in n.body.lower()]

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps({"notes": [asdict(n) for n in self.notes]}, indent=2), "utf-8")
        tmp.replace(self.path)
