"""quick-notes desktop application."""
