// Running-cost calculator for an 8 W lamp.
(function () {
  const hours = document.getElementById("hours");
  const price = document.getElementById("price");
  const out = document.getElementById("cost");
  function update() {
    const kwhPerYear = (8 / 1000) * Number(hours.value || 0) * 365;
    const cost = kwhPerYear * Number(price.value || 0);
    out.textContent = `About ${kwhPerYear.toFixed(1)} kWh and ${cost.toFixed(2)} per year.`;
  }
  hours.addEventListener("input", update);
  price.addEventListener("input", update);
  update();
})();
