# Lumen desk lamp - product website

Static HTML/CSS/JS. Exported as a static website ZIP; it is not a desktop app.
