from fastapi.testclient import TestClient

from inventory_service.main import app

client = TestClient(app)


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_create_adjust_and_reject_negative_stock():
    r = client.post("/items", json={"sku": "WID-001", "name": "Widget", "quantity": 4, "unit_price": 2.5})
    assert r.status_code == 201
    assert client.post("/items/WID-001/adjust", json={"delta": 3}).json()["quantity"] == 7
    r = client.post("/items/WID-001/adjust", json={"delta": -10})
    assert r.status_code == 409
    assert client.get("/items/WID-001").json()["quantity"] == 7


def test_duplicate_and_missing():
    client.post("/items", json={"sku": "GAD-001", "name": "Gadget", "quantity": 1, "unit_price": 9})
    assert client.post("/items", json={"sku": "GAD-001", "name": "Gadget", "quantity": 1, "unit_price": 9}).status_code == 409
    assert client.get("/items/NOPE-1").status_code == 404


def test_validation():
    assert client.post("/items", json={"sku": "x", "name": "", "quantity": -1, "unit_price": 1}).status_code == 422
