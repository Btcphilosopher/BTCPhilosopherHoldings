"""In-memory inventory API."""
