"""Thread-safe in-memory item store."""

from __future__ import annotations

import threading

from pydantic import BaseModel, Field


class Item(BaseModel):
    sku: str = Field(pattern=r"^[A-Z0-9-]{3,32}$")
    name: str = Field(min_length=1, max_length=120)
    quantity: int = Field(ge=0)
    unit_price: float = Field(ge=0)


class StockError(ValueError):
    pass


class Store:
    def __init__(self) -> None:
        self._items: dict[str, Item] = {}
        self._lock = threading.Lock()

    def add(self, item: Item) -> Item:
        with self._lock:
            if item.sku in self._items:
                raise StockError(f"{item.sku} already exists")
            self._items[item.sku] = item
            return item

    def get(self, sku: str) -> Item | None:
        return self._items.get(sku)

    def all(self) -> list[Item]:
        return sorted(self._items.values(), key=lambda i: i.sku)

    def adjust(self, sku: str, delta: int) -> Item:
        with self._lock:
            item = self._items.get(sku)
            if item is None:
                raise KeyError(sku)
            new_qty = item.quantity + delta
            if new_qty < 0:
                raise StockError(f"insufficient stock for {sku}: have {item.quantity}, delta {delta}")
            updated = item.model_copy(update={"quantity": new_qty})
            self._items[sku] = updated
            return updated
