"""FastAPI application."""

from __future__ import annotations

import os

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from .store import Item, StockError, Store

app = FastAPI(title="inventory-service", version="1.0.0")
store = Store()
LOW_STOCK = int(os.environ.get("INVENTORY_LOW_STOCK", "5"))


class Adjustment(BaseModel):
    delta: int


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "items": len(store.all())}


@app.get("/items")
def list_items(low_stock: bool = False) -> list[Item]:
    items = store.all()
    return [i for i in items if i.quantity <= LOW_STOCK] if low_stock else items


@app.post("/items", status_code=201)
def create_item(item: Item) -> Item:
    try:
        return store.add(item)
    except StockError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.get("/items/{sku}")
def get_item(sku: str) -> Item:
    item = store.get(sku)
    if item is None:
        raise HTTPException(status_code=404, detail="not found")
    return item


@app.post("/items/{sku}/adjust")
def adjust(sku: str, body: Adjustment) -> Item:
    try:
        return store.adjust(sku, body.delta)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="not found") from exc
    except StockError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
