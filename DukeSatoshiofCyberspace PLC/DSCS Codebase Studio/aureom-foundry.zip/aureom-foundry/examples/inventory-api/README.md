# inventory-service

A FastAPI service that tracks stock levels in memory.

| Method | Path | Purpose |
| --- | --- | --- |
| GET | /health | readiness |
| GET | /items | list items |
| POST | /items | create an item |
| GET | /items/{sku} | fetch one item |
| POST | /items/{sku}/adjust | change stock by a delta |

```bash
python -m uvicorn inventory_service.main:app --host 127.0.0.1 --port 8000
```

Settings: copy `.env.example` to `.env`. `INVENTORY_LOW_STOCK` sets the low-stock threshold.
