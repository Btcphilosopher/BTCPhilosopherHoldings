"""Create a hostile ZIP archive for testing Foundry's archive intake.

Usage: python make_malicious_zip.py OUTPUT.zip
"""

import stat
import sys
import zipfile


def build(path: str) -> None:
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("project/main.py", "print('hello')\n")
        zf.writestr("project/../../escaped.txt", "path traversal\n")
        zf.writestr("/etc/foundry-absolute.txt", "absolute path\n")
        link = zipfile.ZipInfo("project/link-to-home")
        link.create_system = 3
        link.external_attr = (stat.S_IFLNK | 0o777) << 16
        zf.writestr(link, "/home")
        zf.writestr("project/bomb.txt", "0" * 5_000_000)  # compresses ~1000:1


if __name__ == "__main__":
    build(sys.argv[1] if len(sys.argv) > 1 else "malicious.zip")
