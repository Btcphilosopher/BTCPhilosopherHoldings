# Security fixtures

| Fixture | What it does | Expected Foundry behaviour |
| --- | --- | --- |
| `make_malicious_zip.py` | Writes an archive with `../` traversal, an absolute path, a symlink entry and a high-ratio "bomb" member | Import is rejected as a whole; nothing is extracted |
| `hang-cli/` | A CLI whose entry point never returns | Smoke check is killed at its time limit, recorded as `timed_out`; the worker container is removed |
| `phone-home-cli/` | A CLI that tries to reach `example.com` and whose manifest *requests* network access | Effective settings show network DENIED (not granted); the attempt fails inside the worker and is classified `network-denied` |

These projects are intentionally hostile or broken. Only run them through Foundry.
