"""Fixture: an entry point that never finishes (simulates a hang)."""

import time


def main() -> int:
    print("starting and never finishing...", flush=True)
    while True:
        time.sleep(1)


if __name__ == "__main__":
    raise SystemExit(main())
