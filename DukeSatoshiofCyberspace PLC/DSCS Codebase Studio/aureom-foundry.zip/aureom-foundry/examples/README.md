# Example projects

| Project | Type | Highlights |
| --- | --- | --- |
| `csv-analysis-cli/` | Python CLI (`csv-insight`) | standard library only, console script, 5 tests, smoke check on bundled sample data |
| `inventory-api/` | FastAPI service | in-memory inventory, `/health` readiness, 4 API tests, optional OCI image profile |
| `notes-desktop/` | PySide6 app (`quick-notes`) | Qt-free storage model with tests, offscreen launch check, PyInstaller profile |
| `product-website/` | static website | HTML/CSS/JS with a running-cost calculator; exported as a static site ZIP |
| `fixtures/` | security fixtures | malicious archive generator, a hanging CLI, a CLI that phones home |

Import any of them with the drop zone or `aureom-foundry import examples/<name>`.
Fixtures are intentionally hostile — only run them through Foundry.
