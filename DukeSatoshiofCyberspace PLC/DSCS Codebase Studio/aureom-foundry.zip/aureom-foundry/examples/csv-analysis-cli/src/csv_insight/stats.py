"""Column statistics for CSV data."""

from __future__ import annotations

import csv
import statistics
from dataclasses import dataclass
from pathlib import Path


@dataclass
class ColumnSummary:
    name: str
    numeric: bool
    count: int
    minimum: float | None = None
    maximum: float | None = None
    mean: float | None = None
    distinct: int = 0


def read_rows(path: Path, delimiter: str = ",") -> tuple[list[str], list[dict[str, str]]]:
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f, delimiter=delimiter)
        rows = list(reader)
        return list(reader.fieldnames or []), rows


def _as_float(value: str) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def summarise(columns: list[str], rows: list[dict[str, str]]) -> list[ColumnSummary]:
    out = []
    for col in columns:
        values = [r.get(col, "") for r in rows]
        numbers = [n for n in (_as_float(v) for v in values) if n is not None]
        numeric = bool(values) and len(numbers) == len(values)
        s = ColumnSummary(name=col, numeric=numeric, count=len(values), distinct=len(set(values)))
        if numeric:
            s.minimum, s.maximum, s.mean = min(numbers), max(numbers), statistics.fmean(numbers)
        out.append(s)
    return out


def filter_rows(rows: list[dict[str, str]], column: str, equals: str) -> list[dict[str, str]]:
    return [r for r in rows if r.get(column) == equals]


def top_rows(rows: list[dict[str, str]], column: str, n: int) -> list[dict[str, str]]:
    keyed = [(v, r) for r in rows if (v := _as_float(r.get(column, ""))) is not None]
    keyed.sort(key=lambda pair: pair[0], reverse=True)
    return [r for _, r in keyed[:n]]
