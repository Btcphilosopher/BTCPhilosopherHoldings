"""csv-insight: summarise CSV files."""

__version__ = "1.0.0"
