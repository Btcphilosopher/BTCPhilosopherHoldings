"""Command-line interface for csv-insight."""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

from . import __version__
from .stats import filter_rows, read_rows, summarise, top_rows


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="csv-insight", description="Summarise and filter CSV files.")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    s = sub.add_parser("summary", help="row count and per-column statistics")
    s.add_argument("file", type=Path)
    s.add_argument("--delimiter", default=",")

    f = sub.add_parser("filter", help="print rows where a column equals a value")
    f.add_argument("file", type=Path)
    f.add_argument("--column", required=True)
    f.add_argument("--equals", required=True)

    t = sub.add_parser("top", help="print the rows with the largest values in a numeric column")
    t.add_argument("file", type=Path)
    t.add_argument("--column", required=True)
    t.add_argument("-n", type=int, default=5)
    return p


def _write(columns: list[str], rows: list[dict[str, str]]) -> None:
    w = csv.DictWriter(sys.stdout, fieldnames=columns, lineterminator="\n")
    w.writeheader()
    w.writerows(rows)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if not args.file.is_file():
        print(f"error: {args.file} not found", file=sys.stderr)
        return 2
    columns, rows = read_rows(args.file, getattr(args, "delimiter", ","))
    if args.command == "summary":
        print(f"rows: {len(rows)}")
        for col in summarise(columns, rows):
            if col.numeric:
                print(f"{col.name}: min={col.minimum:.2f} max={col.maximum:.2f} mean={col.mean:.2f}")
            else:
                print(f"{col.name}: {col.distinct} distinct value(s)")
    elif args.command == "filter":
        if args.column not in columns:
            print(f"error: unknown column {args.column!r}", file=sys.stderr)
            return 2
        _write(columns, filter_rows(rows, args.column, args.equals))
    elif args.command == "top":
        _write(columns, top_rows(rows, args.column, args.n))
    return 0
