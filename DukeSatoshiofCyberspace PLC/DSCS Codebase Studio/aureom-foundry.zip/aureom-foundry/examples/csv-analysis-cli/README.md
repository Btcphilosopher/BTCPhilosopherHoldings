# csv-insight

A small command-line tool that summarises CSV files: row counts, numeric column
statistics and simple filtering. Standard library only.

```bash
csv-insight summary data/sample.csv
csv-insight filter data/sample.csv --column region --equals North
csv-insight top data/sample.csv --column revenue -n 3
```

Configuration: see `config.example.toml` (optional; flags override it).
