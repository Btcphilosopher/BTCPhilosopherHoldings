from pathlib import Path

from csv_insight.cli import main

SAMPLE = Path(__file__).resolve().parent.parent / "data" / "sample.csv"


def test_summary_output(capsys):
    assert main(["summary", str(SAMPLE)]) == 0
    out = capsys.readouterr().out
    assert "rows: 6" in out
    assert "revenue: min=99.00 max=400.00" in out


def test_missing_file_returns_error(tmp_path, capsys):
    assert main(["summary", str(tmp_path / "nope.csv")]) == 2
