from csv_insight.stats import filter_rows, summarise, top_rows

COLUMNS = ["region", "revenue"]
ROWS = [
    {"region": "North", "revenue": "10"},
    {"region": "South", "revenue": "30"},
    {"region": "North", "revenue": "20"},
]


def test_summary_detects_numeric_columns():
    summary = {s.name: s for s in summarise(COLUMNS, ROWS)}
    assert summary["revenue"].numeric is True
    assert summary["revenue"].mean == 20
    assert summary["region"].numeric is False
    assert summary["region"].distinct == 2


def test_filter_rows():
    assert len(filter_rows(ROWS, "region", "North")) == 2


def test_top_rows_orders_descending():
    assert [r["revenue"] for r in top_rows(ROWS, "revenue", 2)] == ["30", "20"]
