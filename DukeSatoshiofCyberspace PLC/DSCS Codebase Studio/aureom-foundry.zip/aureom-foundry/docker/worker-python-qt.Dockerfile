# Aureom Foundry - Qt worker image for PySide6 launch checks and Linux desktop executables.
# Provides the system libraries Qt needs for the offscreen platform, plus binutils for PyInstaller.
# Build:  docker build -t aureom-foundry/worker-python-qt:1 -f docker/worker-python-qt.Dockerfile docker
ARG BASE=ubuntu:24.04
FROM ${BASE}
ENV DEBIAN_FRONTEND=noninteractive
RUN apt-get update \
 && apt-get install -y --no-install-recommends \
      python3 python3-venv python3-pip libpython3-dev \
      libegl1 libgl1 libxkbcommon0 libfontconfig1 libfreetype6 libdbus-1-3 libglib2.0-0 \
      libgssapi-krb5-2 libx11-6 libxcb1 libxcb-cursor0 libx11-xcb1 \
      binutils \
 && ln -sf /usr/bin/python3 /usr/local/bin/python \
 && rm -rf /var/lib/apt/lists/*
