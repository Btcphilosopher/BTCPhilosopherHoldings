# Aureom Foundry - default Python worker image.
# The stock python:3.12-slim image works as-is; this file pins it and documents the contract.
# Workers always run with: --read-only, --cap-drop ALL, no-new-privileges, an unprivileged UID,
# tmpfs /work and /tmp, and --network none (except the dependency-fetch stage).
ARG BASE=python:3.12-slim
FROM ${BASE}
RUN python -m pip --version && python -m venv --help >/dev/null
