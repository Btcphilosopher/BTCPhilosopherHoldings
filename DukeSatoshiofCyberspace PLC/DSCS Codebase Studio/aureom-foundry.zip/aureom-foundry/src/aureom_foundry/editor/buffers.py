"""File access for the editor and for validated change operations.

All paths are resolved against the managed project root and must stay inside
it; ``.git`` internals and symbolic links are never read or written.
"""

from __future__ import annotations

from pathlib import Path, PurePosixPath

MAX_EDIT_BYTES = 2_000_000


class PathRejected(ValueError):
    pass


def resolve_inside(root: Path, rel: str) -> Path:
    if not rel or "\x00" in rel or "\\" in rel:
        raise PathRejected("invalid path")
    p = PurePosixPath(rel)
    if p.is_absolute() or ".." in p.parts:
        raise PathRejected(f"path must stay inside the project: {rel}")
    if p.parts and p.parts[0] == ".git":
        raise PathRejected("Git internals cannot be edited")
    root = root.resolve()
    target = root.joinpath(*p.parts)
    # Reject symlinks anywhere along the path.
    cur = root
    for part in p.parts:
        cur = cur / part
        if cur.is_symlink():
            raise PathRejected(f"symbolic links are not followed: {rel}")
    if not target.resolve().is_relative_to(root):
        raise PathRejected(f"path escapes the project: {rel}")
    return target


def read_text(root: Path, rel: str) -> str:
    path = resolve_inside(root, rel)
    data = path.read_bytes()
    if len(data) > MAX_EDIT_BYTES:
        raise PathRejected("file too large for the editor")
    if b"\x00" in data[:8192]:
        raise PathRejected("binary file")
    return data.decode("utf-8", errors="replace")


def write_text(root: Path, rel: str, content: str) -> Path:
    if len(content.encode("utf-8")) > MAX_EDIT_BYTES:
        raise PathRejected("content too large")
    path = resolve_inside(root, rel)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, "utf-8")
    return path
