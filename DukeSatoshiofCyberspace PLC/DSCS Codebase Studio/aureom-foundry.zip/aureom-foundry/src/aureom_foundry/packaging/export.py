"""Export a build as a traceable software package.

The export directory is assembled from an explicit allowlist:

* application artefacts recorded by the build (re-hashed and compared with the record);
* ``CHECKSUMS.sha256``;
* ``dependency-inventory.json`` (declared vs. resolved, from the build lock);
* ``LICENSES.md`` (project licence file plus licence metadata found in wheels);
* ``config.example`` (from the project's example config, with values blanked);
* ``RUN.md``, ``LIMITATIONS.md``, ``BUILD-SUMMARY.md`` and ``build-record.json``;
* ``export-manifest.json`` listing every included and excluded candidate.

Every text file is scanned for credentials before it is written; anything that
matches is excluded. Deployment, signing and publishing are out of scope.
"""

from __future__ import annotations

import json
import re
import shutil
import zipfile
from email.parser import Parser
from pathlib import Path

from pydantic import BaseModel, Field

from ..adapters.base import get_adapter, sha256_file
from ..builds.models import BuildRecord, BuildStatus
from ..dependencies.environments import inventory
from ..inspection.report import inspect_project
from ..inspection.secrets import is_sensitive_filename, redact, scan_text
from ..manifests.loader import load_manifest
from ..persistence.db import new_id, now

CONFIG_EXAMPLE_NAMES = (".env.example", ".env.sample", "config.example.toml", "config.example.yaml", "config.example.yml", "config.example.json", "settings.example.toml")
LICENSE_NAMES = ("LICENSE", "LICENSE.txt", "LICENSE.md", "COPYING", "NOTICE")


class ExportBlocked(Exception):
    pass


class ExportRecord(BaseModel):
    export_id: str
    build_id: str
    path: str
    zip_path: str
    zip_sha256: str
    created_at: str
    verified: bool
    included: list[dict] = Field(default_factory=list)
    excluded: list[dict] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


def _blank_config(text: str, name: str) -> str:
    """Keep keys and comments; blank values that look like credentials."""

    out = []
    for line in text.splitlines():
        m = re.match(r"^(\s*[A-Za-z_][\w.-]*\s*[=:]\s*)(.*)$", line)
        if m and re.search(r"(?i)(key|secret|token|pass|pwd|credential|auth)", m.group(1)):
            out.append(m.group(1) + ('""' if name.endswith((".toml", ".json")) else ""))
        else:
            out.append(line)
    return redact("\n".join(out) + "\n")


def wheel_license(path: Path) -> dict:
    try:
        with zipfile.ZipFile(path) as zf:
            meta = next((n for n in zf.namelist() if n.endswith(".dist-info/METADATA")), None)
            if not meta:
                return {}
            msg = Parser().parsestr(zf.read(meta).decode("utf-8", "replace"))
            classifiers = [c for c in msg.get_all("Classifier") or [] if c.startswith("License ::")]
            lic = msg.get("License-Expression") or msg.get("License") or ""
            return {"name": msg.get("Name"), "version": msg.get("Version"), "license": lic.strip()[:200], "classifiers": classifiers}
    except (zipfile.BadZipFile, OSError):
        return {}


class ExportService:
    def __init__(self, foundry):
        self.f = foundry

    def list(self, build_id: str | None = None) -> list[ExportRecord]:
        rows = self.f.db.query("SELECT doc FROM exports WHERE build_id = ? ORDER BY created_at DESC", (build_id,)) if build_id else self.f.db.query("SELECT doc FROM exports ORDER BY created_at DESC")
        return [ExportRecord.model_validate_json(r["doc"]) for r in rows]

    def export(self, build_id: str, *, allow_unverified: bool = False) -> ExportRecord:
        rec: BuildRecord = self.f.builds.get(build_id)
        if rec.status != BuildStatus.succeeded:
            raise ExportBlocked(f"build {build_id} is {rec.status.value}; only successful builds can be exported")
        if not rec.verified and not allow_unverified:
            raise ExportBlocked(
                f"build {build_id} is not verified (tests: {rec.tests_status.value}, smoke: {rec.smoke_status.value}). "
                "Export it explicitly as unverified if you accept that."
            )
        bdir = self.f.builds.build_dir(build_id)
        art_dir = bdir / "artefacts"
        src = bdir / "source"
        export_id = new_id("exp")
        dest = self.f.settings.exports_dir / f"{rec.project_name}-{build_id}"
        if dest.exists():
            shutil.rmtree(dest)
        dest.mkdir(parents=True)
        out = ExportRecord(export_id=export_id, build_id=build_id, path=str(dest), zip_path="", zip_sha256="", created_at=now(), verified=rec.verified)

        # 1. Artefacts: only those recorded by the build, and only if their hashes still match.
        for a in rec.artefacts:
            p = art_dir / a.path
            if not p.is_file():
                out.excluded.append({"path": a.path, "reason": "recorded artefact missing"})
                continue
            digest = sha256_file(p)
            if digest != a.sha256:
                raise ExportBlocked(f"artefact {a.path} changed after the build (hash mismatch); refusing to export")
            target = dest / "artefacts" / Path(a.path).name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(p, target)
            out.included.append({"path": f"artefacts/{target.name}", "kind": a.kind, "sha256": digest, "size": a.size})

        manifest = load_manifest(src)
        adapter = get_adapter(rec.adapter)
        report = inspect_project(src, self.f.settings)

        # 2. Dependency inventory.
        lock = art_dir / "foundry.lock.json"
        inv = inventory(None, report.dependencies)
        if lock.is_file():
            inv["resolved"] = json.loads(lock.read_text("utf-8")).get("packages", [])
        self._write(dest, "dependency-inventory.json", json.dumps(inv, indent=2), out)

        # 3. Licence information.
        lic_lines = [f"# Licence information for {rec.project_name}\n"]
        for name in LICENSE_NAMES:
            p = src / name
            if p.is_file():
                lic_lines.append(f"## Project licence ({name})\n\n```\n{p.read_text('utf-8', 'replace')[:20000]}\n```\n")
                break
        else:
            data = report.dependencies.pyproject.get("project", {}) if report.dependencies.pyproject else {}
            lic = data.get("license")
            lic_txt = lic.get("text") if isinstance(lic, dict) else lic
            lic_lines.append(f"## Project licence\n\n{lic_txt or 'No licence file or metadata was found. Add one before distributing.'}\n")
        lic_lines.append("## Dependencies (from wheel metadata where available)\n")
        cache_root = None
        if rec.dependency_lock_reference:
            cache_root = Path(rec.dependency_lock_reference.split(" sha256:")[0]).parent
        for pkg in inv.get("resolved", []):
            info = {}
            if cache_root and pkg.get("filename", "").endswith(".whl"):
                w = cache_root / pkg["role"] / pkg["filename"]
                if w.is_file():
                    info = wheel_license(w)
            lic = info.get("license") or ", ".join(c.split("::")[-1].strip() for c in info.get("classifiers", [])) or "not declared in metadata"
            lic_lines.append(f"- {pkg['name']} {pkg['version']} ({pkg['role']}): {lic}")
        lic_lines.append("\nLicence data is copied from package metadata and is not legal advice. Verify obligations before distribution.\n")
        self._write(dest, "LICENSES.md", "\n".join(lic_lines), out)

        # 4. Configuration template (values blanked) - never a real config file.
        for name in CONFIG_EXAMPLE_NAMES:
            p = src / name
            if p.is_file():
                self._write(dest, "config.example" + (Path(name).suffix if not name.startswith(".env") else ".env"), _blank_config(p.read_text("utf-8", "replace"), name), out)
                break
        else:
            self._write(dest, "config.example.txt", "# This application declares no configuration file.\n", out)

        # 5. Run instructions, limitations, summary.
        arts = rec.artefacts
        run_md = adapter.run_instructions(manifest, arts) if adapter and manifest else "See README."
        self._write(dest, "RUN.md", run_md, out)
        lims = (adapter.limitations() if adapter else []) + [
            "This package was produced by local packaging only. Signing, notarisation, app-store submission, deployment and publishing are separate steps not performed by Foundry.",
            "Artefacts are built for the worker platform; they are not guaranteed to run on every operating system.",
        ]
        if not rec.verified:
            lims.insert(0, f"UNVERIFIED: tests {rec.tests_status.value}, smoke check {rec.smoke_status.value}.")
        if rec.tests is None or rec.tests.total == 0:
            lims.append("No automated tests were run for this build.")
        self._write(dest, "LIMITATIONS.md", "# Known limitations\n\n" + "\n".join(f"- {x}" for x in lims) + "\n", out)
        self._write(dest, "BUILD-SUMMARY.md", self._summary_md(rec), out)
        self._write(dest, "build-record.json", rec.model_dump_json(indent=2), out)

        # 6. Excluded candidates from the source tree (for transparency).
        for f in report.files:
            reason = None
            if is_sensitive_filename(f.path):
                reason = "sensitive file name"
            elif any(s.path == f.path for s in report.secrets):
                reason = "possible credential detected"
            if reason:
                out.excluded.append({"path": f"source:{f.path}", "reason": reason})
        out.excluded.append({"path": "source tree", "reason": "not part of the allowlist; sdist/wheel carry the distributable source"})

        # 7. Checksums and manifest.
        sums = []
        for p in sorted(dest.rglob("*")):
            if p.is_file():
                sums.append(f"{sha256_file(p)}  {p.relative_to(dest).as_posix()}")
        (dest / "CHECKSUMS.sha256").write_text("\n".join(sums) + "\n", "utf-8")
        out.included.append({"path": "CHECKSUMS.sha256", "kind": "checksums"})
        (dest / "export-manifest.json").write_text(json.dumps({"build_id": build_id, "verified": rec.verified, "included": out.included, "excluded": out.excluded}, indent=2), "utf-8")

        zpath = self.f.settings.exports_dir / f"{rec.project_name}-{build_id}.zip"
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as zf:
            for p in sorted(dest.rglob("*")):
                if p.is_file():
                    zf.write(p, f"{dest.name}/{p.relative_to(dest).as_posix()}")
        out.zip_path = str(zpath)
        out.zip_sha256 = sha256_file(zpath)
        self.f.db.execute(
            "INSERT INTO exports(id, build_id, path, created_at, doc) VALUES (?, ?, ?, ?, ?)",
            (export_id, build_id, str(dest), out.created_at, out.model_dump_json()),
        )
        self.f.db.log_activity("export", f"Exported build {build_id} ({'verified' if rec.verified else 'UNVERIFIED'}) -> {zpath.name} sha256 {out.zip_sha256[:16]}", rec.project_id)
        return out

    def _write(self, dest: Path, name: str, text: str, out: ExportRecord) -> None:
        findings = scan_text(text, name)
        if findings:
            out.excluded.append({"path": name, "reason": f"possible credential ({findings[0].detector}); file withheld"})
            out.warnings.append(f"{name} withheld: possible credential detected")
            return
        (dest / name).write_text(text, "utf-8")
        out.included.append({"path": name, "kind": "document"})

    @staticmethod
    def _summary_md(rec: BuildRecord) -> str:
        lines = [
            f"# Build summary: {rec.project_name}",
            "",
            f"- Build ID: `{rec.build_id}`",
            f"- Source checkpoint: `{rec.source_checkpoint}`",
            f"- Source hash: `{rec.source_hash}`",
            f"- Manifest schema version: {rec.manifest_version}",
            f"- Build profile: {rec.build_profile}",
            f"- Started / completed: {rec.started_at} / {rec.completed_at}",
            f"- Build status: **{rec.status.value}**",
            f"- Tests: **{rec.tests_status.value}**" + (f" ({rec.tests.passed} passed, {rec.tests.failed} failed, {rec.tests.errors} errors, {rec.tests.skipped} skipped)" if rec.tests and rec.tests.total else ""),
            f"- Smoke check: **{rec.smoke_status.value}**",
            f"- Verified (build + tests + smoke): **{'yes' if rec.verified else 'no'}**",
            f"- Isolation: {rec.isolation}; worker image {rec.worker_image} {rec.worker_image_id}",
            f"- Dependency lock: {rec.dependency_lock_reference or 'none'}",
            "",
            "## Toolchain",
            *[f"- {k}: {v}" for k, v in rec.toolchain_versions.items()],
            "",
            "## Stages",
            *[f"- {s.name}: {s.status.value} - {s.summary}" for s in rec.stages],
            "",
            "## Artefacts",
            *[f"- `{a.path}` ({a.kind}, {a.size} bytes) sha256 `{a.sha256}`" for a in rec.artefacts],
        ]
        return "\n".join(lines) + "\n"
