"""Isolated dependency retrieval and offline installation.

Stage separation:

1. **Fetch** (network: registry only, binary distributions only): ``pip download``
   into a Foundry-owned wheelhouse. No project code runs in this stage and no
   source distribution build scripts run either.
2. **Lock**: Foundry hashes every downloaded file and writes ``foundry.lock.json``
   plus per-role ``*.lock.txt`` files with ``--hash`` entries.
3. **Install** (network: none): every later stage creates a fresh virtual
   environment inside the worker and installs from the wheelhouse with
   ``--no-index --require-hashes``. The user's global Python is never touched.
"""

from __future__ import annotations

import hashlib
import json
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from ..config import FoundrySettings
from ..isolation.commands import WorkerStep
from ..isolation.policy import Mount, WorkerPolicy, prepare_writable
from ..isolation.process import CancellationToken
from ..persistence.db import now
from .analysis import DependencyReport
from .parsers import Requirement, normalise_name

ROLES = ("tooling", "runtime", "dev")
DEFAULT_BUILD_REQUIRES = ["setuptools>=68", "wheel"]
_SPEC_OK = re.compile(r"^(?:(?:===|==|!=|~=|>=|<=|>|<)[A-Za-z0-9.*+!_-]+)(?:,(?:===|==|!=|~=|>=|<=|>|<)[A-Za-z0-9.*+!_-]+)*$")
_MARKER_OK = re.compile(r"^[\w\s.'\"<>=!()~,-]*$")
_WHEEL = re.compile(r"^(?P<name>[A-Za-z0-9_.]+)-(?P<ver>[A-Za-z0-9_.!+]+)(?:-\d[\w.]*)?-[\w.]+-[\w.]+-[\w.]+\.whl$")


class UnsafeRequirement(ValueError):
    pass


_MARKER_VARS = {
    "python_version", "python_full_version", "os_name", "sys_platform", "platform_release", "platform_system",
    "platform_version", "platform_machine", "platform_python_implementation", "implementation_name",
    "implementation_version", "extra", "and", "or", "in", "not",
}


def _marker_words_ok(marker: str) -> bool:
    """PEP 508 markers may only use the standard variables, operators and quoted literals."""

    bare = re.sub(r"'[^']*'|\"[^\"]*\"", " ", marker)
    if "'" in bare or '"' in bare:
        return False
    return all(w in _MARKER_VARS for w in re.findall(r"[A-Za-z_][\w.]*", bare))


def requirement_line(r: Requirement) -> str:
    """Render a parsed requirement back to a safe PEP 508 line (no pip options, no URLs)."""

    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", r.name):
        raise UnsafeRequirement(f"invalid distribution name: {r.name!r}")
    if r.specifier and not _SPEC_OK.match(r.specifier):
        raise UnsafeRequirement(f"unsupported version specifier for {r.name}: {r.specifier!r}")
    marker = re.sub(r"\s*\[extra:[^\]]*\]", "", r.marker).strip()
    if marker and (not _MARKER_OK.match(marker) or not _marker_words_ok(marker)):
        raise UnsafeRequirement(f"unsupported environment marker for {r.name}")
    extras = f"[{','.join(e for e in r.extras if re.fullmatch(r'[A-Za-z0-9_.-]+', e))}]" if r.extras else ""
    line = f"{r.name}{extras}{r.specifier}"
    if marker:
        line += f" ; {marker}"
    return line


@dataclass
class FetchRequest:
    tooling: list[str]
    runtime: list[str]
    dev: list[str]
    rejected: list[str] = field(default_factory=list)

    def key(self, image: str, index_url: str, only_binary: bool) -> str:
        blob = json.dumps({"t": sorted(self.tooling), "r": sorted(self.runtime), "d": sorted(self.dev), "i": image, "x": index_url, "b": only_binary}, sort_keys=True)
        return hashlib.sha256(blob.encode()).hexdigest()[:24]


def build_fetch_request(deps: DependencyReport, *, need_build_tooling: bool, need_tests: bool, extra_tooling: list[str] | None = None) -> FetchRequest:
    rejected: list[str] = []

    def lines(reqs: list[Requirement]) -> list[str]:
        out = []
        for r in reqs:
            if "[extra:" in r.marker and r.kind == "runtime":
                continue  # optional runtime extras are not installed by default
            try:
                out.append(requirement_line(r))
            except UnsafeRequirement as exc:
                rejected.append(str(exc))
        return sorted(set(out))

    tooling: list[str] = []
    if need_build_tooling:
        build_reqs = [r for r in deps.requirements if r.kind == "build" and r.ecosystem == "python"]
        tooling = lines(build_reqs) if build_reqs else list(DEFAULT_BUILD_REQUIRES)
        tooling.append("build")
    tooling += extra_tooling or []
    runtime = lines(deps.runtime_python())
    dev: list[str] = []
    if need_tests:
        dev = lines(deps.dev_python())
        if not any(normalise_name(d.split("[")[0].split("=")[0].split(">")[0].split("<")[0].strip()) == "pytest" for d in dev):
            dev.append("pytest")
    return FetchRequest(tooling=sorted(set(tooling)), runtime=runtime, dev=sorted(set(dev)), rejected=rejected)


@dataclass
class Wheelhouse:
    root: Path
    key: str

    def role_dir(self, role: str) -> Path:
        return self.root / role

    @property
    def lock_path(self) -> Path:
        return self.root / "foundry.lock.json"

    @property
    def complete(self) -> bool:
        return (self.root / ".complete").exists() and self.lock_path.exists()

    def lock(self) -> dict:
        return json.loads(self.lock_path.read_text("utf-8"))

    def lock_sha256(self) -> str:
        return hashlib.sha256(self.lock_path.read_bytes()).hexdigest()

    def has_role(self, role: str) -> bool:
        return (self.root / f"{role}.lock.txt").exists() and (self.root / f"{role}.lock.txt").read_text().strip() != ""


def wheelhouse_for(settings: FoundrySettings, req: FetchRequest, image: str) -> Wheelhouse:
    key = req.key(image, settings.registry.index_url, settings.registry.only_binary)
    return Wheelhouse(settings.data_dir / "cache" / "wheelhouse" / key, key)


def fetch_steps(req: FetchRequest, settings: FoundrySettings) -> list[WorkerStep]:
    steps = []
    for role in ROLES:
        if not getattr(req, role):
            continue
        argv = [
            "python", "-I", "-m", "pip", "download", "--no-input", "--disable-pip-version-check",
            "--dest", f"/wheelhouse/{role}", "--index-url", settings.registry.index_url,
            "-r", f"/input/{role}.txt",
        ]
        if settings.registry.only_binary:
            argv.append("--only-binary=:all:")
        steps.append(WorkerStep(name=f"fetch {role} dependencies", argv=argv, cwd="/work", timeout_s=600, trusted_pip_args=True))
    return steps


def run_fetch(
    runtime,
    settings: FoundrySettings,
    req: FetchRequest,
    image: str,
    *,
    cancel: CancellationToken | None = None,
    on_output=None,
):
    """Download dependencies into the wheelhouse (cached by request hash). Returns (wheelhouse, worker_result|None)."""

    wh = wheelhouse_for(settings, req, image)
    if wh.complete:
        return wh, None
    if wh.root.exists():
        shutil.rmtree(wh.root)
    inp = settings.tmp_dir / f"fetch-input-{wh.key}"
    shutil.rmtree(inp, ignore_errors=True)
    inp.mkdir(parents=True)
    for role in ROLES:
        (inp / f"{role}.txt").write_text("\n".join(getattr(req, role)) + "\n", "utf-8")
        prepare_writable(wh.role_dir(role))
    env = {}
    mounts = [Mount(source=wh.root, target="/wheelhouse", read_only=False), Mount(source=inp, target="/input", read_only=True)]
    ca = settings.registry.ca_bundle
    if ca:
        mounts.append(Mount(source=Path(ca), target="/foundry-ca/ca.crt", read_only=True))
        env["PIP_CERT"] = "/foundry-ca/ca.crt"
    policy = WorkerPolicy(network="fetch", mounts=mounts, limits=settings.limits, env=env, label="fetch")
    steps = fetch_steps(req, settings)
    result = None
    if steps:
        result = runtime.run_plan(image, steps, policy, cancel=cancel, on_output=on_output, name_prefix="foundry-fetch")
        if not result.ok:
            shutil.rmtree(inp, ignore_errors=True)
            return wh, result
    write_lock(wh, req, settings, image)
    shutil.rmtree(inp, ignore_errors=True)
    return wh, result


def write_lock(wh: Wheelhouse, req: FetchRequest, settings: FoundrySettings, image: str) -> dict:
    lock = {
        "lock_version": 1,
        "generated_at": now(),
        "index_url": settings.registry.index_url,
        "only_binary": settings.registry.only_binary,
        "worker_image": image,
        "requested": {r: getattr(req, r) for r in ROLES},
        "packages": [],
    }
    for role in ROLES:
        entries: dict[tuple[str, str], list[str]] = {}
        d = wh.role_dir(role)
        files = sorted(d.iterdir()) if d.exists() else []
        for f in files:
            if not f.is_file():
                continue
            digest = hashlib.sha256(f.read_bytes()).hexdigest()
            m = _WHEEL.match(f.name)
            if m:
                name, ver = m.group("name"), m.group("ver")
            else:
                stem = re.sub(r"\.(tar\.gz|zip)$", "", f.name)
                name, _, ver = stem.rpartition("-")
            entries.setdefault((normalise_name(name), ver), []).append(digest)
            lock["packages"].append({"role": role, "name": normalise_name(name), "version": ver, "filename": f.name, "sha256": digest})
        lines = [f"{n}=={v} " + " ".join(f"--hash=sha256:{h}" for h in sorted(set(hs))) for (n, v), hs in sorted(entries.items())]
        (wh.root / f"{role}.lock.txt").write_text("\n".join(lines) + ("\n" if lines else ""), "utf-8")
    wh.lock_path.write_text(json.dumps(lock, indent=2), "utf-8")
    (wh.root / ".complete").write_text(now(), "utf-8")
    return lock


def install_steps(roles: list[str], wh: Wheelhouse) -> list[WorkerStep]:
    """Steps that create /work/venv and install locked roles offline with hash checking."""

    steps = [WorkerStep(name="create virtual environment", argv=["python", "-I", "-m", "venv", "/work/venv"], timeout_s=120)]
    for role in roles:
        if not wh.has_role(role):
            continue
        steps.append(
            WorkerStep(
                name=f"install {role} (offline, hash-checked)",
                argv=[
                    "/work/venv/bin/python", "-I", "-m", "pip", "install", "--no-input", "--disable-pip-version-check",
                    "--no-index", "--find-links", f"/wheelhouse/{role}", "--require-hashes", "--no-deps",
                    "-r", f"/wheelhouse/{role}.lock.txt",
                ],
                timeout_s=600,
                trusted_pip_args=True,
            )
        )
    return steps


def inventory(wh: Wheelhouse | None, deps: DependencyReport) -> dict:
    """Dependency inventory for exports: what was declared and what was actually resolved."""

    declared = [
        {"name": r.name, "specifier": r.specifier, "kind": r.kind, "source": r.source, "ecosystem": r.ecosystem}
        for r in deps.requirements
    ]
    resolved = wh.lock()["packages"] if wh and wh.complete else []
    return {"declared": declared, "resolved": resolved, "lockfiles_in_project": deps.lockfiles}
