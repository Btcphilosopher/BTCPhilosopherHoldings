"""Dependency inspection: what a project declares, what it imports, and what is missing."""

from __future__ import annotations

import re
from pathlib import Path

from pydantic import BaseModel, Field

from ..diagnostics.issues import Issue, error, info, warning
from ..inspection.python_analysis import NATIVE_HINTS, PythonFacts, distribution_for, third_party_imports
from .parsers import (
    ParseProblem,
    Requirement,
    normalise_name,
    parse_cargo_toml,
    parse_package_json,
    parse_pyproject,
    parse_requirements_txt,
)
from .versions import satisfies, specs_conflict

PY_LOCKFILES = ("requirements.lock", "requirements.lock.txt", "poetry.lock", "uv.lock", "Pipfile.lock", "pdm.lock", "foundry.lock.json")
NODE_LOCKFILES = ("package-lock.json", "yarn.lock", "pnpm-lock.yaml", "bun.lockb")


class DependencyReport(BaseModel):
    manifests: list[str] = Field(default_factory=list)
    lockfiles: list[str] = Field(default_factory=list)
    requirements: list[Requirement] = Field(default_factory=list)
    requires_python: str | None = None
    unresolved_imports: dict[str, list[str]] = Field(default_factory=dict)
    undeclared_imports: dict[str, str] = Field(default_factory=dict)  # module -> known distribution
    problems: list[ParseProblem] = Field(default_factory=list)
    issues: list[Issue] = Field(default_factory=list)
    pyproject: dict = Field(default_factory=dict, exclude=True)

    def runtime_python(self) -> list[Requirement]:
        return [r for r in self.requirements if r.ecosystem == "python" and r.kind == "runtime"]

    def dev_python(self) -> list[Requirement]:
        return [r for r in self.requirements if r.ecosystem == "python" and r.kind == "dev"]


def _is_requirements_file(rel: str) -> bool:
    name = Path(rel).name.lower()
    return bool(re.match(r"^requirements([-_.][a-z0-9_-]+)?\.(txt|in)$", name)) and "lock" not in name


def analyse_dependencies(
    root: Path,
    files: list[str],
    facts: PythonFacts | None,
    worker_python: str = "3.12",
) -> DependencyReport:
    rep = DependencyReport()
    top_level = {f for f in files if "/" not in f}
    for rel in files:
        name = Path(rel).name
        depth = rel.count("/")
        if depth > 1:
            continue
        if name in PY_LOCKFILES or name in NODE_LOCKFILES or name == "Cargo.lock":
            rep.lockfiles.append(rel)
        if _is_requirements_file(rel):
            kind = "dev" if re.search(r"(dev|test|lint|docs)", name.lower()) else "runtime"
            reqs, probs = parse_requirements_txt(root / rel, rel, kind)
            rep.manifests.append(rel)
            rep.requirements += reqs
            rep.problems += probs
        elif name == "pyproject.toml" and rel in top_level:
            data, reqs, probs = parse_pyproject(root / rel, rel)
            rep.pyproject = data
            rep.manifests.append(rel)
            rep.requirements += reqs
            rep.problems += probs
            rep.requires_python = (data.get("project", {}) or {}).get("requires-python")
        elif name == "package.json" and rel in top_level:
            _, reqs, probs = parse_package_json(root / rel, rel)
            rep.manifests.append(rel)
            rep.requirements += reqs
            rep.problems += probs
        elif name == "Cargo.toml" and rel in top_level:
            _, reqs, probs = parse_cargo_toml(root / rel, rel)
            rep.manifests.append(rel)
            rep.requirements += reqs
            rep.problems += probs
        elif name in {"setup.py", "setup.cfg", "Pipfile"} and rel in top_level:
            rep.manifests.append(rel)
            rep.issues.append(
                warning(
                    "legacy-manifest",
                    f"{name} is detected but not evaluated (it may contain executable code).",
                    "Declare dependencies in pyproject.toml [project] or requirements.txt.",
                    rel,
                )
            )

    for p in rep.problems:
        rep.issues.append(warning("manifest-entry-ignored", f"{p.text or p.source}: {p.reason}", path=p.source))

    has_python = any(f.endswith(".py") for f in files)
    py_reqs = [r for r in rep.requirements if r.ecosystem == "python" and r.kind != "build"]
    declared = {r.key for r in py_reqs}

    if has_python and not any(m.endswith((".txt", ".in", "pyproject.toml")) for m in rep.manifests):
        rep.issues.append(
            warning(
                "missing-manifest",
                "No Python dependency manifest (pyproject.toml or requirements.txt) was found.",
                "Add pyproject.toml, or let Foundry scaffold one after you confirm the dependencies.",
            )
        )

    # Imports that are not declared anywhere.
    if facts is not None:
        for module, used_in in sorted(third_party_imports(facts).items()):
            dist = distribution_for(module)
            if dist is None:
                if normalise_name(module) in declared:
                    continue
                rep.unresolved_imports[module] = used_in
                rep.issues.append(
                    warning(
                        "unresolved-import",
                        f"'{module}' is imported but is not in the standard library, the project, or the manifest.",
                        "Supply the distribution that provides this module. Foundry will not guess a similarly named package.",
                        used_in[0],
                    )
                )
            elif normalise_name(dist) not in declared:
                rep.undeclared_imports[module] = dist
                rep.issues.append(
                    error(
                        "undeclared-dependency",
                        f"'{module}' is imported but its distribution '{dist}' is not declared.",
                        f"Declare '{dist}' in the dependency manifest.",
                        used_in[0],
                    )
                )
            if module in NATIVE_HINTS:
                rep.issues.append(info("native-requirement", f"'{module}' may need {NATIVE_HINTS[module]}.", path=used_in[0]))

    # Version quality and conflicts.
    by_name: dict[str, list[Requirement]] = {}
    for r in py_reqs:
        by_name.setdefault(r.key, []).append(r)
        if r.specifier.startswith("@") or "://" in r.specifier:
            rep.issues.append(warning("direct-reference", f"'{r.name}' uses a direct URL reference; it cannot be verified against the configured registry.", path=r.source))
        elif not r.specifier:
            rep.issues.append(warning("unresolved-version", f"'{r.name}' has no version constraint; the resolved version will be recorded in the build lock.", path=r.source))
    for key, reqs in by_name.items():
        for i, a in enumerate(reqs):
            for b in reqs[i + 1 :]:
                if a.marker == b.marker and specs_conflict(a.specifier, b.specifier):
                    rep.issues.append(
                        error(
                            "conflicting-requirements",
                            f"'{a.name}' is declared as '{a.specifier}' in {a.source} and '{b.specifier}' in {b.source}.",
                            "Choose one compatible constraint.",
                            a.source,
                        )
                    )

    if rep.requires_python:
        ok = satisfies(worker_python + ".0", rep.requires_python)
        if ok is False:
            rep.issues.append(
                error(
                    "unsupported-runtime",
                    f"requires-python '{rep.requires_python}' excludes the worker runtime Python {worker_python}.",
                    "Adjust requires-python or configure a worker image with a matching Python.",
                    "pyproject.toml",
                )
            )

    if has_python and py_reqs and not any(Path(lf).name in PY_LOCKFILES for lf in rep.lockfiles):
        rep.issues.append(info("no-lockfile", "No Python lockfile found. Foundry records resolved versions and hashes per build in foundry.lock.json."))
    for lf in rep.lockfiles:
        rep.issues.append(info("lockfile-available", f"Lockfile detected: {lf}", path=lf))
    return rep
