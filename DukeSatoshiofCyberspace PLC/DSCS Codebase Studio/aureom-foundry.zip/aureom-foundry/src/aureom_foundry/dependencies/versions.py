"""Minimal PEP 440-style comparison used only for conflict *detection*.

Resolution itself is always delegated to pip inside an isolated worker; this
module only spots obviously incompatible declarations before a build starts.
"""

from __future__ import annotations

import re

_V = re.compile(r"^\s*v?(\d+(?:\.\d+)*)(?:[.-]?(a|b|rc|alpha|beta|c)(\d*))?(?:\.post(\d+))?(?:\.dev(\d+))?\s*$", re.I)


def parse_version(v: str) -> tuple | None:
    m = _V.match(v)
    if not m:
        return None
    release = tuple(int(x) for x in m.group(1).split("."))
    while len(release) > 1 and release[-1] == 0:
        release = release[:-1]
    pre_map = {"a": 0, "alpha": 0, "b": 1, "beta": 1, "c": 2, "rc": 2}
    pre = (pre_map[m.group(2).lower()], int(m.group(3) or 0)) if m.group(2) else (9, 0)
    return (release, pre, int(m.group(4) or 0))


def _split(spec: str) -> list[tuple[str, str]]:
    out = []
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        m = re.match(r"^(===|==|!=|~=|>=|<=|>|<)\s*(.+)$", part)
        if not m:
            return []
        out.append((m.group(1), m.group(2)))
    return out


def satisfies(version: str, spec: str) -> bool | None:
    """Return True/False, or None when the spec cannot be evaluated here."""

    pv = parse_version(version)
    if pv is None:
        return None
    clauses = _split(spec)
    if spec and not clauses:
        return None
    for op, target in clauses:
        if target.endswith(".*"):
            prefix = parse_version(target[:-2])
            if prefix is None:
                return None
            match = pv[0][: len(prefix[0])] == prefix[0]
            if (op == "==" and not match) or (op == "!=" and match):
                return False
            continue
        tv = parse_version(target)
        if tv is None:
            return None
        if op in ("==", "===") and pv != tv:
            return False
        if op == "!=" and pv == tv:
            return False
        if op == ">=" and pv < tv:
            return False
        if op == "<=" and pv > tv:
            return False
        if op == ">" and pv <= tv:
            return False
        if op == "<" and pv >= tv:
            return False
        if op == "~=":
            rel = tv[0]
            upper = rel[:-1] if len(rel) > 1 else rel
            if pv < tv or pv[0][: len(upper)] != upper:
                return False
    return True


def pinned_version(spec: str) -> str | None:
    clauses = _split(spec)
    if len(clauses) == 1 and clauses[0][0] in ("==", "===") and not clauses[0][1].endswith(".*"):
        return clauses[0][1]
    return None


def specs_conflict(a: str, b: str) -> bool:
    """Detect conflicts where at least one side is an exact pin."""

    for x, y in ((a, b), (b, a)):
        pin = pinned_version(x)
        if pin is not None and y:
            ok = satisfies(pin, y)
            if ok is False:
                return True
    return False
