"""Parsers for dependency manifests. Pure parsing: nothing is resolved or installed here."""

from __future__ import annotations

import json
import re
import tomllib
from pathlib import Path
from typing import Literal

from pydantic import BaseModel

_NAME_RE = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)\s*(\[[^\]]*\])?\s*(.*)$")


def normalise_name(name: str) -> str:
    """PEP 503 normalisation."""

    return re.sub(r"[-_.]+", "-", name).lower()


class Requirement(BaseModel):
    name: str
    specifier: str = ""
    extras: list[str] = []
    marker: str = ""
    source: str
    kind: Literal["runtime", "dev", "build"] = "runtime"
    hashes: list[str] = []
    raw: str = ""
    ecosystem: Literal["python", "node", "rust", "other"] = "python"

    @property
    def key(self) -> str:
        return normalise_name(self.name)

    @property
    def pinned(self) -> bool:
        return self.specifier.startswith("==") and "*" not in self.specifier and "," not in self.specifier


class ParseProblem(BaseModel):
    source: str
    line: int
    text: str
    reason: str


def parse_pep508(line: str, source: str, kind: str = "runtime") -> Requirement | None:
    raw = line
    line = line.split(" #", 1)[0].strip()
    if not line or line.startswith("#"):
        return None
    hashes = re.findall(r"--hash=(sha256:[0-9a-fA-F]{64})", line)
    line = re.sub(r"\s*--hash=\S+", "", line).strip().rstrip("\\").strip()
    marker = ""
    if ";" in line:
        line, marker = (part.strip() for part in line.split(";", 1))
    m = _NAME_RE.match(line)
    if not m:
        return None
    name, extras, spec = m.group(1), m.group(2), m.group(3).strip()
    if spec.startswith("@"):
        # direct URL reference: keep it visible as a specifier so it is flagged as unpinned/unusual
        spec = spec
    spec = spec.replace(" ", "")
    if spec.startswith("(") and spec.endswith(")"):
        spec = spec[1:-1]
    return Requirement(
        name=name,
        specifier=spec,
        extras=[e.strip() for e in extras[1:-1].split(",")] if extras else [],
        marker=marker,
        source=source,
        kind=kind,  # type: ignore[arg-type]
        hashes=hashes,
        raw=raw.strip(),
    )


def parse_requirements_txt(path: Path, rel: str, kind: str = "runtime") -> tuple[list[Requirement], list[ParseProblem]]:
    reqs: list[Requirement] = []
    problems: list[ParseProblem] = []
    text = path.read_text("utf-8", errors="replace")
    # join continuation lines
    joined: list[tuple[int, str]] = []
    buf, start = "", 0
    for i, line in enumerate(text.splitlines(), start=1):
        if not buf:
            start = i
        if line.rstrip().endswith("\\"):
            buf += line.rstrip()[:-1] + " "
            continue
        buf += line
        joined.append((start, buf))
        buf = ""
    for lineno, line in joined:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith(("-r", "--requirement", "-c", "--constraint")):
            problems.append(ParseProblem(source=rel, line=lineno, text=stripped, reason="nested requirement files are not followed automatically"))
            continue
        if stripped.startswith(("-e", "--editable")):
            problems.append(ParseProblem(source=rel, line=lineno, text=stripped, reason="editable installs are not supported in isolated builds"))
            continue
        if stripped.startswith(("--index-url", "-i", "--extra-index-url", "--find-links", "-f", "--trusted-host")):
            problems.append(ParseProblem(source=rel, line=lineno, text=stripped.split()[0], reason="project-supplied index options are ignored; Foundry uses the configured registry"))
            continue
        if stripped.startswith("-"):
            problems.append(ParseProblem(source=rel, line=lineno, text=stripped.split()[0], reason="unsupported pip option ignored"))
            continue
        req = parse_pep508(stripped, rel, kind)
        if req is None:
            problems.append(ParseProblem(source=rel, line=lineno, text=stripped[:120], reason="could not parse requirement"))
        else:
            reqs.append(req)
    return reqs, problems


def parse_pyproject(path: Path, rel: str) -> tuple[dict, list[Requirement], list[ParseProblem]]:
    problems: list[ParseProblem] = []
    try:
        data = tomllib.loads(path.read_text("utf-8"))
    except (tomllib.TOMLDecodeError, UnicodeDecodeError) as exc:
        return {}, [], [ParseProblem(source=rel, line=0, text="", reason=f"invalid TOML: {exc}")]
    project = data.get("project", {}) or {}
    reqs: list[Requirement] = []
    for dep in project.get("dependencies", []) or []:
        r = parse_pep508(str(dep), rel, "runtime")
        if r:
            reqs.append(r)
    for group, deps in (project.get("optional-dependencies", {}) or {}).items():
        kind = "dev" if group in {"dev", "test", "tests", "testing", "lint", "docs"} else "runtime"
        for dep in deps or []:
            r = parse_pep508(str(dep), rel, kind)
            if r:
                r.marker = (r.marker + f" [extra:{group}]").strip()
                reqs.append(r)
    for group, deps in (data.get("dependency-groups", {}) or {}).items():
        for dep in deps or []:
            if isinstance(dep, str):
                r = parse_pep508(dep, rel, "dev")
                if r:
                    reqs.append(r)
    for dep in (data.get("build-system", {}) or {}).get("requires", []) or []:
        r = parse_pep508(str(dep), rel, "build")
        if r:
            reqs.append(r)
    if "tool" in data and "poetry" in data["tool"]:
        problems.append(ParseProblem(source=rel, line=0, text="[tool.poetry]", reason="Poetry dependency tables are detected but not resolved; declare PEP 621 [project] dependencies"))
    return data, reqs, problems


def parse_package_json(path: Path, rel: str) -> tuple[dict, list[Requirement], list[ParseProblem]]:
    try:
        data = json.loads(path.read_text("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        return {}, [], [ParseProblem(source=rel, line=0, text="", reason=f"invalid JSON: {exc}")]
    reqs = []
    for section, kind in (("dependencies", "runtime"), ("devDependencies", "dev")):
        for name, spec in (data.get(section) or {}).items():
            reqs.append(Requirement(name=name, specifier=str(spec), source=rel, kind=kind, ecosystem="node", raw=f"{name}@{spec}"))
    return data, reqs, []


def parse_cargo_toml(path: Path, rel: str) -> tuple[dict, list[Requirement], list[ParseProblem]]:
    try:
        data = tomllib.loads(path.read_text("utf-8"))
    except (tomllib.TOMLDecodeError, UnicodeDecodeError) as exc:
        return {}, [], [ParseProblem(source=rel, line=0, text="", reason=f"invalid TOML: {exc}")]
    reqs = []
    for section, kind in (("dependencies", "runtime"), ("dev-dependencies", "dev"), ("build-dependencies", "build")):
        for name, spec in (data.get(section) or {}).items():
            s = spec if isinstance(spec, str) else (spec.get("version", "") if isinstance(spec, dict) else "")
            reqs.append(Requirement(name=name, specifier=s, source=rel, kind=kind, ecosystem="rust", raw=f"{name} {s}"))
    return data, reqs, []
