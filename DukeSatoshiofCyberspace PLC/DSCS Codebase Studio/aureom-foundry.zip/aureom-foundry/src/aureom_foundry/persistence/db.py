"""SQLite persistence for local project metadata.

The database stores metadata and records (JSON documents validated by Pydantic
models on the way in and out). Source code lives in each project's managed Git
working copy; artefacts live in build and export directories.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

SCHEMA_VERSION = 1

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, type TEXT NOT NULL, root TEXT NOT NULL,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL, ai_sharing INTEGER NOT NULL DEFAULT 0,
    active_profile TEXT NOT NULL DEFAULT 'local-release', doc TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS imports (
    id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    source_kind TEXT NOT NULL, source_ref TEXT NOT NULL, created_at TEXT NOT NULL, doc TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS checkpoints (
    id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    commit_sha TEXT NOT NULL, message TEXT NOT NULL, kind TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS build_profiles (
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE, name TEXT NOT NULL, doc TEXT NOT NULL,
    PRIMARY KEY (project_id, name)
);
CREATE TABLE IF NOT EXISTS builds (
    id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    status TEXT NOT NULL, started_at TEXT NOT NULL, completed_at TEXT, heartbeat_at TEXT, doc TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS test_runs (
    id TEXT PRIMARY KEY, build_id TEXT NOT NULL REFERENCES builds(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL, doc TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS artefacts (
    id TEXT PRIMARY KEY, build_id TEXT NOT NULL REFERENCES builds(id) ON DELETE CASCADE,
    path TEXT NOT NULL, sha256 TEXT NOT NULL, size INTEGER NOT NULL, kind TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS proposals (
    id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL, status TEXT NOT NULL, doc TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS applied_changes (
    id TEXT PRIMARY KEY, proposal_id TEXT NOT NULL REFERENCES proposals(id) ON DELETE CASCADE,
    project_id TEXT NOT NULL, before_commit TEXT NOT NULL, after_commit TEXT NOT NULL,
    applied_at TEXT NOT NULL, reverted_at TEXT, revert_commit TEXT
);
CREATE TABLE IF NOT EXISTS permissions (
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE, key TEXT NOT NULL,
    granted INTEGER NOT NULL, granted_at TEXT NOT NULL, PRIMARY KEY (project_id, key)
);
CREATE TABLE IF NOT EXISTS exports (
    id TEXT PRIMARY KEY, build_id TEXT NOT NULL REFERENCES builds(id) ON DELETE CASCADE,
    path TEXT NOT NULL, created_at TEXT NOT NULL, doc TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS workers (
    container TEXT PRIMARY KEY, owner_id TEXT NOT NULL, kind TEXT NOT NULL, started_at TEXT NOT NULL,
    state TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, project_id TEXT, kind TEXT NOT NULL,
    message TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_builds_project ON builds(project_id, started_at);
CREATE INDEX IF NOT EXISTS idx_activity_project ON activity(project_id, ts);
"""


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


class Database:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._conn().executescript(SCHEMA)  # executescript manages its own transaction
        with self.tx() as c:
            c.execute("INSERT OR IGNORE INTO meta(key, value) VALUES ('schema_version', ?)", (str(SCHEMA_VERSION),))

    def _conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self.path, timeout=30, isolation_level=None)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute("PRAGMA journal_mode = WAL")
            conn.execute("PRAGMA synchronous = NORMAL")
            self._local.conn = conn
        return conn

    @contextmanager
    def tx(self) -> Iterator[sqlite3.Connection]:
        conn = self._conn()
        conn.execute("BEGIN IMMEDIATE")
        try:
            yield conn
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        else:
            conn.execute("COMMIT")

    def query(self, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
        return list(self._conn().execute(sql, params))

    def one(self, sql: str, params: tuple = ()) -> sqlite3.Row | None:
        rows = self.query(sql, params)
        return rows[0] if rows else None

    def execute(self, sql: str, params: tuple = ()) -> None:
        with self.tx() as c:
            c.execute(sql, params)

    def close(self) -> None:
        conn = getattr(self._local, "conn", None)
        if conn is not None:
            conn.close()
            self._local.conn = None

    # ---- convenience ---------------------------------------------------
    def log_activity(self, kind: str, message: str, project_id: str | None = None) -> None:
        from ..inspection.secrets import redact

        self.execute(
            "INSERT INTO activity(ts, project_id, kind, message) VALUES (?, ?, ?, ?)",
            (now(), project_id, kind, redact(message)[:4000]),
        )

    def activity(self, project_id: str | None = None, limit: int = 200) -> list[dict[str, Any]]:
        if project_id:
            rows = self.query("SELECT * FROM activity WHERE project_id = ? ORDER BY id DESC LIMIT ?", (project_id, limit))
        else:
            rows = self.query("SELECT * FROM activity ORDER BY id DESC LIMIT ?", (limit,))
        return [dict(r) for r in rows]

    def set_permission(self, project_id: str, key: str, granted: bool) -> None:
        self.execute(
            "INSERT INTO permissions(project_id, key, granted, granted_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(project_id, key) DO UPDATE SET granted = excluded.granted, granted_at = excluded.granted_at",
            (project_id, key, int(granted), now()),
        )

    def permissions(self, project_id: str) -> dict[str, bool]:
        return {r["key"]: bool(r["granted"]) for r in self.query("SELECT key, granted FROM permissions WHERE project_id = ?", (project_id,))}


def dumps(model: Any) -> str:
    if hasattr(model, "model_dump_json"):
        return model.model_dump_json()
    return json.dumps(model)
