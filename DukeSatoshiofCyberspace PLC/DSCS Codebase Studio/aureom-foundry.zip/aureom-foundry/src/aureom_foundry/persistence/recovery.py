"""Crash recovery and cleanup.

Run at startup while holding the single-instance lock:

* builds left ``queued``/``running`` become ``interrupted`` - never successful;
* Foundry-labelled worker containers are removed;
* Foundry scratch space (``tmp/``), incomplete wheelhouse downloads and build
  scratch directories are deleted.

User source (managed working copies), completed builds' artefacts and exports
are never deleted by recovery.
"""

from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from ..config import FoundrySettings
from .db import Database, now


@dataclass
class RecoveryReport:
    interrupted_builds: list[str] = field(default_factory=list)
    removed_containers: list[str] = field(default_factory=list)
    removed_paths: list[str] = field(default_factory=list)
    skipped_reason: str = ""


class InstanceLock:
    """Advisory lock so recovery never kills workers owned by another running Foundry."""

    def __init__(self, path: Path):
        self.path = path
        self._fh = None

    def acquire(self) -> bool:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = open(self.path, "a+")
        try:
            if os.name == "posix":
                import fcntl

                fcntl.flock(self._fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except OSError:
            self._fh.close()
            self._fh = None
            return False

    def release(self) -> None:
        if self._fh:
            self._fh.close()
            self._fh = None


def recover(settings: FoundrySettings, db: Database, runtime=None, *, have_lock: bool = True) -> RecoveryReport:
    rep = RecoveryReport()
    if not have_lock:
        rep.skipped_reason = "another Foundry instance is running; recovery skipped"
        return rep
    for row in db.query("SELECT id, doc FROM builds WHERE status IN ('queued', 'running')"):
        doc = json.loads(row["doc"])
        doc["status"] = "interrupted"
        doc["completed_at"] = now()
        doc.setdefault("notes", []).append("Foundry stopped before this build finished; marked interrupted during recovery.")
        db.execute("UPDATE builds SET status = 'interrupted', completed_at = ?, doc = ? WHERE id = ?", (now(), json.dumps(doc), row["id"]))
        rep.interrupted_builds.append(row["id"])
        db.log_activity("recovery", f"Build {row['id']} was interrupted and is not counted as successful")
    if runtime is not None and getattr(runtime, "cleanup_orphans", None):
        try:
            rep.removed_containers = runtime.cleanup_orphans()
        except Exception:  # pragma: no cover - runtime might be gone
            pass
    db.execute("DELETE FROM workers")
    # Foundry scratch space only.
    tmp = settings.tmp_dir.resolve()
    if tmp.is_dir():
        for child in tmp.iterdir():
            _rm(child, rep)
    cache = settings.data_dir / "cache" / "wheelhouse"
    if cache.is_dir():
        for wh in cache.iterdir():
            if wh.is_dir() and not (wh / ".complete").exists():
                _rm(wh, rep)
    for bdir in settings.builds_dir.glob("*/image-context"):
        _rm(bdir, rep)
    if rep.interrupted_builds or rep.removed_containers or rep.removed_paths:
        db.log_activity("recovery", f"Recovery: {len(rep.interrupted_builds)} interrupted build(s), {len(rep.removed_containers)} worker(s) removed, {len(rep.removed_paths)} temporary path(s) cleaned")
    return rep


def _rm(path: Path, rep: RecoveryReport) -> None:
    try:
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
        else:
            path.unlink()
        rep.removed_paths.append(str(path))
    except OSError:
        pass
