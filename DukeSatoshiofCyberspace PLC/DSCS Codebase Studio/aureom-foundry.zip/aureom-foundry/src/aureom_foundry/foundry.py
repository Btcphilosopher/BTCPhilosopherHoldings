"""Application facade wiring settings, persistence, isolation and services together."""

from __future__ import annotations

from pathlib import Path

from .builds.service import BuildService
from .config import FoundrySettings
from .diagnostics.logging import configure_logging
from .isolation.runtime import ContainerRuntime, detect_runtime
from .persistence.db import Database
from .persistence.recovery import InstanceLock, RecoveryReport, recover
from .projects.service import ProjectService


class Foundry:
    def __init__(self, settings: FoundrySettings | None = None, runtime: ContainerRuntime | None = None, *, run_recovery: bool = True):
        self.settings = settings or FoundrySettings.load()
        self.settings.ensure_dirs()
        configure_logging(self.settings.data_dir / "logs")
        self.db = Database(self.settings.db_path)
        extra = [Path(self.settings.registry.ca_bundle)] if self.settings.registry.ca_bundle else []
        self.runtime = runtime or detect_runtime(self.settings.runtime, [self.settings.data_dir], extra)
        self.projects = ProjectService(self.settings, self.db)
        self.builds = BuildService(self.settings, self.db, self.projects, self.runtime)
        self.lock = InstanceLock(self.settings.data_dir / "foundry.instance.lock")
        self.recovery: RecoveryReport | None = None
        if run_recovery:
            self.recovery = recover(self.settings, self.db, self.runtime, have_lock=self.lock.acquire())

    # Lazily-built services that depend on optional modules.
    @property
    def exports(self):
        from .packaging.export import ExportService

        return ExportService(self)

    @property
    def proposals(self):
        from .ai.proposals import ProposalService

        return ProposalService(self)

    @property
    def scaffolder(self):
        from .scaffolding.scaffold import Scaffolder

        return Scaffolder(self)

    @property
    def previews(self):
        from .previews.service import PreviewService

        return PreviewService(self)

    def close(self) -> None:
        self.lock.release()
        self.db.close()
