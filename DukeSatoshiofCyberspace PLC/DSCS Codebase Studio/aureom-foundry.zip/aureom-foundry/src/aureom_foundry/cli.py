"""Headless command-line interface for Aureom Foundry."""

from __future__ import annotations

import argparse
import shutil
import sys
import time
from pathlib import Path

from . import APP_NAME, TAGLINE, __version__


def _foundry():
    from .foundry import Foundry

    return Foundry()


def _project(f, ref: str):
    for p in f.projects.list():
        if p.id == ref:
            return p
    matches = [p for p in f.projects.list() if p.name == ref]
    if len(matches) == 1:
        return matches[0]
    if matches:
        sys.exit(f"several projects are named {ref!r}; use the project id")
    sys.exit(f"no project {ref!r}")


def _print_issues(issues) -> None:
    for i in issues:
        print(f"  {i.label()}")
        if i.remedy:
            print(f"      -> {i.remedy}")


def cmd_doctor(a) -> int:
    from .scaffolding.scaffold import templates_root

    f = _foundry()
    st = f.runtime.status()
    print(f"{APP_NAME} {__version__}  -  {TAGLINE}")
    print(f"data directory : {f.settings.data_dir}")
    print(f"isolation      : {st.name} {st.version} ({'available' if st.available else 'UNAVAILABLE: ' + st.reason})")
    for lim in st.limitations:
        print(f"  limitation   : {lim}")
    print(f"worker image   : {f.settings.python_image} ({'present' if getattr(f.runtime, 'image_present', lambda i: False)(f.settings.python_image) else 'not pulled'})")
    print(f"qt image       : {f.settings.qt_image} ({'present' if getattr(f.runtime, 'image_present', lambda i: False)(f.settings.qt_image) else 'not available'})")
    print(f"registry       : {f.settings.registry.index_url} (CA bundle: {f.settings.registry.ca_bundle or 'system'})")
    print(f"git            : {shutil.which('git') or 'MISSING'}")
    try:
        import PySide6

        print(f"PySide6        : {PySide6.__version__}")
    except ImportError:
        print("PySide6        : not installed (desktop UI unavailable; CLI works)")
    try:
        print(f"templates      : {templates_root()}")
    except FileNotFoundError as exc:
        print(f"templates      : {exc}")
    print(f"AI provider    : {f.settings.ai.provider}")
    if f.recovery and (f.recovery.interrupted_builds or f.recovery.removed_containers):
        print(f"recovery       : {len(f.recovery.interrupted_builds)} interrupted build(s), {len(f.recovery.removed_containers)} worker(s) removed")
    return 0 if st.available else 2


def cmd_capabilities(a) -> int:
    from .adapters.base import capability_matrix

    rows = capability_matrix()
    cols = ["project_type", "adapter", "detect", "build", "test", "smoke", "preview", "package"]
    widths = {c: max(len(c), *(len(str(getattr(r, c).value if hasattr(getattr(r, c), "value") else getattr(r, c))) for r in rows)) for c in cols}
    print("  ".join(c.ljust(widths[c]) for c in cols) + "  outputs")
    for r in rows:
        vals = [str(getattr(r, c).value if hasattr(getattr(r, c), "value") else getattr(r, c)) for c in cols]
        print("  ".join(v.ljust(widths[c]) for v, c in zip(vals, cols)) + f"  {r.outputs}")
    return 0


def cmd_import(a) -> int:
    from .projects.service import ImportFailed

    f = _foundry()
    try:
        if a.paste:
            p, rep = f.projects.import_paste(Path(a.paste).read_text("utf-8"), a.name or Path(a.paste).stem, a.filename)
        elif a.spec:
            p, rep = f.projects.import_specification(Path(a.spec).read_text("utf-8"), a.name or Path(a.spec).stem)
        else:
            p, rep = f.projects.import_path(Path(a.path), a.name)
    except ImportFailed as exc:
        print("IMPORT REJECTED:")
        for r in exc.reasons:
            print(f"  - {r}")
        return 3
    print(f"imported {p.name} as {p.id} ({rep.detected_type.value}); managed copy: {p.root}")
    _print_issues(rep.all_issues())
    return 0


def cmd_projects(a) -> int:
    f = _foundry()
    for p in f.projects.list():
        cp = f.projects.latest_checkpoint(p.id)
        print(f"{p.id}  {p.name:24} {p.type:16} profile={p.active_profile:14} checkpoint={cp.commit_sha[:10] if cp else '-'}")
    return 0


def cmd_inspect(a) -> int:
    from .manifests.propose import propose_manifest

    f = _foundry()
    p = _project(f, a.project)
    rep = f.projects.inspect(p)
    if a.json:
        print(rep.model_dump_json(indent=2, exclude={"files"}))
        return 0
    print(f"{p.name}: {len(rep.files)} files, {rep.total_bytes} bytes, source hash {rep.source_hash[:16]}")
    print(f"languages     : {rep.languages}")
    print(f"detected type : {rep.detected_type.value}  ({'; '.join(rep.type_evidence)})")
    print("entry points  : " + (", ".join(f"{e.kind}:{e.target}" for e in rep.entry_points) or "none"))
    print(f"manifests     : {rep.dependencies.manifests}  lockfiles: {rep.dependencies.lockfiles}")
    print(f"build configs : {rep.build_configs}")
    print("issues:")
    _print_issues(rep.all_issues())
    if rep.manifest is None:
        prop = propose_manifest(rep, p.name)
        if prop.manifest:
            from .manifests.loader import dump_manifest

            print("\nproposed foundry.yaml (not written; run `manifest --apply`):\n" + dump_manifest(prop.manifest))
        for q in prop.questions:
            print(f"QUESTION: {q}")
    return 0


def cmd_manifest(a) -> int:
    from .ai.actions import Operation
    from .manifests.effective import compute_effective
    from .manifests.loader import dump_manifest, load_manifest
    from .manifests.propose import propose_manifest

    f = _foundry()
    p = _project(f, a.project)
    m = load_manifest(Path(p.root))
    if m is None:
        prop = propose_manifest(f.projects.inspect(p), p.name)
        if not prop.manifest:
            print("cannot propose a manifest:")
            for q in prop.questions:
                print(f"  QUESTION: {q}")
            return 4
        text = dump_manifest(prop.manifest)
        print(text)
        if a.apply:
            pr = f.proposals.create(p, "Add foundry.yaml", "Manifest proposed from inspection.", [Operation(op="create_file", path="foundry.yaml", content=text)], source="manifest")
            f.proposals.apply(pr.id)
            print(f"applied as proposal {pr.id}")
        m = prop.manifest if not a.apply else load_manifest(Path(p.root))
    st = f.runtime.status()
    eff = compute_effective(m, f.settings, f.db.permissions(p.id), f"{st.name} {st.version}".strip(), st.available)
    print("effective settings:")
    for k, v in eff.rows():
        print(f"  {k:32} {v}")
    return 0


def cmd_deps(a) -> int:
    f = _foundry()
    p = _project(f, a.project)
    d = f.projects.inspect(p).dependencies
    print(f"manifests: {d.manifests}; lockfiles: {d.lockfiles}; requires-python: {d.requires_python}")
    for r in d.requirements:
        print(f"  {r.kind:8} {r.ecosystem:6} {r.name}{r.specifier}  ({r.source})")
    _print_issues(d.issues)
    return 0


def cmd_checkpoint(a) -> int:
    f = _foundry()
    p = _project(f, a.project)
    cp = f.projects.checkpoint(p, a.message)
    print(f"checkpoint {cp.commit_sha}")
    return 0


def _emit(channel: str, text: str) -> None:
    prefix = "[foundry]" if channel == "foundry" else "[project]"
    print(f"{prefix} {text}", flush=True)


def cmd_build(a) -> int:
    f = _foundry()
    p = _project(f, a.project)
    rec = f.builds.run(p, a.profile, emit=_emit if a.verbose else (lambda c, t: print(f"[foundry] {t}") if c == "foundry" and t.startswith(("==", "checkpoint")) else None))
    _print_build(rec)
    return 0 if rec.verified else 1


def _print_build(rec) -> None:
    print(f"\nbuild {rec.build_id}: {rec.status.value} | tests: {rec.tests_status.value} | smoke: {rec.smoke_status.value} | verified: {'yes' if rec.verified else 'no'}")
    for s in rec.stages:
        print(f"  {s.name:8} {s.status.value:10} {s.summary}")
    for art in rec.artefacts:
        print(f"  artefact {art.path} sha256={art.sha256}")
    if rec.diagnosis:
        print(f"  diagnosis: [{rec.diagnosis.category.value}] {rec.diagnosis.summary}")


def cmd_builds(a) -> int:
    f = _foundry()
    p = _project(f, a.project)
    for r in f.builds.list(p.id):
        print(f"{r.build_id}  {r.started_at}  {r.status.value:11} tests={r.tests_status.value:9} smoke={r.smoke_status.value:9} verified={'yes' if r.verified else 'no'}  {r.source_checkpoint[:10]}")
    return 0


def cmd_run(a) -> int:
    f = _foundry()
    res = f.previews.run_cli(a.build, a.args, stdin=sys.stdin.read() if a.stdin else None)
    print(res.project_output, end="" if res.project_output.endswith("\n") else "\n")
    print(f"[foundry] exit code {res.exit_code}{' (timed out)' if res.timed_out else ''} {res.error}")
    return 0 if res.exit_code == 0 else 1


def cmd_preview(a) -> int:
    f = _foundry()
    s = f.previews.start_web(a.build)
    try:
        r = s.readiness
        print(f"preview at {s.url}  readiness: {'READY' if r and r.ready else 'NOT READY'} - {r.detail if r else ''}")
        for n in s.notes:
            print(f"  note: {n}")
        if s.kind == "api" and r and r.ready:
            for e in f.previews.endpoints(s):
                print(f"  {e['method']:6} {e['path']}  {e['summary']}")
        if a.seconds:
            time.sleep(a.seconds)
    finally:
        s.stop()
    return 0 if s.readiness and s.readiness.ready else 1


def cmd_export(a) -> int:
    from .packaging.export import ExportBlocked

    f = _foundry()
    try:
        e = f.exports.export(a.build, allow_unverified=a.allow_unverified)
    except ExportBlocked as exc:
        print(f"EXPORT BLOCKED: {exc}")
        return 5
    print(f"export {e.export_id}: {e.zip_path}\n  sha256 {e.zip_sha256}\n  verified: {e.verified}")
    for i in e.included:
        print(f"  + {i['path']}")
    for x in e.excluded:
        print(f"  - {x['path']}: {x['reason']}")
    return 0


def cmd_repair(a) -> int:
    from .builds.repair import RepairService

    f = _foundry()
    rec = f.builds.get(a.build)
    out = RepairService(f).propose(rec, approved_share=a.approve_share)
    print(out.explanation)
    if out.proposal:
        _print_proposal(out.proposal)
    if out.stopped:
        print(f"[stopped] {out.reason}")
    return 0 if out.proposal and out.proposal.status == "proposed" else 6


def _print_proposal(p) -> None:
    print(f"\nproposal {p.id} [{p.status}] from {p.source}: {p.title}")
    for v in p.violations:
        print(f"  BLOCKED: {v}")
    print(p.diff)


def cmd_proposals(a) -> int:
    f = _foundry()
    p = _project(f, a.project)
    for pr in f.proposals.list(p.id):
        print(f"{pr.id}  {pr.status:9} {pr.source:20} {pr.title}")
    return 0


def cmd_show(a) -> int:
    f = _foundry()
    _print_proposal(f.proposals.get(a.proposal))
    return 0


def cmd_apply(a) -> int:
    f = _foundry()
    p = f.proposals.apply(a.proposal)
    print(f"applied {p.id} as commit {p.applied_commit}")
    return 0


def cmd_revert(a) -> int:
    f = _foundry()
    p = f.proposals.revert(a.proposal)
    print(f"reverted {p.id} with commit {p.revert_commit}")
    return 0


def cmd_reject(a) -> int:
    f = _foundry()
    print(f.proposals.reject(a.proposal).status)
    return 0


def cmd_scaffold(a) -> int:
    from .scaffolding.scaffold import list_templates

    f = _foundry()
    if not a.project:
        for t in list_templates():
            print(f"{t.id:16} {t.label:28} -> {t.project_type} ({t.description})")
        return 0
    p = _project(f, a.project)
    template = a.template or f.scaffolder.suggest_template(p)[0]
    if not template:
        print("QUESTION: " + "; ".join(f.scaffolder.suggest_template(p)[1]))
        return 4
    plan, prop = f.scaffolder.propose(p, template, a.name, a.description or "")
    for q in plan.questions:
        print(f"QUESTION: {q}")
    _print_proposal(prop)
    if a.apply and prop.status == "proposed":
        f.proposals.apply(prop.id)
        print(f"applied {prop.id}")
    return 0


def cmd_grant(a) -> int:
    f = _foundry()
    p = _project(f, a.project)
    f.projects.grant(p, a.permission, a.state == "on")
    print(f"{a.permission}: {'granted' if a.state == 'on' else 'revoked'} for {p.name}")
    return 0


def cmd_ai_sharing(a) -> int:
    from .ai.consent import build_share_preview

    f = _foundry()
    p = _project(f, a.project)
    if a.state:
        f.projects.set_ai_sharing(p, a.state == "on")
    rep = f.projects.inspect(p)
    prev = build_share_preview(Path(p.root), rep, f.settings.ai.max_shared_bytes)
    print(f"external AI sharing for {p.name}: {'ENABLED' if f.projects.get(p.id).ai_sharing else 'disabled'} (provider: {f.settings.ai.provider})")
    print("files that would be shared:")
    for s in prev.files:
        print(f"  {s.path} ({s.bytes} bytes{', ' + str(s.redactions) + ' secret(s) redacted' if s.redactions else ''})")
    for path, reason in prev.excluded:
        print(f"  EXCLUDED {path}: {reason}")
    return 0


def cmd_activity(a) -> int:
    f = _foundry()
    for row in reversed(f.db.activity(limit=a.limit)):
        print(f"{row['ts']}  {row['kind']:16} {row['message']}")
    return 0


def cmd_recover(a) -> int:
    f = _foundry()
    r = f.recovery
    if r is None:
        return 0
    print(f"interrupted builds: {r.interrupted_builds}\nremoved workers: {r.removed_containers}\ncleaned paths: {len(r.removed_paths)}\n{r.skipped_reason}")
    return 0


def cmd_gui(a) -> int:
    from .desktop.app import main as gui_main

    return gui_main()


def cmd_demo(a) -> int:
    from .demo import run_demo

    return run_demo(Path(a.examples) if a.examples else None, Path(a.report) if a.report else None)


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="aureom-foundry", description=f"{APP_NAME} - {TAGLINE}")
    ap.add_argument("--version", action="version", version=__version__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def add(name, fn, help_):
        sp = sub.add_parser(name, help=help_)
        sp.set_defaults(fn=fn)
        return sp

    add("doctor", cmd_doctor, "check isolation, toolchains and settings")
    add("capabilities", cmd_capabilities, "show the capability matrix")
    sp = add("import", cmd_import, "import a folder, file, ZIP, Git repository, pasted code or brief")
    sp.add_argument("path", nargs="?")
    sp.add_argument("--name")
    sp.add_argument("--paste", help="file whose contents are treated as pasted code")
    sp.add_argument("--filename", help="name for pasted code (default: inferred)")
    sp.add_argument("--spec", help="written application brief")
    add("projects", cmd_projects, "list projects")
    sp = add("inspect", cmd_inspect, "inspect a project without executing it")
    sp.add_argument("project")
    sp.add_argument("--json", action="store_true")
    sp = add("manifest", cmd_manifest, "show/propose foundry.yaml and effective settings")
    sp.add_argument("project")
    sp.add_argument("--apply", action="store_true")
    sp = add("deps", cmd_deps, "dependency report")
    sp.add_argument("project")
    sp = add("checkpoint", cmd_checkpoint, "create a Git checkpoint")
    sp.add_argument("project")
    sp.add_argument("-m", "--message", default="Manual checkpoint")
    sp = add("build", cmd_build, "build, test and smoke-check in isolation")
    sp.add_argument("project")
    sp.add_argument("--profile")
    sp.add_argument("-v", "--verbose", action="store_true")
    sp = add("builds", cmd_builds, "list builds")
    sp.add_argument("project")
    sp = add("run", cmd_run, "console preview: run a built CLI in isolation")
    sp.add_argument("build")
    sp.add_argument("args", nargs=argparse.REMAINDER)
    sp.add_argument("--stdin", action="store_true")
    sp = add("preview", cmd_preview, "start a web/API preview and check readiness")
    sp.add_argument("build")
    sp.add_argument("--seconds", type=int, default=0)
    sp = add("export", cmd_export, "export a verified build")
    sp.add_argument("build")
    sp.add_argument("--allow-unverified", action="store_true")
    sp = add("repair", cmd_repair, "propose a repair for a failed build")
    sp.add_argument("build")
    sp.add_argument("--approve-share", action="store_true")
    sp = add("proposals", cmd_proposals, "list proposals")
    sp.add_argument("project")
    for name, fn in (("show", cmd_show), ("apply", cmd_apply), ("revert", cmd_revert), ("reject", cmd_reject)):
        sp = add(name, fn, f"{name} a proposal")
        sp.add_argument("proposal")
    sp = add("scaffold", cmd_scaffold, "list templates or propose a scaffold")
    sp.add_argument("project", nargs="?")
    sp.add_argument("template", nargs="?")
    sp.add_argument("--name")
    sp.add_argument("--description")
    sp.add_argument("--apply", action="store_true")
    sp = add("grant", cmd_grant, "grant or revoke a project permission")
    sp.add_argument("project")
    sp.add_argument("permission", choices=["execution_network"])
    sp.add_argument("state", choices=["on", "off"])
    sp = add("ai-sharing", cmd_ai_sharing, "show or set external AI sharing and the share preview")
    sp.add_argument("project")
    sp.add_argument("state", nargs="?", choices=["on", "off"])
    sp = add("activity", cmd_activity, "activity log")
    sp.add_argument("--limit", type=int, default=50)
    add("recover", cmd_recover, "run crash recovery and report")
    add("gui", cmd_gui, "launch the desktop application")
    sp = add("demo", cmd_demo, "run the scripted 12-step demonstration")
    sp.add_argument("--examples")
    sp.add_argument("--report")
    return ap


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.fn(args) or 0)


if __name__ == "__main__":
    sys.exit(main())
