"""The ten workspace pages:
Projects · Import · Editor · Dependencies · Preview · Build · Tests · Packages · Activity · Settings
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton, QSpinBox,
    QSplitter, QTableWidget, QTabWidget, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget,
)

from ..ai.actions import Operation
from ..editor.buffers import PathRejected, read_text, write_text
from ..manifests.loader import dump_manifest
from ..manifests.propose import propose_manifest
from .widgets import CodeEditor, DropZone, LogView, banner, fill_table, h1, h2, muted, primary, row_layout


class Page(QWidget):
    title = ""
    subtitle = ""

    def __init__(self, win):
        super().__init__()
        self.win = win
        self.setObjectName("page")
        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(24, 18, 24, 18)
        self.root.setSpacing(12)
        self.root.addWidget(h1(self.title))
        if self.subtitle:
            self.root.addWidget(muted(self.subtitle))

    @property
    def f(self):
        return self.win.foundry

    @property
    def p(self):
        return self.win.palette

    def project(self):
        return self.win.current_project()

    def refresh(self) -> None:  # called when the page is shown or the project changes
        pass

    def need_project(self) -> bool:
        if self.project() is None:
            self.win.notify("Select or import a project first.", "warning")
            return False
        return True


# ======================================================================= Projects
class ProjectsPage(Page):
    title = "Projects"
    subtitle = "Foundry works on managed copies. Your original folders, archives and repositories are never modified or executed."

    def __init__(self, win):
        super().__init__(win)
        self.table = QTableWidget()
        self.table.itemSelectionChanged.connect(self._select)
        self.table.doubleClicked.connect(lambda _: self.win.go("Editor"))
        self.root.addWidget(self.table, 1)
        b_open, b_cp, b_del = primary("Open in editor"), QPushButton("Create checkpoint"), QPushButton("Remove managed copy")
        b_del.setObjectName("danger")
        b_open.clicked.connect(lambda: self.win.go("Editor"))
        b_cp.clicked.connect(self._checkpoint)
        b_del.clicked.connect(self._delete)
        self.root.addLayout(row_layout(b_open, b_cp, b_del))
        self.cp_list = QListWidget()
        self.root.addWidget(h2("Checkpoints"))
        self.root.addWidget(self.cp_list, 1)

    def refresh(self) -> None:
        self._projects = self.f.projects.list()
        rows = []
        for pr in self._projects:
            cp = self.f.projects.latest_checkpoint(pr.id)
            b = self.f.builds.latest(pr.id)
            rows.append([pr.name, pr.type, pr.active_profile, cp.commit_sha[:10] if cp else "-", b.status.value if b else "none", ("yes" if b.verified else "no") if b else "-", pr.updated_at])
        self.table.blockSignals(True)  # repopulating must not change the selected project
        fill_table(self.table, ["Name", "Type", "Profile", "Checkpoint", "Last build", "Verified", "Updated"], rows, self.p, (4,))
        self.table.clearSelection()
        cur = self.project()
        for i, pr in enumerate(self._projects):
            if cur and pr.id == cur.id:
                self.table.selectRow(i)
        self.table.blockSignals(False)
        self._checkpoints()

    def _select(self) -> None:
        rows = {i.row() for i in self.table.selectedIndexes()}
        if rows:
            self.win.set_project(self._projects[min(rows)])
            self._checkpoints()

    def _checkpoints(self) -> None:
        self.cp_list.clear()
        pr = self.project()
        if pr:
            for cp in self.f.projects.checkpoints(pr.id):
                self.cp_list.addItem(f"{cp.created_at}  {cp.commit_sha[:10]}  [{cp.kind}]  {cp.message}")

    def _checkpoint(self) -> None:
        if self.need_project():
            cp = self.f.projects.checkpoint(self.project(), "Manual checkpoint from desktop")
            self.win.notify(f"Checkpoint {cp.commit_sha[:10]} created.", "ok")
            self.refresh()
            self.win.refresh_header()

    def _delete(self) -> None:
        pr = self.project()
        if pr and QMessageBox.question(self, "Remove", f"Remove Foundry's managed copy of {pr.name}? The original source and exports are not touched.") == QMessageBox.StandardButton.Yes:
            self.f.projects.delete(pr)
            self.win.set_project(None)
            self.refresh()


# ======================================================================= Import
class ImportPage(Page):
    title = "Import"
    subtitle = "Bring in an existing project, loose code or a written brief. Inspection reads files only; nothing runs."

    def __init__(self, win):
        super().__init__(win)
        self.drop = DropZone()
        self.drop.dropped.connect(self._import_paths)
        self.root.addWidget(self.drop)
        b1, b2, b3, b4 = QPushButton("Choose folder..."), QPushButton("Choose files..."), QPushButton("Choose ZIP..."), QPushButton("Local Git repository...")
        b1.clicked.connect(lambda: self._pick_dir())
        b4.clicked.connect(lambda: self._pick_dir())
        b2.clicked.connect(self._pick_files)
        b3.clicked.connect(self._pick_zip)
        self.root.addLayout(row_layout(b1, b2, b3, b4))
        tabs = QTabWidget()
        # pasted code
        w = QWidget()
        lay = QVBoxLayout(w)
        self.paste = QPlainTextEdit()
        self.paste.setObjectName("code")
        self.paste.setPlaceholderText("Paste a script or a single file here...")
        self.paste_name = QLineEdit(placeholderText="project name (e.g. my-tool)")
        self.paste_file = QLineEdit(placeholderText="file name (optional; inferred)")
        bp = primary("Import pasted code")
        bp.clicked.connect(self._import_paste)
        lay.addWidget(self.paste)
        lay.addLayout(row_layout(self.paste_name, self.paste_file, bp, stretch=False))
        tabs.addTab(w, "Paste code")
        # brief
        w2 = QWidget()
        lay2 = QVBoxLayout(w2)
        self.brief = QPlainTextEdit()
        self.brief.setPlaceholderText("Describe the application. With an AI provider enabled, Foundry proposes code as a reviewable diff.")
        self.brief_name = QLineEdit(placeholderText="project name")
        bb = QPushButton("Create project from brief")
        bb.clicked.connect(self._import_brief)
        lay2.addWidget(self.brief)
        lay2.addLayout(row_layout(self.brief_name, bb, stretch=False))
        tabs.addTab(w2, "Application brief")
        # result
        w3 = QWidget()
        lay3 = QVBoxLayout(w3)
        self.result_box = QVBoxLayout()
        lay3.addLayout(self.result_box)
        self.result = QPlainTextEdit()
        self.result.setReadOnly(True)
        self.result.setObjectName("log")
        lay3.addWidget(self.result, 1)
        self.b_manifest = primary("Apply proposed foundry.yaml")
        self.b_manifest.clicked.connect(self._apply_manifest)
        self.tpl = QComboBox()
        self.b_scaffold = QPushButton("Preview scaffold")
        self.b_scaffold.clicked.connect(self._scaffold)
        lay3.addLayout(row_layout(self.b_manifest, QLabel("Template:"), self.tpl, self.b_scaffold))
        tabs.addTab(w3, "Inspection result")
        self.tabs = tabs
        self.root.addWidget(tabs, 1)
        try:
            from ..scaffolding.scaffold import list_templates

            for t in list_templates():
                self.tpl.addItem(f"{t.label} -> {t.project_type}", t.id)
        except FileNotFoundError:
            self.tpl.addItem("(templates not found)", "")
        self._proposed = None

    def _pick_dir(self) -> None:
        d = QFileDialog.getExistingDirectory(self, "Choose a project folder or Git repository")
        if d:
            self._import_paths([Path(d)])

    def _pick_files(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(self, "Choose files")
        if files:
            self._run_import(lambda: self.f.projects.import_files([Path(x) for x in files], Path(files[0]).stem))

    def _pick_zip(self) -> None:
        z, _ = QFileDialog.getOpenFileName(self, "Choose a ZIP archive", filter="ZIP archives (*.zip)")
        if z:
            self._import_paths([Path(z)])

    def _import_paths(self, paths: list[Path]) -> None:
        if len(paths) == 1:
            self._run_import(lambda: self.f.projects.import_path(paths[0]))
        else:
            self._run_import(lambda: self.f.projects.import_files([p for p in paths if p.is_file()], paths[0].stem))

    def _import_paste(self) -> None:
        code = self.paste.toPlainText()
        if not code.strip():
            return self.win.notify("Nothing pasted.", "warning")
        self._run_import(lambda: self.f.projects.import_paste(code, self.paste_name.text() or "pasted-code", self.paste_file.text() or None))

    def _import_brief(self) -> None:
        text = self.brief.toPlainText()
        if not text.strip():
            return self.win.notify("The brief is empty.", "warning")
        self._run_import(lambda: self.f.projects.import_specification(text, self.brief_name.text() or "from-brief"))

    def _run_import(self, fn) -> None:
        from ..projects.service import ImportFailed

        def done(res):
            project, report = res
            self.win.set_project(project)
            self._show_report(project, report)

        def failed(msg: str):
            self.tabs.setCurrentIndex(2)
            self.result.setPlainText(msg)

        def work():
            try:
                return fn()
            except ImportFailed as exc:
                raise RuntimeError("Import rejected:\n- " + "\n- ".join(exc.reasons)) from None

        self.win.run_bg(work, done, failed, busy="Importing and inspecting...")

    def _show_report(self, project, rep) -> None:
        while self.result_box.count():
            item = self.result_box.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        errs = [i for i in rep.all_issues() if i.severity.value == "error"]
        warns = [i for i in rep.all_issues() if i.severity.value == "warning"]
        if errs:
            self.result_box.addWidget(banner(f"{len(errs)} problem(s) must be fixed before a build can succeed.", "error"))
        if warns:
            self.result_box.addWidget(banner(f"{len(warns)} warning(s) to review.", "warning"))
        if not errs and not warns:
            self.result_box.addWidget(banner("Inspection found no blocking problems.", "ok"))
        lines = [
            f"Project {project.name} ({project.id}) - managed copy {project.root}",
            f"Detected type: {rep.detected_type.value} ({'; '.join(rep.type_evidence)})",
            f"Files: {len(rep.files)}  Bytes: {rep.total_bytes}  Languages: {rep.languages}",
            "Entry points: " + (", ".join(f"{e.kind}: {e.target}" for e in rep.entry_points) or "none"),
            f"Manifests: {rep.dependencies.manifests}  Lockfiles: {rep.dependencies.lockfiles}  Build configs: {rep.build_configs}",
            "",
            "Issues:",
        ]
        for i in rep.all_issues():
            lines.append(f"  {i.label()}" + (f"\n      -> {i.remedy}" if i.remedy else ""))
        self._proposed = None
        if rep.manifest is None:
            prop = propose_manifest(rep, project.name)
            if prop.manifest:
                self._proposed = dump_manifest(prop.manifest)
                lines += ["", "Proposed foundry.yaml (review, then apply):", self._proposed]
            for q in prop.questions:
                lines.append(f"QUESTION: {q}")
        self.b_manifest.setEnabled(self._proposed is not None)
        if project.needs_scaffold:
            tid, qs = self.f.scaffolder.suggest_template(project)
            if tid:
                idx = self.tpl.findData(tid)
                if idx >= 0:
                    self.tpl.setCurrentIndex(idx)
            lines += ["", "This is loose code: preview a scaffold to generate a minimal project."] + [f"QUESTION: {q}" for q in qs]
        self.result.setPlainText("\n".join(lines))
        self.tabs.setCurrentIndex(2)

    def _apply_manifest(self) -> None:
        pr = self.project()
        if not pr or not self._proposed:
            return
        prop = self.f.proposals.create(pr, "Add foundry.yaml", "Manifest proposed from inspection.", [Operation(op="create_file", path="foundry.yaml", content=self._proposed)], source="manifest")
        if self.win.review_proposal(prop):
            self._show_report(self.f.projects.get(pr.id), self.f.projects.inspect(pr))

    def _scaffold(self) -> None:
        pr = self.project()
        tid = self.tpl.currentData()
        if not pr or not tid:
            return
        plan, prop = self.f.scaffolder.propose(pr, tid)
        if plan.questions:
            QMessageBox.information(self, "Scaffold questions", "Foundry cannot infer these safely:\n\n- " + "\n- ".join(plan.questions))
        if self.win.review_proposal(prop):
            self._show_report(self.f.projects.get(pr.id), self.f.projects.inspect(pr))


# ======================================================================= Editor
class EditorPage(Page):
    title = "Editor"
    subtitle = ""

    def __init__(self, win):
        super().__init__(win)
        split = QSplitter(Qt.Orientation.Horizontal)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Project"])
        self.tree.itemClicked.connect(self._open_item)
        self.editor = CodeEditor(win.palette)
        mid = QWidget()
        ml = QVBoxLayout(mid)
        ml.setContentsMargins(0, 0, 0, 0)
        self.path_label = muted("No file open")
        b_save, b_cp = primary("Save"), QPushButton("Save + checkpoint")
        b_save.clicked.connect(self._save)
        b_cp.clicked.connect(lambda: self._save(checkpoint=True))
        ml.addLayout(row_layout(self.path_label, b_save, b_cp))
        ml.addWidget(self.editor, 1)
        side = QTabWidget()
        self.issues = QListWidget()
        self.issues.setWordWrap(True)
        self.build_log = LogView("Build activity appears here while a build runs.")
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        bw = QWidget()
        bl = QVBoxLayout(bw)
        self.b_build = primary("Build in isolation")
        self.b_build.clicked.connect(lambda: self.win.pages["Build"].start_build())
        bl.addWidget(self.b_build)
        bl.addWidget(self.progress)
        bl.addWidget(self.build_log, 1)
        side.addTab(self.issues, "Inspection")
        side.addTab(bw, "Build")
        split.addWidget(self.tree)
        split.addWidget(mid)
        split.addWidget(side)
        split.setSizes([230, 640, 360])
        self.root.addWidget(split, 1)
        self.current_path: str | None = None

    def refresh(self) -> None:
        self.tree.clear()
        self.issues.clear()
        pr = self.project()
        if not pr:
            return
        nodes: dict[str, QTreeWidgetItem] = {}
        root_item = QTreeWidgetItem([pr.name])
        self.tree.addTopLevelItem(root_item)
        for rel in self.f.projects.files(pr):
            parent = root_item
            parts = rel.split("/")
            for i, part in enumerate(parts[:-1]):
                key = "/".join(parts[: i + 1])
                if key not in nodes:
                    nodes[key] = QTreeWidgetItem([part])
                    parent.addChild(nodes[key])
                parent = nodes[key]
            leaf = QTreeWidgetItem([parts[-1]])
            leaf.setData(0, Qt.ItemDataRole.UserRole, rel)
            parent.addChild(leaf)
        root_item.setExpanded(True)
        for item in nodes.values():
            item.setExpanded(item.text(0) in ("src",) or item.parent() is root_item)
        rep = self.f.projects.inspect(pr)
        for i in rep.all_issues():
            it = QListWidgetItem(i.label())
            it.setForeground(Qt.GlobalColor.red if i.severity.value == "error" else Qt.GlobalColor.darkYellow if i.severity.value == "warning" else Qt.GlobalColor.gray)
            it.setToolTip(i.remedy or "")
            self.issues.addItem(it)
        if not self.current_path:
            first = next((e.target for e in rep.entry_points if e.kind == "python-main"), None) or ("foundry.yaml" if rep.manifest else None)
            if first:
                self._open(first)

    def _open_item(self, item) -> None:
        rel = item.data(0, Qt.ItemDataRole.UserRole)
        if rel:
            self._open(rel)

    def _open(self, rel: str) -> None:
        pr = self.project()
        try:
            text = read_text(Path(pr.root), rel)
        except (PathRejected, OSError) as exc:
            self.win.notify(str(exc), "warning")
            return
        self.current_path = rel
        self.editor.set_language(rel)
        self.editor.setPlainText(text)
        self.path_label.setText(rel)

    def _save(self, checkpoint: bool = False) -> None:
        pr = self.project()
        if not pr or not self.current_path:
            return
        write_text(Path(pr.root), self.current_path, self.editor.toPlainText())
        msg = f"Saved {self.current_path}"
        if checkpoint:
            cp = self.f.projects.checkpoint(pr, f"Edit {self.current_path}")
            msg += f"; checkpoint {cp.commit_sha[:10]}"
        self.win.notify(msg, "ok")
        self.win.refresh_header()
        cur = self.current_path
        self.refresh()
        self.current_path = cur


# ======================================================================= Dependencies
class DependenciesPage(Page):
    title = "Dependencies"
    subtitle = "Declared requirements, what is missing, and the effective execution settings. Project permission requests are requests, not grants."

    def __init__(self, win):
        super().__init__(win)
        self.banner_box = QVBoxLayout()
        self.root.addLayout(self.banner_box)
        tabs = QTabWidget()
        self.reqs = QTableWidget()
        self.issues = QTableWidget()
        self.effective = QTableWidget()
        tabs.addTab(self.reqs, "Requirements")
        tabs.addTab(self.issues, "Findings")
        tabs.addTab(self.effective, "Effective settings")
        self.root.addWidget(tabs, 1)

    def refresh(self) -> None:
        from ..manifests.effective import compute_effective

        while self.banner_box.count():
            w = self.banner_box.takeAt(0).widget()
            if w:
                w.deleteLater()
        pr = self.project()
        if not pr:
            return
        rep = self.f.projects.inspect(pr)
        d = rep.dependencies
        fill_table(self.reqs, ["Name", "Specifier", "Kind", "Ecosystem", "Source", "Pinned"], [[r.name, r.specifier or "(any)", r.kind, r.ecosystem, r.source, "yes" if r.pinned else "no"] for r in d.requirements])
        fill_table(self.issues, ["Severity", "Code", "Where", "Finding", "Remedy"], [[i.severity.value.upper(), i.code, i.path or "", i.message, i.remedy or ""] for i in d.issues])
        n_err = sum(i.severity.value == "error" for i in d.issues)
        if n_err:
            self.banner_box.addWidget(banner(f"{n_err} dependency problem(s) need attention.", "error"))
        if rep.manifest:
            st = self.f.runtime.status()
            eff = compute_effective(rep.manifest, self.f.settings, self.f.db.permissions(pr.id), f"{st.name} {st.version}".strip(), st.available)
            fill_table(self.effective, ["Setting", "Effective value"], [list(r) for r in eff.rows()])
        else:
            fill_table(self.effective, ["Setting", "Effective value"], [["foundry.yaml", "missing - apply the proposed manifest on the Import page"]])


# ======================================================================= Preview
class PreviewPage(Page):
    title = "Preview"
    subtitle = "Run the latest build in an isolated worker. Web previews are served from the worker on their own origin; Foundry exposes no local API to them."

    def __init__(self, win):
        super().__init__(win)
        self.session = None
        tabs = QTabWidget()
        # CLI console
        cw = QWidget()
        cl = QVBoxLayout(cw)
        self.args = QLineEdit(placeholderText="arguments, e.g.  summary data/sample.csv")
        self.stdin = QLineEdit(placeholderText="standard input (optional)")
        b_run = primary("Run")
        b_run.clicked.connect(self._run_cli)
        cl.addLayout(row_layout(QLabel("Args"), self.args, b_run, stretch=False))
        cl.addLayout(row_layout(QLabel("Stdin"), self.stdin, stretch=False))
        split = QSplitter(Qt.Orientation.Vertical)
        self.cli_out = LogView("Program output")
        self.cli_log = LogView("Foundry log (kept separate from program output)")
        split.addWidget(self._labelled("Program output", self.cli_out))
        split.addWidget(self._labelled("Foundry log", self.cli_log))
        cl.addWidget(split, 1)
        tabs.addTab(cw, "CLI console")
        # Web / API
        ww = QWidget()
        wl = QVBoxLayout(ww)
        self.b_start, self.b_stop, self.b_open = primary("Start preview"), QPushButton("Stop"), QPushButton("Open in system browser")
        self.b_start.clicked.connect(self._start_web)
        self.b_stop.clicked.connect(self._stop_web)
        self.b_open.clicked.connect(lambda: self.session and QDesktopServices.openUrl(QUrl(self.session.url)))
        self.ready = QLabel("Not running")
        wl.addLayout(row_layout(self.b_start, self.b_stop, self.b_open, self.ready))
        self.web_holder = QVBoxLayout()
        self.web_view = None  # created lazily on first preview
        self.web_note = muted("The preview opens here once it is ready.")
        self.web_holder.addWidget(self.web_note)
        wl.addLayout(self.web_holder, 1)
        tabs.addTab(ww, "Web preview")
        aw = QWidget()
        al = QVBoxLayout(aw)
        self.endpoints = QListWidget()
        self.endpoints.itemClicked.connect(self._pick_endpoint)
        self.method = QComboBox()
        self.method.addItems(["GET", "POST", "PUT", "PATCH", "DELETE"])
        self.path = QLineEdit("/health")
        self.body = QPlainTextEdit()
        self.body.setPlaceholderText('JSON body, e.g. {"sku": "WID-001", "name": "Widget", "quantity": 3, "unit_price": 2.5}')
        self.body.setMaximumHeight(90)
        b_send = primary("Send")
        b_send.clicked.connect(self._send)
        self.response = LogView("Response")
        al.addWidget(h2("Endpoints (from the preview's OpenAPI document)"))
        al.addWidget(self.endpoints)
        al.addLayout(row_layout(self.method, self.path, b_send, stretch=False))
        al.addWidget(self.body)
        al.addWidget(self.response, 1)
        tabs.addTab(aw, "API explorer")
        dw = QWidget()
        dl = QVBoxLayout(dw)
        b_desk = QPushButton("Run desktop launch check")
        b_desk.clicked.connect(self._desktop)
        self.desk_out = muted("Desktop applications are launched in the Qt worker image with the offscreen platform, where that image is available.")
        dl.addLayout(row_layout(b_desk))
        dl.addWidget(self.desk_out)
        dl.addStretch(1)
        tabs.addTab(dw, "Desktop")
        self.root.addWidget(tabs, 1)

    def _labelled(self, text, w):
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(h2(text))
        lay.addWidget(w)
        return box

    def _make_web_view(self):
        """An embedded view with an off-the-record profile, no web channel and no local-file access.

        Returns None (system browser only) when QtWebEngine is missing or when Foundry runs as
        root, where Chromium's sandbox is unavailable - Foundry never disables that sandbox.
        """

        import os

        if hasattr(os, "geteuid") and os.geteuid() == 0:
            self.web_note.setText("Embedded preview disabled: running as root, where the browser sandbox cannot be used. Use 'Open in system browser'.")
            return None
        try:
            from PySide6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage, QWebEngineSettings
            from PySide6.QtWebEngineWidgets import QWebEngineView
        except ImportError:
            self.web_note.setText("Embedded web view unavailable (QtWebEngine not installed). Use 'Open in system browser'.")
            return None
        self._profile = QWebEngineProfile(self)  # no storage name => off-the-record
        view = QWebEngineView()
        page = QWebEnginePage(self._profile, view)
        s = page.settings()
        s.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, False)
        s.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, False)
        s.setAttribute(QWebEngineSettings.WebAttribute.PluginsEnabled, False)
        s.setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanOpenWindows, False)
        s.setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanAccessClipboard, False)
        view.setPage(page)
        return view

    def _build(self):
        pr = self.project()
        if not pr:
            self.win.notify("Select a project first.", "warning")
            return None
        b = next((r for r in self.f.builds.list(pr.id) if r.status.value == "succeeded"), None)
        if b is None:
            self.win.notify("Build the project successfully before previewing it.", "warning")
        return b

    def _run_cli(self) -> None:
        import shlex

        b = self._build()
        if not b:
            return
        try:
            args = shlex.split(self.args.text())  # tokenised into an argument array; never passed to a shell
        except ValueError as exc:
            return self.win.notify(f"Could not parse arguments: {exc}", "warning")
        self.cli_out.clear()
        self.cli_log.clear()

        def done(res):
            self.cli_out.setPlainText(res.project_output)
            self.cli_log.setPlainText("\n".join(res.foundry_log) + f"\nexit code: {res.exit_code}{' (timed out)' if res.timed_out else ''} {res.error}")

        self.win.run_bg(lambda: self.f.previews.run_cli(b.build_id, args, stdin=self.stdin.text() or None), done, busy="Running in isolated worker...")

    def _start_web(self) -> None:
        b = self._build()
        if not b:
            return
        self._stop_web()

        def done(session):
            self.session = session
            r = session.readiness
            self.ready.setText(("READY: " if r and r.ready else "NOT READY: ") + (r.detail if r else "") + f"  {session.url}")
            if r and r.ready and self.web_view is None:
                self.web_view = self._make_web_view()
                if self.web_view is not None:
                    self.web_note.hide()
                    self.web_holder.addWidget(self.web_view, 1)
            if r and r.ready and self.web_view is not None:
                start = "/index.html" if session.kind == "web" else "/docs"
                self.web_view.setUrl(QUrl(session.url + start))
            if session.kind == "api" and r and r.ready:
                self.endpoints.clear()
                for e in self.f.previews.endpoints(session):
                    self.endpoints.addItem(f"{e['method']} {e['path']}  {e['summary']}")

        self.win.run_bg(lambda: self.f.previews.start_web(b.build_id), done, busy="Starting isolated preview and waiting for readiness...")

    def _stop_web(self) -> None:
        if self.session:
            self.session.stop()
            self.session = None
            self.ready.setText("Stopped")

    def _pick_endpoint(self, item) -> None:
        method, path = item.text().split()[:2]
        self.method.setCurrentText(method)
        self.path.setText(path)

    def _send(self) -> None:
        if not self.session:
            return self.win.notify("Start the preview first.", "warning")
        try:
            status, text = self.f.previews.request(self.session, self.method.currentText(), self.path.text(), self.body.toPlainText() or None)
        except Exception as exc:
            return self.response.setPlainText(f"request failed: {exc}")
        self.response.setPlainText(f"HTTP {status}\n\n{text}")

    def _desktop(self) -> None:
        b = self._build()
        if b:
            self.win.run_bg(lambda: self.f.previews.desktop(b.build_id), lambda s: self.desk_out.setText(s), busy="Launching in Qt worker...")


# ======================================================================= Build
class BuildPage(Page):
    title = "Build"
    subtitle = "Each build stages the exact checkpoint, fetches dependencies with registry-only network, then builds, tests and smoke-checks with no network."

    def __init__(self, win):
        super().__init__(win)
        self.profile = QComboBox()
        self.b_build = primary("Build in isolation")
        self.b_cancel = QPushButton("Cancel")
        self.b_cancel.setEnabled(False)
        self.b_build.clicked.connect(self.start_build)
        self.b_cancel.clicked.connect(self._cancel)
        self.root.addLayout(row_layout(QLabel("Profile"), self.profile, self.b_build, self.b_cancel))
        self.progress = QProgressBar()
        self.progress.setRange(0, 5)
        self.progress.setFormat("%v / %m stages")
        self.root.addWidget(self.progress)
        self.banner_box = QVBoxLayout()
        self.root.addLayout(self.banner_box)
        self.stages = QTableWidget()
        self.stages.setMaximumHeight(190)
        self.root.addWidget(self.stages)
        split = QSplitter(Qt.Orientation.Horizontal)
        self.flog = LogView("Foundry log")
        self.plog = LogView("Project output (tools and program)")
        split.addWidget(self._labelled("Foundry log", self.flog))
        split.addWidget(self._labelled("Project output", self.plog))
        self.root.addWidget(split, 2)
        self.root.addWidget(h2("Changes and repairs"))
        self.diag = muted("")
        self.b_explain, self.b_repair = QPushButton("Explain failure"), primary("Propose repair")
        self.b_explain.clicked.connect(self._explain)
        self.b_repair.clicked.connect(self._repair)
        self.root.addLayout(row_layout(self.diag, self.b_explain, self.b_repair))
        self.proposals = QTableWidget()
        self.proposals.setMaximumHeight(150)
        b_review, b_revert = QPushButton("Review selected"), QPushButton("Revert selected")
        b_review.clicked.connect(self._review_selected)
        b_revert.clicked.connect(self._revert_selected)
        self.root.addWidget(self.proposals)
        self.root.addLayout(row_layout(b_review, b_revert))
        self.token = None
        self._done_stages = 0

    def _labelled(self, text, w):
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(h2(text))
        lay.addWidget(w)
        return box

    def refresh(self) -> None:
        pr = self.project()
        self.profile.clear()
        if not pr:
            return
        for prof in self.f.builds.profiles(pr):
            self.profile.addItem(f"{prof.name} - {prof.description}", prof.name)
        idx = self.profile.findData(pr.active_profile)
        if idx >= 0:
            self.profile.setCurrentIndex(idx)
        st = self.f.runtime.status()
        self.b_build.setEnabled(st.available and self.token is None)
        self.b_build.setToolTip("" if st.available else f"Isolation unavailable: {st.reason}")
        latest = self.f.builds.latest(pr.id)
        if latest and self.token is None:
            self.show_record(latest)
        self._proposals()

    def start_build(self) -> None:
        from ..isolation.process import CancellationToken

        if not self.need_project():
            return
        st = self.f.runtime.status()
        if not st.available:
            return self.win.notify(f"Isolated execution is unavailable ({st.reason}). Inspection and editing still work; untrusted code is not run on the host.", "error")
        pr = self.project()
        prof = self.profile.currentData() or pr.active_profile
        self.f.projects.touch(pr.id, active_profile=prof)
        self.win.go("Build")
        self.flog.clear()
        self.plog.clear()
        self._clear_banners()
        self.progress.setValue(0)
        self._done_stages = 0
        self.token = CancellationToken()
        self.b_build.setEnabled(False)
        self.b_cancel.setEnabled(True)
        self.win.pages["Editor"].progress.setVisible(True)

        def emit(channel, text):
            self.win.bridge.message.emit(channel, text)

        token = self.token
        self.win.run_bg(lambda: self.f.builds.run(pr, prof, emit=emit, cancel=token), self._finished, self._failed)

    def on_message(self, channel: str, text: str) -> None:
        if channel == "foundry":
            self.flog.append_line(text)
            self.win.pages["Editor"].build_log.append_line(text)
            if text.startswith(("fetch:", "build:", "package:", "test:", "smoke:")) and (" - " in text) and ("passed" in text or "failed" in text or "skipped" in text or "unsupported" in text or "timed_out" in text):
                self._done_stages += 1
                self.progress.setValue(min(5, self._done_stages))
        else:
            self.plog.append_line(text)

    def _cancel(self) -> None:
        if self.token:
            self.token.cancel()
            self.flog.append_line("cancellation requested - stopping worker")

    def _finished(self, rec) -> None:
        self.token = None
        self.b_cancel.setEnabled(False)
        self.b_build.setEnabled(True)
        self.win.pages["Editor"].progress.setVisible(False)
        self.progress.setValue(5)
        self.show_record(rec)
        self.win.refresh_header()
        self._proposals()

    def _failed(self, msg: str) -> None:
        self.token = None
        self.b_cancel.setEnabled(False)
        self.b_build.setEnabled(True)
        self.win.pages["Editor"].progress.setVisible(False)
        self.win.notify(msg, "error")

    def _clear_banners(self) -> None:
        while self.banner_box.count():
            w = self.banner_box.takeAt(0).widget()
            if w:
                w.deleteLater()

    def show_record(self, rec) -> None:
        self._clear_banners()
        self.record = rec
        kind = "ok" if rec.verified else "error" if rec.status.value != "succeeded" else "warning"
        text = f"Build {rec.build_id}: {rec.status.value.upper()} - tests {rec.tests_status.value.upper()} - smoke {rec.smoke_status.value.upper()} - " + ("VERIFIED" if rec.verified else "NOT VERIFIED")
        self.banner_box.addWidget(banner(text, kind))
        fill_table(self.stages, ["Stage", "Status", "Duration (s)", "Summary"], [[s.name, s.status.value, s.duration_s, s.summary] for s in rec.stages], self.p, (1,))
        d = rec.diagnosis
        self.diag.setText(f"Diagnosis [{d.category.value}]: {d.summary}" if d else "No failure recorded.")
        self.b_repair.setEnabled(d is not None)
        self.b_explain.setEnabled(d is not None)
        if self.token is None:  # showing a finished build: load its persisted logs
            flog = self.f.builds.build_dir(rec.build_id) / "logs" / "foundry.log"
            self.flog.setPlainText(flog.read_text("utf-8", "replace")[-200_000:] if flog.exists() else "")
            parts = []
            for stage, path in rec.logs.items():
                pth = Path(path)
                if pth.exists() and pth.name != "foundry.log":
                    parts.append(f"===== {stage} =====\n" + pth.read_text("utf-8", "replace")[-60_000:])
            self.plog.setPlainText("\n".join(parts))

    def _explain(self) -> None:
        from ..builds.repair import RepairService

        rec = getattr(self, "record", None)
        if rec:
            QMessageBox.information(self, "Failure explanation", RepairService(self.f).explain(rec) + "\n\nEvidence:\n" + "\n".join((rec.diagnosis.evidence or [])[-12:]))

    def _repair(self) -> None:
        from ..ai.consent import build_share_preview
        from ..ai.adapter import adapter_for
        from ..builds.repair import RepairService

        rec = getattr(self, "record", None)
        if not rec:
            return
        pr = self.f.projects.get(rec.project_id)
        approved = False
        if adapter_for(self.f.settings, pr).external:
            prev = build_share_preview(Path(pr.root), self.f.projects.inspect(pr), self.f.settings.ai.max_shared_bytes, [rec.diagnosis.path] if rec.diagnosis and rec.diagnosis.path else None)
            listing = "\n".join(f"  {s.path} ({s.bytes} B{', ' + str(s.redactions) + ' redacted' if s.redactions else ''})" for s in prev.files[:40])
            excl = "\n".join(f"  {p} - {r}" for p, r in prev.excluded[:20])
            approved = QMessageBox.question(self, "Share with external AI?", f"These files would be sent to {self.f.settings.ai.model}:\n{listing}\n\nExcluded:\n{excl}") == QMessageBox.StandardButton.Yes
            if not approved:
                return
        out = RepairService(self.f).propose(rec, approved_share=approved)
        if out.proposal is None:
            QMessageBox.information(self, "No repair proposed", f"{out.explanation}\n\n[{out.reason}]")
            return
        if self.win.review_proposal(out.proposal) and QMessageBox.question(self, "Rebuild", "Change applied and checkpointed. Rebuild now to rerun the checks?") == QMessageBox.StandardButton.Yes:
            self.start_build()
        self._proposals()

    def _proposals(self) -> None:
        pr = self.project()
        self._props = self.f.proposals.list(pr.id) if pr else []
        fill_table(self.proposals, ["Proposal", "Status", "Source", "Title", "Files"], [[p.id, p.status, p.source, p.title, ", ".join(p.files)] for p in self._props])

    def _selected(self):
        rows = {i.row() for i in self.proposals.selectedIndexes()}
        return self._props[min(rows)] if rows else None

    def _review_selected(self) -> None:
        p = self._selected()
        if p:
            self.win.review_proposal(p)
            self._proposals()

    def _revert_selected(self) -> None:
        p = self._selected()
        if not p:
            return
        try:
            self.f.proposals.revert(p.id)
            self.win.notify(f"Reverted {p.id}.", "ok")
        except Exception as exc:
            self.win.notify(str(exc), "error")
        self._proposals()
        self.win.refresh_header()


# ======================================================================= Tests
class TestsPage(Page):
    __test__ = False
    title = "Tests"
    subtitle = "Test results are reported separately from build and smoke-check results. Failing tests are never skipped or weakened to obtain a green build."

    def __init__(self, win):
        super().__init__(win)
        self.summary = QVBoxLayout()
        self.root.addLayout(self.summary)
        self.table = QTableWidget()
        self.root.addWidget(self.table, 1)

    def refresh(self) -> None:
        while self.summary.count():
            w = self.summary.takeAt(0).widget()
            if w:
                w.deleteLater()
        pr = self.project()
        rec = self.f.builds.latest(pr.id) if pr else None
        if not rec:
            self.summary.addWidget(muted("No builds yet."))
            fill_table(self.table, ["Test", "Outcome", "Message"], [])
            return
        t = rec.tests
        kind = "ok" if rec.tests_status.value == "passed" else "error" if rec.tests_status.value in ("failed", "timed_out") else "warning"
        msg = f"Build: {rec.status.value.upper()}  |  Tests: {rec.tests_status.value.upper()}" + (f" ({t.passed} passed, {t.failed} failed, {t.errors} errors, {t.skipped} skipped)" if t and t.total else (f" - {t.note}" if t and t.note else "")) + f"  |  Smoke: {rec.smoke_status.value.upper()}"
        self.summary.addWidget(banner(msg, kind))
        rows = [[f"{c.classname}::{c.name}" if c.classname else c.name, c.outcome, c.message] for c in (t.cases if t else [])]
        fill_table(self.table, ["Test", "Outcome", "Message"], rows, self.p, ())
        for r, c in enumerate(t.cases if t else []):
            from .widgets import status_item

            self.table.setItem(r, 1, status_item({"error": "failed"}.get(c.outcome, c.outcome), self.p))


# ======================================================================= Packages
class PackagesPage(Page):
    title = "Packages"
    subtitle = "Artefacts, checksums and exports. Signing, publishing and deployment are separate steps outside local packaging."

    def __init__(self, win):
        super().__init__(win)
        self.builds = QTableWidget()
        self.builds.itemSelectionChanged.connect(self._select)
        self.root.addWidget(h2("Builds"))
        self.root.addWidget(self.builds, 1)
        self.artefacts = QTableWidget()
        self.root.addWidget(h2("Artefacts"))
        self.root.addWidget(self.artefacts, 1)
        self.allow_unverified = QCheckBox("Allow exporting an unverified build (it will be labelled UNVERIFIED)")
        b_export, b_open = primary("Export package"), QPushButton("Open exports folder")
        b_export.clicked.connect(self._export)
        b_open.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.f.settings.exports_dir))))
        self.root.addLayout(row_layout(b_export, self.allow_unverified, b_open))
        self.exports = QListWidget()
        self.root.addWidget(h2("Exports"))
        self.root.addWidget(self.exports, 1)
        self._recs = []

    def refresh(self) -> None:
        pr = self.project()
        self._recs = self.f.builds.list(pr.id) if pr else []
        fill_table(self.builds, ["Build", "Started", "Build", "Tests", "Smoke", "Verified", "Profile", "Checkpoint"], [[r.build_id, r.started_at, r.status.value, r.tests_status.value, r.smoke_status.value, "yes" if r.verified else "no", r.build_profile, r.source_checkpoint[:10]] for r in self._recs], self.p, (2, 3, 4))
        if self._recs:
            self.builds.selectRow(0)
        self.exports.clear()
        for r in self._recs:
            for e in self.f.exports.list(r.build_id):
                self.exports.addItem(f"{e.created_at}  {'VERIFIED' if e.verified else 'UNVERIFIED'}  {e.zip_path}  sha256 {e.zip_sha256}")

    def _current(self):
        rows = {i.row() for i in self.builds.selectedIndexes()}
        return self._recs[min(rows)] if rows and self._recs else None

    def _select(self) -> None:
        r = self._current()
        fill_table(self.artefacts, ["Artefact", "Kind", "Size", "SHA-256"], [[a.path, a.kind, a.size, a.sha256] for a in (r.artefacts if r else [])])

    def _export(self) -> None:
        from ..packaging.export import ExportBlocked

        r = self._current()
        if not r:
            return
        try:
            e = self.f.exports.export(r.build_id, allow_unverified=self.allow_unverified.isChecked())
        except ExportBlocked as exc:
            return self.win.notify(str(exc), "error")
        self.win.notify(f"Exported {Path(e.zip_path).name} (sha256 {e.zip_sha256[:16]}...).", "ok")
        self.refresh()


# ======================================================================= Activity
class ActivityPage(Page):
    title = "Activity"
    subtitle = "Imports, checkpoints, builds, proposals, permission changes and recovery events. Secrets are redacted before they are recorded."

    def __init__(self, win):
        super().__init__(win)
        self.only_project = QCheckBox("Only the selected project")
        self.only_project.toggled.connect(lambda _: self.refresh())
        self.root.addLayout(row_layout(self.only_project))
        self.table = QTableWidget()
        self.root.addWidget(self.table, 1)

    def refresh(self) -> None:
        pr = self.project()
        rows = self.f.db.activity(pr.id if (pr and self.only_project.isChecked()) else None, 500)
        fill_table(self.table, ["Time", "Kind", "Message"], [[r["ts"], r["kind"], r["message"]] for r in rows])


# ======================================================================= Settings
class SettingsPage(Page):
    title = "Settings"
    subtitle = "Application-controlled policy. Nothing inside an imported project can change these settings."

    def __init__(self, win):
        super().__init__(win)
        tabs = QTabWidget()
        # general / isolation
        g = QWidget()
        gl = QFormLayout(g)
        self.theme = QComboBox()
        self.theme.addItems(["dark", "light"])
        self.runtime = QComboBox()
        self.runtime.addItems(["auto", "docker", "podman", "none"])
        self.image = QLineEdit()
        self.qt_image = QLineEdit()
        self.index = QLineEdit()
        self.ca = QLineEdit()
        self.only_binary = QCheckBox("Binary distributions only during fetch (no package build scripts run with network)")
        self.cpus = QDoubleSpinBox(minimum=0.25, maximum=64, singleStep=0.25)
        self.mem = QSpinBox(minimum=64, maximum=65536, singleStep=256)
        self.pids = QSpinBox(minimum=16, maximum=8192)
        self.tmpfs = QSpinBox(minimum=16, maximum=16384, singleStep=128)
        self.outmb = QSpinBox(minimum=1, maximum=16384, singleStep=128)
        self.timeout = QSpinBox(minimum=10, maximum=7200, singleStep=30)
        self.published = QCheckBox("Published-port previews (needed where container IPs are unreachable; previews can then reach the network)")
        for label, w in (("Theme", self.theme), ("Container runtime", self.runtime), ("Python worker image", self.image), ("Qt worker image", self.qt_image), ("Package index", self.index), ("Registry CA bundle", self.ca), ("", self.only_binary), ("CPU limit", self.cpus), ("Memory (MB)", self.mem), ("Processes", self.pids), ("Scratch space (MB)", self.tmpfs), ("Output limit (MB)", self.outmb), ("Time limit (s)", self.timeout), ("", self.published)):
            gl.addRow(label, w)
        b_save = primary("Save settings")
        b_save.clicked.connect(self._save)
        gl.addRow("", b_save)
        tabs.addTab(g, "General and isolation")
        # isolation status
        iso = QWidget()
        il = QVBoxLayout(iso)
        self.iso_text = QPlainTextEdit()
        self.iso_text.setReadOnly(True)
        il.addWidget(self.iso_text)
        tabs.addTab(iso, "Isolation status")
        # project permissions + AI
        pw = QWidget()
        pl = QFormLayout(pw)
        self.net_grant = QCheckBox("Grant network access during execution for the selected project")
        self.net_grant.toggled.connect(self._grant)
        self.ai_provider = QComboBox()
        self.ai_provider.addItems(["offline", "anthropic"])
        self.ai_model = QLineEdit()
        self.ai_share = QCheckBox("Allow sending this project's files to the external AI provider")
        self.ai_share.toggled.connect(self._share)
        self.share_preview = QPlainTextEdit()
        self.share_preview.setReadOnly(True)
        pl.addRow("Execution network", self.net_grant)
        pl.addRow("AI provider", self.ai_provider)
        pl.addRow("AI model", self.ai_model)
        pl.addRow("External sharing", self.ai_share)
        pl.addRow("Share preview", self.share_preview)
        tabs.addTab(pw, "Project permissions and AI")
        # capability matrix
        cw = QWidget()
        cl = QVBoxLayout(cw)
        self.caps = QTableWidget()
        cl.addWidget(self.caps)
        cl.addWidget(muted("implemented = works end to end here; partial = works with stated limits; detected only = inspected, no build adapter; unsupported = not available."))
        tabs.addTab(cw, "Capability matrix")
        self.root.addWidget(tabs, 1)
        self._loading = False

    def refresh(self) -> None:
        from ..adapters.base import capability_matrix

        self._loading = True
        s = self.f.settings
        self.theme.setCurrentText(s.theme)
        self.runtime.setCurrentText(s.runtime)
        self.image.setText(s.python_image)
        self.qt_image.setText(s.qt_image)
        self.index.setText(s.registry.index_url)
        self.ca.setText(s.registry.ca_bundle or "")
        self.only_binary.setChecked(s.registry.only_binary)
        self.cpus.setValue(s.limits.cpus)
        self.mem.setValue(s.limits.memory_mb)
        self.pids.setValue(s.limits.pids)
        self.tmpfs.setValue(s.limits.tmpfs_mb)
        self.outmb.setValue(s.limits.output_mb)
        self.timeout.setValue(s.limits.timeout_s)
        self.published.setChecked(s.preview_published_ports)
        self.ai_provider.setCurrentText(s.ai.provider)
        self.ai_model.setText(s.ai.model)
        st = self.f.runtime.status()
        self.iso_text.setPlainText(
            f"Runtime: {st.name} {st.version}\nAvailable: {st.available}\n{('Reason: ' + st.reason) if st.reason else ''}\n\nLimitations:\n" + "\n".join(f"- {x}" for x in st.limitations)
            + "\n\nPolicy applied to every worker: no host-home mounts, no inherited host environment, read-only root and source, explicit writable output, CPU/memory/process/scratch/time limits, all capabilities dropped, no-new-privileges, unprivileged user, network disabled except the dependency-fetch stage. The engine socket is never mounted."
        )
        rows = [[r.project_type, r.adapter, r.detect.value, r.build.value, r.test.value, r.smoke.value, r.preview.value, r.package.value, r.outputs, r.notes] for r in capability_matrix()]
        fill_table(self.caps, ["Type", "Adapter", "Detect", "Build", "Test", "Smoke", "Preview", "Package", "Outputs", "Notes"], rows)
        pr = self.project()
        self.net_grant.setEnabled(pr is not None)
        self.ai_share.setEnabled(pr is not None)
        if pr:
            self.net_grant.setChecked(self.f.db.permissions(pr.id).get("execution_network", False))
            self.ai_share.setChecked(pr.ai_sharing)
            self._preview()
        self._loading = False

    def _preview(self) -> None:
        from ..ai.consent import build_share_preview

        pr = self.project()
        prev = build_share_preview(Path(pr.root), self.f.projects.inspect(pr), self.f.settings.ai.max_shared_bytes)
        lines = [f"{'WOULD SHARE' if pr.ai_sharing else 'Not shared (sharing disabled)'}:"]
        lines += [f"  {s.path} ({s.bytes} bytes{', ' + str(s.redactions) + ' secret(s) redacted' if s.redactions else ''})" for s in prev.files]
        lines += ["Excluded:"] + [f"  {p}: {r}" for p, r in prev.excluded]
        self.share_preview.setPlainText("\n".join(lines))

    def _grant(self, on: bool) -> None:
        if self._loading or not self.project():
            return
        if on and QMessageBox.question(self, "Grant network", "Allow this project's code to use the network during builds, tests and previews?") != QMessageBox.StandardButton.Yes:
            self._loading = True
            self.net_grant.setChecked(False)
            self._loading = False
            return
        self.f.projects.grant(self.project(), "execution_network", on)

    def _share(self, on: bool) -> None:
        if self._loading or not self.project():
            return
        self.f.projects.set_ai_sharing(self.project(), on)
        self.win.set_project(self.f.projects.get(self.project().id))
        self._preview()

    def _save(self) -> None:
        s = self.f.settings
        s.theme = self.theme.currentText()
        s.runtime = self.runtime.currentText()
        s.python_image = self.image.text().strip() or s.python_image
        s.qt_image = self.qt_image.text().strip() or s.qt_image
        try:
            s.registry.index_url = self.index.text().strip()
        except ValueError as exc:
            return self.win.notify(str(exc), "error")
        s.registry.ca_bundle = self.ca.text().strip() or None
        s.registry.only_binary = self.only_binary.isChecked()
        s.limits.cpus, s.limits.memory_mb, s.limits.pids = self.cpus.value(), self.mem.value(), self.pids.value()
        s.limits.tmpfs_mb, s.limits.output_mb, s.limits.timeout_s = self.tmpfs.value(), self.outmb.value(), self.timeout.value()
        s.preview_published_ports = self.published.isChecked()
        s.ai.provider = self.ai_provider.currentText()  # type: ignore[assignment]
        s.ai.model = self.ai_model.text().strip() or s.ai.model
        s.save()
        self.win.apply_theme()
        self.win.notify("Settings saved. Runtime changes apply after restarting Foundry.", "ok")
