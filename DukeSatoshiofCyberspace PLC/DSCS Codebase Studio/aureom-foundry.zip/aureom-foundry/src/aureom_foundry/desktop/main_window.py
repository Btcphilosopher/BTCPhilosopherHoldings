"""Main window: navigation, header (project, profile, environment, checkpoint), pages."""

from __future__ import annotations

from PySide6.QtCore import QThreadPool, QTimer
from PySide6.QtWidgets import (
    QDialog, QDialogButtonBox, QFrame, QHBoxLayout, QLabel, QListWidget, QMainWindow, QStackedWidget, QStatusBar,
    QVBoxLayout, QWidget,
)

from .. import APP_NAME
from .pages import (
    ActivityPage, BuildPage, DependenciesPage, EditorPage, ImportPage, PackagesPage, PreviewPage, ProjectsPage,
    SettingsPage, TestsPage,
)
from .theme import palette, stylesheet
from .widgets import DiffView, Worker, WorkerSignals, banner, h2, muted

NAV = ["Projects", "Import", "Editor", "Dependencies", "Preview", "Build", "Tests", "Packages", "Activity", "Settings"]


class MainWindow(QMainWindow):
    def __init__(self, foundry):
        super().__init__()
        self.foundry = foundry
        self.palette = palette(foundry.settings.theme)
        self._project = None
        self.pool = QThreadPool.globalInstance()
        self.bridge = WorkerSignals()  # cross-thread log streaming
        self.setWindowTitle(f"{APP_NAME} - Code to Application")
        self.resize(1360, 860)

        central = QWidget()
        outer = QHBoxLayout(central)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        # navigation
        navbox = QWidget()
        nl = QVBoxLayout(navbox)
        nl.setContentsMargins(0, 0, 0, 0)
        nl.setSpacing(0)
        brand = QFrame()
        brand.setObjectName("brand")
        bl = QVBoxLayout(brand)
        bl.setContentsMargins(18, 18, 18, 10)
        t = QLabel("AUREOM FOUNDRY")
        t.setObjectName("brandTitle")
        s = QLabel("CODE TO APPLICATION")
        s.setObjectName("brandSub")
        bl.addWidget(t)
        bl.addWidget(s)
        self.nav = QListWidget()
        self.nav.setObjectName("nav")
        self.nav.addItems(NAV)
        self.nav.setFixedWidth(232)
        brand.setFixedWidth(232)
        nl.addWidget(brand)
        nl.addWidget(self.nav, 1)
        outer.addWidget(navbox)
        # content
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(0)
        header = QFrame()
        header.setObjectName("header")
        hl = QHBoxLayout(header)
        hl.setContentsMargins(20, 10, 20, 10)
        self.chip_project = QLabel()
        self.chip_profile = QLabel()
        self.chip_env = QLabel()
        self.chip_cp = QLabel()
        for c in (self.chip_project, self.chip_profile, self.chip_env, self.chip_cp):
            c.setObjectName("chip")
            hl.addWidget(c)
        hl.addStretch(1)
        self.notice = QLabel("")
        self.notice.setWordWrap(True)
        self.notice.setMaximumWidth(520)
        hl.addWidget(self.notice)
        rl.addWidget(header)
        self.stack = QStackedWidget()
        rl.addWidget(self.stack, 1)
        outer.addWidget(right, 1)
        self.setCentralWidget(central)
        self.setStatusBar(QStatusBar())

        self.pages = {}
        for name, cls in zip(NAV, (ProjectsPage, ImportPage, EditorPage, DependenciesPage, PreviewPage, BuildPage, TestsPage, PackagesPage, ActivityPage, SettingsPage)):
            page = cls(self)
            self.pages[name] = page
            self.stack.addWidget(page)
        self.bridge.message.connect(self.pages["Build"].on_message)
        self.nav.currentRowChanged.connect(self._switch)
        self.apply_theme()
        projects = foundry.projects.list()
        if projects:
            self._project = projects[0]
        self.nav.setCurrentRow(1 if not projects else 0)
        self.refresh_header()
        rec = foundry.recovery
        if rec and rec.interrupted_builds:
            QTimer.singleShot(300, lambda: self.notify(f"Recovered after an unexpected stop: {len(rec.interrupted_builds)} build(s) marked INTERRUPTED (not successful); {len(rec.removed_containers)} abandoned worker(s) removed.", "warning"))
        if not foundry.runtime.status().available:
            QTimer.singleShot(400, lambda: self.notify("Isolation unavailable: inspection and editing work, but builds and previews of untrusted code are disabled.", "error"))

    # ---- state ------------------------------------------------------------
    def current_project(self):
        return self._project

    def set_project(self, project) -> None:
        self._project = project
        self.refresh_header()
        page = self.stack.currentWidget()
        if page is not None and page is not self.pages["Import"]:  # Import keeps its last result
            page.refresh()

    def go(self, name: str) -> None:
        row = NAV.index(name)
        if self.nav.currentRow() == row:
            self._switch(row)  # already showing: refresh it
        else:
            self.nav.setCurrentRow(row)

    def _switch(self, row: int) -> None:
        page = self.pages[NAV[row]]
        self.stack.setCurrentWidget(page)
        try:
            page.refresh()
        except Exception as exc:  # show, never hide
            self.notify(f"{exc.__class__.__name__}: {exc}", "error")

    def refresh_header(self) -> None:
        st = self.foundry.runtime.status()
        p = self._project
        self.chip_project.setText(f"Project: {p.name}  ({p.type})" if p else "Project: none selected")
        self.chip_profile.setText(f"Profile: {p.active_profile}" if p else "Profile: -")
        self.chip_env.setText(f"Environment: {st.name} {st.version} - isolated" if st.available else "Environment: NO ISOLATION - execution disabled")
        cp = self.foundry.projects.latest_checkpoint(p.id) if p else None
        self.chip_cp.setText(f"Checkpoint: {cp.commit_sha[:10]} ({cp.kind})" if cp else "Checkpoint: -")

    def apply_theme(self) -> None:
        self.palette = palette(self.foundry.settings.theme)
        self.setStyleSheet(stylesheet(self.palette))

    def notify(self, text: str, kind: str = "info") -> None:
        prefix = {"error": "ERROR", "warning": "WARNING", "ok": "OK", "info": "NOTE"}.get(kind, "NOTE")
        color = {"error": self.palette.error, "warning": self.palette.warning, "ok": self.palette.success}.get(kind, self.palette.info)
        self.notice.setText(f"<b style='color:{color}'>{prefix}</b> {text[:400]}")
        self.statusBar().showMessage(f"{prefix}: {text[:200]}", 15000)

    def run_bg(self, fn, on_done=None, on_fail=None, busy: str | None = None) -> None:
        w = Worker(fn)
        if busy:
            self.statusBar().showMessage(busy)
        if on_done:
            w.signals.done.connect(on_done)
        w.signals.done.connect(lambda _: self.statusBar().clearMessage() if busy else None)
        w.signals.failed.connect(on_fail or (lambda m: self.notify(m.splitlines()[0] if m else "failed", "error")))
        self.pool.start(w)

    # ---- review -------------------------------------------------------------
    def review_proposal(self, proposal) -> bool:
        """Show a proposal's diff; apply only on explicit approval. Returns True if applied."""

        dlg = QDialog(self)
        dlg.setWindowTitle(f"Review change - {proposal.title}")
        dlg.resize(900, 640)
        lay = QVBoxLayout(dlg)
        lay.addWidget(h2(proposal.title))
        lay.addWidget(muted(f"Source: {proposal.source}  |  Status: {proposal.status}  |  Files: {', '.join(proposal.files) or '-'}"))
        if proposal.shared_files:
            lay.addWidget(banner("Files shared with the external AI: " + ", ".join(proposal.shared_files), "info"))
        for v in proposal.violations:
            lay.addWidget(banner(v, "error"))
        exp = muted(proposal.explanation)
        lay.addWidget(exp)
        diff = DiffView(self.palette)
        diff.set_diff(proposal.diff or "(no diff)")
        lay.addWidget(diff, 1)
        lay.addWidget(muted("Applying creates a checkpoint first, then a commit for the change. Every applied change can be reverted."))
        buttons = QDialogButtonBox()
        apply_btn = buttons.addButton("Checkpoint and apply", QDialogButtonBox.ButtonRole.AcceptRole)
        apply_btn.setObjectName("primary")
        reject_btn = buttons.addButton("Reject", QDialogButtonBox.ButtonRole.DestructiveRole)
        buttons.addButton("Close", QDialogButtonBox.ButtonRole.RejectRole)
        apply_btn.setEnabled(proposal.status == "proposed")
        lay.addWidget(buttons)
        result = {"applied": False}

        def do_apply():
            try:
                p = self.foundry.proposals.apply(proposal.id)
                result["applied"] = True
                self.notify(f"Applied {p.id} as commit {p.applied_commit[:10]}.", "ok")
            except Exception as exc:
                self.notify(str(exc), "error")
            dlg.accept()

        def do_reject():
            self.foundry.proposals.reject(proposal.id)
            self.notify(f"Rejected {proposal.id}.", "info")
            dlg.reject()

        apply_btn.clicked.connect(do_apply)
        reject_btn.clicked.connect(do_reject)
        buttons.rejected.connect(dlg.reject)
        dlg.exec()
        if result["applied"]:
            self._project = self.foundry.projects.get(proposal.project_id)
            self.refresh_header()
        return result["applied"]
