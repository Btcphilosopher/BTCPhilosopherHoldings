"""Desktop entry point: ``aureom-foundry-desktop`` or ``aureom-foundry gui``."""

from __future__ import annotations

import sys


def main(argv: list[str] | None = None) -> int:
    try:
        from PySide6.QtWidgets import QApplication
    except ImportError:
        print("PySide6 is not installed. Install with: pip install 'aureom-foundry[desktop]'", file=sys.stderr)
        return 1
    from .. import APP_NAME
    from ..foundry import Foundry
    from .main_window import MainWindow

    app = QApplication.instance() or QApplication(argv or sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName("Aureom.AI")
    foundry = Foundry()
    win = MainWindow(foundry)
    win.show()
    code = app.exec()
    foundry.close()
    return code


if __name__ == "__main__":
    sys.exit(main())
