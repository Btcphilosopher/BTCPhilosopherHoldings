"""Aureom Foundry visual theme: midnight-navy navigation, ivory editor surfaces,
copper primary actions, cyan build progress, clearly labelled warnings/errors."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Palette:
    name: str
    nav: str
    nav_text: str
    nav_selected: str
    window: str
    surface: str
    editor: str
    editor_text: str
    text: str
    muted: str
    border: str
    copper: str
    copper_hover: str
    cyan: str
    warning: str
    error: str
    success: str
    info: str


LIGHT = Palette(
    name="light", nav="#0F1B33", nav_text="#D8DEEA", nav_selected="#1F3358", window="#F1ECE1", surface="#FFFFFF",
    editor="#FBF7EE", editor_text="#1D2330", text="#1D2330", muted="#5D6677", border="#D9D2C3", copper="#B5652B",
    copper_hover="#9A5422", cyan="#0FA3B8", warning="#9A6A00", error="#B3261E", success="#2E7D4F", info="#2F5C8F",
)
DARK = Palette(
    name="dark", nav="#0A1326", nav_text="#C9D2E3", nav_selected="#1B2C4D", window="#111A2C", surface="#17223A",
    editor="#1C2740", editor_text="#F3EDDF", text="#E9E4D8", muted="#9AA5B8", border="#2A3754", copper="#D0803F",
    copper_hover="#E0914F", cyan="#2CD3E8", warning="#F2B33D", error="#FF6B5E", success="#5BCB8A", info="#7FB0EA",
)


def palette(name: str) -> Palette:
    return DARK if name == "dark" else LIGHT


def stylesheet(p: Palette) -> str:
    return f"""
QMainWindow, QWidget#page {{ background: {p.window}; color: {p.text}; }}
QWidget {{ color: {p.text}; font-size: 13px; }}
QLabel#muted {{ color: {p.muted}; }}
QLabel#h1 {{ font-size: 22px; font-weight: 600; }}
QLabel#h2 {{ font-size: 15px; font-weight: 600; }}
QListWidget#nav {{ background: {p.nav}; color: {p.nav_text}; border: none; padding-top: 8px; font-size: 14px; outline: 0; }}
QListWidget#nav::item {{ padding: 10px 18px; border-left: 3px solid transparent; }}
QListWidget#nav::item:selected {{ background: {p.nav_selected}; color: #FFFFFF; border-left: 3px solid {p.copper}; }}
QListWidget#nav::item:hover {{ background: {p.nav_selected}; }}
QFrame#brand {{ background: {p.nav}; }}
QLabel#brandTitle {{ color: #F4EEDF; font-size: 15px; font-weight: 700; letter-spacing: 1px; }}
QLabel#brandSub {{ color: {p.copper}; font-size: 11px; letter-spacing: 1px; }}
QFrame#header {{ background: {p.surface}; border-bottom: 1px solid {p.border}; }}
QLabel#chip {{ background: {p.window}; border: 1px solid {p.border}; border-radius: 10px; padding: 3px 10px; color: {p.text}; }}
QFrame#card, QGroupBox {{ background: {p.surface}; border: 1px solid {p.border}; border-radius: 8px; }}
QGroupBox {{ margin-top: 14px; padding-top: 10px; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 10px; padding: 0 4px; color: {p.muted}; }}
QPlainTextEdit, QTextEdit, QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {{
    background: {p.editor}; color: {p.editor_text}; border: 1px solid {p.border}; border-radius: 6px; padding: 4px;
    selection-background-color: {p.cyan}; selection-color: #000000;
}}
QPlainTextEdit#code {{ font-family: "JetBrains Mono", "DejaVu Sans Mono", "Menlo", monospace; font-size: 13px; }}
QPlainTextEdit#log {{ font-family: "DejaVu Sans Mono", monospace; font-size: 12px; }}
QTreeWidget, QTableWidget, QListWidget {{ background: {p.surface}; color: {p.text}; border: 1px solid {p.border}; border-radius: 6px; alternate-background-color: {p.window}; }}
QHeaderView::section {{ background: {p.window}; color: {p.muted}; border: none; border-bottom: 1px solid {p.border}; padding: 4px 6px; }}
QPushButton {{ background: {p.surface}; color: {p.text}; border: 1px solid {p.border}; border-radius: 6px; padding: 6px 14px; }}
QPushButton:hover {{ border-color: {p.copper}; }}
QPushButton:disabled {{ color: {p.muted}; background: {p.window}; }}
QPushButton#primary {{ background: {p.copper}; color: #FFFFFF; border: 1px solid {p.copper}; font-weight: 600; }}
QPushButton#primary:hover {{ background: {p.copper_hover}; }}
QPushButton#primary:disabled {{ background: {p.border}; border-color: {p.border}; color: {p.muted}; }}
QPushButton#danger {{ color: {p.error}; }}
QProgressBar {{ background: {p.window}; border: 1px solid {p.border}; border-radius: 6px; text-align: center; height: 16px; color: {p.text}; }}
QProgressBar::chunk {{ background: {p.cyan}; border-radius: 5px; }}
QTabWidget::pane {{ border: 1px solid {p.border}; border-radius: 6px; background: {p.surface}; }}
QTabBar::tab {{ background: {p.window}; color: {p.muted}; padding: 6px 14px; border: 1px solid {p.border}; border-bottom: none; border-top-left-radius: 6px; border-top-right-radius: 6px; }}
QTabBar::tab:selected {{ background: {p.surface}; color: {p.text}; border-bottom: 2px solid {p.copper}; }}
QFrame#dropzone {{ background: {p.editor}; border: 2px dashed {p.copper}; border-radius: 14px; }}
QFrame#dropzone[hover="true"] {{ border-color: {p.cyan}; }}
QLabel#dropTitle {{ font-size: 24px; font-weight: 600; color: {p.editor_text}; }}
QLabel#dropSub {{ color: {p.muted}; font-size: 14px; }}
QLabel#banner_error {{ background: {p.error}; color: #FFFFFF; padding: 8px 12px; border-radius: 6px; font-weight: 600; }}
QLabel#banner_warning {{ background: {p.warning}; color: #000000; padding: 8px 12px; border-radius: 6px; font-weight: 600; }}
QLabel#banner_ok {{ background: {p.success}; color: #FFFFFF; padding: 8px 12px; border-radius: 6px; font-weight: 600; }}
QLabel#banner_info {{ background: {p.info}; color: #FFFFFF; padding: 8px 12px; border-radius: 6px; }}
QSplitter::handle {{ background: {p.border}; }}
QScrollBar:vertical {{ background: transparent; width: 10px; }}
QScrollBar::handle:vertical {{ background: {p.border}; border-radius: 5px; min-height: 24px; }}
"""


def severity_color(p: Palette, severity: str) -> str:
    return {"error": p.error, "warning": p.warning, "info": p.info, "passed": p.success, "ok": p.success}.get(severity, p.muted)


STATUS_LABEL = {
    "passed": "PASSED", "failed": "FAILED", "skipped": "SKIPPED", "timed_out": "TIMED OUT", "cancelled": "CANCELLED",
    "blocked": "BLOCKED", "unsupported": "UNSUPPORTED", "pending": "PENDING", "running": "RUNNING",
    "succeeded": "SUCCEEDED", "interrupted": "INTERRUPTED", "queued": "QUEUED",
}


def status_severity(status: str) -> str:
    if status in ("passed", "succeeded"):
        return "passed"
    if status in ("failed", "timed_out", "interrupted", "blocked"):
        return "error"
    if status in ("unsupported", "cancelled", "skipped"):
        return "warning"
    return "info"
