"""Reusable widgets: drop zone, code editor with line numbers and highlighting, logs, workers."""

from __future__ import annotations

import re
import traceback
from pathlib import Path
from typing import Callable

from PySide6.QtCore import QObject, QRect, QRunnable, QSize, Qt, Signal, Slot
from PySide6.QtGui import QColor, QFont, QPainter, QSyntaxHighlighter, QTextCharFormat
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QHeaderView, QLabel, QPlainTextEdit, QPushButton, QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget,
)

from .. import TAGLINE
from .theme import STATUS_LABEL, Palette, severity_color, status_severity


# ---------------------------------------------------------------- background work
class WorkerSignals(QObject):
    done = Signal(object)
    failed = Signal(str)
    message = Signal(str, str)  # channel, text


class Worker(QRunnable):
    """Runs ``fn(emit)`` on the thread pool; ``emit(channel, text)`` streams to the UI thread."""

    def __init__(self, fn: Callable, *args, **kwargs):
        super().__init__()
        self.fn, self.args, self.kwargs = fn, args, kwargs
        self.signals = WorkerSignals()
        self.setAutoDelete(True)

    @Slot()
    def run(self) -> None:
        try:
            result = self.fn(*self.args, **self.kwargs)
        except Exception as exc:  # surfaced to the UI, never swallowed
            self.signals.failed.emit(f"{exc.__class__.__name__}: {exc}\n\n{traceback.format_exc(limit=4)}")
        else:
            self.signals.done.emit(result)


# ---------------------------------------------------------------- drop zone
class DropZone(QFrame):
    dropped = Signal(list)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setObjectName("dropzone")
        self.setAcceptDrops(True)
        self.setMinimumHeight(210)
        lay = QVBoxLayout(self)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon = QLabel("⬇")
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon.setStyleSheet("font-size: 40px;")
        title = QLabel(TAGLINE.split(". ")[0] + ".")
        title.setObjectName("dropTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub = QLabel(TAGLINE.split(". ")[1])
        sub.setObjectName("dropTitle")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hint = QLabel("Folders, files, ZIP archives or local Git repositories. Nothing is executed during import.")
        hint.setObjectName("dropSub")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        for w in (icon, title, sub, hint):
            lay.addWidget(w)

    def _set_hover(self, on: bool) -> None:
        self.setProperty("hover", "true" if on else "false")
        self.style().unpolish(self)
        self.style().polish(self)

    def dragEnterEvent(self, e):  # noqa: N802 - Qt API
        if e.mimeData().hasUrls():
            e.acceptProposedAction()
            self._set_hover(True)

    def dragLeaveEvent(self, e):  # noqa: N802
        self._set_hover(False)

    def dropEvent(self, e):  # noqa: N802
        self._set_hover(False)
        paths = [Path(u.toLocalFile()) for u in e.mimeData().urls() if u.isLocalFile()]
        if paths:
            self.dropped.emit(paths)


# ---------------------------------------------------------------- code editor
class _LineArea(QWidget):
    def __init__(self, editor: "CodeEditor"):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self) -> QSize:  # noqa: N802
        return QSize(self.editor.line_area_width(), 0)

    def paintEvent(self, event):  # noqa: N802
        self.editor.paint_line_numbers(event)


class PythonHighlighter(QSyntaxHighlighter):
    KEYWORDS = r"\b(False|None|True|and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield)\b"

    def __init__(self, doc, p: Palette):
        super().__init__(doc)
        self.rules = []

        def fmt(color: str, bold: bool = False, italic: bool = False) -> QTextCharFormat:
            f = QTextCharFormat()
            f.setForeground(QColor(color))
            if bold:
                f.setFontWeight(QFont.Weight.Bold)
            f.setFontItalic(italic)
            return f

        self.rules = [
            (re.compile(self.KEYWORDS), fmt(p.copper, True)),
            (re.compile(r"\b(self|cls)\b"), fmt(p.info)),
            (re.compile(r"\b\d+(\.\d+)?\b"), fmt(p.cyan)),
            (re.compile(r"@\w+"), fmt(p.warning)),
            (re.compile(r"(\"[^\"\n]*\"|'[^'\n]*')"), fmt(p.success)),
            (re.compile(r"#[^\n]*"), fmt(p.muted, italic=True)),
        ]

    def highlightBlock(self, text: str) -> None:  # noqa: N802
        for pat, f in self.rules:
            for m in pat.finditer(text):
                self.setFormat(m.start(), m.end() - m.start(), f)


class CodeEditor(QPlainTextEdit):
    def __init__(self, palette: Palette):
        super().__init__()
        self.setObjectName("code")
        self.p = palette
        self.line_area = _LineArea(self)
        self.blockCountChanged.connect(lambda _: self._update_width())
        self.updateRequest.connect(self._update_area)
        self._update_width()
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.setTabStopDistance(self.fontMetrics().horizontalAdvance(" ") * 4)
        self.highlighter: PythonHighlighter | None = None

    def set_language(self, path: str) -> None:
        if self.highlighter:
            self.highlighter.setDocument(None)
            self.highlighter = None
        if path.endswith(".py"):
            self.highlighter = PythonHighlighter(self.document(), self.p)

    def line_area_width(self) -> int:
        digits = max(3, len(str(self.blockCount())))
        return 12 + self.fontMetrics().horizontalAdvance("9") * digits

    def _update_width(self) -> None:
        self.setViewportMargins(self.line_area_width(), 0, 0, 0)

    def _update_area(self, rect, dy) -> None:
        if dy:
            self.line_area.scroll(0, dy)
        else:
            self.line_area.update(0, rect.y(), self.line_area.width(), rect.height())

    def resizeEvent(self, e):  # noqa: N802
        super().resizeEvent(e)
        cr = self.contentsRect()
        self.line_area.setGeometry(QRect(cr.left(), cr.top(), self.line_area_width(), cr.height()))

    def paint_line_numbers(self, event) -> None:
        painter = QPainter(self.line_area)
        painter.fillRect(event.rect(), QColor(self.p.window))
        block = self.firstVisibleBlock()
        num = block.blockNumber()
        top = round(self.blockBoundingGeometry(block).translated(self.contentOffset()).top())
        bottom = top + round(self.blockBoundingRect(block).height())
        painter.setPen(QColor(self.p.muted))
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                painter.drawText(0, top, self.line_area.width() - 6, self.fontMetrics().height(), Qt.AlignmentFlag.AlignRight, str(num + 1))
            block = block.next()
            top = bottom
            bottom = top + round(self.blockBoundingRect(block).height())
            num += 1


# ---------------------------------------------------------------- misc
class LogView(QPlainTextEdit):
    def __init__(self, placeholder: str = ""):
        super().__init__()
        self.setObjectName("log")
        self.setReadOnly(True)
        self.setMaximumBlockCount(20000)
        self.setPlaceholderText(placeholder)

    def append_line(self, text: str) -> None:
        self.appendPlainText(text)


class DiffView(QTextEdit):
    def __init__(self, p: Palette):
        super().__init__()
        self.setReadOnly(True)
        self.setObjectName("code")
        self.p = p
        self.setStyleSheet('font-family: "DejaVu Sans Mono", monospace; font-size: 12px;')

    def set_diff(self, diff: str) -> None:
        import html

        out = []
        for line in diff.splitlines():
            esc = html.escape(line)
            if line.startswith("+") and not line.startswith("+++"):
                out.append(f'<span style="color:{self.p.success}">{esc}</span>')
            elif line.startswith("-") and not line.startswith("---"):
                out.append(f'<span style="color:{self.p.error}">{esc}</span>')
            elif line.startswith("@@"):
                out.append(f'<span style="color:{self.p.cyan}">{esc}</span>')
            elif line.startswith(("diff ", "---", "+++")):
                out.append(f'<b>{esc}</b>')
            else:
                out.append(esc)
        self.setHtml("<pre>" + "\n".join(out) + "</pre>")


def h1(text: str) -> QLabel:
    lab = QLabel(text)
    lab.setObjectName("h1")
    return lab


def h2(text: str) -> QLabel:
    lab = QLabel(text)
    lab.setObjectName("h2")
    return lab


def muted(text: str) -> QLabel:
    lab = QLabel(text)
    lab.setObjectName("muted")
    lab.setWordWrap(True)
    return lab


def primary(text: str) -> QPushButton:
    b = QPushButton(text)
    b.setObjectName("primary")
    return b


def banner(text: str, kind: str) -> QLabel:
    """kind: error | warning | ok | info. The text always carries an explicit label."""

    prefix = {"error": "ERROR", "warning": "WARNING", "ok": "OK", "info": "NOTE"}[kind]
    lab = QLabel(f"{prefix}: {text}")
    lab.setObjectName(f"banner_{kind}")
    lab.setWordWrap(True)
    return lab


def status_item(status: str, p: Palette) -> QTableWidgetItem:
    item = QTableWidgetItem(STATUS_LABEL.get(status, status.upper()))
    item.setForeground(QColor(severity_color(p, status_severity(status))))
    f = item.font()
    f.setBold(True)
    item.setFont(f)
    return item


def fill_table(table: QTableWidget, headers: list[str], rows: list[list], p: Palette | None = None, status_cols: tuple[int, ...] = ()) -> None:
    table.clear()
    table.setColumnCount(len(headers))
    table.setHorizontalHeaderLabels(headers)
    table.setRowCount(len(rows))
    for r, row in enumerate(rows):
        for c, val in enumerate(row):
            if p is not None and c in status_cols:
                table.setItem(r, c, status_item(str(val), p))
            else:
                item = QTableWidgetItem(str(val))
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                table.setItem(r, c, item)
    table.resizeColumnsToContents()
    hh = table.horizontalHeader()
    for c in range(len(headers) - 1):
        hh.setSectionResizeMode(c, QHeaderView.ResizeMode.Interactive)
    if headers:
        hh.setSectionResizeMode(len(headers) - 1, QHeaderView.ResizeMode.Stretch)
    table.verticalHeader().setVisible(False)
    table.setAlternatingRowColors(True)
    table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)


def row_layout(*widgets, stretch: bool = True) -> QHBoxLayout:
    lay = QHBoxLayout()
    for w in widgets:
        lay.addWidget(w)
    if stretch:
        lay.addStretch(1)
    return lay
