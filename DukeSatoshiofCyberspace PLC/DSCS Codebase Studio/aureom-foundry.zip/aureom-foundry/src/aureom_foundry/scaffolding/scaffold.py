"""Loose-code scaffolding.

Wraps supplied code in a minimal project (source layout, dependency
configuration, entry point, README with run instructions, build profile and a
configuration example). The result is a *proposal*: the user previews the diff
before anything is written, and it can be reverted like any other change.

Scaffolding never invents business logic. User code is moved verbatim; the
generated entry point only calls it. Information that cannot be inferred
safely (unknown distributions, ambiguous entry points) becomes a question.
"""

from __future__ import annotations

import ast
import os
import re
import sys
from pathlib import Path

import yaml
from pydantic import BaseModel, Field

from ..ai.actions import Operation
from ..inspection.python_analysis import analyse_python, distribution_for, third_party_imports
from ..inspection.report import inspect_project
from ..manifests.propose import safe_name
from ..projects.models import Project


class TemplateInfo(BaseModel):
    id: str
    label: str
    project_type: str
    adapter: str
    description: str
    code_slot: str = ""
    path: str


class ScaffoldPlan(BaseModel):
    template: str
    name: str
    package: str
    operations: list[Operation] = Field(default_factory=list)
    questions: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    skipped_existing: list[str] = Field(default_factory=list)


def templates_root() -> Path:
    env = os.environ.get("AUREOM_FOUNDRY_TEMPLATES")
    candidates = [Path(env)] if env else []
    candidates += [
        Path(__file__).resolve().parents[3] / "templates",  # source checkout
        Path(sys.prefix) / "share" / "aureom-foundry" / "templates",  # installed wheel (data-files)
    ]
    for c in candidates:
        if c.is_dir():
            return c
    raise FileNotFoundError("scaffolding templates not found; set AUREOM_FOUNDRY_TEMPLATES")


def list_templates() -> list[TemplateInfo]:
    out = []
    root = templates_root()
    for d in sorted(root.iterdir()):
        meta = d / "template.yaml"
        if meta.is_file():
            data = yaml.safe_load(meta.read_text("utf-8"))
            out.append(TemplateInfo(path=str(d), **{k: data[k] for k in ("id", "label", "project_type", "adapter", "description")}, code_slot=data.get("code_slot", "")))
    return out


def package_name(name: str) -> str:
    pkg = re.sub(r"[^a-z0-9_]", "_", name.lower().replace("-", "_")).strip("_") or "app"
    if pkg[0].isdigit():
        pkg = "app_" + pkg
    return pkg


def _render(text: str, values: dict[str, str]) -> str:
    return re.sub(r"\{\{(\w+)\}\}", lambda m: values.get(m.group(1), ""), text)


def _env_keys(code: str) -> list[str]:
    keys = re.findall(r"os\.(?:environ\.get|getenv)\(\s*[\"']([A-Z][A-Z0-9_]*)[\"']", code)
    keys += re.findall(r"os\.environ\[\s*[\"']([A-Z][A-Z0-9_]*)[\"']\s*\]", code)
    return sorted(set(keys))


class Scaffolder:
    def __init__(self, foundry):
        self.f = foundry

    def suggest_template(self, project: Project) -> tuple[str | None, list[str]]:
        rep = inspect_project(Path(project.root), self.f.settings)
        t = rep.detected_type.value
        mapping = {"python-cli": "python-cli", "python-fastapi": "web-api", "python-pyside6": "desktop-utility", "static-site": "static-site"}
        if t in mapping:
            return mapping[t], []
        py = [f.path for f in rep.files if f.path.endswith(".py")]
        if py:
            return None, ["Is this a command-line program, a desktop utility or a web API?"]
        return None, ["What kind of application should this become?"]

    def plan(self, project: Project, template_id: str, name: str | None = None, description: str = "") -> ScaffoldPlan:
        tpl = next((t for t in list_templates() if t.id == template_id), None)
        if tpl is None:
            raise KeyError(f"unknown template {template_id}")
        root = Path(project.root)
        name = safe_name(name or project.name).lower()
        pkg = package_name(name)
        plan = ScaffoldPlan(template=template_id, name=name, package=pkg)
        rep = inspect_project(root, self.f.settings)
        existing = {f.path for f in rep.files}
        loose_py = [f for f in sorted(existing) if f.endswith(".py") and "/" not in f]
        loose_html = [f for f in sorted(existing) if f.lower().endswith((".html", ".htm")) and "/" not in f]

        code = ""
        values = {"name": name, "package": pkg, "description": description or f"{name} (scaffolded by Aureom Foundry)"}
        questions: list[str] = []
        deps: list[str] = []

        if tpl.project_type.startswith("python"):
            if len(loose_py) > 1:
                questions.append(f"Several Python files were supplied ({', '.join(loose_py)}). Which one is the program? The others will stay as they are.")
            src_file = loose_py[0] if loose_py else None
            if src_file:
                code = (root / src_file).read_text("utf-8", "replace")
                facts = analyse_python(root, [src_file])
                for mod in sorted(third_party_imports(facts)):
                    dist = distribution_for(mod)
                    if dist:
                        deps.append(dist)
                    else:
                        questions.append(f"'{mod}' is imported. Which distribution provides it? (Foundry does not guess.)")
                slot = _render(tpl.code_slot, values)
                plan.operations.append(Operation(op="create_file", path=slot, content=code))
                plan.operations.append(Operation(op="delete_file", path=src_file))
                plan.notes.append(f"{src_file} is moved verbatim to {slot}.")
            else:
                plan.notes.append("No code was supplied; only the project structure is generated.")
            values["dependencies"] = ", ".join(f'"{d}"' for d in deps)
            base_deps = {"web-api": {"fastapi", "uvicorn"}, "desktop-utility": {"PySide6"}}.get(template_id, set())
            extra = [d for d in deps if d not in base_deps]
            values["extra_dependencies"] = "".join(f', "{d}"' for d in extra)
            keys = _env_keys(code)
            values["config_keys"] = "\n".join(f'{k} = ""' if template_id != "web-api" else f"{k}=" for k in keys) or "# (no settings detected)"
            values["config_notes"] = ("Detected environment settings: " + ", ".join(keys)) if keys else ""
            has_main = has_qapp = False
            fastapi_var = router_var = None
            window_cls = None
            if code:
                try:
                    tree = ast.parse(code)
                    has_main = any(isinstance(n, ast.FunctionDef) and n.name == "main" for n in tree.body)
                    for n in ast.walk(tree):
                        if isinstance(n, ast.Call):
                            fn = n.func
                            fname = fn.id if isinstance(fn, ast.Name) else getattr(fn, "attr", "")
                            if fname in ("QApplication", "QGuiApplication"):
                                has_qapp = True
                    for n in tree.body:
                        if isinstance(n, ast.Assign) and isinstance(n.value, ast.Call):
                            fn = n.value.func
                            fname = fn.id if isinstance(fn, ast.Name) else getattr(fn, "attr", "")
                            if fname == "FastAPI" and isinstance(n.targets[0], ast.Name):
                                fastapi_var = n.targets[0].id
                            if fname == "APIRouter" and isinstance(n.targets[0], ast.Name):
                                router_var = n.targets[0].id
                        if isinstance(n, ast.ClassDef) and "window" in n.name.lower():
                            window_cls = n.name
                except SyntaxError as exc:
                    questions.append(f"The supplied code has a syntax error (line {exc.lineno}); fix it before building.")
            values["smoke_args"] = '["--help"]' if "argparse" in code or "click" in code else "[]"
            if has_main:
                values["entry_call"] = "    from . import app\n\n    result = app.main()\n    return int(result) if isinstance(result, int) else 0"
            else:
                values["entry_call"] = f'    runpy.run_module("{pkg}.app", run_name="__main__")\n    return 0'
            if template_id == "web-api":
                if fastapi_var:
                    # The supplied code already defines the app: use it directly as main.py.
                    plan.operations = [o for o in plan.operations if o.op == "delete_file"]
                    plan.operations.append(Operation(op="create_file", path=f"src/{pkg}/main.py", content=code))
                    values["router_include"] = ""
                    plan.notes.append(f"The supplied code defines '{fastapi_var} = FastAPI()'; it becomes src/{pkg}/main.py unchanged.")
                    values["_app_var"] = fastapi_var
                elif router_var:
                    values["router_include"] = f"from .routes import {router_var}\n\napp.include_router({router_var})\n"
                else:
                    values["router_include"] = ""
                    if code:
                        questions.append("The supplied code defines no FastAPI app or APIRouter. How should it be exposed as endpoints?")
            if template_id == "desktop-utility":
                if has_qapp:
                    values["window_code"] = f'    import runpy\n\n    runpy.run_module("{pkg}.app", run_name="__main__")\n    return 0'
                elif window_cls:
                    values["window_code"] = f"    from .app import {window_cls}\n\n    window = {window_cls}()\n    window.show()"
                else:
                    values["window_code"] = "    from PySide6.QtWidgets import QLabel\n\n    window = QLabel(\"No window class was supplied.\")\n    window.show()"
                    if code:
                        questions.append("No window class or QApplication was found in the supplied code. Which widget should the app show?")
        values["open_questions"] = ("\n\nOpen questions:\n" + "\n".join(f"- {q}" for q in questions)) if questions else ""

        tdir = Path(tpl.path)
        for src in sorted(tdir.rglob("*")):
            if not src.is_file() or src.name == "template.yaml":
                continue
            rel = _render(src.relative_to(tdir).as_posix(), values)
            if template_id == "web-api" and values.get("_app_var") and rel == f"src/{pkg}/main.py":
                continue
            if template_id == "static-site" and loose_html and rel != "foundry.yaml" and rel != "README.md":
                continue  # keep the supplied site files; never overwrite or invent assets
            content = _render(src.read_text("utf-8"), values)
            if template_id == "web-api" and values.get("_app_var") and rel == "foundry.yaml":
                content = content.replace(f"{pkg}.main:app", f"{pkg}.main:{values['_app_var']}").replace("http_path: /health", "http_path: /openapi.json")
            if rel in existing:
                plan.skipped_existing.append(rel)
                continue
            plan.operations.append(Operation(op="create_file", path=rel, content=content))
        if template_id == "static-site" and loose_html and "index.html" not in existing:
            questions.append(f"No index.html was supplied. Which page is the home page ({', '.join(loose_html)})?")
        plan.questions = questions
        if plan.skipped_existing:
            plan.notes.append("Existing files are kept unchanged: " + ", ".join(plan.skipped_existing))
        return plan

    def propose(self, project: Project, template_id: str, name: str | None = None, description: str = ""):
        plan = self.plan(project, template_id, name, description)
        explanation = "\n".join(
            [f"Scaffold '{template_id}' for {plan.name} (package {plan.package})."]
            + plan.notes
            + ([f"Open question: {q}" for q in plan.questions])
        )
        prop = self.f.proposals.create(project, f"Scaffold {template_id}", explanation, plan.operations, source="scaffold", allow_delete=True)
        return plan, prop
