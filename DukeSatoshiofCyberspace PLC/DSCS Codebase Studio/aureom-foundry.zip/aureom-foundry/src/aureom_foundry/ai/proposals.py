"""Reviewable change proposals: propose -> review diff -> checkpoint -> apply -> revert."""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field

from ..inspection.report import inspect_project
from ..persistence.db import new_id, now
from ..projects.models import Project
from .actions import Operation, OperationRejected, build_changeset
from .guard import check

Status = Literal["proposed", "blocked", "applied", "rejected", "reverted", "stale"]


class Proposal(BaseModel):
    id: str
    project_id: str
    created_at: str
    source: str
    title: str
    explanation: str
    operations: list[Operation] = Field(default_factory=list)
    diff: str = ""
    files: list[str] = Field(default_factory=list)
    status: Status = "proposed"
    violations: list[str] = Field(default_factory=list)
    base_commit: str = ""
    diagnosis_signature: str = ""
    shared_files: list[str] = Field(default_factory=list)
    applied_commit: str = ""
    revert_commit: str = ""


class ProposalError(Exception):
    pass


class ProposalService:
    def __init__(self, foundry):
        self.f = foundry

    def _save(self, p: Proposal, insert: bool = False) -> None:
        if insert:
            self.f.db.execute("INSERT INTO proposals(id, project_id, created_at, status, doc) VALUES (?, ?, ?, ?, ?)", (p.id, p.project_id, p.created_at, p.status, p.model_dump_json()))
        else:
            self.f.db.execute("UPDATE proposals SET status = ?, doc = ? WHERE id = ?", (p.status, p.model_dump_json(), p.id))

    def get(self, proposal_id: str) -> Proposal:
        row = self.f.db.one("SELECT doc FROM proposals WHERE id = ?", (proposal_id,))
        if row is None:
            raise KeyError(proposal_id)
        return Proposal.model_validate_json(row["doc"])

    def list(self, project_id: str) -> list[Proposal]:
        return [Proposal.model_validate_json(r["doc"]) for r in self.f.db.query("SELECT doc FROM proposals WHERE project_id = ? ORDER BY created_at DESC, rowid DESC", (project_id,))]

    def create(
        self, project: Project, title: str, explanation: str, ops: list[Operation], *, source: str, signature: str = "",
        shared_files: list[str] | None = None, allow_delete: bool = False,
    ) -> Proposal:
        root = Path(project.root)
        repo = self.f.projects.repo(project)
        p = Proposal(
            id=new_id("prop"), project_id=project.id, created_at=now(), source=source, title=title[:200], explanation=explanation,
            operations=ops, base_commit=repo.head() or "", diagnosis_signature=signature, shared_files=shared_files or [],
        )
        try:
            cs = build_changeset(root, ops, allow_delete=allow_delete and source == "scaffold")
        except (OperationRejected, ValueError) as exc:
            p.status, p.violations = "blocked", [f"invalid operation: {exc}"]
            self._save(p, insert=True)
            return p
        p.diff, p.files = cs.diff, cs.paths
        if not cs.changes:
            p.status, p.violations = "blocked", ["the proposal makes no changes"]
        g = check(cs)
        if not g.ok:
            p.status, p.violations = "blocked", g.violations
        self._save(p, insert=True)
        self.f.db.log_activity("proposal", f"Proposal {p.id} ({source}): {title} [{p.status}]", project.id)
        return p

    def apply(self, proposal_id: str) -> Proposal:
        p = self.get(proposal_id)
        if p.status != "proposed":
            raise ProposalError(f"proposal is {p.status}; only reviewed 'proposed' changes can be applied")
        project = self.f.projects.get(p.project_id)
        repo = self.f.projects.repo(project)
        ok, msg = repo.apply_check(p.diff)
        if not ok:
            p.status = "stale"
            self._save(p)
            raise ProposalError(f"the project changed since this proposal was made: {msg[:300]}")
        before = self.f.projects.checkpoint(project, f"Before applying proposal {p.id}", "pre-apply")
        repo.apply(p.diff)
        cp = self.f.projects.checkpoint(project, f"Apply proposal {p.id}: {p.title}", "apply")
        self.f.db.execute(
            "INSERT INTO applied_changes(id, proposal_id, project_id, before_commit, after_commit, applied_at) VALUES (?, ?, ?, ?, ?, ?)",
            (new_id("chg"), p.id, project.id, before.commit_sha, cp.commit_sha, now()),
        )
        p.status, p.applied_commit = "applied", cp.commit_sha
        self._save(p)
        if p.source == "scaffold":
            self.f.projects.touch(project.id, needs_scaffold=False)
        self._refresh_type(project)
        return p

    def reject(self, proposal_id: str) -> Proposal:
        p = self.get(proposal_id)
        if p.status in ("proposed", "blocked", "stale"):
            p.status = "rejected"
            self._save(p)
        return p

    def revert(self, proposal_id: str) -> Proposal:
        p = self.get(proposal_id)
        if p.status != "applied":
            raise ProposalError(f"proposal is {p.status}; only applied proposals can be reverted")
        project = self.f.projects.get(p.project_id)
        repo = self.f.projects.repo(project)
        ok, msg = repo.apply_check(p.diff, reverse=True)
        if not ok:
            raise ProposalError(f"cannot revert cleanly; later changes touch the same lines: {msg[:300]}")
        self.f.projects.checkpoint(project, f"Before reverting proposal {p.id}", "pre-apply")
        repo.apply(p.diff, reverse=True)
        cp = self.f.projects.checkpoint(project, f"Revert proposal {p.id}: {p.title}", "revert")
        self.f.db.execute("UPDATE applied_changes SET reverted_at = ?, revert_commit = ? WHERE proposal_id = ?", (now(), cp.commit_sha, p.id))
        p.status, p.revert_commit = "reverted", cp.commit_sha
        self._save(p)
        return p

    def attempts_for(self, project_id: str, signature: str) -> int:
        return sum(1 for p in self.list(project_id) if signature and p.diagnosis_signature == signature)

    def _refresh_type(self, project: Project) -> None:
        rep = inspect_project(Path(project.root), self.f.settings)
        if rep.detected_type.value != project.type:
            self.f.projects.touch(project.id, type=rep.detected_type.value)
