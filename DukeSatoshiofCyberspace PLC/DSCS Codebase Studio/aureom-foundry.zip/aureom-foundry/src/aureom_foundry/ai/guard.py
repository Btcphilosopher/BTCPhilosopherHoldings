"""Guard against changes that make a build look green without fixing it.

Rejected patterns:

* deleting or emptying test files;
* removing assertions from tests;
* adding skip/xfail markers or ``pytest.skip`` calls;
* swallowing exceptions (``except ...: pass``) in new code;
* weakening Foundry's verification (smoke expectations, test path) or
  changing the permissions block in ``foundry.yaml``;
* shell-style error suppression (``|| true``, ``continue-on-error``).
"""

from __future__ import annotations

import re
from pathlib import PurePosixPath

from pydantic import BaseModel, Field

from .actions import ChangeSet


class GuardResult(BaseModel):
    ok: bool
    violations: list[str] = Field(default_factory=list)


def _is_test_path(path: str) -> bool:
    p = PurePosixPath(path)
    return any(part in ("tests", "test") for part in p.parts[:-1]) or p.name.startswith("test_") or p.name.endswith("_test.py") or p.name == "conftest.py"


_SKIP = re.compile(r"(pytest\.mark\.(skip|skipif|xfail)|pytest\.skip\(|pytest\.xfail\(|unittest\.skip|@skip\b)")
_SWALLOW = re.compile(r"except(\s+[\w.(), ]+)?\s*:\s*(pass|\.\.\.)\s*$")
_SHELL = re.compile(r"(\|\|\s*true|continue-on-error|--deselect|-p\s+no:|--no-verify)")


def check(cs: ChangeSet) -> GuardResult:
    v: list[str] = []
    for ch in cs.changes:
        before_lines = (ch.before or "").splitlines()
        after_lines = (ch.after or "").splitlines()
        removed = [ln for ln in before_lines if ln not in after_lines]
        added = [ln for ln in after_lines if ln not in before_lines]
        if _is_test_path(ch.path):
            if ch.before is not None and ch.after is None:
                v.append(f"{ch.path}: deletes a test file")
            elif ch.before is not None and not (ch.after or "").strip():
                v.append(f"{ch.path}: empties a test file")
            removed_asserts = [ln for ln in removed if re.search(r"\bassert\b|assertEqual|assertTrue|assertRaises|pytest\.raises", ln)]
            if removed_asserts:
                v.append(f"{ch.path}: removes {len(removed_asserts)} assertion(s)")
            if any(_SKIP.search(ln) for ln in added):
                v.append(f"{ch.path}: adds a skip/xfail marker")
            if any(re.match(r"\s*assert\s+(True|1)\s*$", ln) for ln in added):
                v.append(f"{ch.path}: adds a trivially true assertion")
        added_set = set(added)
        swallow = any(_SWALLOW.search(ln) for ln in added) or any(
            re.match(r"\s*except\b[^:]*:\s*$", a) and re.match(r"\s*(pass|\.\.\.)\s*$", b) and a in added_set and b in added_set
            for a, b in zip(after_lines, after_lines[1:])
        )
        if swallow:
            v.append(f"{ch.path}: adds an exception handler that silently discards errors")
        if any(_SHELL.search(ln) for ln in added):
            v.append(f"{ch.path}: adds error suppression")
        if PurePosixPath(ch.path).name == "foundry.yaml":
            # Permission entries are requests, but proposals may not add requests for access or
            # remove existing entries; a new manifest declaring `false` is fine.
            if any(re.match(r"\s*(network|host_filesystem)\s*:\s*true", ln, re.I) for ln in added) or (
                ch.before is not None and any(re.match(r"\s*(network|host_filesystem)\s*:", ln) for ln in removed)
            ):
                v.append("foundry.yaml: proposals may not change the permissions block")
            if any(re.match(r"\s*(expect_exit|expect_output|expect_status|http_path|path)\s*:", ln) for ln in removed):
                v.append("foundry.yaml: proposals may not weaken smoke or test expectations")
    return GuardResult(ok=not v, violations=v)
