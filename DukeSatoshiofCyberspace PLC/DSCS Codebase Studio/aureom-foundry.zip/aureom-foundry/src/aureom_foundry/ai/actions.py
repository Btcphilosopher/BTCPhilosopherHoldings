"""Bounded, validated change operations.

AI output (or a heuristic) never runs commands. It may only propose these
operations, which Foundry validates and converts into a unified diff for
review. There is deliberately no "run shell command" operation.
"""

from __future__ import annotations

import difflib
import re
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field, field_validator

from ..dependencies.parsers import normalise_name
from ..editor.buffers import PathRejected, resolve_inside

MAX_OPERATIONS = 20
MAX_CONTENT = 200_000


class Operation(BaseModel):
    op: Literal["edit_file", "create_file", "add_dependency", "delete_file"]
    path: str = ""
    content: str = ""
    name: str = ""  # add_dependency: distribution name
    specifier: str = ""
    kind: Literal["runtime", "dev", ""] = ""

    @field_validator("content")
    @classmethod
    def _size(cls, v: str) -> str:
        if len(v) > MAX_CONTENT:
            raise ValueError("content too large")
        return v

    @field_validator("name")
    @classmethod
    def _name(cls, v: str) -> str:
        if v and not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,99}", v):
            raise ValueError("invalid distribution name")
        return v

    @field_validator("specifier")
    @classmethod
    def _spec(cls, v: str) -> str:
        if v and not re.fullmatch(r"(?:(?:==|!=|~=|>=|<=|>|<)[A-Za-z0-9.*+!_-]+)(?:,(?:==|!=|~=|>=|<=|>|<)[A-Za-z0-9.*+!_-]+)*", v):
            raise ValueError("invalid version specifier")
        return v


class OperationRejected(ValueError):
    pass


class FileChange(BaseModel):
    path: str
    before: str | None
    after: str | None  # None = file deleted


class ChangeSet(BaseModel):
    changes: list[FileChange] = Field(default_factory=list)
    diff: str = ""

    @property
    def paths(self) -> list[str]:
        return [c.path for c in self.changes]


def _read(root: Path, rel: str) -> str | None:
    p = resolve_inside(root, rel)
    if not p.exists():
        return None
    data = p.read_bytes()
    if b"\x00" in data[:8192]:
        raise OperationRejected(f"{rel} is binary and cannot be edited")
    return data.decode("utf-8", "replace")


def add_dependency_text(get, name: str, specifier: str, kind: str) -> tuple[str, str | None, str]:
    """Return (path, before, after) adding a dependency to pyproject.toml or requirements.txt.

    ``get(rel)`` returns the current (possibly already-modified) text of a file, or None.
    """

    line = f"{name}{specifier}"
    pyproject = get("pyproject.toml")
    if pyproject is not None and "[project]" in pyproject:
        key = "dependencies" if kind != "dev" else None
        if key:
            m = re.search(r"(?ms)^\[project\][^\[]*?^dependencies\s*=\s*\[(.*?)\]", pyproject)
            if m:
                body = m.group(1)
                existing = re.findall(r"[\"']([A-Za-z0-9._-]+)", body)
                if normalise_name(name) in {normalise_name(e) for e in existing}:
                    raise OperationRejected(f"{name} is already declared")
                stripped = body.strip()
                if not stripped:
                    new_body = f'"{line}"'
                elif "\n" in body:
                    indent = re.search(r"\n(\s*)\S", body)
                    pad = indent.group(1) if indent else "    "
                    new_body = body.rstrip().rstrip(",") + f",\n{pad}\"{line}\",\n"
                else:
                    new_body = stripped.rstrip(",") + f', "{line}"'
                after = pyproject[: m.start(1)] + new_body + pyproject[m.end(1) :]
                return "pyproject.toml", pyproject, after
            # [project] without dependencies: insert after the [project] header block
            hm = re.search(r"(?m)^\[project\]\s*$", pyproject)
            assert hm
            insert_at = pyproject.find("\n", hm.end())
            after = pyproject[: insert_at + 1] + f'dependencies = ["{line}"]\n' + pyproject[insert_at + 1 :]
            return "pyproject.toml", pyproject, after
        m = re.search(r"(?ms)^\[project\.optional-dependencies\][^\[]*?^dev\s*=\s*\[(.*?)\]", pyproject)
        if m:
            body = m.group(1)
            new_body = (body.rstrip().rstrip(",") + f', "{line}"') if body.strip() else f'"{line}"'
            return "pyproject.toml", pyproject, pyproject[: m.start(1)] + new_body + pyproject[m.end(1) :]
    req_name = "requirements-dev.txt" if kind == "dev" else "requirements.txt"
    before = get(req_name)
    if before is not None and any(normalise_name(re.split(r"[<>=!~ ;\[]", ln.strip())[0]) == normalise_name(name) for ln in before.splitlines() if ln.strip() and not ln.startswith("#")):
        raise OperationRejected(f"{name} is already declared")
    after = (before or "")
    if after and not after.endswith("\n"):
        after += "\n"
    return req_name, before, after + line + "\n"


_DELETED = object()


def build_changeset(root: Path, ops: list[Operation], *, allow_delete: bool = False) -> ChangeSet:
    """Validate operations and render them as one unified diff.

    ``delete_file`` is only accepted from Foundry's own scaffolder (``allow_delete``);
    AI-sourced proposals can never delete files.
    """
    if len(ops) > MAX_OPERATIONS:
        raise OperationRejected(f"at most {MAX_OPERATIONS} operations per proposal")
    current: dict[str, str | None] = {}
    original: dict[str, str | None] = {}

    def get(rel: str) -> str | None:
        if rel not in current:
            original[rel] = current[rel] = _read(root, rel)
        return current[rel]

    for op in ops:
        try:
            if op.op in ("edit_file", "create_file"):
                if not op.path:
                    raise OperationRejected("path required")
                resolve_inside(root, op.path)
                existing = get(op.path)
                if op.op == "create_file" and existing is not None:
                    raise OperationRejected(f"{op.path} already exists; use edit_file")
                if op.op == "edit_file" and existing is None:
                    raise OperationRejected(f"{op.path} does not exist; use create_file")
                current[op.path] = op.content
            elif op.op == "delete_file":
                if not allow_delete:
                    raise OperationRejected("deleting files is not allowed in this proposal")
                if get(op.path) is None:
                    raise OperationRejected(f"{op.path} does not exist")
                current[op.path] = _DELETED  # type: ignore[assignment]
            elif op.op == "add_dependency":
                if not op.name:
                    raise OperationRejected("add_dependency needs a name")
                # applied against the in-progress content, so earlier operations are respected
                path, _, after = add_dependency_text(get, op.name, op.specifier, op.kind or "runtime")
                current[path] = after
        except PathRejected as exc:
            raise OperationRejected(str(exc)) from exc
    cs = ChangeSet()
    diffs = []
    for rel in sorted(current):
        before, after = original.get(rel), current[rel]
        deleted = after is _DELETED
        if after is None or before == after:
            continue
        cs.changes.append(FileChange(path=rel, before=before, after=None if deleted else after))
        a = (before or "").splitlines(keepends=True)
        b = [] if deleted else after.splitlines(keepends=True)
        if a and not a[-1].endswith("\n"):
            a[-1] += "\n\\ No newline at end of file\n"
        if b and not b[-1].endswith("\n"):
            b[-1] += "\n\\ No newline at end of file\n"
        fromfile = f"a/{rel}" if before is not None else "/dev/null"
        tofile = "/dev/null" if deleted else f"b/{rel}"
        diff = "".join(difflib.unified_diff(a, b, fromfile=fromfile, tofile=tofile))
        if deleted:
            diff = f"diff --git a/{rel} b/{rel}\ndeleted file mode 100644\n" + diff
        elif before is None:
            diff = f"diff --git a/{rel} b/{rel}\nnew file mode 100644\n" + diff
        else:
            diff = f"diff --git a/{rel} b/{rel}\n" + diff
        diffs.append(diff)
    cs.diff = "".join(diffs)
    return cs
