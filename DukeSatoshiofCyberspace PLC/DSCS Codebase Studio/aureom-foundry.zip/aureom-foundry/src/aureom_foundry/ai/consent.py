"""What would be shared with an external model, and with what redactions.

Nothing is sent unless the project has external AI sharing enabled. The share
preview lists every file that would be sent, how many secrets were redacted in
it, and every file excluded with the reason.
"""

from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, Field

from ..inspection.report import InspectionReport
from ..inspection.secrets import is_sensitive_filename, redact, scan_text


class SharedFile(BaseModel):
    path: str
    bytes: int
    redactions: int
    content: str = Field(default="", exclude=True, repr=False)


class SharePreview(BaseModel):
    files: list[SharedFile] = Field(default_factory=list)
    excluded: list[tuple[str, str]] = Field(default_factory=list)
    total_bytes: int = 0

    def payload(self) -> dict[str, str]:
        return {f.path: f.content for f in self.files}


PRIORITY = ("foundry.yaml", "pyproject.toml", "requirements.txt", "requirements-dev.txt", "package.json", "README.md")


def build_share_preview(root: Path, report: InspectionReport, max_bytes: int, focus: list[str] | None = None) -> SharePreview:
    prev = SharePreview()
    order: list[str] = []
    for p in (focus or []) + list(PRIORITY):
        if p and p not in order:
            order.append(p)
    for f in report.files:
        if f.path not in order:
            order.append(f.path)
    by_path = {f.path: f for f in report.files}
    for rel in order:
        entry = by_path.get(rel)
        if entry is None:
            continue
        if is_sensitive_filename(rel):
            prev.excluded.append((rel, "sensitive file name (never shared)"))
            continue
        if entry.binary:
            prev.excluded.append((rel, "binary file"))
            continue
        if entry.size > 200_000:
            prev.excluded.append((rel, "file larger than 200 KB"))
            continue
        if prev.total_bytes + entry.size > max_bytes:
            prev.excluded.append((rel, "share size limit reached"))
            continue
        text = (root / rel).read_text("utf-8", "replace")
        findings = scan_text(text, rel)
        content = redact(text) if findings else text
        prev.files.append(SharedFile(path=rel, bytes=len(content.encode()), redactions=len(findings), content=content))
        prev.total_bytes += len(content.encode())
    return prev
