"""Previews of built applications.

* CLI console: run the installed entry point with chosen arguments and stdin.
* Web preview: serve a static site or ASGI app from an isolated worker on an
  internal network, reachable only from this machine at its own origin.
* API explorer: list OpenAPI endpoints and send requests to the preview.
* Desktop: launch in the Qt worker image with the offscreen platform, where available.

Project output is kept separate from Foundry's own log lines.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field

from ..adapters.base import get_adapter
from ..adapters.python import FastAPIAdapter, PySide6Adapter, PythonPackageAdapter, install_project_steps
from ..adapters.static_site import StaticSiteAdapter
from ..isolation.commands import WorkerStep
from ..previews.server import PreviewSession, http_get, openapi_endpoints, wait_ready


@dataclass
class ConsoleResult:
    exit_code: int | None
    project_output: str
    foundry_log: list[str] = field(default_factory=list)
    timed_out: bool = False
    error: str = ""


class PreviewUnsupported(Exception):
    pass


class PreviewService:
    def __init__(self, foundry):
        self.f = foundry

    def run_cli(self, build_id: str, args: list[str], stdin: str | None = None, timeout_s: int = 60) -> ConsoleResult:
        flog: list[str] = []
        ctx = self.f.builds.context_for(build_id, emit=lambda ch, t: flog.append(t) if ch == "foundry" else None)
        adapter = get_adapter(ctx.record.adapter)
        if not isinstance(adapter, PythonPackageAdapter) or isinstance(adapter, (FastAPIAdapter,)):
            raise PreviewUnsupported("the console preview is for command-line programs")
        cmd = adapter.smoke_command(ctx)
        if not cmd:
            raise PreviewUnsupported("no entry point")
        if len(args) > 32 or any(len(a) > 1024 or "\x00" in a for a in args):
            raise ValueError("arguments too long")
        steps = [
            WorkerStep(name="stage source", kind="copytree", argv=["/src", "/work/src"]),
            *install_project_steps(ctx, ["runtime"]),
            WorkerStep(name="run entry point", argv=[*cmd, *args], cwd="/work/src", timeout_s=timeout_s, stdin=stdin, allow_fail=True),
        ]
        out: list[str] = []
        ctx.emit = lambda ch, t: (out.append(t) if ch == "project" else flog.append(t))
        res, wr = ctx.run_worker("console", steps, mount_artefacts=True)
        step = next((s for s in (wr.steps if wr else []) if s.name == "run entry point"), None)
        # Install output is Foundry's concern; show only the program's own output.
        program = wr.step_output.get(step.index, "") if (wr and step) else ""
        return ConsoleResult(
            exit_code=step.exit_code if step else res.exit_code,
            project_output=program,
            foundry_log=flog,
            timed_out=bool(step and step.timed_out),
            error="" if step else res.summary,
        )

    def start_web(self, build_id: str) -> PreviewSession:
        ctx = self.f.builds.context_for(build_id)
        adapter = get_adapter(ctx.record.adapter)
        if isinstance(adapter, StaticSiteAdapter):
            session = adapter._server(ctx)
            wait_ready(session, "/index.html", 200, timeout_s=30)
            return session
        if isinstance(adapter, FastAPIAdapter):
            from .server import start_server

            session = start_server(ctx.runtime, ctx.settings, ctx.image, adapter.server_steps(ctx), adapter.server_mounts(ctx), ctx.manifest.preview.port, kind="api")
            wait_ready(session, ctx.manifest.smoke.http_path, ctx.manifest.smoke.expect_status, timeout_s=90)
            return session
        raise PreviewUnsupported("web preview is available for static sites and FastAPI applications")

    def endpoints(self, session: PreviewSession) -> list[dict]:
        return openapi_endpoints(session)

    def request(self, session: PreviewSession, method: str, path: str, body: str | None = None) -> tuple[int, str]:
        if method not in {"GET", "POST", "PUT", "PATCH", "DELETE"} or not path.startswith("/"):
            raise ValueError("invalid request")
        data = body.encode() if body else None
        headers = {"Content-Type": "application/json"} if body else {}
        status, _, payload = http_get(session.handle.host, session.handle.port, path, method=method, body=data, headers=headers)
        text = payload.decode("utf-8", "replace")
        try:
            text = json.dumps(json.loads(text), indent=2)
        except ValueError:
            pass
        return status, text[:100_000]

    def desktop(self, build_id: str) -> str:
        ctx = self.f.builds.context_for(build_id)
        adapter = get_adapter(ctx.record.adapter)
        if not isinstance(adapter, PySide6Adapter):
            raise PreviewUnsupported("desktop preview is for PySide6 applications")
        res = adapter.smoke(ctx)
        return f"{res.status.value}: {res.summary}"
