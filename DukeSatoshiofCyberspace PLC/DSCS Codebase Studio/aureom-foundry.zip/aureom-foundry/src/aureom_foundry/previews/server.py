"""Long-running isolated previews (web servers, APIs) and real readiness checks.

A running container does not prove readiness. :func:`wait_ready` polls an HTTP
endpoint from the host and only reports ready when the expected status is
returned; it reports startup failure as soon as the container exits.
"""

from __future__ import annotations

import http.client
import json
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path

from ..config import FoundrySettings
from ..isolation.commands import WorkerStep
from ..isolation.policy import Mount, WorkerPolicy
from ..isolation.runtime import ContainerRuntime, PreviewHandle


@dataclass
class Readiness:
    ready: bool
    status: int | None = None
    elapsed_s: float = 0.0
    detail: str = ""
    body_excerpt: str = ""
    startup_failed: bool = False


@dataclass
class PreviewSession:
    handle: PreviewHandle
    kind: str  # web, api
    plan_root: Path
    readiness: Readiness | None = None
    notes: list[str] = field(default_factory=list)

    @property
    def url(self) -> str:
        return f"http://{self.handle.host}:{self.handle.port}"

    def logs(self) -> str:
        return self.handle.runtime.preview_logs(self.handle)  # type: ignore[attr-defined]

    def stop(self) -> None:
        self.handle.runtime.stop(self.handle.container)  # type: ignore[attr-defined]
        shutil.rmtree(self.plan_root / f"plan-{self.handle.container}", ignore_errors=True)


def start_server(
    runtime: ContainerRuntime,
    settings: FoundrySettings,
    image: str,
    steps: list[WorkerStep],
    mounts: list[Mount],
    port: int,
    kind: str = "web",
) -> PreviewSession:
    plan_root = settings.tmp_dir / "preview-plans"
    plan_root.mkdir(parents=True, exist_ok=True)
    policy = WorkerPolicy(network="preview", mounts=mounts, limits=settings.limits, label="preview")
    handle = runtime.start_preview(image, steps, policy, port, plan_root=plan_root, published=settings.preview_published_ports)  # type: ignore[attr-defined]
    s = PreviewSession(handle=handle, kind=kind, plan_root=plan_root)
    if settings.preview_published_ports:
        s.notes.append("Published-port mode: the preview container is on a bridge network and can reach external hosts.")
    else:
        s.notes.append("Preview runs on an internal network with no external route; it is reachable only from this machine.")
    return s


def http_get(host: str, port: int, path: str, timeout: float = 3.0, method: str = "GET", body: bytes | None = None, headers: dict | None = None) -> tuple[int, dict, bytes]:
    conn = http.client.HTTPConnection(host, port, timeout=timeout)
    try:
        conn.request(method, path, body=body, headers=headers or {})
        resp = conn.getresponse()
        data = resp.read(2_000_000)
        return resp.status, dict(resp.getheaders()), data
    finally:
        conn.close()


def wait_ready(session: PreviewSession, path: str = "/", expect_status: int = 200, timeout_s: float = 60) -> Readiness:
    start = time.monotonic()
    rt = session.handle.runtime
    last = ""
    while time.monotonic() - start < timeout_s:
        if not rt.preview_running(session.handle):  # type: ignore[attr-defined]
            r = Readiness(False, None, time.monotonic() - start, "the server process exited before becoming ready", startup_failed=True)
            session.readiness = r
            return r
        try:
            status, headers, body = http_get(session.handle.host, session.handle.port, path)
            if status == expect_status:
                excerpt = body[:400].decode("utf-8", "replace")
                r = Readiness(True, status, time.monotonic() - start, f"GET {path} returned {status}", excerpt)
                session.readiness = r
                return r
            last = f"GET {path} returned {status} (expected {expect_status})"
        except (OSError, http.client.HTTPException) as exc:
            last = f"not accepting connections yet ({exc.__class__.__name__})"
        time.sleep(0.5)
    r = Readiness(False, None, timeout_s, f"not ready after {timeout_s:.0f}s: {last}")
    session.readiness = r
    return r


def openapi_endpoints(session: PreviewSession) -> list[dict]:
    """List endpoints from the preview's OpenAPI document (API explorer)."""

    status, _, body = http_get(session.handle.host, session.handle.port, "/openapi.json")
    if status != 200:
        return []
    doc = json.loads(body)
    out = []
    for path, ops in (doc.get("paths") or {}).items():
        for method, op in ops.items():
            if method.lower() in {"get", "post", "put", "patch", "delete"}:
                out.append({"method": method.upper(), "path": path, "summary": op.get("summary", "")})
    return out
