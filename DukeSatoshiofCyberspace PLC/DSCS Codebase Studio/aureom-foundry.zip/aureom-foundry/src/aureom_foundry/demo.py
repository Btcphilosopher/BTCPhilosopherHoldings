"""Scripted, reproducible demonstration of the Foundry workflow.

Runs the 12-step walkthrough on the CSV-analysis CLI plus the three security
fixtures, and writes a Markdown + JSON report of what actually happened.
Every result in the report comes from a real run; nothing is simulated.
"""

from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import time
from pathlib import Path

from .builds.repair import RepairService
from .foundry import Foundry
from .manifests.effective import compute_effective
from .manifests.loader import load_manifest
from .projects.service import ImportFailed

FEATURE_PATCH_OLD = '''    t = sub.add_parser("top", help="print the rows with the largest values in a numeric column")'''
FEATURE_PATCH_NEW = '''    tb = sub.add_parser("table", help="pretty-print the file as a table")
    tb.add_argument("file", type=Path)

    t = sub.add_parser("top", help="print the rows with the largest values in a numeric column")'''
FEATURE_CMD_OLD = '''    elif args.command == "top":'''
FEATURE_CMD_NEW = '''    elif args.command == "table":
        from tabulate import tabulate

        print(tabulate([[r[c] for c in columns] for r in rows], headers=columns))
    elif args.command == "top":'''


class Report:
    def __init__(self) -> None:
        self.steps: list[dict] = []
        self.t0 = time.time()

    def step(self, n: str, title: str, ok: bool, detail: str, data: dict | None = None) -> None:
        mark = "PASS" if ok else "FAIL"
        print(f"\n[{mark}] {n}. {title}\n    " + detail.replace("\n", "\n    "), flush=True)
        self.steps.append({"step": n, "title": title, "ok": ok, "detail": detail, "data": data or {}})

    def write(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        md = ["# Aureom Foundry demonstration report", "", f"Duration: {time.time() - self.t0:.0f}s", ""]
        md.append("| # | Step | Result |\n| --- | --- | --- |")
        for s in self.steps:
            md.append(f"| {s['step']} | {s['title']} | {'PASS' if s['ok'] else 'FAIL'} |")
        md.append("")
        for s in self.steps:
            md += [f"## {s['step']}. {s['title']} - {'PASS' if s['ok'] else 'FAIL'}", "", "```", s["detail"], "```", ""]
        path.write_text("\n".join(md), "utf-8")
        path.with_suffix(".json").write_text(json.dumps(self.steps, indent=2, default=str), "utf-8")


def _examples_dir() -> Path:
    here = Path(__file__).resolve().parents[2] / "examples"
    return here


def run_demo(examples: Path | None = None, report_path: Path | None = None) -> int:
    ex = examples or _examples_dir()
    f = Foundry()
    rep = Report()
    st = f.runtime.status()
    print(f"isolation: {st.name} {st.version} available={st.available}")
    if not st.available:
        print(f"Isolation unavailable ({st.reason}). The demo needs a container runtime; inspection-only features still work.")
        return 2

    # 1. Drop in a project
    project, insp = f.projects.import_path(ex / "csv-analysis-cli", "csv-insight")
    rep.step("1", "Drop in a project", True, f"Imported {insp.files.__len__()} files into managed copy {project.root}\nproject id {project.id}")

    # 2. Inspect detected capabilities
    from .adapters.base import get_adapter

    cap = get_adapter(insp.manifest.build.adapter).capability() if insp.manifest else None
    rep.step(
        "2", "Inspect detected capabilities", insp.detected_type.value == "python-cli",
        f"type {insp.detected_type.value} ({'; '.join(insp.type_evidence)})\nentry points: "
        + ", ".join(f"{e.kind}:{e.target}" for e in insp.entry_points)
        + (f"\ncapability: build={cap.build.value} test={cap.test.value} smoke={cap.smoke.value} preview={cap.preview.value} outputs={cap.outputs}" if cap else "")
        + "\nissues: " + "; ".join(i.label() for i in insp.all_issues()),
    )

    # 3. Review dependencies
    d = insp.dependencies
    eff = compute_effective(insp.manifest, f.settings, f.db.permissions(project.id), st.name, st.available)
    rep.step(
        "3", "Review dependencies", not any(i.severity.value == "error" for i in d.issues),
        "declared: " + (", ".join(f"{r.name}{r.specifier} ({r.kind})" for r in d.requirements) or "none")
        + f"\nmanifests: {d.manifests}\n" + "\n".join(f"{k}: {v}" for k, v in eff.rows()),
    )

    # 4. Create a checkpoint
    cp = f.projects.checkpoint(project, "Demo: reviewed import")
    rep.step("4", "Create a checkpoint", bool(cp.commit_sha), f"checkpoint {cp.commit_sha}")

    # 5 + 6. Build in isolation, smoke check
    b1 = f.builds.run(project)
    stages = "\n".join(f"{s.name}: {s.status.value} - {s.summary}" for s in b1.stages)
    rep.step("5", "Build in isolation", b1.status.value == "succeeded", f"build {b1.build_id} {b1.status.value}\n{stages}\nlock: {b1.dependency_lock_reference}\ntoolchain: {b1.toolchain_versions}")
    rep.step("6", "Run a smoke check", b1.smoke_status.value == "passed", f"smoke: {b1.smoke_status.value}; tests: {b1.tests_status.value}; verified: {b1.verified}")

    # 7. Preview
    con = f.previews.run_cli(b1.build_id, ["top", "data/sample.csv", "--column", "revenue", "-n", "2"])
    rep.step("7", "Preview the application (console)", con.exit_code == 0, f"$ csv-insight top data/sample.csv --column revenue -n 2\n{con.project_output.strip()}\n[exit {con.exit_code}]")

    # 8. Introduce a missing dependency (a feature that imports tabulate, without declaring it)
    cli = Path(project.root) / "src" / "csv_insight" / "cli.py"
    text = cli.read_text("utf-8").replace(FEATURE_PATCH_OLD, FEATURE_PATCH_NEW).replace(FEATURE_CMD_OLD, FEATURE_CMD_NEW)
    cli.write_text(text, "utf-8")
    f.projects.checkpoint(project, "Add 'table' command using tabulate")
    insp2 = f.projects.inspect(project)
    flagged = [i for i in insp2.all_issues() if i.code == "undeclared-dependency"]
    manifest = load_manifest(Path(project.root))
    assert manifest is not None
    # Make the smoke check exercise the new command so the missing dependency is observable at runtime.
    yml = (Path(project.root) / "foundry.yaml").read_text("utf-8").replace('args: ["summary", "/work/src/data/sample.csv"]', 'args: ["table", "/work/src/data/sample.csv"]').replace('expect_output: "rows: 6"', 'expect_output: "revenue"')
    (Path(project.root) / "foundry.yaml").write_text(yml, "utf-8")
    f.projects.checkpoint(project, "Smoke-check the table command")
    b2 = f.builds.run(project)
    rep.step(
        "8", "Introduce a missing dependency", bool(flagged) and not b2.verified,
        "inspection: " + "; ".join(i.label() for i in flagged)
        + f"\nbuild {b2.build_id}: {b2.status.value}, tests {b2.tests_status.value}, smoke {b2.smoke_status.value}"
        + (f"\ndiagnosis: [{b2.diagnosis.category.value}] {b2.diagnosis.summary}" if b2.diagnosis else ""),
    )

    # 9. Review a proposed correction
    out = RepairService(f).propose(b2)
    prop = out.proposal
    rep.step("9", "Review a proposed correction", bool(prop and prop.status == "proposed"), f"{out.explanation}\n\n{prop.diff if prop else out.reason}")
    if not prop or prop.status != "proposed":
        return _finish(rep, report_path, f)

    # 10. Apply and rebuild
    applied = f.proposals.apply(prop.id)
    b3 = f.builds.run(project)
    rep.step(
        "10", "Apply and rebuild", b3.verified,
        f"applied {applied.id} as {applied.applied_commit[:12]}\nbuild {b3.build_id}: {b3.status.value}, tests {b3.tests_status.value}, smoke {b3.smoke_status.value}, verified {b3.verified}\n"
        + "\n".join(f"{s.name}: {s.status.value} - {s.summary}" for s in b3.stages),
    )

    # 11. Export a verified artefact and re-verify its checksums
    exp = f.exports.export(b3.build_id)
    bad = []
    for line in (Path(exp.path) / "CHECKSUMS.sha256").read_text().splitlines():
        digest, rel = line.split("  ", 1)
        if hashlib.sha256((Path(exp.path) / rel).read_bytes()).hexdigest() != digest:
            bad.append(rel)
    rep.step(
        "11", "Export a verified artefact", exp.verified and not bad,
        f"{exp.zip_path}\nsha256 {exp.zip_sha256}\nincluded: " + ", ".join(i["path"] for i in exp.included)
        + "\nexcluded: " + "; ".join(f"{x['path']} ({x['reason']})" for x in exp.excluded) + f"\nchecksum mismatches: {bad or 'none'}",
    )

    # 12. Revert the change
    rv = f.proposals.revert(prop.id)
    insp3 = f.projects.inspect(project)
    again = [i for i in insp3.all_issues() if i.code == "undeclared-dependency"]
    rep.step("12", "Revert the change", rv.status == "reverted" and bool(again), f"reverted with commit {rv.revert_commit[:12]}; inspection again reports: " + "; ".join(i.label() for i in again))

    # Security fixtures
    fx = ex / "fixtures"
    with tempfile.TemporaryDirectory() as td:
        sys.path.insert(0, str(fx))
        try:
            import make_malicious_zip  # type: ignore

            zpath = Path(td) / "malicious.zip"
            make_malicious_zip.build(str(zpath))
        finally:
            sys.path.pop(0)
        try:
            f.projects.import_path(zpath, "malicious")
            rep.step("S1", "Malicious archive is rejected", False, "archive was accepted!")
        except ImportFailed as exc:
            escaped = (f.settings.data_dir.parent / "escaped.txt").exists() or Path("/etc/foundry-absolute.txt").exists()
            rep.step("S1", "Malicious archive is rejected", not escaped, "rejected:\n" + "\n".join(exc.reasons) + f"\nfiles written outside staging: {'YES' if escaped else 'none'}")

    hang, _ = f.projects.import_path(fx / "hang-cli", "hang-cli")
    bh = f.builds.run(hang, "quick")
    leftover = [c for c in getattr(f.runtime, "list_foundry_containers", lambda: [])() if "smoke" in c]
    rep.step("S2", "Timed-out process is stopped", bh.smoke_status.value == "timed_out" and not leftover, f"smoke: {bh.smoke_status.value} - {bh.stage('smoke').summary if bh.stage('smoke') else ''}\nverified: {bh.verified}\nleftover worker containers: {leftover or 'none'}")

    ph, phi = f.projects.import_path(fx / "phone-home-cli", "phone-home-cli")
    eff = compute_effective(phi.manifest, f.settings, f.db.permissions(ph.id), st.name, st.available)
    bp = f.builds.run(ph, "quick")
    log = Path(bp.logs.get("smoke", "")).read_text("utf-8") if bp.logs.get("smoke") else ""
    secrets_line = next((ln for ln in log.splitlines() if "environment secrets visible" in ln), "")
    ok = (not eff.execution_network.allowed) and bp.diagnosis is not None and bp.diagnosis.category.value == "network-denied" and "sent!" not in log
    rep.step(
        "S3", "Unauthorised network request is blocked", ok,
        f"manifest requests network: {eff.execution_network.requested}; effective: {'ALLOWED' if eff.execution_network.allowed else 'DENIED'} ({eff.execution_network.reason})\n"
        f"host filesystem: {'ALLOWED' if eff.host_filesystem.allowed else 'DENIED'}\n"
        f"smoke: {bp.smoke_status.value}; diagnosis: {bp.diagnosis.category.value if bp.diagnosis else '-'} - {bp.diagnosis.summary if bp.diagnosis else ''}\n{secrets_line}",
    )
    return _finish(rep, report_path, f)


def _finish(rep: Report, report_path: Path | None, f: Foundry) -> int:
    path = report_path or (f.settings.data_dir / "demo-report.md")
    rep.write(path)
    failed = [s for s in rep.steps if not s["ok"]]
    print(f"\nreport: {path}\n{len(rep.steps) - len(failed)}/{len(rep.steps)} steps passed")
    return 0 if not failed else 1
