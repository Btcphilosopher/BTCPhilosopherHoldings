"""Application settings.

Settings are application-controlled policy. Nothing in an imported project can
change them. They are stored as JSON in the Foundry data directory and can be
overridden with a small set of ``AUREOM_FOUNDRY_*`` environment variables
(useful for CI and the demonstration script).
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


def default_data_dir() -> Path:
    env = os.environ.get("AUREOM_FOUNDRY_HOME")
    if env:
        return Path(env).expanduser().resolve()
    xdg = os.environ.get("XDG_DATA_HOME")
    base = Path(xdg) if xdg else Path.home() / ".local" / "share"
    return (base / "aureom-foundry").resolve()


class ResourceLimits(BaseModel):
    """Per-worker resource ceilings applied by the container runtime."""

    cpus: float = Field(1.0, gt=0, le=64)
    memory_mb: int = Field(1024, ge=64, le=65536)
    pids: int = Field(256, ge=16, le=8192)
    tmpfs_mb: int = Field(512, ge=16, le=16384)
    output_mb: int = Field(512, ge=1, le=16384)
    timeout_s: int = Field(600, ge=1, le=7200)
    log_bytes: int = Field(2_000_000, ge=10_000, le=100_000_000)
    nofile: int = Field(1024, ge=64, le=65536)


class ImportLimits(BaseModel):
    max_files: int = Field(5000, ge=1)
    max_total_mb: int = Field(200, ge=1)
    max_file_mb: int = Field(25, ge=1)
    max_compression_ratio: float = Field(100.0, ge=1)
    max_path_depth: int = Field(32, ge=1)


class RegistrySettings(BaseModel):
    """Package registry configuration used only during the dependency-fetch stage."""

    model_config = ConfigDict(validate_assignment=True)

    index_url: str = "https://pypi.org/simple"
    ca_bundle: str | None = None  # host path, mounted read-only into fetch workers
    only_binary: bool = True  # never run sdist build scripts while network is enabled

    @field_validator("index_url")
    @classmethod
    def _https(cls, v: str) -> str:
        if not v.startswith("https://"):
            raise ValueError("package index must use https://")
        return v


class AISettings(BaseModel):
    provider: Literal["offline", "anthropic"] = "offline"
    model: str = "claude-opus-5-5"
    effort: Literal["low", "medium", "high", "xhigh", "max"] = "high"
    max_shared_bytes: int = 200_000


class FoundrySettings(BaseModel):
    schema_version: int = 1
    data_dir: Path = Field(default_factory=default_data_dir)
    runtime: Literal["auto", "docker", "podman", "none"] = "auto"
    python_image: str = "python:3.12-slim"
    qt_image: str = "aureom-foundry/worker-python-qt:1"
    theme: Literal["light", "dark"] = "dark"
    limits: ResourceLimits = Field(default_factory=ResourceLimits)
    import_limits: ImportLimits = Field(default_factory=ImportLimits)
    registry: RegistrySettings = Field(default_factory=RegistrySettings)
    ai: AISettings = Field(default_factory=AISettings)
    preview_published_ports: bool = False  # opt-in for platforms where container IPs are unreachable
    max_repair_attempts: int = Field(3, ge=1, le=10)

    # ---- derived paths -------------------------------------------------
    @property
    def projects_dir(self) -> Path:
        return self.data_dir / "projects"

    @property
    def builds_dir(self) -> Path:
        return self.data_dir / "builds"

    @property
    def exports_dir(self) -> Path:
        return self.data_dir / "exports"

    @property
    def tmp_dir(self) -> Path:
        return self.data_dir / "tmp"

    @property
    def db_path(self) -> Path:
        return self.data_dir / "foundry.sqlite3"

    def ensure_dirs(self) -> None:
        for p in (self.data_dir, self.projects_dir, self.builds_dir, self.exports_dir, self.tmp_dir):
            p.mkdir(parents=True, exist_ok=True)

    # ---- persistence -----------------------------------------------------
    @classmethod
    def load(cls, data_dir: Path | None = None) -> "FoundrySettings":
        data_dir = (data_dir or default_data_dir()).resolve()
        path = data_dir / "settings.json"
        raw: dict = {}
        if path.exists():
            try:
                raw = json.loads(path.read_text("utf-8"))
            except (OSError, json.JSONDecodeError):
                raw = {}
        raw["data_dir"] = str(data_dir)
        settings = cls.model_validate(raw)
        settings._apply_env()
        settings.ensure_dirs()
        return settings

    def save(self) -> None:
        self.ensure_dirs()
        data = self.model_dump(mode="json")
        (self.data_dir / "settings.json").write_text(json.dumps(data, indent=2), "utf-8")

    def _apply_env(self) -> None:
        env = os.environ
        if v := env.get("AUREOM_FOUNDRY_RUNTIME"):
            self.runtime = v  # type: ignore[assignment]
        if v := env.get("AUREOM_FOUNDRY_PYTHON_IMAGE"):
            self.python_image = v
        if v := env.get("AUREOM_FOUNDRY_REGISTRY_CA"):
            self.registry.ca_bundle = v
        if v := env.get("AUREOM_FOUNDRY_INDEX_URL"):
            self.registry.index_url = v
