"""Build records. A build is never reported successful unless its stages actually passed."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class StageStatus(str, Enum):
    pending = "pending"
    running = "running"
    passed = "passed"
    failed = "failed"
    skipped = "skipped"
    timed_out = "timed_out"
    cancelled = "cancelled"
    blocked = "blocked"
    unsupported = "unsupported"


class BuildStatus(str, Enum):
    queued = "queued"
    running = "running"
    succeeded = "succeeded"  # packaging stage produced artefacts
    failed = "failed"
    cancelled = "cancelled"
    timed_out = "timed_out"
    interrupted = "interrupted"  # set by crash recovery - never success
    blocked = "blocked"  # isolation unavailable or policy denied


TERMINAL = {BuildStatus.succeeded, BuildStatus.failed, BuildStatus.cancelled, BuildStatus.timed_out, BuildStatus.interrupted, BuildStatus.blocked}


class ErrorCategory(str, Enum):
    syntax = "syntax"
    missing_dependency = "missing-dependency"
    invalid_entry_point = "invalid-entry-point"
    configuration = "configuration"
    compiler_failure = "compiler-failure"
    runtime_exception = "runtime-exception"
    test_failure = "test-failure"
    packaging_failure = "packaging-failure"
    network_denied = "network-denied"
    timeout = "timeout"
    resource_limit = "resource-limit"
    isolation = "isolation"
    unknown = "unknown"


class Diagnosis(BaseModel):
    category: ErrorCategory
    summary: str
    stage: str
    evidence: list[str] = Field(default_factory=list)  # redacted excerpt lines
    module: str | None = None  # missing import name, when known
    path: str | None = None
    line: int | None = None
    signature: str = ""  # stable key for bounding repair attempts


class StageResult(BaseModel):
    name: str
    status: StageStatus
    exit_code: int | None = None
    duration_s: float = 0.0
    summary: str = ""
    log_path: str | None = None
    diagnosis: Diagnosis | None = None
    details: dict = Field(default_factory=dict)


class TestCase(BaseModel):
    __test__ = False  # not a pytest class
    name: str
    classname: str = ""
    outcome: str  # passed, failed, error, skipped
    message: str = ""
    duration_s: float = 0.0


class TestReport(BaseModel):
    __test__ = False
    framework: str = "pytest"
    total: int = 0
    passed: int = 0
    failed: int = 0
    errors: int = 0
    skipped: int = 0
    cases: list[TestCase] = Field(default_factory=list)
    status: StageStatus = StageStatus.skipped
    note: str = ""


class Artefact(BaseModel):
    path: str  # relative to the build's artefact directory
    sha256: str
    size: int
    kind: str  # wheel, sdist, container-image, static-site, executable, lock


class BuildRecord(BaseModel):
    build_id: str
    project_id: str
    project_name: str
    project_type: str
    adapter: str
    source_checkpoint: str
    source_hash: str
    manifest_version: int
    toolchain_versions: dict[str, str] = Field(default_factory=dict)
    dependency_lock_reference: str | None = None
    build_profile: str
    started_at: str
    completed_at: str | None = None
    status: BuildStatus = BuildStatus.queued
    tests_status: StageStatus = StageStatus.pending
    smoke_status: StageStatus = StageStatus.pending
    logs: dict[str, str] = Field(default_factory=dict)  # stage -> log file path
    artefact_hashes: dict[str, str] = Field(default_factory=dict)
    artefacts: list[Artefact] = Field(default_factory=list)
    stages: list[StageResult] = Field(default_factory=list)
    tests: TestReport | None = None
    diagnosis: Diagnosis | None = None
    isolation: str = ""
    worker_image: str = ""
    worker_image_id: str = ""
    notes: list[str] = Field(default_factory=list)

    @property
    def verified(self) -> bool:
        """Build, tests and smoke check all passed (tests may be legitimately absent)."""

        return (
            self.status == BuildStatus.succeeded
            and self.smoke_status == StageStatus.passed
            and self.tests_status in (StageStatus.passed, StageStatus.skipped)
            and (self.tests is None or self.tests.failed + self.tests.errors == 0)
        )

    def stage(self, name: str) -> StageResult | None:
        return next((s for s in self.stages if s.name == name), None)
