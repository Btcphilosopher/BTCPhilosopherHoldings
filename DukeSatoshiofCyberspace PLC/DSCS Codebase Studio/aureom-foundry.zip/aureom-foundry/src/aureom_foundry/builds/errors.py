"""Classify build, test and runtime failures from captured output.

Classification is evidence-based: when no rule matches, the category is
``unknown`` and the repair workflow stops rather than guessing.
"""

from __future__ import annotations

import hashlib
import re

from ..inspection.secrets import redact
from .models import Diagnosis, ErrorCategory

_RULES: list[tuple[ErrorCategory, re.Pattern[str], str]] = [
    (ErrorCategory.configuration, re.compile(r"(CERTIFICATE_VERIFY_FAILED|certificate verify failed|There was a problem confirming the ssl certificate|ProxyError|407 Proxy Authentication)", re.I), "The package registry could not be reached securely. Check Settings > Registry (index URL and CA bundle)."),
    (ErrorCategory.network_denied, re.compile(r"(Network is unreachable|Temporary failure in name resolution|Name or service not known|\[Errno -3\]|\[Errno 101\])"), "The program attempted a network connection; workers have no network unless it is granted."),
    (ErrorCategory.missing_dependency, re.compile(r"ModuleNotFoundError: No module named '([\w.]+)'"), "A module could not be imported."),
    (ErrorCategory.missing_dependency, re.compile(r"ImportError: cannot import name|ImportError: No module named ([\w.]+)"), "An import failed."),
    (ErrorCategory.missing_dependency, re.compile(r"(No matching distribution found for [^\s]+|Could not find a version that satisfies the requirement [^\s]+)"), "A declared dependency could not be resolved from the configured registry."),
    (ErrorCategory.syntax, re.compile(r"(SyntaxError|IndentationError|TabError): (.+)"), "Python could not parse a source file."),
    (ErrorCategory.invalid_entry_point, re.compile(r"(Error loading ASGI app|Attribute \"\w+\" not found in module|can't open file|No module named [\w.]+\.__main__|is a package and cannot be directly executed|could not start /work/venv/bin/)"), "The configured entry point does not exist or cannot be started."),
    (ErrorCategory.compiler_failure, re.compile(r"(error: command '[^']*(gcc|cc|clang|g\+\+)[^']*' failed|Failed building wheel|fatal error: [\w./]+\.h: No such file)"), "A native extension failed to compile."),
    (ErrorCategory.packaging_failure, re.compile(r"(ERROR Backend subprocess exited|Python shared library .* was not found|ERROR Missing dependencies|error: Multiple top-level packages discovered|BackendUnavailable|ERROR Source .* does not appear to be a Python project|invalid pyproject.toml|configuration error: `project)"), "The package could not be built."),
    (ErrorCategory.configuration, re.compile(r"(tomllib\.TOMLDecodeError|ValidationError|Invalid configuration|manifest)", re.I), "Configuration is invalid."),
    (ErrorCategory.resource_limit, re.compile(r"(MemoryError|Killed|exit code 137|OSError: \[Errno 28\] No space left on device|BlockingIOError: \[Errno 11\] Resource temporarily unavailable)"), "A resource limit was reached."),
    (ErrorCategory.runtime_exception, re.compile(r"Traceback \(most recent call last\):"), "The program raised an exception."),
]

_FILE_LINE = re.compile(r'File "([^"]+)", line (\d+)')


def classify(output: str, stage: str, *, timed_out: bool = False, exit_code: int | None = None, test_failures: int = 0) -> Diagnosis:
    text = output[-200_000:]
    if timed_out:
        return _diag(ErrorCategory.timeout, f"The {stage} stage exceeded its time limit and was stopped.", stage, text)
    if test_failures:
        # Tests ran and failed. If the failure is really a missing module or a syntax error,
        # report that root cause (it is what a repair must address); otherwise it is a test failure.
        root = classify(text, stage)
        if root.category in (ErrorCategory.missing_dependency, ErrorCategory.syntax):
            root.summary = f"{test_failures} test(s) failed: {root.summary}"
            return root
        return _diag(ErrorCategory.test_failure, f"{test_failures} test(s) failed.", stage, text)
    for cat, pat, summary in _RULES:
        m = pat.search(text)
        if m:
            d = _diag(cat, summary, stage, text, anchor=m.start())
            if cat == ErrorCategory.missing_dependency and m.groups() and m.group(1) and "No module named" in m.group(0):
                d.module = m.group(1).split(".")[0]
                d.summary = f"Module '{d.module}' is not installed in the isolated environment."
            if cat == ErrorCategory.syntax:
                d.summary = f"{m.group(1)}: {m.group(2)[:200]}"
            d.signature = _signature(d)
            return d
    if exit_code == 137:
        return _diag(ErrorCategory.resource_limit, "The worker was killed (likely the memory limit).", stage, text)
    return _diag(ErrorCategory.unknown, f"The {stage} stage failed (exit code {exit_code}). The output does not identify a known cause.", stage, text)


def _diag(cat: ErrorCategory, summary: str, stage: str, text: str, anchor: int | None = None) -> Diagnosis:
    lines = text.splitlines()
    if anchor is not None:
        line_no = text[:anchor].count("\n")
        excerpt = lines[max(0, line_no - 12) : line_no + 6]
    else:
        excerpt = lines[-18:]
    excerpt = [redact(ln)[:400] for ln in excerpt]
    path = line = None
    for ln in reversed(excerpt):
        m = _FILE_LINE.search(ln)
        if m and "/work/venv/" not in m.group(1) and "/usr/local/lib" not in m.group(1):
            path = m.group(1).replace("/work/src/", "")
            line = int(m.group(2))
            break
    d = Diagnosis(category=cat, summary=summary, stage=stage, evidence=excerpt, path=path, line=line)
    d.signature = _signature(d)
    return d


def _signature(d: Diagnosis) -> str:
    raw = f"{d.category.value}|{d.stage}|{d.module or ''}|{d.path or ''}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]
