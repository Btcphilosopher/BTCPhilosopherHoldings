"""Build orchestration.

checkpoint -> stage exact checkpoint tree -> fetch (registry network) ->
build (no network) -> test (no network) -> smoke (no network / internal preview
network) -> package -> hash artefacts -> persist record.

The build status reflects packaging only. Test and smoke results are recorded
separately; :attr:`BuildRecord.verified` requires all three.
"""

from __future__ import annotations

import json
import shutil
import threading
import traceback
from pathlib import Path
from typing import Callable

from .. import __version__
from ..adapters.base import BuildContext, get_adapter, sha256_file
from ..config import FoundrySettings
from ..inspection.report import inspect_project, list_project_files, tree_hash, FileEntry, _sha256
from ..inspection.secrets import redact
from ..isolation.commands import WorkerStep
from ..isolation.policy import WorkerPolicy
from ..isolation.process import CancellationToken, run_process
from ..isolation.runtime import ContainerRuntime
from ..manifests.loader import ManifestError, load_manifest
from ..persistence.db import Database, new_id, now
from ..projects.models import BuildProfile, Project
from ..projects.service import ProjectService
from .models import Artefact, BuildRecord, BuildStatus, Diagnosis, ErrorCategory, StageResult, StageStatus

Emit = Callable[[str, str], None]


def _noop(channel: str, text: str) -> None:
    pass


class BuildService:
    def __init__(self, settings: FoundrySettings, db: Database, projects: ProjectService, runtime: ContainerRuntime):
        self.settings = settings
        self.db = db
        self.projects = projects
        self.runtime = runtime
        self._active: dict[str, CancellationToken] = {}
        self._lock = threading.Lock()

    # ---- profiles ---------------------------------------------------------
    def profiles(self, project: Project) -> list[BuildProfile]:
        rows = self.db.query("SELECT doc FROM build_profiles WHERE project_id = ? ORDER BY name", (project.id,))
        profiles = [BuildProfile.model_validate_json(r["doc"]) for r in rows]
        if not any(p.name == "local-release" for p in profiles):
            profiles.insert(0, BuildProfile())
        if not any(p.name == "quick" for p in profiles):
            profiles.append(BuildProfile(name="quick", run_tests=False, smoke_check=True, description="Build + smoke check, no tests"))
        if project.type == "python-pyside6" and not any(p.name == "desktop-executable" for p in profiles):
            profiles.append(BuildProfile(name="desktop-executable", desktop_executable=True, description="Wheel + Linux desktop executable (PyInstaller, Qt worker image)"))
        if project.type == "python-fastapi" and not any(p.name == "container-image" for p in profiles):
            profiles.append(BuildProfile(name="container-image", package_container_image=True, description="Wheel + OCI image for the API"))
        return profiles

    def save_profile(self, project: Project, profile: BuildProfile) -> None:
        self.db.execute(
            "INSERT INTO build_profiles(project_id, name, doc) VALUES (?, ?, ?) ON CONFLICT(project_id, name) DO UPDATE SET doc = excluded.doc",
            (project.id, profile.name, profile.model_dump_json()),
        )

    def profile(self, project: Project, name: str | None) -> BuildProfile:
        name = name or project.active_profile
        for p in self.profiles(project):
            if p.name == name:
                return p
        raise KeyError(f"unknown build profile {name}")

    # ---- records ------------------------------------------------------------
    def get(self, build_id: str) -> BuildRecord:
        row = self.db.one("SELECT doc, status FROM builds WHERE id = ?", (build_id,))
        if row is None:
            raise KeyError(build_id)
        rec = BuildRecord.model_validate_json(row["doc"])
        rec.status = BuildStatus(row["status"])  # status column is authoritative (recovery updates it)
        return rec

    def list(self, project_id: str | None = None, limit: int = 50) -> list[BuildRecord]:
        if project_id:
            rows = self.db.query("SELECT id FROM builds WHERE project_id = ? ORDER BY started_at DESC, rowid DESC LIMIT ?", (project_id, limit))
        else:
            rows = self.db.query("SELECT id FROM builds ORDER BY started_at DESC, rowid DESC LIMIT ?", (limit,))
        return [self.get(r["id"]) for r in rows]

    def latest(self, project_id: str) -> BuildRecord | None:
        recs = self.list(project_id, 1)
        return recs[0] if recs else None

    def _save(self, rec: BuildRecord, insert: bool = False) -> None:
        doc = rec.model_dump_json()
        if insert:
            self.db.execute(
                "INSERT INTO builds(id, project_id, status, started_at, heartbeat_at, doc) VALUES (?, ?, ?, ?, ?, ?)",
                (rec.build_id, rec.project_id, rec.status.value, rec.started_at, now(), doc),
            )
        else:
            self.db.execute(
                "UPDATE builds SET status = ?, completed_at = ?, heartbeat_at = ?, doc = ? WHERE id = ?",
                (rec.status.value, rec.completed_at, now(), doc, rec.build_id),
            )

    def build_dir(self, build_id: str) -> Path:
        return self.settings.builds_dir / build_id

    def cancel(self, build_id: str) -> bool:
        with self._lock:
            tok = self._active.get(build_id)
        if tok:
            tok.cancel()
            return True
        return False

    # ---- run ------------------------------------------------------------------
    def run(self, project: Project, profile_name: str | None = None, *, emit: Emit = _noop, cancel: CancellationToken | None = None) -> BuildRecord:
        cancel = cancel or CancellationToken()
        profile = self.profile(project, profile_name)
        build_id = new_id("bld")
        bdir = self.build_dir(build_id)
        for sub in ("source", "artefacts", "logs"):
            (bdir / sub).mkdir(parents=True, exist_ok=True)
        st = self.runtime.status()
        rec = BuildRecord(
            build_id=build_id, project_id=project.id, project_name=project.name, project_type=project.type, adapter="",
            source_checkpoint="", source_hash="", manifest_version=0, build_profile=profile.name, started_at=now(),
            status=BuildStatus.running, isolation=f"{st.name} {st.version}".strip(), worker_image=self.settings.python_image,
        )
        self._save(rec, insert=True)
        with self._lock:
            self._active[build_id] = cancel

        def log(text: str) -> None:
            with open(bdir / "logs" / "foundry.log", "a", encoding="utf-8") as f:
                f.write(redact(text) + "\n")
            emit("foundry", redact(text))

        try:
            self._run(project, profile, rec, bdir, cancel, emit, log)
        except Exception as exc:  # never leave a build looking successful
            rec.status = BuildStatus.failed
            rec.diagnosis = Diagnosis(category=ErrorCategory.unknown, summary=f"internal error: {exc.__class__.__name__}: {redact(str(exc))[:300]}", stage="orchestrator")
            log("internal error:\n" + redact(traceback.format_exc()))
        finally:
            rec.completed_at = now()
            if rec.status == BuildStatus.running:
                rec.status = BuildStatus.failed
            self._save(rec)
            (bdir / "record.json").write_text(rec.model_dump_json(indent=2), "utf-8")
            with self._lock:
                self._active.pop(build_id, None)
            self.db.log_activity(
                "build",
                f"Build {build_id} {rec.status.value}; tests {rec.tests_status.value}; smoke {rec.smoke_status.value}"
                + (f"; {rec.diagnosis.category.value}: {rec.diagnosis.summary}" if rec.diagnosis else ""),
                project.id,
            )
        return rec

    def _run(self, project: Project, profile: BuildProfile, rec: BuildRecord, bdir: Path, cancel: CancellationToken, emit: Emit, log) -> None:
        src_root = Path(project.root)
        try:
            manifest = load_manifest(src_root)
        except ManifestError as exc:
            rec.status = BuildStatus.failed
            rec.diagnosis = Diagnosis(category=ErrorCategory.configuration, summary="foundry.yaml is invalid: " + "; ".join(i.message for i in exc.issues)[:400], stage="preflight")
            return
        if manifest is None:
            rec.status = BuildStatus.blocked
            rec.diagnosis = Diagnosis(category=ErrorCategory.configuration, summary="No foundry.yaml. Review and apply the proposed manifest first.", stage="preflight")
            return
        adapter = get_adapter(manifest.build.adapter)
        rec.adapter = manifest.build.adapter
        rec.manifest_version = manifest.schema_version
        if adapter is None:
            rec.status = BuildStatus.failed
            rec.diagnosis = Diagnosis(category=ErrorCategory.configuration, summary=f"Unknown build adapter '{manifest.build.adapter}'.", stage="preflight")
            return

        st = self.runtime.status()
        if not st.available:
            rec.status = BuildStatus.blocked
            rec.diagnosis = Diagnosis(category=ErrorCategory.isolation, summary=f"Isolated execution is unavailable: {st.reason}. Builds do not fall back to the host.", stage="preflight")
            log(rec.diagnosis.summary)
            return

        # Checkpoint and stage the exact checkpoint tree (not the live working copy).
        cp = self.projects.checkpoint(project, f"Pre-build checkpoint ({profile.name})", "pre-build")
        rec.source_checkpoint = cp.commit_sha
        self.projects.repo(project).archive_to(cp.commit_sha, bdir / "source")
        staged = [
            FileEntry(path=rel, size=(bdir / "source" / rel).stat().st_size, sha256=_sha256(bdir / "source" / rel))
            for rel in list_project_files(bdir / "source")
        ]
        rec.source_hash = tree_hash(staged)
        log(f"checkpoint {cp.commit_sha[:12]} staged ({len(staged)} files, source hash {rec.source_hash[:16]})")
        report = inspect_project(bdir / "source", self.settings)
        ctx = BuildContext(
            settings=self.settings, runtime=self.runtime, manifest=manifest, report=report, profile=profile, record=rec,
            build_dir=bdir, cancel=cancel, emit=emit,
        )
        problems = adapter.preflight(ctx)
        if problems:
            rec.status = BuildStatus.blocked if not adapter.implemented else BuildStatus.failed
            rec.diagnosis = Diagnosis(category=ErrorCategory.configuration, summary=" ".join(problems)[:600], stage="preflight")
            log("preflight: " + rec.diagnosis.summary)
            return
        rec.toolchain_versions = self._toolchain(ctx)
        self._save(rec)

        def stage(fn, name: str) -> StageResult:
            log(f"== {name} ==")
            res = fn(ctx)
            rec.stages.append(res)
            log(f"{name}: {res.status.value} - {res.summary}")
            self._save(rec)
            return res

        def halt(res: StageResult) -> bool:
            if res.status == StageStatus.cancelled or cancel.cancelled:
                rec.status = BuildStatus.cancelled
                return True
            if res.status == StageStatus.timed_out:
                rec.status = BuildStatus.timed_out
                rec.diagnosis = res.diagnosis
                return True
            if res.status in (StageStatus.failed, StageStatus.unsupported, StageStatus.blocked):
                rec.status = BuildStatus.failed
                rec.diagnosis = res.diagnosis or Diagnosis(category=ErrorCategory.unknown, summary=res.summary, stage=res.name)
                return True
            return False

        if halt(stage(adapter.fetch, "fetch")):
            return
        if halt(stage(adapter.build, "build")):
            return
        pkg, arts = adapter.package(ctx)
        rec.stages.append(pkg)
        if halt(pkg):
            return
        rec.artefacts = arts
        lock = ctx.artefact_dir / "foundry.lock.json"
        if lock.exists():
            rec.artefacts.append(Artefact(path="foundry.lock.json", sha256=sha256_file(lock), size=lock.stat().st_size, kind="lock"))
        rec.artefact_hashes = {a.path: a.sha256 for a in rec.artefacts}
        rec.status = BuildStatus.succeeded
        self._save(rec)

        # Tests and smoke checks are recorded separately from the build result.
        if profile.run_tests:
            log("== test ==")
            tres, treport = adapter.test(ctx)
            rec.stages.append(tres)
            rec.tests = treport
            rec.tests_status = tres.status
            log(f"test: {tres.status.value} - {tres.summary}")
            if tres.status == StageStatus.failed and tres.diagnosis and rec.diagnosis is None:
                rec.diagnosis = tres.diagnosis
            if tres.status == StageStatus.cancelled:
                rec.status = BuildStatus.cancelled
                return
            self._save(rec)
        else:
            rec.tests_status = StageStatus.skipped
        if profile.smoke_check and not cancel.cancelled:
            sres = stage(adapter.smoke, "smoke")
            rec.smoke_status = sres.status
            if sres.status in (StageStatus.failed, StageStatus.timed_out) and sres.diagnosis and rec.diagnosis is None:
                rec.diagnosis = sres.diagnosis
            if sres.status == StageStatus.cancelled:
                rec.status = BuildStatus.cancelled
        else:
            rec.smoke_status = StageStatus.skipped
        if cancel.cancelled:
            rec.status = BuildStatus.cancelled

    def _toolchain(self, ctx: BuildContext) -> dict[str, str]:
        versions = {"foundry": __version__}
        st = self.runtime.status()
        versions["container-runtime"] = f"{st.name} {st.version}"
        binary = getattr(self.runtime, "binary", None)
        if binary:
            res = run_process([binary, "image", "inspect", "-f", "{{.Id}}", ctx.image], timeout_s=30)
            if res.ok:
                ctx.record.worker_image_id = res.stdout.strip()
        try:
            wr = self.runtime.run_plan(
                ctx.image,
                [
                    WorkerStep(name="python version", argv=["python", "-I", "-VV"], timeout_s=30),
                    WorkerStep(name="pip version", argv=["python", "-I", "-m", "pip", "--version"], timeout_s=30),
                ],
                WorkerPolicy(network="none", limits=self.settings.limits, label="probe"),
                name_prefix="foundry-probe",
            )
            lines = [ln.strip() for ln in wr.output.splitlines() if ln.strip()]
            for ln in lines:
                if ln.startswith("Python "):
                    versions["python"] = ln.split()[1]
                elif ln.startswith("pip "):
                    versions["pip"] = ln.split()[1]
        except Exception as exc:  # pragma: no cover - probe is informational
            versions["probe-error"] = exc.__class__.__name__
        versions["worker-image"] = ctx.image
        return versions

    def context_for(self, build_id: str, emit: Emit = _noop) -> BuildContext:
        """Rebuild an execution context for a finished build (previews, console runs)."""

        from ..dependencies.environments import Wheelhouse

        rec = self.get(build_id)
        bdir = self.build_dir(build_id)
        manifest = load_manifest(bdir / "source")
        if manifest is None:
            raise KeyError("build has no manifest")
        report = inspect_project(bdir / "source", self.settings)
        project = self.projects.get(rec.project_id)
        ctx = BuildContext(
            settings=self.settings, runtime=self.runtime, manifest=manifest, report=report,
            profile=self.profile(project, rec.build_profile), record=rec, build_dir=bdir, cancel=CancellationToken(), emit=emit,
        )
        if rec.dependency_lock_reference:
            root = Path(rec.dependency_lock_reference.split(" sha256:")[0]).parent
            ctx.wheelhouse = Wheelhouse(root, root.name)
        return ctx

    # ---- maintenance ---------------------------------------------------------
    def remove_build_dir(self, build_id: str) -> None:
        d = self.build_dir(build_id).resolve()
        if d.is_relative_to(self.settings.builds_dir.resolve()):
            shutil.rmtree(d, ignore_errors=True)


def record_to_json(rec: BuildRecord) -> str:
    return json.dumps(json.loads(rec.model_dump_json()), indent=2)
