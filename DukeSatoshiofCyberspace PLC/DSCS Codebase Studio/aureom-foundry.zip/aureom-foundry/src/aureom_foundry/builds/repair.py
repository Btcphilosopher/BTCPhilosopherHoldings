"""Repair workflow.

inspect failure -> propose patch -> review diff -> checkpoint -> apply ->
rerun relevant checks.

Attempts are bounded per failure signature (``settings.max_repair_attempts``).
When the diagnosis is ``unknown`` or the adapter reports insufficient evidence,
the workflow stops and explains what the user must supply.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ..ai.adapter import AITask, OfflineAdapter, adapter_for
from ..ai.consent import build_share_preview
from ..ai.proposals import Proposal
from ..inspection.report import inspect_project
from .models import BuildRecord, ErrorCategory


@dataclass
class RepairOutcome:
    proposal: Proposal | None
    explanation: str
    stopped: bool
    reason: str = ""


class RepairService:
    def __init__(self, foundry):
        self.f = foundry

    def explain(self, rec: BuildRecord) -> str:
        project = self.f.projects.get(rec.project_id)
        report = inspect_project(Path(project.root), self.f.settings)
        # Explanations need no repository content, so the offline adapter is always used here.
        res = OfflineAdapter().run(AITask(kind="explain_error", diagnosis=rec.diagnosis), report, None)
        return res.explanation

    def propose(self, rec: BuildRecord, *, approved_share: bool = False) -> RepairOutcome:
        d = rec.diagnosis
        if d is None:
            return RepairOutcome(None, "The build has no recorded failure.", True, "nothing to repair")
        if d.category in (ErrorCategory.unknown, ErrorCategory.isolation, ErrorCategory.timeout, ErrorCategory.resource_limit, ErrorCategory.network_denied):
            return RepairOutcome(None, self.explain(rec), True, f"{d.category.value}: not repairable automatically - evidence is insufficient or the cause is policy/environment")
        project = self.f.projects.get(rec.project_id)
        attempts = self.f.proposals.attempts_for(project.id, d.signature)
        if attempts >= self.f.settings.max_repair_attempts:
            return RepairOutcome(None, self.explain(rec), True, f"repair attempt limit ({self.f.settings.max_repair_attempts}) reached for this failure")
        report = inspect_project(Path(project.root), self.f.settings)
        adapter = adapter_for(self.f.settings, project)
        share = None
        if adapter.external:
            if not approved_share:
                return RepairOutcome(None, "External AI is configured. Review the share preview and approve it to continue.", True, "share approval required")
            share = build_share_preview(Path(project.root), report, self.f.settings.ai.max_shared_bytes, [d.path] if d.path else None)
        result = adapter.run(AITask(kind="propose_fix", diagnosis=d), report, share)
        if result.insufficient_evidence or not result.operations:
            return RepairOutcome(None, result.explanation, True, "insufficient evidence for a safe patch")
        prop = self.f.proposals.create(
            project,
            f"Repair {d.category.value}: {d.summary[:120]}",
            result.explanation,
            result.operations,
            source=result.source,
            signature=d.signature,
            shared_files=[s.path for s in share.files] if share else [],
        )
        return RepairOutcome(prop, result.explanation, prop.status != "proposed", "; ".join(prop.violations))
