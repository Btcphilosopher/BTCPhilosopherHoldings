"""Static analysis of Python sources using :mod:`ast` (never imports or executes)."""

from __future__ import annotations

import ast
import sys
from dataclasses import dataclass, field
from pathlib import Path

STDLIB = set(sys.stdlib_module_names) | {"__future__"}

# Import name -> distribution name, for common cases where they differ or are well known.
# Unknown imports are reported as unresolved: Foundry never guesses a similarly named package.
IMPORT_TO_DIST: dict[str, str] = {
    "yaml": "PyYAML", "PIL": "Pillow", "cv2": "opencv-python", "sklearn": "scikit-learn",
    "bs4": "beautifulsoup4", "dateutil": "python-dateutil", "dotenv": "python-dotenv",
    "jwt": "PyJWT", "magic": "python-magic", "serial": "pyserial", "usb": "pyusb",
    "Crypto": "pycryptodome", "OpenSSL": "pyOpenSSL", "google.protobuf": "protobuf",
    "attr": "attrs", "multipart": "python-multipart", "docx": "python-docx", "pptx": "python-pptx",
    "fitz": "PyMuPDF", "skimage": "scikit-image", "zmq": "pyzmq", "git": "GitPython",
    "fastapi": "fastapi", "uvicorn": "uvicorn", "pydantic": "pydantic", "starlette": "starlette",
    "httpx": "httpx", "requests": "requests", "numpy": "numpy", "pandas": "pandas", "flask": "Flask",
    "django": "Django", "click": "click", "typer": "typer", "rich": "rich", "PySide6": "PySide6",
    "PyQt6": "PyQt6", "pytest": "pytest", "sqlalchemy": "SQLAlchemy", "jinja2": "Jinja2",
    "matplotlib": "matplotlib", "scipy": "scipy", "aiohttp": "aiohttp", "anyio": "anyio",
    "tomli": "tomli", "toml": "toml", "markdown": "Markdown", "lxml": "lxml", "psycopg2": "psycopg2-binary",
    "psycopg": "psycopg", "redis": "redis", "boto3": "boto3", "openpyxl": "openpyxl", "tabulate": "tabulate",
}

# Distributions that need system libraries or compilers when no wheel is available.
NATIVE_HINTS: dict[str, str] = {
    "psycopg2": "PostgreSQL client headers (libpq) unless psycopg2-binary wheels are used",
    "lxml": "libxml2/libxslt when no wheel matches the platform",
    "cv2": "system video/GL libraries for GUI functions",
    "PySide6": "Qt system libraries (libGL, fontconfig, xkbcommon) to display windows",
    "PyQt6": "Qt system libraries (libGL, fontconfig, xkbcommon) to display windows",
    "magic": "libmagic shared library",
    "pyaudio": "PortAudio",
    "mysqlclient": "MySQL client headers",
}


@dataclass
class PythonFacts:
    imports: dict[str, list[str]] = field(default_factory=dict)  # top-level module -> files
    syntax_errors: list[tuple[str, int, str]] = field(default_factory=list)
    main_guards: list[str] = field(default_factory=list)
    fastapi_apps: list[tuple[str, str]] = field(default_factory=list)  # (file, variable)
    qt_apps: list[str] = field(default_factory=list)
    argparse_users: list[str] = field(default_factory=list)
    local_modules: set[str] = field(default_factory=set)


def _local_module_names(root: Path, py_files: list[str]) -> set[str]:
    names: set[str] = set()
    for rel in py_files:
        p = Path(rel)
        parts = p.parts
        if parts and parts[0] == "src" and len(parts) > 1:
            parts = parts[1:]
        if not parts:
            continue
        names.add(Path(parts[0]).stem if len(parts) == 1 else parts[0])
        if len(parts) > 1 and parts[0] in {"tests", "test"}:
            names.add(Path(parts[-1]).stem)
    for top in ("tests", "test"):
        names.add(top)
    return names


def analyse_python(root: Path, py_files: list[str], max_bytes: int = 2_000_000) -> PythonFacts:
    facts = PythonFacts()
    facts.local_modules = _local_module_names(root, py_files)
    for rel in py_files:
        path = root / rel
        try:
            data = path.read_bytes()
        except OSError:
            continue
        if len(data) > max_bytes:
            continue
        try:
            tree = ast.parse(data, filename=rel)
        except SyntaxError as exc:
            facts.syntax_errors.append((rel, exc.lineno or 0, exc.msg))
            continue
        except ValueError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    top = alias.name.split(".")[0]
                    facts.imports.setdefault(top, []).append(rel)
            elif isinstance(node, ast.ImportFrom):
                if node.level == 0 and node.module:
                    top = node.module.split(".")[0]
                    facts.imports.setdefault(top, []).append(rel)
            elif isinstance(node, ast.If):
                t = node.test
                if (
                    isinstance(t, ast.Compare)
                    and isinstance(t.left, ast.Name)
                    and t.left.id == "__name__"
                    and any(isinstance(c, ast.Constant) and c.value == "__main__" for c in t.comparators)
                ):
                    facts.main_guards.append(rel)
            elif isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
                fn = node.value.func
                fname = fn.id if isinstance(fn, ast.Name) else fn.attr if isinstance(fn, ast.Attribute) else ""
                if fname == "FastAPI":
                    for tgt in node.targets:
                        if isinstance(tgt, ast.Name):
                            facts.fastapi_apps.append((rel, tgt.id))
                elif fname in {"QApplication", "QGuiApplication"}:
                    facts.qt_apps.append(rel)
                elif fname == "ArgumentParser":
                    facts.argparse_users.append(rel)
            elif isinstance(node, ast.Call):
                fn = node.func
                fname = fn.id if isinstance(fn, ast.Name) else fn.attr if isinstance(fn, ast.Attribute) else ""
                if fname in {"QApplication", "QGuiApplication"} and rel not in facts.qt_apps:
                    facts.qt_apps.append(rel)
    return facts


def third_party_imports(facts: PythonFacts) -> dict[str, list[str]]:
    return {
        mod: sorted(set(files))
        for mod, files in facts.imports.items()
        if mod not in STDLIB and mod not in facts.local_modules and not mod.startswith("_")
    }


def distribution_for(module: str) -> str | None:
    return IMPORT_TO_DIST.get(module)
