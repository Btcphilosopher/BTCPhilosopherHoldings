"""Safe intake of untrusted archives and folders.

Rules (an archive that breaks any *structural* rule is rejected as a whole;
partial extraction of a hostile archive is never attempted):

* no absolute paths, drive letters, UNC paths or ``..`` components;
* no symbolic links, hard links, device or FIFO entries;
* no case-insensitive name collisions (they behave differently per OS);
* encrypted entries are rejected;
* file-count, per-file size, total size, path depth and compression-ratio
  limits are enforced while streaming, so lying headers cannot bypass them.

Folder copies never follow symbolic links: links are recorded and skipped.
"""

from __future__ import annotations

import os
import shutil
import stat
import zipfile
from pathlib import Path, PurePosixPath

from pydantic import BaseModel, Field

from ..config import ImportLimits

# Directories that are never imported from a folder (caches, environments, VCS internals).
SKIP_DIRS = {
    ".git", ".hg", ".svn", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".tox", ".nox",
    ".venv", "venv", "env", "node_modules", ".idea", ".vscode", "dist", "build", ".eggs", "target",
    ".gradle", ".DS_Store",
}


class ArchiveRejected(Exception):
    def __init__(self, reasons: list[str]):
        super().__init__("; ".join(reasons))
        self.reasons = reasons


class IntakeReport(BaseModel):
    source_kind: str
    accepted_files: int = 0
    total_bytes: int = 0
    skipped: list[str] = Field(default_factory=list)  # informational: caches, links, etc.
    symlinks: list[str] = Field(default_factory=list)
    rejected_reasons: list[str] = Field(default_factory=list)


def _normalise_member(name: str) -> PurePosixPath | None:
    """Return a safe relative path or ``None`` if the name is structurally unsafe."""

    name = name.replace("\\", "/")
    if not name or name.startswith("/") or name.startswith("//"):
        return None
    if len(name) >= 2 and name[1] == ":":  # C:/...
        return None
    if "\x00" in name:
        return None
    p = PurePosixPath(name)
    if any(part in ("..", "") for part in p.parts):
        return None
    parts = [part for part in p.parts if part != "."]
    if not parts:
        return None
    return PurePosixPath(*parts)


def _zip_member_kind(info: zipfile.ZipInfo) -> str:
    mode = (info.external_attr >> 16) & 0xFFFF
    if stat.S_IFMT(mode) == 0:  # no Unix file-type bits recorded (common): plain entry
        return "dir" if info.is_dir() else "file"
    if stat.S_ISLNK(mode):
        return "symlink"
    if stat.S_ISDIR(mode) or info.is_dir():
        return "dir"
    if stat.S_ISREG(mode):
        return "file"
    return "special"


def audit_zip(zip_path: Path, limits: ImportLimits) -> list[str]:
    """Return a list of reasons the archive must be rejected (empty when safe)."""

    reasons: list[str] = []
    try:
        zf = zipfile.ZipFile(zip_path)
    except (zipfile.BadZipFile, OSError) as exc:
        return [f"not a readable ZIP archive: {exc.__class__.__name__}"]
    with zf:
        infos = zf.infolist()
        files = [i for i in infos if not i.is_dir()]
        if len(files) > limits.max_files:
            reasons.append(f"archive holds {len(files)} files; limit is {limits.max_files}")
        seen: dict[str, str] = {}
        declared_total = 0
        for info in infos:
            safe = _normalise_member(info.filename)
            shown = info.filename.encode("ascii", "backslashreplace").decode()[:200]
            if safe is None:
                reasons.append(f"unsafe path rejected: {shown!r}")
                continue
            if len(safe.parts) > limits.max_path_depth:
                reasons.append(f"path too deep: {shown!r}")
            kind = _zip_member_kind(info)
            if kind == "symlink":
                reasons.append(f"symbolic link entry rejected: {shown!r}")
            elif kind == "special":
                reasons.append(f"special file entry rejected: {shown!r}")
            if info.flag_bits & 0x1:
                reasons.append(f"encrypted entry rejected: {shown!r}")
            key = str(safe).lower()
            if key in seen and seen[key] != str(safe) and not info.is_dir():
                reasons.append(f"case-insensitive name collision: {shown!r}")
            seen[key] = str(safe)
            if not info.is_dir():
                declared_total += info.file_size
                if info.file_size > limits.max_file_mb * 1024 * 1024:
                    reasons.append(f"file exceeds {limits.max_file_mb} MB: {shown!r}")
                if info.compress_size > 0 and info.file_size / info.compress_size > limits.max_compression_ratio:
                    reasons.append(f"suspicious compression ratio (possible archive bomb): {shown!r}")
        if declared_total > limits.max_total_mb * 1024 * 1024:
            reasons.append(f"archive expands to {declared_total} bytes; limit is {limits.max_total_mb} MB")
    # de-duplicate while keeping order
    return list(dict.fromkeys(reasons))


def safe_extract_zip(zip_path: Path, dest: Path, limits: ImportLimits) -> IntakeReport:
    reasons = audit_zip(zip_path, limits)
    if reasons:
        raise ArchiveRejected(reasons)
    report = IntakeReport(source_kind="zip")
    dest.mkdir(parents=True, exist_ok=True)
    dest_resolved = dest.resolve()
    max_file = limits.max_file_mb * 1024 * 1024
    max_total = limits.max_total_mb * 1024 * 1024
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            rel = _normalise_member(info.filename)
            assert rel is not None  # audited above
            if any(part in SKIP_DIRS for part in rel.parts[:-1]) or rel.name in SKIP_DIRS:
                report.skipped.append(str(rel))
                continue
            target = (dest / rel).resolve()
            if not target.is_relative_to(dest_resolved):  # belt and braces
                raise ArchiveRejected([f"path escapes destination: {info.filename!r}"])
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            written = 0
            with zf.open(info) as src, open(target, "xb") as out:
                while chunk := src.read(65536):
                    written += len(chunk)
                    report.total_bytes += len(chunk)
                    if written > max_file or report.total_bytes > max_total:
                        out.close()
                        shutil.rmtree(dest, ignore_errors=True)
                        raise ArchiveRejected(["decompressed size exceeded limits (headers were misleading)"])
                    out.write(chunk)
            os.chmod(target, 0o644)  # never preserve executable/setuid bits from archives
            report.accepted_files += 1
    return report


def safe_copy_tree(src: Path, dest: Path, limits: ImportLimits, *, keep_git: bool = False) -> IntakeReport:
    """Copy a folder without following links, enforcing limits."""

    report = IntakeReport(source_kind="folder")
    src = src.resolve()
    if not src.is_dir():
        raise ArchiveRejected([f"not a directory: {src}"])
    max_file = limits.max_file_mb * 1024 * 1024
    max_total = limits.max_total_mb * 1024 * 1024
    dest.mkdir(parents=True, exist_ok=True)
    for root, dirs, files in os.walk(src, followlinks=False):
        root_p = Path(root)
        rel_root = root_p.relative_to(src)
        keep_dirs = []
        for d in dirs:
            full = root_p / d
            if full.is_symlink():
                report.symlinks.append(str(rel_root / d))
                continue
            if d in SKIP_DIRS and not (keep_git and d == ".git"):
                report.skipped.append(str(rel_root / d) + "/")
                continue
            keep_dirs.append(d)
        dirs[:] = keep_dirs
        if len(rel_root.parts) > limits.max_path_depth:
            raise ArchiveRejected([f"path too deep: {rel_root}"])
        for f in files:
            full = root_p / f
            rel = rel_root / f
            st = full.lstat()
            if stat.S_ISLNK(st.st_mode):
                report.symlinks.append(str(rel))
                continue
            if not stat.S_ISREG(st.st_mode):
                report.skipped.append(f"{rel} (special file)")
                continue
            if st.st_size > max_file:
                raise ArchiveRejected([f"file exceeds {limits.max_file_mb} MB: {rel}"])
            report.accepted_files += 1
            report.total_bytes += st.st_size
            if report.accepted_files > limits.max_files:
                raise ArchiveRejected([f"more than {limits.max_files} files"])
            if report.total_bytes > max_total:
                raise ArchiveRejected([f"folder exceeds {limits.max_total_mb} MB"])
            target = dest / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(full, target, follow_symlinks=False)
            os.chmod(target, 0o644)
    return report
