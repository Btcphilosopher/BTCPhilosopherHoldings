"""Project inspection. Reads files only - nothing in the project is executed."""

from __future__ import annotations

import hashlib
import re
from collections import Counter
from pathlib import Path

from pydantic import BaseModel, Field

from ..config import FoundrySettings
from ..dependencies.analysis import DependencyReport, analyse_dependencies
from ..diagnostics.issues import Issue, error, info, warning
from ..manifests.loader import ManifestError, load_manifest
from ..manifests.schema import MANIFEST_FILENAME, FoundryManifest, ProjectType
from .python_analysis import PythonFacts, analyse_python
from .secrets import SecretFinding, is_sensitive_filename, scan_text

LANGUAGE_BY_SUFFIX = {
    ".py": "Python", ".pyi": "Python", ".js": "JavaScript", ".mjs": "JavaScript", ".cjs": "JavaScript",
    ".ts": "TypeScript", ".tsx": "TypeScript", ".jsx": "JavaScript", ".html": "HTML", ".htm": "HTML",
    ".css": "CSS", ".scss": "SCSS", ".rs": "Rust", ".kt": "Kotlin", ".kts": "Kotlin", ".java": "Java",
    ".go": "Go", ".rb": "Ruby", ".c": "C", ".h": "C", ".cpp": "C++", ".hpp": "C++", ".cs": "C#",
    ".swift": "Swift", ".sh": "Shell", ".ps1": "PowerShell", ".sql": "SQL", ".md": "Markdown",
    ".toml": "TOML", ".yaml": "YAML", ".yml": "YAML", ".json": "JSON", ".xml": "XML", ".csv": "CSV",
}
BUILD_CONFIG_FILES = {
    "Makefile", "Dockerfile", "Containerfile", "docker-compose.yml", "compose.yaml", "tox.ini", "noxfile.py",
    "setup.py", "setup.cfg", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts",
    "gradlew", "Cargo.toml", "package.json", "webpack.config.js", "vite.config.js", "vite.config.ts",
    "pyproject.toml", MANIFEST_FILENAME, ".github/workflows", "Justfile", "pyinstaller.spec",
}
TEXT_SCAN_LIMIT = 1_000_000


class FileEntry(BaseModel):
    path: str
    size: int
    sha256: str
    language: str | None = None
    binary: bool = False


class EntryPoint(BaseModel):
    kind: str  # python-main, console-script, asgi-app, qt-app, html-index
    target: str
    evidence: str


class InspectionReport(BaseModel):
    root: str
    files: list[FileEntry] = Field(default_factory=list)
    total_bytes: int = 0
    languages: dict[str, int] = Field(default_factory=dict)
    build_configs: list[str] = Field(default_factory=list)
    entry_points: list[EntryPoint] = Field(default_factory=list)
    detected_type: ProjectType = ProjectType.unknown
    type_evidence: list[str] = Field(default_factory=list)
    candidate_types: list[ProjectType] = Field(default_factory=list)
    manifest: FoundryManifest | None = None
    manifest_issues: list[Issue] = Field(default_factory=list)
    dependencies: DependencyReport = Field(default_factory=DependencyReport)
    secrets: list[SecretFinding] = Field(default_factory=list)
    sensitive_files: list[str] = Field(default_factory=list)
    issues: list[Issue] = Field(default_factory=list)
    source_hash: str = ""

    def all_issues(self) -> list[Issue]:
        return [*self.manifest_issues, *self.issues, *self.dependencies.issues]

    def has_errors(self) -> bool:
        return any(i.severity.value == "error" for i in self.all_issues())


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def tree_hash(entries: list[FileEntry]) -> str:
    h = hashlib.sha256()
    for e in sorted(entries, key=lambda x: x.path):
        h.update(e.path.encode())
        h.update(b"\0")
        h.update(e.sha256.encode())
        h.update(b"\n")
    return h.hexdigest()


def _is_binary(sample: bytes) -> bool:
    return b"\x00" in sample[:8192]


def list_project_files(root: Path) -> list[str]:
    out: list[str] = []
    for p in sorted(root.rglob("*")):
        rel = p.relative_to(root)
        if rel.parts and rel.parts[0] == ".git":
            continue
        if any(part in {"__pycache__", ".pytest_cache"} for part in rel.parts):
            continue
        if p.is_symlink() or not p.is_file():
            continue
        out.append(rel.as_posix())
    return out


def inspect_project(root: Path, settings: FoundrySettings | None = None) -> InspectionReport:
    root = root.resolve()
    rep = InspectionReport(root=str(root))
    rels = list_project_files(root)
    langs: Counter[str] = Counter()
    py_files: list[str] = []
    for rel in rels:
        path = root / rel
        size = path.stat().st_size
        with open(path, "rb") as f:
            head = f.read(8192)
        lang = LANGUAGE_BY_SUFFIX.get(path.suffix.lower())
        binary = _is_binary(head)
        rep.files.append(FileEntry(path=rel, size=size, sha256=_sha256(path), language=lang, binary=binary))
        rep.total_bytes += size
        if lang and lang not in {"Markdown", "TOML", "YAML", "JSON", "XML", "CSV"}:
            langs[lang] += 1
        if lang == "Python":
            py_files.append(rel)
        if path.name in BUILD_CONFIG_FILES or rel.startswith(".github/workflows/"):
            rep.build_configs.append(rel)
        if is_sensitive_filename(rel):
            rep.sensitive_files.append(rel)
        if not binary and size <= TEXT_SCAN_LIMIT:
            rep.secrets += scan_text(path.read_text("utf-8", errors="replace"), rel)
    rep.languages = dict(langs.most_common())
    rep.source_hash = tree_hash(rep.files)

    # Manifest
    try:
        rep.manifest = load_manifest(root)
    except ManifestError as exc:
        rep.manifest_issues = exc.issues

    facts: PythonFacts | None = analyse_python(root, py_files) if py_files else None
    worker_py = (rep.manifest.runtime.python if rep.manifest and rep.manifest.runtime.python else "3.12")
    rep.dependencies = analyse_dependencies(root, rels, facts, worker_python=worker_py)

    _detect_entry_points(root, rels, facts, rep)
    _classify(root, rels, facts, rep)
    _missing(root, rels, facts, rep)

    for finding in rep.secrets:
        rep.issues.append(
            warning(
                "possible-credential",
                f"possible {finding.detector} on line {finding.line} (fingerprint {finding.fingerprint}); value not shown",
                "Remove the credential from source and supply it at runtime. It will be excluded from AI sharing and exports.",
                finding.path,
            )
        )
    for sf in rep.sensitive_files:
        rep.issues.append(warning("sensitive-file", "file name suggests credentials or keys; it is never exported or shared", path=sf))
    return rep


def _detect_entry_points(root: Path, rels: list[str], facts: PythonFacts | None, rep: InspectionReport) -> None:
    if facts:
        for rel in sorted(set(facts.main_guards)):
            rep.entry_points.append(EntryPoint(kind="python-main", target=rel, evidence="if __name__ == '__main__'"))
        for rel in rels:
            if rel.endswith("__main__.py") and rel not in facts.main_guards:
                rep.entry_points.append(EntryPoint(kind="python-main", target=rel, evidence="package __main__ module"))
        for rel, var in facts.fastapi_apps:
            module = _module_name(rel)
            rep.entry_points.append(EntryPoint(kind="asgi-app", target=f"{module}:{var}", evidence=f"{var} = FastAPI(...) in {rel}"))
        for rel in sorted(set(facts.qt_apps)):
            rep.entry_points.append(EntryPoint(kind="qt-app", target=rel, evidence="QApplication(...) constructed"))
    scripts = ((rep.dependencies.pyproject.get("project") or {}).get("scripts") or {}) if rep.dependencies.pyproject else {}
    for name, target in scripts.items():
        rep.entry_points.append(EntryPoint(kind="console-script", target=f"{name} = {target}", evidence="[project.scripts]"))
    for rel in rels:
        if Path(rel).name.lower() == "index.html" and rel.count("/") <= 1:
            rep.entry_points.append(EntryPoint(kind="html-index", target=rel, evidence="index.html"))


def _module_name(rel: str) -> str:
    parts = list(Path(rel).with_suffix("").parts)
    if parts and parts[0] == "src":
        parts = parts[1:]
    return ".".join(parts)


def _classify(root: Path, rels: list[str], facts: PythonFacts | None, rep: InspectionReport) -> None:
    names = {Path(r).name for r in rels}
    candidates: list[ProjectType] = []
    ev: list[str] = []
    imports = set(facts.imports) if facts else set()
    if facts and facts.fastapi_apps:
        candidates.append(ProjectType.python_fastapi)
        ev.append("FastAPI application object found")
    if facts and ("PySide6" in imports) and facts.qt_apps:
        candidates.append(ProjectType.python_pyside6)
        ev.append("PySide6 imported and QApplication constructed")
    if facts and not candidates and (facts.main_guards or any(r.endswith("__main__.py") for r in rels)):
        candidates.append(ProjectType.python_cli)
        ev.append("Python entry point with __main__ found")
    has_html = any(r.lower().endswith((".html", ".htm")) for r in rels)
    if has_html and not facts:
        candidates.append(ProjectType.static_site)
        ev.append("HTML files and no server-side Python")
    if "package.json" in names:
        candidates.append(ProjectType.node_app)
        ev.append("package.json found")
    if "Cargo.toml" in names:
        candidates.append(ProjectType.rust_binary)
        ev.append("Cargo.toml found")
    if "AndroidManifest.xml" in names or any(
        n in names and "android" in (root / n).read_text("utf-8", "replace") for n in ("build.gradle", "build.gradle.kts") if (root / n).is_file()
    ):
        candidates.append(ProjectType.kotlin_android)
        ev.append("Android Gradle configuration found")
    rep.candidate_types = candidates
    rep.type_evidence = ev
    if rep.manifest is not None:
        rep.detected_type = rep.manifest.project.type
        rep.type_evidence.insert(0, "declared in foundry.yaml")
        if candidates and rep.manifest.project.type not in candidates:
            rep.issues.append(
                warning(
                    "type-mismatch",
                    f"foundry.yaml declares {rep.manifest.project.type.value} but inspection suggests "
                    + ", ".join(c.value for c in candidates),
                    path=MANIFEST_FILENAME,
                )
            )
        return
    langs = {k for k in rep.languages if k not in {"HTML", "CSS", "JavaScript"} or not facts}
    if len(candidates) > 1 and not (set(candidates) <= {ProjectType.python_fastapi, ProjectType.python_pyside6}):
        rep.detected_type = ProjectType.mixed
    elif candidates:
        rep.detected_type = candidates[0]
    elif len(langs) > 1:
        rep.detected_type = ProjectType.mixed
    else:
        rep.detected_type = ProjectType.unknown


def _missing(root: Path, rels: list[str], facts: PythonFacts | None, rep: InspectionReport) -> None:
    names_lower = {r.lower() for r in rels}
    if not rels:
        rep.issues.append(error("empty-project", "No files were found.", "Import a folder, archive or pasted code."))
        return
    if not any(n.startswith("readme") for n in names_lower):
        rep.issues.append(info("missing-readme", "No README found.", "Scaffolding can add one with run instructions."))
    if rep.manifest is None and not rep.manifest_issues:
        rep.issues.append(
            info("missing-foundry-manifest", "No foundry.yaml found; Foundry will propose one from the inspection.", "Review the proposed manifest before building.")
        )
    if facts:
        for rel, line, msg in facts.syntax_errors:
            rep.issues.append(error("syntax-error", f"line {line}: {msg}", path=rel))
        if not facts.main_guards and not facts.fastapi_apps and not facts.qt_apps and not any(r.endswith("__main__.py") for r in rels):
            rep.issues.append(
                warning("missing-entry-point", "No Python entry point was found.", "Add a __main__.py or `if __name__ == '__main__':` block, or name the entry point in foundry.yaml.")
            )
        if not any(r.startswith(("tests/", "test/")) or Path(r).name.startswith("test_") for r in rels):
            rep.issues.append(info("missing-tests", "No tests found. Builds can succeed, but there is no test evidence."))
    if rep.manifest and rep.manifest.project.entrypoint and rep.manifest.project.entrypoint not in rels:
        rep.issues.append(error("invalid-entry-point", f"entrypoint '{rep.manifest.project.entrypoint}' does not exist", path=MANIFEST_FILENAME))
    # Static site: references to missing local assets.
    for rel in rels:
        if rel.lower().endswith((".html", ".htm")):
            text = (root / rel).read_text("utf-8", errors="replace")
            for ref in re.findall(r"""(?:src|href)\s*=\s*["']([^"'#?]+)""", text, flags=re.I):
                if re.match(r"^[a-z][a-z0-9+.-]*:", ref, re.I) or ref.startswith("//") or ref.startswith("/"):
                    continue
                target = (Path(rel).parent / ref).as_posix()
                norm = Path(target).as_posix()
                parts: list[str] = []
                for part in norm.split("/"):
                    if part == "..":
                        if parts:
                            parts.pop()
                    elif part not in ("", "."):
                        parts.append(part)
                resolved = "/".join(parts)
                if resolved and resolved not in rels and resolved + "/index.html" not in rels:
                    rep.issues.append(error("missing-asset", f"references '{ref}', which is not in the project", path=rel))
