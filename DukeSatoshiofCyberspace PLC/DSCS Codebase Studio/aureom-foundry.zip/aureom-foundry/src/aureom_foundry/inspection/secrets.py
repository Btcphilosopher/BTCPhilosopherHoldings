"""Credential detection and redaction.

Findings never carry the secret value. Each finding records the file, line,
detector name and a short, non-reversible fingerprint so the same secret can be
tracked across scans without being displayed or logged.
"""

from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass
from pathlib import Path

from pydantic import BaseModel

# Patterns deliberately target well-known token shapes plus generic assignments.
_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("aws-access-key-id", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("aws-secret-access-key", re.compile(r"(?i)aws_?secret_?access_?key\s*[:=]\s*['\"]?([A-Za-z0-9/+=]{40})")),
    ("private-key-block", re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY(?: BLOCK)?-----")),
    ("github-token", re.compile(r"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{36,}\b|\bgithub_pat_[A-Za-z0-9_]{60,}\b")),
    ("slack-token", re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}\b")),
    ("stripe-secret-key", re.compile(r"\b(?:sk|rk)_live_[A-Za-z0-9]{20,}\b")),
    ("anthropic-api-key", re.compile(r"\bsk-ant-[A-Za-z0-9_-]{20,}\b")),
    ("openai-style-key", re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9]{32,}\b")),
    ("google-api-key", re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b")),
    ("jwt", re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b")),
    ("url-credentials", re.compile(r"[a-zA-Z][a-zA-Z0-9+.-]*://[^\s:/@]+:([^\s@/]{4,})@")),
    (
        "generic-secret-assignment",
        re.compile(
            r"(?i)\b(?:api[_-]?key|secret|token|passwd|password|auth[_-]?token|access[_-]?key|client[_-]?secret)"
            r"\b\s*[:=]\s*['\"]([^'\"\s]{8,})['\"]"
        ),
    ),
]

# Placeholder values that should not be reported.
_PLACEHOLDERS = re.compile(
    r"(?i)^(?:x+|\*+|changeme|change-me|example|your[_-].*|<.*>|\$\{.*\}|\{\{.*\}\}|dummy|test|placeholder|none|null|redacted)$"
)

SENSITIVE_FILENAMES = {
    ".env", ".env.local", ".env.production", ".npmrc", ".pypirc", ".netrc", "id_rsa", "id_ed25519",
    "id_ecdsa", "credentials", "credentials.json", "service-account.json", ".git-credentials",
    "secrets.yaml", "secrets.yml", "secrets.json", ".dockercfg", "kubeconfig",
}
SENSITIVE_SUFFIXES = {".pem", ".key", ".p12", ".pfx", ".keystore", ".jks", ".kdbx"}


class SecretFinding(BaseModel):
    path: str
    line: int
    detector: str
    fingerprint: str  # sha256 prefix of the matched value; never the value itself

    def describe(self) -> str:
        return f"{self.path}:{self.line} possible {self.detector} (fingerprint {self.fingerprint})"


def fingerprint(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8", "replace")).hexdigest()[:12]


def _entropy(s: str) -> float:
    if not s:
        return 0.0
    counts: dict[str, int] = {}
    for ch in s:
        counts[ch] = counts.get(ch, 0) + 1
    return -sum((c / len(s)) * math.log2(c / len(s)) for c in counts.values())


@dataclass
class _Match:
    detector: str
    value: str
    start: int
    end: int


def _iter_matches(line: str) -> list[_Match]:
    out: list[_Match] = []
    for name, pat in _PATTERNS:
        for m in pat.finditer(line):
            if m.groups():
                value, start, end = m.group(1), m.start(1), m.end(1)
            else:
                value, start, end = m.group(0), m.start(), m.end()
            if _PLACEHOLDERS.match(value.strip()):
                continue
            if name == "generic-secret-assignment" and _entropy(value) < 2.5:
                continue
            out.append(_Match(name, value, start, end))
    return out


def scan_text(text: str, rel_path: str) -> list[SecretFinding]:
    findings: list[SecretFinding] = []
    seen: set[tuple[int, str]] = set()
    for lineno, line in enumerate(text.splitlines(), start=1):
        if len(line) > 4000:
            line = line[:4000]
        for m in _iter_matches(line):
            key = (lineno, fingerprint(m.value))
            if key in seen:
                continue
            seen.add(key)
            findings.append(SecretFinding(path=rel_path, line=lineno, detector=m.detector, fingerprint=key[1]))
    return findings


def is_sensitive_filename(path: str | Path) -> bool:
    p = Path(path)
    name = p.name.lower()
    if name in SENSITIVE_FILENAMES:
        return True
    if name.startswith(".env.") and name not in {".env.example", ".env.sample", ".env.template"}:
        return True
    return p.suffix.lower() in SENSITIVE_SUFFIXES


def redact(text: str) -> str:
    """Replace any detected secret value in ``text`` with a fingerprinted marker."""

    lines = text.splitlines(keepends=True)
    out: list[str] = []
    for line in lines:
        matches = sorted(_iter_matches(line), key=lambda m: m.start, reverse=True)
        for m in matches:
            line = line[: m.start] + f"[REDACTED:{m.detector}:{fingerprint(m.value)}]" + line[m.end :]
        out.append(line)
    return "".join(out)
