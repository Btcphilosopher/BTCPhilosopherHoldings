"""Extension adapters that are detected but not yet buildable.

They exist so inspection can classify these projects honestly and so the
capability matrix shows exactly what is missing. Each documents the toolchain
an implementation would drive (via typed worker steps, never a reimplemented
compiler).
"""

from __future__ import annotations

from ..builds.models import StageResult, StageStatus
from ..manifests.schema import ProjectType
from .base import Adapter, BuildContext, CapabilityRow, Support, register


class _DetectedOnly(Adapter):
    toolchain = ""
    outputs = ""
    notes = ""

    def capability(self) -> CapabilityRow:
        u = Support.unsupported
        return CapabilityRow(self.project_types[0].value, self.id, Support.detected_only, u, u, u, u, u, self.outputs, self.notes)

    def preflight(self, ctx: BuildContext) -> list[str]:
        return [f"{self.label} projects are detected only. A build adapter for {self.toolchain} is not implemented yet."]

    def build(self, ctx: BuildContext) -> StageResult:
        return StageResult(name="build", status=StageStatus.unsupported, summary=self.preflight(ctx)[0])


class NodeAdapter(_DetectedOnly):
    id = "node"
    label = "Node.js application"
    project_types = (ProjectType.node_app,)
    toolchain = "npm ci --ignore-scripts / npm run build (Node LTS worker image)"
    outputs = "planned: npm pack tarball, static bundle"
    notes = "package.json and lockfiles are inspected; install scripts would run only in the offline build stage."


class RustAdapter(_DetectedOnly):
    id = "rust"
    label = "Rust binary"
    project_types = (ProjectType.rust_binary,)
    toolchain = "cargo fetch (network) then cargo build --release --offline --locked"
    outputs = "planned: native binary for the worker platform"
    notes = "Cargo.toml dependencies are inspected. build.rs scripts are code and would run only inside workers."


class KotlinAndroidAdapter(_DetectedOnly):
    id = "kotlin-android"
    label = "Kotlin Android application"
    project_types = (ProjectType.kotlin_android,)
    toolchain = "Gradle with the Android SDK in a dedicated worker image (gradlew is never run on the host)"
    outputs = "planned: unsigned debug APK"
    notes = "Signing and Play Store submission stay separate from local packaging."


class MixedAdapter(_DetectedOnly):
    id = "mixed"
    label = "Mixed-language project"
    project_types = (ProjectType.mixed,)
    toolchain = "a per-component adapter chain"
    outputs = "planned: one artefact set per component"
    notes = "Choose one component type in foundry.yaml to build it with an implemented adapter."


for _a in (NodeAdapter(), RustAdapter(), KotlinAndroidAdapter(), MixedAdapter()):
    register(_a)
