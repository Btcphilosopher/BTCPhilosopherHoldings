"""Python adapters: command-line packages, FastAPI services and PySide6 desktop apps."""

from __future__ import annotations

import re
import shutil
import tomllib
from pathlib import Path

from ..builds.errors import classify
from ..builds.models import Artefact, StageResult, StageStatus, TestReport
from ..dependencies.environments import build_fetch_request, install_steps, run_fetch
from ..isolation.commands import WorkerStep
from ..isolation.policy import Mount
from ..manifests.schema import FoundryManifest, ProjectType
from ..previews.server import start_server, wait_ready
from ..testing.junit import parse_junit
from .base import Adapter, BuildContext, CapabilityRow, Support, clear_dir, collect_artefacts, register, sha256_file

PY_ARTEFACTS = {"dist/*.whl": "wheel", "dist/*.tar.gz": "sdist"}


def _pyproject(ctx: BuildContext) -> dict:
    p = ctx.source_dir / "pyproject.toml"
    if not p.is_file():
        return {}
    try:
        return tomllib.loads(p.read_text("utf-8"))
    except tomllib.TOMLDecodeError:
        return {}


def has_tests(ctx: BuildContext) -> bool:
    tdir = ctx.source_dir / ctx.manifest.tests.path
    if tdir.is_dir() and any(tdir.rglob("test_*.py")):
        return True
    return any(ctx.source_dir.glob("test_*.py"))


def wheel_path(ctx: BuildContext) -> str | None:
    wheels = sorted((ctx.artefact_dir / "dist").glob("*.whl"))
    return f"/artefacts/dist/{wheels[0].name}" if wheels else None


def install_project_steps(ctx: BuildContext, roles: list[str]) -> list[WorkerStep]:
    assert ctx.wheelhouse is not None
    steps = install_steps(roles, ctx.wheelhouse)
    whl = wheel_path(ctx)
    if whl:
        steps.append(
            WorkerStep(
                name="install built wheel (offline, no deps)",
                argv=["/work/venv/bin/python", "-I", "-m", "pip", "install", "--no-input", "--no-index", "--no-deps", whl],
                timeout_s=300,
                trusted_pip_args=True,
            )
        )
    return steps


class PythonPackageAdapter(Adapter):
    id = "python-package"
    label = "Python command-line tool"
    project_types = (ProjectType.python_cli,)
    implemented = True

    def capability(self) -> CapabilityRow:
        return CapabilityRow(
            "python-cli", self.id, Support.implemented, Support.implemented, Support.implemented, Support.implemented,
            Support.implemented, Support.implemented, "wheel, sdist",
            "Console preview runs the installed package with chosen arguments in an isolated worker.",
        )

    # ---- preflight ------------------------------------------------------------
    def preflight(self, ctx: BuildContext) -> list[str]:
        problems = []
        data = _pyproject(ctx)
        if not data:
            problems.append("pyproject.toml is missing or invalid. Use scaffolding to generate a package configuration.")
        elif "project" not in data:
            problems.append("pyproject.toml has no [project] table (PEP 621 metadata is required).")
        if ctx.report.dependencies.unresolved_imports:
            mods = ", ".join(sorted(ctx.report.dependencies.unresolved_imports))
            ctx.record.notes.append(f"Unresolved imports present ({mods}); the build may fail until their distributions are declared.")
        return problems

    # ---- stages -----------------------------------------------------------------
    def fetch(self, ctx: BuildContext) -> StageResult:
        req = build_fetch_request(ctx.deps, need_build_tooling=True, need_tests=ctx.profile.run_tests and has_tests(ctx), extra_tooling=self.extra_tooling(ctx))
        for r in req.rejected:
            ctx.log(f"fetch: rejected requirement: {r}")
        if req.rejected:
            return StageResult(name="fetch", status=StageStatus.failed, summary="; ".join(req.rejected)[:500])
        ctx.log(f"fetch: tooling={req.tooling} runtime={req.runtime} dev={req.dev}")
        wh, wr = run_fetch(ctx.runtime, ctx.settings, req, ctx.image, cancel=ctx.cancel, on_output=lambda line: ctx.emit("project", line.rstrip("\n")))
        ctx.wheelhouse = wh
        if wr is None:
            res = StageResult(name="fetch", status=StageStatus.passed, summary=f"reused locked wheelhouse {wh.key}")
        elif wr.ok:
            res = StageResult(name="fetch", status=StageStatus.passed, exit_code=0, duration_s=round(wr.duration_s, 2), summary=f"downloaded and locked {len(wh.lock()['packages'])} files")
        else:
            st = StageStatus.timed_out if wr.timed_out else StageStatus.cancelled if wr.cancelled else StageStatus.failed
            res = StageResult(name="fetch", status=st, exit_code=wr.exit_code, duration_s=round(wr.duration_s, 2))
            res.diagnosis = classify(wr.output + "\n" + wr.runtime_error, "fetch", timed_out=wr.timed_out, exit_code=wr.exit_code)
            res.summary = res.diagnosis.summary
            (ctx.logs_dir / "fetch.log").write_text(wr.output, "utf-8")
            ctx.record.logs["fetch"] = str(ctx.logs_dir / "fetch.log")
            return res
        ctx.record.dependency_lock_reference = f"{wh.lock_path} sha256:{wh.lock_sha256()}"
        shutil.copyfile(wh.lock_path, ctx.artefact_dir / "foundry.lock.json")
        return res

    def extra_tooling(self, ctx: BuildContext) -> list[str]:
        return []

    def build(self, ctx: BuildContext) -> StageResult:
        clear_dir(ctx.artefact_dir / "dist")
        steps = [
            WorkerStep(name="stage source", kind="copytree", argv=["/src", "/work/src"]),
            *install_steps(["tooling"], ctx.wheelhouse),  # type: ignore[arg-type]
            WorkerStep(name="byte-compile check", argv=["/work/venv/bin/python", "-I", "-m", "compileall", "-q", "/work/src"], cwd="/work/src", timeout_s=120),
            WorkerStep(
                name="build wheel and sdist",
                argv=["/work/venv/bin/python", "-I", "-m", "build", "--no-isolation", "--wheel", "--sdist", "--outdir", "/out/dist", "/work/src"],
                cwd="/work/src",
                timeout_s=900,
            ),
        ]
        res, _ = ctx.run_worker("build", steps, writable_out=ctx.artefact_dir)
        if res.status == StageStatus.passed and not list((ctx.artefact_dir / "dist").glob("*.whl")):
            res.status = StageStatus.failed
            res.summary = "build finished but produced no wheel"
        return res

    def test(self, ctx: BuildContext) -> tuple[StageResult, TestReport | None]:
        if not has_tests(ctx):
            return StageResult(name="test", status=StageStatus.skipped, summary="no tests in the project"), TestReport(status=StageStatus.skipped, note="no tests supplied")
        out = ctx.build_dir / "test-results"
        clear_dir(out)
        steps = [
            WorkerStep(name="stage source", kind="copytree", argv=["/src", "/work/src"]),
            *install_project_steps(ctx, ["runtime", "dev"]),
            WorkerStep(
                name="run pytest",
                argv=["/work/venv/bin/python", "-I", "-m", "pytest", "-q", "-p", "no:cacheprovider", "--junitxml=/out/junit.xml", ctx.manifest.tests.path if (ctx.source_dir / ctx.manifest.tests.path).exists() else "."],
                cwd="/work/src",
                timeout_s=min(900, ctx.settings.limits.timeout_s),
                allow_fail=True,
                env={"PYTHONPATH": ""},
            ),
        ]
        res, wr = ctx.run_worker("test", steps, writable_out=out, mount_artefacts=True)
        report = parse_junit(out / "junit.xml")
        pytest_step = next((s for s in (wr.steps if wr else []) if s.name == "run pytest"), None)
        if res.status in (StageStatus.timed_out, StageStatus.cancelled):
            report.status = res.status
            return res, report
        if res.status == StageStatus.failed and pytest_step is None:
            report.status = StageStatus.failed
            report.note = "tests could not start: " + res.summary
            return res, report
        if pytest_step and pytest_step.exit_code == 5:
            report.status = StageStatus.skipped
            report.note = "pytest collected no tests"
            res.status, res.summary = StageStatus.skipped, "no tests collected"
            return res, report
        failed = report.failed + report.errors
        if failed or (pytest_step and pytest_step.exit_code not in (0, None)):
            res.status = StageStatus.failed
            res.diagnosis = classify(Path(res.log_path).read_text("utf-8", "replace") if res.log_path else "", "test", test_failures=max(failed, 1))
            res.summary = f"{report.passed} passed, {report.failed} failed, {report.errors} errors, {report.skipped} skipped"
            report.status = StageStatus.failed
        else:
            res.status = StageStatus.passed
            res.summary = f"{report.passed} passed, {report.skipped} skipped"
            report.status = StageStatus.passed
        return res, report

    def smoke_command(self, ctx: BuildContext) -> list[str] | None:
        scripts = ((_pyproject(ctx).get("project") or {}).get("scripts") or {})
        if scripts:
            name = sorted(scripts)[0]
            if re.fullmatch(r"[A-Za-z0-9_.-]+", name):
                return [f"/work/venv/bin/{name}"]
        entry = ctx.manifest.project.entrypoint
        if entry and entry.endswith("__main__.py"):
            parts = list(Path(entry).parent.parts)
            if parts and parts[0] == "src":
                parts = parts[1:]
            if parts:
                return ["/work/venv/bin/python", "-I", "-m", ".".join(parts)]
        if entry:
            return ["/work/venv/bin/python", "-I", f"/work/src/{entry}"]
        return None

    def smoke(self, ctx: BuildContext) -> StageResult:
        cmd = self.smoke_command(ctx)
        if cmd is None:
            return StageResult(name="smoke", status=StageStatus.failed, summary="no entry point to run", diagnosis=None)
        sm = ctx.manifest.smoke
        steps = [
            WorkerStep(name="stage source", kind="copytree", argv=["/src", "/work/src"]),
            *install_project_steps(ctx, ["runtime"]),
            WorkerStep(name="run entry point", argv=[*cmd, *sm.args], cwd="/work", timeout_s=sm.timeout_s, stdin=sm.stdin, allow_fail=True),
        ]
        res, wr = ctx.run_worker("smoke", steps, mount_artefacts=True)
        return self._judge_smoke(ctx, res, wr)

    def _judge_smoke(self, ctx: BuildContext, res: StageResult, wr) -> StageResult:
        sm = ctx.manifest.smoke
        step = next((s for s in (wr.steps if wr else []) if s.name == "run entry point"), None)
        if res.status in (StageStatus.timed_out, StageStatus.cancelled) or (step and step.timed_out):
            res.status = StageStatus.timed_out if not res.status == StageStatus.cancelled else res.status
            res.diagnosis = classify("", "smoke", timed_out=True)
            res.summary = res.diagnosis.summary
            return res
        if step is None:
            return res  # failed during install; diagnosis already attached
        output = Path(res.log_path).read_text("utf-8", "replace") if res.log_path else ""
        res.exit_code = step.exit_code
        if step.exit_code != sm.expect_exit:
            res.status = StageStatus.failed
            res.diagnosis = classify(output, "smoke", exit_code=step.exit_code)
            res.summary = f"exit code {step.exit_code} (expected {sm.expect_exit}): {res.diagnosis.summary}"
        elif sm.expect_output and sm.expect_output not in output:
            res.status = StageStatus.failed
            res.summary = f"exit code {step.exit_code}, but expected output {sm.expect_output!r} was not produced"
        else:
            res.status = StageStatus.passed
            res.summary = f"entry point ran with {sm.args or 'no arguments'} and exited {step.exit_code}"
        return res

    def package(self, ctx: BuildContext) -> tuple[StageResult, list[Artefact]]:
        arts = collect_artefacts(ctx, PY_ARTEFACTS)
        if not arts:
            return StageResult(name="package", status=StageStatus.failed, summary="no artefacts"), []
        return StageResult(name="package", status=StageStatus.passed, summary=", ".join(a.path for a in arts)), arts

    def run_instructions(self, manifest: FoundryManifest, artefacts: list[Artefact]) -> str:
        whl = next((a.path.split("/")[-1] for a in artefacts if a.kind == "wheel"), "<wheel>")
        return (
            f"# Running {manifest.project.name}\n\n"
            "Install into a fresh virtual environment (never into your system Python):\n\n"
            "```bash\npython3 -m venv .venv\n. .venv/bin/activate\n"
            f"pip install {whl}\n```\n\n"
            "If you have no network access, install the locked dependencies first from a wheelhouse built from foundry.lock.json.\n\n"
            "Then run the program by its console script name (see pyproject.toml) or with `python -m <package>`.\n"
        )

    def limitations(self) -> list[str]:
        return [
            "Wheels are pure-Python or built for the worker platform (Linux, CPython of the worker image). They are not universal binaries.",
            "The smoke check runs the entry point with the configured arguments only; it is not a full functional test.",
        ]


class FastAPIAdapter(PythonPackageAdapter):
    id = "python-fastapi"
    label = "Python FastAPI application"
    project_types = (ProjectType.python_fastapi,)

    def capability(self) -> CapabilityRow:
        return CapabilityRow(
            "python-fastapi", self.id, Support.implemented, Support.implemented, Support.implemented, Support.implemented,
            Support.implemented, Support.implemented, "wheel, sdist, OCI container image (optional profile)",
            "Smoke check starts uvicorn on an internal network and waits for a real HTTP response. Preview includes an endpoint explorer.",
        )

    def preflight(self, ctx: BuildContext) -> list[str]:
        problems = super().preflight(ctx)
        if not ctx.manifest.project.app:
            problems.append("foundry.yaml project.app must name the ASGI application, e.g. 'inventory_service.main:app'.")
        return problems

    def server_steps(self, ctx: BuildContext) -> list[WorkerStep]:
        port = ctx.manifest.preview.port
        return [
            *install_project_steps(ctx, ["runtime"]),
            WorkerStep(
                name="serve",
                argv=["/work/venv/bin/python", "-I", "-m", "uvicorn", ctx.manifest.project.app or "app:app", "--host", "0.0.0.0", "--port", str(port), "--no-access-log"],
                cwd="/work",
                timeout_s=3600,
            ),
        ]

    def server_mounts(self, ctx: BuildContext) -> list[Mount]:
        mounts = [Mount(source=ctx.source_dir, target="/src", read_only=True), Mount(source=ctx.artefact_dir, target="/artefacts", read_only=True)]
        if ctx.wheelhouse:
            mounts.append(Mount(source=ctx.wheelhouse.root, target="/wheelhouse", read_only=True))
        return mounts

    def smoke(self, ctx: BuildContext) -> StageResult:
        sm = ctx.manifest.smoke
        ctx.log("smoke: starting server in an isolated preview worker (internal network, no egress)")
        session = start_server(ctx.runtime, ctx.settings, ctx.image, self.server_steps(ctx), self.server_mounts(ctx), ctx.manifest.preview.port, kind="api")
        try:
            r = wait_ready(session, sm.http_path, sm.expect_status, timeout_s=max(sm.timeout_s, 60))
            logs = session.logs()
        finally:
            session.stop()
        log_path = ctx.logs_dir / "smoke.log"
        log_path.write_text(logs, "utf-8")
        ctx.record.logs["smoke"] = str(log_path)
        res = StageResult(name="smoke", status=StageStatus.passed if r.ready else StageStatus.failed, duration_s=round(r.elapsed_s, 2), log_path=str(log_path))
        res.details = {"readiness": r.detail, "status": r.status, "body": r.body_excerpt[:300]}
        if r.ready:
            res.summary = f"server ready: {r.detail} after {r.elapsed_s:.1f}s"
        else:
            res.diagnosis = classify(logs, "smoke")
            res.summary = f"{r.detail}. {res.diagnosis.summary}"
        return res

    def package(self, ctx: BuildContext) -> tuple[StageResult, list[Artefact]]:
        res, arts = super().package(ctx)
        if res.status != StageStatus.passed or not ctx.profile.package_container_image:
            return res, arts
        img_res, img_art = build_container_image(ctx)
        res.details["container_image"] = img_res
        if img_art:
            arts.append(img_art)
            res.summary += f", {img_art.path}"
        else:
            res.summary += f" (container image not built: {img_res.get('reason', 'unknown')})"
        return res, arts

    def run_instructions(self, manifest: FoundryManifest, artefacts: list[Artefact]) -> str:
        base = super().run_instructions(manifest, artefacts)
        base += (
            f"\nServe the API with:\n\n```bash\npython -m uvicorn {manifest.project.app} --host 127.0.0.1 --port {manifest.preview.port}\n```\n"
        )
        if any(a.kind == "container-image" for a in artefacts):
            tar = next(a.path for a in artefacts if a.kind == "container-image")
            base += (
                f"\nOr load the container image:\n\n```bash\ndocker load -i {tar.split('/')[-1]}\n"
                f"docker run --rm -p 127.0.0.1:{manifest.preview.port}:{manifest.preview.port} <image-tag-printed-by-load>\n```\n"
            )
        return base

    def limitations(self) -> list[str]:
        return super().limitations() + [
            "The container image targets linux/amd64 (or the worker host architecture) only.",
            "Deployment, TLS, authentication and production process management are outside local packaging.",
        ]


def build_container_image(ctx: BuildContext) -> tuple[dict, Artefact | None]:
    """Build an OCI image from Foundry's own Dockerfile (never the project's) with build networking disabled."""

    rt = ctx.runtime
    binary = getattr(rt, "binary", None)
    if not binary:
        return {"reason": "runtime cannot build images"}, None
    whl = sorted((ctx.artefact_dir / "dist").glob("*.whl"))
    if not whl or ctx.wheelhouse is None:
        return {"reason": "no wheel"}, None
    bctx = ctx.build_dir / "image-context"
    clear_dir(bctx)
    shutil.copytree(ctx.wheelhouse.role_dir("runtime"), bctx / "wheels")
    shutil.copyfile(whl[0], bctx / "wheels" / whl[0].name)
    shutil.copyfile(ctx.wheelhouse.root / "runtime.lock.txt", bctx / "runtime.lock.txt")
    port = ctx.manifest.preview.port
    app = ctx.manifest.project.app
    (bctx / "Dockerfile").write_text(
        f"FROM {ctx.image}\n"
        "COPY wheels /wheels\nCOPY runtime.lock.txt /runtime.lock.txt\n"
        "RUN python -m pip install --no-index --find-links /wheels --require-hashes --no-deps -r /runtime.lock.txt "
        f"&& python -m pip install --no-index --no-deps /wheels/{whl[0].name} && rm -rf /wheels\n"
        "USER 10001:10001\n"
        f"EXPOSE {port}\n"
        f'CMD ["python", "-m", "uvicorn", "{app}", "--host", "0.0.0.0", "--port", "{port}"]\n',
        "utf-8",
    )
    tag = f"aureom-foundry/{ctx.manifest.project.name.lower()}:{ctx.record.build_id}"
    from ..isolation.process import minimal_env, run_process

    env = minimal_env({"DOCKER_BUILDKIT": "1"})
    b = run_process([binary, "build", "--network", "none", "--pull=false", "-t", tag, "--label", "aureom.foundry=1", str(bctx)], env=env, timeout_s=900)
    (ctx.logs_dir / "image.log").write_text(b.stdout + b.stderr, "utf-8")
    ctx.record.logs["image"] = str(ctx.logs_dir / "image.log")
    if not b.ok:
        return {"reason": "image build failed; see image log", "tag": tag}, None
    tar = ctx.artefact_dir / "image" / f"{ctx.manifest.project.name}-image.tar"
    tar.parent.mkdir(parents=True, exist_ok=True)
    s = run_process([binary, "save", "-o", str(tar), tag], env=env, timeout_s=900)
    if not s.ok:
        return {"reason": "image save failed", "tag": tag}, None
    image_id = run_process([binary, "image", "inspect", "-f", "{{.Id}}", tag], timeout_s=30).stdout.strip()
    shutil.rmtree(bctx, ignore_errors=True)
    return {"tag": tag, "image_id": image_id}, Artefact(path=tar.relative_to(ctx.artefact_dir).as_posix(), sha256=sha256_file(tar), size=tar.stat().st_size, kind="container-image")


class PySide6Adapter(PythonPackageAdapter):
    id = "python-pyside6"
    label = "Python PySide6 desktop application"
    project_types = (ProjectType.python_pyside6,)

    def capability(self) -> CapabilityRow:
        return CapabilityRow(
            "python-pyside6", self.id, Support.implemented, Support.implemented, Support.implemented, Support.partial,
            Support.partial, Support.partial, "wheel, sdist; Linux executable (PyInstaller) where the Qt worker image is available",
            "Launch check needs the Qt worker image (docker/worker-python-qt.Dockerfile). Without it the smoke check reports 'unsupported' instead of pretending.",
        )

    def preflight(self, ctx: BuildContext) -> list[str]:
        # Qt wheels are several hundred MB once installed: give workers more scratch space and memory.
        lim = ctx.settings.limits
        ctx.state["limits"] = lim.model_copy(update={"tmpfs_mb": max(lim.tmpfs_mb, 3000), "memory_mb": max(lim.memory_mb, 4096)})
        ctx.record.notes.append("PySide6 builds use raised worker limits (3000 MB scratch, 4096 MB memory) for Qt wheels.")
        return super().preflight(ctx)

    def qt_image_available(self, ctx: BuildContext) -> bool:
        check = getattr(ctx.runtime, "image_present", None)
        return bool(check and check(ctx.settings.qt_image))

    def extra_tooling(self, ctx: BuildContext) -> list[str]:
        return ["pyinstaller"] if ctx.profile.desktop_executable else []

    def _module(self, ctx: BuildContext) -> str | None:
        entry = ctx.manifest.project.entrypoint or ""
        parts = list(Path(entry).with_suffix("").parts)
        if parts and parts[0] == "src":
            parts = parts[1:]
        return ".".join(parts) if parts else None

    def package(self, ctx: BuildContext) -> tuple[StageResult, list[Artefact]]:
        res, arts = super().package(ctx)
        if res.status != StageStatus.passed or not ctx.profile.desktop_executable:
            return res, arts
        if not self.qt_image_available(ctx):
            res.details["desktop_executable"] = "unsupported: Qt worker image not available"
            res.summary += " (desktop executable not built: Qt worker image unavailable)"
            return res, arts
        module = self._module(ctx)
        if not module:
            res.summary += " (desktop executable not built: no entry point)"
            return res, arts
        # A Foundry-authored launcher (read-only mount) so package-relative imports keep working.
        launch_dir = ctx.build_dir / "launcher"
        clear_dir(launch_dir)
        (launch_dir / "launch.py").write_text(f"import runpy\nrunpy.run_module({module!r}, run_name='__main__')\n", "utf-8")
        name = ctx.manifest.project.name
        out = ctx.build_dir / "desktop-out"
        clear_dir(out)
        steps = [
            WorkerStep(name="stage source", kind="copytree", argv=["/src", "/work/src"]),
            *install_project_steps(ctx, ["runtime", "tooling"]),
            WorkerStep(
                name="pyinstaller",
                argv=["/work/venv/bin/python", "-I", "-m", "PyInstaller", "--noconfirm", "--onedir", "--windowed", "--name", name,
                      "--collect-submodules", module.split(".")[0], "--distpath", "/out", "--workpath", "/tmp/pyi-work", "--specpath", "/tmp/pyi-spec",
                      "/foundry-launch/launch.py"],
                cwd="/work",
                timeout_s=1200,
            ),
        ]
        lim = ctx.state.get("limits") or ctx.settings.limits
        ctx.state["limits"] = lim.model_copy(update={"output_mb": max(lim.output_mb, 2048)})
        pres, _ = ctx.run_worker("desktop-package", steps, writable_out=out, mount_artefacts=True, image=ctx.settings.qt_image,
                                 extra_mounts=[Mount(source=launch_dir, target="/foundry-launch", read_only=True)])
        if pres.status != StageStatus.passed or not (out / name).is_dir():
            res.details["desktop_executable"] = f"failed: {pres.summary}"
            res.summary += f" (desktop executable FAILED: {pres.summary})"
            return res, arts
        dest = ctx.artefact_dir / "desktop" / name
        shutil.rmtree(dest.parent, ignore_errors=True)
        shutil.copytree(out / name, dest, symlinks=False)
        import platform
        import zipfile

        zpath = ctx.artefact_dir / f"{name}-linux-{platform.machine()}.zip"
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as zf:
            for p in sorted(dest.rglob("*")):
                if p.is_file() and not p.is_symlink():
                    info = zipfile.ZipInfo(f"{name}/{p.relative_to(dest).as_posix()}", date_time=(2020, 1, 1, 0, 0, 0))
                    info.external_attr = (0o755 if p.stat().st_mode & 0o111 else 0o644) << 16
                    info.compress_type = zipfile.ZIP_DEFLATED
                    zf.writestr(info, p.read_bytes())
        shutil.rmtree(out, ignore_errors=True)
        arts.append(Artefact(path=zpath.name, sha256=sha256_file(zpath), size=zpath.stat().st_size, kind="desktop-executable"))
        res.summary += f", {zpath.name} (Linux {platform.machine()} only)"
        return res, arts

    def smoke(self, ctx: BuildContext) -> StageResult:
        if not self.qt_image_available(ctx):
            return StageResult(
                name="smoke",
                status=StageStatus.unsupported,
                summary=f"Qt worker image '{ctx.settings.qt_image}' is not available; a GUI launch check cannot run. Build it from docker/worker-python-qt.Dockerfile.",
            )
        cmd = self.smoke_command(ctx)
        if not cmd:
            return StageResult(name="smoke", status=StageStatus.failed, summary="no entry point")
        env = {"QT_QPA_PLATFORM": "offscreen", "FOUNDRY_SMOKE_SECONDS": "3"}
        steps = [
            WorkerStep(name="stage source", kind="copytree", argv=["/src", "/work/src"]),
            *install_project_steps(ctx, ["runtime"]),
            WorkerStep(name="run entry point", argv=[*cmd, *ctx.manifest.smoke.args], cwd="/work", timeout_s=ctx.manifest.smoke.timeout_s, allow_fail=True, env=env),
        ]
        exe = ctx.artefact_dir / "desktop" / ctx.manifest.project.name / ctx.manifest.project.name
        if exe.is_file():
            steps.append(WorkerStep(name="run desktop executable", argv=[f"/artefacts/desktop/{ctx.manifest.project.name}/{ctx.manifest.project.name}"], cwd="/work",
                                    timeout_s=ctx.manifest.smoke.timeout_s, allow_fail=True, env=env))
        res, wr = ctx.run_worker("smoke", steps, mount_artefacts=True, image=ctx.settings.qt_image)
        res = self._judge_smoke(ctx, res, wr)
        output = Path(res.log_path).read_text("utf-8", "replace") if res.log_path else ""
        if res.status == StageStatus.timed_out and "Traceback (most recent call last)" not in output:
            # A GUI that is still running at the deadline without a traceback has launched successfully.
            res.status, res.diagnosis = StageStatus.passed, None
            res.summary = f"application launched and stayed up for {ctx.manifest.smoke.timeout_s}s without errors (offscreen)"
        elif res.status == StageStatus.passed:
            res.summary = "window launched offscreen in the Qt worker and exited cleanly"
        exe_step = next((s for s in (wr.steps if wr else []) if s.name == "run desktop executable"), None)
        if exe_step is not None and res.status == StageStatus.passed:
            if exe_step.exit_code == 0:
                res.summary += "; packaged executable also launched and exited cleanly"
            else:
                res.status = StageStatus.failed
                res.summary = f"packaged desktop executable failed to launch (exit {exe_step.exit_code})"
                res.diagnosis = classify(wr.step_output.get(exe_step.index, ""), "smoke", exit_code=exe_step.exit_code)
        return res

    def limitations(self) -> list[str]:
        return super().limitations() + [
            "Desktop executables are built per operating system; a Linux build does not run on Windows or macOS.",
            "Code signing, notarisation and installers are not part of local packaging.",
            "The launch check uses Qt's offscreen platform: it proves the window starts without error, not that it renders correctly.",
        ]


register(PythonPackageAdapter())
register(FastAPIAdapter())
register(PySide6Adapter())
