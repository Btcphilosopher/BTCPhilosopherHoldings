"""Adapter interface for language toolchains.

An adapter never reimplements a compiler or packager. It describes *bounded*
worker steps that call established toolchains (pip, build, pytest, uvicorn,
PyInstaller, ...) inside isolated workers, and interprets their results.

To add a language, subclass :class:`Adapter`, declare its capabilities, and
register it with :func:`register`. See ``docs/adapters.md``.
"""

from __future__ import annotations

import hashlib
import shutil
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Callable

from ..builds.errors import classify
from ..builds.models import Artefact, BuildRecord, StageResult, StageStatus, TestReport
from ..config import FoundrySettings
from ..dependencies.analysis import DependencyReport
from ..dependencies.environments import Wheelhouse
from ..inspection.report import InspectionReport
from ..inspection.secrets import redact
from ..isolation.commands import WorkerStep
from ..isolation.policy import Mount, WorkerPolicy, prepare_writable
from ..isolation.process import CancellationToken
from ..isolation.runtime import ContainerRuntime, WorkerResult
from ..manifests.schema import FoundryManifest, ProjectType
from ..projects.models import BuildProfile


class Support(str, Enum):
    implemented = "implemented"
    partial = "partial"
    simulated = "simulated"
    detected_only = "detected only"
    unsupported = "unsupported"
    deferred = "deferred"


@dataclass
class CapabilityRow:
    project_type: str
    adapter: str
    detect: Support
    build: Support
    test: Support
    smoke: Support
    preview: Support
    package: Support
    outputs: str
    notes: str = ""


@dataclass
class BuildContext:
    settings: FoundrySettings
    runtime: ContainerRuntime
    manifest: FoundryManifest
    report: InspectionReport
    profile: BuildProfile
    record: BuildRecord
    build_dir: Path
    cancel: CancellationToken
    emit: Callable[[str, str], None]  # (channel, text): channel is "foundry" or "project"
    wheelhouse: Wheelhouse | None = None
    state: dict = field(default_factory=dict)

    # ---- paths ------------------------------------------------------------
    @property
    def source_dir(self) -> Path:
        return self.build_dir / "source"

    @property
    def artefact_dir(self) -> Path:
        return self.build_dir / "artefacts"

    @property
    def logs_dir(self) -> Path:
        return self.build_dir / "logs"

    @property
    def deps(self) -> DependencyReport:
        return self.report.dependencies

    @property
    def image(self) -> str:
        return self.settings.python_image

    def log(self, text: str) -> None:
        line = redact(text.rstrip("\n"))
        with open(self.logs_dir / "foundry.log", "a", encoding="utf-8") as f:
            f.write(f"[{time.strftime('%H:%M:%S')}] {line}\n")
        self.emit("foundry", line)

    # ---- worker execution -------------------------------------------------
    def run_worker(
        self,
        stage: str,
        steps: list[WorkerStep],
        *,
        writable_out: Path | None = None,
        mount_artefacts: bool = False,
        network: str = "none",
        image: str | None = None,
        extra_mounts: list[Mount] | None = None,
    ) -> tuple[StageResult, WorkerResult | None]:
        if self.cancel.cancelled:
            return StageResult(name=stage, status=StageStatus.cancelled, summary="cancelled before start"), None
        mounts = [Mount(source=self.source_dir, target="/src", read_only=True)]
        if self.wheelhouse is not None and self.wheelhouse.root.exists():
            mounts.append(Mount(source=self.wheelhouse.root, target="/wheelhouse", read_only=True))
        if mount_artefacts and self.artefact_dir.exists():
            mounts.append(Mount(source=self.artefact_dir, target="/artefacts", read_only=True))
        if writable_out is not None:
            prepare_writable(writable_out)
            mounts.append(Mount(source=writable_out, target="/out", read_only=False))
        mounts += extra_mounts or []
        limits = self.state.get("limits") or self.settings.limits
        policy = WorkerPolicy(network=network, mounts=mounts, limits=limits, label=stage)  # type: ignore[arg-type]
        log_path = self.logs_dir / f"{stage}.log"
        log_file = open(log_path, "a", encoding="utf-8")

        def on_output(line: str) -> None:
            clean = redact(line)
            log_file.write(clean)
            self.emit("project", clean.rstrip("\n"))

        def on_event(ev: dict) -> None:
            if ev.get("event") == "step_start":
                self.log(f"{stage}: step {ev.get('index')} - {ev.get('name')}")
            elif ev.get("event") == "step_end":
                self.log(f"{stage}: step {ev.get('index')} exit {ev.get('exit')} in {ev.get('duration')}s")

        self.log(f"{stage}: starting isolated worker (network: {network}, image: {image or self.image})")
        try:
            wr = self.runtime.run_plan(image or self.image, steps, policy, cancel=self.cancel, on_output=on_output, on_event=on_event, name_prefix=f"foundry-{stage}")
        finally:
            log_file.close()
        self.record.logs[stage] = str(log_path)
        out_text = log_path.read_text("utf-8", errors="replace")
        status = StageStatus.passed if wr.ok else StageStatus.failed
        if wr.cancelled:
            status = StageStatus.cancelled
        elif wr.timed_out:
            status = StageStatus.timed_out
        result = StageResult(name=stage, status=status, exit_code=wr.exit_code, duration_s=round(wr.duration_s, 2), log_path=str(log_path))
        result.details["steps"] = [{"name": s.name, "exit": s.exit_code, "duration_s": s.duration_s, "timed_out": s.timed_out} for s in wr.steps]
        if wr.runtime_error:
            result.summary = f"worker failed to start: {redact(wr.runtime_error)[:300]}"
        if writable_out is not None and dir_size(writable_out) > self.settings.limits.output_mb * 1024 * 1024:
            result.status = StageStatus.failed
            result.summary = f"output exceeded the {self.settings.limits.output_mb} MB limit"
        if result.status != StageStatus.passed and result.status != StageStatus.cancelled:
            result.diagnosis = classify(out_text, stage, timed_out=wr.timed_out, exit_code=wr.exit_code)
            if not result.summary:
                result.summary = result.diagnosis.summary
        elif result.status == StageStatus.passed:
            result.summary = result.summary or "passed"
        else:
            result.summary = "cancelled"
        return result, wr


def dir_size(path: Path) -> int:
    total = 0
    for p in path.rglob("*"):
        try:
            if p.is_file() and not p.is_symlink():
                total += p.stat().st_size
        except OSError:
            pass
    return total


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(1 << 20):
            h.update(chunk)
    return h.hexdigest()


def collect_artefacts(ctx: BuildContext, patterns: dict[str, str]) -> list[Artefact]:
    """Hash artefacts matching an explicit allowlist of glob -> kind."""

    out: list[Artefact] = []
    for pattern, kind in patterns.items():
        for p in sorted(ctx.artefact_dir.glob(pattern)):
            if p.is_file() and not p.is_symlink():
                out.append(Artefact(path=p.relative_to(ctx.artefact_dir).as_posix(), sha256=sha256_file(p), size=p.stat().st_size, kind=kind))
    return out


class Adapter:
    id = "abstract"
    label = "Abstract"
    project_types: tuple[ProjectType, ...] = ()
    implemented = False

    def capability(self) -> CapabilityRow:  # pragma: no cover - interface
        raise NotImplementedError

    def preflight(self, ctx: BuildContext) -> list[str]:
        """Return blocking problems that must be fixed before any worker runs."""

        return []

    def fetch(self, ctx: BuildContext) -> StageResult:
        return StageResult(name="fetch", status=StageStatus.skipped, summary="no dependencies to fetch")

    def build(self, ctx: BuildContext) -> StageResult:
        return StageResult(name="build", status=StageStatus.unsupported, summary=f"{self.label}: build is not implemented")

    def test(self, ctx: BuildContext) -> tuple[StageResult, TestReport | None]:
        return StageResult(name="test", status=StageStatus.skipped, summary="no test support"), None

    def smoke(self, ctx: BuildContext) -> StageResult:
        return StageResult(name="smoke", status=StageStatus.skipped, summary="no smoke check support")

    def package(self, ctx: BuildContext) -> tuple[StageResult, list[Artefact]]:
        return StageResult(name="package", status=StageStatus.skipped), []

    def run_instructions(self, manifest: FoundryManifest, artefacts: list[Artefact]) -> str:
        return "See the project README."

    def limitations(self) -> list[str]:
        return []


_REGISTRY: dict[str, Adapter] = {}


def register(adapter: Adapter) -> Adapter:
    _REGISTRY[adapter.id] = adapter
    return adapter


def get_adapter(adapter_id: str) -> Adapter | None:
    from . import load_builtin  # noqa: F401  (registers built-in adapters)

    return _REGISTRY.get(adapter_id)


def all_adapters() -> list[Adapter]:
    from . import load_builtin  # noqa: F401  (registers built-in adapters)

    return list(_REGISTRY.values())


def capability_matrix() -> list[CapabilityRow]:
    return [a.capability() for a in all_adapters()]


def clear_dir(path: Path) -> None:
    shutil.rmtree(path, ignore_errors=True)
    path.mkdir(parents=True, exist_ok=True)
