"""Registers built-in adapters (imported lazily by :func:`aureom_foundry.adapters.base.get_adapter`)."""

from . import extensions, python, static_site  # noqa: F401
