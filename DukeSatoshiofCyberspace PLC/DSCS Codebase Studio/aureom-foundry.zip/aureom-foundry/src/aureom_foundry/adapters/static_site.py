"""Static HTML/CSS/JavaScript websites.

Output type is explicit: a static website export is a folder/ZIP of web files.
It is not a native desktop application.
"""

from __future__ import annotations

import re
import shutil
import zipfile
from html.parser import HTMLParser
from pathlib import Path

from ..builds.models import Artefact, StageResult, StageStatus
from ..isolation.commands import WorkerStep
from ..isolation.policy import Mount
from ..manifests.schema import FoundryManifest, ProjectType
from ..previews.server import http_get, start_server, wait_ready
from .base import Adapter, BuildContext, CapabilityRow, Support, clear_dir, sha256_file, register

# Explicit output allowlist for static sites.
SITE_SUFFIXES = {
    ".html", ".htm", ".css", ".js", ".mjs", ".json", ".svg", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".avif",
    ".ico", ".woff", ".woff2", ".ttf", ".otf", ".txt", ".xml", ".webmanifest", ".map", ".mp4", ".webm", ".mp3",
}


class _RefParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.refs: list[str] = []
        self.errors: list[str] = []

    def handle_starttag(self, tag, attrs):
        for k, v in attrs:
            if k in ("src", "href") and v:
                self.refs.append(v)


def site_files(root: Path) -> list[Path]:
    out = []
    for p in sorted(root.rglob("*")):
        rel = p.relative_to(root)
        if any(part.startswith(".") for part in rel.parts) or p.is_symlink() or not p.is_file():
            continue
        if p.suffix.lower() in SITE_SUFFIXES and rel.parts[0] not in {"node_modules", "tests"}:
            out.append(p)
    return out


def local_refs(html: str, rel_dir: str) -> list[str]:
    parser = _RefParser()
    parser.feed(html)
    out = []
    for ref in parser.refs:
        ref = ref.split("#")[0].split("?")[0]
        if not ref or re.match(r"^[a-z][a-z0-9+.-]*:", ref, re.I) or ref.startswith("//"):
            continue
        path = ref.lstrip("/") if ref.startswith("/") else (Path(rel_dir) / ref).as_posix()
        parts: list[str] = []
        for part in path.split("/"):
            if part == "..":
                if parts:
                    parts.pop()
            elif part not in ("", "."):
                parts.append(part)
        out.append("/".join(parts))
    return out


class StaticSiteAdapter(Adapter):
    id = "static-site"
    label = "Static website (HTML/CSS/JS)"
    project_types = (ProjectType.static_site,)
    implemented = True

    def capability(self) -> CapabilityRow:
        return CapabilityRow(
            "static-site", self.id, Support.implemented, Support.implemented, Support.partial, Support.implemented,
            Support.implemented, Support.implemented, "static website folder + ZIP (not a desktop app)",
            "Build validates markup and local references; tests = link/asset check. Preview is served from an isolated worker on its own origin.",
        )

    def build(self, ctx: BuildContext) -> StageResult:
        out = ctx.artefact_dir / "site"
        clear_dir(out)
        files = site_files(ctx.source_dir)
        rels = {p.relative_to(ctx.source_dir).as_posix() for p in files}
        missing: list[str] = []
        for p in files:
            if p.suffix.lower() in (".html", ".htm"):
                rel = p.relative_to(ctx.source_dir).as_posix()
                for ref in local_refs(p.read_text("utf-8", "replace"), str(Path(rel).parent)):
                    if ref and ref not in rels and f"{ref}/index.html" not in rels and ref.rstrip("/") + "/index.html" not in rels:
                        missing.append(f"{rel} -> {ref}")
        log = ctx.logs_dir / "build.log"
        lines = [f"site file: {p.relative_to(ctx.source_dir).as_posix()}" for p in files]
        lines += [f"MISSING: {m}" for m in missing]
        log.write_text("\n".join(lines) + "\n", "utf-8")
        ctx.record.logs["build"] = str(log)
        if not any(p.name.lower() == "index.html" for p in files):
            return StageResult(name="build", status=StageStatus.failed, summary="no index.html", log_path=str(log))
        if missing:
            return StageResult(name="build", status=StageStatus.failed, summary=f"{len(missing)} missing local reference(s): " + "; ".join(missing[:5]), log_path=str(log))
        for p in files:
            dest = out / p.relative_to(ctx.source_dir)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(p, dest)
        excluded = sorted(
            q.relative_to(ctx.source_dir).as_posix() for q in ctx.source_dir.rglob("*") if q.is_file() and q not in files
        )
        return StageResult(name="build", status=StageStatus.passed, summary=f"{len(files)} files staged; {len(excluded)} non-site files excluded", log_path=str(log), details={"excluded": excluded[:200]})

    def _server(self, ctx: BuildContext):
        steps = [WorkerStep(name="serve", argv=["python", "-I", "-m", "http.server", str(ctx.manifest.preview.port), "--bind", "0.0.0.0", "--directory", "/artefacts/site"], cwd="/work", timeout_s=3600)]
        mounts = [Mount(source=ctx.source_dir, target="/src", read_only=True), Mount(source=ctx.artefact_dir, target="/artefacts", read_only=True)]
        return start_server(ctx.runtime, ctx.settings, ctx.image, steps, mounts, ctx.manifest.preview.port)

    def test(self, ctx: BuildContext):
        from ..builds.models import TestCase, TestReport

        site = ctx.artefact_dir / "site"
        rep = TestReport(framework="foundry-site-check")
        html = [p for p in site.rglob("*.htm*")]
        for p in html:
            rel = p.relative_to(site).as_posix()
            text = p.read_text("utf-8", "replace")
            ok = "<title" in text.lower()
            rep.cases.append(TestCase(name=f"{rel} has a <title>", outcome="passed" if ok else "failed", message="" if ok else "missing <title>"))
            lang = re.search(r"<html[^>]*\blang=", text, re.I) is not None
            rep.cases.append(TestCase(name=f"{rel} declares a language", outcome="passed" if lang else "failed", message="" if lang else "add lang to <html>"))
        rep.total = len(rep.cases)
        rep.passed = sum(c.outcome == "passed" for c in rep.cases)
        rep.failed = rep.total - rep.passed
        rep.status = StageStatus.passed if rep.failed == 0 else StageStatus.failed
        return StageResult(name="test", status=rep.status, summary=f"{rep.passed}/{rep.total} structural checks passed"), rep

    def smoke(self, ctx: BuildContext) -> StageResult:
        session = self._server(ctx)
        checked, failures = 0, []
        try:
            r = wait_ready(session, "/index.html", 200, timeout_s=30)
            if r.ready:
                index = (ctx.artefact_dir / "site" / "index.html").read_text("utf-8", "replace")
                for ref in local_refs(index, "."):
                    status, _, _ = http_get(session.handle.host, session.handle.port, "/" + ref)
                    checked += 1
                    if status != 200:
                        failures.append(f"/{ref} -> {status}")
            logs = session.logs()
        finally:
            session.stop()
        log = ctx.logs_dir / "smoke.log"
        log.write_text(logs, "utf-8")
        ctx.record.logs["smoke"] = str(log)
        if not r.ready:
            return StageResult(name="smoke", status=StageStatus.failed, summary=r.detail, log_path=str(log))
        if failures:
            return StageResult(name="smoke", status=StageStatus.failed, summary="assets not served: " + ", ".join(failures[:5]), log_path=str(log))
        return StageResult(name="smoke", status=StageStatus.passed, summary=f"index.html served; {checked} referenced asset(s) returned 200", log_path=str(log))

    def package(self, ctx: BuildContext) -> tuple[StageResult, list[Artefact]]:
        site = ctx.artefact_dir / "site"
        zpath = ctx.artefact_dir / f"{ctx.manifest.project.name}-site.zip"
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as zf:
            for p in sorted(site.rglob("*")):
                if p.is_file():
                    info = zipfile.ZipInfo(p.relative_to(site).as_posix(), date_time=(2020, 1, 1, 0, 0, 0))
                    info.compress_type = zipfile.ZIP_DEFLATED
                    zf.writestr(info, p.read_bytes())  # fixed timestamps -> reproducible archive
        art = Artefact(path=zpath.name, sha256=sha256_file(zpath), size=zpath.stat().st_size, kind="static-site")
        return StageResult(name="package", status=StageStatus.passed, summary=f"{zpath.name} (static website, not a desktop app)"), [art]

    def run_instructions(self, manifest: FoundryManifest, artefacts: list[Artefact]) -> str:
        z = next((a.path for a in artefacts if a.kind == "static-site"), "site.zip")
        return (
            f"# Publishing {manifest.project.name}\n\nThis is a static website export, not a native application.\n\n"
            f"Unzip `{z}` and upload its contents to any static web host, or preview locally:\n\n"
            "```bash\nmkdir site && cd site && unzip ../" + z + "\npython3 -m http.server 8000 --bind 127.0.0.1\n```\n"
        )

    def limitations(self) -> list[str]:
        return [
            "Only files with web extensions are exported (explicit allowlist).",
            "External (CDN) references are not fetched or verified.",
            "Structural checks are not a substitute for browser testing across devices.",
        ]


register(StaticSiteAdapter())
