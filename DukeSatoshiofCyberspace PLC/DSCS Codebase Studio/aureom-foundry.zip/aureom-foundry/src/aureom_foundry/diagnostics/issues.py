"""Shared issue model used by inspection, dependency analysis, builds and export."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel


class Severity(str, Enum):
    info = "info"
    warning = "warning"
    error = "error"


class Issue(BaseModel):
    severity: Severity
    code: str
    message: str
    remedy: str | None = None
    path: str | None = None

    def label(self) -> str:
        tag = {"info": "INFO", "warning": "WARNING", "error": "ERROR"}[self.severity.value]
        where = f" [{self.path}]" if self.path else ""
        return f"{tag} {self.code}{where}: {self.message}"


def info(code: str, message: str, remedy: str | None = None, path: str | None = None) -> Issue:
    return Issue(severity=Severity.info, code=code, message=message, remedy=remedy, path=path)


def warning(code: str, message: str, remedy: str | None = None, path: str | None = None) -> Issue:
    return Issue(severity=Severity.warning, code=code, message=message, remedy=remedy, path=path)


def error(code: str, message: str, remedy: str | None = None, path: str | None = None) -> Issue:
    return Issue(severity=Severity.error, code=code, message=message, remedy=remedy, path=path)
