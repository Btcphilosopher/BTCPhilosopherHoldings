"""Logging with secret redaction.

Every Foundry log record passes through :class:`RedactingFilter` so a secret
that slips into an error message or a captured build log is masked before it
reaches a handler.
"""

from __future__ import annotations

import logging
from pathlib import Path

from ..inspection.secrets import redact


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:  # noqa: A003 - logging API name
        try:
            msg = record.getMessage()
        except Exception:  # pragma: no cover - defensive
            return True
        record.msg = redact(msg)
        record.args = None
        return True


_configured = False


def configure_logging(log_dir: Path | None = None, level: int = logging.INFO) -> logging.Logger:
    global _configured
    logger = logging.getLogger("aureom_foundry")
    if _configured:
        return logger
    logger.setLevel(level)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    handlers: list[logging.Handler] = [logging.StreamHandler()]
    if log_dir is not None:
        log_dir.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(log_dir / "foundry.log", encoding="utf-8"))
    for h in handlers:
        h.setFormatter(fmt)
        h.addFilter(RedactingFilter())
        logger.addHandler(h)
    logger.propagate = False
    _configured = True
    return logger


def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(f"aureom_foundry.{name}")
    if not any(isinstance(f, RedactingFilter) for f in logger.filters):
        logger.addFilter(RedactingFilter())
    return logger
