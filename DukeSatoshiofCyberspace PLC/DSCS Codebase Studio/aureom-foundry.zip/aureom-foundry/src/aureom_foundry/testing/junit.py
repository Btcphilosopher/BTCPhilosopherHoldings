"""Test-result parsing. Results are reported separately from build and smoke-check results."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

from ..builds.models import TestCase, TestReport


def parse_junit(path: Path) -> TestReport:
    rep = TestReport()
    if not path.is_file():
        rep.note = "no junit report produced"
        return rep
    try:
        tree = ET.parse(path)  # junit files are written by pytest in the worker; parsed with expat (no DTD/entities)
    except ET.ParseError:
        rep.note = "junit report could not be parsed"
        return rep
    for case in tree.iter("testcase"):
        outcome, msg = "passed", ""
        for tag in ("failure", "error", "skipped"):
            el = case.find(tag)
            if el is not None:
                outcome = {"failure": "failed", "error": "error", "skipped": "skipped"}[tag]
                msg = (el.get("message") or "")[:500]
                break
        rep.cases.append(TestCase(name=case.get("name", "?"), classname=case.get("classname", ""), outcome=outcome, message=msg, duration_s=float(case.get("time") or 0)))
    rep.total = len(rep.cases)
    rep.passed = sum(c.outcome == "passed" for c in rep.cases)
    rep.failed = sum(c.outcome == "failed" for c in rep.cases)
    rep.errors = sum(c.outcome == "error" for c in rep.cases)
    rep.skipped = sum(c.outcome == "skipped" for c in rep.cases)
    return rep
