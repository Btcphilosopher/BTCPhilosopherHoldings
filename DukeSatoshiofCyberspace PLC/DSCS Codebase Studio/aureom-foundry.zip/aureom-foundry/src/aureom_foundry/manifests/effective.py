"""Compute effective settings: manifest requests filtered through Foundry policy and user grants."""

from __future__ import annotations

from pydantic import BaseModel

from ..config import FoundrySettings, ResourceLimits
from .schema import FoundryManifest


class Decision(BaseModel):
    requested: bool
    allowed: bool
    reason: str


class EffectiveSettings(BaseModel):
    project_name: str
    project_type: str
    entrypoint: str | None
    app: str | None
    adapter: str
    profile: str
    python: str | None
    output_directory: str
    execution_network: Decision
    dependency_network: Decision
    host_filesystem: Decision
    limits: ResourceLimits
    isolation: str
    execution_enabled: bool

    def rows(self) -> list[tuple[str, str]]:
        def d(x: Decision) -> str:
            state = "ALLOWED" if x.allowed else "DENIED"
            return f"{state} (requested: {'yes' if x.requested else 'no'}) - {x.reason}"

        return [
            ("Project", f"{self.project_name} ({self.project_type})"),
            ("Entry point", self.entrypoint or self.app or "-"),
            ("Build adapter / profile", f"{self.adapter} / {self.profile}"),
            ("Runtime", f"Python {self.python}" if self.python else "-"),
            ("Output directory", self.output_directory),
            ("Isolation", self.isolation),
            ("Untrusted execution", "enabled" if self.execution_enabled else "DISABLED"),
            ("Network during execution", d(self.execution_network)),
            ("Network during dependency fetch", d(self.dependency_network)),
            ("Host filesystem access", d(self.host_filesystem)),
            (
                "Limits",
                f"{self.limits.cpus} CPU, {self.limits.memory_mb} MB RAM, {self.limits.pids} processes, "
                f"{self.limits.tmpfs_mb} MB scratch, {self.limits.output_mb} MB output, {self.limits.timeout_s}s",
            ),
        ]


def compute_effective(
    manifest: FoundryManifest,
    settings: FoundrySettings,
    grants: dict[str, bool],
    isolation_name: str,
    isolation_available: bool,
) -> EffectiveSettings:
    req_net = manifest.permissions.network
    granted_net = grants.get("execution_network", False)
    if not req_net:
        exec_net = Decision(requested=False, allowed=False, reason="not requested; workers run with no network")
    elif not granted_net:
        exec_net = Decision(requested=True, allowed=False, reason="requested by the project but not granted in Foundry")
    else:
        exec_net = Decision(requested=True, allowed=True, reason="granted by the user in Foundry settings for this project")
    dep_net = Decision(
        requested=True,
        allowed=True,
        reason=f"fetch stage only, registry {settings.registry.index_url}, binary distributions only"
        if settings.registry.only_binary
        else f"fetch stage only, registry {settings.registry.index_url}",
    )
    host_fs = Decision(
        requested=manifest.permissions.host_filesystem,
        allowed=False,
        reason="never granted: workers see only a read-only source copy and an explicit output directory",
    )
    return EffectiveSettings(
        project_name=manifest.project.name,
        project_type=manifest.project.type.value,
        entrypoint=manifest.project.entrypoint,
        app=manifest.project.app,
        adapter=manifest.build.adapter,
        profile=manifest.build.profile,
        python=manifest.runtime.python,
        output_directory=manifest.output.directory,
        execution_network=exec_net,
        dependency_network=dep_net,
        host_filesystem=host_fs,
        limits=settings.limits,
        isolation=isolation_name,
        execution_enabled=isolation_available,
    )
