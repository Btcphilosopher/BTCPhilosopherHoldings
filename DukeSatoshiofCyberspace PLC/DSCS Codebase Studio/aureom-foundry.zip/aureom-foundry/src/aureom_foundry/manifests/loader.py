"""Load, validate, save and propose ``foundry.yaml`` manifests."""

from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import ValidationError

from ..diagnostics.issues import Issue, error
from .schema import MANIFEST_FILENAME, FoundryManifest

MAX_MANIFEST_BYTES = 64_000


class ManifestError(Exception):
    def __init__(self, issues: list[Issue]):
        super().__init__("; ".join(i.message for i in issues))
        self.issues = issues


def parse_manifest_text(text: str, source: str = MANIFEST_FILENAME) -> FoundryManifest:
    if len(text.encode("utf-8")) > MAX_MANIFEST_BYTES:
        raise ManifestError([error("manifest-too-large", "foundry.yaml exceeds 64 KB", path=source)])
    try:
        data = yaml.safe_load(text)  # safe_load: no arbitrary object construction
    except yaml.YAMLError as exc:
        raise ManifestError([error("manifest-invalid-yaml", f"invalid YAML: {exc}", path=source)]) from exc
    if not isinstance(data, dict):
        raise ManifestError([error("manifest-invalid", "manifest must be a mapping", path=source)])
    try:
        return FoundryManifest.model_validate(data)
    except ValidationError as exc:
        issues = [
            error("manifest-field", f"{'.'.join(str(p) for p in e['loc'])}: {e['msg']}", path=source)
            for e in exc.errors()
        ]
        raise ManifestError(issues) from exc


def load_manifest(project_root: Path) -> FoundryManifest | None:
    path = project_root / MANIFEST_FILENAME
    if not path.is_file() or path.is_symlink():
        return None
    return parse_manifest_text(path.read_text("utf-8", errors="replace"))


def dump_manifest(manifest: FoundryManifest) -> str:
    data = manifest.model_dump(mode="json", exclude_none=True)
    return yaml.safe_dump(data, sort_keys=False)


def save_manifest(project_root: Path, manifest: FoundryManifest) -> Path:
    path = project_root / MANIFEST_FILENAME
    path.write_text(dump_manifest(manifest), "utf-8")
    return path
