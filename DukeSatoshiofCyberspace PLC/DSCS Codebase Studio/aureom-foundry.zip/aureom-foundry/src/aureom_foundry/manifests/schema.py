"""Versioned project manifest (``foundry.yaml``).

The manifest describes the project. Its ``permissions`` block is a *request*:
it never grants anything by itself. Effective permissions are computed by
:mod:`aureom_foundry.manifests.effective` from application policy and explicit
user grants stored by Foundry.
"""

from __future__ import annotations

import re
from enum import Enum
from pathlib import PurePosixPath

from pydantic import BaseModel, ConfigDict, Field, field_validator

MANIFEST_FILENAME = "foundry.yaml"
CURRENT_SCHEMA_VERSION = 1


class ProjectType(str, Enum):
    python_cli = "python-cli"
    python_fastapi = "python-fastapi"
    python_pyside6 = "python-pyside6"
    static_site = "static-site"
    node_app = "node-app"
    rust_binary = "rust-binary"
    kotlin_android = "kotlin-android"
    mixed = "mixed"
    unknown = "unknown"


def _safe_relpath(v: str, field: str) -> str:
    if not v:
        raise ValueError(f"{field} must not be empty")
    if "\x00" in v or "\\" in v:
        raise ValueError(f"{field} contains forbidden characters")
    p = PurePosixPath(v)
    if p.is_absolute() or ".." in p.parts or (len(v) > 1 and v[1] == ":"):
        raise ValueError(f"{field} must be a relative path inside the project")
    return str(p)


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class ProjectSection(_Strict):
    name: str
    type: ProjectType
    entrypoint: str | None = None
    app: str | None = None  # "package.module:variable" for ASGI apps
    description: str = ""
    version: str = "0.1.0"

    @field_validator("name")
    @classmethod
    def _name(cls, v: str) -> str:
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}", v):
            raise ValueError("name must be 1-64 chars of letters, digits, '.', '_' or '-'")
        return v

    @field_validator("entrypoint")
    @classmethod
    def _entry(cls, v: str | None) -> str | None:
        return None if v is None else _safe_relpath(v, "entrypoint")

    @field_validator("app")
    @classmethod
    def _app(cls, v: str | None) -> str | None:
        if v is not None and not re.fullmatch(r"[A-Za-z_][\w.]*:[A-Za-z_]\w*", v):
            raise ValueError("app must look like 'package.module:variable'")
        return v


class RuntimeSection(_Strict):
    python: str | None = "3.12"
    node: str | None = None

    @field_validator("python")
    @classmethod
    def _py(cls, v: str | None) -> str | None:
        if v is not None and not re.fullmatch(r"3\.\d{1,2}", v):
            raise ValueError("runtime.python must look like '3.12'")
        return v


class BuildSection(_Strict):
    adapter: str = "python-package"
    profile: str = "local-release"


class PermissionsRequest(_Strict):
    network: bool = False
    host_filesystem: bool = False


class OutputSection(_Strict):
    directory: str = "dist"

    @field_validator("directory")
    @classmethod
    def _dir(cls, v: str) -> str:
        return _safe_relpath(v, "output.directory")


class SmokeSection(_Strict):
    args: list[str] = Field(default_factory=lambda: ["--help"])
    stdin: str | None = None
    expect_exit: int = 0
    expect_output: str | None = None
    http_path: str = "/"
    expect_status: int = 200
    timeout_s: int = Field(30, ge=1, le=600)

    @field_validator("args")
    @classmethod
    def _args(cls, v: list[str]) -> list[str]:
        if len(v) > 32 or any(len(a) > 512 or "\x00" in a for a in v):
            raise ValueError("smoke args: at most 32 arguments of at most 512 characters")
        return v

    @field_validator("http_path")
    @classmethod
    def _path(cls, v: str) -> str:
        if not v.startswith("/") or "://" in v:
            raise ValueError("http_path must be an absolute path such as /health")
        return v


class TestsSection(_Strict):
    framework: str = "pytest"
    path: str = "tests"

    @field_validator("path")
    @classmethod
    def _p(cls, v: str) -> str:
        return _safe_relpath(v, "tests.path")


class PreviewSection(_Strict):
    port: int = Field(8000, ge=1024, le=65535)


class FoundryManifest(_Strict):
    schema_version: int = CURRENT_SCHEMA_VERSION
    project: ProjectSection
    runtime: RuntimeSection = Field(default_factory=RuntimeSection)
    build: BuildSection = Field(default_factory=BuildSection)
    permissions: PermissionsRequest = Field(default_factory=PermissionsRequest)
    output: OutputSection = Field(default_factory=OutputSection)
    smoke: SmokeSection = Field(default_factory=SmokeSection)
    tests: TestsSection = Field(default_factory=TestsSection)
    preview: PreviewSection = Field(default_factory=PreviewSection)

    @field_validator("schema_version")
    @classmethod
    def _ver(cls, v: int) -> int:
        if v != CURRENT_SCHEMA_VERSION:
            raise ValueError(f"unsupported schema_version {v}; this Foundry understands {CURRENT_SCHEMA_VERSION}")
        return v
