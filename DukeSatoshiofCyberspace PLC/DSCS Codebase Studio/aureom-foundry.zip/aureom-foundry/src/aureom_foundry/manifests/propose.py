"""Propose a manifest from an inspection report. Proposals are previews; nothing is written here."""

from __future__ import annotations

import re
from pathlib import Path

from pydantic import BaseModel, Field

from ..inspection.report import InspectionReport
from .schema import (
    BuildSection,
    FoundryManifest,
    ProjectSection,
    ProjectType,
    SmokeSection,
)

ADAPTER_FOR_TYPE = {
    ProjectType.python_cli: "python-package",
    ProjectType.python_fastapi: "python-fastapi",
    ProjectType.python_pyside6: "python-pyside6",
    ProjectType.static_site: "static-site",
    ProjectType.node_app: "node",
    ProjectType.rust_binary: "rust",
    ProjectType.kotlin_android: "kotlin-android",
    ProjectType.mixed: "mixed",
}


class ManifestProposal(BaseModel):
    manifest: FoundryManifest | None = None
    questions: list[str] = Field(default_factory=list)  # information that cannot be inferred safely
    notes: list[str] = Field(default_factory=list)


def safe_name(raw: str) -> str:
    name = re.sub(r"[^A-Za-z0-9._-]+", "-", raw).strip("-._") or "project"
    return name[:64]


def propose_manifest(rep: InspectionReport, name: str) -> ManifestProposal:
    out = ManifestProposal()
    t = rep.detected_type
    if t in (ProjectType.unknown,):
        out.questions.append("What kind of application is this (command-line tool, web API, desktop utility or static website)?")
        return out
    if t == ProjectType.mixed:
        out.questions.append("Several application types were detected: " + ", ".join(c.value for c in rep.candidate_types) + ". Which one should Foundry build?")
        return out
    entry = None
    app = None
    eps = rep.entry_points
    if t == ProjectType.python_cli:
        mains = [e.target for e in eps if e.kind == "python-main"]
        pkg_mains = [m for m in mains if m.endswith("__main__.py")]
        if len(pkg_mains) == 1:
            entry = pkg_mains[0]
        elif len(mains) == 1:
            entry = mains[0]
        elif mains:
            out.questions.append("Several entry points were found: " + ", ".join(mains) + ". Which one starts the program?")
            entry = (pkg_mains or mains)[0]
        else:
            out.questions.append("Which file starts the program?")
    elif t == ProjectType.python_fastapi:
        apps = [e.target for e in eps if e.kind == "asgi-app"]
        if len(apps) > 1:
            out.questions.append("Several FastAPI apps were found: " + ", ".join(apps) + ". Which one should be served?")
        app = apps[0] if apps else None
        files = [e.evidence.split(" in ")[-1] for e in eps if e.kind == "asgi-app"]
        entry = files[0] if files else None
    elif t == ProjectType.python_pyside6:
        mains = [e.target for e in eps if e.kind in ("python-main",)]
        qt = [e.target for e in eps if e.kind == "qt-app"]
        entry = next((m for m in mains if m.endswith("__main__.py")), None) or (mains[0] if mains else (qt[0] if qt else None))
    elif t == ProjectType.static_site:
        idx = [e.target for e in eps if e.kind == "html-index"]
        entry = idx[0] if idx else None
        if not entry:
            out.questions.append("Which HTML file is the home page?")
    smoke = SmokeSection()
    if t == ProjectType.python_fastapi:
        smoke = SmokeSection(args=[], http_path="/health" if _has_route(rep, "/health") else "/openapi.json")
    elif t in (ProjectType.python_pyside6, ProjectType.static_site):
        smoke = SmokeSection(args=[])
    try:
        manifest = FoundryManifest(
            project=ProjectSection(name=safe_name(name), type=t, entrypoint=entry, app=app),
            build=BuildSection(adapter=ADAPTER_FOR_TYPE.get(t, "python-package")),
            smoke=smoke,
        )
    except ValueError as exc:
        out.notes.append(f"could not build a valid manifest: {exc}")
        return out
    out.manifest = manifest
    if t in (ProjectType.node_app, ProjectType.rust_binary, ProjectType.kotlin_android):
        out.notes.append(f"{t.value} is detected only: Foundry can inspect it but has no build adapter yet.")
    return out


def _has_route(rep: InspectionReport, route: str) -> bool:
    root = Path(rep.root)
    for f in rep.files:
        if f.path.endswith(".py"):
            try:
                if re.search(r"""@\w+\.get\(\s*["']%s["']""" % re.escape(route), (root / f.path).read_text("utf-8", "replace")):
                    return True
            except OSError:
                continue
    return False
