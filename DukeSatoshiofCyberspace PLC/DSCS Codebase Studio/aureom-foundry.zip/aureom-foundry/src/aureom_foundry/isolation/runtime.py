"""Container-runtime adapter for isolated workers.

Docker and Podman are driven through their CLIs with argument arrays. Every
worker runs with:

* ``--network none`` (fetch stages: default bridge; previews: an *internal*
  network with no external route);
* a read-only root filesystem, ``--cap-drop ALL`` and ``no-new-privileges``;
* an unprivileged user;
* CPU, memory (swap disabled), PID, open-file and tmpfs-size limits;
* only Foundry-chosen bind mounts (never the home directory or engine socket);
* an explicit environment - nothing is inherited from the host;
* a host-enforced wall-clock limit followed by ``kill`` and removal.

If no runtime is available, :class:`UnavailableRuntime` is used and every
execution request fails with :class:`IsolationUnavailable`. Foundry never falls
back to running untrusted code on the host.
"""

from __future__ import annotations

import json
import re
import secrets
import shutil
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from ..diagnostics.logging import get_logger
from .commands import WorkerStep, validate_step
from .policy import Mount, WorkerPolicy, validate_mounts, worker_user
from .process import CancellationToken, minimal_env, run_process

log = get_logger("isolation")
WORKER_SCRIPT = Path(__file__).parent / "worker" / "foundry_worker.py"
LABEL = "aureom.foundry"
PREVIEW_NETWORK = "aureom-foundry-preview"


class IsolationUnavailable(RuntimeError):
    pass


@dataclass
class RuntimeStatus:
    name: str
    available: bool
    version: str = ""
    reason: str = ""
    limitations: list[str] = field(default_factory=list)


@dataclass
class StepOutcome:
    index: int
    name: str
    exit_code: int | None = None
    duration_s: float = 0.0
    timed_out: bool = False


@dataclass
class WorkerResult:
    exit_code: int | None
    output: str  # project output (stdout+stderr of steps)
    steps: list[StepOutcome]
    duration_s: float
    timed_out: bool = False
    cancelled: bool = False
    truncated: bool = False
    container: str = ""
    runtime_error: str = ""
    step_output: dict[int, str] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.exit_code == 0 and not self.timed_out and not self.cancelled and not self.runtime_error


@dataclass
class PreviewHandle:
    container: str
    host: str
    port: int
    runtime: "ContainerRuntime"


class ContainerRuntime:
    name = "abstract"

    def status(self) -> RuntimeStatus:  # pragma: no cover - interface
        raise NotImplementedError

    @property
    def available(self) -> bool:
        return self.status().available

    def run_plan(self, *args, **kwargs) -> WorkerResult:  # pragma: no cover - interface
        raise IsolationUnavailable(self.status().reason)


class UnavailableRuntime(ContainerRuntime):
    name = "none"

    def __init__(self, reason: str = "No container runtime is configured or reachable."):
        self.reason = reason

    def status(self) -> RuntimeStatus:
        return RuntimeStatus(
            name="none",
            available=False,
            reason=self.reason,
            limitations=["Inspection and editing remain available. Builds, tests and previews of untrusted code are disabled."],
        )

    def run_plan(self, *args, **kwargs) -> WorkerResult:
        raise IsolationUnavailable(self.reason)

    def start_preview(self, *args, **kwargs) -> PreviewHandle:
        raise IsolationUnavailable(self.reason)

    def cleanup_orphans(self, known: set[str] | None = None) -> list[str]:
        return []


class CliContainerRuntime(ContainerRuntime):
    """Shared implementation for Docker-compatible CLIs."""

    def __init__(self, binary: str, allowed_roots: list[Path], extra_ro_files: list[Path] | None = None):
        self.binary = binary
        self.name = Path(binary).name
        self.allowed_roots = allowed_roots
        self.extra_ro_files = [WORKER_SCRIPT, *(extra_ro_files or [])]
        self._status: RuntimeStatus | None = None
        self._lock = threading.Lock()

    # ---- discovery -----------------------------------------------------
    def status(self, refresh: bool = False) -> RuntimeStatus:
        with self._lock:
            if self._status is not None and not refresh:
                return self._status
            res = run_process([self.binary, "version", "--format", "{{.Server.Version}}"], timeout_s=15, env=minimal_env())
            if res.ok and res.stdout.strip():
                limitations = [
                    "Containers share the host kernel; a kernel or runtime vulnerability can break isolation.",
                    "Output-directory size is checked after each step rather than enforced by a quota.",
                    "The fetch stage uses the default bridge network: egress is not restricted to the registry host at the network layer.",
                ]
                if not Path("/sys/fs/cgroup/cgroup.controllers").exists():
                    limitations.append("cgroup v1 host: some limits are enforced less precisely.")
                self._status = RuntimeStatus(self.name, True, res.stdout.strip().splitlines()[0], "", limitations)
            else:
                reason = (res.stderr or res.stdout or "not reachable").strip().splitlines()
                self._status = RuntimeStatus(self.name, False, "", reason[-1][:300] if reason else "not reachable")
            return self._status

    def image_present(self, image: str) -> bool:
        return run_process([self.binary, "image", "inspect", image], timeout_s=20).ok

    def pull(self, image: str, timeout_s: int = 600) -> bool:
        return run_process([self.binary, "pull", image], timeout_s=timeout_s).ok

    # ---- argument construction -----------------------------------------
    def build_run_args(self, name: str, image: str, policy: WorkerPolicy, command: list[str], *, interactive: bool, detach: bool = False) -> list[str]:
        validate_mounts(policy.mounts, self.allowed_roots, self.extra_ro_files)
        lim = policy.limits
        args = [self.binary, "run"]
        args += ["-d"] if detach else ["--rm"]
        if interactive:
            args.append("-i")
        args += [
            "--name", name,
            "--label", f"{LABEL}=1",
            "--label", f"{LABEL}.kind={policy.label}",
            "--hostname", "foundry-worker",
            "--cpus", str(lim.cpus),
            "--memory", f"{lim.memory_mb}m",
            "--memory-swap", f"{lim.memory_mb}m",
            "--pids-limit", str(lim.pids),
            "--ulimit", f"nofile={lim.nofile}:{lim.nofile}",
            "--read-only",
            "--tmpfs", f"/tmp:rw,nosuid,nodev,size={lim.tmpfs_mb}m,mode=1777",
            "--tmpfs", f"/work:rw,nosuid,nodev,exec,size={lim.tmpfs_mb}m,mode=1777",
            "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges",
            "--user", worker_user(),
            "--workdir", "/work",
            "--log-driver", "none" if not detach else "json-file",
        ]
        if detach:
            args += ["--log-opt", "max-size=1m"]
        if policy.network == "none":
            args += ["--network", "none"]
        elif policy.network == "preview":
            args += ["--network", PREVIEW_NETWORK]
        else:  # fetch, granted
            args += ["--network", "bridge"]
        if policy.publish_port is not None:
            args += ["-p", f"127.0.0.1::{policy.publish_port}"]
        for k, v in sorted(policy.env.items()):
            if not re.fullmatch(r"[A-Z_][A-Z0-9_]*", k):
                raise ValueError(f"invalid env name {k}")
            args += ["--env", f"{k}={v}"]
        for m in policy.mounts:
            spec = f"type=bind,src={m.source.resolve()},dst={m.target}"
            if m.read_only:
                spec += ",readonly"
            args += ["--mount", spec]
        args += [
            "--mount", f"type=bind,src={WORKER_SCRIPT.resolve()},dst=/foundry/worker.py,readonly",
            "--entrypoint", "python",
            image,
        ]
        args += command
        return args

    # ---- batch execution -----------------------------------------------
    def run_plan(
        self,
        image: str,
        steps: list[WorkerStep],
        policy: WorkerPolicy,
        *,
        cancel: CancellationToken | None = None,
        on_output: Callable[[str], None] | None = None,
        on_event: Callable[[dict], None] | None = None,
        name_prefix: str = "foundry",
    ) -> WorkerResult:
        st = self.status()
        if not st.available:
            raise IsolationUnavailable(st.reason)
        steps = [validate_step(s) for s in steps]
        nonce = secrets.token_hex(16)
        name = f"{name_prefix}-{secrets.token_hex(6)}"
        plan = {
            "nonce": nonce,
            "env": dict(policy.env),  # the worker builds child environments from scratch plus this
            "steps": [s.model_dump(include={"name", "argv", "cwd", "timeout_s", "allow_fail", "env", "stdin", "kind"}) for s in steps],
        }
        args = self.build_run_args(name, image, policy, ["-I", "/foundry/worker.py"], interactive=True)
        marker = f"@@FOUNDRY:{nonce}@@"
        outcomes: dict[int, StepOutcome] = {}
        output_lines: list[str] = []

        def handle_err(line: str) -> None:
            if line.startswith(marker):
                try:
                    ev = json.loads(line[len(marker):])
                except json.JSONDecodeError:
                    return
                idx = ev.get("index")
                if ev.get("event") == "step_start" and idx is not None:
                    outcomes[idx] = StepOutcome(index=idx, name=ev.get("name", ""))
                elif ev.get("event") == "step_end" and idx is not None:
                    o = outcomes.setdefault(idx, StepOutcome(index=idx, name=ev.get("name", "")))
                    o.exit_code = ev.get("exit")
                    o.duration_s = ev.get("duration", 0.0)
                elif ev.get("event") == "step_timeout" and idx is not None:
                    outcomes.setdefault(idx, StepOutcome(index=idx, name="")).timed_out = True
                if on_event:
                    on_event(ev)
            else:
                # runtime/CLI diagnostics (not project output)
                output_lines.append(line)
                if on_output:
                    on_output(line)

        step_out: dict[int, list[str]] = {}
        current = {"step": -1}
        out_marker = f"@@FOUNDRY:{nonce}@@step:"

        def handle_out(line: str) -> None:
            if line.startswith(out_marker):
                try:
                    current["step"] = int(line[len(out_marker):].strip())
                except ValueError:
                    pass
                return
            step_out.setdefault(current["step"], []).append(line)
            if on_output:
                on_output(line)

        def kill() -> None:
            run_process([self.binary, "kill", name], timeout_s=20)
            run_process([self.binary, "rm", "-f", name], timeout_s=20)

        if cancel is not None:
            cancel.on_cancel(kill)
        total_timeout = min(policy.limits.timeout_s, sum(s.timeout_s for s in steps) + 60)
        res = run_process(
            args,
            env=minimal_env(),
            timeout_s=total_timeout,
            stdin_data=json.dumps(plan),
            max_output=policy.limits.log_bytes,
            on_stdout=handle_out,
            on_stderr=handle_err,
            on_timeout=kill,
        )
        runtime_error = ""
        if res.exit_code == 125 and not outcomes:
            runtime_error = (res.stderr or "container failed to start").strip()[-500:]
        return WorkerResult(
            exit_code=res.exit_code,
            output="".join(ln for idx in sorted(step_out) for ln in step_out[idx]),
            step_output={k: "".join(v) for k, v in step_out.items()},
            steps=[outcomes[k] for k in sorted(outcomes)],
            duration_s=res.duration_s,
            timed_out=res.timed_out or any(o.timed_out for o in outcomes.values()),
            cancelled=res.cancelled or bool(cancel is not None and cancel.cancelled),
            truncated=res.truncated,
            container=name,
            runtime_error=runtime_error,
        )

    # ---- long-running previews -----------------------------------------
    def ensure_preview_network(self) -> None:
        if run_process([self.binary, "network", "inspect", PREVIEW_NETWORK], timeout_s=20).ok:
            return
        run_process(
            [self.binary, "network", "create", "--internal", "--label", f"{LABEL}=1", PREVIEW_NETWORK],
            timeout_s=30,
        )

    def start_preview(
        self, image: str, steps: list[WorkerStep], policy: WorkerPolicy, port: int, plan_root: Path, published: bool = False
    ) -> PreviewHandle:
        """Start a detached worker that serves on ``port``. Steps run in order; the last one must serve."""

        st = self.status()
        if not st.available:
            raise IsolationUnavailable(st.reason)
        steps = [validate_step(s) for s in steps]
        if published:
            policy = policy.model_copy(update={"network": "granted", "publish_port": port})
        else:
            policy = policy.model_copy(update={"network": "preview"})
            self.ensure_preview_network()
        name = f"foundry-preview-{secrets.token_hex(6)}"
        nonce = secrets.token_hex(16)
        plan = {"nonce": nonce, "env": dict(policy.env), "steps": [s.model_dump(include={"name", "argv", "cwd", "timeout_s", "allow_fail", "env", "stdin", "kind"}) for s in steps]}
        # Detached containers cannot receive stdin after start, so the plan is passed through a
        # Foundry-written, read-only file. Preview status never relies on worker events: readiness
        # is established by an HTTP check from the host.
        plan_dir = plan_root / f"plan-{name}"
        plan_dir.mkdir(parents=True, exist_ok=True)
        (plan_dir / "plan.json").write_text(json.dumps(plan), "utf-8")
        policy = policy.model_copy(update={"mounts": [*policy.mounts, Mount(source=plan_dir, target="/foundry-plan", read_only=True)]})
        args = self.build_run_args(name, image, policy, ["-I", "-c", _PREVIEW_BOOT], interactive=False, detach=True)
        res = run_process(args, timeout_s=60)
        if not res.ok:
            shutil.rmtree(plan_dir, ignore_errors=True)
            raise IsolationUnavailable((res.stderr or "preview container failed to start").strip()[-400:])
        host, host_port = "127.0.0.1", port
        if published:
            pr = run_process([self.binary, "port", name, str(port)], timeout_s=20)
            m = re.search(r":(\d+)\s*$", pr.stdout.strip().splitlines()[0] if pr.stdout.strip() else "")
            if m:
                host_port = int(m.group(1))
        else:
            ip = run_process(
                [self.binary, "inspect", "-f", "{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}", name], timeout_s=20
            ).stdout.strip()
            host = ip or "127.0.0.1"
        return PreviewHandle(container=name, host=host, port=host_port, runtime=self)

    def preview_logs(self, handle: PreviewHandle, tail: int = 400) -> str:
        res = run_process([self.binary, "logs", "--tail", str(tail), handle.container], timeout_s=20)
        return (res.stdout + res.stderr)[-200_000:]

    def preview_running(self, handle: PreviewHandle) -> bool:
        res = run_process([self.binary, "inspect", "-f", "{{.State.Running}}", handle.container], timeout_s=20)
        return res.stdout.strip() == "true"

    def stop(self, container: str) -> None:
        run_process([self.binary, "rm", "-f", container], timeout_s=30)

    # ---- recovery --------------------------------------------------------
    def list_foundry_containers(self) -> list[str]:
        res = run_process([self.binary, "ps", "-a", "--filter", f"label={LABEL}=1", "--format", "{{.Names}}"], timeout_s=30)
        return [n for n in res.stdout.split() if n]

    def cleanup_orphans(self, known: set[str] | None = None) -> list[str]:
        removed = []
        for name in self.list_foundry_containers():
            if known and name in known:
                continue
            self.stop(name)
            removed.append(name)
        return removed


# Boot code for detached previews: it is Foundry-authored (not project code) and only
# hands the mounted plan to the worker's stdin-based entry point.
_PREVIEW_BOOT = (
    "import runpy,sys,io;"
    "sys.stdin=io.StringIO(open('/foundry-plan/plan.json').read());"
    "sys.argv=['/foundry/worker.py'];"
    "runpy.run_path('/foundry/worker.py',run_name='__main__')"
)


def detect_runtime(preference: str, allowed_roots: list[Path], extra_ro_files: list[Path] | None = None) -> ContainerRuntime:
    if preference == "none":
        return UnavailableRuntime("Isolation is disabled in settings.")
    candidates = ["docker", "podman"] if preference == "auto" else [preference]
    reasons = []
    for c in candidates:
        path = shutil.which(c)
        if not path:
            reasons.append(f"{c}: not installed")
            continue
        rt = CliContainerRuntime(path, allowed_roots, extra_ro_files)
        st = rt.status()
        if st.available:
            return rt
        reasons.append(f"{c}: {st.reason}")
    return UnavailableRuntime("No usable container runtime (" + "; ".join(reasons) + ").")
