"""Application-controlled execution policy for isolated workers."""

from __future__ import annotations

import os
from pathlib import Path, PurePosixPath
from typing import Literal

from pydantic import BaseModel, Field

from ..config import ResourceLimits
from .process import CommandRejected

NetworkMode = Literal["none", "fetch", "preview", "granted"]

# Host paths that must never be mounted into a worker.
FORBIDDEN_MOUNT_NAMES = {"docker.sock", "podman.sock", "containerd.sock", "crio.sock", "buildkitd.sock"}
FORBIDDEN_TARGETS = {"/", "/etc", "/usr", "/bin", "/sbin", "/lib", "/lib64", "/proc", "/sys", "/dev", "/var/run", "/run", "/root", "/home"}


class Mount(BaseModel):
    source: Path
    target: str
    read_only: bool = True


class WorkerPolicy(BaseModel):
    network: NetworkMode = "none"
    mounts: list[Mount] = Field(default_factory=list)
    limits: ResourceLimits = Field(default_factory=ResourceLimits)
    env: dict[str, str] = Field(default_factory=dict)
    publish_port: int | None = None  # container port to expose to the host (preview only)
    label: str = "build"


def validate_mounts(mounts: list[Mount], allowed_roots: list[Path], extra_files: list[Path] | None = None) -> None:
    """Reject mounts that would expose host secrets, the home directory or the engine socket.

    ``allowed_roots`` are Foundry-owned workspace directories; ``extra_files``
    are individual, Foundry-chosen read-only files (e.g. the worker script or a
    configured registry CA bundle).
    """

    home = Path.home().resolve()
    roots = [r.resolve() for r in allowed_roots]
    extras = {p.resolve() for p in (extra_files or [])}
    targets: set[str] = set()
    for m in mounts:
        src = m.source.resolve()
        if src.name in FORBIDDEN_MOUNT_NAMES or any(part in FORBIDDEN_MOUNT_NAMES for part in src.parts):
            raise CommandRejected(f"mounting the container engine socket is forbidden: {src}")
        if src.exists() and src.is_socket():
            raise CommandRejected(f"mounting sockets is forbidden: {src}")
        if src == home or src == Path("/"):
            raise CommandRejected("mounting the home directory or filesystem root is forbidden")
        if src in extras:
            if not m.read_only:
                raise CommandRejected(f"{src} may only be mounted read-only")
        elif not any(src == r or src.is_relative_to(r) for r in roots):
            raise CommandRejected(f"mount source outside Foundry workspaces: {src}")
        if home.is_relative_to(src):
            raise CommandRejected("mount source would expose the home directory")
        tgt = PurePosixPath(m.target)
        if not tgt.is_absolute() or ".." in tgt.parts or str(tgt) in FORBIDDEN_TARGETS:
            raise CommandRejected(f"invalid mount target: {m.target}")
        if m.target in targets:
            raise CommandRejected(f"duplicate mount target: {m.target}")
        targets.add(m.target)
        if "," in str(src) or "," in m.target:
            raise CommandRejected("mount paths must not contain commas")


def worker_user() -> str:
    """Run workers as an unprivileged user. When Foundry itself runs as root, use a fixed high UID."""

    if os.name != "posix":  # pragma: no cover
        return "10001:10001"
    uid, gid = os.getuid(), os.getgid()
    if uid == 0:
        return "10001:10001"
    return f"{uid}:{gid}"


def prepare_writable(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    if os.name == "posix" and os.getuid() == 0:
        os.chown(path, 10001, 10001)
        for root, dirs, files in os.walk(path):
            for n in dirs + files:
                try:
                    os.chown(os.path.join(root, n), 10001, 10001, follow_symlinks=False)
                except OSError:
                    pass
