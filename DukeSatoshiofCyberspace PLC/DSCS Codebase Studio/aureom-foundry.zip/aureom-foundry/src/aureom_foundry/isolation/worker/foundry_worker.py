"""Aureom Foundry in-container worker.

This file is mounted read-only into isolated workers and run as the container's
main process. It reads a validated plan from stdin (so child processes cannot
read the plan or its event nonce from disk or the environment), executes each
step as an argument array without a shell, and emits structured events on
stderr prefixed with the per-run nonce. The container exit code - which child
processes cannot forge - is the authoritative result: 0 only if every required
step succeeded.

Standard library only; runs on Python 3.8+.
"""

import json
import os
import shutil
import signal
import subprocess
import sys
import time


def main() -> int:
    plan = json.loads(sys.stdin.read())
    sys.stdin.close()
    nonce = plan["nonce"]

    def event(kind, **data):
        data["event"] = kind
        data["t"] = round(time.time(), 3)
        sys.stderr.write("@@FOUNDRY:%s@@%s\n" % (nonce, json.dumps(data)))
        sys.stderr.flush()

    base_env = {
        "PATH": "/work/venv/bin:/usr/local/bin:/usr/bin:/bin",
        "HOME": "/work/home",
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONUNBUFFERED": "1",
        "PIP_DISABLE_PIP_VERSION_CHECK": "1",
        "PIP_NO_INPUT": "1",
        "TMPDIR": "/tmp",
    }
    base_env.update(plan.get("env", {}))
    os.makedirs("/work/home", exist_ok=True)

    overall = 0
    for index, step in enumerate(plan["steps"]):
        event("step_start", index=index, name=step["name"])
        sys.stdout.write("@@FOUNDRY:%s@@step:%d\n" % (nonce, index))
        sys.stdout.flush()
        started = time.time()
        code = 0
        if step.get("kind") == "copytree":
            src, dst = step["argv"]
            try:
                shutil.copytree(src, dst, symlinks=False, dirs_exist_ok=True)
            except Exception as exc:  # report and fail the step
                sys.stdout.write("copytree failed: %s\n" % exc.__class__.__name__)
                code = 1
        else:
            env = dict(base_env)
            env.update(step.get("env", {}))
            try:
                proc = subprocess.Popen(
                    step["argv"],
                    cwd=step.get("cwd", "/work"),
                    env=env,
                    stdin=subprocess.PIPE if step.get("stdin") is not None else subprocess.DEVNULL,
                    stdout=sys.stdout,
                    stderr=sys.stdout,  # project output goes to stdout; stderr carries Foundry events
                    start_new_session=True,
                )
            except OSError as exc:
                sys.stdout.write("could not start %s: %s\n" % (step["argv"][0], exc.strerror))
                code = 127
            else:
                if step.get("stdin") is not None:
                    try:
                        proc.stdin.write(step["stdin"].encode())
                        proc.stdin.close()
                    except BrokenPipeError:
                        pass
                try:
                    code = proc.wait(timeout=step.get("timeout_s", 300))
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(proc.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    proc.wait()
                    code = 124
                    event("step_timeout", index=index)
        sys.stdout.flush()
        event("step_end", index=index, name=step["name"], exit=code, duration=round(time.time() - started, 3))
        if code != 0 and not step.get("allow_fail"):
            overall = code if 0 < code < 256 else 1
            break
    event("plan_end", exit=overall)
    return overall


if __name__ == "__main__":
    sys.exit(main())
