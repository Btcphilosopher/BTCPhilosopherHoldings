"""Host-side process management for *trusted* tools (git, the container CLI).

* argv arrays only - ``shell=True`` is never used;
* an explicit, minimal environment (host secrets are not inherited);
* timeouts and cooperative cancellation that kill the whole process group;
* bounded output capture.

Untrusted project code never runs through this module directly; it runs inside
container workers started via :mod:`aureom_foundry.isolation.runtime`.
"""

from __future__ import annotations

import os
import signal
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

SAFE_ENV_KEYS = ("PATH", "LANG", "LC_ALL", "TZ", "SYSTEMROOT", "TMPDIR", "XDG_RUNTIME_DIR", "DOCKER_HOST", "CONTAINER_HOST")


class CommandRejected(ValueError):
    pass


class CancellationToken:
    def __init__(self) -> None:
        self._event = threading.Event()
        self._callbacks: list[Callable[[], None]] = []
        self._lock = threading.Lock()

    def cancel(self) -> None:
        with self._lock:
            if self._event.is_set():
                return
            self._event.set()
            callbacks = list(self._callbacks)
        for cb in callbacks:
            try:
                cb()
            except Exception:  # pragma: no cover - best effort
                pass

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()

    def on_cancel(self, cb: Callable[[], None]) -> None:
        with self._lock:
            if not self._event.is_set():
                self._callbacks.append(cb)
                return
        cb()

    def wait(self, timeout: float) -> bool:
        return self._event.wait(timeout)


@dataclass
class ProcessResult:
    argv: list[str]
    exit_code: int | None
    stdout: str
    stderr: str
    duration_s: float
    timed_out: bool = False
    cancelled: bool = False
    truncated: bool = False

    @property
    def ok(self) -> bool:
        return self.exit_code == 0 and not self.timed_out and not self.cancelled


@dataclass
class _Capture:
    limit: int
    chunks: list[str] = field(default_factory=list)
    size: int = 0
    truncated: bool = False

    def add(self, text: str) -> None:
        if self.size >= self.limit:
            self.truncated = True
            return
        room = self.limit - self.size
        if len(text) > room:
            text = text[:room]
            self.truncated = True
        self.chunks.append(text)
        self.size += len(text)

    def text(self) -> str:
        return "".join(self.chunks) + ("\n[output truncated by Foundry]\n" if self.truncated else "")


def validate_argv(argv: list[str]) -> list[str]:
    if not isinstance(argv, (list, tuple)) or not argv:
        raise CommandRejected("command must be a non-empty argument list")
    out = []
    for a in argv:
        if not isinstance(a, str):
            raise CommandRejected("every argument must be a string")
        if "\x00" in a:
            raise CommandRejected("NUL byte in argument")
        if len(a) > 32_768:
            raise CommandRejected("argument too long")
        out.append(a)
    return out


def minimal_env(extra: dict[str, str] | None = None) -> dict[str, str]:
    env = {k: os.environ[k] for k in SAFE_ENV_KEYS if k in os.environ}
    env.setdefault("PATH", "/usr/local/bin:/usr/bin:/bin")
    env["LC_ALL"] = env.get("LC_ALL", "C.UTF-8")
    if extra:
        env.update(extra)
    return env


def _kill_group(proc: subprocess.Popen) -> None:
    try:
        if os.name == "posix":
            os.killpg(proc.pid, signal.SIGTERM)
        else:  # pragma: no cover
            proc.terminate()
    except (ProcessLookupError, PermissionError):
        return
    try:
        proc.wait(timeout=3)
    except subprocess.TimeoutExpired:
        try:
            if os.name == "posix":
                os.killpg(proc.pid, signal.SIGKILL)
            else:  # pragma: no cover
                proc.kill()
        except (ProcessLookupError, PermissionError):
            pass


def run_process(
    argv: list[str],
    *,
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
    timeout_s: float = 600,
    cancel: CancellationToken | None = None,
    stdin_data: str | None = None,
    max_output: int = 2_000_000,
    on_stdout: Callable[[str], None] | None = None,
    on_stderr: Callable[[str], None] | None = None,
    on_timeout: Callable[[], None] | None = None,
) -> ProcessResult:
    argv = validate_argv(list(argv))
    start = time.monotonic()
    out_cap, err_cap = _Capture(max_output), _Capture(max_output)
    proc = subprocess.Popen(  # noqa: S603 - argv list, no shell
        argv,
        cwd=str(cwd) if cwd else None,
        env=env if env is not None else minimal_env(),
        stdin=subprocess.PIPE if stdin_data is not None else subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        start_new_session=(os.name == "posix"),
        shell=False,
    )
    state = {"cancelled": False, "timed_out": False}

    def pump(stream, cap: _Capture, cb):
        for line in iter(stream.readline, ""):
            cap.add(line)
            if cb:
                try:
                    cb(line)
                except Exception:  # pragma: no cover
                    pass
        stream.close()

    threads = [
        threading.Thread(target=pump, args=(proc.stdout, out_cap, on_stdout), daemon=True),
        threading.Thread(target=pump, args=(proc.stderr, err_cap, on_stderr), daemon=True),
    ]
    for t in threads:
        t.start()
    if stdin_data is not None and proc.stdin:
        try:
            proc.stdin.write(stdin_data)
            proc.stdin.close()
        except BrokenPipeError:
            pass

    def do_cancel():
        state["cancelled"] = True
        _kill_group(proc)

    if cancel is not None:
        cancel.on_cancel(do_cancel)
    deadline = start + timeout_s
    while proc.poll() is None:
        if time.monotonic() > deadline:
            state["timed_out"] = True
            if on_timeout:
                try:
                    on_timeout()
                except Exception:  # pragma: no cover
                    pass
            _kill_group(proc)
            break
        time.sleep(0.05)
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:  # pragma: no cover
        _kill_group(proc)
    for t in threads:
        t.join(timeout=5)
    return ProcessResult(
        argv=argv,
        exit_code=proc.returncode,
        stdout=out_cap.text(),
        stderr=err_cap.text(),
        duration_s=time.monotonic() - start,
        timed_out=state["timed_out"],
        cancelled=state["cancelled"],
        truncated=out_cap.truncated or err_cap.truncated,
    )
