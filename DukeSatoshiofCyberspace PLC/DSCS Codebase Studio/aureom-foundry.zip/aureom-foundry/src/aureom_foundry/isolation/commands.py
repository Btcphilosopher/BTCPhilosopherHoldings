"""Validation of commands executed *inside* isolated workers.

Adapters and approved AI actions describe work as :class:`WorkerStep` objects.
Each step is validated here before it is placed in a worker plan:

* programs come from a fixed allowlist (or the worker's own venv ``bin``);
* ``python -c``/``-m`` modules are restricted to an allowlist;
* shells and command interpreters are rejected outright;
* arguments are bounded strings without NUL bytes;
* working directories and file arguments stay inside worker paths.
"""

from __future__ import annotations

import re
from pathlib import PurePosixPath
from typing import Literal

from pydantic import BaseModel, Field, field_validator

from .process import CommandRejected

WORKER_ROOTS = ("/work", "/src", "/out", "/wheelhouse", "/artefacts", "/foundry")
ALLOWED_PROGRAMS = {"python", "python3", "/usr/local/bin/python", "/usr/local/bin/python3"}
ALLOWED_PY_MODULES = {
    "pip", "venv", "build", "pytest", "uvicorn", "compileall", "http.server", "PyInstaller", "py_compile",
}
FORBIDDEN_PROGRAMS = {
    "sh", "bash", "dash", "zsh", "ksh", "csh", "fish", "busybox", "env", "sudo", "su", "nc", "ncat", "curl",
    "wget", "ssh", "scp", "docker", "podman", "kubectl", "perl", "ruby", "node", "eval", "exec",
}
PIP_FORBIDDEN_ARGS = {"--index-url", "-i", "--extra-index-url", "--trusted-host", "--find-links", "-f", "--src", "-e", "--editable", "--user", "--target", "-t", "--prefix", "--root"}


class WorkerStep(BaseModel):
    name: str
    argv: list[str]
    cwd: str = "/work"
    timeout_s: int = Field(300, ge=1, le=7200)
    allow_fail: bool = False
    env: dict[str, str] = Field(default_factory=dict)
    stdin: str | None = None
    kind: Literal["run", "copytree"] = "run"
    trusted_pip_args: bool = False  # set only by Foundry-authored steps that add the configured index

    @field_validator("name")
    @classmethod
    def _name(cls, v: str) -> str:
        if not re.fullmatch(r"[\w .,:/()+-]{1,80}", v):
            raise ValueError("step name has invalid characters")
        return v


def _inside_worker(path: str) -> bool:
    p = PurePosixPath(path)
    if not p.is_absolute() or ".." in p.parts:
        return False
    return any(str(p) == r or str(p).startswith(r + "/") for r in WORKER_ROOTS)


def validate_step(step: WorkerStep) -> WorkerStep:
    if step.kind == "copytree":
        if len(step.argv) != 2 or not all(_inside_worker(a) for a in step.argv):
            raise CommandRejected("copytree takes a source and destination inside worker paths")
        return step
    if not step.argv:
        raise CommandRejected("empty command")
    for a in step.argv:
        if not isinstance(a, str) or "\x00" in a or len(a) > 4096:
            raise CommandRejected("arguments must be strings without NUL, at most 4096 characters")
    if len(step.argv) > 256:
        raise CommandRejected("too many arguments")
    if not _inside_worker(step.cwd):
        raise CommandRejected(f"working directory outside worker paths: {step.cwd}")
    for k, v in step.env.items():
        if not re.fullmatch(r"[A-Z_][A-Z0-9_]{0,63}", k) or "\x00" in v or len(v) > 4096:
            raise CommandRejected(f"invalid environment variable {k!r}")
        if k in {"LD_PRELOAD", "LD_LIBRARY_PATH", "PYTHONSTARTUP", "BASH_ENV", "ENV"}:
            raise CommandRejected(f"environment variable {k} is not allowed")
    prog = step.argv[0]
    base = PurePosixPath(prog).name
    if base in FORBIDDEN_PROGRAMS:
        raise CommandRejected(f"program '{base}' is not allowed in workers")
    parts = PurePosixPath(prog).parts
    venv_bin = prog.startswith("/work/venv/bin/") and ".." not in parts
    built_exe = prog.startswith("/artefacts/desktop/") and ".." not in parts  # executables Foundry built
    if prog not in ALLOWED_PROGRAMS and not venv_bin and not built_exe:
        raise CommandRejected(f"program '{prog}' is not on the worker allowlist")
    if base.startswith("python") or prog in ALLOWED_PROGRAMS:
        args = step.argv[1:]
        # Allow interpreter isolation flags before -m / script.
        while args and args[0] in {"-I", "-B", "-u", "-E", "-s", "-P"}:
            args = args[1:]
        if args and args[0] == "-c":
            raise CommandRejected("'python -c' is not allowed; use a project file or an allowlisted module")
        if args and args[0] == "-m":
            if len(args) < 2 or args[1] not in ALLOWED_PY_MODULES and not _project_module(args[1]):
                raise CommandRejected(f"python module '{args[1] if len(args) > 1 else ''}' is not allowed")
            if args[1] == "pip" and not step.trusted_pip_args:
                bad = PIP_FORBIDDEN_ARGS.intersection(a.split("=")[0] for a in args[2:])
                if bad:
                    raise CommandRejected(f"pip options {sorted(bad)} are controlled by Foundry")
        elif args:
            if not _inside_worker(args[0]) and not _relative_safe(args[0]):
                raise CommandRejected(f"script path outside worker paths: {args[0]}")
    return step


def _project_module(name: str) -> bool:
    """Project modules (e.g. ``python -m example_app``) are allowed: they run inside the worker."""

    return bool(re.fullmatch(r"[A-Za-z_][\w]*(\.[A-Za-z_]\w*)*", name)) and name.split(".")[0] not in {"os", "subprocess", "pty", "code", "ctypes"}


def _relative_safe(path: str) -> bool:
    p = PurePosixPath(path)
    return not p.is_absolute() and ".." not in p.parts and bool(path)
