from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

ImportKind = Literal["folder", "files", "zip", "paste", "git", "template", "specification"]


class Project(BaseModel):
    id: str
    name: str
    type: str
    root: str  # Foundry-managed working copy (the user's original is never modified)
    created_at: str
    updated_at: str
    ai_sharing: bool = False
    active_profile: str = "local-release"
    original_source: str = ""
    needs_scaffold: bool = False
    specification: str = ""


class ImportRecord(BaseModel):
    id: str
    project_id: str
    source_kind: ImportKind
    source_ref: str
    created_at: str
    accepted_files: int
    total_bytes: int
    skipped: list[str] = Field(default_factory=list)
    symlinks: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class Checkpoint(BaseModel):
    id: str
    project_id: str
    commit_sha: str
    message: str
    kind: Literal["import", "manual", "pre-build", "pre-apply", "apply", "revert", "scaffold"]
    created_at: str


class BuildProfile(BaseModel):
    name: str = "local-release"
    run_tests: bool = True
    smoke_check: bool = True
    package_container_image: bool = False
    desktop_executable: bool = False
    description: str = "Wheel + sdist, tests, smoke check"
