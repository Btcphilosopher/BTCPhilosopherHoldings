"""Git operations on Foundry-managed working copies.

Every invocation isolates Git from user and system configuration, disables
hooks, fsmonitor and symlink checkout, and refuses network protocols, so an
imported repository cannot run code through Git configuration.
"""

from __future__ import annotations

import tempfile
from dataclasses import dataclass
from pathlib import Path

from ..isolation.process import ProcessResult, minimal_env, run_process

SAFE_CONFIG = [
    "-c", "core.hooksPath=/dev/null",
    "-c", "core.fsmonitor=false",
    "-c", "core.symlinks=false",
    "-c", "core.autocrlf=false",
    "-c", "commit.gpgsign=false",
    "-c", "tag.gpgsign=false",
    "-c", "protocol.allow=never",
    "-c", "protocol.file.allow=always",
    "-c", "submodule.recurse=false",
    "-c", "user.name=Aureom Foundry",
    "-c", "user.email=foundry@localhost",
    "-c", "init.defaultBranch=main",
    "-c", "advice.detachedHead=false",
]


class GitError(RuntimeError):
    pass


def _env() -> dict[str, str]:
    home = Path(tempfile.gettempdir()) / "aureom-foundry-git-home"
    home.mkdir(exist_ok=True)
    return minimal_env(
        {
            "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_CONFIG_GLOBAL": "/dev/null",
            "GIT_TERMINAL_PROMPT": "0",
            "GIT_ASKPASS": "/bin/false",
            "HOME": str(home),
            "GIT_AUTHOR_NAME": "Aureom Foundry",
            "GIT_AUTHOR_EMAIL": "foundry@localhost",
            "GIT_COMMITTER_NAME": "Aureom Foundry",
            "GIT_COMMITTER_EMAIL": "foundry@localhost",
        }
    )


def git(args: list[str], cwd: Path | None = None, check: bool = True, timeout_s: int = 120, stdin: str | None = None) -> ProcessResult:
    res = run_process(["git", *SAFE_CONFIG, *args], cwd=cwd, env=_env(), timeout_s=timeout_s, stdin_data=stdin)
    if check and not res.ok:
        raise GitError(f"git {args[0]} failed: {(res.stderr or res.stdout).strip()[-600:]}")
    return res


@dataclass
class GitRepo:
    root: Path

    @classmethod
    def init(cls, root: Path) -> "GitRepo":
        git(["init", "-q"], cwd=root)
        (root / ".git" / "info").mkdir(parents=True, exist_ok=True)
        (root / ".git" / "info" / "exclude").write_text("__pycache__/\n*.pyc\n.pytest_cache/\n.foundry-tmp/\n", "utf-8")
        return cls(root)

    @classmethod
    def clone_local(cls, source: Path, dest: Path) -> "GitRepo":
        git(["clone", "-q", "--no-hardlinks", "--no-checkout", str(source.resolve()), str(dest)])
        repo = cls(dest)
        git(["checkout", "-q", "HEAD", "--", "."], cwd=dest, check=False)
        # Rewrite the remote so nothing points back at the user's original repository path.
        git(["remote", "remove", "origin"], cwd=dest, check=False)
        return repo

    def is_repo(self) -> bool:
        return (self.root / ".git").is_dir()

    def head(self) -> str | None:
        res = git(["rev-parse", "HEAD"], cwd=self.root, check=False)
        return res.stdout.strip() if res.ok else None

    def has_changes(self) -> bool:
        res = git(["status", "--porcelain"], cwd=self.root)
        return bool(res.stdout.strip())

    def commit_all(self, message: str, allow_empty: bool = False) -> str:
        git(["add", "-A"], cwd=self.root)
        if not self.has_changes() and not allow_empty and self.head():
            return self.head() or ""
        args = ["commit", "-q", "-m", message]
        if allow_empty or not self.head():
            args.insert(1, "--allow-empty")
        git(args, cwd=self.root)
        return self.head() or ""

    def status(self) -> list[str]:
        return [ln for ln in git(["status", "--porcelain"], cwd=self.root).stdout.splitlines() if ln]

    def diff(self, rev_a: str | None = None, rev_b: str | None = None) -> str:
        args = ["diff", "--no-color", "--no-ext-diff", "--no-textconv"]
        if rev_a:
            args.append(rev_a)
        if rev_b:
            args.append(rev_b)
        return git(args, cwd=self.root).stdout

    def apply_check(self, patch: str, reverse: bool = False) -> tuple[bool, str]:
        args = ["apply", "--check", "--whitespace=nowarn"]
        if reverse:
            args.append("-R")
        res = git(args + ["-"], cwd=self.root, check=False, stdin=patch)
        return res.ok, (res.stderr or res.stdout).strip()

    def apply(self, patch: str, reverse: bool = False) -> None:
        args = ["apply", "--whitespace=nowarn"]
        if reverse:
            args.append("-R")
        git(args + ["-"], cwd=self.root, stdin=patch)

    def log(self, limit: int = 50) -> list[tuple[str, str, str]]:
        res = git(["log", f"-{limit}", "--format=%H%x1f%cI%x1f%s"], cwd=self.root, check=False)
        out = []
        for line in res.stdout.splitlines():
            parts = line.split("\x1f")
            if len(parts) == 3:
                out.append((parts[0], parts[1], parts[2]))
        return out

    def archive_to(self, rev: str, dest: Path) -> None:
        """Export the exact tree of ``rev`` (what a build uses) to ``dest``."""

        import io
        import subprocess
        import tarfile

        # Binary output is needed for exact bytes, so this one call uses subprocess directly
        # (still an argv list with the isolated Git environment).
        proc = subprocess.run(  # noqa: S603 - argv list, no shell
            ["git", *SAFE_CONFIG, "archive", "--format=tar", rev], cwd=self.root, env=_env(), capture_output=True, timeout=300
        )
        if proc.returncode != 0:
            raise GitError(f"git archive failed: {proc.stderr.decode('utf-8', 'replace').strip()[-400:]}")
        dest.mkdir(parents=True, exist_ok=True)
        with tarfile.open(fileobj=io.BytesIO(proc.stdout)) as tf:
            for member in tf.getmembers():
                if not (member.isfile() or member.isdir()):
                    continue  # never materialise links from history
                name = Path(member.name)
                if name.is_absolute() or ".." in name.parts:
                    continue
                tf.extract(member, dest, filter="data")

    def show_file(self, rev: str, path: str) -> str | None:
        res = git(["show", f"{rev}:{path}"], cwd=self.root, check=False)
        return res.stdout if res.ok else None
