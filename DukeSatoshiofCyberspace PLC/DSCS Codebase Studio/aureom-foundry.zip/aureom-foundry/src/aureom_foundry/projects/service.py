"""Project lifecycle: import, managed working copies, checkpoints and permissions.

Imports are copied into a Foundry-managed working copy. The user's original
folder, archive or repository is never modified, built or executed.
"""

from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

from ..config import FoundrySettings
from ..inspection.archive import ArchiveRejected, IntakeReport, safe_copy_tree, safe_extract_zip
from ..inspection.report import InspectionReport, inspect_project, list_project_files
from ..manifests.loader import load_manifest
from ..manifests.schema import MANIFEST_FILENAME
from ..persistence.db import Database, new_id, now
from .git import GitRepo
from .models import Checkpoint, ImportKind, ImportRecord, Project

MAX_PASTE_BYTES = 1_000_000


class ImportFailed(Exception):
    def __init__(self, reasons: list[str]):
        super().__init__("; ".join(reasons))
        self.reasons = reasons


def guess_paste_filename(code: str) -> str:
    head = code.lstrip()[:2000]
    if re.search(r"<!doctype html|<html", head, re.I):
        return "index.html"
    if re.search(r"^\s*(def |class |import |from \w+ import |print\()", code, re.M):
        return "main.py"
    if re.search(r"^\s*(fn main\(|use std::)", code, re.M):
        return "main.rs"
    if re.search(r"^\s*(const |let |function |import .* from ['\"])", code, re.M):
        return "main.js"
    if re.search(r"^\s*[.#]?[\w-]+\s*\{[^}]*:[^}]*\}", code, re.M):
        return "styles.css"
    return "main.txt"


class ProjectService:
    def __init__(self, settings: FoundrySettings, db: Database):
        self.settings = settings
        self.db = db

    # ---- queries --------------------------------------------------------
    def list(self) -> list[Project]:
        return [self._row(r) for r in self.db.query("SELECT * FROM projects ORDER BY updated_at DESC")]

    def get(self, project_id: str) -> Project:
        row = self.db.one("SELECT * FROM projects WHERE id = ?", (project_id,))
        if row is None:
            raise KeyError(project_id)
        return self._row(row)

    def _row(self, r) -> Project:
        doc = json.loads(r["doc"] or "{}")
        return Project(
            id=r["id"], name=r["name"], type=r["type"], root=r["root"], created_at=r["created_at"],
            updated_at=r["updated_at"], ai_sharing=bool(r["ai_sharing"]), active_profile=r["active_profile"],
            original_source=doc.get("original_source", ""), needs_scaffold=doc.get("needs_scaffold", False),
            specification=doc.get("specification", ""),
        )

    def repo(self, project: Project) -> GitRepo:
        return GitRepo(Path(project.root))

    def imports(self, project_id: str) -> list[ImportRecord]:
        return [ImportRecord.model_validate_json(r["doc"]) for r in self.db.query("SELECT doc FROM imports WHERE project_id = ? ORDER BY created_at", (project_id,))]

    def checkpoints(self, project_id: str) -> list[Checkpoint]:
        rows = self.db.query("SELECT * FROM checkpoints WHERE project_id = ? ORDER BY created_at DESC, rowid DESC", (project_id,))
        return [Checkpoint(**dict(r)) for r in rows]

    def latest_checkpoint(self, project_id: str) -> Checkpoint | None:
        cps = self.checkpoints(project_id)
        return cps[0] if cps else None

    def inspect(self, project: Project) -> InspectionReport:
        return inspect_project(Path(project.root), self.settings)

    # ---- import ---------------------------------------------------------
    def import_path(self, path: Path, name: str | None = None) -> tuple[Project, InspectionReport]:
        path = Path(path)
        if path.is_dir():
            if (path / ".git").is_dir():
                return self._import("git", str(path), name or path.name)
            return self._import("folder", str(path), name or path.name)
        if path.suffix.lower() == ".zip":
            return self._import("zip", str(path), name or path.stem)
        if path.is_file():
            return self.import_files([path], name or path.stem)
        raise ImportFailed([f"not found: {path}"])

    def import_files(self, files: list[Path], name: str) -> tuple[Project, InspectionReport]:
        return self._import("files", "\n".join(str(f) for f in files), name, files=files)

    def import_paste(self, code: str, name: str, filename: str | None = None) -> tuple[Project, InspectionReport]:
        if len(code.encode("utf-8")) > MAX_PASTE_BYTES:
            raise ImportFailed(["pasted code exceeds 1 MB"])
        fname = filename or guess_paste_filename(code)
        if "/" in fname or "\\" in fname or fname.startswith("."):
            raise ImportFailed(["file name must be a plain name"])
        return self._import("paste", fname, name, paste=(fname, code))

    def import_specification(self, brief: str, name: str) -> tuple[Project, InspectionReport]:
        """A written brief: creates an empty project that holds the brief for the AI adapter to propose changes."""

        if len(brief) > 50_000:
            raise ImportFailed(["specification exceeds 50,000 characters"])
        return self._import("specification", "brief", name, paste=("SPECIFICATION.md", brief), spec=brief)

    def _import(self, kind: ImportKind, ref: str, name: str, *, files: list[Path] | None = None, paste: tuple[str, str] | None = None, spec: str = "") -> tuple[Project, InspectionReport]:
        pid = new_id("prj")
        base = self.settings.projects_dir / pid
        src = base / "source"
        lim = self.settings.import_limits
        report = IntakeReport(source_kind=kind)
        try:
            if kind == "folder":
                report = safe_copy_tree(Path(ref), src, lim)
            elif kind == "zip":
                staging = self.settings.tmp_dir / f"zip-{pid}"
                try:
                    report = safe_extract_zip(Path(ref), staging, lim)
                    root = _single_top_dir(staging)
                    shutil.copytree(root, src, symlinks=False)
                finally:
                    shutil.rmtree(staging, ignore_errors=True)
            elif kind == "git":
                tmp_clone = self.settings.tmp_dir / f"git-{pid}"
                try:
                    GitRepo.clone_local(Path(ref), tmp_clone)
                    report = safe_copy_tree(tmp_clone, src, lim, keep_git=True)
                    report.source_kind = "git"
                finally:
                    shutil.rmtree(tmp_clone, ignore_errors=True)
            elif kind == "files":
                src.mkdir(parents=True)
                for f in files or []:
                    f = Path(f)
                    if f.is_symlink() or not f.is_file():
                        report.skipped.append(f.name)
                        continue
                    if f.stat().st_size > lim.max_file_mb * 1024 * 1024:
                        raise ArchiveRejected([f"file exceeds {lim.max_file_mb} MB: {f.name}"])
                    shutil.copyfile(f, src / f.name)
                    report.accepted_files += 1
                    report.total_bytes += f.stat().st_size
            elif kind in ("paste", "specification"):
                assert paste
                src.mkdir(parents=True)
                (src / paste[0]).write_text(paste[1], "utf-8")
                report.accepted_files, report.total_bytes = 1, len(paste[1].encode())
        except ArchiveRejected as exc:
            shutil.rmtree(base, ignore_errors=True)
            self.db.log_activity("import-rejected", f"{kind} import rejected: {exc}")
            raise ImportFailed(exc.reasons) from exc
        except Exception:
            shutil.rmtree(base, ignore_errors=True)
            raise

        repo = GitRepo(src)
        if not repo.is_repo():
            repo = GitRepo.init(src)
        commit = repo.commit_all(f"Import from {kind}")
        rep = inspect_project(src, self.settings)
        ptype = rep.detected_type.value
        needs_scaffold = kind in ("paste", "files", "specification") and load_manifest(src) is None
        ts = now()
        doc = {"original_source": ref if kind not in ("paste", "specification") else f"pasted {paste[0] if paste else ''}", "needs_scaffold": needs_scaffold, "specification": spec}
        rec = ImportRecord(
            id=new_id("imp"), project_id=pid, source_kind=kind, source_ref=doc["original_source"], created_at=ts,
            accepted_files=report.accepted_files, total_bytes=report.total_bytes, skipped=report.skipped[:200],
            symlinks=report.symlinks[:200],
        )
        with self.db.tx() as c:
            c.execute(
                "INSERT INTO projects(id, name, type, root, created_at, updated_at, doc) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (pid, name[:64] or "project", ptype, str(src), ts, ts, json.dumps(doc)),
            )
            c.execute(
                "INSERT INTO imports(id, project_id, source_kind, source_ref, created_at, doc) VALUES (?, ?, ?, ?, ?, ?)",
                (rec.id, pid, kind, rec.source_ref, ts, rec.model_dump_json()),
            )
            c.execute(
                "INSERT INTO checkpoints(id, project_id, commit_sha, message, kind, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (new_id("cp"), pid, commit, f"Import from {kind}", "import", ts),
            )
        self.db.log_activity("import", f"Imported {report.accepted_files} files ({kind}); detected {ptype}", pid)
        if report.symlinks:
            self.db.log_activity("import-warning", f"Skipped {len(report.symlinks)} symbolic link(s)", pid)
        return self.get(pid), rep

    # ---- changes --------------------------------------------------------
    def checkpoint(self, project: Project, message: str, kind: str = "manual") -> Checkpoint:
        repo = self.repo(project)
        sha = repo.commit_all(message)
        latest = self.latest_checkpoint(project.id)
        if latest and latest.commit_sha == sha and kind in ("manual", "pre-build", "pre-apply"):
            return latest
        cp = Checkpoint(id=new_id("cp"), project_id=project.id, commit_sha=sha, message=message, kind=kind, created_at=now())  # type: ignore[arg-type]
        self.db.execute(
            "INSERT INTO checkpoints(id, project_id, commit_sha, message, kind, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (cp.id, cp.project_id, cp.commit_sha, cp.message, cp.kind, cp.created_at),
        )
        self.touch(project.id)
        self.db.log_activity("checkpoint", f"Checkpoint {sha[:10]}: {message}", project.id)
        return cp

    def touch(self, project_id: str, **fields) -> None:
        ts = now()
        if "type" in fields:
            self.db.execute("UPDATE projects SET type = ?, updated_at = ? WHERE id = ?", (fields["type"], ts, project_id))
        if "ai_sharing" in fields:
            self.db.execute("UPDATE projects SET ai_sharing = ?, updated_at = ? WHERE id = ?", (int(fields["ai_sharing"]), ts, project_id))
        if "active_profile" in fields:
            self.db.execute("UPDATE projects SET active_profile = ?, updated_at = ? WHERE id = ?", (fields["active_profile"], ts, project_id))
        if "needs_scaffold" in fields:
            row = self.db.one("SELECT doc FROM projects WHERE id = ?", (project_id,))
            doc = json.loads(row["doc"]) if row else {}
            doc["needs_scaffold"] = bool(fields["needs_scaffold"])
            self.db.execute("UPDATE projects SET doc = ?, updated_at = ? WHERE id = ?", (json.dumps(doc), ts, project_id))
        self.db.execute("UPDATE projects SET updated_at = ? WHERE id = ?", (ts, project_id))

    def set_ai_sharing(self, project: Project, enabled: bool) -> None:
        self.touch(project.id, ai_sharing=enabled)
        self.db.log_activity("ai-sharing", f"External AI sharing {'ENABLED' if enabled else 'disabled'} for this project", project.id)

    def grant(self, project: Project, key: str, granted: bool) -> None:
        if key not in {"execution_network"}:
            raise ValueError(f"unknown permission {key}")
        self.db.set_permission(project.id, key, granted)
        self.db.log_activity("permission", f"{key} {'granted' if granted else 'revoked'}", project.id)

    def delete(self, project: Project) -> None:
        """Remove Foundry's managed copy and records. Never touches the original source or exports."""

        root = Path(project.root).resolve()
        managed = self.settings.projects_dir.resolve()
        if not root.is_relative_to(managed):
            raise ValueError("refusing to delete a path outside Foundry-managed projects")
        shutil.rmtree(root.parent, ignore_errors=True)
        self.db.execute("DELETE FROM projects WHERE id = ?", (project.id,))

    # ---- editor helpers ---------------------------------------------------
    def files(self, project: Project) -> list[str]:
        return list_project_files(Path(project.root))

    def has_manifest(self, project: Project) -> bool:
        return (Path(project.root) / MANIFEST_FILENAME).is_file()


def _single_top_dir(staging: Path) -> Path:
    entries = [p for p in staging.iterdir() if p.name not in {"__MACOSX"}]
    if len(entries) == 1 and entries[0].is_dir():
        return entries[0]
    return staging
