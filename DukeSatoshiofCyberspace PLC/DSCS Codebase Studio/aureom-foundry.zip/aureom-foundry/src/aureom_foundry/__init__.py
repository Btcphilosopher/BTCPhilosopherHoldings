"""AUREOM FOUNDRY - Code to Application.

Drop code -> inspect -> configure -> preview -> build -> test -> package -> export.
"""

__version__ = "0.1.0"
APP_NAME = "Aureom Foundry"
TAGLINE = "Drop your code here. Build what comes next."
