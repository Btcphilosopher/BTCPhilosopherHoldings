# {{name}}

{{description}}

## Run locally

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install .
python -m uvicorn {{package}}.main:app --host 127.0.0.1 --port 8000
```

Then open http://127.0.0.1:8000/docs.

Configuration: copy `.env.example` to `.env` and fill in values. Never commit `.env`.
{{open_questions}}
