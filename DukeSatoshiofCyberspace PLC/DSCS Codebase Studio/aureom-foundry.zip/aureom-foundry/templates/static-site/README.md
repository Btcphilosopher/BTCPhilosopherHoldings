# {{name}}

{{description}}

This is a static website. Preview it with `python3 -m http.server --bind 127.0.0.1` and
publish the exported ZIP to any static host. It is not a native desktop application.
