# {{name}}

{{description}}

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install .
python -m {{package}}
```

Desktop builds are per operating system. A Linux build does not run on Windows or macOS.
{{open_questions}}
