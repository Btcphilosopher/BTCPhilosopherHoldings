# Language adapters and the extension interface

Adapters drive existing toolchains through validated worker steps. They never reimplement a
compiler, packager or test runner.

```python
from aureom_foundry.adapters.base import Adapter, BuildContext, CapabilityRow, Support, register

class MyAdapter(Adapter):
    id = "my-lang"
    label = "My language application"
    project_types = (ProjectType.mixed,)          # add a ProjectType if needed
    implemented = True

    def capability(self) -> CapabilityRow: ...    # shown in the capability matrix
    def preflight(self, ctx) -> list[str]: ...    # blocking problems before any worker runs
    def fetch(self, ctx) -> StageResult: ...      # registry network allowed here only
    def build(self, ctx) -> StageResult: ...      # ctx.run_worker("build", steps, writable_out=...)
    def package(self, ctx) -> tuple[StageResult, list[Artefact]]: ...
    def test(self, ctx) -> tuple[StageResult, TestReport | None]: ...
    def smoke(self, ctx) -> StageResult: ...
    def run_instructions(self, manifest, artefacts) -> str: ...
    def limitations(self) -> list[str]: ...

register(MyAdapter())
```

Rules for adapter authors:

* Describe work as `WorkerStep(name, argv=[...], cwd, timeout_s, env)` — argument arrays only.
  Extend `ALLOWED_PROGRAMS` / `ALLOWED_PY_MODULES` in `isolation/commands.py` deliberately and
  add tests when a new toolchain is needed.
* Only the fetch stage may use network. Build, test and smoke stages run with `--network none`.
* Use `collect_artefacts` with an explicit glob allowlist; every artefact is hashed.
* Report `unsupported` rather than `passed` when a check cannot run (see the PySide6 adapter
  without the Qt image).
* Keep output types explicit (a static site export is not a desktop app).

## Detected-only adapters

| Adapter | Detection | Planned toolchain |
| --- | --- | --- |
| `node` | `package.json`, npm/yarn/pnpm lockfiles | `npm ci --ignore-scripts` in fetch, `npm run build` offline in a Node LTS worker |
| `rust` | `Cargo.toml`, `Cargo.lock` | `cargo fetch` then `cargo build --release --offline --locked` |
| `kotlin-android` | `AndroidManifest.xml`, Gradle with Android plugin | Gradle + Android SDK worker image; unsigned debug APK |
| `mixed` | several application types | per-component adapter chain |

These are inspected (dependencies parsed, lockfiles found) and listed honestly as
*detected only* in the capability matrix; builds report `blocked` with an explanation.

## Cross-compilation

Foundry builds for the worker platform. Wheels for pure-Python projects are portable; native
wheels, PyInstaller executables and OCI images are not. A Linux PyInstaller build does not run on
Windows or macOS — build on each target OS (or a matching worker) instead.
