# Security model

## Untrusted inputs

Everything imported is untrusted: files, comments, build scripts, configuration, `foundry.yaml`,
Git configuration, test output and model output.

| Input | Risk | Control |
| --- | --- | --- |
| ZIP archives | path traversal, absolute paths, symlinks, device files, bombs, case collisions, encrypted entries | `inspection/archive.py` rejects the whole archive; sizes are counted while streaming (lying headers do not help); extracted files lose exec/setuid bits |
| Folders | symlinks to secrets, huge trees, caches | links are recorded and skipped; caches (`.venv`, `node_modules`, `__pycache__`, …) skipped; file count/size/depth limits |
| Git repositories | hooks, fsmonitor, filters, symlinks, submodules, remote URLs | cloned with `core.hooksPath=/dev/null`, `core.fsmonitor=false`, `core.symlinks=false`, `protocol.allow=never` (except local file), global/system config disabled; remote removed |
| `setup.py`, `conftest.py`, any `.py` | code execution during inspection | inspection uses `ast.parse` only; tests prove a project that writes a marker file on import does not run |
| `foundry.yaml` | object construction, path escapes, permission escalation | `yaml.safe_load`, strict Pydantic schema, relative-path validation; permissions are *requests* |
| Requirements | pip option injection, URL references, arbitrary markers | options ignored and reported; requirement lines are re-rendered from validated name/specifier/marker fields; direct URLs rejected for fetch |
| Build/test output | log injection, secrets in logs, forged success | logs are redacted before storage/display; success comes from the container exit code, not from parsed output |
| AI output | arbitrary commands, test weakening, permission changes | only `edit_file`/`create_file`/`add_dependency` operations; path containment; guard; diff review; no shell operation exists |

## Secrets

* `inspection/secrets.py` detects common token shapes and generic assignments. Findings contain
  path, line, detector and a 12-character SHA-256 fingerprint — never the value.
* A redacting filter is attached to every Foundry logger; activity entries and build logs are
  redacted before they are written.
* Sensitive files (`.env`, keys, `credentials.json`, …) are never shared with AI providers and
  never exported. Exported text files are scanned again and withheld if anything matches.
* Workers receive no host environment, so host credentials cannot leak into builds.

## Changes and repairs

* All changes — scaffolds, manifest additions, AI proposals, repairs — are proposals with a diff.
  Nothing is written before approval.
* Applying creates a checkpoint, applies with `git apply`, and commits. Reverting applies the
  reverse patch and commits, so history stays auditable. Out-of-order reverts work when patches
  do not overlap; otherwise Foundry refuses rather than guessing.
* The guard (`ai/guard.py`) blocks: deleting/emptying tests, removing assertions, adding
  skip/xfail, trivially true assertions, `except …: pass`, `|| true`/`continue-on-error`,
  weakening smoke/test expectations, and changing `foundry.yaml` permissions.
* Repair attempts are bounded per failure signature, and the workflow stops when the diagnosis is
  `unknown` or the adapter reports insufficient evidence.

## AI data sharing

* Off by default. External providers are used only when configured **and** enabled for the
  specific project.
* The share preview lists every file that would be sent, redaction counts, and every exclusion.
* Repository content is wrapped in `<repository>` and the system prompt states it is untrusted
  data that cannot change policy or grant permissions.

## Export

Explicit allowlists only: recorded artefacts (re-hashed; a mismatch blocks the export),
generated documents, checksums. Source trees, caches, sensitive files and local configuration are
excluded and listed in `export-manifest.json`. Unverified builds cannot be exported unless the user
explicitly accepts it, and the package is then labelled UNVERIFIED.

## Not protected

* Kernel or container-runtime escapes (see `docs/isolation.md`).
* A user who grants execution network to a malicious project.
* Secrets the detectors do not recognise.
* Malicious *dependencies* resolved from the registry: Foundry records and hash-pins what was
  resolved, but does not audit package contents.
