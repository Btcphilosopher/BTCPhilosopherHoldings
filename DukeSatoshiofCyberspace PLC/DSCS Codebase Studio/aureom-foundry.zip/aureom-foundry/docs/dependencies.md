# Dependencies, toolchains and licences

Versions and licence identifiers below were read from the installed packages' own metadata
(`importlib.metadata` / wheel `METADATA`) in the delivery environment on 2026-11-26. Re-check
them for your distribution: licences can change between releases.

## Foundry runtime

| Package | Tested version | Licence (from metadata) | Used for |
| --- | --- | --- | --- |
| pydantic / pydantic-core | 2.14.4 / 2.50.5 | MIT | validated records, manifest schema |
| PyYAML | 6.0.4 | MIT | `foundry.yaml` (`safe_load` only) |
| PySide6 (+ Essentials, shiboken6) | 6.12.0 | LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only | desktop UI (optional extra `desktop`) |
| anthropic | 2.14.0 | Apache-2.0 | optional Claude adapter (extra `ai`) |
| pytest | 9.2.0 | MIT | tests (extra `dev`) |

Python standard library: `sqlite3`, `zipfile`, `ast`, `subprocess`, `http.client`, `tomllib`.

PySide6 is used under the LGPL-3.0 option: it is dynamically linked and installed as a separate
package, so users can replace it. If you ship Foundry as a frozen executable, review the LGPL
relinking obligations.

## External tools (not bundled)

| Tool | Tested version | Licence | Role |
| --- | --- | --- | --- |
| Git | 2.43.0 | GPL-2.0 | checkpoints, diffs, apply/revert |
| Docker Engine | 29.9.3 | Apache-2.0 | default container runtime |
| Podman | not tested here | Apache-2.0 | alternative runtime (same CLI contract) |

## Toolchains used inside workers (fetched per build, recorded in `foundry.lock.json`)

| Package | Version seen | Licence (from metadata) | Notes |
| --- | --- | --- | --- |
| build | 1.6.1 | MIT | PEP 517 front end |
| setuptools / wheel | 84.2.1 / 0.48.0 | MIT | default build backend |
| pytest | 9.x | MIT | test runner |
| FastAPI / uvicorn | 0.165.0 / 0.54.0 | MIT / BSD-3-Clause | example service, ASGI server |
| PyInstaller | 6.22.3 | GPLv2-or-later with bootloader exception | desktop executables; the exception allows distributing the frozen app under its own licence |
| tabulate | 0.10.0 | MIT | demo dependency |

Worker images: `python:3.12-slim` (Debian-based, Python Software Foundation licence for CPython)
and the Ubuntu 24.04-based Qt image built from `docker/worker-python-qt.Dockerfile`.

Official documentation consulted for behaviour Foundry relies on:

* Docker run reference (`--read-only`, `--tmpfs`, `--cap-drop`, `--security-opt`, `--pids-limit`,
  `--network none`, internal networks): <https://docs.docker.com/reference/cli/docker/container/run/>
* pip `download`, `--only-binary`, `--require-hashes`: <https://pip.pypa.io/en/stable/topics/secure-installs/>
* PEP 508 (requirements/markers), PEP 440 (versions), PEP 503 (name normalisation), PEP 621 (`[project]`)
* PyInstaller licence: <https://pyinstaller.org/en/stable/license.html>
* Qt for Python licensing: <https://doc.qt.io/qtforpython-6/licenses.html>
