# Isolated execution

## Policy applied to every worker

| Control | How |
| --- | --- |
| No host-home mounting | `validate_mounts` rejects the home directory, any ancestor of it, `/`, and any source outside Foundry's data directory. Individual Foundry-chosen files (worker script, registry CA bundle) are mounted read-only. |
| No engine socket | Any path containing `docker.sock`, `podman.sock`, `containerd.sock`, … and any socket file is rejected. |
| No inherited secrets | `docker run` receives no `--env` from the host; the worker builds every child environment from scratch (`HOME=/work/home`, fixed `PATH`). Tests assert that host variables are invisible. |
| Dedicated workspaces | `/work` and `/tmp` are size-limited tmpfs mounts; every build has its own directory under `<data>/builds/<id>`. |
| Read-only source | The staged checkpoint is mounted read-only at `/src`; the root filesystem is `--read-only`. |
| Explicit writable output | Only `/out` is writable, bound to a Foundry-owned directory; its size is checked against the output limit after the stage. |
| Resource limits | `--cpus`, `--memory` with `--memory-swap` equal (no swap), `--pids-limit`, `--ulimit nofile`, tmpfs sizes, per-step and per-worker wall-clock limits enforced from the host (`kill` + `rm -f`). |
| Privileges | `--cap-drop ALL`, `--security-opt no-new-privileges`, unprivileged UID (10001 when Foundry runs as root, otherwise the invoking UID). |
| Network | `--network none` by default. The **fetch** stage uses the default bridge network to reach the configured registry. Previews use an `--internal` network (no external route) and are reached from the host by container IP. A project can only get execution network if it *requests* it in `foundry.yaml` **and** the user grants it in Foundry. |
| Cancellation and cleanup | Cancelling a build kills the container; recovery removes any container labelled `aureom.foundry=1` that outlived its owner. |
| Labels | `aureom.foundry=1`, `aureom.foundry.kind=<stage>` for tracking and cleanup. |

If no runtime is reachable (`UnavailableRuntime`), inspection, editing, scaffolding and proposals
still work; builds report `blocked` and previews are refused. **Foundry never runs untrusted code
on the host.**

## Setting up a runtime

### Docker (Linux)

```bash
sudo apt install docker.io            # or Docker Engine from docker.com
sudo usermod -aG docker "$USER"       # note: docker group membership is root-equivalent
docker pull python:3.12-slim
aureom-foundry doctor
```

Rootless Docker is strongly recommended because a rootful daemon is itself a privileged service:
<https://docs.docker.com/engine/security/rootless/>.

### Podman (Linux, rootless by default)

```bash
sudo apt install podman
podman pull docker.io/library/python:3.12-slim
# Settings → Container runtime → podman  (or AUREOM_FOUNDRY_RUNTIME=podman)
```

### macOS and Windows

Docker Desktop runs containers in a VM. Builds, tests and console previews work. Container IPs
are **not** reachable from the host, so web previews and HTTP smoke checks need **Settings →
Published-port previews**. In that mode the preview container is on a bridge network and *can*
reach external hosts; Foundry says so in the preview notes.

### Worker images

* `python:3.12-slim` (default) — any image with `python` 3.8+ works; set it in Settings or
  `AUREOM_FOUNDRY_PYTHON_IMAGE`. Use a registry mirror if Docker Hub rate-limits you
  (e.g. `mirror.gcr.io/library/python:3.12-slim`).
* `aureom-foundry/worker-python-qt:1` — build from `docker/worker-python-qt.Dockerfile`. Adds Qt's
  system libraries, `libpython` and binutils for PySide6 launch checks and PyInstaller.

### TLS-inspecting proxies and private registries

Set **Settings → Registry CA bundle** (or `AUREOM_FOUNDRY_REGISTRY_CA`) to a PEM file. It is
mounted read-only into fetch workers only and passed as `PIP_CERT`. Set **Package index** for a
private index (HTTPS only). Project-supplied `--index-url` / `--extra-index-url` lines are ignored
and reported.

## Limitations (be explicit about them)

* A container is **one** isolation layer. Workers share the host kernel; a kernel or runtime
  vulnerability can break isolation. Use a VM boundary (or gVisor/Kata via the runtime's
  `--runtime` configuration) for hostile code.
* The **fetch** stage's egress is not restricted to the registry host at the network layer.
  Mitigations: no project code runs in that stage, only binary distributions are downloaded (no
  package build scripts run while network is enabled), and requirement lines are rebuilt from
  validated fields (no URLs, no pip options). Registry-only egress filtering is deferred.
* Output-directory size is checked after a stage, not enforced by a quota while writing.
* On cgroup v1 hosts some limits are enforced less precisely.
* Preview plans for detached web workers are passed through a read-only file the server process
  can read; preview readiness never trusts worker events (it is an HTTP check from the host).
* The embedded web preview is disabled when Foundry runs as root (Chromium's sandbox is
  unavailable there and Foundry will not disable it); use the system browser.
