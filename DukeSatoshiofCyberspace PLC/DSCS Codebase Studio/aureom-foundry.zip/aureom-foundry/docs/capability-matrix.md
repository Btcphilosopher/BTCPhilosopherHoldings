# Capability matrix

Generated from the adapters (`aureom-foundry capabilities`, also on **Settings → Capability
matrix**):

| Project type | Adapter | Detect | Build | Test | Smoke | Preview | Package | Outputs |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| python-cli | python-package | implemented | implemented | implemented | implemented | implemented | implemented | wheel, sdist |
| python-fastapi | python-fastapi | implemented | implemented | implemented | implemented | implemented | implemented | wheel, sdist, OCI container image (optional profile) |
| python-pyside6 | python-pyside6 | implemented | implemented | implemented | partial | partial | partial | wheel, sdist; Linux executable (PyInstaller) where the Qt worker image is available |
| static-site | static-site | implemented | implemented | partial | implemented | implemented | implemented | static website folder + ZIP (**not a desktop app**) |
| node-app | node | detected only | unsupported | unsupported | unsupported | unsupported | unsupported | planned: npm pack tarball, static bundle |
| rust-binary | rust | detected only | unsupported | unsupported | unsupported | unsupported | unsupported | planned: native binary for the worker platform |
| kotlin-android | kotlin-android | detected only | unsupported | unsupported | unsupported | unsupported | unsupported | planned: unsigned debug APK |
| mixed | mixed | detected only | unsupported | unsupported | unsupported | unsupported | unsupported | planned: one artefact set per component |

Definitions:

* **implemented** — works end to end and was verified in the delivery run.
* **partial** — works with stated limits: PySide6 smoke/preview/executable require the Qt worker
  image (without it the check reports *unsupported*, never *passed*); static-site "tests" are
  structural checks, not browser tests.
* **detected only** — the project is inspected and classified, dependencies are parsed, but no
  build adapter exists; builds report `blocked`.
* **unsupported** — not available.

Output types are always explicit. A static website export is a folder/ZIP of web files. A wheel
is a Python package, not an executable. A PyInstaller build runs only on the OS and architecture
it was built for.
