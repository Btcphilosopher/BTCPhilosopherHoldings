# Optional AI assistance

AI is optional and replaceable. The default provider is **offline** — deterministic heuristics
that never send anything anywhere.

## Interface

```python
class AIAdapter(Protocol):
    name: str
    external: bool          # True if code leaves the machine
    def run(self, task: AITask, report: InspectionReport, share: SharePreview | None) -> AIResult: ...
```

`AITask.kind`: `explain_error`, `propose_fix`, `scaffold`, `feature`, `docs`, `tests`.
`AIResult`: an explanation, a list of `Operation`s and an `insufficient_evidence` flag.

## Operations (the only things a model can ask for)

| Operation | Fields | Validation |
| --- | --- | --- |
| `edit_file` | path, content | path inside the project, not `.git`, no symlinks, file must exist, text only, ≤ 200 KB |
| `create_file` | path, content | as above; file must not exist |
| `add_dependency` | name, specifier, kind | PEP 503 name, PEP 440 specifier, edits `pyproject.toml` or `requirements*.txt` in place |

There is no "run a command" operation. `delete_file` exists only for Foundry's own scaffolder.
Operations become a unified diff; the guard (`docs/security.md`) blocks changes that would weaken
verification; the user reviews the diff; applying is checkpointed and revertible.

## Providers

### Offline (default)

* Explains every error category in plain language.
* Proposes a dependency declaration for a missing module **only** when the module-to-distribution
  mapping is known (e.g. `yaml` → `PyYAML`). Otherwise it stops and asks — it never substitutes a
  similarly named package.
* Drafts a minimal README from the manifest when none exists.
* Refuses feature generation (needs a model).

### Claude (Anthropic API)

```bash
pip install "aureom-foundry[ai]"
export ANTHROPIC_API_KEY=...        # or `ant auth login`
```

Settings → Project permissions and AI → provider `anthropic`, model (default `claude-opus-5-5`),
then enable **External sharing** for the specific project. The adapter:

* sends only the files in the approved share preview, with detected secrets redacted;
* wraps repository content in `<repository>` and instructs the model that it is untrusted data;
* requests structured JSON output against a strict schema (`output_config.format`), adaptive
  thinking, and server-side refusal fallbacks (`fallbacks: "default"`);
* treats `refusal`, `max_tokens` and schema-invalid output as "no changes proposed".

Status: implemented against `anthropic` 2.14 (parameters verified against the installed SDK) and
unit-tested with a stub client. It was not exercised against the live API in this delivery
because no API key was available.

## Consent

The share preview (Settings, or `aureom-foundry ai-sharing <project>`) lists each file that would
be sent, its size and redaction count, and every excluded file with the reason (sensitive name,
binary, too large, size budget). Explanations of build errors never need repository content and
always use the offline adapter.
