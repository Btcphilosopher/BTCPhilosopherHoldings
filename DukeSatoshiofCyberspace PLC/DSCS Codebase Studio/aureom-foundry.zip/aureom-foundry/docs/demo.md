# Demonstration

```bash
aureom-foundry demo --report demo-report.md
```

The script (`src/aureom_foundry/demo.py`) runs against real isolated workers and writes a
Markdown and JSON report. The report from the delivery run is in
[`demo-report.md`](demo-report.md) (15/15 steps passed, about 2 minutes).

| # | Step | What happens |
| --- | --- | --- |
| 1 | Drop in a project | `examples/csv-analysis-cli` is copied into a managed working copy with an import checkpoint |
| 2 | Inspect detected capabilities | type, entry points, adapter capabilities, issues — nothing executed |
| 3 | Review dependencies | declared requirements and effective settings (network denied, fetch allowed, host filesystem denied, limits) |
| 4 | Create a checkpoint | Git commit in the managed copy |
| 5 | Build in isolation | fetch (registry only) → build/package → test (offline, hash-checked installs) |
| 6 | Run a smoke check | the installed console script runs `summary data/sample.csv`; output must contain `rows: 6` |
| 7 | Preview the application | console preview: `csv-insight top … -n 2`, program output separated from Foundry's log |
| 8 | Introduce a missing dependency | a new `table` command imports `tabulate` without declaring it; inspection flags it and the build is *succeeded / tests passed / smoke failed* with diagnosis `missing-dependency` |
| 9 | Review a proposed correction | the offline adapter proposes `dependencies = ["tabulate"]` as a diff (no invented version) |
| 10 | Apply and rebuild | checkpoint → apply → rebuild: fetch locks `tabulate`, build verified |
| 11 | Export a verified artefact | wheel, sdist, lock, inventory, licences, config template, run instructions, limitations, summary, checksums; checksums re-verified |
| 12 | Revert the change | reverse patch committed; inspection reports the undeclared dependency again |
| S1 | Malicious archive | `../` traversal, absolute path, symlink entry and a ~1000:1 bomb → whole archive rejected, nothing written |
| S2 | Timed-out process | `hang-cli` never returns → smoke killed at 5 s, recorded `timed_out`, container removed, build not verified |
| S3 | Unauthorised network request | `phone-home-cli` requests network in its manifest (DENIED: not granted) and tries `example.com` → blocked, classified `network-denied`; it also sees no host secrets |

## The desktop walkthrough

1. **Import** — drop `examples/csv-analysis-cli` on the drop zone; the *Inspection result* tab
   shows detected type, entry points and issues.
2. **Dependencies** — requirements, findings, and effective settings.
3. **Projects** — *Create checkpoint*.
4. **Build** — choose a profile, *Build in isolation*. Cyan progress, Foundry log and project
   output side by side, stage table with labelled statuses.
5. **Preview** — CLI console (arguments are tokenised into an argv array), web preview with
   readiness, API explorer, desktop launch check.
6. Edit `src/csv_insight/cli.py` in the **Editor**, *Save + checkpoint*, build again.
7. **Build → Propose repair** — review the diff in the dialog, *Checkpoint and apply*, rebuild.
8. **Packages** — *Export package*; the exports list shows the ZIP and its SHA-256.
9. **Build → Revert selected** — reverts the applied proposal.

## Screenshots

| | |
| --- | --- |
| ![Import](screenshots/dark-02-import.png) | ![Editor](screenshots/dark-03-editor.png) |
| ![Build](screenshots/light-06-build.png) | ![Packages](screenshots/light-08-packages.png) |
| ![Dependencies](screenshots/dark-04-dependencies.png) | ![Settings](screenshots/dark-10-settings.png) |
