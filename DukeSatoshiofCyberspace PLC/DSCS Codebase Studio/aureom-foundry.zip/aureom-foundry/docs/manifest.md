# `foundry.yaml` reference (schema_version 1)

```yaml
schema_version: 1            # required; other versions are rejected

project:
  name: example-app          # 1-64 chars: letters, digits, . _ -
  type: python-cli           # python-cli | python-fastapi | python-pyside6 | static-site |
                             # node-app | rust-binary | kotlin-android | mixed | unknown
  entrypoint: src/example_app/__main__.py   # relative path inside the project
  app: example_app.main:app  # ASGI apps only: "package.module:variable"
  description: ""
  version: "0.1.0"

runtime:
  python: "3.12"             # must look like 3.N; checked against requires-python

build:
  adapter: python-package    # python-package | python-fastapi | python-pyside6 | static-site
  profile: local-release     # default profile name

permissions:                 # REQUESTS ONLY - Foundry policy decides
  network: false             # effective only if also granted by the user in Foundry
  host_filesystem: false     # never granted

output:
  directory: dist            # relative path

smoke:
  args: ["--help"]           # CLI: arguments for the entry point (argv array, max 32)
  stdin: null
  expect_exit: 0
  expect_output: null        # substring that must appear in the output
  http_path: /               # web/API: path polled for readiness
  expect_status: 200
  timeout_s: 30

tests:
  framework: pytest
  path: tests

preview:
  port: 8000                 # port the server listens on inside the worker
```

Validation rules:

* unknown keys are rejected at every level (`extra="forbid"`);
* paths must be relative, without `..`, backslashes or NUL;
* YAML is loaded with `safe_load` (no object construction) and capped at 64 KB;
* `http_path` must be an absolute path, never a URL.

## Effective settings

`aureom-foundry manifest <project>` (or **Dependencies → Effective settings**) shows what will
actually apply, for example:

```
Network during execution        DENIED (requested: yes) - requested by the project but not granted in Foundry
Network during dependency fetch ALLOWED (requested: yes) - fetch stage only, registry https://pypi.org/simple, binary distributions only
Host filesystem access          DENIED (requested: yes) - never granted: workers see only a read-only source copy and an explicit output directory
Limits                          1.0 CPU, 1024 MB RAM, 256 processes, 512 MB scratch, 512 MB output, 600s
```

## Build profiles

Built in: `local-release` (wheel + sdist, tests, smoke), `quick` (no tests),
`container-image` (FastAPI: adds an OCI image), `desktop-executable` (PySide6: adds a Linux
PyInstaller build). Custom profiles are stored per project in SQLite.
