# Aureom Foundry demonstration report

Duration: 123s

| # | Step | Result |
| --- | --- | --- |
| 1 | Drop in a project | PASS |
| 2 | Inspect detected capabilities | PASS |
| 3 | Review dependencies | PASS |
| 4 | Create a checkpoint | PASS |
| 5 | Build in isolation | PASS |
| 6 | Run a smoke check | PASS |
| 7 | Preview the application (console) | PASS |
| 8 | Introduce a missing dependency | PASS |
| 9 | Review a proposed correction | PASS |
| 10 | Apply and rebuild | PASS |
| 11 | Export a verified artefact | PASS |
| 12 | Revert the change | PASS |
| S1 | Malicious archive is rejected | PASS |
| S2 | Timed-out process is stopped | PASS |
| S3 | Unauthorised network request is blocked | PASS |

## 1. Drop in a project - PASS

```
Imported 11 files into managed copy <foundry-data>/projects/prj_d11874833438/source
project id prj_d11874833438
```

## 2. Inspect detected capabilities - PASS

```
type python-cli (declared in foundry.yaml; Python entry point with __main__ found)
entry points: python-main:src/csv_insight/__main__.py, console-script:csv-insight = csv_insight.cli:main
capability: build=implemented test=implemented smoke=implemented preview=implemented outputs=wheel, sdist
issues: INFO no-lockfile: No Python lockfile found. Foundry records resolved versions and hashes per build in foundry.lock.json.
```

## 3. Review dependencies - PASS

```
declared: pytest>=8 (dev), setuptools>=68 (build), wheel (build)
manifests: ['pyproject.toml']
Project: csv-insight (python-cli)
Entry point: src/csv_insight/__main__.py
Build adapter / profile: python-package / local-release
Runtime: Python 3.12
Output directory: dist
Isolation: docker
Untrusted execution: enabled
Network during execution: DENIED (requested: no) - not requested; workers run with no network
Network during dependency fetch: ALLOWED (requested: yes) - fetch stage only, registry https://pypi.org/simple, binary distributions only
Host filesystem access: DENIED (requested: no) - never granted: workers see only a read-only source copy and an explicit output directory
Limits: 1.0 CPU, 1024 MB RAM, 256 processes, 512 MB scratch, 512 MB output, 600s
```

## 4. Create a checkpoint - PASS

```
checkpoint 07cdd10101792877a5a1bfd304ee5f6d3734ebc0
```

## 5. Build in isolation - PASS

```
build bld_0a0272305aa4 succeeded
fetch: passed - downloaded and locked 10 files
build: passed - passed
package: passed - dist/csv_insight-1.0.0-py3-none-any.whl, dist/csv_insight-1.0.0.tar.gz
test: passed - 5 passed, 0 skipped
smoke: passed - entry point ran with ['summary', '/work/src/data/sample.csv'] and exited 0
lock: <foundry-data>/cache/wheelhouse/981946820466e022de697ddf/foundry.lock.json sha256:0e04feb3f1d5bad114c8f996e5ecec51d07562b72b569936bd4839dfbecbf5c6
toolchain: {'foundry': '0.1.0', 'container-runtime': 'docker 29.9.3', 'python': '3.12.16', 'pip': '25.0.1', 'worker-image': 'mirror.gcr.io/library/python:3.12-slim'}
```

## 6. Run a smoke check - PASS

```
smoke: passed; tests: passed; verified: True
```

## 7. Preview the application (console) - PASS

```
$ csv-insight top data/sample.csv --column revenue -n 2
date,region,product,units,revenue
2026-01-06,East,Widget,20,400.00
2026-01-07,South,Gadget,5,275.00
[exit 0]
```

## 8. Introduce a missing dependency - PASS

```
inspection: ERROR undeclared-dependency [src/csv_insight/cli.py]: 'tabulate' is imported but its distribution 'tabulate' is not declared.
build bld_7f306161f27d: succeeded, tests passed, smoke failed
diagnosis: [missing-dependency] Module 'tabulate' is not installed in the isolated environment.
```

## 9. Review a proposed correction - PASS

```
'tabulate' is imported (see the traceback) but its distribution 'tabulate' is not declared. Proposed: declare 'tabulate' as a runtime dependency. No version is invented; the resolved version and hash will be recorded in the build lock.

diff --git a/pyproject.toml b/pyproject.toml
--- a/pyproject.toml
+++ b/pyproject.toml
@@ -9,7 +9,7 @@
 readme = "README.md"
 requires-python = ">=3.10"
 license = { text = "MIT" }
-dependencies = []
+dependencies = ["tabulate"]
 
 [project.optional-dependencies]
 dev = ["pytest>=8"]

```

## 10. Apply and rebuild - PASS

```
applied prop_3dacd7e17a14 as c261d0a15def
build bld_2ae1da847536: succeeded, tests passed, smoke passed, verified True
fetch: passed - downloaded and locked 11 files
build: passed - passed
package: passed - dist/csv_insight-1.0.0-py3-none-any.whl, dist/csv_insight-1.0.0.tar.gz
test: passed - 5 passed, 0 skipped
smoke: passed - entry point ran with ['table', '/work/src/data/sample.csv'] and exited 0
```

## 11. Export a verified artefact - PASS

```
<foundry-data>/exports/csv-insight-bld_2ae1da847536.zip
sha256 b02a30aa6740489d9731df22376fe63a9278cab0722059d0ac8b030983512d0b
included: artefacts/csv_insight-1.0.0-py3-none-any.whl, artefacts/csv_insight-1.0.0.tar.gz, artefacts/foundry.lock.json, dependency-inventory.json, LICENSES.md, config.example.toml, RUN.md, LIMITATIONS.md, BUILD-SUMMARY.md, build-record.json, CHECKSUMS.sha256
excluded: source tree (not part of the allowlist; sdist/wheel carry the distributable source)
checksum mismatches: none
```

## 12. Revert the change - PASS

```
reverted with commit f5305ab6705f; inspection again reports: ERROR undeclared-dependency [src/csv_insight/cli.py]: 'tabulate' is imported but its distribution 'tabulate' is not declared.
```

## S1. Malicious archive is rejected - PASS

```
rejected:
unsafe path rejected: 'project/../../escaped.txt'
unsafe path rejected: '/etc/foundry-absolute.txt'
symbolic link entry rejected: 'project/link-to-home'
suspicious compression ratio (possible archive bomb): 'project/bomb.txt'
files written outside staging: none
```

## S2. Timed-out process is stopped - PASS

```
smoke: timed_out - The smoke stage exceeded its time limit and was stopped.
verified: False
leftover worker containers: none
```

## S3. Unauthorised network request is blocked - PASS

```
manifest requests network: True; effective: DENIED (requested by the project but not granted in Foundry)
host filesystem: DENIED
smoke: failed; diagnosis: network-denied - The program attempted a network connection; workers have no network unless it is granted.
environment secrets visible: []
```
