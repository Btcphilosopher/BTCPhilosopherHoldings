# Architecture

Foundry is a single Python process (desktop UI or CLI) that orchestrates **isolated workers**.
Foundry itself only ever reads project files; anything that executes project code, build scripts
or package installers happens inside a container worker.

```
 ┌──────────────── Foundry process (trusted) ─────────────────┐
 │ desktop/ (PySide6)   cli.py                                │
 │        │                 │                                 │
 │        └──── Foundry facade (foundry.py) ──────────┐       │
 │  projects/  inspection/  manifests/  dependencies/ │       │
 │  scaffolding/  ai/  builds/  previews/  packaging/ │       │
 │  persistence/ (SQLite)   projects/git.py (Git)     │       │
 │                                                    ▼       │
 │                 isolation/runtime.py ── argv arrays ──► docker / podman CLI
 └──────────────────────────────────────────────────────────── │ ───────────┘
                                                               ▼
        ┌──────────── worker container (untrusted) ─────────────┐
        │ /foundry/worker.py (read-only, Foundry-authored)        │
        │ /src (read-only checkpoint)  /wheelhouse (read-only)    │
        │ /out (explicit writable)     /work, /tmp (tmpfs)        │
        │ no network · read-only root · cap-drop ALL · non-root   │
        └─────────────────────────────────────────────────────────┘
```

## Data flow

1. **Import** (`projects/service.py`): folder → `safe_copy_tree`; ZIP → `audit_zip` + `safe_extract_zip`;
   Git → clone with hooks/fsmonitor/symlinks disabled, then `safe_copy_tree`; files/paste/brief →
   written directly. The result is a **managed working copy** under
   `<data>/projects/<id>/source`, initialised as a Git repository with an *import* checkpoint.
2. **Inspect** (`inspection/report.py`): inventory with SHA-256 per file, languages, entry points
   (via `ast`, never import), manifests and lockfiles, build configs, secrets (location and
   fingerprint only), sensitive file names, missing items, project-type classification, and the
   dependency report (`dependencies/analysis.py`).
3. **Configure** (`manifests/`): `foundry.yaml` is validated by Pydantic (`extra="forbid"`, safe
   relative paths, versioned schema). If missing, a manifest is *proposed* and applied only through
   a reviewable proposal. `manifests/effective.py` merges manifest *requests* with application
   policy and explicit user grants.
4. **Build** (`builds/service.py`):
   * checkpoint (`pre-build`), then `git archive` of that exact commit into
     `<data>/builds/<build_id>/source` — the build never sees uncommitted edits;
   * source hash = SHA-256 over sorted `(path, file-hash)` pairs of the staged tree;
   * adapter stages: **fetch** → **build** → **package** → **test** → **smoke**;
   * the record is persisted after every stage (heartbeat), so a crash leaves evidence.
5. **Preview** (`previews/`): CLI console runs, web/API servers on an internal network with HTTP
   readiness checks, API explorer via OpenAPI, desktop launch checks in the Qt worker.
6. **Repair** (`builds/repair.py`, `ai/`): diagnosis → adapter proposes *operations* → validated
   change set + guard → diff review → checkpoint → apply → rebuild. Revert applies the reverse
   patch as a new commit.
7. **Export** (`packaging/export.py`): allowlisted artefacts re-hashed against the build record,
   documents generated, every text file secret-scanned, checksums and an export manifest, ZIP.

## Build stages

| Stage | Network | Image | What runs |
| --- | --- | --- | --- |
| fetch | registry only (bridge) | python worker | `pip download --only-binary=:all:` into a Foundry wheelhouse; then Foundry hashes every file and writes `foundry.lock.json` + `*.lock.txt` |
| build | none | python worker | venv, offline hash-checked install of build tooling, byte-compile check, `python -m build --no-isolation` |
| package | none | python worker / Qt worker | collect allowlisted artefacts; optional OCI image (`docker build --network none`) or PyInstaller executable |
| test | none | python worker | venv, offline install of runtime + dev locks and the built wheel, `pytest --junitxml` |
| smoke | none / internal preview network | python worker / Qt worker | run the entry point with manifest arguments, or start the server and wait for a real HTTP response, or launch the GUI offscreen |

Fetch results are cached by a key over (requested requirements, worker image, index URL,
binary-only flag). A cache hit means the build stage runs fully offline.

## Records

`builds/models.py::BuildRecord` stores: `build_id`, `source_checkpoint`, `source_hash`,
`manifest_version`, `toolchain_versions` (Foundry, container runtime, Python and pip inside the
worker, worker image and image ID), `dependency_lock_reference` (path + SHA-256),
`build_profile`, `started_at`, `completed_at`, `status`, `logs` (per stage), `artefact_hashes`,
plus stage results, the test report and the diagnosis.

`status` describes **packaging only**. `tests_status` and `smoke_status` are separate, and
`verified` is true only when the build succeeded, the smoke check passed, and tests passed (or
legitimately do not exist).

## Persistence

SQLite (`persistence/db.py`, WAL mode, thread-local connections). Tables: `projects`, `imports`,
`checkpoints`, `build_profiles`, `builds`, `test_runs`, `artefacts`, `proposals`,
`applied_changes`, `permissions`, `exports`, `workers`, `activity`. Documents are Pydantic JSON;
the `builds.status` column is authoritative so recovery can override it.

Recovery (`persistence/recovery.py`) runs at startup under a single-instance lock: running builds
become `interrupted`, Foundry-labelled containers are removed, and Foundry scratch space and
incomplete wheelhouse downloads are deleted. Managed source, completed builds and exports are
never deleted.

## Process and command handling

* Host-side tools (Git, the container CLI) run through `isolation/process.py`: argv arrays only,
  minimal explicit environment, timeouts, cancellation that kills the process group, bounded output.
* Worker commands are `WorkerStep`s validated by `isolation/commands.py` (program allowlist, no
  shells, no `python -c`, pip index options reserved for Foundry-authored steps, path containment).
* The in-container worker reads its plan from **stdin**, runs each step without a shell, and
  reports events on stderr with a per-run nonce. The **container exit code** is authoritative;
  project output cannot forge success.
