# Known limitations and deferred work

## Platform

* Isolation requires Docker or Podman. Without one, Foundry is an inspection/editing tool only.
* Containers share the host kernel. For hostile code, put the runtime inside a VM or use a
  sandboxed runtime (gVisor, Kata).
* macOS/Windows Docker Desktop: web previews and HTTP smoke checks need published-port mode,
  which gives preview containers outbound network.
* Artefacts target the worker platform (Linux, worker CPU architecture). There is no
  cross-compilation; one executable does not run on every OS.

## Deferred

| Item | Why deferred | Current behaviour |
| --- | --- | --- |
| Registry-only egress filtering in the fetch stage | needs an allowlisting egress proxy chained to any corporate proxy | bridge network during fetch only; binary-only downloads; validated requirement lines |
| GUI screenshots in a virtual display (Xvfb) | needs an X server and capture tooling in the Qt image | offscreen launch checks prove the window starts and exits cleanly |
| Node.js / Rust / Kotlin Android builds | adapters not implemented | detected and inspected; builds report `blocked` |
| Poetry / PDM / uv lock resolution | lockfiles are detected, not consumed | Foundry resolves from PEP 621 / requirements and writes its own lock |
| Byte quota on the writable output mount | Docker bind mounts have no per-mount quota | size checked after each stage |
| Signing, notarisation, installers, publishing, deployment | intentionally separate from local packaging | not performed |
| Live use of the Claude adapter | no API key in the delivery environment | stub-client unit tests; parameters checked against SDK 2.14 |

## Behavioural

* The smoke check runs the configured entry point once; it is not a functional test suite.
* Static-site "tests" are structural checks (title, language, references), not browser tests.
* Secret detection is pattern-based and will miss unusual formats.
* Licence information is copied from package metadata and is not legal advice.
* `setup.py`/`setup.cfg`-only projects are detected but must be given PEP 621 metadata (Foundry
  will not execute `setup.py` to discover dependencies).
* The heuristic repair adapter only fixes missing, well-known dependencies. Other categories are
  explained, not patched.
