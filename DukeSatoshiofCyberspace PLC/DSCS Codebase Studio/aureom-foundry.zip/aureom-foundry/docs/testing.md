# Testing

## Running

```bash
pip install ".[dev]"
pytest                                    # unit tests + isolation tests if a runtime and image exist
AUREOM_FOUNDRY_RUN_INTEGRATION=1 pytest   # + end-to-end builds (needs registry access)
```

Useful environment variables:

| Variable | Purpose |
| --- | --- |
| `AUREOM_FOUNDRY_PYTHON_IMAGE` | worker image (default `python:3.12-slim`) |
| `AUREOM_FOUNDRY_REGISTRY_CA` | CA bundle for a TLS-inspecting proxy |
| `AUREOM_FOUNDRY_RUN_INTEGRATION=1` | enable `tests/test_build_integration.py` |
| `QT_QPA_PLATFORM=offscreen` | GUI tests without a display (set automatically by `test_gui.py`) |

Tests marked `isolation` skip automatically when no container runtime or worker image is
available; `test_gui.py` skips when PySide6 cannot be imported.

## Actual results (delivery run, 2026-11-26)

Environment: Linux x86_64, Python 3.13 (Foundry), Docker 29.9.3 (cgroup v1),
worker image `mirror.gcr.io/library/python:3.12-slim` (Python 3.12.16), Qt worker image built from
`docker/worker-python-qt.Dockerfile` (Ubuntu 24.04, Python 3.12.3), PySide6 6.12.0.

```
AUREOM_FOUNDRY_RUN_INTEGRATION=1 pytest -v
======================= 130 passed in 169.70s (0:02:49) ========================
```

| File | Passed | What it covers |
| --- | --- | --- |
| `tests/test_archive_safety.py` | 13 | traversal, absolute paths, drive letters, symlinks, bombs, file-count limit, case collisions, exec-bit stripping, folder symlink skipping, malicious fixture rejected end-to-end |
| `tests/test_secrets.py` | 6 | detection without values, placeholders, redaction, private keys, sensitive names, log redaction |
| `tests/test_manifest.py` | 18 | example manifests, invalid fields, unsafe YAML, requests vs. grants, execution disabled without isolation |
| `tests/test_inspection.py` | 7 | type detection, **no execution during inspection**, undeclared/unresolved imports, syntax errors, missing assets, secrets |
| `tests/test_dependencies.py` | 8 | ignored pip options, requirement injection, versions, conflicts, unsupported runtime, role separation, lockfiles |
| `tests/test_command_validation.py` | 21 | shells, `python -c`, index overrides, path containment, env validation, inert metacharacters |
| `tests/test_isolation_policy.py` | 6 | engine socket/home mounts rejected, read-only extras, run arguments, networks, unavailable runtime refuses, builds blocked without isolation |
| `tests/test_process.py` | 5 | timeouts kill the process group (grandchildren too), cancellation, no inherited env, output cap, no shell |
| `tests/test_proposals_and_rollback.py` | 10 | apply/revert restores exact content, out-of-order reverts, stale proposals, guard blocks weakening changes, AI cannot delete or escape |
| `tests/test_recovery.py` | 2 | interrupted builds never successful, debris cleaned, source/exports kept, single-instance lock |
| `tests/test_errors.py` | 4 | all error categories, missing module location, test failures vs. root cause, redacted evidence |
| `tests/test_export.py` | 4 | export contents, checksums, secret exclusion, tampered artefact blocked, unverified labelling, failed builds refused |
| `tests/test_scaffold_and_ai.py` | 6 | verbatim wrapping, questions instead of guesses, web-api reuse of an existing app, offline adapter, opt-in for external AI, share preview redaction, bounded repair |
| `tests/test_anthropic_adapter.py` | 3 | structured output parsing, refusal/invalid output, share preview required (stub client) |
| `tests/test_cli_and_capabilities.py` | 2 | honest capability matrix, CLI import/inspect/build-blocked/doctor |
| `tests/test_gui.py` | 2 | all ten pages render offscreen, execution disabled without isolation, themes |
| `tests/test_isolation_integration.py` | 9 | **real containers**: no network, no host secrets/home/socket, non-root, read-only source and root fs, explicit output, memory limit, process limit, timeout + cleanup, cancellation + cleanup, forged events cannot mark success |
| `tests/test_build_integration.py` | 4 | **real builds**: CLI import → build → console run → export; missing-dependency repair cycle with revert; timeout and network fixtures; static site build + preview |

## Example builds (same run)

| Project | Profile | Build | Tests | Smoke | Artefacts |
| --- | --- | --- | --- | --- | --- |
| csv-insight (CLI) | local-release | succeeded | 5 passed | entry point ran, output matched | wheel, sdist, lock |
| inventory-service (FastAPI) | container-image | succeeded | 4 passed | `GET /health` 200 after 7.8 s on an internal network | wheel, sdist, OCI image tar, lock |
| lumen-lamp-site (static) | local-release | succeeded | 4/4 structural checks | `index.html` + 5 assets served | reproducible site ZIP |
| quick-notes (PySide6) | desktop-executable | succeeded | 3 passed | window launched offscreen; packaged executable launched | wheel, sdist, Linux x86_64 executable ZIP, lock |

Without the Qt worker image the PySide6 smoke check reports **unsupported** and the build is not
verified — this was observed before the image was built and is the intended behaviour.

## Static checks

`pyflakes src tests scripts` reports no findings (apart from intentional registration imports).
