import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { StudioService } from '../services/studio.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-diff-review-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    @if (studio.diffReviewModalOpen() && studio.activeDiffTask(); as task) {
      <div
        class="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-6"
        (click)="closeOnBackdrop($event)"
      >
        <div class="w-full max-w-4xl bg-neutral-900 border border-neutral-750 rounded-xl shadow-2xl overflow-hidden font-sans text-xs flex flex-col max-h-[85vh]">
          <!-- Header -->
          <div class="px-5 py-3.5 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between shrink-0">
            <div class="flex items-center gap-2.5">
              <span class="w-2.5 h-2.5 rounded-full bg-blue-400 animate-pulse"></span>
              <span class="font-bold text-white text-sm">Review Agent Mutation Diff</span>
              <span class="font-mono text-[10px] text-blue-400 uppercase bg-blue-950/60 px-2 py-0.5 rounded border border-blue-500/30">
                Agent [{{ task.role }}]
              </span>
            </div>
            <button
              type="button"
              (click)="studio.diffReviewModalOpen.set(false)"
              class="text-neutral-500 hover:text-white p-1"
            >
              <mat-icon class="text-sm">close</mat-icon>
            </button>
          </div>

          <!-- Task Goal Bar -->
          <div class="px-5 py-2.5 bg-neutral-900/90 border-b border-neutral-800 flex items-center justify-between text-xs text-neutral-300 shrink-0">
            <div>
              <span class="text-neutral-500">Goal:</span>
              <span class="font-medium text-white ml-1.5">{{ task.goal }}</span>
            </div>
            <div class="font-mono text-[11px] text-neutral-400">
              Target: {{ task.diffs?.[0]?.filePath || 'active file' }}
            </div>
          </div>

          <!-- Diff Inspection Body -->
          <div class="flex-1 overflow-y-auto p-5 space-y-4 font-mono text-xs">
            @for (diff of task.diffs; track diff.filePath) {
              <div class="border border-neutral-800 rounded-lg overflow-hidden">
                <div class="px-3 py-1.5 bg-neutral-950 border-b border-neutral-800 text-[11px] font-semibold text-neutral-400 flex items-center justify-between">
                  <span>{{ diff.filePath }}</span>
                  <span class="text-blue-400 text-[10px]">Proposed Atomic Patch</span>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-neutral-800 bg-neutral-950">
                  <!-- Original Content -->
                  <div class="p-3 overflow-x-auto">
                    <div class="text-[10px] text-red-400 uppercase font-bold mb-1">Current Workspace File (-)</div>
                    <pre class="text-[11px] text-neutral-400 whitespace-pre leading-relaxed select-text">{{ diff.oldContent || '// (Empty or new file)' }}</pre>
                  </div>

                  <!-- New Proposed Content -->
                  <div class="p-3 overflow-x-auto bg-neutral-900/30">
                    <div class="text-[10px] text-emerald-400 uppercase font-bold mb-1">Proposed Agent Output (+)</div>
                    <pre class="text-[11px] text-emerald-300 whitespace-pre leading-relaxed select-text">{{ diff.newContent }}</pre>
                  </div>
                </div>
              </div>
            }
          </div>

          <!-- Footer Actions -->
          <div class="px-5 py-3 bg-neutral-950 border-t border-neutral-800 flex items-center justify-between shrink-0">
            <span class="text-[11px] text-neutral-500">
              Changes will be committed safely with an atomic rollback entry.
            </span>

            <div class="flex items-center gap-3">
              <button
                type="button"
                (click)="studio.rejectDiffTask(task)"
                class="px-4 py-2 rounded-lg bg-neutral-850 hover:bg-neutral-800 border border-neutral-750 text-neutral-300 text-xs font-medium transition"
              >
                Reject Changes
              </button>
              <button
                type="button"
                (click)="studio.approveDiffTask(task)"
                class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition"
              >
                <mat-icon class="text-xs">check</mat-icon>
                <span>Approve & Write to Source</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class DiffReviewModalComponent {
  readonly studio = inject(StudioService);

  closeOnBackdrop(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.studio.diffReviewModalOpen.set(false);
    }
  }
}
