import type { Metadata } from 'next';
import { Cinzel, Cormorant_Garamond, Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css';

const cinzel = Cinzel({
  subsets: ['latin'],
  variable: '--font-cinzel',
  display: 'swap',
  weight: ['400', '600', '700', '800'],
});

const cormorant = Cormorant_Garamond({
  subsets: ['latin'],
  variable: '--font-cormorant',
  display: 'swap',
  weight: ['400', '500', '600', '700'],
  style: ['normal', 'italic'],
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
  weight: ['400', '500', '600', '700'],
});

export const metadata: Metadata = {
  title: 'The Royal Family — Official Monarchy & Buckingham Palace',
  description: 'The official digital home of the British Monarchy, featuring royal residences, ceremonial pageantry, the Royal Collection, and an interactive 1,100-year historical timeline.',
  openGraph: {
    title: 'The Royal Family — Official Monarchy & Buckingham Palace',
    description: 'Explore the British Monarchy, Buckingham Palace, Windsor Castle, the Crown Jewels, and over a millennium of royal history.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'The Royal Family — Official Monarchy & Buckingham Palace',
    description: 'Explore the British Monarchy, Buckingham Palace, Windsor Castle, the Crown Jewels, and over a millennium of royal history.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${cinzel.variable} ${cormorant.variable} ${plusJakarta.variable}`}>
      <body className="bg-[#0A1124] text-stone-100 antialiased font-sans selection:bg-[#C5A059] selection:text-black min-h-screen" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
