'use client';

import React, { useState } from 'react';
import { RoyalHeader } from '@/components/RoyalHeader';
import { RoyalHero } from '@/components/RoyalHero';
import { HistoricalTimeline } from '@/components/HistoricalTimeline';
import { WorkingMonarchySection } from '@/components/WorkingMonarchySection';
import { ResidencesSection } from '@/components/ResidencesSection';
import { CrownJewelsSection } from '@/components/CrownJewelsSection';
import { PageantrySection } from '@/components/PageantrySection';
import { RoyalFooter } from '@/components/RoyalFooter';
import { MonarchModal } from '@/components/MonarchModal';
import { VisitPlannerModal } from '@/components/VisitPlannerModal';
import { RoyalSearchModal } from '@/components/RoyalSearchModal';
import { AccessibilityModal } from '@/components/AccessibilityModal';
import { Monarch } from '@/data/timelineData';
import { RoyalResidence } from '@/data/residencesData';

export default function Home() {
  const [selectedMonarch, setSelectedMonarch] = useState<Monarch | null>(null);
  const [visitPlannerOpen, setVisitPlannerOpen] = useState(false);
  const [visitResidenceId, setVisitResidenceId] = useState('buckingham-palace');
  const [searchOpen, setSearchOpen] = useState(false);
  const [accessibilityOpen, setAccessibilityOpen] = useState(false);

  // Accessibility States
  const [highContrast, setHighContrast] = useState(false);
  const [largeText, setLargeText] = useState(false);
  const [reduceMotion, setReduceMotion] = useState(false);

  const handleOpenVisitPlannerFor = (residenceId: string) => {
    setVisitResidenceId(residenceId);
    setVisitPlannerOpen(true);
  };

  const handleNavigateSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth' });
    }
  };

  const handleSelectResidenceFromSearch = (r: RoyalResidence) => {
    handleOpenVisitPlannerFor(r.id);
  };

  return (
    <div
      className={`min-h-screen flex flex-col transition-colors ${
        highContrast ? 'contrast-125 saturate-125' : ''
      } ${largeText ? 'text-lg' : ''}`}
    >
      {/* Royal Institutional Header */}
      <RoyalHeader
        onOpenSearch={() => setSearchOpen(true)}
        onOpenAccessibility={() => setAccessibilityOpen(true)}
        onOpenVisitPlanner={() => setVisitPlannerOpen(true)}
      />

      {/* Main Royal Experience */}
      <main className="flex-1">
        {/* Buckingham Palace Hero & 4 Feature Pillars */}
        <RoyalHero
          onOpenVisitPlanner={() => setVisitPlannerOpen(true)}
          onExploreTimeline={() => handleNavigateSection('historical-timeline')}
          onNavigateSection={handleNavigateSection}
        />

        {/* The Historical Timeline of the British Monarchy (Centerpiece Feature) */}
        <HistoricalTimeline onSelectMonarch={setSelectedMonarch} />

        {/* The Working Monarchy & Contemporary Royal Family */}
        <WorkingMonarchySection />

        {/* The Royal Residences & Castles (Buckingham Palace, Windsor, Holyroodhouse, etc.) */}
        <ResidencesSection onOpenVisitPlannerFor={handleOpenVisitPlannerFor} />

        {/* Crown Jewels & Sacred Regalia */}
        <CrownJewelsSection />

        {/* Pageantry, Guard Mounting & Ceremonies */}
        <PageantrySection />
      </main>

      {/* Royal Footer */}
      <RoyalFooter
        onOpenAccessibility={() => setAccessibilityOpen(true)}
        onOpenVisitPlanner={() => setVisitPlannerOpen(true)}
        onOpenSearch={() => setSearchOpen(true)}
      />

      {/* Interactive Modals */}
      <MonarchModal
        monarch={selectedMonarch}
        onClose={() => setSelectedMonarch(null)}
      />

      <VisitPlannerModal
        isOpen={visitPlannerOpen}
        onClose={() => setVisitPlannerOpen(false)}
        initialResidenceId={visitResidenceId}
      />

      <RoyalSearchModal
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        onSelectMonarch={setSelectedMonarch}
        onSelectResidence={handleSelectResidenceFromSearch}
      />

      <AccessibilityModal
        isOpen={accessibilityOpen}
        onClose={() => setAccessibilityOpen(false)}
        highContrast={highContrast}
        setHighContrast={setHighContrast}
        largeText={largeText}
        setLargeText={setLargeText}
        reduceMotion={reduceMotion}
        setReduceMotion={setReduceMotion}
      />
    </div>
  );
}
