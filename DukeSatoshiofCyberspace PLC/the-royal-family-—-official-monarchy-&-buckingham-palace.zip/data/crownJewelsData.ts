export interface RegaliaItem {
  id: string;
  name: string;
  category: 'Crowns' | 'Sceptres & Orbs' | 'Sacred Anointing' | 'Robes & Swords';
  yearCreated: string;
  materials: string;
  weightOrSize: string;
  historicalRole: string;
  details: string;
  gemstones: string[];
}

export const CROWN_JEWELS: RegaliaItem[] = [
  {
    id: 'st-edwards-crown',
    name: "St Edward's Crown",
    category: 'Crowns',
    yearCreated: '1661 (for King Charles II)',
    materials: 'Solid 22-carat gold, velvet cap of maintenance, ermine fur band',
    weightOrSize: '2.23 kg (4.9 lbs)',
    historicalRole: 'The sacred crown used strictly at the moment of Coronation at Westminster Abbey to crown the Sovereign.',
    details: 'Named after King Edward the Confessor. Remade in 1661 by Royal Goldsmith Sir Robert Vyner after the original medieval crown was broken up during the English Civil War. It is only taken out of the Tower of London for the coronation of a new monarch.',
    gemstones: [
      '444 precious and semi-precious stones',
      'Rubies & Amethysts',
      'Sapphires & Garnets',
      'Topazes & Tourmalines'
    ]
  },
  {
    id: 'imperial-state-crown',
    name: 'The Imperial State Crown',
    category: 'Crowns',
    yearCreated: '1937 (incorporating historic royal gems)',
    materials: 'Openwork silver frame, gold mounts, platinum settings, purple velvet cap',
    weightOrSize: '1.06 kg (2.3 lbs)',
    historicalRole: 'Worn by the Sovereign departing Westminster Abbey after coronation, and annually at the State Opening of Parliament.',
    details: 'One of the most famous pieces of jewelry in existence. Contains some of the most historic gems in the British Crown, including the Black Prince\'s Ruby (worn by Henry V at Agincourt 1415), the Stuart Sapphire, and St Edward\'s Sapphire (taken from the ring of Edward the Confessor in 1163).',
    gemstones: [
      '2,868 diamonds',
      'Cullinan II diamond (317.4 carats)',
      'Black Prince\'s Ruby (170-carat red spinel)',
      '269 pearls & 17 sapphires',
      '11 emeralds & 4 rubies'
    ]
  },
  {
    id: 'sovereigns-sceptre',
    name: "The Sovereign's Sceptre with Cross",
    category: 'Sceptres & Orbs',
    yearCreated: '1661 (Adapted 1910)',
    materials: 'Gold rod, faceted amethyst, diamond-encrusted arches',
    weightOrSize: '92.2 cm length',
    historicalRole: 'Represents the monarch\'s temporal power and governance under the cross of Christ.',
    details: 'In 1910, King George V commissioned Garrard & Co to set the magnificent Cullinan I diamond—also known as the "Great Star of Africa"—at the heart of the sceptre. Cullinan I is the largest flawless top-quality cut white diamond in the world.',
    gemstones: [
      'Cullinan I (Great Star of Africa: 530.2 carats)',
      'Amethyst facetted orb surmounted by diamond cross',
      'Emeralds, rubies, and rose-cut diamonds'
    ]
  },
  {
    id: 'sovereigns-orb',
    name: "The Sovereign's Orb",
    category: 'Sceptres & Orbs',
    yearCreated: '1661',
    materials: 'Hollow gold sphere, jeweled bands, cross pattée',
    weightOrSize: '27.5 cm height, 1.2 kg',
    historicalRole: 'Delivered into the monarch\'s right hand during the coronation as a symbol of the Christian world.',
    details: 'A hollow sphere of gold encircled by bands of pearls and gemstones, representing the earth divided into three continents in medieval cosmology. Mounted atop is a cross set with diamonds and an emerald on one side and a sapphire on the other.',
    gemstones: [
      '375 rose-cut diamonds',
      '365 natural pearls',
      '9 emeralds & 9 sapphires',
      '18 rubies & fine cabochon gems'
    ]
  },
  {
    id: 'coronation-spoon',
    name: 'The Coronation Spoon',
    category: 'Sacred Anointing',
    yearCreated: 'Late 12th Century (circa 1199)',
    materials: 'Silver-gilt, engraved filigree, four freshwater pearls',
    weightOrSize: '27 cm length',
    historicalRole: 'Holds the consecrated holy chrism oil for the sacred anointing of the monarch\'s hands, breast, and head.',
    details: 'The oldest surviving object in the entire Royal Collection and Crown Jewels. It survived the 1649 Commonwealth destruction when it was bought for 16 shillings by a loyal yeoman of the Royal Wardrobe, who preserved it and returned it to Charles II at the Restoration.',
    gemstones: [
      'Four freshwater pearls set in handle',
      'Ornate acanthus scroll engraving',
      'Divided bowl for the Archbishop\'s fingers'
    ]
  },
  {
    id: 'queen-marys-crown',
    name: "Queen Mary's Crown",
    category: 'Crowns',
    yearCreated: '1911 (by Garrard & Co)',
    materials: 'Silver and gold openwork, purple velvet cap',
    weightOrSize: '590 grams',
    historicalRole: 'Reset and worn by Queen Camilla at the 2023 Coronation.',
    details: 'Chosen by Queen Camilla for the May 2023 Coronation in the interests of sustainability and historic continuity—the first time since the 18th century that an existing consort crown was reused. Set with Cullinan III, IV, and V diamonds from Queen Elizabeth II\'s personal collection.',
    gemstones: [
      '2,200 diamonds',
      'Cullinan III diamond (94.4 carats)',
      'Cullinan IV diamond (63.6 carats)',
      'Cullinan V heart-shaped brooch diamond (18.8 carats)'
    ]
  }
];
