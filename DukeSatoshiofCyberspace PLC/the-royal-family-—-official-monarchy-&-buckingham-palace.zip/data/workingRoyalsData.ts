export interface WorkingRoyal {
  id: string;
  name: string;
  royalStyle: string;
  role: string;
  born: string;
  monogram: string;
  focusAreas: string[];
  bio: string;
  patronagesCount: string;
  initiatives: string[];
}

export const WORKING_ROYALS: WorkingRoyal[] = [
  {
    id: 'king-charles-iii',
    name: 'His Majesty King Charles III',
    royalStyle: 'The Sovereign',
    role: 'Head of State, Head of the Nation & Head of the Commonwealth',
    born: '14 November 1948',
    monogram: 'C III R',
    focusAreas: [
      'Constitutional Duties & Weekly Audiences with the Prime Minister',
      'Global Environmental Sustainability & Biodiversity Conservation',
      'Heritage Craftsmanship, Traditional Building Arts & The King\'s Foundation',
      'Interfaith Harmony, Community Cohesion & Military Commands'
    ],
    bio: 'Acceded to the throne in September 2022. For more than five decades, King Charles III has championed innovative sustainability, founded over 20 charities including The Prince\'s Trust, and remains Sovereign of the UK armed forces and Patron of hundreds of national institutions.',
    patronagesCount: '400+ Patronages & Presidencies',
    initiatives: [
      'The Prince\'s Trust (Over 1 million youth supported)',
      'The King\'s Foundation & Dumfries House',
      'Sustainable Markets Initiative (Terra Carta)',
      'The Coronation Food Project'
    ]
  },
  {
    id: 'queen-camilla',
    name: 'Her Majesty Queen Camilla',
    royalStyle: 'The Queen Consort',
    role: 'Consort to the Sovereign & Companion in State Ceremonies',
    born: '17 July 1947',
    monogram: 'C R',
    focusAreas: [
      'Champion of Literacy, Reading for Children & The Queen\'s Reading Room',
      'Support for Victims of Domestic Abuse and Sexual Violence',
      'Promoting Active Aging, Dementia Care & Osteoporosis Research',
      'Arts, Theatre & Equine Welfare'
    ],
    bio: 'Queen Camilla supports His Majesty in carrying out national engagements and state visits, while directing passionate personal advocacy toward literacy, domestic abuse survivor support, and health research.',
    patronagesCount: '100+ Patronages',
    initiatives: [
      'The Queen\'s Reading Room Global Charity & Festival',
      'Royal Osteoporosis Society (President since 2001)',
      'SafeLives & Support for Domestic Abuse Shelters',
      'National Literacy Trust'
    ]
  },
  {
    id: 'prince-william',
    name: 'His Royal Highness The Prince of Wales',
    royalStyle: 'Prince William',
    role: 'Heir to the Throne & Duke of Cornwall and Cambridge',
    born: '21 June 1982',
    monogram: 'W',
    focusAreas: [
      'The Earthshot Prize: Global Environmental Solution Catalyst',
      'Homewards: A 5-year Program to End Homelessness across the UK',
      'Mental Health in the Workplace, Military & Emergency Responders',
      'Stewardship of the Duchy of Cornwall (130,000 acres)'
    ],
    bio: 'As Prince of Wales and Duke of Cornwall, Prince William blends royal constitutional duty with urgent 21st-century problem-solving, launching the £50m Earthshot Prize to repair the planet and Homewards to end homelessness.',
    patronagesCount: '30+ Key Patronages',
    initiatives: [
      'The Earthshot Prize (Annual global awards)',
      'Homewards UK Program',
      'Heads Together Mental Health Campaign',
      'United for Wildlife (Countering illegal wildlife trade)'
    ]
  },
  {
    id: 'princess-catherine',
    name: 'Her Royal Highness The Princess of Wales',
    royalStyle: 'Princess Catherine',
    role: 'Princess of Wales & Duchess of Cornwall and Cambridge',
    born: '9 January 1982',
    monogram: 'C',
    focusAreas: [
      'Early Childhood Development & The Royal Foundation Centre for Early Childhood',
      'Children\'s Mental Health & Family Well-being',
      'Visual Arts, Photography & The National Portrait Gallery',
      'Sports, Tennis (AELTC Patron) & Addiction Recovery'
    ],
    bio: 'The Princess of Wales leads landmark scientific research into the earliest years of child development (from pregnancy to age 5), advocating for systemic change to support healthy childhood foundations across society.',
    patronagesCount: '25+ Key Patronages',
    initiatives: [
      'Shaping Us National Campaign',
      'Royal Foundation Centre for Early Childhood',
      'Together at Christmas Carol Service at Westminster Abbey',
      'Place2Be & Anna Freud Centre'
    ]
  },
  {
    id: 'princess-anne',
    name: 'Her Royal Highness The Princess Royal',
    royalStyle: 'Princess Anne',
    role: 'The Sovereign\'s Sister & Most Active Working Royal',
    born: '15 August 1950',
    monogram: 'A',
    focusAreas: [
      'Save the Children (President since 1970, visited over 80 field stations)',
      'Riding for the Disabled Association & Olympian Equestrian Leadership',
      'Science, Technology & Maritime Engineering Fellowships',
      'Gold Stick-in-Waiting and Personal Aide-de-Camp to The King'
    ],
    bio: 'Known as the hardest-working royal, conducting upwards of 450 official engagements each year. Represented Great Britain as an equestrian Olympian in 1976 and served as Gold Stick at the 2023 Coronation.',
    patronagesCount: '300+ Charities & Organizations',
    initiatives: [
      'Save the Children UK',
      'Riding for the Disabled Association',
      'The Princess Royal Trust for Carers (Carers Trust)',
      'Royal College of Midwives'
    ]
  },
  {
    id: 'edward-and-sophie',
    name: 'TRH The Duke and Duchess of Edinburgh',
    royalStyle: 'Prince Edward & Sophie',
    role: 'Senior Working Royals Supporting Commonwealth & Youth',
    born: '1964 & 1965',
    monogram: 'E & S',
    focusAreas: [
      'The Duke of Edinburgh\'s Award (In 130+ Countries)',
      'Global Prevention of Conflict-Related Sexual Violence (PSVI)',
      'Youth Empowerment, STEM Education & Vision 2020 Prevention of Blindness',
      'Promoting Equality for Women in Peace-Building'
    ],
    bio: 'The Duke and Duchess of Edinburgh carry out extensive international and domestic duties, continuing the legacy of Prince Philip\'s world-renowned DofE youth development award scheme.',
    patronagesCount: '150+ Combined Patronages',
    initiatives: [
      'The Duke of Edinburgh\'s Award Foundation',
      'Women, Peace and Security (WPS) Initiative',
      'International Agency for the Prevention of Blindness',
      'Central School of Ballet'
    ]
  }
];
