export interface RoyalResidence {
  id: string;
  name: string;
  role: string;
  location: string;
  flagStatus: 'Royal Standard' | 'Union Flag';
  flagMeaning: string;
  builtYear: string;
  architecturalStyle: string;
  visitorStatus: string;
  visitorOpenTimes: string;
  summary: string;
  highlights: string[];
  imagePath: string;
  ticketPrice?: string;
  stateRoomsOpenSummer: boolean;
}

export const ROYAL_RESIDENCES: RoyalResidence[] = [
  {
    id: 'buckingham-palace',
    name: 'Buckingham Palace',
    role: 'Official London Residence of the Monarch & Working Headquarters',
    location: 'London SW1A 1AA, England',
    flagStatus: 'Royal Standard',
    flagMeaning: 'The King is currently in residence at Buckingham Palace today',
    builtYear: '1703 (Acquired 1761, Nash renovation 1825)',
    architecturalStyle: 'Neoclassical & French Neoclassical',
    visitorStatus: 'Open for Summer Opening (July – September) & Guided Garden Tours',
    visitorOpenTimes: 'Daily 09:30 – 19:30 (Last admission 17:15)',
    summary: 'The administrative heart of the British Monarchy and the official London residence of His Majesty King Charles III. It boasts 775 rooms, including 19 State Rooms, 52 Royal and guest bedrooms, 188 staff bedrooms, 92 offices, and 78 bathrooms.',
    highlights: [
      'The Grand Ballroom (largest room at 36.6m long, site of State Banquets & Investitures)',
      'The Throne Room (adorned with dramatic red silk damask and the Thrones of Estate)',
      'The White Drawing Room (intimate reception room with secret cabinet door for royal arrivals)',
      'The Picture Gallery (housing masterworks by Rembrandt, Rubens, Vermeer, and Canaletto)',
      '39-acre Private Royal Gardens with lake, tennis courts, and rose garden'
    ],
    imagePath: '/assets/aistudio/d9e205f7-45e1-4158-9342-f6abc9471fff_0b0d5420.png',
    ticketPrice: 'From £32.00 (State Rooms)',
    stateRoomsOpenSummer: true
  },
  {
    id: 'windsor-castle',
    name: 'Windsor Castle',
    role: 'Oldest & Largest Inhabited Castle in the World',
    location: 'Windsor, Berkshire SL4 1NJ',
    flagStatus: 'Union Flag',
    flagMeaning: 'Sovereign not currently in residence; castle open for state visitors',
    builtYear: 'Circa 1070 (William the Conqueror)',
    architecturalStyle: 'Medieval, Gothic Revival & Georgian',
    visitorStatus: 'Open Year-Round (Thursday – Monday)',
    visitorOpenTimes: '10:00 – 17:15 (Last entry 16:00)',
    summary: 'Founded by William the Conqueror around 1070, Windsor Castle has been the continuous royal home to 40 British monarchs across nearly 1,000 years of unbroken sovereign history.',
    highlights: [
      'St George\'s Chapel (15th-century Perpendicular Gothic masterpiece, burial place of Queen Elizabeth II and King Henry VIII)',
      'Grand State Apartments decorated with masterpieces from the Royal Collection',
      'The Waterloo Chamber celebrating the allied victory over Napoleon in 1815',
      'Queen Mary\'s Dolls\' House (the most famous dollhouse in the world, celebrating its centenary)'
    ],
    imagePath: '/assets/aistudio/d9e205f7-45e1-4158-9342-f6abc9471fff_0b0d5420.png',
    ticketPrice: 'From £30.00',
    stateRoomsOpenSummer: false
  },
  {
    id: 'holyroodhouse',
    name: 'Palace of Holyroodhouse',
    role: 'Official Scottish Royal Residence',
    location: 'Canongate, The Royal Mile, Edinburgh EH8 8DX, Scotland',
    flagStatus: 'Union Flag',
    flagMeaning: 'Open to the public for Royal Week preparations and exhibitions',
    builtYear: 'Founded 1128 as Abbey, Palace built 1501',
    architecturalStyle: 'Scottish Renaissance & Classical',
    visitorStatus: 'Open Year-Round (Thursday – Monday)',
    visitorOpenTimes: '09:30 – 16:30 (Winter) / 18:00 (Summer)',
    summary: 'Standing at the foot of Edinburgh\'s historic Royal Mile, Holyroodhouse is the official Scottish residence of the Sovereign and the focal point of Royal Week in Scotland every summer.',
    highlights: [
      'Historic Apartments of Mary, Queen of Scots (scene of dramatic 16th-century court intrigues)',
      'The Great Gallery displaying 96 portraits of Scottish kings painted by Jacob de Wet',
      'The ruined 12th-century Holyrood Abbey with dramatic open-sky Gothic arches',
      'The King\'s Bedchamber and Scottish State Apartments used for modern investitures'
    ],
    imagePath: '/assets/aistudio/d9e205f7-45e1-4158-9342-f6abc9471fff_0b0d5420.png',
    ticketPrice: 'From £22.00',
    stateRoomsOpenSummer: false
  },
  {
    id: 'balmoral-castle',
    name: 'Balmoral Castle & Estate',
    role: 'Private Scottish Highland Sanctuary',
    location: 'Royal Deeside, Aberdeenshire, Scotland',
    flagStatus: 'Union Flag',
    flagMeaning: 'Grounds & exhibitions open to visitors in Spring/Early Summer',
    builtYear: '1856 (Commissioned by Queen Victoria & Prince Albert)',
    architecturalStyle: 'Scottish Baronial',
    visitorStatus: 'Estate Grounds & Ballroom Exhibition Open May – August',
    visitorOpenTimes: '10:00 – 17:00 daily',
    summary: 'Purchased for Queen Victoria by Prince Albert in 1852, Balmoral is the private Highland estate where the Royal Family gathers every summer to enjoy the tranquility of Royal Deeside.',
    highlights: [
      'The Balmoral Ballroom with tartan drapery, royal crystal, and sovereign portraits',
      '50,000 acres of protected Highland moors, ancient Caledonian pine forest, and rivers',
      'The King\'s vegetable and flower gardens developed under His Majesty\'s ecological vision',
      'New intimate guided tours of the interior Royal Family living quarters'
    ],
    imagePath: '/assets/aistudio/d9e205f7-45e1-4158-9342-f6abc9471fff_0b0d5420.png',
    ticketPrice: 'From £17.50 (Grounds)',
    stateRoomsOpenSummer: true
  },
  {
    id: 'sandringham-house',
    name: 'Sandringham House',
    role: 'Private Country Retreat in Norfolk & Christmas Home',
    location: 'Sandringham, Norfolk PE35 6EN',
    flagStatus: 'Union Flag',
    flagMeaning: 'House, gardens, and royal parkland open to visitors',
    builtYear: '1870 (Jacobean style for King Edward VII)',
    architecturalStyle: 'Jacobean Revival Red Brick',
    visitorStatus: 'Open April – October (Closed during Winter Royal Residence)',
    visitorOpenTimes: '10:00 – 17:00 daily',
    summary: 'The much-loved private country house of four generations of British monarchs since 1862. It is the traditional venue for the Royal Family\'s annual Christmas celebrations and church walk.',
    highlights: [
      'The Main Saloon with exquisite 19th-century family portraits and roaring hearth',
      '600 acres of royal parkland, designated as an Area of Outstanding Natural Beauty',
      'The Royal Transport Museum featuring historic sovereign limousines and vintage fire engines',
      'St Mary Magdalene Church where the Royal Family gathers on Christmas Day'
    ],
    imagePath: '/assets/aistudio/d9e205f7-45e1-4158-9342-f6abc9471fff_0b0d5420.png',
    ticketPrice: 'From £24.00 (House & Gardens)',
    stateRoomsOpenSummer: false
  }
];
