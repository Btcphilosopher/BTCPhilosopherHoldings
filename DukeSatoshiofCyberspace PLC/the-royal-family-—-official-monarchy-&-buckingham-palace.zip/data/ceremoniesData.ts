export interface RoyalCeremony {
  id: string;
  title: string;
  timing: string;
  location: string;
  description: string;
  uniformAndRegalia: string;
  publicViewingTip: string;
  nextScheduledDate: string;
  regimentOrParticipants: string;
}

export const ROYAL_CEREMONIES: RoyalCeremony[] = [
  {
    id: 'changing-of-the-guard',
    title: "Changing of The King's Guard",
    timing: '11:00 AM (Mondays, Wednesdays, Fridays & Sundays)',
    location: 'Buckingham Palace Forecourt & Friary Court, St James\'s Palace',
    description: 'An iconic display of British pageantry dating back to 1660. The Old Guard (soldiers on active guard duty) hands over responsibility for protecting Buckingham Palace and St James\'s Palace to the New Guard, accompanied by a full military marching band.',
    uniformAndRegalia: 'Scarlet tunics and bearskin caps (The Foot Guards: Grenadier, Coldstream, Scots, Irish, and Welsh Guards).',
    publicViewingTip: 'Arrive at the Victoria Memorial or the palace gates by 10:15 AM for prime views of the band and troops marching along The Mall.',
    nextScheduledDate: 'Confirmed 11:00 AM BST (Weather Permitting)',
    regimentOrParticipants: 'Foot Guards & Household Cavalry Mounted Regiment'
  },
  {
    id: 'trooping-the-colour',
    title: 'Trooping the Colour (The King\'s Birthday Parade)',
    timing: 'Annual Saturday in June (10:00 AM)',
    location: 'Horse Guards Parade, The Mall & Buckingham Palace Balcony',
    description: 'The Sovereign\'s official birthday parade, performed by the regiments of the Household Division. Over 1,400 officers and soldiers, 200 horses, and 400 musicians parade before His Majesty, concluding with the famous Royal Family balcony appearance and RAF flypast.',
    uniformAndRegalia: 'Full ceremonial dress uniform with ceremonial swords, feather plumes, and sovereign standard.',
    publicViewingTip: 'Crowds line the Mall between Buckingham Palace and Horse Guards Parade; royal balcony appearance occurs at 13:00.',
    nextScheduledDate: 'Saturday in June (Annual State Parade)',
    regimentOrParticipants: '1st Battalion Foot Guards, King\'s Troop Royal Horse Artillery & RAF'
  },
  {
    id: 'state-opening-parliament',
    title: 'State Opening of Parliament',
    timing: 'Autumn / Parliamentary Session Commencement',
    location: 'Palace of Westminster (House of Lords)',
    description: 'The formal start of the parliamentary year. The Sovereign travels from Buckingham Palace in the Irish State Coach, wears the Imperial State Crown and Robe of Estate, and delivers the King\'s Speech outlining the Government\'s legislative programme.',
    uniformAndRegalia: 'Imperial State Crown, Robe of State (crimson velvet with ermine cape), Sword of State, and Cap of Maintenance.',
    publicViewingTip: 'Spectators line Whitehall and Parliament Square to watch the Sovereign\'s Escort of the Household Cavalry pass.',
    nextScheduledDate: 'Opening of the Parliamentary Session',
    regimentOrParticipants: 'The King, Her Majesty The Queen, Great Officers of State, Gentleman Usher of the Black Rod'
  },
  {
    id: 'garter-day',
    title: 'Garter Day Procession',
    timing: 'Annual Monday in June (14:30)',
    location: 'Windsor Castle (St George\'s Chapel)',
    description: 'The annual procession of the Knights and Ladies of the Most Noble Order of the Garter, the oldest British order of chivalry founded by King Edward III in 1348. The Sovereign and Knights walk from the Upper Ward down to St George\'s Chapel.',
    uniformAndRegalia: 'Dark blue velvet mantles, heraldic garter badges, Tudor hats with ostrich and black heron feather plumes, and gold collars.',
    publicViewingTip: 'Members of the public can apply for tickets to view the procession from the castle grounds and Lower Ward.',
    nextScheduledDate: 'Mid-June Annually',
    regimentOrParticipants: 'The Sovereign, Companions of the Garter, Military Knights of Windsor & Officers of Arms'
  }
];
