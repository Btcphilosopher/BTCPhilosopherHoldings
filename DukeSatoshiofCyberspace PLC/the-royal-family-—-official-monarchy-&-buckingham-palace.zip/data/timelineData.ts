export interface Monarch {
  id: string;
  name: string;
  house: 'Windsor' | 'Hanover & Saxe-Coburg' | 'Stuart' | 'Tudor' | 'Plantagenet' | 'Norman' | 'Anglo-Saxon';
  reign: string;
  reignStart: number;
  reignEnd: number | null; // null for current
  lifespan: string;
  title: string;
  motto: string;
  portraitUrl?: string;
  summary: string;
  keyAchievements: string[];
  historicalContext: string;
  quote?: string;
  residenceOrPalace: string;
  coronationYear: number;
}

export const MONARCHS: Monarch[] = [
  {
    id: 'charles-iii',
    name: 'King Charles III',
    house: 'Windsor',
    reign: '2022 – Present',
    reignStart: 2022,
    reignEnd: null,
    lifespan: 'Born 1948',
    title: 'By the Grace of God, King of the United Kingdom and 14 Other Realms, Head of the Commonwealth, Defender of the Faith',
    motto: 'Dieu et mon Droit (God and my right)',
    summary: 'Acceded to the throne on 8 September 2022 following the reign of his mother, Queen Elizabeth II. Crowned at Westminster Abbey on 6 May 2023 with St Edward\'s Crown.',
    keyAchievements: [
      'Over 50 years of pioneering leadership in environmental conservation, climate resilience, and sustainable architecture (Poundbury).',
      'Founded The Prince\'s Trust in 1976, helping more than 1 million disadvantaged young people across the UK.',
      'Modernized the working monarchy and champion of interfaith dialogue and national unity.',
      'Sovereign of the Order of the Garter and Order of the Thistle.'
    ],
    historicalContext: 'His coronation in May 2023 was the first in 70 years, balancing ancient liturgical solemnity dating back 1,000 years with representation from all faiths and nations of the Commonwealth.',
    quote: 'As The Queen herself did with such unswerving devotion, I too now solemnly pledge myself, throughout the remaining time God grants me, to uphold the Constitutional principles at the heart of our nation.',
    residenceOrPalace: 'Buckingham Palace & Highgrove House',
    coronationYear: 2023
  },
  {
    id: 'elizabeth-ii',
    name: 'Queen Elizabeth II',
    house: 'Windsor',
    reign: '1952 – 2022',
    reignStart: 1952,
    reignEnd: 2022,
    lifespan: '1926 – 2022',
    title: 'Queen of the United Kingdom, Canada, Australia, New Zealand and Her Other Realms, Head of the Commonwealth',
    motto: 'I serve',
    summary: 'The longest-reigning British monarch in history, reigning for 70 years and 214 days. A steadfast beacon of duty and continuity across seven transformative decades.',
    keyAchievements: [
      'Celebrated Silver, Golden, Diamond, and historic Platinum (70 years) Jubilees.',
      'Held over 3,500 weekly audiences with 15 UK Prime Ministers, from Winston Churchill to Liz Truss.',
      'Transformed the British Empire into the voluntary 56-nation Commonwealth of Nations.',
      'First British monarch to address a joint session of the United States Congress and to visit the Republic of Ireland in 100 years.'
    ],
    historicalContext: 'Her coronation in June 1953 was the first to be fully televised, watched by 27 million people in the UK and hundreds of millions worldwide, inaugurating the modern media age of the monarchy.',
    quote: 'I declare before you all that my whole life whether it be long or short shall be devoted to your service and the service of our great imperial family to which we all belong.',
    residenceOrPalace: 'Buckingham Palace & Windsor Castle',
    coronationYear: 1953
  },
  {
    id: 'george-vi',
    name: 'King George VI',
    house: 'Windsor',
    reign: '1936 – 1952',
    reignStart: 1936,
    reignEnd: 1952,
    lifespan: '1895 – 1952',
    title: 'King of Great Britain, Ireland and the British Dominions Beyond the Seas, Emperor of India (until 1947)',
    motto: 'Dieu et mon Droit',
    summary: 'Stepped forward following the unexpected abdication of his brother Edward VIII. Became a heroic symbol of British fortitude during World War II.',
    keyAchievements: [
      'Refused to leave Buckingham Palace during the London Blitz, even after the palace was bombed nine times.',
      'Instituted the George Cross and George Medal to reward acts of civil bravery during wartime.',
      'Broadcast inspiring Christmas addresses that sustained national and Commonwealth morale.',
      'Supported the postwar transition to the modern Commonwealth and the founding of the NHS.'
    ],
    historicalContext: 'With Queen Elizabeth (the future Queen Mother), King George VI visited bombed districts of East London and industrial heartlands, sharing the direct dangers of his people.',
    quote: 'I said to the man who stood at the gate of the year: "Give me a light that I may tread safely into the unknown." And he replied: "Go out into the darkness and put your hand into the Hand of God."',
    residenceOrPalace: 'Buckingham Palace & Royal Lodge, Windsor',
    coronationYear: 1937
  },
  {
    id: 'george-v',
    name: 'King George V',
    house: 'Windsor',
    reign: '1910 – 1936',
    reignStart: 1910,
    reignEnd: 1936,
    lifespan: '1865 – 1936',
    title: 'King of the United Kingdom and Emperor of India',
    motto: 'Dieu et mon Droit',
    summary: 'Founded the House of Windsor in 1917, changing the royal family name from Saxe-Coburg and Gotha in response to World War I. Inaugurated the annual Royal Christmas Broadcast.',
    keyAchievements: [
      'Founded the House of Windsor by royal proclamation on 17 July 1917.',
      'Delivered the first Royal Christmas Message on radio in 1932, written by Rudyard Kipling.',
      'Conducted over 450 front-line inspections during World War I and visited wounded servicemen.',
      'Celebrated his Silver Jubilee in 1935 amid profound public affection.'
    ],
    historicalContext: 'Navigated the constitutional crisis of the Parliament Act 1911 and the rise of the first Labour Government in 1924 with scrupulous constitutional neutrality.',
    quote: 'I may be uninspiring, but I\'ll be damned if I\'m an alien.',
    residenceOrPalace: 'Buckingham Palace & Sandringham House',
    coronationYear: 1911
  },
  {
    id: 'victoria',
    name: 'Queen Victoria',
    house: 'Hanover & Saxe-Coburg',
    reign: '1837 – 1901',
    reignStart: 1837,
    reignEnd: 1901,
    lifespan: '1819 – 1901',
    title: 'Queen of the United Kingdom of Great Britain and Ireland, Empress of India',
    motto: 'Dieu et mon Droit',
    summary: 'Her 63-year reign defined the Victorian Era, marked by the Industrial Revolution, expansion of constitutional governance, and scientific and artistic flourishing.',
    keyAchievements: [
      'Made Buckingham Palace the official principal residence of the British Sovereign in July 1837.',
      'Championed Prince Albert\'s Great Exhibition of 1851 at the Crystal Palace, showcasing global invention.',
      'Presided over the Golden (1887) and Diamond (1897) Jubilees.',
      'Strictly shaped the modern constitutional role of a monarch who reigns above political factions.'
    ],
    historicalContext: 'Accessing the throne at just 18 years old, Queen Victoria restored immense moral respect to the Crown and oversaw the transformation of Britain into the world\'s pre-eminent industrial power.',
    quote: 'I will be good.',
    residenceOrPalace: 'Buckingham Palace, Windsor Castle & Osborne House',
    coronationYear: 1838
  },
  {
    id: 'george-iii',
    name: 'King George III',
    house: 'Hanover & Saxe-Coburg',
    reign: '1760 – 1820',
    reignStart: 1760,
    reignEnd: 1820,
    lifespan: '1738 – 1820',
    title: 'King of Great Britain and Ireland',
    motto: 'Dieu et mon Droit',
    summary: 'Reigned for nearly 60 years. Purchased Buckingham House in 1761 for Queen Charlotte, known affectionately as "The Queen\'s House", which became modern Buckingham Palace.',
    keyAchievements: [
      'Purchased Buckingham House in 1761, establishing the royal presence at the palace site.',
      'Founded the Royal Academy of Arts in 1768 alongside Sir Joshua Reynolds.',
      'Assembled a 65,000-volume Royal Library, later given to the nation and now at the British Library.',
      'Keen patron of agriculture ("Farmer George") and astronomer William Herschel.'
    ],
    historicalContext: 'His reign witnessed the American Revolutionary War and the defeat of Napoleon at Waterloo in 1815, sealing Britain\'s naval and international standing.',
    quote: 'Born and educated in this country, I glory in the name of Britain.',
    residenceOrPalace: 'Buckingham House & Kew Palace',
    coronationYear: 1761
  },
  {
    id: 'charles-ii',
    name: 'King Charles II',
    house: 'Stuart',
    reign: '1660 – 1685',
    reignStart: 1660,
    reignEnd: 1685,
    lifespan: '1630 – 1685',
    title: 'King of England, Scotland, and Ireland',
    motto: 'Dieu et mon Droit',
    summary: 'Known as "The Merry Monarch". Restored to the throne in May 1660 after eleven years of Cromwellian Commonwealth. Presided over the rebuilding of London and scientific enlightenment.',
    keyAchievements: [
      'The Restoration of the Monarchy in 1660, restoring parliamentary balance and the Church of England.',
      'Granted the Royal Charter to the Royal Society in 1662 (featuring Newton, Boyle, and Wren).',
      'Commissioned Sir Christopher Wren to rebuild St Paul\'s Cathedral following the Great Fire of London (1666).',
      'Founded the Royal Observatory at Greenwich in 1675.'
    ],
    historicalContext: 'Commissioned the replacement of the ancient Crown Jewels in 1661 (including St Edward\'s Crown) after the medieval regalia had been melted down under Cromwell.',
    quote: 'Let not poor Nelly starve.',
    residenceOrPalace: 'Palace of Whitehall & Windsor Castle',
    coronationYear: 1661
  },
  {
    id: 'james-vi-i',
    name: 'King James I & VI',
    house: 'Stuart',
    reign: '1603 – 1625',
    reignStart: 1603,
    reignEnd: 1625,
    lifespan: '1566 – 1625',
    title: 'King of England, Scotland, and Ireland (First to style himself "King of Great Britain")',
    motto: 'Beati pacifici (Blessed are the peacemakers)',
    summary: 'Unified the crowns of Scotland and England upon the death of Elizabeth I in 1603. Commissioned the Authorized King James Version of the Bible.',
    keyAchievements: [
      'Union of the Crowns of Scotland and England in March 1603.',
      'Commissioned the King James Bible in 1604 (published 1611), the most influential English text ever printed.',
      'Patron of William Shakespeare\'s acting troupe, renaming them "The King\'s Men".',
      'Survived the Gunpowder Plot on 5 November 1605.'
    ],
    historicalContext: 'Created the Union Flag in 1606 by combining the Cross of St George (England) with the Cross of St Andrew (Scotland).',
    quote: 'The state of monarchy is the supremest thing upon earth.',
    residenceOrPalace: 'Holyroodhouse & Westminster',
    coronationYear: 1603
  },
  {
    id: 'elizabeth-i',
    name: 'Queen Elizabeth I',
    house: 'Tudor',
    reign: '1558 – 1603',
    reignStart: 1558,
    reignEnd: 1603,
    lifespan: '1533 – 1603',
    title: 'Queen of England, France, and Ireland, Defender of the Faith',
    motto: 'Semper eadem (Always the same)',
    summary: 'The "Virgin Queen" presided over England\'s Golden Age. Defeated the Spanish Armada in 1588, established the Elizabethan Religious Settlement, and inspired a renaissance in literature.',
    keyAchievements: [
      'Decisive defeat of the invading Spanish Armada in 1588, establishing English naval prowess.',
      'Delivered the famous Speech to the Troops at Tilbury: "I have the heart and stomach of a king."',
      'Established stable Protestant compromise via the Elizabethan Religious Settlement of 1559.',
      'Presided over the flowering of Shakespeare, Marlowe, Spenser, and world exploration (Drake, Raleigh).'
    ],
    historicalContext: 'Reigned for 44 years as the last Tudor monarch, leaving an enduring legend of national independence, charismatic leadership, and cultural grandeur.',
    quote: 'I know I have the body of a weak and feeble woman, but I have the heart and stomach of a king, and of a king of England too.',
    residenceOrPalace: 'Greenwich Palace & Richmond Palace',
    coronationYear: 1559
  },
  {
    id: 'henry-viii',
    name: 'King Henry VIII',
    house: 'Tudor',
    reign: '1509 – 1547',
    reignStart: 1509,
    reignEnd: 1547,
    lifespan: '1491 – 1547',
    title: 'King of England, Lord (later King) of Ireland, Defender of the Faith',
    motto: 'Cœur Loyal (Loyal Heart)',
    summary: 'One of the most consequential monarchs in English history. Founded the Church of England, the Royal Navy, and acquired palaces including Hampton Court and St James\'s.',
    keyAchievements: [
      'Passed the Act of Supremacy in 1534, making the English monarch Supreme Head of the Church of England.',
      'Founded the Royal Navy ("Father of the Royal Navy") and built the famous warship Mary Rose.',
      'Transformed Hampton Court Palace into a Renaissance wonder and built St James\'s Palace in London.',
      'United England and Wales through the Laws in Wales Acts 1535 and 1542.'
    ],
    historicalContext: 'A passionate Renaissance prince, musician, composer of "Pastime with Good Company", and keen jouster who permanently altered the course of English constitutional history.',
    quote: 'We at no time stand so highly in our estate royal as in the time of Parliament.',
    residenceOrPalace: 'Hampton Court Palace & St James\'s Palace',
    coronationYear: 1509
  },
  {
    id: 'henry-vii',
    name: 'King Henry VII',
    house: 'Tudor',
    reign: '1485 – 1509',
    reignStart: 1485,
    reignEnd: 1509,
    lifespan: '1457 – 1509',
    title: 'King of England and Lord of Ireland',
    motto: 'Dieu et mon Droit',
    summary: 'Won the crown at the Battle of Bosworth Field, ending the Wars of the Roses. Unified the warring houses of Lancaster and York through his marriage to Elizabeth of York.',
    keyAchievements: [
      'Ended three decades of civil war (Wars of the Roses) in 1485.',
      'Created the emblematic Tudor Rose combining the red rose of Lancaster and white rose of York.',
      'Restored the royal treasury and established administrative efficiency through the Court of Star Chamber.',
      'Built the magnificent Henry VII Lady Chapel at Westminster Abbey, a masterpiece of Perpendicular Gothic.'
    ],
    historicalContext: 'Secured foreign alliances through diplomacy, including the marriage of his daughter Margaret to James IV of Scotland (which ultimately led to the union of crowns).',
    quote: 'Better a small peace than a great war.',
    residenceOrPalace: 'Richmond Palace & Westminster',
    coronationYear: 1485
  },
  {
    id: 'edward-iii',
    name: 'King Edward III',
    house: 'Plantagenet',
    reign: '1327 – 1377',
    reignStart: 1327,
    reignEnd: 1377,
    lifespan: '1312 – 1377',
    title: 'King of England, Lord of Ireland, Duke of Aquitaine',
    motto: 'Honi soit qui mal y pense (Shame on him who thinks evil of it)',
    summary: 'Reigned for 50 years. Founded the Most Noble Order of the Garter in 1348, the oldest and most prestigious order of chivalry in Britain, centered at Windsor Castle.',
    keyAchievements: [
      'Founded the Most Noble Order of the Garter at Windsor Castle in 1348.',
      'Rebuilt Windsor Castle into the grandest residential fortress in Europe.',
      'Transformed Parliament into a bicameral institution with distinct House of Lords and House of Commons.',
      'Military victories at Crécy (1346) and Poitiers (1356).'
    ],
    historicalContext: 'Made English the official spoken language of royal courts and law in 1362, fostering the birth of Chaucerian English literature.',
    quote: 'Honi soit qui mal y pense.',
    residenceOrPalace: 'Windsor Castle',
    coronationYear: 1327
  },
  {
    id: 'john',
    name: 'King John',
    house: 'Plantagenet',
    reign: '1199 – 1216',
    reignStart: 1199,
    reignEnd: 1216,
    lifespan: '1166 – 1216',
    title: 'King of England, Lord of Ireland, Duke of Normandy and Aquitaine',
    motto: 'Dieu et mon Droit',
    summary: 'Sealed Magna Carta (The Great Charter) at Runnymede in June 1215, enshrining the foundational principle of constitutional liberty: that nobody, not even the Sovereign, is above the law.',
    keyAchievements: [
      'Granted the Magna Carta at Runnymede on 15 June 1215 under pressure from the Barons.',
      'Enshrined Clause 39: the bedrock guarantee of trial by jury and due process of law.',
      'Established early naval fortifications along the English Channel.',
      'Granted the famous Royal Charter to the City of London in 1215, creating the annual Lord Mayor\'s Show.'
    ],
    historicalContext: 'Magna Carta remains the cornerstone of modern constitutional law, cited in the UK unwritten constitution, the US Constitution, and the Universal Declaration of Human Rights.',
    quote: 'To no one will we sell, to no one deny or delay right or justice. (Magna Carta, Clause 40)',
    residenceOrPalace: 'Windsor Castle & Corfe Castle',
    coronationYear: 1199
  },
  {
    id: 'william-the-conqueror',
    name: 'King William I (The Conqueror)',
    house: 'Norman',
    reign: '1066 – 1087',
    reignStart: 1066,
    reignEnd: 1087,
    lifespan: 'c. 1028 – 1087',
    title: 'King of the English, Duke of Normandy',
    motto: 'Dex Aïe (God aid us)',
    summary: 'Invaded England and won the Battle of Hastings in October 1066. Crowned at Westminster Abbey on Christmas Day. Built the Tower of London and founded Windsor Castle in 1070.',
    keyAchievements: [
      'Crowned King of England at Westminster Abbey on Christmas Day 1066, establishing the abbey as coronation site.',
      'Commissioned the landmark Domesday Book in 1086, a comprehensive survey of all land and wealth in England.',
      'Founded Windsor Castle around 1070 as part of a defensive ring around London.',
      'Built the White Tower at the Tower of London to guard the River Thames.'
    ],
    historicalContext: 'Fundamentally transformed the governance, language, castle architecture, and cultural destiny of the British Isles, inaugurating the Anglo-Norman era.',
    quote: 'I have loved justice and hated iniquity.',
    residenceOrPalace: 'Tower of London & Windsor Castle',
    coronationYear: 1066
  },
  {
    id: 'alfred-the-great',
    name: 'King Alfred the Great',
    house: 'Anglo-Saxon',
    reign: '871 – 899',
    reignStart: 871,
    reignEnd: 899,
    lifespan: '849 – 899',
    title: 'King of Wessex, King of the Anglo-Saxons',
    motto: 'Truth and Wisdom',
    summary: 'The only British monarch given the epithet "The Great". Defended England against Viking invasion, codified English law, and laid the foundations of a unified English nation.',
    keyAchievements: [
      'Decisive victory at the Battle of Edington (878), halting the Viking conquest of southern Britain.',
      'Created the "Burh" system of fortified towns that protected communities across England.',
      'Founded the first English naval fleet to combat maritime raiders.',
      'Instituted an educational revival, personally translating Latin texts into Old English so people could read in their mother tongue.'
    ],
    historicalContext: 'Alfred\'s vision of an all-English identity ("Angelcynn") was fulfilled by his grandson King Athelstan in 927, who became the first recognized King of all England.',
    quote: 'I desired to live worthily as long as I lived, and to leave after my life, to the men who should come after me, the memory of me in good works.',
    residenceOrPalace: 'Winchester (Ancient Capital of Wessex)',
    coronationYear: 871
  }
];
