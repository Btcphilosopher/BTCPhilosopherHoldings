'use client';

import React, { useState, useMemo } from 'react';
import { Search, X, Crown, Landmark, Sparkles, User, Shield } from 'lucide-react';
import { MONARCHS, Monarch } from '@/data/timelineData';
import { ROYAL_RESIDENCES, RoyalResidence } from '@/data/residencesData';
import { CROWN_JEWELS, RegaliaItem } from '@/data/crownJewelsData';
import { WORKING_ROYALS, WorkingRoyal } from '@/data/workingRoyalsData';
import { ROYAL_CEREMONIES, RoyalCeremony } from '@/data/ceremoniesData';

interface RoyalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectMonarch: (m: Monarch) => void;
  onSelectResidence: (r: RoyalResidence) => void;
}

export function RoyalSearchModal({
  isOpen,
  onClose,
  onSelectMonarch,
  onSelectResidence,
}: RoyalSearchModalProps) {
  const [query, setQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'monarchs' | 'residences' | 'jewels' | 'ceremonies'>('all');

  const filteredResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) {
      return {
        monarchs: MONARCHS.slice(0, 3),
        residences: ROYAL_RESIDENCES.slice(0, 2),
        jewels: CROWN_JEWELS.slice(0, 2),
        royals: WORKING_ROYALS.slice(0, 2),
        ceremonies: ROYAL_CEREMONIES.slice(0, 2),
      };
    }

    return {
      monarchs: MONARCHS.filter(
        (m) =>
          m.name.toLowerCase().includes(q) ||
          m.house.toLowerCase().includes(q) ||
          m.title.toLowerCase().includes(q) ||
          m.summary.toLowerCase().includes(q) ||
          m.keyAchievements.some((a) => a.toLowerCase().includes(q))
      ),
      residences: ROYAL_RESIDENCES.filter(
        (r) =>
          r.name.toLowerCase().includes(q) ||
          r.location.toLowerCase().includes(q) ||
          r.summary.toLowerCase().includes(q)
      ),
      jewels: CROWN_JEWELS.filter(
        (j) =>
          j.name.toLowerCase().includes(q) ||
          j.category.toLowerCase().includes(q) ||
          j.details.toLowerCase().includes(q) ||
          j.gemstones.some((g) => g.toLowerCase().includes(q))
      ),
      royals: WORKING_ROYALS.filter(
        (w) =>
          w.name.toLowerCase().includes(q) ||
          w.role.toLowerCase().includes(q) ||
          w.bio.toLowerCase().includes(q)
      ),
      ceremonies: ROYAL_CEREMONIES.filter(
        (c) =>
          c.title.toLowerCase().includes(q) ||
          c.location.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q)
      ),
    };
  }, [query]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl bg-[#0C152B] border border-[#C5A059]/40 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]"
        role="dialog"
        aria-labelledby="search-dialog-title"
        aria-modal="true"
      >
        {/* Search Bar Input */}
        <div className="p-4 border-b border-[#C5A059]/20 flex items-center gap-3 bg-[#111F3E]">
          <Search className="w-5 h-5 text-[#C5A059] shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search British monarchs, palaces, crown jewels, ceremonies..."
            className="w-full bg-transparent text-white placeholder-stone-400 text-sm focus:outline-none"
            autoFocus
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-stone-400 hover:text-white text-xs px-2 py-1"
            >
              Clear
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-stone-400 hover:text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-1.5 px-4 py-2.5 bg-[#091021] border-b border-stone-800 text-xs overflow-x-auto">
          {(['all', 'monarchs', 'residences', 'jewels', 'ceremonies'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilterType(tab)}
              className={`px-3 py-1 rounded-md capitalize font-medium transition-colors whitespace-nowrap ${
                filterType === tab
                  ? 'bg-[#C5A059] text-black font-semibold'
                  : 'text-stone-300 hover:text-white hover:bg-white/5'
              }`}
            >
              {tab === 'all' ? 'All Results' : tab}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="p-4 overflow-y-auto space-y-4 custom-scrollbar">
          {/* Monarchs */}
          {(filterType === 'all' || filterType === 'monarchs') && filteredResults.monarchs.length > 0 && (
            <div>
              <p className="text-[11px] font-serif uppercase tracking-widest text-[#C5A059] mb-2 flex items-center gap-1.5">
                <Crown className="w-3.5 h-3.5" /> Monarchs & Dynasties ({filteredResults.monarchs.length})
              </p>
              <div className="space-y-1.5">
                {filteredResults.monarchs.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => {
                      onSelectMonarch(m);
                      onClose();
                    }}
                    className="w-full text-left p-2.5 rounded-lg bg-[#142345] hover:bg-[#1B2F5C] border border-[#C5A059]/20 hover:border-[#C5A059]/60 transition-all flex items-center justify-between group"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-royal text-sm text-white group-hover:text-[#F3E5AB]">
                          {m.name}
                        </span>
                        <span className="text-xs text-[#C5A059]">({m.reign})</span>
                      </div>
                      <p className="text-xs text-stone-300 line-clamp-1">{m.summary}</p>
                    </div>
                    <span className="text-xs text-[#C5A059] shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                      View record ›
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Residences */}
          {(filterType === 'all' || filterType === 'residences') && filteredResults.residences.length > 0 && (
            <div>
              <p className="text-[11px] font-serif uppercase tracking-widest text-[#C5A059] mb-2 flex items-center gap-1.5">
                <Landmark className="w-3.5 h-3.5" /> Royal Residences ({filteredResults.residences.length})
              </p>
              <div className="space-y-1.5">
                {filteredResults.residences.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => {
                      onSelectResidence(r);
                      onClose();
                    }}
                    className="w-full text-left p-2.5 rounded-lg bg-[#142345] hover:bg-[#1B2F5C] border border-[#C5A059]/20 hover:border-[#C5A059]/60 transition-all flex items-center justify-between group"
                  >
                    <div>
                      <span className="font-royal text-sm text-white group-hover:text-[#F3E5AB]">
                        {r.name}
                      </span>
                      <p className="text-xs text-stone-300">{r.role}</p>
                    </div>
                    <span className="text-xs text-[#C5A059] shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                      Palace guide ›
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Crown Jewels */}
          {(filterType === 'all' || filterType === 'jewels') && filteredResults.jewels.length > 0 && (
            <div>
              <p className="text-[11px] font-serif uppercase tracking-widest text-[#C5A059] mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> Crown Jewels & Sacred Regalia
              </p>
              <div className="space-y-1.5">
                {filteredResults.jewels.map((j) => (
                  <div
                    key={j.id}
                    className="p-2.5 rounded-lg bg-[#142345] border border-[#C5A059]/20"
                  >
                    <span className="font-royal text-sm text-white">{j.name}</span>
                    <p className="text-xs text-stone-300 mt-0.5">{j.historicalRole}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Ceremonies */}
          {(filterType === 'all' || filterType === 'ceremonies') && filteredResults.ceremonies.length > 0 && (
            <div>
              <p className="text-[11px] font-serif uppercase tracking-widest text-[#C5A059] mb-2 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5" /> Ceremonies & Pageantry
              </p>
              <div className="space-y-1.5">
                {filteredResults.ceremonies.map((c) => (
                  <div
                    key={c.id}
                    className="p-2.5 rounded-lg bg-[#142345] border border-[#C5A059]/20"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-royal text-sm text-white">{c.title}</span>
                      <span className="text-xs text-[#C5A059] font-serif">{c.timing}</span>
                    </div>
                    <p className="text-xs text-stone-300 mt-0.5">{c.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="p-3 bg-[#080E1C] border-t border-stone-800 text-[11px] text-stone-300 flex items-center justify-between">
          <span>Search records across 1,100+ years of British Sovereign History</span>
          <span className="text-stone-300">Press ESC to exit</span>
        </div>
      </div>
    </div>
  );
}
