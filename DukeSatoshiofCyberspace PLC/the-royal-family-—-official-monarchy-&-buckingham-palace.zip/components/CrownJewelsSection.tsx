'use client';

import React, { useState } from 'react';
import { CROWN_JEWELS, RegaliaItem } from '@/data/crownJewelsData';
import { CrownIcon } from './RoyalCrest';
import { Sparkles, Shield, Gem, Layers } from 'lucide-react';

export function CrownJewelsSection() {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [selectedJewel, setSelectedJewel] = useState<RegaliaItem>(CROWN_JEWELS[0]);

  const categories = ['All', 'Crowns', 'Sceptres & Orbs', 'Sacred Anointing'];

  const filteredJewels = CROWN_JEWELS.filter(
    (j) => activeCategory === 'All' || j.category === activeCategory
  );

  return (
    <section id="crown-jewels" className="py-20 bg-[#070D1A] text-stone-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-3">
            <span className="w-8 h-px bg-[#C5A059]" />
            <CrownIcon className="w-6 h-6 text-[#E5C378]" />
            <span className="w-8 h-px bg-[#C5A059]" />
          </div>
          <p className="text-xs font-serif uppercase tracking-[0.25em] text-[#C5A059]">
            The Jewel House · Tower of London
          </p>
          <h2 className="text-3xl sm:text-4xl font-royal text-white">
            The Crown Jewels & Sacred Regalia
          </h2>
          <p className="text-stone-300 font-serif text-sm sm:text-base italic max-w-2xl mx-auto">
            The most potent sacred symbols of British sovereign continuity, preserved under guard at the Tower of London and used in coronations across millennia.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="mt-10 flex items-center justify-center gap-2 overflow-x-auto pb-1 text-xs">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-xl font-medium transition-all ${
                activeCategory === cat
                  ? 'bg-royal-gold text-slate-950 font-semibold shadow-md'
                  : 'bg-[#121E38] text-stone-300 hover:text-white hover:bg-[#18284C]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid of Regalia Items */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredJewels.map((item) => {
            const isSelected = item.id === selectedJewel.id;
            return (
              <div
                key={item.id}
                onClick={() => setSelectedJewel(item)}
                className={`p-6 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#132244] border-[#C5A059] shadow-[0_0_25px_rgba(197,160,89,0.22)] ring-1 ring-[#C5A059]'
                    : 'bg-[#0E172E] border-stone-800 hover:border-[#C5A059]/50 hover:bg-[#111D3B]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between pb-3 border-b border-stone-800">
                    <span className="text-[11px] font-serif uppercase tracking-widest text-[#C5A059]">
                      {item.category}
                    </span>
                    <span className="text-xs text-stone-400 tabular-nums">
                      {item.yearCreated}
                    </span>
                  </div>

                  <h3 className="text-xl font-royal text-white mt-4 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#E5C378] shrink-0" />
                    <span>{item.name}</span>
                  </h3>

                  <p className="mt-2 text-xs text-[#E5C378] font-serif italic">
                    {item.historicalRole}
                  </p>

                  <p className="mt-3 text-xs text-stone-300 leading-relaxed font-sans line-clamp-3">
                    {item.details}
                  </p>

                  {/* Gemstone Highlights */}
                  <div className="mt-4 pt-3 border-t border-stone-800/80 space-y-1">
                    {item.gemstones.slice(0, 3).map((gem, gIdx) => (
                      <div key={gIdx} className="flex items-center gap-1.5 text-[11px] text-stone-300">
                        <Gem className="w-3 h-3 text-[#C5A059] shrink-0" />
                        <span className="truncate">{gem}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-6 pt-3 border-t border-stone-800 flex items-center justify-between text-xs text-stone-400">
                  <span className="font-serif">Weight: <strong className="text-stone-200">{item.weightOrSize}</strong></span>
                  <span className="text-[#C5A059] font-medium">Tower of London</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Jewel Detailed Feature Banner */}
        <div className="mt-12 p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#101F3E] via-[#0E1933] to-[#0A1224] border border-[#C5A059]/40 shadow-2xl">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="space-y-2 max-w-2xl">
              <div className="flex items-center gap-2 text-xs font-serif uppercase tracking-widest text-[#C5A059]">
                <Layers className="w-3.5 h-3.5" />
                <span>Featured Regalia Treasure</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-royal text-white">
                {selectedJewel.name} ({selectedJewel.yearCreated})
              </h3>
              <p className="text-sm text-stone-300 font-sans leading-relaxed">
                {selectedJewel.details}
              </p>
              <div className="flex flex-wrap gap-2 pt-2">
                {selectedJewel.gemstones.map((gem, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 rounded bg-[#17274F] border border-[#C5A059]/30 text-xs text-stone-200"
                  >
                    ✦ {gem}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#091022] border border-[#C5A059]/30 text-xs space-y-2 shrink-0 md:min-w-[240px]">
              <span className="text-xs uppercase tracking-wider text-[#C5A059] font-serif block">
                Regalia Attributes
              </span>
              <div>
                <span className="text-stone-400 block">Materials:</span>
                <span className="text-white font-medium">{selectedJewel.materials}</span>
              </div>
              <div>
                <span className="text-stone-400 block">Weight / Dimensions:</span>
                <span className="text-white font-medium">{selectedJewel.weightOrSize}</span>
              </div>
              <div className="pt-2 text-[11px] text-stone-400 font-serif italic">
                Preserved under sovereign guard at the Martin Tower & Jewel House.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
