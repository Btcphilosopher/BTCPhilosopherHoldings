'use client';

import React, { useState } from 'react';
import { RoyalCrest } from './RoyalCrest';
import { Search, Globe, ChevronDown, Menu, X, Accessibility, Calendar } from 'lucide-react';

interface RoyalHeaderProps {
  onOpenSearch: () => void;
  onOpenAccessibility: () => void;
  onOpenVisitPlanner: () => void;
}

export function RoyalHeader({
  onOpenSearch,
  onOpenAccessibility,
  onOpenVisitPlanner,
}: RoyalHeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('English');
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);

  const languages = ['English', 'Cymraeg (Welsh)', 'Gàidhlig (Scottish Gaelic)', 'Français', 'Español'];

  return (
    <header className="sticky top-0 z-40 w-full shadow-md">
      {/* Upper Institutional White Bar (Matching Buckingham Palace design) */}
      <div className="bg-[#FAF7F2] text-[#0D182E] border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
          {/* Brand & Royal Arms Lockup */}
          <a href="#" className="flex items-center gap-3.5 group">
            <RoyalCrest className="w-10 h-10 text-[#0D182E] group-hover:text-[#9E7D3B] transition-colors shrink-0" />
            <div className="flex flex-col">
              <span className="font-royal text-lg sm:text-xl font-bold tracking-[0.18em] text-[#0D182E] leading-tight">
                BUCKINGHAM PALACE
              </span>
              <span className="text-[10px] sm:text-[11px] font-serif uppercase tracking-[0.24em] text-stone-600 mt-0.5">
                THE OFFICIAL RESIDENCE OF THE MONARCH
              </span>
            </div>
          </a>

          {/* Right Utility Actions */}
          <div className="flex items-center gap-4 sm:gap-6 text-xs text-stone-700">
            {/* Live Flag / Monarchy Indicator (Quiet text) */}
            <div className="hidden xl:flex items-center gap-2 text-stone-600 text-xs">
              <span className="w-2 h-2 rounded-full bg-[#C5A059]" />
              <span>Royal Standard Flying: In Residence</span>
            </div>

            {/* Language Selector */}
            <div className="relative hidden sm:block">
              <button
                onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                className="flex items-center gap-1.5 hover:text-black transition-colors py-1"
                aria-expanded={langDropdownOpen}
              >
                <Globe className="w-4 h-4 text-stone-500" />
                <span className="font-medium">{selectedLanguage}</span>
                <ChevronDown className="w-3.5 h-3.5 text-stone-400" />
              </button>

              {langDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white border border-stone-200 rounded-lg shadow-xl py-1 z-50 text-xs">
                  {languages.map((lang) => (
                    <button
                      key={lang}
                      onClick={() => {
                        setSelectedLanguage(lang);
                        setLangDropdownOpen(false);
                      }}
                      className="w-full text-left px-3.5 py-2 hover:bg-stone-100 text-stone-800 transition-colors"
                    >
                      {lang}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Accessibility Button */}
            <button
              onClick={onOpenAccessibility}
              className="flex items-center gap-1.5 hover:text-black transition-colors"
              title="Accessibility & Inclusion Options"
            >
              <Accessibility className="w-4 h-4 text-stone-500" />
              <span className="hidden md:inline font-medium">Accessibility</span>
            </button>

            {/* Search Trigger */}
            <button
              onClick={onOpenSearch}
              className="flex items-center gap-1.5 hover:text-black transition-colors"
              title="Search the Royal Archive"
            >
              <Search className="w-4 h-4 text-stone-500" />
              <span className="font-medium">Search</span>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-1 text-stone-700 hover:text-black"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Main Deep Royal Navy Navigation Bar with Gold Hairline */}
      <nav className="bg-[#0D1B3A] text-white border-b border-[#C5A059]/40 border-t border-[#C5A059]/20 shadow-inner">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-13">
            {/* Desktop Navigation Links */}
            <div className="hidden lg:flex items-center space-x-7 text-sm font-medium tracking-wide">
              <a
                href="#royal-family"
                className="hover:text-[#F3E5AB] transition-colors py-2 border-b-2 border-transparent hover:border-[#C5A059] flex items-center gap-1 whitespace-nowrap"
              >
                The Royal Family
              </a>
              <a
                href="#historical-timeline"
                className="hover:text-[#F3E5AB] transition-colors py-2 border-b-2 border-transparent hover:border-[#C5A059] flex items-center gap-1 text-[#F3E5AB] font-semibold whitespace-nowrap"
              >
                Historical Timeline
                <span className="text-[10px] font-sans font-normal uppercase tracking-wider text-[#C5A059] px-1.5 py-0.2 bg-[#1A2D57] rounded border border-[#C5A059]/30 ml-1">
                  1,100 Yrs
                </span>
              </a>
              <a
                href="#residences"
                className="hover:text-[#F3E5AB] transition-colors py-2 border-b-2 border-transparent hover:border-[#C5A059] whitespace-nowrap"
              >
                The Palaces
              </a>
              <a
                href="#crown-jewels"
                className="hover:text-[#F3E5AB] transition-colors py-2 border-b-2 border-transparent hover:border-[#C5A059] whitespace-nowrap"
              >
                Crown Jewels & Collections
              </a>
              <a
                href="#pageantry"
                className="hover:text-[#F3E5AB] transition-colors py-2 border-b-2 border-transparent hover:border-[#C5A059] whitespace-nowrap"
              >
                Ceremonies & Pageantry
              </a>
              <a
                href="#plan-visit"
                className="hover:text-[#F3E5AB] transition-colors py-2 border-b-2 border-transparent hover:border-[#C5A059] whitespace-nowrap"
              >
                Visit
              </a>
            </div>

            {/* Quick CTA Button: Plan Your Visit */}
            <div className="hidden sm:flex items-center gap-3">
              <button
                onClick={onOpenVisitPlanner}
                className="px-4 py-1.5 bg-royal-gold text-slate-950 font-semibold text-xs rounded-md hover:brightness-110 transition-all shadow flex items-center gap-1.5 whitespace-nowrap"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Book Tickets</span>
                <span>›</span>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#0A142A] border-t border-[#C5A059]/30 px-4 pt-3 pb-6 space-y-3">
            <a
              href="#royal-family"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-sm text-stone-200 hover:text-[#C5A059] border-b border-stone-800"
            >
              The Royal Family
            </a>
            <a
              href="#historical-timeline"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-sm text-[#F3E5AB] font-semibold border-b border-stone-800 flex items-center justify-between"
            >
              <span>Historical Timeline</span>
              <span className="text-xs text-[#C5A059]">871 AD – Present</span>
            </a>
            <a
              href="#residences"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-sm text-stone-200 hover:text-[#C5A059] border-b border-stone-800"
            >
              Royal Residences & Palaces
            </a>
            <a
              href="#crown-jewels"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-sm text-stone-200 hover:text-[#C5A059] border-b border-stone-800"
            >
              Crown Jewels & Sacred Regalia
            </a>
            <a
              href="#pageantry"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-sm text-stone-200 hover:text-[#C5A059] border-b border-stone-800"
            >
              Ceremonies & Changing of the Guard
            </a>
            <div className="pt-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenVisitPlanner();
                }}
                className="w-full py-2.5 bg-royal-gold text-slate-950 font-semibold text-xs rounded-lg text-center"
              >
                Plan Your Visit & Tickets
              </button>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
