import React from 'react';

export function RoyalCrest({ className = 'w-12 h-12 text-[#C5A059]' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      fill="currentColor"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Royal Coat of Arms Insignia"
    >
      {/* Imperial Crown atop Crest */}
      <path
        d="M50 12 L53 18 L59 15 L57 23 L65 24 L60 30 L66 35 L58 37 L50 29 L42 37 L34 35 L40 30 L35 24 L43 23 L41 15 L47 18 Z"
        fill="currentColor"
      />
      <circle cx="50" cy="10" r="2.5" fill="currentColor" />
      <path d="M48 6 H52 V14 H48 Z" fill="currentColor" />
      <path d="M46 9 H54 V11 H46 Z" fill="currentColor" />

      {/* Royal Mantling and Flourishes */}
      <path
        d="M28 28 C22 34 20 44 26 50 C29 44 33 42 35 44 C29 38 32 30 28 28 Z"
        fill="currentColor"
        opacity="0.85"
      />
      <path
        d="M72 28 C78 34 80 44 74 50 C71 44 67 42 65 44 C71 38 68 30 72 28 Z"
        fill="currentColor"
        opacity="0.85"
      />

      {/* Royal Shield (Quartered) */}
      <path
        d="M32 38 H68 C68 38 69 62 50 78 C31 62 32 38 32 38 Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.5"
      />
      {/* Quartering Dividers */}
      <line x1="50" y1="38" x2="50" y2="76" stroke="currentColor" strokeWidth="1.5" />
      <line x1="32" y1="56" x2="68" y2="56" stroke="currentColor" strokeWidth="1.5" />

      {/* Lions Passant (England - Q1 & Q4) */}
      <path d="M37 43 H45 M38 46 H44 M39 49 H43" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M55 61 H63 M56 64 H62 M57 67 H61" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />

      {/* Scottish Lion Rampant (Scotland - Q2) */}
      <path d="M57 43 L61 46 L58 49 L62 53" stroke="currentColor" strokeWidth="1.2" fill="none" />

      {/* Irish Harp (Ireland - Q3) */}
      <path d="M38 61 C42 61 44 65 43 70 M40 63 V69 M42 64 V68" stroke="currentColor" strokeWidth="1.2" fill="none" />

      {/* Lion Supporter (Dexter - Left) */}
      <path
        d="M18 42 C16 46 16 52 19 56 C22 55 24 51 23 48 C26 50 28 55 26 62 C24 67 19 72 16 77 C22 75 26 71 28 66 C29 70 31 74 34 76 C32 72 30 68 30 63 C31 56 26 48 24 45 C23 43 20 41 18 42 Z"
        fill="currentColor"
      />

      {/* Unicorn Supporter (Sinister - Right) */}
      <path
        d="M82 42 C84 46 84 52 81 56 C78 55 76 51 77 48 C74 50 72 55 74 62 C76 67 81 72 84 77 C78 75 74 71 72 66 C71 70 69 74 66 76 C68 72 70 68 70 63 C69 56 74 48 76 45 C77 43 80 41 82 42 Z"
        fill="currentColor"
      />
      {/* Unicorn Horn */}
      <line x1="82" y1="42" x2="88" y2="34" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />

      {/* Royal Motto Scroll: Dieu et mon Droit */}
      <path
        d="M15 82 C30 79 40 85 50 82 C60 85 70 79 85 82 C82 86 78 88 74 87 C65 89 57 86 50 87 C43 86 35 89 26 87 C22 88 18 86 15 82 Z"
        fill="currentColor"
        opacity="0.9"
      />
    </svg>
  );
}

export function CrownIcon({ className = 'w-6 h-6 text-[#C5A059]' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <path d="M5 16L3 5L8.5 10L12 4L15.5 10L21 5L19 16H5ZM19 19C19 19.5523 18.5523 20 18 20H6C5.44772 20 5 19.5523 5 19V17H19V19Z" />
    </svg>
  );
}
