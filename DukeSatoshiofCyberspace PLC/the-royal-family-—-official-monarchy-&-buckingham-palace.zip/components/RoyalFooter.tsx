'use client';

import React from 'react';
import { RoyalCrest } from './RoyalCrest';
import { Shield, ExternalLink, Globe, Heart } from 'lucide-react';

interface RoyalFooterProps {
  onOpenAccessibility: () => void;
  onOpenVisitPlanner: () => void;
  onOpenSearch: () => void;
}

export function RoyalFooter({
  onOpenAccessibility,
  onOpenVisitPlanner,
  onOpenSearch,
}: RoyalFooterProps) {
  return (
    <footer className="w-full bg-[#050B16] text-stone-300 border-t border-[#C5A059]/30 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Crest & Proclamation */}
        <div className="flex flex-col md:flex-row items-center justify-between pb-12 border-b border-stone-800 gap-8 text-center md:text-left">
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <RoyalCrest className="w-14 h-14 text-[#C5A059] shrink-0" />
            <div>
              <span className="font-royal text-xl sm:text-2xl font-bold tracking-[0.16em] text-white block">
                THE ROYAL FAMILY
              </span>
              <span className="text-xs font-serif uppercase tracking-[0.22em] text-[#C5A059] mt-0.5 block">
                BUCKINGHAM PALACE · WINDSOR CASTLE · HOLYROODHOUSE
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onOpenVisitPlanner}
              className="px-5 py-2.5 bg-royal-gold text-slate-950 font-semibold text-xs rounded-lg hover:brightness-110 transition-all shadow"
            >
              Plan a Palace Visit
            </button>
            <button
              onClick={onOpenSearch}
              className="px-4 py-2.5 bg-[#0F1C36] hover:bg-[#16274D] border border-stone-700 text-xs text-stone-200 rounded-lg transition-colors"
            >
              Search Archives
            </button>
          </div>
        </div>

        {/* Footer Navigation Columns */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-12 border-b border-stone-800 text-xs">
          {/* Col 1 */}
          <div className="space-y-3">
            <h4 className="font-royal text-sm font-bold text-white uppercase tracking-wider">
              The Sovereign
            </h4>
            <ul className="space-y-2 text-stone-400">
              <li><a href="#royal-family" className="hover:text-white transition-colors">His Majesty King Charles III</a></li>
              <li><a href="#royal-family" className="hover:text-white transition-colors">Her Majesty Queen Camilla</a></li>
              <li><a href="#royal-family" className="hover:text-white transition-colors">TRH The Prince and Princess of Wales</a></li>
              <li><a href="#royal-family" className="hover:text-white transition-colors">The Working Monarchy</a></li>
              <li><a href="#royal-family" className="hover:text-white transition-colors">Royal Patronages & Charities</a></li>
            </ul>
          </div>

          {/* Col 2 */}
          <div className="space-y-3">
            <h4 className="font-royal text-sm font-bold text-white uppercase tracking-wider">
              Royal History
            </h4>
            <ul className="space-y-2 text-stone-400">
              <li><a href="#historical-timeline" className="hover:text-white transition-colors">Complete Sovereign Timeline</a></li>
              <li><a href="#historical-timeline" className="hover:text-white transition-colors">House of Windsor (1917–Present)</a></li>
              <li><a href="#historical-timeline" className="hover:text-white transition-colors">Queen Victoria & Hanoverian Era</a></li>
              <li><a href="#historical-timeline" className="hover:text-white transition-colors">Tudor & Plantagenet Lineages</a></li>
              <li><a href="#historical-timeline" className="hover:text-white transition-colors">King Alfred the Great & Wessex</a></li>
            </ul>
          </div>

          {/* Col 3 */}
          <div className="space-y-3">
            <h4 className="font-royal text-sm font-bold text-white uppercase tracking-wider">
              Residences & Palaces
            </h4>
            <ul className="space-y-2 text-stone-400">
              <li><a href="#residences" className="hover:text-white transition-colors">Buckingham Palace (London)</a></li>
              <li><a href="#residences" className="hover:text-white transition-colors">Windsor Castle (Berkshire)</a></li>
              <li><a href="#residences" className="hover:text-white transition-colors">Palace of Holyroodhouse (Edinburgh)</a></li>
              <li><a href="#residences" className="hover:text-white transition-colors">Balmoral Castle (Highlands)</a></li>
              <li><a href="#residences" className="hover:text-white transition-colors">Sandringham House (Norfolk)</a></li>
            </ul>
          </div>

          {/* Col 4 */}
          <div className="space-y-3">
            <h4 className="font-royal text-sm font-bold text-white uppercase tracking-wider">
              Visitor Information
            </h4>
            <ul className="space-y-2 text-stone-400">
              <li><a href="#pageantry" className="hover:text-white transition-colors">Changing of the Guard Schedule</a></li>
              <li><a href="#crown-jewels" className="hover:text-white transition-colors">Crown Jewels at Tower of London</a></li>
              <li><button onClick={onOpenAccessibility} className="hover:text-white transition-colors text-left">Accessibility & Audio Tours</button></li>
              <li><button onClick={onOpenVisitPlanner} className="hover:text-white transition-colors text-left">State Rooms Ticket Booking</button></li>
              <li><a href="#pageantry" className="hover:text-white transition-colors">Ceremonies & Trooping the Colour</a></li>
            </ul>
          </div>
        </div>

        {/* Bottom Legal & Crown Copyright */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between text-xs text-stone-500 gap-4 text-center md:text-left">
          <div>
            <p>© Crown Copyright. The Royal Household, London.</p>
            <p className="mt-0.5 text-stone-600 font-serif">
              Dieu et mon Droit · Honi soit qui mal y pense
            </p>
          </div>

          <div className="flex items-center gap-6">
            <button onClick={onOpenAccessibility} className="hover:text-stone-300 transition-colors">
              Accessibility Statement
            </button>
            <span aria-hidden="true">·</span>
            <span className="hover:text-stone-300 transition-colors">
              Royal Collection Trust
            </span>
            <span aria-hidden="true">·</span>
            <span className="hover:text-stone-300 transition-colors">
              The Commonwealth (56 Nations)
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
