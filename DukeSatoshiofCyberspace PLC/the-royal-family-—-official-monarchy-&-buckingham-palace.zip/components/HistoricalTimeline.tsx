'use client';

import React, { useState, useMemo } from 'react';
import { MONARCHS, Monarch } from '@/data/timelineData';
import { CrownIcon } from './RoyalCrest';
import { Search, ArrowUpDown, Calendar, Landmark, BookOpen, Quote, Sparkles, Filter, ChevronRight } from 'lucide-react';

interface HistoricalTimelineProps {
  onSelectMonarch: (m: Monarch) => void;
}

export function HistoricalTimeline({ onSelectMonarch }: HistoricalTimelineProps) {
  const [selectedHouse, setSelectedHouse] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');
  const [activeView, setActiveView] = useState<'timeline' | 'grid'>('timeline');

  const dynasties = [
    { label: 'All Dynasties', value: 'All' },
    { label: 'Windsor (1917–Present)', value: 'Windsor' },
    { label: 'Hanover & Saxe-Coburg (1714–1917)', value: 'Hanover & Saxe-Coburg' },
    { label: 'House of Stuart (1603–1714)', value: 'Stuart' },
    { label: 'House of Tudor (1485–1603)', value: 'Tudor' },
    { label: 'Plantagenet (1154–1485)', value: 'Plantagenet' },
    { label: 'Norman (1066–1154)', value: 'Norman' },
    { label: 'Anglo-Saxon (871–1066)', value: 'Anglo-Saxon' },
  ];

  const filteredMonarchs = useMemo(() => {
    let list = MONARCHS.filter((m) => {
      const matchHouse = selectedHouse === 'All' || m.house === selectedHouse;
      const q = searchQuery.toLowerCase().trim();
      const matchQuery =
        !q ||
        m.name.toLowerCase().includes(q) ||
        m.reign.toLowerCase().includes(q) ||
        m.summary.toLowerCase().includes(q) ||
        m.historicalContext.toLowerCase().includes(q) ||
        m.keyAchievements.some((a) => a.toLowerCase().includes(q)) ||
        (m.quote && m.quote.toLowerCase().includes(q));

      return matchHouse && matchQuery;
    });

    return list.sort((a, b) => {
      if (sortOrder === 'desc') {
        return (b.reignStart || 0) - (a.reignStart || 0);
      } else {
        return (a.reignStart || 0) - (b.reignStart || 0);
      }
    });
  }, [selectedHouse, searchQuery, sortOrder]);

  return (
    <section id="historical-timeline" className="relative w-full py-20 bg-[#0B1428] text-stone-100 overflow-hidden">
      {/* Decorative Subtle Background Crest Watermark or Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(#C5A059_1px,transparent_1px)] [background-size:32px_32px] opacity-[0.03] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header with Royal Flourish */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-3">
            <span className="w-10 h-px bg-gradient-to-r from-transparent to-[#C5A059]" />
            <CrownIcon className="w-7 h-7 text-[#E5C378]" />
            <span className="w-10 h-px bg-gradient-to-l from-transparent to-[#C5A059]" />
          </div>

          <div className="text-xs font-serif tracking-[0.25em] uppercase text-[#C5A059]">
            The British Sovereign Lineage · 871 AD – Present
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-royal tracking-wide text-white leading-tight">
            Historical Timeline of the Monarchy
          </h2>

          <p className="text-stone-300 font-serif text-base sm:text-lg italic leading-relaxed">
            &ldquo;A constitutional lineage spanning over eleven centuries—from King Alfred the Great&apos;s defense of the realm to the modern reign of His Majesty King Charles III.&rdquo;
          </p>

          {/* Archival Metrics Ribbon */}
          <div className="pt-2 flex items-center justify-center gap-6 sm:gap-10 text-xs font-sans text-stone-400">
            <div>
              <span className="text-[#F3E5AB] font-bold text-sm tabular-nums">1,155+</span> Years of Continuity
            </div>
            <span aria-hidden="true" className="text-stone-700">·</span>
            <div>
              <span className="text-[#F3E5AB] font-bold text-sm tabular-nums">8</span> Royal Dynasties
            </div>
            <span aria-hidden="true" className="text-stone-700">·</span>
            <div>
              <span className="text-[#F3E5AB] font-bold text-sm tabular-nums">62</span> Sovereign Monarchs
            </div>
          </div>
        </div>

        {/* Filter Controls Toolbar */}
        <div className="mt-12 p-4 rounded-2xl bg-[#0F1B38] border border-[#C5A059]/30 shadow-xl space-y-4">
          {/* Top Row: Search & View Modes */}
          <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[#C5A059] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter by monarch, event (e.g. Magna Carta, Armada, Blitz, Victoria, Alfred)..."
                className="w-full bg-[#15254D] border border-stone-700/60 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-stone-400 focus:outline-none focus:border-[#C5A059] transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>

            {/* View Mode & Sort Switches */}
            <div className="flex items-center gap-2 justify-end">
              {/* Chronology Order Button */}
              <button
                onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#15254D] hover:bg-[#1D3264] border border-stone-700 text-xs text-stone-200 transition-colors whitespace-nowrap"
                title="Toggle Chronological Direction"
              >
                <ArrowUpDown className="w-3.5 h-3.5 text-[#C5A059]" />
                <span>{sortOrder === 'desc' ? 'Modern to Ancient' : 'Ancient to Modern'}</span>
              </button>

              {/* View Type: Timeline vs Grid */}
              <div className="flex items-center p-1 bg-[#15254D] rounded-lg border border-stone-700">
                <button
                  onClick={() => setActiveView('timeline')}
                  className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
                    activeView === 'timeline'
                      ? 'bg-royal-gold text-slate-950 font-semibold shadow-sm'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  Timeline Rail
                </button>
                <button
                  onClick={() => setActiveView('grid')}
                  className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
                    activeView === 'grid'
                      ? 'bg-royal-gold text-slate-950 font-semibold shadow-sm'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  Exhibition Cards
                </button>
              </div>
            </div>
          </div>

          {/* Dynasty Filter Buttons (Clean segmented buttons, no pills) */}
          <div className="pt-2 border-t border-stone-800 flex items-center gap-1.5 overflow-x-auto pb-1 text-xs custom-scrollbar">
            <span className="text-[11px] font-serif uppercase tracking-widest text-[#C5A059] mr-2 shrink-0 flex items-center gap-1">
              <Filter className="w-3 h-3" /> Dynasty:
            </span>
            {dynasties.map((dynasty) => (
              <button
                key={dynasty.value}
                onClick={() => setSelectedHouse(dynasty.value)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                  selectedHouse === dynasty.value
                    ? 'bg-[#C5A059] text-slate-950 font-semibold shadow'
                    : 'text-stone-300 hover:text-white bg-[#15254D]/60 hover:bg-[#15254D]'
                }`}
              >
                {dynasty.label}
              </button>
            ))}
          </div>
        </div>

        {/* Results Counter */}
        <div className="mt-6 flex items-center justify-between text-xs text-stone-400 px-2">
          <span>
            Displaying <strong className="text-[#F3E5AB] font-bold">{filteredMonarchs.length}</strong> Sovereign Records
            {selectedHouse !== 'All' ? ` under House of ${selectedHouse}` : ''}
          </span>
          <span className="font-serif italic text-stone-400">Click any monarch to inspect coronation & reign archives</span>
        </div>

        {/* Monarch Timeline Rail View */}
        {activeView === 'timeline' && (
          <div className="mt-8 relative">
            {/* Center Vertical Gold Heritage Guideline */}
            <div className="hidden lg:block absolute left-1/2 top-4 bottom-8 w-px -translate-x-1/2 bg-gradient-to-b from-[#C5A059] via-[#C5A059]/40 to-[#C5A059]/10" />

            <div className="space-y-12 relative">
              {filteredMonarchs.map((monarch, index) => {
                const isEven = index % 2 === 0;
                return (
                  <div
                    key={monarch.id}
                    className={`flex flex-col lg:flex-row items-center gap-8 ${
                      isEven ? 'lg:flex-row-reverse' : ''
                    }`}
                  >
                    {/* Content Card (Half Width on LG) */}
                    <div className="w-full lg:w-1/2">
                      <div
                        onClick={() => onSelectMonarch(monarch)}
                        className="group cursor-pointer p-6 sm:p-7 rounded-2xl bg-gradient-to-br from-[#101D3D] to-[#0A1326] border border-[#C5A059]/30 hover:border-[#C5A059] shadow-xl hover:shadow-[0_0_30px_rgba(197,160,89,0.18)] transition-all transform hover:-translate-y-1 relative"
                      >
                        {/* Top Metadata Line */}
                        <div className="flex items-center justify-between gap-2 pb-3 border-b border-stone-800">
                          <div className="flex items-center gap-2 text-xs font-serif tracking-widest text-[#C5A059] uppercase">
                            <span>House of {monarch.house}</span>
                            <span aria-hidden="true">·</span>
                            <span>Crowned {monarch.coronationYear}</span>
                          </div>
                          <span className="font-royal text-sm font-bold text-[#F3E5AB] tabular-nums bg-[#162752] px-2.5 py-0.5 rounded border border-[#C5A059]/40">
                            {monarch.reign}
                          </span>
                        </div>

                        {/* Monarch Name & Style */}
                        <div className="mt-4">
                          <h3 className="text-2xl font-royal tracking-wide text-white group-hover:text-gold-gradient transition-colors">
                            {monarch.name}
                          </h3>
                          <p className="text-xs text-stone-300 font-serif italic mt-1 line-clamp-1">
                            &ldquo;{monarch.title}&rdquo;
                          </p>
                        </div>

                        {/* Narrative Summary */}
                        <p className="mt-3 text-sm text-stone-300 leading-relaxed font-sans line-clamp-3">
                          {monarch.summary}
                        </p>

                        {/* Key Achievement Highlights */}
                        <div className="mt-4 space-y-1.5 pt-3 border-t border-stone-800/80">
                          {monarch.keyAchievements.slice(0, 2).map((achievement, aIdx) => (
                            <div key={aIdx} className="flex items-start gap-2 text-xs text-stone-300">
                              <span className="text-[#C5A059] font-bold mt-0.5">✦</span>
                              <span className="line-clamp-1">{achievement}</span>
                            </div>
                          ))}
                        </div>

                        {/* Quote Excerpt if present */}
                        {monarch.quote && (
                          <div className="mt-4 p-3 rounded-lg bg-[#142345]/50 border-l-2 border-[#C5A059] text-xs font-serif italic text-stone-300 line-clamp-2">
                            &ldquo;{monarch.quote}&rdquo;
                          </div>
                        )}

                        {/* Action Link Footer */}
                        <div className="mt-5 pt-3 border-t border-[#C5A059]/20 flex items-center justify-between">
                          <span className="text-xs text-stone-400 flex items-center gap-1.5">
                            <Landmark className="w-3.5 h-3.5 text-[#C5A059]" />
                            {monarch.residenceOrPalace}
                          </span>
                          <span className="text-xs font-semibold text-[#F3E5AB] group-hover:translate-x-1 transition-transform flex items-center gap-1">
                            Examine Record <ChevronRight className="w-3.5 h-3.5" />
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Central Gold Node Icon on Desktop */}
                    <div className="hidden lg:flex shrink-0 w-12 h-12 rounded-full bg-[#0D182E] border-2 border-[#C5A059] items-center justify-center text-[#F3E5AB] shadow-lg z-10 group">
                      <CrownIcon className="w-6 h-6 text-[#E5C378]" />
                    </div>

                    {/* Opposite Spacer (Half Width on LG) */}
                    <div className="hidden lg:block w-1/2" />
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Exhibition Cards Grid View */}
        {activeView === 'grid' && (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMonarchs.map((monarch) => (
              <div
                key={monarch.id}
                onClick={() => onSelectMonarch(monarch)}
                className="group cursor-pointer p-6 rounded-2xl bg-gradient-to-br from-[#101D3D] to-[#0A1326] border border-[#C5A059]/30 hover:border-[#C5A059] shadow-xl hover:shadow-[0_0_25px_rgba(197,160,89,0.18)] transition-all transform hover:-translate-y-1 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between pb-3 border-b border-stone-800">
                    <span className="text-xs font-serif tracking-widest text-[#C5A059] uppercase">
                      House of {monarch.house}
                    </span>
                    <span className="font-royal text-xs font-bold text-[#F3E5AB] tabular-nums bg-[#162752] px-2 py-0.5 rounded border border-[#C5A059]/40">
                      {monarch.reign}
                    </span>
                  </div>

                  <h3 className="text-xl font-royal text-white mt-4 group-hover:text-[#F3E5AB] transition-colors">
                    {monarch.name}
                  </h3>
                  <p className="text-xs text-stone-400 font-serif italic mt-0.5 line-clamp-1">
                    Crowned {monarch.coronationYear} AD
                  </p>

                  <p className="mt-3 text-xs text-stone-300 leading-relaxed font-sans line-clamp-3">
                    {monarch.summary}
                  </p>

                  {monarch.quote && (
                    <blockquote className="mt-4 p-2.5 rounded bg-[#142345]/50 border-l-2 border-[#C5A059] text-xs font-serif italic text-stone-300 line-clamp-2">
                      &ldquo;{monarch.quote}&rdquo;
                    </blockquote>
                  )}
                </div>

                <div className="mt-6 pt-3 border-t border-stone-800 flex items-center justify-between text-xs">
                  <span className="text-stone-400 flex items-center gap-1">
                    <Landmark className="w-3.5 h-3.5 text-[#C5A059]" />
                    {monarch.residenceOrPalace.split('&')[0]}
                  </span>
                  <span className="font-semibold text-[#F3E5AB] flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    View Record ›
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
