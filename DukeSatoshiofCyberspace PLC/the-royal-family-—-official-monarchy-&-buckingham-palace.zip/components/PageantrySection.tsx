'use client';

import React, { useState } from 'react';
import { ROYAL_CEREMONIES, RoyalCeremony } from '@/data/ceremoniesData';
import { CrownIcon } from './RoyalCrest';
import { Clock, MapPin, Shield, Eye, Calendar, Award } from 'lucide-react';

export function PageantrySection() {
  const [selectedCeremony, setSelectedCeremony] = useState<RoyalCeremony>(ROYAL_CEREMONIES[0]);

  return (
    <section id="pageantry" className="py-20 bg-[#0B152B] text-stone-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-3">
            <span className="w-8 h-px bg-[#C5A059]" />
            <CrownIcon className="w-6 h-6 text-[#E5C378]" />
            <span className="w-8 h-px bg-[#C5A059]" />
          </div>
          <p className="text-xs font-serif uppercase tracking-[0.25em] text-[#C5A059]">
            The Household Division & State Pageantry
          </p>
          <h2 className="text-3xl sm:text-4xl font-royal text-white">
            Ceremonial Traditions & Guard Schedules
          </h2>
          <p className="text-stone-300 font-serif text-sm sm:text-base italic max-w-2xl mx-auto">
            Living history in motion: centuries-old military discipline, scarlet tunics, bearskin caps, and ceremonial processions across London and Windsor.
          </p>
        </div>

        {/* Live Guard Status Ticker Box */}
        <div className="mt-10 p-4 rounded-xl bg-[#122144] border border-[#C5A059]/40 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
            <div>
              <p className="text-xs font-royal text-white font-bold">
                Today&apos;s Buckingham Palace Guard Mount Status
              </p>
              <p className="text-xs text-stone-300">
                Scheduled for 11:00 AM BST on the Palace Forecourt. Band accompanied by Foot Guards.
              </p>
            </div>
          </div>
          <span className="text-xs text-[#E5C378] font-serif uppercase tracking-wider shrink-0 bg-[#0C152B] px-3 py-1.5 rounded-lg border border-[#C5A059]/30">
            Confirmed · Free Public Spectacle
          </span>
        </div>

        {/* Ceremonies Grid */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          {ROYAL_CEREMONIES.map((ceremony) => {
            const isSelected = ceremony.id === selectedCeremony.id;
            return (
              <div
                key={ceremony.id}
                onClick={() => setSelectedCeremony(ceremony)}
                className={`p-6 sm:p-7 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#152750] border-[#C5A059] shadow-xl ring-1 ring-[#C5A059]'
                    : 'bg-[#0E1B38] border-stone-800 hover:border-[#C5A059]/50 hover:bg-[#122245]'
                }`}
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-stone-800">
                    <span className="text-xs text-[#E5C378] font-serif uppercase tracking-wider flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      {ceremony.timing}
                    </span>
                    <span className="text-xs text-stone-400">
                      {ceremony.regimentOrParticipants.split('&')[0]}
                    </span>
                  </div>

                  <h3 className="text-2xl font-royal text-white">
                    {ceremony.title}
                  </h3>

                  <div className="flex items-center gap-2 text-xs text-stone-300">
                    <MapPin className="w-4 h-4 text-[#C5A059] shrink-0" />
                    <span>{ceremony.location}</span>
                  </div>

                  <p className="text-sm text-stone-300 leading-relaxed font-sans">
                    {ceremony.description}
                  </p>

                  <div className="p-3.5 rounded-xl bg-[#0B152B] border border-stone-800 text-xs text-stone-300 space-y-1.5">
                    <div className="flex items-start gap-2">
                      <Shield className="w-3.5 h-3.5 text-[#C5A059] shrink-0 mt-0.5" />
                      <span><strong>Regalia & Dress:</strong> {ceremony.uniformAndRegalia}</span>
                    </div>
                    <div className="flex items-start gap-2 pt-1 border-t border-stone-800/60">
                      <Eye className="w-3.5 h-3.5 text-[#C5A059] shrink-0 mt-0.5" />
                      <span><strong>Viewing Advice:</strong> {ceremony.publicViewingTip}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-3 border-t border-stone-800 flex items-center justify-between text-xs">
                  <span className="text-stone-400 font-serif">Status: <strong className="text-white">{ceremony.nextScheduledDate}</strong></span>
                  <span className="font-semibold text-[#F3E5AB]">Public Access Guide ›</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
