'use client';

import React from 'react';
import Image from 'next/image';
import { CrownIcon } from './RoyalCrest';
import { ArrowRight, Compass, Shield, Landmark, Sparkles } from 'lucide-react';

interface RoyalHeroProps {
  onOpenVisitPlanner: () => void;
  onExploreTimeline: () => void;
  onNavigateSection: (sectionId: string) => void;
}

export function RoyalHero({
  onOpenVisitPlanner,
  onExploreTimeline,
  onNavigateSection,
}: RoyalHeroProps) {
  return (
    <section className="relative w-full bg-[#FAF7F2] text-[#0D182E] pb-12">
      {/* Grand Hero Image Canvas */}
      <div className="relative w-full h-[520px] sm:h-[580px] lg:h-[640px] overflow-hidden">
        {/* Background Image: The uploaded Buckingham Palace photograph */}
        <Image
          src="/assets/aistudio/d9e205f7-45e1-4158-9342-f6abc9471fff_0b0d5420.png"
          alt="Buckingham Palace facade in London with the Royal Standard flying high"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center"
          referrerPolicy="no-referrer"
        />

        {/* Cinematic gradient scrim ensuring WCAG AA contrast for text on left side */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#070E1E]/95 via-[#0A1630]/75 to-transparent w-full md:w-[70%] lg:w-[55%]" />

        {/* Content Box Overlaid on Left */}
        <div className="relative z-10 max-w-7xl mx-auto h-full px-6 sm:px-8 lg:px-12 flex flex-col justify-center">
          <div className="max-w-xl text-left space-y-5">
            {/* Crown Motif with Gold Hairline Flourishes */}
            <div className="flex items-center gap-3">
              <span className="w-12 h-px bg-gradient-to-r from-transparent to-[#C5A059]" />
              <CrownIcon className="w-8 h-8 text-[#E5C378]" />
              <span className="w-12 h-px bg-gradient-to-l from-transparent to-[#C5A059]" />
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-normal text-white tracking-tight leading-[1.1] text-balance">
              Welcome to <br />
              <span className="font-royal font-semibold text-gold-gradient">
                Buckingham Palace
              </span>
            </h1>

            {/* Deck / Subtitle */}
            <p className="text-base sm:text-lg text-stone-200 leading-relaxed font-sans max-w-lg">
              The official residence of His Majesty The King and a working royal palace at the heart of the Nation.
            </p>

            {/* CTAs */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={onOpenVisitPlanner}
                className="px-6 py-3.5 bg-royal-gold text-slate-950 font-semibold text-sm rounded-md hover:brightness-110 transition-all shadow-lg flex items-center gap-2 group cursor-pointer whitespace-nowrap"
              >
                <span>Plan Your Visit</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                onClick={onExploreTimeline}
                className="px-6 py-3.5 bg-[#0C152B]/85 hover:bg-[#132244] border border-[#C5A059]/60 text-white font-medium text-sm rounded-md transition-all shadow-md flex items-center gap-2 group cursor-pointer whitespace-nowrap backdrop-blur-sm"
              >
                <span>Historical Timeline</span>
                <Compass className="w-4 h-4 text-[#C5A059] group-hover:rotate-45 transition-transform" />
              </button>
            </div>

            {/* Operational Ribbon */}
            <div className="pt-4 border-t border-[#C5A059]/30 text-xs text-stone-300 flex items-center gap-2 flex-wrap">
              <span className="text-[#C5A059] font-semibold">State Rooms Summer Opening:</span>
              <span>Daily 09:30–19:30</span>
              <span aria-hidden="true" className="text-stone-500">·</span>
              <span>Guard Change: Mon, Wed, Fri & Sun 11:00</span>
            </div>
          </div>
        </div>
      </div>

      {/* 4 Featured Pillar Cards (Directly matching the 4 cards at the bottom of the uploaded image) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10 sm:-mt-14 relative z-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {/* Card 1: The Royal Family */}
          <button
            onClick={() => onNavigateSection('royal-family')}
            className="group text-left bg-[#FAF7F2] rounded-xl overflow-hidden border border-stone-200/80 shadow-lg hover:shadow-2xl hover:border-[#C5A059] transition-all transform hover:-translate-y-1"
          >
            <div className="relative h-44 w-full overflow-hidden bg-stone-900">
              <Image
                src="/assets/aistudio/d9e205f7-45e1-4158-9342-f6abc9471fff_0b0d5420.png"
                alt="The King's Guard in bearskin hats at Buckingham Palace"
                fill
                sizes="(max-width: 768px) 100vw, 25vw"
                className="object-cover object-bottom group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            </div>
            <div className="p-4 bg-[#F5F0E6] flex items-center justify-between border-t border-stone-200">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#9E7D3B]" />
                <span className="font-royal text-sm font-bold text-[#0D182E] group-hover:text-[#9E7D3B] transition-colors">
                  The Royal Family
                </span>
              </div>
              <ArrowRight className="w-4 h-4 text-[#9E7D3B] group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          {/* Card 2: Visit the Palace */}
          <button
            onClick={onOpenVisitPlanner}
            className="group text-left bg-[#FAF7F2] rounded-xl overflow-hidden border border-stone-200/80 shadow-lg hover:shadow-2xl hover:border-[#C5A059] transition-all transform hover:-translate-y-1"
          >
            <div className="relative h-44 w-full overflow-hidden bg-stone-900">
              <Image
                src="/assets/aistudio/d9e205f7-45e1-4158-9342-f6abc9471fff_0b0d5420.png"
                alt="Buckingham Palace Grand Ballroom with golden chandeliers"
                fill
                sizes="(max-width: 768px) 100vw, 25vw"
                className="object-cover object-center group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            </div>
            <div className="p-4 bg-[#F5F0E6] flex items-center justify-between border-t border-stone-200">
              <div className="flex items-center gap-2">
                <Landmark className="w-4 h-4 text-[#9E7D3B]" />
                <span className="font-royal text-sm font-bold text-[#0D182E] group-hover:text-[#9E7D3B] transition-colors">
                  Visit the Palace
                </span>
              </div>
              <ArrowRight className="w-4 h-4 text-[#9E7D3B] group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          {/* Card 3: The Royal Collection */}
          <button
            onClick={() => onNavigateSection('crown-jewels')}
            className="group text-left bg-[#FAF7F2] rounded-xl overflow-hidden border border-stone-200/80 shadow-lg hover:shadow-2xl hover:border-[#C5A059] transition-all transform hover:-translate-y-1"
          >
            <div className="relative h-44 w-full overflow-hidden bg-stone-900">
              <Image
                src="/assets/aistudio/d9e205f7-45e1-4158-9342-f6abc9471fff_0b0d5420.png"
                alt="The Royal Collection art treasures in ornate gilded frame"
                fill
                sizes="(max-width: 768px) 100vw, 25vw"
                className="object-cover object-right group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            </div>
            <div className="p-4 bg-[#F5F0E6] flex items-center justify-between border-t border-stone-200">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#9E7D3B]" />
                <span className="font-royal text-sm font-bold text-[#0D182E] group-hover:text-[#9E7D3B] transition-colors">
                  The Royal Collection
                </span>
              </div>
              <ArrowRight className="w-4 h-4 text-[#9E7D3B] group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          {/* Card 4: News & Events */}
          <button
            onClick={() => onNavigateSection('pageantry')}
            className="group text-left bg-[#FAF7F2] rounded-xl overflow-hidden border border-stone-200/80 shadow-lg hover:shadow-2xl hover:border-[#C5A059] transition-all transform hover:-translate-y-1"
          >
            <div className="relative h-44 w-full overflow-hidden bg-stone-900">
              <Image
                src="/assets/aistudio/d9e205f7-45e1-4158-9342-f6abc9471fff_0b0d5420.png"
                alt="Victoria Memorial procession with Union Jacks and Royal Pageantry"
                fill
                sizes="(max-width: 768px) 100vw, 25vw"
                className="object-cover object-top group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            </div>
            <div className="p-4 bg-[#F5F0E6] flex items-center justify-between border-t border-stone-200">
              <div className="flex items-center gap-2">
                <Compass className="w-4 h-4 text-[#9E7D3B]" />
                <span className="font-royal text-sm font-bold text-[#0D182E] group-hover:text-[#9E7D3B] transition-colors">
                  Ceremonies & Events
                </span>
              </div>
              <ArrowRight className="w-4 h-4 text-[#9E7D3B] group-hover:translate-x-1 transition-transform" />
            </div>
          </button>
        </div>
      </div>
    </section>
  );
}
