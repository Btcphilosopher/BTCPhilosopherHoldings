'use client';

import React from 'react';
import { X, Check, Eye, Volume2, Type } from 'lucide-react';

interface AccessibilityModalProps {
  isOpen: boolean;
  onClose: () => void;
  highContrast: boolean;
  setHighContrast: (val: boolean) => void;
  largeText: boolean;
  setLargeText: (val: boolean) => void;
  reduceMotion: boolean;
  setReduceMotion: (val: boolean) => void;
}

export function AccessibilityModal({
  isOpen,
  onClose,
  highContrast,
  setHighContrast,
  largeText,
  setLargeText,
  reduceMotion,
  setReduceMotion,
}: AccessibilityModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-lg bg-[#0E1A33] border border-[#C5A059]/40 rounded-xl shadow-2xl p-6 text-stone-100 relative"
        role="dialog"
        aria-labelledby="accessibility-title"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-4 border-b border-[#C5A059]/20">
          <div>
            <span className="text-xs font-serif tracking-widest uppercase text-[#C5A059]">Royal Household Services</span>
            <h2 id="accessibility-title" className="text-xl font-royal tracking-wide text-white mt-1">
              Accessibility & Inclusion
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800/60 transition-colors"
            aria-label="Close accessibility options"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-stone-300 mt-3 leading-relaxed">
          The Royal Household is dedicated to ensuring Buckingham Palace, Windsor Castle, and our digital records are fully accessible to all visitors.
        </p>

        <div className="mt-5 space-y-3">
          {/* High Contrast */}
          <button
            onClick={() => setHighContrast(!highContrast)}
            className="w-full flex items-center justify-between p-3.5 rounded-lg bg-[#142344] hover:bg-[#1B2F5C] border border-[#C5A059]/30 transition-colors text-left"
          >
            <div className="flex items-center gap-3">
              <Eye className="w-5 h-5 text-[#C5A059] shrink-0" />
              <div>
                <p className="text-sm font-medium text-white">Enhanced Contrast Mode</p>
                <p className="text-xs text-stone-300">Boosts border definitions and text clarity for maximum readability.</p>
              </div>
            </div>
            <div
              className={`w-6 h-6 rounded flex items-center justify-center border transition-colors ${
                highContrast ? 'bg-[#C5A059] border-[#C5A059] text-black' : 'border-stone-500'
              }`}
            >
              {highContrast && <Check className="w-4 h-4 stroke-[3]" />}
            </div>
          </button>

          {/* Larger Typography */}
          <button
            onClick={() => setLargeText(!largeText)}
            className="w-full flex items-center justify-between p-3.5 rounded-lg bg-[#142344] hover:bg-[#1B2F5C] border border-[#C5A059]/30 transition-colors text-left"
          >
            <div className="flex items-center gap-3">
              <Type className="w-5 h-5 text-[#C5A059] shrink-0" />
              <div>
                <p className="text-sm font-medium text-white">Larger Reading Typography</p>
                <p className="text-xs text-stone-300">Expands baseline prose sizes across historical timeline and catalog records.</p>
              </div>
            </div>
            <div
              className={`w-6 h-6 rounded flex items-center justify-center border transition-colors ${
                largeText ? 'bg-[#C5A059] border-[#C5A059] text-black' : 'border-stone-500'
              }`}
            >
              {largeText && <Check className="w-4 h-4 stroke-[3]" />}
            </div>
          </button>

          {/* Reduced Motion */}
          <button
            onClick={() => setReduceMotion(!reduceMotion)}
            className="w-full flex items-center justify-between p-3.5 rounded-lg bg-[#142344] hover:bg-[#1B2F5C] border border-[#C5A059]/30 transition-colors text-left"
          >
            <div className="flex items-center gap-3">
              <Volume2 className="w-5 h-5 text-[#C5A059] shrink-0" />
              <div>
                <p className="text-sm font-medium text-white">Reduced Motion Mode</p>
                <p className="text-xs text-stone-300">Smooths transitions and suppresses continuous animations.</p>
              </div>
            </div>
            <div
              className={`w-6 h-6 rounded flex items-center justify-center border transition-colors ${
                reduceMotion ? 'bg-[#C5A059] border-[#C5A059] text-black' : 'border-stone-500'
              }`}
            >
              {reduceMotion && <Check className="w-4 h-4 stroke-[3]" />}
            </div>
          </button>
        </div>

        <div className="mt-6 pt-4 border-t border-[#C5A059]/20 flex items-center justify-between">
          <span className="text-xs text-stone-300">BSL & Audio Described palace tours available daily.</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-royal-gold text-slate-950 font-semibold text-xs rounded-lg hover:brightness-110 transition-all shadow-md"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
