'use client';

import React, { useState } from 'react';
import { WORKING_ROYALS, WorkingRoyal } from '@/data/workingRoyalsData';
import { CrownIcon } from './RoyalCrest';
import { Shield, Heart, Award, ArrowRight, UserCheck } from 'lucide-react';

export function WorkingMonarchySection() {
  const [selectedRoyalId, setSelectedRoyalId] = useState(WORKING_ROYALS[0].id);

  const activeRoyal = WORKING_ROYALS.find((r) => r.id === selectedRoyalId) || WORKING_ROYALS[0];

  return (
    <section id="royal-family" className="py-20 bg-[#0E182F] text-stone-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-3">
            <span className="w-8 h-px bg-[#C5A059]" />
            <CrownIcon className="w-6 h-6 text-[#E5C378]" />
            <span className="w-8 h-px bg-[#C5A059]" />
          </div>
          <p className="text-xs font-serif uppercase tracking-[0.25em] text-[#C5A059]">
            Constitutional Duty & Public Service
          </p>
          <h2 className="text-3xl sm:text-4xl font-royal text-white">
            The Working Monarchy
          </h2>
          <p className="text-stone-300 font-serif text-sm sm:text-base italic max-w-2xl mx-auto">
            Supporting the Sovereign in official duties, national ceremonies, and championing charitable causes across the United Kingdom and the Commonwealth.
          </p>
        </div>

        {/* Royal Member Selector Grid */}
        <div className="mt-12 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {WORKING_ROYALS.map((royal) => {
            const isSelected = royal.id === activeRoyal.id;
            return (
              <button
                key={royal.id}
                onClick={() => setSelectedRoyalId(royal.id)}
                className={`p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#182C55] border-[#C5A059] shadow-[0_0_20px_rgba(197,160,89,0.25)] ring-1 ring-[#C5A059]'
                    : 'bg-[#111F3C] border-stone-800 hover:border-stone-600 hover:bg-[#15274C]'
                }`}
              >
                <div>
                  <span className="text-[10px] font-royal text-[#C5A059] font-bold block">
                    {royal.monogram}
                  </span>
                  <h3 className="font-royal text-xs font-bold text-white mt-1 line-clamp-2">
                    {royal.name}
                  </h3>
                </div>
                <span className="text-[11px] text-stone-400 mt-2 block line-clamp-1 font-serif">
                  {royal.royalStyle}
                </span>
              </button>
            );
          })}
        </div>

        {/* Selected Royal Feature Card */}
        <div className="mt-8 p-6 sm:p-8 rounded-2xl bg-[#111F3C] border border-[#C5A059]/40 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column: Title & Bio */}
            <div className="lg:col-span-2 space-y-5">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-[#182C55] border border-[#C5A059]/60 flex items-center justify-center text-[#E5C378] font-royal font-bold text-sm">
                  {activeRoyal.monogram}
                </div>
                <div>
                  <span className="text-xs font-serif uppercase tracking-widest text-[#C5A059]">
                    {activeRoyal.royalStyle}
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-royal text-white">
                    {activeRoyal.name}
                  </h3>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#16274D] border border-stone-700/60 text-xs text-stone-200">
                <span className="text-[#C5A059] font-semibold">Official Role: </span>
                {activeRoyal.role}
              </div>

              <p className="text-sm text-stone-300 leading-relaxed font-sans">
                {activeRoyal.bio}
              </p>

              <div>
                <h4 className="text-xs font-serif tracking-widest uppercase text-[#C5A059] mb-3 flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5" /> Core Areas of Royal Advocacy
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {activeRoyal.focusAreas.map((area, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-[#142345] border border-stone-800 text-xs text-stone-200 flex items-start gap-2">
                      <span className="text-[#C5A059] mt-0.5">✦</span>
                      <span>{area}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column: Initiatives & Patronages */}
            <div className="p-5 rounded-xl bg-[#0C152B] border border-[#C5A059]/30 flex flex-col justify-between space-y-6">
              <div>
                <span className="text-xs font-serif uppercase tracking-widest text-[#C5A059] block">
                  Public Sector Service
                </span>
                <p className="text-xl font-royal text-white mt-1 font-bold">
                  {activeRoyal.patronagesCount}
                </p>
                <p className="text-xs text-stone-400 mt-1">
                  Active presidencies across military regiments, charities, and Commonwealth programs.
                </p>

                <div className="mt-5 space-y-3">
                  <span className="text-xs font-serif uppercase tracking-wider text-[#C5A059] block">
                    Flagship Initiatives
                  </span>
                  {activeRoyal.initiatives.map((init, iIdx) => (
                    <div key={iIdx} className="flex items-center gap-2 text-xs text-stone-200">
                      <Award className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                      <span>{init}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-stone-800 text-xs text-stone-400">
                <span>Born {activeRoyal.born} · Official Court Circular Engagements Recorded Annually</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
