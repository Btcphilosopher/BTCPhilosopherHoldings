'use client';

import React, { useState } from 'react';
import { X, Calendar, Users, MapPin, CheckCircle, Info, Sparkles } from 'lucide-react';
import { ROYAL_RESIDENCES } from '@/data/residencesData';

interface VisitPlannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialResidenceId?: string;
}

export function VisitPlannerModal({ isOpen, onClose, initialResidenceId = 'buckingham-palace' }: VisitPlannerModalProps) {
  const [selectedResidence, setSelectedResidence] = useState(initialResidenceId);
  const [visitDate, setVisitDate] = useState('2026-07-25');
  const [adultTickets, setAdultTickets] = useState(2);
  const [childTickets, setChildTickets] = useState(0);
  const [concessionTickets, setConcessionTickets] = useState(0);
  const [includeMultimediaGuide, setIncludeMultimediaGuide] = useState(true);
  const [isBooked, setIsBooked] = useState(false);

  if (!isOpen) return null;

  const currentResidence = ROYAL_RESIDENCES.find(r => r.id === selectedResidence) || ROYAL_RESIDENCES[0];

  // Base pricing
  const baseAdultPrice = selectedResidence === 'buckingham-palace' ? 32 : selectedResidence === 'windsor-castle' ? 30 : 22;
  const childPrice = 16;
  const concessionPrice = 28;
  const guideFee = includeMultimediaGuide ? 0 : 0; // included with state tickets

  const totalCost = (adultTickets * baseAdultPrice) + (childTickets * childPrice) + (concessionTickets * concessionPrice) + guideFee;

  const handleConfirmReservation = (e: React.FormEvent) => {
    e.preventDefault();
    setIsBooked(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-xl max-h-[90vh] overflow-y-auto bg-[#0C1529] border border-[#C5A059]/50 rounded-2xl shadow-2xl text-stone-100 p-6 relative"
        role="dialog"
        aria-labelledby="visit-planner-title"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-4 border-b border-[#C5A059]/20">
          <div>
            <span className="text-xs font-serif tracking-widest uppercase text-[#C5A059]">Royal Collection Trust Visitor Services</span>
            <h2 id="visit-planner-title" className="text-2xl font-royal tracking-wide text-white mt-1">
              Plan Your Royal Visit
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800/60 transition-colors"
            aria-label="Close visit planner"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isBooked ? (
          <div className="py-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#182C55] border-2 border-[#C5A059] flex items-center justify-center text-[#C5A059] mx-auto animate-in zoom-in-75">
              <CheckCircle className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-royal text-white">Royal Visit Reserved</h3>
            <p className="text-sm text-stone-300 max-w-md mx-auto leading-relaxed">
              Your provisional booking for <strong className="text-[#C5A059]">{currentResidence.name}</strong> on <strong className="text-white">{visitDate}</strong> has been confirmed. A formal Royal Collection voucher and QR pass have been prepared.
            </p>
            <div className="p-4 rounded-xl bg-[#142344] border border-[#C5A059]/30 text-left text-xs space-y-2 max-w-sm mx-auto">
              <div className="flex justify-between">
                <span className="text-stone-300">Party:</span>
                <span className="text-white font-medium">{adultTickets} Adults{childTickets > 0 ? `, ${childTickets} Children` : ''}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-300">Palace:</span>
                <span className="text-white font-medium">{currentResidence.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-300">Total Admission:</span>
                <span className="text-[#C5A059] font-bold">£{totalCost.toFixed(2)}</span>
              </div>
            </div>
            <div className="pt-4 flex justify-center gap-3">
              <button
                onClick={() => setIsBooked(false)}
                className="px-4 py-2 border border-[#C5A059]/40 text-xs text-stone-200 rounded-lg hover:bg-white/5 transition-colors"
              >
                Modify Reservation
              </button>
              <button
                onClick={onClose}
                className="px-5 py-2 bg-royal-gold text-slate-950 font-semibold text-xs rounded-lg hover:brightness-110 transition-all shadow-md"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleConfirmReservation} className="mt-5 space-y-5">
            {/* Palace Selection */}
            <div>
              <label htmlFor="residence-select" className="block text-xs font-serif tracking-wider uppercase text-[#C5A059] mb-1.5">
                Select Royal Residence
              </label>
              <select
                id="residence-select"
                value={selectedResidence}
                onChange={(e) => setSelectedResidence(e.target.value)}
                className="w-full bg-[#132242] border border-[#C5A059]/40 rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-[#C5A059]"
              >
                {ROYAL_RESIDENCES.map((res) => (
                  <option key={res.id} value={res.id} className="bg-[#0C1529]">
                    {res.name} — {res.location}
                  </option>
                ))}
              </select>
            </div>

            {/* Residence Info Snippet */}
            <div className="p-3.5 rounded-lg bg-[#142347] border border-[#C5A059]/20 flex items-start gap-3">
              <MapPin className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="text-white font-medium">{currentResidence.name}</p>
                <p className="text-stone-300 mt-0.5">{currentResidence.visitorStatus}</p>
                <p className="text-[#C5A059] mt-1 font-serif">Hours: {currentResidence.visitorOpenTimes}</p>
              </div>
            </div>

            {/* Date Selection */}
            <div>
              <label htmlFor="visit-date-input" className="block text-xs font-serif tracking-wider uppercase text-[#C5A059] mb-1.5">
                Date of Visit
              </label>
              <div className="relative">
                <input
                  id="visit-date-input"
                  type="date"
                  value={visitDate}
                  onChange={(e) => setVisitDate(e.target.value)}
                  min="2026-05-01"
                  max="2026-10-31"
                  className="w-full bg-[#132242] border border-[#C5A059]/40 rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-[#C5A059]"
                />
              </div>
            </div>

            {/* Ticket Quantities */}
            <div>
              <label className="block text-xs font-serif tracking-wider uppercase text-[#C5A059] mb-2">
                Ticket Quantities
              </label>
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 rounded-lg bg-[#111C36] border border-stone-800 text-center">
                  <span className="text-xs text-stone-300 block">Adults (£{baseAdultPrice})</span>
                  <div className="flex items-center justify-center gap-3 mt-2">
                    <button
                      type="button"
                      onClick={() => setAdultTickets(Math.max(1, adultTickets - 1))}
                      className="w-6 h-6 rounded bg-stone-800 text-white flex items-center justify-center text-sm font-bold hover:bg-stone-700"
                    >
                      -
                    </button>
                    <span className="font-bold text-white text-sm">{adultTickets}</span>
                    <button
                      type="button"
                      onClick={() => setAdultTickets(adultTickets + 1)}
                      className="w-6 h-6 rounded bg-stone-800 text-white flex items-center justify-center text-sm font-bold hover:bg-stone-700"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-[#111C36] border border-stone-800 text-center">
                  <span className="text-xs text-stone-300 block">Children 5-17 (£{childPrice})</span>
                  <div className="flex items-center justify-center gap-3 mt-2">
                    <button
                      type="button"
                      onClick={() => setChildTickets(Math.max(0, childTickets - 1))}
                      className="w-6 h-6 rounded bg-stone-800 text-white flex items-center justify-center text-sm font-bold hover:bg-stone-700"
                    >
                      -
                    </button>
                    <span className="font-bold text-white text-sm">{childTickets}</span>
                    <button
                      type="button"
                      onClick={() => setChildTickets(childTickets + 1)}
                      className="w-6 h-6 rounded bg-stone-800 text-white flex items-center justify-center text-sm font-bold hover:bg-stone-700"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-[#111C36] border border-stone-800 text-center">
                  <span className="text-xs text-stone-300 block">Seniors 65+ (£{concessionPrice})</span>
                  <div className="flex items-center justify-center gap-3 mt-2">
                    <button
                      type="button"
                      onClick={() => setConcessionTickets(Math.max(0, concessionTickets - 1))}
                      className="w-6 h-6 rounded bg-stone-800 text-white flex items-center justify-center text-sm font-bold hover:bg-stone-700"
                    >
                      -
                    </button>
                    <span className="font-bold text-white text-sm">{concessionTickets}</span>
                    <button
                      type="button"
                      onClick={() => setConcessionTickets(concessionTickets + 1)}
                      className="w-6 h-6 rounded bg-stone-800 text-white flex items-center justify-center text-sm font-bold hover:bg-stone-700"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Multimedia Guide Option */}
            <div className="flex items-center justify-between p-3.5 rounded-lg bg-[#132242] border border-[#C5A059]/20">
              <div className="flex items-center gap-2.5">
                <Sparkles className="w-4 h-4 text-[#C5A059]" />
                <div>
                  <p className="text-xs font-medium text-white">Complimentary Multimedia Handset</p>
                  <p className="text-[11px] text-stone-300">Narrated audio tour featuring commentary by royal curatorial staff (included).</p>
                </div>
              </div>
              <span className="text-xs text-[#C5A059] font-serif font-bold">Included</span>
            </div>

            {/* Summary & Submit */}
            <div className="pt-3 border-t border-[#C5A059]/20 flex items-center justify-between">
              <div>
                <span className="text-xs text-stone-300 block">Total Est. Price</span>
                <span className="text-xl font-royal text-[#C5A059] font-bold">£{totalCost.toFixed(2)}</span>
              </div>
              <button
                type="submit"
                className="px-6 py-2.5 bg-royal-gold text-slate-950 font-semibold text-xs rounded-lg hover:brightness-110 transition-all shadow-lg flex items-center gap-2"
              >
                <span>Reserve Tickets</span>
                <span>›</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
