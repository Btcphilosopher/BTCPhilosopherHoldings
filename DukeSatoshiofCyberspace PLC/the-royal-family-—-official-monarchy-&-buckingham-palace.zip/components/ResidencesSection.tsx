'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { ROYAL_RESIDENCES, RoyalResidence } from '@/data/residencesData';
import { CrownIcon } from './RoyalCrest';
import { MapPin, Clock, Flag, Ticket, Check, ChevronRight } from 'lucide-react';

interface ResidencesSectionProps {
  onOpenVisitPlannerFor: (residenceId: string) => void;
}

export function ResidencesSection({ onOpenVisitPlannerFor }: ResidencesSectionProps) {
  const [selectedResidence, setSelectedResidence] = useState<RoyalResidence>(ROYAL_RESIDENCES[0]);

  return (
    <section id="residences" className="py-20 bg-[#091124] text-stone-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-3">
            <span className="w-8 h-px bg-[#C5A059]" />
            <CrownIcon className="w-6 h-6 text-[#E5C378]" />
            <span className="w-8 h-px bg-[#C5A059]" />
          </div>
          <p className="text-xs font-serif uppercase tracking-[0.25em] text-[#C5A059]">
            Castles, Palaces & Sovereign Sanctuaries
          </p>
          <h2 className="text-3xl sm:text-4xl font-royal text-white">
            The Royal Residences
          </h2>
          <p className="text-stone-300 font-serif text-sm sm:text-base italic max-w-2xl mx-auto">
            From the neoclassical halls of Buckingham Palace to ancient medieval stone at Windsor Castle and the tranquil heather of Royal Deeside.
          </p>
        </div>

        {/* Palace Nav Tabs */}
        <div className="mt-10 flex items-center justify-start lg:justify-center gap-2 overflow-x-auto pb-2 custom-scrollbar">
          {ROYAL_RESIDENCES.map((res) => {
            const isSelected = res.id === selectedResidence.id;
            return (
              <button
                key={res.id}
                onClick={() => setSelectedResidence(res)}
                className={`px-4 py-2 rounded-xl text-xs font-medium transition-all whitespace-nowrap flex items-center gap-2 ${
                  isSelected
                    ? 'bg-royal-gold text-slate-950 font-semibold shadow-lg'
                    : 'bg-[#122040] text-stone-300 hover:text-white hover:bg-[#182C55]'
                }`}
              >
                <span>{res.name}</span>
                {res.flagStatus === 'Royal Standard' && (
                  <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse" title="Royal Standard Flying" />
                )}
              </button>
            );
          })}
        </div>

        {/* Detailed Palace Showcase */}
        <div className="mt-8 rounded-2xl bg-[#0E1A36] border border-[#C5A059]/40 overflow-hidden shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Visual Canvas (Left Column) */}
            <div className="lg:col-span-5 relative h-72 sm:h-96 lg:h-auto min-h-[340px] bg-stone-900">
              <Image
                src={selectedResidence.imagePath}
                alt={selectedResidence.name}
                fill
                sizes="(max-width: 1024px) 100vw, 45vw"
                className="object-cover object-center"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

              {/* Status Flag Badge Floating in Image */}
              <div className="absolute top-4 left-4 p-2.5 rounded-lg bg-black/70 backdrop-blur-md border border-[#C5A059]/40 text-xs">
                <div className="flex items-center gap-2">
                  <Flag className="w-3.5 h-3.5 text-[#E5C378]" />
                  <span className="font-royal text-white font-semibold">
                    {selectedResidence.flagStatus} Flying
                  </span>
                </div>
                <p className="text-[11px] text-stone-300 mt-0.5">{selectedResidence.flagMeaning}</p>
              </div>

              {/* Admission Ribbon in Image */}
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-white">
                <span className="font-serif italic text-stone-300">Built {selectedResidence.builtYear}</span>
                <span className="font-bold text-[#E5C378]">{selectedResidence.ticketPrice}</span>
              </div>
            </div>

            {/* Information Body (Right Column) */}
            <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between space-y-6">
              <div>
                <div className="flex items-center gap-2 text-xs font-serif uppercase tracking-widest text-[#C5A059]">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{selectedResidence.location}</span>
                </div>

                <h3 className="text-2xl sm:text-3xl font-royal text-white mt-1">
                  {selectedResidence.name}
                </h3>
                <p className="text-xs font-serif italic text-stone-300 mt-1">
                  {selectedResidence.role}
                </p>

                <p className="mt-4 text-sm text-stone-300 leading-relaxed font-sans">
                  {selectedResidence.summary}
                </p>

                {/* Opening Hours & Summer Opening Info */}
                <div className="mt-5 p-3.5 rounded-xl bg-[#14244A] border border-[#C5A059]/20 flex items-start gap-3">
                  <Clock className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                  <div className="text-xs space-y-1">
                    <p className="text-white font-medium">{selectedResidence.visitorStatus}</p>
                    <p className="text-stone-300">Open Hours: {selectedResidence.visitorOpenTimes}</p>
                  </div>
                </div>

                {/* Highlights List */}
                <div className="mt-5">
                  <h4 className="text-xs font-serif uppercase tracking-widest text-[#C5A059] mb-2.5">
                    Architectural & Collection Highlights
                  </h4>
                  <ul className="space-y-2">
                    {selectedResidence.highlights.map((h, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-stone-200">
                        <Check className="w-3.5 h-3.5 text-[#C5A059] shrink-0 mt-0.5" />
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Bottom Action Strip */}
              <div className="pt-4 border-t border-stone-800 flex items-center justify-between flex-wrap gap-4">
                <div className="text-xs text-stone-400">
                  <span>Architecture: <strong>{selectedResidence.architecturalStyle}</strong></span>
                </div>
                <button
                  onClick={() => onOpenVisitPlannerFor(selectedResidence.id)}
                  className="px-5 py-2.5 bg-royal-gold text-slate-950 font-semibold text-xs rounded-lg hover:brightness-110 transition-all shadow-md flex items-center gap-2"
                >
                  <Ticket className="w-4 h-4" />
                  <span>Reserve Visitor Tickets</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
