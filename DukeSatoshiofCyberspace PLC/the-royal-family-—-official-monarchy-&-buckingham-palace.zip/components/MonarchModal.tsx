'use client';

import React from 'react';
import { X, Crown, Calendar, Landmark, BookOpen, Quote, ShieldCheck } from 'lucide-react';
import { Monarch } from '@/data/timelineData';

interface MonarchModalProps {
  monarch: Monarch | null;
  onClose: () => void;
}

export function MonarchModal({ monarch, onClose }: MonarchModalProps) {
  if (!monarch) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-[#0C152A] border border-[#C5A059]/50 rounded-2xl shadow-2xl text-stone-100 relative custom-scrollbar"
        role="dialog"
        aria-labelledby="monarch-title"
        aria-modal="true"
      >
        {/* Modal Header with Gold Accents */}
        <div className="sticky top-0 z-10 bg-[#0C152A]/95 backdrop-blur-sm border-b border-[#C5A059]/30 px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#18284C] border border-[#C5A059]/50 flex items-center justify-center text-[#C5A059]">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs font-serif tracking-widest text-[#C5A059] uppercase">
                <span>House of {monarch.house}</span>
                <span aria-hidden="true">·</span>
                <span className="tabular-nums">{monarch.reign}</span>
              </div>
              <h2 id="monarch-title" className="text-2xl font-royal tracking-wide text-white">
                {monarch.name}
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800/60 transition-colors"
            aria-label="Close details"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Royal Style & Proclamation */}
          <div className="p-4 rounded-xl bg-[#142347] border border-[#C5A059]/30">
            <p className="text-xs font-serif tracking-widest uppercase text-[#C5A059] mb-1">
              Official Sovereign Title
            </p>
            <p className="text-sm font-medium text-stone-200 leading-relaxed italic">
              &ldquo;{monarch.title}&rdquo;
            </p>
          </div>

          {/* Quick Historical Attributes Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="p-3 rounded-lg bg-[#111C36] border border-stone-800">
              <span className="flex items-center gap-1.5 text-xs text-[#C5A059]">
                <Calendar className="w-3.5 h-3.5" /> Reign
              </span>
              <p className="text-sm font-medium text-white mt-1 tabular-nums">{monarch.reign}</p>
            </div>
            <div className="p-3 rounded-lg bg-[#111C36] border border-stone-800">
              <span className="flex items-center gap-1.5 text-xs text-[#C5A059]">
                <ShieldCheck className="w-3.5 h-3.5" /> Coronation
              </span>
              <p className="text-sm font-medium text-white mt-1 tabular-nums">{monarch.coronationYear} AD</p>
            </div>
            <div className="p-3 rounded-lg bg-[#111C36] border border-stone-800 col-span-2 sm:col-span-1">
              <span className="flex items-center gap-1.5 text-xs text-[#C5A059]">
                <Landmark className="w-3.5 h-3.5" /> Primary Palace
              </span>
              <p className="text-sm font-medium text-white mt-1 truncate">{monarch.residenceOrPalace}</p>
            </div>
          </div>

          {/* Sovereign Motto */}
          {monarch.motto && (
            <div className="flex items-center gap-3 p-3.5 rounded-lg bg-[#142347]/60 border-l-2 border-[#C5A059]">
              <span className="text-xs uppercase tracking-wider text-[#C5A059] font-serif">Royal Motto:</span>
              <span className="text-sm font-serif italic text-white">{monarch.motto}</span>
            </div>
          )}

          {/* Historical Overview */}
          <div>
            <h3 className="text-xs font-serif tracking-widest uppercase text-[#C5A059] mb-2 flex items-center gap-2">
              <BookOpen className="w-4 h-4" /> Historical Epoch & Legacy
            </h3>
            <p className="text-stone-300 text-sm leading-relaxed font-sans">
              {monarch.summary}
            </p>
            <p className="text-stone-300 text-sm leading-relaxed font-sans mt-3">
              {monarch.historicalContext}
            </p>
          </div>

          {/* Key Constitutional & Cultural Milestones */}
          <div>
            <h3 className="text-xs font-serif tracking-widest uppercase text-[#C5A059] mb-3">
              Key Achievements & Constitutional Landmark Actions
            </h3>
            <ul className="space-y-2.5">
              {monarch.keyAchievements.map((achievement, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-sm text-stone-200">
                  <span className="text-[#C5A059] mt-0.5 font-bold">✦</span>
                  <span className="leading-snug">{achievement}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Famous Quote */}
          {monarch.quote && (
            <div className="p-4 rounded-xl bg-gradient-to-r from-[#17274D] to-[#121E3B] border border-[#C5A059]/30 relative overflow-hidden">
              <Quote className="absolute right-3 bottom-2 w-12 h-12 text-[#C5A059]/10 pointer-events-none" />
              <p className="text-xs uppercase tracking-widest text-[#C5A059] font-serif mb-1">
                Historic Royal Address
              </p>
              <blockquote className="font-serif italic text-stone-100 text-base leading-relaxed">
                &ldquo;{monarch.quote}&rdquo;
              </blockquote>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-[#0A1122] border-t border-[#C5A059]/20 flex items-center justify-between">
          <span className="text-xs text-stone-300">
            Source: Royal Archives & Sovereign Gazetteers
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-royal-gold text-slate-950 font-semibold text-xs rounded-lg hover:brightness-110 transition-all shadow-md"
          >
            Close Record
          </button>
        </div>
      </div>
    </div>
  );
}
