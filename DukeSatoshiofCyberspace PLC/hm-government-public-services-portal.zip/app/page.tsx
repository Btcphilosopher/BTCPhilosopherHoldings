'use client';

import React, { useState, useEffect, useMemo } from 'react';
import Image from 'next/image';
import {
  Search,
  ArrowRight,
  Globe,
  Coins,
  Users,
  Briefcase,
  Car,
  GraduationCap,
  MapPin,
  Eye,
  SlidersHorizontal,
  X,
  Volume2,
  VolumeX,
  Sparkles,
  ChevronRight,
  Info,
  Check,
} from 'lucide-react';
import { RoyalCrest } from '@/components/RoyalCrest';
import { AccessibilityModal, type AccessibilitySettings } from '@/components/AccessibilityModal';
import { ServiceModal, type ServiceId } from '@/components/ServiceModal';
import { LocalServicesModal } from '@/components/LocalServicesModal';
import { DesignMockupModal } from '@/components/DesignMockupModal';
import { SignInModal } from '@/components/SignInModal';

// Search catalog database for instant auto-complete and search
interface SearchItem {
  id: string;
  title: string;
  titleCy: string;
  category: string;
  categoryCy: string;
  serviceId?: ServiceId;
  snippet: string;
}

const SEARCH_CATALOG: SearchItem[] = [
  {
    id: 'pass-renew',
    title: 'Renew or replace your adult passport online',
    titleCy: 'Adnewyddu neu ailosod eich pasbort oedolyn ar-lein',
    category: 'Passports & Travel',
    categoryCy: 'Pasbortau a Theithio',
    serviceId: 'passport',
    snippet: 'Cost is £88.50. You need a digital photo and your old passport.',
  },
  {
    id: 'pass-first',
    title: 'Apply for a first British passport',
    titleCy: 'Gwneud cais am basbort Prydeinig cyntaf',
    category: 'Passports & Travel',
    categoryCy: 'Pasbortau a Theithio',
    serviceId: 'passport',
    snippet: 'First-time adult applicants require identity confirmation and interview.',
  },
  {
    id: 'tax-sa',
    title: 'Self Assessment tax return deadline and online submission',
    titleCy: 'Dyddiad cau ffurflen dreth Hunanasesiad a chyflwyno ar-lein',
    category: 'Money & Tax',
    categoryCy: 'Arian a Threth',
    serviceId: 'tax',
    snippet: 'Submit your tax return and pay what you owe by 31 January.',
  },
  {
    id: 'tax-paye',
    title: 'Check your Income Tax estimate & PAYE tax code',
    titleCy: 'Gwiriwch eich amcangyfrif Treth Incwm a chod treth TWE',
    category: 'Money & Tax',
    categoryCy: 'Arian a Threth',
    serviceId: 'tax',
    snippet: 'View how much tax you paid and update employer benefits in your personal tax account.',
  },
  {
    id: 'ben-uc',
    title: 'Universal Credit claim and monthly payment tracker',
    titleCy: 'Hawliad Credyd Cynhwysol a thraciwr taliadau misol',
    category: 'Benefits & Support',
    categoryCy: 'Budd-daliadau a Chymorth',
    serviceId: 'benefits',
    snippet: 'Monthly payment for living and housing costs for those on low income or looking for work.',
  },
  {
    id: 'ben-child',
    title: 'Claim Child Benefit and High Income Child Benefit Charge',
    titleCy: 'Hawlio Budd-dal Plant a Thâl Budd-dal Plant Incwm Uchel',
    category: 'Benefits & Support',
    categoryCy: 'Budd-daliadau a Chymorth',
    serviceId: 'benefits',
    snippet: 'Allowance of £25.60 per week for first child, £16.95 for subsequent children.',
  },
  {
    id: 'drive-licence',
    title: 'Renew your 10-year photocard driving licence with DVLA',
    titleCy: 'Adnewyddu eich trwydded yrru cerdyn llun 10 mlynedd gyda DVLA',
    category: 'Driving & Transport',
    categoryCy: 'Gyrru a Thrafnidiaeth',
    serviceId: 'driving',
    snippet: 'Quick £14 fee. Use your UK passport photo and receive licence in 5 days.',
  },
  {
    id: 'drive-mot',
    title: 'Check vehicle MOT history and pay vehicle road tax',
    titleCy: 'Gwirio hanes MOT cerbyd a thalu treth ffordd cerbyd',
    category: 'Driving & Transport',
    categoryCy: 'Gyrru a Thrafnidiaeth',
    serviceId: 'driving',
    snippet: 'Instant vehicle lookup with mileage records, advisory items, and tax band.',
  },
  {
    id: 'work-find',
    title: 'Find a Job service - search national vacancies',
    titleCy: 'Gwasanaeth Dod o Hyd i Swydd - chwilio swyddi gwag cenedlaethol',
    category: 'Work & Employment',
    categoryCy: 'Gwaith a Chyflogaeth',
    serviceId: 'work-pensions',
    snippet: 'Search over 140,000 verified full-time, part-time and apprentice opportunities.',
  },
  {
    id: 'pension-state',
    title: 'Check your State Pension age and forecast',
    titleCy: 'Gwiriwch eich oedran Pensiwn y Wladwriaeth a rhagolwg',
    category: 'Pensions',
    categoryCy: 'Pensiynau',
    serviceId: 'work-pensions',
    snippet: 'See your forecast weekly pension based on National Insurance contribution years.',
  },
  {
    id: 'edu-childcare',
    title: 'Apply for 15 or 30 hours funded childcare for working parents',
    titleCy: 'Gwneud cais am 15 neu 30 awr o ofal plant a ariennir ar gyfer rhieni sy’n gweithio',
    category: 'Education & Childcare',
    categoryCy: 'Addysg a Gofal Plant',
    serviceId: 'education',
    snippet: 'Government-funded hours for children from 9 months up to 4 years old.',
  },
];

export default function Home() {
  const [lang, setLang] = useState<'en' | 'cy'>('en');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [postcode, setPostcode] = useState('');
  const [activeService, setActiveService] = useState<ServiceId | null>(null);
  const [isLocalModalOpen, setIsLocalModalOpen] = useState(false);
  const [isDesignModalOpen, setIsDesignModalOpen] = useState(false);
  const [isAccessibilityOpen, setIsAccessibilityOpen] = useState(false);
  const [isSignInOpen, setIsSignInOpen] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Accessibility state
  const [a11y, setA11y] = useState<AccessibilitySettings>({
    fontSize: 'standard',
    contrast: 'standard',
    dyslexicFont: false,
    underlineLinks: true,
    highFocus: true,
    motionReduced: false,
  });

  // Filtered search results
  const searchResults = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return [];
    return SEARCH_CATALOG.filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.titleCy.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.snippet.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  // Speech synthesis for accessibility
  const speakText = (text: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang === 'cy' ? 'cy-GB' : 'en-GB';
    utterance.rate = 0.95;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  const handleSpeakSummary = () => {
    const summary =
      lang === 'en'
        ? 'HM Government portal. Government services made clear. Find trusted information and get things done. Top services include Renew a passport, Manage your tax, Find benefits and support, Work and pensions, Driving and transport, and Education and childcare. You can search any service or enter your postcode for local council facilities.'
        : 'Porth Llywodraeth EM. Gwasanaethau’r llywodraeth wedi’u gwneud yn glir. Dod o hyd i wybodaeth ddibynadwy a chyflawni pethau. Prif wasanaethau: Adnewyddu pasbort, Rheoli eich treth, Canfod budd-daliadau a chymorth, Gwaith a phensiynau, Gyrru a thrafnidiaeth, Addysg a gofal plant.';
    speakText(summary);
  };

  const handlePostcodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (postcode.trim()) {
      setIsLocalModalOpen(true);
    }
  };

  // Quick search pill selection
  const handlePopularSearch = (term: string) => {
    setSearchQuery(term);
    setSearchOpen(true);
  };

  // Visual classes derived from accessibility preferences
  const fontSizeClass =
    a11y.fontSize === 'xlarge'
      ? 'text-lg'
      : a11y.fontSize === 'large'
      ? 'text-base'
      : 'text-sm';

  const contrastClasses =
    a11y.contrast === 'high-contrast-yellow'
      ? 'bg-black text-[#ffdd00] select-contrast-yellow'
      : a11y.contrast === 'dark-mode'
      ? 'bg-[#0f172a] text-[#f1f5f9]'
      : 'bg-white text-[#0b0c0c]';

  const linkUnderlineClass = a11y.underlineLinks ? 'underline underline-offset-3' : 'hover:underline';

  return (
    <div
      className={`min-h-screen flex flex-col font-sans transition-colors duration-200 ${contrastClasses} ${
        a11y.dyslexicFont ? 'tracking-wider font-mono' : ''
      }`}
    >
      {/* Top Banner Toolbar: View Generated Design & Accessibility status */}
      <aside
        aria-label="Government Design Showcase Controls"
        className="w-full bg-[#00172e] text-white py-1.5 px-4 text-xs border-b border-neutral-700 flex flex-wrap items-center justify-between gap-2"
      >
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="font-semibold text-neutral-200">
            {lang === 'en' ? 'Official Public Design Specimen' : 'Manyleb Dylunio Cyhoeddus Swyddogol'}
          </span>
          <span className="hidden sm:inline text-neutral-400">| WCAG 2.2 AAA Verified Layout</span>
        </div>

        <div className="flex items-center gap-3">
          {/* Button to view the generated UI image requested in prompt */}
          <button
            onClick={() => setIsDesignModalOpen(true)}
            className="px-2.5 py-1 bg-[#005a36] hover:bg-[#00703c] text-white font-bold text-xs flex items-center gap-1.5 border border-emerald-500 focus:outline-3 focus:outline-[#ffdd00]"
          >
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            <span>View Generated UI Image</span>
          </button>

          {/* Quick audio toggle */}
          <button
            onClick={isSpeaking ? stopSpeaking : handleSpeakSummary}
            className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs flex items-center gap-1 border border-neutral-600 focus:outline-3 focus:outline-[#ffdd00]"
            title="Read summary aloud"
          >
            {isSpeaking ? (
              <>
                <VolumeX className="w-3.5 h-3.5 text-red-400" />
                <span className="hidden md:inline">Stop Audio</span>
              </>
            ) : (
              <>
                <Volume2 className="w-3.5 h-3.5 text-sky-400" />
                <span className="hidden md:inline">Listen</span>
              </>
            )}
          </button>

          {/* Accessibility button */}
          <button
            onClick={() => setIsAccessibilityOpen(true)}
            className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs flex items-center gap-1 border border-neutral-600 focus:outline-3 focus:outline-[#ffdd00]"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Display Settings</span>
          </button>
        </div>
      </aside>

      {/* Main Header */}
      <header
        role="banner"
        className={`w-full border-b ${
          a11y.contrast === 'high-contrast-yellow' ? 'border-[#ffdd00]' : 'border-[#b1b4b6]'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            {/* Logo and HM Government Title */}
            <div className="flex items-center gap-3">
              <RoyalCrest
                size={42}
                className={a11y.contrast === 'high-contrast-yellow' ? 'text-[#ffdd00]' : 'text-[#0b0c0c]'}
              />
              <span
                className={`text-2xl sm:text-3xl font-extrabold tracking-tight ${
                  a11y.contrast === 'high-contrast-yellow' ? 'text-[#ffdd00]' : 'text-[#0b0c0c]'
                }`}
              >
                {lang === 'en' ? 'HM Government' : 'Llywodraeth EM'}
              </span>
            </div>

            {/* Navigation links & user controls */}
            <nav aria-label="Top level navigation" className="flex items-center gap-4 sm:gap-7">
              <button
                onClick={() => {
                  setSearchQuery('');
                  window.scrollTo({ top: 380, behavior: 'smooth' });
                }}
                className={`text-base font-bold hidden md:inline-block ${
                  a11y.contrast === 'high-contrast-yellow'
                    ? 'text-[#ffdd00]'
                    : 'text-[#0b0c0c] hover:text-[#002447]'
                } ${linkUnderlineClass}`}
              >
                {lang === 'en' ? 'Services' : 'Gwasanaethau'}
              </button>

              <button
                onClick={() => setActiveService('departments')}
                className={`text-base font-bold hidden md:inline-block ${
                  a11y.contrast === 'high-contrast-yellow'
                    ? 'text-[#ffdd00]'
                    : 'text-[#0b0c0c] hover:text-[#002447]'
                } ${linkUnderlineClass}`}
              >
                {lang === 'en' ? 'Departments' : 'Adrannau'}
              </button>

              <button
                onClick={() => setActiveService('policies')}
                className={`text-base font-bold hidden md:inline-block ${
                  a11y.contrast === 'high-contrast-yellow'
                    ? 'text-[#ffdd00]'
                    : 'text-[#0b0c0c] hover:text-[#002447]'
                } ${linkUnderlineClass}`}
              >
                {lang === 'en' ? 'News' : 'Newyddion'}
              </button>

              <div
                className={`hidden md:block h-6 w-px ${
                  a11y.contrast === 'high-contrast-yellow' ? 'bg-[#ffdd00]' : 'bg-[#b1b4b6]'
                }`}
              ></div>

              {/* Sign in button */}
              <button
                onClick={() => setIsSignInOpen(true)}
                className={`text-base font-bold ${
                  a11y.contrast === 'high-contrast-yellow'
                    ? 'text-[#ffdd00] underline'
                    : 'text-[#002447] hover:underline'
                } focus:outline-4 focus:outline-[#ffdd00]`}
              >
                {lang === 'en' ? 'Sign in' : 'Mewngofnodi'}
              </button>

              {/* Universal Accessibility Icon button */}
              <button
                onClick={() => setIsAccessibilityOpen(true)}
                className={`p-1.5 rounded-full border-2 ${
                  a11y.contrast === 'high-contrast-yellow'
                    ? 'border-[#ffdd00] text-[#ffdd00]'
                    : 'border-[#0b0c0c] text-[#0b0c0c] hover:bg-neutral-100'
                } focus:outline-4 focus:outline-[#ffdd00]`}
                aria-label="Open accessibility and text sizing preferences"
                title="Accessibility Preferences"
              >
                <div className="w-5 h-5 flex items-center justify-center font-serif text-sm font-bold">
                  ⓘ
                </div>
              </button>
            </nav>
          </div>

          {/* Subheader: Country & Language Switcher */}
          <div
            className={`mt-2 pt-2 border-t flex items-center justify-between text-xs sm:text-sm ${
              a11y.contrast === 'high-contrast-yellow' ? 'border-[#ffdd00]/40' : 'border-[#e0e0e0]'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="font-semibold text-[#505a5f]">
                {lang === 'en' ? 'United Kingdom' : 'Y Deyrnas Unedig'}
              </span>
              <span className="text-neutral-400">|</span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setLang('en')}
                  className={`font-semibold ${
                    lang === 'en'
                      ? a11y.contrast === 'high-contrast-yellow'
                        ? 'text-[#ffdd00] underline'
                        : 'text-[#002447] underline font-bold'
                      : 'text-[#505a5f] hover:underline'
                  }`}
                >
                  English
                </button>
                <span>/</span>
                <button
                  onClick={() => setLang('cy')}
                  className={`font-semibold ${
                    lang === 'cy'
                      ? a11y.contrast === 'high-contrast-yellow'
                        ? 'text-[#ffdd00] underline'
                        : 'text-[#002447] underline font-bold'
                      : 'text-[#505a5f] hover:underline'
                  }`}
                >
                  Cymraeg
                </button>
              </div>
            </div>

            <div className="hidden sm:flex items-center gap-2 text-xs text-[#505a5f]">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-600"></span>
              <span>All public systems operational</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main id="main-content" className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 sm:py-10">
        {/* HERO SECTION */}
        <section aria-labelledby="hero-heading" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-12">
          {/* Left Column: Heading, Subheading & Clear Search Bar */}
          <div className="lg:col-span-7 space-y-6">
            <h1
              id="hero-heading"
              className={`text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.08] ${
                a11y.contrast === 'high-contrast-yellow' ? 'text-[#ffdd00]' : 'text-[#0b0c0c]'
              }`}
            >
              {lang === 'en' ? (
                <>
                  Government services.
                  <br />
                  <span className="text-[#002447]">Made clear.</span>
                </>
              ) : (
                <>
                  Gwasanaethau’r llywodraeth.
                  <br />
                  <span className="text-[#002447]">Wedi’u gwneud yn glir.</span>
                </>
              )}
            </h1>

            <p
              className={`text-lg sm:text-xl font-normal leading-relaxed ${
                a11y.contrast === 'high-contrast-yellow' ? 'text-yellow-200' : 'text-[#333333]'
              }`}
            >
              {lang === 'en'
                ? 'Find trusted information and get things done.'
                : 'Dod o hyd i wybodaeth ddibynadwy a chyflawni pethau.'}
            </p>

            {/* Prominent Search Bar */}
            <div className="relative pt-2">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (searchQuery.trim()) setSearchOpen(true);
                }}
                role="search"
                className="flex flex-col sm:flex-row items-stretch gap-2"
              >
                <div
                  className={`relative flex-1 flex items-center border-2 ${
                    a11y.contrast === 'high-contrast-yellow'
                      ? 'border-[#ffdd00] bg-black'
                      : 'border-[#0b0c0c] bg-white'
                  } focus-within:ring-4 focus-within:ring-[#ffdd00]`}
                >
                  <label htmlFor="gov-search-input" className="sr-only">
                    {lang === 'en' ? 'Search services and information' : 'Chwilio gwasanaethau a gwybodaeth'}
                  </label>
                  <div className="pl-3.5 pr-1 text-[#505a5f]" aria-hidden="true">
                    <Search className="w-5 h-5" />
                  </div>
                  <input
                    id="gov-search-input"
                    type="text"
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      setSearchOpen(true);
                    }}
                    onFocus={() => setSearchOpen(true)}
                    placeholder={
                      lang === 'en' ? 'Search services and information' : 'Chwilio gwasanaethau a gwybodaeth'
                    }
                    className={`w-full py-3.5 px-2 text-base outline-none bg-transparent ${
                      a11y.contrast === 'high-contrast-yellow'
                        ? 'text-[#ffdd00] placeholder:text-yellow-500'
                        : 'text-[#0b0c0c] placeholder:text-[#505a5f]'
                    }`}
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => {
                        setSearchQuery('');
                        setSearchOpen(false);
                      }}
                      className="p-2 text-[#505a5f] hover:text-[#0b0c0c]"
                      aria-label="Clear search text"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Dark green Gov Search button */}
                <button
                  type="submit"
                  className="px-8 py-3.5 bg-[#005a36] hover:bg-[#00472b] text-white font-bold text-base transition-colors shrink-0 shadow-xs focus:outline-4 focus:outline-[#ffdd00]"
                >
                  {lang === 'en' ? 'Search' : 'Chwilio'}
                </button>
              </form>

              {/* Live search dropdown results */}
              {searchOpen && searchQuery.trim().length > 0 && (
                <div
                  className={`absolute top-full left-0 right-0 z-40 mt-1 border-2 shadow-2xl p-2 ${
                    a11y.contrast === 'high-contrast-yellow'
                      ? 'border-[#ffdd00] bg-black text-[#ffdd00]'
                      : 'border-[#0b0c0c] bg-white text-[#0b0c0c]'
                  } max-h-80 overflow-y-auto`}
                >
                  <div className="flex items-center justify-between px-3 py-1.5 border-b border-[#b1b4b6] text-xs font-bold text-[#505a5f]">
                    <span>
                      {searchResults.length}{' '}
                      {searchResults.length === 1 ? 'service match' : 'service matches'} for &ldquo;{searchQuery}&rdquo;
                    </span>
                    <button
                      onClick={() => setSearchOpen(false)}
                      className="text-[#002447] underline hover:text-black"
                    >
                      Close results
                    </button>
                  </div>

                  {searchResults.length === 0 ? (
                    <div className="p-4 text-sm text-[#505a5f]">
                      No direct public service found. Try broader keywords like &quot;passport&quot;, &quot;tax&quot;, &quot;driving&quot;, or &quot;benefits&quot;.
                    </div>
                  ) : (
                    <div className="divide-y divide-[#e5e5e5]">
                      {searchResults.map((item) => (
                        <button
                          key={item.id}
                          onClick={() => {
                            if (item.serviceId) setActiveService(item.serviceId);
                            setSearchOpen(false);
                          }}
                          className="w-full text-left p-3 hover:bg-[#f3f2f1] transition-colors focus:bg-[#ffdd00] focus:text-black group block"
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-xs uppercase font-bold text-[#005a36] tracking-wider">
                              {lang === 'cy' ? item.categoryCy : item.category}
                            </span>
                            <ChevronRight className="w-4 h-4 text-[#505a5f] group-hover:translate-x-1 transition-transform" />
                          </div>
                          <div className="font-bold text-sm sm:text-base text-[#1d70b8] group-hover:underline mt-0.5">
                            {lang === 'cy' ? item.titleCy : item.title}
                          </div>
                          <p className="text-xs text-[#505a5f] mt-1 line-clamp-1">{item.snippet}</p>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Popular quick-access search terms */}
              <div className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm">
                <span className="font-bold text-[#0b0c0c]">
                  {lang === 'en' ? 'Popular:' : 'Poblogaidd:'}
                </span>
                {[
                  { en: 'Passports', cy: 'Pasbortau', tag: 'passport' },
                  { en: 'Tax', cy: 'Treth', tag: 'tax' },
                  { en: 'Benefits', cy: 'Budd-daliadau', tag: 'benefits' },
                  { en: 'Driving', cy: 'Gyrru', tag: 'driving' },
                ].map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handlePopularSearch(item.tag)}
                    className={`font-bold text-[#1d70b8] hover:text-[#002447] ${linkUnderlineClass} focus:outline-2 focus:outline-[#ffdd00]`}
                  >
                    {lang === 'en' ? item.en : item.cy}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Civic street photography banner */}
          <div className="lg:col-span-5 relative">
            <div className="relative aspect-16/10 sm:aspect-16/9 lg:aspect-4/3 w-full overflow-hidden border-2 border-[#b1b4b6] shadow-sm bg-neutral-200">
              <Image
                src="/civic_walk_uk.jpg"
                alt="Citizens walking in Whitehall, London past historic HM Government neoclassical buildings"
                fill
                priority
                referrerPolicy="no-referrer"
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 45vw"
              />
              <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent p-3 text-white">
                <p className="text-xs font-semibold">
                  {lang === 'en'
                    ? 'Whitehall & HM Government administrative quarter, London'
                    : 'Whitehall a chwarter gweinyddol Llywodraeth EM, Llundain'}
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION: WHAT DO YOU NEED TO DO? (6 PUBLIC SERVICES GRID) */}
        <section aria-labelledby="services-grid-heading" className="pt-8 pb-12 border-t-2 border-[#0b0c0c]">
          <h2
            id="services-grid-heading"
            className={`text-2xl sm:text-3xl font-extrabold tracking-tight mb-6 ${
              a11y.contrast === 'high-contrast-yellow' ? 'text-[#ffdd00]' : 'text-[#0b0c0c]'
            }`}
          >
            {lang === 'en' ? 'What do you need to do?' : 'Beth sydd angen i chi ei wneud?'}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-0 border-t border-l border-[#d8d8d8]">
            {/* 1. Renew a passport */}
            <article
              onClick={() => setActiveService('passport')}
              className={`p-6 border-b border-r border-[#d8d8d8] flex flex-col justify-between hover:bg-[#f3f2f1] transition-colors cursor-pointer group focus-within:ring-4 focus-within:ring-[#ffdd00] ${
                a11y.contrast === 'high-contrast-yellow' ? 'hover:bg-neutral-900 border-[#ffdd00]/40' : 'bg-white'
              }`}
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="p-2.5 border-2 border-[#0b0c0c] bg-white text-[#0b0c0c] mb-4">
                    <Globe className="w-6 h-6 stroke-[1.8]" />
                  </div>
                  <ArrowRight className="w-5 h-5 text-[#002447] group-hover:translate-x-1.5 transition-transform" />
                </div>
                <h3
                  className={`text-lg sm:text-xl font-bold group-hover:underline ${
                    a11y.contrast === 'high-contrast-yellow' ? 'text-[#ffdd00]' : 'text-[#002447]'
                  }`}
                >
                  {lang === 'en' ? 'Renew a passport' : 'Adnewyddu pasbort'}
                </h3>
                <p className="text-sm text-[#505a5f] mt-1.5 leading-relaxed">
                  {lang === 'en'
                    ? 'Apply to renew, replace or get a first British passport.'
                    : 'Gwneud cais i adnewyddu, ailosod neu gael pasbort Prydeinig cyntaf.'}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center text-xs font-bold text-[#1d70b8]">
                <span>{lang === 'en' ? 'Start online application' : 'Dechrau ar-lein'}</span>
              </div>
            </article>

            {/* 2. Manage your tax */}
            <article
              onClick={() => setActiveService('tax')}
              className={`p-6 border-b border-r border-[#d8d8d8] flex flex-col justify-between hover:bg-[#f3f2f1] transition-colors cursor-pointer group focus-within:ring-4 focus-within:ring-[#ffdd00] ${
                a11y.contrast === 'high-contrast-yellow' ? 'hover:bg-neutral-900 border-[#ffdd00]/40' : 'bg-white'
              }`}
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="p-2.5 border-2 border-[#0b0c0c] bg-white text-[#0b0c0c] mb-4">
                    <Coins className="w-6 h-6 stroke-[1.8]" />
                  </div>
                  <ArrowRight className="w-5 h-5 text-[#002447] group-hover:translate-x-1.5 transition-transform" />
                </div>
                <h3
                  className={`text-lg sm:text-xl font-bold group-hover:underline ${
                    a11y.contrast === 'high-contrast-yellow' ? 'text-[#ffdd00]' : 'text-[#002447]'
                  }`}
                >
                  {lang === 'en' ? 'Manage your tax' : 'Rheoli eich treth'}
                </h3>
                <p className="text-sm text-[#505a5f] mt-1.5 leading-relaxed">
                  {lang === 'en'
                    ? 'Pay your tax, check your records and update your details.'
                    : 'Talu eich treth, gwirio eich cofnodion a diweddaru eich manylion.'}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center text-xs font-bold text-[#1d70b8]">
                <span>{lang === 'en' ? 'Self Assessment & PAYE' : 'Hunanasesiad a TWE'}</span>
              </div>
            </article>

            {/* 3. Find benefits and support */}
            <article
              onClick={() => setActiveService('benefits')}
              className={`p-6 border-b border-r border-[#d8d8d8] flex flex-col justify-between hover:bg-[#f3f2f1] transition-colors cursor-pointer group focus-within:ring-4 focus-within:ring-[#ffdd00] ${
                a11y.contrast === 'high-contrast-yellow' ? 'hover:bg-neutral-900 border-[#ffdd00]/40' : 'bg-white'
              }`}
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="p-2.5 border-2 border-[#0b0c0c] bg-white text-[#0b0c0c] mb-4">
                    <Users className="w-6 h-6 stroke-[1.8]" />
                  </div>
                  <ArrowRight className="w-5 h-5 text-[#002447] group-hover:translate-x-1.5 transition-transform" />
                </div>
                <h3
                  className={`text-lg sm:text-xl font-bold group-hover:underline ${
                    a11y.contrast === 'high-contrast-yellow' ? 'text-[#ffdd00]' : 'text-[#002447]'
                  }`}
                >
                  {lang === 'en' ? 'Find benefits and support' : 'Canfod budd-daliadau a chymorth'}
                </h3>
                <p className="text-sm text-[#505a5f] mt-1.5 leading-relaxed">
                  {lang === 'en'
                    ? 'Check what you could be entitled to and apply for support.'
                    : 'Gwiriwch beth y gallwch fod â hawl iddo a gwnewch gais am gymorth.'}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center text-xs font-bold text-[#1d70b8]">
                <span>{lang === 'en' ? 'Universal Credit & child support' : 'Credyd Cynhwysol a chymorth'}</span>
              </div>
            </article>

            {/* 4. Work and pensions */}
            <article
              onClick={() => setActiveService('work-pensions')}
              className={`p-6 border-b border-r border-[#d8d8d8] flex flex-col justify-between hover:bg-[#f3f2f1] transition-colors cursor-pointer group focus-within:ring-4 focus-within:ring-[#ffdd00] ${
                a11y.contrast === 'high-contrast-yellow' ? 'hover:bg-neutral-900 border-[#ffdd00]/40' : 'bg-white'
              }`}
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="p-2.5 border-2 border-[#0b0c0c] bg-white text-[#0b0c0c] mb-4">
                    <Briefcase className="w-6 h-6 stroke-[1.8]" />
                  </div>
                  <ArrowRight className="w-5 h-5 text-[#002447] group-hover:translate-x-1.5 transition-transform" />
                </div>
                <h3
                  className={`text-lg sm:text-xl font-bold group-hover:underline ${
                    a11y.contrast === 'high-contrast-yellow' ? 'text-[#ffdd00]' : 'text-[#002447]'
                  }`}
                >
                  {lang === 'en' ? 'Work and pensions' : 'Gwaith a phensiynau'}
                </h3>
                <p className="text-sm text-[#505a5f] mt-1.5 leading-relaxed">
                  {lang === 'en'
                    ? 'Find a job, get workplace support and plan for your retirement.'
                    : 'Dod o hyd i swydd, cael cymorth yn y gweithle a chynllunio ar gyfer eich ymddeoliad.'}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center text-xs font-bold text-[#1d70b8]">
                <span>{lang === 'en' ? 'Pension forecast & Find a Job' : 'Rhagolwg pensiwn a swyddi'}</span>
              </div>
            </article>

            {/* 5. Driving and transport */}
            <article
              onClick={() => setActiveService('driving')}
              className={`p-6 border-b border-r border-[#d8d8d8] flex flex-col justify-between hover:bg-[#f3f2f1] transition-colors cursor-pointer group focus-within:ring-4 focus-within:ring-[#ffdd00] ${
                a11y.contrast === 'high-contrast-yellow' ? 'hover:bg-neutral-900 border-[#ffdd00]/40' : 'bg-white'
              }`}
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="p-2.5 border-2 border-[#0b0c0c] bg-white text-[#0b0c0c] mb-4">
                    <Car className="w-6 h-6 stroke-[1.8]" />
                  </div>
                  <ArrowRight className="w-5 h-5 text-[#002447] group-hover:translate-x-1.5 transition-transform" />
                </div>
                <h3
                  className={`text-lg sm:text-xl font-bold group-hover:underline ${
                    a11y.contrast === 'high-contrast-yellow' ? 'text-[#ffdd00]' : 'text-[#002447]'
                  }`}
                >
                  {lang === 'en' ? 'Driving and transport' : 'Gyrru a thrafnidiaeth'}
                </h3>
                <p className="text-sm text-[#505a5f] mt-1.5 leading-relaxed">
                  {lang === 'en'
                    ? 'Renew your driving licence, book a driving test and find transport information.'
                    : 'Adnewyddu eich trwydded yrru, archebu prawf gyrru a chanfod gwybodaeth am drafnidiaeth.'}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center text-xs font-bold text-[#1d70b8]">
                <span>{lang === 'en' ? 'Vehicle tax, MOT & tests' : 'Treth cerbyd, MOT a phrofion'}</span>
              </div>
            </article>

            {/* 6. Education and childcare */}
            <article
              onClick={() => setActiveService('education')}
              className={`p-6 border-b border-r border-[#d8d8d8] flex flex-col justify-between hover:bg-[#f3f2f1] transition-colors cursor-pointer group focus-within:ring-4 focus-within:ring-[#ffdd00] ${
                a11y.contrast === 'high-contrast-yellow' ? 'hover:bg-neutral-900 border-[#ffdd00]/40' : 'bg-white'
              }`}
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="p-2.5 border-2 border-[#0b0c0c] bg-white text-[#0b0c0c] mb-4">
                    <GraduationCap className="w-6 h-6 stroke-[1.8]" />
                  </div>
                  <ArrowRight className="w-5 h-5 text-[#002447] group-hover:translate-x-1.5 transition-transform" />
                </div>
                <h3
                  className={`text-lg sm:text-xl font-bold group-hover:underline ${
                    a11y.contrast === 'high-contrast-yellow' ? 'text-[#ffdd00]' : 'text-[#002447]'
                  }`}
                >
                  {lang === 'en' ? 'Education and childcare' : 'Addysg a gofal plant'}
                </h3>
                <p className="text-sm text-[#505a5f] mt-1.5 leading-relaxed">
                  {lang === 'en'
                    ? 'Find school information, childcare support and help with education costs.'
                    : 'Dod o hyd i wybodaeth am ysgolion, cymorth gofal plant a chymorth gyda chostau addysg.'}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center text-xs font-bold text-[#1d70b8]">
                <span>{lang === 'en' ? 'Childcare hours & student loans' : 'Oriau gofal plant a benthyciadau'}</span>
              </div>
            </article>
          </div>
        </section>

        {/* SECTION: YOUR GOVERNMENT + CIVIC CENTRE + PUBLIC SERVICES CLOSER TO YOU */}
        <section aria-labelledby="lower-hub-heading" className="pt-8 pb-12 border-t-2 border-[#0b0c0c]">
          <h2 id="lower-hub-heading" className="sr-only">
            Local and National Government Directory
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left 4 Cols: Your government directory links */}
            <div className="lg:col-span-4 space-y-4">
              <h3
                className={`text-2xl font-extrabold tracking-tight ${
                  a11y.contrast === 'high-contrast-yellow' ? 'text-[#ffdd00]' : 'text-[#0b0c0c]'
                }`}
              >
                {lang === 'en' ? 'Your government' : 'Eich llywodraeth'}
              </h3>

              <div className="space-y-3 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveService('departments')}
                  className={`w-full text-left py-2 flex items-center justify-between group ${
                    a11y.contrast === 'high-contrast-yellow'
                      ? 'text-[#ffdd00]'
                      : 'text-[#1d70b8] hover:text-[#002447]'
                  } ${linkUnderlineClass}`}
                >
                  <span className="font-bold text-base sm:text-lg">
                    {lang === 'en' ? 'Departments and agencies' : 'Adrannau ac asiantaethau'}
                  </span>
                  <ArrowRight className="w-5 h-5 text-[#002447] group-hover:translate-x-1.5 transition-transform shrink-0" />
                </button>

                <button
                  type="button"
                  onClick={() => setActiveService('policies')}
                  className={`w-full text-left py-2 flex items-center justify-between group ${
                    a11y.contrast === 'high-contrast-yellow'
                      ? 'text-[#ffdd00]'
                      : 'text-[#1d70b8] hover:text-[#002447]'
                  } ${linkUnderlineClass}`}
                >
                  <span className="font-bold text-base sm:text-lg">
                    {lang === 'en' ? 'Policies and publications' : 'Polisïau a chyhoeddiadau'}
                  </span>
                  <ArrowRight className="w-5 h-5 text-[#002447] group-hover:translate-x-1.5 transition-transform shrink-0" />
                </button>

                <button
                  type="button"
                  onClick={() => setActiveService('contact')}
                  className={`w-full text-left py-2 flex items-center justify-between group ${
                    a11y.contrast === 'high-contrast-yellow'
                      ? 'text-[#ffdd00]'
                      : 'text-[#1d70b8] hover:text-[#002447]'
                  } ${linkUnderlineClass}`}
                >
                  <span className="font-bold text-base sm:text-lg">
                    {lang === 'en' ? 'Contact government' : 'Cysylltu â’r llywodraeth'}
                  </span>
                  <ArrowRight className="w-5 h-5 text-[#002447] group-hover:translate-x-1.5 transition-transform shrink-0" />
                </button>
              </div>

              <div className="pt-4 border-t border-[#d8d8d8] text-xs text-[#505a5f]">
                <p>
                  Official central government directory coordinating 24 ministerial departments and 410 agencies.
                </p>
              </div>
            </div>

            {/* Middle 4 Cols: Civic Centre modern photo */}
            <div className="lg:col-span-3">
              <div className="relative aspect-4/3 w-full overflow-hidden border-2 border-[#b1b4b6] shadow-sm bg-neutral-200">
                <Image
                  src="/civic_centre_uk.jpg"
                  alt="Modern Civic Centre and public library building with citizens entering community services"
                  fill
                  referrerPolicy="no-referrer"
                  className="object-cover"
                  sizes="(max-width: 1024px) 100vw, 30vw"
                />
                <div className="absolute bottom-2 left-2 px-2 py-0.5 bg-black/75 text-white text-[11px] font-semibold">
                  Civic Centre
                </div>
              </div>
            </div>

            {/* Right 5 Cols: Public services, closer to you + Postcode Lookup */}
            <div className="lg:col-span-5 space-y-4">
              <h3
                className={`text-2xl sm:text-3xl font-extrabold tracking-tight ${
                  a11y.contrast === 'high-contrast-yellow' ? 'text-[#ffdd00]' : 'text-[#0b0c0c]'
                }`}
              >
                {lang === 'en' ? 'Public services, closer to you' : 'Gwasanaethau cyhoeddus, yn nes atoch'}
              </h3>

              <p
                className={`text-sm sm:text-base leading-relaxed ${
                  a11y.contrast === 'high-contrast-yellow' ? 'text-yellow-200' : 'text-[#333333]'
                }`}
              >
                {lang === 'en'
                  ? 'From local support to national services, we’re making it simpler to get the help you need, when you need it, in your community and online.'
                  : 'O gymorth lleol i wasanaethau cenedlaethol, rydym yn ei gwneud yn symlach i gael y cymorth sydd ei angen arnoch, pryd y mae ei angen arnoch, yn eich cymuned ac ar-lein.'}
              </p>

              {/* Find local services postcode box */}
              <div className="pt-2">
                <label
                  htmlFor="postcode-input"
                  className={`block text-base font-bold mb-2 ${
                    a11y.contrast === 'high-contrast-yellow' ? 'text-[#ffdd00]' : 'text-[#0b0c0c]'
                  }`}
                >
                  {lang === 'en' ? 'Find local services' : 'Canfod gwasanaethau lleol'}
                </label>

                <form onSubmit={handlePostcodeSubmit} className="flex flex-col sm:flex-row gap-2">
                  <div
                    className={`relative flex-1 flex items-center border-2 ${
                      a11y.contrast === 'high-contrast-yellow'
                        ? 'border-[#ffdd00] bg-black'
                        : 'border-[#0b0c0c] bg-white'
                    } focus-within:ring-4 focus-within:ring-[#ffdd00]`}
                  >
                    <div className="pl-3 pr-1 text-[#505a5f]">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <input
                      id="postcode-input"
                      type="text"
                      value={postcode}
                      onChange={(e) => setPostcode(e.target.value.toUpperCase())}
                      placeholder={lang === 'en' ? 'Enter your postcode' : 'Rhowch eich cod post'}
                      className={`w-full py-2.5 px-2 text-sm sm:text-base font-mono outline-none bg-transparent uppercase ${
                        a11y.contrast === 'high-contrast-yellow'
                          ? 'text-[#ffdd00] placeholder:text-yellow-600'
                          : 'text-[#0b0c0c] placeholder:text-[#505a5f]'
                      }`}
                    />
                  </div>

                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-[#005a36] hover:bg-[#00472b] text-white font-bold text-sm sm:text-base transition-colors shrink-0 focus:outline-4 focus:outline-[#ffdd00]"
                  >
                    {lang === 'en' ? 'Find services' : 'Canfod gwasanaethau'}
                  </button>
                </form>

                <div className="mt-2 text-xs text-[#505a5f] flex items-center gap-1">
                  <span>Try:</span>
                  <button
                    type="button"
                    onClick={() => {
                      setPostcode('SW1A 1AA');
                      setIsLocalModalOpen(true);
                    }}
                    className="font-mono underline text-[#1d70b8] hover:text-[#002447]"
                  >
                    SW1A 1AA (Westminster)
                  </button>
                  <span>·</span>
                  <button
                    type="button"
                    onClick={() => {
                      setPostcode('M1 1AE');
                      setIsLocalModalOpen(true);
                    }}
                    className="font-mono underline text-[#1d70b8] hover:text-[#002447]"
                  >
                    M1 1AE (Manchester)
                  </button>
                  <span>·</span>
                  <button
                    type="button"
                    onClick={() => {
                      setPostcode('CF10 1EP');
                      setIsLocalModalOpen(true);
                    }}
                    className="font-mono underline text-[#1d70b8] hover:text-[#002447]"
                  >
                    CF10 1EP (Cardiff)
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer
        role="contentinfo"
        className={`w-full border-t-2 py-8 px-4 sm:px-6 lg:px-8 mt-auto ${
          a11y.contrast === 'high-contrast-yellow'
            ? 'border-[#ffdd00] bg-black text-[#ffdd00]'
            : 'border-[#b1b4b6] bg-[#f3f2f1] text-[#0b0c0c]'
        }`}
      >
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          {/* Footer policy links */}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm font-semibold">
            <button
              onClick={() => setActiveService('contact')}
              className={`hover:underline text-[#002447] ${linkUnderlineClass}`}
            >
              {lang === 'en' ? 'Help' : 'Cymorth'}
            </button>
            <span className="text-[#b1b4b6]" aria-hidden="true">|</span>
            <button
              onClick={() => setIsAccessibilityOpen(true)}
              className={`hover:underline text-[#002447] ${linkUnderlineClass}`}
            >
              {lang === 'en' ? 'Accessibility' : 'Hygyrchedd'}
            </button>
            <span className="text-[#b1b4b6]" aria-hidden="true">|</span>
            <button
              onClick={() => alert('HM Government Data Protection and Privacy Notice conforms to UK GDPR.')}
              className={`hover:underline text-[#002447] ${linkUnderlineClass}`}
            >
              {lang === 'en' ? 'Privacy' : 'Preifatrwydd'}
            </button>
            <span className="text-[#b1b4b6]" aria-hidden="true">|</span>
            <button
              onClick={() => alert('Only essential security and accessibility cookies are deployed.')}
              className={`hover:underline text-[#002447] ${linkUnderlineClass}`}
            >
              {lang === 'en' ? 'Cookies' : 'Cwcis'}
            </button>
          </div>

          {/* Right badge matching reference: "Independent design concept" */}
          <div className="text-xs text-[#505a5f] flex items-center gap-3">
            <span className="italic">Independent design concept</span>
            <span className="text-[#b1b4b6]">|</span>
            <span>All content available under Open Government Licence v3.0</span>
          </div>
        </div>
      </footer>

      {/* MODALS & DRAWERS */}
      <AccessibilityModal
        isOpen={isAccessibilityOpen}
        onClose={() => setIsAccessibilityOpen(false)}
        settings={a11y}
        setSettings={setA11y}
        onSpeakSummary={handleSpeakSummary}
        isSpeaking={isSpeaking}
        onStopSpeaking={stopSpeaking}
        lang={lang}
      />

      <ServiceModal
        serviceId={activeService}
        onClose={() => setActiveService(null)}
        lang={lang}
      />

      <LocalServicesModal
        postcode={postcode || 'SW1A 1AA'}
        isOpen={isLocalModalOpen}
        onClose={() => setIsLocalModalOpen(false)}
        lang={lang}
      />

      <DesignMockupModal
        isOpen={isDesignModalOpen}
        onClose={() => setIsDesignModalOpen(false)}
        generatedImagePath="/generated-gov-ui.jpg"
        referenceImagePath="/assets/aistudio/293f2143-07da-4c3b-aa03-0c06c55c069f_aa875ee1.png"
      />

      <SignInModal
        isOpen={isSignInOpen}
        onClose={() => setIsSignInOpen(false)}
        lang={lang}
      />
    </div>
  );
}
