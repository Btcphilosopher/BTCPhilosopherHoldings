import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'HM Government - Government Services Made Clear',
  description: 'Clean, accessible government website with prominent public service navigation, search, and local civic services.',
  openGraph: {
    title: 'HM Government - Government Services Made Clear',
    description: 'Clean, accessible government website with prominent public service navigation, search, and local civic services.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'HM Government - Government Services Made Clear',
    description: 'Clean, accessible government website with prominent public service navigation, search, and local civic services.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
