import React from 'react';

interface RoyalCrestProps {
  className?: string;
  size?: number;
}

export function RoyalCrest({ className = 'text-current', size = 38 }: RoyalCrestProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="HM Government Royal Arms Insignia"
      role="img"
    >
      {/* Crown Top */}
      <path d="M41 18 L50 12 L59 18 L57 23 L43 23 Z" fill="currentColor" />
      <circle cx="50" cy="11" r="2.5" fill="currentColor" />
      <circle cx="41" cy="17" r="1.8" fill="currentColor" />
      <circle cx="59" cy="17" r="1.8" fill="currentColor" />
      <rect x="42" y="24" width="16" height="4" rx="1" fill="currentColor" />
      
      {/* Central Shield */}
      <path
        d="M38 31 C38 31, 38 60, 50 68 C62 60, 62 31, 62 31 Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="3.2"
        strokeLinejoin="round"
      />
      {/* Shield Quartering */}
      <line x1="50" y1="31" x2="50" y2="67" stroke="currentColor" strokeWidth="2" />
      <line x1="39" y1="48" x2="61" y2="48" stroke="currentColor" strokeWidth="2" />

      {/* Lions inside quarters */}
      {/* Q1: 3 English lions passants */}
      <path d="M42 36 h5 M42 39 h6 M42 42 h5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      {/* Q2: Scottish lion rampant */}
      <path d="M54 36 v6 m0-3 h4 m-3 3 l3 2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      {/* Q3: Irish Harp */}
      <path d="M43 53 c2 0 4 3 4 8 M43 53 v8 M44 57 h3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
      {/* Q4: English lions passants */}
      <path d="M53 54 h5 M53 57 h6 M53 60 h5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />

      {/* Supporter Left: Lion Rampant */}
      <path
        d="M25 58 C23 52, 22 43, 26 36 C28 33, 31 34, 33 38 C34 40, 36 43, 36 47 C34 48, 33 50, 34 54 C35 57, 34 60, 31 63 C28 66, 25 64, 25 58 Z"
        fill="currentColor"
      />
      {/* Lion Crown */}
      <path d="M26 32 L28 35 L30 32 L32 35 L34 32 L34 36 L26 36 Z" fill="currentColor" />
      {/* Lion Paw touching shield */}
      <path d="M32 44 L38 41 L37 44 Z" fill="currentColor" />
      <path d="M33 54 L38 52 L36 55 Z" fill="currentColor" />

      {/* Supporter Right: Unicorn Rampant */}
      <path
        d="M75 58 C77 52, 78 43, 74 36 C72 33, 69 34, 67 38 C66 40, 64 43, 64 47 C66 48, 67 50, 66 54 C65 57, 66 60, 69 63 C72 66, 75 64, 75 58 Z"
        fill="currentColor"
      />
      {/* Unicorn Horn */}
      <line x1="73" y1="35" x2="80" y2="28" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      {/* Unicorn Collar & Chain */}
      <path d="M72 38 C70 41, 69 44, 70 47" stroke="currentColor" strokeWidth="1.5" fill="none" />
      <path d="M70 47 C67 52, 69 57, 72 62" stroke="currentColor" strokeWidth="1.2" strokeDasharray="1.5 1.5" fill="none" />
      {/* Unicorn Hoof touching shield */}
      <path d="M68 44 L62 41 L63 44 Z" fill="currentColor" />
      <path d="M67 54 L62 52 L64 55 Z" fill="currentColor" />

      {/* Compartment & Banner (Dieu et mon droit) */}
      <path
        d="M20 73 C30 70, 42 72, 50 72 C58 72, 70 70, 80 73 C76 77, 66 77, 50 76 C34 77, 24 77, 20 73 Z"
        fill="currentColor"
      />
      <rect x="26" y="78" width="48" height="4" rx="2" fill="currentColor" />
      <circle cx="50" cy="80" r="1.2" fill="#fff" />
    </svg>
  );
}
