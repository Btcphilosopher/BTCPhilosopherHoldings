'use client';

import React, { useState } from 'react';
import { X, Download, ZoomIn, ZoomOut, Maximize2, Check, Sparkles, Layers, Sliders } from 'lucide-react';

interface DesignMockupModalProps {
  isOpen: boolean;
  onClose: () => void;
  generatedImagePath: string;
  referenceImagePath: string;
}

export function DesignMockupModal({
  isOpen,
  onClose,
  generatedImagePath,
  referenceImagePath,
}: DesignMockupModalProps) {
  const [activeTab, setActiveTab] = useState<'generated' | 'reference' | 'comparison' | 'tokens'>('generated');
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="design-mockup-heading"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-6xl bg-white border-4 border-[#0b0c0c] shadow-2xl flex flex-col h-[92vh] overflow-hidden">
        {/* Header bar */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#002447] text-white">
          <div className="flex items-center gap-3">
            <span className="p-1.5 bg-[#005a36] text-white">
              <Sparkles className="w-4 h-4" />
            </span>
            <div>
              <h2 id="design-mockup-heading" className="text-lg md:text-xl font-bold">
                Government Website Design System & Generated Image
              </h2>
              <p className="text-xs text-neutral-300">
                Pixel-accurate rendering conforming to accessibility typography, public service grid & search
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={generatedImagePath}
              download="gov-website-design-mockup.jpg"
              className="px-3 py-1.5 bg-[#005a36] text-white text-xs font-bold hover:bg-[#00703c] inline-flex items-center gap-1.5 focus:outline-4 focus:outline-[#ffdd00]"
            >
              <Download className="w-3.5 h-3.5" /> Download Full Image
            </a>
            <button
              onClick={onClose}
              className="p-1.5 text-white hover:bg-white/20 border border-transparent focus:outline-4 focus:outline-[#ffdd00]"
              aria-label="Close design mockup view"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab switch navigation */}
        <div className="flex items-center justify-between px-6 py-2.5 bg-[#f3f2f1] border-b-2 border-[#b1b4b6] text-xs font-bold text-[#0b0c0c]">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('generated')}
              className={`px-3 py-1.5 border-b-3 transition-colors ${
                activeTab === 'generated'
                  ? 'border-[#002447] text-[#002447] bg-white'
                  : 'border-transparent text-[#505a5f] hover:text-[#0b0c0c]'
              }`}
            >
              Generated Website Image
            </button>
            <button
              onClick={() => setActiveTab('reference')}
              className={`px-3 py-1.5 border-b-3 transition-colors ${
                activeTab === 'reference'
                  ? 'border-[#002447] text-[#002447] bg-white'
                  : 'border-transparent text-[#505a5f] hover:text-[#0b0c0c]'
              }`}
            >
              Original User Reference
            </button>
            <button
              onClick={() => setActiveTab('comparison')}
              className={`px-3 py-1.5 border-b-3 transition-colors ${
                activeTab === 'comparison'
                  ? 'border-[#002447] text-[#002447] bg-white'
                  : 'border-transparent text-[#505a5f] hover:text-[#0b0c0c]'
              }`}
            >
              Side-by-Side Comparison
            </button>
            <button
              onClick={() => setActiveTab('tokens')}
              className={`px-3 py-1.5 border-b-3 transition-colors ${
                activeTab === 'tokens'
                  ? 'border-[#002447] text-[#002447] bg-white'
                  : 'border-transparent text-[#505a5f] hover:text-[#0b0c0c]'
              }`}
            >
              Design Tokens & Accessibility Metrics
            </button>
          </div>

          {(activeTab === 'generated' || activeTab === 'reference') && (
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setZoomLevel((z) => Math.max(0.6, z - 0.2))}
                className="p-1 border border-[#b1b4b6] bg-white hover:bg-neutral-100"
                aria-label="Zoom out"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="px-2 text-[11px] font-mono text-[#505a5f]">{Math.round(zoomLevel * 100)}%</span>
              <button
                onClick={() => setZoomLevel((z) => Math.min(2.5, z + 0.2))}
                className="p-1 border border-[#b1b4b6] bg-white hover:bg-neutral-100"
                aria-label="Zoom in"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setZoomLevel(1)}
                className="px-2 py-1 border border-[#b1b4b6] bg-white text-[11px] hover:bg-neutral-100"
              >
                Fit
              </button>
            </div>
          )}
        </div>

        {/* Content viewer */}
        <div className="flex-1 bg-neutral-900 overflow-auto p-4 flex items-center justify-center">
          {activeTab === 'generated' && (
            <div
              style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'center center' }}
              className="transition-transform duration-150 max-w-full shadow-2xl border-2 border-neutral-700 bg-white"
            >
              <img
                src={generatedImagePath}
                alt="Generated Government Website User Interface Mockup"
                className="max-h-[75vh] w-auto object-contain mx-auto"
                referrerPolicy="no-referrer"
              />
            </div>
          )}

          {activeTab === 'reference' && (
            <div
              style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'center center' }}
              className="transition-transform duration-150 max-w-full shadow-2xl border-2 border-neutral-700 bg-white"
            >
              <img
                src={referenceImagePath}
                alt="Original Reference Government Website Design"
                className="max-h-[75vh] w-auto object-contain mx-auto"
                referrerPolicy="no-referrer"
              />
            </div>
          )}

          {activeTab === 'comparison' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full h-full max-h-[75vh]">
              <div className="flex flex-col bg-white border border-neutral-300 p-2 overflow-hidden">
                <div className="px-2 py-1 text-xs font-bold uppercase bg-[#002447] text-white mb-2">
                  Generated Government UI Design
                </div>
                <div className="flex-1 flex items-center justify-center overflow-auto bg-neutral-100 p-1">
                  <img
                    src={generatedImagePath}
                    alt="Generated Mockup"
                    className="max-h-full max-w-full object-contain"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>

              <div className="flex flex-col bg-white border border-neutral-300 p-2 overflow-hidden">
                <div className="px-2 py-1 text-xs font-bold uppercase bg-[#005a36] text-white mb-2">
                  User Reference Specimen
                </div>
                <div className="flex-1 flex items-center justify-center overflow-auto bg-neutral-100 p-1">
                  <img
                    src={referenceImagePath}
                    alt="Reference Specimen"
                    className="max-h-full max-w-full object-contain"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'tokens' && (
            <div className="bg-white p-6 max-w-4xl w-full border-2 border-neutral-300 shadow-xl overflow-y-auto max-h-[75vh] text-[#0b0c0c]">
              <h3 className="text-xl font-bold mb-4 pb-2 border-b-2 border-[#b1b4b6]">
                Design System Specification & Accessibility Standards
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold text-sm text-[#002447] uppercase mb-3">Color Palette & Contrast Metrics</h4>
                  <div className="space-y-2 text-xs">
                    <div className="p-2.5 border border-[#b1b4b6] flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 bg-[#002447] border border-black"></div>
                        <span className="font-bold">Gov Navy (#002447)</span>
                      </div>
                      <span className="text-[#00703c] font-bold">14.8:1 (WCAG AAA)</span>
                    </div>

                    <div className="p-2.5 border border-[#b1b4b6] flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 bg-[#005a36] border border-black"></div>
                        <span className="font-bold">Gov Forest Green (#005a36)</span>
                      </div>
                      <span className="text-[#00703c] font-bold">7.2:1 (WCAG AAA)</span>
                    </div>

                    <div className="p-2.5 border border-[#b1b4b6] flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 bg-[#1d70b8] border border-black"></div>
                        <span className="font-bold">Gov Link Blue (#1d70b8)</span>
                      </div>
                      <span className="text-[#00703c] font-bold">5.1:1 (WCAG AA)</span>
                    </div>

                    <div className="p-2.5 border border-[#b1b4b6] flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 bg-[#ffdd00] border border-black"></div>
                        <span className="font-bold">Focus Indicator Yellow (#ffdd00)</span>
                      </div>
                      <span className="font-bold">High visibility focus ring</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-sm text-[#002447] uppercase mb-3">Typography & Hierarchy</h4>
                  <ul className="text-xs space-y-2 text-[#333]">
                    <li className="p-2 bg-[#f8f8f8] border border-[#d8d8d8]">
                      <strong>Hero Display (48px / 3rem):</strong> Heavy bold weight, line height 1.15, crisp letter tracking for high readability.
                    </li>
                    <li className="p-2 bg-[#f8f8f8] border border-[#d8d8d8]">
                      <strong>Section Headings (28px / 1.75rem):</strong> Clear, direct phrasing (&apos;What do you need to do?&apos;).
                    </li>
                    <li className="p-2 bg-[#f8f8f8] border border-[#d8d8d8]">
                      <strong>Service Card Titles (18px):</strong> Link blue (#1d70b8 / #002447), bold weight with directional chevron indicators.
                    </li>
                    <li className="p-2 bg-[#f8f8f8] border border-[#d8d8d8]">
                      <strong>Body Text (15px):</strong> Neutral dark (#333333) ensuring effortless reading across all screen resolutions.
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer info bar */}
        <div className="px-6 py-3 bg-white border-t-2 border-[#b1b4b6] flex items-center justify-between text-xs text-[#505a5f]">
          <span>Prompt: Clean layout, accessibility-focused typography, clear search bar, public services navigation.</span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#002447] text-white font-bold hover:bg-[#00172e] focus:outline-4 focus:outline-[#ffdd00]"
          >
            Back to Interactive Portal
          </button>
        </div>
      </div>
    </div>
  );
}
