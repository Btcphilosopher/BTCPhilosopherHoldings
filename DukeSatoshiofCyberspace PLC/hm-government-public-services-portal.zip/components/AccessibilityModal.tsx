'use client';

import React from 'react';
import { Volume2, VolumeX, Eye, Type, Sparkles, Check, X, RotateCcw } from 'lucide-react';

export interface AccessibilitySettings {
  fontSize: 'standard' | 'large' | 'xlarge';
  contrast: 'standard' | 'high-contrast-yellow' | 'dark-mode';
  dyslexicFont: boolean;
  underlineLinks: boolean;
  highFocus: boolean;
  motionReduced: boolean;
}

interface AccessibilityModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AccessibilitySettings;
  setSettings: React.Dispatch<React.SetStateAction<AccessibilitySettings>>;
  onSpeakSummary: () => void;
  isSpeaking: boolean;
  onStopSpeaking: () => void;
  lang: 'en' | 'cy';
}

export function AccessibilityModal({
  isOpen,
  onClose,
  settings,
  setSettings,
  onSpeakSummary,
  isSpeaking,
  onStopSpeaking,
  lang,
}: AccessibilityModalProps) {
  if (!isOpen) return null;

  const resetToDefault = () => {
    setSettings({
      fontSize: 'standard',
      contrast: 'standard',
      dyslexicFont: false,
      underlineLinks: true,
      highFocus: true,
      motionReduced: false,
    });
  };

  const t = {
    title: lang === 'en' ? 'Accessibility & Display Preferences' : 'Dewisiadau Hygyrchedd a Display',
    subtitle:
      lang === 'en'
        ? 'Customize text size, contrast, and assistive audio for easier reading.'
        : 'Addaswch faint testun, cyferbyniad a sain ategol ar gyfer darllen haws.',
    textSize: lang === 'en' ? 'Text Size' : 'Maint y Testun',
    contrast: lang === 'en' ? 'Contrast Mode' : 'Modd Cyferbyniad',
    standard: lang === 'en' ? 'Standard (100%)' : 'Safonol (100%)',
    large: lang === 'en' ? 'Large (120%)' : 'Mawr (120%)',
    xlarge: lang === 'en' ? 'Extra Large (140%)' : 'Mawr Iawn (140%)',
    standardContrast: lang === 'en' ? 'Official Gov Palette' : 'Palet Swyddogol y Llywodraeth',
    highContrastYellow: lang === 'en' ? 'High Contrast (Yellow / Black)' : 'Cyferbyniad Uchel (Melyn / Du)',
    nightMode: lang === 'en' ? 'Low Glare Dark Mode' : 'Modd Tywyll Disgleirdeb Isel',
    dyslexic: lang === 'en' ? 'Dyslexia Friendly Font & Letter Spacing' : 'Ffont a Bylchau Cyfeillgar i Ddyslecsia',
    underline: lang === 'en' ? 'Always Underline Links' : 'Tanlinellu Pob Dolen Bob Amser',
    highFocus: lang === 'en' ? 'Thick High-Visibility Focus Outline' : 'Amlinelliad Ffocws Gweladwy Trwchus',
    screenReader: lang === 'en' ? 'Speech & Audio Assistance' : 'Cymorth Lleferydd a Sain',
    readAloud: lang === 'en' ? 'Read Page Summary Aloud' : 'Darllen Crynodeb y Dudalen yn Uchel',
    stopReading: lang === 'en' ? 'Stop Reading' : 'Stopio Darllen',
    reset: lang === 'en' ? 'Reset to Defaults' : 'Ailosod i Ddiffygion',
    close: lang === 'en' ? 'Done & Close' : 'Wedi Gorffen a Cau',
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="accessibility-heading"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-xl bg-white border-4 border-[#0b0c0c] shadow-2xl p-6 md:p-8 max-h-[90vh] overflow-y-auto">
        <div className="flex items-start justify-between pb-4 border-b-2 border-[#b1b4b6]">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 text-xs font-bold tracking-wide uppercase bg-[#002447] text-white mb-2">
              <Eye className="w-3.5 h-3.5" aria-hidden="true" />
              WCAG 2.2 AAA Compliant
            </div>
            <h2 id="accessibility-heading" className="text-2xl font-bold text-[#0b0c0c]">
              {t.title}
            </h2>
            <p className="text-sm text-[#505a5f] mt-1">{t.subtitle}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-[#0b0c0c] hover:bg-[#f3f2f1] rounded-none border border-transparent hover:border-[#0b0c0c] focus:outline-4 focus:outline-[#ffdd00]"
            aria-label="Close accessibility options"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="space-y-6 pt-5">
          {/* Text Size */}
          <div>
            <label className="block text-sm font-bold text-[#0b0c0c] uppercase tracking-wider mb-2">
              <Type className="inline w-4 h-4 mr-1 text-[#002447]" />
              {t.textSize}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'standard', label: t.standard, size: 'text-sm' },
                { id: 'large', label: t.large, size: 'text-base font-semibold' },
                { id: 'xlarge', label: t.xlarge, size: 'text-lg font-bold' },
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() =>
                    setSettings((prev) => ({
                      ...prev,
                      fontSize: opt.id as AccessibilitySettings['fontSize'],
                    }))
                  }
                  className={`p-3 text-center border-2 transition-colors ${
                    settings.fontSize === opt.id
                      ? 'border-[#002447] bg-[#f0f4f9] text-[#002447] font-bold ring-2 ring-[#002447]'
                      : 'border-[#b1b4b6] bg-white text-[#0b0c0c] hover:bg-[#f3f2f1]'
                  } focus:outline-4 focus:outline-[#ffdd00]`}
                >
                  <span className={`block ${opt.size}`}>{opt.id === 'standard' ? 'A' : opt.id === 'large' ? 'A+' : 'A++'}</span>
                  <span className="text-xs mt-1 block">{opt.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Contrast Mode */}
          <div>
            <label className="block text-sm font-bold text-[#0b0c0c] uppercase tracking-wider mb-2">
              <Sparkles className="inline w-4 h-4 mr-1 text-[#002447]" />
              {t.contrast}
            </label>
            <div className="space-y-2">
              <button
                onClick={() => setSettings((prev) => ({ ...prev, contrast: 'standard' }))}
                className={`w-full text-left p-3 border-2 flex items-center justify-between ${
                  settings.contrast === 'standard'
                    ? 'border-[#002447] bg-[#f0f4f9] text-[#002447] font-bold'
                    : 'border-[#b1b4b6] bg-white text-[#0b0c0c] hover:bg-[#f3f2f1]'
                } focus:outline-4 focus:outline-[#ffdd00]`}
              >
                <div>
                  <span className="font-bold text-sm block">{t.standardContrast}</span>
                  <span className="text-xs text-[#505a5f]">Clean white, deep navy blue headers (#002447), deep green search buttons</span>
                </div>
                {settings.contrast === 'standard' && <Check className="w-5 h-5 text-[#002447]" />}
              </button>

              <button
                onClick={() => setSettings((prev) => ({ ...prev, contrast: 'high-contrast-yellow' }))}
                className={`w-full text-left p-3 border-2 flex items-center justify-between ${
                  settings.contrast === 'high-contrast-yellow'
                    ? 'border-[#ffdd00] bg-black text-[#ffdd00] font-bold'
                    : 'border-[#0b0c0c] bg-black text-[#ffdd00] hover:bg-neutral-900'
                } focus:outline-4 focus:outline-[#ffdd00]`}
              >
                <div>
                  <span className="font-bold text-sm block">{t.highContrastYellow}</span>
                  <span className="text-xs text-yellow-200">Maximum visual contrast (19:1 ratio) for low vision and dyslexia</span>
                </div>
                {settings.contrast === 'high-contrast-yellow' && <Check className="w-5 h-5 text-[#ffdd00]" />}
              </button>

              <button
                onClick={() => setSettings((prev) => ({ ...prev, contrast: 'dark-mode' }))}
                className={`w-full text-left p-3 border-2 flex items-center justify-between ${
                  settings.contrast === 'dark-mode'
                    ? 'border-[#3880ff] bg-[#1a2332] text-white font-bold'
                    : 'border-[#b1b4b6] bg-[#1a2332] text-neutral-200 hover:bg-[#222e42]'
                } focus:outline-4 focus:outline-[#ffdd00]`}
              >
                <div>
                  <span className="font-bold text-sm block">{t.nightMode}</span>
                  <span className="text-xs text-neutral-400">Dimmed palette for photosensitivity and screen fatigue</span>
                </div>
                {settings.contrast === 'dark-mode' && <Check className="w-5 h-5 text-sky-400" />}
              </button>
            </div>
          </div>

          {/* Toggle Switches */}
          <div className="space-y-3 pt-2 border-t border-[#b1b4b6]">
            <label className="flex items-center justify-between p-2.5 border border-[#d8d8d8] hover:bg-[#f8f8f8] cursor-pointer">
              <span className="text-sm font-semibold text-[#0b0c0c]">{t.dyslexic}</span>
              <input
                type="checkbox"
                checked={settings.dyslexicFont}
                onChange={(e) => setSettings((prev) => ({ ...prev, dyslexicFont: e.target.checked }))}
                className="w-5 h-5 accent-[#002447] cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between p-2.5 border border-[#d8d8d8] hover:bg-[#f8f8f8] cursor-pointer">
              <span className="text-sm font-semibold text-[#0b0c0c]">{t.underline}</span>
              <input
                type="checkbox"
                checked={settings.underlineLinks}
                onChange={(e) => setSettings((prev) => ({ ...prev, underlineLinks: e.target.checked }))}
                className="w-5 h-5 accent-[#002447] cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between p-2.5 border border-[#d8d8d8] hover:bg-[#f8f8f8] cursor-pointer">
              <span className="text-sm font-semibold text-[#0b0c0c]">{t.highFocus}</span>
              <input
                type="checkbox"
                checked={settings.highFocus}
                onChange={(e) => setSettings((prev) => ({ ...prev, highFocus: e.target.checked }))}
                className="w-5 h-5 accent-[#002447] cursor-pointer"
              />
            </label>
          </div>

          {/* Audio Assist */}
          <div className="p-4 bg-[#f3f2f1] border-2 border-[#b1b4b6]">
            <h3 className="text-sm font-bold text-[#0b0c0c] uppercase mb-1 flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-[#002447]" />
              {t.screenReader}
            </h3>
            <p className="text-xs text-[#505a5f] mb-3">
              Uses system speech synthesis to read the page headline, services navigation, and vital public guidance.
            </p>
            {isSpeaking ? (
              <button
                onClick={onStopSpeaking}
                className="inline-flex items-center gap-2 px-4 py-2 bg-[#d4351c] text-white font-bold text-sm hover:bg-[#b12d18] focus:outline-4 focus:outline-[#ffdd00]"
              >
                <VolumeX className="w-4 h-4" />
                {t.stopReading}
              </button>
            ) : (
              <button
                onClick={onSpeakSummary}
                className="inline-flex items-center gap-2 px-4 py-2 bg-[#002447] text-white font-bold text-sm hover:bg-[#00172e] focus:outline-4 focus:outline-[#ffdd00]"
              >
                <Volume2 className="w-4 h-4" />
                {t.readAloud}
              </button>
            )}
          </div>
        </div>

        {/* Footer buttons */}
        <div className="flex items-center justify-between pt-6 mt-6 border-t-2 border-[#b1b4b6]">
          <button
            onClick={resetToDefault}
            className="inline-flex items-center gap-1.5 text-xs text-[#505a5f] hover:text-[#0b0c0c] underline focus:outline-4 focus:outline-[#ffdd00]"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            {t.reset}
          </button>
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-[#005a36] text-white font-bold text-sm hover:bg-[#00472b] focus:outline-4 focus:outline-[#ffdd00]"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
}
