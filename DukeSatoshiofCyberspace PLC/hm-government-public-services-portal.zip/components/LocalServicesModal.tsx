'use client';

import React from 'react';
import { X, MapPin, Trash2, Home, BookOpen, FileCheck, PhoneCall, ExternalLink } from 'lucide-react';

interface LocalServicesModalProps {
  postcode: string;
  isOpen: boolean;
  onClose: () => void;
  lang: 'en' | 'cy';
}

export function LocalServicesModal({ postcode, isOpen, onClose, lang }: LocalServicesModalProps) {
  if (!isOpen) return null;

  const cleanPostcode = postcode.trim().toUpperCase() || 'SW1A 1AA';

  // Smart resolution for mock local authorities
  const getCouncil = (pc: string) => {
    if (pc.startsWith('SW') || pc.startsWith('W1') || pc.startsWith('WC')) {
      return {
        name: 'Westminster City Council',
        region: 'Greater London',
        website: 'https://www.westminster.gov.uk',
        bins: 'Mondays & Thursdays (General) · Wednesdays (Food & Dry Recycling)',
        bandD: '£973.16 per year (Lowest in England)',
        contact: '020 7641 6000',
        hub: 'Mayfair Civic Library & One Stop Centre, 66 Mount St',
      };
    } else if (pc.startsWith('M')) {
      return {
        name: 'Manchester City Council',
        region: 'Greater Manchester',
        website: 'https://www.manchester.gov.uk',
        bins: 'Tuesdays (Black bin) · Alternate Tuesdays (Blue & Brown bins)',
        bandD: '£2,042.89 per year',
        contact: '0161 234 5000',
        hub: 'Manchester Central Library, St Peter’s Square',
      };
    } else if (pc.startsWith('CF')) {
      return {
        name: 'Cardiff Council / Cyngor Caerdydd',
        region: 'Wales / Cymru',
        website: 'https://www.cardiff.gov.uk',
        bins: 'Every Friday (Green food caddy & sack recycling)',
        bandD: '£1,894.40 per year',
        contact: '029 2087 2087',
        hub: 'Cardiff Central Hub, The Hayes, Cardiff',
      };
    } else if (pc.startsWith('EH') || pc.startsWith('G')) {
      return {
        name: 'City of Edinburgh Council',
        region: 'Scotland',
        website: 'https://www.edinburgh.gov.uk',
        bins: 'Wednesday mornings · Food waste weekly',
        bandD: '£1,446.84 per year',
        contact: '0131 200 2323',
        hub: 'Waverley Court Civic Centre, 4 East Market Street',
      };
    } else {
      return {
        name: `${cleanPostcode.slice(0, 2)} Metropolitan & Borough Council`,
        region: 'United Kingdom',
        website: 'https://www.gov.uk/find-local-council',
        bins: 'Alternating weekly collections (Residual / Mixed Recycling)',
        bandD: '£1,920.00 average for Band D property',
        contact: '0300 123 4567',
        hub: 'Town Hall & Civic Services Centre',
      };
    }
  };

  const council = getCouncil(cleanPostcode);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="local-services-heading"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-xl bg-white border-4 border-[#005a36] shadow-2xl p-6 md:p-8 max-h-[90vh] overflow-y-auto">
        <div className="flex items-start justify-between pb-4 border-b-2 border-[#b1b4b6]">
          <div>
            <div className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs font-bold tracking-wide uppercase bg-[#005a36] text-white mb-2">
              <MapPin className="w-3.5 h-3.5" />
              {lang === 'en' ? 'Local Civic Directory' : 'Cyfeiriadur Dinesig Lleol'}
            </div>
            <h2 id="local-services-heading" className="text-2xl font-bold text-[#0b0c0c]">
              {council.name}
            </h2>
            <p className="text-sm text-[#505a5f] mt-1">
              {lang === 'en' ? 'Services registered for postcode: ' : 'Gwasanaethau cofrestredig ar gyfer y cod post: '}
              <strong className="text-[#0b0c0c] bg-yellow-100 px-1.5 py-0.5 border border-yellow-300">
                {cleanPostcode}
              </strong>
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-[#0b0c0c] hover:bg-[#f3f2f1] border border-transparent hover:border-[#0b0c0c] focus:outline-4 focus:outline-[#ffdd00]"
            aria-label="Close local services"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="py-5 space-y-4">
          <div className="p-3 bg-[#f8f8f8] border border-[#d8d8d8] flex items-start gap-3">
            <Trash2 className="w-5 h-5 text-[#005a36] shrink-0 mt-0.5" />
            <div>
              <div className="text-xs font-bold uppercase text-[#505a5f]">
                {lang === 'en' ? 'Rubbish & Bin Collection Dates' : 'Dyddiadau Casglu Sbwriel a Biniau'}
              </div>
              <div className="text-sm font-semibold text-[#0b0c0c] mt-0.5">{council.bins}</div>
            </div>
          </div>

          <div className="p-3 bg-[#f8f8f8] border border-[#d8d8d8] flex items-start gap-3">
            <Home className="w-5 h-5 text-[#002447] shrink-0 mt-0.5" />
            <div>
              <div className="text-xs font-bold uppercase text-[#505a5f]">
                {lang === 'en' ? 'Council Tax & Valuation Band' : 'Treth Gyngor a Band Prisiant'}
              </div>
              <div className="text-sm font-semibold text-[#0b0c0c] mt-0.5">{council.bandD}</div>
              <div className="text-xs text-[#505a5f] mt-0.5">Apply for single person discount (25%) or student exemption.</div>
            </div>
          </div>

          <div className="p-3 bg-[#f8f8f8] border border-[#d8d8d8] flex items-start gap-3">
            <BookOpen className="w-5 h-5 text-[#002447] shrink-0 mt-0.5" />
            <div>
              <div className="text-xs font-bold uppercase text-[#505a5f]">
                {lang === 'en' ? 'Nearest Public Library & Community Hub' : 'Llyfrgell Gyhoeddus Agosaf a Hwb Cymunedol'}
              </div>
              <div className="text-sm font-semibold text-[#0b0c0c] mt-0.5">{council.hub}</div>
              <div className="text-xs text-[#505a5f] mt-0.5">Free public Wi-Fi, computer workstations, and registrar appointment desk.</div>
            </div>
          </div>

          <div className="p-3 bg-[#f8f8f8] border border-[#d8d8d8] flex items-start gap-3">
            <PhoneCall className="w-5 h-5 text-[#002447] shrink-0 mt-0.5" />
            <div>
              <div className="text-xs font-bold uppercase text-[#505a5f]">
                {lang === 'en' ? 'Council Customer Contact Centre' : 'Canolfan Gyswllt Cwsmeriaid y Cyngor'}
              </div>
              <div className="text-sm font-semibold text-[#0b0c0c] mt-0.5">{council.contact}</div>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-4 border-t-2 border-[#b1b4b6]">
          <a
            href={council.website}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 text-xs font-bold text-[#1d70b8] hover:underline"
          >
            Visit council website <ExternalLink className="w-3 h-3" />
          </a>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#005a36] text-white font-bold text-sm hover:bg-[#00472b] focus:outline-4 focus:outline-[#ffdd00]"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
