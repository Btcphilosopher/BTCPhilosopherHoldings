'use client';

import React, { useState } from 'react';
import { X, Lock, CheckCircle2, Shield, ArrowRight, Smartphone } from 'lucide-react';
import { RoyalCrest } from './RoyalCrest';

interface SignInModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'en' | 'cy';
}

export function SignInModal({ isOpen, onClose, lang }: SignInModalProps) {
  const [email, setEmail] = useState('');
  const [signedIn, setSignedIn] = useState(false);
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [step, setStep] = useState<'email' | '2fa' | 'success'>('email');

  if (!isOpen) return null;

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) setStep('2fa');
  };

  const handle2faSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSignedIn(true);
    setStep('success');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="signin-heading"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-md bg-white border-4 border-[#0b0c0c] shadow-2xl p-6 md:p-8">
        <div className="flex items-start justify-between pb-4 border-b-2 border-[#b1b4b6]">
          <div className="flex items-center gap-2.5">
            <RoyalCrest size={28} className="text-[#0b0c0c]" />
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-[#505a5f]">GOV.UK One Login</div>
              <h2 id="signin-heading" className="text-xl font-bold text-[#0b0c0c]">
                {step === 'success' ? 'Signed in successfully' : 'Sign in to your account'}
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#0b0c0c] hover:bg-[#f3f2f1] border border-transparent hover:border-[#0b0c0c] focus:outline-4 focus:outline-[#ffdd00]"
            aria-label="Close sign in"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-6">
          {step === 'email' && (
            <form onSubmit={handleEmailSubmit} className="space-y-4">
              <p className="text-xs text-[#505a5f] leading-relaxed">
                Use your single, secure GOV.UK One Login to access your taxes, benefits, driving licence and passport records.
              </p>
              <div>
                <label htmlFor="signin-email" className="block text-sm font-bold text-[#0b0c0c] mb-1">
                  Enter your email address
                </label>
                <input
                  id="signin-email"
                  type="email"
                  required
                  placeholder="name@example.gov.uk"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border-2 border-[#0b0c0c] text-sm focus:outline-4 focus:outline-[#ffdd00]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#005a36] text-white font-bold text-sm hover:bg-[#00472b] flex items-center justify-center gap-2 focus:outline-4 focus:outline-[#ffdd00]"
              >
                Continue <ArrowRight className="w-4 h-4" />
              </button>

              <div className="pt-3 border-t border-[#d8d8d8] text-xs text-center text-[#505a5f]">
                Need an account? <span className="font-bold text-[#1d70b8] hover:underline cursor-pointer">Create a GOV.UK One Login</span>
              </div>
            </form>
          )}

          {step === '2fa' && (
            <form onSubmit={handle2faSubmit} className="space-y-4">
              <div className="p-3 bg-[#f0f4f9] border border-[#002447] flex items-center gap-2 text-xs">
                <Smartphone className="w-4 h-4 text-[#002447] shrink-0" />
                <span>Security code sent via SMS to your verified mobile phone.</span>
              </div>

              <div>
                <label htmlFor="2fa-input" className="block text-sm font-bold text-[#0b0c0c] mb-1">
                  Enter 6-digit security code
                </label>
                <input
                  id="2fa-input"
                  type="text"
                  maxLength={6}
                  required
                  placeholder="123456"
                  value={twoFactorCode}
                  onChange={(e) => setTwoFactorCode(e.target.value)}
                  className="w-full px-3 py-2 border-2 border-[#0b0c0c] font-mono text-center text-lg tracking-widest focus:outline-4 focus:outline-[#ffdd00]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#005a36] text-white font-bold text-sm hover:bg-[#00472b] flex items-center justify-center gap-2 focus:outline-4 focus:outline-[#ffdd00]"
              >
                Verify & Sign In <Shield className="w-4 h-4" />
              </button>
            </form>
          )}

          {step === 'success' && (
            <div className="text-center py-4 space-y-4">
              <CheckCircle2 className="w-12 h-12 text-[#00703c] mx-auto" />
              <div>
                <h3 className="font-bold text-base text-[#0b0c0c]">Welcome, {email}</h3>
                <p className="text-xs text-[#505a5f] mt-1">
                  Your identity is verified. You can now access personal services with full digital authority.
                </p>
              </div>
              <button
                onClick={onClose}
                className="px-6 py-2 bg-[#002447] text-white font-bold text-sm hover:bg-[#00172e] focus:outline-4 focus:outline-[#ffdd00]"
              >
                Return to Services
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
