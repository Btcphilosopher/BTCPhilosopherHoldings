'use client';

import React, { useState } from 'react';
import {
  X,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  FileText,
  Clock,
  HelpCircle,
} from 'lucide-react';

export type ServiceId =
  | 'passport'
  | 'tax'
  | 'benefits'
  | 'work-pensions'
  | 'driving'
  | 'education'
  | 'departments'
  | 'policies'
  | 'contact';

interface ServiceModalProps {
  serviceId: ServiceId | null;
  onClose: () => void;
  lang: 'en' | 'cy';
}

export function ServiceModal({ serviceId, onClose, lang }: ServiceModalProps) {
  // Simple state for interactive features in the modals
  const [passportType, setPassportType] = useState<'standard' | 'jumbo' | 'child'>('standard');
  const [taxIncome, setTaxIncome] = useState<string>('34000');
  const [benefitHousehold, setBenefitHousehold] = useState<'single' | 'couple' | 'children'>('children');
  const [drivingCheckReg, setDrivingCheckReg] = useState<string>('GB24 GOV');
  const [drivingChecked, setDrivingChecked] = useState<boolean>(false);

  if (!serviceId) return null;

  // Content configurations
  const serviceData: Record<
    ServiceId,
    {
      title: string;
      titleCy: string;
      lead: string;
      leadCy: string;
      badge: string;
      content: React.ReactNode;
    }
  > = {
    passport: {
      title: 'Renew or replace your British passport',
      titleCy: 'Adnewyddu neu ailosod eich pasbort Prydeinig',
      lead: 'Standard adult 34-page passport is £88.50 when you apply online. Standard processing time is 3 weeks.',
      leadCy: 'Mae pasbort safonol i oedolion â 34 tudalen yn £88.50 wrth wneud cais ar-lein. Y cyfnod prosesu safonol yw 3 wythnos.',
      badge: 'HM Passport Office',
      content: (
        <div className="space-y-6 text-[#0b0c0c]">
          <div className="bg-[#f3f2f1] p-4 border-l-4 border-[#002447]">
            <h4 className="font-bold text-base mb-1">Before you start online</h4>
            <ul className="text-sm space-y-1.5 list-disc list-inside text-[#333]">
              <li>You need a digital photo taken against a plain light background</li>
              <li>A credit or debit card for the fee</li>
              <li>Your current passport (you will need to post it to the passport office)</li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-sm uppercase text-[#505a5f] tracking-wider mb-2">Select Passport Type:</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setPassportType('standard')}
                className={`p-3 text-left border-2 ${
                  passportType === 'standard' ? 'border-[#002447] bg-[#f0f4f9] font-bold' : 'border-[#b1b4b6] bg-white'
                }`}
              >
                <div className="text-sm">Standard Adult</div>
                <div className="text-xs text-[#505a5f]">34 pages · £88.50</div>
              </button>
              <button
                type="button"
                onClick={() => setPassportType('jumbo')}
                className={`p-3 text-left border-2 ${
                  passportType === 'jumbo' ? 'border-[#002447] bg-[#f0f4f9] font-bold' : 'border-[#b1b4b6] bg-white'
                }`}
              >
                <div className="text-sm">Frequent Traveller</div>
                <div className="text-xs text-[#505a5f]">54 pages · £100.50</div>
              </button>
              <button
                type="button"
                onClick={() => setPassportType('child')}
                className={`p-3 text-left border-2 ${
                  passportType === 'child' ? 'border-[#002447] bg-[#f0f4f9] font-bold' : 'border-[#b1b4b6] bg-white'
                }`}
              >
                <div className="text-sm">Child Passport</div>
                <div className="text-xs text-[#505a5f]">Under 16 · £57.50</div>
              </button>
            </div>
          </div>

          <div className="p-4 border border-[#b1b4b6] bg-white">
            <h4 className="font-bold text-sm mb-2 flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#002447]" />
              Estimated Processing Turnaround
            </h4>
            <div className="w-full bg-[#e5e5e5] h-3 rounded-none overflow-hidden mb-1.5">
              <div className="bg-[#00703c] h-full w-3/4"></div>
            </div>
            <p className="text-xs text-[#505a5f]">
              97.2% of standard renewals are dispatched within 12 working days. Urgent 1-week Fast Track appointments are also available.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              onClick={() => alert('Starting secure HM Passport Office renewal submission simulator.')}
              className="px-6 py-3 bg-[#005a36] text-white font-bold hover:bg-[#00472b] inline-flex items-center justify-center gap-2"
            >
              Start Online Application <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => alert('Opening tracking status for HM Passport Office submissions.')}
              className="px-5 py-3 border-2 border-[#002447] text-[#002447] font-bold hover:bg-[#f0f4f9] inline-flex items-center justify-center"
            >
              Track an existing passport
            </button>
          </div>
        </div>
      ),
    },
    tax: {
      title: 'Manage your tax & HMRC account',
      titleCy: 'Rheoli eich treth a chyfrif CThEM',
      lead: 'Access your Personal Tax Account, verify your PAYE income tax code, submit Self Assessment, and review National Insurance records.',
      leadCy: 'Cyrchwch eich Cyfrif Treth Personol, gwiriwch eich cod treth incwm TWE, cyflwynwch Hunanasesiad, ac adolygwch gofnodion Yswiriant Gwladol.',
      badge: 'HM Revenue & Customs',
      content: (
        <div className="space-y-6 text-[#0b0c0c]">
          <div className="p-4 bg-[#f0f4f9] border border-[#002447]">
            <h4 className="font-bold text-base text-[#002447] mb-1">Quick Income Tax & NI Calculator Estimate</h4>
            <p className="text-xs text-[#505a5f] mb-3">
              Standard tax year personal allowance is £12,570. 20% basic rate applies up to £50,270.
            </p>
            <div className="flex items-center gap-3">
              <label htmlFor="tax-input" className="text-sm font-semibold whitespace-nowrap">
                Gross Salary (£):
              </label>
              <input
                id="tax-input"
                type="number"
                value={taxIncome}
                onChange={(e) => setTaxIncome(e.target.value)}
                className="px-3 py-1.5 border-2 border-[#0b0c0c] bg-white font-mono text-sm w-36"
              />
            </div>
            {Number(taxIncome) > 0 && (
              <div className="mt-3 pt-3 border-t border-[#b1b4b6] grid grid-cols-3 gap-2 text-center">
                <div className="bg-white p-2 border border-[#d8d8d8]">
                  <span className="block text-[11px] text-[#505a5f]">Income Tax</span>
                  <span className="font-bold font-mono text-sm text-[#d4351c]">
                    £
                    {Math.max(
                      0,
                      Math.round(
                        (Math.min(Number(taxIncome), 50270) - 12570 > 0 ? (Math.min(Number(taxIncome), 50270) - 12570) * 0.2 : 0) +
                          (Number(taxIncome) > 50270 ? (Number(taxIncome) - 50270) * 0.4 : 0)
                      )
                    ).toLocaleString()}
                  </span>
                </div>
                <div className="bg-white p-2 border border-[#d8d8d8]">
                  <span className="block text-[11px] text-[#505a5f]">National Insurance (8%)</span>
                  <span className="font-bold font-mono text-sm text-[#002447]">
                    £
                    {Math.max(
                      0,
                      Math.round((Math.min(Number(taxIncome), 50270) - 12570 > 0 ? (Math.min(Number(taxIncome), 50270) - 12570) * 0.08 : 0))
                    ).toLocaleString()}
                  </span>
                </div>
                <div className="bg-white p-2 border border-[#d8d8d8]">
                  <span className="block text-[11px] text-[#505a5f]">Estimated Take-Home</span>
                  <span className="font-bold font-mono text-sm text-[#00703c]">
                    £
                    {Math.max(
                      0,
                      Math.round(
                        Number(taxIncome) -
                          ((Math.min(Number(taxIncome), 50270) - 12570 > 0 ? (Math.min(Number(taxIncome), 50270) - 12570) * 0.2 : 0) +
                            (Number(taxIncome) > 50270 ? (Number(taxIncome) - 50270) * 0.4 : 0) +
                            (Math.min(Number(taxIncome), 50270) - 12570 > 0 ? (Math.min(Number(taxIncome), 50270) - 12570) * 0.08 : 0))
                      )
                    ).toLocaleString()}
                  </span>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3 border border-[#b1b4b6]">
              <h5 className="font-bold text-sm">Self Assessment Tax Return</h5>
              <p className="text-xs text-[#505a5f] mt-1">Next filing deadline: 31 January midnight for online submissions.</p>
              <button
                onClick={() => alert('Redirecting to HMRC Self Assessment online dashboard.')}
                className="mt-3 text-xs font-bold text-[#1d70b8] hover:underline flex items-center gap-1"
              >
                Sign in to file return <ExternalLink className="w-3 h-3" />
              </button>
            </div>
            <div className="p-3 border border-[#b1b4b6]">
              <h5 className="font-bold text-sm">Check National Insurance Record</h5>
              <p className="text-xs text-[#505a5f] mt-1">See gaps in your NI contributions to ensure you qualify for full State Pension.</p>
              <button
                onClick={() => alert('Viewing your 35-year qualifying State Pension contribution record.')}
                className="mt-3 text-xs font-bold text-[#1d70b8] hover:underline flex items-center gap-1"
              >
                View NI years <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      ),
    },
    benefits: {
      title: 'Find benefits, support and Universal Credit',
      titleCy: 'Canfod budd-daliadau, cymorth a Chredyd Cynhwysol',
      lead: 'Use independent eligibility tools to check support for housing, living costs, children, disability and caring responsibilities.',
      leadCy: 'Defnyddiwch offer cymhwysedd annibynnol i wirio cymorth ar gyfer tai, costau byw, plant, anabledd a chyfrifoldebau gofalu.',
      badge: 'Department for Work and Pensions',
      content: (
        <div className="space-y-5 text-[#0b0c0c]">
          <div className="border border-[#b1b4b6] p-4 bg-white">
            <h4 className="font-bold text-sm mb-3">What is your current household situation?</h4>
            <div className="grid grid-cols-3 gap-2 mb-4">
              {[
                { id: 'single', label: 'Single adult' },
                { id: 'couple', label: 'Couple / Partner' },
                { id: 'children', label: 'With dependent children' },
              ].map((h) => (
                <button
                  key={h.id}
                  type="button"
                  onClick={() => setBenefitHousehold(h.id as any)}
                  className={`p-2.5 text-xs text-center border-2 ${
                    benefitHousehold === h.id ? 'border-[#002447] bg-[#f0f4f9] font-bold' : 'border-[#b1b4b6]'
                  }`}
                >
                  {h.label}
                </button>
              ))}
            </div>

            <div className="space-y-3 bg-[#f8f8f8] p-3 border border-[#d8d8d8]">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#00703c] shrink-0 mt-0.5" />
                <div className="text-xs">
                  <span className="font-bold">Universal Credit:</span> You may qualify if on low income or out of work, with standard monthly allowance paid directly into your account.
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#00703c] shrink-0 mt-0.5" />
                <div className="text-xs">
                  <span className="font-bold">Council Tax Reduction:</span> Apply directly to your local council to receive up to 100% discount on council tax bills.
                </div>
              </div>
              {benefitHousehold === 'children' && (
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#00703c] shrink-0 mt-0.5" />
                  <div className="text-xs">
                    <span className="font-bold">Child Benefit:</span> £25.60 per week for eldest or only child; £16.95 for each additional child.
                  </div>
                </div>
              )}
            </div>
          </div>

          <button
            onClick={() => alert('Opening full government-approved benefits assessment calculator.')}
            className="w-full py-3 bg-[#005a36] text-white font-bold text-sm hover:bg-[#00472b] flex items-center justify-center gap-2"
          >
            Launch Full Benefits Eligibility Calculator <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      ),
    },
    'work-pensions': {
      title: 'Work, employment rights and State Pension',
      titleCy: 'Gwaith, hawliau cyflogaeth a Phensiwn y Wladwriaeth',
      lead: 'Explore job vacancies with Find a Job, understand statutory sick pay and holiday rights, and forecast your State Pension age and weekly payment.',
      leadCy: 'Archwiliwch swyddi gwag gyda Dod o Hyd i Swydd, deallwch dâl salwch statudol a hawliau gwyliau, a rhagwelwch eich oedran Pensiwn y Wladwriaeth.',
      badge: 'DWP & Advisory Conciliation',
      content: (
        <div className="space-y-5 text-[#0b0c0c]">
          <div className="p-4 bg-[#f0f4f9] border border-[#002447]">
            <h4 className="font-bold text-sm text-[#002447] mb-2">New State Pension Forecast (2026/27)</h4>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-[#002447]">£221.20</span>
              <span className="text-xs text-[#505a5f]">per week (full rate with 35 qualifying years)</span>
            </div>
            <p className="text-xs text-[#505a5f] mt-2">
              Default State Pension age is currently 66, rising gradually to 67 between 2026 and 2028.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold text-sm">Key Workplace & Employment Tools:</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div className="p-3 border border-[#b1b4b6] bg-white">
                <span className="font-bold text-sm block">Find a Job Service</span>
                <span className="text-xs text-[#505a5f]">Over 140,000 verified public and private UK vacancies</span>
                <button
                  onClick={() => alert('Opening Find a Job portal.')}
                  className="mt-2 text-xs font-bold text-[#1d70b8] hover:underline block"
                >
                  Search vacancies &rarr;
                </button>
              </div>
              <div className="p-3 border border-[#b1b4b6] bg-white">
                <span className="font-bold text-sm block">Redundancy & Notice Pay</span>
                <span className="text-xs text-[#505a5f]">Calculate statutory redundancy entitlements based on age and service</span>
                <button
                  onClick={() => alert('Calculating statutory redundancy entitlement.')}
                  className="mt-2 text-xs font-bold text-[#1d70b8] hover:underline block"
                >
                  Calculate entitlement &rarr;
                </button>
              </div>
            </div>
          </div>
        </div>
      ),
    },
    driving: {
      title: 'Driving, licences and vehicle services',
      titleCy: 'Gyrru, trwyddedau a gwasanaethau cerbydau',
      lead: 'Renew your photocard driving licence, check MOT history, pay vehicle tax (road tax), and book your practical driving or theory test.',
      leadCy: 'Adnewyddu eich trwydded yrru cerdyn llun, gwirio hanes MOT, talu treth cerbyd (treth ffordd), ac archebu eich prawf gyrru ymarferol neu theori.',
      badge: 'Driver and Vehicle Standards Agency (DVLA)',
      content: (
        <div className="space-y-5 text-[#0b0c0c]">
          <div className="border border-[#b1b4b6] p-4 bg-white">
            <h4 className="font-bold text-sm mb-2">Check Vehicle MOT & Tax Status</h4>
            <div className="flex gap-2">
              <input
                type="text"
                value={drivingCheckReg}
                onChange={(e) => setDrivingCheckReg(e.target.value.toUpperCase())}
                placeholder="Enter UK Registration (e.g. GB24 GOV)"
                className="px-3 py-2 border-2 border-[#0b0c0c] bg-yellow-50 font-mono font-bold tracking-wider text-sm flex-1 uppercase"
              />
              <button
                onClick={() => setDrivingChecked(true)}
                className="px-4 py-2 bg-[#005a36] text-white font-bold text-sm hover:bg-[#00472b]"
              >
                Check
              </button>
            </div>

            {drivingChecked && (
              <div className="mt-4 p-3 bg-[#e8f5e9] border border-[#2e7d32] space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-[#1b5e20]">
                  <span>Registration: {drivingCheckReg}</span>
                  <span className="px-2 py-0.5 bg-[#2e7d32] text-white uppercase text-[10px]">Tax & MOT Valid</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-[#333]">
                  <div>Vehicle Tax Expiry: 01 March 2027</div>
                  <div>MOT Test Expiry: 14 October 2027</div>
                  <div>Fuel Type: Hybrid Electric</div>
                  <div>CO₂ Emissions: 88 g/km</div>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => alert('Starting DVLA Photocard Licence Renewal (takes ~5 minutes).')}
              className="p-3 border border-[#b1b4b6] bg-white text-left hover:bg-[#f8f8f8]"
            >
              <span className="font-bold block text-sm text-[#002447]">Renew photocard licence (10 yrs)</span>
              <span className="text-[#505a5f] mt-1 block">£14 fee online. Arrives in 1 week.</span>
            </button>
            <button
              onClick={() => alert('Opening DVSA Driving Test booking system.')}
              className="p-3 border border-[#b1b4b6] bg-white text-left hover:bg-[#f8f8f8]"
            >
              <span className="font-bold block text-sm text-[#002447]">Book driving or theory test</span>
              <span className="text-[#505a5f] mt-1 block">Theory test £23 · Practical car test £62</span>
            </button>
          </div>
        </div>
      ),
    },
    education: {
      title: 'Education, childcare, apprenticeships and schools',
      titleCy: 'Addysg, gofal plant, prentisiaethau ac ysgolion',
      lead: 'Apply for 15 or 30 hours free childcare, find school admissions and performance tables, apply for student finance, and find apprenticeships.',
      leadCy: 'Gwnewch gais am 15 neu 30 awr o ofal plant am ddim, dewch o hyd i fynediad i ysgolion a thablau perfformiad, gwnewch gais am gyllid myfyrwyr.',
      badge: 'Department for Education',
      content: (
        <div className="space-y-4 text-[#0b0c0c]">
          <div className="p-4 bg-[#f0f4f9] border border-[#002447]">
            <h4 className="font-bold text-sm text-[#002447] mb-1">Childcare Expansion Support</h4>
            <p className="text-xs text-[#333] leading-relaxed">
              Working parents of children aged 9 months to 4 years old can now access 15 to 30 hours of government-funded childcare per week during term time (38 weeks a year).
            </p>
          </div>

          <div className="space-y-2">
            {[
              {
                title: 'Apply for Student Finance',
                desc: 'Tuition fee loans and maintenance loans for undergraduate and postgraduate studies in the UK.',
              },
              {
                title: 'Find an Apprenticeship',
                desc: 'Earn while you learn with accredited qualifications from level 2 through to master’s degree level.',
              },
              {
                title: 'Check School Term Dates & Closures',
                desc: 'Check local school terms, inset days, and inspection reports by Ofsted / Estyn.',
              },
            ].map((item, idx) => (
              <div key={idx} className="p-3 border border-[#b1b4b6] bg-white flex items-center justify-between">
                <div>
                  <h5 className="font-bold text-sm">{item.title}</h5>
                  <p className="text-xs text-[#505a5f]">{item.desc}</p>
                </div>
                <button
                  onClick={() => alert(`Opening ${item.title} portal.`)}
                  className="px-3 py-1.5 border border-[#002447] text-xs font-bold text-[#002447] hover:bg-[#002447] hover:text-white shrink-0 ml-3"
                >
                  Apply
                </button>
              </div>
            ))}
          </div>
        </div>
      ),
    },
    departments: {
      title: 'Departments, agencies and public bodies',
      titleCy: 'Adrannau, asiantaethau a chyrff cyhoeddus',
      lead: 'Central government departments, non-ministerial departments, and executive agencies of the United Kingdom.',
      leadCy: 'Adrannau llywodraeth ganolog, adrannau anweinidogol, ac asiantaethau gweithredol y Deyrnas Unedig.',
      badge: 'Cabinet Office Directory',
      content: (
        <div className="space-y-3 text-xs">
          {[
            { name: 'HM Treasury', desc: 'The government’s economic and finance ministry maintaining control over public spending.' },
            { name: 'Home Office', desc: 'Passports, immigration, visas, counter-terrorism, and policing across England and Wales.' },
            { name: 'Department for Work and Pensions (DWP)', desc: 'Welfare, pensions, child maintenance policy, and employment services.' },
            { name: 'HM Revenue and Customs (HMRC)', desc: 'Collecting taxes, customs duties, payment of child benefits and enforcing national minimum wage.' },
            { name: 'Department for Transport (DfT)', desc: 'Connecting communities through roads, railways, ports, airports, and EV charging infrastructure.' },
            { name: 'Department for Health and Social Care (DHSC)', desc: 'Setting healthcare policy, funding the NHS, and public health directives.' },
          ].map((dept, i) => (
            <div key={i} className="p-3 border border-[#d8d8d8] bg-white hover:border-[#002447]">
              <div className="font-bold text-sm text-[#002447]">{dept.name}</div>
              <div className="text-[#505a5f] mt-0.5">{dept.desc}</div>
            </div>
          ))}
        </div>
      ),
    },
    policies: {
      title: 'Policies, publications and public consultations',
      titleCy: 'Polisïau, cyhoeddiadau ac ymgynghoriadau cyhoeddus',
      lead: 'Government white papers, consultation responses, statistical releases, and official ministerial statements.',
      leadCy: 'Papurau gwyn y llywodraeth, ymatebion i ymgynghoriadau, datganiadau ystadegol, a datganiadau gweinidogol swyddogol.',
      badge: 'National Archives & Legislation',
      content: (
        <div className="space-y-3 text-xs">
          <div className="p-3 border-l-4 border-[#005a36] bg-[#f0f4f9]">
            <span className="font-bold block text-sm">Open Public Consultation: National Clean Energy Transition</span>
            <span className="text-[#505a5f]">Closes 15 December 2026 · 1,420 responses submitted to date</span>
          </div>
          <div className="p-3 border-l-4 border-[#002447] bg-white">
            <span className="font-bold block text-sm">Statutory Guidance: Digital Public Service Accessibility Standards</span>
            <span className="text-[#505a5f]">Mandates EN 301 549 and WCAG 2.2 AA conformance across all public sector apps.</span>
          </div>
          <div className="p-3 border-l-4 border-[#002447] bg-white">
            <span className="font-bold block text-sm">Official Statistics: Quarterly Labour Market Trends & Wages</span>
            <span className="text-[#505a5f]">Published by Office for National Statistics (ONS).</span>
          </div>
        </div>
      ),
    },
    contact: {
      title: 'Contact government services & emergency help',
      titleCy: 'Cysylltu â gwasanaethau’r llywodraeth a chymorth brys',
      lead: 'Official telephone helplines, British Sign Language (BSL) video relay, and accessible communication channels.',
      leadCy: 'Llinellau cymorth ffôn swyddogol, trosglwyddydd fideo Iaith Arwyddion Prydain (BSL), a sianeli cyfathrebu hygyrch.',
      badge: 'Public Contact Directory',
      content: (
        <div className="space-y-3 text-xs">
          <div className="p-3 border border-[#d4351c] bg-[#fff5f5]">
            <div className="font-bold text-sm text-[#d4351c] flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" /> Emergencies (Police, Ambulance, Fire, Coastguard)
            </div>
            <div className="text-sm font-bold mt-1 text-[#0b0c0c]">Call 999 or 112 (Text 18000 for emergency text relay)</div>
          </div>
          <div className="p-3 border border-[#b1b4b6] bg-white">
            <div className="font-bold text-sm text-[#002447]">Non-Emergency NHS Medical Advice</div>
            <div className="text-sm font-semibold mt-1">Call 111 (Free 24 hours a day, 365 days a year)</div>
          </div>
          <div className="p-3 border border-[#b1b4b6] bg-white">
            <div className="font-bold text-sm text-[#002447]">HMRC Tax Helplines & Webchat</div>
            <div className="text-sm font-semibold mt-1">Telephone: 0300 200 3300 · Monday to Friday 8am to 6pm</div>
          </div>
          <div className="p-3 border border-[#b1b4b6] bg-white">
            <div className="font-bold text-sm text-[#002447]">Relay UK & BSL Video Relay Service</div>
            <div className="text-sm font-semibold mt-1">Dial 18001 before any UK government telephone number</div>
          </div>
        </div>
      ),
    },
  };

  const current = serviceData[serviceId];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="service-modal-heading"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-2xl bg-white border-4 border-[#002447] shadow-2xl p-6 md:p-8 max-h-[90vh] overflow-y-auto">
        <div className="flex items-start justify-between pb-4 border-b-2 border-[#b1b4b6]">
          <div>
            <div className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs font-bold tracking-wide uppercase bg-[#002447] text-white mb-2">
              <ShieldCheck className="w-3.5 h-3.5" />
              {current.badge}
            </div>
            <h2 id="service-modal-heading" className="text-2xl font-bold text-[#0b0c0c] leading-tight">
              {lang === 'cy' ? current.titleCy : current.title}
            </h2>
            <p className="text-sm text-[#505a5f] mt-1.5 leading-relaxed">
              {lang === 'cy' ? current.leadCy : current.lead}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-[#0b0c0c] hover:bg-[#f3f2f1] border border-transparent hover:border-[#0b0c0c] focus:outline-4 focus:outline-[#ffdd00] shrink-0 ml-4"
            aria-label="Close service details"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="py-6">{current.content}</div>

        <div className="flex items-center justify-between pt-4 border-t-2 border-[#b1b4b6]">
          <span className="text-xs text-[#505a5f] flex items-center gap-1">
            <HelpCircle className="w-3.5 h-3.5" /> Official Gov Service Guidance
          </span>
          <button
            onClick={onClose}
            className="px-6 py-2 bg-[#002447] text-white font-bold text-sm hover:bg-[#00172e] focus:outline-4 focus:outline-[#ffdd00]"
          >
            Close Window
          </button>
        </div>
      </div>
    </div>
  );
}
