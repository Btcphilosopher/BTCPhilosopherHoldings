import { NextRequest, NextResponse } from "next/server";
import { exec } from "child_process";
import path from "path";
import util from "util";

const execPromise = util.promisify(exec);

export async function POST(req: NextRequest) {
  let command = "experiment knowledge-problem";
  try {
    const body = await req.json();
    if (body.command) command = body.command;

    const projectRoot = path.join(process.cwd(), "hayekian-proof-of-knowledge");
    const pythonPath = path.join(projectRoot, "src");

    const fullCmd = `PYTHONPATH="${pythonPath}" python3 -m hayekian.cli.main ${command}`;

    const { stdout, stderr } = await execPromise(fullCmd, {
      cwd: projectRoot,
      timeout: 30000
    });

    return NextResponse.json({
      success: true,
      command: fullCmd,
      output: stdout || stderr
    });
  } catch (err: any) {
    return NextResponse.json({
      success: false,
      command: command,
      error: err.message,
      output: err.stdout || err.stderr || err.message
    }, { status: 500 });
  }
}
