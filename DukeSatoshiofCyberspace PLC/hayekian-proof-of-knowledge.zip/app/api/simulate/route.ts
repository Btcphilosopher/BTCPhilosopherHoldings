import { NextRequest, NextResponse } from "next/server";
import { exec } from "child_process";
import path from "path";
import util from "util";

const execPromise = util.promisify(exec);

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const experimentName = body.experimentName || "knowledge-problem";
    const duration = body.duration || 150;
    const seed = body.seed || 42;
    const priceFlexibility = body.priceFlexibility ?? 1.0;
    const latency = body.latency ?? 0;

    const projectRoot = path.join(process.cwd(), "hayekian-proof-of-knowledge");
    const pythonPath = path.join(projectRoot, "src");

    const code = `
import json
from hayekian.counterfactual.scenario_comparator import CounterfactualComparator
from hayekian.simulation.scenarios import build_canonical_scenario
from hayekian.core.enums import SimulationMode

comparator = CounterfactualComparator(scenario_name="${experimentName}", duration=${duration}, seed=${seed})
results = comparator.run_comparison()

# Add extra details
engine = build_canonical_scenario("${experimentName}", SimulationMode.DECENTRALISED, ${seed})
res = engine.run(${duration})

output = {
    "comparison": results,
    "decentralised_run": res,
    "knowledge_graph": engine.world.knowledge_graph.to_dict(),
    "proofs_of_knowledge": engine.world.proofs_of_knowledge[-20:],
    "discoveries": [d.to_dict() for d in engine.discovery_engine.discovered_opportunities],
    "shocks": engine.world.active_shocks
}
print(json.dumps(output))
`;

    const { stdout, stderr } = await execPromise(`PYTHONPATH="${pythonPath}" python3 -c '${code.replace(/'/g, "'\\''")}'`, {
      cwd: projectRoot,
      timeout: 30000
    });

    const parsed = JSON.parse(stdout);
    return NextResponse.json({ success: true, data: parsed });
  } catch (err: any) {
    console.error("Simulation Execution Error:", err);
    return NextResponse.json({ success: false, error: err.message || "Failed to execute simulation" }, { status: 500 });
  }
}
