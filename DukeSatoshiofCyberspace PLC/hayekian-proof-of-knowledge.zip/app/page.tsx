'use client';

import React, { useState, useEffect } from 'react';
import { HayekianHeader } from '../components/HayekianHeader';
import { SimulationWorkbench } from '../components/SimulationWorkbench';
import { CounterfactualCharts } from '../components/CounterfactualCharts';
import { KnowledgeGraphViewer } from '../components/KnowledgeGraphViewer';
import { EpistemicAuditExplorer } from '../components/EpistemicAuditExplorer';
import { ProofOfKnowledgeLedger } from '../components/ProofOfKnowledgeLedger';
import { CliTerminalBridge } from '../components/CliTerminalBridge';

export default function HayekianProofPage() {
  const [activeTab, setActiveTab] = useState('workbench');
  const [running, setRunning] = useState(false);
  const [simulationData, setSimulationData] = useState<any>(null);

  const handleRunSimulation = async (params: any) => {
    setRunning(true);
    try {
      const res = await fetch('/api/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const json = await res.json();
      if (json.success) {
        setSimulationData(json.data);
      } else {
        console.error("Simulation error:", json.error);
      }
    } catch (err) {
      console.error("Network error running simulation:", err);
    } finally {
      setRunning(false);
    }
  };

  // Auto-run baseline simulation on initial mount
  useEffect(() => {
    let active = true;
    async function init() {
      setRunning(true);
      try {
        const res = await fetch('/api/simulate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ experimentName: 'knowledge-problem', duration: 150, seed: 42 }),
        });
        const json = await res.json();
        if (active && json.success) {
          setSimulationData(json.data);
        }
      } catch (err) {
        console.error("Initialization simulation error:", err);
      } finally {
        if (active) setRunning(false);
      }
    }
    init();
    return () => { active = false; };
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      <HayekianHeader activeTab={activeTab} setActiveTab={setActiveTab} running={running} />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'workbench' && (
          <SimulationWorkbench
            onRunSimulation={handleRunSimulation}
            running={running}
            simulationData={simulationData}
          />
        )}

        {activeTab === 'counterfactual' && (
          <CounterfactualCharts comparisonData={simulationData?.comparison} />
        )}

        {activeTab === 'knowledge-graph' && (
          <KnowledgeGraphViewer graphData={simulationData?.knowledge_graph} />
        )}

        {activeTab === 'epistemic-audit' && (
          <EpistemicAuditExplorer simulationData={simulationData} />
        )}

        {activeTab === 'proof-ledger' && (
          <ProofOfKnowledgeLedger simulationData={simulationData} />
        )}

        {activeTab === 'cli-terminal' && (
          <CliTerminalBridge />
        )}
      </main>

      <footer className="border-t border-slate-800 bg-slate-900/60 py-6 text-center text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>HAYEKIAN PROOF-OF-KNOWLEDGE — Computational Epistemics Engine</span>
          <span>Based on F.A. Hayek, &quot;The Use of Knowledge in Society&quot; (1945)</span>
        </div>
      </footer>
    </div>
  );
}
