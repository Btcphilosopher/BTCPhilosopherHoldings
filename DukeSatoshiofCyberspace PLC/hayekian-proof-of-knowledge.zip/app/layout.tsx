import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Hayekian Proof-of-Knowledge',
  description: 'A production-grade computational laboratory for measuring, tracing, simulating, and analyzing dispersed knowledge and price coordination.',
  openGraph: {
    title: 'Hayekian Proof-of-Knowledge',
    description: 'A production-grade computational laboratory for measuring, tracing, simulating, and analyzing dispersed knowledge and price coordination.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Hayekian Proof-of-Knowledge',
    description: 'A production-grade computational laboratory for measuring, tracing, simulating, and analyzing dispersed knowledge and price coordination.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
