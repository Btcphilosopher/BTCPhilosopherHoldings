from dataclasses import dataclass, field
from decimal import Decimal
from typing import Dict, Any, Optional
from hayekian.core.ids import generate_id

@dataclass
class Action:
    agent_id: str
    action_type: str  # BUY_ORDER, SELL_ORDER, PRODUCE, CONSUME, REALLOCATE, DISCOVER
    target: str
    quantity: float
    timestamp: int
    plan_id: Optional[str] = None
    location: str = "GLOBAL"
    context: Dict[str, Any] = field(default_factory=dict)
    action_id: str = field(default_factory=lambda: generate_id("act"))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action_id": self.action_id,
            "agent_id": self.agent_id,
            "action_type": self.action_type,
            "target": self.target,
            "quantity": self.quantity,
            "timestamp": self.timestamp,
            "plan_id": self.plan_id,
            "location": self.location,
            "context": self.context
        }
