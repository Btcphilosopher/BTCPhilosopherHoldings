from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List
from hayekian.core.ids import generate_id

@dataclass
class KnowledgeCompressionEvent:
    source_agent_id: str
    source_knowledge_ids: list[str]
    compressed_signal_id: str
    recipient_agent_id: Optional[str]  # None if broadcast to market
    raw_information_volume_bytes: int
    compressed_information_volume_bytes: int
    information_loss_ratio: float  # 0.0 to 1.0 (1.0 = full detail lost)
    information_retained_ratio: float  # 1.0 - loss_ratio
    decision_relevance: float  # 0.0 to 1.0 (How actionable the compressed signal is)
    timestamp: int
    event_id: str = field(default_factory=lambda: generate_id("cmp"))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "source_agent_id": self.source_agent_id,
            "source_knowledge_ids": self.source_knowledge_ids,
            "compressed_signal_id": self.compressed_signal_id,
            "recipient_agent_id": self.recipient_agent_id,
            "raw_information_volume_bytes": self.raw_information_volume_bytes,
            "compressed_information_volume_bytes": self.compressed_information_volume_bytes,
            "information_loss_ratio": self.information_loss_ratio,
            "information_retained_ratio": self.information_retained_ratio,
            "decision_relevance": self.decision_relevance,
            "timestamp": self.timestamp
        }

class KnowledgeCompressionModel:
    """
    Models how 1000 heterogeneous local observations (e.g. factory fires, component delays)
    are compressed by market actions into a single high-density PriceSignal.
    """
    @staticmethod
    def compress_to_price_signal(
        source_agent_id: str,
        local_claims: list[Any],
        price_signal_id: str,
        tick: int
    ) -> KnowledgeCompressionEvent:
        raw_volume = sum(len(str(c.content)) for c in local_claims) if local_claims else 500
        compressed_volume = 32  # e.g., "PRICE: 142.50, ASSET: COPPER"
        loss_ratio = max(0.0, min(0.99, 1.0 - (compressed_volume / max(1, raw_volume))))
        
        return KnowledgeCompressionEvent(
            source_agent_id=source_agent_id,
            source_knowledge_ids=[getattr(c, "knowledge_id", str(i)) for i, c in enumerate(local_claims)],
            compressed_signal_id=price_signal_id,
            recipient_agent_id=None,
            raw_information_volume_bytes=raw_volume,
            compressed_information_volume_bytes=compressed_volume,
            information_loss_ratio=loss_ratio,
            information_retained_ratio=1.0 - loss_ratio,
            decision_relevance=0.92,  # Price signal is extremely actionable
            timestamp=tick
        )
