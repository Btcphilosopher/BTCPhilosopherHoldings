from dataclasses import dataclass, field
from typing import Dict, Any, List

@dataclass
class EpistemicState:
    agent_id: str
    known_facts_count: int = 0
    perceived_uncertainty: float = 0.5  # 0.0 (certain) to 1.0 (pure noise)
    hypotheses: List[Dict[str, Any]] = field(default_factory=list)
