import numpy as np

def calculate_entropy(probabilities: list[float]) -> float:
    probs = np.array([p for p in probabilities if p > 0])
    if len(probs) == 0:
        return 0.0
    return float(-np.sum(probs * np.log2(probs)))
