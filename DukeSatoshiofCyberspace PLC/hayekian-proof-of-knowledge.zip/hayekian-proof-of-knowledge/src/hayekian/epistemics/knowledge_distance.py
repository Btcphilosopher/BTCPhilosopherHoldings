from dataclasses import dataclass
from typing import Dict, Any, List

def compute_knowledge_distance(
    agent_info_set: Any,
    required_decision_knowledge: Dict[str, Any],
    current_tick: int,
    agent_location: str,
    decision_location: str
) -> float:
    """
    Computes distance between knowledge possessed by agent and knowledge relevant to decision.
    Distance increases when:
    - relevant knowledge is unavailable
    - knowledge is stale
    - geographically distant
    - contradicted / high uncertainty
    """
    distance = 0.0

    # Geographic distance penalty
    if agent_location != decision_location:
        distance += 2.0

    # Knowledge presence check
    domain = required_decision_knowledge.get("domain", "")
    claims = agent_info_set.knows_about(domain, current_tick) if hasattr(agent_info_set, "knows_about") else []

    if not claims:
        distance += 5.0
    else:
        # Check staleness
        best_claim = max(claims, key=lambda c: c.timestamp)
        age = current_tick - best_claim.timestamp
        distance += min(3.0, age * 0.1)

        # Check uncertainty / confidence
        confidence_penalty = (1.0 - best_claim.confidence) * 2.0
        distance += confidence_penalty

    return round(distance, 4)
