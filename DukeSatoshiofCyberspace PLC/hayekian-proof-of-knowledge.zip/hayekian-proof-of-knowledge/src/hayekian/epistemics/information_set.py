from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from hayekian.knowledge.knowledge_claim import KnowledgeClaim
from hayekian.core.errors import TemporalBoundaryViolationError, KnowledgeIsolationError

@dataclass
class InformationSet:
    agent_id: str
    claims: Dict[str, KnowledgeClaim] = field(default_factory=dict)
    local_observations: List[Dict[str, Any]] = field(default_factory=list)
    observed_price_signals: List[Dict[str, Any]] = field(default_factory=list)
    observed_profit_loss: List[Dict[str, Any]] = field(default_factory=list)

    def add_claim(self, claim: KnowledgeClaim, current_tick: int):
        if claim.timestamp > current_tick:
            raise TemporalBoundaryViolationError(
                f"Future claim timestamp {claim.timestamp} leaks into current simulation tick {current_tick}"
            )
        self.claims[claim.knowledge_id] = claim

    def get_valid_claims(self, current_tick: int) -> List[KnowledgeClaim]:
        return [c for c in self.claims.values() if c.is_valid_at(current_tick)]

    def knows_about(self, domain: str, current_tick: int) -> List[KnowledgeClaim]:
        return [
            c for c in self.get_valid_claims(current_tick)
            if c.domain.upper() == domain.upper()
        ]

    def record_price_signal(self, signal_dict: Dict[str, Any], current_tick: int):
        if signal_dict.get("timestamp", 0) > current_tick:
            raise TemporalBoundaryViolationError("Cannot record future price signal")
        self.observed_price_signals.append(signal_dict)

    def to_dict(self, current_tick: int) -> Dict[str, Any]:
        valid = self.get_valid_claims(current_tick)
        return {
            "agent_id": self.agent_id,
            "claims_count": len(valid),
            "domains": list(set(c.domain for c in valid)),
            "price_signals_received": len(self.observed_price_signals),
            "claims": [c.to_dict() for c in valid]
        }
