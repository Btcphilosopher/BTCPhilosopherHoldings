from dataclasses import dataclass, field
from typing import Dict, Any, List
from hayekian.core.ids import generate_id

@dataclass
class BeliefState:
    agent_id: str
    price_expectations: Dict[str, float] = field(default_factory=dict)
    scarcity_estimates: Dict[str, float] = field(default_factory=dict)
    supplier_reliability: Dict[str, float] = field(default_factory=dict)
    demand_forecasts: Dict[str, float] = field(default_factory=dict)

    def update_from_price_signal(self, asset: str, price: float, previous_price: float):
        if previous_price > 0:
            pct_change = (price - previous_price) / previous_price
            # Increase perceived scarcity if price goes up
            current_scarcity = self.scarcity_estimates.get(asset, 0.5)
            self.scarcity_estimates[asset] = max(0.0, min(1.0, current_scarcity + pct_change * 0.5))
            # Update price expectation
            self.price_expectations[asset] = price * (1.0 + pct_change * 0.2)

    def update_from_profit_loss(self, plan_id: str, profit_or_loss: float):
        # High profit validates belief; loss signals belief failure
        for asset in self.price_expectations:
            if profit_or_loss < 0:
                # Surprise error adjustment
                self.price_expectations[asset] *= 0.9
