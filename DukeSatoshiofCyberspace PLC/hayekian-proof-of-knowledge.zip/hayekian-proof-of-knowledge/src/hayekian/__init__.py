# src/hayekian/__init__.py
"""
HAYEKIAN PROOF-OF-KNOWLEDGE
A Computational Laboratory for Dispersed Knowledge and Price Signals.
"""

__version__ = "0.1.0"
