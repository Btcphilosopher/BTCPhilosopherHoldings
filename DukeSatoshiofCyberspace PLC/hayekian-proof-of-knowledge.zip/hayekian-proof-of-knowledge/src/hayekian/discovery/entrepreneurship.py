import random
from decimal import Decimal
from typing import List, Optional, Dict, Any
from hayekian.agents.agent import Agent
from hayekian.discovery.opportunity import Opportunity
from hayekian.core.enums import AgentType

class DiscoveryEngine:
    """
    Identifies when agents discover something NOT previously represented in the global model.
    Models true Knowledge Creation under uncertainty.
    """
    def __init__(self, discovery_rate: float = 0.05):
        self.discovery_rate = discovery_rate
        self.discovered_opportunities: List[Opportunity] = []

    def scan_for_opportunities(self, agent: Agent, markets: Dict[str, Any], current_tick: int) -> Optional[Opportunity]:
        if agent.agent_type not in (AgentType.ENTREPRENEUR, AgentType.TRADER, AgentType.FIRM):
            return None

        # Check for price discrepancy across markets (Spatial Arbitrage)
        market_prices = {m_id: m.current_price for m_id, m in markets.items()}
        if len(market_prices) >= 2:
            min_m = min(market_prices, key=market_prices.get)
            max_m = max(market_prices, key=market_prices.get)
            spread = market_prices[max_m] - market_prices[min_m]

            if spread > Decimal("5.00"):
                # Agent discovers arbitrage opportunity from local price observation
                opp = Opportunity(
                    discoverer_id=agent.agent_id,
                    location=agent.location,
                    initial_belief=f"Arbitrage buy at {min_m} sell at {max_m}",
                    resources_required={"capital": float(market_prices[min_m] * Decimal("10"))},
                    expected_return=spread * Decimal("10"),
                    risk=0.2,
                    discovery_time=current_tick,
                    opportunity_type="SPATIAL_ARBITRAGE"
                )
                self.discovered_opportunities.append(opp)
                return opp

        # Check for new technological / process discovery based on experience
        if random.random() < self.discovery_rate:
            opp = Opportunity(
                discoverer_id=agent.agent_id,
                location=agent.location,
                initial_belief="Discovered local component substitute reducing production cost by 25%",
                resources_required={"capital": 300.0},
                expected_return=Decimal("450.00"),
                risk=0.45,
                discovery_time=current_tick,
                opportunity_type="PROCESS_INNOVATION"
            )
            self.discovered_opportunities.append(opp)
            return opp

        return None
