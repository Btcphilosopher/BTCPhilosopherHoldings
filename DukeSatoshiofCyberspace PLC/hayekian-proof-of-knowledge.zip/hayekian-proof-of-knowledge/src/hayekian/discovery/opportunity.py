from dataclasses import dataclass, field
from decimal import Decimal
from typing import Dict, Any, Optional
from hayekian.core.ids import generate_id

@dataclass
class Opportunity:
    discoverer_id: str
    location: str
    initial_belief: str
    resources_required: Dict[str, float]
    expected_return: Decimal
    risk: float  # 0.0 to 1.0
    discovery_time: int
    opportunity_type: str = "ARBITRAGE"  # ARBITRAGE, NEW_SUPPLIER, NEW_METHOD, NEW_USE
    realised_outcome: Optional[Decimal] = None
    opportunity_id: str = field(default_factory=lambda: generate_id("opp"))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "opportunity_id": self.opportunity_id,
            "discoverer_id": self.discoverer_id,
            "location": self.location,
            "initial_belief": self.initial_belief,
            "resources_required": self.resources_required,
            "expected_return": float(self.expected_return),
            "risk": self.risk,
            "discovery_time": self.discovery_time,
            "opportunity_type": self.opportunity_type,
            "realised_outcome": float(self.realised_outcome) if self.realised_outcome is not None else None
        }
