from typing import List, Dict, Any
from hayekian.plans.plan import Plan

class ConflictDetector:
    """
    Detects plan conflicts (e.g., multiple agents planning to buy more of a scarce resource
    than total available physical supply).
    """
    @staticmethod
    def detect_resource_conflicts(plans: List[Plan], available_supply: Dict[str, float]) -> List[Dict[str, Any]]:
        conflicts = []
        demand_by_resource: Dict[str, float] = {}

        for p in plans:
            if p.status in ("ACTIVE", "PROPOSED"):
                demand_by_resource[p.target_resource] = demand_by_resource.get(p.target_resource, 0.0) + p.target_quantity

        for res, total_demand in demand_by_resource.items():
            supply = available_supply.get(res, 0.0)
            if total_demand > supply:
                conflicts.append({
                    "resource": res,
                    "total_demand": total_demand,
                    "available_supply": supply,
                    "shortage": total_demand - supply,
                    "conflicting_plans_count": len([p for p in plans if p.target_resource == res])
                })
        return conflicts
