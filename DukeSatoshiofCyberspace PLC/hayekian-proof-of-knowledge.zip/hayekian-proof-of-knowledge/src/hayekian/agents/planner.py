from decimal import Decimal
from typing import Dict, Any, List, Optional
from hayekian.agents.agent import Agent
from hayekian.core.enums import AgentType, PlannerMode
from hayekian.core.errors import TemporalBoundaryViolationError

class CentralPlanner(Agent):
    """
    Central Planner benchmark agent.
    Subject to configurable information visibility constraints.
    """
    def __init__(
        self,
        agent_id: str = "central_planner_01",
        mode: PlannerMode = PlannerMode.PARTIAL_INFORMATION_PLANNER,
        information_delay_ticks: int = 5
    ):
        super().__init__(
            agent_id=agent_id,
            agent_type=AgentType.PLANNER,
            location="CENTRAL_HQ",
            wealth=Decimal("1000000.00"),
            skills=["CENTRAL_ALLOCATION", "STATISTICAL_OPTIMIZATION"]
        )
        self.mode = mode
        self.information_delay_ticks = information_delay_ticks
        self.reported_local_data: List[Dict[str, Any]] = []

    def receive_local_report(self, report: Dict[str, Any], current_tick: int):
        report_tick = report.get("timestamp", current_tick)
        if self.mode == PlannerMode.NO_LOCAL_KNOWLEDGE_PLANNER:
            return  # Completely rejects/ignores local facts

        if self.mode == PlannerMode.DELAYED_INFORMATION_PLANNER:
            available_at = report_tick + self.information_delay_ticks
            if current_tick < available_at:
                return  # Information delayed

        if self.mode == PlannerMode.PARTIAL_INFORMATION_PLANNER:
            # Random loss of 40% of local reports
            import random
            if random.random() < 0.4:
                return

        self.reported_local_data.append(report)

    def calculate_allocation(self, resources: List[str], current_tick: int) -> Dict[str, float]:
        """Calculates central resource quota allocation based strictly on reported data."""
        allocations = {}
        for r in resources:
            # Standard statistical averaging of received reports
            reports_for_r = [rep for rep in self.reported_local_data if rep.get("resource") == r]
            if not reports_for_r:
                allocations[r] = 50.0  # Equal baseline guess under ignorance
            else:
                total_req = sum(rep.get("requested_quantity", 50.0) for rep in reports_for_r)
                allocations[r] = total_req / max(1, len(reports_for_r))
        return allocations
