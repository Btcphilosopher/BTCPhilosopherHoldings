from decimal import Decimal
from typing import Dict, Any, List
from hayekian.agents.agent import Agent
from hayekian.core.enums import AgentType

class InstitutionAgent(Agent):
    def __init__(self, agent_id: str, location: str, name: str, rules: List[str]):
        super().__init__(
            agent_id=agent_id,
            agent_type=AgentType.INSTITUTION,
            location=location,
            wealth=Decimal("10000.00"),
            skills=["RULE_ENFORCEMENT", "CONTRACT_REGISTRATION"]
        )
        self.institution_name = name
        self.rules = rules
