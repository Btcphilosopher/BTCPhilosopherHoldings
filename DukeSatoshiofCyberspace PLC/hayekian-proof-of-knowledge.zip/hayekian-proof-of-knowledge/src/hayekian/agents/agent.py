from dataclasses import dataclass, field
from decimal import Decimal
from typing import Dict, Any, List, Optional
from hayekian.core.enums import AgentType
from hayekian.core.ids import generate_id
from hayekian.core.units import to_money
from hayekian.epistemics.information_set import InformationSet
from hayekian.epistemics.belief_revision import BeliefState

@dataclass
class Agent:
    agent_id: str
    agent_type: AgentType
    location: str
    wealth: Decimal = Decimal("1000.00")
    capital: Decimal = Decimal("500.00")
    skills: List[str] = field(default_factory=list)
    preferences: Dict[str, float] = field(default_factory=dict)
    goals: List[str] = field(default_factory=list)
    risk_tolerance: float = 0.5  # 0.0 risk-averse, 1.0 risk-seeking
    time_preference: float = 0.1  # discount rate
    
    # Strictly isolated local knowledge & belief state
    information_set: InformationSet = field(default_factory=lambda: InformationSet(agent_id=""))
    belief_state: BeliefState = field(default_factory=lambda: BeliefState(agent_id=""))
    plans: List[Any] = field(default_factory=list)
    actions: List[Any] = field(default_factory=list)
    history: List[Dict[str, Any]] = field(default_factory=list)

    def __post_init__(self):
        if not self.information_set.agent_id:
            self.information_set.agent_id = self.agent_id
        if not self.belief_state.agent_id:
            self.belief_state.agent_id = self.agent_id

    def observe(self, observation: Dict[str, Any], current_tick: int):
        """Record local observation strictly into agent's own private information set."""
        self.information_set.local_observations.append({
            "tick": current_tick,
            "data": observation
        })
        self.history.append({
            "tick": current_tick,
            "event": "OBSERVATION",
            "details": observation
        })

    def receive_price_signal(self, signal_dict: Dict[str, Any], current_tick: int):
        self.information_set.record_price_signal(signal_dict, current_tick)
        self.belief_state.update_from_price_signal(
            asset=signal_dict.get("asset", "RESOURCE"),
            price=float(signal_dict.get("price", 10.0)),
            previous_price=float(signal_dict.get("previous_price", 10.0))
        )

    def to_dict(self, current_tick: int) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type.value,
            "location": self.location,
            "wealth": float(self.wealth),
            "capital": float(self.capital),
            "skills": self.skills,
            "risk_tolerance": self.risk_tolerance,
            "time_preference": self.time_preference,
            "information_set": self.information_set.to_dict(current_tick),
            "plans_count": len(self.plans),
            "actions_count": len(self.actions)
        }
