from decimal import Decimal
from typing import Dict, Any, List
from hayekian.agents.agent import Agent
from hayekian.core.enums import AgentType
from hayekian.core.ids import generate_id

class HouseholdAgent(Agent):
    def __init__(self, agent_id: str, location: str, wealth: Decimal = Decimal("500.00")):
        super().__init__(
            agent_id=agent_id,
            agent_type=AgentType.HOUSEHOLD,
            location=location,
            wealth=wealth,
            skills=["LABOUR", "CONSUMPTION"]
        )

class FirmAgent(Agent):
    def __init__(self, agent_id: str, location: str, capacity: float = 100.0, wealth: Decimal = Decimal("5000.00")):
        super().__init__(
            agent_id=agent_id,
            agent_type=AgentType.FIRM,
            location=location,
            wealth=wealth,
            skills=["PRODUCTION", "LOGISTICS"]
        )
        self.capacity = capacity
        self.current_utilization = 1.0

class EntrepreneurAgent(Agent):
    def __init__(self, agent_id: str, location: str, wealth: Decimal = Decimal("2000.00")):
        super().__init__(
            agent_id=agent_id,
            agent_type=AgentType.ENTREPRENEUR,
            location=location,
            wealth=wealth,
            skills=["ARBITRAGE", "DISCOVERY", "INNOVATION"],
            risk_tolerance=0.8
        )

class TraderAgent(Agent):
    def __init__(self, agent_id: str, location: str, wealth: Decimal = Decimal("3000.00")):
        super().__init__(
            agent_id=agent_id,
            agent_type=AgentType.TRADER,
            location=location,
            wealth=wealth,
            skills=["MARKET_MAKING", "LIQUIDITY"]
        )
