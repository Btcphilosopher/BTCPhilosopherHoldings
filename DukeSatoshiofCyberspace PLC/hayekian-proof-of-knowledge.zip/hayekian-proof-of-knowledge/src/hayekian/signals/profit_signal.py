from dataclasses import dataclass, field
from decimal import Decimal
from typing import Dict, Any
from hayekian.core.ids import generate_id

@dataclass
class ProfitSignal:
    agent_id: str
    opportunity_id: str
    realized_profit: Decimal
    timestamp: int
    signal_id: str = field(default_factory=lambda: generate_id("sig_prf"))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "signal_id": self.signal_id,
            "agent_id": self.agent_id,
            "opportunity_id": self.opportunity_id,
            "realized_profit": float(self.realized_profit),
            "timestamp": self.timestamp
        }

@dataclass
class LossSignal:
    agent_id: str
    plan_id: str
    realized_loss: Decimal
    timestamp: int
    cause: str
    signal_id: str = field(default_factory=lambda: generate_id("sig_los"))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "signal_id": self.signal_id,
            "agent_id": self.agent_id,
            "plan_id": self.plan_id,
            "realized_loss": float(self.realized_loss),
            "timestamp": self.timestamp,
            "cause": self.cause
        }
