from dataclasses import dataclass, field
from decimal import Decimal
from typing import Dict, Any, Optional
from hayekian.core.ids import generate_id

@dataclass
class PriceSignal:
    asset: str
    market: str
    timestamp: int
    price: Decimal
    quantity: float
    previous_price: Decimal
    price_change: Decimal
    volume: float
    liquidity: float
    scarcity_estimate: float  # 0.0 abundant to 1.0 severe shortage
    signal_id: str = field(default_factory=lambda: generate_id("sig_prc"))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "signal_id": self.signal_id,
            "asset": self.asset,
            "market": self.market,
            "timestamp": self.timestamp,
            "price": float(self.price),
            "quantity": self.quantity,
            "previous_price": float(self.previous_price),
            "price_change": float(self.price_change),
            "volume": self.volume,
            "liquidity": self.liquidity,
            "scarcity_estimate": self.scarcity_estimate
        }
