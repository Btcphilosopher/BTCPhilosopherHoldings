from dataclasses import dataclass
from typing import Any, Dict

@dataclass
class LocalKnowledgeFact:
    domain: str
    location: str
    entity_id: str
    attribute: str
    value: Any
    observed_tick: int
    context: Dict[str, Any]

class LocalKnowledgeBuilder:
    @staticmethod
    def create_farmer_fact(farmer_id: str, location: str, soil: str, microclimate: str, tick: int):
        return LocalKnowledgeFact(
            domain="AGRICULTURE",
            location=location,
            entity_id=farmer_id,
            attribute="crop_condition",
            value={"soil": soil, "microclimate": microclimate},
            observed_tick=tick,
            context={"role": "farmer"}
        )

    @staticmethod
    def create_mechanic_fact(mechanic_id: str, machine_id: str, wear_level: float, vibration_hz: float, tick: int):
        return LocalKnowledgeFact(
            domain="MAINTENANCE",
            location="factory_floor",
            entity_id=machine_id,
            attribute="vibration_wear",
            value={"wear_level": wear_level, "vibration_hz": vibration_hz},
            observed_tick=tick,
            context={"mechanic_id": mechanic_id}
        )
