from dataclasses import dataclass, field
from typing import Dict, Any
from hayekian.core.ids import generate_id

@dataclass
class Observation:
    agent_id: str
    timestamp: int
    location: str
    raw_data: Dict[str, Any]
    precision: float = 1.0
    observation_id: str = field(default_factory=lambda: generate_id("obs"))

@dataclass
class Inference:
    agent_id: str
    observation_ids: list[str]
    timestamp: int
    derived_claim: Dict[str, Any]
    uncertainty: float
    inference_id: str = field(default_factory=lambda: generate_id("inf"))

@dataclass
class Belief:
    agent_id: str
    proposition: str
    subject: str
    probability: float  # 0.0 to 1.0
    timestamp: int
    basis_knowledge_ids: list[str]
    belief_id: str = field(default_factory=lambda: generate_id("blf"))

@dataclass
class ProvenanceNode:
    node_id: str
    entity_type: str  # Observation, KnowledgeClaim, Signal, Price, etc.
    agent_id: str
    timestamp: int
    parent_ids: list[str] = field(default_factory=list)
