from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Set

@dataclass
class KnowledgeEdge:
    source: str
    destination: str
    relation: str  # OBSERVED, DERIVED, GENERATED_BELIEF, FORMED_PLAN, EXECUTED_ACTION, CREATED_TRANSACTION, FORMED_PRICE, GENERATED_SIGNAL, REVISED_BELIEF
    timestamp: int
    confidence: float
    information_content: Dict[str, Any]
    context: Dict[str, Any]

class PureDiGraph:
    """Pure Python directed graph for zero-dependency execution."""
    def __init__(self):
        self._nodes: Dict[str, Dict[str, Any]] = {}
        self._succ: Dict[str, Dict[str, Dict[str, Any]]] = {}
        self._pred: Dict[str, Dict[str, Dict[str, Any]]] = {}

    def add_node(self, node_id: str, **kwargs):
        if node_id not in self._nodes:
            self._nodes[node_id] = {}
            self._succ[node_id] = {}
            self._pred[node_id] = {}
        self._nodes[node_id].update(kwargs)

    def add_edge(self, u: str, v: str, **kwargs):
        self.add_node(u)
        self.add_node(v)
        self._succ[u][v] = kwargs
        self._pred[v][u] = kwargs

    def number_of_nodes(self) -> int:
        return len(self._nodes)

    def number_of_edges(self) -> int:
        return sum(len(succs) for succs in self._succ.values())

    def ancestors(self, target: str) -> Set[str]:
        visited = set()
        queue = [target]
        while queue:
            curr = queue.pop(0)
            preds = self._pred.get(curr, {})
            for p in preds:
                if p not in visited:
                    visited.add(p)
                    queue.append(p)
        return visited

class KnowledgeGraph:
    """
    Directed Temporal Knowledge Graph tracing the full Hayekian Loop:
    Observation -> Local Knowledge -> Belief -> Plan -> Action -> Transaction -> Price Signal -> Response -> Revision
    """
    def __init__(self):
        self.graph = PureDiGraph()
        self.edges_list: List[KnowledgeEdge] = []

    def add_node(self, node_id: str, node_type: str, agent_id: str, timestamp: int, details: Dict[str, Any]):
        self.graph.add_node(
            node_id,
            node_type=node_type,
            agent_id=agent_id,
            timestamp=timestamp,
            **details
        )

    def add_edge(
        self,
        source: str,
        destination: str,
        relation: str,
        timestamp: int,
        confidence: float = 1.0,
        information_content: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None
    ):
        edge_data = KnowledgeEdge(
            source=source,
            destination=destination,
            relation=relation,
            timestamp=timestamp,
            confidence=confidence,
            information_content=information_content or {},
            context=context or {}
        )
        self.edges_list.append(edge_data)
        self.graph.add_edge(
            source,
            destination,
            relation=relation,
            timestamp=timestamp,
            confidence=confidence,
            information_content=information_content or {},
            context=context or {}
        )

    def audit_agent_knowledge(self, agent_id: str, up_to_tick: int) -> List[Dict[str, Any]]:
        """Answers: WHAT DID THE AGENT KNOW AT TIME T?"""
        results = []
        for n, data in self.graph._nodes.items():
            if data.get("agent_id") == agent_id and data.get("timestamp", 0) <= up_to_tick:
                results.append({"node_id": n, **data})
        return sorted(results, key=lambda x: x.get("timestamp", 0))

    def trace_price_provenance(self, price_signal_id: str) -> Dict[str, Any]:
        """Traces the chain of local observations, actions, and orders that generated a price signal."""
        if price_signal_id not in self.graph._nodes:
            return {"error": "Signal not found in graph"}
        
        ancestors = self.graph.ancestors(price_signal_id)
        relevant_nodes = ancestors | {price_signal_id}
        
        nodes = []
        for n in relevant_nodes:
            nodes.append({"id": n, **self.graph._nodes[n]})
            
        edges = []
        for u in relevant_nodes:
            for v, data in self.graph._succ.get(u, {}).items():
                if v in relevant_nodes:
                    edges.append({"source": u, "target": v, **data})

        return {
            "signal_id": price_signal_id,
            "ancestor_nodes_count": len(ancestors),
            "nodes": nodes,
            "edges": edges
        }

    def to_dict(self) -> Dict[str, Any]:
        nodes = []
        for n, data in self.graph._nodes.items():
            nodes.append({"id": n, **data})
        
        edges = []
        for u, succs in self.graph._succ.items():
            for v, data in succs.items():
                edges.append({"source": u, "target": v, **data})

        return {
            "nodes_count": len(nodes),
            "edges_count": len(edges),
            "nodes": nodes,
            "edges": edges
        }
