from dataclasses import dataclass, field
from typing import Dict, Any, List
from hayekian.core.ids import generate_id

@dataclass
class TacitKnowledgeProxy:
    agent_id: str
    domain: str
    experience_level: float  # 0.0 (novice) to 1.0 (master)
    historical_success_rate: float
    action_pattern: str  # Description of heuristic pattern
    confidence: float
    explainability_level: float  # 0.0 (unexplainable intuition) to 1.0 (fully codifiable)
    proxy_id: str = field(default_factory=lambda: generate_id("tacit"))
    recorded_outcomes: List[Dict[str, Any]] = field(default_factory=list)

    def select_action(self, context: Dict[str, Any]) -> str:
        # Heuristic decision derived from experience without full explicit formulation
        if self.experience_level > 0.7:
            return f"heuristic_expert_{self.domain.lower()}"
        return f"heuristic_standard_{self.domain.lower()}"
