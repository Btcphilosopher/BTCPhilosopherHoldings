from dataclasses import dataclass, field
from typing import Dict, Any, Optional
from hayekian.core.enums import KnowledgeType, EpistemicStatus
from hayekian.core.ids import generate_id

@dataclass
class KnowledgeClaim:
    agent_id: str
    domain: str
    location: str
    timestamp: int
    content: Dict[str, Any]
    knowledge_type: KnowledgeType
    source: str
    confidence: float = 1.0  # 0.0 to 1.0
    observed_at: int = 0
    expires_at: Optional[int] = None
    provenance_id: Optional[str] = None
    action_relevance: float = 1.0
    verification_status: EpistemicStatus = EpistemicStatus.KNOWN
    knowledge_id: str = field(default_factory=lambda: generate_id("knw"))

    def is_valid_at(self, tick: int) -> bool:
        if self.timestamp > tick:
            return False
        if self.expires_at is not None and tick > self.expires_at:
            return False
        return True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "knowledge_id": self.knowledge_id,
            "agent_id": self.agent_id,
            "domain": self.domain,
            "location": self.location,
            "timestamp": self.timestamp,
            "content": self.content,
            "knowledge_type": self.knowledge_type.value,
            "source": self.source,
            "confidence": self.confidence,
            "observed_at": self.observed_at,
            "expires_at": self.expires_at,
            "provenance_id": self.provenance_id,
            "action_relevance": self.action_relevance,
            "verification_status": self.verification_status.value
        }
