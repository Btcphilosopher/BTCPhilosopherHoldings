from decimal import Decimal
from typing import List, Dict, Any, Optional, Tuple
from hayekian.markets.order import Order
from hayekian.markets.transaction import Transaction
from hayekian.markets.price_discovery import OrderBook
from hayekian.signals.price_signal import PriceSignal
from hayekian.core.ids import generate_id

class Market:
    def __init__(self, market_id: str, asset: str, location: str = "GLOBAL", price_flexibility: float = 1.0):
        self.market_id = market_id
        self.asset = asset
        self.location = location
        self.order_book = OrderBook(market_id=market_id, asset=asset, price_flexibility=price_flexibility)
        self.transactions_history: List[Transaction] = []
        self.price_signals: List[PriceSignal] = []
        self.current_price: Decimal = Decimal("100.00")

    def submit_order(self, order: Order, tick: int) -> Tuple[List[Transaction], Optional[PriceSignal]]:
        prev_price = self.current_price
        txns = self.order_book.submit_order(order)
        signal = None

        if txns:
            self.transactions_history.extend(txns)
            self.current_price = txns[-1].price
            price_change = self.current_price - prev_price
            
            # Estimate scarcity based on bids vs asks volume in orderbook
            bids_vol = sum(b.remaining_quantity for b in self.order_book.bids)
            asks_vol = sum(a.remaining_quantity for a in self.order_book.asks)
            tot = max(1.0, bids_vol + asks_vol)
            scarcity = min(1.0, max(0.0, bids_vol / tot))

            signal = PriceSignal(
                asset=self.asset,
                market=self.market_id,
                timestamp=tick,
                price=self.current_price,
                quantity=sum(t.quantity for t in txns),
                previous_price=prev_price,
                price_change=price_change,
                volume=self.order_book.total_volume,
                liquidity=asks_vol + bids_vol,
                scarcity_estimate=scarcity
            )
            self.price_signals.append(signal)

        return txns, signal

    def to_dict(self) -> Dict[str, Any]:
        return {
            "market_id": self.market_id,
            "asset": self.asset,
            "location": self.location,
            "current_price": float(self.current_price),
            "transactions_count": len(self.transactions_history),
            "bids_count": len(self.order_book.bids),
            "asks_count": len(self.order_book.asks),
            "price_signals_count": len(self.price_signals)
        }
