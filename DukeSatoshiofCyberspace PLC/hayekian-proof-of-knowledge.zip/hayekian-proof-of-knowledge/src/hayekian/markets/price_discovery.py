from decimal import Decimal
from typing import List, Tuple, Dict, Any, Optional
from hayekian.markets.order import Order, OrderSide, OrderType
from hayekian.markets.transaction import Transaction
from hayekian.signals.price_signal import PriceSignal

class OrderBook:
    """
    Decentralized limit order book matching engine.
    Matches highest bids with lowest asks to discover market clearing prices.
    """
    def __init__(self, market_id: str, asset: str, price_flexibility: float = 1.0):
        self.market_id = market_id
        self.asset = asset
        self.bids: List[Order] = []  # Sorted descending by price, ascending by timestamp
        self.asks: List[Order] = []  # Sorted ascending by price, ascending by timestamp
        self.last_clearing_price: Decimal = Decimal("100.00")
        self.price_flexibility = price_flexibility  # 1.0 = fully flexible, 0.1 = rigid price controls
        self.total_volume: float = 0.0

    def submit_order(self, order: Order) -> List[Transaction]:
        if order.side == OrderSide.BID:
            self.bids.append(order)
            self.bids.sort(key=lambda o: (-o.price, o.timestamp))
        else:
            self.asks.append(order)
            self.asks.sort(key=lambda o: (o.price, o.timestamp))

        return self.match_orders(order.timestamp)

    def match_orders(self, timestamp: int) -> List[Transaction]:
        transactions: List[Transaction] = []

        while self.bids and self.asks:
            best_bid = self.bids[0]
            best_ask = self.asks[0]

            # Price matching condition
            if best_bid.price < best_ask.price:
                break  # No spread overlap

            # Calculated equilibrium clearing price
            raw_clearing_price = (best_bid.price + best_ask.price) / Decimal("2")
            
            # Apply price rigidity factor if price controls are present
            price_delta = raw_clearing_price - self.last_clearing_price
            adjusted_delta = price_delta * Decimal(str(self.price_flexibility))
            clearing_price = self.last_clearing_price + adjusted_delta

            trade_qty = min(best_bid.remaining_quantity, best_ask.remaining_quantity)

            if trade_qty <= 0:
                break

            txn = Transaction(
                market_id=self.market_id,
                asset=self.asset,
                buyer_id=best_bid.agent_id,
                seller_id=best_ask.agent_id,
                price=clearing_price,
                quantity=trade_qty,
                buy_order_id=best_bid.order_id,
                sell_order_id=best_ask.order_id,
                timestamp=timestamp
            )
            transactions.append(txn)

            best_bid.remaining_quantity -= trade_qty
            best_ask.remaining_quantity -= trade_qty
            self.total_volume += trade_qty
            self.last_clearing_price = clearing_price

            if best_bid.remaining_quantity <= 1e-6:
                self.bids.pop(0)
            if best_ask.remaining_quantity <= 1e-6:
                self.asks.pop(0)

        return transactions
