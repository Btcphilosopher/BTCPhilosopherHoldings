from dataclasses import dataclass, field
from decimal import Decimal
from typing import Optional
from hayekian.core.enums import OrderSide, OrderType
from hayekian.core.ids import generate_id

@dataclass
class Order:
    agent_id: str
    market_id: str
    asset: str
    side: OrderSide
    order_type: OrderType
    price: Decimal  # Max price for BID, Min price for ASK
    quantity: float
    timestamp: int
    remaining_quantity: float = field(init=False)
    order_id: str = field(default_factory=lambda: generate_id("ord"))

    def __post_init__(self):
        self.remaining_quantity = self.quantity

    def to_dict(self):
        return {
            "order_id": self.order_id,
            "agent_id": self.agent_id,
            "market_id": self.market_id,
            "asset": self.asset,
            "side": self.side.value,
            "order_type": self.order_type.value,
            "price": float(self.price),
            "quantity": self.quantity,
            "remaining_quantity": self.remaining_quantity,
            "timestamp": self.timestamp
        }
