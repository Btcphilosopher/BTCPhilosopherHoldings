from dataclasses import dataclass, field
from decimal import Decimal
from typing import Dict, Any
from hayekian.core.ids import generate_id

@dataclass
class Transaction:
    market_id: str
    asset: str
    buyer_id: str
    seller_id: str
    price: Decimal
    quantity: float
    buy_order_id: str
    sell_order_id: str
    timestamp: int
    transaction_id: str = field(default_factory=lambda: generate_id("txn"))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transaction_id": self.transaction_id,
            "market_id": self.market_id,
            "asset": self.asset,
            "buyer_id": self.buyer_id,
            "seller_id": self.seller_id,
            "price": float(self.price),
            "quantity": self.quantity,
            "timestamp": self.timestamp
        }
