from typing import Generic, TypeVar, Optional, Union

T = TypeVar("T")
E = TypeVar("E", bound=Exception)

class Ok(Generic[T]):
    def __init__(self, value: T):
        self.value = value
    def is_ok(self) -> bool: return True
    def is_err(self) -> bool: return False

class Err(Generic[E]):
    def __init__(self, error: E):
        self.error = error
    def is_ok(self) -> bool: return False
    def is_err(self) -> bool: return True

Result = Union[Ok[T], Err[E]]
