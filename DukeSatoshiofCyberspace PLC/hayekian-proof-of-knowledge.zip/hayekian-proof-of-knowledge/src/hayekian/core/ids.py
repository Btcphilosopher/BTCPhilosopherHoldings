import uuid
from typing import NewType

AgentId = NewType("AgentId", str)
KnowledgeId = NewType("KnowledgeId", str)
DecisionId = NewType("DecisionId", str)
ActionId = NewType("ActionId", str)
PlanId = NewType("PlanId", str)
OrderId = NewType("OrderId", str)
TransactionId = NewType("TransactionId", str)
MarketId = NewType("MarketId", str)
OpportunityId = NewType("OpportunityId", str)
ProofId = NewType("ProofId", str)
ExperimentId = NewType("ExperimentId", str)
ResourceId = NewType("ResourceId", str)

def generate_id(prefix: str = "") -> str:
    uid = uuid.uuid4().hex[:12]
    return f"{prefix}_{uid}" if prefix else uid
