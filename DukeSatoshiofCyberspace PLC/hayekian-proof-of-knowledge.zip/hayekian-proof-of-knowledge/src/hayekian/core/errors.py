class HayekianError(Exception):
    """Base error for Hayekian Proof-of-Knowledge system."""
    pass

class TemporalBoundaryViolationError(HayekianError):
    """Raised when an agent attempts to access information with timestamp > simulation time T."""
    pass

class EpistemicViolationError(HayekianError):
    """Raised when knowledge isolation or epistemic boundaries are breached."""
    pass

class KnowledgeIsolationError(HayekianError):
    """Raised when an agent accesses another agent's private knowledge set directly."""
    pass

class MarketExecutionError(HayekianError):
    """Raised when market order processing fails or inventory is invalid."""
    pass
