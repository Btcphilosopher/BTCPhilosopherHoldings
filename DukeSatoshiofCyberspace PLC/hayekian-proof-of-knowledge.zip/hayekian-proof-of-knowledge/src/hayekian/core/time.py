from dataclasses import dataclass
from typing import TotalOrdering

@dataclass(frozen=True)
@TotalOrdering
class SimulationTime:
    tick: int

    def __lt__(self, other: 'SimulationTime') -> bool:
        if not isinstance(other, SimulationTime):
            return NotImplemented
        return self.tick < other.tick

    def __add__(self, delta: int) -> 'SimulationTime':
        return SimulationTime(self.tick + delta)

    def __sub__(self, other: 'SimulationTime') -> int:
        return self.tick - other.tick

    def __str__(self) -> str:
        return f"T={self.tick}"
