from decimal import Decimal, ROUND_HALF_UP
from typing import Union

Money = Decimal

def to_money(val: Union[float, int, str, Decimal]) -> Decimal:
    if isinstance(val, float):
        val = f"{val:.4f}"
    return Decimal(str(val)).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)

def format_money(val: Decimal) -> str:
    return f"${val:,.2f}"
