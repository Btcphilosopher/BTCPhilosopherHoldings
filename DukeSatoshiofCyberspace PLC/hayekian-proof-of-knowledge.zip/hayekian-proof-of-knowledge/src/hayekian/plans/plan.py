from dataclasses import dataclass, field
from decimal import Decimal
from typing import Dict, Any, List, Optional
from hayekian.core.ids import generate_id

@dataclass
class Plan:
    agent_id: str
    goal: str
    target_resource: str
    target_quantity: float
    expected_price: Decimal
    timestamp: int
    plan_id: str = field(default_factory=lambda: generate_id("pln"))
    status: str = "PROPOSED"  # PROPOSED, ACTIVE, EXECUTED, ABANDONED, FAILED
    steps: List[Dict[str, Any]] = field(default_factory=list)
    basis_knowledge_ids: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "plan_id": self.plan_id,
            "agent_id": self.agent_id,
            "goal": self.goal,
            "target_resource": self.target_resource,
            "target_quantity": self.target_quantity,
            "expected_price": float(self.expected_price),
            "timestamp": self.timestamp,
            "status": self.status,
            "basis_knowledge_ids": self.basis_knowledge_ids
        }
