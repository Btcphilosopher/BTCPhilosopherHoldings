import copy
from typing import Dict, Any, List
from hayekian.core.enums import SimulationMode, PlannerMode
from hayekian.simulation.engine import SimulationEngine
from hayekian.simulation.scenarios import build_canonical_scenario

class CounterfactualComparator:
    """
    Counterfactual Engine running identical initial conditions under:
    - WORLD A: Centralized Planning
    - WORLD B: Decentralized Market
    - WORLD C: Hybrid System
    """
    def __init__(self, scenario_name: str = "knowledge-problem", duration: int = 200, seed: int = 42):
        self.scenario_name = scenario_name
        self.duration = duration
        self.seed = seed

    def run_comparison(self) -> Dict[str, Any]:
        # World A: Centralized Planning
        engine_a = build_canonical_scenario(
            scenario_name=self.scenario_name,
            mode=SimulationMode.CENTRALISED,
            seed=self.seed
        )
        res_a = engine_a.run(ticks=self.duration)

        # World B: Decentralized Market
        engine_b = build_canonical_scenario(
            scenario_name=self.scenario_name,
            mode=SimulationMode.DECENTRALISED,
            seed=self.seed
        )
        res_b = engine_b.run(ticks=self.duration)

        # World C: Hybrid System
        engine_c = build_canonical_scenario(
            scenario_name=self.scenario_name,
            mode=SimulationMode.HYBRID,
            seed=self.seed
        )
        res_c = engine_c.run(ticks=self.duration)

        return {
            "scenario": self.scenario_name,
            "seed": self.seed,
            "duration": self.duration,
            "world_a_central_planner": res_a,
            "world_b_decentralised_market": res_b,
            "world_c_hybrid_system": res_c,
            "comparison_summary": {
                "kur_difference": res_b["metrics"]["knowledge_utilisation_rate"] - res_a["metrics"]["knowledge_utilisation_rate"],
                "coordination_error_reduction": res_a["metrics"]["coordination_error"] - res_b["metrics"]["coordination_error"],
                "output_gain_decentralised": res_b["metrics"]["economic_output_total"] - res_a["metrics"]["economic_output_total"]
            }
        }
