from dataclasses import dataclass, field
from typing import Dict, Any, List

@dataclass
class CoordinationMetrics:
    knowledge_utilisation_rate: float  # KUR (0.0 to 1.0)
    local_knowledge_utilisation: float
    entrepreneurial_discovery_rate: float
    coordination_error: float  # Unmatched demand or misallocated supply
    plan_conflict_rate: float
    adaptation_speed_ticks: float
    price_signal_latency_ticks: float
    information_compression_ratio: float
    resource_misallocation_cost: float
    economic_output_total: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "knowledge_utilisation_rate": round(self.knowledge_utilisation_rate, 4),
            "local_knowledge_utilisation": round(self.local_knowledge_utilisation, 4),
            "entrepreneurial_discovery_rate": round(self.entrepreneurial_discovery_rate, 4),
            "coordination_error": round(self.coordination_error, 4),
            "plan_conflict_rate": round(self.plan_conflict_rate, 4),
            "adaptation_speed_ticks": round(self.adaptation_speed_ticks, 2),
            "price_signal_latency_ticks": round(self.price_signal_latency_ticks, 2),
            "information_compression_ratio": round(self.information_compression_ratio, 4),
            "resource_misallocation_cost": round(self.resource_misallocation_cost, 2),
            "economic_output_total": round(self.economic_output_total, 2)
        }
