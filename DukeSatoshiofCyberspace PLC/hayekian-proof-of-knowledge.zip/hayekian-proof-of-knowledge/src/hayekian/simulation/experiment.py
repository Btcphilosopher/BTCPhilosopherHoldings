from typing import Dict, Any, Optional
from hayekian.simulation.world import WorldState
from hayekian.simulation.engine import SimulationEngine
from hayekian.core.enums import SimulationMode
from hayekian.agents.agent import Agent
from hayekian.markets.market import Market

class Experiment:
    """
    Python Experiment DSL API for Hayekian Proof-of-Knowledge.
    Allows researchers to define experiments entirely in Python code.
    """
    def __init__(self, name: str, duration: int = 200, seed: int = 42, mode: SimulationMode = SimulationMode.DECENTRALISED):
        self.name = name
        self.duration = duration
        self.seed = seed
        self.mode = mode
        self.world = WorldState(seed=seed)
        self.engine = SimulationEngine(world=self.world, mode=self.mode)
        self._results: Optional[Dict[str, Any]] = None

    def add_agent(self, agent: Agent):
        self.world.add_agent(agent)

    def add_market(self, market: Market):
        self.world.add_market(market)

    def add_resource(self, name: str, quantity: float):
        self.world.resources[name] = quantity

    def add_shock(self, shock: Dict[str, Any], tick: int = 100):
        shock["tick"] = tick
        self.world.active_shocks.append(shock)

    def run(self) -> Dict[str, Any]:
        self._results = self.engine.run(ticks=self.duration)
        self._results["experiment_name"] = self.name
        return self._results

    def result(self) -> Dict[str, Any]:
        if not self._results:
            return self.run()
        return self._results
