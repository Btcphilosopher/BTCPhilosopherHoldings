class SimulationClock:
    def __init__(self, start_tick: int = 0):
        self._current_tick = start_tick

    @property
    def tick(self) -> int:
        return self._current_tick

    def advance(self) -> int:
        self._current_tick += 1
        return self._current_tick

    def reset(self, tick: int = 0):
        self._current_tick = tick
