from decimal import Decimal
from typing import Dict, List, Any, Optional
from hayekian.agents.agent import Agent
from hayekian.markets.market import Market
from hayekian.knowledge.knowledge_claim import KnowledgeClaim
from hayekian.knowledge.knowledge_graph import KnowledgeGraph
from hayekian.core.enums import ShockType

class WorldState:
    def __init__(self, seed: int = 42):
        self.seed = seed
        self.agents: Dict[str, Agent] = {}
        self.markets: Dict[str, Market] = {}
        self.resources: Dict[str, float] = {}  # Resource availability
        self.knowledge_graph = KnowledgeGraph()
        self.active_shocks: List[Dict[str, Any]] = []
        self.proofs_of_knowledge: List[Dict[str, Any]] = []
        self.event_log: List[Dict[str, Any]] = []

    def add_agent(self, agent: Agent):
        self.agents[agent.agent_id] = agent

    def add_market(self, market: Market):
        self.markets[market.market_id] = market

    def record_proof_of_knowledge(
        self,
        proof_id: str,
        agent_id: str,
        knowledge_id: str,
        tick: int,
        decision_id: str,
        state_hash: str,
        context: Dict[str, Any]
    ):
        self.proofs_of_knowledge.append({
            "proof_id": proof_id,
            "agent_id": agent_id,
            "knowledge_id": knowledge_id,
            "timestamp": tick,
            "decision_id": decision_id,
            "knowledge_state_hash": state_hash,
            "decision_context": context
        })

    def apply_shock(self, shock: Dict[str, Any], tick: int):
        shock["applied_at"] = tick
        self.active_shocks.append(shock)
        self.event_log.append({
            "tick": tick,
            "event": "SHOCK_APPLIED",
            "type": shock.get("type", "UNKNOWN"),
            "details": shock
        })
