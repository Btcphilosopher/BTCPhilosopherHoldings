import unittest
from decimal import Decimal
from hayekian.markets.price_discovery import OrderBook
from hayekian.markets.order import Order, OrderSide, OrderType

class TestPriceDiscovery(unittest.TestCase):
    def test_orderbook_matching(self):
        book = OrderBook(market_id="mkt_1", asset="COPPER")

        # Seller submits ask at 100
        ask = Order(
            agent_id="seller_1",
            market_id="mkt_1",
            asset="COPPER",
            side=OrderSide.ASK,
            order_type=OrderType.LIMIT,
            price=Decimal("100.00"),
            quantity=10.0,
            timestamp=1
        )
        txns = book.submit_order(ask)
        self.assertEqual(len(txns), 0)

        # Buyer submits bid at 110
        bid = Order(
            agent_id="buyer_1",
            market_id="mkt_1",
            asset="COPPER",
            side=OrderSide.BID,
            order_type=OrderType.LIMIT,
            price=Decimal("110.00"),
            quantity=5.0,
            timestamp=2
        )
        txns = book.submit_order(bid)
        self.assertEqual(len(txns), 1)
        self.assertEqual(txns[0].quantity, 5.0)
        self.assertEqual(txns[0].price, Decimal("105.00"))

if __name__ == "__main__":
    unittest.main()
