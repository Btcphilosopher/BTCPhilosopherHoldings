import unittest
from hayekian.knowledge.knowledge_claim import KnowledgeClaim
from hayekian.core.enums import KnowledgeType, EpistemicStatus

class TestKnowledgeClaim(unittest.TestCase):
    def test_temporal_validity(self):
        claim = KnowledgeClaim(
            agent_id="agent_01",
            domain="LOCAL_SUPPLY",
            location="LOCATION_ALPHA",
            timestamp=10,
            content={"soil": "clay"},
            knowledge_type=KnowledgeType.LOCAL,
            source="OBSERVATION",
            expires_at=50
        )

        self.assertTrue(claim.is_valid_at(10))
        self.assertFalse(claim.is_valid_at(5))   # Cannot be valid before timestamp
        self.assertTrue(claim.is_valid_at(30))
        self.assertFalse(claim.is_valid_at(51))  # Expired

if __name__ == "__main__":
    unittest.main()
