# HAYEKIAN PROOF-OF-KNOWLEDGE

> **A Computational Laboratory for Measuring, Tracing, Simulating, and Analyzing the Use of Dispersed Knowledge**

Based on the economic epistemics of Friedrich A. Hayek, specifically *"The Use of Knowledge in Society"* (1945).

## Core Philosophy

This is **NOT** a generic knowledge-management system, **NOT** a blockchain document log, **NOT** a centralized AI database, and **NOT** an attempt to construct an omniscient machine.

It is a scientific laboratory that asks:

> **HOW CAN A COMPUTATIONAL SYSTEM MEASURE, TRACE, SIMULATE AND ANALYSE THE USE OF DISPERSED KNOWLEDGE WITHOUT ASSUMING THAT ALL KNOWLEDGE EXISTS IN ONE CENTRAL DATABASE?**

### The Canonical System Loop
```text
OBSERVATION → LOCAL KNOWLEDGE → BELIEF → PLAN → ACTION → SIGNAL → COORDINATION → OUTCOME → LEARNING → NEW KNOWLEDGE
```

The central unit of analysis is **KNOWLEDGE-IN-ACTION**.

## Fundamental Principles

1. **Strict Knowledge Boundaries**: Every agent has strictly limited local information. No agent receives automatic access to global simulation state.
2. **Hindsight Bias Protection**: Temporal boundaries prevent future observations from leaking into past decision evaluations (`timestamp <= T`).
3. **Price as Knowledge Signal**: Prices compress heterogeneous local circumstances (scarcity, disruptions, preferences) into actionable quantitative signals.
4. **Tacit & Local Knowledge**: Models non-articulable experience proxies (`TacitKnowledgeProxy`) and contextual local facts (microclimates, component wear, local customer demand).
5. **Counterfactual Engine**: Compare identical initial conditions under Central Planning, Decentralized Markets, and Hybrid Systems.
6. **Epistemic Audit & Proof-of-Knowledge**: Track auditable proofs of agent knowledge states prior to decisions.

## Quick Start CLI

Run the canonical Hayekian Knowledge Problem experiment:

```bash
python -m hayekian.cli.main experiment knowledge-problem
```

Other available experiments:
- `mechanic` - Local tacit knowledge vs central diagnostic database
- `price-signal` - Regional shortage and price propagation across cities
- `entrepreneurial-discovery` - Uncovering hidden economic opportunities
- `rigid-price` - Shortages & adaptation under price flexibility controls
- `information-latency` - Communication delays and coordination degradation

## Project Structure

```text
src/hayekian/
    ├── core/           # Identifiers, units, enums, temporal bounds, result types
    ├── agents/         # Household, Firm, Entrepreneur, Trader, Planner, Institution
    ├── knowledge/      # KnowledgeClaim, TacitKnowledge, Provenance, KnowledgeGraph
    ├── epistemics/     # InformationSet, Uncertainty, Distance, Compression Loss
    ├── plans/          # Plans, Expectations, Intentions, Forecasts
    ├── actions/        # Actions, Decisions, Resource Allocations
    ├── markets/        # Limit/Market Order Books, Price Discovery, Matching
    ├── signals/        # PriceSignal, QuantitySignal, Profit/Loss Signals
    ├── coordination/   # Decentralized coordination, Plan matching, Conflict detection
    ├── discovery/      # Entrepreneurship, Arbitrage, Opportunity Creation
    ├── institutions/   # Rules, Property Rights, Governance, Contracts
    ├── simulation/     # Discrete-Event Clock, World, Event Queue, Replay
    ├── counterfactual/ # Central Planner vs Decentralized Market vs Hybrid Engine
    ├── metrics/        # KUR, Coordination Error, Latency, Adaptation Speed
    ├── economics/      # Utility, Production, Costs, Capital, Profit & Loss
    ├── api/            # FastAPI routes and schemas
    ├── storage/        # SQLAlchemy / Event sourcing models
    ├── telemetry/      # Event logging & tracing
    ├── visualisation/  # Knowledge network graph & market dynamics
    └── cli/            # CLI commands & runner
```

## Scientific Disclaimer

This software does **not** claim to "solve" Hayek's knowledge problem. It is a computational laboratory for studying it under specified mathematical and simulation parameters.
