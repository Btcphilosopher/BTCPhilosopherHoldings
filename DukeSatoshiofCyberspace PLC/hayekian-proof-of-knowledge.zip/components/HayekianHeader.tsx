'use client';

import React from 'react';
import { Cpu, Network, ShieldCheck, Scale, Terminal, Zap, BookOpen } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  running: boolean;
}

export const HayekianHeader: React.FC<HeaderProps> = ({ activeTab, setActiveTab, running }) => {
  const tabs = [
    { id: 'workbench', label: 'Laboratory Workbench', icon: Cpu },
    { id: 'counterfactual', label: 'Counterfactual Engine', icon: Scale },
    { id: 'knowledge-graph', label: 'Knowledge-in-Action Graph', icon: Network },
    { id: 'epistemic-audit', label: 'Epistemic Audit', icon: ShieldCheck },
    { id: 'proof-ledger', label: 'Proof-of-Knowledge Ledger', icon: Zap },
    { id: 'cli-terminal', label: 'CLI Terminal', icon: Terminal },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-serif font-bold text-lg">
                H
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
                  HAYEKIAN PROOF-OF-KNOWLEDGE
                  <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono border border-emerald-500/30">
                    LABORATORY v0.1.0
                  </span>
                </h1>
                <p className="text-xs text-slate-400">
                  Computational Engine for Dispersed Knowledge, Price Signals & Epistemic Coordination
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs bg-slate-950 p-2 rounded border border-slate-800 text-slate-400">
            <span className="text-slate-500">CANONICAL LOOP:</span>
            <span className="text-amber-400">Obs</span> → <span className="text-sky-400">LocalKnw</span> → <span className="text-purple-400">Belief</span> → <span className="text-emerald-400">Plan</span> → <span className="text-rose-400">Action</span> → <span className="text-amber-300">Signal</span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 mt-4 overflow-x-auto no-scrollbar border-t border-slate-800/80 pt-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-md transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 font-semibold shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
