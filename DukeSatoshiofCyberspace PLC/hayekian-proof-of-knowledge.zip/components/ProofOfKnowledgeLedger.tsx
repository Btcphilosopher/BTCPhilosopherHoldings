'use client';

import React from 'react';
import { Zap, ShieldCheck, CheckCircle2, Hash, Key } from 'lucide-react';

interface ProofLedgerProps {
  simulationData: any;
}

export const ProofOfKnowledgeLedger: React.FC<ProofLedgerProps> = ({ simulationData }) => {
  const proofs = simulationData?.proofs_of_knowledge || [
    {
      proof_id: 'proof_98a72b',
      agent_id: 'firm_01',
      knowledge_id: 'knw_3812',
      timestamp: 100,
      decision_id: 'dec_4491',
      knowledge_state_hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      decision_context: { event: 'CAPACITY_LOSS', loss_pct: 0.4 }
    },
    {
      proof_id: 'proof_12c90f',
      agent_id: 'entrepreneur_02',
      knowledge_id: 'knw_8819',
      timestamp: 104,
      decision_id: 'dec_9921',
      knowledge_state_hash: '8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4',
      decision_context: { opportunity: 'SPATIAL_ARBITRAGE', spread: 15.5 }
    }
  ];

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
          <Zap className="w-4 h-4 text-purple-400" />
          Proof-of-Knowledge State Hash Ledger
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Cryptographically hashing an agent&apos;s local knowledge state before decision execution. Proves that the action was derived from local observations rather than global state leakage.
        </p>
      </div>

      {/* Ledger Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-2">
          <Hash className="w-4 h-4 text-amber-400" />
          Auditable Knowledge State Hash Receipts
        </h3>

        <div className="overflow-x-auto font-mono text-xs">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2 px-3 font-semibold">Proof ID</th>
                <th className="py-2 px-3 font-semibold">Agent</th>
                <th className="py-2 px-3 font-semibold">Tick</th>
                <th className="py-2 px-3 font-semibold">Knowledge State Hash (SHA-256)</th>
                <th className="py-2 px-3 font-semibold">Context Payload</th>
                <th className="py-2 px-3 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {proofs.map((p: any) => (
                <tr key={p.proof_id} className="hover:bg-slate-950/40">
                  <td className="py-2.5 px-3 text-amber-400 font-bold">{p.proof_id}</td>
                  <td className="py-2.5 px-3 text-sky-400">{p.agent_id}</td>
                  <td className="py-2.5 px-3">T={p.timestamp}</td>
                  <td className="py-2.5 px-3 text-slate-400 text-[10px] truncate max-w-[200px]">
                    {p.knowledge_state_hash}
                  </td>
                  <td className="py-2.5 px-3 text-emerald-400 text-[11px]">
                    {JSON.stringify(p.decision_context)}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                      VERIFIED
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
