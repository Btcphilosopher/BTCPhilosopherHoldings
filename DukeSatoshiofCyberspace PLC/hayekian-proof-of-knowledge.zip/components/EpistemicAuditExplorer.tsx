'use client';

import React, { useState } from 'react';
import { ShieldCheck, Lock, AlertOctagon, HelpCircle, CheckCircle, ArrowRight, Clock } from 'lucide-react';

interface AuditExplorerProps {
  simulationData: any;
}

export const EpistemicAuditExplorer: React.FC<AuditExplorerProps> = ({ simulationData }) => {
  const [selectedAgent, setSelectedAgent] = useState('firm_01');
  const [selectedTick, setSelectedTick] = useState(105);

  const agents = ['firm_01', 'firm_02', 'entrepreneur_01', 'trader_01', 'household_01'];

  const whatKnew = [
    { domain: 'LOCAL_SUPPLY', detail: 'Copper valve reserve down 40% at factory #4', location: 'LOCATION_ALPHA', timestamp: 100 },
    { domain: 'LOCAL_PRICE', detail: 'Market price bid raised to $125.00', location: 'LOCATION_ALPHA', timestamp: 102 }
  ];

  const whatBelieved = [
    { key: 'COPPER_VALVES_EXPECTED_PRICE', val: '$135.00 (+28% expected inflation)' },
    { key: 'LOCAL_SCARCITY_ESTIMATE', val: '0.82 (High Scarcity)' }
  ];

  const whatNotKnew = [
    'Primary cause of factory outage (Trucking fuel strike at Location Alpha depot)',
    'Global steel reserve inventory at Location Beta warehouse #9'
  ];

  const availableElsewhere = [
    { owner: 'trader_03', fact: '100 units of alternative steel components sitting unallocated in Location Beta' }
  ];

  const arrivedLater = [
    { tick: 125, fact: 'Transport line reopened; copper valve price returned to equilibrium $105.00' }
  ];

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          Temporal Epistemic Decision Auditor (Hindsight Bias Protection)
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Evaluating whether an agent&apos;s action was rational strictly using information available at decision time <span className="text-amber-400 font-mono">timestamp ≤ T</span>. Future observations (<span className="text-rose-400 font-mono">timestamp &gt; T</span>) are strictly isolated.
        </p>

        <div className="mt-4 flex flex-wrap items-center gap-4 font-mono text-xs">
          <div>
            <label className="text-slate-400 mr-2">Audit Agent:</label>
            <select
              value={selectedAgent}
              onChange={(e) => setSelectedAgent(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-slate-200"
            >
              {agents.map((a) => (
                <option key={a} value={a}>{a}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-slate-400 mr-2">Decision Tick (T):</label>
            <input
              type="number"
              value={selectedTick}
              onChange={(e) => setSelectedTick(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-200 w-20"
            />
          </div>

          <div className="ml-auto px-3 py-1 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold flex items-center gap-1.5">
            <CheckCircle className="w-3.5 h-3.5" />
            RATIONAL ACTION UNDER LIMITED KNOWLEDGE
          </div>
        </div>
      </div>

      {/* Audit Panels Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
        {/* Panel 1: What the Agent Knew */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-xs font-semibold text-emerald-400 mb-3 uppercase tracking-wider flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            1. What Agent Knew at T={selectedTick} (Valid Claims)
          </h3>
          <div className="space-y-2">
            {whatKnew.map((k, i) => (
              <div key={i} className="p-3 rounded bg-slate-950 border border-slate-800/80">
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span className="text-amber-300 font-bold">{k.domain}</span>
                  <span>T={k.timestamp}</span>
                </div>
                <p className="text-slate-200">{k.detail}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Panel 2: What the Agent Believed */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-xs font-semibold text-purple-400 mb-3 uppercase tracking-wider flex items-center gap-2">
            <Clock className="w-4 h-4 text-purple-400" />
            2. Epistemic Belief State at T={selectedTick}
          </h3>
          <div className="space-y-2">
            {whatBelieved.map((b, i) => (
              <div key={i} className="p-3 rounded bg-slate-950 border border-slate-800/80 flex justify-between items-center">
                <span className="text-slate-400">{b.key}:</span>
                <span className="text-purple-300 font-bold">{b.val}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Panel 3: What the Agent Did NOT Know */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-xs font-semibold text-amber-400 mb-3 uppercase tracking-wider flex items-center gap-2">
            <Lock className="w-4 h-4 text-amber-400" />
            3. Local Ignorance Boundary (Unobserved Facts)
          </h3>
          <div className="space-y-2">
            {whatNotKnew.map((nk, i) => (
              <div key={i} className="p-3 rounded bg-slate-950 border border-slate-800/80 text-slate-300">
                • {nk}
              </div>
            ))}
          </div>
        </div>

        {/* Panel 4: Information Arrived Later */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-xs font-semibold text-rose-400 mb-3 uppercase tracking-wider flex items-center gap-2">
            <AlertOctagon className="w-4 h-4 text-rose-400" />
            4. Post-Decision Observations (Timestamp &gt; T)
          </h3>
          <div className="space-y-2">
            {arrivedLater.map((al, i) => (
              <div key={i} className="p-3 rounded bg-slate-950 border border-slate-800/80">
                <div className="text-[10px] text-rose-400 font-bold mb-0.5">ISOLATED FROM T={selectedTick}: Arrived at T={al.tick}</div>
                <p className="text-slate-300">{al.fact}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
