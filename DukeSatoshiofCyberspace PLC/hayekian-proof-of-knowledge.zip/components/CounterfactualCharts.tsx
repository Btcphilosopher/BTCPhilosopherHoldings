'use client';

import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
} from 'recharts';
import { Scale, CheckCircle2, AlertTriangle, Cpu } from 'lucide-react';

interface CounterfactualProps {
  comparisonData: any;
}

export const CounterfactualCharts: React.FC<CounterfactualProps> = ({ comparisonData }) => {
  if (!comparisonData) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-12 text-center text-slate-400">
        <Scale className="w-8 h-8 mx-auto text-slate-600 mb-2" />
        <p className="text-sm">Run a simulation from the Laboratory Workbench to view counterfactual results.</p>
      </div>
    );
  }

  const wa = comparisonData.world_a_central_planner?.metrics;
  const wb = comparisonData.world_b_decentralised_market?.metrics;
  const wc = comparisonData.world_c_hybrid_system?.metrics;
  const summary = comparisonData.comparison_summary;

  const barMetricsData = [
    {
      name: 'Knowledge Utilisation (KUR)',
      'World A (Planner)': Number((wa?.knowledge_utilisation_rate * 100).toFixed(1)),
      'World B (Market)': Number((wb?.knowledge_utilisation_rate * 100).toFixed(1)),
      'World C (Hybrid)': Number((wc?.knowledge_utilisation_rate * 100).toFixed(1)),
    },
    {
      name: 'Local Knowledge Utilisation',
      'World A (Planner)': Number((wa?.local_knowledge_utilisation * 100).toFixed(1)),
      'World B (Market)': Number((wb?.local_knowledge_utilisation * 100).toFixed(1)),
      'World C (Hybrid)': Number((wc?.local_knowledge_utilisation * 100).toFixed(1)),
    },
    {
      name: 'Plan Conflict Rate',
      'World A (Planner)': Number((wa?.plan_conflict_rate * 100).toFixed(1)),
      'World B (Market)': Number((wb?.plan_conflict_rate * 100).toFixed(1)),
      'World C (Hybrid)': Number((wc?.plan_conflict_rate * 100).toFixed(1)),
    },
  ];

  const outputData = [
    {
      name: 'Economic Output ($)',
      'World A (Planner)': wa?.economic_output_total || 0,
      'World B (Market)': wb?.economic_output_total || 0,
      'World C (Hybrid)': wc?.economic_output_total || 0,
    },
  ];

  const latencyData = [
    {
      name: 'Adaptation Latency (Ticks)',
      'World A (Planner)': wa?.adaptation_speed_ticks || 0,
      'World B (Market)': wb?.adaptation_speed_ticks || 0,
      'World C (Hybrid)': wc?.adaptation_speed_ticks || 0,
    },
    {
      name: 'Coordination Error Index',
      'World A (Planner)': wa?.coordination_error || 0,
      'World B (Market)': wb?.coordination_error || 0,
      'World C (Hybrid)': wc?.coordination_error || 0,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
          <Scale className="w-4 h-4 text-amber-400" />
          Counterfactual Scenario Comparison Engine
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Holding constant: resources, preferences, initial conditions, technology, and random seed ({comparisonData.seed}). Changing ONLY knowledge architecture and coordination mechanism.
        </p>

        {summary && (
          <div className="mt-4 p-4 rounded-lg bg-slate-950 border border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
            <div className="border-l-2 border-emerald-500 pl-3">
              <span className="text-slate-400 block text-[10px]">KUR GAIN (MARKET VS PLANNER)</span>
              <span className="text-emerald-400 text-base font-bold">
                +{(summary.kur_difference * 100).toFixed(1)}%
              </span>
            </div>

            <div className="border-l-2 border-sky-500 pl-3">
              <span className="text-slate-400 block text-[10px]">ERROR REDUCTION</span>
              <span className="text-sky-400 text-base font-bold">
                -{summary.coordination_error_reduction.toFixed(1)} Units
              </span>
            </div>

            <div className="border-l-2 border-amber-500 pl-3">
              <span className="text-slate-400 block text-[10px]">OUTPUT GAIN</span>
              <span className="text-amber-400 text-base font-bold">
                +${summary.output_gain_decentralised.toLocaleString()}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Chart Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Knowledge Utilization */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-xs font-mono uppercase tracking-wider text-slate-300 mb-4">
            Knowledge Utilisation & Local Efficiency (%)
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barMetricsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" stroke="#94a3b8" tick={{ fontSize: 10 }} />
                <YAxis stroke="#94a3b8" tick={{ fontSize: 10 }} unit="%" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#334155', borderRadius: '6px', fontSize: '11px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Bar dataKey="World A (Planner)" fill="#ef4444" />
                <Bar dataKey="World B (Market)" fill="#10b981" />
                <Bar dataKey="World C (Hybrid)" fill="#f59e0b" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Adaptation & Error */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-xs font-mono uppercase tracking-wider text-slate-300 mb-4">
            Adaptation Latency & Coordination Error
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={latencyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" stroke="#94a3b8" tick={{ fontSize: 10 }} />
                <YAxis stroke="#94a3b8" tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#334155', borderRadius: '6px', fontSize: '11px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Bar dataKey="World A (Planner)" fill="#ef4444" />
                <Bar dataKey="World B (Market)" fill="#10b981" />
                <Bar dataKey="World C (Hybrid)" fill="#f59e0b" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Structured Comparison Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-4">
          Detailed Metric Matrix across Architectures
        </h3>
        <div className="overflow-x-auto font-mono text-xs">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5 px-3 font-semibold">Metric</th>
                <th className="py-2.5 px-3 font-semibold text-rose-400">World A (Central Planner)</th>
                <th className="py-2.5 px-3 font-semibold text-emerald-400">World B (Decentralised Market)</th>
                <th className="py-2.5 px-3 font-semibold text-amber-400">World C (Hybrid System)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              <tr>
                <td className="py-2.5 px-3 font-sans text-slate-300">Knowledge Utilisation Rate (KUR)</td>
                <td className="py-2.5 px-3 text-rose-400">{(wa?.knowledge_utilisation_rate * 100).toFixed(2)}%</td>
                <td className="py-2.5 px-3 text-emerald-400">{(wb?.knowledge_utilisation_rate * 100).toFixed(2)}%</td>
                <td className="py-2.5 px-3 text-amber-400">{(wc?.knowledge_utilisation_rate * 100).toFixed(2)}%</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-sans text-slate-300">Coordination Error Index</td>
                <td className="py-2.5 px-3 text-rose-400">{wa?.coordination_error.toFixed(2)}</td>
                <td className="py-2.5 px-3 text-emerald-400">{wb?.coordination_error.toFixed(2)}</td>
                <td className="py-2.5 px-3 text-amber-400">{wc?.coordination_error.toFixed(2)}</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-sans text-slate-300">Adaptation Latency</td>
                <td className="py-2.5 px-3">{wa?.adaptation_speed_ticks.toFixed(1)} Ticks</td>
                <td className="py-2.5 px-3 text-emerald-400">{wb?.adaptation_speed_ticks.toFixed(1)} Ticks</td>
                <td className="py-2.5 px-3">{wc?.adaptation_speed_ticks.toFixed(1)} Ticks</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-sans text-slate-300">Total Economic Output</td>
                <td className="py-2.5 px-3">${wa?.economic_output_total.toLocaleString()}</td>
                <td className="py-2.5 px-3 text-emerald-400">${wb?.economic_output_total.toLocaleString()}</td>
                <td className="py-2.5 px-3 text-amber-400">${wc?.economic_output_total.toLocaleString()}</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-sans text-slate-300">Information Compression Ratio</td>
                <td className="py-2.5 px-3 text-slate-500">N/A (Central DB)</td>
                <td className="py-2.5 px-3 text-emerald-400">{(wb?.information_compression_ratio * 100).toFixed(1)}%</td>
                <td className="py-2.5 px-3 text-amber-400">{(wc?.information_compression_ratio * 100).toFixed(1)}%</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
