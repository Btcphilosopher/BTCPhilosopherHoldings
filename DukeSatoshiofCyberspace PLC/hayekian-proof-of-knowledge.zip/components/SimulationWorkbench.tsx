'use client';

import React, { useState } from 'react';
import { Play, RotateCcw, Activity, ShieldAlert, Cpu, Lightbulb, Zap, TrendingUp, HelpCircle } from 'lucide-react';

interface WorkbenchProps {
  onRunSimulation: (params: any) => Promise<void>;
  running: boolean;
  simulationData: any;
}

export const SimulationWorkbench: React.FC<WorkbenchProps> = ({
  onRunSimulation,
  running,
  simulationData,
}) => {
  const [experimentName, setExperimentName] = useState('knowledge-problem');
  const [duration, setDuration] = useState(150);
  const [seed, setSeed] = useState(42);
  const [priceFlexibility, setPriceFlexibility] = useState(1.0);
  const [latency, setLatency] = useState(0);

  const experiments = [
    {
      id: 'knowledge-problem',
      name: '1. The Knowledge Problem',
      desc: '100 agents & 4 markets facing a major supply shock at T=100. Only local agents observe primary cause.',
    },
    {
      id: 'mechanic',
      name: '2. The Mechanic Experiment',
      desc: '100 machines with random faults. Compares local tacit mechanics vs central diagnostic database.',
    },
    {
      id: 'price-signal',
      name: '3. Price Signal Propagation',
      desc: 'Multiple cities with regional shortages. Measures how prices propagate information without global database.',
    },
    {
      id: 'entrepreneurial-discovery',
      name: '4. Entrepreneurial Discovery',
      desc: 'Hides economically valuable opportunities from global state. Measures knowledge creation by entrepreneurs.',
    },
    {
      id: 'rigid-price',
      name: '5. Rigid Price Experiment',
      desc: 'Tests market coordination under rigid price controls vs flexible prices during unexpected supply shocks.',
    },
    {
      id: 'information-latency',
      name: '6. Information Latency',
      desc: 'Introduces artificial communication delays (0 to 100 ticks) and measures coordination degradation.',
    },
  ];

  const handleRun = () => {
    onRunSimulation({ experimentName, duration, seed, priceFlexibility, latency });
  };

  const comp = simulationData?.comparison?.comparison_summary;
  const metricsB = simulationData?.comparison?.world_b_decentralised_market?.metrics;
  const metricsA = simulationData?.comparison?.world_a_central_planner?.metrics;

  return (
    <div className="space-y-6">
      {/* Top Banner Notice */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded bg-amber-500/10 border border-amber-500/30 text-amber-400 mt-0.5">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-slate-100">
              Computational Epistemics Laboratory
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Testing Hayekian proposition: <span className="text-amber-300 font-mono">Social Knowledge ≠ Sum of Database Records</span>. Every agent operates under strict local information boundaries.
            </p>
          </div>
        </div>

        <button
          onClick={handleRun}
          disabled={running}
          className="flex items-center justify-center gap-2 px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs rounded-md shadow-lg shadow-amber-500/10 transition-all disabled:opacity-50"
        >
          {running ? (
            <>
              <Activity className="w-4 h-4 animate-spin" />
              Simulating Discrete Events...
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" />
              Execute Simulation Engine
            </>
          )}
        </button>
      </div>

      {/* Setup Form Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Experiment Selector */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-2">
            <Activity className="w-4 h-4 text-amber-400" />
            Select Canonical Experiment Scenario
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {experiments.map((exp) => {
              const selected = experimentName === exp.id;
              return (
                <div
                  key={exp.id}
                  onClick={() => setExperimentName(exp.id)}
                  className={`p-3.5 rounded-lg border cursor-pointer transition-all ${
                    selected
                      ? 'bg-amber-500/10 border-amber-500 text-slate-100 ring-1 ring-amber-500/50'
                      : 'bg-slate-950/60 border-slate-800/80 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-semibold text-white">{exp.name}</span>
                    {selected && (
                      <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">{exp.desc}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Controls Parameters */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-2">
            <Zap className="w-4 h-4 text-emerald-400" />
            Simulation Parameters
          </h3>

          <div className="space-y-3 font-mono text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Duration Ticks ({duration})</label>
              <input
                type="range"
                min="50"
                max="500"
                step="25"
                value={duration}
                onChange={(e) => setDuration(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-800 rounded"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Random Seed ({seed})</label>
              <input
                type="number"
                value={seed}
                onChange={(e) => setSeed(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">
                Price Flexibility ({priceFlexibility === 1 ? '1.0 (Fully Flexible)' : priceFlexibility.toFixed(1)})
              </label>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.1"
                value={priceFlexibility}
                onChange={(e) => setPriceFlexibility(Number(e.target.value))}
                className="w-full accent-emerald-500 bg-slate-800 rounded"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">
                Signal Latency Delay ({latency} Ticks)
              </label>
              <input
                type="range"
                min="0"
                max="50"
                step="5"
                value={latency}
                onChange={(e) => setLatency(Number(e.target.value))}
                className="w-full accent-sky-500 bg-slate-800 rounded"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Metrics Cards Display */}
      {metricsB && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
            <span className="text-[10px] font-mono text-slate-400 block uppercase">Knowledge Utilisation (KUR)</span>
            <div className="text-xl font-bold font-mono text-emerald-400 mt-1">
              {(metricsB.knowledge_utilisation_rate * 100).toFixed(1)}%
            </div>
            <span className="text-[10px] text-slate-500">vs Central: {(metricsA?.knowledge_utilisation_rate * 100).toFixed(1)}%</span>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
            <span className="text-[10px] font-mono text-slate-400 block uppercase">Coordination Error</span>
            <div className="text-xl font-bold font-mono text-rose-400 mt-1">
              {metricsB.coordination_error.toFixed(1)}
            </div>
            <span className="text-[10px] text-slate-500">Central: {metricsA?.coordination_error.toFixed(1)}</span>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
            <span className="text-[10px] font-mono text-slate-400 block uppercase">Adaptation Latency</span>
            <div className="text-xl font-bold font-mono text-sky-400 mt-1">
              {metricsB.adaptation_speed_ticks.toFixed(1)} Ticks
            </div>
            <span className="text-[10px] text-slate-500">Central: {metricsA?.adaptation_speed_ticks.toFixed(1)} Ticks</span>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
            <span className="text-[10px] font-mono text-slate-400 block uppercase">Economic Output</span>
            <div className="text-xl font-bold font-mono text-amber-400 mt-1">
              ${metricsB.economic_output_total.toLocaleString()}
            </div>
            <span className="text-[10px] text-slate-500">Central: ${metricsA?.economic_output_total.toLocaleString()}</span>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
            <span className="text-[10px] font-mono text-slate-400 block uppercase">Proof-of-Knowledge</span>
            <div className="text-xl font-bold font-mono text-purple-400 mt-1">
              {simulationData?.proofs_of_knowledge?.length || 0} Records
            </div>
            <span className="text-[10px] text-slate-500">Auditable Hashes</span>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
            <span className="text-[10px] font-mono text-slate-400 block uppercase">Discoveries Created</span>
            <div className="text-xl font-bold font-mono text-yellow-400 mt-1">
              {simulationData?.discoveries?.length || 0} Opps
            </div>
            <span className="text-[10px] text-slate-500">Knowledge Creation</span>
          </div>
        </div>
      )}

      {/* Price Signal History */}
      {simulationData?.decentralised_run?.price_history && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-3 flex items-center justify-between">
            <span className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              Decentralized Price Formation (Order Book Signals)
            </span>
            <span className="text-[10px] text-amber-400">Supply Shock Triggered at T=100</span>
          </h3>

          <div className="h-40 flex items-end gap-1 pt-4 border-b border-slate-800 pb-2 overflow-x-auto">
            {simulationData.decentralised_run.price_history.slice(-40).map((pt: any, idx: number) => {
              const hPct = Math.min(100, Math.max(10, ((pt.price - 80) / 100) * 100));
              const isShock = pt.tick >= 100;
              return (
                <div key={idx} className="flex-1 flex flex-col items-center group relative min-w-[12px]">
                  <div
                    style={{ height: `${hPct}%` }}
                    className={`w-full rounded-t transition-all ${
                      isShock ? 'bg-amber-500 group-hover:bg-amber-400' : 'bg-sky-500 group-hover:bg-sky-400'
                    }`}
                  />
                  <div className="hidden group-hover:block absolute -top-8 bg-slate-950 text-[10px] font-mono text-slate-200 px-1.5 py-0.5 rounded border border-slate-700 z-10 whitespace-nowrap shadow-md">
                    T={pt.tick}: ${pt.price.toFixed(2)} ({pt.asset})
                  </div>
                </div>
              );
            })}
          </div>
          <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-2">
            <span>T=0 (Baseline Equilibrium)</span>
            <span className="text-amber-400">T=100 (Shock: Capacity Loss)</span>
            <span>T={duration} (Price Propagation & Adjustment)</span>
          </div>
        </div>
      )}
    </div>
  );
};
