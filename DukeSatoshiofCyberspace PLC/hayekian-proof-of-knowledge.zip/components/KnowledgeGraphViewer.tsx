'use client';

import React, { useState } from 'react';
import { Network, Search, Filter, Eye, ArrowRight, Database, Clock, Zap } from 'lucide-react';

interface GraphViewerProps {
  graphData: any;
}

export const KnowledgeGraphViewer: React.FC<GraphViewerProps> = ({ graphData }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedNode, setSelectedNode] = useState<any>(null);

  if (!graphData || !graphData.nodes) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-12 text-center text-slate-400">
        <Network className="w-8 h-8 mx-auto text-slate-600 mb-2" />
        <p className="text-sm">Run a simulation from the Laboratory Workbench to generate the Directed Knowledge Graph.</p>
      </div>
    );
  }

  const nodes = graphData.nodes || [];
  const edges = graphData.edges || [];

  const filteredNodes = nodes.filter((n: any) =>
    n.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (n.agent_id && n.agent_id.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (n.node_type && n.node_type.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      {/* Graph Overview Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
            <Network className="w-4 h-4 text-emerald-400" />
            Directed Temporal Knowledge Graph (Provenances & Epistemic Trace)
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Auditing the full Hayekian Loop: <span className="text-amber-300 font-mono">Observation → Local Knowledge → Belief → Plan → Action → Order → Price Signal → Response</span>.
          </p>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-slate-300">
            Nodes: <span className="text-emerald-400 font-bold">{nodes.length}</span>
          </div>
          <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-slate-300">
            Edges: <span className="text-sky-400 font-bold">{edges.length}</span>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Node Explorer List */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
              <input
                type="text"
                placeholder="Search nodes by agent ID, node ID, or type..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-md pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {filteredNodes.slice(0, 30).map((node: any) => {
              const isSelected = selectedNode?.id === node.id;
              return (
                <div
                  key={node.id}
                  onClick={() => setSelectedNode(node)}
                  className={`p-3 rounded-md border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-amber-500/10 border-amber-500 text-slate-100 ring-1 ring-amber-500/40'
                      : 'bg-slate-950/60 border-slate-800/80 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between font-mono text-xs mb-1">
                    <span className="font-semibold text-white flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      {node.id}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                      T={node.timestamp || 0}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono">
                    <span>Agent: <strong className="text-amber-300">{node.agent_id || 'SYSTEM'}</strong></span>
                    <span>Type: <strong className="text-sky-300">{node.node_type || 'KNOWLEDGE_CLAIM'}</strong></span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Node Detail Inspector */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-2">
            <Eye className="w-4 h-4 text-amber-400" />
            Epistemic Node Inspector
          </h3>

          {selectedNode ? (
            <div className="space-y-4 font-mono text-xs">
              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
                <div className="flex justify-between text-slate-400 border-b border-slate-800/80 pb-2">
                  <span>NODE ID</span>
                  <span className="text-amber-400 font-bold">{selectedNode.id}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>TIMESTAMP</span>
                  <span className="text-slate-200">T={selectedNode.timestamp || 0}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>AGENT OWNER</span>
                  <span className="text-sky-400">{selectedNode.agent_id || 'SYSTEM'}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>NODE TYPE</span>
                  <span className="text-emerald-400">{selectedNode.node_type || 'LOCAL_FACT'}</span>
                </div>
              </div>

              <div>
                <span className="text-slate-400 block mb-1">RAW ATTRIBUTES / CONTENT</span>
                <pre className="bg-slate-950 p-3 rounded border border-slate-800 text-[11px] text-slate-300 overflow-x-auto">
                  {JSON.stringify(selectedNode, null, 2)}
                </pre>
              </div>
            </div>
          ) : (
            <div className="py-12 text-center text-slate-500 font-mono text-xs">
              Click any node on the left to inspect its temporal details and provenance chain.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
