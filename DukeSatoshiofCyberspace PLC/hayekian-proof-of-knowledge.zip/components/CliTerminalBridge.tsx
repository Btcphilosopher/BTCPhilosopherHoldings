'use client';

import React, { useState } from 'react';
import { Terminal, Play, RotateCcw, Copy, Check } from 'lucide-react';

export const CliTerminalBridge: React.FC = () => {
  const [command, setCommand] = useState('experiment knowledge-problem');
  const [output, setOutput] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleRunCommand = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/cli', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command }),
      });
      const data = await res.json();
      if (data.output) {
        setOutput(data.output);
      } else if (data.error) {
        setOutput(`Error: ${data.error}`);
      }
    } catch (err: any) {
      setOutput(`Execution failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (output) {
      navigator.clipboard.writeText(output);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
          <Terminal className="w-4 h-4 text-amber-400" />
          Python CLI Command Terminal Runner
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Executes the Python implementation directly: <span className="text-amber-300 font-mono">python -m hayekian.cli.main experiment knowledge-problem</span>.
        </p>
      </div>

      {/* Terminal Container */}
      <div className="bg-slate-950 border border-slate-800 rounded-lg shadow-2xl overflow-hidden font-mono text-xs">
        {/* Terminal Header Bar */}
        <div className="bg-slate-900 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-rose-500 inline-block" />
            <span className="w-3 h-3 rounded-full bg-amber-500 inline-block" />
            <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block" />
            <span className="text-slate-400 ml-2 text-[11px]">hayekian-proof-of-knowledge-cli</span>
          </div>

          <div className="flex items-center gap-2">
            {output && (
              <button
                onClick={handleCopy}
                className="text-slate-400 hover:text-slate-200 flex items-center gap-1 text-[11px] px-2 py-1 rounded bg-slate-800"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            )}
          </div>
        </div>

        {/* Command Input Row */}
        <div className="p-4 border-b border-slate-800/80 bg-slate-900/40 flex items-center gap-3">
          <span className="text-amber-400 font-bold">$ python -m hayekian.cli.main</span>
          <input
            type="text"
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            className="flex-1 bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-slate-200 font-mono focus:outline-none focus:border-amber-500 text-xs"
            placeholder="experiment knowledge-problem"
          />
          <button
            onClick={handleRunCommand}
            disabled={loading}
            className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded flex items-center gap-1.5 transition-all text-xs"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            {loading ? 'Running...' : 'Execute'}
          </button>
        </div>

        {/* Terminal Output Area */}
        <div className="p-5 min-h-[350px] max-h-[500px] overflow-y-auto text-slate-300 leading-relaxed font-mono whitespace-pre-wrap">
          {output ? (
            output
          ) : (
            <span className="text-slate-600 italic">
              Click &quot;Execute&quot; above to run the Python CLI entrypoint and view live canonical research results.
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
