/**
 * VTOL CONTROL DESK
 * Duke Satoshi of Cyberspace PLC
 * 
 * British Aerospace Engineering Grade Digital Workstation
 * Rolls-Royce / BAe Systems Computational Architecture
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  ExecutionEnvironment, 
  FlightMode, 
  VehicleState 
} from '../types/vtol';
import { FlightCoreRuntime } from '../core/flightCore';
import { ThreeVtolCanvas } from './ThreeVtolCanvas';
import { SignatureDemosPanel } from './SignatureDemosPanel';
import { SystemSchematic } from './SystemSchematic';
import { DigitalTwinFleet } from './DigitalTwinFleet';
import { ControlLab } from './ControlLab';
import { MonteCarloLab } from './MonteCarloLab';
import { AircraftDesignLab } from './AircraftDesignLab';
import { FlightReplay } from './FlightReplay';
import { RequirementsTraceability } from './RequirementsTraceability';
import { DocumentationBrowser } from './DocumentationBrowser';

import { 
  Compass, 
  ShieldAlert, 
  CheckCircle2, 
  AlertTriangle, 
  Activity, 
  Zap, 
  Fan, 
  MapPin, 
  Gauge, 
  Cpu, 
  FileText,
  Sliders,
  BarChart3,
  RotateCcw,
  Play
} from 'lucide-react';

type TabView = 
  | 'OVERVIEW'
  | 'PROPULSION'
  | 'ENERGY'
  | 'NAVIGATION'
  | 'DIGITAL_TWIN'
  | 'CONTROL_LAB'
  | 'MONTE_CARLO'
  | 'DESIGN_LAB'
  | 'REPLAY'
  | 'REQUIREMENTS'
  | 'SCHEMATIC'
  | 'DOCS';

export const MainControlDesk: React.FC = () => {
  const runtimeRef = useRef<FlightCoreRuntime>(new FlightCoreRuntime());
  const [vehicleState, setVehicleState] = useState<VehicleState>(() => runtimeRef.current.getState());
  const [activeTab, setActiveTab] = useState<TabView>('OVERVIEW');
  const [activeDemo, setActiveDemo] = useState<number | null>(null);

  // Simulation tick loop (runs at ~20 Hz in UI, driving 1,000 Hz internal physics)
  useEffect(() => {
    const interval = setInterval(() => {
      runtimeRef.current.tick(0.05); // 50ms tick
      setVehicleState({ ...runtimeRef.current.getState() });
    }, 50);

    return () => clearInterval(interval);
  }, []);

  const handleRunDemo = (demoId: number) => {
    setActiveDemo(demoId);
    switch (demoId) {
      case 1:
        runtimeRef.current.triggerDemoVerticalTakeoff();
        setActiveTab('OVERVIEW');
        break;
      case 2:
        runtimeRef.current.triggerDemoTransition();
        setActiveTab('OVERVIEW');
        break;
      case 3:
        runtimeRef.current.triggerDemoMotorFailure();
        setActiveTab('PROPULSION');
        break;
      case 4:
        runtimeRef.current.triggerDemoLowBattery();
        setActiveTab('ENERGY');
        break;
      case 5:
        setActiveTab('DIGITAL_TWIN');
        break;
      case 6:
        setActiveTab('REPLAY');
        break;
      case 7:
        setActiveTab('CONTROL_LAB');
        break;
      case 8:
        setActiveTab('MONTE_CARLO');
        break;
      case 9:
        setActiveTab('DESIGN_LAB');
        break;
      case 10:
        runtimeRef.current.triggerFullMission();
        setActiveTab('OVERVIEW');
        break;
    }
  };

  const handleRestoreMotors = () => {
    runtimeRef.current.restoreAllMotors();
    setVehicleState({ ...runtimeRef.current.getState() });
  };

  const handleEnvChange = (env: ExecutionEnvironment) => {
    runtimeRef.current.setEnvironment(env);
    setVehicleState({ ...runtimeRef.current.getState() });
  };

  return (
    <div className="min-h-screen bg-[#07090e] text-[#e2e8f0] flex flex-col font-sans selection:bg-sky-700 selection:text-white">
      
      {/* 1. TOP BAR CONTRACT (Strict 3-zone layout) */}
      <header className="flex items-center justify-between px-6 py-3.5 bg-[#0b0f17] border-b border-slate-800 shrink-0">
        
        {/* Zone 1: Single text wordmark in display face */}
        <div className="flex items-center gap-2">
          <span className="text-base font-tech font-bold tracking-wider text-slate-100 uppercase">
            VTOL.OS <span className="text-sky-400">·</span> DUKE SATOSHI PLC
          </span>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-5 text-xs font-mono-aerospace text-slate-400">
          <button
            onClick={() => setActiveTab('OVERVIEW')}
            className={`hover:text-slate-100 transition-colors ${activeTab === 'OVERVIEW' ? 'text-sky-400 font-bold border-b-2 border-sky-400 pb-0.5' : ''}`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('PROPULSION')}
            className={`hover:text-slate-100 transition-colors ${activeTab === 'PROPULSION' ? 'text-sky-400 font-bold border-b-2 border-sky-400 pb-0.5' : ''}`}
          >
            Propulsion (12)
          </button>
          <button
            onClick={() => setActiveTab('ENERGY')}
            className={`hover:text-slate-100 transition-colors ${activeTab === 'ENERGY' ? 'text-sky-400 font-bold border-b-2 border-sky-400 pb-0.5' : ''}`}
          >
            Energy.OS
          </button>
          <button
            onClick={() => setActiveTab('NAVIGATION')}
            className={`hover:text-slate-100 transition-colors ${activeTab === 'NAVIGATION' ? 'text-sky-400 font-bold border-b-2 border-sky-400 pb-0.5' : ''}`}
          >
            Navigation
          </button>
          <button
            onClick={() => setActiveTab('DIGITAL_TWIN')}
            className={`hover:text-slate-100 transition-colors ${activeTab === 'DIGITAL_TWIN' ? 'text-sky-400 font-bold border-b-2 border-sky-400 pb-0.5' : ''}`}
          >
            Digital Twin
          </button>
          <button
            onClick={() => setActiveTab('CONTROL_LAB')}
            className={`hover:text-slate-100 transition-colors ${activeTab === 'CONTROL_LAB' ? 'text-sky-400 font-bold border-b-2 border-sky-400 pb-0.5' : ''}`}
          >
            Control Lab
          </button>
          <button
            onClick={() => setActiveTab('MONTE_CARLO')}
            className={`hover:text-slate-100 transition-colors ${activeTab === 'MONTE_CARLO' ? 'text-sky-400 font-bold border-b-2 border-sky-400 pb-0.5' : ''}`}
          >
            Monte Carlo
          </button>
          <button
            onClick={() => setActiveTab('DESIGN_LAB')}
            className={`hover:text-slate-100 transition-colors ${activeTab === 'DESIGN_LAB' ? 'text-sky-400 font-bold border-b-2 border-sky-400 pb-0.5' : ''}`}
          >
            Design Lab
          </button>
          <button
            onClick={() => setActiveTab('REPLAY')}
            className={`hover:text-slate-100 transition-colors ${activeTab === 'REPLAY' ? 'text-sky-400 font-bold border-b-2 border-sky-400 pb-0.5' : ''}`}
          >
            Replay
          </button>
          <button
            onClick={() => setActiveTab('REQUIREMENTS')}
            className={`hover:text-slate-100 transition-colors ${activeTab === 'REQUIREMENTS' ? 'text-sky-400 font-bold border-b-2 border-sky-400 pb-0.5' : ''}`}
          >
            Requirements
          </button>
          <button
            onClick={() => setActiveTab('SCHEMATIC')}
            className={`hover:text-slate-100 transition-colors ${activeTab === 'SCHEMATIC' ? 'text-sky-400 font-bold border-b-2 border-sky-400 pb-0.5' : ''}`}
          >
            Schematic
          </button>
          <button
            onClick={() => setActiveTab('DOCS')}
            className={`hover:text-slate-100 transition-colors ${activeTab === 'DOCS' ? 'text-sky-400 font-bold border-b-2 border-sky-400 pb-0.5' : ''}`}
          >
            Docs
          </button>
        </nav>

        {/* Zone 3: Environment Selector & Primary Action */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-700/80 px-2 py-1 text-xs font-mono-aerospace">
            <span className="text-slate-400 text-[10px]">ENV:</span>
            <select
              value={vehicleState.environment}
              onChange={(e) => handleEnvChange(e.target.value as ExecutionEnvironment)}
              className="bg-transparent text-sky-400 font-semibold focus:outline-none cursor-pointer text-xs"
            >
              <option value="SIMULATION" className="bg-slate-900 text-slate-200">SIMULATION</option>
              <option value="SIL" className="bg-slate-900 text-slate-200">SIL (Software-in-Loop)</option>
              <option value="HIL" className="bg-slate-900 text-slate-200">HIL (Hardware-in-Loop)</option>
              <option value="DEVELOPMENT" className="bg-slate-900 text-slate-200">DEVELOPMENT</option>
              <option value="CERTIFICATION_RESEARCH" className="bg-slate-900 text-slate-200">CERTIFICATION</option>
            </select>
          </div>

          <button
            onClick={() => handleRunDemo(10)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-mono-aerospace font-bold transition-colors whitespace-nowrap"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>RUN VTOL MISSION</span>
          </button>
        </div>
      </header>

      {/* 2. SIGNATURE FLIGHT STATE SUMMARY BANNER (Prompt Spec Match) */}
      <section className="bg-[#0f172a] border-b border-slate-800 px-6 py-3">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Central Aircraft Flight State */}
          <div className="text-center md:text-left">
            <div className="text-xs font-mono-aerospace text-sky-400 font-bold tracking-widest">
              {vehicleState.aircraftId}
            </div>
            <div className="text-xl font-tech font-bold text-slate-100 flex items-center gap-2">
              <span>{vehicleState.flightMode}</span>
              <span className="text-xs text-slate-400 font-mono-aerospace">
                · {vehicleState.altitudeM.toFixed(0)} m / {vehicleState.airspeedKnots.toFixed(0)} kt
              </span>
            </div>
          </div>

          {/* Tri-Column Summary: ENERGY | HEALTH | MISSION */}
          <div className="flex items-center gap-8 text-xs font-mono-aerospace">
            
            {/* ENERGY */}
            <div>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">ENERGY</div>
              <div className="text-base font-bold font-tech text-emerald-400">
                {vehicleState.battery.socPct.toFixed(0)}%
              </div>
              <div className="text-[11px] text-slate-400">
                {vehicleState.battery.powerKw.toFixed(0)} kW
              </div>
            </div>

            <div className="h-8 w-px bg-slate-800"></div>

            {/* HEALTH */}
            <div>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">HEALTH</div>
              <div className={`text-base font-bold font-tech ${vehicleState.health.overallStatus === 'NORMAL' ? 'text-emerald-400' : 'text-amber-400'}`}>
                {vehicleState.health.overallStatus}
              </div>
              <div className="text-[11px] text-slate-400">
                {vehicleState.health.overallScorePct.toFixed(1)}%
              </div>
            </div>

            <div className="h-8 w-px bg-slate-800"></div>

            {/* MISSION */}
            <div>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">MISSION</div>
              <div className="text-base font-bold font-tech text-sky-400">
                {vehicleState.mission.progressPct.toFixed(0)}%
              </div>
              <div className="text-[11px] text-slate-400 truncate max-w-[170px]" title={vehicleState.mission.origin}>
                LON → CITY B
              </div>
            </div>

          </div>

          {/* Quick Diagnostics Badge */}
          <div className="hidden xl:flex items-center gap-4 text-[11px] font-mono-aerospace text-slate-400 border-l border-slate-800 pl-6">
            <div>
              <span className="text-slate-500">EKF: </span>
              <span className="text-emerald-400 font-semibold">{vehicleState.estimation.filterStatus}</span>
            </div>
            <div>
              <span className="text-slate-500">CONTROL: </span>
              <span className="text-emerald-400 font-semibold">STABLE</span>
            </div>
            <div>
              <span className="text-slate-500">CPU: </span>
              <span className="text-slate-300">{vehicleState.diagnostics.cpuLoadPct.toFixed(1)}%</span>
            </div>
          </div>

        </div>
      </section>

      {/* 3. MAIN WORKSPACE AREA */}
      <main className="flex-1 p-4 lg:p-6 max-w-7xl w-full mx-auto space-y-4">
        
        {/* Render Tab Content */}
        {activeTab === 'OVERVIEW' && (
          <div className="space-y-4">
            
            {/* Top: 3D Aircraft Digital Twin & Telemetry Split */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              
              {/* 3D Canvas (2 Cols) */}
              <div className="lg:col-span-2 h-[420px]">
                <ThreeVtolCanvas vehicleState={vehicleState} />
              </div>

              {/* Right: Real-Time Attitude & Flight Parameters */}
              <div className="bg-[#0b0f17] border border-slate-800 p-4 font-mono-aerospace flex flex-col justify-between space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <span className="text-xs font-tech font-bold text-slate-200">FLIGHT INSTRUMENTATION</span>
                  <span className="text-[10px] text-sky-400 bg-slate-900 px-2 py-0.5 border border-slate-700">
                    EKF SYNTHESIS
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-slate-900/90 border border-slate-800 p-2.5">
                    <div className="text-[10px] text-slate-400">PITCH ANGLE</div>
                    <div className="text-xl font-bold font-tech text-slate-100 mt-0.5">
                      {vehicleState.estimation.attitudeEuler.pitchDeg.toFixed(1)}°
                    </div>
                  </div>

                  <div className="bg-slate-900/90 border border-slate-800 p-2.5">
                    <div className="text-[10px] text-slate-400">ROLL ANGLE</div>
                    <div className="text-xl font-bold font-tech text-slate-100 mt-0.5">
                      {vehicleState.estimation.attitudeEuler.rollDeg.toFixed(1)}°
                    </div>
                  </div>

                  <div className="bg-slate-900/90 border border-slate-800 p-2.5">
                    <div className="text-[10px] text-slate-400">ALTITUDE MSL</div>
                    <div className="text-xl font-bold font-tech text-sky-400 mt-0.5">
                      {vehicleState.altitudeM.toFixed(1)} <span className="text-xs text-slate-400">m</span>
                    </div>
                    <div className="text-[10px] text-slate-500">{vehicleState.altitudeFt.toFixed(0)} ft</div>
                  </div>

                  <div className="bg-slate-900/90 border border-slate-800 p-2.5">
                    <div className="text-[10px] text-slate-400">AIRSPEED</div>
                    <div className="text-xl font-bold font-tech text-sky-400 mt-0.5">
                      {vehicleState.airspeedKnots.toFixed(1)} <span className="text-xs text-slate-400">kt</span>
                    </div>
                    <div className="text-[10px] text-slate-500">{vehicleState.airspeedMps.toFixed(1)} m/s</div>
                  </div>

                  <div className="bg-slate-900/90 border border-slate-800 p-2.5">
                    <div className="text-[10px] text-slate-400">VERTICAL SPEED</div>
                    <div className="text-xl font-bold font-tech text-slate-100 mt-0.5">
                      {vehicleState.verticalSpeedMps >= 0 ? '+' : ''}{vehicleState.verticalSpeedMps.toFixed(1)} <span className="text-xs text-slate-400">m/s</span>
                    </div>
                    <div className="text-[10px] text-slate-500">{vehicleState.verticalSpeedFpm.toFixed(0)} fpm</div>
                  </div>

                  <div className="bg-slate-900/90 border border-slate-800 p-2.5">
                    <div className="text-[10px] text-slate-400">TRANSITION</div>
                    <div className="text-xl font-bold font-tech text-emerald-400 mt-0.5">
                      {vehicleState.transitionProgressPct.toFixed(0)} <span className="text-xs text-slate-400">%</span>
                    </div>
                    <div className="text-[10px] text-slate-500">Wing Lift: {(vehicleState.aerodynamicLiftN / 1000).toFixed(1)} kN</div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 space-y-1">
                  <div className="flex justify-between">
                    <span>LIFT PROPULSION THRUST:</span>
                    <span className="text-slate-200 font-semibold">{vehicleState.liftThrustTotalN.toFixed(0)} N</span>
                  </div>
                  <div className="flex justify-between">
                    <span>CRUISE PROPULSION THRUST:</span>
                    <span className="text-slate-200 font-semibold">{vehicleState.cruiseThrustTotalN.toFixed(0)} N</span>
                  </div>
                  <div className="flex justify-between">
                    <span>ESTIMATED DRAG:</span>
                    <span className="text-slate-200 font-semibold">{vehicleState.totalDragN.toFixed(0)} N</span>
                  </div>
                </div>
              </div>

            </div>

            {/* Signature Demonstrators Bar */}
            <SignatureDemosPanel
              onRunDemo={handleRunDemo}
              activeDemo={activeDemo}
              onRestoreMotors={handleRestoreMotors}
            />

            {/* System Schematic Section */}
            <SystemSchematic vehicleState={vehicleState} />
          </div>
        )}

        {/* Tab 2: Propulsion System (12 Units Deep Dive) */}
        {activeTab === 'PROPULSION' && (
          <div className="bg-[#0b0f17] border border-slate-800 p-4 font-mono-aerospace space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <Fan className="w-4 h-4 text-sky-400" />
                  <h3 className="text-sm font-tech font-bold text-slate-100 tracking-wider">
                    DISTRIBUTED ELECTRIC PROPULSION (PROPULSION.OS)
                  </h3>
                </div>
                <p className="text-xs text-slate-400">
                  8 High-Torque Direct-Drive Lift Motors + 4 Cruise Pusher Nacelles
                </p>
              </div>
              <button
                onClick={handleRestoreMotors}
                className="px-3 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
              >
                RESTORE ALL MOTORS
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
              {vehicleState.motors.map((m) => (
                <div
                  key={m.id}
                  className={`p-3 border transition-colors ${
                    m.isFailed
                      ? 'bg-rose-950/60 border-rose-600'
                      : m.health === 'WARNING'
                      ? 'bg-amber-950/60 border-amber-600'
                      : 'bg-slate-900 border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-tech font-bold text-slate-100">{m.name}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 font-bold ${
                      m.isFailed ? 'bg-rose-900 text-rose-200' : 'bg-slate-800 text-slate-300'
                    }`}>
                      {m.type}
                    </span>
                  </div>

                  <div className="space-y-1 text-xs text-slate-400">
                    <div className="flex justify-between">
                      <span>THRUST:</span>
                      <span className="text-slate-100 font-semibold">{m.thrustN} N</span>
                    </div>
                    <div className="flex justify-between">
                      <span>SPEED:</span>
                      <span className="text-slate-100 font-semibold">{m.rpm} RPM</span>
                    </div>
                    <div className="flex justify-between">
                      <span>CURRENT:</span>
                      <span className="text-slate-100 font-semibold">{m.currentA} A</span>
                    </div>
                    <div className="flex justify-between">
                      <span>TEMPERATURE:</span>
                      <span className={m.tempC > 60 ? 'text-amber-400 font-bold' : 'text-emerald-400'}>
                        {m.tempC.toFixed(1)} °C
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>EFFICIENCY:</span>
                      <span className="text-sky-400">{m.efficiencyPct.toFixed(1)}%</span>
                    </div>
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-800 flex justify-between items-center">
                    <span className={`text-[10px] font-bold ${m.isFailed ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {m.health}
                    </span>
                    <button
                      onClick={() => {
                        m.isFailed = !m.isFailed;
                        m.health = m.isFailed ? 'FAILED' : 'NORMAL';
                        setVehicleState({ ...vehicleState });
                      }}
                      className="text-[10px] text-slate-400 hover:text-rose-400 underline"
                    >
                      {m.isFailed ? 'Clear Fault' : 'Inject Failure'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Energy & Thermal (ENERGY.OS) */}
        {activeTab === 'ENERGY' && (
          <div className="bg-[#0b0f17] border border-slate-800 p-4 font-mono-aerospace space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <h3 className="text-sm font-tech font-bold text-slate-100 tracking-wider">
                    ENERGY MANAGEMENT & COUPLED THERMAL SYSTEM (ENERGY.OS)
                  </h3>
                </div>
                <p className="text-xs text-slate-400">
                  780V High-Voltage Architecture · 142 kWh Li-Ion Pack · Lumped Liquid Thermal Circuit
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
              <div className="bg-slate-900 border border-slate-800 p-3">
                <div className="text-[10px] text-slate-400">STATE OF CHARGE (SOC)</div>
                <div className="text-2xl font-bold font-tech text-emerald-400 mt-1">
                  {vehicleState.battery.socPct.toFixed(1)} <span className="text-xs text-slate-400">%</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Remaining: {vehicleState.battery.energyRemainingKwh} kWh</div>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-3">
                <div className="text-[10px] text-slate-400">STATE OF HEALTH (SOH)</div>
                <div className="text-2xl font-bold font-tech text-sky-400 mt-1">
                  {vehicleState.battery.sohPct.toFixed(1)} <span className="text-xs text-slate-400">%</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Cell Imbalance: {vehicleState.battery.cellImbalanceMv} mV</div>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-3">
                <div className="text-[10px] text-slate-400">PACK VOLTAGE & CURRENT</div>
                <div className="text-2xl font-bold font-tech text-slate-100 mt-1">
                  {vehicleState.battery.packVoltageV.toFixed(1)} <span className="text-xs text-slate-400">V</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Draw: {vehicleState.battery.packCurrentA.toFixed(1)} A</div>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-3">
                <div className="text-[10px] text-slate-400">PACK TEMPERATURE</div>
                <div className="text-2xl font-bold font-tech text-amber-400 mt-1">
                  {vehicleState.battery.packTempC.toFixed(1)} <span className="text-xs text-slate-400">°C</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Spread: [{vehicleState.battery.minCellTempC}°C - {vehicleState.battery.maxCellTempC}°C]</div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Navigation & Vertiports */}
        {activeTab === 'NAVIGATION' && (
          <div className="bg-[#0b0f17] border border-slate-800 p-4 font-mono-aerospace space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-sky-400" />
                  <h3 className="text-sm font-tech font-bold text-slate-100 tracking-wider">
                    NAVIGATION & VERTIPORT INFRASTRUCTURE (VERTIPORT.OS)
                  </h3>
                </div>
                <p className="text-xs text-slate-400">
                  London Urban Air Mobility Corridor · RTK Precision Guidance · Geofenced Airspace
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 text-xs">
              <div className="bg-slate-900 border border-slate-800 p-3 space-y-2">
                <div className="text-xs font-tech font-bold text-slate-200">ACTIVE MISSION ROUTE</div>
                <div className="text-slate-400 space-y-1">
                  <div>ORIGIN: <strong className="text-slate-100">{vehicleState.mission.origin}</strong></div>
                  <div>DESTINATION: <strong className="text-slate-100">{vehicleState.mission.destination}</strong></div>
                  <div>DIVERT PAD: <strong className="text-amber-400">{vehicleState.mission.divertAlternative}</strong></div>
                  <div>DISTANCE REMAINING: <strong className="text-sky-400">{vehicleState.mission.distanceRemainingKm.toFixed(1)} km</strong></div>
                  <div>ESTIMATED TIME: <strong className="text-slate-100">{vehicleState.mission.etaMinutes.toFixed(1)} min</strong></div>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-3 space-y-2">
                <div className="text-xs font-tech font-bold text-slate-200">VERTIPORT OCCUPANCY STATUS</div>
                <div className="space-y-1.5 text-slate-400">
                  <div className="flex justify-between items-center bg-slate-950 p-2 border border-slate-800">
                    <span>PAD A1 (BATTERSEA):</span>
                    <span className="text-emerald-400 font-bold">PAD_AVAILABLE</span>
                  </div>
                  <div className="flex justify-between items-center bg-slate-950 p-2 border border-slate-800">
                    <span>PAD B2 (CITY AIRPORT):</span>
                    <span className="text-sky-400 font-bold">PAD_RESERVED</span>
                  </div>
                  <div className="flex justify-between items-center bg-slate-950 p-2 border border-slate-800">
                    <span>PAD C1 (STRATFORD DIVERT):</span>
                    <span className="text-emerald-400 font-bold">PAD_AVAILABLE</span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-3 space-y-2">
                <div className="text-xs font-tech font-bold text-slate-200">GEOFENCE INTEGRITY</div>
                <div className="text-slate-400 space-y-1">
                  <div>CEILING: <strong className="text-slate-100">450 m (1,476 ft)</strong></div>
                  <div>FLOOR: <strong className="text-slate-100">120 m (393 ft)</strong></div>
                  <div>THAMES CORRIDOR: <strong className="text-emerald-400">CLEARED</strong></div>
                  <div>CONFORMANCE: <strong className="text-emerald-400">100% WITHIN BOUNDARY</strong></div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: Digital Twin */}
        {activeTab === 'DIGITAL_TWIN' && <DigitalTwinFleet />}

        {/* Tab 6: Control Lab */}
        {activeTab === 'CONTROL_LAB' && <ControlLab />}

        {/* Tab 7: Monte Carlo */}
        {activeTab === 'MONTE_CARLO' && <MonteCarloLab />}

        {/* Tab 8: Design Lab */}
        {activeTab === 'DESIGN_LAB' && <AircraftDesignLab />}

        {/* Tab 9: Flight Replay */}
        {activeTab === 'REPLAY' && <FlightReplay />}

        {/* Tab 10: Requirements Traceability */}
        {activeTab === 'REQUIREMENTS' && <RequirementsTraceability />}

        {/* Tab 11: System Schematic */}
        {activeTab === 'SCHEMATIC' && <SystemSchematic vehicleState={vehicleState} />}

        {/* Tab 12: Documentation Browser */}
        {activeTab === 'DOCS' && <DocumentationBrowser />}

      </main>

      {/* 4. FOOTER STATUS BAR (Quiet British precision footer) */}
      <footer className="mt-auto px-6 py-2.5 bg-[#0b0f17] border-t border-slate-800 text-[11px] font-mono-aerospace text-slate-500 flex flex-wrap items-center justify-between gap-4 shrink-0">
        <div>
          VTOL.OS · DUKE SATOSHI OF CYBERSPACE PLC · BRITISH AEROSPACE COMPUTING ARCHITECTURE
        </div>
        <div className="flex items-center gap-4">
          <span>CYCLE: #{vehicleState.cycleId.toLocaleString()}</span>
          <span>·</span>
          <span>LATENCY: {vehicleState.diagnostics.p50LatencyMs} ms</span>
          <span>·</span>
          <span>CERTIFICATION RESEARCH ENVIRONMENT</span>
        </div>
      </footer>
    </div>
  );
};
