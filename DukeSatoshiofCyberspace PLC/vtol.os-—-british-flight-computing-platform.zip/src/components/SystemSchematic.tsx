/**
 * VTOL.OS Closed-Loop Computational Architecture Schematic
 * Duke Satoshi of Cyberspace PLC
 * 
 * Signature live animated schematic depicting the 7-layer data loop:
 * SENSORS -> VALIDATION -> ESTIMATION (EKF) -> CONTROL -> ALLOCATION -> PROPULSION -> AIRCRAFT
 */

import React from 'react';
import { VehicleState } from '../types/vtol';
import { 
  Radio, 
  CheckCheck, 
  Cpu, 
  Sliders, 
  Boxes, 
  Fan, 
  Plane, 
  BatteryCharging 
} from 'lucide-react';

interface SystemSchematicProps {
  vehicleState: VehicleState;
}

export const SystemSchematic: React.FC<SystemSchematicProps> = ({ vehicleState }) => {
  const isFailedM03 = vehicleState.motors[2]?.isFailed;

  return (
    <div className="bg-[#0b0f17] border border-slate-800 p-4 font-mono-aerospace">
      <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
        <div>
          <h3 className="text-sm font-tech font-bold text-slate-100 tracking-wider">
            CLOSED-LOOP COMPUTATIONAL SYSTEM SCHEMATIC
          </h3>
          <p className="text-xs text-slate-400">
            Authoritative Signal Flow & Control Path · Real-Time Cycle #{vehicleState.cycleId.toLocaleString()}
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <span className="text-slate-400">LOOP RATE:</span>
          <span className="text-emerald-400 font-semibold">{vehicleState.diagnostics.loopFrequencyHz} Hz</span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400">JITTER:</span>
          <span className="text-sky-400 font-semibold">{vehicleState.diagnostics.jitterUs} µs</span>
        </div>
      </div>

      {/* Schematic Diagram Layout */}
      <div className="relative overflow-x-auto py-2">
        <div className="min-w-[920px] flex items-center justify-between gap-3 text-xs">
          
          {/* Node 1: Physical Sensors */}
          <div className="flex-1 bg-slate-900 border border-slate-700/80 p-3 relative group">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-400 text-[10px]">LAYER 1</span>
              <Radio className="w-3.5 h-3.5 text-sky-400" />
            </div>
            <div className="font-tech text-slate-200 font-bold mb-1">TRIPLE SENSORS</div>
            <div className="text-[11px] text-slate-400 space-y-0.5">
              <div>IMU: <span className="text-emerald-400">3x Tri-Voter</span></div>
              <div>BARO: <span className="text-emerald-400">{vehicleState.sensors.baro.pressurePa.toFixed(0)} Pa</span></div>
              <div>GNSS: <span className="text-sky-400">{vehicleState.sensors.gnss.fixQuality}</span></div>
            </div>
          </div>

          <div className="text-sky-400 font-bold">→</div>

          {/* Node 2: Sensor Validation */}
          <div className="flex-1 bg-slate-900 border border-slate-700/80 p-3 relative">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-400 text-[10px]">LAYER 2</span>
              <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="font-tech text-slate-200 font-bold mb-1">VOTING & HEALTH</div>
            <div className="text-[11px] text-slate-400 space-y-0.5">
              <div>STATUS: <span className="text-emerald-400">HEALTHY</span></div>
              <div>DROPOUTS: <span className="text-slate-300">0</span></div>
              <div>RESIDUAL: <span className="text-slate-300">0.002 g</span></div>
            </div>
          </div>

          <div className="text-sky-400 font-bold">→</div>

          {/* Node 3: State Estimation (EKF) */}
          <div className="flex-1 bg-slate-900 border border-slate-700/80 p-3 relative">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-400 text-[10px]">LAYER 3</span>
              <Cpu className="w-3.5 h-3.5 text-purple-400" />
            </div>
            <div className="font-tech text-slate-200 font-bold mb-1">15-STATE EKF</div>
            <div className="text-[11px] text-slate-400 space-y-0.5">
              <div>ALT: <span className="text-slate-200 font-semibold">{vehicleState.altitudeM.toFixed(1)} m</span></div>
              <div>AIRSPEED: <span className="text-slate-200 font-semibold">{vehicleState.airspeedKnots.toFixed(1)} kt</span></div>
              <div>STATUS: <span className="text-emerald-400">{vehicleState.estimation.filterStatus}</span></div>
            </div>
          </div>

          <div className="text-sky-400 font-bold">→</div>

          {/* Node 4: Flight Control */}
          <div className="flex-1 bg-slate-900 border border-slate-700/80 p-3 relative">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-400 text-[10px]">LAYER 4</span>
              <Sliders className="w-3.5 h-3.5 text-indigo-400" />
            </div>
            <div className="font-tech text-slate-200 font-bold mb-1">CASCADED PID</div>
            <div className="text-[11px] text-slate-400 space-y-0.5">
              <div>MODE: <span className="text-sky-400">{vehicleState.flightMode}</span></div>
              <div>TRANSITION: <span className="text-emerald-400">{vehicleState.transitionProgressPct.toFixed(0)}%</span></div>
              <div>STABILITY: <span className="text-emerald-400">STABLE</span></div>
            </div>
          </div>

          <div className="text-sky-400 font-bold">→</div>

          {/* Node 5: Control Allocation */}
          <div className="flex-1 bg-slate-900 border border-slate-700/80 p-3 relative">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-400 text-[10px]">LAYER 4.2</span>
              <Boxes className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div className="font-tech text-slate-200 font-bold mb-1">ALLOCATION ENGINE</div>
            <div className="text-[11px] text-slate-400 space-y-0.5">
              <div>UNITS: <span className="text-slate-200">8 Lift + 4 Cruise</span></div>
              <div>STATUS: <span className={isFailedM03 ? 'text-amber-400 font-bold' : 'text-emerald-400'}>
                {isFailedM03 ? 'RECONFIGURED' : 'NOMINAL'}
              </span></div>
              <div>SATURATION: <span className="text-slate-300">NONE</span></div>
            </div>
          </div>

          <div className="text-sky-400 font-bold">→</div>

          {/* Node 6: Distributed Propulsion */}
          <div className="flex-1 bg-slate-900 border border-slate-700/80 p-3 relative">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-400 text-[10px]">LAYER 5</span>
              <Fan className="w-3.5 h-3.5 text-sky-400" />
            </div>
            <div className="font-tech text-slate-200 font-bold mb-1">PROPULSION & BMS</div>
            <div className="text-[11px] text-slate-400 space-y-0.5">
              <div>LIFT THRUST: <span className="text-slate-200">{vehicleState.liftThrustTotalN.toFixed(0)} N</span></div>
              <div>CRUISE THRUST: <span className="text-slate-200">{vehicleState.cruiseThrustTotalN.toFixed(0)} N</span></div>
              <div>POWER: <span className="text-amber-400">{vehicleState.battery.powerKw} kW</span></div>
            </div>
          </div>

          <div className="text-sky-400 font-bold">→</div>

          {/* Node 7: Aircraft 6-DOF Physical Machine */}
          <div className="flex-1 bg-slate-900 border border-sky-600/80 p-3 relative">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sky-400 text-[10px]">AIRCRAFT</span>
              <Plane className="w-3.5 h-3.5 text-sky-400" />
            </div>
            <div className="font-tech text-slate-200 font-bold mb-1">DCS-VTOL-01</div>
            <div className="text-[11px] text-slate-400 space-y-0.5">
              <div>LIFT WING: <span className="text-emerald-400">{vehicleState.aerodynamicLiftN.toFixed(0)} N</span></div>
              <div>DRAG: <span className="text-slate-300">{vehicleState.totalDragN.toFixed(0)} N</span></div>
              <div>ENV: <span className="text-sky-400">{vehicleState.environment}</span></div>
            </div>
          </div>

        </div>

        {/* Feedback Return Arrow to Sensors */}
        <div className="mt-3 pt-2 border-t border-dashed border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
          <span>⟵ CLOSED-LOOP FEEDBACK: Real-Time Aerodynamic Response & Dynamic Invariants Fed Back to IMU & Sensors at 1,000 Hz</span>
          <span className="text-emerald-500 font-semibold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            CONTINUOUSLY COMPUTED
          </span>
        </div>
      </div>
    </div>
  );
};
