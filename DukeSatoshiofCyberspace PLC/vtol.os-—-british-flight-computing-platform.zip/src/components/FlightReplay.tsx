/**
 * VTOL.OS Flight Data Recorder & Replay (FDR.OS)
 * Duke Satoshi of Cyberspace PLC
 * 
 * Signature Demo 06: Deterministic Flight Replay of DCS-VTOL-01 Flight 0047
 * Scrubbing timeline synchronously updates multi-channel telemetry graphs.
 */

import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, FastForward, Rewind, Clock } from 'lucide-react';

export const FlightReplay: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<1 | 2 | 5>(1);
  const [currentTimeSec, setCurrentTimeSec] = useState(380); // mid-cruise default
  const totalDurationSec = 870; // 14 mins 30 secs

  // Key phases of Flight 0047
  const getPhaseAtTime = (t: number): string => {
    if (t < 40) return 'PRE-FLIGHT & AUTHORITY CHECK';
    if (t < 80) return 'VERTICAL TAKEOFF';
    if (t < 130) return 'HOVER STABILISATION';
    if (t < 210) return 'HOVER → CRUISE TRANSITION';
    if (t < 680) return 'NOMINAL CRUISE (74 kt / 182 m)';
    if (t < 760) return 'CRUISE → HOVER TRANSITION';
    if (t < 820) return 'APPROACH & VERTIPORT ALIGNMENT';
    return 'VERTICAL DESCENT & TOUCHDOWN';
  };

  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTimeSec((prev) => {
          if (prev >= totalDurationSec) {
            setIsPlaying(false);
            return totalDurationSec;
          }
          return prev + 1 * playbackSpeed;
        });
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed]);

  const formatTime = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${String(mins).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  // Interpolated telemetry values for scrubber time
  const tFrac = currentTimeSec / totalDurationSec;
  const currentAltM = tFrac < 0.1 ? tFrac * 10 * 30 : tFrac < 0.25 ? 30 + (tFrac - 0.1) * 6.6 * 152 : tFrac < 0.8 ? 182 : Math.max(0, 182 * (1 - (tFrac - 0.8) * 5));
  const currentAirspeedKt = tFrac < 0.15 ? 8 : tFrac < 0.3 ? 8 + (tFrac - 0.15) * 6.6 * 66 : tFrac < 0.78 ? 74 : Math.max(0, 74 * (1 - (tFrac - 0.78) * 4.5));
  const currentPowerKw = tFrac < 0.15 ? 480 : tFrac < 0.3 ? 480 - (tFrac - 0.15) * 6.6 * 120 : tFrac < 0.8 ? 360 : 490;
  const currentSocPct = Math.max(18, 96 - tFrac * 34);

  return (
    <div className="bg-[#0b0f17] border border-slate-800 p-4 font-mono-aerospace space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-tech font-bold text-slate-100 tracking-wider">
              FLIGHT DATA RECORDER & DETERMINISTIC REPLAY (FDR.OS)
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            DCS-VTOL-01 · RECORDING #FLT-0047 · VERTIPORT A (BATTERSEA) → VERTIPORT B (CITY)
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">PHASE:</span>
          <span className="text-xs text-sky-400 font-bold bg-slate-900 border border-slate-700 px-2.5 py-0.5">
            {getPhaseAtTime(currentTimeSec)}
          </span>
        </div>
      </div>

      {/* Replay Controls & Scrubber */}
      <div className="bg-slate-900/90 border border-slate-800 p-3 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentTimeSec(0)}
              className="p-1.5 text-slate-400 hover:text-slate-200 bg-slate-800 border border-slate-700"
              title="Rewind to start"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs"
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isPlaying ? 'PAUSE' : 'PLAY REPLAY'}</span>
            </button>
            <div className="flex items-center gap-1 ml-2 text-xs">
              <span className="text-slate-400">SPEED:</span>
              {([1, 2, 5] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setPlaybackSpeed(s)}
                  className={`px-2 py-0.5 border ${
                    playbackSpeed === s
                      ? 'bg-slate-700 text-white border-sky-400'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  {s}X
                </button>
              ))}
            </div>
          </div>

          <div className="text-sm font-bold text-slate-200">
            {formatTime(currentTimeSec)} <span className="text-slate-500">/ {formatTime(totalDurationSec)}</span>
          </div>
        </div>

        {/* Scrubber slider */}
        <div className="relative">
          <input
            type="range"
            min="0"
            max={totalDurationSec}
            value={currentTimeSec}
            onChange={(e) => setCurrentTimeSec(parseInt(e.target.value))}
            className="w-full accent-sky-500 cursor-pointer"
          />
        </div>
      </div>

      {/* Telemetry Curves with cursor */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
        <div className="bg-slate-900 border border-slate-800 p-2.5">
          <div className="text-[10px] text-slate-400">ALTITUDE AT SCRUBBER</div>
          <div className="text-lg font-bold font-tech text-sky-400 mt-1">
            {currentAltM.toFixed(1)} <span className="text-xs text-slate-400">m</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5">
          <div className="text-[10px] text-slate-400">AIRSPEED AT SCRUBBER</div>
          <div className="text-lg font-bold font-tech text-slate-100 mt-1">
            {currentAirspeedKt.toFixed(1)} <span className="text-xs text-slate-400">kt</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5">
          <div className="text-[10px] text-slate-400">POWER DEMAND AT SCRUBBER</div>
          <div className="text-lg font-bold font-tech text-amber-400 mt-1">
            {currentPowerKw.toFixed(0)} <span className="text-xs text-slate-400">kW</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-2.5">
          <div className="text-[10px] text-slate-400">SOC AT SCRUBBER</div>
          <div className="text-lg font-bold font-tech text-emerald-400 mt-1">
            {currentSocPct.toFixed(1)} <span className="text-xs text-slate-400">%</span>
          </div>
        </div>
      </div>
    </div>
  );
};
