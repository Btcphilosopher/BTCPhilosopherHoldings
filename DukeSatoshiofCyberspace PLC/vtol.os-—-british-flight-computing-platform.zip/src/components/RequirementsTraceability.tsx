/**
 * VTOL.OS Requirements & Verification Matrix (REQUIREMENTS.OS)
 * Duke Satoshi of Cyberspace PLC
 * 
 * DO-178C DAL-A / EASA Special Condition VTOL.2510 Traceability Matrix
 * Strict bidirectional linkage: System Req -> Safety Req -> Software Req -> Test -> Evidence.
 */

import React, { useState } from 'react';
import { RequirementNode } from '../types/vtol';
import { ShieldCheck, CheckCircle2, Clock, FileCheck, Search } from 'lucide-react';

export const RequirementsTraceability: React.FC = () => {
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const requirements: RequirementNode[] = [
    {
      id: 'VTOL-SYS-REQ-001',
      category: 'SYSTEM',
      title: 'Deterministic Real-Time Execution Core',
      description: 'Flight core loop shall execute deterministically at 1,000 Hz with maximum cycle jitter < 150 µs.',
      standardRef: 'DO-178C DAL-A §6.3.4',
      verificationMethod: 'TEST_HIL',
      status: 'VERIFIED',
      testEvidenceId: 'EVID-HIL-CYC-8402',
      passRatioPct: 100,
    },
    {
      id: 'VTOL-SFTY-REQ-012',
      category: 'SAFETY',
      title: 'Single Actuator Inverter Desynchronization Immunity',
      description: 'Upon loss of any single lift or cruise motor, the Control Allocation Engine shall re-weight within 20 ms without departing flight envelope.',
      standardRef: 'EASA SC-VTOL.2510(b)',
      verificationMethod: 'TEST_SIL',
      status: 'VERIFIED',
      testEvidenceId: 'EVID-SIL-FLT-0914',
      passRatioPct: 100,
    },
    {
      id: 'VTOL-CTRL-REQ-034',
      category: 'CONTROL',
      title: 'Hover to Cruise Aerodynamic Transition Stability Margin',
      description: 'Transition controller shall maintain pitch angle bounds [-5°, +12°] and roll angle bounds [-10°, +10°] under 15 kt crosswind gusts.',
      standardRef: 'EASA SC-VTOL.2115',
      verificationMethod: 'TEST_SIL',
      status: 'VERIFIED',
      testEvidenceId: 'EVID-SIL-TRN-4412',
      passRatioPct: 100,
    },
    {
      id: 'VTOL-EST-REQ-021',
      category: 'FUNCTIONAL',
      title: 'Triple-Redundant IMU Voting & Fault Isolation',
      description: 'The state estimator shall isolate an IMU exhibiting sensor bias drift > 0.05 g within 50 ms before covariance degradation.',
      standardRef: 'DO-178C DAL-A §6.4.2',
      verificationMethod: 'TEST_SIL',
      status: 'VERIFIED',
      testEvidenceId: 'EVID-SIL-IMU-1192',
      passRatioPct: 100,
    },
    {
      id: 'VTOL-BMS-REQ-045',
      category: 'SAFETY',
      title: 'Electrochemical Thermal Runaway Propagation Prevention',
      description: 'Energy management subsystem shall trip landing diversion alerts when cell temperature exceeds 55.0°C.',
      standardRef: 'EASA SC-VTOL.2430',
      verificationMethod: 'TEST_HIL',
      status: 'VERIFIED',
      testEvidenceId: 'EVID-HIL-BMS-3301',
      passRatioPct: 100,
    },
    {
      id: 'VTOL-NAV-REQ-052',
      category: 'SOFTWARE',
      title: 'Geofence Boundary Real-Time Intersection Test',
      description: 'Trajectory planner shall calculate 4D intersection with static and dynamic airspace restrictions at 50 Hz.',
      standardRef: 'DO-178C DAL-B §5.2.1',
      verificationMethod: 'FORMAL_PROOF',
      status: 'IN_DEVELOPMENT',
      testEvidenceId: 'EVID-PR-GEO-002',
      passRatioPct: 92,
    },
  ];

  const filtered = requirements.filter((r) => {
    const matchesCat = filterCategory === 'ALL' || r.category === filterCategory;
    const matchesSearch = r.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          r.title.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="bg-[#0b0f17] border border-slate-800 p-4 font-mono-aerospace space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-tech font-bold text-slate-100 tracking-wider">
              REQUIREMENTS TRACEABILITY & VERIFICATION MATRIX (DO-178C / EASA)
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            Duke Satoshi PLC · Formal Item & Function Development Assurance Levels (DAL-A)
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <span className="text-slate-400">TOTAL: <strong className="text-slate-200">1,284</strong></span>
          <span className="text-emerald-400 font-semibold">VERIFIED: 1,201</span>
          <span className="text-amber-400">IN DEV: 62</span>
          <span className="text-rose-400">OPEN: 21</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-900/80 p-2.5 border border-slate-800">
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-400 mr-1">CATEGORY:</span>
          {['ALL', 'SYSTEM', 'SAFETY', 'CONTROL', 'FUNCTIONAL', 'SOFTWARE'].map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-2.5 py-1 transition-colors ${
                filterCategory === cat
                  ? 'bg-sky-600 text-white font-bold'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative">
          <input
            type="text"
            placeholder="Search requirement ID or title..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-xs px-2.5 py-1 text-slate-200 w-64 placeholder-slate-500 focus:outline-none focus:border-sky-500"
          />
        </div>
      </div>

      {/* Requirements List */}
      <div className="space-y-2">
        {filtered.map((req) => (
          <div key={req.id} className="bg-slate-900 border border-slate-800 p-3 hover:border-slate-700 transition-colors">
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-sky-400 bg-slate-950 border border-slate-800 px-2 py-0.5">
                  {req.id}
                </span>
                <span className="text-xs font-tech font-bold text-slate-200">
                  {req.title}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 border border-slate-700">
                  {req.standardRef}
                </span>
                <span className={`text-[10px] px-2 py-0.5 font-bold flex items-center gap-1 ${
                  req.status === 'VERIFIED' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-amber-950 text-amber-400 border border-amber-800'
                }`}>
                  {req.status === 'VERIFIED' ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                  {req.status}
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed mb-2">
              {req.description}
            </p>

            <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-800/80">
              <div className="flex items-center gap-3">
                <span>METHOD: <strong className="text-slate-300">{req.verificationMethod}</strong></span>
                <span>EVIDENCE: <strong className="text-sky-400">{req.testEvidenceId}</strong></span>
              </div>
              <div className="flex items-center gap-1.5">
                <span>PASS RATE:</span>
                <span className="text-emerald-400 font-bold">{req.passRatioPct}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
