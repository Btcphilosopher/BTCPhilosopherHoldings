/**
 * VTOL.OS 3D Aircraft Digital Twin & Telemetry Canvas
 * Duke Satoshi of Cyberspace PLC
 * 
 * Interactive Three.js WebGL visualization of DCS-VTOL-01
 * Supports Standard, Explode, Thermal, Power Flow, and Sensor view modes.
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { VehicleState } from '../types/vtol';
import { Eye, Layers, Flame, Zap, Crosshair, RotateCcw } from 'lucide-react';

export type ViewportMode = 'AIRCRAFT' | 'EXPLODE' | 'THERMAL' | 'POWER_FLOW' | 'SENSORS';

interface ThreeVtolCanvasProps {
  vehicleState: VehicleState;
}

export const ThreeVtolCanvas: React.FC<ThreeVtolCanvasProps> = ({ vehicleState }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [viewMode, setViewMode] = useState<ViewportMode>('AIRCRAFT');
  const [exploded, setExploded] = useState(false);

  // References for Three.js objects
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const aircraftGroupRef = useRef<THREE.Group | null>(null);
  const rotorsRef = useRef<THREE.Group[]>([]);
  const cruiseRotorsRef = useRef<THREE.Group[]>([]);
  const batteryMeshRef = useRef<THREE.Mesh | null>(null);
  const avionicsMeshRef = useRef<THREE.Mesh | null>(null);
  const motorMeshesRef = useRef<THREE.Mesh[]>([]);

  // Mouse interaction state
  const isDraggingRef = useRef(false);
  const previousMousePositionRef = useRef({ x: 0, y: 0 });
  const cameraAngleRef = useRef({ theta: Math.PI / 4, phi: Math.PI / 6, radius: 14 });

  useEffect(() => {
    if (!containerRef.current) return;

    // 1. Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0c111a);
    sceneRef.current = scene;

    // Subtle technical grid
    const gridHelper = new THREE.GridHelper(24, 24, 0x1e293b, 0x151e2e);
    gridHelper.position.y = -2.2;
    scene.add(gridHelper);

    // Directional and ambient lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xe0f2fe, 1.2);
    dirLight1.position.set(10, 20, 15);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 0.4);
    dirLight2.position.set(-10, -5, -10);
    scene.add(dirLight2);

    // 2. Camera setup
    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;
    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    cameraRef.current = camera;
    updateCameraPosition();

    // 3. Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 4. Build Aircraft Model DCS-VTOL-01
    const aircraftGroup = new THREE.Group();
    scene.add(aircraftGroup);
    aircraftGroupRef.current = aircraftGroup;

    // Materials
    const fuselageMat = new THREE.MeshStandardMaterial({
      color: 0x222a38,
      roughness: 0.35,
      metalness: 0.65,
    });
    const canopyMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      roughness: 0.1,
      metalness: 0.9,
      transparent: true,
      opacity: 0.75,
    });
    const wingMat = new THREE.MeshStandardMaterial({
      color: 0x1a212e,
      roughness: 0.4,
      metalness: 0.5,
    });
    const motorMountMat = new THREE.MeshStandardMaterial({
      color: 0x475569,
      roughness: 0.3,
      metalness: 0.8,
    });
    const rotorBladeMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.2,
      metalness: 0.7,
      transparent: true,
      opacity: 0.8,
    });

    // Main Fuselage (Tapered aerodynamic body)
    const fuselageGeo = new THREE.CylinderGeometry(0.55, 0.45, 5.8, 16);
    fuselageGeo.rotateX(Math.PI / 2);
    const fuselageMesh = new THREE.Mesh(fuselageGeo, fuselageMat);
    fuselageMesh.scale.set(1.2, 0.85, 1.0);
    aircraftGroup.add(fuselageMesh);

    // Nose Cone
    const noseGeo = new THREE.ConeGeometry(0.52, 1.4, 16);
    noseGeo.rotateX(-Math.PI / 2);
    const noseMesh = new THREE.Mesh(noseGeo, fuselageMat);
    noseMesh.position.set(0, 0, 3.4);
    aircraftGroup.add(noseMesh);

    // Canopy
    const canopyGeo = new THREE.SphereGeometry(0.55, 16, 12);
    canopyGeo.scale(0.85, 0.5, 1.8);
    const canopyMesh = new THREE.Mesh(canopyGeo, canopyMat);
    canopyMesh.position.set(0, 0.42, 1.1);
    aircraftGroup.add(canopyMesh);

    // High Main Wing
    const wingGeo = new THREE.BoxGeometry(10.2, 0.12, 1.4);
    const wingMesh = new THREE.Mesh(wingGeo, wingMat);
    wingMesh.position.set(0, 0.45, 0.2);
    aircraftGroup.add(wingMesh);

    // Longitudinal Rotor Booms (Port & Starboard)
    const boomGeo = new THREE.CylinderGeometry(0.12, 0.12, 4.8, 12);
    boomGeo.rotateX(Math.PI / 2);

    const leftBoom = new THREE.Mesh(boomGeo, wingMat);
    leftBoom.position.set(-2.2, 0.35, 0.1);
    aircraftGroup.add(leftBoom);

    const rightBoom = new THREE.Mesh(boomGeo, wingMat);
    rightBoom.position.set(2.2, 0.35, 0.1);
    aircraftGroup.add(rightBoom);

    // V-Tail / Empennage
    const finMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.4 });
    const finGeo = new THREE.BoxGeometry(0.08, 1.2, 0.9);
    
    const leftFin = new THREE.Mesh(finGeo, finMat);
    leftFin.position.set(-0.6, 0.7, -2.6);
    leftFin.rotation.z = -0.4;
    aircraftGroup.add(leftFin);

    const rightFin = new THREE.Mesh(finGeo, finMat);
    rightFin.position.set(0.6, 0.7, -2.6);
    rightFin.rotation.z = 0.4;
    aircraftGroup.add(rightFin);

    // Underfloor Battery Pack
    const batteryGeo = new THREE.BoxGeometry(0.9, 0.35, 2.4);
    const batteryMat = new THREE.MeshStandardMaterial({
      color: 0x059669,
      roughness: 0.3,
      metalness: 0.5,
    });
    const batteryMesh = new THREE.Mesh(batteryGeo, batteryMat);
    batteryMesh.position.set(0, -0.3, 0.1);
    aircraftGroup.add(batteryMesh);
    batteryMeshRef.current = batteryMesh;

    // Avionics Bay (Dual Redundant Flight Computers)
    const avionicsGeo = new THREE.BoxGeometry(0.6, 0.25, 0.7);
    const avionicsMat = new THREE.MeshStandardMaterial({
      color: 0x3b82f6,
      roughness: 0.2,
      metalness: 0.8,
    });
    const avionicsMesh = new THREE.Mesh(avionicsGeo, avionicsMat);
    avionicsMesh.position.set(0, 0.1, 1.8);
    aircraftGroup.add(avionicsMesh);
    avionicsMeshRef.current = avionicsMesh;

    // 8 Lift Rotors & Motors
    // Positions: 4 along Left Boom, 4 along Right Boom
    const liftMotorPositions: [number, number, number][] = [
      [-2.2, 0.55, 2.1],  // M1
      [-1.1, 0.55, 2.0],  // M2
      [1.1, 0.55, 2.0],   // M3
      [2.2, 0.55, 2.1],   // M4
      [-2.2, 0.55, -1.9], // M5
      [-1.1, 0.55, -1.8], // M6
      [1.1, 0.55, -1.8],  // M7
      [2.2, 0.55, -1.9],  // M8
    ];

    rotorsRef.current = [];
    motorMeshesRef.current = [];

    liftMotorPositions.forEach((pos, idx) => {
      const motorMountGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.22, 16);
      const motorMount = new THREE.Mesh(motorMountGeo, motorMountMat);
      motorMount.position.set(pos[0], pos[1], pos[2]);
      aircraftGroup.add(motorMount);
      motorMeshesRef.current.push(motorMount);

      // Rotor group (blades rotate around Y)
      const rotorGroup = new THREE.Group();
      rotorGroup.position.set(pos[0], pos[1] + 0.14, pos[2]);

      // 3 Blades per rotor
      for (let b = 0; b < 3; b++) {
        const bladeGeo = new THREE.BoxGeometry(1.2, 0.02, 0.09);
        const blade = new THREE.Mesh(bladeGeo, rotorBladeMat);
        blade.position.x = 0.55;
        const pivot = new THREE.Group();
        pivot.rotation.y = (b * Math.PI * 2) / 3;
        pivot.add(blade);
        rotorGroup.add(pivot);
      }
      aircraftGroup.add(rotorGroup);
      rotorsRef.current.push(rotorGroup);
    });

    // 4 Cruise Propulsion Units on trailing wing & nacelles
    const cruisePositions: [number, number, number][] = [
      [-3.4, 0.45, -0.6],
      [-1.6, 0.45, -0.6],
      [1.6, 0.45, -0.6],
      [3.4, 0.45, -0.6],
    ];

    cruiseRotorsRef.current = [];
    cruisePositions.forEach((pos, idx) => {
      const nacelleGeo = new THREE.CylinderGeometry(0.16, 0.14, 0.7, 14);
      nacelleGeo.rotateX(Math.PI / 2);
      const nacelle = new THREE.Mesh(nacelleGeo, motorMountMat);
      nacelle.position.set(pos[0], pos[1], pos[2]);
      aircraftGroup.add(nacelle);
      motorMeshesRef.current.push(nacelle);

      const cruiseRotorGroup = new THREE.Group();
      cruiseRotorGroup.position.set(pos[0], pos[1], pos[2] - 0.42);

      // 3 Cruise Blades rotating around Z
      for (let b = 0; b < 3; b++) {
        const bladeGeo = new THREE.BoxGeometry(0.9, 0.02, 0.08);
        const blade = new THREE.Mesh(bladeGeo, rotorBladeMat);
        blade.position.x = 0.4;
        const pivot = new THREE.Group();
        pivot.rotation.z = (b * Math.PI * 2) / 3;
        pivot.add(blade);
        cruiseRotorGroup.add(pivot);
      }
      aircraftGroup.add(cruiseRotorGroup);
      cruiseRotorsRef.current.push(cruiseRotorGroup);
    });

    // 5. Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      // Rotate lift rotors based on motor commanded ratio
      rotorsRef.current.forEach((r, idx) => {
        const motor = vehicleState.motors[idx];
        const speed = motor && !motor.isFailed ? 0.15 + motor.commandedRatio * 0.4 : 0;
        r.rotation.y += speed * (idx % 2 === 0 ? 1 : -1);
      });

      // Rotate cruise rotors
      cruiseRotorsRef.current.forEach((r, idx) => {
        const motor = vehicleState.motors[idx + 8];
        const speed = motor && !motor.isFailed ? 0.1 + motor.commandedRatio * 0.5 : 0;
        r.rotation.z += speed;
      });

      // Slight simulated dynamic attitude tilt (roll/pitch) from vehicle state
      if (aircraftGroupRef.current) {
        const pitchRad = (vehicleState.estimation.attitudeEuler.pitchDeg * Math.PI) / 180;
        const rollRad = (vehicleState.estimation.attitudeEuler.rollDeg * Math.PI) / 180;
        aircraftGroupRef.current.rotation.x = pitchRad * 0.4;
        aircraftGroupRef.current.rotation.z = -rollRad * 0.4;
      }

      renderer.render(scene, camera);
    };
    animate();

    // Resize handler
    const handleResize = () => {
      if (!containerRef.current || !renderer || !camera) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (containerRef.current && renderer.domElement) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Update view mode materials and explosion offsets
  useEffect(() => {
    if (!motorMeshesRef.current || !batteryMeshRef.current || !avionicsMeshRef.current) return;

    const isThermal = viewMode === 'THERMAL';
    const isPowerFlow = viewMode === 'POWER_FLOW';
    const isExplode = viewMode === 'EXPLODE' || exploded;

    // Explode offsets
    const explodeFactor = isExplode ? 1.0 : 0.0;
    if (batteryMeshRef.current) {
      batteryMeshRef.current.position.y = -0.3 - 0.8 * explodeFactor;
      if (isThermal) {
        (batteryMeshRef.current.material as THREE.MeshStandardMaterial).color.setHex(0xf59e0b); // ~34C amber
      } else if (isPowerFlow) {
        (batteryMeshRef.current.material as THREE.MeshStandardMaterial).color.setHex(0x10b981); // Power source green
      } else {
        (batteryMeshRef.current.material as THREE.MeshStandardMaterial).color.setHex(0x059669);
      }
    }

    if (avionicsMeshRef.current) {
      avionicsMeshRef.current.position.y = 0.1 + 0.9 * explodeFactor;
    }

    // Motor thermal / failure highlights
    motorMeshesRef.current.forEach((m, idx) => {
      const motorState = vehicleState.motors[idx];
      const mat = m.material as THREE.MeshStandardMaterial;

      if (motorState?.isFailed) {
        mat.color.setHex(0xef4444); // Bright Red Failure
      } else if (isThermal) {
        const temp = motorState?.tempC ?? 32;
        if (temp > 65) mat.color.setHex(0xef4444);
        else if (temp > 45) mat.color.setHex(0xf59e0b);
        else mat.color.setHex(0x10b981);
      } else if (isPowerFlow) {
        mat.color.setHex(0x38bdf8); // Glowing Electric Blue
      } else {
        mat.color.setHex(0x475569);
      }
    });
  }, [viewMode, exploded, vehicleState.motors]);

  const updateCameraPosition = () => {
    if (!cameraRef.current) return;
    const { theta, phi, radius } = cameraAngleRef.current;
    cameraRef.current.position.x = radius * Math.sin(phi) * Math.sin(theta);
    cameraRef.current.position.y = radius * Math.cos(phi);
    cameraRef.current.position.z = radius * Math.sin(phi) * Math.cos(theta);
    cameraRef.current.lookAt(0, 0, 0);
  };

  // Mouse drag handlers for Orbit controls
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    const deltaX = e.clientX - previousMousePositionRef.current.x;
    const deltaY = e.clientY - previousMousePositionRef.current.y;

    cameraAngleRef.current.theta += deltaX * 0.008;
    cameraAngleRef.current.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, cameraAngleRef.current.phi - deltaY * 0.008));

    updateCameraPosition();
    previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    cameraAngleRef.current.radius = Math.max(6, Math.min(26, cameraAngleRef.current.radius + e.deltaY * 0.01));
    updateCameraPosition();
  };

  const resetCamera = () => {
    cameraAngleRef.current = { theta: Math.PI / 4, phi: Math.PI / 6, radius: 14 };
    updateCameraPosition();
  };

  return (
    <div className="relative w-full h-full min-h-[380px] bg-[#0c111a] rounded border border-slate-800/80 overflow-hidden select-none">
      {/* 3D WebGL Canvas Target */}
      <div
        ref={containerRef}
        className="w-full h-full cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
      />

      {/* Top Left: Aircraft & Mode Tag */}
      <div className="absolute top-3 left-3 flex items-center gap-2 pointer-events-none">
        <div className="bg-slate-900/90 border border-slate-700/80 px-2.5 py-1 text-xs font-mono-aerospace text-slate-300 backdrop-blur-sm">
          AIRCRAFT: <span className="text-sky-400 font-semibold">{vehicleState.aircraftId}</span>
        </div>
        <div className="bg-slate-900/90 border border-slate-700/80 px-2.5 py-1 text-xs font-mono-aerospace text-slate-400 backdrop-blur-sm">
          VIEW: <span className="text-white font-medium">{viewMode}</span>
        </div>
      </div>

      {/* Top Right: View Mode Controls */}
      <div className="absolute top-3 right-3 flex items-center gap-1 bg-slate-900/90 border border-slate-700/80 p-1 backdrop-blur-sm">
        <button
          onClick={() => { setViewMode('AIRCRAFT'); setExploded(false); }}
          className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono-aerospace transition-colors ${
            viewMode === 'AIRCRAFT' ? 'bg-sky-600 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
          }`}
          title="Standard Aerospace View"
        >
          <Eye className="w-3.5 h-3.5" />
          <span>AIRCRAFT</span>
        </button>

        <button
          onClick={() => { setViewMode('EXPLODE'); setExploded(true); }}
          className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono-aerospace transition-colors ${
            viewMode === 'EXPLODE' ? 'bg-sky-600 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
          }`}
          title="Exploded Assembly View"
        >
          <Layers className="w-3.5 h-3.5" />
          <span>EXPLODE</span>
        </button>

        <button
          onClick={() => { setViewMode('THERMAL'); setExploded(false); }}
          className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono-aerospace transition-colors ${
            viewMode === 'THERMAL' ? 'bg-amber-600 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
          }`}
          title="Component Thermal Gradient"
        >
          <Flame className="w-3.5 h-3.5" />
          <span>THERMAL</span>
        </button>

        <button
          onClick={() => { setViewMode('POWER_FLOW'); setExploded(false); }}
          className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono-aerospace transition-colors ${
            viewMode === 'POWER_FLOW' ? 'bg-emerald-600 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
          }`}
          title="Electrical Power Distribution"
        >
          <Zap className="w-3.5 h-3.5" />
          <span>POWER</span>
        </button>

        <button
          onClick={() => { setViewMode('SENSORS'); setExploded(false); }}
          className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono-aerospace transition-colors ${
            viewMode === 'SENSORS' ? 'bg-purple-600 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
          }`}
          title="Sensor Redundancy Topology"
        >
          <Crosshair className="w-3.5 h-3.5" />
          <span>SENSORS</span>
        </button>

        <button
          onClick={resetCamera}
          className="p-1 text-slate-400 hover:text-slate-200 transition-colors ml-1"
          title="Reset Camera Orientation"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Bottom Center: Sub-Telemetry Overlay HUD */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-4 bg-slate-950/85 border border-slate-800 px-4 py-1.5 text-xs font-mono-aerospace backdrop-blur-sm pointer-events-none">
        <div>
          <span className="text-slate-500">PITCH: </span>
          <span className="text-slate-200 font-semibold">{vehicleState.estimation.attitudeEuler.pitchDeg.toFixed(1)}°</span>
        </div>
        <div className="text-slate-700">|</div>
        <div>
          <span className="text-slate-500">ROLL: </span>
          <span className="text-slate-200 font-semibold">{vehicleState.estimation.attitudeEuler.rollDeg.toFixed(1)}°</span>
        </div>
        <div className="text-slate-700">|</div>
        <div>
          <span className="text-slate-500">YAW: </span>
          <span className="text-slate-200 font-semibold">{vehicleState.estimation.attitudeEuler.yawDeg.toFixed(1)}°</span>
        </div>
        <div className="text-slate-700">|</div>
        <div>
          <span className="text-slate-500">TRANSITION: </span>
          <span className="text-sky-400 font-semibold">{vehicleState.transitionProgressPct.toFixed(0)}%</span>
        </div>
      </div>
    </div>
  );
};
