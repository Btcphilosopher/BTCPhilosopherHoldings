/**
 * VTOL.OS Signature Demos Launchpad
 * Duke Satoshi of Cyberspace PLC
 * 
 * Provides 1-click execution for all 10 Signature Aerospace Demos
 */

import React from 'react';
import { 
  Play, 
  ArrowUpRight, 
  RefreshCw, 
  AlertTriangle, 
  BatteryLow, 
  Cpu, 
  RotateCcw, 
  Sliders, 
  BarChart3, 
  Compass,
  CheckCircle2
} from 'lucide-react';

interface SignatureDemosPanelProps {
  onRunDemo: (demoId: number) => void;
  activeDemo: number | null;
  onRestoreMotors: () => void;
}

export const SignatureDemosPanel: React.FC<SignatureDemosPanelProps> = ({
  onRunDemo,
  activeDemo,
  onRestoreMotors,
}) => {
  const demos = [
    {
      id: 1,
      title: 'DEMO 01 · VERTICAL TAKEOFF',
      desc: 'Pre-flight authority check → Arm → Vertical lift → Hover stabilisation at 30m.',
      icon: <ArrowUpRight className="w-4 h-4 text-emerald-400" />,
      tag: '0 to 30m',
    },
    {
      id: 2,
      title: 'DEMO 02 · HOVER → CRUISE',
      desc: 'Seamless transition: lift rotors handover thrust to wing aerodynamic lift (0% → 100%).',
      icon: <RefreshCw className="w-4 h-4 text-sky-400" />,
      tag: 'Transition Engine',
    },
    {
      id: 3,
      title: 'DEMO 03 · MOTOR FAILURE',
      desc: 'Simulate Motor 03 inverter desync; control allocation dynamically redistributes moments.',
      icon: <AlertTriangle className="w-4 h-4 text-rose-400" />,
      tag: 'Reconfiguration',
    },
    {
      id: 4,
      title: 'DEMO 04 · LOW BATTERY DIVERT',
      desc: 'Energy reserve trips below 20%; mission planner evaluates alternatives: Land / Continue / Divert.',
      icon: <BatteryLow className="w-4 h-4 text-amber-400" />,
      tag: 'Reserve Warning',
    },
    {
      id: 5,
      title: 'DEMO 05 · DIGITAL TWIN FLEET',
      desc: '100 synthetic aircraft fleet; inspect Aircraft 37 (SoH 96.4%, vibration harmonics, residuals).',
      icon: <Cpu className="w-4 h-4 text-purple-400" />,
      tag: '100 Aircraft',
    },
    {
      id: 6,
      title: 'DEMO 06 · FLIGHT REPLAY',
      desc: 'Load DCS-VTOL-01 Flight 0047; scrub timeline with synchronized multi-channel graphs.',
      icon: <RotateCcw className="w-4 h-4 text-cyan-400" />,
      tag: 'Flight 0047',
    },
    {
      id: 7,
      title: 'DEMO 07 · CONTROL LAB',
      desc: 'Compare Controller A (PID), B (Cascaded), C (Adaptive) against crosswind disturbances.',
      icon: <Sliders className="w-4 h-4 text-indigo-400" />,
      tag: 'A vs B vs C',
    },
    {
      id: 8,
      title: 'DEMO 08 · MONTE CARLO',
      desc: '1,000 simulated flights with stochastic wind, battery SOC, payload, and sensor noise.',
      icon: <BarChart3 className="w-4 h-4 text-emerald-400" />,
      tag: '1,000 Runs',
    },
    {
      id: 9,
      title: 'DEMO 09 · AIRCRAFT DESIGN LAB',
      desc: 'Parametric airframe sizing: tweak MTOW, wing area, motor power, and recalculate envelope.',
      icon: <Compass className="w-4 h-4 text-amber-400" />,
      tag: 'Parametric Sizing',
    },
    {
      id: 10,
      title: 'DEMO 10 · RUN FULL MISSION',
      desc: 'Complete closed-loop mission execution: London Vertiport A → Cruise → London Vertiport B.',
      icon: <Play className="w-4 h-4 text-sky-400" />,
      tag: 'End-to-End',
    },
  ];

  return (
    <div className="bg-[#0f172a]/95 border border-slate-800 p-4">
      <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
        <div>
          <h3 className="text-sm font-tech font-bold text-slate-100 tracking-wider">
            SIGNATURE AEROSPACE DEMONSTRATORS
          </h3>
          <p className="text-xs text-slate-400">
            Duke Satoshi of Cyberspace PLC · 10 Certification-Oriented Evaluation Scenarios
          </p>
        </div>
        <button
          onClick={onRestoreMotors}
          className="px-3 py-1.5 text-xs font-mono-aerospace text-slate-300 bg-slate-800 hover:bg-slate-700 transition-colors border border-slate-700 flex items-center gap-1.5"
          title="Reset all simulated faults and restore nominal motors"
        >
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>RESET ALL FAULTS</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-2.5">
        {demos.map((d) => {
          const isActive = activeDemo === d.id;
          return (
            <button
              key={d.id}
              onClick={() => onRunDemo(d.id)}
              className={`text-left p-2.5 border transition-all relative group ${
                isActive
                  ? 'bg-sky-950/60 border-sky-500 shadow-sm'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="p-1 bg-slate-800/80 rounded border border-slate-700/60">
                  {d.icon}
                </div>
                <span className="text-[10px] font-mono-aerospace text-slate-400 bg-slate-800/70 px-1.5 py-0.5">
                  {d.tag}
                </span>
              </div>
              <div className="text-xs font-tech font-semibold text-slate-200 group-hover:text-white truncate">
                {d.title}
              </div>
              <div className="text-[11px] text-slate-400 line-clamp-2 mt-1 leading-snug">
                {d.desc}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
