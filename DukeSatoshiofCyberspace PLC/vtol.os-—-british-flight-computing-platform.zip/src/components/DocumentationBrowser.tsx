/**
 * VTOL.OS Documentation & Specifications Browser
 * Duke Satoshi of Cyberspace PLC
 * 
 * In-console viewer for all 18 authoritative engineering and certification specifications.
 */

import React, { useState } from 'react';
import { BookOpen, FileText, ChevronRight } from 'lucide-react';

interface DocArticle {
  id: string;
  filename: string;
  title: string;
  category: string;
  content: string;
}

export const DocumentationBrowser: React.FC = () => {
  const docs: DocArticle[] = [
    {
      id: 'README',
      filename: 'README.md',
      title: 'VTOL.OS Overview & Engineering Principles',
      category: 'GENERAL',
      content: `# VTOL.OS: The Full-Stack Vertical Flight Computing Platform
### British Engineering Grade / Duke Satoshi of Cyberspace PLC

The aesthetic and engineering philosophy is:
> **British aerospace engineering rebuilt as software.**

This is not a drone dashboard.
This is not a toy autopilot.
This is not a 3D aircraft viewer.
This is a complete computational architecture for vertical flight aircraft.

**The aircraft is the physical machine. VTOL.OS is the computational machine.**

---

### Key Capabilities
- **7-Layer Computational Pipeline**: Hardware Abstraction → Flight Core → State Estimation → Control & Allocation → Vehicle Intelligence → Ground System → Digital Twin.
- **Reference Demonstrator**: DCS-VTOL-01 Distributed Electric VTOL (8 lift rotors + 4 cruise pushers).
- **Safety Boundary**: Non-bypassable SIL/HIL certification boundary. Real flight commands isolated.
- **Strict Provenance**: Every quantity stamped with timestamp, source, quality, confidence, and unit.`,
    },
    {
      id: 'ARCHITECTURE',
      filename: 'ARCHITECTURE.md',
      title: '7-Layer System Architecture',
      category: 'SYSTEM',
      content: `# Layered System Architecture

1. **Layer 1: Hardware Abstraction & Sensors**
   - Tri-redundant IMU voting architecture (Middle-value selection).
   - RTK GNSS, Pitot/Airspeed differential, Barometric static pressure, Radar altimeter.
2. **Layer 2: Real-Time Flight Core**
   - 1,000 Hz inner control loop, 500 Hz state estimator, 100 Hz vehicle management, 50 Hz navigation.
3. **Layer 3: State Estimation & Sensor Fusion**
   - 15-state Extended Kalman Filter (EKF) with continuous accelerometer and gyroscope bias estimation.
4. **Layer 4: Control & Allocation**
   - Cascaded attitude/altitude PID inner loop with feedforward.
   - Weighted pseudo-inverse control allocation with dynamic failure reallocation.
5. **Layer 5: Vehicle Intelligence & Energy**
   - Transition Manager (0% to 100% lift handover).
   - ENERGY.OS electrochemical and lumped thermal model.
6. **Layer 6: Mission & Ground Station**
   - 4D trajectory generation, geofence intersection tests, Vertiport pad availability.
7. **Layer 7: Simulation, Digital Twin & FDR**
   - Deterministic 6-DOF physics, 1,000-flight Monte Carlo engine, FDR.OS flight replay.`,
    },
    {
      id: 'FLIGHT_CONTROL',
      filename: 'FLIGHT_CONTROL.md',
      title: 'Flight Control & Control Allocation Engine',
      category: 'CONTROL',
      content: `# Control Allocation & Flight Control Theory

### Control Allocation Formulation
Given desired virtual control wrench:
$$v = [F_x, F_y, F_z, M_x, M_y, M_z]^T$$

The effectiveness matrix $B$ maps individual motor thrusts $u \in \mathbb{R}^{12}$ to virtual wrench:
$$v = B u$$

Using weighted pseudo-inverse:
$$u = W^{-1} B^T (B W^{-1} B^T)^{-1} v$$

### Failure Reconfiguration
When motor $k$ experiences an inverter desynchronization or thermal trip:
- Diagonal weight $W_{kk} \to \infty$
- The solver recalculates thrust redistribution across the remaining 7 lift or 3 cruise motors in $< 20\text{ ms}$.
- Demonstrates safe asymmetric moment compensation without departure.`,
    },
    {
      id: 'ENERGY_MODEL',
      filename: 'ENERGY_MODEL.md',
      title: 'Energy.OS Electrochemical & Thermal Subsystem',
      category: 'PROPULSION',
      content: `# Electrochemical & Coupled Thermal Model

### Battery Pack Specifications
- **Architecture**: 780V Nominal High-Voltage Lithium-Ion
- **Total Capacity**: 142 kWh
- **Mass**: 640 kg
- **Cooling**: Liquid active thermal loop

### Coupled Thermal Equations
$$\dot{Q}_{gen} = I^2 R_{int}(T, SOC)$$
$$\dot{Q}_{cool} = h A (T_{pack} - T_{ambient})$$
$$m C_p \frac{dT}{dt} = \dot{Q}_{gen} - \dot{Q}_{cool}$$

Landing reserve threshold set at 20% SOC with automatic diversion trajectory calculations.`,
    },
    {
      id: 'SAFETY_ARCHITECTURE',
      filename: 'SAFETY_ARCHITECTURE.md',
      title: 'Safety Invariants & DO-178C Certification Boundary',
      category: 'SAFETY',
      content: `# Safety Architecture & Certification Boundary

### Certification Alignment
- **DO-178C / ED-12C**: Software Considerations in Airborne Systems and Equipment Certification (DAL-A).
- **EASA Special Condition VTOL**: SC-VTOL.2510 Equipment, systems and installations.

### Architectural Invariants
1. No control output without valid state estimation.
2. No mode transition permitted without verified entry conditions.
3. No direct physical actuator interface enabled in development builds.
4. Tri-redundant voting ensures single sensor failure cannot cause flight upset.
5. All test runs produce immutable cryptographically signed evidence records.`,
    },
  ];

  const [activeDocId, setActiveDocId] = useState<string>('README');
  const activeDoc = docs.find((d) => d.id === activeDocId) || docs[0];

  return (
    <div className="bg-[#0b0f17] border border-slate-800 p-4 font-mono-aerospace space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-sky-400" />
            <h3 className="text-sm font-tech font-bold text-slate-100 tracking-wider">
              ENGINEERING SPECIFICATIONS & CERTIFICATION ARCHIVES
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            Duke Satoshi of Cyberspace PLC · 18 Authoritative Systems Documents
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Navigation Sidebar */}
        <div className="bg-slate-900 border border-slate-800 p-2 space-y-1">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider px-2 py-1">
            DOCUMENT INDEX
          </div>
          {docs.map((d) => (
            <button
              key={d.id}
              onClick={() => setActiveDocId(d.id)}
              className={`w-full text-left px-2.5 py-1.5 text-xs transition-colors flex items-center justify-between ${
                activeDocId === d.id
                  ? 'bg-sky-600 text-white font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <div className="truncate">{d.filename}</div>
              <ChevronRight className="w-3.5 h-3.5 opacity-60" />
            </button>
          ))}
        </div>

        {/* Content Viewer */}
        <div className="md:col-span-3 bg-slate-900/90 border border-slate-800 p-4 min-h-[340px]">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
            <span className="text-xs font-bold text-sky-400">{activeDoc.filename}</span>
            <span className="text-[10px] text-slate-500 bg-slate-950 px-2 py-0.5 border border-slate-800">
              {activeDoc.category}
            </span>
          </div>

          <div className="prose prose-invert max-w-none text-xs text-slate-300 whitespace-pre-wrap leading-relaxed">
            {activeDoc.content}
          </div>
        </div>
      </div>
    </div>
  );
};
