/**
 * VTOL.OS Digital Twin & Synthetic Fleet Analytics
 * Duke Satoshi of Cyberspace PLC
 * 
 * Signature Demo 05: Fleet of 100 aircraft with deep diagnostic dive into Aircraft 37.
 * Shows Measured vs Modelled residuals, Vibration FFT harmonics, and SOH degradation.
 */

import React, { useState } from 'react';
import { FleetAircraft } from '../types/vtol';
import { Cpu, Activity, Zap, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';

export const DigitalTwinFleet: React.FC = () => {
  // Generate 100 synthetic fleet aircraft
  const [fleet] = useState<FleetAircraft[]>(() => {
    const list: FleetAircraft[] = [];
    for (let i = 1; i <= 100; i++) {
      const is37 = i === 37;
      const isMaint = i === 12 || i === 54 || i === 89;
      const isHold = i === 23;
      list.push({
        id: `DCS-VTOL-${String(i).padStart(3, '0')}`,
        serialNumber: `SN-2026-UK-${String(8400 + i)}`,
        flightCount: is37 ? 248 : Math.floor(120 + (i * 7) % 350),
        flightHours: is37 ? 312.4 : Number((80 + (i * 9.2) % 410).toFixed(1)),
        batterySohPct: is37 ? 96.4 : Number((92.0 + (i * 0.17) % 7.8).toFixed(1)),
        motorEfficiencyPct: is37 ? 98.1 : Number((97.2 + (i * 0.05) % 2.4).toFixed(1)),
        vibrationRmsG: is37 ? 0.014 : Number((0.012 + (i * 0.001) % 0.015).toFixed(3)),
        modelResidualNorm: is37 ? 0.012 : Number((0.009 + (i * 0.002) % 0.02).toFixed(3)),
        status: isHold ? 'DIAGNOSTIC_HOLD' : isMaint ? 'SCHEDULED_MAINTENANCE' : 'AIRWORTHY',
        lastFlightId: `FLT-UK-${String(1000 + i)}`,
      });
    }
    return list;
  });

  const [selectedAircraftId, setSelectedAircraftId] = useState<string>('DCS-VTOL-037');
  const selectedAircraft = fleet.find(a => a.id === selectedAircraftId) || fleet[36];

  // FFT vibration harmonics for selected aircraft (0 to 200 Hz)
  const fftFrequencies = [10, 24, 40, 60, 80, 100, 120, 140, 160, 180, 200];
  const fftAmplitudes = [0.002, 0.014, 0.005, 0.003, 0.008, 0.002, 0.004, 0.002, 0.001, 0.002, 0.001];

  return (
    <div className="bg-[#0b0f17] border border-slate-800 p-4 font-mono-aerospace space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-purple-400" />
            <h3 className="text-sm font-tech font-bold text-slate-100 tracking-wider">
              FLEET DIGITAL TWIN & PREDICTIVE DIAGNOSTICS
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            Duke Satoshi PLC · 100 Autonomous Continuous-Computing Airframes Tracked
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">ACTIVE SELECTION:</span>
          <span className="text-xs text-sky-400 font-bold bg-slate-900 border border-slate-700 px-2 py-0.5">
            {selectedAircraft.id}
          </span>
        </div>
      </div>

      {/* Aircraft 37 Deep Dive Diagnostic Card */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-3 bg-slate-900/90 border border-slate-800 p-4">
        
        {/* Sub-Card 1: SOH & Airworthiness */}
        <div className="border-r border-slate-800/80 pr-3">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-1">BATTERY HEALTH (SOH)</div>
          <div className="text-2xl font-bold font-tech text-emerald-400">
            {selectedAircraft.batterySohPct.toFixed(1)} <span className="text-xs text-slate-400">%</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-2 space-y-1">
            <div>STATUS: <span className="text-emerald-400 font-semibold">{selectedAircraft.status}</span></div>
            <div>HOURS: <span className="text-slate-200">{selectedAircraft.flightHours} hrs</span></div>
            <div>CYCLES: <span className="text-slate-200">{selectedAircraft.flightCount}</span></div>
          </div>
        </div>

        {/* Sub-Card 2: Propulsion Efficiency & Residuals */}
        <div className="border-r border-slate-800/80 pr-3">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-1">MOTOR EFFICIENCY</div>
          <div className="text-2xl font-bold font-tech text-sky-400">
            {selectedAircraft.motorEfficiencyPct.toFixed(1)} <span className="text-xs text-slate-400">%</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-2 space-y-1">
            <div>MODEL RESIDUAL: <span className="text-slate-200">{selectedAircraft.modelResidualNorm} (LOW)</span></div>
            <div>RMS VIBRATION: <span className="text-emerald-400">{selectedAircraft.vibrationRmsG} g</span></div>
            <div>CALIBRATION: <span className="text-emerald-400">NOMINAL</span></div>
          </div>
        </div>

        {/* Sub-Card 3: Accelerometer Vibration FFT Spectrum */}
        <div className="lg:col-span-2">
          <div className="flex items-center justify-between mb-1.5">
            <div className="text-[10px] text-slate-400 uppercase tracking-wider">
              VIBRATION FFT HARMONICS (ACCELEROMETER SPECTRUM)
            </div>
            <span className="text-[10px] text-slate-500">1P / 2P / 4P Motor Peaks</span>
          </div>
          <div className="h-20 flex items-end gap-1.5 pt-2 bg-slate-950/60 p-2 border border-slate-800">
            {fftFrequencies.map((freq, idx) => {
              const amp = fftAmplitudes[idx];
              const heightPct = Math.min(100, (amp / 0.016) * 100);
              const isPeak = freq === 24; // blade pass frequency peak
              return (
                <div key={freq} className="flex-1 flex flex-col items-center gap-1 h-full justify-end">
                  <div
                    style={{ height: `${heightPct}%` }}
                    className={`w-full transition-all ${
                      isPeak ? 'bg-amber-400' : 'bg-sky-600/70'
                    }`}
                  />
                  <span className="text-[9px] text-slate-500">{freq}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Synthetic 100-Aircraft Grid Selector */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="text-xs font-tech font-bold text-slate-300">
            FLEET MATRIX (100 AIRFRAMES) — CLICK TO INSPECT TWIN
          </div>
          <div className="flex items-center gap-3 text-[11px] text-slate-400">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span> Airworthy (96)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-amber-500"></span> Maintenance (3)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-rose-500"></span> Hold (1)
            </span>
          </div>
        </div>

        <div className="grid grid-cols-5 sm:grid-cols-10 md:grid-cols-20 gap-1 max-h-48 overflow-y-auto p-1 bg-slate-950/80 border border-slate-800">
          {fleet.map((ac) => {
            const isSelected = ac.id === selectedAircraft.id;
            const isHold = ac.status === 'DIAGNOSTIC_HOLD';
            const isMaint = ac.status === 'SCHEDULED_MAINTENANCE';

            let bgClass = 'bg-slate-900 text-slate-400 hover:bg-slate-800 border-slate-800';
            if (isHold) bgClass = 'bg-rose-950/80 text-rose-300 border-rose-700';
            else if (isMaint) bgClass = 'bg-amber-950/80 text-amber-300 border-amber-700';

            if (isSelected) {
              bgClass = 'bg-sky-600 text-white font-bold border-sky-400';
            }

            return (
              <button
                key={ac.id}
                onClick={() => setSelectedAircraftId(ac.id)}
                className={`text-[10px] py-1 border transition-colors text-center ${bgClass}`}
                title={`${ac.id} · SoH: ${ac.batterySohPct}% · Hours: ${ac.flightHours}`}
              >
                {ac.id.replace('DCS-VTOL-', '')}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
