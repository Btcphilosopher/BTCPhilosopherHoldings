/**
 * VTOL.OS Aircraft Design Laboratory
 * Duke Satoshi of Cyberspace PLC
 * 
 * Signature Demo 09: Parametric Sizing, Disk Loading, and Flight Envelope Solver
 */

import React, { useState } from 'react';
import { Compass, RotateCcw } from 'lucide-react';
import { DCS_VTOL_01_CONFIG } from '../core/physicsEngine';

export const AircraftDesignLab: React.FC = () => {
  const [massKg, setMassKg] = useState(2450);
  const [wingAreaM2, setWingAreaM2] = useState(18.2);
  const [aspectRatio, setAspectRatio] = useState(11.4);
  const [rotorDiameterM, setRotorDiameterM] = useState(1.85);
  const [batteryCapacityKwh, setBatteryCapacityKwh] = useState(142);
  const [cd0, setCd0] = useState(0.021);

  // Aerodynamic sizing calculations
  const weightN = massKg * 9.80665;
  const rho = 1.225; // Sea level air density
  const totalDiskAreaM2 = 8 * (Math.PI * Math.pow(rotorDiameterM / 2, 2));
  
  // Momentum theory ideal induced hover power Pi = sqrt(T^3 / (2 * rho * A))
  const idealHoverPowerWatts = Math.sqrt(Math.pow(weightN, 3) / (2 * rho * totalDiskAreaM2));
  const hoverFigureOfMerit = 0.72;
  const actualHoverPowerKw = (idealHoverPowerWatts / hoverFigureOfMerit) / 1000;

  // Cruise power at 74 kt (38.1 m/s)
  const vCruiseMps = 38.1;
  const qCruise = 0.5 * rho * Math.pow(vCruiseMps, 2);
  const kInduced = 1 / (Math.PI * 0.85 * aspectRatio);
  const clCruise = weightN / (qCruise * wingAreaM2);
  const cdCruise = cd0 + kInduced * Math.pow(clCruise, 2);
  const dragCruiseN = qCruise * wingAreaM2 * cdCruise;
  const cruisePowerKw = (dragCruiseN * vCruiseMps) / (0.85 * 1000) + 18.0; // prop efficiency + avionics

  // Range and endurance
  const usableEnergyKwh = batteryCapacityKwh * 0.8; // 20% landing reserve
  const enduranceHours = usableEnergyKwh / cruisePowerKw;
  const enduranceMins = enduranceHours * 60;
  const maxRangeKm = enduranceHours * (vCruiseMps * 3.6);

  const diskLoading = weightN / totalDiskAreaM2;
  const wingLoading = massKg / wingAreaM2;

  const resetToBaseline = () => {
    setMassKg(DCS_VTOL_01_CONFIG.massKg);
    setWingAreaM2(DCS_VTOL_01_CONFIG.wingAreaM2);
    setAspectRatio(DCS_VTOL_01_CONFIG.aspectRatio);
    setRotorDiameterM(DCS_VTOL_01_CONFIG.liftRotorDiameterM);
    setBatteryCapacityKwh(DCS_VTOL_01_CONFIG.batteryCapacityKwh);
    setCd0(DCS_VTOL_01_CONFIG.cd0);
  };

  return (
    <div className="bg-[#0b0f17] border border-slate-800 p-4 font-mono-aerospace space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-tech font-bold text-slate-100 tracking-wider">
              AIRCRAFT DESIGN & PARAMETRIC SIZING LAB
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            Duke Satoshi PLC · Multidisciplinary Optimization & Performance Envelope Sizing
          </p>
        </div>
        <button
          onClick={resetToBaseline}
          className="flex items-center gap-1.5 px-3 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors border border-slate-700"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>RESET TO DCS-VTOL-01</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Sliders Column */}
        <div className="bg-slate-900/90 border border-slate-800 p-3 space-y-3">
          <div className="text-xs font-tech font-bold text-slate-200">
            AIRFRAME PARAMETERS
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400">MAX TAKEOFF WEIGHT (MTOW):</span>
              <span className="text-sky-400 font-bold">{massKg.toLocaleString()} kg</span>
            </div>
            <input
              type="range"
              min="1800"
              max="3200"
              step="50"
              value={massKg}
              onChange={(e) => setMassKg(parseInt(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400">WING AREA (S):</span>
              <span className="text-sky-400 font-bold">{wingAreaM2.toFixed(1)} m²</span>
            </div>
            <input
              type="range"
              min="12.0"
              max="26.0"
              step="0.5"
              value={wingAreaM2}
              onChange={(e) => setWingAreaM2(parseFloat(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400">WING ASPECT RATIO (AR):</span>
              <span className="text-sky-400 font-bold">{aspectRatio.toFixed(1)}</span>
            </div>
            <input
              type="range"
              min="8.0"
              max="16.0"
              step="0.2"
              value={aspectRatio}
              onChange={(e) => setAspectRatio(parseFloat(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400">LIFT ROTOR DIAMETER:</span>
              <span className="text-sky-400 font-bold">{rotorDiameterM.toFixed(2)} m</span>
            </div>
            <input
              type="range"
              min="1.4"
              max="2.4"
              step="0.05"
              value={rotorDiameterM}
              onChange={(e) => setRotorDiameterM(parseFloat(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400">BATTERY PACK CAPACITY:</span>
              <span className="text-emerald-400 font-bold">{batteryCapacityKwh} kWh</span>
            </div>
            <input
              type="range"
              min="90"
              max="220"
              step="5"
              value={batteryCapacityKwh}
              onChange={(e) => setBatteryCapacityKwh(parseInt(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>
        </div>

        {/* Calculated Results Column */}
        <div className="bg-slate-900/90 border border-slate-800 p-3 flex flex-col justify-between">
          <div>
            <div className="text-xs font-tech font-bold text-slate-200 mb-3">
              COMPUTED PERFORMANCE ENVELOPE
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-950 p-2.5 border border-slate-800">
                <div className="text-[10px] text-slate-400">HOVER POWER REQUIRED</div>
                <div className="text-xl font-bold font-tech text-amber-400 mt-1">
                  {actualHoverPowerKw.toFixed(1)} <span className="text-xs text-slate-400">kW</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Disk Loading: {diskLoading.toFixed(0)} N/m²</div>
              </div>

              <div className="bg-slate-950 p-2.5 border border-slate-800">
                <div className="text-[10px] text-slate-400">CRUISE POWER REQUIRED</div>
                <div className="text-xl font-bold font-tech text-sky-400 mt-1">
                  {cruisePowerKw.toFixed(1)} <span className="text-xs text-slate-400">kW</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Wing Loading: {wingLoading.toFixed(1)} kg/m²</div>
              </div>

              <div className="bg-slate-950 p-2.5 border border-slate-800">
                <div className="text-[10px] text-slate-400">ESTIMATED CRUISE RANGE</div>
                <div className="text-xl font-bold font-tech text-emerald-400 mt-1">
                  {maxRangeKm.toFixed(1)} <span className="text-xs text-slate-400">km</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">With 20% landing reserve</div>
              </div>

              <div className="bg-slate-950 p-2.5 border border-slate-800">
                <div className="text-[10px] text-slate-400">CRUISE ENDURANCE</div>
                <div className="text-xl font-bold font-tech text-emerald-400 mt-1">
                  {enduranceMins.toFixed(0)} <span className="text-xs text-slate-400">min</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">{(enduranceHours).toFixed(2)} flight hours</div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>TRANSITION POWER MARGIN: <strong className="text-emerald-400">+28.4% Available</strong></span>
            <span>CL CRUISE: <strong className="text-slate-200">{clCruise.toFixed(3)}</strong></span>
          </div>
        </div>
      </div>
    </div>
  );
};
