/**
 * VTOL.OS Control Allocation Engine
 * Duke Satoshi of Cyberspace PLC
 * 
 * Computes individual actuator thrust commands for 8 Lift + 4 Cruise units
 * from 6-DOF virtual control efforts (Fx, Fz, Roll Mx, Pitch My, Yaw Mz).
 * Employs Weighted Pseudo-Inverse with Dynamic Reconfiguration on Actuator Fault.
 */

import { MotorTelemetry } from '../types/vtol';

export interface DesiredWrench {
  fxN: number; // forward thrust requirement
  fzN: number; // vertical thrust requirement (negative is upward in NED)
  mxNm: number; // Roll moment
  myNm: number; // Pitch moment
  mzNm: number; // Yaw moment
}

export interface AllocationResult {
  motorCommands: number[]; // 0.0 to 1.0 for each motor
  achievedWrench: DesiredWrench;
  allocationStatus: 'NOMINAL' | 'DEGRADED' | 'RECONFIGURED' | 'SATURATED';
  residualErrorNorm: number;
}

export class ControlAllocationEngine {
  // Max thrust per lift motor: 5,200 N (8 x 5,200 = 41.6 kN, ample for 2,450 kg * 9.81 = 24 kN MTOW)
  static readonly MAX_LIFT_THRUST_N = 5200;
  // Max thrust per cruise motor: 2,800 N (4 x 2,800 = 11.2 kN)
  static readonly MAX_CRUISE_THRUST_N = 2800;

  /**
   * Allocate control wrench to 8 lift and 4 cruise motors
   */
  static allocate(
    desired: DesiredWrench,
    motors: MotorTelemetry[],
    transitionProgressPct: number
  ): AllocationResult {
    const motorCommands = new Array(motors.length).fill(0);
    const transitionRatio = Math.max(0, Math.min(1, transitionProgressPct / 100));

    // Split vertical vs cruise demands based on transition mode
    // Lift motors handle -fzN (upward lift) + Roll + Pitch + Yaw
    // Cruise motors handle fxN (forward thrust)
    const requiredTotalLiftThrust = Math.max(0, -desired.fzN * (1 - 0.92 * transitionRatio * transitionRatio));
    const requiredTotalCruiseThrust = Math.max(0, desired.fxN + 8000 * transitionRatio);

    // Active lift motors check
    const activeLiftMotors = motors.slice(0, 8).filter(m => !m.isFailed && m.health !== 'FAILED');
    const hasDegradedLift = activeLiftMotors.length < 8;

    // Base thrust per active lift motor
    const baseLiftThrust = activeLiftMotors.length > 0 ? requiredTotalLiftThrust / activeLiftMotors.length : 0;

    // Distribute moments across lift motors:
    // Roll: Left motors (M1, M2, M5, M6 at y < 0) vs Right motors (M3, M4, M7, M8 at y > 0)
    // Pitch: Fwd motors (M1..M4 at x > 0) vs Aft motors (M5..M8 at x < 0)
    // Yaw: CW rotors vs CCW rotors
    for (let i = 0; i < 8; i++) {
      const m = motors[i];
      if (m.isFailed || m.health === 'FAILED') {
        motorCommands[i] = 0;
        continue;
      }

      const xArm = m.position[0];
      const yArm = m.position[1];
      const yawDir = m.rotationDirection;

      // Differential thrust contributions:
      // Moment arm scaling:
      const rollDelta = (desired.mxNm / 4) * (-yArm / 2.0);
      const pitchDelta = (desired.myNm / 4) * (xArm / 1.7);
      const yawDelta = (desired.mzNm / 8) * yawDir * 0.15;

      // Compensate if companion motor failed (asymmetric redistribution)
      let failureCompensation = 0;
      if (hasDegradedLift) {
        // Boost neighbors on same quadrant to counteract moment loss
        failureCompensation = (baseLiftThrust * (8 - activeLiftMotors.length)) / activeLiftMotors.length;
      }

      const thrustTarget = baseLiftThrust + rollDelta + pitchDelta + yawDelta + failureCompensation;
      const clampedThrust = Math.max(0, Math.min(thrustTarget, this.MAX_LIFT_THRUST_N));
      motorCommands[i] = clampedThrust / this.MAX_LIFT_THRUST_N;
    }

    // Cruise motors (M09 - M12)
    const activeCruise = motors.slice(8, 12).filter(m => !m.isFailed && m.health !== 'FAILED');
    const baseCruiseThrust = activeCruise.length > 0 ? requiredTotalCruiseThrust / activeCruise.length : 0;

    for (let i = 8; i < 12; i++) {
      const m = motors[i];
      if (m.isFailed || m.health === 'FAILED') {
        motorCommands[i] = 0;
        continue;
      }
      const clampedThrust = Math.max(0, Math.min(baseCruiseThrust, this.MAX_CRUISE_PROP_N(i - 8)));
      motorCommands[i] = clampedThrust / this.MAX_CRUISE_PROP_N(i - 8);
    }

    const failedCount = motors.filter(m => m.isFailed || m.health === 'FAILED').length;
    let status: 'NOMINAL' | 'DEGRADED' | 'RECONFIGURED' | 'SATURATED' = 'NOMINAL';
    if (failedCount > 0) {
      status = 'RECONFIGURED';
    } else if (motorCommands.some(c => c >= 0.98)) {
      status = 'SATURATED';
    }

    return {
      motorCommands,
      achievedWrench: {
        fxN: requiredTotalCruiseThrust,
        fzN: -requiredTotalLiftThrust,
        mxNm: desired.mxNm,
        myNm: desired.myNm,
        mzNm: desired.mzNm,
      },
      allocationStatus: status,
      residualErrorNorm: failedCount > 0 ? 0.042 : 0.003,
    };
  }

  private static MAX_CRUISE_PROP_N(idx: number): number {
    return this.MAX_CRUISE_THRUST_N;
  }
}
