/**
 * VTOL.OS Physics Engine
 * Duke Satoshi of Cyberspace PLC
 * 
 * Deterministic 6-DOF Flight Dynamics, ISA Atmosphere, Aerodynamics,
 * Rotor Momentum Theory, and Dryden Turbulence Model.
 */

import { Vector3D, Quaternion, EulerAngles, MotorTelemetry } from '../types/vtol';

export interface AirframeParams {
  massKg: number;
  wingAreaM2: number;
  wingSpanM: number;
  aspectRatio: number;
  cd0: number; // parasite drag
  oswaldEfficiency: number;
  clAlpha: number; // 1/rad
  cl0: number;
  maxCl: number;
  stallAngleDeg: number;
  liftMotorCount: number;
  cruiseMotorCount: number;
  liftRotorDiameterM: number;
  cruisePropDiameterM: number;
  batteryCapacityKwh: number;
  batteryNominalVoltageV: number;
}

export const DCS_VTOL_01_CONFIG: AirframeParams = {
  massKg: 2450,
  wingAreaM2: 18.2,
  wingSpanM: 14.4,
  aspectRatio: 11.4,
  cd0: 0.021,
  oswaldEfficiency: 0.85,
  clAlpha: 5.4, // per rad
  cl0: 0.28,
  maxCl: 1.55,
  stallAngleDeg: 14.5,
  liftMotorCount: 8,
  cruiseMotorCount: 4,
  liftRotorDiameterM: 1.85,
  cruisePropDiameterM: 1.60,
  batteryCapacityKwh: 142,
  batteryNominalVoltageV: 780,
};

export class AtmosphereISA {
  static readonly T0 = 288.15; // Sea level standard temp K
  static readonly P0 = 101325; // Sea level standard pressure Pa
  static readonly RHO0 = 1.225; // Sea level density kg/m3
  static readonly L = 0.0065; // Temp lapse rate K/m
  static readonly G = 9.80665;
  static readonly R = 287.05;

  static calculate(altitudeM: number): { tempK: number; tempC: number; pressurePa: number; densityKgM3: number } {
    const h = Math.max(-500, Math.min(altitudeM, 11000));
    const tempK = this.T0 - this.L * h;
    const pressurePa = this.P0 * Math.pow(1 - (this.L * h) / this.T0, this.G / (this.R * this.L));
    const densityKgM3 = pressurePa / (this.R * tempK);
    return {
      tempK,
      tempC: tempK - 273.15,
      pressurePa,
      densityKgM3,
    };
  }
}

export function quatToEuler(q: Quaternion): EulerAngles {
  // Roll (x-axis rotation)
  const sinr_cosp = 2 * (q.w * q.x + q.y * q.z);
  const cosr_cosp = 1 - 2 * (q.x * q.x + q.y * q.y);
  const rollRad = Math.atan2(sinr_cosp, cosr_cosp);

  // Pitch (y-axis rotation)
  const sinp = 2 * (q.w * q.y - q.z * q.x);
  let pitchRad: number;
  if (Math.abs(sinp) >= 1) {
    pitchRad = Math.sign(sinp) * (Math.PI / 2);
  } else {
    pitchRad = Math.asin(sinp);
  }

  // Yaw (z-axis rotation)
  const siny_cosp = 2 * (q.w * q.z + q.x * q.y);
  const cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z);
  const yawRad = Math.atan2(siny_cosp, cosy_cosp);

  return {
    rollDeg: (rollRad * 180) / Math.PI,
    pitchDeg: (pitchRad * 180) / Math.PI,
    yawDeg: ((yawRad * 180) / Math.PI + 360) % 360,
  };
}

export function eulerToQuat(rollDeg: number, pitchDeg: number, yawDeg: number): Quaternion {
  const phi = (rollDeg * Math.PI) / 360;
  const theta = (pitchDeg * Math.PI) / 360;
  const psi = (yawDeg * Math.PI) / 360;

  const cosPhi = Math.cos(phi);
  const sinPhi = Math.sin(phi);
  const cosTheta = Math.cos(theta);
  const sinTheta = Math.sin(theta);
  const cosPsi = Math.cos(psi);
  const sinPsi = Math.sin(psi);

  return {
    w: cosPhi * cosTheta * cosPsi + sinPhi * sinTheta * sinPsi,
    x: sinPhi * cosTheta * cosPsi - cosPhi * sinTheta * sinPsi,
    y: cosPhi * sinTheta * cosPsi + sinPhi * cosTheta * sinPsi,
    z: cosPhi * cosTheta * sinPsi - sinPhi * sinTheta * cosPsi,
  };
}

export function initializeMotors(): MotorTelemetry[] {
  const motors: MotorTelemetry[] = [];

  // 8 Lift Motors arranged on forward and aft booms
  // Forward Boom: Left Outer, Left Inner, Right Inner, Right Outer
  const liftPositions: [number, number, number][] = [
    [1.8, -2.6, -0.2],  // Motor 01: Fwd Left Outer
    [1.8, -1.2, -0.2],  // Motor 02: Fwd Left Inner
    [1.8, 1.2, -0.2],   // Motor 03: Fwd Right Inner
    [1.8, 2.6, -0.2],   // Motor 04: Fwd Right Outer
    [-1.6, -2.6, -0.1], // Motor 05: Aft Left Outer
    [-1.6, -1.2, -0.1], // Motor 06: Aft Left Inner
    [-1.6, 1.2, -0.1],  // Motor 07: Aft Right Inner
    [-1.6, 2.6, -0.1],  // Motor 08: Aft Right Outer
  ];

  for (let i = 0; i < 8; i++) {
    const isCW = (i % 2 === 0) ? 1 : -1;
    motors.push({
      id: i + 1,
      name: `LIFT_M${String(i + 1).padStart(2, '0')}`,
      type: 'LIFT',
      position: liftPositions[i],
      rotationDirection: isCW as 1 | -1,
      rpm: 0,
      thrustN: 0,
      torqueNm: 0,
      currentA: 0,
      voltageV: 780,
      tempC: 32.5,
      efficiencyPct: 98.2,
      health: 'NORMAL',
      commandedRatio: 0,
      isFailed: false,
    });
  }

  // 4 Cruise Propulsion Units on trailing wing & nacelles
  const cruisePositions: [number, number, number][] = [
    [0.2, -3.8, 0.1], // Cruise 01: Wing Outer Left
    [0.2, -1.8, 0.1], // Cruise 02: Wing Inner Left
    [0.2, 1.8, 0.1],  // Cruise 03: Wing Inner Right
    [0.2, 3.8, 0.1],  // Cruise 04: Wing Outer Right
  ];

  for (let i = 0; i < 4; i++) {
    motors.push({
      id: i + 9,
      name: `CRUISE_M${String(i + 1).padStart(2, '0')}`,
      type: 'CRUISE',
      position: cruisePositions[i],
      rotationDirection: (i % 2 === 0 ? 1 : -1) as 1 | -1,
      rpm: 0,
      thrustN: 0,
      torqueNm: 0,
      currentA: 0,
      voltageV: 780,
      tempC: 30.0,
      efficiencyPct: 97.9,
      health: 'NORMAL',
      commandedRatio: 0,
      isFailed: false,
    });
  }

  return motors;
}
