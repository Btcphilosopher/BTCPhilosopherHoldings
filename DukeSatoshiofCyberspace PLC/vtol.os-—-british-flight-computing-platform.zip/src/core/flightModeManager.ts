/**
 * VTOL.OS Flight Mode Manager
 * Duke Satoshi of Cyberspace PLC
 * 
 * Strict Finite State Machine with Certification-Oriented Transition Invariants.
 * Invariant: No mode transition permitted without meeting formal entry conditions.
 */

import { FlightMode, VehicleState } from '../types/vtol';

export interface TransitionConditionResult {
  allowed: boolean;
  reason?: string;
}

export class FlightModeManager {
  private static readonly VALID_TRANSITIONS: Record<FlightMode, FlightMode[]> = {
    GROUND: ['PRE_FLIGHT'],
    PRE_FLIGHT: ['ARMED_SIMULATION', 'GROUND'],
    ARMED_SIMULATION: ['TAKEOFF', 'GROUND'],
    TAKEOFF: ['HOVER', 'ABORT'],
    HOVER: ['TRANSITION_TO_CRUISE', 'LANDING', 'EMERGENCY', 'ABORT'],
    TRANSITION_TO_CRUISE: ['CRUISE', 'TRANSITION_TO_HOVER', 'EMERGENCY'],
    CRUISE: ['TRANSITION_TO_HOVER', 'EMERGENCY'],
    TRANSITION_TO_HOVER: ['HOVER', 'APPROACH', 'EMERGENCY'],
    APPROACH: ['LANDING', 'HOVER', 'EMERGENCY', 'ABORT'],
    LANDING: ['LANDED', 'HOVER', 'ABORT'],
    LANDED: ['GROUND'],
    EMERGENCY: ['LANDING', 'LANDED'],
    ABORT: ['HOVER', 'LANDING'],
  };

  /**
   * Evaluates if transition to target mode is safe and valid
   */
  static validateTransition(
    current: FlightMode,
    target: FlightMode,
    state: Partial<VehicleState>
  ): TransitionConditionResult {
    const validTargets = this.VALID_TRANSITIONS[current] || [];
    if (!validTargets.includes(target)) {
      return {
        allowed: false,
        reason: `Direct transition from ${current} to ${target} violates DO-178C state invariant.`,
      };
    }

    // Specific condition checks
    if (target === 'TAKEOFF') {
      if ((state.battery?.socPct ?? 0) < 20.0) {
        return { allowed: false, reason: 'Takeoff aborted: Battery SOC below 20% minimum safety reserve.' };
      }
    }

    if (target === 'TRANSITION_TO_CRUISE') {
      if ((state.altitudeM ?? 0) < 15.0) {
        return { allowed: false, reason: 'Transition aborted: Altitude below 15m minimum obstacle clearance.' };
      }
    }

    if (target === 'CRUISE') {
      if ((state.airspeedKnots ?? 0) < 55.0) {
        return { allowed: false, reason: 'Cruise engagement aborted: Airspeed below wing stall threshold (55 kt).' };
      }
    }

    return { allowed: true };
  }
}
