/**
 * VTOL.OS Energy & Thermal Subsystem (ENERGY.OS)
 * Duke Satoshi of Cyberspace PLC
 * 
 * Equivalent Circuit Model (ECM), Electrochemical SoC/SoH Tracking,
 * Coupled Lumped-Parameter Thermal Model, and Energy Range Prediction.
 */

import { BatteryState } from '../types/vtol';

export class EnergySubsystem {
  private totalCapacityKwh: number = 142.0;
  private energyRemainingKwh: number = 110.76; // 78% initial
  private socPct: number = 78.0;
  private sohPct: number = 96.8;
  private packTempC: number = 34.2;
  private cellImbalanceMv: number = 8.5;
  private nominalPackVoltage: number = 780.0;
  private internalResistanceMOhm: number = 24.5;

  /**
   * Update battery state for a time step dt with total electrical power demand
   */
  update(powerKwDemand: number, ambientTempC: number, dtSec: number): BatteryState {
    // 1. Calculate pack current from terminal power P = V * I
    // Quadratic equation: P = V_oc * I - I^2 * R_int
    // Linearized approximation around operating voltage:
    const approxVoltage = this.nominalPackVoltage * (0.85 + 0.15 * (this.socPct / 100));
    const currentA = (powerKwDemand * 1000) / (approxVoltage || 700);

    // 2. Joulean Heating and Convective Cooling
    const heatGenWatts = Math.pow(currentA, 2) * (this.internalResistanceMOhm / 1000);
    const coolingRateWatts = 42.0 * (this.packTempC - ambientTempC); // Active liquid cooling loop
    const netHeatWatts = heatGenWatts - coolingRateWatts;

    // Thermal mass of battery pack ~ 650 kg * 900 J/(kg*K) = 585,000 J/K
    const packThermalMass = 585000;
    const deltaTempC = (netHeatWatts * dtSec) / packThermalMass;
    this.packTempC = Math.max(ambientTempC, Math.min(65.0, this.packTempC + deltaTempC));

    // 3. Electrochemical discharge integration
    const energyUsedKwh = (powerKwDemand * dtSec) / 3600;
    this.energyRemainingKwh = Math.max(0, this.energyRemainingKwh - energyUsedKwh);
    this.socPct = Math.max(0, Math.min(100, (this.energyRemainingKwh / this.totalCapacityKwh) * 100));

    // Cell thermal spread (min/max)
    const maxCellTemp = this.packTempC + 1.8;
    const minCellTemp = this.packTempC - 1.2;
    const thermalProtection = maxCellTemp > 55.0;

    return {
      socPct: Number(this.socPct.toFixed(1)),
      sohPct: this.sohPct,
      packVoltageV: Number((approxVoltage - (currentA * this.internalResistanceMOhm) / 1000).toFixed(1)),
      packCurrentA: Number(currentA.toFixed(1)),
      powerKw: Number(powerKwDemand.toFixed(1)),
      packTempC: Number(this.packTempC.toFixed(1)),
      maxCellTempC: Number(maxCellTemp.toFixed(1)),
      minCellTempC: Number(minCellTemp.toFixed(1)),
      internalResistanceMOhm: Number((this.internalResistanceMOhm + (this.packTempC > 45 ? 4.0 : 0)).toFixed(1)),
      energyRemainingKwh: Number(this.energyRemainingKwh.toFixed(2)),
      totalCapacityKwh: this.totalCapacityKwh,
      cellImbalanceMv: this.cellImbalanceMv,
      thermalProtectionActive: thermalProtection,
    };
  }

  setSoc(socPct: number) {
    this.socPct = Math.max(0, Math.min(100, socPct));
    this.energyRemainingKwh = (this.socPct / 100) * this.totalCapacityKwh;
  }
}
