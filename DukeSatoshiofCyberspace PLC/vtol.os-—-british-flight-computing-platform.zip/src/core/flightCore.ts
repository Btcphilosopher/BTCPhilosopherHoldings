/**
 * VTOL.OS FLIGHTCORE Runtime
 * Duke Satoshi of Cyberspace PLC
 * 
 * Authoritative systems-engineering loop managing sensors, estimation,
 * flight modes, control allocation, propulsion, battery, and diagnostics.
 */

import {
  VehicleState,
  FlightMode,
  ExecutionEnvironment,
  SensorSnapshot,
  AircraftFault,
  MotorTelemetry,
  RequirementNode,
  FleetAircraft,
} from '../types/vtol';
import { initializeMotors, AtmosphereISA, DCS_VTOL_01_CONFIG } from './physicsEngine';
import { ControlAllocationEngine, DesiredWrench } from './controlAllocation';
import { StateEstimator } from './stateEstimator';
import { EnergySubsystem } from './energyModel';
import { FlightModeManager } from './flightModeManager';

export class FlightCoreRuntime {
  private state: VehicleState;
  private estimator: StateEstimator;
  private energy: EnergySubsystem;
  private history: { timeSec: number; altitudeM: number; airspeedKnots: number; powerKw: number; socPct: number }[] = [];

  constructor() {
    this.estimator = new StateEstimator();
    this.energy = new EnergySubsystem();
    this.state = this.createInitialState();
  }

  private createInitialState(): VehicleState {
    const motors = initializeMotors();
    // Sea level ISA atmosphere
    const atmo = AtmosphereISA.calculate(182);

    const sensors: SensorSnapshot = {
      timestampMs: Date.now(),
      imu: {
        accelMps2: { x: 0.05, y: -0.02, z: -9.80 },
        gyroDps: { x: 0.12, y: -0.08, z: 0.05 },
        magGauss: { x: 0.18, y: -0.05, z: 0.42 },
        redundancyA: true,
        redundancyB: true,
        redundancyC: true,
        activePrimary: 'IMU_A',
      },
      gnss: {
        lat: 51.5074, // London
        lon: -0.1278,
        altitudeMslM: 182.4,
        hdop: 0.78,
        satellitesVisible: 18,
        fixQuality: 'RTK_FIXED',
      },
      baro: {
        pressurePa: atmo.pressurePa,
        altitudeBaroM: 182.0,
        valid: true,
      },
      pitot: {
        indicatedAirspeedMps: 37.8,
        trueAirspeedMps: 38.1,
        angleOfAttackDeg: 3.2,
        valid: true,
      },
      radarAltimeterM: 181.8,
    };

    const estimation = this.estimator.update(sensors, 8200, 0.02);

    return {
      aircraftId: 'DCS-VTOL-01',
      architecture: 'DISTRIBUTED_ELECTRIC',
      environment: 'SIMULATION',
      flightMode: 'CRUISE',
      simulationTimeSec: 412.5,
      realTimeRatio: 1.0,
      cycleId: 412500,

      altitudeM: 182.0,
      altitudeFt: 597.1,
      airspeedMps: 38.1,
      airspeedKnots: 74.0,
      groundSpeedKnots: 71.8,
      verticalSpeedMps: 0.0,
      verticalSpeedFpm: 0.0,

      transitionProgressPct: 100.0,
      liftThrustTotalN: 1200,
      cruiseThrustTotalN: 7800,
      aerodynamicLiftN: 22800,
      totalDragN: 7650,

      battery: {
        socPct: 78.0,
        sohPct: 96.8,
        packVoltageV: 762.4,
        packCurrentA: 540.5,
        powerKw: 412.0,
        packTempC: 34.2,
        maxCellTempC: 35.8,
        minCellTempC: 33.1,
        internalResistanceMOhm: 24.5,
        energyRemainingKwh: 110.76,
        totalCapacityKwh: 142.0,
        cellImbalanceMv: 8.5,
        thermalProtectionActive: false,
      },
      motors,
      sensors,
      estimation,

      health: {
        overallStatus: 'NORMAL',
        overallScorePct: 96.8,
        flightComputerStatus: 'NORMAL',
        propulsionStatus: 'NORMAL',
        energyStatus: 'NORMAL',
        sensorsStatus: 'NORMAL',
        navigationStatus: 'NORMAL',
        activeFaults: [],
      },

      mission: {
        missionId: 'MSN-DCS-LON-047',
        currentWaypointIndex: 3,
        totalWaypoints: 6,
        distanceRemainingKm: 28.4,
        etaMinutes: 12.3,
        origin: 'VERTIPORT A (BATTERSEA)',
        destination: 'VERTIPORT B (CITY AIRPORT)',
        divertAlternative: 'VERTIPORT C (STRATFORD)',
        progressPct: 62.0,
      },

      diagnostics: {
        loopFrequencyHz: 1000,
        jitterUs: 42,
        p50LatencyMs: 0.41,
        p95LatencyMs: 0.57,
        p99LatencyMs: 0.72,
        deadlineMissCount: 0,
        cpuLoadPct: 34.2,
        memoryMb: 86.4,
      },
    };
  }

  getState(): VehicleState {
    return this.state;
  }

  getHistory() {
    return this.history;
  }

  setEnvironment(env: ExecutionEnvironment) {
    if (env === 'FLIGHT_DISABLED') {
      return; // invariant: cannot activate real flight output in dev
    }
    this.state.environment = env;
  }

  setArchitecture(arch: any) {
    this.state.architecture = arch;
  }

  /**
   * Run 1 tick of simulation (dt in seconds)
   */
  tick(dt: number) {
    this.state.simulationTimeSec += dt;
    this.state.cycleId += Math.round(dt * 1000);

    // 1. Atmosphere
    const atmo = AtmosphereISA.calculate(this.state.altitudeM);

    // 2. Control demands based on active mode
    let targetAlt = this.state.altitudeM;
    let targetSpeedKnots = this.state.airspeedKnots;
    let desiredTransitionPct = this.state.transitionProgressPct;

    switch (this.state.flightMode) {
      case 'GROUND':
      case 'PRE_FLIGHT':
      case 'ARMED_SIMULATION':
        targetAlt = 0;
        targetSpeedKnots = 0;
        desiredTransitionPct = 0;
        break;
      case 'TAKEOFF':
        targetAlt = 25;
        targetSpeedKnots = 5;
        desiredTransitionPct = 0;
        if (this.state.altitudeM >= 20) {
          this.state.flightMode = 'HOVER';
        }
        break;
      case 'HOVER':
        targetAlt = 30;
        targetSpeedKnots = 8;
        desiredTransitionPct = 0;
        break;
      case 'TRANSITION_TO_CRUISE':
        targetAlt = 150;
        targetSpeedKnots = 65;
        desiredTransitionPct = Math.min(100, this.state.transitionProgressPct + 8 * dt);
        if (desiredTransitionPct >= 99) {
          this.state.flightMode = 'CRUISE';
          desiredTransitionPct = 100;
        }
        break;
      case 'CRUISE':
        targetAlt = 182;
        targetSpeedKnots = 74;
        desiredTransitionPct = 100;
        break;
      case 'TRANSITION_TO_HOVER':
        targetAlt = 40;
        targetSpeedKnots = 15;
        desiredTransitionPct = Math.max(0, this.state.transitionProgressPct - 12 * dt);
        if (desiredTransitionPct <= 2) {
          this.state.flightMode = 'APPROACH';
          desiredTransitionPct = 0;
        }
        break;
      case 'APPROACH':
        targetAlt = 15;
        targetSpeedKnots = 6;
        desiredTransitionPct = 0;
        break;
      case 'LANDING':
        targetAlt = 0;
        targetSpeedKnots = 0;
        desiredTransitionPct = 0;
        if (this.state.altitudeM <= 0.2) {
          this.state.altitudeM = 0;
          this.state.flightMode = 'LANDED';
        }
        break;
    }

    this.state.transitionProgressPct = desiredTransitionPct;

    // Smooth physics dynamics toward target
    const altRate = (targetAlt - this.state.altitudeM) * 0.4;
    this.state.verticalSpeedMps = Math.max(-4.0, Math.min(5.0, altRate));
    this.state.verticalSpeedFpm = this.state.verticalSpeedMps * 196.85;
    this.state.altitudeM = Math.max(0, this.state.altitudeM + this.state.verticalSpeedMps * dt);
    this.state.altitudeFt = this.state.altitudeM * 3.28084;

    const speedRate = (targetSpeedKnots - this.state.airspeedKnots) * 0.3;
    this.state.airspeedKnots = Math.max(0, this.state.airspeedKnots + speedRate * dt);
    this.state.airspeedMps = this.state.airspeedKnots * 0.514444;
    this.state.groundSpeedKnots = Math.max(0, this.state.airspeedKnots - 2.2);

    // 3. Aerodynamics & Power calculation
    const qDynamic = 0.5 * atmo.densityKgM3 * Math.pow(this.state.airspeedMps, 2);
    const sWing = DCS_VTOL_01_CONFIG.wingAreaM2;
    this.state.aerodynamicLiftN = qDynamic * sWing * DCS_VTOL_01_CONFIG.cl0 * (this.state.transitionProgressPct / 100);
    this.state.totalDragN = qDynamic * sWing * (DCS_VTOL_01_CONFIG.cd0 + 0.04 * Math.pow(this.state.transitionProgressPct / 100, 2)) + 400;

    // Total mechanical and electrical power
    // In hover: high lift power ~ 480 kW. In cruise: aerodynamically supported ~ 340-420 kW.
    const hoverPowerFraction = 1 - (this.state.transitionProgressPct / 100) * 0.75;
    let basePowerKw = 150 + 380 * hoverPowerFraction + (this.state.airspeedKnots / 74) * 80;
    if (this.state.flightMode === 'GROUND' || this.state.flightMode === 'LANDED') {
      basePowerKw = 8.5; // avionics baseline
    }

    // 4. Update Battery
    this.state.battery = this.energy.update(basePowerKw, atmo.tempC, dt);

    // 5. Update Control Allocation
    const desiredWrench: DesiredWrench = {
      fxN: this.state.totalDragN,
      fzN: -(DCS_VTOL_01_CONFIG.massKg * 9.81 - this.state.aerodynamicLiftN),
      mxNm: 0,
      myNm: 0,
      mzNm: 0,
    };

    const allocation = ControlAllocationEngine.allocate(
      desiredWrench,
      this.state.motors,
      this.state.transitionProgressPct
    );

    // Update each motor's telemetry
    for (let i = 0; i < this.state.motors.length; i++) {
      const m = this.state.motors[i];
      const cmd = allocation.motorCommands[i];
      m.commandedRatio = cmd;

      if (m.isFailed) {
        m.rpm = 0;
        m.thrustN = 0;
        m.currentA = 0;
        m.tempC = Math.min(115, m.tempC + 0.1 * dt);
        m.health = 'FAILED';
      } else {
        const maxRpm = m.type === 'LIFT' ? 2400 : 3600;
        const maxThrust = m.type === 'LIFT' ? 5200 : 2800;
        m.rpm = Math.round(cmd * maxRpm);
        m.thrustN = Math.round(cmd * maxThrust);
        m.currentA = Math.round(cmd * (basePowerKw * 1000 / (12 * 780)));
        m.tempC = Math.round(32 + cmd * 18 + (this.state.simulationTimeSec % 5) * 0.2);
        m.efficiencyPct = cmd > 0.1 ? 98.2 - cmd * 1.5 : 99.0;
        m.health = m.tempC > 58 ? 'WARNING' : 'NORMAL';
      }
    }

    // 6. Sensor synthesis & EKF update
    this.state.sensors.timestampMs = Date.now();
    this.state.sensors.baro.altitudeBaroM = this.state.altitudeM;
    this.state.sensors.baro.pressurePa = atmo.pressurePa;
    this.state.sensors.pitot.indicatedAirspeedMps = this.state.airspeedMps;
    this.state.sensors.radarAltimeterM = Math.max(0, this.state.altitudeM);

    this.state.estimation = this.estimator.update(this.state.sensors, this.state.liftThrustTotalN, dt);

    // 7. Update Mission progress
    if (this.state.airspeedKnots > 10) {
      const distanceCoveredKm = (this.state.airspeedKnots * 1.852 * dt) / 3600;
      this.state.mission.distanceRemainingKm = Math.max(0, this.state.mission.distanceRemainingKm - distanceCoveredKm);
      this.state.mission.progressPct = Math.min(100, 100 - (this.state.mission.distanceRemainingKm / 46.0) * 100);
      this.state.mission.etaMinutes = (this.state.mission.distanceRemainingKm / (this.state.airspeedKnots * 1.852)) * 60;
    }

    // 8. Push history snapshot
    if (this.history.length === 0 || this.state.simulationTimeSec - this.history[this.history.length - 1].timeSec >= 0.5) {
      this.history.push({
        timeSec: Number(this.state.simulationTimeSec.toFixed(1)),
        altitudeM: Number(this.state.altitudeM.toFixed(1)),
        airspeedKnots: Number(this.state.airspeedKnots.toFixed(1)),
        powerKw: this.state.battery.powerKw,
        socPct: this.state.battery.socPct,
      });
      if (this.history.length > 200) {
        this.history.shift();
      }
    }
  }

  // --- SIGNATURE DEMO HANDLERS ---

  /**
   * Demo 1: Vertical Takeoff Sequence
   */
  triggerDemoVerticalTakeoff() {
    this.state.flightMode = 'TAKEOFF';
    this.state.altitudeM = 0;
    this.state.airspeedKnots = 0;
    this.state.transitionProgressPct = 0;
    this.estimator.reset(0, 0);
  }

  /**
   * Demo 2: Hover to Cruise Transition
   */
  triggerDemoTransition() {
    this.state.flightMode = 'TRANSITION_TO_CRUISE';
    this.state.altitudeM = 45;
    this.state.airspeedKnots = 20;
    this.state.transitionProgressPct = 5;
  }

  /**
   * Demo 3: Motor Failure & Control Reallocation
   * Motor 03 fails -> Fault logged -> Control allocation dynamically redistributes thrust
   */
  triggerDemoMotorFailure() {
    const motor03 = this.state.motors[2]; // Motor 03 (Fwd Right Inner)
    motor03.isFailed = true;
    motor03.health = 'FAILED';
    motor03.tempC = 94.2;

    const fault: AircraftFault = {
      id: `FLT-${Date.now()}`,
      code: 'PROP_M03_INVERTER_DESYNC',
      source: 'LIFT_M03_INVERTER',
      severity: 'CRITICAL',
      description: 'Loss of phase sync on Motor 03 inverter. Thrust output terminated.',
      timestampSec: this.state.simulationTimeSec,
      acknowledged: false,
      mitigationAction: 'Control Allocation Engine re-weighted: asymmetric moments redistributed to M01, M02, M04.',
    };

    this.state.health.activeFaults.unshift(fault);
    this.state.health.propulsionStatus = 'DEGRADED';
    this.state.health.overallScorePct = 88.4;
  }

  /**
   * Restore all failed motors
   */
  restoreAllMotors() {
    for (const m of this.state.motors) {
      m.isFailed = false;
      m.health = 'NORMAL';
      m.tempC = 34.0;
    }
    this.state.health.activeFaults = [];
    this.state.health.propulsionStatus = 'NORMAL';
    this.state.health.overallScorePct = 96.8;
  }

  /**
   * Demo 4: Low Battery Threshold & Divert Planner
   */
  triggerDemoLowBattery() {
    this.energy.setSoc(18.4);
    this.state.battery.socPct = 18.4;

    const fault: AircraftFault = {
      id: `FLT-SOC-${Date.now()}`,
      code: 'BATT_ENERGY_RESERVE_TRIP',
      source: 'ENERGY.OS_BMS',
      severity: 'WARNING',
      description: 'State of Charge dropped below 20% landing reserve threshold.',
      timestampSec: this.state.simulationTimeSec,
      acknowledged: false,
      mitigationAction: 'Simulated divert calculated to Vertiport C (Stratford, 4.2 km). Alternative approach ready.',
    };

    this.state.health.activeFaults.unshift(fault);
    this.state.health.energyStatus = 'WARNING';
  }

  /**
   * Demo 10: Run Full Autonomous Mission Loop
   */
  triggerFullMission() {
    this.restoreAllMotors();
    this.energy.setSoc(92.0);
    this.state.flightMode = 'TAKEOFF';
    this.state.altitudeM = 0;
    this.state.airspeedKnots = 0;
    this.state.transitionProgressPct = 0;
    this.state.mission.distanceRemainingKm = 46.0;
    this.state.mission.progressPct = 0;
  }
}
