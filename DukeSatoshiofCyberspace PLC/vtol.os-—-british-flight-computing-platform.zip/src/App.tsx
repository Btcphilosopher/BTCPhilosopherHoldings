/**
 * VTOL.OS
 * Duke Satoshi of Cyberspace PLC
 */

import { MainControlDesk } from './components/MainControlDesk';

export default function App() {
  return <MainControlDesk />;
}

