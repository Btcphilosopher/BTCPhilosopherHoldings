/**
 * VTOL.OS Core Type System & Units
 * Duke Satoshi of Cyberspace PLC
 * 
 * Strict unit system:
 * Every quantity has an explicit unit, provenance, and validation status.
 */

export type ExecutionEnvironment = 
  | 'SIMULATION'
  | 'SIL' // Software-in-the-Loop
  | 'HIL' // Hardware-in-the-Loop
  | 'DEVELOPMENT'
  | 'TEST'
  | 'CERTIFICATION_RESEARCH'
  | 'FLIGHT_DISABLED'; // Reserved placeholder per safety invariants

export type FlightMode = 
  | 'GROUND'
  | 'PRE_FLIGHT'
  | 'ARMED_SIMULATION'
  | 'TAKEOFF'
  | 'HOVER'
  | 'TRANSITION_TO_CRUISE'
  | 'CRUISE'
  | 'TRANSITION_TO_HOVER'
  | 'APPROACH'
  | 'LANDING'
  | 'LANDED'
  | 'EMERGENCY'
  | 'ABORT';

export type SubsystemHealth = 'NORMAL' | 'DEGRADED' | 'WARNING' | 'FAILED' | 'UNKNOWN';

export type AirframeArchitecture = 
  | 'DISTRIBUTED_ELECTRIC' // DCS-VTOL-01 default (8 lift + 4 cruise)
  | 'LIFT_AND_CRUISE'
  | 'TILT_ROTOR'
  | 'TILT_WING'
  | 'MULTICOPTER'
  | 'COMPOUND';

export interface ProvenanceMetric<T> {
  value: T;
  unit: string;
  timestampMs: number;
  source: 'SENSOR_RAW' | 'EKF_ESTIMATE' | 'MODEL_PREDICTED' | 'COMMANDED' | 'CALIBRATED';
  confidence: number; // 0.0 - 1.0
  validity: boolean;
}

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface Quaternion {
  w: number;
  x: number;
  y: number;
  z: number;
}

export interface EulerAngles {
  rollDeg: number;  // phi
  pitchDeg: number; // theta
  yawDeg: number;   // psi
}

export interface MotorTelemetry {
  id: number;
  name: string;
  type: 'LIFT' | 'CRUISE';
  position: [number, number, number]; // [x, y, z] relative to CG in meters
  rotationDirection: 1 | -1; // 1 = CW, -1 = CCW
  rpm: number;
  thrustN: number;
  torqueNm: number;
  currentA: number;
  voltageV: number;
  tempC: number;
  efficiencyPct: number;
  health: SubsystemHealth;
  commandedRatio: number; // 0.0 - 1.0
  isFailed: boolean;
}

export interface BatteryState {
  socPct: number; // State of Charge (0-100%)
  sohPct: number; // State of Health (0-100%)
  packVoltageV: number;
  packCurrentA: number;
  powerKw: number;
  packTempC: number;
  maxCellTempC: number;
  minCellTempC: number;
  internalResistanceMOhm: number;
  energyRemainingKwh: number;
  totalCapacityKwh: number;
  cellImbalanceMv: number;
  thermalProtectionActive: boolean;
}

export interface SensorSnapshot {
  timestampMs: number;
  imu: {
    accelMps2: Vector3D;
    gyroDps: Vector3D;
    magGauss: Vector3D;
    redundancyA: boolean;
    redundancyB: boolean;
    redundancyC: boolean;
    activePrimary: 'IMU_A' | 'IMU_B' | 'IMU_C';
  };
  gnss: {
    lat: number;
    lon: number;
    altitudeMslM: number;
    hdop: number;
    satellitesVisible: number;
    fixQuality: 'RTK_FIXED' | 'RTK_FLOAT' | '3D_FIX' | 'DEGRADED' | 'NO_FIX';
  };
  baro: {
    pressurePa: number;
    altitudeBaroM: number;
    valid: boolean;
  };
  pitot: {
    indicatedAirspeedMps: number;
    trueAirspeedMps: number;
    angleOfAttackDeg: number;
    valid: boolean;
  };
  radarAltimeterM: number;
}

export interface StateEstimation {
  positionNmd: Vector3D; // North, East, Down (m)
  velocityNedMps: Vector3D;
  attitudeQuat: Quaternion;
  attitudeEuler: EulerAngles;
  angularRateDps: Vector3D;
  linearAccelerationNedMps2: Vector3D;
  windVectorMps: Vector3D;
  sensorBiases: {
    accelBiasMps2: Vector3D;
    gyroBiasDps: Vector3D;
  };
  covarianceDiagonal: number[];
  filterStatus: 'CONVERGED' | 'CONVERGING' | 'HIGH_COVARIANCE' | 'DIVERGED';
}

export interface VehicleState {
  aircraftId: string;
  architecture: AirframeArchitecture;
  environment: ExecutionEnvironment;
  flightMode: FlightMode;
  simulationTimeSec: number;
  realTimeRatio: number;
  cycleId: number;

  altitudeM: number;
  altitudeFt: number;
  airspeedMps: number;
  airspeedKnots: number;
  groundSpeedKnots: number;
  verticalSpeedMps: number;
  verticalSpeedFpm: number;

  transitionProgressPct: number; // 0% = full hover, 100% = full cruise
  liftThrustTotalN: number;
  cruiseThrustTotalN: number;
  aerodynamicLiftN: number;
  totalDragN: number;

  battery: BatteryState;
  motors: MotorTelemetry[];
  sensors: SensorSnapshot;
  estimation: StateEstimation;

  health: {
    overallStatus: SubsystemHealth;
    overallScorePct: number;
    flightComputerStatus: SubsystemHealth;
    propulsionStatus: SubsystemHealth;
    energyStatus: SubsystemHealth;
    sensorsStatus: SubsystemHealth;
    navigationStatus: SubsystemHealth;
    activeFaults: AircraftFault[];
  };

  mission: {
    missionId: string;
    currentWaypointIndex: number;
    totalWaypoints: number;
    distanceRemainingKm: number;
    etaMinutes: number;
    origin: string;
    destination: string;
    divertAlternative: string;
    progressPct: number;
  };

  diagnostics: {
    loopFrequencyHz: number;
    jitterUs: number;
    p50LatencyMs: number;
    p95LatencyMs: number;
    p99LatencyMs: number;
    deadlineMissCount: number;
    cpuLoadPct: number;
    memoryMb: number;
  };
}

export interface AircraftFault {
  id: string;
  code: string;
  source: string;
  severity: 'WARNING' | 'CRITICAL' | 'FATAL';
  description: string;
  timestampSec: number;
  acknowledged: boolean;
  mitigationAction: string;
}

export interface RequirementNode {
  id: string; // e.g. "VTOL-FC-REQ-001"
  category: 'SYSTEM' | 'SAFETY' | 'FUNCTIONAL' | 'SOFTWARE' | 'CONTROL';
  title: string;
  description: string;
  standardRef: string; // e.g. "DO-178C DAL-A / EASA SC-VTOL.2510"
  verificationMethod: 'TEST_HIL' | 'TEST_SIL' | 'ANALYSIS' | 'DEMO' | 'FORMAL_PROOF';
  status: 'VERIFIED' | 'IN_DEVELOPMENT' | 'OPEN';
  testEvidenceId?: string;
  passRatioPct: number;
}

export interface FleetAircraft {
  id: string;
  serialNumber: string;
  flightCount: number;
  flightHours: number;
  batterySohPct: number;
  motorEfficiencyPct: number;
  vibrationRmsG: number;
  modelResidualNorm: number;
  status: 'AIRWORTHY' | 'SCHEDULED_MAINTENANCE' | 'DIAGNOSTIC_HOLD';
  lastFlightId: string;
}
