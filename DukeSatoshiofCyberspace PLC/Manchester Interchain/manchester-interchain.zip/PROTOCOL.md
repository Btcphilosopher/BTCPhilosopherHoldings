# MANCHESTER INTERCHAIN PROTOCOL (MIP-01)

## Canonical Message Schema

All interchain cross-network operations are normalized into canonical `InterchainMessage` structures:

```typescript
interface InterchainMessage {
  message_id: string;              // e.g. "MSG-MCR-8F72A1"
  source_chain: string;            // Origin network identity
  source_tx: string;               // Transaction hash on origin chain
  destination_chain: string;       // Target network identity
  destination_contract: string;    // Target smart contract or account
  sender: string;                  // Origin sender public key / address
  recipient: string;               // Final recipient address
  nonce: number;                   // Strict monotonic increment per origin
  payload_hash: string;            // Keccak256 / SHA256 of calldata
  message_type: MessageClass;      // 14 classes (TRANSFER, CALL, STATE_UPDATE, etc.)
  timestamp: string;               // ISO-8601 creation timestamp
  gas_limit: number;               // Maximum gas allocation on destination
  security_level: string;          // STANDARD | HIGH | CRITICAL_INSTITUTIONAL
  proof_type: ProofType;           // Cryptographic proof model
  validator_threshold: number;     // e.g. 0.67 or 0.80 quorum power
  status: MessageStatus;           // 11 distinct lifecycle stages
}
```

## Lifecycle State Transitions
1. `CREATED`: Emitted by origin smart contract / bridge adapter event log.
2. `SIGNED`: Encrypted payload signed with origin identity key.
3. `ATTESTED`: Synthetic validator quorum gathers $\ge 2/3$ BLS multi-signatures.
4. `PROVEN`: Merkle-Patricia or SPV state root verified against origin block header.
5. `ROUTED`: Dispatched via Manchester Interchain Fabric rail.
6. `DELIVERED`: Delivered into destination chain sequencer / mempool.
7. `EXECUTED`: Smart contract calldata executed on destination runtime.
8. `FINAL`: Two-way cryptographic settlement receipt archived in immutable audit log.
