export type ConsensusType = 
  | 'Proof-of-Stake (PoS)' 
  | 'Proof-of-Work (PoW)' 
  | 'Proof-of-History (PoH)' 
  | 'Tendermint / CometBFT' 
  | 'Snowman Consensus' 
  | 'GRANDPA / BABE' 
  | 'Optimistic Rollup / Nitrous' 
  | 'Optimism OP Stack' 
  | 'Heimdall & Bor' 
  | 'Proof-of-Hive (MI Fabric)';

export type FinalityModel = 
  | 'Single-Slot Finality (12.8s)' 
  | 'Probabilistic (6 Blocks / 60m)' 
  | 'Sub-Second Optimistic (400ms)' 
  | 'Instant BFT (2/3 Quorum / 6s)' 
  | 'Snowman Fast Avalanche (2s)' 
  | 'GRANDPA Deterministic (24s)' 
  | 'Fraud Proof Window (7d / Soft 250ms)' 
  | 'L1 State Commitment (20m)' 
  | 'Heimdall Checkpoint (30m)' 
  | 'Manchester Atomic Quorum (500ms)';

export type NetworkStatus = 'ONLINE' | 'DEGRADED' | 'CONGESTED' | 'OFFLINE';

export interface BlockchainNetwork {
  network_id: string;
  name: string;
  chain_id: number | string;
  category: 'L1 Sovereign' | 'L2 Rollup' | 'AppChain' | 'Manchester Fabric';
  consensus_type: ConsensusType;
  native_asset: string;
  finality_model: FinalityModel;
  block_time_seconds: number;
  current_block: number;
  rpc_endpoint: string;
  explorer_endpoint: string;
  supported_message_protocols: string[];
  supported_assets: string[];
  validator_count: number;
  status: NetworkStatus;
  health_score: number; // 0 to 100
  latency_ms: number;
  tps: number;
  gas_price_gwei: number;
  interchain_channels: number;
  color_hex: string;
  icon_symbol: string;
  description: string;
  state_root: string;
}

export type MessageClass = 
  | 'TRANSFER'
  | 'CALL'
  | 'STATE_UPDATE'
  | 'ATTESTATION'
  | 'ORACLE_UPDATE'
  | 'IDENTITY'
  | 'CONTRACT_CALL'
  | 'GOVERNANCE'
  | 'DATA'
  | 'NFT_TRANSFER'
  | 'TOKEN_MINT'
  | 'TOKEN_BURN'
  | 'SETTLEMENT';

export type MessageStatus = 
  | 'CREATED'
  | 'SIGNED'
  | 'ATTESTED'
  | 'PROVEN'
  | 'ROUTED'
  | 'DELIVERED'
  | 'EXECUTED'
  | 'FINAL'
  | 'FAILED'
  | 'REJECTED'
  | 'EXPIRED';

export type ProofType = 
  | 'Merkle-Patricia Proof'
  | 'SPV Merkle Branch'
  | 'Tower BFT State Proof'
  | 'Tendermint Light Client'
  | 'BEEFY MMR Proof'
  | 'Optimistic State Assertion'
  | 'BLS Aggregated Signature'
  | 'Manchester Multi-Sig Quorum';

export interface MessageLifecycleEvent {
  stage: MessageStatus;
  timestamp: string;
  location: string;
  detail: string;
  tx_hash?: string;
  duration_ms: number;
}

export interface InterchainMessage {
  message_id: string;
  source_chain: string;
  source_tx: string;
  destination_chain: string;
  destination_contract: string;
  sender: string;
  recipient: string;
  nonce: number;
  payload_hash: string;
  message_type: MessageClass;
  payload_data: Record<string, unknown>;
  timestamp: string;
  gas_limit: number;
  gas_used?: number;
  security_level: 'STANDARD' | 'HIGH' | 'CRITICAL_INSTITUTIONAL';
  proof_type: ProofType;
  validator_threshold: number; // e.g. 0.67 or 0.80
  current_attestation_power: number;
  status: MessageStatus;
  route_path: string[];
  latency_total_ms: number;
  lifecycle: MessageLifecycleEvent[];
  error_reason?: string;
  merkle_root?: string;
  simulation_id?: string;
}

export interface ValidatorNode {
  validator_id: string;
  name: string;
  operator: string;
  region: string;
  city: string;
  stake_mi: number;
  stake_share_pct: number;
  reputation: number; // 0-100
  uptime_pct: number;
  latency_ms: number;
  chain_connections: string[];
  attestation_count: number;
  failed_attestations: number;
  slash_events: number;
  risk_score: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  is_byzantine: boolean;
  status: 'ACTIVE' | 'DEGRADED' | 'JAILED' | 'OFFLINE';
  last_attestation_time: string;
  public_key: string;
}

export interface StateProof {
  proof_id: string;
  message_id: string;
  source_chain: string;
  block_height: number;
  state_root: string;
  merkle_path: string[];
  leaf_hash: string;
  proof_type: ProofType;
  quorum_signatures: {
    validator_id: string;
    validator_name: string;
    signature: string;
    timestamp: string;
  }[];
  attested_power_pct: number;
  required_power_pct: number;
  verified: boolean;
  created_at: string;
  verified_at?: string;
  rejection_reason?: string;
}

export interface InterchainRoute {
  route_id: string;
  source_chain: string;
  destination_chain: string;
  hops: string[];
  route_type: 'DIRECT_FABRIC' | 'L2_OPTIMIZED' | 'IBC_RELAY' | 'ATOMIC_SWAP';
  estimated_latency_ms: number;
  fee_estimate_usd: number;
  fee_native_token: string;
  liquidity_available_usd: number;
  security_score: number; // 0-100
  finality_time_s: number;
  reliability_score: number; // 0-100
  recommended: boolean;
  explanation: string;
  congestion_factor: number;
}

export interface Asset {
  asset_id: string;
  origin_chain: string;
  origin_contract: string;
  symbol: string;
  name: string;
  decimals: number;
  total_supply: number;
  wrapped_supply: number;
  canonical_asset: string;
  custody_model: 'LOCK_AND_MINT' | 'BURN_AND_RELEASE' | 'ATOMIC_SWAP' | 'FABRIC_COLLATERAL';
  bridge_model: 'Canonical Interchange Hub' | 'Synthetic Wrapped Token' | 'Liquidity Network';
  usd_price: number;
  volume_24h_usd: number;
  color_hex: string;
}

export interface LiquidityPool {
  pool_id: string;
  pair_name: string;
  primary_asset: string;
  secondary_asset: string;
  chain_a: string;
  chain_b: string;
  reserve_a: number;
  reserve_b: number;
  total_liquidity_usd: number;
  utilization_pct: number;
  fee_tier_bps: number;
  slippage_24h_avg: number;
  settlement_capacity_usd: number;
  status: 'HEALTHY' | 'REBALANCING' | 'CONGESTED' | 'INSUFFICIENT';
}

export interface CrossChainTransfer {
  transfer_id: string;
  source_chain: string;
  destination_chain: string;
  asset_symbol: string;
  amount: number;
  amount_usd: number;
  sender_address: string;
  recipient_address: string;
  message_id: string;
  status: 'INITIATED' | 'SOURCE_LOCKED' | 'PROOF_GENERATED' | 'INTERCHAIN_ROUTED' | 'DEST_MINTED' | 'COMPLETED' | 'FAILED';
  created_at: string;
  completed_at?: string;
  fee_paid_usd: number;
  execution_steps: {
    step_name: string;
    chain: string;
    status: 'PENDING' | 'IN_PROGRESS' | 'DONE' | 'FAILED';
    tx_hash?: string;
    timestamp: string;
  }[];
}

export interface SecurityThreat {
  threat_id: string;
  type: 
    | 'REPLAY_ATTACK'
    | 'INVALID_PROOF'
    | 'NONCE_COLLISION'
    | 'WRONG_CHAIN_ID'
    | 'VALIDATOR_COLLUSION'
    | 'STALE_STATE'
    | 'BRIDGE_DRAIN'
    | 'MALFORMED_PAYLOAD'
    | 'DESTINATION_REVERT';
  severity: 'INFO' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  source_chain: string;
  target_chain: string;
  description: string;
  blocked: boolean;
  detected_at: string;
  causal_remediation: string;
  affected_routes_count: number;
  raw_payload_snippet: string;
}

export interface SimulationIncident {
  incident_id: string;
  title: string;
  severity: 'WARNING' | 'CRITICAL' | 'RESOLVED';
  cause: string;
  affected_routes: string[];
  affected_assets: string[];
  queued_messages_count: number;
  automatic_response: string;
  status: 'ACTIVE' | 'CONTAINED' | 'RESOLVED';
  timestamp: string;
}

export type ProvenanceTag = 'OBSERVED' | 'SYNTHETIC' | 'SIMULATED' | 'MODELLED' | 'SCENARIO' | 'USER_DEFINED';

export interface AuditRecord {
  audit_id: string;
  timestamp: string;
  user_role: string;
  user_identity: string;
  action: string;
  target_type: 'NETWORK' | 'MESSAGE' | 'ROUTE' | 'VALIDATOR' | 'SECURITY' | 'TRANSFER' | 'CONFIG';
  target_id: string;
  before_state: string;
  after_state: string;
  integrity_hash: string;
  provenance: ProvenanceTag;
}

export type UserRole = 
  | 'SYSTEM_ADMIN'
  | 'NETWORK_OPERATOR'
  | 'VALIDATOR_OPERATOR'
  | 'SECURITY_ANALYST'
  | 'LIQUIDITY_MANAGER'
  | 'RESEARCHER'
  | 'AUDITOR'
  | 'READ_ONLY';

export interface InterchainTopologyNode {
  id: string;
  name: string;
  category: string;
  x: number;
  y: number;
  status: NetworkStatus;
  latency_ms: number;
  tps: number;
  native_asset: string;
  color: string;
  is_hub: boolean;
  active_messages_count: number;
  health_score: number;
}

export interface InterchainTopologyEdge {
  id: string;
  source: string;
  target: string;
  channel_id: string;
  status: 'ACTIVE' | 'DEGRADED' | 'SEVERED' | 'CONGESTED';
  latency_ms: number;
  throughput_msg_per_sec: number;
  active_transits: {
    message_id: string;
    progress: number; // 0 to 1
    type: MessageClass;
    color: string;
  }[];
}
