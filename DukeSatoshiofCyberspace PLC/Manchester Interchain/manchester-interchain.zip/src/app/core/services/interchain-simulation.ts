import { Injectable, signal, computed } from '@angular/core';
import { 
  BlockchainNetwork, 
  InterchainMessage, 
  ValidatorNode, 
  StateProof, 
  InterchainRoute, 
  Asset, 
  LiquidityPool, 
  CrossChainTransfer, 
  SecurityThreat, 
  SimulationIncident, 
  AuditRecord, 
  UserRole, 
  MessageClass, 
  MessageStatus
} from '../models/interchain.types';

// Deterministic Pseudo-Random Generator with fixed seed
class SeededRandom {
  private m_w: number;
  private m_z: number;

  constructor(seed = 42161) {
    this.m_w = (123456789 + seed) & 0xffffffff;
    this.m_z = (987654321 - seed) & 0xffffffff;
  }

  public next(): number {
    this.m_z = (36969 * (this.m_z & 65535) + (this.m_z >> 16)) & 0xffffffff;
    this.m_w = (18000 * (this.m_w & 65535) + (this.m_w >> 16)) & 0xffffffff;
    const result = ((this.m_z << 16) + (this.m_w & 65535)) >>> 0;
    return result / 4294967296;
  }

  public range(min: number, max: number): number {
    return min + this.next() * (max - min);
  }

  public choice<T>(arr: T[]): T {
    return arr[Math.floor(this.next() * arr.length)];
  }

  public hex(bytes = 16): string {
    let s = '';
    for (let i = 0; i < bytes; i++) {
      s += Math.floor(this.next() * 256).toString(16).padStart(2, '0');
    }
    return s;
  }
}

@Injectable({
  providedIn: 'root'
})
export class InterchainSimulation {
  private rng = new SeededRandom(1838);

  // Core Simulation State Signals
  public readonly isSimulationRunning = signal<boolean>(true);
  public readonly simulationSpeed = signal<number>(1);
  public readonly currentSeed = signal<number>(1838);
  public readonly activeScenario = signal<string>('NORMAL_OPERATIONS');
  public readonly currentUserRole = signal<UserRole>('NETWORK_OPERATOR');
  public readonly totalMessagesProcessed = signal<number>(19842);
  public readonly totalVolumeUSD = signal<number>(184592000);
  public readonly activeIncidentsCount = signal<number>(0);
  public readonly selectedNetworkId = signal<string>('eth');
  public readonly selectedMessageId = signal<string | null>(null);

  // Chains Registry
  public readonly networks = signal<BlockchainNetwork[]>([
    {
      network_id: 'manchester',
      name: 'Manchester Central Fabric',
      chain_id: 'MANC-01',
      category: 'Manchester Fabric',
      consensus_type: 'Proof-of-Hive (MI Fabric)',
      native_asset: 'MANC',
      finality_model: 'Manchester Atomic Quorum (500ms)',
      block_time_seconds: 1.0,
      current_block: 842109,
      rpc_endpoint: 'https://rpc.fabric.manchester-interchain.io/v1',
      explorer_endpoint: 'https://interchange.manchester.io/explorer',
      supported_message_protocols: ['MIP-01 Canonical', 'IBC-v8', 'GMP-Core', 'CCIP-Direct', 'X-Call'],
      supported_assets: ['MANC', 'ETH', 'BTC', 'USDC', 'SOL', 'ATOM', 'ARB', 'OP'],
      validator_count: 18,
      status: 'ONLINE',
      health_score: 99.98,
      latency_ms: 12,
      tps: 4250,
      gas_price_gwei: 0.1,
      interchain_channels: 10,
      color_hex: '#F9C900',
      icon_symbol: 'hub',
      description: 'The core sovereign interoperability fabric coordinating cross-chain message dispatch, proof verification, and atomic settlement.',
      state_root: '0x8f7a931e2b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e'
    },
    {
      network_id: 'eth',
      name: 'Ethereum Mainnet',
      chain_id: 1,
      category: 'L1 Sovereign',
      consensus_type: 'Proof-of-Stake (PoS)',
      native_asset: 'ETH',
      finality_model: 'Single-Slot Finality (12.8s)',
      block_time_seconds: 12.0,
      current_block: 21948502,
      rpc_endpoint: 'https://eth-mainnet.alchemyapi.io/v2/simulated',
      explorer_endpoint: 'https://etherscan.io',
      supported_message_protocols: ['MIP-01 Canonical', 'EIP-5164', 'CCIP'],
      supported_assets: ['ETH', 'USDC', 'USDT', 'WBTC'],
      validator_count: 984500,
      status: 'ONLINE',
      health_score: 99.95,
      latency_ms: 68,
      tps: 18.4,
      gas_price_gwei: 21.5,
      interchain_channels: 8,
      color_hex: '#627EEA',
      icon_symbol: 'token',
      description: 'The primary EVM settlement layer. Interchain bridge verifies Merkle-Patricia execution state roots.',
      state_root: '0x3a9f1c7d2e4b6a8f0b1c3d5e7f9a1b3c5d7e9f1a3b5c7d9e1f3a5b7c9d1e3f5a'
    },
    {
      network_id: 'btc',
      name: 'Bitcoin Core',
      chain_id: 'BTC-MAIN',
      category: 'L1 Sovereign',
      consensus_type: 'Proof-of-Work (PoW)',
      native_asset: 'BTC',
      finality_model: 'Probabilistic (6 Blocks / 60m)',
      block_time_seconds: 600.0,
      current_block: 887410,
      rpc_endpoint: 'https://btc-rpc.manchester-interchain.io',
      explorer_endpoint: 'https://mempool.space',
      supported_message_protocols: ['SPV Light Client', 'BitVM State Verifier', 'Taproot Prover'],
      supported_assets: ['BTC', 'sBTC'],
      validator_count: 14200,
      status: 'ONLINE',
      health_score: 99.99,
      latency_ms: 180,
      tps: 7.2,
      gas_price_gwei: 45.0,
      interchain_channels: 4,
      color_hex: '#F7931A',
      icon_symbol: 'currency_bitcoin',
      description: 'UTXO architecture with SPV Merkle inclusion verification and zero-knowledge BitVM state bridges.',
      state_root: '0x00000000000000000002f1a9b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2'
    },
    {
      network_id: 'sol',
      name: 'Solana Mainnet-Beta',
      chain_id: 'SOL-101',
      category: 'L1 Sovereign',
      consensus_type: 'Proof-of-History (PoH)',
      native_asset: 'SOL',
      finality_model: 'Sub-Second Optimistic (400ms)',
      block_time_seconds: 0.4,
      current_block: 312894100,
      rpc_endpoint: 'https://api.mainnet-beta.solana.com',
      explorer_endpoint: 'https://solscan.io',
      supported_message_protocols: ['MIP-01 Canonical', 'Wormhole Core', 'SeaLevel Engine'],
      supported_assets: ['SOL', 'USDC', 'JupUSD'],
      validator_count: 1740,
      status: 'ONLINE',
      health_score: 99.42,
      latency_ms: 34,
      tps: 2840,
      gas_price_gwei: 0.005,
      interchain_channels: 6,
      color_hex: '#14F195',
      icon_symbol: 'bolt',
      description: 'High-throughput parallelized SeaLevel runtime verified via Tower BFT quorum attestations.',
      state_root: '0x9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b'
    },
    {
      network_id: 'cosmos',
      name: 'Cosmos Hub',
      chain_id: 'cosmoshub-4',
      category: 'L1 Sovereign',
      consensus_type: 'Tendermint / CometBFT',
      native_asset: 'ATOM',
      finality_model: 'Instant BFT (2/3 Quorum / 6s)',
      block_time_seconds: 6.0,
      current_block: 22481093,
      rpc_endpoint: 'https://rpc.cosmos.network',
      explorer_endpoint: 'https://mintscan.io/cosmos',
      supported_message_protocols: ['IBC-v8', 'MIP-01 Canonical', 'ICS-20'],
      supported_assets: ['ATOM', 'USDC', 'OSMO'],
      validator_count: 180,
      status: 'ONLINE',
      health_score: 99.91,
      latency_ms: 45,
      tps: 110,
      gas_price_gwei: 0.02,
      interchain_channels: 9,
      color_hex: '#2E3148',
      icon_symbol: 'grain',
      description: 'Inter-Blockchain Communication (IBC) native hub with verified light client header tracking.',
      state_root: '0x1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c'
    },
    {
      network_id: 'avax',
      name: 'Avalanche C-Chain',
      chain_id: 43114,
      category: 'L1 Sovereign',
      consensus_type: 'Snowman Consensus',
      native_asset: 'AVAX',
      finality_model: 'Snowman Fast Avalanche (2s)',
      block_time_seconds: 2.0,
      current_block: 54109823,
      rpc_endpoint: 'https://api.avax.network/ext/bc/C/rpc',
      explorer_endpoint: 'https://snowtrace.io',
      supported_message_protocols: ['Teleporter / AWM', 'MIP-01 Canonical'],
      supported_assets: ['AVAX', 'USDC', 'BTC.b'],
      validator_count: 1250,
      status: 'ONLINE',
      health_score: 99.88,
      latency_ms: 40,
      tps: 64,
      gas_price_gwei: 28.0,
      interchain_channels: 5,
      color_hex: '#E84142',
      icon_symbol: 'landscape',
      description: 'Sub-second DAG-based Snowman consensus with cross-subnet Avalanche Warp Messaging (AWM).',
      state_root: '0x7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a'
    },
    {
      network_id: 'dot',
      name: 'Polkadot Relay Chain',
      chain_id: 'polkadot-relay',
      category: 'L1 Sovereign',
      consensus_type: 'GRANDPA / BABE',
      native_asset: 'DOT',
      finality_model: 'GRANDPA Deterministic (24s)',
      block_time_seconds: 6.0,
      current_block: 22894103,
      rpc_endpoint: 'https://rpc.polkadot.io',
      explorer_endpoint: 'https://polkascan.io',
      supported_message_protocols: ['XCM-v3', 'BEEFY Bridge', 'MIP-01 Canonical'],
      supported_assets: ['DOT', 'USDC', 'GLMR'],
      validator_count: 297,
      status: 'ONLINE',
      health_score: 99.89,
      latency_ms: 55,
      tps: 320,
      gas_price_gwei: 0.01,
      interchain_channels: 6,
      color_hex: '#E6007A',
      icon_symbol: 'adjust',
      description: 'Shared security heterogenous multi-chain framework with Merkle Mountain Range (MMR) state proofs.',
      state_root: '0x4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e'
    },
    {
      network_id: 'arb',
      name: 'Arbitrum One',
      chain_id: 42161,
      category: 'L2 Rollup',
      consensus_type: 'Optimistic Rollup / Nitrous',
      native_asset: 'ETH',
      finality_model: 'Fraud Proof Window (7d / Soft 250ms)',
      block_time_seconds: 0.25,
      current_block: 294810231,
      rpc_endpoint: 'https://arb1.arbitrum.io/rpc',
      explorer_endpoint: 'https://arbiscan.io',
      supported_message_protocols: ['MIP-01 Canonical', 'Inbox/Outbox Retryable Tickets', 'LayerZero'],
      supported_assets: ['ARB', 'ETH', 'USDC', 'USDT'],
      validator_count: 24,
      status: 'ONLINE',
      health_score: 99.97,
      latency_ms: 18,
      tps: 142.5,
      gas_price_gwei: 0.1,
      interchain_channels: 8,
      color_hex: '#28A0F0',
      icon_symbol: 'layers',
      description: 'Nitro-powered optimistic rollup posting data to Ethereum L1 with state assertions.',
      state_root: '0x2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b'
    },
    {
      network_id: 'op',
      name: 'Optimism Mainnet',
      chain_id: 10,
      category: 'L2 Rollup',
      consensus_type: 'Optimism OP Stack',
      native_asset: 'ETH',
      finality_model: 'L1 State Commitment (20m)',
      block_time_seconds: 2.0,
      current_block: 129481023,
      rpc_endpoint: 'https://mainnet.optimism.io',
      explorer_endpoint: 'https://optimistic.etherscan.io',
      supported_message_protocols: ['OP Superchain Bridge', 'MIP-01 Canonical'],
      supported_assets: ['OP', 'ETH', 'USDC'],
      validator_count: 16,
      status: 'ONLINE',
      health_score: 99.94,
      latency_ms: 22,
      tps: 88.0,
      gas_price_gwei: 0.12,
      interchain_channels: 7,
      color_hex: '#FF0420',
      icon_symbol: 'speed',
      description: 'Superchain collective standard with cross-L2 message passing and unified sequencing.',
      state_root: '0x9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a'
    },
    {
      network_id: 'base',
      name: 'Base L2',
      chain_id: 8453,
      category: 'L2 Rollup',
      consensus_type: 'Optimism OP Stack',
      native_asset: 'ETH',
      finality_model: 'L1 State Commitment (20m)',
      block_time_seconds: 2.0,
      current_block: 24819034,
      rpc_endpoint: 'https://mainnet.base.org',
      explorer_endpoint: 'https://basescan.org',
      supported_message_protocols: ['OP Superchain Bridge', 'MIP-01 Canonical'],
      supported_assets: ['ETH', 'USDC', 'cbBTC'],
      validator_count: 14,
      status: 'ONLINE',
      health_score: 99.96,
      latency_ms: 20,
      tps: 112.4,
      gas_price_gwei: 0.08,
      interchain_channels: 7,
      color_hex: '#0052FF',
      icon_symbol: 'widgets',
      description: 'Institutional Coinbase L2 on OP Stack directly linked into the Manchester Interchain Hub.',
      state_root: '0x5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d'
    },
    {
      network_id: 'polygon',
      name: 'Polygon PoS',
      chain_id: 137,
      category: 'L1 Sovereign',
      consensus_type: 'Heimdall & Bor',
      native_asset: 'POL',
      finality_model: 'Heimdall Checkpoint (30m)',
      block_time_seconds: 2.1,
      current_block: 64910394,
      rpc_endpoint: 'https://polygon-rpc.com',
      explorer_endpoint: 'https://polygonscan.com',
      supported_message_protocols: ['FxPortal', 'StateSync', 'MIP-01 Canonical'],
      supported_assets: ['POL', 'USDC', 'WETH'],
      validator_count: 105,
      status: 'ONLINE',
      health_score: 99.82,
      latency_ms: 38,
      tps: 76.5,
      gas_price_gwei: 42.0,
      interchain_channels: 6,
      color_hex: '#8247E5',
      icon_symbol: 'grid_view',
      description: 'Hybrid Proof-of-Stake with periodic Heimdall checkpointing to Ethereum root contract.',
      state_root: '0x8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b'
    }
  ]);

  // Validator Hive (18 Geographic & Logical Nodes)
  public readonly validators = signal<ValidatorNode[]>([
    {
      validator_id: 'val-mcr-01',
      name: 'Manchester Node Alpha (Hive Hub)',
      operator: 'Manchester Interchain Foundation',
      region: 'North West England',
      city: 'Manchester (Cottonopolis)',
      stake_mi: 15400000,
      stake_share_pct: 12.8,
      reputation: 99.9,
      uptime_pct: 99.99,
      latency_ms: 8,
      chain_connections: ['manchester', 'eth', 'btc', 'sol', 'cosmos', 'arb'],
      attestation_count: 894120,
      failed_attestations: 2,
      slash_events: 0,
      risk_score: 'LOW',
      is_byzantine: false,
      status: 'ACTIVE',
      last_attestation_time: '1s ago',
      public_key: '0x04f8a9b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0'
    },
    {
      validator_id: 'val-salford-02',
      name: 'Salford Quays Validator',
      operator: 'MediaCity Infrastructure Ltd',
      region: 'North West England',
      city: 'Salford Quays',
      stake_mi: 12800000,
      stake_share_pct: 10.6,
      reputation: 99.8,
      uptime_pct: 99.98,
      latency_ms: 10,
      chain_connections: ['manchester', 'eth', 'arb', 'op', 'base'],
      attestation_count: 765410,
      failed_attestations: 5,
      slash_events: 0,
      risk_score: 'LOW',
      is_byzantine: false,
      status: 'ACTIVE',
      last_attestation_time: '1s ago',
      public_key: '0x04b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2'
    },
    {
      validator_id: 'val-castlefield-03',
      name: 'Castlefield Industrial Relay',
      operator: 'Castlefield Systems Group',
      region: 'North West England',
      city: 'Manchester',
      stake_mi: 9600000,
      stake_share_pct: 8.0,
      reputation: 99.6,
      uptime_pct: 99.95,
      latency_ms: 9,
      chain_connections: ['manchester', 'btc', 'cosmos', 'dot', 'sol'],
      attestation_count: 654210,
      failed_attestations: 12,
      slash_events: 0,
      risk_score: 'LOW',
      is_byzantine: false,
      status: 'ACTIVE',
      last_attestation_time: '2s ago',
      public_key: '0x04c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3'
    },
    {
      validator_id: 'val-spinningfields-04',
      name: 'Spinningfields Capital Validator',
      operator: 'Northern Institutional Node Co.',
      region: 'North West England',
      city: 'Manchester',
      stake_mi: 11200000,
      stake_share_pct: 9.3,
      reputation: 99.7,
      uptime_pct: 99.97,
      latency_ms: 11,
      chain_connections: ['manchester', 'eth', 'sol', 'avax', 'polygon'],
      attestation_count: 712900,
      failed_attestations: 8,
      slash_events: 0,
      risk_score: 'LOW',
      is_byzantine: false,
      status: 'ACTIVE',
      last_attestation_time: '1s ago',
      public_key: '0x04d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4'
    },
    {
      validator_id: 'val-ancoats-05',
      name: 'Ancoats Mills Staking Engine',
      operator: 'Ancoats Urban Node Lab',
      region: 'North West England',
      city: 'Manchester',
      stake_mi: 8400000,
      stake_share_pct: 7.0,
      reputation: 99.4,
      uptime_pct: 99.91,
      latency_ms: 12,
      chain_connections: ['manchester', 'arb', 'op', 'base', 'polygon'],
      attestation_count: 541090,
      failed_attestations: 19,
      slash_events: 0,
      risk_score: 'LOW',
      is_byzantine: false,
      status: 'ACTIVE',
      last_attestation_time: '2s ago',
      public_key: '0x04e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5'
    },
    {
      validator_id: 'val-oxford-rd-06',
      name: 'Oxford Road Corridor Prover',
      operator: 'Manchester Computing Centre',
      region: 'North West England',
      city: 'Manchester',
      stake_mi: 7900000,
      stake_share_pct: 6.6,
      reputation: 99.5,
      uptime_pct: 99.93,
      latency_ms: 10,
      chain_connections: ['manchester', 'eth', 'cosmos', 'dot'],
      attestation_count: 489200,
      failed_attestations: 14,
      slash_events: 0,
      risk_score: 'LOW',
      is_byzantine: false,
      status: 'ACTIVE',
      last_attestation_time: '2s ago',
      public_key: '0x04f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6'
    },
    {
      validator_id: 'val-leeds-07',
      name: 'Leeds AI & FinTech Nexus',
      operator: 'Yorkshire Cloud Infrastructure',
      region: 'Yorkshire',
      city: 'Leeds',
      stake_mi: 6500000,
      stake_share_pct: 5.4,
      reputation: 99.2,
      uptime_pct: 99.88,
      latency_ms: 16,
      chain_connections: ['manchester', 'eth', 'btc', 'avax'],
      attestation_count: 412090,
      failed_attestations: 22,
      slash_events: 0,
      risk_score: 'LOW',
      is_byzantine: false,
      status: 'ACTIVE',
      last_attestation_time: '3s ago',
      public_key: '0x04a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7'
    },
    {
      validator_id: 'val-edinburgh-08',
      name: 'Edinburgh St Andrew Relay',
      operator: 'Caledonian Distributed Tech',
      region: 'Scotland',
      city: 'Edinburgh',
      stake_mi: 5800000,
      stake_share_pct: 4.8,
      reputation: 99.1,
      uptime_pct: 99.85,
      latency_ms: 22,
      chain_connections: ['manchester', 'sol', 'cosmos', 'dot'],
      attestation_count: 365900,
      failed_attestations: 28,
      slash_events: 0,
      risk_score: 'LOW',
      is_byzantine: false,
      status: 'ACTIVE',
      last_attestation_time: '2s ago',
      public_key: '0x04b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8'
    },
    {
      validator_id: 'val-london-09',
      name: 'London Crossrail Data Vault',
      operator: 'City of London Telehouse',
      region: 'Greater London',
      city: 'London',
      stake_mi: 14200000,
      stake_share_pct: 11.8,
      reputation: 99.9,
      uptime_pct: 99.99,
      latency_ms: 15,
      chain_connections: ['manchester', 'eth', 'btc', 'sol', 'arb', 'op', 'base'],
      attestation_count: 845200,
      failed_attestations: 3,
      slash_events: 0,
      risk_score: 'LOW',
      is_byzantine: false,
      status: 'ACTIVE',
      last_attestation_time: '1s ago',
      public_key: '0x04c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9'
    },
    {
      validator_id: 'val-frankfurt-10',
      name: 'Frankfurt Equinix Node',
      operator: 'Deutsche Interchain Services',
      region: 'Central Europe',
      city: 'Frankfurt',
      stake_mi: 8900000,
      stake_share_pct: 7.4,
      reputation: 99.6,
      uptime_pct: 99.94,
      latency_ms: 28,
      chain_connections: ['manchester', 'eth', 'cosmos', 'avax', 'dot'],
      attestation_count: 512400,
      failed_attestations: 16,
      slash_events: 0,
      risk_score: 'LOW',
      is_byzantine: false,
      status: 'ACTIVE',
      last_attestation_time: '2s ago',
      public_key: '0x04d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0'
    },
    {
      validator_id: 'val-zurich-11',
      name: 'Zurich Crypto Valley Vault',
      operator: 'Alpine Cryptographic Node AG',
      region: 'Western Europe',
      city: 'Zurich',
      stake_mi: 7100000,
      stake_share_pct: 5.9,
      reputation: 99.7,
      uptime_pct: 99.96,
      latency_ms: 31,
      chain_connections: ['manchester', 'btc', 'eth', 'dot', 'arb'],
      attestation_count: 423900,
      failed_attestations: 9,
      slash_events: 0,
      risk_score: 'LOW',
      is_byzantine: false,
      status: 'ACTIVE',
      last_attestation_time: '2s ago',
      public_key: '0x04e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1'
    },
    {
      validator_id: 'val-ny-12',
      name: 'New York Wall Street Relay',
      operator: 'Manhattan Custody Node LLC',
      region: 'North America East',
      city: 'New York',
      stake_mi: 9200000,
      stake_share_pct: 7.6,
      reputation: 99.3,
      uptime_pct: 99.90,
      latency_ms: 74,
      chain_connections: ['manchester', 'eth', 'sol', 'base', 'op', 'arb'],
      attestation_count: 532100,
      failed_attestations: 25,
      slash_events: 0,
      risk_score: 'LOW',
      is_byzantine: false,
      status: 'ACTIVE',
      last_attestation_time: '3s ago',
      public_key: '0x04f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2'
    },
    {
      validator_id: 'val-tokyo-13',
      name: 'Tokyo Shinjuku Data Hub',
      operator: 'Nippon Interchain K.K.',
      region: 'East Asia',
      city: 'Tokyo',
      stake_mi: 4800000,
      stake_share_pct: 4.0,
      reputation: 98.9,
      uptime_pct: 99.78,
      latency_ms: 145,
      chain_connections: ['manchester', 'sol', 'cosmos', 'avax', 'polygon'],
      attestation_count: 298400,
      failed_attestations: 45,
      slash_events: 0,
      risk_score: 'MEDIUM',
      is_byzantine: false,
      status: 'ACTIVE',
      last_attestation_time: '4s ago',
      public_key: '0x04a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3'
    },
    {
      validator_id: 'val-singapore-14',
      name: 'Singapore Marina Bay Fabric',
      operator: 'ASEAN Interoperability Pte',
      region: 'Southeast Asia',
      city: 'Singapore',
      stake_mi: 4200000,
      stake_share_pct: 3.5,
      reputation: 99.0,
      uptime_pct: 99.82,
      latency_ms: 138,
      chain_connections: ['manchester', 'eth', 'sol', 'base', 'dot'],
      attestation_count: 271000,
      failed_attestations: 38,
      slash_events: 0,
      risk_score: 'LOW',
      is_byzantine: false,
      status: 'ACTIVE',
      last_attestation_time: '3s ago',
      public_key: '0x04b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4'
    }
  ]);

  // Assets Registry
  public readonly assets = signal<Asset[]>([
    {
      asset_id: 'manc',
      origin_chain: 'manchester',
      origin_contract: '0x0000000000000000000000000000000000000001',
      symbol: 'MANC',
      name: 'Manchester Interchain Token',
      decimals: 18,
      total_supply: 100000000,
      wrapped_supply: 24500000,
      canonical_asset: 'MANC (Native)',
      custody_model: 'FABRIC_COLLATERAL',
      bridge_model: 'Canonical Interchange Hub',
      usd_price: 48.50,
      volume_24h_usd: 34500000,
      color_hex: '#F9C900'
    },
    {
      asset_id: 'eth',
      origin_chain: 'eth',
      origin_contract: '0x0000000000000000000000000000000000000000',
      symbol: 'ETH',
      name: 'Ethereum Ether',
      decimals: 18,
      total_supply: 120400000,
      wrapped_supply: 384000,
      canonical_asset: 'ETH (L1)',
      custody_model: 'LOCK_AND_MINT',
      bridge_model: 'Synthetic Wrapped Token',
      usd_price: 3480.00,
      volume_24h_usd: 89400000,
      color_hex: '#627EEA'
    },
    {
      asset_id: 'btc',
      origin_chain: 'btc',
      origin_contract: 's-utxo-bitcoin-native',
      symbol: 'BTC',
      name: 'Bitcoin',
      decimals: 8,
      total_supply: 19800000,
      wrapped_supply: 42100,
      canonical_asset: 'BTC (Base)',
      custody_model: 'LOCK_AND_MINT',
      bridge_model: 'Canonical Interchange Hub',
      usd_price: 88500.00,
      volume_24h_usd: 124000000,
      color_hex: '#F7931A'
    },
    {
      asset_id: 'usdc',
      origin_chain: 'eth',
      origin_contract: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
      symbol: 'USDC',
      name: 'USD Coin (Cross-Chain Native)',
      decimals: 6,
      total_supply: 34000000000,
      wrapped_supply: 1250000000,
      canonical_asset: 'USDC (Circle CCTP Protocol)',
      custody_model: 'BURN_AND_RELEASE',
      bridge_model: 'Liquidity Network',
      usd_price: 1.00,
      volume_24h_usd: 215000000,
      color_hex: '#2775CA'
    },
    {
      asset_id: 'sol',
      origin_chain: 'sol',
      origin_contract: 'So11111111111111111111111111111111111111112',
      symbol: 'SOL',
      name: 'Solana Native',
      decimals: 9,
      total_supply: 460000000,
      wrapped_supply: 1850000,
      canonical_asset: 'SOL (SeaLevel)',
      custody_model: 'LOCK_AND_MINT',
      bridge_model: 'Synthetic Wrapped Token',
      usd_price: 192.40,
      volume_24h_usd: 48900000,
      color_hex: '#14F195'
    },
    {
      asset_id: 'atom',
      origin_chain: 'cosmos',
      origin_contract: 'uatom',
      symbol: 'ATOM',
      name: 'Cosmos Hub Token',
      decimals: 6,
      total_supply: 390000000,
      wrapped_supply: 5200000,
      canonical_asset: 'ATOM (IBC)',
      custody_model: 'LOCK_AND_MINT',
      bridge_model: 'Canonical Interchange Hub',
      usd_price: 8.85,
      volume_24h_usd: 14200000,
      color_hex: '#2E3148'
    }
  ]);

  // Liquidity Pools
  public readonly liquidityPools = signal<LiquidityPool[]>([
    {
      pool_id: 'pool-mcr-eth',
      pair_name: 'MANC / ETH (Interchange Pool)',
      primary_asset: 'MANC',
      secondary_asset: 'ETH',
      chain_a: 'manchester',
      chain_b: 'eth',
      reserve_a: 540000,
      reserve_b: 7520,
      total_liquidity_usd: 52400000,
      utilization_pct: 64.2,
      fee_tier_bps: 15,
      slippage_24h_avg: 0.08,
      settlement_capacity_usd: 18500000,
      status: 'HEALTHY'
    },
    {
      pool_id: 'pool-mcr-btc',
      pair_name: 'MANC / sBTC (Bridge Rail)',
      primary_asset: 'MANC',
      secondary_asset: 'BTC',
      chain_a: 'manchester',
      chain_b: 'btc',
      reserve_a: 820000,
      reserve_b: 450,
      total_liquidity_usd: 79500000,
      utilization_pct: 71.8,
      fee_tier_bps: 20,
      slippage_24h_avg: 0.12,
      settlement_capacity_usd: 24000000,
      status: 'HEALTHY'
    },
    {
      pool_id: 'pool-eth-usdc',
      pair_name: 'ETH / USDC CCTP Liquidity Rail',
      primary_asset: 'ETH',
      secondary_asset: 'USDC',
      chain_a: 'eth',
      chain_b: 'arb',
      reserve_a: 12500,
      reserve_b: 43500000,
      total_liquidity_usd: 87000000,
      utilization_pct: 58.4,
      fee_tier_bps: 5,
      slippage_24h_avg: 0.02,
      settlement_capacity_usd: 35000000,
      status: 'HEALTHY'
    },
    {
      pool_id: 'pool-mcr-sol',
      pair_name: 'MANC / SOL High-Throughput Rail',
      primary_asset: 'MANC',
      secondary_asset: 'SOL',
      chain_a: 'manchester',
      chain_b: 'sol',
      reserve_a: 420000,
      reserve_b: 105800,
      total_liquidity_usd: 40700000,
      utilization_pct: 79.5,
      fee_tier_bps: 12,
      slippage_24h_avg: 0.09,
      settlement_capacity_usd: 14200000,
      status: 'HEALTHY'
    }
  ]);

  // Messages Queue
  public readonly messages = signal<InterchainMessage[]>([
    {
      message_id: 'MSG-MCR-8F72A1',
      source_chain: 'eth',
      source_tx: '0x8f7a931e2b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e',
      destination_chain: 'cosmos',
      destination_contract: 'cosmos1xyz48190348759328472938472938472938472',
      sender: '0x71C...489A',
      recipient: 'cosmos1...84f9',
      nonce: 10482,
      payload_hash: '0x3a9f1c7d2e4b6a8f0b1c3d5e7f9a1b3c5d7e9f1a3b5c7d9e1f3a5b7c9d1e3f5a',
      message_type: 'TRANSFER',
      payload_data: { asset: 'USDC', amount: 50000, memo: 'Institutional Treasury Rebalance' },
      timestamp: new Date(Date.now() - 3200).toISOString(),
      gas_limit: 250000,
      gas_used: 182400,
      security_level: 'HIGH',
      proof_type: 'Merkle-Patricia Proof',
      validator_threshold: 0.67,
      current_attestation_power: 0.92,
      status: 'FINAL',
      route_path: ['eth', 'manchester', 'cosmos'],
      latency_total_ms: 1240,
      merkle_root: '0x8f7a931e2b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e',
      lifecycle: [
        { stage: 'CREATED', timestamp: new Date(Date.now() - 3200).toLocaleTimeString(), location: 'Ethereum L1', detail: 'Source transaction confirmed in block #21948501', duration_ms: 120 },
        { stage: 'SIGNED', timestamp: new Date(Date.now() - 3080).toLocaleTimeString(), location: 'Bridge Outbox', detail: 'Payload signed with origin nonce #10482', duration_ms: 45 },
        { stage: 'ATTESTED', timestamp: new Date(Date.now() - 3035).toLocaleTimeString(), location: 'Validator Quorum', detail: '13 of 14 validators provided BLS signature (92.4% stake)', duration_ms: 280 },
        { stage: 'PROVEN', timestamp: new Date(Date.now() - 2755).toLocaleTimeString(), location: 'State Proof Engine', detail: 'Merkle-Patricia root verification verified against L1 state root', duration_ms: 150 },
        { stage: 'ROUTED', timestamp: new Date(Date.now() - 2605).toLocaleTimeString(), location: 'Manchester Interchange', detail: 'Determined optimal direct path via Fabric Hub', duration_ms: 40 },
        { stage: 'DELIVERED', timestamp: new Date(Date.now() - 2565).toLocaleTimeString(), location: 'Cosmos IBC Connector', detail: 'Packet packet_sequence=842 committed to Cosmos Hub mempool', duration_ms: 180 },
        { stage: 'EXECUTED', timestamp: new Date(Date.now() - 2385).toLocaleTimeString(), location: 'Destination Chain', detail: 'ICS-20 mint completed on Cosmos Hub', duration_ms: 220 },
        { stage: 'FINAL', timestamp: new Date(Date.now() - 2165).toLocaleTimeString(), location: 'Interchain Registry', detail: 'Two-way cryptographic receipt archived and finality settled', duration_ms: 205 }
      ]
    },
    {
      message_id: 'MSG-MCR-9E44B2',
      source_chain: 'sol',
      source_tx: '5K2b9Z4W8q1L3m6N7p0r8s9t2v3w4x5y6z7a8b9c0d1e2f3a4b5c6d7e8f9a0b1',
      destination_chain: 'arb',
      destination_contract: '0x48942161b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8',
      sender: 'SolUser...89A',
      recipient: '0xArb...394',
      nonce: 4819,
      payload_hash: '0x9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b',
      message_type: 'CONTRACT_CALL',
      payload_data: { targetFunction: 'executeLiquidityRebalance(uint256,bytes)', poolId: 'arb-usdc-v3', params: '0x0024f9' },
      timestamp: new Date(Date.now() - 1400).toISOString(),
      gas_limit: 450000,
      gas_used: 312000,
      security_level: 'CRITICAL_INSTITUTIONAL',
      proof_type: 'Tower BFT State Proof',
      validator_threshold: 0.80,
      current_attestation_power: 0.88,
      status: 'DELIVERED',
      route_path: ['sol', 'manchester', 'arb'],
      latency_total_ms: 860,
      lifecycle: [
        { stage: 'CREATED', timestamp: new Date(Date.now() - 1400).toLocaleTimeString(), location: 'Solana Mainnet', detail: 'Tx finalized in slot #312894098', duration_ms: 90 },
        { stage: 'SIGNED', timestamp: new Date(Date.now() - 1310).toLocaleTimeString(), location: 'Solana Gateway', detail: 'SeaLevel emission signed', duration_ms: 30 },
        { stage: 'ATTESTED', timestamp: new Date(Date.now() - 1280).toLocaleTimeString(), location: 'Validator Quorum', detail: '11 validators attested (88.1% power)', duration_ms: 220 },
        { stage: 'PROVEN', timestamp: new Date(Date.now() - 1060).toLocaleTimeString(), location: 'State Proof Engine', detail: 'Tower BFT state certificate verified', duration_ms: 120 },
        { stage: 'ROUTED', timestamp: new Date(Date.now() - 940).toLocaleTimeString(), location: 'Manchester Interchange', detail: 'Routed to Arbitrum Nitro Sequencer', duration_ms: 30 },
        { stage: 'DELIVERED', timestamp: new Date(Date.now() - 910).toLocaleTimeString(), location: 'Arbitrum Inbox', detail: 'Contract call queued in Nitro outbox', duration_ms: 110 }
      ]
    },
    {
      message_id: 'MSG-MCR-7A11C3',
      source_chain: 'btc',
      source_tx: '00000000000000000002f1a9b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2',
      destination_chain: 'eth',
      destination_contract: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
      sender: 'bc1q9...84a',
      recipient: '0x71...wbtc',
      nonce: 928,
      payload_hash: '0x00000000000000000002f1a9b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2',
      message_type: 'TOKEN_MINT',
      payload_data: { asset: 'BTC', amount: 2.5, btcTx: 'tx-btc-9841' },
      timestamp: new Date(Date.now() - 800).toISOString(),
      gas_limit: 180000,
      security_level: 'CRITICAL_INSTITUTIONAL',
      proof_type: 'SPV Merkle Branch',
      validator_threshold: 0.80,
      current_attestation_power: 0.74,
      status: 'ATTESTED',
      route_path: ['btc', 'manchester', 'eth'],
      latency_total_ms: 640,
      lifecycle: [
        { stage: 'CREATED', timestamp: new Date(Date.now() - 800).toLocaleTimeString(), location: 'Bitcoin Block 887410', detail: 'UTXO locked in Manchester Multi-Sig vault', duration_ms: 180 },
        { stage: 'SIGNED', timestamp: new Date(Date.now() - 620).toLocaleTimeString(), location: 'BTC Adapter', detail: 'SPV header extracted', duration_ms: 60 },
        { stage: 'ATTESTED', timestamp: new Date(Date.now() - 560).toLocaleTimeString(), location: 'Validator Quorum', detail: 'Attestation gathering in progress (74.2% / 80.0% required)', duration_ms: 320 }
      ]
    }
  ]);

  // Proofs Registry
  public readonly proofs = signal<StateProof[]>([
    {
      proof_id: 'PRF-MCR-001948',
      message_id: 'MSG-MCR-8F72A1',
      source_chain: 'eth',
      block_height: 21948501,
      state_root: '0x3a9f1c7d2e4b6a8f0b1c3d5e7f9a1b3c5d7e9f1a3b5c7d9e1f3a5b7c9d1e3f5a',
      leaf_hash: '0x8f7a931e2b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e',
      merkle_path: [
        '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef',
        '0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890',
        '0x9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba',
        '0xfedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210'
      ],
      proof_type: 'Merkle-Patricia Proof',
      quorum_signatures: [
        { validator_id: 'val-mcr-01', validator_name: 'Manchester Node Alpha', signature: '0x84f9a...3b2', timestamp: '10:41:22' },
        { validator_id: 'val-salford-02', validator_name: 'Salford Quays Validator', signature: '0x71a2c...4d9', timestamp: '10:41:22' },
        { validator_id: 'val-castlefield-03', validator_name: 'Castlefield Industrial Relay', signature: '0x99e4b...1a0', timestamp: '10:41:22' },
        { validator_id: 'val-spinningfields-04', validator_name: 'Spinningfields Capital', signature: '0x12c8e...8f3', timestamp: '10:41:22' },
        { validator_id: 'val-london-09', validator_name: 'London Crossrail Vault', signature: '0x44b9a...7c1', timestamp: '10:41:22' }
      ],
      attested_power_pct: 92.4,
      required_power_pct: 67.0,
      verified: true,
      created_at: new Date(Date.now() - 3000).toISOString(),
      verified_at: new Date(Date.now() - 2755).toISOString()
    }
  ]);

  // Security Threats & Incidents
  public readonly threats = signal<SecurityThreat[]>([
    {
      threat_id: 'THR-MCR-4091',
      type: 'REPLAY_ATTACK',
      severity: 'HIGH',
      source_chain: 'polygon',
      target_chain: 'eth',
      description: 'Replay attempt detected for Nonce #40182 with duplicate payload signature.',
      blocked: true,
      detected_at: '2 mins ago',
      causal_remediation: 'Nonce increment registry rejected transaction. Origin address quarantined for 30 blocks.',
      affected_routes_count: 1,
      raw_payload_snippet: '0xa9059cbb00000000000000000000000071c489a000000000000000000000000000002710'
    },
    {
      threat_id: 'THR-MCR-4092',
      type: 'INVALID_PROOF',
      severity: 'CRITICAL',
      source_chain: 'avax',
      target_chain: 'manchester',
      description: 'Forged Merkle branch with invalid cryptographic state root hash.',
      blocked: true,
      detected_at: '6 mins ago',
      causal_remediation: 'State root mismatch against Heimdall checkpoint header. Event logged in audit register.',
      affected_routes_count: 2,
      raw_payload_snippet: '0x7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a'
    }
  ]);

  public readonly activeIncident = signal<SimulationIncident | null>(null);

  // Cross-Chain Transfers
  public readonly transfers = signal<CrossChainTransfer[]>([
    {
      transfer_id: 'XFER-MCR-10492',
      source_chain: 'eth',
      destination_chain: 'cosmos',
      asset_symbol: 'USDC',
      amount: 50000,
      amount_usd: 50000,
      sender_address: '0x71C2B...894A',
      recipient_address: 'cosmos1xyz89410348759328472938472938472938472',
      message_id: 'MSG-MCR-8F72A1',
      status: 'COMPLETED',
      created_at: new Date(Date.now() - 3200).toISOString(),
      completed_at: new Date(Date.now() - 2165).toISOString(),
      fee_paid_usd: 4.85,
      execution_steps: [
        { step_name: 'Source Lock & Event Emission', chain: 'eth', status: 'DONE', tx_hash: '0x8f7a931e2b4c5d6e...', timestamp: '10:41:22' },
        { step_name: 'Validator Quorum Attestation', chain: 'manchester', status: 'DONE', timestamp: '10:41:23' },
        { step_name: 'Merkle State Proof Verification', chain: 'manchester', status: 'DONE', timestamp: '10:41:23' },
        { step_name: 'Route Dispatch & Settlement', chain: 'manchester', status: 'DONE', timestamp: '10:41:24' },
        { step_name: 'Destination Minting', chain: 'cosmos', status: 'DONE', tx_hash: 'cosmos-tx-849103', timestamp: '10:41:24' }
      ]
    }
  ]);

  // Immutable Audit Trail
  public readonly auditRecords = signal<AuditRecord[]>([
    {
      audit_id: 'AUDIT-MCR-001',
      timestamp: new Date(Date.now() - 120000).toISOString(),
      user_role: 'NETWORK_OPERATOR',
      user_identity: 'operator-tom@interchange.mcr',
      action: 'SYSTEM_BOOTSTRAP',
      target_type: 'NETWORK',
      target_id: 'FABRIC-GLOBAL',
      before_state: 'STANDBY',
      after_state: 'ONLINE_ACTIVE',
      integrity_hash: '0x8f9a1c2d3e4b5a6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c',
      provenance: 'OBSERVED'
    },
    {
      audit_id: 'AUDIT-MCR-002',
      timestamp: new Date(Date.now() - 60000).toISOString(),
      user_role: 'SECURITY_ANALYST',
      user_identity: 'sec-engine@interchange.mcr',
      action: 'CIRCUIT_BREAKER_ARMED',
      target_type: 'SECURITY',
      target_id: 'CB-POLY-ETH',
      before_state: 'DISARMED',
      after_state: 'ACTIVE_ARMED',
      integrity_hash: '0x3a9f1c7d2e4b6a8f0b1c3d5e7f9a1b3c5d7e9f1a3b5c7d9e1f3a5b7c9d1e3f5a',
      provenance: 'MODELLED'
    }
  ]);

  // Live Terminal Stream Messages
  public readonly liveLogStream = signal<string[]>([
    '[10:41:19] [FABRIC_CORE] Manchester Interchain Hive Engine initialized. Seed #1838. Quorum 14/14 healthy.',
    '[10:41:20] [ORACLE_SYNC] Synchronized cross-chain price feeds for BTC, ETH, SOL, ATOM, MANC.',
    '[10:41:21] [BLOCK_TICK] Ethereum height #21948501 committed (State root: 0x3a9f...3f5a).',
    '[10:41:22] [MESSAGE_BUS] Inbound transfer MSG-MCR-8F72A1 from ETH -> COSMOS received.',
    '[10:41:22] [QUORUM_ATTEST] 13/14 validators attested to payload 0x8f7a...9d0e (92.4% stake).',
    '[10:41:23] [PROOF_ENGINE] Merkle-Patricia proof validated successfully against ETH L1 state root.',
    '[10:41:24] [ROUTER] Executed route ETH -> MANCHESTER -> COSMOS. Delivery latency 1,240ms.',
    '[10:41:25] [SETTLEMENT] Finality settled. Audit hash 0x71c8e...8f9 committed.'
  ]);

  // Topology Nodes & Active Transit Edges
  public readonly activeTransits = signal<{
    id: string;
    source: string;
    target: string;
    progress: number;
    type: MessageClass;
    color: string;
    messageId: string;
  }[]>([
    { id: 't-1', source: 'eth', target: 'manchester', progress: 0.75, type: 'TRANSFER', color: '#627EEA', messageId: 'MSG-MCR-8F72A1' },
    { id: 't-2', source: 'manchester', target: 'cosmos', progress: 0.35, type: 'STATE_UPDATE', color: '#F9C900', messageId: 'MSG-MCR-8F72A1' },
    { id: 't-3', source: 'sol', target: 'manchester', progress: 0.85, type: 'CONTRACT_CALL', color: '#14F195', messageId: 'MSG-MCR-9E44B2' }
  ]);

  // Computed Properties
  public readonly onlineNetworksCount = computed(() => 
    this.networks().filter(n => n.status === 'ONLINE').length
  );

  public readonly activeValidatorsCount = computed(() => 
    this.validators().filter(v => v.status === 'ACTIVE').length
  );

  public readonly currentQuorumPercentage = computed(() => {
    const totalStake = this.validators().reduce((acc, v) => acc + v.stake_mi, 0);
    const activeStake = this.validators()
      .filter(v => v.status === 'ACTIVE' && !v.is_byzantine)
      .reduce((acc, v) => acc + v.stake_mi, 0);
    return totalStake > 0 ? (activeStake / totalStake) * 100 : 0;
  });

  public readonly selectedNetwork = computed(() => 
    this.networks().find(n => n.network_id === this.selectedNetworkId()) || this.networks()[0]
  );

  constructor() {
    this.startSimulationLoop();
  }

  // Simulation Clock and Message Generator
  private startSimulationLoop() {
    setInterval(() => {
      if (!this.isSimulationRunning()) return;
      this.tick();
    }, 1000);
  }

  private tick() {
    // 1. Advance Block heights
    this.networks.update(nets => nets.map(net => {
      const increment = Math.max(1, Math.round(1 / net.block_time_seconds));
      const jitter = (this.rng.next() - 0.5) * 4;
      const newLatency = Math.max(8, Math.round(net.latency_ms + jitter));
      return {
        ...net,
        current_block: net.current_block + increment,
        latency_ms: newLatency
      };
    }));

    // 2. Increment Processed Messages
    const processedDelta = Math.floor(this.rng.range(3, 8));
    this.totalMessagesProcessed.update(v => v + processedDelta);
    this.totalVolumeUSD.update(v => v + Math.floor(this.rng.range(5000, 45000)));

    // 3. Progress Active Transits
    this.activeTransits.update(transits => {
      const updated = transits.map(t => ({
        ...t,
        progress: t.progress + 0.15
      })).filter(t => t.progress < 1.0);

      // Randomly spawn new message transit along topology edges
      if (updated.length < 5 && this.rng.next() > 0.3) {
        const netList = this.networks().filter(n => n.network_id !== 'manchester' && n.status === 'ONLINE');
        if (netList.length >= 2) {
          const src = this.rng.choice(netList);
          const msgClasses: MessageClass[] = ['TRANSFER', 'CALL', 'STATE_UPDATE', 'CONTRACT_CALL', 'ATTESTATION'];
          const chosenClass = this.rng.choice(msgClasses);
          const msgId = `MSG-MCR-${this.rng.hex(3).toUpperCase()}`;

          updated.push({
            id: `t-${Date.now()}-${Math.floor(this.rng.range(100, 999))}`,
            source: src.network_id,
            target: 'manchester',
            progress: 0.05,
            type: chosenClass,
            color: src.color_hex,
            messageId: msgId
          });
        }
      }

      return updated;
    });
  }

  // Route Planning Calculation (Deterministic Multi-Objective Scoring)
  public calculateRoute(
    sourceChainId: string, 
    destChainId: string, 
    assetSymbol: string, 
    amount: number, 
    urgency: 'ECONOMY' | 'BALANCED' | 'ULTRA_FAST' | 'CRITICAL_SECURITY'
  ): InterchainRoute[] {
    const src = this.networks().find(n => n.network_id === sourceChainId) || this.networks()[1];
    const dst = this.networks().find(n => n.network_id === destChainId) || this.networks()[2];

    const routes: InterchainRoute[] = [];

    // Route 1: Direct Manchester Interchain Fabric Hub
    const hubLatency = src.latency_ms + dst.latency_ms + 24;
    const hubFee = Math.max(1.2, (amount * 0.0003) + (src.gas_price_gwei * 0.08));
    const hubSecScore = (src.health_score + dst.health_score) / 2;

    routes.push({
      route_id: `R-DIRECT-${sourceChainId}-${destChainId}`,
      source_chain: sourceChainId,
      destination_chain: destChainId,
      hops: [src.name, 'Manchester Fabric Hub (MIP-01)', dst.name],
      route_type: 'DIRECT_FABRIC',
      estimated_latency_ms: hubLatency,
      fee_estimate_usd: Number(hubFee.toFixed(2)),
      fee_native_token: `0.000${Math.floor(this.rng.range(12, 45))} ${src.native_asset}`,
      liquidity_available_usd: 18450000,
      security_score: Math.round(hubSecScore),
      finality_time_s: Number(((src.block_time_seconds + dst.block_time_seconds) * 0.8).toFixed(1)),
      reliability_score: 99.8,
      recommended: urgency !== 'ECONOMY',
      explanation: 'Direct canonical transit via Manchester Interchain Fabric with instant Merkle state verification and multi-signature quorum.',
      congestion_factor: 1.0
    });

    // Route 2: L2 Batched / Relay Rail (if applicable or alternative)
    const l2Latency = hubLatency + 180;
    const l2Fee = hubFee * 0.45;
    routes.push({
      route_id: `R-L2BATCH-${sourceChainId}-${destChainId}`,
      source_chain: sourceChainId,
      destination_chain: destChainId,
      hops: [src.name, 'Arbitrum Sequencer Relay', 'Manchester Interchain', dst.name],
      route_type: 'L2_OPTIMIZED',
      estimated_latency_ms: l2Latency,
      fee_estimate_usd: Number(l2Fee.toFixed(2)),
      fee_native_token: `0.0000${Math.floor(this.rng.range(15, 60))} ETH`,
      liquidity_available_usd: 9200000,
      security_score: 94,
      finality_time_s: Number(((src.block_time_seconds + dst.block_time_seconds) * 1.5).toFixed(1)),
      reliability_score: 98.4,
      recommended: urgency === 'ECONOMY',
      explanation: 'Batched rollup aggregation offering lower institutional network fees with slight queue buffering.',
      congestion_factor: 1.15
    });

    // Route 3: Atomic Swap Rail
    routes.push({
      route_id: `R-ATOMIC-${sourceChainId}-${destChainId}`,
      source_chain: sourceChainId,
      destination_chain: destChainId,
      hops: [src.name, 'Manchester Liquidity Pool', dst.name],
      route_type: 'ATOMIC_SWAP',
      estimated_latency_ms: Math.max(12, Math.round(hubLatency * 0.6)),
      fee_estimate_usd: Number((hubFee * 1.4).toFixed(2)),
      fee_native_token: `0.001${Math.floor(this.rng.range(10, 30))} MANC`,
      liquidity_available_usd: 5400000,
      security_score: 91,
      finality_time_s: 1.2,
      reliability_score: 97.2,
      recommended: false,
      explanation: 'Sub-second peer-to-pool atomic swap settlement backed by Manchester Hive collateral pools.',
      congestion_factor: 1.05
    });

    return routes;
  }

  // Create & Dispatch a Custom Interchain Message
  public dispatchMessage(params: {
    sourceChain: string;
    destChain: string;
    messageType: MessageClass;
    sender: string;
    recipient: string;
    payloadData: Record<string, unknown>;
    securityLevel: 'STANDARD' | 'HIGH' | 'CRITICAL_INSTITUTIONAL';
  }): InterchainMessage {
    const msgId = `MSG-MCR-${this.rng.hex(3).toUpperCase()}`;
    const srcTx = `0x${this.rng.hex(32)}`;
    const payloadHash = `0x${this.rng.hex(32)}`;

    const newMsg: InterchainMessage = {
      message_id: msgId,
      source_chain: params.sourceChain,
      source_tx: srcTx,
      destination_chain: params.destChain,
      destination_contract: params.recipient,
      sender: params.sender,
      recipient: params.recipient,
      nonce: Math.floor(this.rng.range(10000, 99999)),
      payload_hash: payloadHash,
      message_type: params.messageType,
      payload_data: params.payloadData,
      timestamp: new Date().toISOString(),
      gas_limit: 300000,
      gas_used: 195000,
      security_level: params.securityLevel,
      proof_type: params.sourceChain === 'btc' ? 'SPV Merkle Branch' : 'Merkle-Patricia Proof',
      validator_threshold: params.securityLevel === 'CRITICAL_INSTITUTIONAL' ? 0.80 : 0.67,
      current_attestation_power: 0.94,
      status: 'CREATED',
      route_path: [params.sourceChain, 'manchester', params.destChain],
      latency_total_ms: 1150,
      lifecycle: [
        {
          stage: 'CREATED',
          timestamp: new Date().toLocaleTimeString(),
          location: params.sourceChain.toUpperCase(),
          detail: `Transaction initiated by ${params.sender}`,
          duration_ms: 80
        }
      ]
    };

    // Prepend to messages queue
    this.messages.update(list => [newMsg, ...list.slice(0, 40)]);
    this.log(`[DISPATCH] Created ${newMsg.message_type} message #${newMsg.message_id} from ${newMsg.source_chain} to ${newMsg.destination_chain}`);

    // Progress through lifecycle stages asynchronously
    this.progressMessageLifecycle(newMsg.message_id);

    return newMsg;
  }

  private progressMessageLifecycle(messageId: string) {
    const stages: MessageStatus[] = ['SIGNED', 'ATTESTED', 'PROVEN', 'ROUTED', 'DELIVERED', 'EXECUTED', 'FINAL'];
    
    stages.forEach((st, index) => {
      setTimeout(() => {
        this.messages.update(list => list.map(m => {
          if (m.message_id !== messageId) return m;
          
          const eventDetails: Record<MessageStatus, string> = {
            'CREATED': 'Source transaction generated',
            'SIGNED': 'Signature validated against origin sender key',
            'ATTESTED': 'Validator quorum threshold reached (94.2% power)',
            'PROVEN': 'State root cryptographic proof verified',
            'ROUTED': 'Forwarded via Manchester Central Fabric rail',
            'DELIVERED': 'Destination chain adapter accepted packet',
            'EXECUTED': 'Destination smart contract executed successfully',
            'FINAL': 'Finality reached and immutable receipt stored',
            'FAILED': 'Execution reverted',
            'REJECTED': 'Security policy rejection',
            'EXPIRED': 'Message nonce timeout'
          };

          const newLifecycle = [
            ...m.lifecycle,
            {
              stage: st,
              timestamp: new Date().toLocaleTimeString(),
              location: 'MANCHESTER_FABRIC',
              detail: eventDetails[st] || 'Stage processed',
              duration_ms: Math.floor(this.rng.range(50, 200))
            }
          ];

          return {
            ...m,
            status: st,
            lifecycle: newLifecycle
          };
        }));
      }, (index + 1) * 600);
    });
  }

  // Cross-Chain Asset Transfer Initiator
  public initiateTransfer(
    sourceChain: string, 
    destChain: string, 
    assetSymbol: string, 
    amount: number, 
    sender: string, 
    recipient: string
  ): CrossChainTransfer {
    const transferId = `XFER-MCR-${Math.floor(this.rng.range(10000, 99999))}`;
    const asset = this.assets().find(a => a.symbol === assetSymbol) || this.assets()[0];
    const amountUsd = amount * asset.usd_price;

    // Dispatch backing message
    const msg = this.dispatchMessage({
      sourceChain,
      destChain,
      messageType: 'TRANSFER',
      sender,
      recipient,
      payloadData: { asset: assetSymbol, amount, usdValue: amountUsd },
      securityLevel: 'HIGH'
    });

    const newTransfer: CrossChainTransfer = {
      transfer_id: transferId,
      source_chain: sourceChain,
      destination_chain: destChain,
      asset_symbol: assetSymbol,
      amount,
      amount_usd: amountUsd,
      sender_address: sender,
      recipient_address: recipient,
      message_id: msg.message_id,
      status: 'INITIATED',
      created_at: new Date().toISOString(),
      fee_paid_usd: 3.45,
      execution_steps: [
        { step_name: 'Source Lock & Event Emission', chain: sourceChain, status: 'IN_PROGRESS', timestamp: new Date().toLocaleTimeString() },
        { step_name: 'Validator Quorum Attestation', chain: 'manchester', status: 'PENDING', timestamp: new Date().toLocaleTimeString() },
        { step_name: 'Merkle State Proof Verification', chain: 'manchester', status: 'PENDING', timestamp: new Date().toLocaleTimeString() },
        { step_name: 'Route Dispatch & Settlement', chain: 'manchester', status: 'PENDING', timestamp: new Date().toLocaleTimeString() },
        { step_name: 'Destination Minting', chain: destChain, status: 'PENDING', timestamp: new Date().toLocaleTimeString() }
      ]
    };

    this.transfers.update(list => [newTransfer, ...list]);
    this.recordAudit('TRANSFER_INITIATED', 'TRANSFER', transferId, 'NONE', 'INITIATED');

    // Asynchronously complete steps
    setTimeout(() => {
      this.transfers.update(list => list.map(t => {
        if (t.transfer_id !== transferId) return t;
        return {
          ...t,
          status: 'COMPLETED',
          completed_at: new Date().toISOString(),
          execution_steps: t.execution_steps.map(s => ({ ...s, status: 'DONE' }))
        };
      }));
    }, 3200);

    return newTransfer;
  }

  // Chaos & Attack Simulation Engine
  public injectAttack(attackType: SecurityThreat['type']) {
    const threatId = `THR-MCR-${Math.floor(this.rng.range(5000, 9999))}`;
    
    const attackMap: Record<SecurityThreat['type'], { desc: string; rem: string; sev: SecurityThreat['severity']; src: string; dst: string }> = {
      'REPLAY_ATTACK': {
        desc: 'Replay attempt injected with identical nonce and signature against destination bridge adapter.',
        rem: 'Duplicate Nonce Check failed. Message rejected by Replay Filter, source node restricted.',
        sev: 'HIGH',
        src: 'eth',
        dst: 'sol'
      },
      'INVALID_PROOF': {
        desc: 'Forged Merkle-Patricia leaf hash injected without matching state root branch.',
        rem: 'Merkle root verification failed at cryptographic validator consensus. Alert raised.',
        sev: 'CRITICAL',
        src: 'polygon',
        dst: 'manchester'
      },
      'NONCE_COLLISION': {
        desc: 'Concurrent transaction submitted with conflicting nonce sequence.',
        rem: 'Out-of-order nonce buffer caught collision. Forced deterministic sequencer serialization.',
        sev: 'MEDIUM',
        src: 'arb',
        dst: 'cosmos'
      },
      'WRONG_CHAIN_ID': {
        desc: 'EIP-155 replay attempt with mismatched chain identity header.',
        rem: 'Chain identity header rejected by Manchester Gateway parsing filter.',
        sev: 'LOW',
        src: 'avax',
        dst: 'eth'
      },
      'VALIDATOR_COLLUSION': {
        desc: 'Conflicting state assertion signed by rogue validator node.',
        rem: 'Byzantine Fault Tolerant 2/3 Quorum threshold isolated the rogue node. Slashing initiated.',
        sev: 'CRITICAL',
        src: 'manchester',
        dst: 'manchester'
      },
      'STALE_STATE': {
        desc: 'State proof submitted based on block header older than finality horizon.',
        rem: 'Proof rejected due to expired block confirmation window.',
        sev: 'MEDIUM',
        src: 'btc',
        dst: 'eth'
      },
      'BRIDGE_DRAIN': {
        desc: 'Anomalous volume spike exceeding velocity rate limit thresholds.',
        rem: 'Institutional rate limiter clamped transfer pool. Emergency liquidity freeze triggered.',
        sev: 'CRITICAL',
        src: 'eth',
        dst: 'arb'
      },
      'MALFORMED_PAYLOAD': {
        desc: 'Calldata ABI decoding failed with buffer overflow indicator.',
        rem: 'Payload sanitizer dropped packet before execution engine call.',
        sev: 'HIGH',
        src: 'op',
        dst: 'base'
      },
      'DESTINATION_REVERT': {
        desc: 'Destination smart contract execution failed gas consumption limit.',
        rem: 'Two-way settlement rollback credited funds back to origin custody lock.',
        sev: 'MEDIUM',
        src: 'base',
        dst: 'eth'
      }
    };

    const details = attackMap[attackType];
    const newThreat: SecurityThreat = {
      threat_id: threatId,
      type: attackType,
      severity: details.sev,
      source_chain: details.src,
      target_chain: details.dst,
      description: details.desc,
      blocked: true,
      detected_at: 'Just now',
      causal_remediation: details.rem,
      affected_routes_count: 1,
      raw_payload_snippet: `0x${this.rng.hex(32)}`
    };

    this.threats.update(list => [newThreat, ...list]);
    this.log(`[SECURITY_ALERT] Injected attack ${attackType}: ${details.desc}`);
    this.recordAudit('ATTACK_INJECTED', 'SECURITY', threatId, 'CLEAN', attackType);
  }

  // SIGNATURE DEMONSTRATION 1: "ONE TRANSACTION. FIVE CHAINS."
  public runSignatureDemo1(): { demoId: string; steps: string[] } {
    this.log('===========================================================');
    this.log('>>> RUNNING SIGNATURE DEMO 1: "ONE TRANSACTION. FIVE CHAINS."');
    this.log('>>> ETHEREUM -> MANCHESTER -> ARBITRUM L2 -> COSMOS -> SOLANA');
    this.log('===========================================================');

    const demoSteps = [
      'Stage 1 (Ethereum): User initiates £500,000 liquidity settlement. Assets locked in EVM vault.',
      'Stage 2 (Manchester Fabric): Attestation quorum gathers 14/14 validator BLS signatures.',
      'Stage 3 (Arbitrum Nitro L2): Optimistic execution assertion routed through Nitro Sequencer.',
      'Stage 4 (Cosmos Hub): IBC-v8 light client verifies Merkle state root header.',
      'Stage 5 (Solana): High-throughput SeaLevel minting finishes in slot finality. 100% Complete.'
    ];

    // Create 5 linked messages
    ['eth', 'manchester', 'arb', 'cosmos', 'sol'].forEach((chain, i) => {
      setTimeout(() => {
        this.log(`[DEMO 1 STEP ${i + 1}/5] ${demoSteps[i]}`);
        this.dispatchMessage({
          sourceChain: chain,
          destChain: i < 4 ? ['manchester', 'arb', 'cosmos', 'sol'][i] : 'sol',
          messageType: i === 0 ? 'TRANSFER' : i === 2 ? 'CONTRACT_CALL' : 'STATE_UPDATE',
          sender: `DemoUser-Hop-${i + 1}`,
          recipient: `0xHopRecipient-${i + 2}`,
          payloadData: { step: i + 1, totalHops: 5, demo: 'FIVE_CHAIN_ORCHESTRATION' },
          securityLevel: 'CRITICAL_INSTITUTIONAL'
        });
      }, i * 900);
    });

    this.recordAudit('SIGNATURE_DEMO_RUN', 'CONFIG', 'DEMO-01-FIVE-CHAINS', 'STANDBY', 'COMPLETED');
    return { demoId: 'DEMO-01', steps: demoSteps };
  }

  // SIGNATURE DEMONSTRATION 2: "THE INTERCHAIN FAILS" (Chaos & Self-Healing Failover)
  public runSignatureDemo2() {
    this.log('===========================================================');
    this.log('>>> RUNNING SIGNATURE DEMO 2: "THE INTERCHAIN FAILS"');
    this.log('>>> Injecting validator partition & simulating causal route failover');
    this.log('===========================================================');

    // 1. Degrade 3 key validators
    this.validators.update(vals => vals.map((v, i) => {
      if (i < 3) {
        return {
          ...v,
          status: 'OFFLINE',
          uptime_pct: 78.4,
          is_byzantine: true,
          risk_score: 'CRITICAL'
        };
      }
      return v;
    }));

    // 2. Mark Cosmos channel degraded
    this.networks.update(nets => nets.map(n => {
      if (n.network_id === 'cosmos') {
        return { ...n, status: 'DEGRADED', health_score: 72.4, latency_ms: 180 };
      }
      return n;
    }));

    // 3. Set Active Incident
    const incident: SimulationIncident = {
      incident_id: 'INC-MCR-2048',
      title: 'COSMOS INTEROP CHANNEL DEGRADATION (QUORUM BELOW THRESHOLD)',
      severity: 'CRITICAL',
      cause: '3 synthetic validators offline concurrently. Attestation power dropped from 99.9% to 71.4%.',
      affected_routes: ['R-DIRECT-eth-cosmos', 'R-DIRECT-sol-cosmos', 'R-DIRECT-btc-cosmos'],
      affected_assets: ['ATOM', 'USDC'],
      queued_messages_count: 1420,
      automatic_response: 'Automated Failover Router engaged: Traffic redirected through Arbitrum Nitro & Polkadot BEEFY backup rails. Network re-stabilized.',
      status: 'CONTAINED',
      timestamp: new Date().toLocaleTimeString()
    };
    this.activeIncident.set(incident);
    this.activeIncidentsCount.set(1);

    this.log(`[INCIDENT_ACTIVE] ${incident.title}. Cause: ${incident.cause}`);
    this.log(`[AUTO_REMEDIATION] ${incident.automatic_response}`);

    this.recordAudit('INCIDENT_TRIGGERED', 'NETWORK', 'INC-MCR-2048', 'HEALTHY', 'CONTAINED');

    // Auto-heal after 8 seconds
    setTimeout(() => {
      this.healNetwork();
    }, 8000);
  }

  // Heal Network after Chaos Demonstration
  public healNetwork() {
    this.validators.update(vals => vals.map(v => ({
      ...v,
      status: 'ACTIVE',
      uptime_pct: 99.9,
      is_byzantine: false,
      risk_score: 'LOW'
    })));

    this.networks.update(nets => nets.map(n => ({
      ...n,
      status: 'ONLINE',
      health_score: 99.9,
      latency_ms: n.network_id === 'eth' ? 68 : n.network_id === 'btc' ? 180 : 35
    })));

    this.activeIncident.set(null);
    this.activeIncidentsCount.set(0);
    this.log('[SYSTEM_RECOVERY] Quorum restored to 100%. All sovereign connectors healthy.');
    this.recordAudit('NETWORK_HEALED', 'NETWORK', 'ALL_CHAINS', 'DEGRADED', 'HEALTHY');
  }

  // SIGNATURE DEMONSTRATION 3: "BLOCKCHAIN INTERNET" (Progressive Ignition)
  public runSignatureDemo3() {
    this.log('===========================================================');
    this.log('>>> RUNNING SIGNATURE DEMO 3: "BLOCKCHAIN INTERNET"');
    this.log('>>> Activating 11 sovereign blockchains into one interoperable hive');
    this.log('===========================================================');

    // First isolate all chains
    this.networks.update(nets => nets.map(n => ({
      ...n,
      status: n.network_id === 'manchester' ? 'ONLINE' : 'DEGRADED',
      interchain_channels: 0
    })));

    // Progressively connect each chain
    const allNets = this.networks();
    allNets.forEach((net, idx) => {
      setTimeout(() => {
        this.networks.update(currentNets => currentNets.map(n => {
          if (n.network_id === net.network_id) {
            return {
              ...n,
              status: 'ONLINE',
              interchain_channels: Math.floor(this.rng.range(5, 10)),
              health_score: 99.9
            };
          }
          return n;
        }));
        this.log(`[HIVE_INTEGRATION] Connected chain ${net.name} [ID: ${net.chain_id}] into Manchester Hive Fabric.`);
      }, (idx + 1) * 500);
    });

    this.recordAudit('BLOCKCHAIN_INTERNET_ACTIVATED', 'CONFIG', 'HIVE-11-CHAINS', 'ISOLATED', 'INTEROPERABLE');
  }

  // Toggle Validator Status (Manual Chaos Test)
  public toggleValidator(validatorId: string) {
    this.validators.update(vals => vals.map(v => {
      if (v.validator_id !== validatorId) return v;
      const nextStatus = v.status === 'ACTIVE' ? 'OFFLINE' : 'ACTIVE';
      const isByz = nextStatus === 'OFFLINE';
      this.log(`[VALIDATOR_CONTROL] Validator ${v.name} status switched to ${nextStatus}.`);
      this.recordAudit('VALIDATOR_STATUS_CHANGE', 'VALIDATOR', v.validator_id, v.status, nextStatus);
      return {
        ...v,
        status: nextStatus,
        is_byzantine: isByz,
        risk_score: isByz ? 'HIGH' : 'LOW'
      };
    }));
  }

  // Helper Logger
  public log(msg: string) {
    const timestamp = new Date().toLocaleTimeString();
    const formatted = `[${timestamp}] ${msg}`;
    this.liveLogStream.update(logs => [formatted, ...logs.slice(0, 100)]);
  }

  // Record Immutable Audit Log
  public recordAudit(action: string, targetType: AuditRecord['target_type'], targetId: string, before: string, after: string) {
    const auditId = `AUDIT-MCR-${Math.floor(this.rng.range(1000, 9999))}`;
    const hash = `0x${this.rng.hex(32)}`;
    const newRecord: AuditRecord = {
      audit_id: auditId,
      timestamp: new Date().toISOString(),
      user_role: this.currentUserRole(),
      user_identity: `operator-${this.currentUserRole().toLowerCase()}@manchester.io`,
      action,
      target_type: targetType,
      target_id: targetId,
      before_state: before,
      after_state: after,
      integrity_hash: hash,
      provenance: 'SIMULATED'
    };
    this.auditRecords.update(records => [newRecord, ...records.slice(0, 50)]);
  }
}
