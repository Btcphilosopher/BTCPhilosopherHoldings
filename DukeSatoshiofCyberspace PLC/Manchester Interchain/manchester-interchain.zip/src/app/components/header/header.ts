import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { InterchainSimulation } from '../../core/services/interchain-simulation';
import { UserRole } from '../../core/models/interchain.types';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="border-b border-[#262933] bg-[#111318] text-[#F4F1E8] px-4 lg:px-6 py-3 select-none">
      <div class="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        
        <!-- Brand & Manchester Bee Abstract Hex Core -->
        <div class="flex items-center gap-4">
          <div class="relative flex items-center justify-center w-11 h-11 bg-[#1A1C23] border border-[#F9C900]/40 rounded-xl shadow-inner group cursor-pointer hover:border-[#F9C900] transition-colors">
            <!-- Geometric Manchester Bee / Hive Motif -->
            <svg class="w-7 h-7 text-[#F9C900]" viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <!-- Central Hive Hexagon -->
              <polygon points="24,6 38,14 38,30 24,38 10,30 10,14" fill="#F9C900" fill-opacity="0.12" stroke="#F9C900"/>
              <!-- Bee Worker Stripes -->
              <line x1="14" y1="18" x2="34" y2="18" stroke="#F9C900" stroke-width="2"/>
              <line x1="12" y1="24" x2="36" y2="24" stroke="#F9C900" stroke-width="2.5"/>
              <line x1="15" y1="30" x2="33" y2="30" stroke="#F9C900" stroke-width="2"/>
              <!-- Cross-Interchange Connectivity Vectors -->
              <circle cx="24" cy="6" r="2.5" fill="#F9C900"/>
              <circle cx="38" cy="14" r="2.5" fill="#F9C900"/>
              <circle cx="38" cy="30" r="2.5" fill="#F9C900"/>
              <circle cx="24" cy="38" r="2.5" fill="#F9C900"/>
              <circle cx="10" cy="30" r="2.5" fill="#F9C900"/>
              <circle cx="10" cy="14" r="2.5" fill="#F9C900"/>
              <!-- Manchester Core Node -->
              <circle cx="24" cy="24" r="3" fill="#F4F1E8" stroke="#0F1013" stroke-width="1.5"/>
            </svg>
            <div class="absolute -bottom-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full ring-2 ring-[#111318] animate-pulse"></div>
          </div>

          <div>
            <div class="flex items-center gap-2">
              <span class="font-extrabold text-lg lg:text-xl tracking-tight text-[#F4F1E8] font-mono">
                MANCHESTER<span class="text-[#F9C900]">.INTERCHAIN</span>
              </span>
              <span class="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded bg-[#F9C900]/10 text-[#F9C900] border border-[#F9C900]/30">
                CONTROL ENGINE v3.7
              </span>
            </div>
            <p class="text-xs text-[#73777A] font-medium tracking-wide flex items-center gap-1.5">
              <span>EVERY CHAIN. ONE INTERCHANGE.</span>
              <span class="inline-block w-1 h-1 rounded-full bg-[#73777A]"></span>
              <span class="text-[#F4F1E8]/70 font-mono text-[11px]">MANCHESTER FABRIC CORE</span>
            </p>
          </div>
        </div>

        <!-- Global Live Telemetry Indicators -->
        <div class="hidden md:grid grid-cols-2 lg:grid-cols-5 gap-2 lg:gap-3 bg-[#181A20] px-4 py-2 rounded-xl border border-[#262933]">
          
          <div class="flex flex-col border-r border-[#262933] pr-3">
            <span class="text-[10px] text-[#73777A] font-semibold uppercase tracking-wider">Messages</span>
            <div class="flex items-center gap-1.5 text-sm font-bold font-mono text-[#F4F1E8]">
              <span class="text-[#F9C900] animate-pulse">●</span>
              <span>{{ sim.totalMessagesProcessed().toLocaleString() }}</span>
            </div>
          </div>

          <div class="flex flex-col border-r border-[#262933] pr-3">
            <span class="text-[10px] text-[#73777A] font-semibold uppercase tracking-wider">Finality Rate</span>
            <span class="text-sm font-bold font-mono text-emerald-400">99.98%</span>
          </div>

          <div class="flex flex-col border-r border-[#262933] pr-3">
            <span class="text-[10px] text-[#73777A] font-semibold uppercase tracking-wider">Quorum Power</span>
            <div class="flex items-center gap-1 text-sm font-bold font-mono" [class.text-emerald-400]="sim.currentQuorumPercentage() > 80" [class.text-amber-400]="sim.currentQuorumPercentage() <= 80">
              <span>{{ sim.currentQuorumPercentage().toFixed(1) }}%</span>
              <span class="text-[10px] text-[#73777A]">({{ sim.activeValidatorsCount() }}/14)</span>
            </div>
          </div>

          <div class="flex flex-col border-r border-[#262933] pr-3">
            <span class="text-[10px] text-[#73777A] font-semibold uppercase tracking-wider">Active Chains</span>
            <div class="flex items-center gap-1.5 text-sm font-bold font-mono text-[#F4F1E8]">
              <span>{{ sim.onlineNetworksCount() }} / {{ sim.networks().length }}</span>
            </div>
          </div>

          <div class="flex flex-col">
            <span class="text-[10px] text-[#73777A] font-semibold uppercase tracking-wider">24h Interchain Vol</span>
            <span class="text-sm font-bold font-mono text-[#F9C900]">&#36;{{ (sim.totalVolumeUSD() / 1000000).toFixed(1) }}M</span>
          </div>

        </div>

        <!-- Controls: Signature Demos, Role Switcher, Seed Badge -->
        <div class="flex items-center flex-wrap gap-2.5">
          
          <!-- Signature Demo Trigger Menu -->
          <div class="flex items-center bg-[#181A20] rounded-lg border border-[#262933] p-1">
            <button 
              (click)="sim.runSignatureDemo1()" 
              title="Demo 1: 5-Chain Orchestrated Hop (ETH -> MI -> ARB -> COSMOS -> SOL)"
              class="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded bg-[#111318] hover:bg-[#F9C900] hover:text-black text-[#F4F1E8] transition-all cursor-pointer">
              <mat-icon class="text-[15px] !w-4 !h-4 text-[#F9C900] group-hover:text-black">alt_route</mat-icon>
              <span>5-Chain Hop</span>
            </button>

            <button 
              (click)="sim.runSignatureDemo2()" 
              title="Demo 2: Chaos & Self-Healing Failover Simulation"
              class="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded hover:bg-rose-500 hover:text-white text-[#F4F1E8] transition-all cursor-pointer">
              <mat-icon class="text-[15px] !w-4 !h-4 text-rose-400">healing</mat-icon>
              <span>Chaos Failover</span>
            </button>

            <button 
              (click)="sim.runSignatureDemo3()" 
              title="Demo 3: Progressive Hive Network Ignition"
              class="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded hover:bg-emerald-500 hover:text-black text-[#F4F1E8] transition-all cursor-pointer">
              <mat-icon class="text-[15px] !w-4 !h-4 text-emerald-400">bolt</mat-icon>
              <span>Ignition</span>
            </button>
          </div>

          <!-- Role Selector -->
          <div class="flex items-center gap-1 bg-[#181A20] border border-[#262933] rounded-lg px-2.5 py-1 text-xs">
            <mat-icon class="text-[#73777A] text-[16px] !w-4 !h-4">admin_panel_settings</mat-icon>
            <select 
              [value]="sim.currentUserRole()" 
              (change)="onRoleChange($event)"
              class="bg-transparent text-xs font-mono font-semibold text-[#F9C900] focus:outline-none cursor-pointer">
              <option value="NETWORK_OPERATOR" class="bg-[#111318] text-[#F4F1E8]">NETWORK OPERATOR</option>
              <option value="SYSTEM_ADMIN" class="bg-[#111318] text-[#F4F1E8]">SYSTEM ADMIN</option>
              <option value="SECURITY_ANALYST" class="bg-[#111318] text-[#F4F1E8]">SECURITY ANALYST</option>
              <option value="VALIDATOR_OPERATOR" class="bg-[#111318] text-[#F4F1E8]">VALIDATOR OPERATOR</option>
              <option value="LIQUIDITY_MANAGER" class="bg-[#111318] text-[#F4F1E8]">LIQUIDITY MANAGER</option>
              <option value="AUDITOR" class="bg-[#111318] text-[#F4F1E8]">AUDITOR (READ ONLY)</option>
            </select>
          </div>

          <!-- Simulation Provenance Badge -->
          <div class="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#262933]/60 border border-white/10 text-[11px] font-mono text-[#73777A]">
            <span class="w-2 h-2 rounded-full bg-[#F9C900]"></span>
            <span>SEED #{{ sim.currentSeed() }}</span>
          </div>

        </div>

      </div>

      <!-- Active Incident Alert Banner if Chaos / Attack Triggered -->
      @if (sim.activeIncident(); as incident) {
        <div class="mt-3 px-3 py-2 rounded-lg bg-rose-950/60 border border-rose-500/50 flex flex-col md:flex-row items-start md:items-center justify-between gap-2 text-xs">
          <div class="flex items-center gap-2 text-rose-200">
            <mat-icon class="text-rose-400 animate-pulse">warning</mat-icon>
            <span class="font-bold font-mono tracking-wide">{{ incident.title }}</span>
            <span class="hidden lg:inline text-rose-300/80">| {{ incident.cause }}</span>
          </div>
          <div class="flex items-center gap-3">
            <span class="text-emerald-300 font-medium">✓ {{ incident.automatic_response }}</span>
            <button 
              (click)="sim.healNetwork()" 
              class="px-2 py-0.5 rounded bg-rose-500 hover:bg-rose-400 text-black font-bold text-[10px] uppercase cursor-pointer">
              Restore Normal
            </button>
          </div>
        </div>
      }
    </header>
  `
})
export class Header {
  protected sim = inject(InterchainSimulation);

  onRoleChange(event: Event) {
    const target = event.target as HTMLSelectElement;
    if (target) {
      this.sim.currentUserRole.set(target.value as UserRole);
      this.sim.recordAudit('ROLE_SWITCH', 'CONFIG', 'RBAC', 'USER_SWITCH', target.value);
    }
  }
}
