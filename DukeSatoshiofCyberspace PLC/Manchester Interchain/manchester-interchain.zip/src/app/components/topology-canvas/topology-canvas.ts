import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { InterchainSimulation } from '../../core/services/interchain-simulation';

interface GraphNode {
  id: string;
  name: string;
  shortName: string;
  category: string;
  x: number;
  y: number;
  color: string;
  isHub: boolean;
  status: string;
  nativeAsset: string;
  latencyMs: number;
  tps: number;
  currentBlock: number;
  channelsCount: number;
}

interface GraphLink {
  id: string;
  sourceId: string;
  targetId: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  status: string;
  latencyMs: number;
  isSecondary: boolean;
}

@Component({
  selector: 'app-topology-canvas',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-[520px] lg:h-[600px] bg-[#0c0d11] border border-[#262933] rounded-2xl overflow-hidden flex flex-col select-none industrial-grid shadow-2xl">
      
      <!-- Graph Header Bar & Filters -->
      <div class="absolute top-3 left-3 right-3 z-20 flex flex-wrap items-center justify-between gap-3 bg-[#111318]/90 backdrop-blur-md px-4 py-2.5 rounded-xl border border-[#262933]">
        <div class="flex items-center gap-3">
          <div class="flex items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-full bg-[#F9C900] animate-pulse"></span>
            <span class="font-extrabold text-xs lg:text-sm uppercase tracking-wider text-[#F4F1E8] font-mono">
              INTERCHAIN TOPOLOGY & FABRIC GRAPH
            </span>
          </div>
          <span class="text-[11px] text-[#73777A] font-mono hidden sm:inline">| 11 SOVEREIGN NODES · 18 INTERCONNECTS</span>
        </div>

        <div class="flex items-center gap-2">
          <!-- Layer Filter Pills -->
          <div class="flex items-center bg-[#181A20] p-0.5 rounded-lg border border-[#262933] text-[11px]">
            <button 
              (click)="activeFilter.set('ALL')"
              [class.bg-[#F9C900]]="activeFilter() === 'ALL'"
              [class.text-black]="activeFilter() === 'ALL'"
              [class.text-[#F4F1E8]]="activeFilter() !== 'ALL'"
              class="px-2.5 py-1 rounded font-semibold transition-colors cursor-pointer">
              All (11)
            </button>
            <button 
              (click)="activeFilter.set('L1')"
              [class.bg-[#F9C900]]="activeFilter() === 'L1'"
              [class.text-black]="activeFilter() === 'L1'"
              [class.text-[#F4F1E8]]="activeFilter() !== 'L1'"
              class="px-2.5 py-1 rounded font-semibold transition-colors cursor-pointer">
              L1 Sovereigns
            </button>
            <button 
              (click)="activeFilter.set('L2')"
              [class.bg-[#F9C900]]="activeFilter() === 'L2'"
              [class.text-black]="activeFilter() === 'L2'"
              [class.text-[#F4F1E8]]="activeFilter() !== 'L2'"
              class="px-2.5 py-1 rounded font-semibold transition-colors cursor-pointer">
              L2 Rollups
            </button>
          </div>

          <!-- View Centering Control -->
          <button 
            (click)="resetView()"
            title="Recenter Topology Graph"
            class="p-1.5 rounded-lg bg-[#181A20] hover:bg-[#262933] border border-[#262933] text-[#F4F1E8] transition-colors cursor-pointer">
            <mat-icon class="text-sm">center_focus_strong</mat-icon>
          </button>
        </div>
      </div>

      <!-- Interactive SVG Network Graph -->
      <div class="relative w-full h-full flex-1 overflow-hidden cursor-crosshair">
        <svg class="w-full h-full" viewBox="0 0 1000 620" preserveAspectRatio="xMidYMid meet">
          
          <defs>
            <!-- Glow Filters for Manchester Core and Sovereign Nodes -->
            <filter id="glow-gold" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur in="SourceGraphic" stdDeviation="6" result="blur"/>
              <feMerge>
                <feMergeNode in="blur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>

            <filter id="glow-packet" x="-40%" y="-40%" width="180%" height="180%">
              <feGaussianBlur in="SourceGraphic" stdDeviation="3" result="blur"/>
              <feMerge>
                <feMergeNode in="blur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>

            <!-- Radial Gradients for Central Hive Fabric -->
            <radialGradient id="hive-gradient" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stop-color="#F9C900" stop-opacity="0.35"/>
              <stop offset="60%" stop-color="#F9C900" stop-opacity="0.08"/>
              <stop offset="100%" stop-color="#0c0d11" stop-opacity="0"/>
            </radialGradient>

            <radialGradient id="node-back-gradient" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stop-color="#262933" stop-opacity="0.8"/>
              <stop offset="100%" stop-color="#111318" stop-opacity="0.95"/>
            </radialGradient>
          </defs>

          <!-- Central Ambient Hive Field -->
          <circle cx="500" cy="310" r="190" fill="url(#hive-gradient)" />
          <circle cx="500" cy="310" r="280" fill="none" stroke="#F9C900" stroke-opacity="0.06" stroke-dasharray="4,6" />
          <circle cx="500" cy="310" r="180" fill="none" stroke="#F9C900" stroke-opacity="0.1" stroke-dasharray="2,4" />

          <!-- Network Edges / Interchain Channels -->
          @for (link of links(); track link.id) {
            <g class="transition-opacity duration-300">
              <!-- Background channel vector -->
              <line 
                [attr.x1]="link.x1" 
                [attr.y1]="link.y1" 
                [attr.x2]="link.x2" 
                [attr.y2]="link.y2" 
                [attr.stroke]="link.isSecondary ? '#34383B' : '#F9C900'" 
                [attr.stroke-opacity]="link.isSecondary ? 0.3 : 0.4" 
                [attr.stroke-width]="link.isSecondary ? 1.5 : 2" 
                [attr.stroke-dasharray]="link.status === 'DEGRADED' ? '6,6' : 'none'"
              />

              <!-- Latency Pill for major routes -->
              @if (!link.isSecondary) {
                <g [attr.transform]="'translate(' + ((link.x1 + link.x2) / 2) + ',' + ((link.y1 + link.y2) / 2) + ')'">
                  <rect x="-16" y="-8" width="32" height="16" rx="4" fill="#111318" stroke="#262933" stroke-width="1"/>
                  <text x="0" y="3" text-anchor="middle" font-size="8" fill="#73777A" font-family="JetBrains Mono" font-weight="600">
                    {{ link.latencyMs }}ms
                  </text>
                </g>
              }
            </g>
          }

          <!-- Traveling Packets / Simulated Messages traversing vectors -->
          @for (transit of sim.activeTransits(); track transit.id) {
            @let coords = getTransitCoordinates(transit.source, transit.target, transit.progress);
            @if (coords) {
              <g [attr.transform]="'translate(' + coords.x + ',' + coords.y + ')'" filter="url(#glow-packet)">
                <circle cx="0" cy="0" r="5" [attr.fill]="transit.color" />
                <circle cx="0" cy="0" r="8" [attr.fill]="transit.color" opacity="0.4" class="animate-ping" />
                <text x="0" y="-8" text-anchor="middle" font-size="8" fill="#F4F1E8" font-family="JetBrains Mono" font-weight="bold">
                  {{ transit.type.substring(0, 4) }}
                </text>
              </g>
            }
          }

          <!-- Sovereign Chain Nodes & Manchester Hive Center -->
          @for (node of nodes(); track node.id) {
            @if (isNodeVisible(node)) {
              <g 
                (click)="selectNode(node.id)"
                [attr.transform]="'translate(' + node.x + ',' + node.y + ')'"
                class="cursor-pointer group">
                
                @if (node.isHub) {
                  <!-- MANCHESTER CENTRAL FABRIC HUB (Abstract Hexagonal Hive Core) -->
                  <g filter="url(#glow-gold)">
                    <!-- Outer rotating ring -->
                    <circle cx="0" cy="0" r="48" fill="none" stroke="#F9C900" stroke-width="1.5" stroke-dasharray="6,8" stroke-opacity="0.7"/>
                    <circle cx="0" cy="0" r="40" fill="#1A1C23" stroke="#F9C900" stroke-width="2.5" />
                    
                    <!-- Hexagonal Bee Core -->
                    <polygon points="0,-22 19,-11 19,11 0,22 -19,11 -19,-11" fill="#F9C900" fill-opacity="0.2" stroke="#F9C900" stroke-width="2"/>
                    <line x1="-10" y1="-5" x2="10" y2="-5" stroke="#F9C900" stroke-width="2"/>
                    <line x1="-12" y1="0" x2="12" y2="0" stroke="#F9C900" stroke-width="2.5"/>
                    <line x1="-10" y1="5" x2="10" y2="5" stroke="#F9C900" stroke-width="2"/>
                    <circle cx="0" cy="0" r="3.5" fill="#F4F1E8"/>

                    <text x="0" y="60" text-anchor="middle" font-size="12" fill="#F9C900" font-family="JetBrains Mono" font-weight="800" letter-spacing="1">
                      MANCHESTER INTERCHAIN
                    </text>
                    <text x="0" y="74" text-anchor="middle" font-size="9" fill="#73777A" font-family="JetBrains Mono" font-weight="500">
                      CORE INTERCHANGE FABRIC
                    </text>
                  </g>
                } @else {
                  <!-- Sovereign Blockchain Node -->
                  <g [class.scale-110]="sim.selectedNetworkId() === node.id" class="transition-transform duration-200">
                    <!-- Background aura -->
                    <circle cx="0" cy="0" r="28" fill="url(#node-back-gradient)" stroke="#262933" stroke-width="1.5" />
                    <circle cx="0" cy="0" r="28" fill="none" [attr.stroke]="node.color" stroke-width="2" [attr.stroke-opacity]="sim.selectedNetworkId() === node.id ? 1 : 0.6" />
                    
                    <!-- Status Ring -->
                    @if (node.status === 'DEGRADED') {
                      <circle cx="0" cy="0" r="32" fill="none" stroke="#F43F5E" stroke-width="1.5" stroke-dasharray="4,4" class="animate-spin" />
                    }

                    <!-- Chain Asset / Icon Text -->
                    <text x="0" y="4" text-anchor="middle" font-size="11" [attr.fill]="node.color" font-family="JetBrains Mono" font-weight="bold">
                      {{ node.nativeAsset }}
                    </text>

                    <!-- Chain Labels -->
                    <g transform="translate(0, 42)">
                      <rect x="-42" y="-9" width="84" height="18" rx="4" fill="#111318" stroke="#262933" stroke-width="1"/>
                      <text x="0" y="3.5" text-anchor="middle" font-size="10" fill="#F4F1E8" font-family="Plus Jakarta Sans" font-weight="700">
                        {{ node.name }}
                      </text>
                    </g>

                    <!-- TPS / Block Pill below -->
                    <text x="0" y="62" text-anchor="middle" font-size="9" fill="#73777A" font-family="JetBrains Mono" font-weight="500">
                      {{ node.tps }} TPS · #{{ (node.currentBlock % 100000).toLocaleString() }}
                    </text>
                  </g>
                }

              </g>
            }
          }

        </svg>
      </div>

      <!-- Graph Footer Status Bar -->
      <div class="px-4 py-2.5 bg-[#111318] border-t border-[#262933] flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-[#73777A]">
        <div class="flex items-center gap-4">
          <span class="flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-[#F9C900]"></span>
            <span class="text-[#F4F1E8]">Direct MIP-01 Channel</span>
          </span>
          <span class="flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-[#34383B]"></span>
            <span>Secondary Rollup Bridge</span>
          </span>
          <span class="flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>Packet in Flight</span>
          </span>
        </div>

        <div class="flex items-center gap-3">
          <span>SELECTED: <strong class="text-[#F9C900]">{{ sim.selectedNetwork().name }}</strong></span>
          <button 
            (click)="selectNode('manchester')"
            class="px-2 py-0.5 rounded bg-[#1A1C23] hover:bg-[#262933] text-[#F4F1E8] border border-[#262933] text-[11px] cursor-pointer">
            Inspect Hub
          </button>
        </div>
      </div>

    </div>
  `
})
export class TopologyCanvas {
  protected sim = inject(InterchainSimulation);

  public readonly activeFilter = signal<'ALL' | 'L1' | 'L2'>('ALL');

  // Node Positions (Center Hub = 500, 310; Sovereign Chains distributed around circle)
  private readonly nodeCoordinates: Record<string, { x: number; y: number }> = {
    'manchester': { x: 500, y: 300 },
    'eth': { x: 260, y: 160 },
    'btc': { x: 500, y: 110 },
    'sol': { x: 740, y: 160 },
    'cosmos': { x: 800, y: 310 },
    'avax': { x: 740, y: 460 },
    'dot': { x: 500, y: 490 },
    'polygon': { x: 260, y: 460 },
    'arb': { x: 190, y: 300 },
    'op': { x: 340, y: 380 },
    'base': { x: 660, y: 380 }
  };

  public readonly nodes = computed<GraphNode[]>(() => {
    const nets = this.sim.networks();
    return nets.map(net => {
      const coords = this.nodeCoordinates[net.network_id] || { x: 500, y: 300 };
      return {
        id: net.network_id,
        name: net.name,
        shortName: net.native_asset,
        category: net.category,
        x: coords.x,
        y: coords.y,
        color: net.color_hex,
        isHub: net.network_id === 'manchester',
        status: net.status,
        nativeAsset: net.native_asset,
        latencyMs: net.latency_ms,
        tps: net.tps,
        currentBlock: net.current_block,
        channelsCount: net.interchain_channels
      };
    });
  });

  public readonly links = computed<GraphLink[]>(() => {
    const hub = this.nodeCoordinates['manchester'];
    const linksList: GraphLink[] = [];

    // 1. Links from all sovereign chains to Central Manchester Fabric Hub
    Object.keys(this.nodeCoordinates).forEach(id => {
      if (id === 'manchester') return;
      const pos = this.nodeCoordinates[id];
      const net = this.sim.networks().find(n => n.network_id === id);
      linksList.push({
        id: `link-hub-${id}`,
        sourceId: 'manchester',
        targetId: id,
        x1: hub.x,
        y1: hub.y,
        x2: pos.x,
        y2: pos.y,
        status: net?.status || 'ONLINE',
        latencyMs: net?.latency_ms || 35,
        isSecondary: false
      });
    });

    // 2. Secondary Cross-Rollup / IBC Links
    const secondaryPairs = [
      { a: 'arb', b: 'op' },
      { a: 'op', b: 'base' },
      { a: 'cosmos', b: 'dot' },
      { a: 'eth', b: 'arb' }
    ];

    secondaryPairs.forEach(pair => {
      const posA = this.nodeCoordinates[pair.a];
      const posB = this.nodeCoordinates[pair.b];
      if (posA && posB) {
        linksList.push({
          id: `link-sec-${pair.a}-${pair.b}`,
          sourceId: pair.a,
          targetId: pair.b,
          x1: posA.x,
          y1: posA.y,
          x2: posB.x,
          y2: posB.y,
          status: 'ONLINE',
          latencyMs: 18,
          isSecondary: true
        });
      }
    });

    return linksList;
  });

  isNodeVisible(node: GraphNode): boolean {
    const f = this.activeFilter();
    if (f === 'ALL' || node.isHub) return true;
    if (f === 'L1') return node.category.includes('L1');
    if (f === 'L2') return node.category.includes('L2');
    return true;
  }

  selectNode(networkId: string) {
    this.sim.selectedNetworkId.set(networkId);
    this.sim.log(`[TOPOLOGY_NAV] Focused on sovereign network: ${networkId.toUpperCase()}`);
  }

  resetView() {
    this.sim.selectedNetworkId.set('manchester');
    this.activeFilter.set('ALL');
    this.sim.log('[TOPOLOGY_NAV] Reset graph viewport to Manchester Central Interchange Hub.');
  }

  getTransitCoordinates(srcId: string, dstId: string, progress: number): { x: number; y: number } | null {
    const p1 = this.nodeCoordinates[srcId];
    const p2 = this.nodeCoordinates[dstId];
    if (!p1 || !p2) return null;

    const clamped = Math.max(0, Math.min(1, progress));
    return {
      x: p1.x + (p2.x - p1.x) * clamped,
      y: p1.y + (p2.y - p1.y) * clamped
    };
  }
}
