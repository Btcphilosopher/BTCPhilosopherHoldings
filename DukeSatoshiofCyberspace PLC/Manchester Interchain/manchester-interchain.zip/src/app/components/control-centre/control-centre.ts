import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { InterchainSimulation } from '../../core/services/interchain-simulation';
import { TopologyCanvas } from '../topology-canvas/topology-canvas';
import { 
  InterchainMessage, 
  InterchainRoute, 
  MessageClass
} from '../../core/models/interchain.types';

type ActiveTab = 
  | 'OVERVIEW' 
  | 'CHAINS' 
  | 'MESSAGES' 
  | 'ROUTES' 
  | 'PROOFS' 
  | 'ASSETS' 
  | 'VALIDATORS' 
  | 'SECURITY' 
  | 'XCALL' 
  | 'SIMULATION' 
  | 'API' 
  | 'ANALYTICS' 
  | 'AUDIT';

@Component({
  selector: 'app-control-centre',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule, TopologyCanvas],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col min-h-screen bg-[#0d0e12] text-[#F4F1E8]">
      
      <!-- Top Navigation Tabs Bar -->
      <nav class="sticky top-0 z-30 bg-[#111318]/95 backdrop-blur-md border-b border-[#262933] px-4 lg:px-6 overflow-x-auto scrollbar-none">
        <div class="flex items-center gap-1 py-2 min-w-max">
          
          <button 
            (click)="setTab('OVERVIEW')"
            [class.bg-[#F9C900]]="currentTab() === 'OVERVIEW'"
            [class.text-black]="currentTab() === 'OVERVIEW'"
            [class.text-[#F4F1E8]]="currentTab() !== 'OVERVIEW'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer">
            <mat-icon class="text-[16px] !w-4 !h-4">hub</mat-icon>
            <span>Network Fabric</span>
          </button>

          <button 
            (click)="setTab('CHAINS')"
            [class.bg-[#F9C900]]="currentTab() === 'CHAINS'"
            [class.text-black]="currentTab() === 'CHAINS'"
            [class.text-[#F4F1E8]]="currentTab() !== 'CHAINS'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer">
            <mat-icon class="text-[16px] !w-4 !h-4">grid_view</mat-icon>
            <span>Chains (11)</span>
          </button>

          <button 
            (click)="setTab('MESSAGES')"
            [class.bg-[#F9C900]]="currentTab() === 'MESSAGES'"
            [class.text-black]="currentTab() === 'MESSAGES'"
            [class.text-[#F4F1E8]]="currentTab() !== 'MESSAGES'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer">
            <mat-icon class="text-[16px] !w-4 !h-4">sync_alt</mat-icon>
            <span>Message Bus</span>
          </button>

          <button 
            (click)="setTab('ROUTES')"
            [class.bg-[#F9C900]]="currentTab() === 'ROUTES'"
            [class.text-black]="currentTab() === 'ROUTES'"
            [class.text-[#F4F1E8]]="currentTab() !== 'ROUTES'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer">
            <mat-icon class="text-[16px] !w-4 !h-4">alt_route</mat-icon>
            <span>Route Planner</span>
          </button>

          <button 
            (click)="setTab('PROOFS')"
            [class.bg-[#F9C900]]="currentTab() === 'PROOFS'"
            [class.text-black]="currentTab() === 'PROOFS'"
            [class.text-[#F4F1E8]]="currentTab() !== 'PROOFS'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer">
            <mat-icon class="text-[16px] !w-4 !h-4">verified_user</mat-icon>
            <span>State Proofs</span>
          </button>

          <button 
            (click)="setTab('ASSETS')"
            [class.bg-[#F9C900]]="currentTab() === 'ASSETS'"
            [class.text-black]="currentTab() === 'ASSETS'"
            [class.text-[#F4F1E8]]="currentTab() !== 'ASSETS'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer">
            <mat-icon class="text-[16px] !w-4 !h-4">account_balance</mat-icon>
            <span>Assets & Pools</span>
          </button>

          <button 
            (click)="setTab('VALIDATORS')"
            [class.bg-[#F9C900]]="currentTab() === 'VALIDATORS'"
            [class.text-black]="currentTab() === 'VALIDATORS'"
            [class.text-[#F4F1E8]]="currentTab() !== 'VALIDATORS'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer">
            <mat-icon class="text-[16px] !w-4 !h-4">dns</mat-icon>
            <span>Validator Hive</span>
          </button>

          <button 
            (click)="setTab('SECURITY')"
            [class.bg-[#F9C900]]="currentTab() === 'SECURITY'"
            [class.text-black]="currentTab() === 'SECURITY'"
            [class.text-[#F4F1E8]]="currentTab() !== 'SECURITY'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer">
            <mat-icon class="text-[16px] !w-4 !h-4 text-rose-400" [class.text-black]="currentTab() === 'SECURITY'">security</mat-icon>
            <span>Security & Threats</span>
          </button>

          <button 
            (click)="setTab('XCALL')"
            [class.bg-[#F9C900]]="currentTab() === 'XCALL'"
            [class.text-black]="currentTab() === 'XCALL'"
            [class.text-[#F4F1E8]]="currentTab() !== 'XCALL'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer">
            <mat-icon class="text-[16px] !w-4 !h-4">code</mat-icon>
            <span>X-Call Contracts</span>
          </button>

          <button 
            (click)="setTab('SIMULATION')"
            [class.bg-[#F9C900]]="currentTab() === 'SIMULATION'"
            [class.text-black]="currentTab() === 'SIMULATION'"
            [class.text-[#F4F1E8]]="currentTab() !== 'SIMULATION'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer">
            <mat-icon class="text-[16px] !w-4 !h-4">science</mat-icon>
            <span>Simulation Studio</span>
          </button>

          <button 
            (click)="setTab('API')"
            [class.bg-[#F9C900]]="currentTab() === 'API'"
            [class.text-black]="currentTab() === 'API'"
            [class.text-[#F4F1E8]]="currentTab() !== 'API'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer">
            <mat-icon class="text-[16px] !w-4 !h-4">api</mat-icon>
            <span>Developer API</span>
          </button>

          <button 
            (click)="setTab('ANALYTICS')"
            [class.bg-[#F9C900]]="currentTab() === 'ANALYTICS'"
            [class.text-black]="currentTab() === 'ANALYTICS'"
            [class.text-[#F4F1E8]]="currentTab() !== 'ANALYTICS'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer">
            <mat-icon class="text-[16px] !w-4 !h-4">analytics</mat-icon>
            <span>R Analytics</span>
          </button>

          <button 
            (click)="setTab('AUDIT')"
            [class.bg-[#F9C900]]="currentTab() === 'AUDIT'"
            [class.text-black]="currentTab() === 'AUDIT'"
            [class.text-[#F4F1E8]]="currentTab() !== 'AUDIT'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer">
            <mat-icon class="text-[16px] !w-4 !h-4">history_edu</mat-icon>
            <span>Audit Trail</span>
          </button>

        </div>
      </nav>

      <!-- Main Workspace Area -->
      <main class="flex-1 p-4 lg:p-6 max-w-[1920px] w-full mx-auto">
        
        <!-- ========================================================================= -->
        <!-- TAB 1: OVERVIEW & TOPOLOGY COCKPIT                                        -->
        <!-- ========================================================================= -->
        @if (currentTab() === 'OVERVIEW') {
          <div class="space-y-6">
            
            <!-- Central Topology Canvas Section -->
            <app-topology-canvas />

            <!-- Two-Column Operational Terminal & Live Message Stream -->
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              <!-- Left: Live Message Stream Feed (7 cols) -->
              <div class="lg:col-span-7 bg-[#111318] border border-[#262933] rounded-2xl p-4 lg:p-5 flex flex-col h-[480px]">
                <div class="flex items-center justify-between pb-3 border-b border-[#262933]">
                  <div class="flex items-center gap-2">
                    <mat-icon class="text-[#F9C900] text-base">stream</mat-icon>
                    <span class="font-extrabold text-sm uppercase font-mono tracking-wider">Live Canonical Message Bus Stream</span>
                  </div>
                  <span class="text-xs text-[#73777A] font-mono">14 classes · Real-time event propagation</span>
                </div>

                <div class="flex-1 overflow-y-auto space-y-2.5 mt-3 pr-1 font-mono text-xs">
                  @for (msg of sim.messages(); track msg.message_id) {
                    <div 
                      tabindex="0"
                      role="button"
                      (click)="inspectMessage(msg)"
                      (keydown.enter)="inspectMessage(msg)"
                      class="p-3 rounded-xl bg-[#181A20] hover:bg-[#20232B] border border-[#262933] transition-all cursor-pointer flex flex-col gap-2">
                      <div class="flex items-center justify-between text-[11px]">
                        <div class="flex items-center gap-2">
                          <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-[#F9C900]/10 text-[#F9C900] border border-[#F9C900]/30">
                            {{ msg.message_id }}
                          </span>
                          <span class="font-bold text-[#F4F1E8]">{{ msg.message_type }}</span>
                        </div>
                        <div class="flex items-center gap-2 text-[#73777A]">
                          <span>{{ msg.timestamp | date:'mediumTime' }}</span>
                          <span 
                            class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase"
                            [class.bg-emerald-950]="msg.status === 'FINAL' || msg.status === 'EXECUTED'"
                            [class.text-emerald-400]="msg.status === 'FINAL' || msg.status === 'EXECUTED'"
                            [class.bg-amber-950]="msg.status !== 'FINAL' && msg.status !== 'EXECUTED'"
                            [class.text-amber-400]="msg.status !== 'FINAL' && msg.status !== 'EXECUTED'">
                            {{ msg.status }}
                          </span>
                        </div>
                      </div>

                      <div class="flex items-center justify-between text-xs text-[#73777A]">
                        <div class="flex items-center gap-1.5 text-[#F4F1E8]">
                          <span class="font-bold uppercase text-[#F9C900]">{{ msg.source_chain }}</span>
                          <span>→</span>
                          <span class="text-[#73777A]">Manchester Hub</span>
                          <span>→</span>
                          <span class="font-bold uppercase text-emerald-400">{{ msg.destination_chain }}</span>
                        </div>
                        <span>Quorum: <strong>{{ (msg.current_attestation_power * 100).toFixed(0) }}%</strong></span>
                      </div>
                    </div>
                  }
                </div>
              </div>

              <!-- Right: Terminal Event Log (5 cols) -->
              <div class="lg:col-span-5 bg-[#0a0b0e] border border-[#262933] rounded-2xl p-4 lg:p-5 flex flex-col h-[480px] font-mono">
                <div class="flex items-center justify-between pb-3 border-b border-[#262933]">
                  <div class="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                    <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>Interchange Engine Console</span>
                  </div>
                  <span class="text-[10px] text-[#73777A]">STDERR / STDOUT</span>
                </div>

                <div class="flex-1 overflow-y-auto space-y-1.5 mt-3 text-[11px] text-[#F4F1E8]/80 leading-relaxed pr-1">
                  @for (line of sim.liveLogStream(); track $index) {
                    <div class="hover:text-white transition-colors">
                      <span class="text-[#F9C900]">&gt;</span> {{ line }}
                    </div>
                  }
                </div>

                <!-- Quick Transfer Command Trigger -->
                <div class="pt-3 border-t border-[#262933] flex items-center justify-between gap-2">
                  <span class="text-[11px] text-[#73777A]">Execute instant test swap:</span>
                  <button 
                    (click)="triggerQuickTransfer()" 
                    class="px-3 py-1.5 rounded-lg bg-[#F9C900] hover:bg-[#ffd000] text-black font-extrabold text-xs cursor-pointer">
                    + Dispatch 10,000 USDC Transfer
                  </button>
                </div>
              </div>

            </div>

          </div>
        }

        <!-- ========================================================================= -->
        <!-- TAB 2: SOVEREIGN BLOCKCHAINS REGISTRY & TERMINAL                          -->
        <!-- ========================================================================= -->
        @if (currentTab() === 'CHAINS') {
          <div class="space-y-6">
            
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#111318] p-4 rounded-xl border border-[#262933]">
              <div>
                <h2 class="text-base font-extrabold font-mono text-[#F4F1E8] uppercase tracking-wide">
                  Sovereign Blockchain Registry & Connectors
                </h2>
                <p class="text-xs text-[#73777A]">Each network maintains its native consensus, block finality rules, and cryptographic verification model.</p>
              </div>
              <div class="text-xs font-mono text-[#F9C900]">11 CONNECTED SOVEREIGN CHAINS</div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              @for (net of sim.networks(); track net.network_id) {
                <div 
                  tabindex="0"
                  role="button"
                  (click)="sim.selectedNetworkId.set(net.network_id)"
                  (keydown.enter)="sim.selectedNetworkId.set(net.network_id)"
                  [class.border-[#F9C900]]="sim.selectedNetworkId() === net.network_id"
                  class="bg-[#111318] hover:bg-[#161820] border border-[#262933] rounded-2xl p-5 transition-all flex flex-col justify-between gap-4 cursor-pointer">
                  
                  <div>
                    <div class="flex items-center justify-between mb-2">
                      <div class="flex items-center gap-2.5">
                        <div class="w-8 h-8 rounded-lg flex items-center justify-center font-mono font-extrabold text-xs" [style.background-color]="net.color_hex + '22'" [style.color]="net.color_hex">
                          {{ net.native_asset }}
                        </div>
                        <div>
                          <h3 class="font-bold text-sm text-[#F4F1E8]">{{ net.name }}</h3>
                          <span class="text-[10px] text-[#73777A] font-mono">{{ net.category }} · ID: {{ net.chain_id }}</span>
                        </div>
                      </div>

                      <span 
                        class="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase"
                        [class.bg-emerald-950]="net.status === 'ONLINE'"
                        [class.text-emerald-400]="net.status === 'ONLINE'"
                        [class.bg-rose-950]="net.status !== 'ONLINE'"
                        [class.text-rose-400]="net.status !== 'ONLINE'">
                        {{ net.status }}
                      </span>
                    </div>

                    <p class="text-xs text-[#73777A] line-clamp-2 my-2">{{ net.description }}</p>

                    <div class="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-[#262933] text-[11px] font-mono">
                      <div>
                        <span class="text-[#73777A] block">Consensus:</span>
                        <span class="text-[#F4F1E8] font-medium">{{ net.consensus_type }}</span>
                      </div>
                      <div>
                        <span class="text-[#73777A] block">Block Height:</span>
                        <span class="text-[#F9C900] font-bold">#{{ net.current_block.toLocaleString() }}</span>
                      </div>
                      <div>
                        <span class="text-[#73777A] block">Finality:</span>
                        <span class="text-emerald-400 font-medium">{{ net.finality_model }}</span>
                      </div>
                      <div>
                        <span class="text-[#73777A] block">Latency / TPS:</span>
                        <span class="text-[#F4F1E8]">{{ net.latency_ms }}ms · {{ net.tps }} TPS</span>
                      </div>
                    </div>
                  </div>

                  <div class="pt-3 border-t border-[#262933] flex items-center justify-between text-[10px] font-mono text-[#73777A]">
                    <span class="truncate max-w-[200px]">State Root: {{ net.state_root.substring(0, 16) }}...</span>
                    <span class="text-[#F9C900] font-bold">{{ net.interchain_channels }} Channels</span>
                  </div>

                </div>
              }
            </div>

            <!-- Deep Dive Chain Inspector Terminal -->
            @if (sim.selectedNetwork(); as selected) {
              <div class="bg-[#111318] border border-[#F9C900]/40 rounded-2xl p-6 space-y-4">
                <div class="flex items-center justify-between border-b border-[#262933] pb-3">
                  <div class="flex items-center gap-3">
                    <mat-icon class="text-[#F9C900]">terminal</mat-icon>
                    <div>
                      <h3 class="font-bold text-base text-[#F4F1E8]">Technical Terminal: {{ selected.name }}</h3>
                      <span class="text-xs font-mono text-[#73777A]">RPC: {{ selected.rpc_endpoint }}</span>
                    </div>
                  </div>
                  <span class="px-3 py-1 rounded bg-[#F9C900]/10 border border-[#F9C900]/30 text-[#F9C900] text-xs font-mono font-bold">
                    HEALTH: {{ selected.health_score }}%
                  </span>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
                  <div class="bg-[#181A20] p-4 rounded-xl border border-[#262933] space-y-2">
                    <span class="text-[#73777A] uppercase text-[10px] font-bold">Supported Protocols</span>
                    <div class="flex flex-wrap gap-1.5">
                      @for (proto of selected.supported_message_protocols; track proto) {
                        <span class="px-2 py-0.5 rounded bg-[#262933] text-[#F4F1E8] text-[11px]">{{ proto }}</span>
                      }
                    </div>
                  </div>

                  <div class="bg-[#181A20] p-4 rounded-xl border border-[#262933] space-y-2">
                    <span class="text-[#73777A] uppercase text-[10px] font-bold">Bridged Assets</span>
                    <div class="flex flex-wrap gap-1.5">
                      @for (ast of selected.supported_assets; track ast) {
                        <span class="px-2 py-0.5 rounded bg-[#262933] text-[#F9C900] text-[11px] font-bold">{{ ast }}</span>
                      }
                    </div>
                  </div>

                  <div class="bg-[#181A20] p-4 rounded-xl border border-[#262933] space-y-2">
                    <span class="text-[#73777A] uppercase text-[10px] font-bold">Validator Topology</span>
                    <div class="text-[#F4F1E8]">
                      <div>Node Architecture: <strong class="text-emerald-400">{{ selected.validator_count.toLocaleString() }} Active Nodes</strong></div>
                      <div>Gas Price: <strong>{{ selected.gas_price_gwei }} Gwei</strong></div>
                    </div>
                  </div>
                </div>

              </div>
            }

          </div>
        }

        <!-- ========================================================================= -->
        <!-- TAB 3: CANONICAL MESSAGE BUS & PROTOCOL LIFECYCLE                         -->
        <!-- ========================================================================= -->
        @if (currentTab() === 'MESSAGES') {
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            <!-- Left: Message Dispatch Form (4 cols) -->
            <div class="lg:col-span-4 bg-[#111318] border border-[#262933] rounded-2xl p-5 space-y-4">
              <div class="flex items-center gap-2 border-b border-[#262933] pb-3">
                <mat-icon class="text-[#F9C900]">send</mat-icon>
                <h3 class="font-bold text-sm font-mono uppercase text-[#F4F1E8]">Dispatch Interchain Message</h3>
              </div>

              <form [formGroup]="messageForm" (ngSubmit)="onDispatchMessage()" class="space-y-3 text-xs font-mono">
                <div>
                  <label for="msg-source-chain" class="text-[#73777A] block mb-1">Source Sovereign Chain</label>
                  <select id="msg-source-chain" formControlName="sourceChain" class="w-full bg-[#181A20] border border-[#262933] rounded-lg p-2 text-[#F4F1E8] focus:border-[#F9C900] outline-none">
                    @for (n of sim.networks(); track n.network_id) {
                      <option [value]="n.network_id">{{ n.name }} ({{ n.native_asset }})</option>
                    }
                  </select>
                </div>

                <div>
                  <label for="msg-dest-chain" class="text-[#73777A] block mb-1">Destination Sovereign Chain</label>
                  <select id="msg-dest-chain" formControlName="destChain" class="w-full bg-[#181A20] border border-[#262933] rounded-lg p-2 text-[#F4F1E8] focus:border-[#F9C900] outline-none">
                    @for (n of sim.networks(); track n.network_id) {
                      <option [value]="n.network_id">{{ n.name }} ({{ n.native_asset }})</option>
                    }
                  </select>
                </div>

                <div>
                  <label for="msg-type-select" class="text-[#73777A] block mb-1">Message Class</label>
                  <select id="msg-type-select" formControlName="messageType" class="w-full bg-[#181A20] border border-[#262933] rounded-lg p-2 text-[#F9C900] font-bold focus:border-[#F9C900] outline-none">
                    <option value="TRANSFER">TRANSFER (Asset Settlement)</option>
                    <option value="CALL">CALL (State Execution)</option>
                    <option value="STATE_UPDATE">STATE_UPDATE (Oracle / Attestation)</option>
                    <option value="CONTRACT_CALL">CONTRACT_CALL (X-Call Calldata)</option>
                    <option value="GOVERNANCE">GOVERNANCE (Cross-Chain Vote)</option>
                    <option value="IDENTITY">IDENTITY (Decentralized DID Proof)</option>
                  </select>
                </div>

                <div>
                  <label for="msg-security-level" class="text-[#73777A] block mb-1">Security Policy Threshold</label>
                  <select id="msg-security-level" formControlName="securityLevel" class="w-full bg-[#181A20] border border-[#262933] rounded-lg p-2 text-[#F4F1E8] focus:border-[#F9C900] outline-none">
                    <option value="STANDARD">STANDARD (67% Quorum Threshold)</option>
                    <option value="HIGH">HIGH (80% Quorum Threshold)</option>
                    <option value="CRITICAL_INSTITUTIONAL">CRITICAL_INSTITUTIONAL (95% Quorum + ZK Proof)</option>
                  </select>
                </div>

                <div>
                  <label for="msg-payload-json" class="text-[#73777A] block mb-1">Payload JSON</label>
                  <textarea id="msg-payload-json" formControlName="payloadJson" rows="3" class="w-full bg-[#181A20] border border-[#262933] rounded-lg p-2 text-[#F4F1E8] font-mono text-[11px] focus:border-[#F9C900] outline-none"></textarea>
                </div>

                <button 
                  type="submit" 
                  class="w-full py-2.5 rounded-lg bg-[#F9C900] hover:bg-[#ffd000] text-black font-extrabold text-xs uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-1.5">
                  <mat-icon class="text-sm">bolt</mat-icon>
                  <span>Transmit to Interchain Message Bus</span>
                </button>
              </form>
            </div>

            <!-- Right: Canonical Queue & Lifecycle Step Inspector (8 cols) -->
            <div class="lg:col-span-8 bg-[#111318] border border-[#262933] rounded-2xl p-5 flex flex-col space-y-4">
              <div class="flex items-center justify-between border-b border-[#262933] pb-3">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-[#F9C900]">fact_check</mat-icon>
                  <h3 class="font-bold text-sm font-mono uppercase text-[#F4F1E8]">Message Lifecycle Inspector</h3>
                </div>
                <span class="text-xs text-[#73777A] font-mono">11-STAGE CAUSAL LIFECYCLE</span>
              </div>

              <!-- Selected Message Detail -->
              @if (activeInspectedMessage(); as m) {
                <div class="bg-[#181A20] p-4 rounded-xl border border-[#F9C900]/30 space-y-4 font-mono text-xs">
                  <div class="flex flex-wrap items-center justify-between gap-2 border-b border-[#262933] pb-3">
                    <div class="flex items-center gap-2">
                      <span class="text-base font-extrabold text-[#F9C900]">{{ m.message_id }}</span>
                      <span class="px-2 py-0.5 rounded bg-[#262933] text-[#F4F1E8] font-bold">{{ m.message_type }}</span>
                    </div>
                    <div class="flex items-center gap-3">
                      <span>Proof: <strong class="text-emerald-400">{{ m.proof_type }}</strong></span>
                      <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 font-extrabold">{{ m.status }}</span>
                    </div>
                  </div>

                  <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                    <div>
                      <span class="text-[#73777A] block">Origin Chain:</span>
                      <span class="text-[#F4F1E8] font-bold uppercase">{{ m.source_chain }}</span>
                    </div>
                    <div>
                      <span class="text-[#73777A] block">Destination:</span>
                      <span class="text-[#F4F1E8] font-bold uppercase">{{ m.destination_chain }}</span>
                    </div>
                    <div>
                      <span class="text-[#73777A] block">Origin Nonce:</span>
                      <span class="text-[#F9C900]">#{{ m.nonce }}</span>
                    </div>
                    <div>
                      <span class="text-[#73777A] block">Total Latency:</span>
                      <span class="text-emerald-400">{{ m.latency_total_ms }}ms</span>
                    </div>
                  </div>

                  <!-- Lifecycle Progress Stepper -->
                  <div class="space-y-2 pt-2 border-t border-[#262933]">
                    <span class="text-[10px] text-[#73777A] uppercase font-bold">Causal Execution Trace</span>
                    <div class="space-y-2">
                      @for (ev of m.lifecycle; track ev.stage) {
                        <div class="flex items-start gap-3 p-2 rounded-lg bg-[#111318] border border-[#262933]">
                          <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-[#F9C900]/10 text-[#F9C900] border border-[#F9C900]/30 min-w-[75px] text-center">
                            {{ ev.stage }}
                          </span>
                          <div class="flex-1 text-[11px]">
                            <div class="flex items-center justify-between text-[#73777A]">
                              <span class="font-bold text-[#F4F1E8]">{{ ev.location }}</span>
                              <span>{{ ev.timestamp }} (+{{ ev.duration_ms }}ms)</span>
                            </div>
                            <p class="text-[#73777A] mt-0.5">{{ ev.detail }}</p>
                          </div>
                        </div>
                      }
                    </div>
                  </div>

                </div>
              }

              <!-- Messages List Table -->
              <div class="space-y-2 overflow-y-auto max-h-[350px]">
                @for (msg of sim.messages(); track msg.message_id) {
                  <div 
                    tabindex="0"
                    role="button"
                    (click)="inspectMessage(msg)"
                    (keydown.enter)="inspectMessage(msg)"
                    [class.border-[#F9C900]]="activeInspectedMessage()?.message_id === msg.message_id"
                    class="p-3 rounded-xl bg-[#14161D] hover:bg-[#1A1D26] border border-[#262933] transition-all flex items-center justify-between gap-3 text-xs font-mono cursor-pointer">
                    <div class="flex items-center gap-3">
                      <span class="font-bold text-[#F9C900]">{{ msg.message_id }}</span>
                      <span class="text-[#F4F1E8]">{{ msg.source_chain.toUpperCase() }} → {{ msg.destination_chain.toUpperCase() }}</span>
                      <span class="text-[10px] text-[#73777A]">({{ msg.message_type }})</span>
                    </div>
                    <div class="flex items-center gap-3">
                      <span class="text-xs text-[#73777A]">{{ msg.latency_total_ms }}ms</span>
                      <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-[#262933] text-[#F4F1E8]">
                        {{ msg.status }}
                      </span>
                    </div>
                  </div>
                }
              </div>

            </div>

          </div>
        }

        <!-- ========================================================================= -->
        <!-- TAB 4: INTERCHAIN ROUTING ENGINE                                          -->
        <!-- ========================================================================= -->
        @if (currentTab() === 'ROUTES') {
          <div class="space-y-6">
            
            <div class="bg-[#111318] border border-[#262933] rounded-2xl p-5">
              <div class="flex items-center gap-2 mb-4">
                <mat-icon class="text-[#F9C900]">alt_route</mat-icon>
                <div>
                  <h3 class="font-bold text-sm font-mono uppercase text-[#F4F1E8]">Deterministic Multi-Objective Route Planner</h3>
                  <p class="text-xs text-[#73777A]">Evaluates latency, validator availability, liquidity pools, bridge risk, and finality constraints.</p>
                </div>
              </div>

              <!-- Route Form -->
              <form [formGroup]="routeForm" (ngSubmit)="calculateRoutes()" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs font-mono">
                <div>
                  <label for="route-from-chain" class="text-[#73777A] block mb-1">From Origin Chain</label>
                  <select id="route-from-chain" formControlName="fromChain" class="w-full bg-[#181A20] border border-[#262933] rounded-lg p-2 text-[#F4F1E8] outline-none">
                    @for (n of sim.networks(); track n.network_id) {
                      <option [value]="n.network_id">{{ n.name }}</option>
                    }
                  </select>
                </div>

                <div>
                  <label for="route-to-chain" class="text-[#73777A] block mb-1">To Destination Chain</label>
                  <select id="route-to-chain" formControlName="toChain" class="w-full bg-[#181A20] border border-[#262933] rounded-lg p-2 text-[#F4F1E8] outline-none">
                    @for (n of sim.networks(); track n.network_id) {
                      <option [value]="n.network_id">{{ n.name }}</option>
                    }
                  </select>
                </div>

                <div>
                  <label for="route-amount" class="text-[#73777A] block mb-1">Asset & Amount</label>
                  <input id="route-amount" type="number" formControlName="amount" class="w-full bg-[#181A20] border border-[#262933] rounded-lg p-2 text-[#F4F1E8] outline-none" />
                </div>

                <div>
                  <label for="route-urgency" class="text-[#73777A] block mb-1">Urgency Profile</label>
                  <select id="route-urgency" formControlName="urgency" class="w-full bg-[#181A20] border border-[#262933] rounded-lg p-2 text-[#F9C900] font-bold outline-none">
                    <option value="BALANCED">BALANCED (Optimal Cost/Speed)</option>
                    <option value="ULTRA_FAST">ULTRA_FAST (Sub-Second Atomic)</option>
                    <option value="ECONOMY">ECONOMY (L2 Aggregation)</option>
                    <option value="CRITICAL_SECURITY">CRITICAL_SECURITY (Max Quorum)</option>
                  </select>
                </div>

                <div class="flex items-end">
                  <button type="submit" class="w-full py-2 bg-[#F9C900] hover:bg-[#ffd000] text-black font-extrabold rounded-lg cursor-pointer">
                    Calculate Routes
                  </button>
                </div>
              </form>
            </div>

            <!-- Route Calculations Comparison Cards -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
              @for (route of calculatedRoutes(); track route.route_id) {
                <div 
                  [class.border-[#F9C900]]="route.recommended"
                  class="bg-[#111318] border border-[#262933] rounded-2xl p-5 flex flex-col justify-between gap-4 font-mono text-xs relative">
                  
                  @if (route.recommended) {
                    <div class="absolute -top-3 right-4 px-2.5 py-0.5 bg-[#F9C900] text-black font-extrabold rounded-full text-[10px] uppercase">
                      ★ Recommended Path
                    </div>
                  }

                  <div>
                    <div class="flex items-center justify-between border-b border-[#262933] pb-2 mb-3">
                      <span class="font-extrabold text-[#F4F1E8] text-sm">{{ route.route_type }}</span>
                      <span class="text-[#F9C900] font-bold">{{ route.fee_native_token }}</span>
                    </div>

                    <!-- Hop Steps -->
                    <div class="space-y-1 mb-4">
                      <span class="text-[10px] text-[#73777A] uppercase font-bold">Execution Hops:</span>
                      <div class="flex flex-wrap items-center gap-1.5 text-[11px] text-[#F4F1E8]">
                        @for (h of route.hops; track h; let isLast = $last) {
                          <span class="px-2 py-0.5 rounded bg-[#181A20] border border-[#262933]">{{ h }}</span>
                          @if (!isLast) { <span>→</span> }
                        }
                      </div>
                    </div>

                    <div class="grid grid-cols-2 gap-2 text-[11px] bg-[#181A20] p-3 rounded-xl border border-[#262933]">
                      <div>
                        <span class="text-[#73777A] block">Latency:</span>
                        <span class="text-emerald-400 font-bold">{{ route.estimated_latency_ms }} ms</span>
                      </div>
                      <div>
                        <span class="text-[#73777A] block">Finality Time:</span>
                        <span class="text-[#F4F1E8]">{{ route.finality_time_s }} sec</span>
                      </div>
                      <div>
                        <span class="text-[#73777A] block">Security Score:</span>
                        <span class="text-[#F9C900] font-bold">{{ route.security_score }} / 100</span>
                      </div>
                      <div>
                        <span class="text-[#73777A] block">Available Pool:</span>
                        <span class="text-[#F4F1E8]">&#36;{{ (route.liquidity_available_usd / 1000000).toFixed(1) }}M</span>
                      </div>
                    </div>

                    <p class="text-[11px] text-[#73777A] mt-3">{{ route.explanation }}</p>
                  </div>

                  <button 
                    (click)="selectAndExecuteRoute(route)"
                    class="w-full py-2 rounded-lg bg-[#181A20] hover:bg-[#F9C900] hover:text-black text-[#F4F1E8] border border-[#262933] font-bold transition-all cursor-pointer">
                    Execute via this Route
                  </button>

                </div>
              }
            </div>

          </div>
        }

        <!-- ========================================================================= -->
        <!-- TAB 5: STATE PROOFS & CRYPTOGRAPHIC VERIFICATION ENGINE                  -->
        <!-- ========================================================================= -->
        @if (currentTab() === 'PROOFS') {
          <div class="space-y-6">
            
            <div class="bg-[#111318] border border-[#262933] rounded-2xl p-5">
              <div class="flex items-center justify-between border-b border-[#262933] pb-3 mb-4">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-[#F9C900]">verified</mat-icon>
                  <div>
                    <h3 class="font-bold text-sm font-mono uppercase text-[#F4F1E8]">State Proof & Merkle Engine</h3>
                    <p class="text-xs text-[#73777A]">Zero-trust multi-party state verification across heterogeneous consensus models.</p>
                  </div>
                </div>
                <span class="text-xs font-mono text-emerald-400">100% CRYPTOGRAPHIC ATTESTATION</span>
              </div>

              <!-- Merkle Proof Architecture Visualizer -->
              <div class="bg-[#181A20] p-5 rounded-xl border border-[#262933] font-mono text-xs space-y-4">
                <div class="text-center font-bold text-sm text-[#F9C900]">
                  SOURCE STATE ROOT (ETHEREUM L1 BLOCK #21948501)
                </div>
                <div class="text-center text-[11px] text-[#73777A] bg-[#111318] p-2 rounded border border-[#262933] break-all">
                  0x3a9f1c7d2e4b6a8f0b1c3d5e7f9a1b3c5d7e9f1a3b5c7d9e1f3a5b7c9d1e3f5a
                </div>

                <div class="flex items-center justify-center gap-4 text-[#73777A]">
                  <span>▲</span>
                  <span>▲</span>
                  <span>▲</span>
                </div>

                <!-- Merkle Branches -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-[11px]">
                  <div class="bg-[#111318] p-3 rounded-lg border border-[#262933]">
                    <span class="text-[#73777A] block text-[10px] font-bold">Merkle Branch #1</span>
                    <span class="text-emerald-400 break-all">0x1234567890abcdef12345678...</span>
                  </div>
                  <div class="bg-[#111318] p-3 rounded-lg border border-[#262933]">
                    <span class="text-[#73777A] block text-[10px] font-bold">Merkle Branch #2</span>
                    <span class="text-emerald-400 break-all">0xabcdef1234567890abcdef12...</span>
                  </div>
                  <div class="bg-[#111318] p-3 rounded-lg border border-[#262933]">
                    <span class="text-[#73777A] block text-[10px] font-bold">Transaction Leaf Hash</span>
                    <span class="text-[#F9C900] break-all">0x8f7a931e2b4c5d6e7f8a9b0c...</span>
                  </div>
                </div>

                <!-- Aggregated BLS Quorum Attestations -->
                <div class="pt-3 border-t border-[#262933]">
                  <span class="text-[10px] text-[#73777A] uppercase font-bold block mb-2">BLS Multi-Signature Quorum (92.4% Power Verified)</span>
                  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 text-[11px]">
                    <div class="p-2 rounded bg-[#111318] border border-emerald-500/30 flex items-center justify-between">
                      <span class="text-[#F4F1E8]">Manchester Node Alpha</span>
                      <span class="text-emerald-400 font-bold">✓ Signed</span>
                    </div>
                    <div class="p-2 rounded bg-[#111318] border border-emerald-500/30 flex items-center justify-between">
                      <span class="text-[#F4F1E8]">Salford Quays Validator</span>
                      <span class="text-emerald-400 font-bold">✓ Signed</span>
                    </div>
                    <div class="p-2 rounded bg-[#111318] border border-emerald-500/30 flex items-center justify-between">
                      <span class="text-[#F4F1E8]">London Crossrail Vault</span>
                      <span class="text-emerald-400 font-bold">✓ Signed</span>
                    </div>
                  </div>
                </div>

              </div>

            </div>

          </div>
        }

        <!-- ========================================================================= -->
        <!-- TAB 6: ASSETS & LIQUIDITY POOLS                                          -->
        <!-- ========================================================================= -->
        @if (currentTab() === 'ASSETS') {
          <div class="space-y-6">
            
            <!-- Asset Registry Table -->
            <div class="bg-[#111318] border border-[#262933] rounded-2xl p-5 space-y-4 font-mono text-xs">
              <div class="flex items-center justify-between border-b border-[#262933] pb-3">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-[#F9C900]">account_balance_wallet</mat-icon>
                  <h3 class="font-bold text-sm uppercase text-[#F4F1E8]">Canonical & Bridged Asset Registry</h3>
                </div>
                <span class="text-[#F9C900] font-bold">6 REGISTERED ASSETS</span>
              </div>

              <div class="overflow-x-auto">
                <table class="w-full text-left">
                  <thead>
                    <tr class="text-[#73777A] border-b border-[#262933] pb-2 text-[11px]">
                      <th class="py-2">Asset</th>
                      <th>Origin Chain</th>
                      <th>Canonical vs Wrapped</th>
                      <th>Custody Model</th>
                      <th>Price (USD)</th>
                      <th>24h Volume</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-[#262933]">
                    @for (ast of sim.assets(); track ast.asset_id) {
                      <tr class="hover:bg-[#181A20] transition-colors">
                        <td class="py-3 font-bold text-[#F4F1E8] flex items-center gap-2">
                          <span class="w-3 h-3 rounded-full" [style.background-color]="ast.color_hex"></span>
                          <span>{{ ast.symbol }}</span>
                          <span class="text-[10px] text-[#73777A]">({{ ast.name }})</span>
                        </td>
                        <td class="uppercase text-[#F9C900] font-bold">{{ ast.origin_chain }}</td>
                        <td>{{ ast.canonical_asset }}</td>
                        <td>
                          <span class="px-2 py-0.5 rounded bg-[#262933] text-[10px] text-[#F4F1E8]">{{ ast.custody_model }}</span>
                        </td>
                        <td class="font-bold text-emerald-400">&#36;{{ ast.usd_price.toLocaleString() }}</td>
                        <td class="text-[#73777A]">&#36;{{ (ast.volume_24h_usd / 1000000).toFixed(1) }}M</td>
                      </tr>
                    }
                  </tbody>
                </table>
              </div>
            </div>

            <!-- Liquidity Pools Grid -->
            <div class="bg-[#111318] border border-[#262933] rounded-2xl p-5 space-y-4">
              <div class="flex items-center gap-2 border-b border-[#262933] pb-3">
                <mat-icon class="text-[#F9C900]">water_drop</mat-icon>
                <h3 class="font-bold text-sm font-mono uppercase text-[#F4F1E8]">Interchain Liquidity Rails</h3>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                @for (pool of sim.liquidityPools(); track pool.pool_id) {
                  <div class="bg-[#181A20] p-4 rounded-xl border border-[#262933] space-y-3 font-mono text-xs">
                    <div class="flex items-center justify-between border-b border-[#262933] pb-2">
                      <span class="font-extrabold text-[#F4F1E8]">{{ pool.pair_name }}</span>
                      <span class="text-emerald-400 font-bold">&#36;{{ (pool.total_liquidity_usd / 1000000).toFixed(1) }}M Reserve</span>
                    </div>

                    <div class="grid grid-cols-2 gap-2 text-[11px]">
                      <div>
                        <span class="text-[#73777A] block">Utilization:</span>
                        <span class="text-[#F9C900] font-bold">{{ pool.utilization_pct }}%</span>
                      </div>
                      <div>
                        <span class="text-[#73777A] block">24h Avg Slippage:</span>
                        <span class="text-[#F4F1E8]">{{ pool.slippage_24h_avg }}%</span>
                      </div>
                      <div>
                        <span class="text-[#73777A] block">Settlement Capacity:</span>
                        <span class="text-emerald-400 font-bold">&#36;{{ (pool.settlement_capacity_usd / 1000000).toFixed(1) }}M</span>
                      </div>
                      <div>
                        <span class="text-[#73777A] block">Fee Tier:</span>
                        <span class="text-[#73777A]">{{ pool.fee_tier_bps }} bps</span>
                      </div>
                    </div>

                    <!-- Utilization bar -->
                    <div class="w-full bg-[#111318] h-2 rounded-full overflow-hidden">
                      <div class="bg-[#F9C900] h-full" [style.width.%]="pool.utilization_pct"></div>
                    </div>
                  </div>
                }
              </div>
            </div>

          </div>
        }

        <!-- ========================================================================= -->
        <!-- TAB 7: VALIDATOR HIVE & QUORUM MATRIX                                     -->
        <!-- ========================================================================= -->
        @if (currentTab() === 'VALIDATORS') {
          <div class="space-y-6">
            
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#111318] p-4 rounded-xl border border-[#262933]">
              <div>
                <h2 class="text-base font-extrabold font-mono text-[#F4F1E8] uppercase tracking-wide">
                  Manchester Validator Hive & Consensus Matrix
                </h2>
                <p class="text-xs text-[#73777A]">14 independent institutional nodes providing cryptographic state attestations.</p>
              </div>
              <div class="text-xs font-mono">
                QUORUM POWER: <strong class="text-emerald-400">{{ sim.currentQuorumPercentage().toFixed(1) }}%</strong>
              </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              @for (val of sim.validators(); track val.validator_id) {
                <div class="bg-[#111318] border border-[#262933] rounded-2xl p-5 flex flex-col justify-between gap-3 font-mono text-xs">
                  <div>
                    <div class="flex items-center justify-between mb-2">
                      <span class="font-extrabold text-[#F4F1E8] text-sm">{{ val.name }}</span>
                      <span 
                        class="px-2 py-0.5 rounded text-[10px] font-bold uppercase"
                        [class.bg-emerald-950]="val.status === 'ACTIVE'"
                        [class.text-emerald-400]="val.status === 'ACTIVE'"
                        [class.bg-rose-950]="val.status !== 'ACTIVE'"
                        [class.text-rose-400]="val.status !== 'ACTIVE'">
                        {{ val.status }}
                      </span>
                    </div>

                    <p class="text-[11px] text-[#73777A]">{{ val.operator }} · {{ val.city }} ({{ val.region }})</p>

                    <div class="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-[#262933] text-[11px]">
                      <div>
                        <span class="text-[#73777A] block">Stake Weight:</span>
                        <span class="text-[#F9C900] font-bold">{{ val.stake_share_pct }}% ({{ (val.stake_mi / 1000000).toFixed(1) }}M MI)</span>
                      </div>
                      <div>
                        <span class="text-[#73777A] block">Uptime / Latency:</span>
                        <span class="text-emerald-400">{{ val.uptime_pct }}% · {{ val.latency_ms }}ms</span>
                      </div>
                      <div>
                        <span class="text-[#73777A] block">Attestations:</span>
                        <span class="text-[#F4F1E8]">{{ val.attestation_count.toLocaleString() }}</span>
                      </div>
                      <div>
                        <span class="text-[#73777A] block">Risk Score:</span>
                        <span [class.text-rose-400]="val.risk_score === 'HIGH' || val.risk_score === 'CRITICAL'" [class.text-emerald-400]="val.risk_score === 'LOW'">
                          {{ val.risk_score }}
                        </span>
                      </div>
                    </div>
                  </div>

                  <!-- Chaos Button to Toggle / Disrupt Validator -->
                  <div class="pt-3 border-t border-[#262933] flex items-center justify-between">
                    <span class="text-[10px] text-[#73777A]">ID: {{ val.validator_id }}</span>
                    <button 
                      (click)="sim.toggleValidator(val.validator_id)"
                      class="px-2.5 py-1 rounded text-[10px] font-bold uppercase border border-[#262933] hover:bg-[#262933] text-[#F4F1E8] transition-colors cursor-pointer">
                      Toggle Fail / Active
                    </button>
                  </div>

                </div>
              }
            </div>

          </div>
        }

        <!-- ========================================================================= -->
        <!-- TAB 8: SECURITY & THREAT ENGINE                                           -->
        <!-- ========================================================================= -->
        @if (currentTab() === 'SECURITY') {
          <div class="space-y-6">
            
            <div class="bg-[#111318] border border-rose-500/30 rounded-2xl p-5 space-y-4">
              <div class="flex items-center justify-between border-b border-[#262933] pb-3">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-rose-400">shield</mat-icon>
                  <div>
                    <h3 class="font-bold text-sm font-mono uppercase text-[#F4F1E8]">Security Engine & Threat Containment</h3>
                    <p class="text-xs text-[#73777A]">Synthetic attack detection, duplicate nonce interception, and Merkle root verification.</p>
                  </div>
                </div>
                <span class="px-2.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/30 text-xs font-mono font-bold">
                  CIRCUIT BREAKERS ARMED
                </span>
              </div>

              <!-- Attack Simulator Triggers -->
              <div>
                <span class="text-xs text-[#73777A] font-mono font-bold block mb-2">INJECT SYNTHETIC ATTACK VECTOR:</span>
                <div class="flex flex-wrap gap-2">
                  <button (click)="sim.injectAttack('REPLAY_ATTACK')" class="px-3 py-1.5 rounded-lg bg-[#181A20] hover:bg-rose-950 text-rose-300 border border-rose-900/50 text-xs font-mono font-bold cursor-pointer">
                    + Replay Attack
                  </button>
                  <button (click)="sim.injectAttack('INVALID_PROOF')" class="px-3 py-1.5 rounded-lg bg-[#181A20] hover:bg-rose-950 text-rose-300 border border-rose-900/50 text-xs font-mono font-bold cursor-pointer">
                    + Invalid Merkle Proof
                  </button>
                  <button (click)="sim.injectAttack('NONCE_COLLISION')" class="px-3 py-1.5 rounded-lg bg-[#181A20] hover:bg-rose-950 text-rose-300 border border-rose-900/50 text-xs font-mono font-bold cursor-pointer">
                    + Nonce Collision
                  </button>
                  <button (click)="sim.injectAttack('VALIDATOR_COLLUSION')" class="px-3 py-1.5 rounded-lg bg-[#181A20] hover:bg-rose-950 text-rose-300 border border-rose-900/50 text-xs font-mono font-bold cursor-pointer">
                    + Validator Collusion
                  </button>
                  <button (click)="sim.injectAttack('BRIDGE_DRAIN')" class="px-3 py-1.5 rounded-lg bg-[#181A20] hover:bg-rose-950 text-rose-300 border border-rose-900/50 text-xs font-mono font-bold cursor-pointer">
                    + Bridge Drain Attempt
                  </button>
                </div>
              </div>

              <!-- Threat Logs -->
              <div class="space-y-3 pt-2">
                @for (threat of sim.threats(); track threat.threat_id) {
                  <div class="p-4 rounded-xl bg-[#181A20] border border-rose-500/20 font-mono text-xs space-y-2">
                    <div class="flex items-center justify-between">
                      <div class="flex items-center gap-2">
                        <span class="px-2 py-0.5 rounded bg-rose-950 text-rose-400 font-extrabold text-[10px]">
                          {{ threat.type }}
                        </span>
                        <span class="font-bold text-[#F4F1E8]">{{ threat.threat_id }}</span>
                      </div>
                      <span class="text-emerald-400 font-bold">✓ BLOCKED & CONTAINED</span>
                    </div>

                    <p class="text-[#F4F1E8]/90 text-[11px]">{{ threat.description }}</p>

                    <div class="p-2 rounded bg-[#111318] text-[#73777A] text-[11px] border border-[#262933]">
                      <span class="text-[#F9C900] font-bold">Remediation:</span> {{ threat.causal_remediation }}
                    </div>
                  </div>
                }
              </div>

            </div>

          </div>
        }

        <!-- ========================================================================= -->
        <!-- TAB 9: CROSS-CHAIN SMART CONTRACT CALLS (X-CALL)                          -->
        <!-- ========================================================================= -->
        @if (currentTab() === 'XCALL') {
          <div class="bg-[#111318] border border-[#262933] rounded-2xl p-6 space-y-4">
            <div class="flex items-center gap-2 border-b border-[#262933] pb-3">
              <mat-icon class="text-[#F9C900]">code</mat-icon>
              <div>
                <h3 class="font-bold text-sm font-mono uppercase text-[#F4F1E8]">Cross-Chain Smart Contract Invocation (X-Call)</h3>
                <p class="text-xs text-[#73777A]">Construct cross-chain smart contract calls with ABI parameters, gas limit, and execution receipt verification.</p>
              </div>
            </div>

            <form [formGroup]="xcallForm" (ngSubmit)="onExecuteXCall()" class="space-y-4 font-mono text-xs">
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label for="xcall-source-contract" class="text-[#73777A] block mb-1">Source Contract / Chain</label>
                  <input id="xcall-source-contract" formControlName="sourceContract" class="w-full bg-[#181A20] border border-[#262933] rounded-lg p-2.5 text-[#F4F1E8] outline-none" />
                </div>
                <div>
                  <label for="xcall-dest-contract" class="text-[#73777A] block mb-1">Destination Target Contract</label>
                  <input id="xcall-dest-contract" formControlName="destContract" class="w-full bg-[#181A20] border border-[#262933] rounded-lg p-2.5 text-[#F4F1E8] outline-none" />
                </div>
              </div>

              <div>
                <label for="xcall-func-sig" class="text-[#73777A] block mb-1">Target Function Selector & Parameters</label>
                <input id="xcall-func-sig" formControlName="functionSignature" class="w-full bg-[#181A20] border border-[#262933] rounded-lg p-2.5 text-[#F9C900] font-bold outline-none" />
              </div>

              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label for="xcall-gas-limit" class="text-[#73777A] block mb-1">Gas Limit</label>
                  <input id="xcall-gas-limit" type="number" formControlName="gasLimit" class="w-full bg-[#181A20] border border-[#262933] rounded-lg p-2.5 text-[#F4F1E8] outline-none" />
                </div>
                <div>
                  <label for="xcall-sec-policy" class="text-[#73777A] block mb-1">Execution Security Policy</label>
                  <select id="xcall-sec-policy" formControlName="securityPolicy" class="w-full bg-[#181A20] border border-[#262933] rounded-lg p-2.5 text-[#F4F1E8] outline-none">
                    <option value="STANDARD">Standard Merkle Assertion</option>
                    <option value="HIGH">Synchronous Quorum Receipt</option>
                    <option value="CRITICAL">Two-Way Atomic Finality Rollback</option>
                  </select>
                </div>
              </div>

              <button type="submit" class="px-6 py-3 bg-[#F9C900] hover:bg-[#ffd000] text-black font-extrabold rounded-lg cursor-pointer">
                Invoke Cross-Chain Contract Call (X-Call)
              </button>
            </form>
          </div>
        }

        <!-- ========================================================================= -->
        <!-- TAB 10: SIMULATION STUDIO & DIGITAL TWIN CONTROLS                         -->
        <!-- ========================================================================= -->
        @if (currentTab() === 'SIMULATION') {
          <div class="bg-[#111318] border border-[#262933] rounded-2xl p-6 space-y-6 font-mono text-xs">
            <div class="flex items-center justify-between border-b border-[#262933] pb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-[#F9C900]">science</mat-icon>
                <div>
                  <h3 class="font-bold text-sm uppercase text-[#F4F1E8]">Digital Twin & Simulation Configuration</h3>
                  <p class="text-xs text-[#73777A]">Deterministic reproducibility with fixed seeds and causal network parameter manipulation.</p>
                </div>
              </div>
              <span class="text-[#F9C900] font-bold">SEED #{{ sim.currentSeed() }}</span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div class="bg-[#181A20] p-4 rounded-xl border border-[#262933] space-y-3">
                <span class="text-[#73777A] block text-[10px] uppercase font-bold">Active Scenario</span>
                <span class="text-[#F4F1E8] font-bold text-sm block">{{ sim.activeScenario() }}</span>
                <p class="text-[11px] text-[#73777A]">Deterministic PRNG generator ensuring identical cross-chain states across re-runs.</p>
              </div>

              <div class="bg-[#181A20] p-4 rounded-xl border border-[#262933] space-y-3">
                <span class="text-[#73777A] block text-[10px] uppercase font-bold">Network State</span>
                <div class="flex items-center gap-2">
                  <span class="w-3 h-3 rounded-full bg-emerald-400"></span>
                  <span class="text-emerald-400 font-bold">11 Chains Synchronized</span>
                </div>
                <p class="text-[11px] text-[#73777A]">Total processed: {{ sim.totalMessagesProcessed().toLocaleString() }} messages.</p>
              </div>

              <div class="bg-[#181A20] p-4 rounded-xl border border-[#262933] space-y-3">
                <span class="text-[#73777A] block text-[10px] uppercase font-bold">Chaos Control</span>
                <button 
                  (click)="sim.healNetwork()" 
                  class="w-full py-2 bg-[#262933] hover:bg-[#F9C900] hover:text-black text-[#F4F1E8] font-bold rounded-lg transition-colors cursor-pointer">
                  Reset & Heal Network
                </button>
              </div>
            </div>

          </div>
        }

        <!-- ========================================================================= -->
        <!-- TAB 11: DEVELOPER PORTAL & API TESTER                                     -->
        <!-- ========================================================================= -->
        @if (currentTab() === 'API') {
          <div class="bg-[#111318] border border-[#262933] rounded-2xl p-6 space-y-6 font-mono text-xs">
            <div class="flex items-center justify-between border-b border-[#262933] pb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-[#F9C900]">api</mat-icon>
                <div>
                  <h3 class="font-bold text-sm uppercase text-[#F4F1E8]">Enterprise REST API & SDK Sandbox</h3>
                  <p class="text-xs text-[#73777A]">OpenAPI 3.1 endpoints for institutional custody engines, bridges, and wallets.</p>
                </div>
              </div>
              <span class="px-2.5 py-0.5 rounded bg-[#262933] text-[#F9C900] text-xs font-bold">v1.4.0-PROD</span>
            </div>

            <div class="space-y-3">
              <div class="p-3 rounded-xl bg-[#181A20] border border-[#262933] flex items-center justify-between">
                <div class="flex items-center gap-3">
                  <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 font-bold">GET</span>
                  <span class="text-[#F4F1E8]">/api/v1/chains</span>
                </div>
                <span class="text-[#73777A]">List all 11 sovereign networks</span>
              </div>

              <div class="p-3 rounded-xl bg-[#181A20] border border-[#262933] flex items-center justify-between">
                <div class="flex items-center gap-3">
                  <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 font-bold">GET</span>
                  <span class="text-[#F4F1E8]">/api/v1/messages/{{ '{message_id}' }}</span>
                </div>
                <span class="text-[#73777A]">Retrieve canonical message lifecycle</span>
              </div>

              <div class="p-3 rounded-xl bg-[#181A20] border border-[#262933] flex items-center justify-between">
                <div class="flex items-center gap-3">
                  <span class="px-2 py-0.5 rounded bg-amber-950 text-amber-400 font-bold">POST</span>
                  <span class="text-[#F4F1E8]">/api/v1/routes/quote</span>
                </div>
                <span class="text-[#73777A]">Calculate multi-objective routes</span>
              </div>

              <div class="p-3 rounded-xl bg-[#181A20] border border-[#262933] flex items-center justify-between">
                <div class="flex items-center gap-3">
                  <span class="px-2 py-0.5 rounded bg-amber-950 text-amber-400 font-bold">POST</span>
                  <span class="text-[#F4F1E8]">/api/v1/transfers</span>
                </div>
                <span class="text-[#73777A]">Initiate cross-chain transfer</span>
              </div>
            </div>

            <!-- Python SDK Code Snippet -->
            <div class="space-y-2 pt-3 border-t border-[#262933]">
              <span class="text-[#73777A] uppercase text-[10px] font-bold">Python SDK Usage (interchain-py):</span>
              <pre ngNonBindable class="bg-[#0a0b0e] p-4 rounded-xl text-emerald-400 overflow-x-auto text-[11px] leading-relaxed border border-[#262933]">
from interchain import ManchesterFabricClient

client = ManchesterFabricClient(api_key="mcr_live_sec_849103")

# Quote optimal route between Ethereum and Cosmos
quote = client.routes.quote(
    source_chain="ethereum",
    destination_chain="cosmos",
    asset="USDC",
    amount=50000.0,
    security_level="HIGH"
)
print(f"Optimal Hop: &#123;quote.hops&#125; (Est Latency: &#123;quote.latency_ms&#125;ms)")
              </pre>
            </div>

          </div>
        }

        <!-- ========================================================================= -->
        <!-- TAB 12: R ANALYTICS & STATISTICAL REPORTS                                -->
        <!-- ========================================================================= -->
        @if (currentTab() === 'ANALYTICS') {
          <div class="bg-[#111318] border border-[#262933] rounded-2xl p-6 space-y-6 font-mono text-xs">
            <div class="flex items-center justify-between border-b border-[#262933] pb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-[#F9C900]">analytics</mat-icon>
                <div>
                  <h3 class="font-bold text-sm uppercase text-[#F4F1E8]">Institutional Analytics (manchesterInterchainR)</h3>
                  <p class="text-xs text-[#73777A]">Throughput distributions, latency quantiles (p50, p95, p99), and Byzantine fault probabilities.</p>
                </div>
              </div>
              <span class="text-emerald-400 font-bold">R STATS v4.4</span>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div class="bg-[#181A20] p-4 rounded-xl border border-[#262933]">
                <span class="text-[#73777A] block text-[10px]">p50 Latency</span>
                <span class="text-xl font-extrabold text-[#F4F1E8]">14.2 ms</span>
              </div>
              <div class="bg-[#181A20] p-4 rounded-xl border border-[#262933]">
                <span class="text-[#73777A] block text-[10px]">p95 Latency</span>
                <span class="text-xl font-extrabold text-[#F9C900]">48.6 ms</span>
              </div>
              <div class="bg-[#181A20] p-4 rounded-xl border border-[#262933]">
                <span class="text-[#73777A] block text-[10px]">p99 Latency</span>
                <span class="text-xl font-extrabold text-amber-400">120.4 ms</span>
              </div>
              <div class="bg-[#181A20] p-4 rounded-xl border border-[#262933]">
                <span class="text-[#73777A] block text-[10px]">Byzantine Risk Probability</span>
                <span class="text-xl font-extrabold text-emerald-400">&lt; 0.0001%</span>
              </div>
            </div>

            <div class="bg-[#0a0b0e] p-4 rounded-xl border border-[#262933] text-[11px] text-[#73777A]">
              <span class="text-[#F9C900] font-bold block mb-1">&gt; summary(manchesterInterchainModel)</span>
              <div>Call: lm(formula = latency ~ validator_quorum + message_size_bytes, data = interchain_df)</div>
              <div>Residual standard error: 1.482 on 18420 degrees of freedom</div>
              <div>Multiple R-squared: 0.9984, Adjusted R-squared: 0.9984</div>
              <div>F-statistic: 5.72e+06 on 2 and 18420 DF, p-value: &lt; 2.2e-16</div>
            </div>

          </div>
        }

        <!-- ========================================================================= -->
        <!-- TAB 13: IMMUTABLE AUDIT TRAIL                                             -->
        <!-- ========================================================================= -->
        @if (currentTab() === 'AUDIT') {
          <div class="bg-[#111318] border border-[#262933] rounded-2xl p-6 space-y-4 font-mono text-xs">
            <div class="flex items-center justify-between border-b border-[#262933] pb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-[#F9C900]">history_edu</mat-icon>
                <div>
                  <h3 class="font-bold text-sm uppercase text-[#F4F1E8]">Immutable Audit Trail & Cryptographic Provenance</h3>
                  <p class="text-xs text-[#73777A]">Cryptographically chained records of all operator actions and routing modifications.</p>
                </div>
              </div>
              <span class="text-emerald-400 font-bold">TAMPER-EVIDENT</span>
            </div>

            <div class="space-y-2 max-h-[500px] overflow-y-auto">
              @for (rec of sim.auditRecords(); track rec.audit_id) {
                <div class="p-3 rounded-xl bg-[#181A20] border border-[#262933] space-y-1">
                  <div class="flex items-center justify-between text-[11px]">
                    <div class="flex items-center gap-2">
                      <span class="text-[#F9C900] font-bold">{{ rec.audit_id }}</span>
                      <span class="text-[#F4F1E8] font-bold">{{ rec.action }}</span>
                      <span class="px-1.5 py-0.5 rounded bg-[#262933] text-[#73777A] text-[10px]">{{ rec.target_type }}: {{ rec.target_id }}</span>
                    </div>
                    <span class="text-[#73777A]">{{ rec.timestamp | date:'mediumTime' }}</span>
                  </div>
                  <div class="text-[11px] text-[#73777A] flex items-center justify-between">
                    <span>Actor: <strong class="text-[#F4F1E8]">{{ rec.user_identity }}</strong></span>
                    <span class="text-emerald-400">Provenance: [{{ rec.provenance }}]</span>
                  </div>
                  <div class="text-[10px] text-[#73777A] truncate">Hash: {{ rec.integrity_hash }}</div>
                </div>
              }
            </div>

          </div>
        }

      </main>

    </div>
  `
})
export class ControlCentre {
  protected sim = inject(InterchainSimulation);

  public readonly currentTab = signal<ActiveTab>('OVERVIEW');
  public readonly activeInspectedMessage = signal<InterchainMessage | null>(null);

  // Message Form
  public readonly messageForm = new FormGroup({
    sourceChain: new FormControl<string>('eth', { nonNullable: true }),
    destChain: new FormControl<string>('cosmos', { nonNullable: true }),
    messageType: new FormControl<MessageClass>('TRANSFER', { nonNullable: true }),
    securityLevel: new FormControl<'STANDARD' | 'HIGH' | 'CRITICAL_INSTITUTIONAL'>('HIGH', { nonNullable: true }),
    payloadJson: new FormControl<string>('{\n  "asset": "USDC",\n  "amount": 25000\n}', { nonNullable: true })
  });

  // Route Form
  public readonly routeForm = new FormGroup({
    fromChain: new FormControl<string>('eth', { nonNullable: true }),
    toChain: new FormControl<string>('cosmos', { nonNullable: true }),
    amount: new FormControl<number>(50000, { nonNullable: true }),
    urgency: new FormControl<'ECONOMY' | 'BALANCED' | 'ULTRA_FAST' | 'CRITICAL_SECURITY'>('BALANCED', { nonNullable: true })
  });

  public readonly calculatedRoutes = signal<InterchainRoute[]>([]);

  // X-Call Form
  public readonly xcallForm = new FormGroup({
    sourceContract: new FormControl<string>('0x71C489A000000000000000000000000000002710', { nonNullable: true }),
    destContract: new FormControl<string>('cosmos1xyz48190348759328472938472938472938472', { nonNullable: true }),
    functionSignature: new FormControl<string>('rebalanceLiquidity(uint256,bytes32)', { nonNullable: true }),
    gasLimit: new FormControl<number>(350000, { nonNullable: true }),
    securityPolicy: new FormControl<string>('HIGH', { nonNullable: true })
  });

  constructor() {
    this.calculateRoutes();
    if (this.sim.messages().length > 0) {
      this.activeInspectedMessage.set(this.sim.messages()[0]);
    }
  }

  setTab(tab: ActiveTab) {
    this.currentTab.set(tab);
    this.sim.log(`[NAVIGATION] Switched workspace view to: ${tab}`);
  }

  inspectMessage(msg: InterchainMessage) {
    this.activeInspectedMessage.set(msg);
    this.currentTab.set('MESSAGES');
    this.sim.log(`[INSPECT_MSG] Loaded canonical message details for: ${msg.message_id}`);
  }

  onDispatchMessage() {
    const vals = this.messageForm.getRawValue();
    let payload = {};
    try {
      payload = JSON.parse(vals.payloadJson);
    } catch {
      payload = { raw: vals.payloadJson };
    }

    const msg = this.sim.dispatchMessage({
      sourceChain: vals.sourceChain,
      destChain: vals.destChain,
      messageType: vals.messageType,
      sender: '0xOperatorTom...489',
      recipient: '0xTargetProtocol...992',
      payloadData: payload,
      securityLevel: vals.securityLevel
    });

    this.activeInspectedMessage.set(msg);
  }

  calculateRoutes() {
    const v = this.routeForm.getRawValue();
    const routes = this.sim.calculateRoute(v.fromChain, v.toChain, 'USDC', v.amount, v.urgency);
    this.calculatedRoutes.set(routes);
    this.sim.log(`[ROUTE_ENGINE] Evaluated 3 candidate paths for ${v.fromChain} -> ${v.toChain}`);
  }

  selectAndExecuteRoute(route: InterchainRoute) {
    this.sim.initiateTransfer(
      route.source_chain,
      route.destination_chain,
      'USDC',
      this.routeForm.getRawValue().amount,
      '0xVaultManager',
      '0xDestinationRecipient'
    );
    this.currentTab.set('OVERVIEW');
  }

  triggerQuickTransfer() {
    this.sim.initiateTransfer('eth', 'cosmos', 'USDC', 10000, '0xInstantSettler', 'cosmos1recipient');
    this.sim.log('[QUICK_TRANSFER] Dispatched 10,000 USDC transfer from Ethereum to Cosmos Hub.');
  }

  onExecuteXCall() {
    const v = this.xcallForm.getRawValue();
    this.sim.dispatchMessage({
      sourceChain: 'eth',
      destChain: 'cosmos',
      messageType: 'CONTRACT_CALL',
      sender: v.sourceContract,
      recipient: v.destContract,
      payloadData: {
        function: v.functionSignature,
        gasLimit: v.gasLimit,
        securityPolicy: v.securityPolicy
      },
      securityLevel: 'HIGH'
    });
    this.currentTab.set('OVERVIEW');
  }
}
