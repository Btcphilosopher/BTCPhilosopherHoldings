import { ChangeDetectionStrategy, Component } from '@angular/core';
import { Header } from './components/header/header';
import { ControlCentre } from './components/control-centre/control-centre';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [Header, ControlCentre],
  template: `
    <div class="min-h-screen flex flex-col bg-[#0d0e12] text-[#F4F1E8]">
      <app-header />
      <app-control-centre class="flex-1" />
    </div>
  `
})
export class App {}

