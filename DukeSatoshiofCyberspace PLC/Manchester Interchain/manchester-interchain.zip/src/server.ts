import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());
const angularApp = new AngularNodeAppEngine();

/**
 * Enterprise Manchester Interchain REST API Endpoints (v1)
 */
app.get('/api/v1/network/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    fabric: 'Manchester Central Fabric (MIP-01)',
    health_score: 99.98,
    quorum_power_pct: 99.4,
    active_chains: 11,
    active_validators: 14,
    timestamp: new Date().toISOString()
  });
});

app.get('/api/v1/chains', (req, res) => {
  res.json({
    total: 11,
    networks: [
      { network_id: 'manchester', name: 'Manchester Central Fabric', chain_id: 'MANC-01', status: 'ONLINE', tps: 4250 },
      { network_id: 'eth', name: 'Ethereum Mainnet', chain_id: 1, status: 'ONLINE', tps: 18.4 },
      { network_id: 'btc', name: 'Bitcoin Core', chain_id: 'BTC-MAIN', status: 'ONLINE', tps: 7.2 },
      { network_id: 'sol', name: 'Solana Mainnet-Beta', chain_id: 'SOL-101', status: 'ONLINE', tps: 2840 },
      { network_id: 'cosmos', name: 'Cosmos Hub', chain_id: 'cosmoshub-4', status: 'ONLINE', tps: 110 },
      { network_id: 'avax', name: 'Avalanche C-Chain', chain_id: 43114, status: 'ONLINE', tps: 64 },
      { network_id: 'dot', name: 'Polkadot Relay Chain', chain_id: 'polkadot-relay', status: 'ONLINE', tps: 320 },
      { network_id: 'arb', name: 'Arbitrum One', chain_id: 42161, status: 'ONLINE', tps: 142.5 },
      { network_id: 'op', name: 'Optimism Mainnet', chain_id: 10, status: 'ONLINE', tps: 88.0 },
      { network_id: 'base', name: 'Base L2', chain_id: 8453, status: 'ONLINE', tps: 112.4 },
      { network_id: 'polygon', name: 'Polygon PoS', chain_id: 137, status: 'ONLINE', tps: 76.5 }
    ]
  });
});

app.post('/api/v1/routes/quote', (req, res) => {
  const { source_chain, destination_chain, asset, amount } = req.body || {};
  res.json({
    quote_id: `Q-${Date.now()}`,
    source_chain: source_chain || 'eth',
    destination_chain: destination_chain || 'cosmos',
    asset: asset || 'USDC',
    amount: amount || 10000,
    optimal_route: {
      route_type: 'DIRECT_FABRIC',
      hops: [source_chain || 'eth', 'Manchester Interchain Hub (MIP-01)', destination_chain || 'cosmos'],
      estimated_latency_ms: 38,
      fee_usd: 2.85,
      security_score: 98,
      finality_time_s: 1.2
    }
  });
});

app.post('/api/v1/messages', (req, res) => {
  const { source_chain, destination_chain, message_type } = req.body || {};
  const msgId = `MSG-MCR-${Math.random().toString(16).substring(2, 8).toUpperCase()}`;
  res.status(201).json({
    message_id: msgId,
    source_chain: source_chain || 'eth',
    destination_chain: destination_chain || 'cosmos',
    message_type: message_type || 'TRANSFER',
    status: 'CREATED',
    payload_hash: `0x${Math.random().toString(16).substring(2, 34)}`,
    timestamp: new Date().toISOString()
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);

