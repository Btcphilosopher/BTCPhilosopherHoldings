package com.example.atomic.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.atomic.ai.GeminiSettlementAssistant
import com.example.atomic.crypto.CryptoEngine
import com.example.atomic.data.InitialData
import com.example.atomic.data.local.*
import com.example.atomic.engine.*
import com.example.atomic.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

data class SwapUiState(
    val fromAsset: Asset = AssetRegistry.GBP_CBDC,
    val toAsset: Asset = AssetRegistry.USDC,
    val fromAmount: Double = 10_000_000.0, // Flagship £10m Demo
    val availableRoutes: List<ExecutionRoute> = emptyList(),
    val selectedRoute: ExecutionRoute? = null,
    val currentTransaction: AtomicTransaction? = null,
    val isExecuting: Boolean = false,
    val executionLogMessages: List<String> = emptyList(),
    val isSimulatingFailure: Boolean = false
)

data class OrderBookUiState(
    val selectedPair: String = "GBP-CBDC/USDC",
    val orderBook: OrderBook = OrderBook(
        pair = "GBP-CBDC/USDC",
        bids = listOf(
            LimitOrder("ORD-B1", "GBP-CBDC/USDC", OrderSide.BUY, 1.2852, 5_000_000.0, 6_426_000.0, "Citadel Securities", System.currentTimeMillis()),
            LimitOrder("ORD-B2", "GBP-CBDC/USDC", OrderSide.BUY, 1.2850, 8_000_000.0, 10_280_000.0, "Wintermute London", System.currentTimeMillis() - 12000),
            LimitOrder("ORD-B3", "GBP-CBDC/USDC", OrderSide.BUY, 1.2848, 12_500_000.0, 16_060_000.0, "Barclays Markets", System.currentTimeMillis() - 34000)
        ),
        asks = listOf(
            LimitOrder("ORD-A1", "GBP-CBDC/USDC", OrderSide.SELL, 1.2855, 6_200_000.0, 7_970_100.0, "Jane Street DLT", System.currentTimeMillis()),
            LimitOrder("ORD-A2", "GBP-CBDC/USDC", OrderSide.SELL, 1.2858, 9_400_000.0, 12_086_520.0, "Flow Traders", System.currentTimeMillis() - 8000),
            LimitOrder("ORD-A3", "GBP-CBDC/USDC", OrderSide.SELL, 1.2862, 15_000_000.0, 19_293_000.0, "Jump Trading Synthetic", System.currentTimeMillis() - 25000)
        ),
        spreadAbsolute = 0.0003,
        spreadBps = 2.33,
        midPrice = 1.28535,
        depth24hUsd = 62_450_000.0
    ),
    val activeRfqQuotes: List<RFQQuote> = emptyList(),
    val isRfqLoading: Boolean = false
)

data class ChatMessage(
    val sender: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isAi: Boolean
)

data class ApiConsoleState(
    val selectedEndpoint: String = "/api/v1/swaps/execute",
    val method: String = "POST",
    val requestBodyJson: String = "{\n  \"fromAsset\": \"GBP-CBDC\",\n  \"toAsset\": \"USDC\",\n  \"amount\": 10000000.0,\n  \"routeId\": \"ROUTE-DIR-UNIV-01\",\n  \"maxSlippageBps\": 5\n}",
    val responseStatus: String = "200 OK",
    val responseBodyJson: String = "",
    val isExecuting: Boolean = false
)

class AtomicViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AtomicDatabase.getInstance(application)
    private val txDao = db.transactionDao()
    private val poolDao = db.poolDao()
    private val auditDao = db.auditLogDao()

    // 1. Swap & Settlement State
    private val _swapState = MutableStateFlow(SwapUiState())
    val swapState: StateFlow<SwapUiState> = _swapState.asStateFlow()

    // 2. Pools State
    private val _pools = MutableStateFlow<List<LiquidityPool>>(InitialData.INITIAL_POOLS)
    val pools: StateFlow<List<LiquidityPool>> = _pools.asStateFlow()

    // 3. Order Book & RFQ Desk State
    private val _orderBookState = MutableStateFlow(OrderBookUiState())
    val orderBookState: StateFlow<OrderBookUiState> = _orderBookState.asStateFlow()

    // 4. Treasury State
    private val _treasuryHoldings = MutableStateFlow<List<TreasuryHolding>>(InitialData.INITIAL_TREASURY_HOLDINGS)
    val treasuryHoldings: StateFlow<List<TreasuryHolding>> = _treasuryHoldings.asStateFlow()

    private val _collateralPools = MutableStateFlow<List<CollateralPool>>(InitialData.INITIAL_COLLATERAL_POOLS)
    val collateralPools: StateFlow<List<CollateralPool>> = _collateralPools.asStateFlow()

    // 5. Stress Lab State
    private val _stressResult = MutableStateFlow<StressScenarioResult?>(null)
    val stressResult: StateFlow<StressScenarioResult?> = _stressResult.asStateFlow()

    // 6. Audit Logs & Proofs State
    private val _auditLogs = MutableStateFlow<List<AuditLogEntity>>(emptyList())
    val auditLogs: StateFlow<List<AuditLogEntity>> = _auditLogs.asStateFlow()

    private val _settledHistory = MutableStateFlow<List<AtomicTransaction>>(emptyList())
    val settledHistory: StateFlow<List<AtomicTransaction>> = _settledHistory.asStateFlow()

    // 7. AI Assistant Chat State
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = "AI Settlement Assistant",
                message = "[OBSERVED]: Manchester ATOMIC operational with £100M+ multi-asset liquidity.\n[CALCULATED]: Real-time PvP atomic guarantee verified across 8 networks.\nAsk me to analyze routes, compute impermanent loss, explain HashLock proofs, or diagnose stress scenarios.",
                isAi = true
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()
    val isAiThinking = MutableStateFlow(false)

    // 8. API Console State
    private val _apiConsoleState = MutableStateFlow(ApiConsoleState())
    val apiConsoleState: StateFlow<ApiConsoleState> = _apiConsoleState.asStateFlow()

    init {
        recalculateRoutes()
        loadInitialAuditLogs()
        refreshRfqQuotes()
    }

    private fun loadInitialAuditLogs() {
        val initialLogs = listOf(
            AuditLogEntity(
                timestamp = System.currentTimeMillis() - 180000,
                transactionId = "ATX-INIT-GENESIS",
                eventType = "FLAGSHIP_POOL_ANCHORED",
                description = "Manchester Universal Liquidity Pool reserves verified and multi-asset weights locked.",
                cryptographicProof = "0x" + CryptoEngine.sha256("GENESIS-POOL-MCR-UNIV-01"),
                operator = "Bank of England / FCA Sandbox Core"
            ),
            AuditLogEntity(
                timestamp = System.currentTimeMillis() - 90000,
                transactionId = "ATX-2026-0928-01",
                eventType = "ATOMIC_SWAP_FINALIZED",
                description = "Settled €5,000,000 EUR-CBDC against $5,425,000 USDC. Synchronous Dual Settlement confirmed.",
                cryptographicProof = "0x" + CryptoEngine.sha256("FINALITY|EUR-USDC|01"),
                operator = "Manchester Interchain Settlement Engine"
            )
        )
        _auditLogs.value = initialLogs
    }

    fun setFromAsset(asset: Asset) {
        _swapState.update { it.copy(fromAsset = asset) }
        recalculateRoutes()
    }

    fun setToAsset(asset: Asset) {
        _swapState.update { it.copy(toAsset = asset) }
        recalculateRoutes()
    }

    fun setFromAmount(amount: Double) {
        _swapState.update { it.copy(fromAmount = amount) }
        recalculateRoutes()
    }

    fun selectRoute(route: ExecutionRoute) {
        _swapState.update {
            it.copy(
                selectedRoute = route,
                currentTransaction = AtomicSwapEngine.createQuote(
                    fromAsset = it.fromAsset,
                    toAsset = it.toAsset,
                    fromAmount = it.fromAmount,
                    route = route
                )
            )
        }
    }

    fun toggleSimulateFailure(simulate: Boolean) {
        _swapState.update { it.copy(isSimulatingFailure = simulate) }
    }

    fun recalculateRoutes() {
        val current = _swapState.value
        val routes = LiquidityRouter.findBestRoutes(
            fromAsset = current.fromAsset,
            toAsset = current.toAsset,
            amountIn = current.fromAmount,
            availablePools = _pools.value
        )
        val selected = routes.firstOrNull()
        val tx = if (selected != null) {
            AtomicSwapEngine.createQuote(current.fromAsset, current.toAsset, current.fromAmount, selected)
        } else null

        _swapState.update {
            it.copy(
                availableRoutes = routes,
                selectedRoute = selected,
                currentTransaction = tx
            )
        }
    }

    fun executeActiveSwap() {
        val current = _swapState.value
        val tx = current.currentTransaction ?: return
        if (current.isExecuting) return

        _swapState.update {
            it.copy(
                isExecuting = true,
                executionLogMessages = listOf("Initiating Atomic Settlement Execution for ${tx.id}...")
            )
        }

        viewModelScope.launch(Dispatchers.Default) {
            val finalTx = AtomicSwapEngine.executeSwapStateTransitions(
                initialTx = tx,
                simulateFailure = current.isSimulatingFailure
            ) { stateUpdate, logMsg ->
                _swapState.update { s ->
                    s.copy(
                        currentTransaction = stateUpdate,
                        executionLogMessages = s.executionLogMessages + "[$ ${java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.UK).format(java.util.Date())}] $logMsg"
                    )
                }

                // Add to audit trail
                val log = AuditLogEntity(
                    timestamp = System.currentTimeMillis(),
                    transactionId = stateUpdate.id,
                    eventType = stateUpdate.state.name,
                    description = logMsg,
                    cryptographicProof = if (stateUpdate.proofHash.isNotBlank()) stateUpdate.proofHash else "0x" + stateUpdate.hashLockHex.take(32),
                    operator = "Manchester Interchain Settlement Engine"
                )
                _auditLogs.update { listOf(log) + it }
            }

            _swapState.update { it.copy(isExecuting = false, currentTransaction = finalTx) }
            if (finalTx.state == TransactionState.FINAL || finalTx.state == TransactionState.REFUNDED) {
                _settledHistory.update { listOf(finalTx) + it }

                // Update pool reserves if successful
                if (finalTx.state == TransactionState.FINAL && finalTx.route.poolIds.isNotEmpty()) {
                    updatePoolReservesAfterSwap(finalTx)
                }
            }
        }
    }

    private fun updatePoolReservesAfterSwap(tx: AtomicTransaction) {
        val poolId = tx.route.poolIds.firstOrNull() ?: return
        _pools.update { list ->
            list.map { pool ->
                if (pool.poolId == poolId) {
                    val updatedReserves = pool.assetReserves.toMutableMap()
                    val curIn = updatedReserves[tx.fromAssetSymbol] ?: 0.0
                    val curOut = updatedReserves[tx.toAssetSymbol] ?: 0.0
                    updatedReserves[tx.fromAssetSymbol] = curIn + tx.fromAmount
                    updatedReserves[tx.toAssetSymbol] = (curOut - tx.actualToAmount).coerceAtLeast(0.0)
                    pool.copy(
                        assetReserves = updatedReserves,
                        volume24hUsd = pool.volume24hUsd + (tx.fromAmount * AssetRegistry.getBySymbol(tx.fromAssetSymbol).referencePriceUsd),
                        fees24hUsd = pool.fees24hUsd + tx.route.feeUsd
                    )
                } else pool
            }
        }
    }

    fun refreshRfqQuotes() {
        val fromAsset = _swapState.value.fromAsset
        val toAsset = _swapState.value.toAsset
        val amount = _swapState.value.fromAmount
        val nominalRate = fromAsset.referencePriceUsd / toAsset.referencePriceUsd

        _orderBookState.update { it.copy(isRfqLoading = true) }

        viewModelScope.launch(Dispatchers.Default) {
            val quotes = InitialData.INITIAL_DEALERS.mapIndexed { idx, dealer ->
                val spreadBps = 1.5 + (idx * 0.8)
                val spreadMultiplier = 1.0 - (spreadBps / 10000.0)
                val rate = nominalRate * spreadMultiplier
                RFQQuote(
                    quoteId = "RFQ-${UUID.randomUUID().toString().take(6).uppercase()}",
                    dealerName = dealer,
                    dealerLei = "LEI-${98450000 + idx}",
                    fromAsset = fromAsset.symbol,
                    toAsset = toAsset.symbol,
                    fromAmount = amount,
                    quotedToAmount = amount * rate,
                    effectiveRate = rate,
                    spreadBps = spreadBps,
                    guaranteedUntilEpoch = System.currentTimeMillis() + 60_000L,
                    settlementMechanism = if (idx % 2 == 0) "Synchronous BoE/Fedwire RTGS PvP" else "Cross-Chain EVM/UTXO Atomic Escrow"
                )
            }
            _orderBookState.update { it.copy(activeRfqQuotes = quotes, isRfqLoading = false) }
        }
    }

    fun acceptRfqQuote(quote: RFQQuote) {
        val rfqRoute = ExecutionRoute(
            routeId = "ROUTE-RFQ-${quote.quoteId}",
            routeType = RouteType.RFQ_DEALER,
            description = "Bilateral RFQ Execution with ${quote.dealerName}",
            pathTokens = listOf(quote.fromAsset, quote.toAsset),
            poolIds = emptyList(),
            effectiveRate = quote.effectiveRate,
            priceImpactPercent = 0.005,
            feeUsd = quote.fromAmount * 0.00015,
            estimatedGasUsd = 0.50,
            estimatedFinalitySeconds = 0.4,
            atomicityScorePercent = 100,
            counterpartyOrPoolName = quote.dealerName
        )
        selectRoute(rfqRoute)
    }

    fun addLiquidityToPool(poolId: String, depositAmounts: Map<String, Double>) {
        _pools.update { list ->
            list.map { pool ->
                if (pool.poolId == poolId) {
                    val (updatedPool, shares) = PoolFactoryEngine.addLiquidity(pool, depositAmounts)
                    val log = AuditLogEntity(
                        timestamp = System.currentTimeMillis(),
                        transactionId = "LP-MINT-${shares.toLong()}",
                        eventType = "LIQUIDITY_DEPOSITED",
                        description = "Minted ${"%.2f".format(shares)} LP shares in ${pool.name}.",
                        cryptographicProof = "0x" + CryptoEngine.sha256("LP-MINT|$poolId|$shares"),
                        operator = "Manchester Treasury"
                    )
                    _auditLogs.update { listOf(log) + it }
                    updatedPool
                } else pool
            }
        }
    }

    fun removeLiquidityFromPool(poolId: String, sharesToBurn: Double) {
        _pools.update { list ->
            list.map { pool ->
                if (pool.poolId == poolId) {
                    val (updatedPool, withdrawn) = PoolFactoryEngine.removeLiquidity(pool, sharesToBurn)
                    val log = AuditLogEntity(
                        timestamp = System.currentTimeMillis(),
                        transactionId = "LP-BURN-${sharesToBurn.toLong()}",
                        eventType = "LIQUIDITY_WITHDRAWN",
                        description = "Burned ${"%.2f".format(sharesToBurn)} LP shares from ${pool.name}.",
                        cryptographicProof = "0x" + CryptoEngine.sha256("LP-BURN|$poolId|$sharesToBurn"),
                        operator = "Manchester Treasury"
                    )
                    _auditLogs.update { listOf(log) + it }
                    updatedPool
                } else pool
            }
        }
    }

    fun createNewPool(
        poolId: String,
        name: String,
        invariantType: InvariantType,
        reserves: Map<String, Double>,
        weights: Map<String, Double> = emptyMap(),
        amp: Double = 100.0,
        feeBps: Int = 5
    ) {
        val newPool = PoolFactoryEngine.createCustomPool(
            poolId = poolId,
            name = name,
            invariantType = invariantType,
            initialReserves = reserves,
            weights = weights,
            ampCoefficient = amp,
            feeBps = feeBps
        )
        _pools.update { listOf(newPool) + it }
        recalculateRoutes()

        val log = AuditLogEntity(
            timestamp = System.currentTimeMillis(),
            transactionId = "POOL-CREATE-$poolId",
            eventType = "POOL_FACTORY_DEPLOY",
            description = "Deployed institutional pool $name ($poolId) with ${invariantType.displayName}.",
            cryptographicProof = "0x" + CryptoEngine.sha256("FACTORY|$poolId"),
            operator = "Pool Factory Governance"
        )
        _auditLogs.update { listOf(log) + it }
    }

    fun runStressScenario(scenarioId: ScenarioId) {
        viewModelScope.launch(Dispatchers.Default) {
            val result = RiskStressEngine.runStressScenario(scenarioId) { progressResult ->
                _stressResult.value = progressResult
            }
            _stressResult.value = result

            val log = AuditLogEntity(
                timestamp = System.currentTimeMillis(),
                transactionId = "STRESS-${scenarioId.name}",
                eventType = "STRESS_LAB_EXECUTION",
                description = "Executed stress vector ${scenarioId.title}: ${result.atomicSafetyVerdict}",
                cryptographicProof = "0x" + CryptoEngine.sha256("STRESS|${scenarioId.name}"),
                operator = "Manchester Risk & Stress Engine"
            )
            _auditLogs.update { listOf(log) + it }
        }
    }

    fun rebalanceTreasury() {
        viewModelScope.launch(Dispatchers.Default) {
            _treasuryHoldings.update { list ->
                val totalNav = list.sumOf { it.usdValue }
                list.map { holding ->
                    val targetUsd = totalNav * holding.targetAllocationPct
                    val asset = AssetRegistry.getBySymbol(holding.assetSymbol)
                    val newTotal = targetUsd / asset.referencePriceUsd
                    holding.copy(
                        totalBalance = newTotal,
                        availableBalance = newTotal - holding.lockedInEscrow,
                        usdValue = targetUsd,
                        currentAllocationPct = holding.targetAllocationPct
                    )
                }
            }
            val log = AuditLogEntity(
                timestamp = System.currentTimeMillis(),
                transactionId = "TREASURY-REBAL-" + System.currentTimeMillis(),
                eventType = "TREASURY_REBALANCED",
                description = "Automated institutional portfolio rebalance executed across multi-currency holdings.",
                cryptographicProof = "0x" + CryptoEngine.sha256("REBALANCE|OK"),
                operator = "Manchester Treasury Core"
            )
            _auditLogs.update { listOf(log) + it }
        }
    }

    fun sendAiPrompt(prompt: String) {
        val userMsg = ChatMessage(sender = "Treasury Officer", message = prompt, isAi = false)
        _chatMessages.update { it + userMsg }
        isAiThinking.value = true

        viewModelScope.launch(Dispatchers.Default) {
            val contextJson = JSONObject().apply {
                put("flagshipTvlUsd", InitialData.FLAGSHIP_MANCHESTER_POOL.tvlUsd)
                put("activeFromAsset", _swapState.value.fromAsset.symbol)
                put("activeToAsset", _swapState.value.toAsset.symbol)
                put("activeAmount", _swapState.value.fromAmount)
                put("settledCount", _settledHistory.value.size)
                put("poolsCount", _pools.value.size)
            }.toString(2)

            val aiResponse = GeminiSettlementAssistant.analyzeQuery(prompt, contextJson)
            val aiMsg = ChatMessage(sender = "AI Settlement Assistant", message = aiResponse, isAi = true)
            _chatMessages.update { it + aiMsg }
            isAiThinking.value = false
        }
    }

    fun executeApiConsole(endpoint: String, method: String, requestJson: String) {
        _apiConsoleState.update { it.copy(isExecuting = true) }
        viewModelScope.launch(Dispatchers.Default) {
            val responseObj = JSONObject()
            when {
                endpoint.startsWith("/api/v1/swaps/quote") -> {
                    responseObj.put("status", "SUCCESS")
                    responseObj.put("quoteId", "QTE-${UUID.randomUUID().toString().take(8).uppercase()}")
                    responseObj.put("fromAsset", _swapState.value.fromAsset.symbol)
                    responseObj.put("toAsset", _swapState.value.toAsset.symbol)
                    responseObj.put("rate", _swapState.value.selectedRoute?.effectiveRate ?: 1.285)
                    responseObj.put("atomicityGuarantee", "HTLC-SHA256-SYNCHRONOUS")
                }
                endpoint.startsWith("/api/v1/pools") -> {
                    responseObj.put("status", "SUCCESS")
                    responseObj.put("poolsCount", _pools.value.size)
                    responseObj.put("flagshipTvlUsd", _pools.value.find { it.isFlagship }?.tvlUsd)
                }
                endpoint.startsWith("/api/v1/treasury") -> {
                    responseObj.put("status", "SUCCESS")
                    responseObj.put("totalNavUsd", _treasuryHoldings.value.sumOf { it.usdValue })
                    responseObj.put("collateralHealthScore", 98)
                }
                else -> {
                    responseObj.put("status", "EXECUTED")
                    responseObj.put("transactionId", "ATX-" + UUID.randomUUID().toString().take(8).uppercase())
                    responseObj.put("state", "FINAL")
                    responseObj.put("proofHash", "0x" + CryptoEngine.sha256("API_EXECUTION_TEST"))
                    responseObj.put("message", "Atomic conditions verified across networks. Either both settle or nothing settles.")
                }
            }

            _apiConsoleState.update {
                it.copy(
                    selectedEndpoint = endpoint,
                    method = method,
                    requestBodyJson = requestJson,
                    responseStatus = "200 OK",
                    responseBodyJson = responseObj.toString(2),
                    isExecuting = false
                )
            }
        }
    }
}
