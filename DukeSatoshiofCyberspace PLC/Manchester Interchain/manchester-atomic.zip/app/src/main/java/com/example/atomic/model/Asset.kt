package com.example.atomic.model

enum class AssetCategory(val displayName: String) {
    CBDC_SYNTHETIC("Synthetic CBDC"),
    STABLECOIN_REGULATED("Regulated Stablecoin"),
    CRYPTO_NATIVE("Crypto Native"),
    TOKENISED_DEPOSIT("Tokenised Deposit"),
    FIAT_BACKED("Fiat-Backed Token")
}

data class Asset(
    val symbol: String,
    val name: String,
    val category: AssetCategory,
    val networkId: String,
    val decimals: Int = 18,
    val referencePriceUsd: Double,
    val isSimulated: Boolean = true,
    val centralBankOrIssuer: String,
    val colorHex: Long = 0xFF38BDF8
)

object AssetRegistry {
    val GBP_CBDC = Asset(
        symbol = "GBP-CBDC",
        name = "Synthetic Digital Sterling",
        category = AssetCategory.CBDC_SYNTHETIC,
        networkId = "BOE-RTGS-CBDC",
        decimals = 2,
        referencePriceUsd = 1.2850,
        isSimulated = true,
        centralBankOrIssuer = "Bank of England (Simulated Core)",
        colorHex = 0xFF00E599
    )

    val USD_CBDC = Asset(
        symbol = "USD-CBDC",
        name = "Synthetic Digital Dollar",
        category = AssetCategory.CBDC_SYNTHETIC,
        networkId = "FED-RTGS-CBDC",
        decimals = 2,
        referencePriceUsd = 1.0000,
        isSimulated = true,
        centralBankOrIssuer = "Federal Reserve (Simulated Core)",
        colorHex = 0xFF38BDF8
    )

    val EUR_CBDC = Asset(
        symbol = "EUR-CBDC",
        name = "Synthetic Digital Euro",
        category = AssetCategory.CBDC_SYNTHETIC,
        networkId = "ECB-TIPS-CBDC",
        decimals = 2,
        referencePriceUsd = 1.0850,
        isSimulated = true,
        centralBankOrIssuer = "European Central Bank (Simulated TIPS)",
        colorHex = 0xFF818CF8
    )

    val JPY_CBDC = Asset(
        symbol = "JPY-CBDC",
        name = "Synthetic Digital Yen",
        category = AssetCategory.CBDC_SYNTHETIC,
        networkId = "BOJ-RTGS-CBDC",
        decimals = 0,
        referencePriceUsd = 0.0067,
        isSimulated = true,
        centralBankOrIssuer = "Bank of Japan (Simulated Core)",
        colorHex = 0xFFF43F5E
    )

    val CNY_CBDC = Asset(
        symbol = "CNY-CBDC",
        name = "Synthetic Digital Yuan (e-CNY)",
        category = AssetCategory.CBDC_SYNTHETIC,
        networkId = "PBOC-DC-CBDC",
        decimals = 2,
        referencePriceUsd = 0.1380,
        isSimulated = true,
        centralBankOrIssuer = "People's Bank of China (Simulated)",
        colorHex = 0xFFF59E0B
    )

    val BTC = Asset(
        symbol = "BTC",
        name = "Bitcoin (Native UTXO)",
        category = AssetCategory.CRYPTO_NATIVE,
        networkId = "BITCOIN-MAINNET",
        decimals = 8,
        referencePriceUsd = 68420.00,
        isSimulated = false,
        centralBankOrIssuer = "Decentralised Proof-of-Work",
        colorHex = 0xFFF7931A
    )

    val ETH = Asset(
        symbol = "ETH",
        name = "Ethereum (EVM Native)",
        category = AssetCategory.CRYPTO_NATIVE,
        networkId = "ETHEREUM-MAINNET",
        decimals = 18,
        referencePriceUsd = 3540.00,
        isSimulated = false,
        centralBankOrIssuer = "Decentralised Proof-of-Stake",
        colorHex = 0xFF627EEA
    )

    val USDC = Asset(
        symbol = "USDC",
        name = "USD Coin (Regulated Token)",
        category = AssetCategory.STABLECOIN_REGULATED,
        networkId = "ETHEREUM-MAINNET",
        decimals = 6,
        referencePriceUsd = 1.0000,
        isSimulated = false,
        centralBankOrIssuer = "Circle Internet Financial Ltd",
        colorHex = 0xFF2775CA
    )

    val USDT = Asset(
        symbol = "USDT",
        name = "Tether USD",
        category = AssetCategory.STABLECOIN_REGULATED,
        networkId = "ARBITRUM-ONE",
        decimals = 6,
        referencePriceUsd = 1.0002,
        isSimulated = false,
        centralBankOrIssuer = "Tether Limited",
        colorHex = 0xFF26A17B
    )

    val BARC_DEP = Asset(
        symbol = "BARC-DEP",
        name = "Barclays Tokenised Deposit GBP",
        category = AssetCategory.TOKENISED_DEPOSIT,
        networkId = "UK-TOKENISED-BANKING",
        decimals = 2,
        referencePriceUsd = 1.2850,
        isSimulated = true,
        centralBankOrIssuer = "Barclays Bank PLC Commercial Ledger",
        colorHex = 0xFF00AEEF
    )

    val HSBC_DEP = Asset(
        symbol = "HSBC-DEP",
        name = "HSBC Tokenised Deposit USD",
        category = AssetCategory.TOKENISED_DEPOSIT,
        networkId = "CANTON-CORDA-DLT",
        decimals = 2,
        referencePriceUsd = 1.0000,
        isSimulated = true,
        centralBankOrIssuer = "HSBC Institutional DLT",
        colorHex = 0xFFDB0011
    )

    val ALL_ASSETS = listOf(
        GBP_CBDC, USD_CBDC, EUR_CBDC, JPY_CBDC, CNY_CBDC,
        BTC, ETH, USDC, USDT, BARC_DEP, HSBC_DEP
    )

    fun getBySymbol(symbol: String): Asset {
        return ALL_ASSETS.find { it.symbol.equals(symbol, ignoreCase = true) } ?: GBP_CBDC
    }
}
