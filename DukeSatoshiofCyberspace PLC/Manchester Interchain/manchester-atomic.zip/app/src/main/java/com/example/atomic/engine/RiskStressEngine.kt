package com.example.atomic.engine

import com.example.atomic.model.*
import kotlinx.coroutines.delay

object RiskStressEngine {

    suspend fun runStressScenario(
        scenarioId: ScenarioId,
        onProgress: suspend (StressScenarioResult) -> Unit
    ): StressScenarioResult {
        var progress = 0
        var currentResult = StressScenarioResult(
            scenarioId = scenarioId,
            isRunning = true,
            progressPercent = 0,
            atomicSafetyVerdict = "INITIALISING SIMULATION INJECTION...",
            fundsAtRiskUsd = 45_000_000.0,
            fundsPreservedUsd = 0.0,
            rolledBackTransactionsCount = 0,
            settledTransactionsCount = 0,
            maxSlippageObservedPct = 0.0,
            explanation = "Injecting stress vectors into synthetic interchain nodes..."
        )
        onProgress(currentResult)
        delay(400)

        when (scenarioId) {
            ScenarioId.BOE_CBDC_RTGS_HALT -> {
                progress = 30
                currentResult = currentResult.copy(
                    progressPercent = progress,
                    atomicSafetyVerdict = "NODE DISCONNECTED: BOE-RTGS-01 UNRESPONSIVE",
                    explanation = "Leg 1 (GBP-CBDC) locked. Leg 2 (USDC) pending witness confirmation. Timer ticking (120s)."
                )
                onProgress(currentResult)
                delay(600)

                progress = 75
                currentResult = currentResult.copy(
                    progressPercent = progress,
                    atomicSafetyVerdict = "TIMELOCK EXPIRED → AUTO ROLLBACK TRIGGERED",
                    explanation = "Preimage never revealed. Both escrow contracts executing deterministic refund path."
                )
                onProgress(currentResult)
                delay(600)

                progress = 100
                currentResult = currentResult.copy(
                    isRunning = false,
                    progressPercent = 100,
                    atomicSafetyVerdict = "100% PRINCIPAL PRESERVED (ZERO SETTLEMENT LOSS)",
                    fundsAtRiskUsd = 0.0,
                    fundsPreservedUsd = 45_000_000.0,
                    rolledBackTransactionsCount = 14,
                    settledTransactionsCount = 0,
                    maxSlippageObservedPct = 0.0,
                    explanation = "ATOMIC GUARANTEE PROVEN: Because Leg 2 failed to verify within the cryptographic deadline, Leg 1 was completely refunded. No partial settlement occurred."
                )
                onProgress(currentResult)
            }

            ScenarioId.STABLECOIN_USDC_DEPEG -> {
                progress = 40
                currentResult = currentResult.copy(
                    progressPercent = progress,
                    atomicSafetyVerdict = "ORACLE DEVIATION: USDC SPOT = $0.8800 (-12%)",
                    explanation = "StableSwap amplification curves adapting. Routing engine rerouting flow to pure CBDC direct paths."
                )
                onProgress(currentResult)
                delay(600)

                progress = 100
                currentResult = currentResult.copy(
                    isRunning = false,
                    progressPercent = 100,
                    atomicSafetyVerdict = "CIRCUIT BREAKER ACTIVATED & ROUTING REROUTED",
                    fundsAtRiskUsd = 0.0,
                    fundsPreservedUsd = 88_500_000.0,
                    rolledBackTransactionsCount = 4,
                    settledTransactionsCount = 28,
                    maxSlippageObservedPct = 0.45,
                    explanation = "Manchester ATOMIC detected >3% oracle divergence and restricted USDC pool deposits while maintaining atomic settlement integrity across unaffected CBDC corridors."
                )
                onProgress(currentResult)
            }

            ScenarioId.BTC_FLASH_CRASH_40 -> {
                progress = 50
                currentResult = currentResult.copy(
                    progressPercent = progress,
                    atomicSafetyVerdict = "VOLATILITY SPIKE: BTC -40% ($41,050 USD)",
                    explanation = "Collateral haircut dynamically widened to 45%. Margin calls triggered deterministically."
                )
                onProgress(currentResult)
                delay(600)

                progress = 100
                currentResult = currentResult.copy(
                    isRunning = false,
                    progressPercent = 100,
                    atomicSafetyVerdict = "COLLATERAL SOLVENCY MAINTAINED (HEALTH: 94%)",
                    fundsAtRiskUsd = 0.0,
                    fundsPreservedUsd = 120_000_000.0,
                    rolledBackTransactionsCount = 2,
                    settledTransactionsCount = 45,
                    maxSlippageObservedPct = 1.15,
                    explanation = "Crypto collateral buffers absorbed the volatility shock without impairing settlement liquidity in the flagship Manchester Universal Pool."
                )
                onProgress(currentResult)
            }

            else -> {
                progress = 100
                currentResult = currentResult.copy(
                    isRunning = false,
                    progressPercent = 100,
                    atomicSafetyVerdict = "STRESS TEST COMPLETE: ATOMIC INVARIANTS SATISFIED",
                    fundsAtRiskUsd = 0.0,
                    fundsPreservedUsd = 50_000_000.0,
                    rolledBackTransactionsCount = 1,
                    settledTransactionsCount = 19,
                    maxSlippageObservedPct = 0.08,
                    explanation = "All cryptographic commitments and hashlock time constraints performed according to formal verification specification."
                )
                onProgress(currentResult)
            }
        }

        return currentResult
    }
}
