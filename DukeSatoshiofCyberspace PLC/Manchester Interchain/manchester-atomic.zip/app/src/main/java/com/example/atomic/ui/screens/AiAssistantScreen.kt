package com.example.atomic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.atomic.viewmodel.AtomicViewModel
import com.example.atomic.viewmodel.ChatMessage
import com.example.ui.theme.*

@Composable
fun AiAssistantScreen(
    viewModel: AtomicViewModel,
    modifier: Modifier = Modifier
) {
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isThinking by viewModel.isAiThinking.collectAsState()

    var inputPrompt by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AtomicBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = AtomicSurfaceElevated),
            shape = RoundedCornerShape(12.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorder))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = AtomicGreen, modifier = Modifier.size(18.dp))
                        Text(
                            text = "AI ATOMIC SETTLEMENT ASSISTANT",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = AtomicTextPrimary
                        )
                    }
                    Text(
                        text = "Powered by Gemini 3.5 Flash | Strict Institutional Fact-Tagging",
                        style = MaterialTheme.typography.bodySmall,
                        color = AtomicTextSecondary
                    )
                }
            }
        }

        // Quick Suggestion Pills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            QuickPill("Explain £10M Route", modifier = Modifier.weight(1f)) {
                viewModel.sendAiPrompt("Explain the optimal routing and price impact for the £10,000,000 GBP-CBDC to USDC transaction.")
            }
            QuickPill("Audit HashLock Safety", modifier = Modifier.weight(1f)) {
                viewModel.sendAiPrompt("Audit the SHA-256 HashLock and timelock refund mechanism during cross-chain network interruptions.")
            }
            QuickPill("Compare Invariants", modifier = Modifier.weight(1f)) {
                viewModel.sendAiPrompt("Compare the mathematical slippage of StableSwap vs Constant Product for CBDC lot trades.")
            }
        }

        // Chat Message Feed
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(chatMessages) { msg ->
                MessageBubble(message = msg)
            }

            if (isThinking) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = AtomicGreen, strokeWidth = 2.dp)
                        Text(
                            text = "Computing mathematical and cryptographic proof breakdown...",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = AtomicTextMuted
                        )
                    }
                }
            }
        }

        // Prompt Input Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputPrompt,
                onValueChange = { inputPrompt = it },
                placeholder = { Text("Ask about atomic routes, proofs, risk or invariants...", fontSize = 11.sp, color = AtomicTextMuted) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_assistant_prompt_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = AtomicNavyDark,
                    unfocusedContainerColor = AtomicNavyDark,
                    focusedBorderColor = AtomicGreen,
                    focusedTextColor = AtomicTextPrimary,
                    unfocusedTextColor = AtomicTextPrimary
                ),
                shape = RoundedCornerShape(8.dp)
            )

            IconButton(
                onClick = {
                    if (inputPrompt.isNotBlank()) {
                        viewModel.sendAiPrompt(inputPrompt)
                        inputPrompt = ""
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(AtomicGreen)
                    .testTag("send_ai_prompt_button")
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = Color.Black)
            }
        }
    }
}

@Composable
private fun QuickPill(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(AtomicSurfaceElevated)
            .border(1.dp, AtomicBorderSubtle, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            color = AtomicBlueLight,
            maxLines = 1
        )
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val containerColor = if (message.isAi) AtomicSurfaceElevated else AtomicNavyDark
    val borderColor = if (message.isAi) AtomicBorder else AtomicBorderSubtle

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        shape = RoundedCornerShape(10.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(borderColor))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = message.sender,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = if (message.isAi) AtomicGreen else AtomicBlue
                )
            }

            Text(
                text = message.message,
                fontSize = 12.sp,
                color = AtomicTextPrimary,
                lineHeight = 18.sp
            )
        }
    }
}
