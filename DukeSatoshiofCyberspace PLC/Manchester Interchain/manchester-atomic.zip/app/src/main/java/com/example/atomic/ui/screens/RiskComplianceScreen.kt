package com.example.atomic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.atomic.model.InstitutionalComplianceState
import com.example.ui.theme.*

@Composable
fun RiskComplianceScreen(
    modifier: Modifier = Modifier
) {
    val compliance = InstitutionalComplianceState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AtomicBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AtomicSurfaceElevated),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorder))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(imageVector = Icons.Default.Policy, contentDescription = null, tint = AtomicBlue, modifier = Modifier.size(20.dp))
                            Text(
                                text = "RISK & COMPLIANCE MATRIX",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = AtomicTextPrimary
                            )
                        }
                        Text(
                            text = "G-SIFI Travel Rule, Sanctions Screening & Quantitative Risk",
                            style = MaterialTheme.typography.bodySmall,
                            color = AtomicTextSecondary
                        )
                    }
                }
            }
        }

        // Quantitative Risk Metrics Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AtomicSurfaceCard),
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorderSubtle))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "QUANTITATIVE RISK INDICATORS",
                        style = MaterialTheme.typography.titleSmall,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = AtomicTextPrimary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        RiskBox(label = "VaR (99% 1-Day)", value = "$1,420,000", color = AtomicAmber)
                        RiskBox(label = "Expected Shortfall", value = "$1,885,000", color = AtomicRed)
                        RiskBox(label = "Settlement Risk", value = "0.00% (Atomic)", color = AtomicGreen)
                    }
                }
            }
        }

        // Compliance Entity Profile Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AtomicNavyDark),
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorderSubtle))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "INSTITUTIONAL REGULATORY PROFILE",
                        style = MaterialTheme.typography.titleSmall,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = AtomicGreen
                    )

                    ComplianceItem(label = "Participant Entity", value = compliance.entityName)
                    ComplianceItem(label = "LEI Identification", value = compliance.leiCode)
                    ComplianceItem(label = "Jurisdiction Sandbox", value = compliance.jurisdiction)
                    ComplianceItem(label = "Regulatory Tier", value = compliance.tier.label)
                    ComplianceItem(label = "Sanctions Screening", value = compliance.sanctionsScreeningStatus, valueColor = AtomicGreen)
                    ComplianceItem(label = "Travel Rule Protocol", value = compliance.travelRuleExchangeProtocol)
                    ComplianceItem(label = "Daily Authorized Limit", value = "$${"%,.0f".format(compliance.dailyLimitUsd)} USD")
                    ComplianceItem(label = "Daily Utilised Turnover", value = "$${"%,.0f".format(compliance.dailyTurnoverUsd)} USD", valueColor = AtomicBlueLight)
                }
            }
        }
    }
}

@Composable
private fun RiskBox(label: String, value: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(AtomicNavyDark)
            .padding(10.dp)
    ) {
        Column {
            Text(text = label, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AtomicTextSecondary)
            Text(text = value, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
private fun ComplianceItem(label: String, value: String, valueColor: Color = AtomicTextPrimary) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = AtomicTextSecondary)
        Text(text = value, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = valueColor)
    }
}
