package com.example.atomic.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.atomic.model.LimitOrder
import com.example.atomic.model.OrderBook
import com.example.ui.theme.*

@Composable
fun OrderBookLadder(
    orderBook: OrderBook,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(AtomicNavyDark)
            .border(1.dp, AtomicBorder, RoundedCornerShape(10.dp))
            .padding(12.dp)
            .testTag("order_book_ladder")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ORDER BOOK DEPTH (${orderBook.pair})",
                    style = MaterialTheme.typography.titleSmall,
                    fontSize = 11.sp,
                    color = AtomicTextSecondary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Spread: ${"%.4f".format(orderBook.spreadAbsolute)} (${orderBook.spreadBps} bps)",
                    fontSize = 10.sp,
                    color = AtomicBlue,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Headers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "PRICE (USD)", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AtomicTextMuted)
                Text(text = "SIZE", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AtomicTextMuted)
                Text(text = "PARTICIPANT / DEALER", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AtomicTextMuted)
            }

            // Asks (Sells)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                orderBook.asks.take(3).reversed().forEach { ask ->
                    OrderRow(order = ask, isBuy = false)
                }
            }

            // Mid Market Spread Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(AtomicSurfaceElevated)
                    .padding(vertical = 4.dp, horizontal = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MID-MARKET BENCHMARK: ${"%.5f".format(orderBook.midPrice)}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = AtomicTextPrimary
                    )
                    Text(
                        text = "Depth: $${"%,.0f".format(orderBook.depth24hUsd)}",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = AtomicTextSecondary
                    )
                }
            }

            // Bids (Buys)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                orderBook.bids.take(3).forEach { bid ->
                    OrderRow(order = bid, isBuy = true)
                }
            }
        }
    }
}

@Composable
private fun OrderRow(order: LimitOrder, isBuy: Boolean) {
    val priceColor = if (isBuy) AtomicGreen else AtomicRed
    val depthFraction = (order.amount / 15_000_000.0).coerceIn(0.1, 1.0)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(24.dp)
    ) {
        // Background depth fill
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(depthFraction.toFloat())
                .clip(RoundedCornerShape(3.dp))
                .background(if (isBuy) AtomicGreenDim.copy(alpha = 0.35f) else AtomicRedDim.copy(alpha = 0.35f))
                .align(Alignment.CenterStart)
        )

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "%.4f".format(order.price),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = priceColor
            )
            Text(
                text = "${"%,.0f".format(order.amount)}",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = AtomicTextPrimary
            )
            Text(
                text = order.participant,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = AtomicTextSecondary,
                maxLines = 1
            )
        }
    }
}
