package com.example.atomic.crypto

import java.security.MessageDigest
import java.security.SecureRandom

object CryptoEngine {
    private val secureRandom = SecureRandom()

    fun generatePreimage(): String {
        val bytes = ByteArray(32)
        secureRandom.nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun sha256(hexInput: String): String {
        val bytes = try {
            if (hexInput.length % 2 == 0 && hexInput.matches(Regex("^[0-9a-fA-F]+$"))) {
                hexStringToByteArray(hexInput)
            } else {
                hexInput.toByteArray(Charsets.UTF_8)
            }
        } catch (e: Exception) {
            hexInput.toByteArray(Charsets.UTF_8)
        }
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(bytes)
        return hash.joinToString("") { "%02x".format(it) }
    }

    fun verifyPreimage(preimageHex: String, hashLockHex: String): Boolean {
        if (preimageHex.isBlank() || hashLockHex.isBlank()) return false
        val computed = sha256(preimageHex)
        return computed.equals(hashLockHex, ignoreCase = true)
    }

    fun computeMerkleRoot(leaves: List<String>): String {
        if (leaves.isEmpty()) return sha256("EMPTY_TREE")
        var currentLevel = leaves.map { if (it.length == 64) it else sha256(it) }
        while (currentLevel.size > 1) {
            val nextLevel = mutableListOf<String>()
            for (i in 0 until currentLevel.size step 2) {
                if (i + 1 < currentLevel.size) {
                    val combined = currentLevel[i] + currentLevel[i + 1]
                    nextLevel.add(sha256(combined))
                } else {
                    val combined = currentLevel[i] + currentLevel[i]
                    nextLevel.add(sha256(combined))
                }
            }
            currentLevel = nextLevel
        }
        return currentLevel.first()
    }

    fun generateDeterministicTxHash(
        txId: String,
        legIndex: Int,
        asset: String,
        amount: Double,
        nonce: Long
    ): String {
        val payload = "MANCHESTER-ATOMIC|$txId|$legIndex|$asset|$amount|$nonce"
        return "0x" + sha256(payload)
    }

    fun generateValidatorSignature(txHash: String, validatorId: String): String {
        val payload = "SIG|$validatorId|$txHash"
        return "0x" + sha256(payload).take(32) + sha256(payload.reversed()).take(32)
    }

    private fun hexStringToByteArray(s: String): ByteArray {
        val len = s.length
        val data = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            data[i / 2] = ((Character.digit(s[i], 16) shl 4) + Character.digit(s[i + 1], 16)).toByte()
            i += 2
        }
        return data
    }
}
