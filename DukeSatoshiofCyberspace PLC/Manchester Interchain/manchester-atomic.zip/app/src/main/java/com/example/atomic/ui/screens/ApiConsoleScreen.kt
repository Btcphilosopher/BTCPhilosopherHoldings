package com.example.atomic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.atomic.viewmodel.AtomicViewModel
import com.example.ui.theme.*

@Composable
fun ApiConsoleScreen(
    viewModel: AtomicViewModel,
    modifier: Modifier = Modifier
) {
    val apiState by viewModel.apiConsoleState.collectAsState()

    var selectedEndpoint by remember { mutableStateOf(apiState.selectedEndpoint) }
    var method by remember { mutableStateOf(apiState.method) }
    var requestJson by remember { mutableStateOf(apiState.requestBodyJson) }

    val endpoints = listOf(
        Pair("POST", "/api/v1/swaps/execute"),
        Pair("GET", "/api/v1/swaps/quote"),
        Pair("GET", "/api/v1/pools"),
        Pair("GET", "/api/v1/treasury"),
        Pair("GET", "/api/v1/settlement/proof")
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AtomicBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AtomicSurfaceElevated),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorder))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(imageVector = Icons.Default.Code, contentDescription = null, tint = AtomicGreen, modifier = Modifier.size(20.dp))
                            Text(
                                text = "DEVELOPER REST & WEBSOCKET API",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = AtomicTextPrimary
                            )
                        }
                        Text(
                            text = "Interactive Institutional Endpoint Test Bench",
                            style = MaterialTheme.typography.bodySmall,
                            color = AtomicTextSecondary
                        )
                    }
                }
            }
        }

        // Endpoint Selector Pills
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "SELECT REST ENDPOINT:",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicTextMuted
                )
                endpoints.forEach { (m, ep) ->
                    val isSelected = selectedEndpoint == ep
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) AtomicNavyDark else AtomicSurfaceCard)
                            .border(1.dp, if (isSelected) AtomicGreen else AtomicBorderSubtle, RoundedCornerShape(6.dp))
                            .clickable {
                                selectedEndpoint = ep
                                method = m
                                if (ep.contains("quote")) {
                                    requestJson = "{\n  \"fromAsset\": \"GBP-CBDC\",\n  \"toAsset\": \"USDC\",\n  \"amount\": 10000000.0\n}"
                                } else if (ep.contains("execute")) {
                                    requestJson = "{\n  \"fromAsset\": \"GBP-CBDC\",\n  \"toAsset\": \"USDC\",\n  \"amount\": 10000000.0,\n  \"routeId\": \"ROUTE-DIR-UNIV-01\"\n}"
                                } else {
                                    requestJson = "{}"
                                }
                            }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (m == "POST") AtomicGreenDim else AtomicBlueDim)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(text = m, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = if (m == "POST") AtomicGreenLight else AtomicBlueLight)
                            }
                            Text(text = ep, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = AtomicTextPrimary)
                        }

                        if (isSelected) {
                            Text(text = "SELECTED", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AtomicGreen)
                        }
                    }
                }
            }
        }

        // Request Body Editor
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AtomicNavyDark),
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorder))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "HTTP REQUEST PAYLOAD (JSON):",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = AtomicTextSecondary
                    )

                    OutlinedTextField(
                        value = requestJson,
                        onValueChange = { requestJson = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .testTag("api_request_json_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = AtomicBackground,
                            unfocusedContainerColor = AtomicBackground,
                            focusedBorderColor = AtomicBlue,
                            focusedTextColor = AtomicTextPrimary,
                            unfocusedTextColor = AtomicTextPrimary
                        ),
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                    )

                    Button(
                        onClick = { viewModel.executeApiConsole(selectedEndpoint, method, requestJson) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp)
                            .testTag("execute_api_console_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = AtomicGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        if (apiState.isExecuting) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black, strokeWidth = 2.dp)
                        } else {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "EXECUTE $method REQUEST", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Response Body
        if (apiState.responseBodyJson.isNotBlank()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AtomicNavyDark),
                    shape = RoundedCornerShape(10.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicGreen))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "HTTP RESPONSE [${apiState.responseStatus}]:",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = AtomicGreen
                            )
                            Text(
                                text = "Latency: 24ms",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = AtomicTextMuted
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(AtomicBackground)
                                .padding(10.dp)
                        ) {
                            Text(
                                text = apiState.responseBodyJson,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = AtomicGreenLight
                            )
                        }
                    }
                }
            }
        }
    }
}
