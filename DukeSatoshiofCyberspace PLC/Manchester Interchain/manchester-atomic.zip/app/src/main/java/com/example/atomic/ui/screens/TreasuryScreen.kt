package com.example.atomic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.atomic.model.CollateralPool
import com.example.atomic.model.TreasuryHolding
import com.example.atomic.viewmodel.AtomicViewModel
import com.example.ui.theme.*

@Composable
fun TreasuryScreen(
    viewModel: AtomicViewModel,
    modifier: Modifier = Modifier
) {
    val treasuryHoldings by viewModel.treasuryHoldings.collectAsState()
    val collateralPools by viewModel.collateralPools.collectAsState()

    val totalNavUsd = treasuryHoldings.sumOf { it.usdValue }
    val totalLockedUsd = treasuryHoldings.sumOf { (it.lockedInEscrow / it.totalBalance.coerceAtLeast(1.0)) * it.usdValue }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AtomicBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AtomicSurfaceElevated),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorder))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(imageVector = Icons.Default.AccountBalance, contentDescription = null, tint = AtomicGreen, modifier = Modifier.size(20.dp))
                            Text(
                                text = "INSTITUTIONAL TREASURY",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = AtomicTextPrimary
                            )
                        }

                        Button(
                            onClick = { viewModel.rebalanceTreasury() },
                            colors = ButtonDefaults.buttonColors(containerColor = AtomicBlue, contentColor = Color.Black),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("auto_rebalance_button")
                        ) {
                            Icon(imageVector = Icons.Default.AutoMode, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("AUTO REBALANCE", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "TOTAL NAV (USD)", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AtomicTextSecondary)
                            Text(text = "$${"%,.2f".format(totalNavUsd)}", fontSize = 18.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AtomicGreen)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "LOCKED IN ESCROW", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AtomicTextSecondary)
                            Text(text = "$${"%,.2f".format(totalLockedUsd)}", fontSize = 14.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AtomicAmber)
                        }
                    }
                }
            }
        }

        // Multi-Currency Holdings
        item {
            Text(
                text = "MULTI-CURRENCY WORKING CAPITAL & RESERVES:",
                style = MaterialTheme.typography.titleSmall,
                fontSize = 11.sp,
                color = AtomicTextSecondary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(treasuryHoldings) { holding ->
            HoldingCard(holding = holding)
        }

        // Collateral Pools & Haircuts
        item {
            Text(
                text = "COLLATERAL POOLS & REGULATORY HAIRCUTS:",
                style = MaterialTheme.typography.titleSmall,
                fontSize = 11.sp,
                color = AtomicTextSecondary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(collateralPools) { pool ->
            CollateralCard(pool = pool)
        }
    }
}

@Composable
private fun HoldingCard(holding: TreasuryHolding) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AtomicSurfaceCard),
        shape = RoundedCornerShape(8.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorderSubtle))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = holding.assetSymbol, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AtomicTextPrimary)
                Text(text = "$${"%,.2f".format(holding.usdValue)} USD", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AtomicGreen)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Total: ${"%,.2f".format(holding.totalBalance)} | Avail: ${"%,.2f".format(holding.availableBalance)}",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicTextSecondary
                )
                Text(
                    text = "Target: ${"%.1f".format(holding.targetAllocationPct * 100)}% (Cur: ${"%.1f".format(holding.currentAllocationPct * 100)}%)",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicBlueLight
                )
            }
        }
    }
}

@Composable
private fun CollateralCard(pool: CollateralPool) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AtomicNavyDark),
        shape = RoundedCornerShape(8.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorderSubtle))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = AtomicGreen, modifier = Modifier.size(14.dp))
                    Text(text = "${pool.collateralAssetSymbol} Collateral", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AtomicTextPrimary)
                }
                Text(
                    text = "Haircut: ${pool.haircutPercent}% | Max LTV: ${pool.maxLtvPercent}%",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicTextSecondary
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(text = "Effective Value", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AtomicTextMuted)
                Text(text = "$${"%,.2f".format(pool.effectiveCollateralValueUsd)}", fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AtomicGreen)
            }
        }
    }
}
