package com.example.atomic.engine

import com.example.atomic.model.*
import kotlin.math.sqrt

object PoolFactoryEngine {

    fun createCustomPool(
        poolId: String,
        name: String,
        invariantType: InvariantType,
        initialReserves: Map<String, Double>,
        weights: Map<String, Double> = emptyMap(),
        ampCoefficient: Double = 100.0,
        feeBps: Int = 5
    ): LiquidityPool {
        var totalTvl = 0.0
        for ((symbol, amount) in initialReserves) {
            val asset = AssetRegistry.getBySymbol(symbol)
            totalTvl += amount * asset.referencePriceUsd
        }
        val initialLpSupply = totalTvl

        return LiquidityPool(
            poolId = poolId,
            name = name,
            invariantType = invariantType,
            assetReserves = initialReserves,
            assetWeights = weights,
            ampCoefficient = ampCoefficient,
            feeBps = feeBps,
            tvlUsd = totalTvl,
            volume24hUsd = 0.0,
            fees24hUsd = 0.0,
            lpTokenTotalSupply = initialLpSupply,
            userLpShares = initialLpSupply, // Creator owns initial shares
            navPerShareUsd = 1.00,
            poolHealthScore = 100,
            minDepositUsd = 10_000.0
        )
    }

    fun addLiquidity(
        pool: LiquidityPool,
        depositAmounts: Map<String, Double>
    ): Pair<LiquidityPool, Double> {
        var depositValueUsd = 0.0
        val newReserves = pool.assetReserves.toMutableMap()

        for ((symbol, amount) in depositAmounts) {
            val asset = AssetRegistry.getBySymbol(symbol)
            depositValueUsd += amount * asset.referencePriceUsd
            val current = newReserves[symbol] ?: 0.0
            newReserves[symbol] = current + amount
        }

        val sharesMinted = if (pool.tvlUsd > 0 && pool.lpTokenTotalSupply > 0) {
            (depositValueUsd / pool.tvlUsd) * pool.lpTokenTotalSupply
        } else {
            depositValueUsd
        }

        val newTotalSupply = pool.lpTokenTotalSupply + sharesMinted
        val newTvl = pool.tvlUsd + depositValueUsd
        val newUserShares = pool.userLpShares + sharesMinted
        val newNav = if (newTotalSupply > 0) newTvl / newTotalSupply else 1.00

        val updatedPool = pool.copy(
            assetReserves = newReserves,
            tvlUsd = newTvl,
            lpTokenTotalSupply = newTotalSupply,
            userLpShares = newUserShares,
            navPerShareUsd = newNav
        )

        return Pair(updatedPool, sharesMinted)
    }

    fun removeLiquidity(
        pool: LiquidityPool,
        sharesToBurn: Double
    ): Pair<LiquidityPool, Map<String, Double>> {
        val burnRatio = (sharesToBurn / pool.lpTokenTotalSupply).coerceIn(0.0, 1.0)
        val withdrawnAmounts = mutableMapOf<String, Double>()
        val newReserves = pool.assetReserves.toMutableMap()
        var totalWithdrawnUsd = 0.0

        for ((symbol, reserve) in pool.assetReserves) {
            val amountOut = reserve * burnRatio
            withdrawnAmounts[symbol] = amountOut
            newReserves[symbol] = (reserve - amountOut).coerceAtLeast(0.0)
            val asset = AssetRegistry.getBySymbol(symbol)
            totalWithdrawnUsd += amountOut * asset.referencePriceUsd
        }

        val newTotalSupply = (pool.lpTokenTotalSupply - sharesToBurn).coerceAtLeast(1.0)
        val newTvl = (pool.tvlUsd - totalWithdrawnUsd).coerceAtLeast(0.0)
        val newUserShares = (pool.userLpShares - sharesToBurn).coerceAtLeast(0.0)
        val newNav = if (newTotalSupply > 0) newTvl / newTotalSupply else 1.00

        val updatedPool = pool.copy(
            assetReserves = newReserves,
            tvlUsd = newTvl,
            lpTokenTotalSupply = newTotalSupply,
            userLpShares = newUserShares,
            navPerShareUsd = newNav
        )

        return Pair(updatedPool, withdrawnAmounts)
    }

    fun calculateImpermanentLossPercent(priceRatioChange: Double): Double {
        if (priceRatioChange <= 0.0) return 0.0
        val k = priceRatioChange
        val il = (2.0 * sqrt(k) / (1.0 + k)) - 1.0
        return il * 100.0 // negative percentage
    }
}
