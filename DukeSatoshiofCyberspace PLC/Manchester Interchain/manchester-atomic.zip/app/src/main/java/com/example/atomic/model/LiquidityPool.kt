package com.example.atomic.model

enum class InvariantType(val displayName: String, val formulaDescription: String) {
    CONSTANT_PRODUCT("Constant Product AMM", "x * y = k"),
    STABLE_SWAP("StableSwap Invariant", "A * n^n * sum(x_i) + D = A * D * n^n + D^(n+1)/(n^n * prod(x_i))"),
    WEIGHTED_MULTI_ASSET("Multi-Asset Weighted Pool", "prod(B_i ^ w_i) = k")
}

data class LiquidityPool(
    val poolId: String,
    val name: String,
    val invariantType: InvariantType,
    val assetReserves: Map<String, Double>,
    val assetWeights: Map<String, Double> = emptyMap(),
    val ampCoefficient: Double = 100.0,
    val feeBps: Int = 5, // 0.05%
    val tvlUsd: Double,
    val volume24hUsd: Double,
    val fees24hUsd: Double,
    val lpTokenTotalSupply: Double,
    val userLpShares: Double = 0.0,
    val navPerShareUsd: Double = 1.00,
    val poolHealthScore: Int = 98,
    val circuitBreakerTripped: Boolean = false,
    val isFlagship: Boolean = false,
    val minDepositUsd: Double = 10000.0
)
