package com.example.atomic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.atomic.model.NetworkInfo
import com.example.atomic.model.NetworkRegistry
import com.example.atomic.ui.components.NetworkTopologyCanvas
import com.example.ui.theme.*

@Composable
fun NetworkGraphScreen(
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AtomicBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AtomicSurfaceElevated),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorder))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(imageVector = Icons.Default.Hub, contentDescription = null, tint = AtomicGreen, modifier = Modifier.size(20.dp))
                            Text(
                                text = "NETWORK CONTROL CENTRE",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = AtomicTextPrimary
                            )
                        }
                        Text(
                            text = "Central Bank RTGS, EVM Escrows & UTXO Settlement Connectors",
                            style = MaterialTheme.typography.bodySmall,
                            color = AtomicTextSecondary
                        )
                    }
                }
            }
        }

        // Network Topology Visualizer Canvas
        item {
            NetworkTopologyCanvas()
        }

        item {
            Text(
                text = "CONNECTED SETTLEMENT ADAPTERS (8 NETWORKS):",
                style = MaterialTheme.typography.titleSmall,
                fontSize = 11.sp,
                color = AtomicTextSecondary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(NetworkRegistry.ALL_NETWORKS) { network ->
            NetworkInfoCard(network = network)
        }
    }
}

@Composable
private fun NetworkInfoCard(network: NetworkInfo) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AtomicSurfaceCard),
        shape = RoundedCornerShape(10.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorderSubtle))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color(network.status.colorHex))
                    )
                    Text(
                        text = network.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = AtomicTextPrimary
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(network.status.colorHex).copy(alpha = 0.2f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (network.isSimulated) "SIMULATED RTGS" else "MAINNET ADAPTER",
                        color = Color(network.status.colorHex),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                text = "Consensus: ${network.consensus}",
                fontSize = 10.sp,
                color = AtomicTextSecondary
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Finality: ${network.averageFinalitySeconds}s | Latency: ${network.latencyMs}ms",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicBlueLight
                )
                Text(
                    text = "Height/Seq: #${network.blockHeightOrLedgerSeq}",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicGreenLight
                )
            }
        }
    }
}
