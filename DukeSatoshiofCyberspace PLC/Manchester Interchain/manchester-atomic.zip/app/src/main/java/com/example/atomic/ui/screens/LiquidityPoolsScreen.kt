package com.example.atomic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.atomic.engine.PoolFactoryEngine
import com.example.atomic.model.InvariantType
import com.example.atomic.model.LiquidityPool
import com.example.atomic.ui.components.InvariantCurveChart
import com.example.atomic.viewmodel.AtomicViewModel
import com.example.ui.theme.*

@Composable
fun LiquidityPoolsScreen(
    viewModel: AtomicViewModel,
    modifier: Modifier = Modifier
) {
    val pools by viewModel.pools.collectAsState()
    var selectedPool by remember { mutableStateOf<LiquidityPool?>(pools.firstOrNull()) }
    var showDeployPoolDialog by remember { mutableStateOf(false) }
    var showDepositDialog by remember { mutableStateOf(false) }
    var showWithdrawDialog by remember { mutableStateOf(false) }

    // Impermanent loss slider state
    var priceRatioSlider by remember { mutableStateOf(1.5f) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AtomicBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "INSTITUTIONAL POOL PLATFORM",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = AtomicTextPrimary
                    )
                    Text(
                        text = "Multi-Asset AMM, StableSwap & Balancer Invariants",
                        style = MaterialTheme.typography.bodySmall,
                        color = AtomicTextSecondary
                    )
                }

                Button(
                    onClick = { showDeployPoolDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = AtomicGreen, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("pool_factory_deploy_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "POOL FACTORY", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Pools Horizontal / Vertical Card List
        items(pools) { pool ->
            val isSelected = selectedPool?.poolId == pool.poolId
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedPool = pool },
                colors = CardDefaults.cardColors(containerColor = if (isSelected) AtomicSurfaceElevated else AtomicSurfaceCard),
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(if (isSelected) AtomicGreen else AtomicBorderSubtle)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = pool.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = AtomicTextPrimary
                            )
                            if (pool.isFlagship) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(AtomicGreenDim)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "FLAGSHIP",
                                        color = AtomicGreenLight,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Text(
                            text = "TVL: $${"%,.0f".format(pool.tvlUsd)}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = AtomicGreen
                        )
                    }

                    // Reserves Pills
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        pool.assetReserves.entries.take(4).forEach { (symbol, amount) ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(AtomicNavyDark)
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "$symbol: ${"%,.0f".format(amount)}",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = AtomicTextSecondary
                                )
                            }
                        }
                    }

                    // Stats Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "24h Vol: $${"%,.0f".format(pool.volume24hUsd)}",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = AtomicTextMuted
                        )
                        Text(
                            text = "Fee Tier: ${pool.feeBps} bps | Health: ${pool.poolHealthScore}%",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = AtomicBlueLight
                        )
                    }
                }
            }
        }

        // Selected Pool Deep Analytics & Liquidity Provider Terminal
        selectedPool?.let { pool ->
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AtomicSurfaceElevated),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorder))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "LP TERMINAL & INVARIANT CONTROL: ${pool.poolId}",
                            style = MaterialTheme.typography.titleSmall,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AtomicTextPrimary,
                            fontFamily = FontFamily.Monospace
                        )

                        // Invariant Curve Canvas
                        InvariantCurveChart(pool = pool)

                        // LP Position Breakdown
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(AtomicNavyDark)
                                .padding(10.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "YOUR LP SHARES:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = AtomicTextSecondary)
                                    Text(text = "${"%,.2f".format(pool.userLpShares)} LP Tokens", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AtomicTextPrimary)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "SHARE OF POOL:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = AtomicTextSecondary)
                                    val pct = if (pool.lpTokenTotalSupply > 0) (pool.userLpShares / pool.lpTokenTotalSupply) * 100.0 else 0.0
                                    Text(text = "${"%.2f".format(pct)}%", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AtomicGreen)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "POSITION NAV VALUE:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = AtomicTextSecondary)
                                    val posValue = pool.userLpShares * pool.navPerShareUsd
                                    Text(text = "$${"%,.2f".format(posValue)} USD", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AtomicBlueLight)
                                }
                            }
                        }

                        // Deposit / Withdraw Liquidity Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { showDepositDialog = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("deposit_liquidity_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = AtomicGreen, contentColor = Color.Black),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(text = "CONTRIBUTE LIQUIDITY", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { showWithdrawDialog = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("withdraw_liquidity_button"),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = AtomicAmber),
                                border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicAmber)),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(text = "WITHDRAW SHARES", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Impermanent Loss Calculator
                        Divider(color = AtomicBorderSubtle)
                        Text(
                            text = "IMPERMANENT LOSS STRESS CALCULATOR",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = AtomicTextSecondary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Price Divergence: ${"%.2f".format(priceRatioSlider)}x",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = AtomicTextPrimary
                            )
                            val ilPct = PoolFactoryEngine.calculateImpermanentLossPercent(priceRatioSlider.toDouble())
                            Text(
                                text = "IL: ${"%.2f".format(ilPct)}%",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (ilPct < -5.0) AtomicRed else AtomicAmber
                            )
                        }

                        Slider(
                            value = priceRatioSlider,
                            onValueChange = { priceRatioSlider = it },
                            valueRange = 0.2f..5.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = AtomicGreen,
                                activeTrackColor = AtomicGreen,
                                inactiveTrackColor = AtomicBorder
                            )
                        )
                    }
                }
            }
        }
    }

    // Deposit Liquidity Dialog
    if (showDepositDialog && selectedPool != null) {
        val pool = selectedPool!!
        var depositAmountStr by remember { mutableStateOf("1000000") }

        AlertDialog(
            onDismissRequest = { showDepositDialog = false },
            containerColor = AtomicSurface,
            title = {
                Text(text = "CONTRIBUTE TO ${pool.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = AtomicTextPrimary)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(text = "Enter proportional deposit units across pool assets:", fontSize = 11.sp, color = AtomicTextSecondary)
                    OutlinedTextField(
                        value = depositAmountStr,
                        onValueChange = { depositAmountStr = it },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = AtomicNavyDark,
                            unfocusedContainerColor = AtomicNavyDark,
                            focusedBorderColor = AtomicGreen,
                            focusedTextColor = AtomicTextPrimary,
                            unfocusedTextColor = AtomicTextPrimary
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = depositAmountStr.toDoubleOrNull() ?: 100000.0
                        val depositMap = pool.assetReserves.mapValues { (_, reserve) ->
                            (reserve / pool.assetReserves.values.sum()) * amount
                        }
                        viewModel.addLiquidityToPool(pool.poolId, depositMap)
                        showDepositDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AtomicGreen, contentColor = Color.Black)
                ) {
                    Text("MINT LP SHARES")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDepositDialog = false }) { Text("CANCEL", color = AtomicTextMuted) }
            }
        )
    }

    // Withdraw Liquidity Dialog
    if (showWithdrawDialog && selectedPool != null) {
        val pool = selectedPool!!
        var sharesStr by remember { mutableStateOf((pool.userLpShares * 0.5).toLong().toString()) }

        AlertDialog(
            onDismissRequest = { showWithdrawDialog = false },
            containerColor = AtomicSurface,
            title = {
                Text(text = "WITHDRAW SHARES FROM ${pool.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = AtomicTextPrimary)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(text = "Available Shares: ${"%,.2f".format(pool.userLpShares)}", fontSize = 11.sp, color = AtomicTextSecondary)
                    OutlinedTextField(
                        value = sharesStr,
                        onValueChange = { sharesStr = it },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = AtomicNavyDark,
                            unfocusedContainerColor = AtomicNavyDark,
                            focusedBorderColor = AtomicAmber,
                            focusedTextColor = AtomicTextPrimary,
                            unfocusedTextColor = AtomicTextPrimary
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val shares = sharesStr.toDoubleOrNull() ?: 0.0
                        viewModel.removeLiquidityFromPool(pool.poolId, shares)
                        showWithdrawDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AtomicAmber, contentColor = Color.Black)
                ) {
                    Text("BURN & REDEEM")
                }
            },
            dismissButton = {
                TextButton(onClick = { showWithdrawDialog = false }) { Text("CANCEL", color = AtomicTextMuted) }
            }
        )
    }

    // Deploy Pool Factory Dialog
    if (showDeployPoolDialog) {
        var poolName by remember { mutableStateOf("Sovereign Multi-CBDC Bridge Pool") }
        var selectedInvariant by remember { mutableStateOf(InvariantType.STABLE_SWAP) }
        var feeBpsStr by remember { mutableStateOf("3") }

        AlertDialog(
            onDismissRequest = { showDeployPoolDialog = false },
            containerColor = AtomicSurface,
            title = {
                Text(text = "POOL FACTORY: DEPLOY CUSTOM POOL", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = AtomicTextPrimary)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = poolName,
                        onValueChange = { poolName = it },
                        label = { Text("Pool Name") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = AtomicNavyDark,
                            unfocusedContainerColor = AtomicNavyDark,
                            focusedBorderColor = AtomicGreen,
                            focusedTextColor = AtomicTextPrimary,
                            unfocusedTextColor = AtomicTextPrimary
                        )
                    )

                    Text(text = "Invariant Mathematical Model:", fontSize = 10.sp, color = AtomicTextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        InvariantType.values().forEach { inv ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (selectedInvariant == inv) AtomicGreenDim else AtomicNavyDark)
                                    .border(1.dp, if (selectedInvariant == inv) AtomicGreen else AtomicBorderSubtle, RoundedCornerShape(4.dp))
                                    .clickable { selectedInvariant = inv }
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = inv.name.take(6),
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (selectedInvariant == inv) AtomicGreenLight else AtomicTextMuted
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = feeBpsStr,
                        onValueChange = { feeBpsStr = it },
                        label = { Text("Fee Tier (bps)") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = AtomicNavyDark,
                            unfocusedContainerColor = AtomicNavyDark,
                            focusedBorderColor = AtomicGreen,
                            focusedTextColor = AtomicTextPrimary,
                            unfocusedTextColor = AtomicTextPrimary
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val poolId = "POOL-CUSTOM-" + (1000..9999).random()
                        val feeBps = feeBpsStr.toIntOrNull() ?: 3
                        val initialRes = mapOf("GBP-CBDC" to 15_000_000.0, "EUR-CBDC" to 17_500_000.0)
                        viewModel.createNewPool(
                            poolId = poolId,
                            name = poolName,
                            invariantType = selectedInvariant,
                            reserves = initialRes,
                            feeBps = feeBps
                        )
                        showDeployPoolDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AtomicGreen, contentColor = Color.Black)
                ) {
                    Text("DEPLOY POOL")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeployPoolDialog = false }) { Text("CANCEL", color = AtomicTextMuted) }
            }
        )
    }
}
