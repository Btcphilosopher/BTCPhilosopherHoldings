package com.example.atomic.model

enum class ComplianceTier(val label: String, val dailyLimitUsd: Double) {
    TIER_1_CENTRAL_BANK("Tier 1 - Sovereign & Central Bank Core", 1_000_000_000.0),
    TIER_1_INSTITUTIONAL("Tier 1 - G-SIFI Primary Dealer", 250_000_000.0),
    TIER_2_QUALIFIED("Tier 2 - Regulated Institutional Fund", 50_000_000.0),
    TIER_3_PROVISIONAL("Tier 3 - Sandbox Pilot Participant", 5_000_000.0)
}

data class InstitutionalComplianceState(
    val entityName: String = "Manchester Interchain Liquidity Desk Ltd",
    val leiCode: String = "984500F123MANCHEST01",
    val jurisdiction: String = "United Kingdom (PRA / FCA Sandbox Simulation)",
    val tier: ComplianceTier = ComplianceTier.TIER_1_INSTITUTIONAL,
    val sanctionsScreeningStatus: String = "PASSED (OFAC/UN/UK-HMT Cleared)",
    val travelRuleExchangeProtocol: String = "IVMS 101 Compatible",
    val dailyLimitUsd: Double = 250_000_000.0,
    val dailyTurnoverUsd: Double = 34_820_000.0,
    val isAutoApproveWhitelisted: Boolean = true
)
