package com.example.atomic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.atomic.model.*
import com.example.atomic.ui.components.AtomicExecutionTimeline
import com.example.atomic.viewmodel.AtomicViewModel
import com.example.ui.theme.*

@Composable
fun UniversalSwapScreen(
    viewModel: AtomicViewModel,
    modifier: Modifier = Modifier
) {
    val swapState by viewModel.swapState.collectAsState()

    var showFromAssetPicker by remember { mutableStateOf(false) }
    var showToAssetPicker by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AtomicBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero / Institutional Directive Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AtomicSurfaceElevated),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorder))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "ATOMIC SETTLEMENT DESK",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = AtomicTextPrimary
                        )
                        Text(
                            text = "ASSET A + ASSET B → ATOMIC EXECUTION → EITHER BOTH SETTLE OR NOTHING SETTLES",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = AtomicGreen
                        )
                    }

                    // Simulation Mode Pill
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (swapState.isSimulatingFailure) AtomicAmberDim else AtomicNavyDark)
                            .border(1.dp, if (swapState.isSimulatingFailure) AtomicAmber else AtomicBorderSubtle, RoundedCornerShape(6.dp))
                            .clickable { viewModel.toggleSimulateFailure(!swapState.isSimulatingFailure) }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("simulate_failure_toggle"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (swapState.isSimulatingFailure) Icons.Default.Warning else Icons.Default.BugReport,
                            contentDescription = "Test Failure",
                            tint = if (swapState.isSimulatingFailure) AtomicAmber else AtomicTextMuted,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = if (swapState.isSimulatingFailure) "SIMULATING TIMEOUT" else "NORMAL MODE",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (swapState.isSimulatingFailure) AtomicAmberLight else AtomicTextSecondary
                        )
                    }
                }
            }
        }

        // Fast Preset Scenarios
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "INSTITUTIONAL DEMO BENCHMARKS:",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicTextMuted
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PresetPill(
                        label = "£10M GBP → USDC",
                        isSelected = swapState.fromAsset.symbol == "GBP-CBDC" && swapState.toAsset.symbol == "USDC" && swapState.fromAmount == 10_000_000.0,
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.setFromAsset(AssetRegistry.GBP_CBDC)
                        viewModel.setToAsset(AssetRegistry.USDC)
                        viewModel.setFromAmount(10_000_000.0)
                    }

                    PresetPill(
                        label = "50 BTC → USD-CBDC",
                        isSelected = swapState.fromAsset.symbol == "BTC" && swapState.toAsset.symbol == "USD-CBDC",
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.setFromAsset(AssetRegistry.BTC)
                        viewModel.setToAsset(AssetRegistry.USD_CBDC)
                        viewModel.setFromAmount(50.0)
                    }

                    PresetPill(
                        label = "€5M EUR → GBP-CBDC",
                        isSelected = swapState.fromAsset.symbol == "EUR-CBDC" && swapState.toAsset.symbol == "GBP-CBDC",
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.setFromAsset(AssetRegistry.EUR_CBDC)
                        viewModel.setToAsset(AssetRegistry.GBP_CBDC)
                        viewModel.setFromAmount(5_000_000.0)
                    }

                    PresetPill(
                        label = "BTC → GBP (Multi-Hop)",
                        isSelected = swapState.fromAsset.symbol == "BTC" && swapState.toAsset.symbol == "GBP-CBDC",
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.setFromAsset(AssetRegistry.BTC)
                        viewModel.setToAsset(AssetRegistry.GBP_CBDC)
                        viewModel.setFromAmount(25.0)
                    }
                }
            }
        }

        // Asset Selectors & Amount Input Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AtomicSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorder))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // FROM ASSET BLOCK
                    Text(
                        text = "DELIVER (SOURCE LEG):",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = AtomicTextSecondary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Asset Dropdown Button
                        AssetSelectorButton(
                            asset = swapState.fromAsset,
                            modifier = Modifier.weight(1.2f),
                            onClick = { showFromAssetPicker = true }
                        )

                        // Amount TextField
                        OutlinedTextField(
                            value = if (swapState.fromAmount == 0.0) "" else swapState.fromAmount.toString(),
                            onValueChange = { str ->
                                val parsed = str.toDoubleOrNull() ?: 0.0
                                viewModel.setFromAmount(parsed)
                            },
                            modifier = Modifier
                                .weight(1.8f)
                                .testTag("swap_amount_input"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = AtomicNavyDark,
                                unfocusedContainerColor = AtomicNavyDark,
                                focusedBorderColor = AtomicBlue,
                                unfocusedBorderColor = AtomicBorder,
                                focusedTextColor = AtomicTextPrimary,
                                unfocusedTextColor = AtomicTextPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    // Swap Direction Reversal Icon
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(
                            onClick = {
                                val temp = swapState.fromAsset
                                viewModel.setFromAsset(swapState.toAsset)
                                viewModel.setToAsset(temp)
                            },
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(AtomicSurfaceElevated)
                                .border(1.dp, AtomicBorder, CircleShape)
                                .testTag("swap_direction_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                contentDescription = "Swap Assets",
                                tint = AtomicGreen,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // TO ASSET BLOCK
                    Text(
                        text = "RECEIVE (DESTINATION LEG):",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = AtomicTextSecondary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AssetSelectorButton(
                            asset = swapState.toAsset,
                            modifier = Modifier.weight(1.2f),
                            onClick = { showToAssetPicker = true }
                        )

                        // Expected Output Box
                        val expectedOut = (swapState.fromAmount * (swapState.selectedRoute?.effectiveRate ?: 0.0))
                        Box(
                            modifier = Modifier
                                .weight(1.8f)
                                .height(56.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(AtomicNavyDark)
                                .border(1.dp, AtomicBorderSubtle, RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Column {
                                Text(
                                    text = "%,.4f".format(expectedOut),
                                    fontSize = 16.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = AtomicGreen
                                )
                                Text(
                                    text = "≈ $${"%,.2f".format(expectedOut * swapState.toAsset.referencePriceUsd)} USD",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = AtomicTextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        // Available Routes Selection
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "OPTIMAL EXECUTABLE ROUTES DISCOVERED:",
                    style = MaterialTheme.typography.titleSmall,
                    fontSize = 11.sp,
                    color = AtomicTextSecondary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                swapState.availableRoutes.forEach { route ->
                    RouteCard(
                        route = route,
                        isSelected = swapState.selectedRoute?.routeId == route.routeId,
                        onSelect = { viewModel.selectRoute(route) }
                    )
                }
            }
        }

        // Pre-Trade Settlement Breakdown Card
        item {
            swapState.selectedRoute?.let { route ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AtomicSurfaceElevated),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorder))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "PRE-TRADE SETTLEMENT SPECIFICATION",
                            style = MaterialTheme.typography.titleSmall,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AtomicTextPrimary,
                            fontFamily = FontFamily.Monospace
                        )

                        Divider(color = AtomicBorderSubtle)

                        BreakdownRow("EFFECTIVE RATE", "1 ${swapState.fromAsset.symbol} = ${"%.6f".format(route.effectiveRate)} ${swapState.toAsset.symbol}")
                        BreakdownRow("PRICE IMPACT", "${"%.3f".format(route.priceImpactPercent)}%", if (route.priceImpactPercent > 0.5) AtomicAmber else AtomicGreen)
                        BreakdownRow("INSTITUTIONAL FEE", "$${"%,.2f".format(route.feeUsd)}")
                        BreakdownRow("NETWORK SETTLEMENT COST", "$${"%,.2f".format(route.estimatedGasUsd)}")
                        BreakdownRow("ESTIMATED DUAL FINALITY", "${route.estimatedFinalitySeconds}s")
                        BreakdownRow("SETTLEMENT VENUE", route.counterpartyOrPoolName)
                        BreakdownRow("COMPLIANCE TIER", "APPROVED (LEI: 984500F123)", AtomicBlueLight)
                        BreakdownRow("ATOMICITY GUARANTEE", "100% (SHA-256 HASHLOCK)", AtomicGreenLight)

                        Spacer(modifier = Modifier.height(6.dp))

                        // Execution Button
                        Button(
                            onClick = { viewModel.executeActiveSwap() },
                            enabled = !swapState.isExecuting && swapState.fromAmount > 0,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("execute_atomic_swap_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (swapState.isSimulatingFailure) AtomicAmber else AtomicGreen,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            if (swapState.isExecuting) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color.Black,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "SYNCHRONISING ATOMIC ESCROWS...",
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (swapState.isSimulatingFailure) "AUTHORISE & TEST TIMEOUT ROLLBACK" else "AUTHORISE & EXECUTE ATOMIC SETTLEMENT",
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Live Synchronous Execution Timeline
        item {
            swapState.currentTransaction?.let { tx ->
                AtomicExecutionTimeline(
                    transaction = tx,
                    isExecuting = swapState.isExecuting
                )
            }
        }

        // Live Settlement Console Logs
        if (swapState.executionLogMessages.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AtomicNavyDark),
                    shape = RoundedCornerShape(10.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorderSubtle))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "SETTLEMENT ENGINE EVENT LOGS:",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = AtomicGreen
                        )
                        swapState.executionLogMessages.takeLast(6).forEach { log ->
                            Text(
                                text = log,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = AtomicTextSecondary
                            )
                        }
                    }
                }
            }
        }
    }

    // Asset Selection Dialog
    if (showFromAssetPicker || showToAssetPicker) {
        AlertDialog(
            onDismissRequest = {
                showFromAssetPicker = false
                showToAssetPicker = false
            },
            containerColor = AtomicSurface,
            title = {
                Text(
                    text = if (showFromAssetPicker) "SELECT DELIVER ASSET" else "SELECT RECEIVE ASSET",
                    style = MaterialTheme.typography.titleMedium,
                    color = AtomicTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(AssetRegistry.ALL_ASSETS) { asset ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(AtomicSurfaceElevated)
                                .clickable {
                                    if (showFromAssetPicker) viewModel.setFromAsset(asset)
                                    else viewModel.setToAsset(asset)
                                    showFromAssetPicker = false
                                    showToAssetPicker = false
                                }
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = asset.symbol,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(asset.colorHex)
                                    )
                                    if (asset.isSimulated) {
                                        Text(
                                            text = "SIMULATED",
                                            fontSize = 8.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = AtomicBlueLight
                                        )
                                    }
                                }
                                Text(
                                    text = asset.name,
                                    fontSize = 11.sp,
                                    color = AtomicTextSecondary
                                )
                            }
                            Text(
                                text = "$${"%,.2f".format(asset.referencePriceUsd)}",
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                color = AtomicTextPrimary
                            )
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }
}

@Composable
private fun PresetPill(label: String, isSelected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) AtomicGreenDim else AtomicSurfaceElevated)
            .border(1.dp, if (isSelected) AtomicGreen else AtomicBorderSubtle, RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = if (isSelected) AtomicGreenLight else AtomicTextSecondary
        )
    }
}

@Composable
private fun AssetSelectorButton(asset: Asset, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(
        modifier = modifier
            .height(56.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(AtomicNavyDark)
            .border(1.dp, AtomicBorder, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = asset.symbol,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color(asset.colorHex)
            )
            Text(
                text = asset.category.displayName,
                fontSize = 9.sp,
                color = AtomicTextMuted,
                maxLines = 1
            )
        }
        Icon(
            imageVector = Icons.Default.ArrowDropDown,
            contentDescription = null,
            tint = AtomicTextSecondary
        )
    }
}

@Composable
private fun RouteCard(route: ExecutionRoute, isSelected: Boolean, onSelect: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() },
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) AtomicSurfaceElevated else AtomicNavyDark
        ),
        shape = RoundedCornerShape(8.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(if (isSelected) AtomicGreen else AtomicBorderSubtle)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = route.routeType.label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AtomicTextPrimary
                    )
                    Text(
                        text = route.pathTokens.joinToString(" → "),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = AtomicBlue
                    )
                }
                Text(
                    text = route.description,
                    fontSize = 10.sp,
                    color = AtomicTextSecondary
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "Rate: ${"%.4f".format(route.effectiveRate)}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = AtomicGreen
                )
                Text(
                    text = "Finality: ${route.estimatedFinalitySeconds}s | Gas: $${"%.2f".format(route.estimatedGasUsd)}",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicTextMuted
                )
            }
        }
    }
}

@Composable
private fun BreakdownRow(label: String, value: String, valueColor: Color = AtomicTextPrimary) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = AtomicTextSecondary)
        Text(text = value, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = valueColor)
    }
}
