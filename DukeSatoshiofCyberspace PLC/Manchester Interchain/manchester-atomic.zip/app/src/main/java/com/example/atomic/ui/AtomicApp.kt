package com.example.atomic.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.atomic.ui.components.InstitutionalHeader
import com.example.atomic.ui.screens.*
import com.example.atomic.viewmodel.AtomicViewModel
import com.example.ui.theme.*

enum class AppNavDestination(val label: String, val icon: ImageVector) {
    SWAP_DESK("Settlement", Icons.Default.SwapHoriz),
    POOLS("Pools", Icons.Default.WaterDrop),
    RFQ_BOOK("RFQ / Book", Icons.Default.RequestQuote),
    LEDGER("Proofs", Icons.Default.VerifiedUser),
    TREASURY("Treasury", Icons.Default.AccountBalance),
    STRESS_LAB("Stress Lab", Icons.Default.Science),
    NETWORKS("Networks", Icons.Default.Hub),
    COMPLIANCE("Risk", Icons.Default.Policy),
    AI_ASSISTANT("AI Assist", Icons.Default.AutoAwesome),
    API_CONSOLE("API", Icons.Default.Code)
}

@Composable
fun AtomicApp(
    viewModel: AtomicViewModel = viewModel()
) {
    var currentDestination by remember { mutableStateOf(AppNavDestination.SWAP_DESK) }

    Scaffold(
        topBar = {
            InstitutionalHeader(activeTabName = currentDestination.label)
        },
        bottomBar = {
            NavigationBar(
                containerColor = AtomicSurface,
                tonalElevation = 8.dp
            ) {
                // Display primary institutional destinations on phone bottom bar
                val primaryDestinations = listOf(
                    AppNavDestination.SWAP_DESK,
                    AppNavDestination.POOLS,
                    AppNavDestination.RFQ_BOOK,
                    AppNavDestination.TREASURY,
                    AppNavDestination.STRESS_LAB,
                    AppNavDestination.LEDGER,
                    AppNavDestination.AI_ASSISTANT,
                    AppNavDestination.API_CONSOLE
                )

                primaryDestinations.take(5).forEach { dest ->
                    val isSelected = currentDestination == dest
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentDestination = dest },
                        icon = {
                            Icon(
                                imageVector = dest.icon,
                                contentDescription = dest.label,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = dest.label,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AtomicGreen,
                            selectedTextColor = AtomicGreen,
                            unselectedIconColor = AtomicTextMuted,
                            unselectedTextColor = AtomicTextMuted,
                            indicatorColor = AtomicGreenDim
                        ),
                        modifier = Modifier.testTag("nav_item_${dest.name.lowercase()}")
                    )
                }
            }
        },
        containerColor = AtomicBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Secondary Navigation Rail / Scrollable Sub-bar for advanced institutional tools
            ScrollableTabRow(
                selectedTabIndex = currentDestination.ordinal,
                containerColor = AtomicSurfaceElevated,
                contentColor = AtomicGreen,
                edgePadding = 8.dp,
                divider = {}
            ) {
                AppNavDestination.values().forEach { dest ->
                    Tab(
                        selected = currentDestination == dest,
                        onClick = { currentDestination = dest },
                        text = {
                            Text(
                                text = dest.label.uppercase(),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (currentDestination == dest) FontWeight.Bold else FontWeight.Normal,
                                color = if (currentDestination == dest) AtomicGreen else AtomicTextSecondary
                            )
                        },
                        modifier = Modifier.testTag("sub_tab_${dest.name.lowercase()}")
                    )
                }
            }

            // Screen Destination Switcher
            Box(modifier = Modifier.weight(1f)) {
                when (currentDestination) {
                    AppNavDestination.SWAP_DESK -> UniversalSwapScreen(viewModel = viewModel)
                    AppNavDestination.POOLS -> LiquidityPoolsScreen(viewModel = viewModel)
                    AppNavDestination.RFQ_BOOK -> RfqOrderBookScreen(
                        viewModel = viewModel,
                        onNavigateToSwap = { currentDestination = AppNavDestination.SWAP_DESK }
                    )
                    AppNavDestination.LEDGER -> ProofVerificationScreen(viewModel = viewModel)
                    AppNavDestination.TREASURY -> TreasuryScreen(viewModel = viewModel)
                    AppNavDestination.STRESS_LAB -> StressLabScreen(viewModel = viewModel)
                    AppNavDestination.NETWORKS -> NetworkGraphScreen()
                    AppNavDestination.COMPLIANCE -> RiskComplianceScreen()
                    AppNavDestination.AI_ASSISTANT -> AiAssistantScreen(viewModel = viewModel)
                    AppNavDestination.API_CONSOLE -> ApiConsoleScreen(viewModel = viewModel)
                }
            }
        }
    }
}
