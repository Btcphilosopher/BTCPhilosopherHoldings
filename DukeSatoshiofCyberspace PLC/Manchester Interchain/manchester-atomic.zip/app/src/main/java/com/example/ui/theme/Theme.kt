package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AtomicColorScheme = darkColorScheme(
    primary = AtomicGreen,
    onPrimary = Color(0xFF001F12),
    primaryContainer = AtomicGreenDim,
    onPrimaryContainer = AtomicGreenLight,
    
    secondary = AtomicBlue,
    onSecondary = Color(0xFF001E2F),
    secondaryContainer = AtomicBlueDim,
    onSecondaryContainer = AtomicBlueLight,
    
    tertiary = AtomicAmber,
    onTertiary = Color(0xFF2D1C00),
    tertiaryContainer = AtomicAmberDim,
    onTertiaryContainer = AtomicAmberLight,
    
    background = AtomicBackground,
    onBackground = AtomicTextPrimary,
    
    surface = AtomicSurface,
    onSurface = AtomicTextPrimary,
    surfaceVariant = AtomicSurfaceElevated,
    onSurfaceVariant = AtomicTextSecondary,
    
    outline = AtomicBorder,
    outlineVariant = AtomicBorderSubtle,
    
    error = AtomicRed,
    onError = Color.White,
    errorContainer = AtomicRedDim,
    onErrorContainer = Color(0xFFFECACA)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AtomicColorScheme,
        typography = Typography,
        content = content
    )
}
