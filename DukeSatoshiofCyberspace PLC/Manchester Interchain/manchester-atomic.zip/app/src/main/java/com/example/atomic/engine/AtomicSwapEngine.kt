package com.example.atomic.engine

import com.example.atomic.crypto.CryptoEngine
import com.example.atomic.model.*
import kotlinx.coroutines.delay
import java.util.UUID

object AtomicSwapEngine {

    fun createQuote(
        fromAsset: Asset,
        toAsset: Asset,
        fromAmount: Double,
        route: ExecutionRoute
    ): AtomicTransaction {
        val preimage = CryptoEngine.generatePreimage()
        val hashLock = CryptoEngine.sha256(preimage)
        val txId = "ATX-" + UUID.randomUUID().toString().take(8).uppercase()
        val timestamp = System.currentTimeMillis()
        val deadline = timestamp + (route.estimatedFinalitySeconds * 1000).toLong() + 300_000L // 5 min timeout
        val expectedToAmount = fromAmount * route.effectiveRate

        val legs = mutableListOf<SwapLeg>()
        if (route.pathTokens.size > 2) {
            // Multi-Hop legs
            for (i in 0 until route.pathTokens.size - 1) {
                val legFromSymbol = route.pathTokens[i]
                val legToSymbol = route.pathTokens[i + 1]
                val legFromAsset = AssetRegistry.getBySymbol(legFromSymbol)
                val legToAsset = AssetRegistry.getBySymbol(legToSymbol)
                val legAmount = if (i == 0) fromAmount else fromAmount * (legFromAsset.referencePriceUsd / legToAsset.referencePriceUsd)

                legs.add(
                    SwapLeg(
                        legId = "$txId-LEG-${i + 1}",
                        legIndex = i + 1,
                        sourceNetworkId = legFromAsset.networkId,
                        destinationNetworkId = legToAsset.networkId,
                        assetSymbol = legFromSymbol,
                        amount = legAmount,
                        senderAccount = "MCR-TREASURY-01",
                        receiverAccount = "ESCROW-${legToAsset.networkId.take(6)}",
                        escrowContractOrScript = "0x" + CryptoEngine.sha256("ESCROW|$txId|$i").take(40)
                    )
                )
            }
        } else {
            // Standard 2-Leg atomic swap (Leg 1: FromAsset -> Counterparty, Leg 2: ToAsset -> Initiator)
            legs.add(
                SwapLeg(
                    legId = "$txId-LEG-1",
                    legIndex = 1,
                    sourceNetworkId = fromAsset.networkId,
                    destinationNetworkId = toAsset.networkId,
                    assetSymbol = fromAsset.symbol,
                    amount = fromAmount,
                    senderAccount = "MCR-TREASURY-VAULT",
                    receiverAccount = "ESCROW-${fromAsset.networkId.take(6)}",
                    escrowContractOrScript = "0x" + CryptoEngine.sha256("ESCROW-LEG1|$txId").take(40)
                )
            )
            legs.add(
                SwapLeg(
                    legId = "$txId-LEG-2",
                    legIndex = 2,
                    sourceNetworkId = toAsset.networkId,
                    destinationNetworkId = fromAsset.networkId,
                    assetSymbol = toAsset.symbol,
                    amount = expectedToAmount,
                    senderAccount = "LIQUIDITY-VENUE-${toAsset.networkId.take(6)}",
                    receiverAccount = "MCR-TREASURY-VAULT",
                    escrowContractOrScript = "0x" + CryptoEngine.sha256("ESCROW-LEG2|$txId").take(40)
                )
            )
        }

        return AtomicTransaction(
            id = txId,
            timestamp = timestamp,
            fromAssetSymbol = fromAsset.symbol,
            toAssetSymbol = toAsset.symbol,
            fromAmount = fromAmount,
            expectedToAmount = expectedToAmount,
            actualToAmount = 0.0,
            state = TransactionState.QUOTED,
            hashLockHex = hashLock,
            preimageHex = preimage,
            timeLockDeadlineEpoch = deadline,
            route = route,
            legs = legs,
            isMultiHop = route.pathTokens.size > 2
        )
    }

    suspend fun executeSwapStateTransitions(
        initialTx: AtomicTransaction,
        simulateFailure: Boolean = false,
        onStateChanged: suspend (AtomicTransaction, String) -> Unit
    ): AtomicTransaction {
        var currentTx = initialTx

        // 1. AUTHORISED
        currentTx = currentTx.copy(state = TransactionState.AUTHORISED)
        onStateChanged(currentTx, "Institutional policy and sanctions screening validated. Treasury authorised execution.")
        delay(600)

        // 2. FUNDED
        currentTx = currentTx.copy(state = TransactionState.FUNDED)
        onStateChanged(currentTx, "Working capital settlement buffers allocated on respective networks.")
        delay(600)

        // 3. LOCKING DUAL LEGS
        val updatedLegsAfterLock = currentTx.legs.map { leg ->
            val adapter = NetworkAdapterManager.getAdapter(leg.sourceNetworkId)
            val lockHash = adapter.lockEscrow(
                txId = currentTx.id,
                legIndex = leg.legIndex,
                asset = leg.assetSymbol,
                amount = leg.amount,
                hashLockHex = currentTx.hashLockHex,
                timelockSeconds = 300,
                sender = leg.senderAccount,
                recipient = leg.receiverAccount
            )
            leg.copy(
                lockTxHash = lockHash,
                status = LegStatus.LOCKED,
                lockTimestamp = System.currentTimeMillis()
            )
        }
        currentTx = currentTx.copy(state = TransactionState.LOCKED, legs = updatedLegsAfterLock)
        onStateChanged(currentTx, "Cryptographic HashLock commitments locked in dual escrow smart contracts / UTXO scripts.")
        delay(700)

        // If simulated failure requested (e.g. Leg 2 timeout or network outage):
        if (simulateFailure) {
            delay(800)
            currentTx = currentTx.copy(
                state = TransactionState.EXPIRED,
                failureReason = "Simulated Timeout: Leg 2 validator failed to provide finality witness before timelock expiry."
            )
            onStateChanged(currentTx, "Timelock expired without preimage disclosure. Triggering deterministic refund rollback.")
            delay(900)

            val refundedLegs = currentTx.legs.map { leg ->
                val adapter = NetworkAdapterManager.getAdapter(leg.sourceNetworkId)
                val refundHash = adapter.executeRefundTimelock(leg.lockTxHash ?: "0x0")
                leg.copy(
                    refundTxHash = refundHash,
                    status = LegStatus.REFUNDED
                )
            }
            currentTx = currentTx.copy(state = TransactionState.REFUNDED, legs = refundedLegs)
            onStateChanged(currentTx, "ALL LEGS REFUNDED ATOMICALLY. Zero principal lost. Invariant: NOTHING SETTLES.")
            return currentTx
        }

        // 4. VERIFYING DUAL CONDITIONS
        val verifiedLegs = currentTx.legs.map { leg ->
            val adapter = NetworkAdapterManager.getAdapter(leg.sourceNetworkId)
            val isConditionValid = adapter.verifyLockedCondition(leg.lockTxHash ?: "", currentTx.hashLockHex)
            leg.copy(
                status = if (isConditionValid) LegStatus.VERIFIED else LegStatus.FAILED,
                currentConfirmations = leg.confirmationsRequired
            )
        }
        currentTx = currentTx.copy(state = TransactionState.VERIFIED, legs = verifiedLegs)
        onStateChanged(currentTx, "Cross-chain condition verification complete. Both legs locked with matching SHA-256 HashLock.")
        delay(700)

        // 5. ATOMIC EXECUTION (Preimage Revelation)
        currentTx = currentTx.copy(state = TransactionState.ATOMIC_EXECUTION)
        onStateChanged(currentTx, "Preimage secret revealed to multi-chain verifier network: ${currentTx.preimageHex.take(16)}...")
        delay(600)

        // 6. SYNCHRONOUS SETTLEMENT
        val settledLegs = currentTx.legs.map { leg ->
            val adapter = NetworkAdapterManager.getAdapter(leg.sourceNetworkId)
            val settleHash = adapter.executeSettlementWithPreimage(leg.lockTxHash ?: "", currentTx.preimageHex)
            leg.copy(
                settleTxHash = settleHash,
                status = LegStatus.SETTLED,
                settleTimestamp = System.currentTimeMillis()
            )
        }
        currentTx = currentTx.copy(
            state = TransactionState.SETTLED,
            legs = settledLegs,
            actualToAmount = currentTx.expectedToAmount
        )
        onStateChanged(currentTx, "Atomic synchronisation satisfied: Both legs settled synchronously.")
        delay(700)

        // 7. FINALITY PROOF GENERATION
        val leafHashes = settledLegs.map { it.settleTxHash ?: "" }
        val merkleRoot = CryptoEngine.computeMerkleRoot(leafHashes)
        val proofHash = "0x" + CryptoEngine.sha256("FINALITY|$merkleRoot|${currentTx.id}")

        currentTx = currentTx.copy(
            state = TransactionState.FINAL,
            proofHash = proofHash
        )
        onStateChanged(currentTx, "Cryptographic proof anchored. Irrevocable finality achieved.")

        return currentTx
    }
}
