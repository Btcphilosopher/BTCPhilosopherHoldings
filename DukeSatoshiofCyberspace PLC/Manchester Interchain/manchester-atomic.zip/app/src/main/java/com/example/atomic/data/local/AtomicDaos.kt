package com.example.atomic.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM atomic_transactions ORDER BY timestamp DESC")
    fun getAllTransactionsFlow(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM atomic_transactions WHERE id = :txId LIMIT 1")
    suspend fun getTransactionById(txId: String): TransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)
}

@Dao
interface PoolDao {
    @Query("SELECT * FROM atomic_pools")
    fun getAllPoolsFlow(): Flow<List<PoolEntity>>

    @Query("SELECT * FROM atomic_pools WHERE poolId = :poolId LIMIT 1")
    suspend fun getPoolById(poolId: String): PoolEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(pools: List<PoolEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPool(pool: PoolEntity)

    @Update
    suspend fun updatePool(pool: PoolEntity)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM atomic_audit_logs ORDER BY timestamp DESC LIMIT 200")
    fun getRecentLogsFlow(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLogEntity)
}
