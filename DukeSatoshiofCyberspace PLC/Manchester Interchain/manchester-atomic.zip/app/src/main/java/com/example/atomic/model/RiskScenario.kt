package com.example.atomic.model

enum class ScenarioId(val title: String, val shortDesc: String) {
    BASELINE_NORMAL("Baseline Normal Operation", "All settlement nodes, pools and oracles in deterministic equilibrium."),
    BTC_FLASH_CRASH_40("Bitcoin -40% Volatility Shock", "Extreme crypto volatility spike; testing circuit breakers & liquidation boundaries."),
    STABLECOIN_USDC_DEPEG("USDC Depeg to $0.88", "Simulated reserve dislocation; testing cross-pool arbitrage and oracle divergence safety."),
    BOE_CBDC_RTGS_HALT("Bank of England RTGS Node Outage", "Synthetic BoE node unresponsive; proving atomic timeout refunds Leg 1 without partial loss."),
    EVM_CONGESTION_GAS_SPIKE("Ethereum Gas Spike (800 Gwei)", "Extreme gas congestion; testing time-lock expansion and priority adaptor queues."),
    ORACLE_DESYNC_ATTACK("Oracle Manipulation / Desync", "Synthetic feed divergence > 3.5%; testing automatic route rejection and pool freeze."),
    SIMULTANEOUS_REDEMPTION("£50M Simultaneous Pool Drain", "Mass redemption run; testing invariant elasticity, slippage ramp and LP NAV protection.")
}

data class StressScenarioResult(
    val scenarioId: ScenarioId,
    val isRunning: Boolean,
    val progressPercent: Int,
    val atomicSafetyVerdict: String,
    val fundsAtRiskUsd: Double,
    val fundsPreservedUsd: Double,
    val rolledBackTransactionsCount: Int,
    val settledTransactionsCount: Int,
    val maxSlippageObservedPct: Double,
    val explanation: String
)
