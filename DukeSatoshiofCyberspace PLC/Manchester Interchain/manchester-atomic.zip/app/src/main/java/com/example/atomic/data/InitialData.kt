package com.example.atomic.data

import com.example.atomic.model.*

object InitialData {
    val FLAGSHIP_MANCHESTER_POOL = LiquidityPool(
        poolId = "POOL-MCR-UNIV-01",
        name = "Manchester Universal Liquidity Pool (Flagship)",
        invariantType = InvariantType.WEIGHTED_MULTI_ASSET,
        assetReserves = mapOf(
            "GBP-CBDC" to 45_000_000.0, // ~$57.8M
            "USD-CBDC" to 60_000_000.0, // $60.0M
            "EUR-CBDC" to 35_000_000.0, // ~$37.9M
            "BTC" to 350.0,             // ~$23.9M
            "USDC" to 50_000_000.0      // $50.0M
        ),
        assetWeights = mapOf(
            "GBP-CBDC" to 0.25,
            "USD-CBDC" to 0.26,
            "EUR-CBDC" to 0.17,
            "BTC" to 0.10,
            "USDC" to 0.22
        ),
        ampCoefficient = 150.0,
        feeBps = 3, // 0.03%
        tvlUsd = 229_745_000.0,
        volume24hUsd = 48_920_000.0,
        fees24hUsd = 14_676.0,
        lpTokenTotalSupply = 200_000_000.0,
        userLpShares = 12_500_000.0, // user owns 6.25% share
        navPerShareUsd = 1.1487,
        poolHealthScore = 99,
        circuitBreakerTripped = false,
        isFlagship = true,
        minDepositUsd = 250_000.0
    )

    val GBP_USD_CBDC_POOL = LiquidityPool(
        poolId = "POOL-GBP-USD-CBDC",
        name = "Sterling / Dollar Central Bank PvP Pool",
        invariantType = InvariantType.STABLE_SWAP,
        assetReserves = mapOf(
            "GBP-CBDC" to 30_000_000.0,
            "USD-CBDC" to 38_550_000.0
        ),
        ampCoefficient = 300.0,
        feeBps = 1, // 0.01%
        tvlUsd = 77_100_000.0,
        volume24hUsd = 26_400_000.0,
        fees24hUsd = 2_640.0,
        lpTokenTotalSupply = 75_000_000.0,
        userLpShares = 5_000_000.0,
        navPerShareUsd = 1.028,
        poolHealthScore = 100,
        isFlagship = false,
        minDepositUsd = 100_000.0
    )

    val BTC_USDC_POOL = LiquidityPool(
        poolId = "POOL-BTC-USDC-DEEP",
        name = "Bitcoin / USDC Atomic Cross-Chain AMM",
        invariantType = InvariantType.CONSTANT_PRODUCT,
        assetReserves = mapOf(
            "BTC" to 1250.0,
            "USDC" to 85_525_000.0
        ),
        feeBps = 5, // 0.05%
        tvlUsd = 171_050_000.0,
        volume24hUsd = 62_150_000.0,
        fees24hUsd = 31_075.0,
        lpTokenTotalSupply = 150_000_000.0,
        userLpShares = 3_000_000.0,
        navPerShareUsd = 1.140,
        poolHealthScore = 98,
        isFlagship = false,
        minDepositUsd = 50_000.0
    )

    val EUR_USDC_POOL = LiquidityPool(
        poolId = "POOL-EUR-USDC-STABLE",
        name = "Digital Euro / USDC Regulated FX Pool",
        invariantType = InvariantType.STABLE_SWAP,
        assetReserves = mapOf(
            "EUR-CBDC" to 40_000_000.0,
            "USDC" to 43_400_000.0
        ),
        ampCoefficient = 200.0,
        feeBps = 2,
        tvlUsd = 86_800_000.0,
        volume24hUsd = 19_200_000.0,
        fees24hUsd = 3_840.0,
        lpTokenTotalSupply = 80_000_000.0,
        userLpShares = 2_500_000.0,
        navPerShareUsd = 1.085,
        poolHealthScore = 99,
        isFlagship = false,
        minDepositUsd = 50_000.0
    )

    val BARC_TOKENISED_POOL = LiquidityPool(
        poolId = "POOL-UK-RLN-BARCLAYS",
        name = "Barclays Tokenised Deposit / Sterling CBDC Bridge",
        invariantType = InvariantType.STABLE_SWAP,
        assetReserves = mapOf(
            "BARC-DEP" to 25_000_000.0,
            "GBP-CBDC" to 25_000_000.0
        ),
        ampCoefficient = 500.0,
        feeBps = 1,
        tvlUsd = 64_250_000.0,
        volume24hUsd = 14_800_000.0,
        fees24hUsd = 1_480.0,
        lpTokenTotalSupply = 50_000_000.0,
        userLpShares = 1_000_000.0,
        navPerShareUsd = 1.285,
        poolHealthScore = 100,
        isFlagship = false,
        minDepositUsd = 100_000.0
    )

    val INITIAL_POOLS = listOf(
        FLAGSHIP_MANCHESTER_POOL,
        GBP_USD_CBDC_POOL,
        BTC_USDC_POOL,
        EUR_USDC_POOL,
        BARC_TOKENISED_POOL
    )

    val INITIAL_DEALERS = listOf(
        "Citadel Securities (Synthetic DLT)",
        "Wintermute Institutional London",
        "Jane Street Global Liquidity",
        "Barclays Digital Assets Desk",
        "Flow Traders CBDC & Crypto"
    )

    val INITIAL_TREASURY_HOLDINGS = listOf(
        TreasuryHolding("GBP-CBDC", 18_500_000.0, 2_000_000.0, 16_500_000.0, 23_772_500.0, 0.30, 0.315, 4.75),
        TreasuryHolding("USD-CBDC", 22_000_000.0, 1_500_000.0, 20_500_000.0, 22_000_000.0, 0.30, 0.292, 5.15),
        TreasuryHolding("EUR-CBDC", 12_000_000.0, 0.0, 12_000_000.0, 13_020_000.0, 0.15, 0.173, 3.85),
        TreasuryHolding("BTC", 145.0, 12.5, 132.5, 9_920_900.0, 0.15, 0.132, 1.20),
        TreasuryHolding("USDC", 6_750_000.0, 500_000.0, 6_250_000.0, 6_750_000.0, 0.10, 0.088, 5.00)
    )

    val INITIAL_COLLATERAL_POOLS = listOf(
        CollateralPool("USD-CBDC", haircutPercent = 0.0, maxLtvPercent = 95.0, eligibleAsMargin = true, depositedAmount = 15_000_000.0, effectiveCollateralValueUsd = 15_000_000.0, concentrationLimitUsd = 50_000_000.0),
        CollateralPool("GBP-CBDC", haircutPercent = 1.0, maxLtvPercent = 94.0, eligibleAsMargin = true, depositedAmount = 10_000_000.0, effectiveCollateralValueUsd = 12_721_500.0, concentrationLimitUsd = 40_000_000.0),
        CollateralPool("USDC", haircutPercent = 2.0, maxLtvPercent = 90.0, eligibleAsMargin = true, depositedAmount = 5_000_000.0, effectiveCollateralValueUsd = 4_900_000.0, concentrationLimitUsd = 25_000_000.0),
        CollateralPool("BTC", haircutPercent = 25.0, maxLtvPercent = 70.0, eligibleAsMargin = true, depositedAmount = 80.0, effectiveCollateralValueUsd = 4_105_200.0, concentrationLimitUsd = 15_000_000.0)
    )
}
