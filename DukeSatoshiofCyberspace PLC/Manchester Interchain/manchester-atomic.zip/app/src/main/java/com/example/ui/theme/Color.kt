package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AtomicBackground = Color(0xFF080C15)
val AtomicNavyDark = Color(0xFF080C15)
val AtomicSurface = Color(0xFF0E1626)
val AtomicSurfaceElevated = Color(0xFF162136)
val AtomicSurfaceCard = Color(0xFF111C2E)
val AtomicBorder = Color(0xFF26354D)
val AtomicBorderSubtle = Color(0xFF1B283D)

val AtomicGreen = Color(0xFF00E599)
val AtomicGreenDim = Color(0xFF004D31)
val AtomicGreenLight = Color(0xFF66FFC2)

val AtomicBlue = Color(0xFF38BDF8)
val AtomicBlueDim = Color(0xFF075985)
val AtomicBlueLight = Color(0xFFBAE6FD)

val AtomicAmber = Color(0xFFF59E0B)
val AtomicAmberDim = Color(0xFF78350F)
val AtomicAmberLight = Color(0xFFFDE68A)

val AtomicPurple = Color(0xFFA78BFA)
val AtomicPurpleDim = Color(0xFF4C1D95)

val AtomicRed = Color(0xFFEF4444)
val AtomicRedDim = Color(0xFF7F1D1D)

val AtomicTextPrimary = Color(0xFFF1F5F9)
val AtomicTextSecondary = Color(0xFF94A3B8)
val AtomicTextMuted = Color(0xFF64748B)

val AtomicGold = Color(0xFFFBBF24)
val AtomicCbdcIndigo = Color(0xFF818CF8)
