package com.example.atomic.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun NetworkTopologyCanvas(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(AtomicNavyDark)
            .border(1.dp, AtomicBorder, RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "GLOBAL INTERCHAIN TOPOLOGY & LIQUIDITY MESH",
                    style = MaterialTheme.typography.titleSmall,
                    fontSize = 11.sp,
                    color = AtomicTextSecondary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "8 NETWORKS CONNECTED",
                    fontSize = 10.sp,
                    color = AtomicGreen,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.height * 0.38f

                val nodeLabels = listOf(
                    "BoE RTGS", "Fedwire", "ECB TIPS",
                    "Bitcoin UTXO", "Ethereum L1", "Arbitrum",
                    "Canton DLT", "UK RLN"
                )

                val nodeColors = listOf(
                    AtomicGreen, AtomicBlue, AtomicCbdcIndigo,
                    AtomicAmber, Color(0xFF627EEA), Color(0xFF28A0F0),
                    AtomicPurple, Color(0xFF00AEEF)
                )

                val nodeCount = nodeLabels.size

                // Draw connecting orbital channels to center
                for (i in 0 until nodeCount) {
                    val angle = (2 * Math.PI * i / nodeCount) - (Math.PI / 2)
                    val nx = center.x + radius * cos(angle).toFloat()
                    val ny = center.y + radius * sin(angle).toFloat()
                    val nodePos = Offset(nx, ny)

                    // Line to center
                    drawLine(
                        color = Color(0xFF26354D),
                        start = center,
                        end = nodePos,
                        strokeWidth = 2f
                    )

                    // Mesh lines between adjacent nodes
                    val nextAngle = (2 * Math.PI * (i + 1) / nodeCount) - (Math.PI / 2)
                    val nextNx = center.x + radius * cos(nextAngle).toFloat()
                    val nextNy = center.y + radius * sin(nextAngle).toFloat()
                    drawLine(
                        color = Color(0xFF162136),
                        start = nodePos,
                        end = Offset(nextNx, nextNy),
                        strokeWidth = 1f
                    )

                    // Draw Node Circle
                    drawCircle(
                        color = nodeColors[i].copy(alpha = 0.3f),
                        radius = 14f,
                        center = nodePos
                    )
                    drawCircle(
                        color = nodeColors[i],
                        radius = 7f,
                        center = nodePos
                    )
                }

                // Draw Center Hub (Manchester Universal Liquidity Core)
                drawCircle(
                    color = AtomicGreenDim,
                    radius = 28f,
                    center = center
                )
                drawCircle(
                    color = AtomicGreen,
                    radius = 28f,
                    center = center,
                    style = Stroke(width = 2f)
                )
                drawCircle(
                    color = Color.White,
                    radius = 6f,
                    center = center
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Core: Manchester Universal Liquidity Pool",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicTextSecondary
                )
                Text(
                    text = "Multi-Hop Atomicity: GUARANTEED",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicGreenLight
                )
            }
        }
    }
}
