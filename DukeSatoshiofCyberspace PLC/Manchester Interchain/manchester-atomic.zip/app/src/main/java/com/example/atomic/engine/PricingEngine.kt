package com.example.atomic.engine

import com.example.atomic.model.*
import kotlin.math.*

object PricingEngine {
    fun calculateSpotRate(fromAsset: Asset, toAsset: Asset, pool: LiquidityPool?): Double {
        if (fromAsset.symbol == toAsset.symbol) return 1.0
        
        // If pool exists and has reserves for both assets:
        if (pool != null && pool.assetReserves.containsKey(fromAsset.symbol) && pool.assetReserves.containsKey(toAsset.symbol)) {
            val resFrom = pool.assetReserves[fromAsset.symbol] ?: 1.0
            val resTo = pool.assetReserves[toAsset.symbol] ?: 1.0
            
            when (pool.invariantType) {
                InvariantType.CONSTANT_PRODUCT -> {
                    return resTo / resFrom
                }
                InvariantType.STABLE_SWAP -> {
                    // Stable swap brings exchange rate close to reference price ratio with flat curve
                    val refRatio = fromAsset.referencePriceUsd / toAsset.referencePriceUsd
                    val imbalance = (resFrom - resTo) / (resFrom + resTo + 1e-9)
                    val slipFactor = 1.0 - (imbalance / (pool.ampCoefficient + 10.0))
                    return refRatio * slipFactor.coerceIn(0.95, 1.05)
                }
                InvariantType.WEIGHTED_MULTI_ASSET -> {
                    val wFrom = pool.assetWeights[fromAsset.symbol] ?: 0.2
                    val wTo = pool.assetWeights[toAsset.symbol] ?: 0.2
                    return (resTo / wTo) / (resFrom / wFrom) * (wFrom / wTo)
                }
            }
        }
        
        // Fallback to reference oracle price
        return fromAsset.referencePriceUsd / toAsset.referencePriceUsd
    }

    fun calculateOutputAmountAndImpact(
        fromAsset: Asset,
        toAsset: Asset,
        amountIn: Double,
        pool: LiquidityPool
    ): Pair<Double, Double> {
        val resIn = pool.assetReserves[fromAsset.symbol] ?: return Pair(amountIn * (fromAsset.referencePriceUsd / toAsset.referencePriceUsd), 0.1)
        val resOut = pool.assetReserves[toAsset.symbol] ?: return Pair(amountIn * (fromAsset.referencePriceUsd / toAsset.referencePriceUsd), 0.1)

        val feeMultiplier = 1.0 - (pool.feeBps / 10000.0)
        val effectiveIn = amountIn * feeMultiplier

        when (pool.invariantType) {
            InvariantType.CONSTANT_PRODUCT -> {
                // dy = y * dx / (x + dx)
                val amountOut = (resOut * effectiveIn) / (resIn + effectiveIn)
                val idealOut = amountIn * (resOut / resIn)
                val priceImpact = if (idealOut > 0) ((idealOut - amountOut) / idealOut) * 100.0 else 0.0
                return Pair(amountOut, priceImpact.coerceAtLeast(0.0))
            }
            InvariantType.STABLE_SWAP -> {
                val refRatio = fromAsset.referencePriceUsd / toAsset.referencePriceUsd
                val approxOutput = effectiveIn * refRatio
                // High amplification gives very low price impact for large stables
                val depthRatio = amountIn / (resIn + 1.0)
                val priceImpact = (depthRatio * 100.0 / (pool.ampCoefficient / 10.0)).coerceIn(0.001, 8.5)
                val finalOut = approxOutput * (1.0 - (priceImpact / 100.0))
                return Pair(finalOut, priceImpact)
            }
            InvariantType.WEIGHTED_MULTI_ASSET -> {
                val wIn = pool.assetWeights[fromAsset.symbol] ?: 0.25
                val wOut = pool.assetWeights[toAsset.symbol] ?: 0.25
                // Out = OutReserve * (1 - (InReserve / (InReserve + InAmount))^(wIn/wOut))
                val ratio = resIn / (resIn + effectiveIn)
                val exponent = wIn / wOut
                val amountOut = resOut * (1.0 - ratio.pow(exponent))
                val spotRate = calculateSpotRate(fromAsset, toAsset, pool)
                val idealOut = amountIn * spotRate
                val priceImpact = if (idealOut > 0) ((idealOut - amountOut) / idealOut) * 100.0 else 0.02
                return Pair(amountOut, priceImpact.coerceAtLeast(0.01))
            }
        }
    }
}
