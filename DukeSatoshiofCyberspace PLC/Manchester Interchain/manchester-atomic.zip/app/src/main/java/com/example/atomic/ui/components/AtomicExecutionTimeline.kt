package com.example.atomic.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.atomic.model.AtomicTransaction
import com.example.atomic.model.LegStatus
import com.example.atomic.model.TransactionState
import com.example.ui.theme.*

@Composable
fun AtomicExecutionTimeline(
    transaction: AtomicTransaction?,
    isExecuting: Boolean,
    modifier: Modifier = Modifier
) {
    if (transaction == null) return

    val currentState = transaction.state

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("atomic_execution_timeline"),
        colors = CardDefaults.cardColors(containerColor = AtomicSurfaceElevated),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
                if (currentState == TransactionState.FINAL || currentState == TransactionState.SETTLED) AtomicGreen
                else if (currentState == TransactionState.REFUNDED || currentState == TransactionState.EXPIRED) AtomicAmber
                else AtomicBlue
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "ATOMIC SETTLEMENT PIPELINE",
                            style = MaterialTheme.typography.titleSmall,
                            color = AtomicTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(currentState.colorHex).copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = currentState.label.uppercase(),
                                color = Color(currentState.colorHex),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = "Transaction ID: ${transaction.id}",
                        style = MaterialTheme.typography.bodySmall,
                        color = AtomicTextMuted,
                        fontFamily = FontFamily.Monospace
                    )
                }

                if (isExecuting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = AtomicGreen
                    )
                } else if (currentState == TransactionState.FINAL) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Settled",
                        tint = AtomicGreen,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // Cryptographic Invariant Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(AtomicNavyDark)
                    .border(1.dp, AtomicBorderSubtle, RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "SHA-256 HASHLOCK (H):",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = AtomicTextMuted
                        )
                        Text(
                            text = "0x" + transaction.hashLockHex.take(16) + "...",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = AtomicAmber
                        )
                    }

                    if (currentState.ordinal >= TransactionState.ATOMIC_EXECUTION.ordinal && currentState != TransactionState.REFUNDED) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "REVEALED PREIMAGE (S):",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = AtomicTextMuted
                            )
                            Text(
                                text = "0x" + transaction.preimageHex.take(16) + "...",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = AtomicGreen
                            )
                        }
                    }

                    if (transaction.proofHash.isNotBlank()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "MERKLE FINALITY PROOF:",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = AtomicTextMuted
                            )
                            Text(
                                text = transaction.proofHash.take(18) + "...",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = AtomicBlueLight
                            )
                        }
                    }
                }
            }

            // Synchronous Multi-Leg Status Cards
            Text(
                text = "SYNCHRONOUS SETTLEMENT LEGS (ALL-OR-NOTHING):",
                style = MaterialTheme.typography.labelSmall,
                color = AtomicTextSecondary,
                fontFamily = FontFamily.Monospace
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                transaction.legs.forEach { leg ->
                    LegCard(
                        leg = leg,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // State Transition Progress Nodes
            StateTransitionSteps(currentState = currentState)
        }
    }
}

@Composable
private fun LegCard(
    leg: com.example.atomic.model.SwapLeg,
    modifier: Modifier = Modifier
) {
    val statusColor = when (leg.status) {
        LegStatus.SETTLED -> AtomicGreen
        LegStatus.LOCKED, LegStatus.VERIFIED -> AtomicAmber
        LegStatus.REFUNDED -> AtomicGold
        LegStatus.FAILED -> AtomicRed
        LegStatus.PENDING -> AtomicTextMuted
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AtomicNavyDark)
            .border(1.dp, statusColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LEG #${leg.legIndex}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicTextPrimary
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(statusColor.copy(alpha = 0.2f))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = leg.status.name,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = statusColor
                    )
                }
            }

            Text(
                text = "${"%,.2f".format(leg.amount)} ${leg.assetSymbol}",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = AtomicTextPrimary
            )

            Text(
                text = "Network: ${leg.sourceNetworkId}",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = AtomicTextSecondary,
                maxLines = 1
            )

            if (leg.lockTxHash != null) {
                Text(
                    text = "Lock: ${leg.lockTxHash.take(12)}...",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicBlueLight
                )
            }
            if (leg.settleTxHash != null) {
                Text(
                    text = "Settle: ${leg.settleTxHash.take(12)}...",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicGreenLight
                )
            }
            if (leg.refundTxHash != null) {
                Text(
                    text = "Refund: ${leg.refundTxHash.take(12)}...",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicAmberLight
                )
            }
        }
    }
}

@Composable
private fun StateTransitionSteps(currentState: TransactionState) {
    val steps = listOf(
        "QUOTE",
        "AUTH",
        "LOCK",
        "VERIFY",
        "SECRET",
        "SETTLE",
        "FINAL"
    )

    val currentStepIndex = when (currentState) {
        TransactionState.QUOTED -> 0
        TransactionState.AUTHORISED, TransactionState.FUNDED -> 1
        TransactionState.LOCKED -> 2
        TransactionState.VERIFIED -> 3
        TransactionState.ATOMIC_EXECUTION -> 4
        TransactionState.SETTLED -> 5
        TransactionState.FINAL -> 6
        TransactionState.EXPIRED, TransactionState.REFUNDED, TransactionState.FAILED -> 3 // refund branch
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEachIndexed { index, stepName ->
            val isCompleted = index <= currentStepIndex && currentState != TransactionState.REFUNDED && currentState != TransactionState.FAILED
            val isCurrent = index == currentStepIndex
            val stepColor = if (isCurrent) AtomicBlue else if (isCompleted) AtomicGreen else AtomicBorder

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(if (isCompleted || isCurrent) stepColor else AtomicSurface)
                        .border(1.dp, stepColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(10.dp)
                        )
                    }
                }
                Text(
                    text = stepName,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                    color = if (isCurrent) AtomicBlue else if (isCompleted) AtomicTextPrimary else AtomicTextMuted
                )
            }

            if (index < steps.size - 1) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(2.dp)
                        .background(if (index < currentStepIndex) AtomicGreen else AtomicBorder)
                        .padding(horizontal = 2.dp)
                )
            }
        }
    }
}
