package com.example.atomic.model

enum class OrderSide {
    BUY,
    SELL
}

data class LimitOrder(
    val orderId: String,
    val pair: String,
    val side: OrderSide,
    val price: Double,
    val amount: Double,
    val totalUsd: Double,
    val participant: String,
    val timestamp: Long,
    val isFilled: Boolean = false
)

data class OrderBook(
    val pair: String,
    val bids: List<LimitOrder>,
    val asks: List<LimitOrder>,
    val spreadAbsolute: Double,
    val spreadBps: Double,
    val midPrice: Double,
    val depth24hUsd: Double
)

enum class RfqStatus {
    ACTIVE,
    ACCEPTED,
    EXPIRED,
    REJECTED
}

data class RFQQuote(
    val quoteId: String,
    val dealerName: String,
    val dealerLei: String,
    val fromAsset: String,
    val toAsset: String,
    val fromAmount: Double,
    val quotedToAmount: Double,
    val effectiveRate: Double,
    val spreadBps: Double,
    val guaranteedUntilEpoch: Long,
    val settlementMechanism: String,
    val status: RfqStatus = RfqStatus.ACTIVE,
    val atomicityProtocol: String = "HTLC-Sha256-PvP"
)
