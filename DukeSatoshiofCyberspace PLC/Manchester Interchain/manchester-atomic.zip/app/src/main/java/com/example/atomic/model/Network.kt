package com.example.atomic.model

enum class NetworkType(val label: String) {
    CBDC_RTGS("Central Bank RTGS Core"),
    EVM_MAINNET("EVM Layer 1 Smart Escrow"),
    EVM_L2("EVM Layer 2 Rollup"),
    BITCOIN_UTXO("Bitcoin Script UTXO / HTLC"),
    PRIVACY_DLT("Institutional Canton / Corda DLT"),
    TOKENISED_BANKING("Regulated Liability Network")
}

enum class NetworkStatus(val label: String, val colorHex: Long) {
    OPERATIONAL("Operational (Finality Guaranteed)", 0xFF00E599),
    CONGESTED("Elevated Latency", 0xFFF59E0B),
    DEGRADED("Partial Sync", 0xFFF97316),
    SIMULATED_ACTIVE("Active Simulation Mode", 0xFF38BDF8),
    HALTED("Emergency Circuit Breaker Halted", 0xFFEF4444)
}

data class NetworkInfo(
    val networkId: String,
    val name: String,
    val type: NetworkType,
    val consensus: String,
    val averageFinalitySeconds: Double,
    val latencyMs: Long,
    val gasFeeUsd: Double,
    val status: NetworkStatus,
    val blockHeightOrLedgerSeq: Long,
    val validatorCount: Int,
    val settlementAdapterName: String,
    val isSimulated: Boolean
)

object NetworkRegistry {
    val BOE_CBDC = NetworkInfo(
        networkId = "BOE-RTGS-CBDC",
        name = "Bank of England Synthetic CBDC Core",
        type = NetworkType.CBDC_RTGS,
        consensus = "Central Bank Direct Synchronous Settlement (PvP Core)",
        averageFinalitySeconds = 0.4,
        latencyMs = 45,
        gasFeeUsd = 0.00,
        status = NetworkStatus.SIMULATED_ACTIVE,
        blockHeightOrLedgerSeq = 48920194L,
        validatorCount = 12,
        settlementAdapterName = "BoePvPAdapter",
        isSimulated = true
    )

    val FED_CBDC = NetworkInfo(
        networkId = "FED-RTGS-CBDC",
        name = "Federal Reserve Digital Synthetic Fedwire",
        type = NetworkType.CBDC_RTGS,
        consensus = "FedNow Synthetic Atomic Core",
        averageFinalitySeconds = 0.5,
        latencyMs = 62,
        gasFeeUsd = 0.00,
        status = NetworkStatus.SIMULATED_ACTIVE,
        blockHeightOrLedgerSeq = 89104820L,
        validatorCount = 18,
        settlementAdapterName = "FedwireAtomicAdapter",
        isSimulated = true
    )

    val ECB_CBDC = NetworkInfo(
        networkId = "ECB-TIPS-CBDC",
        name = "ECB TIPS Synthetic Digital Euro",
        type = NetworkType.CBDC_RTGS,
        consensus = "TIPS Atomic Instant Settlement Engine",
        averageFinalitySeconds = 0.6,
        latencyMs = 58,
        gasFeeUsd = 0.00,
        status = NetworkStatus.SIMULATED_ACTIVE,
        blockHeightOrLedgerSeq = 31940120L,
        validatorCount = 15,
        settlementAdapterName = "EcbTipsAdapter",
        isSimulated = true
    )

    val BITCOIN = NetworkInfo(
        networkId = "BITCOIN-MAINNET",
        name = "Bitcoin UTXO Network",
        type = NetworkType.BITCOIN_UTXO,
        consensus = "SHA-256 Proof of Work (HTLC BIP-199 Script)",
        averageFinalitySeconds = 600.0,
        latencyMs = 420,
        gasFeeUsd = 4.25,
        status = NetworkStatus.OPERATIONAL,
        blockHeightOrLedgerSeq = 884920L,
        validatorCount = 18500,
        settlementAdapterName = "BitcoinHtlcAdapter",
        isSimulated = false
    )

    val ETHEREUM = NetworkInfo(
        networkId = "ETHEREUM-MAINNET",
        name = "Ethereum Mainnet",
        type = NetworkType.EVM_MAINNET,
        consensus = "Proof-of-Stake (Atomic Smart Escrow)",
        averageFinalitySeconds = 12.0,
        latencyMs = 110,
        gasFeeUsd = 8.50,
        status = NetworkStatus.OPERATIONAL,
        blockHeightOrLedgerSeq = 21984210L,
        validatorCount = 980000,
        settlementAdapterName = "EvmAtomicEscrowAdapter",
        isSimulated = false
    )

    val ARBITRUM = NetworkInfo(
        networkId = "ARBITRUM-ONE",
        name = "Arbitrum One L2",
        type = NetworkType.EVM_L2,
        consensus = "Nitro Rollup (Sub-second Soft Finality)",
        averageFinalitySeconds = 1.2,
        latencyMs = 35,
        gasFeeUsd = 0.12,
        status = NetworkStatus.OPERATIONAL,
        blockHeightOrLedgerSeq = 248910220L,
        validatorCount = 20,
        settlementAdapterName = "EvmRollupAdapter",
        isSimulated = false
    )

    val CANTON_DLT = NetworkInfo(
        networkId = "CANTON-CORDA-DLT",
        name = "Canton Network Institutional DLT",
        type = NetworkType.PRIVACY_DLT,
        consensus = "Privacy-Preserving Canton Sub-Transaction Atomic Protocol",
        averageFinalitySeconds = 0.8,
        latencyMs = 80,
        gasFeeUsd = 0.05,
        status = NetworkStatus.SIMULATED_ACTIVE,
        blockHeightOrLedgerSeq = 1420188L,
        validatorCount = 45,
        settlementAdapterName = "CantonAtomicAdapter",
        isSimulated = true
    )

    val UK_RLN = NetworkInfo(
        networkId = "UK-TOKENISED-BANKING",
        name = "UK Regulated Liability Network (RLN)",
        type = NetworkType.TOKENISED_BANKING,
        consensus = "Commercial Bank Multi-Token Atomic Synchroniser",
        averageFinalitySeconds = 0.7,
        latencyMs = 70,
        gasFeeUsd = 0.01,
        status = NetworkStatus.SIMULATED_ACTIVE,
        blockHeightOrLedgerSeq = 5510290L,
        validatorCount = 8,
        settlementAdapterName = "RlnDepositAdapter",
        isSimulated = true
    )

    val ALL_NETWORKS = listOf(
        BOE_CBDC, FED_CBDC, ECB_CBDC, BITCOIN, ETHEREUM, ARBITRUM, CANTON_DLT, UK_RLN
    )

    fun getById(id: String): NetworkInfo {
        return ALL_NETWORKS.find { it.networkId.equals(id, ignoreCase = true) } ?: BOE_CBDC
    }
}
