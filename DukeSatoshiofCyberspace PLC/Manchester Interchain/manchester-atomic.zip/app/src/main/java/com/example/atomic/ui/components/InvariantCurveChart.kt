package com.example.atomic.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.atomic.model.InvariantType
import com.example.atomic.model.LiquidityPool
import com.example.ui.theme.*

@Composable
fun InvariantCurveChart(
    pool: LiquidityPool,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(AtomicNavyDark)
            .border(1.dp, AtomicBorder, RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "INVARIANT CURVE & OPERATING DEPTH",
                    style = MaterialTheme.typography.titleSmall,
                    fontSize = 11.sp,
                    color = AtomicTextSecondary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = pool.invariantType.displayName,
                    fontSize = 10.sp,
                    color = AtomicGreen,
                    fontFamily = FontFamily.Monospace
                )
            }

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                val w = size.width
                val h = size.height
                val pad = 16f

                // Draw Grid
                for (i in 1..4) {
                    val y = pad + (h - 2 * pad) * (i / 4f)
                    drawLine(
                        color = Color(0xFF1B283D),
                        start = Offset(pad, y),
                        end = Offset(w - pad, y),
                        strokeWidth = 1f
                    )
                    val x = pad + (w - 2 * pad) * (i / 4f)
                    drawLine(
                        color = Color(0xFF1B283D),
                        start = Offset(x, pad),
                        end = Offset(x, h - pad),
                        strokeWidth = 1f
                    )
                }

                val path = Path()
                val steps = 60

                when (pool.invariantType) {
                    InvariantType.CONSTANT_PRODUCT -> {
                        // Hyperbola y = k/x
                        for (i in 0..steps) {
                            val normX = i / steps.toFloat()
                            val xPos = pad + normX * (w - 2 * pad)
                            val t = 0.15f + normX * 0.85f
                            val normY = (0.25f / t).coerceIn(0.1f, 0.95f)
                            val yPos = (h - pad) - (normY * (h - 2 * pad))
                            if (i == 0) path.moveTo(xPos, yPos) else path.lineTo(xPos, yPos)
                        }
                    }
                    InvariantType.STABLE_SWAP -> {
                        // Very flat curve near center (stable swap)
                        for (i in 0..steps) {
                            val normX = i / steps.toFloat()
                            val xPos = pad + normX * (w - 2 * pad)
                            // Linear with slight curvature at edges
                            val dev = (normX - 0.5f) * 2f
                            val normY = (1.0f - normX) + 0.15f * (dev * dev * dev)
                            val yPos = (h - pad) - (normY.coerceIn(0.05f, 0.95f) * (h - 2 * pad))
                            if (i == 0) path.moveTo(xPos, yPos) else path.lineTo(xPos, yPos)
                        }
                    }
                    InvariantType.WEIGHTED_MULTI_ASSET -> {
                        // Weighted surface
                        for (i in 0..steps) {
                            val normX = i / steps.toFloat()
                            val xPos = pad + normX * (w - 2 * pad)
                            val t = (1.0f - normX).coerceIn(0.05f, 0.95f)
                            val normY = Math.pow(t.toDouble(), 0.75).toFloat()
                            val yPos = (h - pad) - (normY * (h - 2 * pad))
                            if (i == 0) path.moveTo(xPos, yPos) else path.lineTo(xPos, yPos)
                        }
                    }
                }

                drawPath(
                    path = path,
                    color = AtomicGreen,
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )

                // Draw Current Operating Point
                val opX = w * 0.52f
                val opY = h * 0.48f
                drawCircle(
                    color = AtomicGreenDim,
                    radius = 12f,
                    center = Offset(opX, opY)
                )
                drawCircle(
                    color = AtomicGreen,
                    radius = 6f,
                    center = Offset(opX, opY)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Formula: ${pool.invariantType.formulaDescription}",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AtomicTextMuted
                )
                Text(
                    text = "Health: ${pool.poolHealthScore}/100",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = AtomicGreenLight
                )
            }
        }
    }
}
