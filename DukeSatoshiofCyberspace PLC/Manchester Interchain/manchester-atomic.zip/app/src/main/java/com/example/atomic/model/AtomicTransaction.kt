package com.example.atomic.model

enum class TransactionState(val label: String, val colorHex: Long) {
    QUOTED("Quoted", 0xFF94A3B8),
    AUTHORISED("Authorised by Treasury", 0xFF38BDF8),
    FUNDED("Funded & Ready", 0xFF60A5FA),
    LOCKED("Dual-Legs Locked in Escrow", 0xFFF59E0B),
    VERIFIED("Cryptographic Proofs Verified", 0xFFA78BFA),
    ATOMIC_EXECUTION("Atomic Secret Revealed", 0xFF00E599),
    SETTLED("Settled (Synchronised)", 0xFF00E599),
    FINAL("Finality Irrevocable", 0xFF10B981),
    EXPIRED("Timelock Expired", 0xFFF97316),
    REFUNDED("Refunded Safely to Parties", 0xFFEAB308),
    FAILED("Execution Halted / Reverted", 0xFFEF4444)
}

enum class LegStatus {
    PENDING,
    LOCKED,
    VERIFIED,
    SETTLED,
    REFUNDED,
    FAILED
}

data class SwapLeg(
    val legId: String,
    val legIndex: Int,
    val sourceNetworkId: String,
    val destinationNetworkId: String,
    val assetSymbol: String,
    val amount: Double,
    val senderAccount: String,
    val receiverAccount: String,
    val escrowContractOrScript: String,
    val lockTxHash: String? = null,
    val settleTxHash: String? = null,
    val refundTxHash: String? = null,
    val status: LegStatus = LegStatus.PENDING,
    val confirmationsRequired: Int = 1,
    val currentConfirmations: Int = 0,
    val lockTimestamp: Long = 0L,
    val settleTimestamp: Long = 0L
)

enum class RouteType(val label: String) {
    DIRECT_POOL("Direct AMM Pool"),
    MULTI_HOP_POOL("Multi-Hop Cross-Pool"),
    RFQ_DEALER("Institutional RFQ Dealer"),
    ORDERBOOK_SPLIT("Order Book Limit Depth"),
    AGGREGATED("Aggregated Multi-Venue Split")
}

data class ExecutionRoute(
    val routeId: String,
    val routeType: RouteType,
    val description: String,
    val pathTokens: List<String>,
    val poolIds: List<String>,
    val effectiveRate: Double,
    val priceImpactPercent: Double,
    val feeUsd: Double,
    val estimatedGasUsd: Double,
    val estimatedFinalitySeconds: Double,
    val atomicityScorePercent: Int = 100,
    val counterpartyOrPoolName: String,
    val splitRatio: Map<String, Double> = emptyMap()
)

data class AtomicTransaction(
    val id: String,
    val timestamp: Long,
    val fromAssetSymbol: String,
    val toAssetSymbol: String,
    val fromAmount: Double,
    val expectedToAmount: Double,
    val actualToAmount: Double,
    val state: TransactionState,
    val hashLockHex: String,
    val preimageHex: String,
    val timeLockDeadlineEpoch: Long,
    val route: ExecutionRoute,
    val legs: List<SwapLeg>,
    val complianceStatus: String = "APPROVED_INSTITUTIONAL_TIER_1",
    val proofHash: String = "",
    val failureReason: String? = null,
    val isMultiHop: Boolean = false,
    val initiatorParticipant: String = "Manchester Treasury Desk (LEI: 984500F123MANCHEST01)"
)
