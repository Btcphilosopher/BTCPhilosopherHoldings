package com.example.atomic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.atomic.model.OrderSide
import com.example.atomic.model.RFQQuote
import com.example.atomic.ui.components.OrderBookLadder
import com.example.atomic.viewmodel.AtomicViewModel
import com.example.ui.theme.*

@Composable
fun RfqOrderBookScreen(
    viewModel: AtomicViewModel,
    onNavigateToSwap: () -> Unit,
    modifier: Modifier = Modifier
) {
    val orderBookState by viewModel.orderBookState.collectAsState()
    val swapState by viewModel.swapState.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0: RFQ Desk, 1: Order Book Ladder
    var limitPriceStr by remember { mutableStateOf("1.2854") }
    var limitAmountStr by remember { mutableStateOf("5000000") }
    var selectedSide by remember { mutableStateOf(OrderSide.BUY) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AtomicBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tab Selector Row (RFQ Desk vs Order Book)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(AtomicSurfaceElevated)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                TabButton(
                    label = "INSTITUTIONAL RFQ DESK",
                    isSelected = activeTab == 0,
                    modifier = Modifier.weight(1f)
                ) { activeTab = 0 }

                TabButton(
                    label = "LIMIT ORDER BOOK",
                    isSelected = activeTab == 1,
                    modifier = Modifier.weight(1f)
                ) { activeTab = 1 }
            }
        }

        if (activeTab == 0) {
            // RFQ Desk Mode
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AtomicSurfaceElevated),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorder))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "MULTI-DEALER RFQ ENGINE",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = AtomicTextPrimary
                                )
                                Text(
                                    text = "Requesting: ${"%,.0f".format(swapState.fromAmount)} ${swapState.fromAsset.symbol} → ${swapState.toAsset.symbol}",
                                    fontSize = 11.sp,
                                    color = AtomicGreen
                                )
                            }

                            IconButton(
                                onClick = { viewModel.refreshRfqQuotes() },
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(AtomicNavyDark)
                                    .testTag("refresh_rfq_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Refresh RFQ",
                                    tint = AtomicBlue
                                )
                            }
                        }

                        Text(
                            text = "COMPETING INSTITUTIONAL DEALER QUOTES (HTLC ATOMIC PVP):",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = AtomicTextMuted
                        )
                    }
                }
            }

            items(orderBookState.activeRfqQuotes) { quote ->
                RfqQuoteCard(
                    quote = quote,
                    onAccept = {
                        viewModel.acceptRfqQuote(quote)
                        onNavigateToSwap()
                    }
                )
            }
        } else {
            // Limit Order Book Mode
            item {
                OrderBookLadder(orderBook = orderBookState.orderBook)
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AtomicSurfaceElevated),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorder))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "PLACE INSTITUTIONAL LIMIT ORDER",
                            style = MaterialTheme.typography.titleSmall,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = AtomicTextPrimary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { selectedSide = OrderSide.BUY },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedSide == OrderSide.BUY) AtomicGreen else AtomicNavyDark,
                                    contentColor = if (selectedSide == OrderSide.BUY) Color.Black else AtomicTextSecondary
                                ),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("BID (BUY)", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { selectedSide = OrderSide.SELL },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedSide == OrderSide.SELL) AtomicRed else AtomicNavyDark,
                                    contentColor = if (selectedSide == OrderSide.SELL) Color.White else AtomicTextSecondary
                                ),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("ASK (SELL)", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        }

                        OutlinedTextField(
                            value = limitPriceStr,
                            onValueChange = { limitPriceStr = it },
                            label = { Text("Limit Price (USD)") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = AtomicNavyDark,
                                unfocusedContainerColor = AtomicNavyDark,
                                focusedBorderColor = AtomicBlue,
                                focusedTextColor = AtomicTextPrimary,
                                unfocusedTextColor = AtomicTextPrimary
                            )
                        )

                        OutlinedTextField(
                            value = limitAmountStr,
                            onValueChange = { limitAmountStr = it },
                            label = { Text("Order Size (GBP-CBDC)") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = AtomicNavyDark,
                                unfocusedContainerColor = AtomicNavyDark,
                                focusedBorderColor = AtomicBlue,
                                focusedTextColor = AtomicTextPrimary,
                                unfocusedTextColor = AtomicTextPrimary
                            )
                        )

                        Button(
                            onClick = {},
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AtomicBlue, contentColor = Color.Black),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("SUBMIT TO ORDER BOOK", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RfqQuoteCard(quote: RFQQuote, onAccept: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AtomicSurfaceCard),
        shape = RoundedCornerShape(10.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorderSubtle))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = quote.dealerName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = AtomicTextPrimary
                    )
                    Text(
                        text = quote.dealerLei,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = AtomicTextMuted
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(AtomicGreenDim)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${quote.spreadBps} BPS SPREAD",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = AtomicGreenLight
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "EXECUTABLE RATE", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AtomicTextSecondary)
                    Text(text = "1 ${quote.fromAsset} = ${"%.6f".format(quote.effectiveRate)}", fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AtomicGreen)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "YOU RECEIVE", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AtomicTextSecondary)
                    Text(text = "${"%,.2f".format(quote.quotedToAmount)} ${quote.toAsset}", fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AtomicTextPrimary)
                }
            }

            Button(
                onClick = onAccept,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .testTag("accept_rfq_${quote.quoteId}"),
                colors = ButtonDefaults.buttonColors(containerColor = AtomicGreen, contentColor = Color.Black),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(text = "ROUTE & ATOMICALLY SETTLE WITH DEALER", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun TabButton(label: String, isSelected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) AtomicNavyDark else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = if (isSelected) AtomicGreen else AtomicTextSecondary
        )
    }
}
