package com.example.atomic.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "atomic_transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val fromAssetSymbol: String,
    val toAssetSymbol: String,
    val fromAmount: Double,
    val expectedToAmount: Double,
    val actualToAmount: Double,
    val state: String,
    val hashLockHex: String,
    val preimageHex: String,
    val timeLockDeadlineEpoch: Long,
    val routeType: String,
    val routeDescription: String,
    val effectiveRate: Double,
    val priceImpactPercent: Double,
    val feeUsd: Double,
    val complianceStatus: String,
    val proofHash: String,
    val failureReason: String?,
    val isMultiHop: Boolean
)

@Entity(tableName = "atomic_pools")
data class PoolEntity(
    @PrimaryKey val poolId: String,
    val name: String,
    val invariantType: String,
    val reservesJson: String, // serialized json or comma delimited
    val weightsJson: String,
    val ampCoefficient: Double,
    val feeBps: Int,
    val tvlUsd: Double,
    val volume24hUsd: Double,
    val fees24hUsd: Double,
    val lpTokenTotalSupply: Double,
    val userLpShares: Double,
    val isFlagship: Boolean
)

@Entity(tableName = "atomic_audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val logId: Long = 0,
    val timestamp: Long,
    val transactionId: String,
    val eventType: String,
    val description: String,
    val cryptographicProof: String,
    val operator: String
)
