package com.example.atomic.engine

import com.example.atomic.crypto.CryptoEngine
import com.example.atomic.model.*
import kotlinx.coroutines.delay

interface NetworkSettlementAdapter {
    val networkId: String
    val adapterName: String

    suspend fun discoverCapabilities(): Map<String, Any>
    suspend fun lockEscrow(
        txId: String,
        legIndex: Int,
        asset: String,
        amount: Double,
        hashLockHex: String,
        timelockSeconds: Long,
        sender: String,
        recipient: String
    ): String // returns lock tx hash

    suspend fun verifyLockedCondition(
        lockTxHash: String,
        expectedHashLock: String
    ): Boolean

    suspend fun executeSettlementWithPreimage(
        lockTxHash: String,
        preimageHex: String
    ): String // returns settlement tx hash

    suspend fun executeRefundTimelock(
        lockTxHash: String
    ): String // returns refund tx hash
}

class BaseNetworkAdapter(
    override val networkId: String,
    override val adapterName: String,
    private val simulatedLatencyMs: Long = 100
) : NetworkSettlementAdapter {

    override suspend fun discoverCapabilities(): Map<String, Any> {
        return mapOf(
            "network" to networkId,
            "adapter" to adapterName,
            "supportsHtlc" to true,
            "supportsAdaptorSignatures" to true,
            "supportsSmartEscrow" to true,
            "deterministicFinality" to true
        )
    }

    override suspend fun lockEscrow(
        txId: String,
        legIndex: Int,
        asset: String,
        amount: Double,
        hashLockHex: String,
        timelockSeconds: Long,
        sender: String,
        recipient: String
    ): String {
        delay(simulatedLatencyMs)
        val nonce = System.currentTimeMillis()
        return CryptoEngine.generateDeterministicTxHash(txId, legIndex, asset, amount, nonce)
    }

    override suspend fun verifyLockedCondition(
        lockTxHash: String,
        expectedHashLock: String
    ): Boolean {
        delay(simulatedLatencyMs / 2)
        return lockTxHash.isNotBlank() && expectedHashLock.length == 64
    }

    override suspend fun executeSettlementWithPreimage(
        lockTxHash: String,
        preimageHex: String
    ): String {
        delay(simulatedLatencyMs)
        val settleNonce = System.currentTimeMillis() + 999
        return "0x" + CryptoEngine.sha256("SETTLE|$lockTxHash|$preimageHex|$settleNonce")
    }

    override suspend fun executeRefundTimelock(
        lockTxHash: String
    ): String {
        delay(simulatedLatencyMs)
        val refundNonce = System.currentTimeMillis() + 8888
        return "0x" + CryptoEngine.sha256("REFUND_TIMELOCK_EXPIRED|$lockTxHash|$refundNonce")
    }
}

object NetworkAdapterManager {
    private val adapters = mapOf(
        "BOE-RTGS-CBDC" to BaseNetworkAdapter("BOE-RTGS-CBDC", "BoePvPAdapter", 50),
        "FED-RTGS-CBDC" to BaseNetworkAdapter("FED-RTGS-CBDC", "FedwireAtomicAdapter", 60),
        "ECB-TIPS-CBDC" to BaseNetworkAdapter("ECB-TIPS-CBDC", "EcbTipsAdapter", 55),
        "BITCOIN-MAINNET" to BaseNetworkAdapter("BITCOIN-MAINNET", "BitcoinHtlcAdapter", 150),
        "ETHEREUM-MAINNET" to BaseNetworkAdapter("ETHEREUM-MAINNET", "EvmAtomicEscrowAdapter", 120),
        "ARBITRUM-ONE" to BaseNetworkAdapter("ARBITRUM-ONE", "EvmRollupAdapter", 40),
        "CANTON-CORDA-DLT" to BaseNetworkAdapter("CANTON-CORDA-DLT", "CantonAtomicAdapter", 65),
        "UK-TOKENISED-BANKING" to BaseNetworkAdapter("UK-TOKENISED-BANKING", "RlnDepositAdapter", 60)
    )

    fun getAdapter(networkId: String): NetworkSettlementAdapter {
        return adapters[networkId] ?: BaseNetworkAdapter(networkId, "GenericHtlcAdapter", 80)
    }
}
