package com.example.atomic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.atomic.model.ScenarioId
import com.example.atomic.viewmodel.AtomicViewModel
import com.example.ui.theme.*

@Composable
fun StressLabScreen(
    viewModel: AtomicViewModel,
    modifier: Modifier = Modifier
) {
    val stressResult by viewModel.stressResult.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AtomicBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AtomicSurfaceElevated),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorder))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(imageVector = Icons.Default.Science, contentDescription = null, tint = AtomicAmber, modifier = Modifier.size(20.dp))
                            Text(
                                text = "STRESS & SCENARIO LABORATORY",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = AtomicTextPrimary
                            )
                        }
                        Text(
                            text = "Deterministic Byzantine Fault Injection & Atomic Refund Verification",
                            style = MaterialTheme.typography.bodySmall,
                            color = AtomicTextSecondary
                        )
                    }
                }
            }
        }

        // Live Simulation Result Card (if active or finished)
        stressResult?.let { res ->
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AtomicNavyDark),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(if (res.isRunning) AtomicAmber else AtomicGreen)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = res.scenarioId.title.uppercase(),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = AtomicAmber
                            )
                            if (res.isRunning) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = AtomicAmber, strokeWidth = 2.dp)
                            }
                        }

                        LinearProgressIndicator(
                            progress = { res.progressPercent / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (res.progressPercent == 100) AtomicGreen else AtomicAmber,
                            trackColor = AtomicSurface
                        )

                        Text(
                            text = res.atomicSafetyVerdict,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = if (res.progressPercent == 100) AtomicGreen else AtomicTextPrimary
                        )

                        Text(
                            text = res.explanation,
                            fontSize = 11.sp,
                            color = AtomicTextSecondary
                        )

                        Divider(color = AtomicBorderSubtle)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "FUNDS PRESERVED", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AtomicTextMuted)
                                Text(text = "$${"%,.0f".format(res.fundsPreservedUsd)}", fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AtomicGreen)
                            }
                            Column {
                                Text(text = "ROLLED BACK TXS", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AtomicTextMuted)
                                Text(text = "${res.rolledBackTransactionsCount} (Refunded)", fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AtomicAmber)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "PRINCIPAL LOST", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AtomicTextMuted)
                                Text(text = "$0.00 (0.00%)", fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AtomicGreen)
                            }
                        }
                    }
                }
            }
        }

        // Stress Vectors List
        item {
            Text(
                text = "SELECT STRESS SCENARIO TO INJECT:",
                style = MaterialTheme.typography.titleSmall,
                fontSize = 11.sp,
                color = AtomicTextSecondary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(ScenarioId.values().toList()) { scenario ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AtomicSurfaceCard),
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AtomicBorderSubtle))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = scenario.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = AtomicTextPrimary
                        )
                        Text(
                            text = scenario.shortDesc,
                            fontSize = 10.sp,
                            color = AtomicTextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { viewModel.runStressScenario(scenario) },
                        colors = ButtonDefaults.buttonColors(containerColor = AtomicAmber, contentColor = Color.Black),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("run_stress_${scenario.name}")
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "INJECT", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
