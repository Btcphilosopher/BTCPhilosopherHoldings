package com.example.atomic.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.atomic.model.NetworkRegistry
import com.example.ui.theme.*

@Composable
fun InstitutionalHeader(
    modifier: Modifier = Modifier,
    activeTabName: String = "SETTLEMENT TERMINAL"
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = AtomicSurface,
        tonalElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(AtomicGreenDim)
                            .border(1.dp, AtomicGreen, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Atomic Lock",
                            tint = AtomicGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "MANCHESTER ATOMIC",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = AtomicTextPrimary,
                                letterSpacing = 1.sp
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(AtomicGreenDim)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "INSTITUTIONAL CORE",
                                    color = AtomicGreenLight,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Text(
                            text = "Cross-Chain DvP / PvP Settlement & Multi-Asset Liquidity",
                            style = MaterialTheme.typography.bodySmall,
                            color = AtomicTextSecondary
                        )
                    }
                }

                // Institutional Compliance Badge
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(AtomicSurfaceElevated)
                        .border(1.dp, AtomicBorder, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("compliance_badge"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Compliant",
                        tint = AtomicBlue,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "LEI: 984500F123",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = AtomicBlueLight
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Live Network Health Ticker
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(AtomicNavyDark)
                    .border(1.dp, AtomicBorderSubtle, RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    NetworkStatusPill("BoE RTGS", true)
                    NetworkStatusPill("Fedwire", true)
                    NetworkStatusPill("Bitcoin UTXO", true)
                    NetworkStatusPill("EVM Escrow", true)
                }

                Text(
                    text = "ATOMIC GUARANTEE: SHA-256 / TIMELOCK SYNCHRONISED",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    color = AtomicGreen
                )
            }
        }
    }
}

@Composable
private fun NetworkStatusPill(name: String, isHealthy: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(if (isHealthy) AtomicGreen else AtomicAmber)
        )
        Text(
            text = name,
            fontSize = 10.sp,
            color = AtomicTextSecondary,
            fontFamily = FontFamily.Monospace
        )
    }
}
