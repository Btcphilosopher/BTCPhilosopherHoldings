package com.example.atomic.model

data class TreasuryHolding(
    val assetSymbol: String,
    val totalBalance: Double,
    val lockedInEscrow: Double,
    val availableBalance: Double,
    val usdValue: Double,
    val targetAllocationPct: Double,
    val currentAllocationPct: Double,
    val yieldApy: Double = 0.0
)

data class CollateralPool(
    val collateralAssetSymbol: String,
    val haircutPercent: Double,
    val maxLtvPercent: Double,
    val eligibleAsMargin: Boolean,
    val depositedAmount: Double,
    val effectiveCollateralValueUsd: Double,
    val concentrationLimitUsd: Double
)

data class TreasurySummary(
    val totalNavUsd: Double,
    val settlementBufferUsd: Double,
    val lockedInActiveSwapsUsd: Double,
    val availableLiquidityUsd: Double,
    val dailyTurnoverUsd: Double,
    val var99Usd: Double,
    val expectedShortfallUsd: Double,
    val marginHealthScore: Int
)
