package com.example.atomic.model

data class SettlementProof(
    val proofId: String,
    val transactionId: String,
    val legIndex: Int,
    val networkId: String,
    val blockNumberOrLedgerSeq: Long,
    val transactionHash: String,
    val stateRootHash: String,
    val hashLockSha256: String,
    val preimageSecretHex: String,
    val merkleRoot: String,
    val cryptographicSignature: String,
    val validatorWitness: String,
    val timestamp: Long,
    val isFinalized: Boolean,
    val replayProtectionNonce: Long
)
