package com.example.atomic.engine

import com.example.atomic.model.*
import java.util.UUID

object LiquidityRouter {
    fun findBestRoutes(
        fromAsset: Asset,
        toAsset: Asset,
        amountIn: Double,
        availablePools: List<LiquidityPool>
    ): List<ExecutionRoute> {
        val routes = mutableListOf<ExecutionRoute>()

        // 1. Direct Pool Routes
        val directPools = availablePools.filter {
            it.assetReserves.containsKey(fromAsset.symbol) && it.assetReserves.containsKey(toAsset.symbol)
        }

        for (pool in directPools) {
            val (amountOut, priceImpact) = PricingEngine.calculateOutputAmountAndImpact(fromAsset, toAsset, amountIn, pool)
            val effectiveRate = if (amountIn > 0) amountOut / amountIn else 0.0
            val feeUsd = amountIn * fromAsset.referencePriceUsd * (pool.feeBps / 10000.0)
            val netFrom = NetworkRegistry.getById(fromAsset.networkId)
            val netTo = NetworkRegistry.getById(toAsset.networkId)
            val gasEst = netFrom.gasFeeUsd + netTo.gasFeeUsd
            val finalityEst = maxOf(netFrom.averageFinalitySeconds, netTo.averageFinalitySeconds)

            routes.add(
                ExecutionRoute(
                    routeId = "ROUTE-DIR-${pool.poolId.takeLast(6)}",
                    routeType = RouteType.DIRECT_POOL,
                    description = "Direct Pool Execution via ${pool.name}",
                    pathTokens = listOf(fromAsset.symbol, toAsset.symbol),
                    poolIds = listOf(pool.poolId),
                    effectiveRate = effectiveRate,
                    priceImpactPercent = priceImpact,
                    feeUsd = feeUsd,
                    estimatedGasUsd = gasEst,
                    estimatedFinalitySeconds = finalityEst,
                    atomicityScorePercent = 100,
                    counterpartyOrPoolName = pool.name
                )
            )
        }

        // 2. Multi-Hop Route (via USDC or USD-CBDC as intermediate liquidity bridge)
        val intermediateTokens = listOf("USDC", "USD-CBDC")
        for (interSymbol in intermediateTokens) {
            if (fromAsset.symbol != interSymbol && toAsset.symbol != interSymbol) {
                val interAsset = AssetRegistry.getBySymbol(interSymbol)
                val poolHop1 = availablePools.find { it.assetReserves.containsKey(fromAsset.symbol) && it.assetReserves.containsKey(interSymbol) }
                val poolHop2 = availablePools.find { it.assetReserves.containsKey(interSymbol) && it.assetReserves.containsKey(toAsset.symbol) }

                if (poolHop1 != null && poolHop2 != null) {
                    val (hop1Out, impact1) = PricingEngine.calculateOutputAmountAndImpact(fromAsset, interAsset, amountIn, poolHop1)
                    val (hop2Out, impact2) = PricingEngine.calculateOutputAmountAndImpact(interAsset, toAsset, hop1Out, poolHop2)
                    val totalImpact = impact1 + impact2
                    val effectiveRate = if (amountIn > 0) hop2Out / amountIn else 0.0
                    val feeUsd = (amountIn * fromAsset.referencePriceUsd * (poolHop1.feeBps / 10000.0)) +
                            (hop1Out * interAsset.referencePriceUsd * (poolHop2.feeBps / 10000.0))

                    val netFrom = NetworkRegistry.getById(fromAsset.networkId)
                    val netInter = NetworkRegistry.getById(interAsset.networkId)
                    val netTo = NetworkRegistry.getById(toAsset.networkId)
                    val gasEst = netFrom.gasFeeUsd + netInter.gasFeeUsd + netTo.gasFeeUsd
                    val finalityEst = maxOf(netFrom.averageFinalitySeconds, netInter.averageFinalitySeconds, netTo.averageFinalitySeconds)

                    routes.add(
                        ExecutionRoute(
                            routeId = "ROUTE-HOP-$interSymbol",
                            routeType = RouteType.MULTI_HOP_POOL,
                            description = "Multi-Hop Cross-Chain Route: ${fromAsset.symbol} → $interSymbol → ${toAsset.symbol}",
                            pathTokens = listOf(fromAsset.symbol, interSymbol, toAsset.symbol),
                            poolIds = listOf(poolHop1.poolId, poolHop2.poolId),
                            effectiveRate = effectiveRate,
                            priceImpactPercent = totalImpact,
                            feeUsd = feeUsd,
                            estimatedGasUsd = gasEst,
                            estimatedFinalitySeconds = finalityEst,
                            atomicityScorePercent = 100,
                            counterpartyOrPoolName = "Multi-Hop Bridge (${poolHop1.poolId} + ${poolHop2.poolId})"
                        )
                    )
                }
            }
        }

        // 3. Institutional RFQ Dealer Route
        val nominalRate = fromAsset.referencePriceUsd / toAsset.referencePriceUsd
        val rfqRate = nominalRate * 0.9997 // tight 3 bps institutional spread
        val rfqFeeUsd = amountIn * fromAsset.referencePriceUsd * 0.0002
        routes.add(
            ExecutionRoute(
                routeId = "ROUTE-RFQ-JANE-STREET",
                routeType = RouteType.RFQ_DEALER,
                description = "Institutional RFQ Bilateral Stream via Jane Street Global",
                pathTokens = listOf(fromAsset.symbol, toAsset.symbol),
                poolIds = emptyList(),
                effectiveRate = rfqRate,
                priceImpactPercent = 0.01,
                feeUsd = rfqFeeUsd,
                estimatedGasUsd = 0.50,
                estimatedFinalitySeconds = 0.6,
                atomicityScorePercent = 100,
                counterpartyOrPoolName = "Jane Street Global Liquidity (Bilateral HTLC)"
            )
        )

        // 4. Aggregated Split (65% Flagship Pool + 35% RFQ)
        val aggRate = (nominalRate * 0.9996)
        routes.add(
            ExecutionRoute(
                routeId = "ROUTE-AGG-SPLIT",
                routeType = RouteType.AGGREGATED,
                description = "Smart Split: 65% Manchester Pool + 35% Citadel RFQ",
                pathTokens = listOf(fromAsset.symbol, toAsset.symbol),
                poolIds = listOf("POOL-MCR-UNIV-01"),
                effectiveRate = aggRate,
                priceImpactPercent = 0.02,
                feeUsd = (amountIn * fromAsset.referencePriceUsd * 0.0003),
                estimatedGasUsd = 1.20,
                estimatedFinalitySeconds = 0.8,
                atomicityScorePercent = 100,
                counterpartyOrPoolName = "Manchester Smart Liquidity Aggregator",
                splitRatio = mapOf("POOL-MCR-UNIV-01" to 0.65, "CITADEL-RFQ" to 0.35)
            )
        )

        return routes.sortedByDescending { it.effectiveRate }
    }
}
