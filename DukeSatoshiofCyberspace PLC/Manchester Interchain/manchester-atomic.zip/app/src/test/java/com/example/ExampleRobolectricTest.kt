package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.atomic.crypto.CryptoEngine
import com.example.atomic.engine.PricingEngine
import com.example.atomic.model.AssetRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun readStringFromContext() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Manchester ATOMIC", appName)
    }

    @Test
    fun testSha256PreimageVerification() {
        val preimage = CryptoEngine.generatePreimage()
        val hashLock = CryptoEngine.sha256(preimage)
        assertTrue(CryptoEngine.verifyPreimage(preimage, hashLock))
    }

    @Test
    fun testSpotRateCalculation() {
        val rate = PricingEngine.calculateSpotRate(AssetRegistry.GBP_CBDC, AssetRegistry.USDC, null)
        assertEquals(1.2850, rate, 0.001)
    }
}
