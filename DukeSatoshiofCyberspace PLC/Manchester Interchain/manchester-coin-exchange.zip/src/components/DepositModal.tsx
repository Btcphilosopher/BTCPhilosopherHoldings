import React, { useState } from 'react';
import { useExchange } from '../store/exchangeStore';
import { AssetSymbol } from '../types/exchange';
import { ASSETS_REGISTRY } from '../data/initialMarkets';
import { X, CheckCircle, ArrowDownToLine, Copy } from 'lucide-react';

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DepositModal: React.FC<DepositModalProps> = ({ isOpen, onClose }) => {
  const { balances, depositFunds } = useExchange();
  const [selectedAsset, setSelectedAsset] = useState<AssetSymbol>('GBP');
  const [amount, setAmount] = useState<string>('25000');
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const info = ASSETS_REGISTRY[selectedAsset];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (isNaN(val) || val <= 0) return;
    depositFunds(selectedAsset, val);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 2000);
  };

  const handleCopyIban = () => {
    navigator.clipboard?.writeText(
      selectedAsset === 'GBP' ? 'GB29MCX040004812345678' : `0xMCX${selectedAsset}VaultDeposit`
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
      <div className="bg-[#12151c] border-2 border-[#842226] rounded-sm max-w-lg w-full p-6 relative shadow-2xl space-y-4">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-[#717887] hover:text-white p-1 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-sm bg-[#842226] flex items-center justify-center text-white">
            <ArrowDownToLine className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-display font-bold text-white text-lg">
              Institutional Asset Deposit
            </h3>
            <span className="text-xs text-[#8e95a5]">
              Instant Faster Payments clearing &amp; Deep Cold Vault custody
            </span>
          </div>
        </div>

        {/* Asset selection */}
        <div>
          <label className="block text-xs text-[#8e95a5] mb-1.5 font-medium">Select Asset</label>
          <div className="grid grid-cols-4 gap-2">
            {balances.map((b) => (
              <button
                key={b.asset}
                type="button"
                onClick={() => setSelectedAsset(b.asset)}
                className={`py-2 text-xs font-mono font-bold rounded-sm border cursor-pointer transition-colors ${
                  selectedAsset === b.asset
                    ? 'bg-[#842226] text-white border-[#b23238]'
                    : 'bg-[#181d26] text-[#8e95a5] border-[#252c3c] hover:text-white'
                }`}
              >
                {b.asset}
              </button>
            ))}
          </div>
        </div>

        {/* Account Details Box */}
        <div className="bg-[#0b0d10] p-3 rounded-sm border border-[#1f242e] text-xs font-mono-num space-y-1">
          <span className="text-[10px] text-[#717887] uppercase block">
            {info.isFiat ? 'UK Faster Payments / CHAPS Account' : 'Segregated Taproot Vault Address'}
          </span>
          <div className="flex items-center justify-between text-white font-mono text-[11px] bg-[#161a24] p-2 rounded">
            <span className="truncate">
              {info.isFiat
                ? 'GB29MCX040004812345678 (Sort: 04-00-04)'
                : `0xMCX${selectedAsset}VaultManchesterCold${selectedAsset}99`}
            </span>
            <button
              onClick={handleCopyIban}
              className="text-[#8e95a5] hover:text-white ml-2 cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>
          </div>
          {copied && <span className="text-[10px] text-emerald-400">Copied to clipboard</span>}
        </div>

        {/* Amount Input */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs text-[#8e95a5] mb-1 font-medium">
              Deposit Amount ({selectedAsset})
            </label>
            <input
              type="number"
              step="any"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-[#0b0d10] border border-[#272e3d] text-white text-base font-mono-num px-3 py-2 rounded-sm focus:outline-none focus:border-[#842226]"
              placeholder="0.00"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-[#842226] hover:bg-[#9f2a2f] text-white font-bold py-3 rounded-sm text-xs uppercase tracking-wider transition-colors cursor-pointer border border-[#b23238]"
          >
            Credit Funds to Segregated Account
          </button>

          {submitted && (
            <div className="p-3 bg-emerald-950/40 text-emerald-300 border border-emerald-700 rounded text-xs flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>Funds successfully credited and reconciled in double-entry ledger!</span>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
