import React, { useState, useMemo } from 'react';
import { useExchange } from '../store/exchangeStore';
import { OrderSide, OrderType, Candle } from '../types/exchange';
import {
  TrendingUp,
  TrendingDown,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
  XCircle,
  AlertCircle,
  RefreshCw,
  Sliders,
  DollarSign,
  ChevronDown,
} from 'lucide-react';

export const MarketTerminal: React.FC = () => {
  const {
    markets,
    activeMarketId,
    activeMarket,
    setActiveMarketId,
    orderBook,
    recentTrades,
    candles,
    timeframe,
    setTimeframe,
    userOrders,
    userFills,
    balances,
    submitUserOrder,
    cancelUserOrder,
    recentLedgerEntries,
  } = useExchange();

  // Order Entry State
  const [side, setSide] = useState<OrderSide>('BUY');
  const [orderType, setOrderType] = useState<OrderType>('LIMIT');
  const [priceInput, setPriceInput] = useState<string>(activeMarket.lastPrice.toString());
  const [sizeInput, setSizeInput] = useState<string>('0.25');
  const [orderMessage, setOrderMessage] = useState<{ text: string; isError: boolean } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeBottomTab, setActiveBottomTab] = useState<'open' | 'fills' | 'balances' | 'ledger'>('open');
  const [bookViewTab, setBookViewTab] = useState<'book' | 'depth' | 'trades'>('book');

  // Hovered candle for crosshair tooltip
  const [hoveredCandle, setHoveredCandle] = useState<Candle | null>(null);

  // When active market changes, reset default price input
  React.useEffect(() => {
    setPriceInput(activeMarket.lastPrice.toString());
  }, [activeMarket.lastPrice, activeMarketId]);

  // Balance helpers
  const quoteBalance = balances.find((b) => b.asset === activeMarket.quoteAsset);
  const baseBalance = balances.find((b) => b.asset === activeMarket.baseAsset);

  const numPrice = parseFloat(priceInput) || 0;
  const numSize = parseFloat(sizeInput) || 0;
  const estimatedTotal = numPrice * numSize;
  const estimatedFee = estimatedTotal * (orderType === 'MARKET' ? activeMarket.takerFeeRate : activeMarket.makerFeeRate);

  const handlePercentageClick = (pct: number) => {
    if (side === 'BUY') {
      const avail = quoteBalance?.available || 0;
      if (avail <= 0) return;
      const budget = (avail * pct) / (1 + activeMarket.makerFeeRate);
      const calcPrice = orderType === 'MARKET' ? activeMarket.askPrice : numPrice || activeMarket.lastPrice;
      if (calcPrice > 0) {
        const calculatedSize = Math.floor((budget / calcPrice) * 10000) / 10000;
        setSizeInput(calculatedSize.toString());
      }
    } else {
      const avail = baseBalance?.available || 0;
      if (avail <= 0) return;
      const calculatedSize = Math.floor(avail * pct * 10000) / 10000;
      setSizeInput(calculatedSize.toString());
    }
  };

  const handlePriceClick = (price: number) => {
    setPriceInput(price.toFixed(activeMarket.priceDecimals));
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setOrderMessage(null);

    const price = orderType === 'MARKET' ? (side === 'BUY' ? activeMarket.askPrice : activeMarket.bidPrice) : parseFloat(priceInput);
    const size = parseFloat(sizeInput);

    if (isNaN(size) || size <= 0) {
      setOrderMessage({ text: 'Please enter a valid order size', isError: true });
      setIsSubmitting(false);
      return;
    }

    if (orderType === 'LIMIT' && (isNaN(price) || price <= 0)) {
      setOrderMessage({ text: 'Please enter a valid limit price', isError: true });
      setIsSubmitting(false);
      return;
    }

    const res = submitUserOrder({
      marketId: activeMarket.id,
      side,
      type: orderType,
      price,
      size,
    });

    setOrderMessage({
      text: res.message,
      isError: !res.success,
    });

    setIsSubmitting(false);

    // Auto clear notification after 6s
    setTimeout(() => {
      setOrderMessage(null);
    }, 6000);
  };

  // Open orders for this market
  const activeOrders = useMemo(() => {
    return userOrders.filter(
      (o) => o.marketId === activeMarketId && (o.status === 'OPEN' || o.status === 'PARTIALLY_FILLED')
    );
  }, [userOrders, activeMarketId]);

  // Max totals for depth bar percentage in order book
  const maxBidTotal = useMemo(() => {
    return Math.max(...orderBook.bids.map((b) => b.total), 1);
  }, [orderBook.bids]);

  const maxAskTotal = useMemo(() => {
    return Math.max(...orderBook.asks.map((a) => a.total), 1);
  }, [orderBook.asks]);

  // SVG Candlestick geometry calculations
  const chartHeight = 320;
  const chartWidth = 720;
  const candleMetrics = useMemo(() => {
    if (!candles || candles.length === 0) return null;
    let minPrice = Infinity;
    let maxPrice = -Infinity;
    let maxVol = 0;

    candles.forEach((c) => {
      if (c.low < minPrice) minPrice = c.low;
      if (c.high > maxPrice) maxPrice = c.high;
      if (c.volume > maxVol) maxVol = c.volume;
    });

    const priceRange = maxPrice - minPrice || 1;
    const padding = priceRange * 0.05;
    const effectiveMin = minPrice - padding;
    const effectiveMax = maxPrice + padding;
    const effectiveRange = effectiveMax - effectiveMin;

    return {
      minPrice: effectiveMin,
      maxPrice: effectiveMax,
      priceRange: effectiveRange,
      maxVol: maxVol || 1,
    };
  }, [candles]);

  return (
    <div className="bg-[#0b0d10] text-[#e8e4db] min-h-[calc(100vh-100px)]">
      {/* Institutional Market Header Banner */}
      <div className="bg-[#101319] border-b border-[#1f242e] px-4 py-3">
        <div className="max-w-[1720px] mx-auto flex flex-wrap items-center justify-between gap-4">
          {/* Pair Selector & Flagship branding */}
          <div className="flex items-center space-x-4">
            <div className="relative group">
              <select
                aria-label="Trading Pair"
                value={activeMarketId}
                onChange={(e) => setActiveMarketId(e.target.value)}
                className="appearance-none bg-[#181c25] hover:bg-[#202532] text-white font-display font-bold text-base border border-[#333a49] py-1.5 pl-3 pr-8 rounded-sm cursor-pointer focus:outline-none focus:border-[#842226]"
              >
                {markets.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.displayName}
                  </option>
                ))}
              </select>
              <ChevronDown className="w-4 h-4 text-[#9ea6b5] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            <div className="flex items-center space-x-2">
              <span className="font-mono-num text-2xl font-black text-white tracking-tight">
                {activeMarket.quoteAsset === 'GBP' ? '£' : '$'}
                {activeMarket.lastPrice.toLocaleString(undefined, {
                  minimumFractionDigits: activeMarket.priceDecimals,
                  maximumFractionDigits: activeMarket.priceDecimals,
                })}
              </span>
              <span
                className={`inline-flex items-center text-xs font-bold px-2 py-0.5 rounded ${
                  activeMarket.change24h >= 0
                    ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                    : 'bg-[#842226]/30 text-[#e67a7f] border border-[#842226]/50'
                }`}
              >
                {activeMarket.change24h >= 0 ? <TrendingUp className="w-3.5 h-3.5 mr-1" /> : <TrendingDown className="w-3.5 h-3.5 mr-1" />}
                {activeMarket.change24h >= 0 ? '+' : ''}
                {activeMarket.change24h.toFixed(2)}%
              </span>
            </div>
          </div>

          {/* 24h Statistics Strip */}
          <div className="flex flex-wrap items-center gap-6 font-mono-num text-xs">
            <div>
              <span className="text-[#7c8393] uppercase block text-[10px] tracking-wider">24h High</span>
              <span className="text-white font-semibold">
                {activeMarket.quoteAsset === 'GBP' ? '£' : '$'}
                {activeMarket.high24h.toLocaleString(undefined, { minimumFractionDigits: activeMarket.priceDecimals })}
              </span>
            </div>

            <div>
              <span className="text-[#7c8393] uppercase block text-[10px] tracking-wider">24h Low</span>
              <span className="text-white font-semibold">
                {activeMarket.quoteAsset === 'GBP' ? '£' : '$'}
                {activeMarket.low24h.toLocaleString(undefined, { minimumFractionDigits: activeMarket.priceDecimals })}
              </span>
            </div>

            <div>
              <span className="text-[#7c8393] uppercase block text-[10px] tracking-wider">24h Volume ({activeMarket.quoteAsset})</span>
              <span className="text-white font-semibold">
                {activeMarket.quoteAsset === 'GBP' ? '£' : '$'}
                {(activeMarket.volume24hQuote / 1000000).toFixed(2)}M
              </span>
            </div>

            <div>
              <span className="text-[#7c8393] uppercase block text-[10px] tracking-wider">Market Spread</span>
              <span className="text-[#c59f5b] font-semibold">
                {activeMarket.spread.toFixed(2)}% ({(activeMarket.askPrice - activeMarket.bidPrice).toFixed(activeMarket.priceDecimals)})
              </span>
            </div>

            <div className="hidden lg:block pl-4 border-l border-[#222731]">
              <span className="text-[#7c8393] uppercase block text-[10px] tracking-wider">Settlement Architecture</span>
              <span className="text-emerald-400 font-semibold text-[11px]">
                {activeMarket.quoteAsset === 'GBP' ? 'Bank of England CHAPS / FPS' : 'ERC-20 Treasury Reserve'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Terminal Grid */}
      <div className="max-w-[1720px] mx-auto p-3 lg:p-4 grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left Column: Candlestick Chart (7 cols on lg) */}
        <div className="lg:col-span-7 flex flex-col space-y-3">
          <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-3">
            {/* Chart Toolbar */}
            <div className="flex items-center justify-between pb-3 border-b border-[#1f242e] text-xs">
              <div className="flex items-center space-x-1">
                <span className="text-[#8e95a5] mr-2 font-display text-[11px] uppercase tracking-wider">Timeframe:</span>
                {['1M', '5M', '15M', '1H', '1D', '1W'].map((tf) => (
                  <button
                    key={tf}
                    onClick={() => setTimeframe(tf)}
                    className={`px-2.5 py-1 text-xs rounded-sm transition-colors cursor-pointer ${
                      timeframe === tf
                        ? 'bg-[#842226] text-white font-bold'
                        : 'text-[#9ea6b5] hover:bg-[#1a1e27] hover:text-white'
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>

              {/* Crosshair reading */}
              {hoveredCandle ? (
                <div className="hidden sm:flex items-center space-x-3 font-mono-num text-[11px]">
                  <span className="text-[#8e95a5]">O: <strong className="text-white">{hoveredCandle.open}</strong></span>
                  <span className="text-[#8e95a5]">H: <strong className="text-emerald-400">{hoveredCandle.high}</strong></span>
                  <span className="text-[#8e95a5]">L: <strong className="text-[#c94046]">{hoveredCandle.low}</strong></span>
                  <span className="text-[#8e95a5]">C: <strong className="text-white">{hoveredCandle.close}</strong></span>
                  <span className="text-[#8e95a5]">Vol: <strong className="text-[#c59f5b]">{hoveredCandle.volume}</strong></span>
                </div>
              ) : (
                <div className="text-[11px] text-[#717887] flex items-center space-x-1">
                  <Clock className="w-3 h-3 text-[#842226]" />
                  <span>Interactive Manchester Price Discovery</span>
                </div>
              )}
            </div>

            {/* SVG Candlestick & Volume Chart Canvas */}
            <div className="relative w-full h-[360px] pt-3 overflow-hidden select-none bg-[#0e1015]">
              {candleMetrics && candles.length > 0 && (
                <svg
                  viewBox={`0 0 ${chartWidth} ${chartHeight}`}
                  className="w-full h-full"
                  preserveAspectRatio="none"
                >
                  <defs>
                    <linearGradient id="volGradBull" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" stopOpacity="0.3" />
                      <stop offset="100%" stopColor="#10b981" stopOpacity="0.05" />
                    </linearGradient>
                    <linearGradient id="volGradBear" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#842226" stopOpacity="0.3" />
                      <stop offset="100%" stopColor="#842226" stopOpacity="0.05" />
                    </linearGradient>
                  </defs>

                  {/* Horizontal Grid lines */}
                  {[0.2, 0.4, 0.6, 0.8].map((pct, i) => {
                    const y = chartHeight * 0.8 * pct;
                    const priceAtY = candleMetrics.maxPrice - pct * candleMetrics.priceRange;
                    return (
                      <g key={i}>
                        <line
                          x1="0"
                          y1={y}
                          x2={chartWidth}
                          y2={y}
                          stroke="#1a1e28"
                          strokeDasharray="3 3"
                        />
                        <text
                          x={chartWidth - 5}
                          y={y - 4}
                          textAnchor="end"
                          fill="#4c5364"
                          fontSize="10"
                          fontFamily="JetBrains Mono"
                        >
                          {priceAtY.toFixed(activeMarket.priceDecimals)}
                        </text>
                      </g>
                    );
                  })}

                  {/* Candlesticks & Volume Bars */}
                  {candles.map((c, i) => {
                    const candleWidth = chartWidth / candles.length;
                    const x = i * candleWidth + candleWidth * 0.15;
                    const width = candleWidth * 0.7;
                    const centerX = x + width / 2;

                    const chartPriceArea = chartHeight * 0.75;
                    const chartVolArea = chartHeight * 0.22;

                    // Y mappings
                    const yHigh =
                      chartPriceArea * (1 - (c.high - candleMetrics.minPrice) / candleMetrics.priceRange);
                    const yLow =
                      chartPriceArea * (1 - (c.low - candleMetrics.minPrice) / candleMetrics.priceRange);
                    const yOpen =
                      chartPriceArea * (1 - (c.open - candleMetrics.minPrice) / candleMetrics.priceRange);
                    const yClose =
                      chartPriceArea * (1 - (c.close - candleMetrics.minPrice) / candleMetrics.priceRange);

                    const isBull = c.close >= c.open;
                    const bodyTop = Math.min(yOpen, yClose);
                    const bodyHeight = Math.max(Math.abs(yClose - yOpen), 1.5);

                    // Volume bar
                    const volHeight = (c.volume / candleMetrics.maxVol) * chartVolArea;
                    const volY = chartHeight - volHeight;

                    return (
                      <g
                        key={c.timestamp + i}
                        onMouseEnter={() => setHoveredCandle(c)}
                        onMouseLeave={() => setHoveredCandle(null)}
                        className="cursor-crosshair group"
                      >
                        {/* Volume Bar */}
                        <rect
                          x={x}
                          y={volY}
                          width={width}
                          height={volHeight}
                          fill={isBull ? '#10b981' : '#842226'}
                          opacity={0.35}
                        />

                        {/* Wick */}
                        <line
                          x1={centerX}
                          y1={yHigh}
                          x2={centerX}
                          y2={yLow}
                          stroke={isBull ? '#10b981' : '#842226'}
                          strokeWidth="1.2"
                        />

                        {/* Candle Body */}
                        <rect
                          x={x}
                          y={bodyTop}
                          width={width}
                          height={bodyHeight}
                          fill={isBull ? '#10b981' : '#842226'}
                          stroke={isBull ? '#10b981' : '#9e2a2f'}
                          strokeWidth="0.8"
                          rx="0.5"
                        />
                      </g>
                    );
                  })}
                </svg>
              )}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-[#1f242e] text-[10px] text-[#767e8f]">
              <span>MANCHESTER COIN EXCHANGE DETERMINISTIC PRICE FORMATION</span>
              <span>24H SPREAD DISCOVERY • ULTRA-LOW 38µS EXECUTION</span>
            </div>
          </div>
        </div>

        {/* Middle Column: Order Book & Recent Trades (3 cols on lg) */}
        <div className="lg:col-span-3 flex flex-col space-y-3">
          <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-3 flex flex-col h-[420px]">
            {/* View Switcher */}
            <div className="flex items-center justify-between pb-2 border-b border-[#1f242e] text-xs">
              <div className="flex items-center space-x-1">
                <button
                  onClick={() => setBookViewTab('book')}
                  className={`px-2 py-1 rounded text-xs cursor-pointer font-medium ${
                    bookViewTab === 'book' ? 'bg-[#842226] text-white' : 'text-[#8e95a5] hover:text-white'
                  }`}
                >
                  Order Book
                </button>
                <button
                  onClick={() => setBookViewTab('trades')}
                  className={`px-2 py-1 rounded text-xs cursor-pointer font-medium ${
                    bookViewTab === 'trades' ? 'bg-[#842226] text-white' : 'text-[#8e95a5] hover:text-white'
                  }`}
                >
                  Trades
                </button>
                <button
                  onClick={() => setBookViewTab('depth')}
                  className={`px-2 py-1 rounded text-xs cursor-pointer font-medium ${
                    bookViewTab === 'depth' ? 'bg-[#842226] text-white' : 'text-[#8e95a5] hover:text-white'
                  }`}
                >
                  Depth
                </button>
              </div>
              <span className="text-[10px] font-mono-num text-[#842226] font-bold">L2 REAL-TIME</span>
            </div>

            {bookViewTab === 'book' && (
              <div className="flex flex-col flex-1 overflow-hidden font-mono-num text-[11px] pt-2">
                <div className="grid grid-cols-3 text-[10px] text-[#767e8f] pb-1 border-b border-[#1c202a] uppercase tracking-wider">
                  <span>Price ({activeMarket.quoteAsset})</span>
                  <span className="text-right">Size ({activeMarket.baseAsset})</span>
                  <span className="text-right">Total</span>
                </div>

                {/* Asks (Sells) - Sorted ascending from bottom up */}
                <div className="flex flex-col-reverse overflow-y-auto max-h-[140px] no-scrollbar py-1">
                  {orderBook.asks.slice(0, 8).map((ask, idx) => {
                    const depthPercent = Math.min((ask.total / maxAskTotal) * 100, 100);
                    return (
                      <div
                        key={`ask_${idx}`}
                        onClick={() => handlePriceClick(ask.price)}
                        className="grid grid-cols-3 py-0.5 relative group hover:bg-[#842226]/20 cursor-pointer transition-colors"
                      >
                        <div
                          className="absolute right-0 top-0 bottom-0 bg-[#842226]/20 pointer-events-none"
                          style={{ width: `${depthPercent}%` }}
                        />
                        <span className="text-[#e67a7f] font-semibold z-10">
                          {ask.price.toFixed(activeMarket.priceDecimals)}
                        </span>
                        <span className="text-right text-[#c9cfda] z-10">{ask.size.toFixed(activeMarket.sizeDecimals)}</span>
                        <span className="text-right text-[#80899a] z-10">{ask.total.toFixed(activeMarket.sizeDecimals)}</span>
                      </div>
                    );
                  })}
                </div>

                {/* Mid-Spread Indicator */}
                <div className="py-1.5 my-1 px-2 bg-[#0e1015] border-y border-[#202532] flex items-center justify-between text-xs">
                  <span className="font-bold text-white">
                    {activeMarket.quoteAsset === 'GBP' ? '£' : '$'}
                    {activeMarket.lastPrice.toLocaleString(undefined, { minimumFractionDigits: activeMarket.priceDecimals })}
                  </span>
                  <span className="text-[10px] text-[#c59f5b]">
                    Spread: {activeMarket.spread.toFixed(2)}%
                  </span>
                </div>

                {/* Bids (Buys) */}
                <div className="flex flex-col overflow-y-auto max-h-[140px] no-scrollbar py-1">
                  {orderBook.bids.slice(0, 8).map((bid, idx) => {
                    const depthPercent = Math.min((bid.total / maxBidTotal) * 100, 100);
                    return (
                      <div
                        key={`bid_${idx}`}
                        onClick={() => handlePriceClick(bid.price)}
                        className="grid grid-cols-3 py-0.5 relative group hover:bg-emerald-500/15 cursor-pointer transition-colors"
                      >
                        <div
                          className="absolute right-0 top-0 bottom-0 bg-emerald-500/15 pointer-events-none"
                          style={{ width: `${depthPercent}%` }}
                        />
                        <span className="text-emerald-400 font-semibold z-10">
                          {bid.price.toFixed(activeMarket.priceDecimals)}
                        </span>
                        <span className="text-right text-[#c9cfda] z-10">{bid.size.toFixed(activeMarket.sizeDecimals)}</span>
                        <span className="text-right text-[#80899a] z-10">{bid.total.toFixed(activeMarket.sizeDecimals)}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {bookViewTab === 'trades' && (
              <div className="flex flex-col flex-1 overflow-hidden font-mono-num text-[11px] pt-2">
                <div className="grid grid-cols-3 text-[10px] text-[#767e8f] pb-1 border-b border-[#1c202a] uppercase tracking-wider">
                  <span>Price ({activeMarket.quoteAsset})</span>
                  <span className="text-right">Size</span>
                  <span className="text-right">Time</span>
                </div>
                <div className="overflow-y-auto flex-1 no-scrollbar space-y-1 py-1">
                  {recentTrades.length === 0 ? (
                    <div className="text-[#676f80] text-center py-6 text-xs italic">
                      Awaiting trades on active market...
                    </div>
                  ) : (
                    recentTrades.map((t) => (
                      <div key={t.id} className="grid grid-cols-3 py-0.5 hover:bg-[#1a1e28]">
                        <span className={t.side === 'BUY' ? 'text-emerald-400' : 'text-[#e67a7f]'}>
                          {t.price.toFixed(activeMarket.priceDecimals)}
                        </span>
                        <span className="text-right text-[#c7cbd2]">{t.size.toFixed(activeMarket.sizeDecimals)}</span>
                        <span className="text-right text-[#717887]">
                          {new Date(t.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {bookViewTab === 'depth' && (
              <div className="flex flex-col flex-1 items-center justify-center p-2 text-center">
                <div className="w-full h-36 bg-[#0a0c10] border border-[#1d222c] rounded p-2 flex flex-col justify-end">
                  <div className="flex items-end justify-between h-28 gap-1">
                    {/* Bids curve bars */}
                    <div className="flex-1 flex items-end justify-end space-x-1 h-full">
                      {orderBook.bids.slice(0, 6).reverse().map((b, i) => (
                        <div
                          key={i}
                          className="bg-emerald-500/40 w-3 rounded-t"
                          style={{ height: `${Math.min((b.total / maxBidTotal) * 100, 100)}%` }}
                          title={`Bid: ${b.price} (Size: ${b.total})`}
                        />
                      ))}
                    </div>
                    <div className="w-px h-full bg-[#353c4d]" />
                    {/* Asks curve bars */}
                    <div className="flex-1 flex items-end space-x-1 h-full">
                      {orderBook.asks.slice(0, 6).map((a, i) => (
                        <div
                          key={i}
                          className="bg-[#842226]/60 w-3 rounded-t"
                          style={{ height: `${Math.min((a.total / maxAskTotal) * 100, 100)}%` }}
                          title={`Ask: ${a.price} (Size: ${a.total})`}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="flex justify-between text-[10px] text-[#717887] pt-1 border-t border-[#1d222c]">
                    <span className="text-emerald-400 font-semibold">Cumulative Bids</span>
                    <span className="text-[#e67a7f] font-semibold">Cumulative Asks</span>
                  </div>
                </div>
                <span className="text-[11px] text-[#8e95a5] mt-2">
                  Market Depth: High liquidity cushion in Manchester Vault
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Order Entry Desk (2 cols on lg) */}
        <div className="lg:col-span-2 flex flex-col space-y-3">
          <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-3">
            <div className="pb-2 border-b border-[#1f242e] flex items-center justify-between">
              <span className="font-display uppercase text-xs tracking-wider text-[#d4c6b2] font-semibold">
                Order Execution
              </span>
              <span className="text-[10px] bg-[#1a1f29] px-1.5 py-0.5 rounded text-[#8e95a5] font-mono">
                P-T PRIORITY
              </span>
            </div>

            {/* Buy / Sell Toggle */}
            <div className="grid grid-cols-2 gap-1 my-3 bg-[#0a0c10] p-1 rounded-sm border border-[#1f242e]">
              <button
                type="button"
                onClick={() => setSide('BUY')}
                className={`py-1.5 text-xs font-bold rounded-sm transition-all cursor-pointer ${
                  side === 'BUY'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-[#8e95a5] hover:text-white'
                }`}
              >
                BUY {activeMarket.baseAsset}
              </button>
              <button
                type="button"
                onClick={() => setSide('SELL')}
                className={`py-1.5 text-xs font-bold rounded-sm transition-all cursor-pointer ${
                  side === 'SELL'
                    ? 'bg-[#842226] text-white shadow-sm'
                    : 'text-[#8e95a5] hover:text-white'
                }`}
              >
                SELL {activeMarket.baseAsset}
              </button>
            </div>

            {/* Order Type Toggle */}
            <div className="flex items-center space-x-1 mb-3 text-xs">
              {(['LIMIT', 'MARKET', 'STOP_LIMIT'] as OrderType[]).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setOrderType(t)}
                  className={`flex-1 py-1 text-[11px] rounded transition-colors cursor-pointer ${
                    orderType === t
                      ? 'bg-[#222834] text-white font-semibold border border-[#3b4356]'
                      : 'text-[#7e8596] hover:bg-[#181c25]'
                  }`}
                >
                  {t.replace('_', ' ')}
                </button>
              ))}
            </div>

            {/* Form */}
            <form onSubmit={handleSubmitOrder} className="space-y-3 text-xs">
              {/* Limit Price Input */}
              {orderType !== 'MARKET' && (
                <div>
                  <div className="flex justify-between text-[11px] text-[#7f8797] mb-1">
                    <span>Order Price ({activeMarket.quoteAsset})</span>
                    <button
                      type="button"
                      onClick={() => handlePriceClick(side === 'BUY' ? activeMarket.bidPrice : activeMarket.askPrice)}
                      className="text-[#c59f5b] hover:underline cursor-pointer"
                    >
                      Best {side === 'BUY' ? 'Bid' : 'Ask'}
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type="number"
                      step="any"
                      value={priceInput}
                      onChange={(e) => setPriceInput(e.target.value)}
                      className="w-full bg-[#0a0c10] border border-[#232936] focus:border-[#842226] px-3 py-2 text-white font-mono-num rounded-sm focus:outline-none"
                      placeholder="0.00"
                    />
                    <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#7f8797] font-mono text-[11px]">
                      {activeMarket.quoteAsset}
                    </span>
                  </div>
                </div>
              )}

              {/* Order Size Input */}
              <div>
                <div className="flex justify-between text-[11px] text-[#7f8797] mb-1">
                  <span>Order Quantity</span>
                  <span className="font-mono-num">
                    {side === 'BUY'
                      ? `Avail: ${quoteBalance?.available.toFixed(2) || 0} ${activeMarket.quoteAsset}`
                      : `Avail: ${baseBalance?.available.toFixed(4) || 0} ${activeMarket.baseAsset}`}
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="number"
                    step="any"
                    value={sizeInput}
                    onChange={(e) => setSizeInput(e.target.value)}
                    className="w-full bg-[#0a0c10] border border-[#232936] focus:border-[#842226] px-3 py-2 text-white font-mono-num rounded-sm focus:outline-none"
                    placeholder="0.00"
                  />
                  <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#7f8797] font-mono text-[11px]">
                    {activeMarket.baseAsset}
                  </span>
                </div>
              </div>

              {/* Quick % buttons */}
              <div className="grid grid-cols-4 gap-1">
                {[0.25, 0.5, 0.75, 1.0].map((pct) => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() => handlePercentageClick(pct)}
                    className="bg-[#181d26] hover:bg-[#232a38] text-[#9fa6b2] hover:text-white py-1 rounded text-[10px] font-mono cursor-pointer transition-colors"
                  >
                    {pct * 100}%
                  </button>
                ))}
              </div>

              {/* Total & Fee Estimation */}
              <div className="bg-[#0e1117] p-2.5 rounded-sm border border-[#1b202a] space-y-1 font-mono-num text-[11px]">
                <div className="flex justify-between text-[#828a9b]">
                  <span>Total Value:</span>
                  <span className="text-white font-medium">
                    {activeMarket.quoteAsset === 'GBP' ? '£' : '$'}
                    {estimatedTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between text-[#828a9b]">
                  <span>Est. Fee ({orderType === 'MARKET' ? '0.15% Taker' : '0.08% Maker'}):</span>
                  <span className="text-[#c59f5b]">
                    {activeMarket.quoteAsset === 'GBP' ? '£' : '$'}
                    {estimatedFee.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full py-2.5 rounded-sm text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-md ${
                  side === 'BUY'
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-400/40'
                    : 'bg-[#842226] hover:bg-[#9f2a2f] text-white border border-[#b23238]/60'
                }`}
              >
                {side === 'BUY'
                  ? `Execute Buy ${activeMarket.baseAsset}`
                  : `Execute Sell ${activeMarket.baseAsset}`}
              </button>

              {/* Order Feedback Toast */}
              {orderMessage && (
                <div
                  className={`p-2 rounded text-[11px] flex items-start space-x-1.5 ${
                    orderMessage.isError
                      ? 'bg-red-950/40 text-red-300 border border-red-800/50'
                      : 'bg-[#842226]/20 text-[#eae6dd] border border-[#842226]/60'
                  }`}
                >
                  {orderMessage.isError ? (
                    <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
                  ) : (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  )}
                  <span>{orderMessage.text}</span>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>

      {/* Bottom Management Console (Tabs: Open Orders, Fills, Balances, Ledger Audit) */}
      <div className="max-w-[1720px] mx-auto px-3 lg:px-4 pb-8">
        <div className="bg-[#12151c] border border-[#1f242e] rounded-sm">
          {/* Tab Headers */}
          <div className="flex items-center justify-between border-b border-[#1f242e] px-4 py-2">
            <div className="flex items-center space-x-2 text-xs">
              <button
                onClick={() => setActiveBottomTab('open')}
                className={`px-3 py-1.5 rounded-sm font-medium transition-colors cursor-pointer ${
                  activeBottomTab === 'open'
                    ? 'bg-[#842226] text-white font-semibold'
                    : 'text-[#8e95a5] hover:text-white'
                }`}
              >
                Open Orders ({activeOrders.length})
              </button>

              <button
                onClick={() => setActiveBottomTab('fills')}
                className={`px-3 py-1.5 rounded-sm font-medium transition-colors cursor-pointer ${
                  activeBottomTab === 'fills'
                    ? 'bg-[#842226] text-white font-semibold'
                    : 'text-[#8e95a5] hover:text-white'
                }`}
              >
                Trade Executions ({userFills.length})
              </button>

              <button
                onClick={() => setActiveBottomTab('balances')}
                className={`px-3 py-1.5 rounded-sm font-medium transition-colors cursor-pointer ${
                  activeBottomTab === 'balances'
                    ? 'bg-[#842226] text-white font-semibold'
                    : 'text-[#8e95a5] hover:text-white'
                }`}
              >
                Exchange Balances
              </button>

              <button
                onClick={() => setActiveBottomTab('ledger')}
                className={`px-3 py-1.5 rounded-sm font-medium transition-colors cursor-pointer ${
                  activeBottomTab === 'ledger'
                    ? 'bg-[#842226] text-white font-semibold'
                    : 'text-[#8e95a5] hover:text-white'
                }`}
              >
                Double-Entry Audit Log
              </button>
            </div>

            <span className="text-[10px] text-[#717887] uppercase font-mono">
              MCX Authoritative In-Memory Engine State
            </span>
          </div>

          {/* Tab Contents */}
          <div className="p-3 overflow-x-auto">
            {activeBottomTab === 'open' && (
              <div>
                {activeOrders.length === 0 ? (
                  <div className="text-center py-8 text-[#717887] text-xs">
                    No open resting orders in the matching engine for {activeMarket.displayName}.
                  </div>
                ) : (
                  <table className="w-full text-left font-mono-num text-xs">
                    <thead>
                      <tr className="text-[#717887] text-[10px] border-b border-[#1f242e] uppercase">
                        <th className="pb-2">Order ID</th>
                        <th className="pb-2">Market</th>
                        <th className="pb-2">Side</th>
                        <th className="pb-2">Type</th>
                        <th className="pb-2">Price</th>
                        <th className="pb-2">Size</th>
                        <th className="pb-2">Filled</th>
                        <th className="pb-2">Status</th>
                        <th className="pb-2 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#181d27]">
                      {activeOrders.map((o) => (
                        <tr key={o.id} className="hover:bg-[#161a22]">
                          <td className="py-2.5 font-mono text-[11px] text-[#9fa6b2]">{o.id}</td>
                          <td className="py-2.5 font-semibold text-white">{o.marketId}</td>
                          <td className="py-2.5">
                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                o.side === 'BUY'
                                  ? 'bg-emerald-500/20 text-emerald-400'
                                  : 'bg-[#842226]/30 text-[#e67a7f]'
                              }`}
                            >
                              {o.side}
                            </span>
                          </td>
                          <td className="py-2.5 text-[#9fa6b2]">{o.type}</td>
                          <td className="py-2.5 font-semibold text-white">{o.price.toFixed(activeMarket.priceDecimals)}</td>
                          <td className="py-2.5">{o.size.toFixed(activeMarket.sizeDecimals)}</td>
                          <td className="py-2.5 text-[#8e95a5]">
                            {o.filledSize.toFixed(activeMarket.sizeDecimals)} (
                            {((o.filledSize / o.size) * 100).toFixed(0)}%)
                          </td>
                          <td className="py-2.5">
                            <span className="text-[10px] text-amber-400 font-bold bg-amber-400/10 px-1.5 py-0.5 rounded">
                              {o.status}
                            </span>
                          </td>
                          <td className="py-2.5 text-right">
                            <button
                              onClick={() => cancelUserOrder(o.id)}
                              className="px-2 py-1 text-[10px] bg-red-950/60 hover:bg-red-900 text-red-300 rounded border border-red-800/40 cursor-pointer transition-colors"
                            >
                              Cancel Order
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {activeBottomTab === 'fills' && (
              <div>
                {userFills.length === 0 ? (
                  <div className="text-center py-8 text-[#717887] text-xs">
                    No executions recorded in current trading session yet.
                  </div>
                ) : (
                  <table className="w-full text-left font-mono-num text-xs">
                    <thead>
                      <tr className="text-[#717887] text-[10px] border-b border-[#1f242e] uppercase">
                        <th className="pb-2">Execution Fill ID</th>
                        <th className="pb-2">Market</th>
                        <th className="pb-2">Side</th>
                        <th className="pb-2">Executed Price</th>
                        <th className="pb-2">Executed Size</th>
                        <th className="pb-2">Quote Volume</th>
                        <th className="pb-2">Fee Accrued</th>
                        <th className="pb-2 text-right">Timestamp</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#181d27]">
                      {userFills.map((f) => (
                        <tr key={f.id} className="hover:bg-[#161a22]">
                          <td className="py-2.5 font-mono text-[11px] text-[#9fa6b2]">{f.id}</td>
                          <td className="py-2.5 font-semibold text-white">{f.marketId}</td>
                          <td className="py-2.5">
                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                f.side === 'BUY'
                                  ? 'bg-emerald-500/20 text-emerald-400'
                                  : 'bg-[#842226]/30 text-[#e67a7f]'
                              }`}
                            >
                              {f.side}
                            </span>
                          </td>
                          <td className="py-2.5 font-semibold text-white">{f.price.toLocaleString()}</td>
                          <td className="py-2.5">{f.size}</td>
                          <td className="py-2.5 font-medium text-white">{f.quoteVolume.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                          <td className="py-2.5 text-[#c59f5b]">{f.takerFee.toFixed(4)}</td>
                          <td className="py-2.5 text-right text-[#717887]">
                            {new Date(f.timestamp).toLocaleTimeString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {activeBottomTab === 'balances' && (
              <table className="w-full text-left font-mono-num text-xs">
                <thead>
                  <tr className="text-[#717887] text-[10px] border-b border-[#1f242e] uppercase">
                    <th className="pb-2">Asset</th>
                    <th className="pb-2">Available Balance</th>
                    <th className="pb-2">Locked in Orders</th>
                    <th className="pb-2">Total Holdings</th>
                    <th className="pb-2 text-right">GBP Equivalent Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#181d27]">
                  {balances.map((b) => (
                    <tr key={b.asset} className="hover:bg-[#161a22]">
                      <td className="py-2.5 font-bold text-white flex items-center space-x-2">
                        <span className="w-2 h-2 rounded-full bg-[#842226]"></span>
                        <span>{b.asset}</span>
                      </td>
                      <td className="py-2.5 text-emerald-400 font-medium">
                        {b.available.toLocaleString(undefined, { minimumFractionDigits: b.asset === 'GBP' ? 2 : 4 })}
                      </td>
                      <td className="py-2.5 text-[#8e95a5]">
                        {b.locked.toLocaleString(undefined, { minimumFractionDigits: b.asset === 'GBP' ? 2 : 4 })}
                      </td>
                      <td className="py-2.5 font-semibold text-white">
                        {b.total.toLocaleString(undefined, { minimumFractionDigits: b.asset === 'GBP' ? 2 : 4 })}
                      </td>
                      <td className="py-2.5 text-right font-bold text-[#eae6dd]">
                        £{b.gbpValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {activeBottomTab === 'ledger' && (
              <table className="w-full text-left font-mono-num text-xs">
                <thead>
                  <tr className="text-[#717887] text-[10px] border-b border-[#1f242e] uppercase">
                    <th className="pb-2">Ledger Reference</th>
                    <th className="pb-2">Transaction Type</th>
                    <th className="pb-2">Debit Account</th>
                    <th className="pb-2">Credit Account</th>
                    <th className="pb-2">Amount & Asset</th>
                    <th className="pb-2">Description</th>
                    <th className="pb-2 text-right">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#181d27]">
                  {recentLedgerEntries.slice(0, 10).map((l) => (
                    <tr key={l.id} className="hover:bg-[#161a22]">
                      <td className="py-2 font-mono text-[11px] text-[#9fa6b2]">{l.id}</td>
                      <td className="py-2">
                        <span className="text-[10px] bg-[#1a1f29] px-1.5 py-0.5 rounded text-[#c59f5b] font-semibold">
                          {l.type}
                        </span>
                      </td>
                      <td className="py-2 text-[#8e95a5] font-mono text-[11px]">{l.debitAccount}</td>
                      <td className="py-2 text-[#8e95a5] font-mono text-[11px]">{l.creditAccount}</td>
                      <td className="py-2 font-semibold text-white">
                        {l.amount.toLocaleString()} {l.asset}
                      </td>
                      <td className="py-2 text-[#a2abbd] max-w-xs truncate">{l.description}</td>
                      <td className="py-2 text-right text-[#717887]">
                        {new Date(l.timestamp).toLocaleTimeString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
