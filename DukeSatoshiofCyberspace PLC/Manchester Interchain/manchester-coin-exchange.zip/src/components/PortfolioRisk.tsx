import React, { useState } from 'react';
import { useExchange } from '../store/exchangeStore';
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  ShieldAlert,
  Sliders,
  PieChart,
  CheckCircle,
  X,
  FileSpreadsheet,
} from 'lucide-react';

export const PortfolioRisk: React.FC = () => {
  const {
    balances,
    totalPortfolioGBP,
    totalPortfolioUSD,
    stressTestResult,
    runStressScenario,
    clearStressScenario,
  } = useExchange();

  const [selectedRiskTab, setSelectedRiskTab] = useState<'holdings' | 'risk_metrics' | 'stress_lab'>('holdings');

  // Quant metrics
  const var95GBP = Math.round(totalPortfolioGBP * 0.048);
  const var99GBP = Math.round(totalPortfolioGBP * 0.082);
  const cvar99GBP = Math.round(totalPortfolioGBP * 0.114);
  const sharpeRatio = 2.41;

  return (
    <div className="bg-[#0b0d10] text-[#eae6dd] py-8">
      <div className="max-w-[1680px] mx-auto px-4 lg:px-8 space-y-6">
        {/* Header */}
        <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-6">
          <div className="flex flex-wrap items-center justify-between gap-6">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-[#842226] flex items-center justify-center rounded-sm">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-display text-2xl font-bold text-white">
                  Institutional Portfolio &amp; Quantitative Risk Laboratory
                </h2>
                <p className="text-xs text-[#8e95a5]">
                  Basel III compliant Value-at-Risk (VaR), liquidity stress simulation, and capital adequacy metrics.
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-6 font-mono-num text-xs">
              <div>
                <span className="text-[10px] text-[#717887] uppercase block">Total Net Assets (GBP)</span>
                <span className="text-2xl font-black text-white">
                  £{totalPortfolioGBP.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="pl-4 border-l border-[#202532]">
                <span className="text-[10px] text-[#717887] uppercase block">USD Equivalent</span>
                <span className="text-xl font-bold text-[#c59f5b]">
                  ${totalPortfolioUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="pl-4 border-l border-[#202532]">
                <span className="text-[10px] text-[#717887] uppercase block">Unrealized P&amp;L (30d)</span>
                <span className="text-xl font-bold text-emerald-400">+£38,420.50 (+8.4%)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Subtabs */}
        <div className="flex items-center space-x-2 border-b border-[#1f242e] pb-3 text-xs">
          {[
            { id: 'holdings', label: 'Portfolio Asset Holdings' },
            { id: 'risk_metrics', label: 'Quantitative VaR & Exposure' },
            { id: 'stress_lab', label: 'Market Stress Simulation Laboratory' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedRiskTab(tab.id as any)}
              className={`px-4 py-2 rounded-sm font-semibold transition-colors cursor-pointer ${
                selectedRiskTab === tab.id
                  ? 'bg-[#842226] text-white shadow-sm'
                  : 'bg-[#14171f] text-[#8e95a5] hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab 1: Holdings */}
        {selectedRiskTab === 'holdings' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Table */}
            <div className="lg:col-span-8 bg-[#12151c] border border-[#1f242e] rounded-sm p-4 overflow-x-auto">
              <h3 className="font-display font-bold text-white text-base mb-3">
                Custodied Digital Assets Breakdown
              </h3>
              <table className="w-full text-left font-mono-num text-xs">
                <thead>
                  <tr className="bg-[#161a22] text-[#717887] text-[10px] uppercase border-b border-[#202532]">
                    <th className="py-2.5 px-3">Asset</th>
                    <th className="py-2.5 px-3">Total Holdings</th>
                    <th className="py-2.5 px-3">Available</th>
                    <th className="py-2.5 px-3">Locked</th>
                    <th className="py-2.5 px-3">Weight</th>
                    <th className="py-2.5 px-3 text-right">Value (GBP)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1a1e28]">
                  {balances.map((b) => {
                    const weightPct = ((b.gbpValue / totalPortfolioGBP) * 100).toFixed(1);
                    return (
                      <tr key={b.asset} className="hover:bg-[#181c25]">
                        <td className="py-3 px-3 font-bold text-white flex items-center space-x-2">
                          <span className="w-2 h-2 rounded-full bg-[#842226]"></span>
                          <span>{b.asset}</span>
                        </td>
                        <td className="py-3 px-3 text-white font-medium">
                          {b.total.toLocaleString(undefined, { minimumFractionDigits: b.asset === 'GBP' ? 2 : 4 })}
                        </td>
                        <td className="py-3 px-3 text-emerald-400">
                          {b.available.toLocaleString(undefined, { minimumFractionDigits: b.asset === 'GBP' ? 2 : 4 })}
                        </td>
                        <td className="py-3 px-3 text-[#8e95a5]">
                          {b.locked.toLocaleString(undefined, { minimumFractionDigits: b.asset === 'GBP' ? 2 : 4 })}
                        </td>
                        <td className="py-3 px-3 text-[#c59f5b]">{weightPct}%</td>
                        <td className="py-3 px-3 text-right font-bold text-white">
                          £{b.gbpValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Allocation Bar & Breakdown */}
            <div className="lg:col-span-4 bg-[#12151c] border border-[#1f242e] rounded-sm p-5 space-y-4">
              <h3 className="font-display font-bold text-white text-base">
                Asset Allocation Weights
              </h3>

              {/* Stacked allocation bar */}
              <div className="h-5 flex rounded-sm overflow-hidden border border-[#262c3b]">
                {balances.map((b) => {
                  const weightPct = (b.gbpValue / totalPortfolioGBP) * 100;
                  const colorMap: Record<string, string> = {
                    BTC: '#f7931a',
                    ETH: '#627eea',
                    SOL: '#14f195',
                    GBP: '#842226',
                    USDC: '#2775ca',
                    USDT: '#26a17b',
                    XRP: '#23292f',
                    EUR: '#c59f5b',
                  };
                  return (
                    <div
                      key={b.asset}
                      style={{
                        width: `${weightPct}%`,
                        backgroundColor: colorMap[b.asset] || '#555',
                      }}
                      title={`${b.asset}: ${weightPct.toFixed(1)}%`}
                    />
                  );
                })}
              </div>

              <div className="space-y-2 font-mono-num text-xs">
                {balances.map((b) => {
                  const weightPct = ((b.gbpValue / totalPortfolioGBP) * 100).toFixed(1);
                  return (
                    <div key={b.asset} className="flex justify-between items-center text-[#8e95a5]">
                      <span className="flex items-center space-x-2">
                        <span className="w-2 h-2 rounded-full bg-[#842226]"></span>
                        <span className="text-white font-medium">{b.asset}</span>
                      </span>
                      <span>{weightPct}% &middot; £{b.gbpValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Quant Risk Metrics */}
        {selectedRiskTab === 'risk_metrics' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 font-mono-num text-xs">
            <div className="p-5 bg-[#12151c] border border-[#1f242e] rounded-sm space-y-2">
              <span className="text-[10px] text-[#717887] uppercase block">Parametric VaR (95%, 1-Day)</span>
              <span className="text-2xl font-bold text-amber-400">£{var95GBP.toLocaleString()}</span>
              <p className="text-[11px] text-[#8e95a5] font-sans">
                95% probability daily downside does not exceed this amount under standard volatility distributions.
              </p>
            </div>

            <div className="p-5 bg-[#12151c] border border-[#1f242e] rounded-sm space-y-2">
              <span className="text-[10px] text-[#717887] uppercase block">Extreme VaR (99%, 1-Day)</span>
              <span className="text-2xl font-bold text-[#e67a7f]">£{var99GBP.toLocaleString()}</span>
              <p className="text-[11px] text-[#8e95a5] font-sans">
                1-in-100 days tail risk limit. Monitored continuously by MCX risk engines.
              </p>
            </div>

            <div className="p-5 bg-[#12151c] border border-[#1f242e] rounded-sm space-y-2">
              <span className="text-[10px] text-[#717887] uppercase block">Expected Shortfall (CVaR)</span>
              <span className="text-2xl font-bold text-red-500">£{cvar99GBP.toLocaleString()}</span>
              <p className="text-[11px] text-[#8e95a5] font-sans">
                Average anticipated tail loss when 99% VaR boundary is breached.
              </p>
            </div>

            <div className="p-5 bg-[#12151c] border border-[#1f242e] rounded-sm space-y-2">
              <span className="text-[10px] text-[#717887] uppercase block">Sharpe Ratio (Annualised)</span>
              <span className="text-2xl font-bold text-emerald-400">{sharpeRatio}</span>
              <p className="text-[11px] text-[#8e95a5] font-sans">
                Risk-adjusted return profile benchmarked against UK Bank of England Base Rate.
              </p>
            </div>
          </div>
        )}

        {/* Tab 3: Market Stress Laboratory */}
        {selectedRiskTab === 'stress_lab' && (
          <div className="space-y-6">
            <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-6 space-y-4">
              <div className="flex items-center space-x-3">
                <AlertTriangle className="w-5 h-5 text-[#c59f5b]" />
                <h3 className="font-display font-bold text-white text-lg">
                  Deterministic Market Stress Testing Simulator
                </h3>
              </div>
              <p className="text-xs text-[#8e95a5]">
                Simulate catastrophic market conditions to assess capital solvency, liquidity evaporation, and portfolio shock.
              </p>

              {/* 4 Scenarios Buttons */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
                <button
                  onClick={() => runStressScenario('FLASH_CRASH_BTC')}
                  className="p-4 bg-[#0a0c10] border border-[#222834] hover:border-[#842226] rounded-sm text-left cursor-pointer transition-colors space-y-2"
                >
                  <span className="text-xs font-bold text-[#e67a7f] block">Scenario 1: BTC Cascade</span>
                  <span className="text-[11px] text-white font-mono block">-35% Global Bitcoin Flash Crash</span>
                  <span className="text-[10px] text-[#8e95a5] block">Cascading exchange liquidations</span>
                </button>

                <button
                  onClick={() => runStressScenario('ETH_LIQUIDITY_SHOCK')}
                  className="p-4 bg-[#0a0c10] border border-[#222834] hover:border-[#842226] rounded-sm text-left cursor-pointer transition-colors space-y-2"
                >
                  <span className="text-xs font-bold text-amber-400 block">Scenario 2: Gas &amp; Liquidity Drain</span>
                  <span className="text-[11px] text-white font-mono block">280 Gwei L1 Congestion</span>
                  <span className="text-[10px] text-[#8e95a5] block">Offshore bridge delays</span>
                </button>

                <button
                  onClick={() => runStressScenario('STABLECOIN_DEPEG')}
                  className="p-4 bg-[#0a0c10] border border-[#222834] hover:border-[#842226] rounded-sm text-left cursor-pointer transition-colors space-y-2"
                >
                  <span className="text-xs font-bold text-blue-400 block">Scenario 3: Stablecoin Depeg</span>
                  <span className="text-[11px] text-white font-mono block">0.91 Off-Shore Fracture</span>
                  <span className="text-[10px] text-[#8e95a5] block">Flight to regulated UK Sterling</span>
                </button>

                <button
                  onClick={() => runStressScenario('STERLING_VOLATILITY')}
                  className="p-4 bg-[#0a0c10] border border-[#222834] hover:border-[#842226] rounded-sm text-left cursor-pointer transition-colors space-y-2"
                >
                  <span className="text-xs font-bold text-emerald-400 block">Scenario 4: Sterling FX Shock</span>
                  <span className="text-[11px] text-white font-mono block">+/- 6.5% GBP/USD Move</span>
                  <span className="text-[10px] text-[#8e95a5] block">Domestic UK hedge flow</span>
                </button>
              </div>
            </div>

            {/* Stress Test Simulation Output Card */}
            {stressTestResult && (
              <div className="bg-[#151922] border-2 border-[#842226] rounded-sm p-6 space-y-4 font-mono-num relative">
                <button
                  onClick={clearStressScenario}
                  className="absolute right-4 top-4 text-[#767e8f] hover:text-white p-1"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="flex items-center space-x-2 text-[#c59f5b]">
                  <ShieldAlert className="w-5 h-5 text-[#842226]" />
                  <span className="font-display font-bold text-lg text-white">
                    Stress Test Output: {stressTestResult.scenarioName}
                  </span>
                </div>

                <p className="text-xs text-[#d4c6b2] font-sans max-w-3xl">
                  {stressTestResult.description}
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                  <div className="p-3 bg-[#0c0e12] rounded border border-[#202532]">
                    <span className="text-[10px] text-[#717887] uppercase block">Portfolio P&amp;L Shock</span>
                    <span className="text-xl font-bold text-[#e67a7f]">
                      {stressTestResult.portfolioShockPercent}% (-£{stressTestResult.portfolioLossGBP.toLocaleString()})
                    </span>
                  </div>
                  <div className="p-3 bg-[#0c0e12] rounded border border-[#202532]">
                    <span className="text-[10px] text-[#717887] uppercase block">Estimated Stress 99% VaR</span>
                    <span className="text-xl font-bold text-amber-400">
                      £{stressTestResult.var99GBP.toLocaleString()}
                    </span>
                  </div>
                  <div className="p-3 bg-[#0c0e12] rounded border border-[#202532]">
                    <span className="text-[10px] text-[#717887] uppercase block">Liquidity Cushion Status</span>
                    <span className="text-xs font-semibold text-emerald-400 block pt-1">
                      {stressTestResult.liquidityImpactScore}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-[#1b202c] border border-[#2e3648] rounded text-xs text-[#eae6dd] flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>
                    <strong>Manchester Risk Committee Recommendation:</strong>{' '}
                    {stressTestResult.stressRecommendation}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
