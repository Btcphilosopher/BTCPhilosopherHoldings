import React from 'react';
import { useExchange } from '../store/exchangeStore';
import {
  TrendingUp,
  LayoutDashboard,
  CandlestickChart,
  Shield,
  Layers,
  BarChart3,
  Terminal,
  Activity,
  Sparkles,
  ArrowDownToLine,
  Landmark,
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onOpenDeposit: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, setCurrentTab, onOpenDeposit }) => {
  const { totalPortfolioGBP, balances } = useExchange();

  const gbpBalance = balances.find((b) => b.asset === 'GBP')?.available || 0;

  const navItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'terminal', label: 'Terminal', icon: CandlestickChart },
    { id: 'markets', label: 'Markets', icon: TrendingUp },
    { id: 'custody', label: 'Custody & Ledger', icon: Shield },
    { id: 'rfq', label: 'Institutional RFQ', icon: Layers },
    { id: 'portfolio', label: 'Portfolio & Risk', icon: BarChart3 },
    { id: 'control', label: 'Control Room', icon: Activity },
    { id: 'api', label: 'API & SDK', icon: Terminal },
    { id: 'concierge', label: 'Market Concierge', icon: Sparkles, highlight: true },
  ];

  return (
    <header className="bg-[#0c0e12] border-b border-[#1f242e] sticky top-0 z-40">
      <div className="max-w-[1680px] mx-auto px-4 lg:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Brand & Crest */}
          <div className="flex items-center space-x-6">
            <button
              onClick={() => setCurrentTab('overview')}
              className="flex items-center space-x-3 group cursor-pointer text-left focus:outline-none"
            >
              <div className="relative flex items-center justify-center w-10 h-10 bg-[#161a22] border-2 border-[#842226] rounded-sm shadow-md group-hover:border-[#c59f5b] transition-all">
                <div className="absolute inset-0 bg-gradient-to-br from-[#842226]/40 via-transparent to-black pointer-events-none"></div>
                <Landmark className="w-5 h-5 text-[#d4c6b2] group-hover:text-[#c59f5b] transition-colors" />
                <span className="absolute -bottom-1 -right-1 w-2.5 h-2.5 bg-[#842226] border border-[#161a22]"></span>
              </div>

              <div className="flex flex-col">
                <div className="flex items-center space-x-2">
                  <span className="font-display font-black text-xl tracking-wider text-white">MCX</span>
                  <span className="h-3.5 w-px bg-[#333a48]"></span>
                  <span className="font-serif-inst italic text-xs text-[#c59f5b] tracking-wide">
                    Manchester, England
                  </span>
                </div>
                <span className="text-[10px] tracking-widest text-[#a89f91] uppercase font-semibold">
                  Manchester Coin Exchange
                </span>
              </div>
            </button>

            {/* Navigation Tabs */}
            <nav className="hidden xl:flex items-center space-x-1 pl-4 border-l border-[#222731]">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentTab(item.id)}
                    className={`flex items-center space-x-1.5 px-3 py-1.5 text-xs font-medium rounded-sm transition-all cursor-pointer ${
                      isActive
                        ? 'bg-[#842226] text-white shadow-sm font-semibold'
                        : item.highlight
                        ? 'text-[#c59f5b] hover:bg-[#1a1e27] hover:text-white border border-[#c59f5b]/30'
                        : 'text-[#9ea6b5] hover:text-[#eae6dd] hover:bg-[#14171e]'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : item.highlight ? 'text-[#c59f5b]' : 'text-[#842226]'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* User & Liquidity Stats & Action */}
          <div className="flex items-center space-x-4">
            <div className="hidden md:flex flex-col text-right font-mono-num">
              <span className="text-[10px] uppercase tracking-wider text-[#8e95a5]">Total Liquidity Value</span>
              <span className="text-sm font-bold text-[#eae6dd]">
                £{totalPortfolioGBP.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>

            <div className="hidden lg:flex items-center space-x-2 px-2.5 py-1 bg-[#14171f] border border-[#262c38] rounded-sm text-xs">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400"></div>
              <span className="text-[#9fa6b2]">Avail GBP:</span>
              <span className="font-mono-num font-bold text-white">
                £{gbpBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
            </div>

            <button
              onClick={onOpenDeposit}
              className="flex items-center space-x-1.5 bg-[#842226] hover:bg-[#9e2a2f] text-white text-xs font-semibold px-3 py-2 rounded-sm transition-all shadow-md cursor-pointer border border-[#b23238]/50"
            >
              <ArrowDownToLine className="w-3.5 h-3.5" />
              <span>Deposit GBP / Crypto</span>
            </button>

            {/* Mobile / Compact Navigation toggle */}
            <div className="xl:hidden flex items-center">
              <select
                aria-label="Navigation Section"
                value={currentTab}
                onChange={(e) => setCurrentTab(e.target.value)}
                className="bg-[#141820] text-xs text-[#eae6dd] border border-[#2b313e] py-1.5 px-2 rounded-sm"
              >
                {navItems.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
