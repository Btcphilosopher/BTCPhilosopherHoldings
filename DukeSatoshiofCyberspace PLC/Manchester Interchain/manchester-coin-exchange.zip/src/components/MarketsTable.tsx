import React, { useState, useMemo } from 'react';
import { useExchange } from '../store/exchangeStore';
import {
  TrendingUp,
  TrendingDown,
  Search,
  Filter,
  ArrowRight,
  Layers,
  Sparkles,
  BarChart2,
} from 'lucide-react';

interface MarketsTableProps {
  onSelectMarket: (marketId: string) => void;
}

export const MarketsTable: React.FC<MarketsTableProps> = ({ onSelectMarket }) => {
  const { markets } = useExchange();
  const [filterCategory, setFilterCategory] = useState<'ALL' | 'GBP' | 'USD' | 'GAINERS'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredMarkets = useMemo(() => {
    return markets.filter((m) => {
      const matchesSearch =
        m.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.baseAsset.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.quoteAsset.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchesSearch) return false;

      if (filterCategory === 'GBP') return m.quoteAsset === 'GBP';
      if (filterCategory === 'USD') return m.quoteAsset === 'USDC' || m.quoteAsset === 'USDT';
      if (filterCategory === 'GAINERS') return m.change24h > 0;
      return true;
    });
  }, [markets, searchQuery, filterCategory]);

  return (
    <div className="bg-[#0b0d10] text-[#eae6dd] py-8">
      <div className="max-w-[1680px] mx-auto px-4 lg:px-8 space-y-6">
        {/* Manchester Market Index (MMI-30) Header Card */}
        <div className="bg-gradient-to-r from-[#141720] via-[#161a24] to-[#12141a] border border-[#262c3b] rounded-sm p-6 relative overflow-hidden">
          <div className="absolute right-0 top-0 bottom-0 w-96 bg-[#842226]/10 blur-2xl pointer-events-none" />
          <div className="flex flex-wrap items-center justify-between gap-4 relative z-10">
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <span className="bg-[#842226] text-white text-[10px] font-bold px-2 py-0.5 uppercase tracking-wider rounded-xs">
                  COMPOSITE BENCHMARK
                </span>
                <span className="font-serif-inst italic text-xs text-[#c59f5b]">
                  Northern England Digital Capital Standard
                </span>
              </div>
              <h2 className="font-display text-2xl font-bold text-white">
                Manchester Market Index (MMI-30)
              </h2>
              <p className="text-xs text-[#8e95a5] max-w-2xl">
                Capitalisation-weighted institutional index measuring top British and global digital assets
                settled via UK clearing channels.
              </p>
            </div>

            <div className="flex items-center space-x-6 font-mono-num">
              <div>
                <span className="text-[10px] uppercase text-[#717887] block">Index Value</span>
                <span className="text-2xl font-black text-white">1,482.60</span>
              </div>
              <div>
                <span className="text-[10px] uppercase text-[#717887] block">24h Performance</span>
                <span className="text-base font-bold text-emerald-400 flex items-center">
                  <TrendingUp className="w-4 h-4 mr-1" />
                  +2.95%
                </span>
              </div>
              <div>
                <span className="text-[10px] uppercase text-[#717887] block">Composite Vol</span>
                <span className="text-base font-bold text-[#c59f5b]">£410.2M</span>
              </div>
            </div>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 bg-[#12151c] p-4 border border-[#1f242e] rounded-sm">
          {/* Categories */}
          <div className="flex items-center space-x-2 text-xs">
            <span className="text-[#717887] mr-2 font-display text-[11px] uppercase">Filter:</span>
            {[
              { id: 'ALL', label: 'All Pairs' },
              { id: 'GBP', label: 'GBP Flagship Markets' },
              { id: 'USD', label: 'USD / USDC Markets' },
              { id: 'GAINERS', label: 'Top Gainers' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setFilterCategory(cat.id as any)}
                className={`px-3 py-1.5 rounded-sm font-medium transition-colors cursor-pointer ${
                  filterCategory === cat.id
                    ? 'bg-[#842226] text-white font-semibold'
                    : 'bg-[#181c25] text-[#8e95a5] hover:text-white hover:bg-[#202532]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative min-w-[260px]">
            <Search className="w-4 h-4 text-[#717887] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search asset or market (e.g. BTC, GBP)..."
              className="w-full bg-[#0a0c10] border border-[#242a38] text-white text-xs pl-9 pr-3 py-1.5 rounded-sm focus:outline-none focus:border-[#842226]"
            />
          </div>
        </div>

        {/* Markets Data Table */}
        <div className="bg-[#12151c] border border-[#1f242e] rounded-sm overflow-hidden">
          <table className="w-full text-left font-mono-num text-xs">
            <thead>
              <tr className="bg-[#161a22] text-[#717887] text-[10px] uppercase border-b border-[#202532]">
                <th className="py-3 px-4">Market Pair</th>
                <th className="py-3 px-4">Settlement Asset</th>
                <th className="py-3 px-4">Last Price</th>
                <th className="py-3 px-4">24h Change</th>
                <th className="py-3 px-4">24h High</th>
                <th className="py-3 px-4">24h Low</th>
                <th className="py-3 px-4">24h Volume</th>
                <th className="py-3 px-4">Bid / Ask Spread</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1a1e28]">
              {filteredMarkets.length === 0 ? (
                <tr>
                  <td colSpan={10} className="text-center py-12 text-[#717887]">
                    No digital asset markets match the current criteria.
                  </td>
                </tr>
              ) : (
                filteredMarkets.map((m) => {
                  const isUp = m.change24h >= 0;
                  return (
                    <tr
                      key={m.id}
                      onClick={() => onSelectMarket(m.id)}
                      className="hover:bg-[#181c25] transition-colors cursor-pointer group"
                    >
                      <td className="py-3.5 px-4 font-bold text-white flex items-center space-x-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#842226]"></span>
                        <span className="font-display text-sm group-hover:text-[#c59f5b] transition-colors">
                          {m.displayName}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-[#8e95a5]">
                        <span className="px-2 py-0.5 rounded bg-[#181c26] text-[11px] font-mono text-[#d4c6b2]">
                          {m.quoteAsset}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-bold text-white text-sm">
                        {m.quoteAsset === 'GBP' ? '£' : '$'}
                        {m.lastPrice.toLocaleString(undefined, { minimumFractionDigits: m.priceDecimals })}
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-flex items-center text-xs font-bold ${
                            isUp ? 'text-emerald-400' : 'text-[#c94046]'
                          }`}
                        >
                          {isUp ? <TrendingUp className="w-3.5 h-3.5 mr-1" /> : <TrendingDown className="w-3.5 h-3.5 mr-1" />}
                          {isUp ? '+' : ''}
                          {m.change24h.toFixed(2)}%
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-[#8e95a5]">
                        {m.quoteAsset === 'GBP' ? '£' : '$'}
                        {m.high24h.toLocaleString(undefined, { minimumFractionDigits: m.priceDecimals })}
                      </td>
                      <td className="py-3.5 px-4 text-[#8e95a5]">
                        {m.quoteAsset === 'GBP' ? '£' : '$'}
                        {m.low24h.toLocaleString(undefined, { minimumFractionDigits: m.priceDecimals })}
                      </td>
                      <td className="py-3.5 px-4 text-[#c7cbd2]">
                        {m.quoteAsset === 'GBP' ? '£' : '$'}
                        {(m.volume24hQuote / 1000000).toFixed(2)}M
                      </td>
                      <td className="py-3.5 px-4 text-[#c59f5b]">{m.spread.toFixed(2)}%</td>
                      <td className="py-3.5 px-4">
                        <span className="text-[10px] bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-semibold">
                          {m.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <span className="inline-flex items-center text-xs font-semibold text-[#842226] group-hover:text-white group-hover:bg-[#842226] px-3 py-1 rounded transition-colors border border-[#842226]/50">
                          Launch &rarr;
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
