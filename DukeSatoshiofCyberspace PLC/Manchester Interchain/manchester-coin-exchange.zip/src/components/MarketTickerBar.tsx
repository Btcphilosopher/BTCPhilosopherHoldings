import React from 'react';
import { useExchange } from '../store/exchangeStore';
import { TrendingUp, TrendingDown, Cpu, ShieldCheck } from 'lucide-react';

export const MarketTickerBar: React.FC = () => {
  const { markets, setActiveMarketId, activeMarketId, engineHealth, isSimulating, toggleSimulation } = useExchange();

  return (
    <div className="bg-[#090b0e] border-b border-[#222731] text-xs py-1.5 px-4 flex items-center justify-between overflow-x-auto no-scrollbar font-mono-num select-none">
      <div className="flex items-center space-x-6 min-w-max">
        <div className="flex items-center space-x-2 text-[#9fa6b2] pr-2 border-r border-[#222731]">
          <span className="w-2 h-2 rounded-full bg-[#842226] animate-pulse"></span>
          <span className="font-semibold text-[#d4c6b2] tracking-wider uppercase font-display text-[10px]">
            MCX LIVE ORDER FLOW
          </span>
        </div>

        {markets.slice(0, 6).map((m) => {
          const isUp = m.change24h >= 0;
          const isSelected = m.id === activeMarketId;
          return (
            <button
              key={m.id}
              onClick={() => setActiveMarketId(m.id)}
              className={`flex items-center space-x-2 py-0.5 px-2 rounded transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#842226]/25 border border-[#842226]/60 text-white'
                  : 'hover:bg-[#161a22] text-[#c7cbd1]'
              }`}
            >
              <span className="font-medium text-[#eae6dd]">{m.displayName}</span>
              <span className="font-mono text-[#ffffff]">
                {m.quoteAsset === 'GBP' ? '£' : '$'}
                {m.lastPrice.toLocaleString(undefined, {
                  minimumFractionDigits: m.priceDecimals,
                  maximumFractionDigits: m.priceDecimals,
                })}
              </span>
              <span
                className={`flex items-center text-[11px] font-semibold ${
                  isUp ? 'text-emerald-400' : 'text-[#c94046]'
                }`}
              >
                {isUp ? <TrendingUp className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
                {isUp ? '+' : ''}
                {m.change24h.toFixed(2)}%
              </span>
            </button>
          );
        })}
      </div>

      <div className="flex items-center space-x-4 pl-4 border-l border-[#222731] min-w-max text-[11px] text-[#8e95a5]">
        <div className="flex items-center space-x-1.5">
          <Cpu className="w-3.5 h-3.5 text-[#c59f5b]" />
          <span>Engine Latency:</span>
          <span className="text-[#eae6dd] font-semibold font-mono">{engineHealth.latencyMicros}µs</span>
        </div>
        <div className="flex items-center space-x-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Ledger:</span>
          <span className="text-emerald-400 font-semibold font-mono">100% RECONCILED</span>
        </div>
        <button
          onClick={toggleSimulation}
          title={isSimulating ? 'Pause synthetic market order flow' : 'Resume synthetic market order flow'}
          className={`px-2 py-0.5 text-[10px] uppercase font-bold rounded cursor-pointer transition-colors ${
            isSimulating
              ? 'bg-[#842226]/30 text-[#e89195] border border-[#842226]/50 hover:bg-[#842226]/50'
              : 'bg-[#222731] text-[#9fa6b2] hover:text-white'
          }`}
        >
          {isSimulating ? 'Sim Engine: Active' : 'Sim Engine: Paused'}
        </button>
      </div>
    </div>
  );
};
