import React, { useState } from 'react';
import { useExchange } from '../store/exchangeStore';
import {
  Terminal,
  Code,
  Key,
  Copy,
  CheckCircle,
  Play,
  Layers,
  Shield,
  FileCode,
} from 'lucide-react';

export const ApiConsole: React.FC = () => {
  const { markets, balances, activeMarket, orderBook, recentTrades } = useExchange();

  const [activeLang, setActiveLang] = useState<'rust' | 'python' | 'ts' | 'curl'>('rust');
  const [selectedEndpoint, setSelectedEndpoint] = useState<string>('/api/v1/ticker');
  const [testResponse, setTestResponse] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  // Sample API key credentials
  const apiKey = 'mcx_live_9488a1f8e9184c7b2a99e';
  const apiSecret = 'sec_manchester_vault_0x992384a8bc91823719284';

  const endpoints = [
    { path: '/api/v1/markets', method: 'GET', desc: 'List all active digital asset markets, tick sizes and fees' },
    { path: '/api/v1/ticker', method: 'GET', desc: 'Get 24h ticker, high, low, volume and last price for market' },
    { path: '/api/v1/orderbook', method: 'GET', desc: 'Retrieve aggregated L2 order book up to depth 50' },
    { path: '/api/v1/trades', method: 'GET', desc: 'Stream recent public trade fills' },
    { path: '/api/v1/orders', method: 'POST', desc: 'Submit authenticated limit/market order to matching engine' },
    { path: '/api/v1/balances', method: 'GET', desc: 'Inspect institutional client balances and locked margin' },
    { path: '/api/v1/rfq/quote', method: 'POST', desc: 'Request streaming block RFQ quote from dealer syndicates' },
  ];

  const handleExecuteTest = (endpoint: string) => {
    let mockData: unknown;
    if (endpoint === '/api/v1/markets') {
      mockData = {
        code: 200,
        status: 'SUCCESS',
        data: markets.map((m) => ({
          market_id: m.id,
          display_name: m.displayName,
          base: m.baseAsset,
          quote: m.quoteAsset,
          last_price: m.lastPrice,
          change_24h_pct: m.change24h,
          spread_pct: m.spread,
        })),
      };
    } else if (endpoint === '/api/v1/ticker') {
      mockData = {
        code: 200,
        status: 'SUCCESS',
        market_id: activeMarket.id,
        last_price: activeMarket.lastPrice,
        bid: activeMarket.bidPrice,
        ask: activeMarket.askPrice,
        high_24h: activeMarket.high24h,
        low_24h: activeMarket.low24h,
        volume_quote_24h: activeMarket.volume24hQuote,
        timestamp: Date.now(),
      };
    } else if (endpoint === '/api/v1/orderbook') {
      mockData = {
        code: 200,
        status: 'SUCCESS',
        market_id: activeMarket.id,
        sequence: orderBook.sequence,
        bids: orderBook.bids.slice(0, 5),
        asks: orderBook.asks.slice(0, 5),
      };
    } else if (endpoint === '/api/v1/trades') {
      mockData = {
        code: 200,
        status: 'SUCCESS',
        trades: recentTrades.slice(0, 5),
      };
    } else if (endpoint === '/api/v1/balances') {
      mockData = {
        code: 200,
        status: 'SUCCESS',
        institution_id: 'MCX-MAN-8841',
        balances: balances.map((b) => ({
          asset: b.asset,
          available: b.available,
          locked: b.locked,
          total: b.total,
          gbp_equivalent: b.gbpValue,
        })),
      };
    } else {
      mockData = {
        code: 200,
        status: 'SUCCESS',
        message: 'Endpoint authenticated and validated by MCX Gateway.',
        timestamp: Date.now(),
      };
    }

    setTestResponse(JSON.stringify(mockData, null, 2));
  };

  const codeSnippets: Record<string, string> = {
    rust: `// Manchester Coin Exchange (MCX) High-Frequency Rust Client
use mcx_client::{McxExchange, OrderSide, OrderType};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let client = McxExchange::new(
        "${apiKey}",
        "${apiSecret}",
        "https://api.mcx.manchester.uk"
    )?;

    // Submit ultra-low-latency limit buy on flagship BTC/GBP
    let order = client.place_order(
        "BTC-GBP",
        OrderSide::Buy,
        OrderType::Limit { price: ${activeMarket.bidPrice} },
        0.50, // 0.50 BTC
    ).await?;

    println!("MCX Order Placed: {:?} | Latency: 38µs", order.id);
    Ok(())
}`,
    python: `# Manchester Coin Exchange (MCX) Python SDK
import mcx_exchange as mcx

client = mcx.InstitutionalClient(
    api_key="${apiKey}",
    api_secret="${apiSecret}",
    environment="production"
)

# Fetch authoritative flagship order book
book = client.get_order_book("BTC-GBP", depth=25)
print(f"MCX Best Bid: £{book['bids'][0]['price']} | Best Ask: £{book['asks'][0]['price']}")

# Submit Market Order
order = client.create_order(
    market="BTC-GBP",
    side="BUY",
    order_type="MARKET",
    size=0.25
)
print(f"Executed Order ID: {order['id']}, Status: {order['status']}")
`,
    ts: `// Manchester Coin Exchange (MCX) TypeScript Client
import { McxClient } from '@mcx/sdk';

const client = new McxClient({
  apiKey: '${apiKey}',
  apiSecret: '${apiSecret}',
  baseUrl: 'https://api.mcx.manchester.uk'
});

async function run() {
  const ticker = await client.getTicker('BTC-GBP');
  console.log('MCX BTC/GBP Last Price:', ticker.lastPrice);

  // Subscribe to real-time WebSocket order book feed
  client.subscribe('orderbook:BTC-GBP', (book) => {
    console.log('L2 Book Update Sequence:', book.sequence);
  });
}

run();`,
    curl: `# MCX REST API cURL Example
curl -X GET "https://api.mcx.manchester.uk/api/v1/ticker?market=BTC-GBP" \\
  -H "X-MCX-APIKEY: ${apiKey}" \\
  -H "X-MCX-SIGNATURE: 7e891c92a98f12..." \\
  -H "X-MCX-TIMESTAMP: ${Date.now()}"`,
  };

  const handleCopyCode = () => {
    navigator.clipboard?.writeText(codeSnippets[activeLang]);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="bg-[#0b0d10] text-[#eae6dd] py-8">
      <div className="max-w-[1680px] mx-auto px-4 lg:px-8 space-y-6">
        {/* Header */}
        <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-[#842226] flex items-center justify-center rounded-sm">
                <Terminal className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-display text-2xl font-bold text-white">
                  Institutional API Trading &amp; SDK Architecture
                </h2>
                <p className="text-xs text-[#8e95a5]">
                  High-frequency binary FIX 4.4, WebSocket streaming, and REST endpoints with HMAC-SHA256 authenticated execution.
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3 font-mono-num text-xs">
              <span className="bg-[#181c25] border border-[#272e3d] px-3 py-1.5 rounded text-[#d4c6b2]">
                REST RATE LIMIT: <strong className="text-emerald-400">1,200 REQ/MIN</strong>
              </span>
              <span className="bg-[#181c25] border border-[#272e3d] px-3 py-1.5 rounded text-[#d4c6b2]">
                FIX / WS LATENCY: <strong className="text-white">&lt; 50µs</strong>
              </span>
            </div>
          </div>
        </div>

        {/* API Credentials Card */}
        <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-5">
          <div className="flex items-center space-x-2 mb-3">
            <Key className="w-4 h-4 text-[#c59f5b]" />
            <h3 className="font-display font-bold text-white text-sm">
              Your Institutional API Credentials
            </h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono-num text-xs">
            <div className="p-3 bg-[#0a0c10] border border-[#222834] rounded-sm">
              <span className="text-[10px] text-[#717887] uppercase block">API Key (Public ID)</span>
              <span className="text-white font-mono">{apiKey}</span>
            </div>
            <div className="p-3 bg-[#0a0c10] border border-[#222834] rounded-sm">
              <span className="text-[10px] text-[#717887] uppercase block">HMAC Secret (Air-Gapped)</span>
              <span className="text-[#c59f5b] font-mono">{apiSecret.substring(0, 16)}••••••••••••</span>
            </div>
          </div>
        </div>

        {/* Interactive Endpoint Explorer & Code Snippets Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Endpoints Directory */}
          <div className="lg:col-span-5 bg-[#12151c] border border-[#1f242e] rounded-sm p-5 space-y-3">
            <h3 className="font-display font-bold text-white text-sm">
              REST &amp; WebSocket Endpoints
            </h3>
            <div className="space-y-2 font-mono-num text-xs">
              {endpoints.map((ep) => (
                <div
                  key={ep.path}
                  onClick={() => {
                    setSelectedEndpoint(ep.path);
                    handleExecuteTest(ep.path);
                  }}
                  className={`p-3 rounded-sm border cursor-pointer transition-all ${
                    selectedEndpoint === ep.path
                      ? 'bg-[#181c26] border-[#842226]'
                      : 'bg-[#0a0c10] border-[#1d222e] hover:border-[#353d4f]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        ep.method === 'GET'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'bg-[#842226]/30 text-[#e67a7f]'
                      }`}
                    >
                      {ep.method}
                    </span>
                    <span className="font-mono text-white font-semibold">{ep.path}</span>
                  </div>
                  <p className="text-[11px] text-[#8e95a5] font-sans">{ep.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Code Sample & Interactive Test Response */}
          <div className="lg:col-span-7 space-y-4">
            {/* Code Snippets */}
            <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-5 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#1f242e]">
                <div className="flex items-center space-x-1 text-xs">
                  {[
                    { id: 'rust', label: 'Rust SDK' },
                    { id: 'python', label: 'Python' },
                    { id: 'ts', label: 'TypeScript' },
                    { id: 'curl', label: 'cURL' },
                  ].map((l) => (
                    <button
                      key={l.id}
                      onClick={() => setActiveLang(l.id as any)}
                      className={`px-3 py-1 rounded text-xs font-mono font-medium cursor-pointer transition-colors ${
                        activeLang === l.id
                          ? 'bg-[#842226] text-white font-bold'
                          : 'text-[#8e95a5] hover:text-white'
                      }`}
                    >
                      {l.label}
                    </button>
                  ))}
                </div>

                <button
                  onClick={handleCopyCode}
                  className="flex items-center space-x-1 text-xs text-[#8e95a5] hover:text-white cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedCode ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <pre className="p-4 bg-[#0a0c10] border border-[#1d222e] rounded-sm text-xs font-mono text-[#d4c6b2] overflow-x-auto leading-relaxed">
                <code>{codeSnippets[activeLang]}</code>
              </pre>
            </div>

            {/* Test Response Console */}
            <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-5 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#1f242e]">
                <span className="font-display font-bold text-white text-xs">
                  Live Response &middot; {selectedEndpoint}
                </span>
                <button
                  onClick={() => handleExecuteTest(selectedEndpoint)}
                  className="bg-[#842226] hover:bg-[#9e2a2f] text-white text-xs px-3 py-1 rounded cursor-pointer transition-colors flex items-center space-x-1"
                >
                  <Play className="w-3 h-3" />
                  <span>Run Query</span>
                </button>
              </div>

              <pre className="p-4 bg-[#0a0c10] border border-[#1d222e] rounded-sm text-xs font-mono text-emerald-400 overflow-x-auto max-h-60 leading-relaxed">
                <code>
                  {testResponse ||
                    `// Click 'Run Query' or select an endpoint to inspect real-time JSON payload from the MCX matching core.`}
                </code>
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
