import React from 'react';
import { useExchange } from '../store/exchangeStore';
import {
  TrendingUp,
  TrendingDown,
  Shield,
  Zap,
  Building2,
  Users2,
  ArrowRight,
  Landmark,
  Scale,
  Award,
  ChevronRight,
  Flame,
  CheckCircle,
  ExternalLink,
} from 'lucide-react';

interface LandingHeroProps {
  onOpenTerminal: () => void;
  onOpenMarkets: () => void;
  onOpenCustody: () => void;
}

export const LandingHero: React.FC<LandingHeroProps> = ({
  onOpenTerminal,
  onOpenMarkets,
  onOpenCustody,
}) => {
  const { markets, setActiveMarketId, activeMarket } = useExchange();

  const flagshipMarket = markets.find((m) => m.id === 'BTC-GBP') || markets[0];

  return (
    <div className="bg-[#0b0d10] text-[#eae6dd]">
      {/* Imposing Victorian Commercial Architectural Banner */}
      <section className="relative border-b border-[#222834] overflow-hidden bg-gradient-to-b from-[#0f1218] via-[#0d0f14] to-[#0a0c0f]">
        {/* Architectural red-brick subtle grid overlay */}
        <div className="absolute inset-0 bg-manchester-grid opacity-30 pointer-events-none"></div>

        {/* Ambient warm brick red & brass glow in corners */}
        <div className="absolute top-0 right-1/4 w-[500px] h-[350px] bg-[#842226]/12 blur-[120px] pointer-events-none"></div>
        <div className="absolute top-1/3 left-10 w-[350px] h-[300px] bg-[#c59f5b]/8 blur-[100px] pointer-events-none"></div>

        <div className="max-w-[1680px] mx-auto px-4 lg:px-8 pt-8 pb-12 relative z-10">
          {/* Institutional Header Stamp */}
          <div className="flex flex-wrap items-center justify-between pb-6 border-b border-[#1f242e] mb-8">
            <div className="flex items-center space-x-3">
              <div className="px-2.5 py-1 bg-[#842226] text-white text-[11px] font-bold uppercase tracking-widest rounded-xs shadow-sm">
                MANCHESTER, ENGLAND
              </div>
              <span className="text-[#6d7585] text-xs font-mono">/</span>
              <span className="font-serif-inst italic text-xs text-[#c59f5b] tracking-wide">
                Royal Exchange Tradition &middot; Modern British Digital Asset Settlement
              </span>
            </div>

            <div className="flex items-center space-x-4 text-xs font-mono-num text-[#8e95a5]">
              <span className="flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>FCA Custody Interoperability Architecture</span>
              </span>
              <span className="hidden sm:inline text-[#3a4150]">|</span>
              <span className="hidden sm:inline text-[#d4c6b2]">Bank of England Faster Payments / CHAPS Direct</span>
            </div>
          </div>

          {/* Hero Grid: Left Narrative + Right Live Flagship Terminal Preview */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Narrative */}
            <div className="lg:col-span-6 space-y-6">
              <div className="inline-flex items-center space-x-2 px-3 py-1 bg-[#161a22] border border-[#2b3342] text-xs text-[#d4c6b2] rounded-xs font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-[#842226]"></span>
                <span className="text-[#c59f5b] font-semibold">DIGITAL ASSETS. REAL ECONOMY.</span>
              </div>

              <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-black text-white leading-[1.12] tracking-tight">
                Manchester’s <br />
                <span className="text-white">Trusted Exchange</span> <br />
                <span className="text-[#c59f5b] font-serif-inst italic font-normal">
                  for a Digital Future
                </span>
              </h1>

              <p className="text-base text-[#9ea6b5] leading-relaxed max-w-xl font-light">
                Manchester Coin Exchange (MCX) is Britain’s institutional and private banking digital asset house,
                founded in the cradle of the Industrial Revolution. We pair sovereign British financial permanence
                and fired Manchester red-brick commercial heritage with a deterministic price-time-priority matching engine.
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={onOpenTerminal}
                  className="bg-[#842226] hover:bg-[#9f2a2f] text-white font-semibold text-sm px-6 py-3 rounded-sm transition-all shadow-lg hover:shadow-[#842226]/30 flex items-center space-x-2 cursor-pointer border border-[#b23238]"
                >
                  <span>Launch Market Terminal</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={onOpenMarkets}
                  className="bg-[#141821] hover:bg-[#1c222e] text-[#d4c6b2] hover:text-white font-semibold text-sm px-5 py-3 rounded-sm transition-colors border border-[#2a3242] flex items-center space-x-2 cursor-pointer"
                >
                  <span>Explore 12 Digital Markets</span>
                </button>

                <button
                  onClick={onOpenCustody}
                  className="text-xs text-[#8e95a5] hover:text-[#c59f5b] underline underline-offset-4 ml-2 transition-colors cursor-pointer"
                >
                  Inspect Segregated Vaults &rarr;
                </button>
              </div>

              {/* Key Trust Badges */}
              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-[#1f242e] font-mono-num">
                <div>
                  <span className="text-[10px] uppercase text-[#717887] tracking-wider block">24h Sterling Volume</span>
                  <span className="text-lg font-bold text-white">£1.84 Billion</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase text-[#717887] tracking-wider block">Engine Micro-Latency</span>
                  <span className="text-lg font-bold text-[#c59f5b]">38 Microseconds</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase text-[#717887] tracking-wider block">Deep Vault Cold Storage</span>
                  <span className="text-lg font-bold text-emerald-400">94.2% Segregated</span>
                </div>
              </div>
            </div>

            {/* Right: Flagship Live Market Module (BTC/GBP with candle graph & depth) */}
            <div className="lg:col-span-6">
              <div className="bg-[#12151c] border-2 border-[#842226]/60 rounded-sm shadow-2xl p-5 relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-[#842226]/20 to-transparent pointer-events-none"></div>

                {/* Header */}
                <div className="flex items-center justify-between pb-4 border-b border-[#1f242e]">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-full bg-[#f7931a] flex items-center justify-center font-bold text-black text-sm">
                      ₿
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-display font-bold text-lg text-white">BTC / GBP</span>
                        <span className="text-[10px] uppercase bg-[#842226] text-white px-1.5 py-0.2 rounded font-bold">
                          FLAGSHIP
                        </span>
                      </div>
                      <span className="text-xs text-[#8e95a5]">Manchester Premier Liquid Pair</span>
                    </div>
                  </div>

                  <div className="text-right font-mono-num">
                    <span className="text-2xl font-black text-white tracking-tight">
                      £{flagshipMarket.lastPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                    <span className="flex items-center justify-end text-xs font-semibold text-emerald-400">
                      <TrendingUp className="w-3.5 h-3.5 mr-0.5" />
                      +{flagshipMarket.change24h}% (24h)
                    </span>
                  </div>
                </div>

                {/* Stats Bar */}
                <div className="grid grid-cols-3 gap-2 py-3 border-b border-[#1f242e] font-mono-num text-xs">
                  <div>
                    <span className="text-[10px] text-[#767e8f] block uppercase">24h High</span>
                    <span className="text-white font-medium">£{flagshipMarket.high24h.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#767e8f] block uppercase">24h Low</span>
                    <span className="text-white font-medium">£{flagshipMarket.low24h.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#767e8f] block uppercase">24h Vol (GBP)</span>
                    <span className="text-white font-medium">£{(flagshipMarket.volume24hQuote / 1000000).toFixed(1)}M</span>
                  </div>
                </div>

                {/* Micro Candlestick Simulation Box */}
                <div className="py-4">
                  <div className="flex justify-between items-center text-[11px] text-[#8e95a5] mb-2 font-mono">
                    <span>PRICE DISCOVERY (1H BARS)</span>
                    <span className="text-[#c59f5b]">SPREAD: {flagshipMarket.spread}%</span>
                  </div>
                  <div className="h-28 flex items-end justify-between gap-1.5 bg-[#0a0c10] p-2 rounded border border-[#1b202a]">
                    {[38, 42, 45, 41, 49, 53, 50, 58, 62, 59, 67, 72, 69, 78, 84, 89, 93, 88, 95, 100].map((h, i) => (
                      <div key={i} className="flex-1 flex flex-col items-center justify-end h-full">
                        <div
                          className={`w-full rounded-t-xs transition-all ${
                            i % 4 === 1 ? 'bg-[#842226]' : 'bg-emerald-500'
                          }`}
                          style={{ height: `${h}%`, opacity: 0.8 }}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Quick Action Strip */}
                <div className="pt-2 flex items-center justify-between">
                  <span className="text-xs text-[#8e95a5] font-mono">
                    Instant Bank Settlement via CHAPS &amp; FPS
                  </span>
                  <button
                    onClick={() => {
                      setActiveMarketId('BTC-GBP');
                      onOpenTerminal();
                    }}
                    className="bg-[#842226] hover:bg-[#9f2a2f] text-white text-xs font-bold px-4 py-2 rounded-sm cursor-pointer transition-colors flex items-center space-x-1 border border-[#b23238]"
                  >
                    <span>Trade BTC/GBP Now</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4 Pillars of Manchester Institutional Finance */}
      <section className="py-12 border-b border-[#1f242e] bg-[#0c0e13]">
        <div className="max-w-[1680px] mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 bg-[#12151c] border border-[#202532] rounded-sm hover:border-[#842226] transition-all group">
              <div className="w-10 h-10 rounded-sm bg-[#842226]/20 border border-[#842226]/50 flex items-center justify-center text-[#e67a7f] mb-4 group-hover:scale-105 transition-transform">
                <Shield className="w-5 h-5 text-[#c94046]" />
              </div>
              <h3 className="font-display font-bold text-white text-lg mb-2">Vault Custody</h3>
              <p className="text-xs text-[#8e95a5] leading-relaxed">
                Multi-layer air-gapped cryptographic vaults situated in subterranean Manchester facilities.
                Segregated client assets with 100% mathematical auditability.
              </p>
            </div>

            <div className="p-6 bg-[#12151c] border border-[#202532] rounded-sm hover:border-[#842226] transition-all group">
              <div className="w-10 h-10 rounded-sm bg-[#842226]/20 border border-[#842226]/50 flex items-center justify-center text-[#e67a7f] mb-4 group-hover:scale-105 transition-transform">
                <Zap className="w-5 h-5 text-[#c59f5b]" />
              </div>
              <h3 className="font-display font-bold text-white text-lg mb-2">Deterministic Engine</h3>
              <p className="text-xs text-[#8e95a5] leading-relaxed">
                Ultra-low latency price-time priority matching engine executing at 38 microseconds. Full order book
                replay and zero-slippage RFQ execution for institutional blocks.
              </p>
            </div>

            <div className="p-6 bg-[#12151c] border border-[#202532] rounded-sm hover:border-[#842226] transition-all group">
              <div className="w-10 h-10 rounded-sm bg-[#842226]/20 border border-[#842226]/50 flex items-center justify-center text-[#e67a7f] mb-4 group-hover:scale-105 transition-transform">
                <Building2 className="w-5 h-5 text-[#d4c6b2]" />
              </div>
              <h3 className="font-display font-bold text-white text-lg mb-2">British Commercial Heritage</h3>
              <p className="text-xs text-[#8e95a5] leading-relaxed">
                Founded upon Manchester’s legendary history as the commercial powerhouse of the world. Built for
                corporates, family offices, liquidity providers and discerning retail traders.
              </p>
            </div>

            <div className="p-6 bg-[#12151c] border border-[#202532] rounded-sm hover:border-[#842226] transition-all group">
              <div className="w-10 h-10 rounded-sm bg-[#842226]/20 border border-[#842226]/50 flex items-center justify-center text-[#e67a7f] mb-4 group-hover:scale-105 transition-transform">
                <Scale className="w-5 h-5 text-emerald-400" />
              </div>
              <h3 className="font-display font-bold text-white text-lg mb-2">Regulatory Architecture</h3>
              <p className="text-xs text-[#8e95a5] leading-relaxed">
                Full double-entry general ledger reconciliation with zero fractional reserve. Real-time surveillance
                monitoring for spoofing, layering and synthetic market manipulation.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Markets Quick Overview */}
      <section className="py-12 max-w-[1680px] mx-auto px-4 lg:px-8">
        <div className="flex flex-wrap items-center justify-between mb-6">
          <div>
            <h2 className="font-display text-2xl font-bold text-white tracking-wide">
              Exchange Markets Overview
            </h2>
            <p className="text-xs text-[#8e95a5]">
              Real-time prices, institutional spreads and order book depth across British Sterling &amp; Dollar pairs.
            </p>
          </div>
          <button
            onClick={onOpenMarkets}
            className="text-xs font-semibold text-[#c59f5b] hover:text-white flex items-center space-x-1 cursor-pointer"
          >
            <span>View All Markets</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="bg-[#12151c] border border-[#1f242e] rounded-sm overflow-hidden">
          <table className="w-full text-left font-mono-num text-xs">
            <thead>
              <tr className="bg-[#161a22] text-[#767e8f] text-[10px] uppercase border-b border-[#202532]">
                <th className="py-3 px-4">Market</th>
                <th className="py-3 px-4">Last Traded Price</th>
                <th className="py-3 px-4">24h Movement</th>
                <th className="py-3 px-4">24h High / Low</th>
                <th className="py-3 px-4">24h Volume</th>
                <th className="py-3 px-4">Spread</th>
                <th className="py-3 px-4 text-right">Direct Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1a1e28]">
              {markets.slice(0, 6).map((m) => {
                const isUp = m.change24h >= 0;
                return (
                  <tr key={m.id} className="hover:bg-[#171b24] transition-colors">
                    <td className="py-3.5 px-4 font-bold text-white flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-[#842226]"></span>
                      <span className="font-display">{m.displayName}</span>
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-white">
                      {m.quoteAsset === 'GBP' ? '£' : '$'}
                      {m.lastPrice.toLocaleString(undefined, { minimumFractionDigits: m.priceDecimals })}
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-flex items-center text-xs font-bold ${
                          isUp ? 'text-emerald-400' : 'text-[#c94046]'
                        }`}
                      >
                        {isUp ? '+' : ''}
                        {m.change24h.toFixed(2)}%
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-[#8e95a5]">
                      {m.quoteAsset === 'GBP' ? '£' : '$'}
                      {m.high24h.toLocaleString(undefined, { minimumFractionDigits: m.priceDecimals })} / £
                      {m.low24h.toLocaleString(undefined, { minimumFractionDigits: m.priceDecimals })}
                    </td>
                    <td className="py-3.5 px-4 text-[#c7cbd2]">
                      {m.quoteAsset === 'GBP' ? '£' : '$'}
                      {(m.volume24hQuote / 1000000).toFixed(2)}M
                    </td>
                    <td className="py-3.5 px-4 text-[#c59f5b]">{m.spread.toFixed(2)}%</td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => {
                          setActiveMarketId(m.id);
                          onOpenTerminal();
                        }}
                        className="bg-[#1d222e] hover:bg-[#842226] text-white text-[11px] font-semibold px-3 py-1.5 rounded-sm transition-colors cursor-pointer border border-[#2b3342] hover:border-[#842226]"
                      >
                        Trade
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* Northern Engineering & Mobile Custody Homage Section */}
      <section className="py-12 border-t border-[#1f242e] bg-[#0c0f15]">
        <div className="max-w-[1680px] mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left: Engineering & Light Rail Metrolink visual block */}
            <div className="lg:col-span-7 bg-gradient-to-br from-[#161a24] to-[#10131a] p-6 lg:p-8 rounded-sm border border-[#2b3344] relative overflow-hidden space-y-5">
              <div className="absolute top-0 right-0 w-64 h-64 bg-[#c59f5b]/10 blur-3xl pointer-events-none"></div>

              <div className="flex items-center space-x-2 text-xs font-mono text-[#c59f5b]">
                <span className="w-2 h-2 rounded-full bg-[#842226]"></span>
                <span className="font-semibold uppercase tracking-wider">MANCHESTER ENGINEERING EXCELLENCE</span>
              </div>

              <h3 className="font-display text-2xl lg:text-3xl font-bold text-white leading-tight">
                Trade Bitcoin. <br />
                <span className="text-[#c59f5b] font-serif-inst italic">Trade The Future.</span>
              </h3>

              <p className="text-xs lg:text-sm text-[#9ea6b5] leading-relaxed max-w-xl">
                From the world’s first inter-city passenger railway in 1830 to modern Metrolink light-rail and advanced financial telemetry:
                Manchester has perpetually engineered the transport systems that carry commerce forward.
                MCX applies that exact ethos to high-throughput digital liquidity.
              </p>

              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-[#222836] font-mono-num text-xs">
                <div>
                  <span className="text-[10px] text-[#717887] uppercase block">Network Uptime</span>
                  <span className="text-base font-bold text-emerald-400">99.998%</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#717887] uppercase block">Clearing Speed</span>
                  <span className="text-base font-bold text-white">&lt; 12 Sec (FPS)</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#717887] uppercase block">Custody Backing</span>
                  <span className="text-base font-bold text-[#c59f5b]">1:1 Full Reserve</span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={onOpenTerminal}
                  className="bg-[#842226] hover:bg-[#9f2a2f] text-white text-xs font-bold px-5 py-2.5 rounded-sm transition-all border border-[#b23238] cursor-pointer inline-flex items-center space-x-2"
                >
                  <span>Start Institutional Trading</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Right: Mobile App & Custody Showcase */}
            <div className="lg:col-span-5 bg-[#12151c] border border-[#202532] rounded-sm p-6 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#1f242e]">
                <div>
                  <h4 className="font-display font-bold text-white text-base">MCX Mobile Custody</h4>
                  <span className="text-xs text-[#8e95a5]">Institutional access on iOS &amp; Android</span>
                </div>
                <span className="text-[10px] bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-mono font-bold">
                  BIOMETRIC 2FA
                </span>
              </div>

              {/* Mock Mobile View Card */}
              <div className="bg-[#090b0e] border border-[#252c3c] rounded-lg p-5 font-mono-num space-y-4 shadow-xl">
                <div className="flex items-center justify-between text-xs text-[#717887]">
                  <span className="font-display text-[#c59f5b] font-bold">MCX SECURE</span>
                  <span>TAPROOT CUSTODY</span>
                </div>

                <div>
                  <span className="text-[10px] text-[#8e95a5] uppercase block">Total Balance</span>
                  <span className="text-2xl font-bold text-white">£12,846.32</span>
                  <span className="text-xs text-emerald-400 font-semibold block pt-0.5">+2.48% (24h)</span>
                </div>

                <div className="grid grid-cols-4 gap-2 pt-2 text-center text-[10px]">
                  <div className="p-2 bg-[#141822] rounded border border-[#202532] text-[#d4c6b2]">
                    Deposit
                  </div>
                  <div className="p-2 bg-[#141822] rounded border border-[#202532] text-[#d4c6b2]">
                    Trade
                  </div>
                  <div className="p-2 bg-[#141822] rounded border border-[#202532] text-[#d4c6b2]">
                    Earn
                  </div>
                  <div className="p-2 bg-[#141822] rounded border border-[#202532] text-[#d4c6b2]">
                    Vault
                  </div>
                </div>
              </div>

              <div className="text-xs text-[#8e95a5] flex items-center justify-between pt-2">
                <span>Direct settlement to UK Faster Payments</span>
                <span className="text-[#c59f5b] font-semibold">FCA Compliant</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Institutional Callout Footer Ribbon */}
      <section className="bg-[#12151c] border-t border-[#1f242e] py-8">
        <div className="max-w-[1680px] mx-auto px-4 lg:px-8 flex flex-wrap items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#842226] flex items-center justify-center rounded-sm">
              <Landmark className="w-6 h-6 text-white" />
            </div>
            <div>
              <h4 className="font-display font-bold text-white text-base tracking-wide">
                MANCHESTER COIN EXCHANGE (MCX)
              </h4>
              <p className="text-xs text-[#8e95a5]">
                Deansgate Financial Quarter &middot; City of Manchester &middot; United Kingdom
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-[#8e95a5]">
            <span>Deterministic Rust Matching Core</span>
            <span>&bull;</span>
            <span>Real Double-Entry Accounting</span>
            <span>&bull;</span>
            <span>Sub-Millisecond Execution</span>
            <span>&bull;</span>
            <span className="text-[#c59f5b] font-serif-inst italic">Manchester Builds What’s Next</span>
          </div>
        </div>
      </section>
    </div>
  );
};
