import React, { useState } from 'react';
import { useExchange } from '../store/exchangeStore';
import { ASSETS_REGISTRY } from '../data/initialMarkets';
import { AssetSymbol } from '../types/exchange';
import {
  Shield,
  Lock,
  ArrowDownToLine,
  ArrowUpFromLine,
  CheckCircle,
  Copy,
  ExternalLink,
  History,
  FileCheck2,
  AlertTriangle,
  RefreshCw,
  Landmark,
} from 'lucide-react';

export const CustodyWallet: React.FC = () => {
  const {
    balances,
    totalPortfolioGBP,
    totalPortfolioUSD,
    recentLedgerEntries,
    deposits,
    withdrawals,
    depositFunds,
    requestWithdrawal,
    reconcileAudit,
  } = useExchange();

  const [selectedAsset, setSelectedAsset] = useState<AssetSymbol>('GBP');
  const [activeTab, setActiveTab] = useState<'holdings' | 'deposit' | 'withdraw' | 'ledger' | 'vaults'>('holdings');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Form states
  const [depAmount, setDepAmount] = useState<string>('25000');
  const [wthAmount, setWthAmount] = useState<string>('5000');
  const [wthAddress, setWthAddress] = useState<string>('0x3A94bF28eC884E0c961e6B5C7B7Fa8558A46eA81');
  const [actionFeedback, setActionFeedback] = useState<{ text: string; isError: boolean } | null>(null);

  // Ledger audit state
  const [auditResult, setAuditResult] = useState<ReturnType<typeof reconcileAudit> | null>(null);

  const assetInfo = ASSETS_REGISTRY[selectedAsset];
  const currentBalance = balances.find((b) => b.asset === selectedAsset);

  const handleCopy = (text: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2500);
  };

  const handleExecuteDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(depAmount);
    if (isNaN(amt) || amt <= 0) {
      setActionFeedback({ text: 'Please specify a valid deposit amount', isError: true });
      return;
    }
    depositFunds(selectedAsset, amt);
    setActionFeedback({
      text: `Successfully initiated and credited ${amt.toLocaleString()} ${selectedAsset} via ${assetInfo.network}. Double-entry ledger reconciled.`,
      isError: false,
    });
    setTimeout(() => setActionFeedback(null), 5000);
  };

  const handleExecuteWithdrawal = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(wthAmount);
    if (isNaN(amt) || amt <= 0) {
      setActionFeedback({ text: 'Please specify a valid withdrawal amount', isError: true });
      return;
    }
    if (!wthAddress.trim()) {
      setActionFeedback({ text: 'Please specify destination address / IBAN', isError: true });
      return;
    }

    const res = requestWithdrawal(selectedAsset, amt, wthAddress);
    setActionFeedback({
      text: res.message,
      isError: !res.success,
    });
    setTimeout(() => setActionFeedback(null), 5000);
  };

  const handleRunReconciliation = () => {
    const res = reconcileAudit();
    setAuditResult(res);
  };

  return (
    <div className="bg-[#0b0d10] text-[#eae6dd] py-8">
      <div className="max-w-[1680px] mx-auto px-4 lg:px-8 space-y-6">
        {/* Custody Header Banner */}
        <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-6">
          <div className="flex flex-wrap items-center justify-between gap-6">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-[#842226] flex items-center justify-center rounded-sm border border-[#9e2a2f]">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h2 className="font-display text-2xl font-bold text-white">
                    Manchester Deep Vault Custody &amp; Double-Entry Ledger
                  </h2>
                  <span className="bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded uppercase">
                    100% SOLVENT
                  </span>
                </div>
                <p className="text-xs text-[#8e95a5]">
                  FCA-interoperable institutional asset segregation with Bank of England CHAPS clearing and physical cold vaults in Greater Manchester.
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-6 font-mono-num text-xs">
              <div>
                <span className="text-[10px] text-[#717887] uppercase block">Total Portfolio (GBP)</span>
                <span className="text-xl font-black text-white">
                  £{totalPortfolioGBP.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="pl-4 border-l border-[#202532]">
                <span className="text-[10px] text-[#717887] uppercase block">Cold / Hot Ratio</span>
                <span className="text-xl font-black text-emerald-400">94.2% / 5.8%</span>
              </div>
              <div className="pl-4 border-l border-[#202532]">
                <button
                  onClick={handleRunReconciliation}
                  className="bg-[#842226] hover:bg-[#9e2a2f] text-white px-3 py-2 rounded-sm text-xs font-semibold cursor-pointer transition-colors flex items-center space-x-1.5"
                >
                  <FileCheck2 className="w-4 h-4" />
                  <span>Audit Reconcile</span>
                </button>
              </div>
            </div>
          </div>

          {/* Audit Result Banner if run */}
          {auditResult && (
            <div className="mt-4 p-3 bg-[#171c26] border border-emerald-500/40 rounded-sm text-xs flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  <strong>Authoritative Reconciliation Proof:</strong> Verified {auditResult.totalEntries} double-entry general ledger records.
                  Debit sum: £{auditResult.debitSumGBP.toLocaleString()} === Credit sum: £{auditResult.creditSumGBP.toLocaleString()}.
                  Variance: £0.00 (Balanced).
                </span>
              </div>
              <span className="text-[10px] text-[#717887] font-mono">
                TIMESTAMP: {new Date(auditResult.timestamp).toISOString()}
              </span>
            </div>
          )}
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center space-x-2 border-b border-[#1f242e] pb-3 text-xs">
          {[
            { id: 'holdings', label: 'Asset Holdings & Segregation' },
            { id: 'deposit', label: 'Deposit (Faster Payments / Crypto)' },
            { id: 'withdraw', label: 'Institutional Withdrawal' },
            { id: 'ledger', label: 'Complete Double-Entry Ledger' },
            { id: 'vaults', label: 'Manchester Underground Vault Architecture' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2 rounded-sm font-semibold transition-colors cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-[#842226] text-white shadow-sm'
                  : 'bg-[#14171f] text-[#8e95a5] hover:text-white hover:bg-[#1a1e28]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab 1: Holdings */}
        {activeTab === 'holdings' && (
          <div className="bg-[#12151c] border border-[#1f242e] rounded-sm overflow-hidden">
            <table className="w-full text-left font-mono-num text-xs">
              <thead>
                <tr className="bg-[#161a22] text-[#717887] text-[10px] uppercase border-b border-[#202532]">
                  <th className="py-3 px-4">Digital / Fiat Asset</th>
                  <th className="py-3 px-4">Network / Protocol</th>
                  <th className="py-3 px-4">Available Balance</th>
                  <th className="py-3 px-4">Locked in Orders</th>
                  <th className="py-3 px-4">Total Custodied</th>
                  <th className="py-3 px-4">Cold Custody Ratio</th>
                  <th className="py-3 px-4 text-right">GBP Equivalent</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1a1e28]">
                {balances.map((b) => {
                  const info = ASSETS_REGISTRY[b.asset];
                  return (
                    <tr key={b.asset} className="hover:bg-[#181c25] transition-colors">
                      <td className="py-3.5 px-4 font-bold text-white flex items-center space-x-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#842226]"></span>
                        <div>
                          <span className="font-display text-sm">{b.asset}</span>
                          <span className="block text-[10px] text-[#767e8f] font-normal">{info.name}</span>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-[#8e95a5] text-[11px] max-w-xs truncate">
                        {info.network}
                      </td>
                      <td className="py-3.5 px-4 text-emerald-400 font-semibold">
                        {b.available.toLocaleString(undefined, { minimumFractionDigits: b.asset === 'GBP' ? 2 : 4 })}
                      </td>
                      <td className="py-3.5 px-4 text-[#8e95a5]">
                        {b.locked.toLocaleString(undefined, { minimumFractionDigits: b.asset === 'GBP' ? 2 : 4 })}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-white">
                        {b.total.toLocaleString(undefined, { minimumFractionDigits: b.asset === 'GBP' ? 2 : 4 })}
                      </td>
                      <td className="py-3.5 px-4 text-[#c59f5b]">
                        {(info.custodyColdRatio * 100).toFixed(0)}% Cold Storage
                      </td>
                      <td className="py-3.5 px-4 text-right font-bold text-[#eae6dd]">
                        £{b.gbpValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <button
                            onClick={() => {
                              setSelectedAsset(b.asset);
                              setActiveTab('deposit');
                            }}
                            className="px-2 py-1 bg-[#1a1f29] hover:bg-[#842226] text-white rounded text-[11px] cursor-pointer transition-colors"
                          >
                            Deposit
                          </button>
                          <button
                            onClick={() => {
                              setSelectedAsset(b.asset);
                              setActiveTab('withdraw');
                            }}
                            className="px-2 py-1 bg-[#1a1f29] hover:bg-[#252c3b] text-[#9fa6b2] hover:text-white rounded text-[11px] cursor-pointer transition-colors"
                          >
                            Withdraw
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Tab 2: Deposit */}
        {activeTab === 'deposit' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-6 bg-[#12151c] border border-[#1f242e] rounded-sm p-6 space-y-4">
              <h3 className="font-display font-bold text-white text-lg">
                Institutional Deposit &middot; {selectedAsset}
              </h3>
              <p className="text-xs text-[#8e95a5]">
                {assetInfo.isFiat
                  ? 'Transfer British Sterling via Bank of England CHAPS or UK Faster Payments. Settles within 12 seconds to your dedicated MCX institutional IBAN.'
                  : `Send ${selectedAsset} to your segregated multi-signature Taproot/Vault address. Automatically credited after ${assetInfo.depositConfirmationBlocks} block confirmations.`}
              </p>

              {/* Asset selector */}
              <div>
                <label className="block text-xs text-[#8e95a5] mb-1">Select Asset to Deposit</label>
                <div className="flex flex-wrap gap-2">
                  {balances.map((b) => (
                    <button
                      key={b.asset}
                      type="button"
                      onClick={() => setSelectedAsset(b.asset)}
                      className={`px-3 py-1.5 rounded text-xs font-mono font-bold cursor-pointer transition-colors ${
                        selectedAsset === b.asset
                          ? 'bg-[#842226] text-white'
                          : 'bg-[#181c25] text-[#8e95a5] hover:text-white'
                      }`}
                    >
                      {b.asset}
                    </button>
                  ))}
                </div>
              </div>

              {/* Dedicated Address / Clearing details */}
              <div className="bg-[#0b0d10] p-4 rounded-sm border border-[#1f242e] space-y-2 font-mono-num text-xs">
                <span className="text-[10px] text-[#767e8f] uppercase block">
                  {assetInfo.isFiat ? 'Designated UK Bank Account & Sort Code' : 'Segregated Manchester Vault Deposit Address'}
                </span>
                <div className="flex items-center justify-between bg-[#151922] p-2.5 rounded border border-[#232936]">
                  <span className="font-mono text-white text-xs break-all">
                    {assetInfo.isFiat
                      ? 'Sort Code: 04-00-04 | Account: 81234567 | IBAN: GB29MCX040004812345678'
                      : `0xMCX${selectedAsset}VaultManchesterTaproot${Math.random().toString(36).substring(2, 8).toUpperCase()}`}
                  </span>
                  <button
                    onClick={() =>
                      handleCopy(
                        assetInfo.isFiat
                          ? 'GB29MCX040004812345678'
                          : `0xMCX${selectedAsset}VaultManchesterTaproot`
                      )
                    }
                    className="p-1.5 hover:bg-[#252c3c] text-[#8e95a5] hover:text-white rounded cursor-pointer ml-2"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
                {copiedText && <span className="text-[10px] text-emerald-400">Copied to clipboard!</span>}
              </div>

              {/* Deposit Simulation / Real Form */}
              <form onSubmit={handleExecuteDeposit} className="space-y-3 pt-2">
                <div>
                  <label className="block text-xs text-[#8e95a5] mb-1">
                    Deposit Amount ({selectedAsset})
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={depAmount}
                    onChange={(e) => setDepAmount(e.target.value)}
                    className="w-full bg-[#0b0d10] border border-[#242a38] text-white text-sm px-3 py-2 rounded-sm focus:outline-none focus:border-[#842226]"
                    placeholder="Enter amount to credit"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#842226] hover:bg-[#9e2a2f] text-white font-bold py-2.5 rounded-sm text-xs uppercase tracking-wider cursor-pointer transition-all border border-[#b23238]"
                >
                  Simulate Bank Transfer / Blockchain Receipt
                </button>

                {actionFeedback && (
                  <div
                    className={`p-3 rounded text-xs ${
                      actionFeedback.isError
                        ? 'bg-red-950/40 text-red-300 border border-red-800'
                        : 'bg-[#842226]/20 text-[#eae6dd] border border-[#842226]'
                    }`}
                  >
                    {actionFeedback.text}
                  </div>
                )}
              </form>
            </div>

            {/* Deposit History */}
            <div className="lg:col-span-6 bg-[#12151c] border border-[#1f242e] rounded-sm p-6 space-y-4">
              <h3 className="font-display font-bold text-white text-lg">
                Recent Deposits &amp; Confirmations
              </h3>
              <div className="space-y-3 font-mono-num text-xs">
                {deposits.map((d) => (
                  <div key={d.id} className="p-3 bg-[#0e1117] border border-[#1d222e] rounded-sm space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">
                        +{d.amount.toLocaleString()} {d.asset}
                      </span>
                      <span className="text-[10px] bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-semibold">
                        {d.status} ({d.confirmations}/{d.requiredConfirmations} Confirms)
                      </span>
                    </div>
                    <div className="text-[11px] text-[#767e8f] flex justify-between">
                      <span>{d.network}</span>
                      <span>{new Date(d.timestamp).toLocaleString()}</span>
                    </div>
                    <div className="text-[10px] text-[#555d6e] truncate">
                      Tx: {d.txHash}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Withdraw */}
        {activeTab === 'withdraw' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-6 bg-[#12151c] border border-[#1f242e] rounded-sm p-6 space-y-4">
              <h3 className="font-display font-bold text-white text-lg">
                Institutional Withdrawal &middot; {selectedAsset}
              </h3>
              <p className="text-xs text-[#8e95a5]">
                Withdrawals from MCX undergo cryptographic threshold signature verification and automated OFAC / UK Sanctions screening before broadcast.
              </p>

              <form onSubmit={handleExecuteWithdrawal} className="space-y-4">
                <div>
                  <div className="flex justify-between text-xs text-[#8e95a5] mb-1">
                    <span>Amount to Withdraw ({selectedAsset})</span>
                    <span>Avail: {currentBalance?.available.toLocaleString()} {selectedAsset}</span>
                  </div>
                  <input
                    type="number"
                    step="any"
                    value={wthAmount}
                    onChange={(e) => setWthAmount(e.target.value)}
                    className="w-full bg-[#0b0d10] border border-[#242a38] text-white text-sm px-3 py-2 rounded-sm focus:outline-none focus:border-[#842226]"
                    placeholder="0.00"
                  />
                </div>

                <div>
                  <label className="block text-xs text-[#8e95a5] mb-1">
                    Destination Address / Whitelisted IBAN
                  </label>
                  <input
                    type="text"
                    value={wthAddress}
                    onChange={(e) => setWthAddress(e.target.value)}
                    className="w-full bg-[#0b0d10] border border-[#242a38] text-white text-xs px-3 py-2 rounded-sm focus:outline-none focus:border-[#842226] font-mono"
                    placeholder="Enter external address or IBAN"
                  />
                </div>

                <div className="p-3 bg-[#0a0c10] border border-[#1e2330] rounded-sm text-xs space-y-1 font-mono-num text-[#8e95a5]">
                  <div className="flex justify-between">
                    <span>Network / Custody Fee:</span>
                    <span className="text-white">{assetInfo.withdrawalFee} {selectedAsset}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Minimum Withdrawal:</span>
                    <span>{assetInfo.minWithdrawal} {selectedAsset}</span>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#842226] hover:bg-[#9e2a2f] text-white font-bold py-2.5 rounded-sm text-xs uppercase tracking-wider cursor-pointer transition-all border border-[#b23238]"
                >
                  Authorize &amp; Broadcast Settlement
                </button>

                {actionFeedback && (
                  <div
                    className={`p-3 rounded text-xs ${
                      actionFeedback.isError
                        ? 'bg-red-950/40 text-red-300 border border-red-800'
                        : 'bg-[#842226]/20 text-[#eae6dd] border border-[#842226]'
                    }`}
                  >
                    {actionFeedback.text}
                  </div>
                )}
              </form>
            </div>

            {/* Withdrawals Log */}
            <div className="lg:col-span-6 bg-[#12151c] border border-[#1f242e] rounded-sm p-6 space-y-4">
              <h3 className="font-display font-bold text-white text-lg">
                Recent Withdrawal Dispatches
              </h3>
              <div className="space-y-3 font-mono-num text-xs">
                {withdrawals.map((w) => (
                  <div key={w.id} className="p-3 bg-[#0e1117] border border-[#1d222e] rounded-sm space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#e67a7f]">
                        -{w.amount.toLocaleString()} {w.asset}
                      </span>
                      <span className="text-[10px] bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-semibold">
                        {w.status}
                      </span>
                    </div>
                    <div className="text-[11px] text-[#767e8f] flex justify-between">
                      <span className="truncate max-w-xs">To: {w.destinationAddress}</span>
                      <span>{new Date(w.timestamp).toLocaleTimeString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Complete Ledger */}
        {activeTab === 'ledger' && (
          <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-white text-lg">
                Double-Entry Authoritative General Ledger Log
              </h3>
              <span className="text-xs font-mono text-[#c59f5b]">
                DEBITS === CREDITS (ZERO SLIPPAGE TOLERANCE)
              </span>
            </div>

            <table className="w-full text-left font-mono-num text-xs">
              <thead>
                <tr className="bg-[#161a22] text-[#717887] text-[10px] uppercase border-b border-[#202532]">
                  <th className="py-2.5 px-3">Entry ID</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">Debit Account</th>
                  <th className="py-2.5 px-3">Credit Account</th>
                  <th className="py-2.5 px-3">Asset &amp; Amount</th>
                  <th className="py-2.5 px-3">Reference / Tx</th>
                  <th className="py-2.5 px-3">Description</th>
                  <th className="py-2.5 px-3 text-right">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#181d27]">
                {recentLedgerEntries.map((l) => (
                  <tr key={l.id} className="hover:bg-[#161a22]">
                    <td className="py-2.5 px-3 font-mono text-[11px] text-[#9fa6b2]">{l.id}</td>
                    <td className="py-2.5 px-3">
                      <span className="text-[10px] bg-[#1a1f29] text-[#c59f5b] px-1.5 py-0.5 rounded font-semibold">
                        {l.type}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-[#8e95a5] font-mono text-[11px]">{l.debitAccount}</td>
                    <td className="py-2.5 px-3 text-[#8e95a5] font-mono text-[11px]">{l.creditAccount}</td>
                    <td className="py-2.5 px-3 font-semibold text-white">
                      {l.amount.toLocaleString()} {l.asset}
                    </td>
                    <td className="py-2.5 px-3 text-[#828a99] font-mono text-[11px]">{l.referenceId}</td>
                    <td className="py-2.5 px-3 text-[#a8b0c0] max-w-xs truncate">{l.description}</td>
                    <td className="py-2.5 px-3 text-right text-[#717887]">
                      {new Date(l.timestamp).toLocaleTimeString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Tab 5: Vaults Architecture */}
        {activeTab === 'vaults' && (
          <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-6 space-y-6">
            <h3 className="font-display font-bold text-white text-xl">
              Manchester Subterranean Cryptographic Vault Specifications
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
              <div className="p-4 bg-[#0a0c10] border border-[#1e2330] rounded-sm space-y-2">
                <span className="text-[#842226] font-display font-bold text-sm block">1. Physical Facility</span>
                <p className="text-[#8e95a5] leading-relaxed">
                  Engineered inside former bank vaults in Manchester’s Deansgate and Castlefield railway arch masonry.
                  Faraday shielded and seismic-dampened with biometric multi-custodian quorum.
                </p>
              </div>
              <div className="p-4 bg-[#0a0c10] border border-[#1e2330] rounded-sm space-y-2">
                <span className="text-[#c59f5b] font-display font-bold text-sm block">2. Multi-Party Computation</span>
                <p className="text-[#8e95a5] leading-relaxed">
                  4-of-7 threshold signature scheme (TSS) distributed across independent British geographic enclaves.
                  Zero single points of failure.
                </p>
              </div>
              <div className="p-4 bg-[#0a0c10] border border-[#1e2330] rounded-sm space-y-2">
                <span className="text-emerald-400 font-display font-bold text-sm block">3. FCA &amp; BoE Interoperability</span>
                <p className="text-[#8e95a5] leading-relaxed">
                  Segregated client custody trust structures. British Sterling fiat funds held in direct settlement accounts
                  with UK Tier-1 clearing institutions under English law.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
