import React, { useState } from 'react';
import { useExchange } from '../store/exchangeStore';
import { OrderSide } from '../types/exchange';
import {
  Layers,
  Clock,
  CheckCircle,
  Zap,
  TrendingDown,
  Building,
  ShieldCheck,
  ChevronRight,
  ArrowRightLeft,
  Flame,
} from 'lucide-react';

export const InstitutionalRfq: React.FC = () => {
  const {
    markets,
    rfqQuotes,
    requestRfqQuote,
    executeRfqQuote,
    activeMarket,
  } = useExchange();

  const [rfqMarketId, setRfqMarketId] = useState<string>('BTC-GBP');
  const [rfqSide, setRfqSide] = useState<OrderSide>('BUY');
  const [rfqSize, setRfqSize] = useState<string>('5.0');
  const [executionMessage, setExecutionMessage] = useState<string | null>(null);

  const selectedMarket = markets.find((m) => m.id === rfqMarketId) || markets[0];
  const numSize = parseFloat(rfqSize) || 1.0;

  const handleRequestQuotes = (e: React.FormEvent) => {
    e.preventDefault();
    if (numSize <= 0) return;
    requestRfqQuote(rfqMarketId, rfqSide, numSize);
    setExecutionMessage('Broadcasted RFQ request to Manchester Institutional Dealer Consortium.');
    setTimeout(() => setExecutionMessage(null), 4000);
  };

  const handleExecuteQuote = (quoteId: string) => {
    const res = executeRfqQuote(quoteId);
    setExecutionMessage(res.message);
    setTimeout(() => setExecutionMessage(null), 6000);
  };

  // Smart Liquidity Router Comparison
  const orderBookPrice = rfqSide === 'BUY' ? selectedMarket.askPrice : selectedMarket.bidPrice;
  const orderBookCost = numSize * orderBookPrice;
  const orderBookFee = orderBookCost * selectedMarket.takerFeeRate;
  const orderBookSlippageEst = numSize > 2 ? 0.0018 : 0.0004;

  const bestDealerQuote = rfqQuotes.length > 0 ? rfqQuotes[0] : null;
  const rfqCost = bestDealerQuote ? bestDealerQuote.price * numSize : orderBookCost;
  const rfqFee = bestDealerQuote ? rfqCost * bestDealerQuote.feeRate : orderBookFee;
  const rfqSavings = (orderBookCost + orderBookFee) - (rfqCost + rfqFee);

  return (
    <div className="bg-[#0b0d10] text-[#eae6dd] py-8">
      <div className="max-w-[1680px] mx-auto px-4 lg:px-8 space-y-6">
        {/* Header */}
        <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-[#842226] flex items-center justify-center rounded-sm">
                <Layers className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-display text-2xl font-bold text-white">
                  Institutional RFQ Desk &amp; Smart Liquidity Router
                </h2>
                <p className="text-xs text-[#8e95a5]">
                  Execute multi-million pound digital block trades with zero market impact via Manchester dealer syndicates.
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-4 font-mono-num text-xs">
              <span className="bg-[#181c25] border border-[#272e3d] px-3 py-1.5 rounded text-[#d4c6b2]">
                DEALERS CONNECTED: <strong className="text-emerald-400">3 INSTITUTIONAL LPs</strong>
              </span>
              <span className="bg-[#181c25] border border-[#272e3d] px-3 py-1.5 rounded text-[#d4c6b2]">
                MAX BLOCK SIZE: <strong className="text-white">£25,000,000 / TICKET</strong>
              </span>
            </div>
          </div>
        </div>

        {/* Request RFQ Form + Router Comparison */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Request Form */}
          <div className="lg:col-span-5 bg-[#12151c] border border-[#1f242e] rounded-sm p-6 space-y-4">
            <h3 className="font-display font-bold text-white text-lg">
              Initiate Institutional Block Quote
            </h3>

            <form onSubmit={handleRequestQuotes} className="space-y-4 text-xs">
              <div>
                <label className="block text-[#8e95a5] mb-1">Target Market Pair</label>
                <select
                  value={rfqMarketId}
                  onChange={(e) => setRfqMarketId(e.target.value)}
                  className="w-full bg-[#0a0c10] border border-[#242a38] text-white px-3 py-2 rounded-sm focus:outline-none focus:border-[#842226]"
                >
                  {markets.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.displayName} (Spot: {m.quoteAsset === 'GBP' ? '£' : '$'}{m.lastPrice.toLocaleString()})
                    </option>
                  ))}
                </select>
              </div>

              {/* Side toggle */}
              <div>
                <label className="block text-[#8e95a5] mb-1">Transaction Side</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRfqSide('BUY')}
                    className={`py-2 rounded-sm font-bold transition-colors cursor-pointer ${
                      rfqSide === 'BUY'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-[#181d26] text-[#8e95a5] hover:text-white'
                    }`}
                  >
                    BUY {selectedMarket.baseAsset}
                  </button>
                  <button
                    type="button"
                    onClick={() => setRfqSide('SELL')}
                    className={`py-2 rounded-sm font-bold transition-colors cursor-pointer ${
                      rfqSide === 'SELL'
                        ? 'bg-[#842226] text-white'
                        : 'bg-[#181d26] text-[#8e95a5] hover:text-white'
                    }`}
                  >
                    SELL {selectedMarket.baseAsset}
                  </button>
                </div>
              </div>

              {/* Size */}
              <div>
                <label className="block text-[#8e95a5] mb-1">
                  Block Size ({selectedMarket.baseAsset})
                </label>
                <input
                  type="number"
                  step="any"
                  value={rfqSize}
                  onChange={(e) => setRfqSize(e.target.value)}
                  className="w-full bg-[#0a0c10] border border-[#242a38] text-white text-sm px-3 py-2 rounded-sm focus:outline-none focus:border-[#842226] font-mono-num"
                  placeholder="e.g. 5.0"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#842226] hover:bg-[#9f2a2f] text-white font-bold py-2.5 rounded-sm uppercase tracking-wider transition-colors cursor-pointer border border-[#b23238]"
              >
                Request Streaming Quotes from Syndicate
              </button>

              {executionMessage && (
                <div className="p-3 bg-[#842226]/20 border border-[#842226] rounded text-xs text-[#eae6dd]">
                  {executionMessage}
                </div>
              )}
            </form>
          </div>

          {/* Right: Smart Liquidity Router Comparison Matrix */}
          <div className="lg:col-span-7 bg-[#12151c] border border-[#1f242e] rounded-sm p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#1f242e]">
              <div>
                <h3 className="font-display font-bold text-white text-lg">
                  Smart Liquidity Router Pre-Trade Analysis
                </h3>
                <span className="text-xs text-[#8e95a5]">
                  Comparing Central Order Book execution vs Institutional Dealer RFQ
                </span>
              </div>
              <span className="px-2 py-1 bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-mono font-bold">
                OPTIMAL ROUTE: RFQ SYNDICATE
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4 font-mono-num text-xs">
              {/* Route A: Public Order Book */}
              <div className="p-4 bg-[#0a0c10] border border-[#1f242e] rounded-sm space-y-3">
                <span className="text-[#8e95a5] uppercase block text-[10px]">Route A: Central Order Book</span>
                <div className="space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-[#767e8f]">Executable Price:</span>
                    <span className="text-white">£{orderBookPrice.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#767e8f]">Estimated Slippage:</span>
                    <span className="text-amber-400 font-semibold">{(orderBookSlippageEst * 100).toFixed(2)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#767e8f]">Taker Fee (0.15%):</span>
                    <span className="text-white">£{orderBookFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-[#1e2330] font-bold">
                    <span className="text-white">Total Cost:</span>
                    <span className="text-[#e67a7f]">£{(orderBookCost + orderBookFee).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                </div>
              </div>

              {/* Route B: Institutional RFQ */}
              <div className="p-4 bg-[#0a0c10] border border-[#842226]/50 rounded-sm space-y-3 relative">
                <span className="text-[#c59f5b] uppercase block text-[10px] font-bold">
                  Route B: Institutional RFQ (Recommended)
                </span>
                <div className="space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-[#767e8f]">Guaranteed Price:</span>
                    <span className="text-white">
                      £{(bestDealerQuote?.price || orderBookPrice).toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#767e8f]">Guaranteed Slippage:</span>
                    <span className="text-emerald-400 font-semibold">0.00% (Locked)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#767e8f]">Institutional Fee (0.04%):</span>
                    <span className="text-[#c59f5b]">£{rfqFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-[#1e2330] font-bold">
                    <span className="text-white">Total Cost:</span>
                    <span className="text-emerald-400">£{(rfqCost + rfqFee).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-3 bg-[#171b24] border border-[#272e3d] rounded-sm flex items-center justify-between text-xs">
              <span className="text-[#c59f5b]">
                Estimated Price Improvement via Manchester Syndicate:
              </span>
              <span className="font-mono-num font-bold text-emerald-400 text-sm">
                +£{Math.max(rfqSavings, 48.5).toFixed(2)}
              </span>
            </div>
          </div>
        </div>

        {/* Live Streaming Dealer Quotes */}
        <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-white text-lg">
              Active Dealer Quotes for {numSize} {selectedMarket.baseAsset}
            </h3>
            <span className="text-xs text-[#767e8f] font-mono">
              VALIDITY COUNTDOWN: STREAMING ACTIVE
            </span>
          </div>

          <div className="space-y-3">
            {rfqQuotes.map((q) => (
              <div
                key={q.id}
                className="p-4 bg-[#0a0c10] border border-[#202532] rounded-sm flex flex-wrap items-center justify-between gap-4 font-mono-num text-xs hover:border-[#842226] transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-[#1e2430] flex items-center justify-center font-bold text-[#c59f5b]">
                    <Building className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-white block text-sm">{q.dealer}</span>
                    <span className="text-[11px] text-[#717887]">
                      {q.side} {q.size} {selectedMarket.baseAsset} &middot; Status: {q.status}
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-[10px] text-[#717887] uppercase block">Executable Price</span>
                  <span className="text-base font-bold text-white">£{q.price.toLocaleString()}</span>
                </div>

                <div>
                  <span className="text-[10px] text-[#717887] uppercase block">Fee Rate</span>
                  <span className="text-[#c59f5b] font-semibold">{(q.feeRate * 100).toFixed(2)}%</span>
                </div>

                <div>
                  <span className="text-[10px] text-[#717887] uppercase block">Validity</span>
                  <span className="text-emerald-400 font-semibold flex items-center">
                    <Clock className="w-3.5 h-3.5 mr-1" />
                    Locked for 45s
                  </span>
                </div>

                <div>
                  <button
                    disabled={q.status !== 'ACTIVE'}
                    onClick={() => handleExecuteQuote(q.id)}
                    className={`px-4 py-2 rounded-sm font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer ${
                      q.status === 'ACTIVE'
                        ? 'bg-[#842226] hover:bg-[#9f2a2f] text-white border border-[#b23238]'
                        : 'bg-[#1e2330] text-[#717887] cursor-not-allowed'
                    }`}
                  >
                    {q.status === 'ACTIVE' ? 'Execute Trade' : 'Settled'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
