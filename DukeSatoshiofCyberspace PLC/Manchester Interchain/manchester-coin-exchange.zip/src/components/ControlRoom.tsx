import React, { useState } from 'react';
import { useExchange } from '../store/exchangeStore';
import {
  Activity,
  Cpu,
  ShieldCheck,
  AlertTriangle,
  Radio,
  Server,
  RefreshCw,
  Search,
  Eye,
  CheckCircle2,
  Clock,
  Zap,
} from 'lucide-react';

export const ControlRoom: React.FC = () => {
  const {
    engineHealth,
    surveillanceAlerts,
    markets,
    isSimulating,
    toggleSimulation,
  } = useExchange();

  const [filterSeverity, setFilterSeverity] = useState<string>('ALL');

  const filteredAlerts = surveillanceAlerts.filter((a) => {
    if (filterSeverity === 'ALL') return true;
    return a.severity === filterSeverity;
  });

  return (
    <div className="bg-[#0b0d10] text-[#eae6dd] py-8">
      <div className="max-w-[1680px] mx-auto px-4 lg:px-8 space-y-6">
        {/* Header */}
        <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-6">
          <div className="flex flex-wrap items-center justify-between gap-6">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-[#842226] flex items-center justify-center rounded-sm">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h2 className="font-display text-2xl font-bold text-white">
                    Exchange Control Room &amp; Market Surveillance
                  </h2>
                  <span className="bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded uppercase">
                    SYSTEM OPERATIONAL
                  </span>
                </div>
                <p className="text-xs text-[#8e95a5]">
                  Real-time matching engine diagnostics, low-latency telemetry, order-book anomaly detection, and regulatory compliance surveillance.
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <button
                onClick={toggleSimulation}
                className={`px-3 py-2 text-xs font-semibold rounded-sm transition-colors cursor-pointer border ${
                  isSimulating
                    ? 'bg-[#842226]/30 text-[#e67a7f] border-[#842226] hover:bg-[#842226]/50'
                    : 'bg-[#181d26] text-[#8e95a5] border-[#252d3c] hover:text-white'
                }`}
              >
                {isSimulating ? 'Pause Synthetic Market Flow' : 'Resume Synthetic Market Flow'}
              </button>
            </div>
          </div>
        </div>

        {/* Engine Telemetry Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 font-mono-num text-xs">
          <div className="p-5 bg-[#12151c] border border-[#1f242e] rounded-sm space-y-2">
            <div className="flex justify-between items-center text-[#717887]">
              <span className="uppercase text-[10px]">Matching Core Latency</span>
              <Cpu className="w-4 h-4 text-[#c59f5b]" />
            </div>
            <span className="text-2xl font-bold text-white">{engineHealth.latencyMicros} µs</span>
            <span className="text-[11px] text-emerald-400 block">Sub-millisecond Rust event loop</span>
          </div>

          <div className="p-5 bg-[#12151c] border border-[#1f242e] rounded-sm space-y-2">
            <div className="flex justify-between items-center text-[#717887]">
              <span className="uppercase text-[10px]">Engine Throughput</span>
              <Zap className="w-4 h-4 text-emerald-400" />
            </div>
            <span className="text-2xl font-bold text-white">{engineHealth.matchingThroughputTPS.toLocaleString()} TPS</span>
            <span className="text-[11px] text-[#8e95a5] block">Stress tested up to 250k TPS</span>
          </div>

          <div className="p-5 bg-[#12151c] border border-[#1f242e] rounded-sm space-y-2">
            <div className="flex justify-between items-center text-[#717887]">
              <span className="uppercase text-[10px]">Processed Orders</span>
              <Server className="w-4 h-4 text-[#842226]" />
            </div>
            <span className="text-2xl font-bold text-white">{engineHealth.totalOrdersProcessed.toLocaleString()}</span>
            <span className="text-[11px] text-[#8e95a5] block">Deterministic audit sequence</span>
          </div>

          <div className="p-5 bg-[#12151c] border border-[#1f242e] rounded-sm space-y-2">
            <div className="flex justify-between items-center text-[#717887]">
              <span className="uppercase text-[10px]">Active WebSockets</span>
              <Radio className="w-4 h-4 text-blue-400" />
            </div>
            <span className="text-2xl font-bold text-white">{engineHealth.activeSockets.toLocaleString()}</span>
            <span className="text-[11px] text-emerald-400 block">100% Heartbeat synchronization</span>
          </div>
        </div>

        {/* Market Surveillance Anomaly Detection Engine */}
        <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-[#1f242e]">
            <div className="flex items-center space-x-3">
              <Eye className="w-5 h-5 text-[#842226]" />
              <div>
                <h3 className="font-display font-bold text-white text-lg">
                  Automated Market Surveillance Engine
                </h3>
                <span className="text-xs text-[#8e95a5]">
                  Scans for spoofing, layering, synthetic wash-trading, and abnormal quoting velocity.
                </span>
              </div>
            </div>

            {/* Severity Filter */}
            <div className="flex items-center space-x-2 text-xs">
              <span className="text-[#717887] text-[10px] uppercase">Severity:</span>
              {['ALL', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].map((sev) => (
                <button
                  key={sev}
                  onClick={() => setFilterSeverity(sev)}
                  className={`px-2.5 py-1 rounded text-[11px] font-mono cursor-pointer transition-colors ${
                    filterSeverity === sev
                      ? 'bg-[#842226] text-white font-bold'
                      : 'bg-[#181c25] text-[#8e95a5] hover:text-white'
                  }`}
                >
                  {sev}
                </button>
              ))}
            </div>
          </div>

          {/* Surveillance Alerts List */}
          <div className="space-y-3 font-mono-num text-xs">
            {filteredAlerts.length === 0 ? (
              <div className="text-center py-8 text-[#717887]">
                No active surveillance anomalies detected in current window.
              </div>
            ) : (
              filteredAlerts.map((a) => (
                <div
                  key={a.id}
                  className="p-4 bg-[#0a0c10] border border-[#1f242e] rounded-sm space-y-2 hover:border-[#842226] transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          a.severity === 'CRITICAL'
                            ? 'bg-red-950 text-red-300 border border-red-700'
                            : a.severity === 'HIGH'
                            ? 'bg-red-900/40 text-red-400'
                            : a.severity === 'MEDIUM'
                            ? 'bg-amber-900/40 text-amber-300'
                            : 'bg-blue-900/30 text-blue-300'
                        }`}
                      >
                        {a.severity}
                      </span>
                      <span className="font-bold text-white">{a.type.replace('_', ' ')}</span>
                      <span className="text-[#717887]">Market: {a.marketId}</span>
                    </div>

                    <div className="text-[11px] text-[#717887] flex items-center space-x-2">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{new Date(a.timestamp).toLocaleTimeString()}</span>
                      <span className="bg-[#181c25] px-2 py-0.5 rounded text-[#d4c6b2] font-semibold">
                        {a.status}
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-[#a2abbd] font-sans pl-1">
                    {a.details}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Operational Infrastructure Map */}
        <div className="bg-[#12151c] border border-[#1f242e] rounded-sm p-6 space-y-4">
          <h3 className="font-display font-bold text-white text-lg">
            Active Market Trading Engines &amp; Circuit Breakers
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs font-mono-num">
            {markets.map((m) => (
              <div key={m.id} className="p-3 bg-[#0a0c10] border border-[#1f242e] rounded-sm space-y-1">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-white">{m.displayName}</span>
                  <span className="text-[10px] bg-emerald-500/15 text-emerald-400 px-1.5 py-0.5 rounded">
                    NORMAL
                  </span>
                </div>
                <div className="flex justify-between text-[#8e95a5] text-[11px]">
                  <span>Circuit Breaker:</span>
                  <span>+/- 12% Max Velocity</span>
                </div>
                <div className="flex justify-between text-[#8e95a5] text-[11px]">
                  <span>Last Match:</span>
                  <span className="text-white">£{m.lastPrice.toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
