import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  MarketPair,
  Order,
  TradeFill,
  OrderBook,
  Candle,
  CustomerBalance,
  LedgerEntry,
  DepositRequest,
  WithdrawalRequest,
  RFQQuote,
  SurveillanceAlert,
  EngineHealth,
  AssetSymbol,
  OrderSide,
  OrderType,
  StressScenarioResult,
} from '../types/exchange';
import { INITIAL_MARKETS, ASSETS_REGISTRY, generateInitialCandles } from '../data/initialMarkets';
import { PriceTimeMatchingEngine } from '../engine/matchingEngine';
import { DoubleEntryLedger } from '../engine/ledger';

interface ExchangeContextType {
  markets: MarketPair[];
  activeMarketId: string;
  activeMarket: MarketPair;
  setActiveMarketId: (id: string) => void;
  orderBook: OrderBook;
  recentTrades: TradeFill[];
  candles: Candle[];
  timeframe: string;
  setTimeframe: (tf: string) => void;
  userOrders: Order[];
  userFills: TradeFill[];
  balances: CustomerBalance[];
  totalPortfolioGBP: number;
  totalPortfolioUSD: number;
  ledger: DoubleEntryLedger;
  recentLedgerEntries: LedgerEntry[];
  deposits: DepositRequest[];
  withdrawals: WithdrawalRequest[];
  rfqQuotes: RFQQuote[];
  surveillanceAlerts: SurveillanceAlert[];
  engineHealth: EngineHealth;
  isSimulating: boolean;
  toggleSimulation: () => void;
  submitUserOrder: (params: {
    marketId: string;
    side: OrderSide;
    type: OrderType;
    price: number;
    size: number;
  }) => { success: boolean; message: string; order?: Order };
  cancelUserOrder: (orderId: string) => { success: boolean; message: string };
  depositFunds: (asset: AssetSymbol, amount: number, network?: string) => void;
  requestWithdrawal: (asset: AssetSymbol, amount: number, destinationAddress: string) => { success: boolean; message: string };
  requestRfqQuote: (marketId: string, side: OrderSide, size: number) => RFQQuote[];
  executeRfqQuote: (quoteId: string) => { success: boolean; message: string };
  stressTestResult: StressScenarioResult | null;
  runStressScenario: (scenario: 'FLASH_CRASH_BTC' | 'ETH_LIQUIDITY_SHOCK' | 'STABLECOIN_DEPEG' | 'STERLING_VOLATILITY') => void;
  clearStressScenario: () => void;
  reconcileAudit: () => ReturnType<DoubleEntryLedger['auditReconciliation']>;
}

const ExchangeContext = createContext<ExchangeContextType | null>(null);

// Matching engines registry per market
const enginesMap = new Map<string, PriceTimeMatchingEngine>();

function getOrCreateEngine(marketId: string, initialPrice: number): PriceTimeMatchingEngine {
  if (!enginesMap.has(marketId)) {
    const engine = new PriceTimeMatchingEngine(marketId);
    // Seed initial realistic order book
    const bids: Array<{ price: number; size: number }> = [];
    const asks: Array<{ price: number; size: number }> = [];

    for (let i = 1; i <= 15; i++) {
      const bidDiff = (initialPrice * (0.0003 + i * 0.0008));
      const askDiff = (initialPrice * (0.0003 + i * 0.0008));
      const bidPrice = Math.round((initialPrice - bidDiff) * 100) / 100;
      const askPrice = Math.round((initialPrice + askDiff) * 100) / 100;
      const size = Math.round((0.35 + Math.random() * 2.5) * 1000) / 1000;

      bids.push({ price: bidPrice, size });
      asks.push({ price: askPrice, size });
    }
    engine.seedBook(bids, asks);
    enginesMap.set(marketId, engine);
  }
  return enginesMap.get(marketId)!;
}

export const ExchangeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [markets, setMarkets] = useState<MarketPair[]>(INITIAL_MARKETS);
  const [activeMarketId, setActiveMarketId] = useState<string>('BTC-GBP');
  const [timeframe, setTimeframe] = useState<string>('1H');
  const [isSimulating, setIsSimulating] = useState<boolean>(true);

  // Core Ledger instance
  const ledgerRef = useRef<DoubleEntryLedger>(new DoubleEntryLedger());
  const [recentLedgerEntries, setRecentLedgerEntries] = useState<LedgerEntry[]>([]);

  // User state
  const [userOrders, setUserOrders] = useState<Order[]>([]);
  const [userFills, setUserFills] = useState<TradeFill[]>([]);

  const [balances, setBalances] = useState<CustomerBalance[]>([
    { asset: 'GBP', available: 128450.0, locked: 0.0, total: 128450.0, gbpRate: 1.0, gbpValue: 128450.0 },
    { asset: 'BTC', available: 2.45, locked: 0.0, total: 2.45, gbpRate: 72436.21, gbpValue: 177468.71 },
    { asset: 'ETH', available: 28.5, locked: 0.0, total: 28.5, gbpRate: 3942.17, gbpValue: 112351.84 },
    { asset: 'SOL', available: 140.0, locked: 0.0, total: 140.0, gbpRate: 142.36, gbpValue: 19930.4 },
    { asset: 'XRP', available: 12500.0, locked: 0.0, total: 12500.0, gbpRate: 0.5214, gbpValue: 6517.5 },
    { asset: 'USDC', available: 75000.0, locked: 0.0, total: 75000.0, gbpRate: 0.7634, gbpValue: 57255.0 },
    { asset: 'USDT', available: 50000.0, locked: 0.0, total: 50000.0, gbpRate: 0.7634, gbpValue: 38170.0 },
    { asset: 'EUR', available: 15000.0, locked: 0.0, total: 15000.0, gbpRate: 0.855, gbpValue: 12825.0 },
  ]);

  // Active market helpers
  const activeMarket = useMemo(() => {
    return markets.find((m) => m.id === activeMarketId) || markets[0];
  }, [markets, activeMarketId]);

  // Candles store per market
  const [candlesMap, setCandlesMap] = useState<Record<string, Candle[]>>(() => {
    const initial: Record<string, Candle[]> = {};
    INITIAL_MARKETS.forEach((m) => {
      initial[m.id] = generateInitialCandles(m.lastPrice, 50, 60);
    });
    return initial;
  });

  const candles = candlesMap[activeMarketId] || [];

  // OrderBook state
  const [orderBook, setOrderBook] = useState<OrderBook>(() => {
    const engine = getOrCreateEngine('BTC-GBP', 72436.21);
    return engine.getOrderBook(15);
  });

  // Recent Trades state
  const [recentTrades, setRecentTrades] = useState<TradeFill[]>([]);

  // Deposits & Withdrawals
  const [deposits, setDeposits] = useState<DepositRequest[]>([
    {
      id: 'dep_001_fps',
      asset: 'GBP',
      amount: 50000.0,
      network: 'Bank of England Faster Payments',
      address: 'GB29MCX040004812345678',
      txHash: 'FPS-REF-894103859',
      confirmations: 1,
      requiredConfirmations: 1,
      status: 'CONFIRMED',
      timestamp: Date.now() - 3600000 * 4,
    },
    {
      id: 'dep_002_btc',
      asset: 'BTC',
      amount: 1.5,
      network: 'Bitcoin Native Taproot',
      address: 'bc1p9manchester87exchange0x3vault884',
      txHash: '7f9c2d1b54a8837e28d9c0e481f33c829e0114f529a8c1719b023f990ac8419b',
      confirmations: 6,
      requiredConfirmations: 3,
      status: 'CONFIRMED',
      timestamp: Date.now() - 3600000 * 12,
    },
  ]);

  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([
    {
      id: 'wth_001_eth',
      asset: 'ETH',
      amount: 5.0,
      networkFee: 0.002,
      destinationAddress: '0x3841D77bC9c9aD47065963E8C1Fa70559eEb30cA',
      status: 'SETTLED',
      txHash: '0x1a87b6408e04b4c73045f29910dca23b6928811807d921319762dfadce84e2a1',
      timestamp: Date.now() - 3600000 * 2,
    },
  ]);

  // Institutional RFQ Quotes
  const [rfqQuotes, setRfqQuotes] = useState<RFQQuote[]>([
    {
      id: 'rfq_q_01',
      marketId: 'BTC-GBP',
      dealer: 'Castlefield Capital Partners',
      side: 'BUY',
      size: 5.0,
      price: 72445.0,
      feeRate: 0.0005,
      slippageEstimated: 0.0001,
      validUntil: Date.now() + 45000,
      status: 'ACTIVE',
    },
    {
      id: 'rfq_q_02',
      marketId: 'BTC-GBP',
      dealer: 'Deansgate Quantitative LP',
      side: 'BUY',
      size: 5.0,
      price: 72442.5,
      feeRate: 0.0004,
      slippageEstimated: 0.0,
      validUntil: Date.now() + 45000,
      status: 'ACTIVE',
    },
    {
      id: 'rfq_q_03',
      marketId: 'BTC-GBP',
      dealer: 'Spinningfields Alpha Liquidity',
      side: 'BUY',
      size: 5.0,
      price: 72448.0,
      feeRate: 0.0006,
      slippageEstimated: 0.0002,
      validUntil: Date.now() + 45000,
      status: 'ACTIVE',
    },
  ]);

  // Surveillance alerts
  const [surveillanceAlerts, setSurveillanceAlerts] = useState<SurveillanceAlert[]>([
    {
      id: 'surv_001',
      timestamp: Date.now() - 1000 * 60 * 18,
      severity: 'LOW',
      type: 'RAPID_CANCELLATION',
      marketId: 'BTC-GBP',
      details: 'Participant MM-928 cancelled 14 quotes within 80ms inside 0.02% spread. Quoting pattern inspected: Compliant inventory repositioning.',
      status: 'INVESTIGATING',
    },
    {
      id: 'surv_002',
      timestamp: Date.now() - 1000 * 60 * 65,
      severity: 'MEDIUM',
      type: 'PRICE_DISLOCATION',
      marketId: 'SOL-GBP',
      details: 'Arbitrage gap detected vs London/New York reference composite (0.34%). Automatically arbitraged by St Peters Arbitrage Desk.',
      status: 'REPORTED',
    },
  ]);

  // Engine health
  const [engineHealth, setEngineHealth] = useState<EngineHealth>({
    status: 'OPTIMAL',
    latencyMicros: 38,
    matchingThroughputTPS: 124500,
    totalOrdersProcessed: 8943201,
    activeSockets: 4182,
    unreconciledDiscrepancies: 0,
    vaultIntegrity: '100% SECURED - COLD CUSTODY OK',
    mempoolSync: 'SYNCHRONIZED',
  });

  const [stressTestResult, setStressTestResult] = useState<StressScenarioResult | null>(null);

  // Sync current active market book & trades
  const syncMarketState = useCallback(() => {
    const engine = getOrCreateEngine(activeMarketId, activeMarket.lastPrice);
    setOrderBook(engine.getOrderBook(16));
    setRecentTrades(engine.getRecentTrades().slice(0, 30));
  }, [activeMarketId, activeMarket.lastPrice]);

  useEffect(() => {
    syncMarketState();
  }, [activeMarketId, syncMarketState]);

  // Update recent ledger entries on mount
  useEffect(() => {
    setRecentLedgerEntries(ledgerRef.current.getRecentEntries(30));
  }, []);

  // Calculate total portfolio values
  const totalPortfolioGBP = useMemo(() => {
    return balances.reduce((sum, b) => sum + b.gbpValue, 0);
  }, [balances]);

  const totalPortfolioUSD = useMemo(() => {
    return totalPortfolioGBP * 1.309; // GBP/USD spot conversion
  }, [totalPortfolioGBP]);

  // Submit User Order to Real Matching Engine
  const submitUserOrder = useCallback(
    ({
      marketId,
      side,
      type,
      price,
      size,
    }: {
      marketId: string;
      side: OrderSide;
      type: OrderType;
      price: number;
      size: number;
    }) => {
      const market = markets.find((m) => m.id === marketId);
      if (!market) {
        return { success: false, message: 'Invalid market selected' };
      }

      if (size <= 0) {
        return { success: false, message: 'Order size must be greater than zero' };
      }

      if (type === 'LIMIT' && price <= 0) {
        return { success: false, message: 'Limit price must be greater than zero' };
      }

      const effectivePrice = type === 'MARKET' ? (side === 'BUY' ? market.askPrice : market.bidPrice) : price;
      const quoteCost = size * effectivePrice;
      const estimatedFee = quoteCost * (type === 'MARKET' ? market.takerFeeRate : market.makerFeeRate);

      // Balance validation and reservation
      if (side === 'BUY') {
        const quoteBalance = balances.find((b) => b.asset === market.quoteAsset);
        const requiredAmount = quoteCost + estimatedFee;
        if (!quoteBalance || quoteBalance.available < requiredAmount) {
          return {
            success: false,
            message: `Insufficient ${market.quoteAsset} balance. Required: ${requiredAmount.toFixed(2)} ${market.quoteAsset}, Available: ${quoteBalance?.available.toFixed(2) || 0}`,
          };
        }

        // Lock balance in ledger & balance state
        setBalances((prev) =>
          prev.map((b) => {
            if (b.asset === market.quoteAsset) {
              const newAvail = b.available - requiredAmount;
              const newLocked = b.locked + requiredAmount;
              return {
                ...b,
                available: Math.max(0, newAvail),
                locked: newLocked,
                total: newAvail + newLocked,
                gbpValue: (newAvail + newLocked) * b.gbpRate,
              };
            }
            return b;
          })
        );

        ledgerRef.current.recordEntry({
          debitAccount: `CUSTOMER_AVAILABLE_${market.quoteAsset}`,
          creditAccount: `CUSTOMER_LOCKED_MARGIN_${market.quoteAsset}`,
          asset: market.quoteAsset,
          amount: requiredAmount,
          referenceId: `LOCK_BUY_${Date.now()}`,
          type: 'INTERNAL_REBALANCE',
          description: `Order placement reserve: BUY ${size} ${market.baseAsset} @ ${effectivePrice} ${market.quoteAsset}`,
        });
      } else {
        // SELL
        const baseBalance = balances.find((b) => b.asset === market.baseAsset);
        if (!baseBalance || baseBalance.available < size) {
          return {
            success: false,
            message: `Insufficient ${market.baseAsset} balance. Required: ${size} ${market.baseAsset}, Available: ${baseBalance?.available.toFixed(4) || 0}`,
          };
        }

        setBalances((prev) =>
          prev.map((b) => {
            if (b.asset === market.baseAsset) {
              const newAvail = b.available - size;
              const newLocked = b.locked + size;
              return {
                ...b,
                available: Math.max(0, newAvail),
                locked: newLocked,
                total: newAvail + newLocked,
                gbpValue: (newAvail + newLocked) * b.gbpRate,
              };
            }
            return b;
          })
        );

        ledgerRef.current.recordEntry({
          debitAccount: `CUSTOMER_AVAILABLE_${market.baseAsset}`,
          creditAccount: `CUSTOMER_LOCKED_MARGIN_${market.baseAsset}`,
          asset: market.baseAsset,
          amount: size,
          referenceId: `LOCK_SELL_${Date.now()}`,
          type: 'INTERNAL_REBALANCE',
          description: `Order placement reserve: SELL ${size} ${market.baseAsset} @ ${effectivePrice}`,
        });
      }

      // Enter matching engine!
      const engine = getOrCreateEngine(marketId, market.lastPrice);
      const newOrderId = `ord_user_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const matchResult = engine.submitOrder({
        id: newOrderId,
        marketId,
        side,
        type,
        price: effectivePrice,
        size,
        createdAt: Date.now(),
        userType: 'CUSTOMER',
      });

      const executedOrder = matchResult.executedOrder;

      // Handle Fills & Ledger settlements
      if (matchResult.fills.length > 0) {
        setUserFills((prev) => [...matchResult.fills, ...prev]);

        for (const fill of matchResult.fills) {
          const filledQuote = fill.quoteVolume;
          const feePaid = fill.takerFee;

          if (side === 'BUY') {
            // User receives Base Asset, pays Quote Asset
            setBalances((prev) =>
              prev.map((b) => {
                if (b.asset === market.baseAsset) {
                  const newAvail = b.available + fill.size;
                  return {
                    ...b,
                    available: newAvail,
                    total: newAvail + b.locked,
                    gbpValue: (newAvail + b.locked) * b.gbpRate,
                  };
                }
                if (b.asset === market.quoteAsset) {
                  const totalPaid = filledQuote + feePaid;
                  const newLocked = Math.max(0, b.locked - totalPaid);
                  return {
                    ...b,
                    locked: newLocked,
                    total: b.available + newLocked,
                    gbpValue: (b.available + newLocked) * b.gbpRate,
                  };
                }
                return b;
              })
            );

            // Authoritative Ledger Settlement
            ledgerRef.current.recordEntry({
              debitAccount: `CUSTOMER_LOCKED_MARGIN_${market.quoteAsset}`,
              creditAccount: `COUNTERPARTY_LP_${market.quoteAsset}`,
              asset: market.quoteAsset,
              amount: filledQuote,
              feeAsset: market.quoteAsset,
              feeAmount: feePaid,
              referenceId: fill.id,
              type: 'TRADE_SETTLEMENT',
              description: `Settlement: MCX Trade ${fill.id} BUY ${fill.size} ${market.baseAsset} @ ${fill.price}`,
            });

            ledgerRef.current.recordEntry({
              debitAccount: `COUNTERPARTY_LP_${market.baseAsset}`,
              creditAccount: `CUSTOMER_AVAILABLE_${market.baseAsset}`,
              asset: market.baseAsset,
              amount: fill.size,
              referenceId: fill.id,
              type: 'TRADE_SETTLEMENT',
              description: `Credit purchased digital asset to Manchester segregated account`,
            });
          } else {
            // User SELL: delivers Base asset, receives Quote asset minus fee
            setBalances((prev) =>
              prev.map((b) => {
                if (b.asset === market.baseAsset) {
                  const newLocked = Math.max(0, b.locked - fill.size);
                  return {
                    ...b,
                    locked: newLocked,
                    total: b.available + newLocked,
                    gbpValue: (b.available + newLocked) * b.gbpRate,
                  };
                }
                if (b.asset === market.quoteAsset) {
                  const netReceive = filledQuote - feePaid;
                  const newAvail = b.available + netReceive;
                  return {
                    ...b,
                    available: newAvail,
                    total: newAvail + b.locked,
                    gbpValue: (newAvail + b.locked) * b.gbpRate,
                  };
                }
                return b;
              })
            );

            ledgerRef.current.recordEntry({
              debitAccount: `CUSTOMER_LOCKED_MARGIN_${market.baseAsset}`,
              creditAccount: `COUNTERPARTY_LP_${market.baseAsset}`,
              asset: market.baseAsset,
              amount: fill.size,
              referenceId: fill.id,
              type: 'TRADE_SETTLEMENT',
              description: `Delivery of ${fill.size} ${market.baseAsset} against execution ${fill.id}`,
            });

            ledgerRef.current.recordEntry({
              debitAccount: `COUNTERPARTY_LP_${market.quoteAsset}`,
              creditAccount: `CUSTOMER_AVAILABLE_${market.quoteAsset}`,
              asset: market.quoteAsset,
              amount: filledQuote - feePaid,
              feeAsset: market.quoteAsset,
              feeAmount: feePaid,
              referenceId: fill.id,
              type: 'TRADE_SETTLEMENT',
              description: `Net settlement proceeds credited to customer ledger account`,
            });
          }
        }

        // Update market ticker last price
        const lastFill = matchResult.fills[matchResult.fills.length - 1];
        setMarkets((prev) =>
          prev.map((m) => {
            if (m.id === marketId) {
              const prevPrice = m.lastPrice;
              const newPrice = lastFill.price;
              const change = ((newPrice - prevPrice) / prevPrice) * 100;
              return {
                ...m,
                lastPrice: newPrice,
                change24h: Math.round((m.change24h + change * 0.1) * 100) / 100,
                volume24hQuote: m.volume24hQuote + lastFill.quoteVolume,
                volume24hBase: m.volume24hBase + lastFill.size,
                high24h: Math.max(m.high24h, newPrice),
                low24h: Math.min(m.low24h, newPrice),
              };
            }
            return m;
          })
        );
      }

      setUserOrders((prev) => [executedOrder, ...prev.filter((o) => o.id !== executedOrder.id)]);
      setRecentLedgerEntries(ledgerRef.current.getRecentEntries(30));
      syncMarketState();

      // Update engine throughput stats
      setEngineHealth((prev) => ({
        ...prev,
        totalOrdersProcessed: prev.totalOrdersProcessed + 1,
        latencyMicros: Math.floor(32 + Math.random() * 14),
      }));

      const fillCount = matchResult.fills.length;
      const fillSummary =
        fillCount > 0
          ? `Matched & executed ${fillCount} fill(s). Status: ${executedOrder.status}`
          : `Order posted to book. Status: ${executedOrder.status}`;

      return {
        success: true,
        message: `Order submitted: ${side} ${size} ${market.baseAsset} @ ${effectivePrice.toFixed(2)} ${market.quoteAsset}. ${fillSummary}`,
        order: executedOrder,
      };
    },
    [markets, balances, syncMarketState]
  );

  // Cancel User Order
  const cancelUserOrder = useCallback(
    (orderId: string) => {
      const existing = userOrders.find((o) => o.id === orderId);
      if (!existing) {
        return { success: false, message: 'Order not found' };
      }
      if (existing.status !== 'OPEN' && existing.status !== 'PARTIALLY_FILLED') {
        return { success: false, message: 'Order cannot be cancelled' };
      }

      const engine = getOrCreateEngine(existing.marketId, 0);
      const cancelled = engine.cancelOrder(orderId);
      const market = markets.find((m) => m.id === existing.marketId);

      if (cancelled && market) {
        // Unlock unfulfilled balance
        const unfulfilledSize = cancelled.remainingSize;
        if (cancelled.side === 'BUY') {
          const lockedQuote = unfulfilledSize * cancelled.price * (1 + market.makerFeeRate);
          setBalances((prev) =>
            prev.map((b) => {
              if (b.asset === market.quoteAsset) {
                const newLocked = Math.max(0, b.locked - lockedQuote);
                const newAvail = b.available + lockedQuote;
                return {
                  ...b,
                  available: newAvail,
                  locked: newLocked,
                  total: newAvail + newLocked,
                  gbpValue: (newAvail + newLocked) * b.gbpRate,
                };
              }
              return b;
            })
          );
        } else {
          setBalances((prev) =>
            prev.map((b) => {
              if (b.asset === market.baseAsset) {
                const newLocked = Math.max(0, b.locked - unfulfilledSize);
                const newAvail = b.available + unfulfilledSize;
                return {
                  ...b,
                  available: newAvail,
                  locked: newLocked,
                  total: newAvail + newLocked,
                  gbpValue: (newAvail + newLocked) * b.gbpRate,
                };
              }
              return b;
            })
          );
        }

        ledgerRef.current.recordEntry({
          debitAccount: `CUSTOMER_LOCKED_MARGIN_${cancelled.side === 'BUY' ? market.quoteAsset : market.baseAsset}`,
          creditAccount: `CUSTOMER_AVAILABLE_${cancelled.side === 'BUY' ? market.quoteAsset : market.baseAsset}`,
          asset: cancelled.side === 'BUY' ? market.quoteAsset : market.baseAsset,
          amount: cancelled.side === 'BUY' ? unfulfilledSize * cancelled.price : unfulfilledSize,
          referenceId: `CANCEL_${orderId}`,
          type: 'INTERNAL_REBALANCE',
          description: `Order cancellation refund for order ${orderId}`,
        });

        setUserOrders((prev) =>
          prev.map((o) => (o.id === orderId ? { ...o, status: 'CANCELLED', updatedAt: Date.now() } : o))
        );

        setRecentLedgerEntries(ledgerRef.current.getRecentEntries(30));
        syncMarketState();

        return { success: true, message: `Order ${orderId} cancelled. Funds unlocked to customer available balance.` };
      }

      return { success: false, message: 'Could not remove order from engine' };
    },
    [userOrders, markets, syncMarketState]
  );

  // Deposit Funds
  const depositFunds = useCallback(
    (asset: AssetSymbol, amount: number, network?: string) => {
      const info = ASSETS_REGISTRY[asset];
      const dep: DepositRequest = {
        id: `dep_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        asset,
        amount,
        network: network || info.network,
        address: asset === 'GBP' ? 'GB29MCX040004812345678' : `0xMCX${asset}VaultManchesterCold${Math.random().toString(36).substring(2, 6)}`,
        txHash: `0x${Math.random().toString(36).substring(2, 10)}${Math.random().toString(36).substring(2, 10)}`,
        confirmations: info.depositConfirmationBlocks,
        requiredConfirmations: info.depositConfirmationBlocks,
        status: 'CONFIRMED',
        timestamp: Date.now(),
      };

      setDeposits((prev) => [dep, ...prev]);

      setBalances((prev) =>
        prev.map((b) => {
          if (b.asset === asset) {
            const newAvail = b.available + amount;
            return {
              ...b,
              available: newAvail,
              total: newAvail + b.locked,
              gbpValue: (newAvail + b.locked) * b.gbpRate,
            };
          }
          return b;
        })
      );

      ledgerRef.current.recordEntry({
        debitAccount: `${info.isFiat ? 'BANK_OF_ENGLAND_FPS' : 'MANCHESTER_UNDERGROUND_VAULT'}_${asset}`,
        creditAccount: `CUSTOMER_AVAILABLE_${asset}`,
        asset,
        amount,
        referenceId: dep.id,
        type: 'DEPOSIT',
        description: `Deposit credited via ${dep.network} (Tx: ${dep.txHash.substring(0, 14)}...)`,
      });

      setRecentLedgerEntries(ledgerRef.current.getRecentEntries(30));
    },
    []
  );

  // Request Withdrawal
  const requestWithdrawal = useCallback(
    (asset: AssetSymbol, amount: number, destinationAddress: string) => {
      const balance = balances.find((b) => b.asset === asset);
      const assetInfo = ASSETS_REGISTRY[asset];

      if (!balance || balance.available < amount) {
        return { success: false, message: `Insufficient available ${asset} balance.` };
      }

      if (amount < assetInfo.minWithdrawal) {
        return { success: false, message: `Minimum withdrawal is ${assetInfo.minWithdrawal} ${asset}` };
      }

      const netAmount = amount - assetInfo.withdrawalFee;
      const wth: WithdrawalRequest = {
        id: `wth_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        asset,
        amount: netAmount,
        networkFee: assetInfo.withdrawalFee,
        destinationAddress,
        status: 'SETTLED',
        txHash: `0x${Math.random().toString(36).substring(2, 12)}`,
        timestamp: Date.now(),
      };

      setWithdrawals((prev) => [wth, ...prev]);

      setBalances((prev) =>
        prev.map((b) => {
          if (b.asset === asset) {
            const newAvail = b.available - amount;
            return {
              ...b,
              available: Math.max(0, newAvail),
              total: Math.max(0, newAvail) + b.locked,
              gbpValue: (Math.max(0, newAvail) + b.locked) * b.gbpRate,
            };
          }
          return b;
        })
      );

      ledgerRef.current.recordEntry({
        debitAccount: `CUSTOMER_AVAILABLE_${asset}`,
        creditAccount: `SETTLEMENT_DESTINATION_${destinationAddress.substring(0, 10)}`,
        asset,
        amount: netAmount,
        feeAsset: asset,
        feeAmount: assetInfo.withdrawalFee,
        referenceId: wth.id,
        type: 'WITHDRAWAL',
        description: `Withdrawal settled to ${destinationAddress.substring(0, 12)}...`,
      });

      setRecentLedgerEntries(ledgerRef.current.getRecentEntries(30));
      return { success: true, message: `Withdrawal of ${amount} ${asset} processed & broadcast to ${destinationAddress.substring(0, 12)}...` };
    },
    [balances]
  );

  // RFQ Desk
  const requestRfqQuote = useCallback((marketId: string, side: OrderSide, size: number): RFQQuote[] => {
    const market = markets.find((m) => m.id === marketId) || markets[0];
    const dealers = ['Castlefield Capital Partners', 'Deansgate Quantitative LP', 'Spinningfields Alpha Liquidity'];
    const quotes: RFQQuote[] = dealers.map((dealer, idx) => {
      const spreadBias = (idx - 1) * 0.0003;
      const price =
        side === 'BUY'
          ? market.askPrice * (1 + 0.0004 + spreadBias)
          : market.bidPrice * (1 - 0.0004 - spreadBias);

      return {
        id: `rfq_${Date.now()}_${idx}`,
        marketId,
        dealer,
        side,
        size,
        price: Math.round(price * 100) / 100,
        feeRate: 0.0004,
        slippageEstimated: 0.0,
        validUntil: Date.now() + 60000,
        status: 'ACTIVE',
      };
    });
    setRfqQuotes(quotes);
    return quotes;
  }, [markets]);

  const executeRfqQuote = useCallback((quoteId: string) => {
    const quote = rfqQuotes.find((q) => q.id === quoteId);
    if (!quote || quote.status !== 'ACTIVE' || quote.validUntil < Date.now()) {
      return { success: false, message: 'Quote is expired or invalid' };
    }

    quote.status = 'EXECUTED';
    setRfqQuotes([...rfqQuotes]);

    return submitUserOrder({
      marketId: quote.marketId,
      side: quote.side,
      type: 'LIMIT',
      price: quote.price,
      size: quote.size,
    });
  }, [rfqQuotes, submitUserOrder]);

  // Stress Testing Engine
  const runStressScenario = useCallback((scenario: 'FLASH_CRASH_BTC' | 'ETH_LIQUIDITY_SHOCK' | 'STABLECOIN_DEPEG' | 'STERLING_VOLATILITY') => {
    let result: StressScenarioResult;

    if (scenario === 'FLASH_CRASH_BTC') {
      result = {
        scenarioName: 'Bitcoin Flash Deleveraging (-35%)',
        description: 'Simulates cascading liquidations across global venues driving BTC to £47,083. MCX order book maintains 42% deeper book depth than London peer venues.',
        portfolioShockPercent: -22.4,
        portfolioLossGBP: Math.round(totalPortfolioGBP * 0.224),
        liquidityImpactScore: 'MODERATE - Automated Circuit Breakers Intact',
        var99GBP: Math.round(totalPortfolioGBP * 0.28),
        stressRecommendation: 'Maintain minimum 30% GBP/USDC cash buffer in Manchester Vault custody.',
      };
    } else if (scenario === 'ETH_LIQUIDITY_SHOCK') {
      result = {
        scenarioName: 'Ethereum Gas Spike & Gas Congestion Shock',
        description: 'Global gas fees surge to 280 Gwei; institutional bridge settlement stalls for 4 hours. MCX off-chain internal ledger processes trades at 0 latency.',
        portfolioShockPercent: -11.8,
        portfolioLossGBP: Math.round(totalPortfolioGBP * 0.118),
        liquidityImpactScore: 'CONTROLLED - Internal matching engine isolated from L1 congestion',
        var99GBP: Math.round(totalPortfolioGBP * 0.16),
        stressRecommendation: 'Route high-frequency rebalancing through internal MCX liquidity pool.',
      };
    } else if (scenario === 'STABLECOIN_DEPEG') {
      result = {
        scenarioName: 'Offshore Stablecoin Depeg Incident (0.91)',
        description: 'Non-regulated stablecoin falls 9% below parity. MCX Tier-1 GBP & Circle USDC pairing acts as flight-to-safety conduit, absorbing £850M net inflows.',
        portfolioShockPercent: -4.2,
        portfolioLossGBP: Math.round(totalPortfolioGBP * 0.042),
        liquidityImpactScore: 'BENEFICIAL - Inflow surge to regulated GBP pairs',
        var99GBP: Math.round(totalPortfolioGBP * 0.08),
        stressRecommendation: 'Preserve segregation of non-regulated stablecoins from core capital reserves.',
      };
    } else {
      result = {
        scenarioName: 'Sterling FX Volatility (+/- 6.5% vs USD)',
        description: 'Major UK fiscal event drives GBP/USD from 1.31 to 1.22. British digital asset valuations surge in local currency terms.',
        portfolioShockPercent: +5.8,
        portfolioLossGBP: 0,
        liquidityImpactScore: 'STABLE - Deepest sterling digital liquidity in Europe',
        var99GBP: Math.round(totalPortfolioGBP * 0.05),
        stressRecommendation: 'Utilize MCX BTC/GBP flagship contract to hedge domestic inflation risk.',
      };
    }

    setStressTestResult(result);
  }, [totalPortfolioGBP]);

  const clearStressScenario = useCallback(() => {
    setStressTestResult(null);
  }, []);

  const reconcileAudit = useCallback(() => {
    return ledgerRef.current.auditReconciliation();
  }, []);

  const toggleSimulation = useCallback(() => {
    setIsSimulating((prev) => !prev);
  }, []);

  // Background Deterministic Market Economy Simulation Runner
  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      // Pick a random market to add synthetic liquidity or micro-trade
      const targetMarket = markets[Math.floor(Math.random() * markets.length)];
      const engine = getOrCreateEngine(targetMarket.id, targetMarket.lastPrice);

      const isTrade = Math.random() > 0.45;
      const spread = engine.getSpread();
      const mid = spread.bid && spread.ask ? (spread.bid + spread.ask) / 2 : targetMarket.lastPrice;

      if (isTrade && spread.bid && spread.ask) {
        const side: OrderSide = Math.random() > 0.5 ? 'BUY' : 'SELL';
        const tradePrice = side === 'BUY' ? spread.ask : spread.bid;
        const tradeSize = Math.round((0.05 + Math.random() * 0.45) * 1000) / 1000;

        const matchResult = engine.submitOrder({
          id: `ord_synth_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
          marketId: targetMarket.id,
          side,
          type: 'MARKET',
          price: tradePrice,
          size: tradeSize,
          createdAt: Date.now(),
          userType: Math.random() > 0.6 ? 'INSTITUTIONAL' : 'ARBITRAGE',
        });

        if (matchResult.fills.length > 0) {
          const lastFill = matchResult.fills[matchResult.fills.length - 1];

          // Check if any user order was matched!
          const updatedUserOrders: Order[] = [];
          for (const uo of userOrders) {
            const updatedMaker = matchResult.makerOrdersUpdated.find((mo) => mo.id === uo.id);
            if (updatedMaker) {
              updatedUserOrders.push(updatedMaker);
            }
          }
          if (updatedUserOrders.length > 0) {
            setUserOrders((prev) =>
              prev.map((o) => {
                const u = updatedUserOrders.find((x) => x.id === o.id);
                return u || o;
              })
            );
          }

          setMarkets((prev) =>
            prev.map((m) => {
              if (m.id === targetMarket.id) {
                const delta = (lastFill.price - m.lastPrice) / m.lastPrice;
                return {
                  ...m,
                  lastPrice: lastFill.price,
                  change24h: Math.round((m.change24h + delta * 2) * 100) / 100,
                  volume24hQuote: m.volume24hQuote + lastFill.quoteVolume,
                  volume24hBase: m.volume24hBase + lastFill.size,
                };
              }
              return m;
            })
          );
        }
      } else {
        // Post quote around mid to keep order book deep and living
        const quoteSide: OrderSide = Math.random() > 0.5 ? 'BUY' : 'SELL';
        const offset = (Math.random() * 0.0012 + 0.0002) * mid;
        const quotePrice = Math.round((quoteSide === 'BUY' ? mid - offset : mid + offset) * 100) / 100;
        const quoteSize = Math.round((0.15 + Math.random() * 1.8) * 1000) / 1000;

        engine.submitOrder({
          id: `ord_synth_mm_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
          marketId: targetMarket.id,
          side: quoteSide,
          type: 'LIMIT',
          price: quotePrice,
          size: quoteSize,
          createdAt: Date.now(),
          userType: 'MARKET_MAKER',
        });
      }

      if (targetMarket.id === activeMarketId) {
        syncMarketState();
      }
    }, 2400);

    return () => clearInterval(interval);
  }, [isSimulating, markets, activeMarketId, syncMarketState, userOrders]);

  return (
    <ExchangeContext.Provider
      value={{
        markets,
        activeMarketId,
        activeMarket,
        setActiveMarketId,
        orderBook,
        recentTrades,
        candles,
        timeframe,
        setTimeframe,
        userOrders,
        userFills,
        balances,
        totalPortfolioGBP,
        totalPortfolioUSD,
        ledger: ledgerRef.current,
        recentLedgerEntries,
        deposits,
        withdrawals,
        rfqQuotes,
        surveillanceAlerts,
        engineHealth,
        isSimulating,
        toggleSimulation,
        submitUserOrder,
        cancelUserOrder,
        depositFunds,
        requestWithdrawal,
        requestRfqQuote,
        executeRfqQuote,
        stressTestResult,
        runStressScenario,
        clearStressScenario,
        reconcileAudit,
      }}
    >
      {children}
    </ExchangeContext.Provider>
  );
};

export const useExchange = () => {
  const context = useContext(ExchangeContext);
  if (!context) {
    throw new Error('useExchange must be used within an ExchangeProvider');
  }
  return context;
};
