import { Order, OrderBook, OrderBookLevel, TradeFill, OrderSide, OrderType } from '../types/exchange';

export interface MatchResult {
  fills: TradeFill[];
  executedOrder: Order;
  makerOrdersUpdated: Order[];
}

export class PriceTimeMatchingEngine {
  public marketId: string;
  private bids: Order[] = []; // sorted descending by price, then ascending by time
  private asks: Order[] = []; // sorted ascending by price, then ascending by time
  private sequence: number = 0;
  private tradeHistory: TradeFill[] = [];
  private eventLog: Array<{ type: string; payload: unknown; timestamp: number }> = [];

  constructor(marketId: string) {
    this.marketId = marketId;
  }

  public getOrderBook(depth: number = 15): OrderBook {
    const aggregateLevels = (orders: Order[], isBid: boolean): OrderBookLevel[] => {
      const priceMap = new Map<number, { size: number; count: number }>();
      for (const ord of orders) {
        if (ord.status === 'OPEN' || ord.status === 'PARTIALLY_FILLED') {
          const current = priceMap.get(ord.price) || { size: 0, count: 0 };
          current.size += ord.remainingSize;
          current.count += 1;
          priceMap.set(ord.price, current);
        }
      }

      const sortedPrices = Array.from(priceMap.keys()).sort((a, b) => (isBid ? b - a : a - b));
      let runningTotal = 0;
      const levels: OrderBookLevel[] = [];

      for (const price of sortedPrices.slice(0, depth)) {
        const item = priceMap.get(price)!;
        runningTotal += item.size;
        levels.push({
          price,
          size: Math.round(item.size * 10000) / 10000,
          total: Math.round(runningTotal * 10000) / 10000,
          ordersCount: item.count,
        });
      }
      return levels;
    };

    return {
      bids: aggregateLevels(this.bids, true),
      asks: aggregateLevels(this.asks, false),
      sequence: ++this.sequence,
      timestamp: Date.now(),
    };
  }

  public submitOrder(orderInput: Omit<Order, 'filledSize' | 'remainingSize' | 'feePaid' | 'status' | 'updatedAt'>): MatchResult {
    const order: Order = {
      ...orderInput,
      filledSize: 0,
      remainingSize: orderInput.size,
      feePaid: 0,
      status: 'OPEN',
      updatedAt: Date.now(),
    };

    this.eventLog.push({ type: 'ORDER_SUBMITTED', payload: { ...order }, timestamp: Date.now() });

    const fills: TradeFill[] = [];
    const makerOrdersUpdated: Order[] = [];

    if (order.side === 'BUY') {
      // Aggressive BUY matches against ASKS (lowest price first)
      let askIndex = 0;
      while (askIndex < this.asks.length && order.remainingSize > 0.00000001) {
        const makerAsk = this.asks[askIndex];
        const isMatchable = order.type === 'MARKET' || order.price >= makerAsk.price;

        if (!isMatchable) {
          break; // Since asks are sorted ascending, no further ask will match
        }

        const matchQty = Math.min(order.remainingSize, makerAsk.remainingSize);
        const matchPrice = makerAsk.price; // Price-Time Priority: maker sets the price

        // Calculate maker & taker fees
        const quoteVolume = matchQty * matchPrice;
        const makerFee = quoteVolume * 0.0008; // 0.08% maker rebate/fee
        const takerFee = quoteVolume * 0.0015; // 0.15% taker fee

        const fill: TradeFill = {
          id: `fill_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          marketId: this.marketId,
          makerOrderId: makerAsk.id,
          takerOrderId: order.id,
          price: matchPrice,
          size: matchQty,
          quoteVolume,
          makerFee,
          takerFee,
          timestamp: Date.now(),
          side: 'BUY',
        };

        fills.push(fill);
        this.tradeHistory.unshift(fill);
        if (this.tradeHistory.length > 100) this.tradeHistory.pop();

        // Update sizes
        order.filledSize += matchQty;
        order.remainingSize -= matchQty;
        order.feePaid += takerFee;

        makerAsk.filledSize += matchQty;
        makerAsk.remainingSize -= matchQty;
        makerAsk.feePaid += makerFee;
        makerAsk.updatedAt = Date.now();

        if (makerAsk.remainingSize <= 0.00000001) {
          makerAsk.status = 'FILLED';
          this.asks.splice(askIndex, 1);
        } else {
          makerAsk.status = 'PARTIALLY_FILLED';
          askIndex++;
        }

        makerOrdersUpdated.push({ ...makerAsk });
      }

      // If residual remains for BUY
      if (order.remainingSize > 0.00000001) {
        if (order.type === 'LIMIT') {
          order.status = order.filledSize > 0 ? 'PARTIALLY_FILLED' : 'OPEN';
          this.insertBid(order);
        } else {
          // Market order residual gets cancelled if no liquidity remains
          order.status = order.filledSize > 0 ? 'PARTIALLY_FILLED' : 'CANCELLED';
        }
      } else {
        order.status = 'FILLED';
      }
    } else {
      // Aggressive SELL matches against BIDS (highest price first)
      let bidIndex = 0;
      while (bidIndex < this.bids.length && order.remainingSize > 0.00000001) {
        const makerBid = this.bids[bidIndex];
        const isMatchable = order.type === 'MARKET' || order.price <= makerBid.price;

        if (!isMatchable) {
          break; // Since bids are sorted descending, no further bid will match
        }

        const matchQty = Math.min(order.remainingSize, makerBid.remainingSize);
        const matchPrice = makerBid.price;

        const quoteVolume = matchQty * matchPrice;
        const makerFee = quoteVolume * 0.0008;
        const takerFee = quoteVolume * 0.0015;

        const fill: TradeFill = {
          id: `fill_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          marketId: this.marketId,
          makerOrderId: makerBid.id,
          takerOrderId: order.id,
          price: matchPrice,
          size: matchQty,
          quoteVolume,
          makerFee,
          takerFee,
          timestamp: Date.now(),
          side: 'SELL',
        };

        fills.push(fill);
        this.tradeHistory.unshift(fill);
        if (this.tradeHistory.length > 100) this.tradeHistory.pop();

        order.filledSize += matchQty;
        order.remainingSize -= matchQty;
        order.feePaid += takerFee;

        makerBid.filledSize += matchQty;
        makerBid.remainingSize -= matchQty;
        makerBid.feePaid += makerFee;
        makerBid.updatedAt = Date.now();

        if (makerBid.remainingSize <= 0.00000001) {
          makerBid.status = 'FILLED';
          this.bids.splice(bidIndex, 1);
        } else {
          makerBid.status = 'PARTIALLY_FILLED';
          bidIndex++;
        }

        makerOrdersUpdated.push({ ...makerBid });
      }

      if (order.remainingSize > 0.00000001) {
        if (order.type === 'LIMIT') {
          order.status = order.filledSize > 0 ? 'PARTIALLY_FILLED' : 'OPEN';
          this.insertAsk(order);
        } else {
          order.status = order.filledSize > 0 ? 'PARTIALLY_FILLED' : 'CANCELLED';
        }
      } else {
        order.status = 'FILLED';
      }
    }

    return {
      fills,
      executedOrder: order,
      makerOrdersUpdated,
    };
  }

  public cancelOrder(orderId: string): Order | null {
    // Check bids
    const bidIdx = this.bids.findIndex((o) => o.id === orderId);
    if (bidIdx !== -1) {
      const cancelled = this.bids.splice(bidIdx, 1)[0];
      cancelled.status = 'CANCELLED';
      cancelled.updatedAt = Date.now();
      this.eventLog.push({ type: 'ORDER_CANCELLED', payload: { orderId }, timestamp: Date.now() });
      return cancelled;
    }

    // Check asks
    const askIdx = this.asks.findIndex((o) => o.id === orderId);
    if (askIdx !== -1) {
      const cancelled = this.asks.splice(askIdx, 1)[0];
      cancelled.status = 'CANCELLED';
      cancelled.updatedAt = Date.now();
      this.eventLog.push({ type: 'ORDER_CANCELLED', payload: { orderId }, timestamp: Date.now() });
      return cancelled;
    }

    return null;
  }

  public getRecentTrades(): TradeFill[] {
    return [...this.tradeHistory];
  }

  public seedBook(bids: Array<{ price: number; size: number }>, asks: Array<{ price: number; size: number }>) {
    this.bids = [];
    this.asks = [];
    const now = Date.now();

    bids.forEach((b, i) => {
      this.insertBid({
        id: `seed_bid_${i}_${Math.random().toString(36).substring(2, 6)}`,
        marketId: this.marketId,
        side: 'BUY',
        type: 'LIMIT',
        price: b.price,
        size: b.size,
        filledSize: 0,
        remainingSize: b.size,
        feePaid: 0,
        status: 'OPEN',
        createdAt: now - (bids.length - i) * 1000,
        updatedAt: now,
        userType: 'MARKET_MAKER',
      });
    });

    asks.forEach((a, i) => {
      this.insertAsk({
        id: `seed_ask_${i}_${Math.random().toString(36).substring(2, 6)}`,
        marketId: this.marketId,
        side: 'SELL',
        type: 'LIMIT',
        price: a.price,
        size: a.size,
        filledSize: 0,
        remainingSize: a.size,
        feePaid: 0,
        status: 'OPEN',
        createdAt: now - (asks.length - i) * 1000,
        updatedAt: now,
        userType: 'MARKET_MAKER',
      });
    });
  }

  private insertBid(order: Order) {
    // Price-Time priority: Bids sorted descending by price, then ascending by time
    let idx = 0;
    while (idx < this.bids.length) {
      if (order.price > this.bids[idx].price) {
        break;
      } else if (order.price === this.bids[idx].price) {
        if (order.createdAt < this.bids[idx].createdAt) {
          break;
        }
      }
      idx++;
    }
    this.bids.splice(idx, 0, order);
  }

  private insertAsk(order: Order) {
    // Price-Time priority: Asks sorted ascending by price, then ascending by time
    let idx = 0;
    while (idx < this.asks.length) {
      if (order.price < this.asks[idx].price) {
        break;
      } else if (order.price === this.asks[idx].price) {
        if (order.createdAt < this.asks[idx].createdAt) {
          break;
        }
      }
      idx++;
    }
    this.asks.splice(idx, 0, order);
  }

  public getSpread(): { bid: number; ask: number; spreadPercent: number } {
    const bestBid = this.bids.length > 0 ? this.bids[0].price : 0;
    const bestAsk = this.asks.length > 0 ? this.asks[0].price : 0;
    const spreadPercent = bestBid && bestAsk ? ((bestAsk - bestBid) / bestAsk) * 100 : 0;
    return {
      bid: bestBid,
      ask: bestAsk,
      spreadPercent: Math.round(spreadPercent * 1000) / 1000,
    };
  }
}
