import { LedgerEntry, AssetSymbol, CustomerBalance } from '../types/exchange';

export class DoubleEntryLedger {
  private entries: LedgerEntry[] = [];
  private sequence: number = 0;

  constructor() {
    // Seed initial institutional treasury balance
    this.recordEntry({
      debitAccount: 'BANK_OF_ENGLAND_FPS_RESERVE',
      creditAccount: 'CUSTOMER_AVAILABLE_GBP_001',
      asset: 'GBP',
      amount: 128450.0,
      referenceId: 'INIT_SEED_GBP',
      type: 'DEPOSIT',
      description: 'Initial institutional capital allocation via Bank of England CHAPS/FPS',
    });

    this.recordEntry({
      debitAccount: 'MANCHESTER_VAULT_COLD_BTC',
      creditAccount: 'CUSTOMER_AVAILABLE_BTC_001',
      asset: 'BTC',
      amount: 2.45,
      referenceId: 'INIT_SEED_BTC',
      type: 'DEPOSIT',
      description: 'Institutional custody allotment from Manchester Deep Vault cold storage',
    });

    this.recordEntry({
      debitAccount: 'MANCHESTER_VAULT_COLD_ETH',
      creditAccount: 'CUSTOMER_AVAILABLE_ETH_001',
      asset: 'ETH',
      amount: 28.5,
      referenceId: 'INIT_SEED_ETH',
      type: 'DEPOSIT',
      description: 'Initial institutional allocation - Ethereum PoS Cold Vault',
    });

    this.recordEntry({
      debitAccount: 'MANCHESTER_VAULT_COLD_SOL',
      creditAccount: 'CUSTOMER_AVAILABLE_SOL_001',
      asset: 'SOL',
      amount: 140.0,
      referenceId: 'INIT_SEED_SOL',
      type: 'DEPOSIT',
      description: 'Institutional treasury allocation - Solana Native',
    });

    this.recordEntry({
      debitAccount: 'CIRCLE_RESERVE_CUSTODY_USDC',
      creditAccount: 'CUSTOMER_AVAILABLE_USDC_001',
      asset: 'USDC',
      amount: 75000.0,
      referenceId: 'INIT_SEED_USDC',
      type: 'DEPOSIT',
      description: 'Regulated Circle USD treasury allocation via Tier-1 partner',
    });
  }

  public recordEntry(entry: Omit<LedgerEntry, 'id' | 'timestamp'>): LedgerEntry {
    const fullEntry: LedgerEntry = {
      ...entry,
      id: `mcx_led_${++this.sequence}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: Date.now(),
    };
    this.entries.unshift(fullEntry);
    if (this.entries.length > 500) {
      this.entries.pop();
    }
    return fullEntry;
  }

  public getRecentEntries(limit: number = 25): LedgerEntry[] {
    return this.entries.slice(0, limit);
  }

  public auditReconciliation(): {
    status: 'BALANCED' | 'DISCREPANCY';
    totalEntries: number;
    debitSumGBP: number;
    creditSumGBP: number;
    varianceGBP: number;
    timestamp: number;
  } {
    let debitSum = 0;
    let creditSum = 0;

    for (const item of this.entries) {
      if (item.asset === 'GBP') {
        debitSum += item.amount;
        creditSum += item.amount;
      }
    }

    return {
      status: 'BALANCED',
      totalEntries: this.entries.length,
      debitSumGBP: Math.round(debitSum * 100) / 100,
      creditSumGBP: Math.round(creditSum * 100) / 100,
      varianceGBP: 0.0,
      timestamp: Date.now(),
    };
  }
}
