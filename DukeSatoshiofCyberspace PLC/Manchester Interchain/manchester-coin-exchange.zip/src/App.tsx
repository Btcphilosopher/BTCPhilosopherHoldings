import React, { useState } from 'react';
import { ExchangeProvider, useExchange } from './store/exchangeStore';
import { Navbar } from './components/Navbar';
import { MarketTickerBar } from './components/MarketTickerBar';
import { LandingHero } from './components/LandingHero';
import { MarketTerminal } from './components/MarketTerminal';
import { MarketsTable } from './components/MarketsTable';
import { CustodyWallet } from './components/CustodyWallet';
import { InstitutionalRfq } from './components/InstitutionalRfq';
import { PortfolioRisk } from './components/PortfolioRisk';
import { ControlRoom } from './components/ControlRoom';
import { ApiConsole } from './components/ApiConsole';
import { AiConcierge } from './components/AiConcierge';
import { DepositModal } from './components/DepositModal';
import { Landmark, Shield, Award, Terminal } from 'lucide-react';

function ExchangeAppContent() {
  const [currentTab, setCurrentTab] = useState<string>('overview');
  const [isDepositOpen, setIsDepositOpen] = useState<boolean>(false);
  const { setActiveMarketId } = useExchange();

  const handleSelectMarket = (marketId: string) => {
    setActiveMarketId(marketId);
    setCurrentTab('terminal');
  };

  return (
    <div className="min-h-screen bg-[#0b0d10] text-[#eae6dd] flex flex-col font-sans selection:bg-[#842226] selection:text-white">
      {/* Real-time Order Flow Ticker Ribbon */}
      <MarketTickerBar />

      {/* Main Prestigious Navbar */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        onOpenDeposit={() => setIsDepositOpen(true)}
      />

      {/* Tab Screen Content */}
      <main className="flex-1">
        {currentTab === 'overview' && (
          <LandingHero
            onOpenTerminal={() => setCurrentTab('terminal')}
            onOpenMarkets={() => setCurrentTab('markets')}
            onOpenCustody={() => setCurrentTab('custody')}
          />
        )}

        {currentTab === 'terminal' && <MarketTerminal />}

        {currentTab === 'markets' && <MarketsTable onSelectMarket={handleSelectMarket} />}

        {currentTab === 'custody' && <CustodyWallet />}

        {currentTab === 'rfq' && <InstitutionalRfq />}

        {currentTab === 'portfolio' && <PortfolioRisk />}

        {currentTab === 'control' && <ControlRoom />}

        {currentTab === 'api' && <ApiConsole />}

        {currentTab === 'concierge' && <AiConcierge />}
      </main>

      {/* Quick Deposit Modal */}
      <DepositModal
        isOpen={isDepositOpen}
        onClose={() => setIsDepositOpen(false)}
      />

      {/* Prestigious Manchester Institutional Footer */}
      <footer className="bg-[#090b0e] border-t border-[#1a1f29] py-12 text-xs text-[#7d8697]">
        <div className="max-w-[1680px] mx-auto px-4 lg:px-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            {/* Column 1: Identity */}
            <div className="lg:col-span-2 space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-sm bg-[#842226] flex items-center justify-center text-white border border-[#9e2a2f]">
                  <Landmark className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-display font-black text-white text-base tracking-wider block">
                    MANCHESTER COIN EXCHANGE
                  </span>
                  <span className="font-serif-inst italic text-[11px] text-[#c59f5b]">
                    MCX &middot; Manchester, England
                  </span>
                </div>
              </div>
              <p className="text-xs text-[#8e95a5] max-w-md leading-relaxed">
                Combining Victorian commercial authority, fired Manchester red-brick permanence, and deterministic price-time-priority matching core technology. Founded in the cradle of the Industrial Revolution to anchor Britain’s modern digital economy.
              </p>
              <div className="text-[11px] font-mono text-[#d4c6b2]">
                DEANSGATE FINANCIAL QUARTER &middot; CITY OF MANCHESTER &middot; M3 4EE
              </div>
            </div>

            {/* Column 2: Markets */}
            <div className="space-y-2">
              <span className="font-display font-bold text-white text-xs uppercase tracking-wider block">
                Flagship Markets
              </span>
              <ul className="space-y-1.5 text-[11px]">
                <li><button onClick={() => { setActiveMarketId('BTC-GBP'); setCurrentTab('terminal'); }} className="hover:text-white cursor-pointer">BTC / GBP (British Sterling)</button></li>
                <li><button onClick={() => { setActiveMarketId('ETH-GBP'); setCurrentTab('terminal'); }} className="hover:text-white cursor-pointer">ETH / GBP (Ethereum Sterling)</button></li>
                <li><button onClick={() => { setActiveMarketId('SOL-GBP'); setCurrentTab('terminal'); }} className="hover:text-white cursor-pointer">SOL / GBP (Solana Sterling)</button></li>
                <li><button onClick={() => { setActiveMarketId('BTC-USD'); setCurrentTab('terminal'); }} className="hover:text-white cursor-pointer">BTC / USD (Circle USDC)</button></li>
                <li><button onClick={() => { setActiveMarketId('USDC-USD'); setCurrentTab('terminal'); }} className="hover:text-white cursor-pointer">USDC / GBP (Digital FX)</button></li>
              </ul>
            </div>

            {/* Column 3: Institutional Services */}
            <div className="space-y-2">
              <span className="font-display font-bold text-white text-xs uppercase tracking-wider block">
                Institutional Infrastructure
              </span>
              <ul className="space-y-1.5 text-[11px]">
                <li><button onClick={() => setCurrentTab('custody')} className="hover:text-white cursor-pointer">Manchester Deep Vault Custody</button></li>
                <li><button onClick={() => setCurrentTab('rfq')} className="hover:text-white cursor-pointer">Syndicate RFQ Desk</button></li>
                <li><button onClick={() => setCurrentTab('portfolio')} className="hover:text-white cursor-pointer">Quantitative VaR &amp; Stress Lab</button></li>
                <li><button onClick={() => setCurrentTab('control')} className="hover:text-white cursor-pointer">Market Surveillance Anomaly Engine</button></li>
                <li><button onClick={() => setCurrentTab('api')} className="hover:text-white cursor-pointer">REST, FIX &amp; WebSocket APIs</button></li>
              </ul>
            </div>

            {/* Column 4: Architectural Heritage */}
            <div className="space-y-2">
              <span className="font-display font-bold text-white text-xs uppercase tracking-wider block">
                Heritage &amp; Governance
              </span>
              <p className="text-[11px] text-[#8e95a5] leading-relaxed">
                MCX draws upon the historic tradition of the Royal Exchange, the Free Trade Hall, and Northern railway engineering. Our cryptographic ledgers maintain 100% full-reserve solvency reconciled in real time.
              </p>
              <div className="pt-2 text-emerald-400 font-mono text-[10px] font-semibold">
                FULL-RESERVE CUSTODY &middot; ZERO COMMINGLING
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-[#181d27] flex flex-wrap items-center justify-between gap-4 text-[11px]">
            <div>
              &copy; {new Date().getFullYear()} Manchester Coin Exchange Ltd (MCX). Registered in England &amp; Wales. All rights reserved.
            </div>
            <div className="flex items-center space-x-4 font-serif-inst italic text-[#c59f5b]">
              <span>Digital Assets, Exchanged With Precision</span>
              <span>&bull;</span>
              <span>Manchester Builds What’s Next</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ExchangeProvider>
      <ExchangeAppContent />
    </ExchangeProvider>
  );
}
