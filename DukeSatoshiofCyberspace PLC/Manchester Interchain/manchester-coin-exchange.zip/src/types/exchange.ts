export type AssetSymbol = 'BTC' | 'ETH' | 'SOL' | 'XRP' | 'USDC' | 'USDT' | 'GBP' | 'EUR';

export interface AssetInfo {
  symbol: AssetSymbol;
  name: string;
  decimals: number;
  isFiat: boolean;
  network: string;
  depositConfirmationBlocks: number;
  withdrawalFee: number;
  minWithdrawal: number;
  contractAddress?: string;
  custodyColdRatio: number; // e.g. 0.92 = 92% in Manchester Deep Vault
  description: string;
}

export interface MarketPair {
  id: string; // e.g. 'BTC-GBP'
  baseAsset: AssetSymbol;
  quoteAsset: AssetSymbol;
  displayName: string;
  priceDecimals: number;
  sizeDecimals: number;
  minOrderSize: number;
  makerFeeRate: number; // 0.0008 (0.08%)
  takerFeeRate: number; // 0.0015 (0.15%)
  lastPrice: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24hQuote: number;
  volume24hBase: number;
  bidPrice: number;
  askPrice: number;
  spread: number;
  status: 'ACTIVE' | 'HALTED' | 'AUCTION';
}

export type OrderType = 'LIMIT' | 'MARKET' | 'STOP_LIMIT';
export type OrderSide = 'BUY' | 'SELL';
export type OrderStatus = 'NEW' | 'OPEN' | 'PARTIALLY_FILLED' | 'FILLED' | 'CANCELLED' | 'REJECTED';

export interface Order {
  id: string;
  marketId: string;
  clientOrderId?: string;
  side: OrderSide;
  type: OrderType;
  price: number; // 0 for market order
  size: number;
  filledSize: number;
  remainingSize: number;
  feePaid: number;
  status: OrderStatus;
  createdAt: number;
  updatedAt: number;
  userType: 'CUSTOMER' | 'INSTITUTIONAL' | 'MARKET_MAKER' | 'ARBITRAGE';
}

export interface TradeFill {
  id: string;
  marketId: string;
  makerOrderId: string;
  takerOrderId: string;
  price: number;
  size: number;
  quoteVolume: number;
  makerFee: number;
  takerFee: number;
  timestamp: number;
  side: OrderSide; // side of the taker
}

export interface OrderBookLevel {
  price: number;
  size: number;
  total: number;
  ordersCount: number;
}

export interface OrderBook {
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  sequence: number;
  timestamp: number;
}

export interface Candle {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface CustomerBalance {
  asset: AssetSymbol;
  available: number;
  locked: number;
  total: number;
  gbpRate: number;
  gbpValue: number;
}

export interface LedgerEntry {
  id: string;
  timestamp: number;
  debitAccount: string;
  creditAccount: string;
  asset: AssetSymbol;
  amount: number;
  feeAsset?: AssetSymbol;
  feeAmount?: number;
  referenceId: string;
  type: 'TRADE_SETTLEMENT' | 'DEPOSIT' | 'WITHDRAWAL' | 'FEE_ACCRUAL' | 'INTERNAL_REBALANCE';
  description: string;
}

export interface DepositRequest {
  id: string;
  asset: AssetSymbol;
  amount: number;
  network: string;
  address: string;
  txHash: string;
  confirmations: number;
  requiredConfirmations: number;
  status: 'PENDING' | 'CONFIRMED' | 'CREDITED';
  timestamp: number;
}

export interface WithdrawalRequest {
  id: string;
  asset: AssetSymbol;
  amount: number;
  networkFee: number;
  destinationAddress: string;
  status: 'SCREENING' | 'SIGNING' | 'BROADCAST' | 'SETTLED';
  txHash?: string;
  timestamp: number;
}

export interface RFQQuote {
  id: string;
  marketId: string;
  dealer: string;
  side: OrderSide;
  size: number;
  price: number;
  feeRate: number;
  slippageEstimated: number;
  validUntil: number; // Unix timestamp
  status: 'ACTIVE' | 'EXPIRED' | 'EXECUTED';
}

export interface StressScenarioResult {
  scenarioName: string;
  description: string;
  portfolioShockPercent: number;
  portfolioLossGBP: number;
  liquidityImpactScore: string;
  var99GBP: number;
  stressRecommendation: string;
}

export interface SurveillanceAlert {
  id: string;
  timestamp: number;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  type: 'SPOOFING_PATTERN' | 'WASH_TRADE_SUSPICION' | 'RAPID_CANCELLATION' | 'PRICE_DISLOCATION';
  marketId: string;
  details: string;
  status: 'INVESTIGATING' | 'DISMISSED' | 'REPORTED';
}

export interface EngineHealth {
  status: 'OPTIMAL' | 'DEGRADED' | 'MAINTENANCE';
  latencyMicros: number;
  matchingThroughputTPS: number;
  totalOrdersProcessed: number;
  activeSockets: number;
  unreconciledDiscrepancies: number;
  vaultIntegrity: '100% SECURED - COLD CUSTODY OK';
  mempoolSync: 'SYNCHRONIZED';
}
