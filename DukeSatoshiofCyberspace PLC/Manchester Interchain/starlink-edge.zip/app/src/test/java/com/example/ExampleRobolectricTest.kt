package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.starlinkedge.api.StarlinkEdgeCli
import com.example.starlinkedge.model.ComputeJob
import com.example.starlinkedge.model.ResourceRequirements
import com.example.starlinkedge.model.RuntimeConfig
import com.example.starlinkedge.model.WorkloadType
import com.example.starlinkedge.simulation.SimulationEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Starlink-Edge", appName)
  }

  @Test
  fun `verify simulation engine initializes 100 nodes`() {
    val simulationEngine = SimulationEngine()
    val nodes = simulationEngine.nodes.value
    assertEquals(100, nodes.size)
  }

  @Test
  fun `verify CLI executes nodes list command`() {
    val simulationEngine = SimulationEngine()
    val cli = StarlinkEdgeCli(simulationEngine)
    val output = cli.executeCommand("starlink-edge nodes list")
    assertTrue(output.contains("SE-EDGE"))
  }

  @Test
  fun `verify job scheduler matches resource requirements`() {
    val simulationEngine = SimulationEngine()
    val job = ComputeJob(
      id = "test_job_1",
      title = "H100 LLM Inference Test",
      ownerId = "unit_test",
      type = WorkloadType.AI_INFERENCE,
      requirements = ResourceRequirements(cpuCores = 16, ramGb = 32, gpuCount = 1, vramGb = 24),
      runtime = RuntimeConfig("ollama/ollama:latest"),
      submittedAtMs = System.currentTimeMillis()
    )
    val decision = simulationEngine.submitJob(job)
    assertTrue(decision.selectedNodeId != null)
  }
}
