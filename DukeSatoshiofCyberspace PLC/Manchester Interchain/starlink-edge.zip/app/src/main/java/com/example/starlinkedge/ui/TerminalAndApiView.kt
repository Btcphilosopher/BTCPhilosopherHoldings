package com.example.starlinkedge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.starlinkedge.api.OpenApiSpecProvider
import com.example.starlinkedge.api.StarlinkEdgeCli
import com.example.ui.theme.*

@Composable
fun TerminalAndApiView(cli: StarlinkEdgeCli) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = CLI Terminal, 1 = OpenAPI Spec
    var commandInput by remember { mutableStateOf("starlink-edge nodes list") }
    var consoleOutput by remember {
        mutableStateOf(
            """
========================================================================
             STARLINK-EDGE CLI v2.4-PROD (ORBITAL COMPUTE)
========================================================================
Connected to Starlink-Edge local infrastructure simulation API daemon.
Type 'starlink-edge --help' or tap quick action chips below.
========================================================================
            """.trimIndent()
        )
    }

    val terminalScrollState = rememberScrollState()

    fun runCommand(cmd: String) {
        val output = cli.executeCommand(cmd)
        consoleOutput = "$consoleOutput\n\n$ > $cmd\n$output"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavyBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Tab Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TabButton(
                label = "OPERATIONS TERMINAL (CLI)",
                icon = Icons.Default.Terminal,
                isSelected = selectedTab == 0
            ) { selectedTab = 0 }

            TabButton(
                label = "OPENAPI V3 SPECIFICATION",
                icon = Icons.Default.Code,
                isSelected = selectedTab == 1
            ) { selectedTab = 1 }
        }

        if (selectedTab == 0) {
            // CLI Quick Action Chips
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                QuickCommandChip("nodes list") { runCommand("starlink-edge nodes list") }
                QuickCommandChip("miners list") { runCommand("starlink-edge miners list") }
                QuickCommandChip("mining stats") { runCommand("starlink-edge mining stats") }
                QuickCommandChip("jobs list") { runCommand("starlink-edge jobs list") }
                QuickCommandChip("health") { runCommand("starlink-edge health") }
            }

            // Command Input Box
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = commandInput,
                    onValueChange = { commandInput = it },
                    placeholder = { Text("starlink-edge <subcommand>", color = TextMuted, fontSize = 12.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CardSurface,
                        unfocusedContainerColor = CardSurface,
                        focusedBorderColor = TacticalBlue,
                        unfocusedBorderColor = SteelBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("cli_command_input")
                )

                IconButton(
                    onClick = {
                        if (commandInput.isNotBlank()) {
                            runCommand(commandInput)
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(TacticalBlue, RoundedCornerShape(8.dp))
                        .testTag("run_command_button")
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Run", tint = DeepNavyBg)
                }
            }

            // Terminal Console Screen
            Surface(
                color = DarkSurface,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, SteelBorder, RoundedCornerShape(8.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                        .verticalScroll(terminalScrollState)
                ) {
                    Text(
                        text = consoleOutput,
                        color = EmeraldOnline,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 16.sp
                    )
                }
            }
        } else {
            // OpenAPI Spec View
            Surface(
                color = DarkSurface,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .border(1.dp, SteelBorder, RoundedCornerShape(8.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = OpenApiSpecProvider.getOpenApiYamlSpec(),
                        color = TacticalBlue,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
fun TabButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (isSelected) TacticalBlue else CardSurface,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .border(1.dp, if (isSelected) TacticalBlue else SteelBorder, RoundedCornerShape(8.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = if (isSelected) DeepNavyBg else TextPrimary, modifier = Modifier.size(16.dp))
            Text(
                text = label,
                color = if (isSelected) DeepNavyBg else TextPrimary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun QuickCommandChip(command: String, onClick: () -> Unit) {
    Surface(
        color = CardSurface,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .border(1.dp, SteelBorder, RoundedCornerShape(12.dp))
            .clickable { onClick() }
    ) {
        Text(
            text = command,
            color = TextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
