package com.example.starlinkedge.simulation

import com.example.starlinkedge.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class SimulationEngine(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) {
    private val _nodes = MutableStateFlow<List<ComputeNode>>(emptyList())
    val nodes: StateFlow<List<ComputeNode>> = _nodes.asStateFlow()

    private val _workers = MutableStateFlow<List<MiningWorker>>(emptyList())
    val workers: StateFlow<List<MiningWorker>> = _workers.asStateFlow()

    private val _jobs = MutableStateFlow<List<ComputeJob>>(emptyList())
    val jobs: StateFlow<List<ComputeJob>> = _jobs.asStateFlow()

    private val _pools = MutableStateFlow<List<MiningPool>>(emptyList())
    val pools: StateFlow<List<MiningPool>> = _pools.asStateFlow()

    private val _decisions = MutableStateFlow<List<SchedulerDecision>>(emptyList())
    val decisions: StateFlow<List<SchedulerDecision>> = _decisions.asStateFlow()

    private val _isSimulating = MutableStateFlow(false)
    val isSimulating: StateFlow<Boolean> = _isSimulating.asStateFlow()

    private var tickerJob: Job? = null

    private val satelliteSites = listOf(
        GeoLocation("United Kingdom", "Shetland Islands", 60.35, -1.23, "GS-UK-NORTH-01"),
        GeoLocation("Norway", "Nordland Plateau", 67.28, 14.40, "GS-NO-ARCTIC-02"),
        GeoLocation("Chile", "Atacama Desert", -23.86, -69.13, "GS-CL-ANDES-03"),
        GeoLocation("Australia", "Outback Station", -25.27, 133.77, "GS-AU-CENTRAL-04"),
        GeoLocation("Canada", "Yukon Territory", 64.06, -139.43, "GS-CA-YUKON-05"),
        GeoLocation("South Africa", "Karoo Basin", -31.25, 21.08, "GS-ZA-KAROO-06"),
        GeoLocation("Iceland", "Highland Outpost", 64.14, -19.04, "GS-IS-VOLCANIC-07"),
        GeoLocation("United States", "Mojave Desert", 35.01, -115.47, "GS-US-WEST-08"),
        GeoLocation("Argentina", "Patagonia Station", -46.54, -68.92, "GS-AR-PATAGONIA-09"),
        GeoLocation("United Kingdom", "Scottish Highlands", 57.32, -4.42, "GS-UK-HIGHLANDS-10"),
        GeoLocation("Japan", "Hokkaido Northern Peak", 43.80, 142.85, "GS-JP-NORTH-11"),
        GeoLocation("New Zealand", "Southern Alps", -43.53, 170.14, "GS-NZ-ALPS-12"),
        GeoLocation("Finland", "Lapland Wilderness", 67.92, 26.50, "GS-FI-LAPLAND-13"),
        GeoLocation("Spain", "Sierra Nevada", 37.05, -3.31, "GS-ES-SOUTH-14"),
        GeoLocation("Greenland", "Nuuk Gateway", 64.18, -51.72, "GS-GL-NUUK-15"),
        GeoLocation("Kazakhstan", "Steppe Hub", 48.01, 66.90, "GS-KZ-STEPPE-16"),
        GeoLocation("United States", "Alaska North Slope", 69.95, -152.01, "GS-US-ALASKA-17"),
        GeoLocation("Brazil", "Cerrado Highlands", -14.23, -51.92, "GS-BR-CERRADO-18"),
        GeoLocation("Oman", "Empty Quarter Edge", 21.51, 55.92, "GS-OM-DESERT-19"),
        GeoLocation("Sweden", "Kiruna Arctic Site", 67.85, 20.22, "GS-SE-ARCTIC-20")
    )

    init {
        initializeInitialState()
        startSimulation()
    }

    private fun initializeInitialState() {
        val createdPools = listOf(
            MiningPool("pool_01", "ORBITAL-STRATUM-NORTH", "stratum+tcp://btc-north.starlink-edge.net:3333", 0.5, 14, 320.5, 8192.0),
            MiningPool("pool_02", "ORBITAL-STRATUM-SOUTH", "stratum+tcp://btc-south.starlink-edge.net:3333", 0.5, 11, 245.8, 8192.0)
        )
        _pools.value = createdPools

        val createdNodes = mutableListOf<ComputeNode>()
        val createdWorkers = mutableListOf<MiningWorker>()

        for (i in 1..100) {
            val site = satelliteSites[(i - 1) % satelliteSites.size]
            val nodeId = "node_${i.toString().padStart(3, '0')}"
            val hostname = "SE-EDGE-${site.region.take(3).uppercase()}-${i.toString().padStart(3, '0')}"

            val hasGpu = (i % 2 == 0) // 50 GPUs
            val hasAsic = (i % 4 == 0) // 25 ASICs

            val cpu = CpuHardware(
                id = "cpu_$nodeId",
                model = if (i % 2 == 0) "AMD EPYC 9654 96-Core" else "Intel Xeon Platinum 8480+",
                cores = if (i % 2 == 0) 96 else 56,
                threads = if (i % 2 == 0) 192 else 112,
                architecture = "x86_64",
                frequencyGHz = 3.2,
                utilizationPercent = Random.nextDouble(15.0, 45.0),
                temperatureC = Random.nextDouble(42.0, 58.0),
                powerWatts = Random.nextDouble(180.0, 320.0)
            )

            val gpu = if (hasGpu) {
                GpuHardware(
                    id = "gpu_$nodeId",
                    model = if (i % 3 == 0) "NVIDIA H100 SXM5 80GB" else "NVIDIA RTX 4090 24GB",
                    vramGb = if (i % 3 == 0) 80 else 24,
                    computeCapability = "9.0",
                    utilizationPercent = Random.nextDouble(30.0, 85.0),
                    temperatureC = Random.nextDouble(55.0, 72.0),
                    powerWatts = Random.nextDouble(250.0, 450.0),
                    memoryBandwidthGBs = 3350.0
                )
            } else null

            val asic = if (hasAsic) {
                val model = if (i % 8 == 0) "Antminer S21 Hydro" else "Antminer S19 Pro"
                val nominalTH = if (i % 8 == 0) 335.0 else 110.0
                val powerW = if (i % 8 == 0) 5360.0 else 3250.0
                AsicHardware(
                    id = "asic_$nodeId",
                    manufacturer = "Bitmain",
                    model = model,
                    nominalHashrateTHs = nominalTH,
                    currentHashrateTHs = nominalTH * Random.nextDouble(0.97, 1.02),
                    powerDrawWatts = powerW,
                    temperatureC = Random.nextDouble(62.0, 74.0),
                    fanSpeedRpm = Random.nextInt(4200, 5800),
                    acceptedShares = Random.nextLong(12000, 85000),
                    rejectedShares = Random.nextLong(10, 120),
                    hardwareErrors = Random.nextLong(0, 15)
                )
            } else null

            if (asic != null) {
                val pool = createdPools[i % createdPools.size]
                createdWorkers.add(
                    MiningWorker(
                        id = "miner_${nodeId.removePrefix("node_")}",
                        nodeId = nodeId,
                        hardwareId = asic.id,
                        hashrate = Hashrate(asic.currentHashrateTHs, "TH/s"),
                        powerWatts = asic.powerDrawWatts,
                        temperatureC = asic.temperatureC,
                        status = WorkerStatus.RUNNING,
                        acceptedShares = asic.acceptedShares,
                        rejectedShares = asic.rejectedShares,
                        hardwareErrors = asic.hardwareErrors,
                        poolName = pool.name
                    )
                )
            }

            val storage = StorageHardware(
                id = "storage_$nodeId",
                capacityTB = 16.0,
                usedTB = Random.nextDouble(2.0, 8.5),
                readIOPS = 45000,
                writeIOPS = 38000,
                readBandwidthMBs = 3500.0,
                writeBandwidthMBs = 2800.0,
                healthPercent = Random.nextInt(94, 100)
            )

            val baseLatency = Random.nextDouble(32.0, 68.0)
            val netInterface = NetworkInterface(
                interfaceName = "sat0",
                downlinkMbps = Random.nextDouble(180.0, 240.0),
                uplinkMbps = Random.nextDouble(25.0, 45.0),
                latencyMs = baseLatency,
                packetLossPercent = Random.nextDouble(0.01, 0.4),
                jitterMs = Random.nextDouble(2.0, 8.0)
            )

            val caps = mutableSetOf(Capability.CPU, Capability.STORAGE, Capability.CONTAINER, Capability.BATCH)
            if (gpu != null) {
                caps.add(Capability.GPU)
                caps.add(Capability.AI_INFERENCE)
                caps.add(Capability.RENDERING)
            }
            if (asic != null) {
                caps.add(Capability.ASIC)
                caps.add(Capability.BITCOIN_MINING)
            }

            val totalPower = cpu.powerWatts + (gpu?.powerWatts ?: 0.0) + (asic?.powerDrawWatts ?: 0.0) + 45.0
            val thermalStatus = when {
                (asic?.temperatureC ?: cpu.temperatureC) > 82.0 -> ThermalStatus.THERMAL_WARNING
                else -> ThermalStatus.THERMAL_NORMAL
            }

            val initialWorkloads = mutableListOf<Workload>()
            if (hasGpu) {
                initialWorkloads.add(
                    Workload(
                        id = "wl_inf_${nodeId}",
                        name = "Llama3-8B-Inference-Job",
                        type = WorkloadType.AI_INFERENCE,
                        cpuAllocatedCores = 16,
                        ramAllocatedGb = 32,
                        gpuAllocatedGb = 24,
                        powerDrawWatts = 220.0,
                        startTimeMs = System.currentTimeMillis() - 3600000
                    )
                )
            }

            val computeNode = ComputeNode(
                id = nodeId,
                hostname = hostname,
                status = if (i % 25 == 0) NodeStatus.DEGRADED else NodeStatus.ONLINE,
                location = site,
                hardware = HardwareInventory(cpu, gpu, asic, storage, netInterface),
                power = PowerState(
                    inputWatts = totalPower * 1.05,
                    computeWatts = totalPower,
                    networkWatts = 25.0,
                    coolingWatts = 20.0,
                    totalWatts = totalPower + 45.0,
                    powerCapWatts = 6500.0,
                    mode = PowerMode.POWER_NORMAL
                ),
                thermal = ThermalState(
                    cpuTempC = cpu.temperatureC,
                    gpuTempC = gpu?.temperatureC,
                    asicTempC = asic?.temperatureC,
                    ambientTempC = Random.nextDouble(12.0, 24.0),
                    fanSpeedRpm = if (asic != null) asic.fanSpeedRpm else Random.nextInt(2100, 3400),
                    coolingPowerWatts = 35.0,
                    thermalHeadroomC = 90.0 - max(cpu.temperatureC, asic?.temperatureC ?: 0.0),
                    status = thermalStatus
                ),
                network = NetworkState(
                    telemetry = NetworkTelemetry(
                        timestampMs = System.currentTimeMillis(),
                        downlinkMbps = netInterface.downlinkMbps,
                        uplinkMbps = netInterface.uplinkMbps,
                        latencyMs = netInterface.latencyMs,
                        jitterMs = netInterface.jitterMs,
                        packetLossPercent = netInterface.packetLossPercent,
                        connectionState = ConnectionState.CONNECTED,
                        providerType = ProviderType.SATELLITE_ORBITAL
                    ),
                    ipAddress = "10.201.${(i / 25) + 1}.${i % 25 + 1}",
                    groundStationId = site.groundStation
                ),
                workloads = initialWorkloads,
                capabilities = caps,
                uptimeSeconds = Random.nextLong(14400, 1800000)
            )

            createdNodes.add(computeNode)
        }

        _nodes.value = createdNodes
        _workers.value = createdWorkers

        // Initial sample jobs
        val sampleJobs = listOf(
            ComputeJob(
                id = "job_001",
                title = "GROMACS Molecular Dynamics Simulation",
                ownerId = "owner_oxford_lab",
                type = WorkloadType.SCIENTIFIC,
                requirements = ResourceRequirements(cpuCores = 32, ramGb = 64, gpuCount = 1, vramGb = 24),
                runtime = RuntimeConfig("biocontainers/gromacs:latest", listOf("gmx", "mdrun", "-s", "protein.tpr")),
                priority = 2,
                assignedNodeId = "node_002",
                status = JobStatus.RUNNING,
                submittedAtMs = System.currentTimeMillis() - 1800000,
                startedAtMs = System.currentTimeMillis() - 1750000,
                progressPercent = 42.5
            ),
            ComputeJob(
                id = "job_002",
                title = "4K Aerospace CFD Render Batch",
                ownerId = "owner_aerospace_corp",
                type = WorkloadType.RENDER,
                requirements = ResourceRequirements(cpuCores = 64, ramGb = 128, gpuCount = 2, vramGb = 48),
                runtime = RuntimeConfig("blender/blender:latest", listOf("blender", "-b", "wing.blend", "-f", "1..100")),
                priority = 3,
                assignedNodeId = "node_004",
                status = JobStatus.RUNNING,
                submittedAtMs = System.currentTimeMillis() - 900000,
                startedAtMs = System.currentTimeMillis() - 850000,
                progressPercent = 78.0
            ),
            ComputeJob(
                id = "job_003",
                title = "Financial Monte Carlo Risk Engine",
                ownerId = "owner_hedge_fund",
                type = WorkloadType.BATCH,
                requirements = ResourceRequirements(cpuCores = 48, ramGb = 64),
                runtime = RuntimeConfig("python:3.11-slim", listOf("python", "simulate_risk.py")),
                priority = 1,
                status = JobStatus.QUEUED,
                submittedAtMs = System.currentTimeMillis() - 120000
            )
        )
        _jobs.value = sampleJobs
    }

    fun startSimulation() {
        if (_isSimulating.value) return
        _isSimulating.value = true

        tickerJob = scope.launch {
            while (_isSimulating.value) {
                delay(1000)
                tickPhysicsAndTelemetry()
            }
        }
    }

    fun stopSimulation() {
        _isSimulating.value = false
        tickerJob?.cancel()
        tickerJob = null
    }

    private fun tickPhysicsAndTelemetry() {
        val currentNodes = _nodes.value.toMutableList()
        val currentWorkers = _workers.value.toMutableList()
        val currentJobs = _jobs.value.toMutableList()

        for (i in currentNodes.indices) {
            val node = currentNodes[i]
            val hasAsic = node.hardware.asic != null
            val hasGpu = node.hardware.gpu != null

            // Workload power calculation
            val activeWorkloadsCount = node.workloads.size
            val cpuLoad = min(98.0, max(10.0, 20.0 + activeWorkloadsCount * 25.0 + Random.nextDouble(-3.0, 3.0)))

            val updatedCpu = node.hardware.cpu.copy(
                utilizationPercent = cpuLoad,
                temperatureC = min(92.0, max(38.0, 42.0 + (cpuLoad * 0.35) + Random.nextDouble(-0.5, 0.5))),
                powerWatts = 120.0 + (cpuLoad * 2.2)
            )

            val updatedGpu = node.hardware.gpu?.let { gpu ->
                val gpuLoad = if (activeWorkloadsCount > 0) Random.nextDouble(65.0, 95.0) else Random.nextDouble(5.0, 20.0)
                gpu.copy(
                    utilizationPercent = gpuLoad,
                    temperatureC = min(88.0, max(40.0, 45.0 + (gpuLoad * 0.32) + Random.nextDouble(-0.8, 0.8))),
                    powerWatts = 50.0 + (gpuLoad * 3.8)
                )
            }

            var updatedAsic = node.hardware.asic
            if (updatedAsic != null) {
                val netLatency = node.network.telemetry.latencyMs
                val isHighLatency = netLatency > 120.0
                val staleFactor = if (isHighLatency) 0.08 else 0.002

                val newAccepted = updatedAsic.acceptedShares + Random.nextInt(1, 4)
                val newRejected = updatedAsic.rejectedShares + if (Random.nextDouble() < staleFactor) 1 else 0

                val currentTemp = min(92.0, max(55.0, updatedAsic.temperatureC + Random.nextDouble(-0.3, 0.3)))
                val currentHash = updatedAsic.nominalHashrateTHs * (if (currentTemp > 82.0) 0.82 else 1.0) * Random.nextDouble(0.98, 1.01)

                updatedAsic = updatedAsic.copy(
                    currentHashrateTHs = currentHash,
                    temperatureC = currentTemp,
                    acceptedShares = newAccepted,
                    rejectedShares = newRejected
                )

                // update worker state
                val wIndex = currentWorkers.indexOfFirst { it.nodeId == node.id }
                if (wIndex != -1) {
                    val w = currentWorkers[wIndex]
                    currentWorkers[wIndex] = w.copy(
                        hashrate = Hashrate(currentHash, "TH/s"),
                        temperatureC = currentTemp,
                        acceptedShares = newAccepted,
                        rejectedShares = newRejected,
                        status = if (currentTemp > 82.0) WorkerStatus.THROTTLED else WorkerStatus.RUNNING
                    )
                }
            }

            // Power computation
            val computeWatts = updatedCpu.powerWatts + (updatedGpu?.powerWatts ?: 0.0) + (updatedAsic?.powerDrawWatts ?: 0.0)
            val coolingWatts = 20.0 + (max(updatedCpu.temperatureC, updatedAsic?.temperatureC ?: 0.0) * 0.4)
            val totalWatts = computeWatts + 25.0 + coolingWatts

            val highestTemp = max(updatedCpu.temperatureC, max(updatedGpu?.temperatureC ?: 0.0, updatedAsic?.temperatureC ?: 0.0))
            val thermalStatus = when {
                highestTemp >= 86.0 -> ThermalStatus.THERMAL_CRITICAL
                highestTemp >= 78.0 -> ThermalStatus.THERMAL_WARNING
                else -> ThermalStatus.THERMAL_NORMAL
            }

            val nodeStatus = when {
                highestTemp >= 86.0 -> NodeStatus.OVERHEATED
                node.network.telemetry.connectionState == ConnectionState.DEGRADED -> NodeStatus.NETWORK_DEGRADED
                else -> NodeStatus.ONLINE
            }

            val updatedNetTelemetry = node.network.telemetry.copy(
                timestampMs = System.currentTimeMillis(),
                latencyMs = max(18.0, node.network.telemetry.latencyMs + Random.nextDouble(-2.0, 2.0)),
                jitterMs = max(1.0, node.network.telemetry.jitterMs + Random.nextDouble(-0.5, 0.5))
            )

            currentNodes[i] = node.copy(
                status = nodeStatus,
                hardware = node.hardware.copy(
                    cpu = updatedCpu,
                    gpu = updatedGpu,
                    asic = updatedAsic
                ),
                power = node.power.copy(
                    computeWatts = computeWatts,
                    coolingWatts = coolingWatts,
                    totalWatts = totalWatts
                ),
                thermal = node.thermal.copy(
                    cpuTempC = updatedCpu.temperatureC,
                    gpuTempC = updatedGpu?.temperatureC,
                    asicTempC = updatedAsic?.temperatureC,
                    fanSpeedRpm = min(6800, max(2000, (highestTemp * 65).toInt())),
                    thermalHeadroomC = 95.0 - highestTemp,
                    status = thermalStatus
                ),
                network = node.network.copy(telemetry = updatedNetTelemetry),
                uptimeSeconds = node.uptimeSeconds + 1
            )
        }

        // Job Progress update
        for (j in currentJobs.indices) {
            val job = currentJobs[j]
            if (job.status == JobStatus.RUNNING) {
                val newProgress = min(100.0, job.progressPercent + Random.nextDouble(1.0, 4.0))
                if (newProgress >= 100.0) {
                    currentJobs[j] = job.copy(
                        progressPercent = 100.0,
                        status = JobStatus.COMPLETED,
                        completedAtMs = System.currentTimeMillis(),
                        executionOutput = "Job completed successfully on compute node ${job.assignedNodeId}."
                    )
                } else {
                    currentJobs[j] = job.copy(progressPercent = newProgress)
                }
            }
        }

        _nodes.value = currentNodes
        _workers.value = currentWorkers
        _jobs.value = currentJobs
    }

    fun submitJob(job: ComputeJob): SchedulerDecision {
        val availableNodes = _nodes.value.filter { it.status == NodeStatus.ONLINE || it.status == NodeStatus.DEGRADED }
        val req = job.requirements

        val scoredNodes = availableNodes.map { node ->
            var score = 100.0
            if (req.cpuCores > node.hardware.cpu.cores - (node.workloads.sumOf { it.cpuAllocatedCores })) score -= 50.0
            if (req.gpuCount > 0) {
                if (node.hardware.gpu == null) score = -1000.0
                else if (node.hardware.gpu.vramGb < req.vramGb) score -= 200.0
            }
            score -= (node.network.telemetry.latencyMs * 0.5)
            score -= (node.thermal.cpuTempC * 0.3)
            node to score
        }.filter { it.second > 0 }.sortedByDescending { it.second }

        val bestMatch = scoredNodes.firstOrNull()?.first
        val decisionReason = if (bestMatch != null) {
            "Scheduled on ${bestMatch.hostname} (Match score: ${String.format("%.1f", scoredNodes.first().second)})"
        } else {
            "No suitable node found meeting resource constraints"
        }

        val updatedJob = if (bestMatch != null) {
            job.copy(
                assignedNodeId = bestMatch.id,
                status = JobStatus.RUNNING,
                startedAtMs = System.currentTimeMillis()
            )
        } else {
            job.copy(status = JobStatus.QUEUED)
        }

        _jobs.value = _jobs.value + updatedJob

        if (bestMatch != null) {
            val updatedNodes = _nodes.value.toMutableList()
            val nIdx = updatedNodes.indexOfFirst { it.id == bestMatch.id }
            if (nIdx != -1) {
                val n = updatedNodes[nIdx]
                val newWl = Workload(
                    id = "wl_${job.id}",
                    name = job.title,
                    type = job.type,
                    cpuAllocatedCores = req.cpuCores,
                    ramAllocatedGb = req.ramGb,
                    gpuAllocatedGb = req.vramGb,
                    powerDrawWatts = 180.0,
                    startTimeMs = System.currentTimeMillis()
                )
                updatedNodes[nIdx] = n.copy(workloads = n.workloads + newWl)
                _nodes.value = updatedNodes
            }
        }

        val decision = SchedulerDecision(
            jobId = job.id,
            selectedNodeId = bestMatch?.id,
            candidateNodesEvaluated = availableNodes.size,
            decisionReason = decisionReason,
            scoreMap = scoredNodes.take(5).associate { it.first.id to it.second },
            timestampMs = System.currentTimeMillis()
        )

        _decisions.value = listOf(decision) + _decisions.value.take(19)
        return decision
    }

    fun simulateSatelliteDegradation(siteRegion: String, degradationFactor: Double) {
        _nodes.value = _nodes.value.map { node ->
            if (node.location.region.contains(siteRegion, ignoreCase = true) || siteRegion == "ALL") {
                val newLat = node.network.telemetry.latencyMs * degradationFactor
                val newJitter = node.network.telemetry.jitterMs * degradationFactor
                val connState = if (degradationFactor > 2.0) ConnectionState.DEGRADED else ConnectionState.CONNECTED
                node.copy(
                    status = if (degradationFactor > 2.5) NodeStatus.NETWORK_DEGRADED else node.status,
                    network = node.network.copy(
                        telemetry = node.network.telemetry.copy(
                            latencyMs = newLat,
                            jitterMs = newJitter,
                            packetLossPercent = min(12.0, node.network.telemetry.packetLossPercent * degradationFactor),
                            connectionState = connState
                        )
                    )
                )
            } else node
        }
    }

    fun triggerNodeOverheat(nodeId: NodeId) {
        _nodes.value = _nodes.value.map { node ->
            if (node.id == nodeId) {
                val updatedCpu = node.hardware.cpu.copy(temperatureC = 89.5, utilizationPercent = 99.0)
                node.copy(
                    status = NodeStatus.OVERHEATED,
                    hardware = node.hardware.copy(cpu = updatedCpu),
                    thermal = node.thermal.copy(
                        cpuTempC = 89.5,
                        status = ThermalStatus.THERMAL_CRITICAL,
                        thermalHeadroomC = 5.5
                    )
                )
            } else node
        }
    }
}
