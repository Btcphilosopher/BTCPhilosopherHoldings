package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val StarlinkColorScheme = darkColorScheme(
    primary = TacticalBlue,
    onPrimary = DeepNavyBg,
    secondary = BitcoinGold,
    onSecondary = DeepNavyBg,
    tertiary = EmeraldOnline,
    background = DeepNavyBg,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = CardSurface,
    onSurfaceVariant = TextMuted,
    outline = SteelBorder,
    error = CrimsonCritical
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StarlinkColorScheme,
        typography = Typography,
        content = content
    )
}
