package com.example.starlinkedge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.starlinkedge.model.ComputeNode
import com.example.starlinkedge.model.MiningWorker
import com.example.starlinkedge.model.NodeStatus
import com.example.ui.theme.*

@Composable
fun MainDashboardView(
    nodes: List<ComputeNode>,
    workers: List<MiningWorker>,
    onSelectNode: (ComputeNode) -> Unit,
    onSimulateDegradation: () -> Unit,
    onInjectOverheat: () -> Unit
) {
    val scrollState = rememberScrollState()

    val totalNodes = nodes.size
    val onlineNodes = nodes.count { it.status == NodeStatus.ONLINE }
    val totalHashratePhs = workers.sumOf { it.hashrate.value } / 1000.0
    val totalPowerMw = nodes.sumOf { it.power.totalWatts } / 1_000_000.0
    val totalGpuVramGb = nodes.sumOf { it.hardware.gpu?.vramGb ?: 0 }
    val avgLatencyMs = if (nodes.isNotEmpty()) nodes.map { it.network.telemetry.latencyMs }.average() else 0.0
    val activeJobs = nodes.sumOf { it.workloads.size }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavyBg)
            .padding(16.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Banner Text
        Text(
            text = "GLOBAL COMPUTE FABRIC SUMMARY",
            color = TextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )

        // Metrics Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricTile(
                title = "NODES ONLINE",
                value = "$onlineNodes / $totalNodes",
                subText = "${((onlineNodes.toDouble() / maxOf(1, totalNodes)) * 100).toInt()}% Fabric Operational",
                icon = Icons.Default.Dns,
                accentColor = EmeraldOnline,
                modifier = Modifier.weight(1f)
            )
            MetricTile(
                title = "BITCOIN HASHRATE",
                value = "${String.format("%.2f", totalHashratePhs)} PH/s",
                subText = "${workers.size} Active SHA-256 Miners",
                icon = Icons.Default.CurrencyBitcoin,
                accentColor = BitcoinGold,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricTile(
                title = "POWER LOAD",
                value = "${String.format("%.3f", totalPowerMw)} MW",
                subText = "${(totalPowerMw * 1000).toInt()} kW Consumed",
                icon = Icons.Default.Bolt,
                accentColor = TacticalBlue,
                modifier = Modifier.weight(1f)
            )
            MetricTile(
                title = "GPU VRAM CAPACITY",
                value = "$totalGpuVramGb GB",
                subText = "${nodes.count { it.hardware.gpu != null }} AI Accelerator Nodes",
                icon = Icons.Default.DeveloperBoard,
                accentColor = EmeraldOnline,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricTile(
                title = "SATELLITE LATENCY",
                value = "${String.format("%.1f", avgLatencyMs)} ms",
                subText = "20 Ground Stations Connected",
                icon = Icons.Default.SatelliteAlt,
                accentColor = TacticalBlue,
                modifier = Modifier.weight(1f)
            )
            MetricTile(
                title = "ACTIVE WORKLOADS",
                value = "$activeJobs Jobs",
                subText = "GPU + Container Execution",
                icon = Icons.Default.Work,
                accentColor = BitcoinGold,
                modifier = Modifier.weight(1f)
            )
        }

        // Quick Controls
        Surface(
            color = CardSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SteelBorder, RoundedCornerShape(10.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "SIMULATION CONTROL & FAULT INJECTION",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = onSimulateDegradation,
                        colors = ButtonDefaults.buttonColors(containerColor = AmberWarning, contentColor = DeepNavyBg),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("sim_rain_fade_button")
                    ) {
                        Icon(Icons.Default.CloudOff, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Trigger Rain Fade", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onInjectOverheat,
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonCritical, contentColor = TextPrimary),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("sim_overheat_button")
                    ) {
                        Icon(Icons.Default.Thermostat, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Inject Overheat", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Global Node Grid Topology Map
        Surface(
            color = CardSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SteelBorder, RoundedCornerShape(10.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "GLOBAL ORBITAL NODE TOPOLOGY (100 NODES)",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        LegendItem("ONLINE", EmeraldOnline)
                        LegendItem("DEGRADED", AmberWarning)
                        LegendItem("OVERHEAT", CrimsonCritical)
                    }
                }

                Spacer(Modifier.height(12.dp))

                Box(modifier = Modifier.height(300.dp)) {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 64.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(nodes) { node ->
                            val statusColor = when (node.status) {
                                NodeStatus.ONLINE -> EmeraldOnline
                                NodeStatus.DEGRADED, NodeStatus.NETWORK_DEGRADED -> AmberWarning
                                NodeStatus.OVERHEATED -> CrimsonCritical
                                else -> TextMuted
                            }

                            Box(
                                modifier = Modifier
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(DarkSurface)
                                    .border(1.dp, statusColor.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                    .clickable { onSelectNode(node) }
                                    .padding(4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(statusColor)
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = node.id.removePrefix("node_"),
                                        color = TextPrimary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = if (node.hardware.asic != null) "ASIC" else if (node.hardware.gpu != null) "GPU" else "CPU",
                                        color = TextMuted,
                                        fontSize = 8.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricTile(
    title: String,
    value: String,
    subText: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = CardSurface,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier.border(1.dp, SteelBorder, RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = TextMuted,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = value,
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = subText,
                color = accentColor,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(color))
        Text(text = label, color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }
}
