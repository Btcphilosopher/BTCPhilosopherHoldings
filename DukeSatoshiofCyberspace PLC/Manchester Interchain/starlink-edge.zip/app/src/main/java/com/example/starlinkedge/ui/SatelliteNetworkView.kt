package com.example.starlinkedge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SatelliteAlt
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.starlinkedge.model.ComputeNode
import com.example.ui.theme.*

@Composable
fun SatelliteNetworkView(
    nodes: List<ComputeNode>,
    onSimulateRainFade: () -> Unit
) {
    val scrollState = rememberScrollState()

    val avgDown = if (nodes.isNotEmpty()) nodes.map { it.network.telemetry.downlinkMbps }.average() else 0.0
    val avgUp = if (nodes.isNotEmpty()) nodes.map { it.network.telemetry.uplinkMbps }.average() else 0.0
    val avgLat = if (nodes.isNotEmpty()) nodes.map { it.network.telemetry.latencyMs }.average() else 0.0
    val avgJitter = if (nodes.isNotEmpty()) nodes.map { it.network.telemetry.jitterMs }.average() else 0.0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavyBg)
            .padding(16.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.SatelliteAlt, contentDescription = null, tint = TacticalBlue, modifier = Modifier.size(28.dp))
                Column {
                    Text(
                        text = "SATELLITE INTERNET NETWORK TELEMETRY",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "ORBITAL SHELL-4 // LEO CONSTELLATION LINK LAYER",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Button(
                onClick = onSimulateRainFade,
                colors = ButtonDefaults.buttonColors(containerColor = AmberWarning, contentColor = DeepNavyBg),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.testTag("sim_fade_network_button")
            ) {
                Text("SIMULATE RAIN FADE", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }

        // Summary Tiles
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            MetricTile(
                title = "DOWNLINK SPEED",
                value = "${String.format("%.1f", avgDown)} Mbps",
                subText = "Avg Ground Bandwidth",
                icon = Icons.Default.SatelliteAlt,
                accentColor = TacticalBlue,
                modifier = Modifier.weight(1f)
            )
            MetricTile(
                title = "UPLINK SPEED",
                value = "${String.format("%.1f", avgUp)} Mbps",
                subText = "Avg Share Submissions",
                icon = Icons.Default.SatelliteAlt,
                accentColor = EmeraldOnline,
                modifier = Modifier.weight(1f)
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            MetricTile(
                title = "ROUND-TRIP LATENCY",
                value = "${String.format("%.1f", avgLat)} ms",
                subText = "LEO Orbit -> Ground Station",
                icon = Icons.Default.SatelliteAlt,
                accentColor = TacticalBlue,
                modifier = Modifier.weight(1f)
            )
            MetricTile(
                title = "LINK JITTER",
                value = "${String.format("%.1f", avgJitter)} ms",
                subText = "Packet Loss: < 0.2%",
                icon = Icons.Default.SatelliteAlt,
                accentColor = AmberWarning,
                modifier = Modifier.weight(1f)
            )
        }

        // Network Ground Station Matrix
        Surface(
            color = CardSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SteelBorder, RoundedCornerShape(10.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "GROUND STATION LATENCY MATRIX (20 STATIONS)",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(Modifier.height(10.dp))

                Box(modifier = Modifier.height(300.dp)) {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(nodes.take(20)) { node ->
                            Surface(
                                color = DarkSurface,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "${node.location.groundStation} (${node.location.region})",
                                            color = TextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = "Node: ${node.hostname} // IP: ${node.network.ipAddress}",
                                            color = TextMuted,
                                            fontSize = 10.sp
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "${String.format("%.1f", node.network.telemetry.latencyMs)} ms",
                                            color = TacticalBlue,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = "${String.format("%.1f", node.network.telemetry.downlinkMbps)} / ${String.format("%.1f", node.network.telemetry.uplinkMbps)} Mbps",
                                            color = TextMuted,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
