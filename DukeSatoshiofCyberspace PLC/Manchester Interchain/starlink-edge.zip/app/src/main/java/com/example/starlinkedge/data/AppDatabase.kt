package com.example.starlinkedge.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "node_snapshots")
data class NodeSnapshotEntity(
    @PrimaryKey val id: String,
    val hostname: String,
    val status: String,
    val country: String,
    val region: String,
    val totalPowerWatts: Double,
    val cpuTempC: Double,
    val hashrateTHs: Double,
    val timestampMs: Long
)

@Entity(tableName = "audit_events")
data class AuditEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val eventType: String,
    val description: String,
    val principal: String = "OPERATOR",
    val timestampMs: Long = System.currentTimeMillis()
)

@Dao
interface NodeSnapshotDao {
    @Query("SELECT * FROM node_snapshots ORDER BY timestampMs DESC")
    fun getAllSnapshots(): Flow<List<NodeSnapshotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(snapshots: List<NodeSnapshotEntity>)
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audit_events ORDER BY timestampMs DESC LIMIT 50")
    fun getRecentEvents(): Flow<List<AuditEventEntity>>

    @Insert
    suspend fun insertEvent(event: AuditEventEntity)
}

@Database(entities = [NodeSnapshotEntity::class, AuditEventEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun nodeSnapshotDao(): NodeSnapshotDao
    abstract fun auditDao(): AuditDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "starlink_edge_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
