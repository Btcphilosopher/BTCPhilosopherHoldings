package com.example.starlinkedge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CurrencyBitcoin
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.starlinkedge.model.MiningPool
import com.example.starlinkedge.model.MiningWorker
import com.example.ui.theme.*

@Composable
fun BitcoinMiningView(
    workers: List<MiningWorker>,
    pools: List<MiningPool>
) {
    val scrollState = rememberScrollState()

    val totalHashrateTHs = workers.sumOf { it.hashrate.value }
    val totalPowerW = workers.sumOf { it.powerWatts }
    val totalAccepted = workers.sumOf { it.acceptedShares }
    val totalRejected = workers.sumOf { it.rejectedShares }
    val efficiencyJPerTH = if (totalHashrateTHs > 0) totalPowerW / totalHashrateTHs else 0.0

    // Economics Calculator state
    var powerTariffUsd by remember { mutableStateOf("0.045") }
    var btcPriceUsd by remember { mutableStateOf("68500") }

    val tariff = powerTariffUsd.toDoubleOrNull() ?: 0.045
    val btcPrice = btcPriceUsd.toDoubleOrNull() ?: 68500.0

    val dailyKwh = (totalPowerW / 1000.0) * 24.0
    val dailyPowerCost = dailyKwh * tariff
    val totalHashratePhs = totalHashrateTHs / 1000.0
    val dailyBtcEarned = totalHashratePhs * 0.00062
    val dailyGrossRev = dailyBtcEarned * btcPrice
    val dailyNetMargin = dailyGrossRev - dailyPowerCost

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavyBg)
            .padding(16.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Default.CurrencyBitcoin, contentDescription = null, tint = BitcoinGold, modifier = Modifier.size(28.dp))
            Column {
                Text(
                    text = "BITCOIN SHA-256 MINING ENGINE",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "POOL COORDINATION // HASHRATE ACCOUNTING // ENERGY ECONOMICS",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Summary Cards
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            MetricTile(
                title = "TOTAL HASHRATE",
                value = "${String.format("%.2f", totalHashratePhs)} PH/s",
                subText = "${String.format("%.1f", totalHashrateTHs)} TH/s Total",
                icon = Icons.Default.CurrencyBitcoin,
                accentColor = BitcoinGold,
                modifier = Modifier.weight(1f)
            )
            MetricTile(
                title = "ENERGY EFFICIENCY",
                value = "${String.format("%.2f", efficiencyJPerTH)} J/TH",
                subText = "${String.format("%.1f", totalPowerW / 1000.0)} kW Power Draw",
                icon = Icons.Default.CurrencyBitcoin,
                accentColor = EmeraldOnline,
                modifier = Modifier.weight(1f)
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            MetricTile(
                title = "ACCEPTED SHARES",
                value = String.format("%,d", totalAccepted),
                subText = "Valid Submissions",
                icon = Icons.Default.CurrencyBitcoin,
                accentColor = EmeraldOnline,
                modifier = Modifier.weight(1f)
            )
            MetricTile(
                title = "REJECTED SHARES",
                value = String.format("%,d", totalRejected),
                subText = "Stale Share Rate: ${String.format("%.2f", (totalRejected.toDouble() / maxOf(1L, totalAccepted + totalRejected)) * 100)}%",
                icon = Icons.Default.CurrencyBitcoin,
                accentColor = AmberWarning,
                modifier = Modifier.weight(1f)
            )
        }

        // Mining Economic Calculator Panel
        Surface(
            color = CardSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SteelBorder, RoundedCornerShape(10.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "MINING ECONOMIC SIMULATION MODEL [MODELED MODEL]",
                    color = BitcoinGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = powerTariffUsd,
                        onValueChange = { powerTariffUsd = it },
                        label = { Text("Electricity Tariff ($/kWh)", color = TextMuted, fontSize = 10.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = DarkSurface,
                            unfocusedContainerColor = DarkSurface,
                            focusedBorderColor = TacticalBlue,
                            unfocusedBorderColor = SteelBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tariff_input")
                    )

                    OutlinedTextField(
                        value = btcPriceUsd,
                        onValueChange = { btcPriceUsd = it },
                        label = { Text("Assumed BTC Price ($)", color = TextMuted, fontSize = 10.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = DarkSurface,
                            unfocusedContainerColor = DarkSurface,
                            focusedBorderColor = TacticalBlue,
                            unfocusedBorderColor = SteelBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btc_price_input")
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurface, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Daily Energy Consumed: ${String.format("%.1f", dailyKwh)} kWh", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text("Daily Power Cost: $${String.format("%.2f", dailyPowerCost)}", color = AmberWarning, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text("Modelled BTC Output: ${String.format("%.6f", dailyBtcEarned)} BTC", color = BitcoinGold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Gross Daily Revenue: $${String.format("%.2f", dailyGrossRev)}", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text(
                            text = "Net Margin: $${String.format("%.2f", dailyNetMargin)}",
                            color = if (dailyNetMargin >= 0) EmeraldOnline else CrimsonCritical,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text("Margin %: ${String.format("%.1f", if (dailyGrossRev > 0) (dailyNetMargin / dailyGrossRev) * 100 else 0.0)}%", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Active Workers List
        Surface(
            color = CardSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SteelBorder, RoundedCornerShape(10.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "ACTIVE ASIC WORKERS (${workers.size} WORKERS)",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(Modifier.height(10.dp))

                Box(modifier = Modifier.height(260.dp)) {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(workers) { worker ->
                            WorkerRowItem(worker = worker)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WorkerRowItem(worker: MiningWorker) {
    Surface(
        color = DarkSurface,
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth().testTag("worker_item_${worker.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "${worker.id} (${worker.nodeId})",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Pool: ${worker.poolName} // Temp: ${String.format("%.1f", worker.temperatureC)}°C",
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${String.format("%.1f", worker.hashrate.value)} TH/s",
                    color = BitcoinGold,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Shares: ${worker.acceptedShares} / ${worker.rejectedShares} rej",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
