package com.example.starlinkedge.model

import java.time.Instant

typealias NodeId = String
typealias WorkerId = String
typealias JobId = String
typealias HardwareId = String
typealias OwnerId = String

enum class NodeStatus {
    PROVISIONING,
    ONLINE,
    DEGRADED,
    OVERHEATED,
    NETWORK_DEGRADED,
    POWER_LIMITED,
    OFFLINE,
    MAINTENANCE
}

enum class Capability {
    CPU,
    GPU,
    ASIC,
    STORAGE,
    BITCOIN_MINING,
    CONTAINER,
    VM,
    BATCH,
    AI_INFERENCE,
    RENDERING,
    EDGE
}

data class GeoLocation(
    val country: String,
    val region: String,
    val latitude: Double,
    val longitude: Double,
    val groundStation: String
)

data class CpuHardware(
    val id: HardwareId,
    val model: String,
    val cores: Int,
    val threads: Int,
    val architecture: String,
    val frequencyGHz: Double,
    val utilizationPercent: Double,
    val temperatureC: Double,
    val powerWatts: Double
)

data class GpuHardware(
    val id: HardwareId,
    val model: String,
    val vramGb: Int,
    val computeCapability: String,
    val utilizationPercent: Double,
    val temperatureC: Double,
    val powerWatts: Double,
    val memoryBandwidthGBs: Double
)

enum class MiningAlgorithm {
    SHA256D
}

data class AsicHardware(
    val id: HardwareId,
    val manufacturer: String,
    val model: String,
    val algorithm: MiningAlgorithm = MiningAlgorithm.SHA256D,
    val nominalHashrateTHs: Double,
    val currentHashrateTHs: Double,
    val powerDrawWatts: Double,
    val temperatureC: Double,
    val fanSpeedRpm: Int,
    val acceptedShares: Long,
    val rejectedShares: Long,
    val hardwareErrors: Long
)

data class StorageHardware(
    val id: HardwareId,
    val capacityTB: Double,
    val usedTB: Double,
    val readIOPS: Int,
    val writeIOPS: Int,
    val readBandwidthMBs: Double,
    val writeBandwidthMBs: Double,
    val healthPercent: Int
)

data class NetworkInterface(
    val interfaceName: String,
    val downlinkMbps: Double,
    val uplinkMbps: Double,
    val latencyMs: Double,
    val packetLossPercent: Double,
    val jitterMs: Double
)

data class HardwareInventory(
    val cpu: CpuHardware,
    val gpu: GpuHardware?,
    val asic: AsicHardware?,
    val storage: StorageHardware,
    val networkInterface: NetworkInterface
)

enum class PowerMode {
    POWER_NORMAL,
    POWER_LIMITED,
    POWER_CRITICAL
}

data class PowerState(
    val inputWatts: Double,
    val computeWatts: Double,
    val networkWatts: Double,
    val coolingWatts: Double,
    val totalWatts: Double,
    val powerCapWatts: Double,
    val mode: PowerMode
)

enum class ThermalStatus {
    THERMAL_NORMAL,
    THERMAL_WARNING,
    THERMAL_THROTTLED,
    THERMAL_CRITICAL
}

data class ThermalState(
    val cpuTempC: Double,
    val gpuTempC: Double?,
    val asicTempC: Double?,
    val ambientTempC: Double,
    val fanSpeedRpm: Int,
    val coolingPowerWatts: Double,
    val thermalHeadroomC: Double,
    val status: ThermalStatus
)

enum class ConnectionState {
    CONNECTED,
    DEGRADED,
    CONGESTED,
    INTERRUPTED,
    UNKNOWN
}

enum class ProviderType {
    SATELLITE_ORBITAL,
    FIBER_ENTERPRISE,
    HYBRID_BACKUP
}

data class NetworkTelemetry(
    val timestampMs: Long,
    val downlinkMbps: Double,
    val uplinkMbps: Double,
    val latencyMs: Double,
    val jitterMs: Double,
    val packetLossPercent: Double,
    val connectionState: ConnectionState,
    val providerType: ProviderType = ProviderType.SATELLITE_ORBITAL,
    val satelliteConstellation: String = "ORBITAL-SHELL-4"
)

data class NetworkState(
    val telemetry: NetworkTelemetry,
    val ipAddress: String,
    val groundStationId: String
)

enum class WorkloadType {
    CONTAINER,
    BATCH,
    GPU_COMPUTE,
    AI_INFERENCE,
    RENDER,
    SCIENTIFIC,
    DATA_PROCESSING,
    STORAGE,
    EDGE_SERVICE,
    BITCOIN_MINING
}

data class Workload(
    val id: String,
    val name: String,
    val type: WorkloadType,
    val cpuAllocatedCores: Int,
    val ramAllocatedGb: Int,
    val gpuAllocatedGb: Int,
    val powerDrawWatts: Double,
    val startTimeMs: Long
)

data class ComputeNode(
    val id: NodeId,
    val hostname: String,
    val status: NodeStatus,
    val location: GeoLocation,
    val hardware: HardwareInventory,
    val power: PowerState,
    val thermal: ThermalState,
    val network: NetworkState,
    val workloads: List<Workload>,
    val capabilities: Set<Capability>,
    val uptimeSeconds: Long
)
