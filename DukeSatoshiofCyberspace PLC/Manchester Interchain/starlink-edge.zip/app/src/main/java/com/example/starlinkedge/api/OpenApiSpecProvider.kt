package com.example.starlinkedge.api

object OpenApiSpecProvider {
    fun getOpenApiYamlSpec(): String {
        return """
openapi: 3.0.3
info:
  title: STARLINK-EDGE Orbital Compute Network API
  description: Production-grade API platform for distributed Bitcoin mining, GPU/CPU cloud computing, and satellite internet node management.
  version: 2.4.0
servers:
  - url: https://api.starlink-edge.net/v1
    description: Production Gateway
  - url: http://localhost:8080/api/v1
    description: Local Infrastructure Emulator
paths:
  /nodes:
    get:
      summary: List compute nodes
      parameters:
        - name: status
          in: query
          schema:
            type: string
        - name: capability
          in: query
          schema:
            type: string
      responses:
        '200':
          description: Array of compute nodes
    post:
      summary: Register a new compute node
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              properties:
                hostname:
                  type: string
                  example: EDGE-NODE-001
                capabilities:
                  type: array
                  items:
                    type: string
      responses:
        '201':
          description: Node registered
  /nodes/{id}:
    get:
      summary: Get node telemetry and hardware
      parameters:
        - name: id
          in: path
          required: true
          schema:
            type: string
      responses:
        '200':
          description: Detailed compute node object
  /miners:
    get:
      summary: List active Bitcoin ASIC workers
      responses:
        '200':
          description: List of mining workers
  /miners/{id}/hashrate:
    get:
      summary: Get live hashrate accounting
      responses:
        '200':
          description: Hashrate telemetry
  /jobs:
    get:
      summary: List cloud compute jobs
      responses:
        '200':
          description: Compute job list
    post:
      summary: Submit new cloud compute workload
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              properties:
                type:
                  type: string
                  example: GPU_COMPUTE
                requirements:
                  type: object
                  properties:
                    gpuCount:
                      type: integer
                      example: 2
                    vramGb:
                      type: integer
                      example: 48
      responses:
        '202':
          description: Job scheduled
  /network/telemetry:
    get:
      summary: Satellite network connection state & latency
      responses:
        '200':
          description: Network telemetry metrics
        """.trimIndent()
    }
}
