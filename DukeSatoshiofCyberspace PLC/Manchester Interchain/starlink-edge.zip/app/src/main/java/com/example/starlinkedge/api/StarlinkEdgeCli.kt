package com.example.starlinkedge.api

import com.example.starlinkedge.model.ComputeJob
import com.example.starlinkedge.model.ResourceRequirements
import com.example.starlinkedge.model.RuntimeConfig
import com.example.starlinkedge.model.WorkloadType
import com.example.starlinkedge.simulation.SimulationEngine

class StarlinkEdgeCli(private val simulationEngine: SimulationEngine) {

    fun executeCommand(commandString: String): String {
        val tokens = commandString.trim().split("\\s+".toRegex())
        if (tokens.isEmpty() || tokens[0].lowercase() != "starlink-edge") {
            return "Error: Command must start with 'starlink-edge'. Type 'starlink-edge --help' for available commands."
        }

        if (tokens.size == 1 || tokens.getOrNull(1) == "--help" || tokens.getOrNull(1) == "-h") {
            return """
========================================================================
             STARLINK-EDGE CLI v2.4-PROD (ORBITAL COMPUTE)
========================================================================
USAGE: starlink-edge <subcommand> [options]

AVAILABLE SUBCOMMANDS:
  nodes list                      List all compute nodes in the orbital fabric
  nodes inspect <node_id>         Inspect detailed hardware & thermal state for a node
  miners list                     List active Bitcoin SHA-256 ASIC miners
  miners status <miner_id>        Get detailed status for a specific miner
  mining stats                    Display global Bitcoin hashrate & energy telemetry
  mining simulate                 Calculate modelled mining revenue & gross margins
  jobs list                       List active and queued cloud compute jobs
  jobs submit <type> <title>      Submit a new compute job (e.g. GPU_COMPUTE, AI_INFERENCE)
  jobs inspect <job_id>           Inspect compute job execution handle
  network status                  Show orbital satellite constellation link telemetry
  simulate start                  Start the live real-time infrastructure simulator
  simulate stop                   Pause the live real-time infrastructure simulator
  health                          System diagnostic, component status & API readiness
========================================================================
            """.trimIndent()
        }

        return when (tokens[1].lowercase()) {
            "nodes" -> handleNodes(tokens.drop(2))
            "miners" -> handleMiners(tokens.drop(2))
            "mining" -> handleMining(tokens.drop(2))
            "jobs" -> handleJobs(tokens.drop(2))
            "network" -> handleNetwork(tokens.drop(2))
            "simulate" -> handleSimulate(tokens.drop(2))
            "health" -> handleHealth()
            else -> "Error: Unknown subcommand '${tokens[1]}'. Use 'starlink-edge --help'."
        }
    }

    private fun handleNodes(args: List<String>): String {
        val sub = args.firstOrNull()?.lowercase() ?: "list"
        val nodes = simulationEngine.nodes.value

        return when (sub) {
            "list" -> {
                val sb = StringBuilder()
                sb.appendLine("ID         HOSTNAME          STATUS           LOCATION              CAPABILITIES                  UPTIME")
                sb.appendLine("---------------------------------------------------------------------------------------------------------")
                nodes.take(25).forEach { n ->
                    val caps = n.capabilities.joinToString(",")
                    val uptimeH = n.uptimeSeconds / 3600
                    sb.appendLine("${n.id.padEnd(10)} ${n.hostname.padEnd(17)} ${n.status.name.padEnd(16)} ${(n.location.country + "/" + n.location.region).take(21).padEnd(21)} ${caps.take(28).padEnd(28)} ${uptimeH}h")
                }
                sb.appendLine("\n[Showing 25 of ${nodes.size} nodes. Use 'starlink-edge nodes inspect <id>' for full state]")
                sb.toString()
            }
            "inspect" -> {
                val nodeId = args.getOrNull(1) ?: return "Error: Missing <node_id> parameter."
                val node = nodes.find { it.id.equals(nodeId, ignoreCase = true) || it.hostname.equals(nodeId, ignoreCase = true) }
                    ?: return "Error: Compute node '$nodeId' not found."

                """
========================================================================
COMPUTE NODE INSPECTION: ${node.hostname} (${node.id})
========================================================================
Status           : ${node.status}
Location         : ${node.location.region}, ${node.location.country} (Lat: ${node.location.latitude}, Lon: ${node.location.longitude})
Ground Station   : ${node.location.groundStation}
Uptime           : ${node.uptimeSeconds / 3600} hours
Capabilities     : ${node.capabilities.joinToString(", ")}

[HARDWARE INVENTORY]
CPU Model        : ${node.hardware.cpu.model}
CPU Cores/Threads: ${node.hardware.cpu.cores} cores / ${node.hardware.cpu.threads} threads @ ${node.hardware.cpu.frequencyGHz} GHz
CPU Load / Temp  : ${String.format("%.1f", node.hardware.cpu.utilizationPercent)}% | ${String.format("%.1f", node.hardware.cpu.temperatureC)}°C | ${String.format("%.1f", node.hardware.cpu.powerWatts)} W

GPU Model        : ${node.hardware.gpu?.model ?: "N/A"}
GPU VRAM / Load  : ${node.hardware.gpu?.let { "${it.vramGb} GB VRAM | ${String.format("%.1f", it.utilizationPercent)}% | ${String.format("%.1f", it.temperatureC)}°C | ${String.format("%.1f", it.powerWatts)} W" } ?: "N/A"}

ASIC Model       : ${node.hardware.asic?.model ?: "N/A"}
ASIC Hashrate    : ${node.hardware.asic?.let { "${String.format("%.1f", it.currentHashrateTHs)} TH/s | ${String.format("%.1f", it.powerDrawWatts)} W | ${String.format("%.1f", it.temperatureC)}°C" } ?: "N/A"}

[POWER & THERMALS]
Total Power Draw : ${String.format("%.1f", node.power.totalWatts)} W (Cap: ${node.power.powerCapWatts} W)
Cooling Power    : ${String.format("%.1f", node.power.coolingWatts)} W | Fan Speed: ${node.thermal.fanSpeedRpm} RPM
Thermal Headroom : ${String.format("%.1f", node.thermal.thermalHeadroomC)}°C (${node.thermal.status})

[NETWORK LINK TELEMETRY]
Provider         : ${node.network.telemetry.providerType} (${node.network.telemetry.satelliteConstellation})
Down / Up Bandw. : ${String.format("%.1f", node.network.telemetry.downlinkMbps)} Mbps / ${String.format("%.1f", node.network.telemetry.uplinkMbps)} Mbps
Latency / Jitter : ${String.format("%.1f", node.network.telemetry.latencyMs)} ms | ${String.format("%.1f", node.network.telemetry.jitterMs)} ms | Packet Loss: ${String.format("%.2f", node.network.telemetry.packetLossPercent)}%
========================================================================
                """.trimIndent()
            }
            else -> "Error: Unknown nodes command '$sub'."
        }
    }

    private fun handleMiners(args: List<String>): String {
        val sub = args.firstOrNull()?.lowercase() ?: "list"
        val workers = simulationEngine.workers.value

        return when (sub) {
            "list" -> {
                val sb = StringBuilder()
                sb.appendLine("WORKER ID   NODE ID    STATUS      HASHRATE      POWER(W)   TEMP(C)   ACCEPTED   REJECTED   POOL")
                sb.appendLine("-------------------------------------------------------------------------------------------------------")
                workers.forEach { w ->
                    sb.appendLine("${w.id.padEnd(11)} ${w.nodeId.padEnd(10)} ${w.status.name.padEnd(11)} ${String.format("%.1f", w.hashrate.value).padEnd(5)} TH/s   ${String.format("%.0f", w.powerWatts).padEnd(10)} ${String.format("%.1f", w.temperatureC).padEnd(9)} ${w.acceptedShares.toString().padEnd(10)} ${w.rejectedShares.toString().padEnd(10)} ${w.poolName}")
                }
                sb.appendLine("\nTotal Active Workers: ${workers.size}")
                sb.toString()
            }
            "status" -> {
                val minerId = args.getOrNull(1) ?: return "Error: Missing <miner_id> parameter."
                val worker = workers.find { it.id.equals(minerId, ignoreCase = true) }
                    ?: return "Error: Miner '$minerId' not found."

                """
========================================================================
BITCOIN ASIC WORKER STATUS: ${worker.id}
========================================================================
Node ID          : ${worker.nodeId}
Algorithm        : SHA-256d
Status           : ${worker.status}
Current Hashrate : ${String.format("%.2f", worker.hashrate.value)} TH/s
Power Draw       : ${String.format("%.1f", worker.powerWatts)} Watts
Temperature      : ${String.format("%.1f", worker.temperatureC)} °C
Pool Name        : ${worker.poolName}
Accepted Shares  : ${worker.acceptedShares}
Rejected Shares  : ${worker.rejectedShares}
Hardware Errors  : ${worker.hardwareErrors}
Efficiency       : ${String.format("%.2f", worker.powerWatts / worker.hashrate.value)} Joules/TH
========================================================================
                """.trimIndent()
            }
            else -> "Error: Unknown miners command '$sub'."
        }
    }

    private fun handleMining(args: List<String>): String {
        val sub = args.firstOrNull()?.lowercase() ?: "stats"
        val workers = simulationEngine.workers.value

        return when (sub) {
            "stats" -> {
                val totalHashrateTHs = workers.sumOf { it.hashrate.value }
                val totalPowerW = workers.sumOf { it.powerWatts }
                val totalAccepted = workers.sumOf { it.acceptedShares }
                val totalRejected = workers.sumOf { it.rejectedShares }
                val effJPerTh = if (totalHashrateTHs > 0) totalPowerW / totalHashrateTHs else 0.0

                """
========================================================================
ORBITAL BITCOIN MINING FABRIC TELEMETRY
========================================================================
Total Hashrate   : ${String.format("%.2f", totalHashrateTHs / 1000.0)} PH/s (${String.format("%.1f", totalHashrateTHs)} TH/s)
Active Workers   : ${workers.count { it.status == com.example.starlinkedge.model.WorkerStatus.RUNNING }} / ${workers.size}
Total Power Draw : ${String.format("%.2f", totalPowerW / 1000.0)} kW
Efficiency       : ${String.format("%.2f", effJPerTh)} J/TH
Accepted Shares  : $totalAccepted
Rejected Shares  : $totalRejected (Stale Rate: ${String.format("%.2f", (totalRejected.toDouble() / (totalAccepted + totalRejected + 1)) * 100)}%)
Active Pools     : ORBITAL-STRATUM-NORTH, ORBITAL-STRATUM-SOUTH
========================================================================
                """.trimIndent()
            }
            "simulate" -> {
                val totalPowerKw = workers.sumOf { it.powerWatts } / 1000.0
                val totalHashratePhs = workers.sumOf { it.hashrate.value } / 1000.0
                val dailyKwh = totalPowerKw * 24.0
                val powerCostPerKwh = 0.045 // $0.045 / kWh
                val dailyPowerCost = dailyKwh * powerCostPerKwh
                val modelledBtcPerPhsDay = 0.00062
                val dailyBtcEarned = totalHashratePhs * modelledBtcPerPhsDay
                val btcPriceUsd = 68500.0
                val dailyGrossRevenue = dailyBtcEarned * btcPriceUsd
                val dailyGrossMargin = dailyGrossRevenue - dailyPowerCost

                """
========================================================================
MINING ECONOMIC SIMULATION MODEL [MODELED MODEL]
========================================================================
Electricity Tariff : ${"$"}${powerCostPerKwh} / kWh (Stranded / Industrial)
Assumed BTC Price  : ${"$"}${String.format("%,.2f", btcPriceUsd)}
Total Hashrate     : ${String.format("%.3f", totalHashratePhs)} PH/s
Daily Energy Cons. : ${String.format("%.1f", dailyKwh)} kWh
Daily Power Cost   : ${"$"}${String.format("%.2f", dailyPowerCost)}
Modelled Daily BTC : ${String.format("%.6f", dailyBtcEarned)} BTC
Modelled Gross Rev : ${"$"}${String.format("%.2f", dailyGrossRevenue)}
Modelled Net Margin: ${"$"}${String.format("%.2f", dailyGrossMargin)} (${String.format("%.1f", (dailyGrossMargin / dailyGrossRevenue) * 100)}%)
========================================================================
                """.trimIndent()
            }
            else -> "Error: Unknown mining command '$sub'."
        }
    }

    private fun handleJobs(args: List<String>): String {
        val sub = args.firstOrNull()?.lowercase() ?: "list"
        val jobs = simulationEngine.jobs.value

        return when (sub) {
            "list" -> {
                val sb = StringBuilder()
                sb.appendLine("JOB ID     TYPE           STATUS      PROGRESS   NODE ID    TITLE")
                sb.appendLine("-------------------------------------------------------------------------------------------------")
                jobs.forEach { j ->
                    sb.appendLine("${j.id.padEnd(10)} ${j.type.name.padEnd(14)} ${j.status.name.padEnd(11)} ${String.format("%.1f%%", j.progressPercent).padEnd(10)} ${(j.assignedNodeId ?: "UNASSIGNED").padEnd(10)} ${j.title}")
                }
                sb.toString()
            }
            "submit" -> {
                val typeStr = args.getOrNull(1)?.uppercase() ?: "GPU_COMPUTE"
                val title = args.drop(2).joinToString(" ").ifEmpty { "Custom Batch Workload" }
                val type = try { WorkloadType.valueOf(typeStr) } catch (e: Exception) { WorkloadType.GPU_COMPUTE }

                val job = ComputeJob(
                    id = "job_${System.currentTimeMillis().toString().takeLast(6)}",
                    title = title,
                    ownerId = "cli_user",
                    type = type,
                    requirements = ResourceRequirements(cpuCores = 16, ramGb = 32, gpuCount = if (type == WorkloadType.GPU_COMPUTE) 1 else 0, vramGb = 24),
                    runtime = RuntimeConfig("starlink/cli-runner:latest", listOf("run", "--job-id", "job_cli")),
                    submittedAtMs = System.currentTimeMillis()
                )

                val decision = simulationEngine.submitJob(job)
                """
Job submitted successfully!
Job ID     : ${job.id}
Status     : ${decision.selectedNodeId?.let { "SCHEDULED -> RUNNING" } ?: "QUEUED"}
Assigned   : ${decision.selectedNodeId ?: "Awaiting capacity"}
Reason     : ${decision.decisionReason}
                """.trimIndent()
            }
            "inspect" -> {
                val jobId = args.getOrNull(1) ?: return "Error: Missing <job_id> parameter."
                val job = jobs.find { it.id.equals(jobId, ignoreCase = true) }
                    ?: return "Error: Job '$jobId' not found."

                """
========================================================================
COMPUTE JOB HANDLE: ${job.id}
========================================================================
Title            : ${job.title}
Owner ID         : ${job.ownerId}
Type             : ${job.type}
Status           : ${job.status}
Assigned Node    : ${job.assignedNodeId ?: "Unassigned"}
Progress         : ${String.format("%.1f", job.progressPercent)}%
Container Image  : ${job.runtime.image}
Command          : ${job.runtime.command.joinToString(" ")}
Requirements     : ${job.requirements.cpuCores} Cores | ${job.requirements.ramGb} GB RAM | ${job.requirements.gpuCount} GPU
Output Logs      : ${job.executionOutput.ifEmpty { "Executing..." }}
========================================================================
                """.trimIndent()
            }
            else -> "Error: Unknown jobs command '$sub'."
        }
    }

    private fun handleNetwork(args: List<String>): String {
        val nodes = simulationEngine.nodes.value
        val avgDown = nodes.map { it.network.telemetry.downlinkMbps }.average()
        val avgUp = nodes.map { it.network.telemetry.uplinkMbps }.average()
        val avgLat = nodes.map { it.network.telemetry.latencyMs }.average()
        val degradedCount = nodes.count { it.network.telemetry.connectionState == com.example.starlinkedge.model.ConnectionState.DEGRADED }

        return """
========================================================================
SATELLITE INTERNET NETWORK TELEMETRY (ORBITAL FABRIC)
========================================================================
Active Links     : ${nodes.size} Satellite Ground Stations
Avg Downlink     : ${String.format("%.1f", avgDown)} Mbps
Avg Uplink       : ${String.format("%.1f", avgUp)} Mbps
Avg Latency      : ${String.format("%.1f", avgLat)} ms
Degraded Links   : $degradedCount
Constellation    : ORBITAL-SHELL-4 (LEO Constellation)
========================================================================
        """.trimIndent()
    }

    private fun handleSimulate(args: List<String>): String {
        val action = args.firstOrNull()?.lowercase() ?: "status"
        return when (action) {
            "start" -> {
                simulationEngine.startSimulation()
                "Simulation engine started. Real-time telemetry ticker active."
            }
            "stop" -> {
                simulationEngine.stopSimulation()
                "Simulation engine paused."
            }
            else -> "Simulation is currently ${if (simulationEngine.isSimulating.value) "RUNNING" else "PAUSED"}."
        }
    }

    private fun handleHealth(): String {
        return """
========================================================================
STARLINK-EDGE PLATFORM DIAGNOSTICS & HEALTH
========================================================================
API Server Status     : ONLINE (v2.4.0)
Simulation Engine     : ${if (simulationEngine.isSimulating.value) "RUNNING" else "PAUSED"}
Total Managed Nodes   : ${simulationEngine.nodes.value.size}
Total Active Workers  : ${simulationEngine.workers.value.size}
Active Compute Jobs   : ${simulationEngine.jobs.value.count { it.status == com.example.starlinkedge.model.JobStatus.RUNNING }}
Database Connection   : ROOM PERSISTENT DB (OK)
OpenTelemetry Export  : PROMETHEUS METRICS AGENT ACTIVE
========================================================================
        """.trimIndent()
    }
}
