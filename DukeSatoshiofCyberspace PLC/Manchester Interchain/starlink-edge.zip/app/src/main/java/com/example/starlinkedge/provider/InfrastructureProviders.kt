package com.example.starlinkedge.provider

import com.example.starlinkedge.model.*

interface SatelliteNetworkProvider {
    suspend fun getConnectionState(nodeId: NodeId): ConnectionState
    suspend fun getTelemetry(nodeId: NodeId): NetworkTelemetry
    suspend fun measureLatency(nodeId: NodeId): Double
    suspend fun simulateLinkDegradation(siteRegion: String, factor: Double)
}

interface MiningBackend {
    suspend fun start(worker: MiningWorker): MiningWorker
    suspend fun stop(worker: MiningWorker): MiningWorker
    suspend fun getStatus(worker: MiningWorker): MiningStatus
    suspend fun submitShare(share: MiningShare): Boolean
    suspend fun updatePowerLimit(worker: MiningWorker, limitWatts: Double)
}

interface ComputeExecutor {
    suspend fun submit(job: ComputeJob): String // handle ID
    suspend fun stop(handleId: String)
    suspend fun status(handleId: String): JobStatus
    suspend fun getLogs(handleId: String): String
}

interface BitcoinSettlementProvider {
    suspend fun getEstimatedBalance(ownerId: OwnerId): Double
    suspend fun recordPayout(ownerId: OwnerId, amountBtc: Double, txHash: String): Boolean
}

interface PowerTelemetryProvider {
    suspend fun getPowerState(nodeId: NodeId): PowerState
    suspend fun setPowerCap(nodeId: NodeId, maxWatts: Double): PowerState
}

interface HardwareTelemetryProvider {
    suspend fun getThermalState(nodeId: NodeId): ThermalState
    suspend fun setFanSpeedOverride(nodeId: NodeId, fanSpeedRpm: Int): ThermalState
}
