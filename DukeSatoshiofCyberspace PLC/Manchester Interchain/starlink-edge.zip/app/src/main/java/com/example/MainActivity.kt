package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.starlinkedge.api.StarlinkEdgeCli
import com.example.starlinkedge.model.ComputeNode
import com.example.starlinkedge.simulation.SimulationEngine
import com.example.starlinkedge.ui.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    private val simulationEngine = SimulationEngine()
    private val cli = StarlinkEdgeCli(simulationEngine)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                StarlinkEdgeApp(simulationEngine = simulationEngine, cli = cli)
            }
        }
    }
}

@Composable
fun StarlinkEdgeApp(
    simulationEngine: SimulationEngine,
    cli: StarlinkEdgeCli
) {
    var selectedViewIndex by remember { mutableIntStateOf(0) } // 0=Fabric, 1=Fleet, 2=Mining, 3=Cloud, 4=Terminal
    var selectedNodeForInspection by remember { mutableStateOf<ComputeNode?>(null) }

    val isSimulating by simulationEngine.isSimulating.collectAsStateWithLifecycle()
    val nodes by simulationEngine.nodes.collectAsStateWithLifecycle()
    val workers by simulationEngine.workers.collectAsStateWithLifecycle()
    val jobs by simulationEngine.jobs.collectAsStateWithLifecycle()
    val pools by simulationEngine.pools.collectAsStateWithLifecycle()
    val decisions by simulationEngine.decisions.collectAsStateWithLifecycle()

    // BackHandler for custom state navigation
    BackHandler(enabled = selectedViewIndex != 0 || selectedNodeForInspection != null) {
        if (selectedNodeForInspection != null) {
            selectedNodeForInspection = null
        } else {
            selectedViewIndex = 0
        }
    }

    Scaffold(
        topBar = {
            HeaderAndTopBar(
                isSimulating = isSimulating,
                onToggleSimulation = {
                    if (isSimulating) simulationEngine.stopSimulation() else simulationEngine.startSimulation()
                }
            )
        },
        bottomBar = {
            Surface(
                color = DarkSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SteelBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    NavTabItem(
                        title = "FABRIC",
                        icon = Icons.Default.GridView,
                        isSelected = selectedViewIndex == 0,
                        tag = "tab_fabric"
                    ) {
                        selectedViewIndex = 0
                    }

                    NavTabItem(
                        title = "FLEET (${nodes.size})",
                        icon = Icons.Default.Dns,
                        isSelected = selectedViewIndex == 1,
                        tag = "tab_fleet"
                    ) {
                        selectedViewIndex = 1
                    }

                    NavTabItem(
                        title = "MINING",
                        icon = Icons.Default.CurrencyBitcoin,
                        isSelected = selectedViewIndex == 2,
                        tag = "tab_mining"
                    ) {
                        selectedViewIndex = 2
                    }

                    NavTabItem(
                        title = "CLOUD",
                        icon = Icons.Default.Cloud,
                        isSelected = selectedViewIndex == 3,
                        tag = "tab_cloud"
                    ) {
                        selectedViewIndex = 3
                    }

                    NavTabItem(
                        title = "TERMINAL",
                        icon = Icons.Default.Terminal,
                        isSelected = selectedViewIndex == 4,
                        tag = "tab_terminal"
                    ) {
                        selectedViewIndex = 4
                    }
                }
            }
        },
        containerColor = DeepNavyBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedViewIndex) {
                0 -> MainDashboardView(
                    nodes = nodes,
                    workers = workers,
                    onSelectNode = { node ->
                        selectedNodeForInspection = node
                        selectedViewIndex = 1
                    },
                    onSimulateDegradation = {
                        simulationEngine.simulateSatelliteDegradation("ALL", 2.8)
                    },
                    onInjectOverheat = {
                        nodes.firstOrNull()?.let { simulationEngine.triggerNodeOverheat(it.id) }
                    }
                )

                1 -> FleetNodesView(
                    nodes = nodes,
                    selectedNode = selectedNodeForInspection,
                    onSelectNode = { selectedNodeForInspection = it }
                )

                2 -> BitcoinMiningView(
                    workers = workers,
                    pools = pools
                )

                3 -> CloudComputeView(
                    jobs = jobs,
                    decisions = decisions,
                    onSubmitJob = { newJob ->
                        simulationEngine.submitJob(newJob)
                    }
                )

                4 -> TerminalAndApiView(
                    cli = cli
                )
            }
        }
    }
}

@Composable
fun NavTabItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    tag: String,
    onClick: () -> Unit
) {
    TextButton(
        onClick = onClick,
        colors = ButtonDefaults.textButtonColors(
            contentColor = if (isSelected) TacticalBlue else TextMuted
        ),
        modifier = Modifier.testTag(tag)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) TacticalBlue else TextMuted,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = title,
                color = if (isSelected) TacticalBlue else TextMuted,
                fontSize = 9.sp,
                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Normal,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
