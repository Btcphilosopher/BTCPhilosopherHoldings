package com.example.starlinkedge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.starlinkedge.model.Capability
import com.example.starlinkedge.model.ComputeNode
import com.example.starlinkedge.model.NodeStatus
import com.example.ui.theme.*

@Composable
fun FleetNodesView(
    nodes: List<ComputeNode>,
    selectedNode: ComputeNode?,
    onSelectNode: (ComputeNode?) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCapabilityFilter by remember { mutableStateOf<Capability?>(null) }

    val filteredNodes = remember(nodes, searchQuery, selectedCapabilityFilter) {
        nodes.filter { n ->
            val matchesQuery = searchQuery.isEmpty() ||
                    n.hostname.contains(searchQuery, ignoreCase = true) ||
                    n.id.contains(searchQuery, ignoreCase = true) ||
                    n.location.country.contains(searchQuery, ignoreCase = true) ||
                    n.location.region.contains(searchQuery, ignoreCase = true)

            val matchesCap = selectedCapabilityFilter == null || n.capabilities.contains(selectedCapabilityFilter)
            matchesQuery && matchesCap
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavyBg)
            .padding(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // Header Search & Filters
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search node ID, hostname, region...", color = TextMuted, fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CardSurface,
                        unfocusedContainerColor = CardSurface,
                        focusedBorderColor = TacticalBlue,
                        unfocusedBorderColor = SteelBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("node_search_input")
                )
            }

            // Capability filter chips
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                CapFilterChip(label = "ALL (${nodes.size})", isSelected = selectedCapabilityFilter == null) {
                    selectedCapabilityFilter = null
                }
                CapFilterChip(label = "ASIC MINERS", isSelected = selectedCapabilityFilter == Capability.ASIC) {
                    selectedCapabilityFilter = Capability.ASIC
                }
                CapFilterChip(label = "GPU NODES", isSelected = selectedCapabilityFilter == Capability.GPU) {
                    selectedCapabilityFilter = Capability.GPU
                }
                CapFilterChip(label = "CPU NODES", isSelected = selectedCapabilityFilter == Capability.CPU) {
                    selectedCapabilityFilter = Capability.CPU
                }
            }

            Text(
                text = "FLEET NODES (${filteredNodes.size} DISPLAYED)",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            // Node List
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredNodes, key = { it.id }) { node ->
                    NodeItemCard(node = node, onClick = { onSelectNode(node) })
                }
            }
        }

        // Node Inspector Modal Dialog
        if (selectedNode != null) {
            NodeDetailDialog(node = selectedNode, onDismiss = { onSelectNode(null) })
        }
    }
}

@Composable
fun CapFilterChip(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (isSelected) TacticalBlue else CardSurface,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .border(1.dp, if (isSelected) TacticalBlue else SteelBorder, RoundedCornerShape(16.dp))
            .clickable { onClick() }
    ) {
        Text(
            text = label,
            color = if (isSelected) DeepNavyBg else TextPrimary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}

@Composable
fun NodeItemCard(node: ComputeNode, onClick: () -> Unit) {
    val statusColor = when (node.status) {
        NodeStatus.ONLINE -> EmeraldOnline
        NodeStatus.DEGRADED, NodeStatus.NETWORK_DEGRADED -> AmberWarning
        NodeStatus.OVERHEATED -> CrimsonCritical
        else -> TextMuted
    }

    Surface(
        color = CardSurface,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SteelBorder, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .testTag("node_card_${node.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(statusColor)
                )

                Column {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = node.hostname,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = node.id,
                            color = TextMuted,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = "${node.location.region}, ${node.location.country} // GS: ${node.location.groundStation}",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${String.format("%.0f", node.power.totalWatts)} W | ${String.format("%.1f", node.thermal.cpuTempC)}°C",
                    color = TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "${String.format("%.1f", node.network.telemetry.latencyMs)} ms lat",
                    color = TacticalBlue,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun NodeDetailDialog(node: ComputeNode, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = node.hostname, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text(text = "NODE ID: ${node.id} // ${node.location.region}", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextPrimary)
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("STATUS: ${node.status}", color = EmeraldOnline, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)

                Surface(color = CardSurface, shape = RoundedCornerShape(6.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("HARDWARE TELEMETRY", color = TacticalBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Spacer(Modifier.height(4.dp))
                        Text("CPU: ${node.hardware.cpu.model} (${node.hardware.cpu.cores} Cores @ ${String.format("%.1f", node.hardware.cpu.utilizationPercent)}%)", color = TextPrimary, fontSize = 11.sp)
                        node.hardware.gpu?.let { gpu ->
                            Text("GPU: ${gpu.model} (${gpu.vramGb} GB VRAM @ ${String.format("%.1f", gpu.utilizationPercent)}%)", color = TextPrimary, fontSize = 11.sp)
                        }
                        node.hardware.asic?.let { asic ->
                            Text("ASIC: ${asic.model} (${String.format("%.1f", asic.currentHashrateTHs)} TH/s SHA-256d)", color = BitcoinGold, fontSize = 11.sp)
                        }
                    }
                }

                Surface(color = CardSurface, shape = RoundedCornerShape(6.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("POWER & THERMAL", color = TacticalBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Spacer(Modifier.height(4.dp))
                        Text("Total Power: ${String.format("%.1f", node.power.totalWatts)} W (Cap: ${node.power.powerCapWatts} W)", color = TextPrimary, fontSize = 11.sp)
                        Text("CPU Temp: ${String.format("%.1f", node.thermal.cpuTempC)}°C | Cooling Fan: ${node.thermal.fanSpeedRpm} RPM", color = TextPrimary, fontSize = 11.sp)
                    }
                }

                Surface(color = CardSurface, shape = RoundedCornerShape(6.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("SATELLITE INTERNET LINK", color = TacticalBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Spacer(Modifier.height(4.dp))
                        Text("Ground Station: ${node.location.groundStation}", color = TextPrimary, fontSize = 11.sp)
                        Text("Bandwidth: ${String.format("%.1f", node.network.telemetry.downlinkMbps)} Mbps Down / ${String.format("%.1f", node.network.telemetry.uplinkMbps)} Mbps Up", color = TextPrimary, fontSize = 11.sp)
                        Text("Latency: ${String.format("%.1f", node.network.telemetry.latencyMs)} ms | Jitter: ${String.format("%.1f", node.network.telemetry.jitterMs)} ms", color = TextPrimary, fontSize = 11.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = TacticalBlue, contentColor = DeepNavyBg)
            ) {
                Text("CLOSE INSPECTION", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
    )
}
