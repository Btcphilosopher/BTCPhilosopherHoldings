package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepNavyBg = Color(0xFF0B132B)
val DarkSurface = Color(0xFF121824)
val CardSurface = Color(0xFF1C2541)
val SteelBorder = Color(0xFF3A506B)

val TextPrimary = Color(0xFFF8F9FA)
val TextMuted = Color(0xFF8D99AE)

val TacticalBlue = Color(0xFF00A8E8)
val BitcoinGold = Color(0xFFF7931A)
val EmeraldOnline = Color(0xFF06D6A0)
val AmberWarning = Color(0xFFF7B801)
val CrimsonCritical = Color(0xFFEF476F)
