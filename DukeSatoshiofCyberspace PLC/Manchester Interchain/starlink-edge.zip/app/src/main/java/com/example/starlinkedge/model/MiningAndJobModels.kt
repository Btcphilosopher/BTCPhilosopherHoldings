package com.example.starlinkedge.model

enum class WorkerStatus {
    INITIALIZING,
    RUNNING,
    THROTTLED,
    PAUSED,
    STOPPED,
    ERROR
}

data class Hashrate(
    val value: Double,
    val unit: String // "TH/s", "PH/s", "EH/s"
)

data class MiningWorker(
    val id: WorkerId,
    val nodeId: NodeId,
    val hardwareId: HardwareId,
    val algorithm: MiningAlgorithm = MiningAlgorithm.SHA256D,
    val hashrate: Hashrate,
    val powerWatts: Double,
    val temperatureC: Double,
    val status: WorkerStatus,
    val acceptedShares: Long,
    val rejectedShares: Long,
    val hardwareErrors: Long,
    val poolName: String
)

data class MiningPool(
    val id: String,
    val name: String,
    val endpoint: String,
    val feePercent: Double,
    val activeWorkersCount: Int,
    val totalHashratePHs: Double,
    val stratumDifficulty: Double
)

data class MiningStatus(
    val workerId: WorkerId,
    val nodeId: NodeId,
    val status: WorkerStatus,
    val algorithm: MiningAlgorithm,
    val instantaneousHashrateTHs: Double,
    val fiveMinHashrateTHs: Double,
    val oneHourHashrateTHs: Double,
    val twentyFourHourHashrateTHs: Double,
    val powerWatts: Double,
    val temperatureC: Double,
    val acceptedShares: Long,
    val rejectedShares: Long,
    val staleShareRatePercent: Double,
    val hashesPerJoule: Double,
    val joulesPerTerahash: Double
)

data class MiningJob(
    val jobId: String,
    val poolId: String,
    val blockHeight: Long,
    val difficulty: Double,
    val targetHex: String,
    val createdTimeMs: Long
)

data class MiningShare(
    val shareId: String,
    val workerId: WorkerId,
    val nodeId: NodeId,
    val nonceHex: String,
    val isAccepted: Boolean,
    val isStale: Boolean,
    val latencyMs: Double,
    val timestampMs: Long
)

data class MiningEconomics(
    val electricityTariffUsdPerKwh: Double,
    val bitcoinPriceUsd: Double,
    val totalPowerDrawMw: Double,
    val dailyEnergyKwh: Double,
    val dailyPowerCostUsd: Double,
    val modelledDailyBtcEarned: Double,
    val modelledDailyGrossRevenueUsd: Double,
    val modelledDailyGrossMarginUsd: Double,
    val marginPercent: Double
)

enum class JobStatus {
    QUEUED,
    SCHEDULED,
    STARTING,
    RUNNING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class ResourceRequirements(
    val cpuCores: Int,
    val ramGb: Int,
    val gpuCount: Int = 0,
    val vramGb: Int = 0,
    val storageGb: Double = 10.0,
    val maxLatencyMs: Double = 150.0,
    val minBandwidthMbps: Double = 50.0
)

data class RuntimeConfig(
    val image: String,
    val command: List<String> = emptyList(),
    val environment: Map<String, String> = emptyMap()
)

data class ComputeJob(
    val id: JobId,
    val title: String,
    val ownerId: OwnerId,
    val type: WorkloadType,
    val requirements: ResourceRequirements,
    val runtime: RuntimeConfig,
    val priority: Int = 1,
    val assignedNodeId: NodeId? = null,
    val status: JobStatus = JobStatus.QUEUED,
    val submittedAtMs: Long,
    val startedAtMs: Long? = null,
    val completedAtMs: Long? = null,
    val progressPercent: Double = 0.0,
    val executionOutput: String = ""
)

data class SchedulerDecision(
    val jobId: JobId,
    val selectedNodeId: NodeId?,
    val candidateNodesEvaluated: Int,
    val decisionReason: String,
    val scoreMap: Map<NodeId, Double>,
    val timestampMs: Long
)
