package com.example.starlinkedge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.starlinkedge.model.*
import com.example.ui.theme.*

@Composable
fun CloudComputeView(
    jobs: List<ComputeJob>,
    decisions: List<SchedulerDecision>,
    onSubmitJob: (ComputeJob) -> Unit
) {
    val scrollState = rememberScrollState()

    var showSubmitDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavyBg)
            .padding(16.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.Cloud, contentDescription = null, tint = TacticalBlue, modifier = Modifier.size(28.dp))
                Column {
                    Text(
                        text = "CLOUD COMPUTING & RESOURCE SCHEDULER",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "GPU / CPU / CONTAINER / AI INFERENCE WORKLOAD ENGINE",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Button(
                onClick = { showSubmitDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = TacticalBlue, contentColor = DeepNavyBg),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.testTag("submit_job_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("SUBMIT JOB", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }

        // Active Jobs List
        Surface(
            color = CardSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SteelBorder, RoundedCornerShape(10.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "ACTIVE & QUEUED COMPUTATION JOBS (${jobs.size} JOBS)",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(Modifier.height(10.dp))

                Box(modifier = Modifier.height(260.dp)) {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(jobs) { job ->
                            JobRowItem(job = job)
                        }
                    }
                }
            }
        }

        // Scheduler Decisions Log
        Surface(
            color = CardSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SteelBorder, RoundedCornerShape(10.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "SCHEDULER ALLOCATION LOGS",
                    color = TacticalBlue,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(Modifier.height(8.dp))

                if (decisions.isEmpty()) {
                    Text("No scheduler decisions logged yet.", color = TextMuted, fontSize = 11.sp)
                } else {
                    Box(modifier = Modifier.height(180.dp)) {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(decisions) { decision ->
                                Surface(
                                    color = DarkSurface,
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Text(
                                            text = "JOB: ${decision.jobId} -> ${decision.selectedNodeId ?: "UNASSIGNED"}",
                                            color = TextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = decision.decisionReason,
                                            color = TextMuted,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSubmitDialog) {
        SubmitJobDialog(
            onDismiss = { showSubmitDialog = false },
            onSubmit = { newJob ->
                onSubmitJob(newJob)
                showSubmitDialog = false
            }
        )
    }
}

@Composable
fun JobRowItem(job: ComputeJob) {
    val statusColor = when (job.status) {
        JobStatus.RUNNING -> EmeraldOnline
        JobStatus.SCHEDULED, JobStatus.STARTING -> TacticalBlue
        JobStatus.QUEUED -> AmberWarning
        JobStatus.COMPLETED -> EmeraldOnline
        else -> CrimsonCritical
    }

    Surface(
        color = DarkSurface,
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth().testTag("job_item_${job.id}")
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = job.id,
                        color = TacticalBlue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = job.title,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Text(
                    text = job.status.name,
                    color = statusColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Node: ${job.assignedNodeId ?: "Awaiting Node"} | Type: ${job.type}",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "${String.format("%.1f", job.progressPercent)}%",
                    color = TextPrimary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(Modifier.height(4.dp))

            LinearProgressIndicator(
                progress = { (job.progressPercent / 100.0).toFloat() },
                modifier = Modifier.fillMaxWidth().height(4.dp),
                color = statusColor,
                trackColor = CardSurface
            )
        }
    }
}

@Composable
fun SubmitJobDialog(
    onDismiss: () -> Unit,
    onSubmit: (ComputeJob) -> Unit
) {
    var title by remember { mutableStateOf("Distributed Llama-3 AI Inference") }
    var typeStr by remember { mutableStateOf("AI_INFERENCE") }
    var cpuCores by remember { mutableStateOf("16") }
    var ramGb by remember { mutableStateOf("32") }
    var gpuCount by remember { mutableStateOf("1") }
    var vramGb by remember { mutableStateOf("24") }
    var image by remember { mutableStateOf("ollama/ollama:latest") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text("SUBMIT NEW CLOUD COMPUTING WORKLOAD", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Job Title", color = TextMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )

                OutlinedTextField(
                    value = image,
                    onValueChange = { image = it },
                    label = { Text("Container Image", color = TextMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = cpuCores,
                        onValueChange = { cpuCores = it },
                        label = { Text("CPU Cores", color = TextMuted) },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = ramGb,
                        onValueChange = { ramGb = it },
                        label = { Text("RAM GB", color = TextMuted) },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = gpuCount,
                        onValueChange = { gpuCount = it },
                        label = { Text("GPUs", color = TextMuted) },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = vramGb,
                        onValueChange = { vramGb = it },
                        label = { Text("VRAM GB", color = TextMuted) },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val job = ComputeJob(
                        id = "job_${System.currentTimeMillis().toString().takeLast(6)}",
                        title = title,
                        ownerId = "console_user",
                        type = WorkloadType.AI_INFERENCE,
                        requirements = ResourceRequirements(
                            cpuCores = cpuCores.toIntOrNull() ?: 16,
                            ramGb = ramGb.toIntOrNull() ?: 32,
                            gpuCount = gpuCount.toIntOrNull() ?: 1,
                            vramGb = vramGb.toIntOrNull() ?: 24
                        ),
                        runtime = RuntimeConfig(image, listOf("serve")),
                        submittedAtMs = System.currentTimeMillis()
                    )
                    onSubmit(job)
                },
                colors = ButtonDefaults.buttonColors(containerColor = TacticalBlue, contentColor = DeepNavyBg)
            ) {
                Text("SUBMIT WORKLOAD", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = TextMuted, fontSize = 11.sp)
            }
        }
    )
}
