package com.example.mipg.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mipg.domain.model.PaymentIntentStatus
import com.example.mipg.ui.components.CodeBlockViewer
import com.example.mipg.ui.components.QrCodeView
import com.example.mipg.ui.components.StateBadge
import com.example.mipg.ui.viewmodel.MipgViewModel
import com.example.ui.theme.*

@Composable
fun CheckoutDemosScreen(viewModel: MipgViewModel) {
    var activeDemoTab by remember { mutableIntStateOf(0) }
    val activeQuote by viewModel.activeQuote.collectAsState()
    val intents by viewModel.paymentIntents.collectAsState()
    val events by viewModel.paymentEvents.collectAsState()

    val currentIntent = intents.firstOrNull()

    var walletConnected by remember { mutableStateOf(false) }
    var selectedWalletAsset by remember { mutableStateOf("USDC") }
    var paymentProgressStep by remember { mutableIntStateOf(0) } // 0: Idle, 1: Connected, 2: Signed, 3: Settled
    var showPayModal by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tab Header
        item {
            Column {
                Text(
                    text = "FLAGSHIP WEB3 DEMONSTRATIONS",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = AgedBrass,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "Interactive Institutional Web3 Checkout • Multi-Asset Auto-Settlement • Embeddable Pay Button",
                    fontSize = 11.sp,
                    color = WarmIvoryMuted
                )
            }
        }

        // Demo Selector Buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "1. MANCHESTER WEB3 CHECKOUT",
                    "2. GLOBAL MERCHANT",
                    "3. PAY BUTTON MODAL"
                ).forEachIndexed { idx, label ->
                    Button(
                        onClick = { activeDemoTab = idx },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (activeDemoTab == idx) BrickRedPrimary else CharcoalSurface,
                            contentColor = WarmIvoryText
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f).testTag("demo_tab_$idx")
                    ) {
                        Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }
        }

        // FLAGSHIP DEMO 1: MANCHESTER WEB3 CHECKOUT
        if (activeDemoTab == 0) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AgedBrass, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = "FLAGSHIP DEMO 1: MANCHESTER WEB3 CHECKOUT",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AgedBrass,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "Fictional Manchester Retailer • USDC (Ethereum) ➔ MCX Conversion ➔ sGBP (Manchester Chain)",
                                    fontSize = 10.sp,
                                    color = WarmIvoryMuted
                                )
                            }
                            if (currentIntent != null) StateBadge(currentIntent.status)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Step 1: Wallet Connection
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CharcoalDark),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, CharcoalBorder, RoundedCornerShape(6.dp))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "STEP 1: SELECT PAYMENT ASSET & CONNECT WEB3 WALLET",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SandstoneAccent
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    listOf("USDC", "ETH", "BTC", "sGBP", "USDT").forEach { asset ->
                                        FilterChip(
                                            selected = selectedWalletAsset == asset,
                                            onClick = {
                                                selectedWalletAsset = asset
                                                if (currentIntent != null) {
                                                    viewModel.requestQuoteForIntent(currentIntent, asset)
                                                }
                                            },
                                            label = { Text(asset, fontSize = 10.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = AgedBrass,
                                                selectedLabelColor = CharcoalDark
                                            )
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (walletConnected) Icons.Default.AccountBalanceWallet else Icons.Default.NoEncryption,
                                            contentDescription = null,
                                            tint = if (walletConnected) StatusSuccess else StatusWarning
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = if (walletConnected) "Wallet: 0x8A92...E110 (Ethereum Mainnet)" else "No Web3 Wallet Connected",
                                            fontSize = 11.sp,
                                            color = WarmIvoryText,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    Button(
                                        onClick = {
                                            walletConnected = !walletConnected
                                            if (walletConnected) paymentProgressStep = 1
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (walletConnected) StatusSuccess else AgedBrass,
                                            contentColor = CharcoalDark
                                        ),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.testTag("connect_wallet_btn")
                                    ) {
                                        Text(if (walletConnected) "CONNECTED" else "CONNECT WALLET", fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Step 2: Executable Quote & Interchain Route
                        if (activeQuote != null) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = CharcoalDark),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, CharcoalBorder, RoundedCornerShape(6.dp))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "STEP 2: EXECUTABLE MANCHESTER INTERCHAIN ROUTE & QUOTE",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SandstoneAccent
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Customer Pays: ${String.format("%.4f", activeQuote!!.inputAmount)} ${activeQuote!!.inputAsset} ➔ Merchant Receives: £${String.format("%.2f", activeQuote!!.outputAmount)} ${activeQuote!!.outputAsset}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = StatusSuccess
                                    )
                                    Text(
                                        text = "Route Hops: ${activeQuote!!.route.hops.size} hops • MCX Liquidity Pool Swap • Fee: £${String.format("%.2f", activeQuote!!.gatewayFee)}",
                                        fontSize = 10.sp,
                                        color = WarmIvoryMuted
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Step 3: Authorise & Execute Payment
                        Button(
                            onClick = {
                                if (currentIntent != null && activeQuote != null) {
                                    paymentProgressStep = 3
                                    viewModel.confirmAndSettlePayment(currentIntent, activeQuote!!)
                                }
                            },
                            enabled = walletConnected && currentIntent != null,
                            colors = ButtonDefaults.buttonColors(containerColor = BrickRedPrimary, contentColor = WarmIvoryText),
                            modifier = Modifier.fillMaxWidth().testTag("execute_web3_payment_btn"),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("AUTHORISE & SETTLE IN SGBP NATIVELY", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }

                        if (paymentProgressStep == 3 && currentIntent?.status == PaymentIntentStatus.SETTLED) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = StatusSuccessBg),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, StatusSuccess, RoundedCornerShape(6.dp))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusSuccess)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "SETTLEMENT COMPLETE & AUDITED",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = StatusSuccess
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Double-Entry Ledger Updated • Merchant Account Credited • Signed Webhook Dispatched (`payment.settled`)",
                                        fontSize = 10.sp,
                                        color = WarmIvoryText
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // FLAGSHIP DEMO 2: GLOBAL WEB3 MERCHANT AUTO-CONVERSION
        if (activeDemoTab == 1) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AgedBrass, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "FLAGSHIP DEMO 2: GLOBAL WEB3 MERCHANT AUTO-SETTLEMENT",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = AgedBrass,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Merchant configured to auto-settle ALL multi-chain assets directly into sGBP with 0 slippage.",
                            fontSize = 10.sp,
                            color = WarmIvoryMuted
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Multi-asset grid simulation
                        listOf(
                            Triple("BTC (Bitcoin)", "0.0182 BTC", "£1,250.00 sGBP"),
                            Triple("ETH (Ethereum)", "0.4401 ETH", "£1,250.00 sGBP"),
                            Triple("USDC (Arbitrum)", "1,592.35 USDC", "£1,250.00 sGBP"),
                            Triple("USDT (Tron)", "1,592.35 USDT", "£1,250.00 sGBP")
                        ).forEach { (rail, input, settled) ->
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(CharcoalDark, RoundedCornerShape(6.dp))
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Text(text = rail, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = WarmIvoryText)
                                    Text(text = "Input: $input", fontSize = 10.sp, color = SandstoneAccent)
                                }
                                Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = AgedBrass)
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "Auto-Settled", fontSize = 9.sp, color = StatusSuccess, fontWeight = FontWeight.Bold)
                                    Text(text = settled, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = WarmIvoryText)
                                }
                            }
                        }
                    }
                }
            }
        }

        // FLAGSHIP DEMO 3: MANCHESTER INTERCHAIN PAY BUTTON & MODAL
        if (activeDemoTab == 2) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AgedBrass, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "FLAGSHIP DEMO 3: EMBEDDABLE MANCHESTER PAY BUTTON",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = AgedBrass,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "A tiny JS/Kotlin snippet that external merchants drop into any app to trigger the MIPG Payment Modal.",
                            fontSize = 10.sp,
                            color = WarmIvoryMuted
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        CodeBlockViewer(
                            title = "JavaScript Embed Snippet",
                            code = """
<script src="https://js.manchester.ac.uk/v1/mipg.js"></script>
<button onclick="ManchesterPay.open({
  paymentIntentId: 'pi_mcr_8819',
  onSuccess: (res) => console.log('Settled:', res.txHash),
  onCancel: () => console.log('Cancelled')
})">Pay with Manchester Interchain</button>
                            """.trimIndent()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Interactive Pay Button preview
                        Button(
                            onClick = { showPayModal = true },
                            colors = ButtonDefaults.buttonColors(containerColor = BrickRedPrimary, contentColor = WarmIvoryText),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("trigger_pay_modal_btn")
                        ) {
                            Icon(Icons.Default.Payment, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("PAY £1,250.00 WITH MANCHESTER PAY", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }

    // Embeddable Pay Modal Dialog Simulation
    if (showPayModal) {
        AlertDialog(
            onDismissRequest = { showPayModal = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(BrickRedPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("M", color = WarmIvoryText, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("MANCHESTER INTERCHAIN PAY", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AgedBrass)
                }
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(text = "Merchant: Manchester Fine Goods Ltd", fontSize = 11.sp, color = WarmIvoryMuted)
                    Text(text = "Amount: £1,250.00 sGBP", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = SandstoneAccent)

                    QrCodeView(data = "mipg:pay?intent=pi_mcr_8819&amt=1250.00&curr=sGBP")

                    Text(text = "Scan with any Web3 Wallet or select a connected provider", fontSize = 10.sp, color = WarmIvoryMuted)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (currentIntent != null && activeQuote != null) {
                            viewModel.confirmAndSettlePayment(currentIntent, activeQuote!!)
                        }
                        showPayModal = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                    modifier = Modifier.testTag("modal_pay_now_btn")
                ) {
                    Text("AUTHORISE & PAY NOW", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPayModal = false }) {
                    Text("CANCEL", color = WarmIvoryMuted)
                }
            },
            containerColor = CharcoalSurface,
            textContentColor = WarmIvoryText
        )
    }
}
