package com.example.mipg.domain.model

import java.util.UUID

enum class PaymentIntentStatus {
    CREATED,
    QUOTED,
    PAYMENT_METHOD_SELECTED,
    AUTHORISED,
    PROCESSING,
    SOURCE_CONFIRMED,
    SETTLEMENT_PENDING,
    SETTLED,
    EXPIRED,
    CANCELLED,
    FAILED,
    REFUNDED,
    DISPUTED,
    MANUAL_REVIEW
}

enum class EnvironmentType {
    SIMULATED,
    SANDBOX,
    INTEGRATION_READY,
    LIVE
}

enum class RiskLevel {
    LOW,
    MEDIUM,
    HIGH,
    BLOCKED,
    MANUAL_REVIEW
}

enum class BalanceType {
    AVAILABLE,
    PENDING,
    RESERVED,
    IN_TRANSIT
}

data class PaymentIntent(
    val id: String = "pi_" + UUID.randomUUID().toString().take(12),
    val merchantId: String,
    val customerRef: String,
    val merchantRef: String,
    val amount: Double,
    val currency: String, // e.g. GBP, USD, EUR, USDC, BTC
    val acceptedPaymentMethods: List<String> = listOf("BTC", "ETH", "USDC", "USDT", "sGBP", "CARD"),
    val settlementDestination: String,
    val expiryTimestamp: Long = System.currentTimeMillis() + 900_000, // 15 mins default
    val status: PaymentIntentStatus = PaymentIntentStatus.CREATED,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val metadata: Map<String, String> = emptyMap(),
    val networkPreferences: List<String> = listOf("Ethereum", "ManchesterChain", "Bitcoin", "Arbitrum"),
    val web3Requirements: Web3Requirements = Web3Requirements()
)

data class Web3Requirements(
    val requireWalletConnection: Boolean = true,
    val minConfirmations: Int = 2,
    val allowGasless: Boolean = true,
    val requiredChainId: Long? = 1L
)

data class RouteHop(
    val hopIndex: Int,
    val sourceNetwork: String,
    val destinationNetwork: String,
    val inputAsset: String,
    val outputAsset: String,
    val protocol: String, // e.g., "Manchester Interchain Bridge", "MCX Liquidity Pool", "UniSwap V3"
    val feeAmount: Double,
    val estimatedTimeSeconds: Int,
    val liquidityProvider: String
)

data class PaymentRoute(
    val routeId: String = "rt_" + UUID.randomUUID().toString().take(10),
    val intentId: String,
    val hops: List<RouteHop>,
    val totalFee: Double,
    val netExchangeRate: Double,
    val estimatedTotalTimeSeconds: Int,
    val slippageAllowance: Double = 0.005, // 0.5%
    val finalityRequirement: String = "Probabilistic-2-Blocks",
    val riskState: RiskLevel = RiskLevel.LOW
)

data class PaymentQuote(
    val id: String = "qte_" + UUID.randomUUID().toString().take(10),
    val intentId: String,
    val inputAsset: String,
    val outputAsset: String,
    val inputAmount: Double,
    val outputAmount: Double,
    val exchangeRate: Double,
    val networkFee: Double,
    val gatewayFee: Double,
    val liquidityFee: Double,
    val spread: Double,
    val slippageAllowance: Double = 0.005,
    val expiryTimestamp: Long = System.currentTimeMillis() + 300_000, // 5 min quote lock
    val sourceNetwork: String,
    val destinationNetwork: String,
    val settlementEstimateSeconds: Int = 12,
    val isLocked: Boolean = true,
    val feePaidByCustomer: Boolean = true,
    val route: PaymentRoute
)

data class PaymentAttempt(
    val id: String = "att_" + UUID.randomUUID().toString().take(10),
    val intentId: String,
    val methodId: String,
    val status: PaymentIntentStatus,
    val txHash: String? = null,
    val network: String,
    val blockNumber: Long? = null,
    val confirmations: Int = 0,
    val gasUsed: Double = 0.0,
    val errorMessage: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class PaymentMethod(
    val id: String,
    val identifier: String, // e.g., "eth_usdc", "btc_native", "manchester_sgbp"
    val name: String,
    val network: String,
    val asset: String,
    val walletRequirements: String,
    val settlementMechanism: String,
    val confirmationPolicy: String,
    val supportedRegions: List<String> = listOf("Global", "UK", "EU", "US"),
    val minAmount: Double = 0.10,
    val maxAmount: Double = 1_000_000.0,
    val feeModel: String,
    val capabilities: List<String> = listOf("INSTANT_QUOTE", "REFUNDABLE", "SPLIT_PAYMENT", "SUBSCRIPTION")
)

data class CheckoutSession(
    val id: String = "cs_" + UUID.randomUUID().toString().take(12),
    val intentId: String,
    val merchantId: String,
    val checkoutUrl: String,
    val embedConfigJson: String,
    val acceptedAssets: List<String>,
    val acceptedNetworks: List<String>,
    val settlementCurrency: String,
    val customerPaysFees: Boolean = true,
    val autoConvert: Boolean = true,
    val status: String = "OPEN", // OPEN, COMPLETED, EXPIRED
    val createdAt: Long = System.currentTimeMillis()
)

data class Settlement(
    val id: String = "stl_" + UUID.randomUUID().toString().take(10),
    val intentId: String,
    val merchantId: String,
    val grossAmount: Double,
    val gatewayFee: Double,
    val netAmount: Double,
    val currency: String,
    val destinationAccount: String,
    val ledgerRef: String,
    val settledAt: Long = System.currentTimeMillis()
)

data class Refund(
    val id: String = "ref_" + UUID.randomUUID().toString().take(10),
    val originalPaymentId: String,
    val intentId: String,
    val amount: Double,
    val currency: String,
    val reason: String,
    val status: String = "COMPLETED",
    val createdAt: Long = System.currentTimeMillis(),
    val destination: String
)

data class Payout(
    val id: String = "po_" + UUID.randomUUID().toString().take(10),
    val merchantId: String,
    val amount: Double,
    val asset: String,
    val destination: String,
    val status: String = "SETTLED", // PENDING, IN_TRANSIT, SETTLED
    val balanceType: BalanceType = BalanceType.AVAILABLE,
    val scheduledAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = System.currentTimeMillis()
)

data class Merchant(
    val merchantId: String = "merch_mcr_001",
    val name: String = "Manchester Fine Goods Ltd",
    val settlementCurrencyPreference: String = "sGBP",
    val apiKey: String = "mipg_live_key_9876543210_mcr",
    val sandboxApiKey: String = "mipg_sandbox_key_1234567890_mcr",
    val webhookUrl: String = "https://merchant.example.com/api/webhooks/mipg",
    val webhookSecret: String = "whsec_mcr_prod_998877665544332211",
    val riskLevel: RiskLevel = RiskLevel.LOW,
    val availableBalanceGbp: Double = 142580.50,
    val pendingBalanceGbp: Double = 12450.00,
    val reservedBalanceGbp: Double = 5000.00
)

data class LedgerEntry(
    val entryId: String = "led_" + UUID.randomUUID().toString().take(10),
    val timestamp: Long = System.currentTimeMillis(),
    val debitAccount: String,
    val creditAccount: String,
    val amount: Double,
    val currency: String,
    val description: String,
    val refType: String, // PAYMENT_SETTLEMENT, GATEWAY_FEE, REFUND, PAYOUT
    val refId: String
)

data class PaymentEvent(
    val eventId: String = "evt_" + UUID.randomUUID().toString().take(12),
    val eventType: String, // e.g. payment.created, payment.quoted, payment.settled
    val paymentIntentId: String,
    val merchantId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val oldStatus: PaymentIntentStatus?,
    val newStatus: PaymentIntentStatus,
    val payloadJson: String,
    val signature: String
)

data class WebhookEndpoint(
    val id: String = "whe_" + UUID.randomUUID().toString().take(8),
    val merchantId: String,
    val url: String,
    val secret: String,
    val enabledEvents: List<String> = listOf("payment.created", "payment.settled", "payment.failed", "payout.completed"),
    val status: String = "ACTIVE"
)

data class WebhookDeliveryLog(
    val id: String = "whl_" + UUID.randomUUID().toString().take(10),
    val webhookId: String,
    val eventId: String,
    val eventType: String,
    val timestamp: Long = System.currentTimeMillis(),
    val statusCode: Int = 200,
    val responseBody: String = "{\"status\":\"accepted\"}",
    val retryCount: Int = 0,
    val status: String = "DELIVERED"
)

data class RiskEvaluation(
    val id: String = "risk_" + UUID.randomUUID().toString().take(8),
    val intentId: String,
    val score: Int, // 0 to 100
    val level: RiskLevel,
    val triggeredRules: List<String>,
    val evaluatedAt: Long = System.currentTimeMillis()
)

data class AgenticPolicy(
    val id: String = "pol_ag_" + UUID.randomUUID().toString().take(8),
    val agentName: String = "Manchester Autonomous Order Agent v1",
    val maxTxLimitGbp: Double = 500.0,
    val dailyLimitGbp: Double = 2500.0,
    val allowedMerchants: List<String> = listOf("merch_mcr_001", "merch_mcr_002"),
    val allowedAssets: List<String> = listOf("USDC", "USDT", "sGBP"),
    val requireHumanApprovalAboveGbp: Double = 250.0,
    val currentDailySpentGbp: Double = 120.0
)

data class AgenticPaymentRequest(
    val id: String = "agreq_" + UUID.randomUUID().toString().take(8),
    val agentId: String,
    val amount: Double,
    val currency: String,
    val merchantId: String,
    val purpose: String,
    val approvalStatus: String, // APPROVED_AUTOMATICALLY, PENDING_HUMAN_APPROVAL, REJECTED
    val intentId: String? = null
)

data class SplitAllocation(
    val recipientId: String,
    val recipientType: String, // MERCHANT, MARKETPLACE, CREATOR, PLATFORM_FEE, TAX_RESERVE
    val amount: Double,
    val currency: String,
    val percentage: Double
)

data class SubscriptionSchedule(
    val id: String = "sub_" + UUID.randomUUID().toString().take(8),
    val merchantId: String,
    val customerRef: String,
    val intervalDays: Int = 30,
    val amount: Double,
    val currency: String,
    val asset: String,
    val autoDebitMethod: String,
    val status: String = "ACTIVE",
    val nextBillingAt: Long = System.currentTimeMillis() + 30 * 86400_000L
)

data class ProviderPlugin(
    val providerId: String,
    val name: String,
    val version: String,
    val status: String, // ENABLED, SANDBOX_ONLY, DISABLED
    val environment: EnvironmentType,
    val capabilities: List<String>
)
