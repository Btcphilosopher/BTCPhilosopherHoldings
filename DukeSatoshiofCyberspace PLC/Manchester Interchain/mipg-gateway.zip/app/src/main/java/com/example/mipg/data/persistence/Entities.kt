package com.example.mipg.data.persistence

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "payment_intents")
data class PaymentIntentEntity(
    @PrimaryKey val id: String,
    val merchantId: String,
    val customerRef: String,
    val merchantRef: String,
    val amount: Double,
    val currency: String,
    val status: String,
    val acceptedPaymentMethods: String, // comma separated
    val settlementDestination: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "payment_events")
data class PaymentEventEntity(
    @PrimaryKey val eventId: String,
    val eventType: String,
    val paymentIntentId: String,
    val merchantId: String,
    val timestamp: Long,
    val oldStatus: String?,
    val newStatus: String,
    val payloadJson: String,
    val signature: String
)

@Entity(tableName = "ledger_entries")
data class LedgerEntryEntity(
    @PrimaryKey val entryId: String,
    val timestamp: Long,
    val debitAccount: String,
    val creditAccount: String,
    val amount: Double,
    val currency: String,
    val description: String,
    val refType: String,
    val refId: String
)

@Entity(tableName = "webhook_logs")
data class WebhookLogEntity(
    @PrimaryKey val id: String,
    val webhookId: String,
    val eventId: String,
    val eventType: String,
    val timestamp: Long,
    val statusCode: Int,
    val responseBody: String,
    val status: String
)

@Entity(tableName = "risk_audit_logs")
data class RiskAuditLogEntity(
    @PrimaryKey val id: String,
    val intentId: String,
    val score: Int,
    val level: String,
    val rulesTriggered: String,
    val timestamp: Long
)
