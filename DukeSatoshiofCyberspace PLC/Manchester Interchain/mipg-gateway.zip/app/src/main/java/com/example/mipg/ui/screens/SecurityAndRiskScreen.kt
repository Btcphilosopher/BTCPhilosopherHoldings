package com.example.mipg.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mipg.ui.components.CodeBlockViewer
import com.example.mipg.ui.viewmodel.MipgViewModel
import com.example.ui.theme.*

@Composable
fun SecurityAndRiskScreen(viewModel: MipgViewModel) {
    val agenticPolicy by viewModel.agenticPolicy.collectAsState()
    val agenticLog by viewModel.agenticRequestLog.collectAsState()

    var agentAmountInput by remember { mutableStateOf("150.00") }
    var agentPurposeInput by remember { mutableStateOf("Autonomous Manchester Server Hosting Subscription") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "SECURITY, RISK & AGENTIC PAYMENTS",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = AgedBrass,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "Transaction Risk Engine • Autonomous Agentic Payment Rules • Provider Plugin SDK Manifest",
                    fontSize = 11.sp,
                    color = WarmIvoryMuted
                )
            }
        }

        // AGENTIC PAYMENTS ENGINE SECTION
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BrickRedPrimary, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.SmartToy, contentDescription = null, tint = AgedBrass)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AUTONOMOUS AGENTIC PAYMENTS ENGINE",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = WarmIvoryText,
                                letterSpacing = 1.sp
                            )
                        }
                        Text(
                            text = "FUTURE-READY",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = AgedBrass
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Agent: ${agenticPolicy.agentName}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SandstoneAccent
                    )
                    Text(
                        text = "Max Single Tx: £${agenticPolicy.maxTxLimitGbp} • Daily Limit: £${agenticPolicy.dailyLimitGbp} (Spent: £${agenticPolicy.currentDailySpentGbp}) • Human Approval Required Above: £${agenticPolicy.requireHumanApprovalAboveGbp}",
                        fontSize = 10.sp,
                        color = WarmIvoryMuted
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = agentAmountInput,
                        onValueChange = { agentAmountInput = it },
                        label = { Text("Agent Payment Request Amount (£)") },
                        modifier = Modifier.fillMaxWidth().testTag("agent_amount_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = agentPurposeInput,
                        onValueChange = { agentPurposeInput = it },
                        label = { Text("Agent Purpose / Mandate") },
                        modifier = Modifier.fillMaxWidth().testTag("agent_purpose_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            val amt = agentAmountInput.toDoubleOrNull() ?: 150.0
                            viewModel.simulateAgenticPayment(amt, "sGBP", agentPurposeInput)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrickRedPrimary, contentColor = WarmIvoryText),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().testTag("submit_agentic_request_btn")
                    ) {
                        Text("SIMULATE AUTONOMOUS AGENT PAYMENT REQUEST", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }

                    if (agenticLog.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "AGENTIC EVALUATION LOG", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AgedBrass)
                        Spacer(modifier = Modifier.height(4.dp))
                        agenticLog.forEach { (req, msg) ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = CharcoalDark),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(text = "Request ID: ${req.id}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = WarmIvoryText)
                                        Text(
                                            text = req.approvalStatus,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (req.approvalStatus == "APPROVED_AUTOMATICALLY") StatusSuccess else StatusWarning
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(text = msg, fontSize = 10.sp, color = WarmIvoryMuted)
                                }
                            }
                        }
                    }
                }
            }
        }

        // PROVIDER PLUGIN SDK CAPABILITY MANIFEST
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CharcoalBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "PROVIDER PLUGIN SDK CAPABILITY REGISTRY",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = WarmIvoryText,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    CodeBlockViewer(
                        title = "REGISTERED PLUGIN: ManchesterDemoRailProvider",
                        code = """
Plugin ID: plugin_mcr_demo_rail
Version: 2.1.0-K2
Environment: INTEGRATION_READY
Capabilities:
  - INSTANT_QUOTE
  - MULTI_HOP_INTERCHAIN
  - DOUBLE_ENTRY_SETTLEMENT
  - REFUNDABLE
  - REPLAY_TEST_CONFORMANCE_PASS
                        """.trimIndent()
                    )
                }
            }
        }
    }
}
