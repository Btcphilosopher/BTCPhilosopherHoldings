package com.example.mipg.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mipg.ui.components.CodeBlockViewer
import com.example.mipg.ui.viewmodel.MipgViewModel
import com.example.ui.theme.*

@Composable
fun DeveloperPortalScreen(viewModel: MipgViewModel) {
    val merchant by viewModel.currentMerchant.collectAsState()
    val sdkLang by viewModel.sdkLanguage.collectAsState()
    val webhookLogs by viewModel.webhookLogs.collectAsState()
    val replayOutput by viewModel.replayOutput.collectAsState()
    val faucetBalances by viewModel.faucetBalance.collectAsState()

    var activeDevTab by remember { mutableIntStateOf(0) } // 0: API Keys, 1: SDK Generator, 2: Webhooks, 3: Faucet

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "MERCHANT DEVELOPER PLATFORM",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = AgedBrass,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "Scoped API Keys • Multi-Language SDKs • HMAC Webhooks • Payment Replay Engine • Faucet",
                    fontSize = 11.sp,
                    color = WarmIvoryMuted
                )
            }
        }

        // Dev Sub-tabs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("1. API KEYS", "2. SDK CODEGEN", "3. WEBHOOKS & REPLAY", "4. FAUCET").forEachIndexed { idx, label ->
                    Button(
                        onClick = { activeDevTab = idx },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (activeDevTab == idx) BrickRedPrimary else CharcoalSurface,
                            contentColor = WarmIvoryText
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f).testTag("dev_tab_$idx")
                    ) {
                        Text(label, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // TAB 0: API KEYS & SCOPED CREDENTIALS
        if (activeDevTab == 0) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CharcoalBorder, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "AUTHENTICATION & SCOPED API KEYS",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = AgedBrass,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        CodeBlockViewer(
                            title = "SANDBOX API KEY",
                            code = merchant.sandboxApiKey
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        CodeBlockViewer(
                            title = "LIVE PRODUCTION API KEY",
                            code = merchant.apiKey
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "ACTIVE PERMISSION SCOPES",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = SandstoneAccent
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        val scopes = listOf(
                            "payments:create" to "Create payment intents & request quotes",
                            "payments:read" to "Read authoritative payment state machine",
                            "refunds:create" to "Trigger full and partial payment refunds",
                            "payouts:create" to "Initiate treasury settlement payouts",
                            "balances:read" to "Access double-entry ledger balances",
                            "webhooks:manage" to "Register and replay webhook endpoints"
                        )

                        scopes.forEach { (scope, desc) ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp)
                                    .background(CharcoalDark, RoundedCornerShape(4.dp))
                                    .padding(8.dp)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = StatusSuccess, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = scope, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = WarmIvoryText, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = "— $desc", fontSize = 9.sp, color = WarmIvoryMuted)
                            }
                        }
                    }
                }
            }
        }

        // TAB 1: SDK CODE GENERATOR
        if (activeDevTab == 1) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CharcoalBorder, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "CANONICAL SDK CODE GENERATOR",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = AgedBrass,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("KOTLIN", "TYPESCRIPT", "PYTHON", "RUST").forEach { lang ->
                                FilterChip(
                                    selected = sdkLang == lang,
                                    onClick = { viewModel.setSdkLanguage(lang) },
                                    label = { Text(lang, fontSize = 10.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AgedBrass,
                                        selectedLabelColor = CharcoalDark
                                    ),
                                    modifier = Modifier.testTag("sdk_lang_$lang")
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        val snippet = when (sdkLang) {
                            "TYPESCRIPT" -> """
import { MipgClient } from '@manchester/mipg-sdk';

const mipg = new MipgClient({ apiKey: 'mipg_live_key_9876543210_mcr' });

const intent = await mipg.paymentIntents.create({
  amount: 1250.00,
  currency: 'sGBP',
  acceptedMethods: ['USDC', 'BTC', 'ETH'],
  settlementDestination: '0x8A92...E110'
});

const quote = await mipg.quotes.get(intent.id, 'USDC');
console.log('Interchain Route Hops:', quote.route.hops);
                            """.trimIndent()

                            "PYTHON" -> """
from mipg import MipgClient

client = MipgClient(api_key="mipg_live_key_9876543210_mcr")

intent = client.payment_intents.create(
    amount=1250.00,
    currency="sGBP",
    accepted_methods=["USDC", "BTC", "ETH"]
)

quote = client.quotes.get(intent.id, method="USDC")
print(f"Locked Rate: {quote.exchange_rate}")
                            """.trimIndent()

                            "RUST" -> """
use mipg_sdk::MipgClient;

let client = MipgClient::new("mipg_live_key_9876543210_mcr");

let intent = client.payment_intents().create(1250.0, "sGBP").await?;
let quote = client.quotes().get_executable_quote(&intent.id, "USDC").await?;

println!("Settlement Estimate: {}s", quote.settlement_estimate_seconds);
                            """.trimIndent()

                            else -> """
val client = MipgClient(apiKey = "mipg_live_key_9876543210_mcr")

val intent = client.paymentIntents.create(
    amount = 1250.00,
    currency = "sGBP",
    acceptedMethods = listOf("USDC", "BTC", "ETH")
)

val quote = client.quotes.getExecutableQuote(intent.id, "USDC")
println("Route: ${'$'}{quote.route.hops.size} hops")
                            """.trimIndent()
                        }

                        CodeBlockViewer(
                            title = "OFFICIAL $sdkLang SDK IMPLEMENTATION",
                            code = snippet
                        )
                    }
                }
            }
        }

        // TAB 2: WEBHOOKS & EVENT REPLAY ENGINE
        if (activeDevTab == 2) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CharcoalBorder, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "HMAC SIGNED WEBHOOK LOGS & REPLAY ENGINE",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = AgedBrass,
                                letterSpacing = 1.sp
                            )
                            Button(
                                onClick = { viewModel.runReplayEngine() },
                                colors = ButtonDefaults.buttonColors(containerColor = BrickRedPrimary, contentColor = WarmIvoryText),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.testTag("run_replay_btn")
                            ) {
                                Text("REPLAY EVENTS", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        if (replayOutput.isNotEmpty()) {
                            Text(
                                text = "REPLAY EXECUTION OUTPUT",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = StatusSuccess
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            replayOutput.forEach { line ->
                                Text(
                                    text = line,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = WarmIvoryText
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                        }

                        webhookLogs.take(5).forEach { log ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                                    .background(CharcoalDark, RoundedCornerShape(4.dp))
                                    .padding(10.dp)
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(text = log.eventType, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SandstoneAccent)
                                    Text(text = "HTTP ${log.statusCode}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = StatusSuccess)
                                }
                                Text(text = "Response: ${log.responseBody}", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = WarmIvoryMuted)
                            }
                        }
                    }
                }
            }
        }

        // TAB 3: SANDBOX FAUCET
        if (activeDevTab == 3) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CharcoalBorder, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "SYNTHETIC SANDBOX FAUCET",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = AgedBrass,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Mint synthetic test balances to test multi-chain interchain settlement flows.",
                            fontSize = 10.sp,
                            color = WarmIvoryMuted
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        faucetBalances.forEach { (asset, bal) ->
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(CharcoalDark, RoundedCornerShape(6.dp))
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Text(text = asset, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = WarmIvoryText)
                                    Text(text = "Balance: $bal $asset", fontSize = 10.sp, color = SandstoneAccent)
                                }
                                Button(
                                    onClick = { viewModel.faucetMint(asset, 500.0) },
                                    colors = ButtonDefaults.buttonColors(containerColor = AgedBrass, contentColor = CharcoalDark),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.testTag("faucet_mint_$asset")
                                ) {
                                    Text("+ MINT 500 $asset", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
