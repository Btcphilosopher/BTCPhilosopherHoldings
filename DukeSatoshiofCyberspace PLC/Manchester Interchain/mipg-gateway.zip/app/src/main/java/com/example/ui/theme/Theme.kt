package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PrestigeDarkColorScheme = darkColorScheme(
    primary = BrickRedPrimary,
    onPrimary = WarmIvoryText,
    primaryContainer = BrickRedDark,
    onPrimaryContainer = SandstoneLight,
    secondary = AgedBrass,
    onSecondary = CharcoalDark,
    secondaryContainer = AgedBrassDark,
    onSecondaryContainer = SandstoneLight,
    tertiary = SandstoneAccent,
    onTertiary = CharcoalDark,
    background = CharcoalDark,
    onBackground = WarmIvoryText,
    surface = CharcoalSurface,
    onSurface = WarmIvoryText,
    surfaceVariant = CharcoalCard,
    onSurfaceVariant = WarmIvoryMuted,
    outline = CharcoalBorder,
    outlineVariant = RestrainedSteel,
    error = StatusError,
    onError = WarmIvoryText
)

private val PrestigeLightColorScheme = lightColorScheme(
    primary = BrickRedPrimary,
    onPrimary = WarmIvoryText,
    primaryContainer = Color(0xFFF7E8E6),
    onPrimaryContainer = BrickRedDark,
    secondary = AgedBrassDark,
    onSecondary = WarmIvoryText,
    secondaryContainer = Color(0xFFF5EEDC),
    onSecondaryContainer = CharcoalDark,
    tertiary = BrickRedDark,
    onTertiary = WarmIvoryText,
    background = WarmIvoryText,
    onBackground = CharcoalDark,
    surface = Color(0xFFF2EFE9),
    onSurface = CharcoalDark,
    surfaceVariant = Color(0xFFE8E4DC),
    onSurfaceVariant = CharcoalDark,
    outline = Color(0xFFC0B8AD),
    outlineVariant = SteelLight,
    error = StatusError,
    onError = WarmIvoryText
)

@Composable
fun MIPGTheme(
    darkTheme: Boolean = true, // Default to dark Prestige Manchester institutional aesthetic
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) PrestigeDarkColorScheme else PrestigeLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
