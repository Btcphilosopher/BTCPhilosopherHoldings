package com.example.mipg.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mipg.ui.components.MetricCard
import com.example.mipg.ui.components.StateBadge
import com.example.mipg.ui.viewmodel.MipgViewModel
import com.example.ui.theme.*

@Composable
fun DashboardScreen(
    viewModel: MipgViewModel,
    onNavigateToIntents: () -> Unit,
    onNavigateToCheckout: () -> Unit
) {
    val intents by viewModel.paymentIntents.collectAsState()
    val events by viewModel.paymentEvents.collectAsState()
    val merchant by viewModel.currentMerchant.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome institutional banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BrickRedDark),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AgedBrass, RoundedCornerShape(8.dp))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = merchant.name.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AgedBrass,
                            letterSpacing = 1.2.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Institutional Web3 Payment Rail Gateway",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = WarmIvoryText,
                            fontFamily = FontFamily.Serif
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Connected to Manchester Interchain • MCX Liquidity Engine • 1-API Multi-Chain Settlement",
                            fontSize = 11.sp,
                            color = WarmIvoryMuted
                        )
                    }
                    Button(
                        onClick = onNavigateToCheckout,
                        colors = ButtonDefaults.buttonColors(containerColor = AgedBrass, contentColor = CharcoalDark),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("launch_web3_checkout_btn")
                    ) {
                        Text("LAUNCH DEMO", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }

        // Metrics Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    MetricCard(
                        title = "Available Balance",
                        value = "£${String.format("%,.2f", merchant.availableBalanceGbp)}",
                        subtitle = "+£12,450.00 pending settlement",
                        icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = AgedBrass) },
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Settlement Success Rate",
                        value = "99.85%",
                        subtitle = "Avg latency 2.4s across chains",
                        icon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusSuccess) },
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    MetricCard(
                        title = "Active Payment Intents",
                        value = "${intents.size}",
                        subtitle = "${intents.count { it.status.name == "SETTLED" }} settled natively",
                        icon = { Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = SandstoneAccent) },
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Interchain Rails Active",
                        value = "6 Rails",
                        subtitle = "BTC, ETH, USDC, USDT, sGBP, sCBDC",
                        icon = { Icon(Icons.Default.Hub, contentDescription = null, tint = BrickRedLight) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Active Intents Table Section
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CharcoalBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.FormatListBulleted, contentDescription = null, tint = AgedBrass)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "RECENT PAYMENT INTENTS",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = WarmIvoryText,
                                letterSpacing = 1.sp
                            )
                        }
                        TextButton(onClick = onNavigateToIntents) {
                            Text("VIEW ALL INTENTS", fontSize = 11.sp, color = AgedBrass, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (intents.isEmpty()) {
                        Text(text = "No payment intents recorded yet.", fontSize = 12.sp, color = WarmIvoryMuted)
                    } else {
                        intents.take(4).forEach { intent ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                                    .background(CharcoalDark, RoundedCornerShape(6.dp))
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Text(
                                        text = intent.id,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = WarmIvoryText,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "Customer Ref: ${intent.customerRef} • ${intent.acceptedPaymentMethods.joinToString("/")}",
                                        fontSize = 10.sp,
                                        color = WarmIvoryMuted
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "£${String.format("%.2f", intent.amount)} ${intent.currency}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SandstoneAccent
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    StateBadge(intent.status)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Live WebSocket / Event Stream Feed
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CharcoalBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(StatusSuccess)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "REAL-TIME WEBSOCKET STREAM",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = WarmIvoryText,
                                letterSpacing = 1.sp
                            )
                        }
                        Text(
                            text = "LIVE FEED",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = StatusSuccess
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (events.isEmpty()) {
                        Text(text = "Awaiting real-time payment lifecycle events...", fontSize = 12.sp, color = WarmIvoryMuted)
                    } else {
                        events.take(5).forEach { evt ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(CharcoalDark, RoundedCornerShape(4.dp))
                                    .padding(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = null,
                                    tint = AgedBrass,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = evt.eventType.uppercase(),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SandstoneAccent,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "Intent ${evt.paymentIntentId} -> ${evt.newStatus.name}",
                                        fontSize = 10.sp,
                                        color = WarmIvoryMuted
                                    )
                                }
                                Text(
                                    text = evt.signature.take(12) + "...",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = RestrainedSteel
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
