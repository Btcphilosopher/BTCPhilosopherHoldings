package com.example.mipg.domain.engine

import com.example.mipg.domain.model.*
import com.example.mipg.domain.provider.PaymentRailAdapter
import java.util.UUID

class PaymentRouter(private val adapters: List<PaymentRailAdapter>) {

    fun findBestAdapterForMethod(methodIdentifier: String): PaymentRailAdapter? {
        return adapters.find {
            it.supportedAsset.equals(methodIdentifier, ignoreCase = true) ||
                    it.providerId.equals(methodIdentifier, ignoreCase = true)
        } ?: adapters.firstOrNull()
    }

    suspend fun buildRouteAndQuote(
        intent: PaymentIntent,
        selectedMethodIdentifier: String
    ): PaymentQuote {
        val adapter = findBestAdapterForMethod(selectedMethodIdentifier)
            ?: throw IllegalStateException("No rail adapter found for method: $selectedMethodIdentifier")

        return adapter.quote(intent, intent.currency)
    }
}

class QuoteEngine {
    fun isQuoteExpired(quote: PaymentQuote): Boolean {
        return System.currentTimeMillis() > quote.expiryTimestamp
    }

    fun recalculateFeeForPayer(quote: PaymentQuote, customerPays: Boolean): PaymentQuote {
        return quote.copy(feePaidByCustomer = customerPays)
    }
}

class DoubleEntryLedger {
    private val entries = mutableListOf<LedgerEntry>()

    fun recordSettlement(
        intent: PaymentIntent,
        quote: PaymentQuote,
        merchant: Merchant
    ): List<LedgerEntry> {
        val timestamp = System.currentTimeMillis()
        val gross = quote.outputAmount
        val gatewayFee = quote.gatewayFee
        val net = gross - gatewayFee

        // Debit Customer Reference Account -> Credit Merchant Pending/Available Settlement Account
        val entry1 = LedgerEntry(
            timestamp = timestamp,
            debitAccount = "CUSTOMER_PAYMENT_IN_TRANSIT",
            creditAccount = "MERCHANT_SETTLEMENT_CLEARING",
            amount = gross,
            currency = quote.outputAsset,
            description = "Gross Payment Settlement for Intent ${intent.id}",
            refType = "PAYMENT_SETTLEMENT",
            refId = intent.id
        )

        // Debit Merchant Clearing -> Credit Gateway Revenue Account
        val entry2 = LedgerEntry(
            timestamp = timestamp,
            debitAccount = "MERCHANT_SETTLEMENT_CLEARING",
            creditAccount = "MIPG_GATEWAY_REVENUE",
            amount = gatewayFee,
            currency = quote.outputAsset,
            description = "MIPG Gateway Fee for Intent ${intent.id}",
            refType = "GATEWAY_FEE",
            refId = intent.id
        )

        // Debit Merchant Clearing -> Credit Merchant Available Balance
        val entry3 = LedgerEntry(
            timestamp = timestamp,
            debitAccount = "MERCHANT_SETTLEMENT_CLEARING",
            creditAccount = "MERCHANT_BALANCE_AVAILABLE_${merchant.merchantId}",
            amount = net,
            currency = quote.outputAsset,
            description = "Net Merchant Credit for Intent ${intent.id}",
            refType = "MERCHANT_CREDIT",
            refId = intent.id
        )

        entries.addAll(listOf(entry1, entry2, entry3))
        return listOf(entry1, entry2, entry3)
    }

    fun getAllEntries(): List<LedgerEntry> = entries.toList()

    fun verifyBalanceSheet(): Boolean {
        // Double-entry sanity check: Sum of debits equals sum of credits
        val totalDebits = entries.sumOf { it.amount }
        val totalCredits = entries.sumOf { it.amount }
        return totalDebits == totalCredits
    }
}

class WebhookEngine {
    fun generateEventSignature(eventId: String, secret: String): String {
        return "sha256=" + (eventId + secret).hashCode().toString().replace("-", "")
    }

    fun createWebhookLog(
        merchant: Merchant,
        event: PaymentEvent
    ): WebhookDeliveryLog {
        val sig = generateEventSignature(event.eventId, merchant.webhookSecret)
        return WebhookDeliveryLog(
            webhookId = "whe_" + merchant.merchantId,
            eventId = event.eventId,
            eventType = event.eventType,
            timestamp = System.currentTimeMillis(),
            statusCode = 200,
            responseBody = "{\"received\": true, \"event_id\": \"${event.eventId}\", \"signature\": \"$sig\"}",
            retryCount = 0,
            status = "DELIVERED"
        )
    }
}

class RiskEngine {
    fun evaluateIntent(intent: PaymentIntent): RiskEvaluation {
        val score = when {
            intent.amount > 100_000.0 -> 75
            intent.amount > 20_000.0 -> 45
            else -> 12
        }

        val level = when {
            score >= 80 -> RiskLevel.BLOCKED
            score >= 60 -> RiskLevel.HIGH
            score >= 35 -> RiskLevel.MEDIUM
            else -> RiskLevel.LOW
        }

        val rules = mutableListOf<String>()
        if (intent.amount > 20_000) rules.add("HIGH_VALUE_THRESHOLD_EXCEEDED")
        if (intent.web3Requirements.minConfirmations < 2) rules.add("LOW_CONFIRMATION_POLICY")
        if (rules.isEmpty()) rules.add("STANDARD_INTERCHAIN_COMPLIANCE_PASS")

        return RiskEvaluation(
            intentId = intent.id,
            score = score,
            level = level,
            triggeredRules = rules
        )
    }
}

class AgenticEngine {
    fun processAgentRequest(
        policy: AgenticPolicy,
        request: AgenticPaymentRequest
    ): Pair<AgenticPaymentRequest, String> {
        if (request.amount > policy.maxTxLimitGbp) {
            return request.copy(approvalStatus = "REJECTED") to "Transaction amount exceeds max single tx limit (${policy.maxTxLimitGbp} GBP)"
        }
        if (policy.currentDailySpentGbp + request.amount > policy.dailyLimitGbp) {
            return request.copy(approvalStatus = "REJECTED") to "Daily budget exhausted"
        }
        if (request.amount > policy.requireHumanApprovalAboveGbp) {
            return request.copy(approvalStatus = "PENDING_HUMAN_APPROVAL") to "Amount exceeds auto-approval threshold (${policy.requireHumanApprovalAboveGbp} GBP). Human principal authorisation required."
        }
        return request.copy(approvalStatus = "APPROVED_AUTOMATICALLY") to "Bounded agentic spending policy passed successfully."
    }
}

class ReplayEngine {
    fun replayEventHistory(events: List<PaymentEvent>): List<String> {
        return events.mapIndexed { idx, evt ->
            "Replay Step #${idx + 1}: Event ${evt.eventType} -> PaymentIntent ${evt.paymentIntentId} transitioned from ${evt.oldStatus ?: "NONE"} to ${evt.newStatus} at ${evt.timestamp}"
        }
    }
}
