package com.example.mipg.domain.provider

import com.example.mipg.domain.model.EnvironmentType
import com.example.mipg.domain.model.PaymentAttempt
import com.example.mipg.domain.model.PaymentIntent
import com.example.mipg.domain.model.PaymentQuote
import com.example.mipg.domain.model.Payout
import com.example.mipg.domain.model.Refund
import com.example.mipg.domain.model.Settlement

interface PaymentRailAdapter {
    val providerId: String
    val providerName: String
    val supportedAsset: String
    val nativeNetwork: String
    val environment: EnvironmentType

    suspend fun quote(intent: PaymentIntent, targetAsset: String): PaymentQuote
    suspend fun authorise(intent: PaymentIntent, quote: PaymentQuote, walletAddress: String?): PaymentAttempt
    suspend fun capture(attempt: PaymentAttempt): PaymentAttempt
    suspend fun cancel(intentId: String): Boolean
    suspend fun refund(intentId: String, amount: Double, reason: String): Refund
    suspend fun getStatus(attemptId: String): PaymentAttempt
    suspend fun verify(txHash: String): Boolean
    suspend fun settle(intent: PaymentIntent, quote: PaymentQuote): Settlement
    suspend fun payout(merchantId: String, amount: Double, asset: String, destination: String): Payout
}
