package com.example.mipg.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mipg.domain.model.PaymentIntent
import com.example.mipg.domain.model.PaymentIntentStatus
import com.example.mipg.ui.components.GraphRouteVisualizer
import com.example.mipg.ui.components.StateBadge
import com.example.mipg.ui.viewmodel.MipgViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IntentsAndRouterScreen(viewModel: MipgViewModel) {
    val intents by viewModel.paymentIntents.collectAsState()
    val activeQuote by viewModel.activeQuote.collectAsState()

    var showCreateDialog by remember { mutableStateOf(false) }
    var selectedIntentId by remember { mutableStateOf<String?>(null) }

    val selectedIntent = intents.find { it.id == selectedIntentId } ?: intents.firstOrNull()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Action Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PAYMENT INTENTS & ROUTER ENGINE",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = AgedBrass,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "Canonical Abstraction • Dynamic Graph Router • Executable Quotes",
                        fontSize = 11.sp,
                        color = WarmIvoryMuted
                    )
                }

                Button(
                    onClick = { showCreateDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = BrickRedPrimary, contentColor = WarmIvoryText),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("create_intent_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("NEW PAYMENT INTENT", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        // Selected Intent & Executable Quote Detail
        if (selectedIntent != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AgedBrass, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = "CANONICAL PAYMENT INTENT INSPECTOR",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SandstoneAccent,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = selectedIntent.id,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = WarmIvoryText,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            StateBadge(selectedIntent.status)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // State Machine Transition Line
                        Text(
                            text = "STATE MACHINE LIFECYCLE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = RestrainedSteel,
                            letterSpacing = 0.8.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CharcoalDark, RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val states = listOf(
                                PaymentIntentStatus.CREATED,
                                PaymentIntentStatus.QUOTED,
                                PaymentIntentStatus.PAYMENT_METHOD_SELECTED,
                                PaymentIntentStatus.AUTHORISED,
                                PaymentIntentStatus.PROCESSING,
                                PaymentIntentStatus.SETTLED
                            )
                            states.forEachIndexed { idx, st ->
                                val isActive = selectedIntent.status.ordinal >= st.ordinal
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .background(if (isActive) StatusSuccess else RestrainedSteel)
                                    )
                                    Text(
                                        text = st.name.take(3),
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isActive) WarmIvoryText else RestrainedSteel
                                    )
                                }
                                if (idx < states.size - 1) {
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(1.dp)
                                            .background(if (selectedIntent.status.ordinal > st.ordinal) StatusSuccess else RestrainedSteel)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Executable Quote Section
                        if (activeQuote != null) {
                            Text(
                                text = "DETERMINISTIC & EXECUTABLE QUOTE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = AgedBrass,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = CharcoalDark),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, CharcoalBorder, RoundedCornerShape(6.dp))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(text = "Quote ID: ${activeQuote!!.id}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = WarmIvoryText)
                                        Text(text = "LOCKED (300s)", fontSize = 10.sp, color = StatusSuccess, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column {
                                            Text(text = "CUSTOMER PAYS", fontSize = 9.sp, color = RestrainedSteel)
                                            Text(text = "${String.format("%.4f", activeQuote!!.inputAmount)} ${activeQuote!!.inputAsset}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SandstoneAccent)
                                        }
                                        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = AgedBrass)
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(text = "MERCHANT RECEIVES", fontSize = 9.sp, color = RestrainedSteel)
                                            Text(text = "£${String.format("%.2f", activeQuote!!.outputAmount)} ${activeQuote!!.outputAsset}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = StatusSuccess)
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Exchange Rate: 1 ${activeQuote!!.inputAsset} = ${activeQuote!!.exchangeRate} ${activeQuote!!.outputAsset} • Network Fee: £${String.format("%.2f", activeQuote!!.networkFee)} • Gateway Fee: £${String.format("%.2f", activeQuote!!.gatewayFee)}",
                                        fontSize = 10.sp,
                                        color = WarmIvoryMuted
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Executable Graph Route
                            GraphRouteVisualizer(route = activeQuote!!.route)

                            Spacer(modifier = Modifier.height(16.dp))

                            // Settle or Refund Controls
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (selectedIntent.status != PaymentIntentStatus.SETTLED && selectedIntent.status != PaymentIntentStatus.REFUNDED) {
                                    Button(
                                        onClick = {
                                            viewModel.confirmAndSettlePayment(selectedIntent, activeQuote!!)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess, contentColor = WarmIvoryText),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("confirm_settle_btn"),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("CONFIRM & SETTLE", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                } else if (selectedIntent.status == PaymentIntentStatus.SETTLED) {
                                    Button(
                                        onClick = {
                                            viewModel.triggerRefund(selectedIntent.id, selectedIntent.amount, "Merchant requested customer refund")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = BrickRedDark, contentColor = WarmIvoryText),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("refund_btn"),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("TRIGGER FULL REFUND", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Intent History List
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CharcoalBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "CANONICAL PAYMENT INTENT REGISTRY",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = WarmIvoryText,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    intents.forEach { intent ->
                        Card(
                            onClick = {
                                selectedIntentId = intent.id
                                viewModel.requestQuoteForIntent(intent, intent.acceptedPaymentMethods.firstOrNull() ?: "USDC")
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = if (intent.id == selectedIntent?.id) BrickRedDark else CharcoalDark
                            ),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .border(1.dp, if (intent.id == selectedIntent?.id) AgedBrass else CharcoalBorder, RoundedCornerShape(6.dp))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = intent.id,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = WarmIvoryText
                                    )
                                    Text(
                                        text = "Ref: ${intent.merchantRef} • Accepted: ${intent.acceptedPaymentMethods.joinToString(",")}",
                                        fontSize = 10.sp,
                                        color = WarmIvoryMuted
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "£${String.format("%.2f", intent.amount)} ${intent.currency}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SandstoneAccent
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    StateBadge(intent.status)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Dialog to Create Payment Intent
    if (showCreateDialog) {
        var inputAmount by remember { mutableStateOf("500.00") }
        var inputCustomerRef by remember { mutableStateOf("cust_mcr_992") }
        var selectedMethod by remember { mutableStateOf("USDC") }

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = {
                Text(
                    text = "CREATE PAYMENT INTENT",
                    fontWeight = FontWeight.Bold,
                    color = AgedBrass,
                    fontSize = 14.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = inputAmount,
                        onValueChange = { inputAmount = it },
                        label = { Text("Amount (GBP)") },
                        modifier = Modifier.fillMaxWidth().testTag("intent_amount_input")
                    )
                    OutlinedTextField(
                        value = inputCustomerRef,
                        onValueChange = { inputCustomerRef = it },
                        label = { Text("Customer Reference") },
                        modifier = Modifier.fillMaxWidth().testTag("intent_customer_ref_input")
                    )
                    Text("Select Primary Payment Method Rail:", fontSize = 11.sp, color = WarmIvoryMuted)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("USDC", "BTC", "ETH", "sGBP", "MNCH").forEach { method ->
                            FilterChip(
                                selected = selectedMethod == method,
                                onClick = { selectedMethod = method },
                                label = { Text(method, fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AgedBrass,
                                    selectedLabelColor = CharcoalDark
                                )
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = inputAmount.toDoubleOrNull() ?: 500.0
                        viewModel.createPaymentIntent(amt, "sGBP", inputCustomerRef, selectedMethod)
                        showCreateDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrickRedPrimary),
                    modifier = Modifier.testTag("submit_create_intent_btn")
                ) {
                    Text("CREATE INTENT & ROUTE", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("CANCEL", color = WarmIvoryMuted)
                }
            },
            containerColor = CharcoalSurface,
            textContentColor = WarmIvoryText
        )
    }
}
