package com.example.mipg.data.repository

import com.example.mipg.data.persistence.*
import com.example.mipg.domain.engine.*
import com.example.mipg.domain.model.*
import com.example.mipg.domain.provider.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class MipgRepository(private val dao: MipgDao) {

    val railAdapters: List<PaymentRailAdapter> = listOf(
        SyntheticGbpAdapter(),
        UsdcRailAdapter(),
        BitcoinRailAdapter(),
        EthereumRailAdapter(),
        ManchesterDemoRailProvider()
    )

    val router = PaymentRouter(railAdapters)
    val quoteEngine = QuoteEngine()
    val ledger = DoubleEntryLedger()
    val webhookEngine = WebhookEngine()
    val riskEngine = RiskEngine()
    val agenticEngine = AgenticEngine()
    val replayEngine = ReplayEngine()

    val paymentIntentsFlow: Flow<List<PaymentIntent>> = dao.getAllPaymentIntents().map { list ->
        list.map { e ->
            PaymentIntent(
                id = e.id,
                merchantId = e.merchantId,
                customerRef = e.customerRef,
                merchantRef = e.merchantRef,
                amount = e.amount,
                currency = e.currency,
                status = try { PaymentIntentStatus.valueOf(e.status) } catch (x: Exception) { PaymentIntentStatus.CREATED },
                acceptedPaymentMethods = e.acceptedPaymentMethods.split(","),
                settlementDestination = e.settlementDestination,
                createdAt = e.createdAt,
                updatedAt = e.updatedAt
            )
        }
    }

    val paymentEventsFlow: Flow<List<PaymentEvent>> = dao.getAllPaymentEvents().map { list ->
        list.map { e ->
            PaymentEvent(
                eventId = e.eventId,
                eventType = e.eventType,
                paymentIntentId = e.paymentIntentId,
                merchantId = e.merchantId,
                timestamp = e.timestamp,
                oldStatus = e.oldStatus?.let { try { PaymentIntentStatus.valueOf(it) } catch (x: Exception) { null } },
                newStatus = try { PaymentIntentStatus.valueOf(e.newStatus) } catch (x: Exception) { PaymentIntentStatus.CREATED },
                payloadJson = e.payloadJson,
                signature = e.signature
            )
        }
    }

    val ledgerEntriesFlow: Flow<List<LedgerEntry>> = dao.getAllLedgerEntries().map { list ->
        list.map { e ->
            LedgerEntry(
                entryId = e.entryId,
                timestamp = e.timestamp,
                debitAccount = e.debitAccount,
                creditAccount = e.creditAccount,
                amount = e.amount,
                currency = e.currency,
                description = e.description,
                refType = e.refType,
                refId = e.refId
            )
        }
    }

    val webhookLogsFlow: Flow<List<WebhookDeliveryLog>> = dao.getAllWebhookLogs().map { list ->
        list.map { e ->
            WebhookDeliveryLog(
                id = e.id,
                webhookId = e.webhookId,
                eventId = e.eventId,
                eventType = e.eventType,
                timestamp = e.timestamp,
                statusCode = e.statusCode,
                responseBody = e.responseBody,
                status = e.status
            )
        }
    }

    suspend fun saveIntent(intent: PaymentIntent) {
        val entity = PaymentIntentEntity(
            id = intent.id,
            merchantId = intent.merchantId,
            customerRef = intent.customerRef,
            merchantRef = intent.merchantRef,
            amount = intent.amount,
            currency = intent.currency,
            status = intent.status.name,
            acceptedPaymentMethods = intent.acceptedPaymentMethods.joinToString(","),
            settlementDestination = intent.settlementDestination,
            createdAt = intent.createdAt,
            updatedAt = intent.updatedAt
        )
        dao.insertPaymentIntent(entity)
        recordEvent(
            eventType = "payment.created",
            intentId = intent.id,
            merchantId = intent.merchantId,
            oldStatus = null,
            newStatus = intent.status,
            payload = "{\"intentId\": \"${intent.id}\", \"amount\": ${intent.amount}, \"currency\": \"${intent.currency}\"}"
        )
    }

    suspend fun updateIntentStatus(intentId: String, merchantId: String, oldStatus: PaymentIntentStatus?, newStatus: PaymentIntentStatus) {
        dao.updatePaymentIntentStatus(intentId, newStatus.name)
        recordEvent(
            eventType = "payment.${newStatus.name.lowercase()}",
            intentId = intentId,
            merchantId = merchantId,
            oldStatus = oldStatus,
            newStatus = newStatus,
            payload = "{\"intentId\": \"$intentId\", \"status\": \"${newStatus.name}\"}"
        )
    }

    private suspend fun recordEvent(
        eventType: String,
        intentId: String,
        merchantId: String,
        oldStatus: PaymentIntentStatus?,
        newStatus: PaymentIntentStatus,
        payload: String
    ) {
        val evtId = "evt_" + UUID.randomUUID().toString().take(12)
        val sig = "sha256_sig_" + (evtId + merchantId).hashCode().toString().replace("-", "")
        val evt = PaymentEventEntity(
            eventId = evtId,
            eventType = eventType,
            paymentIntentId = intentId,
            merchantId = merchantId,
            timestamp = System.currentTimeMillis(),
            oldStatus = oldStatus?.name,
            newStatus = newStatus.name,
            payloadJson = payload,
            signature = sig
        )
        dao.insertPaymentEvent(evt)

        // Webhook delivery simulation
        val whLog = WebhookLogEntity(
            id = "whl_" + UUID.randomUUID().toString().take(10),
            webhookId = "whe_$merchantId",
            eventId = evtId,
            eventType = eventType,
            timestamp = System.currentTimeMillis(),
            statusCode = 200,
            responseBody = "{\"status\":\"accepted\",\"signature\":\"$sig\"}",
            status = "DELIVERED"
        )
        dao.insertWebhookLog(whLog)
    }

    suspend fun recordLedgerEntries(entries: List<LedgerEntry>) {
        entries.forEach { e ->
            dao.insertLedgerEntry(
                LedgerEntryEntity(
                    entryId = e.entryId,
                    timestamp = e.timestamp,
                    debitAccount = e.debitAccount,
                    creditAccount = e.creditAccount,
                    amount = e.amount,
                    currency = e.currency,
                    description = e.description,
                    refType = e.refType,
                    refId = e.refId
                )
            )
        }
    }

    suspend fun recordRiskEvaluation(eval: RiskEvaluation) {
        dao.insertRiskLog(
            RiskAuditLogEntity(
                id = eval.id,
                intentId = eval.intentId,
                score = eval.score,
                level = eval.level.name,
                rulesTriggered = eval.triggeredRules.joinToString(","),
                timestamp = eval.evaluatedAt
            )
        )
    }
}
