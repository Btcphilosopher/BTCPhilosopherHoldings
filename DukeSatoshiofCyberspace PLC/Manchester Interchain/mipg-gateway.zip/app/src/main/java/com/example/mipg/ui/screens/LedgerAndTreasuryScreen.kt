package com.example.mipg.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mipg.domain.model.SplitAllocation
import com.example.mipg.ui.components.MetricCard
import com.example.mipg.ui.viewmodel.MipgViewModel
import com.example.ui.theme.*

@Composable
fun LedgerAndTreasuryScreen(viewModel: MipgViewModel) {
    val ledgerEntries by viewModel.ledgerEntries.collectAsState()
    val merchant by viewModel.currentMerchant.collectAsState()

    var payoutAmountInput by remember { mutableStateOf("5000.00") }
    var payoutDestinationInput by remember { mutableStateOf("0x8A92...E110 (FPS/Interchain)") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "DOUBLE-ENTRY LEDGER & TREASURY ENGINE",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = AgedBrass,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "Balanced Accounting • Settlement Reconciliation • Marketplace Split Payments • Payouts",
                    fontSize = 11.sp,
                    color = WarmIvoryMuted
                )
            }
        }

        // Ledger Integrity Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StatusSuccess, RoundedCornerShape(8.dp))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Verified, contentDescription = null, tint = StatusSuccess)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "DOUBLE-ENTRY BALANCE SHEET IS BALANCED",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = StatusSuccess
                            )
                            Text(
                                text = "Sum(Debits) == Sum(Credits) • 0 Unreconciled Interchain Exceptions",
                                fontSize = 10.sp,
                                color = WarmIvoryMuted
                            )
                        }
                    }
                    Button(
                        onClick = { /* Refresh Reconciliation */ },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusSuccessBg, contentColor = StatusSuccess),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.testTag("verify_ledger_btn")
                    ) {
                        Text("RECONCILE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Merchant Balances Cards
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                MetricCard(
                    title = "Available Balance",
                    value = "£${String.format("%,.2f", merchant.availableBalanceGbp)}",
                    subtitle = "Cleared for immediate payout",
                    icon = { Icon(Icons.Default.AccountBalance, contentDescription = null, tint = StatusSuccess) },
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "In-Transit / Pending",
                    value = "£${String.format("%,.2f", merchant.pendingBalanceGbp)}",
                    subtitle = "Awaiting finality batch",
                    icon = { Icon(Icons.Default.HourglassEmpty, contentDescription = null, tint = StatusWarning) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Payout Execution Form
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CharcoalBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "TREASURY PAYOUT ENGINE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AgedBrass,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = payoutAmountInput,
                            onValueChange = { payoutAmountInput = it },
                            label = { Text("Payout Amount (£)") },
                            modifier = Modifier.weight(1f).testTag("payout_amount_input")
                        )
                        Button(
                            onClick = {
                                val amt = payoutAmountInput.toDoubleOrNull() ?: 1000.0
                                viewModel.requestPayout(amt, payoutDestinationInput)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BrickRedPrimary, contentColor = WarmIvoryText),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.testTag("request_payout_btn")
                        ) {
                            Text("REQUEST PAYOUT", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // MARKETPLACE SPLIT PAYMENTS SIMULATOR
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CharcoalBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "MARKETPLACE SPLIT PAYMENTS DEMO",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = SandstoneAccent,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "A single £1,250.00 customer payment automatically split between 4 stakeholders in 1 atomic transaction.",
                        fontSize = 10.sp,
                        color = WarmIvoryMuted
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    val splits = listOf(
                        SplitAllocation("Merchant Net Share", "MERCHANT", 1062.50, "sGBP", 85.0),
                        SplitAllocation("Marketplace Platform Fee", "MARKETPLACE", 125.00, "sGBP", 10.0),
                        SplitAllocation("Creator Royalty Share", "CREATOR", 37.50, "sGBP", 3.0),
                        SplitAllocation("Tax Reserve Clearing", "TAX_RESERVE", 25.00, "sGBP", 2.0)
                    )

                    splits.forEach { split ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .background(CharcoalDark, RoundedCornerShape(4.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(text = split.recipientId, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = WarmIvoryText)
                                Text(text = "${split.recipientType} • ${split.percentage}% allocation", fontSize = 9.sp, color = WarmIvoryMuted)
                            }
                            Text(
                                text = "£${String.format("%.2f", split.amount)} ${split.currency}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = SandstoneAccent
                            )
                        }
                    }
                }
            }
        }

        // DOUBLE ENTRY GENERAL LEDGER TABLE
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CharcoalBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "DOUBLE-ENTRY GENERAL LEDGER LOG",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = WarmIvoryText,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    if (ledgerEntries.isEmpty()) {
                        Text(text = "No ledger entries recorded yet.", fontSize = 11.sp, color = WarmIvoryMuted)
                    } else {
                        ledgerEntries.forEach { entry ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(CharcoalDark, RoundedCornerShape(6.dp))
                                    .padding(10.dp)
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(text = entry.description, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = WarmIvoryText)
                                    Text(text = "£${String.format("%.2f", entry.amount)} ${entry.currency}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SandstoneAccent)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "DEBIT: ${entry.debitAccount} ➔ CREDIT: ${entry.creditAccount}",
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = WarmIvoryMuted
                                    )
                                    Text(
                                        text = entry.refType,
                                        fontSize = 9.sp,
                                        color = RestrainedSteel
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
