package com.example.mipg.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mipg.domain.model.EnvironmentType
import com.example.mipg.domain.model.PaymentIntentStatus
import com.example.mipg.domain.model.PaymentRoute
import com.example.ui.theme.*

@Composable
fun PrestigeHeaderBar(
    environment: EnvironmentType,
    onEnvironmentChanged: (EnvironmentType) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = CharcoalSurface,
        contentColor = WarmIvoryText,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, CharcoalBorder)
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(BrickRedPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "M",
                            color = WarmIvoryText,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            fontFamily = FontFamily.Serif
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "MANCHESTER INTERCHAIN",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp,
                            fontSize = 13.sp,
                            color = AgedBrass
                        )
                        Text(
                            text = "PAYMENT GATEWAY (MIPG)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = WarmIvoryMuted,
                            letterSpacing = 0.8.sp
                        )
                    }
                }

                // Environment selector pill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(CharcoalDark)
                        .border(1.dp, AgedBrassDark, RoundedCornerShape(20.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (environment == EnvironmentType.LIVE) StatusSuccess else AgedBrass)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = environment.name,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = WarmIvoryText
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = {
                            val next = if (environment == EnvironmentType.SANDBOX) EnvironmentType.LIVE else EnvironmentType.SANDBOX
                            onEnvironmentChanged(next)
                        },
                        modifier = Modifier.size(20.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = "Toggle Environment",
                            tint = AgedBrass,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Sub-header stats ticker
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CharcoalDark, RoundedCornerShape(4.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusTickerItem(label = "INTERCHAIN TPS", value = "1,250 tps")
                StatusTickerItem(label = "MCX LIQUIDITY", value = "$42.8M")
                StatusTickerItem(label = "NODES ONLINE", value = "64/64")
                StatusTickerItem(label = "LATENCY", value = "12ms")
            }
        }
    }
}

@Composable
fun StatusTickerItem(label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(text = "$label: ", fontSize = 9.sp, color = RestrainedSteel, fontWeight = FontWeight.Bold)
        Text(text = value, fontSize = 9.sp, color = SandstoneAccent, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: @Composable () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
            .border(1.dp, CharcoalBorder, RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title.uppercase(),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = SandstoneAccent,
                    letterSpacing = 1.sp
                )
                icon()
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = WarmIvoryText,
                fontFamily = FontFamily.Serif
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = WarmIvoryMuted
            )
        }
    }
}

@Composable
fun StateBadge(status: PaymentIntentStatus) {
    val (bgColor, textColor) = when (status) {
        PaymentIntentStatus.SETTLED -> StatusSuccessBg to StatusSuccess
        PaymentIntentStatus.PROCESSING, PaymentIntentStatus.SOURCE_CONFIRMED, PaymentIntentStatus.SETTLEMENT_PENDING -> StatusInfoBg to StatusInfo
        PaymentIntentStatus.QUOTED, PaymentIntentStatus.PAYMENT_METHOD_SELECTED, PaymentIntentStatus.AUTHORISED -> StatusWarningBg to StatusWarning
        PaymentIntentStatus.FAILED, PaymentIntentStatus.EXPIRED, PaymentIntentStatus.CANCELLED -> StatusErrorBg to StatusError
        PaymentIntentStatus.REFUNDED, PaymentIntentStatus.DISPUTED, PaymentIntentStatus.MANUAL_REVIEW -> CharcoalDark to AgedBrass
        else -> CharcoalDark to WarmIvoryMuted
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bgColor)
            .border(1.dp, textColor.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = status.name,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = textColor,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun GraphRouteVisualizer(route: PaymentRoute) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CharcoalDark),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AgedBrassDark, RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "EXECUTABLE GRAPH ROUTE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = AgedBrass,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "EST. ${route.estimatedTotalTimeSeconds}s",
                    fontSize = 10.sp,
                    color = WarmIvoryMuted,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            route.hops.forEachIndexed { idx, hop ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CharcoalSurface, RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(BrickRedPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${idx + 1}",
                            color = WarmIvoryText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${hop.sourceNetwork} (${hop.inputAsset}) ➔ ${hop.destinationNetwork} (${hop.outputAsset})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = WarmIvoryText
                        )
                        Text(
                            text = "Protocol: ${hop.protocol} | LP: ${hop.liquidityProvider}",
                            fontSize = 10.sp,
                            color = WarmIvoryMuted
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Fee: £${String.format("%.2f", hop.feeAmount)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SandstoneAccent
                        )
                        Text(
                            text = "${hop.estimatedTimeSeconds}s",
                            fontSize = 9.sp,
                            color = RestrainedSteel
                        )
                    }
                }
                if (idx < route.hops.size - 1) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowDownward,
                            contentDescription = "Hop link",
                            tint = AgedBrass,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "Slippage Allowance: ${(route.slippageAllowance * 100)}%", fontSize = 10.sp, color = RestrainedSteel)
                Text(text = "Finality: ${route.finalityRequirement}", fontSize = 10.sp, color = RestrainedSteel)
            }
        }
    }
}

@Composable
fun CodeBlockViewer(
    code: String,
    title: String,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(containerColor = CharcoalDark),
        shape = RoundedCornerShape(6.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, CharcoalBorder, RoundedCornerShape(6.dp))
    ) {
        Column {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CharcoalSurface)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = title,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = SandstoneAccent,
                    fontFamily = FontFamily.Monospace
                )
                TextButton(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(code))
                        copied = true
                    },
                    modifier = Modifier.testTag("copy_code_btn")
                ) {
                    Icon(
                        imageVector = if (copied) Icons.Default.Check else Icons.Default.ContentCopy,
                        contentDescription = "Copy Code",
                        tint = AgedBrass,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (copied) "COPIED" else "COPY",
                        fontSize = 10.sp,
                        color = AgedBrass
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Text(
                    text = code,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = WarmIvoryText,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
fun QrCodeView(
    data: String,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .background(WarmIvoryText, RoundedCornerShape(8.dp))
            .padding(16.dp)
    ) {
        Canvas(modifier = Modifier.size(140.dp)) {
            val gridCount = 12
            val cellSize = size.width / gridCount
            val hash = data.hashCode()
            
            // Draw stylized QR matrix
            for (row in 0 until gridCount) {
                for (col in 0 until gridCount) {
                    val isCorner = (row < 3 && col < 3) || (row < 3 && col >= gridCount - 3) || (row >= gridCount - 3 && col < 3)
                    val isFilled = isCorner || ((row * 31 + col * 17 + hash) % 3 == 0)
                    if (isFilled) {
                        drawRect(
                            color = Color(0xFF121316),
                            topLeft = Offset(col * cellSize, row * cellSize),
                            size = Size(cellSize - 1f, cellSize - 1f)
                        )
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "SCAN TO PAY WITH WEB3 WALLET",
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            color = CharcoalDark,
            letterSpacing = 0.5.sp
        )
    }
}
