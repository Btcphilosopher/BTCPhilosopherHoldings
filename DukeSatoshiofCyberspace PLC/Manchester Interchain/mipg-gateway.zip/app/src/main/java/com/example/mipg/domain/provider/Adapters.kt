package com.example.mipg.domain.provider

import com.example.mipg.domain.model.*
import java.util.UUID

class SyntheticGbpAdapter : PaymentRailAdapter {
    override val providerId = "rail_manchester_sgbp"
    override val providerName = "Manchester Interchain sGBP Native Rail"
    override val supportedAsset = "sGBP"
    override val nativeNetwork = "Manchester Interchain"
    override val environment = EnvironmentType.SANDBOX

    override suspend fun quote(intent: PaymentIntent, targetAsset: String): PaymentQuote {
        val rate = 1.0 // 1 sGBP = 1 GBP
        val inputAmt = intent.amount
        val outputAmt = inputAmt * rate
        val netFee = 0.0005 * inputAmt // 0.05% interchain fee
        val gwFee = 0.0010 * inputAmt // 0.1% gateway fee
        val hop = RouteHop(
            hopIndex = 1,
            sourceNetwork = "Manchester Interchain",
            destinationNetwork = "Manchester Interchain",
            inputAsset = "sGBP",
            outputAsset = "sGBP",
            protocol = "Manchester Interchain Direct Settlement",
            feeAmount = netFee,
            estimatedTimeSeconds = 2,
            liquidityProvider = "Manchester Interchain Protocol"
        )
        val route = PaymentRoute(
            intentId = intent.id,
            hops = listOf(hop),
            totalFee = netFee + gwFee,
            netExchangeRate = rate,
            estimatedTotalTimeSeconds = 2
        )
        return PaymentQuote(
            intentId = intent.id,
            inputAsset = "sGBP",
            outputAsset = targetAsset,
            inputAmount = inputAmt,
            outputAmount = outputAmt,
            exchangeRate = rate,
            networkFee = netFee,
            gatewayFee = gwFee,
            liquidityFee = 0.0,
            spread = 0.0,
            sourceNetwork = nativeNetwork,
            destinationNetwork = nativeNetwork,
            settlementEstimateSeconds = 2,
            route = route
        )
    }

    override suspend fun authorise(intent: PaymentIntent, quote: PaymentQuote, walletAddress: String?): PaymentAttempt {
        return PaymentAttempt(
            intentId = intent.id,
            methodId = providerId,
            status = PaymentIntentStatus.AUTHORISED,
            txHash = "0xmcr_sgbp_" + UUID.randomUUID().toString().take(16),
            network = nativeNetwork,
            blockNumber = 12_849_012L,
            confirmations = 1
        )
    }

    override suspend fun capture(attempt: PaymentAttempt): PaymentAttempt {
        return attempt.copy(status = PaymentIntentStatus.SETTLED, confirmations = 12)
    }

    override suspend fun cancel(intentId: String) = true

    override suspend fun refund(intentId: String, amount: Double, reason: String): Refund {
        return Refund(
            originalPaymentId = intentId,
            intentId = intentId,
            amount = amount,
            currency = "sGBP",
            reason = reason,
            destination = "0x" + UUID.randomUUID().toString().take(16)
        )
    }

    override suspend fun getStatus(attemptId: String): PaymentAttempt {
        return PaymentAttempt(
            id = attemptId,
            intentId = "pi_mock",
            methodId = providerId,
            status = PaymentIntentStatus.SETTLED,
            network = nativeNetwork
        )
    }

    override suspend fun verify(txHash: String) = true

    override suspend fun settle(intent: PaymentIntent, quote: PaymentQuote): Settlement {
        val gross = quote.outputAmount
        val fee = quote.gatewayFee
        val net = gross - fee
        return Settlement(
            intentId = intent.id,
            merchantId = intent.merchantId,
            grossAmount = gross,
            gatewayFee = fee,
            netAmount = net,
            currency = quote.outputAsset,
            destinationAccount = intent.settlementDestination,
            ledgerRef = "led_sgbp_" + UUID.randomUUID().toString().take(8)
        )
    }

    override suspend fun payout(merchantId: String, amount: Double, asset: String, destination: String): Payout {
        return Payout(
            merchantId = merchantId,
            amount = amount,
            asset = asset,
            destination = destination
        )
    }
}

class UsdcRailAdapter : PaymentRailAdapter {
    override val providerId = "rail_ethereum_usdc"
    override val providerName = "USDC ERC-20 / Arbitrum Rail"
    override val supportedAsset = "USDC"
    override val nativeNetwork = "Ethereum Mainnet"
    override val environment = EnvironmentType.SANDBOX

    override suspend fun quote(intent: PaymentIntent, targetAsset: String): PaymentQuote {
        val rate = if (targetAsset == "sGBP" || targetAsset == "GBP") 0.7850 else 1.0
        val inputUsdc = intent.amount / rate
        val networkFeeUsdc = 1.20
        val gatewayFeeUsdc = 0.0015 * inputUsdc
        val liquidityFeeUsdc = 0.0005 * inputUsdc

        val hop1 = RouteHop(
            hopIndex = 1,
            sourceNetwork = "Ethereum Mainnet",
            destinationNetwork = "Manchester Interchain",
            inputAsset = "USDC",
            outputAsset = "sUSDC",
            protocol = "Manchester Interchain Lock & Mint Bridge",
            feeAmount = 1.20,
            estimatedTimeSeconds = 12,
            liquidityProvider = "Interchain Bridge Validator"
        )
        val hop2 = RouteHop(
            hopIndex = 2,
            sourceNetwork = "Manchester Interchain",
            destinationNetwork = "Manchester Interchain",
            inputAsset = "sUSDC",
            outputAsset = targetAsset,
            protocol = "MCX Liquidity Pool (USDC/sGBP)",
            feeAmount = gatewayFeeUsdc,
            estimatedTimeSeconds = 3,
            liquidityProvider = "Manchester Coin Exchange Pool"
        )

        val route = PaymentRoute(
            intentId = intent.id,
            hops = listOf(hop1, hop2),
            totalFee = networkFeeUsdc + gatewayFeeUsdc + liquidityFeeUsdc,
            netExchangeRate = rate,
            estimatedTotalTimeSeconds = 15
        )

        return PaymentQuote(
            intentId = intent.id,
            inputAsset = "USDC",
            outputAsset = targetAsset,
            inputAmount = inputUsdc,
            outputAmount = intent.amount,
            exchangeRate = rate,
            networkFee = networkFeeUsdc,
            gatewayFee = gatewayFeeUsdc,
            liquidityFee = liquidityFeeUsdc,
            spread = 0.0008,
            sourceNetwork = "Ethereum",
            destinationNetwork = "Manchester Interchain",
            settlementEstimateSeconds = 15,
            route = route
        )
    }

    override suspend fun authorise(intent: PaymentIntent, quote: PaymentQuote, walletAddress: String?): PaymentAttempt {
        return PaymentAttempt(
            intentId = intent.id,
            methodId = providerId,
            status = PaymentIntentStatus.AUTHORISED,
            txHash = "0x8a92b" + UUID.randomUUID().toString().replace("-", "").take(28),
            network = nativeNetwork,
            blockNumber = 19_842_110L,
            confirmations = 2
        )
    }

    override suspend fun capture(attempt: PaymentAttempt) = attempt.copy(status = PaymentIntentStatus.SETTLED, confirmations = 15)
    override suspend fun cancel(intentId: String) = true
    override suspend fun refund(intentId: String, amount: Double, reason: String) = Refund(
        originalPaymentId = intentId,
        intentId = intentId,
        amount = amount,
        currency = "USDC",
        reason = reason,
        destination = "0x" + UUID.randomUUID().toString().take(16)
    )
    override suspend fun getStatus(attemptId: String) = PaymentAttempt(id = attemptId, intentId = "pi_mock", methodId = providerId, status = PaymentIntentStatus.SETTLED, network = nativeNetwork)
    override suspend fun verify(txHash: String) = true
    override suspend fun settle(intent: PaymentIntent, quote: PaymentQuote) = Settlement(
        intentId = intent.id,
        merchantId = intent.merchantId,
        grossAmount = quote.outputAmount,
        gatewayFee = quote.gatewayFee,
        netAmount = quote.outputAmount - quote.gatewayFee,
        currency = quote.outputAsset,
        destinationAccount = intent.settlementDestination,
        ledgerRef = "led_usdc_" + UUID.randomUUID().toString().take(8)
    )
    override suspend fun payout(merchantId: String, amount: Double, asset: String, destination: String) = Payout(merchantId = merchantId, amount = amount, asset = asset, destination = destination)
}

class BitcoinRailAdapter : PaymentRailAdapter {
    override val providerId = "rail_bitcoin_native"
    override val providerName = "Bitcoin Native On-Chain Rail"
    override val supportedAsset = "BTC"
    override val nativeNetwork = "Bitcoin Mainnet"
    override val environment = EnvironmentType.SIMULATED

    override suspend fun quote(intent: PaymentIntent, targetAsset: String): PaymentQuote {
        val btcPriceGbp = 68450.00
        val inputBtc = (intent.amount / if (targetAsset == "GBP" || targetAsset == "sGBP") 1.0 else 1.28) / btcPriceGbp
        val netFeeBtc = 0.00008
        val gwFeeBtc = 0.00005

        val hop = RouteHop(
            hopIndex = 1,
            sourceNetwork = "Bitcoin Mainnet",
            destinationNetwork = "Manchester Interchain",
            inputAsset = "BTC",
            outputAsset = targetAsset,
            protocol = "Manchester Interchain HTLC Swap",
            feeAmount = (netFeeBtc + gwFeeBtc) * btcPriceGbp,
            estimatedTimeSeconds = 300,
            liquidityProvider = "MCX Bitcoin Bridge Node"
        )
        val route = PaymentRoute(intentId = intent.id, hops = listOf(hop), totalFee = (netFeeBtc + gwFeeBtc) * btcPriceGbp, netExchangeRate = btcPriceGbp, estimatedTotalTimeSeconds = 300)

        return PaymentQuote(
            intentId = intent.id,
            inputAsset = "BTC",
            outputAsset = targetAsset,
            inputAmount = inputBtc,
            outputAmount = intent.amount,
            exchangeRate = btcPriceGbp,
            networkFee = netFeeBtc * btcPriceGbp,
            gatewayFee = gwFeeBtc * btcPriceGbp,
            liquidityFee = 0.001 * intent.amount,
            spread = 0.002,
            sourceNetwork = nativeNetwork,
            destinationNetwork = "Manchester Interchain",
            settlementEstimateSeconds = 300,
            route = route
        )
    }

    override suspend fun authorise(intent: PaymentIntent, quote: PaymentQuote, walletAddress: String?): PaymentAttempt {
        return PaymentAttempt(
            intentId = intent.id,
            methodId = providerId,
            status = PaymentIntentStatus.AUTHORISED,
            txHash = "btc_tx_" + UUID.randomUUID().toString().replace("-", "").take(24),
            network = nativeNetwork,
            blockNumber = 840_120L,
            confirmations = 1
        )
    }

    override suspend fun capture(attempt: PaymentAttempt) = attempt.copy(status = PaymentIntentStatus.SETTLED, confirmations = 3)
    override suspend fun cancel(intentId: String) = true
    override suspend fun refund(intentId: String, amount: Double, reason: String) = Refund(originalPaymentId = intentId, intentId = intentId, amount = amount, currency = "BTC", reason = reason, destination = "bc1q" + UUID.randomUUID().toString().take(16))
    override suspend fun getStatus(attemptId: String) = PaymentAttempt(id = attemptId, intentId = "pi_mock", methodId = providerId, status = PaymentIntentStatus.SETTLED, network = nativeNetwork)
    override suspend fun verify(txHash: String) = true
    override suspend fun settle(intent: PaymentIntent, quote: PaymentQuote) = Settlement(intentId = intent.id, merchantId = intent.merchantId, grossAmount = quote.outputAmount, gatewayFee = quote.gatewayFee, netAmount = quote.outputAmount - quote.gatewayFee, currency = quote.outputAsset, destinationAccount = intent.settlementDestination, ledgerRef = "led_btc_" + UUID.randomUUID().toString().take(8))
    override suspend fun payout(merchantId: String, amount: Double, asset: String, destination: String) = Payout(merchantId = merchantId, amount = amount, asset = asset, destination = destination)
}

class EthereumRailAdapter : PaymentRailAdapter {
    override val providerId = "rail_ethereum_eth"
    override val providerName = "Ethereum Native ETH Rail"
    override val supportedAsset = "ETH"
    override val nativeNetwork = "Ethereum Mainnet"
    override val environment = EnvironmentType.SANDBOX

    override suspend fun quote(intent: PaymentIntent, targetAsset: String): PaymentQuote {
        val ethPriceGbp = 2840.00
        val inputEth = intent.amount / ethPriceGbp
        val hop = RouteHop(
            hopIndex = 1,
            sourceNetwork = "Ethereum Mainnet",
            destinationNetwork = "Manchester Interchain",
            inputAsset = "ETH",
            outputAsset = targetAsset,
            protocol = "Manchester Bridge Pool",
            feeAmount = 2.50,
            estimatedTimeSeconds = 14,
            liquidityProvider = "Manchester Interchain Pool"
        )
        val route = PaymentRoute(intentId = intent.id, hops = listOf(hop), totalFee = 2.50, netExchangeRate = ethPriceGbp, estimatedTotalTimeSeconds = 14)
        return PaymentQuote(
            intentId = intent.id,
            inputAsset = "ETH",
            outputAsset = targetAsset,
            inputAmount = inputEth,
            outputAmount = intent.amount,
            exchangeRate = ethPriceGbp,
            networkFee = 2.00,
            gatewayFee = 0.50,
            liquidityFee = 0.20,
            spread = 0.001,
            sourceNetwork = nativeNetwork,
            destinationNetwork = "Manchester Interchain",
            settlementEstimateSeconds = 14,
            route = route
        )
    }

    override suspend fun authorise(intent: PaymentIntent, quote: PaymentQuote, walletAddress: String?) = PaymentAttempt(
        intentId = intent.id,
        methodId = providerId,
        status = PaymentIntentStatus.AUTHORISED,
        txHash = "0xeth_" + UUID.randomUUID().toString().replace("-", "").take(20),
        network = nativeNetwork,
        blockNumber = 19_842_112L,
        confirmations = 2
    )

    override suspend fun capture(attempt: PaymentAttempt) = attempt.copy(status = PaymentIntentStatus.SETTLED)
    override suspend fun cancel(intentId: String) = true
    override suspend fun refund(intentId: String, amount: Double, reason: String) = Refund(originalPaymentId = intentId, intentId = intentId, amount = amount, currency = "ETH", reason = reason, destination = "0x" + UUID.randomUUID().toString().take(16))
    override suspend fun getStatus(attemptId: String) = PaymentAttempt(id = attemptId, intentId = "pi_mock", methodId = providerId, status = PaymentIntentStatus.SETTLED, network = nativeNetwork)
    override suspend fun verify(txHash: String) = true
    override suspend fun settle(intent: PaymentIntent, quote: PaymentQuote) = Settlement(intentId = intent.id, merchantId = intent.merchantId, grossAmount = quote.outputAmount, gatewayFee = quote.gatewayFee, netAmount = quote.outputAmount - quote.gatewayFee, currency = quote.outputAsset, destinationAccount = intent.settlementDestination, ledgerRef = "led_eth_" + UUID.randomUUID().toString().take(8))
    override suspend fun payout(merchantId: String, amount: Double, asset: String, destination: String) = Payout(merchantId = merchantId, amount = amount, asset = asset, destination = destination)
}

class ManchesterDemoRailProvider : PaymentRailAdapter {
    override val providerId = "plugin_mcr_demo_rail"
    override val providerName = "Manchester Plugin SDK Demo Rail"
    override val supportedAsset = "MNCH"
    override val nativeNetwork = "Manchester Interchain Plugin"
    override val environment = EnvironmentType.INTEGRATION_READY

    override suspend fun quote(intent: PaymentIntent, targetAsset: String): PaymentQuote {
        val rate = 2.45 // 1 MNCH = 2.45 GBP
        val input = intent.amount / rate
        val hop = RouteHop(
            hopIndex = 1,
            sourceNetwork = nativeNetwork,
            destinationNetwork = "Manchester Interchain",
            inputAsset = "MNCH",
            outputAsset = targetAsset,
            protocol = "Plugin SDK Provider Interface",
            feeAmount = 0.10,
            estimatedTimeSeconds = 1,
            liquidityProvider = "Manchester Institutional SDK Node"
        )
        val route = PaymentRoute(intentId = intent.id, hops = listOf(hop), totalFee = 0.10, netExchangeRate = rate, estimatedTotalTimeSeconds = 1)
        return PaymentQuote(
            intentId = intent.id,
            inputAsset = "MNCH",
            outputAsset = targetAsset,
            inputAmount = input,
            outputAmount = intent.amount,
            exchangeRate = rate,
            networkFee = 0.05,
            gatewayFee = 0.05,
            liquidityFee = 0.0,
            spread = 0.0001,
            sourceNetwork = nativeNetwork,
            destinationNetwork = "Manchester Interchain",
            settlementEstimateSeconds = 1,
            route = route
        )
    }

    override suspend fun authorise(intent: PaymentIntent, quote: PaymentQuote, walletAddress: String?) = PaymentAttempt(
        intentId = intent.id,
        methodId = providerId,
        status = PaymentIntentStatus.AUTHORISED,
        txHash = "0xplugin_mcr_" + UUID.randomUUID().toString().replace("-", "").take(16),
        network = nativeNetwork,
        blockNumber = 129000L,
        confirmations = 1
    )

    override suspend fun capture(attempt: PaymentAttempt) = attempt.copy(status = PaymentIntentStatus.SETTLED)
    override suspend fun cancel(intentId: String) = true
    override suspend fun refund(intentId: String, amount: Double, reason: String) = Refund(originalPaymentId = intentId, intentId = intentId, amount = amount, currency = "MNCH", reason = reason, destination = "0x" + UUID.randomUUID().toString().take(16))
    override suspend fun getStatus(attemptId: String) = PaymentAttempt(id = attemptId, intentId = "pi_mock", methodId = providerId, status = PaymentIntentStatus.SETTLED, network = nativeNetwork)
    override suspend fun verify(txHash: String) = true
    override suspend fun settle(intent: PaymentIntent, quote: PaymentQuote) = Settlement(intentId = intent.id, merchantId = intent.merchantId, grossAmount = quote.outputAmount, gatewayFee = quote.gatewayFee, netAmount = quote.outputAmount - quote.gatewayFee, currency = quote.outputAsset, destinationAccount = intent.settlementDestination, ledgerRef = "led_plugin_" + UUID.randomUUID().toString().take(8))
    override suspend fun payout(merchantId: String, amount: Double, asset: String, destination: String) = Payout(merchantId = merchantId, amount = amount, asset = asset, destination = destination)
}
