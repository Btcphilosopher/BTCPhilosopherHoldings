package com.example.mipg.data.persistence

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PaymentIntentEntity::class,
        PaymentEventEntity::class,
        LedgerEntryEntity::class,
        WebhookLogEntity::class,
        RiskAuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MipgDatabase : RoomDatabase() {
    abstract fun mipgDao(): MipgDao

    companion object {
        @Volatile
        private var INSTANCE: MipgDatabase? = null

        fun getDatabase(context: Context): MipgDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MipgDatabase::class.java,
                    "mipg_gateway.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
