package com.example.mipg.data.persistence

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MipgDao {
    @Query("SELECT * FROM payment_intents ORDER BY createdAt DESC")
    fun getAllPaymentIntents(): Flow<List<PaymentIntentEntity>>

    @Query("SELECT * FROM payment_intents WHERE id = :id")
    suspend fun getPaymentIntentById(id: String): PaymentIntentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPaymentIntent(intent: PaymentIntentEntity)

    @Query("UPDATE payment_intents SET status = :status, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updatePaymentIntentStatus(id: String, status: String, updatedAt: Long = System.currentTimeMillis())

    @Query("SELECT * FROM payment_events ORDER BY timestamp DESC")
    fun getAllPaymentEvents(): Flow<List<PaymentEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPaymentEvent(event: PaymentEventEntity)

    @Query("SELECT * FROM ledger_entries ORDER BY timestamp DESC")
    fun getAllLedgerEntries(): Flow<List<LedgerEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedgerEntry(entry: LedgerEntryEntity)

    @Query("SELECT * FROM webhook_logs ORDER BY timestamp DESC")
    fun getAllWebhookLogs(): Flow<List<WebhookLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWebhookLog(log: WebhookLogEntity)

    @Query("SELECT * FROM risk_audit_logs ORDER BY timestamp DESC")
    fun getAllRiskLogs(): Flow<List<RiskAuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRiskLog(log: RiskAuditLogEntity)
}
