package com.example.mipg.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.mipg.data.persistence.MipgDatabase
import com.example.mipg.data.repository.MipgRepository
import com.example.mipg.domain.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class MipgViewModel(application: Application) : AndroidViewModel(application) {

    private val db = MipgDatabase.getDatabase(application)
    val repository = MipgRepository(db.mipgDao())

    val paymentIntents: StateFlow<List<PaymentIntent>> = repository.paymentIntentsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val paymentEvents: StateFlow<List<PaymentEvent>> = repository.paymentEventsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val ledgerEntries: StateFlow<List<LedgerEntry>> = repository.ledgerEntriesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val webhookLogs: StateFlow<List<WebhookDeliveryLog>> = repository.webhookLogsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentMerchant = MutableStateFlow(Merchant())
    val currentMerchant: StateFlow<Merchant> = _currentMerchant.asStateFlow()

    private val _activeQuote = MutableStateFlow<PaymentQuote?>(null)
    val activeQuote: StateFlow<PaymentQuote?> = _activeQuote.asStateFlow()

    private val _activeSession = MutableStateFlow<CheckoutSession?>(null)
    val activeSession: StateFlow<CheckoutSession?> = _activeSession.asStateFlow()

    private val _selectedEnvironment = MutableStateFlow(EnvironmentType.SANDBOX)
    val selectedEnvironment: StateFlow<EnvironmentType> = _selectedEnvironment.asStateFlow()

    private val _sdkLanguage = MutableStateFlow("KOTLIN")
    val sdkLanguage: StateFlow<String> = _sdkLanguage.asStateFlow()

    private val _agenticPolicy = MutableStateFlow(AgenticPolicy())
    val agenticPolicy: StateFlow<AgenticPolicy> = _agenticPolicy.asStateFlow()

    private val _agenticRequestLog = MutableStateFlow<List<Pair<AgenticPaymentRequest, String>>>(emptyList())
    val agenticRequestLog: StateFlow<List<Pair<AgenticPaymentRequest, String>>> = _agenticRequestLog.asStateFlow()

    private val _replayOutput = MutableStateFlow<List<String>>(emptyList())
    val replayOutput: StateFlow<List<String>> = _replayOutput.asStateFlow()

    private val _faucetBalance = MutableStateFlow(mapOf("USDC" to 10000.0, "sGBP" to 5000.0, "BTC" to 1.5, "ETH" to 10.0))
    val faucetBalance: StateFlow<Map<String, Double>> = _faucetBalance.asStateFlow()

    init {
        // Seed initial sample intent if empty
        viewModelScope.launch {
            paymentIntents.first().let { current ->
                if (current.isEmpty()) {
                    seedDefaultDemoData()
                }
            }
        }
    }

    private suspend fun seedDefaultDemoData() {
        val defaultIntent = PaymentIntent(
            merchantId = _currentMerchant.value.merchantId,
            customerRef = "cust_mcr_8819",
            merchantRef = "inv_mcr_2026_091",
            amount = 1250.00,
            currency = "sGBP",
            acceptedPaymentMethods = listOf("USDC", "BTC", "ETH", "sGBP", "USDT"),
            settlementDestination = "0x" + UUID.randomUUID().toString().take(16),
            status = PaymentIntentStatus.CREATED
        )
        repository.saveIntent(defaultIntent)

        // Evaluate risk
        val risk = repository.riskEngine.evaluateIntent(defaultIntent)
        repository.recordRiskEvaluation(risk)

        // Generate quote
        val quote = repository.router.buildRouteAndQuote(defaultIntent, "USDC")
        _activeQuote.value = quote

        // Advance to QUOTED
        repository.updateIntentStatus(defaultIntent.id, defaultIntent.merchantId, PaymentIntentStatus.CREATED, PaymentIntentStatus.QUOTED)
    }

    fun createPaymentIntent(
        amount: Double,
        currency: String,
        customerRef: String,
        acceptedMethod: String
    ) {
        viewModelScope.launch {
            val intent = PaymentIntent(
                merchantId = _currentMerchant.value.merchantId,
                customerRef = customerRef.ifBlank { "cust_mcr_" + (1000..9999).random() },
                merchantRef = "ord_mcr_" + System.currentTimeMillis().toString().takeLast(6),
                amount = amount,
                currency = currency,
                acceptedPaymentMethods = listOf(acceptedMethod, "USDC", "sGBP", "BTC", "ETH"),
                settlementDestination = "0x" + UUID.randomUUID().toString().take(16)
            )
            repository.saveIntent(intent)

            val risk = repository.riskEngine.evaluateIntent(intent)
            repository.recordRiskEvaluation(risk)

            val quote = repository.router.buildRouteAndQuote(intent, acceptedMethod)
            _activeQuote.value = quote
            repository.updateIntentStatus(intent.id, intent.merchantId, PaymentIntentStatus.CREATED, PaymentIntentStatus.QUOTED)

            // Create checkout session
            _activeSession.value = CheckoutSession(
                intentId = intent.id,
                merchantId = intent.merchantId,
                checkoutUrl = "https://pay.manchester.ac.uk/checkout/${intent.id}",
                embedConfigJson = "{\"intentId\": \"${intent.id}\", \"amount\": ${intent.amount}, \"currency\": \"${intent.currency}\"}",
                acceptedAssets = intent.acceptedPaymentMethods,
                acceptedNetworks = intent.networkPreferences,
                settlementCurrency = intent.currency
            )
        }
    }

    fun requestQuoteForIntent(intent: PaymentIntent, methodIdentifier: String) {
        viewModelScope.launch {
            val quote = repository.router.buildRouteAndQuote(intent, methodIdentifier)
            _activeQuote.value = quote
            repository.updateIntentStatus(intent.id, intent.merchantId, intent.status, PaymentIntentStatus.QUOTED)
        }
    }

    fun confirmAndSettlePayment(intent: PaymentIntent, quote: PaymentQuote) {
        viewModelScope.launch {
            // State transitions: PAYMENT_METHOD_SELECTED -> AUTHORISED -> PROCESSING -> SOURCE_CONFIRMED -> SETTLEMENT_PENDING -> SETTLED
            val mId = intent.merchantId
            repository.updateIntentStatus(intent.id, mId, intent.status, PaymentIntentStatus.PAYMENT_METHOD_SELECTED)
            repository.updateIntentStatus(intent.id, mId, PaymentIntentStatus.PAYMENT_METHOD_SELECTED, PaymentIntentStatus.AUTHORISED)
            repository.updateIntentStatus(intent.id, mId, PaymentIntentStatus.AUTHORISED, PaymentIntentStatus.PROCESSING)
            repository.updateIntentStatus(intent.id, mId, PaymentIntentStatus.PROCESSING, PaymentIntentStatus.SOURCE_CONFIRMED)
            repository.updateIntentStatus(intent.id, mId, PaymentIntentStatus.SOURCE_CONFIRMED, PaymentIntentStatus.SETTLEMENT_PENDING)

            // Double Entry Ledger entries
            val entries = repository.ledger.recordSettlement(intent, quote, _currentMerchant.value)
            repository.recordLedgerEntries(entries)

            // Final state: SETTLED
            repository.updateIntentStatus(intent.id, mId, PaymentIntentStatus.SETTLEMENT_PENDING, PaymentIntentStatus.SETTLED)

            // Update merchant balances
            val netAdd = quote.outputAmount - quote.gatewayFee
            _currentMerchant.value = _currentMerchant.value.copy(
                availableBalanceGbp = _currentMerchant.value.availableBalanceGbp + netAdd
            )
        }
    }

    fun triggerRefund(intentId: String, amount: Double, reason: String) {
        viewModelScope.launch {
            val mId = _currentMerchant.value.merchantId
            repository.updateIntentStatus(intentId, mId, PaymentIntentStatus.SETTLED, PaymentIntentStatus.REFUNDED)
            _currentMerchant.value = _currentMerchant.value.copy(
                availableBalanceGbp = (_currentMerchant.value.availableBalanceGbp - amount).coerceAtLeast(0.0)
            )
        }
    }

    fun requestPayout(amount: Double, destination: String) {
        viewModelScope.launch {
            _currentMerchant.value = _currentMerchant.value.copy(
                availableBalanceGbp = (_currentMerchant.value.availableBalanceGbp - amount).coerceAtLeast(0.0),
                pendingBalanceGbp = _currentMerchant.value.pendingBalanceGbp + amount
            )
        }
    }

    fun simulateAgenticPayment(amount: Double, currency: String, purpose: String) {
        val req = AgenticPaymentRequest(
            agentId = "agent_mcr_auto_01",
            amount = amount,
            currency = currency,
            merchantId = _currentMerchant.value.merchantId,
            purpose = purpose,
            approvalStatus = "PENDING"
        )
        val (evalReq, msg) = repository.agenticEngine.processAgentRequest(_agenticPolicy.value, req)

        if (evalReq.approvalStatus == "APPROVED_AUTOMATICALLY") {
            _agenticPolicy.value = _agenticPolicy.value.copy(
                currentDailySpentGbp = _agenticPolicy.value.currentDailySpentGbp + amount
            )
            createPaymentIntent(amount, currency, "agentic_cust_01", "USDC")
        }

        _agenticRequestLog.value = listOf(evalReq to msg) + _agenticRequestLog.value
    }

    fun runReplayEngine() {
        val events = paymentEvents.value
        val output = repository.replayEngine.replayEventHistory(events)
        _replayOutput.value = output
    }

    fun switchEnvironment(env: EnvironmentType) {
        _selectedEnvironment.value = env
    }

    fun setSdkLanguage(lang: String) {
        _sdkLanguage.value = lang
    }

    fun faucetMint(asset: String, amount: Double) {
        val current = _faucetBalance.value.toMutableMap()
        current[asset] = (current[asset] ?: 0.0) + amount
        _faucetBalance.value = current
    }
}
