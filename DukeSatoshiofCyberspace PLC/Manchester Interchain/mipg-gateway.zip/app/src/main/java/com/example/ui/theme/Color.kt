package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Prestige Manchester Color Palette
val BrickRedPrimary = Color(0xFF8B261D)
val BrickRedDark = Color(0xFF5E1711)
val BrickRedLight = Color(0xFFAE3D32)

val CharcoalDark = Color(0xFF121316)
val CharcoalSurface = Color(0xFF1A1B1E)
val CharcoalCard = Color(0xFF22242A)
val CharcoalBorder = Color(0xFF323640)

val GraphiteDark = Color(0xFF292C33)
val SandstoneAccent = Color(0xFFD8C29D)
val SandstoneLight = Color(0xFFEBE0CD)
val AgedBrass = Color(0xFFC5A059)
val AgedBrassDark = Color(0xFF8C6E33)

val WarmIvoryText = Color(0xFFFAF8F5)
val WarmIvoryMuted = Color(0xFFC2BEB8)
val RestrainedSteel = Color(0xFF4A525D)
val SteelLight = Color(0xFF7A838F)

val StatusSuccess = Color(0xFF2E7D32)
val StatusSuccessBg = Color(0xFF132B15)
val StatusWarning = Color(0xFFED6C02)
val StatusWarningBg = Color(0xFF33200A)
val StatusError = Color(0xFFD32F2F)
val StatusErrorBg = Color(0xFF321414)
val StatusInfo = Color(0xFF0288D1)
val StatusInfoBg = Color(0xFF0C2738)
