package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mipg.ui.components.PrestigeHeaderBar
import com.example.mipg.ui.screens.*
import com.example.mipg.ui.viewmodel.MipgViewModel
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {

    private val viewModel: MipgViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MIPGTheme(darkTheme = true) {
                var selectedTab by remember { mutableIntStateOf(0) }
                val env by viewModel.selectedEnvironment.collectAsState()

                Scaffold(
                    topBar = {
                        PrestigeHeaderBar(
                            environment = env,
                            onEnvironmentChanged = { newEnv -> viewModel.switchEnvironment(newEnv) }
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = CharcoalSurface,
                            contentColor = WarmIvoryText,
                            tonalElevation = 8.dp,
                            modifier = Modifier.border(1.dp, CharcoalBorder)
                        ) {
                            val items = listOf(
                                MipgNavItem("Dashboard", Icons.Default.Dashboard, 0),
                                MipgNavItem("Intents", Icons.Default.ReceiptLong, 1),
                                MipgNavItem("Demos", Icons.Default.ShoppingBag, 2),
                                MipgNavItem("Ledger", Icons.Default.AccountBalance, 3),
                                MipgNavItem("Dev Portal", Icons.Default.Code, 4),
                                MipgNavItem("Security", Icons.Default.Shield, 5)
                            )

                            items.forEach { item ->
                                NavigationBarItem(
                                    selected = selectedTab == item.index,
                                    onClick = { selectedTab = item.index },
                                    icon = { Icon(item.icon, contentDescription = item.label) },
                                    label = { Text(item.label, fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = WarmIvoryText,
                                        selectedTextColor = AgedBrass,
                                        indicatorColor = BrickRedPrimary,
                                        unselectedIconColor = WarmIvoryMuted,
                                        unselectedTextColor = WarmIvoryMuted
                                    ),
                                    modifier = Modifier.testTag("nav_tab_${item.index}")
                                )
                            }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(CharcoalDark)
                    ) {
                        when (selectedTab) {
                            0 -> DashboardScreen(
                                viewModel = viewModel,
                                onNavigateToIntents = { selectedTab = 1 },
                                onNavigateToCheckout = { selectedTab = 2 }
                            )
                            1 -> IntentsAndRouterScreen(viewModel = viewModel)
                            2 -> CheckoutDemosScreen(viewModel = viewModel)
                            3 -> LedgerAndTreasuryScreen(viewModel = viewModel)
                            4 -> DeveloperPortalScreen(viewModel = viewModel)
                            5 -> SecurityAndRiskScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

private data class MipgNavItem(
    val label: String,
    val icon: ImageVector,
    val index: Int
)
