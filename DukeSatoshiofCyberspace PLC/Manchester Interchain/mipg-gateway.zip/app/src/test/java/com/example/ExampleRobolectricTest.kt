package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.mipg.domain.engine.DoubleEntryLedger
import com.example.mipg.domain.engine.RiskEngine
import com.example.mipg.domain.model.*
import com.example.mipg.domain.provider.SyntheticGbpAdapter
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app_name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("MIPG Gateway", appName)
    }

    @Test
    fun `test double entry ledger balance integrity`() {
        val ledger = DoubleEntryLedger()
        val intent = PaymentIntent(merchantId = "merch_001", amount = 1000.0, currency = "sGBP", settlementDestination = "0x123")
        val quote = PaymentQuote(
            intentId = intent.id,
            inputAsset = "sGBP",
            outputAsset = "sGBP",
            inputAmount = 1000.0,
            outputAmount = 1000.0,
            exchangeRate = 1.0,
            networkFee = 0.5,
            gatewayFee = 1.0,
            liquidityFee = 0.0,
            spread = 0.0,
            sourceNetwork = "Manchester Interchain",
            destinationNetwork = "Manchester Interchain",
            route = PaymentRoute(intentId = intent.id, hops = emptyList(), totalFee = 1.5, netExchangeRate = 1.0, estimatedTotalTimeSeconds = 2)
        )
        val merchant = Merchant(merchantId = "merch_001")

        val entries = ledger.recordSettlement(intent, quote, merchant)
        assertEquals(3, entries.size)
        assertTrue(ledger.verifyBalanceSheet())
    }

    @Test
    fun `test synthetic rail adapter quote and risk engine`() = runBlocking {
        val adapter = SyntheticGbpAdapter()
        val intent = PaymentIntent(merchantId = "merch_001", amount = 500.0, currency = "sGBP", settlementDestination = "0x456")

        val quote = adapter.quote(intent, "sGBP")
        assertEquals(500.0, quote.inputAmount, 0.001)

        val riskEngine = RiskEngine()
        val risk = riskEngine.evaluateIntent(intent)
        assertEquals(RiskLevel.LOW, risk.level)
    }
}
