package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.min.adapter.AdapterRegistry
import com.example.min.domain.model.*
import com.example.min.domain.state.InvalidStateTransitionException
import com.example.min.domain.state.MessageStateMachine
import com.example.min.engine.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.math.BigInteger

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun testAppNameResource() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Manchester Interchain", appName)
    }

    @Test
    fun testMessageStateMachineTransitions() {
        val now = System.currentTimeMillis()
        val initialMsg = InterchainMessage(
            messageId = MessageId("msg_test_01"),
            sourceNetwork = NetworkId("net_manchester_main"),
            destinationNetwork = NetworkId("net_ethereum_main"),
            sender = Address("mnc1vault"),
            recipient = Address("0x1234567890123456789012345678901234567890"),
            assetId = AssetId("SGBP"),
            amount = BigInteger.valueOf(100_000_00L),
            formattedAmount = "£100,000.00 SGBP",
            nonce = 1L,
            payloadHash = "0xhash123",
            createdAtTimestamp = now,
            expiresAtTimestamp = now + 10000L,
            currentState = MessageState.CREATED,
            sourceTxHash = null,
            destinationTxHash = null,
            routingMetadata = null,
            proofMetadata = null,
            stateHistory = emptyList(),
            correlationId = "corr_1"
        )

        val validated = MessageStateMachine.transition(
            initialMsg,
            MessageState.VALIDATED,
            "chk_123",
            NodeId("node_test")
        )
        assertEquals(MessageState.VALIDATED, validated.currentState)
        assertEquals(1, validated.stateHistory.size)

        val routed = MessageStateMachine.transition(
            validated,
            MessageState.ROUTED,
            "rte_direct",
            NodeId("node_test")
        )
        assertEquals(MessageState.ROUTED, routed.currentState)
    }

    @Test(expected = InvalidStateTransitionException::class)
    fun testInvalidStateTransitionThrows() {
        val initialMsg = InterchainMessage(
            messageId = MessageId("msg_test_invalid"),
            sourceNetwork = NetworkId("net_manchester_main"),
            destinationNetwork = NetworkId("net_ethereum_main"),
            sender = Address("mnc1vault"),
            recipient = Address("0x1234"),
            assetId = AssetId("SGBP"),
            amount = BigInteger.valueOf(100L),
            formattedAmount = "£1.00",
            nonce = 1L,
            payloadHash = "0xhash",
            createdAtTimestamp = 1000L,
            expiresAtTimestamp = 2000L,
            currentState = MessageState.CREATED,
            sourceTxHash = null,
            destinationTxHash = null,
            routingMetadata = null,
            proofMetadata = null,
            stateHistory = emptyList(),
            correlationId = "corr_inv"
        )

        // Cannot jump directly from CREATED to SETTLED
        MessageStateMachine.transition(
            initialMsg,
            MessageState.SETTLED,
            "illegal jump",
            NodeId("node_test")
        )
    }

    @Test
    fun testReplayProtectionDeduplication() {
        val engine = ReplayProtectionEngine()
        val res1 = engine.checkAndRegister(
            messageId = MessageId("msg_unique_1"),
            sourceTxHash = TxHash("0xtx_unique_1"),
            sender = Address("mnc1sender"),
            nonce = 101L,
            destinationNetwork = NetworkId("net_ethereum_main")
        )
        assertTrue(res1.isSuccess)

        val duplicate = engine.checkAndRegister(
            messageId = MessageId("msg_unique_1"),
            sourceTxHash = TxHash("0xtx_unique_1"),
            sender = Address("mnc1sender"),
            nonce = 101L,
            destinationNetwork = NetworkId("net_ethereum_main")
        )
        assertTrue(duplicate.isFailure)
    }

    @Test
    fun testAuditLedgerTamperProofChain() {
        val ledger = AuditLedger()
        ledger.record(
            entityType = "MESSAGE",
            entityId = "msg_001",
            actor = "TEST_RUNNER",
            action = "SETTLE",
            previousState = "SUBMITTED",
            newState = "SETTLED",
            sourceEvent = "TEST_EV",
            resultingEvent = "TEST_OK"
        )

        val verification = ledger.verifyIntegrity()
        assertTrue(verification.isChainValid)
        assertEquals(2, verification.totalEntriesVerified) // Genesis + 1 record
    }
}
