package com.example.min.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.min.adapter.AdapterRegistry
import com.example.min.api.MinApiGateway
import com.example.min.api.MinCliEngine
import com.example.min.bus.*
import com.example.min.domain.model.*
import com.example.min.engine.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.math.BigInteger
import java.util.Locale

data class NodeUiState(
    val nodeIdentity: NodeIdentity,
    val healthReport: NodeHealthReport,
    val networks: List<ChainNetwork> = emptyList(),
    val assets: List<Asset> = emptyList(),
    val bridges: List<BridgeDescriptor> = emptyList(),
    val liquidityPools: List<LiquidityPool> = emptyList(),
    val peers: List<PeerNode> = emptyList(),
    val recentEvents: List<BusEvent> = emptyList(),
    val messages: List<InterchainMessage> = emptyList(),
    val auditEntries: List<AuditEntry> = emptyList(),
    val metrics: NodeMetrics = NodeMetrics(
        blocksObserved = 24_800L,
        transactionsProcessed = 1_840_900L,
        messagesRouted = 142_900L,
        messagesSettled = 142_780L,
        messagesFailed = 120L,
        totalSettledVolumeGbp = 2_840_500_000.0,
        averageSettlementLatencySeconds = 2.4,
        activePeerCount = 4,
        apiLatencyMs = 2,
        messageBusQueueDepth = 0,
        validationTps = 840.0,
        proofVerificationSuccessRate = 99.98
    ),
    val activeQuote: InterchainQuote? = null,
    val isQuoteLoading: Boolean = false,
    val isScenarioRunning: Boolean = false,
    val scenarioProgressMessage: String? = null,
    val selectedTopicFilter: String = "ALL",
    val terminalOutput: List<String> = listOf(
        "MANCHESTER INTERCHAIN NODE (MIN) — INSTITUTIONAL INTEROPERABILITY ENGINE",
        "Protocol MIN/1.4 | Node: node_manchester_uk_01 | Region: eu-west-2",
        "Ready. Type 'min help' for available system commands.",
        "------------------------------------------------------------------------"
    ),
    val chaosStatusMessage: String? = null,
    val auditVerification: AuditVerificationResult? = null
)

class MinNodeViewModel : ViewModel() {

    // Subsystems
    val adapterRegistry = AdapterRegistry()
    val bus = InterchainMessageBus()
    val auditLedger = AuditLedger()
    val replayProtectionEngine = ReplayProtectionEngine()
    val validationEngine = ValidationEngine(adapterRegistry, replayProtectionEngine)
    val liquidityEngine = LiquidityEngine(adapterRegistry)
    val router = InterchainRouter(adapterRegistry, liquidityEngine)
    val proofVerificationLayer = ProofVerificationLayer()
    val peerDiscoveryService = PeerDiscoveryService()
    val settlementCoordinator = SettlementCoordinator(
        adapterRegistry = adapterRegistry,
        validationEngine = validationEngine,
        router = router,
        proofVerificationLayer = proofVerificationLayer,
        auditLedger = auditLedger,
        bus = bus
    )
    val blockObserver = BlockObserver(adapterRegistry, bus, auditLedger)
    val simulationEngine = SimulationEngine(
        adapterRegistry = adapterRegistry,
        settlementCoordinator = settlementCoordinator,
        bus = bus,
        auditLedger = auditLedger
    )
    val apiGateway = MinApiGateway(
        adapterRegistry = adapterRegistry,
        router = router,
        liquidityEngine = liquidityEngine,
        settlementCoordinator = settlementCoordinator,
        proofVerificationLayer = proofVerificationLayer,
        auditLedger = auditLedger,
        peerDiscoveryService = peerDiscoveryService,
        simulationEngine = simulationEngine,
        bus = bus
    )
    val cliEngine = MinCliEngine(apiGateway, simulationEngine)

    private val _uiState = MutableStateFlow(
        NodeUiState(
            nodeIdentity = peerDiscoveryService.localNode,
            healthReport = NodeHealthReport(
                isLivenessHealthy = true,
                isReadinessHealthy = true,
                networkHealthSummary = emptyMap(),
                dependencies = emptyList(),
                activeAlerts = emptyList(),
                memoryUsageMb = 248,
                uptimeSeconds = 345600
            )
        )
    )
    val uiState: StateFlow<NodeUiState> = _uiState.asStateFlow()

    init {
        blockObserver.startObserving()
        simulationEngine.startContinuousSimulation()
        refreshAllData()
        observeBusEvents()

        // Seed initial corridor demonstration message so tables have initial institutional data
        viewModelScope.launch {
            simulationEngine.runManchesterCorridorScenario()
            refreshAllData()
        }
    }

    private fun observeBusEvents() {
        viewModelScope.launch {
            bus.eventFlow.collect { event ->
                val current = _uiState.value
                val updatedEvents = (listOf(event) + current.recentEvents).take(200)

                // Dynamically update metrics
                val m = current.metrics
                val newMetrics = when (event) {
                    is BlockObservedEvent -> m.copy(blocksObserved = m.blocksObserved + 1)
                    is TransactionSeenEvent -> m.copy(transactionsProcessed = m.transactionsProcessed + 1)
                    is RouteSelectedEvent -> m.copy(messagesRouted = m.messagesRouted + 1)
                    is InterchainSettledEvent -> m.copy(
                        messagesSettled = m.messagesSettled + 1,
                        totalSettledVolumeGbp = m.totalSettledVolumeGbp + 1_500_000.0
                    )
                    is MessageFailedEvent -> m.copy(messagesFailed = m.messagesFailed + 1)
                    else -> m
                }

                _uiState.update {
                    it.copy(
                        recentEvents = updatedEvents,
                        metrics = newMetrics,
                        messages = settlementCoordinator.getAllMessages(),
                        auditEntries = auditLedger.getAllEntries().take(100),
                        networks = adapterRegistry.getAllAdapters().map { a -> a.network }
                    )
                }
            }
        }
    }

    fun refreshAllData() {
        viewModelScope.launch {
            val nets = apiGateway.getNetworks().data ?: emptyList()
            val assets = apiGateway.getAssets().data ?: emptyList()
            val bridges = apiGateway.getBridges().data ?: emptyList()
            val pools = apiGateway.getLiquidityPools().data ?: emptyList()
            val peers = apiGateway.getPeers().data ?: emptyList()
            val messages = apiGateway.getMessages().data ?: emptyList()
            val audits = apiGateway.getAuditEntries(100).data ?: emptyList()
            val health = apiGateway.getHealth().data

            _uiState.update {
                it.copy(
                    networks = nets,
                    assets = assets,
                    bridges = bridges,
                    liquidityPools = pools,
                    peers = peers,
                    messages = messages,
                    auditEntries = audits,
                    healthReport = health ?: it.healthReport
                )
            }
        }
    }

    fun requestQuote(
        sourceNetwork: NetworkId,
        destinationNetwork: NetworkId,
        inputAssetId: AssetId,
        outputAssetId: AssetId,
        amountHuman: Double
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isQuoteLoading = true) }
            val res = apiGateway.createQuote(
                sourceNetwork.value,
                destinationNetwork.value,
                inputAssetId.value,
                outputAssetId.value,
                amountHuman
            )
            _uiState.update {
                it.copy(
                    activeQuote = res.data,
                    isQuoteLoading = false,
                    scenarioProgressMessage = if (res.data != null) "Quote generated: ${res.data.exchangeRateFormatted}" else res.error
                )
            }
        }
    }

    fun executeActiveQuote() {
        val q = _uiState.value.activeQuote ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isScenarioRunning = true, scenarioProgressMessage = "Executing cross-chain settlement...") }
            val inAsset = q.inputAsset
            val humanAmt = inAsset.formatAmount(q.inputAmount)

            val res = settlementCoordinator.createAndExecuteMessage(
                sourceNetwork = q.route.sourceNetwork,
                destinationNetwork = q.route.destinationNetwork,
                sender = Address("mnc1institution_vault_alpha"),
                recipient = Address("0x89205A3A3b2A55384284A4cf838f5379b1836109"),
                assetId = q.inputAsset.canonicalId,
                amount = q.inputAmount,
                memo = "Interchain Execution via Quote ${q.quoteId.value}"
            )

            _uiState.update {
                it.copy(
                    isScenarioRunning = false,
                    scenarioProgressMessage = if (res.isSuccess) "Settlement complete: ${res.getOrThrow().messageId.value} [SETTLED]" else "Failed: ${res.exceptionOrNull()?.message}"
                )
            }
            refreshAllData()
        }
    }

    fun runCorridorScenario() {
        viewModelScope.launch {
            _uiState.update { it.copy(isScenarioRunning = true, scenarioProgressMessage = "Running Manchester Interchain Corridor...") }
            val res = simulationEngine.runManchesterCorridorScenario()
            _uiState.update {
                it.copy(
                    isScenarioRunning = false,
                    scenarioProgressMessage = if (res.isSuccess) "Manchester Corridor Settled (£1.5M SGBP) — Message: ${res.getOrThrow().messageId.value}" else "Corridor execution error: ${res.exceptionOrNull()?.message}"
                )
            }
            refreshAllData()
        }
    }

    fun runBtcToGbpScenario() {
        viewModelScope.launch {
            _uiState.update { it.copy(isScenarioRunning = true, scenarioProgressMessage = "Running BTC → MCX → SGBP Conversion...") }
            val res = simulationEngine.runBtcToGbpScenario()
            _uiState.update {
                it.copy(
                    isScenarioRunning = false,
                    scenarioProgressMessage = if (res.isSuccess) "BTC → SGBP Settled: ${res.getOrThrow().messageId.value}" else "Error: ${res.exceptionOrNull()?.message}"
                )
            }
            refreshAllData()
        }
    }

    fun runUsdcIngressScenario() {
        viewModelScope.launch {
            _uiState.update { it.copy(isScenarioRunning = true, scenarioProgressMessage = "Running USDC Ingress...") }
            val res = simulationEngine.runUsdcToManchesterScenario()
            _uiState.update {
                it.copy(
                    isScenarioRunning = false,
                    scenarioProgressMessage = if (res.isSuccess) "USDC Ingress Settled ($5.0M USDC) — Message: ${res.getOrThrow().messageId.value}" else "Error: ${res.exceptionOrNull()?.message}"
                )
            }
            refreshAllData()
        }
    }

    fun injectNetworkOutage(networkId: NetworkId) {
        viewModelScope.launch {
            val msg = simulationEngine.injectNetworkOutage(networkId)
            _uiState.update { it.copy(chaosStatusMessage = msg) }
            refreshAllData()
        }
    }

    fun recoverNetwork(networkId: NetworkId) {
        viewModelScope.launch {
            val msg = simulationEngine.recoverNetwork(networkId)
            _uiState.update { it.copy(chaosStatusMessage = msg) }
            refreshAllData()
        }
    }

    fun injectReplayAttack() {
        viewModelScope.launch {
            val outcome = simulationEngine.injectReplayAttackSimulation()
            _uiState.update { it.copy(chaosStatusMessage = outcome) }
            refreshAllData()
        }
    }

    fun injectInvalidProof() {
        viewModelScope.launch {
            val outcome = simulationEngine.injectInvalidProofSimulation()
            _uiState.update { it.copy(chaosStatusMessage = outcome) }
            refreshAllData()
        }
    }

    fun verifyAuditChain() {
        viewModelScope.launch {
            val res = auditLedger.verifyIntegrity()
            _uiState.update { it.copy(auditVerification = res) }
        }
    }

    fun executeCliCommand(command: String) {
        viewModelScope.launch {
            val output = cliEngine.executeCommand(command)
            if (output == "__CLEAR__") {
                _uiState.update { it.copy(terminalOutput = emptyList()) }
                return@launch
            }
            val newOutput = _uiState.value.terminalOutput + "> $command" + output.split("\n")
            _uiState.update { it.copy(terminalOutput = newOutput.takeLast(150)) }
            refreshAllData()
        }
    }

    fun setTopicFilter(filter: String) {
        _uiState.update { it.copy(selectedTopicFilter = filter) }
    }

    override fun onCleared() {
        super.onCleared()
        blockObserver.stopObserving()
        simulationEngine.stopContinuousSimulation()
    }
}
