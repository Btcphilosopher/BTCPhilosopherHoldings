package com.example.min.adapter

import com.example.min.domain.model.*
import java.math.BigInteger

class ManchesterChainAdapter(
    initialNetwork: ChainNetwork = ChainNetwork(
        networkId = NetworkId("net_manchester_main"),
        chainId = ChainId(1894),
        name = "Manchester Chain",
        shortCode = "MNC-NET",
        protocol = ProtocolType.MANCHESTER_BFT,
        nativeAssetId = AssetId("MNC"),
        rpcEndpoints = listOf("https://rpc.node-01.manchester-interchain.net", "wss://feed.manchester-interchain.net"),
        finalityModel = FinalityModel.EXPLICIT_BFT_INSTITUTIONAL,
        blockHeight = 2_840_192L,
        latestBlockHash = BlockHash("0x8f4d92a0e1c53b76543210abcedf99281746201a4e5f7c8b9d0e1a2f3b4c5d6e"),
        peerCount = 48,
        confirmationPolicy = ConfirmationPolicy(
            standardConfirmations = 1,
            highValueConfirmations = 2,
            highValueThresholdGbp = 1_000_000.0,
            targetBlockTimeSeconds = 0.8,
            maxReorgDepthProtected = 0
        ),
        capabilities = setOf(
            NetworkCapability.SMART_CONTRACTS,
            NetworkCapability.NATIVE_ASSET_TRANSFERS,
            NetworkCapability.ADAPTOR_SIGNATURES,
            NetworkCapability.HTLC_CONTRACTS,
            NetworkCapability.PROOF_EMISSION,
            NetworkCapability.CROSS_CHAIN_CALLS,
            NetworkCapability.ZERO_GAS_INTERCHAIN_RELAY
        ),
        healthState = NetworkHealthState.HEALTHY,
        integrationMode = IntegrationMode.SIMULATED,
        adapterVersion = "adapter-manchester-bft-v2.4.0",
        blockLatencyMs = 800L,
        totalTransactionsObserved = 18_429_050L,
        description = "Core institutional high-throughput BFT network engineered for the Manchester Coin Exchange and Digital Interchain settlement."
    )
) : BaseSimulatedAdapter(initialNetwork) {

    override suspend fun validateAddress(address: Address): Boolean {
        return address.value.startsWith("mnc1") && address.value.length in 38..44 ||
                address.value.startsWith("0x") && address.value.length == 42
    }

    override suspend fun checkFinality(blockHeight: Long): FinalityStatus {
        val current = currentBlockHeight.get()
        val confs = if (blockHeight <= current) (current - blockHeight + 1).toInt() else 0
        val isFinal = confs >= 1
        return FinalityStatus(
            networkId = network.networkId,
            blockHeight = blockHeight,
            confirmations = confs,
            requiredConfirmations = 1,
            isFinalized = isFinal,
            confidenceRating = if (isFinal) 1.0 else 0.5,
            finalityModel = FinalityModel.EXPLICIT_BFT_INSTITUTIONAL,
            estimatedSecondsToFinal = if (isFinal) 0L else 1L
        )
    }

    override fun calculateFee(amount: BigInteger): BigInteger {
        // Zero or negligible relay fee for institutional clearing
        return BigInteger.valueOf((100 * congestionMultiplier).toLong())
    }

    override fun isHeightFinalized(height: Long): Boolean = true

    override fun calculateFinalityConfidence(height: Long): Double = 1.0
}
