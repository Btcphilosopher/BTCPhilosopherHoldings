package com.example.min.adapter

import com.example.min.domain.model.*
import java.math.BigInteger

class SyntheticGbpAdapter(
    initialNetwork: ChainNetwork = ChainNetwork(
        networkId = NetworkId("net_gbp_digital_clearing"),
        chainId = ChainId(826),
        name = "Digital Pound Network",
        shortCode = "GBP-RTGS",
        protocol = ProtocolType.SYNTHETIC_CLEARING,
        nativeAssetId = AssetId("SGBP"),
        rpcEndpoints = listOf("https://rtgs-gateway.boe-clearing.uk.internal"),
        finalityModel = FinalityModel.INSTANT_CLEARING,
        blockHeight = 5_920_300L,
        latestBlockHash = BlockHash("0x99281746201a4e5f7c8b9d0e1a2f3b4c5d6e8f4d92a0e1c53b76543210abcedf"),
        peerCount = 18,
        confirmationPolicy = ConfirmationPolicy(
            standardConfirmations = 1,
            highValueConfirmations = 1,
            highValueThresholdGbp = 50_000_000.0,
            targetBlockTimeSeconds = 0.2,
            maxReorgDepthProtected = 0
        ),
        capabilities = setOf(
            NetworkCapability.NATIVE_ASSET_TRANSFERS,
            NetworkCapability.ADAPTOR_SIGNATURES,
            NetworkCapability.CONFIDENTIAL_SETTLEMENT,
            NetworkCapability.ZERO_GAS_INTERCHAIN_RELAY
        ),
        healthState = NetworkHealthState.HEALTHY,
        integrationMode = IntegrationMode.SIMULATED,
        adapterVersion = "adapter-synthetic-gbp-rtgs-v3.0.1",
        blockLatencyMs = 200L,
        totalTransactionsObserved = 89_200_000L,
        description = "Synthetic Sterling Digital Pound wholesale settlement rail with Bank of England clearing parity."
    )
) : BaseSimulatedAdapter(initialNetwork) {

    override suspend fun validateAddress(address: Address): Boolean {
        return address.value.startsWith("gbp1") || address.value.startsWith("uk_ch_")
    }

    override suspend fun checkFinality(blockHeight: Long): FinalityStatus {
        return FinalityStatus(
            networkId = network.networkId,
            blockHeight = blockHeight,
            confirmations = 1,
            requiredConfirmations = 1,
            isFinalized = true,
            confidenceRating = 1.0,
            finalityModel = FinalityModel.INSTANT_CLEARING,
            estimatedSecondsToFinal = 0L
        )
    }

    override fun calculateFee(amount: BigInteger): BigInteger = BigInteger.ZERO // Institutional clearing without per-tx gas
    override fun isHeightFinalized(height: Long): Boolean = true
    override fun calculateFinalityConfidence(height: Long): Double = 1.0
}

class StablecoinSettlementAdapter(
    initialNetwork: ChainNetwork = ChainNetwork(
        networkId = NetworkId("net_stablecoin_clearing"),
        chainId = ChainId(840),
        name = "USD Stablecoin Settlement",
        shortCode = "USD-CLEAR",
        protocol = ProtocolType.STABLECOIN_RAIL,
        nativeAssetId = AssetId("USDC"),
        rpcEndpoints = listOf("https://usdc-settle.manchester-interchain.net"),
        finalityModel = FinalityModel.EXPLICIT_BFT_INSTITUTIONAL,
        blockHeight = 8_420_110L,
        latestBlockHash = BlockHash("0x11223344556677889900aabbccddeeff0011223344556677889900aabbccddeeff"),
        peerCount = 36,
        confirmationPolicy = ConfirmationPolicy(
            standardConfirmations = 1,
            highValueConfirmations = 2,
            highValueThresholdGbp = 5_000_000.0,
            targetBlockTimeSeconds = 0.5,
            maxReorgDepthProtected = 0
        ),
        capabilities = setOf(
            NetworkCapability.SMART_CONTRACTS,
            NetworkCapability.NATIVE_ASSET_TRANSFERS,
            NetworkCapability.HTLC_CONTRACTS,
            NetworkCapability.PROOF_EMISSION
        ),
        healthState = NetworkHealthState.HEALTHY,
        integrationMode = IntegrationMode.SIMULATED,
        adapterVersion = "adapter-stablecoin-v1.4.0",
        blockLatencyMs = 500L,
        totalTransactionsObserved = 412_000_000L,
        description = "High-throughput fiat-referenced stablecoin settlement infrastructure."
    )
) : BaseSimulatedAdapter(initialNetwork) {

    override suspend fun validateAddress(address: Address): Boolean {
        return address.value.startsWith("usd1") || (address.value.startsWith("0x") && address.value.length == 42)
    }

    override suspend fun checkFinality(blockHeight: Long): FinalityStatus {
        return FinalityStatus(
            networkId = network.networkId,
            blockHeight = blockHeight,
            confirmations = 1,
            requiredConfirmations = 1,
            isFinalized = true,
            confidenceRating = 1.0,
            finalityModel = FinalityModel.EXPLICIT_BFT_INSTITUTIONAL,
            estimatedSecondsToFinal = 0L
        )
    }

    override fun calculateFee(amount: BigInteger): BigInteger = BigInteger.valueOf(10)
    override fun isHeightFinalized(height: Long): Boolean = true
    override fun calculateFinalityConfidence(height: Long): Double = 1.0
}

class TokenisedDepositAdapter(
    initialNetwork: ChainNetwork = ChainNetwork(
        networkId = NetworkId("net_tokenised_deposits"),
        chainId = ChainId(827),
        name = "Commercial Deposit Network",
        shortCode = "DEP-UK",
        protocol = ProtocolType.RWA_REGISTRY,
        nativeAssetId = AssetId("DEP-GBP"),
        rpcEndpoints = listOf("https://deposit-clearing.manchester-banks.uk"),
        finalityModel = FinalityModel.EXPLICIT_BFT_INSTITUTIONAL,
        blockHeight = 1_490_800L,
        latestBlockHash = BlockHash("0xaa11bb22cc33dd44ee55ff667788990011223344556677889900aabbccddeeff"),
        peerCount = 14,
        confirmationPolicy = ConfirmationPolicy(
            standardConfirmations = 1,
            highValueConfirmations = 1,
            highValueThresholdGbp = 20_000_000.0,
            targetBlockTimeSeconds = 1.0,
            maxReorgDepthProtected = 0
        ),
        capabilities = setOf(
            NetworkCapability.NATIVE_ASSET_TRANSFERS,
            NetworkCapability.PROOF_EMISSION,
            NetworkCapability.CONFIDENTIAL_SETTLEMENT
        ),
        healthState = NetworkHealthState.HEALTHY,
        integrationMode = IntegrationMode.SIMULATED,
        adapterVersion = "adapter-tokenised-deposits-v1.0.0",
        blockLatencyMs = 1000L,
        totalTransactionsObserved = 6_400_000L,
        description = "Regulated commercial bank deposit token network for institutional liquidity transfer."
    )
) : BaseSimulatedAdapter(initialNetwork) {

    override suspend fun validateAddress(address: Address): Boolean {
        return address.value.startsWith("bank1") || address.value.startsWith("iban_")
    }

    override suspend fun checkFinality(blockHeight: Long): FinalityStatus {
        return FinalityStatus(
            networkId = network.networkId,
            blockHeight = blockHeight,
            confirmations = 1,
            requiredConfirmations = 1,
            isFinalized = true,
            confidenceRating = 1.0,
            finalityModel = FinalityModel.EXPLICIT_BFT_INSTITUTIONAL,
            estimatedSecondsToFinal = 0L
        )
    }

    override fun calculateFee(amount: BigInteger): BigInteger = BigInteger.ZERO
    override fun isHeightFinalized(height: Long): Boolean = true
    override fun calculateFinalityConfidence(height: Long): Double = 1.0
}
