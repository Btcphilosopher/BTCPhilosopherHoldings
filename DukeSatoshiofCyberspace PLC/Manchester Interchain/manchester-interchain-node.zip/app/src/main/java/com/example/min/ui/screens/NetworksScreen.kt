package com.example.min.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.min.domain.model.ChainNetwork
import com.example.min.domain.model.LiquidityPool
import com.example.min.domain.model.NetworkHealthState
import com.example.min.ui.components.SectionHeader
import com.example.min.ui.viewmodel.NodeUiState
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@Composable
fun NetworksScreen(
    state: NodeUiState,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Connected Blockchain Networks",
                subtitle = "Active chain adapters, consensus models, RPC endpoints & block progression"
            )
        }

        items(state.networks) { network ->
            NetworkDetailedCard(network = network)
        }

        item {
            SectionHeader(
                title = "MCX Institutional Liquidity Pools",
                subtitle = "Cross-chain automated market maker reserves and fee tiers"
            )
        }

        items(state.liquidityPools) { pool ->
            PoolDetailedCard(pool = pool)
        }
    }
}

@Composable
fun NetworkDetailedCard(
    network: ChainNetwork,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalSurface),
        border = BorderStroke(1.dp, ManchesterGraphiteBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (network.healthState == NetworkHealthState.HEALTHY) StatusSettledGreen else StatusFailedRed)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = network.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = ManchesterIvoryText
                    )
                }
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = ManchesterBrickContainer,
                    border = BorderStroke(0.8.dp, ManchesterBrick)
                ) {
                    Text(
                        text = network.integrationMode.name,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = ManchesterSandstoneLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = network.description,
                style = MaterialTheme.typography.bodySmall,
                color = ManchesterMutedText,
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = ManchesterGraphiteDivider)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "Block Height", style = MaterialTheme.typography.labelSmall, color = ManchesterSubtleText)
                    Text(
                        text = "#${network.blockHeight}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = ManchesterBrassLight
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "Finality Model", style = MaterialTheme.typography.labelSmall, color = ManchesterSubtleText)
                    Text(
                        text = network.finalityModel.name,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = StatusRoutingBlue,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Confirmations: ${network.confirmationPolicy.standardConfirmations} (Std) / ${network.confirmationPolicy.highValueConfirmations} (High-Val)",
                    style = MaterialTheme.typography.bodySmall,
                    color = ManchesterMutedText,
                    fontSize = 10.sp
                )
                Text(
                    text = "Adapter: ${network.adapterVersion}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ManchesterSubtleText,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
fun PoolDetailedCard(
    pool: LiquidityPool,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalCard),
        border = BorderStroke(1.dp, ManchesterGraphiteBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = pool.poolName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = ManchesterIvoryText
                )
                if (pool.isMcxNative) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = ManchesterBrassDark
                    ) {
                        Text(
                            text = "MCX NATIVE",
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = ManchesterIvoryText,
                            fontWeight = FontWeight.Bold,
                            fontSize = 8.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Reserve A: ${pool.formattedReserveA}", style = MaterialTheme.typography.bodySmall, color = ManchesterSandstoneLight, fontSize = 11.sp)
                Text(text = "Reserve B: ${pool.formattedReserveB}", style = MaterialTheme.typography.bodySmall, color = ManchesterSandstoneLight, fontSize = 11.sp)
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Total Liquidity: £${NumberFormat.getNumberInstance(Locale.UK).format(pool.totalLiquidityGbp)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ManchesterBrass,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp
                )
                Text(
                    text = "Fee: ${pool.feeBps} bps • Util: ${pool.utilizationPercent}%",
                    style = MaterialTheme.typography.bodySmall,
                    color = ManchesterSubtleText,
                    fontSize = 10.sp
                )
            }
        }
    }
}
