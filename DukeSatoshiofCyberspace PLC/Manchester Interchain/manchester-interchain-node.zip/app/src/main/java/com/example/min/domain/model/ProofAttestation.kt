package com.example.min.domain.model

enum class ProofType {
    MERKLE_INCLUSION,
    VALIDATOR_MULTISIG,
    LIGHT_CLIENT_HEADER,
    ZK_SNARK_ATTESTATION
}

enum class VerificationStatus {
    VERIFIED,
    SIMULATED_VERIFICATION,
    UNVERIFIED,
    INVALID,
    REJECTED
}

data class ProofAttestation(
    val proofId: String,
    val messageId: MessageId,
    val sourceNetwork: NetworkId,
    val destinationNetwork: NetworkId,
    val proofType: ProofType,
    val rootHash: String,
    val rawProofHex: String,
    val verificationStatus: VerificationStatus,
    val verifiedByNodeId: NodeId,
    val verifiedAtTimestamp: Long,
    val signatures: List<String>,
    val thresholdRequired: Int,
    val signaturesProvided: Int,
    val cryptographicSummary: String
)

data class MerkleInclusionProof(
    val leafHash: String,
    val rootHash: String,
    val pathHashes: List<String>,
    val leafIndex: Long,
    val txHash: TxHash,
    val blockHeight: Long
)

data class ValidatorAttestation(
    val validatorAddress: Address,
    val signatureHex: String,
    val signedPayloadHash: String,
    val timestamp: Long,
    val validatorName: String
)
