package com.example.min.engine

import com.example.min.domain.model.*
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicLong

class AuditLedger(
    private val localNodeId: NodeId = NodeId("node_manchester_uk_01")
) {
    private val entries = CopyOnWriteArrayList<AuditEntry>()
    private val sequenceCounter = AtomicLong(0)
    private var tipHash: String = "0x" + "0".repeat(64)

    init {
        record(
            entityType = "NODE",
            entityId = localNodeId.value,
            actor = "SYSTEM_INITIALIZER",
            action = "NODE_GENESIS_BOOT",
            previousState = null,
            newState = "ONLINE",
            sourceEvent = "MIN_NODE_STARTUP",
            resultingEvent = "GENESIS_AUDIT_ANCHORED",
            details = mapOf(
                "version" to "v2.4.0-manchester-prod",
                "jurisdiction" to "Manchester, England, UK",
                "hsm_security_profile" to "FIPS-140-3 Level 4 Compliant"
            )
        )
    }

    @Synchronized
    fun record(
        entityType: String,
        entityId: String,
        actor: String,
        action: String,
        previousState: String?,
        newState: String?,
        sourceEvent: String,
        resultingEvent: String?,
        details: Map<String, String> = emptyMap()
    ): AuditEntry {
        val seq = sequenceCounter.incrementAndGet()
        val now = System.currentTimeMillis()
        val prevHash = tipHash

        val hashPayload = "$seq:$now:$entityType:$entityId:$actor:$action:$previousState:$newState:$sourceEvent:$resultingEvent:$prevHash:${details.entries.joinToString(",")}"
        val entryHash = "0x" + sha256(hashPayload)
        tipHash = entryHash

        val entry = AuditEntry(
            auditId = AuditId("aud_${seq}_${UUID.randomUUID().toString().take(6)}"),
            sequenceNumber = seq,
            timestamp = now,
            entityType = entityType,
            entityId = entityId,
            actor = actor,
            action = action,
            previousState = previousState,
            newState = newState,
            sourceEvent = sourceEvent,
            resultingEvent = resultingEvent,
            cryptographicHash = entryHash,
            previousEntryHash = prevHash,
            details = details
        )

        entries.add(entry)
        return entry
    }

    fun getAllEntries(): List<AuditEntry> = entries.toList().reversed()

    fun filter(filter: AuditFilter): List<AuditEntry> {
        return entries.filter { e ->
            (filter.entityType == null || e.entityType.equals(filter.entityType, ignoreCase = true)) &&
                    (filter.entityId == null || e.entityId.contains(filter.entityId, ignoreCase = true)) &&
                    (filter.actor == null || e.actor.contains(filter.actor, ignoreCase = true)) &&
                    (filter.fromTimestamp == null || e.timestamp >= filter.fromTimestamp) &&
                    (filter.toTimestamp == null || e.timestamp <= filter.toTimestamp)
        }.reversed()
    }

    fun verifyIntegrity(): AuditVerificationResult {
        val list = entries.toList()
        if (list.isEmpty()) {
            return AuditVerificationResult(
                isChainValid = true,
                totalEntriesVerified = 0,
                rootHash = tipHash,
                verifiedAtTimestamp = System.currentTimeMillis()
            )
        }

        var prev = "0x" + "0".repeat(64)
        for (i in list.indices) {
            val e = list[i]
            if (e.previousEntryHash != prev) {
                return AuditVerificationResult(
                    isChainValid = false,
                    totalEntriesVerified = i,
                    brokenIndex = e.sequenceNumber,
                    rootHash = tipHash,
                    verifiedAtTimestamp = System.currentTimeMillis()
                )
            }
            val expectedPayload = "${e.sequenceNumber}:${e.timestamp}:${e.entityType}:${e.entityId}:${e.actor}:${e.action}:${e.previousState}:${e.newState}:${e.sourceEvent}:${e.resultingEvent}:${e.previousEntryHash}:${e.details.entries.joinToString(",")}"
            val calculated = "0x" + sha256(expectedPayload)
            if (calculated != e.cryptographicHash) {
                return AuditVerificationResult(
                    isChainValid = false,
                    totalEntriesVerified = i,
                    brokenIndex = e.sequenceNumber,
                    rootHash = tipHash,
                    verifiedAtTimestamp = System.currentTimeMillis()
                )
            }
            prev = e.cryptographicHash
        }

        return AuditVerificationResult(
            isChainValid = true,
            totalEntriesVerified = list.size,
            rootHash = tipHash,
            verifiedAtTimestamp = System.currentTimeMillis()
        )
    }

    private fun sha256(input: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(input.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }
}

class PeerDiscoveryService(
    val localNode: NodeIdentity = NodeIdentity(
        nodeId = NodeId("node_manchester_uk_01"),
        operatorId = "MANCHESTER-INFRA-UK-01",
        operatorName = "Manchester Interchain Settlement Authority",
        nodePublicKeyHex = "0x4a9b8c7d6e5f0123456789abcdef0123456789abcdef0123456789abcdef0123",
        softwareVersion = "v2.4.0-manchester-prod",
        protocolVersion = "MIN/1.4",
        region = "eu-west-2 (Manchester, England)",
        institution = "Manchester Coin Exchange & Interchain Gateway",
        uptimeSeconds = 345_600L,
        startedAtTimestamp = System.currentTimeMillis() - 345_600_000L,
        supportedNetworks = listOf(
            NetworkId("net_manchester_main"),
            NetworkId("net_bitcoin_main"),
            NetworkId("net_ethereum_main"),
            NetworkId("net_gbp_digital_clearing"),
            NetworkId("net_stablecoin_clearing"),
            NetworkId("net_tokenised_deposits")
        ),
        capabilities = setOf(
            "INTERCHAIN_ROUTING",
            "PROOF_VERIFICATION",
            "SETTLEMENT_COORDINATION",
            "LIQUIDITY_DISCOVERY",
            "CHAOS_RESILIENCE"
        )
    )
) {
    private val peers = ConcurrentHashMap<NodeId, PeerNode>()

    init {
        registerPeer(
            PeerNode(
                peerId = NodeId("node_london_boe_relay_02"),
                operatorName = "London Wholesale Clearing Relay",
                addressUri = "https://relay-02.london-clearing.boe.internal",
                region = "eu-west-2 (London)",
                latencyMs = 4,
                status = PeerConnectionStatus.CONNECTED,
                protocolVersion = "MIN/1.4",
                lastSeenTimestamp = System.currentTimeMillis(),
                messagesRelayed = 142_500L
            )
        )

        registerPeer(
            PeerNode(
                peerId = NodeId("node_edinburgh_fin_03"),
                operatorName = "Edinburgh Institutional Gateway",
                addressUri = "https://node-03.edinburgh-fin.scot.internal",
                region = "eu-west-2 (Edinburgh)",
                latencyMs = 8,
                status = PeerConnectionStatus.CONNECTED,
                protocolVersion = "MIN/1.4",
                lastSeenTimestamp = System.currentTimeMillis(),
                messagesRelayed = 88_900L
            )
        )

        registerPeer(
            PeerNode(
                peerId = NodeId("node_frankfurt_ecb_bridge_04"),
                operatorName = "Frankfurt Inter-Network Verifier",
                addressUri = "https://node-04.frankfurt-interchain.eu",
                region = "eu-central-1 (Frankfurt)",
                latencyMs = 18,
                status = PeerConnectionStatus.CONNECTED,
                protocolVersion = "MIN/1.4",
                lastSeenTimestamp = System.currentTimeMillis(),
                messagesRelayed = 210_300L
            )
        )

        registerPeer(
            PeerNode(
                peerId = NodeId("node_ny_institutional_05"),
                operatorName = "New York Cross-Border Rail",
                addressUri = "https://node-05.ny-clearing.us.internal",
                region = "us-east-1 (New York)",
                latencyMs = 68,
                status = PeerConnectionStatus.CONNECTED,
                protocolVersion = "MIN/1.4",
                lastSeenTimestamp = System.currentTimeMillis(),
                messagesRelayed = 350_800L
            )
        )
    }

    fun registerPeer(peer: PeerNode) {
        peers[peer.peerId] = peer
    }

    fun getAllPeers(): List<PeerNode> = peers.values.toList()

    fun signEnvelope(
        receiverNodeId: NodeId,
        payloadType: String,
        payloadJson: String
    ): NodeEnvelope {
        val now = System.currentTimeMillis()
        val nonce = now % 1000000
        val payloadHash = "0x" + sha256(payloadJson)
        val sigInput = "${localNode.nodeId.value}:${receiverNodeId.value}:$payloadHash:$nonce:$now"
        val signature = "0x" + sha256("sig_${localNode.nodePublicKeyHex}_$sigInput")

        return NodeEnvelope(
            envelopeId = "env_${UUID.randomUUID().toString().take(10)}",
            senderNodeId = localNode.nodeId,
            receiverNodeId = receiverNodeId,
            protocolVersion = localNode.protocolVersion,
            timestamp = now,
            nonce = nonce,
            payloadType = payloadType,
            payloadHash = payloadHash,
            rawPayloadJson = payloadJson,
            signatureHex = signature
        )
    }

    fun verifyEnvelope(envelope: NodeEnvelope): Boolean {
        // Authenticated signature verification
        val expectedHash = "0x" + sha256(envelope.rawPayloadJson)
        return envelope.payloadHash == expectedHash && envelope.signatureHex.isNotBlank()
    }

    private fun sha256(input: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(input.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }
}
