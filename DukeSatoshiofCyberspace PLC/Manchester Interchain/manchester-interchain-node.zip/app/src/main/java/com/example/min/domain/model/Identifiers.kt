package com.example.min.domain.model

@JvmInline
value class NetworkId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class ChainId(val value: Long) {
    override fun toString(): String = value.toString()
}

@JvmInline
value class NodeId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class MessageId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class TxHash(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class BlockHash(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class AssetId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class Address(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class SettlementId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class QuoteId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class BridgeId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class PoolId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class AuditId(val value: String) {
    override fun toString(): String = value
}
