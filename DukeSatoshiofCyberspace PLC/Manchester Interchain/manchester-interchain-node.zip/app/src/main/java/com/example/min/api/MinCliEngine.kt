package com.example.min.api

import com.example.min.domain.model.NetworkId
import com.example.min.engine.SimulationEngine
import java.util.Locale

class MinCliEngine(
    private val apiGateway: MinApiGateway,
    private val simulationEngine: SimulationEngine
) {
    suspend fun executeCommand(input: String): String {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return ""

        val parts = trimmed.split("\\s+".toRegex())
        val root = parts.first().lowercase(Locale.ROOT)
        val args = parts.drop(1)

        if (root != "min" && root != "help") {
            return "Command not recognized. Type 'min help' for available MIN CLI commands."
        }

        if (root == "help" || args.isEmpty() || args[0] == "help") {
            return """
                ╔══════════════════════════════════════════════════════════════════════════════╗
                ║   MANCHESTER INTERCHAIN NODE (MIN) — INSTITUTIONAL CLI v2.4.0-PROD          ║
                ║   Node: node_manchester_uk_01 | Region: eu-west-2 (Manchester, UK)           ║
                ╚══════════════════════════════════════════════════════════════════════════════╝
                AVAILABLE COMMANDS:
                  min status               Inspect node identity, health status, and operational metrics
                  min networks             List connected chains, block heights, and finality models
                  min peers                View authenticated P2P nodes and latencies
                  min bridges              List active interchain bridge descriptors and security models
                  min pools                Inspect MCX institutional liquidity pools & depth
                  min corridor             Execute flagship Manchester Interchain Corridor scenario
                  min btc-gbp              Execute BTC → MCX → SGBP liquidity conversion scenario
                  min usdc-ingress         Execute USDC → Ethereum → Manchester Chain ingress scenario
                  min quote <amt>          Generate executable quote for SGBP across Corridor
                  min audit-verify         Verify SHA-256 cryptographic chain integrity across Audit Ledger
                  min chaos outage <net>   Inject simulated network partition on specified adapter
                  min chaos recover <net>  Restore network adapter connectivity
                  min chaos replay         Execute Byzantine duplicate replay attack resilience test
                  min chaos proof          Inject corrupted Merkle proof to test verification defenses
                  min clear                Clear console output
            """.trimIndent()
        }

        return when (args[0].lowercase(Locale.ROOT)) {
            "status" -> {
                val node = apiGateway.getNodeInfo().data
                val health = apiGateway.getHealth().data
                """
                === MANCHESTER INTERCHAIN NODE STATUS ===
                Node ID:       ${node?.nodeId?.value}
                Operator:      ${node?.operatorName} (${node?.operatorId})
                Institution:   ${node?.institution}
                Region:        ${node?.region}
                Software:      ${node?.softwareVersion} [Protocol: ${node?.protocolVersion}]
                Liveness:      ${if (health?.isLivenessHealthy == true) "HEALTHY (ONLINE)" else "UNHEALTHY"}
                Readiness:     ${if (health?.isReadinessHealthy == true) "READY FOR INSTITUTIONAL SETTLEMENT" else "DEGRADED"}
                Memory Usage:  ${health?.memoryUsageMb} MB
                Active Alerts: ${if (health?.activeAlerts.isNullOrEmpty()) "None (All Systems Nominal)" else health?.activeAlerts?.joinToString(", ")}
                """.trimIndent()
            }

            "networks" -> {
                val nets = apiGateway.getNetworks().data ?: emptyList()
                val sb = StringBuilder("=== CONNECTED INTERCHAIN NETWORKS (${nets.size}) ===\n")
                nets.forEach { n ->
                    sb.append(
                        String.format(
                            "%-10s | Height: %-9d | Latency: %-6s | Finality: %-25s | State: %s\n",
                            n.shortCode,
                            n.blockHeight,
                            "${n.blockLatencyMs}ms",
                            n.finalityModel.name,
                            n.healthState.name
                        )
                    )
                }
                sb.toString()
            }

            "peers" -> {
                val peers = apiGateway.getPeers().data ?: emptyList()
                val sb = StringBuilder("=== AUTHENTICATED P2P NODES (${peers.size}) ===\n")
                peers.forEach { p ->
                    sb.append(
                        String.format(
                            "%-28s | %-22s | Latency: %-4d ms | Relayed: %-8d | %s\n",
                            p.peerId.value,
                            p.region,
                            p.latencyMs,
                            p.messagesRelayed,
                            p.status.name
                        )
                    )
                }
                sb.toString()
            }

            "bridges" -> {
                val bridges = apiGateway.getBridges().data ?: emptyList()
                val sb = StringBuilder("=== REGISTERED INTERCHAIN BRIDGES (${bridges.size}) ===\n")
                bridges.forEach { b ->
                    sb.append(
                        "• ${b.name} (${b.bridgeId.value})\n  Route: ${b.sourceNetwork.value} → ${b.destinationNetwork.value}\n  Trust: ${b.trustModel.displayName}\n  Daily Limit: £${b.dailyLimitGbp} | Avg Latency: ${b.avgLatencySeconds}s | Status: ${b.status}\n\n"
                    )
                }
                sb.toString().trimEnd()
            }

            "pools" -> {
                val pools = apiGateway.getLiquidityPools().data ?: emptyList()
                val sb = StringBuilder("=== MCX & CROSS-CHAIN LIQUIDITY POOLS ===\n")
                pools.forEach { p ->
                    sb.append(
                        "• ${p.poolName} (${p.poolId.value})\n  Reserves: ${p.formattedReserveA} / ${p.formattedReserveB}\n  Total Depth: £${p.totalLiquidityGbp} | Fee: ${p.feeBps} bps | Utilisation: ${p.utilizationPercent}%\n\n"
                    )
                }
                sb.toString().trimEnd()
            }

            "corridor" -> {
                val result = simulationEngine.runManchesterCorridorScenario()
                if (result.isSuccess) {
                    val msg = result.getOrThrow()
                    """
                    >>> EXECUTING MANCHESTER INTERCHAIN CORRIDOR SCENARIO <<<
                    [1/6] Generated Cross-Chain Message: ${msg.messageId.value}
                    [2/6] Amount: ${msg.formattedAmount} (${msg.sourceNetwork.value} → ${msg.destinationNetwork.value})
                    [3/6] Source Tx Confirmed: ${msg.sourceTxHash?.value}
                    [4/6] Merkle Proof Attested: ${msg.proofMetadata?.proofId} [Status: ${msg.proofMetadata?.verificationStatus}]
                    [5/6] Destination Tx Confirmed: ${msg.destinationTxHash?.value}
                    [6/6] Finality Reached: SETTLED in ${msg.stateHistory.lastOrNull()?.timestamp?.minus(msg.createdAtTimestamp)} ms
                    Audit Anchor Hash: ${msg.stateHistory.lastOrNull()?.stateDigest}
                    """.trimIndent()
                } else {
                    "SCENARIO EXECUTION FAILED: ${result.exceptionOrNull()?.message}"
                }
            }

            "btc-gbp" -> {
                val result = simulationEngine.runBtcToGbpScenario()
                if (result.isSuccess) {
                    val msg = result.getOrThrow()
                    """
                    >>> BTC → MCX → SYNTHETIC GBP SETTLEMENT COMPLETE <<<
                    Message ID: ${msg.messageId.value}
                    Settled Amount: ${msg.formattedAmount}
                    State: ${msg.currentState}
                    Proof: ${msg.proofMetadata?.proofId} [${msg.proofMetadata?.verificationStatus}]
                    """.trimIndent()
                } else {
                    "Execution failed: ${result.exceptionOrNull()?.message}"
                }
            }

            "usdc-ingress" -> {
                val result = simulationEngine.runUsdcToManchesterScenario()
                if (result.isSuccess) {
                    val msg = result.getOrThrow()
                    """
                    >>> USDC INGRESS TO MANCHESTER CHAIN COMPLETE <<<
                    Message ID: ${msg.messageId.value}
                    Amount: ${msg.formattedAmount}
                    State: ${msg.currentState}
                    """.trimIndent()
                } else {
                    "Execution failed: ${result.exceptionOrNull()?.message}"
                }
            }

            "quote" -> {
                val amt = args.getOrNull(1)?.toDoubleOrNull() ?: 100_000.0
                val q = apiGateway.createQuote("net_manchester_main", "net_ethereum_main", "SGBP", "SGBP", amt).data
                if (q != null) {
                    """
                    === INTERCHAIN EXECUTABLE QUOTE ===
                    Quote ID:        ${q.quoteId.value}
                    Route:           ${q.route.pathName}
                    Input Amount:    ${q.inputAsset.formatAmount(q.inputAmount)}
                    Expected Output: ${q.outputAsset.formatAmount(q.expectedOutputAmount)}
                    Total Fee:       £${String.format(Locale.UK, "%.2f", q.totalFeeGbp)} (Network: £${q.networkFeeGbp}, Spread: £${String.format(Locale.UK, "%.2f", q.exchangeSpreadGbp)})
                    Slippage:        < 0.05%
                    Status:          ${q.status} (Valid for 120s)
                    Settlement Rail: ${q.route.settlementMechanism.displayName}
                    """.trimIndent()
                } else {
                    "Failed to generate quote for amount £$amt"
                }
            }

            "audit-verify" -> {
                val res = apiGateway.verifyAuditLedger().data
                if (res?.isChainValid == true) {
                    """
                    [AUDIT LEDGER VERIFICATION: SUCCESS]
                    Total Chained Audit Records Verified: ${res.totalEntriesVerified}
                    Integrity Status: 100% UNCOMPROMISED (Tamper-evident SHA-256 chain)
                    Ledger Tip Root Hash: ${res.rootHash}
                    Verification Timestamp: ${res.verifiedAtTimestamp}
                    """.trimIndent()
                } else {
                    "[AUDIT LEDGER VERIFICATION: FAILED] Broken record at sequence #${res?.brokenIndex}"
                }
            }

            "chaos" -> {
                val sub = args.getOrNull(1)?.lowercase(Locale.ROOT)
                when (sub) {
                    "outage" -> {
                        val net = args.getOrNull(2) ?: "net_ethereum_main"
                        simulationEngine.injectNetworkOutage(NetworkId(net))
                    }
                    "recover" -> {
                        val net = args.getOrNull(2) ?: "net_ethereum_main"
                        simulationEngine.recoverNetwork(NetworkId(net))
                    }
                    "replay" -> {
                        simulationEngine.injectReplayAttackSimulation()
                    }
                    "proof" -> {
                        simulationEngine.injectInvalidProofSimulation()
                    }
                    else -> "Usage: min chaos [outage <net_id> | recover <net_id> | replay | proof]"
                }
            }

            "clear" -> "__CLEAR__"

            else -> "Unknown command 'min ${args[0]}'. Type 'min help' for usage."
        }
    }
}
