package com.example.min.domain.model

data class NodeIdentity(
    val nodeId: NodeId,
    val operatorId: String,
    val operatorName: String,
    val nodePublicKeyHex: String,
    val softwareVersion: String,
    val protocolVersion: String,
    val region: String,
    val institution: String,
    val uptimeSeconds: Long,
    val startedAtTimestamp: Long,
    val supportedNetworks: List<NetworkId>,
    val capabilities: Set<String>
)

data class NodeEnvelope(
    val envelopeId: String,
    val senderNodeId: NodeId,
    val receiverNodeId: NodeId,
    val protocolVersion: String,
    val timestamp: Long,
    val nonce: Long,
    val payloadType: String,
    val payloadHash: String,
    val rawPayloadJson: String,
    val signatureHex: String,
    val signatureAlgorithm: String = "Ed25519-Institutional"
)

enum class PeerConnectionStatus {
    CONNECTED,
    HANDSHAKING,
    DISCONNECTED,
    BLOCKED
}

data class PeerNode(
    val peerId: NodeId,
    val operatorName: String,
    val addressUri: String,
    val region: String,
    val latencyMs: Long,
    val status: PeerConnectionStatus,
    val protocolVersion: String,
    val lastSeenTimestamp: Long,
    val messagesRelayed: Long
)

data class NodeMetrics(
    val blocksObserved: Long,
    val transactionsProcessed: Long,
    val messagesRouted: Long,
    val messagesSettled: Long,
    val messagesFailed: Long,
    val totalSettledVolumeGbp: Double,
    val averageSettlementLatencySeconds: Double,
    val activePeerCount: Int,
    val apiLatencyMs: Long,
    val messageBusQueueDepth: Int,
    val validationTps: Double,
    val proofVerificationSuccessRate: Double
)

data class DependencyHealth(
    val name: String,
    val isHealthy: Boolean,
    val latencyMs: Long,
    val message: String
)

data class NodeHealthReport(
    val isLivenessHealthy: Boolean,
    val isReadinessHealthy: Boolean,
    val networkHealthSummary: Map<NetworkId, NetworkHealthState>,
    val dependencies: List<DependencyHealth>,
    val activeAlerts: List<String>,
    val memoryUsageMb: Long,
    val uptimeSeconds: Long
)
