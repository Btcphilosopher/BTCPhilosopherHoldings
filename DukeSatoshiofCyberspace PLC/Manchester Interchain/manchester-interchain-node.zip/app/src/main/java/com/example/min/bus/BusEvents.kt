package com.example.min.bus

import com.example.min.domain.model.*

sealed interface BusEvent {
    val eventId: String
    val timestamp: Long
    val correlationId: String
    val topic: String
}

data class BlockObservedEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val networkId: NetworkId,
    val blockHeight: Long,
    val blockHash: BlockHash,
    val txCount: Int,
    val finalityConfidence: Double
) : BusEvent {
    override val topic: String = "blocks.${networkId.value}"
}

data class TransactionSeenEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val networkId: NetworkId,
    val txHash: TxHash,
    val from: Address,
    val to: Address,
    val assetId: AssetId,
    val amountFormatted: String
) : BusEvent {
    override val topic: String = "txs.seen.${networkId.value}"
}

data class TransactionConfirmedEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val networkId: NetworkId,
    val txHash: TxHash,
    val blockHeight: Long,
    val confirmations: Int,
    val isFinal: Boolean
) : BusEvent {
    override val topic: String = "txs.confirmed.${networkId.value}"
}

data class MessageCreatedEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val messageId: MessageId,
    val sourceNetwork: NetworkId,
    val destinationNetwork: NetworkId,
    val assetId: AssetId,
    val amountFormatted: String
) : BusEvent {
    override val topic: String = "message.created"
}

data class MessageValidatedEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val messageId: MessageId,
    val validationCheckSum: String
) : BusEvent {
    override val topic: String = "message.validated"
}

data class RouteSelectedEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val messageId: MessageId,
    val routeId: String,
    val hopsCount: Int,
    val feeGbp: Double,
    val settlementMechanism: SettlementMechanism
) : BusEvent {
    override val topic: String = "message.routed"
}

data class SourceSettledEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val messageId: MessageId,
    val sourceTxHash: TxHash,
    val sourceNetwork: NetworkId
) : BusEvent {
    override val topic: String = "message.source_settled"
}

data class ProofGeneratedEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val messageId: MessageId,
    val proofId: String,
    val proofType: ProofType,
    val rootHash: String
) : BusEvent {
    override val topic: String = "proof.generated"
}

data class ProofVerifiedEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val messageId: MessageId,
    val proofId: String,
    val verificationStatus: VerificationStatus,
    val verifiedByNodeId: NodeId
) : BusEvent {
    override val topic: String = "proof.verified"
}

data class DestinationSubmittedEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val messageId: MessageId,
    val destinationNetwork: NetworkId,
    val destinationTxHash: TxHash
) : BusEvent {
    override val topic: String = "message.destination_submitted"
}

data class DestinationConfirmedEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val messageId: MessageId,
    val destinationNetwork: NetworkId,
    val destinationTxHash: TxHash,
    val confirmations: Int
) : BusEvent {
    override val topic: String = "message.destination_confirmed"
}

data class InterchainSettledEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val messageId: MessageId,
    val sourceNetwork: NetworkId,
    val destinationNetwork: NetworkId,
    val settledAmountFormatted: String,
    val totalSettlementTimeMs: Long
) : BusEvent {
    override val topic: String = "message.settled"
}

data class MessageFailedEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val messageId: MessageId,
    val failureReason: String,
    val failedAtState: MessageState
) : BusEvent {
    override val topic: String = "message.failed"
}

data class ChaosInjectedEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val chaosType: String,
    val targetNetworkId: NetworkId?,
    val details: String
) : BusEvent {
    override val topic: String = "chaos.injected"
}

data class AuditLoggedEvent(
    override val eventId: String,
    override val timestamp: Long,
    override val correlationId: String,
    val auditEntry: AuditEntry
) : BusEvent {
    override val topic: String = "audit.entry"
}
