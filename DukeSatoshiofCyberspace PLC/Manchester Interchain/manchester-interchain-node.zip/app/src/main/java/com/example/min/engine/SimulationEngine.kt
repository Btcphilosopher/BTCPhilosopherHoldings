package com.example.min.engine

import com.example.min.adapter.AdapterRegistry
import com.example.min.bus.*
import com.example.min.domain.model.*
import kotlinx.coroutines.*
import java.math.BigInteger
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

class SimulationEngine(
    private val adapterRegistry: AdapterRegistry,
    private val settlementCoordinator: SettlementCoordinator,
    private val bus: InterchainMessageBus,
    private val auditLedger: AuditLedger,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) {
    private var simulationJob: Job? = null
    val isRunning = AtomicBoolean(false)

    fun startContinuousSimulation() {
        if (isRunning.getAndSet(true)) return

        simulationJob = scope.launch {
            // Block production loop
            launch {
                while (isActive && isRunning.get()) {
                    delay(1200)
                    // Produce blocks across adapters with varying cadences
                    val mnc = adapterRegistry.getAdapter(NetworkId("net_manchester_main"))
                    val eth = adapterRegistry.getAdapter(NetworkId("net_ethereum_main"))
                    val gbp = adapterRegistry.getAdapter(NetworkId("net_gbp_digital_clearing"))
                    val usd = adapterRegistry.getAdapter(NetworkId("net_stablecoin_clearing"))

                    mnc?.produceSimulatedBlock()
                    gbp?.produceSimulatedBlock()
                    if ((1..3).random() == 1) eth?.produceSimulatedBlock()
                    if ((1..2).random() == 1) usd?.produceSimulatedBlock()
                }
            }
        }
    }

    fun stopContinuousSimulation() {
        isRunning.set(false)
        simulationJob?.cancel()
        simulationJob = null
    }

    // Flagship Scenario 1: MANCHESTER INTERCHAIN CORRIDOR
    suspend fun runManchesterCorridorScenario(): Result<InterchainMessage> {
        bus.publish(
            ChaosInjectedEvent(
                eventId = "sim_${UUID.randomUUID().toString().take(8)}",
                timestamp = System.currentTimeMillis(),
                correlationId = "scenario_corridor",
                chaosType = "SCENARIO_TRIGGER",
                targetNetworkId = NetworkId("net_manchester_main"),
                details = "Flagship Scenario: Manchester Interchain Corridor (SGBP Manchester Chain → Ethereum Liquidity → BoE Settlement)"
            )
        )

        return settlementCoordinator.createAndExecuteMessage(
            sourceNetwork = NetworkId("net_manchester_main"),
            destinationNetwork = NetworkId("net_ethereum_main"),
            sender = Address("mnc1institution_clearing_vault_01"),
            recipient = Address("0x71C0a8D4A6e4f3aB7c9081e6F86f4a3D4B92e105"),
            assetId = AssetId("SGBP"),
            amount = BigInteger.valueOf(1_500_000_00L), // £1,500,000.00 SGBP
            memo = "Manchester Institutional Interchain Corridor SGBP Settlement"
        )
    }

    // Flagship Scenario 2: BTC -> MCX -> Synthetic GBP
    suspend fun runBtcToGbpScenario(): Result<InterchainMessage> {
        bus.publish(
            ChaosInjectedEvent(
                eventId = "sim_${UUID.randomUUID().toString().take(8)}",
                timestamp = System.currentTimeMillis(),
                correlationId = "scenario_btc_gbp",
                chaosType = "SCENARIO_TRIGGER",
                targetNetworkId = NetworkId("net_bitcoin_main"),
                details = "Flagship Scenario: Bitcoin Institutional Liquidity to Synthetic GBP via MCX AMM & Adaptor Signatures"
            )
        )

        return settlementCoordinator.createAndExecuteMessage(
            sourceNetwork = NetworkId("net_bitcoin_main"),
            destinationNetwork = NetworkId("net_manchester_main"),
            sender = Address("bc1q8institution_btc_coldvault_992"),
            recipient = Address("mnc1corporate_treasury_manchester_88"),
            assetId = AssetId("BTC"),
            amount = BigInteger.valueOf(25_00000000L), // 25.00000000 BTC (~£1.25M)
            memo = "Institutional Cross-Chain Conversion: BTC → MCX Liquidity → SGBP"
        )
    }

    // Flagship Scenario 3: USDC -> Ethereum -> Manchester Chain
    suspend fun runUsdcToManchesterScenario(): Result<InterchainMessage> {
        bus.publish(
            ChaosInjectedEvent(
                eventId = "sim_${UUID.randomUUID().toString().take(8)}",
                timestamp = System.currentTimeMillis(),
                correlationId = "scenario_usdc_mnc",
                chaosType = "SCENARIO_TRIGGER",
                targetNetworkId = NetworkId("net_stablecoin_clearing"),
                details = "Flagship Scenario: Cross-border USD Stablecoin Ingress to Manchester Chain Institutional Hub"
            )
        )

        return settlementCoordinator.createAndExecuteMessage(
            sourceNetwork = NetworkId("net_stablecoin_clearing"),
            destinationNetwork = NetworkId("net_manchester_main"),
            sender = Address("usd1institutional_clearing_depository"),
            recipient = Address("mnc1liquidity_provider_vault_44"),
            assetId = AssetId("USDC"),
            amount = BigInteger.valueOf(5_000_000_000000L), // $5,000,000.00 USDC
            memo = "USD Institutional Ingress via MIN Settlement Relayer"
        )
    }

    // FAILURE LABORATORY: Deterministic Chaos Injection
    suspend fun injectNetworkOutage(networkId: NetworkId): String {
        val adapter = adapterRegistry.getAdapter(networkId) ?: return "Network not found"
        adapter.setSimulationFailureMode(true, "Simulated network partitioned / RPC RPC_CONNECTION_REFUSED")

        bus.publish(
            ChaosInjectedEvent(
                eventId = "chaos_${UUID.randomUUID().toString().take(8)}",
                timestamp = System.currentTimeMillis(),
                correlationId = "chaos_outage_${networkId.value}",
                chaosType = "NETWORK_OUTAGE",
                targetNetworkId = networkId,
                details = "Injected network partition outage on ${adapter.network.name}. MIN node failover activated."
            )
        )

        auditLedger.record(
            entityType = "CHAOS",
            entityId = networkId.value,
            actor = "CHAOS_ENGINE",
            action = "NETWORK_OUTAGE_INJECTED",
            previousState = "HEALTHY",
            newState = "OUTAGE",
            sourceEvent = "OPERATOR_CHAOS_TEST",
            resultingEvent = "ADAPTER_PARTITION_SIMULATED",
            details = mapOf("network" to networkId.value)
        )

        return "Injected network outage on ${adapter.network.name}"
    }

    fun recoverNetwork(networkId: NetworkId): String {
        val adapter = adapterRegistry.getAdapter(networkId) ?: return "Network not found"
        adapter.setSimulationFailureMode(false, null)

        bus.publish(
            ChaosInjectedEvent(
                eventId = "chaos_${UUID.randomUUID().toString().take(8)}",
                timestamp = System.currentTimeMillis(),
                correlationId = "chaos_recover_${networkId.value}",
                chaosType = "NETWORK_RECOVERY",
                targetNetworkId = networkId,
                details = "Recovered network connectivity on ${adapter.network.name}."
            )
        )

        auditLedger.record(
            entityType = "CHAOS",
            entityId = networkId.value,
            actor = "CHAOS_ENGINE",
            action = "NETWORK_RECOVERED",
            previousState = "OUTAGE",
            newState = "HEALTHY",
            sourceEvent = "OPERATOR_CHAOS_RECOVERY",
            resultingEvent = "ADAPTER_ONLINE",
            details = mapOf("network" to networkId.value)
        )

        return "Recovered network ${adapter.network.name}"
    }

    suspend fun injectReplayAttackSimulation(): String {
        val lastSettled = settlementCoordinator.getAllMessages().find { it.currentState == MessageState.SETTLED }
        if (lastSettled == null) {
            return "No previous settled messages to replay. Run a corridor transaction first."
        }

        bus.publish(
            ChaosInjectedEvent(
                eventId = "chaos_${UUID.randomUUID().toString().take(8)}",
                timestamp = System.currentTimeMillis(),
                correlationId = "chaos_replay_attack",
                chaosType = "REPLAY_ATTACK_SIMULATION",
                targetNetworkId = lastSettled.destinationNetwork,
                details = "Attempting Byzantine replay of settled message ${lastSettled.messageId.value} with nonce ${lastSettled.nonce}..."
            )
        )

        val result = settlementCoordinator.executeWorkflow(lastSettled)
        val outcome = if (result.isFailure) {
            "DEFENDED: Replay attack successfully blocked by MIN Replay Protection Engine! [${result.exceptionOrNull()?.message}]"
        } else {
            "CRITICAL: Replay succeeded (unexpected)"
        }

        auditLedger.record(
            entityType = "CHAOS",
            entityId = lastSettled.messageId.value,
            actor = "CHAOS_ENGINE",
            action = "REPLAY_ATTACK_TEST",
            previousState = "SETTLED",
            newState = "DEFENDED",
            sourceEvent = "BYZANTINE_REPLAY_INJECTION",
            resultingEvent = "REPLAY_PROTECTION_AFFIRMED",
            details = mapOf("outcome" to outcome)
        )

        return outcome
    }

    suspend fun injectInvalidProofSimulation(): String {
        val now = System.currentTimeMillis()
        val messageId = MessageId("msg_byzantine_${now % 10000}")
        val corruptedMessage = InterchainMessage(
            messageId = messageId,
            sourceNetwork = NetworkId("net_manchester_main"),
            destinationNetwork = NetworkId("net_ethereum_main"),
            sender = Address("mnc1byzantine_adversary"),
            recipient = Address("0x000000000000000000000000000000000000dEaD"),
            assetId = AssetId("SGBP"),
            amount = BigInteger.valueOf(999_999_00L),
            formattedAmount = "£999,999.00 SGBP",
            nonce = 999999L,
            payloadHash = "0xinvalid_spoofed_hash_000000000000000000000000000000000000000000",
            createdAtTimestamp = now,
            expiresAtTimestamp = now + 60000L,
            currentState = MessageState.CREATED,
            sourceTxHash = TxHash("0xspoofed_tx_999"),
            destinationTxHash = null,
            routingMetadata = null,
            proofMetadata = MessageProofMetadata(
                proofId = "prf_corrupted",
                proofType = ProofType.MERKLE_INCLUSION,
                rootHash = "0xroot_mismatch",
                verificationStatus = VerificationStatus.INVALID,
                verifierNodeId = null,
                verifiedAtTimestamp = null
            ),
            stateHistory = emptyList(),
            correlationId = "byzantine_test"
        )

        bus.publish(
            ChaosInjectedEvent(
                eventId = "chaos_${UUID.randomUUID().toString().take(8)}",
                timestamp = now,
                correlationId = "byzantine_proof",
                chaosType = "INVALID_PROOF_INJECTION",
                targetNetworkId = NetworkId("net_ethereum_main"),
                details = "Injecting Byzantine message with forged Merkle proof and invalid state root..."
            )
        )

        val result = settlementCoordinator.executeWorkflow(corruptedMessage)
        val msg = if (result.isFailure) {
            "DEFENDED: Cryptographic Proof Verification Layer rejected invalid proof! [${result.exceptionOrNull()?.message}]"
        } else {
            "Accepted"
        }

        return msg
    }
}
