package com.example.min.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.min.domain.model.*
import com.example.ui.theme.*

@Composable
fun ManchesterNodeHeader(
    nodeIdentity: NodeIdentity,
    healthReport: NodeHealthReport,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("manchester_node_header"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalSurface),
        border = BorderStroke(1.dp, ManchesterGraphiteBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (healthReport.isReadinessHealthy) StatusSettledGreen else StatusFailedRed)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (healthReport.isReadinessHealthy) "NODE ONLINE • LIVE CLEARING" else "OUTAGE / DEGRADED",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (healthReport.isReadinessHealthy) StatusSettledGreen else StatusFailedRed,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = ManchesterBrickContainer,
                    border = BorderStroke(1.dp, ManchesterBrick)
                ) {
                    Text(
                        text = "MIN/1.4",
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = ManchesterSandstoneLight,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "MANCHESTER INTERCHAIN",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                letterSpacing = 2.sp,
                color = ManchesterIvoryText
            )
            Text(
                text = "CORE DIGITAL INTEROPERABILITY INFRASTRUCTURE • MANCHESTER, ENGLAND",
                style = MaterialTheme.typography.bodySmall,
                color = ManchesterBrass,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp,
                letterSpacing = 0.8.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Operator: ${nodeIdentity.operatorId}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ManchesterMutedText,
                    fontSize = 11.sp
                )
                Text(
                    text = "Region: ${nodeIdentity.region}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ManchesterMutedText,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun MetricDialCard(
    title: String,
    value: String,
    subValue: String,
    icon: ImageVector,
    accentColor: Color = ManchesterBrass,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.testTag("metric_card_${title.lowercase().replace(' ', '_')}"),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalCard),
        border = BorderStroke(1.dp, ManchesterGraphiteBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = ManchesterMutedText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    letterSpacing = 0.5.sp
                )
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = ManchesterIvoryText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subValue,
                style = MaterialTheme.typography.bodySmall,
                color = accentColor,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun MessageStateBadge(
    state: MessageState,
    modifier: Modifier = Modifier
) {
    val (bg, fg, border) = when (state) {
        MessageState.SETTLED -> Triple(StatusSettledBg, StatusSettledGreen, StatusSettledGreen)
        MessageState.ROUTED, MessageState.DESTINATION_SUBMITTED, MessageState.SOURCE_SUBMITTED ->
            Triple(StatusRoutingBg, StatusRoutingBlue, StatusRoutingBlue)
        MessageState.PROOF_AVAILABLE, MessageState.VALIDATED ->
            Triple(StatusProofBg, StatusProofPurple, StatusProofPurple)
        MessageState.CREATED, MessageState.SOURCE_CONFIRMED, MessageState.DESTINATION_CONFIRMED, MessageState.DESTINATION_AUTHORISED ->
            Triple(StatusPendingBg, StatusPendingAmber, StatusPendingAmber)
        MessageState.FAILED, MessageState.REJECTED, MessageState.EXPIRED, MessageState.MANUAL_REVIEW ->
            Triple(StatusFailedBg, StatusFailedRed, StatusFailedRed)
        MessageState.REFUNDED ->
            Triple(ManchesterBrickContainer, ManchesterSandstone, ManchesterBrick)
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(4.dp),
        color = bg,
        border = BorderStroke(0.8.dp, border.copy(alpha = 0.7f))
    ) {
        Text(
            text = state.label.uppercase(),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            fontWeight = FontWeight.Bold,
            fontSize = 9.sp,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    trailingAction: @Composable (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.titleSmall,
                color = ManchesterSandstone,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp
            )
            if (trailingAction != null) {
                trailingAction()
            }
        }
        if (subtitle != null) {
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = ManchesterSubtleText,
                fontSize = 11.sp
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Divider(color = ManchesterGraphiteDivider, thickness = 1.dp)
        Spacer(modifier = Modifier.height(10.dp))
    }
}

@Composable
fun ProofInspectorCard(
    proofAttestation: ProofAttestation,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalCardHover),
        border = BorderStroke(1.dp, ManchesterGraphiteBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "PROOF: ${proofAttestation.proofType}",
                    style = MaterialTheme.typography.labelSmall,
                    color = ManchesterBrassLight,
                    fontWeight = FontWeight.Bold
                )
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = when (proofAttestation.verificationStatus) {
                        VerificationStatus.VERIFIED -> StatusSettledBg
                        VerificationStatus.SIMULATED_VERIFICATION -> StatusRoutingBg
                        else -> StatusFailedBg
                    }
                ) {
                    Text(
                        text = proofAttestation.verificationStatus.name,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = when (proofAttestation.verificationStatus) {
                            VerificationStatus.VERIFIED -> StatusSettledGreen
                            VerificationStatus.SIMULATED_VERIFICATION -> StatusRoutingBlue
                            else -> StatusFailedRed
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "State Root: ${proofAttestation.rootHash}",
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                color = ManchesterMutedText,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = proofAttestation.cryptographicSummary,
                style = MaterialTheme.typography.bodySmall,
                color = ManchesterIvoryText,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun EventTickerRow(
    event: com.example.min.bus.BusEvent,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(4.dp),
        color = ManchesterCharcoalSurface,
        border = BorderStroke(0.5.dp, ManchesterGraphiteDivider)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = event.topic,
                    style = MaterialTheme.typography.labelSmall,
                    color = when {
                        event.topic.startsWith("blocks") -> StatusSettledGreen
                        event.topic.startsWith("message") -> StatusRoutingBlue
                        event.topic.startsWith("proof") -> StatusProofPurple
                        event.topic.startsWith("chaos") -> StatusFailedRed
                        else -> ManchesterBrass
                    },
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = when (event) {
                        is com.example.min.bus.BlockObservedEvent -> "Block #${event.blockHeight} finalized (${event.txCount} txs)"
                        is com.example.min.bus.InterchainSettledEvent -> "Settled: ${event.settledAmountFormatted} in ${event.totalSettlementTimeMs}ms"
                        is com.example.min.bus.RouteSelectedEvent -> "Route: ${event.routeId} (${event.hopsCount} hops, fee: £${event.feeGbp})"
                        is com.example.min.bus.ProofVerifiedEvent -> "Proof ${event.proofId} verified [${event.verificationStatus}]"
                        is com.example.min.bus.ChaosInjectedEvent -> "${event.chaosType}: ${event.details}"
                        else -> event.eventId
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = ManchesterIvoryText,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

