package com.example.min.adapter

import com.example.min.domain.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.math.BigInteger
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

abstract class BaseSimulatedAdapter(
    initialNetwork: ChainNetwork
) : ChainAdapter {

    @Volatile
    protected var currentNetwork: ChainNetwork = initialNetwork

    protected val mutex = Mutex()
    protected val currentBlockHeight = AtomicLong(initialNetwork.blockHeight)
    protected val blocks = ConcurrentHashMap<Long, BlockHeader>()
    protected val transactions = ConcurrentHashMap<TxHash, Transaction>()
    protected val receipts = ConcurrentHashMap<TxHash, TransactionReceipt>()
    protected val balances = ConcurrentHashMap<String, BigInteger>()

    protected val blockFlow = MutableSharedFlow<BlockHeader>(replay = 10, extraBufferCapacity = 50)
    protected val eventFlow = MutableSharedFlow<ChainEvent>(replay = 20, extraBufferCapacity = 100)

    protected val isFailureInjected = AtomicBoolean(false)
    protected var failureReason: String? = null
    @Volatile
    protected var congestionMultiplier: Double = 1.0

    init {
        // Seed genesis/latest block
        val genesisHeader = BlockHeader(
            networkId = initialNetwork.networkId,
            height = initialNetwork.blockHeight,
            hash = initialNetwork.latestBlockHash,
            parentHash = BlockHash("0x" + "0".repeat(64)),
            timestamp = System.currentTimeMillis() - 10000,
            transactionCount = 14,
            stateRoot = "0x" + sha256("state_${initialNetwork.networkId.value}"),
            proposer = "validator_01_${initialNetwork.shortCode.lowercase()}",
            finalized = true,
            finalityConfidence = 1.0
        )
        blocks[genesisHeader.height] = genesisHeader
    }

    override val network: ChainNetwork
        get() = currentNetwork

    override suspend fun getNetworkStatus(): ChainNetwork = mutex.withLock {
        val latest = blocks[currentBlockHeight.get()]
        currentNetwork = currentNetwork.copy(
            blockHeight = currentBlockHeight.get(),
            latestBlockHash = latest?.hash ?: currentNetwork.latestBlockHash,
            healthState = if (isFailureInjected.get()) NetworkHealthState.OUTAGE else currentNetwork.healthState
        )
        currentNetwork
    }

    override suspend fun getLatestBlock(): BlockHeader = mutex.withLock {
        blocks[currentBlockHeight.get()] ?: produceSimulatedBlock()
    }

    override suspend fun getBlockByHeight(height: Long): BlockHeader? = blocks[height]

    override suspend fun submitTransaction(
        from: Address,
        to: Address,
        assetId: AssetId,
        amount: BigInteger,
        payload: String?
    ): Result<TxHash> {
        if (isFailureInjected.get()) {
            return Result.failure(IllegalStateException(failureReason ?: "Network adapter outage injected on ${network.name}"))
        }

        if (!validateAddress(from) || !validateAddress(to)) {
            return Result.failure(IllegalArgumentException("Invalid address format for ${network.name}"))
        }

        val txHashString = "0x" + sha256("${network.networkId.value}:${from.value}:${to.value}:${amount}:${System.currentTimeMillis()}:${UUID.randomUUID()}")
        val txHash = TxHash(txHashString)

        val tx = Transaction(
            txHash = txHash,
            networkId = network.networkId,
            from = from,
            to = to,
            assetId = assetId,
            amount = amount,
            fee = calculateFee(amount),
            nonce = System.currentTimeMillis() % 100000,
            blockHeight = null,
            blockHash = null,
            status = TransactionStatus.PENDING,
            confirmations = 0,
            timestamp = System.currentTimeMillis(),
            rawPayload = payload
        )

        transactions[txHash] = tx
        return Result.success(txHash)
    }

    override suspend fun getTransaction(txHash: TxHash): Transaction? = transactions[txHash]

    override suspend fun getTransactionReceipt(txHash: TxHash): TransactionReceipt? = receipts[txHash]

    override suspend fun getBalance(address: Address, assetId: AssetId): AddressBalance {
        val key = "${address.value}_${assetId.value}"
        val confirmed = balances.getOrPut(key) {
            BigInteger.valueOf(500_000_000_000L) // Default healthy reserve
        }
        return AddressBalance(
            address = address,
            networkId = network.networkId,
            assetId = assetId,
            confirmedBalance = confirmed,
            pendingBalance = BigInteger.ZERO,
            lockedInSettlement = BigInteger.ZERO,
            spendableBalance = confirmed
        )
    }

    override fun observeBlocks(): Flow<BlockHeader> = blockFlow.asSharedFlow()
    override fun observeEvents(): Flow<ChainEvent> = eventFlow.asSharedFlow()

    override suspend fun produceSimulatedBlock(): BlockHeader = mutex.withLock {
        val nextHeight = currentBlockHeight.incrementAndGet()
        val prevBlock = blocks[nextHeight - 1]
        val parentHash = prevBlock?.hash ?: BlockHash("0x" + "0".repeat(64))
        val blockHash = BlockHash("0x" + sha256("${network.networkId.value}:$nextHeight:${System.currentTimeMillis()}"))

        val finalized = isHeightFinalized(nextHeight)
        val confidence = calculateFinalityConfidence(nextHeight)

        // Process pending transactions
        val pendingTxs = transactions.values.filter { it.status == TransactionStatus.PENDING }.take(10)
        pendingTxs.forEach { tx ->
            val includedTx = tx.copy(
                blockHeight = nextHeight,
                blockHash = blockHash,
                status = TransactionStatus.CONFIRMED,
                confirmations = 1
            )
            transactions[tx.txHash] = includedTx

            val event = ChainEvent(
                eventId = "ev_${UUID.randomUUID().toString().take(8)}",
                networkId = network.networkId,
                blockHeight = nextHeight,
                txHash = tx.txHash,
                eventName = "InterchainTransferExecuted",
                contractOrRail = tx.to,
                attributes = mapOf(
                    "from" to tx.from.value,
                    "to" to tx.to.value,
                    "amount" to tx.amount.toString(),
                    "asset" to tx.assetId.value
                ),
                timestamp = System.currentTimeMillis()
            )

            receipts[tx.txHash] = TransactionReceipt(
                txHash = tx.txHash,
                networkId = network.networkId,
                blockHeight = nextHeight,
                blockHash = blockHash,
                confirmations = 1,
                status = TransactionStatus.CONFIRMED,
                gasUsedOrFee = tx.fee,
                events = listOf(event),
                timestamp = System.currentTimeMillis()
            )

            eventFlow.tryEmit(event)
        }

        // Update confirmations for older transactions
        transactions.values.filter { it.blockHeight != null && it.status == TransactionStatus.CONFIRMED }.forEach { tx ->
            val confs = (nextHeight - tx.blockHeight!! + 1).toInt()
            if (confs > tx.confirmations) {
                val isFinal = confs >= network.confirmationPolicy.standardConfirmations
                transactions[tx.txHash] = tx.copy(
                    confirmations = confs,
                    status = if (isFinal) TransactionStatus.FINALIZED else TransactionStatus.CONFIRMED
                )
            }
        }

        val header = BlockHeader(
            networkId = network.networkId,
            height = nextHeight,
            hash = blockHash,
            parentHash = parentHash,
            timestamp = System.currentTimeMillis(),
            transactionCount = pendingTxs.size + (2..18).random(),
            stateRoot = "0x" + sha256("state_$nextHeight"),
            proposer = "val_${network.shortCode.lowercase()}_${(1..5).random()}",
            finalized = finalized,
            finalityConfidence = confidence
        )

        blocks[nextHeight] = header
        currentNetwork = currentNetwork.copy(
            blockHeight = nextHeight,
            latestBlockHash = blockHash,
            totalTransactionsObserved = currentNetwork.totalTransactionsObserved + header.transactionCount
        )

        blockFlow.tryEmit(header)
        header
    }

    override fun setCongestionLevel(multiplier: Double) {
        this.congestionMultiplier = multiplier
    }

    override fun setSimulationFailureMode(shouldFail: Boolean, reason: String?) {
        this.isFailureInjected.set(shouldFail)
        this.failureReason = reason
    }

    protected abstract fun calculateFee(amount: BigInteger): BigInteger
    protected abstract fun isHeightFinalized(height: Long): Boolean
    protected abstract fun calculateFinalityConfidence(height: Long): Double

    protected fun sha256(input: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(input.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }
}
