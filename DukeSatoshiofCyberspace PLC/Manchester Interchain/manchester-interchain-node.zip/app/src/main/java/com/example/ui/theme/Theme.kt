package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ManchesterBrickLight,
    onPrimary = Color.White,
    primaryContainer = ManchesterBrickContainer,
    onPrimaryContainer = ManchesterSandstoneLight,

    secondary = ManchesterSandstone,
    onSecondary = ManchesterCharcoalBg,
    secondaryContainer = ManchesterCharcoalCardHover,
    onSecondaryContainer = ManchesterSandstoneLight,

    tertiary = ManchesterBrass,
    onTertiary = ManchesterCharcoalBg,
    tertiaryContainer = ManchesterBrassDark,
    onTertiaryContainer = ManchesterBrassLight,

    background = ManchesterCharcoalBg,
    onBackground = ManchesterIvoryText,
    surface = ManchesterCharcoalSurface,
    onSurface = ManchesterIvoryText,
    surfaceVariant = ManchesterCharcoalCard,
    onSurfaceVariant = ManchesterMutedText,
    outline = ManchesterGraphiteBorder,
    outlineVariant = ManchesterGraphiteDivider
)

private val LightColorScheme = lightColorScheme(
    primary = ManchesterBrick,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDAD8),
    onPrimaryContainer = ManchesterBrickDark,

    secondary = Color(0xFF6E5D4E),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF7DECD),
    onSecondaryContainer = Color(0xFF261A0F),

    tertiary = ManchesterBrassDark,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFDE9F),
    onTertiaryContainer = Color(0xFF271900),

    background = Color(0xFFFAF7F2),
    onBackground = Color(0xFF1B1B1C),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1B1B1C),
    surfaceVariant = Color(0xFFECE6DD),
    onSurfaceVariant = Color(0xFF4C453C),
    outline = Color(0xFF7E756B)
)

@Composable
fun ManchesterInterchainTheme(
    darkTheme: Boolean = true, // Institutional node defaults to dark operational mode
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
