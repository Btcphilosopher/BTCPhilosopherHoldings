package com.example.min.domain.state

import com.example.min.domain.model.InterchainMessage
import com.example.min.domain.model.MessageState
import com.example.min.domain.model.NodeId
import com.example.min.domain.model.StateTransitionRecord
import java.security.MessageDigest
import java.util.UUID

class InvalidStateTransitionException(
    val fromState: MessageState,
    val toState: MessageState,
    message: String
) : IllegalStateException("Invalid interchain state transition from $fromState to $toState: $message")

object MessageStateMachine {

    private val validTransitions: Map<MessageState, Set<MessageState>> = mapOf(
        MessageState.CREATED to setOf(
            MessageState.VALIDATED,
            MessageState.REJECTED,
            MessageState.EXPIRED,
            MessageState.FAILED
        ),
        MessageState.VALIDATED to setOf(
            MessageState.ROUTED,
            MessageState.REJECTED,
            MessageState.EXPIRED,
            MessageState.FAILED
        ),
        MessageState.ROUTED to setOf(
            MessageState.SOURCE_SUBMITTED,
            MessageState.EXPIRED,
            MessageState.FAILED,
            MessageState.REJECTED
        ),
        MessageState.SOURCE_SUBMITTED to setOf(
            MessageState.SOURCE_CONFIRMED,
            MessageState.FAILED,
            MessageState.EXPIRED,
            MessageState.MANUAL_REVIEW
        ),
        MessageState.SOURCE_CONFIRMED to setOf(
            MessageState.PROOF_AVAILABLE,
            MessageState.FAILED,
            MessageState.REFUNDED,
            MessageState.MANUAL_REVIEW
        ),
        MessageState.PROOF_AVAILABLE to setOf(
            MessageState.DESTINATION_AUTHORISED,
            MessageState.FAILED,
            MessageState.REFUNDED,
            MessageState.MANUAL_REVIEW
        ),
        MessageState.DESTINATION_AUTHORISED to setOf(
            MessageState.DESTINATION_SUBMITTED,
            MessageState.FAILED,
            MessageState.REFUNDED,
            MessageState.MANUAL_REVIEW
        ),
        MessageState.DESTINATION_SUBMITTED to setOf(
            MessageState.DESTINATION_CONFIRMED,
            MessageState.FAILED,
            MessageState.MANUAL_REVIEW
        ),
        MessageState.DESTINATION_CONFIRMED to setOf(
            MessageState.SETTLED,
            MessageState.FAILED,
            MessageState.MANUAL_REVIEW
        ),
        MessageState.MANUAL_REVIEW to setOf(
            MessageState.DESTINATION_AUTHORISED,
            MessageState.DESTINATION_SUBMITTED,
            MessageState.REFUNDED,
            MessageState.REJECTED,
            MessageState.FAILED,
            MessageState.SETTLED
        ),
        MessageState.FAILED to setOf(
            MessageState.REFUNDED,
            MessageState.MANUAL_REVIEW
        ),
        // Pure terminal states
        MessageState.SETTLED to emptySet(),
        MessageState.REJECTED to emptySet(),
        MessageState.EXPIRED to emptySet(),
        MessageState.REFUNDED to emptySet()
    )

    fun canTransition(from: MessageState, to: MessageState): Boolean {
        return validTransitions[from]?.contains(to) == true
    }

    fun transition(
        message: InterchainMessage,
        newState: MessageState,
        reasonOrTxHash: String,
        actorNodeId: NodeId,
        currentTime: Long = System.currentTimeMillis()
    ): InterchainMessage {
        val currentState = message.currentState
        if (!canTransition(currentState, newState)) {
            throw InvalidStateTransitionException(
                fromState = currentState,
                toState = newState,
                message = "Deterministic state machine prohibited transition."
            )
        }

        val digestInput = "${message.messageId.value}:${currentState}:${newState}:${currentTime}:${reasonOrTxHash}"
        val digest = sha256(digestInput)

        val record = StateTransitionRecord(
            transitionId = "tr_${UUID.randomUUID().toString().take(8)}",
            fromState = currentState,
            toState = newState,
            timestamp = currentTime,
            reasonOrTxHash = reasonOrTxHash,
            actorNodeId = actorNodeId,
            stateDigest = digest
        )

        val updatedHistory = message.stateHistory + record

        return message.copy(
            currentState = newState,
            stateHistory = updatedHistory,
            failureReason = if (newState.isFailure) reasonOrTxHash else message.failureReason
        )
    }

    private fun sha256(input: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(input.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }
}
