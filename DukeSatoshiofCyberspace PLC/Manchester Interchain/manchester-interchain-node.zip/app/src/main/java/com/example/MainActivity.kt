package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.min.ui.screens.*
import com.example.min.ui.viewmodel.MinNodeViewModel
import com.example.ui.theme.ManchesterCharcoalBg
import com.example.ui.theme.ManchesterCharcoalSurface
import com.example.ui.theme.ManchesterGraphiteBorder
import com.example.ui.theme.ManchesterGraphiteDivider
import com.example.ui.theme.ManchesterInterchainTheme
import com.example.ui.theme.ManchesterIvoryText
import com.example.ui.theme.ManchesterMutedText
import com.example.ui.theme.ManchesterSandstone

enum class MinScreen(val title: String, val icon: ImageVector) {
    OVERVIEW("Overview", Icons.Default.Dashboard),
    ROUTER("Router", Icons.Default.Route),
    NETWORKS("Chains", Icons.Default.Hub),
    LEDGER("Ledger", Icons.Default.ReceiptLong),
    FAILURE_LAB("Failure Lab", Icons.Default.BugReport),
    GATEWAY("API & CLI", Icons.Default.Terminal)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ManchesterInterchainTheme(darkTheme = true) {
                MinAppContent()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MinAppContent(
    viewModel: MinNodeViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var currentScreen by remember { mutableStateOf(MinScreen.OVERVIEW) }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(ManchesterCharcoalBg),
        containerColor = ManchesterCharcoalBg,
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("main_navigation_bar"),
                containerColor = ManchesterCharcoalSurface,
                tonalElevation = 8.dp
            ) {
                MinScreen.values().forEach { screen ->
                    val isSelected = currentScreen == screen
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentScreen = screen },
                        icon = {
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = screen.title,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = screen.title,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ManchesterIvoryText,
                            selectedTextColor = ManchesterSandstone,
                            indicatorColor = com.example.ui.theme.ManchesterBrick,
                            unselectedIconColor = ManchesterMutedText,
                            unselectedTextColor = ManchesterMutedText
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            when (currentScreen) {
                MinScreen.OVERVIEW -> NodeOverviewScreen(
                    state = uiState,
                    onRunCorridor = { viewModel.runCorridorScenario() },
                    onRunBtcScenario = { viewModel.runBtcToGbpScenario() },
                    onRunUsdcScenario = { viewModel.runUsdcIngressScenario() },
                    onNavigateToRouter = { currentScreen = MinScreen.ROUTER }
                )
                MinScreen.ROUTER -> RouterScreen(
                    state = uiState,
                    onRequestQuote = { src, dst, inAsset, outAsset, amt ->
                        viewModel.requestQuote(src, dst, inAsset, outAsset, amt)
                    },
                    onExecuteQuote = { viewModel.executeActiveQuote() }
                )
                MinScreen.NETWORKS -> NetworksScreen(
                    state = uiState
                )
                MinScreen.LEDGER -> MessagesScreen(
                    state = uiState
                )
                MinScreen.FAILURE_LAB -> FailureLabScreen(
                    state = uiState,
                    onInjectOutage = { net -> viewModel.injectNetworkOutage(net) },
                    onRecoverOutage = { net -> viewModel.recoverNetwork(net) },
                    onInjectReplayAttack = { viewModel.injectReplayAttack() },
                    onInjectInvalidProof = { viewModel.injectInvalidProof() },
                    onVerifyAuditLedger = { viewModel.verifyAuditChain() }
                )
                MinScreen.GATEWAY -> {
                    var isTerminalTab by remember { mutableStateOf(false) }
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = !isTerminalTab,
                                onClick = { isTerminalTab = false },
                                label = { Text("REST API & WebSocket", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = com.example.ui.theme.ManchesterBrick,
                                    selectedLabelColor = Color.White
                                )
                            )
                            FilterChip(
                                selected = isTerminalTab,
                                onClick = { isTerminalTab = true },
                                label = { Text("MIN Interactive CLI", fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = com.example.ui.theme.ManchesterBrick,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                        if (isTerminalTab) {
                            TerminalScreen(
                                state = uiState,
                                onExecuteCommand = { cmd -> viewModel.executeCliCommand(cmd) }
                            )
                        } else {
                            ApiGatewayScreen(
                                state = uiState,
                                onSelectTopicFilter = { topic -> viewModel.setTopicFilter(topic) }
                            )
                        }
                    }
                }
            }
        }
    }
}
