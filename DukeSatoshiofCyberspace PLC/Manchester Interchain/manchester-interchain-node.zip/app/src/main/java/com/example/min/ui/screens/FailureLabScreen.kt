package com.example.min.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.min.domain.model.NetworkId
import com.example.min.ui.components.SectionHeader
import com.example.min.ui.viewmodel.NodeUiState
import com.example.ui.theme.*

@Composable
fun FailureLabScreen(
    state: NodeUiState,
    onInjectOutage: (NetworkId) -> Unit,
    onRecoverOutage: (NetworkId) -> Unit,
    onInjectReplayAttack: () -> Unit,
    onInjectInvalidProof: () -> Unit,
    onVerifyAuditLedger: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Chaos & Resilience Failure Laboratory",
                subtitle = "Inject deterministic faults, partition attacks & verify node defense mechanisms"
            )
        }

        // 1. Status Callout
        if (state.chaosStatusMessage != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = ManchesterBrickContainer),
                    border = BorderStroke(1.dp, ManchesterBrick)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = ManchesterSandstoneLight, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "CHAOS TEST BENCH RESULT",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = ManchesterSandstoneLight
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = state.chaosStatusMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = ManchesterIvoryText,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // 2. Byzantine Fault Injections
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalSurface),
                border = BorderStroke(1.dp, ManchesterGraphiteBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "BYZANTINE ATTACK SIMULATIONS",
                        style = MaterialTheme.typography.labelSmall,
                        color = ManchesterBrass,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Verify that duplicate messages, replay attacks, or forged Merkle roots are deterministically repelled.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ManchesterMutedText,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = onInjectReplayAttack,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("inject_replay_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = StatusFailedBg),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, StatusFailedRed)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, tint = StatusFailedRed, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Simulate Byzantine Message Replay Attack", color = ManchesterIvoryText, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = onInjectInvalidProof,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("inject_proof_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = ManchesterCharcoalCardHover),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, StatusProofPurple)
                    ) {
                        Icon(Icons.Default.GppBad, contentDescription = null, tint = StatusProofPurple, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Inject Corrupted Merkle State Root Proof", color = ManchesterIvoryText, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 3. Network Outage Injections
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalSurface),
                border = BorderStroke(1.dp, ManchesterGraphiteBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "ADAPTER NETWORK PARTITIONS",
                        style = MaterialTheme.typography.labelSmall,
                        color = ManchesterBrass,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Partition specific chain adapters to trigger automatic failover routing and manual intervention states.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ManchesterMutedText,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onInjectOutage(NetworkId("net_ethereum_main")) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("outage_eth_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = StatusFailedBg),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("Partition ETH-NET", fontSize = 11.sp, color = ManchesterIvoryText)
                        }

                        OutlinedButton(
                            onClick = { onRecoverOutage(NetworkId("net_ethereum_main")) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("recover_eth_button"),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, StatusSettledGreen),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusSettledGreen)
                        ) {
                            Text("Recover ETH-NET", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // 4. Cryptographic Audit Ledger Verification
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalSurface),
                border = BorderStroke(1.dp, ManchesterGraphiteBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "IMMUTABLE AUDIT LEDGER INTEGRITY",
                        style = MaterialTheme.typography.labelSmall,
                        color = ManchesterBrass,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Verify the complete SHA-256 hash-chained history of all node transitions since genesis.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ManchesterMutedText,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onVerifyAuditLedger,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("verify_audit_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = ManchesterBrick),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(Icons.Default.FactCheck, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Verify Complete Audit Ledger Chain", fontWeight = FontWeight.Bold)
                    }

                    if (state.auditVerification != null) {
                        val ver = state.auditVerification
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (ver.isChainValid) StatusSettledBg else StatusFailedBg
                        ) {
                            Text(
                                text = if (ver.isChainValid)
                                    "✓ INTEGRITY VERIFIED: ${ver.totalEntriesVerified} records validated against tip ${ver.rootHash.take(16)}..."
                                else
                                    "✗ INTEGRITY COMPROMISED at sequence #${ver.brokenIndex}",
                                modifier = Modifier.padding(8.dp),
                                style = MaterialTheme.typography.bodySmall,
                                color = if (ver.isChainValid) StatusSettledGreen else StatusFailedRed,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
