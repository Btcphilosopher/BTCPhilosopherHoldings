package com.example.min.domain.model

import java.math.BigInteger

enum class SettlementMechanism(val displayName: String, val isAtomic: Boolean) {
    ATOMIC_HTLC("Hash Time-Locked Contract (Atomic)", true),
    ESCROW_LOCK_RELEASE("Institutional Escrow Lock & Release", false),
    ADAPTOR_SIGNATURE("Schnorr / ECDSA Adaptor Signature", true),
    BRIDGE_MINT_BURN("Canonical Bridge Mint / Burn", false),
    SIMULATED_INTERCHAIN("Simulated Sandbox Clearing", true)
}

enum class RouteRiskFlag(val label: String, val severity: String) {
    HIGH_FINALITY_LATENCY("High Finality Latency (>10 min)", "WARNING"),
    LOW_BRIDGE_CAPACITY("Bridge Nearing Daily Capacity", "WARNING"),
    HIGH_SLIPPAGE("Elevated AMM Slippage", "INFO"),
    ASYMMETRIC_TRUST("Multi-Sig Validator Trust Model", "INFO"),
    UNVERIFIED_VALIDATOR("Non-Federated Validator Set", "CRITICAL")
}

data class RouteHop(
    val hopIndex: Int,
    val fromNetwork: NetworkId,
    val toNetwork: NetworkId,
    val bridgeId: BridgeId?,
    val inputAssetId: AssetId,
    val outputAssetId: AssetId,
    val estimatedFeeGbp: Double,
    val expectedDelaySeconds: Long,
    val description: String
)

data class InterchainRoute(
    val routeId: String,
    val sourceNetwork: NetworkId,
    val destinationNetwork: NetworkId,
    val inputAssetId: AssetId,
    val outputAssetId: AssetId,
    val hops: List<RouteHop>,
    val totalEstimatedFeeGbp: Double,
    val expectedSettlementTimeSeconds: Long,
    val riskFlags: List<RouteRiskFlag>,
    val settlementMechanism: SettlementMechanism,
    val confidenceScore: Double, // 0.0 to 1.0
    val maxTransferLimitGbp: Double,
    val pathName: String
)

enum class QuoteStatus {
    QUOTED,
    LOCKED,
    EXECUTED,
    EXPIRED,
    SETTLED
}

data class InterchainQuote(
    val quoteId: QuoteId,
    val route: InterchainRoute,
    val inputAsset: Asset,
    val outputAsset: Asset,
    val inputAmount: BigInteger,
    val expectedOutputAmount: BigInteger,
    val minimumOutputAmount: BigInteger,
    val exchangeRateFormatted: String,
    val exchangeSpreadGbp: Double,
    val networkFeeGbp: Double,
    val bridgeFeeGbp: Double,
    val totalFeeGbp: Double,
    val createdAtTimestamp: Long,
    val expiresAtTimestamp: Long,
    val status: QuoteStatus,
    val lockedUntilTimestamp: Long? = null
)
