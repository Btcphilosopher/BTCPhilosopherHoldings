package com.example.min.engine

import com.example.min.adapter.AdapterRegistry
import com.example.min.bus.*
import com.example.min.domain.model.*
import com.example.min.domain.state.MessageStateMachine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.math.BigInteger
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class SettlementCoordinator(
    private val adapterRegistry: AdapterRegistry,
    private val validationEngine: ValidationEngine,
    private val router: InterchainRouter,
    private val proofVerificationLayer: ProofVerificationLayer,
    private val auditLedger: AuditLedger,
    private val bus: InterchainMessageBus,
    private val localNodeId: NodeId = NodeId("node_manchester_uk_01")
) {
    private val messages = ConcurrentHashMap<MessageId, InterchainMessage>()

    fun getMessage(messageId: MessageId): InterchainMessage? = messages[messageId]
    fun getAllMessages(): List<InterchainMessage> = messages.values.toList().sortedByDescending { it.createdAtTimestamp }

    suspend fun createAndExecuteMessage(
        sourceNetwork: NetworkId,
        destinationNetwork: NetworkId,
        sender: Address,
        recipient: Address,
        assetId: AssetId,
        amount: BigInteger,
        memo: String? = null
    ): Result<InterchainMessage> {
        val now = System.currentTimeMillis()
        val messageId = MessageId("msg_${now % 100000}_${UUID.randomUUID().toString().take(6)}")
        val asset = adapterRegistry.getAsset(assetId)
            ?: return Result.failure(IllegalArgumentException("Asset $assetId unknown"))

        val payloadHash = "0x" + sha256("${messageId.value}:${sourceNetwork.value}:${destinationNetwork.value}:${amount}:${sender.value}:${recipient.value}:$now")

        val initialMessage = InterchainMessage(
            messageId = messageId,
            sourceNetwork = sourceNetwork,
            destinationNetwork = destinationNetwork,
            sender = sender,
            recipient = recipient,
            assetId = assetId,
            amount = amount,
            formattedAmount = asset.formatAmount(amount),
            nonce = now % 1000000,
            payloadHash = payloadHash,
            createdAtTimestamp = now,
            expiresAtTimestamp = now + 300_000L, // 5 min expiry
            currentState = MessageState.CREATED,
            sourceTxHash = null,
            destinationTxHash = null,
            routingMetadata = null,
            proofMetadata = null,
            stateHistory = emptyList(),
            correlationId = "corr_${UUID.randomUUID().toString().take(8)}",
            memo = memo
        )

        messages[messageId] = initialMessage

        bus.publish(
            MessageCreatedEvent(
                eventId = "ev_${UUID.randomUUID().toString().take(8)}",
                timestamp = now,
                correlationId = initialMessage.correlationId,
                messageId = messageId,
                sourceNetwork = sourceNetwork,
                destinationNetwork = destinationNetwork,
                assetId = assetId,
                amountFormatted = initialMessage.formattedAmount
            )
        )

        auditLedger.record(
            entityType = "MESSAGE",
            entityId = messageId.value,
            actor = "SETTLEMENT_COORDINATOR",
            action = "MESSAGE_CREATED",
            previousState = null,
            newState = MessageState.CREATED.name,
            sourceEvent = "USER_SUBMISSION",
            resultingEvent = "MESSAGE_INITIALIZED",
            details = mapOf(
                "source" to sourceNetwork.value,
                "destination" to destinationNetwork.value,
                "amount" to initialMessage.formattedAmount
            )
        )

        // Run full orchestrated workflow asynchronously
        return executeWorkflow(initialMessage)
    }

    suspend fun executeWorkflow(message: InterchainMessage): Result<InterchainMessage> {
        var current = message

        // 1. VALIDATION
        val valResult = validationEngine.validateMessage(current)
        if (valResult is ValidationResult.Invalid) {
            current = MessageStateMachine.transition(
                message = current,
                newState = MessageState.REJECTED,
                reasonOrTxHash = valResult.reason,
                actorNodeId = localNodeId
            )
            messages[current.messageId] = current
            bus.publish(
                MessageFailedEvent(
                    eventId = "ev_${UUID.randomUUID().toString().take(8)}",
                    timestamp = System.currentTimeMillis(),
                    correlationId = current.correlationId,
                    messageId = current.messageId,
                    failureReason = valResult.reason,
                    failedAtState = MessageState.CREATED
                )
            )
            auditLedger.record(
                entityType = "MESSAGE",
                entityId = current.messageId.value,
                actor = "VALIDATION_ENGINE",
                action = "MESSAGE_REJECTED",
                previousState = MessageState.CREATED.name,
                newState = MessageState.REJECTED.name,
                sourceEvent = "VALIDATION_CHECK",
                resultingEvent = "REJECTION_RECORDED",
                details = mapOf("reason" to valResult.reason)
            )
            return Result.failure(IllegalStateException("Validation rejected: ${valResult.reason}"))
        }

        current = MessageStateMachine.transition(
            message = current,
            newState = MessageState.VALIDATED,
            reasonOrTxHash = (valResult as ValidationResult.Valid).checksum,
            actorNodeId = localNodeId
        )
        messages[current.messageId] = current
        bus.publish(
            MessageValidatedEvent(
                eventId = "ev_${UUID.randomUUID().toString().take(8)}",
                timestamp = System.currentTimeMillis(),
                correlationId = current.correlationId,
                messageId = current.messageId,
                validationCheckSum = valResult.checksum
            )
        )

        // 2. ROUTING
        val routes = router.findRoutes(current.sourceNetwork, current.destinationNetwork, current.assetId, current.assetId)
        val selectedRoute = routes.firstOrNull() ?: InterchainRoute(
            routeId = "rte_direct_fallback",
            sourceNetwork = current.sourceNetwork,
            destinationNetwork = current.destinationNetwork,
            inputAssetId = current.assetId,
            outputAssetId = current.assetId,
            hops = emptyList(),
            totalEstimatedFeeGbp = 1.0,
            expectedSettlementTimeSeconds = 5,
            riskFlags = emptyList(),
            settlementMechanism = SettlementMechanism.ESCROW_LOCK_RELEASE,
            confidenceScore = 0.99,
            maxTransferLimitGbp = 10_000_000.0,
            pathName = "Standard Institutional Settlement Channel"
        )

        val routeMeta = MessageRoutingMetadata(
            selectedRouteId = selectedRoute.routeId,
            settlementMechanism = selectedRoute.settlementMechanism,
            hopsCount = selectedRoute.hops.size.coerceAtLeast(1),
            feeGbp = selectedRoute.totalEstimatedFeeGbp,
            deadlineTimestamp = current.createdAtTimestamp + (selectedRoute.expectedSettlementTimeSeconds * 1000L) + 60000L
        )
        current = current.copy(routingMetadata = routeMeta)
        current = MessageStateMachine.transition(
            message = current,
            newState = MessageState.ROUTED,
            reasonOrTxHash = selectedRoute.routeId,
            actorNodeId = localNodeId
        )
        messages[current.messageId] = current
        bus.publish(
            RouteSelectedEvent(
                eventId = "ev_${UUID.randomUUID().toString().take(8)}",
                timestamp = System.currentTimeMillis(),
                correlationId = current.correlationId,
                messageId = current.messageId,
                routeId = selectedRoute.routeId,
                hopsCount = routeMeta.hopsCount,
                feeGbp = routeMeta.feeGbp,
                settlementMechanism = routeMeta.settlementMechanism
            )
        )

        // 3. SOURCE SUBMITTED
        val srcAdapter = adapterRegistry.getAdapter(current.sourceNetwork)!!
        val srcTxResult = srcAdapter.submitTransaction(
            from = current.sender,
            to = Address("escrow_vault_${current.sourceNetwork.value.takeLast(4)}"),
            assetId = current.assetId,
            amount = current.amount,
            payload = "min_lock:${current.messageId.value}:${current.payloadHash}"
        )

        if (srcTxResult.isFailure) {
            val err = srcTxResult.exceptionOrNull()?.message ?: "Source submission failed"
            current = MessageStateMachine.transition(
                message = current,
                newState = MessageState.FAILED,
                reasonOrTxHash = err,
                actorNodeId = localNodeId
            )
            messages[current.messageId] = current
            return Result.failure(IllegalStateException(err))
        }

        val srcTxHash = srcTxResult.getOrThrow()
        current = current.copy(sourceTxHash = srcTxHash)
        current = MessageStateMachine.transition(
            message = current,
            newState = MessageState.SOURCE_SUBMITTED,
            reasonOrTxHash = srcTxHash.value,
            actorNodeId = localNodeId
        )
        messages[current.messageId] = current

        // 4. SOURCE CONFIRMED (produce block on source if needed)
        val srcBlock = srcAdapter.produceSimulatedBlock()
        current = MessageStateMachine.transition(
            message = current,
            newState = MessageState.SOURCE_CONFIRMED,
            reasonOrTxHash = "block_${srcBlock.height}_${srcTxHash.value}",
            actorNodeId = localNodeId
        )
        messages[current.messageId] = current
        bus.publish(
            SourceSettledEvent(
                eventId = "ev_${UUID.randomUUID().toString().take(8)}",
                timestamp = System.currentTimeMillis(),
                correlationId = current.correlationId,
                messageId = current.messageId,
                sourceTxHash = srcTxHash,
                sourceNetwork = current.sourceNetwork
            )
        )

        // 5. PROOF AVAILABLE
        val rawProof = proofVerificationLayer.generateSimulatedProof(current, srcBlock)
        val verifiedProof = proofVerificationLayer.verifyProof(current, rawProof)
        val proofMeta = MessageProofMetadata(
            proofId = verifiedProof.proofId,
            proofType = verifiedProof.proofType,
            rootHash = verifiedProof.rootHash,
            verificationStatus = verifiedProof.verificationStatus,
            verifierNodeId = verifiedProof.verifiedByNodeId,
            verifiedAtTimestamp = verifiedProof.verifiedAtTimestamp
        )
        current = current.copy(proofMetadata = proofMeta)

        if (verifiedProof.verificationStatus == VerificationStatus.INVALID || verifiedProof.verificationStatus == VerificationStatus.REJECTED) {
            current = MessageStateMachine.transition(
                message = current,
                newState = MessageState.FAILED,
                reasonOrTxHash = "Proof verification failed: ${verifiedProof.cryptographicSummary}",
                actorNodeId = localNodeId
            )
            messages[current.messageId] = current
            return Result.failure(IllegalStateException(verifiedProof.cryptographicSummary))
        }

        current = MessageStateMachine.transition(
            message = current,
            newState = MessageState.PROOF_AVAILABLE,
            reasonOrTxHash = verifiedProof.proofId,
            actorNodeId = localNodeId
        )
        messages[current.messageId] = current
        bus.publish(
            ProofVerifiedEvent(
                eventId = "ev_${UUID.randomUUID().toString().take(8)}",
                timestamp = System.currentTimeMillis(),
                correlationId = current.correlationId,
                messageId = current.messageId,
                proofId = verifiedProof.proofId,
                verificationStatus = verifiedProof.verificationStatus,
                verifiedByNodeId = localNodeId
            )
        )

        // 6. DESTINATION AUTHORISED
        current = MessageStateMachine.transition(
            message = current,
            newState = MessageState.DESTINATION_AUTHORISED,
            reasonOrTxHash = "Authorised by MIN Settlement Engine (Proof Verified)",
            actorNodeId = localNodeId
        )
        messages[current.messageId] = current

        // 7. DESTINATION SUBMITTED
        val dstAdapter = adapterRegistry.getAdapter(current.destinationNetwork)!!
        val dstTxResult = dstAdapter.submitTransaction(
            from = Address("escrow_vault_${current.destinationNetwork.value.takeLast(4)}"),
            to = current.recipient,
            assetId = current.assetId,
            amount = current.amount,
            payload = "min_release:${current.messageId.value}:${verifiedProof.proofId}"
        )

        if (dstTxResult.isFailure) {
            val err = dstTxResult.exceptionOrNull()?.message ?: "Destination submission failed"
            current = MessageStateMachine.transition(
                message = current,
                newState = MessageState.MANUAL_REVIEW,
                reasonOrTxHash = "Destination submission failed: $err (Source locked; requires operator intervention or refund)",
                actorNodeId = localNodeId
            )
            messages[current.messageId] = current
            return Result.failure(IllegalStateException(err))
        }

        val dstTxHash = dstTxResult.getOrThrow()
        current = current.copy(destinationTxHash = dstTxHash)
        current = MessageStateMachine.transition(
            message = current,
            newState = MessageState.DESTINATION_SUBMITTED,
            reasonOrTxHash = dstTxHash.value,
            actorNodeId = localNodeId
        )
        messages[current.messageId] = current
        bus.publish(
            DestinationSubmittedEvent(
                eventId = "ev_${UUID.randomUUID().toString().take(8)}",
                timestamp = System.currentTimeMillis(),
                correlationId = current.correlationId,
                messageId = current.messageId,
                destinationNetwork = current.destinationNetwork,
                destinationTxHash = dstTxHash
            )
        )

        // 8. DESTINATION CONFIRMED
        val dstBlock = dstAdapter.produceSimulatedBlock()
        current = MessageStateMachine.transition(
            message = current,
            newState = MessageState.DESTINATION_CONFIRMED,
            reasonOrTxHash = "block_${dstBlock.height}_${dstTxHash.value}",
            actorNodeId = localNodeId
        )
        messages[current.messageId] = current
        bus.publish(
            DestinationConfirmedEvent(
                eventId = "ev_${UUID.randomUUID().toString().take(8)}",
                timestamp = System.currentTimeMillis(),
                correlationId = current.correlationId,
                messageId = current.messageId,
                destinationNetwork = current.destinationNetwork,
                destinationTxHash = dstTxHash,
                confirmations = 1
            )
        )

        // 9. SETTLED
        current = MessageStateMachine.transition(
            message = current,
            newState = MessageState.SETTLED,
            reasonOrTxHash = "Cross-chain settlement finality achieved.",
            actorNodeId = localNodeId
        )
        messages[current.messageId] = current

        val elapsed = System.currentTimeMillis() - current.createdAtTimestamp
        bus.publish(
            InterchainSettledEvent(
                eventId = "ev_${UUID.randomUUID().toString().take(8)}",
                timestamp = System.currentTimeMillis(),
                correlationId = current.correlationId,
                messageId = current.messageId,
                sourceNetwork = current.sourceNetwork,
                destinationNetwork = current.destinationNetwork,
                settledAmountFormatted = current.formattedAmount,
                totalSettlementTimeMs = elapsed
            )
        )

        auditLedger.record(
            entityType = "SETTLEMENT",
            entityId = current.messageId.value,
            actor = "SETTLEMENT_COORDINATOR",
            action = "INTERCHAIN_SETTLEMENT_FINALIZED",
            previousState = MessageState.DESTINATION_CONFIRMED.name,
            newState = MessageState.SETTLED.name,
            sourceEvent = "DESTINATION_CONFIRMED",
            resultingEvent = "SETTLEMENT_COMPLETE",
            details = mapOf(
                "source" to current.sourceNetwork.value,
                "destination" to current.destinationNetwork.value,
                "amount" to current.formattedAmount,
                "source_tx" to (srcTxHash.value),
                "destination_tx" to (dstTxHash.value),
                "latency_ms" to elapsed.toString()
            )
        )

        return Result.success(current)
    }

    suspend fun executeRefund(messageId: MessageId, reason: String): Result<InterchainMessage> {
        val msg = messages[messageId] ?: return Result.failure(IllegalArgumentException("Message not found"))
        if (msg.currentState.isTerminal) {
            return Result.failure(IllegalStateException("Cannot refund terminal state ${msg.currentState}"))
        }

        val refunded = MessageStateMachine.transition(
            message = msg,
            newState = MessageState.REFUNDED,
            reasonOrTxHash = "Refund executed: $reason",
            actorNodeId = localNodeId
        )
        messages[messageId] = refunded

        auditLedger.record(
            entityType = "SETTLEMENT",
            entityId = messageId.value,
            actor = "OPERATOR_OVERRIDE",
            action = "MANUAL_REFUND_EXECUTED",
            previousState = msg.currentState.name,
            newState = MessageState.REFUNDED.name,
            sourceEvent = "OPERATOR_REFUND_COMMAND",
            resultingEvent = "ESCROW_UNLOCKED",
            details = mapOf("reason" to reason)
        )

        return Result.success(refunded)
    }

    private fun sha256(input: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(input.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }
}

class BlockObserver(
    private val adapterRegistry: AdapterRegistry,
    private val bus: InterchainMessageBus,
    private val auditLedger: AuditLedger,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) {
    private val observationJobs = ConcurrentHashMap<NetworkId, Job>()

    fun startObserving() {
        adapterRegistry.getAllAdapters().forEach { adapter ->
            if (observationJobs.containsKey(adapter.networkId)) return@forEach

            val job = scope.launch {
                adapter.observeBlocks().collect { header ->
                    bus.publish(
                        BlockObservedEvent(
                            eventId = "blk_${UUID.randomUUID().toString().take(8)}",
                            timestamp = header.timestamp,
                            correlationId = "obs_${header.networkId.value}_${header.height}",
                            networkId = header.networkId,
                            blockHeight = header.height,
                            blockHash = header.hash,
                            txCount = header.transactionCount,
                            finalityConfidence = header.finalityConfidence
                        )
                    )
                }
            }
            observationJobs[adapter.networkId] = job
        }
    }

    fun stopObserving() {
        observationJobs.values.forEach { it.cancel() }
        observationJobs.clear()
    }
}
