package com.example.min.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.min.domain.model.InterchainMessage
import com.example.min.domain.model.MessageState
import com.example.min.ui.components.*
import com.example.min.ui.viewmodel.NodeUiState
import com.example.ui.theme.*

@Composable
fun MessagesScreen(
    state: NodeUiState,
    modifier: Modifier = Modifier
) {
    var expandedMessageId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Interchain Message Ledger",
                subtitle = "Deterministic state machine tracking, cryptographic proofs & audit transition history"
            )
        }

        if (state.messages.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalSurface)
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No interchain messages observed yet. Run a corridor scenario or request a quote.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ManchesterMutedText
                        )
                    }
                }
            }
        } else {
            items(state.messages) { message ->
                val isExpanded = expandedMessageId == message.messageId.value
                MessageLedgerCard(
                    message = message,
                    isExpanded = isExpanded,
                    onToggleExpand = {
                        expandedMessageId = if (isExpanded) null else message.messageId.value
                    }
                )
            }
        }
    }
}

@Composable
fun MessageLedgerCard(
    message: InterchainMessage,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onToggleExpand() }
            .testTag("message_card_${message.messageId.value}"),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalSurface),
        border = BorderStroke(1.dp, if (isExpanded) ManchesterBrass else ManchesterGraphiteBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = message.messageId.value,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = ManchesterIvoryText
                )
                MessageStateBadge(state = message.currentState)
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${message.sourceNetwork.value} ⟶ ${message.destinationNetwork.value}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ManchesterBrassLight,
                    fontSize = 11.sp
                )
                Text(
                    text = message.formattedAmount,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = StatusSettledGreen
                )
            }

            if (isExpanded) {
                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = ManchesterGraphiteDivider)
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Payload Hash: ${message.payloadHash}",
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = ManchesterMutedText,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                if (message.sourceTxHash != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Source Tx: ${message.sourceTxHash.value}",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = ManchesterSandstoneLight,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (message.destinationTxHash != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Dest Tx: ${message.destinationTxHash.value}",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = ManchesterSandstoneLight,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (message.proofMetadata != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Proof: ${message.proofMetadata.proofId ?: "N/A"} [${message.proofMetadata.verificationStatus}]",
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusProofPurple,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "DETERMINISTIC STATE TRANSITIONS (${message.stateHistory.size}):",
                    style = MaterialTheme.typography.labelSmall,
                    color = ManchesterBrass,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))

                message.stateHistory.forEach { step ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "• ${step.fromState.name} ⟶ ${step.toState.name}",
                            style = MaterialTheme.typography.bodySmall,
                            color = ManchesterIvoryText,
                            fontSize = 10.sp
                        )
                        Text(
                            text = step.stateDigest.take(12) + "...",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = ManchesterSubtleText,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }
    }
}
