package com.example.min.engine

import com.example.min.adapter.AdapterRegistry
import com.example.min.domain.model.*
import java.math.BigDecimal
import java.math.BigInteger
import java.math.RoundingMode
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class LiquidityEngine(
    private val adapterRegistry: AdapterRegistry
) {
    private val pools = ConcurrentHashMap<PoolId, LiquidityPool>()

    init {
        // Initialise MCX & Network Pools
        registerPool(
            LiquidityPool(
                poolId = PoolId("pool_mcx_sgbp_mnc"),
                poolName = "MCX Core: SGBP / MNC",
                networkId = NetworkId("net_manchester_main"),
                assetA = AssetId("SGBP"),
                assetB = AssetId("MNC"),
                reserveA = BigInteger.valueOf(25_000_000_00L), // £25M SGBP (2 decimals)
                reserveB = BigInteger.valueOf(500_000_00000000L), // 500k MNC (8 decimals)
                formattedReserveA = "£25,000,000.00 SGBP",
                formattedReserveB = "500,000.00 MNC",
                totalLiquidityGbp = 50_000_000.0,
                feeBps = 5, // 0.05%
                utilizationPercent = 24.5,
                isMcxNative = true,
                healthState = NetworkHealthState.HEALTHY
            )
        )

        registerPool(
            LiquidityPool(
                poolId = PoolId("pool_mcx_sgbp_eth"),
                poolName = "MCX Institutional: SGBP / ETH",
                networkId = NetworkId("net_manchester_main"),
                assetA = AssetId("SGBP"),
                assetB = AssetId("ETH"),
                reserveA = BigInteger.valueOf(40_000_000_00L), // £40M SGBP
                reserveB = BigInteger("16000000000000000000000"), // 16,000 ETH (18 decimals)
                formattedReserveA = "£40,000,000.00 SGBP",
                formattedReserveB = "16,000.00 ETH",
                totalLiquidityGbp = 80_000_000.0,
                feeBps = 10, // 0.10%
                utilizationPercent = 38.2,
                isMcxNative = true,
                healthState = NetworkHealthState.HEALTHY
            )
        )

        registerPool(
            LiquidityPool(
                poolId = PoolId("pool_mcx_sgbp_btc"),
                poolName = "MCX Vault: SGBP / BTC",
                networkId = NetworkId("net_manchester_main"),
                assetA = AssetId("SGBP"),
                assetB = AssetId("BTC"),
                reserveA = BigInteger.valueOf(60_000_000_00L), // £60M SGBP
                reserveB = BigInteger.valueOf(1_200_00000000L), // 1,200 BTC
                formattedReserveA = "£60,000,000.00 SGBP",
                formattedReserveB = "1,200.00 BTC",
                totalLiquidityGbp = 120_000_000.0,
                feeBps = 12,
                utilizationPercent = 42.1,
                isMcxNative = true,
                healthState = NetworkHealthState.HEALTHY
            )
        )

        registerPool(
            LiquidityPool(
                poolId = PoolId("pool_usdc_sgbp_bridge"),
                poolName = "Institutional FX: USDC / SGBP",
                networkId = NetworkId("net_stablecoin_clearing"),
                assetA = AssetId("USDC"),
                assetB = AssetId("SGBP"),
                reserveA = BigInteger.valueOf(50_000_000_000000L), // $50M USDC (6 decimals)
                reserveB = BigInteger.valueOf(39_000_000_00L), // £39M SGBP
                formattedReserveA = "$50,000,000.00 USDC",
                formattedReserveB = "£39,000,000.00 SGBP",
                totalLiquidityGbp = 78_000_000.0,
                feeBps = 8,
                utilizationPercent = 31.0,
                isMcxNative = false,
                healthState = NetworkHealthState.HEALTHY
            )
        )
    }

    fun registerPool(pool: LiquidityPool) {
        pools[pool.poolId] = pool
    }

    fun getPool(poolId: PoolId): LiquidityPool? = pools[poolId]

    fun getAllPools(): List<LiquidityPool> = pools.values.toList()

    fun calculateSwap(
        inputAsset: Asset,
        outputAsset: Asset,
        inputAmount: BigInteger
    ): SwapResult {
        val inDecimals = inputAsset.decimals
        val outDecimals = outputAsset.decimals

        val inputHuman = BigDecimal(inputAmount).movePointLeft(inDecimals)

        // Deterministic FX rates relative to SGBP (GBP baseline)
        val rateToGbp = when (inputAsset.symbol) {
            "SGBP", "DEP-GBP" -> BigDecimal.ONE
            "MNC" -> BigDecimal("50.00") // 1 MNC = £50
            "BTC" -> BigDecimal("50000.00") // 1 BTC = £50,000
            "ETH" -> BigDecimal("2500.00") // 1 ETH = £2,500
            "USDC" -> BigDecimal("0.78") // 1 USDC = £0.78
            else -> BigDecimal.ONE
        }

        val rateFromGbp = when (outputAsset.symbol) {
            "SGBP", "DEP-GBP" -> BigDecimal.ONE
            "MNC" -> BigDecimal.ONE.divide(BigDecimal("50.00"), 8, RoundingMode.HALF_UP)
            "BTC" -> BigDecimal.ONE.divide(BigDecimal("50000.00"), 8, RoundingMode.HALF_UP)
            "ETH" -> BigDecimal.ONE.divide(BigDecimal("2500.00"), 8, RoundingMode.HALF_UP)
            "USDC" -> BigDecimal.ONE.divide(BigDecimal("0.78"), 8, RoundingMode.HALF_UP)
            else -> BigDecimal.ONE
        }

        val gbpEquivalent = inputHuman.multiply(rateToGbp)
        val rawOutputHuman = gbpEquivalent.multiply(rateFromGbp)

        // AMM Slippage: based on size relative to pool depth (e.g. 0.01% per £100k)
        val slippagePercent = (gbpEquivalent.toDouble() / 10_000_000.0).coerceIn(0.0001, 0.02)
        val feeRate = 0.001 // 0.10%

        val outputAfterFeesHuman = rawOutputHuman.multiply(BigDecimal.valueOf(1.0 - feeRate - slippagePercent))
        val outputBaseUnits = outputAfterFeesHuman.movePointRight(outDecimals).toBigInteger().coerceAtLeast(BigInteger.ONE)

        val spreadGbp = gbpEquivalent.toDouble() * 0.0005
        val minOutput = outputAfterFeesHuman.multiply(BigDecimal.valueOf(0.995)).movePointRight(outDecimals).toBigInteger()

        val rateRatio = if (inputHuman.toDouble() > 0) outputAfterFeesHuman.divide(inputHuman, 6, RoundingMode.HALF_UP) else BigDecimal.ONE

        return SwapResult(
            outputAmount = outputBaseUnits,
            minimumOutputAmount = minOutput,
            rateFormatted = "1 ${inputAsset.symbol} ≈ ${rateRatio.toPlainString()} ${outputAsset.symbol}",
            spreadGbp = spreadGbp,
            liquidityFeeGbp = gbpEquivalent.toDouble() * feeRate,
            slippagePercent = slippagePercent * 100
        )
    }
}

data class SwapResult(
    val outputAmount: BigInteger,
    val minimumOutputAmount: BigInteger,
    val rateFormatted: String,
    val spreadGbp: Double,
    val liquidityFeeGbp: Double,
    val slippagePercent: Double
)

class InterchainRouter(
    private val adapterRegistry: AdapterRegistry,
    private val liquidityEngine: LiquidityEngine
) {
    private val quotes = ConcurrentHashMap<QuoteId, InterchainQuote>()
    private val bridges = ConcurrentHashMap<BridgeId, BridgeDescriptor>()

    init {
        // Register Institutional Bridges
        registerBridge(
            BridgeDescriptor(
                bridgeId = BridgeId("brg_manchester_eth_canonical"),
                name = "Manchester-Ethereum Institutional Relayer",
                sourceNetwork = NetworkId("net_manchester_main"),
                destinationNetwork = NetworkId("net_ethereum_main"),
                supportedAssets = listOf(AssetId("SGBP"), AssetId("MNC"), AssetId("ETH")),
                trustModel = BridgeTrustModel.TRUSTLESS_LIGHT_CLIENT,
                securityLevel = BridgeSecurityLevel.CRYPTOGRAPHIC_PROVABLE,
                status = BridgeStatus.OPERATIONAL,
                dailyLimitGbp = 100_000_000.0,
                currentDailyVolumeGbp = 14_850_000.0,
                feeBaseGbp = 1.50,
                feePercentageBps = 2,
                avgLatencySeconds = 14,
                validatorCount = 21,
                riskFlags = emptyList()
            )
        )

        registerBridge(
            BridgeDescriptor(
                bridgeId = BridgeId("brg_manchester_btc_htlc"),
                name = "Manchester-Bitcoin HTLC Adaptor Gateway",
                sourceNetwork = NetworkId("net_manchester_main"),
                destinationNetwork = NetworkId("net_bitcoin_main"),
                supportedAssets = listOf(AssetId("BTC"), AssetId("SGBP")),
                trustModel = BridgeTrustModel.INSTITUTIONAL_FEDERATION,
                securityLevel = BridgeSecurityLevel.INSTITUTIONAL_TIER_1,
                status = BridgeStatus.OPERATIONAL,
                dailyLimitGbp = 50_000_000.0,
                currentDailyVolumeGbp = 8_200_000.0,
                feeBaseGbp = 15.00,
                feePercentageBps = 5,
                avgLatencySeconds = 1200,
                validatorCount = 15,
                riskFlags = listOf("High confirmation latency on Bitcoin")
            )
        )

        registerBridge(
            BridgeDescriptor(
                bridgeId = BridgeId("brg_boe_rtgs_clearing"),
                name = "Bank of England Wholesale RTGS Bridge",
                sourceNetwork = NetworkId("net_gbp_digital_clearing"),
                destinationNetwork = NetworkId("net_manchester_main"),
                supportedAssets = listOf(AssetId("SGBP"), AssetId("DEP-GBP")),
                trustModel = BridgeTrustModel.INSTITUTIONAL_FEDERATION,
                securityLevel = BridgeSecurityLevel.INSTITUTIONAL_TIER_1,
                status = BridgeStatus.OPERATIONAL,
                dailyLimitGbp = 500_000_000.0,
                currentDailyVolumeGbp = 82_400_000.0,
                feeBaseGbp = 0.0,
                feePercentageBps = 0,
                avgLatencySeconds = 1,
                validatorCount = 9,
                riskFlags = emptyList()
            )
        )

        registerBridge(
            BridgeDescriptor(
                bridgeId = BridgeId("brg_stablecoin_clearing_rail"),
                name = "Institutional Stablecoin Rail Bridge",
                sourceNetwork = NetworkId("net_stablecoin_clearing"),
                destinationNetwork = NetworkId("net_manchester_main"),
                supportedAssets = listOf(AssetId("USDC"), AssetId("SGBP")),
                trustModel = BridgeTrustModel.MULTI_SIG_ATTESTATION,
                securityLevel = BridgeSecurityLevel.INSTITUTIONAL_TIER_1,
                status = BridgeStatus.OPERATIONAL,
                dailyLimitGbp = 150_000_000.0,
                currentDailyVolumeGbp = 32_100_000.0,
                feeBaseGbp = 0.80,
                feePercentageBps = 3,
                avgLatencySeconds = 4,
                validatorCount = 12,
                riskFlags = emptyList()
            )
        )
    }

    fun registerBridge(bridge: BridgeDescriptor) {
        bridges[bridge.bridgeId] = bridge
    }

    fun getAllBridges(): List<BridgeDescriptor> = bridges.values.toList()

    fun findRoutes(
        sourceNetwork: NetworkId,
        destinationNetwork: NetworkId,
        inputAssetId: AssetId,
        outputAssetId: AssetId
    ): List<InterchainRoute> {
        val routes = mutableListOf<InterchainRoute>()

        // 1. Direct route if networks same or direct bridge exists
        if (sourceNetwork == destinationNetwork) {
            routes.add(
                InterchainRoute(
                    routeId = "rte_direct_${sourceNetwork.value.takeLast(4)}_${UUID.randomUUID().toString().take(6)}",
                    sourceNetwork = sourceNetwork,
                    destinationNetwork = destinationNetwork,
                    inputAssetId = inputAssetId,
                    outputAssetId = outputAssetId,
                    hops = listOf(
                        RouteHop(
                            hopIndex = 0,
                            fromNetwork = sourceNetwork,
                            toNetwork = destinationNetwork,
                            bridgeId = null,
                            inputAssetId = inputAssetId,
                            outputAssetId = outputAssetId,
                            estimatedFeeGbp = 0.50,
                            expectedDelaySeconds = 2,
                            description = "Intra-network exchange execution"
                        )
                    ),
                    totalEstimatedFeeGbp = 0.50,
                    expectedSettlementTimeSeconds = 2,
                    riskFlags = emptyList(),
                    settlementMechanism = SettlementMechanism.ATOMIC_HTLC,
                    confidenceScore = 0.999,
                    maxTransferLimitGbp = 50_000_000.0,
                    pathName = "Direct Intra-Chain Path"
                )
            )
            return routes
        }

        // 2. Canonical direct bridge route if available
        val directBridge = bridges.values.find {
            (it.sourceNetwork == sourceNetwork && it.destinationNetwork == destinationNetwork) ||
                    (it.sourceNetwork == destinationNetwork && it.destinationNetwork == sourceNetwork)
        }

        if (directBridge != null) {
            val isBtc = sourceNetwork.value.contains("bitcoin") || destinationNetwork.value.contains("bitcoin")
            val mech = if (isBtc) SettlementMechanism.ADAPTOR_SIGNATURE else SettlementMechanism.ESCROW_LOCK_RELEASE
            val riskList = mutableListOf<RouteRiskFlag>()
            if (isBtc) riskList.add(RouteRiskFlag.HIGH_FINALITY_LATENCY)

            routes.add(
                InterchainRoute(
                    routeId = "rte_bridge_${directBridge.bridgeId.value}_${UUID.randomUUID().toString().take(6)}",
                    sourceNetwork = sourceNetwork,
                    destinationNetwork = destinationNetwork,
                    inputAssetId = inputAssetId,
                    outputAssetId = outputAssetId,
                    hops = listOf(
                        RouteHop(
                            hopIndex = 0,
                            fromNetwork = sourceNetwork,
                            toNetwork = destinationNetwork,
                            bridgeId = directBridge.bridgeId,
                            inputAssetId = inputAssetId,
                            outputAssetId = outputAssetId,
                            estimatedFeeGbp = directBridge.feeBaseGbp + 2.0,
                            expectedDelaySeconds = directBridge.avgLatencySeconds,
                            description = "${directBridge.name} direct relay"
                        )
                    ),
                    totalEstimatedFeeGbp = directBridge.feeBaseGbp + 2.0,
                    expectedSettlementTimeSeconds = directBridge.avgLatencySeconds,
                    riskFlags = riskList,
                    settlementMechanism = mech,
                    confidenceScore = 0.99,
                    maxTransferLimitGbp = directBridge.dailyLimitGbp,
                    pathName = "${sourceNetwork.value} → ${directBridge.name} → ${destinationNetwork.value}"
                )
            )
        }

        // 3. Multi-Hop Flagship Corridor routes via Manchester Chain Hub
        val hubNetwork = NetworkId("net_manchester_main")
        if (sourceNetwork != hubNetwork && destinationNetwork != hubNetwork) {
            routes.add(
                InterchainRoute(
                    routeId = "rte_multihop_mcx_hub_${UUID.randomUUID().toString().take(6)}",
                    sourceNetwork = sourceNetwork,
                    destinationNetwork = destinationNetwork,
                    inputAssetId = inputAssetId,
                    outputAssetId = outputAssetId,
                    hops = listOf(
                        RouteHop(
                            hopIndex = 0,
                            fromNetwork = sourceNetwork,
                            toNetwork = hubNetwork,
                            bridgeId = BridgeId("brg_ingress_to_mcx"),
                            inputAssetId = inputAssetId,
                            outputAssetId = AssetId("SGBP"),
                            estimatedFeeGbp = 3.50,
                            expectedDelaySeconds = 15,
                            description = "Ingress to Manchester Interchain Core via Bridge"
                        ),
                        RouteHop(
                            hopIndex = 1,
                            fromNetwork = hubNetwork,
                            toNetwork = destinationNetwork,
                            bridgeId = BridgeId("brg_egress_from_mcx"),
                            inputAssetId = AssetId("SGBP"),
                            outputAssetId = outputAssetId,
                            estimatedFeeGbp = 4.20,
                            expectedDelaySeconds = 20,
                            description = "Manchester Liquidity Routing & Egress Settlement"
                        )
                    ),
                    totalEstimatedFeeGbp = 7.70,
                    expectedSettlementTimeSeconds = 35,
                    riskFlags = listOf(RouteRiskFlag.ASYMMETRIC_TRUST),
                    settlementMechanism = SettlementMechanism.ESCROW_LOCK_RELEASE,
                    confidenceScore = 0.97,
                    maxTransferLimitGbp = 25_000_000.0,
                    pathName = "Manchester Institutional Multi-Hop Corridor"
                )
            )
        }

        return routes
    }

    fun generateQuote(
        sourceNetwork: NetworkId,
        destinationNetwork: NetworkId,
        inputAssetId: AssetId,
        outputAssetId: AssetId,
        inputAmount: BigInteger
    ): Result<InterchainQuote> {
        val inAsset = adapterRegistry.getAsset(inputAssetId)
            ?: return Result.failure(IllegalArgumentException("Input asset '$inputAssetId' not found."))
        val outAsset = adapterRegistry.getAsset(outputAssetId)
            ?: return Result.failure(IllegalArgumentException("Output asset '$outputAssetId' not found."))

        val routes = findRoutes(sourceNetwork, destinationNetwork, inputAssetId, outputAssetId)
        if (routes.isEmpty()) {
            return Result.failure(IllegalStateException("No viable interchain route between ${sourceNetwork.value} and ${destinationNetwork.value}."))
        }

        val bestRoute = routes.first()
        val swap = liquidityEngine.calculateSwap(inAsset, outAsset, inputAmount)

        val quoteId = QuoteId("qte_${UUID.randomUUID().toString().take(10)}")
        val now = System.currentTimeMillis()

        val quote = InterchainQuote(
            quoteId = quoteId,
            route = bestRoute,
            inputAsset = inAsset,
            outputAsset = outAsset,
            inputAmount = inputAmount,
            expectedOutputAmount = swap.outputAmount,
            minimumOutputAmount = swap.minimumOutputAmount,
            exchangeRateFormatted = swap.rateFormatted,
            exchangeSpreadGbp = swap.spreadGbp,
            networkFeeGbp = bestRoute.totalEstimatedFeeGbp,
            bridgeFeeGbp = 1.20,
            totalFeeGbp = swap.spreadGbp + bestRoute.totalEstimatedFeeGbp + swap.liquidityFeeGbp,
            createdAtTimestamp = now,
            expiresAtTimestamp = now + 120_000L, // 2-minute valid quote
            status = QuoteStatus.QUOTED
        )

        quotes[quoteId] = quote
        return Result.success(quote)
    }

    fun lockQuote(quoteId: QuoteId): Result<InterchainQuote> {
        val quote = quotes[quoteId] ?: return Result.failure(IllegalArgumentException("Quote not found."))
        if (quote.expiresAtTimestamp <= System.currentTimeMillis()) {
            val expired = quote.copy(status = QuoteStatus.EXPIRED)
            quotes[quoteId] = expired
            return Result.failure(IllegalStateException("Quote has expired."))
        }
        val locked = quote.copy(
            status = QuoteStatus.LOCKED,
            lockedUntilTimestamp = System.currentTimeMillis() + 60_000L
        )
        quotes[quoteId] = locked
        return Result.success(locked)
    }

    fun getQuote(quoteId: QuoteId): InterchainQuote? = quotes[quoteId]
}
