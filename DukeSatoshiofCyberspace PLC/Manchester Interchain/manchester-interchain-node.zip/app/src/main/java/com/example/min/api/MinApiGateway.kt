package com.example.min.api

import com.example.min.adapter.AdapterRegistry
import com.example.min.bus.InterchainMessageBus
import com.example.min.domain.model.*
import com.example.min.engine.*
import java.math.BigInteger

data class ApiResponse<T>(
    val status: String,
    val statusCode: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val data: T?,
    val error: String? = null
)

class MinApiGateway(
    private val adapterRegistry: AdapterRegistry,
    private val router: InterchainRouter,
    private val liquidityEngine: LiquidityEngine,
    private val settlementCoordinator: SettlementCoordinator,
    private val proofVerificationLayer: ProofVerificationLayer,
    private val auditLedger: AuditLedger,
    private val peerDiscoveryService: PeerDiscoveryService,
    private val simulationEngine: SimulationEngine,
    private val bus: InterchainMessageBus
) {
    suspend fun getNodeInfo(): ApiResponse<NodeIdentity> {
        return ApiResponse("SUCCESS", 200, data = peerDiscoveryService.localNode)
    }

    suspend fun getHealth(): ApiResponse<NodeHealthReport> {
        val adapters = adapterRegistry.getAllAdapters()
        val networkStates = adapters.associate { it.networkId to it.network.healthState }
        val dependencies = listOf(
            DependencyHealth("PostgreSQL Operational State", true, 2, "Authoritative state storage connected"),
            DependencyHealth("Redis Coordination Cache", true, 1, "0.4ms latency, 99.99% cache hit"),
            DependencyHealth("Kafka Interchain Bus", true, 3, "Topic partitions healthy, zero lag"),
            DependencyHealth("HSM / KMS Attestation Vault", true, 1, "FIPS-140-3 Level 4 key active")
        )
        val alerts = mutableListOf<String>()
        if (networkStates.values.any { it == NetworkHealthState.OUTAGE }) {
            alerts.add("Active network outage detected on one or more adapters")
        }

        val report = NodeHealthReport(
            isLivenessHealthy = true,
            isReadinessHealthy = alerts.isEmpty(),
            networkHealthSummary = networkStates,
            dependencies = dependencies,
            activeAlerts = alerts,
            memoryUsageMb = 248L,
            uptimeSeconds = peerDiscoveryService.localNode.uptimeSeconds
        )
        return ApiResponse(if (report.isReadinessHealthy) "HEALTHY" else "DEGRADED", 200, data = report)
    }

    suspend fun getNetworks(): ApiResponse<List<ChainNetwork>> {
        val list = adapterRegistry.getAllAdapters().map { it.getNetworkStatus() }
        return ApiResponse("SUCCESS", 200, data = list)
    }

    suspend fun getNetworkById(id: String): ApiResponse<ChainNetwork> {
        val adapter = adapterRegistry.getAdapter(NetworkId(id))
            ?: return ApiResponse("NOT_FOUND", 404, data = null, error = "Network '$id' not found.")
        return ApiResponse("SUCCESS", 200, data = adapter.getNetworkStatus())
    }

    suspend fun getAssets(): ApiResponse<List<Asset>> {
        return ApiResponse("SUCCESS", 200, data = adapterRegistry.getAllAssets())
    }

    suspend fun getBridges(): ApiResponse<List<BridgeDescriptor>> {
        return ApiResponse("SUCCESS", 200, data = router.getAllBridges())
    }

    suspend fun getLiquidityPools(): ApiResponse<List<LiquidityPool>> {
        return ApiResponse("SUCCESS", 200, data = liquidityEngine.getAllPools())
    }

    suspend fun getPeers(): ApiResponse<List<PeerNode>> {
        return ApiResponse("SUCCESS", 200, data = peerDiscoveryService.getAllPeers())
    }

    suspend fun getAuditEntries(limit: Int = 50): ApiResponse<List<AuditEntry>> {
        return ApiResponse("SUCCESS", 200, data = auditLedger.getAllEntries().take(limit))
    }

    suspend fun verifyAuditLedger(): ApiResponse<AuditVerificationResult> {
        val result = auditLedger.verifyIntegrity()
        return ApiResponse("SUCCESS", 200, data = result)
    }

    suspend fun getMessages(): ApiResponse<List<InterchainMessage>> {
        return ApiResponse("SUCCESS", 200, data = settlementCoordinator.getAllMessages())
    }

    suspend fun getMessageById(messageId: String): ApiResponse<InterchainMessage> {
        val msg = settlementCoordinator.getMessage(MessageId(messageId))
            ?: return ApiResponse("NOT_FOUND", 404, data = null, error = "Message '$messageId' not found.")
        return ApiResponse("SUCCESS", 200, data = msg)
    }

    suspend fun calculateRoute(
        sourceNetwork: String,
        destinationNetwork: String,
        assetId: String
    ): ApiResponse<List<InterchainRoute>> {
        val routes = router.findRoutes(
            NetworkId(sourceNetwork),
            NetworkId(destinationNetwork),
            AssetId(assetId),
            AssetId(assetId)
        )
        return ApiResponse("SUCCESS", 200, data = routes)
    }

    suspend fun createQuote(
        sourceNetwork: String,
        destinationNetwork: String,
        inputAssetId: String,
        outputAssetId: String,
        amountHuman: Double
    ): ApiResponse<InterchainQuote> {
        val inAsset = adapterRegistry.getAsset(AssetId(inputAssetId))
            ?: return ApiResponse("BAD_REQUEST", 400, data = null, error = "Asset $inputAssetId unknown")
        val baseAmount = inAsset.toBaseUnits(amountHuman)

        val quoteResult = router.generateQuote(
            NetworkId(sourceNetwork),
            NetworkId(destinationNetwork),
            AssetId(inputAssetId),
            AssetId(outputAssetId),
            baseAmount
        )

        return if (quoteResult.isSuccess) {
            ApiResponse("SUCCESS", 200, data = quoteResult.getOrThrow())
        } else {
            ApiResponse("BAD_REQUEST", 400, data = null, error = quoteResult.exceptionOrNull()?.message)
        }
    }

    suspend fun executeSettlement(
        sourceNetwork: String,
        destinationNetwork: String,
        sender: String,
        recipient: String,
        assetId: String,
        amountHuman: Double,
        memo: String? = null
    ): ApiResponse<InterchainMessage> {
        val asset = adapterRegistry.getAsset(AssetId(assetId))
            ?: return ApiResponse("BAD_REQUEST", 400, data = null, error = "Asset $assetId unknown")
        val baseAmount = asset.toBaseUnits(amountHuman)

        val result = settlementCoordinator.createAndExecuteMessage(
            sourceNetwork = NetworkId(sourceNetwork),
            destinationNetwork = NetworkId(destinationNetwork),
            sender = Address(sender),
            recipient = Address(recipient),
            assetId = AssetId(assetId),
            amount = baseAmount,
            memo = memo
        )

        return if (result.isSuccess) {
            ApiResponse("SETTLED", 200, data = result.getOrThrow())
        } else {
            ApiResponse("EXECUTION_FAILED", 500, data = null, error = result.exceptionOrNull()?.message)
        }
    }
}
