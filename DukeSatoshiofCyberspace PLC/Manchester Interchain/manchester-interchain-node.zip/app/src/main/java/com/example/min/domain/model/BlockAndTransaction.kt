package com.example.min.domain.model

import java.math.BigInteger

data class BlockHeader(
    val networkId: NetworkId,
    val height: Long,
    val hash: BlockHash,
    val parentHash: BlockHash,
    val timestamp: Long,
    val transactionCount: Int,
    val stateRoot: String,
    val proposer: String,
    val finalized: Boolean,
    val finalityConfidence: Double
)

enum class TransactionStatus {
    PENDING,
    INCLUDED,
    CONFIRMED,
    FINALIZED,
    REVERTED,
    DROPPED
}

data class Transaction(
    val txHash: TxHash,
    val networkId: NetworkId,
    val from: Address,
    val to: Address,
    val assetId: AssetId,
    val amount: BigInteger,
    val fee: BigInteger,
    val nonce: Long,
    val blockHeight: Long?,
    val blockHash: BlockHash?,
    val status: TransactionStatus,
    val confirmations: Int,
    val timestamp: Long,
    val rawPayload: String? = null
)

data class TransactionReceipt(
    val txHash: TxHash,
    val networkId: NetworkId,
    val blockHeight: Long,
    val blockHash: BlockHash,
    val confirmations: Int,
    val status: TransactionStatus,
    val gasUsedOrFee: BigInteger,
    val events: List<ChainEvent>,
    val timestamp: Long
)

data class ChainEvent(
    val eventId: String,
    val networkId: NetworkId,
    val blockHeight: Long,
    val txHash: TxHash,
    val eventName: String,
    val contractOrRail: Address,
    val attributes: Map<String, String>,
    val timestamp: Long
)

data class AddressBalance(
    val address: Address,
    val networkId: NetworkId,
    val assetId: AssetId,
    val confirmedBalance: BigInteger,
    val pendingBalance: BigInteger,
    val lockedInSettlement: BigInteger,
    val spendableBalance: BigInteger
)

data class FinalityStatus(
    val networkId: NetworkId,
    val blockHeight: Long,
    val confirmations: Int,
    val requiredConfirmations: Int,
    val isFinalized: Boolean,
    val confidenceRating: Double, // 0.0 to 1.0
    val finalityModel: FinalityModel,
    val estimatedSecondsToFinal: Long
)
