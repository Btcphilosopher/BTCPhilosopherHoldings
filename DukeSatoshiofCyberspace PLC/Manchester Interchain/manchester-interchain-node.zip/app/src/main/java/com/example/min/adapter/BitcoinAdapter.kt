package com.example.min.adapter

import com.example.min.domain.model.*
import java.math.BigInteger

class BitcoinAdapter(
    initialNetwork: ChainNetwork = ChainNetwork(
        networkId = NetworkId("net_bitcoin_main"),
        chainId = ChainId(0),
        name = "Bitcoin Network",
        shortCode = "BTC-NET",
        protocol = ProtocolType.BITCOIN_UTXO,
        nativeAssetId = AssetId("BTC"),
        rpcEndpoints = listOf("https://btc-rpc.manchester-interchain.net", "https://bitcoin-node.internal"),
        finalityModel = FinalityModel.PROBABILISTIC_POW,
        blockHeight = 862_410L,
        latestBlockHash = BlockHash("00000000000000000002ab4c8e7190d5fe6312ca794619bfa67e23114d59a80b"),
        peerCount = 124,
        confirmationPolicy = ConfirmationPolicy(
            standardConfirmations = 3,
            highValueConfirmations = 6,
            highValueThresholdGbp = 250_000.0,
            targetBlockTimeSeconds = 600.0,
            maxReorgDepthProtected = 6
        ),
        capabilities = setOf(
            NetworkCapability.NATIVE_ASSET_TRANSFERS,
            NetworkCapability.ADAPTOR_SIGNATURES,
            NetworkCapability.HTLC_CONTRACTS
        ),
        healthState = NetworkHealthState.HEALTHY,
        integrationMode = IntegrationMode.SIMULATED,
        adapterVersion = "adapter-btc-utxo-v1.8.2",
        blockLatencyMs = 600_000L,
        totalTransactionsObserved = 942_110_400L,
        description = "Decentralised Nakamoto consensus proof-of-work network with probabilistic settlement."
    )
) : BaseSimulatedAdapter(initialNetwork) {

    override suspend fun validateAddress(address: Address): Boolean {
        return address.value.startsWith("bc1") || address.value.startsWith("1") || address.value.startsWith("3")
    }

    override suspend fun checkFinality(blockHeight: Long): FinalityStatus {
        val current = currentBlockHeight.get()
        val confs = if (blockHeight <= current) (current - blockHeight + 1).toInt() else 0
        val required = network.confirmationPolicy.standardConfirmations
        val isFinal = confs >= required
        val confidence = when {
            confs >= 6 -> 0.99999
            confs == 5 -> 0.9999
            confs == 4 -> 0.999
            confs == 3 -> 0.99
            confs == 2 -> 0.95
            confs == 1 -> 0.85
            else -> 0.10
        }
        val remainingConfs = (required - confs).coerceAtLeast(0)
        return FinalityStatus(
            networkId = network.networkId,
            blockHeight = blockHeight,
            confirmations = confs,
            requiredConfirmations = required,
            isFinalized = isFinal,
            confidenceRating = confidence,
            finalityModel = FinalityModel.PROBABILISTIC_POW,
            estimatedSecondsToFinal = remainingConfs * 600L
        )
    }

    override fun calculateFee(amount: BigInteger): BigInteger {
        return BigInteger.valueOf((2500 * congestionMultiplier).toLong()) // ~2500 satoshis
    }

    override fun isHeightFinalized(height: Long): Boolean {
        return (currentBlockHeight.get() - height) >= 3
    }

    override fun calculateFinalityConfidence(height: Long): Double {
        val diff = currentBlockHeight.get() - height
        return if (diff >= 3) 0.99 else 0.85
    }
}
