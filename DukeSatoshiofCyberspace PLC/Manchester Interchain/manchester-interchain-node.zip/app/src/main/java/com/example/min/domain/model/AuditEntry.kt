package com.example.min.domain.model

data class AuditEntry(
    val auditId: AuditId,
    val sequenceNumber: Long,
    val timestamp: Long,
    val entityType: String, // MESSAGE, ROUTE, PROOF, BLOCK, SETTLEMENT, CHAOS, NODE
    val entityId: String,
    val actor: String,
    val action: String,
    val previousState: String?,
    val newState: String?,
    val sourceEvent: String,
    val resultingEvent: String?,
    val cryptographicHash: String,
    val previousEntryHash: String,
    val details: Map<String, String>
)

data class AuditFilter(
    val entityType: String? = null,
    val entityId: String? = null,
    val fromTimestamp: Long? = null,
    val toTimestamp: Long? = null,
    val actor: String? = null
)

data class AuditVerificationResult(
    val isChainValid: Boolean,
    val totalEntriesVerified: Int,
    val brokenIndex: Long? = null,
    val rootHash: String,
    val verifiedAtTimestamp: Long
)
