package com.example.min.domain.model

import java.math.BigInteger

enum class BridgeTrustModel(val displayName: String) {
    INSTITUTIONAL_FEDERATION("Manchester Clearing Federation (HSM-backed)"),
    TRUSTLESS_LIGHT_CLIENT("Cryptographic Light-Client Header Proofs"),
    MULTI_SIG_ATTESTATION("Threshold Multi-Sig Attestation Set"),
    OPTIMISTIC_VERIFIER("Optimistic Challenge-Window Relayer"),
    NATIVE_MINT_BURN("Native Protocol Mint/Burn Rail")
}

enum class BridgeSecurityLevel {
    INSTITUTIONAL_TIER_1,
    CRYPTOGRAPHIC_PROVABLE,
    REPUTATIONAL_MULTI_SIG,
    DEVELOPMENT_SANDBOX
}

enum class BridgeStatus {
    OPERATIONAL,
    DEGRADED,
    PAUSED,
    MAINTENANCE
}

data class BridgeDescriptor(
    val bridgeId: BridgeId,
    val name: String,
    val sourceNetwork: NetworkId,
    val destinationNetwork: NetworkId,
    val supportedAssets: List<AssetId>,
    val trustModel: BridgeTrustModel,
    val securityLevel: BridgeSecurityLevel,
    val status: BridgeStatus,
    val dailyLimitGbp: Double,
    val currentDailyVolumeGbp: Double,
    val feeBaseGbp: Double,
    val feePercentageBps: Int,
    val avgLatencySeconds: Long,
    val validatorCount: Int,
    val riskFlags: List<String>
)

data class LiquidityPool(
    val poolId: PoolId,
    val poolName: String,
    val networkId: NetworkId,
    val assetA: AssetId,
    val assetB: AssetId,
    val reserveA: BigInteger,
    val reserveB: BigInteger,
    val formattedReserveA: String,
    val formattedReserveB: String,
    val totalLiquidityGbp: Double,
    val feeBps: Int,
    val utilizationPercent: Double,
    val isMcxNative: Boolean,
    val healthState: NetworkHealthState
)
