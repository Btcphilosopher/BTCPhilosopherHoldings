package com.example.min.bus

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicLong

class InterchainMessageBus(
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default,
    private val maxHistorySize: Int = 400
) {
    private val scope = CoroutineScope(SupervisorJob() + dispatcher)

    private val _eventFlow = MutableSharedFlow<BusEvent>(
        replay = 50,
        extraBufferCapacity = 500,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val eventFlow: Flow<BusEvent> = _eventFlow.asSharedFlow()

    private val eventHistory = ConcurrentLinkedQueue<BusEvent>()
    private val deadLetterQueue = ConcurrentLinkedQueue<BusEvent>()
    private val totalEventsPublished = AtomicLong(0)

    fun publish(event: BusEvent) {
        totalEventsPublished.incrementAndGet()
        eventHistory.add(event)
        while (eventHistory.size > maxHistorySize) {
            eventHistory.poll()
        }
        _eventFlow.tryEmit(event)
    }

    fun subscribe(topicPrefix: String? = null): Flow<BusEvent> {
        return if (topicPrefix.isNullOrBlank()) {
            eventFlow
        } else {
            eventFlow.filter { it.topic.startsWith(topicPrefix) }
        }
    }

    fun pushToDeadLetter(event: BusEvent, error: Throwable) {
        deadLetterQueue.add(event)
        while (deadLetterQueue.size > 100) {
            deadLetterQueue.poll()
        }
    }

    fun getRecentEvents(limit: Int = 50): List<BusEvent> {
        return eventHistory.toList().takeLast(limit).reversed()
    }

    fun getDeadLetterCount(): Int = deadLetterQueue.size

    fun getQueueDepth(): Int = _eventFlow.replayCache.size

    fun getTotalEventsCount(): Long = totalEventsPublished.get()
}
