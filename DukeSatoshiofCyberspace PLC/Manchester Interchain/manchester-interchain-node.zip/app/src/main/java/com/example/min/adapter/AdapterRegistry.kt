package com.example.min.adapter

import com.example.min.domain.model.Asset
import com.example.min.domain.model.AssetId
import com.example.min.domain.model.AssetType
import com.example.min.domain.model.CustodyModel
import com.example.min.domain.model.NetworkId
import java.util.concurrent.ConcurrentHashMap

class AdapterRegistry {
    private val adapters = ConcurrentHashMap<NetworkId, ChainAdapter>()
    private val assets = ConcurrentHashMap<AssetId, Asset>()

    init {
        // Register standard network adapters
        registerAdapter(ManchesterChainAdapter())
        registerAdapter(BitcoinAdapter())
        registerAdapter(EthereumAdapter())
        registerAdapter(SyntheticGbpAdapter())
        registerAdapter(StablecoinSettlementAdapter())
        registerAdapter(TokenisedDepositAdapter())

        // Register default institutional assets
        registerAsset(
            Asset(
                canonicalId = AssetId("SGBP"),
                networkId = NetworkId("net_manchester_main"),
                symbol = "SGBP",
                name = "Synthetic Digital Pound",
                decimals = 2,
                assetType = AssetType.SYNTHETIC_FIAT,
                contractAddress = null,
                issuer = "Manchester Interchain Settlement Authority / Bank of England Clearing",
                totalSupplyFormatted = "£500,000,000.00",
                custodyModel = CustodyModel.CENTRAL_BANK_CLEARING,
                supportedSettlementRoutes = listOf(
                    NetworkId("net_manchester_main"),
                    NetworkId("net_gbp_digital_clearing"),
                    NetworkId("net_ethereum_main"),
                    NetworkId("net_tokenised_deposits")
                ),
                iconEmoji = "💷",
                isSettlementPrimary = true
            )
        )

        registerAsset(
            Asset(
                canonicalId = AssetId("MNC"),
                networkId = NetworkId("net_manchester_main"),
                symbol = "MNC",
                name = "Manchester Coin",
                decimals = 8,
                assetType = AssetType.NATIVE,
                contractAddress = null,
                issuer = "Manchester Coin Exchange Protocol",
                totalSupplyFormatted = "21,000,000 MNC",
                custodyModel = CustodyModel.SELF_CUSTODIAL,
                supportedSettlementRoutes = listOf(
                    NetworkId("net_manchester_main"),
                    NetworkId("net_ethereum_main"),
                    NetworkId("net_bitcoin_main")
                ),
                iconEmoji = "🏛️",
                isSettlementPrimary = true
            )
        )

        registerAsset(
            Asset(
                canonicalId = AssetId("BTC"),
                networkId = NetworkId("net_bitcoin_main"),
                symbol = "BTC",
                name = "Bitcoin",
                decimals = 8,
                assetType = AssetType.NATIVE,
                contractAddress = null,
                issuer = "Bitcoin Decentralised Consensus",
                totalSupplyFormatted = "19,750,000 BTC",
                custodyModel = CustodyModel.SELF_CUSTODIAL,
                supportedSettlementRoutes = listOf(
                    NetworkId("net_bitcoin_main"),
                    NetworkId("net_manchester_main"),
                    NetworkId("net_ethereum_main")
                ),
                iconEmoji = "₿",
                isSettlementPrimary = false
            )
        )

        registerAsset(
            Asset(
                canonicalId = AssetId("ETH"),
                networkId = NetworkId("net_ethereum_main"),
                symbol = "ETH",
                name = "Ether",
                decimals = 18,
                assetType = AssetType.NATIVE,
                contractAddress = null,
                issuer = "Ethereum Consensus Layer",
                totalSupplyFormatted = "120,400,000 ETH",
                custodyModel = CustodyModel.SELF_CUSTODIAL,
                supportedSettlementRoutes = listOf(
                    NetworkId("net_ethereum_main"),
                    NetworkId("net_manchester_main"),
                    NetworkId("net_stablecoin_clearing")
                ),
                iconEmoji = "⟠",
                isSettlementPrimary = false
            )
        )

        registerAsset(
            Asset(
                canonicalId = AssetId("USDC"),
                networkId = NetworkId("net_stablecoin_clearing"),
                symbol = "USDC",
                name = "USD Coin (Institutional Clearing)",
                decimals = 6,
                assetType = AssetType.STABLECOIN,
                contractAddress = null,
                issuer = "Circle Institutional / MIN Settlement Rail",
                totalSupplyFormatted = "$34,000,000,000.00",
                custodyModel = CustodyModel.INSTITUTIONAL_ESCROW,
                supportedSettlementRoutes = listOf(
                    NetworkId("net_stablecoin_clearing"),
                    NetworkId("net_ethereum_main"),
                    NetworkId("net_manchester_main")
                ),
                iconEmoji = "💵",
                isSettlementPrimary = false
            )
        )

        registerAsset(
            Asset(
                canonicalId = AssetId("DEP-GBP"),
                networkId = NetworkId("net_tokenised_deposits"),
                symbol = "DEP-GBP",
                name = "Tokenised Sterling Commercial Bank Deposit",
                decimals = 2,
                assetType = AssetType.TOKENISED_DEPOSIT,
                contractAddress = null,
                issuer = "Manchester Consortium Banks (Wholesale)",
                totalSupplyFormatted = "£1,250,000,000.00",
                custodyModel = CustodyModel.CENTRAL_BANK_CLEARING,
                supportedSettlementRoutes = listOf(
                    NetworkId("net_tokenised_deposits"),
                    NetworkId("net_manchester_main"),
                    NetworkId("net_gbp_digital_clearing")
                ),
                iconEmoji = "🏦",
                isSettlementPrimary = false
            )
        )
    }

    fun registerAdapter(adapter: ChainAdapter) {
        adapters[adapter.networkId] = adapter
    }

    fun getAdapter(networkId: NetworkId): ChainAdapter? = adapters[networkId]

    fun getAllAdapters(): List<ChainAdapter> = adapters.values.toList()

    fun registerAsset(asset: Asset) {
        assets[asset.canonicalId] = asset
    }

    fun getAsset(assetId: AssetId): Asset? = assets[assetId]

    fun getAllAssets(): List<Asset> = assets.values.toList()
}
