package com.example.min.adapter

import com.example.min.domain.model.Address
import com.example.min.domain.model.AddressBalance
import com.example.min.domain.model.AssetId
import com.example.min.domain.model.BlockHash
import com.example.min.domain.model.BlockHeader
import com.example.min.domain.model.ChainEvent
import com.example.min.domain.model.ChainNetwork
import com.example.min.domain.model.FinalityStatus
import com.example.min.domain.model.NetworkId
import com.example.min.domain.model.Transaction
import com.example.min.domain.model.TransactionReceipt
import com.example.min.domain.model.TxHash
import kotlinx.coroutines.flow.Flow
import java.math.BigInteger

interface ChainAdapter {
    val network: ChainNetwork
    val networkId: NetworkId get() = network.networkId

    suspend fun getNetworkStatus(): ChainNetwork
    suspend fun getLatestBlock(): BlockHeader
    suspend fun getBlockByHeight(height: Long): BlockHeader?
    suspend fun submitTransaction(
        from: Address,
        to: Address,
        assetId: AssetId,
        amount: BigInteger,
        payload: String? = null
    ): Result<TxHash>

    suspend fun getTransaction(txHash: TxHash): Transaction?
    suspend fun getTransactionReceipt(txHash: TxHash): TransactionReceipt?
    suspend fun getBalance(address: Address, assetId: AssetId): AddressBalance
    suspend fun validateAddress(address: Address): Boolean
    suspend fun checkFinality(blockHeight: Long): FinalityStatus
    fun observeBlocks(): Flow<BlockHeader>
    fun observeEvents(): Flow<ChainEvent>
    suspend fun produceSimulatedBlock(): BlockHeader
    fun setCongestionLevel(multiplier: Double)
    fun setSimulationFailureMode(shouldFail: Boolean, reason: String? = null)
}
