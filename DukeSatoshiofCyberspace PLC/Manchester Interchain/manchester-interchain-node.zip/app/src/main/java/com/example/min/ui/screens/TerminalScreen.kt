package com.example.min.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.min.ui.components.SectionHeader
import com.example.min.ui.viewmodel.NodeUiState
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TerminalScreen(
    state: NodeUiState,
    onExecuteCommand: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var commandInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(state.terminalOutput.size) {
        if (state.terminalOutput.isNotEmpty()) {
            listState.animateScrollToItem(state.terminalOutput.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "MIN Institutional CLI Terminal",
            subtitle = "Direct node management, transaction injection & resilience testing interface"
        )

        // Quick Command Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("min status", "min corridor", "min audit-verify", "min chaos replay", "min help").forEach { cmd ->
                AssistChip(
                    onClick = { onExecuteCommand(cmd) },
                    label = { Text(cmd, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = ManchesterCharcoalSurface,
                        labelColor = ManchesterBrassLight
                    ),
                    border = BorderStroke(1.dp, ManchesterGraphiteBorder)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Console Window
        Surface(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .testTag("terminal_console_window"),
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFF0A0C0E),
            border = BorderStroke(1.dp, ManchesterGraphiteBorder)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                items(state.terminalOutput) { line ->
                    Text(
                        text = line,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = when {
                            line.startsWith(">") -> ManchesterBrass
                            line.startsWith("[AUDIT") || line.startsWith(">>>") -> StatusSettledGreen
                            line.startsWith("SCENARIO") || line.startsWith("[FAIL") -> StatusFailedRed
                            line.startsWith("===") || line.startsWith("╔") || line.startsWith("║") || line.startsWith("╚") -> ManchesterSandstone
                            else -> ManchesterIvoryText
                        },
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Command Input Field
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = commandInput,
                onValueChange = { commandInput = it },
                placeholder = { Text("min status, min corridor, min help...", fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("cli_command_input"),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ManchesterBrass,
                    unfocusedBorderColor = ManchesterGraphiteBorder,
                    focusedTextColor = ManchesterIvoryText,
                    unfocusedTextColor = ManchesterIvoryText
                )
            )

            IconButton(
                onClick = {
                    if (commandInput.isNotBlank()) {
                        onExecuteCommand(commandInput)
                        commandInput = ""
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(ManchesterBrick, RoundedCornerShape(6.dp))
                    .testTag("submit_cli_button")
            ) {
                Icon(Icons.Default.Send, contentDescription = "Execute", tint = Color.White, modifier = Modifier.size(18.dp))
            }
        }
    }
}
