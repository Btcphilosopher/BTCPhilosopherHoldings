package com.example.min.domain.model

import java.math.BigInteger

enum class MessageState(val label: String, val isTerminal: Boolean, val isFailure: Boolean) {
    CREATED("Created", false, false),
    VALIDATED("Validated", false, false),
    ROUTED("Routed", false, false),
    SOURCE_SUBMITTED("Source Submitted", false, false),
    SOURCE_CONFIRMED("Source Confirmed", false, false),
    PROOF_AVAILABLE("Proof Available", false, false),
    DESTINATION_AUTHORISED("Destination Authorised", false, false),
    DESTINATION_SUBMITTED("Destination Submitted", false, false),
    DESTINATION_CONFIRMED("Destination Confirmed", false, false),
    SETTLED("Settled", true, false),

    // Recovery & Terminal Failure states
    REJECTED("Rejected", true, true),
    EXPIRED("Expired", true, true),
    FAILED("Failed", true, true),
    REFUNDED("Refunded", true, false),
    MANUAL_REVIEW("Manual Review Required", false, true)
}

data class StateTransitionRecord(
    val transitionId: String,
    val fromState: MessageState,
    val toState: MessageState,
    val timestamp: Long,
    val reasonOrTxHash: String,
    val actorNodeId: NodeId,
    val stateDigest: String
)

data class MessageRoutingMetadata(
    val selectedRouteId: String,
    val settlementMechanism: SettlementMechanism,
    val hopsCount: Int,
    val feeGbp: Double,
    val deadlineTimestamp: Long
)

data class MessageProofMetadata(
    val proofId: String?,
    val proofType: ProofType?,
    val rootHash: String?,
    val verificationStatus: VerificationStatus,
    val verifierNodeId: NodeId?,
    val verifiedAtTimestamp: Long?
)

data class InterchainMessage(
    val messageId: MessageId,
    val sourceNetwork: NetworkId,
    val destinationNetwork: NetworkId,
    val sender: Address,
    val recipient: Address,
    val assetId: AssetId,
    val amount: BigInteger,
    val formattedAmount: String,
    val nonce: Long,
    val payloadHash: String,
    val createdAtTimestamp: Long,
    val expiresAtTimestamp: Long,
    val currentState: MessageState,
    val sourceTxHash: TxHash?,
    val destinationTxHash: TxHash?,
    val routingMetadata: MessageRoutingMetadata?,
    val proofMetadata: MessageProofMetadata?,
    val stateHistory: List<StateTransitionRecord>,
    val retryCount: Int = 0,
    val failureReason: String? = null,
    val correlationId: String,
    val memo: String? = null
)
