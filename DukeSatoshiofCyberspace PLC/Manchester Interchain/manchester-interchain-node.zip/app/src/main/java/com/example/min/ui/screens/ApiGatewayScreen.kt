package com.example.min.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.min.ui.components.EventTickerRow
import com.example.min.ui.components.SectionHeader
import com.example.min.ui.viewmodel.NodeUiState
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiGatewayScreen(
    state: NodeUiState,
    onSelectTopicFilter: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedEndpoint by remember { mutableStateOf("/v1/node") }
    val topics = listOf("ALL", "blocks", "txs", "message", "proof", "chaos", "audit")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "MIN Interchain API Gateway",
                subtitle = "Institutional REST endpoints, WebSocket event streaming & OpenAPI schemas"
            )
        }

        // 1. REST Endpoint Sandbox
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalSurface),
                border = BorderStroke(1.dp, ManchesterGraphiteBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "REST ENDPOINT EXPLORER",
                        style = MaterialTheme.typography.labelSmall,
                        color = ManchesterBrass,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("/v1/node", "/v1/health", "/v1/networks", "/v1/bridges", "/v1/liquidity").forEach { ep ->
                            val isSelected = selectedEndpoint == ep
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedEndpoint = ep },
                                label = { Text(ep, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ManchesterBrick,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Simulated JSON Response Viewer
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = ManchesterCharcoalBg,
                        border = BorderStroke(1.dp, ManchesterGraphiteBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "HTTP/1.1 200 OK  [Content-Type: application/json]",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = StatusSettledGreen,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp
                                )
                                Text(
                                    text = "latency: 1.8ms",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ManchesterMutedText,
                                    fontSize = 10.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = when (selectedEndpoint) {
                                    "/v1/node" -> """
                                        {
                                          "node_id": "${state.nodeIdentity.nodeId.value}",
                                          "operator": "${state.nodeIdentity.operatorName}",
                                          "protocol": "${state.nodeIdentity.protocolVersion}",
                                          "software": "${state.nodeIdentity.softwareVersion}",
                                          "region": "${state.nodeIdentity.region}",
                                          "status": "ONLINE_SETTLING"
                                        }
                                    """.trimIndent()
                                    "/v1/health" -> """
                                        {
                                          "liveness": ${state.healthReport.isLivenessHealthy},
                                          "readiness": ${state.healthReport.isReadinessHealthy},
                                          "memory_mb": ${state.healthReport.memoryUsageMb},
                                          "uptime_sec": ${state.healthReport.uptimeSeconds}
                                        }
                                    """.trimIndent()
                                    "/v1/networks" -> """
                                        [
                                          { "id": "net_manchester_main", "height": 2840192, "finality": "EXPLICIT_BFT" },
                                          { "id": "net_bitcoin_main", "height": 862410, "finality": "PROBABILISTIC_POW" },
                                          { "id": "net_ethereum_main", "height": 20891450, "finality": "CONFIRMATION_DEPTH" }
                                        ]
                                    """.trimIndent()
                                    else -> """
                                        {
                                          "status": "SUCCESS",
                                          "items_count": 6,
                                          "timestamp": ${System.currentTimeMillis()}
                                        }
                                    """.trimIndent()
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = ManchesterIvoryText,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }

        // 2. WebSocket Live Event Bus Feed
        item {
            SectionHeader(
                title = "Live WebSocket Event Stream",
                subtitle = "wss://feed.manchester-interchain.net/v1/events"
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                topics.forEach { topic ->
                    val isSelected = state.selectedTopicFilter == topic
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectTopicFilter(topic) },
                        label = { Text(topic, fontSize = 10.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ManchesterBrassDark,
                            selectedLabelColor = ManchesterSandstoneLight
                        )
                    )
                }
            }
        }

        val filteredEvents = if (state.selectedTopicFilter == "ALL") {
            state.recentEvents
        } else {
            state.recentEvents.filter { it.topic.contains(state.selectedTopicFilter, ignoreCase = true) }
        }

        items(filteredEvents.take(15)) { event ->
            EventTickerRow(event = event)
        }
    }
}
