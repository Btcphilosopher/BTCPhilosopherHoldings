package com.example.min.domain.model

import java.math.BigDecimal
import java.math.BigInteger

enum class AssetType {
    NATIVE,
    WRAPPED,
    STABLECOIN,
    SYNTHETIC_FIAT,
    TOKENISED_DEPOSIT,
    RWA
}

enum class CustodyModel {
    SELF_CUSTODIAL,
    INSTITUTIONAL_ESCROW,
    MULTI_SIG_VAULT,
    CENTRAL_BANK_CLEARING
}

data class Asset(
    val canonicalId: AssetId,
    val networkId: NetworkId,
    val symbol: String,
    val name: String,
    val decimals: Int,
    val assetType: AssetType,
    val contractAddress: Address?,
    val issuer: String,
    val totalSupplyFormatted: String,
    val custodyModel: CustodyModel,
    val supportedSettlementRoutes: List<NetworkId>,
    val iconEmoji: String,
    val isSettlementPrimary: Boolean = false
) {
    val networkQualifiedId: String
        get() = "${networkId.value}:${symbol}"

    fun formatAmount(baseUnits: BigInteger): String {
        val bd = BigDecimal(baseUnits).movePointLeft(decimals)
        return "${bd.toPlainString()} $symbol"
    }

    fun toBaseUnits(humanAmount: Double): BigInteger {
        val bd = BigDecimal.valueOf(humanAmount).movePointRight(decimals)
        return bd.toBigInteger()
    }
}
