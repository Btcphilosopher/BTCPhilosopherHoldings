package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Manchester Industrial & Institutional Palette
val ManchesterBrick = Color(0xFF9E2A2B)
val ManchesterBrickDark = Color(0xFF541515)
val ManchesterBrickLight = Color(0xFFBD3A3B)
val ManchesterBrickContainer = Color(0xFF381012)

val ManchesterSandstone = Color(0xFFD9C5B2)
val ManchesterSandstoneDark = Color(0xFF8C7965)
val ManchesterSandstoneLight = Color(0xFFF3EAE0)

val ManchesterBrass = Color(0xFFC5A059)
val ManchesterBrassLight = Color(0xFFE2BE76)
val ManchesterBrassDark = Color(0xFF876B30)

val ManchesterCharcoalBg = Color(0xFF0D0F12)
val ManchesterCharcoalSurface = Color(0xFF13171D)
val ManchesterCharcoalCard = Color(0xFF1A1F27)
val ManchesterCharcoalCardHover = Color(0xFF222833)
val ManchesterGraphiteBorder = Color(0xFF2C3440)
val ManchesterGraphiteDivider = Color(0xFF202630)

val ManchesterIvoryText = Color(0xFFF5F2EB)
val ManchesterMutedText = Color(0xFF9EABB8)
val ManchesterSubtleText = Color(0xFF6B7888)

// Status & Indicator Colors
val StatusSettledGreen = Color(0xFF10B981)
val StatusSettledBg = Color(0xFF064E3B)
val StatusPendingAmber = Color(0xFFF59E0B)
val StatusPendingBg = Color(0xFF78350F)
val StatusFailedRed = Color(0xFFEF4444)
val StatusFailedBg = Color(0xFF7F1D1D)
val StatusRoutingBlue = Color(0xFF38BDF8)
val StatusRoutingBg = Color(0xFF0C4A6E)
val StatusProofPurple = Color(0xFFA855F7)
val StatusProofBg = Color(0xFF581C87)
