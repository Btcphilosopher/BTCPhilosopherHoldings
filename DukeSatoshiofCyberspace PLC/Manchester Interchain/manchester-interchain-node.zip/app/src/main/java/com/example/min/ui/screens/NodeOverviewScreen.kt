package com.example.min.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.min.bus.*
import com.example.min.domain.model.ChainNetwork
import com.example.min.domain.model.NetworkHealthState
import com.example.min.ui.components.*
import com.example.min.ui.viewmodel.NodeUiState
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@Composable
fun NodeOverviewScreen(
    state: NodeUiState,
    onRunCorridor: () -> Unit,
    onRunBtcScenario: () -> Unit,
    onRunUsdcScenario: () -> Unit,
    onNavigateToRouter: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currencyFormatter = NumberFormat.getCurrencyInstance(Locale.UK).apply {
        maximumFractionDigits = 0
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Node Identity Header
        item {
            ManchesterNodeHeader(
                nodeIdentity = state.nodeIdentity,
                healthReport = state.healthReport
            )
        }

        // 2. Hero Corridor Showcase Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hero_corridor_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalCard),
                border = BorderStroke(1.dp, ManchesterGraphiteBorder)
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(ManchesterBrickDark, ManchesterCharcoalBg, ManchesterBrassDark)
                                )
                            )
                    ) {
                        AsyncImage(
                            model = R.drawable.manchester_interchain_hero_1790582805866,
                            contentDescription = "Manchester Interchain Infrastructure",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Transparent, ManchesterCharcoalCard.copy(alpha = 0.9f))
                                    )
                                )
                        )
                    }

                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "FLAGSHIP INTERCHAIN CORRIDOR",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Black,
                                color = ManchesterIvoryText,
                                letterSpacing = 1.sp
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = StatusSettledBg
                            ) {
                                Text(
                                    text = "ACTIVE",
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StatusSettledGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Manchester Chain ⟷ Ethereum ⟷ Bank of England RTGS Clearing ⟷ MCX Liquidity",
                            style = MaterialTheme.typography.bodySmall,
                            color = ManchesterBrassLight,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onRunCorridor,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("run_corridor_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = ManchesterBrick),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(vertical = 10.dp)
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Execute SGBP Corridor", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = onNavigateToRouter,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("open_router_button"),
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.dp, ManchesterBrass),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = ManchesterBrass),
                                contentPadding = PaddingValues(vertical = 10.dp)
                            ) {
                                Icon(Icons.Default.Route, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Route Builder", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (state.scenarioProgressMessage != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = state.scenarioProgressMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = ManchesterSandstoneLight,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // 3. Node Metrics Matrix (2x2 Grid)
        item {
            SectionHeader(
                title = "Node Operational Telemetry",
                subtitle = "Deterministic metrics across all connected interchain rails"
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricDialCard(
                        title = "Settled Volume",
                        value = "£2.84B",
                        subValue = "142,780 settled msgs",
                        icon = Icons.Default.AccountBalance,
                        accentColor = ManchesterBrass,
                        modifier = Modifier.weight(1f)
                    )
                    MetricDialCard(
                        title = "Validation TPS",
                        value = "840.0 TPS",
                        subValue = "Sub-second BFT consensus",
                        icon = Icons.Default.Speed,
                        accentColor = StatusSettledGreen,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricDialCard(
                        title = "Avg Settlement Latency",
                        value = "2.40 sec",
                        subValue = "Multi-hop cryptographic finality",
                        icon = Icons.Default.Timer,
                        accentColor = StatusRoutingBlue,
                        modifier = Modifier.weight(1f)
                    )
                    MetricDialCard(
                        title = "Proof Attestation Rate",
                        value = "99.98%",
                        subValue = "${state.peers.size} active verifier peers",
                        icon = Icons.Default.VerifiedUser,
                        accentColor = StatusProofPurple,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 4. Connected Interchain Networks Overview
        item {
            SectionHeader(
                title = "Connected Network Universe",
                subtitle = "Live status and real-time block progression"
            )
        }

        items(state.networks) { network ->
            NetworkMiniCard(network = network)
        }

        // 5. Quick Scenario Executions
        item {
            SectionHeader(
                title = "Institutional Settlement Scenarios",
                subtitle = "Execute pre-configured multi-hop cross-chain workflows"
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ScenarioRowCard(
                    title = "BTC ⟶ MCX ⟶ Synthetic GBP",
                    desc = "Bitcoin UTXO lock → Manchester AMM swap → SGBP BoE clearing",
                    icon = Icons.Default.CurrencyBitcoin,
                    accentColor = Color(0xFFF7931A),
                    onExecute = onRunBtcScenario
                )
                ScenarioRowCard(
                    title = "USDC ⟶ Ethereum ⟶ Manchester Hub",
                    desc = "USD Stablecoin ingress → Multi-sig bridge → MNC liquidity vault",
                    icon = Icons.Default.AttachMoney,
                    accentColor = Color(0xFF2775CA),
                    onExecute = onRunUsdcScenario
                )
            }
        }

        // 6. Real-Time Bus Event Stream
        item {
            SectionHeader(
                title = "Live Interchain Event Bus",
                subtitle = "Subscribed to canonical block, proof, and settlement topics"
            )
        }

        items(state.recentEvents.take(10)) { event ->
            EventTickerRow(event = event)
        }
    }
}

@Composable
fun NetworkMiniCard(
    network: ChainNetwork,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("network_card_${network.shortCode.lowercase()}"),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalSurface),
        border = BorderStroke(1.dp, ManchesterGraphiteBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (network.healthState == NetworkHealthState.HEALTHY) StatusSettledGreen else StatusFailedRed)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = network.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = ManchesterIvoryText
                    )
                    Text(
                        text = "${network.shortCode} • ${network.finalityModel.name}",
                        style = MaterialTheme.typography.bodySmall,
                        color = ManchesterMutedText,
                        fontSize = 10.sp
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "#${network.blockHeight}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = ManchesterBrassLight
                )
                Text(
                    text = "${network.peerCount} peers • ${network.blockLatencyMs}ms",
                    style = MaterialTheme.typography.bodySmall,
                    color = ManchesterSubtleText,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
fun ScenarioRowCard(
    title: String,
    desc: String,
    icon: ImageVector,
    accentColor: Color,
    onExecute: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalCard),
        border = BorderStroke(1.dp, ManchesterGraphiteBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = ManchesterCharcoalBg,
                    modifier = Modifier.size(36.dp),
                    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.5f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = ManchesterIvoryText,
                        fontSize = 13.sp
                    )
                    Text(
                        text = desc,
                        style = MaterialTheme.typography.bodySmall,
                        color = ManchesterMutedText,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            IconButton(
                onClick = onExecute,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Run", tint = ManchesterBrass)
            }
        }
    }
}
