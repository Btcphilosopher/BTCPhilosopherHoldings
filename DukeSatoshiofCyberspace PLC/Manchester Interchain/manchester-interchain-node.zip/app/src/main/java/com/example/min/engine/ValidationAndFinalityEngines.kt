package com.example.min.engine

import com.example.min.adapter.AdapterRegistry
import com.example.min.domain.model.*
import java.math.BigInteger

class ValidationEngine(
    private val adapterRegistry: AdapterRegistry,
    private val replayProtectionEngine: ReplayProtectionEngine
) {
    fun validateMessage(message: InterchainMessage): ValidationResult {
        // 1. Structure & Non-null check
        if (message.messageId.value.isBlank()) {
            return ValidationResult.Invalid("Message ID cannot be empty.")
        }
        if (message.amount <= BigInteger.ZERO) {
            return ValidationResult.Invalid("Amount must be strictly positive (received: ${message.amount}).")
        }

        // 2. Network presence check
        val srcAdapter = adapterRegistry.getAdapter(message.sourceNetwork)
            ?: return ValidationResult.Invalid("Source network '${message.sourceNetwork.value}' is unknown or unsupported.")
        val dstAdapter = adapterRegistry.getAdapter(message.destinationNetwork)
            ?: return ValidationResult.Invalid("Destination network '${message.destinationNetwork.value}' is unknown or unsupported.")

        // 3. Expiry check
        val now = System.currentTimeMillis()
        if (message.expiresAtTimestamp <= now) {
            return ValidationResult.Invalid("Message expired at ${message.expiresAtTimestamp} (current: $now).")
        }

        // 4. Asset validity check
        val asset = adapterRegistry.getAsset(message.assetId)
            ?: return ValidationResult.Invalid("Asset '${message.assetId.value}' is not registered in the institutional registry.")

        if (!asset.supportedSettlementRoutes.contains(message.destinationNetwork) &&
            message.sourceNetwork != message.destinationNetwork
        ) {
            // Need multi-hop or bridge check
        }

        // 5. Payload hash integrity
        if (message.payloadHash.isBlank()) {
            return ValidationResult.Invalid("Missing payload cryptographic hash.")
        }

        // 6. Replay protection
        val replayCheck = replayProtectionEngine.checkAndRegister(
            messageId = message.messageId,
            sourceTxHash = message.sourceTxHash,
            sender = message.sender,
            nonce = message.nonce,
            destinationNetwork = message.destinationNetwork
        )
        if (replayCheck.isFailure) {
            return ValidationResult.Invalid(replayCheck.exceptionOrNull()?.message ?: "Replay protection triggered.")
        }

        return ValidationResult.Valid(
            checksum = "val_chk_${message.payloadHash.take(12)}",
            sourceNetworkName = srcAdapter.network.name,
            destinationNetworkName = dstAdapter.network.name
        )
    }
}

sealed interface ValidationResult {
    data class Valid(
        val checksum: String,
        val sourceNetworkName: String,
        val destinationNetworkName: String
    ) : ValidationResult

    data class Invalid(val reason: String) : ValidationResult
}

class FinalityEngine(
    private val adapterRegistry: AdapterRegistry
) {
    suspend fun evaluateFinality(networkId: NetworkId, blockHeight: Long): FinalityStatus {
        val adapter = adapterRegistry.getAdapter(networkId)
            ?: return FinalityStatus(
                networkId = networkId,
                blockHeight = blockHeight,
                confirmations = 0,
                requiredConfirmations = 1,
                isFinalized = false,
                confidenceRating = 0.0,
                finalityModel = FinalityModel.CONFIRMATION_DEPTH,
                estimatedSecondsToFinal = -1L
            )
        return adapter.checkFinality(blockHeight)
    }
}
