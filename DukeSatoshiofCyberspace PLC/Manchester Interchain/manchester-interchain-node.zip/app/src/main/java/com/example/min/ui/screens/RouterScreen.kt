package com.example.min.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.min.domain.model.*
import com.example.min.ui.components.*
import com.example.min.ui.viewmodel.NodeUiState
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RouterScreen(
    state: NodeUiState,
    onRequestQuote: (NetworkId, NetworkId, AssetId, AssetId, Double) -> Unit,
    onExecuteQuote: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSourceNetwork by remember { mutableStateOf(NetworkId("net_manchester_main")) }
    var selectedDestNetwork by remember { mutableStateOf(NetworkId("net_ethereum_main")) }
    var selectedInputAsset by remember { mutableStateOf(AssetId("SGBP")) }
    var selectedOutputAsset by remember { mutableStateOf(AssetId("SGBP")) }
    var amountInputText by remember { mutableStateOf("100000") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Interchain Route Discovery & Quotes",
                subtitle = "Algorithmic multi-hop pathfinding across institutional bridge rails & liquidity"
            )
        }

        // 1. Source & Destination Network Selection
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalSurface),
                border = BorderStroke(1.dp, ManchesterGraphiteBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "NETWORK ROUTING PARAMETERS",
                        style = MaterialTheme.typography.labelSmall,
                        color = ManchesterBrass,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Source Origin Network",
                        style = MaterialTheme.typography.bodySmall,
                        color = ManchesterMutedText,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        state.networks.take(3).forEach { net ->
                            val isSelected = net.networkId == selectedSourceNetwork
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedSourceNetwork = net.networkId },
                                label = { Text(net.shortCode, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ManchesterBrick,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Destination Settlement Network",
                        style = MaterialTheme.typography.bodySmall,
                        color = ManchesterMutedText,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        state.networks.drop(1).take(3).forEach { net ->
                            val isSelected = net.networkId == selectedDestNetwork
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedDestNetwork = net.networkId },
                                label = { Text(net.shortCode, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ManchesterBrick,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Divider(color = ManchesterGraphiteDivider)
                    Spacer(modifier = Modifier.height(14.dp))

                    // Asset & Amount
                    Text(
                        text = "Asset & Transfer Amount",
                        style = MaterialTheme.typography.bodySmall,
                        color = ManchesterMutedText,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("SGBP", "MNC", "BTC", "ETH", "USDC").forEach { symbol ->
                            val isSelected = symbol == selectedInputAsset.value
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selectedInputAsset = AssetId(symbol)
                                    selectedOutputAsset = AssetId(symbol)
                                },
                                label = { Text(symbol, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ManchesterBrassDark,
                                    selectedLabelColor = ManchesterSandstoneLight
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = amountInputText,
                        onValueChange = { amountInputText = it },
                        label = { Text("Transfer Amount (${selectedInputAsset.value})") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("transfer_amount_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ManchesterBrass,
                            unfocusedBorderColor = ManchesterGraphiteBorder,
                            focusedTextColor = ManchesterIvoryText,
                            unfocusedTextColor = ManchesterIvoryText
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val amt = amountInputText.toDoubleOrNull() ?: 100000.0
                            onRequestQuote(
                                selectedSourceNetwork,
                                selectedDestNetwork,
                                selectedInputAsset,
                                selectedOutputAsset,
                                amt
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("generate_quote_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = ManchesterBrick),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Calculate Optimal Interchain Route & Quote", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 2. Active Quote Inspector & Multi-Hop Path Visualizer
        if (state.activeQuote != null) {
            val q = state.activeQuote
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("active_quote_card"),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalCard),
                    border = BorderStroke(1.dp, ManchesterBrass)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "EXECUTABLE INTERCHAIN QUOTE",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Black,
                                color = ManchesterBrassLight
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = StatusSettledBg
                            ) {
                                Text(
                                    text = q.status.name,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StatusSettledGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Quote ID: ${q.quoteId.value}",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = ManchesterMutedText,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Multi-Hop Path Visualizer
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(6.dp),
                            colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalBg),
                            border = BorderStroke(1.dp, ManchesterGraphiteBorder)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "DISCOVERED ROUTE PATH",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ManchesterSandstone,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = q.route.pathName,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = ManchesterIvoryText,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Settlement Mechanism: ${q.route.settlementMechanism.displayName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = StatusRoutingBlue,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Quote Financial Details
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Input Amount", style = MaterialTheme.typography.bodySmall, color = ManchesterMutedText)
                            Text(
                                text = q.inputAsset.formatAmount(q.inputAmount),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = ManchesterIvoryText
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Expected Output", style = MaterialTheme.typography.bodySmall, color = ManchesterMutedText)
                            Text(
                                text = q.outputAsset.formatAmount(q.expectedOutputAmount),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = StatusSettledGreen
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Effective Rate", style = MaterialTheme.typography.bodySmall, color = ManchesterMutedText)
                            Text(text = q.exchangeRateFormatted, style = MaterialTheme.typography.bodySmall, color = ManchesterBrassLight)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Total Routing & Network Fee", style = MaterialTheme.typography.bodySmall, color = ManchesterMutedText)
                            Text(
                                text = "£${String.format(Locale.UK, "%.2f", q.totalFeeGbp)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = ManchesterSandstoneLight
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = onExecuteQuote,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("execute_quote_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = StatusSettledBg),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, StatusSettledGreen)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null, tint = StatusSettledGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Lock Quote & Authorise Cross-Chain Settlement",
                                color = StatusSettledGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 3. Registered Bridges List
        item {
            SectionHeader(
                title = "Registered Interchain Bridges",
                subtitle = "Institutional relayers, light-clients & multi-sig attestations"
            )
        }

        items(state.bridges) { bridge ->
            BridgeCard(bridge = bridge)
        }
    }
}

@Composable
fun BridgeCard(
    bridge: BridgeDescriptor,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ManchesterCharcoalSurface),
        border = BorderStroke(1.dp, ManchesterGraphiteBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = bridge.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = ManchesterIvoryText
                )
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = if (bridge.status == BridgeStatus.OPERATIONAL) StatusSettledBg else StatusFailedBg
                ) {
                    Text(
                        text = bridge.status.name,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (bridge.status == BridgeStatus.OPERATIONAL) StatusSettledGreen else StatusFailedRed,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${bridge.sourceNetwork.value} ⟶ ${bridge.destinationNetwork.value}",
                style = MaterialTheme.typography.bodySmall,
                color = ManchesterBrassLight,
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Trust Model: ${bridge.trustModel.displayName}",
                style = MaterialTheme.typography.bodySmall,
                color = ManchesterMutedText,
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Daily Limit: £${NumberFormat.getNumberInstance(Locale.UK).format(bridge.dailyLimitGbp)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ManchesterSubtleText,
                    fontSize = 10.sp
                )
                Text(
                    text = "Avg Latency: ${bridge.avgLatencySeconds}s • ${bridge.validatorCount} verifiers",
                    style = MaterialTheme.typography.bodySmall,
                    color = ManchesterSubtleText,
                    fontSize = 10.sp
                )
            }
        }
    }
}
