package com.example.min.domain.model

enum class ProtocolType {
    MANCHESTER_BFT,
    EVM,
    BITCOIN_UTXO,
    SYNTHETIC_CLEARING,
    STABLECOIN_RAIL,
    RWA_REGISTRY
}

enum class FinalityModel(val description: String) {
    EXPLICIT_BFT_INSTITUTIONAL("Deterministic Single-Slot BFT Finality"),
    CONFIRMATION_DEPTH("Block Depth Threshold Finality"),
    PROBABILISTIC_POW("Nakamoto Probabilistic Poisson Finality"),
    OPTIMISTIC_CHALLENGE("Challenge Window Fraud Proof Finality"),
    INSTANT_CLEARING("Central Bank / RTGS Clearing Finality")
}

enum class NetworkHealthState {
    HEALTHY,
    DEGRADED,
    OUTAGE,
    SYNCHRONIZING
}

enum class IntegrationMode {
    LIVE,
    SIMULATED,
    MOCKED,
    UNAVAILABLE
}

data class ConfirmationPolicy(
    val standardConfirmations: Int,
    val highValueConfirmations: Int,
    val highValueThresholdGbp: Double,
    val targetBlockTimeSeconds: Double,
    val maxReorgDepthProtected: Int
)

enum class NetworkCapability {
    SMART_CONTRACTS,
    NATIVE_ASSET_TRANSFERS,
    ADAPTOR_SIGNATURES,
    HTLC_CONTRACTS,
    PROOF_EMISSION,
    CROSS_CHAIN_CALLS,
    ZERO_GAS_INTERCHAIN_RELAY,
    CONFIDENTIAL_SETTLEMENT
}

data class ChainNetwork(
    val networkId: NetworkId,
    val chainId: ChainId,
    val name: String,
    val shortCode: String,
    val protocol: ProtocolType,
    val nativeAssetId: AssetId,
    val rpcEndpoints: List<String>,
    val finalityModel: FinalityModel,
    val blockHeight: Long,
    val latestBlockHash: BlockHash,
    val peerCount: Int,
    val confirmationPolicy: ConfirmationPolicy,
    val capabilities: Set<NetworkCapability>,
    val healthState: NetworkHealthState,
    val integrationMode: IntegrationMode,
    val adapterVersion: String,
    val blockLatencyMs: Long,
    val totalTransactionsObserved: Long,
    val description: String
)
