# AUREOM MUSIC LIBRARY - ARCHITECTURE BLUEPRINT

Aureom is a production-grade, offline-first personal music manager and playback platform engineered for Linux.

## System Topology

```text
                               AUREOM MUSIC DESKTOP (Tauri Shell)
                                               │
               ┌───────────────────────────────┼───────────────────────────────┐
               │                               │                               │
        [LIBRARY ENGINE]               [AUDIO PIPELINE]                [SOCIAL CONNECT]
               │                               │                               │
        SQLite Database (WAL)         GStreamer Pipeline               Axum Socket Client
        FTS5 Search Indices           PipeWire Stream Node             HTTPS Publishing API
        Recursive File Scanner        Gapless Pre-roll Buffer          WebRTC Share Rooms
               │                               │                               │
               └───────────────────────────────┼───────────────────────────────┘
                                               │
                                       RUST SYSTEMS CORE
                                               │
                                     Linux Filesystem (ext4)
```

## Layer Definitions

1. **User Interface (TypeScript / React / Tailwind)**:
   - Houses the visual shell, responsive grids, virtualization logic, and control inputs.
   - Communicates with Rust through Tauri's strongly-typed async command channels and event emission loops.

2. **Core Storage Engine (Rust + SQLite)**:
   - Employs SQLite in Write-Ahead Logging (WAL) mode for transactional safety.
   - Normalizes the domain schema: Works, Recordings, Releases, and Tracks to properly support remixes, alternative takes, and masters.
   - Computes complex metadata metrics, play frequency trends, and decadal listening breakdowns locally.

3. **Audio Engine (Rust + GStreamer + PipeWire)**:
   - Configures a GStreamer `playbin` with customizable audio sinks targeting PipeWire.
   - Enforces genuine **gapless playback** by monitoring state buffers and pre-loading Track B while Track A approaches completion.
   - Preserves source bit-depths and sample rates, passing raw streams directly to PipeWire nodes without unnecessary resampling.

4. **Federated Social Core (Rust + Axum WebSockets)**:
   - Keeps user data strictly private and local by default.
   - Restricts external sync entirely to items marked explicitly as `PUBLIC` or `FOLLOWERS` on a track-by-track basis.
   - Facilitates real-time "Listen Together" lobbies using simple playback synchronization clocks.
