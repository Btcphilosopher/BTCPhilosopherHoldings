//! Aureom Music Core Models
//! Defines the foundational domain entities for the Linux Personal Music Library.

use serde::{Serialize, Deserialize};
use std::path::PathBuf;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrackFileIdentity {
    pub absolute_path: PathBuf,
    pub file_size: u64,
    pub modification_time: u64,
    pub audio_duration_ms: u64,
    pub content_hash: Option<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PlaybackState {
    Stopped,
    Loading,
    Playing,
    Paused,
    Seeking,
    Buffering,
    Finished,
    Error,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlayerState {
    pub current_track: Option<Track>,
    pub position_ms: u64,
    pub duration_ms: u64,
    pub volume: f32, // 0.0 to 1.0
    pub muted: bool,
    pub shuffle: bool,
    pub repeat_mode: RepeatMode,
    pub queue: Vec<Track>,
    pub playback_state: PlaybackState,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum RepeatMode {
    Off,
    One,
    All,
}

/// The architectural music model: WORK -> RECORDING -> RELEASE -> TRACK
/// This represents a composition (e.g. Beethoven's 5th, or Comfortably Numb).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Work {
    pub id: String,
    pub title: String,
    pub composer_id: Option<String>,
    pub year: Option<i32>,
}

/// This represents an actual recorded performance of a WORK.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Recording {
    pub id: String,
    pub work_id: Option<String>,
    pub artist_id: String,
    pub duration_ms: u64,
    pub is_live: bool,
    pub is_remix: bool,
}

/// This represents a specific publication release containing RECORDINGS (e.g. CD, Vinyl, Digital).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Release {
    pub id: String,
    pub title: String,
    pub artist_id: String,
    pub year: i32,
    pub genre: String,
    pub label: Option<String>,
    pub mb_release_id: Option<String>, // MusicBrainz ID
}

/// This represents a specific audio file track in a release.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Track {
    pub id: String,
    pub release_id: String,
    pub recording_id: String,
    pub track_number: u32,
    pub disc_number: u32,
    pub title: String,
    pub artist: String,
    pub file_identity: TrackFileIdentity,
    pub format: String, // "FLAC", "MP3", etc.
    pub bitrate: u32, // kbps
    pub sample_rate: u32, // Hz
    pub bit_depth: Option<u32>, // e.g. 24 for high-res
    pub channels: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Artist {
    pub id: String,
    pub name: String,
    pub bio: Option<String>,
    pub mb_artist_id: Option<String>,
}
