-- Aureom Music Library Database Initial Schema
-- Designed for SQLite with WAL mode, foreign keys, and FTS5.

-- Ensure Foreign Keys are enabled
PRAGMA foreign_keys = ON;

-- Core Music Catalog Model
CREATE TABLE IF NOT EXISTS artists (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    bio TEXT,
    mb_artist_id TEXT, -- MusicBrainz artist ID
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS works (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    composer_id TEXT,
    year INTEGER,
    FOREIGN KEY(composer_id) REFERENCES artists(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS recordings (
    id TEXT PRIMARY KEY,
    work_id TEXT,
    artist_id TEXT NOT NULL,
    duration_ms INTEGER NOT NULL,
    is_live BOOLEAN NOT NULL DEFAULT 0,
    is_remix BOOLEAN NOT NULL DEFAULT 0,
    FOREIGN KEY(work_id) REFERENCES works(id) ON DELETE SET NULL,
    FOREIGN KEY(artist_id) REFERENCES artists(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS releases (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    artist_id TEXT NOT NULL,
    year INTEGER NOT NULL,
    genre TEXT NOT NULL,
    label TEXT,
    mb_release_id TEXT, -- MusicBrainz release ID
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(artist_id) REFERENCES artists(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tracks (
    id TEXT PRIMARY KEY,
    release_id TEXT NOT NULL,
    recording_id TEXT NOT NULL,
    track_number INTEGER NOT NULL,
    disc_number INTEGER NOT NULL,
    title TEXT NOT NULL,
    artist TEXT NOT NULL,
    absolute_path TEXT UNIQUE NOT NULL,
    file_size INTEGER NOT NULL,
    modification_time INTEGER NOT NULL,
    audio_duration_ms INTEGER NOT NULL,
    content_hash TEXT,
    format TEXT NOT NULL,
    bitrate INTEGER NOT NULL,
    sample_rate INTEGER NOT NULL,
    bit_depth INTEGER,
    channels INTEGER NOT NULL,
    rating INTEGER DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
    is_favourite BOOLEAN DEFAULT 0,
    play_count INTEGER DEFAULT 0,
    skip_count INTEGER DEFAULT 0,
    last_played TIMESTAMP,
    FOREIGN KEY(release_id) REFERENCES releases(id) ON DELETE CASCADE,
    FOREIGN KEY(recording_id) REFERENCES recordings(id) ON DELETE CASCADE
);

-- Indexing for high-performance scanning and library queries
CREATE INDEX IF NOT EXISTS idx_tracks_release ON tracks(release_id);
CREATE INDEX IF NOT EXISTS idx_tracks_recording ON tracks(recording_id);
CREATE INDEX IF NOT EXISTS idx_releases_artist ON releases(artist_id);
CREATE INDEX IF NOT EXISTS idx_tracks_rating ON tracks(rating);
CREATE INDEX IF NOT EXISTS idx_tracks_path ON tracks(absolute_path);

-- Playlists
CREATE TABLE IF NOT EXISTS playlists (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_smart BOOLEAN NOT NULL DEFAULT 0,
    smart_rules TEXT -- JSON block representing smart rule conditions (ALL/ANY, filters)
);

CREATE TABLE IF NOT EXISTS playlist_items (
    playlist_id TEXT NOT NULL,
    track_id TEXT NOT NULL,
    sort_order INTEGER NOT NULL,
    PRIMARY KEY (playlist_id, track_id),
    FOREIGN KEY(playlist_id) REFERENCES playlists(id) ON DELETE CASCADE,
    FOREIGN KEY(track_id) REFERENCES tracks(id) ON DELETE CASCADE
);

-- History
CREATE TABLE IF NOT EXISTS play_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    track_id TEXT NOT NULL,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    duration_played_ms INTEGER NOT NULL,
    completed BOOLEAN NOT NULL,
    FOREIGN KEY(track_id) REFERENCES tracks(id) ON DELETE CASCADE
);

-- Social Profiles & Activity
CREATE TABLE IF NOT EXISTS social_profiles (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    visibility TEXT NOT NULL CHECK (visibility IN ('PRIVATE', 'FOLLOWERS', 'CLOSE_FRIENDS', 'PUBLIC')),
    listening_now_enabled BOOLEAN DEFAULT 0,
    avatar_url TEXT
);

CREATE TABLE IF NOT EXISTS social_publications (
    id TEXT PRIMARY KEY,
    track_id TEXT NOT NULL,
    owner_id TEXT NOT NULL,
    title TEXT NOT NULL,
    artist TEXT NOT NULL,
    vis_policy TEXT NOT NULL CHECK (vis_policy IN ('LOCAL_ONLY', 'METADATA_ONLY', 'APPROVED_ONLY', 'PUBLIC_STREAM')),
    stream_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(track_id) REFERENCES tracks(id) ON DELETE CASCADE,
    FOREIGN KEY(owner_id) REFERENCES social_profiles(id) ON DELETE CASCADE
);

-- Search Index FTS5 Table for ultra-fast matching
CREATE VIRTUAL TABLE IF NOT EXISTS fts_library_search USING fts5(
    track_id,
    title,
    artist,
    album,
    genre,
    composer
);
