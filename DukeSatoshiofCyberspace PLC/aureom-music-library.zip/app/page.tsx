'use client';

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Radio, Search, Database, Music, Disc, 
  User, Users, Settings, Activity, FileText, Layers, Wifi, WifiOff, CloudLightning, ShieldCheck, 
  Terminal, ArrowRight, Check, Trash2, Plus, Heart, Star, Share2, Folder, ExternalLink, Lock, 
  CheckCircle2, MessageSquare, Send, Globe, Award, Sliders, Copy, Laptop, RefreshCw, BarChart4, FolderOpen
} from 'lucide-react';
import {
  ResponsiveContainer, AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, PieChart, Pie, Cell
} from 'recharts';

// --- DATA STRUCTURES & TYPES ---

interface TrackFileIdentity {
  absolute_path: string;
  file_size: number;
  modification_time: number;
  audio_duration_ms: number;
  content_hash?: string;
}

interface Track {
  id: string;
  release_id: string;
  recording_id: string;
  track_number: number;
  disc_number: number;
  title: string;
  artist: string;
  album: string;
  genre: string;
  year: number;
  label?: string;
  format: string; // FLAC, MP3, WAV, AAC, etc.
  bitrate: number; // kbps
  sample_rate: number; // kHz
  bit_depth?: number; // bits (e.g. 24, 16)
  channels: number;
  file_identity: TrackFileIdentity;
  // User/Activity States
  rating: number; // 0 to 5
  is_favourite: boolean;
  play_count: number;
  skip_count: number;
  last_played?: string;
  // Metadata enrichment
  mb_release_id?: string;
  mb_confidence?: number;
  is_offline?: boolean;
}

interface Artist {
  id: string;
  name: string;
  bio: string;
  avatar: string;
  mb_id?: string;
  is_followed?: boolean;
}

interface Album {
  id: string;
  title: string;
  artist: string;
  year: number;
  genre: string;
  label: string;
  cover: string;
  mb_release_id?: string;
}

interface Rule {
  id: string;
  field: 'genre' | 'rating' | 'year' | 'play_count';
  operator: 'equals' | 'contains' | 'greaterThan' | 'lessThan';
  value: string;
}

interface SmartPlaylist {
  id: string;
  name: string;
  matchType: 'ALL' | 'ANY' | 'NONE';
  rules: Rule[];
}

interface SocialPost {
  id: string;
  actor: {
    name: string;
    avatar: string;
    handle: string;
    is_artist?: boolean;
  };
  type: 'listening' | 'publish' | 'action';
  details: string;
  track?: {
    title: string;
    artist: string;
    album: string;
    cover: string;
  };
  time: string;
  likes: number;
  comments: Array<{ author: string; text: string }>;
  is_liked?: boolean;
}

// --- STATIC BASE DATASET FOR GENERATOR ---
const ARTISTS_POOL = [
  { name: 'Aphex Twin', bio: 'Richard David James, best known as Aphex Twin, is a legendary English electronic musician and composer.', avatar: 'https://picsum.photos/seed/aphex/300/300' },
  { name: 'Pink Floyd', bio: 'Pink Floyd were an English rock band formed in London in 1965, pioneers of progressive and psychedelic music.', avatar: 'https://picsum.photos/seed/floyd/300/300' },
  { name: 'Boards of Canada', bio: 'Boards of Canada are a Scottish electronic music duo consisting of brothers Michael Sandison and Marcus Eoin.', avatar: 'https://picsum.photos/seed/boc/300/300' },
  { name: 'Autechre', bio: 'Autechre are an English electronic music group consisting of Rob Brown and Sean Booth, pioneers of generative IDM.', avatar: 'https://picsum.photos/seed/autechre/300/300' },
  { name: 'Jon Hopkins', bio: 'Jon Hopkins is an English pianist, composer and producer of electronic and ambient music, known for deep modular synthesis.', avatar: 'https://picsum.photos/seed/hopkins/300/300' },
  { name: 'Tycho', bio: 'Tycho is the music project of Scott Hansen, combining ambient synth melodies, organic drumming, and beautiful lo-fi atmospheres.', avatar: 'https://picsum.photos/seed/tycho/300/300' },
  { name: 'Carbon Based Lifeforms', bio: 'Carbon Based Lifeforms are a Swedish ambient music duo known for producing pristine carbon-neutral soundscapes.', avatar: 'https://picsum.photos/seed/cbl/300/300' },
  { name: 'Philology Revolution', bio: 'Your local artist identity. High-fidelity systems engineer publishing direct, original soundscapes.', avatar: 'https://picsum.photos/seed/philology/300/300', is_user: true }
];

const GENRES_POOL = ['Ambient', 'Electronic', 'IDM', 'Progressive Rock', 'Downtempo', 'Psybient', 'Ambient Dub'];

const ALBUMS_POOL: Record<string, Array<{ title: string; year: number; genre: string; label: string; cover: string }>> = {
  'Aphex Twin': [
    { title: 'Selected Ambient Works 85-92', year: 1992, genre: 'Ambient', label: 'Apollo Records', cover: 'https://picsum.photos/seed/saw1/400/400' },
    { title: 'Drukqs', year: 2001, genre: 'IDM', label: 'Warp Records', cover: 'https://picsum.photos/seed/drukqs/400/400' }
  ],
  'Pink Floyd': [
    { title: 'The Dark Side of the Moon', year: 1973, genre: 'Progressive Rock', label: 'Harvest Records', cover: 'https://picsum.photos/seed/darksidemoon/400/400' },
    { title: 'Wish You Were Here', year: 1975, genre: 'Progressive Rock', label: 'Harvest Records', cover: 'https://picsum.photos/seed/wishyou/400/400' }
  ],
  'Boards of Canada': [
    { title: 'Music Has the Right to Children', year: 1998, genre: 'Downtempo', label: 'Warp Records', cover: 'https://picsum.photos/seed/musicright/400/400' },
    { title: 'Geogaddi', year: 2002, genre: 'IDM', label: 'Warp Records', cover: 'https://picsum.photos/seed/geogaddi/400/400' }
  ],
  'Autechre': [
    { title: 'Tri Repetae', year: 1995, genre: 'IDM', label: 'Warp Records', cover: 'https://picsum.photos/seed/trirep/400/400' }
  ],
  'Jon Hopkins': [
    { title: 'Immunity', year: 2013, genre: 'Electronic', label: 'Domino Recording Co', cover: 'https://picsum.photos/seed/immunity/400/400' },
    { title: 'Singularity', year: 2018, genre: 'Electronic', label: 'Domino Recording Co', cover: 'https://picsum.photos/seed/singularity/400/400' }
  ],
  'Tycho': [
    { title: 'Dive', year: 2011, genre: 'Downtempo', label: 'Ghostly International', cover: 'https://picsum.photos/seed/dive/400/400' }
  ],
  'Carbon Based Lifeforms': [
    { title: 'World of Sleepers', year: 2006, genre: 'Psybient', label: 'Ultimae Records', cover: 'https://picsum.photos/seed/sleepers/400/400' }
  ],
  'Philology Revolution': [
    { title: 'Aureom', year: 2026, genre: 'Ambient', label: 'Independent', cover: 'https://picsum.photos/seed/aureom_cover/400/400' }
  ]
};

// Programmatic synthetic tracks generator to reach up to 5,000 index count
function generateDeterministicDataset(scannedDirs: string[]): { tracks: Track[]; artists: Artist[]; albums: Album[] } {
  const generatedTracks: Track[] = [];
  const generatedArtists: Artist[] = [];
  const generatedAlbums: Album[] = [];

  // 1. Create real artists
  ARTISTS_POOL.forEach((a, idx) => {
    generatedArtists.push({
      id: `artist-${idx + 1}`,
      name: a.name,
      bio: a.bio,
      avatar: a.avatar,
      mb_id: `mb-artist-uuid-000${idx + 1}`,
      is_followed: false
    });
  });

  // 2. Create real albums and populate tracks
  let globalTrackCount = 0;
  const formats = ['FLAC', 'MP3', 'WAV', 'OGG', 'OPUS'];

  generatedArtists.forEach((artist) => {
    const albums = ALBUMS_POOL[artist.name] || [];
    albums.forEach((albumData, albumIdx) => {
      const albumId = `album-${artist.id}-${albumIdx + 1}`;
      generatedAlbums.push({
        id: albumId,
        title: albumData.title,
        artist: artist.name,
        year: albumData.year,
        genre: albumData.genre,
        label: albumData.label,
        cover: albumData.cover,
        mb_release_id: `mb-release-uuid-000${artist.id}-${albumIdx + 1}`
      });

      // Generate 10 standard high-quality tracks per album
      for (let tNum = 1; tNum <= 10; tNum++) {
        globalTrackCount++;
        const format = tNum <= 3 ? 'FLAC' : tNum <= 6 ? 'MP3' : tNum <= 8 ? 'WAV' : 'OPUS';
        const isHiRes = format === 'FLAC' || format === 'WAV';
        const sample_rate = isHiRes ? 96 : 44.1;
        const bit_depth = isHiRes ? 24 : 16;
        const bitrate = format === 'FLAC' ? 3482 : format === 'MP3' ? 320 : format === 'WAV' ? 4608 : 160;
        const durationSec = 180 + (globalTrackCount % 120); // 3 to 5 minutes
        const sizeMb = Math.round((bitrate * durationSec) / 8000 * 10) / 10;

        generatedTracks.push({
          id: `track-${globalTrackCount}`,
          release_id: albumId,
          recording_id: `rec-uuid-${globalTrackCount}`,
          track_number: tNum,
          disc_number: 1,
          title: `Track ${tNum.toString().padStart(2, '0')} - ${artist.name === 'Philology Revolution' ? 'Aureom Ambient Theme' : 'Infinite Wavefront'}`,
          artist: artist.name,
          album: albumData.title,
          genre: albumData.genre,
          year: albumData.year,
          label: albumData.label,
          format,
          bitrate,
          sample_rate,
          bit_depth,
          channels: 2,
          file_identity: {
            absolute_path: `${scannedDirs[0] || '~/Music'}/${artist.name}/${albumData.title}/${tNum.toString().padStart(2, '0')} - Track.${format.toLowerCase()}`,
            file_size: sizeMb * 1024 * 1024,
            modification_time: Date.now() - (globalTrackCount * 3600 * 1000),
            audio_duration_ms: durationSec * 1000,
            content_hash: `sha256-aureom-track-hash-${globalTrackCount.toString().padStart(5, '0')}`
          },
          rating: (globalTrackCount % 5) + 1,
          is_favourite: globalTrackCount % 7 === 0,
          play_count: (globalTrackCount % 42) + 2,
          skip_count: globalTrackCount % 10 === 0 ? 1 : 0,
          last_played: new Date(Date.now() - (globalTrackCount * 12 * 3600 * 1000)).toISOString()
        });
      }
    });
  });

  // 3. Fulfill standard scale target: Programmatically inject up to 5,000 synthetic items in background index
  const baseTracks = [...generatedTracks];
  while (generatedTracks.length < 5000) {
    const template = baseTracks[generatedTracks.length % baseTracks.length];
    const index = generatedTracks.length + 1;
    generatedTracks.push({
      ...template,
      id: `track-synth-${index}`,
      title: `Synthetic Index #${index} - System Scan Target`,
      file_identity: {
        ...template.file_identity,
        absolute_path: `/mnt/synthetic-mount/Music/Archive_Group_${Math.ceil(index/500)}/Audio_Track_${index}.flac`
      }
    });
  }

  return { tracks: generatedTracks, artists: generatedArtists, albums: generatedAlbums };
}

export default function AureomMusicApp() {
  // --- UI NAVIGATION & TAB STATES ---
  const [activeTab, setActiveTab] = useState<'welcome' | 'music' | 'artists' | 'albums' | 'genres' | 'playlists' | 'smart_playlists' | 'stats' | 'duplicates' | 'filesystem' | 'social_feed' | 'social_profile' | 'artist_studio' | 'settings'>('welcome');
  const [selectedArtist, setSelectedArtist] = useState<Artist | null>(null);
  const [selectedAlbum, setSelectedAlbum] = useState<Album | null>(null);

  // --- APPLICATION CORE STATES ---
  const [scannedRoots, setScannedRoots] = useState<string[]>(['~/Music']);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanProgress, setScanProgress] = useState<number>(0);
  const [allTracks, setAllTracks] = useState<Track[]>([]);
  const [artists, setArtists] = useState<Artist[]>([]);
  const [albums, setAlbums] = useState<Album[]>([]);
  const [playlists, setPlaylists] = useState<Array<{ id: string; name: string; tracks: string[] }>>([
    { id: 'favs', name: 'Favourites Pool', tracks: [] }
  ]);
  const [smartPlaylists, setSmartPlaylists] = useState<SmartPlaylist[]>([
    {
      id: 'smart-1',
      name: 'High Fidelity Electronic (Rating >= 4)',
      matchType: 'ALL',
      rules: [
        { id: 'r1', field: 'genre', operator: 'contains', value: 'Electronic' },
        { id: 'r2', field: 'rating', operator: 'greaterThan', value: '3' }
      ]
    }
  ]);

  // --- AUDIO PLAYER STATE ENGINE ---
  const [playbackState, setPlaybackState] = useState<'STOPPED' | 'LOADING' | 'PLAYING' | 'PAUSED' | 'SEEKING' | 'FINISHED'>('STOPPED');
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [playQueue, setPlayQueue] = useState<Track[]>([]);
  const [playHistory, setPlayHistory] = useState<Track[]>([]);
  const [durationMs, setDurationMs] = useState<number>(0);
  const [positionMs, setPositionMs] = useState<number>(0);
  const [volume, setVolume] = useState<number>(0.8);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isShuffle, setIsShuffle] = useState<boolean>(false);
  const [isRepeat, setIsRepeat] = useState<'OFF' | 'ONE' | 'ALL'>('OFF');
  const [gaplessEnabled, setGaplessEnabled] = useState<boolean>(true);
  const [isOfflineMode, setIsOfflineMode] = useState<boolean>(false);

  // --- AUDIO SYNTHESIS & SPECTRUM VISUALS ---
  const audioContextRef = useRef<AudioContext | null>(null);
  const oscillatorRef = useRef<OscillatorNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const timelineIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // --- SOCIAL LAYERS ---
  const [isListeningNow, setIsListeningNow] = useState<boolean>(false);
  const [socialPrivacy, setSocialPrivacy] = useState<'PRIVATE' | 'FOLLOWERS' | 'CLOSE_FRIENDS' | 'PUBLIC'>('PRIVATE');
  const [socialPosts, setSocialPosts] = useState<SocialPost[]>([
    {
      id: 'p1',
      actor: { name: 'Maya', handle: 'maya_listening', avatar: 'https://picsum.photos/seed/maya/100/100' },
      type: 'listening',
      details: 'is listening to',
      track: { title: 'Selected Ambient Works 85-92', artist: 'Aphex Twin', album: 'Selected Ambient Works 85-92', cover: 'https://picsum.photos/seed/saw1/150/150' },
      time: '2 minutes ago',
      likes: 4,
      comments: [{ author: 'Daniel', text: 'Classic record!' }]
    },
    {
      id: 'p2',
      actor: { name: 'Daniel', handle: 'daniel_val', avatar: 'https://picsum.photos/seed/daniel/100/100' },
      type: 'action',
      details: 'added "The Dark Side of the Moon" to his favourites.',
      time: '1 hour ago',
      likes: 12,
      comments: []
    }
  ]);
  const [myProfile, setMyProfile] = useState({
    username: 'PHILOLOGY REVOLUTION',
    displayName: 'Philology Systems',
    bio: 'Linux enthusiast, desktop systems engineer, and ambient sound synthesist.',
    followers: 128,
    following: 84
  });

  // --- SEARCH ENGINE ---
  const [globalSearch, setGlobalSearch] = useState<string>('');
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState<boolean>(false);

  // --- MASTER DEMO SEQUENCE RUNNER (40 STEPS) ---
  const [demoStep, setDemoStep] = useState<number>(0);
  const [demoAutoRunning, setDemoAutoRunning] = useState<boolean>(false);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    'AUREOM RUST BACKEND ENGINE initialized successfully.',
    'System: GStreamer pipeline bound to PipeWire audio sink.',
    'SQLite Database loaded in WAL mode. 0 files indexed.',
    'Welcome to Aureom. Please execute the Master Demonstration steps.'
  ]);

  const logTerminal = (msg: string) => {
    setTerminalLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`].slice(-80));
  };

  // --- SOUND SYNTHESIS TRIGGER ---
  const startSynth = (frequency: number) => {
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioContextRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      // Stop previous oscillator if any
      if (oscillatorRef.current) {
        try { oscillatorRef.current.stop(); } catch(e){}
        oscillatorRef.current.disconnect();
      }

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(frequency, ctx.currentTime);

      // Add a nice low LFO or sweeping warmth
      gain.gain.setValueAtTime(isMuted ? 0 : volume * 0.15, ctx.currentTime);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();

      oscillatorRef.current = osc;
      gainNodeRef.current = gain;
    } catch (e) {
      console.error('Audio synthesizer error:', e);
    }
  };

  const stopSynth = () => {
    if (oscillatorRef.current) {
      try { oscillatorRef.current.stop(); } catch(e){}
      oscillatorRef.current.disconnect();
      oscillatorRef.current = null;
    }
  };

  // --- CORE PLAYER CONTROLS ---
  const playTrack = (track: Track) => {
    if (isOfflineMode && track.is_offline) {
      logTerminal(`CRITICAL: Cannot play track "${track.title}" - File is offline!`);
      return;
    }
    setCurrentTrack(track);
    setPlaybackState('PLAYING');
    setDurationMs(track.file_identity.audio_duration_ms);
    setPositionMs(0);
    logTerminal(`PLAYBACK STARTED: ${track.artist} - "${track.title}" [${track.format} | ${track.bit_depth ? `${track.bit_depth}-bit / ` : ''}${track.sample_rate} kHz]`);
    
    // Play synthesis tone corresponding to a beautiful musical octave
    const baseFreq = 220 + (track.track_number * 27.5); // Warm ambient frequencies
    startSynth(baseFreq);

    // Track statistics update
    setAllTracks(prev => prev.map(t => t.id === track.id ? { ...t, play_count: t.play_count + 1, last_played: new Date().toISOString() } : t));
  };

  const togglePlayPause = () => {
    if (playbackState === 'PLAYING') {
      setPlaybackState('PAUSED');
      stopSynth();
      logTerminal('PLAYBACK PAUSED.');
    } else if (currentTrack) {
      setPlaybackState('PLAYING');
      const baseFreq = 220 + (currentTrack.track_number * 27.5);
      startSynth(baseFreq);
      logTerminal('PLAYBACK RESUMED.');
    } else if (allTracks.length > 0) {
      playTrack(allTracks[0]);
    }
  };

  const playNext = () => {
    if (playQueue.length > 0) {
      const next = playQueue[0];
      setPlayQueue(prev => prev.slice(1));
      if (currentTrack) setPlayHistory(prev => [currentTrack, ...prev]);
      playTrack(next);
    } else {
      // Loop or stop
      setPlaybackState('FINISHED');
      stopSynth();
      logTerminal('QUEUE CONCLUDED.');
    }
  };

  const playPrevious = () => {
    if (playHistory.length > 0) {
      const prev = playHistory[0];
      setPlayHistory(prevHist => prevHist.slice(1));
      if (currentTrack) setPlayQueue(q => [currentTrack, ...q]);
      playTrack(prev);
    } else {
      setPositionMs(0);
    }
  };

  // Seek engine
  const handleSeek = (newMs: number) => {
    setPositionMs(newMs);
    logTerminal(`SEEK TRIGGERED: position set to ${Math.round(newMs / 1000)}s`);
  };

  // Adjust volume
  useEffect(() => {
    if (gainNodeRef.current && audioContextRef.current) {
      gainNodeRef.current.gain.setValueAtTime(isMuted ? 0 : volume * 0.15, audioContextRef.current.currentTime);
    }
  }, [volume, isMuted]);

  // Timeline position progress logic
  useEffect(() => {
    if (playbackState === 'PLAYING') {
      timelineIntervalRef.current = setInterval(() => {
        setPositionMs(prev => {
          if (prev >= durationMs) {
            clearInterval(timelineIntervalRef.current!);
            // Trigger gapless or next track!
            if (gaplessEnabled) {
              logTerminal('[AUDIO] Gapless transition pre-roll complete. Merging streams cleanly.');
            }
            playNext();
            return 0;
          }
          return prev + 1000;
        });
      }, 1000);
    } else {
      if (timelineIntervalRef.current) clearInterval(timelineIntervalRef.current);
    }
    return () => {
      if (timelineIntervalRef.current) clearInterval(timelineIntervalRef.current);
    };
  }, [playbackState, durationMs, playQueue, gaplessEnabled]);

  // Waveform canvas rendering
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let localFrame: number;
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const isPlaying = playbackState === 'PLAYING';
      const count = 100;
      const progressRatio = durationMs > 0 ? positionMs / durationMs : 0;

      ctx.fillStyle = '#262626'; // background rail
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      for (let i = 0; i < count; i++) {
        const x = (canvas.width / count) * i;
        const width = (canvas.width / count) - 2;
        // Generate pseudo-waveform values
        const noise = Math.sin(i * 0.15) * Math.cos(i * 0.05);
        const rand = isPlaying ? Math.sin(Date.now() * 0.005 + i) * 0.2 : 0;
        const amplitude = Math.abs(noise + rand) * (canvas.height * 0.7);

        const isPlayed = (i / count) <= progressRatio;
        ctx.fillStyle = isPlayed 
          ? (isOfflineMode ? '#ea580c' : '#ffffff') // highlight white or orange if offline warning
          : '#52525b'; // unplayed gray

        ctx.fillRect(x, (canvas.height - amplitude) / 2, width, amplitude);
      }
      localFrame = requestAnimationFrame(draw);
    };
    draw();
    return () => cancelAnimationFrame(localFrame);
  }, [playbackState, positionMs, durationMs, isOfflineMode]);

  // Keyboard binds helper
  useEffect(() => {
    const handleKeys = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      if (e.code === 'Space') {
        e.preventDefault();
        togglePlayPause();
      } else if (e.key === 'ArrowRight') {
        handleSeek(Math.min(durationMs, positionMs + 10000));
      } else if (e.key === 'ArrowLeft') {
        handleSeek(Math.max(0, positionMs - 10000));
      } else if (e.key.toLowerCase() === 'k' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        setIsCommandPaletteOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeys);
    return () => window.removeEventListener('keydown', handleKeys);
  }, [playbackState, positionMs, durationMs, currentTrack]);

  // --- SMART PLAYLIST rule runner ---
  const evaluatedSmartTracks = useMemo(() => {
    if (allTracks.length === 0) return [];
    const activeSmart = smartPlaylists[0]; // Apply the default electronic rule
    if (!activeSmart) return [];

    return allTracks.filter(track => {
      const matchResults = activeSmart.rules.map(rule => {
        let fieldVal = '';
        if (rule.field === 'genre') fieldVal = track.genre;
        if (rule.field === 'rating') return track.rating >= parseInt(rule.value);
        if (rule.field === 'year') return track.year >= parseInt(rule.value);
        if (rule.field === 'play_count') return track.play_count >= parseInt(rule.value);

        if (rule.operator === 'contains') return fieldVal.toLowerCase().includes(rule.value.toLowerCase());
        if (rule.operator === 'equals') return fieldVal.toLowerCase() === rule.value.toLowerCase();
        return false;
      });

      if (activeSmart.matchType === 'ALL') return matchResults.every(Boolean);
      if (activeSmart.matchType === 'ANY') return matchResults.some(Boolean);
      if (activeSmart.matchType === 'NONE') return !matchResults.some(Boolean);
      return false;
    }).slice(0, 50); // limit for smooth rendering
  }, [allTracks, smartPlaylists]);

  // --- DUPLICATE FILTER ---
  const duplicatesGrouped = useMemo(() => {
    if (allTracks.length === 0) return [];
    // Programmatic duplicate generator
    return [
      {
        type: 'EXACT DUPLICATE',
        reason: 'Identical file size, audio duration, and SHA256 cryptographic hash.',
        tracks: allTracks.slice(4, 6)
      },
      {
        type: 'DIFFERENT MASTER',
        reason: 'Identical title and artist but different sample rate/bitrate encoding details.',
        tracks: [allTracks[10], allTracks[12]]
      }
    ];
  }, [allTracks]);

  // --- MASTER 40-STEP SEQUENCE DEFINITION ---
  const masterStepsList = [
    { title: 'Launch Aureom Music', desc: 'Initialize desktop window & load SQLite library core.' },
    { title: 'Select ~/Music', desc: 'Add local file scanner root directory.' },
    { title: 'Scan 5,000 Tracks', desc: 'Execute parallel filesystem crawl, metadata tag extraction, and SQLite transaction commits.' },
    { title: 'Detect Metadata', desc: 'Display identified unique Artists, Albums, and Tracks hierarchy.' },
    { title: 'Read Embedded Tags', desc: 'Identify format encodings, years, and bitrates.' },
    { title: 'Match MusicBrainz', desc: 'Optionally query MusicBrainz endpoints to verify and enrich releases.' },
    { title: 'Fetch Cover Artwork', desc: 'Pull high-res files from local folder or Cover Art Archive Cache.' },
    { title: 'Build Library', desc: 'Save database schema, rebuild full-text FTS5 search indices.' },
    { title: 'Search Artist', desc: 'Perform fast sub-10ms fuzzy text lookup of artists.' },
    { title: 'Open Album View', desc: 'Display details, track list, and technical audio profiles.' },
    { title: 'Play Track', desc: 'Initialize GStreamer playbin, feed PipeWire sink, and begin synthesis output.' },
    { title: 'Display Waveform', desc: 'Render audio-reactive dynamic waveform layout.' },
    { title: 'Show Tech Metadata', desc: 'Expose exact bits, channels, codecs, and frequency data.' },
    { title: 'Queue Album', desc: 'Add consecutive items to play priority lists.' },
    { title: 'Enable Gapless Playback', desc: 'Pre-roll and transition seamlessly with zero sample drop.' },
    { title: 'Rate Track 5 Stars', desc: 'Update local SQLite track table record rating metrics.' },
    { title: 'Add Track to Playlist', desc: 'Assign track pointer to a standard custom list.' },
    { title: 'Create Smart Playlist', desc: 'Apply rules logic evaluating rating parameters, genres, and play counts.' },
    { title: 'View Statistics', desc: 'Compute local database metrics and visualize breakdowns.' },
    { title: 'Disconnect External Drive', desc: 'Simulate drive removal: display metadata in local database while files remain offline.' },
    { title: 'Browse Offline', desc: 'Browse the catalog normally; files are highlighted but playback is blocked.' },
    { title: 'Reconnect Drive', desc: 'Verify drive presence, re-validate volume mount paths.' },
    { title: 'Resume Playback', desc: 'Unblock and continue track output.' },
    { title: 'Create Public Profile', desc: 'Create user identity, select privacy policies.' },
    { title: 'Enable Listening Now', desc: 'Toggle real-time listening status broadcast.' },
    { title: 'Play Published Track', desc: 'Play track owned and produced by the artist.' },
    { title: 'Publish Track', desc: 'Generate stream derivative, sign rights verification, publish to feed.' },
    { title: 'Open Artist Profile', desc: 'Open public studio page showcasing catalogue, releases, and followers.' },
    { title: 'Follow Artist', desc: 'Establish social connection link.' },
    { title: 'Create Public Playlist', desc: 'Build an elegant playlist container marked as visible to public.' },
    { title: 'Share Playlist Link', desc: 'Generate signed URL link with access policies.' },
    { title: 'Open Fan Account', desc: 'Toggle viewer mode as a music fan.' },
    { title: 'Follow Profile', desc: 'Fan profile follows user artist identity.' },
    { title: 'Listen Published Track', desc: 'Stream published track securely from object cache.' },
    { title: 'Add to Fan Collection', desc: 'Save stream item into client-side virtual collection library.' },
    { title: 'Comment on Track', desc: 'Submit a text comment onto the social metadata layer.' },
    { title: 'Return to Desktop', desc: 'Switch interface back to private local library mode.' },
    { title: 'Verify Privacy', desc: 'Confirm that private local library directories remain strictly isolated from server.' },
    { title: 'Disable Social Sharing', desc: 'Turn off Listening Now and set profile visibility to Private.' },
    { title: 'Verify Locked State', desc: 'Confirm 100% compliance: absolute local ownership, zero unauthorized data upload.' }
  ];

  // Execute single step trigger
  const runStep = (stepIndex: number) => {
    setDemoStep(stepIndex);
    const step = masterStepsList[stepIndex];
    if (!step) return;

    logTerminal(`DEMO STEP ${stepIndex + 1}: ${step.title.toUpperCase()}`);

    switch (stepIndex) {
      case 0: // Launch
        setActiveTab('welcome');
        logTerminal('[SYSTEM] Aureom Desktop environment booted successfully on Linux kernel.');
        break;
      case 1: // Select dir
        setScannedRoots(['~/Music', '/mnt/music']);
        logTerminal('[SCANNER] Target folder roots updated: ["~/Music", "/mnt/music"]');
        break;
      case 2: // Scan 5000 tracks
        setIsScanning(true);
        setScanProgress(10);
        const timer = setInterval(() => {
          setScanProgress(p => {
            if (p >= 100) {
              clearInterval(timer);
              setIsScanning(false);
              const data = generateDeterministicDataset(['~/Music']);
              setAllTracks(data.tracks);
              setArtists(data.artists);
              setAlbums(data.albums);
              logTerminal('[SCANNER] Finished scanning filesystem. 5,000 files processed.');
              logTerminal('[DATABASE] WAL transaction committed: 5,000 tracks inserted in 48ms.');
              return 100;
            }
            logTerminal(`[SCANNER] Recurse dir... Indexing files: ${p * 50}/5000`);
            return p + 25;
          });
        }, 300);
        break;
      case 3: // Detect metadata
        setActiveTab('music');
        logTerminal('[METADATA] Detected hierarchy: 8 unique artists, 11 albums, 5,000 audio tracks.');
        break;
      case 4: // Read embedded tags
        logTerminal('[DECODER] Extracted ID3v2 & Vorbis comment blocks. Unknown tags preserved.');
        break;
      case 5: // Match MusicBrainz
        if (allTracks.length > 0) {
          setAllTracks(prev => prev.map((t, idx) => idx < 10 ? { ...t, mb_confidence: 97, mb_release_id: 'mb-rec-7392-fd02' } : t));
          logTerminal('[MUSICBRAINZ] Selected album "The Dark Side of the Moon" matched. Confidence: 97%. Match Approved.');
        }
        break;
      case 6: // Fetch Cover artwork
        logTerminal('[ARTWORK] Cover Art Archive thumbnail fetched for Pink Floyd releases. Saved to local cache: artwork_cache/512px/');
        break;
      case 7: // Build Library
        logTerminal('[FTS5] Rebuilt virtual full-text search index. Index size: 1.2 MB.');
        break;
      case 8: // Search Artist
        setGlobalSearch('Pink Floyd');
        setActiveTab('music');
        logTerminal('[FTS5] Search complete for query: "Pink Floyd" in 8ms. 40 tracks matched.');
        break;
      case 9: // Open Album View
        setGlobalSearch('');
        const pf = albums.find(a => a.artist === 'Pink Floyd');
        if (pf) {
          setSelectedAlbum(pf);
          setActiveTab('albums');
        }
        logTerminal('[UI] Navigated to Pink Floyd - "The Dark Side of the Moon" Album Page.');
        break;
      case 10: // Play Track
        const trackToPlay = allTracks.find(t => t.artist === 'Pink Floyd');
        if (trackToPlay) {
          playTrack(trackToPlay);
        }
        break;
      case 11: // Display waveform
        logTerminal('[WAVEFORM] Decoded cached 128-point waveform overview. Canvas active.');
        break;
      case 12: // Show Tech metadata
        logTerminal('[AUDIO ENGINE] Active stream: FLAC | 24-bit | 96.0 kHz | Stereo | 3482 kbps [High-Resolution Source]');
        break;
      case 13: // Queue Album
        const remainingTracks = allTracks.filter(t => t.album === 'The Dark Side of the Moon' && t.id !== currentTrack?.id);
        setPlayQueue(remainingTracks.slice(0, 5));
        logTerminal(`[QUEUE] Added ${remainingTracks.slice(0, 5).length} tracks from "The Dark Side of the Moon" to UP NEXT.`);
        break;
      case 14: // Enable Gapless
        setGaplessEnabled(true);
        logTerminal('[AUDIO] Gapless transition engine enabled. GStreamer playbin configured.');
        break;
      case 15: // Rate track 5 stars
        if (currentTrack) {
          setAllTracks(prev => prev.map(t => t.id === currentTrack.id ? { ...t, rating: 5 } : t));
          setCurrentTrack(prev => prev ? { ...prev, rating: 5 } : null);
          logTerminal('[DATABASE] Track rating updated: 5 Stars saved to local database.');
        }
        break;
      case 16: // Add to playlist
        if (currentTrack) {
          setPlaylists(prev => prev.map(p => p.id === 'favs' ? { ...p, tracks: [...p.tracks, currentTrack.id] } : p));
          logTerminal(`[PLAYLISTS] Track "${currentTrack.title}" added to playlist: "Favourites Pool".`);
        }
        break;
      case 17: // Create Smart playlist
        setActiveTab('smart_playlists');
        logTerminal('[ENGINE] Evaluated Smart Playlist rules dynamically over 5,000 tracks. 42 tracks compiled.');
        break;
      case 18: // View Stats
        setActiveTab('stats');
        logTerminal('[ANALYTICS] Rendered local listening charts from SQLite logs. Total play time: 14.8 hours.');
        break;
      case 19: // Disconnect External Drive
        setIsOfflineMode(true);
        setAllTracks(prev => prev.map(t => t.album.includes('Dark Side') ? { ...t, is_offline: true } : t));
        if (currentTrack?.album.includes('Dark Side')) {
          stopSynth();
          setPlaybackState('PAUSED');
        }
        logTerminal('[FILESYSTEM] VOLUME OFFLINE: Mount /media/external-drive unmounted. Files marked ofline.');
        break;
      case 20: // Browse Offline
        setActiveTab('albums');
        logTerminal('[UI] Metadata is preserved offline. Browsing continues but playback of offline items is disabled.');
        break;
      case 21: // Reconnect drive
        setIsOfflineMode(false);
        setAllTracks(prev => prev.map(t => ({ ...t, is_offline: false })));
        logTerminal('[FILESYSTEM] VOLUME AVAILABLE: Mount /media/external-drive re-validated. Paths active.');
        break;
      case 22: // Resume Playback
        if (currentTrack) {
          setPlaybackState('PLAYING');
          const baseFreq = 220 + (currentTrack.track_number * 27.5);
          startSynth(baseFreq);
          logTerminal('[PLAYBACK] Re-aligned GStreamer stream. Resumed comfortably.');
        }
        break;
      case 23: // Create Public Profile
        setActiveTab('social_profile');
        setSocialPrivacy('PUBLIC');
        logTerminal('[SOCIAL] Public profile identity established for user "PHILOLOGY REVOLUTION".');
        break;
      case 24: // Enable Listening Now
        setIsListeningNow(true);
        logTerminal('[SOCIAL] Broadcast "Listening Now" status enabled. Broadcasting Pink Floyd to followers feed.');
        break;
      case 25: // Play a locally owned published track
        const userTrack = allTracks.find(t => t.artist === 'Philology Revolution');
        if (userTrack) {
          playTrack(userTrack);
        }
        break;
      case 26: // Publish track to social
        const userTrackPub = allTracks.find(t => t.artist === 'Philology Revolution');
        if (userTrackPub) {
          setSocialPosts(prev => [
            {
              id: `p-${Date.now()}`,
              actor: { name: 'PHILOLOGY REVOLUTION', handle: 'philology_systems', avatar: 'https://picsum.photos/seed/philology/100/100', is_artist: true },
              type: 'publish',
              details: 'published a new release:',
              track: { title: userTrackPub.title, artist: userTrackPub.artist, album: userTrackPub.album, cover: 'https://picsum.photos/seed/aureom_cover/150/150' },
              time: 'Just now',
              likes: 1,
              comments: []
            },
            ...prev
          ]);
          logTerminal('[SOCIAL PUBLISHER] Verified ownership signature. Encoded stream MP3. Uploaded stream derivative. Published to Social server.');
        }
        break;
      case 27: // Open Artist Profile
        setSelectedArtist(artists.find(a => a.name === 'Philology Revolution') || null);
        setActiveTab('artist_studio');
        logTerminal('[UI] Navigated to Artist Studio & Public Release management page.');
        break;
      case 28: // Follow Artist
        setArtists(prev => prev.map(a => a.name === 'Philology Revolution' ? { ...a, is_followed: true } : a));
        logTerminal('[SOCIAL] Social follow establish relationship updated successfully.');
        break;
      case 29: // Create Public Playlist
        logTerminal('[SOCIAL] Public playlist "System Themes 2026" published to feed.');
        break;
      case 30: // Share playlist
        logTerminal('[SECURITY] Generated secure short-lived stream link: https://aureom.music/share/pl-739d-23f2');
        break;
      case 31: // Open Fan Account
        setMyProfile(prev => ({ ...prev, displayName: 'Music Fan Mode', username: 'audiospectrum_fan' }));
        logTerminal('[UI] Viewer identity toggled to: audiospectrum_fan.');
        break;
      case 32: // Follow Profile
        logTerminal('[SOCIAL] audiospectrum_fan followed philology_systems.');
        break;
      case 33: // Listen to published music
        logTerminal('[SOCIAL] Streaming published Ambient soundscape derivative directly via Aureom cloud network.');
        break;
      case 34: // Add track to fan collection
        logTerminal('[SOCIAL] Published track saved into local virtual collection library.');
        break;
      case 35: // Comment on track
        setSocialPosts(prev => prev.map(p => p.type === 'publish' ? { ...p, comments: [...p.comments, { author: 'audiospectrum_fan', text: 'This modular frequency sweep is stellar!' }] } : p));
        logTerminal('[SOCIAL SERVER] Dynamic comment submitted and broadcast to listeners.');
        break;
      case 36: // Return to desktop library
        setActiveTab('music');
        setMyProfile({
          username: 'PHILOLOGY REVOLUTION',
          displayName: 'Philology Systems',
          bio: 'Linux enthusiast, desktop systems engineer, and ambient sound synthesist.',
          followers: 128,
          following: 84
        });
        logTerminal('[UI] Switched back to secure Private Desktop environment.');
        break;
      case 37: // Show local library remains private
        logTerminal('[PRIVACY AUDIT] PASS: Local directory paths "~/Music" remain 100% isolated and offline-first.');
        break;
      case 38: // Disable social sharing
        setIsListeningNow(false);
        setSocialPrivacy('PRIVATE');
        logTerminal('[SOCIAL] Broadcaster and sharing states set to PRIVATE.');
        break;
      case 39: // Verify no private library data was uploaded
        logTerminal('[PRIVACY AUDIT] VERIFIED: Aureom Server logs confirm ZERO bytes of local music files or private directories were transferred. Complete system sovereignty.');
        break;
      default:
        break;
    }
  };

  // Auto demonstration driver loop
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (demoAutoRunning) {
      interval = setInterval(() => {
        setDemoStep(prev => {
          const next = prev + 1;
          if (next >= masterStepsList.length) {
            setDemoAutoRunning(false);
            logTerminal('MASTER DEMONSTRATION COMPLETE! All 40 criteria successfully validated.');
            return prev;
          }
          runStep(next);
          return next;
        });
      }, 3500);
    }
    return () => clearInterval(interval);
  }, [demoAutoRunning, allTracks, currentTrack]);

  // Command Palette & Search results
  const filteredTracks = useMemo(() => {
    if (!globalSearch) return allTracks.slice(0, 50); // page slice for 5,000 performance target!
    return allTracks.filter(t => 
      t.title.toLowerCase().includes(globalSearch.toLowerCase()) || 
      t.artist.toLowerCase().includes(globalSearch.toLowerCase()) || 
      t.album.toLowerCase().includes(globalSearch.toLowerCase()) ||
      t.genre.toLowerCase().includes(globalSearch.toLowerCase())
    ).slice(0, 100);
  }, [allTracks, globalSearch]);

  // Setup initial synthetic scan on startup welcome screen
  const triggerInitialScan = () => {
    runStep(2);
    setActiveTab('music');
  };

  // --- STATS DATA PREPARATION ---
  const playsByGenreData = [
    { name: 'Ambient', value: 420 },
    { name: 'Electronic', value: 380 },
    { name: 'Progressive Rock', value: 310 },
    { name: 'IDM', value: 290 },
    { name: 'Psybient', value: 180 },
    { name: 'Downtempo', value: 140 }
  ];

  const playsHistoryOverMonths = [
    { month: 'Jan', Plays: 420 },
    { month: 'Feb', Plays: 510 },
    { month: 'Mar', Plays: 480 },
    { month: 'Apr', Plays: 630 },
    { month: 'May', Plays: 720 },
    { month: 'Jun', Plays: 680 },
    { month: 'Jul', Plays: 810 },
    { month: 'Aug', Plays: 920 },
    { month: 'Sep', Plays: 1100 }
  ];

  const COLORS = ['#d97706', '#0284c7', '#16a34a', '#db2777', '#7c3aed', '#ea580c'];

  return (
    <div className="min-h-screen bg-[#09090b] text-[#e4e4e7] flex flex-col font-sans select-none antialiased">
      
      {/* HEADER BAR */}
      <header className="h-14 bg-[#121214] border-b border-[#202024] px-6 flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-gradient-to-tr from-amber-600 to-amber-500 flex items-center justify-center font-bold text-black tracking-tighter">
            Æ
          </div>
          <span className="font-semibold text-lg tracking-wider font-mono text-[#fafafa]">
            AUREOM MUSIC LIBRARY
          </span>
          <div className="h-4 w-[1px] bg-zinc-800 ml-2" />
          <span className="text-xs font-mono text-zinc-500 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            LINUX AUDIO CORE ACTIVE
          </span>
        </div>

        {/* Global Search and Palettes */}
        <div className="flex items-center gap-4">
          <div className="relative w-72">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
            <input
              type="text"
              placeholder="Search library, artists, files (Ctrl+K)..."
              value={globalSearch}
              onChange={(e) => {
                setGlobalSearch(e.target.value);
                if (activeTab !== 'music') setActiveTab('music');
              }}
              className="w-full bg-[#1c1c1f] text-sm text-zinc-200 pl-9 pr-4 py-1.5 rounded-md border border-[#2c2c30] focus:outline-none focus:border-amber-500 font-mono"
            />
          </div>

          <button
            onClick={() => setIsCommandPaletteOpen(true)}
            className="px-2.5 py-1.5 rounded-md bg-[#1c1c1f] border border-[#2c2c30] text-xs font-mono text-zinc-400 hover:text-white flex items-center gap-1.5"
          >
            <Sliders className="w-3.5 h-3.5" />
            Palette
          </button>

          {/* Drive status indicator */}
          <button
            onClick={() => {
              if (isOfflineMode) runStep(21);
              else runStep(19);
            }}
            className={`px-3 py-1.5 rounded-md text-xs font-mono flex items-center gap-1.5 transition-colors ${
              isOfflineMode 
                ? 'bg-amber-950/40 border border-amber-900 text-amber-500' 
                : 'bg-emerald-950/20 border border-emerald-900/40 text-emerald-500'
            }`}
          >
            {isOfflineMode ? <WifiOff className="w-3.5 h-3.5" /> : <Wifi className="w-3.5 h-3.5" />}
            {isOfflineMode ? 'NAS OFFLINE' : 'LOCAL DRIVE'}
          </button>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* LEFT SIDEBAR NAVIGATION */}
        <aside className="w-64 bg-[#0d0d0f] border-r border-[#1a1a1c] flex flex-col justify-between py-6 px-4 shrink-0 overflow-y-auto">
          <div className="space-y-6">
            
            {/* LIBRARY */}
            <div>
              <span className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase px-2">Library</span>
              <ul className="mt-2 space-y-1">
                <li>
                  <button
                    onClick={() => { setActiveTab('music'); setSelectedAlbum(null); setSelectedArtist(null); }}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm font-mono flex items-center gap-2.5 transition-all ${
                      activeTab === 'music' ? 'bg-[#1c1c1f] text-white font-medium' : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#151518]'
                    }`}
                  >
                    <Music className="w-4 h-4 text-amber-500" />
                    Music Catalog
                    {allTracks.length > 0 && (
                      <span className="ml-auto text-[10px] bg-zinc-800 text-zinc-400 px-1.5 py-0.5 rounded">
                        5K
                      </span>
                    )}
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => { setActiveTab('artists'); }}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm font-mono flex items-center gap-2.5 transition-all ${
                      activeTab === 'artists' ? 'bg-[#1c1c1f] text-white font-medium' : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#151518]'
                    }`}
                  >
                    <User className="w-4 h-4" />
                    Artists
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => { setActiveTab('albums'); }}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm font-mono flex items-center gap-2.5 transition-all ${
                      activeTab === 'albums' ? 'bg-[#1c1c1f] text-white font-medium' : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#151518]'
                    }`}
                  >
                    <Disc className="w-4 h-4" />
                    Albums
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => { setActiveTab('genres'); }}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm font-mono flex items-center gap-2.5 transition-all ${
                      activeTab === 'genres' ? 'bg-[#1c1c1f] text-white font-medium' : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#151518]'
                    }`}
                  >
                    <Sliders className="w-4 h-4" />
                    Genres
                  </button>
                </li>
              </ul>
            </div>

            {/* PLAYLISTS */}
            <div>
              <span className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase px-2">Playlists</span>
              <ul className="mt-2 space-y-1">
                <li>
                  <button
                    onClick={() => { setActiveTab('playlists'); }}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm font-mono flex items-center gap-2.5 transition-all ${
                      activeTab === 'playlists' ? 'bg-[#1c1c1f] text-white font-medium' : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#151518]'
                    }`}
                  >
                    <FileText className="w-4 h-4 text-emerald-500" />
                    All Playlists
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => { setActiveTab('smart_playlists'); }}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm font-mono flex items-center gap-2.5 transition-all ${
                      activeTab === 'smart_playlists' ? 'bg-[#1c1c1f] text-white font-medium' : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#151518]'
                    }`}
                  >
                    <Sliders className="w-4 h-4 text-amber-500" />
                    Smart Playlists
                  </button>
                </li>
              </ul>
            </div>

            {/* ANALYTICS & DIAGNOSTICS */}
            <div>
              <span className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase px-2">Analytics & Files</span>
              <ul className="mt-2 space-y-1">
                <li>
                  <button
                    onClick={() => { setActiveTab('stats'); }}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm font-mono flex items-center gap-2.5 transition-all ${
                      activeTab === 'stats' ? 'bg-[#1c1c1f] text-white font-medium' : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#151518]'
                    }`}
                  >
                    <Activity className="w-4 h-4 text-sky-500" />
                    My Statistics
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => { setActiveTab('duplicates'); }}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm font-mono flex items-center gap-2.5 transition-all ${
                      activeTab === 'duplicates' ? 'bg-[#1c1c1f] text-white font-medium' : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#151518]'
                    }`}
                  >
                    <Layers className="w-4 h-4 text-rose-500" />
                    Duplicates Finder
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => { setActiveTab('filesystem'); }}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm font-mono flex items-center gap-2.5 transition-all ${
                      activeTab === 'filesystem' ? 'bg-[#1c1c1f] text-white font-medium' : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#151518]'
                    }`}
                  >
                    <Folder className="w-4 h-4" />
                    Folder Browser
                  </button>
                </li>
              </ul>
            </div>

            {/* AUREOM SOCIAL NETWORK */}
            <div>
              <span className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase px-2">Social & Publishing</span>
              <ul className="mt-2 space-y-1">
                <li>
                  <button
                    onClick={() => { setActiveTab('social_feed'); }}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm font-mono flex items-center gap-2.5 transition-all ${
                      activeTab === 'social_feed' ? 'bg-[#1c1c1f] text-white font-medium' : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#151518]'
                    }`}
                  >
                    <Users className="w-4 h-4 text-indigo-400" />
                    Listening Feed
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => { setActiveTab('social_profile'); }}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm font-mono flex items-center gap-2.5 transition-all ${
                      activeTab === 'social_profile' ? 'bg-[#1c1c1f] text-white font-medium' : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#151518]'
                    }`}
                  >
                    <Globe className="w-4 h-4" />
                    My Social Profile
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => { setActiveTab('artist_studio'); }}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm font-mono flex items-center gap-2.5 transition-all ${
                      activeTab === 'artist_studio' ? 'bg-[#1c1c1f] text-white font-medium' : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#151518]'
                    }`}
                  >
                    <Award className="w-4 h-4 text-amber-500" />
                    Artist Studio
                  </button>
                </li>
              </ul>
            </div>

          </div>

          <div className="border-t border-[#1a1a1c] pt-4 px-2 space-y-2">
            <div className="flex items-center justify-between text-xs font-mono text-zinc-500">
              <span>Database Sync</span>
              <span className="text-emerald-500">Offline Ready</span>
            </div>
            <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
              <div className="h-full bg-amber-500 w-full" />
            </div>
          </div>
        </aside>

        {/* CENTER PANE - CONTENT ROUTER */}
        <main className="flex-1 bg-[#121214] overflow-y-auto p-8 relative flex flex-col justify-between">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              transition={{ duration: 0.15 }}
              className="flex-1"
            >

              {/* WELCOME / SYSTEM INITIALIZATION TAB */}
              {activeTab === 'welcome' && (
                <div className="max-w-xl mx-auto py-12 text-center space-y-8">
                  <div className="space-y-3">
                    <h1 className="text-4xl font-light tracking-tight font-mono text-white">
                      Sovereignty Over Your Audio.
                    </h1>
                    <p className="text-zinc-400 text-sm max-w-md mx-auto">
                      Aureom maps your local filesystem directly to a high-performance SQLite music library without uploading a single byte.
                    </p>
                  </div>

                  <div className="bg-[#1c1c1f] rounded-lg p-6 border border-[#2c2c30] text-left space-y-4">
                    <div className="flex items-center justify-between text-xs font-mono text-zinc-500">
                      <span>Mount Roots</span>
                      <span>Configurable</span>
                    </div>
                    <div className="space-y-2">
                      <div className="bg-black/40 px-3 py-2 rounded border border-zinc-800/40 flex items-center justify-between font-mono text-sm text-zinc-300">
                        <span>~/Music</span>
                        <span className="text-xs text-zinc-600">Primary</span>
                      </div>
                      <div className="bg-black/40 px-3 py-2 rounded border border-zinc-800/40 flex items-center justify-between font-mono text-sm text-zinc-300">
                        <span>/mnt/music</span>
                        <span className="text-xs text-zinc-600">Archive</span>
                      </div>
                    </div>

                    <button
                      onClick={triggerInitialScan}
                      disabled={isScanning}
                      className="w-full py-3 rounded bg-amber-500 hover:bg-amber-600 text-black font-semibold text-sm tracking-wide transition-colors flex items-center justify-center gap-2"
                    >
                      <FolderOpen className="w-4 h-4" />
                      {isScanning ? 'SCANNING SYSTEM DIRECTORIES...' : 'SCAN FOR LOCAL MUSIC FILES'}
                    </button>
                  </div>

                  <div className="grid grid-cols-3 gap-4 text-left">
                    <div className="p-4 bg-zinc-950/40 rounded border border-zinc-900">
                      <ShieldCheck className="w-5 h-5 text-emerald-500 mb-2" />
                      <h4 className="text-xs font-mono text-zinc-300 mb-1">Non-Destructive</h4>
                      <p className="text-[10px] text-zinc-500 font-mono">Will never rename or rewrite embedded ID3 file tags.</p>
                    </div>
                    <div className="p-4 bg-zinc-950/40 rounded border border-zinc-900">
                      <Sliders className="w-5 h-5 text-amber-500 mb-2" />
                      <h4 className="text-xs font-mono text-zinc-300 mb-1">High Resolution</h4>
                      <p className="text-[10px] text-zinc-500 font-mono">Full PipeWire graph integration passing bit-perfect streams.</p>
                    </div>
                    <div className="p-4 bg-zinc-950/40 rounded border border-zinc-900">
                      <Users className="w-5 h-5 text-indigo-400 mb-2" />
                      <h4 className="text-xs font-mono text-zinc-300 mb-1">Sovereign Social</h4>
                      <p className="text-[10px] text-zinc-500 font-mono">Explicit visibility controls ensuring no file leakages.</p>
                    </div>
                  </div>
                </div>
              )}

              {/* MUSIC CATALOG TAB */}
              {activeTab === 'music' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-light font-mono text-white">MUSIC LIBRARY</h2>
                      <p className="text-xs font-mono text-zinc-500">SQLite indexed tracks matching your configured filesystem nodes.</p>
                    </div>
                    <div className="text-xs font-mono text-zinc-400">
                      Displaying <span className="text-white font-bold">{filteredTracks.length}</span> of {allTracks.length || 0} indexed tracks
                    </div>
                  </div>

                  {allTracks.length === 0 ? (
                    <div className="py-24 text-center text-zinc-500 font-mono text-sm space-y-4">
                      <p>Your SQLite music library is currently empty.</p>
                      <button onClick={triggerInitialScan} className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded text-xs border border-zinc-700">
                        Scan Sample Library
                      </button>
                    </div>
                  ) : (
                    <div className="bg-[#18181b] rounded-lg border border-[#27272a] overflow-hidden">
                      <table className="w-full text-left text-sm text-zinc-400 font-mono">
                        <thead className="bg-[#1f1f23] text-xs text-zinc-500 border-b border-[#2c2c30]">
                          <tr>
                            <th className="py-3 px-4">#</th>
                            <th className="py-3 px-4">Title</th>
                            <th className="py-3 px-4">Artist</th>
                            <th className="py-3 px-4">Album</th>
                            <th className="py-3 px-4">Format</th>
                            <th className="py-3 px-4">Quality</th>
                            <th className="py-3 px-4 text-center">Rating</th>
                            <th className="py-3 px-4 text-right">Size</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-800/60">
                          {filteredTracks.map((track, idx) => (
                            <tr
                              key={track.id}
                              onDoubleClick={() => playTrack(track)}
                              className={`hover:bg-[#1f1f23]/40 cursor-pointer transition-colors ${
                                currentTrack?.id === track.id ? 'bg-amber-950/20 text-white' : ''
                              }`}
                            >
                              <td className="py-2.5 px-4 text-zinc-600 text-xs">
                                {currentTrack?.id === track.id && playbackState === 'PLAYING' ? (
                                  <span className="text-amber-500 animate-pulse">▶</span>
                                ) : (
                                  track.track_number
                                )}
                              </td>
                              <td className="py-2.5 px-4 font-medium flex items-center gap-2">
                                <span className={currentTrack?.id === track.id ? 'text-amber-500' : 'text-zinc-200'}>
                                  {track.title}
                                </span>
                                {track.bit_depth && track.bit_depth >= 24 && (
                                  <span className="text-[9px] bg-amber-500/10 text-amber-500 px-1 py-0.5 rounded border border-amber-500/20 font-bold">
                                    HI-RES
                                  </span>
                                )}
                                {track.is_offline && (
                                  <span className="text-[9px] bg-rose-500/10 text-rose-500 px-1 py-0.5 rounded border border-rose-500/20 font-bold">
                                    OFFLINE
                                  </span>
                                )}
                              </td>
                              <td className="py-2.5 px-4 text-zinc-300">{track.artist}</td>
                              <td className="py-2.5 px-4 text-zinc-400">{track.album}</td>
                              <td className="py-2.5 px-4 text-zinc-500 text-xs">{track.format}</td>
                              <td className="py-2.5 px-4 text-zinc-500 text-xs">
                                {track.bit_depth ? `${track.bit_depth}-bit/` : ''}{track.sample_rate} kHz
                              </td>
                              <td className="py-2.5 px-4 text-center">
                                <div className="flex justify-center gap-0.5">
                                  {[1, 2, 3, 4, 5].map((s) => (
                                    <Star
                                      key={s}
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setAllTracks(prev => prev.map(t => t.id === track.id ? { ...t, rating: s } : t));
                                        logTerminal(`[DATABASE] Track "${track.title}" rating updated to ${s} Stars.`);
                                      }}
                                      className={`w-3 h-3 ${s <= track.rating ? 'text-amber-500 fill-amber-500' : 'text-zinc-700'}`}
                                    />
                                  ))}
                                </div>
                              </td>
                              <td className="py-2.5 px-4 text-right text-zinc-500 text-xs">
                                {Math.round(track.file_identity.file_size / (1024 * 1024) * 10) / 10} MB
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}

              {/* ARTISTS GRID */}
              {activeTab === 'artists' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-light font-mono text-white">ARTISTS INDEX</h2>
                    <p className="text-xs font-mono text-zinc-500">Normalized artists metadata matching directory names.</p>
                  </div>

                  <div className="grid grid-cols-4 gap-6">
                    {artists.map((artist) => (
                      <div
                        key={artist.id}
                        onClick={() => { setSelectedArtist(artist); setActiveTab('artist_studio'); }}
                        className="bg-[#18181b] p-5 rounded-lg border border-[#27272a] hover:border-zinc-500 cursor-pointer transition-all space-y-4 text-center"
                      >
                        <div className="w-24 h-24 rounded-full mx-auto overflow-hidden bg-zinc-800 border-2 border-zinc-700">
                          <img src={artist.avatar} alt={artist.name} className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-sm text-zinc-200 font-mono">{artist.name}</h3>
                          <p className="text-[10px] text-zinc-500 font-mono mt-1">Local Releases: 2</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ALBUMS GRID */}
              {activeTab === 'albums' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-light font-mono text-white">ALBUMS INDEX</h2>
                    <p className="text-xs font-mono text-zinc-500">Releases cached with cover artwork configurations.</p>
                  </div>

                  <div className="grid grid-cols-5 gap-6">
                    {albums.map((album) => (
                      <div
                        key={album.id}
                        onClick={() => { setSelectedAlbum(album); setActiveTab('music'); setGlobalSearch(album.title); }}
                        className="bg-[#18181b] p-4 rounded-lg border border-[#27272a] hover:border-zinc-500 cursor-pointer transition-all space-y-3"
                      >
                        <div className="aspect-square bg-zinc-800 rounded overflow-hidden relative border border-zinc-800">
                          <img src={album.cover} alt={album.title} className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-xs text-zinc-200 font-mono truncate">{album.title}</h3>
                          <p className="text-[10px] text-zinc-400 font-mono mt-0.5 truncate">{album.artist}</p>
                          <div className="flex items-center justify-between text-[9px] text-zinc-500 font-mono mt-2">
                            <span>{album.year}</span>
                            <span>{album.genre}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* GENRES STATS */}
              {activeTab === 'genres' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-light font-mono text-white">GENRES DISCOVERY</h2>
                    <p className="text-xs font-mono text-zinc-500">Audio files categorized dynamically based on ID3 Genre tags.</p>
                  </div>

                  <div className="grid grid-cols-4 gap-4">
                    {GENRES_POOL.map((genre, idx) => {
                      const count = allTracks.filter(t => t.genre === genre).length;
                      return (
                        <div
                          key={genre}
                          onClick={() => { setActiveTab('music'); setGlobalSearch(genre); }}
                          className="bg-[#18181b] p-6 rounded-lg border border-[#27272a] hover:border-zinc-500 cursor-pointer transition-all flex flex-col justify-between"
                        >
                          <span className="text-zinc-500 text-[10px] font-mono">0{idx + 1}</span>
                          <div className="mt-4">
                            <h3 className="text-sm font-semibold text-zinc-200 font-mono">{genre}</h3>
                            <p className="text-xs text-zinc-400 font-mono mt-1">{count || 12} items</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* SMART PLAYLIST RULE BUILDER */}
              {activeTab === 'smart_playlists' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-light font-mono text-white">SMART PLAYLIST RULES ENGINE</h2>
                    <p className="text-xs font-mono text-zinc-500">Dynamic playlists populated in real-time by local relational rules.</p>
                  </div>

                  <div className="grid grid-cols-3 gap-6">
                    {/* Rules panel */}
                    <div className="col-span-1 bg-[#18181b] p-6 rounded-lg border border-[#27272a] space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-mono text-zinc-400">Rules Settings</span>
                        <span className="text-[10px] font-mono bg-zinc-800 text-amber-500 px-1.5 py-0.5 rounded">Active</span>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <label className="block text-xs font-mono text-zinc-500 mb-1">Match Criteria</label>
                          <select className="w-full bg-[#121214] border border-[#2c2c30] text-sm text-zinc-200 py-1.5 px-2 rounded font-mono">
                            <option>ALL Conditions (AND)</option>
                            <option>ANY Conditions (OR)</option>
                            <option>NONE Conditions (NOT)</option>
                          </select>
                        </div>

                        <div className="space-y-2 pt-2 border-t border-zinc-800">
                          <label className="block text-xs font-mono text-zinc-400">Active Rules</label>
                          <div className="bg-[#121214] p-3 rounded border border-zinc-800/40 text-xs font-mono text-zinc-300">
                            Genre contains <span className="text-amber-500">&quot;Electronic&quot;</span>
                          </div>
                          <div className="bg-[#121214] p-3 rounded border border-zinc-800/40 text-xs font-mono text-zinc-300">
                            Rating greater than <span className="text-amber-500">3 stars</span>
                          </div>
                        </div>

                        <button className="w-full py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded text-xs font-mono flex items-center justify-center gap-1">
                          <Plus className="w-3.5 h-3.5" />
                          Add Condition Rule
                        </button>
                      </div>
                    </div>

                    {/* Results list */}
                    <div className="col-span-2 space-y-4">
                      <h3 className="text-sm font-semibold text-zinc-300 font-mono flex items-center justify-between">
                        <span>Dynamically Filtered Tracks</span>
                        <span className="text-xs text-zinc-500">{evaluatedSmartTracks.length} Matched</span>
                      </h3>

                      <div className="bg-[#18181b] rounded-lg border border-[#27272a] overflow-hidden">
                        <table className="w-full text-left text-xs text-zinc-400 font-mono">
                          <thead className="bg-[#1f1f23] text-zinc-500 border-b border-[#2c2c30]">
                            <tr>
                              <th className="py-2.5 px-4">Title</th>
                              <th className="py-2.5 px-4">Artist</th>
                              <th className="py-2.5 px-4">Genre</th>
                              <th className="py-2.5 px-4 text-center">Rating</th>
                              <th className="py-2.5 px-4 text-right">Plays</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-zinc-800/40">
                            {evaluatedSmartTracks.slice(0, 8).map((track) => (
                              <tr key={track.id} onDoubleClick={() => playTrack(track)} className="hover:bg-[#1f1f23]/40 cursor-pointer">
                                <td className="py-2 px-4 text-zinc-200 font-medium">{track.title}</td>
                                <td className="py-2 px-4 text-zinc-300">{track.artist}</td>
                                <td className="py-2 px-4 text-zinc-400">{track.genre}</td>
                                <td className="py-2 px-4 text-center text-amber-500">{'★'.repeat(track.rating)}</td>
                                <td className="py-2 px-4 text-right text-zinc-500">{track.play_count}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* ANALYTICS STATS VIEW */}
              {activeTab === 'stats' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-light font-mono text-white">MY MUSIC STATISTICS</h2>
                    <p className="text-xs font-mono text-zinc-500">Listening habits, file details, and library analysis from SQLite logs.</p>
                  </div>

                  <div className="grid grid-cols-4 gap-4">
                    <div className="bg-[#18181b] p-5 rounded-lg border border-[#27272a] space-y-1">
                      <span className="text-[10px] font-mono text-zinc-500">Total Play Time</span>
                      <p className="text-2xl font-light font-mono text-amber-500">14.8 Hours</p>
                    </div>
                    <div className="bg-[#18181b] p-5 rounded-lg border border-[#27272a] space-y-1">
                      <span className="text-[10px] font-mono text-zinc-500">Unique Tracks Played</span>
                      <p className="text-2xl font-light font-mono text-sky-500">342 Tracks</p>
                    </div>
                    <div className="bg-[#18181b] p-5 rounded-lg border border-[#27272a] space-y-1">
                      <span className="text-[10px] font-mono text-zinc-500">Lossless Ratio</span>
                      <p className="text-2xl font-light font-mono text-emerald-500">74 %</p>
                    </div>
                    <div className="bg-[#18181b] p-5 rounded-lg border border-[#27272a] space-y-1">
                      <span className="text-[10px] font-mono text-zinc-500">Average Bitrate</span>
                      <p className="text-2xl font-light font-mono text-indigo-400">1,482 kbps</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    {/* Area Chart of monthly play history */}
                    <div className="bg-[#18181b] p-6 rounded-lg border border-[#27272a] space-y-4">
                      <span className="text-xs font-mono text-zinc-400">Play Frequency Trend (9 Months)</span>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={playsHistoryOverMonths}>
                            <defs>
                              <linearGradient id="playsGrad" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#d97706" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="#d97706" stopOpacity={0}/>
                              </linearGradient>
                            </defs>
                            <XAxis dataKey="month" stroke="#52525b" fontSize={11} fontFamily="monospace" />
                            <YAxis stroke="#52525b" fontSize={11} fontFamily="monospace" />
                            <Tooltip contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a' }} />
                            <Area type="monotone" dataKey="Plays" stroke="#d97706" fillOpacity={1} fill="url(#playsGrad)" />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* Bar Chart of plays by genre */}
                    <div className="bg-[#18181b] p-6 rounded-lg border border-[#27272a] space-y-4">
                      <span className="text-xs font-mono text-zinc-400">Plays By Genre Distribution</span>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={playsByGenreData}>
                            <XAxis dataKey="name" stroke="#52525b" fontSize={11} fontFamily="monospace" />
                            <YAxis stroke="#52525b" fontSize={11} fontFamily="monospace" />
                            <Tooltip contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a' }} />
                            <Bar dataKey="value" fill="#d97706" radius={[4, 4, 0, 0]}>
                              {playsByGenreData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* DUPLICATES DETECTOR */}
              {activeTab === 'duplicates' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-light font-mono text-white">DUPLICATE CRAWLER</h2>
                    <p className="text-xs font-mono text-zinc-500">Automated directory audit indexing identical cryptographic hashes or durations.</p>
                  </div>

                  <div className="space-y-4">
                    {duplicatesGrouped.map((dup, dIdx) => (
                      <div key={dIdx} className="bg-[#18181b] p-6 rounded-lg border border-[#27272a] space-y-4">
                        <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3">
                          <div className="space-y-1">
                            <span className="text-xs font-mono bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded">
                              {dup.type}
                            </span>
                            <p className="text-[10px] text-zinc-500 font-mono mt-1">{dup.reason}</p>
                          </div>
                          <span className="text-xs font-mono text-zinc-400">{dup.tracks.length} occurrences</span>
                        </div>

                        <div className="space-y-2">
                          {dup.tracks.map((track, tIdx) => (
                            <div key={tIdx} className="bg-[#121214] p-3 rounded border border-zinc-800/50 flex items-center justify-between font-mono text-xs text-zinc-300">
                              <div className="space-y-1">
                                <span className="font-semibold text-zinc-200">{track.artist} - {track.title}</span>
                                <p className="text-[10px] text-zinc-500">{track.file_identity.absolute_path}</p>
                              </div>
                              <div className="text-right text-[10px] text-zinc-500 space-y-1">
                                <span>{track.format} | {track.sample_rate} kHz</span>
                                <p>{Math.round(track.file_identity.file_size / (1024*1024)*10)/10} MB</p>
                              </div>
                            </div>
                          ))}
                        </div>

                        <div className="flex justify-end gap-2 text-xs font-mono pt-2">
                          <button className="px-3 py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300">
                            Ignore Match
                          </button>
                          <button className="px-3 py-1.5 rounded bg-rose-600 hover:bg-rose-700 text-white">
                            Safe Delete...
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* FILESYSTEM FOLDER BROWSER */}
              {activeTab === 'filesystem' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-light font-mono text-white">LOCAL FOLDER BROWSER</h2>
                    <p className="text-xs font-mono text-zinc-500">Exposing directory maps exactly as they exist on your hard drive.</p>
                  </div>

                  <div className="bg-[#18181b] rounded-lg border border-[#27272a] p-6 space-y-4">
                    <div className="flex items-center gap-2 text-sm text-zinc-400 font-mono bg-black/40 p-2.5 rounded border border-zinc-800">
                      <Folder className="w-4 h-4 text-amber-500" />
                      <span>~/Music</span>
                      <span className="text-zinc-600">/</span>
                      <span className="text-zinc-200 font-bold">Aphex Twin</span>
                      <span className="text-zinc-600">/</span>
                      <span className="text-zinc-400">Selected Ambient Works 85-92</span>
                    </div>

                    <div className="space-y-1.5 font-mono text-xs">
                      <div className="flex items-center justify-between p-2.5 bg-zinc-900/40 rounded border border-zinc-800/30 hover:border-zinc-700 cursor-pointer text-zinc-300">
                        <span className="flex items-center gap-2">
                          <Music className="w-3.5 h-3.5 text-zinc-500" />
                          01 - Xtal.flac
                        </span>
                        <span className="text-zinc-500">32.4 MB</span>
                      </div>
                      <div className="flex items-center justify-between p-2.5 bg-zinc-900/40 rounded border border-zinc-800/30 hover:border-zinc-700 cursor-pointer text-zinc-300">
                        <span className="flex items-center gap-2">
                          <Music className="w-3.5 h-3.5 text-zinc-500" />
                          02 - Tha.flac
                        </span>
                        <span className="text-zinc-500">41.8 MB</span>
                      </div>
                      <div className="flex items-center justify-between p-2.5 bg-zinc-900/40 rounded border border-zinc-800/30 hover:border-zinc-700 cursor-pointer text-zinc-300">
                        <span className="flex items-center gap-2">
                          <Music className="w-3.5 h-3.5 text-zinc-500" />
                          03 - Pulsewidth.flac
                        </span>
                        <span className="text-zinc-500">28.9 MB</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* SOCIAL FEED TAB */}
              {activeTab === 'social_feed' && (
                <div className="max-w-xl mx-auto space-y-6">
                  <div>
                    <h2 className="text-2xl font-light font-mono text-white">LISTENING FEED</h2>
                    <p className="text-xs font-mono text-zinc-500">What friends and artists in your approved federation circles are listening to.</p>
                  </div>

                  <div className="space-y-4">
                    {socialPosts.map((post) => (
                      <div key={post.id} className="bg-[#18181b] p-6 rounded-lg border border-[#27272a] space-y-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full overflow-hidden border border-zinc-800">
                            <img src={post.actor.avatar} alt={post.actor.name} className="w-full h-full object-cover" />
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-sm font-semibold text-zinc-200 font-mono">{post.actor.name}</span>
                              {post.actor.is_artist && (
                                <span className="text-[9px] bg-amber-500 text-black px-1 py-0.5 rounded font-bold uppercase font-mono">Artist</span>
                              )}
                            </div>
                            <p className="text-[10px] text-zinc-500 font-mono">@{post.actor.handle}</p>
                          </div>
                          <span className="ml-auto text-[10px] text-zinc-600 font-mono">{post.time}</span>
                        </div>

                        <div className="text-sm font-mono text-zinc-300 pl-1">
                          {post.details}
                        </div>

                        {post.track && (
                          <div className="bg-[#121214] p-4 rounded-md border border-zinc-800/40 flex items-center gap-4">
                            <div className="w-12 h-12 bg-zinc-800 rounded overflow-hidden">
                              <img src={post.track.cover} alt={post.track.title} className="w-full h-full object-cover" />
                            </div>
                            <div className="font-mono text-xs">
                              <p className="font-semibold text-zinc-200">{post.track.title}</p>
                              <p className="text-zinc-500">{post.track.artist} - {post.track.album}</p>
                            </div>
                          </div>
                        )}

                        {/* Comments loop */}
                        {post.comments.length > 0 && (
                          <div className="space-y-2 pt-3 border-t border-zinc-800/60">
                            {post.comments.map((comment, cIdx) => (
                              <div key={cIdx} className="bg-black/30 p-2.5 rounded text-xs font-mono text-zinc-400">
                                <span className="font-semibold text-zinc-200">@{comment.author}:</span> {comment.text}
                              </div>
                            ))}
                          </div>
                        )}

                        <div className="flex items-center gap-4 pt-2 text-xs font-mono text-zinc-500">
                          <button
                            onClick={() => {
                              setSocialPosts(prev => prev.map(p => p.id === post.id ? { ...p, likes: p.likes + 1 } : p));
                              logTerminal(`Liked post by @${post.actor.handle}`);
                            }}
                            className="hover:text-zinc-300 flex items-center gap-1"
                          >
                            <Heart className="w-3.5 h-3.5 text-zinc-600" />
                            {post.likes} Likes
                          </button>
                          <div className="flex items-center gap-1">
                            <MessageSquare className="w-3.5 h-3.5 text-zinc-600" />
                            {post.comments.length} Comments
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* SOCIAL PROFILE CONTROL */}
              {activeTab === 'social_profile' && (
                <div className="max-w-xl mx-auto space-y-6">
                  <div>
                    <h2 className="text-2xl font-light font-mono text-white">MY PUBLIC PROFILE</h2>
                    <p className="text-xs font-mono text-zinc-500">Establish your social identity and sync visibility limits.</p>
                  </div>

                  <div className="bg-[#18181b] p-8 rounded-lg border border-[#27272a] space-y-6">
                    <div className="flex items-center gap-4 border-b border-zinc-800/80 pb-6">
                      <div className="w-16 h-16 rounded-full overflow-hidden bg-zinc-800 border-2 border-zinc-700 relative">
                        <img src="https://picsum.photos/seed/philology/150/150" alt="Avatar" className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-base text-zinc-200 font-mono">{myProfile.displayName}</h3>
                        <p className="text-xs text-zinc-500 font-mono">@{myProfile.username.toLowerCase()}</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-xs font-mono text-zinc-500 mb-1">Privacy Mode</label>
                        <select
                          value={socialPrivacy}
                          onChange={(e) => {
                            setSocialPrivacy(e.target.value as any);
                            logTerminal(`[SOCIAL] Privacy level set to: ${e.target.value}`);
                          }}
                          className="w-full bg-[#121214] border border-[#2c2c30] text-sm text-zinc-200 py-2 px-3 rounded font-mono"
                        >
                          <option value="PRIVATE">PRIVATE (Strict local isolation)</option>
                          <option value="FOLLOWERS">FOLLOWERS ONLY</option>
                          <option value="CLOSE_FRIENDS">CLOSE FRIENDS ONLY</option>
                          <option value="PUBLIC">PUBLIC DISPLAY</option>
                        </select>
                      </div>

                      <div className="flex items-center justify-between pt-4 border-t border-zinc-800">
                        <div className="space-y-1">
                          <span className="text-xs font-mono text-zinc-300">Listening Now Status</span>
                          <p className="text-[10px] text-zinc-500 font-mono">Allow followers to view your active playhead real-time.</p>
                        </div>
                        <button
                          onClick={() => {
                            setIsListeningNow(p => !p);
                            logTerminal(`[SOCIAL] Listening Now broadcast toggled to: ${!isListeningNow ? 'ON' : 'OFF'}`);
                          }}
                          className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 focus:outline-none ${
                            isListeningNow ? 'bg-amber-500' : 'bg-zinc-800'
                          }`}
                        >
                          <div className={`bg-black w-4 h-4 rounded-full shadow-md transform duration-200 ${
                            isListeningNow ? 'translate-x-6' : 'translate-x-0'
                          }`} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* ARTIST STUDIO */}
              {activeTab === 'artist_studio' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-light font-mono text-white">ARTIST STUDIO</h2>
                      <p className="text-xs font-mono text-zinc-500">Self-publishing console for original audio and release catalogs.</p>
                    </div>
                    <span className="text-xs font-mono bg-amber-500/10 text-amber-500 border border-amber-500/25 px-2 py-1 rounded">
                      Artist Account Active
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-6">
                    {/* Publishing tool */}
                    <div className="col-span-1 bg-[#18181b] p-6 rounded-lg border border-[#27272a] space-y-4">
                      <span className="text-xs font-mono text-zinc-400 block border-b border-zinc-800 pb-2">Publish Local Release</span>
                      
                      <div className="space-y-3 font-mono text-xs">
                        <div>
                          <label className="text-zinc-500 block mb-1">Select Local Master Track</label>
                          <div className="bg-black/30 p-2.5 rounded border border-zinc-800 flex items-center justify-between">
                            <span className="text-zinc-300">01 - Aureom Ambient Theme.flac</span>
                            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                          </div>
                        </div>

                        <div>
                          <label className="text-zinc-500 block mb-1">Visibility Policy</label>
                          <select className="w-full bg-[#121214] border border-[#2c2c30] text-zinc-300 py-1.5 px-2 rounded">
                            <option>PUBLIC_STREAM (Streaming allowed for all)</option>
                            <option>METADATA_ONLY (No audio upload)</option>
                            <option>APPROVED_ONLY (Short-lived signed tokens)</option>
                          </select>
                        </div>

                        <div className="bg-amber-950/20 p-3 rounded border border-amber-900/30 text-[10px] text-amber-400 leading-relaxed">
                          By publishing, you confirm that you own the necessary master and composition rights. No unauthorized commercial music will be uploaded.
                        </div>

                        <button
                          onClick={() => runStep(26)}
                          className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-black font-semibold rounded text-xs transition-colors"
                        >
                          Sign Rights & Publish Release
                        </button>
                      </div>
                    </div>

                    {/* Catalog grid */}
                    <div className="col-span-2 bg-[#18181b] p-6 rounded-lg border border-[#27272a] space-y-4">
                      <span className="text-xs font-mono text-zinc-400 block border-b border-zinc-800 pb-2">My Catalog</span>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-[#121214] p-4 rounded border border-zinc-800 flex items-center gap-4">
                          <div className="w-12 h-12 bg-zinc-800 rounded overflow-hidden">
                            <img src="https://picsum.photos/seed/aureom_cover/150/150" alt="Album" className="w-full h-full object-cover" />
                          </div>
                          <div className="font-mono text-xs">
                            <p className="font-semibold text-zinc-200">Aureom (LP)</p>
                            <p className="text-zinc-500">10 Tracks | Published</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

            </motion.div>
          </AnimatePresence>

          {/* PERSISTENT PLAYBAR CONTROLS */}
          <footer className="mt-8 bg-[#18181b] border border-[#27272a] rounded-lg p-4 flex items-center justify-between gap-6 relative">
            
            {/* Left track info */}
            <div className="flex items-center gap-3 w-72 shrink-0">
              <div className="w-12 h-12 bg-zinc-800 rounded overflow-hidden border border-zinc-800 shrink-0">
                {currentTrack ? (
                  <img src={`https://picsum.photos/seed/${currentTrack.release_id}/120/120`} alt="Art" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-[#121214] flex items-center justify-center font-mono text-zinc-700 text-xs">
                    Æ
                  </div>
                )}
              </div>
              <div className="font-mono overflow-hidden">
                <p className="text-xs font-semibold text-zinc-200 truncate">
                  {currentTrack ? currentTrack.title : 'No Track Loaded'}
                </p>
                <p className="text-[10px] text-zinc-500 truncate mt-0.5">
                  {currentTrack ? `${currentTrack.artist} — ${currentTrack.album}` : 'Select a track to play'}
                </p>
              </div>
            </div>

            {/* Center Timeline / Visualizer */}
            <div className="flex-1 flex flex-col items-center gap-1 max-w-xl">
              
              {/* Dynamic waveform visualizer */}
              <div className="w-full h-8 rounded relative overflow-hidden">
                <canvas ref={canvasRef} width={500} height={32} className="w-full h-full block" />
              </div>

              {/* Timeline control block */}
              <div className="w-full flex items-center justify-between text-[10px] font-mono text-zinc-500">
                <span>{Math.floor(positionMs / 60000)}:{(Math.floor((positionMs % 60000) / 1000)).toString().padStart(2, '0')}</span>
                <span>{Math.floor(durationMs / 60000)}:{(Math.floor((durationMs % 60000) / 1000)).toString().padStart(2, '0')}</span>
              </div>
            </div>

            {/* Right Buttons / Volumes */}
            <div className="flex items-center gap-4 w-80 shrink-0 justify-end">
              
              {/* Play buttons */}
              <div className="flex items-center gap-2">
                <button onClick={playPrevious} className="p-2 rounded hover:bg-[#202024] text-zinc-400 hover:text-white transition-all">
                  <SkipBack className="w-4 h-4" />
                </button>
                <button
                  onClick={togglePlayPause}
                  className="p-2.5 rounded bg-white hover:bg-zinc-200 text-black transition-all"
                >
                  {playbackState === 'PLAYING' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </button>
                <button onClick={playNext} className="p-2 rounded hover:bg-[#202024] text-zinc-400 hover:text-white transition-all">
                  <SkipForward className="w-4 h-4" />
                </button>
              </div>

              {/* Tech details of audio */}
              {currentTrack && (
                <div className="text-[9px] font-mono bg-zinc-900 border border-zinc-800 px-2 py-1 rounded text-zinc-500 shrink-0">
                  <span className="text-zinc-400 font-bold">{currentTrack.format}</span> | {currentTrack.bit_depth ? `${currentTrack.bit_depth}-bit/` : ''}{currentTrack.sample_rate} kHz
                </div>
              )}

              {/* Volume slider */}
              <div className="flex items-center gap-2">
                <button onClick={() => setIsMuted(!isMuted)} className="p-1.5 rounded hover:bg-[#202024] text-zinc-400 hover:text-white">
                  {isMuted ? <VolumeX className="w-4 h-4 text-rose-500" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={volume}
                  onChange={(e) => setVolume(parseFloat(e.target.value))}
                  className="w-16 accent-amber-500"
                />
              </div>

            </div>
          </footer>
        </main>

        {/* RIGHT DRAWER - MASTER DEMO SCENARIO LOGGER */}
        <aside className="w-96 bg-[#0c0c0e] border-l border-[#19191b] flex flex-col justify-between overflow-hidden shrink-0">
          
          {/* Header */}
          <div className="p-4 border-b border-[#1f1f23] space-y-2 bg-[#121214]/60">
            <span className="text-[10px] font-mono tracking-widest text-zinc-400 uppercase">Verification Engine</span>
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-zinc-200 font-mono flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-amber-500" />
                MASTER SCENARIO RUNNER
              </h3>
              <div className="flex items-center gap-1">
                <div className="h-2 w-2 rounded-full bg-emerald-500 animate-ping" />
                <span className="text-[9px] font-mono text-zinc-400 bg-zinc-900 px-1.5 py-0.5 rounded border border-zinc-800">
                  {demoStep + 1}/40
                </span>
              </div>
            </div>
            
            {/* Action buttons */}
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => setDemoAutoRunning(!demoAutoRunning)}
                className={`py-1.5 rounded font-mono text-xs font-semibold tracking-wider flex items-center justify-center gap-1.5 transition-colors ${
                  demoAutoRunning 
                    ? 'bg-rose-950/40 border border-rose-900 text-rose-400' 
                    : 'bg-amber-500 hover:bg-amber-600 text-black'
                }`}
              >
                <Radio className="w-3.5 h-3.5" />
                {demoAutoRunning ? 'STOP DEMO' : 'AUTO RUN'}
              </button>
              <button
                onClick={() => {
                  const next = (demoStep + 1) % masterStepsList.length;
                  runStep(next);
                }}
                className="py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-mono text-xs border border-zinc-700/60 flex items-center justify-center gap-1"
              >
                NEXT STEP
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Current Step Description Card */}
          <div className="p-4 bg-zinc-950/40 border-b border-[#1f1f23] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-amber-500 uppercase tracking-wide font-bold">Active Criteria</span>
              <span className="text-[9px] font-mono text-zinc-500">Verified</span>
            </div>
            <div className="space-y-1.5 bg-[#121214] p-3 rounded border border-zinc-800/40 font-mono">
              <p className="text-xs font-bold text-zinc-200">
                {demoStep + 1}. {masterStepsList[demoStep]?.title}
              </p>
              <p className="text-[10px] text-zinc-400 leading-relaxed">
                {masterStepsList[demoStep]?.desc}
              </p>
            </div>
          </div>

          {/* Terminal Console Logger Output */}
          <div className="flex-1 p-4 overflow-y-auto font-mono text-[10px] bg-black/50 text-[#a3a3a3] space-y-1.5 border-b border-[#1f1f23]">
            {terminalLogs.map((log, idx) => (
              <div key={idx} className={`leading-relaxed border-l-2 pl-2 ${
                log.includes('CRITICAL') ? 'text-rose-400 border-rose-500 bg-rose-950/10' :
                log.includes('PLAYBACK') ? 'text-amber-300 border-amber-500 bg-amber-950/5' :
                log.includes('VERIFIED') ? 'text-emerald-400 border-emerald-500 bg-emerald-950/5' :
                'text-zinc-400 border-zinc-800'
              }`}>
                {log}
              </div>
            ))}
          </div>

          {/* Structural representation of Rust Crate Workspace */}
          <div className="p-4 space-y-2 bg-[#0c0c0e]">
            <span className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase">Rust Workspace layout</span>
            <div className="font-mono text-[9px] text-zinc-400 bg-black/40 p-2.5 rounded border border-zinc-900 overflow-x-auto space-y-0.5">
              <p className="text-zinc-300">aureom-music/ (Cargo Workspace)</p>
              <p className="text-zinc-500">├── apps/desktop/ (Tauri Shell)</p>
              <p className="text-zinc-500">├── crates/</p>
              <p className="text-zinc-600">│   ├── aureom-core/ (Domain models)</p>
              <p className="text-zinc-600">│   ├── aureom-audio/ (GStreamer engine)</p>
              <p className="text-zinc-600">│   └── aureom-library/ (SQLite indices)</p>
              <p className="text-zinc-500">└── database/migrations/ (001_init.sql)</p>
            </div>
          </div>

        </aside>

      </div>

      {/* MODAL: FULL GLOBAL COMMAND PALETTE */}
      {isCommandPaletteOpen && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-lg bg-[#18181b] rounded-lg border border-[#27272a] shadow-2xl overflow-hidden font-mono text-sm text-zinc-300">
            <div className="p-4 border-b border-[#2c2c30] flex items-center justify-between">
              <span className="text-xs font-semibold text-zinc-500">GLOBAL COMMAND PALETTE</span>
              <button onClick={() => setIsCommandPaletteOpen(false)} className="text-xs hover:text-white">Esc</button>
            </div>
            
            <div className="p-2 space-y-1">
              <button
                onClick={() => { runStep(2); setIsCommandPaletteOpen(false); }}
                className="w-full text-left p-3 rounded hover:bg-[#202024] flex items-center justify-between"
              >
                <span>/scan_library</span>
                <span className="text-xs text-zinc-500">Trigger recursive filesystem scan</span>
              </button>
              <button
                onClick={() => { setActiveTab('stats'); setIsCommandPaletteOpen(false); }}
                className="w-full text-left p-3 rounded hover:bg-[#202024] flex items-center justify-between"
              >
                <span>/show_statistics</span>
                <span className="text-xs text-zinc-500">Open database metrics summary</span>
              </button>
              <button
                onClick={() => { setActiveTab('smart_playlists'); setIsCommandPaletteOpen(false); }}
                className="w-full text-left p-3 rounded hover:bg-[#202024] flex items-center justify-between"
              >
                <span>/smart_playlists</span>
                <span className="text-xs text-zinc-500">Inspect relational smart lists</span>
              </button>
              <button
                onClick={() => { runStep(19); setIsCommandPaletteOpen(false); }}
                className="w-full text-left p-3 rounded hover:bg-[#202024] flex items-center justify-between"
              >
                <span>/disconnect_drive</span>
                <span className="text-xs text-zinc-500">Simulate offline-first caching metadata</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
