import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Aureom Music Library',
  description: 'The ultimate Linux personal music library and social listening platform.',
  openGraph: {
    title: 'Aureom Music Library',
    description: 'The ultimate Linux personal music library and social listening platform.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aureom Music Library',
    description: 'The ultimate Linux personal music library and social listening platform.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
