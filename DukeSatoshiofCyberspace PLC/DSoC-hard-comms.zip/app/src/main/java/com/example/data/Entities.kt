package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "organisations")
data class Organisation(
    @PrimaryKey val organisationId: String,
    val legalName: String,
    val displayName: String,
    val status: String,
    val createdAt: Long
)

@Entity(tableName = "people")
data class Person(
    @PrimaryKey val personId: String,
    val organisationId: String,
    val displayName: String,
    val role: String,
    val status: String
)

@Entity(tableName = "identities")
data class Identity(
    @PrimaryKey val identityId: String,
    val personId: String,
    val publicIdentityKey: String,
    val identityFingerprint: String,
    val verificationState: String, // UNVERIFIED, PENDING, VERIFIED, KEY_CHANGED, REVOKED, COMPROMISED, UNKNOWN
    val createdAt: Long,
    val revokedAt: Long? = null
)

@Entity(tableName = "devices")
data class Device(
    @PrimaryKey val deviceId: String,
    val identityId: String,
    val deviceName: String,
    val platform: String,
    val devicePublicKey: String,
    val registrationState: String,
    val lastSeen: Long,
    val revokedAt: Long? = null
)

@Entity(tableName = "links")
data class Link(
    @PrimaryKey val linkId: String,
    val localIdentityId: String,
    val remoteIdentityId: String,
    val localDeviceId: String,
    val remoteDeviceId: String,
    val verificationState: String, // UNVERIFIED, PENDING, VERIFIED, KEY_CHANGED, REVOKED
    val protocolVersion: String,
    val sessionState: String, // DISCOVERY, IDENTITY_FETCH, PREKEY_FETCH, AUTHENTICATION, KEY_AGREEMENT, SESSION_INITIALISATION, VERIFICATION, LINK_ESTABLISHED
    val establishedAt: Long,
    val lastKeyRotation: Long,
    val lastMessage: String
)

@Entity(tableName = "channels")
data class Channel(
    @PrimaryKey val channelId: String,
    val linkId: String,
    val channelType: String, // DIRECT, GROUP, PROJECT, INCIDENT, OPERATIONS, BOARD, TECHNICAL, SECURITY
    val state: String, // NORMAL, CONFIDENTIAL, RESTRICTED, HARD
    val createdAt: Long
)

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey val messageId: String,
    val channelId: String,
    val senderDeviceId: String,
    val ciphertext: String,
    val encryptedMetadata: String,
    val createdAt: Long,
    val deliveryState: String // CREATED, ENCRYPTING, QUEUED, SENT, SERVER_ACCEPTED, DELIVERED, READ, FAILED, EXPIRED, REVOKED
)

@Entity(tableName = "calls")
data class Call(
    @PrimaryKey val callId: String,
    val channelId: String,
    val callType: String, // VOICE, VIDEO, SCREEN_SHARE, etc.
    val state: String, // ACTIVE, ENDED
    val startedAt: Long,
    val endedAt: Long? = null,
    val activeParticipantsCount: Int = 1,
    val mediaKeyEpoch: Int = 0,
    val latencyMs: Int = 31,
    val packetLossPct: Double = 0.2
)

@Entity(tableName = "attachments")
data class Attachment(
    @PrimaryKey val attachmentId: String,
    val messageId: String,
    val encryptedBlobReference: String,
    val contentType: String,
    val size: Long,
    val digest: String
)

@Entity(tableName = "security_events")
data class SecurityEvent(
    @PrimaryKey val eventId: String,
    val severity: String, // INFO, NOTICE, WARNING, HIGH, CRITICAL
    val category: String, // device_registered, device_revoked, identity_verified, identity_changed, etc.
    val deviceId: String,
    val identityId: String,
    val timestamp: Long,
    val eventHash: String,
    val details: String
)

@Entity(tableName = "incidents")
data class Incident(
    @PrimaryKey val incidentId: String,
    val title: String,
    val status: String, // ACTIVE, RESOLVED, INVESTIGATING
    val severity: String, // LOW, MEDIUM, HIGH, CRITICAL
    val createdAt: Long,
    val activeDevicesCount: Int = 1
)

@Entity(tableName = "vault_notes")
data class VaultNote(
    @PrimaryKey val noteId: String,
    val title: String,
    val content: String, // Simulated encrypted content
    val category: String, // Note, Document, Bookmark, Contact Note, Call Note, Research Note, Incident Note
    val createdAt: Long
)
