package com.example.core.crypto

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

enum class CryptoSuite {
    CLASSICAL,
    HYBRID,
    POST_QUANTUM
}

object CryptoEngine {
    private const val ALGORITHM = "AES"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val TAG_LENGTH_BIT = 128
    private const val IV_LENGTH_BYTE = 12

    /**
     * Generates a random cryptographic key of specified length in bits (default 256).
     */
    fun generateRandomKey(bits: Int = 256): String {
        val random = SecureRandom()
        val keyBytes = ByteArray(bits / 8)
        random.nextBytes(keyBytes)
        return Base64.encodeToString(keyBytes, Base64.NO_WRAP)
    }

    /**
     * Derives a SHA-256 fingerprint formatted in space-separated hex blocks.
     * e.g., "7C42 8A1D 91B3 ..."
     */
    fun computeFingerprint(input: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(input.toByteArray(Charsets.UTF_8))
            hash.joinToString("") { String.format("%02X", it) }
                .chunked(4)
                .take(8) // Limit to a reasonable length of 8 blocks for readable UI instrument display
                .joinToString(" ")
        } catch (e: Exception) {
            "ERROR-HASH-FAILED"
        }
    }

    /**
     * Encrypts plaintext using AES-GCM 256 with a unique random IV.
     * Returns a Base64-encoded envelope: IV_BASE64:CIPHERTEXT_BASE64
     */
    fun encryptAesGcm(plaintext: String, keyBase64: String): String {
        return try {
            val keyBytes = Base64.decode(keyBase64, Base64.DEFAULT)
            val secretKey = SecretKeySpec(keyBytes, ALGORITHM)

            val iv = ByteArray(IV_LENGTH_BYTE)
            SecureRandom().nextBytes(iv)

            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(TAG_LENGTH_BIT, iv)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, spec)

            val ciphertextBytes = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))

            val ivBase64 = Base64.encodeToString(iv, Base64.NO_WRAP)
            val ciphertextBase64 = Base64.encodeToString(ciphertextBytes, Base64.NO_WRAP)

            "$ivBase64:$ciphertextBase64"
        } catch (e: Exception) {
            "ENCRYPTION_ERROR:${e.localizedMessage}"
        }
    }

    /**
     * Decrypts an envelope formatted as IV_BASE64:CIPHERTEXT_BASE64 using AES-GCM.
     */
    fun decryptAesGcm(envelope: String, keyBase64: String): String {
        if (!envelope.contains(":")) return "DECRYPTION_ERROR_MALFORMED_ENVELOPE"
        return try {
            val parts = envelope.split(":")
            val iv = Base64.decode(parts[0], Base64.DEFAULT)
            val ciphertext = Base64.decode(parts[1], Base64.DEFAULT)

            val keyBytes = Base64.decode(keyBase64, Base64.DEFAULT)
            val secretKey = SecretKeySpec(keyBytes, ALGORITHM)

            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(TAG_LENGTH_BIT, iv)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)

            val decryptedBytes = cipher.doFinal(ciphertext)
            String(decryptedBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            "DECRYPTION_ERROR:${e.localizedMessage}"
        }
    }

    /**
     * Simulates a Signal Double Ratchet KDF key step.
     * Derives a new root key and chain key, and output message key.
     */
    fun advanceRatchet(chainKeyBase64: String): Pair<String, String> {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val chainKeyBytes = Base64.decode(chainKeyBase64, Base64.DEFAULT)
            // Derivation: ChainKeyStep(key) = Hash(key + "RATCHET_STEP")
            val newChainKeyBytes = digest.digest(chainKeyBytes + "RATCHET_STEP".toByteArray(Charsets.UTF_8))
            val messageKeyBytes = digest.digest(chainKeyBytes + "MESSAGE_KEY_STEP".toByteArray(Charsets.UTF_8))

            Pair(
                Base64.encodeToString(newChainKeyBytes, Base64.NO_WRAP),
                Base64.encodeToString(messageKeyBytes, Base64.NO_WRAP)
            )
        } catch (e: Exception) {
            Pair(chainKeyBase64, generateRandomKey())
        }
    }
}
