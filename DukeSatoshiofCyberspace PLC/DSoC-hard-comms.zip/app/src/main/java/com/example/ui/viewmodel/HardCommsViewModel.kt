package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.core.crypto.CryptoEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class HardCommsViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    val repository = HardCommsRepository(database.dao())

    // UI state flows
    val organisations: StateFlow<List<Organisation>> = repository.organisations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val people: StateFlow<List<Person>> = repository.people
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val identities: StateFlow<List<Identity>> = repository.identities
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val devices: StateFlow<List<Device>> = repository.devices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val links: StateFlow<List<Link>> = repository.links
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val channels: StateFlow<List<Channel>> = repository.channels
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val messages: StateFlow<List<Message>> = repository.messages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val calls: StateFlow<List<Call>> = repository.calls
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val attachments: StateFlow<List<Attachment>> = repository.attachments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val securityEvents: StateFlow<List<SecurityEvent>> = repository.securityEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val incidents: StateFlow<List<Incident>> = repository.incidents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vaultNotes: StateFlow<List<VaultNote>> = repository.vaultNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Application Control State
    val isLocked = MutableStateFlow(true)
    val currentMenuTab = MutableStateFlow("LINKS") // LINKS, SECURITY, NODE, GRAPH, VAULT, DEMO
    val selectedChannelId = MutableStateFlow<String?>(null)
    val selectedNodeId = MutableStateFlow("DSC-LON-001")

    // Node & Security flags from Repository
    val nodeState = MutableStateFlow("ACTIVE") // ACTIVE, DEGRADED, ISOLATED, OFFLINE
    val onlineState = MutableStateFlow("ONLINE") // ONLINE, DEGRADED, OFFLINE, RECONNECTING
    val isHardModeActive = MutableStateFlow(false)

    // Active Call State (Real-time instrumentation simulation)
    val activeCall = MutableStateFlow<Call?>(null)

    // Demo status logs
    val demoLog = MutableStateFlow("Select a demonstration step to execute.")
    val selectedDemoStep = MutableStateFlow(1)
    val selectedFailureStep = MutableStateFlow(1)

    init {
        viewModelScope.launch {
            repository.seedDatabase()
            // Pull initial configurations
            nodeState.value = repository.currentNodeState
            onlineState.value = repository.isOnlineState
            isHardModeActive.value = repository.isHardModeActive
        }
    }

    fun unlockApp() {
        isLocked.value = false
    }

    fun lockApp() {
        isLocked.value = true
    }

    fun selectMenuTab(tab: String) {
        currentMenuTab.value = tab
    }

    fun selectChannel(channelId: String?) {
        selectedChannelId.value = channelId
    }

    fun selectNode(nodeId: String) {
        selectedNodeId.value = nodeId
    }

    // Isolate Node command
    fun toggleIsolateNode() {
        viewModelScope.launch {
            if (nodeState.value == "ISOLATED") {
                nodeState.value = "ACTIVE"
                repository.currentNodeState = "ACTIVE"
                repository.logEvent("NOTICE", "node_restored", "DSC-LON-001", "SYSTEM", "Node isolation cancelled. Node online.")
            } else {
                nodeState.value = "ISOLATED"
                repository.currentNodeState = "ISOLATED"
                // Terminate active call and restrict links
                activeCall.value = null
                repository.logEvent("CRITICAL", "node_isolated", "DSC-LON-001", "SYSTEM", "OPERATOR WARNING: Node isolator engaged. Outbound traffic blocked.")
            }
        }
    }

    // Toggle Hard Mode
    fun toggleHardMode() {
        viewModelScope.launch {
            isHardModeActive.value = !isHardModeActive.value
            repository.isHardModeActive = isHardModeActive.value
            val status = if (isHardModeActive.value) "ENABLED" else "DISABLED"
            repository.logEvent("NOTICE", "hard_mode_changed", "DSC-LON-001", "SYSTEM", "Hard mode has been $status by local operator.")
        }
    }

    // Toggle Online state
    fun setOnlineState(state: String) {
        viewModelScope.launch {
            onlineState.value = state
            repository.isOnlineState = state
            repository.logEvent("NOTICE", "network_state_changed", "DSC-LON-001", "SYSTEM", "Operator changed network state to: $state")
        }
    }

    // Add Secure Note
    fun addVaultNote(title: String, content: String, category: String) {
        viewModelScope.launch {
            val note = VaultNote(
                noteId = "NOTE-${UUID.randomUUID()}",
                title = title,
                content = content,
                category = category,
                createdAt = System.currentTimeMillis()
            )
            repository.insertVaultNote(note)
            repository.logEvent("INFO", "vault_note_added", "DSC-LON-001", "SYSTEM", "New encrypted note added to Vault: $title")
        }
    }

    // Delete Note
    fun deleteVaultNote(id: String) {
        viewModelScope.launch {
            repository.deleteVaultNote(id)
            repository.logEvent("NOTICE", "vault_note_deleted", "DSC-LON-001", "SYSTEM", "An encrypted note was securely shredded.")
        }
    }

    // Execute Master Demonstration Steps (1 to 25)
    fun executeDemoStep(step: Int) {
        viewModelScope.launch {
            selectedDemoStep.value = step
            val result = repository.executeDemoStep(step)
            demoLog.value = result

            // Special UI reactions for specific steps
            when (step) {
                6 -> {
                    // Set Maya-Alex as default channel
                    selectedChannelId.value = "CH-MAYA-ALEX-DIRECT"
                }
                12 -> {
                    // Launch Call simulation in UI
                    activeCall.value = Call(
                        callId = "CALL-001",
                        channelId = "CH-MAYA-ALEX-DIRECT",
                        callType = "VOICE",
                        state = "ACTIVE",
                        startedAt = System.currentTimeMillis(),
                        activeParticipantsCount = 2,
                        mediaKeyEpoch = 42
                    )
                }
                13 -> {
                    activeCall.value = activeCall.value?.copy(activeParticipantsCount = 3)
                }
                14 -> {
                    activeCall.value = activeCall.value?.copy(mediaKeyEpoch = 43)
                }
                15 -> {
                    activeCall.value = activeCall.value?.copy(activeParticipantsCount = 2)
                }
                16 -> {
                    activeCall.value = activeCall.value?.copy(mediaKeyEpoch = 44)
                }
                17 -> {
                    // Simulated device key change is triggered. This locks down channel MSG-002
                }
                22 -> {
                    // Restored link
                }
            }
        }
    }

    // Execute Failure Demonstration (1 to 12)
    fun executeFailureStep(step: Int) {
        viewModelScope.launch {
            selectedFailureStep.value = step
            val result = repository.executeFailureDemo(step)
            demoLog.value = result
        }
    }

    // Send local direct message manually
    fun sendDirectMessage(plaintext: String) {
        viewModelScope.launch {
            val channelId = selectedChannelId.value ?: "CH-MAYA-ALEX-DIRECT"
            val key = "e9g8X5r4t3y2u1i0o9p8a7s6d5f4g3h2"
            val ciphertext = CryptoEngine.encryptAesGcm(plaintext, key)
            val msgId = "MSG-${UUID.randomUUID()}"
            val msg = Message(
                messageId = msgId,
                channelId = channelId,
                senderDeviceId = "DEV-LOCAL-NODE",
                ciphertext = ciphertext,
                encryptedMetadata = "SUITE=CLASSICAL:ALGO=AES-GCM",
                createdAt = System.currentTimeMillis(),
                deliveryState = "DELIVERED"
            )
            repository.insertMessage(msg)
            repository.logEvent("INFO", "message_sent", "DSC-LON-001", "LOCAL_IDENTITY", "Outbound encrypted message sent. ID: $msgId")
        }
    }

    // Trigger instant reseed
    fun reseedDatabase() {
        viewModelScope.launch {
            repository.seedDatabase()
            demoLog.value = "Database seeded successfully. All synthetic parameters initialized."
        }
    }

    fun endCall() {
        activeCall.value = null
        viewModelScope.launch {
            repository.logEvent("NOTICE", "call_ended", "DSC-LON-001", "SYSTEM", "Call session CALL-001 terminated by local operator.")
        }
    }
}
