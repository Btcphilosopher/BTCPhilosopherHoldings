package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface HardCommsDao {

    // Organisations
    @Query("SELECT * FROM organisations ORDER BY createdAt DESC")
    fun getAllOrganisations(): Flow<List<Organisation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrganisation(org: Organisation)

    // People
    @Query("SELECT * FROM people")
    fun getAllPeople(): Flow<List<Person>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPerson(person: Person)

    // Identities
    @Query("SELECT * FROM identities")
    fun getAllIdentities(): Flow<List<Identity>>

    @Query("SELECT * FROM identities WHERE identityId = :id")
    suspend fun getIdentityById(id: String): Identity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIdentity(identity: Identity)

    // Devices
    @Query("SELECT * FROM devices")
    fun getAllDevices(): Flow<List<Device>>

    @Query("SELECT * FROM devices WHERE deviceId = :id")
    suspend fun getDeviceById(id: String): Device?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDevice(device: Device)

    // Links
    @Query("SELECT * FROM links")
    fun getAllLinks(): Flow<List<Link>>

    @Query("SELECT * FROM links WHERE linkId = :id")
    suspend fun getLinkById(id: String): Link?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLink(link: Link)

    // Channels
    @Query("SELECT * FROM channels")
    fun getAllChannels(): Flow<List<Channel>>

    @Query("SELECT * FROM channels WHERE channelId = :id")
    suspend fun getChannelById(id: String): Channel?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChannel(channel: Channel)

    // Messages
    @Query("SELECT * FROM messages ORDER BY createdAt ASC")
    fun getAllMessages(): Flow<List<Message>>

    @Query("SELECT * FROM messages WHERE channelId = :channelId ORDER BY createdAt ASC")
    fun getMessagesForChannel(channelId: String): Flow<List<Message>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: Message)

    // Calls
    @Query("SELECT * FROM calls")
    fun getAllCalls(): Flow<List<Call>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCall(call: Call)

    // Attachments
    @Query("SELECT * FROM attachments")
    fun getAllAttachments(): Flow<List<Attachment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttachment(attachment: Attachment)

    // Security Events
    @Query("SELECT * FROM security_events ORDER BY timestamp DESC")
    fun getAllSecurityEvents(): Flow<List<SecurityEvent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSecurityEvent(event: SecurityEvent)

    // Incidents
    @Query("SELECT * FROM incidents ORDER BY createdAt DESC")
    fun getAllIncidents(): Flow<List<Incident>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncident(incident: Incident)

    // Vault Notes
    @Query("SELECT * FROM vault_notes ORDER BY createdAt DESC")
    fun getAllVaultNotes(): Flow<List<VaultNote>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaultNote(note: VaultNote)

    @Query("DELETE FROM vault_notes WHERE noteId = :noteId")
    suspend fun deleteVaultNote(noteId: String)
}
