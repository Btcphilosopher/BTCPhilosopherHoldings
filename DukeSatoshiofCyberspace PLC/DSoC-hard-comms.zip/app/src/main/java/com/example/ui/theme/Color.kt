package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Hard Comms Anodized & Steel Palettes
val HardAnodizedBlack = Color(0xFF111215)
val HardGraphiteDark = Color(0xFF1D1F24)
val HardGraphiteMedium = Color(0xFF2C2E35)
val HardSteelLight = Color(0xFFD6DBE1)
val HardSteelMuted = Color(0xFF8E95A0)

// British Institutional Typography & Accents
val HardDeepBlue = Color(0xFF0F2537)
val HardDeepBlueLight = Color(0xFF1C3A54)
val HardOffWhite = Color(0xFFF3F5F7)

// Restrained Warning Indicators
val HardRestrainedAmber = Color(0xFFE5A93C)
val HardWarningRed = Color(0xFFC0392B)
val HardMutedGreen = Color(0xFF27AE60)
val HardPureWhite = Color(0xFFFFFFFF)
