package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.crypto.CryptoEngine
import com.example.data.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.HardCommsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainConsoleScreen(viewModel: HardCommsViewModel) {
    val context = LocalContext.current
    val isLocked by viewModel.isLocked.collectAsStateWithLifecycle()

    if (isLocked) {
        HardLockScreen(
            onUnlock = { pwd ->
                if (pwd == "001") {
                    viewModel.unlockApp()
                } else {
                    Toast.makeText(context, "OPERATOR KEY ACCESS REJECTED", Toast.LENGTH_SHORT).show()
                }
            }
        )
    } else {
        OperatorDashboard(viewModel)
    }
}

/**
 * Tactical hardware lock screen.
 */
@Composable
fun HardLockScreen(onUnlock: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HardAnodizedBlack)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 400.dp)
                .background(HardGraphiteDark)
                .border(1.dp, HardSteelMuted.copy(alpha = 0.5f))
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // British Crest / Core emblem Simulation
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .background(HardDeepBlue)
                    .border(1.dp, HardRestrainedAmber)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Crest Logo",
                    tint = HardRestrainedAmber,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "DUKE SATOSHI OF CYBERSPACE",
                style = MaterialTheme.typography.labelLarge.copy(
                    letterSpacing = 2.sp,
                    color = HardSteelLight,
                    fontWeight = FontWeight.Bold
                ),
                textAlign = TextAlign.Center
            )
            Text(
                text = "HARD COMMS LINK",
                style = MaterialTheme.typography.titleLarge.copy(
                    color = HardRestrainedAmber,
                    letterSpacing = 1.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(HardAnodizedBlack)
                    .border(1.dp, HardSteelMuted.copy(alpha = 0.2f))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "NODE:",
                        style = MaterialTheme.typography.labelMedium.copy(color = HardSteelMuted)
                    )
                    Text(
                        text = "DSC-LON-001",
                        style = MaterialTheme.typography.labelMedium.copy(color = HardSteelLight, fontWeight = FontWeight.Bold)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "IDENTITY:",
                        style = MaterialTheme.typography.labelMedium.copy(color = HardSteelMuted)
                    )
                    Text(
                        text = "VERIFIED",
                        style = MaterialTheme.typography.labelMedium.copy(color = HardMutedGreen, fontWeight = FontWeight.Bold)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "SYSTEM:",
                        style = MaterialTheme.typography.labelMedium.copy(color = HardSteelMuted)
                    )
                    Text(
                        text = "NOMINAL",
                        style = MaterialTheme.typography.labelMedium.copy(color = HardMutedGreen, fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = pin,
                onValueChange = { pin = it },
                label = { Text("OPERATOR KEY PASS", color = HardSteelMuted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = HardRestrainedAmber,
                    unfocusedBorderColor = HardSteelMuted,
                    focusedTextColor = HardPureWhite,
                    unfocusedTextColor = HardSteelLight,
                    focusedContainerColor = HardAnodizedBlack,
                    unfocusedContainerColor = HardAnodizedBlack
                ),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onUnlock(pin) }),
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            HardButton(
                text = "UNLOCK TERMINAL",
                onClick = { onUnlock(pin) },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Default key passcode is: 001",
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardSteelMuted)
            )
        }
    }
}

/**
 * Primary Core Dashboard
 */
@Composable
fun OperatorDashboard(viewModel: HardCommsViewModel) {
    val currentTab by viewModel.currentMenuTab.collectAsStateWithLifecycle()
    val configuration = LocalConfiguration.current
    val isWideScreen = configuration.screenWidthDp >= 800

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = HardAnodizedBlack,
        topBar = { TopLevelStatusBar(viewModel) }
    ) { innerPadding ->
        if (isWideScreen) {
            // Three-Column Layout for Desktop Operators / Wide Screens
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(8.dp)
            ) {
                // Column 1: Left Menu Sidebar
                LeftMenuSidebar(
                    activeTab = currentTab,
                    onTabSelected = { viewModel.selectMenuTab(it) },
                    onLock = { viewModel.lockApp() },
                    modifier = Modifier
                        .width(200.dp)
                        .fillMaxHeight()
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Column 2: Center Viewport
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    CenterViewport(viewModel = viewModel, activeTab = currentTab)
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Column 3: Right Status Telemetry Instrument
                RightTelemetryInstrument(
                    viewModel = viewModel,
                    modifier = Modifier
                        .width(280.dp)
                        .fillMaxHeight()
                )
            }
        } else {
            // Responsive layout for standard portrait/mobile devices
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(6.dp)
            ) {
                // Quick toggles to switch columns
                var mobileSubView by remember { mutableStateOf("CENTER") } // MENU, CENTER, INSTRUMENT

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                        .background(HardGraphiteDark)
                        .border(1.dp, HardSteelMuted.copy(alpha = 0.3f)),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { mobileSubView = "MENU" }
                            .background(if (mobileSubView == "MENU") HardDeepBlueLight else Color.Transparent)
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "MENU",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (mobileSubView == "MENU") HardRestrainedAmber else HardSteelMuted
                            )
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { mobileSubView = "CENTER" }
                            .background(if (mobileSubView == "CENTER") HardDeepBlueLight else Color.Transparent)
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "OPERATOR WORK",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (mobileSubView == "CENTER") HardRestrainedAmber else HardSteelMuted
                            )
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { mobileSubView = "INSTRUMENT" }
                            .background(if (mobileSubView == "INSTRUMENT") HardDeepBlueLight else Color.Transparent)
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "TELEMETRY",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (mobileSubView == "INSTRUMENT") HardRestrainedAmber else HardSteelMuted
                            )
                        )
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    when (mobileSubView) {
                        "MENU" -> LeftMenuSidebar(
                            activeTab = currentTab,
                            onTabSelected = {
                                viewModel.selectMenuTab(it)
                                mobileSubView = "CENTER" // swap back after selecting
                            },
                            onLock = { viewModel.lockApp() },
                            modifier = Modifier.fillMaxSize()
                        )
                        "CENTER" -> CenterViewport(viewModel = viewModel, activeTab = currentTab)
                        "INSTRUMENT" -> RightTelemetryInstrument(viewModel = viewModel, modifier = Modifier.fillMaxSize())
                    }
                }
            }
        }
    }
}

/**
 * Top Global Status bar matching section 5
 */
@Composable
fun TopLevelStatusBar(viewModel: HardCommsViewModel) {
    val nodeState by viewModel.nodeState.collectAsStateWithLifecycle()
    val isHardMode by viewModel.isHardModeActive.collectAsStateWithLifecycle()
    val onlineState by viewModel.onlineState.collectAsStateWithLifecycle()
    val links by viewModel.links.collectAsStateWithLifecycle()

    var showQuickInfo by remember { mutableStateOf<String?>(null) }

    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(HardAnodizedBlack)
                .border(1.dp, HardSteelMuted.copy(alpha = 0.2f))
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = "Console",
                    tint = HardRestrainedAmber,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "HARD COMMS LINK",
                    style = MaterialTheme.typography.labelLarge.copy(color = HardSteelLight, fontWeight = FontWeight.Bold)
                )
            }

            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Clicking each item displays a technical information snippet
                Box(modifier = Modifier.clickable { showQuickInfo = "SYSTEM" }) {
                    HardStatus("SYSTEM", nodeState)
                }
                Box(modifier = Modifier.clickable { showQuickInfo = "IDENTITY" }) {
                    HardStatus("IDENTITY", "VERIFIED")
                }
                Box(modifier = Modifier.clickable { showQuickInfo = "NETWORK" }) {
                    HardStatus("NETWORK", onlineState)
                }
                Box(modifier = Modifier.clickable { showQuickInfo = "LINKS" }) {
                    HardStatus("LINKS", "${links.size} ACTIVE")
                }
                Box(modifier = Modifier.clickable { showQuickInfo = "SECURITY" }) {
                    HardStatus("SECURITY", if (isHardMode) "HARD ACTIVE" else "NOMINAL")
                }
            }
        }

        // Quick info description block
        AnimatedVisibility(
            visible = showQuickInfo != null,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            if (showQuickInfo != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(HardDeepBlue)
                        .border(1.dp, HardSteelMuted.copy(alpha = 0.3f))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "METRIC DETAIL: ${showQuickInfo?.uppercase()}",
                            style = MaterialTheme.typography.labelMedium.copy(color = HardRestrainedAmber, fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        val desc = when (showQuickInfo) {
                            "SYSTEM" -> "Current operating system state is '$nodeState'. If ISOLATED, physical/logical node loopback is active and outbound transmissions are severed."
                            "IDENTITY" -> "All local identity files are validated with standard Android Keystore RSA/ECDSA hardware elements. Backdoor vector 0.00%."
                            "NETWORK" -> "Network communications state: $onlineState. Local queued messages are transmitted when state returns to ONLINE."
                            "LINKS" -> "Total established E2EE handshakes. Each link operates an independent Hybrid Double Ratchet protocol."
                            "SECURITY" -> if (isHardMode) "HARD MODE ACTIVE: strict device checks, disappearing files, and zero unverified traffic rules enforced." else "Standard policy evaluation is NOMINAL. All endpoints are verified."
                            else -> ""
                        }
                        Text(
                            text = desc,
                            style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelLight)
                        )
                    }
                    IconButton(onClick = { showQuickInfo = null }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = HardSteelMuted)
                    }
                }
            }
        }
    }
}

/**
 * Column 1: Left Menu Sidebar
 */
@Composable
fun LeftMenuSidebar(
    activeTab: String,
    onTabSelected: (String) -> Unit,
    onLock: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(HardGraphiteDark)
            .border(1.dp, HardSteelMuted.copy(alpha = 0.3f))
            .padding(8.dp)
    ) {
        Text(
            text = "DUKE SATOSHI\nHARD COMMS",
            style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.Bold,
                color = HardSteelLight,
                lineHeight = 16.sp,
                letterSpacing = 1.sp
            ),
            modifier = Modifier.padding(8.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        val menuItems = listOf(
            Triple("LINKS", "LINK CONTROL", Icons.Default.Link),
            Triple("SECURITY", "SECURITY CTR", Icons.Default.Lock),
            Triple("NODE", "NODE CONSOLE", Icons.Default.DeveloperBoard),
            Triple("GRAPH", "TRUST GRAPH", Icons.Default.Hub),
            Triple("VAULT", "SECURE VAULT", Icons.Default.FolderSpecial),
            Triple("DEMO", "SYSTEM RUNS", Icons.Default.BugReport)
        )

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            menuItems.forEach { (tabId, label, icon) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onTabSelected(tabId) }
                        .background(if (activeTab == tabId) HardDeepBlue else Color.Transparent)
                        .border(
                            1.dp,
                            if (activeTab == tabId) HardRestrainedAmber.copy(alpha = 0.4f) else Color.Transparent
                        )
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (activeTab == tabId) HardRestrainedAmber else HardSteelMuted,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (activeTab == tabId) HardRestrainedAmber else HardSteelLight
                        )
                    )
                }
            }
        }

        // Lock button
        HardButton(
            text = "LOCK CONSOLE",
            onClick = onLock,
            modifier = Modifier.fillMaxWidth(),
            color = HardWarningRed,
            textColor = HardPureWhite
        )
    }
}

/**
 * Column 2: Center Viewport
 */
@Composable
fun CenterViewport(viewModel: HardCommsViewModel, activeTab: String) {
    when (activeTab) {
        "LINKS" -> ChannelMessagesScreen(viewModel)
        "SECURITY" -> SecurityCentreScreen(viewModel)
        "NODE" -> NodeConsoleScreen(viewModel)
        "GRAPH" -> TrustGraphScreen(viewModel)
        "VAULT" -> PrivateVaultScreen(viewModel)
        "DEMO" -> DemonstrationPanel(viewModel)
        else -> Box(modifier = Modifier.fillMaxSize())
    }
}

/**
 * Channel & Messages center Viewport
 */
@Composable
fun ChannelMessagesScreen(viewModel: HardCommsViewModel) {
    val links by viewModel.links.collectAsStateWithLifecycle()
    val channels by viewModel.channels.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val selectedChannelId by viewModel.selectedChannelId.collectAsStateWithLifecycle()
    val isHardMode by viewModel.isHardModeActive.collectAsStateWithLifecycle()

    var messageInput by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        if (links.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(HardGraphiteDark)
                    .border(1.dp, HardSteelMuted.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.LinkOff,
                        contentDescription = "No Links",
                        tint = HardSteelMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "NO ACTIVE LINKS FOUND",
                        style = MaterialTheme.typography.labelLarge.copy(color = HardSteelMuted)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Run Step 6 in SYSTEM RUNS to establish crypted link.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            // Header showing selected peer info
            val activeLink = links.firstOrNull() // Simplify mapping to default Maya-Alex E2EE link
            val activeChannel = channels.firstOrNull()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(HardGraphiteDark)
                    .border(1.dp, HardSteelMuted.copy(alpha = 0.3f))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ALEXANDER REED",
                        style = MaterialTheme.typography.titleLarge.copy(color = HardSteelLight, fontSize = 16.sp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(6.dp).background(if (activeLink?.sessionState == "SUSPENDED") HardWarningRed else HardMutedGreen))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (activeLink?.sessionState == "SUSPENDED") "LINK SUSPENDED" else "VERIFIED LINK - SECURE",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontSize = 10.sp,
                                color = if (activeLink?.sessionState == "SUSPENDED") HardWarningRed else HardMutedGreen
                            )
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HardBadge(if (isHardMode) "HARD MODE" else "PQXDH ACTIVE", color = HardDeepBlue)
                    HardBadge("ROTATING EPOCH", color = HardRestrainedAmber, textColor = HardAnodizedBlack)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Message scrolling area
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(HardAnodizedBlack)
                    .border(1.dp, HardSteelMuted.copy(alpha = 0.2f))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // If link is suspended, show prominent "HARD STOP" alert
                if (activeLink?.sessionState == "SUSPENDED") {
                    item {
                        HardAlert(
                            title = "IDENTITY KEY CHANGED",
                            description = "WARNING: Remote peer identity key signature altered. All communications suspended.\nDO NOT ASSUME THIS IS NORMAL.",
                            severity = "CRITICAL"
                        )
                    }
                }

                items(messages) { msg ->
                    val isLocal = msg.senderDeviceId == "DEV-LOCAL-NODE" || msg.senderDeviceId == "DEV-MAYA-MAC"
                    // Decode if not failed
                    val displayContent = if (msg.ciphertext.startsWith("ENCRYPT_FAILED")) {
                        "[TRANSMISSION BLOCKED: SAFE FAILURE-CLOSED]"
                    } else {
                        // Decrypted payload visualization
                        CryptoEngine.decryptAesGcm(msg.ciphertext, "e9g8X5r4t3y2u1i0o9p8a7s6d5f4g3h2")
                    }

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = if (isLocal) Alignment.End else Alignment.Start
                    ) {
                        Text(
                            text = if (isLocal) "LOCAL OPERATOR (MAYA)" else "REMOTE PEER (ALEX)",
                            style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardSteelMuted)
                        )
                        Box(
                            modifier = Modifier
                                .background(if (isLocal) HardDeepBlueLight else HardGraphiteMedium)
                                .border(1.dp, if (isLocal) HardRestrainedAmber.copy(alpha = 0.3f) else HardSteelMuted.copy(alpha = 0.2f))
                                .padding(10.dp)
                                .widthIn(max = 280.dp)
                        ) {
                            Column {
                                Text(
                                    text = displayContent,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = if (msg.ciphertext.startsWith("ENCRYPT_FAILED")) HardWarningRed else HardSteelLight
                                    )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = msg.encryptedMetadata,
                                        style = MaterialTheme.typography.labelMedium.copy(fontSize = 8.sp, color = HardSteelMuted)
                                    )
                                    Text(
                                        text = msg.deliveryState,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (msg.deliveryState == "FAILED") HardWarningRed else HardMutedGreen
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Composer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(HardGraphiteDark)
                    .border(1.dp, HardSteelMuted.copy(alpha = 0.3f))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = messageInput,
                    onValueChange = { messageInput = it },
                    placeholder = { Text("Enter E2EE packet command...", color = HardSteelMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = HardRestrainedAmber,
                        unfocusedBorderColor = HardSteelMuted,
                        focusedTextColor = HardPureWhite,
                        unfocusedTextColor = HardSteelLight,
                        focusedContainerColor = HardAnodizedBlack,
                        unfocusedContainerColor = HardAnodizedBlack
                    ),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                HardButton(
                    text = "SEND",
                    onClick = {
                        if (messageInput.isNotBlank()) {
                            viewModel.sendDirectMessage(messageInput)
                            messageInput = ""
                        }
                    },
                    enabled = activeLink?.sessionState != "SUSPENDED"
                )
            }
        }
    }
}

/**
 * Security Centre screen
 */
@Composable
fun SecurityCentreScreen(viewModel: HardCommsViewModel) {
    val identities by viewModel.identities.collectAsStateWithLifecycle()
    val devices by viewModel.devices.collectAsStateWithLifecycle()
    val logs by viewModel.securityEvents.collectAsStateWithLifecycle()
    val isHardMode by viewModel.isHardModeActive.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "SECURITY AUDIT OPERATIONS",
                style = MaterialTheme.typography.titleLarge.copy(color = HardRestrainedAmber)
            )
            Text(
                text = "Cryptographic identities, validation records, and raw threat audit feeds.",
                style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted)
            )
        }

        item {
            HardPanel(headerText = "ACTIVE SECURE RETENTION POLICIES") {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Device Limits:", style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted))
                    Text("Strict (Max 2 devices)", style = MaterialTheme.typography.labelLarge.copy(color = HardSteelLight))
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Unverified Communications:", style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted))
                    Text(if (isHardMode) "BLOCK" else "WARN", style = MaterialTheme.typography.labelLarge.copy(color = if (isHardMode) HardWarningRed else HardRestrainedAmber))
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Minimum Crypto Suite:", style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted))
                    Text("HYBRID (PQXDH + KYBER-768)", style = MaterialTheme.typography.labelLarge.copy(color = HardMutedGreen))
                }
            }
        }

        item {
            Text(
                text = "REGISTERED CRYPTO ENDPOINTS",
                style = MaterialTheme.typography.labelLarge.copy(color = HardSteelLight, fontWeight = FontWeight.Bold)
            )
        }

        if (identities.isEmpty()) {
            item {
                Text(
                    text = "No identities registered. Run Demonstration Step 1 & 3.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted)
                )
            }
        } else {
            items(identities) { ident ->
                val associatedDevices = devices.filter { it.identityId == ident.identityId }
                HardPanel(headerText = "IDENTITY: ${ident.identityId}") {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Fingerprint:", style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted))
                        Text(ident.identityFingerprint, style = MaterialTheme.typography.labelLarge.copy(color = HardRestrainedAmber))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Verification State:", style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted))
                        Text(
                            text = ident.verificationState,
                            style = MaterialTheme.typography.labelLarge.copy(
                                color = when (ident.verificationState) {
                                    "VERIFIED" -> HardMutedGreen
                                    "KEY_CHANGED" -> HardWarningRed
                                    else -> HardRestrainedAmber
                                }
                            )
                        )
                    }

                    if (associatedDevices.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("ASSOCIATED DEVICES:", style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardSteelMuted))
                        associatedDevices.forEach { dev ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp)
                                    .background(HardAnodizedBlack)
                                    .padding(4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(dev.deviceName, style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelLight))
                                Text(dev.platform.uppercase(), style = MaterialTheme.typography.labelMedium.copy(color = HardSteelMuted))
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "REAL-TIME SECURITY LOG",
                style = MaterialTheme.typography.labelLarge.copy(color = HardSteelLight, fontWeight = FontWeight.Bold)
            )
        }

        if (logs.isEmpty()) {
            item {
                Text("No security events logged.", style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted))
            }
        } else {
            items(logs) { ev ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(HardGraphiteDark)
                        .border(1.dp, HardSteelMuted.copy(alpha = 0.2f))
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(
                                        when (ev.severity) {
                                            "CRITICAL" -> HardWarningRed
                                            "WARNING", "HIGH" -> HardRestrainedAmber
                                            else -> HardSteelMuted
                                        }
                                    )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = ev.category.uppercase(),
                                style = MaterialTheme.typography.labelLarge.copy(
                                    color = if (ev.severity == "CRITICAL") HardWarningRed else HardSteelLight
                                )
                            )
                        }
                        Text(
                            text = ev.severity,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontSize = 9.sp,
                                color = if (ev.severity == "CRITICAL") HardWarningRed else HardSteelMuted
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(ev.details, style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelLight))
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "HASH: ${ev.eventHash}",
                            style = MaterialTheme.typography.labelMedium.copy(fontSize = 8.sp, color = HardSteelMuted)
                        )
                        Text(
                            text = "TS: ${ev.timestamp}",
                            style = MaterialTheme.typography.labelMedium.copy(fontSize = 8.sp, color = HardSteelMuted)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Node Console
 */
@Composable
fun NodeConsoleScreen(viewModel: HardCommsViewModel) {
    val nodeState by viewModel.nodeState.collectAsStateWithLifecycle()
    val isHardMode by viewModel.isHardModeActive.collectAsStateWithLifecycle()
    val onlineState by viewModel.onlineState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "HARD NODE OPERATIONS CONSOLE",
            style = MaterialTheme.typography.titleLarge.copy(color = HardRestrainedAmber)
        )
        Text(
            text = "Isolate physical nodes, modify loopback variables, and configure hardware interfaces.",
            style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HardMetric("NODE ID", "DSC-LON-001", modifier = Modifier.weight(1f))
            HardMetric("PEER LINKS", "17", unit = "links", modifier = Modifier.weight(1f))
        }

        HardPanel(headerText = "NODE SECURITY ISOLATION CONTROL") {
            Text(
                text = "Engagement of Node Isolation immediately severs all external handshakes, deletes active ephemeral session keys, and forces local sandbox loops. Use only in event of physical security breach.",
                style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelLight)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ISOLATION STATE:",
                    style = MaterialTheme.typography.labelMedium.copy(color = HardSteelMuted)
                )
                Text(
                    text = if (nodeState == "ISOLATED") "ISOLATED" else "OPERATIONAL",
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = if (nodeState == "ISOLATED") HardWarningRed else HardMutedGreen,
                        fontSize = 18.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            HardButton(
                text = if (nodeState == "ISOLATED") "DISENGAGE ISOLATION" else "ENGAGE NODE ISOLATION",
                onClick = { viewModel.toggleIsolateNode() },
                color = if (nodeState == "ISOLATED") HardMutedGreen else HardWarningRed,
                textColor = HardPureWhite,
                modifier = Modifier.fillMaxWidth()
            )
        }

        HardPanel(headerText = "TACTICAL INTERFACE CONFIGURATIONS") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("HIGH SECURITY 'HARD MODE':", style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelLight))
                Switch(
                    checked = isHardMode,
                    onCheckedChange = { viewModel.toggleHardMode() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = HardRestrainedAmber,
                        checkedTrackColor = HardDeepBlueLight,
                        uncheckedThumbColor = HardSteelMuted,
                        uncheckedTrackColor = HardGraphiteMedium
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("NETWORK TRANSCEIVER:", style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelLight))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    HardButton(
                        text = "ONLINE",
                        onClick = { viewModel.setOnlineState("ONLINE") },
                        isBorderOnly = onlineState != "ONLINE",
                        color = HardMutedGreen,
                        textColor = HardPureWhite,
                        modifier = Modifier.height(30.dp)
                    )
                    HardButton(
                        text = "OFFLINE",
                        onClick = { viewModel.setOnlineState("OFFLINE") },
                        isBorderOnly = onlineState != "OFFLINE",
                        color = HardWarningRed,
                        textColor = HardPureWhite,
                        modifier = Modifier.height(30.dp)
                    )
                }
            }
        }
    }
}

/**
 * Custom Visual Trust Graph / Link Map
 */
@Composable
fun TrustGraphScreen(viewModel: HardCommsViewModel) {
    val nodeState by viewModel.nodeState.collectAsStateWithLifecycle()
    var selectedGraphNode by remember { mutableStateOf("DSC-LON-001") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp)
    ) {
        Text(
            text = "HARD COMMS TRUST GRAPH & LINK MAP",
            style = MaterialTheme.typography.titleLarge.copy(color = HardRestrainedAmber)
        )
        Text(
            text = "Visualizing authenticated, cryptographically bound peer-to-peer relationships.",
            style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Interative canvas drawing nodes & lines
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .background(HardAnodizedBlack)
                .border(1.dp, HardSteelMuted.copy(alpha = 0.3f))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height

                // Center node: London
                val lonOffset = Offset(width / 2, height / 2)
                // Peripheral nodes
                val nycOffset = Offset(width * 0.15f, height * 0.3f)
                val zrhOffset = Offset(width * 0.85f, height * 0.3f)
                val ediOffset = Offset(width * 0.3f, height * 0.8f)
                val manOffset = Offset(width * 0.7f, height * 0.8f)

                // Draw Link path lines (all verified except Switzerland which is suspended in simulator)
                drawLine(
                    color = if (nodeState == "ISOLATED") HardWarningRed else HardMutedGreen,
                    start = lonOffset,
                    end = nycOffset,
                    strokeWidth = 2f
                )
                drawLine(
                    color = HardRestrainedAmber,
                    start = lonOffset,
                    end = zrhOffset,
                    strokeWidth = 1.5f
                )
                drawLine(
                    color = if (nodeState == "ISOLATED") HardWarningRed else HardMutedGreen,
                    start = lonOffset,
                    end = ediOffset,
                    strokeWidth = 2f
                )
                drawLine(
                    color = if (nodeState == "ISOLATED") HardWarningRed else HardMutedGreen,
                    start = lonOffset,
                    end = manOffset,
                    strokeWidth = 2f
                )

                // Draw Node circles
                drawCircle(color = if (nodeState == "ISOLATED") HardWarningRed else HardRestrainedAmber, radius = 12f, center = lonOffset)
                drawCircle(color = HardSteelMuted, radius = 9f, center = nycOffset)
                drawCircle(color = HardWarningRed, radius = 9f, center = zrhOffset)
                drawCircle(color = HardSteelMuted, radius = 9f, center = ediOffset)
                drawCircle(color = HardSteelMuted, radius = 9f, center = manOffset)
            }

            // Clickable overlays mapped to node positions
            Text(
                "LONDON NODE (LON-001)",
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardRestrainedAmber),
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = 20.dp)
                    .clickable { selectedGraphNode = "DSC-LON-001" }
            )
            Text(
                "NEW YORK (NYC-001)",
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardSteelLight),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = 10.dp, y = 80.dp)
                    .clickable { selectedGraphNode = "DSC-NYC-001" }
            )
            Text(
                "ZURICH (ZRH-001)",
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardWarningRed),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = (-10).dp, y = 80.dp)
                    .clickable { selectedGraphNode = "DSC-ZRH-001" }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        HardPanel(headerText = "NODE DETAIL: $selectedGraphNode") {
            val statusStr = when (selectedGraphNode) {
                "DSC-LON-001" -> if (nodeState == "ISOLATED") "ISOLATED" else "ACTIVE / INSTALLED"
                "DSC-ZRH-001" -> "SUSPENDED (KEY MISMATCH)"
                else -> "ACTIVE"
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Operational Status:", style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted))
                Text(statusStr, style = MaterialTheme.typography.labelLarge.copy(color = if (statusStr.contains("ACTIVE")) HardMutedGreen else HardWarningRed))
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Verification state:", style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted))
                Text(if (selectedGraphNode == "DSC-ZRH-001") "COMPROMISED" else "VERIFIED", style = MaterialTheme.typography.labelLarge.copy(color = if (selectedGraphNode == "DSC-ZRH-001") HardWarningRed else HardMutedGreen))
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("E2EE Channels Bound:", style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted))
                Text("3 DIRECT, 1 FILES, 1 SECURE AUDIO", style = MaterialTheme.typography.labelLarge.copy(color = HardSteelLight))
            }
        }
    }
}

/**
 * Secure Vault for Notes
 */
@Composable
fun PrivateVaultScreen(viewModel: HardCommsViewModel) {
    val notes by viewModel.vaultNotes.collectAsStateWithLifecycle()
    var titleInput by remember { mutableStateOf("") }
    var contentInput by remember { mutableStateOf("") }
    var noteCategory by remember { mutableStateOf("Research Note") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "PRIVATE ENCRYPTED VAULT",
                style = MaterialTheme.typography.titleLarge.copy(color = HardRestrainedAmber)
            )
            Text(
                text = "Local secure memos stored using AES-256 with Android Keystore. Content never transmits.",
                style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted)
            )
        }

        item {
            HardPanel(headerText = "CREATE SECURE MEMO RECORD") {
                OutlinedTextField(
                    value = titleInput,
                    onValueChange = { titleInput = it },
                    label = { Text("MEMBER TITLE", color = HardSteelMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = HardRestrainedAmber,
                        unfocusedBorderColor = HardSteelMuted,
                        focusedTextColor = HardPureWhite,
                        unfocusedTextColor = HardSteelLight,
                        focusedContainerColor = HardAnodizedBlack,
                        unfocusedContainerColor = HardAnodizedBlack
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = contentInput,
                    onValueChange = { contentInput = it },
                    label = { Text("MEMO DATA (PLAINTEXT)", color = HardSteelMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = HardRestrainedAmber,
                        unfocusedBorderColor = HardSteelMuted,
                        focusedTextColor = HardPureWhite,
                        unfocusedTextColor = HardSteelLight,
                        focusedContainerColor = HardAnodizedBlack,
                        unfocusedContainerColor = HardAnodizedBlack
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                HardButton(
                    text = "COMMITTED TO SECURE VAULT",
                    onClick = {
                        if (titleInput.isNotBlank() && contentInput.isNotBlank()) {
                            // Encrypt on insertion representation
                            val encrypted = CryptoEngine.encryptAesGcm(contentInput, "e9g8X5r4t3y2u1i0o9p8a7s6d5f4g3h2")
                            viewModel.addVaultNote(titleInput, encrypted, noteCategory)
                            titleInput = ""
                            contentInput = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        item {
            Text(
                "SHREDDABLE MEMO TIMELINE",
                style = MaterialTheme.typography.labelLarge.copy(color = HardSteelLight, fontWeight = FontWeight.Bold)
            )
        }

        if (notes.isEmpty()) {
            item {
                Text("Vault index empty.", style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted))
            }
        } else {
            items(notes) { note ->
                val decodedContent = if (note.content.contains(":")) {
                    CryptoEngine.decryptAesGcm(note.content, "e9g8X5r4t3y2u1i0o9p8a7s6d5f4g3h2")
                } else {
                    note.content
                }

                HardPanel(
                    headerText = "MEMO: ${note.title.uppercase()}",
                    headerAction = {
                        IconButton(onClick = { viewModel.deleteVaultNote(note.noteId) }) {
                            Icon(
                                imageVector = Icons.Default.DeleteForever,
                                contentDescription = "Shred",
                                tint = HardWarningRed,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                ) {
                    Text(
                        text = "ENCRYPTION SUITE: AES-256-GCM / INTEGRAL STORAGE",
                        style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardRestrainedAmber)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = decodedContent,
                        style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelLight)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "RAW CIPHERTEXT RECORD: ${note.content.take(24)}...",
                        style = MaterialTheme.typography.labelMedium.copy(fontSize = 8.sp, color = HardSteelMuted)
                    )
                }
            }
        }
    }
}

/**
 * Demonstration Controller matching Section 60 & 61
 */
@Composable
fun DemonstrationPanel(viewModel: HardCommsViewModel) {
    val currentDemoStep by viewModel.selectedDemoStep.collectAsStateWithLifecycle()
    val currentFailureStep by viewModel.selectedFailureStep.collectAsStateWithLifecycle()
    val terminalLog by viewModel.demoLog.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "MASTER DEMONSTRATION RUNS",
                style = MaterialTheme.typography.titleLarge.copy(color = HardRestrainedAmber)
            )
            Text(
                text = "Execute explicit sequential security runs to verify state machine protocols under normal and adversarial loads.",
                style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelMuted)
            )
        }

        item {
            HardPanel(headerText = "RAW CRYPTOGRAPHIC INSTRUMENT LOG") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .background(HardAnodizedBlack)
                        .padding(8.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = terminalLog,
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = if (terminalLog.contains("CRITICAL") || terminalLog.contains("WARNING") || terminalLog.contains("FAILED") || terminalLog.contains("REJECT")) HardWarningRed else HardRestrainedAmber,
                            fontSize = 11.sp
                        )
                    )
                }
            }
        }

        item {
            Text(
                text = "25-STEP MASTER DEMONSTRATION SEQUENCE",
                style = MaterialTheme.typography.labelLarge.copy(color = HardSteelLight, fontWeight = FontWeight.Bold)
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(HardGraphiteDark)
                    .border(1.dp, HardSteelMuted.copy(alpha = 0.2f))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RUN STEP: $currentDemoStep / 25",
                    style = MaterialTheme.typography.labelLarge.copy(color = HardSteelLight)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    HardButton(
                        text = "PREV",
                        onClick = { if (currentDemoStep > 1) viewModel.executeDemoStep(currentDemoStep - 1) },
                        enabled = currentDemoStep > 1,
                        isBorderOnly = true,
                        modifier = Modifier.height(36.dp)
                    )
                    HardButton(
                        text = "TRIGGER",
                        onClick = { viewModel.executeDemoStep(currentDemoStep) },
                        color = HardRestrainedAmber,
                        textColor = HardAnodizedBlack,
                        modifier = Modifier.height(36.dp)
                    )
                    HardButton(
                        text = "NEXT",
                        onClick = { if (currentDemoStep < 25) viewModel.executeDemoStep(currentDemoStep + 1) },
                        enabled = currentDemoStep < 25,
                        isBorderOnly = true,
                        modifier = Modifier.height(36.dp)
                    )
                }
            }
        }

        item {
            Text(
                text = "12 FAILURE & ADVERSARIAL DEMOS",
                style = MaterialTheme.typography.labelLarge.copy(color = HardWarningRed, fontWeight = FontWeight.Bold)
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(HardGraphiteDark)
                    .border(1.dp, HardWarningRed.copy(alpha = 0.2f))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FAILURE RUN: $currentFailureStep / 12",
                    style = MaterialTheme.typography.labelLarge.copy(color = HardSteelLight)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    HardButton(
                        text = "PREV",
                        onClick = { if (currentFailureStep > 1) viewModel.executeFailureStep(currentFailureStep - 1) },
                        enabled = currentFailureStep > 1,
                        isBorderOnly = true,
                        modifier = Modifier.height(36.dp),
                        color = HardWarningRed
                    )
                    HardButton(
                        text = "FAIL CLOSED",
                        onClick = { viewModel.executeFailureStep(currentFailureStep) },
                        color = HardWarningRed,
                        textColor = HardPureWhite,
                        modifier = Modifier.height(36.dp)
                    )
                    HardButton(
                        text = "NEXT",
                        onClick = { if (currentFailureStep < 12) viewModel.executeFailureStep(currentFailureStep + 1) },
                        enabled = currentFailureStep < 12,
                        isBorderOnly = true,
                        modifier = Modifier.height(36.dp),
                        color = HardWarningRed
                    )
                }
            }
        }

        item {
            HardButton(
                text = "RESET & RE-SEED DATABASE",
                onClick = { viewModel.reseedDatabase() },
                modifier = Modifier.fillMaxWidth(),
                isBorderOnly = true
            )
        }
    }
}

/**
 * Column 3: Right Status Telemetry Instrument (Engineering Instrument)
 */
@Composable
fun RightTelemetryInstrument(viewModel: HardCommsViewModel, modifier: Modifier = Modifier) {
    val links by viewModel.links.collectAsStateWithLifecycle()
    val activeCall by viewModel.activeCall.collectAsStateWithLifecycle()
    val nodeState by viewModel.nodeState.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .background(HardGraphiteDark)
            .border(1.dp, HardSteelMuted.copy(alpha = 0.3f))
            .padding(10.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "LINK STATUS INSTRUMENT",
            style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.Bold,
                color = HardRestrainedAmber,
                letterSpacing = 1.sp
            )
        )
        HorizontalDivider(color = HardSteelMuted.copy(alpha = 0.3f))

        // Peer context
        Text(
            text = "CURRENT PEER DETAIL",
            style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardSteelMuted)
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(HardAnodizedBlack)
                .padding(8.dp)
        ) {
            Text("PEER: Alexander Reed", style = MaterialTheme.typography.bodyMedium.copy(color = HardPureWhite, fontWeight = FontWeight.Bold))
            Text("DEVICE: ALEX-SECURE-PHONE", style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardSteelMuted))
            Text("IDENTITY: ID-ALEX", style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardSteelMuted))
            Spacer(modifier = Modifier.height(6.dp))
            Text("FINGERPRINT:", style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardSteelMuted))
            val linkState = links.firstOrNull()?.verificationState ?: "UNVERIFIED"
            Text(
                text = "91B3 8F4C A092 DC1F",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontSize = 12.sp,
                    color = when (linkState) {
                        "VERIFIED" -> HardMutedGreen
                        "KEY_CHANGED" -> HardWarningRed
                        else -> HardRestrainedAmber
                    }
                )
            )
            Text(
                text = "VERIFICATION: $linkState",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontSize = 10.sp,
                    color = when (linkState) {
                        "VERIFIED" -> HardMutedGreen
                        "KEY_CHANGED" -> HardWarningRed
                        else -> HardRestrainedAmber
                    }
                )
            )
        }

        // Crypto State
        Text(
            text = "CRYPTOGRAPHIC STATE",
            style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardSteelMuted)
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(HardAnodizedBlack)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("PROTOCOL:", style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardSteelMuted))
                Text("PQXDH-V1-SPQR", style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardSteelLight))
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("SUITE:", style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardSteelMuted))
                Text("HYBRID (EC+KYBER)", style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardMutedGreen, fontWeight = FontWeight.Bold))
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("RATCHET:", style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardSteelMuted))
                Text("ACTIVE", style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardMutedGreen))
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("LAST ROTATION:", style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardSteelMuted))
                Text("2m 41s ago", style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardRestrainedAmber))
            }
        }

        // Active call instrument panel (Section 52)
        if (activeCall != null && nodeState != "ISOLATED") {
            val call = activeCall!!
            Text(
                text = "ACTIVE E2EE CALL TELEMETRY",
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardWarningRed, fontWeight = FontWeight.Bold)
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(HardWarningRed.copy(alpha = 0.08f))
                    .border(1.dp, HardWarningRed.copy(alpha = 0.3f))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text("HARD CALL: VOICE", style = MaterialTheme.typography.labelLarge.copy(color = HardWarningRed))
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("MEDIA:", style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardSteelMuted))
                    Text("E2EE SECURE", style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardMutedGreen))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("KEY EPOCH:", style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardSteelMuted))
                    Text("00${call.mediaKeyEpoch}", style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardRestrainedAmber, fontWeight = FontWeight.Bold))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("LATENCY:", style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardSteelMuted))
                    Text("${call.latencyMs} ms", style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardPureWhite))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("PACKET LOSS:", style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardSteelMuted))
                    Text("${call.packetLossPct}%", style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardPureWhite))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("PARTICIPANTS:", style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardSteelMuted))
                    Text("${call.activeParticipantsCount} DEVICES", style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardPureWhite))
                }

                Spacer(modifier = Modifier.height(8.dp))

                HardButton(
                    text = "DISCONNECT CALL",
                    onClick = { viewModel.endCall() },
                    color = HardWarningRed,
                    textColor = HardPureWhite,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
