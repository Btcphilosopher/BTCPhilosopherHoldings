package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun HardPanel(
    modifier: Modifier = Modifier,
    headerText: String? = null,
    borderStroke: BorderStroke = BorderStroke(1.dp, HardSteelMuted.copy(alpha = 0.4f)),
    headerAction: @Composable (RowScope.() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .background(HardGraphiteDark)
            .border(borderStroke)
            .padding(12.dp)
    ) {
        if (headerText != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = headerText.uppercase(),
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = HardSteelLight
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (headerAction != null) {
                    Row { headerAction() }
                }
            }
            HorizontalDivider(
                modifier = Modifier.padding(bottom = 10.dp),
                color = HardSteelMuted.copy(alpha = 0.2f)
            )
        }
        content()
    }
}

@Composable
fun HardButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = HardRestrainedAmber,
    textColor: Color = HardAnodizedBlack,
    enabled: Boolean = true,
    isBorderOnly: Boolean = false
) {
    val containerColor = if (isBorderOnly) Color.Transparent else color
    val contentColor = if (isBorderOnly) color else textColor
    val border = if (isBorderOnly) BorderStroke(1.dp, color) else null

    Button(
        onClick = onClick,
        modifier = modifier.height(44.dp),
        enabled = enabled,
        shape = RoundedCornerShape(0.dp), // Severe sharp corners
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor,
            disabledContainerColor = HardGraphiteMedium,
            disabledContentColor = HardSteelMuted
        ),
        border = border,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = text.uppercase(),
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun HardStatus(
    label: String,
    state: String,
    modifier: Modifier = Modifier
) {
    val indicatorColor = when (state.uppercase()) {
        "NOMINAL", "OPERATIONAL", "VERIFIED", "SECURE", "ONLINE", "ACTIVE" -> HardMutedGreen
        "PENDING", "DEGRADED", "RECONNECTING" -> HardRestrainedAmber
        "CRITICAL", "ISOLATED", "SUSPENDED", "REVOKED", "COMPROMISED", "KEY_CHANGED" -> HardWarningRed
        else -> HardSteelMuted
    }

    Row(
        modifier = modifier
            .background(HardGraphiteMedium)
            .border(1.dp, HardSteelMuted.copy(alpha = 0.2f))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(indicatorColor)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label.uppercase() + ":",
            style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardSteelMuted)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = state.uppercase(),
            style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardPureWhite, fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
fun HardBadge(
    text: String,
    color: Color = HardDeepBlueLight,
    textColor: Color = HardSteelLight,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(color)
            .border(1.dp, textColor.copy(alpha = 0.3f))
            .padding(horizontal = 6.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text.uppercase(),
            style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = textColor, fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
fun HardMetric(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    unit: String? = null
) {
    Column(
        modifier = modifier
            .background(HardGraphiteMedium)
            .border(1.dp, HardSteelMuted.copy(alpha = 0.2f))
            .padding(8.dp)
    ) {
        Text(
            text = label.uppercase(),
            style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, color = HardSteelMuted)
        )
        Row(
            verticalAlignment = Alignment.Bottom,
            modifier = Modifier.padding(top = 2.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.labelLarge.copy(fontSize = 16.sp, color = HardPureWhite, fontWeight = FontWeight.Bold)
            )
            if (unit != null) {
                Spacer(modifier = Modifier.width(2.dp))
                Text(
                    text = unit,
                    style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, color = HardSteelMuted)
                )
            }
        }
    }
}

@Composable
fun HardAlert(
    title: String,
    description: String,
    modifier: Modifier = Modifier,
    severity: String = "HIGH"
) {
    val borderColor = if (severity == "CRITICAL" || severity == "HIGH") HardWarningRed else HardRestrainedAmber
    val bgColors = if (severity == "CRITICAL" || severity == "HIGH") HardWarningRed.copy(alpha = 0.08f) else HardRestrainedAmber.copy(alpha = 0.08f)

    Column(
        modifier = modifier
            .background(bgColors)
            .border(BorderStroke(1.dp, borderColor))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).background(borderColor))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = borderColor)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = description,
            style = MaterialTheme.typography.bodyMedium.copy(color = HardSteelLight)
        )
    }
}
