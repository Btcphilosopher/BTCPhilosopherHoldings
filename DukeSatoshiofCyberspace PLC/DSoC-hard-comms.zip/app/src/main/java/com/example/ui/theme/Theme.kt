package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val HardColorScheme = darkColorScheme(
    primary = HardRestrainedAmber,
    onPrimary = HardAnodizedBlack,
    primaryContainer = HardDeepBlueLight,
    onPrimaryContainer = HardSteelLight,
    secondary = HardDeepBlueLight,
    onSecondary = HardSteelLight,
    background = HardAnodizedBlack,
    onBackground = HardSteelLight,
    surface = HardGraphiteDark,
    onSurface = HardSteelLight,
    surfaceVariant = HardGraphiteMedium,
    onSurfaceVariant = HardSteelLight,
    error = HardWarningRed,
    onError = HardPureWhite,
    outline = HardSteelMuted
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = HardColorScheme,
        typography = Typography,
        content = content
    )
}
