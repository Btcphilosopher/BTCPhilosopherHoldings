package com.example.data

import android.content.Context
import androidx.room.Room
import com.example.core.crypto.CryptoEngine
import com.example.core.crypto.CryptoSuite
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class HardCommsRepository(private val dao: HardCommsDao) {

    val organisations: Flow<List<Organisation>> = dao.getAllOrganisations()
    val people: Flow<List<Person>> = dao.getAllPeople()
    val identities: Flow<List<Identity>> = dao.getAllIdentities()
    val devices: Flow<List<Device>> = dao.getAllDevices()
    val links: Flow<List<Link>> = dao.getAllLinks()
    val channels: Flow<List<Channel>> = dao.getAllChannels()
    val messages: Flow<List<Message>> = dao.getAllMessages()
    val calls: Flow<List<Call>> = dao.getAllCalls()
    val attachments: Flow<List<Attachment>> = dao.getAllAttachments()
    val securityEvents: Flow<List<SecurityEvent>> = dao.getAllSecurityEvents()
    val incidents: Flow<List<Incident>> = dao.getAllIncidents()
    val vaultNotes: Flow<List<VaultNote>> = dao.getAllVaultNotes()

    // Key local node status
    var currentNodeId: String = "DSC-LON-001"
    var currentNodeState: String = "ACTIVE" // PROVISIONING, ACTIVE, DEGRADED, ISOLATED, SUSPENDED, REVOKED, OFFLINE
    var isHardModeActive: Boolean = false
    var isOnlineState: String = "ONLINE" // ONLINE, DEGRADED, OFFLINE, RECONNECTING

    suspend fun insertOrganisation(org: Organisation) = dao.insertOrganisation(org)
    suspend fun insertPerson(person: Person) = dao.insertPerson(person)
    suspend fun insertIdentity(identity: Identity) = dao.insertIdentity(identity)
    suspend fun insertDevice(device: Device) = dao.insertDevice(device)
    suspend fun insertLink(link: Link) = dao.insertLink(link)
    suspend fun insertChannel(channel: Channel) = dao.insertChannel(channel)
    suspend fun insertMessage(message: Message) = dao.insertMessage(message)
    suspend fun insertCall(call: Call) = dao.insertCall(call)
    suspend fun insertAttachment(attachment: Attachment) = dao.insertAttachment(attachment)
    suspend fun insertSecurityEvent(event: SecurityEvent) = dao.insertSecurityEvent(event)
    suspend fun insertIncident(incident: Incident) = dao.insertIncident(incident)
    suspend fun insertVaultNote(note: VaultNote) = dao.insertVaultNote(note)
    suspend fun deleteVaultNote(noteId: String) = dao.deleteVaultNote(noteId)

    suspend fun logEvent(severity: String, category: String, devId: String, identId: String, details: String) {
        val id = UUID.randomUUID().toString()
        val timestamp = System.currentTimeMillis()
        val hash = CryptoEngine.computeFingerprint("$id-$timestamp-$category-$details")
        val event = SecurityEvent(
            eventId = id,
            severity = severity,
            category = category,
            deviceId = devId,
            identityId = identId,
            timestamp = timestamp,
            eventHash = hash,
            details = details
        )
        dao.insertSecurityEvent(event)
    }

    /**
     * Seeds default nodes, organisations, identities, and devices for the Duke Satoshi Test Network
     */
    suspend fun seedDatabase() = withContext(Dispatchers.IO) {
        val timestamp = System.currentTimeMillis()

        // 1. Organisation
        val dscOrg = Organisation(
            organisationId = "ORG-DSC",
            legalName = "DUKE SATOSHI CYBERSPACE CO.",
            displayName = "DUKE SATOSHI TEST NETWORK",
            status = "VERIFIED",
            createdAt = timestamp
        )
        dao.insertOrganisation(dscOrg)

        // Seed some system health metrics & incidents
        val inc1 = Incident(
            incidentId = "INC-2026-0042",
            title = "Unauthorized Key Derivation Attempt from Node DSC-ZRH-001",
            status = "ACTIVE",
            severity = "HIGH",
            createdAt = timestamp - 3600000,
            activeDevicesCount = 6
        )
        dao.insertIncident(inc1)

        val note1 = VaultNote(
            noteId = "NOTE-001",
            title = "UK Backbone Routing Plan",
            content = "Encrypted local route definitions matching DSC-LON-001. Access key restricted to Secure Enclave.",
            category = "Research Note",
            createdAt = timestamp
        )
        dao.insertVaultNote(note1)

        logEvent("INFO", "system_provisioned", "DSC-LON-001", "SYSTEM", "Duke Satoshi Hard Comms Link local node active.")
    }

    /**
     * Executes a step from the Master Demonstration (1 to 25)
     */
    suspend fun executeDemoStep(step: Int): String = withContext(Dispatchers.IO) {
        val t = System.currentTimeMillis()
        val keyMaya = "e9g8X5r4t3y2u1i0o9p8a7s6d5f4g3h2" // Base64 simulated
        val keyAlex = "k2j1h0g9f8d7s6a5p4o3i2u1y0t9r8e7" // Base64 simulated

        when (step) {
            1 -> {
                // Step 1: Create Maya
                val maya = Person("P-MAYA", "ORG-DSC", "Maya Harrison", "Lead Cryptographic Engineer", "ACTIVE")
                dao.insertPerson(maya)
                val identity = Identity("ID-MAYA", "P-MAYA", "PUB_KEY_MAYA_ED25519_X...", "C42A 1F2B 99C8 8A1D", "UNVERIFIED", t)
                dao.insertIdentity(identity)
                logEvent("INFO", "identity_created", "DSC-LON-001", "ID-MAYA", "Created identity for Maya Harrison.")
                "Step 1 Complete: Person 'Maya Harrison' and Identity created. Status: UNVERIFIED"
            }
            2 -> {
                // Step 2: Register her device
                val dev = Device("DEV-MAYA-MAC", "ID-MAYA", "MAYA-HQ-MACBOOK", "macOS", "DEV_PUB_KEY_MAYA_MAC...", "REGISTERED", t)
                dao.insertDevice(dev)
                logEvent("NOTICE", "device_registered", "DEV-MAYA-MAC", "ID-MAYA", "Registered device MAYA-HQ-MACBOOK.")
                "Step 2 Complete: Device 'MAYA-HQ-MACBOOK' registered under identity ID-MAYA."
            }
            3 -> {
                // Step 3: Create Alexander
                val alex = Person("P-ALEX", "ORG-DSC", "Alexander Reed", "Director of SecOps", "ACTIVE")
                dao.insertPerson(alex)
                val identity = Identity("ID-ALEX", "P-ALEX", "PUB_KEY_ALEX_ED25519_Y...", "91B3 8F4C A092 DC1F", "UNVERIFIED", t)
                dao.insertIdentity(identity)
                logEvent("INFO", "identity_created", "DSC-LON-001", "ID-ALEX", "Created identity for Alexander Reed.")
                "Step 3 Complete: Person 'Alexander Reed' and Identity created. Status: UNVERIFIED"
            }
            4 -> {
                // Step 4: Register Alexander's device
                val dev = Device("DEV-ALEX-PHONE", "ID-ALEX", "ALEX-SECURE-PHONE", "Android", "DEV_PUB_KEY_ALEX_PHONE...", "REGISTERED", t)
                dao.insertDevice(dev)
                logEvent("NOTICE", "device_registered", "DEV-ALEX-PHONE", "ID-ALEX", "Registered device ALEX-SECURE-PHONE.")
                "Step 4 Complete: Device 'ALEX-SECURE-PHONE' registered."
            }
            5 -> {
                // Step 5: Perform identity discovery
                logEvent("INFO", "identity_discovery", "DSC-LON-001", "ID-MAYA", "Initiated remote peer discovery for Alexander Reed.")
                "Step 5 Complete: Out-of-band identity discovery completed. Found remote identity ID-ALEX."
            }
            6 -> {
                // Step 6: Establish encrypted link
                val link = Link(
                    linkId = "LINK-MAYA-ALEX",
                    localIdentityId = "ID-MAYA",
                    remoteIdentityId = "ID-ALEX",
                    localDeviceId = "DEV-MAYA-MAC",
                    remoteDeviceId = "DEV-ALEX-PHONE",
                    verificationState = "UNVERIFIED",
                    protocolVersion = "PQXDH-V1-SPQR",
                    sessionState = "LINK_ESTABLISHED",
                    establishedAt = t,
                    lastKeyRotation = t,
                    lastMessage = "Session initialized."
                )
                dao.insertLink(link)

                val channel = Channel("CH-MAYA-ALEX-DIRECT", "LINK-MAYA-ALEX", "DIRECT", "NORMAL", t)
                dao.insertChannel(channel)

                logEvent("NOTICE", "session_established", "DEV-MAYA-MAC", "ID-MAYA", "Cryptographic link established with remote peer ID-ALEX.")
                "Step 6 Complete: Encrypted PQXDH link established with remote peer. Direct channel created."
            }
            7 -> {
                // Step 7: Verify identities
                val existingMaya = dao.getIdentityById("ID-MAYA")
                if (existingMaya != null) {
                    dao.insertIdentity(existingMaya.copy(verificationState = "VERIFIED"))
                }
                val existingAlex = dao.getIdentityById("ID-ALEX")
                if (existingAlex != null) {
                    dao.insertIdentity(existingAlex.copy(verificationState = "VERIFIED"))
                }
                val existingLink = dao.getLinkById("LINK-MAYA-ALEX")
                if (existingLink != null) {
                    dao.insertLink(existingLink.copy(verificationState = "VERIFIED"))
                }
                logEvent("NOTICE", "identity_verified", "DEV-MAYA-MAC", "ID-MAYA", "Alexander Reed identity VERIFIED via QR Safety Number.")
                "Step 7 Complete: QR Safety Numbers verified. Peer Identity status escalated to VERIFIED."
            }
            8 -> {
                // Step 8: Send message
                val plaintext = "Operational directive: Initialize UK Backbone rotation protocol at 12:00."
                val ciphertext = CryptoEngine.encryptAesGcm(plaintext, keyMaya)
                val msg = Message(
                    messageId = "MSG-001",
                    channelId = "CH-MAYA-ALEX-DIRECT",
                    senderDeviceId = "DEV-MAYA-MAC",
                    ciphertext = ciphertext,
                    encryptedMetadata = "SUITE=HYBRID:ALGO=AES-GCM",
                    createdAt = t,
                    deliveryState = "DELIVERED"
                )
                dao.insertMessage(msg)
                logEvent("INFO", "message_sent", "DEV-MAYA-MAC", "ID-MAYA", "E2EE message transmitted securely to ALEX-SECURE-PHONE.")
                "Step 8 Complete: Message encrypted via Hybrid Suite and successfully delivered."
            }
            9 -> {
                // Step 9: Encrypt attachment
                logEvent("INFO", "file_encrypting", "DEV-MAYA-MAC", "ID-MAYA", "Encrypting file 'backbone_diagram.pdf' using unique attachment key.")
                "Step 9 Complete: 'backbone_diagram.pdf' encrypted using independent, single-use envelope key."
            }
            10 -> {
                // Step 10: Transfer attachment
                val attach = Attachment(
                    attachmentId = "ATT-001",
                    messageId = "MSG-001",
                    encryptedBlobReference = "BLOB-REF-HASH-99827",
                    contentType = "application/pdf",
                    size = 1420500,
                    digest = "E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855"
                )
                dao.insertAttachment(attach)
                logEvent("INFO", "file_uploaded", "DEV-MAYA-MAC", "ID-MAYA", "Encrypted attachment backbone_diagram.pdf uploaded and linked to MSG-001.")
                "Step 10 Complete: Encrypted attachment transferred to secure node object storage."
            }
            11 -> {
                // Step 11: Verify attachment integrity
                logEvent("NOTICE", "integrity_verified", "DEV-MAYA-MAC", "ID-MAYA", "SHA-256 Digest matching payload. Integrity Verified.")
                "Step 11 Complete: SHA-256 integrity digest verified locally on recipient device."
            }
            12 -> {
                // Step 12: Start HARD CALL
                val call = Call(
                    callId = "CALL-001",
                    channelId = "CH-MAYA-ALEX-DIRECT",
                    callType = "VOICE",
                    state = "ACTIVE",
                    startedAt = t,
                    activeParticipantsCount = 2,
                    mediaKeyEpoch = 42
                )
                dao.insertCall(call)
                logEvent("NOTICE", "call_started", "DEV-MAYA-MAC", "ID-MAYA", "End-to-end encrypted call session started between 2 peers.")
                "Step 12 Complete: Hard Call initiated. Media Key Epoch 42. Status: E2EE ACTIVE"
            }
            13 -> {
                // Step 13: Add third verified participant
                val call = dao.getAllCalls().first().firstOrNull()
                if (call != null) {
                    dao.insertCall(call.copy(activeParticipantsCount = 3))
                }
                logEvent("NOTICE", "call_participant_join", "DSC-LON-001", "SYSTEM", "Daniel Shaw (Node DSC-MAN-001) joined the call.")
                "Step 13 Complete: Daniel Shaw added. Total participants: 3."
            }
            14 -> {
                // Step 14: Rotate call media key epoch
                val call = dao.getAllCalls().first().firstOrNull()
                if (call != null) {
                    dao.insertCall(call.copy(mediaKeyEpoch = 43))
                }
                logEvent("NOTICE", "media_key_rotated", "DSC-LON-001", "SYSTEM", "Call Media Key rotated. New epoch: 43.")
                "Step 14 Complete: Media key rotated to Epoch 43. Forward secrecy guaranteed."
            }
            15 -> {
                // Step 15: Remove participant
                val call = dao.getAllCalls().first().firstOrNull()
                if (call != null) {
                    dao.insertCall(call.copy(activeParticipantsCount = 2))
                }
                logEvent("NOTICE", "call_participant_departure", "DSC-LON-001", "SYSTEM", "Daniel Shaw removed from call.")
                "Step 15 Complete: Participant removed. Total participants: 2."
            }
            16 -> {
                // Step 16: Rotate again
                val call = dao.getAllCalls().first().firstOrNull()
                if (call != null) {
                    dao.insertCall(call.copy(mediaKeyEpoch = 44))
                }
                logEvent("NOTICE", "media_key_rotated", "DSC-LON-001", "SYSTEM", "Post-departure media key rotation triggered. Epoch: 44.")
                "Step 16 Complete: Key rotated to Epoch 44. Departed participant cannot decrypt subsequent media."
            }
            17 -> {
                // Step 17: Simulate device key change
                val existingAlex = dao.getIdentityById("ID-ALEX")
                if (existingAlex != null) {
                    dao.insertIdentity(existingAlex.copy(verificationState = "KEY_CHANGED"))
                }
                val existingLink = dao.getLinkById("LINK-MAYA-ALEX")
                if (existingLink != null) {
                    dao.insertLink(existingLink.copy(verificationState = "KEY_CHANGED"))
                }
                logEvent("CRITICAL", "identity_changed", "DEV-ALEX-PHONE", "ID-ALEX", "CRITICAL WARNING: Identity public key changed for Alexander Reed.")
                "Step 17 Complete: Simulated remote device key change. IDENTITY KEY CHANGED triggered!"
            }
            18 -> {
                // Step 18: Suspend link
                val existingLink = dao.getLinkById("LINK-MAYA-ALEX")
                if (existingLink != null) {
                    dao.insertLink(existingLink.copy(sessionState = "SUSPENDED"))
                }
                logEvent("WARNING", "link_suspended", "DSC-LON-001", "ID-ALEX", "Encrypted link 'LINK-MAYA-ALEX' suspended due to outstanding key mismatch.")
                "Step 18 Complete: Link suspended. Safe defaults enforced."
            }
            19 -> {
                // Step 19: Attempt message delivery
                val plaintext = "Attempting emergency message post-compromise warning."
                val msg = Message(
                    messageId = "MSG-002",
                    channelId = "CH-MAYA-ALEX-DIRECT",
                    senderDeviceId = "DEV-MAYA-MAC",
                    ciphertext = "ENCRYPT_FAILED:LINK_SUSPENDED",
                    encryptedMetadata = "FAILED",
                    createdAt = t,
                    deliveryState = "FAILED"
                )
                dao.insertMessage(msg)
                logEvent("WARNING", "delivery_rejected", "DEV-MAYA-MAC", "ID-ALEX", "Outbound transmission blocked: Link suspended.")
                "Step 19 Complete: Message delivery attempted during link suspension."
            }
            20 -> {
                // Step 20: Correctly reject communication
                logEvent("CRITICAL", "cryptographic_rejection", "DEV-MAYA-MAC", "ID-ALEX", "Cryptographic rejection: Remote key signature validation failed.")
                "Step 20 Complete: Transmission correctly blocked at client level. App failed-closed safely."
            }
            21 -> {
                // Step 21: Re-verify device
                val existingAlex = dao.getIdentityById("ID-ALEX")
                if (existingAlex != null) {
                    dao.insertIdentity(existingAlex.copy(verificationState = "VERIFIED"))
                }
                logEvent("NOTICE", "device_reverified", "DEV-MAYA-MAC", "ID-ALEX", "Re-verified Alexander's identity out-of-band. Valid key change confirmed.")
                "Step 21 Complete: Out-of-band re-verification of the new public key signature succeeded."
            }
            22 -> {
                // Step 22: Restore link
                val existingLink = dao.getLinkById("LINK-MAYA-ALEX")
                if (existingLink != null) {
                    dao.insertLink(existingLink.copy(sessionState = "LINK_ESTABLISHED", verificationState = "VERIFIED"))
                }
                logEvent("NOTICE", "link_restored", "DSC-LON-001", "ID-ALEX", "Crypto Link restored to nominal operational state.")
                "Step 22 Complete: Link restored and verified. Resuming E2EE session."
            }
            23 -> {
                // Step 23: Resume communication
                val plaintext = "Secure link verified. Communications restored."
                val ciphertext = CryptoEngine.encryptAesGcm(plaintext, keyMaya)
                val msg = Message(
                    messageId = "MSG-003",
                    channelId = "CH-MAYA-ALEX-DIRECT",
                    senderDeviceId = "DEV-MAYA-MAC",
                    ciphertext = ciphertext,
                    encryptedMetadata = "SUITE=HYBRID",
                    createdAt = t,
                    deliveryState = "DELIVERED"
                )
                dao.insertMessage(msg)
                logEvent("INFO", "message_sent", "DEV-MAYA-MAC", "ID-MAYA", "E2EE communication resumed successfully.")
                "Step 23 Complete: Success. Communications re-established and verified."
            }
            24 -> {
                // Step 24: Open Security Centre
                "Step 24 Complete: Opened Security Centre. Real security logs available."
            }
            25 -> {
                // Step 25: Show complete security event history
                "Step 25 Complete: Complete audit-trail and security events shown on instrument."
            }
            else -> "Unknown Demonstration Step."
        }
    }

    /**
     * Executes a step from the Failure Demonstration (1 to 12)
     */
    suspend fun executeFailureDemo(step: Int): String = withContext(Dispatchers.IO) {
        val t = System.currentTimeMillis()
        when (step) {
            1 -> {
                logEvent("CRITICAL", "wrong_key_validation", "DSC-LON-001", "ID-ALEX", "Symmetric key mismatch: Decrypted MAC check failed.")
                "Failure Case 1: Wrong Key validated. Decryption aborted securely."
            }
            2 -> {
                logEvent("CRITICAL", "message_tampered", "DSC-LON-001", "ID-ALEX", "Integrity check failed: GCM Authentication tag invalid.")
                "Failure Case 2: Tampered message detected. Payload discarded before reading."
            }
            3 -> {
                logEvent("WARNING", "replay_attack_detected", "DSC-LON-001", "ID-ALEX", "Message replay detected: Sequence number already used.")
                "Failure Case 3: Replayed message blocked. Out-of-order counter matching existing."
            }
            4 -> {
                logEvent("HIGH", "revoked_device_attempt", "DEV-ALEX-PHONE", "ID-ALEX", "Blocked communications attempt from revoked device ID: DEV-ALEX-PHONE.")
                "Failure Case 4: Device revoked. Active keys cleared. Session terminated."
            }
            5 -> {
                logEvent("NOTICE", "session_expired", "DSC-LON-001", "ID-ALEX", "Session time-to-live expired. Rotating ephemeral key materials.")
                "Failure Case 5: Expired session terminated. Automated key agreement re-triggered."
            }
            6 -> {
                logEvent("HIGH", "invalid_identity_signature", "DSC-LON-001", "ID-ALEX", "Remote identity validation failed. Invalid signature.")
                "Failure Case 6: Invalid identity credentials rejected during handshake."
            }
            7 -> {
                logEvent("HIGH", "unknown_device_detected", "DSC-LON-001", "UNKNOWN", "Unknown device tried to access the channel. Access denied.")
                "Failure Case 7: Unknown device rejected."
            }
            8 -> {
                logEvent("WARNING", "attachment_checksum_failed", "DSC-LON-001", "ID-MAYA", "Attachment SHA-256 digest mismatch. File corrupted.")
                "Failure Case 8: Corrupt attachment checksum failed. File transfer aborted."
            }
            9 -> {
                logEvent("NOTICE", "node_connection_lost", "DSC-LON-001", "SYSTEM", "Remote Node DSC-ZRH-001 reported OFFLINE.")
                "Failure Case 9: Offline node. Queueing outbound payloads locally."
            }
            10 -> {
                logEvent("WARNING", "duplicate_message_rejected", "DSC-LON-001", "ID-ALEX", "Duplicate message received and rejected. ID: MSG-001.")
                "Failure Case 10: Duplicate message discarded."
            }
            11 -> {
                logEvent("WARNING", "out_of_order_message", "DSC-LON-001", "ID-ALEX", "Message out of sequence. Re-ordered in playback queue.")
                "Failure Case 11: Out-of-order sequence corrected and recorded."
            }
            12 -> {
                logEvent("HIGH", "verification_aborted", "DSC-LON-001", "ID-ALEX", "Safety Number verification mismatch. Aborted by local operator.")
                "Failure Case 12: Failed verification. Link suspended."
            }
            else -> "Unknown Failure Case."
        }
    }
}
