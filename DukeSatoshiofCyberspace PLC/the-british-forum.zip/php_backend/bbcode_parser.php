<?php
/**
 * The British Forum - PHP BBCode & Rich Post Parser
 * Converts forum BBCode tags to clean, sanitized HTML
 */

header('Content-Type: application/json');

function parse_bbcode($text) {
    // Sanitize first
    $text = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');

    $find = [
        '~\[b\](.*?)\[/b\]~s',
        '~\[i\](.*?)\[/i\]~s',
        '~\[u\](.*?)\[/u\]~s',
        '~\[quote=(.*?)\](.*?)\[/quote\]~s',
        '~\[quote\](.*?)\[/quote\]~s',
        '~\[code\](.*?)\[/code\]~s',
        '~\[url=(.*?)\](.*?)\[/url\]~s',
        '~\[color=(.*?)\](.*?)\[/color\]~s'
    ];

    $replace = [
        '<strong>$1</strong>',
        '<em>$1</em>',
        '<span class="underline">$1</span>',
        '<blockquote class="border-l-2 border-sky-600 bg-slate-900/40 pl-4 py-2 my-2 text-slate-300 italic"><div class="text-xs font-semibold text-sky-400 not-italic mb-1">$1 wrote:</div>$2</blockquote>',
        '<blockquote class="border-l-2 border-sky-600 bg-slate-900/40 pl-4 py-2 my-2 text-slate-300 italic">$1</blockquote>',
        '<pre class="bg-slate-950 p-3 rounded font-mono text-xs text-sky-300 overflow-x-auto my-2">$1</pre>',
        '<a href="$1" target="_blank" rel="noopener noreferrer" class="text-sky-400 hover:underline">$2</a>',
        '<span style="color: $1">$2</span>'
    ];

    $parsed = preg_replace($find, $replace, $text);
    return nl2br($parsed);
}

if (php_sapi_name() === 'cli') {
    $raw_input = isset($argv[1]) ? $argv[1] : '';
    if ($raw_input === '' && !posix_isatty(STDIN)) {
        $raw_input = file_get_contents('php://stdin');
    }
    
    $html = parse_bbcode($raw_input);
    echo json_encode([
        'status' => 'success',
        'engine' => 'PHP BBCode Parser v2.1',
        'raw' => $raw_input,
        'html' => $html
    ]) . PHP_EOL;
}
