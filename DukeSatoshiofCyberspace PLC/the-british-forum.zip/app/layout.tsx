import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'The British Forum - Discuss, Debate, Build a Better Britain',
  description: 'The premier British discussion community for politics, economy, tech, culture, and life across the UK.',
  openGraph: {
    title: 'The British Forum - Discuss, Debate, Build a Better Britain',
    description: 'The premier British discussion community for politics, economy, tech, culture, and life across the UK.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'The British Forum - Discuss, Debate, Build a Better Britain',
    description: 'The premier British discussion community for politics, economy, tech, culture, and life across the UK.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-[#070d18] text-slate-100 antialiased font-sans" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
