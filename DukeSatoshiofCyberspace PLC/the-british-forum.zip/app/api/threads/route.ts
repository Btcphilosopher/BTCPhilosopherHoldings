import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const categorySlug = searchParams.get('category') || undefined;
    const sort = (searchParams.get('sort') || 'activity') as 'activity' | 'replies' | 'views' | 'newest';
    const search = searchParams.get('q') || undefined;

    const threads = db.getThreads({
      categorySlug,
      sort,
      search,
    });

    return NextResponse.json({
      success: true,
      threads,
      total: threads.length
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { title, categorySlug, content, userId } = body;

    if (!title || !title.trim()) {
      return NextResponse.json({ success: false, error: 'Thread title is required' }, { status: 400 });
    }
    if (!content || !content.trim()) {
      return NextResponse.json({ success: false, error: 'Initial post content is required' }, { status: 400 });
    }

    const thread = db.createThread({
      title: title.trim(),
      categorySlug: categorySlug || 'uk-news-politics',
      content: content.trim(),
      userId: userId || 1,
    });

    return NextResponse.json({
      success: true,
      thread
    }, { status: 201 });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
