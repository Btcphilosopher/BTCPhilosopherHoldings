import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const threadId = parseInt(id, 10);
    if (isNaN(threadId)) {
      return NextResponse.json({ success: false, error: 'Invalid thread ID' }, { status: 400 });
    }

    const body = await req.json();
    const { content, userId } = body;

    if (!content || !content.trim()) {
      return NextResponse.json({ success: false, error: 'Reply content cannot be empty' }, { status: 400 });
    }

    const reply = db.addReply({
      threadId,
      userId: userId || 1,
      content: content.trim()
    });

    if (!reply) {
      return NextResponse.json({ success: false, error: 'Thread not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      reply
    }, { status: 201 });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
