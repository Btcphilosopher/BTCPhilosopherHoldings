import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { username, email, password, displayName, location } = body;

    if (!username || username.trim().length < 3) {
      return NextResponse.json({ success: false, error: 'Username must be at least 3 characters' }, { status: 400 });
    }
    if (!email || !email.includes('@')) {
      return NextResponse.json({ success: false, error: 'A valid email address is required' }, { status: 400 });
    }
    if (!password || password.length < 6) {
      return NextResponse.json({ success: false, error: 'Password must be at least 6 characters' }, { status: 400 });
    }

    const existingUser = db.getUserByUsernameOrEmail(username) || db.getUserByUsernameOrEmail(email);
    if (existingUser) {
      return NextResponse.json({ success: false, error: 'Username or email already in use' }, { status: 409 });
    }

    const newUser = db.createUser({
      username: username.trim(),
      email: email.trim().toLowerCase(),
      passwordHash: `$2y$11$sample_hashed_${Date.now()}`,
      displayName: displayName ? displayName.trim() : username.trim(),
      location: location ? location.trim() : 'United Kingdom'
    });

    const token = `btf_sess_${newUser.id}_${Date.now()}`;

    return NextResponse.json({
      success: true,
      token,
      user: {
        id: newUser.id,
        username: newUser.username,
        displayName: newUser.displayName,
        role: newUser.role,
        avatarUrl: newUser.avatarUrl,
        customTitle: newUser.customTitle,
        reputation: newUser.reputation,
        postCount: newUser.postCount,
        initials: newUser.initials
      }
    }, { status: 201 });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
