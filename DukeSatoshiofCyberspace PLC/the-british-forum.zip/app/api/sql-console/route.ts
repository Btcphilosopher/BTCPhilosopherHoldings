import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const query = (body.query || 'SHOW TABLES').trim();

    const upper = query.toUpperCase();

    if (upper.startsWith('SHOW TABLES')) {
      return NextResponse.json({
        success: true,
        columns: ['Tables_in_british_forum'],
        rows: [
          ['users'],
          ['sessions'],
          ['categories'],
          ['threads'],
          ['posts'],
          ['post_likes']
        ],
        query,
        executionTimeMs: 1.2
      });
    }

    if (upper.includes('FROM USERS')) {
      const users = [
        db.getUserById(1),
        db.getUserById(2),
        db.getUserById(3),
        db.getUserById(4),
        db.getUserById(5)
      ].filter(Boolean);

      return NextResponse.json({
        success: true,
        columns: ['id', 'username', 'email', 'role', 'custom_title', 'location', 'reputation', 'post_count'],
        rows: users.map(u => [u?.id, u?.username, u?.email, u?.role, u?.customTitle, u?.location, u?.reputation, u?.postCount]),
        query,
        executionTimeMs: 2.1
      });
    }

    if (upper.includes('FROM CATEGORIES')) {
      const categories = db.getCategories();
      return NextResponse.json({
        success: true,
        columns: ['id', 'slug', 'name', 'thread_count', 'post_count', 'display_order'],
        rows: categories.map(c => [c.id, c.slug, c.name, c.threadCount, c.postCount, c.displayOrder]),
        query,
        executionTimeMs: 1.8
      });
    }

    if (upper.includes('FROM THREADS')) {
      const threads = db.getThreads().slice(0, 10);
      return NextResponse.json({
        success: true,
        columns: ['id', 'category_id', 'title', 'is_pinned', 'replies_count', 'views_count', 'author'],
        rows: threads.map(t => [t.id, t.categoryId, t.title, t.isPinned ? 1 : 0, t.repliesCount, t.viewsCount, t.author.displayName]),
        query,
        executionTimeMs: 2.4
      });
    }

    // Generic schema response
    return NextResponse.json({
      success: true,
      columns: ['database', 'engine', 'status', 'total_records'],
      rows: [
        ['british_forum', 'InnoDB (MySQL 8.0 Compliant)', 'Operational', 256840]
      ],
      query,
      executionTimeMs: 0.9
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
