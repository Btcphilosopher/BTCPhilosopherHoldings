'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { TopHeader } from '@/components/TopHeader';
import { SubNav } from '@/components/SubNav';
import { AnnouncementBanner } from '@/components/AnnouncementBanner';
import { CategorySidebar } from '@/components/CategorySidebar';
import { DiscussionList } from '@/components/DiscussionList';
import { ThreadView } from '@/components/ThreadView';
import { RightSidebar } from '@/components/RightSidebar';
import { AuthModal } from '@/components/AuthModal';
import { NewThreadModal } from '@/components/NewThreadModal';
import { TechArchitectureModal } from '@/components/TechArchitectureModal';
import { Footer } from '@/components/Footer';
import type { Category, Thread, CommunityStats, User } from '@/lib/db';

export default function HomePage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [threads, setThreads] = useState<Thread[]>([]);
  const [stats, setStats] = useState<CommunityStats>({
    members: 248732,
    threads: 52618,
    posts: 1942387,
    lastMember: 'YorkshireLad',
  });
  const [latestPosts, setLatestPosts] = useState<
    { id: number; title: string; category: string; timeAgo: string; userInitial: string; threadId: number }[]
  >([]);

  // Navigation and filtering
  const [currentTab, setCurrentTab] = useState('home');
  const [selectedCategorySlug, setSelectedCategorySlug] = useState('all');
  const [sortBy, setSortBy] = useState<'activity' | 'replies' | 'views' | 'newest'>('activity');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeThread, setActiveThread] = useState<Thread | null>(null);

  // Authentication State
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Modals
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [newThreadModalOpen, setNewThreadModalOpen] = useState(false);
  const [techModalOpen, setTechModalOpen] = useState(false);

  // Load initial categories & stats
  const fetchMetadata = useCallback(async () => {
    try {
      const [catsRes, statsRes] = await Promise.all([
        fetch('/api/categories'),
        fetch('/api/stats'),
      ]);
      const catsData = await catsRes.json();
      const statsData = await statsRes.json();

      if (catsData.success) setCategories(catsData.categories);
      if (statsData.success) {
        setStats(statsData.stats);
        if (statsData.latestPosts) setLatestPosts(statsData.latestPosts);
      }
    } catch (err) {
      console.error('Failed to load initial forum data', err);
    }
  }, []);

  // Fetch threads with active filter
  const fetchThreads = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (selectedCategorySlug !== 'all') {
        params.set('category', selectedCategorySlug);
      }
      params.set('sort', sortBy);
      if (searchQuery.trim()) {
        params.set('q', searchQuery.trim());
      }

      const res = await fetch(`/api/threads?${params.toString()}`);
      const data = await res.json();
      if (data.success) {
        setThreads(data.threads);
      }
    } catch (err) {
      console.error('Failed to load threads', err);
    }
  }, [selectedCategorySlug, sortBy, searchQuery]);

  // Load thread detail
  const loadThreadDetail = useCallback(async (threadId: number) => {
    try {
      const res = await fetch(`/api/threads/${threadId}`);
      const data = await res.json();
      if (data.success) {
        setActiveThread(data.thread);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } catch (err) {
      console.error('Failed to load thread detail', err);
    }
  }, []);

  useEffect(() => {
    fetchMetadata();
  }, [fetchMetadata]);

  useEffect(() => {
    fetchThreads();
  }, [fetchThreads]);

  // Post reply handler
  const handlePostReply = async (content: string) => {
    if (!activeThread) return;
    try {
      const res = await fetch(`/api/threads/${activeThread.id}/reply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content,
          userId: currentUser?.id || 1,
        }),
      });
      const data = await res.json();
      if (data.success) {
        // Refresh thread detail and thread list
        await loadThreadDetail(activeThread.id);
        fetchThreads();
        fetchMetadata();
      }
    } catch (err) {
      console.error('Failed to post reply', err);
    }
  };

  // Toggle like handler
  const handleToggleLike = async (postId: number) => {
    if (!activeThread) return;
    try {
      await fetch(`/api/posts/${postId}/like`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser?.id || 1 }),
      });
      await loadThreadDetail(activeThread.id);
    } catch (err) {
      console.error('Failed to toggle like', err);
    }
  };

  // Create thread handler
  const handleCreateThread = async (params: {
    title: string;
    categorySlug: string;
    content: string;
  }) => {
    try {
      const res = await fetch('/api/threads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...params,
          userId: currentUser?.id || 1,
        }),
      });
      const data = await res.json();
      if (data.success) {
        await fetchThreads();
        await fetchMetadata();
        if (data.thread?.id) {
          await loadThreadDetail(data.thread.id);
        }
      }
    } catch (err) {
      console.error('Failed to create thread', err);
    }
  };

  const handleOpenAuth = (mode: 'login' | 'register' = 'login') => {
    setAuthMode(mode);
    setAuthModalOpen(true);
  };

  const handleResetHome = () => {
    setActiveThread(null);
    setSelectedCategorySlug('all');
    setSearchQuery('');
    setCurrentTab('home');
  };

  const currentCategory = categories.find((c) => c.slug === selectedCategorySlug);

  return (
    <div className="min-h-screen flex flex-col bg-[#070e1a] text-slate-100">
      {/* 1. Panoramic Top Header with Westminster view */}
      <TopHeader
        currentUser={currentUser}
        onOpenAuth={handleOpenAuth}
        onLogout={() => setCurrentUser(null)}
        searchQuery={searchQuery}
        onSearchChange={(q) => {
          setSearchQuery(q);
          setActiveThread(null);
        }}
        onOpenTech={() => setTechModalOpen(true)}
        onResetView={handleResetHome}
      />

      {/* 2. Sub-Navigation Bar */}
      <SubNav
        currentTab={currentTab}
        onTabChange={(tab) => {
          setCurrentTab(tab);
          if (tab === 'home' || tab === 'forums') {
            setActiveThread(null);
            setSelectedCategorySlug('all');
          }
        }}
        onOpenTech={() => setTechModalOpen(true)}
      />

      {/* 3. Community Notice Banner */}
      <AnnouncementBanner />

      {/* 4. Main 3-Column Content Grid */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex flex-col lg:flex-row gap-5 items-start">
          {/* Left Column: Forum Categories */}
          <CategorySidebar
            categories={categories}
            selectedCategorySlug={selectedCategorySlug}
            onSelectCategory={(slug) => {
              setSelectedCategorySlug(slug);
              setActiveThread(null);
            }}
          />

          {/* Center Column: Latest Discussions or Active Thread Detail */}
          {activeThread ? (
            <ThreadView
              thread={activeThread}
              currentUser={currentUser}
              onBack={() => setActiveThread(null)}
              onSelectCategorySlug={(slug) => {
                setSelectedCategorySlug(slug);
                setActiveThread(null);
              }}
              onPostReply={handlePostReply}
              onToggleLike={handleToggleLike}
              onOpenAuth={() => handleOpenAuth('login')}
            />
          ) : (
            <DiscussionList
              threads={threads}
              selectedCategoryName={currentCategory ? currentCategory.name : 'Latest Discussions'}
              sortBy={sortBy}
              onSortChange={(sort) => setSortBy(sort)}
              onOpenNewThread={() => setNewThreadModalOpen(true)}
              onSelectThread={(id) => loadThreadDetail(id)}
              onSelectCategorySlug={(slug) => setSelectedCategorySlug(slug)}
            />
          )}

          {/* Right Column: Widgets & Community Stats */}
          <RightSidebar
            stats={stats}
            latestPosts={latestPosts}
            onSelectThread={(threadId) => loadThreadDetail(threadId)}
            onJoinClick={() => handleOpenAuth('register')}
          />
        </div>
      </main>

      {/* 5. Footer */}
      <Footer
        onNavClick={(tab) => {
          setCurrentTab(tab);
          setActiveThread(null);
        }}
        onOpenTech={() => setTechModalOpen(true)}
      />

      {/* Modals */}
      <AuthModal
        isOpen={authModalOpen}
        initialMode={authMode}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={(user) => {
          setCurrentUser(user);
        }}
      />

      <NewThreadModal
        isOpen={newThreadModalOpen}
        onClose={() => setNewThreadModalOpen(false)}
        categories={categories}
        currentCategorySlug={selectedCategorySlug}
        currentUser={currentUser}
        onOpenAuth={() => handleOpenAuth('login')}
        onCreateThread={handleCreateThread}
      />

      <TechArchitectureModal
        isOpen={techModalOpen}
        onClose={() => setTechModalOpen(false)}
      />
    </div>
  );
}
