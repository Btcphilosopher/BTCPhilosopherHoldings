import fs from 'fs';
import path from 'path';

export interface User {
  id: number;
  username: string;
  email: string;
  passwordHash: string;
  displayName: string;
  role: 'admin' | 'moderator' | 'vip' | 'member';
  avatarUrl: string;
  customTitle: string;
  location: string;
  reputation: number;
  postCount: number;
  threadCount: number;
  joinedAt: string;
  initials: string;
}

export interface Category {
  id: number;
  slug: string;
  name: string;
  description: string;
  iconName: string;
  threadCount: number;
  postCount: number;
  displayOrder: number;
}

export interface Post {
  id: number;
  threadId: number;
  userId: number;
  user: User;
  content: string;
  isOriginalPost: boolean;
  likesCount: number;
  likedByUserIds: number[];
  createdAt: string;
  timeAgo: string;
}

export interface Thread {
  id: number;
  categoryId: number;
  categoryName: string;
  categorySlug: string;
  userId: number;
  author: User;
  title: string;
  slug: string;
  isPinned: boolean;
  isLocked: boolean;
  viewsCount: number;
  repliesCount: number;
  lastPostUserId: number;
  lastPostUser: User;
  lastPostTimeAgo: string;
  createdAt: string;
  timeAgo: string;
  posts?: Post[];
}

export interface CommunityStats {
  members: number;
  threads: number;
  posts: number;
  lastMember: string;
}

interface ForumDataStore {
  users: User[];
  categories: Category[];
  threads: Thread[];
  posts: Post[];
  stats: CommunityStats;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'forum_store.json');

const INITIAL_USERS: User[] = [
  {
    id: 1,
    username: 'Admin',
    email: 'admin@britishforum.co.uk',
    passwordHash: '$2y$11$q9hEshJ.sE5Q9/3lZkgzUuF73w7.0fI1k1jE4k2h7.8a9zE3d1r4y',
    displayName: 'Admin',
    role: 'admin',
    avatarUrl: '/images/admin_avatar.jpg',
    customTitle: 'Founder & Moderator',
    location: 'Westminster, London',
    reputation: 9850,
    postCount: 1420,
    threadCount: 45,
    joinedAt: '2024-01-01T00:00:00Z',
    initials: 'AD'
  },
  {
    id: 2,
    username: 'YorkshireLad',
    email: 'yorkshire@britishforum.co.uk',
    passwordHash: '$2y$11$q9hEshJ.sE5Q9/3lZkgzUuF73w7.0fI1k1jE4k2h7.8a9zE3d1r4y',
    displayName: 'YorkshireLad',
    role: 'vip',
    avatarUrl: '/images/member_avatar.jpg',
    customTitle: 'Community Veteran',
    location: 'North Yorkshire',
    reputation: 4320,
    postCount: 3840,
    threadCount: 112,
    joinedAt: '2024-03-15T00:00:00Z',
    initials: 'YL'
  },
  {
    id: 3,
    username: 'FlatCapDave',
    email: 'dave@britishforum.co.uk',
    passwordHash: '$2y$11$q9hEshJ.sE5Q9/3lZkgzUuF73w7.0fI1k1jE4k2h7.8a9zE3d1r4y',
    displayName: 'FlatCapDave',
    role: 'member',
    avatarUrl: '',
    customTitle: 'Senior Contributor',
    location: 'Lancashire',
    reputation: 2190,
    postCount: 1980,
    threadCount: 68,
    joinedAt: '2024-05-10T00:00:00Z',
    initials: 'FD'
  },
  {
    id: 4,
    username: 'LakeDistrictFan',
    email: 'cumbria@britishforum.co.uk',
    passwordHash: '$2y$11$q9hEshJ.sE5Q9/3lZkgzUuF73w7.0fI1k1jE4k2h7.8a9zE3d1r4y',
    displayName: 'LakeDistrictFan',
    role: 'member',
    avatarUrl: '',
    customTitle: 'Outdoors Enthusiast',
    location: 'Keswick, Cumbria',
    reputation: 1740,
    postCount: 890,
    threadCount: 42,
    joinedAt: '2024-06-22T00:00:00Z',
    initials: 'LF'
  },
  {
    id: 5,
    username: 'GadgetGirl',
    email: 'tech@britishforum.co.uk',
    passwordHash: '$2y$11$q9hEshJ.sE5Q9/3lZkgzUuF73w7.0fI1k1jE4k2h7.8a9zE3d1r4y',
    displayName: 'GadgetGirl',
    role: 'member',
    avatarUrl: '',
    customTitle: 'Silicon Fen Techie',
    location: 'Cambridge',
    reputation: 3410,
    postCount: 2210,
    threadCount: 75,
    joinedAt: '2024-04-05T00:00:00Z',
    initials: 'GG'
  },
  {
    id: 6,
    username: 'WessexWanderer',
    email: 'wessex@britishforum.co.uk',
    passwordHash: '$2y$11$q9hEshJ.sE5Q9/3lZkgzUuF73w7.0fI1k1jE4k2h7.8a9zE3d1r4y',
    displayName: 'WessexWanderer',
    role: 'member',
    avatarUrl: '',
    customTitle: 'Historian',
    location: 'Winchester, Hampshire',
    reputation: 2890,
    postCount: 1450,
    threadCount: 54,
    joinedAt: '2024-02-18T00:00:00Z',
    initials: 'WW'
  },
  {
    id: 7,
    username: 'GoalDigger',
    email: 'football@britishforum.co.uk',
    passwordHash: '$2y$11$q9hEshJ.sE5Q9/3lZkgzUuF73w7.0fI1k1jE4k2h7.8a9zE3d1r4y',
    displayName: 'GoalDigger',
    role: 'member',
    avatarUrl: '',
    customTitle: 'Matchday Analyst',
    location: 'Newcastle upon Tyne',
    reputation: 4120,
    postCount: 3120,
    threadCount: 95,
    joinedAt: '2024-01-20T00:00:00Z',
    initials: 'GD'
  },
  {
    id: 8,
    username: 'DataDave',
    email: 'datadave@britishforum.co.uk',
    passwordHash: '$2y$11$q9hEshJ.sE5Q9/3lZkgzUuF73w7.0fI1k1jE4k2h7.8a9zE3d1r4y',
    displayName: 'DataDave',
    role: 'member',
    avatarUrl: '',
    customTitle: 'AI & Data Specialist',
    location: 'London',
    reputation: 2650,
    postCount: 1670,
    threadCount: 39,
    joinedAt: '2024-07-11T00:00:00Z',
    initials: 'DD'
  },
  {
    id: 9,
    username: 'PintSearcher',
    email: 'ale@britishforum.co.uk',
    passwordHash: '$2y$11$q9hEshJ.sE5Q9/3lZkgzUuF73w7.0fI1k1jE4k2h7.8a9zE3d1r4y',
    displayName: 'PintSearcher',
    role: 'member',
    avatarUrl: '',
    customTitle: 'CAMRA Ambassador',
    location: 'Burton upon Trent',
    reputation: 1980,
    postCount: 940,
    threadCount: 31,
    joinedAt: '2024-08-01T00:00:00Z',
    initials: 'PS'
  },
  {
    id: 10,
    username: 'TrailBlazer',
    email: 'hiker@britishforum.co.uk',
    passwordHash: '$2y$11$q9hEshJ.sE5Q9/3lZkgzUuF73w7.0fI1k1jE4k2h7.8a9zE3d1r4y',
    displayName: 'TrailBlazer',
    role: 'member',
    avatarUrl: '',
    customTitle: 'Highland Explorer',
    location: 'Fort William, Scotland',
    reputation: 1530,
    postCount: 720,
    threadCount: 28,
    joinedAt: '2024-09-09T00:00:00Z',
    initials: 'TB'
  },
  {
    id: 11,
    username: 'ConservativeMind',
    email: 'politics@britishforum.co.uk',
    passwordHash: '$2y$11$q9hEshJ.sE5Q9/3lZkgzUuF73w7.0fI1k1jE4k2h7.8a9zE3d1r4y',
    displayName: 'ConservativeMind',
    role: 'member',
    avatarUrl: '',
    customTitle: 'Policy Analyst',
    location: 'Edinburgh',
    reputation: 2210,
    postCount: 1540,
    threadCount: 62,
    joinedAt: '2024-03-01T00:00:00Z',
    initials: 'CM'
  },
  {
    id: 12,
    username: 'Londoner1987',
    email: 'londoner@britishforum.co.uk',
    passwordHash: '$2y$11$q9hEshJ.sE5Q9/3lZkgzUuF73w7.0fI1k1jE4k2h7.8a9zE3d1r4y',
    displayName: 'Londoner1987',
    role: 'member',
    avatarUrl: '',
    customTitle: 'Civic Member',
    location: 'Greenwich, London',
    reputation: 3100,
    postCount: 2890,
    threadCount: 88,
    joinedAt: '2024-02-14T00:00:00Z',
    initials: 'LM'
  }
];

const INITIAL_CATEGORIES: Category[] = [
  { id: 1, slug: 'uk-news-politics', name: 'UK News & Politics', description: 'Debate Westminster affairs, national elections, policy, and public discourse.', iconName: 'Landmark', threadCount: 12400, postCount: 198600, displayOrder: 1 },
  { id: 2, slug: 'economy-finance', name: 'Economy & Finance', description: 'Bank of England rates, cost of living, business, housing market, and personal finance.', iconName: 'TrendingUp', threadCount: 8700, postCount: 145200, displayOrder: 2 },
  { id: 3, slug: 'technology-innovation', name: 'Technology & Innovation', description: 'British tech sector, AI research, consumer electronics, telecom, and scientific computing.', iconName: 'Cpu', threadCount: 6300, postCount: 102800, displayOrder: 3 },
  { id: 4, slug: 'science-environment', name: 'Science & Environment', description: 'Energy transition, British biodiversity, National Parks, climate, and space research.', iconName: 'Leaf', threadCount: 4900, postCount: 76300, displayOrder: 4 },
  { id: 5, slug: 'history-heritage', name: 'History & Heritage', description: 'British castles, Roman Britain, the Industrial Revolution, archaeology, and historical archives.', iconName: 'Building2', threadCount: 5200, postCount: 93100, displayOrder: 5 },
  { id: 6, slug: 'culture-arts-media', name: 'Culture, Arts & Media', description: 'British cinema, West End theater, BBC, literature, visual arts, and broadcasting.', iconName: 'Palette', threadCount: 3800, postCount: 67400, displayOrder: 6 },
  { id: 7, slug: 'sport', name: 'Sport', description: 'Premier League, Six Nations Rugby, The Ashes cricket, Wimbledon, and Formula 1.', iconName: 'Trophy', threadCount: 4100, postCount: 89700, displayOrder: 7 },
  { id: 8, slug: 'gaming-entertainment', name: 'Gaming & Entertainment', description: 'UK video game developers, television, streaming, board games, and popular culture.', iconName: 'Gamepad2', threadCount: 2600, postCount: 54200, displayOrder: 8 },
  { id: 9, slug: 'life-travel-outdoors', name: 'Life, Travel & Outdoors', description: 'Hiking in the Highlands, coastal getaways, Cotswolds villages, pubs, and British lifestyle.', iconName: 'Mountain', threadCount: 3400, postCount: 71900, displayOrder: 9 },
  { id: 10, slug: 'local-regional', name: 'Local & Regional', description: 'Town halls, devolved nations (Scotland, Wales, Northern Ireland), and county discussions.', iconName: 'MapPin', threadCount: 1800, postCount: 32600, displayOrder: 10 },
  { id: 11, slug: 'off-topic', name: 'Off Topic', description: 'Casual banter, British weather complaints, everyday observations, and general chatter.', iconName: 'MessageCircle', threadCount: 2900, postCount: 58300, displayOrder: 11 }
];

const INITIAL_THREADS: Thread[] = [
  {
    id: 1,
    categoryId: 1,
    categoryName: 'Site Announcements',
    categorySlug: 'uk-news-politics',
    userId: 1,
    author: INITIAL_USERS[0],
    title: 'Welcome to The British Forum',
    slug: 'welcome-to-the-british-forum',
    isPinned: true,
    isLocked: false,
    viewsCount: 12400,
    repliesCount: 24,
    lastPostUserId: 1,
    lastPostUser: INITIAL_USERS[0],
    lastPostTimeAgo: '2 years ago',
    createdAt: '2024-01-01T12:00:00Z',
    timeAgo: '2 years ago'
  },
  {
    id: 2,
    categoryId: 2,
    categoryName: 'Economy & Finance',
    categorySlug: 'economy-finance',
    userId: 11,
    author: INITIAL_USERS[10],
    title: "The UK's Energy Future – Nuclear, Renewables or Both?",
    slug: 'uk-energy-future-nuclear-renewables',
    isPinned: false,
    isLocked: false,
    viewsCount: 6800,
    repliesCount: 142,
    lastPostUserId: 2,
    lastPostUser: INITIAL_USERS[1],
    lastPostTimeAgo: '13 minutes ago',
    createdAt: '2026-10-31T06:50:00Z',
    timeAgo: '3 hours ago'
  },
  {
    id: 3,
    categoryId: 1,
    categoryName: 'UK News & Politics',
    categorySlug: 'uk-news-politics',
    userId: 12,
    author: INITIAL_USERS[11],
    title: 'Is the UK heading for another housing crisis?',
    slug: 'is-uk-heading-for-another-housing-crisis',
    isPinned: false,
    isLocked: false,
    viewsCount: 12100,
    repliesCount: 287,
    lastPostUserId: 3,
    lastPostUser: INITIAL_USERS[2],
    lastPostTimeAgo: '28 minutes ago',
    createdAt: '2026-10-31T04:50:00Z',
    timeAgo: '5 hours ago'
  },
  {
    id: 4,
    categoryId: 9,
    categoryName: 'Life, Travel & Outdoors',
    categorySlug: 'life-travel-outdoors',
    userId: 4,
    author: INITIAL_USERS[3],
    title: 'Best British coastal towns for a summer holiday?',
    slug: 'best-british-coastal-towns-summer-holiday',
    isPinned: false,
    isLocked: false,
    viewsCount: 4300,
    repliesCount: 96,
    lastPostUserId: 4,
    lastPostUser: INITIAL_USERS[3],
    lastPostTimeAgo: '1 hour ago',
    createdAt: '2026-10-31T02:50:00Z',
    timeAgo: '7 hours ago'
  },
  {
    id: 5,
    categoryId: 3,
    categoryName: 'Technology & Innovation',
    categorySlug: 'technology-innovation',
    userId: 5,
    author: INITIAL_USERS[4],
    title: 'New iPhone 18 – worth the upgrade?',
    slug: 'new-iphone-18-worth-upgrade',
    isPinned: false,
    isLocked: false,
    viewsCount: 8700,
    repliesCount: 203,
    lastPostUserId: 5,
    lastPostUser: INITIAL_USERS[4],
    lastPostTimeAgo: '1 hour ago',
    createdAt: '2026-10-31T01:50:00Z',
    timeAgo: '8 hours ago'
  },
  {
    id: 6,
    categoryId: 5,
    categoryName: 'History & Heritage',
    categorySlug: 'history-heritage',
    userId: 6,
    author: INITIAL_USERS[5],
    title: 'The History of the British Empire – a balanced view?',
    slug: 'history-british-empire-balanced-view',
    isPinned: false,
    isLocked: false,
    viewsCount: 9200,
    repliesCount: 176,
    lastPostUserId: 6,
    lastPostUser: INITIAL_USERS[5],
    lastPostTimeAgo: '2 hours ago',
    createdAt: '2026-10-30T23:50:00Z',
    timeAgo: '10 hours ago'
  },
  {
    id: 7,
    categoryId: 7,
    categoryName: 'Sport',
    categorySlug: 'sport',
    userId: 7,
    author: INITIAL_USERS[6],
    title: 'Premier League 2025/26 Predictions',
    slug: 'premier-league-2025-26-predictions',
    isPinned: false,
    isLocked: false,
    viewsCount: 16800,
    repliesCount: 312,
    lastPostUserId: 7,
    lastPostUser: INITIAL_USERS[6],
    lastPostTimeAgo: '3 hours ago',
    createdAt: '2026-10-30T21:50:00Z',
    timeAgo: '12 hours ago'
  },
  {
    id: 8,
    categoryId: 2,
    categoryName: 'Economy & Finance',
    categorySlug: 'economy-finance',
    userId: 8,
    author: INITIAL_USERS[7],
    title: 'The impact of AI on the UK job market',
    slug: 'impact-ai-uk-job-market',
    isPinned: false,
    isLocked: false,
    viewsCount: 10400,
    repliesCount: 198,
    lastPostUserId: 8,
    lastPostUser: INITIAL_USERS[7],
    lastPostTimeAgo: '4 hours ago',
    createdAt: '2026-10-30T19:50:00Z',
    timeAgo: '14 hours ago'
  },
  {
    id: 9,
    categoryId: 6,
    categoryName: 'Culture, Arts & Media',
    categorySlug: 'culture-arts-media',
    userId: 9,
    author: INITIAL_USERS[8],
    title: 'Best British pubs with real ale?',
    slug: 'best-british-pubs-real-ale',
    isPinned: false,
    isLocked: false,
    viewsCount: 5600,
    repliesCount: 87,
    lastPostUserId: 9,
    lastPostUser: INITIAL_USERS[8],
    lastPostTimeAgo: '5 hours ago',
    createdAt: '2026-10-30T17:50:00Z',
    timeAgo: '16 hours ago'
  },
  {
    id: 10,
    categoryId: 9,
    categoryName: 'Life, Travel & Outdoors',
    categorySlug: 'life-travel-outdoors',
    userId: 10,
    author: INITIAL_USERS[9],
    title: 'Wild camping in the Lake District – tips and advice',
    slug: 'wild-camping-lake-district-tips-advice',
    isPinned: false,
    isLocked: false,
    viewsCount: 7900,
    repliesCount: 124,
    lastPostUserId: 10,
    lastPostUser: INITIAL_USERS[9],
    lastPostTimeAgo: '6 hours ago',
    createdAt: '2026-10-30T15:50:00Z',
    timeAgo: '18 hours ago'
  }
];

const INITIAL_POSTS: Post[] = [
  {
    id: 1,
    threadId: 1,
    userId: 1,
    user: INITIAL_USERS[0],
    content: "Welcome to The British Forum!\n\nOur mission is to foster respectful, civil, and constructive debate regarding all aspects of life in the United Kingdom. Whether you are passionate about local heritage, national infrastructure, British engineering, arts, or economic renewal—you have a voice here.\n\nPlease take a moment to review our community guidelines:\n1. Treat fellow members with dignity and respect.\n2. Keep debates evidence-based and free of ad-hominem attacks.\n3. Celebrate the diversity of viewpoints from Scotland, Wales, Northern Ireland, and England alike.",
    isOriginalPost: true,
    likesCount: 384,
    likedByUserIds: [2, 3, 5, 6, 7],
    createdAt: '2024-01-01T12:00:00Z',
    timeAgo: '2 years ago'
  },
  {
    id: 2,
    threadId: 2,
    userId: 11,
    user: INITIAL_USERS[10],
    content: "With the continued decommissioning of aging coal and older AGR nuclear facilities, the United Kingdom faces an unprecedented baseload electricity challenge.\n\nWhile offshore wind in the Dogger Bank and North Sea provides incredible peak generation during blustery spells, 'dunkelflaute' periods remain a severe vulnerability. Should the UK government commit fully to Rolls-Royce Small Modular Reactors (SMRs) and Sizewell C, or can battery storage and green hydrogen bridge the intermittency gap?",
    isOriginalPost: true,
    likesCount: 52,
    likedByUserIds: [2, 8, 12],
    createdAt: '2026-10-31T06:50:00Z',
    timeAgo: '3 hours ago'
  },
  {
    id: 3,
    threadId: 2,
    userId: 2,
    user: INITIAL_USERS[1],
    content: "As someone who has worked alongside the Humber energy estuary for over 25 years, both are non-negotiable. SMRs offer modular deployment without the multi-decade budget overruns of massive gigawatt reactors. Pair that with tidal lagoon power along the Severn and Irish Sea, and Britain could become a net clean energy exporter.",
    isOriginalPost: false,
    likesCount: 29,
    likedByUserIds: [1, 11],
    createdAt: '2026-10-31T09:39:00Z',
    timeAgo: '13 minutes ago'
  },
  {
    id: 4,
    threadId: 3,
    userId: 12,
    user: INITIAL_USERS[11],
    content: "Looking across Greater London, Manchester, and Leeds, mortgage affordability ratios remain stretched well beyond historical averages. Are proposed planning reforms on brownfield development sufficient, or does the UK need substantial social housing construction reminiscent of the post-war era?",
    isOriginalPost: true,
    likesCount: 78,
    likedByUserIds: [3, 7, 9],
    createdAt: '2026-10-31T04:50:00Z',
    timeAgo: '5 hours ago'
  },
  {
    id: 5,
    threadId: 3,
    userId: 3,
    user: INITIAL_USERS[2],
    content: "Planning deregulation alone won't solve the shortage if speculative landbanking remains profitable. Local councils need statutory borrowing powers to build council estates directly with skilled local apprenticeships.",
    isOriginalPost: false,
    likesCount: 41,
    likedByUserIds: [1, 12],
    createdAt: '2026-10-31T09:24:00Z',
    timeAgo: '28 minutes ago'
  },
  {
    id: 6,
    threadId: 4,
    userId: 4,
    user: INITIAL_USERS[3],
    content: "Planning a family road trip around the British coastline next summer. We're weighing up St Ives & Falmouth in Cornwall, Tenby in Pembrokeshire, Whitby on the Yorkshire coast, and Crail in Fife. Where would you recommend for authentic fish and chips, historic harbor views, and scenic coastal paths?",
    isOriginalPost: true,
    likesCount: 33,
    likedByUserIds: [2, 9, 10],
    createdAt: '2026-10-31T02:50:00Z',
    timeAgo: '7 hours ago'
  },
  {
    id: 7,
    threadId: 4,
    userId: 2,
    user: INITIAL_USERS[1],
    content: "You cannot beat Whitby! Walk the 199 steps to the Abbey, get haddock & chips at Magpie Cafe, and take the North Yorkshire Moors Railway steam train up to Goathland. Unmatched British charm.",
    isOriginalPost: false,
    likesCount: 22,
    likedByUserIds: [4, 9],
    createdAt: '2026-10-31T08:52:00Z',
    timeAgo: '1 hour ago'
  }
];

class DatabaseService {
  private data: ForumDataStore;

  constructor() {
    this.data = this.loadData();
  }

  private loadData(): ForumDataStore {
    try {
      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (e) {
      console.warn('Could not load forum_store.json, creating initial store.', e);
    }

    const initial: ForumDataStore = {
      users: INITIAL_USERS,
      categories: INITIAL_CATEGORIES,
      threads: INITIAL_THREADS,
      posts: INITIAL_POSTS,
      stats: {
        members: 248732,
        threads: 52618,
        posts: 1942387,
        lastMember: 'YorkshireLad'
      }
    };

    this.saveData(initial);
    return initial;
  }

  private saveData(data: ForumDataStore): void {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to write forum_store.json', e);
    }
  }

  public getCategories(): Category[] {
    return this.data.categories;
  }

  public getCategoryBySlug(slug: string): Category | undefined {
    return this.data.categories.find(c => c.slug === slug);
  }

  public getThreads(options?: {
    categorySlug?: string;
    sort?: 'activity' | 'replies' | 'views' | 'newest';
    search?: string;
  }): Thread[] {
    let threads = [...this.data.threads];

    if (options?.categorySlug && options.categorySlug !== 'all') {
      threads = threads.filter(t => t.categorySlug === options.categorySlug);
    }

    if (options?.search) {
      const q = options.search.toLowerCase().trim();
      threads = threads.filter(t =>
        t.title.toLowerCase().includes(q) ||
        t.categoryName.toLowerCase().includes(q) ||
        t.author.displayName.toLowerCase().includes(q)
      );
    }

    const sort = options?.sort || 'activity';
    threads.sort((a, b) => {
      // Pinned threads stay at top
      if (a.isPinned !== b.isPinned) {
        return a.isPinned ? -1 : 1;
      }
      if (sort === 'replies') {
        return b.repliesCount - a.repliesCount;
      }
      if (sort === 'views') {
        return b.viewsCount - a.viewsCount;
      }
      if (sort === 'newest') {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
      // default: activity (newest created / last updated)
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

    return threads;
  }

  public getThreadById(id: number): Thread | undefined {
    const thread = this.data.threads.find(t => t.id === id);
    if (!thread) return undefined;

    // Attach posts
    const threadPosts = this.data.posts.filter(p => p.threadId === id);
    return {
      ...thread,
      posts: threadPosts
    };
  }

  public incrementViews(threadId: number): void {
    const thread = this.data.threads.find(t => t.id === threadId);
    if (thread) {
      thread.viewsCount += 1;
      this.saveData(this.data);
    }
  }

  public createThread(params: {
    title: string;
    categorySlug: string;
    content: string;
    userId: number;
  }): Thread {
    const user = this.data.users.find(u => u.id === params.userId) || this.data.users[0];
    const category = this.data.categories.find(c => c.slug === params.categorySlug) || this.data.categories[0];

    const threadId = this.data.threads.length > 0 ? Math.max(...this.data.threads.map(t => t.id)) + 1 : 1;
    const postId = this.data.posts.length > 0 ? Math.max(...this.data.posts.map(p => p.id)) + 1 : 1;

    const slug = params.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');

    const newThread: Thread = {
      id: threadId,
      categoryId: category.id,
      categoryName: category.name,
      categorySlug: category.slug,
      userId: user.id,
      author: user,
      title: params.title,
      slug,
      isPinned: false,
      isLocked: false,
      viewsCount: 1,
      repliesCount: 0,
      lastPostUserId: user.id,
      lastPostUser: user,
      lastPostTimeAgo: 'Just now',
      createdAt: new Date().toISOString(),
      timeAgo: 'Just now'
    };

    const firstPost: Post = {
      id: postId,
      threadId,
      userId: user.id,
      user,
      content: params.content,
      isOriginalPost: true,
      likesCount: 0,
      likedByUserIds: [],
      createdAt: new Date().toISOString(),
      timeAgo: 'Just now'
    };

    // Update stats
    category.threadCount += 1;
    category.postCount += 1;
    user.threadCount += 1;
    user.postCount += 1;
    this.data.stats.threads += 1;
    this.data.stats.posts += 1;

    this.data.threads.unshift(newThread);
    this.data.posts.push(firstPost);

    this.saveData(this.data);
    return newThread;
  }

  public addReply(params: {
    threadId: number;
    userId: number;
    content: string;
  }): Post | null {
    const thread = this.data.threads.find(t => t.id === params.threadId);
    if (!thread) return null;

    const user = this.data.users.find(u => u.id === params.userId) || this.data.users[0];
    const postId = this.data.posts.length > 0 ? Math.max(...this.data.posts.map(p => p.id)) + 1 : 1;

    const newPost: Post = {
      id: postId,
      threadId: thread.id,
      userId: user.id,
      user,
      content: params.content,
      isOriginalPost: false,
      likesCount: 0,
      likedByUserIds: [],
      createdAt: new Date().toISOString(),
      timeAgo: 'Just now'
    };

    thread.repliesCount += 1;
    thread.lastPostUserId = user.id;
    thread.lastPostUser = user;
    thread.lastPostTimeAgo = 'Just now';

    user.postCount += 1;
    this.data.stats.posts += 1;

    const cat = this.data.categories.find(c => c.id === thread.categoryId);
    if (cat) cat.postCount += 1;

    this.data.posts.push(newPost);
    this.saveData(this.data);
    return newPost;
  }

  public toggleLike(postId: number, userId: number): { likesCount: number; isLiked: boolean } | null {
    const post = this.data.posts.find(p => p.id === postId);
    if (!post) return null;

    const idx = post.likedByUserIds.indexOf(userId);
    let isLiked = false;
    if (idx > -1) {
      post.likedByUserIds.splice(idx, 1);
      post.likesCount = Math.max(0, post.likesCount - 1);
      isLiked = false;
    } else {
      post.likedByUserIds.push(userId);
      post.likesCount += 1;
      isLiked = true;
      // author gains reputation
      const author = this.data.users.find(u => u.id === post.userId);
      if (author) author.reputation += 10;
    }

    this.saveData(this.data);
    return { likesCount: post.likesCount, isLiked };
  }

  public getUserById(id: number): User | undefined {
    return this.data.users.find(u => u.id === id);
  }

  public getUserByUsernameOrEmail(identifier: string): User | undefined {
    const clean = identifier.toLowerCase().trim();
    return this.data.users.find(u =>
      u.username.toLowerCase() === clean || u.email.toLowerCase() === clean
    );
  }

  public createUser(params: {
    username: string;
    email: string;
    passwordHash: string;
    displayName: string;
    location?: string;
  }): User {
    const id = this.data.users.length > 0 ? Math.max(...this.data.users.map(u => u.id)) + 1 : 1;
    const initials = params.username.slice(0, 2).toUpperCase();

    const newUser: User = {
      id,
      username: params.username,
      email: params.email,
      passwordHash: params.passwordHash,
      displayName: params.displayName || params.username,
      role: 'member',
      avatarUrl: '',
      customTitle: 'New Member',
      location: params.location || 'United Kingdom',
      reputation: 10,
      postCount: 0,
      threadCount: 0,
      joinedAt: new Date().toISOString(),
      initials
    };

    this.data.users.push(newUser);
    this.data.stats.members += 1;
    this.data.stats.lastMember = newUser.displayName;

    this.saveData(this.data);
    return newUser;
  }

  public getStats(): CommunityStats {
    return this.data.stats;
  }

  public getLatestPosts(limit = 5): { id: number; title: string; category: string; timeAgo: string; userInitial: string; threadId: number }[] {
    return this.data.threads.slice(1, limit + 1).map(t => ({
      id: t.id,
      title: t.title,
      category: t.categoryName,
      timeAgo: t.lastPostTimeAgo,
      userInitial: t.lastPostUser.initials.charAt(0) || 'U',
      threadId: t.id
    }));
  }
}

// Global singleton instance
const globalForDb = global as unknown as { forumDbInstance?: DatabaseService };
export const db = globalForDb.forumDbInstance || new DatabaseService();
if (process.env.NODE_ENV !== 'production') globalForDb.forumDbInstance = db;
