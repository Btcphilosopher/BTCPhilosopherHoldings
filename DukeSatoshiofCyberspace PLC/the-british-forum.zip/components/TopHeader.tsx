'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Search, X, User as UserIcon, LogOut, Terminal, CheckCircle2 } from 'lucide-react';
import { CrownIcon } from './CrownIcon';
import type { User } from '@/lib/db';

interface TopHeaderProps {
  currentUser: User | null;
  onOpenAuth: (mode: 'login' | 'register') => void;
  onLogout: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenTech: () => void;
  onResetView: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  currentUser,
  onOpenAuth,
  onLogout,
  searchQuery,
  onSearchChange,
  onOpenTech,
  onResetView,
}) => {
  const [localSearch, setLocalSearch] = useState(searchQuery);

  const handleSubmitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchChange(localSearch);
  };

  const handleClear = () => {
    setLocalSearch('');
    onSearchChange('');
  };

  return (
    <header className="relative w-full overflow-hidden border-b border-slate-800/80 bg-[#081222] select-none">
      {/* Twilight Westminster Background Panorama */}
      <div className="absolute inset-0 z-0 opacity-40 mix-blend-luminosity hover:opacity-50 transition-opacity duration-700 pointer-events-none">
        <Image
          src="/images/header_banner.jpg"
          alt="Palace of Westminster and Big Ben at twilight"
          fill
          priority
          referrerPolicy="no-referrer"
          className="object-cover object-[center_35%]"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#060e1c] via-[#081324]/85 to-[#060e1c]/95" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#060e1c] via-transparent to-[#060e1c]/60" />
      </div>

      {/* Main Header Container */}
      <div className="relative z-10 max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Brand Lockup */}
        <button
          onClick={onResetView}
          className="flex items-center gap-3.5 text-left group transition-transform focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded-lg p-1"
        >
          <div className="p-1.5 rounded-lg bg-sky-950/40 border border-sky-800/40 group-hover:border-sky-500/50 transition-colors shadow-inner">
            <CrownIcon className="w-10 h-8 sm:w-12 sm:h-9 text-slate-100 group-hover:text-amber-300 transition-colors" />
          </div>
          <div>
            <h1
              className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-serif group-hover:text-sky-100 transition-colors"
              style={{ fontFamily: "'Cinzel', Georgia, serif" }}
            >
              The British Forum
            </h1>
            <p className="text-[10px] sm:text-[11px] font-semibold tracking-[0.22em] sm:tracking-[0.26em] text-sky-200/90 uppercase mt-0.5">
              DISCUSS · DEBATE · BUILD A BETTER BRITAIN
            </p>
          </div>
        </button>

        {/* Right Zone: Controls & Search */}
        <div className="flex flex-wrap items-center justify-end gap-3 w-full md:w-auto">
          {/* Tech Stack Badge / Inspector Button */}
          <button
            onClick={onOpenTech}
            title="Inspect real C99 Search, PHP 8 Engine, & MySQL Relational DB"
            className="hidden lg:flex items-center gap-2 px-2.5 py-1.5 rounded-md text-xs font-medium text-slate-300 bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 transition-colors"
          >
            <Terminal className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-slate-400">Backend:</span>
            <span className="text-sky-300 font-mono text-[11px]">C99 · PHP 8 · MySQL</span>
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
          </button>

          {/* Auth Controls */}
          {currentUser ? (
            <div className="flex items-center gap-2.5 bg-slate-900/90 border border-slate-700/80 rounded-lg px-3 py-1.5 shadow-sm">
              <div className="relative w-7 h-7 rounded-full overflow-hidden bg-sky-950 border border-sky-600/50 flex items-center justify-center text-xs font-bold text-sky-200">
                {currentUser.avatarUrl ? (
                  <Image
                    src={currentUser.avatarUrl}
                    alt={currentUser.displayName}
                    fill
                    referrerPolicy="no-referrer"
                    className="object-cover"
                  />
                ) : (
                  <span>{currentUser.initials}</span>
                )}
              </div>
              <div className="flex flex-col text-left">
                <span className="text-xs font-semibold text-slate-100 leading-tight">
                  {currentUser.displayName}
                </span>
                <span className="text-[10px] text-sky-400 font-medium">
                  {currentUser.customTitle}
                </span>
              </div>
              <button
                onClick={onLogout}
                title="Log out"
                className="ml-2 p-1 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-xs font-medium">
              <button
                onClick={() => onOpenAuth('login')}
                className="text-slate-200 hover:text-white px-2.5 py-1.5 rounded transition-colors"
              >
                Log in
              </button>
              <button
                onClick={() => onOpenAuth('register')}
                className="bg-sky-600 hover:bg-sky-500 text-white font-medium px-3 py-1.5 rounded-md transition-colors shadow-sm"
              >
                Sign up
              </button>
            </div>
          )}

          {/* Search Box */}
          <form onSubmit={handleSubmitSearch} className="relative w-full sm:w-60 md:w-64">
            <input
              type="text"
              value={localSearch}
              onChange={(e) => {
                setLocalSearch(e.target.value);
                onSearchChange(e.target.value);
              }}
              placeholder="Search the forum..."
              className="w-full bg-[#0c192d]/90 hover:bg-[#0f2038] focus:bg-[#0c192d] text-slate-100 placeholder-slate-400 text-xs rounded-md pl-8 pr-7 py-2 border border-slate-700/80 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5 pointer-events-none" />
            {localSearch && (
              <button
                type="button"
                onClick={handleClear}
                className="absolute right-2 top-2 text-slate-400 hover:text-slate-200 p-0.5"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </form>
        </div>
      </div>
    </header>
  );
};
