'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import {
  ArrowLeft,
  Pin,
  Heart,
  Quote,
  Send,
  Bold,
  Italic,
  Code,
  Link as LinkIcon,
  Crown,
  MapPin,
  Calendar,
  MessageSquare,
  Award,
} from 'lucide-react';
import type { Thread, Post, User } from '@/lib/db';

interface ThreadViewProps {
  thread: Thread;
  currentUser: User | null;
  onBack: () => void;
  onSelectCategorySlug: (slug: string) => void;
  onPostReply: (content: string) => Promise<void>;
  onToggleLike: (postId: number) => Promise<void>;
  onOpenAuth: () => void;
}

export const ThreadView: React.FC<ThreadViewProps> = ({
  thread,
  currentUser,
  onBack,
  onSelectCategorySlug,
  onPostReply,
  onToggleLike,
  onOpenAuth,
}) => {
  const [replyText, setReplyText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [activeLikeIds, setActiveLikeIds] = useState<number[]>([]);

  const handleInsertBBCode = (tag: string) => {
    if (tag === 'quote') {
      setReplyText((prev) => prev + `[quote]Quote text here[/quote]\n`);
    } else if (tag === 'b') {
      setReplyText((prev) => prev + `[b]bold text[/b]`);
    } else if (tag === 'i') {
      setReplyText((prev) => prev + `[i]italic text[/i]`);
    } else if (tag === 'code') {
      setReplyText((prev) => prev + `[code]\n// code snippet\n[/code]\n`);
    } else if (tag === 'url') {
      setReplyText((prev) => prev + `[url=https://example.co.uk]Link text[/url]`);
    }
  };

  const handleQuotePost = (post: Post) => {
    const quoteBlock = `[quote=${post.user.displayName}]${post.content.slice(0, 200)}${post.content.length > 200 ? '...' : ''}[/quote]\n`;
    setReplyText((prev) => prev + quoteBlock);
    // Smooth scroll down to reply box
    const el = document.getElementById('reply-composer');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSubmitReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (!replyText.trim() || submitting) return;

    try {
      setSubmitting(true);
      await onPostReply(replyText.trim());
      setReplyText('');
    } finally {
      setSubmitting(false);
    }
  };

  const handleLikeClick = async (postId: number) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    setActiveLikeIds((prev) =>
      prev.includes(postId) ? prev.filter((id) => id !== postId) : [...prev, postId]
    );
    await onToggleLike(postId);
  };

  return (
    <div className="flex-1 min-w-0 space-y-4">
      {/* Top Breadcrumb & Back Bar */}
      <div className="bg-[#0b1526] rounded-xl border border-slate-800/80 p-4 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-700/80 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Discussions</span>
          </button>
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <button
              onClick={() => onSelectCategorySlug(thread.categorySlug)}
              className="text-sky-400 hover:underline font-medium"
            >
              {thread.categoryName}
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span>Views: <strong className="text-slate-200">{thread.viewsCount}</strong></span>
          <span className="text-slate-600">·</span>
          <span>Replies: <strong className="text-slate-200">{thread.repliesCount}</strong></span>
        </div>
      </div>

      {/* Thread Title Header */}
      <div className="bg-[#0c182c] rounded-xl border border-slate-800/80 p-5 shadow-sm">
        <div className="flex items-center gap-2 flex-wrap mb-1">
          {thread.isPinned && (
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-400 bg-amber-950/60 border border-amber-800/60 px-2 py-0.5 rounded">
              <Pin className="w-3.5 h-3.5 fill-amber-400" />
              <span>Pinned Discussion</span>
            </span>
          )}
          <span className="text-xs text-slate-400">
            Started by <span className="text-slate-200 font-semibold">{thread.author.displayName}</span> · {thread.timeAgo}
          </span>
        </div>
        <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
          {thread.title}
        </h1>
      </div>

      {/* Posts Stream */}
      <div className="space-y-4">
        {thread.posts?.map((post, index) => {
          const isUserLiked =
            (currentUser && post.likedByUserIds.includes(currentUser.id)) ||
            activeLikeIds.includes(post.id);

          return (
            <div
              key={post.id}
              className="bg-[#0b1526] rounded-xl border border-slate-800/80 shadow-sm overflow-hidden flex flex-col md:flex-row"
            >
              {/* Author Column */}
              <div className="w-full md:w-56 bg-[#091220]/90 p-4 border-b md:border-b-0 md:border-r border-slate-800/80 shrink-0 text-center md:text-left flex flex-row md:flex-col items-center md:items-start justify-between md:justify-start gap-3">
                <div className="flex items-center md:flex-col md:items-center gap-3 w-full">
                  {/* User Avatar */}
                  <div className="relative w-14 h-14 rounded-full overflow-hidden bg-slate-800 border-2 border-slate-700/80 flex items-center justify-center font-bold text-lg text-slate-200 shrink-0">
                    {post.user.avatarUrl ? (
                      <Image
                        src={post.user.avatarUrl}
                        alt={post.user.displayName}
                        fill
                        referrerPolicy="no-referrer"
                        className="object-cover"
                      />
                    ) : (
                      <span>{post.user.initials}</span>
                    )}
                  </div>

                  <div className="text-left md:text-center min-w-0">
                    <div className="font-bold text-sm text-slate-100 flex items-center justify-center gap-1">
                      {post.user.role === 'admin' && (
                        <Crown className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      )}
                      <span>{post.user.displayName}</span>
                    </div>
                    <div className="text-[11px] font-semibold text-sky-400 mt-0.5">
                      {post.user.customTitle}
                    </div>
                  </div>
                </div>

                {/* Author Stats */}
                <div className="hidden md:block w-full mt-3 pt-3 border-t border-slate-800/70 text-[11px] text-slate-400 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1 text-slate-400">
                      <Award className="w-3 h-3 text-amber-400" />
                      <span>Reputation</span>
                    </span>
                    <span className="font-semibold text-slate-200 tabular-nums">
                      {post.user.reputation}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1 text-slate-400">
                      <MessageSquare className="w-3 h-3 text-slate-400" />
                      <span>Posts</span>
                    </span>
                    <span className="font-semibold text-slate-200 tabular-nums">
                      {post.user.postCount}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1 text-slate-400">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      <span>Location</span>
                    </span>
                    <span className="font-medium text-slate-300 truncate max-w-[90px]">
                      {post.user.location}
                    </span>
                  </div>
                </div>
              </div>

              {/* Post Content Column */}
              <div className="flex-1 p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 pb-3 border-b border-slate-800/60 mb-4">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>Posted {post.timeAgo}</span>
                    </div>
                    <span className="font-mono text-[11px] text-slate-400">
                      #{index + 1}
                    </span>
                  </div>

                  {/* Rendered content */}
                  <div className="text-sm leading-relaxed text-slate-200 whitespace-pre-line space-y-3 font-sans">
                    {post.content}
                  </div>
                </div>

                {/* Post Footer Actions */}
                <div className="mt-6 pt-3.5 border-t border-slate-800/60 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleLikeClick(post.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        isUserLiked
                          ? 'bg-rose-950/70 text-rose-300 border border-rose-800/60'
                          : 'bg-slate-900 hover:bg-slate-850 text-slate-300 border border-slate-800'
                      }`}
                    >
                      <Heart
                        className={`w-3.5 h-3.5 ${
                          isUserLiked ? 'fill-rose-400 text-rose-400' : 'text-slate-400'
                        }`}
                      />
                      <span>{post.likesCount} {post.likesCount === 1 ? 'Like' : 'Likes'}</span>
                    </button>
                  </div>

                  <button
                    onClick={() => handleQuotePost(post)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 text-slate-300 border border-slate-800 transition-colors"
                  >
                    <Quote className="w-3.5 h-3.5 text-slate-400" />
                    <span>Quote</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Reply Composer Box */}
      <div id="reply-composer" className="bg-[#0b1526] rounded-xl border border-slate-800/80 p-5 shadow-sm">
        <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-sky-400" />
          <span>Post a Reply</span>
        </h3>

        {currentUser ? (
          <form onSubmit={handleSubmitReply} className="space-y-3">
            {/* Formatting Toolbar */}
            <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg border border-slate-800 text-xs text-slate-300">
              <button
                type="button"
                onClick={() => handleInsertBBCode('b')}
                className="p-1.5 hover:bg-slate-800 rounded transition-colors"
                title="Bold"
              >
                <Bold className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => handleInsertBBCode('i')}
                className="p-1.5 hover:bg-slate-800 rounded transition-colors"
                title="Italic"
              >
                <Italic className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => handleInsertBBCode('quote')}
                className="p-1.5 hover:bg-slate-800 rounded transition-colors"
                title="Quote"
              >
                <Quote className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => handleInsertBBCode('code')}
                className="p-1.5 hover:bg-slate-800 rounded transition-colors"
                title="Code"
              >
                <Code className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => handleInsertBBCode('url')}
                className="p-1.5 hover:bg-slate-800 rounded transition-colors"
                title="Link"
              >
                <LinkIcon className="w-3.5 h-3.5" />
              </button>
              <span className="text-[10px] text-slate-400 ml-auto pr-2">
                Processed via PHP 8 BBCode Parser
              </span>
            </div>

            <textarea
              rows={4}
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              placeholder="Write your respectful, constructive contribution to this discussion..."
              className="w-full bg-[#081220] text-slate-100 placeholder-slate-400 text-sm rounded-lg p-3 border border-slate-700/80 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            />

            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400">
                Posting as <strong className="text-sky-300">{currentUser.displayName}</strong>
              </span>

              <button
                type="submit"
                disabled={submitting || !replyText.trim()}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-xs font-semibold shadow transition-all"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{submitting ? 'Posting...' : 'Post Reply'}</span>
              </button>
            </div>
          </form>
        ) : (
          <div className="p-4 bg-slate-900/80 rounded-lg border border-slate-800 text-center">
            <p className="text-xs text-slate-300 mb-3">
              You must be logged in to participate in debates and reply to this discussion.
            </p>
            <button
              onClick={onOpenAuth}
              className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold transition-colors"
            >
              Log in to Reply
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
