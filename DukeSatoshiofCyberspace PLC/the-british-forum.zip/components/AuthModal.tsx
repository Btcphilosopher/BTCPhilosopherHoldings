'use client';

import React, { useState } from 'react';
import { X, Lock, UserPlus, LogIn, Crown, ShieldCheck } from 'lucide-react';
import type { User } from '@/lib/db';

interface AuthModalProps {
  isOpen: boolean;
  initialMode: 'login' | 'register';
  onClose: () => void;
  onSuccess: (user: User, token: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode,
  onClose,
  onSuccess,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [usernameOrEmail, setUsernameOrEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [location, setLocation] = useState('United Kingdom');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!usernameOrEmail.trim() || !password) {
      setError('Please enter both your username/email and password');
      return;
    }

    try {
      setLoading(true);
      setError('');
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ usernameOrEmail: usernameOrEmail.trim(), password }),
      });
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to login');
      }
      onSuccess(data.user, data.token);
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Login failed';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !email.trim() || !password) {
      setError('Please fill in all required fields');
      return;
    }

    try {
      setLoading(true);
      setError('');
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: username.trim(),
          email: email.trim(),
          displayName: displayName.trim() || username.trim(),
          password,
          location: location.trim(),
        }),
      });
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Registration failed');
      }
      onSuccess(data.user, data.token);
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Registration failed';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemoLogin = (userLogin: string) => {
    setUsernameOrEmail(userLogin);
    setPassword('DemoPassword123!');
    setTimeout(() => {
      fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ usernameOrEmail: userLogin, password: 'DemoPassword123!' }),
      })
        .then((r) => r.json())
        .then((data) => {
          if (data.success) {
            onSuccess(data.user, data.token);
            onClose();
          }
        });
    }, 50);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#0b162a] border border-slate-700/80 rounded-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-[#0d1c33]">
          <div className="flex items-center gap-2 text-white font-bold text-base">
            {mode === 'login' ? (
              <>
                <LogIn className="w-4 h-4 text-sky-400" />
                <span>Log in to The British Forum</span>
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4 text-emerald-400" />
                <span>Join The British Forum</span>
              </>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5 space-y-4">
          {error && (
            <div className="p-3 bg-rose-950/70 border border-rose-800 text-rose-200 text-xs rounded-lg">
              {error}
            </div>
          )}

          {/* Quick Demo Logins Bar */}
          <div className="p-2.5 bg-slate-900/90 rounded-lg border border-slate-800 space-y-1.5">
            <div className="text-[11px] font-semibold text-slate-400 flex items-center justify-between">
              <span>Quick 1-Click Demo Accounts:</span>
              <span className="text-[10px] text-emerald-400 font-mono">PHP & MySQL Auth</span>
            </div>
            <div className="grid grid-cols-3 gap-1.5 text-xs">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('Admin')}
                className="flex items-center justify-center gap-1 py-1.5 px-2 bg-amber-950/60 hover:bg-amber-900/70 text-amber-300 border border-amber-800/60 rounded text-[11px] font-medium transition-colors"
              >
                <Crown className="w-3 h-3 text-amber-400" />
                <span>Admin</span>
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('YorkshireLad')}
                className="flex items-center justify-center gap-1 py-1.5 px-2 bg-sky-950/60 hover:bg-sky-900/70 text-sky-300 border border-sky-800/60 rounded text-[11px] font-medium transition-colors"
              >
                <span>YorkshireLad</span>
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('Londoner1987')}
                className="flex items-center justify-center gap-1 py-1.5 px-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded text-[11px] font-medium transition-colors"
              >
                <span>Londoner</span>
              </button>
            </div>
          </div>

          {mode === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Username or Email
                </label>
                <input
                  type="text"
                  value={usernameOrEmail}
                  onChange={(e) => setUsernameOrEmail(e.target.value)}
                  placeholder="e.g. Admin or admin@britishforum.co.uk"
                  className="w-full bg-[#081220] border border-slate-700 text-slate-100 text-sm rounded-lg p-2.5 focus:border-sky-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-[#081220] border border-slate-700 text-slate-100 text-sm rounded-lg p-2.5 focus:border-sky-500 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs rounded-lg shadow transition-colors mt-2"
              >
                {loading ? 'Authenticating...' : 'Sign In'}
              </button>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-2.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Username
                </label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. HighlandWanderer"
                  className="w-full bg-[#081220] border border-slate-700 text-slate-100 text-sm rounded-lg p-2 focus:border-sky-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@domain.co.uk"
                  className="w-full bg-[#081220] border border-slate-700 text-slate-100 text-sm rounded-lg p-2 focus:border-sky-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Display Name
                </label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Optional public title"
                  className="w-full bg-[#081220] border border-slate-700 text-slate-100 text-sm rounded-lg p-2 focus:border-sky-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Location (UK Region)
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Edinburgh, Scotland / Devon / Cornwall"
                  className="w-full bg-[#081220] border border-slate-700 text-slate-100 text-sm rounded-lg p-2 focus:border-sky-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 6 characters"
                  className="w-full bg-[#081220] border border-slate-700 text-slate-100 text-sm rounded-lg p-2 focus:border-sky-500 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs rounded-lg shadow transition-colors mt-2"
              >
                {loading ? 'Creating Account...' : 'Complete Registration'}
              </button>
            </form>
          )}

          {/* Toggle Mode */}
          <div className="pt-2 text-center text-xs text-slate-400">
            {mode === 'login' ? (
              <p>
                Don&apos;t have an account?{' '}
                <button
                  type="button"
                  onClick={() => setMode('register')}
                  className="text-sky-400 hover:underline font-semibold"
                >
                  Sign up now
                </button>
              </p>
            ) : (
              <p>
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className="text-sky-400 hover:underline font-semibold"
                >
                  Log in
                </button>
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
