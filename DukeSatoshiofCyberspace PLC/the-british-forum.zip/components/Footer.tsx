'use client';

import React from 'react';
import { CrownIcon } from './CrownIcon';
import { Rss } from 'lucide-react';

interface FooterProps {
  onNavClick: (tab: string) => void;
  onOpenTech: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavClick, onOpenTech }) => {
  return (
    <footer className="w-full bg-[#050b14] border-t border-slate-800/90 text-slate-400 text-xs py-8 mt-12 select-none">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Brand lockup */}
          <div className="flex items-center gap-3">
            <div className="p-1 rounded bg-sky-950/50 border border-sky-800/40">
              <CrownIcon className="w-6 h-5 text-slate-200" />
            </div>
            <span
              className="text-lg font-bold text-slate-100 font-serif"
              style={{ fontFamily: "'Cinzel', Georgia, serif" }}
            >
              The British Forum
            </span>
          </div>

          {/* Nav links */}
          <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-xs font-medium text-slate-400">
            <button
              onClick={() => onNavClick('home')}
              className="hover:text-white transition-colors"
            >
              Home
            </button>
            <button
              onClick={() => onNavClick('forums')}
              className="hover:text-white transition-colors"
            >
              Forums
            </button>
            <button
              onClick={() => onNavClick('whats-new')}
              className="hover:text-white transition-colors"
            >
              What&apos;s New
            </button>
            <button
              onClick={() => onNavClick('members')}
              className="hover:text-white transition-colors"
            >
              Members
            </button>
            <button
              onClick={() => onNavClick('help')}
              className="hover:text-white transition-colors"
            >
              Help
            </button>
            <button
              onClick={onOpenTech}
              className="hover:text-emerald-400 transition-colors text-emerald-500 font-mono"
            >
              Backend / DB
            </button>
            <span className="hover:text-white transition-colors cursor-pointer">Contact</span>
            <span className="hover:text-white transition-colors cursor-pointer">Terms</span>
            <span className="hover:text-white transition-colors cursor-pointer">Privacy</span>
          </div>

          {/* Social Icons & Motto */}
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <div className="flex items-center gap-3 text-slate-400">
              {/* X icon */}
              <button
                className="hover:text-white transition-colors p-1"
                aria-label="X Twitter"
                title="X (Twitter)"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              </button>
              {/* Facebook icon */}
              <button
                className="hover:text-white transition-colors p-1"
                aria-label="Facebook"
                title="Facebook"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
              </button>
              {/* YouTube icon */}
              <button
                className="hover:text-white transition-colors p-1"
                aria-label="YouTube"
                title="YouTube"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                </svg>
              </button>
              {/* RSS icon */}
              <button
                className="hover:text-white transition-colors p-1"
                aria-label="RSS Feed"
                title="RSS Feed"
              >
                <Rss className="w-4 h-4" />
              </button>
            </div>

            <span className="text-[11px] text-slate-400 italic">
              For a stronger, kinder, more prosperous Britain.
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
