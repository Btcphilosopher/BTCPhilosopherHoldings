'use client';

import React from 'react';
import Image from 'next/image';
import { Users, MessageSquare, MessageCircle, ArrowRight } from 'lucide-react';
import type { CommunityStats } from '@/lib/db';

interface LatestPostItem {
  id: number;
  title: string;
  category: string;
  timeAgo: string;
  userInitial: string;
  threadId: number;
}

interface RightSidebarProps {
  stats: CommunityStats;
  latestPosts: LatestPostItem[];
  onSelectThread: (threadId: number) => void;
  onJoinClick: () => void;
}

const INITIAL_COLORS: Record<string, string> = {
  Y: 'bg-blue-900/70 text-blue-200 border-blue-700/60',
  F: 'bg-purple-900/70 text-purple-200 border-purple-700/60',
  G: 'bg-rose-900/70 text-rose-200 border-rose-700/60',
  W: 'bg-amber-900/70 text-amber-200 border-amber-700/60',
  A: 'bg-emerald-900/70 text-emerald-200 border-emerald-700/60',
  C: 'bg-teal-900/70 text-teal-200 border-teal-700/60',
};

export const RightSidebar: React.FC<RightSidebarProps> = ({
  stats,
  latestPosts,
  onSelectThread,
  onJoinClick,
}) => {
  return (
    <aside className="w-full lg:w-80 shrink-0 space-y-4">
      {/* 1. Latest Posts Widget */}
      <div className="bg-[#0b1526] rounded-xl border border-slate-800/80 p-3.5 shadow-sm">
        <h2 className="text-xs font-bold tracking-wider text-slate-300 uppercase px-1 pb-2.5 mb-1 border-b border-slate-800/70">
          Latest Posts
        </h2>
        <div className="space-y-1">
          {latestPosts.map((post) => {
            const initial = post.userInitial.toUpperCase();
            const colorClass = INITIAL_COLORS[initial] || 'bg-slate-800 text-slate-200 border-slate-700';

            return (
              <button
                key={post.id}
                onClick={() => onSelectThread(post.threadId)}
                className="w-full flex items-start gap-2.5 p-2 rounded-lg text-left hover:bg-slate-900/80 transition-colors group"
              >
                <div
                  className={`w-7 h-7 rounded-md flex items-center justify-center font-bold text-xs shrink-0 border mt-0.5 ${colorClass}`}
                >
                  {initial}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-semibold text-slate-200 group-hover:text-sky-300 transition-colors truncate">
                    {post.title}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5 truncate">
                    <span>{post.category}</span>
                    <span className="mx-1 text-slate-400">·</span>
                    <span>{post.timeAgo}</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Community Statistics Widget */}
      <div className="bg-[#0b1526] rounded-xl border border-slate-800/80 p-4 shadow-sm">
        <h2 className="text-xs font-bold tracking-wider text-slate-300 uppercase pb-3 border-b border-slate-800/70">
          Community Statistics
        </h2>
        <div className="mt-3.5 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-400">
              <Users className="w-4 h-4 text-slate-400" />
              <span>Members</span>
            </div>
            <span className="font-bold text-slate-200 tabular-nums">
              {stats.members.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-400">
              <MessageSquare className="w-4 h-4 text-slate-400" />
              <span>Threads</span>
            </div>
            <span className="font-bold text-slate-200 tabular-nums">
              {stats.threads.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-400">
              <MessageCircle className="w-4 h-4 text-slate-400" />
              <span>Posts</span>
            </div>
            <span className="font-bold text-slate-200 tabular-nums">
              {stats.posts.toLocaleString()}
            </span>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-800/60 text-[11px] text-slate-400">
          <span>Last member: </span>
          <span className="font-semibold text-sky-400">{stats.lastMember}</span>
        </div>
      </div>

      {/* 3. Promotional Join Community Card */}
      <div className="relative rounded-xl overflow-hidden border border-slate-800 shadow-lg min-h-[200px] flex flex-col justify-end p-5 group">
        <div className="absolute inset-0 z-0">
          <Image
            src="/images/countryside_promo.jpg"
            alt="Scenic British rolling countryside"
            fill
            referrerPolicy="no-referrer"
            className="object-cover group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#060d18] via-[#091526]/80 to-transparent" />
        </div>

        <div className="relative z-10">
          <h3 className="text-base sm:text-lg font-bold text-white leading-snug drop-shadow-md">
            Real people. Real conversations. A stronger Britain.
          </h3>
          <button
            onClick={onJoinClick}
            className="mt-3.5 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition-all active:scale-[0.98]"
          >
            <span>Join the community</span>
            <ArrowRight className="w-3.5 h-3.5 stroke-[2.5]" />
          </button>
        </div>
      </div>
    </aside>
  );
};
