'use client';

import React, { useState } from 'react';
import { X, Terminal, Cpu, Database, Play, CheckCircle2, RefreshCw } from 'lucide-react';

interface TechArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TechArchitectureModal: React.FC<TechArchitectureModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'c_engine' | 'php_backend' | 'mysql'>('c_engine');

  // C Engine state
  const [cQuery, setCQuery] = useState('energy');
  const [cResult, setCResult] = useState<Record<string, unknown> | null>(null);
  const [cLoading, setCLoading] = useState(false);

  // PHP Backend state
  const [phpAction, setPhpAction] = useState<'parse_bbcode' | 'hash' | 'status'>('parse_bbcode');
  const [phpInput, setPhpInput] = useState('[b]British Forum Discussion[/b]\n[quote=Admin]Build a better Britain[/quote]');
  const [phpResult, setPhpResult] = useState<Record<string, unknown> | null>(null);
  const [phpLoading, setPhpLoading] = useState(false);

  // MySQL state
  const [sqlQuery, setSqlQuery] = useState('SELECT * FROM users LIMIT 5');
  const [sqlResult, setSqlResult] = useState<{ columns?: string[]; rows?: (string | number)[][]; executionTimeMs?: number } | null>(null);
  const [sqlLoading, setSqlLoading] = useState(false);

  if (!isOpen) return null;

  const runCEngine = async () => {
    try {
      setCLoading(true);
      const res = await fetch('/api/c-engine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: cQuery }),
      });
      const data = await res.json();
      setCResult(data);
    } catch (err: unknown) {
      setCResult({ error: String(err) });
    } finally {
      setCLoading(false);
    }
  };

  const runPHPBackend = async () => {
    try {
      setPhpLoading(true);
      const res = await fetch('/api/php-backend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: phpAction, text: phpInput, password: 'UserSecretPassword99!' }),
      });
      const data = await res.json();
      setPhpResult(data);
    } catch (err: unknown) {
      setPhpResult({ error: String(err) });
    } finally {
      setPhpLoading(false);
    }
  };

  const runSQLQuery = async () => {
    try {
      setSqlLoading(true);
      const res = await fetch('/api/sql-console', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: sqlQuery }),
      });
      const data = await res.json();
      setSqlResult(data);
    } catch (err: unknown) {
      setSqlResult({ columns: ['Error'], rows: [[String(err)]] });
    } finally {
      setSqlLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-[#091322] border border-slate-700/80 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-[#0c182b] shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-md bg-emerald-950/60 border border-emerald-700/50 text-emerald-400">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                <span>The British Forum Backend & Database Console</span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/70 border border-emerald-800/60 px-1.5 py-0.5 rounded">
                  ONLINE
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Native C99 Search · PHP 8 Engine · Next.js · MySQL Relational DDL
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-slate-800 bg-[#08101d] px-4 pt-2 gap-2 shrink-0">
          <button
            onClick={() => setActiveTab('c_engine')}
            className={`flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-t-lg transition-colors border-t border-x ${
              activeTab === 'c_engine'
                ? 'bg-[#091322] text-sky-400 border-slate-700 border-b-transparent'
                : 'text-slate-400 hover:text-slate-200 border-transparent'
            }`}
          >
            <Cpu className="w-3.5 h-3.5 text-sky-400" />
            <span>C99 Native Search Engine</span>
          </button>

          <button
            onClick={() => setActiveTab('php_backend')}
            className={`flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-t-lg transition-colors border-t border-x ${
              activeTab === 'php_backend'
                ? 'bg-[#091322] text-amber-400 border-slate-700 border-b-transparent'
                : 'text-slate-400 hover:text-slate-200 border-transparent'
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-amber-400" />
            <span>PHP 8 Auth & BBCode</span>
          </button>

          <button
            onClick={() => setActiveTab('mysql')}
            className={`flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-t-lg transition-colors border-t border-x ${
              activeTab === 'mysql'
                ? 'bg-[#091322] text-emerald-400 border-slate-700 border-b-transparent'
                : 'text-slate-400 hover:text-slate-200 border-transparent'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span>MySQL 8.0 Relational DB</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* TAB 1: C99 Engine */}
          {activeTab === 'c_engine' && (
            <div className="space-y-4">
              <div className="p-3 bg-slate-900/80 rounded-lg border border-slate-800 text-xs text-slate-300">
                <div className="font-semibold text-sky-300 mb-1 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Compiled C Binary: /bin/forum_engine (GCC -O3 std=c99)</span>
                </div>
                The C binary parses British English search queries, applies stopword stripping, computes log10 engagement factors, and calculates decay-weighted ranking in microseconds.
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={cQuery}
                  onChange={(e) => setCQuery(e.target.value)}
                  placeholder="Enter search keyword e.g. energy, housing, Lake District"
                  className="flex-1 bg-[#060c16] border border-slate-700 text-slate-100 text-xs rounded-lg px-3 py-2 focus:border-sky-500 focus:outline-none"
                />
                <button
                  onClick={runCEngine}
                  disabled={cLoading}
                  className="flex items-center gap-1.5 px-4 py-2 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-colors"
                >
                  {cLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                  <span>Execute C Binary</span>
                </button>
              </div>

              {cResult && (
                <div className="bg-[#050a12] p-3 rounded-lg border border-slate-800 font-mono text-xs text-sky-300 overflow-x-auto">
                  <pre>{JSON.stringify(cResult, null, 2)}</pre>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: PHP 8 Backend */}
          {activeTab === 'php_backend' && (
            <div className="space-y-4">
              <div className="p-3 bg-slate-900/80 rounded-lg border border-slate-800 text-xs text-slate-300">
                <div className="font-semibold text-amber-300 mb-1 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>PHP 8.2 CLI Engine: /php_backend/auth.php & bbcode_parser.php</span>
                </div>
                Runs real PHP scripts for password encryption using standard Bcrypt (`password_hash`), session validation, and BBCode to sanitized HTML parsing.
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setPhpAction('parse_bbcode')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md ${
                    phpAction === 'parse_bbcode' ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  BBCode Parser
                </button>
                <button
                  onClick={() => setPhpAction('hash')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md ${
                    phpAction === 'hash' ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  Password Hash (Bcrypt)
                </button>
                <button
                  onClick={() => setPhpAction('status')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md ${
                    phpAction === 'status' ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  PHP Engine Status
                </button>
              </div>

              {phpAction === 'parse_bbcode' && (
                <textarea
                  rows={3}
                  value={phpInput}
                  onChange={(e) => setPhpInput(e.target.value)}
                  className="w-full bg-[#060c16] border border-slate-700 text-slate-100 text-xs rounded-lg p-2.5 font-mono"
                />
              )}

              <button
                onClick={runPHPBackend}
                disabled={phpLoading}
                className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-colors"
              >
                {phpLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                <span>Execute PHP Script</span>
              </button>

              {phpResult && (
                <div className="bg-[#050a12] p-3 rounded-lg border border-slate-800 font-mono text-xs text-amber-300 overflow-x-auto">
                  <pre>{JSON.stringify(phpResult, null, 2)}</pre>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: MySQL Relational DB */}
          {activeTab === 'mysql' && (
            <div className="space-y-4">
              <div className="p-3 bg-slate-900/80 rounded-lg border border-slate-800 text-xs text-slate-300">
                <div className="font-semibold text-emerald-300 mb-1 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>MySQL 8.0 Schema DDL: /db/schema.sql</span>
                </div>
                Relational schema with InnoDB engine, utf8mb4 encoding, foreign keys (`fk_threads_user`, `fk_posts_thread`), and indexed lookup fields.
              </div>

              <div className="flex flex-wrap gap-1.5 text-xs">
                <button
                  onClick={() => setSqlQuery('SHOW TABLES')}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded font-mono text-[11px]"
                >
                  SHOW TABLES
                </button>
                <button
                  onClick={() => setSqlQuery('SELECT * FROM users LIMIT 5')}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded font-mono text-[11px]"
                >
                  SELECT * FROM users
                </button>
                <button
                  onClick={() => setSqlQuery('SELECT * FROM threads LIMIT 5')}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded font-mono text-[11px]"
                >
                  SELECT * FROM threads
                </button>
                <button
                  onClick={() => setSqlQuery('SELECT * FROM categories')}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded font-mono text-[11px]"
                >
                  SELECT * FROM categories
                </button>
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={sqlQuery}
                  onChange={(e) => setSqlQuery(e.target.value)}
                  className="flex-1 bg-[#060c16] border border-slate-700 text-slate-100 text-xs rounded-lg px-3 py-2 font-mono"
                />
                <button
                  onClick={runSQLQuery}
                  disabled={sqlLoading}
                  className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-colors"
                >
                  {sqlLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                  <span>Run Query</span>
                </button>
              </div>

              {sqlResult && (
                <div className="bg-[#050a12] rounded-lg border border-slate-800 overflow-x-auto">
                  <div className="px-3 py-2 bg-slate-900 border-b border-slate-800 text-[11px] font-mono text-slate-400 flex justify-between">
                    <span>Query: {sqlQuery}</span>
                    <span className="text-emerald-400">{sqlResult.executionTimeMs} ms</span>
                  </div>
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <tr>
                        {sqlResult.columns?.map((col, idx) => (
                          <th key={idx} className="p-2 font-semibold">
                            {col}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850 text-slate-300">
                      {sqlResult.rows?.map((row, rIdx) => (
                        <tr key={rIdx} className="hover:bg-slate-900/60">
                          {row.map((val, cIdx) => (
                            <td key={cIdx} className="p-2 whitespace-nowrap">
                              {String(val ?? 'NULL')}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
