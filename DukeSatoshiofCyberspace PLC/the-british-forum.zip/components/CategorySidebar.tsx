'use client';

import React from 'react';
import {
  Landmark,
  TrendingUp,
  Cpu,
  Leaf,
  Building2,
  Palette,
  Trophy,
  Gamepad2,
  Mountain,
  MapPin,
  MessageCircle,
  ChevronRight,
  Layers,
} from 'lucide-react';
import type { Category } from '@/lib/db';

interface CategorySidebarProps {
  categories: Category[];
  selectedCategorySlug: string;
  onSelectCategory: (slug: string) => void;
}

const ICON_MAP: Record<string, React.ElementType> = {
  Landmark,
  TrendingUp,
  Cpu,
  Leaf,
  Building2,
  Palette,
  Trophy,
  Gamepad2,
  Mountain,
  MapPin,
  MessageCircle,
};

function formatCount(num: number): string {
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'k';
  }
  return num.toString();
}

export const CategorySidebar: React.FC<CategorySidebarProps> = ({
  categories,
  selectedCategorySlug,
  onSelectCategory,
}) => {
  return (
    <aside className="w-full lg:w-72 shrink-0">
      <div className="bg-[#0b1526] rounded-xl border border-slate-800/80 p-3.5 shadow-sm">
        <div className="flex items-center justify-between px-2 pb-2.5 mb-1 border-b border-slate-800/70">
          <h2 className="text-[11px] font-bold tracking-wider text-slate-400 uppercase">
            Forum Categories
          </h2>
          <span className="text-[10px] text-slate-400 font-medium">
            {categories.length} Sections
          </span>
        </div>

        {/* All Discussions Option */}
        <button
          onClick={() => onSelectCategory('all')}
          className={`w-full flex items-center justify-between p-2 rounded-lg text-left transition-colors mb-1 group ${
            selectedCategorySlug === 'all'
              ? 'bg-sky-950/70 text-sky-200 border border-sky-800/50'
              : 'text-slate-300 hover:bg-slate-900/80 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className={`p-1.5 rounded-md ${selectedCategorySlug === 'all' ? 'bg-sky-600 text-white' : 'bg-slate-800 text-slate-400 group-hover:text-slate-200'}`}>
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-semibold">All Discussions</div>
              <div className="text-[11px] text-slate-400">All forum categories</div>
            </div>
          </div>
          <ChevronRight className={`w-3.5 h-3.5 ${selectedCategorySlug === 'all' ? 'text-sky-400' : 'text-slate-400 group-hover:text-slate-400'}`} />
        </button>

        {/* Categories List */}
        <div className="space-y-0.5">
          {categories.map((category) => {
            const IconComponent = ICON_MAP[category.iconName] || MessageCircle;
            const isSelected = selectedCategorySlug === category.slug;

            return (
              <button
                key={category.id}
                onClick={() => onSelectCategory(category.slug)}
                className={`w-full flex items-center justify-between p-2 rounded-lg text-left transition-colors group ${
                  isSelected
                    ? 'bg-sky-950/80 text-sky-100 border border-sky-800/60 shadow-sm'
                    : 'text-slate-300 hover:bg-slate-900/70 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0 pr-2">
                  <div
                    className={`p-1.5 rounded-md shrink-0 transition-colors ${
                      isSelected
                        ? 'bg-sky-600 text-white'
                        : 'bg-slate-800/70 text-slate-400 group-hover:text-sky-300 group-hover:bg-slate-800'
                    }`}
                  >
                    <IconComponent className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-semibold truncate leading-tight group-hover:text-white">
                      {category.name}
                    </div>
                    <div className="text-[10px] text-slate-400 leading-normal mt-0.5 whitespace-nowrap">
                      {formatCount(category.threadCount)} threads <span className="text-slate-400">·</span> {formatCount(category.postCount)} posts
                    </div>
                  </div>
                </div>

                <ChevronRight
                  className={`w-3.5 h-3.5 shrink-0 transition-transform ${
                    isSelected ? 'text-sky-400 translate-x-0.5' : 'text-slate-400 group-hover:text-slate-300'
                  }`}
                />
              </button>
            );
          })}
        </div>
      </div>
    </aside>
  );
};
