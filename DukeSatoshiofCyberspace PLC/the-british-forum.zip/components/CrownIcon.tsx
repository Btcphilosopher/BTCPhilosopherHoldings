import React from 'react';

interface CrownIconProps {
  className?: string;
  size?: number;
}

export const CrownIcon: React.FC<CrownIconProps> = ({ className = 'w-10 h-10 text-white', size }) => {
  return (
    <svg
      viewBox="0 0 100 80"
      fill="currentColor"
      className={className}
      style={size ? { width: size, height: size * 0.8 } : undefined}
      xmlns="http://www.w3.org/2000/svg"
      aria-label="The British Forum Crown Emblem"
    >
      {/* Top Cross */}
      <path d="M 48 3 L 52 3 L 52 7 L 56 7 L 56 11 L 52 11 L 52 15 L 48 15 L 48 11 L 44 11 L 44 7 L 48 7 Z" />
      {/* Orb below Cross */}
      <circle cx="50" cy="18" r="4.5" />
      {/* Crown Arches */}
      <path
        d="M 50 22 C 34 23 20 30 18 43 C 24 43 32 37 41 33 C 44 38 47 43 50 45 C 53 43 56 38 59 33 C 68 37 76 43 82 43 C 80 30 66 23 50 22 Z"
        opacity="0.95"
      />
      {/* Central Cross Formee & Fleur-de-lis */}
      <path d="M 47 30 L 53 30 L 51 38 L 55 40 L 53 46 L 47 46 L 45 40 L 49 38 Z" />
      <path d="M 28 35 C 29 42 34 46 38 47 C 32 46 29 48 27 52 C 26 48 23 46 17 47 C 22 45 27 41 28 35 Z" />
      <path d="M 72 35 C 71 42 66 46 62 47 C 68 46 71 48 73 52 C 74 48 77 46 83 47 C 78 45 73 41 72 35 Z" />
      {/* Crown Rim / Diadem */}
      <path
        d="M 12 56 C 24 53 76 53 88 56 C 89 61 88 66 87 70 C 75 67 25 67 13 70 C 12 66 11 61 12 56 Z"
      />
      {/* Jewels on Band */}
      <circle cx="20" cy="63" r="2.5" fill="#f8fafc" />
      <circle cx="35" cy="62" r="3" fill="#f8fafc" />
      <circle cx="50" cy="61.5" r="3.5" fill="#f8fafc" />
      <circle cx="65" cy="62" r="3" fill="#f8fafc" />
      <circle cx="80" cy="63" r="2.5" fill="#f8fafc" />
    </svg>
  );
};
