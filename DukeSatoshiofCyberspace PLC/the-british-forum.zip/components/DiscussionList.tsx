'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Pin, Plus, ChevronDown, Check, Eye, MessageSquare, Crown } from 'lucide-react';
import type { Thread } from '@/lib/db';

interface DiscussionListProps {
  threads: Thread[];
  selectedCategoryName?: string;
  sortBy: 'activity' | 'replies' | 'views' | 'newest';
  onSortChange: (sort: 'activity' | 'replies' | 'views' | 'newest') => void;
  onOpenNewThread: () => void;
  onSelectThread: (threadId: number) => void;
  onSelectCategorySlug: (slug: string) => void;
}

const AVATAR_BG_COLORS: Record<string, string> = {
  A: 'bg-purple-900/60 text-purple-200 border-purple-700/60',
  C: 'bg-teal-900/60 text-teal-200 border-teal-700/60',
  L: 'bg-indigo-900/60 text-indigo-200 border-indigo-700/60',
  S: 'bg-emerald-900/60 text-emerald-200 border-emerald-700/60',
  T: 'bg-cyan-900/60 text-cyan-200 border-cyan-700/60',
  H: 'bg-amber-900/60 text-amber-200 border-amber-700/60',
  F: 'bg-orange-900/60 text-orange-200 border-orange-700/60',
  P: 'bg-fuchsia-900/60 text-fuchsia-200 border-fuchsia-700/60',
  M: 'bg-sky-900/60 text-sky-200 border-sky-700/60',
  Y: 'bg-blue-900/60 text-blue-200 border-blue-700/60',
  G: 'bg-rose-900/60 text-rose-200 border-rose-700/60',
  W: 'bg-violet-900/60 text-violet-200 border-violet-700/60',
};

function formatCount(num: number): string {
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'k';
  }
  return num.toString();
}

export const DiscussionList: React.FC<DiscussionListProps> = ({
  threads,
  selectedCategoryName,
  sortBy,
  onSortChange,
  onOpenNewThread,
  onSelectThread,
  onSelectCategorySlug,
}) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const sortLabels: Record<string, string> = {
    activity: 'Latest Activity',
    replies: 'Most Replies',
    views: 'Most Views',
    newest: 'Newest Threads',
  };

  return (
    <div className="flex-1 min-w-0 bg-[#0b1526] rounded-xl border border-slate-800/80 shadow-sm overflow-hidden">
      {/* Top Controls Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-4 py-3.5 border-b border-slate-800/80 bg-[#0c182b]">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <span>{selectedCategoryName || 'Latest Discussions'}</span>
            <span className="text-xs font-normal text-slate-400">
              ({threads.length} threads)
            </span>
          </h2>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          {/* New Thread CTA */}
          <button
            onClick={onOpenNewThread}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-sm transition-all active:scale-[0.98]"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>New Thread</span>
          </button>

          {/* Sort Dropdown */}
          <div className="relative">
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 text-slate-200 text-xs font-medium border border-slate-700/80 transition-colors"
            >
              <span>{sortLabels[sortBy]}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {dropdownOpen && (
              <div className="absolute right-0 mt-1.5 w-44 rounded-lg bg-[#0e1a2f] border border-slate-700 shadow-xl z-20 py-1 text-xs">
                {(['activity', 'replies', 'views', 'newest'] as const).map((key) => (
                  <button
                    key={key}
                    onClick={() => {
                      onSortChange(key);
                      setDropdownOpen(false);
                    }}
                    className="w-full flex items-center justify-between px-3 py-2 text-left text-slate-300 hover:text-white hover:bg-sky-950/60 transition-colors"
                  >
                    <span>{sortLabels[key]}</span>
                    {sortBy === key && <Check className="w-3.5 h-3.5 text-sky-400" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Threads List */}
      <div className="divide-y divide-slate-800/70">
        {threads.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-sm">
            <MessageSquare className="w-8 h-8 mx-auto text-slate-400 mb-2" />
            No discussions found in this section. Be the first to start a debate!
          </div>
        ) : (
          threads.map((thread) => {
            const initial = (thread.author.displayName || 'A').charAt(0).toUpperCase();
            const avatarColor = AVATAR_BG_COLORS[initial] || 'bg-slate-800 text-slate-200 border-slate-700';

            return (
              <div
                key={thread.id}
                className="group flex flex-col md:flex-row md:items-center justify-between gap-3 px-4 py-3.5 hover:bg-[#0e1b30]/80 transition-colors cursor-pointer"
                onClick={() => onSelectThread(thread.id)}
              >
                {/* Left: Avatar + Title & Metadata */}
                <div className="flex items-start gap-3 min-w-0 flex-1">
                  {/* Author Avatar */}
                  <div
                    className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm shrink-0 border mt-0.5 ${avatarColor}`}
                  >
                    {thread.author.avatarUrl ? (
                      <div className="relative w-full h-full rounded-full overflow-hidden">
                        <Image
                          src={thread.author.avatarUrl}
                          alt={thread.author.displayName}
                          fill
                          referrerPolicy="no-referrer"
                          className="object-cover"
                        />
                      </div>
                    ) : (
                      <span>{initial}</span>
                    )}
                  </div>

                  {/* Title & Metadata */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {thread.isPinned && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-400 bg-amber-950/40 border border-amber-800/40 px-1.5 py-0.5 rounded">
                          <Pin className="w-3 h-3 fill-amber-400" />
                          <span>Pinned</span>
                        </span>
                      )}
                      <h3 className="text-sm font-semibold text-slate-100 group-hover:text-sky-300 transition-colors leading-snug">
                        {thread.title}
                      </h3>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-1 flex-wrap">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectCategorySlug(thread.categorySlug);
                        }}
                        className="text-sky-400 hover:text-sky-300 hover:underline font-medium"
                      >
                        {thread.categoryName}
                      </button>
                      <span className="text-slate-400" aria-hidden="true">·</span>
                      <span>
                        Started by <span className="text-slate-300 font-medium">{thread.author.displayName}</span>
                      </span>
                      <span className="text-slate-400" aria-hidden="true">·</span>
                      <span>{thread.timeAgo}</span>
                    </div>
                  </div>
                </div>

                {/* Right: Counters & Last Poster */}
                <div className="flex items-center justify-between md:justify-end gap-6 shrink-0 pl-12 md:pl-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-800/50">
                  {/* Stats Counters */}
                  <div className="flex items-center gap-5 text-right">
                    <div className="w-14">
                      <div className="text-xs font-bold text-slate-200 tabular-nums">
                        {formatCount(thread.repliesCount)}
                      </div>
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider">
                        Replies
                      </div>
                    </div>
                    <div className="w-14">
                      <div className="text-xs font-bold text-slate-200 tabular-nums">
                        {formatCount(thread.viewsCount)}
                      </div>
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider">
                        Views
                      </div>
                    </div>
                  </div>

                  {/* Last Activity Poster */}
                  <div className="flex items-center gap-2.5 w-36 sm:w-40 text-left">
                    {thread.lastPostUser.role === 'admin' ? (
                      <div className="w-7 h-7 rounded-full bg-amber-950/80 border border-amber-600/70 flex items-center justify-center text-amber-300 shrink-0">
                        <Crown className="w-3.5 h-3.5" />
                      </div>
                    ) : thread.lastPostUser.avatarUrl ? (
                      <div className="relative w-7 h-7 rounded-full overflow-hidden shrink-0 border border-slate-700">
                        <Image
                          src={thread.lastPostUser.avatarUrl}
                          alt={thread.lastPostUser.displayName}
                          fill
                          referrerPolicy="no-referrer"
                          className="object-cover"
                        />
                      </div>
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-semibold text-slate-300 shrink-0">
                        {thread.lastPostUser.initials.charAt(0)}
                      </div>
                    )}
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-200 truncate group-hover:text-white">
                        {thread.lastPostUser.displayName}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate whitespace-nowrap">
                        {thread.lastPostTimeAgo}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
