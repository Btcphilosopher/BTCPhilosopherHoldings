'use client';

import React, { useState } from 'react';
import { X, Send, PlusCircle } from 'lucide-react';
import type { Category, User } from '@/lib/db';

interface NewThreadModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  currentCategorySlug: string;
  currentUser: User | null;
  onOpenAuth: () => void;
  onCreateThread: (params: { title: string; categorySlug: string; content: string }) => Promise<void>;
}

export const NewThreadModal: React.FC<NewThreadModalProps> = ({
  isOpen,
  onClose,
  categories,
  currentCategorySlug,
  currentUser,
  onOpenAuth,
  onCreateThread,
}) => {
  const [title, setTitle] = useState('');
  const [categorySlug, setCategorySlug] = useState(
    currentCategorySlug !== 'all' ? currentCategorySlug : 'uk-news-politics'
  );
  const [content, setContent] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (!title.trim()) {
      setError('Please provide a descriptive title for your thread');
      return;
    }
    if (!content.trim()) {
      setError('Please provide initial context or arguments for this discussion');
      return;
    }

    try {
      setSubmitting(true);
      setError('');
      await onCreateThread({
        title: title.trim(),
        categorySlug,
        content: content.trim(),
      });
      setTitle('');
      setContent('');
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to publish thread';
      setError(msg);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-[#0b162a] border border-slate-700/80 rounded-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-[#0d1c33]">
          <div className="flex items-center gap-2 text-white font-bold text-base">
            <PlusCircle className="w-5 h-5 text-sky-400" />
            <span>Create New Discussion</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {!currentUser ? (
          <div className="p-6 text-center space-y-4">
            <p className="text-sm text-slate-300">
              You must be logged in to create a new discussion thread on The British Forum.
            </p>
            <button
              onClick={() => {
                onClose();
                onOpenAuth();
              }}
              className="px-5 py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition-colors"
            >
              Log In or Register
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 space-y-4">
            {error && (
              <div className="p-3 bg-rose-950/70 border border-rose-800 text-rose-200 text-xs rounded-lg">
                {error}
              </div>
            )}

            {/* Category selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Forum Category
              </label>
              <select
                value={categorySlug}
                onChange={(e) => setCategorySlug(e.target.value)}
                className="w-full bg-[#081220] border border-slate-700 text-slate-200 text-xs rounded-lg p-2.5 focus:border-sky-500 focus:outline-none"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.slug}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Thread Title
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. British High-Speed Rail & Regional Development"
                className="w-full bg-[#081220] border border-slate-700 text-slate-100 placeholder-slate-400 text-sm rounded-lg p-2.5 focus:border-sky-500 focus:outline-none"
                maxLength={180}
              />
            </div>

            {/* Body */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Opening Post Content
              </label>
              <textarea
                rows={6}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="State your thesis, questions, or perspectives to initiate the discussion..."
                className="w-full bg-[#081220] border border-slate-700 text-slate-100 placeholder-slate-400 text-sm rounded-lg p-3 focus:border-sky-500 focus:outline-none font-sans"
              />
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 text-xs font-medium transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting || !title.trim() || !content.trim()}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-xs font-semibold shadow transition-all"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{submitting ? 'Publishing...' : 'Publish Thread'}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
