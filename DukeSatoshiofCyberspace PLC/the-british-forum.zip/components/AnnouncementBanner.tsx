'use client';

import React, { useState } from 'react';
import { Megaphone, X } from 'lucide-react';

export const AnnouncementBanner: React.FC = () => {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 pt-4 pb-2">
      <div className="flex items-center justify-between gap-3 px-4 py-3 rounded-lg bg-[#0d1c33] border border-sky-800/40 text-slate-200 text-xs sm:text-sm shadow-sm transition-all">
        <div className="flex items-center gap-3">
          <div className="p-1.5 rounded-md bg-sky-900/50 text-sky-300 shrink-0">
            <Megaphone className="w-4 h-4" />
          </div>
          <p className="leading-snug">
            Welcome to <span className="font-semibold text-white">The British Forum</span> — a friendly, independent discussion community for people who care about Britain, its future and the wider world.
          </p>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="p-1 rounded text-slate-400 hover:text-slate-100 hover:bg-sky-950/50 transition-colors shrink-0"
          title="Dismiss notice"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
