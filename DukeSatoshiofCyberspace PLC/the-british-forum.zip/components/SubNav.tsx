'use client';

import React from 'react';
import { Home, MessageSquare, Sparkles, Users, HelpCircle, ChevronDown, Database, Cpu } from 'lucide-react';

interface SubNavProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  onOpenTech: () => void;
}

export const SubNav: React.FC<SubNavProps> = ({ currentTab, onTabChange, onOpenTech }) => {
  return (
    <nav className="w-full bg-[#0a1322] border-b border-slate-800 text-xs font-medium text-slate-300">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Left Navigation Items */}
        <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto scrollbar-none py-1.5">
          {/* Home Tab */}
          <button
            onClick={() => onTabChange('home')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              currentTab === 'home'
                ? 'bg-sky-700/90 text-white font-semibold shadow-sm'
                : 'hover:text-white hover:bg-slate-850/60 text-slate-300'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>Home</span>
          </button>

          {/* Forums Tab */}
          <button
            onClick={() => onTabChange('forums')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              currentTab === 'forums'
                ? 'bg-sky-700/90 text-white font-semibold'
                : 'hover:text-white hover:bg-slate-850/60 text-slate-300'
            }`}
          >
            <MessageSquare className="w-4 h-4 text-slate-400" />
            <span>Forums</span>
          </button>

          {/* What's New */}
          <div className="relative group">
            <button
              onClick={() => onTabChange('whats-new')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
                currentTab === 'whats-new'
                  ? 'bg-sky-700/90 text-white font-semibold'
                  : 'hover:text-white hover:bg-slate-850/60 text-slate-300'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>What&apos;s New</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>
          </div>

          {/* Members */}
          <div className="relative group">
            <button
              onClick={() => onTabChange('members')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
                currentTab === 'members'
                  ? 'bg-sky-700/90 text-white font-semibold'
                  : 'hover:text-white hover:bg-slate-850/60 text-slate-300'
              }`}
            >
              <Users className="w-4 h-4 text-slate-400" />
              <span>Members</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>
          </div>

          {/* Help */}
          <div className="relative group">
            <button
              onClick={() => onTabChange('help')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
                currentTab === 'help'
                  ? 'bg-sky-700/90 text-white font-semibold'
                  : 'hover:text-white hover:bg-slate-850/60 text-slate-300'
              }`}
            >
              <HelpCircle className="w-4 h-4 text-slate-400" />
              <span>Help</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>
          </div>

          {/* Live C & PHP & MySQL tab */}
          <button
            onClick={onOpenTech}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap text-emerald-400 hover:text-emerald-300 hover:bg-emerald-950/30 border border-emerald-900/40 ml-1"
          >
            <Cpu className="w-3.5 h-3.5" />
            <Database className="w-3.5 h-3.5 text-sky-400" />
            <span>C & PHP & MySQL Console</span>
          </button>
        </div>

        {/* Right Section: UK Flag & Forum Selector */}
        <div className="hidden sm:flex items-center gap-2 pl-4 shrink-0">
          <div className="flex items-center gap-2 px-2.5 py-1 rounded bg-[#07101c] border border-slate-800 text-slate-200 cursor-pointer hover:border-slate-700">
            {/* UK Flag Emoji / SVG */}
            <span className="text-sm leading-none" role="img" aria-label="United Kingdom Flag">
              🇬🇧
            </span>
            <span className="text-xs font-medium">British Forum</span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </div>
        </div>
      </div>
    </nav>
  );
};
