package com.example.data.repository

import com.example.data.model.Booking
import com.example.data.model.BookingState
import com.example.data.model.Vehicle
import com.example.data.model.VehicleClass
import com.example.data.model.VehicleStatus

object AvailabilityEngine {

    // 2 hours buffer in milliseconds for cleaning and pre-rental inspection
    private const val TURNAROUND_BUFFER_MS = 2 * 60 * 60 * 1000L

    fun calculateAvailableVehicles(
        fleet: List<Vehicle>,
        bookings: List<Booking>,
        targetClass: VehicleClass?,
        pickupBranchId: String,
        pickupTime: Long,
        returnTime: Long
    ): List<Vehicle> {
        // Filter out vehicles that are in maintenance or cleaning immediately
        val cleanFleet = fleet.filter { 
            it.status != VehicleStatus.MAINTENANCE
        }

        return cleanFleet.filter { vehicle ->
            // 1. Matches requested vehicle class (if specified)
            val matchesClass = targetClass == null || vehicle.category == targetClass
            if (!matchesClass) return@filter false

            // 2. Is the vehicle physically at the branch? 
            // In a real system, it's available if it's either currently at the branch and not booked,
            // or if it's arriving at the branch via an active rental that terminates before this pickup.
            // For our demo model, we check if its current branch matches or if it has an arrival return that fits.
            val currentBranchOk = vehicle.currentBranchId == pickupBranchId
            if (!currentBranchOk) return@filter false

            // 3. Check for overlapping bookings
            val hasOverlap = bookings.any { booking ->
                if (booking.vehicleId != vehicle.id) return@any false
                
                // Exclude cancelled or non-active states
                val isActiveState = booking.status != BookingState.CANCELLED && 
                                   booking.status != BookingState.COMPLETED &&
                                   booking.status != BookingState.NO_SHOW

                if (!isActiveState) return@any false

                // Add cleaning turnaround buffer to the booking's return time
                val bookingEndWithBuffer = booking.returnTime + TURNAROUND_BUFFER_MS
                val bookingStartWithBuffer = booking.pickupTime - TURNAROUND_BUFFER_MS

                // Overlap condition
                val overlaps = pickupTime < bookingEndWithBuffer && returnTime > bookingStartWithBuffer
                overlaps
            }

            !hasOverlap
        }
    }

    fun calculateAvailableClasses(
        fleet: List<Vehicle>,
        bookings: List<Booking>,
        pickupBranchId: String,
        pickupTime: Long,
        returnTime: Long
    ): Map<VehicleClass, Double> { // Class mapped to its lowest daily rate
        val availableVehicles = calculateAvailableVehicles(
            fleet = fleet,
            bookings = bookings,
            targetClass = null,
            pickupBranchId = pickupBranchId,
            pickupTime = pickupTime,
            returnTime = returnTime
        )

        return availableVehicles
            .groupBy { it.category }
            .mapValues { entry ->
                entry.value.minOf { it.dailyPrice }
            }
    }
}
