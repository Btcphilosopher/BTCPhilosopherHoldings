package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Booking
import com.example.data.model.BookingState
import com.example.data.model.Branch
import com.example.data.model.CoverLevel
import com.example.data.model.DamageItem
import com.example.data.model.EventLog
import com.example.data.model.Extra
import com.example.data.model.SupportTicket
import com.example.data.model.Vehicle
import com.example.data.model.VehicleClass
import com.example.data.repository.AnalyticsEngine
import com.example.data.repository.MotorRentalRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository = MotorRentalRepository(application)

    // --- BOTTOM NAVIGATION TABS ---
    enum class AppTab {
        EXPLORE, ACTIVE_RENTAL, ACCOUNT, SUPPORT, ADMIN
    }

    private val _currentTab = MutableStateFlow(AppTab.EXPLORE)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    fun selectTab(tab: AppTab) {
        _currentTab.value = tab
    }

    // --- SEARCH STATE ---
    val branches: StateFlow<List<Branch>> = repository.getAllBranches()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vehicles: StateFlow<List<Vehicle>> = repository.getAllVehicles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookings: StateFlow<List<Booking>> = repository.getAllBookings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val eventLogs: StateFlow<List<EventLog>> = repository.getAllEventLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val supportTickets: StateFlow<List<SupportTicket>> = repository.getAllSupportTickets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search input values
    val pickupBranchId = MutableStateFlow("LON-LHR")
    val returnBranchId = MutableStateFlow("LON-LHR")
    val pickupDateDaysAhead = MutableStateFlow(1) // tomorrow
    val returnDateDaysAhead = MutableStateFlow(3)  // 3 days later
    val sameLocation = MutableStateFlow(true)
    val selectedClassFilter = MutableStateFlow<VehicleClass?>(null)

    // Additional Filter Toggles
    val automaticOnly = MutableStateFlow(false)
    val electricOnly = MutableStateFlow(false)
    val under50PerDay = MutableStateFlow(false)
    val unlimitedMileageOnly = MutableStateFlow(false)

    // Search Results State
    private val _searchResults = MutableStateFlow<List<Vehicle>>(emptyList())
    val searchResults: StateFlow<List<Vehicle>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    // Screen State within EXPLORE Tab
    sealed class ExploreScreen {
        object Home : ExploreScreen()
        object Results : ExploreScreen()
        data class VehicleDetail(val vehicle: Vehicle) : ExploreScreen()
        data class BookingFlow(val vehicle: Vehicle, val step: Int) : ExploreScreen()
        data class BookingConfirmed(val booking: Booking) : ExploreScreen()
    }

    private val _exploreScreen = MutableStateFlow<ExploreScreen>(ExploreScreen.Home)
    val exploreScreen: StateFlow<ExploreScreen> = _exploreScreen.asStateFlow()

    fun navigateToExplore(screen: ExploreScreen) {
        _exploreScreen.value = screen
    }

    init {
        // Automatically search when parameters or filters change
        viewModelScope.launch {
            combine(
                pickupBranchId,
                returnBranchId,
                pickupDateDaysAhead,
                returnDateDaysAhead,
                selectedClassFilter,
                automaticOnly,
                electricOnly,
                under50PerDay,
                unlimitedMileageOnly,
                vehicles, // Trigger on database changes
                bookings
            ) { args ->
                // Refresh list
                executeSearchInternal()
            }.collect {}
        }
    }

    fun executeSearch() {
        viewModelScope.launch {
            _isSearching.value = true
            executeSearchInternal()
            _isSearching.value = false
            _exploreScreen.value = ExploreScreen.Results
        }
    }

    private suspend fun executeSearchInternal() {
        val pickup = getTimestampForDaysAhead(pickupDateDaysAhead.value, 10) // 10:00 AM
        val returnTime = getTimestampForDaysAhead(returnDateDaysAhead.value, 18) // 18:00 PM

        val rawResults = repository.searchVehicles(
            pickupBranchId = pickupBranchId.value,
            returnBranchId = if (sameLocation.value) pickupBranchId.value else returnBranchId.value,
            pickupTime = pickup,
            returnTime = returnTime,
            vehicleClass = selectedClassFilter.value
        )

        // Apply visual/additional filters
        val filtered = rawResults.filter { vehicle ->
            if (automaticOnly.value && vehicle.transmission != "Automatic") false
            else if (electricOnly.value && vehicle.fuelType != "Electric") false
            else if (under50PerDay.value && vehicle.dailyPrice > 50.0) false
            else if (unlimitedMileageOnly.value && vehicle.mileagePolicy != "Unlimited Mileage") false
            else true
        }

        _searchResults.value = filtered
    }

    private fun getTimestampForDaysAhead(days: Int, hourOfDay: Int): Long {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, days)
        cal.set(Calendar.HOUR_OF_DAY, hourOfDay)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    // --- BOOKING WORKFLOW STATE ---
    val bookingDriverName = MutableStateFlow("Thomas Harrison")
    val bookingDriverDob = MutableStateFlow("14/05/1991")
    val bookingDriverEmail = MutableStateFlow("thomas.harrison@domain.co.uk")
    val bookingDriverPhone = MutableStateFlow("+44 7911 123456")
    val bookingDriverLicence = MutableStateFlow("HARRI910514TH999")
    val bookingLicenceCountry = MutableStateFlow("United Kingdom")
    val bookingCoverLevel = MutableStateFlow(CoverLevel.STANDARD)

    // Optional Extras State
    val extraAddDriver = MutableStateFlow(false)
    val extraChildSeat = MutableStateFlow(false)
    val extraSatNav = MutableStateFlow(false)
    val extraEvChargePack = MutableStateFlow(false)
    val extraRoadside = MutableStateFlow(false)

    fun getSelectedExtras(): List<Extra> {
        return listOf(
            Extra("Additional Driver", 8.0, extraAddDriver.value, "Share driving responsibilities securely"),
            Extra("British Isofix Child Seat", 12.0, extraChildSeat.value, "Premium child safety restraints"),
            Extra("UK Sat-Nav Pack", 5.0, extraSatNav.value, "Offline-mapped British navigation assist"),
            Extra("Green EV Charging Package", 15.0, extraEvChargePack.value, "Unlimited charging at partner network"),
            Extra("Premium Roadside Cover", 6.0, extraRoadside.value, "Fully-inclusive RAC breakdown support")
        )
    }

    fun handleCreateBooking(vehicle: Vehicle) {
        viewModelScope.launch {
            val pickup = getTimestampForDaysAhead(pickupDateDaysAhead.value, 10)
            val returnTime = getTimestampForDaysAhead(returnDateDaysAhead.value, 18)

            val booking = repository.createBooking(
                vehicleId = vehicle.id,
                pickupBranchId = pickupBranchId.value,
                returnBranchId = if (sameLocation.value) pickupBranchId.value else returnBranchId.value,
                pickupTime = pickup,
                returnTime = returnTime,
                driverName = bookingDriverName.value,
                driverDob = bookingDriverDob.value,
                driverEmail = bookingDriverEmail.value,
                driverPhone = bookingDriverPhone.value,
                driverLicenceNumber = bookingDriverLicence.value,
                driverLicenceCountry = bookingLicenceCountry.value,
                coverLevel = bookingCoverLevel.value,
                selectedExtras = getSelectedExtras()
            )

            _exploreScreen.value = ExploreScreen.BookingFlow(vehicle, 4) // Jump directly to payment stage since we already set details
        }
    }

    fun handleConfirmPayment(bookingId: String) {
        viewModelScope.launch {
            val success = repository.processPaymentAndConfirm(bookingId, "Simulated Apple Pay")
            if (success) {
                val bookingObj = repository.getBookingById(bookingId)
                if (bookingObj != null) {
                    _exploreScreen.value = ExploreScreen.BookingConfirmed(bookingObj)
                }
            }
        }
    }

    // --- ACTIVE RENTAL WORKFLOW STATE ---
    val activeBooking: StateFlow<Booking?> = bookings.combine(currentTab) { list, tab ->
        // Return first ACTIVE, CONFIRMED, READY_FOR_PICKUP, CHECKING_IN, or RETURNING booking
        list.firstOrNull { 
            it.status == BookingState.ACTIVE || 
            it.status == BookingState.READY_FOR_PICKUP ||
            it.status == BookingState.CHECKING_IN ||
            it.status == BookingState.RETURNING ||
            it.status == BookingState.CONFIRMED ||
            it.status == BookingState.EXTENSION_REQUESTED
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Inspection checklist states (simulated photo checklist)
    val photoFrontTaken = MutableStateFlow(false)
    val photoRearTaken = MutableStateFlow(false)
    val photoLeftTaken = MutableStateFlow(false)
    val photoRightTaken = MutableStateFlow(false)
    val photoInteriorTaken = MutableStateFlow(false)
    val fuelLevelObserved = MutableStateFlow(100)
    val mileageObserved = MutableStateFlow(12050)

    fun startCollectionCheck(bookingId: String) {
        viewModelScope.launch {
            repository.startInspection(bookingId, "PICKUP")
            // Reset checklist state
            photoFrontTaken.value = false
            photoRearTaken.value = false
            photoLeftTaken.value = false
            photoRightTaken.value = false
            photoInteriorTaken.value = false
            fuelLevelObserved.value = 100
        }
    }

    fun completeCollectionCheck(bookingId: String, currentBookingMileage: Int) {
        viewModelScope.launch {
            repository.completePickupInspection(
                bookingId = bookingId,
                mileage = currentBookingMileage,
                fuelPercent = fuelLevelObserved.value,
                batteryPercent = fuelLevelObserved.value,
                exteriorOk = true,
                interiorOk = true,
                damageItems = emptyList() // No damages detected for demo standard check
            )
        }
    }

    fun startReturnCheck(bookingId: String) {
        viewModelScope.launch {
            repository.startInspection(bookingId, "RETURN")
            photoFrontTaken.value = false
            photoRearTaken.value = false
            photoLeftTaken.value = false
            photoRightTaken.value = false
            photoInteriorTaken.value = false
            fuelLevelObserved.value = 95 // Return with 95% charge or fuel
        }
    }

    fun completeReturnCheck(bookingId: String, finalMileage: Int) {
        viewModelScope.launch {
            repository.completeReturnInspection(
                bookingId = bookingId,
                mileage = finalMileage,
                fuelPercent = fuelLevelObserved.value,
                batteryPercent = fuelLevelObserved.value,
                exteriorOk = true,
                interiorOk = true,
                damageItems = emptyList()
            )
        }
    }

    // Rental Extension
    val extensionHours = MutableStateFlow(12) // 12 hours standard
    val extensionStatusMessage = MutableStateFlow<String?>(null)

    fun requestExtension(bookingId: String) {
        viewModelScope.launch {
            val res = repository.checkAndExtendRental(bookingId, extensionHours.value)
            if (res.first) {
                extensionStatusMessage.value = "Rental successfully extended! Additional £${res.second} charged to card on file."
            } else {
                extensionStatusMessage.value = "Extension unavailable: This vehicle is scheduled for an upcoming booking."
            }
        }
    }

    // Live Simulator Actions (Simulate driving and mileage accumulation for high realism!)
    fun simulateDrive(milesDriven: Int) {
        val current = activeBooking.value ?: return
        viewModelScope.launch {
            val nextMileage = current.currentMileage + milesDriven
            // Reduce fuel or charge
            val nextFuel = (current.currentFuelPercent - (milesDriven * 0.4).toInt()).coerceAtLeast(10)
            
            // Update db record
            val updated = current.copy(
                currentMileage = nextMileage,
                currentFuelPercent = nextFuel,
                currentBatteryPercent = nextFuel
            )
            repository.updateBooking(updated)
            // Synchronize telemetry
            repository.updateVehicleTelemetry(current.vehicleId, nextFuel, nextMileage)
        }
    }

    // EV Charging simulator
    fun simulateCharge() {
        val current = activeBooking.value ?: return
        viewModelScope.launch {
            val updated = current.copy(
                currentFuelPercent = 100,
                currentBatteryPercent = 100
            )
            repository.updateBooking(updated)
            repository.updateVehicleTelemetry(current.vehicleId, 100, current.currentMileage)
        }
    }

    // --- SUPPORT TICKETS ---
    val ticketSubject = MutableStateFlow("")
    val ticketDescription = MutableStateFlow("")
    val ticketCategory = MutableStateFlow("Booking")
    val ticketStatusMessage = MutableStateFlow<String?>(null)

    fun submitSupportTicket(bookingId: String) {
        viewModelScope.launch {
            if (ticketSubject.value.isBlank() || ticketDescription.value.isBlank()) {
                ticketStatusMessage.value = "Please complete all fields before submitting."
                return@launch
            }
            repository.raiseSupportTicket(
                bookingId = bookingId,
                category = ticketCategory.value,
                subject = ticketSubject.value,
                description = ticketDescription.value
            )
            ticketStatusMessage.value = "Ticket successfully raised. A service agent will review your issue shortly."
            ticketSubject.value = ""
            ticketDescription.value = ""
        }
    }
}
