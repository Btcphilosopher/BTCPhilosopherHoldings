package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.data.repository.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainLayout(viewModel: MainViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    
    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentTab == MainViewModel.AppTab.EXPLORE,
                    onClick = { viewModel.selectTab(MainViewModel.AppTab.EXPLORE) },
                    icon = { Icon(Icons.Default.Search, contentDescription = "Explore") },
                    label = { Text("Explore", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_explore")
                )
                NavigationBarItem(
                    selected = currentTab == MainViewModel.AppTab.ACTIVE_RENTAL,
                    onClick = { viewModel.selectTab(MainViewModel.AppTab.ACTIVE_RENTAL) },
                    icon = { Icon(Icons.Default.DirectionsCar, contentDescription = "Active Trip") },
                    label = { Text("Active Trip", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_active")
                )
                NavigationBarItem(
                    selected = currentTab == MainViewModel.AppTab.ACCOUNT,
                    onClick = { viewModel.selectTab(MainViewModel.AppTab.ACCOUNT) },
                    icon = { Icon(Icons.Default.Person, contentDescription = "Club & Account") },
                    label = { Text("Account", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_account")
                )
                NavigationBarItem(
                    selected = currentTab == MainViewModel.AppTab.SUPPORT,
                    onClick = { viewModel.selectTab(MainViewModel.AppTab.SUPPORT) },
                    icon = { Icon(Icons.Default.HeadsetMic, contentDescription = "Support") },
                    label = { Text("Support", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_support")
                )
                NavigationBarItem(
                    selected = currentTab == MainViewModel.AppTab.ADMIN,
                    onClick = { viewModel.selectTab(MainViewModel.AppTab.ADMIN) },
                    icon = { Icon(Icons.Default.Analytics, contentDescription = "Operations") },
                    label = { Text("Operations", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_admin")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (currentTab) {
                MainViewModel.AppTab.EXPLORE -> ExploreTab(viewModel)
                MainViewModel.AppTab.ACTIVE_RENTAL -> ActiveRentalTab(viewModel)
                MainViewModel.AppTab.ACCOUNT -> AccountTab(viewModel)
                MainViewModel.AppTab.SUPPORT -> SupportTab(viewModel)
                MainViewModel.AppTab.ADMIN -> AdminTab(viewModel)
            }
        }
    }
}

// ==========================================
// 1. EXPLORE TAB & JOURNEYS
// ==========================================
@Composable
fun ExploreTab(viewModel: MainViewModel) {
    val screenState by viewModel.exploreScreen.collectAsState()

    when (val screen = screenState) {
        is MainViewModel.ExploreScreen.Home -> ExploreHomeScreen(viewModel)
        is MainViewModel.ExploreScreen.Results -> SearchResultsScreen(viewModel)
        is MainViewModel.ExploreScreen.VehicleDetail -> VehicleDetailScreen(viewModel, screen.vehicle)
        is MainViewModel.ExploreScreen.BookingFlow -> BookingFlowScreen(viewModel, screen.vehicle, screen.step)
        is MainViewModel.ExploreScreen.BookingConfirmed -> BookingConfirmedScreen(viewModel, screen.booking)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreHomeScreen(viewModel: MainViewModel) {
    val branches by viewModel.branches.collectAsState()
    val pickupBranch by viewModel.pickupBranchId.collectAsState()
    val returnBranch by viewModel.returnBranchId.collectAsState()
    val sameLoc by viewModel.sameLocation.collectAsState()
    val pDays by viewModel.pickupDateDaysAhead.collectAsState()
    val rDays by viewModel.returnDateDaysAhead.collectAsState()

    // Filter toggles
    val autoOnly by viewModel.automaticOnly.collectAsState()
    val elecOnly by viewModel.electricOnly.collectAsState()
    val cheapOnly by viewModel.under50PerDay.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // CONFIDENT HEADER
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(BritishRacingGreen)
                .padding(horizontal = 24.dp, vertical = 28.dp)
        ) {
            Column {
                Text(
                    text = "ENGLISH MOTOR",
                    color = WarmWhite,
                    style = MaterialTheme.typography.displayLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "YOUR CAR. YOUR JOURNEY.",
                    color = SoftGrey,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp)
                )
                Text(
                    text = "Simple UK car hire, wherever Britain takes you.",
                    color = SoftGrey.copy(alpha = 0.8f),
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // HERO ILLUSTRATION
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Box(modifier = Modifier.height(180.dp)) {
                Image(
                    painter = painterResource(id = R.drawable.english_motor_hero),
                    contentDescription = "Scenic British Countryside",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.35f))
                        .padding(16.dp),
                    contentAlignment = Alignment.BottomStart
                ) {
                    Column {
                        Text(
                            "Discover Britain",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                        Text(
                            "From city hubs to coastal retreats with zero emission fleets.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }

        // SEARCH CARD
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .border(1.dp, SoftGrey, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "WHERE ARE YOU GOING?",
                    style = MaterialTheme.typography.titleMedium,
                    color = BritishRacingGreen
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Same Location Toggle
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Checkbox(checked = sameLoc, onCheckedChange = { viewModel.sameLocation.value = it })
                    Text("Return to same branch location", style = MaterialTheme.typography.bodyMedium)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Pickup location dropdown / selector
                Text("Pick-up Location", style = MaterialTheme.typography.labelMedium)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SoftGrey)
                        .clickable { /* dropdown toggle simulated */ }
                        .padding(12.dp)
                ) {
                    val branchName = branches.find { it.id == pickupBranch }?.name ?: "Select branch"
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(branchName, style = MaterialTheme.typography.bodyMedium)
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                    }
                }

                // Dropdown simulation: Simple buttons for other branches to facilitate easy simulation
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    branches.take(3).forEach { branch ->
                        Button(
                            onClick = { viewModel.pickupBranchId.value = branch.id },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (pickupBranch == branch.id) BritishRacingGreen else SoftGrey,
                                contentColor = if (pickupBranch == branch.id) Color.White else Graphite
                            ),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(branch.name.replace(" Airport", "").replace(" Station", "").replace(" Railway", ""), fontSize = 11.sp)
                        }
                    }
                }

                if (!sameLoc) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Return Location", style = MaterialTheme.typography.labelMedium)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(SoftGrey)
                            .padding(12.dp)
                    ) {
                        val branchName = branches.find { it.id == returnBranch }?.name ?: "Select branch"
                        Text(branchName, style = MaterialTheme.typography.bodyMedium)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Date sliders for simple, precise duration manipulation
                Text("Pick-up Date: Tomorrow +$pDays days", style = MaterialTheme.typography.labelMedium)
                Slider(
                    value = pDays.toFloat(),
                    onValueChange = { viewModel.pickupDateDaysAhead.value = it.toInt() },
                    valueRange = 0f..10f,
                    steps = 9
                )

                Text("Return Date: Tomorrow +$rDays days", style = MaterialTheme.typography.labelMedium)
                Slider(
                    value = rDays.toFloat(),
                    onValueChange = { viewModel.returnDateDaysAhead.value = it.toInt().coerceAtLeast(pDays + 1) },
                    valueRange = 1f..15f,
                    steps = 14
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Active Filters
                Text("PRE-FILTERS", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = autoOnly,
                        onClick = { viewModel.automaticOnly.value = !autoOnly },
                        label = { Text("Automatic only", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = elecOnly,
                        onClick = { viewModel.electricOnly.value = !elecOnly },
                        label = { Text("Electric only", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = cheapOnly,
                        onClick = { viewModel.under50PerDay.value = !cheapOnly },
                        label = { Text("Under £50/day", fontSize = 11.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { viewModel.executeSearch() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("search_cars_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.DirectionsCar, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("SEARCH CARS", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Pick branch links
        Text(
            "POPULAR REGIONS & STATIONS",
            modifier = Modifier.padding(horizontal = 24.dp),
            style = MaterialTheme.typography.labelMedium,
            color = Color.Gray
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            branches.forEach { branch ->
                Card(
                    modifier = Modifier
                        .width(130.dp)
                        .clickable { viewModel.pickupBranchId.value = branch.id },
                    colors = CardDefaults.cardColors(containerColor = SoftGrey)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Icon(
                            imageVector = if (branch.type == BranchType.AIRPORT) Icons.Default.Flight else Icons.Default.Train,
                            contentDescription = null,
                            tint = BritishRacingGreen
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(branch.name.replace(" Airport", "").replace(" Station", ""), style = MaterialTheme.typography.titleMedium, fontSize = 13.sp)
                        Text(branch.city, style = MaterialTheme.typography.bodyMedium, fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun SearchResultsScreen(viewModel: MainViewModel) {
    val results by viewModel.searchResults.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateToExplore(MainViewModel.ExploreScreen.Home) }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Select Vehicle", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(start = 8.dp))
        }

        if (isSearching) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = BritishRacingGreen)
            }
        } else if (results.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.LightGray)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No available vehicles fit filters.", style = MaterialTheme.typography.bodyLarge)
                    Text("Try broadening your filter configurations.", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(results) { vehicle ->
                    VehicleCard(vehicle = vehicle, onSelect = {
                        viewModel.navigateToExplore(MainViewModel.ExploreScreen.VehicleDetail(vehicle))
                    })
                }
            }
        }
    }
}

@Composable
fun VehicleCard(vehicle: Vehicle, onSelect: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SoftGrey, RoundedCornerShape(12.dp))
            .clickable { onSelect() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(vehicle.name, style = MaterialTheme.typography.titleLarge)
                    Text(
                        vehicle.category.name.replace("_", " "),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray
                    )
                }
                
                // Branded Vehicle Status / Color Accent
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(BritishRacingGreen.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(vehicle.fuelType, color = BritishRacingGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Specs Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Gray)
                    Text(" " + vehicle.transmission, fontSize = 12.sp, color = Color.Gray)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AirlineSeatReclineExtra, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Gray)
                    Text(" " + vehicle.seats, fontSize = 12.sp, color = Color.Gray)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Luggage, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Gray)
                    Text(" " + vehicle.luggageLarge + " Bags", fontSize = 12.sp, color = Color.Gray)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            HorizontalDivider(color = SoftGrey)

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("£${vehicle.dailyPrice} / day", style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
                    Text("Excess: £${vehicle.excessAmount} • Deposit: £${vehicle.depositAmount}", fontSize = 11.sp, color = Color.Gray)
                }

                Button(
                    onClick = onSelect,
                    colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("SELECT", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun VehicleDetailScreen(viewModel: MainViewModel, vehicle: Vehicle) {
    val branches by viewModel.branches.collectAsState()
    val pickupBranchId by viewModel.pickupBranchId.collectAsState()
    val returnBranchId by viewModel.returnBranchId.collectAsState()
    val pDays by viewModel.pickupDateDaysAhead.collectAsState()
    val rDays by viewModel.returnDateDaysAhead.collectAsState()

    // Retrieve full branch objects
    val pickupBranch = branches.find { it.id == pickupBranchId } ?: SeedData.branches.first()
    val returnBranch = branches.find { it.id == returnBranchId } ?: SeedData.branches.first()

    // Pricing components state
    val coverLevel by viewModel.bookingCoverLevel.collectAsState()
    val selectedExtras = viewModel.getSelectedExtras()

    val pickupTime = System.currentTimeMillis() + (pDays * 24 * 60 * 60 * 1000L)
    val returnTime = System.currentTimeMillis() + (rDays * 24 * 60 * 60 * 1000L)

    val pricingBreakdown = PricingEngine.calculatePrice(
        vehicle = vehicle,
        pickupBranch = pickupBranch,
        returnBranch = returnBranch,
        pickupTimeMillis = pickupTime,
        returnTimeMillis = returnTime,
        coverLevel = coverLevel,
        selectedExtras = selectedExtras
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateToExplore(MainViewModel.ExploreScreen.Results) }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Vehicle Details", style = MaterialTheme.typography.titleLarge)
        }

        // Vehicle specifications header
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(vehicle.name, style = MaterialTheme.typography.displayMedium, color = BritishRacingGreen)
                Text("Category: " + vehicle.category.name, style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SpecificationChip("Color", vehicle.color)
                    SpecificationChip("Transmission", vehicle.transmission)
                    SpecificationChip("Fuel", vehicle.fuelType)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SpecificationChip("Drivetrain", vehicle.drivetrain)
                    SpecificationChip("Seats", "${vehicle.seats} seats")
                    SpecificationChip("Luggage", "${vehicle.luggageLarge} large, ${vehicle.luggageSmall} small")
                }

                if (vehicle.fuelType == "Electric") {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(BritishRacingGreen.copy(alpha = 0.08f))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.EvStation, contentDescription = null, tint = BritishRacingGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Electric vehicle - Battery: ${vehicle.batteryPercent}%", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BritishRacingGreen)
                            Text("Estimated range: ~${vehicle.estimatedRangeMiles} miles on full charge", fontSize = 11.sp, color = Graphite)
                        }
                    }
                }
            }
        }

        // CHOOSE COVER OPTIONS
        Text("CHOOSE YOUR COVER LEVEL", modifier = Modifier.padding(horizontal = 24.dp), style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
        Spacer(modifier = Modifier.height(8.dp))

        Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            CoverOptionRow(
                level = CoverLevel.BASIC,
                selected = coverLevel == CoverLevel.BASIC,
                price = "£0.00 / day",
                excess = "£${vehicle.excessAmount} excess fee",
                desc = "Basic motor vehicle cover. Credit card authorization hold required at branch desk.",
                onClick = { viewModel.bookingCoverLevel.value = CoverLevel.BASIC }
            )
            CoverOptionRow(
                level = CoverLevel.STANDARD,
                selected = coverLevel == CoverLevel.STANDARD,
                price = "£12.50 / day",
                excess = "£${vehicle.excessAmount / 2} excess fee",
                desc = "Standard protection. Reduces excess responsibility by half and halves standard deposit.",
                onClick = { viewModel.bookingCoverLevel.value = CoverLevel.STANDARD }
            )
            CoverOptionRow(
                level = CoverLevel.PREMIUM,
                selected = coverLevel == CoverLevel.PREMIUM,
                price = "£25.00 / day",
                excess = "£50 excess fee",
                desc = "Full reassurance. Almost zero excess responsibility, releases deposit to a simple £50 hold.",
                onClick = { viewModel.bookingCoverLevel.value = CoverLevel.PREMIUM }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // OPTIONAL EXTRAS
        Text("ADD REFINED EXTRAS", modifier = Modifier.padding(horizontal = 24.dp), style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
        Spacer(modifier = Modifier.height(8.dp))

        Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val addDriver by viewModel.extraAddDriver.collectAsState()
            val childSeat by viewModel.extraChildSeat.collectAsState()
            val satNav by viewModel.extraSatNav.collectAsState()
            val evPack by viewModel.extraEvChargePack.collectAsState()
            val roadside by viewModel.extraRoadside.collectAsState()

            ExtraToggleRow("Additional Driver", "£8.00 / day", addDriver, { viewModel.extraAddDriver.value = it })
            ExtraToggleRow("British Isofix Child Seat", "£12.00 / day", childSeat, { viewModel.extraChildSeat.value = it })
            ExtraToggleRow("UK Offline Sat-Nav System", "£5.00 / day", satNav, { viewModel.extraSatNav.value = it })
            ExtraToggleRow("Green EV Network Charging Pack", "£15.00 / day", evPack, { viewModel.extraEvChargePack.value = it })
            ExtraToggleRow("Premium Roadside Assistance (RAC)", "£6.00 / day", roadside, { viewModel.extraRoadside.value = it })
        }

        Spacer(modifier = Modifier.height(24.dp))

        // TRANSPARENT PRICING BREAKDOWN
        Text("TRANSPARENT PRICE DESCRIPTION", modifier = Modifier.padding(horizontal = 24.dp), style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = SoftGrey)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                PricingRow("Vehicle Hire (${rDays - pDays} days)", "£${pricingBreakdown.baseRental}")
                if (pricingBreakdown.locationCharges > 0) {
                    PricingRow("Location & Relocation surcharges", "£${pricingBreakdown.locationCharges}")
                }
                if (pricingBreakdown.coverCharge > 0) {
                    PricingRow("Cover Level Protection Charge", "£${pricingBreakdown.coverCharge}")
                }
                if (pricingBreakdown.extrasCharge > 0) {
                    PricingRow("Optional products & equipment", "£${pricingBreakdown.extrasCharge}")
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color.LightGray)

                PricingRow("Net value", "£" + String.format("%.2f", pricingBreakdown.totalAmount - pricingBreakdown.vatAmount))
                PricingRow("UK VAT (20% included)", "£${pricingBreakdown.vatAmount}")

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color.LightGray)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Total amount payable", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                    Text("£${pricingBreakdown.totalAmount}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = BritishRacingGreen)
                }

                Spacer(modifier = Modifier.height(8.dp))
                PricingRow("Refundable Card Deposit (Standard Hold)", "£${pricingBreakdown.deposit}")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { viewModel.handleCreateBooking(vehicle) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .height(54.dp)
                .testTag("proceed_to_booking_button"),
            colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("PROCEED TO SECURE CHECKOUT", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
fun BookingFlowScreen(viewModel: MainViewModel, vehicle: Vehicle, step: Int) {
    val name by viewModel.bookingDriverName.collectAsState()
    val dob by viewModel.bookingDriverDob.collectAsState()
    val email by viewModel.bookingDriverEmail.collectAsState()
    val phone by viewModel.bookingDriverPhone.collectAsState()
    val licence by viewModel.bookingDriverLicence.collectAsState()
    val country by viewModel.bookingLicenceCountry.collectAsState()

    val branches by viewModel.branches.collectAsState()
    val pickupBranchId by viewModel.pickupBranchId.collectAsState()
    val returnBranchId by viewModel.returnBranchId.collectAsState()
    val pDays by viewModel.pickupDateDaysAhead.collectAsState()
    val rDays by viewModel.returnDateDaysAhead.collectAsState()

    val pickupBranch = branches.find { it.id == pickupBranchId } ?: SeedData.branches.first()
    val returnBranch = branches.find { it.id == returnBranchId } ?: SeedData.branches.first()
    val coverLevel by viewModel.bookingCoverLevel.collectAsState()

    val pickupTime = System.currentTimeMillis() + (pDays * 24 * 60 * 60 * 1000L)
    val returnTime = System.currentTimeMillis() + (rDays * 24 * 60 * 60 * 1000L)

    val pricingBreakdown = PricingEngine.calculatePrice(
        vehicle = vehicle,
        pickupBranch = pickupBranch,
        returnBranch = returnBranch,
        pickupTimeMillis = pickupTime,
        returnTimeMillis = returnTime,
        coverLevel = coverLevel,
        selectedExtras = viewModel.getSelectedExtras()
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateToExplore(MainViewModel.ExploreScreen.VehicleDetail(vehicle)) }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Booking Checkout", style = MaterialTheme.typography.titleLarge)
        }

        // STEP INDICATOR (M3)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            StepIndicatorItem("01 Driver", true)
            StepIndicatorItem("02 Cover", true)
            StepIndicatorItem("03 Extras", true)
            StepIndicatorItem("04 Payment", step == 4)
        }

        HorizontalDivider(modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))

        // STAGE 4: PAYMENT FORM
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("SECURE PAYMENT", style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Verify driver details and execute secure simulated payment.", fontSize = 11.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(16.dp))

                // Driver recap
                Text("Driver: $name", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("Licence: $licence ($country)", fontSize = 12.sp, color = Color.Gray)
                Text("Branch: ${pickupBranch.name}", fontSize = 12.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = "•••• •••• •••• 4912",
                    onValueChange = {},
                    enabled = false,
                    label = { Text("Secure Card Number (Simulated)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = "12/29",
                        onValueChange = {},
                        enabled = false,
                        label = { Text("Expiry") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = "•••",
                        onValueChange = {},
                        enabled = false,
                        label = { Text("CVC") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(SoftGrey)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Total Amount due", fontWeight = FontWeight.Bold)
                    Text("£${pricingBreakdown.totalAmount}", fontWeight = FontWeight.Bold, color = BritishRacingGreen)
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { 
                        // Simulate checkout complete
                        viewModel.handleConfirmPayment(bookingId = "EM-TEMP")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("pay_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.CreditCard, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("PAY £${pricingBreakdown.totalAmount}", fontWeight = FontWeight.Bold)
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "This is a simulated demo environment. No real funds are transferred.",
                    fontSize = 10.sp,
                    color = LondonRed,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun BookingConfirmedScreen(viewModel: MainViewModel, booking: Booking) {
    val branches by viewModel.branches.collectAsState()
    val pickupBranch = branches.find { it.id == booking.pickupBranchId } ?: SeedData.branches.first()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(64.dp), tint = BritishRacingGreen)
        Spacer(modifier = Modifier.height(12.dp))
        Text("BOOKING SECURED", style = MaterialTheme.typography.displayMedium, color = BritishRacingGreen)
        Text("Your Car. Your Journey.", style = MaterialTheme.typography.labelSmall, color = Color.Gray)

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("BOOKING NUMBER", style = MaterialTheme.typography.labelSmall)
                    Text(booking.id, fontWeight = FontWeight.Bold, color = BritishRacingGreen, style = MaterialTheme.typography.labelMedium)
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = SoftGrey)
                Spacer(modifier = Modifier.height(12.dp))

                Text(booking.vehicleName, style = MaterialTheme.typography.titleLarge)
                Text("Registration: " + booking.vehicleRegistration, style = MaterialTheme.typography.labelMedium, color = Graphite)

                Spacer(modifier = Modifier.height(12.dp))

                Text("Pick-up Branch", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                Text(booking.pickupBranchName, fontWeight = FontWeight.Bold)
                Text("Operating Hours: ${pickupBranch.operatingHours}", fontSize = 12.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(12.dp))

                Text("How to Collect Your Vehicle", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                Text(pickupBranch.walkingInstructions, fontSize = 12.sp)

                Spacer(modifier = Modifier.height(16.dp))

                // Simulate QR code
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .background(Color.White)
                        .border(1.dp, Color.LightGray)
                        .padding(12.dp)
                        .align(Alignment.CenterHorizontally),
                    contentAlignment = Alignment.Center
                ) {
                    // Render simple QR design
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawRect(color = Color.Black, style = Stroke(width = 8f))
                        drawRect(color = Color.Black, size = this.size * 0.3f)
                    }
                    Text("EM KEYLESS QR", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = { viewModel.selectTab(MainViewModel.AppTab.ACTIVE_RENTAL) },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("view_my_booking_button"),
            colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("VIEW MY ACTIVE TRIP CONSOLE", fontWeight = FontWeight.Bold)
        }
    }
}


// ==========================================
// 2. ACTIVE RENTAL TAB & SIMULATORS
// ==========================================
@Composable
fun ActiveRentalTab(viewModel: MainViewModel) {
    val activeBooking by viewModel.activeBooking.collectAsState()

    if (activeBooking == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                Icon(Icons.Default.DirectionsCar, contentDescription = null, modifier = Modifier.size(64.dp), tint = Color.LightGray)
                Spacer(modifier = Modifier.height(16.dp))
                Text("No Active Rental", style = MaterialTheme.typography.titleLarge)
                Text("You do not have any vehicle rentals in progress or pick-ups due.", textAlign = TextAlign.Center, color = Color.Gray)
                Spacer(modifier = Modifier.height(24.dp))
                Button(onClick = { viewModel.selectTab(MainViewModel.AppTab.EXPLORE) }, colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen)) {
                    Text("SEARCH VEHICLES NOW")
                }
            }
        }
    } else {
        val booking = activeBooking!!
        when (booking.status) {
            BookingState.READY_FOR_PICKUP, BookingState.CONFIRMED, BookingState.CHECKING_IN -> {
                PickupInspectionScreen(viewModel, booking)
            }
            BookingState.ACTIVE, BookingState.EXTENSION_REQUESTED -> {
                TripDashboardScreen(viewModel, booking)
            }
            BookingState.RETURNING -> {
                ReturnInspectionScreen(viewModel, booking)
            }
            else -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Rental in state: ${booking.status}")
                }
            }
        }
    }
}

@Composable
fun PickupInspectionScreen(viewModel: MainViewModel, booking: Booking) {
    val pFront by viewModel.photoFrontTaken.collectAsState()
    val pRear by viewModel.photoRearTaken.collectAsState()
    val pLeft by viewModel.photoLeftTaken.collectAsState()
    val pRight by viewModel.photoRightTaken.collectAsState()
    val pInt by viewModel.photoInteriorTaken.collectAsState()
    val fuelObserved by viewModel.fuelLevelObserved.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("YOUR CAR IS READY", style = MaterialTheme.typography.displayMedium, color = BritishRacingGreen)
        Text("Pre-Rental Digital Condition Report", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)

        Spacer(modifier = Modifier.height(16.dp))

        // Vehicle info
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(booking.vehicleName, style = MaterialTheme.typography.titleLarge)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Reg: " + booking.vehicleRegistration, fontWeight = FontWeight.Bold, color = BritishRacingGreen)
                    Text("Color: " + booking.vehicleColor, color = Color.Gray)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("Location: " + booking.pickupBranchName, fontSize = 12.sp)
                Text("Walking instructions: Go to Bay 14 in the rental garage.", fontSize = 12.sp, color = Color.Gray)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text("DIGITAL DAMAGE & FUEL CHECKLIST", style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
        Text("Please confirm vehicle state and take simulated verification photos.", fontSize = 11.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(12.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PhotoCheckItem("Front of vehicle", pFront, { viewModel.photoFrontTaken.value = it })
            PhotoCheckItem("Rear of vehicle", pRear, { viewModel.photoRearTaken.value = it })
            PhotoCheckItem("Left hand side", pLeft, { viewModel.photoLeftTaken.value = it })
            PhotoCheckItem("Right hand side", pRight, { viewModel.photoRightTaken.value = it })
            PhotoCheckItem("Interior & dashboard", pInt, { viewModel.photoInteriorTaken.value = it })
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Fuel Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Observed Fuel/Charge level", fontWeight = FontWeight.Bold)
            Text("$fuelObserved%", fontWeight = FontWeight.Bold, color = BritishRacingGreen)
        }
        Slider(
            value = fuelObserved.toFloat(),
            onValueChange = { viewModel.fuelLevelObserved.value = it.toInt() },
            valueRange = 0f..100f
        )

        Spacer(modifier = Modifier.height(24.dp))

        val allPhotosTaken = pFront && pRear && pLeft && pRight && pInt

        Button(
            onClick = { 
                viewModel.completeCollectionCheck(booking.id, booking.currentMileage)
            },
            enabled = allPhotosTaken,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("collect_vehicle_button"),
            colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen)
        ) {
            Text("START RENTAL & UNLOCK CAR", fontWeight = FontWeight.Bold)
        }
        if (!allPhotosTaken) {
            Text("Please photograph all 5 angles of the vehicle to unlock.", color = LondonRed, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
        }
    }
}

@Composable
fun TripDashboardScreen(viewModel: MainViewModel, booking: Booking) {
    val extHours by viewModel.extensionHours.collectAsState()
    val extMsg by viewModel.extensionStatusMessage.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("YOUR CURRENT RENTAL", style = MaterialTheme.typography.displayMedium, color = BritishRacingGreen)
        Text("Enjoy your journey with English Motor", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)

        Spacer(modifier = Modifier.height(16.dp))

        // Large status card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = BritishRacingGreen)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(booking.vehicleName, style = MaterialTheme.typography.displayMedium, color = WarmWhite)
                Text("REGISTRATION: ${booking.vehicleRegistration}", style = MaterialTheme.typography.labelMedium, color = SoftGrey)
                
                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("FUEL / CHARGE", style = MaterialTheme.typography.labelSmall, color = SoftGrey)
                        Text("${booking.currentFuelPercent}%", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = WarmWhite)
                    }
                    Column {
                        Text("CURRENT ODOMETER", style = MaterialTheme.typography.labelSmall, color = SoftGrey)
                        Text("${booking.currentMileage} miles", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = WarmWhite)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // HIGH REALISM TRIP SIMULATOR CONTROLS
        Text("VEHICLE TELEMETRY SIMULATOR", style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Simulate driving to test real-time state transitions and battery charge calculations.", fontSize = 11.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.simulateDrive(25) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen)
                    ) {
                        Text("Drive 25 Miles", fontSize = 12.sp)
                    }
                    Button(
                        onClick = { viewModel.simulateCharge() },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
                    ) {
                        Text("Simulate EV Charge", fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // EXTEND RENTAL
        Text("EXTEND HIRE PERIOD", style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("New Return Time Slider (Hours to add)", style = MaterialTheme.typography.labelSmall)
                Slider(
                    value = extHours.toFloat(),
                    onValueChange = { viewModel.extensionHours.value = it.toInt() },
                    valueRange = 1f..48f
                )
                Text("Hours to extend: +$extHours hours", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { viewModel.requestExtension(booking.id) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen)
                ) {
                    Text("CONFIRM EXTENSION", fontWeight = FontWeight.Bold)
                }

                if (extMsg != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(extMsg!!, fontWeight = FontWeight.Bold, color = LondonRed, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // RETURN CAR
        Button(
            onClick = { viewModel.startReturnCheck(booking.id) },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("return_vehicle_button"),
            colors = ButtonDefaults.buttonColors(containerColor = LondonRed)
        ) {
            Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("PROCEED TO RETURN EXPERIENCE", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ReturnInspectionScreen(viewModel: MainViewModel, booking: Booking) {
    val pFront by viewModel.photoFrontTaken.collectAsState()
    val pRear by viewModel.photoRearTaken.collectAsState()
    val pLeft by viewModel.photoLeftTaken.collectAsState()
    val pRight by viewModel.photoRightTaken.collectAsState()
    val pInt by viewModel.photoInteriorTaken.collectAsState()
    val fuelObserved by viewModel.fuelLevelObserved.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("RETURN YOUR CAR", style = MaterialTheme.typography.displayMedium, color = BritishRacingGreen)
        Text("Vehicle Handover & Handback Protocol", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Return area: " + booking.returnBranchName, fontWeight = FontWeight.Bold)
                Text("Please park in any empty English Motor bay, photograph vehicle state, and lock.", fontSize = 12.sp, color = Color.Gray)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text("DIGITAL PHOTOS", style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PhotoCheckItem("Front bumper & grill", pFront, { viewModel.photoFrontTaken.value = it })
            PhotoCheckItem("Rear bumper & exhaust", pRear, { viewModel.photoRearTaken.value = it })
            PhotoCheckItem("Left panels", pLeft, { viewModel.photoLeftTaken.value = it })
            PhotoCheckItem("Right panels", pRight, { viewModel.photoRightTaken.value = it })
            PhotoCheckItem("Interior state", pInt, { viewModel.photoInteriorTaken.value = it })
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Observed Fuel/Battery level", fontWeight = FontWeight.Bold)
            Text("$fuelObserved%", fontWeight = FontWeight.Bold, color = BritishRacingGreen)
        }
        Slider(
            value = fuelObserved.toFloat(),
            onValueChange = { viewModel.fuelLevelObserved.value = it.toInt() },
            valueRange = 0f..100f
        )

        Spacer(modifier = Modifier.height(24.dp))

        val allPhotosTaken = pFront && pRear && pLeft && pRight && pInt

        Button(
            onClick = { 
                viewModel.completeReturnCheck(booking.id, booking.currentMileage + 35) // assume 35 additional miles driven since pickup
            },
            enabled = allPhotosTaken,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("complete_return_button"),
            colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen)
        ) {
            Text("LOCK VEHICLE & SUBMIT HANDBACK", fontWeight = FontWeight.Bold)
        }
    }
}


// ==========================================
// 3. ACCOUNT & CLUB MEMBERSHIP TAB
// ==========================================
@Composable
fun AccountTab(viewModel: MainViewModel) {
    var dvlaChecked by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("ENGLISH MOTOR CLUB", style = MaterialTheme.typography.displayMedium, color = BritishRacingGreen)
        Text("Your Loyalty, Digital Licence, & Membership Details", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)

        Spacer(modifier = Modifier.height(20.dp))

        // Membership Gold badge
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DeepNavy)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("CLUB STATUS: MEMBER", color = WarmWhite, style = MaterialTheme.typography.labelMedium)
                Text("Thomas Harrison", style = MaterialTheme.typography.displayMedium, color = WarmWhite)
                Text("Loyalty Tier: Premium British Explorer", fontSize = 12.sp, color = SoftGrey)
                Spacer(modifier = Modifier.height(12.dp))
                Text("• 8% discount pre-applied on all luxury classes\n• Complimentary additional driver included\n• High priority keyless car selection enabled", fontSize = 11.sp, color = SoftGrey)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // DVLA License Verification
        Text("DVLA DRIVING LICENCE VERIFICATION", style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("UK driving regulations require digital validation of penalty points via the DVLA share code.", fontSize = 11.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Licence: HARRI910514TH999", fontWeight = FontWeight.Bold)
                        Text(
                            text = if (dvlaChecked) "VERIFIED: ELIGIBLE (0 POINTS)" else "UNVERIFIED",
                            fontWeight = FontWeight.Bold,
                            color = if (dvlaChecked) BritishRacingGreen else LondonRed,
                            fontSize = 11.sp
                        )
                    }

                    Button(
                        onClick = { dvlaChecked = true },
                        colors = ButtonDefaults.buttonColors(containerColor = if (dvlaChecked) BritishRacingGreen else DeepNavy),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                    ) {
                        Text(if (dvlaChecked) "Verified" else "Simulate DVLA check", fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // GDPR Privacy Options
        Text("GDPR COMPLIANCE & PRIVACY", style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Under standard UK data regulations, you have full control over stored driver telemetry.", fontSize = 11.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { /* simulated json download */ },
                    colors = ButtonDefaults.buttonColors(containerColor = SoftGrey, contentColor = Graphite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Download, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Export My PII Data File (JSON)")
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { /* simulated delete */ },
                    colors = ButtonDefaults.buttonColors(containerColor = LondonRed.copy(alpha = 0.1f), contentColor = LondonRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Right to Erasure (Delete Account)")
                }
            }
        }
    }
}


// ==========================================
// 4. SUPPORT CENTRE TAB
// ==========================================
@Composable
fun SupportTab(viewModel: MainViewModel) {
    val activeBooking by viewModel.activeBooking.collectAsState()
    val ticketSubject by viewModel.ticketSubject.collectAsState()
    val ticketDescription by viewModel.ticketDescription.collectAsState()
    val statusMsg by viewModel.ticketStatusMessage.collectAsState()
    val tickets by viewModel.supportTickets.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("SUPPORT CENTRE", style = MaterialTheme.typography.displayMedium, color = BritishRacingGreen)
        Text("Help, Emergency Roadside & Assistance Tickets", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)

        Spacer(modifier = Modifier.height(20.dp))

        // EMERGENCY HELPLINE
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LondonRed.copy(alpha = 0.1f)),
            border = BorderStroke(1.5.dp, LondonRed)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("NEED EMERGENCY HELPLINE?", fontWeight = FontWeight.Bold, color = LondonRed, style = MaterialTheme.typography.titleMedium)
                Text("In case of standard vehicle breakdown, flat tire, or warning indicators:", fontSize = 12.sp, color = Graphite)
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Call, contentDescription = null, tint = LondonRed)
                    Text(" RAC Priority Breakdown Assistance: +44 (0) 800 123 4567", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // FAQ SECTION
        Text("POPULAR TOPICS", style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
        Spacer(modifier = Modifier.height(8.dp))

        FAQItem("How does the keyless collection work?", "For eligible vehicles marked 'Keyless Available', you don't need to visit the rental counter. Confirm driver verification and condition check on your mobile device to receive a digital Bluetooth key. Press 'Unlock' to instantly start your hire.")
        FAQItem("What is the fuel & EV charging return policy?", "All fuel vehicles must be returned with a full tank of fuel unless the pre-paid fuel option is selected. Electric vehicles must be returned with at least 80% charge unless the charging package was chosen.")
        FAQItem("Can I drive outside the UK border?", "Yes, but you must acquire the optional 'Cross-Border Travel' product during the checkout flow to ensure appropriate continental insurance coverage.")

        Spacer(modifier = Modifier.height(24.dp))

        // SUBMIT SUPPORT TICKET FORM
        Text("SUBMIT A SUPPORT TICKET", style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = ticketSubject,
                    onValueChange = { viewModel.ticketSubject.value = it },
                    label = { Text("Subject / Issue Topic") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = ticketDescription,
                    onValueChange = { viewModel.ticketDescription.value = it },
                    label = { Text("Explain your issue in detail") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { viewModel.submitSupportTicket(activeBooking?.id ?: "EM-DEMO") },
                    colors = ButtonDefaults.buttonColors(containerColor = BritishRacingGreen),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("SUBMIT TICKET", fontWeight = FontWeight.Bold)
                }

                if (statusMsg != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(statusMsg!!, fontWeight = FontWeight.Bold, color = BritishRacingGreen, fontSize = 12.sp)
                }
            }
        }

        if (tickets.isNotEmpty()) {
            Spacer(modifier = Modifier.height(24.dp))
            Text("YOUR TICKET HISTORY", style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
            Spacer(modifier = Modifier.height(8.dp))

            tickets.forEach { ticket ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftGrey)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(ticket.subject, fontWeight = FontWeight.Bold)
                            Text(ticket.status, color = BritishRacingGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                        Text(ticket.description, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. OPERATIONS DASHBOARD & ANALYTICS TAB (ADMIN)
// ==========================================
@Composable
fun AdminTab(viewModel: MainViewModel) {
    val vehicles by viewModel.vehicles.collectAsState()
    val bookings by viewModel.bookings.collectAsState()
    val events by viewModel.eventLogs.collectAsState()

    val utilMetrics = AnalyticsEngine.calculateUtilization(vehicles)
    val forecasts = AnalyticsEngine.generateDemandForecast(bookings)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("OPERATIONS PORTAL", style = MaterialTheme.typography.displayMedium, color = BritishRacingGreen)
        Text("Internal Fleet Telemetry & Immutable Event Audit Logs", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)

        Spacer(modifier = Modifier.height(20.dp))

        // CORE METRICS GRID
        Text("FLEET STATUS & UTILIZATION", style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("Total Fleet", "${utilMetrics.totalFleetSize}", Modifier.weight(1f))
            MetricCard("On Hire", "${utilMetrics.onRentalCount}", Modifier.weight(1f))
            MetricCard("Utilization", String.format("%.1f%%", utilMetrics.overallUtilizationPercent), Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("In Cleaning", "${utilMetrics.cleaningCount}", Modifier.weight(1f))
            MetricCard("In Repair", "${utilMetrics.maintenanceCount}", Modifier.weight(1f))
            MetricCard("EV On Hire", String.format("%.1f%%", utilMetrics.evUtilizationPercent), Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(24.dp))

        // ggplot2 DEMAND FORECAST ANALYTICS REPRESENTATION (R COMPATIBLE)
        Text("7-DAY STATISTICAL DEMAND FORECAST (R FABLE)", style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
        Text("Fitted with Holt-Winters Exponential Smoothing & 95% Confidence Intervals", fontSize = 11.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Simple bar representing predicted volume per day
                forecasts.forEach { point ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(point.label, fontWeight = FontWeight.Bold, modifier = Modifier.width(60.dp), fontSize = 11.sp)
                        
                        // Custom progress bar chart for forecast
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(16.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(SoftGrey)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(fraction = (point.forecastedDemandCount / 20.0).toFloat().coerceIn(0.1f, 1.0f))
                                    .background(BritishRacingGreen)
                            )
                        }
                        
                        Text(
                            text = "${point.forecastedDemandCount} cars",
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(start = 12.dp),
                            fontSize = 11.sp,
                            color = BritishRacingGreen
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // IMMUTABLE EVENT AUDIT LOG TRAIL (SHA-256 integrity check)
        Text("IMMUTABLE AUDIT LOG (EVENT HISTORY)", style = MaterialTheme.typography.titleMedium, color = BritishRacingGreen)
        Text("System health & cryptographic tamper-evident record of operations", fontSize = 11.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp),
            colors = CardDefaults.cardColors(containerColor = Graphite)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
            ) {
                items(events) { log ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(log.eventType, color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            val df = SimpleDateFormat("HH:mm:ss", Locale.UK)
                            Text(df.format(Date(log.timestamp)), color = SoftGrey.copy(alpha = 0.7f), fontSize = 10.sp)
                        }
                        Text(log.description, color = SoftGrey, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
                        
                        // Hash visualization (first 16 characters)
                        Text(
                            text = "SHA256: " + log.hash.take(16) + "...",
                            color = AmberWarning,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        HorizontalDivider(color = Color.DarkGray, thickness = 0.5.dp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

// ==========================================
// BOTTOM/GLOBAL HELPER COMPOSABLES
// ==========================================

@Composable
fun SpecificationChip(label: String, valStr: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(SoftGrey)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text("$label: $valStr", fontSize = 11.sp, color = Graphite)
    }
}

@Composable
fun CoverOptionRow(
    level: CoverLevel,
    selected: Boolean,
    price: String,
    excess: String,
    desc: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .border(
                1.5.dp,
                if (selected) BritishRacingGreen else Color.Transparent,
                RoundedCornerShape(8.dp)
            ),
        colors = CardDefaults.cardColors(containerColor = if (selected) BritishRacingGreen.copy(alpha = 0.05f) else MaterialTheme.colorScheme.surface)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = selected, onClick = onClick)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(level.name + " COVER", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                    Text(price, fontWeight = FontWeight.Bold, color = BritishRacingGreen, fontSize = 13.sp)
                }
                Text(excess, color = LondonRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(desc, fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable
fun ExtraToggleRow(name: String, priceStr: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(priceStr, fontSize = 11.sp, color = Color.Gray)
            }
            Switch(checked = checked, onCheckedChange = onChecked)
        }
    }
}

@Composable
fun PricingRow(label: String, priceStr: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 13.sp)
        Text(priceStr, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun StepIndicatorItem(label: String, active: Boolean) {
    Text(
        text = label,
        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
        color = if (active) BritishRacingGreen else Color.Gray,
        fontSize = 12.sp
    )
}

@Composable
fun PhotoCheckItem(label: String, taken: Boolean, onTake: (Boolean) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (taken) Icons.Default.CheckCircle else Icons.Default.CameraAlt,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = if (taken) BritishRacingGreen else Color.Gray
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Button(
                onClick = { onTake(!taken) },
                colors = ButtonDefaults.buttonColors(containerColor = if (taken) BritishRacingGreen else SoftGrey, contentColor = if (taken) Color.White else Graphite),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
            ) {
                Text(if (taken) "Change Photo" else "Take Photo", fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun FAQItem(q: String, a: String) {
    var expanded by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(q, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null)
            }
            if (expanded) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(a, fontSize = 12.sp, color = Color.DarkGray)
            }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.Center)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = BritishRacingGreen)
        }
    }
}
