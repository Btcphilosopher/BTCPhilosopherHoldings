package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// British Motor Rental Color Palette
val BritishRacingGreen = Color(0xFF004225)
val DeepNavy = Color(0xFF001F54)
val LondonRed = Color(0xFFB3191F)
val Graphite = Color(0xFF1C1D1F)
val Charcoal = Color(0xFF2C2D30)
val WarmWhite = Color(0xFFFAF8F5)
val SoftGrey = Color(0xFFEFECE6)
val AmberWarning = Color(0xFFD97706)

// Light Palette Colors
val LightPrimary = BritishRacingGreen
val LightSecondary = DeepNavy
val LightTertiary = LondonRed
val LightBackground = WarmWhite
val LightSurface = Color.White
val LightOnPrimary = Color.White
val LightOnSecondary = Color.White
val LightOnBackground = Graphite
val LightOnSurface = Graphite

// Dark Palette Colors
val DarkPrimary = Color(0xFF4D9C73)
val DarkSecondary = Color(0xFF74A2E6)
val DarkTertiary = Color(0xFFE25B60)
val DarkBackground = Graphite
val DarkSurface = Charcoal
val DarkOnPrimary = Graphite
val DarkOnSecondary = Graphite
val DarkOnBackground = WarmWhite
val DarkOnSurface = WarmWhite
