package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// --- ENUMS & CORE VALUES ---

enum class VehicleClass {
    CITY, ECONOMY, COMPACT, FAMILY, ESTATE, SUV, PREMIUM, EXECUTIVE, LUXURY, ELECTRIC, SEVEN_SEAT, VAN, LONG_TERM
}

enum class VehicleStatus {
    AVAILABLE, MAINTENANCE, CLEANING, ON_RENTAL, CHARGING
}

enum class BranchType {
    CITY, AIRPORT, RAILWAY
}

enum class CoverLevel {
    BASIC, STANDARD, PREMIUM
}

enum class BookingState {
    SEARCHED, QUOTED, HELD, PENDING_PAYMENT, CONFIRMED, READY_FOR_PICKUP, CHECKING_IN, ACTIVE, EXTENSION_REQUESTED, RETURNING, INSPECTION, COMPLETED, CANCELLED, NO_SHOW
}

// --- DOMAIN MODELS ---

data class User(
    val id: String,
    val email: String,
    val name: String,
    val isCorporate: Boolean = false,
    val membershipLevel: String = "Standard" // "Standard", "Club Member" (English Motor Club)
)

data class Driver(
    val name: String,
    val dateOfBirth: String,
    val email: String,
    val phone: String,
    val drivingLicence: DrivingLicence
)

data class DrivingLicence(
    val licenceNumber: String,
    val country: String,
    val issueDate: String,
    val expiryDate: String,
    val verified: Boolean = false,
    val checkCode: String = "" // DVLA share code
)

@Entity(tableName = "vehicles")
data class Vehicle(
    @PrimaryKey val id: String,
    val registration: String,
    val name: String,
    val category: VehicleClass,
    val transmission: String, // "Automatic", "Manual"
    val fuelType: String,      // "Petrol", "Diesel", "Hybrid", "Plug-in Hybrid", "Electric"
    val seats: Int,
    val doors: Int,
    val luggageLarge: Int,
    val luggageSmall: Int,
    val drivetrain: String,    // "Front-Wheel Drive", "Rear-Wheel Drive", "All-Wheel Drive"
    val dailyPrice: Double,
    val mileagePolicy: String = "Unlimited Mileage",
    val depositAmount: Double = 250.0,
    val excessAmount: Double = 1000.0,
    val imageUrl: String = "",
    val color: String = "British Racing Green",
    val rating: Double = 4.8,
    val batteryPercent: Int = 100, // For EVs
    val estimatedRangeMiles: Int = 250,
    val currentBranchId: String,
    val status: VehicleStatus = VehicleStatus.AVAILABLE,
    val keylessAvailable: Boolean = true
)

@Entity(tableName = "branches")
data class Branch(
    @PrimaryKey val id: String,
    val name: String,
    val city: String,
    val type: BranchType,
    val latitude: Double,
    val longitude: Double,
    val terminalInfo: String = "",
    val walkingInstructions: String = "",
    val operatingHours: String = "06:00 - 23:00",
    val additionalAirportCharges: Double = 0.0,
    val phone: String = "+44 (0) 20 7946 0192"
)

@Entity(tableName = "bookings")
data class Booking(
    @PrimaryKey val id: String, // e.g. EM-2026-7A8B
    val vehicleId: String,
    val vehicleName: String,
    val vehicleCategory: VehicleClass,
    val pickupBranchId: String,
    val pickupBranchName: String,
    val returnBranchId: String,
    val returnBranchName: String,
    val pickupTime: Long,
    val returnTime: Long,
    val originalReturnTime: Long, // Saved for extension checks
    val basePrice: Double,
    val totalPaid: Double,
    val depositAmount: Double,
    val status: BookingState,
    
    // Driver Details
    val driverName: String,
    val driverDob: String,
    val driverEmail: String,
    val driverPhone: String,
    val driverLicenceNumber: String,
    val driverLicenceCountry: String,
    
    // Cover & Extras
    val coverLevel: CoverLevel = CoverLevel.BASIC,
    val coverPrice: Double = 0.0,
    val selectedExtrasJson: String = "[]", // List of Extra
    
    // Operational State
    val currentMileage: Int = 12050,
    val currentFuelPercent: Int = 100,
    val currentBatteryPercent: Int = 100,
    val vehicleRegistration: String = "",
    val vehicleColor: String = "",
    val isKeyless: Boolean = false,
    val qrCodeUrl: String = "",
    val isCorporate: Boolean = false,
    val costCentre: String = ""
)

data class PriceComponent(
    val name: String,
    val amount: Double,
    val isMandatory: Boolean = true
)

data class PriceBreakdown(
    val baseRental: Double,
    val locationCharges: Double,
    val coverCharge: Double,
    val extrasCharge: Double,
    val discountAmount: Double,
    val vatAmount: Double,
    val deposit: Double,
    val totalAmount: Double
)

data class Extra(
    val name: String,
    val pricePerDay: Double,
    val isSelected: Boolean = false,
    val description: String = ""
)

@Entity(tableName = "damage_reports")
data class DamageReport(
    @PrimaryKey val id: String, // DR-XXXX
    val bookingId: String,
    val vehicleId: String,
    val reportedTime: Long,
    val isCompleted: Boolean = false,
    val description: String = "",
    val damageItemsJson: String = "[]", // Serialized List<DamageItem>
    val photosJson: String = "[]" // Serialized List<String>
)

data class DamageItem(
    val area: String, // "Front", "Rear", "Left", "Right", "Wheels", "Windscreen", "Interior"
    val severity: String, // "Light Scratch", "Scuff", "Dent", "Crack"
    val description: String,
    val photoUrl: String = ""
)

@Entity(tableName = "inspections")
data class Inspection(
    @PrimaryKey val id: String, // IN-XXXX
    val bookingId: String,
    val type: String, // "PICKUP" or "RETURN"
    val timestamp: Long,
    val inspectorName: String = "Digital Condition Service",
    val mileage: Int,
    val fuelPercent: Int,
    val batteryPercent: Int,
    val exteriorOk: Boolean,
    val interiorOk: Boolean,
    val damageReported: Boolean,
    val damageItemsJson: String = "[]"
)

@Entity(tableName = "event_logs")
data class EventLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val eventType: String, // e.g. "BookingCreated"
    val description: String,
    val bookingId: String = "",
    val vehicleId: String = "",
    val actor: String = "System",
    val hash: String = "" // Simulates immutable signature hash
)

@Entity(tableName = "support_tickets")
data class SupportTicket(
    @PrimaryKey val id: String, // TK-XXXX
    val bookingId: String = "",
    val category: String, // "Booking", "Pickup", "Vehicle", "Damage", "Breakdown"
    val subject: String,
    val description: String,
    val status: String = "OPEN", // "OPEN", "RESOLVED"
    val createdAt: Long = System.currentTimeMillis()
)

data class EVChargingSession(
    val sessionId: String,
    val chargerId: String,
    val branchName: String,
    val batteryStartPercent: Int,
    val batteryEndPercent: Int,
    val energyKwh: Double,
    val durationMinutes: Int,
    val cost: Double
)

data class NotificationMessage(
    val id: String,
    val title: String,
    val body: String,
    val timestamp: Long,
    val read: Boolean = false
)

data class VehicleTelemetry(
    val id: String,
    val latitude: Double,
    val longitude: Double,
    val fuelPercent: Int,
    val batteryPercent: Int,
    val odometer: Int,
    val speedKmph: Double = 0.0,
    val locked: Boolean = true
)
