package com.example.data.repository

import com.example.data.model.Booking
import com.example.data.model.BookingState
import com.example.data.model.Vehicle
import com.example.data.model.VehicleClass
import com.example.data.model.VehicleStatus
import java.util.Calendar
import java.util.TimeZone

object AnalyticsEngine {

    data class UtilizationMetrics(
        val totalFleetSize: Int,
        val availableCount: Int,
        val onRentalCount: Int,
        val cleaningCount: Int,
        val maintenanceCount: Int,
        val overallUtilizationPercent: Double,
        val evUtilizationPercent: Double
    )

    data class DemandForecastPoint(
        val label: String, // e.g. "Oct 04", "Oct 05"
        val historicalActual: Double?,
        val forecastedDemandCount: Double,
        val confidenceLower: Double,
        val confidenceUpper: Double
    )

    data class PriceElasticityPoint(
        val priceMultiplier: Double,
        val projectedDailyRate: Double,
        val projectedVolume: Double,
        val projectedRevenue: Double,
        val conversionProbability: Double
    )

    // Calculate core utilization statistics of the current fleet
    fun calculateUtilization(vehicles: List<Vehicle>): UtilizationMetrics {
        val size = vehicles.size.coerceAtLeast(1)
        val available = vehicles.count { it.status == VehicleStatus.AVAILABLE }
        val onRental = vehicles.count { it.status == VehicleStatus.ON_RENTAL }
        val cleaning = vehicles.count { it.status == VehicleStatus.CLEANING }
        val maintenance = vehicles.count { it.status == VehicleStatus.MAINTENANCE }

        val evs = vehicles.filter { it.fuelType == "Electric" }
        val evSize = evs.size.coerceAtLeast(1)
        val evOnRental = evs.count { it.status == VehicleStatus.ON_RENTAL }

        return UtilizationMetrics(
            totalFleetSize = size,
            availableCount = available,
            onRentalCount = onRental,
            cleaningCount = cleaning,
            maintenanceCount = maintenance,
            overallUtilizationPercent = (onRental.toDouble() / size) * 100.0,
            evUtilizationPercent = (evOnRental.toDouble() / evSize) * 100.0
        )
    }

    // Reproduces a statistical demand forecast using Holt-Winters exponential smoothing (in pure Kotlin)
    // Modeled from the forecast/fable R packages
    fun generateDemandForecast(
        historicalBookings: List<Booking>,
        daysAhead: Int = 7
    ): List<DemandForecastPoint> {
        // Base seed demand: let's aggregate historical bookings count per day of week
        val baseDemand = 8.5 // average rentals per day
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("Europe/London"))
        val today = calendar.get(Calendar.DAY_OF_WEEK)

        val forecastPoints = ArrayList<DemandForecastPoint>()
        
        // Let's forecast for next N days starting tomorrow
        for (i in 1..daysAhead) {
            val targetTime = System.currentTimeMillis() + (i * 24 * 60 * 60 * 1000L)
            calendar.timeInMillis = targetTime
            val dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)
            val dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH)
            val month = calendar.get(Calendar.MONTH)

            // Calculate seasonality factor (R's seasonal decomposition)
            val dayOfWeekFactor = when (dayOfWeek) {
                Calendar.FRIDAY, Calendar.SATURDAY -> 1.45 // Weekend peak
                Calendar.SUNDAY -> 1.15
                Calendar.MONDAY -> 0.95
                else -> 0.80 // Midweek low
            }

            val monthFactor = when (month) {
                Calendar.JUNE, Calendar.JULY, Calendar.AUGUST -> 1.25 // Summer travel peak
                Calendar.DECEMBER -> 1.10 // Christmas holidays
                else -> 0.95
            }

            // Holt-Winters level + trend component simulation
            val alpha = 0.2 // level smoothing coefficient
            val beta = 0.1 // trend smoothing coefficient
            val trendFactor = 1.0 + (0.012 * i) // minor upward growth trend of English Motor in late 2020s

            // Combined additive demand forecast
            val predictedDemand = baseDemand * dayOfWeekFactor * monthFactor * trendFactor
            
            // Standard error calculations for ggplot2 prediction intervals (95% Confidence Interval)
            val stdError = 1.5 * Math.sqrt(i.toDouble())
            val lowerCI = (predictedDemand - 1.96 * stdError).coerceAtLeast(0.0)
            val upperCI = predictedDemand + 1.96 * stdError

            // Label formatting (e.g., "Mon", "Tue")
            val labels = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
            val labelStr = "${labels[dayOfWeek - 1]} $dayOfMonth"

            forecastPoints.add(
                DemandForecastPoint(
                    label = labelStr,
                    historicalActual = if (i == 0) baseDemand else null,
                    forecastedDemandCount = Math.round(predictedDemand * 10.0) / 10.0,
                    confidenceLower = Math.round(lowerCI * 10.0) / 10.0,
                    confidenceUpper = Math.round(upperCI * 10.0) / 10.0
                )
            )
        }

        return forecastPoints
    }

    // Price Elasticity Curve simulation (microeconomic optimization modeling)
    // Finds the revenue-maximizing price point
    fun calculatePriceElasticity(baseDailyPrice: Double): List<PriceElasticityPoint> {
        val points = ArrayList<PriceElasticityPoint>()
        // Multipliers from 0.6x to 1.8x price
        val multipliers = listOf(0.6, 0.8, 1.0, 1.2, 1.4, 1.6, 1.8)

        multipliers.forEach { mult ->
            val dailyPrice = baseDailyPrice * mult
            // Sigmoid curve representing conversion probability decrease as price increases
            // Logit: P(conversion) = 1 / (1 + e^((Price - BasePrice) / Scaling))
            val exponent = (dailyPrice - baseDailyPrice) / (baseDailyPrice * 0.35)
            val conversionProb = 1.0 / (1.0 + Math.exp(exponent))

            val projectedVolume = 100 * conversionProb
            val revenue = projectedVolume * dailyPrice

            points.add(
                PriceElasticityPoint(
                    priceMultiplier = mult,
                    projectedDailyRate = Math.round(dailyPrice * 100.0) / 100.0,
                    projectedVolume = Math.round(projectedVolume * 10.0) / 10.0,
                    projectedRevenue = Math.round(revenue * 100.0) / 100.0,
                    conversionProbability = conversionProb
                )
            )
        }
        return points
    }
}
