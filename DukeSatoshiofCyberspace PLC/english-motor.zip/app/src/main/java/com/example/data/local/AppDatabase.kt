package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.Update
import com.example.data.model.Booking
import com.example.data.model.Branch
import com.example.data.model.DamageReport
import com.example.data.model.EventLog
import com.example.data.model.Inspection
import com.example.data.model.SupportTicket
import com.example.data.model.Vehicle
import kotlinx.coroutines.flow.Flow

@Dao
interface BranchDao {
    @Query("SELECT * FROM branches")
    fun getAllBranches(): Flow<List<Branch>>

    @Query("SELECT * FROM branches")
    suspend fun getAllBranchesSync(): List<Branch>

    @Query("SELECT * FROM branches WHERE id = :id")
    suspend fun getBranchById(id: String): Branch?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBranches(branches: List<Branch>)
}

@Dao
interface VehicleDao {
    @Query("SELECT * FROM vehicles")
    fun getAllVehicles(): Flow<List<Vehicle>>

    @Query("SELECT * FROM vehicles")
    suspend fun getAllVehiclesSync(): List<Vehicle>

    @Query("SELECT * FROM vehicles WHERE id = :id")
    suspend fun getVehicleById(id: String): Vehicle?

    @Query("SELECT * FROM vehicles WHERE currentBranchId = :branchId")
    suspend fun getVehiclesByBranch(branchId: String): List<Vehicle>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicles(vehicles: List<Vehicle>)

    @Update
    suspend fun updateVehicle(vehicle: Vehicle)

    @Query("UPDATE vehicles SET status = :status WHERE id = :id")
    suspend fun updateVehicleStatus(id: String, status: String)
}

@Dao
interface BookingDao {
    @Query("SELECT * FROM bookings ORDER BY pickupTime DESC")
    fun getAllBookings(): Flow<List<Booking>>

    @Query("SELECT * FROM bookings ORDER BY pickupTime DESC")
    suspend fun getAllBookingsSync(): List<Booking>

    @Query("SELECT * FROM bookings WHERE id = :id")
    fun getBookingByIdFlow(id: String): Flow<Booking?>

    @Query("SELECT * FROM bookings WHERE id = :id")
    suspend fun getBookingById(id: String): Booking?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: Booking)

    @Update
    suspend fun updateBooking(booking: Booking)
}

@Dao
interface DamageReportDao {
    @Query("SELECT * FROM damage_reports")
    fun getAllDamageReports(): Flow<List<DamageReport>>

    @Query("SELECT * FROM damage_reports WHERE bookingId = :bookingId")
    suspend fun getDamageReportsForBooking(bookingId: String): List<DamageReport>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDamageReport(report: DamageReport)
}

@Dao
interface InspectionDao {
    @Query("SELECT * FROM inspections")
    fun getAllInspections(): Flow<List<Inspection>>

    @Query("SELECT * FROM inspections WHERE bookingId = :bookingId")
    suspend fun getInspectionsForBooking(bookingId: String): List<Inspection>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInspection(inspection: Inspection)
}

@Dao
interface EventLogDao {
    @Query("SELECT * FROM event_logs ORDER BY timestamp DESC")
    fun getAllEventLogs(): Flow<List<EventLog>>

    @Query("SELECT * FROM event_logs ORDER BY timestamp DESC")
    suspend fun getAllEventLogsSync(): List<EventLog>

    @Query("SELECT * FROM event_logs WHERE bookingId = :bookingId ORDER BY timestamp DESC")
    suspend fun getEventLogsForBooking(bookingId: String): List<EventLog>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEventLog(eventLog: EventLog)
}

@Dao
interface SupportTicketDao {
    @Query("SELECT * FROM support_tickets ORDER BY createdAt DESC")
    fun getAllTickets(): Flow<List<SupportTicket>>

    @Query("SELECT * FROM support_tickets WHERE bookingId = :bookingId ORDER BY createdAt DESC")
    suspend fun getTicketsForBooking(bookingId: String): List<SupportTicket>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: SupportTicket)
}

@Database(
    entities = [
        Branch::class,
        Vehicle::class,
        Booking::class,
        DamageReport::class,
        Inspection::class,
        EventLog::class,
        SupportTicket::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun branchDao(): BranchDao
    abstract fun vehicleDao(): VehicleDao
    abstract fun bookingDao(): BookingDao
    abstract fun damageReportDao(): DamageReportDao
    abstract fun inspectionDao(): InspectionDao
    abstract fun eventLogDao(): EventLogDao
    abstract fun supportTicketDao(): SupportTicketDao
}
