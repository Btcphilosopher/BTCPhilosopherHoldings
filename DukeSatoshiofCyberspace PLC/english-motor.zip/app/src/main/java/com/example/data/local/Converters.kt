package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.BranchType
import com.example.data.model.BookingState
import com.example.data.model.CoverLevel
import com.example.data.model.VehicleClass
import com.example.data.model.VehicleStatus

class Converters {
    @TypeConverter
    fun fromVehicleClass(value: VehicleClass): String = value.name

    @TypeConverter
    fun toVehicleClass(value: String): VehicleClass = VehicleClass.valueOf(value)

    @TypeConverter
    fun fromVehicleStatus(value: VehicleStatus): String = value.name

    @TypeConverter
    fun toVehicleStatus(value: String): VehicleStatus = VehicleStatus.valueOf(value)

    @TypeConverter
    fun fromBranchType(value: BranchType): String = value.name

    @TypeConverter
    fun toBranchType(value: String): BranchType = BranchType.valueOf(value)

    @TypeConverter
    fun fromCoverLevel(value: CoverLevel): String = value.name

    @TypeConverter
    fun toCoverLevel(value: String): CoverLevel = CoverLevel.valueOf(value)

    @TypeConverter
    fun fromBookingState(value: BookingState): String = value.name

    @TypeConverter
    fun toBookingState(value: String): BookingState = BookingState.valueOf(value)
}
