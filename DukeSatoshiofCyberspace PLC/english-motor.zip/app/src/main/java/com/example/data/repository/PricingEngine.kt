package com.example.data.repository

import com.example.data.model.Branch
import com.example.data.model.BranchType
import com.example.data.model.CoverLevel
import com.example.data.model.Extra
import com.example.data.model.PriceBreakdown
import com.example.data.model.Vehicle
import com.example.data.model.VehicleClass
import java.util.Calendar
import java.util.TimeZone

object PricingEngine {
    
    fun calculatePrice(
        vehicle: Vehicle,
        pickupBranch: Branch,
        returnBranch: Branch,
        pickupTimeMillis: Long,
        returnTimeMillis: Long,
        driverAge: Int = 30,
        coverLevel: CoverLevel = CoverLevel.BASIC,
        selectedExtras: List<Extra> = emptyList(),
        isCorporate: Boolean = false,
        membershipLevel: String = "Standard"
    ): PriceBreakdown {
        // 1. Duration Calculation (Minimum 1 day, rounded up)
        val diffMillis = returnTimeMillis - pickupTimeMillis
        val diffDays = Math.ceil(diffMillis.toDouble() / (1000 * 60 * 60 * 24)).toInt().coerceAtLeast(1)

        // 2. Base Rental with Seasonality & Long-term Discount
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("Europe/London"))
        calendar.timeInMillis = pickupTimeMillis
        val month = calendar.get(Calendar.MONTH) // 0-11
        
        // Summer peak (June, July, August) + Christmas peak (December)
        val seasonalMultiplier = when (month) {
            Calendar.JUNE, Calendar.JULY, Calendar.AUGUST -> 1.25
            Calendar.DECEMBER -> 1.15
            else -> 1.0
        }

        // Long-term progressive discounts: 7d (10%), 14d (15%), 30d+ (25%)
        val durationDiscountFactor = when {
            diffDays >= 30 -> 0.75
            diffDays >= 14 -> 0.85
            diffDays >= 7 -> 0.90
            else -> 1.0
        }

        val dailyRate = vehicle.dailyPrice * seasonalMultiplier * durationDiscountFactor
        val rawBaseRental = dailyRate * diffDays

        // 3. Location Specific Charges (Airport Fees / Station Surcharges)
        var locationCharges = 0.0
        if (pickupBranch.type == BranchType.AIRPORT) {
            locationCharges += pickupBranch.additionalAirportCharges.coerceAtLeast(45.0) // Airport access fee
        } else if (pickupBranch.type == BranchType.RAILWAY) {
            locationCharges += 20.0 // Railway infrastructure charge
        }

        // One-Way Rental Surcharge (relocation requirement)
        if (pickupBranch.id != returnBranch.id) {
            locationCharges += 75.0 // London to Manchester relocation etc.
        }

        // 4. Driver & Cover Fees
        var coverCharge = 0.0
        val dailyCoverRate = when (coverLevel) {
            CoverLevel.BASIC -> 0.0
            CoverLevel.STANDARD -> 12.50
            CoverLevel.PREMIUM -> 25.00
        }
        coverCharge += dailyCoverRate * diffDays

        // Surcharges
        var extraFees = 0.0
        if (driverAge < 25) {
            extraFees += 30.0 * diffDays // Young driver surcharge
        }

        // Selected Extras (Child seat, Sat nav, Additional driver, EV package)
        var extrasCharge = 0.0
        selectedExtras.forEach { extra ->
            extrasCharge += extra.pricePerDay * diffDays
        }
        extrasCharge += extraFees

        // 5. Membership & Corporate Discounts
        var discountAmount = 0.0
        if (isCorporate) {
            discountAmount += rawBaseRental * 0.15 // 15% corporate rate discount
        } else if (membershipLevel == "Club Member") {
            discountAmount += rawBaseRental * 0.08 // 8% Club Member discount
        }

        val preTaxTotal = (rawBaseRental + locationCharges + coverCharge + extrasCharge) - discountAmount
        
        // 6. VAT calculation (Standard 20% UK VAT included in final price representation)
        // VAT is computed from total taxable items
        val vatRate = 0.20
        val vatAmount = preTaxTotal * (vatRate / (1 + vatRate)) // 20% VAT inclusive calculation

        // 7. Security Deposit calculation (reduced with premium cover)
        val depositAmount = when (coverLevel) {
            CoverLevel.BASIC -> vehicle.depositAmount
            CoverLevel.STANDARD -> vehicle.depositAmount * 0.5
            CoverLevel.PREMIUM -> 50.0 // Premium cover reduces deposit to standard £50 card hold
        }

        return PriceBreakdown(
            baseRental = Math.round(rawBaseRental * 100.0) / 100.0,
            locationCharges = Math.round(locationCharges * 100.0) / 100.0,
            coverCharge = Math.round(coverCharge * 100.0) / 100.0,
            extrasCharge = Math.round(extrasCharge * 100.0) / 100.0,
            discountAmount = Math.round(discountAmount * 100.0) / 100.0,
            vatAmount = Math.round(vatAmount * 100.0) / 100.0,
            deposit = Math.round(depositAmount * 100.0) / 100.0,
            totalAmount = Math.round(preTaxTotal * 100.0) / 100.0
        )
    }
}
