package com.example.data.repository

import android.content.Context
import androidx.room.Room
import com.example.data.local.AppDatabase
import com.example.data.model.Booking
import com.example.data.model.BookingState
import com.example.data.model.Branch
import com.example.data.model.CoverLevel
import com.example.data.model.DamageItem
import com.example.data.model.DamageReport
import com.example.data.model.EventLog
import com.example.data.model.Extra
import com.example.data.model.Inspection
import com.example.data.model.SupportTicket
import com.example.data.model.Vehicle
import com.example.data.model.VehicleClass
import com.example.data.model.VehicleStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.util.UUID

class MotorRentalRepository(private val context: Context) {

    private val db: AppDatabase = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "english_motor_rental.db"
    ).fallbackToDestructiveMigration().build()

    private val branchDao = db.branchDao()
    private val vehicleDao = db.vehicleDao()
    private val bookingDao = db.bookingDao()
    private val damageReportDao = db.damageReportDao()
    private val inspectionDao = db.inspectionDao()
    private val eventLogDao = db.eventLogDao()
    private val supportTicketDao = db.supportTicketDao()

    init {
        // Trigger seeding in background
        kotlinx.coroutines.GlobalScope.launch(Dispatchers.IO) {
            seedIfNeeded()
        }
    }

    private suspend fun seedIfNeeded() {
        val existingBranches = branchDao.getAllBranchesSync()
        if (existingBranches.isEmpty()) {
            branchDao.insertBranches(SeedData.branches)
            vehicleDao.insertVehicles(SeedData.vehicles)
            
            // Log the initial system bootstrap event
            logEvent("SystemBootstrapped", "Fleet database initialized with dataset ENGLISH-MOTOR-DEMO-001", actor = "System")
        }
    }

    // --- IMMUTABLE AUDIT LOG GENERATION ---
    private suspend fun logEvent(
        eventType: String,
        description: String,
        bookingId: String = "",
        vehicleId: String = "",
        actor: String = "Customer"
    ) {
        val timestamp = System.currentTimeMillis()
        val rawSig = "$timestamp|$eventType|$description|$bookingId|$vehicleId|$actor"
        val hash = sha256(rawSig)

        val log = EventLog(
            timestamp = timestamp,
            eventType = eventType,
            description = description,
            bookingId = bookingId,
            vehicleId = vehicleId,
            actor = actor,
            hash = hash
        )
        eventLogDao.insertEventLog(log)
    }

    private fun sha256(input: String): String {
        return try {
            val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
            bytes.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            "error_hash"
        }
    }

    // --- GETTERS (FLOW & SYNC) ---
    fun getAllBranches(): Flow<List<Branch>> = branchDao.getAllBranches()
    suspend fun getBranchById(id: String): Branch? = branchDao.getBranchById(id)

    fun getAllVehicles(): Flow<List<Vehicle>> = vehicleDao.getAllVehicles()
    suspend fun getVehicleById(id: String): Vehicle? = vehicleDao.getVehicleById(id)

    fun getAllBookings(): Flow<List<Booking>> = bookingDao.getAllBookings()
    suspend fun getAllBookingsSync(): List<Booking> = bookingDao.getAllBookingsSync()
    fun getBookingByIdFlow(id: String): Flow<Booking?> = bookingDao.getBookingByIdFlow(id)
    suspend fun getBookingById(id: String): Booking? = bookingDao.getBookingById(id)

    fun getAllEventLogs(): Flow<List<EventLog>> = eventLogDao.getAllEventLogs()
    suspend fun getAllEventLogsSync(): List<EventLog> = eventLogDao.getAllEventLogsSync()

    fun getAllSupportTickets(): Flow<List<SupportTicket>> = supportTicketDao.getAllTickets()

    // --- JOURNEY 1 & 2: SEARCH & COMPARE ---
    suspend fun searchVehicles(
        pickupBranchId: String,
        returnBranchId: String,
        pickupTime: Long,
        returnTime: Long,
        vehicleClass: VehicleClass? = null
    ): List<Vehicle> = withContext(Dispatchers.IO) {
        val fleet = vehicleDao.getAllVehiclesSync()
        val allBookings = bookingDao.getAllBookingsSync()
        
        // Log query generation
        logEvent(
            eventType = "QuoteGenerated",
            description = "Search query processed for branch $pickupBranchId from $pickupTime to $returnTime"
        )

        AvailabilityEngine.calculateAvailableVehicles(
            fleet = fleet,
            bookings = allBookings,
            targetClass = vehicleClass,
            pickupBranchId = pickupBranchId,
            pickupTime = pickupTime,
            returnTime = returnTime
        )
    }

    // --- JOURNEY 3: BOOK & COVER & EXTRAS ---
    suspend fun createBooking(
        vehicleId: String,
        pickupBranchId: String,
        returnBranchId: String,
        pickupTime: Long,
        returnTime: Long,
        driverName: String,
        driverDob: String,
        driverEmail: String,
        driverPhone: String,
        driverLicenceNumber: String,
        driverLicenceCountry: String,
        coverLevel: CoverLevel,
        selectedExtras: List<Extra>,
        isCorporate: Boolean = false,
        costCentre: String = ""
    ): Booking = withContext(Dispatchers.IO) {
        val vehicle = vehicleDao.getVehicleById(vehicleId) ?: throw IllegalArgumentException("Vehicle not found")
        val pickupBranch = branchDao.getBranchById(pickupBranchId) ?: throw IllegalArgumentException("Pickup branch not found")
        val returnBranch = branchDao.getBranchById(returnBranchId) ?: throw IllegalArgumentException("Return branch not found")

        val breakdown = PricingEngine.calculatePrice(
            vehicle = vehicle,
            pickupBranch = pickupBranch,
            returnBranch = returnBranch,
            pickupTimeMillis = pickupTime,
            returnTimeMillis = returnTime,
            coverLevel = coverLevel,
            selectedExtras = selectedExtras,
            isCorporate = isCorporate
        )

        // Convert extras to json string
        val extrasJson = selectedExtras.filter { it.isSelected }.joinToString(prefix = "[", postfix = "]") { extra ->
            "{\"name\":\"${extra.name}\",\"pricePerDay\":${extra.pricePerDay}}"
        }

        val bookingId = "EM-${1000 + (Math.random() * 8999).toInt()}-${vehicle.registration.takeLast(4)}"

        val booking = Booking(
            id = bookingId,
            vehicleId = vehicle.id,
            vehicleName = vehicle.name,
            vehicleCategory = vehicle.category,
            pickupBranchId = pickupBranch.id,
            pickupBranchName = pickupBranch.name,
            returnBranchId = returnBranch.id,
            returnBranchName = returnBranch.name,
            pickupTime = pickupTime,
            returnTime = returnTime,
            originalReturnTime = returnTime,
            basePrice = breakdown.baseRental,
            totalPaid = breakdown.totalAmount,
            depositAmount = breakdown.deposit,
            status = BookingState.HELD, // Booking initially held awaiting payment
            driverName = driverName,
            driverDob = driverDob,
            driverEmail = driverEmail,
            driverPhone = driverPhone,
            driverLicenceNumber = driverLicenceNumber,
            driverLicenceCountry = driverLicenceCountry,
            coverLevel = coverLevel,
            coverPrice = breakdown.coverCharge,
            selectedExtrasJson = extrasJson,
            vehicleRegistration = vehicle.registration,
            vehicleColor = vehicle.color,
            isKeyless = vehicle.keylessAvailable,
            qrCodeUrl = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=$bookingId",
            isCorporate = isCorporate,
            costCentre = costCentre
        )

        bookingDao.insertBooking(booking)
        logEvent("BookingCreated", "Booking held for vehicle ${vehicle.name} ($bookingId)", bookingId, vehicle.id)
        booking
    }

    // --- JOURNEY 4: PAYMENT ---
    suspend fun processPaymentAndConfirm(bookingId: String, paymentMethod: String): Boolean = withContext(Dispatchers.IO) {
        val booking = bookingDao.getBookingById(bookingId) ?: return@withContext false
        
        val updatedBooking = booking.copy(
            status = BookingState.CONFIRMED
        )
        bookingDao.updateBooking(updatedBooking)

        logEvent("PaymentAuthorised", "Payment authorized via $paymentMethod for booking $bookingId", bookingId, booking.vehicleId)
        logEvent("BookingConfirmed", "Booking confirmed and locked in fleet schedule ($bookingId)", bookingId, booking.vehicleId)

        // Automatically assign vehicle ready status
        val updatedBookingReady = updatedBooking.copy(
            status = BookingState.READY_FOR_PICKUP
        )
        bookingDao.updateBooking(updatedBookingReady)
        logEvent("VehicleReady", "Vehicle ${booking.vehicleRegistration} valeted, charged/fueled and ready in bay", bookingId, booking.vehicleId)

        true
    }

    // --- JOURNEY 5: COLLECTION (INSPECT & UNLOCK) ---
    suspend fun startInspection(bookingId: String, type: String): Boolean = withContext(Dispatchers.IO) {
        val booking = bookingDao.getBookingById(bookingId) ?: return@withContext false
        val nextState = if (type == "PICKUP") BookingState.CHECKING_IN else BookingState.RETURNING
        
        bookingDao.updateBooking(booking.copy(status = nextState))
        logEvent("PickupStarted", "$type Inspection and digital condition check started", bookingId, booking.vehicleId)
        true
    }

    suspend fun completePickupInspection(
        bookingId: String,
        mileage: Int,
        fuelPercent: Int,
        batteryPercent: Int,
        exteriorOk: Boolean,
        interiorOk: Boolean,
        damageItems: List<DamageItem>
    ): Boolean = withContext(Dispatchers.IO) {
        val booking = bookingDao.getBookingById(bookingId) ?: return@withContext false
        
        // 1. Create Inspection record
        val inspectionId = "IN-${1000 + (Math.random() * 8999).toInt()}"
        val damageItemsJson = damageItems.joinToString(prefix = "[", postfix = "]") { item ->
            "{\"area\":\"${item.area}\",\"severity\":\"${item.severity}\",\"description\":\"${item.description}\"}"
        }

        val inspection = Inspection(
            id = inspectionId,
            bookingId = bookingId,
            type = "PICKUP",
            timestamp = System.currentTimeMillis(),
            mileage = mileage,
            fuelPercent = fuelPercent,
            batteryPercent = batteryPercent,
            exteriorOk = exteriorOk,
            interiorOk = interiorOk,
            damageReported = damageItems.isNotEmpty(),
            damageItemsJson = damageItemsJson
        )
        inspectionDao.insertInspection(inspection)

        // 2. Create Damage Report if damage detected
        if (damageItems.isNotEmpty()) {
            val reportId = "DR-${1000 + (Math.random() * 8999).toInt()}"
            val damageReport = DamageReport(
                id = reportId,
                bookingId = bookingId,
                vehicleId = booking.vehicleId,
                reportedTime = System.currentTimeMillis(),
                isCompleted = true,
                description = "Discovered during pre-rental pickup check",
                damageItemsJson = damageItemsJson
            )
            damageReportDao.insertDamageReport(damageReport)
            logEvent("DamageReported", "Condition anomalies logged: ${damageItems.size} items", bookingId, booking.vehicleId)
        }

        // 3. Transition to ACTIVE rental state & update vehicle status
        val updatedBooking = booking.copy(
            status = BookingState.ACTIVE,
            currentMileage = mileage,
            currentFuelPercent = fuelPercent,
            currentBatteryPercent = batteryPercent
        )
        bookingDao.updateBooking(updatedBooking)
        vehicleDao.updateVehicleStatus(booking.vehicleId, VehicleStatus.ON_RENTAL.name)

        logEvent("RentalStarted", "Vehicle ${booking.vehicleRegistration} unlocked & rental started. Drive safely.", bookingId, booking.vehicleId)
        true
    }

    // --- JOURNEY 6: EXTEND RENTAL ---
    suspend fun checkAndExtendRental(bookingId: String, extraHours: Int): Pair<Boolean, Double> = withContext(Dispatchers.IO) {
        val booking = bookingDao.getBookingById(bookingId) ?: return@withContext Pair(false, 0.0)
        val vehicle = vehicleDao.getVehicleById(booking.vehicleId) ?: return@withContext Pair(false, 0.0)

        // Calculate new return time
        val extraMillis = extraHours * 60 * 60 * 1000L
        val newReturnTime = booking.returnTime + extraMillis

        // 1. Availability validation (Check future bookings)
        val allBookings = bookingDao.getAllBookingsSync()
        val conflict = allBookings.any { other ->
            other.vehicleId == booking.vehicleId &&
            other.id != bookingId &&
            other.status != BookingState.CANCELLED &&
            other.status != BookingState.COMPLETED &&
            newReturnTime > (other.pickupTime - 2 * 60 * 60 * 1000L) &&
            booking.pickupTime < other.returnTime
        }

        if (conflict) {
            // Vehicle has future bookings! Relocation or other customer would be impacted
            return@withContext Pair(false, 0.0)
        }

        // Calculate extension cost based on simple daily rate proportional to extra hours
        val extensionCost = Math.round((vehicle.dailyPrice / 24.0) * extraHours * 1.15 * 100.0) / 100.0 // 15% premium extension surcharge

        // 2. Update Booking
        val updatedBooking = booking.copy(
            returnTime = newReturnTime,
            totalPaid = booking.totalPaid + extensionCost
        )
        bookingDao.updateBooking(updatedBooking)

        logEvent("RentalExtended", "Rental extended by $extraHours hours to ${java.util.Date(newReturnTime)}. Additional: £$extensionCost", bookingId, booking.vehicleId)
        Pair(true, extensionCost)
    }

    // --- JOURNEY 7: RETURN VEHICLE & INSPECT ---
    suspend fun completeReturnInspection(
        bookingId: String,
        mileage: Int,
        fuelPercent: Int,
        batteryPercent: Int,
        exteriorOk: Boolean,
        interiorOk: Boolean,
        damageItems: List<DamageItem>
    ): Boolean = withContext(Dispatchers.IO) {
        val booking = bookingDao.getBookingById(bookingId) ?: return@withContext false
        
        // 1. Create Return Inspection record
        val inspectionId = "IN-${1000 + (Math.random() * 8999).toInt()}"
        val damageItemsJson = damageItems.joinToString(prefix = "[", postfix = "]") { item ->
            "{\"area\":\"${item.area}\",\"severity\":\"${item.severity}\",\"description\":\"${item.description}\"}"
        }

        val inspection = Inspection(
            id = inspectionId,
            bookingId = bookingId,
            type = "RETURN",
            timestamp = System.currentTimeMillis(),
            mileage = mileage,
            fuelPercent = fuelPercent,
            batteryPercent = batteryPercent,
            exteriorOk = exteriorOk,
            interiorOk = interiorOk,
            damageReported = damageItems.isNotEmpty(),
            damageItemsJson = damageItemsJson
        )
        inspectionDao.insertInspection(inspection)

        // 2. Damage logger
        if (damageItems.isNotEmpty()) {
            val reportId = "DR-${1000 + (Math.random() * 8999).toInt()}"
            val damageReport = DamageReport(
                id = reportId,
                bookingId = bookingId,
                vehicleId = booking.vehicleId,
                reportedTime = System.currentTimeMillis(),
                isCompleted = true,
                description = "Logged during return inspection",
                damageItemsJson = damageItemsJson
            )
            damageReportDao.insertDamageReport(damageReport)
            logEvent("DamageReported", "New damage reported during return: ${damageItems.size} issues", bookingId, booking.vehicleId)
        }

        // 3. Mark booking as COMPLETED, free up the vehicle status (mark as CLEANING/AVAILABLE)
        val updatedBooking = booking.copy(
            status = BookingState.COMPLETED,
            currentMileage = mileage,
            currentFuelPercent = fuelPercent,
            currentBatteryPercent = batteryPercent
        )
        bookingDao.updateBooking(updatedBooking)

        // Free vehicle and update to charging/cleaning/available status
        val nextStatus = if (fuelPercent < 90 || batteryPercent < 90) VehicleStatus.CLEANING else VehicleStatus.AVAILABLE
        vehicleDao.updateVehicleStatus(booking.vehicleId, nextStatus.name)

        // If electric, update telemetry battery
        val vehicleObj = vehicleDao.getVehicleById(booking.vehicleId)
        if (vehicleObj != null && vehicleObj.fuelType == "Electric") {
            vehicleDao.updateVehicle(vehicleObj.copy(
                batteryPercent = batteryPercent,
                estimatedRangeMiles = (batteryPercent * 3.1).toInt(),
                status = nextStatus
            ))
        }

        logEvent("InspectionCompleted", "Digital return inspection successfully checked.", bookingId, booking.vehicleId)
        logEvent("RentalCompleted", "Vehicle returned to branch. Final mileage $mileage.", bookingId, booking.vehicleId)
        logEvent("DepositReleased", "Security deposit hold of £${booking.depositAmount} has been released to card provider.", bookingId, booking.vehicleId)

        true
    }

    // --- OTHER CORE ACTIONS ---
    suspend fun raiseSupportTicket(bookingId: String, category: String, subject: String, description: String): SupportTicket = withContext(Dispatchers.IO) {
        val ticketId = "TK-${1000 + (Math.random() * 8999).toInt()}"
        val ticket = SupportTicket(
            id = ticketId,
            bookingId = bookingId,
            category = category,
            subject = subject,
            description = description,
            status = "OPEN",
            createdAt = System.currentTimeMillis()
        )
        supportTicketDao.insertTicket(ticket)
        logEvent("SupportTicketCreated", "Support Ticket $ticketId submitted for topic: $category", bookingId)
        ticket
    }

    // Manual vehicle telemetry mock updater for drive-mode simulators
    suspend fun updateVehicleTelemetry(vehicleId: String, batteryPercent: Int, currentMileage: Int) = withContext(Dispatchers.IO) {
        val vehicle = vehicleDao.getVehicleById(vehicleId) ?: return@withContext
        val updated = vehicle.copy(
            batteryPercent = batteryPercent,
            estimatedRangeMiles = (batteryPercent * 3.1).toInt()
        )
        vehicleDao.updateVehicle(updated)
    }

    suspend fun updateBooking(booking: Booking) = withContext(Dispatchers.IO) {
        bookingDao.updateBooking(booking)
    }
}
