package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Branch
import com.example.data.model.BranchType
import com.example.data.model.CoverLevel
import com.example.data.model.Vehicle
import com.example.data.model.VehicleClass
import com.example.data.repository.PricingEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34]) // Match stable SDK values
class ExampleRobolectricTest {

    @Test
    fun testAppNameString() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("English Motor", appName)
    }

    @Test
    fun testPricingEngineBaseAndAirportFee() {
        val branchLhr = Branch(
            id = "LON-LHR",
            name = "London Heathrow Airport",
            city = "London",
            type = BranchType.AIRPORT,
            latitude = 51.4700,
            longitude = -0.4543,
            additionalAirportCharges = 45.0
        )

        val vehicleCompact = Vehicle(
            id = "V-001",
            registration = "LX75 EMA",
            name = "Ford Puma MHEV",
            category = VehicleClass.COMPACT,
            transmission = "Automatic",
            fuelType = "Hybrid",
            seats = 5,
            doors = 5,
            luggageLarge = 1,
            luggageSmall = 2,
            drivetrain = "Front-Wheel Drive",
            dailyPrice = 38.00,
            currentBranchId = "LON-LHR"
        )

        // Calculate a 1-day rental from tomorrow at 10:00 to day-after at 10:00
        val pickup = System.currentTimeMillis() + (1 * 24 * 60 * 60 * 1000L)
        val returnTime = pickup + (1 * 24 * 60 * 60 * 1000L)

        val pricing = PricingEngine.calculatePrice(
            vehicle = vehicleCompact,
            pickupBranch = branchLhr,
            returnBranch = branchLhr,
            pickupTimeMillis = pickup,
            returnTimeMillis = returnTime,
            coverLevel = CoverLevel.BASIC
        )

        // Verify base pricing calculations
        assertTrue("Base price should correspond to daily rate", pricing.baseRental >= 38.00)
        assertEquals("LHR airport surcharge must be captured", 45.0, pricing.locationCharges, 0.01)
        assertEquals("Basic cover is complementary", 0.0, pricing.coverCharge, 0.0)
    }
}
