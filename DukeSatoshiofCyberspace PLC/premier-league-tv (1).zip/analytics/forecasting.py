#!/usr/bin/env python3
"""
Premier League TV — Operational Analytics & Matchday Capacity Forecasting Engine.
Models concurrent viewer spikes, egress bandwidth, CDN costs, and QoS correlations.
"""

import math
from typing import Dict, Any

class BroadcastCapacityModeler:
    def __init__(self, cost_per_gb_usd: float = 0.0018, origin_shield_ratio: float = 0.985):
        self.cost_per_gb_usd = cost_per_gb_usd
        self.origin_shield_ratio = origin_shield_ratio

    def compute_matchday_forecast(self, viewers: int, avg_bitrate_mbps: float) -> Dict[str, Any]:
        """
        Calculates peak network egress, origin shield load, and hourly infrastructure costs.
        Formula: Egress in Gbit/s = (N * b) / 1000
        """
        gross_egress_gbps = (viewers * avg_bitrate_mbps) / 1000.0
        origin_egress_gbps = gross_egress_gbps * (1.0 - self.origin_shield_ratio)
        hourly_egress_tb = (gross_egress_gbps * 3600.0) / (8.0 * 1024.0)
        hourly_cost_usd = hourly_egress_tb * 1024.0 * self.cost_per_gb_usd
        recommended_origin_nodes = math.ceil(origin_egress_gbps / 10.0)  # 10Gbps NICs

        return {
            "concurrent_viewers": viewers,
            "avg_bitrate_mbps": avg_bitrate_mbps,
            "gross_egress_gbps": round(gross_egress_gbps, 2),
            "origin_egress_gbps": round(origin_egress_gbps, 3),
            "origin_shield_efficiency_pct": round(self.origin_shield_ratio * 100, 2),
            "bandwidth_hourly_tb": round(hourly_egress_tb, 2),
            "estimated_cdn_cost_hourly_usd": round(hourly_cost_usd, 2),
            "recommended_origin_shield_nodes": max(2, recommended_origin_nodes),
            "transcoder_cluster_nodes": 16
        }

if __name__ == "__main__":
    modeler = BroadcastCapacityModeler()
    result = modeler.compute_matchday_forecast(viewers=1_500_000, avg_bitrate_mbps=5.2)
    print("--- PREMIER LEAGUE TV CAPACITY FORECAST ---")
    for k, v in result.items():
        print(f"{k}: {v}")
