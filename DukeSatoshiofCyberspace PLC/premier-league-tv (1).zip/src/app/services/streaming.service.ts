import {Injectable, inject, signal, computed} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Fixture, PlaybackSession, StreamHealthMetrics, CapacityForecast, SelfTestResult} from '../models/broadcast.model';

@Injectable({
  providedIn: 'root'
})
export class StreamingService {
  private http = inject(HttpClient);

  // Core state signals
  readonly fixtures = signal<Fixture[]>([]);
  readonly selectedFixture = signal<Fixture | null>(null);
  readonly currentTerritory = signal<string>('GB');
  readonly currentTier = signal<string>('all_access');
  readonly activePlaybackSession = signal<PlaybackSession | null>(null);
  readonly authError = signal<{ error: string; message: string; window?: string } | null>(null);

  // Playback & ABR controls
  readonly isPlaying = signal<boolean>(true);
  readonly isMuted = signal<boolean>(false);
  readonly volume = signal<number>(0.75);
  readonly selectedAudioTrack = signal<string>('en_main');
  readonly selectedCameraAngle = signal<'broadcast' | 'tactical' | 'player_cam' | 'dugout'>('broadcast');
  readonly selectedRendition = signal<string>('auto'); // 'auto', '1080p', '720p', '540p', '360p'
  readonly showDiagnostics = signal<boolean>(false);

  // Live telemetry signals (updated in real-time)
  readonly liveLatencySec = signal<number>(3.24);
  readonly bufferLengthSec = signal<number>(4.82);
  readonly currentBitrateKbps = signal<number>(6500);
  readonly droppedFrames = signal<number>(0);
  readonly fps = signal<number>(60);
  readonly cdnEdgeNode = signal<string>('LHR-EDGE-04');
  readonly tokenTtlSec = signal<number>(118);

  // SRE & Ops signals
  readonly systemHealth = signal<StreamHealthMetrics | null>(null);
  readonly capacityForecast = signal<CapacityForecast | null>(null);
  readonly testResults = signal<SelfTestResult | null>(null);
  readonly isRunningTests = signal<boolean>(false);

  // Territory Options
  readonly availableTerritories = [
    { code: 'GB', name: 'United Kingdom', flag: '🇬🇧', blackoutApplies: true },
    { code: 'US', name: 'United States', flag: '🇺🇸', blackoutApplies: false },
    { code: 'AU', name: 'Australia', flag: '🇦🇺', blackoutApplies: false },
    { code: 'IN', name: 'India', flag: '🇮🇳', blackoutApplies: false },
    { code: 'FR', name: 'France', flag: '🇫🇷', blackoutApplies: false },
    { code: 'DE', name: 'Germany', flag: '🇩🇪', blackoutApplies: false }
  ];

  // Subscription Tiers
  readonly subscriptionTiers = [
    { id: 'free', name: 'Free Match Pass', price: '£0/mo', description: 'Replays and editorial studio programming' },
    { id: 'match_pass', name: 'Weekend Match Pass', price: '£14.99', description: 'Single weekend live match broadcast' },
    { id: 'all_access', name: 'Premier Live All-Access', price: '£29.99/mo', description: 'All 380 live fixtures in 1080p60 + multi-cam' },
    { id: 'ultra_4k', name: 'Ultra 4K Broadcast Pass', price: '£39.99/mo', description: '4K HDR broadcast, spatial audio & unlimited devices' }
  ];

  constructor() {
    this.loadFixtures();
    this.pollSystemHealth();
    this.runCapacityForecast(1500000, 5.2);

    // Live telemetry interval & token countdown
    if (typeof window !== 'undefined') {
      window.setInterval(() => {
        if (this.tokenTtlSec() > 1) {
          this.tokenTtlSec.update(t => t - 1);
        } else if (this.activePlaybackSession()) {
          // Auto-renew token before expiry
          const fix = this.selectedFixture();
          if (fix) this.requestPlaybackSession(fix.id);
        }

        // Slight jitter to simulate real ABR buffer and presentation latency
        if (this.isPlaying()) {
          const jitter = (Math.random() - 0.5) * 0.15;
          this.bufferLengthSec.update(b => Math.max(2.1, Math.min(8.0, Number((b + jitter).toFixed(2)))));
          this.liveLatencySec.update(l => Math.max(2.4, Math.min(4.8, Number((l + jitter * 0.5).toFixed(2)))));

          // Send heartbeat to backend
          this.sendHeartbeat();
        }
      }, 2000);
    }
  }

  loadFixtures() {
    this.http.get<{ fixtures: Fixture[] }>(`/api/v1/fixtures?territory=${this.currentTerritory()}&tier=${this.currentTier()}`)
      .subscribe({
        next: (res) => {
          this.fixtures.set(res.fixtures);
          // Default selection to first live match if none
          if (!this.selectedFixture() && res.fixtures.length > 0) {
            this.selectFixture(res.fixtures[0]);
          } else if (this.selectedFixture()) {
            const updated = res.fixtures.find(f => f.id === this.selectedFixture()?.id);
            if (updated) this.selectedFixture.set(updated);
          }
        },
        error: (err) => console.error('Error fetching fixtures:', err)
      });
  }

  selectFixture(fixture: Fixture) {
    this.selectedFixture.set(fixture);
    this.authError.set(null);
    this.requestPlaybackSession(fixture.id);
  }

  requestPlaybackSession(fixtureId: string) {
    this.authError.set(null);
    this.http.post<PlaybackSession>('/api/v1/playback-sessions', {
      fixtureId,
      userId: 'user_live_01',
      territory: this.currentTerritory(),
      subscriptionTier: this.currentTier(),
      deviceType: 'web_desktop'
    }).subscribe({
      next: (session) => {
        this.activePlaybackSession.set(session);
        this.tokenTtlSec.set(session.expiresInSec);
        this.authError.set(null);
      },
      error: (err) => {
        this.activePlaybackSession.set(null);
        if (err.error) {
          this.authError.set(err.error);
        } else {
          this.authError.set({
            error: 'NETWORK_ERROR',
            message: 'Unable to contact playback authorisation service.'
          });
        }
      }
    });
  }

  changeTerritory(code: string) {
    this.currentTerritory.set(code);
    this.loadFixtures();
    const curr = this.selectedFixture();
    if (curr) {
      this.requestPlaybackSession(curr.id);
    }
  }

  changeTier(tierId: string) {
    this.currentTier.set(tierId);
    this.loadFixtures();
    const curr = this.selectedFixture();
    if (curr) {
      this.requestPlaybackSession(curr.id);
    }
  }

  setAudioTrack(id: string) {
    this.selectedAudioTrack.set(id);
  }

  setCameraAngle(angle: 'broadcast' | 'tactical' | 'player_cam' | 'dugout') {
    this.selectedCameraAngle.set(angle);
  }

  setRendition(renditionId: string) {
    this.selectedRendition.set(renditionId);
    if (renditionId === '1080p') {
      this.currentBitrateKbps.set(6500);
      this.fps.set(60);
    } else if (renditionId === '720p') {
      this.currentBitrateKbps.set(4200);
      this.fps.set(60);
    } else if (renditionId === '540p') {
      this.currentBitrateKbps.set(2100);
      this.fps.set(30);
    } else if (renditionId === '360p') {
      this.currentBitrateKbps.set(800);
      this.fps.set(30);
    } else {
      // Auto: high by default on desktop
      this.currentBitrateKbps.set(6500);
      this.fps.set(60);
    }
  }

  togglePlay() {
    this.isPlaying.update(v => !v);
  }

  toggleMute() {
    this.isMuted.update(v => !v);
  }

  setVolume(vol: number) {
    this.volume.set(vol);
    if (vol > 0 && this.isMuted()) {
      this.isMuted.set(false);
    }
  }

  syncToLive() {
    this.liveLatencySec.set(2.85);
    this.bufferLengthSec.set(4.2);
  }

  sendHeartbeat() {
    const session = this.activePlaybackSession();
    if (!session) return;
    this.http.post('/api/v1/telemetry/heartbeat', {
      sessionId: session.sessionId,
      fixtureId: session.fixtureId,
      bitrateKbps: this.currentBitrateKbps(),
      bufferLengthSec: this.bufferLengthSec(),
      droppedFrames: this.droppedFrames(),
      latencyMs: Math.round(this.liveLatencySec() * 1000),
      stallCount: 0,
      cdnNode: this.cdnEdgeNode()
    }).subscribe({
      next: () => {},
      error: () => {}
    });
  }

  pollSystemHealth() {
    this.http.get<StreamHealthMetrics>('/api/v1/stream-health')
      .subscribe({
        next: (data) => this.systemHealth.set(data),
        error: (err) => console.error('Health poll error:', err)
      });
  }

  triggerChaos(action: string) {
    this.http.post<{ success: boolean; chaosState: any }>('/api/v1/chaos/trigger', { action })
      .subscribe({
        next: () => {
          this.pollSystemHealth();
          this.loadFixtures();
          const curr = this.selectedFixture();
          if (curr) this.requestPlaybackSession(curr.id);
        },
        error: (err) => console.error('Chaos trigger error:', err)
      });
  }

  runCapacityForecast(viewers: number, avgBitrate: number) {
    this.http.get<CapacityForecast>(`/api/v1/analytics/capacity-forecast?viewers=${viewers}&bitrate=${avgBitrate}`)
      .subscribe({
        next: (data) => this.capacityForecast.set(data),
        error: (err) => console.error('Forecast error:', err)
      });
  }

  runSelfTests() {
    this.isRunningTests.set(true);
    this.http.get<SelfTestResult>('/api/v1/tests/run')
      .subscribe({
        next: (data) => {
          this.testResults.set(data);
          this.isRunningTests.set(false);
        },
        error: (err) => {
          console.error('Test run error:', err);
          this.isRunningTests.set(false);
        }
      });
  }
}
