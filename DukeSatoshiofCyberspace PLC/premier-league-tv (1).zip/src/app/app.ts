import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {CommonModule} from '@angular/common';
import {MatIconModule} from '@angular/material/icon';
import {StreamingService} from './services/streaming.service';
import {Fixture} from './models/broadcast.model';
import {BroadcastPlayer} from './components/player/broadcast-player';
import {MatchCenter} from './components/match-center/match-center';
import {SreControl} from './components/sre-control/sre-control';
import {CapacityModeler} from './components/capacity/capacity-modeler';
import {SubscriptionModal} from './components/subscription-modal/subscription-modal';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    MatIconModule,
    BroadcastPlayer,
    MatchCenter,
    SreControl,
    CapacityModeler,
    SubscriptionModal
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly stream = inject(StreamingService);
  readonly showSubscriptionModal = signal<boolean>(false);
  readonly activeView = signal<'live' | 'fixtures' | 'match_center' | 'sre' | 'capacity'>('live');

  readonly fixtures = computed(() => this.stream.fixtures());
  readonly selectedFixture = computed(() => this.stream.selectedFixture());
  readonly territory = computed(() => this.stream.currentTerritory());
  readonly currentTier = computed(() => this.stream.currentTier());

  // Image assets generated via prompt directive
  readonly heroBroadcastImage = '/src/assets/images/pl_hero_match_broadcast_1792076335324.jpg';
  readonly studioDeskImage = '/src/assets/images/pl_studio_analysis_desk_1792076336221.jpg';

  scrollToSection(viewId: 'live' | 'fixtures' | 'match_center' | 'sre' | 'capacity') {
    this.activeView.set(viewId);
    if (typeof document !== 'undefined') {
      const el = document.getElementById(viewId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  }

  selectMatch(f: Fixture) {
    this.stream.selectFixture(f);
    this.scrollToSection('live');
  }

  openSettings() {
    this.showSubscriptionModal.set(true);
  }

  closeSettings() {
    this.showSubscriptionModal.set(false);
  }
}
