export interface CommentaryTrack {
  id: string;
  name: string;
  lang: string;
}

export interface Fixture {
  id: string;
  homeTeam: string;
  awayTeam: string;
  homeShort: string;
  awayShort: string;
  homeScore: number;
  awayScore: number;
  status: 'LIVE' | 'UPCOMING' | 'FT' | 'HIGHLIGHTS';
  minute: number;
  kickoffTime: string;
  stadium: string;
  competition: string;
  season: string;
  programmeType: 'LIVE_BROADCAST' | 'REPLAY' | 'HIGHLIGHTS' | 'STUDIO_ANALYSIS';
  permittedTerritories: string[];
  blackoutTerritories: string[];
  permittedTiers: string[];
  currentViewerCount: number;
  peakViewerCount: number;
  broadcaster: string;
  commentaryTracks: CommentaryTrack[];
  entitlementStatus?: 'ENTITLED' | 'TERRITORY_RESTRICTED' | 'BLACKED_OUT' | 'SUBSCRIPTION_REQUIRED';
  isBlackout?: boolean;
}

export interface PlaybackSession {
  sessionId: string;
  fixtureId: string;
  token: string;
  expiresInSec: number;
  manifestUrl: string;
  drmHandoff: {
    type: string;
    keySystem: string;
    licenseServerUrl: string;
    sessionHeaderToken: string;
  };
  renditions: RenditionProfile[];
  audioTracks: CommentaryTrack[];
  telemetryHeartbeatIntervalMs: number;
}

export interface RenditionProfile {
  id: string;
  label: string;
  bitrate: number;
  resolution: string;
  fps: number;
}

export interface StreamHealthMetrics {
  ingestGateway: {
    status: string;
    primaryProtocol: string;
    redundantProtocol: string;
    contributionBitrate: string;
    packetLoss: string;
    clockDrift: string;
    sourceResolution: string;
  };
  transcoderCluster: {
    status: string;
    activeNodes: number;
    processingLatencyMs: string;
    renditionsActive: number;
    gpuLoad: string;
  };
  packager: {
    status: string;
    protocol: string;
    segmentDuration: string;
    manifestPublishDelayMs: number;
    discontinuityCount: number;
  };
  cdnDelivery: {
    status: string;
    cacheHitRatio: string;
    totalEgressBandwidth: string;
    activeMultiCdnRouting: { provider: string; share: string; latency: string }[];
  };
  clientQoE: {
    avgBufferSec: string;
    avgPresentationLatencyMs: number;
    stallRatioPercent: string;
    fatalErrorRatePercent: string;
    timeToFirstFrameMs: number;
  };
  chaosState: {
    signalInterrupted: boolean;
    encoderDegraded: boolean;
    cdnDegraded: boolean;
    blackoutActive: boolean;
    activeIncidents: { id: string; title: string; severity: string; timestamp: string; autoRecoveryInSec: number }[];
  };
}

export interface CapacityForecast {
  inputs: {
    concurrentViewers: number;
    avgBitrateMbps: number;
  };
  metrics: {
    grossEgressGbps: string;
    originEgressGbps: string;
    originShieldProtectionPercent: string;
    bandwidthHourlyTB: string;
    estimatedCdnCostPerHourUSD: string;
    recommendedOriginNodes: number;
    transcodingClusterNodes: number;
  };
}

export interface SelfTestResult {
  total: number;
  passed: number;
  failed: number;
  executedAt: string;
  tests: {
    id: string;
    name: string;
    passed: boolean;
    details: string;
  }[];
}
