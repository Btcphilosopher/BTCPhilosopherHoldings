import {ChangeDetectionStrategy, Component, computed, inject, output} from '@angular/core';
import {CommonModule} from '@angular/common';
import {MatIconModule} from '@angular/material/icon';
import {StreamingService} from '../../services/streaming.service';

@Component({
  selector: 'app-subscription-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  templateUrl: './subscription-modal.html',
  styleUrl: './subscription-modal.css'
})
export class SubscriptionModal {
  readonly stream = inject(StreamingService);
  readonly dismissModal = output<void>();

  readonly currentTerritory = computed(() => this.stream.currentTerritory());
  readonly currentTier = computed(() => this.stream.currentTier());
  readonly territories = this.stream.availableTerritories;
  readonly tiers = this.stream.subscriptionTiers;

  selectTerritory(code: string) {
    this.stream.changeTerritory(code);
  }

  selectTier(tierId: string) {
    this.stream.changeTier(tierId);
  }

  dismiss() {
    this.dismissModal.emit();
  }
}
