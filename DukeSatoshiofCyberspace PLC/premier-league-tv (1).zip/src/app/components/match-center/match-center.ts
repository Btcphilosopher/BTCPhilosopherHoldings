import {ChangeDetectionStrategy, Component, computed, inject} from '@angular/core';
import {CommonModule} from '@angular/common';
import {MatIconModule} from '@angular/material/icon';
import {StreamingService} from '../../services/streaming.service';

interface MatchIncident {
  minute: number;
  type: 'GOAL' | 'YELLOW_CARD' | 'RED_CARD' | 'SUBSTITUTION' | 'VAR';
  team: 'ARS' | 'MCI';
  player: string;
  detail: string;
}

@Component({
  selector: 'app-match-center',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  templateUrl: './match-center.html',
  styleUrl: './match-center.css'
})
export class MatchCenter {
  readonly stream = inject(StreamingService);
  readonly fixture = computed(() => this.stream.selectedFixture());

  readonly activeTab = computed<'stats' | 'lineups' | 'commentary'>(() => 'stats');
  currentTab: 'stats' | 'lineups' | 'commentary' = 'stats';

  // Live tactical statistics
  readonly matchStats = [
    { label: 'Expected Goals (xG)', home: '1.84', away: '1.42', homePct: 56, awayPct: 44 },
    { label: 'Possession', home: '48%', away: '52%', homePct: 48, awayPct: 52 },
    { label: 'Total Shots', home: '14', away: '11', homePct: 56, awayPct: 44 },
    { label: 'Shots on Target', home: '6', away: '4', homePct: 60, awayPct: 40 },
    { label: 'Pass Accuracy', home: '88%', away: '91%', homePct: 49, awayPct: 51 },
    { label: 'Corner Kicks', home: '7', away: '5', homePct: 58, awayPct: 42 },
    { label: 'Fouls Committed', home: '9', away: '12', homePct: 43, awayPct: 57 }
  ];

  // Match timeline events
  readonly incidents: MatchIncident[] = [
    { minute: 71, type: 'GOAL', team: 'ARS', player: 'Bukayo Saka', detail: 'Curling left-footed strike into the top corner from edge of penalty box.' },
    { minute: 64, type: 'YELLOW_CARD', team: 'MCI', player: 'Rodri', detail: 'Tactical foul stopping counter-attack by Ødegaard.' },
    { minute: 58, type: 'VAR', team: 'ARS', player: 'VAR Goal Check', detail: 'Goal confirmed after review for potential offside in buildup.' },
    { minute: 52, type: 'GOAL', team: 'MCI', player: 'Erling Haaland', detail: 'Header from 6 yards off Kevin De Bruyne whipped cross.' },
    { minute: 34, type: 'GOAL', team: 'ARS', player: 'Kai Havertz', detail: 'Poked home rebound after Ederson parry.' },
    { minute: 18, type: 'YELLOW_CARD', team: 'ARS', player: 'William Saliba', detail: 'Late tackle on Phil Foden.' }
  ];

  // Starting XI lineups
  readonly arsenalLineup = [
    { number: '1', name: 'David Raya', pos: 'GK' },
    { number: '4', name: 'Ben White', pos: 'RB' },
    { number: '2', name: 'William Saliba', pos: 'CB' },
    { number: '6', name: 'Gabriel Magalhães', pos: 'CB' },
    { number: '12', name: 'Jurriën Timber', pos: 'LB' },
    { number: '41', name: 'Declan Rice', pos: 'CM' },
    { number: '23', name: 'Mikel Merino', pos: 'CM' },
    { number: '8', name: 'Martin Ødegaard (C)', pos: 'CAM' },
    { number: '7', name: 'Bukayo Saka', pos: 'RW' },
    { number: '29', name: 'Kai Havertz', pos: 'ST' },
    { number: '11', name: 'Gabriel Martinelli', pos: 'LW' }
  ];

  readonly manCityLineup = [
    { number: '31', name: 'Ederson', pos: 'GK' },
    { number: '2', name: 'Kyle Walker (C)', pos: 'RB' },
    { number: '3', name: 'Rúben Dias', pos: 'CB' },
    { number: '25', name: 'Manuel Akanji', pos: 'CB' },
    { number: '24', name: 'Joško Gvardiol', pos: 'LB' },
    { number: '16', name: 'Rodri', pos: 'CDM' },
    { number: '8', name: 'Mateo Kovačić', pos: 'CM' },
    { number: '17', name: 'Kevin De Bruyne', pos: 'CAM' },
    { number: '20', name: 'Bernardo Silva', pos: 'RW' },
    { number: '9', name: 'Erling Haaland', pos: 'ST' },
    { number: '10', name: 'Jack Grealish', pos: 'LW' }
  ];

  setTab(tab: 'stats' | 'lineups' | 'commentary') {
    this.currentTab = tab;
  }
}
