import {ChangeDetectionStrategy, Component, computed, inject} from '@angular/core';
import {CommonModule} from '@angular/common';
import {MatIconModule} from '@angular/material/icon';
import {StreamingService} from '../../services/streaming.service';

@Component({
  selector: 'app-sre-control',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  templateUrl: './sre-control.html',
  styleUrl: './sre-control.css'
})
export class SreControl {
  readonly stream = inject(StreamingService);
  readonly health = computed(() => this.stream.systemHealth());

  // Chaos & Resilience actions
  triggerIncident(action: string) {
    this.stream.triggerChaos(action);
  }
}
