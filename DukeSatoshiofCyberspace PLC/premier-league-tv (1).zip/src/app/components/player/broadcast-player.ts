import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  computed,
  inject
} from '@angular/core';
import {CommonModule} from '@angular/common';
import {MatIconModule} from '@angular/material/icon';
import {StreamingService} from '../../services/streaming.service';

@Component({
  selector: 'app-broadcast-player',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  templateUrl: './broadcast-player.html',
  styleUrl: './broadcast-player.css'
})
export class BroadcastPlayer implements OnInit, OnDestroy {
  readonly stream = inject(StreamingService);

  @ViewChild('broadcastCanvas', { static: false }) canvasRef?: ElementRef<HTMLCanvasElement>;
  @ViewChild('playerContainer', { static: false }) containerRef?: ElementRef<HTMLDivElement>;

  private animationFrameId?: number;
  private audioCtx?: AudioContext;
  private crowdNoiseNode?: AudioNode;
  private gainNode?: GainNode;
  private matchTimeSec = 74 * 60 + 12; // Start at 74m 12s
  private ballX = 0.5;
  private ballY = 0.5;
  private ballVx = 0.003;
  private ballVy = 0.002;
  private pulse = 0;

  readonly fixture = computed(() => this.stream.selectedFixture());
  readonly session = computed(() => this.stream.activePlaybackSession());
  readonly authError = computed(() => this.stream.authError());
  readonly isPlaying = computed(() => this.stream.isPlaying());
  readonly isMuted = computed(() => this.stream.isMuted());
  readonly volume = computed(() => this.stream.volume());
  readonly showDiagnostics = computed(() => this.stream.showDiagnostics());
  readonly selectedRendition = computed(() => this.stream.selectedRendition());
  readonly currentBitrate = computed(() => this.stream.currentBitrateKbps());
  readonly liveLatency = computed(() => this.stream.liveLatencySec());
  readonly bufferLength = computed(() => this.stream.bufferLengthSec());
  readonly currentAngle = computed(() => this.stream.selectedCameraAngle());
  readonly currentAudio = computed(() => this.stream.selectedAudioTrack());
  readonly tokenTtl = computed(() => this.stream.tokenTtlSec());

  // Formatted match clock
  readonly formattedClock = computed(() => {
    const mins = Math.floor(this.matchTimeSec / 60);
    const secs = Math.floor(this.matchTimeSec % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  });

  ngOnInit() {
    if (typeof window !== 'undefined') {
      window.requestAnimationFrame(() => this.initCanvasLoop());
    }
  }

  ngOnDestroy() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    this.stopAudio();
  }

  togglePlay() {
    this.stream.togglePlay();
    if (this.stream.isPlaying()) {
      this.startAudio();
    } else {
      this.stopAudio();
    }
  }

  toggleMute() {
    this.stream.toggleMute();
    if (this.gainNode) {
      this.gainNode.gain.value = this.stream.isMuted() ? 0 : this.stream.volume();
    }
    if (!this.stream.isMuted() && !this.audioCtx) {
      this.startAudio();
    }
  }

  onVolumeChange(event: Event) {
    const target = event.target as HTMLInputElement;
    const val = parseFloat(target.value);
    this.stream.setVolume(val);
    if (this.gainNode) {
      this.gainNode.gain.value = this.stream.isMuted() ? 0 : val;
    }
  }

  toggleDiagnostics() {
    this.stream.showDiagnostics.update(v => !v);
  }

  setCameraAngle(angle: 'broadcast' | 'tactical' | 'player_cam' | 'dugout') {
    this.stream.setCameraAngle(angle);
  }

  setAudioTrack(trackId: string) {
    this.stream.setAudioTrack(trackId);
    // Restart audio synthesizer with selected profile
    if (!this.stream.isMuted()) {
      this.stopAudio();
      this.startAudio();
    }
  }

  setRendition(renditionId: string) {
    this.stream.setRendition(renditionId);
  }

  syncToLive() {
    this.stream.syncToLive();
  }

  toggleFullscreen() {
    if (!this.containerRef) return;
    const el = this.containerRef.nativeElement;
    if (!document.fullscreenElement) {
      el.requestFullscreen?.().catch(err => console.warn(err));
    } else {
      document.exitFullscreen?.().catch(err => console.warn(err));
    }
  }

  // Web Audio Stadium Atmosphere Synthesizer
  private startAudio() {
    if (typeof window === 'undefined' || this.audioCtx) return;
    try {
      const webkitCtx = (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      const AudioCtxClass = window.AudioContext || webkitCtx;
      if (!AudioCtxClass) return;
      this.audioCtx = new AudioCtxClass();
      
      this.gainNode = this.audioCtx.createGain();
      this.gainNode.gain.value = this.stream.isMuted() ? 0 : this.stream.volume() * 0.15;
      this.gainNode.connect(this.audioCtx.destination);

      // Pink noise crowd chant generator
      const bufferSize = this.audioCtx.sampleRate * 2;
      const noiseBuffer = this.audioCtx.createBuffer(2, bufferSize, this.audioCtx.sampleRate);
      for (let channel = 0; channel < 2; channel++) {
        const output = noiseBuffer.getChannelData(channel);
        let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
        for (let i = 0; i < bufferSize; i++) {
          const white = Math.random() * 2 - 1;
          b0 = 0.99886 * b0 + white * 0.0555179;
          b1 = 0.99332 * b1 + white * 0.0750759;
          b2 = 0.96900 * b2 + white * 0.1538520;
          b3 = 0.86650 * b3 + white * 0.3104856;
          b4 = 0.55000 * b4 + white * 0.5329522;
          b5 = -0.7616 * b5 - white * 0.0168980;
          output[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11;
          b6 = white * 0.115926;
        }
      }

      const noiseSource = this.audioCtx.createBufferSource();
      noiseSource.buffer = noiseBuffer;
      noiseSource.loop = true;

      // Bandpass filter for authentic stadium reverberation
      const filter = this.audioCtx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 450;
      filter.Q.value = 1.8;

      noiseSource.connect(filter);
      filter.connect(this.gainNode);
      noiseSource.start(0);
      this.crowdNoiseNode = noiseSource;
    } catch (e) {
      console.warn('Audio Context init prevented:', e);
    }
  }

  private stopAudio() {
    if (this.crowdNoiseNode) {
      const source = this.crowdNoiseNode as AudioScheduledSourceNode;
      if (typeof source.stop === 'function') {
        source.stop();
      }
      this.crowdNoiseNode = undefined;
    }
    if (this.audioCtx) {
      void this.audioCtx.close();
      this.audioCtx = undefined;
    }
  }

  // 60FPS Live Broadcast Pitch Renderer
  private initCanvasLoop() {
    const render = () => {
      this.animationFrameId = requestAnimationFrame(render);
      if (!this.canvasRef || !this.isPlaying() || this.authError()) return;

      const canvas = this.canvasRef.nativeElement;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const width = canvas.width = canvas.clientWidth || 960;
      const height = canvas.height = canvas.clientHeight || 540;

      this.pulse += 0.03;
      this.matchTimeSec += 0.016; // Increment match time

      // Update ball position with dynamic bounce
      this.ballX += this.ballVx;
      this.ballY += this.ballVy;
      if (this.ballX > 0.88 || this.ballX < 0.12) this.ballVx = -this.ballVx;
      if (this.ballY > 0.82 || this.ballY < 0.18) this.ballVy = -this.ballVy;

      // 1. Draw Pristine Emerald Pitch
      const grad = ctx.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, '#0a3818');
      grad.addColorStop(0.5, '#0d4722');
      grad.addColorStop(1, '#093316');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Pitch mowing turf stripes
      const stripeCount = 12;
      const stripeW = width / stripeCount;
      for (let i = 0; i < stripeCount; i += 2) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.035)';
        ctx.fillRect(i * stripeW, 0, stripeW, height);
      }

      // 2. Pitch Markings (White Lines)
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
      ctx.lineWidth = 2.5;

      const padX = width * 0.08;
      const padY = height * 0.08;
      const pitchW = width - padX * 2;
      const pitchH = height - padY * 2;

      // Touchline & Goal-line boundary
      ctx.strokeRect(padX, padY, pitchW, pitchH);

      // Halfway line & Center Circle
      ctx.beginPath();
      ctx.moveTo(width / 2, padY);
      ctx.lineTo(width / 2, height - padY);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(width / 2, height / 2, height * 0.16, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.beginPath();
      ctx.arc(width / 2, height / 2, 3.5, 0, Math.PI * 2);
      ctx.fill();

      // Penalty boxes
      const boxW = pitchW * 0.18;
      const boxH = pitchH * 0.54;
      const boxY = height / 2 - boxH / 2;
      ctx.strokeRect(padX, boxY, boxW, boxH);
      ctx.strokeRect(width - padX - boxW, boxY, boxW, boxH);

      // 3. Camera Mode Specific Perspectives
      const angle = this.currentAngle();
      if (angle === 'tactical') {
        // Overlay Tactical Pressing Mesh
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.25)';
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(padX + boxW, padY);
        ctx.lineTo(padX + boxW, height - padY);
        ctx.moveTo(width - padX - boxW, padY);
        ctx.lineTo(width - padX - boxW, height - padY);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // 4. Draw Players (Red: Arsenal, Sky Blue: Man City)
      const homeTeamColor = '#e11d48'; // Arsenal crimson red
      const awayTeamColor = '#38bdf8'; // Man City sky blue

      const drawPlayer = (x: number, y: number, color: string, num: string, hasBall = false) => {
        const px = padX + x * pitchW;
        const py = padY + y * pitchH;

        // Player shadow
        ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
        ctx.beginPath();
        ctx.ellipse(px, py + 8, 9, 4, 0, 0, Math.PI * 2);
        ctx.fill();

        // Player kit circle
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(px, py, 7.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Squad number
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 8px monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(num, px, py + 0.5);

        // Active ball possessor ring
        if (hasBall) {
          ctx.strokeStyle = '#fbbf24';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(px, py, 13 + Math.sin(this.pulse * 3) * 2, 0, Math.PI * 2);
          ctx.stroke();
        }
      };

      // Home Team (Arsenal - Red)
      drawPlayer(0.04, 0.50, '#10b981', '1'); // Raya (GK)
      drawPlayer(0.18, 0.22, homeTeamColor, '4'); // White
      drawPlayer(0.16, 0.40, homeTeamColor, '2'); // Saliba
      drawPlayer(0.16, 0.60, homeTeamColor, '6'); // Gabriel
      drawPlayer(0.18, 0.78, homeTeamColor, '12'); // Timber
      drawPlayer(0.32, 0.38, homeTeamColor, '41'); // Rice
      drawPlayer(0.35, 0.62, homeTeamColor, '23'); // Merino
      drawPlayer(0.48, 0.50, homeTeamColor, '8'); // Ødegaard
      drawPlayer(0.62, 0.20, homeTeamColor, '7', true); // Saka (has ball!)
      drawPlayer(0.64, 0.50, homeTeamColor, '29'); // Havertz
      drawPlayer(0.62, 0.80, homeTeamColor, '11'); // Martinelli

      // Away Team (Manchester City - Sky Blue)
      drawPlayer(0.96, 0.50, '#f59e0b', '31'); // Ederson (GK)
      drawPlayer(0.82, 0.25, awayTeamColor, '2'); // Walker
      drawPlayer(0.84, 0.42, awayTeamColor, '3'); // Dias
      drawPlayer(0.84, 0.58, awayTeamColor, '25'); // Akanji
      drawPlayer(0.82, 0.75, awayTeamColor, '24'); // Gvardiol
      drawPlayer(0.68, 0.40, awayTeamColor, '16'); // Rodri
      drawPlayer(0.66, 0.60, awayTeamColor, '8'); // Kovacic
      drawPlayer(0.55, 0.50, awayTeamColor, '17'); // De Bruyne
      drawPlayer(0.42, 0.22, awayTeamColor, '20'); // Bernardo
      drawPlayer(0.45, 0.52, awayTeamColor, '9'); // Haaland
      drawPlayer(0.42, 0.78, awayTeamColor, '10'); // Grealish

      // 5. Draw Football
      const bx = padX + this.ballX * pitchW;
      const by = padY + this.ballY * pitchH;
      ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
      ctx.beginPath();
      ctx.ellipse(bx, by + 5, 5, 2.5, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(bx, by, 4.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 1;
      ctx.stroke();

      // 6. Camera Frame Vignette & Stadium Floodlight Sheen
      const floodlightGrad = ctx.createRadialGradient(width / 2, height / 2, width * 0.1, width / 2, height / 2, width * 0.6);
      floodlightGrad.addColorStop(0, 'rgba(255, 255, 255, 0.08)');
      floodlightGrad.addColorStop(1, 'rgba(0, 0, 0, 0.35)');
      ctx.fillStyle = floodlightGrad;
      ctx.fillRect(0, 0, width, height);

      // Player Cam banner if active
      if (angle === 'player_cam') {
        ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
        ctx.fillRect(width - 240, height - 50, 220, 36);
        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 11px system-ui';
        ctx.textAlign = 'left';
        ctx.fillText('PLAYER ISO CAM', width - 230, height - 34);
        ctx.fillStyle = '#f8fafc';
        ctx.font = '11px system-ui';
        ctx.fillText('9. ERLING HAALAND', width - 230, height - 20);
      }
    };

    render();
  }
}
