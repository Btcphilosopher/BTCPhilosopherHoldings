import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {CommonModule} from '@angular/common';
import {MatIconModule} from '@angular/material/icon';
import {StreamingService} from '../../services/streaming.service';

@Component({
  selector: 'app-capacity-modeler',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  templateUrl: './capacity-modeler.html',
  styleUrl: './capacity-modeler.css'
})
export class CapacityModeler {
  readonly stream = inject(StreamingService);
  readonly forecast = computed(() => this.stream.capacityForecast());
  readonly testResults = computed(() => this.stream.testResults());
  readonly isRunningTests = computed(() => this.stream.isRunningTests());

  // Local model sliders
  readonly viewerCount = signal<number>(1500000);
  readonly avgBitrate = signal<number>(5.2);

  // Preset match scenarios
  setScenario(preset: 'weekday' | 'derby' | 'championship_finale' | 'world_record') {
    if (preset === 'weekday') {
      this.viewerCount.set(450000);
      this.avgBitrate.set(4.0);
    } else if (preset === 'derby') {
      this.viewerCount.set(1500000);
      this.avgBitrate.set(5.2);
    } else if (preset === 'championship_finale') {
      this.viewerCount.set(3200000);
      this.avgBitrate.set(6.5);
    } else if (preset === 'world_record') {
      this.viewerCount.set(5000000);
      this.avgBitrate.set(7.5);
    }
    this.updateCalculation();
  }

  onViewersInput(event: Event) {
    const val = parseInt((event.target as HTMLInputElement).value, 10);
    this.viewerCount.set(val);
    this.updateCalculation();
  }

  onBitrateInput(event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.avgBitrate.set(val);
    this.updateCalculation();
  }

  updateCalculation() {
    this.stream.runCapacityForecast(this.viewerCount(), this.avgBitrate());
  }

  runVerificationTests() {
    this.stream.runSelfTests();
  }
}
