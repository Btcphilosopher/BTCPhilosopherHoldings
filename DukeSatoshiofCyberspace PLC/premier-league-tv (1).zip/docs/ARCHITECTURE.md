# PREMIER LEAGUE TV — BROADCAST ARCHITECTURE & INFRASTRUCTURE

## 1. System Overview & Component Topology

```text
========================================================================================
                          PREMIER LEAGUE BROADCAST PIPELINE
========================================================================================

[ STADIUM CONTRIBUTION ]
  - Dual 10Gbps SDI Direct Connect from Broadcast Truck
  - SRT (Secure Reliable Transport) caller with 120ms latency buffer
  - RIST (Reliable Internet Stream Transport) redundant standby
       │
       ▼
[ INGESTION GATEWAY & VALIDATION CLUSTER ]
  - Ingest Validation: 3840x2160p50 Main 10 HDR & 1080p50 HD-SDI
  - Clock Synchronisation: SMPTE ST 2110 / PTP IEEE 1588 timecodes
  - Source Health Probe: Clock drift (<2ms), packet loss (<0.01%), audio channels (16-ch PCM)
       │
       ▼
[ TRANSCODING & ABR LADDER ORCHESTRATION ]
  - Rendition Ladder (H.264 / HEVC / AV1):
      * 1080p60 @ 6500 kbps (High profile, CABAC, 2.0s GOP)
      * 720p60  @ 4200 kbps (Main profile, 2.0s GOP)
      * 540p30  @ 2100 kbps (Main profile, 2.0s GOP)
      * 360p30  @  800 kbps (Baseline profile, 2.0s GOP)
  - Audio Groups:
      * English Main Commentary (192 kbps AAC-LC)
      * Spanish Latino Commentary (192 kbps AAC-LC)
      * Stadium Atmosphere Only (256 kbps 5.1/Stereo Crowd)
      * Tactical & Data Feed (128 kbps Analytical Radio)
       │
       ▼
[ CMAF PACKAGER & DRM INTEGRATION ]
  - Chunked CMAF / HLS v6 / MPEG-DASH v4 packaging
  - Dynamic Manifest Generation with sliding 5-segment window (EXT-X-MEDIA-SEQUENCE)
  - DRM Integration: Common Encryption (CENC) with Widevine Modular & FairPlay Streaming
  - Playback Token Authentication Gate (HMAC-SHA256, 120s TTL)
       │
       ▼
[ ORIGIN SHIELD & MULTI-CDN DELIVERY ]
  - Origin Shield Layer (98.5%+ Cache Hit Ratio protection)
  - Multi-CDN Edge Routing & Failover Steering:
      * Cloudflare Broadcast Edge (48% primary share)
      * Fastly Media Shield (34% secondary share)
      * Akamai Adaptive Media Delivery (18% tertiary share)
  - Edge URL signing & Geo-fenced IP validation
       │
       ▼
[ SUBSCRIBER PLAYBACK ENGINE ]
  - Adaptive Bitrate (ABR) Player with Low-Latency live-edge tracking
  - Multi-Audio Commentary & Tactical Angle Selection
  - Real-time client QoE telemetry reporting (/api/v1/telemetry/heartbeat)
```

## 2. Rust Control Plane Microservice Topology

The streaming control plane is designed for high concurrency, microsecond entitlement evaluation, and zero-allocation token validation:

- `services/identity-session`: Validates user authentication, JWT claims, and enforces concurrent device limits (Max 2 simultaneous streams per subscription).
- `services/entitlements`: Evaluates fixture licensing, tier rules (Match Pass, All-Access, Ultra 4K), and UK Article 48 3pm Saturday broadcast blackouts.
- `services/playback-authorisation`: Issues cryptographically signed short-lived playback tokens (HMAC-SHA256, 120s TTL) and negotiates DRM licensing proxies.
- `services/stream-orchestration`: Monitors SRT/RIST ingestion lines, triggers automated line failover within 180ms upon packet drop, and manages packager discontinuity insertion.
- `services/telemetry-collector`: High-throughput ingestion of client QoE metrics (buffer length, dropped frames, playback stalls) feeding Prometheus and SRE dashboards.

## 3. Capacity Model & Matchday Concurrency

Media delivery egress bandwidth is modelled as:
$$Egress_{\text{Gbps}} \approx \frac{N \times b}{1000}$$
Where $N$ is concurrent viewers and $b$ is average delivered bitrate in Mbps.

- **Peak Matchday Scenario (Arsenal vs Man City)**:
  - $N = 1,500,000$ concurrent viewers
  - Average bitrate $b = 5.2$ Mbps (accounting for mixed 1080p and mobile devices)
  - Gross CDN Egress: $7,800$ Gbps (7.8 Tbps)
  - Origin Shield Hit Ratio: $98.5\%$
  - Origin Ingest Demand: $117$ Gbps
  - Cost per hour: $\approx \$12,636$ USD
