terraform {
  required_version = ">= 1.7.0"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
    cloudflare = {
      source  = "cloudflare/cloudflare"
      version = "~> 4.0"
    }
  }
}

# 1. Media Origin Object Storage with Lifecycle Rules for CMAF Segments
resource "google_storage_bucket" "broadcast_origin" {
  name          = "pltv-live-media-origin-prod"
  location      = "EUROPE-WEST2"
  force_destroy = false

  uniform_bucket_level_access = true

  lifecycle_rule {
    condition {
      age = 1 # Purge live sliding window segments older than 24 hours
    }
    action {
      type = "Delete"
    }
  }

  cors {
    origin          = ["*"]
    method          = ["GET", "HEAD", "OPTIONS"]
    response_header = ["*"]
    max_age_seconds = 3600
  }
}

# 2. Origin Shield Compute Nodes
resource "google_compute_region_instance_group_manager" "origin_shield" {
  name               = "pltv-origin-shield-mig"
  base_instance_name = "origin-shield"
  region             = "europe-west2"
  target_size        = 6

  version {
    instance_template = "projects/pltv-prod/global/instanceTemplates/origin-shield-v3"
  }

  auto_healing_policies {
    health_check      = "projects/pltv-prod/global/healthChecks/origin-shield-http"
    initial_delay_sec = 60
  }
}

# 3. Cloudflare Stream CDN Distribution & Caching Rules
resource "cloudflare_zone_settings_override" "broadcast_delivery" {
  zone_id = "pltv_production_zone_id"
  settings {
    brotli = "on"
    cache_level = "aggressive"
    http3 = "on"
  }
}
