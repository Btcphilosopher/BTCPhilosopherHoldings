package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.example.data.TripEntity
import com.example.ui.components.DigitalBoardingPass
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaDarkBackground
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaWarmWhite

@Composable
fun WalletScreen(
    trip: TripEntity?,
    modifier: Modifier = Modifier
) {
    val currentTrip = trip ?: return

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BaDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("wallet_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        // Section 41: Header
        item {
            Column {
                Text(
                    text = "BRITISH AIRWAYS • PASSENGER VAULT",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaSkyBlue
                )
                Text(
                    text = "TRAVEL WALLET",
                    style = MaterialTheme.typography.headlineLarge,
                    color = BaWarmWhite
                )
                Text(
                    text = "Encrypted digital documents, boarding passes and travel clearances.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = BaSilver
                )
            }
        }

        // Section 19: Boarding Pass
        item {
            DigitalBoardingPass(
                passengerName = "Tom Loveitt",
                flightNumber = currentTrip.flightNumber,
                originCode = currentTrip.originCode,
                originName = currentTrip.originName,
                originTerminal = currentTrip.originTerminal,
                destCode = currentTrip.destCode,
                destName = currentTrip.destName,
                flightDate = currentTrip.flightDate,
                departureTime = currentTrip.departureTime,
                boardingTime = "07:10",
                gate = currentTrip.gate,
                seat = currentTrip.seat,
                cabinName = currentTrip.cabinName,
                boardingGroup = currentTrip.boardingGroup,
                bookingRef = currentTrip.bookingRef
            )
        }

        item {
            Text("GOVERNMENT IDENTITY & TRAVEL VISAS", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        }

        // Passport Document Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaBorderNavy)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Badge, contentDescription = null, tint = BaGold, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("UNITED KINGDOM OF GREAT BRITAIN PASSPORT", style = MaterialTheme.typography.labelSmall, color = BaGold)
                        Text("GBR ••••••••42 (Biometric Chip Verified)", style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace), color = BaWarmWhite)
                        Text("Holder: Tom Loveitt • Exp: 12 AUG 2032", style = MaterialTheme.typography.labelSmall, color = BaSilver)
                    }
                    Icon(Icons.Default.Lock, contentDescription = null, tint = BaGreenSuccess, modifier = Modifier.size(16.dp))
                }
            }
        }

        // US ESTA Visa Waiver Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaBorderNavy)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = BaGreenSuccess, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("UNITED STATES ESTA VISA WAIVER", style = MaterialTheme.typography.labelSmall, color = BaGreenSuccess)
                        Text("AUTHORISATION APPROVED", style = MaterialTheme.typography.titleMedium, color = BaWarmWhite)
                        Text("Linked to passport • Valid for multiple entries", style = MaterialTheme.typography.labelSmall, color = BaSilver)
                    }
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BaGreenSuccess, modifier = Modifier.size(16.dp))
                }
            }
        }

        // Travel Insurance Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaBorderNavy)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.HealthAndSafety, contentDescription = null, tint = BaSkyBlue, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("BRITISH AIRWAYS COMPREHENSIVE TRAVEL INSURANCE", style = MaterialTheme.typography.labelSmall, color = BaSkyBlue)
                        Text("POLICY #BA-GOLD-94821", style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace), color = BaWarmWhite)
                        Text("Full worldwide medical, baggage & flight cancellation cover", style = MaterialTheme.typography.labelSmall, color = BaSilver)
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
