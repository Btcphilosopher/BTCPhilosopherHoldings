package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirplaneTicket
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Luggage
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TripEntity
import com.example.model.CabinClass
import com.example.model.JourneyState
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaDarkBackground
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

@Composable
fun TripsScreen(
    trips: List<TripEntity>,
    onSelectTrip: (TripEntity) -> Unit,
    onNavigateToTicket: (TripEntity) -> Unit,
    onNavigateToCheckIn: (TripEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTripForDetail by remember { mutableStateOf<TripEntity?>(null) }

    if (selectedTripForDetail != null) {
        TripDetailView(
            trip = selectedTripForDetail!!,
            onBack = { selectedTripForDetail = null },
            onViewBoardingPass = { onNavigateToTicket(selectedTripForDetail!!) },
            onCheckIn = { onNavigateToCheckIn(selectedTripForDetail!!) }
        )
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BaDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("trips_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        item {
            Column {
                Text(
                    text = "BRITISH AIRWAYS • TRAVEL LIBRARY",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaSkyBlue
                )
                Text(
                    text = "MY TRIPS",
                    style = MaterialTheme.typography.headlineLarge,
                    color = BaWarmWhite
                )
                Text(
                    text = "Active bookings and upcoming confirmed British Airways journeys.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = BaSilver
                )
            }
        }

        items(trips) { trip ->
            TripDocumentCard(
                trip = trip,
                onClick = { selectedTripForDetail = trip },
                onViewPass = { onNavigateToTicket(trip) }
            )
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun TripDocumentCard(
    trip: TripEntity,
    onClick: () -> Unit,
    onViewPass: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("trip_card_${trip.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = BaNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (trip.isFlagshipDemo) BaGold.copy(alpha = 0.8f) else BaBorderNavy)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header: Booking ref & Cabin
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(BaSpeedmarqueRed, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "REF: ${trip.bookingRef}",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                        color = BaSilver
                    )
                }
                Box(
                    modifier = Modifier
                        .background(if (trip.cabinName == "FIRST") BaGold.copy(alpha = 0.2f) else BaNavyElevated, RoundedCornerShape(4.dp))
                        .border(1.dp, if (trip.cabinName == "FIRST") BaGold else BaSkyBlue, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = trip.cabinName,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (trip.cabinName == "FIRST") BaGold else BaSkyBlue
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Cities & Flight
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = trip.originCode, style = MaterialTheme.typography.displayMedium, color = BaWarmWhite)
                    Text(text = trip.originName, style = MaterialTheme.typography.labelMedium, color = BaSilver)
                    Text(text = "${trip.originTerminal} • ${trip.departureTime}", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = trip.flightNumber, style = MaterialTheme.typography.labelMedium, color = BaSkyBlue)
                    Icon(
                        imageVector = Icons.Default.Flight,
                        contentDescription = null,
                        tint = BaSpeedmarqueRed,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(text = trip.flightDate, style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = trip.destCode, style = MaterialTheme.typography.displayMedium, color = BaWarmWhite)
                    Text(text = trip.destName, style = MaterialTheme.typography.labelMedium, color = BaSilver)
                    Text(text = "${trip.destTerminal} • ${trip.arrivalTime}", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                }
            }

            if (trip.isConnecting) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BaNavyElevated, RoundedCornerShape(6.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "CONNECTING FLIGHT: ${trip.connFlightNumber} → ${trip.connDest} (${trip.connGate})",
                        style = MaterialTheme.typography.labelSmall,
                        color = BaSkyBlue
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SEAT: ${trip.seat} • GATE: ${trip.gate}",
                    style = MaterialTheme.typography.labelMedium,
                    color = BaWarmWhite
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(BaNavyElevated)
                        .border(1.dp, BaSkyBlue.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .clickable(onClick = onViewPass)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AirplaneTicket, contentDescription = null, tint = BaSkyBlue, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("BOARDING PASS", style = MaterialTheme.typography.labelSmall, color = BaWarmWhite)
                    }
                }
            }
        }
    }
}

@Composable
private fun TripDetailView(
    trip: TripEntity,
    onBack: () -> Unit,
    onViewBoardingPass: () -> Unit,
    onCheckIn: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BaDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("trip_detail_view"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = BaWarmWhite)
                }
                Text(
                    text = "${trip.originName.uppercase()} → ${trip.destName.uppercase()}",
                    style = MaterialTheme.typography.headlineMedium,
                    color = BaWarmWhite
                )
            }
        }

        // Full Aircraft & Booking Spec
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaBorderNavy)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("FLIGHT NUMBER", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                            Text(trip.flightNumber, style = MaterialTheme.typography.titleLarge, color = BaSkyBlue)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("AIRCRAFT", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                            Text(trip.aircraft, style = MaterialTheme.typography.bodyMedium, color = BaWarmWhite)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("CABIN & SEAT", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                            Text("${trip.cabinName} • Suite ${trip.seat}", style = MaterialTheme.typography.titleMedium, color = BaGold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("BOARDING GROUP", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                            Text("Group ${trip.boardingGroup} (Priority)", style = MaterialTheme.typography.titleMedium, color = BaWarmWhite)
                        }
                    }
                }
            }
        }

        // Section 18: Vertical Journey Timeline
        item {
            Text(
                text = "JOURNEY PROGRESSION TIMELINE",
                style = MaterialTheme.typography.labelSmall,
                color = BaMutedSilver
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavyCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaNavyLight.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    TimelineItem(title = "BOOKING CONFIRMED", subtitle = "Reference: ${trip.bookingRef}", isDone = true)
                    TimelineItem(title = "CHECKED IN", subtitle = "Digital boarding pass generated", isDone = true)
                    TimelineItem(title = "FAST TRACK / FIRST WING SECURITY", subtitle = "Heathrow Terminal 5 • 3 min wait", isCurrent = true)
                    TimelineItem(title = "CONCORDE ROOM LOUNGE", subtitle = "Open • Laurent-Perrier Champagne Bar", isDone = false)
                    TimelineItem(title = "GATE ${trip.gate}", subtitle = "Gate opens 07:00", isDone = false)
                    TimelineItem(title = "BOARDING", subtitle = "07:10 GMT • Group ${trip.boardingGroup}", isDone = false)
                    TimelineItem(title = "DEPARTURE", subtitle = "${trip.departureTime} GMT • On Time", isDone = false)
                    TimelineItem(title = "ARRIVAL", subtitle = "${trip.arrivalTime} EST • New York JFK Terminal 7", isDone = false, isLast = true)
                }
            }
        }

        // Action Buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(BaSpeedmarqueRed)
                        .clickable(onClick = onViewBoardingPass)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("VIEW BOARDING PASS", style = MaterialTheme.typography.labelLarge, color = BaWarmWhite)
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun TimelineItem(
    title: String,
    subtitle: String,
    isDone: Boolean = false,
    isCurrent: Boolean = false,
    isLast: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            isDone -> BaGreenSuccess
                            isCurrent -> BaSkyBlue
                            else -> BaNavyElevated
                        }
                    )
                    .border(
                        1.dp,
                        when {
                            isDone -> BaGreenSuccess
                            isCurrent -> BaWarmWhite
                            else -> BaBorderNavy
                        },
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isDone) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BaDarkBackground, modifier = Modifier.size(12.dp))
                }
            }
            if (!isLast) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(34.dp)
                        .background(if (isDone) BaGreenSuccess.copy(alpha = 0.5f) else BaBorderNavy)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.padding(bottom = if (isLast) 0.dp else 16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = when {
                    isCurrent -> BaSkyBlue
                    isDone -> BaWarmWhite
                    else -> BaMutedSilver
                }
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = if (isCurrent) BaWarmWhite else BaSilver
            )
        }
    }
}
