package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.AirlineSeatReclineExtra
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocalParking
import androidx.compose.material.icons.filled.Luggage
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TripEntity
import com.example.model.CabinClass
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaDarkBackground
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

@Composable
fun ManageBookingScreen(
    trip: TripEntity?,
    onNavigateToSeatChange: () -> Unit,
    onUpgradeCabin: (CabinClass) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentTrip = trip ?: return

    var selectedMeal by remember { mutableStateOf("British Airways Signature Fine Dining") }
    var selectedAssistance by remember { mutableStateOf("None Required") }

    val meals = listOf(
        "British Airways Signature Fine Dining",
        "Vegetarian Vegan Meal (VGML)",
        "Kosher Meal (KSML)",
        "Halal Meal (MOML)",
        "Gluten Intolerant Meal (GFML)",
        "Diabetic Meal (DBML)"
    )

    val assistanceOptions = listOf(
        "None Required",
        "Wheelchair to Aircraft Door (WCHC)",
        "Mobility Assistance at Concourse (WCHS)",
        "Visual Assistance (BLND)",
        "Deaf / Hearing Assistance (DEAF)",
        "Family Travelling with Infant (Bassinet)"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BaDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("manage_booking_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        // Section 37: Header
        item {
            Column {
                Text(
                    text = "BRITISH AIRWAYS • MANAGE MY BOOKING",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaSkyBlue
                )
                Text(
                    text = "MANAGE JOURNEY",
                    style = MaterialTheme.typography.headlineLarge,
                    color = BaWarmWhite
                )
                Text(
                    text = "Flight ${currentTrip.flightNumber} • Ref: ${currentTrip.bookingRef}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                    color = BaGold
                )
            }
        }

        // Section 38: Cabin Upgrade Hub
        item {
            Text("CABIN UPGRADE OPTIONS", style = MaterialTheme.typography.labelSmall, color = BaGold)
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaGold)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("CURRENT CABIN", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                            Text(currentTrip.cabinName, style = MaterialTheme.typography.titleMedium, color = BaWarmWhite)
                        }
                        Box(
                            modifier = Modifier
                                .background(BaNavyElevated, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("Suite ${currentTrip.seat}", style = MaterialTheme.typography.labelSmall, color = BaSkyBlue)
                        }
                    }

                    HorizontalDivider(color = BaNavyLight.copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 10.dp))

                    if (currentTrip.cabinName != "FIRST") {
                        UpgradeOptionRow(
                            targetCabin = "FIRST CLASS",
                            price = "£1,280",
                            features = "First Wing, Concorde Room, Laurent-Perrier Champagne, 79\" Flat Bed",
                            onUpgrade = {
                                onUpgradeCabin(CabinClass.FIRST)
                                Toast.makeText(context, "Upgraded to British Airways First", Toast.LENGTH_SHORT).show()
                            }
                        )
                    } else {
                        Text(
                            text = "You are confirmed in British Airways First — our highest tier of luxury hospitality.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BaGold
                        )
                    }
                }
            }
        }

        // Seat Selection Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onNavigateToSeatChange),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavyCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaBorderNavy)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AirlineSeatReclineExtra, contentDescription = null, tint = BaSkyBlue, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("CHANGE SEAT ASSIGNMENT", style = MaterialTheme.typography.titleMedium, color = BaWarmWhite)
                            Text("Currently Suite ${currentTrip.seat} • View Aircraft Cross-Section", style = MaterialTheme.typography.bodyMedium, color = BaSilver)
                        }
                    }
                    Text("CHANGE →", style = MaterialTheme.typography.labelSmall, color = BaSkyBlue)
                }
            }
        }

        // Section 49: Special Dietary & Meals
        item {
            Text("SPECIAL MEALS & DIETARY REQUIREMENTS", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        }

        items(meals) { meal ->
            val isSelected = selectedMeal == meal
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedMeal = meal },
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = if (isSelected) BaNavyElevated else BaNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) BaGold else BaBorderNavy)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Restaurant, contentDescription = null, tint = if (isSelected) BaGold else BaSilver, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(meal, style = MaterialTheme.typography.bodyMedium, color = if (isSelected) BaWarmWhite else BaSilver)
                    }
                    if (isSelected) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = BaGold, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Section 49: Accessibility Assistance
        item {
            Text("PASSENGER ACCESSIBILITY & ASSISTANCE", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        }

        items(assistanceOptions) { req ->
            val isSelected = selectedAssistance == req
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedAssistance = req },
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = if (isSelected) BaNavyElevated else BaNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) BaSkyBlue else BaBorderNavy)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Accessible, contentDescription = null, tint = if (isSelected) BaSkyBlue else BaSilver, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(req, style = MaterialTheme.typography.bodyMedium, color = if (isSelected) BaWarmWhite else BaSilver)
                    }
                    if (isSelected) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = BaSkyBlue, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Section 39: Trip Extras
        item {
            Text("TRAVEL EXTRAS & CONCIERGE", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExtraCard(
                    title = "Additional Baggage",
                    price = "£65 / 23kg bag",
                    icon = Icons.Default.Luggage,
                    modifier = Modifier.weight(1f),
                    onClick = { Toast.makeText(context, "Extra 23kg bag added to BA 017", Toast.LENGTH_SHORT).show() }
                )
                ExtraCard(
                    title = "Heathrow Valet Parking",
                    price = "£110 / 7 days",
                    icon = Icons.Default.LocalParking,
                    modifier = Modifier.weight(1f),
                    onClick = { Toast.makeText(context, "Valet parking booked at T5", Toast.LENGTH_SHORT).show() }
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun UpgradeOptionRow(
    targetCabin: String,
    price: String,
    features: String,
    onUpgrade: () -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("UPGRADE TO $targetCabin", style = MaterialTheme.typography.titleMedium, color = BaGold)
                Text(features, style = MaterialTheme.typography.labelSmall, color = BaSilver)
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(BaGold)
                    .clickable(onClick = onUpgrade)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(price, style = MaterialTheme.typography.labelLarge, color = BaDarkBackground)
            }
        }
    }
}

@Composable
private fun ExtraCard(
    title: String,
    price: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(BaNavySurface)
            .border(1.dp, BaBorderNavy, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Column {
            Icon(imageVector = icon, contentDescription = title, tint = BaSkyBlue, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = title, style = MaterialTheme.typography.labelMedium, color = BaWarmWhite)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = price, style = MaterialTheme.typography.labelSmall, color = BaGold)
        }
    }
}
