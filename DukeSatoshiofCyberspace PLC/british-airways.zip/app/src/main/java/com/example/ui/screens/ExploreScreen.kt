package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaDarkBackground
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

data class DestinationItem(
    val city: String,
    val country: String,
    val airportCode: String,
    val flightNo: String,
    val aircraft: String,
    val duration: String,
    val imageRes: Int,
    val highlight: String
)

@Composable
fun ExploreScreen(
    onSelectDestination: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val destinations = listOf(
        DestinationItem(
            city = "NEW YORK",
            country = "UNITED STATES",
            airportCode = "JFK",
            flightNo = "BA 017",
            aircraft = "Boeing 777-300ER",
            duration = "7h 20m Direct",
            imageRes = R.drawable.ba_newyork_skyline,
            highlight = "Up to 8 daily flights from Heathrow T5 to JFK Terminal 7 with First Suite service."
        ),
        DestinationItem(
            city = "TOKYO",
            country = "JAPAN",
            airportCode = "HND",
            flightNo = "BA 005",
            aircraft = "Boeing 787-10 Dreamliner",
            duration = "14h 20m Direct",
            imageRes = R.drawable.ba_aircraft_hero,
            highlight = "Non-stop daily service to Tokyo Haneda with Club World Suite and Japanese dining."
        ),
        DestinationItem(
            city = "SINGAPORE",
            country = "SINGAPORE",
            airportCode = "SIN",
            flightNo = "BA 011",
            aircraft = "Airbus A380 Superjumbo",
            duration = "13h 10m Direct",
            imageRes = R.drawable.ba_aircraft_hero,
            highlight = "Flagship double-decker A380 service to Changi Airport Terminal 1."
        ),
        DestinationItem(
            city = "CAPE TOWN",
            country = "SOUTH AFRICA",
            airportCode = "CPT",
            flightNo = "BA 059",
            aircraft = "Airbus A350-1000",
            duration = "11h 35m Direct",
            imageRes = R.drawable.ba_newyork_skyline,
            highlight = "Overnight flagship flight to the Western Cape with zero jet lag."
        )
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BaDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("explore_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        // Section 43: Header
        item {
            Column {
                Text(
                    text = "BRITISH AIRWAYS • GLOBAL DESTINATIONS",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaSkyBlue
                )
                Text(
                    text = "WHERE WILL YOU GO?",
                    style = MaterialTheme.typography.displayMedium,
                    color = BaWarmWhite
                )
                Text(
                    text = "Aviation-led discovery of British Airways intercontinental routes.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = BaSilver
                )
            }
        }

        items(destinations) { dest ->
            DestinationCard(item = dest, onBook = { onSelectDestination(dest.city) })
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun DestinationCard(
    item: DestinationItem,
    onBook: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onBook)
            .testTag("destination_card_${item.airportCode}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = BaNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, BaBorderNavy)
    ) {
        Column {
            // Visual header image
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
            ) {
                Image(
                    painter = painterResource(id = item.imageRes),
                    contentDescription = item.city,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                colors = listOf(androidx.compose.ui.graphics.Color.Transparent, BaNavySurface)
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(14.dp)
                ) {
                    Text(item.country, style = MaterialTheme.typography.labelSmall, color = BaSkyBlue)
                    Text(item.city, style = MaterialTheme.typography.headlineLarge, color = BaWarmWhite)
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .background(BaNavySurface.copy(alpha = 0.85f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(item.airportCode, style = MaterialTheme.typography.titleMedium, color = BaGold)
                }
            }

            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("FLIGHT & FLEET", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                        Text("${item.flightNo} • ${item.aircraft}", style = MaterialTheme.typography.bodyMedium, color = BaWarmWhite)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("DURATION", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                        Text(item.duration, style = MaterialTheme.typography.bodyMedium, color = BaSkyBlue)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(item.highlight, style = MaterialTheme.typography.bodyMedium, color = BaSilver)

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(BaSpeedmarqueRed)
                            .clickable(onClick = onBook)
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("EXPLORE FLIGHTS", style = MaterialTheme.typography.labelSmall, color = BaWarmWhite)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = BaWarmWhite, modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }
        }
    }
}
