package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CabinClass
import com.example.model.DisruptionState
import com.example.model.JourneyState
import com.example.ui.theme.BaAmberWarning
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

@Composable
fun JourneyStateController(
    currentState: JourneyState,
    currentDisruption: DisruptionState,
    onStateSelect: (JourneyState) -> Unit,
    onDisruptionToggle: (DisruptionState) -> Unit,
    onSelectDemo: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(BaNavySurface)
            .border(1.dp, BaNavyLight, RoundedCornerShape(12.dp))
            .padding(10.dp)
            .testTag("journey_state_controller")
    ) {
        // Collapsible Header bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { isExpanded = !isExpanded },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(if (currentDisruption != DisruptionState.ON_TIME) BaAmberWarning else BaGreenSuccess, CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "BA.OS JOURNEY STATE ENGINE",
                        style = MaterialTheme.typography.labelSmall,
                        color = BaSkyBlue
                    )
                    Text(
                        text = "STAGE: ${currentState.label.uppercase()} ${if (currentDisruption != DisruptionState.ON_TIME) "• " + currentDisruption.title else ""}",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (currentDisruption != DisruptionState.ON_TIME) BaAmberWarning else BaWarmWhite
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (isExpanded) "CLOSE" else "SWITCH STAGE / DEMO",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaSilver
                )
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = BaSilver,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        AnimatedVisibility(
            visible = isExpanded,
            enter = expandVertically(),
            exit = shrinkVertically()
        ) {
            Column(modifier = Modifier.padding(top = 10.dp)) {
                // 5 Signature Demos Selector
                Text(
                    text = "SPECIFICATION SIGNATURE DEMOS",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaGold
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    item {
                        DemoChip(title = "Demo 1: LHR → JFK First", onClick = { onSelectDemo(1) })
                    }
                    item {
                        DemoChip(title = "Demo 2: Connection to LAX", onClick = { onSelectDemo(2) })
                    }
                    item {
                        DemoChip(title = "Demo 3: Disruption + Rebook", onClick = { onSelectDemo(3) })
                    }
                    item {
                        DemoChip(title = "Demo 4: First Wing & Concorde", onClick = { onSelectDemo(4) })
                    }
                    item {
                        DemoChip(title = "Demo 5: World Traveller", onClick = { onSelectDemo(5) })
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 15 Journey States Selector
                Text(
                    text = "STEP-BY-STEP PASSENGER JOURNEY STATES (15 STAGES)",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaMutedSilver
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(JourneyState.values()) { state ->
                        val isSelected = currentState == state
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) BaSpeedmarqueRed else BaNavyElevated)
                                .border(
                                    1.dp,
                                    if (isSelected) BaWarmWhite else BaBorderNavy,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { onStateSelect(state) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = state.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) BaWarmWhite else BaSilver
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Disruption Toggle Strip
                Text(
                    text = "DISRUPTION ENGINE SIMULATOR",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaAmberWarning
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(DisruptionState.values()) { dis ->
                        val isCurrent = currentDisruption == dis
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isCurrent) BaAmberWarning.copy(alpha = 0.25f) else BaNavyElevated)
                                .border(
                                    1.dp,
                                    if (isCurrent) BaAmberWarning else BaBorderNavy,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { onDisruptionToggle(dis) }
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = dis.title,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isCurrent) BaAmberWarning else BaMutedSilver
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DemoChip(title: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(BaNavyElevated)
            .border(1.dp, BaGold.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = BaGold, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = title, style = MaterialTheme.typography.labelSmall, color = BaWarmWhite)
        }
    }
}
