package com.example.model

enum class JourneyState(val label: String, val description: String) {
    BOOKED("Booked", "Trip confirmed. Flight details reserved."),
    CHECK_IN_OPEN("Check-in Open", "Online check-in is now open (48h before departure)."),
    CHECKED_IN("Checked In", "Digital boarding pass issued. Ready for travel."),
    BAG_DROP("Bag Drop", "Drop hold luggage at Heathrow T5 Zone C/J."),
    SECURITY("Security", "The First Wing / Fast Track security clearance."),
    AIRPORT("At Heathrow T5", "Explore Terminal 5 departures and galleries."),
    LOUNGE("Concorde Room", "Relax in the British Airways Concorde Room."),
    GATE("Gate Open", "Proceed to Gate A20. Flight preparing for boarding."),
    BOARDING("Boarding Now", "Group 1 priority boarding underway."),
    DEPARTED("Departed", "Aircraft pushed back and airborne."),
    IN_FLIGHT("In Flight", "Cruising at 36,000 ft across the North Atlantic."),
    CONNECTING("Connecting", "Transfer in progress at connection hub."),
    ARRIVED("Arrived", "Welcome to New York JFK. Aircraft at gate."),
    BAGGAGE("Baggage Claim", "Luggage arriving on Baggage Belt 8."),
    COMPLETED("Journey Complete", "Journey finished. Executive Club Avios awarded.")
}

enum class DisruptionState(val title: String) {
    ON_TIME("On Time"),
    DELAYED("Delayed (+55 min)"),
    GATE_CHANGED("Gate Changed (A20 → A24)"),
    CANCELLED("Flight Cancelled"),
    DIVERTED("Diverted"),
    BAGGAGE_DELAY("Baggage Delayed"),
    CONNECTION_AT_RISK("Connection At Risk")
}

enum class CabinClass(val displayName: String, val code: String, val description: String) {
    FIRST("First", "F", "Private suite, Flat bed, Fine dining, First Wing & Concorde Room access"),
    CLUB("Club World", "J", "Club Suite with privacy door, 79\" flat bed, Lounge access"),
    WORLD_TRAVELLER_PLUS("World Traveller Plus", "W", "Wider seat, 38\" pitch legroom, Premium dining, Priority boarding"),
    WORLD_TRAVELLER("World Traveller", "Y", "Ergonomic contour seat, 31\" pitch, Inflight entertainment & Wi-Fi")
}

data class Flight(
    val id: String,
    val flightNumber: String,
    val originCode: String,
    val originName: String,
    val originTerminal: String,
    val destCode: String,
    val destName: String,
    val destTerminal: String,
    val departureTime: String,
    val arrivalTime: String,
    val duration: String,
    val aircraft: String,
    val gate: String,
    val seat: String,
    val cabin: CabinClass,
    val bookingRef: String,
    val boardingGroup: Int = 1,
    val priceFirst: Int = 4820,
    val priceClub: Int = 1920,
    val priceWtp: Int = 980,
    val priceWt: Int = 610
)

data class FlightTelemetry(
    val altitudeFt: Int = 36000,
    val groundSpeedKt: Int = 482,
    val distanceRemainingMi: Int = 2814,
    val outsideTempC: Int = -54,
    val headingDeg: Int = 288,
    val progressPct: Float = 0.42f,
    val estimatedArrival: String = "11:05 EST"
)

data class BaggageTrackItem(
    val tagNumber: String,
    val weightKg: Int,
    val passengerName: String,
    val status: String,
    val currentLocation: String,
    val beltNumber: String,
    val stagesCompleted: Int
)

data class PassengerProfile(
    val name: String = "Tom Loveitt",
    val title: String = "Mr",
    val tier: String = "Gold",
    val aviosBalance: Int = 124800,
    val tierPoints: Int = 1340,
    val nextTierThreshold: Int = 1500,
    val membershipNumber: String = "BA 9482 1042",
    val passportMasked: String = "GBR ••••••••42",
    val nationality: String = "British",
    val mealPreference: String = "British Airways Seasonal Fine Dining",
    val assistanceReq: String = "None"
)

data class ConnectionPlan(
    val arriveTime: String = "12:05",
    val disembarkTime: String = "12:18",
    val passportControlTime: String = "12:34",
    val securityTime: String = "12:49",
    val transferTime: String = "13:05",
    val gateTime: String = "13:21",
    val boardingTime: String = "13:47",
    val walkTimeMin: Int = 18,
    val securityMin: Int = 12,
    val bufferMin: Int = 72,
    val totalAvailableMin: Int = 102,
    val connectingFlightNumber: String = "BA 1512",
    val destination: String = "Los Angeles LAX",
    val connectionTerminal: String = "Terminal 4",
    val connectionGate: String = "Gate B12",
    val isAtRisk: Boolean = false
)
