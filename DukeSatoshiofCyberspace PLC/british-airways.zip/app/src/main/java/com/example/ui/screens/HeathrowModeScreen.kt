package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Train
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.DisruptionState
import com.example.ui.components.FlightBoardView
import com.example.ui.components.VectorAirportMap
import com.example.ui.theme.BaAmberWarning
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaDarkBackground
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

@Composable
fun HeathrowModeScreen(
    currentGate: String = "A20",
    disruptionState: DisruptionState = DisruptionState.ON_TIME,
    onSimulateGateChange: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var isGateChangedLocally by remember(disruptionState) {
        mutableStateOf(disruptionState == DisruptionState.GATE_CHANGED)
    }

    val activeGate = if (isGateChangedLocally) "A24" else currentGate

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BaDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("heathrow_mode_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        // Section 22: Header
        item {
            Column {
                Text(
                    text = "LOCATION-AWARE AIRPORT INFRASTRUCTURE",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaSkyBlue
                )
                Text(
                    text = "HEATHROW TERMINAL 5",
                    style = MaterialTheme.typography.headlineLarge,
                    color = BaWarmWhite
                )
                Text(
                    text = "British Airways flagship global hub • Terminals 5A, 5B, 5C & The First Wing.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = BaSilver
                )
            }
        }

        // Live Airport Status Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AirportMetricCard(
                    title = "CHECK-IN",
                    value = "THE FIRST WING",
                    subtext = "Dedicated Zone J",
                    isGold = true,
                    modifier = Modifier.weight(1f)
                )
                AirportMetricCard(
                    title = "FAST TRACK SECURITY",
                    value = "3 MIN WAIT",
                    subtext = "Main Security: 12 min",
                    isGreen = true,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AirportMetricCard(
                    title = "CURRENT GATE",
                    value = "GATE $activeGate",
                    subtext = if (isGateChangedLocally) "Gate Recalculated!" else "14 min walk from First Wing",
                    isAlert = isGateChangedLocally,
                    modifier = Modifier.weight(1f)
                )
                AirportMetricCard(
                    title = "BOARDING TIME",
                    value = "07:10 GMT",
                    subtext = "Group 1 Priority Call",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Section 23 & 24: Vector Map & Interactive Wayfinding
        item {
            VectorAirportMap(
                targetGate = activeGate,
                isGateChanged = isGateChangedLocally
            )
        }

        // Simulate Gate Change Button
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isGateChangedLocally) BaNavyElevated else BaNavyCard)
                    .border(1.dp, if (isGateChangedLocally) BaAmberWarning else BaSkyBlue, RoundedCornerShape(8.dp))
                    .clickable {
                        isGateChangedLocally = !isGateChangedLocally
                        onSimulateGateChange()
                    }
                    .padding(vertical = 12.dp, horizontal = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AltRoute,
                        contentDescription = null,
                        tint = if (isGateChangedLocally) BaAmberWarning else BaSkyBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isGateChangedLocally) "RESET GATE BACK TO A20" else "SIMULATE GATE CHANGE (A20 → A24)",
                        style = MaterialTheme.typography.labelSmall,
                        color = BaWarmWhite
                    )
                }
            }
        }

        // Transit Shuttle to Satellite Concourse (T5B / T5C)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavyCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaNavyLight.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Train, contentDescription = null, tint = BaSkyBlue, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("TTS AUTOMATED TRANSIT SYSTEM", style = MaterialTheme.typography.labelSmall, color = BaSkyBlue)
                        Text("Shuttle trains running every 90 seconds to T5B and T5C gates.", style = MaterialTheme.typography.bodyMedium, color = BaWarmWhite)
                        Text("Located at Level -4 via escalators past security.", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                    }
                }
            }
        }

        // Section 55: Airport Departures Flight Board
        item {
            FlightBoardView()
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun AirportMetricCard(
    title: String,
    value: String,
    subtext: String,
    modifier: Modifier = Modifier,
    isGold: Boolean = false,
    isGreen: Boolean = false,
    isAlert: Boolean = false
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = BaNavySurface),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            when {
                isAlert -> BaAmberWarning
                isGold -> BaGold
                else -> BaBorderNavy
            }
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                color = when {
                    isAlert -> BaAmberWarning
                    isGold -> BaGold
                    isGreen -> BaGreenSuccess
                    else -> BaWarmWhite
                }
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtext, style = MaterialTheme.typography.labelSmall, color = BaSilver)
        }
    }
}
