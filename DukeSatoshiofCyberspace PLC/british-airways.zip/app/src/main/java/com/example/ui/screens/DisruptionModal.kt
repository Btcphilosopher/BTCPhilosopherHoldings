package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.TripEntity
import com.example.ui.theme.BaAmberWarning
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaDarkBackground
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

data class AlternativeOption(
    val flightNo: String,
    val depTime: String,
    val arrTime: String,
    val aircraft: String,
    val gate: String,
    val cabinAvailable: String
)

@Composable
fun DisruptionModal(
    trip: TripEntity,
    onDismiss: () -> Unit,
    onConfirmRebook: (AlternativeOption) -> Unit
) {
    val context = LocalContext.current

    val alternatives = remember {
        listOf(
            AlternativeOption("BA 019", "09:20", "12:40", "Boeing 777-300ER", "Gate A14", "First Suite & Club Available"),
            AlternativeOption("BA 021", "12:10", "15:30", "Airbus A350-1000", "Gate B34", "First Suite & Club Available")
        )
    }

    var selectedOption by remember { mutableStateOf(alternatives.first()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .testTag("disruption_rebooking_dialog"),
            colors = CardDefaults.cardColors(containerColor = BaNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, BaAmberWarning)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = BaAmberWarning, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "FLIGHT DISRUPTION REBOOKING",
                            style = MaterialTheme.typography.labelSmall,
                            color = BaAmberWarning
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = BaSilver)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "YOUR FLIGHT HAS CHANGED",
                    style = MaterialTheme.typography.headlineMedium,
                    color = BaWarmWhite
                )
                Text(
                    text = "${trip.flightNumber} London (LHR) to New York (JFK) is delayed +55m (New Dep: 08:35). Complimentary rebooking is authorized under British Airways passenger charter.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = BaSilver
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text("ALTERNATIVE DEPARTURES TODAY", style = MaterialTheme.typography.labelSmall, color = BaGold)
                Spacer(modifier = Modifier.height(8.dp))

                alternatives.forEach { alt ->
                    val isSelected = selectedOption == alt
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { selectedOption = alt },
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) BaNavyElevated else BaNavyCard),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) BaGold else BaBorderNavy)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${alt.flightNo} • Departs ${alt.depTime} GMT",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (isSelected) BaGold else BaWarmWhite
                                )
                                Text(
                                    text = "Arrives JFK ${alt.arrTime} EST • ${alt.aircraft}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = BaSilver
                                )
                                Text(
                                    text = "${alt.gate} • ${alt.cabinAvailable}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BaGreenSuccess
                                )
                            }
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = BaGold, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Actions
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(BaSpeedmarqueRed)
                        .clickable {
                            onConfirmRebook(selectedOption)
                            Toast.makeText(context, "Rebooked onto ${selectedOption.flightNo}", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "CONFIRM REBOOKING ONTO ${selectedOption.flightNo}",
                        style = MaterialTheme.typography.labelMedium,
                        color = BaWarmWhite
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(BaNavyElevated)
                        .clickable(onClick = onDismiss)
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("KEEP ORIGINAL FLIGHT (08:35)", style = MaterialTheme.typography.labelSmall, color = BaSilver)
                }
            }
        }
    }
}
