package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val BaColorScheme = darkColorScheme(
    primary = BaSkyBlue,
    onPrimary = BaDeepNavy,
    primaryContainer = BaNavyLight,
    onPrimaryContainer = BaWarmWhite,
    secondary = BaGold,
    onSecondary = BaDeepNavy,
    secondaryContainer = BaBurgundy,
    onSecondaryContainer = BaWarmWhite,
    tertiary = BaSpeedmarqueRed,
    onTertiary = BaWarmWhite,
    background = BaDarkBackground,
    onBackground = BaWarmWhite,
    surface = BaNavySurface,
    onSurface = BaWarmWhite,
    surfaceVariant = BaNavyCard,
    onSurfaceVariant = BaSilver,
    outline = BaBorderNavy,
    outlineVariant = BaNavyLight
)

@Composable
fun BritishAirwaysTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // BA.OS uses the signature Anglo-Futurist dark luxury aesthetic consistently
    MaterialTheme(
        colorScheme = BaColorScheme,
        typography = Typography,
        content = content
    )
}
