package com.example.data

import com.example.model.CabinClass
import com.example.model.DisruptionState
import com.example.model.JourneyState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FlightRepository(
    private val database: AppDatabase,
    private val scope: CoroutineScope
) {
    private val tripDao = database.tripDao()
    private val baggageDao = database.baggageDao()
    private val profileDao = database.profileDao()

    val allTrips: Flow<List<TripEntity>> = tripDao.getAllTrips()
    val baggageList: Flow<List<BaggageEntity>> = baggageDao.getAllBaggage()
    val userProfile: Flow<ProfileEntity?> = profileDao.getProfile()

    init {
        scope.launch(Dispatchers.IO) {
            checkAndSeedIfEmpty()
        }
    }

    private suspend fun checkAndSeedIfEmpty() {
        val existing = tripDao.getAllTrips().firstOrNull()
        if (existing.isNullOrEmpty()) {
            populateInitialData(database)
        }
    }

    fun getTripById(id: String): Flow<TripEntity?> = tripDao.getTripById(id)

    suspend fun updateJourneyState(tripId: String, state: JourneyState) = withContext(Dispatchers.IO) {
        tripDao.updateJourneyState(tripId, state.name)
        // Also advance baggage stages dynamically
        val baggageStage = when (state) {
            JourneyState.BOOKED, JourneyState.CHECK_IN_OPEN -> 0
            JourneyState.CHECKED_IN, JourneyState.BAG_DROP -> 1
            JourneyState.SECURITY, JourneyState.AIRPORT, JourneyState.LOUNGE -> 2
            JourneyState.GATE, JourneyState.BOARDING -> 3
            JourneyState.DEPARTED, JourneyState.IN_FLIGHT -> 4
            JourneyState.ARRIVED, JourneyState.BAGGAGE, JourneyState.COMPLETED -> 5
            else -> 1
        }
        val baggageStatus = when (baggageStage) {
            0 -> "Pending Bag Drop"
            1 -> "Checked in at T5 Zone C"
            2 -> "Security Clearance & Bag Sorting"
            3 -> "Loaded onto Hold Aircraft"
            4 -> "In Flight — Hold Cargo Bay 2"
            5 -> "Delivered to Baggage Belt 8"
            else -> "In Transit"
        }
        val baggageLoc = when (baggageStage) {
            0, 1 -> "Heathrow Terminal 5 Zone C"
            2 -> "Heathrow T5 Automated Baggage Hall"
            3 -> "Boeing 777 Aircraft Hold"
            4 -> "In Flight (Cruising Altitude)"
            5 -> "New York JFK Terminal 7 Baggage Claim"
            else -> "Terminal 5"
        }
        baggageDao.updateStatus("BA123456", baggageStatus, baggageLoc, baggageStage)
        baggageDao.updateStatus("BA123457", baggageStatus, baggageLoc, baggageStage)
    }

    suspend fun updateDisruption(tripId: String, disruption: DisruptionState, gate: String) = withContext(Dispatchers.IO) {
        tripDao.updateDisruption(tripId, disruption.name, gate)
    }

    suspend fun updateSeatAndCabin(tripId: String, seat: String, cabin: CabinClass) = withContext(Dispatchers.IO) {
        tripDao.updateSeatAndCabin(tripId, seat, cabin.name)
    }

    suspend fun rebookFlight(
        tripId: String,
        newFlightNum: String,
        newDep: String,
        newArr: String,
        newGate: String
    ) = withContext(Dispatchers.IO) {
        val current = tripDao.getTripById(tripId).firstOrNull() ?: return@withContext
        val updated = current.copy(
            flightNumber = newFlightNum,
            departureTime = newDep,
            arrivalTime = newArr,
            gate = newGate,
            disruptionStateName = DisruptionState.ON_TIME.name
        )
        tripDao.updateTrip(updated)
    }

    suspend fun createTrip(trip: TripEntity) = withContext(Dispatchers.IO) {
        tripDao.insertTrip(trip)
    }
}
