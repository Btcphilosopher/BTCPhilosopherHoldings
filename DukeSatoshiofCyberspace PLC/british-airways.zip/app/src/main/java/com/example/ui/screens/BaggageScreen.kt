package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Luggage
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BaggageEntity
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaDarkBackground
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

@Composable
fun BaggageScreen(
    baggageList: List<BaggageEntity>,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BaDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("baggage_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        // Section 21: Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "BRITISH AIRWAYS • HOLD BAGGAGE RECONCILIATION",
                        style = MaterialTheme.typography.labelSmall,
                        color = BaSkyBlue
                    )
                    Text(
                        text = "YOUR BAGGAGE",
                        style = MaterialTheme.typography.headlineLarge,
                        color = BaWarmWhite
                    )
                }
                Box(
                    modifier = Modifier
                        .background(BaNavyElevated, RoundedCornerShape(4.dp))
                        .border(1.dp, BaGold.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("SIMULATED DATA", style = MaterialTheme.typography.labelSmall, color = BaGold)
                }
            }
        }

        items(baggageList) { bag ->
            BaggageItemCard(bag = bag)
        }

        // Baggage Delivery Guarantee Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavyCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaNavyLight.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("FIRST CLASS PRIORITY BAGGAGE", style = MaterialTheme.typography.labelSmall, color = BaGold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Your bags are tagged with British Airways Priority First ribbons and will be among the first on Baggage Belt 8 at JFK Terminal 7.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BaSilver
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun BaggageItemCard(bag: BaggageEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = BaNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, BaBorderNavy)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Luggage, contentDescription = null, tint = BaSkyBlue, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "TAG: ${bag.tagNumber}",
                            style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
                            color = BaWarmWhite
                        )
                        Text(
                            text = "${bag.weightKg} KG • HOLD BAGGAGE",
                            style = MaterialTheme.typography.labelSmall,
                            color = BaMutedSilver
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .background(BaNavyElevated, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(bag.beltNumber, style = MaterialTheme.typography.labelSmall, color = BaGold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Current Status & Location
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BaNavyCard, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text("LATEST SCAN", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                    Text(bag.status, style = MaterialTheme.typography.titleMedium, color = BaGreenSuccess)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("Location: ${bag.location}", style = MaterialTheme.typography.bodyMedium, color = BaSilver)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Baggage Milestones
            Text("TRACKING MILESTONES", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
            Spacer(modifier = Modifier.height(8.dp))

            val stages = listOf("CHECKED IN", "SECURITY", "SORTING", "LOADED", "IN FLIGHT", "CLAIM BELT")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                stages.forEachIndexed { index, name ->
                    val isCompleted = index <= bag.stagesCompleted
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(if (isCompleted) BaGreenSuccess else BaNavyElevated)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = name,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 7.sp),
                            color = if (isCompleted) BaWarmWhite else BaMutedSilver
                        )
                    }
                }
            }
        }
    }
}
