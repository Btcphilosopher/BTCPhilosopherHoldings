package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionPlan
import com.example.ui.theme.BaAmberWarning
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaDarkBackground
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

@Composable
fun ConnectionsScreen(
    plan: ConnectionPlan = ConnectionPlan(),
    modifier: Modifier = Modifier
) {
    var isSimulatedDelay by remember { mutableStateOf(false) }

    val activeBuffer = if (isSimulatedDelay) 17 else plan.bufferMin
    val isRisk = isSimulatedDelay

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BaDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("connections_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        // Section 25: Header
        item {
            Column {
                Text(
                    text = "BRITISH AIRWAYS • MULTI-LEG JOURNEY ENGINE",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaSkyBlue
                )
                Text(
                    text = "CONNECTION ASSISTANT",
                    style = MaterialTheme.typography.headlineLarge,
                    color = BaWarmWhite
                )
                Text(
                    text = "Automated transit routing, immigration clearance & transfer buffer prediction.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = BaSilver
                )
            }
        }

        // Multi-leg Routing Summary Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaBorderNavy)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("ITINERARY: LONDON → NEW YORK → LOS ANGELES", style = MaterialTheme.typography.labelSmall, color = BaGold)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("LEG 1: BA 017", style = MaterialTheme.typography.labelSmall, color = BaSkyBlue)
                            Text("LHR → JFK", style = MaterialTheme.typography.titleLarge, color = BaWarmWhite)
                            Text("07:45 - 11:05", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                        }
                        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = BaSpeedmarqueRed, modifier = Modifier.size(20.dp))
                        Column(horizontalAlignment = Alignment.End) {
                            Text("LEG 2: BA 1512", style = MaterialTheme.typography.labelSmall, color = BaSkyBlue)
                            Text("JFK → LAX", style = MaterialTheme.typography.titleLarge, color = BaWarmWhite)
                            Text("13:47 - 16:50", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                        }
                    }
                }
            }
        }

        // Connection Risk Alert if delayed
        if (isRisk) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = BaNavyCard),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, BaAmberWarning)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = BaAmberWarning, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("CONNECTION AT RISK (+55 MIN DELAY)", style = MaterialTheme.typography.labelLarge, color = BaAmberWarning)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Buffer reduced to 17 minutes. British Airways Express Connection escort requested at JFK Gate 4.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BaSilver
                        )
                    }
                }
            }
        }

        // Section 26: Calculation Matrix
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isRisk) BaAmberWarning else BaSkyBlue.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("CONNECTION METRICS (ESTIMATED)", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        BufferMetric(title = "AVAILABLE", value = "1h 42m", sub = "102 min")
                        BufferMetric(title = "EST. WALK", value = "18 min", sub = "Terminal 4")
                        BufferMetric(title = "SECURITY", value = "12 min", sub = "TSA PreCheck")
                        BufferMetric(
                            title = "SAFETY BUFFER",
                            value = "${activeBuffer} min",
                            sub = if (isRisk) "Tight Margin" else "Optimal",
                            isAlert = isRisk,
                            isGreen = !isRisk
                        )
                    }
                }
            }
        }

        // Simulate Connection Risk Button
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isRisk) BaNavyElevated else BaNavyCard)
                    .border(1.dp, if (isRisk) BaAmberWarning else BaBorderNavy, RoundedCornerShape(8.dp))
                    .clickable { isSimulatedDelay = !isSimulatedDelay }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isRisk) "RESET CONNECTION TO ON-TIME" else "SIMULATE INBOUND DELAY (TRIGGER CONNECTION AT RISK)",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isRisk) BaAmberWarning else BaSkyBlue
                )
            }
        }

        // Section 27: Vertical Connection Timeline
        item {
            Text("CONNECTION TIMELINE AT NEW YORK JFK", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavyCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaNavyLight.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    ConnectionTimelineStep(time = plan.arriveTime, title = "ARRIVE AT GATE", desc = "BA 017 touches down at JFK T7", isDone = true)
                    ConnectionTimelineStep(time = plan.disembarkTime, title = "DISEMBARK", desc = "Priority disembarkation for First & Club", isDone = true)
                    ConnectionTimelineStep(time = plan.passportControlTime, title = "PASSPORT CONTROL", desc = "Global Entry / US Customs clearance", isCurrent = true)
                    ConnectionTimelineStep(time = plan.securityTime, title = "SECURITY SCREENING", desc = "Terminal 4 TSA Checkpoint", isDone = false)
                    ConnectionTimelineStep(time = plan.transferTime, title = "AIRTRAIN TRANSFER", desc = "Transfer from Terminal 7 to Terminal 4", isDone = false)
                    ConnectionTimelineStep(time = plan.gateTime, title = "ARRIVE AT GATE B12", desc = "Gate B12 concourse", isDone = false)
                    ConnectionTimelineStep(time = plan.boardingTime, title = "BOARDING", desc = "BA 1512 to Los Angeles LAX", isDone = false, isLast = true)
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun BufferMetric(
    title: String,
    value: String,
    sub: String,
    isAlert: Boolean = false,
    isGreen: Boolean = false
) {
    Column {
        Text(text = title, style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            color = when {
                isAlert -> BaAmberWarning
                isGreen -> BaGreenSuccess
                else -> BaWarmWhite
            }
        )
        Text(text = sub, style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = BaSilver)
    }
}

@Composable
private fun ConnectionTimelineStep(
    time: String,
    title: String,
    desc: String,
    isDone: Boolean = false,
    isCurrent: Boolean = false,
    isLast: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = time,
            style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace),
            color = if (isCurrent) BaSkyBlue else BaSilver,
            modifier = Modifier.width(52.dp)
        )

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(14.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            isDone -> BaGreenSuccess
                            isCurrent -> BaSkyBlue
                            else -> BaNavyElevated
                        }
                    )
            )
            if (!isLast) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(30.dp)
                        .background(if (isDone) BaGreenSuccess.copy(alpha = 0.5f) else BaBorderNavy)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.padding(bottom = if (isLast) 0.dp else 12.dp)) {
            Text(text = title, style = MaterialTheme.typography.labelMedium, color = BaWarmWhite)
            Text(text = desc, style = MaterialTheme.typography.labelSmall, color = BaSilver)
        }
    }
}
