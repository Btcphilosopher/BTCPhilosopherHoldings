package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CabinClass
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

@Composable
fun DigitalBoardingPass(
    passengerName: String = "Tom Loveitt",
    flightNumber: String = "BA 017",
    originCode: String = "LHR",
    originName: String = "London Heathrow",
    originTerminal: String = "Terminal 5",
    destCode: String = "JFK",
    destName: String = "New York JFK",
    flightDate: String = "18 OCT",
    departureTime: String = "07:45",
    boardingTime: String = "07:10",
    gate: String = "A20",
    seat: String = "3A",
    cabinName: String = "FIRST",
    boardingGroup: Int = 1,
    bookingRef: String = "BA-LON772K",
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(BaNavySurface)
            .border(1.dp, BaBorderNavy, RoundedCornerShape(16.dp))
            .testTag("digital_boarding_pass")
    ) {
        // Top Ribbon Header (Speedmarque Red + Navy)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(BaNavyElevated)
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(BaSpeedmarqueRed, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "BRITISH AIRWAYS",
                        style = MaterialTheme.typography.labelLarge,
                        color = BaWarmWhite
                    )
                }

                Box(
                    modifier = Modifier
                        .background(
                            if (cabinName == "FIRST") BaGold.copy(alpha = 0.2f) else BaNavyCard,
                            RoundedCornerShape(4.dp)
                        )
                        .border(
                            1.dp,
                            if (cabinName == "FIRST") BaGold else BaSkyBlue,
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = cabinName.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (cabinName == "FIRST") BaGold else BaSkyBlue
                    )
                }
            }
        }

        // Flight Route & Timing Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = originCode, style = MaterialTheme.typography.displayMedium, color = BaWarmWhite)
                    Text(text = originName, style = MaterialTheme.typography.labelMedium, color = BaSilver)
                    Text(text = originTerminal, style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = flightNumber, style = MaterialTheme.typography.labelMedium, color = BaSkyBlue)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Canvas(modifier = Modifier.width(48.dp).height(2.dp)) {
                            drawLine(
                                color = BaBorderNavy,
                                start = Offset(0f, size.height / 2),
                                end = Offset(size.width, size.height / 2),
                                strokeWidth = 2f
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "To",
                            tint = BaSpeedmarqueRed,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(text = flightDate, style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = destCode, style = MaterialTheme.typography.displayMedium, color = BaWarmWhite)
                    Text(text = destName, style = MaterialTheme.typography.labelMedium, color = BaSilver)
                    Text(text = "TERMINAL 7", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Key Flight Parameters (Boarding, Gate, Seat, Group)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BaNavyCard, RoundedCornerShape(10.dp))
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                PassParam(title = "BOARDING", value = boardingTime, isHighlighted = true)
                PassParam(title = "GATE", value = gate, isHighlighted = false)
                PassParam(title = "GROUP", value = "$boardingGroup", isHighlighted = false)
                PassParam(title = "SEAT", value = seat, isGold = cabinName == "FIRST")
            }
        }

        // Perforated Ticket Divider line
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(20.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val midY = size.height / 2

                // Left & right punch cutouts
                drawCircle(color = BaNavyElevated, radius = 10.dp.toPx(), center = Offset(0f, midY))
                drawCircle(color = BaNavyElevated, radius = 10.dp.toPx(), center = Offset(w, midY))

                // Dashed line
                drawLine(
                    color = BaBorderNavy,
                    start = Offset(14.dp.toPx(), midY),
                    end = Offset(w - 14.dp.toPx(), midY),
                    strokeWidth = 1.5f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                )
            }
        }

        // Passenger & Barcode Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("PASSENGER", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                    Text(passengerName, style = MaterialTheme.typography.titleMedium, color = BaWarmWhite)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("BOOKING REF", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                    Text(bookingRef, style = MaterialTheme.typography.titleMedium, color = BaSkyBlue)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Architectural Aztec 2D Barcode pattern
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .background(Color.White, RoundedCornerShape(8.dp))
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val barColor = Color.Black

                    // Draw stylized PDF417 / Aztec airline barcode lines
                    var x = 8f
                    var seed = 42
                    while (x < w - 8f) {
                        seed = (seed * 1103515245 + 12345) and 0x7fffffff
                        val barWidth = if (seed % 3 == 0) 4f else if (seed % 5 == 0) 6f else 2f
                        drawRect(
                            color = barColor,
                            topLeft = Offset(x, 4f),
                            size = Size(barWidth, h - 8f)
                        )
                        x += barWidth + (if (seed % 2 == 0) 3f else 5f)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.DownloadDone, contentDescription = null, tint = BaGreenSuccess, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "STORED SECURELY OFFLINE • BRITISH AIRWAYS WALLET",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaMutedSilver
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(BaNavyElevated)
                        .border(1.dp, BaSkyBlue.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .clickable {
                            Toast.makeText(context, "Pass Added to Google Wallet", Toast.LENGTH_SHORT).show()
                        }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Wallet, contentDescription = null, tint = BaSkyBlue, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ADD TO WALLET", style = MaterialTheme.typography.labelSmall, color = BaWarmWhite)
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(BaNavyElevated)
                        .border(1.dp, BaBorderNavy, RoundedCornerShape(8.dp))
                        .clickable {
                            Toast.makeText(context, "Boarding pass shared", Toast.LENGTH_SHORT).show()
                        }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.IosShare, contentDescription = null, tint = BaSilver, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("SHARE PASS", style = MaterialTheme.typography.labelSmall, color = BaSilver)
                    }
                }
            }
        }
    }
}

@Composable
private fun PassParam(
    title: String,
    value: String,
    isHighlighted: Boolean = false,
    isGold: Boolean = false
) {
    Column {
        Text(text = title, style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            color = when {
                isGold -> BaGold
                isHighlighted -> BaSkyBlue
                else -> BaWarmWhite
            }
        )
    }
}
