package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaDarkBackground
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

@Composable
fun AviosScreen(
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BaDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("avios_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        // Section 16 & 42: Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "BRITISH AIRWAYS EXECUTIVE CLUB",
                        style = MaterialTheme.typography.labelSmall,
                        color = BaGold
                    )
                    Text(
                        text = "AVIOS & TIER",
                        style = MaterialTheme.typography.headlineLarge,
                        color = BaWarmWhite
                    )
                }
                Box(
                    modifier = Modifier
                        .background(BaNavyElevated, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text("SYNTHETIC DATA", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                }
            }
        }

        // Executive Club Gold Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, BaGold)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("EXECUTIVE CLUB GOLD", style = MaterialTheme.typography.titleMedium, color = BaGold)
                        Text("BA 9482 1042", style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace), color = BaSilver)
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Text("AVAILABLE BALANCE", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                    Text(
                        text = "124,800",
                        style = MaterialTheme.typography.displayLarge.copy(fontFamily = FontFamily.Monospace),
                        color = BaWarmWhite
                    )
                    Text("AVIOS", style = MaterialTheme.typography.labelMedium, color = BaSkyBlue)

                    Spacer(modifier = Modifier.height(18.dp))

                    // Tier Progress
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TIER POINTS PROGRESS", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                        Text("1,340 / 1,500 TP", style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace), color = BaGold)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { 1340f / 1500f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = BaGold,
                        trackColor = BaNavyElevated
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("160 Tier Points required by 31 Dec 2026 to retain Gold tier.", style = MaterialTheme.typography.labelSmall, color = BaSilver)
                }
            }
        }

        // Tier Benefits Strip
        item {
            Text("EXECUTIVE CLUB GOLD PRIVILEGES", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavyCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaNavyLight.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    BenefitRow("First Wing access at Heathrow T5 with private security channel")
                    BenefitRow("Access to British Airways First Lounges and Concorde Room")
                    BenefitRow("Free seat selection from time of booking on all flights")
                    BenefitRow("Additional 32kg checked baggage allowance across all cabins")
                    BenefitRow("100% Avios bonus on all British Airways and oneworld flights")
                }
            }
        }

        // Recent Activity Statement (Section 16)
        item {
            Text("RECENT AVIOS ACTIVITY", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaBorderNavy)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    AviosActivityItem(
                        title = "London (LHR) → New York (JFK)",
                        date = "18 SEP 2026",
                        points = "+ 18,400",
                        isCredit = true,
                        category = "First Class Flight BA 017"
                    )
                    HorizontalDivider(color = BaNavyLight.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 10.dp))
                    AviosActivityItem(
                        title = "British Airways American Express",
                        date = "04 SEP 2026",
                        points = "+ 2,400",
                        isCredit = true,
                        category = "Partner Purchase Bonus"
                    )
                    HorizontalDivider(color = BaNavyLight.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 10.dp))
                    AviosActivityItem(
                        title = "Reward Flight: London → Paris CDG",
                        date = "22 AUG 2026",
                        points = "− 50,000",
                        isCredit = false,
                        category = "Club Europe Reward Booking"
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun BenefitRow(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Star, contentDescription = null, tint = BaGold, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = BaWarmWhite)
    }
}

@Composable
private fun AviosActivityItem(
    title: String,
    date: String,
    points: String,
    isCredit: Boolean,
    category: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(title, style = MaterialTheme.typography.bodyMedium, color = BaWarmWhite)
            Text("$category • $date", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        }
        Text(
            text = points,
            style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
            color = if (isCredit) BaGreenSuccess else BaSpeedmarqueRed
        )
    }
}
