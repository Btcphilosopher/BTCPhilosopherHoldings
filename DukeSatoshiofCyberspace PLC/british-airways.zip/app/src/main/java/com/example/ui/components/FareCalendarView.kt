package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CabinClass
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

data class DayFare(
    val dayOfMonth: String,
    val dayOfWeek: String,
    val dateFull: String,
    val price: Int,
    val isLowest: Boolean = false
)

@Composable
fun FareCalendarView(
    cabinClass: CabinClass = CabinClass.FIRST,
    selectedDate: String = "18 OCT",
    modifier: Modifier = Modifier,
    onDateSelected: (String, Int) -> Unit = { _, _ -> }
) {
    var activeDate by remember(selectedDate) { mutableStateOf(selectedDate) }

    // Multiplier based on cabin
    val cabinMultiplier = when (cabinClass) {
        CabinClass.FIRST -> 7.9f
        CabinClass.CLUB -> 3.1f
        CabinClass.WORLD_TRAVELLER_PLUS -> 1.6f
        CabinClass.WORLD_TRAVELLER -> 1.0f
    }

    val days = remember(cabinClass) {
        listOf(
            DayFare("16", "THU", "16 OCT", (640 * cabinMultiplier).toInt()),
            DayFare("17", "FRI", "17 OCT", (612 * cabinMultiplier).toInt()),
            DayFare("18", "SAT", "18 OCT", (610 * cabinMultiplier).toInt()),
            DayFare("19", "SUN", "19 OCT", (735 * cabinMultiplier).toInt()),
            DayFare("20", "MON", "20 OCT", (642 * cabinMultiplier).toInt()),
            DayFare("21", "TUE", "21 OCT", (590 * cabinMultiplier).toInt(), isLowest = true),
            DayFare("22", "WED", "22 OCT", (618 * cabinMultiplier).toInt()),
            DayFare("23", "THU", "23 OCT", (675 * cabinMultiplier).toInt())
        )
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(BaNavySurface)
            .border(1.dp, BaBorderNavy, RoundedCornerShape(12.dp))
            .padding(14.dp)
            .testTag("fare_calendar_view")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "FARE MATRIX • OCT 2026",
                    style = MaterialTheme.typography.labelMedium,
                    color = BaSkyBlue
                )
                Text(
                    text = "LOWEST FARES ACROSS DATES",
                    style = MaterialTheme.typography.titleMedium,
                    color = BaWarmWhite
                )
            }
            Text(
                text = "${cabinClass.displayName.uppercase()}",
                style = MaterialTheme.typography.labelSmall,
                color = if (cabinClass == CabinClass.FIRST) BaGold else BaSkyBlue
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(days) { day ->
                val isSelected = activeDate == day.dateFull
                Box(
                    modifier = Modifier
                        .width(76.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            when {
                                isSelected -> BaNavyElevated
                                day.isLowest -> BaNavyCard
                                else -> BaNavyCard
                            }
                        )
                        .border(
                            1.dp,
                            when {
                                isSelected -> if (cabinClass == CabinClass.FIRST) BaGold else BaSkyBlue
                                day.isLowest -> BaGreenSuccess.copy(alpha = 0.6f)
                                else -> BaBorderNavy
                            },
                            RoundedCornerShape(8.dp)
                        )
                        .clickable {
                            activeDate = day.dateFull
                            onDateSelected(day.dateFull, day.price)
                        }
                        .padding(vertical = 10.dp, horizontal = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = day.dayOfWeek,
                            style = MaterialTheme.typography.labelSmall,
                            color = BaMutedSilver
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = day.dayOfMonth,
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (isSelected) BaWarmWhite else BaSilver
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "£${day.price.toString().replace(Regex("(\\d)(?=(\\d{3})+$)"), "$1,")}",
                            style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace),
                            color = when {
                                day.isLowest -> BaGreenSuccess
                                cabinClass == CabinClass.FIRST -> BaGold
                                else -> BaWarmWhite
                            }
                        )
                        if (day.isLowest) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "LOWEST",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 7.sp),
                                color = BaGreenSuccess
                            )
                        }
                    }
                }
            }
        }
    }
}
