package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirlineSeatReclineExtra
import androidx.compose.material.icons.filled.AirplaneTicket
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ConnectingAirports
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.LocalAtm
import androidx.compose.material.icons.filled.Luggage
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.TripEntity
import com.example.model.CabinClass
import com.example.model.DisruptionState
import com.example.model.JourneyState
import com.example.ui.components.FlightDeckTelemetryView
import com.example.ui.components.JourneyStateController
import com.example.ui.components.VectorAirportMap
import com.example.ui.theme.BaAmberWarning
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaDarkBackground
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

@Composable
fun HomeScreen(
    trip: TripEntity?,
    journeyState: JourneyState,
    disruptionState: DisruptionState,
    onStateSelect: (JourneyState) -> Unit,
    onDisruptionToggle: (DisruptionState) -> Unit,
    onSelectDemo: (Int) -> Unit,
    onNavigateToTicket: () -> Unit,
    onNavigateToHeathrow: () -> Unit,
    onNavigateToLounge: () -> Unit,
    onNavigateToBaggage: () -> Unit,
    onNavigateToSeat: () -> Unit,
    onNavigateToManage: () -> Unit,
    onNavigateToDisruptionRebook: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentTrip = trip ?: return

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BaDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("home_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Space
        item { Spacer(modifier = Modifier.height(8.dp)) }

        // State Simulator Controller Strip
        item {
            JourneyStateController(
                currentState = journeyState,
                currentDisruption = disruptionState,
                onStateSelect = onStateSelect,
                onDisruptionToggle = onDisruptionToggle,
                onSelectDemo = onSelectDemo
            )
        }

        // Editorial British Airways Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(BaSpeedmarqueRed, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "BRITISH AIRWAYS",
                            style = MaterialTheme.typography.labelSmall,
                            color = BaSkyBlue
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Good morning, Tom.",
                        style = MaterialTheme.typography.headlineLarge,
                        color = BaWarmWhite
                    )
                }

                // Executive Club Gold Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(BaNavyElevated)
                        .border(1.dp, BaGold, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "EXECUTIVE CLUB",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp),
                            color = BaGold
                        )
                        Text(
                            text = "GOLD • 124,800 AVIOS",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = BaWarmWhite
                        )
                    }
                }
            }
        }

        // Disruption Alert Card (if triggered)
        if (disruptionState != DisruptionState.ON_TIME) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("disruption_alert_banner"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = BaNavyCard),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, BaAmberWarning)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = BaAmberWarning,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "YOUR FLIGHT STATUS HAS CHANGED",
                                style = MaterialTheme.typography.labelLarge,
                                color = BaAmberWarning
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = when (disruptionState) {
                                DisruptionState.DELAYED -> "${currentTrip.flightNumber} is delayed by 55 minutes due to Heathrow air traffic flow management. New departure: 08:35."
                                DisruptionState.GATE_CHANGED -> "Gate changed from A20 to Gate A24 (Terminal 5 North). Terminal wayfinding path recalculated."
                                DisruptionState.CONNECTION_AT_RISK -> "Inbound delay puts your connection in New York at risk. Pre-cleared alternative options are available."
                                else -> "Flight advisory in place. Please review options."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = BaSilver
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(BaAmberWarning)
                                    .clickable { onNavigateToDisruptionRebook() }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "VIEW REBOOKING OPTIONS",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = BaDarkBackground
                                )
                            }
                            if (disruptionState == DisruptionState.GATE_CHANGED) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(BaNavyElevated)
                                        .border(1.dp, BaSkyBlue, RoundedCornerShape(6.dp))
                                        .clickable { onNavigateToHeathrow() }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                    Text(
                                        text = "NAVIGATE TO GATE A24",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = BaSkyBlue
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Hero Flight Card (British aviation infrastructure centerpiece)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToTicket() }
                    .testTag("hero_journey_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaBorderNavy)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    // Top flight identity
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "YOUR NEXT JOURNEY",
                            style = MaterialTheme.typography.labelSmall,
                            color = BaMutedSilver
                        )
                        Text(
                            text = "${currentTrip.flightNumber} • ${currentTrip.flightDate}",
                            style = MaterialTheme.typography.labelMedium,
                            color = BaSkyBlue
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Route Architecture: LHR -> JFK
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "LONDON",
                                style = MaterialTheme.typography.titleLarge,
                                color = BaWarmWhite
                            )
                            Text(
                                text = "HEATHROW T5",
                                style = MaterialTheme.typography.headlineMedium,
                                color = BaSkyBlue
                            )
                            Text(
                                text = currentTrip.departureTime,
                                style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Monospace),
                                color = BaWarmWhite
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = currentTrip.duration,
                                style = MaterialTheme.typography.labelSmall,
                                color = BaMutedSilver
                            )
                            Icon(
                                imageVector = Icons.Default.Flight,
                                contentDescription = null,
                                tint = BaSpeedmarqueRed,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "DIRECT",
                                style = MaterialTheme.typography.labelSmall,
                                color = BaMutedSilver
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "NEW YORK",
                                style = MaterialTheme.typography.titleLarge,
                                color = BaWarmWhite
                            )
                            Text(
                                text = "JFK T7",
                                style = MaterialTheme.typography.headlineMedium,
                                color = BaSkyBlue
                            )
                            Text(
                                text = currentTrip.arrivalTime,
                                style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Monospace),
                                color = BaWarmWhite
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Dynamic Journey Stage Banner inside Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(BaNavyElevated)
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "STATUS: ${journeyState.label.uppercase()}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (journeyState == JourneyState.BOARDING) BaSpeedmarqueRed else BaGold
                                )
                                Text(
                                    text = journeyState.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = BaWarmWhite
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = null,
                                tint = BaSilver,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Airport Key Metrics Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricBlock(
                            label = "CABIN",
                            value = currentTrip.cabinName,
                            subtext = "Seat ${currentTrip.seat}",
                            isGold = currentTrip.cabinName == "FIRST"
                        )
                        MetricBlock(
                            label = "TERMINAL",
                            value = "T5",
                            subtext = "The First Wing"
                        )
                        MetricBlock(
                            label = "GATE",
                            value = currentTrip.gate,
                            subtext = if (disruptionState == DisruptionState.GATE_CHANGED) "Changed" else "14 min walk",
                            isAlert = disruptionState == DisruptionState.GATE_CHANGED
                        )
                        MetricBlock(
                            label = "BOARDING",
                            value = "07:10",
                            subtext = "Group ${currentTrip.boardingGroup}"
                        )
                    }
                }
            }
        }

        // Live Contextual Module based on journey stage
        when (journeyState) {
            JourneyState.DEPARTED, JourneyState.IN_FLIGHT -> {
                item {
                    FlightDeckTelemetryView(
                        flightNumber = currentTrip.flightNumber,
                        originCode = currentTrip.originCode,
                        destCode = currentTrip.destCode
                    )
                }
            }
            JourneyState.AIRPORT, JourneyState.SECURITY, JourneyState.GATE, JourneyState.BOARDING -> {
                item {
                    VectorAirportMap(
                        targetGate = currentTrip.gate,
                        isGateChanged = disruptionState == DisruptionState.GATE_CHANGED,
                        onGateClick = { onNavigateToHeathrow() }
                    )
                }
            }
            JourneyState.LOUNGE -> {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToLounge() },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = BaNavyCard),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BaGold)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("CONCORDE ROOM • HEATHROW T5", style = MaterialTheme.typography.labelSmall, color = BaGold)
                                Text("SIMULATED CAPACITY: QUIET ●●●○○", style = MaterialTheme.typography.labelSmall, color = BaGreenSuccess)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Welcome, Mr Loveitt. Your private dining booth and cabana are ready.", style = MaterialTheme.typography.bodyMedium, color = BaWarmWhite)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Tap to view lounge dining menu & private amenities →", style = MaterialTheme.typography.labelSmall, color = BaSkyBlue)
                        }
                    }
                }
            }
            JourneyState.BAGGAGE, JourneyState.ARRIVED -> {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToBaggage() },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = BaNavyCard),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BaSkyBlue)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("WELCOME TO NEW YORK JFK • BAGGAGE READY", style = MaterialTheme.typography.labelSmall, color = BaSkyBlue)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("2 checked bags delivered to Baggage Belt 8 (Terminal 7)", style = MaterialTheme.typography.titleMedium, color = BaWarmWhite)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Tags: BA123456 • BA123457 (Tracked) →", style = MaterialTheme.typography.labelSmall, color = BaGold)
                        }
                    }
                }
            }
            else -> {}
        }

        // Quick Travel Infrastructure Services
        item {
            Text(
                text = "TRAVEL DESK SERVICES",
                style = MaterialTheme.typography.labelSmall,
                color = BaMutedSilver
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickServiceCard(
                    title = "Boarding Pass",
                    subtitle = "Group 1 • Seat ${currentTrip.seat}",
                    icon = Icons.Default.AirplaneTicket,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToTicket
                )
                QuickServiceCard(
                    title = "Heathrow T5",
                    subtitle = "First Wing • Map",
                    icon = Icons.Default.Map,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToHeathrow
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickServiceCard(
                    title = "Concorde Room",
                    subtitle = "Lounge • Quiet",
                    icon = Icons.Default.MeetingRoom,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToLounge
                )
                QuickServiceCard(
                    title = "Baggage Tracker",
                    subtitle = "2 Bags • Tracked",
                    icon = Icons.Default.Luggage,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToBaggage
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickServiceCard(
                    title = "Seat & Cabin",
                    subtitle = "Suite ${currentTrip.seat} • 777",
                    icon = Icons.Default.AirlineSeatReclineExtra,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToSeat
                )
                QuickServiceCard(
                    title = "Manage Booking",
                    subtitle = "Meals, Upgrades",
                    icon = Icons.Default.Security,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToManage
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun MetricBlock(
    label: String,
    value: String,
    subtext: String,
    isGold: Boolean = false,
    isAlert: Boolean = false
) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            color = when {
                isAlert -> BaAmberWarning
                isGold -> BaGold
                else -> BaWarmWhite
            }
        )
        Text(text = subtext, style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = BaSilver)
    }
}

@Composable
private fun QuickServiceCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(BaNavyCard)
            .border(1.dp, BaNavyLight.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(14.dp)
    ) {
        Column {
            Icon(imageVector = icon, contentDescription = title, tint = BaSkyBlue, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = title, style = MaterialTheme.typography.titleMedium, color = BaWarmWhite)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        }
    }
}
