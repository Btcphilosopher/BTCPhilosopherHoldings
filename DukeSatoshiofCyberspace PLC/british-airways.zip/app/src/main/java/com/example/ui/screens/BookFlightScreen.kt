package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TripEntity
import com.example.model.CabinClass
import com.example.ui.components.AircraftSeatMapView
import com.example.ui.components.FareCalendarView
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaDarkBackground
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

@Composable
fun BookFlightScreen(
    onBookingConfirmed: (TripEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var origin by remember { mutableStateOf("London (LHR)") }
    var destination by remember { mutableStateOf("New York (JFK)") }
    var selectedDate by remember { mutableStateOf("18 OCT") }
    var selectedCabin by remember { mutableStateOf(CabinClass.FIRST) }
    var adultCount by remember { mutableStateOf(1) }
    var childCount by remember { mutableStateOf(0) }
    var infantCount by remember { mutableStateOf(0) }
    var selectedSeat by remember { mutableStateOf("1A") }

    var step by remember { mutableStateOf(1) } // 1: Search & Fares, 2: Select Flight, 3: Seat, 4: Confirmed Ticket
    var bookedTripEntity by remember { mutableStateOf<TripEntity?>(null) }

    val destinations = listOf("New York (JFK)", "Tokyo (HND)", "Singapore (SIN)", "Los Angeles (LAX)", "Dubai (DXB)", "Cape Town (CPT)")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BaDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("book_flight_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        // Section 8: Header
        item {
            Column {
                Text(
                    text = "BRITISH AIRWAYS • FLIGHT RESERVATION",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaSkyBlue
                )
                Text(
                    text = "WHERE NEXT?",
                    style = MaterialTheme.typography.displayMedium,
                    color = BaWarmWhite
                )
                Text(
                    text = "Search scheduled British Airways flights from London Heathrow.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = BaSilver
                )
            }
        }

        if (step == 1) {
            // Origin & Destination Selector
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = BaNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BaBorderNavy)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("FROM", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                                Text(origin, style = MaterialTheme.typography.titleLarge, color = BaWarmWhite)
                            }
                            Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = BaSkyBlue, modifier = Modifier.size(24.dp))
                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                Text("TO", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                                Text(destination, style = MaterialTheme.typography.titleLarge, color = BaGold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Quick Destination selector chips
                        Text("POPULAR DESTINATIONS", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(destinations) { dest ->
                                val isSelected = destination == dest
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) BaNavyElevated else BaNavyCard)
                                        .border(1.dp, if (isSelected) BaGold else BaBorderNavy, RoundedCornerShape(6.dp))
                                        .clickable { destination = dest }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = dest,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isSelected) BaGold else BaSilver
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Passenger Selection (with Family Mode)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = BaNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BaBorderNavy)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("PASSENGERS & FAMILY ASSISTANCE", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Adults (16+)", style = MaterialTheme.typography.bodyMedium, color = BaWarmWhite)
                                Text("Standard passenger fare", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                            }
                            PassengerCounter(count = adultCount, onDec = { if (adultCount > 1) adultCount-- }, onInc = { adultCount++ })
                        }

                        HorizontalDivider(color = BaNavyLight.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Children (2–15)", style = MaterialTheme.typography.bodyMedium, color = BaWarmWhite)
                                Text("Adjacent family seating prioritised", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                            }
                            PassengerCounter(count = childCount, onDec = { if (childCount > 0) childCount-- }, onInc = { childCount++ })
                        }
                    }
                }
            }

            // Cabin Class Selector & Comparison (Section 11)
            item {
                Text("CABIN SELECTION", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(CabinClass.values()) { cabin ->
                        val isSelected = selectedCabin == cabin
                        Box(
                            modifier = Modifier
                                .width(160.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) BaNavyElevated else BaNavyCard)
                                .border(
                                    1.dp,
                                    if (isSelected) (if (cabin == CabinClass.FIRST) BaGold else BaSkyBlue) else BaBorderNavy,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { selectedCabin = cabin }
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(
                                    text = cabin.displayName.uppercase(),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (cabin == CabinClass.FIRST) BaGold else BaWarmWhite
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = cabin.description,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BaSilver,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }
            }

            // Fare Calendar Component (Section 10)
            item {
                FareCalendarView(
                    cabinClass = selectedCabin,
                    selectedDate = selectedDate,
                    onDateSelected = { date, _ -> selectedDate = date }
                )
            }

            // Search Flights Button
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(BaSpeedmarqueRed)
                        .clickable { step = 2 }
                        .padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("SEARCH FLIGHTS", style = MaterialTheme.typography.labelLarge, color = BaWarmWhite)
                }
            }
        } else if (step == 2) {
            // Flight Search Results (Section 9)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("FLIGHT RESULTS • $selectedDate", style = MaterialTheme.typography.labelSmall, color = BaSkyBlue)
                    Text("BACK TO SEARCH", style = MaterialTheme.typography.labelSmall, color = BaSilver, modifier = Modifier.clickable { step = 1 })
                }
            }

            item {
                AviationFlightResultCard(
                    flightNo = "BA 017",
                    depTime = "07:45",
                    arrTime = "11:05",
                    origin = "LHR T5",
                    dest = "JFK T7",
                    duration = "7h 20m",
                    aircraft = "Boeing 777-300ER",
                    cabin = selectedCabin,
                    price = when (selectedCabin) {
                        CabinClass.FIRST -> 4820
                        CabinClass.CLUB -> 1920
                        CabinClass.WORLD_TRAVELLER_PLUS -> 980
                        CabinClass.WORLD_TRAVELLER -> 610
                    },
                    onSelect = {
                        step = 3
                    }
                )
            }

            item {
                AviationFlightResultCard(
                    flightNo = "BA 117",
                    depTime = "11:20",
                    arrTime = "14:40",
                    origin = "LHR T5",
                    dest = "JFK T7",
                    duration = "7h 20m",
                    aircraft = "Airbus A350-1000",
                    cabin = selectedCabin,
                    price = when (selectedCabin) {
                        CabinClass.FIRST -> 5140
                        CabinClass.CLUB -> 2050
                        CabinClass.WORLD_TRAVELLER_PLUS -> 1020
                        CabinClass.WORLD_TRAVELLER -> 645
                    },
                    onSelect = {
                        step = 3
                    }
                )
            }
        } else if (step == 3) {
            // Seat Selection (Section 13 & 14)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("SELECT SEAT • BA 017", style = MaterialTheme.typography.labelSmall, color = BaSkyBlue)
                    Text("BACK TO FLIGHTS", style = MaterialTheme.typography.labelSmall, color = BaSilver, modifier = Modifier.clickable { step = 2 })
                }
            }

            item {
                AircraftSeatMapView(
                    currentSeat = selectedSeat,
                    currentCabin = selectedCabin,
                    onSeatSelected = { seat, cabin ->
                        selectedSeat = seat
                        selectedCabin = cabin
                    }
                )
            }

            // Confirm & Pay CTA (Section 53)
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(BaSpeedmarqueRed)
                        .clickable {
                            val newTrip = TripEntity(
                                id = "trip-new-${System.currentTimeMillis()}",
                                flightNumber = "BA 017",
                                originCode = "LHR",
                                originName = "London Heathrow",
                                originTerminal = "Terminal 5",
                                destCode = "JFK",
                                destName = "New York JFK",
                                destTerminal = "Terminal 7",
                                departureTime = "07:45",
                                arrivalTime = "11:05",
                                duration = "7h 20m",
                                flightDate = selectedDate,
                                aircraft = "Boeing 777-300ER",
                                gate = "A20",
                                seat = selectedSeat,
                                cabinName = selectedCabin.name,
                                bookingRef = "BA-${(1000..9999).random()}K",
                                boardingGroup = if (selectedCabin == CabinClass.FIRST) 1 else 2,
                                journeyStateName = "BOOKED",
                                disruptionStateName = "ON_TIME"
                            )
                            bookedTripEntity = newTrip
                            onBookingConfirmed(newTrip)
                            step = 4
                        }
                        .padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("CONFIRM BOOKING & CONSTRUCT TICKET", style = MaterialTheme.typography.labelLarge, color = BaWarmWhite)
                }
            }
        } else if (step == 4) {
            // Section 53: BOOKING ANIMATION & CONFIRMATION
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = BaNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, BaGreenSuccess)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BaGreenSuccess, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("PAYMENT CONFIRMED", style = MaterialTheme.typography.labelSmall, color = BaGreenSuccess)
                        Text("BOOKING CONFIRMED", style = MaterialTheme.typography.headlineLarge, color = BaWarmWhite)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Reference: ${bookedTripEntity?.bookingRef ?: "BA-9482K"}",
                            style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
                            color = BaGold
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "BA 017 • LONDON HEATHROW → NEW YORK JFK • $selectedDate",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BaSilver
                        )
                        Text(
                            text = "Seat $selectedSeat (${selectedCabin.displayName})",
                            style = MaterialTheme.typography.labelLarge,
                            color = BaSkyBlue
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(BaNavyElevated)
                                .border(1.dp, BaSkyBlue, RoundedCornerShape(8.dp))
                                .clickable { step = 1 }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("BOOK ANOTHER FLIGHT", style = MaterialTheme.typography.labelMedium, color = BaWarmWhite)
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun AviationFlightResultCard(
    flightNo: String,
    depTime: String,
    arrTime: String,
    origin: String,
    dest: String,
    duration: String,
    aircraft: String,
    cabin: CabinClass,
    price: Int,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = BaNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, BaBorderNavy)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(flightNo, style = MaterialTheme.typography.titleMedium, color = BaSkyBlue)
                Text(aircraft, style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(depTime, style = MaterialTheme.typography.displayMedium, color = BaWarmWhite)
                    Text(origin, style = MaterialTheme.typography.labelMedium, color = BaSilver)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(duration, style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                    Icon(Icons.Default.Flight, contentDescription = null, tint = BaSpeedmarqueRed, modifier = Modifier.size(18.dp))
                    Text("DIRECT", style = MaterialTheme.typography.labelSmall, color = BaGreenSuccess)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(arrTime, style = MaterialTheme.typography.displayMedium, color = BaWarmWhite)
                    Text(dest, style = MaterialTheme.typography.labelMedium, color = BaSilver)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("${cabin.displayName.uppercase()} FARE", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                    Text(
                        "£${price.toString().replace(Regex("(\\d)(?=(\\d{3})+$)"), "$1,")}",
                        style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Monospace),
                        color = if (cabin == CabinClass.FIRST) BaGold else BaWarmWhite
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(BaSpeedmarqueRed)
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text("SELECT FLIGHT", style = MaterialTheme.typography.labelSmall, color = BaWarmWhite)
                }
            }
        }
    }
}

@Composable
private fun PassengerCounter(count: Int, onDec: () -> Unit, onInc: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onDec, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = BaSilver)
        }
        Text(
            text = "$count",
            style = MaterialTheme.typography.titleMedium,
            color = BaWarmWhite,
            modifier = Modifier.padding(horizontal = 8.dp)
        )
        IconButton(onClick = onInc, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Add, contentDescription = "Increase", tint = BaSkyBlue)
        }
    }
}
