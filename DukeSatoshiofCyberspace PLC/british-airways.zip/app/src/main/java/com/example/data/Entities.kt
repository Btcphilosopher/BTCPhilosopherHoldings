package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trips")
data class TripEntity(
    @PrimaryKey val id: String,
    val flightNumber: String,
    val originCode: String,
    val originName: String,
    val originTerminal: String,
    val destCode: String,
    val destName: String,
    val destTerminal: String,
    val departureTime: String,
    val arrivalTime: String,
    val duration: String,
    val flightDate: String,
    val aircraft: String,
    val gate: String,
    val seat: String,
    val cabinName: String,
    val bookingRef: String,
    val boardingGroup: Int,
    val journeyStateName: String,
    val disruptionStateName: String,
    val isConnecting: Boolean = false,
    val connFlightNumber: String = "",
    val connDest: String = "",
    val connGate: String = "",
    val isFlagshipDemo: Boolean = false
)

@Entity(tableName = "baggage")
data class BaggageEntity(
    @PrimaryKey val tagNumber: String,
    val tripId: String,
    val passengerName: String,
    val weightKg: Int,
    val status: String,
    val location: String,
    val beltNumber: String,
    val stagesCompleted: Int
)

@Entity(tableName = "profile")
data class ProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String,
    val tier: String,
    val aviosBalance: Int,
    val tierPoints: Int,
    val membershipNumber: String,
    val passportMasked: String,
    val nationality: String,
    val mealPreference: String,
    val assistanceReq: String
)
