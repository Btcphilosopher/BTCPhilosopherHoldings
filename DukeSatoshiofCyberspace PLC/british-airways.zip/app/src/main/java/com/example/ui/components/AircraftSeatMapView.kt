package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirlineSeatReclineExtra
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoorFront
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CabinClass
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

enum class SeatMapMode { SEAT_MAP, CABIN_SUITE, AIRCRAFT_TWIN }

data class SeatInfo(
    val code: String,
    val row: Int,
    val col: String,
    val cabin: CabinClass,
    val isOccupied: Boolean = false,
    val isBassinet: Boolean = false,
    val isExitRow: Boolean = false,
    val pitchInches: Int = 79,
    val widthInches: Int = 24
)

@Composable
fun AircraftSeatMapView(
    currentSeat: String = "3A",
    currentCabin: CabinClass = CabinClass.FIRST,
    aircraftName: String = "Boeing 777-300ER",
    modifier: Modifier = Modifier,
    onSeatSelected: (String, CabinClass) -> Unit = { _, _ -> }
) {
    var selectedSeat by remember(currentSeat) { mutableStateOf(currentSeat) }
    var selectedMode by remember { mutableStateOf(SeatMapMode.SEAT_MAP) }
    var selectedAircraft by remember { mutableStateOf(aircraftName) }

    val aircraftOptions = listOf("Boeing 777-300ER", "Airbus A350-1000", "Boeing 787-10", "Airbus A380")

    val sampleSeats = remember {
        listOf(
            SeatInfo("1A", 1, "A", CabinClass.FIRST, isOccupied = false),
            SeatInfo("1K", 1, "K", CabinClass.FIRST, isOccupied = true),
            SeatInfo("2A", 2, "A", CabinClass.FIRST, isOccupied = false),
            SeatInfo("2K", 2, "K", CabinClass.FIRST, isOccupied = false),
            SeatInfo("3A", 3, "A", CabinClass.FIRST, isOccupied = false), // Current passenger
            SeatInfo("3K", 3, "K", CabinClass.FIRST, isOccupied = false),
            SeatInfo("4A", 4, "A", CabinClass.CLUB, isOccupied = false),
            SeatInfo("4E", 4, "E", CabinClass.CLUB, isOccupied = true),
            SeatInfo("4F", 4, "F", CabinClass.CLUB, isOccupied = false),
            SeatInfo("4K", 4, "K", CabinClass.CLUB, isOccupied = false),
            SeatInfo("5A", 5, "A", CabinClass.CLUB, isOccupied = false),
            SeatInfo("5E", 5, "E", CabinClass.CLUB, isOccupied = false),
            SeatInfo("5F", 5, "F", CabinClass.CLUB, isOccupied = true),
            SeatInfo("5K", 5, "K", CabinClass.CLUB, isOccupied = false),
            SeatInfo("12A", 12, "A", CabinClass.WORLD_TRAVELLER_PLUS, isOccupied = false, isExitRow = true, pitchInches = 38, widthInches = 18),
            SeatInfo("12B", 12, "B", CabinClass.WORLD_TRAVELLER_PLUS, isOccupied = false, isExitRow = true, pitchInches = 38, widthInches = 18),
            SeatInfo("12J", 12, "J", CabinClass.WORLD_TRAVELLER_PLUS, isOccupied = true, isExitRow = true, pitchInches = 38, widthInches = 18),
            SeatInfo("12K", 12, "K", CabinClass.WORLD_TRAVELLER_PLUS, isOccupied = false, isExitRow = true, pitchInches = 38, widthInches = 18),
            SeatInfo("24A", 24, "A", CabinClass.WORLD_TRAVELLER, isOccupied = false, pitchInches = 31, widthInches = 17),
            SeatInfo("24B", 24, "B", CabinClass.WORLD_TRAVELLER, isOccupied = true, pitchInches = 31, widthInches = 17),
            SeatInfo("24C", 24, "C", CabinClass.WORLD_TRAVELLER, isOccupied = false, pitchInches = 31, widthInches = 17),
            SeatInfo("24H", 24, "H", CabinClass.WORLD_TRAVELLER, isOccupied = false, pitchInches = 31, widthInches = 17),
            SeatInfo("24J", 24, "J", CabinClass.WORLD_TRAVELLER, isOccupied = false, pitchInches = 31, widthInches = 17),
            SeatInfo("24K", 24, "K", CabinClass.WORLD_TRAVELLER, isOccupied = true, pitchInches = 31, widthInches = 17)
        )
    }

    val currentSeatDetail = sampleSeats.find { it.code == selectedSeat } ?: sampleSeats.first()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(BaNavySurface, RoundedCornerShape(12.dp))
            .border(1.dp, BaBorderNavy, RoundedCornerShape(12.dp))
            .padding(16.dp)
            .testTag("aircraft_seat_map_view")
    ) {
        // Mode Selector: SEAT MAP / CABIN / AIRCRAFT TWIN
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BaNavyCard, RoundedCornerShape(8.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            SeatMapMode.values().forEach { mode ->
                val isSelected = selectedMode == mode
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) BaNavyElevated else Color.Transparent)
                        .border(
                            1.dp,
                            if (isSelected) BaSkyBlue.copy(alpha = 0.5f) else Color.Transparent,
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { selectedMode = mode }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when (mode) {
                            SeatMapMode.SEAT_MAP -> "SEAT MAP"
                            SeatMapMode.CABIN_SUITE -> "CABIN SUITE"
                            SeatMapMode.AIRCRAFT_TWIN -> "DIGITAL TWIN"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) BaSkyBlue else BaMutedSilver
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Aircraft Model Chip Selector
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(aircraftOptions) { ac ->
                val isSelected = selectedAircraft == ac
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) BaNavyElevated else BaNavyCard)
                        .border(
                            1.dp,
                            if (isSelected) BaGold else BaBorderNavy,
                            RoundedCornerShape(16.dp)
                        )
                        .clickable { selectedAircraft = ac }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = ac,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) BaGold else BaSilver
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        when (selectedMode) {
            SeatMapMode.SEAT_MAP -> {
                // Interactive Aircraft Cross Section Seat Map
                Text(
                    text = "AIRCRAFT NOSE • FIRST CABIN SUITES",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaMutedSilver,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Nose cone curve indicator
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val path = Path().apply {
                            moveTo(size.width * 0.15f, size.height)
                            quadraticTo(size.width * 0.5f, 0f, size.width * 0.85f, size.height)
                        }
                        drawPath(path, color = BaNavyLight, style = Stroke(width = 2f))
                    }
                }

                // Grid of Seats: First Class (1-3)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BaNavyCard, RoundedCornerShape(10.dp))
                        .border(1.dp, BaNavyLight.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "FIRST CLASS SUITES (1 - 2 - 1 LAYOUT)",
                        style = MaterialTheme.typography.labelSmall,
                        color = BaGold
                    )

                    listOf(1, 2, 3).forEach { rowNum ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val leftSeat = sampleSeats.find { it.row == rowNum && it.col == "A" }
                            val rightSeat = sampleSeats.find { it.row == rowNum && it.col == "K" }

                            if (leftSeat != null) {
                                SeatButton(
                                    seat = leftSeat,
                                    isSelected = selectedSeat == leftSeat.code,
                                    onClick = {
                                        if (!leftSeat.isOccupied) {
                                            selectedSeat = leftSeat.code
                                            onSeatSelected(leftSeat.code, leftSeat.cabin)
                                        }
                                    }
                                )
                            }

                            // Center Galley / Aisle indicator
                            Text(
                                text = "AISLE",
                                style = MaterialTheme.typography.labelSmall,
                                color = BaMutedSilver.copy(alpha = 0.6f)
                            )

                            if (rightSeat != null) {
                                SeatButton(
                                    seat = rightSeat,
                                    isSelected = selectedSeat == rightSeat.code,
                                    onClick = {
                                        if (!rightSeat.isOccupied) {
                                            selectedSeat = rightSeat.code
                                            onSeatSelected(rightSeat.code, rightSeat.cabin)
                                        }
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "GALLEY & ARCHITECTURAL PRIVACY SCREEN",
                        style = MaterialTheme.typography.labelSmall,
                        color = BaMutedSilver,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )

                    // Club World row sample
                    Text(
                        text = "CLUB WORLD SUITES (WITH DOORS)",
                        style = MaterialTheme.typography.labelSmall,
                        color = BaSkyBlue
                    )

                    listOf(4, 5).forEach { rowNum ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val seatA = sampleSeats.find { it.row == rowNum && it.col == "A" }
                            val seatE = sampleSeats.find { it.row == rowNum && it.col == "E" }
                            val seatF = sampleSeats.find { it.row == rowNum && it.col == "F" }
                            val seatK = sampleSeats.find { it.row == rowNum && it.col == "K" }

                            seatA?.let {
                                SeatButton(it, selectedSeat == it.code) {
                                    if (!it.isOccupied) {
                                        selectedSeat = it.code
                                        onSeatSelected(it.code, it.cabin)
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                seatE?.let {
                                    SeatButton(it, selectedSeat == it.code) {
                                        if (!it.isOccupied) {
                                            selectedSeat = it.code
                                            onSeatSelected(it.code, it.cabin)
                                        }
                                    }
                                }
                                seatF?.let {
                                    SeatButton(it, selectedSeat == it.code) {
                                        if (!it.isOccupied) {
                                            selectedSeat = it.code
                                            onSeatSelected(it.code, it.cabin)
                                        }
                                    }
                                }
                            }
                            seatK?.let {
                                SeatButton(it, selectedSeat == it.code) {
                                    if (!it.isOccupied) {
                                        selectedSeat = it.code
                                        onSeatSelected(it.code, it.cabin)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            SeatMapMode.CABIN_SUITE -> {
                // Cabin Suite Detail specification
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BaNavyCard, RoundedCornerShape(10.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "SUITE SPECIFICATION: ${currentSeatDetail.code} (${currentSeatDetail.cabin.displayName})",
                        style = MaterialTheme.typography.titleMedium,
                        color = BaGold
                    )
                    Text(
                        text = "Handcrafted British leather, bespoke ambient lighting, and sliding acoustic privacy door.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BaSilver
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        FeatureBadge(icon = Icons.Default.AirlineSeatReclineExtra, title = "79\" Flat Bed", desc = "200 cm length")
                        FeatureBadge(icon = Icons.Default.DoorFront, title = "Privacy Door", desc = "Full acoustic closure")
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        FeatureBadge(icon = Icons.Default.Tv, title = "24\" 4K Screen", desc = "Noise-cancelling audio")
                        FeatureBadge(icon = Icons.Default.Power, title = "Fast USB-C & AC", desc = "60W in-seat charging")
                    }
                }
            }

            SeatMapMode.AIRCRAFT_TWIN -> {
                // Digital Twin overview
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BaNavyCard, RoundedCornerShape(10.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "DIGITAL TWIN: $selectedAircraft",
                        style = MaterialTheme.typography.titleMedium,
                        color = BaSkyBlue
                    )
                    Text(
                        text = "Simulated airframe metrics, Rolls-Royce Trent engines, HEPA filtration at 99.97% efficiency.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BaSilver
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("CABIN ALTITUDE", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                            Text("6,000 FT (Optimized)", style = MaterialTheme.typography.labelLarge, color = BaWarmWhite)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("WI-FI CONNECTIVITY", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                            Text(".air High-Speed Ka-Band", style = MaterialTheme.typography.labelLarge, color = BaGreenSuccess)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Selected Seat Confirmation Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BaNavyElevated, RoundedCornerShape(8.dp))
                .border(1.dp, BaNavyLight, RoundedCornerShape(8.dp))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "CURRENT SEAT ASSIGNMENT", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                Text(
                    text = "SEAT $selectedSeat • ${currentSeatDetail.cabin.displayName.uppercase()}",
                    style = MaterialTheme.typography.titleMedium,
                    color = if (currentSeatDetail.cabin == CabinClass.FIRST) BaGold else BaSkyBlue
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(BaSpeedmarqueRed)
                    .clickable { onSeatSelected(selectedSeat, currentSeatDetail.cabin) }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "CONFIRM SEAT",
                    style = MaterialTheme.typography.labelMedium,
                    color = BaWarmWhite
                )
            }
        }
    }
}

@Composable
private fun SeatButton(
    seat: SeatInfo,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val bgColor = when {
        isSelected -> BaSpeedmarqueRed
        seat.isOccupied -> BaNavySurface.copy(alpha = 0.4f)
        seat.cabin == CabinClass.FIRST -> BaGold.copy(alpha = 0.25f)
        seat.cabin == CabinClass.CLUB -> BaSkyBlue.copy(alpha = 0.2f)
        else -> BaNavyElevated
    }

    val borderColor = when {
        isSelected -> BaWarmWhite
        seat.isOccupied -> Color.Transparent
        seat.cabin == CabinClass.FIRST -> BaGold
        seat.cabin == CabinClass.CLUB -> BaSkyBlue
        else -> BaBorderNavy
    }

    Box(
        modifier = Modifier
            .size(width = 54.dp, height = 44.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .clickable(enabled = !seat.isOccupied, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = seat.code,
                style = MaterialTheme.typography.labelMedium,
                color = when {
                    isSelected -> BaWarmWhite
                    seat.isOccupied -> BaMutedSilver.copy(alpha = 0.3f)
                    seat.cabin == CabinClass.FIRST -> BaGold
                    else -> BaWarmWhite
                }
            )
            if (seat.isOccupied) {
                Text("OCCUPIED", style = MaterialTheme.typography.labelSmall.copy(fontSize = 7.sp), color = BaMutedSilver.copy(alpha = 0.4f))
            } else if (isSelected) {
                Text("SELECTED", style = MaterialTheme.typography.labelSmall.copy(fontSize = 7.sp), color = BaWarmWhite)
            }
        }
    }
}

@Composable
private fun FeatureBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Icon(imageVector = icon, contentDescription = title, tint = BaGold, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(text = title, style = MaterialTheme.typography.labelMedium, color = BaWarmWhite)
            Text(text = desc, style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        }
    }
}
