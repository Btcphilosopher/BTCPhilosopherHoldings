package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BaAmberWarning
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

@Composable
fun VectorAirportMap(
    targetGate: String = "A20",
    isGateChanged: Boolean = false,
    modifier: Modifier = Modifier,
    onGateClick: (String) -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulsePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulsePhase"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(BaNavySurface, RoundedCornerShape(12.dp))
            .border(1.dp, BaBorderNavy, RoundedCornerShape(12.dp))
            .padding(16.dp)
            .testTag("vector_airport_map")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "HEATHROW TERMINAL 5",
                    style = MaterialTheme.typography.labelMedium,
                    color = BaSkyBlue
                )
                Text(
                    text = if (isGateChanged) "WAYFINDING: ROUTE RECALCULATED" else "WAYFINDING: ACTIVE ROUTE",
                    style = MaterialTheme.typography.titleMedium,
                    color = if (isGateChanged) BaAmberWarning else BaWarmWhite
                )
            }
            Box(
                modifier = Modifier
                    .background(
                        if (isGateChanged) BaAmberWarning.copy(alpha = 0.2f) else BaNavyElevated,
                        RoundedCornerShape(6.dp)
                    )
                    .border(
                        1.dp,
                        if (isGateChanged) BaAmberWarning else BaSkyBlue.copy(alpha = 0.4f),
                        RoundedCornerShape(6.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if (isGateChanged) "GATE $targetGate • 8 MIN" else "GATE $targetGate • 14 MIN",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isGateChanged) BaAmberWarning else BaSkyBlue
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Vector Architectural Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .background(BaNavyCard, RoundedCornerShape(8.dp))
                .border(1.dp, BaNavyLight.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Draw Grid Lines (British architectural blueprint)
                val gridSpacing = 32.dp.toPx()
                var gx = 0f
                while (gx < w) {
                    drawLine(
                        color = BaBorderNavy.copy(alpha = 0.25f),
                        start = Offset(gx, 0f),
                        end = Offset(gx, h),
                        strokeWidth = 1f
                    )
                    gx += gridSpacing
                }
                var gy = 0f
                while (gy < h) {
                    drawLine(
                        color = BaBorderNavy.copy(alpha = 0.25f),
                        start = Offset(0f, gy),
                        end = Offset(w, gy),
                        strokeWidth = 1f
                    )
                    gy += gridSpacing
                }

                // T5A Concourse (Main building)
                val t5aRectLeft = w * 0.08f
                val t5aRectTop = h * 0.15f
                val t5aRectRight = w * 0.65f
                val t5aRectBottom = h * 0.85f

                drawRect(
                    color = BaNavySurface,
                    topLeft = Offset(t5aRectLeft, t5aRectTop),
                    size = androidx.compose.ui.geometry.Size(
                        t5aRectRight - t5aRectLeft,
                        t5aRectBottom - t5aRectTop
                    )
                )
                drawRect(
                    color = BaBorderNavy,
                    topLeft = Offset(t5aRectLeft, t5aRectTop),
                    size = androidx.compose.ui.geometry.Size(
                        t5aRectRight - t5aRectLeft,
                        t5aRectBottom - t5aRectTop
                    ),
                    style = Stroke(width = 1.5f)
                )

                // Transit Shuttle Track to T5B / T5C
                val transitTrackX = w * 0.72f
                drawLine(
                    color = BaMutedSilver.copy(alpha = 0.5f),
                    start = Offset(transitTrackX, h * 0.15f),
                    end = Offset(transitTrackX, h * 0.85f),
                    strokeWidth = 3f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                )

                // T5B Satellite outline
                val t5bLeft = w * 0.80f
                drawRect(
                    color = BaNavySurface.copy(alpha = 0.6f),
                    topLeft = Offset(t5bLeft, h * 0.25f),
                    size = androidx.compose.ui.geometry.Size(w * 0.14f, h * 0.50f)
                )
                drawRect(
                    color = BaBorderNavy.copy(alpha = 0.6f),
                    topLeft = Offset(t5bLeft, h * 0.25f),
                    size = androidx.compose.ui.geometry.Size(w * 0.14f, h * 0.50f),
                    style = Stroke(width = 1f)
                )

                // Security & First Wing nodes
                val firstWingX = t5aRectLeft + 30f
                val firstWingY = t5aRectTop + 40f
                drawCircle(color = BaGold, radius = 6f, center = Offset(firstWingX, firstWingY))

                val securityX = t5aRectLeft + 80f
                val securityY = t5aRectTop + 60f
                drawCircle(color = BaGreenSuccess, radius = 5f, center = Offset(securityX, securityY))

                // Concorde Room Lounge
                val concordeX = t5aRectLeft + 130f
                val concordeY = t5aRectTop + 50f
                drawCircle(color = BaGold, radius = 6f, center = Offset(concordeX, concordeY))

                // Gate Locations
                val gateA20X = t5aRectRight - 40f
                val gateA20Y = t5aRectBottom - 35f

                val gateA24X = t5aRectRight - 40f
                val gateA24Y = t5aRectTop + 45f

                // Active Route Path
                val activeTargetX = if (isGateChanged) gateA24X else gateA20X
                val activeTargetY = if (isGateChanged) gateA24Y else gateA20Y

                // Draw route line
                val midWaypointX = t5aRectLeft + 160f
                val midWaypointY = (securityY + activeTargetY) / 2f

                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(securityX, securityY)
                    lineTo(midWaypointX, securityY)
                    lineTo(midWaypointX, activeTargetY)
                    lineTo(activeTargetX, activeTargetY)
                }

                // Background glow route
                drawPath(
                    path = path,
                    color = if (isGateChanged) BaAmberWarning.copy(alpha = 0.35f) else BaSkyBlue.copy(alpha = 0.35f),
                    style = Stroke(width = 6f, cap = StrokeCap.Round)
                )

                // Dashed animated route
                val dashOffset = pulsePhase * 40f
                drawPath(
                    path = path,
                    color = if (isGateChanged) BaAmberWarning else BaSkyBlue,
                    style = Stroke(
                        width = 2.5f,
                        cap = StrokeCap.Round,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 10f), -dashOffset)
                    )
                )

                // Current passenger position
                val currentPaxX = securityX + (midWaypointX - securityX) * (pulsePhase * 0.5f)
                drawCircle(
                    color = Color.White,
                    radius = 5f,
                    center = Offset(currentPaxX, securityY)
                )
                drawCircle(
                    color = BaSkyBlue.copy(alpha = 1f - pulsePhase),
                    radius = 8f + pulsePhase * 14f,
                    center = Offset(currentPaxX, securityY),
                    style = Stroke(width = 2f)
                )

                // Target Gate marker
                drawCircle(
                    color = if (isGateChanged) BaAmberWarning else BaSpeedmarqueRed,
                    radius = 8f,
                    center = Offset(activeTargetX, activeTargetY)
                )
                drawCircle(
                    color = (if (isGateChanged) BaAmberWarning else BaSpeedmarqueRed).copy(alpha = 1f - pulsePhase),
                    radius = 10f + pulsePhase * 16f,
                    center = Offset(activeTargetX, activeTargetY),
                    style = Stroke(width = 2f)
                )
            }

            // Overlay key points labels
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 22.dp, top = 14.dp)
            ) {
                Text("FIRST WING", style = MaterialTheme.typography.labelSmall, color = BaGold)
                Text("FAST TRACK", style = MaterialTheme.typography.labelSmall, color = BaGreenSuccess)
                Text("CONCORDE ROOM", style = MaterialTheme.typography.labelSmall, color = BaWarmWhite)
            }

            Column(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 16.dp, bottom = 14.dp)
            ) {
                Text(
                    text = "TARGET: GATE $targetGate",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (isGateChanged) BaAmberWarning else BaSpeedmarqueRed
                )
                Text(
                    text = if (isGateChanged) "RECALCULATED VIA NORTH CONCOURSE" else "VIA CENTRAL ESPLANADE",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaMutedSilver
                )
            }

            // Transit train indicator
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 56.dp)
            ) {
                Text("TTS SHUTTLE", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                Text("T5B / T5C", style = MaterialTheme.typography.labelSmall, color = BaSilver)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Wayfinding Directions card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BaNavyElevated, RoundedCornerShape(8.dp))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Navigation,
                contentDescription = "Wayfinding Direction",
                tint = if (isGateChanged) BaAmberWarning else BaSkyBlue,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isGateChanged) "Follow amber signage toward Gate A24 (North Concourse)" else "Follow blue airport guide line to Gate A20 (South Pier)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = BaWarmWhite
                )
                Text(
                    text = "Lifts and accessible travelators available along concourse",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaMutedSilver
                )
            }
        }
    }
}
