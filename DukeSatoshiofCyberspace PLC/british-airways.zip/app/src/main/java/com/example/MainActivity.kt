package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ConnectingAirports
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Luggage
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.TravelExplore
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Flight
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Luggage
import androidx.compose.material.icons.outlined.TravelExplore
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AppDatabase
import com.example.data.FlightRepository
import com.example.model.CabinClass
import com.example.model.DisruptionState
import com.example.model.JourneyState
import com.example.ui.components.AircraftSeatMapView
import com.example.ui.components.DigitalBoardingPass
import com.example.ui.screens.AviosScreen
import com.example.ui.screens.BaggageScreen
import com.example.ui.screens.BookFlightScreen
import com.example.ui.screens.CheckInDialog
import com.example.ui.screens.ConnectionsScreen
import com.example.ui.screens.DisruptionModal
import com.example.ui.screens.ExploreScreen
import com.example.ui.screens.HeathrowModeScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoungeScreen
import com.example.ui.screens.ManageBookingScreen
import com.example.ui.screens.TripsScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaDarkBackground
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite
import com.example.ui.theme.BritishAirwaysTheme
import com.example.ui.viewmodel.MainViewModel

enum class AppDestination {
    HOME,
    TRIPS,
    BOOK,
    EXPLORE,
    ACCOUNT,
    // Sub-screens
    HEATHROW,
    LOUNGE,
    CONNECTIONS,
    BAGGAGE,
    SEAT,
    MANAGE,
    TICKET,
    WALLET
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val scope = rememberCoroutineScope()
            val database = remember { AppDatabase.getDatabase(applicationContext, scope) }
            val repository = remember { FlightRepository(database, scope) }
            val viewModel: MainViewModel = viewModel(
                factory = MainViewModel.provideFactory(repository)
            )

            BritishAirwaysTheme {
                BritishAirwaysApp(viewModel)
            }
        }
    }
}

@Composable
fun BritishAirwaysApp(viewModel: MainViewModel) {
    var currentScreen by remember { mutableStateOf(AppDestination.HOME) }
    var screenHistory by remember { mutableStateOf(listOf(AppDestination.HOME)) }

    val trips by viewModel.trips.collectAsStateWithLifecycle()
    val activeTrip by viewModel.activeTrip.collectAsStateWithLifecycle()
    val baggageList by viewModel.baggage.collectAsStateWithLifecycle()
    val journeyState by viewModel.journeyState.collectAsStateWithLifecycle()
    val disruptionState by viewModel.disruptionState.collectAsStateWithLifecycle()

    var showDisruptionModal by remember { mutableStateOf(false) }
    var showCheckInDialog by remember { mutableStateOf(false) }

    fun navigateTo(dest: AppDestination) {
        screenHistory = screenHistory + dest
        currentScreen = dest
    }

    fun navigateBack() {
        if (screenHistory.size > 1) {
            val updated = screenHistory.dropLast(1)
            screenHistory = updated
            currentScreen = updated.last()
        } else {
            currentScreen = AppDestination.HOME
        }
    }

    // BackHandler for sub-screens
    if (currentScreen != AppDestination.HOME) {
        BackHandler {
            navigateBack()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = BaDarkBackground,
        bottomBar = {
            // Main Bottom Bar (Visible on primary top-level tabs)
            val isPrimaryTab = currentScreen in listOf(
                AppDestination.HOME,
                AppDestination.TRIPS,
                AppDestination.BOOK,
                AppDestination.EXPLORE,
                AppDestination.ACCOUNT
            )

            if (isPrimaryTab) {
                NavigationBar(
                    modifier = Modifier
                        .navigationBarsPadding()
                        .testTag("bottom_nav_bar"),
                    containerColor = BaNavySurface,
                    contentColor = BaWarmWhite
                ) {
                    NavigationBarItem(
                        selected = currentScreen == AppDestination.HOME,
                        onClick = {
                            currentScreen = AppDestination.HOME
                            screenHistory = listOf(AppDestination.HOME)
                        },
                        icon = {
                            Icon(
                                if (currentScreen == AppDestination.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                                contentDescription = "Home"
                            )
                        },
                        label = { Text("HOME", style = MaterialTheme.typography.labelSmall) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BaWarmWhite,
                            selectedTextColor = BaWarmWhite,
                            indicatorColor = BaSpeedmarqueRed,
                            unselectedIconColor = BaSilver,
                            unselectedTextColor = BaSilver
                        )
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppDestination.TRIPS,
                        onClick = {
                            currentScreen = AppDestination.TRIPS
                            screenHistory = listOf(AppDestination.HOME, AppDestination.TRIPS)
                        },
                        icon = {
                            Icon(
                                if (currentScreen == AppDestination.TRIPS) Icons.Filled.Luggage else Icons.Outlined.Luggage,
                                contentDescription = "Trips"
                            )
                        },
                        label = { Text("TRIPS", style = MaterialTheme.typography.labelSmall) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BaWarmWhite,
                            selectedTextColor = BaWarmWhite,
                            indicatorColor = BaSpeedmarqueRed,
                            unselectedIconColor = BaSilver,
                            unselectedTextColor = BaSilver
                        )
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppDestination.BOOK,
                        onClick = {
                            currentScreen = AppDestination.BOOK
                            screenHistory = listOf(AppDestination.HOME, AppDestination.BOOK)
                        },
                        icon = {
                            Icon(
                                if (currentScreen == AppDestination.BOOK) Icons.Filled.Flight else Icons.Outlined.Flight,
                                contentDescription = "Book"
                            )
                        },
                        label = { Text("BOOK", style = MaterialTheme.typography.labelSmall) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BaWarmWhite,
                            selectedTextColor = BaWarmWhite,
                            indicatorColor = BaSpeedmarqueRed,
                            unselectedIconColor = BaSilver,
                            unselectedTextColor = BaSilver
                        )
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppDestination.EXPLORE,
                        onClick = {
                            currentScreen = AppDestination.EXPLORE
                            screenHistory = listOf(AppDestination.HOME, AppDestination.EXPLORE)
                        },
                        icon = {
                            Icon(
                                if (currentScreen == AppDestination.EXPLORE) Icons.Filled.Explore else Icons.Outlined.Explore,
                                contentDescription = "Explore"
                            )
                        },
                        label = { Text("EXPLORE", style = MaterialTheme.typography.labelSmall) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BaWarmWhite,
                            selectedTextColor = BaWarmWhite,
                            indicatorColor = BaSpeedmarqueRed,
                            unselectedIconColor = BaSilver,
                            unselectedTextColor = BaSilver
                        )
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppDestination.ACCOUNT,
                        onClick = {
                            currentScreen = AppDestination.ACCOUNT
                            screenHistory = listOf(AppDestination.HOME, AppDestination.ACCOUNT)
                        },
                        icon = {
                            Icon(
                                if (currentScreen == AppDestination.ACCOUNT) Icons.Filled.AccountCircle else Icons.Outlined.AccountCircle,
                                contentDescription = "Account"
                            )
                        },
                        label = { Text("AVIOS", style = MaterialTheme.typography.labelSmall) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BaWarmWhite,
                            selectedTextColor = BaWarmWhite,
                            indicatorColor = BaGold,
                            unselectedIconColor = BaSilver,
                            unselectedTextColor = BaSilver
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppDestination.HOME -> {
                    HomeScreen(
                        trip = activeTrip,
                        journeyState = journeyState,
                        disruptionState = disruptionState,
                        onStateSelect = { viewModel.setJourneyState(it) },
                        onDisruptionToggle = { viewModel.setDisruptionState(it) },
                        onSelectDemo = { demoId ->
                            viewModel.loadSignatureDemo(demoId)
                            if (demoId == 2) {
                                navigateTo(AppDestination.CONNECTIONS)
                            } else if (demoId == 3) {
                                showDisruptionModal = true
                            }
                        },
                        onNavigateToTicket = { navigateTo(AppDestination.TICKET) },
                        onNavigateToHeathrow = { navigateTo(AppDestination.HEATHROW) },
                        onNavigateToLounge = { navigateTo(AppDestination.LOUNGE) },
                        onNavigateToBaggage = { navigateTo(AppDestination.BAGGAGE) },
                        onNavigateToSeat = { navigateTo(AppDestination.SEAT) },
                        onNavigateToManage = { navigateTo(AppDestination.MANAGE) },
                        onNavigateToDisruptionRebook = { showDisruptionModal = true }
                    )
                }

                AppDestination.TRIPS -> {
                    TripsScreen(
                        trips = trips,
                        onSelectTrip = { trip ->
                            viewModel.selectTrip(trip.id)
                        },
                        onNavigateToTicket = { trip ->
                            viewModel.selectTrip(trip.id)
                            navigateTo(AppDestination.TICKET)
                        },
                        onNavigateToCheckIn = { trip ->
                            viewModel.selectTrip(trip.id)
                            showCheckInDialog = true
                        }
                    )
                }

                AppDestination.BOOK -> {
                    BookFlightScreen(
                        onBookingConfirmed = { newTrip ->
                            viewModel.addNewTrip(newTrip)
                        }
                    )
                }

                AppDestination.EXPLORE -> {
                    ExploreScreen(
                        onSelectDestination = { dest ->
                            navigateTo(AppDestination.BOOK)
                        }
                    )
                }

                AppDestination.ACCOUNT -> {
                    AviosScreen()
                }

                AppDestination.HEATHROW -> {
                    HeathrowModeScreen(
                        currentGate = activeTrip?.gate ?: "A20",
                        disruptionState = disruptionState,
                        onSimulateGateChange = {
                            val newDis = if (disruptionState == DisruptionState.GATE_CHANGED) {
                                DisruptionState.ON_TIME
                            } else {
                                DisruptionState.GATE_CHANGED
                            }
                            viewModel.setDisruptionState(newDis)
                        }
                    )
                }

                AppDestination.LOUNGE -> {
                    LoungeScreen(
                        flightNumber = activeTrip?.flightNumber ?: "BA 017",
                        gate = activeTrip?.gate ?: "A20",
                        boardingTime = "07:10"
                    )
                }

                AppDestination.CONNECTIONS -> {
                    ConnectionsScreen()
                }

                AppDestination.BAGGAGE -> {
                    BaggageScreen(baggageList = baggageList)
                }

                AppDestination.SEAT -> {
                    Box(modifier = Modifier.padding(16.dp)) {
                        AircraftSeatMapView(
                            currentSeat = activeTrip?.seat ?: "3A",
                            currentCabin = when (activeTrip?.cabinName) {
                                "FIRST" -> CabinClass.FIRST
                                "CLUB" -> CabinClass.CLUB
                                "WORLD_TRAVELLER_PLUS" -> CabinClass.WORLD_TRAVELLER_PLUS
                                else -> CabinClass.WORLD_TRAVELLER
                            },
                            onSeatSelected = { seat, cabin ->
                                viewModel.updateSeat(seat, cabin)
                            }
                        )
                    }
                }

                AppDestination.MANAGE -> {
                    ManageBookingScreen(
                        trip = activeTrip,
                        onNavigateToSeatChange = { navigateTo(AppDestination.SEAT) },
                        onUpgradeCabin = { cabin ->
                            viewModel.updateSeat(activeTrip?.seat ?: "3A", cabin)
                        }
                    )
                }

                AppDestination.TICKET -> {
                    WalletScreen(trip = activeTrip)
                }

                AppDestination.WALLET -> {
                    WalletScreen(trip = activeTrip)
                }
            }
        }
    }

    // Modal Overlays
    if (showDisruptionModal && activeTrip != null) {
        DisruptionModal(
            trip = activeTrip!!,
            onDismiss = { showDisruptionModal = false },
            onConfirmRebook = { option ->
                viewModel.rebookFlight(
                    option.flightNo,
                    option.depTime,
                    option.arrTime,
                    option.gate
                )
            }
        )
    }

    if (showCheckInDialog && activeTrip != null) {
        CheckInDialog(
            trip = activeTrip!!,
            onDismiss = { showCheckInDialog = false },
            onCompleteCheckIn = {
                viewModel.completeCheckIn()
            }
        )
    }
}
