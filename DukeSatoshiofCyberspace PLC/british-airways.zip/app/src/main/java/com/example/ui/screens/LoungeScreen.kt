package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bathtub
import androidx.compose.material.icons.filled.Bed
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.LocalBar
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaDarkBackground
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaWarmWhite

@Composable
fun LoungeScreen(
    passengerName: String = "Tom Loveitt",
    flightNumber: String = "BA 017",
    gate: String = "A20",
    boardingTime: String = "07:10",
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf("DINING") }

    val menuItems = remember {
        listOf(
            "Laurent-Perrier Grand Siècle Champagne" to "Champagne, France • Prestige Cuvée",
            "Herefordshire 28-Day Dry Aged Beef Fillet" to "Truffle potato purée, charred shallots, bone marrow jus",
            "Cornish Dover Sole Meunière" to "Brown butter, capers, lemon, steamed sea greens",
            "British Heritage Artisan Cheese Board" to "Colston Bassett Stilton, Montgomery's Cheddar, damson jelly",
            "Traditional Afternoon Tea by British Airways" to "Warm scones, clotted cream, strawberry preserve, Jing tea"
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BaDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("lounge_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        // Section 29: Header
        item {
            Column {
                Text(
                    text = "HEATHROW TERMINAL 5 • THE FIRST WING ACCESS",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaGold
                )
                Text(
                    text = "THE CONCORDE ROOM",
                    style = MaterialTheme.typography.headlineLarge,
                    color = BaWarmWhite
                )
                Text(
                    text = "Exclusive sanctuary for British Airways First Class passengers and Concorde Room cardholders.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = BaSilver
                )
            }
        }

        // Hero Image of Concorde Room
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, BaGold.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ba_concorde_room),
                    contentDescription = "Concorde Room Lounge",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // Gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                colors = listOf(androidx.compose.ui.graphics.Color.Transparent, BaNavySurface.copy(alpha = 0.9f))
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(14.dp)
                ) {
                    Text("WELCOME, MR LOVEITT", style = MaterialTheme.typography.labelSmall, color = BaGold)
                    Text("Private Cabana 04 reserved until 07:00", style = MaterialTheme.typography.titleMedium, color = BaWarmWhite)
                }
            }
        }

        // Section 30: Capacity & Flight Status banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaBorderNavy)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("CURRENT CAPACITY", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                            Text("QUIET ●●●○○", style = MaterialTheme.typography.titleMedium, color = BaGreenSuccess)
                        }
                        Box(
                            modifier = Modifier
                                .background(BaNavyElevated, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text("SIMULATED CAPACITY", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                        }
                    }

                    HorizontalDivider(color = BaNavyLight.copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("FLIGHT", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                            Text(flightNumber, style = MaterialTheme.typography.titleMedium, color = BaSkyBlue)
                        }
                        Column {
                            Text("GATE", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                            Text(gate, style = MaterialTheme.typography.titleMedium, color = BaWarmWhite)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("BOARDING CALL", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                            Text(boardingTime, style = MaterialTheme.typography.titleMedium, color = BaGold)
                        }
                    }
                }
            }
        }

        // Lounge Amenities Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LoungeAmenityCard(
                    title = "Private Dining",
                    desc = "A la carte waiter service",
                    icon = Icons.Default.Restaurant,
                    modifier = Modifier.weight(1f),
                    onClick = { selectedCategory = "DINING" }
                )
                LoungeAmenityCard(
                    title = "Private Cabanas",
                    desc = "Day bed & en-suite",
                    icon = Icons.Default.Bed,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        Toast.makeText(context, "Cabana 04 Confirmed for Mr Loveitt", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LoungeAmenityCard(
                    title = "Champagne Bar",
                    desc = "Laurent-Perrier Bar",
                    icon = Icons.Default.LocalBar,
                    modifier = Modifier.weight(1f),
                    onClick = { selectedCategory = "CHAMPAGNE" }
                )
                LoungeAmenityCard(
                    title = "Work Suites",
                    desc = "High-speed quiet pods",
                    icon = Icons.Default.Wifi,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        Toast.makeText(context, "Work Pod connected to BA Wi-Fi", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }

        // Dining Menu Preview
        item {
            Text("CONCORDE ROOM PRIVATE DINING", style = MaterialTheme.typography.labelSmall, color = BaGold)
        }

        items(menuItems) { (dish, desc) ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = BaNavyCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, BaNavyLight.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(dish, style = MaterialTheme.typography.titleMedium, color = BaWarmWhite)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(desc, style = MaterialTheme.typography.bodyMedium, color = BaSilver)
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun LoungeAmenityCard(
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(BaNavySurface)
            .border(1.dp, BaBorderNavy, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Column {
            Icon(imageVector = icon, contentDescription = title, tint = BaGold, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = title, style = MaterialTheme.typography.labelLarge, color = BaWarmWhite)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = desc, style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        }
    }
}
