package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// British Airways Anglo-Futurist Supermodernity Palette
val BaDeepNavy = Color(0xFF07152B)
val BaNavy = Color(0xFF0B2240)
val BaNavyLight = Color(0xFF143564)
val BaNavySurface = Color(0xFF0E1C30)
val BaNavyCard = Color(0xFF12243E)
val BaNavyElevated = Color(0xFF182F50)
val BaDarkBackground = Color(0xFF050E1C)

// Accents
val BaSpeedmarqueRed = Color(0xFFEB2226)
val BaBurgundy = Color(0xFF7E1B28)
val BaGold = Color(0xFFC5A059)
val BaSkyBlue = Color(0xFF38BDF8)
val BaAviationBlue = Color(0xFF1E88E5)

// Neutral & Architectural
val BaWarmWhite = Color(0xFFF8F9FA)
val BaGraphite = Color(0xFF1E232B)
val BaSilver = Color(0xFFCBD5E1)
val BaMutedSilver = Color(0xFF94A3B8)
val BaBorderNavy = Color(0xFF1D3557)
val BaGreenSuccess = Color(0xFF10B981)
val BaAmberWarning = Color(0xFFF59E0B)
