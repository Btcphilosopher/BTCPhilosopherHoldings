package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FlightTelemetry
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

@Composable
fun FlightDeckTelemetryView(
    telemetry: FlightTelemetry = FlightTelemetry(),
    flightNumber: String = "BA 017",
    originCode: String = "LHR",
    destCode: String = "JFK",
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "flightProgress")
    val pulseProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseProgress"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(BaNavySurface, RoundedCornerShape(12.dp))
            .border(1.dp, BaBorderNavy, RoundedCornerShape(12.dp))
            .padding(16.dp)
            .testTag("flight_deck_telemetry")
    ) {
        // Header with Simulation Tag
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AIRCRAFT TELEMETRY • $flightNumber",
                    style = MaterialTheme.typography.labelMedium,
                    color = BaSkyBlue
                )
                Text(
                    text = "AIRBORNE • NORTH ATLANTIC TRACK",
                    style = MaterialTheme.typography.titleMedium,
                    color = BaWarmWhite
                )
            }
            Box(
                modifier = Modifier
                    .background(BaNavyElevated, RoundedCornerShape(4.dp))
                    .border(1.dp, BaGold.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "SIMULATED FLIGHT DATA",
                    style = MaterialTheme.typography.labelSmall,
                    color = BaGold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Flight corridor radar map
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .background(BaNavyCard, RoundedCornerShape(8.dp))
                .border(1.dp, BaNavyLight.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Draw latitude/longitude grid rings
                drawCircle(
                    color = BaBorderNavy.copy(alpha = 0.3f),
                    radius = w * 0.45f,
                    center = Offset(w * 0.5f, h * 0.5f),
                    style = Stroke(width = 1f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 8f), 0f))
                )
                drawCircle(
                    color = BaBorderNavy.copy(alpha = 0.2f),
                    radius = w * 0.25f,
                    center = Offset(w * 0.5f, h * 0.5f),
                    style = Stroke(width = 1f)
                )

                // Transatlantic great circle arc: London (right) to New York (left)
                val lhrX = w * 0.85f
                val lhrY = h * 0.40f

                val jfkX = w * 0.15f
                val jfkY = h * 0.65f

                val controlX = w * 0.50f
                val controlY = h * 0.15f // Arc up toward Greenland/Iceland track

                val flightPath = Path().apply {
                    moveTo(lhrX, lhrY)
                    quadraticTo(controlX, controlY, jfkX, jfkY)
                }

                // Path track
                drawPath(
                    path = flightPath,
                    color = BaBorderNavy,
                    style = Stroke(width = 3f, cap = StrokeCap.Round)
                )

                // Flown portion (from LHR to current point)
                val t = 0.52f // Current simulated progress
                val currentPlaneX = (1 - t) * (1 - t) * lhrX + 2 * (1 - t) * t * controlX + t * t * jfkX
                val currentPlaneY = (1 - t) * (1 - t) * lhrY + 2 * (1 - t) * t * controlY + t * t * jfkY

                val flownPath = Path().apply {
                    moveTo(lhrX, lhrY)
                    quadraticTo(
                        (lhrX + controlX) / 2f,
                        (lhrY + controlY) / 2f,
                        currentPlaneX,
                        currentPlaneY
                    )
                }

                drawPath(
                    path = flownPath,
                    color = BaSkyBlue,
                    style = Stroke(width = 3.5f, cap = StrokeCap.Round)
                )

                // Origin (LHR) node
                drawCircle(color = BaWarmWhite, radius = 5f, center = Offset(lhrX, lhrY))
                // Destination (JFK) node
                drawCircle(color = BaGold, radius = 5f, center = Offset(jfkX, jfkY))

                // Aircraft marker
                drawCircle(
                    color = BaSpeedmarqueRed,
                    radius = 7f,
                    center = Offset(currentPlaneX, currentPlaneY)
                )
                // Radar ping ring
                drawCircle(
                    color = BaSpeedmarqueRed.copy(alpha = 1f - pulseProgress),
                    radius = 7f + pulseProgress * 20f,
                    center = Offset(currentPlaneX, currentPlaneY),
                    style = Stroke(width = 2f)
                )
            }

            // Map Overlays
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
                    .align(Alignment.BottomCenter),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "DESTINATION", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                    Text(text = "$destCode (11:05 EST)", style = MaterialTheme.typography.titleMedium, color = BaGold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "DEPARTED", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
                    Text(text = "$originCode (07:45 GMT)", style = MaterialTheme.typography.titleMedium, color = BaWarmWhite)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Instruments Grid (Engineering telemetry)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TelemetryGauge(
                title = "ALTITUDE",
                value = "${telemetry.altitudeFt.toString().replace(Regex("(\\d)(?=(\\d{3})+$)"), "$1,")} FT",
                subtitle = "FL 360",
                modifier = Modifier.weight(1f)
            )
            TelemetryGauge(
                title = "GROUND SPEED",
                value = "${telemetry.groundSpeedKt} KT",
                subtitle = "Mach 0.84",
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TelemetryGauge(
                title = "DISTANCE REMAINING",
                value = "${telemetry.distanceRemainingMi.toString().replace(Regex("(\\d)(?=(\\d{3})+$)"), "$1,")} MI",
                subtitle = "ETA 11:05 EST",
                modifier = Modifier.weight(1f)
            )
            TelemetryGauge(
                title = "OUTSIDE TEMP",
                value = "${telemetry.outsideTempC}°C",
                subtitle = "Heading ${telemetry.headingDeg}° NW",
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun TelemetryGauge(
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(BaNavyElevated, RoundedCornerShape(8.dp))
            .border(1.dp, BaNavyLight.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Text(text = title, style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, style = MaterialTheme.typography.titleLarge, color = BaWarmWhite)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = BaSkyBlue)
    }
}
