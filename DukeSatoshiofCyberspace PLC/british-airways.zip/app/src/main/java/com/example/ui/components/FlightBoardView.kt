package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BaAmberWarning
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

data class FlightBoardItem(
    val flightNo: String,
    val destination: String,
    val schedTime: String,
    val terminal: String,
    val gate: String,
    val status: String,
    val statusColor: Color
)

@Composable
fun FlightBoardView(
    modifier: Modifier = Modifier,
    onFlightSelect: (String) -> Unit = {}
) {
    val sampleBoard = remember {
        listOf(
            FlightBoardItem("BA 017", "NEW YORK JFK", "07:45", "T5A", "A20", "BOARDING", BaGreenSuccess),
            FlightBoardItem("BA 245", "PARIS CDG", "08:10", "T5A", "A14", "GATE OPEN", BaSkyBlue),
            FlightBoardItem("BA 331", "TOKYO HND", "08:30", "T5B", "B32", "ON TIME", BaSilver),
            FlightBoardItem("BA 138", "MUMBAI BOM", "09:15", "T5C", "C54", "ON TIME", BaSilver),
            FlightBoardItem("BA 285", "SAN FRANCISCO", "10:05", "T5B", "B44", "ON TIME", BaSilver),
            FlightBoardItem("BA 117", "NEW YORK JFK", "11:20", "T5A", "A18", "ON TIME", BaSilver),
            FlightBoardItem("BA 109", "DUBAI DXB", "12:15", "T5C", "C62", "DELAYED", BaAmberWarning)
        )
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(BaNavySurface)
            .border(1.dp, BaBorderNavy, RoundedCornerShape(12.dp))
            .padding(14.dp)
            .testTag("flight_board_view")
    ) {
        // Board Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "HEATHROW TERMINAL 5 • DEPARTURES",
                    style = MaterialTheme.typography.labelMedium,
                    color = BaSkyBlue
                )
                Text(
                    text = "FLIGHT INFORMATION DISPLAY",
                    style = MaterialTheme.typography.titleMedium,
                    color = BaWarmWhite
                )
            }
            Text(
                text = "07:18 GMT",
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
                color = BaGold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Column Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BaNavyElevated, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("FLIGHT", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver, modifier = Modifier.width(62.dp))
            Text("DESTINATION", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver, modifier = Modifier.weight(1f))
            Text("DEP", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver, modifier = Modifier.width(44.dp))
            Text("GATE", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver, modifier = Modifier.width(42.dp))
            Text("STATUS", style = MaterialTheme.typography.labelSmall, color = BaMutedSilver, modifier = Modifier.width(76.dp))
        }

        Spacer(modifier = Modifier.height(6.dp))

        sampleBoard.forEachIndexed { index, item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (index % 2 == 0) BaNavyCard else Color.Transparent)
                    .clickable { onFlightSelect(item.flightNo) }
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.flightNo,
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = FontFamily.Monospace),
                    color = if (item.flightNo == "BA 017") BaGold else BaSkyBlue,
                    modifier = Modifier.width(62.dp)
                )
                Text(
                    text = item.destination,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = BaWarmWhite,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = item.schedTime,
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = FontFamily.Monospace),
                    color = BaSilver,
                    modifier = Modifier.width(44.dp)
                )
                Text(
                    text = item.gate,
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = FontFamily.Monospace),
                    color = BaWarmWhite,
                    modifier = Modifier.width(42.dp)
                )
                Text(
                    text = item.status,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = item.statusColor,
                    modifier = Modifier.width(76.dp)
                )
            }
            if (index < sampleBoard.size - 1) {
                HorizontalDivider(color = BaNavyLight.copy(alpha = 0.2f), thickness = 0.5.dp)
            }
        }
    }
}
