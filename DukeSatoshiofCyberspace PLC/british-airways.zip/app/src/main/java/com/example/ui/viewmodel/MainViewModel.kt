package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.BaggageEntity
import com.example.data.FlightRepository
import com.example.data.ProfileEntity
import com.example.data.TripEntity
import com.example.model.CabinClass
import com.example.model.DisruptionState
import com.example.model.JourneyState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: FlightRepository
) : ViewModel() {

    val trips: StateFlow<List<TripEntity>> = repository.allTrips
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val baggage: StateFlow<List<BaggageEntity>> = repository.baggageList
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val profile: StateFlow<ProfileEntity?> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _activeTripId = MutableStateFlow("trip-ba017-lhr-jfk")
    val activeTripId: StateFlow<String> = _activeTripId.asStateFlow()

    private val _journeyState = MutableStateFlow(JourneyState.CHECKED_IN)
    val journeyState: StateFlow<JourneyState> = _journeyState.asStateFlow()

    private val _disruptionState = MutableStateFlow(DisruptionState.ON_TIME)
    val disruptionState: StateFlow<DisruptionState> = _disruptionState.asStateFlow()

    val activeTrip: StateFlow<TripEntity?> = combine(trips, _activeTripId) { tripList, activeId ->
        tripList.find { it.id == activeId } ?: tripList.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun selectTrip(tripId: String) {
        _activeTripId.value = tripId
    }

    fun setJourneyState(state: JourneyState) {
        _journeyState.value = state
        viewModelScope.launch {
            repository.updateJourneyState(_activeTripId.value, state)
        }
    }

    fun setDisruptionState(disruption: DisruptionState) {
        _disruptionState.value = disruption
        val gate = if (disruption == DisruptionState.GATE_CHANGED) "A24" else "A20"
        viewModelScope.launch {
            repository.updateDisruption(_activeTripId.value, disruption, gate)
        }
    }

    fun loadSignatureDemo(demoId: Int) {
        when (demoId) {
            1 -> {
                // Demo 1: London -> New York First Class Journey
                _activeTripId.value = "trip-ba017-lhr-jfk"
                _journeyState.value = JourneyState.CHECKED_IN
                _disruptionState.value = DisruptionState.ON_TIME
                viewModelScope.launch {
                    repository.updateSeatAndCabin("trip-ba017-lhr-jfk", "3A", CabinClass.FIRST)
                    repository.updateJourneyState("trip-ba017-lhr-jfk", JourneyState.CHECKED_IN)
                }
            }
            2 -> {
                // Demo 2: Connecting Journey LHR -> JFK -> LAX
                _activeTripId.value = "trip-ba-lhr-jfk-lax"
                _journeyState.value = JourneyState.CONNECTING
                _disruptionState.value = DisruptionState.ON_TIME
            }
            3 -> {
                // Demo 3: Disruption & Rebooking
                _activeTripId.value = "trip-ba017-lhr-jfk"
                _journeyState.value = JourneyState.AIRPORT
                _disruptionState.value = DisruptionState.DELAYED
                viewModelScope.launch {
                    repository.updateDisruption("trip-ba017-lhr-jfk", DisruptionState.DELAYED, "A20")
                }
            }
            4 -> {
                // Demo 4: First Class Procession (Suite 1A, Concorde Room)
                _activeTripId.value = "trip-ba017-lhr-jfk"
                _journeyState.value = JourneyState.LOUNGE
                _disruptionState.value = DisruptionState.ON_TIME
                viewModelScope.launch {
                    repository.updateSeatAndCabin("trip-ba017-lhr-jfk", "1A", CabinClass.FIRST)
                    repository.updateJourneyState("trip-ba017-lhr-jfk", JourneyState.LOUNGE)
                }
            }
            5 -> {
                // Demo 5: World Traveller Economy Experience
                _activeTripId.value = "trip-ba017-lhr-jfk"
                _journeyState.value = JourneyState.GATE
                _disruptionState.value = DisruptionState.ON_TIME
                viewModelScope.launch {
                    repository.updateSeatAndCabin("trip-ba017-lhr-jfk", "24A", CabinClass.WORLD_TRAVELLER)
                    repository.updateJourneyState("trip-ba017-lhr-jfk", JourneyState.GATE)
                }
            }
        }
    }

    fun rebookFlight(newFlightNo: String, depTime: String, arrTime: String, gate: String) {
        viewModelScope.launch {
            repository.rebookFlight(_activeTripId.value, newFlightNo, depTime, arrTime, gate)
            _disruptionState.value = DisruptionState.ON_TIME
        }
    }

    fun updateSeat(seat: String, cabin: CabinClass) {
        viewModelScope.launch {
            repository.updateSeatAndCabin(_activeTripId.value, seat, cabin)
        }
    }

    fun completeCheckIn() {
        _journeyState.value = JourneyState.CHECKED_IN
        viewModelScope.launch {
            repository.updateJourneyState(_activeTripId.value, JourneyState.CHECKED_IN)
        }
    }

    fun addNewTrip(trip: TripEntity) {
        viewModelScope.launch {
            repository.createTrip(trip)
            _activeTripId.value = trip.id
            _journeyState.value = JourneyState.BOOKED
        }
    }

    companion object {
        fun provideFactory(repository: FlightRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return MainViewModel(repository) as T
                }
            }
    }
}
