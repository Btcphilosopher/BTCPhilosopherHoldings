package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [TripEntity::class, BaggageEntity::class, ProfileEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tripDao(): TripDao
    abstract fun baggageDao(): BaggageDao
    abstract fun profileDao(): ProfileDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "british_airways_os.db"
                )
                .addCallback(DatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }
    }
}

suspend fun populateInitialData(database: AppDatabase) {
    val tripDao = database.tripDao()
    val baggageDao = database.baggageDao()
    val profileDao = database.profileDao()

    // 1. Flagship Signature Journey: BA 017 London to New York (FIRST CLASS)
    val flagshipTrip = TripEntity(
        id = "trip-ba017-lhr-jfk",
        flightNumber = "BA 017",
        originCode = "LHR",
        originName = "London Heathrow",
        originTerminal = "Terminal 5",
        destCode = "JFK",
        destName = "New York JFK",
        destTerminal = "Terminal 7",
        departureTime = "07:45",
        arrivalTime = "11:05",
        duration = "7h 20m",
        flightDate = "18 OCT",
        aircraft = "Boeing 777-300ER (Concorde Suite Spec)",
        gate = "A20",
        seat = "3A",
        cabinName = "FIRST",
        bookingRef = "BA-LON772K",
        boardingGroup = 1,
        journeyStateName = "CHECKED_IN",
        disruptionStateName = "ON_TIME",
        isConnecting = false,
        isFlagshipDemo = true
    )

    // 2. Connecting Journey: LHR -> JFK -> LAX
    val connectingTrip = TripEntity(
        id = "trip-ba-lhr-jfk-lax",
        flightNumber = "BA 017",
        originCode = "LHR",
        originName = "London Heathrow",
        originTerminal = "Terminal 5",
        destCode = "JFK",
        destName = "New York JFK",
        destTerminal = "Terminal 7",
        departureTime = "07:45",
        arrivalTime = "11:05",
        duration = "11h 45m total",
        flightDate = "24 OCT",
        aircraft = "Airbus A350-1000",
        gate = "A22",
        seat = "1A",
        cabinName = "FIRST",
        bookingRef = "BA-CONN482",
        boardingGroup = 1,
        journeyStateName = "BOOKED",
        disruptionStateName = "ON_TIME",
        isConnecting = true,
        connFlightNumber = "BA 1512",
        connDest = "Los Angeles LAX",
        connGate = "B12",
        isFlagshipDemo = false
    )

    // 3. Upcoming Tokyo Journey: BA 005 London to Tokyo Haneda
    val tokyoTrip = TripEntity(
        id = "trip-ba005-lhr-hnd",
        flightNumber = "BA 005",
        originCode = "LHR",
        originName = "London Heathrow",
        originTerminal = "Terminal 5",
        destCode = "HND",
        destName = "Tokyo Haneda",
        destTerminal = "Terminal 3",
        departureTime = "13:35",
        arrivalTime = "10:55 +1",
        duration = "14h 20m",
        flightDate = "03 NOV",
        aircraft = "Boeing 787-10 Dreamliner",
        gate = "B38",
        seat = "2K",
        cabinName = "CLUB",
        bookingRef = "BA-TYO991A",
        boardingGroup = 1,
        journeyStateName = "BOOKED",
        disruptionStateName = "ON_TIME",
        isConnecting = false,
        isFlagshipDemo = false
    )

    tripDao.insertTrips(listOf(flagshipTrip, connectingTrip, tokyoTrip))

    // Baggage for flagship trip
    val bags = listOf(
        BaggageEntity(
            tagNumber = "BA123456",
            tripId = "trip-ba017-lhr-jfk",
            passengerName = "Tom Loveitt",
            weightKg = 23,
            status = "Checked In & Tagged",
            location = "Heathrow T5 Bag Drop C",
            beltNumber = "Belt 8",
            stagesCompleted = 1
        ),
        BaggageEntity(
            tagNumber = "BA123457",
            tripId = "trip-ba017-lhr-jfk",
            passengerName = "Tom Loveitt",
            weightKg = 21,
            status = "Checked In & Tagged",
            location = "Heathrow T5 Bag Drop C",
            beltNumber = "Belt 8",
            stagesCompleted = 1
        )
    )
    baggageDao.insertBaggage(bags)

    // Executive Club Profile for Tom Loveitt
    val profile = ProfileEntity(
        id = 1,
        name = "Tom Loveitt",
        tier = "Gold",
        aviosBalance = 124800,
        tierPoints = 1340,
        membershipNumber = "BA 9482 1042",
        passportMasked = "GBR ••••••••42",
        nationality = "British",
        mealPreference = "British Airways Seasonal Fine Dining",
        assistanceReq = "None"
    )
    profileDao.insertProfile(profile)
}
