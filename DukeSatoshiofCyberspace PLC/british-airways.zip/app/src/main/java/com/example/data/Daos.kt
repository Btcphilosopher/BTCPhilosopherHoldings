package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TripDao {
    @Query("SELECT * FROM trips ORDER BY isFlagshipDemo DESC, id ASC")
    fun getAllTrips(): Flow<List<TripEntity>>

    @Query("SELECT * FROM trips WHERE id = :id LIMIT 1")
    fun getTripById(id: String): Flow<TripEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrip(trip: TripEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrips(trips: List<TripEntity>)

    @Update
    suspend fun updateTrip(trip: TripEntity)

    @Query("UPDATE trips SET journeyStateName = :state WHERE id = :id")
    suspend fun updateJourneyState(id: String, state: String)

    @Query("UPDATE trips SET disruptionStateName = :state, gate = :gate WHERE id = :id")
    suspend fun updateDisruption(id: String, state: String, gate: String)

    @Query("UPDATE trips SET seat = :seat, cabinName = :cabin WHERE id = :id")
    suspend fun updateSeatAndCabin(id: String, seat: String, cabin: String)

    @Query("DELETE FROM trips WHERE id = :id")
    suspend fun deleteTrip(id: String)
}

@Dao
interface BaggageDao {
    @Query("SELECT * FROM baggage")
    fun getAllBaggage(): Flow<List<BaggageEntity>>

    @Query("SELECT * FROM baggage WHERE tripId = :tripId")
    fun getBaggageForTrip(tripId: String): Flow<List<BaggageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBaggage(items: List<BaggageEntity>)

    @Update
    suspend fun updateBaggage(item: BaggageEntity)

    @Query("UPDATE baggage SET status = :status, location = :location, stagesCompleted = :stage WHERE tagNumber = :tag")
    suspend fun updateStatus(tag: String, status: String, location: String, stage: Int)
}

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profile WHERE id = 1 LIMIT 1")
    fun getProfile(): Flow<ProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: ProfileEntity)

    @Update
    suspend fun updateProfile(profile: ProfileEntity)
}
