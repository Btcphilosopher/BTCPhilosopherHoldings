package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.TripEntity
import com.example.ui.theme.BaBorderNavy
import com.example.ui.theme.BaGold
import com.example.ui.theme.BaGreenSuccess
import com.example.ui.theme.BaMutedSilver
import com.example.ui.theme.BaNavyCard
import com.example.ui.theme.BaNavyElevated
import com.example.ui.theme.BaNavyLight
import com.example.ui.theme.BaNavySurface
import com.example.ui.theme.BaSilver
import com.example.ui.theme.BaSkyBlue
import com.example.ui.theme.BaSpeedmarqueRed
import com.example.ui.theme.BaWarmWhite

@Composable
fun CheckInDialog(
    trip: TripEntity,
    passengerName: String = "Tom Loveitt",
    onDismiss: () -> Unit,
    onCompleteCheckIn: () -> Unit
) {
    val context = LocalContext.current
    var isConfirmed by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .testTag("check_in_dialog"),
            colors = CardDefaults.cardColors(containerColor = BaNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, BaGold)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ONLINE CHECK-IN", style = MaterialTheme.typography.labelSmall, color = BaSkyBlue)
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = BaSilver)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                if (!isConfirmed) {
                    Text(
                        text = "FLIGHT CHECK-IN",
                        style = MaterialTheme.typography.headlineMedium,
                        color = BaWarmWhite
                    )
                    Text(
                        text = "Confirm details for ${trip.flightNumber} to New York JFK.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BaSilver
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = BaNavyCard),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BaNavyLight.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            CheckInDetailRow("PASSENGER", passengerName)
                            CheckInDetailRow("FLIGHT", "${trip.flightNumber} • ${trip.originCode} → ${trip.destCode}")
                            CheckInDetailRow("CABIN & SEAT", "${trip.cabinName} • Suite ${trip.seat}")
                            CheckInDetailRow("CHECKED BAGGAGE", "2 × Checked Hold Bags (Complimentary)")
                            CheckInDetailRow("PASSPORT", "GBR ••••••••42 (Verified)")
                            CheckInDetailRow("DINING", "British Airways Seasonal Fine Dining")
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(BaSpeedmarqueRed)
                            .clickable {
                                isConfirmed = true
                                onCompleteCheckIn()
                            }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("CONFIRM CHECK-IN & ISSUE PASS", style = MaterialTheme.typography.labelLarge, color = BaWarmWhite)
                    }
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BaGreenSuccess, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("YOU'RE CHECKED IN", style = MaterialTheme.typography.headlineLarge, color = BaWarmWhite)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Boarding Pass generated. Boarding Group 1 priority access confirmed.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BaSilver
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(BaNavyElevated)
                                .border(1.dp, BaSkyBlue, RoundedCornerShape(8.dp))
                                .clickable { onDismiss() }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("VIEW BOARDING PASS", style = MaterialTheme.typography.labelMedium, color = BaWarmWhite)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CheckInDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = BaMutedSilver)
        Text(value, style = MaterialTheme.typography.labelMedium, color = BaWarmWhite)
    }
}
