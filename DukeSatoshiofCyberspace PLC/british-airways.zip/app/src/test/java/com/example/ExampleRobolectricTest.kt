package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.CabinClass
import com.example.model.DisruptionState
import com.example.model.JourneyState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app name from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("British Airways", appName)
  }

  @Test
  fun `verify journey states and cabins count`() {
    assertEquals(15, JourneyState.values().size)
    assertEquals(7, DisruptionState.values().size)
    assertNotNull(CabinClass.FIRST)
    assertNotNull(CabinClass.CLUB)
  }
}
