package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoolWhite
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.InstrumentBlack
import com.example.ui.theme.MutedGreen
import com.example.ui.theme.TacticalPanelBorder
import com.example.ui.theme.TechnicalBlue
import com.example.ui.theme.Titanium
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CircularGauge(
    title: String,
    value: Float,
    unit: String,
    minVal: Float,
    maxVal: Float,
    warningVal: Float? = null,
    criticalVal: Float? = null,
    modifier: Modifier = Modifier,
    sizeDp: Dp = 110.dp,
    decimalPlaces: Int = 0
) {
    Box(
        modifier = modifier
            .size(sizeDp)
            .background(InstrumentBlack, CircleShape)
            .testTag("circular_gauge_${title.lowercase().replace(" ", "_")}"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(sizeDp)) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val radius = (size.width / 2f) - 8.dp.toPx()

            val startAngle = 135f
            val sweepTotal = 270f

            // 1. Background Arc Track
            drawArc(
                color = TacticalPanelBorder,
                startAngle = startAngle,
                sweepAngle = sweepTotal,
                useCenter = false,
                topLeft = Offset(cx - radius, cy - radius),
                size = Size(radius * 2, radius * 2),
                style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
            )

            // 2. Colored Arc Bands (Normal, Caution, Warning)
            val range = (maxVal - minVal).coerceAtLeast(1f)
            
            // Value progress arc
            val fraction = ((value - minVal) / range).coerceIn(0f, 1f)
            val sweepActive = sweepTotal * fraction

            val activeColor = when {
                criticalVal != null && ((criticalVal > minVal && value >= criticalVal) || (criticalVal < minVal && value <= criticalVal)) -> CriticalRed
                warningVal != null && ((warningVal > minVal && value >= warningVal) || (warningVal < minVal && value <= warningVal)) -> AmberWarning
                else -> MutedGreen
            }

            drawArc(
                color = activeColor,
                startAngle = startAngle,
                sweepAngle = sweepActive,
                useCenter = false,
                topLeft = Offset(cx - radius, cy - radius),
                size = Size(radius * 2, radius * 2),
                style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
            )

            // 3. Tick Marks
            val numTicks = 9
            for (i in 0 until numTicks) {
                val tickFraction = i.toFloat() / (numTicks - 1)
                val tickAngleDeg = startAngle + (sweepTotal * tickFraction)
                val tickAngleRad = Math.toRadians(tickAngleDeg.toDouble())

                val innerR = radius - 7.dp.toPx()
                val outerR = radius - 2.dp.toPx()

                val start = Offset(
                    (cx + innerR * cos(tickAngleRad)).toFloat(),
                    (cy + innerR * sin(tickAngleRad)).toFloat()
                )
                val end = Offset(
                    (cx + outerR * cos(tickAngleRad)).toFloat(),
                    (cy + outerR * sin(tickAngleRad)).toFloat()
                )
                drawLine(
                    color = Titanium,
                    start = start,
                    end = end,
                    strokeWidth = 1.2.dp.toPx()
                )
            }

            // 4. Pointer Needle
            val needleAngleDeg = startAngle + sweepActive
            val needleAngleRad = Math.toRadians(needleAngleDeg.toDouble())
            val needleLen = radius - 10.dp.toPx()
            val needleEnd = Offset(
                (cx + needleLen * cos(needleAngleRad)).toFloat(),
                (cy + needleLen * sin(needleAngleRad)).toFloat()
            )
            drawLine(
                color = CoolWhite,
                start = Offset(cx, cy),
                end = needleEnd,
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawCircle(color = TechnicalBlue, radius = 4.dp.toPx(), center = Offset(cx, cy))
        }

        // Center Digital Readout & Title
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title.uppercase(),
                color = Titanium,
                fontFamily = FontFamily.Monospace,
                fontSize = 8.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(2.dp))
            val formattedVal = if (decimalPlaces == 0) value.toInt().toString() else "%.${decimalPlaces}f".format(value)
            Text(
                text = formattedVal,
                color = CoolWhite,
                fontFamily = FontFamily.Monospace,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = unit,
                color = Titanium,
                fontFamily = FontFamily.Monospace,
                fontSize = 8.sp
            )
        }
    }
}
