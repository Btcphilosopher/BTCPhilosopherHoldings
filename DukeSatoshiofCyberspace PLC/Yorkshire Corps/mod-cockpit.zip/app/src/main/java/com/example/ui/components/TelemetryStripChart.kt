package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CoolWhite
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.InstrumentBlack
import com.example.ui.theme.TacticalGridLine
import com.example.ui.theme.TacticalPanelBorder
import com.example.ui.theme.TechnicalBlue
import com.example.ui.theme.Titanium

@Composable
fun TelemetryStripChart(
    title: String,
    dataPoints: List<Float>,
    unit: String,
    lineColor: Color = TechnicalBlue,
    modifier: Modifier = Modifier,
    minYOverride: Float? = null,
    maxYOverride: Float? = null
) {
    val minVal = minYOverride ?: (dataPoints.minOrNull() ?: 0f)
    val maxVal = maxYOverride ?: (dataPoints.maxOrNull() ?: 100f).coerceAtLeast(minVal + 1f)
    val avgVal = if (dataPoints.isNotEmpty()) dataPoints.average().toFloat() else 0f
    val currentVal = dataPoints.lastOrNull() ?: 0f

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(130.dp)
            .background(InstrumentBlack, RoundedCornerShape(6.dp))
            .padding(8.dp)
            .testTag("telemetry_chart_${title.lowercase().replace(" ", "_")}")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Chart Header with Min / Max / Avg / Current readouts
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title.uppercase(),
                    color = CoolWhite,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "CUR: ${currentVal.toInt()} $unit  |  MIN: ${minVal.toInt()}  |  MAX: ${maxVal.toInt()}  |  AVG: ${avgVal.toInt()}",
                    color = Titanium,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Waveform Canvas
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Grid lines (3 horizontal + 4 vertical)
                for (i in 0..3) {
                    val y = (h / 3f) * i
                    drawLine(TacticalGridLine, Offset(0f, y), Offset(w, y), 1f)
                }
                for (i in 0..4) {
                    val x = (w / 4f) * i
                    drawLine(TacticalGridLine, Offset(x, 0f), Offset(x, h), 1f)
                }

                if (dataPoints.size >= 2) {
                    val range = (maxVal - minVal).coerceAtLeast(0.001f)
                    val stepX = w / (dataPoints.size - 1).coerceAtLeast(1)

                    val path = Path()
                    dataPoints.forEachIndexed { index, value ->
                        val x = index * stepX
                        val normalized = ((value - minVal) / range).coerceIn(0f, 1f)
                        val y = h - (normalized * h)
                        if (index == 0) {
                            path.moveTo(x, y)
                        } else {
                            path.lineTo(x, y)
                        }
                    }

                    // Stroke curve
                    drawPath(
                        path = path,
                        color = lineColor,
                        style = Stroke(width = 2f, cap = StrokeCap.Round)
                    )

                    // Latest point indicator dot
                    val lastX = (dataPoints.size - 1) * stepX
                    val lastNorm = ((currentVal - minVal) / range).coerceIn(0f, 1f)
                    val lastY = h - (lastNorm * h)
                    drawCircle(color = CoolWhite, radius = 3.5f, center = Offset(lastX, lastY))
                }
            }
        }
    }
}
