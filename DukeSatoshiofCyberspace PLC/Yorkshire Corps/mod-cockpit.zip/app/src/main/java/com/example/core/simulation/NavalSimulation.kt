package com.example.core.simulation

import com.example.core.model.FaultInjection
import com.example.core.model.StandardFaults
import com.example.core.model.SubsystemCategory
import com.example.core.model.SubsystemHealth
import com.example.core.model.SystemStatus
import com.example.core.model.TelemetryPacket
import com.example.core.model.TrainingScenario
import com.example.core.model.VehicleProfile
import com.example.core.model.VehicleRegistry
import com.example.core.model.VehicleType
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class NavalSimulation : VehicleSimulation {
    override val vehicleProfile: VehicleProfile = VehicleRegistry.getProfile(VehicleType.NAVAL)

    private var simulationTimeSec = 0f
    private var speedKnots = 18.5f
    private var headingDeg = 245f
    private var rudderAngleDeg = 0f
    private var pitchDeg = 1.0f
    private var rollDeg = -2.0f
    private var shaftRpmPort = 180f
    private var shaftRpmStbd = 180f
    private var boilerPressureBar = 42.0f
    private var coolantTempC = 82f
    private var lubeOilPressureBar = 4.2f
    private var fuelRemainingPct = 84f
    private var busVoltageV = 440f
    private var generatorKw = 3200f
    private var bilgeLevelB1Pct = 0f
    private var emergencyPumpActive = false
    private var seaState = 4
    private var windSpeedKts = 22f
    private var windDirectionDeg = 110f
    private var waterDepthM = 48f

    private val activeFaults = mutableMapOf<String, FaultInjection>()
    private val alertList = mutableListOf<String>()

    override fun initialize(scenario: TrainingScenario?) {
        reset()
        scenario?.initialFaultId?.let { faultId ->
            StandardFaults.faults.find { it.id == faultId }?.let { injectFault(it) }
        }
    }

    override fun reset() {
        simulationTimeSec = 0f
        speedKnots = 18.5f
        headingDeg = 245f
        rudderAngleDeg = 0f
        pitchDeg = 1.0f
        rollDeg = -2.0f
        shaftRpmPort = 180f
        shaftRpmStbd = 180f
        boilerPressureBar = 42.0f
        coolantTempC = 82f
        lubeOilPressureBar = 4.2f
        fuelRemainingPct = 84f
        busVoltageV = 440f
        generatorKw = 3200f
        bilgeLevelB1Pct = 0f
        emergencyPumpActive = false
        seaState = 4
        windSpeedKts = 22f
        windDirectionDeg = 110f
        waterDepthM = 48f
        activeFaults.clear()
        alertList.clear()
    }

    override fun injectFault(fault: FaultInjection) {
        activeFaults[fault.id] = fault
        if (!alertList.contains(fault.title)) {
            alertList.add(fault.title)
        }
    }

    override fun clearFault(faultId: String) {
        activeFaults.remove(faultId)?.let {
            alertList.remove(it.title)
        }
    }

    fun toggleEmergencyPump(active: Boolean) {
        emergencyPumpActive = active
    }

    override fun step(
        deltaTimeSec: Float,
        throttleInput: Float, // 0.0 to 1.0 (Telegraph setting)
        steeringInput: Float, // -1.0 (Port) to +1.0 (Starboard)
        secondaryInput: Float // Trim / Auxiliary control
    ) {
        val dt = deltaTimeSec.coerceIn(0.001f, 0.1f)
        simulationTimeSec += dt

        // 1. Propulsion Dynamics (High inertia ship dynamics)
        val targetRpm = throttleInput * 250f
        val rpmLagFactor = 0.35f * dt
        shaftRpmPort += (targetRpm - shaftRpmPort) * rpmLagFactor
        shaftRpmStbd += (targetRpm - shaftRpmStbd) * rpmLagFactor

        // Port shaft bearing fault impact
        if (activeFaults.containsKey("NV_PROP_COOL")) {
            coolantTempC = (coolantTempC + 1.8f * dt).coerceAtMost(96f)
            lubeOilPressureBar = (lubeOilPressureBar - 0.2f * dt).coerceAtLeast(1.9f)
            shaftRpmPort = shaftRpmPort.coerceAtMost(140f)
        } else {
            coolantTempC += (82f - coolantTempC) * 0.1f * dt
            lubeOilPressureBar += (4.2f - lubeOilPressureBar) * 0.1f * dt
        }

        // Speed through water: F = mass * a, quadratic water resistance
        val averageRpm = (shaftRpmPort + shaftRpmStbd) / 2f
        val targetSpeed = (averageRpm / 250f) * 31.5f
        val speedLagFactor = 0.12f * dt
        speedKnots += (targetSpeed - speedKnots) * speedLagFactor
        speedKnots = speedKnots.coerceIn(0f, 32f)

        // 2. Rudder & Heading Dynamics
        val targetRudder = steeringInput * 35f // Max 35 degrees rudder
        rudderAngleDeg += (targetRudder - rudderAngleDeg) * 1.5f * dt
        // Turning rate is proportional to rudder angle and ship speed
        val turnRate = (rudderAngleDeg / 35f) * (speedKnots / 30f) * 1.2f // deg/sec
        headingDeg = (headingDeg + turnRate * dt + 360f) % 360f

        // 3. Sea State & Hydrodynamic Pitch / Roll Oscillations
        val waveFreq = 0.8f + (seaState * 0.1f)
        val waveAmpPitch = seaState * 0.7f
        val waveAmpRoll = seaState * 1.5f
        pitchDeg = waveAmpPitch * sin(simulationTimeSec * waveFreq) + (speedKnots * 0.05f)
        rollDeg = waveAmpRoll * cos(simulationTimeSec * waveFreq * 0.7f) - (turnRate * 1.8f)

        // 4. Electrical System
        if (activeFaults.containsKey("NV_GEN_DEG")) {
            busVoltageV = (busVoltageV - 4.5f * dt).coerceAtLeast(406f)
            generatorKw = 2650f
        } else {
            busVoltageV += (440f - busVoltageV) * 0.2f * dt
            generatorKw = 3100f + (throttleInput * 250f)
        }

        // 5. Bilge & Flooding Dynamics (Compartment B1)
        if (activeFaults.containsKey("NV_FLOOD_B1")) {
            val ingressRate = 1.4f * dt // % per sec
            val pumpDischarge = if (emergencyPumpActive) 2.2f * dt else 0f
            bilgeLevelB1Pct = (bilgeLevelB1Pct + ingressRate - pumpDischarge).coerceIn(0f, 100f)
            if (bilgeLevelB1Pct > 15f && !alertList.contains("B1 HIGH BILGE LEVEL")) {
                alertList.add("B1 HIGH BILGE LEVEL")
            }
        } else {
            if (emergencyPumpActive && bilgeLevelB1Pct > 0f) {
                bilgeLevelB1Pct = (bilgeLevelB1Pct - 3f * dt).coerceAtLeast(0f)
                if (bilgeLevelB1Pct == 0f) alertList.remove("B1 HIGH BILGE LEVEL")
            }
        }

        // Fuel burn
        val burnRate = (speedKnots / 30f) * 0.005f * dt
        fuelRemainingPct = (fuelRemainingPct - burnRate).coerceAtLeast(5f)
    }

    override fun getTelemetry(): TelemetryPacket {
        val overallIntegrity = (100f - (bilgeLevelB1Pct * 0.35f) - (activeFaults.size * 6f)).coerceIn(10f, 100f)
        val caution = activeFaults.values.any { it.severity == SystemStatus.CAUTION } || bilgeLevelB1Pct > 20f
        val warning = activeFaults.values.any { it.severity == SystemStatus.WARNING } || bilgeLevelB1Pct > 50f

        return TelemetryPacket(
            timestampMs = System.currentTimeMillis(),
            simulationTimeSec = simulationTimeSec,
            vehicleType = VehicleType.NAVAL,
            speed = speedKnots,
            headingDeg = headingDeg,
            altitudeOrDepth = waterDepthM,
            pitchDeg = pitchDeg,
            rollDeg = rollDeg,
            rateOfTurnDegPerSec = (rudderAngleDeg / 35f) * (speedKnots / 30f) * 1.2f,
            engineRpm = (shaftRpmPort + shaftRpmStbd) / 2f,
            engineLoadPct = ((shaftRpmPort + shaftRpmStbd) / 500f) * 100f,
            coolantTempC = coolantTempC,
            oilPressureBar = lubeOilPressureBar,
            fuelRemainingPct = fuelRemainingPct,
            fuelFlowRate = (speedKnots * 45f) + 300f,
            busVoltageV = busVoltageV,
            powerGeneratedKw = generatorKw,
            batteryReservePct = 96f,
            hydraulicPressurePsi = 2200f,
            overallIntegrityPct = overallIntegrity,
            ambientTempC = 14f,
            seaStateOrTerrainIndex = seaState,
            customMetrics = mapOf(
                "shaftRpmPort" to shaftRpmPort,
                "shaftRpmStbd" to shaftRpmStbd,
                "boilerPressureBar" to boilerPressureBar,
                "rudderAngleDeg" to rudderAngleDeg,
                "bilgeLevelB1Pct" to bilgeLevelB1Pct,
                "windSpeedKts" to windSpeedKts,
                "windDirectionDeg" to windDirectionDeg
            ),
            activeAlerts = alertList.toList(),
            masterCautionActive = caution,
            masterWarningActive = warning
        )
    }

    override fun getSubsystems(): List<SubsystemHealth> {
        val b1Status = when {
            bilgeLevelB1Pct > 40f -> SystemStatus.WARNING
            bilgeLevelB1Pct > 10f -> SystemStatus.CAUTION
            else -> SystemStatus.NORMAL
        }
        val genStatus = if (activeFaults.containsKey("NV_GEN_DEG")) SystemStatus.CAUTION else SystemStatus.NORMAL
        val propStatus = if (activeFaults.containsKey("NV_PROP_COOL")) SystemStatus.CAUTION else SystemStatus.NORMAL

        return listOf(
            SubsystemHealth(
                id = "nv_prop_shaft",
                name = "Port/Starboard Steam Turbine Shafts",
                category = SubsystemCategory.PROPULSION,
                status = propStatus,
                currentValue = (shaftRpmPort + shaftRpmStbd) / 2f,
                unit = "RPM",
                expectedMin = 60f,
                expectedMax = 250f,
                warningThreshold = 265f,
                criticalThreshold = 280f,
                diagnosticSummary = if (propStatus == SystemStatus.CAUTION) "Port shaft bearing temperature high (94°C). Lubrication flow restricted." else "Twin propeller shafts synchronized and running within normal limits.",
                trainingRecommendation = if (propStatus == SystemStatus.CAUTION) "Reduce port engine telegraph to Half Ahead; check sea-strainer." else "Continue standard underway watch."
            ),
            SubsystemHealth(
                id = "nv_elec_gen2",
                name = "Ship Service Diesel Generator 2 (440V)",
                category = SubsystemCategory.ELECTRICAL,
                status = genStatus,
                currentValue = busVoltageV,
                unit = "V",
                expectedMin = 430f,
                expectedMax = 445f,
                warningThreshold = 415f,
                criticalThreshold = 390f,
                diagnosticSummary = if (genStatus == SystemStatus.CAUTION) "Generator 2 governor hunting; bus voltage degraded to ${busVoltageV.toInt()}V." else "440V 60Hz 3-phase bus stable with 3.2 MW reserve capacity.",
                trainingRecommendation = if (genStatus == SystemStatus.CAUTION) "Shed secondary hotel loads and parallel GT Gen 3." else "Nominal generation distribution."
            ),
            SubsystemHealth(
                id = "nv_hull_b1",
                name = "Compartment B1 Engine Room Bilge",
                category = SubsystemCategory.HULL_INTEGRITY,
                status = b1Status,
                currentValue = bilgeLevelB1Pct,
                unit = "%",
                expectedMin = 0f,
                expectedMax = 5f,
                warningThreshold = 15f,
                criticalThreshold = 45f,
                diagnosticSummary = if (bilgeLevelB1Pct > 5f) "Ingress detected at sea-chest valve. Bilge water at ${bilgeLevelB1Pct.toInt()}%." else "All watertight bulkheads sealed; bilges dry.",
                trainingRecommendation = if (bilgeLevelB1Pct > 5f) "Start Emergency Bilge Pump 2 and isolate sea valve." else "Maintain standard watertight integrity."
            ),
            SubsystemHealth(
                id = "nv_nav_gyro",
                name = "Master Gyrocompass & Inertial Nav",
                category = SubsystemCategory.NAVIGATION,
                status = SystemStatus.NORMAL,
                currentValue = headingDeg,
                unit = "°",
                expectedMin = 0f,
                expectedMax = 360f,
                warningThreshold = 365f,
                criticalThreshold = 370f,
                diagnosticSummary = "Dual ring-laser gyrocompass synchronized with GPS compass backup.",
                trainingRecommendation = "Course steady on ${headingDeg.toInt()}°."
            )
        )
    }
}
