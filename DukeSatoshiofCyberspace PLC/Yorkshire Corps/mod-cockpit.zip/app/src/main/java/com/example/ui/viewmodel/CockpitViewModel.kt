package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.CockpitLayoutMode
import com.example.core.model.FaultInjection
import com.example.core.model.ScenarioCatalog
import com.example.core.model.StandardFaults
import com.example.core.model.SubsystemHealth
import com.example.core.model.TelemetryPacket
import com.example.core.model.TrainingScenario
import com.example.core.model.VehicleProfile
import com.example.core.model.VehicleRegistry
import com.example.core.model.VehicleType
import com.example.core.simulation.ArmouredSimulation
import com.example.core.simulation.AviationSimulation
import com.example.core.simulation.NavalSimulation
import com.example.core.simulation.VehicleSimulation
import com.example.core.storage.CockpitDatabase
import com.example.core.storage.SessionRecordEntity
import com.example.core.storage.SessionRepository
import com.example.core.storage.TelemetrySampleEntity
import com.example.ui.cockpit.render.VisualizerViewMode
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CockpitViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SessionRepository

    // Active Simulations
    private val navalSim = NavalSimulation()
    private val armouredSim = ArmouredSimulation()
    private val aviationSim = AviationSimulation()
    private var currentSim: VehicleSimulation = navalSim

    // UI States
    private val _selectedVehicleType = MutableStateFlow(VehicleType.NAVAL)
    val selectedVehicleType: StateFlow<VehicleType> = _selectedVehicleType.asStateFlow()

    private val _telemetry = MutableStateFlow(TelemetryPacket.defaultFor(VehicleType.NAVAL))
    val telemetry: StateFlow<TelemetryPacket> = _telemetry.asStateFlow()

    private val _subsystems = MutableStateFlow<List<SubsystemHealth>>(emptyList())
    val subsystems: StateFlow<List<SubsystemHealth>> = _subsystems.asStateFlow()

    private val _layoutMode = MutableStateFlow(CockpitLayoutMode.SPLIT_VIEW)
    val layoutMode: StateFlow<CockpitLayoutMode> = _layoutMode.asStateFlow()

    private val _visualizerViewMode = MutableStateFlow(VisualizerViewMode.CHASE)
    val visualizerViewMode: StateFlow<VisualizerViewMode> = _visualizerViewMode.asStateFlow()

    // Control Inputs
    private val _throttle = MutableStateFlow(0.65f)
    val throttle: StateFlow<Float> = _throttle.asStateFlow()

    private val _steering = MutableStateFlow(0.0f)
    val steering: StateFlow<Float> = _steering.asStateFlow()

    private val _secondary = MutableStateFlow(0.0f)
    val secondary: StateFlow<Float> = _secondary.asStateFlow()

    // Subsystem toggle flags
    private val _subsystem1Active = MutableStateFlow(false)
    val subsystem1Active: StateFlow<Boolean> = _subsystem1Active.asStateFlow()

    private val _subsystem2Active = MutableStateFlow(false)
    val subsystem2Active: StateFlow<Boolean> = _subsystem2Active.asStateFlow()

    // Active Scenario
    private val _activeScenario = MutableStateFlow<TrainingScenario?>(null)
    val activeScenario: StateFlow<TrainingScenario?> = _activeScenario.asStateFlow()

    private val _scenarioElapsedSec = MutableStateFlow(0)
    val scenarioElapsedSec: StateFlow<Int> = _scenarioElapsedSec.asStateFlow()

    private val _scenarioScore = MutableStateFlow(100)
    val scenarioScore: StateFlow<Int> = _scenarioScore.asStateFlow()

    private val _scenarioDebrief = MutableStateFlow<String?>(null)
    val scenarioDebrief: StateFlow<String?> = _scenarioDebrief.asStateFlow()

    // Historical records from Room
    val pastSessions: StateFlow<List<SessionRecordEntity>>

    // Live Chart Histories
    private val _speedHistory = MutableStateFlow<List<Float>>(emptyList())
    val speedHistory: StateFlow<List<Float>> = _speedHistory.asStateFlow()

    private val _rpmHistory = MutableStateFlow<List<Float>>(emptyList())
    val rpmHistory: StateFlow<List<Float>> = _rpmHistory.asStateFlow()

    private val _tempHistory = MutableStateFlow<List<Float>>(emptyList())
    val tempHistory: StateFlow<List<Float>> = _tempHistory.asStateFlow()

    private val _powerHistory = MutableStateFlow<List<Float>>(emptyList())
    val powerHistory: StateFlow<List<Float>> = _powerHistory.asStateFlow()

    // Telemetry Recording Buffer
    private val recordingBuffer = mutableListOf<TelemetryPacket>()
    private val _isRecording = MutableStateFlow(true)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    // Replay mode state
    private val _isReplayMode = MutableStateFlow(false)
    val isReplayMode: StateFlow<Boolean> = _isReplayMode.asStateFlow()

    private val _replaySamples = MutableStateFlow<List<TelemetrySampleEntity>>(emptyList())
    val replaySamples: StateFlow<List<TelemetrySampleEntity>> = _replaySamples.asStateFlow()

    private val _replayScrubIndex = MutableStateFlow(0)
    val replayScrubIndex: StateFlow<Int> = _replayScrubIndex.asStateFlow()

    private var simLoopJob: Job? = null

    init {
        val db = CockpitDatabase.getDatabase(application)
        repository = SessionRepository(db.sessionDao())
        pastSessions = repository.allSessions.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        viewModelScope.launch {
            repository.ensureInitialSeedData()
        }

        switchVehicle(VehicleType.NAVAL)
        startSimulationLoop()
    }

    fun switchVehicle(type: VehicleType) {
        _selectedVehicleType.value = type
        currentSim = when (type) {
            VehicleType.NAVAL -> navalSim
            VehicleType.ARMOURED -> armouredSim
            VehicleType.AVIATION -> aviationSim
        }
        _throttle.value = if (type == VehicleType.AVIATION) 0.72f else 0.60f
        _steering.value = 0.0f
        _secondary.value = 0.0f
        _subsystem1Active.value = false
        _subsystem2Active.value = false
        _activeScenario.value = null
        _scenarioDebrief.value = null
        recordingBuffer.clear()
        _speedHistory.value = emptyList()
        _rpmHistory.value = emptyList()
        _tempHistory.value = emptyList()
        _powerHistory.value = emptyList()

        currentSim.initialize(null)
        updateStates()
    }

    fun setThrottle(value: Float) {
        _throttle.value = value.coerceIn(0f, 1f)
    }

    fun setSteering(value: Float) {
        _steering.value = value.coerceIn(-1f, 1f)
    }

    fun setSecondary(value: Float) {
        _secondary.value = value
    }

    fun setLayoutMode(mode: CockpitLayoutMode) {
        _layoutMode.value = mode
    }

    fun setVisualizerViewMode(mode: VisualizerViewMode) {
        _visualizerViewMode.value = mode
    }

    fun toggleSubsystem1() {
        val next = !_subsystem1Active.value
        _subsystem1Active.value = next
        when (currentSim) {
            is NavalSimulation -> (currentSim as NavalSimulation).toggleEmergencyPump(next)
            is ArmouredSimulation -> (currentSim as ArmouredSimulation).toggleRadiatorBypass(next)
            is AviationSimulation -> (currentSim as AviationSimulation).toggleHydCircuitA(next)
        }
    }

    fun toggleSubsystem2() {
        val next = !_subsystem2Active.value
        _subsystem2Active.value = next
        when (currentSim) {
            is NavalSimulation -> { /* auxiliary generator lock */ }
            is ArmouredSimulation -> (currentSim as ArmouredSimulation).toggleApu(next)
            is AviationSimulation -> (currentSim as AviationSimulation).togglePitotHeat(next)
        }
    }

    fun injectFault(fault: FaultInjection) {
        currentSim.injectFault(fault)
        updateStates()
    }

    fun clearFault(faultId: String) {
        currentSim.clearFault(faultId)
        updateStates()
    }

    fun startScenario(scenario: TrainingScenario) {
        if (_selectedVehicleType.value != scenario.vehicleType) {
            switchVehicle(scenario.vehicleType)
        }
        _activeScenario.value = scenario
        _scenarioElapsedSec.value = 0
        _scenarioScore.value = 100
        _scenarioDebrief.value = null
        currentSim.initialize(scenario)
        updateStates()
    }

    fun endScenario() {
        val scen = _activeScenario.value ?: return
        val score = _scenarioScore.value
        val passed = score >= scen.passingScore
        val debrief = "Mission '${scen.title}' ${if (passed) "COMPLETED" else "FAILED"}. Final Score: $score / 100. Target Duration: ${scen.targetDurationSec}s. Objectives assessed against simulated flight envelope standards."
        _scenarioDebrief.value = debrief

        // Record in Room Database
        viewModelScope.launch {
            repository.recordCompletedSession(
                vehicleType = scen.vehicleType.name,
                callsign = VehicleRegistry.getProfile(scen.vehicleType).callsign,
                scenarioTitle = scen.title,
                durationSeconds = _scenarioElapsedSec.value,
                scoreAchieved = score,
                passed = passed,
                faultsCount = if (scen.initialFaultId != null) 1 else 0,
                samples = recordingBuffer.toList()
            )
        }
    }

    fun startReplaySession(session: SessionRecordEntity) {
        viewModelScope.launch {
            val samples = repository.getSamplesForSession(session.id)
            if (samples.isNotEmpty()) {
                _replaySamples.value = samples
                _replayScrubIndex.value = 0
                _isReplayMode.value = true
            }
        }
    }

    fun scrubReplay(index: Int) {
        val samples = _replaySamples.value
        if (samples.isNotEmpty()) {
            val clamped = index.coerceIn(0, samples.size - 1)
            _replayScrubIndex.value = clamped
            val s = samples[clamped]
            // Update preview telemetry
            _telemetry.value = _telemetry.value.copy(
                speed = s.speed,
                headingDeg = s.headingDeg,
                altitudeOrDepth = s.altitudeOrDepth,
                pitchDeg = s.pitchDeg,
                rollDeg = s.rollDeg,
                engineRpm = s.engineRpm,
                coolantTempC = s.coolantTempC,
                powerGeneratedKw = s.powerGeneratedKw,
                overallIntegrityPct = s.integrityPct
            )
        }
    }

    fun exitReplayMode() {
        _isReplayMode.value = false
        _replaySamples.value = emptyList()
    }

    fun acknowledgeAlerts() {
        // Ack logic
    }

    private fun startSimulationLoop() {
        simLoopJob?.cancel()
        simLoopJob = viewModelScope.launch {
            var lastTick = System.currentTimeMillis()
            var secondAccumulator = 0f

            while (true) {
                val now = System.currentTimeMillis()
                val dt = ((now - lastTick) / 1000f).coerceIn(0.01f, 0.05f)
                lastTick = now

                if (!_isReplayMode.value) {
                    currentSim.step(
                        deltaTimeSec = dt,
                        throttleInput = _throttle.value,
                        steeringInput = _steering.value,
                        secondaryInput = _secondary.value
                    )
                    updateStates()

                    // Scenario timer tick
                    secondAccumulator += dt
                    if (secondAccumulator >= 1.0f) {
                        secondAccumulator -= 1.0f
                        if (_activeScenario.value != null && _scenarioDebrief.value == null) {
                            _scenarioElapsedSec.value += 1
                            // Check score deductions if system warnings active
                            val telem = _telemetry.value
                            if (telem.masterWarningActive) {
                                _scenarioScore.value = (_scenarioScore.value - 1).coerceAtLeast(10)
                            }
                            if (_scenarioElapsedSec.value >= (_activeScenario.value?.targetDurationSec ?: 180)) {
                                endScenario()
                            }
                        }
                    }
                }

                delay(33) // ~30 Hz tick rate
            }
        }
    }

    private fun updateStates() {
        val pkt = currentSim.getTelemetry()
        _telemetry.value = pkt
        _subsystems.value = currentSim.getSubsystems()

        // Append to charts (keep last 50 points)
        val maxPoints = 50
        _speedHistory.value = (_speedHistory.value + pkt.speed).takeLast(maxPoints)
        _rpmHistory.value = (_rpmHistory.value + pkt.engineRpm).takeLast(maxPoints)
        _tempHistory.value = (_tempHistory.value + pkt.coolantTempC).takeLast(maxPoints)
        _powerHistory.value = (_powerHistory.value + pkt.powerGeneratedKw).takeLast(maxPoints)

        if (_isRecording.value) {
            recordingBuffer.add(pkt)
            if (recordingBuffer.size > 500) {
                recordingBuffer.removeAt(0)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        simLoopJob?.cancel()
    }
}
