package com.example.core.model

enum class CockpitLayoutMode(val label: String, val iconName: String) {
    FULL_COCKPIT("Full Viewport", "Fullscreen"),
    SPLIT_VIEW("Split Cockpit", "Dashboard"),
    ENGINEERING_VIEW("Engineering", "Build"),
    INSTRUCTOR_VIEW("Instructor", "School")
}

data class TrainingScenario(
    val id: String,
    val title: String,
    val vehicleType: VehicleType,
    val description: String,
    val difficulty: String,
    val targetDurationSec: Int,
    val environmentDescription: String,
    val objectives: List<String>,
    val passingScore: Int,
    val initialFaultId: String? = null
)

object ScenarioCatalog {
    val scenarios = listOf(
        // Naval Scenarios
        TrainingScenario(
            id = "NV_SCEN_01",
            title = "Heavy Sea Station-Keeping & Heading Control",
            vehicleType = VehicleType.NAVAL,
            description = "Maintain a steady heading of 245° through Sea State 5 wind shear and heavy Atlantic swell.",
            difficulty = "Moderate",
            targetDurationSec = 180,
            environmentDescription = "Sea State 5, 28-knot crosswind, rolling swell.",
            objectives = listOf(
                "Maintain heading 245° within ±5° tolerance",
                "Keep speed through water above 18 knots without boiler overload",
                "Monitor bilge levels and balance propulsion shaft RPM"
            ),
            passingScore = 80
        ),
        TrainingScenario(
            id = "NV_SCEN_02",
            title = "Engine Room Bilge Ingress & Damage Control",
            vehicleType = VehicleType.NAVAL,
            description = "Respond to sudden water ingress in Compartment B1 Engine Room while underway.",
            difficulty = "Advanced",
            targetDurationSec = 240,
            environmentDescription = "Sea State 4, reduced visibility, underway at 20 kts.",
            objectives = listOf(
                "Identify and acknowledge Compartment B1 flooding alert within 15 seconds",
                "Activate Emergency Drainage Bilge Pump 2",
                "Reduce speed to prevent hydraulic dynamic hull pressure on forward bulkheads",
                "Maintain ship electrical generation above 3,000 kW"
            ),
            passingScore = 85,
            initialFaultId = "NV_FLOOD_B1"
        ),

        // Armoured Scenarios
        TrainingScenario(
            id = "AR_SCEN_01",
            title = "Cross-Country Slope Stability & Powertrain Handling",
            vehicleType = VehicleType.ARMOURED,
            description = "Traverse a simulated rough terrain course, managing engine torque and slope inclination.",
            difficulty = "Moderate",
            targetDurationSec = 150,
            environmentDescription = "Rough sand and gravel, 18° transverse slope inclination.",
            objectives = listOf(
                "Keep vehicle speed between 25 and 45 km/h",
                "Prevent engine over-revving beyond 2600 RPM on steep inclines",
                "Maintain roll angle under 15° to prevent track de-beading",
                "Monitor transmission oil temp under 110°C"
            ),
            passingScore = 80
        ),
        TrainingScenario(
            id = "AR_SCEN_02",
            title = "Cooling System Degradation & Thermal Management",
            vehicleType = VehicleType.ARMOURED,
            description = "A hydraulic radiator fan leak triggers rising engine coolant temperature during an approach.",
            difficulty = "Advanced",
            targetDurationSec = 210,
            environmentDescription = "Desert heat 38°C ambient, broken gravel terrain.",
            objectives = listOf(
                "Detect coolant temperature warning above 105°C",
                "Throttle back and downshift to lower engine thermal load",
                "Engage secondary auxiliary radiator bypass",
                "Safely park vehicle in defilade before catastrophic thermal derate"
            ),
            passingScore = 85,
            initialFaultId = "AR_COOL_PUMP"
        ),

        // Aviation Scenarios
        TrainingScenario(
            id = "AV_SCEN_01",
            title = "High-Altitude Level Flight & Mach Stability",
            vehicleType = VehicleType.AVIATION,
            description = "Maintain smooth flight envelope at 25,000 feet, cruising at Mach 0.75 without stall or over-G.",
            difficulty = "Beginner",
            targetDurationSec = 120,
            environmentDescription = "FL250, thin atmosphere, clear skies, light turbulence.",
            objectives = listOf(
                "Hold altitude 24,500 - 25,500 ft within ±200 ft",
                "Maintain airspeed 400 - 440 knots (Mach 0.72 - 0.78)",
                "Keep G-load within 0.8G to 1.4G envelope",
                "Scan and verify primary engine and hydraulic parameters"
            ),
            passingScore = 80
        ),
        TrainingScenario(
            id = "AV_SCEN_02",
            title = "Hydraulic System A Failure & Recovery",
            vehicleType = VehicleType.AVIATION,
            description = "Hydraulic Circuit A depressurizes at 22,000 ft. Manage flight controls and safely trim the aircraft.",
            difficulty = "Advanced",
            targetDurationSec = 180,
            environmentDescription = "FL220, dense cloud layer, moderate chop.",
            objectives = listOf(
                "Acknowledge Master Caution alert within 10 seconds",
                "Isolate Hydraulic Line A to conserve reserve fluid",
                "Verify Circuit B maintains 3,000 psi to all primary flight surfaces",
                "Trim aircraft for level descent without exceeding 30° bank angle"
            ),
            passingScore = 90,
            initialFaultId = "AV_HYD_A_LEAK"
        )
    )

    fun getScenariosFor(type: VehicleType): List<TrainingScenario> {
        return scenarios.filter { it.vehicleType == type }
    }
}
