package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CockpitColorScheme = darkColorScheme(
    primary = TechnicalBlue,
    onPrimary = InstrumentBlack,
    primaryContainer = DeepGraphite,
    onPrimaryContainer = CoolWhite,
    secondary = Titanium,
    onSecondary = Obsidian,
    secondaryContainer = DeepGraphite,
    onSecondaryContainer = CoolWhite,
    tertiary = AmberWarning,
    onTertiary = InstrumentBlack,
    background = Obsidian,
    onBackground = CoolWhite,
    surface = DeepGraphite,
    onSurface = CoolWhite,
    surfaceVariant = InstrumentBlack,
    onSurfaceVariant = Titanium,
    outline = TacticalPanelBorder,
    error = CriticalRed,
    onError = InstrumentBlack
)

@Composable
fun ModCockpitTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CockpitColorScheme,
        typography = Typography,
        content = content
    )
}
