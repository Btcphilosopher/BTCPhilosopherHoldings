package com.example.core.model

data class TelemetryPacket(
    val timestampMs: Long,
    val simulationTimeSec: Float,
    val vehicleType: VehicleType,
    // Motion & Navigation
    val speed: Float,            // Knots (Naval), km/h (Armoured), Knots IAS (Aviation)
    val headingDeg: Float,       // 0 - 360
    val altitudeOrDepth: Float,  // Feet (Aviation), Water Depth m (Naval), Altitude m (Armoured)
    val pitchDeg: Float,         // -90 to +90
    val rollDeg: Float,          // -180 to +180
    val rateOfTurnDegPerSec: Float,

    // Powertrain & Engine
    val engineRpm: Float,
    val engineLoadPct: Float,
    val coolantTempC: Float,
    val oilPressureBar: Float,
    val fuelRemainingPct: Float,
    val fuelFlowRate: Float,

    // Electrical & Aux
    val busVoltageV: Float,
    val powerGeneratedKw: Float,
    val batteryReservePct: Float,
    val hydraulicPressurePsi: Float,

    // Damage & Environmental
    val overallIntegrityPct: Float,
    val ambientTempC: Float,
    val seaStateOrTerrainIndex: Int, // 1 to 7

    // Specific metrics map
    val customMetrics: Map<String, Float> = emptyMap(),
    // Active diagnostic alerts
    val activeAlerts: List<String> = emptyList(),
    // Critical master caution/warning states
    val masterCautionActive: Boolean = false,
    val masterWarningActive: Boolean = false
) {
    companion object {
        fun defaultFor(type: VehicleType): TelemetryPacket {
            return when (type) {
                VehicleType.NAVAL -> TelemetryPacket(
                    timestampMs = System.currentTimeMillis(),
                    simulationTimeSec = 0f,
                    vehicleType = VehicleType.NAVAL,
                    speed = 18.5f,
                    headingDeg = 245f,
                    altitudeOrDepth = 48.0f,
                    pitchDeg = 1.2f,
                    rollDeg = -2.5f,
                    rateOfTurnDegPerSec = 0.0f,
                    engineRpm = 180f,
                    engineLoadPct = 65f,
                    coolantTempC = 82f,
                    oilPressureBar = 4.2f,
                    fuelRemainingPct = 84f,
                    fuelFlowRate = 1250f,
                    busVoltageV = 440f,
                    powerGeneratedKw = 3200f,
                    batteryReservePct = 96f,
                    hydraulicPressurePsi = 2200f,
                    overallIntegrityPct = 98f,
                    ambientTempC = 14f,
                    seaStateOrTerrainIndex = 3,
                    customMetrics = mapOf(
                        "shaftRpmPort" to 182f,
                        "shaftRpmStbd" to 179f,
                        "thrustKn" to 680f,
                        "compartmentFloodingPct" to 0f,
                        "windSpeedKts" to 18f,
                        "windDirectionDeg" to 110f
                    )
                )
                VehicleType.ARMOURED -> TelemetryPacket(
                    timestampMs = System.currentTimeMillis(),
                    simulationTimeSec = 0f,
                    vehicleType = VehicleType.ARMOURED,
                    speed = 34.0f,
                    headingDeg = 045f,
                    altitudeOrDepth = 310f,
                    pitchDeg = 3.8f,
                    rollDeg = 1.5f,
                    rateOfTurnDegPerSec = 0.0f,
                    engineRpm = 1950f,
                    engineLoadPct = 58f,
                    coolantTempC = 91f,
                    oilPressureBar = 4.8f,
                    fuelRemainingPct = 78f,
                    fuelFlowRate = 42f,
                    busVoltageV = 27.8f,
                    powerGeneratedKw = 18.5f,
                    batteryReservePct = 94f,
                    hydraulicPressurePsi = 1800f,
                    overallIntegrityPct = 95f,
                    ambientTempC = 19f,
                    seaStateOrTerrainIndex = 2,
                    customMetrics = mapOf(
                        "gearSelection" to 4f,
                        "suspensionDeflectionMm" to 120f,
                        "trackTensionKn" to 45f,
                        "trackSlipPct" to 4.2f,
                        "apuStatus" to 1f,
                        "exhaustTempC" to 540f
                    )
                )
                VehicleType.AVIATION -> TelemetryPacket(
                    timestampMs = System.currentTimeMillis(),
                    simulationTimeSec = 0f,
                    vehicleType = VehicleType.AVIATION,
                    speed = 420.0f,
                    headingDeg = 310f,
                    altitudeOrDepth = 24500f,
                    pitchDeg = 2.0f,
                    rollDeg = 0.0f,
                    rateOfTurnDegPerSec = 0.0f,
                    engineRpm = 92f,
                    engineLoadPct = 76f,
                    coolantTempC = 740f, // Turbine inlet temp
                    oilPressureBar = 3.5f,
                    fuelRemainingPct = 68f,
                    fuelFlowRate = 3400f,
                    busVoltageV = 115f,
                    powerGeneratedKw = 90f,
                    batteryReservePct = 99f,
                    hydraulicPressurePsi = 3050f,
                    overallIntegrityPct = 99f,
                    ambientTempC = -32f,
                    seaStateOrTerrainIndex = 1,
                    customMetrics = mapOf(
                        "machNumber" to 0.74f,
                        "verticalSpeedFpm" to 0f,
                        "gLoad" to 1.0f,
                        "angleOfAttackDeg" to 4.1f,
                        "hydCircuitA" to 3040f,
                        "hydCircuitB" to 3020f,
                        "flightControlLimiter" to 1f
                    )
                )
            }
        }
    }
}
