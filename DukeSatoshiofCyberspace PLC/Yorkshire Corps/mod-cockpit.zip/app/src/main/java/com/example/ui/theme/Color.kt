package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// British Defence Engineering Colour Palette
val Obsidian = Color(0xFF101317)       // Primary background
val DeepGraphite = Color(0xFF1A2026)   // Surface cards, panel containers
val InstrumentBlack = Color(0xFF080B0E)// Dark instrument faces, gauge wells
val Titanium = Color(0xFF737E89)        // Secondary text, technical labels, dividers
val TitaniumLight = Color(0xFF9EABB8)   // Active borders, highlighted ticks
val CoolWhite = Color(0xFFE7EBEE)       // Primary values, high contrast readouts
val MutedGreen = Color(0xFF83A78A)      // Normal operating condition, nominal status
val AmberWarning = Color(0xFFD5A24C)    // Caution state, elevated parameter
val CriticalRed = Color(0xFFD65A54)     // Critical threshold, emergency alert
val TechnicalBlue = Color(0xFF709AB9)   // HUD reticles, navigation, aviation accents

// Extended tactical palette
val TacticalPanelBorder = Color(0xFF28323D)
val TacticalGridLine = Color(0xFF1B242D)
val TacticalGlowBlue = Color(0x33709AB9)
val TacticalGlowAmber = Color(0x33D5A24C)
val TacticalGlowRed = Color(0x33D65A54)
val TacticalGlowGreen = Color(0x3383A78A)
