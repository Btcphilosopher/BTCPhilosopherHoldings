package com.example.core.simulation

import com.example.core.model.FaultInjection
import com.example.core.model.StandardFaults
import com.example.core.model.SubsystemCategory
import com.example.core.model.SubsystemHealth
import com.example.core.model.SystemStatus
import com.example.core.model.TelemetryPacket
import com.example.core.model.TrainingScenario
import com.example.core.model.VehicleProfile
import com.example.core.model.VehicleRegistry
import com.example.core.model.VehicleType
import kotlin.math.cos
import kotlin.math.sin

class AviationSimulation : VehicleSimulation {
    override val vehicleProfile: VehicleProfile = VehicleRegistry.getProfile(VehicleType.AVIATION)

    private var simulationTimeSec = 0f
    private var indicatedAirspeedKts = 420.0f
    private var altitudeFt = 24500f
    private var verticalSpeedFpm = 0f
    private var headingDeg = 310f
    private var pitchDeg = 2.0f
    private var rollDeg = 0.0f
    private var gLoad = 1.0f
    private var engineRpmPct = 92f
    private var turbineInletTempC = 740f
    private var fuelRemainingPct = 68f
    private var fuelFlowKgH = 3400f
    private var hydCircuitAPsi = 3050f
    private var hydCircuitBPsi = 3020f
    private var hydAIsolationActive = false
    private var pitotHeatActive = false
    private var fbwLimiterActive = true
    private var ambientTempC = -32f

    private val activeFaults = mutableMapOf<String, FaultInjection>()
    private val alertList = mutableListOf<String>()

    override fun initialize(scenario: TrainingScenario?) {
        reset()
        scenario?.initialFaultId?.let { faultId ->
            StandardFaults.faults.find { it.id == faultId }?.let { injectFault(it) }
        }
    }

    override fun reset() {
        simulationTimeSec = 0f
        indicatedAirspeedKts = 420.0f
        altitudeFt = 24500f
        verticalSpeedFpm = 0f
        headingDeg = 310f
        pitchDeg = 2.0f
        rollDeg = 0.0f
        gLoad = 1.0f
        engineRpmPct = 92f
        turbineInletTempC = 740f
        fuelRemainingPct = 68f
        fuelFlowKgH = 3400f
        hydCircuitAPsi = 3050f
        hydCircuitBPsi = 3020f
        hydAIsolationActive = false
        pitotHeatActive = false
        fbwLimiterActive = true
        ambientTempC = -32f
        activeFaults.clear()
        alertList.clear()
    }

    override fun injectFault(fault: FaultInjection) {
        activeFaults[fault.id] = fault
        if (!alertList.contains(fault.title)) {
            alertList.add(fault.title)
        }
    }

    override fun clearFault(faultId: String) {
        activeFaults.remove(faultId)?.let {
            alertList.remove(it.title)
        }
    }

    fun toggleHydCircuitA(isolate: Boolean) {
        hydAIsolationActive = isolate
    }

    fun togglePitotHeat(active: Boolean) {
        pitotHeatActive = active
    }

    override fun step(
        deltaTimeSec: Float,
        throttleInput: Float, // 0.0 to 1.0 (Throttle quadrant)
        steeringInput: Float, // -1.0 to +1.0 (Stick Roll / Bank)
        secondaryInput: Float // -1.0 to +1.0 (Stick Pitch: -1 nose down, +1 nose up)
    ) {
        val dt = deltaTimeSec.coerceIn(0.001f, 0.1f)
        simulationTimeSec += dt

        // 1. Engine & Thrust Dynamics
        val targetRpm = 65f + (throttleInput * 39f) // 65% to 104%
        engineRpmPct += (targetRpm - engineRpmPct) * 1.8f * dt

        // Turbine temp fault impact
        if (activeFaults.containsKey("AV_TIT_OVERHEAT")) {
            turbineInletTempC = (turbineInletTempC + 18f * dt).coerceAtMost(985f)
            if (turbineInletTempC > 880f && !alertList.contains("TURBINE INLET TEMP OVERHEAT")) {
                alertList.add("TURBINE INLET TEMP OVERHEAT")
            }
        } else {
            val normalTit = 620f + (engineRpmPct * 2.2f)
            turbineInletTempC += (normalTit - turbineInletTempC) * 0.8f * dt
            alertList.remove("TURBINE INLET TEMP OVERHEAT")
        }

        // 2. Flight Attitude Dynamics (Pitch & Roll)
        val pitchRate = secondaryInput * 18f // deg/sec
        val rollRate = steeringInput * 55f   // deg/sec
        
        pitchDeg = (pitchDeg + pitchRate * dt).coerceIn(-65f, 65f)
        rollDeg = ((rollDeg + rollRate * dt + 180f) % 360f) - 180f

        // Turn rate derived from bank angle and airspeed
        val bankRad = Math.toRadians(rollDeg.toDouble())
        val turnRateDegPerSec = (9.81 * kotlin.math.tan(bankRad) / (indicatedAirspeedKts * 0.5144)) * (180 / Math.PI)
        headingDeg = (headingDeg + turnRateDegPerSec.toFloat() * dt + 360f) % 360f

        // G-Load factor = 1 / cos(bank) + pitch rate effect
        val baseG = (1.0f / kotlin.math.cos(bankRad.toFloat()).coerceIn(0.2f, 1.0f))
        gLoad = (baseG + (pitchRate * 0.15f)).coerceIn(0.5f, 8.5f)

        // 3. Airspeed & Altitude Dynamics
        // Pitch modifies vertical speed: VVI = TAS * sin(pitch)
        verticalSpeedFpm = indicatedAirspeedKts * sin(Math.toRadians(pitchDeg.toDouble())).toFloat() * 101.2f
        altitudeFt = (altitudeFt + (verticalSpeedFpm / 60f) * dt).coerceIn(500f, 60000f)

        // Speed responds to thrust and pitch gravity component
        val targetSpeed = (engineRpmPct / 100f) * 620f - (pitchDeg * 3.5f)
        indicatedAirspeedKts += (targetSpeed - indicatedAirspeedKts) * 0.6f * dt
        indicatedAirspeedKts = indicatedAirspeedKts.coerceIn(140f, 850f)

        // 4. Hydraulic System Dynamics
        if (activeFaults.containsKey("AV_HYD_A_LEAK")) {
            if (!hydAIsolationActive) {
                hydCircuitAPsi = (hydCircuitAPsi - 180f * dt).coerceAtLeast(650f)
            }
            if (hydCircuitAPsi < 2000f && !alertList.contains("HYD CIRCUIT A LOW PRESS")) {
                alertList.add("HYD CIRCUIT A LOW PRESS")
            }
        } else {
            hydCircuitAPsi += (3050f - hydCircuitAPsi) * 0.5f * dt
            alertList.remove("HYD CIRCUIT A LOW PRESS")
        }
        hydCircuitBPsi = 3020f + 15f * sin(simulationTimeSec * 2f)

        // 5. Pitot moisture fault
        if (activeFaults.containsKey("AV_SENSOR_PITOT") && !pitotHeatActive) {
            if (!alertList.contains("AIRSPEED UNRELIABLE // PITOT ICE")) {
                alertList.add("AIRSPEED UNRELIABLE // PITOT ICE")
            }
        } else {
            alertList.remove("AIRSPEED UNRELIABLE // PITOT ICE")
        }

        // Fuel burn
        fuelFlowKgH = (engineRpmPct / 100f) * 4200f
        fuelRemainingPct = (fuelRemainingPct - (fuelFlowKgH / 10000f) * 0.005f * dt).coerceAtLeast(3f)
    }

    override fun getTelemetry(): TelemetryPacket {
        val overallIntegrity = (99f - (activeFaults.size * 9f) - (if (hydCircuitAPsi < 1800f) 10f else 0f)).coerceIn(20f, 100f)
        val caution = activeFaults.values.any { it.severity == SystemStatus.CAUTION } || hydCircuitAPsi < 2500f
        val warning = activeFaults.values.any { it.severity == SystemStatus.WARNING } || hydCircuitAPsi < 1500f || turbineInletTempC > 880f

        // Synthetic Mach number: M = TAS / a(alt)
        val speedOfSoundKts = 661.47f * kotlin.math.sqrt(((ambientTempC + 273.15f) / 288.15f).toDouble()).toFloat()
        val mach = (indicatedAirspeedKts / speedOfSoundKts.coerceAtLeast(500f)).coerceIn(0.2f, 2.3f)

        val displayedSpeed = if (activeFaults.containsKey("AV_SENSOR_PITOT") && !pitotHeatActive) {
            indicatedAirspeedKts - 55f
        } else {
            indicatedAirspeedKts
        }

        return TelemetryPacket(
            timestampMs = System.currentTimeMillis(),
            simulationTimeSec = simulationTimeSec,
            vehicleType = VehicleType.AVIATION,
            speed = displayedSpeed,
            headingDeg = headingDeg,
            altitudeOrDepth = altitudeFt,
            pitchDeg = pitchDeg,
            rollDeg = rollDeg,
            rateOfTurnDegPerSec = 0f,
            engineRpm = engineRpmPct,
            engineLoadPct = engineRpmPct,
            coolantTempC = turbineInletTempC,
            oilPressureBar = 3.5f,
            fuelRemainingPct = fuelRemainingPct,
            fuelFlowRate = fuelFlowKgH,
            busVoltageV = 115f,
            powerGeneratedKw = 90f,
            batteryReservePct = 99f,
            hydraulicPressurePsi = (hydCircuitAPsi + hydCircuitBPsi) / 2f,
            overallIntegrityPct = overallIntegrity,
            ambientTempC = ambientTempC,
            seaStateOrTerrainIndex = 1,
            customMetrics = mapOf(
                "machNumber" to mach,
                "verticalSpeedFpm" to verticalSpeedFpm,
                "gLoad" to gLoad,
                "hydCircuitA" to hydCircuitAPsi,
                "hydCircuitB" to hydCircuitBPsi,
                "hydAIsolated" to if (hydAIsolationActive) 1f else 0f,
                "pitotHeat" to if (pitotHeatActive) 1f else 0f
            ),
            activeAlerts = alertList.toList(),
            masterCautionActive = caution,
            masterWarningActive = warning
        )
    }

    override fun getSubsystems(): List<SubsystemHealth> {
        val hydStatus = when {
            hydCircuitAPsi < 1500f -> SystemStatus.WARNING
            hydCircuitAPsi < 2500f -> SystemStatus.CAUTION
            else -> SystemStatus.NORMAL
        }
        val engStatus = when {
            turbineInletTempC > 880f -> SystemStatus.WARNING
            turbineInletTempC > 800f -> SystemStatus.CAUTION
            else -> SystemStatus.NORMAL
        }
        val navStatus = if (activeFaults.containsKey("AV_SENSOR_PITOT") && !pitotHeatActive) SystemStatus.CAUTION else SystemStatus.NORMAL

        return listOf(
            SubsystemHealth(
                id = "av_hyd_circuit_a",
                name = "Flight Control Hydraulic Circuit A",
                category = SubsystemCategory.HYDRAULICS,
                status = hydStatus,
                currentValue = hydCircuitAPsi,
                unit = "PSI",
                expectedMin = 2800f,
                expectedMax = 3200f,
                warningThreshold = 2200f,
                criticalThreshold = 1500f,
                diagnosticSummary = if (hydStatus != SystemStatus.NORMAL) "System A manifold pressure loss. Backup Circuit B maintaining flight surface actuation." else "Dual hydraulic circuits pressurized at 3,000 psi.",
                trainingRecommendation = if (hydStatus != SystemStatus.NORMAL) "Isolate Circuit A isolation shutoff; avoid high-G aerodynamic loads." else "Flight controls fully responsive."
            ),
            SubsystemHealth(
                id = "av_eng_turbine",
                name = "Twin Low-Bypass Turbofans & Afterburner",
                category = SubsystemCategory.PROPULSION,
                status = engStatus,
                currentValue = turbineInletTempC,
                unit = "°C",
                expectedMin = 600f,
                expectedMax = 820f,
                warningThreshold = 860f,
                criticalThreshold = 920f,
                diagnosticSummary = if (engStatus != SystemStatus.NORMAL) "Turbine Inlet Temperature excursion. Thermal limiter active." else "Spool RPM ${engineRpmPct.toInt()}% N2; turbine thermal profile nominal.",
                trainingRecommendation = if (engStatus != SystemStatus.NORMAL) "Retard throttle lever; disengage reheat / afterburner." else "Thrust parameters within envelope."
            ),
            SubsystemHealth(
                id = "av_nav_pitot",
                name = "Air Data Computer & Pitot-Static Mast",
                category = SubsystemCategory.NAVIGATION,
                status = navStatus,
                currentValue = indicatedAirspeedKts,
                unit = "KTS",
                expectedMin = 150f,
                expectedMax = 750f,
                warningThreshold = 160f,
                criticalThreshold = 145f,
                diagnosticSummary = if (navStatus != SystemStatus.NORMAL) "Pitot mast moisture icing detected. Airspeed cross-check divergence." else "Triple-redundant air data sensors cross-checked and synchronized.",
                trainingRecommendation = if (navStatus != SystemStatus.NORMAL) "Switch Pitot Heat to HIGH; cross-check pitch/power." else "Nominal air data guidance."
            ),
            SubsystemHealth(
                id = "av_elec_gen",
                name = "Integrated Drive Generator (115V 400Hz)",
                category = SubsystemCategory.ELECTRICAL,
                status = SystemStatus.NORMAL,
                currentValue = 115f,
                unit = "V",
                expectedMin = 112f,
                expectedMax = 118f,
                warningThreshold = 108f,
                criticalThreshold = 102f,
                diagnosticSummary = "Variable-speed constant-frequency generator powering dual avionics buses.",
                trainingRecommendation = "Electrical generation nominal."
            )
        )
    }
}
