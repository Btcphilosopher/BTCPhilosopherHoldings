package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.storage.SessionRecordEntity
import com.example.core.storage.TelemetrySampleEntity
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoolWhite
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.InstrumentBlack
import com.example.ui.theme.MutedGreen
import com.example.ui.theme.TacticalPanelBorder
import com.example.ui.theme.TechnicalBlue
import com.example.ui.theme.Titanium
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RecordsScreen(
    sessions: List<SessionRecordEntity>,
    isReplayMode: Boolean,
    replaySamples: List<TelemetrySampleEntity>,
    scrubIndex: Int,
    onStartReplay: (SessionRecordEntity) -> Unit,
    onScrubReplay: (Int) -> Unit,
    onExitReplay: () -> Unit,
    onEnterCockpit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(InstrumentBlack)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            // Header
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "OPERATIONAL TRAINING RECORDS",
                        color = CoolWhite,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Box(
                        modifier = Modifier
                            .background(TechnicalBlue.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .border(1.dp, TechnicalBlue, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "${sessions.size} SESSIONS SAVED",
                            color = TechnicalBlue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Room-persisted telemetry recordings, historical score debriefs and multi-channel replay scrubber.",
                    color = Titanium,
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 11.sp
                )
            }
        }

        // Active Replay Scrubber Control Box
        if (isReplayMode && replaySamples.isNotEmpty()) {
            item {
                val currentSample = replaySamples.getOrNull(scrubIndex) ?: replaySamples[0]
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DeepGraphite, RoundedCornerShape(8.dp))
                        .border(1.5.dp, TechnicalBlue, RoundedCornerShape(8.dp))
                        .padding(14.dp)
                        .testTag("telemetry_replay_controller")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "LIVE TELEMETRY REPLAY SCRUBBER",
                                color = TechnicalBlue,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "OFFSET: ${currentSample.timeOffsetSec.toInt()}s  |  SAMPLE ${scrubIndex + 1} / ${replaySamples.size}",
                                color = CoolWhite,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        }

                        Button(
                            onClick = onExitReplay,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = InstrumentBlack,
                                contentColor = CoolWhite
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.border(1.dp, TacticalPanelBorder, RoundedCornerShape(4.dp))
                        ) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "EXIT", fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Replay Scrubber Slider
                    Slider(
                        value = scrubIndex.toFloat(),
                        onValueChange = { onScrubReplay(it.toInt()) },
                        valueRange = 0f..(replaySamples.size - 1).toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = CoolWhite,
                            activeTrackColor = TechnicalBlue,
                            inactiveTrackColor = InstrumentBlack
                        ),
                        modifier = Modifier.testTag("replay_scrubber_slider")
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Replay Telemetry Metrics Summary
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(InstrumentBlack, RoundedCornerShape(4.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "SPEED", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                            Text(text = "${currentSample.speed.toInt()}", color = CoolWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Column {
                            Text(text = "HEADING", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                            Text(text = "${currentSample.headingDeg.toInt()}°", color = CoolWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Column {
                            Text(text = "ALT / DEPTH", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                            Text(text = "${currentSample.altitudeOrDepth.toInt()}", color = CoolWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Column {
                            Text(text = "TEMP", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                            Text(text = "${currentSample.coolantTempC.toInt()}°C", color = AmberWarning, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Column {
                            Text(text = "HEALTH", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                            Text(text = "${currentSample.integrityPct.toInt()}%", color = MutedGreen, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = onEnterCockpit,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TechnicalBlue,
                            contentColor = InstrumentBlack
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth().testTag("view_replay_in_cockpit_button")
                    ) {
                        Text(
                            text = "VIEW REPLAY IN CENTRAL 3D VIEWPORT",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // Sessions List
        items(sessions) { session ->
            SessionCard(
                session = session,
                onReplay = { onStartReplay(session) },
                onExport = {
                    exportSessionCsv(context, session)
                }
            )
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun SessionCard(
    session: SessionRecordEntity,
    onReplay: () -> Unit,
    onExport: () -> Unit
) {
    val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(session.startTimeMs))
    val passColor = if (session.passed) MutedGreen else CriticalRed

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepGraphite, RoundedCornerShape(6.dp))
            .border(1.dp, TacticalPanelBorder, RoundedCornerShape(6.dp))
            .padding(14.dp)
            .testTag("session_record_${session.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${session.scenarioTitle} // ${session.vehicleType}",
                    color = CoolWhite,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "Callsign: ${session.callsign}  |  $dateStr",
                    color = Titanium,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )
            }

            Box(
                modifier = Modifier
                    .background(passColor.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                    .border(1.dp, passColor, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = if (session.passed) "PASSED (${session.scoreAchieved})" else "FAILED (${session.scoreAchieved})",
                    color = passColor,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Session Stats
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentBlack, RoundedCornerShape(4.dp))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = "DURATION", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                Text(text = "${session.durationSeconds}s", color = CoolWhite, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
            Column {
                Text(text = "AVG SPEED", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                Text(text = "${session.avgSpeed.toInt()}", color = CoolWhite, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
            Column {
                Text(text = "MAX SPEED", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                Text(text = "${session.maxSpeed.toInt()}", color = CoolWhite, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
            Column {
                Text(text = "FAULTS", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                Text(text = "${session.faultsEncounteredCount}", color = if (session.faultsEncounteredCount > 0) AmberWarning else MutedGreen, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onReplay,
                colors = ButtonDefaults.buttonColors(
                    containerColor = TechnicalBlue,
                    contentColor = InstrumentBlack
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.weight(1f).testTag("replay_session_button_${session.id}")
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Replay", modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "LOAD REPLAY", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }

            Button(
                onClick = onExport,
                colors = ButtonDefaults.buttonColors(
                    containerColor = DeepGraphite,
                    contentColor = CoolWhite
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .border(1.dp, TacticalPanelBorder, RoundedCornerShape(4.dp))
                    .testTag("export_session_button_${session.id}")
            ) {
                Icon(imageVector = Icons.Default.Share, contentDescription = "Export", modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "EXPORT CSV", fontFamily = FontFamily.Monospace, fontSize = 9.sp)
            }
        }
    }
}

private fun exportSessionCsv(context: Context, session: SessionRecordEntity) {
    val csv = buildString {
        appendLine("MOD COCKPIT TELEMETRY LOG // SYNTHETIC SIMULATION DATA")
        appendLine("Session ID,Vehicle,Callsign,Scenario,DurationSec,Score,Passed,AvgSpeed,MaxSpeed,MinIntegrity")
        appendLine("${session.id},${session.vehicleType},${session.callsign},\"${session.scenarioTitle}\",${session.durationSeconds},${session.scoreAchieved},${session.passed},${session.avgSpeed},${session.maxSpeed},${session.minIntegrityPct}")
    }

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "MOD Cockpit Log - ${session.scenarioTitle}")
        putExtra(Intent.EXTRA_TEXT, csv)
    }
    context.startActivity(Intent.createChooser(intent, "Export Telemetry CSV"))
}
