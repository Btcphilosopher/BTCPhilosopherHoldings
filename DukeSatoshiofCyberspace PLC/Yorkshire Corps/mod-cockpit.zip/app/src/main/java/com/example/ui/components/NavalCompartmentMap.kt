package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoolWhite
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.InstrumentBlack
import com.example.ui.theme.MutedGreen
import com.example.ui.theme.TacticalPanelBorder
import com.example.ui.theme.TechnicalBlue
import com.example.ui.theme.Titanium

data class CompartmentInfo(
    val id: String,
    val name: String,
    val frameLocation: String,
    val waterLevelPct: Float,
    val fireLoopNormal: Boolean,
    val pumpAvailable: Boolean
)

@Composable
fun NavalCompartmentMap(
    bilgeLevelB1: Float,
    isPumpActive: Boolean,
    onTogglePump: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCompartmentId by remember { mutableStateOf("B1") }

    val compartments = listOf(
        CompartmentInfo("A1", "BOW FOREPEAK", "Frames 0-35", 0f, true, true),
        CompartmentInfo("A2", "FWD MAGAZINE", "Frames 36-80", 0f, true, true),
        CompartmentInfo("B1", "MAIN ENGINE ROOM", "Frames 81-140", bilgeLevelB1, true, true),
        CompartmentInfo("B2", "BOILER ROOMS", "Frames 141-190", 0f, true, true),
        CompartmentInfo("C1", "AUX MACHINERY", "Frames 191-230", 0f, true, true),
        CompartmentInfo("C2", "AFT STEERING GEAR", "Frames 231-270", 0f, true, true)
    )

    val activeComp = compartments.firstOrNull { it.id == selectedCompartmentId } ?: compartments[2]

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(DeepGraphite, RoundedCornerShape(6.dp))
            .border(1.dp, TacticalPanelBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
            .testTag("naval_compartment_damage_control")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "HULL DAMAGE CONTROL // WATERTIGHT COMPARTMENTS",
                color = CoolWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
            Text(
                text = "6 SECTIONS MONITORED",
                color = Titanium,
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Ship Silhouette Compartment Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .background(InstrumentBlack, RoundedCornerShape(4.dp))
                .border(1.dp, TacticalPanelBorder, RoundedCornerShape(4.dp))
                .padding(2.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            compartments.forEach { comp ->
                val isSelected = comp.id == selectedCompartmentId
                val statusColor = when {
                    comp.waterLevelPct > 30f -> CriticalRed
                    comp.waterLevelPct > 5f -> AmberWarning
                    else -> MutedGreen
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (isSelected) statusColor.copy(alpha = 0.35f) else statusColor.copy(alpha = 0.15f),
                            RoundedCornerShape(3.dp)
                        )
                        .border(
                            if (isSelected) 1.5.dp else 0.8.dp,
                            if (isSelected) CoolWhite else statusColor,
                            RoundedCornerShape(3.dp)
                        )
                        .clickable { selectedCompartmentId = comp.id }
                        .padding(2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = comp.id,
                            color = if (isSelected) CoolWhite else statusColor,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                        Text(
                            text = if (comp.waterLevelPct > 0f) "${comp.waterLevelPct.toInt()}%" else "SECURE",
                            color = if (comp.waterLevelPct > 0f) statusColor else Titanium,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 7.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Detailed Compartment Status & Controls
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentBlack, RoundedCornerShape(4.dp))
                .padding(10.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "COMPARTMENT ${activeComp.id}: ${activeComp.name}",
                        color = CoolWhite,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    Text(
                        text = activeComp.frameLocation,
                        color = Titanium,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "WATER INGRESS: ${activeComp.waterLevelPct.toInt()}%",
                            color = if (activeComp.waterLevelPct > 5f) CriticalRed else MutedGreen,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "FIRE DETECTION LOOP: SECURE",
                            color = MutedGreen,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                    }

                    if (activeComp.id == "B1") {
                        Button(
                            onClick = { onTogglePump(!isPumpActive) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPumpActive) MutedGreen else TechnicalBlue,
                                contentColor = InstrumentBlack
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.testTag("toggle_emergency_bilge_pump_button")
                        ) {
                            Text(
                                text = if (isPumpActive) "PUMP ACTIVE (STOP)" else "START BILGE PUMP",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        }
                    } else {
                        Text(
                            text = "BULKHEAD SEALED",
                            color = Titanium,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }
    }
}
