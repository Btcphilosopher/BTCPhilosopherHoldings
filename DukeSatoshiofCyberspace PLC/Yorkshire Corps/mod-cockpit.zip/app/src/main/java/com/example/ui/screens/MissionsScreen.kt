package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.ScenarioCatalog
import com.example.core.model.TrainingScenario
import com.example.core.model.VehicleType
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoolWhite
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.InstrumentBlack
import com.example.ui.theme.MutedGreen
import com.example.ui.theme.TacticalPanelBorder
import com.example.ui.theme.TechnicalBlue
import com.example.ui.theme.Titanium

@Composable
fun MissionsScreen(
    currentVehicleType: VehicleType,
    activeScenario: TrainingScenario?,
    scenarioElapsedSec: Int,
    scenarioScore: Int,
    scenarioDebrief: String?,
    onStartScenario: (TrainingScenario) -> Unit,
    onEndScenario: () -> Unit,
    onEnterCockpit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scenarios = ScenarioCatalog.getScenariosFor(currentVehicleType)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(InstrumentBlack)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            // Header
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "OPERATIONAL TRAINING MISSIONS",
                        color = CoolWhite,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Box(
                        modifier = Modifier
                            .background(TechnicalBlue.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .border(1.dp, TechnicalBlue, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "${currentVehicleType.name} SYLLABUS",
                            color = TechnicalBlue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Fictional, non-combat engineering scenarios focusing on handling, navigation, and fault mitigation.",
                    color = Titanium,
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 11.sp
                )
            }
        }

        // Active Mission Progress Banner (If scenario running)
        if (activeScenario != null) {
            item {
                ActiveScenarioTrackerCard(
                    scenario = activeScenario,
                    elapsedSec = scenarioElapsedSec,
                    score = scenarioScore,
                    onEndScenario = onEndScenario,
                    onViewCockpit = onEnterCockpit
                )
            }
        }

        // Post-exercise Debrief Box (If scenario just ended)
        if (scenarioDebrief != null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DeepGraphite, RoundedCornerShape(6.dp))
                        .border(1.5.dp, MutedGreen, RoundedCornerShape(6.dp))
                        .padding(14.dp)
                        .testTag("mission_debrief_card")
                ) {
                    Column {
                        Text(
                            text = "TRAINING MISSION DEBRIEF // EXERCISE COMPLETE",
                            color = MutedGreen,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = scenarioDebrief,
                            color = CoolWhite,
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }

        // Available Scenarios for current vehicle
        items(scenarios) { scenario ->
            val isCurrentActive = activeScenario?.id == scenario.id
            ScenarioCard(
                scenario = scenario,
                isActive = isCurrentActive,
                onStart = {
                    onStartScenario(scenario)
                    onEnterCockpit()
                }
            )
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun ActiveScenarioTrackerCard(
    scenario: TrainingScenario,
    elapsedSec: Int,
    score: Int,
    onEndScenario: () -> Unit,
    onViewCockpit: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepGraphite, RoundedCornerShape(8.dp))
            .border(1.5.dp, TechnicalBlue, RoundedCornerShape(8.dp))
            .padding(14.dp)
            .testTag("active_scenario_tracker")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "ACTIVE MISSION: ${scenario.title.uppercase()}",
                    color = TechnicalBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Text(
                    text = "TIME: ${elapsedSec}s / ${scenario.targetDurationSec}s  |  CURRENT SCORE: $score / 100",
                    color = CoolWhite,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp
                )
            }

            Box(
                modifier = Modifier
                    .background(MutedGreen.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "IN PROGRESS",
                    color = MutedGreen,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Objectives Checklist
        Text(
            text = "EXERCISE OBJECTIVES:",
            color = Titanium,
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp
        )
        scenario.objectives.forEach { obj ->
            Row(
                modifier = Modifier.padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Objective",
                    tint = MutedGreen,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = obj,
                    color = CoolWhite,
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onViewCockpit,
                colors = ButtonDefaults.buttonColors(
                    containerColor = TechnicalBlue,
                    contentColor = InstrumentBlack
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.weight(1f).testTag("view_mission_cockpit_button")
            ) {
                Text(
                    text = "RESUME COCKPIT",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }

            Button(
                onClick = onEndScenario,
                colors = ButtonDefaults.buttonColors(
                    containerColor = DeepGraphite,
                    contentColor = CriticalRed
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .border(1.dp, CriticalRed.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                    .testTag("complete_mission_early_button")
            ) {
                Text(
                    text = "END EXERCISE",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
fun ScenarioCard(
    scenario: TrainingScenario,
    isActive: Boolean,
    onStart: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepGraphite, RoundedCornerShape(6.dp))
            .border(1.dp, if (isActive) TechnicalBlue else TacticalPanelBorder, RoundedCornerShape(6.dp))
            .padding(14.dp)
            .testTag("scenario_card_${scenario.id.lowercase()}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = scenario.title,
                    color = CoolWhite,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "Difficulty: ${scenario.difficulty}  |  Duration: ${scenario.targetDurationSec}s  |  Pass: ${scenario.passingScore}%",
                    color = Titanium,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )
            }
            Box(
                modifier = Modifier
                    .background(TechnicalBlue.copy(alpha = 0.15f), RoundedCornerShape(3.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = scenario.vehicleType.name,
                    color = TechnicalBlue,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = scenario.description,
            color = Titanium,
            fontFamily = FontFamily.SansSerif,
            fontSize = 11.sp,
            lineHeight = 15.sp
        )

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Environment: ${scenario.environmentDescription}",
            color = CoolWhite,
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = onStart,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isActive) MutedGreen else TechnicalBlue,
                contentColor = InstrumentBlack
            ),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth().testTag("start_scenario_button_${scenario.id.lowercase()}")
        ) {
            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Start", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isActive) "MISSION ACTIVE (RESUME)" else "INITIATE TRAINING SCENARIO",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            )
        }
    }
}
