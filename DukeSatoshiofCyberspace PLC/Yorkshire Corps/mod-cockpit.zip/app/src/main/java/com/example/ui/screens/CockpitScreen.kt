package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.CockpitLayoutMode
import com.example.core.model.SubsystemHealth
import com.example.core.model.TelemetryPacket
import com.example.core.model.VehicleType
import com.example.ui.cockpit.render.CockpitVisualizer
import com.example.ui.cockpit.render.VisualizerViewMode
import com.example.ui.components.AlertBanner
import com.example.ui.components.CircularGauge
import com.example.ui.components.LinearTape
import com.example.ui.components.NavalCompartmentMap
import com.example.ui.components.TacticalControls
import com.example.ui.components.TelemetryStripChart
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoolWhite
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.InstrumentBlack
import com.example.ui.theme.MutedGreen
import com.example.ui.theme.TacticalPanelBorder
import com.example.ui.theme.TechnicalBlue
import com.example.ui.theme.Titanium

@Composable
fun CockpitScreen(
    telemetry: TelemetryPacket,
    subsystems: List<SubsystemHealth>,
    layoutMode: CockpitLayoutMode,
    visualizerViewMode: VisualizerViewMode,
    speedHistory: List<Float>,
    rpmHistory: List<Float>,
    throttle: Float,
    steering: Float,
    secondary: Float,
    subsystem1Active: Boolean,
    subsystem2Active: Boolean,
    onThrottleChange: (Float) -> Unit,
    onSteeringChange: (Float) -> Unit,
    onSecondaryChange: (Float) -> Unit,
    onToggleSubsystem1: () -> Unit,
    onToggleSubsystem2: () -> Unit,
    onLayoutModeChange: (CockpitLayoutMode) -> Unit,
    onVisualizerViewModeChange: (VisualizerViewMode) -> Unit,
    onAcknowledgeAlerts: () -> Unit,
    modifier: Modifier = Modifier
) {
    val vehicleType = telemetry.vehicleType

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(InstrumentBlack)
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("cockpit_screen_container")
    ) {
        // Cockpit Master Header with Status & Mode Selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(if (telemetry.masterWarningActive) CriticalRed else MutedGreen, RoundedCornerShape(4.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${vehicleType.title.uppercase()} COCKPIT // ${vehicleType.designation}",
                        color = CoolWhite,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                Text(
                    text = "HDG: ${telemetry.headingDeg.toInt()}°  |  INTEGRITY: ${telemetry.overallIntegrityPct.toInt()}%  |  TIME: ${telemetry.simulationTimeSec.toInt()}s",
                    color = Titanium,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )
            }

            // Layout Mode Switchers
            Row(
                modifier = Modifier
                    .background(DeepGraphite, RoundedCornerShape(4.dp))
                    .border(1.dp, TacticalPanelBorder, RoundedCornerShape(4.dp)),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                CockpitLayoutMode.values().forEach { mode ->
                    val isSelected = mode == layoutMode
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSelected) TechnicalBlue else DeepGraphite,
                                RoundedCornerShape(3.dp)
                            )
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                            .testTag("layout_mode_${mode.name.lowercase()}")
                    ) {
                        Text(
                            text = mode.label,
                            color = if (isSelected) InstrumentBlack else Titanium,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 8.sp,
                            modifier = Modifier.padding(horizontal = 2.dp)
                        )
                    }
                }
            }
        }

        // Master Caution / Warning Alert Banner
        AlertBanner(
            alerts = telemetry.activeAlerts,
            isCaution = telemetry.masterCautionActive,
            isWarning = telemetry.masterWarningActive,
            onAcknowledge = onAcknowledgeAlerts,
            modifier = Modifier.padding(vertical = 4.dp)
        )

        // View Mode Toggle (3D Chase / Top-Down / Cutaway)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            VisualizerViewMode.values().forEach { mode ->
                val isSelected = mode == visualizerViewMode
                Button(
                    onClick = { onVisualizerViewModeChange(mode) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) TechnicalBlue else DeepGraphite,
                        contentColor = if (isSelected) InstrumentBlack else CoolWhite
                    ),
                    shape = RoundedCornerShape(3.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(30.dp)
                        .border(1.dp, if (isSelected) TechnicalBlue else TacticalPanelBorder, RoundedCornerShape(3.dp))
                        .testTag("cam_mode_${mode.name.lowercase()}")
                ) {
                    Text(
                        text = mode.label,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. Central 3D Visualizer Viewport (The signature feature)
            item {
                val viewportHeight = when (layoutMode) {
                    CockpitLayoutMode.FULL_COCKPIT -> 320.dp
                    CockpitLayoutMode.SPLIT_VIEW -> 220.dp
                    CockpitLayoutMode.ENGINEERING_VIEW -> 170.dp
                    CockpitLayoutMode.INSTRUCTOR_VIEW -> 180.dp
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(viewportHeight)
                        .border(1.dp, TacticalPanelBorder, RoundedCornerShape(6.dp))
                ) {
                    CockpitVisualizer(
                        telemetry = telemetry,
                        viewMode = visualizerViewMode,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // 2. Primary Instrumentation Cluster (Dials & Linear Tapes)
            item {
                when (vehicleType) {
                    VehicleType.NAVAL -> {
                        NavalInstrumentCluster(telemetry)
                    }
                    VehicleType.ARMOURED -> {
                        ArmouredInstrumentCluster(telemetry)
                    }
                    VehicleType.AVIATION -> {
                        AviationInstrumentCluster(telemetry)
                    }
                }
            }

            // 3. Compartment Damage Control (Naval specific)
            if (vehicleType == VehicleType.NAVAL) {
                item {
                    val b1Bilge = telemetry.customMetrics["bilgeLevelB1Pct"] ?: 0f
                    NavalCompartmentMap(
                        bilgeLevelB1 = b1Bilge,
                        isPumpActive = subsystem1Active,
                        onTogglePump = { onToggleSubsystem1() }
                    )
                }
            }

            // 4. Live Telemetry Strip Chart
            item {
                val speedUnit = when (vehicleType) {
                    VehicleType.NAVAL -> "KTS"
                    VehicleType.ARMOURED -> "KM/H"
                    VehicleType.AVIATION -> "KTS IAS"
                }
                TelemetryStripChart(
                    title = "SPEED & POWER HISTORICAL PROFILE",
                    dataPoints = speedHistory,
                    unit = speedUnit,
                    lineColor = TechnicalBlue
                )
            }

            // 5. Tactical Simulation Controls (Throttle, Steering, Subsystems)
            item {
                val sub1Label = when (vehicleType) {
                    VehicleType.NAVAL -> if (subsystem1Active) "BILGE PUMP: ON" else "BILGE PUMP: OFF"
                    VehicleType.ARMOURED -> if (subsystem1Active) "RAD BYPASS: ON" else "RAD BYPASS: OFF"
                    VehicleType.AVIATION -> if (subsystem1Active) "HYD A ISOL: ON" else "HYD A ISOL: OFF"
                }
                val sub2Label = when (vehicleType) {
                    VehicleType.NAVAL -> "GT GEN 3: AUTO"
                    VehicleType.ARMOURED -> if (subsystem2Active) "APU: ACTIVE" else "APU: STOPPED"
                    VehicleType.AVIATION -> if (subsystem2Active) "PITOT HEAT: HIGH" else "PITOT HEAT: AUTO"
                }

                TacticalControls(
                    vehicleType = vehicleType,
                    throttle = throttle,
                    steering = steering,
                    secondary = secondary,
                    onThrottleChange = onThrottleChange,
                    onSteeringChange = onSteeringChange,
                    onSecondaryChange = onSecondaryChange,
                    onToggleSubsystem1 = onToggleSubsystem1,
                    subsystem1Label = sub1Label,
                    subsystem1Active = subsystem1Active,
                    onToggleSubsystem2 = onToggleSubsystem2,
                    subsystem2Label = sub2Label,
                    subsystem2Active = subsystem2Active
                )
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun NavalInstrumentCluster(telemetry: TelemetryPacket) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepGraphite, RoundedCornerShape(6.dp))
            .border(1.dp, TacticalPanelBorder, RoundedCornerShape(6.dp))
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        CircularGauge(
            title = "SPEED",
            value = telemetry.speed,
            unit = "KNOTS",
            minVal = 0f,
            maxVal = 35f,
            warningVal = 32f,
            sizeDp = 105.dp,
            decimalPlaces = 1
        )
        CircularGauge(
            title = "SHAFT RPM",
            value = telemetry.engineRpm,
            unit = "RPM",
            minVal = 0f,
            maxVal = 300f,
            warningVal = 260f,
            criticalVal = 280f,
            sizeDp = 105.dp
        )
        CircularGauge(
            title = "BUS VOLT",
            value = telemetry.busVoltageV,
            unit = "V AC",
            minVal = 380f,
            maxVal = 460f,
            warningVal = 415f,
            criticalVal = 390f,
            sizeDp = 105.dp
        )
    }
}

@Composable
private fun ArmouredInstrumentCluster(telemetry: TelemetryPacket) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepGraphite, RoundedCornerShape(6.dp))
            .border(1.dp, TacticalPanelBorder, RoundedCornerShape(6.dp))
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        CircularGauge(
            title = "SPEED",
            value = telemetry.speed,
            unit = "KM/H",
            minVal = 0f,
            maxVal = 80f,
            warningVal = 72f,
            sizeDp = 105.dp
        )
        CircularGauge(
            title = "V12 RPM",
            value = telemetry.engineRpm,
            unit = "RPM",
            minVal = 600f,
            maxVal = 3000f,
            warningVal = 2600f,
            criticalVal = 2850f,
            sizeDp = 105.dp
        )
        CircularGauge(
            title = "COOLANT",
            value = telemetry.coolantTempC,
            unit = "°C",
            minVal = 60f,
            maxVal = 130f,
            warningVal = 102f,
            criticalVal = 115f,
            sizeDp = 105.dp
        )
    }
}

@Composable
private fun AviationInstrumentCluster(telemetry: TelemetryPacket) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepGraphite, RoundedCornerShape(6.dp))
            .border(1.dp, TacticalPanelBorder, RoundedCornerShape(6.dp))
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        LinearTape(
            title = "AIRSPEED",
            currentValue = telemetry.speed,
            unit = "KTS IAS",
            stepSize = 50
        )
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CircularGauge(
                title = "TURBINE",
                value = telemetry.coolantTempC,
                unit = "°C TIT",
                minVal = 500f,
                maxVal = 1100f,
                warningVal = 860f,
                criticalVal = 920f,
                sizeDp = 95.dp
            )
            CircularGauge(
                title = "HYD PRESS",
                value = telemetry.hydraulicPressurePsi,
                unit = "PSI",
                minVal = 1000f,
                maxVal = 3500f,
                warningVal = 2200f,
                criticalVal = 1500f,
                sizeDp = 95.dp
            )
        }
        LinearTape(
            title = "ALTITUDE",
            currentValue = telemetry.altitudeOrDepth,
            unit = "FEET",
            stepSize = 1000
        )
    }
}
