package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.FaultInjection
import com.example.core.model.StandardFaults
import com.example.core.model.SubsystemHealth
import com.example.core.model.SystemStatus
import com.example.core.model.VehicleType
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoolWhite
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.InstrumentBlack
import com.example.ui.theme.MutedGreen
import com.example.ui.theme.TacticalPanelBorder
import com.example.ui.theme.TechnicalBlue
import com.example.ui.theme.Titanium

@Composable
fun SystemsScreen(
    vehicleType: VehicleType,
    subsystems: List<SubsystemHealth>,
    onInjectFault: (FaultInjection) -> Unit,
    onClearFault: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf<SystemStatus?>(null) }
    val availableFaults = StandardFaults.getFaultsFor(vehicleType)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(InstrumentBlack)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            // Header
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PLATFORM SYSTEMS DIAGNOSTICS",
                        color = CoolWhite,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Box(
                        modifier = Modifier
                            .background(TechnicalBlue.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .border(1.dp, TechnicalBlue, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "${vehicleType.name} DOMAIN",
                            color = TechnicalBlue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Real-time subsystem health monitoring, operating tolerances and interactive training fault injection.",
                    color = Titanium,
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 11.sp
                )
            }
        }

        // Filter Pills
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(null to "ALL", SystemStatus.NORMAL to "NORMAL", SystemStatus.CAUTION to "CAUTION", SystemStatus.WARNING to "WARNING").forEach { (status, label) ->
                    val isSelected = selectedFilter == status
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (isSelected) TechnicalBlue else DeepGraphite,
                                RoundedCornerShape(4.dp)
                            )
                            .border(1.dp, if (isSelected) TechnicalBlue else TacticalPanelBorder, RoundedCornerShape(4.dp))
                            .clickable { selectedFilter = status }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) InstrumentBlack else CoolWhite,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }

        // Subsystems List
        val filteredSubsystems = if (selectedFilter == null) subsystems else subsystems.filter { it.status == selectedFilter }
        items(filteredSubsystems) { sub ->
            SubsystemDiagnosticCard(subsystem = sub)
        }

        // Training Fault Injection Panel
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepGraphite, RoundedCornerShape(8.dp))
                    .border(1.5.dp, AmberWarning.copy(alpha = 0.8f), RoundedCornerShape(8.dp))
                    .padding(14.dp)
                    .testTag("fault_injection_panel")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Build,
                            contentDescription = "Fault",
                            tint = AmberWarning,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "TRAINING FAULT INJECTION CONTROLS",
                            color = CoolWhite,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                    Text(
                        text = "SIMULATOR OVERRIDE",
                        color = AmberWarning,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Inject realistic system degradation into the live simulation loop to assess operational emergency response.",
                    color = Titanium,
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                availableFaults.forEach { fault ->
                    FaultInjectionRow(
                        fault = fault,
                        onInject = { onInjectFault(fault) },
                        onClear = { onClearFault(fault.id) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun SubsystemDiagnosticCard(subsystem: SubsystemHealth) {
    val statusColor = subsystem.status.color

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepGraphite, RoundedCornerShape(6.dp))
            .border(1.dp, TacticalPanelBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
            .testTag("subsystem_card_${subsystem.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = subsystem.name.uppercase(),
                    color = CoolWhite,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Text(
                    text = subsystem.category.title,
                    color = Titanium,
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 10.sp
                )
            }
            Box(
                modifier = Modifier
                    .background(statusColor.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                    .border(1.dp, statusColor, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = subsystem.status.label,
                    color = statusColor,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Readings & Thresholds Grid
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentBlack, RoundedCornerShape(4.dp))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = "CURRENT", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                Text(
                    text = "${subsystem.currentValue.toInt()} ${subsystem.unit}",
                    color = statusColor,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
            Column {
                Text(text = "NOMINAL RANGE", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                Text(
                    text = "${subsystem.expectedMin.toInt()} - ${subsystem.expectedMax.toInt()} ${subsystem.unit}",
                    color = CoolWhite,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
            Column {
                Text(text = "WARNING", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                Text(
                    text = "${subsystem.warningThreshold.toInt()} ${subsystem.unit}",
                    color = AmberWarning,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
            Column {
                Text(text = "CRITICAL", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                Text(
                    text = "${subsystem.criticalThreshold.toInt()} ${subsystem.unit}",
                    color = CriticalRed,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Diagnostic Explanation & Training Action
        Text(
            text = "Diagnostic: ${subsystem.diagnosticSummary}",
            color = Titanium,
            fontFamily = FontFamily.SansSerif,
            fontSize = 11.sp,
            lineHeight = 15.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Action: ${subsystem.trainingRecommendation}",
            color = if (subsystem.status != SystemStatus.NORMAL) AmberWarning else CoolWhite,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun FaultInjectionRow(
    fault: FaultInjection,
    onInject: () -> Unit,
    onClear: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(InstrumentBlack, RoundedCornerShape(4.dp))
            .border(0.8.dp, TacticalPanelBorder, RoundedCornerShape(4.dp))
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = fault.title,
                color = CoolWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
            Text(
                text = fault.description,
                color = Titanium,
                fontFamily = FontFamily.SansSerif,
                fontSize = 10.sp
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Button(
                onClick = onInject,
                colors = ButtonDefaults.buttonColors(
                    containerColor = AmberWarning,
                    contentColor = InstrumentBlack
                ),
                shape = RoundedCornerShape(3.dp),
                modifier = Modifier.testTag("inject_fault_button_${fault.id.lowercase()}")
            ) {
                Text(
                    text = "INJECT",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp
                )
            }
            Button(
                onClick = onClear,
                colors = ButtonDefaults.buttonColors(
                    containerColor = DeepGraphite,
                    contentColor = CoolWhite
                ),
                shape = RoundedCornerShape(3.dp),
                modifier = Modifier
                    .border(1.dp, TacticalPanelBorder, RoundedCornerShape(3.dp))
                    .testTag("clear_fault_button_${fault.id.lowercase()}")
            ) {
                Text(
                    text = "CLEAR",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )
            }
        }
    }
}
