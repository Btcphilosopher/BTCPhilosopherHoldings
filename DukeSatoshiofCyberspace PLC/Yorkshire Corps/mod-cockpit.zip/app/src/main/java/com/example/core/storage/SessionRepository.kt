package com.example.core.storage

import android.content.Context
import com.example.core.model.TelemetryPacket
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class SessionRepository(private val dao: SessionDao) {

    val allSessions: Flow<List<SessionRecordEntity>> = dao.getAllSessions()

    suspend fun recordCompletedSession(
        vehicleType: String,
        callsign: String,
        scenarioTitle: String,
        durationSeconds: Int,
        scoreAchieved: Int,
        passed: Boolean,
        faultsCount: Int,
        samples: List<TelemetryPacket>
    ): Long {
        val avgSpd = if (samples.isNotEmpty()) samples.map { it.speed }.average().toFloat() else 0f
        val maxSpd = if (samples.isNotEmpty()) samples.maxOf { it.speed } else 0f
        val minInteg = if (samples.isNotEmpty()) samples.minOf { it.overallIntegrityPct } else 100f

        val session = SessionRecordEntity(
            vehicleType = vehicleType,
            callsign = callsign,
            scenarioTitle = scenarioTitle,
            startTimeMs = System.currentTimeMillis() - (durationSeconds * 1000L),
            durationSeconds = durationSeconds,
            scoreAchieved = scoreAchieved,
            passed = passed,
            faultsEncounteredCount = faultsCount,
            avgSpeed = avgSpd,
            maxSpeed = maxSpd,
            minIntegrityPct = minInteg
        )
        val sessionId = dao.insertSession(session)

        // Downsample for database storage if needed
        val sampleEntities = samples.mapIndexed { index, pkt ->
            TelemetrySampleEntity(
                sessionId = sessionId,
                timeOffsetSec = pkt.simulationTimeSec,
                speed = pkt.speed,
                headingDeg = pkt.headingDeg,
                altitudeOrDepth = pkt.altitudeOrDepth,
                pitchDeg = pkt.pitchDeg,
                rollDeg = pkt.rollDeg,
                engineRpm = pkt.engineRpm,
                coolantTempC = pkt.coolantTempC,
                powerGeneratedKw = pkt.powerGeneratedKw,
                integrityPct = pkt.overallIntegrityPct
            )
        }
        dao.insertSamples(sampleEntities)
        return sessionId
    }

    suspend fun getSamplesForSession(sessionId: Long): List<TelemetrySampleEntity> {
        return dao.getSamplesForSession(sessionId)
    }

    suspend fun deleteSession(sessionId: Long) {
        dao.deleteSamplesForSession(sessionId)
        dao.deleteSession(sessionId)
    }

    suspend fun ensureInitialSeedData() {
        val current = dao.getAllSessions().first()
        if (current.isEmpty()) {
            // Seed a realistic completed Naval, Armoured, and Aviation session
            val now = System.currentTimeMillis()
            val navalId = dao.insertSession(
                SessionRecordEntity(
                    vehicleType = "NAVAL",
                    callsign = "Vanguard Lead",
                    scenarioTitle = "Heavy Sea Station-Keeping",
                    startTimeMs = now - 3600000L * 4,
                    durationSeconds = 180,
                    scoreAchieved = 92,
                    passed = true,
                    faultsEncounteredCount = 1,
                    avgSpeed = 19.4f,
                    maxSpeed = 24.2f,
                    minIntegrityPct = 94.0f
                )
            )
            val armouredId = dao.insertSession(
                SessionRecordEntity(
                    vehicleType = "ARMOURED",
                    callsign = "Ironclad 1-1",
                    scenarioTitle = "Slope Stability & Powertrain Handling",
                    startTimeMs = now - 3600000L * 24,
                    durationSeconds = 150,
                    scoreAchieved = 88,
                    passed = true,
                    faultsEncounteredCount = 0,
                    avgSpeed = 32.1f,
                    maxSpeed = 46.8f,
                    minIntegrityPct = 96.5f
                )
            )
            val aviationId = dao.insertSession(
                SessionRecordEntity(
                    vehicleType = "AVIATION",
                    callsign = "Viper 04",
                    scenarioTitle = "Hydraulic System A Recovery Drill",
                    startTimeMs = now - 3600000L * 48,
                    durationSeconds = 180,
                    scoreAchieved = 95,
                    passed = true,
                    faultsEncounteredCount = 1,
                    avgSpeed = 445f,
                    maxSpeed = 610f,
                    minIntegrityPct = 89.0f
                )
            )

            // Seed sample curves for naval replay
            val navalSamples = (0..30).map { i ->
                val t = i * 6f
                TelemetrySampleEntity(
                    sessionId = navalId,
                    timeOffsetSec = t,
                    speed = 18f + kotlin.math.sin(i * 0.3).toFloat() * 3f,
                    headingDeg = 245f + kotlin.math.cos(i * 0.2).toFloat() * 4f,
                    altitudeOrDepth = 48f,
                    pitchDeg = kotlin.math.sin(i * 0.5).toFloat() * 2f,
                    rollDeg = kotlin.math.cos(i * 0.4).toFloat() * 3.5f,
                    engineRpm = 180f + (i % 5) * 4f,
                    coolantTempC = 82f + (i * 0.2f),
                    powerGeneratedKw = 3200f + (i % 3) * 50f,
                    integrityPct = 98f - (if (i > 15) 4f else 0f)
                )
            }
            dao.insertSamples(navalSamples)
        }
    }
}
