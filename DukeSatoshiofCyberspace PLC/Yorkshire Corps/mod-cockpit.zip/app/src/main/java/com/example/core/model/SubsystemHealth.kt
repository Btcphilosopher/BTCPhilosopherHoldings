package com.example.core.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.MutedGreen
import com.example.ui.theme.Titanium

enum class SystemStatus(val label: String, val color: Color) {
    NORMAL("NORMAL", MutedGreen),
    CAUTION("CAUTION", AmberWarning),
    WARNING("WARNING", CriticalRed),
    UNAVAILABLE("OFFLINE", Titanium)
}

enum class SubsystemCategory(val title: String) {
    PROPULSION("Propulsion & Mobility"),
    ELECTRICAL("Electrical & Power Distribution"),
    HYDRAULICS("Hydraulics & Flight Controls"),
    NAVIGATION("Navigation & Environmental Telemetry"),
    HULL_INTEGRITY("Hull & Damage Control"),
    THERMAL("Cooling & Thermal Management")
}

data class SubsystemHealth(
    val id: String,
    val name: String,
    val category: SubsystemCategory,
    val status: SystemStatus,
    val currentValue: Float,
    val unit: String,
    val expectedMin: Float,
    val expectedMax: Float,
    val warningThreshold: Float,
    val criticalThreshold: Float,
    val diagnosticSummary: String,
    val trainingRecommendation: String,
    val trendHistory: List<Float> = emptyList()
)
