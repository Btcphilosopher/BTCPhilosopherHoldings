package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.VehicleProfile
import com.example.core.model.VehicleRegistry
import com.example.core.model.VehicleType
import com.example.ui.theme.CoolWhite
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.InstrumentBlack
import com.example.ui.theme.MutedGreen
import com.example.ui.theme.TacticalPanelBorder
import com.example.ui.theme.TechnicalBlue
import com.example.ui.theme.Titanium

@Composable
fun HangarScreen(
    currentVehicleType: VehicleType,
    onSelectVehicle: (VehicleType) -> Unit,
    onEnterCockpit: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(InstrumentBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Header
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DEFENCE PLATFORM HANGAR",
                        color = CoolWhite,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Box(
                        modifier = Modifier
                            .background(TechnicalBlue.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .border(1.dp, TechnicalBlue, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "3 PLATFORMS READY",
                            color = TechnicalBlue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Select an operational simulation environment to configure telemetry, systems and training scenarios.",
                    color = Titanium,
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 12.sp
                )
            }
        }

        items(VehicleRegistry.profiles) { profile ->
            val isSelected = profile.type == currentVehicleType
            VehicleHangarCard(
                profile = profile,
                isSelected = isSelected,
                onSelect = {
                    onSelectVehicle(profile.type)
                },
                onLaunchCockpit = {
                    onSelectVehicle(profile.type)
                    onEnterCockpit()
                }
            )
        }

        item {
            // Operational Disclaimer Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepGraphite, RoundedCornerShape(6.dp))
                    .border(1.dp, TacticalPanelBorder, RoundedCornerShape(6.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "SIMULATION NOTICE // NON-CLASSIFIED TRAINING ARCHITECTURE",
                        color = Titanium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "All telemetry streams, powertrain parameters, hydrodynamic responses and aerodynamic flight envelopes are mathematically synthesized locally. Not connected to real military equipment or active weapons.",
                        color = Titanium,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun VehicleHangarCard(
    profile: VehicleProfile,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onLaunchCockpit: () -> Unit
) {
    val borderColor = if (isSelected) TechnicalBlue else TacticalPanelBorder
    val cardBackground = if (isSelected) DeepGraphite else Color(0xFF14181E)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(cardBackground, RoundedCornerShape(8.dp))
            .border(if (isSelected) 1.5.dp else 1.dp, borderColor, RoundedCornerShape(8.dp))
            .clickable { onSelect() }
            .padding(16.dp)
            .testTag("hangar_card_${profile.type.name.lowercase()}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val icon = when (profile.type) {
                    VehicleType.NAVAL -> Icons.Default.DirectionsBoat
                    VehicleType.ARMOURED -> Icons.Default.PrecisionManufacturing
                    VehicleType.AVIATION -> Icons.Default.Flight
                }
                Icon(
                    imageVector = icon,
                    contentDescription = profile.type.title,
                    tint = if (isSelected) TechnicalBlue else Titanium,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "${profile.type.title}  //  ${profile.type.designation}",
                        color = CoolWhite,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = profile.type.primaryDomain,
                        color = Titanium,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp
                    )
                }
            }

            if (isSelected) {
                Box(
                    modifier = Modifier
                        .background(MutedGreen.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "ACTIVE",
                        color = MutedGreen,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Technical Specs Grid
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentBlack, RoundedCornerShape(4.dp))
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = "READINESS", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                Text(text = "${profile.simulatedReadinessPct}%", color = MutedGreen, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Column {
                Text(text = "DISPLACEMENT / MASS", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                Text(text = "${profile.massTons.toInt()} TONS", color = CoolWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Column {
                Text(text = "TOP SPEED", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                Text(text = profile.topSpeedDisplay, color = CoolWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Column {
                Text(text = "HEALTH", color = Titanium, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                Text(text = "${profile.overallHealthPct}%", color = MutedGreen, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "Powerplant: ${profile.powerPlantDescription}",
            color = Titanium,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp
        )
        Text(
            text = "Profile: ${profile.activeProfile}",
            color = Titanium,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        Button(
            onClick = onLaunchCockpit,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isSelected) TechnicalBlue else DeepGraphite,
                contentColor = if (isSelected) InstrumentBlack else CoolWhite
            ),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, if (isSelected) TechnicalBlue else TacticalPanelBorder, RoundedCornerShape(4.dp))
                .testTag("enter_cockpit_button_${profile.type.name.lowercase()}")
        ) {
            Text(
                text = "ENTER COCKPIT INSTRUMENTATION",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Enter", modifier = Modifier.size(16.dp))
        }
    }
}
