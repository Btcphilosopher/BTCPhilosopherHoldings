package com.example.core.storage

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface SessionDao {
    @Query("SELECT * FROM training_sessions ORDER BY startTimeMs DESC")
    fun getAllSessions(): Flow<List<SessionRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: SessionRecordEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSamples(samples: List<TelemetrySampleEntity>)

    @Query("SELECT * FROM telemetry_samples WHERE sessionId = :sessionId ORDER BY timeOffsetSec ASC")
    suspend fun getSamplesForSession(sessionId: Long): List<TelemetrySampleEntity>

    @Query("DELETE FROM training_sessions WHERE id = :sessionId")
    suspend fun deleteSession(sessionId: Long)

    @Query("DELETE FROM telemetry_samples WHERE sessionId = :sessionId")
    suspend fun deleteSamplesForSession(sessionId: Long)
}

@Database(
    entities = [SessionRecordEntity::class, TelemetrySampleEntity::class],
    version = 1,
    exportSchema = false
)
abstract class CockpitDatabase : RoomDatabase() {
    abstract fun sessionDao(): SessionDao

    companion object {
        @Volatile
        private var INSTANCE: CockpitDatabase? = null

        fun getDatabase(context: Context): CockpitDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CockpitDatabase::class.java,
                    "mod_cockpit_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
