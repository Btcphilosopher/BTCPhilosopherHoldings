package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.VehicleType
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoolWhite
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.InstrumentBlack
import com.example.ui.theme.MutedGreen
import com.example.ui.theme.TacticalPanelBorder
import com.example.ui.theme.TechnicalBlue
import com.example.ui.theme.Titanium

@Composable
fun TacticalControls(
    vehicleType: VehicleType,
    throttle: Float,
    steering: Float,
    secondary: Float,
    onThrottleChange: (Float) -> Unit,
    onSteeringChange: (Float) -> Unit,
    onSecondaryChange: (Float) -> Unit,
    onToggleSubsystem1: () -> Unit,
    subsystem1Label: String,
    subsystem1Active: Boolean,
    onToggleSubsystem2: () -> Unit,
    subsystem2Label: String,
    subsystem2Active: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(DeepGraphite, RoundedCornerShape(6.dp))
            .border(1.dp, TacticalPanelBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
            .testTag("tactical_controls_panel")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "OPERATIONAL SIMULATION CONTROLS",
                color = CoolWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
            Text(
                text = "LIVE TELEMETRY COUPLING",
                color = TechnicalBlue,
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Throttle Control Slider
        val throttleLabel = when (vehicleType) {
            VehicleType.NAVAL -> "ENGINE TELEGRAPH // FORWARD SPEED"
            VehicleType.ARMOURED -> "ACCELERATOR // DRIVE POWERTRAIN"
            VehicleType.AVIATION -> "THROTTLE QUADRANT // ENGINE THRUST"
        }
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = throttleLabel,
                    color = Titanium,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )
                Text(
                    text = "${(throttle * 100).toInt()}%",
                    color = CoolWhite,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
            Slider(
                value = throttle,
                onValueChange = onThrottleChange,
                valueRange = 0f..1f,
                colors = SliderDefaults.colors(
                    thumbColor = CoolWhite,
                    activeTrackColor = TechnicalBlue,
                    inactiveTrackColor = InstrumentBlack
                ),
                modifier = Modifier.testTag("throttle_slider")
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Steering / Rudder / Bank Control Slider
        val steeringLabel = when (vehicleType) {
            VehicleType.NAVAL -> "RUDDER ANGLE (PORT <--> STBD)"
            VehicleType.ARMOURED -> "PIVOT STEER (LEFT <--> RIGHT)"
            VehicleType.AVIATION -> "FLIGHT CONTROL STICK (ROLL / BANK)"
        }
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = steeringLabel,
                    color = Titanium,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )
                Text(
                    text = if (steering > 0.05f) "+${(steering * 35).toInt()}°" else if (steering < -0.05f) "${(steering * 35).toInt()}°" else "CENTER",
                    color = CoolWhite,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
            Slider(
                value = steering,
                onValueChange = onSteeringChange,
                valueRange = -1f..1f,
                colors = SliderDefaults.colors(
                    thumbColor = CoolWhite,
                    activeTrackColor = TechnicalBlue,
                    inactiveTrackColor = InstrumentBlack
                ),
                modifier = Modifier.testTag("steering_slider")
            )
        }

        // Secondary Input (Pitch / Trim / Brake)
        val secondaryLabel = when (vehicleType) {
            VehicleType.NAVAL -> "TRIM TANK BALLAST TRANSFER"
            VehicleType.ARMOURED -> "MECHANICAL SERVICE BRAKE"
            VehicleType.AVIATION -> "ELEVATOR STICK (PITCH TRIM NOSE +/-)"
        }
        val secondaryRange = if (vehicleType == VehicleType.AVIATION) -1f..1f else 0f..1f
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = secondaryLabel,
                    color = Titanium,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )
                Text(
                    text = "${(secondary * 100).toInt()}%",
                    color = CoolWhite,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
            Slider(
                value = secondary,
                onValueChange = onSecondaryChange,
                valueRange = secondaryRange,
                colors = SliderDefaults.colors(
                    thumbColor = CoolWhite,
                    activeTrackColor = AmberWarning,
                    inactiveTrackColor = InstrumentBlack
                ),
                modifier = Modifier.testTag("secondary_control_slider")
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Subsystem Toggle Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onToggleSubsystem1,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (subsystem1Active) MutedGreen else InstrumentBlack,
                    contentColor = if (subsystem1Active) InstrumentBlack else CoolWhite
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, if (subsystem1Active) MutedGreen else TacticalPanelBorder, RoundedCornerShape(4.dp))
                    .testTag("toggle_subsystem_1_button")
            ) {
                Text(
                    text = subsystem1Label,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = onToggleSubsystem2,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (subsystem2Active) TechnicalBlue else InstrumentBlack,
                    contentColor = if (subsystem2Active) InstrumentBlack else CoolWhite
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, if (subsystem2Active) TechnicalBlue else TacticalPanelBorder, RoundedCornerShape(4.dp))
                    .testTag("toggle_subsystem_2_button")
            ) {
                Text(
                    text = subsystem2Label,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
