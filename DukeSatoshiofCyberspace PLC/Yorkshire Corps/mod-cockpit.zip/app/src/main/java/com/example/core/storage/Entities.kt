package com.example.core.storage

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "training_sessions")
data class SessionRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val vehicleType: String,
    val callsign: String,
    val scenarioTitle: String,
    val startTimeMs: Long,
    val durationSeconds: Int,
    val scoreAchieved: Int,
    val passed: Boolean,
    val faultsEncounteredCount: Int,
    val avgSpeed: Float,
    val maxSpeed: Float,
    val minIntegrityPct: Float
)

@Entity(tableName = "telemetry_samples")
data class TelemetrySampleEntity(
    @PrimaryKey(autoGenerate = true)
    val sampleId: Long = 0,
    val sessionId: Long,
    val timeOffsetSec: Float,
    val speed: Float,
    val headingDeg: Float,
    val altitudeOrDepth: Float,
    val pitchDeg: Float,
    val rollDeg: Float,
    val engineRpm: Float,
    val coolantTempC: Float,
    val powerGeneratedKw: Float,
    val integrityPct: Float
)
