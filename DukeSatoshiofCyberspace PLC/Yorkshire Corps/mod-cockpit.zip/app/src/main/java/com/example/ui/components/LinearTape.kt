package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CoolWhite
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.InstrumentBlack
import com.example.ui.theme.TacticalPanelBorder
import com.example.ui.theme.TechnicalBlue
import com.example.ui.theme.Titanium

@Composable
fun LinearTape(
    title: String,
    currentValue: Float,
    unit: String,
    stepSize: Int = 50,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .width(68.dp)
            .height(180.dp)
            .background(InstrumentBlack, RoundedCornerShape(4.dp))
            .testTag("linear_tape_${title.lowercase()}")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val tapeH = size.height
            val midY = tapeH / 2f
            val pixelsPerUnit = 0.5f

            // Draw graduated tick marks above and below current value
            val baseVal = (currentValue / stepSize).toInt() * stepSize
            for (offset in -4..4) {
                val tickVal = baseVal + (offset * stepSize)
                val delta = tickVal - currentValue
                val y = midY - (delta * pixelsPerUnit)

                if (y in 0f..tapeH) {
                    val isMajor = tickVal % (stepSize * 2) == 0
                    val tickLen = if (isMajor) 14.dp.toPx() else 8.dp.toPx()
                    drawLine(
                        color = if (isMajor) CoolWhite else Titanium,
                        start = Offset(size.width - tickLen, y),
                        end = Offset(size.width, y),
                        strokeWidth = if (isMajor) 2f else 1.2f
                    )
                }
            }

            // Center Reading Bug Indicator Line
            drawLine(
                color = TechnicalBlue,
                start = Offset(0f, midY),
                end = Offset(size.width, midY),
                strokeWidth = 2.5f
            )
        }

        // Overlay text badge in the center
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .background(DeepGraphite, RoundedCornerShape(3.dp))
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            Text(
                text = currentValue.toInt().toString(),
                color = CoolWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }

        // Title at Top
        Text(
            text = title,
            color = Titanium,
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 4.dp)
        )

        // Unit at Bottom
        Text(
            text = unit,
            color = Titanium,
            fontFamily = FontFamily.Monospace,
            fontSize = 8.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 4.dp)
        )
    }
}
