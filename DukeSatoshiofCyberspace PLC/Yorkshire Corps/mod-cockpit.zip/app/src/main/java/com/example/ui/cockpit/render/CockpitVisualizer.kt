package com.example.ui.cockpit.render

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.SystemStatus
import com.example.core.model.TelemetryPacket
import com.example.core.model.VehicleType
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoolWhite
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.InstrumentBlack
import com.example.ui.theme.MutedGreen
import com.example.ui.theme.TacticalPanelBorder
import com.example.ui.theme.TechnicalBlue
import com.example.ui.theme.Titanium
import com.example.ui.theme.TitaniumLight
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class VisualizerViewMode(val label: String) {
    CHASE("3D CHASE"),
    TOP_DOWN("TOP-DOWN"),
    CUTAWAY("CUTAWAY")
}

@Composable
fun CockpitVisualizer(
    telemetry: TelemetryPacket,
    modifier: Modifier = Modifier,
    viewMode: VisualizerViewMode = VisualizerViewMode.CHASE,
    batterySaver: Boolean = false
) {
    // Camera orbit controls from user touch drag
    var orbitAngleX by remember { mutableFloatStateOf(0f) }
    var orbitAngleY by remember { mutableFloatStateOf(0f) }

    // Continuous animation timer for wave/terrain/afterburner effects
    val phaseAnim = remember { Animatable(0f) }
    LaunchedEffect(batterySaver) {
        if (!batterySaver) {
            phaseAnim.animateTo(
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 2000, easing = LinearEasing)
                )
            )
        }
    }

    Box(
        modifier = modifier
            .background(InstrumentBlack)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    orbitAngleX = (orbitAngleX + dragAmount.x * 0.4f).coerceIn(-60f, 60f)
                    orbitAngleY = (orbitAngleY + dragAmount.y * 0.4f).coerceIn(-30f, 30f)
                }
            }
            .testTag("cockpit_visualizer_viewport")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val cx = width / 2f
            val cy = height / 2f
            val phase = phaseAnim.value

            when (telemetry.vehicleType) {
                VehicleType.NAVAL -> {
                    drawNavalVisualization(
                        telemetry = telemetry,
                        viewMode = viewMode,
                        phase = phase,
                        orbitX = orbitAngleX,
                        orbitY = orbitAngleY
                    )
                }
                VehicleType.ARMOURED -> {
                    drawArmouredVisualization(
                        telemetry = telemetry,
                        viewMode = viewMode,
                        phase = phase,
                        orbitX = orbitAngleX,
                        orbitY = orbitAngleY
                    )
                }
                VehicleType.AVIATION -> {
                    drawAviationVisualization(
                        telemetry = telemetry,
                        viewMode = viewMode,
                        phase = phase,
                        orbitX = orbitAngleX,
                        orbitY = orbitAngleY
                    )
                }
            }

            // Technical HUD Grid and Viewport Framing
            drawTechnicalHudFrame(width, height, telemetry, viewMode)
        }

        // Camera mode badge
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
                .background(InstrumentBlack.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CAM: ${viewMode.label}  // DRAG TO ORBIT",
                color = Titanium,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp
            )
        }
    }
}

// ==========================================
// 1. NAVAL BATTLESHIP RENDERER
// ==========================================
private fun DrawScope.drawNavalVisualization(
    telemetry: TelemetryPacket,
    viewMode: VisualizerViewMode,
    phase: Float,
    orbitX: Float,
    orbitY: Float
) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val speed = telemetry.speed
    val pitch = telemetry.pitchDeg
    val roll = telemetry.rollDeg
    val b1Flooding = telemetry.customMetrics["bilgeLevelB1Pct"] ?: 0f

    // Background ocean gradient
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF0A0F15),
                Color(0xFF101923),
                Color(0xFF0C131B)
            )
        )
    )

    // Animated ocean wave grid
    val waveSpacing = 32f
    val waveOffset = (phase * waveSpacing * (speed / 10f).coerceAtLeast(0.5f)) % waveSpacing
    for (y in (cy.toInt()..size.height.toInt() step waveSpacing.toInt())) {
        val yPos = y.toFloat()
        val waveAmplitude = 4f + (telemetry.seaStateOrTerrainIndex * 1.5f)
        val wavePath = Path()
        wavePath.moveTo(0f, yPos)
        var x = 0f
        while (x <= size.width) {
            val waveY = yPos + sin((x / 60f) + (phase * 2 * PI.toFloat())) * waveAmplitude
            wavePath.lineTo(x, waveY)
            x += 20f
        }
        val alpha = ((yPos - cy) / (size.height - cy)).coerceIn(0.1f, 0.45f)
        drawPath(
            path = wavePath,
            color = TechnicalBlue.copy(alpha = alpha),
            style = Stroke(width = 1f)
        )
    }

    // Wake trails behind ship
    if (speed > 2f) {
        val wakePath = Path()
        wakePath.moveTo(cx - 30f, cy + 40f)
        wakePath.lineTo(cx - 160f, size.height)
        wakePath.moveTo(cx + 30f, cy + 40f)
        wakePath.lineTo(cx + 160f, size.height)
        drawPath(
            path = wakePath,
            color = CoolWhite.copy(alpha = 0.25f),
            style = Stroke(width = 2f, cap = StrokeCap.Round)
        )
    }

    // Ship Hull & Superstructure (Transformed by pitch, roll, and touch orbit)
    val shipCenterY = cy + orbitY
    val shipCenterX = cx + orbitX
    val totalRotation = roll + (orbitX * 0.2f)

    rotate(degrees = totalRotation, pivot = Offset(shipCenterX, shipCenterY)) {
        if (viewMode == VisualizerViewMode.TOP_DOWN) {
            // Top-down naval planform
            drawNavalTopDown(shipCenterX, shipCenterY, b1Flooding)
        } else {
            // Isometric / 3D Chase Profile
            drawNavalSilhouetteProfile(
                cx = shipCenterX,
                cy = shipCenterY + (pitch * 2f),
                isCutaway = viewMode == VisualizerViewMode.CUTAWAY,
                b1Flooding = b1Flooding,
                radarAngle = phase * 360f
            )
        }
    }
}

private fun DrawScope.drawNavalSilhouetteProfile(
    cx: Float,
    cy: Float,
    isCutaway: Boolean,
    b1Flooding: Float,
    radarAngle: Float
) {
    val shipLength = 260f
    val shipHeight = 55f

    // Main Armor Belt & Hull Path
    val hull = Path().apply {
        moveTo(cx - shipLength / 2f + 25f, cy + 22f) // Stern
        lineTo(cx + shipLength / 2f - 30f, cy + 22f) // Keel
        lineTo(cx + shipLength / 2f, cy - 8f)        // Bow clipper rake
        lineTo(cx + shipLength / 2f - 35f, cy - 10f) // Forecastle
        lineTo(cx - shipLength / 2f + 15f, cy - 10f) // Quarterdeck
        lineTo(cx - shipLength / 2f, cy - 2f)        // Stern overhang
        close()
    }

    drawPath(
        path = hull,
        color = Color(0xFF1E2832)
    )
    drawPath(
        path = hull,
        color = Titanium,
        style = Stroke(width = 2f)
    )

    // Red Waterline Stripe
    drawLine(
        color = CriticalRed.copy(alpha = 0.85f),
        start = Offset(cx - shipLength / 2f + 10f, cy + 12f),
        end = Offset(cx + shipLength / 2f - 10f, cy + 12f),
        strokeWidth = 2.5f
    )

    // Superstructure & Bridge Citadel
    val bridge = Path().apply {
        moveTo(cx - 30f, cy - 10f)
        lineTo(cx - 20f, cy - 42f)
        lineTo(cx + 40f, cy - 42f) // Bridge deck
        lineTo(cx + 55f, cy - 10f) // Forward superstructure
        close()
    }
    drawPath(path = bridge, color = Color(0xFF283644))
    drawPath(path = bridge, color = TitaniumLight, style = Stroke(width = 1.5f))

    // Mast and Rotating Radar Scanner
    drawLine(
        color = TitaniumLight,
        start = Offset(cx + 10f, cy - 42f),
        end = Offset(cx + 10f, cy - 65f),
        strokeWidth = 2f
    )
    val radarLength = 22f * cos(Math.toRadians(radarAngle.toDouble())).toFloat()
    drawLine(
        color = TechnicalBlue,
        start = Offset(cx + 10f - radarLength, cy - 65f),
        end = Offset(cx + 10f + radarLength, cy - 65f),
        strokeWidth = 3f,
        cap = StrokeCap.Round
    )

    // Twin Funnel Stacks
    drawRect(
        color = Color(0xFF18222C),
        topLeft = Offset(cx - 15f, cy - 36f),
        size = Size(14f, 26f)
    )
    drawRect(
        color = Titanium,
        topLeft = Offset(cx - 15f, cy - 36f),
        size = Size(14f, 26f),
        style = Stroke(width = 1f)
    )

    // Main Gun Turrets (Forward & Aft)
    // Turret A (Fore)
    drawRect(
        color = Color(0xFF2F3E4D),
        topLeft = Offset(cx + 65f, cy - 20f),
        size = Size(24f, 10f)
    )
    drawLine(
        color = TitaniumLight,
        start = Offset(cx + 89f, cy - 16f),
        end = Offset(cx + 115f, cy - 18f),
        strokeWidth = 3f
    )
    // Turret Y (Aft)
    drawRect(
        color = Color(0xFF2F3E4D),
        topLeft = Offset(cx - 75f, cy - 20f),
        size = Size(24f, 10f)
    )
    drawLine(
        color = TitaniumLight,
        start = Offset(cx - 75f, cy - 16f),
        end = Offset(cx - 102f, cy - 18f),
        strokeWidth = 3f
    )

    // Cutaway view: Highlight watertight compartments inside the hull
    if (isCutaway) {
        val compartments: List<Triple<Float, String, SystemStatus>> = listOf(
            Triple(cx - 90f, "AFT STEER", SystemStatus.NORMAL),
            Triple(cx - 45f, "AUX PLANT", SystemStatus.NORMAL),
            Triple(
                cx,
                "ENG B1",
                if (b1Flooding > 30f) SystemStatus.WARNING else if (b1Flooding > 5f) SystemStatus.CAUTION else SystemStatus.NORMAL
            ),
            Triple(cx + 45f, "BOILER", SystemStatus.NORMAL),
            Triple(cx + 85f, "MAGAZINE", SystemStatus.NORMAL)
        )
        compartments.forEach { (compX, label, status) ->
            val boxColor = status.color
            drawRect(
                color = boxColor.copy(alpha = 0.25f),
                topLeft = Offset(compX - 18f, cy - 4f),
                size = Size(36f, 18f)
            )
            drawRect(
                color = boxColor,
                topLeft = Offset(compX - 18f, cy - 4f),
                size = Size(36f, 18f),
                style = Stroke(width = 1.2f)
            )
        }
    }
}

private fun DrawScope.drawNavalTopDown(cx: Float, cy: Float, b1Flooding: Float) {
    val shipPath = Path().apply {
        moveTo(cx, cy - 120f) // Bow
        cubicTo(cx + 35f, cy - 40f, cx + 38f, cy + 40f, cx + 28f, cy + 110f) // Stbd
        lineTo(cx - 28f, cy + 110f) // Transom
        cubicTo(cx - 38f, cy + 40f, cx - 35f, cy - 40f, cx, cy - 120f) // Port
        close()
    }
    drawPath(path = shipPath, color = Color(0xFF1E2832))
    drawPath(path = shipPath, color = TechnicalBlue, style = Stroke(width = 2f))

    // Compartment transverse bulkheads
    val b1Color = if (b1Flooding > 30f) CriticalRed else if (b1Flooding > 5f) AmberWarning else MutedGreen
    drawRect(
        color = b1Color.copy(alpha = 0.3f),
        topLeft = Offset(cx - 32f, cy - 10f),
        size = Size(64f, 40f)
    )
    drawRect(
        color = b1Color,
        topLeft = Offset(cx - 32f, cy - 10f),
        size = Size(64f, 40f),
        style = Stroke(width = 1.5f)
    )
}

// ==========================================
// 2. ARMOURED TANK RENDERER
// ==========================================
private fun DrawScope.drawArmouredVisualization(
    telemetry: TelemetryPacket,
    viewMode: VisualizerViewMode,
    phase: Float,
    orbitX: Float,
    orbitY: Float
) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val speed = telemetry.speed
    val pitch = telemetry.pitchDeg
    val roll = telemetry.rollDeg
    val suspension = telemetry.customMetrics["suspensionDeflectionMm"] ?: 120f

    // Desert / Tactical Terrain Background
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF0F1318),
                Color(0xFF1C222A),
                Color(0xFF13171E)
            )
        )
    )

    // Animated ground contour lines
    val groundY = cy + 45f + orbitY
    val terrainPath = Path().apply {
        moveTo(0f, groundY + 15f)
        var x = 0f
        while (x <= size.width) {
            val h = sin((x / 50f) + (phase * (speed / 15f).coerceAtLeast(0.3f))) * 6f
            lineTo(x, groundY + 15f + h)
            x += 25f
        }
        lineTo(size.width, size.height)
        lineTo(0f, size.height)
        close()
    }
    drawPath(path = terrainPath, color = Color(0xFF181F26))
    drawPath(path = terrainPath, color = TacticalPanelBorder, style = Stroke(width = 1.5f))

    // Dust particles kicked by tracks
    if (speed > 5f) {
        val dustCount = 8
        for (i in 0 until dustCount) {
            val dx = cx - 120f - (i * 18f) - (phase * 35f)
            val dy = groundY + 8f - (i * 3f)
            val radius = 6f + (i * 2.5f)
            drawCircle(
                color = Titanium.copy(alpha = (0.35f - (i * 0.04f)).coerceAtLeast(0.05f)),
                radius = radius,
                center = Offset(dx, dy)
            )
        }
    }

    // Vehicle Chassis and Turret transformed by pitch & roll
    val chassisX = cx + orbitX
    val chassisY = groundY - 18f + (pitch * 1.5f)

    rotate(degrees = roll * 0.6f, pivot = Offset(chassisX, chassisY)) {
        if (viewMode == VisualizerViewMode.TOP_DOWN) {
            drawArmouredTopDown(chassisX, chassisY, telemetry)
        } else {
            drawArmouredProfile(
                cx = chassisX,
                cy = chassisY,
                isCutaway = viewMode == VisualizerViewMode.CUTAWAY,
                speed = speed,
                phase = phase,
                suspensionDeflection = suspension,
                coolantTemp = telemetry.coolantTempC
            )
        }
    }
}

private fun DrawScope.drawArmouredProfile(
    cx: Float,
    cy: Float,
    isCutaway: Boolean,
    speed: Float,
    phase: Float,
    suspensionDeflection: Float,
    coolantTemp: Float
) {
    val tankW = 210f
    val tankH = 42f

    // Hull Lower Glacis & Upper Glacis Path
    val hull = Path().apply {
        moveTo(cx - tankW / 2f + 15f, cy + 5f)  // Rear lower hull
        lineTo(cx + tankW / 2f - 25f, cy + 5f)  // Front lower hull
        lineTo(cx + tankW / 2f, cy - 10f)       // Front upper glacis
        lineTo(cx + tankW / 2f - 40f, cy - 22f) // Forward hull deck
        lineTo(cx - tankW / 2f + 20f, cy - 22f) // Engine deck
        lineTo(cx - tankW / 2f, cy - 8f)        // Rear exhaust deck
        close()
    }
    drawPath(path = hull, color = Color(0xFF222B34))
    drawPath(path = hull, color = TitaniumLight, style = Stroke(width = 1.8f))

    // Turret & Main Gun
    val turret = Path().apply {
        moveTo(cx - 35f, cy - 22f)
        lineTo(cx - 25f, cy - 42f) // Turret bustle
        lineTo(cx + 35f, cy - 42f) // Turret roof
        lineTo(cx + 55f, cy - 22f) // Turret mantlet
        close()
    }
    drawPath(path = turret, color = Color(0xFF2C3742))
    drawPath(path = turret, color = TitaniumLight, style = Stroke(width = 1.8f))

    // 120mm Smoothbore Barrel & Thermal Sleeve
    drawLine(
        color = CoolWhite,
        start = Offset(cx + 55f, cy - 32f),
        end = Offset(cx + 145f, cy - 32f),
        strokeWidth = 4f,
        cap = StrokeCap.Square
    )
    // Bore Evacuator
    drawRect(
        color = Titanium,
        topLeft = Offset(cx + 95f, cy - 35f),
        size = Size(20f, 6f)
    )

    // Tracks and Roadwheels (Animated rotation with vehicle speed)
    val wheelRadius = 14f
    val numWheels = 6
    val wheelSpacing = 28f
    val startWheelX = cx - ((numWheels - 1) * wheelSpacing) / 2f

    // Track outer perimeter
    val trackBelt = Path().apply {
        addRoundRect(
            androidx.compose.ui.geometry.RoundRect(
                left = cx - tankW / 2f + 8f,
                top = cy - 2f,
                right = cx + tankW / 2f - 8f,
                bottom = cy + 26f,
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(14f, 14f)
            )
        )
    }
    drawPath(path = trackBelt, color = Color(0xFF141A21))
    drawPath(path = trackBelt, color = Titanium, style = Stroke(width = 2.5f))

    // Rotating roadwheels
    val wheelRotation = (phase * 360f * (speed / 20f).coerceAtLeast(0.1f)) % 360f
    for (i in 0 until numWheels) {
        val wx = startWheelX + (i * wheelSpacing)
        val wy = cy + 12f
        drawCircle(color = Color(0xFF1D252E), radius = wheelRadius, center = Offset(wx, wy))
        drawCircle(color = TitaniumLight, radius = wheelRadius, center = Offset(wx, wy), style = Stroke(width = 1.5f))
        drawCircle(color = TechnicalBlue, radius = 4f, center = Offset(wx, wy))

        // Wheel spoke indicator to show rotation
        rotate(degrees = wheelRotation, pivot = Offset(wx, wy)) {
            drawLine(
                color = CoolWhite.copy(alpha = 0.6f),
                start = Offset(wx, wy - wheelRadius + 2f),
                end = Offset(wx, wy + wheelRadius - 2f),
                strokeWidth = 1.2f
            )
        }
    }

    // Cutaway view: Highlight V12 Engine & Hydro-pneumatic Suspension
    if (isCutaway) {
        val engColor = if (coolantTemp > 105f) CriticalRed else MutedGreen
        drawRect(
            color = engColor.copy(alpha = 0.3f),
            topLeft = Offset(cx - tankW / 2f + 25f, cy - 20f),
            size = Size(50f, 18f)
        )
        drawRect(
            color = engColor,
            topLeft = Offset(cx - tankW / 2f + 25f, cy - 20f),
            size = Size(50f, 18f),
            style = Stroke(width = 1.5f)
        )
    }
}

private fun DrawScope.drawArmouredTopDown(cx: Float, cy: Float, telemetry: TelemetryPacket) {
    val tankW = 90f
    val tankL = 160f

    drawRect(
        color = Color(0xFF222B34),
        topLeft = Offset(cx - tankW / 2f, cy - tankL / 2f),
        size = Size(tankW, tankL)
    )
    drawRect(
        color = TitaniumLight,
        topLeft = Offset(cx - tankW / 2f, cy - tankL / 2f),
        size = Size(tankW, tankL),
        style = Stroke(width = 2f)
    )
    // Left & right tracks
    drawRect(color = Color(0xFF141A21), topLeft = Offset(cx - tankW / 2f - 14f, cy - tankL / 2f - 8f), size = Size(16f, tankL + 16f))
    drawRect(color = Color(0xFF141A21), topLeft = Offset(cx + tankW / 2f - 2f, cy - tankL / 2f - 8f), size = Size(16f, tankL + 16f))
    // Turret circle
    drawCircle(color = Color(0xFF2C3742), radius = 34f, center = Offset(cx, cy))
    drawCircle(color = TechnicalBlue, radius = 34f, center = Offset(cx, cy), style = Stroke(width = 2f))
    // Gun forward
    drawLine(color = CoolWhite, start = Offset(cx, cy - 34f), end = Offset(cx, cy - 110f), strokeWidth = 5f)
}

// ==========================================
// 3. AVIATION JET FIGHTER RENDERER
// ==========================================
private fun DrawScope.drawAviationVisualization(
    telemetry: TelemetryPacket,
    viewMode: VisualizerViewMode,
    phase: Float,
    orbitX: Float,
    orbitY: Float
) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val speed = telemetry.speed
    val pitch = telemetry.pitchDeg
    val roll = telemetry.rollDeg
    val altitude = telemetry.altitudeOrDepth
    val hydA = telemetry.customMetrics["hydCircuitA"] ?: 3000f

    // Stratospheric Sky Background
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF070B10),
                Color(0xFF0F1822),
                Color(0xFF0A1017)
            )
        )
    )

    // Moving high-altitude cloud horizon strips
    val cloudSpacing = 40f
    val cloudOffset = (phase * cloudSpacing * (speed / 100f).coerceAtLeast(1f)) % cloudSpacing
    for (i in 0..6) {
        val y = cy + 40f + (i * cloudSpacing) - cloudOffset
        val alpha = (0.25f - (i * 0.03f)).coerceIn(0.04f, 0.25f)
        drawLine(
            color = TechnicalBlue.copy(alpha = alpha),
            start = Offset(0f, y),
            end = Offset(size.width, y),
            strokeWidth = 1.5f
        )
    }

    // Jet Fighter Aircraft transformed by Pitch, Roll, and Touch Orbit
    val aircraftX = cx + orbitX
    val aircraftY = cy + orbitY - (pitch * 1.5f)
    val totalRoll = roll + (orbitX * 0.5f)

    rotate(degrees = totalRoll, pivot = Offset(aircraftX, aircraftY)) {
        if (viewMode == VisualizerViewMode.TOP_DOWN) {
            drawAviationTopDown(aircraftX, aircraftY, telemetry, phase)
        } else {
            drawAviationChaseProfile(
                cx = aircraftX,
                cy = aircraftY,
                isCutaway = viewMode == VisualizerViewMode.CUTAWAY,
                speed = speed,
                engineRpm = telemetry.engineRpm,
                phase = phase,
                hydAPsi = hydA
            )
        }
    }

    // HUD Flight Path Vector & Pitch Ladder
    drawFlightDirectorHUD(cx, cy, pitch, roll, telemetry)
}

private fun DrawScope.drawAviationChaseProfile(
    cx: Float,
    cy: Float,
    isCutaway: Boolean,
    speed: Float,
    engineRpm: Float,
    phase: Float,
    hydAPsi: Float
) {
    // Stealth Delta Wing / Twin Tail Profile
    val wingSpan = 180f
    val fuselageLen = 140f

    // Twin Afterburner Exhaust Cones
    val flameLength = (engineRpm / 100f) * 45f + (sin(phase * 2 * PI.toFloat()) * 5f)
    if (engineRpm > 75f) {
        val flameColor = if (engineRpm > 90f) AmberWarning else TechnicalBlue
        // Left Nozzle Flame
        drawOval(
            color = flameColor.copy(alpha = 0.85f),
            topLeft = Offset(cx - 24f - 6f, cy + 30f),
            size = Size(12f, flameLength)
        )
        // Right Nozzle Flame
        drawOval(
            color = flameColor.copy(alpha = 0.85f),
            topLeft = Offset(cx + 24f - 6f, cy + 30f),
            size = Size(12f, flameLength)
        )
    }

    // Main Airframe Silhouette
    val jet = Path().apply {
        moveTo(cx, cy - fuselageLen / 2f) // Radome nose
        lineTo(cx + 12f, cy - 20f)        // Canopy shoulder
        lineTo(cx + wingSpan / 2f, cy + 18f)// Starboard wingtip
        lineTo(cx + 38f, cy + 28f)        // Trailing edge
        lineTo(cx + 34f, cy + 34f)        // Starboard nozzle
        lineTo(cx - 34f, cy + 34f)        // Port nozzle
        lineTo(cx - 38f, cy + 28f)        // Port trailing edge
        lineTo(cx - wingSpan / 2f, cy + 18f)// Port wingtip
        lineTo(cx - 12f, cy - 20f)
        close()
    }

    drawPath(path = jet, color = Color(0xFF1C2530))
    drawPath(path = jet, color = TechnicalBlue, style = Stroke(width = 2f))

    // Twin Cant-Out Vertical Stabilizers
    drawLine(color = TitaniumLight, start = Offset(cx - 26f, cy + 10f), end = Offset(cx - 42f, cy - 20f), strokeWidth = 2.5f)
    drawLine(color = TitaniumLight, start = Offset(cx + 26f, cy + 10f), end = Offset(cx + 42f, cy - 20f), strokeWidth = 2.5f)

    // Cockpit Canopy Bubble
    val canopy = Path().apply {
        moveTo(cx, cy - 45f)
        lineTo(cx + 8f, cy - 18f)
        lineTo(cx - 8f, cy - 18f)
        close()
    }
    drawPath(path = canopy, color = TechnicalBlue.copy(alpha = 0.6f))
    drawPath(path = canopy, color = CoolWhite, style = Stroke(width = 1.2f))

    // Cutaway view: Highlight Twin Turbofans & Hydraulic Lines
    if (isCutaway) {
        val hydColor = if (hydAPsi < 2000f) CriticalRed else MutedGreen
        // Left Engine & Hyd Circuit A
        drawRect(
            color = hydColor.copy(alpha = 0.35f),
            topLeft = Offset(cx - 28f, cy - 5f),
            size = Size(20f, 32f)
        )
        drawRect(
            color = hydColor,
            topLeft = Offset(cx - 28f, cy - 5f),
            size = Size(20f, 32f),
            style = Stroke(width = 1.5f)
        )
        // Right Engine
        drawRect(
            color = MutedGreen.copy(alpha = 0.35f),
            topLeft = Offset(cx + 8f, cy - 5f),
            size = Size(20f, 32f)
        )
        drawRect(
            color = MutedGreen,
            topLeft = Offset(cx + 8f, cy - 5f),
            size = Size(20f, 32f),
            style = Stroke(width = 1.5f)
        )
    }
}

private fun DrawScope.drawAviationTopDown(cx: Float, cy: Float, telemetry: TelemetryPacket, phase: Float) {
    drawAviationChaseProfile(cx, cy, false, telemetry.speed, telemetry.engineRpm, phase, 3000f)
}

private fun DrawScope.drawFlightDirectorHUD(cx: Float, cy: Float, pitch: Float, roll: Float, telemetry: TelemetryPacket) {
    // Pitch Ladder Lines
    val ladderSpacing = 24f
    for (i in -2..2) {
        if (i == 0) continue
        val y = cy + (i * ladderSpacing) + (pitch * 1.5f)
        val deg = -i * 10
        drawLine(
            color = TechnicalBlue.copy(alpha = 0.5f),
            start = Offset(cx - 35f, y),
            end = Offset(cx - 15f, y),
            strokeWidth = 1.5f
        )
        drawLine(
            color = TechnicalBlue.copy(alpha = 0.5f),
            start = Offset(cx + 15f, y),
            end = Offset(cx + 35f, y),
            strokeWidth = 1.5f
        )
    }

    // Velocity Vector Symbol (Flight Path Marker)
    val vvx = cx
    val vvy = cy + (pitch * 0.8f)
    drawCircle(color = MutedGreen, radius = 5f, center = Offset(vvx, vvy), style = Stroke(width = 1.5f))
    drawLine(color = MutedGreen, start = Offset(vvx - 12f, vvy), end = Offset(vvx - 5f, vvy), strokeWidth = 1.5f)
    drawLine(color = MutedGreen, start = Offset(vvx + 5f, vvy), end = Offset(vvx + 12f, vvy), strokeWidth = 1.5f)
    drawLine(color = MutedGreen, start = Offset(vvx, vvy - 5f), end = Offset(vvx, vvy - 10f), strokeWidth = 1.5f)
}

// ==========================================
// TECHNICAL HUD RETICLE & BORDER FRAME
// ==========================================
private fun DrawScope.drawTechnicalHudFrame(width: Float, height: Float, telemetry: TelemetryPacket, viewMode: VisualizerViewMode) {
    val cornerLen = 18f
    val strokeW = 1.5f
    val frameColor = TitaniumLight.copy(alpha = 0.6f)

    // Four HUD Corner Marks
    // Top-Left
    drawLine(frameColor, Offset(10f, 10f), Offset(10f + cornerLen, 10f), strokeW)
    drawLine(frameColor, Offset(10f, 10f), Offset(10f, 10f + cornerLen), strokeW)
    // Top-Right
    drawLine(frameColor, Offset(width - 10f, 10f), Offset(width - 10f - cornerLen, 10f), strokeW)
    drawLine(frameColor, Offset(width - 10f, 10f), Offset(width - 10f, 10f + cornerLen), strokeW)
    // Bottom-Left
    drawLine(frameColor, Offset(10f, height - 10f), Offset(10f + cornerLen, height - 10f), strokeW)
    drawLine(frameColor, Offset(10f, height - 10f), Offset(10f, height - 10f - cornerLen), strokeW)
    // Bottom-Right
    drawLine(frameColor, Offset(width - 10f, height - 10f), Offset(width - 10f - cornerLen, height - 10f), strokeW)
    drawLine(frameColor, Offset(width - 10f, height - 10f), Offset(width - 10f, height - 10f - cornerLen), strokeW)

    // Center Crosshairs
    val cx = width / 2f
    val cy = height / 2f
    drawLine(Titanium.copy(alpha = 0.35f), Offset(cx - 15f, cy), Offset(cx + 15f, cy), 1f)
    drawLine(Titanium.copy(alpha = 0.35f), Offset(cx, cy - 15f), Offset(cx, cy + 15f), 1f)
}
