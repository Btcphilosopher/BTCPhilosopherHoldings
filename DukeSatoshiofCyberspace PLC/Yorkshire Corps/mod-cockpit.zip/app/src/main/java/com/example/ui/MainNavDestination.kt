package com.example.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.School
import androidx.compose.ui.graphics.vector.ImageVector

enum class MainNavDestination(
    val title: String,
    val icon: ImageVector,
    val tag: String
) {
    HANGAR("Hangar", Icons.Default.DirectionsBoat, "nav_item_hangar"),
    COCKPIT("Cockpit", Icons.Default.Dashboard, "nav_item_cockpit"),
    SYSTEMS("Systems", Icons.Default.Build, "nav_item_systems"),
    MISSIONS("Missions", Icons.Default.School, "nav_item_missions"),
    RECORDS("Records", Icons.Default.History, "nav_item_records")
}
