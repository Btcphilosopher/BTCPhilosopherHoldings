package com.example.core.model

enum class VehicleType(
    val title: String,
    val categoryLabel: String,
    val designation: String,
    val primaryDomain: String
) {
    NAVAL(
        title = "HMS Vanguard",
        categoryLabel = "Naval Systems",
        designation = "BB-23",
        primaryDomain = "Surface Warfare & Maritime Navigation"
    ),
    ARMOURED(
        title = "MBT-90 Centurion",
        categoryLabel = "Armoured Systems",
        designation = "MBT-90",
        primaryDomain = "Ground Mobility & Powertrain Simulation"
    ),
    AVIATION(
        title = "XF-41 Tempest",
        categoryLabel = "Aviation Systems",
        designation = "XF-41",
        primaryDomain = "Atmospheric Flight & Avionics Envelope"
    )
}

data class VehicleProfile(
    val type: VehicleType,
    val callsign: String,
    val simulatedReadinessPct: Int,
    val overallHealthPct: Int,
    val activeProfile: String,
    val massTons: Float,
    val powerPlantDescription: String,
    val topSpeedDisplay: String,
    val operationalRangeDisplay: String,
    val simulationNotes: String
)

object VehicleRegistry {
    val profiles = listOf(
        VehicleProfile(
            type = VehicleType.NAVAL,
            callsign = "Vanguard Lead",
            simulatedReadinessPct = 98,
            overallHealthPct = 96,
            activeProfile = "MOD Naval Architecture Sim v3.8",
            massTons = 44500f,
            powerPlantDescription = "4x Steam Turbines / High-Pressure Marine Boilers (130,000 SHP)",
            topSpeedDisplay = "31.5 Knots",
            operationalRangeDisplay = "8,500 NM @ 15 kts",
            simulationNotes = "Full hydrodynamics with compartmental flooding, dual shaft propulsion and DC alert training."
        ),
        VehicleProfile(
            type = VehicleType.ARMOURED,
            callsign = "Ironclad 1-1",
            simulatedReadinessPct = 94,
            overallHealthPct = 92,
            activeProfile = "Armoured Powertrain Dynamics v2.4",
            massTons = 62.5f,
            powerPlantDescription = "V12 Twin-Turbocharged Multi-Fuel Diesel (1,500 BHP @ 2600 RPM)",
            topSpeedDisplay = "72 km/h (Road) / 48 km/h (Cross-Country)",
            operationalRangeDisplay = "550 km (Internal Fuel)",
            simulationNotes = "Hydro-pneumatic suspension deflection, transmission thermal curve and slope mobility simulation."
        ),
        VehicleProfile(
            type = VehicleType.AVIATION,
            callsign = "Viper 04",
            simulatedReadinessPct = 99,
            overallHealthPct = 97,
            activeProfile = "AeroDynamic Flight Envelope v4.1",
            massTons = 19.8f,
            powerPlantDescription = "Twin Afterburning Low-Bypass Turbofans (2x 28,000 lbf Wet)",
            topSpeedDisplay = "Mach 2.15 (1,430 kts at 36,000 ft)",
            operationalRangeDisplay = "1,850 km Combat Radius",
            simulationNotes = "Fly-by-wire stability simulation, dual hydraulic circuits and dynamic G-limiter modeling."
        )
    )

    fun getProfile(type: VehicleType): VehicleProfile {
        return profiles.firstOrNull { it.type == type } ?: profiles[0]
    }
}
