package com.example.core.simulation

import com.example.core.model.FaultInjection
import com.example.core.model.SubsystemHealth
import com.example.core.model.TelemetryPacket
import com.example.core.model.TrainingScenario
import com.example.core.model.VehicleProfile

interface VehicleSimulation {
    val vehicleProfile: VehicleProfile
    fun initialize(scenario: TrainingScenario? = null)
    fun step(deltaTimeSec: Float, throttleInput: Float, steeringInput: Float, secondaryInput: Float)
    fun injectFault(fault: FaultInjection)
    fun clearFault(faultId: String)
    fun getTelemetry(): TelemetryPacket
    fun getSubsystems(): List<SubsystemHealth>
    fun reset()
}
