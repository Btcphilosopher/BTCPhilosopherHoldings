package com.example.core.simulation

import com.example.core.model.FaultInjection
import com.example.core.model.StandardFaults
import com.example.core.model.SubsystemCategory
import com.example.core.model.SubsystemHealth
import com.example.core.model.SystemStatus
import com.example.core.model.TelemetryPacket
import com.example.core.model.TrainingScenario
import com.example.core.model.VehicleProfile
import com.example.core.model.VehicleRegistry
import com.example.core.model.VehicleType
import kotlin.math.cos
import kotlin.math.sin

class ArmouredSimulation : VehicleSimulation {
    override val vehicleProfile: VehicleProfile = VehicleRegistry.getProfile(VehicleType.ARMOURED)

    private var simulationTimeSec = 0f
    private var speedKmh = 34.0f
    private var headingDeg = 045f
    private var engineRpm = 1950f
    private var gear = 4 // 1 to 6
    private var pitchDeg = 3.8f
    private var rollDeg = 1.5f
    private var coolantTempC = 91f
    private var oilPressureBar = 4.8f
    private var fuelRemainingPct = 78f
    private var busVoltageV = 27.8f
    private var apuActive = true
    private var trackTensionKn = 45f
    private var trackSlipPct = 4.2f
    private var suspensionDeflectionMm = 120f
    private var altitudeM = 310f
    private var exhaustTempC = 540f
    private var radiatorBypassActive = false

    private val activeFaults = mutableMapOf<String, FaultInjection>()
    private val alertList = mutableListOf<String>()

    override fun initialize(scenario: TrainingScenario?) {
        reset()
        scenario?.initialFaultId?.let { faultId ->
            StandardFaults.faults.find { it.id == faultId }?.let { injectFault(it) }
        }
    }

    override fun reset() {
        simulationTimeSec = 0f
        speedKmh = 34.0f
        headingDeg = 045f
        engineRpm = 1950f
        gear = 4
        pitchDeg = 3.8f
        rollDeg = 1.5f
        coolantTempC = 91f
        oilPressureBar = 4.8f
        fuelRemainingPct = 78f
        busVoltageV = 27.8f
        apuActive = true
        trackTensionKn = 45f
        trackSlipPct = 4.2f
        suspensionDeflectionMm = 120f
        altitudeM = 310f
        exhaustTempC = 540f
        radiatorBypassActive = false
        activeFaults.clear()
        alertList.clear()
    }

    override fun injectFault(fault: FaultInjection) {
        activeFaults[fault.id] = fault
        if (!alertList.contains(fault.title)) {
            alertList.add(fault.title)
        }
    }

    override fun clearFault(faultId: String) {
        activeFaults.remove(faultId)?.let {
            alertList.remove(it.title)
        }
    }

    fun toggleRadiatorBypass(active: Boolean) {
        radiatorBypassActive = active
    }

    fun toggleApu(active: Boolean) {
        apuActive = active
    }

    override fun step(
        deltaTimeSec: Float,
        throttleInput: Float, // 0.0 to 1.0 (Accelerator pedal)
        steeringInput: Float, // -1.0 (Pivot Left) to +1.0 (Pivot Right)
        secondaryInput: Float // Brake / Gear override
    ) {
        val dt = deltaTimeSec.coerceIn(0.001f, 0.1f)
        simulationTimeSec += dt

        // 1. Engine & Gear Selection
        val maxSpeedPerGear = listOf(0f, 12f, 24f, 40f, 56f, 68f, 74f)
        val targetSpeed = throttleInput * 72f * (1.0f - (secondaryInput.coerceIn(0f, 1f) * 0.9f))
        
        // Auto transmission shift logic
        gear = when {
            speedKmh < 8f -> 1
            speedKmh < 18f -> 2
            speedKmh < 32f -> 3
            speedKmh < 48f -> 4
            speedKmh < 62f -> 5
            else -> 6
        }

        // Engine RPM calculation based on gear and speed
        val gearRatioSpeed = (speedKmh / maxSpeedPerGear[gear]).coerceIn(0.1f, 1.0f)
        val idleRpm = 800f
        val peakRpm = 2600f
        val calculatedRpm = idleRpm + (peakRpm - idleRpm) * (gearRatioSpeed * 0.7f + throttleInput * 0.3f)
        engineRpm += (calculatedRpm - engineRpm) * 3f * dt

        // Speed acceleration and rolling resistance
        val accelRate = (throttleInput * 14f) - (speedKmh * 0.15f) - (secondaryInput * 25f)
        speedKmh = (speedKmh + accelRate * dt).coerceIn(0f, 74f)

        // 2. Track & Steering Dynamics
        val steerRate = steeringInput * 22f // deg/sec pivot turn
        headingDeg = (headingDeg + steerRate * dt + 360f) % 360f

        // Track tension fault impact
        if (activeFaults.containsKey("AR_TRACK_TENS")) {
            trackTensionKn = (trackTensionKn - 3f * dt).coerceAtLeast(18f)
            trackSlipPct = 14.5f + sin(simulationTimeSec * 4f) * 2f
            if (!alertList.contains("LEFT TRACK TENSION LOW")) alertList.add("LEFT TRACK TENSION LOW")
        } else {
            trackTensionKn += (45f - trackTensionKn) * 0.5f * dt
            trackSlipPct = (4.2f + (speedKmh / 70f) * 3f)
        }

        // 3. Thermal Dynamics (Cooling leak fault)
        if (activeFaults.containsKey("AR_COOL_PUMP")) {
            val heatingFactor = if (radiatorBypassActive) 0.6f else 2.2f
            coolantTempC = (coolantTempC + heatingFactor * dt).coerceAtMost(118f)
            if (coolantTempC > 105f && !alertList.contains("ENGINE COOLANT OVERHEAT")) {
                alertList.add("ENGINE COOLANT OVERHEAT")
            }
        } else {
            val normalTarget = 88f + (throttleInput * 12f)
            coolantTempC += (normalTarget - coolantTempC) * 0.2f * dt
            alertList.remove("ENGINE COOLANT OVERHEAT")
        }

        // 4. Terrain & Suspension Response
        val terrainFrequency = (speedKmh / 15f).coerceAtLeast(0.5f)
        pitchDeg = 3.5f + 4f * sin(simulationTimeSec * terrainFrequency) + (accelRate * 0.15f)
        rollDeg = 1.2f + 2.5f * cos(simulationTimeSec * terrainFrequency * 0.8f) - (steeringInput * 3.5f)
        suspensionDeflectionMm = 120f + 55f * sin(simulationTimeSec * terrainFrequency * 1.5f)

        // 5. Electrical & APU
        if (activeFaults.containsKey("AR_APU_FAIL")) {
            apuActive = false
            busVoltageV = (busVoltageV - 0.15f * dt).coerceAtLeast(23.2f)
            if (!alertList.contains("APU SHUTDOWN // BATT DRAW")) alertList.add("APU SHUTDOWN // BATT DRAW")
        } else {
            busVoltageV += (28.2f - busVoltageV) * 0.3f * dt
            alertList.remove("APU SHUTDOWN // BATT DRAW")
        }

        // Fuel burn
        fuelRemainingPct = (fuelRemainingPct - (throttleInput * 0.008f * dt)).coerceAtLeast(4f)
    }

    override fun getTelemetry(): TelemetryPacket {
        val overallIntegrity = (98f - (activeFaults.size * 8f) - (if (coolantTempC > 105f) 12f else 0f)).coerceIn(15f, 100f)
        val caution = activeFaults.values.any { it.severity == SystemStatus.CAUTION } || coolantTempC > 100f
        val warning = activeFaults.values.any { it.severity == SystemStatus.WARNING } || coolantTempC > 110f || trackTensionKn < 22f

        return TelemetryPacket(
            timestampMs = System.currentTimeMillis(),
            simulationTimeSec = simulationTimeSec,
            vehicleType = VehicleType.ARMOURED,
            speed = speedKmh,
            headingDeg = headingDeg,
            altitudeOrDepth = altitudeM,
            pitchDeg = pitchDeg,
            rollDeg = rollDeg,
            rateOfTurnDegPerSec = 0f,
            engineRpm = engineRpm,
            engineLoadPct = (engineRpm / 2600f) * 100f,
            coolantTempC = coolantTempC,
            oilPressureBar = oilPressureBar,
            fuelRemainingPct = fuelRemainingPct,
            fuelFlowRate = (engineRpm / 2600f) * 65f,
            busVoltageV = busVoltageV,
            powerGeneratedKw = if (apuActive) 18.5f else 4.0f,
            batteryReservePct = 94f,
            hydraulicPressurePsi = 1800f,
            overallIntegrityPct = overallIntegrity,
            ambientTempC = 22f,
            seaStateOrTerrainIndex = 3,
            customMetrics = mapOf(
                "gearSelection" to gear.toFloat(),
                "suspensionDeflectionMm" to suspensionDeflectionMm,
                "trackTensionKn" to trackTensionKn,
                "trackSlipPct" to trackSlipPct,
                "apuStatus" to if (apuActive) 1f else 0f,
                "exhaustTempC" to exhaustTempC,
                "radiatorBypass" to if (radiatorBypassActive) 1f else 0f
            ),
            activeAlerts = alertList.toList(),
            masterCautionActive = caution,
            masterWarningActive = warning
        )
    }

    override fun getSubsystems(): List<SubsystemHealth> {
        val coolStatus = when {
            coolantTempC > 110f -> SystemStatus.WARNING
            coolantTempC > 100f -> SystemStatus.CAUTION
            else -> SystemStatus.NORMAL
        }
        val trackStatus = if (trackTensionKn < 25f) SystemStatus.CAUTION else SystemStatus.NORMAL
        val apuStatus = if (!apuActive) SystemStatus.CAUTION else SystemStatus.NORMAL

        return listOf(
            SubsystemHealth(
                id = "ar_thermal_cool",
                name = "V12 Powertrain Cooling & Radiators",
                category = SubsystemCategory.THERMAL,
                status = coolStatus,
                currentValue = coolantTempC,
                unit = "°C",
                expectedMin = 80f,
                expectedMax = 95f,
                warningThreshold = 102f,
                criticalThreshold = 112f,
                diagnosticSummary = if (coolStatus != SystemStatus.NORMAL) "Radiator fan hydrostatic pressure drop. Engine block temperature elevated." else "Twin suction radiator fans operating nominally; coolant within limits.",
                trainingRecommendation = if (coolStatus != SystemStatus.NORMAL) "Engage secondary electric radiator bypass; limit RPM under 1800." else "Maintain scheduled cross-country speed."
            ),
            SubsystemHealth(
                id = "ar_mob_track",
                name = "Hydro-Pneumatic Suspension & Track Tension",
                category = SubsystemCategory.PROPULSION,
                status = trackStatus,
                currentValue = trackTensionKn,
                unit = "kN",
                expectedMin = 40f,
                expectedMax = 50f,
                warningThreshold = 30f,
                criticalThreshold = 20f,
                diagnosticSummary = if (trackStatus != SystemStatus.NORMAL) "Hydraulic track tensioner relief vented. Track slack exceeds 65mm." else "8 dual roadwheel stations balanced; track tension within nominal specification.",
                trainingRecommendation = if (trackStatus != SystemStatus.NORMAL) "Reduce speed below 20 km/h; avoid tight pivot turns." else "Nominal ground mobility."
            ),
            SubsystemHealth(
                id = "ar_elec_apu",
                name = "28V DC Electrical Bus & APU",
                category = SubsystemCategory.ELECTRICAL,
                status = apuStatus,
                currentValue = busVoltageV,
                unit = "V",
                expectedMin = 26.5f,
                expectedMax = 28.5f,
                warningThreshold = 24.5f,
                criticalThreshold = 22.0f,
                diagnosticSummary = if (apuStatus != SystemStatus.NORMAL) "Auxiliary Power Unit offline. High load drawing down main battery bank." else "APU running; 28V DC regulated bus supplying fire control and radio.",
                trainingRecommendation = if (apuStatus != SystemStatus.NORMAL) "Start main engine generator or restart APU sequence." else "Standard silent watch configuration."
            ),
            SubsystemHealth(
                id = "ar_mob_trans",
                name = "Powershift Automatic Transmission",
                category = SubsystemCategory.PROPULSION,
                status = SystemStatus.NORMAL,
                currentValue = gear.toFloat(),
                unit = "GEAR",
                expectedMin = 1f,
                expectedMax = 6f,
                warningThreshold = 6.5f,
                criticalThreshold = 7f,
                diagnosticSummary = "Hydraulic torque converter locked up in Gear $gear.",
                trainingRecommendation = "Normal transmission shifting profile."
            )
        )
    }
}
