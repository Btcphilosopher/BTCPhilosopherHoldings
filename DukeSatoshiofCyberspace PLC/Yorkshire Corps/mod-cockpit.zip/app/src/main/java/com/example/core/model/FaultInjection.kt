package com.example.core.model

data class FaultInjection(
    val id: String,
    val title: String,
    val vehicleType: VehicleType,
    val affectedSubsystemId: String,
    val severity: SystemStatus,
    val description: String,
    val symptoms: String,
    val trainingProcedure: String
)

object StandardFaults {
    val faults = listOf(
        // Naval Faults
        FaultInjection(
            id = "NV_GEN_DEG",
            title = "Ship Service Diesel Generator 2 Degradation",
            vehicleType = VehicleType.NAVAL,
            affectedSubsystemId = "nv_elec_gen2",
            severity = SystemStatus.CAUTION,
            description = "Main bus voltage drops from 440V to 408V due to fuel injection imbalance.",
            symptoms = "Bus voltage fluctuation, generator load transfer alert.",
            trainingProcedure = "Shed secondary hotel loads and switch to Auxiliary Gas Turbine Gen 3."
        ),
        FaultInjection(
            id = "NV_FLOOD_B1",
            title = "Compartment B1 Engine Room Flooding Alert",
            vehicleType = VehicleType.NAVAL,
            affectedSubsystemId = "nv_hull_b1",
            severity = SystemStatus.WARNING,
            description = "Sea-chest strainer seal failure. Water ingress rate 180 L/min in main engine space.",
            symptoms = "High bilge alarm, hull integrity drop to 76%, minor list angle.",
            trainingProcedure = "Isolate sea-chest valve, start Emergency Bilge Pump 2, verify watertight bulkhead B-C seal."
        ),
        FaultInjection(
            id = "NV_PROP_COOL",
            title = "Port Shaft Bearing Temperature Excursion",
            vehicleType = VehicleType.NAVAL,
            affectedSubsystemId = "nv_prop_shaft",
            severity = SystemStatus.CAUTION,
            description = "Lubricant cooling flow restricted; port shaft bearing temp exceeds 92°C.",
            symptoms = "Lube oil pressure drops to 2.1 bar, bearing temp rising.",
            trainingProcedure = "Reduce port engine telegraph to Half Ahead, activate cross-connect cooling line."
        ),

        // Armoured Faults
        FaultInjection(
            id = "AR_COOL_PUMP",
            title = "Cooling Fan Hydraulic Drive Leak",
            vehicleType = VehicleType.ARMOURED,
            affectedSubsystemId = "ar_thermal_cool",
            severity = SystemStatus.WARNING,
            description = "Hydrostatic cooling circuit loses pressure, radiator airflow drops by 65%.",
            symptoms = "Engine coolant temp rises above 108°C, thermal derate warning.",
            trainingProcedure = "Limit engine RPM below 1800, stop in defilade, activate secondary electric radiator bypass."
        ),
        FaultInjection(
            id = "AR_TRACK_TENS",
            title = "Left Track Tensioner Relief Blowoff",
            vehicleType = VehicleType.ARMOURED,
            affectedSubsystemId = "ar_mob_track",
            severity = SystemStatus.CAUTION,
            description = "Hydraulic track tensioner loses pressure over uneven terrain; slack increases track throw risk.",
            symptoms = "Track slip ratio increases to 14%, audible vibration, steering yaw bias.",
            trainingProcedure = "Reduce speed to 15 km/h, avoid sharp pivot turns, engage mechanical tension lock."
        ),
        FaultInjection(
            id = "AR_APU_FAIL",
            title = "Auxiliary Power Unit Fuel Starvation",
            vehicleType = VehicleType.ARMOURED,
            affectedSubsystemId = "ar_elec_apu",
            severity = SystemStatus.CAUTION,
            description = "APU shuts down unexpectedly; silent watch electrical draw shifts to main battery bank.",
            symptoms = "Battery voltage decreases towards 23.5V, APU offline alert.",
            trainingProcedure = "Start main V12 engine to charge battery banks or cycle APU fuel primer."
        ),

        // Aviation Faults
        FaultInjection(
            id = "AV_HYD_A_LEAK",
            title = "Hydraulic Circuit A Pressure Loss",
            vehicleType = VehicleType.AVIATION,
            affectedSubsystemId = "av_hyd_circuit_a",
            severity = SystemStatus.WARNING,
            description = "System A hydraulic manifold line leak. Pressure falls below 1,800 psi.",
            symptoms = "Master Caution chime, secondary flight control actuator fallback to Circuit B.",
            trainingProcedure = "Isolate Hyd Circuit A shutoff valve, observe Circuit B 3,000 psi stability, limit high-G maneuvers."
        ),
        FaultInjection(
            id = "AV_TIT_OVERHEAT",
            title = "Turbine Inlet Temperature Excursion",
            vehicleType = VehicleType.AVIATION,
            affectedSubsystemId = "av_eng_turbine",
            severity = SystemStatus.WARNING,
            description = "Right turbofan variable bleed valve stuck closed at high altitude.",
            symptoms = "Turbine temp spikes to 980°C, engine vibration index increases to 2.8.",
            trainingProcedure = "Retard right throttle lever to 70%, disengage afterburner, verify nozzle divergence."
        ),
        FaultInjection(
            id = "AV_SENSOR_PITOT",
            title = "Pitot-Static Tube Icing & Airspeed Inconsistency",
            vehicleType = VehicleType.AVIATION,
            affectedSubsystemId = "av_nav_pitot",
            severity = SystemStatus.CAUTION,
            description = "Left pitot tube moisture freezing; airspeed reading diverges by 45 knots from GPS ground speed.",
            symptoms = "Airspeed unreliable flag, flight director caution, cross-check warning.",
            trainingProcedure = "Engage Pitot Heat High mode, cross-check pitch and power attitude instruments."
        )
    )

    fun getFaultsFor(type: VehicleType): List<FaultInjection> {
        return faults.filter { it.vehicleType == type }
    }
}
