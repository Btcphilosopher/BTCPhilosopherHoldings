package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.VehicleType
import com.example.ui.MainNavDestination
import com.example.ui.screens.CockpitScreen
import com.example.ui.screens.HangarScreen
import com.example.ui.screens.MissionsScreen
import com.example.ui.screens.RecordsScreen
import com.example.ui.screens.SystemsScreen
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoolWhite
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.DeepGraphite
import com.example.ui.theme.InstrumentBlack
import com.example.ui.theme.ModCockpitTheme
import com.example.ui.theme.MutedGreen
import com.example.ui.theme.TacticalPanelBorder
import com.example.ui.theme.TechnicalBlue
import com.example.ui.theme.Titanium
import com.example.ui.viewmodel.CockpitViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: CockpitViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ModCockpitTheme {
                MainAppShell(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppShell(viewModel: CockpitViewModel) {
    var currentDestination by remember { mutableStateOf(MainNavDestination.COCKPIT) }

    val vehicleType by viewModel.selectedVehicleType.collectAsState()
    val telemetry by viewModel.telemetry.collectAsState()
    val subsystems by viewModel.subsystems.collectAsState()
    val layoutMode by viewModel.layoutMode.collectAsState()
    val visualizerViewMode by viewModel.visualizerViewMode.collectAsState()

    val throttle by viewModel.throttle.collectAsState()
    val steering by viewModel.steering.collectAsState()
    val secondary by viewModel.secondary.collectAsState()
    val sub1Active by viewModel.subsystem1Active.collectAsState()
    val sub2Active by viewModel.subsystem2Active.collectAsState()

    val activeScenario by viewModel.activeScenario.collectAsState()
    val scenarioElapsedSec by viewModel.scenarioElapsedSec.collectAsState()
    val scenarioScore by viewModel.scenarioScore.collectAsState()
    val scenarioDebrief by viewModel.scenarioDebrief.collectAsState()

    val pastSessions by viewModel.pastSessions.collectAsState()
    val speedHistory by viewModel.speedHistory.collectAsState()
    val rpmHistory by viewModel.rpmHistory.collectAsState()

    val isReplayMode by viewModel.isReplayMode.collectAsState()
    val replaySamples by viewModel.replaySamples.collectAsState()
    val scrubIndex by viewModel.replayScrubIndex.collectAsState()

    // Handle back button to return to Cockpit if on secondary screens
    if (currentDestination != MainNavDestination.COCKPIT) {
        BackHandler {
            currentDestination = MainNavDestination.COCKPIT
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(InstrumentBlack),
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopSimulationHeader(
                activeVehicle = vehicleType,
                cautionActive = telemetry.masterCautionActive,
                warningActive = telemetry.masterWarningActive
            )
        },
        bottomBar = {
            BottomTacticalNav(
                currentDestination = currentDestination,
                onSelectDestination = { dest ->
                    currentDestination = dest
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(InstrumentBlack)
        ) {
            when (currentDestination) {
                MainNavDestination.HANGAR -> {
                    HangarScreen(
                        currentVehicleType = vehicleType,
                        onSelectVehicle = { type ->
                            viewModel.switchVehicle(type)
                        },
                        onEnterCockpit = {
                            currentDestination = MainNavDestination.COCKPIT
                        }
                    )
                }
                MainNavDestination.COCKPIT -> {
                    CockpitScreen(
                        telemetry = telemetry,
                        subsystems = subsystems,
                        layoutMode = layoutMode,
                        visualizerViewMode = visualizerViewMode,
                        speedHistory = speedHistory,
                        rpmHistory = rpmHistory,
                        throttle = throttle,
                        steering = steering,
                        secondary = secondary,
                        subsystem1Active = sub1Active,
                        subsystem2Active = sub2Active,
                        onThrottleChange = { viewModel.setThrottle(it) },
                        onSteeringChange = { viewModel.setSteering(it) },
                        onSecondaryChange = { viewModel.setSecondary(it) },
                        onToggleSubsystem1 = { viewModel.toggleSubsystem1() },
                        onToggleSubsystem2 = { viewModel.toggleSubsystem2() },
                        onLayoutModeChange = { viewModel.setLayoutMode(it) },
                        onVisualizerViewModeChange = { viewModel.setVisualizerViewMode(it) },
                        onAcknowledgeAlerts = { viewModel.acknowledgeAlerts() }
                    )
                }
                MainNavDestination.SYSTEMS -> {
                    SystemsScreen(
                        vehicleType = vehicleType,
                        subsystems = subsystems,
                        onInjectFault = { viewModel.injectFault(it) },
                        onClearFault = { viewModel.clearFault(it) }
                    )
                }
                MainNavDestination.MISSIONS -> {
                    MissionsScreen(
                        currentVehicleType = vehicleType,
                        activeScenario = activeScenario,
                        scenarioElapsedSec = scenarioElapsedSec,
                        scenarioScore = scenarioScore,
                        scenarioDebrief = scenarioDebrief,
                        onStartScenario = { viewModel.startScenario(it) },
                        onEndScenario = { viewModel.endScenario() },
                        onEnterCockpit = { currentDestination = MainNavDestination.COCKPIT }
                    )
                }
                MainNavDestination.RECORDS -> {
                    RecordsScreen(
                        sessions = pastSessions,
                        isReplayMode = isReplayMode,
                        replaySamples = replaySamples,
                        scrubIndex = scrubIndex,
                        onStartReplay = { viewModel.startReplaySession(it) },
                        onScrubReplay = { viewModel.scrubReplay(it) },
                        onExitReplay = { viewModel.exitReplayMode() },
                        onEnterCockpit = { currentDestination = MainNavDestination.COCKPIT }
                    )
                }
            }
        }
    }
}

@Composable
fun TopSimulationHeader(
    activeVehicle: VehicleType,
    cautionActive: Boolean,
    warningActive: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepGraphite)
            .border(0.8.dp, TacticalPanelBorder)
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("top_simulation_header")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "MOD COCKPIT",
                    color = CoolWhite,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "// ${activeVehicle.designation}",
                    color = TechnicalBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp
                )
            }

            // Conspicuous SIMULATION MODE Indicator (Directive requirement)
            Box(
                modifier = Modifier
                    .background(
                        when {
                            warningActive -> CriticalRed.copy(alpha = 0.25f)
                            cautionActive -> AmberWarning.copy(alpha = 0.25f)
                            else -> MutedGreen.copy(alpha = 0.2f)
                        },
                        RoundedCornerShape(3.dp)
                    )
                    .border(
                        1.dp,
                        when {
                            warningActive -> CriticalRed
                            cautionActive -> AmberWarning
                            else -> MutedGreen
                        },
                        RoundedCornerShape(3.dp)
                    )
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                    .testTag("simulation_mode_indicator")
            ) {
                Text(
                    text = "SIMULATION MODE // SYNTHETIC",
                    color = when {
                        warningActive -> CriticalRed
                        cautionActive -> AmberWarning
                        else -> MutedGreen
                    },
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 8.sp
                )
            }
        }
    }
}

@Composable
fun BottomTacticalNav(
    currentDestination: MainNavDestination,
    onSelectDestination: (MainNavDestination) -> Unit
) {
    NavigationBar(
        containerColor = DeepGraphite,
        contentColor = CoolWhite,
        tonalElevation = 0.dp,
        modifier = Modifier
            .border(0.8.dp, TacticalPanelBorder)
            .testTag("bottom_tactical_nav")
    ) {
        MainNavDestination.values().forEach { dest ->
            val isSelected = currentDestination == dest
            NavigationBarItem(
                selected = isSelected,
                onClick = { onSelectDestination(dest) },
                icon = {
                    Icon(
                        imageVector = dest.icon,
                        contentDescription = dest.title,
                        tint = if (isSelected) TechnicalBlue else Titanium,
                        modifier = Modifier.size(20.dp)
                    )
                },
                label = {
                    Text(
                        text = dest.title.uppercase(),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 9.sp,
                        color = if (isSelected) CoolWhite else Titanium
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = TechnicalBlue.copy(alpha = 0.2f),
                    selectedIconColor = TechnicalBlue,
                    unselectedIconColor = Titanium,
                    selectedTextColor = CoolWhite,
                    unselectedTextColor = Titanium
                ),
                modifier = Modifier.testTag(dest.tag)
            )
        }
    }
}
