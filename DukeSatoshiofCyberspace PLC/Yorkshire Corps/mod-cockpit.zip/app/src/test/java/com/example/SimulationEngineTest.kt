package com.example

import com.example.core.model.StandardFaults
import com.example.core.model.SystemStatus
import com.example.core.model.VehicleType
import com.example.core.simulation.ArmouredSimulation
import com.example.core.simulation.AviationSimulation
import com.example.core.simulation.NavalSimulation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SimulationEngineTest {

    @Test
    fun testNavalSimulationPhysicsAndFlooding() {
        val naval = NavalSimulation()
        naval.initialize(null)

        val initialTelem = naval.getTelemetry()
        assertEquals(VehicleType.NAVAL, initialTelem.vehicleType)
        assertTrue(initialTelem.speed > 0f)

        // Step forward with high throttle
        for (i in 0 until 50) {
            naval.step(0.05f, throttleInput = 1.0f, steeringInput = 0.5f, secondaryInput = 0f)
        }
        val advancedTelem = naval.getTelemetry()
        assertTrue("Speed should increase with full throttle", advancedTelem.speed >= initialTelem.speed)
        assertTrue("Heading should change with steering input", advancedTelem.headingDeg != initialTelem.headingDeg)

        // Inject flooding fault
        val floodFault = StandardFaults.faults.first { it.id == "NV_FLOOD_B1" }
        naval.injectFault(floodFault)
        for (i in 0 until 40) {
            naval.step(0.05f, 0.5f, 0f, 0f)
        }

        val floodedTelem = naval.getTelemetry()
        val b1Level = floodedTelem.customMetrics["bilgeLevelB1Pct"] ?: 0f
        assertTrue("Bilge level should rise after flooding fault", b1Level > 0f)
        assertTrue("Master Caution or Warning should trigger", floodedTelem.masterCautionActive || floodedTelem.masterWarningActive)

        // Start emergency pump
        naval.toggleEmergencyPump(true)
        for (i in 0 until 80) {
            naval.step(0.05f, 0.5f, 0f, 0f)
        }
        val pumpedTelem = naval.getTelemetry()
        val pumpedB1 = pumpedTelem.customMetrics["bilgeLevelB1Pct"] ?: 0f
        assertTrue("Pump should mitigate bilge flooding", pumpedB1 < b1Level)
    }

    @Test
    fun testArmouredSimulationPowertrainAndThermal() {
        val armoured = ArmouredSimulation()
        armoured.initialize(null)

        val initTelem = armoured.getTelemetry()
        assertEquals(VehicleType.ARMOURED, initTelem.vehicleType)

        // Accelerate
        for (i in 0 until 60) {
            armoured.step(0.05f, throttleInput = 1.0f, steeringInput = 0f, secondaryInput = 0f)
        }
        val fastTelem = armoured.getTelemetry()
        assertTrue("Speed should increase with throttle", fastTelem.speed > initTelem.speed)

        // Inject cooling fault
        val coolFault = StandardFaults.faults.first { it.id == "AR_COOL_PUMP" }
        armoured.injectFault(coolFault)
        val initialTemp = fastTelem.coolantTempC

        for (i in 0 until 50) {
            armoured.step(0.05f, throttleInput = 0.8f, steeringInput = 0f, secondaryInput = 0f)
        }
        val hotTelem = armoured.getTelemetry()
        assertTrue("Coolant temp should rise after fan pump failure", hotTelem.coolantTempC > initialTemp)

        // Clear fault
        armoured.clearFault(coolFault.id)
        for (i in 0 until 50) {
            armoured.step(0.05f, throttleInput = 0.2f, steeringInput = 0f, secondaryInput = 0f)
        }
        val recoveredTelem = armoured.getTelemetry()
        assertTrue("Coolant temp should begin cooling off after clearance", recoveredTelem.coolantTempC < hotTelem.coolantTempC)
    }

    @Test
    fun testAviationSimulationFlightEnvelopeAndHydraulics() {
        val aviation = AviationSimulation()
        aviation.initialize(null)

        val initTelem = aviation.getTelemetry()
        assertEquals(VehicleType.AVIATION, initTelem.vehicleType)
        assertTrue(initTelem.altitudeOrDepth > 10000f)

        // Pull nose up (climb)
        for (i in 0 until 40) {
            aviation.step(0.05f, throttleInput = 0.85f, steeringInput = 0f, secondaryInput = 0.4f)
        }
        val climbTelem = aviation.getTelemetry()
        assertTrue("Altitude should increase during climb", climbTelem.altitudeOrDepth >= initTelem.altitudeOrDepth)

        // Inject hydraulic circuit A leak
        val hydFault = StandardFaults.faults.first { it.id == "AV_HYD_A_LEAK" }
        aviation.injectFault(hydFault)

        for (i in 0 until 70) {
            aviation.step(0.05f, throttleInput = 0.7f, steeringInput = 0f, secondaryInput = 0f)
        }
        val leakedTelem = aviation.getTelemetry()
        val hydAPressure = leakedTelem.customMetrics["hydCircuitA"] ?: 3000f
        assertTrue("Hydraulic circuit A pressure should drop below 2500 psi (was $hydAPressure)", hydAPressure < 2500f)

        // Isolate circuit A
        aviation.toggleHydCircuitA(true)
        val isolatedPressure = leakedTelem.customMetrics["hydCircuitA"] ?: 0f
        for (i in 0 until 30) {
            aviation.step(0.05f, throttleInput = 0.7f, steeringInput = 0f, secondaryInput = 0f)
        }
        val stabilizedTelem = aviation.getTelemetry()
        val postIsoPressure = stabilizedTelem.customMetrics["hydCircuitA"] ?: 0f
        assertEquals("Isolated line should stop dropping", isolatedPressure, postIsoPressure, 20f)
    }
}
