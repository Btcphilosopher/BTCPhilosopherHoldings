# MOD COCKPIT
### Enterprise-Grade Simulated Military Vehicle Instrumentation & Systems Monitor

**MOD COCKPIT** is an enterprise-grade native Android application for simulated military vehicle instrumentation, platform systems monitoring, mission visualization, and operational training.

---

## 1. VEHICLE SIMULATION DOMAINS

1. **NAVAL SYSTEMS — HMS Vanguard (BB-23)**
   - **Bridge & Navigation:** Gyrocompass heading, speed through water (knots), sounding depth, rudder rate of turn, sea state wave drift.
   - **Propulsion & Steam Turbines:** Port and starboard shaft RPM, boiler pressure (bar), lube oil temperature and pressure.
   - **Ship Electrical Distribution:** 440V AC 60Hz 3.2 MW generation, bus voltage stabilization, hotel load shedding.
   - **Hull & Damage Control:** Compartmental damage control grid (Bow A1, Forward Magazine A2, Engine Room B1, Boiler Room B2, Auxiliary Machinery C1, Aft Steering C2), flood rate simulation, and emergency bilge drainage pumps.

2. **ARMOURED SYSTEMS — MBT-90 Centurion**
   - **Powertrain & Transmission:** 1,500 BHP V12 twin-turbocharged multi-fuel diesel, automatic powershift transmission (Gears 1-6 + Reverse), torque converter lockup.
   - **Mobility & Suspension:** Road speed (km/h), hydro-pneumatic suspension deflection per roadwheel, track tension (kN), slip ratio (%), and terrain slope inclination (pitch & roll).
   - **Thermal & Electrical:** Cooling radiator fan circuit, coolant temperature (°C), 28V DC electrical bus, battery bank, and Auxiliary Power Unit (APU) for silent watch.

3. **AVIATION SYSTEMS — XF-41 Tempest**
   - **Aerodynamics & Flight Envelope:** Indicated airspeed (knots IAS / synthetic Mach), barometric altitude (ft), vertical speed (ft/min), pitch ladder (-90° to +90°), bank angle, G-load factor (-2G to +9G).
   - **Twin Turbofans:** Spool RPM (% N2), Turbine Inlet Temperature (TIT °C), afterburner stage and dynamic thrust cones, fuel flow (kg/h).
   - **Flight Controls & Hydraulics:** Dual 3,000 psi hydraulic circuits (Circuit A & Circuit B), line isolation valves, fly-by-wire envelope limiter, and pitot heat anti-icing.

---

## 2. THE SIGNATURE COCKPIT VISUALIZATION

The central instrument area features a real-time, hardware-accelerated 2.5D/3D procedural technical renderer:
- **Naval Mode:** Fully articulated battleship silhouette, animated dynamic ocean wave grid responding to sea state and ship speed, wake trails, rotating radar mast scanner, and color-coded watertight compartment cutaways.
- **Armoured Mode:** Articulated tank silhouette with rotating roadwheels linked to vehicle speed, dynamic track belt, suspension deflection over undulating terrain, and dust particle trails.
- **Aviation Mode:** Stealth delta-wing fighter banking and pitching in 3D projection, dynamic HUD pitch ladder, velocity vector (flight path marker), altitude cloud lines, and animated afterburner flame cones.
- **Interactive Camera:** Drag horizontally or vertically on the viewport to orbit around the vehicle in real time. Switch between **3D CHASE**, **TOP-DOWN**, and **CUTAWAY** camera modes.

---

## 3. ARCHITECTURE & TECHNOLOGY STACK

- **Language:** Kotlin
- **UI Framework:** Jetpack Compose with custom Material 3 British defence engineering design tokens.
- **Architecture:** Clean MVVM with unidirectional data flow (UDF).
- **Simulation Engine:** Deterministic, time-stepped Euler integration (~30 Hz) with bounded physical states and reproducible initial conditions.
- **Persistence:** Android Jetpack Room Database (`CockpitDatabase`) storing session logs and downsampled telemetry frames for multi-channel replay.
- **Navigation:** Five primary destinations:
  - `HANGAR`: Vehicle selection, readiness %, displacement, specifications.
  - `COCKPIT`: Central 3D viewport, primary circular dials, vertical tapes, tactical controls, and layout switchers.
  - `SYSTEMS`: Full engineering diagnostic tree, operating tolerances, and live training fault injection controls.
  - `MISSIONS`: Non-combat training scenarios with objective checklists, live scoring, and debrief reports.
  - `RECORDS`: Historical session records, time scrubber replay timeline, and CSV export.

---

## 4. MATHEMATICAL FORMULAS & SIMULATION UNITS

1. **Naval Hydrodynamic Speed:**
   $$\frac{dv}{dt} = \frac{T_{thrust} - c_d \cdot v^2}{M_{ship}}$$
   Where $v$ is speed in knots, $T_{thrust} \propto RPM_{shaft}$, and $M_{ship} = 44,500$ tons.

2. **Aviation Turn Rate & G-Load:**
   $$\omega_{turn} = \frac{g \cdot \tan(\phi)}{V_{TAS}}, \quad N_z = \frac{1}{\cos(\phi)}$$
   Where $\phi$ is the bank angle, $g = 9.81\text{ m/s}^2$, and $N_z$ is the aerodynamic load factor.

3. **Armoured Powertrain & Thermal Excursion:**
   $$\frac{dT_{coolant}}{dt} = \dot{Q}_{combustion}(RPM) - \dot{Q}_{radiator}(\Delta P_{fan}, v)$$

---

## 5. BUILD & RUN INSTRUCTIONS

Compile the project and run unit tests via Gradle:

```bash
# Compile the application
gradle assembleDebug

# Run unit and Robolectric tests
gradle :app:testDebugUnitTest
```
