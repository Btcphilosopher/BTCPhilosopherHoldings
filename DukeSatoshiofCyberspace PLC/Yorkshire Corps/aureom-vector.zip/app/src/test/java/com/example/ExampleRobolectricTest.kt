package com.example

import android.Manifest
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.sources.DeviceTelemetryProvider
import com.example.domain.model.SensorAvailability
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Aureom Vector", appName)
    }

    @Test
    fun `location permission state is reflected accurately in DeviceTelemetryProvider`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val shadowApp = Shadows.shadowOf(app)
        val provider = DeviceTelemetryProvider(app)

        shadowApp.denyPermissions(
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        assertFalse(provider.hasLocationPermission())
        provider.refreshLocationStream()
        assertEquals(SensorAvailability.PERMISSION_REQUIRED, provider.state.value.gnssAvailability)

        shadowApp.grantPermissions(Manifest.permission.ACCESS_COARSE_LOCATION)
        assertTrue(provider.hasLocationPermission())
    }

    @Test
    fun `ktor websocket observation json parses accurately`() {
        val json = """
            {"type":"observation","messageId":"K-1","sourceId":"KTOR-WS-FEED","sequenceNumber":1,
             "sensorTimestampMs":1700000001000,"latDeg":55.42,"lonDeg":1.85,"groundSpeedMps":12.5,
             "courseOverGroundDeg":90.0,"altitudeMeters":0.0,"altitudeReference":"SURFACE",
             "reportedIdentity":"MV TEST","reportedIdentitySource":"AIS","objectCategory":"MARITIME_VESSEL",
             "uncertaintyMeters":30.0,"isClutter":false}
        """.trimIndent()
        val parsed = com.example.data.sources.KtorWebSocketSourceAdapter.parseObservationJson(json, 1700000001100L)
        org.junit.Assert.assertNotNull(parsed)
        assertEquals("MV TEST", parsed?.reportedIdentity)
        assertEquals(55.42, parsed?.latDeg ?: 0.0, 1e-6)
    }
}
