package com.example

import com.example.data.sources.KtorWebSocketSourceAdapter
import com.example.domain.alerts.AlertEngine
import com.example.domain.geo.GeoMath
import com.example.domain.model.AlertResolutionState
import com.example.domain.model.AlertRuleType
import com.example.domain.model.AltitudeReference
import com.example.domain.model.ConnectionState
import com.example.domain.model.GeoPoint
import com.example.domain.model.MonitoredZone
import com.example.domain.model.ObjectCategory
import com.example.domain.model.PositionQuality
import com.example.domain.model.RawSourceMessage
import com.example.domain.model.ScenarioId
import com.example.domain.model.SimulatorConfig
import com.example.domain.model.SourceHealthInfo
import com.example.domain.model.SourceType
import com.example.domain.model.TrackStatus
import com.example.domain.model.ZoneShape
import com.example.domain.sim.RadarSimulator
import com.example.domain.tracking.TrackAssociator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class AureomDomainTests {

    private val northSeaOrigin = GeoPoint(55.4200, 1.8500)

    @Test
    fun `coordinate conversion roundtrip and bearing wraparound`() {
        val target = GeoMath.destinationPoint(northSeaOrigin, 45.0, 10_000.0)
        val enu = GeoMath.toEnu(target, northSeaOrigin)
        val back = GeoMath.fromEnu(enu, northSeaOrigin)
        assertTrue(abs(target.latDeg - back.latDeg) < 0.0005)
        assertTrue(abs(target.lonDeg - back.lonDeg) < 0.0005)

        val dist = GeoMath.haversineDistanceMeters(northSeaOrigin, target)
        assertEquals(10_000.0, dist, 15.0)

        assertEquals(2.0, GeoMath.shortestAngularDeltaDeg(359.0, 1.0), 1e-6)
        assertEquals(-2.0, GeoMath.shortestAngularDeltaDeg(1.0, 359.0), 1e-6)
        assertEquals(355.0, GeoMath.normalizeBearingDeg(-5.0), 1e-6)
    }

    @Test
    fun `invalid positions and duplicate messages are rejected cleanly`() {
        val associator = TrackAssociator(northSeaOrigin)
        val invalidLat = RawSourceMessage(
            messageId = "BAD-1",
            sourceId = "SRC-1",
            sourceType = SourceType.SYNTHETIC_SIM,
            sequenceNumber = 1L,
            sensorTimestampMs = 1_000_000L,
            receivedAtMs = 1_000_000L,
            latDeg = 95.0, // invalid > 90
            lonDeg = 1.8,
            groundSpeedMps = 10.0,
            courseOverGroundDeg = 90.0,
            headingDeg = null,
            altitudeMeters = 0.0,
            altitudeReference = AltitudeReference.SURFACE,
            reportedIdentity = "TEST",
            reportedIdentitySource = "AIS",
            objectCategory = ObjectCategory.MARITIME_VESSEL,
            uncertaintyMeters = 20.0
        )
        val badRes = associator.ingest(invalidLat)
        assertNull(badRes.acceptedObservation)
        assertNotNull(badRes.rejectionReason)

        val valid = invalidLat.copy(messageId = "GOOD-1", sequenceNumber = 2L, latDeg = 55.42)
        val first = associator.ingest(valid)
        assertNotNull(first.acceptedObservation)
        assertFalse(first.isDuplicate)

        val dup = associator.ingest(valid)
        assertNull(dup.acceptedObservation)
        assertTrue(dup.isDuplicate)
    }

    @Test
    fun `tracks with identical labels at different positions are never falsely merged`() {
        val associator = TrackAssociator(northSeaOrigin)
        val posA = GeoMath.destinationPoint(northSeaOrigin, 0.0, 5_000.0)
        val posB = GeoMath.destinationPoint(northSeaOrigin, 180.0, 5_000.0)

        val mA = RawSourceMessage(
            messageId = "A1", sourceId = "AIS-1", sourceType = SourceType.SYNTHETIC_SIM,
            sequenceNumber = 1, sensorTimestampMs = 10_000L, receivedAtMs = 10_000L,
            latDeg = posA.latDeg, lonDeg = posA.lonDeg, groundSpeedMps = 10.0,
            courseOverGroundDeg = 0.0, headingDeg = null, altitudeMeters = 0.0,
            altitudeReference = AltitudeReference.SURFACE, reportedIdentity = "NORTH WORKBOAT",
            reportedIdentitySource = "VHF", objectCategory = ObjectCategory.MARITIME_VESSEL,
            uncertaintyMeters = 30.0
        )
        val mB = mA.copy(
            messageId = "B1", sequenceNumber = 2,
            latDeg = posB.latDeg, lonDeg = posB.lonDeg
        )

        val rA = associator.ingest(mA)
        val rB = associator.ingest(mB)
        assertTrue(rA.associatedTrackId != rB.associatedTrackId)
        val preds = associator.buildDisplayPredictions(10_500L, northSeaOrigin)
        assertEquals(2, preds.size)
        assertTrue(preds.all { !it.track.identityVerified })
    }

    @Test
    fun `observation age and extrapolation capping stop runaway predicted motion`() {
        val associator = TrackAssociator(northSeaOrigin)
        val m = RawSourceMessage(
            messageId = "OBS-1", sourceId = "SRC", sourceType = SourceType.SYNTHETIC_SIM,
            sequenceNumber = 1, sensorTimestampMs = 100_000L, receivedAtMs = 100_000L,
            latDeg = northSeaOrigin.latDeg, lonDeg = northSeaOrigin.lonDeg,
            groundSpeedMps = 50.0, courseOverGroundDeg = 90.0, headingDeg = null,
            altitudeMeters = 500.0, altitudeReference = AltitudeReference.AMSL,
            reportedIdentity = "TEST-1", reportedIdentitySource = "ADS-B",
            objectCategory = ObjectCategory.CIVILIAN_AIRCRAFT, uncertaintyMeters = 40.0
        )
        associator.ingest(m)

        val fresh = associator.buildDisplayPredictions(101_000L, northSeaOrigin).single()
        assertEquals(PositionQuality.MEASURED, fresh.positionQuality)
        assertFalse(fresh.isExtrapolationCapped)

        val stale = associator.buildDisplayPredictions(
            nowMs = 135_000L,
            ownPosition = northSeaOrigin,
            staleThresholdMs = 15_000L,
            maxExtrapolationMs = 20_000L
        ).single()
        assertEquals(PositionQuality.EXTRAPOLATED, stale.positionQuality)
        assertEquals(TrackStatus.STALE, stale.track.status)
        assertTrue(stale.isExtrapolationCapped)
        assertEquals(20_000L, stale.extrapolationDurationMs)
    }

    @Test
    fun `zone hysteresis prevents chatter and acknowledgement preserves active resolution`() {
        val engine = AlertEngine(confirmObservationsRequired = 2)
        val associator = TrackAssociator(northSeaOrigin)
        val zone = MonitoredZone(
            zoneId = "Z1",
            name = "Test Safety Zone",
            scenarioId = ScenarioId.NORTH_SEA_OBSERVATION,
            shape = ZoneShape.CIRCLE,
            center = northSeaOrigin,
            radiusMeters = 1000.0,
            hysteresisMeters = 200.0,
            loiterThresholdSec = 30
        )

        // Two observations inside zone confirm entry
        for (i in 1..2) {
            val insidePos = GeoMath.destinationPoint(northSeaOrigin, 0.0, 700.0)
            associator.ingest(
                RawSourceMessage(
                    messageId = "IN-$i", sourceId = "S", sourceType = SourceType.SYNTHETIC_SIM,
                    sequenceNumber = i.toLong(), sensorTimestampMs = 10_000L + i * 1000L,
                    receivedAtMs = 10_000L + i * 1000L, latDeg = insidePos.latDeg, lonDeg = insidePos.lonDeg,
                    groundSpeedMps = 5.0, courseOverGroundDeg = 0.0, headingDeg = null,
                    altitudeMeters = 0.0, altitudeReference = AltitudeReference.SURFACE,
                    reportedIdentity = "VESSEL", reportedIdentitySource = "AIS",
                    objectCategory = ObjectCategory.MARITIME_VESSEL, uncertaintyMeters = 20.0
                )
            )
            val preds = associator.buildDisplayPredictions(10_000L + i * 1000L, northSeaOrigin)
            engine.evaluate(10_000L + i * 1000L, preds, listOf(zone), emptyList(), 15_000L)
        }

        val entryAlert = engine.getAlerts().first { it.ruleType == AlertRuleType.ZONE_ENTRY }
        assertEquals(AlertResolutionState.ACTIVE, entryAlert.resolutionState)
        assertFalse(entryAlert.acknowledged)

        // Acknowledge must NOT auto-resolve active condition
        engine.acknowledgeAlert(entryAlert.alertId, 12_500L)
        val acked = engine.getAlerts().first { it.alertId == entryAlert.alertId }
        assertTrue(acked.acknowledged)
        assertEquals(AlertResolutionState.ACTIVE, acked.resolutionState)

        // Noisy step just 50m outside (within 200m hysteresis) must NOT trigger exit!
        val edgePos = GeoMath.destinationPoint(northSeaOrigin, 0.0, 1050.0)
        associator.ingest(
            RawSourceMessage(
                messageId = "EDGE-1", sourceId = "S", sourceType = SourceType.SYNTHETIC_SIM,
                sequenceNumber = 3L, sensorTimestampMs = 13_000L, receivedAtMs = 13_000L,
                latDeg = edgePos.latDeg, lonDeg = edgePos.lonDeg, groundSpeedMps = 5.0,
                courseOverGroundDeg = 0.0, headingDeg = null, altitudeMeters = 0.0,
                altitudeReference = AltitudeReference.SURFACE, reportedIdentity = "VESSEL",
                reportedIdentitySource = "AIS", objectCategory = ObjectCategory.MARITIME_VESSEL,
                uncertaintyMeters = 20.0
            )
        )
        engine.evaluate(13_000L, associator.buildDisplayPredictions(13_000L, northSeaOrigin), listOf(zone), emptyList(), 15_000L)
        assertTrue(engine.getAlerts().none { it.ruleType == AlertRuleType.ZONE_EXIT })
    }

    @Test
    fun `replay determinism and disconnect recovery alert transitions`() {
        val cfg = SimulatorConfig(scenarioId = ScenarioId.NORTH_SEA_OBSERVATION, seed = 998877L)
        val simA = RadarSimulator(cfg)
        val simB = RadarSimulator(cfg)

        val batchA = (1..10).flatMap { simA.step(1000L, 1_700_000_000_000L + it * 1000L) }
        val batchB = (1..10).flatMap { simB.step(1000L, 1_700_000_000_000L + it * 1000L) }
        assertEquals(batchA, batchB)

        // Disconnect & recovery alert transition
        val engine = AlertEngine()
        val downSource = SourceHealthInfo(
            sourceId = "KTOR-WS-FEED", name = "Ktor Backend", sourceType = SourceType.KTOR_WEBSOCKET,
            connectionState = ConnectionState.DISCONNECTED, lastMessageTimestampMs = 1000L,
            messagesAccepted = 5, messagesRejected = 0, duplicatesDropped = 0,
            averageLatencyMs = 20, outageActive = true, endpoint = "ws://10.0.2.2:8080/ws/stream"
        )
        engine.evaluate(2000L, emptyList(), emptyList(), listOf(downSource), 15_000L)
        assertEquals(AlertResolutionState.ACTIVE, engine.getAlerts().single().resolutionState)

        // Recovery clears condition
        engine.evaluate(
            3000L,
            emptyList(),
            emptyList(),
            listOf(downSource.copy(connectionState = ConnectionState.CONNECTED, outageActive = false)),
            15_000L
        )
        assertEquals(AlertResolutionState.CONDITION_CLEARED, engine.getAlerts().single().resolutionState)
    }
}
