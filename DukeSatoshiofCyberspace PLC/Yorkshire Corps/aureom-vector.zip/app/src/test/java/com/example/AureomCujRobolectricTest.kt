package com.example

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w1024dp-h768dp-land")
class AureomCujRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `launch home start North Sea simulation open radar and verify scope and alerts`() {
        composeRule.mainClock.autoAdvance = false
        composeRule.mainClock.advanceTimeBy(500L)

        // Verify persistent mode indicator & Start Simulation action on Home
        assertTrue(composeRule.onAllNodesWithTag("mode_indicator_badge").fetchSemanticsNodes().isNotEmpty())
        composeRule.onNodeWithTag("start_simulation_button")
            .performScrollTo()
            .performClick()

        // Advance clock for NavHost transition & initial simulator frame
        composeRule.mainClock.advanceTimeBy(1200L)

        // Verify Radar Scope + Track Table in Tablet Landscape
        assertTrue(composeRule.onAllNodesWithTag("radar_scope_canvas").fetchSemanticsNodes().isNotEmpty())
        assertTrue(composeRule.onAllNodesWithTag("tabular_track_list").fetchSemanticsNodes().isNotEmpty())

        // Toggle outage button & navigate to Alerts screen
        composeRule.onNodeWithTag("toggle_outage_button").performClick()
        composeRule.mainClock.advanceTimeBy(800L)

        composeRule.onNodeWithTag("top_alerts_badge").performClick()
        composeRule.mainClock.advanceTimeBy(1000L)
        assertTrue(composeRule.onAllNodesWithTag("alerts_export_button").fetchSemanticsNodes().isNotEmpty())
    }
}
