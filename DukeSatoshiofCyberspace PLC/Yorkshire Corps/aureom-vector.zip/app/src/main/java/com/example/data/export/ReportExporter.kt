package com.example.data.export

import com.example.domain.geo.GeoMath
import com.example.domain.model.AlertRecord
import com.example.domain.model.CoordinateFormat
import com.example.domain.model.DisplayPrediction
import com.example.domain.model.DistanceUnit
import com.example.domain.model.MonitoredZone
import com.example.domain.model.ObservationArea
import com.example.domain.model.OperatingMode
import com.example.domain.model.SourceHealthInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object ReportExporter {
    private val utcFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    fun buildReport(
        generatedAtMs: Long,
        mode: OperatingMode,
        area: ObservationArea,
        seed: Long?,
        predictions: List<DisplayPrediction>,
        alerts: List<AlertRecord>,
        zones: List<MonitoredZone>,
        sources: List<SourceHealthInfo>,
        coordinateFormat: CoordinateFormat,
        distanceUnit: DistanceUnit
    ): String {
        val sb = StringBuilder()
        sb.appendLine("================================================================")
        sb.appendLine("AUREOM VECTOR — OBSERVATION & ALERT REPORT")
        sb.appendLine("================================================================")
        sb.appendLine("Generated UTC    : ${utcFormat.format(Date(generatedAtMs))}")
        sb.appendLine("Operating Mode   : ${mode.label}")
        sb.appendLine("Observation Area : ${area.name} (${area.referenceFrame})")
        sb.appendLine("Origin Reference : ${GeoMath.formatCoordinate(area.center, coordinateFormat)}")
        if (seed != null) {
            sb.appendLine("DeterministicSeed: $seed")
        }
        sb.appendLine()

        sb.appendLine("--- SENSOR & FEED SOURCES (${sources.size}) ---")
        sources.forEach { src ->
            val lastTs = src.lastMessageTimestampMs?.let { utcFormat.format(Date(it)) } ?: "NEVER"
            sb.appendLine(
                "• ${src.name} [${src.sourceId}] | State=${src.connectionState.label} | " +
                    "Accepted=${src.messagesAccepted} | Rejected=${src.messagesRejected} | " +
                    "Dups=${src.duplicatesDropped} | Last=$lastTs"
            )
        }
        sb.appendLine()

        sb.appendLine("--- MONITORED ZONES (${zones.size}) ---")
        zones.forEach { z ->
            sb.appendLine(
                "• ${z.name} [${z.zoneId}] | Shape=${z.shape.name} | " +
                    "Radius=${GeoMath.formatDistance(z.radiusMeters, distanceUnit)} | " +
                    "Dwell=${z.loiterThresholdSec}s | Enabled=${z.enabled}"
            )
        }
        sb.appendLine()

        sb.appendLine("--- TRACK PICTURE (${predictions.size}) ---")
        if (predictions.isEmpty()) {
            sb.appendLine("No active tracks at report time.")
        } else {
            predictions.forEach { pred ->
                val t = pred.track
                val idLabel = t.reportedIdentity?.let { "$it (${t.reportedIdentitySource ?: "unverified"})" }
                    ?: "UNLABELED (${t.reportedIdentitySource ?: "no transponder"})"
                sb.appendLine(
                    "• ${t.trackId} | $idLabel | Cat=${t.category.displayLabel} | " +
                        "Status=${t.status.badge} | Quality=${pred.positionQuality.badge}"
                )
                sb.appendLine(
                    "  Pos=${GeoMath.formatCoordinate(pred.displayPosition, coordinateFormat)} | " +
                        "Rng=${GeoMath.formatDistance(pred.rangeFromOriginMeters, distanceUnit)} | " +
                        "Brg=${GeoMath.formatBearing(pred.bearingFromOriginDeg)}"
                )
                sb.appendLine(
                    "  Spd=${GeoMath.formatSpeed(t.estimatedSpeedMps, distanceUnit)} | " +
                        "COG=${GeoMath.formatBearing(t.estimatedCourseDeg)} | " +
                        "Age=${GeoMath.formatAge(pred.observationAgeMs)} | " +
                        "Uncert=±${String.format(Locale.US, "%.0f", t.uncertaintyMeters)} m | " +
                        "Ambiguous=${t.ambiguousAssociation}"
                )
            }
        }
        sb.appendLine()

        sb.appendLine("--- ALERTS & OPERATOR DISPOSITION (${alerts.size}) ---")
        if (alerts.isEmpty()) {
            sb.appendLine("No alerts raised.")
        } else {
            alerts.forEach { a ->
                sb.appendLine(
                    "• [${a.severity.label}] ${a.alertId} — ${a.title} (${a.ruleType.label})"
                )
                sb.appendLine(
                    "  Resolution=${a.resolutionState.label} | Acknowledged=${a.acknowledged} | " +
                        "Occurrences=${a.occurrenceCount}"
                )
                sb.appendLine(
                    "  First=${utcFormat.format(Date(a.firstOccurrenceMs))} | " +
                        "Recent=${utcFormat.format(Date(a.lastOccurrenceMs))}"
                )
                sb.appendLine("  TriggerObs=${a.triggeringObservationIds.joinToString(", ").ifEmpty { "NONE" }}")
                if (a.operatorNotes.isNotBlank()) {
                    sb.appendLine("  OperatorNotes=${a.operatorNotes}")
                }
            }
        }
        sb.appendLine("================================================================")
        return sb.toString()
    }
}
