package com.example.domain.model

enum class OperatingMode(val label: String) {
    SIMULATION("SIMULATION"),
    REPLAY("REPLAY"),
    LIVE_OBSERVATION("LIVE OBSERVATION")
}

enum class ScenarioId(
    val title: String,
    val subtitle: String,
    val defaultRangeNm: Double,
    val rangePresetsNm: List<Double>
) {
    NORTH_SEA_OBSERVATION(
        title = "North Sea Observation",
        subtitle = "Central North Sea maritime lanes, offshore platforms & civilian airways",
        defaultRangeNm = 40.0,
        rangePresetsNm = listOf(5.0, 15.0, 40.0, 80.0)
    ),
    SOLENT_MARITIME_CROSSING(
        title = "Solent Maritime Crossing",
        subtitle = "Stationary coastal radar monitoring ferries, cargo traffic & VFR corridor",
        defaultRangeNm = 15.0,
        rangePresetsNm = listOf(2.0, 5.0, 15.0, 30.0)
    ),
    INDUSTRIAL_PERIMETER_SITE(
        title = "Industrial Perimeter Site",
        subtitle = "Short-range perimeter surveillance of ground vehicles & restricted approach",
        defaultRangeNm = 2.0,
        rangePresetsNm = listOf(0.5, 1.0, 2.0, 5.0)
    )
}

enum class RadarOrientationMode {
    NORTH_UP,
    HEADING_UP
}

enum class CoordinateFormat(val label: String) {
    DECIMAL_DEGREES("Decimal Deg (DD.dddd°)"),
    DEGREES_MINUTES("Deg Min (DD° MM.mmm')"),
    LOCAL_GRID_REF("Grid Reference")
}

enum class DistanceUnit(val label: String) {
    NAUTICAL("Nautical (NM / kt)"),
    METRIC_KM("Metric (km / km/h)"),
    METRIC_M("SI (m / m/s)")
}

enum class ObjectCategory(val displayLabel: String) {
    CIVILIAN_AIRCRAFT("Civilian Aircraft"),
    MARITIME_VESSEL("Maritime Vessel"),
    PERIMETER_VEHICLE("Perimeter Vehicle"),
    UNKNOWN_CONTACT("Unclassified Contact"),
    CLUTTER("Sensor Clutter")
}

enum class SourceType(val displayLabel: String) {
    SYNTHETIC_SIM("Synthetic Radar Sim"),
    KTOR_WEBSOCKET("Ktor WebSocket Feed"),
    RECORDED_FILE("Recorded Session"),
    DEVICE_GNSS("Device GNSS"),
    EXTERNAL_ADAPTER("External Sensor Adapter")
}

enum class PositionQuality(val badge: String) {
    MEASURED("MEASURED"),
    ESTIMATED("ESTIMATED"),
    EXTRAPOLATED("EXTRAPOLATED")
}

enum class TrackStatus(val badge: String) {
    TENTATIVE("TENTATIVE"),
    CONFIRMED("CONFIRMED"),
    COASTING("COASTING"),
    STALE("STALE"),
    LOST("LOST")
}

enum class AltitudeReference(val shortLabel: String) {
    AMSL("AMSL"),
    AGL("AGL"),
    PRESSURE_FL("FL"),
    SURFACE("SURFACE"),
    UNAVAILABLE("UNAVAIL")
}

data class GeoPoint(
    val latDeg: Double,
    val lonDeg: Double
)

data class ObservationArea(
    val scenarioId: ScenarioId,
    val name: String,
    val center: GeoPoint,
    val coastlinePolygons: List<List<GeoPoint>>,
    val referenceFrame: String = "WGS-84"
)

/**
 * Layer 1: Raw source message prior to validation and deduplication.
 */
data class RawSourceMessage(
    val messageId: String,
    val sourceId: String,
    val sourceType: SourceType,
    val sequenceNumber: Long,
    val sensorTimestampMs: Long,
    val receivedAtMs: Long,
    val latDeg: Double,
    val lonDeg: Double,
    val groundSpeedMps: Double?,
    val courseOverGroundDeg: Double?,
    val headingDeg: Double?,
    val altitudeMeters: Double?,
    val altitudeReference: AltitudeReference,
    val reportedIdentity: String?,
    val reportedIdentitySource: String?,
    val objectCategory: ObjectCategory,
    val uncertaintyMeters: Double,
    val isClutter: Boolean = false,
    val rawPayloadSummary: String = ""
)

/**
 * Layer 2: Validated and unit-explicit observation.
 */
data class ValidatedObservation(
    val observationId: String,
    val rawMessageId: String,
    val sourceId: String,
    val sourceType: SourceType,
    val sequenceNumber: Long,
    val sensorTimestampMs: Long,
    val ingestedAtMs: Long,
    val position: GeoPoint,
    val positionUncertaintyMeters: Double,
    val groundSpeedMps: Double?,
    val courseOverGroundDeg: Double?,
    val headingDeg: Double?,
    val altitudeMeters: Double?,
    val altitudeReference: AltitudeReference,
    val reportedIdentity: String?,
    val reportedIdentitySource: String?,
    val objectCategory: ObjectCategory,
    val isClutter: Boolean
)

data class TrackHistoryPoint(
    val position: GeoPoint,
    val timestampMs: Long,
    val quality: PositionQuality
)

data class AssociationEvent(
    val timestampMs: Long,
    val observationId: String,
    val sourceId: String,
    val gateDistanceMeters: Double,
    val ambiguousCandidates: Int,
    val summary: String
)

/**
 * Layer 3: Associated track maintained by the baseline kinematic tracker.
 * Note: reportedIdentity is never treated as verified identity.
 */
data class AssociatedTrack(
    val trackId: String,
    val category: ObjectCategory,
    val primarySourceId: String,
    val contributingSources: Set<String>,
    val reportedIdentity: String?,
    val reportedIdentitySource: String?,
    val identityVerified: Boolean = false,
    val lastMeasuredPosition: GeoPoint,
    val lastObservationId: String,
    val lastObservationTimestampMs: Long,
    val estimatedPosition: GeoPoint,
    val estimatedSpeedMps: Double?,
    val estimatedCourseDeg: Double?,
    val headingDeg: Double?,
    val altitudeMeters: Double?,
    val altitudeReference: AltitudeReference,
    val uncertaintyMeters: Double,
    val status: TrackStatus,
    val observationCount: Int,
    val missedScanCount: Int,
    val ambiguousAssociation: Boolean,
    val ambiguousTrackIds: List<String>,
    val history: List<TrackHistoryPoint>,
    val associationHistory: List<AssociationEvent>
)

/**
 * Layer 4: Display prediction bounded against indefinite extrapolation.
 */
data class DisplayPrediction(
    val track: AssociatedTrack,
    val displayPosition: GeoPoint,
    val positionQuality: PositionQuality,
    val observationAgeMs: Long,
    val extrapolationDurationMs: Long,
    val isExtrapolationCapped: Boolean,
    val rangeFromOriginMeters: Double,
    val bearingFromOriginDeg: Double
)

/**
 * Layer 5: Operator annotations & classifications attached to tracks or alerts.
 */
data class OperatorAnnotation(
    val targetId: String,
    val note: String,
    val updatedAtMs: Long
)

enum class ZoneShape {
    CIRCLE,
    POLYGON
}

data class MonitoredZone(
    val zoneId: String,
    val name: String,
    val scenarioId: ScenarioId,
    val shape: ZoneShape,
    val center: GeoPoint,
    val radiusMeters: Double,
    val polygonVertices: List<GeoPoint> = emptyList(),
    val alertOnEntry: Boolean = true,
    val alertOnExit: Boolean = true,
    val loiterThresholdSec: Int = 60,
    val hysteresisMeters: Double = 150.0,
    val enabled: Boolean = true
)

enum class AlertRuleType(val label: String) {
    ZONE_ENTRY("Zone Entry"),
    ZONE_EXIT("Zone Exit"),
    ZONE_LOITER("Extended Dwell / Loiter"),
    TRACK_STALE("Track Stale"),
    SOURCE_CONNECTION_LOSS("Source Connection Loss"),
    INVALID_SOURCE_DATA("Invalid Source Data")
}

enum class AlertSeverity(val label: String) {
    INFO("INFO"),
    CAUTION("CAUTION"),
    CRITICAL("CRITICAL")
}

enum class AlertResolutionState(val label: String) {
    ACTIVE("ACTIVE"),
    CONDITION_CLEARED("CONDITION CLEARED"),
    RESOLVED("RESOLVED")
}

data class AlertRecord(
    val alertId: String,
    val ruleType: AlertRuleType,
    val severity: AlertSeverity,
    val title: String,
    val description: String,
    val trackId: String?,
    val zoneId: String?,
    val sourceId: String?,
    val triggeringObservationIds: List<String>,
    val firstOccurrenceMs: Long,
    val lastOccurrenceMs: Long,
    val occurrenceCount: Int,
    val acknowledged: Boolean,
    val acknowledgedAtMs: Long?,
    val resolutionState: AlertResolutionState,
    val operatorNotes: String
)

enum class ConnectionState(val label: String) {
    CONNECTED("CONNECTED"),
    DEGRADED("DEGRADED"),
    DISCONNECTED("DISCONNECTED"),
    STANDBY("STANDBY")
}

data class SourceHealthInfo(
    val sourceId: String,
    val name: String,
    val sourceType: SourceType,
    val connectionState: ConnectionState,
    val lastMessageTimestampMs: Long?,
    val messagesAccepted: Long,
    val messagesRejected: Long,
    val duplicatesDropped: Long,
    val averageLatencyMs: Long,
    val outageActive: Boolean,
    val endpoint: String
)

data class SimulatorConfig(
    val scenarioId: ScenarioId = ScenarioId.NORTH_SEA_OBSERVATION,
    val seed: Long = 20260401L,
    val tickIntervalMs: Long = 1000L,
    val missedDetectionProb: Double = 0.04,
    val clutterPerScan: Int = 1,
    val delayedMessageProb: Double = 0.08,
    val delayMs: Long = 2500L,
    val duplicateMessageProb: Double = 0.05,
    val positionNoiseSigmaMeters: Double = 45.0,
    val sensorOutageActive: Boolean = false
)

enum class SensorAvailability(val label: String) {
    AVAILABLE("AVAILABLE"),
    PERMISSION_REQUIRED("PERMISSION REQ"),
    UNAVAILABLE("UNAVAILABLE")
}

data class DeviceTelemetryState(
    val gnssAvailability: SensorAvailability = SensorAvailability.PERMISSION_REQUIRED,
    val gnssPosition: GeoPoint? = null,
    val gnssAccuracyMeters: Float? = null,
    val gnssTimestampMs: Long? = null,
    val gnssProvider: String = "NONE",
    val orientationAvailability: SensorAvailability = SensorAvailability.UNAVAILABLE,
    val deviceHeadingDeg: Float? = null,
    val devicePitchDeg: Float? = null,
    val deviceRollDeg: Float? = null,
    val orientationAccuracyLabel: String = "UNAVAILABLE",
    val orientationTimestampMs: Long? = null
)

data class SystemMetricsSnapshot(
    val frameTimeMs: Double = 16.6,
    val estimatedFps: Double = 60.0,
    val usedMemoryMb: Double = 0.0,
    val maxMemoryMb: Double = 0.0,
    val updateLatencyMs: Long = 0L,
    val queueDepth: Int = 0,
    val maxQueueDepth: Int = 256,
    val activeTracksCount: Int = 0,
    val totalObservationsProcessed: Long = 0L,
    val droppedBackpressureCount: Long = 0L,
    val batteryDrainEstimate: String = "Nominal (1 Hz sim)"
)

data class ReplaySessionSummary(
    val sessionId: String,
    val title: String,
    val scenarioId: ScenarioId,
    val seed: Long,
    val startedAtMs: Long,
    val endedAtMs: Long,
    val observationCount: Int,
    val alertCount: Int,
    val isBuiltInDemo: Boolean = false
)

data class ReplayPlaybackState(
    val activeSession: ReplaySessionSummary? = null,
    val isPlaying: Boolean = false,
    val speedMultiplier: Float = 1.0f,
    val currentOffsetMs: Long = 0L,
    val totalDurationMs: Long = 0L,
    val eventMarkersMs: List<Long> = emptyList()
)

data class AppSettingsState(
    val nightMode: Boolean = true,
    val reducedMotion: Boolean = false,
    val colorBlindSymbols: Boolean = false,
    val textScale: Float = 1.0f,
    val coordinateFormat: CoordinateFormat = CoordinateFormat.DECIMAL_DEGREES,
    val distanceUnit: DistanceUnit = DistanceUnit.NAUTICAL,
    val staleThresholdSec: Int = 15,
    val maxExtrapolationSec: Int = 20,
    val trailLength: Int = 30,
    val showMapOverlay: Boolean = true,
    val showSweepAnimation: Boolean = true,
    val orientationMode: RadarOrientationMode = RadarOrientationMode.NORTH_UP,
    val backendWsUrl: String = "ws://10.0.2.2:8080/ws/stream",
    val backendAuthToken: String = "aureom-dev-token",
    val useRemoteBackend: Boolean = false
)
